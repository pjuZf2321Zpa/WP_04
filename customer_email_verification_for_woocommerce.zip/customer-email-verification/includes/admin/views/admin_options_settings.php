<?php
/**
 * Admin Options Settings Template (ZUI)
 *
 * Renders the Settings tab: a ZUI sidebar (one item per section) + Quick Help,
 * and a content column with one .zui-section per sidebar item. Section
 * switching is handled client-side by the library JS (data-zui-section).
 *
 * Field markup is still produced by render_settings_fields() — restyled in a
 * later step. The .panel[data-cev-section] wrapper is preserved because the
 * per-section AJAX save (admin.js → cev_save_section) collects fields from it.
 *
 * Expects via $this (admin instance):
 *   render_settings_fields(), get_cev_signup_verification_settings_data(),
 *   get_cev_checkout_verification_settings_data(),
 *   get_cev_general_settings_data(), get_cev_settings_data_login_otp(),
 *   get_cev_2fa_settings_data(), get_cev_spam_protection_settings_data(),
 *   get_cev_advanced_settings_data()
 *
 * @package Customer_Email_Verification_Pro
 * @since 2.10.0
 *
 * Expected variables, supplied by the including scope:
 *
 * @var WC_Customer_Email_Verification_Admin_Pro $this The admin object that included this template.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Read-only page reference for the form action URL; no state change.
$cev_page    = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';
$form_action = admin_url( 'admin.php?page=' . $cev_page );

// Inline Lucide-style icon helper (the library expects an <svg class="zui-icon">).
$cev_icon = function ( $name ) {
	$paths = array(
		'mail'         => '<rect x="2" y="4" width="20" height="16" rx="2"></rect><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"></path>',
		'user-plus'    => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><line x1="19" x2="19" y1="8" y2="14"></line><line x1="22" x2="16" y1="11" y2="11"></line>',
		'shopping-cart' => '<circle cx="8" cy="21" r="1"></circle><circle cx="19" cy="21" r="1"></circle><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"></path>',
		'sliders'      => '<line x1="4" x2="4" y1="21" y2="14"></line><line x1="4" x2="4" y1="10" y2="3"></line><line x1="12" x2="12" y1="21" y2="12"></line><line x1="12" x2="12" y1="8" y2="3"></line><line x1="20" x2="20" y1="21" y2="16"></line><line x1="20" x2="20" y1="12" y2="3"></line><line x1="2" x2="6" y1="14" y2="14"></line><line x1="10" x2="14" y1="8" y2="8"></line><line x1="18" x2="22" y1="16" y2="16"></line>',
		'lock'         => '<rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path>',
		'shield'       => '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"></path>',
		'shield-alert' => '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"></path><path d="M12 8v4"></path><path d="M12 16h.01"></path>',
		'sliders-h'    => '<line x1="21" x2="14" y1="4" y2="4"></line><line x1="10" x2="3" y1="4" y2="4"></line><line x1="21" x2="12" y1="12" y2="12"></line><line x1="8" x2="3" y1="12" y2="12"></line><line x1="21" x2="16" y1="20" y2="20"></line><line x1="12" x2="3" y1="20" y2="20"></line><line x1="14" x2="14" y1="2" y2="6"></line><line x1="8" x2="8" y1="10" y2="14"></line><line x1="16" x2="16" y1="18" y2="22"></line>',
		'arrow-right'  => '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
		'x'            => '<line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line>',
	);
	$d = isset( $paths[ $name ] ) ? $paths[ $name ] : '';
	return '<svg class="zui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $d . '</svg>';
};

// Centralised unsafe-echo helper. Every call site routes prebuilt HTML through
// this closure so the EscapeOutput rule fires ONCE here (suppressed below)
// instead of at every $cev_icon() / $cev_2fa_card_html call site — keeps the
// per-line phpcs:ignore noise out of the template.
$cev_print_html = function ( $html ) {
	// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Callers pass SVG built from a static path map ($cev_icon) or HTML from CEV_2FA_Setup::render_settings_section() where every interpolated value is escaped at source; wp_kses_post would strip required data-* / SVG attributes.
	echo $html;
};

// Section registry: key, icon, title, sub. (two_factor is rendered specially.)
$cev_sections = array(
	'signup_verification'   => array( 'user-plus', __( 'Signup Verification', 'customer-email-verification' ), __( 'Configure the form type and rules for new account registrations.', 'customer-email-verification' ) ),
	'checkout_verification' => array( 'shopping-cart', __( 'Checkout Verification', 'customer-email-verification' ), __( 'Configure email verification options applied during checkout.', 'customer-email-verification' ) ),
	'general'            => array( 'sliders', __( 'General', 'customer-email-verification' ), __( 'Verification code, expiry, resend limits, and customer messages.', 'customer-email-verification' ) ),
	'login_auth'         => array( 'lock', __( 'Login Authentication', 'customer-email-verification' ), __( 'Require a one-time code at login for risky sign-ins.', 'customer-email-verification' ) ),
	'two_factor'         => array( 'shield', __( 'Two-Factor Authentication', 'customer-email-verification' ), __( 'Let customers secure their account with an authenticator app.', 'customer-email-verification' ) ),
	'spam_protection'    => array( 'shield-alert', __( 'Spam Protection', 'customer-email-verification' ), __( 'Block disposable emails, bad domains, and known abusers.', 'customer-email-verification' ) ),
	'advanced'           => array( 'sliders-h', __( 'Advanced', 'customer-email-verification' ), __( 'Developer and data-handling options.', 'customer-email-verification' ) ),
);
$cev_default_section = 'signup_verification';

// Persist the active section across reloads: honor a validated ?section=
// query param (written by admin.js when the user switches sections) so a
// refresh keeps the same section instead of snapping back to the first.
// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended
$cev_requested_section = isset( $_GET['section'] ) ? sanitize_key( wp_unslash( $_GET['section'] ) ) : '';
if ( '' !== $cev_requested_section && isset( $cev_sections[ $cev_requested_section ] ) ) {
	$cev_default_section = $cev_requested_section;
}

// Emits a section panel's class + data-zui-section + hidden attributes,
// marking the section that matches $cev_default_section as active so a
// ?section= deep link / refresh restores it.
$cev_section_open = function ( $key ) use ( &$cev_default_section ) {
	$is_active = ( $key === $cev_default_section );
	echo 'class="' . esc_attr( $is_active ? 'zui-section is-active' : 'zui-section' ) . '" data-zui-section="' . esc_attr( $key ) . '"';
	if ( ! $is_active ) {
		echo ' hidden';
	}
};

// Emits a .zui-section-header (icon + title + sub + Save button).
$cev_section_header = function ( $key, $icon, $title, $sub ) use ( $cev_icon, $cev_print_html ) {
	?>
	<div class="zui-section-header">
		<div class="zui-section-header__main">
			<span class="zui-section-header__icon"><?php $cev_print_html( $cev_icon( $icon ) ); ?></span>
			<div class="zui-section-header__text">
				<div class="zui-section-header__titlewrap">
					<h2 class="zui-section-header__title"><?php echo esc_html( $title ); ?></h2>
				</div>
				<p class="zui-section-header__sub"><?php echo esc_html( $sub ); ?></p>
			</div>
		</div>
		<div class="zui-section-header__actions">
			<span class="zui-savebtn-wrap">
				<button type="button" class="zui-savebtn cev_section_save_button" data-cev-section="<?php echo esc_attr( $key ); ?>" data-label-saving="<?php esc_attr_e( 'Saving…', 'customer-email-verification' ); ?>" data-label-saved="<?php esc_attr_e( 'Saved', 'customer-email-verification' ); ?>">
					<span class="zui-savebtn__label"><?php esc_html_e( 'Save changes', 'customer-email-verification' ); ?></span>
					<span class="zui-savebtn__spinner spinner"></span>
				</button>
			</span>
		</div>
	</div>
	<?php
};
?>
<section id="cev_content_settings">
	<form method="post" id="cev_settings_form" action="<?php echo esc_url( $form_action ); ?>" enctype="multipart/form-data">

		<div class="zui-layout">

			<div class="zui-sidebar__overlay" data-zui-drawer-close></div>

			<aside class="zui-sidebar" id="cev-set-sidebar">

				<div class="zui-sidebar__mobile-head">
					<span class="zui-sidebar__mobile-title"><?php esc_html_e( 'CEV Pro Settings', 'customer-email-verification' ); ?></span>
					<button type="button" class="zui-sidebar__close" data-zui-drawer-close aria-label="<?php esc_attr_e( 'Close menu', 'customer-email-verification' ); ?>"><?php $cev_print_html( $cev_icon( 'x' ) ); ?></button>
				</div>

				<nav class="zui-sidebar__nav" aria-label="<?php esc_attr_e( 'Settings sections', 'customer-email-verification' ); ?>">
					<?php foreach ( $cev_sections as $key => $meta ) : ?>
						<button type="button" class="zui-sidebar__item<?php echo ( $cev_default_section === $key ) ? ' is-active' : ''; ?>" data-zui-section="<?php echo esc_attr( $key ); ?>"<?php echo ( $cev_default_section === $key ) ? ' aria-current="true"' : ''; ?>>
							<span class="zui-sidebar__icon"><?php $cev_print_html( $cev_icon( $meta[0] ) ); ?></span>
							<span class="zui-sidebar__label"><?php echo esc_html( $meta[1] ); ?></span>
						</button>
					<?php endforeach; ?>
				</nav>

				<div class="zui-quickhelp">
					<h4 class="zui-quickhelp__title"><?php esc_html_e( 'Quick Help', 'customer-email-verification' ); ?></h4>
					<p class="zui-quickhelp__text"><?php esc_html_e( 'Learn how to configure CEV Pro for best results.', 'customer-email-verification' ); ?></p>
					<div class="zui-quickhelp__links">
						<a class="zui-quickhelp__link" href="https://www.zorem.com/docs/" target="_blank" rel="noreferrer noopener">
							<span><?php esc_html_e( 'View Documentation', 'customer-email-verification' ); ?></span>
							<?php $cev_print_html( $cev_icon( 'arrow-right' ) ); ?>
						</a>
						<a class="zui-quickhelp__link zui-quickhelp__link--muted" href="https://www.zorem.com/support/" target="_blank" rel="noreferrer noopener">
							<span><?php esc_html_e( 'Get Support', 'customer-email-verification' ); ?></span>
							<?php $cev_print_html( $cev_icon( 'arrow-right' ) ); ?>
						</a>
					</div>
					<div class="zui-quickhelp__art" aria-hidden="true">
						<span class="zui-quickhelp__glow"></span>
						<span class="zui-quickhelp__sphere"></span>
						<span class="zui-quickhelp__paper zui-quickhelp__paper--1">
							<span class="zui-quickhelp__line zui-quickhelp__line--brand"></span>
							<span class="zui-quickhelp__line zui-quickhelp__line--mid"></span>
							<span class="zui-quickhelp__line zui-quickhelp__line--short"></span>
						</span>
						<span class="zui-quickhelp__paper zui-quickhelp__paper--2">
							<span class="zui-quickhelp__line zui-quickhelp__line--accent"></span>
							<span class="zui-quickhelp__line zui-quickhelp__line--mid"></span>
							<span class="zui-quickhelp__line zui-quickhelp__line--mid"></span>
							<span class="zui-quickhelp__line zui-quickhelp__line--short"></span>
						</span>
						<span class="zui-quickhelp__check">&#10003;</span>
					</div>
				</div>

				<?php if ( class_exists( 'CEV_Pro_Admin_Notice' ) ) : ?>
					<div class="zui-quickhelp cev-review-card">
						<h4 class="zui-quickhelp__title"><?php esc_html_e( 'Enjoying CEV?', 'customer-email-verification' ); ?></h4>
						<div class="cev-review-card__stars" aria-hidden="true">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
						<p class="zui-quickhelp__text"><?php esc_html_e( 'If CEV keeps spam signups and fake orders away from your store, please leave us a quick review. It really helps!', 'customer-email-verification' ); ?></p>
						<a class="zui-btn-primary cev-review-card__btn" href="<?php echo esc_url( CEV_Pro_Admin_Notice::REVIEW_URL ); ?>" target="_blank" rel="noreferrer noopener">
							<?php esc_html_e( 'Leave a review', 'customer-email-verification' ); ?>
						</a>
					</div>
				<?php endif; ?>

			</aside>

			<main class="zui-content" id="cev-set-content">

				<?php
				if ( class_exists( 'CEV_Pro_Setup_Checklist' ) ) {
					CEV_Pro_Setup_Checklist::get_instance()->render();
				}
				?>

				<?php $cev_section_meta = $cev_sections['signup_verification']; ?>
				<section <?php $cev_section_open( 'signup_verification' ); ?>>
					<?php $cev_section_header( 'signup_verification', $cev_section_meta[0], $cev_section_meta[1], $cev_section_meta[2] ); ?>
					<div class="panel" data-cev-section="signup_verification">
						<?php $this->render_settings_fields( $this->get_cev_signup_verification_settings_data() ); ?>
					</div>
				</section>

				<?php $cev_section_meta = $cev_sections['checkout_verification']; ?>
				<section <?php $cev_section_open( 'checkout_verification' ); ?>>
					<?php $cev_section_header( 'checkout_verification', $cev_section_meta[0], $cev_section_meta[1], $cev_section_meta[2] ); ?>
					<div class="panel" data-cev-section="checkout_verification">
						<?php $this->render_settings_fields( $this->get_cev_checkout_verification_settings_data() ); ?>
					</div>
				</section>

				<?php $cev_section_meta = $cev_sections['general']; ?>
				<section <?php $cev_section_open( 'general' ); ?>>
					<?php $cev_section_header( 'general', $cev_section_meta[0], $cev_section_meta[1], $cev_section_meta[2] ); ?>
					<div class="panel" data-cev-section="general">
						<?php $this->render_settings_fields( $this->get_cev_general_settings_data() ); ?>
					</div>
				</section>

				<?php $cev_section_meta = $cev_sections['login_auth']; ?>
				<section <?php $cev_section_open( 'login_auth' ); ?>>
					<?php $cev_section_header( 'login_auth', $cev_section_meta[0], $cev_section_meta[1], $cev_section_meta[2] ); ?>
					<div class="panel" data-cev-section="login_auth">
						<?php $this->render_settings_fields( $this->get_cev_settings_data_login_otp() ); ?>
					</div>
				</section>

				<?php $cev_section_meta = $cev_sections['two_factor']; ?>
				<section <?php $cev_section_open( 'two_factor' ); ?>>
					<?php $cev_section_header( 'two_factor', $cev_section_meta[0], $cev_section_meta[1], $cev_section_meta[2] ); ?>
					<div class="panel" data-cev-section="two_factor">
						<?php
						$this->render_settings_fields( $this->get_cev_2fa_settings_data() );

						// Current admin's own enrolment card (rendered below the policy fields).
						if ( class_exists( 'CEV_2FA_Setup' ) ) {
							ob_start();
							CEV_2FA_Setup::instance()->render_settings_section();
							$cev_2fa_card_html = trim( (string) ob_get_clean() );
							if ( '' !== $cev_2fa_card_html ) {
								$cev_2fa_toggle_on = 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'cev_enable_2fa', 0 );
								echo '<div class="cev-2fa-settings-embed"' . ( $cev_2fa_toggle_on ? '' : ' style="display:none"' ) . '>';
								$cev_print_html( $cev_2fa_card_html );
								echo '</div>';
							}
						}
						?>
					</div>
				</section>

				<?php $cev_section_meta = $cev_sections['spam_protection']; ?>
				<section <?php $cev_section_open( 'spam_protection' ); ?>>
					<?php $cev_section_header( 'spam_protection', $cev_section_meta[0], $cev_section_meta[1], $cev_section_meta[2] ); ?>
					<div class="panel" data-cev-section="spam_protection">
						<?php $this->render_settings_fields( $this->get_cev_spam_protection_settings_data() ); ?>
					</div>
				</section>

				<?php $cev_section_meta = $cev_sections['advanced']; ?>
				<section <?php $cev_section_open( 'advanced' ); ?>>
					<?php $cev_section_header( 'advanced', $cev_section_meta[0], $cev_section_meta[1], $cev_section_meta[2] ); ?>
					<div class="panel" data-cev-section="advanced">
						<?php $this->render_settings_fields( $this->get_cev_advanced_settings_data() ); ?>
					</div>
				</section>

			</main>

		</div>

		<?php wp_nonce_field( 'cev_settings_form_nonce', 'cev_settings_form_nonce' ); ?>
		<input type="hidden" name="action" value="cev_settings_form_update">
	</form>
</section>
