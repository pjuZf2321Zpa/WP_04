<?php
/**
 * Menu Tabs Template (ZUI)
 *
 * Renders the top tab strip as ZUI tab items. Top tabs are real links that
 * reload with ?tab=<slug> — this keeps deep-linking, browser back/forward,
 * and the license redirect working server-side. (In-page switching is only
 * used for the Settings sidebar sections, via data-zui-section.)
 *
 * Expected in scope:
 *   $current_tab  string  Current tab slug.
 *   $tabs         array   Tab configuration from get_cev_tab_settings_data().
 *
 * @package Customer_Email_Verification_Pro
 * @since 2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

if ( ! isset( $current_tab ) || ! isset( $tabs ) ) {
	return;
}

// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Read-only admin-page tab selector; no state change.
$cev_page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : 'customer-email-verification-for-woocommerce';

foreach ( (array) $tabs as $tab_id => $tab_data ) {

	// External link tab (e.g. Customize → email customizer).
	if ( isset( $tab_data['type'] ) && 'link' === $tab_data['type'] ) {
		?>
		<a class="zui-tabs__item" href="<?php echo esc_url( $tab_data['link'] ); ?>">
			<?php echo esc_html( $tab_data['title'] ); ?>
		</a>
		<?php
		continue;
	}

	// Standard tab → reload link with ?tab=<slug>.
	$tab_slug  = isset( $tab_data['data-tab'] ) ? $tab_data['data-tab'] : '';
	$is_active = ( $current_tab === $tab_slug );
	$tab_url   = admin_url( 'admin.php?page=' . $cev_page . '&tab=' . $tab_slug );
	?>
	<a
		class="zui-tabs__item<?php echo $is_active ? ' is-active' : ''; ?>"
		href="<?php echo esc_url( $tab_url ); ?>"
		data-cev-tab="<?php echo esc_attr( $tab_slug ); ?>"
		<?php echo $is_active ? 'aria-current="page"' : ''; ?>
	>
		<?php echo esc_html( $tab_data['title'] ); ?>
	</a>
	<?php
}
