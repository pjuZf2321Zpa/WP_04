<?php
/**
 * Bulk Action Notices Template
 *
 * @package Customer_Email_Verification
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

// Handle notice for verified users.
if ( ! empty( $_REQUEST['verify_users_emails'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Read-only count shown after WP's own bulk-action nonce flow.
	// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Read-only count shown after WP's own bulk-action nonce flow.
	$verify_users_emails = absint( wp_unslash( $_REQUEST['verify_users_emails'] ) );
	?>
	<div id="message" class="updated notice is-dismissible">
		<p>
			<?php
			echo esc_html(
				sprintf(
					/* translators: %s: Number of users whose verification status was updated */
					_n(
						'Verification status updated for %s user.',
						'Verification status updated for %s users.',
						$verify_users_emails,
						'customer-email-verification'
					),
					$verify_users_emails
				)
			);
			?>
		</p>
	</div>
	<?php
}

// Handle notice for force-activated users (Paid-Order Gatekeeping override).
if ( ! empty( $_REQUEST['cev_force_activated'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Read-only count shown after WP's own bulk-action nonce flow.
	// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Read-only count shown after WP's own bulk-action nonce flow.
	$cev_force_activated = absint( wp_unslash( $_REQUEST['cev_force_activated'] ) );
	?>
	<div id="message" class="updated notice is-dismissible">
		<p>
			<?php
			echo esc_html(
				sprintf(
					/* translators: %s: Number of users force-activated, skipping the paid-order requirement */
					_n(
						'Force-activated %s user (paid-order requirement skipped).',
						'Force-activated %s users (paid-order requirement skipped).',
						$cev_force_activated,
						'customer-email-verification'
					),
					$cev_force_activated
				)
			);
			?>
		</p>
	</div>
	<?php
}

// Handle notice for force re-verified users (retroactive re-verify tool).
if ( ! empty( $_REQUEST['cev_force_reverified'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Read-only count shown after WP's own bulk-action nonce flow.
	// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Read-only count shown after WP's own bulk-action nonce flow.
	$cev_force_reverified = absint( wp_unslash( $_REQUEST['cev_force_reverified'] ) );
	?>
	<div id="message" class="updated notice is-dismissible">
		<p>
			<?php
			echo esc_html(
				sprintf(
					/* translators: %s: Number of users marked unverified */
					_n(
						'%s user marked unverified — they must re-verify on next login.',
						'%s users marked unverified — they must re-verify on next login.',
						$cev_force_reverified,
						'customer-email-verification'
					),
					$cev_force_reverified
				)
			);
			?>
		</p>
	</div>
	<?php
}
