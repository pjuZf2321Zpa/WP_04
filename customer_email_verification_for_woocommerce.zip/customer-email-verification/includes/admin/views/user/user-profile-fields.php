<?php
/**
 * User Profile Fields Template
 *
 * @package Customer_Email_Verification
 * @since 1.0.0
 *
 * Expected variables, supplied by the including scope:
 *
 * @var WP_User $user                  The user whose profile is being rendered.
 * @var bool    $is_admin_user         Whether the profile user is a back-office account.
 * @var string  $verification_meta_key Meta key holding the verification state.
 * @var string  $nonce_action_email    Nonce action for the resend-email link.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

$user_id  = absint( $user->ID );
$verified = get_user_meta( $user_id, $verification_meta_key, true );

// Manual verify/unverify is a store-admin action. A user viewing their own
// profile sees their status only — never the action buttons or the nonce.
$can_manage_verification = current_user_can( 'manage_woocommerce' );
$nonce                   = $can_manage_verification ? wp_create_nonce( $nonce_action_email ) : '';

// Skip admin users.
$can_verify = ! $is_admin_user;
// Treat the gatekeeping `pending_paid_order` state as verified — the user's
// email is already verified, so show the verified icon + "Un-verify email"
// action rather than the manual-verify button.
$is_verified = ( 'true' === $verified || 'pending_paid_order' === $verified );
?>
<table class="form-table cev-admin-menu">
	<tr>
		<th colspan="2">
			<h4 class="cev_admin_user">
				<?php esc_html_e( 'Customer verification', 'customer-email-verification' ); ?>
			</h4>
		</th>
	</tr>
	<tr>
		<th class="cev-admin-padding">
			<label><?php esc_html_e( 'Email verification status:', 'customer-email-verification' ); ?></label>
		</th>
		<td>
			<?php if ( $can_verify ) : ?>
				<?php
				$verified_icon_css   = $is_verified ? '' : 'display:none';
				$unverified_icon_css = $is_verified ? 'display:none' : '';
				?>
				<span style="<?php echo esc_attr( $verified_icon_css ); ?>" 
					  class="dashicons dashicons-yes cev_5 cev_verified_admin_user_action_single" 
					  title="<?php esc_attr_e( 'Verified', 'customer-email-verification' ); ?>">
				</span>
				<span style="<?php echo esc_attr( $unverified_icon_css ); ?>" 
					  class="dashicons dashicons-no no-border cev_unverified_admin_user_action_single cev_5" 
					  title="<?php esc_attr_e( 'Unverify', 'customer-email-verification' ); ?>">
				</span>
			<?php else : ?>
				<?php esc_html_e( 'Admin', 'customer-email-verification' ); ?>
			<?php endif; ?>
		</td>
	</tr>
	<?php
	// Action-buttons row — only render it when there's actually something
	// to render. For admin users `$can_verify` is false → the row would
	// be empty but still painted by the form-table CSS, creating a stray
	// horizontal band of borders between the email-status row and the
	// 2FA section below. Skipping the <tr> entirely fixes that.
	?>
	<?php if ( $can_verify && $can_manage_verification ) : ?>
		<tr>
			<td colspan="2">
				<?php
				$verify_btn_css   = $is_verified ? 'display:none' : '';
				$unverify_btn_css = $is_verified ? '' : 'display:none';
				?>
				<a style="<?php echo esc_attr( $verify_btn_css ); ?>"
				   class="button-primary cev-admin-verify-button cev_dashicons_icon_verify_user"
				   id="<?php echo esc_attr( $user_id ); ?>"
				   wp_nonce="<?php echo esc_attr( $nonce ); ?>">
					<span class="dashicons dashicons-yes cev-admin-dashicons" style="color:#ffffff; margin-right: 2px;"></span>
					<span><?php esc_html_e( 'Verify email manually', 'customer-email-verification' ); ?></span>
				</a>
				<a style="<?php echo esc_attr( $unverify_btn_css ); ?>"
				   class="button-primary cev-admin-unverify-button cev_dashicons_icon_unverify_user"
				   id="<?php echo esc_attr( $user_id ); ?>"
				   wp_nonce="<?php echo esc_attr( $nonce ); ?>">
					<span class="dashicons dashicons-no cev-admin-dashicons"></span>
					<span><?php esc_html_e( 'Un-verify email', 'customer-email-verification' ); ?></span>
				</a>
			</td>
		</tr>
	<?php endif; ?>

	<?php
	// 2FA section is no longer rendered INSIDE this table — it lives in
	// its own card below (see CEV_2FA_Setup::render_user_profile()). That
	// avoids the "two borders" nesting and lets the 2FA card stand on
	// its own.
	?>
</table>
