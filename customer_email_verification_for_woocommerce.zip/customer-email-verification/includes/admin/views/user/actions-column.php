<?php
/**
 * Actions Column Template
 *
 * @package Customer_Email_Verification
 * @since 1.0.0
 *
 * Expected variables, supplied by the including scope:
 *
 * @var int    $user_id            The user the row belongs to.
 * @var string $verified           Current customer_email_verified meta value.
 * @var bool   $is_admin_user      Whether the row user is a back-office account.
 * @var string $nonce_action_email Nonce action for the resend-email link.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

// Skip admin users.
if ( $is_admin_user ) {
	return;
}

// Treat the gatekeeping `pending_paid_order` state as verified — the user
// has already verified their email, so the available action is to unverify
// (✗), not to verify (✓). The orange clock status still flags the pending
// order in the verification-status column.
$is_verified         = ( 'true' === $verified || 'pending_paid_order' === $verified );
$verify_btn_css      = $is_verified ? 'display:none' : '';
$unverify_btn_css    = $is_verified ? '' : 'display:none';
$nonce               = wp_create_nonce( $nonce_action_email );
?>
<span style="<?php echo esc_attr( $unverify_btn_css ); ?>" class="dashicons dashicons-no cev_dashicons_icon_unverify_user" id="<?php echo esc_attr( $user_id ); ?>" wp_nonce="<?php echo esc_attr( $nonce ); ?>"></span>
<span style="<?php echo esc_attr( $verify_btn_css ); ?>" class="dashicons dashicons-yes small-yes cev_dashicons_icon_verify_user cev_10" id="<?php echo esc_attr( $user_id ); ?>" wp_nonce="<?php echo esc_attr( $nonce ); ?>"></span>
