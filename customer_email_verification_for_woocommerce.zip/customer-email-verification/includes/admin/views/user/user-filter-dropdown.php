<?php
/**
 * User Filter Dropdown Template
 *
 * @package Customer_Email_Verification
 * @since 1.0.0
 *
 * Expected variables, supplied by the including scope:
 *
 * @var string $which Which table nav the dropdown is rendered into (top/bottom).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

if ( 'top' !== $which ) {
	return;
}

// Get selected filter value.
// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Read-only Users-list filter (mirrors WP core list-table filters); no state change.
$top_filter    = isset( $_GET['customer_email_verified_top'] ) ? sanitize_text_field( wp_unslash( $_GET['customer_email_verified_top'] ) ) : '';
// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Read-only Users-list filter (mirrors WP core list-table filters); no state change.
$bottom_filter = isset( $_GET['customer_email_verified_bottom'] ) ? sanitize_text_field( wp_unslash( $_GET['customer_email_verified_bottom'] ) ) : '';
$selected_value = ! empty( $top_filter ) ? $top_filter : $bottom_filter;

// Determine selected options.
$true_selected    = ( 'true' === $selected_value ) ? 'selected' : '';
$false_selected   = ( 'false' === $selected_value ) ? 'selected' : '';
$pending_selected = ( 'pending_paid_order' === $selected_value ) ? 'selected' : '';
?>
<select name="customer_email_verified_<?php echo esc_attr( $which ); ?>" style="float:none; margin-left:10px;">
	<option value=""><?php esc_html_e( 'User verification', 'customer-email-verification' ); ?></option>
	<option value="true" <?php echo esc_attr( $true_selected ); ?>>
		<?php esc_html_e( 'Verified', 'customer-email-verification' ); ?>
	</option>
	<option value="pending_paid_order" <?php echo esc_attr( $pending_selected ); ?>>
		<?php esc_html_e( 'Pending Order', 'customer-email-verification' ); ?>
	</option>
	<option value="false" <?php echo esc_attr( $false_selected ); ?>>
		<?php esc_html_e( 'Non verified', 'customer-email-verification' ); ?>
	</option>
</select>
<?php
submit_button( __( 'Filter', 'customer-email-verification' ), '', $which, false );

