<?php
/**
 * Admin Notice Template
 *
 * @package Customer_Email_Verification
 * @since 1.0.0
 *
 * Expected variables, supplied by the including scope:
 *
 * @var string $message Already-escaped notice text to render.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<div class="updated notice">
	<p><?php echo esc_html( $message ); ?></p>
</div>

