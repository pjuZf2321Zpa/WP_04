<?php
/**
 * Verification Status Column Template
 *
 * @package Customer_Email_Verification
 * @since 1.0.0
 *
 * Expected variables, supplied by the including scope:
 *
 * @var string $verified      Current customer_email_verified meta value.
 * @var bool   $is_admin_user Whether the row user is a back-office account.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

// Skip admin users.
if ( $is_admin_user ) {
	echo '-';
	return;
}

// Paid-Order Gatekeeping: a user who has verified their email but not yet
// completed a paid order sits in the `pending_paid_order` state. Show a
// distinct yellow badge for it instead of the verified/unverified icons.
if ( 'pending_paid_order' === $verified ) {
	$pending_tip = __( 'Pending Order — email verified, awaiting first paid order', 'customer-email-verification' );
	?>
	<span class="cev-pending-tip" tabindex="0" data-cev-tip="<?php echo esc_attr( $pending_tip ); ?>" aria-label="<?php echo esc_attr( $pending_tip ); ?>">
		<span class="dashicons dashicons-clock cev_5" style="color:#d97706;" aria-hidden="true"></span>
	</span>
	<?php
	return;
}

$is_verified           = ( 'true' === $verified );
$verified_icon_css     = $is_verified ? '' : 'display:none';
$unverified_icon_css   = $is_verified ? 'display:none' : '';
?>
<span style="<?php echo esc_attr( $verified_icon_css ); ?>" class="dashicons dashicons-yes cev_5 cev_verified_admin_user_action" title="<?php esc_attr_e( 'Verified', 'customer-email-verification' ); ?>"></span>
<span style="<?php echo esc_attr( $unverified_icon_css ); ?>" class="dashicons dashicons-no no-border cev_unverified_admin_user_action cev_5" title="<?php esc_attr_e( 'Unverify', 'customer-email-verification' ); ?>"></span>
