<?php
/**
 * Unverified Users Tab Template (ZUI)
 *
 * ZUI layout (sidebar: User List / Maintenance) + content. The User List
 * section holds the bulk toolbar + the DataTables-enhanced verification log;
 * the Maintenance section includes cev_maintenance_tab.php.
 *
 * All JS hooks are preserved: #userLogTable, #select_all, .row_checkbox,
 * #bulk_action, .apply_bulk_action, .cev_export_unverified_csv, the per-row
 * .cev_send_reminder_button / .delete_button (+ nonces).
 *
 * @package Customer_Email_Verification
 * @since 2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

global $wpdb;

$plugin_instance = cev_pro();
$plugin_url      = $plugin_instance->plugin_dir_url();
$plugin_version  = isset( $plugin_instance->version ) ? $plugin_instance->version : '1.0.0';

// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQLPlaceholders.UnquotedComplexPlaceholder,WordPress.DB.DirectDatabaseQuery.NoCaching
$results = $wpdb->get_results(
	"SELECT id, email, verified, last_updated
	 FROM {$wpdb->prefix}cev_user_log
	 ORDER BY last_updated DESC",
	ARRAY_A
);
// phpcs:enable

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Re-assert: the bare phpcs:enable above re-enables ALL rules, which would otherwise cancel the file-level disable at the top of this template.

$cev_stats = array(
	'pending'                 => 0,
	'verified'                => 0,
	'total'                   => 0,
	'oldest_pending_age_days' => 0,
	'last_cleanup_at'         => '',
	'last_cleanup_count'      => 0,
);
if ( class_exists( 'CEV_Pro_Maintenance' ) ) {
	$cev_stats = CEV_Pro_Maintenance::get_instance()->get_stats();
}

// Inline Lucide-style icon helper.
$cev_icon = function ( $name ) {
	$stroke = array(
		'users'       => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M22 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path>',
		'wrench'      => '<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path>',
		'user-x'      => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><line x1="17" y1="8" x2="22" y2="13"></line><line x1="22" y1="8" x2="17" y2="13"></line>',
		'download'    => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line>',
		'mail'        => '<rect x="2" y="4" width="20" height="16" rx="2"></rect><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"></path>',
		'trash'       => '<polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>',
		'arrow-right' => '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
		'x'           => '<line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line>',
	);
	$d = isset( $stroke[ $name ] ) ? $stroke[ $name ] : '';
	return '<svg class="zui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $d . '</svg>';
};

/**
 * Echoes already-safe HTML (built from constant string maps, no user input).
 * One centralised phpcs:ignore so callsites stay free of trailing same-line
 * suppression comments — those are unreliable on the audit server's PHPCS
 * for the EscapeOutput sniff.
 */
$cev_print_html = function ( $html ) {
	// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Callers pass SVG / HTML built from constant maps with no user input; wp_kses_post would strip required SVG attributes.
	echo $html;
};
?>
<section id="cev_content_user">
	<div class="zui-layout">

		<div class="zui-sidebar__overlay" data-zui-drawer-close></div>

		<aside class="zui-sidebar">
			<div class="zui-sidebar__mobile-head">
				<span class="zui-sidebar__mobile-title"><?php esc_html_e( 'Unverified Users', 'customer-email-verification' ); ?></span>
				<button type="button" class="zui-sidebar__close" data-zui-drawer-close aria-label="<?php esc_attr_e( 'Close menu', 'customer-email-verification' ); ?>"><?php $cev_print_html( $cev_icon( 'x' ) ); ?></button>
			</div>
			<nav class="zui-sidebar__nav" aria-label="<?php esc_attr_e( 'Unverified Users sections', 'customer-email-verification' ); ?>">
				<button type="button" class="zui-sidebar__item is-active" data-zui-section="user-list" aria-current="true">
					<span class="zui-sidebar__icon"><?php $cev_print_html( $cev_icon( 'users' ) ); ?></span>
					<span class="zui-sidebar__label"><?php esc_html_e( 'User List', 'customer-email-verification' ); ?></span>
				</button>
				<button type="button" class="zui-sidebar__item" data-zui-section="maintenance">
					<span class="zui-sidebar__icon"><?php $cev_print_html( $cev_icon( 'wrench' ) ); ?></span>
					<span class="zui-sidebar__label"><?php esc_html_e( 'Maintenance', 'customer-email-verification' ); ?></span>
				</button>
			</nav>

			<div class="zui-quickhelp">
				<h4 class="zui-quickhelp__title"><?php esc_html_e( 'Quick Help', 'customer-email-verification' ); ?></h4>
				<p class="zui-quickhelp__text"><?php esc_html_e( 'Learn how to configure CEV Pro for best results.', 'customer-email-verification' ); ?></p>
				<div class="zui-quickhelp__links">
					<a class="zui-quickhelp__link" href="https://www.zorem.com/docs/" target="_blank" rel="noreferrer noopener">
						<span><?php esc_html_e( 'View Documentation', 'customer-email-verification' ); ?></span>
						<?php $cev_print_html( $cev_icon( 'arrow-right' ) ); ?>
					</a>
					<a class="zui-quickhelp__link zui-quickhelp__link--muted" href="https://www.zorem.com/support/" target="_blank" rel="noreferrer noopener">
						<span><?php esc_html_e( 'Get Support', 'customer-email-verification' ); ?></span>
						<?php $cev_print_html( $cev_icon( 'arrow-right' ) ); ?>
					</a>
				</div>
				<div class="zui-quickhelp__art" aria-hidden="true">
					<span class="zui-quickhelp__glow"></span>
					<span class="zui-quickhelp__sphere"></span>
					<span class="zui-quickhelp__paper zui-quickhelp__paper--1">
						<span class="zui-quickhelp__line zui-quickhelp__line--brand"></span>
						<span class="zui-quickhelp__line zui-quickhelp__line--mid"></span>
						<span class="zui-quickhelp__line zui-quickhelp__line--short"></span>
					</span>
					<span class="zui-quickhelp__paper zui-quickhelp__paper--2">
						<span class="zui-quickhelp__line zui-quickhelp__line--accent"></span>
						<span class="zui-quickhelp__line zui-quickhelp__line--mid"></span>
						<span class="zui-quickhelp__line zui-quickhelp__line--mid"></span>
						<span class="zui-quickhelp__line zui-quickhelp__line--short"></span>
					</span>
					<span class="zui-quickhelp__check">&#10003;</span>
				</div>
			</div>
		</aside>

		<main class="zui-content">

			<!-- ── Section: User List ─────────────────────────── -->
			<section class="zui-section is-active" data-zui-section="user-list">

				<div class="zui-section-header">
					<div class="zui-section-header__main">
						<span class="zui-section-header__icon"><?php $cev_print_html( $cev_icon( 'user-x' ) ); ?></span>
						<div class="zui-section-header__text">
							<div class="zui-section-header__titlewrap">
								<h2 class="zui-section-header__title"><?php esc_html_e( 'Unverified Users', 'customer-email-verification' ); ?></h2>
							</div>
							<p class="zui-section-header__sub"><?php esc_html_e( 'Customers who started signing up but never verified their email address.', 'customer-email-verification' ); ?></p>
						</div>
					</div>
				</div>

				<p class="zui-row__desc">
					<strong><?php echo esc_html( number_format_i18n( $cev_stats['pending'] ) ); ?></strong>
					<?php esc_html_e( 'pending verifications', 'customer-email-verification' ); ?>
					<?php if ( $cev_stats['oldest_pending_age_days'] > 0 ) : ?>
						&nbsp;|&nbsp;
						<?php
						printf(
							/* translators: %d: number of days */
							esc_html( _n( 'oldest pending: %d day', 'oldest pending: %d days', $cev_stats['oldest_pending_age_days'], 'customer-email-verification' ) ),
							(int) $cev_stats['oldest_pending_age_days']
						);
						?>
					<?php endif; ?>
				</p>

				<?php if ( ! empty( $results ) ) : ?>
					<div class="zui-card">

						<div class="zui-bulkbar" role="toolbar" aria-label="<?php esc_attr_e( 'Bulk actions', 'customer-email-verification' ); ?>">
							<div class="zui-bulkbar__group">
								<label for="bulk_action" class="screen-reader-text"><?php esc_html_e( 'Select bulk action', 'customer-email-verification' ); ?></label>
								<div class="zui-select-wrap">
									<select id="bulk_action" name="bulk_action" class="zui-select" aria-label="<?php esc_attr_e( 'Bulk action', 'customer-email-verification' ); ?>">
										<option value=""><?php esc_html_e( 'Bulk Action', 'customer-email-verification' ); ?></option>
										<option value="delete"><?php esc_html_e( 'Delete', 'customer-email-verification' ); ?></option>
										<option value="send_reminder"><?php esc_html_e( 'Send re-engagement reminder', 'customer-email-verification' ); ?></option>
									</select>
									<span class="zui-select-chevron"><svg class="zui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"></polyline></svg></span>
								</div>
								<button type="button" class="zui-btn-soft apply_bulk_action" data-send-reminder-nonce="<?php echo esc_attr( wp_create_nonce( 'cev_reengagement_send_bulk_nonce' ) ); ?>"><?php esc_html_e( 'Apply', 'customer-email-verification' ); ?></button>
							</div>
							<div class="zui-bulkbar__group">
								<button type="button" class="zui-btn-soft cev_export_unverified_csv" data-nonce="<?php echo esc_attr( wp_create_nonce( 'cev_export_unverified_nonce' ) ); ?>">
									<?php $cev_print_html( $cev_icon( 'download' ) ); ?>
									<?php esc_html_e( 'Export CSV', 'customer-email-verification' ); ?>
								</button>
							</div>
						</div>

						<table id="userLogTable" class="zui-table" role="table" aria-label="<?php esc_attr_e( 'User log entries', 'customer-email-verification' ); ?>">
							<thead>
								<tr role="row">
									<th scope="col">
										<label class="zui-checkbox">
											<input type="checkbox" id="select_all" class="zui-checkbox__input" aria-label="<?php esc_attr_e( 'Select all entries', 'customer-email-verification' ); ?>" />
											<span class="zui-checkbox__box"></span>
										</label>
									</th>
									<th scope="col"><?php esc_html_e( 'Customer', 'customer-email-verification' ); ?></th>
									<th scope="col"><?php esc_html_e( 'Last Updated', 'customer-email-verification' ); ?></th>
									<th scope="col"><?php esc_html_e( 'Risk', 'customer-email-verification' ); ?></th>
									<th scope="col"><span class="screen-reader-text"><?php esc_html_e( 'Actions', 'customer-email-verification' ); ?></span></th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ( $results as $row ) : ?>
									<?php
									$entry_id     = isset( $row['id'] ) ? absint( $row['id'] ) : 0;
									$entry_email  = isset( $row['email'] ) ? sanitize_email( $row['email'] ) : '';
									$last_updated = isset( $row['last_updated'] ) ? $row['last_updated'] : '';

									$email_local = $entry_email;
									if ( $entry_email && false !== strpos( $entry_email, '@' ) ) {
										$email_local = strstr( $entry_email, '@', true );
									}
									$display_name = $email_local ? trim( ucwords( str_replace( array( '.', '_', '-' ), ' ', $email_local ) ) ) : $entry_email;
									$initials     = '';
									foreach ( explode( ' ', (string) $display_name ) as $word ) {
										if ( '' !== $word ) {
											$initials .= mb_substr( $word, 0, 1 );
										}
										if ( mb_strlen( $initials ) >= 2 ) {
											break;
										}
									}
									$initials = strtoupper( '' !== $initials ? $initials : '?' );

									$palette      = array( '#2563eb', '#7c3aed', '#0891b2', '#059669', '#d97706', '#db2777', '#475569', '#0ea5e9' );
									$avatar_color = $palette[ ( $entry_email ? abs( crc32( strtolower( $entry_email ) ) ) : 0 ) % count( $palette ) ];

									$absolute_date = __( 'N/A', 'customer-email-verification' );
									$relative_date = '';
									if ( ! empty( $last_updated ) ) {
										$ts = strtotime( $last_updated );
										if ( $ts ) {
											$absolute_date = wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $ts );
											/* translators: %s: human-readable time difference (e.g. "3 hours") */
											$relative_date = sprintf( __( '%s ago', 'customer-email-verification' ), human_time_diff( $ts, current_time( 'timestamp' ) ) );
										} else {
											$absolute_date = $last_updated;
										}
									}

									// AI risk chip (from the stored assessment, if any).
									$cev_risk          = class_exists( 'CEV_Signup_Risk' ) ? CEV_Signup_Risk::get_stored_risk( $entry_email ) : null;
									$cev_risk_score    = ( is_array( $cev_risk ) && isset( $cev_risk['score'] ) ) ? (int) $cev_risk['score'] : null;
									$cev_risk_action   = ( is_array( $cev_risk ) && isset( $cev_risk['action'] ) ) ? (string) $cev_risk['action'] : '';
									$cev_reason_labels = array(
										'gibberish_local'   => __( 'Random-looking mailbox', 'customer-email-verification' ),
										'suspicious_domain' => __( 'Unusual domain', 'customer-email-verification' ),
										'address_shape'     => __( 'Role / plus address', 'customer-email-verification' ),
										'signup_velocity'   => __( 'Many signups from one IP', 'customer-email-verification' ),
									);
									$cev_reasons_text = '';
									if ( is_array( $cev_risk ) && ! empty( $cev_risk['reasons'] ) ) {
										$cev_parts = array();
										foreach ( (array) $cev_risk['reasons'] as $cev_reason_key ) {
											$cev_parts[] = isset( $cev_reason_labels[ $cev_reason_key ] ) ? $cev_reason_labels[ $cev_reason_key ] : $cev_reason_key;
										}
										$cev_reasons_text = implode( ', ', $cev_parts );
									}
									$cev_risk_class = 'cev-risk-chip--none';
									if ( null !== $cev_risk_score ) {
										if ( 'block' === $cev_risk_action ) {
											$cev_risk_class = 'cev-risk-chip--high';
										} elseif ( 'otp' === $cev_risk_action ) {
											$cev_risk_class = 'cev-risk-chip--medium';
										} else {
											$cev_risk_class = 'cev-risk-chip--low';
										}
									}
									?>
									<tr role="row">
										<td role="gridcell">
											<label class="zui-checkbox">
												<input type="checkbox" class="row_checkbox zui-checkbox__input" id="row_checkbox_<?php echo esc_attr( $entry_id ); ?>" value="<?php echo esc_attr( $entry_id ); ?>" aria-label="<?php esc_attr_e( 'Select this entry', 'customer-email-verification' ); ?>" />
												<span class="zui-checkbox__box"></span>
											</label>
										</td>
										<td role="gridcell">
											<div class="zui-cell-user">
												<span class="zui-avatar" aria-hidden="true" style="--zui-c: <?php echo esc_attr( $avatar_color ); ?>; --zui-c-fg: #fff;"><?php echo esc_html( $initials ); ?></span>
												<div class="zui-cell-user__meta">
													<strong><?php echo esc_html( $display_name ); ?></strong>
													<small><?php echo esc_html( $entry_email ); ?></small>
												</div>
											</div>
										</td>
										<td role="gridcell" title="<?php echo esc_attr( $absolute_date ); ?>">
											<?php if ( $relative_date ) : ?>
												<strong><?php echo esc_html( $relative_date ); ?></strong>
												<small><?php echo esc_html( $absolute_date ); ?></small>
											<?php else : ?>
												<strong><?php echo esc_html( $absolute_date ); ?></strong>
											<?php endif; ?>
										</td>
										<td role="gridcell">
											<?php if ( null !== $cev_risk_score ) : ?>
												<span class="cev-risk-chip <?php echo esc_attr( $cev_risk_class ); ?>" title="<?php echo esc_attr( $cev_reasons_text ); ?>"><?php echo esc_html( (string) $cev_risk_score ); ?></span>
											<?php else : ?>
												<span class="cev-risk-chip cev-risk-chip--none" aria-hidden="true">—</span>
											<?php endif; ?>
										</td>
										<td role="gridcell" style="text-align:right;">
											<div class="zui-actions">
												<button type="button" class="zui-actions-toggle" aria-haspopup="menu" aria-expanded="false" aria-label="<?php /* translators: %s: Email address */ printf( esc_attr__( 'Open actions menu for %s', 'customer-email-verification' ), esc_attr( $entry_email ) ); ?>">
													<svg class="zui-icon" viewBox="0 0 24 24" fill="currentColor" stroke="none" aria-hidden="true"><circle cx="12" cy="5" r="1.6"></circle><circle cx="12" cy="12" r="1.6"></circle><circle cx="12" cy="19" r="1.6"></circle></svg>
												</button>
												<div class="zui-actions-menu" role="menu" hidden>
													<button type="button" role="menuitem" class="zui-actions-item cev_send_reminder_button" data-id="<?php echo esc_attr( $entry_id ); ?>" data-nonce="<?php echo esc_attr( wp_create_nonce( 'cev_reengagement_send_one_nonce' ) ); ?>">
														<?php $cev_print_html( $cev_icon( 'mail' ) ); ?>
														<?php esc_html_e( 'Send reminder', 'customer-email-verification' ); ?>
													</button>
													<button type="button" role="menuitem" class="zui-actions-item zui-actions-item--danger delete_button" data-id="<?php echo esc_attr( $entry_id ); ?>">
														<?php $cev_print_html( $cev_icon( 'trash' ) ); ?>
														<?php esc_html_e( 'Delete', 'customer-email-verification' ); ?>
													</button>
												</div>
											</div>
										</td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>

					</div>
				<?php else : ?>
					<div class="zui-card zui-placeholder">
						<p class="zui-placeholder__title"><?php esc_html_e( 'No unverified users', 'customer-email-verification' ); ?></p>
						<p class="zui-placeholder__text"><?php esc_html_e( 'Everyone who signed up has verified their email — nothing pending right now.', 'customer-email-verification' ); ?></p>
					</div>
				<?php endif; ?>

			</section>

			<!-- ── Section: Maintenance ───────────────────────── -->
			<section class="zui-section" data-zui-section="maintenance" hidden>

				<div class="zui-section-header">
					<div class="zui-section-header__main">
						<span class="zui-section-header__icon"><?php $cev_print_html( $cev_icon( 'wrench' ) ); ?></span>
						<div class="zui-section-header__text">
							<div class="zui-section-header__titlewrap">
								<h2 class="zui-section-header__title"><?php esc_html_e( 'Maintenance', 'customer-email-verification' ); ?></h2>
							</div>
							<p class="zui-section-header__sub"><?php esc_html_e( 'Background hygiene tools for unverified records and accounts.', 'customer-email-verification' ); ?></p>
						</div>
					</div>
					<div class="zui-section-header__actions">
						<span class="zui-savebtn-wrap">
							<?php // Submits #cev_maintenance_form (rendered below) via the form attribute. ?>
							<button type="submit" form="cev_maintenance_form" name="save" class="zui-savebtn woocommerce-save-button cev_settings_save" aria-label="<?php esc_attr_e( 'Save all maintenance settings', 'customer-email-verification' ); ?>">
								<?php esc_html_e( 'Save changes', 'customer-email-verification' ); ?>
							</button>
						</span>
					</div>
				</div>

				<?php
				$cev_maintenance_path = cev_pro()->get_plugin_path() . '/includes/admin/views/cev_maintenance_tab.php';
				if ( file_exists( $cev_maintenance_path ) ) {
					include $cev_maintenance_path;
				}
				?>

			</section>

		</main>
	</div>
</section>
