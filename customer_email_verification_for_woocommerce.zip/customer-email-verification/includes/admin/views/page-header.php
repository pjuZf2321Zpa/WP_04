<?php
/**
 * Admin Page Header (ZUI shell)
 *
 * Renders the Zorem UI header bar (brand + actions) and the top tab strip.
 * Included from page-layout.php so it lives INSIDE the .zui-scope wrapper
 * (the --zui-* design tokens are scoped to .zui-scope).
 *
 * Expected in scope (from render_email_verification_page()):
 *   $current_tab     string  Current tab slug.
 *   $admin_instance  object  The admin class instance (for tab data).
 *
 * @package Customer_Email_Verification_Pro
 * @since 2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

// Load ZUI brand registry + icon renderer (idempotent — wrapped in function_exists).
require_once cev_pro()->get_plugin_path() . '/assets/zui/brand.php';
require_once cev_pro()->get_plugin_path() . '/assets/zui/icons.php';

// Resolve icon key from the shared ZUI registry (colours are set explicitly below).
$cev_brand        = \Zorem\UI\get_plugin_brand( 'customer-email-verification/customer-email-verification.php' );
$cev_icon_key     = $cev_brand ? $cev_brand['icon'] : 'shield-check';
$cev_emblem_bg    = '#DBEAFE';
$cev_emblem_color = '#2563EB';

$cev_docs_url = 'https://docs.zorem.com/docs/customer-email-verification-pro/';
?>
<header class="zui-header" id="cev-set-header">
	<div class="zui-header__bar">

		<div class="zui-header__lead">
			<button type="button" class="zui-header__menu-toggle" data-zui-drawer-toggle aria-label="<?php esc_attr_e( 'Open settings menu', 'customer-email-verification' ); ?>">
				<svg class="zui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
			</button>

			<div class="zui-brand">
				<span class="zui-brand__emblem" aria-hidden="true" style="--zui-brand-emblem-bg:<?php echo esc_attr( $cev_emblem_bg ); ?>;--zui-brand-emblem-color:<?php echo esc_attr( $cev_emblem_color ); ?>">
					<?php \Zorem\UI\icon( $cev_icon_key ); ?>
				</span>
				<span class="zui-brand__name">CEV</span>
				<span class="zui-brand__badge">PRO</span>
				<span class="zui-brand__tagline"><?php esc_html_e( 'Customer Email Verification', 'customer-email-verification' ); ?></span>
			</div>
		</div>

		<div class="zui-header-actions">
			<a class="zui-header-action zui-header-action--with-label" href="<?php echo esc_url( $cev_docs_url ); ?>" target="_blank" rel="noreferrer noopener">
				<svg class="zui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path></svg>
				<span class="zui-header-action__label"><?php esc_html_e( 'Docs', 'customer-email-verification' ); ?></span>
			</a>
		</div>

	</div>

	<nav class="zui-tabs" aria-label="<?php esc_attr_e( 'CEV Pro modules', 'customer-email-verification' ); ?>">
		<?php
		if ( isset( $admin_instance ) ) {
			$admin_instance->render_menu_tabs( $admin_instance->get_cev_tab_settings_data() );
		}
		?>
	</nav>
</header>
