<?php
/**
 * Admin Page Layout (ZUI shell)
 *
 * Owns the .zui-scope wrapper. Pulls in the header/tabs partial (inside the
 * scope so the design tokens resolve), then renders one .zui-tab-panel per
 * top tab. Only the current tab's panel is visible; the rest carry [hidden].
 *
 * Top-tab switching is a server-side reload (see menu-tabs.php), so each
 * panel's content initialises fresh on load — no client-side tab JS needed.
 *
 * Expected in scope (from render_email_verification_page()):
 *   $current_tab     string
 *   $plugin_path     string
 *   $admin_instance  object  (also $this === admin instance here)
 *
 * @package Customer_Email_Verification_Pro
 * @since 2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

$plugin_instance = cev_pro();
$plugin_path     = isset( $plugin_path ) ? $plugin_path : $plugin_instance->get_plugin_path();
$current_tab     = isset( $current_tab ) ? $current_tab : 'email-verification';

$views = $plugin_path . '/includes/admin/views/';

// data-tab slug => content view file. (Customize is an external link, no panel.)
$cev_panels = array(
	'email-verification' => 'admin_options_settings.php',
	'unverified-users'   => 'cev_users_tab.php',
	'analytics'          => 'cev_analytics_tab.php',
);
?>
<div class="zui-scope cev-admin" id="cev-admin-app">

	<?php
	// Header + top tabs (kept inside .zui-scope on purpose).
	$header_path = $views . 'page-header.php';
	if ( file_exists( $header_path ) ) {
		include $header_path;
	}
	?>

	<?php foreach ( $cev_panels as $tab_slug => $view_file ) : ?>
		<div class="zui-tab-panel" data-zui-tab="<?php echo esc_attr( $tab_slug ); ?>" <?php echo ( $current_tab === $tab_slug ) ? '' : 'hidden'; ?>>
			<?php
			$panel_path = $views . $view_file;
			if ( file_exists( $panel_path ) ) {
				require_once $panel_path;
			}
			?>
		</div>
	<?php endforeach; ?>

</div>
