<?php
/**
 * Dropdown Field Template (ZUI native styled select).
 *
 * @package Customer_Email_Verification_Pro
 * @since 2.10.0
 *
 * Expected variables, supplied by the including scope:
 *
 * @var string $field_id Setting id used as the control name/id.
 * @var array  $field    Field definition array from the settings schema.
 * @var string $disabled Rendered disabled attribute/class, or an empty string.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

$default_value = isset( $field['Default'] ) ? $field['Default'] : '';
$current_value = cev_pro()->function->cev_pro_admin_settings( $field_id, $default_value );
?>
<div class="zui-select-wrap">
	<select
		class="zui-select"
		id="<?php echo esc_attr( $field_id ); ?>"
		name="<?php echo esc_attr( $field_id ); ?>"
		<?php echo esc_attr( $disabled ); ?>
	>
		<?php
		foreach ( $field['options'] as $option_key => $option_value ) {
			?>
			<option value="<?php echo esc_attr( $option_key ); ?>" <?php selected( (string) $current_value, (string) $option_key ); ?>>
				<?php echo esc_html( $option_value ); ?>
			</option>
			<?php
		}
		?>
	</select>
	<span class="zui-select-chevron">
		<svg class="zui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"></polyline></svg>
	</span>
</div>
