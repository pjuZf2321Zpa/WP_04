<?php
/**
 * Multiple Select Field Template (ZUI .zui-ms widget).
 *
 * Renders the ZUI multi-select: a hidden native <select multiple> as the
 * save-of-truth, plus the chip control + dropdown. The powering JS lives in
 * admin.js (ZuiMultiselect), auto-initialised via the data-zui-multiselect
 * hook. Save handling is unchanged — the native select posts field_id[].
 *
 * @package Customer_Email_Verification
 * @since 1.0.0
 *
 * Expected variables, supplied by the including scope:
 *
 * @var string $field_id Setting id used as the control name/id.
 * @var array  $field    Field definition array from the settings schema.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

$multi_values = cev_pro()->function->cev_pro_admin_settings( $field_id, array() );
$placeholder  = isset( $field['placeholder'] ) ? $field['placeholder'] : __( 'Select one or more…', 'customer-email-verification' );

// Selected options — used for the initial (no-flash) chip render. The JS
// re-renders chips + dropdown from the native <select> on init.
$selected_opts = array();
foreach ( $field['options'] as $option_key => $option_value ) {
	if ( isset( $multi_values[ $option_key ] ) && 1 === (int) $multi_values[ $option_key ] ) {
		$selected_opts[ $option_key ] = $option_value;
	}
}
?>
<div class="zui-ms" data-zui-multiselect data-placeholder="<?php echo esc_attr( $placeholder ); ?>">
	<select multiple class="zui-ms__native" name="<?php echo esc_attr( $field_id ); ?>[]" id="<?php echo esc_attr( $field_id ); ?>" hidden>
		<?php foreach ( $field['options'] as $option_key => $option_value ) : ?>
			<option value="<?php echo esc_attr( $option_key ); ?>"<?php echo isset( $selected_opts[ $option_key ] ) ? ' selected' : ''; ?>><?php echo esc_html( $option_value ); ?></option>
		<?php endforeach; ?>
	</select>
	<div class="zui-ms__control" tabindex="0" role="combobox" aria-haspopup="listbox" aria-expanded="false">
		<div class="zui-ms__chips">
			<?php if ( empty( $selected_opts ) ) : ?>
				<span class="zui-ms__placeholder"><?php echo esc_html( $placeholder ); ?></span>
			<?php else : ?>
				<?php foreach ( $selected_opts as $option_key => $option_value ) : ?>
					<span class="zui-ms__chip" data-value="<?php echo esc_attr( $option_key ); ?>">
						<span class="zui-ms__chip-label"><?php echo esc_html( $option_value ); ?></span>
						<button type="button" class="zui-ms__chip-remove" aria-label="<?php esc_attr_e( 'Remove', 'customer-email-verification' ); ?>">&times;</button>
					</span>
				<?php endforeach; ?>
			<?php endif; ?>
		</div>
		<span class="zui-ms__chevron">
			<svg class="zui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"></polyline></svg>
		</span>
	</div>
	<div class="zui-ms__dropdown" role="listbox" hidden></div>
</div>
