<?php
/**
 * Field Description Template (ZUI — full-width informational text).
 *
 * @package Customer_Email_Verification_Pro
 * @since 2.10.0
 *
 * Expected variables, supplied by the including scope:
 *
 * @var string $field_id Setting id used as the control name/id.
 * @var array  $field    Field definition array from the settings schema.
 * @var string $disabled Rendered disabled attribute/class, or an empty string.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<p class="zui-row__desc <?php echo esc_attr( $disabled ); ?>" id="<?php echo esc_attr( $field_id ); ?>">
	<?php
	if ( ! empty( $field['html'] ) ) {
		echo wp_kses_post( $field['html'] );
	} else {
		echo esc_html( $field['title'] );
	}
	?>
</p>
