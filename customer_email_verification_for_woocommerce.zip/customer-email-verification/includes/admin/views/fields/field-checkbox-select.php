<?php
/**
 * Checkbox + Select Field Template (ZUI control only — label is the row head).
 *
 * @package Customer_Email_Verification_Pro
 * @since 2.10.0
 *
 * Expected variables, supplied by the including scope:
 *
 * @var string $field_id Setting id used as the control name/id.
 * @var array  $field    Field definition array from the settings schema.
 * @var string $disabled Rendered disabled attribute/class, or an empty string.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

$default_value = isset( $field['Default'] ) ? $field['Default'] : 1;
$is_checked    = (bool) cev_pro()->function->cev_pro_admin_settings( $field_id, $default_value );
?>
<div class="zui-control-group">
	<label class="zui-checkbox <?php echo esc_attr( $disabled ); ?>">
		<input
			type="checkbox"
			class="zui-checkbox__input"
			id="<?php echo esc_attr( $field_id ); ?>"
			name="<?php echo esc_attr( $field_id ); ?>"
			value="1"
			<?php checked( $is_checked ); ?>
			<?php echo esc_attr( $disabled ); ?>
		/>
		<span class="zui-checkbox__box"></span>
	</label>

	<?php if ( ! empty( $field['select'] ) ) : ?>
		<?php
		$select_id      = $field['select']['id'];
		$selected_value = cev_pro()->function->cev_pro_admin_settings( $select_id, '' );
		?>
		<div class="zui-select-wrap">
			<select
				class="zui-select"
				name="<?php echo esc_attr( $select_id ); ?>"
				id="<?php echo esc_attr( $select_id ); ?>"
				<?php echo esc_attr( $disabled ); ?>
			>
				<?php
				foreach ( $field['select']['options'] as $option_key => $option_value ) {
					?>
					<option value="<?php echo esc_attr( $option_key ); ?>" <?php selected( (string) $selected_value, (string) $option_key ); ?>>
						<?php echo esc_html( $option_value ); ?>
					</option>
					<?php
				}
				?>
			</select>
			<span class="zui-select-chevron">
				<svg class="zui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"></polyline></svg>
			</span>
		</div>
	<?php endif; ?>
</div>
