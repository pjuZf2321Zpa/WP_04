<?php
/**
 * Toggle group (CEV) — single-select OR multi-select.
 *
 * Rendered as ZUI toggle rows inside a self-contained bordered card (heading +
 * rows, no inner dividers). The chosen value(s) live in a hidden input
 * (name = field_id). By default the group is single-select (radio semantics);
 * with `'multi' => true` it becomes multi-select and the hidden input holds a
 * comma-separated list of the enabled values. Both modes plus dependent
 * conditionals are driven by SmartFormUI in admin.js (which reads the
 * data-cev-toggle-multi flag).
 *
 * @package Customer_Email_Verification
 * @since 2.10.0
 *
 * Expected variables, supplied by the including scope:
 *
 * @var string $field_id Setting id used as the control name/id.
 * @var array  $field    Field definition array from the settings schema.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

$default_value = isset( $field['Default'] ) ? $field['Default'] : '';
$current_value = (string) cev_pro()->function->cev_pro_admin_settings( $field_id, $default_value );
$options       = ( isset( $field['options'] ) && is_array( $field['options'] ) ) ? $field['options'] : array();
$heading       = isset( $field['heading'] ) ? $field['heading'] : '';
$is_multi      = ! empty( $field['multi'] );

// For multi-select the stored value is a comma-separated list; build a lookup
// of the currently-enabled values so each toggle can reflect its own state.
$selected_values = $is_multi
	? array_filter( array_map( 'trim', explode( ',', $current_value ) ) )
	: array();
?>
<div class="cev-method-card">
	<?php if ( '' !== $heading ) : ?>
		<span class="cev-group-title">
			<?php echo esc_html( $heading ); ?>
			<?php if ( ! empty( $field['tooltip'] ) ) : ?>
				<span class="zui-tooltip" tabindex="0" role="img" aria-label="<?php echo esc_attr( $field['tooltip'] ); ?>">
					<svg class="zui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
					<span class="zui-tooltip__bubble"><?php echo esc_html( $field['tooltip'] ); ?><span class="zui-tooltip__arrow"></span></span>
				</span>
			<?php endif; ?>
		</span>
	<?php endif; ?>
	<input type="hidden" name="<?php echo esc_attr( $field_id ); ?>" id="<?php echo esc_attr( $field_id ); ?>" value="<?php echo esc_attr( $current_value ); ?>" data-cev-toggle-select<?php echo $is_multi ? ' data-cev-toggle-multi="1"' : ''; ?> />
	<div class="cev-method-list" data-cev-toggle-group="<?php echo esc_attr( $field_id ); ?>">
		<?php foreach ( $options as $opt_value => $opt ) : ?>
			<?php
			$opt_label = isset( $opt['label'] ) ? $opt['label'] : '';
			$opt_desc  = isset( $opt['desc'] ) ? $opt['desc'] : '';
			$opt_phone = ! empty( $opt['hidden_unless_phone'] );
			$is_on     = $is_multi
				? in_array( (string) $opt_value, $selected_values, true )
				: ( $current_value === (string) $opt_value );
			?>
			<div class="cev-method-item" data-cev-option="<?php echo esc_attr( $opt_value ); ?>"<?php echo $opt_phone ? ' data-cev-phone-only="1"' : ''; ?>>
				<span class="cev-method-item__text">
					<span class="cev-method-item__label"><?php echo esc_html( $opt_label ); ?></span>
					<?php if ( '' !== $opt_desc ) : ?>
						<span class="cev-method-item__desc"><?php echo esc_html( $opt_desc ); ?></span>
					<?php endif; ?>
				</span>
				<label class="zui-toggle">
					<input type="checkbox" class="zui-toggle__input cev-method-toggle" data-cev-value="<?php echo esc_attr( $opt_value ); ?>" <?php checked( $is_on ); ?> />
					<span class="zui-toggle__track"><span class="zui-toggle__thumb"></span></span>
				</label>
			</div>
		<?php endforeach; ?>
	</div>
</div>
