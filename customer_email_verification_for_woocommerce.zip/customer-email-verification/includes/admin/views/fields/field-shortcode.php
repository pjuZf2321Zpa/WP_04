<?php
/**
 * Shortcode Callout Field Template (CEV).
 *
 * A highlighted full-width banner (icon + heading + description) with the
 * shortcode and a click-to-copy button. Used for the Smart Form placement
 * code. Copy behaviour lives in admin.js (SmartFormUI).
 *
 * @package Customer_Email_Verification
 * @since 2.10.0
 *
 * Expected variables, supplied by the including scope:
 *
 * @var array $field Field definition array from the settings schema.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

$cev_shortcode = isset( $field['shortcode'] ) ? $field['shortcode'] : '';
$cev_title     = isset( $field['title'] ) ? $field['title'] : '';
$cev_desc      = isset( $field['description'] ) ? $field['description'] : '';
?>
<div class="cev-shortcode-callout">
	<div class="cev-shortcode-callout__head">
		<span class="cev-shortcode-callout__icon" aria-hidden="true">
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"></polyline><polyline points="8 6 2 12 8 18"></polyline></svg>
		</span>
		<span class="cev-shortcode-callout__text">
			<strong class="cev-shortcode-callout__title"><?php echo esc_html( $cev_title ); ?></strong>
			<?php if ( '' !== $cev_desc ) : ?>
				<span class="cev-shortcode-callout__desc"><?php echo esc_html( $cev_desc ); ?></span>
			<?php endif; ?>
		</span>
	</div>
	<div class="cev-shortcode-callout__row">
		<code class="cev-shortcode-chip"><?php echo esc_html( $cev_shortcode ); ?></code>
		<button type="button" class="cev-shortcode-copy" data-cev-copy="<?php echo esc_attr( $cev_shortcode ); ?>" data-cev-copied="<?php esc_attr_e( 'Copied!', 'customer-email-verification' ); ?>"><?php esc_html_e( 'Copy', 'customer-email-verification' ); ?></button>
	</div>
</div>
