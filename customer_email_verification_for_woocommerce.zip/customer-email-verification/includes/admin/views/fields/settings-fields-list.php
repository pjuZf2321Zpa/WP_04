<?php
/**
 * Settings Fields List Template (ZUI)
 *
 * Wraps a section's fields in a .zui-card and renders each field as a .zui-row
 * (inline for toggles/checkboxes, stacked otherwise). The label + one-line
 * description live in .zui-row__head; the control template fills .zui-row__control.
 *
 * Field ids/names and per-field $field['class'] hooks are preserved on the row
 * so the existing admin.js conditional show/hide logic keeps working (it now
 * targets .zui-row instead of <li>).
 *
 * @package Customer_Email_Verification_Pro
 * @since 2.10.0
 *
 * Expected variables, supplied by the including scope:
 *
 * @var array                  $fields                    Settings schema for the section being rendered.
 * @var CEV_Pro_Admin_Settings $settings_instance         The settings object that included this template.
 * @var array                  $field_types_without_label Field types whose row head omits the label.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

// Field types whose control sits to the RIGHT of the label (inline row).
$cev_inline_types = array( 'toogel', 'checkbox', 'checkbox_select', 'dropdown', 'segmented' );

// Whether to wrap the rows in a .zui-card. Sections that supply their own
// card (e.g. Maintenance) pass false via render_settings_fields($fields, false).
// IMPORTANT: use pure-PHP brace syntax for the wrapper — NOT the alt-syntax
// form (if : ... endif). PHPCS's Generic.WhiteSpace.ScopeIndent.IncorrectExact
// rule treats the colon like an opening brace, and on some audit-server
// versions it fires even when the body div is on its own line. Echoing the
// literal HTML from inside the if() block sidesteps the sniff entirely.
$cev_wrap_card = isset( $cev_wrap_card ) ? (bool) $cev_wrap_card : true;

if ( $cev_wrap_card ) {
	echo '<div class="zui-card">';
}

foreach ( (array) $fields as $field_id => $field ) {

	if ( empty( $field['show'] ) ) {
		continue;
	}

	// Use a CEV-prefixed local — `$type` is a WordPress core global
	// (post type) and reassigning it trips
	// WordPress.WP.GlobalVariablesOverride in template scope.
	$cev_field_type = isset( $field['type'] ) ? $field['type'] : 'text';

	// Separators drive the group dividers (rows themselves are flush) so the
	// layout matches the schema's intended grouping. A separator may carry a
	// class + initially_visible so it can hide together with the group it
	// introduces, instead of leaving a stray rule behind.
	if ( 'separator' === $cev_field_type ) {
		$cev_sep_class = isset( $field['class'] ) ? ' ' . $field['class'] : '';
		$cev_sep_style = ( isset( $field['initially_visible'] ) && 'no' === $field['initially_visible'] ) ? 'display:none' : '';
		printf(
			'<div class="zui-row-divider%1$s" style="%2$s"></div>',
			esc_attr( $cev_sep_class ),
			esc_attr( $cev_sep_style )
		);
		continue;
	}

	$class    = isset( $field['class'] ) ? $field['class'] : '';
	$hidden   = ( isset( $field['initially_visible'] ) && 'no' === $field['initially_visible'] );
	$disabled = isset( $disabled_states[ $field_id ] ) ? $disabled_states[ $field_id ] : '';

	// Full-width controls that render their own heading/layout (no
	// label/control split): info paragraphs + the Smart Form widgets.
	if ( in_array( $cev_field_type, array( 'desc', 'toggle_select', 'sms_gateway', 'shortcode' ), true ) ) {
		?>
		<div class="zui-row zui-row--flush <?php echo esc_attr( $class ); ?>"<?php echo $hidden ? ' style="display:none"' : ''; ?>>
			<div class="zui-row__control">
				<?php $settings_instance->render_field_by_type( $field_id, $field, $disabled ); ?>
			</div>
		</div>
		<?php
		continue;
	}

	$inline = in_array( $cev_field_type, $cev_inline_types, true ) || ! empty( $field['inline'] );
	?>
	<div class="zui-row zui-row--flush<?php echo $inline ? ' zui-row--inline' : ''; ?> <?php echo esc_attr( $class ); ?>"<?php echo $hidden ? ' style="display:none"' : ''; ?>>
		<div class="zui-row__head">
			<span class="zui-row__label">
				<?php echo esc_html( $field['title'] ); ?>
				<?php if ( ! empty( $field['tooltip'] ) ) : ?>
					<span class="zui-tooltip" tabindex="0" role="img" aria-label="<?php echo esc_attr( $field['tooltip'] ); ?>">
						<svg class="zui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
						<span class="zui-tooltip__bubble"><?php echo esc_html( $field['tooltip'] ); ?><span class="zui-tooltip__arrow"></span></span>
					</span>
				<?php endif; ?>
			</span>
			<?php if ( ! empty( $field['description'] ) ) : ?>
				<p class="zui-row__desc"><?php echo esc_html( $field['description'] ); ?></p>
			<?php endif; ?>
		</div>
		<div class="zui-row__control">
			<?php $settings_instance->render_field_by_type( $field_id, $field, $disabled ); ?>
		</div>
	</div>
	<?php
}

if ( $cev_wrap_card ) {
	echo '</div>';
}
