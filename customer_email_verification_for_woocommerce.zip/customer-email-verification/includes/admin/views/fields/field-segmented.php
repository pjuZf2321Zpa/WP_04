<?php
/**
 * Segmented Control Field Template (CEV).
 *
 * A pill toggle (one option active) backed by a hidden <input> that holds the
 * selected value, so the existing save path persists it unchanged. The toggle
 * JS lives in admin.js (SegmentedControl), keyed on data-cev-segmented.
 *
 * @package Customer_Email_Verification
 * @since 2.10.0
 *
 * Expected variables, supplied by the including scope:
 *
 * @var string $field_id Setting id used as the control name/id.
 * @var array  $field    Field definition array from the settings schema.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

$default_value = isset( $field['Default'] ) ? $field['Default'] : '';
$current_value = (string) cev_pro()->function->cev_pro_admin_settings( $field_id, $default_value );
$options       = ( isset( $field['options'] ) && is_array( $field['options'] ) ) ? $field['options'] : array();
?>
<input type="hidden" name="<?php echo esc_attr( $field_id ); ?>" id="<?php echo esc_attr( $field_id ); ?>" value="<?php echo esc_attr( $current_value ); ?>" />
<div class="zui-segmented" role="tablist" data-cev-segmented="<?php echo esc_attr( $field_id ); ?>">
	<?php foreach ( $options as $opt_value => $opt_label ) : ?>
		<button type="button" class="zui-segmented__item<?php echo ( $current_value === (string) $opt_value ) ? ' is-active' : ''; ?>" role="tab" aria-selected="<?php echo ( $current_value === (string) $opt_value ) ? 'true' : 'false'; ?>" data-value="<?php echo esc_attr( $opt_value ); ?>"><?php echo esc_html( $opt_label ); ?></button>
	<?php endforeach; ?>
</div>
