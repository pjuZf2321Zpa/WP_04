<?php
/**
 * Smart Form Template Picker Field Template (CEV).
 *
 * Four radio cards (one checked) with mini wireframe previews. The checked
 * radio (name = field_id) is the source of truth — selection + value persist
 * natively, no JS needed; the active card is styled via :checked / :has().
 *
 * @package Customer_Email_Verification
 * @since 2.10.0
 *
 * Expected variables, supplied by the including scope:
 *
 * @var string $field_id Setting id used as the control name/id.
 * @var array  $field    Field definition array from the settings schema.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

$default_value = isset( $field['Default'] ) ? $field['Default'] : 'template1';
$current_value = (string) cev_pro()->function->cev_pro_admin_settings( $field_id, $default_value );

$cev_templates = array(
	'template1' => array(
		'name'  => __( 'Template 1 — Tabbed card', 'customer-email-verification' ),
		'title' => __( 'Tabbed login & register', 'customer-email-verification' ),
		'desc'  => __( 'Bordered card with a brand top accent and underline tabs. The only tabbed template.', 'customer-email-verification' ),
	),
	'template2' => array(
		'name'  => __( 'Template 2 — Split / brand panel', 'customer-email-verification' ),
		'title' => __( 'Two-column hero', 'customer-email-verification' ),
		'desc'  => __( 'Brand panel beside a single form — switch with a link, no tabs.', 'customer-email-verification' ),
	),
	'template3' => array(
		'name'  => __( 'Template 3 — Brand header banner', 'customer-email-verification' ),
		'title' => __( 'Header banner', 'customer-email-verification' ),
		'desc'  => __( 'Brand-colored header with the store name, form below — switch with a link, no tabs.', 'customer-email-verification' ),
	),
	'template4' => array(
		'name'  => __( 'Template 4 — Side-by-side', 'customer-email-verification' ),
		'title' => __( 'Login & Register columns', 'customer-email-verification' ),
		'desc'  => __( 'Both visible at once, side by side. No tabs.', 'customer-email-verification' ),
	),
);

// Emits the mini wireframe markup for a given template key (static HTML).
$cev_wireframe = function ( $key ) {
	switch ( $key ) {
		case 'template1':
			?>
			<span class="cev-wf">
				<span class="cev-wf-card cev-wf-card--narrow cev-wf-card--accent">
					<span class="cev-wf-line cev-wf-line--logo-left"></span>
					<span class="cev-wf-tabs cev-wf-tabs--underline">
						<span class="cev-wf-tab cev-wf-tab--on"></span>
						<span class="cev-wf-tab"></span>
					</span>
					<span class="cev-wf-line"></span>
					<span class="cev-wf-line"></span>
					<span class="cev-wf-btn"></span>
				</span>
			</span>
			<?php
			break;
		case 'template2':
			?>
			<span class="cev-wf cev-wf--split">
				<span class="cev-wf-brand"></span>
				<span class="cev-wf-col">
					<span class="cev-wf-line"></span>
					<span class="cev-wf-line cev-wf-line--half"></span>
					<span class="cev-wf-btn"></span>
				</span>
			</span>
			<?php
			break;
		case 'template3':
			?>
			<span class="cev-wf">
				<span class="cev-wf-card cev-wf-card--narrow">
					<span class="cev-wf-banner"></span>
					<span class="cev-wf-line"></span>
					<span class="cev-wf-line cev-wf-line--half"></span>
					<span class="cev-wf-line"></span>
					<span class="cev-wf-btn"></span>
				</span>
			</span>
			<?php
			break;
		case 'template4':
			?>
			<span class="cev-wf cev-wf--cols">
				<span class="cev-wf-col">
					<span class="cev-wf-line cev-wf-line--half"></span>
					<span class="cev-wf-line"></span>
					<span class="cev-wf-btn"></span>
				</span>
				<span class="cev-wf-col cev-wf-col--divider">
					<span class="cev-wf-line cev-wf-line--half"></span>
					<span class="cev-wf-line"></span>
					<span class="cev-wf-btn"></span>
				</span>
			</span>
			<?php
			break;
	}
};
?>
<a class="cev-tpl-customize-link" href="<?php echo esc_url( admin_url( 'admin.php?page=cev_customizer' ) ); ?>"><?php esc_html_e( 'Customize in the Customizer tab →', 'customer-email-verification' ); ?></a>
<div class="cev-tpl-grid">
	<?php foreach ( $cev_templates as $cev_key => $cev_tpl ) : ?>
		<label class="cev-tpl-card">
			<input type="radio" class="cev-tpl-card__radio" name="<?php echo esc_attr( $field_id ); ?>" value="<?php echo esc_attr( $cev_key ); ?>" <?php checked( $current_value, $cev_key ); ?> />
			<span class="cev-tpl-card__bar">
				<span class="cev-tpl-dot"></span>
				<span class="cev-tpl-dot"></span>
				<span class="cev-tpl-dot"></span>
				<span class="cev-tpl-card__name"><?php echo esc_html( $cev_tpl['name'] ); ?></span>
				<span class="cev-tpl-card__check" aria-hidden="true">&#10003;</span>
			</span>
			<span class="cev-tpl-card__canvas">
				<?php $cev_wireframe( $cev_key ); ?>
			</span>
			<span class="cev-tpl-card__meta">
				<strong><?php echo esc_html( $cev_tpl['title'] ); ?></strong>
				<small><?php echo esc_html( $cev_tpl['desc'] ); ?></small>
			</span>
		</label>
	<?php endforeach; ?>
</div>
