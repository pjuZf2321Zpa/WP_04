<?php
/**
 * Toggle Field Template (ZUI control only — label is emitted by the row head).
 *
 * @package Customer_Email_Verification_Pro
 * @since 2.10.0
 *
 * Expected variables, supplied by the including scope:
 *
 * @var string $field_id Setting id used as the control name/id.
 * @var array  $field    Field definition array from the settings schema.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

$default_value = isset( $field['Default'] ) ? $field['Default'] : '';
$is_checked    = (bool) cev_pro()->function->cev_pro_admin_settings( $field_id, $default_value );
?>
<label class="zui-toggle">
	<input
		type="checkbox"
		class="zui-toggle__input"
		id="<?php echo esc_attr( $field_id ); ?>"
		name="<?php echo esc_attr( $field_id ); ?>"
		value="1"
		<?php checked( $is_checked ); ?>
	/>
	<span class="zui-toggle__track"><span class="zui-toggle__thumb"></span></span>
</label>
