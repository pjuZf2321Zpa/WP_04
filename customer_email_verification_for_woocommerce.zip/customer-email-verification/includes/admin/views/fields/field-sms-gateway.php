<?php
/**
 * SMS Gateway section (CEV).
 *
 * Provider dropdown + per-provider credential fields (WhatsApp / Twilio /
 * Vonage / MSG91). Each input is named after its own setting key and saved by
 * CEV_Pro_Admin_Settings::update_sms_gateway_field(). Provider switching and
 * the nested conditionals (Twilio send-via, WhatsApp header image) are driven
 * by SmartFormUI in admin.js. The whole row is shown only when phone
 * verification or Phone OTP login is selected.
 *
 * @package Customer_Email_Verification
 * @since 2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

$cev_get = function ( $key, $fallback = '' ) {
	return cev_pro()->function->cev_pro_admin_settings( $key, $fallback );
};

$cev_provider = (string) $cev_get( 'cev_sms_provider', 'whatsapp' );
$cev_sendvia  = (string) $cev_get( 'cev_sms_twilio_send_via', 'phone_number' );
$cev_wa_img   = (bool) $cev_get( 'cev_sms_wa_header_image', 0 );

// Renders one labelled text input (optionally full-width / with a hint).
$cev_text = function ( $key, $label, $hint, $full ) use ( $cev_get ) {
	$classes = 'cev-sms-field' . ( $full ? ' cev-sms-field--full' : '' );
	?>
	<div class="<?php echo esc_attr( $classes ); ?>">
		<label class="cev-sms-field__label" for="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label>
		<?php if ( '' !== $hint ) : ?>
			<span class="cev-sms-field__hint"><?php echo esc_html( $hint ); ?></span>
		<?php endif; ?>
		<input type="text" class="zui-input" id="<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( $cev_get( $key ) ); ?>" autocomplete="off" />
	</div>
	<?php
};

// "Where do I find these?" helper link for a provider.
$cev_help = function ( $anchor ) {
	$url = 'https://docs.zorem.com/docs/sms-for-woocommerce/how-to-get-the-sms-provider-api-keys/' . $anchor;
	?>
	<a class="cev-sms__link" href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Where do I find these?', 'customer-email-verification' ); ?></a>
	<?php
};
?>
<span class="cev-group-title"><?php esc_html_e( 'SMS Gateway', 'customer-email-verification' ); ?></span>
<p class="cev-sms__intro"><?php esc_html_e( 'Connect a provider to send verification codes by phone. Required for phone verification and Phone OTP login.', 'customer-email-verification' ); ?></p>
<input type="hidden" name="cev_smart_sms_gateway" value="1" />
<?php
$cev_sms_managed      = class_exists( 'CEV_SMS_Compat' ) && CEV_SMS_Compat::is_sms_plugin_available();
$cev_sms_incompatible = class_exists( 'CEV_SMS_Compat' ) && CEV_SMS_Compat::is_active_but_incompatible();
?>
<?php if ( $cev_sms_managed ) : ?>
	<div class="cev-sms cev-sms--managed" style="padding:16px; border:1px solid #e2e8f0; border-radius:8px; background:#f8fafc;">
		<p class="cev-sms__intro" style="margin-top:0;"><?php esc_html_e( 'SMS Gateway settings are managed by the SMS for WooCommerce plugin. Configure your SMS provider in the SMS plugin settings.', 'customer-email-verification' ); ?></p>
		<a class="zui-btn-secondary" href="<?php echo esc_url( CEV_SMS_Compat::settings_url() ); ?>"><?php esc_html_e( 'Open SMS plugin settings', 'customer-email-verification' ); ?></a>
	</div>
<?php else : ?>
	<?php if ( $cev_sms_incompatible ) : ?>
		<div class="cev-sms__warning" style="margin-bottom:12px; padding:10px 12px; border:1px solid #fcd34d; border-radius:8px; background:#fffbeb; color:#92400e; font-size:13px;">
			<?php
			/* translators: %s = minimum supported SMS plugin version. */
			printf( esc_html__( 'Your SMS for WooCommerce plugin is too old to integrate (CEV needs %s or newer). CEV is using its own SMS gateway below until you update.', 'customer-email-verification' ), esc_html( CEV_SMS_Compat::min_version() ) );
			?>
		</div>
	<?php endif; ?>
	<div class="cev-sms" data-cev-sms>
	<div class="cev-sms-field cev-sms-field--full">
		<label class="cev-sms-field__label" for="cev_sms_provider"><?php esc_html_e( 'SMS provider', 'customer-email-verification' ); ?></label>
		<div class="zui-select-wrap">
			<select class="zui-select" id="cev_sms_provider" name="cev_sms_provider" data-cev-sms-provider>
				<option value="whatsapp" <?php selected( $cev_provider, 'whatsapp' ); ?>><?php esc_html_e( 'WhatsApp Business', 'customer-email-verification' ); ?></option>
				<option value="twilio" <?php selected( $cev_provider, 'twilio' ); ?>><?php esc_html_e( 'Twilio', 'customer-email-verification' ); ?></option>
				<option value="vonage" <?php selected( $cev_provider, 'vonage' ); ?>><?php esc_html_e( 'Vonage (Nexmo)', 'customer-email-verification' ); ?></option>
				<option value="msg91" <?php selected( $cev_provider, 'msg91' ); ?>><?php esc_html_e( 'MSG91', 'customer-email-verification' ); ?></option>
			</select>
		</div>
	</div>

	<div class="cev-sms__divider"></div>

	<div class="cev-sms-provider" data-cev-provider="whatsapp"<?php echo ( 'whatsapp' !== $cev_provider ) ? ' style="display:none"' : ''; ?>>
		<div class="cev-sms-grid">
			<?php
			$cev_text( 'cev_sms_wa_access_token', __( 'Access token', 'customer-email-verification' ), '', false );
			$cev_text( 'cev_sms_wa_namespace', __( 'Namespace', 'customer-email-verification' ), '', false );
			$cev_text( 'cev_sms_wa_sender', __( 'Sender / Phone number ID', 'customer-email-verification' ), __( "The WhatsApp 'From' phone number ID.", 'customer-email-verification' ), true );
			?>
		</div>
		<div class="cev-sms__toggle-row">
			<span class="cev-sms-field__label"><?php esc_html_e( 'Header image', 'customer-email-verification' ); ?></span>
			<label class="zui-toggle">
				<input type="checkbox" class="zui-toggle__input" name="cev_sms_wa_header_image" value="1" data-cev-sms-cond-toggle="wa_header" <?php checked( $cev_wa_img ); ?> />
				<span class="zui-toggle__track"><span class="zui-toggle__thumb"></span></span>
			</label>
		</div>
		<div class="cev-sms-grid cev-sms__cond" data-cev-sms-cond="wa_header"<?php echo $cev_wa_img ? '' : ' style="display:none"'; ?>>
			<?php $cev_text( 'cev_sms_wa_header_image_url', __( 'Header image URL', 'customer-email-verification' ), '', true ); ?>
		</div>
		<?php $cev_help( '#whatsapp-business' ); ?>
	</div>

	<div class="cev-sms-provider" data-cev-provider="twilio"<?php echo ( 'twilio' !== $cev_provider ) ? ' style="display:none"' : ''; ?>>
		<div class="cev-sms-grid">
			<?php
			$cev_text( 'cev_sms_twilio_account_sid', __( 'Account SID', 'customer-email-verification' ), '', false );
			$cev_text( 'cev_sms_twilio_auth_token', __( 'Auth Token', 'customer-email-verification' ), '', false );
			?>
			<div class="cev-sms-field cev-sms-field--full">
				<label class="cev-sms-field__label" for="cev_sms_twilio_send_via"><?php esc_html_e( 'Send via', 'customer-email-verification' ); ?></label>
				<div class="zui-select-wrap">
					<select class="zui-select" id="cev_sms_twilio_send_via" name="cev_sms_twilio_send_via" data-cev-sms-sendvia>
						<option value="phone_number" <?php selected( $cev_sendvia, 'phone_number' ); ?>><?php esc_html_e( 'Phone Number', 'customer-email-verification' ); ?></option>
						<option value="messaging_service_sid" <?php selected( $cev_sendvia, 'messaging_service_sid' ); ?>><?php esc_html_e( 'Messaging Service SID', 'customer-email-verification' ); ?></option>
					</select>
				</div>
			</div>
			<div class="cev-sms-field cev-sms-field--full" data-cev-sms-sendvia-field="phone_number"<?php echo ( 'phone_number' !== $cev_sendvia ) ? ' style="display:none"' : ''; ?>>
				<label class="cev-sms-field__label" for="cev_sms_twilio_phone"><?php esc_html_e( 'Sender phone number', 'customer-email-verification' ); ?></label>
				<input type="text" class="zui-input" id="cev_sms_twilio_phone" name="cev_sms_twilio_phone" value="<?php echo esc_attr( $cev_get( 'cev_sms_twilio_phone' ) ); ?>" autocomplete="off" />
			</div>
			<div class="cev-sms-field cev-sms-field--full" data-cev-sms-sendvia-field="messaging_service_sid"<?php echo ( 'messaging_service_sid' !== $cev_sendvia ) ? ' style="display:none"' : ''; ?>>
				<label class="cev-sms-field__label" for="cev_sms_twilio_messaging_service_sid"><?php esc_html_e( 'Messaging Service SID', 'customer-email-verification' ); ?></label>
				<span class="cev-sms-field__hint"><?php esc_html_e( 'Starts with MG…', 'customer-email-verification' ); ?></span>
				<input type="text" class="zui-input" id="cev_sms_twilio_messaging_service_sid" name="cev_sms_twilio_messaging_service_sid" value="<?php echo esc_attr( $cev_get( 'cev_sms_twilio_messaging_service_sid' ) ); ?>" autocomplete="off" />
			</div>
		</div>
		<?php $cev_help( '#twilio' ); ?>
	</div>

	<div class="cev-sms-provider" data-cev-provider="vonage"<?php echo ( 'vonage' !== $cev_provider ) ? ' style="display:none"' : ''; ?>>
		<div class="cev-sms-grid">
			<?php
			$cev_text( 'cev_sms_vonage_key', __( 'Key', 'customer-email-verification' ), '', false );
			$cev_text( 'cev_sms_vonage_secret', __( 'Secret', 'customer-email-verification' ), '', false );
			$cev_text( 'cev_sms_vonage_sender', __( 'Sender phone number / Sender ID', 'customer-email-verification' ), '', true );
			?>
		</div>
		<?php $cev_help( '#vonage-nexmo' ); ?>
	</div>

	<div class="cev-sms-provider" data-cev-provider="msg91"<?php echo ( 'msg91' !== $cev_provider ) ? ' style="display:none"' : ''; ?>>
		<div class="cev-sms-grid">
			<?php
			$cev_text( 'cev_sms_msg91_auth_key', __( 'Authentication Key', 'customer-email-verification' ), '', false );
			$cev_text( 'cev_sms_msg91_sender', __( 'Sender ID', 'customer-email-verification' ), '', false );
			?>
		</div>
		<div class="cev-sms__toggle-row">
			<span class="cev-sms-field__label"><?php esc_html_e( 'Use DLT Template id', 'customer-email-verification' ); ?></span>
			<label class="zui-toggle">
				<input type="checkbox" class="zui-toggle__input" name="cev_sms_msg91_use_dlt" value="1" <?php checked( (bool) $cev_get( 'cev_sms_msg91_use_dlt', 0 ) ); ?> />
				<span class="zui-toggle__track"><span class="zui-toggle__thumb"></span></span>
			</label>
		</div>
		<?php $cev_help( '#msg91' ); ?>
	</div>
	<div class="cev-sms__test" style="margin-top:16px; padding-top:16px; border-top:1px solid #e2e8f0;">
		<label class="cev-sms-field__label" for="cev_sms_test_phone"><?php esc_html_e( 'Send a test SMS', 'customer-email-verification' ); ?></label>
		<span class="cev-sms-field__hint"><?php esc_html_e( 'Verify your provider credentials before going live.', 'customer-email-verification' ); ?></span>
		<div class="cev-sms__test-row" style="display:flex; gap:8px; align-items:center; margin-top:8px;">
			<input type="text" class="zui-input" id="cev_sms_test_phone" placeholder="<?php esc_attr_e( 'e.g. +14155550123', 'customer-email-verification' ); ?>" autocomplete="off" style="flex:1;" />
			<button type="button" class="zui-btn-secondary cev-sms__test-btn" data-cev-sms-test data-cev-nonce="<?php echo esc_attr( wp_create_nonce( 'cev_sms_test_nonce' ) ); ?>"><?php esc_html_e( 'Send test SMS', 'customer-email-verification' ); ?></button>
		</div>
		<span class="cev-sms__test-result" aria-live="polite" style="display:block; margin-top:8px; font-size:13px;"></span>
	</div>
</div>
<?php endif; ?>
