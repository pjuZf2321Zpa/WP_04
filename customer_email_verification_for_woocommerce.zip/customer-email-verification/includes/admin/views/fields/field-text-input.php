<?php
/**
 * Text Input Field Template (ZUI).
 *
 * @package Customer_Email_Verification_Pro
 * @since 2.10.0
 *
 * Expected variables, supplied by the including scope:
 *
 * @var string $field_id Setting id used as the control name/id.
 * @var array  $field    Field definition array from the settings schema.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

$default_value = isset( $field['Default'] ) ? $field['Default'] : '';
$current_value = cev_pro()->function->cev_pro_admin_settings( $field_id, $default_value );
$placeholder   = isset( $field['placeholder'] ) ? $field['placeholder'] : '';
?>
<input
	type="text"
	class="zui-input"
	name="<?php echo esc_attr( $field_id ); ?>"
	id="<?php echo esc_attr( $field_id ); ?>"
	value="<?php echo esc_attr( $current_value ); ?>"
	placeholder="<?php echo esc_attr( $placeholder ); ?>"
/>
