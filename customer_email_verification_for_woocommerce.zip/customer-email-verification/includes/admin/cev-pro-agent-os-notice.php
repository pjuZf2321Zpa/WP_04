<?php
/**
 * AI Agent OS Launch Notice for Customer Email Verification
 *
 * Promotes zorem's AI Agent OS (launch offer: 40% off with coupon AGENTOS40)
 * in wp-admin using the shared Zorem UI plugin-notice component
 * (`.zui-pnotice`). Shown to store managers on admin pages other than the
 * plugin's own screens, until it is dismissed, the offer ends, or AI Agent OS
 * is already active.
 *
 * @package Customer_Email_Verification
 * @since 3.0.6
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'CEV_Pro_Agent_Os_Notice' ) ) {

	/**
	 * CEV_Pro_Agent_Os_Notice Class
	 *
	 * Renders the AI Agent OS launch notice and handles its dismissal.
	 */
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
	class CEV_Pro_Agent_Os_Notice {

		/**
		 * Singleton instance.
		 *
		 * @var CEV_Pro_Agent_Os_Notice
		 */
		private static $instance;

		/**
		 * AI Agent OS product page.
		 *
		 * @var string
		 */
		const PRODUCT_URL = 'https://www.zorem.com/product/ai-agent-os/';

		/**
		 * UTM source identifying this build in the product-page link.
		 *
		 * @var string
		 */
		const UTM_SOURCE = 'cev-woo';

		/**
		 * Last moment of the launch offer (site timezone, inclusive).
		 *
		 * @var string
		 */
		const OFFER_END = '2026-11-15 23:59:59';

		/**
		 * The plugin's own settings + customizer page slugs — the notice is
		 * suppressed on these so it never clashes with the custom ZUI layout.
		 *
		 * @var string[]
		 */
		const OWN_PAGES = array( 'customer-email-verification-for-woocommerce', 'cev_customizer' );

		/**
		 * AI Agent OS plugin files — the notice hides once either is active.
		 *
		 * @var string[]
		 */
		const AGENT_OS_PLUGINS = array( 'ai-agent-os/ai-agent-os.php', 'zorem-agent-os/zorem-agent-os.php' );

		/**
		 * Option holding the timestamp the notice was dismissed. Shared with the
		 * free CEV plugin, so a dismissal there carries over.
		 *
		 * @var string
		 */
		const DISMISS_OPTION = 'cev_agent_os_notice_dismissed_at';

		/**
		 * URL query parameter that triggers dismissal.
		 *
		 * @var string
		 */
		const DISMISS_QUERY_PARAM = 'cev_agent_os_notice_dismiss';

		/**
		 * Constructor.
		 *
		 * @since 3.0.6
		 */
		public function __construct() {
			$this->init();
		}

		/**
		 * Get the singleton instance.
		 *
		 * @since 3.0.6
		 * @return CEV_Pro_Agent_Os_Notice
		 */
		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Register hooks.
		 *
		 * @since 3.0.6
		 * @return void
		 */
		public function init() {
			add_action( 'admin_notices', array( $this, 'render' ) );
			add_action( 'admin_init', array( $this, 'maybe_dismiss' ) );
		}

		/**
		 * Whether the notice should be shown on the current request.
		 *
		 * @since 3.0.6
		 * @return bool
		 */
		public function should_display() {
			if ( ! current_user_can( 'manage_woocommerce' ) || get_option( self::DISMISS_OPTION ) ) {
				return false;
			}

			$offer_end = new DateTimeImmutable( self::OFFER_END, wp_timezone() );
			if ( time() > $offer_end->getTimestamp() ) {
				return false;
			}

			// Never on the plugin's own (custom-layout) admin screens.
			if ( $this->is_own_admin_page() ) {
				return false;
			}

			if ( ! function_exists( 'is_plugin_active' ) ) {
				require_once ABSPATH . 'wp-admin/includes/plugin.php';
			}
			foreach ( self::AGENT_OS_PLUGINS as $plugin_file ) {
				if ( is_plugin_active( $plugin_file ) ) {
					return false;
				}
			}

			return true;
		}

		/**
		 * Whether the current screen is one of the plugin's own admin pages.
		 *
		 * @since 3.0.6
		 * @return bool
		 */
		private function is_own_admin_page() {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Read-only screen check; no state change.
			$cev_page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';
			return in_array( $cev_page, self::OWN_PAGES, true );
		}

		/**
		 * Build the nonce-protected dismiss URL for the current page.
		 *
		 * @since 3.0.6
		 * @return string Raw URL (escape at output).
		 */
		private function get_dismiss_url() {
			return wp_nonce_url(
				add_query_arg( self::DISMISS_QUERY_PARAM, 'true' ),
				self::DISMISS_QUERY_PARAM,
				'_cev_agent_os_nonce'
			);
		}

		/**
		 * Handle the dismiss click: verify the nonce, store the timestamp, then
		 * redirect back to the same page without the query args.
		 *
		 * @since 3.0.6
		 * @return void
		 */
		public function maybe_dismiss() {
			$nonce = isset( $_GET['_cev_agent_os_nonce'] ) ? sanitize_text_field( wp_unslash( $_GET['_cev_agent_os_nonce'] ) ) : '';
			if ( '' === $nonce || ! wp_verify_nonce( $nonce, self::DISMISS_QUERY_PARAM ) ) {
				return;
			}

			if ( ! current_user_can( 'manage_woocommerce' ) ) {
				return;
			}

			$value = isset( $_GET[ self::DISMISS_QUERY_PARAM ] ) ? sanitize_text_field( wp_unslash( $_GET[ self::DISMISS_QUERY_PARAM ] ) ) : '';
			if ( 'true' !== $value ) {
				return;
			}

			update_option( self::DISMISS_OPTION, time(), false );

			wp_safe_redirect( remove_query_arg( array( self::DISMISS_QUERY_PARAM, '_cev_agent_os_nonce' ) ) );
			exit;
		}

		/**
		 * Render the notice markup (ZUI plugin-notice component).
		 *
		 * @since 3.0.6
		 * @return void
		 */
		public function render() {
			if ( ! $this->should_display() ) {
				return;
			}

			require_once cev_pro()->get_plugin_path() . '/assets/zui/icons.php';
			$dismiss_url = $this->get_dismiss_url();
			$product_url = add_query_arg(
				array(
					'utm_source'   => self::UTM_SOURCE,
					'utm_medium'   => 'admin-notice',
					'utm_campaign' => 'ai-agent-os-launch',
				),
				self::PRODUCT_URL
			);
			?>
			<div class="zui-pnotice cev-aos-notice" role="status">
				<span class="zui-pnotice__avatar" aria-hidden="true">
					<?php \Zorem\UI\icon( 'shield-check' ); ?>
				</span>
				<div class="zui-pnotice__body">
					<strong class="zui-pnotice__title">
						<?php esc_html_e( 'New from zorem: AI Agent OS — MCP Governance for WordPress AI Agents', 'customer-email-verification' ); ?>
					</strong>
					<p class="zui-pnotice__text">
						<?php esc_html_e( "See every tool your plugins expose to AI agents and set clear permissions for each agent. Customer details stay hidden from agents that don't need them, and every action is logged.", 'customer-email-verification' ); ?>
					</p>
					<p class="zui-pnotice__text cev-aos-notice__offer">
						<strong><?php esc_html_e( 'Launch offer: 40% off', 'customer-email-verification' ); ?></strong>
						&mdash;
						<?php esc_html_e( 'use coupon code', 'customer-email-verification' ); ?>
						<code class="cev-aos-notice__coupon">AGENTOS40</code>
						<?php esc_html_e( 'Valid until November 15, 2026.', 'customer-email-verification' ); ?>
					</p>
					<div class="zui-pnotice__actions">
						<a class="zui-pnotice__btn" href="<?php echo esc_url( $product_url ); ?>" target="_blank" rel="noopener noreferrer">
							<?php esc_html_e( 'Get AI Agent OS', 'customer-email-verification' ); ?>
						</a>
						<a class="zui-pnotice__link" href="<?php echo esc_url( $dismiss_url ); ?>">
							<?php esc_html_e( 'No thanks', 'customer-email-verification' ); ?>
						</a>
					</div>
				</div>
				<a class="zui-pnotice__close" href="<?php echo esc_url( $dismiss_url ); ?>" aria-label="<?php esc_attr_e( 'Dismiss this notice.', 'customer-email-verification' ); ?>">&times;</a>
			</div>
			<?php
		}
	}
}
