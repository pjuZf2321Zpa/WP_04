<?php
/**
 * Analytics dashboard — backend.
 *
 * Owns the AJAX endpoint that powers the Analytics tab. Reads from the
 * `wp_cev_verification_events` table and returns aggregated JSON:
 *   - KPI cards (signups, verified count + rate, blocked spam, avg time-to-verify)
 *   - Daily time-series (signups vs verified vs blocked, bucketed by DATE)
 *   - Funnel (signups → otp_sent → otp_verified)
 *   - Top 10 blocked disposable domains
 *
 * Date ranges are passed in from the JS picker (7d / 30d / 90d / custom).
 * All aggregation is done in SQL with GROUP BY so we never load thousands
 * of rows into PHP.
 *
 * @package Customer_Email_Verification
 * @since   2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * CEV_Pro_Admin_Analytics — singleton.
 */
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
class CEV_Pro_Admin_Analytics {

	const NONCE_ACTION = 'cev_analytics_nonce';
	const AJAX_ACTION  = 'cev_analytics_data';

	/**
	 * Singleton.
	 *
	 * @var CEV_Pro_Admin_Analytics|null
	 */
	private static $instance = null;

	/**
	 * Get singleton.
	 *
	 * @return CEV_Pro_Admin_Analytics
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'wp_ajax_' . self::AJAX_ACTION, array( $this, 'ajax_data' ) );
	}

	/* ----------------------------------------------------------------
	 * AJAX endpoint.
	 * --------------------------------------------------------------*/

	/**
	 * Return aggregated analytics data for a date range.
	 *
	 * Inputs (POST):
	 *   nonce        — `cev_analytics_nonce`
	 *   range        — one of '7d' | '30d' | '90d' | 'custom'
	 *   from / to    — Y-m-d strings, only when range = custom
	 *
	 * Output (success):
	 *   {
	 *     kpis:        { signups, verified, verified_rate, blocked, avg_seconds },
	 *     kpis_prev:   { signups, verified, blocked, avg_seconds } — for trend %
	 *     series:      { dates: [...], signups: [...], verified: [...], blocked: [...] },
	 *     funnel:      [ {label, count, pct}, ... ],
	 *     top_domains: [ {domain, count}, ... ],
	 *     range_label: 'Apr 12 — May 12, 2026'
	 *   }
	 *
	 * @return void
	 */
	public function ajax_data() {
		if ( ! check_ajax_referer( self::NONCE_ACTION, 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', 'customer-email-verification' ) ), 403 );
		}

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission.', 'customer-email-verification' ) ), 403 );
		}

		// All $_POST reads concentrated here, immediately under the nonce
		// check, so PHPCS sees the verification adjacent to the access.
		// `resolve_range()` takes these as parameters so it doesn't have
		// to touch superglobals at all.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended
		$range_key = isset( $_POST['range'] ) ? sanitize_key( wp_unslash( $_POST['range'] ) ) : '30d';
		// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended
		$from_raw = isset( $_POST['from'] ) ? sanitize_text_field( wp_unslash( $_POST['from'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended
		$to_raw = isset( $_POST['to'] ) ? sanitize_text_field( wp_unslash( $_POST['to'] ) ) : '';

		list( $from, $to ) = $this->resolve_range( $range_key, $from_raw, $to_raw );

		// Persist the user's chosen range so a page refresh restores
		// the same selection. For Custom range, also save the from/to
		// dates so the inputs come back pre-filled.
		$user_id = get_current_user_id();
		if ( in_array( $range_key, array( '7d', '30d', '90d', 'custom' ), true ) ) {
			update_user_meta( $user_id, 'cev_analytics_range', $range_key );
		}
		if ( 'custom' === $range_key ) {
			update_user_meta( $user_id, 'cev_analytics_from', gmdate( 'Y-m-d', strtotime( $from ) ) );
			update_user_meta( $user_id, 'cev_analytics_to', gmdate( 'Y-m-d', strtotime( $to ) ) );
		}

		// Previous comparable period for trend %.
		$span_seconds = strtotime( $to ) - strtotime( $from );
		$prev_to      = gmdate( 'Y-m-d H:i:s', strtotime( $from ) - 1 );
		$prev_from    = gmdate( 'Y-m-d H:i:s', strtotime( $from ) - 1 - $span_seconds );

		$kpis      = $this->kpis_for_range( $from, $to );
		$kpis_prev = $this->kpis_for_range( $prev_from, $prev_to );
		$series    = $this->series( $from, $to );
		$funnel    = $this->funnel( $from, $to );
		$top       = $this->top_blocked_domains( $from, $to, 10 );
		$status    = $this->verification_status( $from, $to );
		$ai_risk   = $this->ai_risk_summary( $from, $to );

		wp_send_json_success(
			array(
				'kpis'                => $kpis,
				'kpis_prev'           => $kpis_prev,
				'series'              => $series,
				'funnel'              => $funnel,
				'top_domains'         => $top,
				'verification_status' => $status,
				'ai_risk'             => $ai_risk,
				'range_label'         => $this->humanise_range( $from, $to ),
				'has_data'            => ( (int) $kpis['signups'] + (int) $kpis['blocked'] + (int) $status['total'] ) > 0,
			)
		);
	}

	/* ----------------------------------------------------------------
	 * Range parsing.
	 * --------------------------------------------------------------*/

	/**
	 * Convert the sanitised range inputs into a [from, to] pair of MySQL
	 * datetime strings (server timezone).
	 *
	 * Pure function of its arguments — does NOT read `$_POST` so PHPCS
	 * has no nonce-verification concern here. The caller (`ajax_data()`)
	 * is responsible for reading + sanitising the inputs immediately
	 * after a successful `check_ajax_referer()`.
	 *
	 * @param string $range_key One of '7d' | '30d' | '90d' | 'custom'.
	 * @param string $from_raw  Y-m-d string when $range_key = 'custom'; ignored otherwise.
	 * @param string $to_raw    Y-m-d string when $range_key = 'custom'; ignored otherwise.
	 * @return array{0:string,1:string}
	 */
	private function resolve_range( $range_key, $from_raw, $to_raw ) {
		$days = 30;
		switch ( $range_key ) {
			case '7d':
				$days = 7;
				break;
			case '30d':
				$days = 30;
				break;
			case '90d':
				$days = 90;
				break;
			case 'custom':
				$from_ts = strtotime( $from_raw );
				$to_ts   = strtotime( $to_raw );
				if ( $from_ts && $to_ts && $to_ts >= $from_ts ) {
					$from = gmdate( 'Y-m-d 00:00:00', $from_ts );
					$to   = gmdate( 'Y-m-d 23:59:59', $to_ts );
					return array( $from, $to );
				}
				$days = 30;
				break;
		}

		$to   = current_time( 'mysql' );
		$from = gmdate( 'Y-m-d 00:00:00', strtotime( $to ) - ( $days - 1 ) * DAY_IN_SECONDS );
		return array( $from, $to );
	}

	/**
	 * Render a date range as "Apr 12 — May 12, 2026" for the UI subtitle.
	 *
	 * @param string $from MySQL datetime.
	 * @param string $to   MySQL datetime.
	 * @return string
	 */
	private function humanise_range( $from, $to ) {
		$from_fmt = date_i18n( 'M j', strtotime( $from ) );
		$to_fmt   = date_i18n( 'M j, Y', strtotime( $to ) );
		return $from_fmt . ' — ' . $to_fmt;
	}

	/* ----------------------------------------------------------------
	 * Aggregations.
	 * --------------------------------------------------------------*/

	/**
	 * Customer-side user query — the FROM/WHERE clause used by every
	 * signup-related count (Signups KPI, Verified KPI, Verification
	 * Status widget, time-series chart).
	 *
	 * Returns a tuple of [SQL fragment, prepared values] that the caller
	 * splices into its own SELECT. The fragment:
	 *
	 *   - LEFT JOINs `customer_email_verified` usermeta so users
	 *     WITHOUT that meta (admin-unverified, imports, etc.) still
	 *     show up — they count as "Unverified".
	 *   - Excludes administrator/editor roles via `wp_capabilities`
	 *     so back-office accounts don't inflate signup numbers.
	 *   - Filters by `user_registered` in the date range.
	 *
	 * @since 2.10.0
	 * @param string $from MySQL datetime.
	 * @param string $to   MySQL datetime.
	 * @return array{0:string,1:array}
	 */
	private function customer_users_sql( $from, $to ) {
		global $wpdb;

		$cap_meta_key = $wpdb->get_blog_prefix() . 'capabilities';

		$sql = "FROM {$wpdb->users} u
			INNER JOIN {$wpdb->usermeta} cap ON cap.user_id = u.ID AND cap.meta_key = %s
			LEFT JOIN {$wpdb->usermeta} um ON um.user_id = u.ID AND um.meta_key = %s
			WHERE u.user_registered BETWEEN %s AND %s
			  AND cap.meta_value NOT LIKE %s
			  AND cap.meta_value NOT LIKE %s";

		$values = array(
			$cap_meta_key,
			'customer_email_verified',
			$from,
			$to,
			'%' . $wpdb->esc_like( '"administrator"' ) . '%',
			'%' . $wpdb->esc_like( '"editor"' ) . '%',
		);

		return array( $sql, $values );
	}
	// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQLPlaceholders.UnquotedComplexPlaceholder,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare,WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber,WordPress.DB.DirectDatabaseQuery.NoCaching,PluginCheck.Security.DirectDB.UnescapedDBParameter
	/**
	 * KPI numbers for one date range.
	 *
	 * Source-of-truth choices (see CLAUDE.md → Data Model):
	 *   - signups    → COUNT(wp_users WHERE user_registered IN range
	 *                  AND NOT admin/editor)  ← LEFT JOIN, includes
	 *                  users w/o the customer_email_verified meta
	 *   - verified   → same, plus customer_email_verified = 'true'
	 *   - blocked    → COUNT(events WHERE event_type LIKE 'blocked_%')
	 *   - avg_secs   → diff between matched otp_sent / otp_verified events
	 *
	 * @param string $from MySQL datetime.
	 * @param string $to   MySQL datetime.
	 * @return array
	 */
	private function kpis_for_range( $from, $to ) {
		global $wpdb;

		list( $user_sql, $user_values ) = $this->customer_users_sql( $from, $to );

		// Signups = ALL customer-side users registered in range.
		$signups = (int) $wpdb->get_var(
			$wpdb->prepare( "SELECT COUNT(DISTINCT u.ID) {$user_sql}", $user_values )
		);

		// Verified = those with meta = 'true'.
		$verified_values = array_merge( $user_values, array( 'true' ) );
		$verified = (int) $wpdb->get_var(
			$wpdb->prepare( "SELECT COUNT(DISTINCT u.ID) {$user_sql} AND um.meta_value = %s", $verified_values )
		);

		// Blocked spam (sum of all blocked_* event types).
		$blocked = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->prefix}cev_verification_events WHERE event_type LIKE %s AND created_at BETWEEN %s AND %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				'blocked_%',
				$from,
				$to
			)
		);

		// Avg time-to-verify, in seconds. For each email that has BOTH
		// otp_sent and otp_verified in the range, take the time difference
		// between the FIRST otp_sent and the FIRST otp_verified.
		$avg_seconds = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT AVG(TIMESTAMPDIFF(SECOND, s.first_sent, v.first_verified))
				FROM (
					SELECT email, MIN(created_at) AS first_sent
					FROM {$wpdb->prefix}cev_verification_events
					WHERE event_type = %s AND created_at BETWEEN %s AND %s
					GROUP BY email
				) s
				INNER JOIN (
					SELECT email, MIN(created_at) AS first_verified
					FROM {$wpdb->prefix}cev_verification_events
					WHERE event_type = %s AND created_at BETWEEN %s AND %s
					GROUP BY email
				) v ON s.email = v.email
				WHERE v.first_verified >= s.first_sent", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				'otp_sent', $from, $to,
				'otp_verified', $from, $to
			)
		);

		$rate = ( $signups > 0 ) ? round( ( $verified * 100 ) / $signups, 1 ) : 0.0;

		return array(
			'signups'       => $signups,
			'verified'      => $verified,
			'verified_rate' => $rate,
			'blocked'       => $blocked,
			'avg_seconds'   => $avg_seconds,
		);
	}

	/**
	 * Time-series — signups vs verified vs blocked, bucketed by an
	 * interval that adapts to the chosen date range:
	 *
	 *   Span ≤ 31 days   → daily buckets    ("May 12")
	 *   Span ≤ 180 days  → weekly buckets   ("May 12")
	 *   Span ≤ 1095 days → monthly buckets  ("May '26")
	 *   Span > 1095 days → yearly buckets   ("2026")
	 *
	 * Without bucketing, a 2-year custom range would render ~730 daily
	 * data points — most of them zero — and look like a flat line. The
	 * bucket size keeps the chart readable across any range.
	 *
	 * Implementation: SQL stays at DATE granularity (uses the existing
	 * `counts_by_date*` helpers), then PHP rolls daily counts into the
	 * chosen bucket. Simpler + portable across MySQL versions.
	 *
	 * @param string $from MySQL datetime.
	 * @param string $to   MySQL datetime.
	 * @return array { bucket, dates, signups, verified, blocked }
	 */
	private function series( $from, $to ) {
		$bucket = $this->pick_bucket( $from, $to );

		// Daily counts (one SQL query per series).
		//
		// Signups + Verified come from wp_users (not the events table)
		// so the chart matches the KPI numbers. Blocked comes from the
		// events table because there's no wp_users equivalent.
		$signups_daily  = $this->users_registered_by_date( $from, $to, false );
		$verified_daily = $this->users_registered_by_date( $from, $to, true );
		$blocked_daily  = $this->counts_by_date_like( 'blocked_%', $from, $to );

		// Roll daily maps up into the chosen bucket.
		$signups_map  = $this->rollup_daily_to_bucket( $signups_daily, $bucket );
		$verified_map = $this->rollup_daily_to_bucket( $verified_daily, $bucket );
		$blocked_map  = $this->rollup_daily_to_bucket( $blocked_daily, $bucket );

		// Build the continuous list of bucket-start timestamps so the
		// chart x-axis has no gaps even on zero-activity buckets.
		$starts = $this->bucket_starts_for_range( $from, $to, $bucket );

		$labels   = array();
		$signups  = array();
		$verified = array();
		$blocked  = array();
		foreach ( $starts as $start_ts ) {
			$key        = $this->bucket_key_for_ts( $bucket, $start_ts );
			$labels[]   = $this->format_bucket_label( $bucket, $start_ts );
			$signups[]  = isset( $signups_map[ $key ] ) ? (int) $signups_map[ $key ] : 0;
			$verified[] = isset( $verified_map[ $key ] ) ? (int) $verified_map[ $key ] : 0;
			$blocked[]  = isset( $blocked_map[ $key ] ) ? (int) $blocked_map[ $key ] : 0;
		}

		return array(
			'bucket'   => $bucket,
			'dates'    => $labels,
			'signups'  => $signups,
			'verified' => $verified,
			'blocked'  => $blocked,
		);
	}

	/**
	 * Choose the bucket size for a date range.
	 *
	 *   ≤ 31 days   → daily   (covers Last 7d + Last 30d presets)
	 *   ≤ 90 days   → weekly  (covers Last 90d preset)
	 *   < 365 days  → monthly (custom ranges between 3 and 12 months)
	 *   ≥ 365 days  → yearly  (custom ranges spanning 1+ year)
	 *
	 * Thresholds keep each bucket count between ~5 and ~30 cells so the
	 * chart stays readable across any range. Bigger ranges roll up to
	 * coarser buckets to avoid a flat line of mostly-zero daily points.
	 *
	 * @param string $from MySQL datetime.
	 * @param string $to   MySQL datetime.
	 * @return string 'day' | 'week' | 'month' | 'year'
	 */
	private function pick_bucket( $from, $to ) {
		$span_seconds = max( 0, strtotime( $to ) - strtotime( $from ) );
		$span_days    = (int) floor( $span_seconds / DAY_IN_SECONDS );

		if ( $span_days <= 31 ) {
			return 'day';
		}
		if ( $span_days <= 90 ) {
			return 'week';
		}
		if ( $span_days < 365 ) {
			return 'month';
		}
		return 'year';
	}

	/**
	 * Roll a daily date→count map into the chosen bucket size.
	 *
	 * @param array  $daily  Map keyed by 'Y-m-d'.
	 * @param string $bucket 'day' | 'week' | 'month' | 'year'.
	 * @return array<string,int> Map keyed by bucket-start 'Y-m-d'.
	 */
	private function rollup_daily_to_bucket( $daily, $bucket ) {
		if ( 'day' === $bucket || empty( $daily ) ) {
			return (array) $daily;
		}
		$out = array();
		foreach ( $daily as $date_str => $count ) {
			$ts = strtotime( $date_str );
			if ( ! $ts ) {
				continue;
			}
			$key = $this->bucket_key_for_ts( $bucket, $ts );
			$out[ $key ] = isset( $out[ $key ] ) ? $out[ $key ] + (int) $count : (int) $count;
		}
		return $out;
	}

	/**
	 * Build the continuous list of bucket-start UNIX timestamps from
	 * `$from` to `$to`, aligned to the bucket boundary.
	 *
	 *   Day:   start of day
	 *   Week:  Monday 00:00
	 *   Month: 1st 00:00
	 *   Year:  Jan 1 00:00
	 *
	 * @param string $from   MySQL datetime.
	 * @param string $to     MySQL datetime.
	 * @param string $bucket 'day' | 'week' | 'month' | 'year'.
	 * @return array<int,int> List of UNIX timestamps.
	 */
	private function bucket_starts_for_range( $from, $to, $bucket ) {
		$start_ts = $this->align_to_bucket_start( $bucket, strtotime( $from ) );
		$end_ts   = strtotime( $to );

		$starts = array();
		$cursor = $start_ts;
		// Hard cap so a misconfigured 100-year range can't run out of memory.
		$cap = 500;
		while ( $cursor <= $end_ts && count( $starts ) < $cap ) {
			$starts[] = $cursor;
			$cursor   = $this->advance_one_bucket( $bucket, $cursor );
		}
		return $starts;
	}

	/**
	 * Snap a timestamp to the start of its containing bucket.
	 *
	 * @param string $bucket 'day' | 'week' | 'month' | 'year'.
	 * @param int    $ts     UNIX timestamp.
	 * @return int UNIX timestamp at bucket start.
	 */
	private function align_to_bucket_start( $bucket, $ts ) {
		switch ( $bucket ) {
			case 'week':
				// ISO week — Monday is day 1.
				$wday    = (int) gmdate( 'N', $ts );
				$day_ts  = strtotime( gmdate( 'Y-m-d', $ts ) );
				return $day_ts - ( $wday - 1 ) * DAY_IN_SECONDS;
			case 'month':
				return strtotime( gmdate( 'Y-m-01', $ts ) );
			case 'year':
				return strtotime( gmdate( 'Y-01-01', $ts ) );
			case 'day':
			default:
				return strtotime( gmdate( 'Y-m-d', $ts ) );
		}
	}

	/**
	 * Advance a bucket-start timestamp by exactly one bucket.
	 *
	 * @param string $bucket 'day' | 'week' | 'month' | 'year'.
	 * @param int    $ts     UNIX timestamp at bucket start.
	 * @return int Next bucket's start timestamp.
	 */
	private function advance_one_bucket( $bucket, $ts ) {
		switch ( $bucket ) {
			case 'week':
				return $ts + 7 * DAY_IN_SECONDS;
			case 'month':
				return strtotime( '+1 month', $ts );
			case 'year':
				return strtotime( '+1 year', $ts );
			case 'day':
			default:
				return $ts + DAY_IN_SECONDS;
		}
	}

	/**
	 * Compute the canonical bucket-key for a timestamp. Two timestamps
	 * in the same bucket produce the same key, so we can group by it.
	 *
	 * @param string $bucket 'day' | 'week' | 'month' | 'year'.
	 * @param int    $ts     UNIX timestamp.
	 * @return string Bucket key.
	 */
	private function bucket_key_for_ts( $bucket, $ts ) {
		$start = $this->align_to_bucket_start( $bucket, $ts );
		switch ( $bucket ) {
			case 'year':
				return gmdate( 'Y', $start );
			case 'month':
				return gmdate( 'Y-m', $start );
			case 'week':
			case 'day':
			default:
				return gmdate( 'Y-m-d', $start );
		}
	}

	/**
	 * Render the human-readable x-axis label for a bucket.
	 *
	 *   Day:   "May 12"
	 *   Week:  "May 12"      (week-of label = Monday date)
	 *   Month: "May '26"
	 *   Year:  "2026"
	 *
	 * @param string $bucket 'day' | 'week' | 'month' | 'year'.
	 * @param int    $ts     Bucket-start UNIX timestamp.
	 * @return string
	 */
	private function format_bucket_label( $bucket, $ts ) {
		switch ( $bucket ) {
			case 'year':
				return date_i18n( 'Y', $ts );
			case 'month':
				return date_i18n( "M 'y", $ts );
			case 'week':
				return date_i18n( 'M j', $ts );
			case 'day':
			default:
				return date_i18n( 'M j', $ts );
		}
	}

	/**
	 * Helper: COUNT(*) grouped by DATE(created_at) for a fixed
	 * event_type within a date range.
	 *
	 * @param string $event_type Event type slug.
	 * @param string $from       MySQL datetime.
	 * @param string $to         MySQL datetime.
	 * @return array<string,int> [Y-m-d => count]
	 */
	private function counts_by_date( $event_type, $from, $to ) {
		global $wpdb;
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT DATE(created_at) AS d, COUNT(*) AS c FROM {$wpdb->prefix}cev_verification_events
				WHERE event_type = %s AND created_at BETWEEN %s AND %s
				GROUP BY DATE(created_at)", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$event_type,
				$from,
				$to
			),
			ARRAY_A
		);
		$out = array();
		foreach ( (array) $rows as $r ) {
			$out[ $r['d'] ] = (int) $r['c'];
		}
		return $out;
	}

	/**
	 * Same as counts_by_date but with an event_type LIKE pattern (e.g.
	 * "blocked_%" to roll up every block reason into a single series).
	 *
	 * @param string $pattern LIKE pattern.
	 * @param string $from    MySQL datetime.
	 * @param string $to      MySQL datetime.
	 * @return array<string,int>
	 */
	private function counts_by_date_like( $pattern, $from, $to ) {
		global $wpdb;
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT DATE(created_at) AS d, COUNT(*) AS c FROM {$wpdb->prefix}cev_verification_events
				WHERE event_type LIKE %s AND created_at BETWEEN %s AND %s
				GROUP BY DATE(created_at)", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$pattern,
				$from,
				$to
			),
			ARRAY_A
		);
		$out = array();
		foreach ( (array) $rows as $r ) {
			$out[ $r['d'] ] = (int) $r['c'];
		}
		return $out;
	}

	/**
	 * COUNT(*) of wp_users grouped by DATE(user_registered) for the
	 * range, optionally filtered to verified users only.
	 *
	 * Restricted to users that have the `customer_email_verified` meta
	 * (i.e. users the plugin has touched) so admin-only accounts don't
	 * skew the signup chart.
	 *
	 * @param string $from         MySQL datetime.
	 * @param string $to           MySQL datetime.
	 * @param bool   $only_verified Filter to meta_value='true'?
	 * @return array<string,int> [Y-m-d => count]
	 */
	private function users_registered_by_date( $from, $to, $only_verified ) {
		global $wpdb;

		list( $user_sql, $user_values ) = $this->customer_users_sql( $from, $to );

		if ( $only_verified ) {
			$user_values[] = 'true';
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT DATE(u.user_registered) AS d, COUNT(DISTINCT u.ID) AS c
					 {$user_sql}
					 AND um.meta_value = %s
					 GROUP BY DATE(u.user_registered)",
					$user_values
				),
				ARRAY_A
			);
		} else {
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT DATE(u.user_registered) AS d, COUNT(DISTINCT u.ID) AS c
					 {$user_sql}
					 GROUP BY DATE(u.user_registered)",
					$user_values
				),
				ARRAY_A
			);
		}

		$out = array();
		foreach ( (array) $rows as $r ) {
			$out[ $r['d'] ] = (int) $r['c'];
		}
		return $out;
	}

	/**
	 * Funnel — drop-off from OTP-sent to OTP-verified.
	 *
	 * IMPORTANT: This is the only place where ABANDONED signup attempts
	 * (rows in `cev_user_log` with no matching `wp_users` entry) DO get
	 * counted. The funnel is intentionally event-based — its whole job
	 * is to surface the drop-off, which only makes sense if you include
	 * the people who got an OTP but never verified.
	 *
	 * Contrast with the Signups KPI, which reads from `wp_users` and
	 * deliberately excludes those abandoned attempts.
	 *
	 * @param string $from MySQL datetime.
	 * @param string $to   MySQL datetime.
	 * @return array
	 */
	private function funnel( $from, $to ) {
		global $wpdb;

		$sent = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->prefix}cev_verification_events WHERE event_type = %s AND created_at BETWEEN %s AND %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				'otp_sent',
				$from,
				$to
			)
		);

		$verified = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->prefix}cev_verification_events WHERE event_type = %s AND created_at BETWEEN %s AND %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				'otp_verified',
				$from,
				$to
			)
		);

		// Clamp so the funnel never goes UP (can happen across boundaries).
		$verified_clamped = min( $verified, $sent );

		$step1 = array(
			'label' => __( 'Verification email sent', 'customer-email-verification' ),
			'count' => $sent,
			'pct'   => 100,
		);
		$step2 = array(
			'label' => __( 'Code verified', 'customer-email-verification' ),
			'count' => $verified_clamped,
			'pct'   => ( $sent > 0 ) ? round( ( $verified_clamped * 100 ) / $sent, 1 ) : 0.0,
		);

		return array( $step1, $step2 );
	}

	/**
	 * Verification status — Verified vs Pending Paid Order vs Unverified
	 * breakdown of users registered in the selected date range.
	 *
	 *   Verified           = wp_users WHERE meta = 'true'
	 *   Pending Paid Order = wp_users WHERE meta = 'pending_paid_order'
	 *                        (Paid-Order Gatekeeping — verified email, no
	 *                        paid order yet)
	 *   Unverified         = wp_users WHERE meta is neither of the above
	 *                        (i.e. 'false', missing, or empty)
	 *
	 * Same data source as the Signups KPI (wp_users joined with the
	 * `customer_email_verified` meta), so the totals reconcile cleanly:
	 *
	 *   Signups KPI  =  verification_status.total
	 *
	 * The Pending Paid Order bucket is always returned but is only zero when
	 * the gatekeeping feature is off, so the widget transparently falls back
	 * to a two-bucket display.
	 *
	 * @param string $from MySQL datetime.
	 * @param string $to   MySQL datetime.
	 * @return array { verified, pending_paid_order, unverified, total }
	 */
	private function verification_status( $from, $to ) {
		global $wpdb;

		list( $user_sql, $user_values ) = $this->customer_users_sql( $from, $to );

		// Literals prepended for the CASE WHEN comparisons, in placeholder
		// order: verified='true', pending='pending_paid_order', then both
		// again for the "neither" unverified clause.
		$values = array_merge(
			array( 'true', 'pending_paid_order', 'true', 'pending_paid_order' ),
			$user_values
		);

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT
					SUM( CASE WHEN um.meta_value = %s THEN 1 ELSE 0 END ) AS verified,
					SUM( CASE WHEN um.meta_value = %s THEN 1 ELSE 0 END ) AS pending_paid_order,
					SUM( CASE WHEN um.meta_value IS NULL OR ( um.meta_value <> %s AND um.meta_value <> %s ) THEN 1 ELSE 0 END ) AS unverified
				 {$user_sql}",
				$values
			),
			ARRAY_A
		);

		$verified   = ( isset( $rows[0]['verified'] ) ) ? (int) $rows[0]['verified'] : 0;
		$pending    = ( isset( $rows[0]['pending_paid_order'] ) ) ? (int) $rows[0]['pending_paid_order'] : 0;
		$unverified = ( isset( $rows[0]['unverified'] ) ) ? (int) $rows[0]['unverified'] : 0;

		return array(
			'verified'           => $verified,
			'pending_paid_order' => $pending,
			'unverified'         => $unverified,
			'total'              => $verified + $pending + $unverified,
		);
	}

	/**
	 * Top blocked domains across all `blocked_*` event types.
	 *
	 * Pulls the domain off each event's `extra` JSON (the validator
	 * stores `{"domain":"mailinator.com"}` when blocking). Falls back
	 * to extracting from the email column if the JSON is missing.
	 *
	 * @param string $from   MySQL datetime.
	 * @param string $to     MySQL datetime.
	 * @param int    $limit  Max rows to return.
	 * @return array<int,array{domain:string,count:int}>
	 */
	private function top_blocked_domains( $from, $to, $limit = 10 ) {
		global $wpdb;
		$limit = max( 1, min( 100, (int) $limit ) );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT email, extra FROM {$wpdb->prefix}cev_verification_events
				WHERE event_type LIKE %s AND created_at BETWEEN %s AND %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				'blocked_%',
				$from,
				$to
			),
			ARRAY_A
		);

		$counts = array();
		foreach ( (array) $rows as $r ) {
			$domain = '';
			if ( ! empty( $r['extra'] ) ) {
				$decoded = json_decode( $r['extra'], true );
				if ( is_array( $decoded ) && ! empty( $decoded['domain'] ) ) {
					$domain = strtolower( (string) $decoded['domain'] );
				}
			}
			if ( '' === $domain && ! empty( $r['email'] ) ) {
				$at = strpos( $r['email'], '@' );
				if ( false !== $at ) {
					$domain = strtolower( substr( $r['email'], $at + 1 ) );
				}
			}
			if ( '' === $domain ) {
				continue;
			}
			$counts[ $domain ] = isset( $counts[ $domain ] ) ? $counts[ $domain ] + 1 : 1;
		}

		arsort( $counts );
		$top = array();
		$i = 0;
		foreach ( $counts as $domain => $count ) {
			if ( $i++ >= $limit ) {
				break;
			}
			$top[] = array(
				'domain' => $domain,
				'count'  => (int) $count,
			);
		}
		return $top;
	}

	/**
	 * AI risk-scoring summary for the range: average score, how many signups
	 * were scored, how many the AI blocked, and the top contributing reasons.
	 *
	 * Reads the `signup_risk_scored` events' `extra` JSON ({score, action,
	 * reasons}) plus the `blocked_ai_risk` block count.
	 *
	 * @param string $from MySQL datetime.
	 * @param string $to   MySQL datetime.
	 * @return array { avg_score:float, scored:int, blocked:int, top_reasons:array }
	 */
	private function ai_risk_summary( $from, $to ) {
		global $wpdb;

		$blocked = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->prefix}cev_verification_events WHERE event_type = %s AND created_at BETWEEN %s AND %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				'blocked_ai_risk',
				$from,
				$to
			)
		);

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT extra FROM {$wpdb->prefix}cev_verification_events WHERE event_type = %s AND created_at BETWEEN %s AND %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				'signup_risk_scored',
				$from,
				$to
			),
			ARRAY_A
		);

		$score_sum     = 0;
		$scored        = 0;
		$reason_counts = array();
		foreach ( (array) $rows as $r ) {
			if ( empty( $r['extra'] ) ) {
				continue;
			}
			$decoded = json_decode( $r['extra'], true );
			if ( ! is_array( $decoded ) ) {
				continue;
			}
			++$scored;
			$score_sum += isset( $decoded['score'] ) ? (int) $decoded['score'] : 0;
			if ( ! empty( $decoded['reasons'] ) && is_array( $decoded['reasons'] ) ) {
				foreach ( $decoded['reasons'] as $reason ) {
					$reason                   = (string) $reason;
					$reason_counts[ $reason ] = isset( $reason_counts[ $reason ] ) ? $reason_counts[ $reason ] + 1 : 1;
				}
			}
		}

		$avg_score = ( $scored > 0 ) ? round( $score_sum / $scored, 1 ) : 0.0;

		arsort( $reason_counts );
		$labels      = $this->risk_reason_labels();
		$top_reasons = array();
		$count       = 0;
		foreach ( $reason_counts as $key => $n ) {
			if ( $count >= 5 ) {
				break;
			}
			$top_reasons[] = array(
				'key'   => $key,
				'label' => isset( $labels[ $key ] ) ? $labels[ $key ] : $key,
				'count' => (int) $n,
			);
			++$count;
		}

		return array(
			'avg_score'   => (float) $avg_score,
			'scored'      => (int) $scored,
			'blocked'     => (int) $blocked,
			'top_reasons' => $top_reasons,
		);
	}

	/**
	 * Human-readable labels for the risk-reason keys.
	 *
	 * @return array
	 */
	private function risk_reason_labels() {
		return array(
			'gibberish_local'   => __( 'Random-looking mailbox', 'customer-email-verification' ),
			'suspicious_domain' => __( 'Unusual domain', 'customer-email-verification' ),
			'address_shape'     => __( 'Role / plus address', 'customer-email-verification' ),
			'signup_velocity'   => __( 'Many signups from one IP', 'customer-email-verification' ),
		);
	}
}
