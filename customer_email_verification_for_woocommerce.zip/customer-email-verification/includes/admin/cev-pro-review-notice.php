<?php
/**
 * Plugin Review Notice for Customer Email Verification
 *
 * Shows a branded "leave us a review" call-out in wp-admin using the shared
 * Zorem UI plugin-notice component (`.zui-pnotice`). It appears on admin pages
 * other than the plugin's own screens and is dismissed with a single click
 * (a nonce-protected link + redirect, the same pattern as the other admin
 * notice) — no grace period, no snooze.
 *
 * @package Customer_Email_Verification
 * @since 3.0.2
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'CEV_Pro_Review_Notice' ) ) {

	/**
	 * CEV_Pro_Review_Notice Class
	 *
	 * Renders the plugin-review request notice and handles its dismissal.
	 */
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
	class CEV_Pro_Review_Notice {

		/**
		 * Singleton instance.
		 *
		 * @var CEV_Pro_Review_Notice
		 */
		private static $instance;

		/**
		 * Direct link to the plugin review form.
		 *
		 * @var string
		 */
		const REVIEW_URL = 'https://woocommerce.com/products/customer-email-verification/';

		/**
		 * Brand-registry slug used to resolve the emblem icon (build-specific).
		 *
		 * @var string
		 */
		const BRAND_SLUG = 'customer-email-verification/customer-email-verification.php';

		/**
		 * The plugin's own settings + customizer page slugs — the notice is
		 * suppressed on these so it never clashes with the custom ZUI layout.
		 *
		 * @var string[]
		 */
		const OWN_PAGES = array( 'customer-email-verification-for-woocommerce', 'cev_customizer' );

		/**
		 * Option flag set once the notice has been dismissed.
		 *
		 * @var string
		 */
		const DISMISS_OPTION = 'cev_review_notice_dismissed';

		/**
		 * URL query parameter that triggers dismissal.
		 *
		 * @var string
		 */
		const DISMISS_QUERY_PARAM = 'cev_review_notice_dismiss';

		/**
		 * Constructor.
		 *
		 * @since 3.0.2
		 */
		public function __construct() {
			$this->init();
		}

		/**
		 * Get the singleton instance.
		 *
		 * @since 3.0.2
		 * @return CEV_Pro_Review_Notice
		 */
		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Register hooks.
		 *
		 * @since 3.0.2
		 * @return void
		 */
		public function init() {
			add_action( 'admin_notices', array( $this, 'render' ) );
			add_action( 'admin_init', array( $this, 'maybe_dismiss' ) );
		}

		/**
		 * Whether the review notice should be shown on the current request.
		 *
		 * @since 3.0.2
		 * @return bool
		 */
		public function should_display() {
			if ( ! current_user_can( 'manage_options' ) ) {
				return false;
			}

			// Never on the plugin's own (custom-layout) admin screens.
			if ( $this->is_own_admin_page() ) {
				return false;
			}

			return 'true' !== (string) get_option( self::DISMISS_OPTION, '' );
		}

		/**
		 * Whether the current screen is one of the plugin's own admin pages.
		 *
		 * @since 3.0.2
		 * @return bool
		 */
		private function is_own_admin_page() {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Read-only screen check; no state change.
			$cev_page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';
			return in_array( $cev_page, self::OWN_PAGES, true );
		}

		/**
		 * Build the nonce-protected dismiss URL for the current page.
		 *
		 * @since 3.0.2
		 * @return string Raw URL (escape at output).
		 */
		private function get_dismiss_url() {
			return wp_nonce_url(
				add_query_arg( self::DISMISS_QUERY_PARAM, 'true' ),
				self::DISMISS_QUERY_PARAM,
				'_cev_review_nonce'
			);
		}

		/**
		 * Handle the dismiss click: verify the nonce, store the flag, then
		 * redirect back to the same page without the query args.
		 *
		 * @since 3.0.2
		 * @return void
		 */
		public function maybe_dismiss() {
			$nonce = isset( $_GET['_cev_review_nonce'] ) ? sanitize_text_field( wp_unslash( $_GET['_cev_review_nonce'] ) ) : '';
			if ( '' === $nonce || ! wp_verify_nonce( $nonce, self::DISMISS_QUERY_PARAM ) ) {
				return;
			}

			$value = isset( $_GET[ self::DISMISS_QUERY_PARAM ] ) ? sanitize_text_field( wp_unslash( $_GET[ self::DISMISS_QUERY_PARAM ] ) ) : '';
			if ( 'true' !== $value ) {
				return;
			}

			update_option( self::DISMISS_OPTION, 'true' );

			wp_safe_redirect( remove_query_arg( array( self::DISMISS_QUERY_PARAM, '_cev_review_nonce' ) ) );
			exit;
		}

		/**
		 * Render the review notice markup (ZUI plugin-notice component).
		 *
		 * @since 3.0.2
		 * @return void
		 */
		public function render() {
			if ( ! $this->should_display() ) {
				return;
			}

			// Resolve the emblem icon from the shared brand registry, mirroring
			// the page header (same icon + blue emblem the header uses).
			require_once cev_pro()->get_plugin_path() . '/assets/zui/brand.php';
			require_once cev_pro()->get_plugin_path() . '/assets/zui/icons.php';
			$brand        = \Zorem\UI\get_plugin_brand( self::BRAND_SLUG );
			$icon_key     = ( is_array( $brand ) && ! empty( $brand['icon'] ) ) ? $brand['icon'] : 'shield-check';
			$emblem_bg    = '#DBEAFE';
			$emblem_color = '#2563EB';
			$dismiss_url  = $this->get_dismiss_url();
			?>
			<div class="zui-pnotice cev-review-pnotice" role="status">
				<span class="zui-pnotice__avatar" aria-hidden="true"
					style="--zui-pnotice-avatar-bg:<?php echo esc_attr( $emblem_bg ); ?>;--zui-pnotice-avatar-color:<?php echo esc_attr( $emblem_color ); ?>;">
					<?php \Zorem\UI\icon( $icon_key ); ?>
				</span>
				<div class="zui-pnotice__body">
					<strong class="zui-pnotice__title">
						<?php esc_html_e( 'Enjoying Customer Email Verification?', 'customer-email-verification' ); ?>
					</strong>
					<p class="zui-pnotice__text">
						<?php
						printf(
							/* translators: %s: five gold stars. */
							esc_html__( 'If Customer Email Verification is helping keep the spam away, a quick %s review would mean a lot — it helps other stores discover the plugin.', 'customer-email-verification' ),
							'<span style="color:#f59e0b;letter-spacing:1px;" aria-hidden="true">&#9733;&#9733;&#9733;&#9733;&#9733;</span>'
						);
						?>
					</p>
					<div class="zui-pnotice__actions">
						<a class="zui-pnotice__btn" href="<?php echo esc_url( self::REVIEW_URL ); ?>" target="_blank" rel="noopener noreferrer">
							<?php esc_html_e( 'Leave a review', 'customer-email-verification' ); ?>
						</a>
						<a class="zui-pnotice__link" href="<?php echo esc_url( $dismiss_url ); ?>">
							<?php esc_html_e( 'No, thanks', 'customer-email-verification' ); ?>
						</a>
					</div>
				</div>
				<a class="zui-pnotice__close" href="<?php echo esc_url( $dismiss_url ); ?>" style="text-decoration:none;" aria-label="<?php esc_attr_e( 'Dismiss', 'customer-email-verification' ); ?>">&times;</a>
			</div>
			<?php
		}
	}
}
