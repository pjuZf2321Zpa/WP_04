<?php
/**
 * Setup checklist shown at the top of the Settings tab.
 *
 * The shared steps (turn on signup verification, send a test email,
 * customize the email, check the Unverified Users list) use the same
 * wording as the free plugin; PRO adds checkout verification and spam
 * protection. The card hides itself once every step is done or the store
 * manager hides it.
 *
 * Contains no license logic, so it ships unchanged in both builds.
 *
 * @package Customer_Email_Verification_Pro
 * @since 3.0.5
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
class CEV_Pro_Setup_Checklist {

	/**
	 * Admin page slug.
	 */
	const PAGE_SLUG = 'customer-email-verification-for-woocommerce';

	/**
	 * Nonce action for the checklist AJAX calls.
	 */
	const NONCE_ACTION = 'cev_setup_checklist';

	/**
	 * Instance of this class.
	 *
	 * @var CEV_Pro_Setup_Checklist
	 */
	private static $instance;

	/**
	 * Get the class instance.
	 *
	 * @return CEV_Pro_Setup_Checklist
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->init();
		}
		return self::$instance;
	}

	/**
	 * Register hooks.
	 */
	private function init() {
		add_action( 'wp_ajax_cev_send_test_email', array( $this, 'ajax_send_test_email' ) );
		add_action( 'wp_ajax_cev_dismiss_checklist', array( $this, 'ajax_dismiss' ) );
		add_action( 'admin_init', array( $this, 'maybe_mark_users_viewed' ) );
		add_action( 'update_option_cev_pro_customizer', array( $this, 'mark_email_customized' ) );
	}

	/**
	 * Steps and whether each is done.
	 *
	 * @return array
	 */
	public function get_steps() {
		$settings = cev_pro()->function;
		return array(
			'enable'    => array(
				'label' => __( 'Turn on signup verification', 'customer-email-verification' ),
				'done'  => 1 === (int) $settings->cev_pro_admin_settings( 'cev_enable_email_verification', 1 ),
				'hint'  => __( 'Use the switch in Signup Verification, then save.', 'customer-email-verification' ),
			),
			'test'      => array(
				'label' => __( 'Send yourself a test verification email', 'customer-email-verification' ),
				'done'  => (bool) get_option( 'cev_checklist_test_email_sent' ),
			),
			'customize' => array(
				'label' => __( 'Customize the verification email and popup', 'customer-email-verification' ),
				'done'  => (bool) get_option( 'cev_checklist_email_customized' ),
				'url'   => admin_url( 'admin.php?page=cev_customizer&preview=email_registration' ),
			),
			'checkout'  => array(
				'label' => __( 'Turn on checkout verification', 'customer-email-verification' ),
				'done'  => 1 === (int) $settings->cev_pro_admin_settings( 'cev_enable_email_verification_checkout', 0 ),
				'url'   => admin_url( 'admin.php?page=' . self::PAGE_SLUG . '&tab=email-verification&section=checkout_verification' ),
			),
			'spam'      => array(
				'label' => __( 'Turn on disposable email blocking in Spam Protection', 'customer-email-verification' ),
				'done'  => 1 === (int) $settings->cev_pro_admin_settings( 'cev_block_disposable_emails', 0 ),
				'url'   => admin_url( 'admin.php?page=' . self::PAGE_SLUG . '&tab=email-verification&section=spam_protection' ),
			),
			'users'     => array(
				'label' => __( 'Check the Unverified Users list', 'customer-email-verification' ),
				'done'  => (bool) get_option( 'cev_checklist_users_viewed' ),
				'url'   => admin_url( 'admin.php?page=' . self::PAGE_SLUG . '&tab=unverified-users' ),
			),
		);
	}

	/**
	 * Whether the checklist should render.
	 *
	 * @return bool
	 */
	public function should_show() {
		if ( get_option( 'cev_checklist_dismissed' ) || ! current_user_can( 'manage_woocommerce' ) ) {
			return false;
		}
		$steps = $this->get_steps();
		return count( array_filter( wp_list_pluck( $steps, 'done' ) ) ) < count( $steps );
	}

	/**
	 * Output the checklist card (library card + row components, no new styling).
	 */
	public function render() {
		if ( ! $this->should_show() ) {
			return;
		}
		$steps = $this->get_steps();
		$done  = count( array_filter( wp_list_pluck( $steps, 'done' ) ) );
		?>
		<div class="zui-card cev-setup-checklist" id="cev-setup-checklist">
			<div class="zui-card__head">
				<h3 class="zui-card__title"><?php esc_html_e( 'Get started with email verification', 'customer-email-verification' ); ?></h3>
				<p class="zui-card__sub">
					<?php
					/* translators: 1: number of completed steps, 2: total number of steps. */
					$progress = sprintf( __( '%1$d of %2$d steps done', 'customer-email-verification' ), $done, count( $steps ) );
					echo esc_html( $progress );
					?>
				</p>
			</div>
			<?php foreach ( $steps as $key => $step ) : ?>
				<div class="zui-row zui-row--inline">
					<div class="zui-row__head">
						<span class="zui-row__label"><?php echo esc_html( $step['label'] ); ?></span>
					</div>
					<div class="zui-row__control">
						<?php if ( $step['done'] ) : ?>
							<span class="zui-badge zui-badge--success cev-setup-checklist__done">&#10003; <?php esc_html_e( 'Done', 'customer-email-verification' ); ?></span>
						<?php elseif ( 'test' === $key ) : ?>
							<button type="button" class="zui-btn-soft cev-send-test-email"><?php esc_html_e( 'Send test email', 'customer-email-verification' ); ?></button>
						<?php elseif ( isset( $step['hint'] ) ) : ?>
							<span class="zui-row__desc"><?php echo esc_html( $step['hint'] ); ?></span>
						<?php else : ?>
							<a class="zui-btn-soft" href="<?php echo esc_url( $step['url'] ); ?>"><?php esc_html_e( 'Open', 'customer-email-verification' ); ?></a>
						<?php endif; ?>
					</div>
				</div>
			<?php endforeach; ?>
			<div class="zui-row">
				<button type="button" class="zui-btn-ghost cev-dismiss-checklist"><?php esc_html_e( 'Hide checklist', 'customer-email-verification' ); ?></button>
			</div>
		</div>
		<?php
	}

	/**
	 * Data for admin.js.
	 *
	 * @return array
	 */
	public function get_script_data() {
		return array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( self::NONCE_ACTION ),
			'i18n'     => array(
				'sending'        => __( 'Sending…', 'customer-email-verification' ),
				'request_failed' => __( 'Something went wrong. Please try again.', 'customer-email-verification' ),
			),
		);
	}

	/**
	 * AJAX: send a test verification email to the current admin.
	 */
	public function ajax_send_test_email() {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'You are not allowed to do this.', 'customer-email-verification' ) ), 403 );
		}

		$to     = wp_get_current_user()->user_email;
		$sender = new CEV_Signup_Email();
		$sent   = is_email( $to ) && $sender->send_test_email( $to );

		if ( ! $sent ) {
			wp_send_json_error( array( 'message' => __( 'The test email could not be sent. Check your store email settings.', 'customer-email-verification' ) ) );
		}

		update_option( 'cev_checklist_test_email_sent', 1, false );

		/* translators: %s: admin email address the test was sent to. */
		$message = sprintf( __( 'Test email sent to %s.', 'customer-email-verification' ), $to );
		wp_send_json_success( array( 'message' => $message ) );
	}

	/**
	 * AJAX: hide the checklist for good.
	 */
	public function ajax_dismiss() {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array(), 403 );
		}
		update_option( 'cev_checklist_dismissed', 1, false );
		wp_send_json_success();
	}

	/**
	 * Opening the Unverified Users tab completes that step.
	 */
	public function maybe_mark_users_viewed() {
		if ( get_option( 'cev_checklist_users_viewed' ) ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Read-only screen check; only records that the tab was viewed.
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Read-only screen check; only records that the tab was viewed.
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : '';

		if ( self::PAGE_SLUG === $page && 'unverified-users' === $tab ) {
			update_option( 'cev_checklist_users_viewed', 1, false );
		}
	}

	/**
	 * A customizer save completes the "Customize" step.
	 *
	 * Only saves made from the customizer (an AJAX or REST request by a store
	 * manager) count; option migrations during plugin updates do not.
	 */
	public function mark_email_customized() {
		$is_request = wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST );
		if ( $is_request && current_user_can( 'manage_woocommerce' ) ) {
			update_option( 'cev_checklist_email_customized', 1, false );
		}
	}
}
