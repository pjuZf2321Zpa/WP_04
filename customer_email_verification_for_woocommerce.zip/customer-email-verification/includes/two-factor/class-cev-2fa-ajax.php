<?php
/**
 * 2FA AJAX endpoints.
 *
 * Handles the user-side enrollment flow plus admin overrides:
 *   - cev_2fa_start_setup       : generate pending secret + return otpauth:// URI
 *   - cev_2fa_complete_setup    : verify first code, persist enrollment, return recovery codes
 *   - cev_2fa_disable           : user disables their own 2FA
 *   - cev_2fa_regenerate_codes  : user generates a new set of recovery codes
 *   - cev_2fa_admin_reset       : ADMIN-only — wipe a user's 2FA enrollment
 *
 * All endpoints require the logged-in user (no nopriv variants) and a
 * valid nonce. Admin-only actions also gate on `manage_woocommerce`.
 *
 * @package Customer_Email_Verification_Pro
 * @since   2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * CEV_2FA_Ajax — singleton.
 */
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
class CEV_2FA_Ajax {

	const NONCE_USER  = 'cev_2fa_user_nonce';
	const NONCE_ADMIN = 'cev_2fa_admin_nonce';

	/**
	 * Singleton.
	 *
	 * @var CEV_2FA_Ajax|null
	 */
	private static $instance = null;

	/**
	 * Get singleton.
	 *
	 * @return CEV_2FA_Ajax
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor — wires the AJAX hooks.
	 */
	public function __construct() {
		add_action( 'wp_ajax_cev_2fa_start_setup', array( $this, 'start_setup' ) );
		add_action( 'wp_ajax_cev_2fa_complete_setup', array( $this, 'complete_setup' ) );
		add_action( 'wp_ajax_cev_2fa_disable', array( $this, 'disable' ) );
		add_action( 'wp_ajax_cev_2fa_regenerate_codes', array( $this, 'regenerate_codes' ) );
		add_action( 'wp_ajax_cev_2fa_admin_reset', array( $this, 'admin_reset' ) );
	}

	/* ----------------------------------------------------------------
	 * User endpoints.
	 * --------------------------------------------------------------*/

	/**
	 * Start enrollment — creates a fresh pending secret, returns the
	 * otpauth:// URI for the QR + a short manual-entry display string.
	 *
	 * @return void Sends JSON.
	 */
	public function start_setup() {
		if ( ! check_ajax_referer( self::NONCE_USER, 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', 'customer-email-verification' ) ), 403 );
		}

		$user_id = get_current_user_id();
		if ( $user_id <= 0 ) {
			wp_send_json_error( array( 'message' => __( 'You must be logged in.', 'customer-email-verification' ) ), 401 );
		}

		// Block re-setup if already enrolled — caller should disable first.
		$mgr = CEV_2FA_Manager::instance();
		if ( $mgr->is_enrolled( $user_id ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Two-factor authentication is already enabled. Disable it first to set up a new device.', 'customer-email-verification' ),
				),
				400
			);
		}

		$user   = get_userdata( $user_id );
		$issuer = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		if ( '' === trim( $issuer ) ) {
			$issuer = wp_parse_url( home_url(), PHP_URL_HOST );
		}

		$secret = $mgr->start_setup( $user_id );
		$uri    = CEV_TOTP::provisioning_uri( $secret, $user->user_email, $issuer );

		// Format the secret with spaces every 4 chars for human entry —
		// authenticator apps strip whitespace automatically when typed.
		$display_secret = trim( chunk_split( $secret, 4, ' ' ) );

		// QR rendering happens CLIENT-SIDE via the jquery.qrcode library
		// (vendored from Wordfence — Jérôme Etienne's plugin, 15+ years
		// in production, MIT). We just hand the otpauth:// URI to the
		// JS, which calls `$(el).qrcode({ text: uri, ... })`. No server-
		// side QR generation needed.
		wp_send_json_success(
			array(
				'otpauth_uri'    => $uri,
				'manual_secret'  => $display_secret,
				'account_label'  => $user->user_email,
				'issuer_label'   => $issuer,
			)
		);
	}

	/**
	 * Verify the first code typed by the user. On success, completes
	 * enrollment and returns the 10 plaintext recovery codes.
	 *
	 * @return void Sends JSON.
	 */
	public function complete_setup() {
		if ( ! check_ajax_referer( self::NONCE_USER, 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', 'customer-email-verification' ) ), 403 );
		}

		$user_id = get_current_user_id();
		if ( $user_id <= 0 ) {
			wp_send_json_error( array( 'message' => __( 'You must be logged in.', 'customer-email-verification' ) ), 401 );
		}

		$code = isset( $_POST['code'] ) ? sanitize_text_field( wp_unslash( $_POST['code'] ) ) : '';

		$result = CEV_2FA_Manager::instance()->complete_setup( $user_id, $code );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error(
				array(
					'message' => $result->get_error_message(),
					'code'    => $result->get_error_code(),
				),
				400
			);
		}

		wp_send_json_success(
			array(
				'message'        => __( 'Two-factor authentication is now active. Save the recovery codes below — they\'re your only way back in if you lose your phone.', 'customer-email-verification' ),
				'recovery_codes' => $result['recovery_codes'],
			)
		);
	}

	/**
	 * User disables their own 2FA.
	 *
	 * Note: a user who is required by the role policy to have 2FA can
	 * still disable here — they will be re-prompted to set it up on the
	 * next login (subject to grace period). We intentionally don't block
	 * this so a user who's lost their phone can re-enrol with a new one.
	 *
	 * @return void Sends JSON.
	 */
	public function disable() {
		if ( ! check_ajax_referer( self::NONCE_USER, 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', 'customer-email-verification' ) ), 403 );
		}

		$user_id = get_current_user_id();
		if ( $user_id <= 0 ) {
			wp_send_json_error( array( 'message' => __( 'You must be logged in.', 'customer-email-verification' ) ), 401 );
		}

		CEV_2FA_Manager::instance()->disable( $user_id );

		wp_send_json_success(
			array(
				'message' => __( 'Two-factor authentication has been turned off for your account.', 'customer-email-verification' ),
			)
		);
	}

	/**
	 * Regenerate the 10 recovery codes — replaces the old set entirely.
	 *
	 * @return void Sends JSON.
	 */
	public function regenerate_codes() {
		if ( ! check_ajax_referer( self::NONCE_USER, 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', 'customer-email-verification' ) ), 403 );
		}

		$user_id = get_current_user_id();
		if ( $user_id <= 0 ) {
			wp_send_json_error( array( 'message' => __( 'You must be logged in.', 'customer-email-verification' ) ), 401 );
		}

		$result = CEV_2FA_Manager::instance()->regenerate_recovery_codes( $user_id );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error(
				array(
					'message' => $result->get_error_message(),
					'code'    => $result->get_error_code(),
				),
				400
			);
		}

		wp_send_json_success(
			array(
				'message'        => __( 'New recovery codes generated. The old codes will no longer work.', 'customer-email-verification' ),
				'recovery_codes' => $result,
			)
		);
	}

	/* ----------------------------------------------------------------
	 * Admin-only endpoint.
	 * --------------------------------------------------------------*/

	/**
	 * Admin "Reset 2FA" button — wipes a user's enrollment so they can
	 * log in with just their password and re-enrol from scratch. Used
	 * when a user lost their phone AND ran out of recovery codes.
	 *
	 * @return void Sends JSON.
	 */
	public function admin_reset() {
		if ( ! check_ajax_referer( self::NONCE_ADMIN, 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', 'customer-email-verification' ) ), 403 );
		}

		if ( ! current_user_can( 'edit_users' ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'You don\'t have permission to reset other users\' 2FA.', 'customer-email-verification' ),
				),
				403
			);
		}

		$target_user_id = isset( $_POST['user_id'] ) ? absint( wp_unslash( $_POST['user_id'] ) ) : 0;
		if ( $target_user_id <= 0 ) {
			wp_send_json_error( array( 'message' => __( 'Invalid user.', 'customer-email-verification' ) ), 400 );
		}

		// Even with edit_users, refuse to reset a user the current admin
		// can't otherwise edit (multisite super-admin scoping etc.).
		if ( ! current_user_can( 'edit_user', $target_user_id ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'You don\'t have permission to edit this user.', 'customer-email-verification' ),
				),
				403
			);
		}

		CEV_2FA_Manager::instance()->disable( $target_user_id );

		wp_send_json_success(
			array(
				'message' => __( 'The user\'s two-factor authentication has been reset. They can log in with their password and re-enrol.', 'customer-email-verification' ),
			)
		);
	}
}
