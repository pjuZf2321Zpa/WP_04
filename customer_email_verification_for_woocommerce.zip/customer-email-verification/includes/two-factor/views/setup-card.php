<?php
/**
 * Authenticator-App 2FA setup card.
 *
 * Rendered both inside the WooCommerce "My Account" tab and the wp-admin
 * Users → Profile screen. The HTML/CSS is identical so we keep one
 * template; the wrapping page just supplies its own headings around it.
 *
 * Expected variables:
 *   $cev_2fa_enrolled  bool — has the current user finished setup?
 *   $cev_2fa_remaining int  — recovery codes left.
 *
 * @package Customer_Email_Verification_Pro
 * @since   2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

$cev_2fa_enrolled  = isset( $cev_2fa_enrolled ) ? (bool) $cev_2fa_enrolled : false;
$cev_2fa_remaining = isset( $cev_2fa_remaining ) ? (int) $cev_2fa_remaining : 0;
?>
<div class="cev-2fa-card" data-cev-2fa-card>
	<div class="cev-2fa-card__header">
		<span class="cev-2fa-card__icon" aria-hidden="true">
			<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
				<rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
				<path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
			</svg>
		</span>
		<div class="cev-2fa-card__title">
			<h3><?php esc_html_e( 'Two-Factor Authentication', 'customer-email-verification' ); ?></h3>
			<p class="cev-2fa-card__subtitle">
				<?php esc_html_e( 'Add a 6-digit code from your authenticator app to every login.', 'customer-email-verification' ); ?>
			</p>
		</div>
		<span class="cev-2fa-card__status <?php echo $cev_2fa_enrolled ? 'is-on' : 'is-off'; ?>">
			<?php
			echo $cev_2fa_enrolled
				? esc_html__( 'On', 'customer-email-verification' )
				: esc_html__( 'Off', 'customer-email-verification' );
			?>
		</span>
	</div>

	<div class="cev-2fa-card__body">

		<?php if ( ! $cev_2fa_enrolled ) : ?>

			<!-- ENROLLMENT FLOW (3 steps) -->
			<div class="cev-2fa-step" data-cev-2fa-step="intro">
				<ol class="cev-2fa-steps">
					<li><?php esc_html_e( 'Install an authenticator app on your phone (Google Authenticator, Authy, Microsoft Authenticator, 1Password — any of them work).', 'customer-email-verification' ); ?></li>
					<li><?php esc_html_e( 'Click "Start setup" below.', 'customer-email-verification' ); ?></li>
					<li><?php esc_html_e( 'Scan the QR code with your app, then type the 6-digit code it shows.', 'customer-email-verification' ); ?></li>
				</ol>
				<button type="button" class="button button-primary cev-2fa-btn cev-2fa-btn--primary" data-cev-2fa-action="start">
					<?php esc_html_e( 'Start setup', 'customer-email-verification' ); ?>
				</button>
			</div>

			<div class="cev-2fa-step" data-cev-2fa-step="scan" hidden>

				<!--
					Step 1: Add to your authenticator app (two equal options:
					scan QR or copy key). The grey wrapper box is gone — both
					options sit on plain white with a clear two-column split.
				-->
				<div class="cev-2fa-add">
					<div class="cev-2fa-add__option">
						<div class="cev-2fa-add__label"><?php esc_html_e( 'Option A — scan with your phone', 'customer-email-verification' ); ?></div>
						<div class="cev-2fa-qr" data-cev-2fa-qr></div>
					</div>

					<div class="cev-2fa-add__divider" aria-hidden="true">
						<span><?php esc_html_e( 'OR', 'customer-email-verification' ); ?></span>
					</div>

					<div class="cev-2fa-add__option">
						<div class="cev-2fa-add__label"><?php esc_html_e( 'Option B — copy the key', 'customer-email-verification' ); ?></div>
						<p class="cev-2fa-add__hint">
							<?php esc_html_e( "In your authenticator app, choose 'Enter a setup key' (or 'Add manually'), set type to Time-based, then paste:", 'customer-email-verification' ); ?>
						</p>
						<div class="cev-2fa-key-row">
							<input
								type="text"
								class="cev-2fa-key-input"
								data-cev-2fa-secret-input
								readonly
								aria-label="<?php esc_attr_e( 'Setup key', 'customer-email-verification' ); ?>"
							>
							<button type="button" class="cev-2fa-icon-btn" data-cev-2fa-action="copy-secret" aria-label="<?php esc_attr_e( 'Copy key', 'customer-email-verification' ); ?>">
								<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
									<rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
									<path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
								</svg>
							</button>
						</div>
						<!--
							Copy feedback sits right under the copy button so the
							user sees confirmation NEXT TO what they clicked.
						-->
						<p class="cev-2fa-copy-feedback" data-cev-2fa-copy-feedback role="status" aria-live="polite"></p>
						<dl class="cev-2fa-key-meta">
							<dt><?php esc_html_e( 'Account', 'customer-email-verification' ); ?></dt>
							<dd data-cev-2fa-account></dd>
						</dl>
					</div>
				</div>

				<!--
					Step 2: enter the 6-digit code. Stacked layout — input on
					its own line, button below — looks far cleaner than the
					side-by-side cramped pairing on the older design.

					IMPORTANT: this is a <div>, NOT a <form>. The whole 2FA
					section renders inside the wp-admin profile <form>, and
					nested forms are invalid HTML — the browser collapses
					them and submitting our inner button bubbles up as a
					submit on the OUTER profile form, triggering the
					"Leave site? Changes you made may not be saved" dialog.
				-->
				<div class="cev-2fa-verify">
					<label class="cev-2fa-verify__label" for="cev-2fa-code">
						<?php esc_html_e( 'Enter the 6-digit code your app shows', 'customer-email-verification' ); ?>
					</label>
					<div class="cev-2fa-verify__form" data-cev-2fa-verify-form>
						<input
							type="text"
							id="cev-2fa-code"
							class="cev-2fa-verify__input"
							inputmode="numeric"
							pattern="[0-9]*"
							autocomplete="one-time-code"
							maxlength="6"
							placeholder="123456"
							data-cev-2fa-code
							aria-label="<?php esc_attr_e( '6-digit verification code', 'customer-email-verification' ); ?>"
						>
						<button type="button" class="cev-2fa-verify__submit" data-cev-2fa-action="verify">
							<?php esc_html_e( 'Verify and enable', 'customer-email-verification' ); ?>
						</button>
					</div>
					<p class="cev-2fa-feedback" data-cev-2fa-feedback role="status" aria-live="polite"></p>
				</div>

				<p class="cev-2fa-cancel-row">
					<button type="button" class="cev-2fa-cancel" data-cev-2fa-action="cancel">
						<?php esc_html_e( 'Cancel setup', 'customer-email-verification' ); ?>
					</button>
				</p>
			</div>

		<?php else : ?>

			<!-- ALREADY ENROLLED -->
			<p class="cev-2fa-enrolled-msg">
				<?php esc_html_e( 'Two-factor authentication is active on your account. You\'ll be asked for a 6-digit code from your authenticator app every time you log in.', 'customer-email-verification' ); ?>
			</p>

			<div class="cev-2fa-recovery-info">
				<strong><?php esc_html_e( 'Recovery codes', 'customer-email-verification' ); ?></strong>
				<p>
					<?php
					/* translators: %d: number of recovery codes the user has left. */
					echo esc_html( sprintf( _n( '%d recovery code remaining.', '%d recovery codes remaining.', $cev_2fa_remaining, 'customer-email-verification' ), $cev_2fa_remaining ) );
					?>
					<?php if ( $cev_2fa_remaining <= 3 ) : ?>
						<span class="cev-2fa-warn">
							<?php esc_html_e( 'Running low — generate a new set and store them somewhere safe.', 'customer-email-verification' ); ?>
						</span>
					<?php endif; ?>
				</p>
				<button type="button" class="button cev-2fa-btn" data-cev-2fa-action="regenerate">
					<?php esc_html_e( 'Generate new recovery codes', 'customer-email-verification' ); ?>
				</button>
			</div>

			<div class="cev-2fa-danger">
				<button type="button" class="button cev-2fa-btn cev-2fa-btn--danger" data-cev-2fa-action="disable">
					<?php esc_html_e( 'Turn off two-factor authentication', 'customer-email-verification' ); ?>
				</button>
			</div>

		<?php endif; ?>

		<!-- Recovery codes display panel — shared by enrollment + regenerate. -->
		<div class="cev-2fa-codes-panel" data-cev-2fa-codes-panel hidden>
			<h4><?php esc_html_e( 'Save your recovery codes', 'customer-email-verification' ); ?></h4>
			<p>
				<?php esc_html_e( 'Each code can be used ONCE if you lose access to your authenticator app. Store them somewhere safe (password manager, printed copy in a drawer). They will not be shown again.', 'customer-email-verification' ); ?>
			</p>
			<ul class="cev-2fa-codes-list" data-cev-2fa-codes-list></ul>
			<div class="cev-2fa-codes-actions">
				<button type="button" class="button cev-2fa-btn" data-cev-2fa-action="copy-codes">
					<?php esc_html_e( 'Copy to clipboard', 'customer-email-verification' ); ?>
				</button>
				<button type="button" class="button cev-2fa-btn" data-cev-2fa-action="download-codes">
					<?php esc_html_e( 'Download as text file', 'customer-email-verification' ); ?>
				</button>
				<button type="button" class="button button-primary cev-2fa-btn cev-2fa-btn--primary" data-cev-2fa-action="ack-codes">
					<?php esc_html_e( "I've saved them", 'customer-email-verification' ); ?>
				</button>
			</div>
		</div>

	</div>
</div>
