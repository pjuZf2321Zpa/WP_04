<?php
/**
 * 2FA Setup UI — surfaces the enrollment card on:
 *   1. WooCommerce → My Account → "Two-Factor Auth" tab (frontend, customers).
 *   2. wp-admin → Users → Your Profile (backend, staff).
 *   3. wp-admin → Users → Edit User (admin override / reset).
 *
 * Also enqueues the assets (qrcode.min.js + cev-2fa.css + cev-2fa-setup.js)
 * only on the screens that actually render the card.
 *
 * @package Customer_Email_Verification_Pro
 * @since   2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * CEV_2FA_Setup — singleton.
 */
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
class CEV_2FA_Setup {

	/** Slug of the WC My-Account endpoint. */
	const WC_ENDPOINT = 'cev-2fa';

	/**
	 * Singleton.
	 *
	 * @var CEV_2FA_Setup|null
	 */
	private static $instance = null;

	/**
	 * Get singleton.
	 *
	 * @return CEV_2FA_Setup
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor — wires hooks.
	 */
	public function __construct() {
		// Frontend (WooCommerce My Account).
		add_action( 'init', array( $this, 'register_wc_endpoint' ) );
		add_filter( 'woocommerce_account_menu_items', array( $this, 'wc_menu_item' ), 20 );
		add_filter( 'woocommerce_get_query_vars', array( $this, 'wc_query_vars' ) );
		add_action( 'woocommerce_account_' . self::WC_ENDPOINT . '_endpoint', array( $this, 'render_wc_endpoint' ) );
		add_filter( 'the_title', array( $this, 'wc_endpoint_title' ), 10, 2 );

		// Backend (admin staff own 2FA) — the setup card lives INSIDE
		// the CEV admin settings page (WooCommerce → Customer Email
		// Verification → Settings → Two-Factor Authentication section),
		// so we do NOT hook `show_user_profile`. The settings template
		// calls `render_settings_section()` directly.

		// BUT we DO need `edit_user_profile` — that's where an admin
		// helps a customer who's lost both their authenticator app
		// AND their recovery codes. Users → click the customer →
		// "Reset 2FA for this user" wipes the customer's enrolment so
		// they can log in with just their password and re-enrol.
		add_action( 'edit_user_profile', array( $this, 'render_edit_user' ) );

		// Asset enqueue.
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_frontend_assets' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
	}

	/* ----------------------------------------------------------------
	 * WooCommerce My-Account endpoint.
	 * --------------------------------------------------------------*/

	/**
	 * Register the rewrite endpoint so /my-account/cev-2fa/ resolves.
	 *
	 * @return void
	 */
	public function register_wc_endpoint() {
		add_rewrite_endpoint( self::WC_ENDPOINT, EP_PAGES );
	}

	/**
	 * Add the endpoint to WC's My-Account menu sidebar. Only show it
	 * when the master toggle is on AND the role policy applies to this
	 * user — keeps the menu clean for users 2FA doesn't apply to.
	 *
	 * @param array $items Existing menu items.
	 * @return array
	 */
	public function wc_menu_item( $items ) {
		$mgr = CEV_2FA_Manager::instance();
		if ( ! $mgr->is_enabled_globally() ) {
			return $items;
		}

		$user_id = get_current_user_id();
		if ( ! $mgr->policy_requires( $user_id ) && ! $mgr->is_enrolled( $user_id ) ) {
			return $items;
		}

		// Insert just before "Logout" if present, else append.
		$new_item = array( self::WC_ENDPOINT => __( 'Two-Factor Auth', 'customer-email-verification' ) );
		if ( isset( $items['customer-logout'] ) ) {
			$logout = array( 'customer-logout' => $items['customer-logout'] );
			unset( $items['customer-logout'] );
			return array_merge( $items, $new_item, $logout );
		}
		return array_merge( $items, $new_item );
	}

	/**
	 * Tell WC to recognise the endpoint as a query var.
	 *
	 * @param array $vars Query vars.
	 * @return array
	 */
	public function wc_query_vars( $vars ) {
		$vars[ self::WC_ENDPOINT ] = self::WC_ENDPOINT;
		return $vars;
	}

	/**
	 * Set the page title shown above the My-Account content area.
	 *
	 * @param string $title Default title.
	 * @param int    $id    Page ID.
	 * @return string
	 */
	public function wc_endpoint_title( $title, $id = null ) {
		global $wp_query;
		if ( ! is_null( $wp_query ) && in_the_loop() && is_account_page() && isset( $wp_query->query_vars[ self::WC_ENDPOINT ] ) ) {
			return __( 'Two-Factor Authentication', 'customer-email-verification' );
		}
		return $title;
	}

	/**
	 * Render the My-Account endpoint — wraps the shared setup card.
	 *
	 * @return void
	 */
	public function render_wc_endpoint() {
		$user_id           = get_current_user_id();
		$mgr               = CEV_2FA_Manager::instance();
		$cev_2fa_enrolled  = $mgr->is_enrolled( $user_id );
		$cev_2fa_remaining = $mgr->recovery_codes_remaining( $user_id );

		// Wrap in a context class so CSS can apply the stacked
		// "Option A on top / OR / Option B below" layout
		// unconditionally on the front-end (regardless of viewport
		// width). The wp-admin embed doesn't get this class, so it
		// keeps the side-by-side layout.
		echo '<div class="cev-2fa-frontend">';
		$view = dirname( __FILE__ ) . '/views/setup-card.php';
		if ( file_exists( $view ) ) {
			include $view;
		}
		echo '</div>';
	}

	/* The previous grace-period banner used the "Setup grace period"
	 * setting to mean "days a required user can delay enrolment". The
	 * setting now means "days the device is trusted after a successful
	 * 2FA verification" (see CEV_2FA_Login::handle_submit), so the
	 * setup-delay grace concept no longer exists and the banner is
	 * not rendered anywhere. The method has been removed. */

	/* ----------------------------------------------------------------
	 * CEV Admin Settings page → Two-Factor Authentication section.
	 * --------------------------------------------------------------*/

	/**
	 * Render the current admin's own 2FA setup card inside the CEV
	 * Settings page's Two-Factor Authentication section.
	 *
	 * Called from `includes/admin/views/admin_options_settings.php`
	 * after the policy fields. Means an admin can enrol without
	 * leaving the CEV admin pages.
	 *
	 * Bails when the master toggle is off (we don't want to clutter
	 * the section while 2FA is globally disabled).
	 *
	 * @return void
	 */
	public function render_settings_section() {
		// IMPORTANT: do NOT gate on `is_enabled_globally()` here. The
		// setup card needs to be in the DOM from page load so the
		// admin.js handler can show it the moment the master toggle is
		// flipped — without the gate the JS would have nothing to show
		// until the page was saved + refreshed. The "applies to me /
		// master toggle off" decisions are handled CLIENT-SIDE in
		// `updateTwoFaEmbedVisibility()`, which respects live changes
		// to the toggle, the policy dropdown, and the role checkboxes.
		$user_id = get_current_user_id();
		if ( $user_id <= 0 ) {
			return;
		}

		$this->render_admin_profile_section( $user_id, false );
	}

	/* ----------------------------------------------------------------
	 * Legacy wrappers — kept so existing callers don't break, but the
	 * matching WP-action hooks are no longer registered (see the
	 * constructor's note on why).
	 * --------------------------------------------------------------*/

	/**
	 * Render the setup card on a user's own profile.
	 *
	 * @return void
	 */
	public function render_user_profile() {
		if ( ! CEV_2FA_Manager::instance()->is_enabled_globally() ) {
			return;
		}
		$this->render_admin_profile_section( get_current_user_id(), false );
	}

	/**
	 * Render on Users → Edit User (admin viewing someone else). Shows a
	 * READ-ONLY status + a "Reset 2FA" button for the admin to wipe the
	 * user's enrollment if they're locked out.
	 *
	 * @param WP_User $user The user being edited.
	 * @return void
	 */
	public function render_edit_user( $user ) {
		if ( ! CEV_2FA_Manager::instance()->is_enabled_globally() ) {
			return;
		}
		if ( ! current_user_can( 'edit_user', $user->ID ) ) {
			return;
		}
		$this->render_admin_profile_section( (int) $user->ID, true );
	}

	/**
	 * Shared renderer for both wp-admin profile screens.
	 *
	 * @param int  $user_id     User being viewed/edited.
	 * @param bool $is_other_user True when an admin is editing someone else.
	 * @return void
	 */
	private function render_admin_profile_section( $user_id, $is_other_user ) {
		$mgr               = CEV_2FA_Manager::instance();
		$cev_2fa_enrolled  = $mgr->is_enrolled( $user_id );
		$cev_2fa_remaining = $mgr->recovery_codes_remaining( $user_id );

		// No <h2> here — the card supplies its own header (icon + title +
		// status pill) which would otherwise duplicate.
		if ( $is_other_user ) {
			// Read-only view for an admin editing someone else.
			?>
			<div class="cev-2fa-card cev-2fa-card--standalone">
				<div class="cev-2fa-card__header">
					<span class="cev-2fa-card__icon" aria-hidden="true">
						<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
							<rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
							<path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
						</svg>
					</span>
					<div class="cev-2fa-card__title">
						<h3><?php esc_html_e( 'Two-Factor Authentication', 'customer-email-verification' ); ?></h3>
						<p class="cev-2fa-card__subtitle">
							<?php esc_html_e( 'Authenticator-app status for this user.', 'customer-email-verification' ); ?>
						</p>
					</div>
					<span class="cev-2fa-card__status <?php echo $cev_2fa_enrolled ? 'is-on' : 'is-off'; ?>">
						<?php echo $cev_2fa_enrolled ? esc_html__( 'Active', 'customer-email-verification' ) : esc_html__( 'Not set up', 'customer-email-verification' ); ?>
					</span>
				</div>
				<div class="cev-2fa-card__body">
					<?php if ( $cev_2fa_enrolled ) : ?>
						<p>
							<?php
							/* translators: %d: remaining recovery codes. */
							echo esc_html( sprintf( _n( '%d recovery code remaining.', '%d recovery codes remaining.', $cev_2fa_remaining, 'customer-email-verification' ), $cev_2fa_remaining ) );
							?>
						</p>
						<button
							type="button"
							class="button cev-2fa-btn"
							data-cev-2fa-action="admin-reset"
							data-cev-2fa-user-id="<?php echo esc_attr( $user_id ); ?>"
							data-cev-2fa-confirm="<?php esc_attr_e( "Reset this user's two-factor authentication? They'll be able to log in with just their password and re-enrol.", 'customer-email-verification' ); ?>"
						>
							<?php esc_html_e( 'Reset 2FA for this user', 'customer-email-verification' ); ?>
						</button>
					<?php else : ?>
						<p>
							<?php esc_html_e( "This user hasn't enrolled an authenticator app yet.", 'customer-email-verification' ); ?>
						</p>
					<?php endif; ?>
				</div>
			</div>
			<?php
		} else {
			// Self view — full setup card with QR + recovery flow.
			$view = dirname( __FILE__ ) . '/views/setup-card.php';
			if ( file_exists( $view ) ) {
				include $view;
			}
		}
	}

	/* ----------------------------------------------------------------
	 * Asset enqueue.
	 * --------------------------------------------------------------*/

	/**
	 * Enqueue on the WC My-Account 2FA endpoint only.
	 *
	 * @return void
	 */
	public function enqueue_frontend_assets() {
		if ( ! function_exists( 'is_account_page' ) || ! is_account_page() ) {
			return;
		}
		// Only on our endpoint, not other account pages.
		global $wp;
		if ( empty( $wp->query_vars[ self::WC_ENDPOINT ] ) && ! isset( $wp->query_vars[ self::WC_ENDPOINT ] ) ) {
			// Some setups won't have the key present unless on the endpoint —
			// fall through if our key is missing.
			if ( ! isset( $wp->query_vars[ self::WC_ENDPOINT ] ) ) {
				return;
			}
		}
		$this->enqueue_shared();
	}

	/**
	 * Enqueue on Users → Profile + Edit User.
	 *
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public function enqueue_admin_assets( $hook ) {
		// Allowed hooks:
		//   - profile.php / user-edit.php (legacy — kept so the standalone
		//     render still works if anyone re-enables the show_user_profile
		//     hook in the future).
		//   - the CEV admin Settings page — `woocommerce_page_<page-slug>`.
		$allowed = array(
			'profile.php',
			'user-edit.php',
			'woocommerce_page_customer-email-verification-for-woocommerce',
			'woocommerce_page_customer-email-verification',
		);
		if ( ! in_array( $hook, $allowed, true ) ) {
			return;
		}
		$this->enqueue_shared();
	}

	/**
	 * Shared enqueue for both surfaces — qrcode lib + setup JS + CSS.
	 *
	 * @return void
	 */
	private function enqueue_shared() {
		$base_url = $this->plugin_url();
		$ver      = $this->plugin_version();

		wp_enqueue_style(
			'cev-2fa',
			$base_url . 'assets/css/cev-2fa.css',
			array(),
			$ver
		);

		// jQuery QR plugin — vendored from Wordfence. Renders the QR
		// client-side as a <canvas> via `$(el).qrcode({ text: ... })`.
		// This is the proven path; the previous PHP-side encoder was
		// replaced because of subtle matrix bugs.
		wp_enqueue_script(
			'cev-jquery-qrcode',
			$base_url . 'assets/js/vendor/jquery.qrcode.min.js',
			array( 'jquery' ),
			$ver,
			true
		);

		wp_enqueue_script(
			'cev-2fa-setup',
			$base_url . 'assets/js/cev-2fa-setup.js',
			array( 'jquery', 'cev-jquery-qrcode' ),
			$ver,
			true
		);

		// Current user's roles + enrolment flag — used by the live JS
		// "does the policy apply to me?" check on the CEV settings page.
		$current_user       = wp_get_current_user();
		$current_user_roles = ( $current_user instanceof WP_User )
			? array_values( (array) $current_user->roles )
			: array();
		$current_user_enrolled = ( $current_user && $current_user->ID )
			? CEV_2FA_Manager::instance()->is_enrolled( (int) $current_user->ID )
			: false;

		wp_localize_script(
			'cev-2fa-setup',
			'CEV_2FA_SETUP',
			array(
				'ajax_url'           => admin_url( 'admin-ajax.php' ),
				'user_nonce'         => wp_create_nonce( CEV_2FA_Ajax::NONCE_USER ),
				'admin_nonce'        => wp_create_nonce( CEV_2FA_Ajax::NONCE_ADMIN ),
				'current_user_roles' => $current_user_roles,
				'current_user_enrolled' => $current_user_enrolled,
				'i18n'        => array(
					'enter_code'           => __( 'Enter the 6-digit code from your app.', 'customer-email-verification' ),
					'verifying'            => __( 'Verifying…', 'customer-email-verification' ),
					'enabling'             => __( 'Enabling…', 'customer-email-verification' ),
					'disabling'            => __( 'Turning off…', 'customer-email-verification' ),
					'generating'           => __( 'Generating…', 'customer-email-verification' ),
					'resetting'            => __( 'Resetting…', 'customer-email-verification' ),
					'copied'               => __( 'Copied to clipboard.', 'customer-email-verification' ),
					'copy_failed'          => __( "Couldn't copy automatically. Select the codes and copy them manually.", 'customer-email-verification' ),
					'confirm_disable'      => __( 'Turn off two-factor authentication? You can re-enable it later.', 'customer-email-verification' ),
					'confirm_regenerate'   => __( 'Replace your recovery codes? The old codes will stop working.', 'customer-email-verification' ),
					'recovery_filename'    => __( 'recovery-codes.txt', 'customer-email-verification' ),
					'unknown_error'        => __( 'Something went wrong. Please try again.', 'customer-email-verification' ),
					// Modal-dialog strings — used by the styled CevModal
					// helper instead of the browser's native confirm().
					'cancel'               => __( 'Cancel', 'customer-email-verification' ),
					'regenerate_title'     => __( 'Replace recovery codes?', 'customer-email-verification' ),
					'regenerate_confirm'   => __( 'Generate new codes', 'customer-email-verification' ),
					'disable_title'        => __( 'Turn off two-factor authentication?', 'customer-email-verification' ),
					'disable_confirm'      => __( 'Turn it off', 'customer-email-verification' ),
					'admin_reset_title'    => __( "Reset this user's 2FA?", 'customer-email-verification' ),
					'admin_reset_confirm'  => __( 'Reset 2FA', 'customer-email-verification' ),
				),
			)
		);
	}

	/**
	 * URL of the plugin root, with trailing slash.
	 *
	 * Uses the main plugin class's `plugin_dir_url()` method (NOT the
	 * non-existent `plugin_url` property — that bug caused the JS/CSS to
	 * 404 and the Start setup button to do nothing).
	 *
	 * @return string
	 */
	private function plugin_url() {
		return cev_pro()->plugin_dir_url();
	}

	/**
	 * Plugin version (for asset cache-busting).
	 *
	 * TEMP: returning time() so every page load forces a fresh fetch of
	 * the 2FA JS/CSS during testing. Restore to `cev_pro()->version`
	 * before shipping a release.
	 *
	 * @return string
	 */
	private function plugin_version() {
		return (string) time();
	}
}
