<?php
/**
 * 2FA Login Interceptor — gates the WordPress login with the
 * Authenticator App code.
 *
 * Flow:
 *   1. User submits username + password to wp-login.php (or any other
 *      WP login surface — REST, XML-RPC, custom forms — all go through
 *      the `authenticate` filter).
 *   2. After WP authenticates the credentials, we check:
 *      - Is master 2FA toggle on?
 *      - Does the role policy require this user?
 *      - Has the user enrolled?
 *      - Does the user have an unexpired "trusted" cookie from a prior
 *        successful 2FA on this same browser?
 *   3. If 2FA is required AND not satisfied, we PARK the half-authenticated
 *      session in a transient keyed by a one-shot token, send the user
 *      to a small TOTP entry page, and return a non-fatal WP_Error so WP
 *      doesn't issue the auth cookie yet.
 *   4. On the TOTP page, user enters their 6-digit code (or one-time
 *      recovery code). On success, we resume the original login by
 *      calling `wp_set_auth_cookie()` for the parked user_id and redirect
 *      to wherever they were heading.
 *
 * Edge cases handled:
 *   - User in grace period AND not enrolled: login proceeds; a soft
 *     banner reminds them on the My Account page.
 *   - Recovery code used: code is consumed (single-use) and a notice
 *     fires after login.
 *   - Trusted browser: we can issue a 30-day signed cookie so frequent
 *     logins from the same machine don't ask every time. Disabled by
 *     default — opt-in via filter `cev_2fa_remember_browser_days`.
 *
 * @package Customer_Email_Verification_Pro
 * @since   2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * CEV_2FA_Login — singleton.
 */
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
class CEV_2FA_Login {

	/** Transient prefix for parked sessions. */
	const PARK_PREFIX = 'cev_2fa_park_';

	/** Park transient TTL (seconds). User has 5 min to enter the code. */
	const PARK_TTL = 300;

	/** GET key the TOTP page reads to find the parked session. */
	const PARK_KEY = 'cev_2fa_token';

	/** Action name (POST) the TOTP page submits to. */
	const SUBMIT_ACTION = 'cev_2fa_submit';

	/** Cookie name for "remember this browser". */
	const REMEMBER_COOKIE = 'cev_2fa_trust';

	/**
	 * Singleton.
	 *
	 * @var CEV_2FA_Login|null
	 */
	private static $instance = null;

	/**
	 * Get singleton.
	 *
	 * @return CEV_2FA_Login
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor — wires hooks.
	 */
	public function __construct() {
		// Late authenticate filter — runs AFTER username/password check
		// (priority 30 — WP's own checks run at 20).
		add_filter( 'authenticate', array( $this, 'gate_login' ), 30, 3 );

		// wp-login.php TOTP form (used for admin / staff logins).
		add_action( 'login_form_' . self::SUBMIT_ACTION, array( $this, 'handle_submit' ) );
		add_action( 'login_form_cev_2fa', array( $this, 'render_form' ) );

		// Front-end TOTP form — rendered on the same /my-account/ URL
		// the customer logged in from, using the active store theme so
		// the prompt keeps the same header / branding instead of
		// jumping to a generic wp-login.php page.
		add_action( 'template_redirect', array( $this, 'maybe_handle_frontend_2fa' ), 5 );

		// Note: the legacy `wp_login` enforcement hook + the
		// `cev_2fa_enroll` forced-setup screen were removed when 2FA
		// became fully opt-in. We never block or redirect a user who
		// hasn't enrolled.
	}

	/* ----------------------------------------------------------------
	 * Pre-cookie gate.
	 * --------------------------------------------------------------*/

	/**
	 * `authenticate` filter — intercept after WP has accepted the
	 * password but before the auth cookie is issued.
	 *
	 * @param WP_User|WP_Error|null $user     Authenticated user or error.
	 * @param string                $username Username typed.
	 * @param string                $password Password typed (unused here).
	 * @return WP_User|WP_Error
	 */
	public function gate_login( $user, $username, $password ) {
		// Only intervene when WP has already accepted the password.
		if ( ! ( $user instanceof WP_User ) ) {
			return $user;
		}

		$mgr = CEV_2FA_Manager::instance();
		if ( ! $mgr->is_enabled_globally() ) {
			return $user;
		}

		$user_id = (int) $user->ID;

		// User has enrolled VOLUNTARILY — ask for a 6-digit code unless
		// the trusted-device cookie is still valid (which it will be
		// for the configured "Remember this device for" period after
		// the last successful verification).
		if ( $mgr->is_enrolled( $user_id ) ) {
			if ( $this->has_trusted_cookie( $user_id ) ) {
				return $user;
			}
			return $this->park_and_redirect( $user );
		}

		// Not enrolled — ALWAYS let the login proceed. 2FA is fully
		// opt-in: users discover the setup card on their account /
		// settings page, but no one is ever forced to enrol or
		// blocked from logging in. The role policy
		// (CEV_2FA_Manager::policy_requires) only controls who SEES
		// the "Set up 2FA" UI — never who is required to use it.
		return $user;
	}

	/**
	 * Stash the half-authenticated user in a transient and redirect to
	 * the TOTP entry page.
	 *
	 * Now that 2FA is fully opt-in, this is only ever called for users
	 * who have voluntarily enrolled — there is no forced-enrolment
	 * path any more.
	 *
	 * @param WP_User $user Authenticated user.
	 * @return WP_Error  Suppresses the normal auth-cookie issuance.
	 */
	private function park_and_redirect( $user ) {
		wp_safe_redirect( self::build_park_url( $user ) );
		exit;
	}

	/**
	 * Park a user pending their 2FA challenge and return the URL to send
	 * them to — same transient + URL logic as park_and_redirect(), but
	 * returns instead of issuing an HTTP redirect.
	 *
	 * SECURITY: this is the reusable half of the "park a half-authenticated
	 * user" flow, so a caller that authenticates OUTSIDE wp_signon() (and
	 * therefore never passes through gate_login() on the `authenticate`
	 * filter — e.g. Smart Form's emailed/texted OTP login) can still defer
	 * to the account's Authenticator App 2FA instead of completing sign-in.
	 *
	 * @since 3.0.4
	 * @param WP_User $user Authenticated user.
	 * @return string The URL to redirect the browser to.
	 */
	public static function build_park_url( $user ) {
		$token = wp_generate_password( 32, false, false );

		// Resolve the post-2FA redirect target. If the original login
		// request had `redirect_to`, honour it. Otherwise pick a
		// sensible default based on the user's role — admins go to
		// wp-admin, customers go to My Account.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Redirect target only; esc_url_raw'd.
		$redirect_to = isset( $_REQUEST['redirect_to'] ) ? esc_url_raw( wp_unslash( $_REQUEST['redirect_to'] ) ) : '';
		if ( '' === $redirect_to ) {
			$redirect_to = user_can( $user, 'manage_woocommerce' )
				? admin_url()
				: ( function_exists( 'wc_get_account_endpoint_url' ) ? wc_get_account_endpoint_url( 'dashboard' ) : home_url() );
		}

		set_transient(
			self::PARK_PREFIX . $token,
			array(
				'user_id'     => (int) $user->ID,
				'redirect_to' => $redirect_to,
				'created_at'  => time(),
			),
			self::PARK_TTL
		);

		// Pick the prompt surface — front-end My Account form (using
		// the active theme) for customers, or wp-login.php for staff.
		if ( self::use_frontend_form_for( $user, $redirect_to ) ) {
			$account_url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/my-account/' );
			$url = add_query_arg(
				array( self::PARK_KEY => $token ),
				$account_url
			);
		} else {
			$url = add_query_arg(
				array(
					'action'       => 'cev_2fa',
					self::PARK_KEY => $token,
				),
				site_url( 'wp-login.php', 'login' )
			);
		}

		return $url;
	}

	/**
	 * Decide whether to render the 2FA prompt on the front-end
	 * (My Account, theme-styled) or via wp-login.php (admin-styled).
	 *
	 * Rules:
	 *   - If `redirect_to` clearly points to wp-admin → wp-login.php
	 *   - If the user has the `manage_woocommerce` cap → wp-login.php
	 *   - Otherwise → front-end form
	 *
	 * @param WP_User $user        Authenticated user.
	 * @param string  $redirect_to The resolved post-2FA destination.
	 * @return bool
	 */
	private static function use_frontend_form_for( $user, $redirect_to ) {
		$admin_url = admin_url();
		if ( '' !== $redirect_to && 0 === strpos( $redirect_to, $admin_url ) ) {
			return false; // redirect target IS wp-admin → keep admin flow
		}
		if ( user_can( $user, 'manage_woocommerce' ) ) {
			return false; // staff/admin user → keep admin flow
		}
		return true;
	}

	/* ----------------------------------------------------------------
	 * TOTP entry page (rendered on wp-login.php?action=cev_2fa).
	 * --------------------------------------------------------------*/

	/**
	 * Render the TOTP entry page. Hooked on `login_form_cev_2fa`.
	 *
	 * @return void
	 */
	public function render_form() {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Parked 2FA session token; HMAC-verified in load_parked() below.
		$token  = isset( $_GET[ self::PARK_KEY ] ) ? sanitize_text_field( wp_unslash( $_GET[ self::PARK_KEY ] ) ) : '';
		$parked = $this->load_parked( $token );
		if ( ! $parked ) {
			wp_die(
				esc_html__( 'Your two-factor authentication session has expired. Please log in again.', 'customer-email-verification' ),
				esc_html__( 'Session expired', 'customer-email-verification' ),
				array( 'response' => 403, 'back_link' => true )
			);
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Read-only error-message display; no state change.
		$error_msg = isset( $_GET['cev_2fa_err'] ) ? sanitize_text_field( wp_unslash( $_GET['cev_2fa_err'] ) ) : '';
		$this->print_login_page( $token, $error_msg, false );
		exit;
	}

	/**
	 * Handle the POST from the TOTP entry page.
	 *
	 * @return void
	 */
	public function handle_submit() {
		$token  = isset( $_POST[ self::PARK_KEY ] ) ? sanitize_text_field( wp_unslash( $_POST[ self::PARK_KEY ] ) ) : '';
		$parked = $this->load_parked( $token );
		if ( ! $parked ) {
			wp_die(
				esc_html__( 'Your two-factor authentication session has expired. Please log in again.', 'customer-email-verification' ),
				esc_html__( 'Session expired', 'customer-email-verification' ),
				array( 'response' => 403, 'back_link' => true )
			);
		}

		check_admin_referer( 'cev_2fa_submit_' . $token, '_cev_2fa_nonce' );

		$user_id = (int) $parked['user_id'];
		$mgr     = CEV_2FA_Manager::instance();

		// Distinguish 6-digit TOTP from a 10-char recovery code.
		$code_input = isset( $_POST['cev_2fa_code'] ) ? sanitize_text_field( wp_unslash( $_POST['cev_2fa_code'] ) ) : '';
		$is_recovery = ( strlen( preg_replace( '/[^a-z0-9]/i', '', $code_input ) ) >= 10 );

		$ok = false;
		if ( $is_recovery ) {
			$ok = $mgr->consume_recovery_code( $user_id, $code_input );
		} else {
			$ok = $mgr->verify_login_code( $user_id, $code_input );
		}

		// Analytics: log the outcome of this 2FA attempt.
		if ( method_exists( cev_pro()->function, 'log_event' ) ) {
			$user_obj = get_userdata( $user_id );
			cev_pro()->function->log_event(
				$user_obj ? $user_obj->user_email : '',
				$ok ? '2fa_verified' : '2fa_failed',
				'2fa',
				array( 'recovery' => $is_recovery ),
				$user_id
			);
		}

		if ( ! $ok ) {
			$err = $is_recovery
				? __( 'That recovery code is not valid (or has already been used).', 'customer-email-verification' )
				: __( 'Incorrect code. Make sure the time on your phone is correct, then try the latest code your app shows.', 'customer-email-verification' );

			$retry_url = add_query_arg(
				array(
					'action'        => 'cev_2fa',
					self::PARK_KEY  => $token,
					'cev_2fa_err'   => rawurlencode( $err ),
				),
				site_url( 'wp-login.php', 'login' )
			);
			wp_safe_redirect( $retry_url );
			exit;
		}

		// Burn the token — single-use.
		delete_transient( self::PARK_PREFIX . $token );

		// Auto-trust this device for the configured number of days,
		// taken from the "Remember this device for" setting. 0 means
		// don't remember (cookie not set) → user is prompted at every
		// login.
		$trust_days = (int) CEV_2FA_Manager::instance()->grace_days();
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		$trust_days = (int) apply_filters( 'cev_2fa_remember_browser_days', $trust_days, $user_id );
		if ( $trust_days > 0 ) {
			$this->set_trusted_cookie( $user_id, $trust_days );
		}

		// Notify the user if they consumed a recovery code.
		if ( $is_recovery ) {
			$remaining = $mgr->recovery_codes_remaining( $user_id );
			set_transient( 'cev_2fa_recovery_used_' . $user_id, max( 0, (int) $remaining ), 60 );
		}

		// Resume the login.
		// phpcs:ignore Generic.PHP.ForbiddenFunctions.Discouraged -- Programmatic login after a verified 2FA factor; wp_signon() needs a password.
		wp_set_current_user( $user_id );
		// phpcs:ignore Generic.PHP.ForbiddenFunctions.Discouraged -- Programmatic login after a verified 2FA factor; wp_signon() needs a password.
		wp_set_auth_cookie( $user_id, false ); // nosemgrep: audit.php.wp.security.auth-bypass.wp-set-auth-cookie -- $user_id is the parked, TOTP-verified user, not raw request input.
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core WP/WooCommerce/third-party hook; must fire the exact documented name for integrations to respond.
		do_action( 'wp_login', get_userdata( $user_id )->user_login, get_userdata( $user_id ) );

		$redirect = ! empty( $parked['redirect_to'] ) ? $parked['redirect_to'] : admin_url();
		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Print the login page chrome + TOTP form. Reuses WP's login header
	 * helpers so the page looks native.
	 *
	 * @param string $token     Park token.
	 * @param string $error_msg Optional error to surface above the form.
	 * @param bool   $unused    Reserved.
	 * @return void
	 */
	private function print_login_page( $token, $error_msg, $unused ) {
		login_header( __( 'Two-Factor Authentication', 'customer-email-verification' ) );
		?>
		<style>
			.cev-2fa-login-form .input { width: 100%; padding: 14px; font-size: 24px; letter-spacing: 6px; text-align: center; box-sizing: border-box; }
			.cev-2fa-login-form .description { font-size: 13px; color: #50575e; margin-bottom: 12px; }
			.cev-2fa-login-form .recovery-link { display: block; margin-top: 14px; font-size: 13px; }
			.cev-2fa-error { background: #fff8e5; border-left: 4px solid #dba617; padding: 10px 12px; margin-bottom: 16px; }
		</style>
		<form name="cev2faform" id="cev2faform" class="cev-2fa-login-form" method="post" action="<?php echo esc_url( site_url( 'wp-login.php?action=' . self::SUBMIT_ACTION, 'login' ) ); ?>">
			<?php if ( '' !== $error_msg ) : ?>
				<div class="cev-2fa-error"><?php echo esc_html( $error_msg ); ?></div>
			<?php endif; ?>
			<p class="description">
				<?php esc_html_e( 'Open your authenticator app and enter the 6-digit code shown for this site.', 'customer-email-verification' ); ?>
			</p>
			<p>
				<label for="cev_2fa_code"><?php esc_html_e( 'Authentication code', 'customer-email-verification' ); ?></label>
				<input
					type="text"
					name="cev_2fa_code"
					id="cev_2fa_code"
					class="input"
					inputmode="numeric"
					autocomplete="one-time-code"
					maxlength="20"
					autofocus
				>
			</p>
			<input type="hidden" name="<?php echo esc_attr( self::PARK_KEY ); ?>" value="<?php echo esc_attr( $token ); ?>">
			<?php wp_nonce_field( 'cev_2fa_submit_' . $token, '_cev_2fa_nonce' ); ?>
			<p class="submit">
				<button type="submit" class="button button-primary button-large" style="width:100%;">
					<?php esc_html_e( 'Log in', 'customer-email-verification' ); ?>
				</button>
			</p>
			<p class="recovery-link">
				<?php esc_html_e( "Can't access your authenticator app? Type one of your recovery codes above instead (10 characters with a dash).", 'customer-email-verification' ); ?>
			</p>
		</form>
		<?php
		login_footer();
	}

	/* ----------------------------------------------------------------
	 * Forced-enrollment screen (post-grace).
	 * --------------------------------------------------------------*/

	/* The forced-enrolment flow (`render_enroll_form` + the
	 * `enforce_post_login` belt-and-braces hook + the
	 * `cev_2fa_must_setup_*` transient) was removed when 2FA became
	 * fully opt-in. The plugin no longer redirects, blocks, or nags
	 * any user into setting up 2FA. */

	/* ----------------------------------------------------------------
	 * Front-end 2FA prompt (renders on /my-account/ with active theme).
	 *
	 * Customers land here instead of wp-login.php after submitting the
	 * password on the My Account login form, so the 2FA prompt keeps
	 * the same header / branding the customer was just on.
	 * --------------------------------------------------------------*/

	/**
	 * `template_redirect` hook — detects a parked 2FA session in the
	 * URL and either renders the form (GET) or processes the code
	 * submission (POST).
	 *
	 * @return void
	 */
	public function maybe_handle_frontend_2fa() {
		if ( is_admin() ) {
			return;
		}

		$is_post = ( 'POST' === ( isset( $_SERVER['REQUEST_METHOD'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) : '' ) );

		// The token below is a one-time opaque identifier looked up via
		// `load_parked()`, which does cryptographic + expiry verification
		// before any state is acted on. A nonce on this initial detection
		// step would be redundant — and impossible to provide for the
		// `$_GET` entry path, where the user is following a redirect link
		// after authentication. PHPCS doesn't see the downstream check.
		//
		// We pull the superglobal reads onto their OWN statements (not
		// inline inside the `if (...)` condition) so the previous-line
		// `phpcs:ignore` reliably applies — when the access sits inside
		// a multi-condition expression on the same line as the `if`,
		// some audit-server PHPCS versions don't honour the suppression.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended
		$post_park_token = isset( $_POST[ self::PARK_KEY ] ) ? sanitize_text_field( wp_unslash( $_POST[ self::PARK_KEY ] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended
		$get_park_token  = isset( $_GET[ self::PARK_KEY ] )  ? sanitize_text_field( wp_unslash( $_GET[ self::PARK_KEY ] ) )  : '';

		$token = '';
		if ( $is_post && '' !== $post_park_token ) {
			$token = $post_park_token;
		} elseif ( '' !== $get_park_token ) {
			$token = $get_park_token;
		}

		if ( '' === $token ) {
			return; // not a 2FA request — let normal page render
		}

		$parked = $this->load_parked( $token );
		if ( ! $parked ) {
			// Token expired / invalid. Render a soft error page with
			// the theme so we don't fall through to the My Account
			// login form (which would be confusing).
			$this->print_frontend_form(
				$token,
				__( 'Your 2FA session expired. Please log in again.', 'customer-email-verification' ),
				true
			);
			exit;
		}

		if ( $is_post ) {
			$this->process_frontend_submit( $token, $parked );
			return; // process_frontend_submit either redirects or re-renders + exits
		}

		// GET — render the form with the theme.
		$this->print_frontend_form( $token, '', false );
		exit;
	}

	/**
	 * Verify the code from the front-end form, finish login on
	 * success, or re-render the form with an error on failure.
	 *
	 * @param string $token  Parked-session token.
	 * @param array  $parked Parked-session data.
	 * @return void
	 */
	private function process_frontend_submit( $token, $parked ) {
		// Nonce check — prevents replay / forgery of the form.
		$nonce = isset( $_POST['_cev_2fa_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_cev_2fa_nonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'cev_2fa_submit_' . $token ) ) {
			$this->print_frontend_form(
				$token,
				__( 'Security check failed. Please refresh and try again.', 'customer-email-verification' ),
				false
			);
			exit;
		}

		$user_id = (int) $parked['user_id'];
		$mgr     = CEV_2FA_Manager::instance();

		$code_input  = isset( $_POST['cev_2fa_code'] ) ? sanitize_text_field( wp_unslash( $_POST['cev_2fa_code'] ) ) : '';
		$is_recovery = ( strlen( preg_replace( '/[^a-z0-9]/i', '', $code_input ) ) >= 10 );

		$ok = $is_recovery
			? $mgr->consume_recovery_code( $user_id, $code_input )
			: $mgr->verify_login_code( $user_id, $code_input );

		// Analytics: log the outcome of this front-end 2FA attempt.
		if ( method_exists( cev_pro()->function, 'log_event' ) ) {
			$user_obj = get_userdata( $user_id );
			cev_pro()->function->log_event(
				$user_obj ? $user_obj->user_email : '',
				$ok ? '2fa_verified' : '2fa_failed',
				'2fa',
				array( 'recovery' => $is_recovery, 'surface' => 'frontend' ),
				$user_id
			);
		}

		if ( ! $ok ) {
			$err = $is_recovery
				? __( 'That recovery code is not valid (or has already been used).', 'customer-email-verification' )
				: __( "Incorrect code. Make sure your phone's clock is correct, then try the latest code your app shows.", 'customer-email-verification' );
			$this->print_frontend_form( $token, $err, false );
			exit;
		}

		// Burn the parked token — single-use.
		delete_transient( self::PARK_PREFIX . $token );

		// Auto-trust this device per the configured "Remember this
		// device for" setting.
		$trust_days = (int) $mgr->grace_days();
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		$trust_days = (int) apply_filters( 'cev_2fa_remember_browser_days', $trust_days, $user_id );
		if ( $trust_days > 0 ) {
			$this->set_trusted_cookie( $user_id, $trust_days );
		}

		// Notify if a recovery code was used (transient consumed on
		// next page load).
		if ( $is_recovery ) {
			$remaining = $mgr->recovery_codes_remaining( $user_id );
			set_transient( 'cev_2fa_recovery_used_' . $user_id, max( 0, (int) $remaining ), 60 );
		}

		// Issue the real auth cookie + fire wp_login + redirect.
		// phpcs:ignore Generic.PHP.ForbiddenFunctions.Discouraged -- Programmatic login after a verified 2FA factor; wp_signon() needs a password.
		wp_set_current_user( $user_id );
		// phpcs:ignore Generic.PHP.ForbiddenFunctions.Discouraged -- Programmatic login after a verified 2FA factor; wp_signon() needs a password.
		wp_set_auth_cookie( $user_id, false ); // nosemgrep: audit.php.wp.security.auth-bypass.wp-set-auth-cookie -- $user_id is the parked, TOTP-verified user, not raw request input.
		$user = get_userdata( $user_id );
		if ( $user ) {
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core WP/WooCommerce/third-party hook; must fire the exact documented name for integrations to respond.
			do_action( 'wp_login', $user->user_login, $user );
		}

		$redirect = ! empty( $parked['redirect_to'] ) ? $parked['redirect_to'] : home_url();
		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Render the front-end 2FA prompt using the active theme.
	 *
	 * Uses get_header() / get_footer() so the page gets the store's
	 * branding, navigation, and footer — same context the customer
	 * was just on.
	 *
	 * @param string $token        Parked-session token (passed back through the form).
	 * @param string $error_msg    Optional error to display above the form.
	 * @param bool   $token_expired When true, replaces the form with a "session expired" message + a link back to login.
	 * @return void
	 */
	private function print_frontend_form( $token, $error_msg, $token_expired = false ) {
		// Make sure our card styles load on this URL. (The asset
		// enqueue normally only fires on /my-account/cev-2fa/, so we
		// re-enqueue here for the token URL.)
		if ( class_exists( 'CEV_2FA_Setup' ) ) {
			$base = cev_pro()->plugin_dir_url();
			$ver  = function_exists( 'cev_pro' ) ? (string) time() : '1.0';
			wp_enqueue_style( 'cev-2fa', $base . 'assets/css/cev-2fa.css', array(), $ver );
		}

		$nonce  = wp_create_nonce( 'cev_2fa_submit_' . $token );
		$action = esc_url( home_url( add_query_arg( null, null ) ) );

		// Strip our own query args from the form's action URL so the
		// final POST stays clean.
		$action = remove_query_arg( array( self::PARK_KEY ), $action );

		get_header();
		?>
		<div class="cev-2fa-frontend-wrap">
			<div class="cev-2fa-card cev-2fa-card--standalone">
				<div class="cev-2fa-card__header">
					<span class="cev-2fa-card__icon" aria-hidden="true">
						<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
							<rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
							<path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
						</svg>
					</span>
					<div class="cev-2fa-card__title">
						<h3><?php esc_html_e( 'Two-Factor Authentication', 'customer-email-verification' ); ?></h3>
						<p class="cev-2fa-card__subtitle">
							<?php esc_html_e( 'Open your authenticator app and enter the 6-digit code shown for this site.', 'customer-email-verification' ); ?>
						</p>
					</div>
				</div>

				<div class="cev-2fa-card__body">
					<?php if ( $token_expired ) : ?>
						<p class="cev-2fa-feedback is-error">
							<?php echo esc_html( $error_msg ); ?>
						</p>
						<p style="margin-top:14px;">
							<a class="cev-2fa-cancel" href="<?php echo esc_url( function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url() ); ?>">
								<?php esc_html_e( 'Back to login', 'customer-email-verification' ); ?>
							</a>
						</p>
					<?php else : ?>
						<form method="post" action="<?php echo esc_url( $action ); ?>" class="cev-2fa-verify__form" style="max-width:280px;">
							<label class="cev-2fa-verify__label" for="cev_2fa_code">
								<?php esc_html_e( 'Authentication code', 'customer-email-verification' ); ?>
							</label>
							<input
								type="text"
								id="cev_2fa_code"
								name="cev_2fa_code"
								class="cev-2fa-verify__input"
								inputmode="numeric"
								autocomplete="one-time-code"
								maxlength="20"
								placeholder="123456"
								autofocus
							>
							<input type="hidden" name="<?php echo esc_attr( self::PARK_KEY ); ?>" value="<?php echo esc_attr( $token ); ?>">
							<input type="hidden" name="_cev_2fa_nonce" value="<?php echo esc_attr( $nonce ); ?>">
							<button type="submit" class="cev-2fa-verify__submit">
								<?php esc_html_e( 'Log in', 'customer-email-verification' ); ?>
							</button>
							<?php if ( '' !== $error_msg ) : ?>
								<p class="cev-2fa-feedback is-error" style="margin-top:10px;">
									<?php echo esc_html( $error_msg ); ?>
								</p>
							<?php endif; ?>
						</form>
						<p style="font-size:13px;color:#64748b;margin-top:16px;max-width:520px;">
							<?php esc_html_e( "Can't access your authenticator app? Type one of your recovery codes above instead (10 characters with a dash).", 'customer-email-verification' ); ?>
						</p>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php
		get_footer();
	}

	/* ----------------------------------------------------------------
	 * Trusted-browser cookie (opt-in).
	 * --------------------------------------------------------------*/

	/**
	 * Does the request carry a valid "remember this browser" cookie for
	 * this user?
	 *
	 * @param int $user_id WP user ID.
	 * @return bool
	 */
	private function has_trusted_cookie( $user_id ) {
		if ( empty( $_COOKIE[ self::REMEMBER_COOKIE ] ) ) {
			return false;
		}
		// Cookie format is `base64url(payload).hmac` — a single-line ASCII
		// string. sanitize_text_field() is safe: it only trims whitespace
		// and strips tags, neither of which would appear in a legitimate
		// cookie value. `verify_cookie_payload()` then HMAC-checks the
		// signature, so tampering is rejected cryptographically.
		$raw     = sanitize_text_field( wp_unslash( $_COOKIE[ self::REMEMBER_COOKIE ] ) );
		$payload = $this->verify_cookie_payload( $raw );
		if ( ! $payload ) {
			return false;
		}
		return ( (int) $payload['uid'] === (int) $user_id && $payload['exp'] > time() );
	}

	/**
	 * Issue the trusted-browser cookie.
	 *
	 * @param int $user_id WP user ID.
	 * @param int $days    Validity in days.
	 * @return void
	 */
	private function set_trusted_cookie( $user_id, $days ) {
		$exp     = time() + ( $days * DAY_IN_SECONDS );
		$payload = array( 'uid' => (int) $user_id, 'exp' => $exp );
		$body    = wp_json_encode( $payload );
		$sig     = hash_hmac( 'sha256', $body, wp_salt( 'auth' ) );
		$value   = rtrim( strtr( base64_encode( $body ), '+/', '-_' ), '=' ) . '.' . $sig;
		$cookie_path   = defined( 'COOKIEPATH' ) ? (string) constant( 'COOKIEPATH' ) : '';
		$cookie_domain = defined( 'COOKIE_DOMAIN' ) ? (string) constant( 'COOKIE_DOMAIN' ) : '';
		setcookie( self::REMEMBER_COOKIE, $value, $exp, $cookie_path, $cookie_domain, is_ssl(), true );
	}

	/**
	 * Verify the cookie signature.
	 *
	 * @param string $raw Raw cookie value.
	 * @return array|false Decoded payload or false on tamper / bad format.
	 */
	private function verify_cookie_payload( $raw ) {
		if ( ! is_string( $raw ) || false === strpos( $raw, '.' ) ) {
			return false;
		}
		list( $b64, $sig ) = explode( '.', $raw, 2 );
		$body              = base64_decode( strtr( $b64, '-_', '+/' ), true ); // phpcs:ignore WordPress.PHP.DiscouragedFunctions.obfuscation_base64_decode -- needed for cookie decoding.
		if ( false === $body ) {
			return false;
		}
		$expected = hash_hmac( 'sha256', $body, wp_salt( 'auth' ) );
		if ( ! hash_equals( $expected, (string) $sig ) ) {
			return false;
		}
		$decoded = json_decode( $body, true );
		return is_array( $decoded ) ? $decoded : false;
	}

	/* ----------------------------------------------------------------
	 * Internals.
	 * --------------------------------------------------------------*/

	/**
	 * Load + validate a parked session by token.
	 *
	 * @param string $token Token.
	 * @return array|false  Parked data or false.
	 */
	private function load_parked( $token ) {
		if ( '' === $token || strlen( $token ) > 64 ) {
			return false;
		}
		$data = get_transient( self::PARK_PREFIX . $token );
		if ( ! is_array( $data ) || empty( $data['user_id'] ) ) {
			return false;
		}
		return $data;
	}
}
