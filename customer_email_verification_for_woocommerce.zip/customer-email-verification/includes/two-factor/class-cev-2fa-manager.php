<?php
/**
 * 2FA Manager — orchestrates Authenticator-App enrollment and verification.
 *
 * High-level coordinator. Knows nothing about TOTP math (delegates to
 * CEV_TOTP) and nothing about UI (delegates to setup/login classes).
 * Owns:
 *   - Per-user enrollment state (user meta).
 *   - Recovery codes (10 single-use codes, hashed at rest).
 *   - Replay-protection counter.
 *   - Role-policy gate (which users MUST have 2FA).
 *   - Grace-period bookkeeping for new enrollments.
 *
 * @package Customer_Email_Verification_Pro
 * @since   2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * CEV_2FA_Manager — singleton.
 */
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
class CEV_2FA_Manager {

	/* ---------- Meta keys ---------- */

	const META_ENABLED         = 'cev_2fa_enabled';
	const META_SECRET          = 'cev_2fa_secret_b32';
	const META_PENDING_SECRET  = 'cev_2fa_pending_secret'; // gitleaks:allow -- Meta-key name where the pending TOTP secret is stored during enrolment; not a secret value.
	const META_LAST_STEP       = 'cev_2fa_last_step';
	const META_RECOVERY_HASHES = 'cev_2fa_recovery_hashes';
	const META_ENABLED_AT      = 'cev_2fa_enabled_at';
	const META_ENROLLMENT_DUE  = 'cev_2fa_enrollment_due';

	/** Number of backup recovery codes generated at enrollment. */
	const RECOVERY_CODE_COUNT = 10;

	/** Recovery code length (chars, hex). */
	const RECOVERY_CODE_LEN = 10;

	/**
	 * Singleton instance.
	 *
	 * @var CEV_2FA_Manager|null
	 */
	private static $instance = null;

	/**
	 * Get singleton.
	 *
	 * @return CEV_2FA_Manager
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/* ----------------------------------------------------------------
	 * Settings helpers — read once and cached for the request.
	 * --------------------------------------------------------------*/

	/**
	 * Is the master 2FA toggle on?
	 *
	 * @return bool
	 */
	public function is_enabled_globally() {
		return ( 1 === (int) cev_pro()->function->cev_pro_admin_settings( 'cev_enable_2fa', 0 ) );
	}

	/**
	 * Number of days to "trust" a device after a successful 2FA
	 * verification. While the trust cookie is valid, the user can log
	 * in without being asked for a 6-digit code on the same browser.
	 *
	 * The setting key is `cev_2fa_grace_days` (kept for backward
	 * compatibility with existing installs). 0 means "always ask at
	 * every login".
	 *
	 * @return int Days. 0 = no trust period.
	 */
	public function grace_days() {
		$days = (int) cev_pro()->function->cev_pro_admin_settings( 'cev_2fa_grace_days', 7 );
		return max( 0, $days );
	}

	/* ----------------------------------------------------------------
	 * Role-policy gate.
	 *
	 * Same option keys as Phase 1 (`cev_login_auth_enforcement` +
	 * `cev_login_auth_roles`) but here they decide who must use the
	 * Authenticator App. They no longer affect the email-OTP login auth
	 * flow (that was reverted to its legacy hard-coded skip).
	 * --------------------------------------------------------------*/

	/**
	 * Does the role policy require 2FA for this user?
	 *
	 * @param int $user_id WP user ID.
	 * @return bool
	 */
	public function policy_requires( $user_id ) {
		$user_id = (int) $user_id;
		if ( $user_id <= 0 ) {
			return false;
		}

		$user = get_userdata( $user_id );
		if ( ! $user || empty( $user->roles ) ) {
			return false;
		}

		$policy = cev_pro()->function->cev_pro_admin_settings( 'cev_login_auth_enforcement', 'excluded_roles' );
		$roles  = cev_pro()->function->cev_pro_admin_settings( 'cev_login_auth_roles', array() );

		// `multiple_select` field stores as { 'role_key' => '1' } — pick
		// only the truthy keys so the policy checks against the selected
		// subset.
		$selected = array();
		if ( is_array( $roles ) ) {
			foreach ( $roles as $role_key => $val ) {
				if ( '1' === (string) $val || 1 === $val ) {
					$selected[] = (string) $role_key;
				}
			}
		}

		// Backward-compat: empty selection on `excluded_roles` falls back
		// to the legacy "skip Administrator + Editor" behaviour.
		if ( 'excluded_roles' === $policy && empty( $selected ) ) {
			$selected = array( 'administrator', 'editor' );
		}

		// Policy evaluation.
		switch ( $policy ) {
			case 'all_users':
				$required = true;
				break;

			case 'roles_only':
				$required = (bool) array_intersect( $user->roles, $selected );
				break;

			case 'excluded_roles':
			default:
				$required = ! array_intersect( $user->roles, $selected );
				break;
		}

		/**
		 * Filter the final policy decision.
		 *
		 * @param bool   $required Whether 2FA is required for this user.
		 * @param int    $user_id  WP user ID.
		 * @param string $policy   Active policy.
		 * @param array  $selected Selected role slugs.
		 */
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		return (bool) apply_filters( 'cev_2fa_policy_requires', $required, $user_id, $policy, $selected );
	}

	/* ----------------------------------------------------------------
	 * Enrollment state.
	 * --------------------------------------------------------------*/

	/**
	 * Has this user completed Authenticator App setup?
	 *
	 * @param int $user_id WP user ID.
	 * @return bool
	 */
	public function is_enrolled( $user_id ) {
		$flag = get_user_meta( (int) $user_id, self::META_ENABLED, true );
		return ( '1' === (string) $flag );
	}

	/**
	 * Get the active (post-enrollment) Base32 secret. Returns '' if not
	 * enrolled.
	 *
	 * @param int $user_id WP user ID.
	 * @return string Base32 secret or empty string.
	 */
	public function get_secret( $user_id ) {
		return (string) get_user_meta( (int) $user_id, self::META_SECRET, true );
	}

	/**
	 * Generate a fresh pending secret and store it as user meta. Returns
	 * the secret so the caller can render the QR code.
	 *
	 * Re-running this overwrites any earlier pending secret — that's
	 * intentional, since a user who abandoned setup might want a fresh
	 * code.
	 *
	 * @param int $user_id WP user ID.
	 * @return string Base32 secret.
	 */
	public function start_setup( $user_id ) {
		$secret = CEV_TOTP::generate_secret();
		update_user_meta( (int) $user_id, self::META_PENDING_SECRET, $secret );
		return $secret;
	}

	/**
	 * Verify the user's first code against the pending secret. On success,
	 * promote pending → active, generate recovery codes, mark enrolled.
	 *
	 * @param int    $user_id WP user ID.
	 * @param string $code    6-digit code from the authenticator app.
	 * @return array|WP_Error On success: { 'recovery_codes' => string[10] }.
	 *                         On failure: WP_Error with `invalid_code` or
	 *                         `no_pending_secret`.
	 */
	public function complete_setup( $user_id, $code ) {
		$user_id = (int) $user_id;
		$pending = (string) get_user_meta( $user_id, self::META_PENDING_SECRET, true );

		if ( '' === $pending ) {
			return new WP_Error(
				'no_pending_secret',
				__( 'No setup in progress. Please scan the QR code first.', 'customer-email-verification' )
			);
		}

		$matched_step = CEV_TOTP::verify( $pending, $code, 0 );
		if ( false === $matched_step ) {
			return new WP_Error(
				'invalid_code',
				__( 'That code is incorrect. Make sure your phone\'s clock is set to "Network time" and try the next code.', 'customer-email-verification' )
			);
		}

		// Promote pending → active.
		update_user_meta( $user_id, self::META_SECRET, $pending );
		update_user_meta( $user_id, self::META_LAST_STEP, $matched_step );
		update_user_meta( $user_id, self::META_ENABLED, '1' );
		update_user_meta( $user_id, self::META_ENABLED_AT, time() );
		delete_user_meta( $user_id, self::META_PENDING_SECRET );
		delete_user_meta( $user_id, self::META_ENROLLMENT_DUE );

		// Generate + persist recovery codes (return plaintext to caller —
		// will be shown ONCE in the UI, never again).
		$plaintext_codes = $this->generate_recovery_codes();
		$hashes          = array_map( array( $this, 'hash_recovery_code' ), $plaintext_codes );
		update_user_meta( $user_id, self::META_RECOVERY_HASHES, $hashes );

		/**
		 * Fires after a user successfully enrols in Authenticator App 2FA.
		 *
		 * @param int $user_id WP user ID.
		 */
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		do_action( 'cev_2fa_user_enrolled', $user_id );

		// Analytics: record the enrolment.
		if ( method_exists( cev_pro()->function, 'log_event' ) ) {
			$user = get_userdata( $user_id );
			cev_pro()->function->log_event(
				$user ? $user->user_email : '',
				'2fa_enrolled',
				'2fa',
				array(),
				$user_id
			);
		}

		return array(
			'recovery_codes' => $plaintext_codes,
		);
	}

	/**
	 * Verify a code at login time. On success, advances the replay-
	 * protection counter so the same code can't be reused.
	 *
	 * @param int    $user_id WP user ID.
	 * @param string $code    6-digit code.
	 * @return bool True on success.
	 */
	public function verify_login_code( $user_id, $code ) {
		$user_id = (int) $user_id;
		$secret  = $this->get_secret( $user_id );
		if ( '' === $secret ) {
			return false;
		}

		$last_step    = (int) get_user_meta( $user_id, self::META_LAST_STEP, true );
		$matched_step = CEV_TOTP::verify( $secret, $code, $last_step );

		if ( false === $matched_step ) {
			return false;
		}

		update_user_meta( $user_id, self::META_LAST_STEP, $matched_step );
		return true;
	}

	/**
	 * Try to consume one recovery code. On match, the code is deleted
	 * from the user's stored hashes (single-use).
	 *
	 * @param int    $user_id WP user ID.
	 * @param string $code    Plaintext recovery code as typed.
	 * @return bool True if the code was valid and has been consumed.
	 */
	public function consume_recovery_code( $user_id, $code ) {
		$user_id = (int) $user_id;
		$hashes  = (array) get_user_meta( $user_id, self::META_RECOVERY_HASHES, true );
		if ( empty( $hashes ) ) {
			return false;
		}

		$normalized = $this->normalize_recovery_code( $code );
		if ( '' === $normalized ) {
			return false;
		}

		foreach ( $hashes as $i => $hash ) {
			if ( wp_check_password( $normalized, $hash ) ) {
				unset( $hashes[ $i ] );
				update_user_meta( $user_id, self::META_RECOVERY_HASHES, array_values( $hashes ) );
				return true;
			}
		}

		return false;
	}

	/**
	 * Disable 2FA for a user — wipes the secret, recovery codes, and
	 * enrollment flag. Used by:
	 *   - The user themselves clicking "Disable 2FA" on their account page.
	 *   - An administrator clicking "Reset 2FA" on a user's profile (e.g.
	 *     to help a user who lost their phone AND ran out of recovery codes).
	 *
	 * @param int $user_id WP user ID.
	 * @return void
	 */
	public function disable( $user_id ) {
		$user_id = (int) $user_id;
		delete_user_meta( $user_id, self::META_ENABLED );
		delete_user_meta( $user_id, self::META_SECRET );
		delete_user_meta( $user_id, self::META_PENDING_SECRET );
		delete_user_meta( $user_id, self::META_LAST_STEP );
		delete_user_meta( $user_id, self::META_RECOVERY_HASHES );
		delete_user_meta( $user_id, self::META_ENABLED_AT );
		delete_user_meta( $user_id, self::META_ENROLLMENT_DUE );

		/**
		 * Fires after a user's 2FA enrollment is wiped.
		 *
		 * @param int $user_id WP user ID.
		 */
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		do_action( 'cev_2fa_user_disabled', $user_id );
	}

	/**
	 * Re-generate recovery codes (replaces the old set entirely). Returns
	 * plaintext codes for one-time display.
	 *
	 * @param int $user_id WP user ID.
	 * @return string[]|WP_Error 10 plaintext codes on success.
	 */
	public function regenerate_recovery_codes( $user_id ) {
		$user_id = (int) $user_id;
		if ( ! $this->is_enrolled( $user_id ) ) {
			return new WP_Error(
				'not_enrolled',
				__( 'You must complete 2FA setup before regenerating recovery codes.', 'customer-email-verification' )
			);
		}

		$plaintext = $this->generate_recovery_codes();
		$hashes    = array_map( array( $this, 'hash_recovery_code' ), $plaintext );
		update_user_meta( $user_id, self::META_RECOVERY_HASHES, $hashes );

		return $plaintext;
	}

	/**
	 * How many recovery codes does this user have left?
	 *
	 * @param int $user_id WP user ID.
	 * @return int
	 */
	public function recovery_codes_remaining( $user_id ) {
		$hashes = (array) get_user_meta( (int) $user_id, self::META_RECOVERY_HASHES, true );
		return count( $hashes );
	}

	/* ----------------------------------------------------------------
	 * Login enforcement.
	 *
	 * The "setup grace period" concept (delaying enrolment for N days
	 * after the policy starts applying) was removed when the
	 * `cev_2fa_grace_days` setting was repurposed to mean "trust this
	 * device for N days after a successful verification".
	 *
	 * Result: required users must enrol at the FIRST login after the
	 * master toggle is on. There's no grace window any more.
	 * --------------------------------------------------------------*/

	/**
	 * Stub kept for backward-compatibility with any external code that
	 * checks "are we still in the setup-delay grace period". Always
	 * false now — there is no setup grace.
	 *
	 * @param int $user_id Unused.
	 * @return false
	 */
	public function in_grace_period( $user_id ) {
		unset( $user_id ); // suppress unused-arg warnings.
		return false;
	}

	/**
	 * Should login be hard-blocked for this user right now?
	 *
	 * True when:
	 *   - 2FA master toggle is on
	 *   - Role policy requires this user
	 *   - User has NOT completed enrolment
	 *
	 * @param int $user_id WP user ID.
	 * @return bool
	 */
	public function should_block_login( $user_id ) {
		if ( ! $this->is_enabled_globally() ) {
			return false;
		}
		if ( $this->is_enrolled( (int) $user_id ) ) {
			return false;
		}
		return $this->policy_requires( (int) $user_id );
	}

	/* ----------------------------------------------------------------
	 * Recovery code helpers.
	 * --------------------------------------------------------------*/

	/**
	 * Generate N random plaintext recovery codes formatted as
	 * "xxxxx-xxxxx" (10 hex chars, dash in the middle for readability).
	 *
	 * @return string[] Plaintext codes.
	 */
	private function generate_recovery_codes() {
		$codes = array();
		for ( $i = 0; $i < self::RECOVERY_CODE_COUNT; $i++ ) {
			$bytes = function_exists( 'random_bytes' ) ? random_bytes( 5 ) : openssl_random_pseudo_bytes( 5 );
			$hex   = bin2hex( $bytes );
			$codes[] = substr( $hex, 0, 5 ) . '-' . substr( $hex, 5, 5 );
		}
		return $codes;
	}

	/**
	 * Normalise a user-typed recovery code so casing and hyphens don't
	 * cause false negatives.
	 *
	 * @param string $code Raw user input.
	 * @return string Normalised lowercase hex with hyphen.
	 */
	private function normalize_recovery_code( $code ) {
		$only_hex = strtolower( preg_replace( '/[^0-9a-f]/i', '', (string) $code ) );
		if ( strlen( $only_hex ) !== self::RECOVERY_CODE_LEN ) {
			return '';
		}
		return substr( $only_hex, 0, 5 ) . '-' . substr( $only_hex, 5, 5 );
	}

	/**
	 * Hash a recovery code with WP's password-hashing layer (bcrypt-ish via
	 * PasswordHash on older WP, native password_hash() on modern WP).
	 *
	 * @param string $code Plaintext code.
	 * @return string Hash.
	 */
	private function hash_recovery_code( $code ) {
		return wp_hash_password( $code );
	}
}
