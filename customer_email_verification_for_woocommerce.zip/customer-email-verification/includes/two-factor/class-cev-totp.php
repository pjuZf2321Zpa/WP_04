<?php
/**
 * TOTP (Time-based One-Time Password) — RFC 6238 implementation.
 *
 * Pure-PHP TOTP generator and verifier. No third-party dependency, no
 * Composer. Compatible with Google Authenticator, Authy, Microsoft
 * Authenticator, 1Password, Bitwarden, and every other RFC 6238 client.
 *
 * Defaults:
 *   - 6-digit codes
 *   - 30-second time-step
 *   - SHA1 HMAC (the format every authenticator app understands by default;
 *     SHA256/SHA512 work too but Google Authenticator on iOS used to
 *     silently fall back to SHA1, so we stay on SHA1 for compatibility).
 *   - 160-bit (20-byte) random secret encoded as Base32.
 *
 * @package Customer_Email_Verification_Pro
 * @since   2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * CEV_TOTP — stateless RFC 6238 helper.
 *
 * All public methods are static. Storage of the secret + replay-protection
 * counter lives in CEV_2FA_Manager (which calls into this class).
 */
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
class CEV_TOTP {

	/** Default code length in digits. */
	const DIGITS = 6;

	/** Default time-step in seconds. */
	const PERIOD = 30;

	/** HMAC algorithm — kept on SHA1 for maximum app compatibility. */
	const ALGO = 'sha1';

	/**
	 * Generate a fresh 160-bit random secret, returned Base32-encoded.
	 *
	 * @return string Base32-encoded secret (32 chars, no padding).
	 */
	public static function generate_secret() {
		// 20 bytes = 160 bits, the RFC 6238 recommendation.
		$random_bytes = function_exists( 'random_bytes' ) ? random_bytes( 20 ) : openssl_random_pseudo_bytes( 20 );
		return self::base32_encode( $random_bytes );
	}

	/**
	 * Build an `otpauth://totp/...` provisioning URI for the QR code.
	 *
	 * The user's authenticator app scans this URI and stores the secret
	 * along with a human-readable label (issuer + account name).
	 *
	 * Format (RFC: https://github.com/google/google-authenticator/wiki/Key-Uri-Format):
	 *   otpauth://totp/Issuer:account@example.com?secret=...&issuer=Issuer&algorithm=SHA1&digits=6&period=30
	 *
	 * @param string $secret_b32  Base32-encoded secret.
	 * @param string $account     Account label — usually the user's email.
	 * @param string $issuer      Issuer label — usually the site name.
	 * @return string Full otpauth:// URI ready to be QR-encoded.
	 */
	public static function provisioning_uri( $secret_b32, $account, $issuer ) {
		// Trim and rawurlencode each label segment per the spec.
		$issuer  = trim( wp_strip_all_tags( $issuer ) );
		$account = trim( wp_strip_all_tags( $account ) );

		// Path segment: "Issuer:account" (colon is literal in the URI spec).
		$label = rawurlencode( $issuer ) . ':' . rawurlencode( $account );

		$query = http_build_query(
			array(
				'secret'    => $secret_b32,
				'issuer'    => $issuer,
				'algorithm' => strtoupper( self::ALGO ),
				'digits'    => self::DIGITS,
				'period'    => self::PERIOD,
			),
			'',
			'&',
			PHP_QUERY_RFC3986
		);

		return 'otpauth://totp/' . $label . '?' . $query;
	}

	/**
	 * Generate the TOTP code for a given Base32 secret at a given timestamp.
	 *
	 * Used internally by verify(); exposed publicly for tests.
	 *
	 * @param string   $secret_b32 Base32-encoded secret.
	 * @param int|null $timestamp  Unix timestamp (defaults to now).
	 * @return string Zero-padded 6-digit code.
	 */
	public static function code_at( $secret_b32, $timestamp = null ) {
		if ( null === $timestamp ) {
			$timestamp = time();
		}
		$counter = (int) floor( $timestamp / self::PERIOD );
		return self::hotp_code( self::base32_decode( $secret_b32 ), $counter );
	}

	/**
	 * Verify a user-supplied code against the stored secret.
	 *
	 * Accepts a small ±window of time-steps to tolerate clock drift between
	 * the user's phone and the server. RFC 6238 §5.2 recommends a window
	 * of 1 (= ±30 s) which we use by default.
	 *
	 * Replay-protection: the caller passes `$last_used_step`. If the
	 * matched step is <= that, we reject (prevents the same code being
	 * replayed within its 30s validity).
	 *
	 * @param string   $secret_b32     Base32-encoded secret.
	 * @param string   $user_code      6-digit code typed by the user.
	 * @param int      $last_used_step Highest time-step previously accepted (0 = none yet).
	 * @param int      $window         Allowed ± steps for clock drift.
	 * @param int|null $timestamp      Unix timestamp (defaults to now).
	 * @return int|false  Time-step that matched (caller stores it as the
	 *                    new last_used_step), or false on failure.
	 */
	public static function verify( $secret_b32, $user_code, $last_used_step = 0, $window = 1, $timestamp = null ) {
		if ( null === $timestamp ) {
			$timestamp = time();
		}

		// Strip whitespace + non-digits in case the user pasted "123 456".
		$user_code = preg_replace( '/\D/', '', (string) $user_code );
		if ( strlen( $user_code ) !== self::DIGITS ) {
			return false;
		}

		$current_step = (int) floor( $timestamp / self::PERIOD );
		$secret_raw   = self::base32_decode( $secret_b32 );
		if ( '' === $secret_raw || false === $secret_raw ) {
			return false;
		}

		// Try each step in the [-window, +window] range. We use
		// hash_equals() inside hotp_code() comparison to keep the timing
		// of the inner check constant.
		for ( $offset = -$window; $offset <= $window; $offset++ ) {
			$step = $current_step + $offset;
			if ( $step <= $last_used_step ) {
				// Replay protection — already used.
				continue;
			}
			$candidate = self::hotp_code( $secret_raw, $step );
			if ( hash_equals( $candidate, $user_code ) ) {
				return $step;
			}
		}

		return false;
	}

	/**
	 * Core HOTP computation (RFC 4226).
	 *
	 * Used by both `code_at()` and `verify()`. Takes the raw (binary)
	 * secret + counter, returns the zero-padded code string.
	 *
	 * @param string $secret_raw Binary (already-decoded) secret.
	 * @param int    $counter    Time-step counter.
	 * @return string Zero-padded 6-digit code.
	 */
	private static function hotp_code( $secret_raw, $counter ) {
		// Counter packed as big-endian 64-bit integer.
		// pack('N*', high, low) writes two big-endian uint32s back-to-back,
		// which equals one big-endian uint64. We split because PHP's pack()
		// has no portable 'J' (uint64 BE) on 32-bit builds.
		$high = ( $counter >> 32 ) & 0xFFFFFFFF;
		$low  = $counter & 0xFFFFFFFF;
		$bin  = pack( 'N*', $high, $low );

		$hash = hash_hmac( self::ALGO, $bin, $secret_raw, true );

		// Dynamic truncation per RFC 4226 §5.3.
		$offset = ord( substr( $hash, -1 ) ) & 0x0F;
		$code   = (
			( ( ord( $hash[ $offset ] ) & 0x7F ) << 24 ) |
			( ( ord( $hash[ $offset + 1 ] ) & 0xFF ) << 16 ) |
			( ( ord( $hash[ $offset + 2 ] ) & 0xFF ) << 8 ) |
			( ord( $hash[ $offset + 3 ] ) & 0xFF )
		);

		return str_pad( (string) ( $code % ( 10 ** self::DIGITS ) ), self::DIGITS, '0', STR_PAD_LEFT );
	}

	/* ----------------------------------------------------------------
	 * Base32 helpers (RFC 4648 — alphabet: A-Z, 2-7).
	 *
	 * We don't depend on any extension; mbstring is not required.
	 * --------------------------------------------------------------*/

	/**
	 * Base32 alphabet — the standard RFC 4648 set used by every
	 * authenticator app.
	 *
	 * @var string
	 */
	const B32_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

	/**
	 * Base32-encode a binary string.
	 *
	 * Output is uppercase, no padding (matches what authenticator apps
	 * expect). Spaces every 4 chars are a display convention added by the
	 * UI, not by the encoder.
	 *
	 * @param string $bin Raw binary input.
	 * @return string Base32 string (uppercase, no `=` padding).
	 */
	public static function base32_encode( $bin ) {
		if ( '' === $bin ) {
			return '';
		}

		$bits = '';
		$len  = strlen( $bin );
		for ( $i = 0; $i < $len; $i++ ) {
			$bits .= str_pad( decbin( ord( $bin[ $i ] ) ), 8, '0', STR_PAD_LEFT );
		}

		$out = '';
		// Pad with trailing zero bits so total length is a multiple of 5.
		$pad_len = ( 5 - ( strlen( $bits ) % 5 ) ) % 5;
		$bits   .= str_repeat( '0', $pad_len );

		$chunks = str_split( $bits, 5 );
		foreach ( $chunks as $chunk ) {
			$out .= self::B32_ALPHABET[ bindec( $chunk ) ];
		}

		return $out;
	}

	/**
	 * Decode a Base32 string back to binary.
	 *
	 * Tolerant: lowercase + whitespace + `=` padding are accepted and
	 * stripped. Returns empty string on invalid input.
	 *
	 * @param string $b32 Base32-encoded string.
	 * @return string Raw binary, or '' on failure.
	 */
	public static function base32_decode( $b32 ) {
		// Normalise: uppercase, drop whitespace + padding.
		$b32 = strtoupper( preg_replace( '/[\s=]+/', '', (string) $b32 ) );
		if ( '' === $b32 ) {
			return '';
		}

		// Reject any character outside the alphabet.
		if ( preg_match( '/[^A-Z2-7]/', $b32 ) ) {
			return '';
		}

		$bits = '';
		$len  = strlen( $b32 );
		for ( $i = 0; $i < $len; $i++ ) {
			$index = strpos( self::B32_ALPHABET, $b32[ $i ] );
			if ( false === $index ) {
				return '';
			}
			$bits .= str_pad( decbin( $index ), 5, '0', STR_PAD_LEFT );
		}

		// Walk byte-by-byte; drop any trailing partial byte (encoder padding).
		$bin       = '';
		$bit_count = strlen( $bits );
		for ( $i = 0; $i + 8 <= $bit_count; $i += 8 ) {
			$bin .= chr( bindec( substr( $bits, $i, 8 ) ) );
		}

		return $bin;
	}
}
