<?php
/**
 * QR Code generator — pure PHP, server-side, outputs inline SVG.
 *
 * This replaces the JS QR encoder.  The advantage of doing it on the
 * server: we control every byte the browser receives, no client-side
 * library to keep in sync, and PHP is easier to unit-test.
 *
 * Algorithm: ISO/IEC 18004 (port of Project Nayuki's reference
 * implementation).  Supports byte mode + versions 1..10 + all four ECL
 * levels + best-mask selection.  That covers every otpauth:// URI we
 * encode (typical 90–150 bytes ⇒ versions 5–8 at ECL M).
 *
 * Usage:
 *   $svg = CEV_QR::svg( $text, 240, $ecl );
 *
 * @package Customer_Email_Verification_Pro
 * @since   2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * CEV_QR — stateless QR encoder.
 */
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
class CEV_QR {

	/* ECL constants — match the spec's format-info codes. */
	const ECL_L = 1;
	const ECL_M = 0;
	const ECL_Q = 3;
	const ECL_H = 2;

	/**
	 * Generate the QR as a PNG data URI — `data:image/png;base64,...`.
	 *
	 * This is the preferred path because PNG is binary + pixel-exact:
	 * no SVG rendering quirks, no fill-rule issues, no anti-aliasing
	 * surprises. If the GD extension isn't available, the caller falls
	 * back to ::svg().
	 *
	 * @param string $text     Text to encode (UTF-8).
	 * @param int    $size_px  Target image width/height (square).
	 * @param int    $ecl      One of the ECL_* constants. Default ECL_M.
	 * @return string|false   data: URI ready for an <img src=…>, or false
	 *                        if GD is missing.
	 */
	public static function png_data_uri( $text, $size_px = 256, $ecl = self::ECL_M ) {
		if ( ! function_exists( 'imagecreatetruecolor' ) ) {
			return false;
		}

		$mat = self::build_matrix( $text, $ecl );
		return self::render_png_data_uri( $mat, $size_px );
	}

	/**
	 * Generate an SVG string for the given text.
	 *
	 * @param string $text     Text to encode (UTF-8).
	 * @param int    $size_px  Target SVG width/height in px (square).
	 * @param int    $ecl      One of the ECL_* constants. Default ECL_M.
	 * @return string  Inline SVG markup.
	 */
	public static function svg( $text, $size_px = 240, $ecl = self::ECL_M ) {
		$mat = self::build_matrix( $text, $ecl );
		return self::render_svg( $mat, $size_px );
	}

	/**
	 * Build the final QR matrix (function patterns + data + best mask +
	 * format/version info) for the given text. Used by both svg() and
	 * png_data_uri() so they share the same encoding logic — no risk
	 * of the two output paths drifting.
	 *
	 * @param string $text  Text to encode.
	 * @param int    $ecl   ECL constant.
	 * @return bool[][]     2-D matrix of true (dark) / false (light).
	 */
	private static function build_matrix( $text, $ecl ) {
		$bytes   = self::utf8_bytes( $text );
		$version = self::pick_version( count( $bytes ), $ecl );
		$size    = 17 + 4 * $version;

		$data  = self::build_data( $bytes, $version, $ecl );
		$inter = self::interleave( $data, $version, $ecl );

		// Try every mask, keep the lowest-penalty matrix.
		$best_mat = null;
		$best_pen = PHP_INT_MAX;
		for ( $m = 0; $m < 8; $m++ ) {
			$mat = self::build_blank( $size );
			$fix = self::build_blank( $size );
			self::draw_function_patterns( $mat, $fix, $version );
			self::draw_data( $mat, $fix, $inter );
			self::apply_mask( $mat, $fix, $m );
			self::draw_format( $mat, $ecl, $m );
			self::draw_version( $mat, $version );

			$pen = self::penalty( $mat );
			if ( $pen < $best_pen ) {
				$best_pen = $pen;
				$best_mat = $mat;
			}
		}

		return $best_mat;
	}

	/**
	 * Render the matrix as a PNG data URI using GD.
	 *
	 * Pixel-exact: each module = an integer pixel block. We size the
	 * image so module_px is always >= 4 (enough for any phone camera
	 * to focus on at typical scanning distance).
	 *
	 * @param bool[][] $mat       QR matrix.
	 * @param int      $target_px Approx target image width.
	 * @return string `data:image/png;base64,...`
	 */
	private static function render_png_data_uri( $mat, $target_px ) {
		$size  = count( $mat );
		$quiet = 4;
		$total = $size + 2 * $quiet;

		$module_px = max( 4, intval( $target_px / $total ) );
		$img_px    = $module_px * $total;

		$img = imagecreatetruecolor( $img_px, $img_px );
		// Disable anti-aliasing on filled rects — we want hard edges.
		imageantialias( $img, false );

		$white = imagecolorallocate( $img, 255, 255, 255 );
		$black = imagecolorallocate( $img, 0, 0, 0 );

		// Fill background (also covers quiet zone).
		imagefilledrectangle( $img, 0, 0, $img_px - 1, $img_px - 1, $white );

		// Paint each dark module as a solid black square.
		for ( $y = 0; $y < $size; $y++ ) {
			for ( $x = 0; $x < $size; $x++ ) {
				if ( $mat[ $y ][ $x ] ) {
					$x1 = ( $x + $quiet ) * $module_px;
					$y1 = ( $y + $quiet ) * $module_px;
					$x2 = $x1 + $module_px - 1;
					$y2 = $y1 + $module_px - 1;
					imagefilledrectangle( $img, $x1, $y1, $x2, $y2, $black );
				}
			}
		}

		ob_start();
		imagepng( $img );
		$png = ob_get_clean();
		// No imagedestroy() — deprecated since PHP 8.5 (GD frees the image when
		// $img goes out of scope on return); it was a no-op on PHP 8.0+ anyway.

		return 'data:image/png;base64,' . base64_encode( $png );
	}

	/* ----------------------------------------------------------------
	 * Capacity / block tables (versions 1..10) for byte mode.
	 *
	 * Each cell: [ec_codewords_per_block, g1_blocks, g1_dc, g2_blocks, g2_dc].
	 * Indexed [version-1][ECL_IDX[ecl]].
	 * --------------------------------------------------------------*/
	private static $ECL_IDX = array( 1 => 0, 0 => 1, 3 => 2, 2 => 3 );

	private static $TABLE = array(
		// v1
		array( array( 7, 1, 19, 0, 0 ), array( 10, 1, 16, 0, 0 ), array( 13, 1, 13, 0, 0 ), array( 17, 1, 9, 0, 0 ) ),
		// v2
		array( array( 10, 1, 34, 0, 0 ), array( 16, 1, 28, 0, 0 ), array( 22, 1, 22, 0, 0 ), array( 28, 1, 16, 0, 0 ) ),
		// v3
		array( array( 15, 1, 55, 0, 0 ), array( 26, 1, 44, 0, 0 ), array( 18, 2, 17, 0, 0 ), array( 22, 2, 13, 0, 0 ) ),
		// v4
		array( array( 20, 1, 80, 0, 0 ), array( 18, 2, 32, 0, 0 ), array( 26, 2, 24, 0, 0 ), array( 16, 4, 9, 0, 0 ) ),
		// v5
		array( array( 26, 1,108, 0, 0 ), array( 24, 2, 43, 0, 0 ), array( 18, 2, 15, 2, 16 ), array( 22, 2, 11, 2, 12 ) ),
		// v6
		array( array( 18, 2, 68, 0, 0 ), array( 16, 4, 27, 0, 0 ), array( 24, 4, 19, 0, 0 ), array( 28, 4, 15, 0, 0 ) ),
		// v7
		array( array( 20, 2, 78, 0, 0 ), array( 18, 4, 31, 0, 0 ), array( 18, 2, 14, 4, 15 ), array( 26, 4, 13, 1, 14 ) ),
		// v8
		array( array( 24, 2, 97, 0, 0 ), array( 22, 2, 38, 2, 39 ), array( 22, 4, 18, 2, 19 ), array( 26, 4, 14, 2, 15 ) ),
		// v9
		array( array( 30, 2,116, 0, 0 ), array( 22, 3, 36, 2, 37 ), array( 20, 4, 16, 4, 17 ), array( 24, 4, 12, 4, 13 ) ),
		// v10
		array( array( 18, 2, 68, 2, 69 ), array( 26, 4, 43, 1, 44 ), array( 24, 6, 19, 2, 20 ), array( 28, 6, 15, 2, 16 ) ),
	);

	private static $ALIGN_POS = array(
		array(),
		array(),
		array( 6, 18 ),
		array( 6, 22 ),
		array( 6, 26 ),
		array( 6, 30 ),
		array( 6, 34 ),
		array( 6, 22, 38 ),
		array( 6, 24, 42 ),
		array( 6, 26, 46 ),
		array( 6, 28, 50 ),
	);

	/**
	 * Total data codewords for a (version, ecl) pair.
	 */
	private static function total_data_codewords( $version, $ecl ) {
		$row = self::$TABLE[ $version - 1 ][ self::$ECL_IDX[ $ecl ] ];
		return $row[ 1 ] * $row[ 2 ] + $row[ 3 ] * $row[ 4 ];
	}

	/**
	 * Pick the smallest version (1..10) that fits the data.
	 */
	private static function pick_version( $byte_len, $ecl ) {
		for ( $v = 1; $v <= 10; $v++ ) {
			$cap_bytes = self::total_data_codewords( $v, $ecl );
			$cc_bits   = ( $v < 10 ) ? 8 : 16;
			if ( 4 + $cc_bits + $byte_len * 8 + 4 <= $cap_bytes * 8 ) {
				return $v;
			}
		}
		throw new Exception( 'CEV QR: data too long for version ≤ 10' );
	}

	/* ----------------------------------------------------------------
	 * GF(256) tables — primitive polynomial 0x11D.
	 * --------------------------------------------------------------*/
	private static $EXP = null;
	private static $LOG = null;

	private static function gf_init() {
		if ( null !== self::$EXP ) {
			return;
		}
		self::$EXP = array_fill( 0, 256, 0 );
		self::$LOG = array_fill( 0, 256, 0 );
		$x = 1;
		for ( $i = 0; $i < 255; $i++ ) {
			self::$EXP[ $i ] = $x;
			self::$LOG[ $x ] = $i;
			$x <<= 1;
			if ( $x & 0x100 ) {
				$x ^= 0x11D;
			}
		}
		self::$EXP[ 255 ] = self::$EXP[ 0 ];
	}

	private static function gf_mul( $a, $b ) {
		if ( 0 === $a || 0 === $b ) {
			return 0;
		}
		return self::$EXP[ ( self::$LOG[ $a ] + self::$LOG[ $b ] ) % 255 ];
	}

	private static function rs_generator( $degree ) {
		self::gf_init();
		$poly = array( 1 );
		for ( $i = 0; $i < $degree; $i++ ) {
			$nxt = array_fill( 0, count( $poly ) + 1, 0 );
			for ( $k = 0; $k < count( $poly ); $k++ ) {
				$nxt[ $k ]     ^= $poly[ $k ];
				$nxt[ $k + 1 ] ^= self::gf_mul( $poly[ $k ], self::$EXP[ $i ] );
			}
			$poly = $nxt;
		}
		return $poly;
	}

	private static function rs_encode( $data, $ec_len ) {
		$gen = self::rs_generator( $ec_len );
		$res = $data;
		for ( $i = 0; $i < $ec_len; $i++ ) {
			$res[] = 0;
		}
		for ( $i = 0; $i < count( $data ); $i++ ) {
			$coef = $res[ $i ];
			if ( 0 === $coef ) {
				continue;
			}
			for ( $j = 0; $j < count( $gen ); $j++ ) {
				$res[ $i + $j ] ^= self::gf_mul( $gen[ $j ], $coef );
			}
		}
		return array_slice( $res, count( $data ) );
	}

	/* ----------------------------------------------------------------
	 * Build the data bit stream (byte mode).
	 * --------------------------------------------------------------*/
	private static function build_data( $bytes, $version, $ecl ) {
		$cap_bytes = self::total_data_codewords( $version, $ecl );
		$cc_bits   = ( $version < 10 ) ? 8 : 16;

		$bits = array();
		$push = function ( $v, $n ) use ( &$bits ) {
			for ( $i = $n - 1; $i >= 0; $i-- ) {
				$bits[] = ( $v >> $i ) & 1;
			}
		};

		$push( 0x4, 4 );                        // byte mode
		$push( count( $bytes ), $cc_bits );
		foreach ( $bytes as $b ) {
			$push( $b, 8 );
		}

		// Terminator: up to 4 zero bits.
		$rem = $cap_bytes * 8 - count( $bits );
		$term_len = min( 4, $rem );
		for ( $t = 0; $t < $term_len; $t++ ) {
			$bits[] = 0;
		}
		// Pad to byte boundary.
		while ( count( $bits ) % 8 !== 0 ) {
			$bits[] = 0;
		}
		// Pad bytes alternating 0xEC, 0x11.
		$pad_bytes = array( 0xEC, 0x11 );
		$pi = 0;
		while ( count( $bits ) < $cap_bytes * 8 ) {
			$pad = $pad_bytes[ $pi % 2 ];
			++$pi;
			for ( $b = 7; $b >= 0; $b-- ) {
				$bits[] = ( $pad >> $b ) & 1;
			}
		}

		// Pack bits to bytes.
		$out = array();
		$count = count( $bits );
		for ( $j = 0; $j < $count; $j += 8 ) {
			$v = 0;
			for ( $k = 0; $k < 8; $k++ ) {
				$v = ( $v << 1 ) | $bits[ $j + $k ];
			}
			$out[] = $v;
		}
		return $out;
	}

	/* ----------------------------------------------------------------
	 * Interleave data + EC blocks per ISO 18004.
	 * Handles mixed group-1 + group-2 block lengths.
	 * --------------------------------------------------------------*/
	private static function interleave( $data_bytes, $version, $ecl ) {
		$row = self::$TABLE[ $version - 1 ][ self::$ECL_IDX[ $ecl ] ];
		list( $ec_per_blk, $g1_blocks, $g1_dc, $g2_blocks, $g2_dc ) = $row;
		$ec_per_blk = (int) $ec_per_blk;
		$g1_blocks  = (int) $g1_blocks;
		$g1_dc      = (int) $g1_dc;
		$g2_blocks  = (int) $g2_blocks;
		$g2_dc      = (int) $g2_dc;
		$num_blocks = $g1_blocks + $g2_blocks;

		$data_blocks = array();
		$ec_blocks   = array();
		$off = 0;
		for ( $b = 0; $b < $num_blocks; $b++ ) {
			$len = ( $b < $g1_blocks ) ? $g1_dc : $g2_dc;
			$blk = array_slice( $data_bytes, $off, $len );
			$off += $len;
			$data_blocks[] = $blk;
			$ec_blocks[]   = self::rs_encode( $blk, $ec_per_blk );
		}

		$out = array();
		$max_dc = max( $g1_dc, $g2_dc );
		for ( $i = 0; $i < $max_dc; $i++ ) {
			for ( $b = 0; $b < $num_blocks; $b++ ) {
				if ( $i < count( $data_blocks[ $b ] ) ) {
					$out[] = $data_blocks[ $b ][ $i ];
				}
			}
		}
		for ( $i = 0; $i < $ec_per_blk; $i++ ) {
			for ( $b = 0; $b < $num_blocks; $b++ ) {
				$out[] = $ec_blocks[ $b ][ $i ];
			}
		}
		return $out;
	}

	/* ----------------------------------------------------------------
	 * Format-info BCH(15,5).  Generator 0x537, mask 0x5412.
	 * --------------------------------------------------------------*/
	private static function encode_format( $ecl, $mask ) {
		$format_bits = ( $ecl << 3 ) | $mask;
		$rem = $format_bits;
		for ( $i = 0; $i < 10; $i++ ) {
			$rem <<= 1;
			if ( $rem & 0x400 ) {
				$rem ^= 0x537;
			}
		}
		return ( ( $format_bits << 10 ) | ( $rem & 0x3FF ) ) ^ 0x5412;
	}

	/* ----------------------------------------------------------------
	 * Version-info BCH(18,6).  Generator 0x1F25.  Required for v >= 7.
	 * --------------------------------------------------------------*/
	private static function encode_version( $version ) {
		$rem = $version;
		for ( $i = 0; $i < 12; $i++ ) {
			$rem <<= 1;
			if ( $rem & 0x1000 ) {
				$rem ^= 0x1F25;
			}
		}
		return ( $version << 12 ) | ( $rem & 0xFFF );
	}

	/* ----------------------------------------------------------------
	 * Matrix construction.
	 * --------------------------------------------------------------*/
	private static function build_blank( $size ) {
		$mat = array();
		for ( $y = 0; $y < $size; $y++ ) {
			$mat[ $y ] = array_fill( 0, $size, false );
		}
		return $mat;
	}

	private static function draw_function_patterns( &$mat, &$fix, $version ) {
		$size = count( $mat );

		// Three finder patterns + 1-cell separator (only the cells that
		// fall inside the matrix — separator on the matrix edge is
		// implicitly off-matrix and skipped).
		$set_finder = function ( $cx, $cy ) use ( &$mat, &$fix, $size ) {
			for ( $dy = -1; $dy <= 7; $dy++ ) {
				for ( $dx = -1; $dx <= 7; $dx++ ) {
					$x = $cx + $dx;
					$y = $cy + $dy;
					if ( $x < 0 || $y < 0 || $x >= $size || $y >= $size ) {
						continue;
					}
					$on = false;
					if ( $dx >= 0 && $dx <= 6 && $dy >= 0 && $dy <= 6 ) {
						$m = max( abs( $dx - 3 ), abs( $dy - 3 ) );
						$on = ( $m <= 1 || 3 === $m );
					}
					$mat[ $y ][ $x ] = $on;
					$fix[ $y ][ $x ] = true;
				}
			}
		};
		$set_finder( 0, 0 );
		$set_finder( $size - 7, 0 );
		$set_finder( 0, $size - 7 );

		// Timing patterns — alternating starting with 1.
		for ( $i = 8; $i < $size - 8; $i++ ) {
			$on = ( 0 === $i % 2 );
			$mat[ 6 ][ $i ] = $on;
			$fix[ 6 ][ $i ] = true;
			$mat[ $i ][ 6 ] = $on;
			$fix[ $i ][ 6 ] = true;
		}

		// Alignment patterns — skip if center already fixed.
		$pos = self::$ALIGN_POS[ $version ];
		$pcount = count( $pos );
		for ( $ai = 0; $ai < $pcount; $ai++ ) {
			for ( $aj = 0; $aj < $pcount; $aj++ ) {
				$cy = $pos[ $ai ];
				$cx = $pos[ $aj ];
				if ( $fix[ $cy ][ $cx ] ) {
					continue;
				}
				for ( $dy = -2; $dy <= 2; $dy++ ) {
					for ( $dx = -2; $dx <= 2; $dx++ ) {
						$d = max( abs( $dx ), abs( $dy ) );
						$on = ( 0 === $d || 2 === $d );
						$mat[ $cy + $dy ][ $cx + $dx ] = $on;
						$fix[ $cy + $dy ][ $cx + $dx ] = true;
					}
				}
			}
		}

		// Reserve format-info cells.
		for ( $i = 0; $i <= 8; $i++ ) {
			$fix[ 8 ][ $i ] = true;
			$fix[ $i ][ 8 ] = true;
		}
		for ( $i = 0; $i <= 7; $i++ ) {
			$fix[ 8 ][ $size - 1 - $i ] = true;
			$fix[ $size - 1 - $i ][ 8 ] = true;
		}
		// Dark module.
		$mat[ $size - 8 ][ 8 ] = true;
		$fix[ $size - 8 ][ 8 ] = true;

		// Reserve version-info cells (v >= 7).
		if ( $version >= 7 ) {
			for ( $y = 0; $y < 6; $y++ ) {
				for ( $x = 0; $x < 3; $x++ ) {
					$fix[ $y ][ $size - 11 + $x ] = true;
					$fix[ $size - 11 + $x ][ $y ] = true;
				}
			}
		}
	}

	private static function draw_data( &$mat, &$fix, $codewords ) {
		$size = count( $mat );
		$bits = array();
		foreach ( $codewords as $cw ) {
			for ( $b = 7; $b >= 0; $b-- ) {
				$bits[] = ( $cw >> $b ) & 1;
			}
		}

		$bi = 0;
		$bit_count = count( $bits );
		for ( $right = $size - 1; $right >= 1; $right -= 2 ) {
			if ( 6 === $right ) {
				$right = 5;
			}
			for ( $vert = 0; $vert < $size; $vert++ ) {
				for ( $j = 0; $j < 2; $j++ ) {
					$x  = $right - $j;
					$up = ( ( ( $right + 1 ) & 2 ) === 0 );
					$y  = $up ? $size - 1 - $vert : $vert;
					if ( $fix[ $y ][ $x ] ) {
						continue;
					}
					if ( $bi < $bit_count ) {
						$mat[ $y ][ $x ] = ( 1 === $bits[ $bi ] );
						++$bi;
					} else {
						$mat[ $y ][ $x ] = false;
					}
				}
			}
		}
	}

	private static $MASK_FN = array(
		0 => array( __CLASS__, 'mask0' ),
		1 => array( __CLASS__, 'mask1' ),
		2 => array( __CLASS__, 'mask2' ),
		3 => array( __CLASS__, 'mask3' ),
		4 => array( __CLASS__, 'mask4' ),
		5 => array( __CLASS__, 'mask5' ),
		6 => array( __CLASS__, 'mask6' ),
		7 => array( __CLASS__, 'mask7' ),
	);
	public static function mask0( $y, $x ) {
		return 0 === ( ( $y + $x ) % 2 );
	}
	public static function mask1( $y, $x ) {
		return 0 === ( $y % 2 );
	}
	public static function mask2( $y, $x ) {
		return 0 === ( $x % 3 );
	}
	public static function mask3( $y, $x ) {
		return 0 === ( ( $y + $x ) % 3 );
	}
	public static function mask4( $y, $x ) {
		return 0 === ( ( intval( $y / 2 ) + intval( $x / 3 ) ) % 2 );
	}
	public static function mask5( $y, $x ) {
		return 0 === ( ( $y * $x ) % 2 ) + ( ( $y * $x ) % 3 );
	}
	public static function mask6( $y, $x ) {
		return 0 === ( ( ( $y * $x ) % 2 ) + ( ( $y * $x ) % 3 ) ) % 2;
	}
	public static function mask7( $y, $x ) {
		return 0 === ( ( ( $y + $x ) % 2 ) + ( ( $y * $x ) % 3 ) ) % 2;
	}

	private static function apply_mask( &$mat, &$fix, $mask ) {
		$size = count( $mat );
		$fn = self::$MASK_FN[ $mask ];
		for ( $y = 0; $y < $size; $y++ ) {
			for ( $x = 0; $x < $size; $x++ ) {
				if ( $fix[ $y ][ $x ] ) {
					continue;
				}
				if ( call_user_func( $fn, $y, $x ) ) {
					$mat[ $y ][ $x ] = ! $mat[ $y ][ $x ];
				}
			}
		}
	}

	private static function draw_format( &$mat, $ecl, $mask ) {
		$size = count( $mat );
		$bits = self::encode_format( $ecl, $mask );
		// Copy 1 — top-left.
		for ( $i = 0; $i <= 5; $i++ ) {
			$mat[ 8 ][ $i ] = ( ( $bits >> $i ) & 1 ) === 1;
		}
		$mat[ 8 ][ 7 ] = ( ( $bits >> 6 ) & 1 ) === 1;
		$mat[ 8 ][ 8 ] = ( ( $bits >> 7 ) & 1 ) === 1;
		$mat[ 7 ][ 8 ] = ( ( $bits >> 8 ) & 1 ) === 1;
		for ( $i = 9; $i <= 14; $i++ ) {
			$mat[ 14 - $i ][ 8 ] = ( ( $bits >> $i ) & 1 ) === 1;
		}
		// Copy 2 — bottom-left strip (bits 0..6) + top-right strip (bits 7..14).
		for ( $i = 0; $i <= 6; $i++ ) {
			$mat[ $size - 1 - $i ][ 8 ] = ( ( $bits >> $i ) & 1 ) === 1;
		}
		for ( $i = 7; $i <= 14; $i++ ) {
			$mat[ 8 ][ $size - 15 + $i ] = ( ( $bits >> $i ) & 1 ) === 1;
		}
		// Re-assert dark module.
		$mat[ $size - 8 ][ 8 ] = true;
	}

	private static function draw_version( &$mat, $version ) {
		if ( $version < 7 ) {
			return;
		}
		$size = count( $mat );
		$bits = self::encode_version( $version );
		for ( $i = 0; $i < 18; $i++ ) {
			$on  = ( ( $bits >> $i ) & 1 ) === 1;
			$row = intval( $i / 3 );
			$col = ( $size - 11 ) + ( $i % 3 );
			$mat[ $row ][ $col ] = $on;
			$mat[ $col ][ $row ] = $on;
		}
	}

	/* ----------------------------------------------------------------
	 * Penalty score (ISO 18004 §8.8.2) — lower is better.
	 * --------------------------------------------------------------*/
	private static function penalty( $mat ) {
		$size = count( $mat );
		$p = 0;

		// Rule 1: runs of >= 5 same-coloured modules.
		for ( $y = 0; $y < $size; $y++ ) {
			$run  = 0;
			$last = -1;
			for ( $x = 0; $x < $size; $x++ ) {
				$c = $mat[ $y ][ $x ] ? 1 : 0;
				if ( $c === $last ) {
					$run++;
					if ( 5 === $run ) {
						$p += 3;
					} elseif ( $run > 5 ) {
						++$p;
					}
				} else {
					$last = $c;
					$run  = 1;
				}
			}
		}
		for ( $x = 0; $x < $size; $x++ ) {
			$run  = 0;
			$last = -1;
			for ( $y = 0; $y < $size; $y++ ) {
				$c = $mat[ $y ][ $x ] ? 1 : 0;
				if ( $c === $last ) {
					$run++;
					if ( 5 === $run ) {
						$p += 3;
					} elseif ( $run > 5 ) {
						++$p;
					}
				} else {
					$last = $c;
					$run  = 1;
				}
			}
		}

		// Rule 2: 2x2 same-colour blocks.
		for ( $y = 0; $y < $size - 1; $y++ ) {
			for ( $x = 0; $x < $size - 1; $x++ ) {
				$c = $mat[ $y ][ $x ];
				if ( $c === $mat[ $y ][ $x + 1 ] && $c === $mat[ $y + 1 ][ $x ] && $c === $mat[ $y + 1 ][ $x + 1 ] ) {
					$p += 3;
				}
			}
		}

		// Rule 3: finder-like patterns (1011101 with 4-module quiet zone).
		$pat = array( true, false, true, true, true, false, true );
		for ( $y = 0; $y < $size; $y++ ) {
			for ( $x = 0; $x <= $size - 7; $x++ ) {
				$ok = true;
				for ( $k = 0; $k < 7; $k++ ) {
					if ( $mat[ $y ][ $x + $k ] !== $pat[ $k ] ) {
						$ok = false;
						break;
					}
				}
				if ( $ok ) {
					$p += 40;
				}
			}
		}
		for ( $x = 0; $x < $size; $x++ ) {
			for ( $y = 0; $y <= $size - 7; $y++ ) {
				$ok = true;
				for ( $k = 0; $k < 7; $k++ ) {
					if ( $mat[ $y + $k ][ $x ] !== $pat[ $k ] ) {
						$ok = false;
						break;
					}
				}
				if ( $ok ) {
					$p += 40;
				}
			}
		}

		// Rule 4: dark-module ratio.
		$dark = 0;
		for ( $y = 0; $y < $size; $y++ ) {
			for ( $x = 0; $x < $size; $x++ ) {
				if ( $mat[ $y ][ $x ] ) {
					$dark++;
				}
			}
		}
		$total = $size * $size;
		$pct   = intval( $dark * 100 / $total );
		$k     = intval( abs( $pct - 50 ) / 5 );
		$p += $k * 10;

		return $p;
	}

	/* ----------------------------------------------------------------
	 * Render matrix as inline SVG.  Includes a 4-module quiet zone
	 * (recommended by the spec — without it some readers won't even
	 * try to decode).
	 * --------------------------------------------------------------*/
	private static function render_svg( $mat, $size_px ) {
		$size  = count( $mat );
		$quiet = 4;
		$total = $size + 2 * $quiet;

		// Responsive SVG — width/height NOT set explicitly so CSS controls
		// the display size, while viewBox + shape-rendering="crispEdges"
		// guarantee each module renders as a sharp filled square at any
		// scale. This is the canonical scannable QR setup.
		$svg  = '<svg xmlns="http://www.w3.org/2000/svg" ';
		$svg .= 'viewBox="0 0 ' . $total . ' ' . $total . '" ';
		$svg .= 'width="100%" height="100%" ';
		$svg .= 'shape-rendering="crispEdges" ';
		$svg .= 'preserveAspectRatio="xMidYMid meet" ';
		$svg .= 'aria-label="QR code">';
		// White background — covers the quiet zone too.
		$svg .= '<rect width="' . $total . '" height="' . $total . '" fill="#ffffff"/>';

		// One <rect> per dark module. Larger SVG markup than a single
		// <path>, but every browser/decoder treats <rect> identically —
		// no subpath fill-rule quirks, no path-rounding issues.
		$rects = '';
		for ( $y = 0; $y < $size; $y++ ) {
			for ( $x = 0; $x < $size; $x++ ) {
				if ( $mat[ $y ][ $x ] ) {
					$rects .= '<rect x="' . ( $x + $quiet ) . '" y="' . ( $y + $quiet ) . '" width="1" height="1" fill="#000000"/>';
				}
			}
		}
		$svg .= $rects;
		$svg .= '</svg>';
		return $svg;
	}

	/* ----------------------------------------------------------------
	 * UTF-8 encode a PHP string to a byte array.
	 * --------------------------------------------------------------*/
	private static function utf8_bytes( $s ) {
		$out = array();
		$len = strlen( $s );
		for ( $i = 0; $i < $len; $i++ ) {
			$out[] = ord( $s[ $i ] );
		}
		return $out;
	}
}
