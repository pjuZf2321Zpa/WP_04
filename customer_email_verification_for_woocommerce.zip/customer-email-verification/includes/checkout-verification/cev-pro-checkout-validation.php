<?php
/**
 * Checkout Validation Handler for Customer Email Verification PRO
 *
 * Handles checkout validation to ensure email verification is completed
 * before allowing order placement.
 *
 * @package Customer_Email_Verification
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * CEV_Checkout_Validation Class
 *
 * Manages checkout validation for email verification.
 */
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
class CEV_Checkout_Validation {

	/**
	 * Checkout verification instance.
	 *
	 * @var CEV_Checkout_Verification
	 */
	private $checkout_verification;

	/**
	 * Initialize the validation handler.
	 *
	 * @since 1.0.0
	 * @param CEV_Checkout_Verification $checkout_verification Checkout verification instance.
	 */
	public function __construct( CEV_Checkout_Verification $checkout_verification ) {
		$this->checkout_verification = $checkout_verification;
	}

	/**
	 * Check email verification on checkout process.
	 *
	 * Validates that guest users have verified their email before allowing
	 * order placement. Adds validation error if email is not verified.
	 *
	 * @since 1.0.0
	 * @param array    $fields Checkout fields.
	 * @param WP_Error $errors Validation errors.
	 * @return void
	 */
	public function after_checkout_validation( $fields, $errors ) {
		if ( '1' !== cev_pro()->function->cev_pro_admin_settings( 'cev_enable_email_verification_checkout' ) ) {
			return;
		}

		// --- Logged-in user path ---
		if ( is_user_logged_in() ) {
			// Store staff are not customers — never block their orders.
			if ( cev_pro()->function->is_back_office_user() ) {
				return;
			}
			$user_id = get_current_user_id();

			// Already verified via permanent user meta — allow checkout.
			// (Includes the gatekeeping `pending_paid_order` state — a pending
			// user has proven their email and must not be blocked at checkout.)
			if ( cev_pro()->function->is_user_email_verified( $user_id ) ) {
				return;
			}

			// Respect free orders exemption.
			// SECURITY: this gate decides whether the order about to be
			// placed RIGHT NOW needs verification, so it must use the
			// LIVE cart — not the cart snapshot captured at OTP-send
			// time. Using the stale snapshot let a shopper verify a
			// small/free cart, add paid items afterward, and skip
			// verification for the larger order.
			$free_orders_exempt = cev_pro()->function->cev_pro_admin_settings( 'cev_enable_email_verification_free_orders' );
			$cart_subtotal_li   = (float) WC()->cart->get_subtotal() + (float) WC()->cart->get_subtotal_tax();
			if ( 1 === (int) $free_orders_exempt && $cart_subtotal_li > 0 ) {
				return;
			}

			// Cart-total threshold: skip verification when the cart is below the threshold.
			if ( $this->threshold_skip_at_gate() ) {
				return;
			}

			// Accept session-based verification (set during this checkout session via inline/popup AJAX).
			$billing_email = isset( $fields['billing_email'] ) ? $fields['billing_email'] : '';
			if ( ! empty( $billing_email ) && $this->is_email_verified_in_session( $billing_email ) ) {
				return;
			}

			// Block checkout — user has not verified their email.
			$errors->add( 'validation', __( 'Please verify your email address.', 'customer-email-verification' ) );
			echo '<input type="hidden" name="validation_error" value="1">';
			return;
		}

		// --- Guest user path ---
		// Check if verification is needed based on order total.
		if ( ! $this->needs_verification_for_order( $fields ) ) {
			return;
		}

		// Verify email is verified in session.
		if ( ! $this->is_email_verified_in_session( $fields['billing_email'] ) ) {
			$message = __( 'Please verify your email address.', 'customer-email-verification' );
			$errors->add( 'validation', $message );
			echo '<input type="hidden" name="validation_error" value="1">';
		}
	}

	/**
	 * Determine if verification is needed for this order.
	 *
	 * @since 1.0.0
	 * @param array $fields Checkout fields.
	 * @return bool True if verification is needed, false otherwise.
	 */
	private function needs_verification_for_order( $fields ) {
		// AI risk: a medium-risk ("require OTP") guest email must verify even
		// when the cart-level exemptions below (free orders, cart threshold,
		// guest-without-account) would otherwise skip verification. A high-risk
		// email is already stopped upstream by the validation chain.
		if ( class_exists( 'CEV_Signup_Risk' ) ) {
			$risk_email = isset( $fields['billing_email'] ) ? $fields['billing_email'] : '';
			if ( '' !== $risk_email && CEV_Signup_Risk::get_instance()->requires_otp( $risk_email, 'checkout' ) ) {
				return true;
			}
		}

		$require_create_account_setting = (int) cev_pro()->function->cev_pro_admin_settings( 'cev_create_an_account_during_checkout', 0 );
		$guest_checkout_enabled        = 'yes' === get_option( 'woocommerce_enable_guest_checkout' );

		if ( $require_create_account_setting && $guest_checkout_enabled ) {
			$create_account_checked = false;

			if ( isset( $fields['createaccount'] ) ) {
				$create_account_checked = wc_string_to_bool( $fields['createaccount'] );
			} elseif ( isset( $_POST['createaccount'] ) ) {
				// Verify nonce for checkout form submission.
				if ( isset( $_POST['woocommerce-process-checkout-nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['woocommerce-process-checkout-nonce'] ) ), 'woocommerce-process_checkout' ) ) {
					$create_account_checked = wc_string_to_bool( sanitize_text_field( wp_unslash( $_POST['createaccount'] ) ) );
				}
			}

			if ( ! $create_account_checked ) {
				return false;
			}
		}

		$cev_enable_email_verification_free_orders = cev_pro()->function->cev_pro_admin_settings( 'cev_enable_email_verification_free_orders' );

		// SECURITY: this gate decides whether the order about to be placed
		// RIGHT NOW needs verification, so it must use the live cart, not
		// the OTP-send-time snapshot (`cev_cart_total_at_otp_send`). A
		// shopper could otherwise request/verify an OTP while the cart was
		// small, then add items before submitting checkout, and the stale
		// snapshot would still say verification wasn't needed.
		$order_subtotal = (float) WC()->cart->get_subtotal() + (float) WC()->cart->get_subtotal_tax();

		// If free orders are exempt and order has value, no verification needed.
		if ( 1 === (int) $cev_enable_email_verification_free_orders && $order_subtotal > 0 ) {
			return false;
		}

		// Cart-total threshold: below the threshold → no verification needed.
		if ( $this->threshold_skip_at_gate() ) {
			return false;
		}

		// If order is free and free orders are exempt, verification is needed.
		if ( 0 === (int) $order_subtotal && 1 === (int) $cev_enable_email_verification_free_orders ) {
			return true;
		}

		// If free orders are not exempt, verification is always needed.
		if ( 1 !== (int) $cev_enable_email_verification_free_orders ) {
			return true;
		}

		return false;
	}

	/**
	 * Whether the cart-total threshold says verification can be SKIPPED.
	 *
	 * SECURITY: always reads the LIVE cart, never the OTP-send-time
	 * snapshot (`cev_cart_total_at_otp_send`) — this is the gate decision
	 * for the order being placed RIGHT NOW, and a stale snapshot let a
	 * shopper verify a small cart, then add items before submitting, and
	 * still skip verification for the now-larger order.
	 *
	 * @since 2.10.0
	 * @return bool True when the cart is BELOW the configured threshold.
	 */
	private function threshold_skip_at_gate() {
		if ( 1 !== (int) cev_pro()->function->cev_pro_admin_settings( 'cev_enable_cart_threshold_verification', 0 ) ) {
			return false;
		}

		$threshold = (float) cev_pro()->function->cev_pro_admin_settings( 'cev_cart_verification_threshold_amount', 0 );
		if ( $threshold <= 0 ) {
			return false;
		}

		$amount = cev_pro()->function->cev_pro_get_cart_threshold_amount();

		return ( $amount < $threshold );
	}

	/**
	 * Check if email is verified in session.
	 *
	 * @since 1.0.0
	 * @param string $billing_email Billing email from checkout.
	 * @return bool True if email is verified, false otherwise.
	 */
	private function is_email_verified_in_session( $billing_email ) {
		$cev_user_verified_data_raw = WC()->session->get( 'cev_user_verified_data' );
		$cev_user_verified_data      = ! is_null( $cev_user_verified_data_raw ) ? json_decode( $cev_user_verified_data_raw ) : null;

		if ( ! isset( $cev_user_verified_data->email ) || ! isset( $cev_user_verified_data->verified ) ) {
			return false;
		}

		return ( $cev_user_verified_data->email === $billing_email && 1 === (int) $cev_user_verified_data->verified );
	}
}
