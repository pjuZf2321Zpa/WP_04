<?php
/**
 * Guest User Checkout Verification Popup Template
 *
 * This template displays the email verification popup for guest users during checkout.
 * It includes email input, OTP verification fields, and all necessary styling options.
 *
 * @package Customer_Email_Verification_Pro
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Procedural view template include'd inside a method/hook, so its top-level variables are function-scoped locals, not globals.

// Get verification data from session.
// Check both session keys: cev_user_verification_data (set when code is sent) and cev_user_verified_data (set when verified).
$cev_user_verification_data_raw = WC()->session->get( 'cev_user_verification_data' );
$cev_user_verification_data = ! is_null( $cev_user_verification_data_raw ) ? json_decode( $cev_user_verification_data_raw ) : null;

$cev_user_verified_data_raw = WC()->session->get( 'cev_user_verified_data' );
$cev_user_verified_data = ! is_null( $cev_user_verified_data_raw ) ? json_decode( $cev_user_verified_data_raw ) : null;

// Determine email and verification status from session data.
// Priority: cev_user_verification_data (active verification) > cev_user_verified_data (already verified).
$email = 'youremail@gmail.com';
if ( ! empty( $cev_user_verification_data ) && isset( $cev_user_verification_data->email ) ) {
	// Email is in active verification session (code sent, not yet verified).
	$email = $cev_user_verification_data->email;
	$cev_already_verify_style = 'pointer-events: all';
} elseif ( ! empty( $cev_user_verified_data ) && isset( $cev_user_verified_data->email ) ) {
	// Email is in verified session (already verified).
	$email = $cev_user_verified_data->email;
	$cev_already_verify_style = 'pointer-events: all';
} else {
	// No email found in session, use default placeholder.
	$cev_already_verify_style = 'pointer-events: none;color: rgba(0,0,0,.6)';
}

// Initialize customizer options for default values.
$CEV_Customizer_Options = new CEV_Customizer_Options();

// Popup appearance is emitted once as design tokens on the root element below
// (see CEV_Functions_Pro::popup_style_tokens) — colours, width, padding,
// alignment, heading size and the button size/width all live there. Do NOT
// re-read those keys here and re-emit them as inline style attributes.
$cev_popup_style = cev_pro()->function->popup_style_attr();

// Get content and messaging options.
$heading_default = __( 'Verify its you.', 'customer-email-verification' );
$heading         = cev_pro()->function->cev_pro_customizer_settings( 'cev_header_text_checkout', $heading_default );
if ( empty( $heading ) ) {
	$heading = cev_pro()->function->cev_pro_customizer_settings( 'cev_verification_header', $heading_default );
}
$heading = cev_pro()->function->cev_pro_translate_string( $heading );

// Get verification message from customizer settings (with placeholder for email).
$verification_message = cev_pro()->function->cev_pro_customizer_settings(
	'cev_verification_widget_message_checkout',
	$CEV_Customizer_Options->defaults['cev_verification_widget_message_checkout']
);
// Conditional Verification: if a flagged category in the cart has a custom
// message, show that instead of the default checkout message.
$cev_category_message = cev_pro()->function->cev_pro_get_triggering_category_message();
if ( '' !== $cev_category_message ) {
	$verification_message = $cev_category_message;
}
$verification_message = cev_pro()->function->cev_pro_translate_string( $verification_message );
// Parse other merge tags (like {site_title}) but keep {customer_email} for JavaScript replacement.
$verification_message = cev_pro()->function->maybe_parse_merge_tags( $verification_message, cev_pro()->function );
// Note: {customer_email} will be replaced dynamically via JavaScript when popup is shown.


// Get button text options (guard against missing default key).
$verify_send_default = isset( $CEV_Customizer_Options->defaults['cev_verification_header_send_verify_button_text'] )
	? $CEV_Customizer_Options->defaults['cev_verification_header_send_verify_button_text']
	: __( 'Verify Your Email', 'customer-email-verification' );

$verify_send = cev_pro()->function->cev_pro_customizer_settings( 'cev_verification_header_send_verify_button_text', $verify_send_default );
$verify_send = cev_pro()->function->cev_pro_translate_string( $verify_send );

// Get OTP section visibility setting.
$cev_verification_widget_hide_otp_section = cev_pro()->function->cev_pro_customizer_settings( 'cev_verification_widget_hide_otp_section', $CEV_Customizer_Options->defaults['cev_verification_widget_hide_otp_section'] );

// Whether the "Already have verification code?" link is actionable depends on
// session state, not on styling — so it is a class, not an inline style.
$cev_already_verify_class = ( 'pointer-events: all' === $cev_already_verify_style ) ? '' : ' cev-is-disabled';

// Get nonces for AJAX requests.
$wp_nonce_send    = wp_create_nonce( 'wc_cev_email_guest_user' );
$wp_nonce_verify  = wp_create_nonce( 'wc_cev_email_guest_user_verify' );
$escaped_nonce_send   = esc_attr( $wp_nonce_send );
$escaped_nonce_verify = esc_attr( $wp_nonce_verify );
?>

<div class="cev-authorization-grid__visual" style="display:block;<?php echo esc_attr( $cev_popup_style ); ?>">
	<div class="cev-authorization-grid__holder">
		<div class="cev-authorization-grid__inner">
			<div class="cev-authorization">
				<form id="cev_verify_email" class="cev_pin_verification_form_pro" method="post" novalidate>
					<section class="cev-authorization__holder">
						<?php
						// Popup header — the built-in mark, or the merchant's Header Image.
						// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- popup_header_html() escapes the image URL and alt; the mark is a constant SVG.
						echo cev_pro()->function->popup_header_html( __( 'Email Verification', 'customer-email-verification' ) );
						?>

						<?php // Main heading and description section. ?>
						<div class="cev-authorization__heading">
							<span class="cev-authorization__title">
								<?php echo esc_html( $heading ); ?>
							</span>
							<span class="cev-authorization__description">
								<?php 
								// Use the parsed verification message with merge tags.
								$display_message = $verification_message;
								// Replace {customer_email} placeholder if email is available.
								if ( ! empty( $email ) && 'youremail@gmail.com' !== $email ) {
									$display_message = str_replace( '{customer_email}', '<strong>' . esc_html( $email ) . '</strong>', $display_message );
								}
								echo wp_kses_post( $display_message ); 
								?>
							</span>
						</div>

						<?php // Email input section. ?>
						<div class="cev-field cev-field_size_extra-large cev-field_icon_left cev-field_event_right cev-hide-success-message">
							<input class="cev_pin_box_email" id="cev_pin_email" name="cev_pin_email" type="email" placeholder="<?php esc_attr_e( 'Enter your email address', 'customer-email-verification' ); ?>" required />

							<?php // Inline email error (disposable / MX / blocked / allowlist rejections render here instead of a native alert). ?>
							<div class="cev_email_error_message" role="alert" aria-live="polite" style="display:none;"></div>

							<a href="javascript:;" class="cev_already_verify<?php echo esc_attr( $cev_already_verify_class ); ?>">
								<?php esc_html_e( 'Already have verification code?', 'customer-email-verification' ); ?>
							</a>

							<?php // Send verification code button. ?>
							<div class="cev_send_email_tag">
								<button wp_nonce="<?php echo esc_attr( $escaped_nonce_send ); ?>" class="cev-button cev-button_color_success cev-send-verification-code" type="button">
									<?php
									if ( ! empty( $verify_send ) ) {
										echo esc_html( $verify_send );
									} else {
										esc_html_e( 'Verify Your Email', 'customer-email-verification' );
									}
									?>
								</button>
								<?php // Resend limit message (hidden by default). ?>
								<div class="cev_limit_message" style="display: none;">
									<?php
									// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
									$resend_limit_message = apply_filters( 'cev_resend_limit_message', __( 'Too many attempts, please contact us for further assistance', 'customer-email-verification' ) );
									echo esc_html( $resend_limit_message );
									?>
								</div>
							</div>
						</div>

						<?php // Verification code sent confirmation section (hidden by default) - matches preview structure. ?>
						<div class="cev-authorization__heading cev-show-reg-content" style="display:none;">
							<!-- Back Button -->
							<div class="back_btn" role="button" tabindex="0" aria-label="<?php esc_attr_e( 'Close popup', 'customer-email-verification' ); ?>">
								<svg viewBox="0 0 14 14" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
									<path d="M1 1l12 12M13 1L1 13"></path>
								</svg>
							</div>

							<span class="cev-authorization__title">
								<?php
								// Use checkout OTP popup header text.
								$verification_header = cev_pro()->function->cev_pro_customizer_settings( 'cev_header_text_checkout_otp', $heading_default );
								if ( empty( $verification_header ) ) {
									$verification_header = cev_pro()->function->cev_pro_customizer_settings( 'cev_verification_header', $heading_default );
								}
								echo wp_kses_post( $verification_header );
								?>
							</span>
							<span class="cev-authorization__description">
								<?php
								// Get verification message from checkout OTP popup customizer settings.
								$otp_verification_message = cev_pro()->function->cev_pro_customizer_settings(
									'cev_verification_widget_message_checkout_otp',
									$CEV_Customizer_Options->defaults['cev_verification_widget_message_checkout_otp']
								);
								// Parse other merge tags (like {site_title}).
								$otp_verification_message = cev_pro()->function->maybe_parse_merge_tags( $otp_verification_message, cev_pro()->function );
								// Replace {customer_email} with a span that JavaScript can update.
								// Use session email as initial value, but JavaScript will update it with the actual entered email.
								$initial_email = ( ! empty( $email ) && 'youremail@gmail.com' !== $email ) ? esc_html( $email ) : '';
								if ( ! empty( $initial_email ) ) {
									$otp_verification_message = str_replace( '{customer_email}', '<strong><span class="cev-customer-email-display">' . $initial_email . '</span></strong>', $otp_verification_message );
								} else {
									// Add placeholder span for JavaScript to populate.
									$otp_verification_message = str_replace( '{customer_email}', '<strong><span class="cev-customer-email-display"></span></strong>', $otp_verification_message );
								}
								echo wp_kses_post( $otp_verification_message );
								?>
							</span>
						</div>

						<?php // OTP verification section (only shown if not hidden) - simplified to match preview. ?>
						<?php if ( 0 === (int) $cev_verification_widget_hide_otp_section ) : ?>
							<?php
							// Determine number of OTP digits based on setting.
							$code_length = cev_pro()->function->cev_pro_admin_settings( 'cev_verification_code_length', 4 );
							if ( '1' === $code_length ) {
								$otp_digits = 4;
							} elseif ( '2' === $code_length ) {
								$otp_digits = 6;
							} else {
								// Default to 4 digits if setting is invalid.
								$otp_digits = 4;
							}
							?>
							<div class="otp-container" role="group" aria-label="<?php esc_attr_e( 'Enter verification code', 'customer-email-verification' ); ?>" style="display:none;">
								<?php for ( $i = 1; $i <= $otp_digits; $i++ ) : ?>
									<?php
									/* translators: %d: OTP digit position number */
									$aria_label = sprintf( esc_attr__( 'OTP digit %d', 'customer-email-verification' ), (int) $i );
									?>
									<input
										type="text"
										maxlength="1"
										class="otp-input"
										id="otp_input_<?php echo esc_attr( $i ); ?>"
										placeholder=" "
										aria-label="<?php echo esc_attr( $aria_label ); ?>"
										inputmode="numeric"
										autocomplete="one-time-code"
									/>
								<?php endfor; ?>
							</div>

							<!-- Error Message Container -->
							<div class="error_mesg" role="alert" aria-live="polite" style="display: none;"></div>

							<!-- Verify OTP Button -->
							<div class="cev_send_email_tag" style="display:none;">
								<button id="cev_submit_pin_button" class="cev-button cev-button_color_success" type="button">
									<?php esc_html_e( 'Verify Code', 'customer-email-verification' ); ?>
								</button>
							</div>

							<!-- Footer Message for OTP popup -->
							<?php
							$footer_message_otp = cev_pro()->function->cev_pro_customizer_settings(
								'cev_verification_widget_footer_checkout_otp',
								isset( $CEV_Customizer_Options->defaults['cev_verification_widget_footer_checkout_otp'] ) ? $CEV_Customizer_Options->defaults['cev_verification_widget_footer_checkout_otp'] : ''
							);
							// Parse merge tags in footer message if method exists.
							if ( ! empty( $footer_message_otp ) ) {
								$footer_message_otp = cev_pro()->function->maybe_parse_merge_tags( $footer_message_otp, cev_pro()->function );
							}
							?>
							<?php if ( ! empty( $footer_message_otp ) ) : ?>
								<?php // Single OTP-step footer: the resend timer (front.js) hides it during the countdown and shows it after, via the cev_resend_link_front class. Uses the Checkout OTP Popup footer setting so it matches the Customizer preview. ?>
								<footer class="cev-authorization__footer cev-rge-content cev_resend_link_front" style="display:none;">
									<?php echo wp_kses_post( $footer_message_otp ); ?>
								</footer>
							<?php endif; ?>
						<?php endif; ?>

						<?php // Footer message (shown initially) — only for guests; logged-in users do not need Login now. ?>
					<?php if ( ! is_user_logged_in() ) : ?>
						<footer class="cev-authorization__footer cev_send_email_span_tag">
							<?php
							$footer_message_checkout = cev_pro()->function->cev_pro_customizer_settings( 'cev_verification_widget_message_footer_checkout_pro', $CEV_Customizer_Options->defaults['cev_verification_widget_message_footer_checkout_pro'] );
							$footer_message_checkout = cev_pro()->function->cev_pro_translate_string( $footer_message_checkout );
							// Parse merge tags in footer message.
							if ( ! empty( $footer_message_checkout ) ) {
								$footer_message_checkout = cev_pro()->function->maybe_parse_merge_tags( $footer_message_checkout, cev_pro()->function );
							}
							echo wp_kses_post( $footer_message_checkout );
							?>
						</footer>
					<?php endif; ?>

						<?php // Resend timer display (hidden by default). ?>
						<span class="cev_resend_timer cev_resend_front" style="display:none;"></span>
					</section>
				</form>
			</div>
		</div>
	</div>
</div>

<?php
/*
 * The overlay tint is the --cev-popup-overlay token on the root above. It used
 * to be an unscoped <style> block with !important, which repainted every
 * .cev-authorization-grid__visual on the page — including nested ones.
 */
?>
