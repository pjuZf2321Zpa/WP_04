<?php
/**
 * Email Pre-flight Validator for Customer Email Verification PRO
 *
 * Centralized validator that runs configurable rules (currently:
 * disposable / temporary email blocking) before a verification email
 * is generated and sent. Each rule short-circuits on first failure
 * and returns a translatable WP_Error with a stable error code so
 * downstream handlers can surface the message to the customer and
 * future analytics can log the rejection reason.
 *
 * Disposable rule design:
 *
 *   - Built-in list (430+ domains, bundled in `assets/data/`).
 *   - Additional blocked domains (admin-managed via UI textarea).
 *   - Excluded domains (always allowed — overrides both lists above).
 *
 * Future tasks (MX validation, custom allow/blocklist) plug into the
 * same `cev_email_validation_rules` filter without touching call sites.
 *
 * @package Customer_Email_Verification_Pro
 * @since   2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * CEV_Email_Validation Class
 *
 * Singleton validator. Call:
 *   CEV_Email_Validation::get_instance()->validate( $email, $context )
 * from any pre-send entry point (signup, checkout, edit-account).
 */
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Plugin-owned class; the marketplace audit does not honour the phpcs.xml prefix registration, so the CEV_ prefix is suppressed per-line.
class CEV_Email_Validation {

	/**
	 * Singleton instance.
	 *
	 * @var CEV_Email_Validation|null
	 */
	private static $instance = null;

	/**
	 * Tracks one-time hook registration.
	 *
	 * @var bool
	 */
	private static $hooks_registered = false;

	/**
	 * In-memory cache of the merged blocked-domain set
	 * (`domain => true`) loaded once per request.
	 *
	 * @var array|null
	 */
	private $blocked_domains_cache = null;

	/**
	 * In-memory cache of the excluded (always-allowed) domain set.
	 *
	 * @var array|null
	 */
	private $excluded_domains_cache = null;

	/**
	 * Get the singleton instance.
	 *
	 * @since 2.10.0
	 * @return CEV_Email_Validation
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Register filters/actions that the validator needs.
	 *
	 * Idempotent — call once from the main plugin file's
	 * `includes_for_all()`.
	 *
	 * @since 2.10.0
	 * @return void
	 */
	public static function register() {
		if ( self::$hooks_registered ) {
			return;
		}
		self::$hooks_registered = true;
		// Currently nothing to register, but the static method is kept
		// so the main plugin file's wiring stays stable for future rules.
	}

	/**
	 * Validate an email address against the active rule set.
	 *
	 * @since 2.10.0
	 * @param string $email   Email address to validate.
	 * @param string $context Context label: 'signup' | 'checkout' | 'edit_account'.
	 * @return true|WP_Error  True if allowed, otherwise a WP_Error whose
	 *                        message is safe to display to the customer.
	 */
	public function validate( $email, $context = 'signup' ) {
		$email = is_string( $email ) ? trim( $email ) : '';

		if ( '' === $email || ! is_email( $email ) ) {
			return new WP_Error(
				'invalid_email',
				__( 'Invalid email address.', 'customer-email-verification' ),
				array( 'email' => $email )
			);
		}

		// Default rule set. Extensible via filter so additional rules can
		// register without editing this file.
		//
		// Order matters: cheap in-memory rules first, expensive DNS check last.
		//   1. disposable        → hash lookup vs bundled list + admin extras
		//   2. blocked emails    → exact-match against admin ban list
		//   3. B2B allowlist     → "only these domains" gate (when set)
		//   4. MX                → DNS lookup (slow, last)
		//
		// `rule_blocked_emails` runs before `rule_b2b_allowlist` because
		// "blocked email" is a stronger signal than "domain not in allowlist"
		// — the WP_Error code is more specific for analytics.
		//
		// Note: the "Excluded domains" list is owned by the Disposable
		// feature and is consulted inside `rule_disposable_domain`, not
		// at this top level. The MX rule has its own semantics and
		// doesn't consult the excluded list.
		$rules = array(
			array( $this, 'rule_disposable_domain' ),
			array( $this, 'rule_blocked_emails' ),
			array( $this, 'rule_b2b_allowlist' ),
			array( $this, 'rule_mx_check' ),
		);

		/**
		 * Filter the ordered list of validation rules.
		 *
		 * Each rule is a `callable( string $email, string $context ): true|WP_Error`.
		 * Rules run in order; the first one that returns `WP_Error` short-circuits
		 * the chain.
		 *
		 * @since 2.10.0
		 * @param array  $rules   Array of callables.
		 * @param string $email   Email being validated.
		 * @param string $context Context label.
		 */
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		$rules = apply_filters( 'cev_email_validation_rules', $rules, $email, $context );

		foreach ( $rules as $rule ) {
			if ( ! is_callable( $rule ) ) {
				continue;
			}
			$result = call_user_func( $rule, $email, $context );
			if ( is_wp_error( $result ) ) {
				// Analytics: record the block. Event-type comes from the
				// WP_Error code (e.g. "blocked_disposable", "blocked_mx",
				// "blocked_blocklist", "blocked_not_in_allowlist") so the
				// dashboard can group by reason.
				if ( method_exists( cev_pro()->function, 'log_event' ) ) {
					$code = $result->get_error_code();
					if ( '' !== $code && 'invalid_email' !== $code ) {
						$domain = '';
						$at = strpos( $email, '@' );
						if ( false !== $at ) {
							$domain = strtolower( substr( $email, $at + 1 ) );
						}
						cev_pro()->function->log_event(
							$email,
							$code,
							$context,
							array( 'domain' => $domain )
						);
					}
				}
				return $result;
			}
		}

		return true;
	}

	/**
	 * Rule: reject disposable / temporary email domains.
	 *
	 * Resolution order:
	 *
	 *   1. If the master toggle is OFF → allow (rule no-op).
	 *   2. If domain is in the EXCLUDED list → allow (overrides blocklist).
	 *   3. If domain is in (built-in ∪ additional) blocked list → block.
	 *   4. Otherwise → allow.
	 *
	 * The Excluded list is scoped to this rule (it doesn't override MX).
	 * Conceptually: "Excluded" means "don't treat as disposable", not
	 * "always allow regardless of other validation".
	 *
	 * @since 2.10.0
	 * @param string $email   Email address.
	 * @param string $context Validation context.
	 * @return true|WP_Error
	 */
	public function rule_disposable_domain( $email, $context ) {
		$enabled = (int) cev_pro()->function->cev_pro_admin_settings( 'cev_block_disposable_emails', 0 );
		if ( 1 !== $enabled ) {
			return true;
		}

		$domain = $this->extract_domain( $email );
		if ( '' === $domain ) {
			return true; // Defensive — `is_email()` already passed.
		}

		// Excluded list overrides the disposable blocklist (with wildcard
		// support — e.g. `*.acme.com` excludes every subdomain of acme.com).
		$excluded = $this->get_excluded_domain_set();
		if ( $this->domain_matches_list( $domain, $excluded ) ) {
			return true;
		}

		// Check the merged blocklist (built-in + admin "Additional blocked").
		// Wildcard support: pattern like `*.ru` blocks every .ru domain.
		$blocked = $this->get_blocked_domain_set();
		if ( ! empty( $blocked ) && $this->domain_matches_list( $domain, $blocked ) ) {
			$default_message = __(
				"Disposable email addresses aren't allowed. Please use a permanent address.",
				'customer-email-verification'
			);
			$message = (string) cev_pro()->function->cev_pro_admin_message(
				'cev_disposable_block_message',
				$default_message
			);
			if ( '' === trim( $message ) ) {
				$message = $default_message;
			}

			return new WP_Error(
				'blocked_disposable',
				$message,
				array(
					'email'  => $email,
					'domain' => $domain,
				)
			);
		}

		// Heuristic pattern match — catches throwaway domains that are NOT on
		// the list (e.g. tempmail-new.xyz) when the admin opts in. Excluded
		// domains already returned above; common providers are allowlisted
		// inside looks_like_disposable(). Logged as a distinct
		// "blocked_disposable_pattern" event so analytics can tell heuristic
		// catches apart from exact-list catches.
		$heuristic_on = (int) cev_pro()->function->cev_pro_admin_settings( 'cev_disposable_heuristic', 0 );
		if ( 1 === $heuristic_on && $this->looks_like_disposable( $domain ) ) {
			$default_pattern_message = __(
				"Disposable email addresses aren't allowed. Please use a permanent address.",
				'customer-email-verification'
			);
			$pattern_message = (string) cev_pro()->function->cev_pro_admin_message(
				'cev_disposable_block_message',
				$default_pattern_message
			);
			if ( '' === trim( $pattern_message ) ) {
				$pattern_message = $default_pattern_message;
			}

			return new WP_Error(
				'blocked_disposable_pattern',
				$pattern_message,
				array(
					'email'  => $email,
					'domain' => $domain,
				)
			);
		}

		return true;
	}

	/**
	 * Rule: reject email addresses on domains that have no MX (mail) record.
	 *
	 * Catches typos (gmial.com), fake bot domains, and dead inboxes BEFORE
	 * we waste an OTP send. Result is cached per-domain in a transient for
	 * 24 hours so repeat signups from common providers (gmail, yahoo, etc.)
	 * don't pay the DNS-lookup cost twice.
	 *
	 * Fail-open semantics: if the DNS lookup itself errors out (host
	 * networking issue), we allow the email through rather than block real
	 * customers because of our infrastructure problem.
	 *
	 * @since 2.10.0
	 * @param string $email   Email address.
	 * @param string $context Validation context.
	 * @return true|WP_Error
	 */
	public function rule_mx_check( $email, $context ) {
		$enabled = (int) cev_pro()->function->cev_pro_admin_settings( 'cev_validate_mx', 0 );
		if ( 1 !== $enabled ) {
			return true;
		}

		$domain = $this->extract_domain( $email );
		if ( '' === $domain ) {
			return true;
		}

		$has_mx = $this->domain_has_mx( $domain );

		// `null` = lookup unavailable / errored. Fail open.
		if ( null === $has_mx ) {
			return true;
		}

		if ( true === $has_mx ) {
			return true;
		}

		// Domain confirmed to have no MX record → block.
		$default_message = __(
			"We couldn't deliver mail to that domain. Please check the address.",
			'customer-email-verification'
		);
		$message = (string) cev_pro()->function->cev_pro_admin_settings(
			'cev_mx_fail_message',
			$default_message
		);
		if ( '' === trim( $message ) ) {
			$message = $default_message;
		}

		return new WP_Error(
			'blocked_mx',
			$message,
			array(
				'email'  => $email,
				'domain' => $domain,
			)
		);
	}

	/**
	 * Rule: reject specific email addresses on the admin's ban list.
	 *
	 * Personal "ban this customer" feature. Independent from the B2B
	 * allowlist — admins toggle and configure this on its own.
	 *
	 * Resolution:
	 *   1. If toggle is OFF → allow (rule no-op).
	 *   2. If exact email is in the ban list → block.
	 *   3. Otherwise → allow.
	 *
	 * Useful for: known abusers, competitor scrapers, banned customers
	 * who keep re-signing up.
	 *
	 * @since 2.10.0
	 * @param string $email   Email address.
	 * @param string $context Validation context.
	 * @return true|WP_Error
	 */
	public function rule_blocked_emails( $email, $context ) {
		$enabled = (int) cev_pro()->function->cev_pro_admin_settings( 'cev_enable_blocked_emails', 0 );
		if ( 1 !== $enabled ) {
			return true;
		}

		$email_lc = strtolower( trim( (string) $email ) );
		$domain   = $this->extract_domain( $email_lc );
		if ( '' === $domain ) {
			return true; // Defensive.
		}

		$blocked_text = (string) cev_pro()->function->cev_pro_admin_settings( 'cev_blocked_emails', '' );
		if ( '' === trim( $blocked_text ) ) {
			return true; // Toggle on but no entries — nothing to block.
		}

		$blocked_set = $this->parse_email_text( $blocked_text );
		if ( ! isset( $blocked_set[ $email_lc ] ) ) {
			return true;
		}

		$default_message = __(
			'This email address is not allowed at our store.',
			'customer-email-verification'
		);
		$message = (string) cev_pro()->function->cev_pro_admin_settings(
			'cev_blocked_emails_message',
			$default_message
		);
		if ( '' === trim( $message ) ) {
			$message = $default_message;
		}

		return new WP_Error(
			'blocked_specific_email',
			$message,
			array(
				'email'  => $email,
				'domain' => $domain,
				'reason' => 'blocked_specific_email',
			)
		);
	}

	/**
	 * Rule: enforce a B2B domain allowlist — only listed domains can sign up.
	 *
	 * Independent toggle and rejection message from `rule_blocked_emails`.
	 * When the toggle is ON and the allowlist is non-empty, EVERY domain
	 * not in the allowlist is rejected. Wildcard suffixes supported
	 * (`*.acme.com` matches subdomains; bare `acme.com` is a separate entry).
	 *
	 * Resolution:
	 *   1. If toggle is OFF → allow (rule no-op).
	 *   2. If allowlist is empty → allow (treats unconfigured allowlist as
	 *      "no restriction" rather than "block everyone").
	 *   3. If domain matches the allowlist → allow.
	 *   4. Otherwise → block.
	 *
	 * Perfect for B2B / wholesale stores limiting signups to partner
	 * company domains.
	 *
	 * @since 2.10.0
	 * @param string $email   Email address.
	 * @param string $context Validation context.
	 * @return true|WP_Error
	 */
	public function rule_b2b_allowlist( $email, $context ) {
		$enabled = (int) cev_pro()->function->cev_pro_admin_settings( 'cev_enable_b2b_allowlist', 0 );
		if ( 1 !== $enabled ) {
			return true;
		}

		$domain = $this->extract_domain( $email );
		if ( '' === $domain ) {
			return true; // Defensive.
		}

		$allowlist_text = (string) cev_pro()->function->cev_pro_admin_settings( 'cev_domain_allowlist', '' );
		if ( '' === trim( $allowlist_text ) ) {
			return true; // Toggle on but allowlist empty — fail open (don't lock out everyone).
		}

		$allowlist = $this->parse_domain_text( $allowlist_text );
		if ( empty( $allowlist ) || $this->domain_matches_list( $domain, $allowlist ) ) {
			return true;
		}

		$default_message = __(
			'Sign-ups are restricted to specific company domains. Please contact us for access.',
			'customer-email-verification'
		);
		$message = (string) cev_pro()->function->cev_pro_admin_settings(
			'cev_domain_allowlist_message',
			$default_message
		);
		if ( '' === trim( $message ) ) {
			$message = $default_message;
		}

		return new WP_Error(
			'blocked_not_in_allowlist',
			$message,
			array(
				'email'  => $email,
				'domain' => $domain,
				'reason' => 'not_in_allowlist',
			)
		);
	}

	/**
	 * Wildcard-aware domain-set matcher.
	 *
	 * Two match modes:
	 *   - Exact match: O(1) hash lookup (e.g. `acme.com`)
	 *   - Wildcard match: pattern starts with `*.` and we test whether
	 *     the candidate domain ends with the rest. So `*.ru` matches
	 *     `mail.ru`, `temp.foo.ru`, etc.
	 *
	 * Wildcard semantics: `*.acme.com` matches subdomains
	 * (`mail.acme.com`) but NOT the bare `acme.com`. This matches the
	 * DNS / SSL convention. To match both, admin lists `acme.com` AND
	 * `*.acme.com` separately.
	 *
	 * Used by:
	 *   - `rule_disposable_domain` — for "Additional blocked" + "Excluded"
	 *   - `rule_custom_email_rules` — for B2B allowlist
	 *
	 * @since 2.10.0
	 * @param string $domain   Lowercased domain to test.
	 * @param array  $list_set Domain set keyed by pattern.
	 * @return bool
	 */
	private function domain_matches_list( $domain, $list_set ) {
		if ( ! is_string( $domain ) || '' === $domain || empty( $list_set ) ) {
			return false;
		}

		// Fast path: O(1) exact match via array key lookup.
		if ( isset( $list_set[ $domain ] ) ) {
			return true;
		}

		// Wildcard suffix loop: pattern `*.X` matches if domain ends with `.X`.
		foreach ( $list_set as $pattern => $_ignored ) {
			if ( 0 !== strpos( $pattern, '*.' ) ) {
				continue; // Not a wildcard pattern.
			}
			$suffix = substr( $pattern, 1 ); // strip the asterisk; keep the leading dot
			if ( '' === $suffix || '.' === $suffix ) {
				continue; // Defensive — malformed pattern.
			}
			$suffix_len = strlen( $suffix );
			if ( strlen( $domain ) > $suffix_len
				&& substr( $domain, -$suffix_len ) === $suffix
			) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Parse a multiline string into a lowercased email-address set.
	 *
	 * Used by `rule_custom_email_rules` for the specific-emails blocklist.
	 * Tolerant: ignores blank lines + comments. Skips lines that aren't
	 * valid emails so we don't accidentally block on garbage input.
	 *
	 * @since 2.10.0
	 * @param string $text Multiline text, one email per line.
	 * @return array Set keyed by lowercased email.
	 */
	private function parse_email_text( $text ) {
		$set = array();
		if ( ! is_string( $text ) || '' === $text ) {
			return $set;
		}
		$lines = preg_split( "/\r\n|\n|\r/", $text );
		if ( ! is_array( $lines ) ) {
			return $set;
		}
		foreach ( $lines as $line ) {
			$line = strtolower( trim( $line ) );
			if ( '' === $line || 0 === strpos( $line, '#' ) ) {
				continue;
			}
			if ( ! is_email( $line ) ) {
				continue; // Skip garbage so we never block on a typo.
			}
			$set[ $line ] = true;
		}
		return $set;
	}

	/**
	 * Check whether the given domain has an MX record.
	 *
	 * Returns true / false / null:
	 *   - true  = domain has MX record (or A record fallback per RFC 5321)
	 *   - false = domain definitively has no MX record
	 *   - null  = lookup unavailable or errored (caller should fail open)
	 *
	 * Result is cached for 24 hours per domain via transient.
	 *
	 * @since 2.10.0
	 * @param string $domain Lowercased domain (e.g. "example.com").
	 * @return bool|null
	 */
	private function domain_has_mx( $domain ) {
		if ( '' === $domain ) {
			return null;
		}

		$cache_key = 'cev_mx_' . md5( $domain );
		$cached    = get_transient( $cache_key );
		if ( 'ok' === $cached ) {
			return true;
		}
		if ( 'fail' === $cached ) {
			return false;
		}

		$has_mx = null;

		// Primary check: checkdnsrr (POSIX hosts).
		if ( function_exists( 'checkdnsrr' ) ) {
			$result = @checkdnsrr( $domain, 'MX' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			if ( true === $result ) {
				$has_mx = true;
			} elseif ( false === $result ) {
				$has_mx = false;
			}
		}

		// Fallback: dns_get_record (works on Windows + cases where checkdnsrr returned no result).
		if ( null === $has_mx && function_exists( 'dns_get_record' ) ) {
			$records = @dns_get_record( $domain, DNS_MX ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			if ( is_array( $records ) ) {
				$has_mx = ( count( $records ) > 0 );
			}
		}

		// RFC 5321: if no MX record, the A record (if any) is treated as an
		// implicit MX. Cover that fallback so domains using only an A record
		// for mail aren't false-positive rejected.
		if ( false === $has_mx && function_exists( 'dns_get_record' ) ) {
			$a_records = @dns_get_record( $domain, DNS_A ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			if ( is_array( $a_records ) && count( $a_records ) > 0 ) {
				$has_mx = true;
			}
		}

		// Cache positive AND negative results to avoid hammering DNS.
		// Failures cached for a shorter window so genuine new domains
		// (just-propagated DNS) become valid sooner.
		if ( true === $has_mx ) {
			set_transient( $cache_key, 'ok', DAY_IN_SECONDS );
		} elseif ( false === $has_mx ) {
			set_transient( $cache_key, 'fail', HOUR_IN_SECONDS * 6 );
		}

		/**
		 * Filter to override / inspect the MX-check result for a given domain.
		 *
		 * Useful for testing or for hosts that need to inject custom logic
		 * (e.g., trust an internal corporate domain that lacks public MX).
		 *
		 * @since 2.10.0
		 * @param bool|null $has_mx True / false / null (unknown).
		 * @param string    $domain Lowercased domain.
		 */
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		return apply_filters( 'cev_domain_has_mx', $has_mx, $domain );
	}

	/**
	 * Get the merged blocked-domain set: built-in ∪ additional admin-defined.
	 *
	 * Loaded once per request; cached on the instance.
	 *
	 * @since 2.10.0
	 * @return array Set keyed by domain (`domain => true`).
	 */
	private function get_blocked_domain_set() {
		if ( null !== $this->blocked_domains_cache ) {
			return $this->blocked_domains_cache;
		}

		// 1. Built-in list (always loaded).
		$domains = $this->load_domains_from_file( $this->get_bundled_list_path() );

		// 2. Additional admin-defined domains (always merged on top).
		$additional_text = (string) cev_pro()->function->cev_pro_admin_settings(
			'cev_disposable_custom_domains',
			''
		);
		if ( '' !== trim( $additional_text ) ) {
			$additional = $this->parse_domain_text( $additional_text );
			foreach ( $additional as $d => $_v ) {
				$domains[ $d ] = true;
			}
		}

		/**
		 * Filter to inject extra disposable domains at runtime (in addition
		 * to the built-in and admin-defined lists).
		 *
		 * @since 2.10.0
		 * @param array $extra Array of additional domains (case-insensitive).
		 */
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		$extra = apply_filters( 'cev_disposable_extra_domains', array() );
		if ( is_array( $extra ) ) {
			foreach ( $extra as $d ) {
				$d = strtolower( trim( (string) $d ) );
				if ( '' !== $d ) {
					$domains[ $d ] = true;
				}
			}
		}

		$this->blocked_domains_cache = $domains;
		return $this->blocked_domains_cache;
	}

	/**
	 * Get the excluded (always-allowed) domain set from the admin textarea.
	 *
	 * Loaded once per request; cached on the instance.
	 *
	 * @since 2.10.0
	 * @return array Set keyed by domain (`domain => true`).
	 */
	private function get_excluded_domain_set() {
		if ( null !== $this->excluded_domains_cache ) {
			return $this->excluded_domains_cache;
		}

		$excluded_text = (string) cev_pro()->function->cev_pro_admin_settings(
			'cev_disposable_excluded_domains',
			''
		);
		$set = '' !== trim( $excluded_text ) ? $this->parse_domain_text( $excluded_text ) : array();

		/**
		 * Filter to inject extra excluded (always-allowed) domains at runtime.
		 *
		 * @since 2.10.0
		 * @param array $extra Array of additional excluded domains.
		 */
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		$extra = apply_filters( 'cev_disposable_extra_excluded_domains', array() );
		if ( is_array( $extra ) ) {
			foreach ( $extra as $d ) {
				$d = strtolower( trim( (string) $d ) );
				if ( '' !== $d ) {
					$set[ $d ] = true;
				}
			}
		}

		$this->excluded_domains_cache = $set;
		return $this->excluded_domains_cache;
	}

	/**
	 * Parse a multiline string into a lowercased domain set.
	 *
	 * Tolerant: ignores blank lines, comments starting with "#", strips
	 * a leading "@" if the admin pasted "@domain.com" by accident.
	 *
	 * @since 2.10.0
	 * @param string $text Multiline text, one domain per line.
	 * @return array Set keyed by domain.
	 */
	private function parse_domain_text( $text ) {
		$set = array();
		if ( ! is_string( $text ) || '' === $text ) {
			return $set;
		}
		$lines = preg_split( "/\r\n|\n|\r/", $text );
		if ( ! is_array( $lines ) ) {
			return $set;
		}
		foreach ( $lines as $line ) {
			$line = strtolower( trim( $line ) );
			if ( '' === $line || 0 === strpos( $line, '#' ) ) {
				continue;
			}
			if ( 0 === strpos( $line, '@' ) ) {
				$line = substr( $line, 1 );
			}
			if ( '' === $line ) {
				continue;
			}
			$set[ $line ] = true;
		}
		return $set;
	}

	/**
	 * Path to the bundled blocklist that ships with the plugin.
	 *
	 * @since 2.10.0
	 * @return string
	 */
	public function get_bundled_list_path() {
		return cev_pro()->get_plugin_path() . '/assets/data/disposable-domains.txt';
	}

	/**
	 * Load a list file into a lowercased domain set.
	 *
	 * One domain per line. Lines starting with "#" or blank lines are ignored.
	 *
	 * @since 2.10.0
	 * @param string $path Absolute file path.
	 * @return array Set keyed by domain.
	 */
	private function load_domains_from_file( $path ) {
		$set = array();

		if ( ! file_exists( $path ) || ! is_readable( $path ) ) {
			return $set;
		}

		$contents = @file_get_contents( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		if ( false === $contents || '' === $contents ) {
			return $set;
		}

		$lines = preg_split( "/\r\n|\n|\r/", $contents );
		if ( ! is_array( $lines ) ) {
			return $set;
		}

		foreach ( $lines as $line ) {
			$line = strtolower( trim( $line ) );
			if ( '' === $line || 0 === strpos( $line, '#' ) ) {
				continue;
			}
			$set[ $line ] = true;
		}

		return $set;
	}

	/**
	 * Extract the lowercased domain part of an email address.
	 *
	 * @since 2.10.0
	 * @param string $email Email address.
	 * @return string Domain (lowercased) or '' if extraction fails.
	 */
	private function extract_domain( $email ) {
		$at = strrpos( $email, '@' );
		if ( false === $at ) {
			return '';
		}
		return strtolower( substr( $email, $at + 1 ) );
	}

	/**
	 * Heuristic: does this domain look like a disposable / throwaway mail
	 * service that isn't (yet) on the static blocklist?
	 *
	 * High-confidence, low-false-positive by design: it matches only strong
	 * throwaway signals — well-known temp-mail brand tokens, and a
	 * "temp/trash/fake/…"+"mail/inbox/box" word shape — and never fires on a
	 * common mailbox provider. New throwaway domains (tempmail-new.xyz,
	 * trashmail123.info) that follow these patterns are caught even though the
	 * exact domain isn't listed.
	 *
	 * @since 3.0.2
	 * @param string $domain Lowercased domain part.
	 * @return bool True if the domain looks disposable.
	 */
	private function looks_like_disposable( $domain ) {
		$domain = strtolower( (string) $domain );
		if ( '' === $domain || $this->is_common_provider_domain( $domain ) ) {
			return false;
		}

		/**
		 * Filter the disposable-heuristic brand tokens. A domain containing any
		 * of these substrings is treated as disposable.
		 *
		 * @since 3.0.2
		 * @param string[] $needles Substrings that flag a disposable domain.
		 * @param string   $domain  The domain being tested.
		 */
		$default_needles = array(
			'tempmail',
			'temp-mail',
			'tempemail',
			'tmpmail',
			'temporarymail',
			'trashmail',
			'trash-mail',
			'throwaway',
			'throwmail',
			'disposable',
			'fakemail',
			'fake-mail',
			'fakeinbox',
			'burnermail',
			'guerrillamail',
			'guerilla',
			'mailinator',
			'yopmail',
			'getnada',
			'maildrop',
			'sharklasers',
			'mailnesia',
			'mohmal',
			'moakt',
			'dropmail',
			'emailondeck',
			'mintemail',
			'mytemp',
			'10minute',
			'10minmail',
			'minutemail',
			'spam4',
			'junkmail',
			'spambox',
			'trashinbox',
			'discard',
		);
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Plugin-owned hook; the marketplace audit does not honour the phpcs.xml prefix registration, so the cev_ prefix is suppressed per-line.
		$needles = apply_filters( 'cev_disposable_heuristic_needles', $default_needles, $domain );

		foreach ( $needles as $needle ) {
			if ( '' !== $needle && false !== strpos( $domain, $needle ) ) {
				return true;
			}
		}

		// Generic "temp/trash/fake/…"+"mail/inbox/box" word shape, e.g.
		// "trash-box.net", "fakeinbox24.org", "tempbox.io".
		if ( preg_match( '/(?:^|[._-])(temp|tmp|trash|fake|spam|junk|throw|dispos|burner|guerr|nada)[a-z0-9]*[._-]?(mail|inbox|box|email)/', $domain ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Whether the domain is a well-known consumer mailbox provider that must
	 * never be flagged by the disposable heuristic.
	 *
	 * @since 3.0.2
	 * @param string $domain Lowercased domain part.
	 * @return bool
	 */
	private function is_common_provider_domain( $domain ) {
		$providers = array(
			'gmail.com',
			'googlemail.com',
			'yahoo.com',
			'yahoo.co.uk',
			'ymail.com',
			'outlook.com',
			'hotmail.com',
			'hotmail.co.uk',
			'live.com',
			'msn.com',
			'icloud.com',
			'me.com',
			'mac.com',
			'aol.com',
			'protonmail.com',
			'proton.me',
			'gmx.com',
			'gmx.net',
			'zoho.com',
			'yandex.com',
			'mail.com',
			'email.com',
			'fastmail.com',
		);
		return in_array( $domain, $providers, true );
	}
}
