/**
 * 2FA Setup — wires the enrollment card UI to the AJAX endpoints.
 *
 * Runs on:
 *   - WooCommerce → My Account → Two-Factor Auth (frontend)
 *   - wp-admin → Users → Profile / Edit User
 *
 * Depends on:
 *   - jQuery (admin + WC default)
 *   - QRCode (window.QRCode from qrcode.min.js — vendored)
 *   - window.CEV_2FA_SETUP (localized config: ajax_url, nonces, i18n)
 *
 * @package Customer_Email_Verification_Pro
 * @since   2.10.0
 */
( function ( $ ) {
	'use strict';

	if ( typeof window.CEV_2FA_SETUP === 'undefined' ) {
		return;
	}
	var cfg  = window.CEV_2FA_SETUP;
	var i18n = cfg.i18n || {};

	/** Translate helper with safe fallback. */
	function t( key, fallback ) {
		return ( i18n && i18n[ key ] ) ? i18n[ key ] : ( fallback || key );
	}

	$( function () {
		var $card = $( '[data-cev-2fa-card]' ).first();
		if ( ! $card.length ) {
			// Admin "edit user" screen has no card, only the reset button.
			bindAdminReset();
			return;
		}

		bindCardActions( $card );
		bindAdminReset();
	} );

	/**
	 * Wire all data-cev-2fa-action buttons inside the setup card.
	 */
	function bindCardActions( $card ) {
		$card.on( 'click', '[data-cev-2fa-action]', function ( e ) {
			var action = $( this ).attr( 'data-cev-2fa-action' );
			switch ( action ) {
				case 'start':
					e.preventDefault();
					startSetup( $card, $( this ) );
					break;
				case 'verify':
					// Explicit click handler — necessary because the
					// surrounding wp-admin profile form means we can't
					// use a nested <form> + submit button (HTML disallows
					// nested forms; the inner submit bubbles to the outer
					// form). So this button is type="button" and we wire
					// the click directly.
					e.preventDefault();
					completeSetup( $card );
					break;
				case 'cancel':
					e.preventDefault();
					cancelSetup( $card );
					break;
				case 'regenerate':
					e.preventDefault();
					( function ( $btn ) {
						confirmDialog( {
							title:        t( 'regenerate_title', 'Replace recovery codes?' ),
							body:         '<p>' + escapeHtml( t( 'confirm_regenerate' ) ) + '</p>',
							confirmText:  t( 'regenerate_confirm', 'Generate new codes' ),
							cancelText:   t( 'cancel', 'Cancel' ),
							destructive:  true,
							onConfirm:    function () { regenerateCodes( $card, $btn ); }
						} );
					} )( $( this ) );
					break;
				case 'disable':
					e.preventDefault();
					( function ( $btn ) {
						confirmDialog( {
							title:        t( 'disable_title', 'Turn off two-factor authentication?' ),
							body:         '<p>' + escapeHtml( t( 'confirm_disable' ) ) + '</p>',
							confirmText:  t( 'disable_confirm', 'Turn it off' ),
							cancelText:   t( 'cancel', 'Cancel' ),
							destructive:  true,
							onConfirm:    function () { disableTotp( $card, $btn ); }
						} );
					} )( $( this ) );
					break;
				case 'copy-codes':
					e.preventDefault();
					copyCodes( $card );
					break;
				case 'copy-secret':
					e.preventDefault();
					copySecret( $card );
					break;
				case 'download-codes':
					e.preventDefault();
					downloadCodes( $card );
					break;
				case 'ack-codes':
					e.preventDefault();
					// Reload so the card re-renders in "enrolled" state.
					window.location.reload();
					break;
				default:
					break;
			}
		} );

		// Enter-key inside the code input acts like clicking Verify —
		// natural shortcut now that the wrapper is a <div> (no native
		// submit handling). Also stops the keypress from bubbling to the
		// outer wp-admin profile form which would otherwise submit it.
		$card.on( 'keydown', '[data-cev-2fa-code]', function ( e ) {
			if ( 'Enter' === e.key || 13 === e.keyCode ) {
				e.preventDefault();
				e.stopPropagation();
				completeSetup( $card );
			}
		} );
	}

	/**
	 * Start enrollment — hit the server for a fresh secret, render QR.
	 */
	function startSetup( $card, $btn ) {
		setBusy( $btn, true, t( 'enabling' ) );
		$.post( cfg.ajax_url, {
			action: 'cev_2fa_start_setup',
			nonce:  cfg.user_nonce
		} )
			.done( function ( res ) {
				setBusy( $btn, false );
				if ( ! res || ! res.success ) {
					feedback( $card, ( res && res.data && res.data.message ) || t( 'unknown_error' ), true );
					return;
				}
				// QR is rendered client-side using the vendored
				// jquery.qrcode library (Wordfence's choice — 15 years
				// in production). We just hand it the otpauth URI.
				renderQr( $card, res.data.otpauth_uri );
				// Both old (text) and new (input) selectors — keep both so
				// any cached templates still work.
				$card.find( '[data-cev-2fa-secret]' ).text( res.data.manual_secret );
				$card.find( '[data-cev-2fa-secret-input]' ).val( res.data.manual_secret );
				$card.find( '[data-cev-2fa-account]' ).text( res.data.account_label );
				showStep( $card, 'scan' );
				$card.find( '[data-cev-2fa-code]' ).trigger( 'focus' );
			} )
			.fail( function () {
				setBusy( $btn, false );
				feedback( $card, t( 'unknown_error' ), true );
			} );
	}

	/**
	 * Verify the first code typed during enrollment.
	 */
	function completeSetup( $card ) {
		var code = $card.find( '[data-cev-2fa-code]' ).val();
		if ( ! /^\d{6}$/.test( ( code || '' ).replace( /\s+/g, '' ) ) ) {
			feedback( $card, t( 'enter_code' ), true );
			return;
		}

		var $btn = $card.find( '[data-cev-2fa-action="verify"]' );
		setBusy( $btn, true, t( 'verifying' ) );

		$.post( cfg.ajax_url, {
			action: 'cev_2fa_complete_setup',
			nonce:  cfg.user_nonce,
			code:   code
		} )
			.done( function ( res ) {
				setBusy( $btn, false );
				if ( ! res || ! res.success ) {
					feedback( $card, ( res && res.data && res.data.message ) || t( 'unknown_error' ), true );
					return;
				}
				feedback( $card, res.data.message, false );
				renderRecoveryCodes( $card, res.data.recovery_codes );
			} )
			.fail( function () {
				setBusy( $btn, false );
				feedback( $card, t( 'unknown_error' ), true );
			} );
	}

	/**
	 * Cancel the in-progress setup — flips back to the intro step.
	 * (Server-side pending secret is harmless; will be overwritten on
	 * next "Start setup".)
	 */
	function cancelSetup( $card ) {
		showStep( $card, 'intro' );
		feedback( $card, '', false );
		$card.find( '[data-cev-2fa-code]' ).val( '' );
	}

	/**
	 * Disable enrollment.
	 */
	function disableTotp( $card, $btn ) {
		setBusy( $btn, true, t( 'disabling' ) );
		$.post( cfg.ajax_url, {
			action: 'cev_2fa_disable',
			nonce:  cfg.user_nonce
		} )
			.done( function () { window.location.reload(); } )
			.fail( function () {
				setBusy( $btn, false );
				feedback( $card, t( 'unknown_error' ), true );
			} );
	}

	/**
	 * Regenerate recovery codes.
	 */
	function regenerateCodes( $card, $btn ) {
		setBusy( $btn, true, t( 'generating' ) );
		$.post( cfg.ajax_url, {
			action: 'cev_2fa_regenerate_codes',
			nonce:  cfg.user_nonce
		} )
			.done( function ( res ) {
				setBusy( $btn, false );
				if ( ! res || ! res.success ) {
					feedback( $card, ( res && res.data && res.data.message ) || t( 'unknown_error' ), true );
					return;
				}
				renderRecoveryCodes( $card, res.data.recovery_codes );
			} )
			.fail( function () {
				setBusy( $btn, false );
				feedback( $card, t( 'unknown_error' ), true );
			} );
	}

	/**
	 * Render the QR using the vendored jquery.qrcode plugin.
	 *
	 * The plugin attaches a <canvas> to the target element and draws
	 * the QR pixel-by-pixel. Same library Wordfence uses for its 2FA,
	 * so it's known to scan with every authenticator app on every
	 * phone camera.
	 *
	 * @param {jQuery} $card  The 2FA card root.
	 * @param {string} uri    The otpauth:// URI to encode.
	 */
	function renderQr( $card, uri ) {
		var $qr = $card.find( '[data-cev-2fa-qr]' );
		$qr.empty();

		// Compute size from the container so we honour the CSS width.
		var px = Math.max( 192, $qr.width() || 240 );

		// correctLevel: 0=L, 1=M, 2=Q, 3=H. Quartile (2) gives ~25%
		// damage tolerance — best balance for screen scanning.
		try {
			$qr.qrcode( {
				text:         uri,
				width:        px,
				height:       px,
				correctLevel: 2,
				background:   '#ffffff',
				foreground:   '#000000'
			} );
		} catch ( err ) {
			$qr.text( uri ); // last-resort fallback
		}
	}

	/**
	 * Render the recovery-codes panel + flash it.
	 */
	function renderRecoveryCodes( $card, codes ) {
		if ( ! codes || ! codes.length ) {
			return;
		}
		var $panel = $card.find( '[data-cev-2fa-codes-panel]' );
		var $list  = $panel.find( '[data-cev-2fa-codes-list]' );
		$list.empty();
		codes.forEach( function ( c ) {
			$list.append( $( '<li/>' ).text( c ) );
		} );
		$panel.prop( 'hidden', false );
		// Hide the QR-scan step once we're showing recovery codes.
		showStep( $card, 'codes' );
	}

	/**
	 * Copy the secret key to clipboard.
	 *
	 * Shows the success message NEXT TO the copy button (not way down at
	 * the global feedback area below the verify form), and auto-clears
	 * after 2.5 s so it doesn't linger.
	 */
	function copySecret( $card ) {
		var $input = $card.find( '[data-cev-2fa-secret-input]' );
		var val = $input.val() || '';
		val = val.replace( /\s+/g, '' ); // strip the display spaces
		if ( ! val ) {
			return;
		}
		if ( navigator.clipboard && navigator.clipboard.writeText ) {
			navigator.clipboard.writeText( val ).then(
				function () { copyFeedback( $card, t( 'copied' ), false ); },
				function () { copyFeedback( $card, t( 'copy_failed' ), true ); }
			);
		} else {
			$input.get( 0 ).select();
			try { document.execCommand( 'copy' ); copyFeedback( $card, t( 'copied' ), false ); }
			catch ( e ) { copyFeedback( $card, t( 'copy_failed' ), true ); }
		}
	}

	/**
	 * Show feedback inside Option B (next to the copy button) and
	 * auto-hide after 2.5 seconds.
	 */
	var copyFeedbackTimer = null;
	function copyFeedback( $card, msg, isError ) {
		var $f = $card.find( '[data-cev-2fa-copy-feedback]' );
		$f.text( msg || '' );
		$f.toggleClass( 'is-error', !! isError );
		$f.removeClass( 'is-hidden' );
		if ( copyFeedbackTimer ) { clearTimeout( copyFeedbackTimer ); }
		copyFeedbackTimer = setTimeout( function () {
			$f.text( '' ).removeClass( 'is-error' );
		}, 2500 );
	}

	/**
	 * Copy all codes to clipboard.
	 */
	function copyCodes( $card ) {
		var lines = [];
		$card.find( '[data-cev-2fa-codes-list] li' ).each( function () {
			lines.push( $( this ).text() );
		} );
		var blob = lines.join( '\n' );

		if ( navigator.clipboard && navigator.clipboard.writeText ) {
			navigator.clipboard.writeText( blob ).then(
				function () { feedback( $card, t( 'copied' ), false ); },
				function () { feedback( $card, t( 'copy_failed' ), true ); }
			);
		} else {
			feedback( $card, t( 'copy_failed' ), true );
		}
	}

	/**
	 * Download codes as a small text file.
	 */
	function downloadCodes( $card ) {
		var lines = [ '# ' + ( document.title || 'Recovery codes' ), '' ];
		$card.find( '[data-cev-2fa-codes-list] li' ).each( function () {
			lines.push( $( this ).text() );
		} );
		var blob = new Blob( [ lines.join( '\n' ) + '\n' ], { type: 'text/plain;charset=utf-8' } );
		var url  = URL.createObjectURL( blob );
		var a    = document.createElement( 'a' );
		a.href     = url;
		a.download = t( 'recovery_filename' );
		document.body.appendChild( a );
		a.click();
		setTimeout( function () {
			document.body.removeChild( a );
			URL.revokeObjectURL( url );
		}, 0 );
	}

	/**
	 * Toggle which sub-step is visible inside the card.
	 */
	function showStep( $card, name ) {
		$card.find( '[data-cev-2fa-step]' ).each( function () {
			$( this ).prop( 'hidden', $( this ).attr( 'data-cev-2fa-step' ) !== name );
		} );
	}

	/**
	 * Show feedback under the verify form.
	 *
	 * Success messages auto-clear after 3 seconds so they don't linger.
	 * Errors stay until the user retries (we don't want to hide a
	 * "wrong code" message before they've read it).
	 */
	var verifyFeedbackTimer = null;
	function feedback( $card, msg, isError ) {
		var $f = $card.find( '[data-cev-2fa-feedback]' );
		$f.text( msg || '' );
		$f.toggleClass( 'is-error', !! isError );
		if ( verifyFeedbackTimer ) {
			clearTimeout( verifyFeedbackTimer );
			verifyFeedbackTimer = null;
		}
		if ( msg && ! isError ) {
			verifyFeedbackTimer = setTimeout( function () {
				$f.text( '' );
			}, 3000 );
		}
	}

	/**
	 * Toggle a button's busy state.
	 */
	function setBusy( $btn, busy, label ) {
		if ( ! $btn || ! $btn.length ) { return; }
		if ( busy ) {
			$btn.data( 'cev-2fa-orig', $btn.text() ).prop( 'disabled', true );
			if ( label ) { $btn.text( label ); }
		} else {
			var orig = $btn.data( 'cev-2fa-orig' );
			if ( orig ) { $btn.text( orig ); }
			$btn.prop( 'disabled', false );
		}
	}

	/* --------------------------------------------------------------
	 * Admin "Reset 2FA" button (Users → Edit User screen).
	 * ------------------------------------------------------------*/
	function bindAdminReset() {
		$( document ).on( 'click', '[data-cev-2fa-action="admin-reset"]', function ( e ) {
			e.preventDefault();
			var $btn        = $( this );
			var userId      = $btn.attr( 'data-cev-2fa-user-id' );
			var confirmMsg  = $btn.attr( 'data-cev-2fa-confirm' );

			var doReset = function () {
				setBusy( $btn, true, t( 'resetting' ) );
				$.post( cfg.ajax_url, {
					action:  'cev_2fa_admin_reset',
					nonce:   cfg.admin_nonce,
					user_id: userId
				} )
					.done( function () { window.location.reload(); } )
					.fail( function () {
						setBusy( $btn, false );
						alertDialog( {
							title: t( 'reset_failed_title', 'Reset failed' ),
							body:  '<p>' + escapeHtml( t( 'unknown_error' ) ) + '</p>'
						} );
					} );
			};

			if ( ! confirmMsg ) {
				doReset();
				return;
			}

			confirmDialog( {
				title:        t( 'admin_reset_title', "Reset this user's 2FA?" ),
				body:         '<p>' + escapeHtml( confirmMsg ) + '</p>',
				confirmText:  t( 'admin_reset_confirm', 'Reset 2FA' ),
				cancelText:   t( 'cancel', 'Cancel' ),
				destructive:  true,
				onConfirm:    doReset
			} );
		} );
	}

	/**
	 * Show a styled confirmation modal — always custom, never the
	 * browser's native window.confirm() (which is ugly + can't be
	 * styled to match the site).
	 *
	 * Self-contained: builds its own DOM + click + keyboard handling
	 * without depending on admin.js's CevModal helper. Same `opts`
	 * shape as CevModal.confirm so call sites are interchangeable.
	 *
	 * If the global window.CevModal exists (e.g. on wp-admin pages
	 * where admin.js is loaded) we delegate to it for visual
	 * consistency. Otherwise we render our own here.
	 */
	function confirmDialog( opts ) {
		opts = opts || {};
		if ( window.CevModal && typeof window.CevModal.confirm === 'function' ) {
			window.CevModal.confirm( opts );
			return;
		}
		renderInlineModal( opts );
	}

	/**
	 * Single-OK alert popup — used in place of window.alert(). Same
	 * styling as confirmDialog but with no Cancel button.
	 */
	function alertDialog( opts ) {
		opts = opts || {};
		if ( window.CevModal && typeof window.CevModal.alert === 'function' ) {
			window.CevModal.alert( opts );
			return;
		}
		renderInlineModal( {
			title:       opts.title       || t( 'notice_title', 'Notice' ),
			body:        opts.body        || '',
			confirmText: opts.confirmText || 'OK',
			cancelText:  '',  // suppresses Cancel button
			destructive: !! opts.destructive,
			onConfirm:   opts.onConfirm   || function () {}
		} );
	}

	function renderInlineModal( opts ) {
		var title       = opts.title       || 'Confirm';
		var body        = opts.body        || '';
		var confirmText = opts.confirmText || 'OK';
		// Empty string OR explicit false => alert mode (no Cancel button).
		var cancelText  = ( '' === opts.cancelText || false === opts.cancelText )
			? ''
			: ( opts.cancelText || 'Cancel' );
		var destructive = !! opts.destructive;
		var onConfirm   = opts.onConfirm   || function () {};
		var onCancel    = opts.onCancel    || function () {};

		// Dispose any open modal first.
		$( '.cev-modal' ).remove();

		var headerCls  = destructive ? ' cev-modal-warning' : '';
		var confirmCls = 'cev-modal-confirm' + ( destructive ? ' cev-modal-destructive' : '' );
		var cancelHtml = cancelText
			? '<button type="button" class="cev-modal-cancel"></button>'
			: '';

		var $modal = $(
			'<div class="cev-modal" role="dialog" aria-modal="true">'
			+ '<div class="cev-modal-backdrop"></div>'
			+ '<div class="cev-modal-dialog" role="document">'
			+ '<div class="cev-modal-header' + headerCls + '">'
			+ '<h2 class="cev-modal-title"><span class="cev-modal-title-text"></span></h2>'
			+ '</div>'
			+ '<div class="cev-modal-body"></div>'
			+ '<div class="cev-modal-footer">'
			+ cancelHtml
			+ '<button type="button" class="' + confirmCls + '"></button>'
			+ '</div>'
			+ '</div></div>'
		);

		// Safe text injections.
		$modal.find( '.cev-modal-title-text' ).text( title );
		if ( cancelText ) {
			$modal.find( '.cev-modal-cancel' ).text( cancelText );
		}
		$modal.find( '.cev-modal-confirm' ).text( confirmText );
		// Body intentionally accepts pre-built HTML (caller controls trust).
		$modal.find( '.cev-modal-body' ).html( body );

		$( 'body' ).append( $modal ).addClass( 'cev-modal-open' );

		var dispose = function () {
			$modal.remove();
			$( 'body' ).removeClass( 'cev-modal-open' );
			$( document ).off( 'keydown.cev-2fa-modal' );
		};

		$modal.find( '.cev-modal-confirm' ).on( 'click', function () {
			dispose();
			try { onConfirm(); } catch ( e ) { /* swallow */ }
		} );

		var cancel = function () {
			dispose();
			try { onCancel(); } catch ( e ) { /* swallow */ }
		};
		// Cancel button only exists in confirm-mode; backdrop click
		// always cancels (acts as "dismiss" for alert mode too).
		if ( cancelText ) {
			$modal.find( '.cev-modal-cancel' ).on( 'click', cancel );
		}
		$modal.find( '.cev-modal-backdrop' ).on( 'click', cancel );

		$( document ).on( 'keydown.cev-2fa-modal', function ( e ) {
			if ( 'Escape' === e.key || 27 === e.keyCode ) {
				cancel();
			}
		} );

		// Focus the Cancel button by default — safer than auto-focusing
		// a destructive primary action.
		setTimeout( function () {
			$modal.find( '.cev-modal-cancel' ).trigger( 'focus' );
		}, 30 );
	}

	/**
	 * Tiny HTML-escape helper for messages we drop into the modal body.
	 */
	function escapeHtml( str ) {
		return String( str || '' )
			.replace( /&/g, '&amp;' )
			.replace( /</g, '&lt;' )
			.replace( />/g, '&gt;' )
			.replace( /"/g, '&quot;' )
			.replace( /'/g, '&#39;' );
	}

} )( jQuery );
