/**
 * Account verification popup for logged-in unverified customers.
 *
 * Mirrors the registration / checkout popup behaviour: the OTP is auto-sent
 * server-side, the boxes auto-verify when fully entered (no button), and the
 * "Resend code" link appears only after a countdown. Resend limit + OTP
 * length are driven by the admin settings (server-side). Depends only on
 * jQuery and the localized `cev_account_verify` object.
 *
 * @package Customer_Email_Verification_Pro
 * @since 2.10.0
 */
( function ( $ ) {
	'use strict';

	if ( typeof window.cev_account_verify === 'undefined' ) {
		return;
	}

	var cfg = window.cev_account_verify;

	function t( key, fallback ) {
		return ( cfg.i18n && cfg.i18n[ key ] ) ? cfg.i18n[ key ] : fallback;
	}

	$( function () {
		var $popup = $( '#cev-account-verify' );
		if ( ! $popup.length ) {
			return;
		}

		var $msg    = $popup.find( '[data-cev-av="msg"]' );
		var $boxes  = $popup.find( '.cev-av-otp' );
		var $resend = $popup.find( '[data-cev-av="resend"]' );
		var $timer  = $popup.find( '[data-cev-av="timer"]' );
		var $verifyBtn = $popup.find( '[data-cev-av="verify"]' );
		var verifying = false;

		// Manual-verify mode (Customizer "Verify Button" = Show): the Verify
		// button is rendered by the template and the customer must click it —
		// the code is never submitted automatically on the last digit.
		var manualVerifyMode = ( '1' === String( cfg.show_verify_button || '0' ) ) && $verifyBtn.length > 0;

		// Colour comes from the popup design tokens via .is-error / .is-success
		// in cev-popup.css — never set it inline here, or the merchant's
		// Customizer colours cannot reach this element.
		function setMsg( text, isError ) {
			$msg.text( text || '' )
				.toggleClass( 'is-error', !! isError )
				.toggleClass( 'is-success', ! isError && !! text );
		}

		function getCode() {
			var code = '';
			$boxes.each( function () {
				code += ( $( this ).val() || '' ).replace( /[^0-9]/g, '' );
			} );
			return code;
		}

		// Countdown before the resend link appears (mirrors the signup popup).
		function startResendTimer() {
			var delay = parseInt( cfg.resend_delay, 10 ) || 30;
			var label = cfg.count_down_text || t( 'count_down_text', 'You can resend the code in' );
			var left  = delay;

			$resend.hide();
			$timer.show().text( label + ' ' + left + 's' );

			var iv = setInterval( function () {
				left--;
				if ( left <= 0 ) {
					clearInterval( iv );
					$timer.hide().text( '' );
					$resend.show();
				} else {
					$timer.text( label + ' ' + left + 's' );
				}
			}, 1000 );
		}

		function verifyCode() {
			if ( verifying ) {
				return;
			}
			var code = getCode();
			if ( code.length < $boxes.length ) {
				return;
			}
			verifying = true;
			$boxes.prop( 'disabled', true );
			setMsg( t( 'verifying', 'Verifying…' ), false );

			$.post( cfg.ajax_url, {
				action: 'cev_account_verify_code',
				nonce:  cfg.nonce,
				code:   code
			} ).done( function ( res ) {
				if ( res && res.success ) {
					setMsg( t( 'verified', 'Verified! Reloading…' ), false );
					window.location.reload();
				} else {
					setMsg( ( res && res.error && res.error.message ) || t( 'verify_failed', 'Invalid or expired code.' ), true );
					verifying = false;
					$boxes.prop( 'disabled', false ).val( '' );
					$boxes.first().trigger( 'focus' );
				}
			} ).fail( function () {
				setMsg( t( 'verify_failed', 'Invalid or expired code.' ), true );
				verifying = false;
				$boxes.prop( 'disabled', false );
			} );
		}

		// OTP boxes: one digit each, auto-advance, backspace to previous,
		// and (in auto mode) auto-verify once every box is filled.
		$boxes.on( 'input', function () {
			this.value = ( this.value || '' ).replace( /[^0-9]/g, '' ).slice( 0, 1 );
			if ( this.value ) {
				var $next = $( this ).nextAll( '.cev-av-otp' ).first();
				if ( $next.length ) {
					$next.trigger( 'focus' );
				}
			}
			if ( ! manualVerifyMode && getCode().length === $boxes.length ) {
				verifyCode();
			}
		} );
		$boxes.on( 'keydown', function ( e ) {
			if ( 8 === e.keyCode && ! this.value ) {
				$( this ).prevAll( '.cev-av-otp' ).first().trigger( 'focus' );
			}
		} );

		// Paste — spread the pasted digits across every box, then auto-verify
		// (the per-box `input` handler only sees one box, so a multi-digit
		// paste would never hit the "all boxes filled" check on its own).
		$boxes.on( 'paste', function ( e ) {
			var clip = ( e.originalEvent || e ).clipboardData;
			if ( ! clip ) {
				return;
			}
			e.preventDefault();
			var chars = ( clip.getData( 'text' ) || '' ).replace( /\D/g, '' ).split( '' );
			$boxes.each( function ( i ) {
				$( this ).val( chars[ i ] || '' );
			} );
			if ( chars.length >= $boxes.length ) {
				$boxes.last().trigger( 'focus' );
				if ( ! manualVerifyMode ) {
					verifyCode();
				}
			} else {
				$boxes.eq( chars.length ).trigger( 'focus' );
			}
		} );

		// Manual Verify button (rendered only when the Customizer "Verify
		// Button" setting is Show) — validates completeness, then reuses the
		// same verifyCode() flow the auto mode uses.
		$verifyBtn.on( 'click', function ( e ) {
			e.preventDefault();
			if ( getCode().length < $boxes.length ) {
				setMsg( t( 'enter_code', 'Please enter the code.' ), true );
				$boxes.filter( function () {
					return ! $( this ).val();
				} ).first().trigger( 'focus' );
				return;
			}
			verifyCode();
		} );

		// Resend — always sends a fresh code (server enforces the resend limit).
		$resend.on( 'click', function ( e ) {
			e.preventDefault();
			$resend.css( 'pointer-events', 'none' );
			setMsg( t( 'sending', 'Sending…' ), false );

			$.post( cfg.ajax_url, {
				action: 'cev_account_send_code',
				nonce:  cfg.nonce
			} ).done( function ( res ) {
				if ( res && res.success ) {
					$boxes.prop( 'disabled', false ).val( '' );
					$boxes.first().trigger( 'focus' );
					setMsg( t( 'code_sent', 'Code sent — check your inbox.' ), false );
					startResendTimer();
				} else {
					setMsg( ( res && res.error && res.error.message ) || t( 'send_failed', 'Could not send the code.' ), true );
				}
			} ).fail( function () {
				setMsg( t( 'send_failed', 'Could not send the code.' ), true );
			} ).always( function () {
				$resend.css( 'pointer-events', '' );
			} );
		} );

		// Code is already sent server-side on login — start the countdown.
		$boxes.first().trigger( 'focus' );
		startResendTimer();
	} );

} )( jQuery );
