/**
 * CEV Smart Form — front-end script.
 *
 * Phase 2: Login <-> Register tab switching + required-field / format validation.
 * Phase 3: the Register (email) flow is wired via AJAX. The OTP step reuses the
 *   SHARED signup verification popup (#otp-popup) — the same popup the classic
 *   WooCommerce signup flow uses — driven here against the cev_smart_* endpoints.
 *   (On Smart Form pages the classic signup-script.js is not enqueued, so there
 *   is no double-binding of the popup's OTP boxes.)
 *
 * Strings come from the localized `cev_smart_form` object (English fallbacks).
 */
( function () {
	'use strict';

	function getCfg() {
		return window.cev_smart_form || {};
	}

	function i18n( key, fallback ) {
		var bag = getCfg().i18n || {};
		return bag[ key ] || fallback;
	}

	/**
	 * Manual-verify mode (Customizer "Verify Button" = Show).
	 *
	 * When enabled the shared popup's Verify button is visible and the visitor
	 * must click it — the OTP is never submitted automatically when the last
	 * digit is entered or pasted.
	 */
	function manualVerifyMode() {
		return '1' === String( getCfg().show_verify_button || '0' );
	}

	function escHtml( str ) {
		return String( str ).replace( /&/g, '&amp;' ).replace( /</g, '&lt;' ).replace( />/g, '&gt;' );
	}

	/* ---------- Tab switching ---------- */

	function activate( root, target ) {
		root.querySelectorAll( '.cev-sf-tab' ).forEach( function ( tab ) {
			var selected = tab.getAttribute( 'data-cev-sf-tab' ) === target;
			tab.classList.toggle( 'is-active', selected );
			// Keep WAI-ARIA tab state + roving tabindex in sync (only meaningful
			// when the tab bar is shown — template 1; harmless otherwise).
			if ( 'tab' === tab.getAttribute( 'role' ) ) {
				tab.setAttribute( 'aria-selected', selected ? 'true' : 'false' );
				tab.setAttribute( 'tabindex', selected ? '0' : '-1' );
			}
		} );
		root.querySelectorAll( '.cev-sf-panel' ).forEach( function ( panel ) {
			panel.classList.toggle( 'is-active', panel.getAttribute( 'data-cev-sf-panel' ) === target );
		} );
	}

	// Switch the login form to a method (password | email_otp | phone_otp).
	// Shows the chosen pane, enables ONLY its inputs (so the other panes never
	// submit or block validation), records the active method + delivery channel
	// in the hidden fields the server reads, and updates the submit label.
	function setLoginMethod( form, method ) {
		form.querySelectorAll( '[data-cev-sf-login-method]' ).forEach( function ( btn ) {
			var on = btn.getAttribute( 'data-cev-sf-login-method' ) === method;
			btn.classList.toggle( 'is-active', on );
			btn.setAttribute( 'aria-selected', on ? 'true' : 'false' );
		} );
		form.querySelectorAll( '[data-cev-sf-login-pane]' ).forEach( function ( pane ) {
			var on = pane.getAttribute( 'data-cev-sf-login-pane' ) === method;
			if ( on ) {
				pane.removeAttribute( 'hidden' );
			} else {
				pane.setAttribute( 'hidden', 'hidden' );
			}
			pane.querySelectorAll( 'input' ).forEach( function ( input ) {
				input.disabled = ! on;
				if ( 'hidden' !== input.type ) {
					input.required = on;
				}
			} );
		} );
		var methodEl = form.querySelector( '[data-cev-sf-login-method-value]' );
		if ( methodEl ) {
			methodEl.value = method;
		}
		var channelEl = form.querySelector( '[data-cev-sf-channel-value]' );
		if ( channelEl ) {
			channelEl.value = ( 'phone_otp' === method ) ? 'phone' : 'email';
		}
		// Submit label: the customizer login text for password, "Send code" for OTP.
		var submitBtn = form.querySelector( '[data-cev-sf-login-submit]' );
		if ( submitBtn ) {
			var pwLabel  = submitBtn.getAttribute( 'data-cev-sf-label-password' ) || submitBtn.textContent;
			var otpLabel = submitBtn.getAttribute( 'data-cev-sf-label-otp' ) || submitBtn.textContent;
			submitBtn.textContent = ( 'password' === method ) ? pwLabel : otpLabel;
		}
		var formErr = form.querySelector( '.cev-sf-form-error' );
		if ( formErr ) {
			showMessage( formErr, '' );
		}
	}

	// The login method currently active on a form (from the hidden field the
	// tabs keep in sync), falling back to the single configured method.
	function activeLoginMethod( form ) {
		var el = form.querySelector( '[data-cev-sf-login-method-value]' );
		if ( el && el.value ) {
			return el.value;
		}
		return getCfg().login_method || 'password';
	}

	/* ---------- International phone (intl-tel-input) ---------- */

	function initIntlPhone() {
		var cfg = getCfg().intl_phone || {};
		if ( ! cfg.enabled || 'function' !== typeof window.intlTelInput ) {
			return;
		}
		document.querySelectorAll( '[data-cev-sf-intl]' ).forEach( function ( input ) {
			if ( input.cevSfIti ) {
				return;
			}
			input.cevSfIti = window.intlTelInput( input, {
				initialCountry: cfg.initial_country || 'us',
				preferredCountries: cfg.preferred_countries || [],
				separateDialCode: true,
				autoPlaceholder: 'aggressive',
				dropdownContainer: document.body,
				utilsScript: cfg.utils_url || ''
			} );
		} );
	}

	// Replace each intl phone field's value with the full E.164 number before the
	// form is collected, so the server stores the number WITH its country code.
	function applyIntlPhone( form ) {
		form.querySelectorAll( '[data-cev-sf-intl]' ).forEach( function ( input ) {
			var iti = input.cevSfIti;
			if ( ! iti ) {
				return;
			}
			var full = ( 'function' === typeof iti.getNumber ) ? ( iti.getNumber() || '' ) : '';
			// utils.js may not have loaded yet — getNumber() then returns the raw
			// national value. Build E.164 from the selected country's dial code.
			if ( '+' !== full.charAt( 0 ) ) {
				var data = ( 'function' === typeof iti.getSelectedCountryData ) ? iti.getSelectedCountryData() : null;
				var cc = ( data && data.dialCode ) ? data.dialCode : '';
				var nat = ( input.value || '' ).replace( /\D/g, '' );
				full = ( cc && nat ) ? ( '+' + cc + nat ) : full;
			}
			if ( full ) {
				input.value = full;
			}
		} );
	}

	/* ---------- Field validation ---------- */

	function fieldLabel( field ) {
		var label = field.querySelector( '.cev-sf-label' );
		if ( ! label ) {
			return '';
		}
		// Drop the required asterisk / "(optional)" hint so the message reads cleanly.
		return label.textContent.replace( '*', '' ).replace( /\(optional\)/i, '' ).trim();
	}

	function setError( field, message ) {
		field.classList.add( 'cev-sf-field--invalid' );
		var input = field.querySelector( '.cev-sf-input' );
		if ( input ) {
			input.classList.add( 'cev-sf-invalid' );
			input.setAttribute( 'aria-invalid', 'true' );
		}
		var err = field.querySelector( '.cev-sf-error' );
		if ( err ) {
			err.textContent = message;
		}
	}

	function clearError( field ) {
		field.classList.remove( 'cev-sf-field--invalid' );
		var input = field.querySelector( '.cev-sf-input' );
		if ( input ) {
			input.classList.remove( 'cev-sf-invalid' );
			input.removeAttribute( 'aria-invalid' );
		}
		var err = field.querySelector( '.cev-sf-error' );
		if ( err ) {
			err.textContent = '';
		}
	}

	function validateInput( input ) {
		var field = input.closest ? input.closest( '.cev-sf-field' ) : null;
		if ( ! field ) {
			return true;
		}

		var type = ( input.type || '' ).toLowerCase();

		// Checkboxes / radios validate on "checked", not a text value. Fields
		// that share a name form a group; at least one must be selected.
		if ( 'checkbox' === type || 'radio' === type ) {
			var groupName = input.getAttribute( 'name' );
			var checked = false;
			if ( groupName && input.form ) {
				var group = input.form.querySelectorAll( 'input[name="' + groupName + '"]' );
				for ( var gi = 0; gi < group.length; gi++ ) {
					if ( group[ gi ].checked ) {
						checked = true;
						break;
					}
				}
			} else {
				checked = !! input.checked;
			}
			if ( ! checked ) {
				setError( field, i18n( 'field_required', '%s is required.' ).replace( '%s', fieldLabel( field ) ) );
				return false;
			}
			clearError( field );
			return true;
		}

		var value = ( input.value || '' ).trim();
		var name = input.getAttribute( 'name' );

		if ( ! value ) {
			setError( field, i18n( 'field_required', '%s is required.' ).replace( '%s', fieldLabel( field ) ) );
			return false;
		}

		if ( 'email' === input.type || 'email' === name ) {
			if ( ! /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test( value ) ) {
				setError( field, i18n( 'email_invalid', 'Enter a valid email address.' ) );
				return false;
			}
		}

		if ( 'tel' === input.type || 'phone' === name ) {
			if ( value.replace( /[^\d]/g, '' ).length < 6 ) {
				setError( field, i18n( 'phone_invalid', 'Enter a valid phone number.' ) );
				return false;
			}
		}

		// Password policy enforcement - registration password only. Mirrors the
		// server validator; the minimum length and whether the strong-complexity
		// check applies come from the localized config, so the admin setting
		// drives both layers.
		if ( 'cev-sf-reg-password' === input.id ) {
			var pwCfg = getCfg();
			var minLen = parseInt( pwCfg.password_min_length, 10 ) || 8;
			var needStrong = ( '0' !== String( pwCfg.password_require_strong ) );
			var strong = value.length >= minLen;
			if ( strong && needStrong ) {
				strong = /[a-z]/.test( value ) && /[A-Z]/.test( value ) && /[0-9]/.test( value ) && /[^a-zA-Z0-9]/.test( value );
			}
			if ( ! strong ) {
				setError( field, i18n( 'password_weak', 'Use at least 8 characters with upper & lower case, a number, and a symbol.' ) );
				return false;
			}
		}

		clearError( field );
		return true;
	}

	function showMessage( el, message ) {
		if ( ! el ) {
			return;
		}
		el.textContent = message || '';
		el.classList.toggle( 'is-shown', !! message );
	}

	/* ---------- Password strength meter ---------- */

	function passwordScore( pw ) {
		var score = 0;
		if ( ! pw ) {
			return 0;
		}
		if ( pw.length >= 8 ) {
			score++;
		}
		if ( /[a-z]/.test( pw ) && /[A-Z]/.test( pw ) ) {
			score++;
		}
		if ( /[0-9]/.test( pw ) ) {
			score++;
		}
		if ( /[^a-zA-Z0-9]/.test( pw ) ) {
			score++;
		}
		return score;
	}

	function updatePasswordMeter( input ) {
		var field = input.closest ? input.closest( '.cev-sf-field' ) : null;
		if ( ! field ) {
			return;
		}
		var meter = field.querySelector( '.cev-sf-pw-meter' );
		var bar = field.querySelector( '.cev-sf-pw-bar' );
		var label = field.querySelector( '.cev-sf-pw-label' );
		var pw = input.value || '';

		if ( ! pw ) {
			if ( meter ) {
				meter.hidden = true;
			}
			if ( bar ) {
				bar.className = 'cev-sf-pw-bar';
			}
			if ( label ) {
				label.className = 'cev-sf-pw-label';
				label.textContent = '';
			}
			return;
		}

		var score = passwordScore( pw );
		var level = ( 1 >= score ) ? 'weak' : ( ( 4 === score ) ? 'strong' : 'medium' );
		var text = ( 'weak' === level ) ? i18n( 'pw_weak', 'Weak' ) : ( ( 'strong' === level ) ? i18n( 'pw_strong', 'Strong' ) : i18n( 'pw_medium', 'Medium' ) );

		if ( meter ) {
			meter.hidden = false;
		}
		if ( bar ) {
			bar.className = 'cev-sf-pw-bar is-' + level;
		}
		if ( label ) {
			label.className = 'cev-sf-pw-label is-' + level;
			label.textContent = text;
		}
	}

	/* ---------- AJAX ---------- */

	function ajaxPost( action, params, done, fail ) {
		var cfg = getCfg();
		if ( ! cfg.ajax_url ) {
			if ( fail ) {
				fail();
			}
			return;
		}
		params = params || {};
		params.action = action;
		params.nonce = cfg.nonce || '';

		var body = new URLSearchParams();
		Object.keys( params ).forEach( function ( k ) {
			body.append( k, null == params[ k ] ? '' : params[ k ] );
		} );

		fetch( cfg.ajax_url, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body.toString()
		} ).then( function ( r ) {
			return r.json();
		} ).then( function ( res ) {
			done( res );
		} ).catch( function () {
			if ( fail ) {
				fail();
			}
		} );
	}

	function errorMessage( res ) {
		if ( res && res.error && res.error.message ) {
			return res.error.message;
		}
		return i18n( 'generic_error', 'Something went wrong. Please try again.' );
	}

	// Serialize every field in the form (incl. any captcha fields a WC-form
	// plugin injected) so the server can validate the third-party captcha.
	function collectForm( form ) {
		var params = {};
		try {
			new FormData( form ).forEach( function ( value, key ) {
				params[ key ] = value;
			} );
		} catch ( err ) {
			var emailEl = form.querySelector( '[name="email"]' );
			var passEl = form.querySelector( '[name="password"]' );
			params.email = emailEl ? emailEl.value : '';
			params.password = passEl ? passEl.value : '';
		}
		return params;
	}

	/* ---------- Shared OTP popup (#otp-popup) ---------- */

	function popupEl() {
		return document.getElementById( 'otp-popup' );
	}

	function otpBoxes( popup ) {
		return Array.prototype.slice.call( popup.querySelectorAll( '.otp-input' ) );
	}

	function otpValue( popup ) {
		return otpBoxes( popup ).map( function ( b ) {
			return b.value;
		} ).join( '' );
	}

	function clearOtp( popup ) {
		otpBoxes( popup ).forEach( function ( b ) {
			b.value = '';
			b.disabled = false;
		} );
	}

	function setLoading( on ) {
		var overlay = document.querySelector( '.cev_loading_overlay' );
		if ( overlay ) {
			overlay.style.display = on ? 'block' : 'none';
		}
	}

	function showPopupError( popup, message ) {
		var err = popup.querySelector( '.error_mesg' );
		if ( err ) {
			err.textContent = message || '';
			err.style.display = message ? 'block' : 'none';
		}
	}

	function isVisible( el ) {
		return !! el && 'none' !== el.style.display && '' !== el.style.display;
	}

	/* Keep keyboard focus inside the open OTP dialog (aria-modal contract). */
	function trapFocus( e, popup ) {
		var nodes = Array.prototype.slice.call(
			popup.querySelectorAll( '.otp-input, .back_btn, .cev-sf-resend-link, #verify-otp-button, a[href], button' )
		).filter( function ( n ) {
			return ! n.disabled && null !== n.offsetParent && '-1' !== n.getAttribute( 'tabindex' );
		} );
		if ( ! nodes.length ) {
			return;
		}
		var firstN = nodes[ 0 ];
		var lastN = nodes[ nodes.length - 1 ];
		if ( e.shiftKey && document.activeElement === firstN ) {
			e.preventDefault();
			lastN.focus();
		} else if ( ! e.shiftKey && document.activeElement === lastN ) {
			e.preventDefault();
			firstN.focus();
		}
	}

	function openPopup( email, verifyAction, resendAction, display, channel ) {
		var popup = popupEl();
		if ( ! popup ) {
			return false;
		}
		// Remember what had focus so it can be restored when the dialog closes.
		popup.cevSfReturnFocus = document.activeElement;
		popup.cevSfEmail = email;
		popup.cevSfVerifyAction = verifyAction || 'cev_smart_verify_register';
		popup.cevSfResendAction = resendAction || 'cev_smart_resend_register';

		// Fill {customer_email} in the popup description with the delivery target
		// (the masked phone for SMS, else the email). For SMS channel, swap to the
		// phone-appropriate template (data-cev-sf-sms-tpl) so the message says
		// "check your SMS" instead of "check your inbox".
		var desc = popup.querySelector( '.cev-authorization__description' );
		if ( desc ) {
			if ( null === desc.getAttribute( 'data-cev-sf-tpl' ) ) {
				desc.setAttribute( 'data-cev-sf-tpl', desc.innerHTML );
			}
			var smsTpl = ( 'sms' === channel ) ? desc.getAttribute( 'data-cev-sf-sms-tpl' ) : null;
			var tpl = smsTpl || desc.getAttribute( 'data-cev-sf-tpl' );
			desc.innerHTML = tpl.replace( '{customer_email}', escHtml( display || email ) );
		}

		var success = popup.querySelector( '.resend_sucsess' );
		if ( success ) {
			success.style.display = 'none';
		}
		showPopupError( popup, '' );
		clearOtp( popup );
		popup.style.display = 'block';

		var first = popup.querySelector( '.otp-input' );
		if ( first ) {
			first.focus();
		}
		startResendTimer( popup );
		return true;
	}

	function closePopup() {
		var popup = popupEl();
		if ( popup ) {
			popup.style.display = 'none';
			if ( popup.cevSfTimer ) {
				window.clearTimeout( popup.cevSfTimer );
			}
			// Return focus to whatever opened the dialog (keyboard / SR users).
			if ( popup.cevSfReturnFocus && 'function' === typeof popup.cevSfReturnFocus.focus ) {
				popup.cevSfReturnFocus.focus();
				popup.cevSfReturnFocus = null;
			}
		}
		setLoading( false );
	}

	function onOtpInput( box ) {
		var popup = popupEl();
		if ( ! popup ) {
			return;
		}
		box.value = ( box.value || '' ).replace( /[^0-9]/g, '' ).slice( 0, 1 );
		var boxes = otpBoxes( popup );
		var idx = boxes.indexOf( box );
		if ( box.value && idx > -1 && idx < boxes.length - 1 ) {
			boxes[ idx + 1 ].focus();
		}
		var val = otpValue( popup );
		if ( ! manualVerifyMode() && val.length === boxes.length ) {
			verifyOtp( popup, val );
		}
	}

	function verifyOtp( popup, code ) {
		showPopupError( popup, '' );
		setLoading( true );
		otpBoxes( popup ).forEach( function ( b ) {
			b.disabled = true;
		} );

		ajaxPost( popup.cevSfVerifyAction || 'cev_smart_verify_register', { email: popup.cevSfEmail || '', otp: code }, function ( res ) {
			if ( res && res.success ) {
				var data = res.data || {};
				if ( data.redirect_url ) {
					window.location.assign( data.redirect_url );
				} else {
					window.location.reload();
				}
				return;
			}
			setLoading( false );
			showPopupError( popup, errorMessage( res ) );
			clearOtp( popup );
			var first = popup.querySelector( '.otp-input' );
			if ( first ) {
				first.focus();
			}
		}, function () {
			setLoading( false );
			clearOtp( popup );
			showPopupError( popup, i18n( 'generic_error', 'Something went wrong. Please try again.' ) );
		} );
	}

	function resendOtp( popup ) {
		showPopupError( popup, '' );
		setLoading( true );

		var resendParams = { email: popup.cevSfEmail || '' };
		if ( popup.cevSfChannel ) {
			resendParams.channel = popup.cevSfChannel;
		}
		ajaxPost( popup.cevSfResendAction || 'cev_smart_resend_register', resendParams, function ( res ) {
			setLoading( false );
			if ( res && res.success ) {
				clearOtp( popup );
				var first = popup.querySelector( '.otp-input' );
				if ( first ) {
					first.focus();
				}
				var success = popup.querySelector( '.resend_sucsess' );
				if ( success ) {
					success.style.display = 'block';
				}
				startResendTimer( popup );
			} else {
				showPopupError( popup, errorMessage( res ) );
			}
		}, function () {
			setLoading( false );
			showPopupError( popup, i18n( 'generic_error', 'Something went wrong. Please try again.' ) );
		} );
	}

	function startResendTimer( popup ) {
		var remaining = parseInt( getCfg().resend_delay, 10 ) || 30;
		var timer = popup.querySelector( '.cev_resend_timer' );
		if ( ! timer ) {
			return;
		}
		timer.style.display = 'block';
		if ( popup.cevSfTimer ) {
			window.clearTimeout( popup.cevSfTimer );
		}

		function tick() {
			if ( remaining <= 0 ) {
				timer.innerHTML = '';
				var link = document.createElement( 'a' );
				link.href = '#';
				link.className = 'cev-sf-resend-link';
				link.textContent = i18n( 'resend', 'Resend code' );
				timer.appendChild( link );
				return;
			}
			timer.textContent = i18n( 'resend_in', 'Resend code in %d s' ).replace( '%d', remaining );
			remaining = remaining - 1;
			popup.cevSfTimer = window.setTimeout( tick, 1000 );
		}
		tick();
	}

	/* ---------- Register flow ---------- */

	function submitRegister( form ) {
		var emailEl = form.querySelector( '[name="email"]' );
		var passEl = form.querySelector( '[name="password"]' );
		var email = emailEl ? emailEl.value.trim() : '';
		var btn = form.querySelector( '.cev-sf-btn--primary' );
		var formErr = form.querySelector( '.cev-sf-form-error' );

		showMessage( formErr, '' );

		if ( btn ) {
			btn.disabled = true;
			btn.dataset.cevLabel = btn.dataset.cevLabel || btn.textContent;
			btn.textContent = i18n( 'creating', 'Creating your account…' );
		}

		ajaxPost( 'cev_smart_register', collectForm( form ), function ( res ) {
			if ( btn ) {
				btn.disabled = false;
				btn.textContent = btn.dataset.cevLabel || 'Create account';
			}
			if ( res && res.success ) {
				var data = res.data || {};
				if ( data.verified && data.redirect_url ) {
					window.location.assign( data.redirect_url );
					return;
				}
				// Open the SHARED signup popup for OTP entry (show the SMS
				// destination when the server delivered the code by phone).
				if ( ! openPopup( email, null, null, data.destination || email, data.channel ) ) {
					showMessage( formErr, i18n( 'generic_error', 'Something went wrong. Please try again.' ) );
				}
			} else {
				showMessage( formErr, errorMessage( res ) );
			}
		}, function () {
			if ( btn ) {
				btn.disabled = false;
				btn.textContent = btn.dataset.cevLabel || 'Create account';
			}
			showMessage( formErr, i18n( 'generic_error', 'Something went wrong. Please try again.' ) );
		} );
	}

	/* ---------- Login flow ---------- */

	function setBtnLoading( btn, on ) {
		if ( ! btn ) {
			return;
		}
		if ( on ) {
			btn.disabled = true;
			btn.dataset.cevLabel = btn.dataset.cevLabel || btn.textContent;
			btn.textContent = i18n( 'please_wait', 'Please wait…' );
		} else {
			btn.disabled = false;
			if ( btn.dataset.cevLabel ) {
				btn.textContent = btn.dataset.cevLabel;
			}
		}
	}

	function submitLogin( form ) {
		var btn = form.querySelector( '.cev-sf-btn--primary' );
		var formErr = form.querySelector( '.cev-sf-form-error' );
		showMessage( formErr, '' );
		setBtnLoading( btn, true );

		ajaxPost( 'cev_smart_login', collectForm( form ), function ( res ) {
			if ( res && res.success && res.data && res.data.redirect_url ) {
				window.location.assign( res.data.redirect_url );
				return;
			}
			setBtnLoading( btn, false );
			showMessage( formErr, errorMessage( res ) );
		}, function () {
			setBtnLoading( btn, false );
			showMessage( formErr, i18n( 'generic_error', 'Something went wrong. Please try again.' ) );
		} );
	}

	function submitLoginOtp( form ) {
		// The active channel pane's input is the enabled one (the inactive pane
		// is disabled), so skip disabled inputs when reading the identifier.
		var loginEl = form.querySelector( '[name="login"]:not([disabled])' );
		var email = loginEl ? loginEl.value.trim() : '';
		var btn = form.querySelector( '.cev-sf-btn--primary' );
		var formErr = form.querySelector( '.cev-sf-form-error' );
		var channelEl = form.querySelector( '[data-cev-sf-channel-value]' );
		var channel = channelEl ? channelEl.value : '';
		showMessage( formErr, '' );
		setBtnLoading( btn, true );

		ajaxPost( 'cev_smart_login_otp_request', collectForm( form ), function ( res ) {
			setBtnLoading( btn, false );
			if ( res && res.success ) {
				// Reuse the SHARED popup with the login verify / resend endpoints;
				// show the destination the server reports (masked phone or email).
				openPopup( email, 'cev_smart_login_otp_verify', 'cev_smart_login_otp_request', ( res.data && res.data.destination ) || email );
				// Remember the chosen channel so a popup "resend" uses the same one.
				var otpPopup = popupEl();
				if ( otpPopup ) {
					otpPopup.cevSfChannel = channel;
				}
			} else {
				showMessage( formErr, errorMessage( res ) );
			}
		}, function () {
			setBtnLoading( btn, false );
			showMessage( formErr, i18n( 'generic_error', 'Something went wrong. Please try again.' ) );
		} );
	}

	/* ---------- Event wiring ---------- */

	function onClick( e ) {
		if ( ! e.target.closest ) {
			return;
		}

		// Password show/hide toggle (eye icon).
		var pwToggle = e.target.closest( '.cev-sf-pw-toggle' );
		if ( pwToggle ) {
			e.preventDefault();
			var wrap = pwToggle.closest( '.cev-sf-input-wrap' );
			var pwInput = wrap ? wrap.querySelector( '.cev-sf-input' ) : null;
			if ( pwInput ) {
				var showing = ( 'text' === pwInput.type );
				pwInput.type = showing ? 'password' : 'text';
				pwToggle.classList.toggle( 'is-showing', ! showing );
				pwToggle.setAttribute( 'aria-pressed', showing ? 'false' : 'true' );
				pwToggle.setAttribute( 'aria-label', showing ? i18n( 'pw_show', 'Show password' ) : i18n( 'pw_hide', 'Hide password' ) );
			}
			return;
		}

		// Manual Verify button inside the shared popup (Customizer "Verify
		// Button" = Show). signup-script.js is not loaded on Smart Form pages,
		// so this delegation owns the button here — it validates completeness
		// and reuses the same verifyOtp() flow the auto mode uses.
		if ( e.target.closest( '#otp-popup #verify-otp-button' ) ) {
			e.preventDefault();
			var vPopup = popupEl();
			if ( vPopup ) {
				var vBoxes = otpBoxes( vPopup );
				var vVal   = otpValue( vPopup );
				if ( vVal.length < vBoxes.length ) {
					showPopupError( vPopup, i18n( 'enter_code', 'Please enter the complete code.' ) );
					for ( var vi = 0; vi < vBoxes.length; vi++ ) {
						if ( ! vBoxes[ vi ].value ) {
							vBoxes[ vi ].focus();
							break;
						}
					}
				} else {
					verifyOtp( vPopup, vVal );
				}
			}
			return;
		}

		// Resend link inside the shared popup.
		if ( e.target.closest( '.cev-sf-resend-link' ) ) {
			e.preventDefault();
			var rPopup = popupEl();
			if ( rPopup ) {
				resendOtp( rPopup );
			}
			return;
		}

		// Close (back) button inside the shared popup.
		if ( e.target.closest( '#otp-popup .back_btn' ) ) {
			e.preventDefault();
			closePopup();
			return;
		}

		// Login method tab (Password / Email code / Phone code).
		var methodBtn = e.target.closest( '[data-cev-sf-login-method]' );
		if ( methodBtn ) {
			e.preventDefault();
			var methodForm = methodBtn.closest( '.cev-sf-form' );
			if ( methodForm ) {
				setLoginMethod( methodForm, methodBtn.getAttribute( 'data-cev-sf-login-method' ) );
			}
			return;
		}

		// Login / Register tab switch.
		var trigger = e.target.closest( '[data-cev-sf-tab]' );
		if ( ! trigger ) {
			return;
		}
		var root = trigger.closest( '[data-cev-smart-form]' );
		if ( ! root ) {
			return;
		}
		e.preventDefault();
		activate( root, trigger.getAttribute( 'data-cev-sf-tab' ) );
	}

	function onSubmit( e ) {
		var form = e.target.closest ? e.target.closest( '.cev-sf-form' ) : null;
		if ( ! form ) {
			return;
		}
		e.preventDefault();

		// Fold the selected country code into the phone value (intl-tel-input)
		// before validation + send, so the server gets the full E.164 number.
		applyIntlPhone( form );

		var firstInvalid = null;
		form.querySelectorAll( '[required]' ).forEach( function ( input ) {
			if ( input.closest( '[hidden]' ) ) {
				return;
			}
			if ( ! validateInput( input ) && ! firstInvalid ) {
				firstInvalid = input;
			}
		} );
		if ( firstInvalid ) {
			firstInvalid.focus();
			return;
		}

		var which = form.getAttribute( 'data-cev-sf-form' );
		if ( 'register' === which ) {
			// Both email and phone (SMS) registration post cev_smart_register; the
			// server picks the OTP channel and the shared popup verifies either.
			submitRegister( form );
			return;
		}
		if ( 'login' === which ) {
			// Route by the tab the customer is on (or the single enabled method).
			var lm = activeLoginMethod( form );
			if ( 'password' === lm ) {
				submitLogin( form );
			} else {
				// email_otp + phone_otp both use the OTP request flow; the hidden
				// `channel` field (kept in sync by the tabs) tells the server
				// whether to deliver by SMS or email.
				submitLoginOtp( form );
			}
		}
	}

	function onInput( e ) {
		var el = e.target;
		if ( ! el || ! el.classList ) {
			return;
		}
		if ( el.classList.contains( 'otp-input' ) && el.closest( '#otp-popup' ) ) {
			onOtpInput( el );
			return;
		}
		if ( el.classList.contains( 'cev-sf-input' ) ) {
			if ( 'cev-sf-reg-password' === el.id ) {
				updatePasswordMeter( el );
			}
			var field = el.closest( '.cev-sf-field' );
			if ( field && field.classList.contains( 'cev-sf-field--invalid' ) ) {
				clearError( field );
			}
		}
	}

	function onKeydown( e ) {
		// Close (back) button is a role="button" — activate with Enter / Space.
		var back = e.target.closest ? e.target.closest( '#otp-popup .back_btn' ) : null;
		if ( back && ( 'Enter' === e.key || ' ' === e.key || 'Spacebar' === e.key ) ) {
			e.preventDefault();
			closePopup();
			return;
		}

		// Trap Tab focus inside the open modal dialog.
		if ( 'Tab' === e.key ) {
			var modal = popupEl();
			if ( modal && isVisible( modal ) && modal.contains( e.target ) ) {
				trapFocus( e, modal );
				return;
			}
		}

		// Roving keyboard navigation for the Login / Register tablist.
		var tab = e.target.closest ? e.target.closest( '.cev-sf-tab[role="tab"]' ) : null;
		if ( tab ) {
			var navKeys = [ 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Home', 'End' ];
			if ( navKeys.indexOf( e.key ) > -1 ) {
				e.preventDefault();
				var tabs = Array.prototype.slice.call( tab.parentNode.querySelectorAll( '.cev-sf-tab[role="tab"]' ) );
				var ti = tabs.indexOf( tab );
				var to = ti;
				if ( 'ArrowLeft' === e.key || 'ArrowUp' === e.key ) {
					to = ti > 0 ? ti - 1 : tabs.length - 1;
				} else if ( 'ArrowRight' === e.key || 'ArrowDown' === e.key ) {
					to = ti < tabs.length - 1 ? ti + 1 : 0;
				} else if ( 'Home' === e.key ) {
					to = 0;
				} else if ( 'End' === e.key ) {
					to = tabs.length - 1;
				}
				var tabRoot = tab.closest( '[data-cev-smart-form]' );
				if ( tabRoot && tabs[ to ] ) {
					activate( tabRoot, tabs[ to ].getAttribute( 'data-cev-sf-tab' ) );
					tabs[ to ].focus();
				}
				return;
			}
		}

		// OTP boxes: Backspace on an empty box steps to the previous box.
		var el = e.target;
		if ( ! el.classList || ! el.classList.contains( 'otp-input' ) || ! el.closest( '#otp-popup' ) ) {
			return;
		}
		if ( 'Backspace' === e.key && ! el.value ) {
			var popup = popupEl();
			if ( ! popup ) {
				return;
			}
			var boxes = otpBoxes( popup );
			var idx = boxes.indexOf( el );
			if ( idx > 0 ) {
				boxes[ idx - 1 ].focus();
			}
		}
	}

	function onKeyup( e ) {
		if ( 'Escape' === e.key ) {
			var popup = popupEl();
			if ( popup && 'none' !== popup.style.display && '' !== popup.style.display ) {
				closePopup();
			}
		}
	}

	function onPaste( e ) {
		var el = e.target;
		if ( ! el.classList || ! el.classList.contains( 'otp-input' ) || ! el.closest( '#otp-popup' ) ) {
			return;
		}
		var clip = e.clipboardData || window.clipboardData;
		if ( ! clip ) {
			return;
		}
		var text = ( clip.getData( 'text' ) || '' ).replace( /[^0-9]/g, '' );
		if ( ! text ) {
			return;
		}
		e.preventDefault();
		var popup = popupEl();
		if ( ! popup ) {
			return;
		}
		var boxes = otpBoxes( popup );
		for ( var i = 0; i < boxes.length; i++ ) {
			boxes[ i ].value = text.charAt( i ) || '';
		}
		var val = otpValue( popup );
		if ( val.length === boxes.length ) {
			if ( manualVerifyMode() ) {
				// Manual mode: focus the last box and wait for the button click.
				boxes[ boxes.length - 1 ].focus();
			} else {
				verifyOtp( popup, val );
			}
		} else {
			var next = boxes[ Math.min( text.length, boxes.length - 1 ) ];
			if ( next ) {
				next.focus();
			}
		}
	}

	function init() {
		document.addEventListener( 'click', onClick );
		document.addEventListener( 'submit', onSubmit );
		document.addEventListener( 'input', onInput );
		document.addEventListener( 'keydown', onKeydown );
		document.addEventListener( 'keyup', onKeyup );
		document.addEventListener( 'paste', onPaste );
		document.querySelectorAll( '[data-cev-smart-form]' ).forEach( function ( node ) {
			node.setAttribute( 'data-cev-ready', '1' );
		} );
		initIntlPhone();
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
} )();
