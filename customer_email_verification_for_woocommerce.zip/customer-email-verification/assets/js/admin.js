/**
 * Customer Email Verification Admin JavaScript
 *
 * Handles all admin-side JavaScript functionality including settings forms,
 * AJAX requests, UI interactions, and data table management.
 *
 * @package Customer_Email_Verification
 * @since 1.0.0
 */

(function( jQuery ) {
	'use strict';

	/**
	 * Configuration constants
	 */
	const CONFIG = {
		SNACKBAR_DURATION: 3000,
		DATATABLE_PAGE_LENGTH: 50,
		CHECKOUT_TYPE_INLINE: '2',
		VERIFICATION_TYPE_LINK: 'link',
		AJAX_TIMEOUT: 30000,
	};

	/**
	 * Selector constants
	 */
	const SELECTORS = {
		SETTINGS_FORM: '#cev_settings_form',
		SETTINGS_SAVE_BUTTON: '.cev_settings_save',
		CHECKOUT_DROPDOWN: '#cev_verification_checkout_dropdown_option',
		VERIFICATION_TYPE: '#cev_verification_type',
		LOGIN_AUTH_TOGGLE: '#cev_enable_login_authentication',
		CHECKOUT_TOGGLE: '#cev_enable_email_verification_checkout',
		TWO_FA_TOGGLE: '#cev_enable_2fa',
		TWO_FA_POLICY: '#cev_login_auth_enforcement',
		DISPOSABLE_TOGGLE: '#cev_block_disposable_emails',
		MX_TOGGLE: '#cev_validate_mx',
		B2B_ALLOWLIST_TOGGLE: '#cev_enable_b2b_allowlist',
		BLOCKED_EMAILS_TOGGLE: '#cev_enable_blocked_emails',
		AI_RISK_TOGGLE: '#cev_ai_risk_scoring',
		BOT_CLUSTER_TOGGLE: '#cev_bot_cluster_detection',
		USER_LOG_TABLE: '#userLogTable',
		ACTIVITY_PANEL_TAB: '#activity-panel-tab-help',
		ACTIVITY_PANEL_WRAPPER: '.woocommerce-layout__activity-panel-wrapper',
		ACTIVITY_PANEL: '.woocommerce-layout__activity-panel',
		MENU_BUTTON: '.menu-button',
		POPUP_MENU: '.popup-menu',
	};

	/**
	 * CSS class constants
	 */
	const CLASSES = {
		DISABLED: 'disabled',
		ACTIVE: 'active',
		IS_ACTIVE: 'is-active',
		IS_OPEN: 'is-open',
		IS_SWITCHING: 'is-switching',
		HOVER_ROW: 'hover-row',
	};

	/**
	 * AJAX action constants
	 */
	const AJAX_ACTIONS = {
		SETTINGS_UPDATE: 'cev_settings_form_update',
		DELETE_USER: 'delete_user',
		DELETE_USERS: 'delete_users',
	};

	/**
	 * i18n bridge — pulls translated strings from the global
	 * `cev_admin_i18n` object that PHP populates via wp_localize_script
	 * (see cev-pro-enqueue.php). Falls back to the English literal if a
	 * key is missing OR if the localization object failed to load. Supports
	 * %d, %s, and positional %1$d / %2$s placeholders.
	 *
	 * Usage:
	 *   i18n( 'reminder_sent', 'Reminder sent.' )
	 *   i18n( 'preview_count_many', '%d users …', count )
	 *   i18n( 'multi', '%1$s sent to %2$s', verb, name )
	 *
	 * @param {string} key
	 * @param {string} fallback
	 * @param {...*}   substitutions
	 * @returns {string}
	 */
	const i18n = function( key, fallback ) {
		const subs = Array.prototype.slice.call( arguments, 2 );
		const str  = ( typeof cev_admin_i18n !== 'undefined' && cev_admin_i18n[ key ] )
			? cev_admin_i18n[ key ]
			: fallback;
		if ( ! subs.length ) {
			return String( str );
		}
		let cursor = 0;
		return String( str ).replace( /%([0-9])\$[ds]|%[ds]/g, function( match, posIndex ) {
			if ( typeof posIndex !== 'undefined' ) {
				const v = subs[ parseInt( posIndex, 10 ) - 1 ];
				return ( v === undefined ) ? match : v;
			}
			const v = subs[ cursor++ ];
			return ( v === undefined ) ? match : v;
		} );
	};

	/**
	 * Messages constants — all keys point at the translatable string store.
	 */
	const MESSAGES = {
		get SETTINGS_SAVED()       { return i18n( 'settings_saved', 'Your Settings have been successfully saved.' ); },
		get USERS_DELETED()        { return i18n( 'users_deleted', 'Users deleted successfully.' ); },
		get USER_DELETED()         { return i18n( 'user_deleted', 'User deleted successfully.' ); },
		get ERROR_DELETING_USERS() { return i18n( 'error_deleting_users', 'Error deleting users.' ); },
		get ERROR_DELETING_USER()  { return i18n( 'error_deleting_user', 'Error deleting user.' ); },
		get NO_USERS_SELECTED()    { return i18n( 'no_users_selected', 'No users selected for deletion' ); },
	};

	/**
	 * Response code constants for standardized AJAX responses.
	 *
	 * @type {Object}
	 */
	const RESPONSE_CODES = {
		SETTINGS_SAVED: 'settings_saved',
		ALL_DELETED: 'all_deleted',
		PARTIAL_DELETE: 'partial_delete',
		DELETE_FAILED: 'delete_failed',
	};

	/**
	 * AJAX Response Handler
	 *
	 * Provides standardized methods for handling AJAX responses.
	 */
	const AjaxResponseHandler = {
		/**
		 * Extract error message from response.
		 *
		 * @param {Object} response - AJAX response object.
		 * @param {string} defaultMessage - Default error message if none found.
		 * @return {string} Error message.
		 */
		getErrorMessage: function(response, defaultMessage) {
			defaultMessage = defaultMessage || 'An error occurred. Please try again.';
			
			if (response && response.error && response.error.message) {
				return response.error.message;
			}
			
			return defaultMessage;
		},

		/**
		 * Check if response indicates success.
		 *
		 * @param {Object} response - AJAX response object.
		 * @return {boolean} True if success.
		 */
		isSuccess: function(response) {
			return !!(response && response.success === true);
		},

		/**
		 * Get response code from response.
		 *
		 * @param {Object} response - AJAX response object.
		 * @return {string|null} Response code or null.
		 */
		getCode: function(response) {
			return (response && response.code) ? response.code : null;
		},

		/**
		 * Get data from response.
		 *
		 * @param {Object} response - AJAX response object.
		 * @return {Object} Response data object.
		 */
		getData: function(response) {
			return (response && response.data) ? response.data : {};
		},
	};

	/**
	 * Snackbar notifications — a thin wrapper over the Zorem UI library's
	 * ZUI.snackbar() toast (.zui-snackbar). The showSuccess / showWarning API is
	 * unchanged so existing callers keep working; a small dedup guard preserves
	 * the old "don't stack the same message twice" behaviour.
	 */
	const Snackbar = {
		/**
		 * Show success snackbar message.
		 *
		 * @param {string} message - Message to display
		 */
		showSuccess: function( message ) {
			this._show( message, 'success', false );
		},

		/**
		 * Show error/warning snackbar message.
		 *
		 * @param {string} message - Message to display (may contain HTML)
		 */
		showWarning: function( message ) {
			this._show( message, 'error', true );
		},

		/**
		 * Render via the ZUI library snackbar, skipping an identical toast that
		 * is already on screen (so a double click doesn't stack two copies).
		 *
		 * @param {string}  message
		 * @param {string}  type  ZUI snackbar type: 'success' | 'error'.
		 * @param {boolean} html  Render the message as HTML (warnings) vs text.
		 * @private
		 */
		_show: function( message, type, html ) {
			if ( ! window.ZUI || typeof window.ZUI.snackbar !== 'function' ) {
				return;
			}

			// Dedup against any non-leaving toast with the same (tag-stripped) text.
			const plain = String( null === message || undefined === message ? '' : message ).replace( /<[^>]*>/g, '' ).trim();
			const existing = document.querySelectorAll( '.zui-snackbar-stack .zui-snackbar:not(.is-leaving) .zui-snackbar__text' );
			for ( let i = 0; i < existing.length; i++ ) {
				if ( existing[ i ].textContent.trim() === plain ) {
					return;
				}
			}

			window.ZUI.snackbar( message, {
				type: type,
				html: html,
				duration: CONFIG.SNACKBAR_DURATION,
			} );
		},
	};

	/**
	 * Modal confirmation helper.
	 *
	 * Replaces the ugly browser-native `window.confirm()` dialog with a
	 * styled modal that matches WP-admin patterns. Supports a destructive
	 * variant with a red primary button and warning header.
	 *
	 * Usage:
	 *   CevModal.confirm( {
	 *     title: 'Delete this thing?',
	 *     body: '<p>HTML body content.</p>',
	 *     confirmText: 'Delete',
	 *     cancelText: 'Cancel',
	 *     destructive: true,
	 *     onConfirm: function() { ... },
	 *     onCancel:  function() { ... },
	 *   } );
	 */
	const CevModal = {
		/**
		 * Show a confirmation modal. Returns nothing — use the
		 * onConfirm / onCancel callbacks for results.
		 *
		 * @param {Object} opts
		 */
		confirm: function( opts ) {
			opts = opts || {};
			const title       = opts.title       || 'Confirm';
			const body        = opts.body        || '';
			const confirmText = opts.confirmText || 'OK';
			const cancelText  = opts.cancelText  || 'Cancel';
			const destructive = !! opts.destructive;
			const onConfirm   = opts.onConfirm   || function() {};
			const onCancel    = opts.onCancel    || function() {};

			// Dispose any existing CEV modal before opening a new one.
			jQuery( '.cev-modal' ).remove();

			// Build markup. Title + body are pre-built so we can mix safe
			// HTML in `body` (caller's responsibility) but always escape
			// the title text.
			const headerClass = destructive ? ' cev-modal-warning' : '';
			const icon        = destructive
				? '<span class="dashicons dashicons-warning" aria-hidden="true"></span>'
				: '';
			const confirmCls  = 'button button-primary cev-modal-confirm'
				+ ( destructive ? ' cev-modal-destructive' : '' );

			const $modal = jQuery(
				'<div class="cev-modal" role="dialog" aria-modal="true">'
				+ '<div class="cev-modal-backdrop"></div>'
				+ '<div class="cev-modal-dialog" role="document">'
				+ '<div class="cev-modal-header' + headerClass + '">'
				+ '<h2 class="cev-modal-title">' + icon
				+ '<span class="cev-modal-title-text"></span></h2>'
				+ '</div>'
				+ '<div class="cev-modal-body"></div>'
				+ '<div class="cev-modal-footer">'
				+ '<button type="button" class="button cev-modal-cancel"></button>'
				+ '<button type="button" class="' + confirmCls + '"></button>'
				+ '</div>'
				+ '</div></div>'
			);

			// Safe text injections.
			$modal.find( '.cev-modal-title-text' ).text( title );
			$modal.find( '.cev-modal-cancel' ).text( cancelText );
			$modal.find( '.cev-modal-confirm' ).text( confirmText );
			// Body may contain HTML — caller controls trust level.
			$modal.find( '.cev-modal-body' ).html( body );

			// Append + freeze background scroll.
			jQuery( 'body' ).append( $modal ).addClass( 'cev-modal-open' );

			// Resolve and clean up.
			const dispose = function() {
				$modal.remove();
				jQuery( 'body' ).removeClass( 'cev-modal-open' );
				jQuery( document ).off( 'keydown.cev-modal' );
			};

			$modal.find( '.cev-modal-confirm' ).on( 'click', function() {
				dispose();
				try { onConfirm(); } catch ( e ) { /* swallow */ }
			} );

			const cancelHandler = function() {
				dispose();
				try { onCancel(); } catch ( e ) { /* swallow */ }
			};
			$modal.find( '.cev-modal-cancel, .cev-modal-backdrop' ).on( 'click', cancelHandler );

			// Keyboard: Escape cancels.
			jQuery( document ).on( 'keydown.cev-modal', function( e ) {
				if ( e.key === 'Escape' || e.keyCode === 27 ) {
					cancelHandler();
				}
			} );

			// Focus the cancel button by default — safer than auto-focusing
			// a destructive primary action.
			setTimeout( function() {
				$modal.find( '.cev-modal-cancel' ).trigger( 'focus' );
			}, 30 );
		},

		/**
		 * Single-OK alert popup — replaces window.alert() with a styled
		 * modal. Same look as `confirm()` but with no Cancel button.
		 *
		 * Usage:
		 *   CevModal.alert( {
		 *     title: 'Heads up',
		 *     body: '<p>Something needs your attention.</p>',
		 *     confirmText: 'Got it',
		 *     onConfirm: function() { ... }
		 *   } );
		 *
		 * @param {Object} opts
		 */
		alert: function( opts ) {
			opts = opts || {};
			const title       = opts.title       || 'Notice';
			const body        = opts.body        || '';
			const confirmText = opts.confirmText || 'OK';
			const onConfirm   = opts.onConfirm   || function() {};

			jQuery( '.cev-modal' ).remove();

			const $modal = jQuery(
				'<div class="cev-modal" role="dialog" aria-modal="true">'
				+ '<div class="cev-modal-backdrop"></div>'
				+ '<div class="cev-modal-dialog" role="document">'
				+ '<div class="cev-modal-header">'
				+ '<h2 class="cev-modal-title"><span class="cev-modal-title-text"></span></h2>'
				+ '</div>'
				+ '<div class="cev-modal-body"></div>'
				+ '<div class="cev-modal-footer">'
				+ '<button type="button" class="button button-primary cev-modal-confirm"></button>'
				+ '</div>'
				+ '</div></div>'
			);

			$modal.find( '.cev-modal-title-text' ).text( title );
			$modal.find( '.cev-modal-confirm' ).text( confirmText );
			$modal.find( '.cev-modal-body' ).html( body );

			jQuery( 'body' ).append( $modal ).addClass( 'cev-modal-open' );

			const dispose = function() {
				$modal.remove();
				jQuery( 'body' ).removeClass( 'cev-modal-open' );
				jQuery( document ).off( 'keydown.cev-modal' );
			};

			const close = function() {
				dispose();
				try { onConfirm(); } catch ( e ) { /* swallow */ }
			};

			$modal.find( '.cev-modal-confirm, .cev-modal-backdrop' ).on( 'click', close );

			jQuery( document ).on( 'keydown.cev-modal', function( e ) {
				if ( e.key === 'Escape' || e.keyCode === 27 || e.key === 'Enter' || e.keyCode === 13 ) {
					close();
				}
			} );

			setTimeout( function() {
				$modal.find( '.cev-modal-confirm' ).trigger( 'focus' );
			}, 30 );
		},
	};

	// Expose CevModal globally so other CEV scripts (e.g. cev-2fa-setup.js)
	// can reuse the same styled modal without redefining it.
	window.CevModal = CevModal;

	/**
	 * jQuery plugin extensions
	 */
	jQuery.fn.zorem_snackbar = function( msg ) {
		Snackbar.showSuccess( msg );
		return this;
	};

	jQuery.fn.zorem_snackbar_warning = function( msg ) {
		Snackbar.showWarning( msg );
		return this;
	};

	/**
	 * Check if element is in viewport
	 *
	 * @returns {boolean} True if element is in viewport
	 */
	jQuery.fn.isInViewport = function() {
		const $win = jQuery( window );
		const viewport = {
			top: $win.scrollTop(),
			bottom: $win.scrollTop() + $win.height(),
		};

		const bounds = this.offset();
		if ( ! bounds ) {
			return false;
		}

		bounds.bottom = bounds.top + this.outerHeight();

		return bounds.top >= 0 && bounds.bottom <= window.innerHeight;
	};

	/**
	 * AJAX utility functions
	 */
	const AjaxUtils = {
		/**
		 * Make AJAX request with error handling
		 *
		 * @param {Object} options - AJAX options
		 * @param {string} options.url - AJAX URL
		 * @param {string} options.type - Request type (GET/POST)
		 * @param {Object} options.data - Data to send
		 * @param {Function} options.success - Success callback
		 * @param {Function} options.error - Error callback
		 * @param {string} options.dataType - Expected data type
		 */
		request: function( options ) {
			// Get AJAX URL - check multiple sources
			let ajaxUrl = '';
			if ( typeof ajaxurl !== 'undefined' ) {
				ajaxUrl = ajaxurl;
			} else if ( typeof cev_vars !== 'undefined' && cev_vars.ajax_url ) {
				ajaxUrl = cev_vars.ajax_url;
			} else {
				ajaxUrl = typeof admin_url !== 'undefined' ? admin_url( 'admin-ajax.php' ) : '/wp-admin/admin-ajax.php';
			}

			const defaults = {
				url: ajaxUrl,
				type: 'POST',
				dataType: 'json',
				timeout: CONFIG.AJAX_TIMEOUT,
			};

			const settings = jQuery.extend( {}, defaults, options );

			jQuery.ajax( settings ).fail( function( xhr, status, error ) {
				console.error( 'AJAX Error:', {
					status: status,
					error: error,
					response: xhr.responseText,
				} );

				if ( typeof settings.error === 'function' ) {
					settings.error( xhr, status, error );
				}
			} );
		},
	};

	/**
	 * Settings form handler
	 */
	const SettingsForm = {
		/**
		 * Initialize settings form handlers
		 */
		init: function() {
			this.handleAutoSave();
			this.handleManualSave();
		},

		/**
		 * Handle auto-save on toggle changes
		 */
		handleAutoSave: function() {
			jQuery( document ).on(
				'change',
				'#cev_enable_email_verification, #cev_signup_form_type, input[name="cev_signup_smart_template"], #cev_smart_reg_method, #cev_smart_login_method, #cev_sms_provider, #cev_sms_twilio_send_via, input[name="cev_sms_wa_header_image"], input[name="cev_sms_msg91_use_dlt"], #cev_enable_email_verification_checkout, #cev_enable_login_authentication, #cev_require_otp_every_login, #cev_require_verify_unverified_login, #cev_disable_wooCommerce_store_api, #cev_block_disposable_emails, #cev_disposable_heuristic, #cev_validate_mx, #cev_enable_b2b_allowlist, #cev_enable_blocked_emails, #cev_ai_risk_scoring, #cev_bot_cluster_detection, #cev_enable_paid_order_gatekeeping, #cev_auto_cleanup_enabled, #cev_auto_cleanup_pending_days, #cev_auto_delete_unverified_users, #cev_auto_delete_unverified_users_days, #cev_send_reengagement_emails, #cev_reengagement_intervals',
				function() {
					const $input = jQuery( this );

					// Prefer a SCOPED per-section save: when the changed control
					// lives in a settings section panel, save ONLY that section
					// (action=cev_save_section) instead of re-posting the entire
					// settings form. Much lighter, and it never re-writes
					// unrelated settings (e.g. all the SMS credentials) on every
					// toggle.
					const $panel = $input.closest( '.panel[data-cev-section]' );
					if ( $panel.length ) {
						const section = $panel.attr( 'data-cev-section' );
						const $sectionSave = jQuery( '.cev_section_save_button[data-cev-section="' + section + '"]' ).first();
						if ( $sectionSave.length ) {
							$sectionSave.trigger( 'click' );
							return;
						}
					}

					// Fallback: auto-save the whole form that owns the changed
					// input (e.g. the Maintenance tab's standalone form, which
					// has no per-section save) — without the settings AJAX
					// handler resetting fields it doesn't see.
					const $form = $input.closest( 'form' );
					if ( $form.length === 0 ) {
						return;
					}

					AjaxUtils.request( {
						data: $form.serialize(),
						success: function( response ) {
							// Check for success - handle both AjaxResponseHandler and direct response checks
							const isSuccess = ( typeof AjaxResponseHandler !== 'undefined' && AjaxResponseHandler.isSuccess( response ) ) 
								|| ( response && ( response.success === true || response.success === 'true' ) );
							
							if ( isSuccess ) {
								// Extract message from response.data.message or response.message
								const responseData = ( typeof AjaxResponseHandler !== 'undefined' ) 
									? AjaxResponseHandler.getData( response ) 
									: ( response && response.data ) ? response.data : {};
								const message = ( responseData && responseData.message ) || response.message || MESSAGES.SETTINGS_SAVED;
								Snackbar.showSuccess( message );
							} else {
								const errorMessage = ( typeof AjaxResponseHandler !== 'undefined' )
									? AjaxResponseHandler.getErrorMessage( response, 'Failed to save settings.' )
									: ( response && response.error && response.error.message ) ? response.error.message : 'Failed to save settings.';
								Snackbar.showWarning( errorMessage );
							}
						},
						error: function( xhr, status, error ) {
							const errorMessage = ( typeof AjaxResponseHandler !== 'undefined' )
								? AjaxResponseHandler.getErrorMessage( xhr.responseJSON, 'Failed to save settings.' )
								: ( xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ) ? xhr.responseJSON.error.message : 'Failed to save settings.';
							Snackbar.showWarning( errorMessage );
						},
					} );
				}
			);

			// The "Replace the My Account page form" toggle saves immediately
			// through its section's per-section save (reliable + scoped) rather
			// than relying on the shared full-form auto-save above.
			jQuery( document ).on( 'change', '#cev_smart_takeover_myaccount', function() {
				jQuery( '.cev_section_save_button[data-cev-section="signup_verification"]' ).first().trigger( 'click' );
			} );
		},

		/**
		 * Handle manual save button click
		 */
		handleManualSave: function() {
			// Handle form submission for any CEV form on the page.
			// Maintenance + User Cleanup tabs each have their own form; all
			// of them post to a CEV AJAX action and should never reload the
			// page. The selector list is the single place that wires this up.
			jQuery( document ).on(
				'submit',
				'#cev_settings_form, #cev_maintenance_form',
				function( e ) {
				e.preventDefault();
				e.stopPropagation();

				// Scope button lookup to THIS form so we don't disable
				// Save buttons in other forms on the same page.
				const $form = jQuery( this );
				// The save button usually lives inside the form; the Maintenance
				// button sits in the section HEADER and is associated via the
				// form="<id>" attribute — look there as a fallback.
				let $button = $form.find( SELECTORS.SETTINGS_SAVE_BUTTON ).first();
				if ( ! $button.length && $form.attr( 'id' ) ) {
					$button = jQuery( SELECTORS.SETTINGS_SAVE_BUTTON + '[form="' + $form.attr( 'id' ) + '"]' ).first();
				}
				const originalText = $button.length > 0 ? $button.text() : 'Save';

				// Prevent multiple submissions
				if ( $button.length > 0 && $button.prop( 'disabled' ) ) {
					return false;
				}

				// Update UI state
				let $spinner = null;
				if ( $button.length > 0 ) {
					$button.prop( 'disabled', true ).text( i18n( 'saving', 'Saving…' ) );

					$spinner = jQuery( '<span class="spinner is-active" style="margin-left:6px; vertical-align:middle;"></span>' );
					$button.next( '.spinner' ).remove();
					$button.after( $spinner );
				}

				// Make AJAX request
				AjaxUtils.request( {
					data: $form.serialize(),
					success: function( response ) {
						if ( $spinner ) {
							$spinner.remove();
						}
						if ( $button.length > 0 ) {
							$button.prop( 'disabled', false );
							$button.text( originalText );
						}
						$form.find( '.spinner' ).removeClass( CLASSES.ACTIVE );
						
						// Check for success - handle both AjaxResponseHandler and direct response checks
						const isSuccess = ( typeof AjaxResponseHandler !== 'undefined' && AjaxResponseHandler.isSuccess( response ) ) 
							|| ( response && ( response.success === true || response.success === 'true' ) );
						
						if ( isSuccess ) {
							// Extract message from response.data.message or response.message
							const responseData = ( typeof AjaxResponseHandler !== 'undefined' ) 
								? AjaxResponseHandler.getData( response ) 
								: ( response && response.data ) ? response.data : {};
							const message = ( responseData && responseData.message ) || response.message || MESSAGES.SETTINGS_SAVED;
							Snackbar.showSuccess( message );
						} else {
							const errorMessage = ( typeof AjaxResponseHandler !== 'undefined' )
								? AjaxResponseHandler.getErrorMessage( response, 'Failed to save settings. Please try again.' )
								: ( response && response.error && response.error.message ) ? response.error.message : 'Failed to save settings. Please try again.';
							Snackbar.showWarning( errorMessage );
						}
					},
					error: function( xhr, status, error ) {
						if ( $button.length > 0 ) {
							$spinner.remove();
							$button.prop( 'disabled', false );
							$button.text( originalText );
						}
						
						const errorMessage = ( typeof AjaxResponseHandler !== 'undefined' )
							? AjaxResponseHandler.getErrorMessage( xhr.responseJSON, 'Failed to save settings. Please try again.' )
							: ( xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ) ? xhr.responseJSON.error.message : 'Failed to save settings. Please try again.';
						Snackbar.showWarning( errorMessage );
					},
				} );

				return false;
			} );

			/**
			 * Per-section save (each accordion has its own Save button).
			 *
			 * Each button carries `data-cev-section="<section_key>"` and
			 * lives inside `<div class="panel" data-cev-section="...">`.
			 * On click we:
			 *   1. Collect all form fields inside that panel only.
			 *   2. Add the WP nonce + admin-ajax `action=cev_save_section`
			 *      + `cev_section=<key>` so the server knows which
			 *      settings group to update.
			 *   3. POST + show success/error feedback inline next to the
			 *      button + a top-of-screen snackbar.
			 *
			 * Fields in OTHER sections are never sent — saving "Email
			 * verification" can't reset a toggle in "Spam Protection".
			 */
			jQuery( document ).on( 'click', '.cev_section_save_button', function( e ) {
				e.preventDefault();
				e.stopPropagation();

				const $button   = jQuery( this );
				const section   = $button.attr( 'data-cev-section' );
				if ( ! section ) { return false; }
				if ( $button.prop( 'disabled' ) ) { return false; }

				// The Save button now lives in the accordion HEADER. We
				// jump over to the matching panel (sibling) by section
				// key so we collect ONLY that section's fields — never
				// any other panel's fields.
				const $panel       = jQuery( '.panel[data-cev-section="' + section + '"]' ).first();
				const $form        = jQuery( '#cev_settings_form' );
				const btnEl        = $button.get( 0 );
				const useZui       = ( typeof window.ZUI !== 'undefined' && typeof window.ZUI.btnSaving === 'function' );
				// Stash original label only for the no-ZUI fallback path so
				// success/error handlers can restore it. ZUI's own state
				// machine remembers the label internally.
				const $fallbackLbl = useZui ? null : ( $button.find( '.zui-savebtn__label' ).length ? $button.find( '.zui-savebtn__label' ) : $button );
				const fallbackText = useZui ? '' : $fallbackLbl.text();

				if ( useZui ) {
					window.ZUI.btnSaving( btnEl );
				} else {
					$button.prop( 'disabled', true );
					$fallbackLbl.text( i18n( 'saving', 'Saving…' ) );
				}

				// Build the POST payload from THIS panel's fields only,
				// plus the nonce, action, and section identifier.
				const formData = new FormData();

				// Pull every input/select/textarea inside this panel.
				$panel.find( 'input, select, textarea' ).each( function() {
					const $el  = jQuery( this );
					const name = $el.attr( 'name' );
					if ( ! name ) { return; }
					const type = ( $el.attr( 'type' ) || '' ).toLowerCase();

					if ( 'checkbox' === type || 'radio' === type ) {
						if ( $el.is( ':checked' ) ) {
							formData.append( name, $el.val() );
						}
					} else if ( $el.is( 'select[multiple]' ) ) {
						const vals = $el.val() || [];
						vals.forEach( function( v ) { formData.append( name, v ); } );
					} else {
						formData.append( name, $el.val() != null ? $el.val() : '' );
					}
				} );

				// Add the WP nonce from the surrounding form. The nonce
				// field name matches the action ('cev_settings_form_nonce')
				// — that's what the PHP `check_admin_referer()` looks up.
				const nonceFieldName = 'cev_settings_form_nonce';
				const nonceField = $form.find( 'input[name="' + nonceFieldName + '"]' ).first();
				if ( nonceField.length ) {
					formData.append( nonceFieldName, nonceField.val() );
				}
				const refererField = $form.find( 'input[name="_wp_http_referer"]' ).first();
				if ( refererField.length ) {
					formData.append( '_wp_http_referer', refererField.val() );
				}

				formData.append( 'action', 'cev_save_section' );
				formData.append( 'cev_section', section );

				// admin-ajax URL — pull from cev_vars (localized by PHP),
				// fall back to WP's global `ajaxurl`. NOT CONFIG.AJAX_URL
				// (that property doesn't exist; using it sent the request
				// to the current page URL → got back HTML instead of JSON).
				const ajaxEndpoint = ( typeof cev_vars !== 'undefined' && cev_vars.ajax_url )
					? cev_vars.ajax_url
					: ( typeof ajaxurl !== 'undefined' ? ajaxurl : '/wp-admin/admin-ajax.php' );

				jQuery.ajax( {
					url: ajaxEndpoint,
					type: 'POST',
					data: formData,
					processData: false,
					contentType: false,
					success: function( response ) {
						const isSuccess = ( typeof AjaxResponseHandler !== 'undefined' && AjaxResponseHandler.isSuccess( response ) )
							|| ( response && ( response.success === true || response.success === 'true' ) );

						if ( isSuccess ) {
							// Library shows the green "Saved" confirmation for
							// 3s then auto-resets; snackbar fires the toast.
							if ( useZui ) {
								window.ZUI.btnSaved( btnEl );
							} else {
								$button.prop( 'disabled', false );
								$fallbackLbl.text( fallbackText );
							}
							const data = ( typeof AjaxResponseHandler !== 'undefined' )
								? AjaxResponseHandler.getData( response )
								: ( response && response.data ) ? response.data : {};
							Snackbar.showSuccess( ( data && data.message ) || 'Settings saved.' );
						} else {
							if ( useZui ) {
								window.ZUI.btnReset( btnEl );
							} else {
								$button.prop( 'disabled', false );
								$fallbackLbl.text( fallbackText );
							}
							const errorMessage = ( typeof AjaxResponseHandler !== 'undefined' )
								? AjaxResponseHandler.getErrorMessage( response, 'Failed to save settings.' )
								: 'Failed to save settings.';
							Snackbar.showWarning( errorMessage );
						}
					},
					error: function( xhr ) {
						if ( useZui ) {
							window.ZUI.btnReset( btnEl );
						} else {
							$button.prop( 'disabled', false );
							$fallbackLbl.text( fallbackText );
						}
						const errorMessage = ( typeof AjaxResponseHandler !== 'undefined' )
							? AjaxResponseHandler.getErrorMessage( xhr.responseJSON, 'Failed to save settings.' )
							: 'Failed to save settings.';
						Snackbar.showWarning( errorMessage );
					}
				} );

				return false;
			} );
		},
	};

	/**
	 * Field visibility and state management
	 */
	const FieldManager = {
		/**
		 * Initialize field managers
		 */
		init: function() {
			this.handleCheckoutDropdown();
			this.handleVerificationType();
			this.handleCheckoutToggle();
			this.handleLoginAuthToggle();
			this.handleLoginAuthVisibility();
			this.handleTwoFaToggle();
			this.handleTwoFaPolicyChange();
			this.handleSpamProtectionToggles();
			this.handleCartPageVisibility();
			this.handleCartThresholdToggle();
			this.handleConditionalCategoryToggle();
			this.handleConditionalCategorySync();
			this.initializeCheckoutDependentFields();
			this.initializeLoginAuthDependentFields();
			this.initializeLoginAuthVisibility();
			this.initializeTwoFaDependentFields();
			this.initializeTwoFaPolicyFields();
			this.initializeSpamProtectionState();
			this.initializeCartThresholdDependentFields();
			this.initializeConditionalCategoryDependentFields();
		},

		/**
		 * Check if create account flag is yes
		 *
		 * @param {*} flag - Flag value to check
		 * @returns {boolean} True if flag is yes/1/true
		 */
		isCreateAccountFlagYes: function( flag ) {
			if ( flag === undefined || flag === null ) {
				return false;
			}
			const flagStr = String( flag ).toLowerCase();
			return flagStr === 'yes' || flagStr === '1' || flagStr === 'true';
		},

		/**
		 * Update create account field visibility based on checkout dropdown
		 *
		 * @param {string} selectedValue - Selected dropdown value
		 */
		updateCreateAccountVisibility: function( selectedValue ) {
			const valNum = parseInt( selectedValue, 10 );
			const isInline = ! isNaN( valNum ) && valNum === 2;
			const isPopup = ! isNaN( valNum ) && valNum === 1;

			if ( isInline ) {
				// Hide cart page field and show create account field for Inline type
				jQuery( '#cev_enable_email_verification_cart_page' ).closest( '.zui-row' ).hide();
				// Show free orders + cart-total threshold options for Inline type
				jQuery( '#cev_enable_email_verification_free_orders' ).closest( '.zui-row' ).show();
				jQuery( '#cev_enable_cart_threshold_verification' ).closest( '.zui-row' ).show();
				this.updateCartThresholdDependentFields( jQuery( '#cev_enable_cart_threshold_verification' ).prop( 'checked' ) );

				const $createAccountField = jQuery( '#cev_create_an_account_during_checkout' );
				if ( $createAccountField.length ) {
					const shouldShow = this.isCreateAccountFlagYes(
						typeof cev_vars !== 'undefined' ? cev_vars.cev_create_an_account_during_checkout : false
					);
					$createAccountField.closest( '.zui-row' ).toggle( shouldShow );
				}
			} else if ( isPopup ) {
				// Hide free orders + threshold options for Popup type, show cart page option
				jQuery( '#cev_enable_email_verification_free_orders' ).closest( '.zui-row' ).hide();
				jQuery( '#cev_enable_cart_threshold_verification' ).closest( '.zui-row' ).hide();
				this.updateCartThresholdDependentFields( false );
				jQuery( '#cev_create_an_account_during_checkout' ).closest( '.zui-row' ).hide();
				jQuery( '#cev_enable_email_verification_cart_page' ).closest( '.zui-row' ).show();
			} else {
				// Default: show cart page, hide create account + threshold
				jQuery( '#cev_enable_cart_threshold_verification' ).closest( '.zui-row' ).hide();
				this.updateCartThresholdDependentFields( false );
				jQuery( '#cev_create_an_account_during_checkout' ).closest( '.zui-row' ).hide();
				jQuery( '#cev_enable_email_verification_cart_page' ).closest( '.zui-row' ).show();
			}
		},

		/**
		 * Handle checkout dropdown changes
		 */
		handleCheckoutDropdown: function() {
			const self = this;

			// On change
			jQuery( document ).on( 'change', SELECTORS.CHECKOUT_DROPDOWN, function() {
				self.updateCreateAccountVisibility( jQuery( this ).val() );

				// Toggle cart values visibility
				const isInline = jQuery( this ).val() === CONFIG.CHECKOUT_TYPE_INLINE;
				jQuery( '.cev_cart_values_hide' ).toggle( ! isInline );
			} );

			// Run on page load
			const initialValue = jQuery( SELECTORS.CHECKOUT_DROPDOWN ).val();
			if ( initialValue ) {
				this.updateCreateAccountVisibility( initialValue );
			}
		},

		/**
		 * Handle verification type changes
		 */
		handleVerificationType: function() {
			jQuery( document ).on( 'change', SELECTORS.VERIFICATION_TYPE, function() {
				const isLinkType = jQuery( this ).val() === CONFIG.VERIFICATION_TYPE_LINK;
				const $lengthField = jQuery( '#cev_verification_code_length' );
				const $expirationField = jQuery( '#cev_verification_code_expiration' );

				$lengthField.prop( 'disabled', isLinkType ).closest( '.zui-row' ).toggleClass( CLASSES.DISABLED, isLinkType );
				$expirationField.prop( 'disabled', isLinkType ).closest( '.zui-row' ).toggleClass( CLASSES.DISABLED, isLinkType );
			} );
		},

		/**
		 * Show/hide the cart-total threshold amount + metric fields based on
		 * the threshold toggle state.
		 *
		 * @param {boolean} isChecked - Whether the threshold toggle is enabled
		 */
		updateCartThresholdDependentFields: function( isChecked ) {
			// The amount + metric rows only make sense when the threshold
			// checkbox itself is visible (it shows only in inline mode) AND checked.
			const groupVisible = jQuery( '#cev_enable_cart_threshold_verification' ).closest( '.zui-row' ).is( ':visible' );
			const show = isChecked && groupVisible;
			[ '#cev_cart_verification_threshold_amount', '#cev_cart_verification_threshold_metric' ].forEach( function( selector ) {
				const $field = jQuery( selector );
				if ( ! $field.length ) {
					return;
				}
				if ( show ) {
					$field.closest( '.zui-row' ).show();
				} else {
					$field.closest( '.zui-row' ).hide();
				}
			} );
		},

		/**
		 * Handle cart-total threshold toggle changes
		 */
		handleCartThresholdToggle: function() {
			const self = this;
			// Threshold and free-orders are mutually exclusive — enabling one
			// clears the other, since "verify only above $X" and "verify only
			// free orders" are opposite strategies.
			jQuery( document ).on( 'change', '#cev_enable_cart_threshold_verification', function() {
				const isChecked = jQuery( this ).prop( 'checked' );
				if ( isChecked ) {
					jQuery( '#cev_enable_email_verification_free_orders' ).prop( 'checked', false );
				}
				self.updateCartThresholdDependentFields( isChecked );
			} );
			jQuery( document ).on( 'change', '#cev_enable_email_verification_free_orders', function() {
				if ( jQuery( this ).prop( 'checked' ) ) {
					jQuery( '#cev_enable_cart_threshold_verification' ).prop( 'checked', false );
					self.updateCartThresholdDependentFields( false );
				}
			} );
		},

		/**
		 * Initialize cart-total threshold field visibility on page load
		 */
		initializeCartThresholdDependentFields: function() {
			const self = this;
			jQuery( document ).ready( function() {
				const $threshold = jQuery( '#cev_enable_cart_threshold_verification' );
				// Enforce mutual exclusivity on load — never show both checked
				// (keep the older free-orders option if a legacy save has both).
				if ( $threshold.prop( 'checked' ) && jQuery( '#cev_enable_email_verification_free_orders' ).prop( 'checked' ) ) {
					$threshold.prop( 'checked', false );
				}
				self.updateCartThresholdDependentFields( $threshold.prop( 'checked' ) );
			} );
		},

		/**
		 * Show/hide the conditional-category fields (multi-select + per-category
		 * messages) based on the toggle state.
		 *
		 * @param {boolean} isChecked - Whether the category toggle is enabled
		 */
		updateConditionalCategoryDependentFields: function( isChecked ) {
			// The category picker + messages only show when the category toggle
			// itself is visible (checkout verification on) AND checked.
			const groupVisible = jQuery( '#cev_enable_conditional_verification_by_category' ).closest( '.zui-row' ).is( ':visible' );
			const show = isChecked && groupVisible;
			[ '#cev_required_verification_categories', '#cev_conditional_category_message' ].forEach( function( selector ) {
				const $field = jQuery( selector );
				if ( ! $field.length ) {
					return;
				}
				if ( show ) {
					$field.closest( '.zui-row' ).show();
				} else {
					$field.closest( '.zui-row' ).hide();
				}
			} );
		},

		/**
		 * Handle conditional category-verification toggle changes
		 */
		handleConditionalCategoryToggle: function() {
			const self = this;
			jQuery( document ).on( 'change', '#cev_enable_conditional_verification_by_category', function() {
				self.updateConditionalCategoryDependentFields( jQuery( this ).prop( 'checked' ) );
			} );
		},

		/**
		 * Initialize conditional-category field visibility on page load
		 */
		initializeConditionalCategoryDependentFields: function() {
			const self = this;
			jQuery( document ).ready( function() {
				self.updateConditionalCategoryDependentFields(
					jQuery( '#cev_enable_conditional_verification_by_category' ).prop( 'checked' )
				);
			} );
		},

		/**
		 * Keep the per-category message rows in sync with the category
		 * multi-select: add an empty labelled textarea for each newly-selected
		 * category and remove rows for deselected ones (typed values persist).
		 */
		handleConditionalCategorySync: function() {
			jQuery( document ).on( 'change', '#cev_required_verification_categories', function() {
				const $container = jQuery( '[data-cev-category-messages]' );
				if ( ! $container.length ) {
					return;
				}

				// Map of currently-selected { catId: label } from the select options.
				const selected = {};
				jQuery( this ).find( 'option:selected' ).each( function() {
					selected[ jQuery( this ).val() ] = jQuery( this ).text();
				} );

				// Remove rows whose category is no longer selected.
				$container.find( '.cev-category-message-row' ).each( function() {
					const id = jQuery( this ).attr( 'data-cev-cat-id' );
					if ( typeof selected[ id ] === 'undefined' ) {
						jQuery( this ).remove();
					}
				} );

				// Add rows for newly-selected categories.
				Object.keys( selected ).forEach( function( id ) {
					if ( $container.find( '.cev-category-message-row[data-cev-cat-id="' + id + '"]' ).length ) {
						return;
					}
					const $label = jQuery( '<label class="cev-category-message-label"></label>' ).text( selected[ id ] );
					const $textarea = jQuery( '<textarea class="input-text regular-input" rows="2"></textarea>' )
						.attr( 'name', 'cev_conditional_category_message[' + id + ']' );
					const $row = jQuery( '<div class="cev-category-message-row"></div>' )
						.attr( 'data-cev-cat-id', id )
						.append( $label )
						.append( $textarea );
					$container.append( $row );
				} );
			} );
		},

		/**
		 * Update dependent fields based on checkout verification toggle state
		 *
		 * @param {boolean} isChecked - Whether checkout verification is enabled
		 */
		updateCheckoutDependentFields: function( isChecked ) {
			const $createAccountField = jQuery( '#cev_create_an_account_during_checkout' );
			const $cartPageField = jQuery( '#cev_enable_email_verification_cart_page' );
			const $verificationTypeField = jQuery( SELECTORS.VERIFICATION_TYPE );
			const $checkoutDropdownField = jQuery( SELECTORS.CHECKOUT_DROPDOWN );
			const $freeOrdersField = jQuery( '#cev_enable_email_verification_free_orders' );

			// Handle free orders checkbox
			if ( $freeOrdersField.length ) {
				if ( ! isChecked ) {
					// Uncheck and disable when checkout verification is disabled
					$freeOrdersField.prop( 'checked', false ).prop( 'disabled', true );
					$freeOrdersField.closest( '.zui-row' ).addClass( CLASSES.DISABLED );
				} else {
					// Enable when checkout verification is enabled
					$freeOrdersField.prop( 'disabled', false );
					$freeOrdersField.closest( '.zui-row' ).removeClass( CLASSES.DISABLED );
				}
			}

			// Handle checkout verification type dropdown
			if ( $checkoutDropdownField.length ) {
				if ( ! isChecked ) {
					// Disable when checkout verification is disabled
					$checkoutDropdownField.prop( 'disabled', true );
					$checkoutDropdownField.closest( '.zui-row' ).addClass( CLASSES.DISABLED );
				} else {
					// Enable when checkout verification is enabled
					$checkoutDropdownField.prop( 'disabled', false );
					$checkoutDropdownField.closest( '.zui-row' ).removeClass( CLASSES.DISABLED );
				}
			}

			// Handle create account checkbox
			if ( $createAccountField.length ) {
				if ( ! isChecked ) {
					// Uncheck and disable when checkout verification is disabled
					$createAccountField.prop( 'checked', false ).prop( 'disabled', true );
					$createAccountField.closest( '.zui-row' ).addClass( CLASSES.DISABLED );
				} else {
					// Enable when checkout verification is enabled
					$createAccountField.prop( 'disabled', false );
					$createAccountField.closest( '.zui-row' ).removeClass( CLASSES.DISABLED );
				}
			}

			// Handle cart page checkbox
			if ( $cartPageField.length ) {
				if ( ! isChecked ) {
					// Uncheck and disable when checkout verification is disabled
					$cartPageField.prop( 'checked', false ).prop( 'disabled', true );
					$cartPageField.closest( '.zui-row' ).addClass( CLASSES.DISABLED );
				} else {
					// Enable when checkout verification is enabled
					$cartPageField.prop( 'disabled', false );
					$cartPageField.closest( '.zui-row' ).removeClass( CLASSES.DISABLED );
				}
			}

			// Handle verification type dropdown
			if ( $verificationTypeField.length ) {
				if ( ! isChecked ) {
					// Disable when checkout verification is disabled
					$verificationTypeField.prop( 'disabled', true );
					$verificationTypeField.closest( '.zui-row' ).addClass( CLASSES.DISABLED );
				} else {
					// Enable when checkout verification is enabled
					$verificationTypeField.prop( 'disabled', false );
					$verificationTypeField.closest( '.zui-row' ).removeClass( CLASSES.DISABLED );
				}
			}

			// Handle cart-total threshold checkbox (sub-option of checkout verification)
			const $thresholdField = jQuery( '#cev_enable_cart_threshold_verification' );
			if ( $thresholdField.length ) {
				if ( ! isChecked ) {
					// Uncheck and disable when checkout verification is disabled
					$thresholdField.prop( 'checked', false ).prop( 'disabled', true );
					$thresholdField.closest( '.zui-row' ).addClass( CLASSES.DISABLED );
				} else {
					// Enable when checkout verification is enabled
					$thresholdField.prop( 'disabled', false );
					$thresholdField.closest( '.zui-row' ).removeClass( CLASSES.DISABLED );
				}
				// Keep the amount + metric rows in sync with the threshold state.
				FieldManager.updateCartThresholdDependentFields( $thresholdField.prop( 'checked' ) );
			}

			// Conditional category verification only applies when checkout
			// verification is on: show its toggle then, hide it otherwise. The
			// saved category selection is preserved (we don't uncheck it).
			const $categoryToggle = jQuery( '#cev_enable_conditional_verification_by_category' );
			if ( $categoryToggle.length ) {
				if ( isChecked ) {
					$categoryToggle.closest( '.zui-row' ).show();
				} else {
					$categoryToggle.closest( '.zui-row' ).hide();
				}
				// Re-sync the picker + messages (respects the visibility above).
				FieldManager.updateConditionalCategoryDependentFields( $categoryToggle.prop( 'checked' ) );
			}
		},

		/**
		 * Handle checkout toggle changes
		 */
		handleCheckoutToggle: function() {
			const self = this;
			jQuery( document ).on( 'change', SELECTORS.CHECKOUT_TOGGLE, function() {
				const isChecked = jQuery( this ).prop( 'checked' );
				self.updateCheckoutDependentFields( isChecked );
			} );
		},

		/**
		 * Update dependent fields based on login authentication toggle state
		 *
		 * @param {boolean} isChecked - Whether login authentication is enabled
		 */
		updateLoginAuthDependentFields: function( isChecked ) {
				const fieldsToToggle = [
					'#enable_email_otp_for_account',
					'#enable_email_auth_for_new_device',
					'#enable_email_auth_for_new_location',
					'#enable_email_auth_for_login_time',
				];

				fieldsToToggle.forEach( function( selector ) {
				const $field = jQuery( selector );
				if ( ! isChecked ) {
					// Uncheck and disable when login authentication is disabled
					$field.prop( 'checked', false ).prop( 'disabled', true );
					$field.closest( '.zui-row' ).addClass( CLASSES.DISABLED );
				} else {
					// Enable when login authentication is enabled
					$field.prop( 'disabled', false );
					$field.closest( '.zui-row' ).removeClass( CLASSES.DISABLED );
				}
			} );

			// Handle dropdown inside checkbox_select
			const $lastLoginTime = jQuery( '#cev_last_login_more_then_time' );
			if ( ! isChecked ) {
				$lastLoginTime.prop( 'disabled', true );
			} else {
				$lastLoginTime.prop( 'disabled', false );
			}

				jQuery( 'p#login_auth_desc' ).toggleClass( CLASSES.DISABLED, ! isChecked );
		},

		/**
		 * Handle login authentication toggle changes
		 */
		handleLoginAuthToggle: function() {
			const self = this;
			jQuery( document ).on( 'change', SELECTORS.LOGIN_AUTH_TOGGLE, function() {
				const isChecked = jQuery( this ).prop( 'checked' );
				self.updateLoginAuthDependentFields( isChecked );
			} );
		},

		/**
		 * Resolve the visibility of every Login Authentication condition row from
		 * both mode toggles at once.
		 *
		 * Two switches compete for the same rows, so the state is computed in one
		 * place rather than by independent handlers that would fight each other:
		 *   - "Require OTP on every login" ON  -> nothing below it can change the
		 *     outcome, so the whole conditions block hides.
		 *   - otherwise Smart detection ON     -> manual conditions hide, the
		 *     sensitivity selector shows (and vice versa).
		 *
		 * Rows are hidden, never disabled. Disabled inputs are not POSTed, and the
		 * per-section save writes 0 over any absent toggle — which would silently
		 * wipe the merchant's saved conditions. Hidden inputs still submit, so the
		 * values survive and return intact when the mode is switched back.
		 */
		updateLoginAuthVisibility: function() {
			// The marker classes sit on the .zui-row itself (settings-fields-list.php).
			const everyLogin = jQuery( '#cev_require_otp_every_login' ).prop( 'checked' );
			const smartOn    = jQuery( '#cev_smart_login_detection' ).prop( 'checked' );

			// Marker sits on rows AND on the divider that introduces the
			// verify-unverified group; a divider is .zui-row-divider, which is a
			// separate class token from .zui-row, so both are matched explicitly.
			jQuery( '.zui-row.cev-login-cond-block, .zui-row-divider.cev-login-cond-block' ).toggle( ! everyLogin );

			if ( ! everyLogin ) {
				jQuery( '.zui-row.cev-manual-login-cond' ).toggle( ! smartOn );
				jQuery( '.zui-row.cev-smart-login-sensitivity' ).toggle( !! smartOn );
			}

			// The conditions block's own divider has no marker class, so it is
			// anchored to the row after it. (The divider above the
			// verify-unverified group carries cev-login-cond-block itself, so it
			// is already handled by the toggle above.)
			jQuery( 'p#login_auth_desc' )
				.closest( '.zui-row' )
				.prev( '.zui-row-divider' )
				.toggle( ! everyLogin );
		},

		/**
		 * Wire both login-mode toggles to the shared show/hide behaviour.
		 */
		handleLoginAuthVisibility: function() {
			const self = this;
			jQuery( document ).on(
				'change',
				'#cev_smart_login_detection, #cev_require_otp_every_login',
				function() {
					self.updateLoginAuthVisibility();
				}
			);
		},

		/**
		 * Apply the login-mode show/hide state on page load.
		 */
		initializeLoginAuthVisibility: function() {
			if ( jQuery( '#cev_smart_login_detection' ).length || jQuery( '#cev_require_otp_every_login' ).length ) {
				this.updateLoginAuthVisibility();
			}
		},

		/**
		 * Handle cart page visibility on page load
		 */
		handleCartPageVisibility: function() {
			jQuery( document ).ready( function() {
				const checkoutValue = jQuery( SELECTORS.CHECKOUT_DROPDOWN ).val();
				if ( checkoutValue === CONFIG.CHECKOUT_TYPE_INLINE ) {
					jQuery( '#cev_enable_email_verification_cart_page' ).closest( '.zui-row' ).hide();
				}
			} );
		},

		/**
		 * Initialize checkout verification dependent fields on page load
		 */
		initializeCheckoutDependentFields: function() {
			const self = this;
			jQuery( document ).ready( function() {
				const isChecked = jQuery( SELECTORS.CHECKOUT_TOGGLE ).prop( 'checked' );
				self.updateCheckoutDependentFields( isChecked );
			} );
		},

		/**
		 * Initialize login authentication dependent fields on page load
		 */
		initializeLoginAuthDependentFields: function() {
			const self = this;
			jQuery( document ).ready( function() {
				const isChecked = jQuery( SELECTORS.LOGIN_AUTH_TOGGLE ).prop( 'checked' );
				self.updateLoginAuthDependentFields( isChecked );
			} );
		},

		/**
		 * Show / hide every field inside the Two-Factor Authentication
		 * section based on the master toggle. The intro description stays
		 * visible so users always see what the section is for.
		 *
		 * @param {boolean} isChecked Whether the master 2FA toggle is on.
		 */
		updateTwoFaDependentFields: function( isChecked ) {
			const dependentFields = [
				'#cev_login_auth_enforcement',
				'#cev_login_auth_roles',
				'#cev_2fa_grace_days',
			];
			dependentFields.forEach( function( selector ) {
				const $field = jQuery( selector );
				if ( ! $field.length ) {
					return;
				}
				const $row = $field.closest( '.zui-row' );
				if ( isChecked ) {
					$row.show();
				} else {
					$row.hide();
				}
			} );

			// The Roles row answers to a SECOND condition on top of the
			// master toggle: it is meaningless when the policy is "All
			// users". Re-apply that rule after the blanket show above,
			// or switching the master toggle on would resurrect a Roles
			// row the policy dropdown says should stay hidden.
			// updateTwoFaPolicyFields() ends with the embed re-check, so
			// return here rather than running it twice.
			if ( isChecked ) {
				this.updateTwoFaPolicyFields( jQuery( SELECTORS.TWO_FA_POLICY ).val() );
				return;
			}

			// Re-evaluate the embedded card's visibility — accounts for
			// both the master toggle and the policy-applies-to-me check.
			this.updateTwoFaEmbedVisibility();
		},

		/**
		 * Decide whether to show the admin's own 2FA setup card based on:
		 *   1. Master toggle (off → hide everything)
		 *   2. Already enrolled (always show — so they can disable / get codes)
		 *   3. "Policy applies to me" — replicates the server-side
		 *      CEV_2FA_Manager::policy_requires() logic in JS so the user
		 *      sees the card appear/disappear LIVE as they change the
		 *      policy dropdown or the Roles multi-select, without saving.
		 *
		 * Selected roles for the policy come from the multi-select's
		 * checked checkboxes (the field-multiple-select.php renderer
		 * outputs <input type="checkbox" name="cev_login_auth_roles[<role>]" value="1">).
		 */
		updateTwoFaEmbedVisibility: function() {
			const $embed = jQuery( '.cev-2fa-settings-embed' );
			if ( ! $embed.length ) {
				return;
			}
			// Show the admin's own setup card whenever the master toggle is
			// on (matches the target design). The visibility POLICY only
			// controls which users see the card on their My-Account page —
			// it no longer hides the admin's own card here, which read as
			// the section being "missing" whenever the saved policy
			// excluded administrators.
			const $toggle = jQuery( SELECTORS.TWO_FA_TOGGLE );
			if ( $toggle.length && ! $toggle.prop( 'checked' ) ) {
				$embed.hide();
				return;
			}
			$embed.show();
		},

		/**
		 * Bind change handler on the 2FA master toggle.
		 */
		handleTwoFaToggle: function() {
			const self = this;
			jQuery( document ).on( 'change', SELECTORS.TWO_FA_TOGGLE, function() {
				const isChecked = jQuery( this ).prop( 'checked' );
				self.updateTwoFaDependentFields( isChecked );
			} );
		},

		/**
		 * Apply the 2FA visibility rule on initial page load so the
		 * dependent fields are hidden by default (master toggle defaults
		 * to off).
		 */
		initializeTwoFaDependentFields: function() {
			const self = this;
			jQuery( document ).ready( function() {
				const isChecked = jQuery( SELECTORS.TWO_FA_TOGGLE ).prop( 'checked' );
				self.updateTwoFaDependentFields( isChecked );
			} );
		},

		/**
		 * Decide whether the Roles multi-select is visible. It needs BOTH
		 * conditions to hold: the section's master toggle must be on, and
		 * the "Show 2FA option to" dropdown must be one of the role-based
		 * modes — the Roles list is meaningless under "All users", which
		 * ignores roles entirely.
		 *
		 * The master-toggle half matters because this pass runs AFTER
		 * updateTwoFaDependentFields() on page load. Keying off the policy
		 * alone would re-show the Roles row on top of that pass's hide
		 * whenever the saved policy is role-based but 2FA is switched off.
		 *
		 * @param {string} policy Current value of the policy dropdown.
		 */
		updateTwoFaPolicyFields: function( policy ) {
			const $rolesField = jQuery( '#cev_login_auth_roles' );
			if ( $rolesField.length ) {
				const $toggle = jQuery( SELECTORS.TWO_FA_TOGGLE );
				const twoFaOn = ! $toggle.length || $toggle.prop( 'checked' );
				const $row    = $rolesField.closest( '.zui-row' );
				if ( twoFaOn && 'all_users' !== policy ) {
					$row.show();
				} else {
					$row.hide();
				}
			}
			// Policy change can flip "applies to me" — re-check the embed.
			this.updateTwoFaEmbedVisibility();
		},

		/**
		 * Bind change handlers on the "Apply 2FA to" dropdown AND on each
		 * role checkbox. Either change can flip whether the policy applies
		 * to the current admin, so we re-evaluate the embed visibility on
		 * both.
		 */
		handleTwoFaPolicyChange: function() {
			const self = this;
			jQuery( document ).on( 'change', SELECTORS.TWO_FA_POLICY, function() {
				self.updateTwoFaPolicyFields( jQuery( this ).val() );
			} );
			// Roles multi-select — the ZUI multiselect widget keeps the
			// hidden native <select multiple> as its source of truth and
			// dispatches a bubbling `change` on it whenever a chip is
			// added/removed. We bind to that.
			jQuery( document ).on( 'change', '#cev_login_auth_roles', function() {
				self.updateTwoFaEmbedVisibility();
			} );
		},

		/**
		 * Apply the policy-based visibility on initial page load so the
		 * Roles row is correctly shown/hidden based on the saved
		 * dropdown value, and the embed reflects the saved state.
		 */
		initializeTwoFaPolicyFields: function() {
			const self = this;
			jQuery( document ).ready( function() {
				const policy = jQuery( SELECTORS.TWO_FA_POLICY ).val();
				self.updateTwoFaPolicyFields( policy );
				self.updateTwoFaEmbedVisibility();
			} );
		},

		/**
		 * Update Spam Protection section visibility based on the four
		 * independent toggles inside it (Disposable + MX + B2B Allowlist
		 * + Blocked Emails).
		 *
		 * Layout:
		 *   - Disposable-only fields (incl. "Excluded domains"): shown
		 *     only when Disposable toggle is ON.
		 *   - MX-only fields: shown only when MX toggle is ON.
		 *   - B2B Allowlist fields: shown only when that toggle is ON.
		 *   - Blocked Emails fields: shown only when that toggle is ON.
		 *   - Section separators: always visible (delineate the blocks).
		 */
		updateSpamProtectionState: function() {
			const disposableOn   = jQuery( SELECTORS.DISPOSABLE_TOGGLE ).prop( 'checked' );
			const mxOn           = jQuery( SELECTORS.MX_TOGGLE ).prop( 'checked' );
			const b2bOn          = jQuery( SELECTORS.B2B_ALLOWLIST_TOGGLE ).prop( 'checked' );
			const blockedOn      = jQuery( SELECTORS.BLOCKED_EMAILS_TOGGLE ).prop( 'checked' );
			const aiRiskOn       = jQuery( SELECTORS.AI_RISK_TOGGLE ).prop( 'checked' );
			const botClusterOn   = jQuery( SELECTORS.BOT_CLUSTER_TOGGLE ).prop( 'checked' );

			// Helper: hide/show the <li> wrapping a field by selector.
			const toggleRow = function( selector, visible ) {
				const $field = jQuery( selector );
				if ( ! $field.length ) {
					return;
				}
				const $row = $field.closest( '.zui-row' );
				if ( visible ) {
					$row.show();
				} else {
					$row.hide();
				}
			};

			// Disposable-only fields (incl. excluded domains).
			toggleRow( '#cev_disposable_built_in_desc',     disposableOn );
			toggleRow( '#cev_disposable_custom_domains',    disposableOn );
			toggleRow( '#cev_disposable_excluded_domains',  disposableOn );
			toggleRow( '#cev_disposable_block_message',     disposableOn );
			toggleRow( '#cev_disposable_heuristic',         disposableOn );

			// MX-only fields.
			toggleRow( '#cev_mx_check_desc',    mxOn );
			toggleRow( '#cev_mx_fail_message',  mxOn );

			// B2B Allowlist fields.
			toggleRow( '#cev_b2b_allowlist_desc',           b2bOn );
			toggleRow( '#cev_domain_allowlist',             b2bOn );
			toggleRow( '#cev_domain_allowlist_message',     b2bOn );

			// Blocked Emails fields.
			toggleRow( '#cev_blocked_emails_desc',          blockedOn );
			toggleRow( '#cev_blocked_emails',               blockedOn );
			toggleRow( '#cev_blocked_emails_message',       blockedOn );

			// AI risk scoring fields.
			toggleRow( '#cev_ai_risk_desc',           aiRiskOn );
			toggleRow( '#cev_ai_risk_sensitivity',    aiRiskOn );
			toggleRow( '#cev_ai_risk_medium_action',  aiRiskOn );
			toggleRow( '#cev_ai_risk_high_action',    aiRiskOn );
			toggleRow( '#cev_ai_risk_block_message',  aiRiskOn );

			// Bot-cluster detection fields.
			toggleRow( '#cev_bot_cluster_desc',         botClusterOn );
			toggleRow( '#cev_bot_cluster_sensitivity',  botClusterOn );
			toggleRow( '#cev_bot_cluster_message',      botClusterOn );

			// Separators stay always visible.
		},

		/**
		 * Bind change handlers for the four Spam Protection toggles.
		 */
		handleSpamProtectionToggles: function() {
			const self = this;
			const selectorList = SELECTORS.DISPOSABLE_TOGGLE
				+ ',' + SELECTORS.MX_TOGGLE
				+ ',' + SELECTORS.B2B_ALLOWLIST_TOGGLE
				+ ',' + SELECTORS.BLOCKED_EMAILS_TOGGLE
				+ ',' + SELECTORS.AI_RISK_TOGGLE
				+ ',' + SELECTORS.BOT_CLUSTER_TOGGLE;
			jQuery( document ).on( 'change', selectorList, function() {
				self.updateSpamProtectionState();
			} );
		},

		/**
		 * Apply Spam Protection visibility on initial page load.
		 */
		initializeSpamProtectionState: function() {
			const self = this;
			jQuery( document ).ready( function() {
				self.updateSpamProtectionState();
			} );
		},
	};


	/**
	 * User log table management
	 */
	const UserLogTable = {
		table: null,

		/**
		 * Initialize DataTable
		 */
		init: function() {
			// Bind handlers that work via document delegation FIRST — these
			// must run even when the user-log table isn't rendered (e.g. on
			// the Maintenance tab, or empty-state on Unverified Users).
			this.handleCsvExport();
			this.handleRunCleanupNow();
			this.handlePreviewUnverifiedUsers();
			this.handleRunUserCleanupNow();
			this.handleUserCleanupCount();
			this.handleUserCleanupActivationGuard();
			this.handleReengagementRunNow();
			this.handleReengagementSendTest();
			this.handleSendReminderRowButton();
			this.handleForceReverifyAll();
			this.handleRowActionsMenu();

			const $table = jQuery( SELECTORS.USER_LOG_TABLE );
			if ( $table.length === 0 ) {
				return;
			}

			// DataTables is a vendored library. If it failed to load, degrade to
			// a plain table rather than throwing — an exception here used to
			// abort every init queued after UserLogTable in the ready handler
			// (segmented controls, Smart Form UI, date picker, row menus...).
			// The row-kebab and bulk handlers above are already bound by now.
			if ( ! jQuery.fn.DataTable ) {
				return;
			}

			this.table = $table.DataTable( {
				searching: false,
				lengthChange: false,
				pageLength: CONFIG.DATATABLE_PAGE_LENGTH,
				columnDefs: [
					{
						// Columns: 0 checkbox, 1 customer (avatar+name+email), 2 last updated, 3 risk, 4 actions kebab.
						orderable: false,
						targets: [ 0, 1, 2, 3, 4 ],
					},
					{
						width: '20px',
						targets: 0,
					},
					{
						className: 'text-right',
						targets: -1,
					},
					{
						targets: '_all',
						createdCell: function( td, cellData, rowData, row, col ) {
							// Right-align the Actions column.
							if ( col === 4 ) {
								jQuery( td ).css( 'text-align', 'right' );
							}
							if ( row === 0 ) {
								jQuery( td ).css( 'width', col === 0 ? '20px' : 'auto' );
							}
						},
					},
				],
				rowCallback: function( row ) {
					jQuery( row ).hover(
						function() {
							jQuery( this ).addClass( CLASSES.HOVER_ROW );
						},
						function() {
							jQuery( this ).removeClass( CLASSES.HOVER_ROW );
						}
					);
				},
			} );

			this.handleTabNavigation();
			this.handleSelectAll();
			this.handleBulkActions();
			this.handleDeleteButton();
		},

		/**
		 * Handle "Preview affected users" button (Task 5c).
		 *
		 * Calls the preview AJAX endpoint and renders up to 100 users
		 * that WOULD be deleted on the next run. Read-only — no
		 * deletion happens. Lets admins sanity-check their settings
		 * before turning auto-delete on.
		 */
		handlePreviewUnverifiedUsers: function() {
			jQuery( document ).on( 'click', '.cev_preview_unverified_users', function( e ) {
				e.preventDefault();

				const $btn   = jQuery( this );
				const $panel = $btn.closest( 'form' ).find( '.cev_user_cleanup_preview' );
				const nonce  = $btn.data( 'nonce' );

				if ( ! nonce || ! $panel.length ) {
					return;
				}

				$btn.prop( 'disabled', true );
				$panel.show().html( '<p class="cev-preview-loading">' + i18n( 'preview_loading', 'Loading…' ) + '</p>' );

				AjaxUtils.request( {
					data: {
						action: 'cev_preview_unverified_users',
						nonce:  nonce,
					},
					success: function( response ) {
						if ( ! response || ! response.success ) {
							const msg = ( response && response.data && response.data.message )
								? response.data.message
								: i18n( 'preview_failed', 'Preview failed.' );
							$panel.html( '<p class="cev-preview-error">' + msg + '</p>' );
							return;
						}

						const data = response.data || {};
						const candidates = data.candidates || [];
						const count = data.count || 0;
						const days = data.days || 0;

						let html = '<div class="cev-preview-header">';
						if ( count === 0 ) {
							html += '<strong>' + i18n( 'preview_no_users', 'No users currently match your settings.' ) + '</strong>';
							html += ' <span class="cev-preview-meta">' + i18n( 'preview_retention_window', 'Retention window: %d days. All recent / staff / paying customers are safely excluded.', days ) + '</span>';
							html += '</div>';
						} else {
							const headline = ( count === 1 )
								? i18n( 'preview_count_one', '1 user would be deleted on the next run.' )
								: i18n( 'preview_count_many', '%d users would be deleted on the next run.', count );
							html += '<strong>' + headline + '</strong>';
							html += ' <span class="cev-preview-meta">' + i18n( 'preview_retention_short', 'Retention window: %d days.', days ) + '</span>';
							html += '</div>';

							html += '<table class="cev-preview-table"><thead><tr>';
							html += '<th>' + i18n( 'preview_col_email', 'Email' ) + '</th>';
							html += '<th>' + i18n( 'preview_col_registered', 'Registered' ) + '</th>';
							html += '<th>' + i18n( 'preview_col_role', 'Role' ) + '</th>';
							html += '</tr></thead><tbody>';
							candidates.forEach( function( u ) {
								html += '<tr>';
								html += '<td>' + jQuery( '<div>' ).text( u.email || '' ).html() + '</td>';
								html += '<td>' + jQuery( '<div>' ).text( u.registered || '' ).html() + '</td>';
								html += '<td>' + jQuery( '<div>' ).text( u.role || '' ).html() + '</td>';
								html += '</tr>';
							} );
							html += '</tbody></table>';
						}

						html += '<p><button type="button" class="button-link cev_preview_hide">' + i18n( 'preview_hide', 'Hide preview' ) + '</button></p>';
						$panel.html( html );
					},
					error: function() {
						$panel.html( '<p class="cev-preview-error">' + i18n( 'preview_request_failed', 'Preview request failed.' ) + '</p>' );
					},
					complete: function() {
						$btn.prop( 'disabled', false );
					},
				} );
			} );

			// Hide preview link.
			jQuery( document ).on( 'click', '.cev_preview_hide', function( e ) {
				e.preventDefault();
				jQuery( this ).closest( '.cev_user_cleanup_preview' ).hide().empty();
			} );
		},

		/**
		 * Handle "Run now" button for user cleanup (Task 5c).
		 *
		 * Confirms with a styled modal first — this is destructive.
		 * Result is surfaced via the same Snackbar used for settings
		 * saves so the UX is consistent across the plugin.
		 */
		handleRunUserCleanupNow: function() {
			jQuery( document ).on( 'click', '.cev_run_user_cleanup_now', function( e ) {
				e.preventDefault();

				const $btn  = jQuery( this );
				const nonce = $btn.data( 'nonce' );
				if ( ! nonce ) {
					return;
				}

				CevModal.confirm( {
					title:       i18n( 'modal_user_cleanup_title', 'Run user cleanup now?' ),
					body:        '<p>' + i18n( 'modal_user_cleanup_body', 'This will permanently delete unverified user accounts that pass all the safeguard checks (orders, subscriptions, roles, recent login).' ) + '</p>'
						+ '<p><strong>' + i18n( 'modal_undone_warning', 'This action cannot be undone.' ) + '</strong></p>',
					confirmText: i18n( 'modal_user_cleanup_btn', 'Delete now' ),
					cancelText:  i18n( 'modal_btn_cancel', 'Cancel' ),
					destructive: true,
					onConfirm:   function() {
						$btn.prop( 'disabled', true );

						AjaxUtils.request( {
							data: {
								action: 'cev_run_user_cleanup_now',
								nonce:  nonce,
							},
							success: function( response ) {
								if ( response && response.success ) {
									const data = response.data || {};
									Snackbar.showSuccess( data.message || i18n( 'cleanup_complete', 'Cleanup complete.' ) );
								} else {
									const msg = ( response && response.data && response.data.message )
										? response.data.message
										: i18n( 'cleanup_failed', 'Cleanup failed.' );
									Snackbar.showWarning( msg );
								}
							},
							error: function() {
								Snackbar.showWarning( i18n( 'cleanup_request_failed', 'Cleanup request failed.' ) );
							},
							complete: function() {
								$btn.prop( 'disabled', false );
							},
						} );
					},
				} );
			} );
		},

		/**
		 * First-activation guard for the destructive user-cleanup toggle.
		 *
		 * If the admin flips the toggle ON, show a styled confirmation
		 * modal. If they cancel, revert the toggle to OFF so the next
		 * auto-save persists the OFF state.
		 *
		 * Note: the auto-save handler may have already fired with the
		 * ON state by the time the modal is closed. That's fine — when
		 * the user cancels, we re-trigger 'change' on the OFF toggle,
		 * which auto-saves OFF as the final state.
		 */
		handleUserCleanupActivationGuard: function() {
			jQuery( document ).on( 'change', '#cev_auto_delete_unverified_users', function() {
				const $toggle = jQuery( this );
				if ( ! $toggle.prop( 'checked' ) ) {
					return; // Turning OFF is always safe.
				}

				CevModal.confirm( {
					title:       i18n( 'modal_user_cleanup_activate_title', 'Enable auto-delete of unverified user accounts?' ),
					body:        '<p>' + i18n( 'modal_user_cleanup_activate_body', 'This will permanently delete WP user accounts that never verified their email after the retention window.' ) + '</p>'
						+ '<p><strong>' + i18n( 'modal_user_cleanup_safeguards_intro', 'Safeguards (always applied):' ) + '</strong></p>'
						+ '<ul>'
						+ '<li>' + i18n( 'modal_user_cleanup_skip_verified', 'Verified users are never deleted' ) + '</li>'
						+ '<li>' + i18n( 'modal_user_cleanup_skip_orders', 'Users with any orders are never deleted' ) + '</li>'
						+ '<li>' + i18n( 'modal_user_cleanup_skip_subs', 'Users with active subscriptions are never deleted' ) + '</li>'
						+ '<li>' + i18n( 'modal_user_cleanup_skip_role', 'Users with elevated roles (admin, editor, etc.) are never deleted' ) + '</li>'
						+ '<li>' + i18n( 'modal_user_cleanup_skip_login', 'Users with login activity in the last 30 days are never deleted' ) + '</li>'
						+ '</ul>'
						+ '<p><em>' + i18n( 'modal_user_cleanup_recommend', 'Recommended: click <strong>Preview affected users</strong> first to see what would be deleted.' ) + '</em></p>',
					confirmText: i18n( 'modal_btn_enable', 'Enable' ),
					cancelText:  i18n( 'modal_btn_cancel', 'Cancel' ),
					destructive: true,
					onCancel:    function() {
						// User backed out — revert the toggle and re-fire
						// the change event so auto-save persists OFF.
						$toggle.prop( 'checked', false ).trigger( 'change' );
					},
				} );
			} );
		},

		/**
		 * Tools → "Force re-verify all customers".
		 *
		 * Fetches the affected-user count, shows a destructive confirmation
		 * modal, then kicks off the background re-verify job on confirm.
		 */
		handleForceReverifyAll: function() {
			jQuery( document ).on( 'click', '.cev_force_reverify_all', function( e ) {
				e.preventDefault();

				const $btn  = jQuery( this );
				const nonce = $btn.data( 'nonce' );
				if ( ! nonce ) {
					return;
				}

				$btn.prop( 'disabled', true );

				// Step 1 — fetch the affected count for the modal.
				AjaxUtils.request( {
					data: {
						action: 'cev_count_force_reverify',
						nonce:  nonce,
					},
					success: function( response ) {
						const data     = ( response && response.data ) ? response.data : {};
						const countMsg = data.message || i18n( 'force_reverify_count_fallback', 'Selected customers will be marked unverified.' );

						CevModal.confirm( {
							title:       i18n( 'modal_force_reverify_title', 'Force re-verify all customers?' ),
							body:        '<p>' + countMsg + '</p>'
								+ '<p>' + i18n( 'modal_force_reverify_body', 'They will be required to verify their email on their next login. Nobody is deleted.' ) + '</p>'
								+ '<p><strong>' + i18n( 'modal_undone_warning', 'This action cannot be undone.' ) + '</strong></p>',
							confirmText: i18n( 'modal_force_reverify_btn', 'Force re-verify' ),
							cancelText:  i18n( 'modal_btn_cancel', 'Cancel' ),
							destructive: true,
							onConfirm:   function() {
								// Step 2 — start the background job.
								AjaxUtils.request( {
									data: {
										action: 'cev_force_reverify_all',
										nonce:  nonce,
									},
									success: function( res ) {
										if ( res && res.success ) {
											const d = res.data || {};
											Snackbar.showSuccess( d.message || i18n( 'force_reverify_started', 'Force re-verify started.' ) );
										} else {
											const msg = ( res && res.data && res.data.message )
												? res.data.message
												: i18n( 'force_reverify_failed', 'Could not start force re-verify.' );
											Snackbar.showWarning( msg );
										}
									},
									error: function() {
										Snackbar.showWarning( i18n( 'force_reverify_failed', 'Could not start force re-verify.' ) );
									},
									complete: function() {
										$btn.prop( 'disabled', false );
									},
								} );
							},
							onCancel: function() {
								$btn.prop( 'disabled', false );
							},
						} );
					},
					error: function() {
						Snackbar.showWarning( i18n( 'force_reverify_count_failed', 'Could not load the affected user count.' ) );
						$btn.prop( 'disabled', false );
					},
				} );
			} );
		},

		/**
		 * Lazy "N users eligible for deletion" note on the Maintenance card.
		 *
		 * The count scans customer accounts, which on a large store takes
		 * seconds — so PHP no longer computes it during the page render.
		 * The template marks the note with data-cev-needs-count="1" when no
		 * cached value exists; we fetch it ONCE, the first time the card is
		 * actually displayed — on load when Maintenance is the section being
		 * opened, otherwise when the merchant switches to it.
		 *
		 * `offsetParent === null` is the display test: every tab panel and
		 * sidebar section ships in the DOM on each page load with the
		 * inactive ones hidden, so a hidden card has no layout box. (An
		 * IntersectionObserver is the wrong tool here — it also requires the
		 * card to be scrolled into the viewport, which would leave the note
		 * stuck on "Counting…" for a merchant who never scrolls down.)
		 */
		handleUserCleanupCount: function() {
			const note = document.querySelector( '.cev_user_cleanup_eligible[data-cev-needs-count="1"]' );
			if ( ! note ) {
				return;
			}

			const $note = jQuery( note );
			let requested = false;

			const fetchCount = function() {
				// offsetParent is null while any ancestor is display:none.
				if ( requested || null === note.offsetParent ) {
					return;
				}
				requested = true;

				AjaxUtils.request( {
					data: {
						action: 'cev_user_cleanup_count',
						nonce:  $note.data( 'nonce' ),
					},
					success: function( response ) {
						if ( response && response.success && response.data && response.data.message ) {
							$note.text( response.data.message );
						} else {
							$note.text( i18n( 'user_cleanup_count_failed', 'Could not count eligible accounts.' ) );
						}
					},
					error: function() {
						$note.text( i18n( 'user_cleanup_count_failed', 'Could not count eligible accounts.' ) );
					},
					complete: function() {
						$note.attr( 'data-cev-needs-count', '0' );
					},
				} );
			};

			// Already on screen (deep link to ?tab=unverified-users&section=maintenance).
			fetchCount();

			// Otherwise: the top tab or the sidebar section that holds it is
			// opened. Both switch panels synchronously, so re-check on the
			// next tick.
			const recheck = function() {
				window.setTimeout( fetchCount, 0 );
			};
			document.addEventListener( 'cev:top-tab', recheck );
			document.addEventListener( 'zui:section', recheck );
		},

		/**
		 * Handle "Run cleanup now" button on the Maintenance tab.
		 *
		 * Triggers the daily-cleanup callback on demand so admins don't
		 * have to wait 24 hours to see their settings take effect. The
		 * result is surfaced via the same Snackbar used for settings
		 * saves, so the UX is consistent across the plugin.
		 */
		handleRunCleanupNow: function() {
			jQuery( document ).on( 'click', '.cev_run_cleanup_now', function( e ) {
				e.preventDefault();

				const $btn  = jQuery( this );
				const nonce = $btn.data( 'nonce' );
				if ( ! nonce ) {
					return;
				}

				$btn.prop( 'disabled', true );

				AjaxUtils.request( {
					data: {
						action: 'cev_run_cleanup_now',
						nonce:  nonce,
					},
					success: function( response ) {
						if ( response && response.success ) {
							const data = ( response.data && response.data.message ) ? response.data : {};
							Snackbar.showSuccess( data.message || i18n( 'cleanup_complete', 'Cleanup complete.' ) );
						} else {
							const msg = ( response && response.data && response.data.message )
								? response.data.message
								: i18n( 'cleanup_failed', 'Cleanup failed.' );
							Snackbar.showWarning( msg );
						}
					},
					error: function() {
						Snackbar.showWarning( i18n( 'cleanup_request_failed', 'Cleanup request failed.' ) );
					},
					complete: function() {
						$btn.prop( 'disabled', false );
					},
				} );
			} );
		},

		/**
		 * Handle Export CSV button click on the Unverified Users tab.
		 *
		 * Builds a download URL for the AJAX handler and navigates the
		 * browser to it — the handler streams the file with a Content-
		 * Disposition: attachment header so it downloads instead of
		 * navigating away.
		 */
		handleCsvExport: function() {
			jQuery( document ).on( 'click', '.cev_export_unverified_csv', function( e ) {
				e.preventDefault();

				const nonce = jQuery( this ).data( 'nonce' );
				if ( ! nonce ) {
					return;
				}

				// Resolve the AJAX URL the same way the rest of the file does.
				let ajaxUrl = '';
				if ( typeof ajaxurl !== 'undefined' ) {
					ajaxUrl = ajaxurl;
				} else if ( typeof cev_vars !== 'undefined' && cev_vars.ajax_url ) {
					ajaxUrl = cev_vars.ajax_url;
				} else {
					ajaxUrl = '/wp-admin/admin-ajax.php';
				}

				const url = ajaxUrl
					+ '?action=cev_export_unverified_users'
					+ '&nonce=' + encodeURIComponent( nonce );

				// Trigger download by navigating; Content-Disposition: attachment
				// keeps the user on the current page.
				window.location.href = url;
			} );
		},

		/**
		 * Handle tab navigation
		 */
		handleTabNavigation: function() {
			jQuery( document ).on( 'click', '.cev_tab_input', function() {
				const tab = jQuery( this ).data( 'tab' );
				const url =
					window.location.protocol +
					'//' +
					window.location.host +
					window.location.pathname +
					'?page=customer-email-verification-for-woocommerce&tab=' +
					tab;
				window.history.pushState( { path: url }, '', url );
			} );

			// Sub-tab persistence — remember the active sub-tab via the URL
			// hash so a full page reload (e.g. after Save, or navigating away
			// and back) restores the same sub-tab the user was viewing
			// instead of snapping back to the default "User List".
			const $subInputs = jQuery( '.cev_subtab_input' );
			if ( $subInputs.length ) {
				// 1. On load: if the current URL hash matches a sub-tab radio
				//    ID, force-check that radio so the matching panel is shown.
				const initialHash = ( window.location.hash || '' ).replace( /^#/, '' );
				if ( initialHash ) {
					const $target = jQuery( '#' + initialHash );
					if ( $target.length && $target.hasClass( 'cev_subtab_input' ) ) {
						$target.prop( 'checked', true );
					}
				}

				// 2. On change: write the active sub-tab's ID into the URL
				//    hash. Uses history.replaceState so the back-button
				//    history doesn't fill up with a hash entry per click.
				$subInputs.on( 'change', function() {
					const id = jQuery( this ).attr( 'id' );
					if ( ! id ) {
						return;
					}
					if ( window.history && window.history.replaceState ) {
						window.history.replaceState( null, '', '#' + id );
					} else {
						window.location.hash = id;
					}
				} );
			}
		},

		/**
		 * Handle select all checkbox
		 */
		handleSelectAll: function() {
			const selectAll = document.getElementById( 'select_all' );
			if ( selectAll ) {
				selectAll.addEventListener( 'click', function() {
					const checkboxes = document.querySelectorAll( '.row_checkbox' );
					checkboxes.forEach( function( checkbox ) {
						checkbox.checked = this.checked;
					}, this );
				} );
			}
		},

		/**
		 * Handle bulk actions.
		 *
		 * Confirmation is shown via the styled CevModal (matches WP-admin
		 * design) instead of the native `window.confirm()` dialog.
		 */
		handleBulkActions: function() {
			const self = this;
			jQuery( '.apply_bulk_action' ).on( 'click', function() {
				const action = jQuery( '#bulk_action' ).val();
				const $btn   = jQuery( this );

				const selectedIds = [];
				jQuery( '.row_checkbox:checked' ).each( function() {
					selectedIds.push( jQuery( this ).val() );
				} );

				if ( selectedIds.length === 0 ) {
					Snackbar.showWarning( MESSAGES.NO_USERS_SELECTED );
					return;
				}

				// ── Delete ────────────────────────────────────────────
				if ( action === 'delete' ) {
					const deleteBody = ( selectedIds.length === 1 )
						? i18n( 'modal_delete_body_one', 'This will permanently delete <strong>1</strong> verification log entry.' )
						: i18n( 'modal_delete_body_many', 'This will permanently delete <strong>%d</strong> verification log entries.', selectedIds.length );
					CevModal.confirm( {
						title:       i18n( 'modal_delete_title', 'Delete selected users?' ),
						body:        '<p>' + deleteBody + '</p><p>' + i18n( 'modal_undone_warning', 'This action cannot be undone.' ) + '</p>',
						confirmText: i18n( 'modal_btn_delete', 'Delete' ),
						cancelText:  i18n( 'modal_btn_cancel', 'Cancel' ),
						destructive: true,
						onConfirm:   function() {
							self.deleteUsers( selectedIds );
						},
					} );
					return;
				}

				// ── Send re-engagement reminder ───────────────────────
				if ( action === 'send_reminder' ) {
					const nonce = $btn.data( 'send-reminder-nonce' );
					if ( ! nonce ) {
						Snackbar.showWarning( i18n( 'missing_security_token', 'Missing security token. Please reload the page.' ) );
						return;
					}
					const reminderBody = ( selectedIds.length === 1 )
						? i18n( 'modal_send_reminder_body_one', 'Send the customizer-defined reminder email to <strong>1</strong> user.' )
						: i18n( 'modal_send_reminder_body_many', 'Send the customizer-defined reminder email to <strong>%d</strong> users.', selectedIds.length );
					CevModal.confirm( {
						title:       i18n( 'modal_send_reminder_title', 'Send re-engagement reminder?' ),
						body:        '<p>' + reminderBody + '</p><p>' + i18n( 'modal_send_reminder_safeguards', 'Users who already verified, have orders, or were active recently are skipped automatically.' ) + '</p>',
						confirmText: i18n( 'modal_btn_send', 'Send' ),
						cancelText:  i18n( 'modal_btn_cancel', 'Cancel' ),
						destructive: false,
						onConfirm:   function() {
							self.bulkSendReminders( selectedIds, nonce );
						},
					} );
					return;
				}
			} );
		},

		/**
		 * Bulk-send re-engagement reminders to the selected log rows.
		 *
		 * Reuses the snackbar pattern + the same id-array convention as
		 * the bulk delete handler so server-side handling stays simple.
		 *
		 * @param {Array}  selectedIds   Log entry IDs.
		 * @param {string} nonce         Pre-issued nonce (data-attribute).
		 */
		bulkSendReminders: function( selectedIds, nonce ) {
			AjaxUtils.request( {
				data: {
					action: 'cev_reengagement_send_bulk',
					nonce:  nonce,
					ids:    selectedIds,
				},
				success: function( response ) {
					if ( response && response.success ) {
						const data = response.data || {};
						Snackbar.showSuccess( data.message || i18n( 'reminders_sent', 'Reminders sent.' ) );
					} else {
						const msg = ( response && response.data && response.data.message )
							? response.data.message
							: i18n( 'bulk_send_failed', 'Bulk send failed.' );
						Snackbar.showWarning( msg );
					}
				},
				error: function( xhr ) {
					const msg = ( xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message )
						? xhr.responseJSON.data.message
						: i18n( 'bulk_send_failed_mailer', 'Bulk send failed. Check your mailer configuration.' );
					Snackbar.showWarning( msg );
				},
			} );
		},

		/**
		 * Per-row Actions kebab menu.
		 *
		 * The Unverified Users table now has a single Actions column
		 * with a vertical-ellipsis button per row. Clicking the button
		 * toggles a small popover containing Send / Delete actions.
		 *
		 * One menu can be open at a time. Closes on:
		 *   - clicking the toggle again
		 *   - clicking outside the menu
		 *   - pressing Escape
		 *   - clicking any action inside the menu (handlers below
		 *     run on the actual buttons via existing delegation)
		 */
		handleRowActionsMenu: function() {
			// Self-contained kebab (.zui-actions) toggle owned HERE in admin.js
			// rather than leaning on the shared zui.js. When several Zorem
			// plugins each ship their own zui.js, the `if ( window.ZUI ) return;`
			// guard lets whichever loaded FIRST win — an older copy without the
			// actions-menu wiring would otherwise leave the kebab dead. We run on
			// the CAPTURE phase + stopPropagation so we fire before (and suppress)
			// any zui.js bubble-phase handler, which prevents a double-toggle.
			const closeAll = function() {
				document.querySelectorAll( '.zui-actions-menu' ).forEach( function( m ) { m.hidden = true; } );
				document.querySelectorAll( '.zui-actions-toggle' ).forEach( function( t ) { t.setAttribute( 'aria-expanded', 'false' ); } );
			};

			document.addEventListener( 'click', function( e ) {
				const toggle = e.target.closest ? e.target.closest( '.zui-actions-toggle' ) : null;
				if ( ! toggle ) {
					return;
				}
				e.preventDefault();
				e.stopPropagation();
				const menu = toggle.parentNode.querySelector( '.zui-actions-menu' );
				if ( ! menu ) {
					return;
				}
				const willOpen = menu.hidden;
				closeAll();
				menu.hidden = ! willOpen;
				toggle.setAttribute( 'aria-expanded', willOpen ? 'true' : 'false' );
			}, true );

			// Close on outside click, or after picking an action inside the menu.
			document.addEventListener( 'click', function( e ) {
				const inActions = e.target.closest && e.target.closest( '.zui-actions' );
				const onItem    = e.target.closest && e.target.closest( '.zui-actions-item' );
				if ( ! inActions || onItem ) {
					closeAll();
				}
			} );

			// Close on Escape.
			document.addEventListener( 'keydown', function( e ) {
				if ( 'Escape' === e.key || 27 === e.keyCode ) {
					closeAll();
				}
			} );
		},

		/**
		 * Per-row "Send re-engagement reminder" icon on the Unverified
		 * Users table (Task 5d).
		 *
		 * No confirmation modal — sending an email isn't destructive,
		 * and confirming every single click adds friction without
		 * meaningfully reducing risk.
		 */
		handleSendReminderRowButton: function() {
			jQuery( document ).on( 'click', '.cev_send_reminder_button', function( e ) {
				e.preventDefault();

				const $btn  = jQuery( this );
				const id    = $btn.data( 'id' );
				const nonce = $btn.data( 'nonce' );
				if ( ! id || ! nonce ) {
					return;
				}

				$btn.prop( 'disabled', true );

				AjaxUtils.request( {
					data: {
						action: 'cev_reengagement_send_one',
						nonce:  nonce,
						id:     id,
					},
					success: function( response ) {
						if ( response && response.success ) {
							const data = response.data || {};
							Snackbar.showSuccess( data.message || i18n( 'reminder_sent', 'Reminder sent.' ) );
						} else {
							const msg = ( response && response.data && response.data.message )
								? response.data.message
								: i18n( 'could_not_send_reminder', 'Could not send reminder.' );
							Snackbar.showWarning( msg );
						}
					},
					error: function( xhr ) {
						// Try to surface the JSON error body's message instead
						// of a generic "request failed" — covers the case where
						// the server returns a non-2xx status with a JSON body.
						const msg = ( xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message )
							? xhr.responseJSON.data.message
							: i18n( 'could_not_send_reminder_mailer', 'Could not send reminder. Check your mailer configuration.' );
						Snackbar.showWarning( msg );
					},
					complete: function() {
						$btn.prop( 'disabled', false );
					},
				} );
			} );
		},

		/**
		 * "Run now" button on the Re-engagement card (Maintenance tab).
		 *
		 * Triggers the daily reminder cron immediately so the admin
		 * doesn't have to wait until the next nightly run to see
		 * their settings take effect.
		 */
		handleReengagementRunNow: function() {
			jQuery( document ).on( 'click', '.cev_reengagement_run_now', function( e ) {
				e.preventDefault();

				const $btn  = jQuery( this );
				const nonce = $btn.data( 'nonce' );
				if ( ! nonce ) {
					return;
				}

				$btn.prop( 'disabled', true );

				AjaxUtils.request( {
					data: {
						action: 'cev_reengagement_run_now',
						nonce:  nonce,
					},
					success: function( response ) {
						if ( response && response.success ) {
							const data = response.data || {};
							Snackbar.showSuccess( data.message || i18n( 'reminders_sent', 'Reminders sent.' ) );
						} else {
							const msg = ( response && response.data && response.data.message )
								? response.data.message
								: i18n( 'run_failed', 'Run failed.' );
							Snackbar.showWarning( msg );
						}
					},
					error: function( xhr ) {
						const msg = ( xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message )
							? xhr.responseJSON.data.message
							: i18n( 'run_failed_mailer', 'Run failed. Check your mailer configuration.' );
						Snackbar.showWarning( msg );
					},
					complete: function() {
						$btn.prop( 'disabled', false );
					},
				} );
			} );
		},

		/**
		 * "Send test" button on the Re-engagement card.
		 *
		 * Sends the rendered reminder email to the current admin so
		 * they can sanity-check customizer changes without waiting
		 * for a real eligible user.
		 */
		handleReengagementSendTest: function() {
			jQuery( document ).on( 'click', '.cev_reengagement_send_test', function( e ) {
				e.preventDefault();

				const $btn  = jQuery( this );
				const nonce = $btn.data( 'nonce' );
				if ( ! nonce ) {
					return;
				}

				$btn.prop( 'disabled', true );

				AjaxUtils.request( {
					data: {
						action: 'cev_reengagement_send_test',
						nonce:  nonce,
					},
					success: function( response ) {
						if ( response && response.success ) {
							const data = response.data || {};
							Snackbar.showSuccess( data.message || i18n( 'test_email_sent', 'Test email sent.' ) );
						} else {
							const msg = ( response && response.data && response.data.message )
								? response.data.message
								: i18n( 'test_send_failed', 'Test send failed.' );
							Snackbar.showWarning( msg );
						}
					},
					error: function( xhr ) {
						const msg = ( xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message )
							? xhr.responseJSON.data.message
							: i18n( 'test_send_failed_mailer', 'Test send failed. Check your mailer configuration.' );
						Snackbar.showWarning( msg );
					},
					complete: function() {
						$btn.prop( 'disabled', false );
					},
				} );
			} );
		},

		/**
		 * Handle per-row delete button.
		 *
		 * Confirmation is shown via the styled CevModal.
		 */
		handleDeleteButton: function() {
			const self = this;
			jQuery( document ).on( 'click', '.delete_button', function() {
				const $button = jQuery( this );
				const userId  = $button.data( 'id' );
				// Pull the email from the same row for a more informative
				// confirmation prompt.
				const $row    = $button.closest( 'tr' );
				const email   = $row.find( 'td' ).eq( 1 ).text().trim();

				const safeEmail = email ? jQuery( '<div>' ).text( email ).html() : '';
				const bodyEmail = email
					? '<p>' + i18n( 'modal_delete_one_body', 'Permanently delete the verification log entry for <strong>%s</strong>?', safeEmail ) + '</p>'
					: '<p>' + i18n( 'modal_delete_one_body_no_email', 'Permanently delete this verification log entry?' ) + '</p>';

				CevModal.confirm( {
					title:       i18n( 'modal_delete_one_title', 'Delete this entry?' ),
					body:        bodyEmail + '<p>' + i18n( 'modal_undone_warning', 'This action cannot be undone.' ) + '</p>',
					confirmText: i18n( 'modal_btn_delete', 'Delete' ),
					cancelText:  i18n( 'modal_btn_cancel', 'Cancel' ),
					destructive: true,
					onConfirm:   function() {
						self.deleteUser( userId, $button );
					},
				} );
			} );
		},

		/**
		 * Delete single user
		 *
		 * @param {string} userId - User ID to delete
		 * @param {jQuery} $button - Delete button element
		 */
		deleteUser: function( userId, $button ) {
			if ( ! this.table ) {
				return;
			}

			AjaxUtils.request( {
				url: typeof cev_vars !== 'undefined' ? cev_vars.ajax_url : ajaxurl,
				data: {
					action: AJAX_ACTIONS.DELETE_USER,
					nonce: typeof cev_vars !== 'undefined' ? cev_vars.delete_user_nonce : '',
					id: userId,
				},
				success: ( response ) => {
					if ( typeof AjaxResponseHandler !== 'undefined' && AjaxResponseHandler.isSuccess( response ) ) {
						this.table.row( $button.closest( 'tr' ) ).remove().draw();
						const message = response.message || MESSAGES.USER_DELETED;
						Snackbar.showSuccess( message );
					} else {
						const errorMessage = ( typeof AjaxResponseHandler !== 'undefined' )
							? AjaxResponseHandler.getErrorMessage( response, MESSAGES.ERROR_DELETING_USER )
							: ( response && response.error && response.error.message ) ? response.error.message : MESSAGES.ERROR_DELETING_USER;
						Snackbar.showWarning( errorMessage );
					}
				},
				error: ( xhr, status, error ) => {
					const errorMessage = ( typeof AjaxResponseHandler !== 'undefined' )
						? AjaxResponseHandler.getErrorMessage( xhr.responseJSON, MESSAGES.ERROR_DELETING_USER )
						: ( xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ) ? xhr.responseJSON.error.message : MESSAGES.ERROR_DELETING_USER;
					Snackbar.showWarning( errorMessage );
				},
			} );
		},

		/**
		 * Delete multiple users
		 *
		 * @param {Array} selectedIds - Array of user IDs to delete
		 */
		deleteUsers: function( selectedIds ) {
			if ( ! this.table ) {
				return;
			}

			AjaxUtils.request( {
				url: typeof cev_vars !== 'undefined' ? cev_vars.ajax_url : ajaxurl,
				data: {
					action: AJAX_ACTIONS.DELETE_USERS,
					nonce: typeof cev_vars !== 'undefined' ? cev_vars.delete_user_nonce : '',
					ids: selectedIds,
				},
				success: ( response ) => {
					if ( typeof AjaxResponseHandler !== 'undefined' && AjaxResponseHandler.isSuccess( response ) ) {
						// Remove successfully deleted rows
						const responseData = AjaxResponseHandler.getData( response );
						if ( responseData.deletedIds ) {
							responseData.deletedIds.forEach( ( id ) => {
								this.table.row( jQuery( 'input[value="' + id + '"]' ).closest( 'tr' ) ).remove().draw();
							} );
						} else {
							// Fallback: remove all selected IDs
							selectedIds.forEach( ( id ) => {
								this.table.row( jQuery( 'input[value="' + id + '"]' ).closest( 'tr' ) ).remove().draw();
							} );
						}
						const message = response.message || MESSAGES.USERS_DELETED;
						Snackbar.showSuccess( message );
					} else {
						const responseData = ( typeof AjaxResponseHandler !== 'undefined' ) ? AjaxResponseHandler.getData( response ) : ( response && response.data ) ? response.data : {};
						let errorMessage = ( typeof AjaxResponseHandler !== 'undefined' )
							? AjaxResponseHandler.getErrorMessage( response, MESSAGES.ERROR_DELETING_USERS )
							: ( response && response.error && response.error.message ) ? response.error.message : MESSAGES.ERROR_DELETING_USERS;
						if ( errorMessage === MESSAGES.ERROR_DELETING_USERS && responseData.messages && responseData.messages.length > 0 ) {
							errorMessage = responseData.messages[0];
						}
						Snackbar.showWarning( errorMessage );
					}
				},
				error: ( xhr, status, error ) => {
					const errorMessage = ( typeof AjaxResponseHandler !== 'undefined' )
						? AjaxResponseHandler.getErrorMessage( xhr.responseJSON, MESSAGES.ERROR_DELETING_USERS )
						: ( xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message ) ? xhr.responseJSON.error.message : MESSAGES.ERROR_DELETING_USERS;
					Snackbar.showWarning( errorMessage );
				},
			} );
		},
	};

	/**
	 * Activity panel handler
	 */
	const ActivityPanel = {
		/**
		 * Initialize activity panel handlers
		 */
		init: function() {
			jQuery( document ).on( 'click', SELECTORS.ACTIVITY_PANEL_TAB, function() {
				jQuery( this ).addClass( CLASSES.IS_ACTIVE );
				jQuery( SELECTORS.ACTIVITY_PANEL_WRAPPER ).addClass( CLASSES.IS_OPEN + ' ' + CLASSES.IS_SWITCHING );
			} );

			jQuery( document ).on( 'click', function( event ) {
				const $trigger = jQuery( SELECTORS.ACTIVITY_PANEL );
				if ( ! $trigger.is( event.target ) && ! $trigger.has( event.target ).length ) {
					jQuery( SELECTORS.ACTIVITY_PANEL_TAB ).removeClass( CLASSES.IS_ACTIVE );
					jQuery( SELECTORS.ACTIVITY_PANEL_WRAPPER ).removeClass( CLASSES.IS_OPEN + ' ' + CLASSES.IS_SWITCHING );
				}
			} );
		},
	};

	/**
	 * Popup menu handler
	 */
	const PopupMenu = {
		/**
		 * Initialize popup menu
		 */
		init: function() {
			const menuButton = document.querySelector( SELECTORS.MENU_BUTTON );
			const popupMenu = document.querySelector( SELECTORS.POPUP_MENU );

			if ( ! menuButton || ! popupMenu ) {
				return;
			}

			// Toggle menu visibility on button click
			menuButton.addEventListener( 'click', function( e ) {
				e.preventDefault();
				e.stopPropagation();
				const isVisible = popupMenu.style.display === 'block';
				popupMenu.style.display = isVisible ? 'none' : 'block';
			} );

			// Close menu when clicking outside
			document.addEventListener( 'click', function( e ) {
				if ( menuButton && popupMenu && ! menuButton.contains( e.target ) && ! popupMenu.contains( e.target ) ) {
					popupMenu.style.display = 'none';
				}
			} );
		},
	};

	/**
	 * Miscellaneous handlers
	 */
	const MiscHandlers = {
		/**
		 * Initialize miscellaneous handlers
		 */
		init: function() {
			this.handleDelayAccountCheck();
			this.initTooltips();
		},

		/**
		 * Handle delay account check radio buttons
		 */
		handleDelayAccountCheck: function() {
			jQuery( document ).on( 'click', '.delay_account_check', function() {
				if ( jQuery( this ).prop( 'checked' ) === true ) {
					jQuery( '.delay_account_check' ).prop( 'checked', false );
					jQuery( this ).prop( 'checked', true );
				}
			} );
		},

		/**
		 * Initialize tooltips
		 */
		initTooltips: function() {
			jQuery( document ).ready( function() {
				if ( typeof jQuery.fn.tipTip !== 'undefined' ) {
					jQuery( '.woocommerce-help-tip' ).tipTip();
				}
			} );
		},
	};

	/**
	 * Top-tab switching (in-page, no reload)
	 *
	 * All top-tab panels are server-rendered in the DOM (only the active one
	 * visible), so switching tabs is a pure show/hide — no reload needed.
	 * The tab URL is still pushed to history so refresh / back-forward /
	 * deep links keep working (the server renders the right panel for ?tab=).
	 * The Customize tab carries no data-cev-tab attribute and navigates
	 * normally (it's a separate admin page).
	 */
	const TopTabs = {
		init: function() {
			const self = this;

			jQuery( document ).on( 'click', '.zui-tabs__item[data-cev-tab]', function( e ) {
				// Let open-in-new-tab / modifier clicks behave like normal links.
				if ( e.ctrlKey || e.metaKey || e.shiftKey ) {
					return;
				}
				e.preventDefault();

				const tab  = jQuery( this ).attr( 'data-cev-tab' );
				const href = jQuery( this ).attr( 'href' );
				self.activate( tab );

				if ( href && window.history && window.history.pushState ) {
					window.history.pushState( { cevTab: tab }, '', href );
				}
			} );

			// Browser back/forward — restore the tab encoded in the URL.
			window.addEventListener( 'popstate', function() {
				const params = new URLSearchParams( window.location.search );
				self.activate( params.get( 'tab' ) || 'email-verification' );
			} );
		},

		/**
		 * Show the panel for a tab + set the active tab state, then re-flow
		 * widgets that were initialised while their panel was hidden.
		 *
		 * @param {string} tab Tab slug (matches data-cev-tab / data-zui-tab).
		 */
		activate: function( tab ) {
			if ( ! tab ) {
				return;
			}

			jQuery( '.zui-tabs__item[data-cev-tab]' ).each( function() {
				const on = jQuery( this ).attr( 'data-cev-tab' ) === tab;
				jQuery( this ).toggleClass( 'is-active', on );
				if ( on ) {
					this.setAttribute( 'aria-current', 'page' );
				} else {
					this.removeAttribute( 'aria-current' );
				}
			} );

			jQuery( '.zui-tab-panel[data-zui-tab]' ).each( function() {
				this.hidden = this.getAttribute( 'data-zui-tab' ) !== tab;
			} );

			// Widgets drawn while hidden have zero dimensions — re-flow them
			// one tick after the panel becomes visible.
			window.setTimeout( function() {
				if ( 'unverified-users' === tab && jQuery.fn.dataTable && jQuery.fn.dataTable.isDataTable( '#userLogTable' ) ) {
					jQuery( '#userLogTable' ).DataTable().columns.adjust();
				}
				document.dispatchEvent( new CustomEvent( 'cev:top-tab', { detail: { tab: tab } } ) );
			}, 0 );
		},
	};

	/**
	 * Settings sidebar section persistence.
	 *
	 * The ZUI library switches sections client-side (data-zui-section) and
	 * fires a `zui:section` event but doesn't record the choice — so a full
	 * page reload snaps back to the first section. Mirror the active section
	 * into the URL (?section=) via replaceState so the server renders it
	 * active on the next load (admin_options_settings.php reads ?section=).
	 */
	const SectionPersistence = {
		init: function() {
			document.addEventListener( 'zui:section', function( e ) {
				const key = e && e.detail ? e.detail.section : '';
				if ( ! key || ! window.history || ! window.history.replaceState ) {
					return;
				}
				const url = new URL( window.location.href );
				url.searchParams.set( 'section', key );
				window.history.replaceState( null, '', url.toString() );
			} );
		},
	};

	/**
	 * ZUI multi-select widget (chips + dropdown) backed by a hidden native
	 * <select multiple> as the source of truth. Auto-inits every
	 * .zui-ms[data-zui-multiselect]. Save is unchanged — the native select is
	 * read by the per-section Save.
	 *
	 * FALLBACK ONLY. ZUI >= 1.9.x ships its own multiselect JS (ZUI.scan() →
	 * _initMultiselect) and marks each wired root with `_zuiMsBound`. Binding
	 * ours on top of the library's would attach a SECOND click handler to the
	 * control, so a click toggles `is-open` twice and the dropdown opens and
	 * instantly closes again — i.e. it never appears to open. We therefore
	 * honour (and set) the same `_zuiMsBound` flag: whichever runs first wins,
	 * and the library runs first because zui.js is a dependency of admin.js.
	 */
	const ZuiMultiselect = {
		init: function() {
			document.querySelectorAll( '.zui-ms[data-zui-multiselect]' ).forEach( function( root ) {
				ZuiMultiselect.setup( root );
			} );
		},

		setup: function( root ) {
			// Already wired by the ZUI library (or by a previous init pass) —
			// a second set of handlers would cancel out the open/close toggle.
			if ( root._zuiMsBound ) {
				return;
			}
			const select    = root.querySelector( 'select.zui-ms__native' );
			const control   = root.querySelector( '.zui-ms__control' );
			const chipsWrap = root.querySelector( '.zui-ms__chips' );
			const dropdown  = root.querySelector( '.zui-ms__dropdown' );
			if ( ! select || ! control || ! chipsWrap || ! dropdown ) {
				return;
			}
			root._zuiMsBound = true;
			const placeholder = root.getAttribute( 'data-placeholder' ) || 'Select…';

			function opts() {
				return Array.prototype.slice.call( select.options );
			}

			function commit() {
				// Native <select> is the source of truth; notify any listeners.
				select.dispatchEvent( new Event( 'change', { bubbles: true } ) );
				renderChips();
				renderDropdown();
			}

			function renderChips() {
				chipsWrap.innerHTML = '';
				const selected = opts().filter( function( o ) { return o.selected; } );
				if ( ! selected.length ) {
					const ph = document.createElement( 'span' );
					ph.className = 'zui-ms__placeholder';
					ph.textContent = placeholder;
					chipsWrap.appendChild( ph );
					return;
				}
				selected.forEach( function( o ) {
					const chip = document.createElement( 'span' );
					chip.className = 'zui-ms__chip';
					chip.setAttribute( 'data-value', o.value );
					const label = document.createElement( 'span' );
					label.className = 'zui-ms__chip-label';
					label.textContent = o.textContent;
					const remove = document.createElement( 'button' );
					remove.type = 'button';
					remove.className = 'zui-ms__chip-remove';
					remove.innerHTML = '&times;';
					remove.setAttribute( 'aria-label', 'Remove ' + o.textContent );
					remove.addEventListener( 'click', function( e ) {
						e.stopPropagation();
						o.selected = false;
						commit();
					} );
					chip.appendChild( label );
					chip.appendChild( remove );
					chipsWrap.appendChild( chip );
				} );
			}

			function renderDropdown() {
				dropdown.innerHTML = '';
				opts().forEach( function( o ) {
					const item = document.createElement( 'div' );
					item.className = 'zui-ms__option' + ( o.selected ? ' is-selected' : '' );
					item.setAttribute( 'role', 'option' );
					item.setAttribute( 'aria-selected', o.selected ? 'true' : 'false' );
					const lbl = document.createElement( 'span' );
					lbl.textContent = o.textContent;
					item.appendChild( lbl );
					if ( o.selected ) {
						const ck = document.createElement( 'span' );
						ck.className = 'zui-ms__check';
						ck.innerHTML = '&#10003;';
						item.appendChild( ck );
					}
					item.addEventListener( 'click', function() {
						o.selected = ! o.selected;
						commit();
					} );
					dropdown.appendChild( item );
				} );
			}

			function openDd() {
				root.classList.add( 'is-open' );
				control.setAttribute( 'aria-expanded', 'true' );
				dropdown.removeAttribute( 'hidden' );
			}
			function closeDd() {
				root.classList.remove( 'is-open' );
				control.setAttribute( 'aria-expanded', 'false' );
				dropdown.setAttribute( 'hidden', 'hidden' );
			}

			control.addEventListener( 'click', function() {
				if ( root.classList.contains( 'is-open' ) ) { closeDd(); } else { openDd(); }
			} );
			control.addEventListener( 'keydown', function( e ) {
				if ( 'Enter' === e.key || ' ' === e.key ) {
					e.preventDefault();
					if ( root.classList.contains( 'is-open' ) ) { closeDd(); } else { openDd(); }
				} else if ( 'Escape' === e.key ) {
					closeDd();
				}
			} );
			document.addEventListener( 'click', function( e ) {
				if ( ! root.contains( e.target ) ) { closeDd(); }
			} );

			renderChips();
			renderDropdown();
		},
	};

	/**
	 * Segmented control (form-type pills) — clicking a pill sets it active
	 * (mutual exclusion) and writes its value into the paired hidden input
	 * (named like the field) so the section Save persists it. The visual now
	 * comes from the ZUI library (.zui-segmented); the data-cev-segmented
	 * attribute is the field-id ↔ hidden-input bridge.
	 */
	const SegmentedControl = {
		init: function() {
			document.addEventListener( 'click', function( e ) {
				const btn = e.target.closest ? e.target.closest( '[data-cev-segmented] .zui-segmented__item' ) : null;
				if ( ! btn ) {
					return;
				}
				const wrap = btn.closest( '[data-cev-segmented]' );
				if ( ! wrap ) {
					return;
				}
				wrap.querySelectorAll( '.zui-segmented__item' ).forEach( function( b ) {
					const on = b === btn;
					b.classList.toggle( 'is-active', on );
					b.setAttribute( 'aria-selected', on ? 'true' : 'false' );
				} );
				const input = document.getElementById( wrap.getAttribute( 'data-cev-segmented' ) );
				if ( input ) {
					input.value = btn.getAttribute( 'data-value' );
					input.dispatchEvent( new Event( 'change', { bubbles: true } ) );
				}
			} );
		},
	};

	/**
	 * Date picker (analytics range picker) — owns the JS half of the ZUI
	 * .zui-datepicker / .zui-calendar components. The library ships only
	 * the CSS visual; consumers own popover toggle, month rendering, and
	 * day selection. We persist the ISO value (YYYY-MM-DD) into the hidden
	 * input the analytics AJAX reads ([data-cev-from] / [data-cev-to]) and
	 * mirror a friendly label ("Jun 24, 2026") into the visible <input>.
	 */
	const DatePicker = {
		_dpI18n: function() {
			return ( typeof window.cev_admin_i18n !== 'undefined' ) ? window.cev_admin_i18n : {};
		},
		_months: function() {
			const i = this._dpI18n();
			return ( Array.isArray( i.cal_months ) && 12 === i.cal_months.length ) ? i.cal_months : [
				'January','February','March','April','May','June',
				'July','August','September','October','November','December'
			];
		},
		_monthsShort: function() {
			const i = this._dpI18n();
			return ( Array.isArray( i.cal_months_short ) && 12 === i.cal_months_short.length ) ? i.cal_months_short : [
				'Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'
			];
		},
		_dow: function() {
			const i = this._dpI18n();
			return ( Array.isArray( i.cal_dow ) && 7 === i.cal_dow.length ) ? i.cal_dow : [
				'Mo','Tu','We','Th','Fr','Sa','Su'
			];
		},
		_pad: function( n ) { return n < 10 ? '0' + n : String( n ); },
		_parseISO: function( iso ) {
			const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec( iso || '' );
			if ( ! m ) { return null; }
			return new Date( parseInt( m[ 1 ], 10 ), parseInt( m[ 2 ], 10 ) - 1, parseInt( m[ 3 ], 10 ) );
		},
		_formatDisplay: function( y, m, d ) {
			return this._monthsShort()[ m - 1 ] + ' ' + d + ', ' + y;
		},

		init: function() {
			const self = this;
			document.addEventListener( 'click', function( e ) {
				// Outside any datepicker → close all open ones.
				if ( ! e.target.closest( '[data-cev-datepicker]' ) ) {
					self.closeAll();
					return;
				}
				// Click in the input row → toggle that picker.
				const inputRow = e.target.closest( '.zui-datepicker__input' );
				if ( inputRow ) {
					const picker = inputRow.parentElement;
					if ( ! picker || ! picker.matches( '[data-cev-datepicker]' ) ) { return; }
					if ( picker.classList.contains( 'is-open' ) ) {
						self.close( picker );
					} else {
						self.closeAll();
						self.open( picker );
					}
					return;
				}
				// Prev / next month nav.
				const nav = e.target.closest( '.zui-calendar__nav' );
				if ( nav ) {
					e.preventDefault();
					const picker2 = nav.closest( '[data-cev-datepicker]' );
					if ( ! picker2 ) { return; }
					self.shiftMonth( picker2, nav.classList.contains( 'zui-calendar__nav--prev' ) ? -1 : 1 );
					return;
				}
				// Day cell click (skip muted adjacent-month cells).
				const day = e.target.closest( '.zui-calendar__day' );
				if ( day && ! day.classList.contains( 'zui-calendar__day--muted' ) ) {
					const picker3 = day.closest( '[data-cev-datepicker]' );
					if ( ! picker3 ) { return; }
					self.selectDay( picker3, day );
				}
			} );
			document.addEventListener( 'keydown', function( e ) {
				if ( 'Escape' === e.key ) { self.closeAll(); }
			} );
		},
		closeAll: function() {
			const self = this;
			document.querySelectorAll( '[data-cev-datepicker].is-open' ).forEach( function( p ) {
				self.close( p );
			} );
		},
		close: function( picker ) {
			picker.classList.remove( 'is-open' );
			// Library contract: the .zui-calendar popover is positioned
			// absolute but has no display:none rule keyed off .is-open —
			// it stays visible until removed from the DOM (or `hidden`).
			// We rebuild it on every open, so removing here is safe.
			const cal = picker.querySelector( '.zui-calendar' );
			if ( cal ) { cal.remove(); }
		},
		open: function( picker ) {
			const hidden = picker.querySelector( 'input[type="hidden"]' );
			const iso = hidden && hidden.value ? hidden.value : '';
			let d = iso ? this._parseISO( iso ) : null;
			if ( ! d ) { d = new Date(); }
			picker.dataset.cevMonth = d.getFullYear() + '-' + ( d.getMonth() + 1 );
			this.renderCalendar( picker );
			picker.classList.add( 'is-open' );
		},
		shiftMonth: function( picker, delta ) {
			const parts = ( picker.dataset.cevMonth || '' ).split( '-' );
			let y = parseInt( parts[ 0 ], 10 );
			let m = parseInt( parts[ 1 ], 10 );
			if ( ! y || ! m ) {
				const now = new Date();
				y = now.getFullYear();
				m = now.getMonth() + 1;
			}
			m += delta;
			if ( m < 1 )       { m = 12; y--; }
			else if ( m > 12 ) { m = 1;  y++; }
			picker.dataset.cevMonth = y + '-' + m;
			this.renderCalendar( picker );
		},
		selectDay: function( picker, dayEl ) {
			const parts = ( picker.dataset.cevMonth || '' ).split( '-' );
			const y = parseInt( parts[ 0 ], 10 );
			const m = parseInt( parts[ 1 ], 10 );
			const d = parseInt( dayEl.textContent, 10 );
			if ( ! y || ! m || ! d ) { return; }
			const iso = y + '-' + this._pad( m ) + '-' + this._pad( d );
			const hidden  = picker.querySelector( 'input[type="hidden"]' );
			const display = picker.querySelector( '.zui-input' );
			if ( hidden ) {
				hidden.value = iso;
				hidden.dispatchEvent( new Event( 'change', { bubbles: true } ) );
			}
			if ( display ) {
				display.value = this._formatDisplay( y, m, d );
			}
			this.close( picker );
		},
		renderCalendar: function( picker ) {
			const existing = picker.querySelector( '.zui-calendar' );
			if ( existing ) { existing.remove(); }
			const parts = ( picker.dataset.cevMonth || '' ).split( '-' );
			let y = parseInt( parts[ 0 ], 10 );
			let m = parseInt( parts[ 1 ], 10 );
			if ( ! y || ! m ) {
				const now = new Date();
				y = now.getFullYear();
				m = now.getMonth() + 1;
			}
			const hidden = picker.querySelector( 'input[type="hidden"]' );
			const selectedIso = hidden && hidden.value ? hidden.value : '';
			const today  = new Date();
			const todayY = today.getFullYear();
			const todayM = today.getMonth() + 1;
			const todayD = today.getDate();
			const firstDay = new Date( y, m - 1, 1 );
			// Monday=0 .. Sunday=6 (we display Mo–Su).
			const lead = ( firstDay.getDay() + 6 ) % 7;
			const daysInMonth   = new Date( y, m,     0 ).getDate();
			const prevMonthDays = new Date( y, m - 1, 0 ).getDate();
			const totalCells = Math.ceil( ( lead + daysInMonth ) / 7 ) * 7;

			const i18n = this._dpI18n();
			const prevLbl = i18n.dp_prev_month || 'Previous month';
			const nextLbl = i18n.dp_next_month || 'Next month';
			const monthsLong = this._months();
			const dow = this._dow();

			let html = '<div class="zui-calendar zui-calendar--popover">';
			html += '<div class="zui-calendar__head">';
			html += '<button type="button" class="zui-calendar__nav zui-calendar__nav--prev" aria-label="' + prevLbl + '"><svg class="zui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m15 18-6-6 6-6"/></svg></button>';
			html += '<div class="zui-calendar__title">' + monthsLong[ m - 1 ] + ' ' + y + '</div>';
			html += '<button type="button" class="zui-calendar__nav zui-calendar__nav--next" aria-label="' + nextLbl + '"><svg class="zui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg></button>';
			html += '</div>';
			html += '<div class="zui-calendar__grid">';
			for ( let i = 0; i < 7; i++ ) {
				html += '<span class="zui-calendar__dow">' + dow[ i ] + '</span>';
			}
			for ( let i = 0; i < totalCells; i++ ) {
				let cellDay, isMuted, cellY, cellM;
				if ( i < lead ) {
					cellDay = prevMonthDays - lead + 1 + i;
					isMuted = true;
					cellY = 1 === m ? y - 1 : y;
					cellM = 1 === m ? 12 : m - 1;
				} else if ( i < lead + daysInMonth ) {
					cellDay = i - lead + 1;
					isMuted = false;
					cellY = y;
					cellM = m;
				} else {
					cellDay = i - lead - daysInMonth + 1;
					isMuted = true;
					cellY = 12 === m ? y + 1 : y;
					cellM = 12 === m ? 1 : m + 1;
				}
				let classes = 'zui-calendar__day';
				if ( isMuted ) { classes += ' zui-calendar__day--muted'; }
				if ( ! isMuted && cellY === todayY && cellM === todayM && cellDay === todayD ) {
					classes += ' zui-calendar__day--today';
				}
				if ( ! isMuted && selectedIso === cellY + '-' + this._pad( cellM ) + '-' + this._pad( cellDay ) ) {
					classes += ' is-selected';
				}
				html += '<button type="button" class="' + classes + '">' + cellDay + '</button>';
			}
			html += '</div></div>';
			picker.insertAdjacentHTML( 'beforeend', html );
		},
	};

	/**
	 * Smart Form UI — show the Template picker row only when the Signup form
	 * type is "Smart Form". The form-type segmented control dispatches a
	 * `change` on its hidden #cev_signup_form_type input (see SegmentedControl);
	 * we mirror the picker's visibility off that. The initial state is also set
	 * server-side via the field's `initially_visible` flag.
	 */
	const SmartFormUI = {
		init: function() {
			const groupValue = function( group ) {
				const input = document.getElementById( group );
				return input ? input.value : '';
			};
			// A group is multi-select when its hidden input carries the
			// data-cev-toggle-multi flag (set by field-toggle-select.php).
			const groupIsMulti = function( group ) {
				const input = document.getElementById( group );
				return !! ( input && input.hasAttribute( 'data-cev-toggle-multi' ) );
			};
			// Enabled values of a (single or multi) group as an array.
			const groupValues = function( group ) {
				return groupValue( group ).split( ',' ).map( function( v ) {
					return v.trim();
				} ).filter( function( v ) {
					return '' !== v;
				} );
			};
			const groupHas = function( group, value ) {
				return groupValues( group ).indexOf( value ) > -1;
			};
			// Multi-select: store a comma-separated list and reflect each toggle.
			const setGroupMulti = function( group, values ) {
				const input = document.getElementById( group );
				if ( ! input ) {
					return;
				}
				input.value = values.join( ',' );
				const wrap = document.querySelector( '[data-cev-toggle-group="' + group + '"]' );
				if ( wrap ) {
					wrap.querySelectorAll( '.cev-method-toggle' ).forEach( function( t ) {
						t.checked = ( values.indexOf( t.getAttribute( 'data-cev-value' ) ) > -1 );
					} );
				}
				input.dispatchEvent( new Event( 'change', { bubbles: true } ) );
			};
			// Remove a value from a multi group (used when a conditional makes an
			// option invalid, e.g. Phone OTP after switching to Email reg). Never
			// leaves the group empty — falls back to Password.
			const removeFromGroup = function( group, value ) {
				if ( ! groupIsMulti( group ) || ! groupHas( group, value ) ) {
					return;
				}
				const next = groupValues( group ).filter( function( v ) {
					return v !== value;
				} );
				setGroupMulti( group, next.length ? next : [ 'password' ] );
			};
			const setGroup = function( group, value ) {
				const input = document.getElementById( group );
				if ( ! input ) {
					return;
				}
				input.value = value;
				const wrap = document.querySelector( '[data-cev-toggle-group="' + group + '"]' );
				if ( wrap ) {
					wrap.querySelectorAll( '.cev-method-toggle' ).forEach( function( t ) {
						t.checked = ( t.getAttribute( 'data-cev-value' ) === value );
					} );
				}
				input.dispatchEvent( new Event( 'change', { bubbles: true } ) );
			};
			const sync = function() {
				const formType = document.getElementById( 'cev_signup_form_type' );
				const smart = ( formType && 'smart' === formType.value );
				// Show/hide every Smart-Form-only row together.
				document.querySelectorAll( '.cev-smart-only' ).forEach( function( row ) {
					row.style.display = smart ? '' : 'none';
				} );
				const reg = groupValue( 'cev_smart_reg_method' );
				// Login method is multi-select — test membership, not equality.
				const loginHasPhoneOtp = groupHas( 'cev_smart_login_method', 'phone_otp' );
				// Phone OTP login option only appears when reg method is phone.
				const phoneOtp = document.querySelector( '[data-cev-toggle-group="cev_smart_login_method"] [data-cev-phone-only="1"]' );
				if ( phoneOtp ) {
					phoneOtp.style.display = ( 'phone' === reg ) ? '' : 'none';
				}
				// SMS gateway row needs Smart Form AND phone involvement.
				const smsRow = document.querySelector( '.cev-sms-row' );
				if ( smsRow ) {
					smsRow.style.display = ( smart && ( 'phone' === reg || loginHasPhoneOtp ) ) ? '' : 'none';
				}
				// Phone-number field options apply only to EMAIL registration —
				// phone (SMS) registration forces the field on + required, so the
				// toggles are hidden then. The "required" toggle only shows once
				// the field itself is enabled.
				const isEmailReg = ( 'email' === reg );
				const showPhone = document.getElementById( 'cev_smart_show_phone_field' );
				const showPhoneOn = !! ( showPhone && showPhone.checked );
				document.querySelectorAll( '.cev-phone-opt' ).forEach( function( row ) {
					row.style.display = ( smart && isEmailReg ) ? '' : 'none';
				} );
				document.querySelectorAll( '.cev-phone-required-opt' ).forEach( function( row ) {
					row.style.display = ( smart && isEmailReg && showPhoneOn ) ? '' : 'none';
				} );
			};

			// Single-select method toggles (radio semantics). Clicking the
			// label flips the native checkbox and fires 'change' on the input
			// (.cev-method-toggle); we then force exactly one ON per group.
			document.addEventListener( 'change', function( e ) {
				const toggle = e.target;
				if ( ! toggle || ! toggle.classList || ! toggle.classList.contains( 'cev-method-toggle' ) ) {
					return;
				}
				const wrap = toggle.closest( '[data-cev-toggle-group]' );
				if ( ! wrap ) {
					return;
				}
				const group = wrap.getAttribute( 'data-cev-toggle-group' );
				const value = toggle.getAttribute( 'data-cev-value' );
				if ( groupIsMulti( group ) ) {
					// Multi-select: add/remove this value. Never allow the last
					// enabled method to be turned off (would lock everyone out).
					const current = groupValues( group );
					if ( toggle.checked ) {
						if ( current.indexOf( value ) === -1 ) {
							current.push( value );
						}
					} else if ( current.length <= 1 ) {
						// Block turning off the only remaining method.
						toggle.checked = true;
						return;
					} else {
						const idx = current.indexOf( value );
						if ( idx > -1 ) {
							current.splice( idx, 1 );
						}
					}
					setGroupMulti( group, current );
					sync();
					return;
				}

				// Single-select (radio semantics): force exactly one ON.
				// Choosing Email registration drops a Phone-OTP login choice.
				if ( 'cev_smart_reg_method' === group && 'email' === value ) {
					removeFromGroup( 'cev_smart_login_method', 'phone_otp' );
				}
				setGroup( group, value );
				sync();
			} );

			// Re-sync / drive the SMS conditionals on the relevant changes.
			document.addEventListener( 'change', function( e ) {
				if ( ! e.target ) {
					return;
				}
				if ( 'cev_signup_form_type' === e.target.id || 'cev_smart_show_phone_field' === e.target.id ) {
					sync();
				} else if ( e.target.matches && e.target.matches( '[data-cev-sms-provider]' ) ) {
					const val = e.target.value;
					document.querySelectorAll( '[data-cev-provider]' ).forEach( function( block ) {
						block.style.display = ( block.getAttribute( 'data-cev-provider' ) === val ) ? '' : 'none';
					} );
				} else if ( e.target.matches && e.target.matches( '[data-cev-sms-sendvia]' ) ) {
					const val = e.target.value;
					document.querySelectorAll( '[data-cev-sms-sendvia-field]' ).forEach( function( f ) {
						f.style.display = ( f.getAttribute( 'data-cev-sms-sendvia-field' ) === val ) ? '' : 'none';
					} );
				} else if ( e.target.matches && e.target.matches( '[data-cev-sms-cond-toggle]' ) ) {
					const key = e.target.getAttribute( 'data-cev-sms-cond-toggle' );
					const target = document.querySelector( '[data-cev-sms-cond="' + key + '"]' );
					if ( target ) {
						target.style.display = e.target.checked ? '' : 'none';
					}
				}
			} );

			// Copy the Placement shortcode to the clipboard (flashes "Copied!").
			document.addEventListener( 'click', function( e ) {
				const btn = e.target.closest ? e.target.closest( '.cev-shortcode-copy' ) : null;
				if ( ! btn ) {
					return;
				}
				const text = btn.getAttribute( 'data-cev-copy' ) || '';
				const orig = btn.getAttribute( 'data-cev-orig' ) || btn.textContent;
				btn.setAttribute( 'data-cev-orig', orig );
				const flash = function() {
					btn.classList.add( 'is-copied' );
					btn.textContent = btn.getAttribute( 'data-cev-copied' ) || orig;
					window.setTimeout( function() {
						btn.classList.remove( 'is-copied' );
						btn.textContent = orig;
					}, 1500 );
				};
				if ( navigator.clipboard && navigator.clipboard.writeText ) {
					navigator.clipboard.writeText( text ).then( flash, flash );
				} else {
					flash();
				}
			} );

			// Send-test-SMS button (SMS Gateway section).
			document.addEventListener( 'click', function( e ) {
				const testBtn = e.target.closest ? e.target.closest( '[data-cev-sms-test]' ) : null;
				if ( ! testBtn ) {
					return;
				}
				e.preventDefault();
				const wrap = testBtn.closest( '.cev-sms__test' );
				const phoneEl = wrap ? wrap.querySelector( '#cev_sms_test_phone' ) : null;
				const result = wrap ? wrap.querySelector( '.cev-sms__test-result' ) : null;
				const phone = phoneEl ? phoneEl.value.trim() : '';
				if ( result ) {
					result.textContent = '';
				}
				if ( ! phone ) {
					if ( result ) {
						result.textContent = i18n( 'sms_test_phone', 'Please enter a phone number to test.' );
						result.style.color = '#e11d48';
					}
					return;
				}
				const origText = testBtn.textContent;
				testBtn.disabled = true;
				testBtn.textContent = i18n( 'sms_testing', 'Sending…' );
				jQuery.post( window.ajaxurl, {
					action: 'cev_sms_test_send',
					nonce: testBtn.getAttribute( 'data-cev-nonce' ) || '',
					phone: phone
				} ).done( function( res ) {
					const ok = !! ( res && res.success );
					if ( result ) {
						result.textContent = ( res && res.data && res.data.message ) ? res.data.message : '';
						result.style.color = ok ? '#16a34a' : '#e11d48';
					}
				} ).fail( function() {
					if ( result ) {
						result.textContent = i18n( 'sms_test_failed', 'Could not send the test. Please try again.' );
						result.style.color = '#e11d48';
					}
				} ).always( function() {
					testBtn.disabled = false;
					testBtn.textContent = origText;
				} );
			} );

			sync();
		},
	};

	/**
	 * Main initialization
	 */
	jQuery( document ).ready( function() {
		// Each module is initialised in isolation. A failure in one (a missing
		// vendor library, a markup change) must never stop the ones after it:
		// a DataTables 404 inside UserLogTable.init() used to take out every
		// later handler, which is why the settings segmented controls, Smart
		// Form UI and date picker silently stopped responding to clicks.
		const cevModules = [
			[ 'SettingsForm', SettingsForm ],
			[ 'FieldManager', FieldManager ],
			[ 'UserLogTable', UserLogTable ],
			[ 'ActivityPanel', ActivityPanel ],
			[ 'PopupMenu', PopupMenu ],
			[ 'MiscHandlers', MiscHandlers ],
			[ 'TopTabs', TopTabs ],
			[ 'SectionPersistence', SectionPersistence ],
			[ 'ZuiMultiselect', ZuiMultiselect ],
			[ 'SegmentedControl', SegmentedControl ],
			[ 'DatePicker', DatePicker ],
			[ 'SmartFormUI', SmartFormUI ]
		];

		cevModules.forEach( function( entry ) {
			try {
				entry[ 1 ].init();
			} catch ( err ) {
				if ( window.console && window.console.error ) {
					window.console.error( '[CEV] ' + entry[ 0 ] + '.init() failed:', err );
				}
			}
		} );

		// Pre-warm hack — fire a silent no-op AJAX 500ms after page load so
		// PHP-FPM / opcache are hot by the time the user hits Save. Without
		// this, the first save after a hard reload can hit a cold worker
		// that exceeds the host/Cloudflare upstream timeout → 504. Failures
		// (including 504s) are intentionally swallowed — the goal is just
		// to spend the cold cost off the user's interaction path.
		setTimeout( function() {
			const ajaxEndpoint = ( typeof cev_vars !== 'undefined' && cev_vars.ajax_url )
				? cev_vars.ajax_url
				: ( typeof ajaxurl !== 'undefined' ? ajaxurl : '/wp-admin/admin-ajax.php' );
			try {
				jQuery.ajax( {
					url: ajaxEndpoint,
					type: 'POST',
					data: { action: 'cev_admin_warmup' },
					timeout: 90000,
					global: false
				} ).fail( function() { /* expected on cold-stack 504; ignore. */ } );
			} catch ( e ) { /* ignore */ }
		}, 500 );
	} );
})( jQuery );

/* Setup checklist (Settings tab): send a test email and hide the card.
   Text comes from the server response or the localized
   cev_setup_checklist.i18n object. */
jQuery( function ( $ ) {
	if ( 'undefined' === typeof cev_setup_checklist ) {
		return;
	}

	function messageFrom( response ) {
		return ( response && response.data && response.data.message ) ? response.data.message : cev_setup_checklist.i18n.request_failed;
	}

	$( document ).on( 'click', '.cev-send-test-email', function () {
		var $btn  = $( this );
		var label = $btn.text();
		$btn.prop( 'disabled', true ).text( cev_setup_checklist.i18n.sending );
		$.post( cev_setup_checklist.ajax_url, {
			action: 'cev_send_test_email',
			nonce: cev_setup_checklist.nonce
		} ).done( function ( response ) {
			if ( response && response.success ) {
				$btn.zorem_snackbar( messageFrom( response ) );
				$btn.replaceWith( $( '<span class="zui-row__desc"></span>' ).text( messageFrom( response ) ) );
			} else {
				$btn.zorem_snackbar_warning( messageFrom( response ) );
				$btn.prop( 'disabled', false ).text( label );
			}
		} ).fail( function ( xhr ) {
			$btn.zorem_snackbar_warning( messageFrom( xhr.responseJSON ) );
			$btn.prop( 'disabled', false ).text( label );
		} );
	} );

	$( document ).on( 'click', '.cev-dismiss-checklist', function () {
		$( '#cev-setup-checklist' ).remove();
		$.post( cev_setup_checklist.ajax_url, {
			action: 'cev_dismiss_checklist',
			nonce: cev_setup_checklist.nonce
		} );
	} );
} );
