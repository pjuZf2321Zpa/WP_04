/**
 * Analytics dashboard front-end.
 *
 * Fetches aggregated data from the cev_analytics_data AJAX endpoint and
 * renders:
 *   - KPI cards with trend indicators
 *   - Time-series chart (via CevChart)
 *   - Funnel widget
 *   - Top-10 blocked domains list
 *   - Date range picker (controls the fetch)
 *
 * @package Customer_Email_Verification_Pro
 * @since   2.10.0
 */
( function ( $ ) {
	'use strict';

	if ( typeof window.CEV_ANALYTICS === 'undefined' ) {
		return;
	}
	var cfg = window.CEV_ANALYTICS;

	$( function () {
		var $root = $( '[data-cev-analytics]' ).first();
		if ( ! $root.length ) { return; }

		var state = {
			range:      $root.attr( 'data-initial-range' ) || '30d',
			from:       $root.attr( 'data-initial-from' )  || '',
			to:         $root.attr( 'data-initial-to' )    || '',
			chart:      null,
			lastSeries: null
		};

		// Initial sync of custom-range visibility.
		toggleCustomRangeVisibility( $root, state.range );

		// Bind range dropdown.
		$root.on( 'change', '[data-cev-range]', function () {
			state.range = $( this ).val();
			toggleCustomRangeVisibility( $root, state.range );
			if ( 'custom' !== state.range ) {
				fetchAndRender( $root, state );
			}
		} );

		// Bind custom-range apply.
		$root.on( 'click', '[data-cev-apply-range]', function () {
			state.from = $root.find( '[data-cev-from]' ).val() || '';
			state.to   = $root.find( '[data-cev-to]' ).val()   || '';
			if ( ! state.from || ! state.to ) {
				return;
			}
			fetchAndRender( $root, state );
		} );

		// Re-render the chart when the user switches back to the Analytics
		// top tab. Panels are shown/hidden in-page (admin.js → TopTabs); a
		// canvas drawn while its panel was hidden has zero dimensions, so
		// redraw with the cached series once the panel is visible.
		document.addEventListener( 'cev:top-tab', function ( ev ) {
			if ( ! ev.detail || 'analytics' !== ev.detail.tab ) { return; }
			if ( ! state.lastSeries ) { return; }
			// Defer one tick so the panel is visible and the canvas has its
			// real dimensions before we draw.
			setTimeout( function () {
				renderChart( $root, state, state.lastSeries );
			}, 0 );
		} );

		// Initial fetch.
		fetchAndRender( $root, state );
	} );

	function toggleCustomRangeVisibility( $root, range ) {
		var $custom = $root.find( '[data-cev-custom-range]' );
		if ( 'custom' === range ) {
			$custom.removeAttr( 'hidden' );
		} else {
			$custom.attr( 'hidden', 'hidden' );
		}
	}

	function fetchAndRender( $root, state ) {
		var $skeleton = $root.find( '[data-cev-skeleton]' );
		var $loading  = $root.find( '[data-cev-loading]' );
		var $content  = $root.find( '[data-cev-content]' );
		var $empty    = $root.find( '[data-cev-empty]' );

		// Show the skeleton on EVERY fetch (initial load + range changes
		// + custom-range Apply). Hide the real content + empty state so
		// the skeleton is the only thing visible until the response lands.
		// The inline `[data-cev-loading]` spinner is kept hidden — the
		// skeleton replaces it as the loading affordance.
		$skeleton.removeAttr( 'hidden' );
		$loading.attr( 'hidden', 'hidden' );
		$content.attr( 'hidden', 'hidden' );
		$content.css( 'opacity', '1' );
		$empty.attr( 'hidden', 'hidden' );

		// Destroy the previous chart (if any) so its hover/canvas state
		// doesn't bleed across range changes while the skeleton is up.
		if ( state.chart && state.chart.destroy ) {
			state.chart.destroy();
			state.chart = null;
		}

		$.post( cfg.ajax_url, {
			action: 'cev_analytics_data',
			nonce:  cfg.nonce,
			range:  state.range,
			from:   state.from,
			to:     state.to
		} )
			.done( function ( res ) {
				$skeleton.attr( 'hidden', 'hidden' );

				if ( ! res || ! res.success || ! res.data ) {
					$content.attr( 'hidden', 'hidden' );
					$empty.removeAttr( 'hidden' );
					return;
				}

				var data = res.data;
				renderRangeLabel( $root, data.range_label );

				if ( ! data.has_data ) {
					$content.attr( 'hidden', 'hidden' );
					$empty.removeAttr( 'hidden' );
					return;
				}
				$content.removeAttr( 'hidden' );

				// Cache the series so the tab-switch handler can redraw
				// the chart if the canvas pixels get cleared by a
				// display:none/block cycle.
				state.lastSeries = data.series;

				renderKpis( $root, data.kpis, data.kpis_prev );
				renderChart( $root, state, data.series );
				renderFunnel( $root, data.funnel );
				renderVerificationStatus( $root, data.verification_status );
				renderTopDomains( $root, data.top_domains );
				renderAiRisk( $root, data.ai_risk );
			} )
			.fail( function () {
				$skeleton.attr( 'hidden', 'hidden' );
				$content.attr( 'hidden', 'hidden' );
				$empty.removeAttr( 'hidden' );
			} );
	}

	function renderRangeLabel( $root, label ) {
		$root.find( '[data-cev-range-label]' ).text( label || '—' );
	}

	function renderKpis( $root, k, prev ) {
		// All four KPI cards show a single number for visual consistency.
		// The verification rate (verified / signups) was previously shown
		// inline as "2 • 100%" which read like a decimal — moved out to
		// the Verification Status widget where it has its own bar.
		setKpi( $root, 'signups',  String( k.signups || 0 ) );
		setKpi( $root, 'verified', String( k.verified || 0 ) );
		setKpi( $root, 'blocked',  String( k.blocked || 0 ) );
		setKpi( $root, 'avg',      formatDuration( k.avg_seconds ) );

		setTrend( $root, 'signups',  diffPct( k.signups,  prev.signups ),  false );
		setTrend( $root, 'verified', diffPct( k.verified, prev.verified ), false );
		setTrend( $root, 'blocked',  diffPct( k.blocked,  prev.blocked ),  false );
		setTrend( $root, 'avg',      diffDuration( k.avg_seconds, prev.avg_seconds ), true );
	}

	function setKpi( $root, key, value ) {
		$root.find( '[data-cev-kpi="' + key + '"]' ).text( value );
	}

	/**
	 * Update a KPI's trend indicator.
	 *
	 * @param {jQuery} $root
	 * @param {string} key
	 * @param {Object} diff           { delta, label }
	 * @param {boolean} invertColors  When true (e.g. avg time), down = good.
	 */
	function setTrend( $root, key, diff, invertColors ) {
		var $el = $root.find( '[data-cev-trend="' + key + '"]' );
		if ( ! diff ) { $el.text( '' ); return; }
		var arrow = diff.delta > 0 ? '▲' : ( diff.delta < 0 ? '▼' : '' );
		var goodDelta = invertColors ? ( diff.delta < 0 ) : ( diff.delta > 0 );
		var badDelta  = invertColors ? ( diff.delta > 0 ) : ( diff.delta < 0 );
		$el.text( arrow + ' ' + diff.label + ' vs previous period' );
		// .zui-stat__delta is green by default; the --down modifier turns it red.
		$el.removeClass( 'zui-stat__delta--down' );
		if ( badDelta ) { $el.addClass( 'zui-stat__delta--down' ); }
	}

	function diffPct( cur, prev ) {
		cur = parseInt( cur, 10 ) || 0;
		prev = parseInt( prev, 10 ) || 0;
		if ( 0 === prev && 0 === cur ) { return null; }
		if ( 0 === prev ) { return { delta: cur, label: 'first time tracked' }; }
		var pct = ( ( cur - prev ) / prev ) * 100;
		var sign = pct >= 0 ? '+' : '';
		return { delta: pct, label: sign + pct.toFixed( 1 ) + '%' };
	}

	function diffDuration( cur, prev ) {
		cur = parseInt( cur, 10 ) || 0;
		prev = parseInt( prev, 10 ) || 0;
		if ( 0 === prev && 0 === cur ) { return null; }
		if ( 0 === prev || 0 === cur ) { return null; }
		var diff = cur - prev;
		var sign = diff >= 0 ? '+' : '−';
		return { delta: diff, label: sign + formatDuration( Math.abs( diff ) ) };
	}

	function formatDuration( seconds ) {
		seconds = parseInt( seconds, 10 ) || 0;
		if ( seconds <= 0 ) { return '—'; }
		if ( seconds < 60 ) { return seconds + ' s'; }
		var m = Math.floor( seconds / 60 );
		var s = seconds % 60;
		if ( m < 60 ) { return m + ' m ' + ( s ? s + ' s' : '' ).trim(); }
		var h = Math.floor( m / 60 );
		m = m % 60;
		return h + ' h ' + ( m ? m + ' m' : '' ).trim();
	}

	function renderChart( $root, state, series ) {
		var $canvas = $root.find( '[data-cev-chart]' );
		if ( ! $canvas.length ) { return; }

		// Tear down previous chart (e.g. when switching ranges).
		if ( state.chart && state.chart.destroy ) {
			state.chart.destroy();
		}
		if ( typeof window.CevChart === 'undefined' ) { return; }

		state.chart = new window.CevChart( $canvas.get( 0 ), {
			labels: series.dates || [],
			series: [
				{ label: 'Signups',  data: series.signups  || [], color: '#4338ca' },
				{ label: 'Verified', data: series.verified || [], color: '#047857' },
				{ label: 'Blocked',  data: series.blocked  || [], color: '#b91c1c' }
			]
		} );
	}

	function renderFunnel( $root, funnel ) {
		var $list = $root.find( '[data-cev-funnel]' );
		$list.empty();
		if ( ! funnel || ! funnel.length ) { return; }

		var max = funnel[ 0 ].count || 1;
		var prevCount = funnel[ 0 ].count || 0;

		funnel.forEach( function ( step, idx ) {
			var pct = ( max > 0 ) ? Math.round( ( step.count / max ) * 100 ) : 0;
			var drop = '';
			if ( idx > 0 && prevCount > 0 ) {
				var dropPct = 100 - Math.round( ( step.count / prevCount ) * 100 );
				if ( dropPct > 0 ) { drop = ' (−' + dropPct + '% drop-off)'; }
			}
			prevCount = step.count;

			var $row = $(
				'<div class="zui-meter">'
				+ '<div class="zui-meter__label"></div>'
				+ '<div class="zui-meter__track"><div class="zui-meter__bar"></div></div>'
				+ '<div class="zui-meter__value"></div>'
				+ '</div>'
			);
			$row.find( '.zui-meter__label' ).text( step.label );
			$row.find( '.zui-meter__value' ).text( String( step.count ) + ' (' + step.pct + '%)' + drop );
			$row.find( '.zui-meter__bar' ).css( 'width', pct + '%' );
			$list.append( $row );
		} );
	}

	function renderVerificationStatus( $root, status ) {
		var $list  = $root.find( '[data-cev-status]' );
		var $empty = $root.find( '[data-cev-status-empty]' );
		$list.empty();

		if ( ! status || ! status.total ) {
			$empty.removeAttr( 'hidden' );
			return;
		}
		$empty.attr( 'hidden', 'hidden' );

		var verified   = parseInt( status.verified,   10 ) || 0;
		var pending    = parseInt( status.pending_paid_order, 10 ) || 0;
		var unverified = parseInt( status.unverified, 10 ) || 0;
		var total      = verified + pending + unverified;
		var verifiedPct   = total > 0 ? Math.round( ( verified   / total ) * 100 ) : 0;
		var pendingPct    = total > 0 ? Math.round( ( pending    / total ) * 100 ) : 0;
		var unverifiedPct = total > 0 ? Math.round( ( unverified / total ) * 100 ) : 0;

		appendStatusRow( $list, 'good', 'Verified',   verified,   verifiedPct );
		// Paid-Order Gatekeeping bucket — only shown when it has users, so the
		// widget falls back to the original two-row display when the feature
		// is off (pending is always 0 then).
		if ( pending > 0 ) {
			appendStatusRow( $list, 'pending', 'Pending Order', pending, pendingPct );
		}
		appendStatusRow( $list, 'bad',  'Unverified', unverified, unverifiedPct );
	}

	function appendStatusRow( $list, tone, label, count, pct ) {
		var barMod = 'good' === tone ? ' zui-meter__bar--success'
			: ( 'pending' === tone ? ' zui-meter__bar--warning' : ' zui-meter__bar--muted' );
		var $row = $(
			'<div class="zui-meter">'
			+ '<div class="zui-meter__label"></div>'
			+ '<div class="zui-meter__track"><div class="zui-meter__bar' + barMod + '"></div></div>'
			+ '<div class="zui-meter__value"></div>'
			+ '</div>'
		);
		$row.find( '.zui-meter__label' ).text( label );
		$row.find( '.zui-meter__value' ).text( String( count ) + ' (' + pct + '%)' );
		$row.find( '.zui-meter__bar' ).css( 'width', pct + '%' );
		$list.append( $row );
	}

	function renderTopDomains( $root, top ) {
		var $list = $root.find( '[data-cev-top-domains]' );
		var $empty = $root.find( '[data-cev-top-empty]' );
		$list.empty();

		if ( ! top || ! top.length ) {
			$empty.removeAttr( 'hidden' );
			return;
		}
		$empty.attr( 'hidden', 'hidden' );

		top.forEach( function ( row, idx ) {
			var $row = $(
				'<div class="zui-ranklist__row">'
				+ '<span class="zui-ranklist__rank"></span>'
				+ '<span class="zui-ranklist__label"></span>'
				+ '<span class="zui-ranklist__value"></span>'
				+ '</div>'
			);
			$row.find( '.zui-ranklist__rank' ).text( '#' + ( idx + 1 ) );
			$row.find( '.zui-ranklist__label' ).text( row.domain );
			$row.find( '.zui-ranklist__value' ).text( String( row.count ) );
			$list.append( $row );
		} );
	}

	function renderAiRisk( $root, ai ) {
		var $card = $root.find( '[data-cev-ai-risk]' );
		if ( ! $card.length ) {
			return;
		}
		ai = ai || {};
		var scored  = parseInt( ai.scored, 10 ) || 0;
		var blocked = parseInt( ai.blocked, 10 ) || 0;

		// Only surface the card once the engine has actually scored something.
		if ( scored < 1 && blocked < 1 ) {
			$card.attr( 'hidden', 'hidden' );
			return;
		}
		$card.removeAttr( 'hidden' );

		$card.find( '[data-cev-ai-avg]' ).text( String( ai.avg_score != null ? ai.avg_score : 0 ) );
		$card.find( '[data-cev-ai-blocked]' ).text( String( blocked ) );
		$card.find( '[data-cev-ai-scored]' ).text( String( scored ) );

		var $list  = $card.find( '[data-cev-ai-reasons]' );
		var $empty = $card.find( '[data-cev-ai-reasons-empty]' );
		$list.empty();

		var reasons = ai.top_reasons || [];
		if ( ! reasons.length ) {
			$empty.removeAttr( 'hidden' );
			return;
		}
		$empty.attr( 'hidden', 'hidden' );

		reasons.forEach( function ( row, idx ) {
			var $row = $(
				'<div class="zui-ranklist__row">'
				+ '<span class="zui-ranklist__rank"></span>'
				+ '<span class="zui-ranklist__label"></span>'
				+ '<span class="zui-ranklist__value"></span>'
				+ '</div>'
			);
			$row.find( '.zui-ranklist__rank' ).text( '#' + ( idx + 1 ) );
			$row.find( '.zui-ranklist__label' ).text( row.label || row.key );
			$row.find( '.zui-ranklist__value' ).text( String( row.count ) );
			$list.append( $row );
		} );
	}

} )( jQuery );
