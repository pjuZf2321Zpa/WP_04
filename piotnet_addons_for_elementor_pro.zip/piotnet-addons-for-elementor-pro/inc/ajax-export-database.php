<?php

if ( ! defined( 'ABSPATH' ) ) { exit; }
	
add_action( 'wp_ajax_pafe_export_database', 'pafe_export_database' );

function pafe_export_database_prepare_http_header() {
    $now = gmdate('D, d M Y H:i:s');
	header("Expires: Tue, 03 Jul 2001 06:00:00 GMT");
    header("Cache-Control: max-age=0, no-cache, must-revalidate, proxy-revalidate");
    header("Last-Modified: {$now} GMT");
    header("Content-Type: application/force-download");
    header("Content-Type: application/octet-stream");
    header("Content-Type: application/download");
    header("Content-Disposition: attachment;filename=pafe-form-database.csv");
    header("Content-Transfer-Encoding: binary");
}

function pafe_export_database() {
	if ( ! is_user_logged_in() || ! current_user_can( 'manage_options' ) ) {
		wp_die(
			esc_html__( 'You do not have permission to export the form database.', 'pafe' ),
			esc_html__( 'Forbidden', 'pafe' ),
			array( 'response' => 403 )
		);
	}

	check_ajax_referer( 'pafe_export_database', 'nonce' );

	$allowed_post_types = array( 'pafe-form-database', 'pafe-formabandonment' );
	$post_type = isset( $_GET['post_type'] ) ? sanitize_key( wp_unslash( $_GET['post_type'] ) ) : 'pafe-form-database';
	if ( ! in_array( $post_type, $allowed_post_types, true ) ) {
		wp_die(
			esc_html__( 'Invalid post type.', 'pafe' ),
			esc_html__( 'Bad Request', 'pafe' ),
			array( 'response' => 400 )
		);
	}

	$args = array(
		'post_type' => $post_type,
		'posts_per_page' => -1,
	);

	if ( ! empty( $_GET['post_status'] ) ) {
		$post_status = sanitize_key( wp_unslash( $_GET['post_status'] ) );
		if ( 'all' !== $post_status ) {
			$allowed_statuses = array( 'publish', 'pending', 'draft', 'future', 'private', 'trash' );
			if ( in_array( $post_status, $allowed_statuses, true ) ) {
				$args['post_status'] = $post_status;
			}
		}
	}

	if ( ! empty( $_GET['m'] ) ) {
		$args['m'] = absint( $_GET['m'] );
	}

	if ( ! empty( $_GET['form_id'] ) ) {
		$args['meta_key'] = 'form_id';
		$args['meta_value'] = sanitize_text_field( str_replace( '+', ' ', wp_unslash( $_GET['form_id'] ) ) );
	}

	pafe_export_database_prepare_http_header();

	$query = new WP_Query($args);
	$field_id = array();
	$fields = array();
	$th = array();

	$index = 0;
	if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post(); $index++;
		if ($index == 1) {
			$fields_database = get_post_meta(get_the_ID(), '_pafe_form_builder_fields_database', true);
			if ($fields_database) {
                $fields_database = strip_tags($fields_database);
                $fields_database = json_decode($fields_database, true);
			}
		}
		$metas = get_post_meta(get_the_ID());

		foreach($metas as $key=>$value) {
		    if (!in_array($key,$field_id)) {
	    		if (is_array($fields_database)) {
		    		if (isset($fields_database[$key])) {
		    			$field_id[] = $key;
		    		}
	    		} else {
	    			$field_id[] = $key;
	    		}
		    }
		}

	endwhile; endif;

	foreach($field_id as $id) {
		if ($id != '_elementor_controls_usage' && $id != '_edit_lock' && $id != 'form_id_elementor' && $id != 'post_id' && $id != '_pafe_form_builder_fields_database') {
			if (is_array($fields_database)) {
				if (isset($fields_database[$id])) {
					$th[] = !empty($fields_database[$id]['label']) ? $fields_database[$id]['label'] : $id;
				}
			} else {
				$th[] = $id;
			}
		}
	}

	$fields[] = $th;

	if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post();
		$tr = array();
		foreach($field_id as $id) {
			if ($id != '_elementor_controls_usage' && $id != '_edit_lock' && $id != 'form_id_elementor' && $id != 'post_id' && $id != '_pafe_form_builder_fields_database') {
				$meta_value = get_post_meta(get_the_ID(),$id,true);
				$tr[] = $meta_value;
			}
		}
		$fields[] = $tr;
	endwhile; endif;

	$output = fopen('php://output', 'w');

	fwrite($output, "\xEF\xBB\xBF");

	foreach ($fields as $line) {
		fputcsv($output, $line);
	}
	
	wp_die();
}
