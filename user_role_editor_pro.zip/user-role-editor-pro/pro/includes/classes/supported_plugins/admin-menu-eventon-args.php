<?php
defined( 'ABSPATH' ) || exit;

class URE_Admin_Menu_Eventon_Args {
    
    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only: builds the static list of allowed URL argument keys for the current admin post-type screen; no state is read or written from $_GET beyond that.
    public static function get_for_edit($args) {
        if (!isset($_GET['post_type']) || $_GET['post_type']!=='ajde_events') {
            return $args;
        }
        
        $args[''][] = 'event_date_type';
        
        return $args;
    }
    // end of get_for_edit()
    

}
// end of URE_Admin_Menu_Eventon_Args