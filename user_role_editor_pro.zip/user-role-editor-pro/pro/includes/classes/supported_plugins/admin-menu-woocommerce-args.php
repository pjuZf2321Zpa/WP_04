<?php
defined( 'ABSPATH' ) || exit;

class URE_Admin_Menu_Woocommerce_Args {
    
    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only: builds the static list of allowed URL argument keys for the current admin post-type screen; no state is read or written from $_GET beyond that.
    public static function get_for_edit($args) {
        if (!isset($_GET['post_type'])) {
            return $args;
        }

        if ($_GET['post_type']=='product') {
            $args[''][] = 'product_cat';
            $args[''][] = 'product_type';
            $args[''][] = 'stock_status';
            $args[''][] = 'product_brand';
        } elseif ($_GET['post_type']=='shop_order') {
            $args[''][] = '_customer_user';
            $args[''][] = '_created_via';
        } elseif ($_GET['post_type']=='shop_coupon') {
            $args[''][] = 'coupon_type';
        }
        
        return $args;
    }
    // end of get_for_edit()
    

}
// end of URE_Admin_Menu_Woocommerce_Args