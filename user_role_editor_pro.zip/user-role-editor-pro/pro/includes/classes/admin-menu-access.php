<?php
defined( 'ABSPATH' ) || exit;
// phpcs:disable WordPress.WP.I18n.TextDomainMismatch -- Pro intentionally reuses the free plugin's 'user-role-editor' text domain across all bundled files and loads translations for it from Pro's own lang/ folder; this is not a mismatch.

/*
 * User Role Editor WordPress plugin
 * Class URE_Admin_Menu_Access - admin menu access add-on part loaded for every user:
 * the role/user editor UI, admin menu copy maintenance and menu glitches cleanup.
 * Restrictions themselves are applied by URE_Admin_Menu_Access_Restrict, which is not loaded for superadmin.
 * Author: Vladimir Garagulya
 * Author email: support@role-editor.com
 * Author URI: https://role-editor.com
 * License: GPL v2+ 
 */

class URE_Admin_Menu_Access {

    const DEBUG = false;
    
    // reference to the code library object
    private $lib = null;   
    
    // URE_Admin_Menu_Access_Restrict object, loaded for not superadmin users only
    private $restrictions = null;
    

    public function __construct() {
        
        $this->lib = URE_Lib_Pro::get_instance();
        
        add_action('ure_role_edit_toolbar_service', 'URE_Admin_Menu_View::add_toolbar_buttons');
        add_action('ure_load_js', 'URE_Admin_Menu_View::add_js');
        add_action('ure_dialogs_html', 'URE_Admin_Menu_View::dialog_html');        
        add_action('activated_plugin', 'URE_Admin_Menu_Copy::force_update');
        add_action('admin_menu', array($this, 'menu_glitches_cleanup'), 9998);
        add_action('admin_menu', 'URE_Admin_Menu_Copy::update', 9999999997);  // Jetpack uses 998, MetaSlider - 9553, FooGallery - 999999999. We should execute code as late as possible.
        add_action('init', array($this, 'load_restrictions'));
    }
    // end of __construct()
    
    
    /**
     * URE Pro does not restrict superadmin, so restrictions are loaded for other users only.
     * It is executed at 'init', not at 'plugins_loaded' with the constructor, as the current user may be changed between them.
     */
    public function load_restrictions() {
        
        if ( $this->restrictions!==null || $this->lib->is_super_admin() ) {
            return;
        }
        
        $this->restrictions = new URE_Admin_Menu_Access_Restrict();
        
    }
    // end of load_restrictions()
    

    /**
     * Check if there is an accessible submenu item - replace menu item capability with submenu item capability then
     * @global array $submenu
     * @param array $menu_item
     * @return boolean
     */
    private function is_submenu_permitted($menu_item) {
        global $submenu;
        
        $permitted = false;
        if (isset($submenu[$menu_item[2]])) {
            foreach($submenu[$menu_item[2]] as $submenu_item) {
                if (current_user_can($submenu_item[1])) {
                    $permitted = true;
                    break;
                }
            }
        }
        
        return $permitted;
    }
    // end of is_submenu_permitted()
    
    
    /* 
     * Remove menus that require privileges which a user does not have.
     */
    private function remove_prohibited_items() {
        global $menu;
        
        foreach ( $menu as $key=>$menu_item ) {
            if ( !current_user_can( $menu_item[1] ) && !$this->is_submenu_permitted( $menu_item ) ) {
                unset( $menu[$key] );
            }                        
        } // foreach($menu ...
        
    }
    // end of remove_prohibited_items()
    
    
    /**
     * Some plugins incorrectly modify globals $menu/$submenu and users with changed permissions may get broken $menu/submenu$ structures.
     * This function fixes that, removing broken menu/submenu items.
     * @global type $menu
     * @global array $submenu
     */
    public function menu_glitches_cleanup() {
        global $menu, $submenu;
        
        foreach( $menu as $key=>$item ) {
            if ( !isset( $item[1] ) ) {
                unset( $menu[$key] );
            }
        }
        
        foreach( $submenu as $key=>$items_list ) {
            foreach( $items_list as $item_key=>$item ) {
                if ( empty( $item ) || !isset( $item[1] ) || empty( $item[1] ) ) {
                    unset( $submenu[$key][$item_key] );
                }
            }
        }
            
        foreach( $menu as $key=>$item ) {            
            if ( isset( $submenu[$item[2]] ) && empty( $submenu[$item[2]] ) ) {
                unset( $menu[$key] );
            }
        }

        
        $this->remove_prohibited_items();
        
    }
    // end of menu_glitches_cleanup()
    
}
// end of URE_Admin_Menu_Access class
