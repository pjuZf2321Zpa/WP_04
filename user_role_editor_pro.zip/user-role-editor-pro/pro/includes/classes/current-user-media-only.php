<?php
defined( 'ABSPATH' ) || exit;

/* Project: User Role Editor Pro WordPress plugin
 * Setup additional URE option: Current user Media Only
 * Current user see his only media items in the Media Library
 * Author: Vladimir Garagulia
 * Email: support@role-editor.com
 * Site: https://role-editor.com
 * License: GPL v.3
 */

class URE_Current_User_Media_Only {
    
    function __construct() {
         
	add_filter( 'ure_role_additional_options', [__CLASS__, 'add_option'], 10 );         
	
    }
    // end of __construct()
    
    
    public static function add_option( $items ) {
	
	$item = URE_Role_Additional_Options::create_item( 
            'add_current_user_media_only_option', 
            esc_html__('Current user Media only', 'user-role-editor'), 
            'pre_get_posts', 
            [__CLASS__, 'set'] );
	$items[$item->id] = $item;
    
	return $items;	
    }
    // end of add_option()
    
    
    public static function set( $query ) {

	if ( !is_admin() ) {
	    // Apply for /wp-admin UI only
	    return;
	}
	
	if ( !isset( $query->query['post_type'] ) || $query->query['post_type'] !== 'attachment') {
	    return;
	}
	
	$suppressing_filters = $query->get('suppress_filters'); // Filter suppression on?
	if ($suppressing_filters) {
	    return;
	}
	
	$lib = URE_Lib_Pro::get_instance();
	if ( $lib->user_is_admin() ) {
	    return;
	}

	$show_full_list = apply_filters('ure_attachments_show_full_list', false);
	if ( $show_full_list ) { // show full list of attachments
	    return;
	}

	remove_action('pre_get_posts', [__ClASS__, 'set'], 99);

	$query->set('author', get_current_user_id() );

	add_action('pre_get_posts', [__ClASS__, 'set'], 99);
    }
    // end of set()        
    
}
// end of class URE_Current_User_Media_Only