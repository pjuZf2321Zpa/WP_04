<?php
defined( 'ABSPATH' ) || exit;

/*
 * Project: User Role Editor WordPress plugin 
 * Class for Assigning to a user multiple roles
 * Author: Vladimir Garagulya
 * Author email: support@role-editor.com
 * Author URI: https://www.role-editor.com
 * License: GPL v2+
 * 
*/

class URE_User_Other_Roles {

    protected $lib = null;
    private static $counter = 0;
    
    function __construct() {
    
        $this->lib = URE_Lib::get_instance();
        $this->set_hooks();

    }
    // end of $lib
    
    
    public function set_hooks() {
        
        add_filter( 'additional_capabilities_display', array($this, 'additional_capabilities_display'), 10, 1);        
        add_action( 'admin_print_styles-user-edit.php', array($this, 'load_css') );
        add_action( 'admin_print_styles-user-new.php', array($this, 'load_css') );
        add_action( 'admin_enqueue_scripts', array($this, 'load_js' ) );
        add_action( 'edit_user_profile', array($this, 'edit_user_profile_html'), 10, 1 );
        add_action( 'user_new_form', array($this, 'user_new_form'), 10, 1 );
        add_action( 'profile_update', array($this, 'update'), 10 );
        
        $multisite = $this->lib->get('multisite');
        if ($multisite) {          
            add_action( 'wpmu_activate_user', array($this, 'add_other_roles'), 10, 1 );
            add_action( 'added_existing_user', array($this, 'add_other_roles'), 10, 1);
        }
        add_action( 'user_register', array($this, 'add_other_roles'), 10, 1 );
            
    }
    // end of set_hooks()
    
    
    public function additional_capabilities_display( $display ) {
        
        $show = apply_filters('ure_show_additional_capabilities_section', true);
        if ( empty( $show ) ) {
            return $display;
        }

        
        if ( !current_user_can('promote_users') ) {
            return $display;  // No permissions to promote users
        }
        
        $display = false;
        
        return $display;
        
    }
    // end of additional_capabilities_display()    
    
    
    /*
     * Load CSS for the user profile edit page
     */
    public function load_css() {
        
        $show = apply_filters('ure_show_additional_capabilities_section', true );
        if ( empty( $show ) ) {
            return;
        }

        if ( !current_user_can('promote_users') ) {
            return;  // No permissions to promote users
        }
        
        if ( defined('WP_DEBUG') && !empty( WP_DEBUG ) ) {
            $file_name = 'multiple-select.css';
        } else {
            $file_name = 'multiple-select.min.css';
        }
        
        wp_enqueue_style('wp-jquery-ui-dialog');
        wp_enqueue_style('ure-jquery-multiple-select', plugins_url('/css/'. $file_name, URE_Core::get_plugin_full_path() ), array(), URE_Core::PLUGIN_VERSION, 'screen');
        
    }
    // end of load_css()                


    public function load_js($hook_suffix)  {
        global $wp_version;
        
        if ( !in_array( $hook_suffix, array('user-edit.php', 'user-new.php') ) ) {
            return;
        }

        $show = apply_filters('ure_show_additional_capabilities_section', true );
        if ( empty( $show ) ) {
            return;
        }
        
        if ( !current_user_can('promote_users') ) {
            return;  // No permissions to promote users
        }
        
        if ( defined('WP_DEBUG') && !empty( WP_DEBUG ) ) {
            $ms_file_name = 'multiple-select.js';
        } else {
            $ms_file_name = 'multiple-select.min.js';
        }
        $ure_js_suffix = ( defined('SCRIPT_DEBUG') && SCRIPT_DEBUG ) ? '' : '.min';

        $select_primary_role = apply_filters('ure_users_select_primary_role', true);

        wp_enqueue_script('jquery-ui-dialog', '', array('jquery-ui-core', 'jquery-ui-button', 'jquery'), $wp_version, true );
        wp_register_script('ure-jquery-multiple-select', plugins_url('/js/'. $ms_file_name, URE_Core::get_plugin_full_path() ), array(), URE_Core::PLUGIN_VERSION, true );
        wp_enqueue_script('ure-jquery-multiple-select');
        wp_register_script('ure-user-profile-other-roles', plugins_url('/js/user-profile-other-roles' . $ure_js_suffix . '.js', URE_Core::get_plugin_full_path() ), array(), URE_Core::PLUGIN_VERSION, true );
        wp_enqueue_script('ure-user-profile-other-roles');
        wp_localize_script('ure-user-profile-other-roles', 'ure_data_user_profile_other_roles', array(
            'wp_nonce' => wp_create_nonce('user-role-editor'),
            'other_roles' => esc_html__('Other Roles', 'user-role-editor'),
            'select_roles' => esc_html__('Select additional roles for this user', 'user-role-editor'),
            'select_primary_role' => ($select_primary_role || $this->lib->is_super_admin()) ? 1: 0
        ));
    }
    // end of load_js()
    
    
    /**
     * Returns list of user roles, except 1st one, and bbPress assigned as they are shown by WordPress and bbPress themselves.
     * 
     * @param type $user WP_User from wp-includes/capabilities.php
     * @return array
     */
    public function get_roles_array( $user ) {

        if ( !is_array( $user->roles ) || count( $user->roles )<=1 ) {
            return array();
        }

        // get bbPress assigned user role
        if ( function_exists( 'bbp_filter_blog_editable_roles' ) ) {
            $bb_press_role = bbp_get_user_role( $user->ID );
        } else {
            $bb_press_role = '';
        }

        $roles = array();
        foreach ( $user->roles as $role) {
            if (!empty($bb_press_role) && $bb_press_role === $role) {
                // exclude bbPress assigned role
                continue;
            }
            $roles[] = $role;
        }
        array_shift( $roles ); // exclude primary role which is shown by WordPress itself

        return $roles;
    }
    // end of get_roles_array()    
    

    private function roles_select_html($user, $context) {        
        global $wp_roles;
                
        $user_roles = $user->roles;
        $primary_role = array_shift($user_roles);
        // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- 'editable_roles' is WordPress core's own filter hook, not a custom one; name must match exactly.
        $roles = apply_filters('editable_roles', $wp_roles->roles);    // exclude restricted roles if any
        $roles = array_reverse( $roles  );
        if (isset($roles[$primary_role])) { // exclude role assigned to the user as a primary role
            unset($roles[$primary_role]);
        }
        $button_number =  (self::$counter>0) ? '_2': '';

        if ($context==='add-new-user' || $context==='add-existing-user') {
            // Get other default roles
            $other_roles = $this->lib->get_option('other_default_roles', array());
        } else {
            $other_roles = $this->get_roles_array($user);
        }
        if (!is_array($other_roles)) {
            $other_roles = array();
        }

        echo '<select multiple="multiple" id="ure_select_other_roles'. esc_attr( $button_number ) .'" name="ure_select_other_roles" style="width: 500px;" >'."\n";
        foreach($roles as $key=>$role) {
            $selected = in_array( $key, $other_roles, true ) ? 'selected="selected"' : '';
            echo '<option value="'. esc_attr( $key ) .'" '. esc_attr( $selected ) .'>'. esc_html( $role['name'] ) .'</option>'."\n";
        }   // foreach()
        echo '</select><br>'."\n";

        $other_roles_str = count($other_roles) > 0 ? implode(',', $other_roles) : '';
        echo '<input type="hidden" name="ure_other_roles" id="ure_other_roles'. esc_attr( $button_number ) .'" value="' . esc_attr( $other_roles_str ) . '" />';


        $output = $this->lib->roles_text($other_roles);
        echo '<span id="ure_other_roles_list'. esc_attr( $button_number ) .'">'. esc_html( $output ) .'</span>';
        
        self::$counter++;
    }
    // end of roles_select()    
    
    
    /**
     * Returns comma separated string of capabilities directly (not through the roles) assigned to the user
     * 
     * @global WP_Roles $wp_roles
     * @param object $user
     * @return string
     */
    private function get_user_caps_str( $user ) {
        global $wp_roles;
        
        $output = '';
        foreach ($user->caps as $cap => $value) {
            if ( $wp_roles->is_role( $cap ) ) {
                continue;
            }
            if ('' !== $output) {
                $output .= ', ';
            }
            // translators: placeholder %s is replaced by denied user capability id string value
            $output .= $value ? $cap : sprintf(__('Denied: %s', 'user-role-editor'), $cap);
        }
        
        return $output;
    }
    // end of get_user_caps_str()
    
        
    private function user_profile_capabilities($user) {
        
        $current_user_id = get_current_user_id();        
        $user_caps = $this->get_user_caps_str( $user );
?>
          <tr>
              <th>
                  <?php esc_html_e('Capabilities', 'user-role-editor'); ?>
              </th>    
              <td>
<?php 
                echo esc_html( $user_caps ) .'<br/>';
      if ($this->lib->user_is_admin( $current_user_id ) ) {
            echo '<a href="' . esc_url( wp_nonce_url("users.php?page=users-". URE_Core::get_plugin_file() ."&object=user&user_id={$user->ID}", "ure_user_{$user->ID}") ) . '">' .
                 esc_html__('Edit', 'user-role-editor') . '</a>';
      }                      
?>
              </td>
          </tr>    
<?php                
    }
    // end of user_profile_capabilities()
    
    
    private function display($user, $context) {
?>
        <table class="form-table">
        		<tr>
        			<th scope="row"><?php esc_html_e('Other Roles', 'user-role-editor'); ?></th>
        			<td>
<?php
            $this->roles_select_html($user, $context);            
?>
        			</td>
        		</tr>
<?php
    if ($context==='user-edit') {
        $this->user_profile_capabilities($user);
    }
?>
        </table>		
        <?php
        
    }
    // end of display()
    
    
    private function is_user_profile_extention_allowed() {
	
	if ( !isset( $_SERVER['REQUEST_URI'] ) || empty( $_SERVER['REQUEST_URI'] ) ) {
	    return false;
	}
        // Check if we are not at the network admin center
        $request_uri = sanitize_url( wp_unslash( $_SERVER['REQUEST_URI'] ) );
        $result = stripos( $request_uri, 'network/user-edit.php') === false;
        
        return $result;
    }
    // end of is_user_profile_extention_allowed()
    
        
    /**
     * Add URE stuff to the edit user profile page
     * 
     * @param object $user
     * @return void
     */
    public function edit_user_profile_html($user) {
                
        if (!$this->is_user_profile_extention_allowed()) {  
            return;
        }
        
        $show = apply_filters('ure_show_additional_capabilities_section', true);
        if (empty($show)) {
            return;
        }
        
        if ( !current_user_can('promote_users') ) {
            return;  // No permissions to promote users
        }

?>
        <h3><?php esc_html_e('Additional Capabilities', 'user-role-editor'); ?></h3>
<?php
        $this->display($user, 'user-edit');
    }
    // end of edit_user_profile_html()

    
    public function user_new_form( $context ) {
        $show = apply_filters('ure_show_additional_capabilities_section', true);
        if (empty($show)) {
            return;
        }

        if ( !current_user_can('promote_users') ) {
            return;  // No permissions to promote users
        }
        
        $user = new WP_User();
        $this->display( $user, $context );
        
    }
    // end of user_new_form()
    
    
    /* 
     * Save additional user roles when user profile is updated, as WordPress itself doesn't know about them
     * Returns different numbers for automatic testing purpose
     */
    public function update( $user_id ) {
        
        if ( !current_user_can('promote_users') ) {
            return -1;  // No permissions to promote users
        }
        if ( !current_user_can('edit_user', $user_id) ) {
            return -1;  // No permissions to edit this user
        }
        // phpcs:disable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- update() is hooked to WordPress core's own 'profile_update' action, which core only fires after its own check_admin_referer('update-user_...') nonce check on the user-edit/profile screen; verified entirely outside this plugin, WPCS can't see it at all. Below, each role ID extracted from $_POST['ure_other_roles'] is checked against $editable_roles (WP core's own get_editable_roles()) via isset() before use - the function returns early (-2) for any role that isn't a real, existing editable role, so unslashing/sanitizing the raw POST value first would be a no-op.
        if ( !isset( $_POST['ure_other_roles'] ) ) {
            return 3;   // Add default other roles, there is no related data at the POST
        }
        if ( empty( $_POST['ure_other_roles'] ) ) {
            return 1;   // There is no need in processing of other roles. User did not select them
        }

        $user = get_userdata( $user_id );
        $data = explode(',', str_replace(' ', '', $_POST['ure_other_roles'] ) );
        // phpcs:enable
        $editable_roles = get_editable_roles();
        $ure_other_roles = array();
        foreach( $data as $role_id ) {
            if ( empty( $role_id ) ) {
                continue;
            }            
            if ( !isset( $editable_roles[ $role_id ] ) ) {
                return -2;   // If the role isn't editable by the current user, stop processing - no permission to assign this role.
            }
            if ( is_array( $user->roles ) && !in_array( $role_id, $user->roles ) ) {
                $ure_other_roles[] = $role_id;
            }
        }
        foreach( $ure_other_roles as $role ) {
            $user->add_role( $role );
        }
        
        return 2;        
    }
    // end of update()

    
    public function add_default_other_roles( $user_id ) {
        
        if ( empty( $user_id ) ) {
            return false;
        }
        $user = get_user_by('id', $user_id );
        if ( empty( $user->ID ) ) {
            return true;
        }

        // Get default roles if any
        $other_default_roles = $this->lib->get_option('other_default_roles', array() );
        if ( count( $other_default_roles ) === 0 ) {
            return true;
        }
        foreach ( $other_default_roles as $role ) {
            if ( !isset( $user->caps[$role] ) ) {
                $user->add_role( $role );
            }
        }
    }
    // end of add_default_other_roles()


    public function add_other_roles( $user_id ) {

        if ( empty( $user_id ) ) {
            return false;
        }

        $result = $this->update( $user_id );
        if ( $result===3 ) {    // Other roles were not selected manually
            $this->add_default_other_roles( $user_id );
        }
        
    }
    // end of add_other_roles()    
    
        
}
// end of URE_User_Other_Roles class
