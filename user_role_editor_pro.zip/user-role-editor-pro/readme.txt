=== User Role Editor Pro ===
Contributors: shinephp
Tags: user, role, editor, security, access
Requires at least: 4.7
Tested up to: 7.2
Stable tag: 4.67
Requires PHP: 8.2
License: GPLv2 or later
License URI: https://www.role-editor.com/end-user-license-agreement/

User Role Editor Pro WordPress plugin makes user roles and capabilities changing easy. Edit/add/delete WordPress user roles and capabilities.

== Description ==

User Role Editor Pro WordPress plugin allows you to change user roles and capabilities easy.
Just turn on check boxes of capabilities you wish to add to the selected role and click "Update" button to save your changes. That's done. 
Add new roles and customize its capabilities according to your needs, from scratch of as a copy of other existing role. 
Unnecessary self-made role can be deleted if there are no users whom such role is assigned.
Role assigned every new created user by default may be changed too.
Capabilities could be assigned on per user basis. Multiple roles could be assigned to user simultaneously.
You can add new capabilities and remove unnecessary capabilities which could be left from uninstalled plugins.
Multi-site support is provided.

== Installation ==

Installation procedure:

1. Deactivate plugin if you have the previous version installed.
2. Extract "user-role-editor-pro.zip" archive content to the "/wp-content/plugins/user-role-editor-pro" directory.
3. Activate "User Role Editor Pro" plugin via 'Plugins' menu in WordPress admin menu. 
4. Go to the "Settings"-"User Role Editor" and adjust plugin options according to your needs. For WordPress multisite URE options page is located under Network Admin Settings menu.
5. Go to the "Users"-"User Role Editor" menu item and change WordPress roles and capabilities according to your needs.

In case you have a free version of User Role Editor installed: 
Pro version includes its own copy of a free version (or the core of a User Role Editor). So you should deactivate free version and can remove it before installing of a Pro version. 
The only thing that you should remember is that both versions (free and Pro) use the same place to store their settings data. 
So if you delete free version via WordPress Plugins Delete link, plugin will delete automatically its settings data. Changes made to the roles will stay unchanged.
You will have to configure lost part of the settings at the User Role Editor Pro Settings page again after that.
Right decision in this case is to delete free version folder (user-role-editor) after deactivation via FTP, not via WordPress.

== Changelog ==

= [4.67] 04.11.2026 =
* Core version: 4.67
* Security fix (core): Users page: Change Role, Grant Role, Add Role: a user with the "promote_users" capability could grant themselves (or others) roles with capabilities beyond their own, when custom high-privilege roles existed on the site. Role assignment now requires that the acting user already holds all critical capabilities of the target role; self-assignment of roles is no longer allowed. Thanks to Ahmed Mahmoud (Haktrak Networks) for the responsible disclosure.
* New (core): custom filter 'ure_get_critical_capabilities' allows to modify the list of critical capabilities used for the role assignment check. 'manage_options', 'activate_plugins', 'delete_plugins', 'edit_users', 'delete_users' capabilities are under control by default.
* Fix (core): "Without role" button on the Users page stopped working (showed "Please select at least one item to perform this action on." after role selection). 
* Update (core): allow users with only the 'promote_users' capability to use the "Without role" button.
* Update: the site URL (the 'siteurl' option value) is sent to the URE Pro update server with update checking/download request.

= [4.66.4] 27.10.2026 =
* Core version: 4.66.3
* Update: Marked as compatible with WordPress version 7.2
* Update: Required PHP version increased up to 8.2
* Fix: Content view restrictions add-on: restricted posts were not excluded from the front-end posts lists (home page, search results, archives) and from other posts queries, which do not set a single post type: post type is not set at all, set as an array of post types or as 'any'. The check "restrictions are applied to the public custom post types only" added in version 4.63 skipped such queries. Now such queries are skipped only if all requested post types are registered non-public ones. A single post/page view is processed as before: the selected access error action is applied. Discovered and responsibly reported by Michael LaRue.
* Fix: Content view restrictions add-on: the access error action set for a role/user was not loaded under PHP 8, when a post was blocked at the roles level: a string constant was compared with 0 instead of the current access error action value. URE_Content_View_Restrictions::get_access_error_action() returned 0, and the redirect access error action set via the 'ure_content_view_access_data_for_user' or 'ure_content_view_access_data_for_role' filter was not applied. Reported by Michael LaRue.
* New: "Current user Media only" option. Turn it on at Settings > Additional Modules, then tick "Current user Media only" in the "Additional Options" section of the role editor for any role: users with that role see only the media items they uploaded themselves in the Media Library (wp-admin only; administrators are not restricted). Use the 'ure_attachments_show_full_list' filter (return true) to show the full list in a custom context.
* New: Brazilian Portuguese (pt_BR) translation was added. Thanks to Jayron Castro.
* Fix: Admin menu access add-on: Remove only menu items, which submenu was emptied as blocked by URE itself. Some plugins/themes (e.g. Hello Elementor) intentionally remove all their submenu items at 'admin_head' to show a top level menu item only, and URE Pro removed such top level menu item.
* Update: Admin menu access add-on: the code which applies admin menu restrictions was moved to the separate URE_Admin_Menu_Access_Restrict class, which is not loaded for superadmin at all, as URE Pro does not restrict superadmin. URE_Admin_Menu_Access class keeps the code required for every user: Admin Menu access UI, admin menu copy update.
* Fix: Admin menu access add-on: a top level menu item, which is a submenu item for administrator (the admin menu copy is made for administrator), was not removed from menu when blocked (not allowed) for another role. Example: Wordfence "Login Security" page is a submenu item under "Wordfence" for users with 'activate_plugins' capability and a top level menu item for other users. Now restrictions set for the submenu item are applied to such top level menu item too.
* Fix: Several labels on the "About" box ("User Role Editor", "User Role Editor Pro", "Version:", "Plugin URL:", "Download URL:", "Author:", "Send support question") and the "Reset User Roles" heading at the Settings > Tools tab were hardcoded in English and could not be translated. The misspelled "Dowload URL:" label was corrected to "Download URL:".
* Update: "Admin Menu", "Gravity Forms Access", "Meta Boxes", "Nav Menus", "Other Roles", "Plugins", "Posts Edit" and "Widgets Admin" add-ons dialogs JavaScript: the own copy of the AJAX request success handler, identical to the core one, was removed; the core ure_main.update_success() is used instead.
* Update: Admin menu access add-on: unused code was removed from URE_Admin_Menu_Copy::get_submenu(): it added the "Profile" item to a local copy of the admin menu, which was not used. URE_Admin_Menu_Copy::get_menu() adds this item to the admin menu copy.
* Fix (core): Multisite: only the first 100 sites of a network were processed when a role change was applied to all sites of the network, network add-ons data was replicated, a role was imported to all sites, and plugin data was cleaned up on uninstall, as get_sites() (used by URE_Base_Lib::get_blog_ids() since version 4.66) returns 100 sites max by default.
* New (core): 'ure_get_blog_ids_args' filter allows to exclude archived, spam and deleted sites from the list of network sites processed by the plugin (e.g. when a role change is applied to all sites of the network). Return an array with any of 'archived', 'spam', 'deleted' keys set to 0 (exclude such sites) or 1 (process such sites only), e.g. array( 'archived' => 0, 'spam' => 0, 'deleted' => 0 ). Other get_sites() arguments are ignored. Plugin data cleanup on uninstall always processes all sites.

Full list of changes is available in changelog.txt file.
