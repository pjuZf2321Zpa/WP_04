/**
 * Copy a license key to the clipboard (frontend, My Account subscription page).
 *
 * Each copy button next to a key in Related Licenses carries the key in
 * data-license-key. After a copy, the button shows a green tick for two seconds
 * (the `is-copied` class swaps the icons) and the result is announced to screen
 * readers through the sibling status element.
 */
(function () {
  "use strict";

  /**
   * Copy text, falling back to a hidden textarea where the Clipboard API is
   * unavailable (older browsers, non-secure contexts).
   *
   * @param {string} text Text to copy.
   * @return {Promise} Resolves once copied.
   */
  function subscrpt_copy_text(text) {
    if (navigator.clipboard && window.isSecureContext) {
      return navigator.clipboard.writeText(text);
    }

    return new Promise(function (resolve, reject) {
      var field = document.createElement("textarea");
      field.value = text;
      field.setAttribute("readonly", "");
      field.style.position = "fixed";
      field.style.opacity = "0";
      document.body.appendChild(field);
      field.select();

      try {
        if (document.execCommand("copy")) {
          resolve();
        } else {
          reject();
        }
      } catch (error) {
        reject(error);
      }

      document.body.removeChild(field);
    });
  }

  /**
   * Show the copy result on the button for two seconds, then reset it.
   *
   * @param {HTMLElement} button  Copy button.
   * @param {boolean}     copied  Whether the key was copied.
   */
  function subscrpt_show_result(button, copied) {
    var label = button.getAttribute(copied ? "data-copied-label" : "data-failed-label");
    var status = button.parentNode.querySelector(".subscrpt-license-key__status");

    clearTimeout(button.subscrptResetTimer);
    button.classList.toggle("is-copied", copied);
    button.setAttribute("aria-label", label);
    button.setAttribute("title", label);
    if (status) {
      status.textContent = label;
    }

    button.subscrptResetTimer = setTimeout(function () {
      var original = button.getAttribute("data-label");

      button.classList.remove("is-copied");
      button.setAttribute("aria-label", original);
      button.setAttribute("title", original);
      if (status) {
        status.textContent = "";
      }
    }, 2000);
  }

  document.addEventListener("click", function (event) {
    var button = event.target.closest(".subscrpt-license-key__copy");

    if (!button) {
      return;
    }

    subscrpt_copy_text(button.getAttribute("data-license-key")).then(
      function () {
        subscrpt_show_result(button, true);
      },
      function () {
        subscrpt_show_result(button, false);
      },
    );
  });
})();
