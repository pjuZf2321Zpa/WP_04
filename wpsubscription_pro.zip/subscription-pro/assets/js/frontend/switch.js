/**
 * Subscription switch picker (frontend, My Account).
 *
 * Moves the switch picker into the actions row and toggles it like an accordion
 * when the "Switch Subscription" button is clicked.
 */
(function () {
  "use strict";

  function subscrpt_init_switch_picker() {
    var toggle = document.querySelector(".subscrpt_switch_toggle");

    if (!toggle) {
      return;
    }

    // Disabled state (a downgrade is already scheduled): block clicks, show a tooltip.
    if (toggle.classList.contains("subscrpt_switch_disabled")) {
      var tip = document.getElementById("subscrpt_switch_scheduled_tooltip");
      if (tip) {
        toggle.setAttribute("title", tip.textContent);
      }
      toggle.setAttribute("aria-disabled", "true");
      toggle.addEventListener("click", function (event) {
        event.preventDefault();
      });
      return;
    }

    var picker = document.getElementById("subscrpt_switch_picker");
    if (!picker) {
      return;
    }

    // Place the picker inside the actions cell, on its own line below the buttons.
    var actionsCell = toggle.closest("td") || toggle.parentNode;
    actionsCell.appendChild(picker);

    toggle.addEventListener("click", function (event) {
      event.preventDefault();
      picker.classList.toggle("subscrpt_switch_picker_open");
    });

    // Cancel button closes the picker.
    var cancel = picker.querySelector(".subscrpt_switch_cancel");
    if (cancel) {
      cancel.addEventListener("click", function (event) {
        event.preventDefault();
        picker.classList.remove("subscrpt_switch_picker_open");
      });
    }

    // Show the selected option's notice below the intro text.
    var notice = picker.querySelector(".subscrpt_switch_notice");
    var radios = picker.querySelectorAll(".subscrpt_switch_option_radio");

    if (notice) {
      radios.forEach(function (radio) {
        radio.addEventListener("change", function () {
          notice.innerHTML = radio.getAttribute("data-subscrpt-notice") || "";
          notice.hidden = false;
        });
      });
    }

    // Confirm before checkout when the selected plan charges now (upgrade).
    var form = picker.querySelector(".subscrpt_switch_form");
    if (form) {
      form.addEventListener("submit", function (event) {
        var selected = form.querySelector(".subscrpt_switch_option_radio:checked");
        if (!selected) {
          return;
        }
        var message = selected.getAttribute("data-subscrpt-confirm");
        if (message && !window.confirm(message)) {
          event.preventDefault();
        }
      });
    }
  }

  /**
   * Ask for confirmation before following the "Cancel downgrade" link.
   */
  function subscrpt_init_cancel_downgrade_confirm() {
    var cancel = document.querySelector(".subscrpt-scheduled-downgrade-notice__cancel");

    if (!cancel) {
      return;
    }

    cancel.addEventListener("click", function (event) {
      var message = cancel.getAttribute("data-subscrpt-confirm");
      if (message && !window.confirm(message)) {
        event.preventDefault();
      }
    });
  }

  function subscrpt_init() {
    subscrpt_init_switch_picker();
    subscrpt_init_cancel_downgrade_confirm();
  }

  if ("loading" === document.readyState) {
    document.addEventListener("DOMContentLoaded", subscrpt_init);
  } else {
    subscrpt_init();
  }
})();
