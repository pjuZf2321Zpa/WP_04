/**
 * Storefront plan selector — scaffold interactions (no API).
 *
 * Two-level selector: pick a plan group (radio card), then a term (buttons).
 * Simple products are server-rendered; variable products start empty and are
 * (re)built by JS from each variation's injected plan data on `found_variation`
 * (mirrors Sublium). Pure DOM, mock data only.
 */
(function ($) {
  "use strict";

  var box = document.querySelector("[data-subscrpt-buybox]");
  if (!box) {
    return;
  }

  var placeholder = box.innerHTML;

  /**
   * Write the chosen plan-term id into the hidden field that posts with
   * add-to-cart. Empty for the One-Time card (no term).
   */
  function syncPlanId() {
    var hidden = box.querySelector("[data-subscrpt-plan-id]");
    if (!hidden) {
      return;
    }
    var checked = box.querySelector('input[name="subscrpt_plan_group"]:checked');
    var card = checked ? checked.closest("[data-subscrpt-card]") : null;
    var planId = "";
    if (card) {
      var activeBtn = card.querySelector("[data-subscrpt-term-btn].is-active");
      if (activeBtn) {
        planId = activeBtn.getAttribute("data-term-id");
      } else if (card.hasAttribute("data-subscrpt-single-term")) {
        planId = card.getAttribute("data-subscrpt-single-term");
      }
    }
    hidden.value = planId || "";
  }

  // ---- selection behaviour (works for server- or JS-rendered cards) ----
  box.addEventListener("change", function (e) {
    if (e.target.name === "subscrpt_plan_group") {
      box.querySelectorAll("[data-subscrpt-card]").forEach(function (card) {
        card.classList.remove("is-selected");
      });
      var card = e.target.closest("[data-subscrpt-card]");
      if (card) {
        card.classList.add("is-selected");
      }
      syncPlanId();
    }
  });

  // Choosing a term button updates that card's price + note and selects the card.
  box.addEventListener("click", function (e) {
    var btn = e.target.closest("[data-subscrpt-term-btn]");
    if (!btn) {
      return;
    }
    e.preventDefault();
    var wrap = btn.closest("[data-subscrpt-card]");
    if (!wrap) {
      return;
    }

    wrap.querySelectorAll("[data-subscrpt-term-btn]").forEach(function (b) {
      b.classList.remove("is-active");
    });
    btn.classList.add("is-active");

    var priceEl = wrap.querySelector("[data-subscrpt-card-price]");
    var noteEl = wrap.querySelector("[data-subscrpt-note]");
    if (priceEl && btn.getAttribute("data-price")) {
      priceEl.textContent = btn.getAttribute("data-price");
    }
    if (noteEl) {
      // Note is server-built HTML (may include a struck-through regular price).
      noteEl.innerHTML = btn.getAttribute("data-note") || "";
    }

    // The badge reports what *this* term saves, so it moves with the selection.
    // Terms discount by different amounts; one figure for the whole card was
    // only ever right for one of them. Hidden outright when the chosen term is
    // not discounted, so no empty pill is left behind.
    var badgeEl = wrap.querySelector("[data-subscrpt-badge]");
    if (badgeEl) {
      var badge = btn.getAttribute("data-badge") || "";
      badgeEl.textContent = badge;
      badgeEl.hidden = badge === "";
    }

    var radio = wrap.querySelector('input[name="subscrpt_plan_group"]');
    if (radio && !radio.checked) {
      radio.checked = true;
      radio.dispatchEvent(new Event("change", { bubbles: true }));
    }
    syncPlanId();
  });

  // Initialise the hidden plan id from the pre-selected (first) card.
  syncPlanId();

  // ---- variable products: rebuild cards on variation change ----
  if (box.getAttribute("data-subscrpt-variable") !== "1" || typeof $ !== "function") {
    return;
  }

  function esc(str) {
    return String(str == null ? "" : str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function stripHtml(html) {
    var tmp = document.createElement("div");
    tmp.innerHTML = html || "";
    return tmp.textContent || tmp.innerText || "";
  }

  function buildCard(group, selected) {
    var terms = group.terms || [];

    // Head: name + price beside the radio (One-Time may show a struck old price).
    var head;
    if (group.type === "one_time") {
      var old = group.old_price ? "<del>" + group.old_price + "</del>" : "";
      head =
        '<span class="subscrpt-buybox__label">' +
        esc(group.label) +
        "</span>" +
        '<span class="subscrpt-buybox__price">' +
        old +
        "<ins data-subscrpt-card-price>" +
        (group.price || "") +
        "</ins></span>";
    } else if (terms.length) {
      head = '<span class="subscrpt-buybox__label">' + esc(group.label) + "</span>";
    } else {
      head = "";
    }

    // Term options render as buttons below the head (only when more than one).
    var buttons = "";
    if (terms.length > 1) {
      buttons =
        '<span class="subscrpt-buybox__terms" data-subscrpt-terms>' +
        terms
          .map(function (t, i) {
            return (
              '<button type="button" class="subscrpt-buybox__term' +
              (i === 0 ? " is-active" : "") +
              '" data-subscrpt-term-btn data-term-id="' +
              esc(t.id) +
              '" data-price="' +
              esc(stripHtml(t.price)) +
              '" data-note="' +
              esc(t.note) +
              '" data-badge="' +
              esc(t.badge || "") +
              '">' +
              esc(t.label) +
              "</button>"
            );
          })
          .join("") +
        "</span>";
    }

    // Note is server-built HTML (prices/periods only — no user input), rendered
    // as-is so a struck-through regular price shows.
    var note = terms.length
      ? '<span class="subscrpt-buybox__note" data-subscrpt-note>' + terms[0].note + "</span>"
      : "";

    // Slot rendered whenever any term carries a badge, so a discounted term
    // reached later can still fill it; hidden while the shown term has none.
    var badgeText = group.badge || "";
    var anyBadge =
      badgeText !== "" ||
      terms.some(function (t) {
        return t.badge;
      });
    var badge = anyBadge
      ? '<span class="subscrpt-buybox__badge" data-subscrpt-badge' +
        (badgeText === "" ? " hidden" : "") +
        ">" +
        esc(badgeText) +
        "</span>"
      : "";
    var singleAttr = terms.length === 1 ? ' data-subscrpt-single-term="' + esc(terms[0].id) + '"' : "";

    return (
      '<label class="subscrpt-buybox__card' +
      (selected ? " is-selected" : "") +
      '" data-subscrpt-card' +
      singleAttr +
      ">" +
      badge +
      '<span class="subscrpt-buybox__head">' +
      '<input type="radio" class="subscrpt-buybox__radio" name="subscrpt_plan_group" value="' +
      esc(group.id) +
      '"' +
      (selected ? " checked" : "") +
      ">" +
      head +
      "</span>" +
      note +
      buttons +
      "</label>"
    );
  }

  function renderGroups(groups) {
    if (!groups || !groups.length) {
      box.innerHTML = placeholder;
      return;
    }
    box.innerHTML =
      '<input type="hidden" name="subscrpt_plan_id" value="" data-subscrpt-plan-id>' +
      groups
        .map(function (g, i) {
          return buildCard(g, i === 0);
        })
        .join("");
    syncPlanId();
  }

  var $form = $(box).closest("form.variations_form");
  if (!$form.length) {
    $form = $("form.variations_form").first();
  }

  $form.on("found_variation", function (event, variation) {
    if (variation && variation.subscrpt_plans) {
      renderGroups(variation.subscrpt_plans);
    }
  });

  $form.on("reset_data hide_variation", function () {
    box.innerHTML = placeholder;
  });
})(window.jQuery);
