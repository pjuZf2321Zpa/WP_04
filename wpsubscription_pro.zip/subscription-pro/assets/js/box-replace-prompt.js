/**
 * The replace prompt: a full box asks which items to give up for what is coming.
 *
 * One component for every place a box can be changed (the card on an item's
 * page, the cart, a live subscription's box). It only asks; the caller writes
 * the answer.
 *
 *     window.subscrptBoxReplace.ask( { incoming, current, max, trigger } )
 *       -> Promise<Array|null>
 *
 * Contract:
 *
 * - Rows carry product_id, variation_id, qty, name, thumbnail and, when set,
 *   once. A product every cycle and the same product once are two rows, in the
 *   merge and in what the shopper gives up. `max` is the box's maximum in units; 0 or missing means unlimited.
 *   `trigger` is the element that gets focus back (default: the focused one).
 * - over = units(current) + units(incoming) - max. The shopper is asked once
 *   per unit over capacity, each answer giving up one unit of the chosen
 *   current row. Incoming items are never offered for removal.
 * - If over is 0 or less, or max is 0, there is nothing to ask: it resolves at
 *   once with current + incoming merged and opens no dialog.
 * - It resolves with the final contents (rows of product_id, variation_id, qty
 *   and, when set, once), or null for "Keep my box", Escape, the backdrop, or
 *   a browser with no <dialog> (the caller should then fall back).
 * - The server still validates what comes back.
 *
 * Strings come from `subscrptBoxReplaceText`.
 */
(function () {
  "use strict";

  var text = window.subscrptBoxReplaceText || {};
  var FOCUSABLE =
    "button:not([disabled]), [href], input:not([disabled]), select, textarea, [tabindex]:not([tabindex='-1'])";

  /**
   * Fill a "%s" or "%d" placeholder.
   *
   * @param {string} template Template with one placeholder.
   * @param {string|number} value Value to put in.
   * @return {string} The sentence.
   */
  function fill(template, value) {
    return String(template).replace(/%s|%d/, String(value));
  }

  /**
   * Build an element.
   *
   * @param {string} tag Tag name.
   * @param {string} className Class name.
   * @param {string} [content] Text content.
   * @return {HTMLElement} The element.
   */
  function el(tag, className, content) {
    var node = document.createElement(tag);
    node.className = className;
    if (content !== undefined) {
      node.textContent = content;
    }
    return node;
  }

  /**
   * A row's picture, or nothing when it has none.
   *
   * @param {Object} row Item row.
   * @param {string} className Class name for the image.
   * @return {HTMLElement|null} The image.
   */
  function picture(row, className) {
    if (!row.thumbnail) {
      return null;
    }
    var img = el("img", className);
    img.src = row.thumbnail;
    img.alt = "";
    img.width = 48;
    img.height = 48;
    return img;
  }

  /**
   * The same row, keeping only what the cart accepts back.
   *
   * @param {Object} row Item row.
   * @param {number} qty Quantity to give it.
   * @return {Object} Clean row.
   */
  function clean(row, qty) {
    var out = {
      product_id: parseInt(row.product_id, 10) || 0,
      variation_id: parseInt(row.variation_id, 10) || 0,
      qty: qty,
    };
    if (row.once) {
      out.once = true;
    }
    return out;
  }

  var open = null;

  /**
   * Ask which items to swap.
   *
   * @param {{incoming: Object[], current: Object[], max: number, trigger: HTMLElement}} args What is coming, what the box holds, its maximum, and where focus returns.
   * @return {Promise<Object[]|null>} The final contents, or null to keep the box.
   */
  function ask(args) {
    if (open) {
      open.finish(null);
    }

    var incoming = (args && args.incoming ? args.incoming : []).slice();
    var contents = (args && args.current ? args.current : []).map(function (row) {
      return clean(row, parseInt(row.qty, 10) || 1);
    });
    var shown = (args && args.current ? args.current : []).map(function (row) {
      return Object.assign({}, row, { left: parseInt(row.qty, 10) || 1 });
    });
    var trigger = args && args.trigger ? args.trigger : document.activeElement;
    var max = (args && parseInt(args.max, 10)) || 0;
    var index = 0;

    /**
     * Total units in rows.
     *
     * @param {Object[]} rows Item rows.
     * @return {number} Units.
     */
    function units(rows) {
      return rows.reduce(function (sum, row) {
        return sum + (parseInt(row.qty, 10) || 1);
      }, 0);
    }

    /**
     * The contents with the incoming rows added, merging a row already there.
     *
     * @return {Object[]} Final rows.
     */
    function merged() {
      incoming.forEach(function (item) {
        var add = clean(item, parseInt(item.qty, 10) || 1);
        // The same product every cycle and once are two rows: merging them would lose the once.
        var found = contents.filter(function (entry) {
          return (
            entry.product_id === add.product_id &&
            entry.variation_id === add.variation_id &&
            !!entry.once === !!add.once
          );
        })[0];
        if (found) {
          found.qty += add.qty;
        } else {
          contents.push(add);
        }
      });
      return contents;
    }

    var over = max > 0 ? units(contents) + units(incoming) - max : 0;
    var questions = Math.min(over, units(contents));

    return new Promise(function (resolve) {
      if (!incoming.length) {
        resolve(null);
        return;
      }
      if (over <= 0) {
        resolve(merged());
        return;
      }
      if (typeof HTMLDialogElement === "undefined") {
        resolve(null);
        return;
      }

      var dialog = el("dialog", "subscrpt-box-replace");
      var title = el("p", "subscrpt-box-replace__title");
      var list = el("ul", "subscrpt-box-replace__list");
      var keep = el("button", "button subscrpt-box-replace__keep", text.keep || "Keep my box");
      var done = false;

      title.id = "subscrpt-box-replace-title-" + Date.now();
      dialog.setAttribute("aria-labelledby", title.id);
      keep.type = "button";

      /**
       * Close and settle once.
       *
       * @param {Object[]|null} value What to resolve with.
       */
      function finish(value) {
        if (done) {
          return;
        }
        done = true;
        open = null;
        if (dialog.open) {
          dialog.close();
        }
        dialog.remove();
        if (trigger && typeof trigger.focus === "function" && document.contains(trigger)) {
          trigger.focus();
        }
        resolve(value);
      }

      /**
       * Show the question for the current incoming item.
       */
      function render() {
        var names = incoming
          .map(function (item) {
            return item.name || "";
          })
          .join(", ");
        title.textContent = fill(text.title || "Your box is full. Replace one of these with %s?", names);
        list.textContent = "";

        shown.forEach(function (row, position) {
          if (row.left < 1) {
            return;
          }
          var li = el("li", "subscrpt-box-replace__entry");
          var button = el("button", "subscrpt-box-replace__choice");
          var img = picture(row, "subscrpt-box-replace__thumb");
          var label = el("span", "subscrpt-box-replace__name", row.name || "");
          var tag = row.once ? text.once || "next box only" : "";

          button.type = "button";
          button.setAttribute(
            "aria-label",
            fill(text.replace || "Replace %s", row.name || "") +
              (tag ? ", " + tag : "") +
              (row.left > 1 ? ", " + fill(text.count || "× %d", row.left) : ""),
          );
          if (img) {
            button.appendChild(img);
          }
          button.appendChild(label);
          if (tag) {
            button.appendChild(el("span", "subscrpt-box-replace__once", tag));
          }
          if (row.left > 1) {
            button.appendChild(el("span", "subscrpt-box-replace__qty", fill(text.count || "× %d", row.left)));
          }
          button.addEventListener("click", function () {
            swap(position);
          });
          li.appendChild(button);
          list.appendChild(li);
        });

        // The least destructive answer is where focus starts.
        keep.focus();
      }

      /**
       * Give up one unit of the chosen row.
       *
       * @param {number} position Index into the shown rows.
       */
      function swap(position) {
        var row = shown[position];

        contents = contents
          .map(function (entry) {
            if (
              entry.product_id === (parseInt(row.product_id, 10) || 0) &&
              entry.variation_id === (parseInt(row.variation_id, 10) || 0) &&
              !!entry.once === !!row.once
            ) {
              entry.qty -= 1;
            }
            return entry;
          })
          .filter(function (entry) {
            return entry.qty > 0;
          });
        row.left -= 1;
        index += 1;

        if (index >= questions) {
          finish(merged());
          return;
        }
        render();
      }

      var lead = incoming[0] ? picture(incoming[0], "subscrpt-box-replace__incoming") : null;
      var footer = el("div", "subscrpt-box-replace__footer");

      if (lead) {
        dialog.appendChild(lead);
      }
      footer.appendChild(keep);
      dialog.appendChild(title);
      dialog.appendChild(list);
      dialog.appendChild(footer);

      keep.addEventListener("click", function () {
        finish(null);
      });
      // Escape fires `cancel`; it is the same as Keep my box.
      dialog.addEventListener("cancel", function (e) {
        e.preventDefault();
        finish(null);
      });
      // A click on the backdrop lands on the dialog itself.
      dialog.addEventListener("click", function (e) {
        if (e.target === dialog) {
          finish(null);
        }
      });
      // showModal makes the page inert, but wrapping keeps Tab inside on
      // browsers that let focus reach the address bar.
      dialog.addEventListener("keydown", function (e) {
        if (e.key !== "Tab") {
          return;
        }
        var stops = dialog.querySelectorAll(FOCUSABLE);
        if (!stops.length) {
          return;
        }
        var head = stops[0];
        var tail = stops[stops.length - 1];
        if (e.shiftKey && document.activeElement === head) {
          e.preventDefault();
          tail.focus();
        } else if (!e.shiftKey && document.activeElement === tail) {
          e.preventDefault();
          head.focus();
        }
      });

      open = { finish: finish };
      document.body.appendChild(dialog);
      dialog.showModal();
      render();
    });
  }

  window.subscrptBoxReplace = { ask: ask };
})();
