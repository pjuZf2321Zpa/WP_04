/**
 * The box builder.
 *
 * Counts what is in the box, says so, and keeps the add-to-cart button honest:
 * a box that breaks its own rules cannot be submitted. The server validates the
 * same rules again — this only saves the shopper the round trip.
 */
(function () {
  "use strict";

  /**
   * Total units chosen in a builder.
   *
   * @param {HTMLElement} root Builder element.
   * @return {number} Units.
   */
  function countUnits(root) {
    var total = 0;

    root.querySelectorAll(".subscrpt-box-choice__qty").forEach(function (input) {
      total += Math.max(0, parseInt(input.value, 10) || 0);
    });

    return total;
  }

  /**
   * Whether the one-time purchase option is the chosen one. Bought once, every
   * item ships once, so there is nothing left to choose.
   *
   * @param {HTMLElement} root Builder element.
   * @return {boolean} True when one-time is selected.
   */
  function isOneTime(root) {
    var form = root.closest("form");
    var select = form ? form.querySelector('select[name="subscrpt_plan_group"]') : null;
    var checked = form ? form.querySelector('input[name="subscrpt_plan_group"]:checked') : null;

    return (select ? select.value : checked ? checked.value : "") === "one_time";
  }

  /**
   * Show the once choices, or take them away while one-time is selected: hidden,
   * and disabled so they do not post.
   *
   * @param {HTMLElement} root Builder element.
   * @return {void}
   */
  function applyOnce(root) {
    var oneTime = isOneTime(root);

    root.querySelectorAll(".subscrpt-box-choice__once").forEach(function (label) {
      label.hidden = oneTime;
      label.querySelector("input").disabled = oneTime;
    });

    var split = root.querySelector("[data-subscrpt-box-split]");

    if (split && oneTime) {
      split.hidden = true;
      var amount = root.querySelector("[data-subscrpt-box-amount]");

      if (amount) {
        amount.hidden = false;
      }
    }
  }

  /**
   * Units chosen that ship once: the quantity of every ticked once choice.
   *
   * @param {HTMLElement} root Builder element.
   * @return {number} Units.
   */
  function countOnce(root) {
    var total = 0;

    root.querySelectorAll(".subscrpt-box-choice__once input:checked:not(:disabled)").forEach(function (box) {
      var qty = root.querySelector('[name="' + box.name.replace("subscrpt_box_once", "subscrpt_box_items") + '"]');

      total += Math.max(0, parseInt(qty && qty.value, 10) || 0);
    });

    // My Account's form has a quantity of its own for what ships in the next box only.
    root.querySelectorAll(".subscrpt-box-choice__qty--once").forEach(function (input) {
      total += Math.max(0, parseInt(input.value, 10) || 0);
    });

    return total;
  }

  /**
   * The size rule in force — the chosen variation's, or the product's.
   *
   * @param {HTMLElement} root Builder element.
   * @return {{min: number, max: number}} Rule.
   */
  function currentRule(root) {
    var rule = {
      min: parseInt(root.dataset.min, 10) || 0,
      max: parseInt(root.dataset.max, 10) || 0,
    };

    var form = root.closest("form.cart");

    if (!form) {
      return rule;
    }

    var variationInput = form.querySelector('input[name="variation_id"]');

    if (!variationInput || !variationInput.value) {
      return rule;
    }

    var sizes = {};

    try {
      sizes = JSON.parse(root.dataset.sizes || "{}");
    } catch (error) {
      return rule;
    }

    var forVariation = sizes[variationInput.value];

    if (forVariation) {
      return {
        min: parseInt(forVariation.min, 10) || 0,
        max: parseInt(forVariation.max, 10) || 0,
      };
    }

    return rule;
  }

  /**
   * The counter sentences, translated by the server. The English here is only
   * the fallback for a page that did not print them.
   */
  var strings = Object.assign(
    {
      picked: "%d picked",
      pickedOf: "%1$d of %2$d picked",
      pickedNeeded: "%1$d picked, at least %2$d needed",
      pickedNeededRecurring: "%1$d picked, at least %2$d needed that are not once",
    },
    window.subscrptBoxBuilder || {},
  );

  /**
   * Fill %d, %1$d and %2$d in a translated sentence.
   *
   * @param {string}   text   Sentence.
   * @param {number[]} values Numbers, in order.
   * @return {string} The sentence.
   */
  function format(text, values) {
    var next = 0;

    return text.replace(/%(?:(\d+)\$)?d/g, function (match, position) {
      return values[position ? parseInt(position, 10) - 1 : next++];
    });
  }

  /**
   * Mark the picked choices and open or shut their steppers: minus at zero,
   * plus at the item's own maximum or once the box is full. A held builder
   * keeps every control shut.
   *
   * @param {HTMLElement} root Builder element.
   * @param {boolean}     full Whether the box holds its maximum.
   * @return {void}
   */
  function syncChoices(root, full) {
    var held = root.hasAttribute("data-subscrpt-box-held");

    root.querySelectorAll(".subscrpt-box-choice").forEach(function (choice) {
      var picked = 0;

      choice.querySelectorAll(".subscrpt-box-choice__qty:not(.subscrpt-box-choice__qty--once)").forEach(function (qty) {
        picked += Math.max(0, parseInt(qty.value, 10) || 0);
      });

      choice.classList.toggle("is-picked", picked > 0);
      writePicks(choice);

      var input = shownQty(choice);
      var stepper = input ? input.closest(".subscrpt-box-choice__stepper") : null;

      if (!stepper) {
        return;
      }

      var qty = Math.max(0, parseInt(input.value, 10) || 0);
      var max = parseInt(input.max, 10) || 0;

      stepper.querySelectorAll("[data-subscrpt-box-step]").forEach(function (button) {
        var up = parseInt(button.getAttribute("data-subscrpt-box-step"), 10) > 0;

        button.disabled = held || input.disabled || (up ? full || (max && qty >= max) : qty <= 0);
      });
    });
  }

  /**
   * The quantity a card's stepper is showing: its selected variation's.
   *
   * @param {HTMLElement} choice A `.subscrpt-box-choice`.
   * @return {?HTMLInputElement} The input, or null.
   */
  function shownQty(choice) {
    return choice.querySelector(".subscrpt-box-choice__stepper .subscrpt-box-choice__qty:not([hidden])");
  }

  /**
   * List what a variable card holds: a line on the card, e.g. "Blue × 1 · Red × 2",
   * and a row per option in its popup, each with a way to take it out.
   *
   * @param {HTMLElement} choice A `.subscrpt-box-choice`.
   * @return {void}
   */
  function writePicks(choice) {
    var picks = choice.querySelector("[data-subscrpt-box-picks]");
    var select = choice.querySelector("[data-subscrpt-box-variant]");

    if (!select) {
      return;
    }

    var parts = [];
    var rows = [];

    Array.prototype.forEach.call(select.options, function (option) {
      var input = choice.querySelector('.subscrpt-box-choice__qty[data-subscrpt-box-for="' + option.value + '"]');
      var qty = input ? Math.max(0, parseInt(input.value, 10) || 0) : 0;

      if (qty) {
        parts.push(option.textContent.trim() + " × " + qty);
        rows.push({ id: option.value, label: option.textContent.trim(), qty: qty });
      }
    });

    if (picks) {
      picks.textContent = parts.join(" · ");
      picks.hidden = !parts.length;
    }

    var open = choice.querySelector("[data-subscrpt-box-open]");

    if (open) {
      open.textContent = open.getAttribute(parts.length ? "data-label-picked" : "data-label-empty");
    }

    writeInbox(choice, rows);
  }

  /**
   * Fill a popup's "In your box" list.
   *
   * @param {HTMLElement} choice A `.subscrpt-box-choice`.
   * @param {Array}       rows   Each picked option: id, label, qty.
   * @return {void}
   */
  function writeInbox(choice, rows) {
    var inbox = choice.querySelector("[data-subscrpt-box-inbox]");

    if (!inbox) {
      return;
    }

    var removeLabel = inbox.getAttribute("data-label-remove") || "Remove";

    inbox.textContent = "";

    rows.forEach(function (row) {
      var item = document.createElement("li");
      var show = document.createElement("button");
      var qty = document.createElement("span");
      var remove = document.createElement("button");

      item.className = "subscrpt-box-variants__item";

      // The option's name shows it above, to change how many.
      show.type = "button";
      show.className = "subscrpt-box-variants__show";
      show.setAttribute("data-subscrpt-box-show", row.id);
      show.textContent = row.label;

      qty.className = "subscrpt-box-variants__qty";
      qty.textContent = "× " + row.qty;

      remove.type = "button";
      remove.className = "subscrpt-box-variants__remove";
      remove.setAttribute("data-subscrpt-box-remove", row.id);
      remove.setAttribute("aria-label", removeLabel + " " + row.label);
      remove.textContent = removeLabel;

      item.appendChild(show);
      item.appendChild(qty);
      item.appendChild(remove);
      inbox.appendChild(item);
    });

    var empty = choice.querySelector("[data-subscrpt-box-inbox-empty]");

    if (empty) {
      empty.hidden = rows.length > 0;
    }
  }

  /**
   * The attributes an option of a variable card carries, e.g. {attribute_pa_color: "blue"}.
   * An empty value is "any".
   *
   * @param {HTMLOptionElement} option Option of the card's select.
   * @return {Object} Attributes.
   */
  function optionAttrs(option) {
    try {
      return JSON.parse((option && option.getAttribute("data-attrs")) || "{}") || {};
    } catch (error) {
      return {};
    }
  }

  /**
   * Press the popup's attribute values for the option showing. An attribute
   * the option leaves as "any" keeps the shopper's own choice.
   *
   * @param {HTMLElement} choice A `.subscrpt-box-choice`.
   * @return {void}
   */
  function pressAttrs(choice) {
    var dialog = choice.querySelector("[data-subscrpt-box-dialog]");
    var select = choice.querySelector("[data-subscrpt-box-variant]");

    if (!dialog || !select) {
      return;
    }

    var attrs = optionAttrs(select.options[select.selectedIndex]);
    var wanted = dialog.subscrptWanted || {};
    var groups = dialog.querySelectorAll("[data-subscrpt-box-attr]");
    var pressed = {};

    groups.forEach(function (group) {
      var key = group.getAttribute("data-subscrpt-box-attr");
      var first = group.querySelector("[data-subscrpt-box-attr-value]");

      pressed[key] = attrs[key] || wanted[key] || (first ? first.getAttribute("data-subscrpt-box-attr-value") : "");
    });

    var offered = Array.prototype.map.call(select.options, optionAttrs);

    groups.forEach(function (group) {
      var key = group.getAttribute("data-subscrpt-box-attr");

      group.querySelectorAll("[data-subscrpt-box-attr-value]").forEach(function (button) {
        var value = button.getAttribute("data-subscrpt-box-attr-value");

        // As on the product page: a value no option in the box has, beside
        // the others pressed, is dimmed. Still clickable; choosing it moves
        // the others to an option that has it.
        var inBox = offered.some(function (option) {
          return Object.keys(pressed).every(function (k) {
            var want = k === key ? value : pressed[k];

            return !option[k] || option[k] === want;
          });
        });

        button.setAttribute("aria-pressed", value === pressed[key] ? "true" : "false");
        button.classList.toggle("is-unavailable", !inBox);
      });
    });
  }

  /**
   * Pick one attribute value in a popup and show the option it leads to: the
   * one matching every pressed value, else the first that has this value.
   *
   * @param {HTMLElement} button The value's button.
   * @return {void}
   */
  function chooseAttr(button) {
    var choice = button.closest(".subscrpt-box-choice");
    var dialog = choice.querySelector("[data-subscrpt-box-dialog]");
    var select = choice.querySelector("[data-subscrpt-box-variant]");
    var key = button.closest("[data-subscrpt-box-attr]").getAttribute("data-subscrpt-box-attr");
    var wanted = {};

    dialog.querySelectorAll("[data-subscrpt-box-attr]").forEach(function (group) {
      var pressed = group.querySelector('[aria-pressed="true"]');

      wanted[group.getAttribute("data-subscrpt-box-attr")] = pressed
        ? pressed.getAttribute("data-subscrpt-box-attr-value")
        : "";
    });

    wanted[key] = button.getAttribute("data-subscrpt-box-attr-value");
    dialog.subscrptWanted = wanted;

    var options = Array.prototype.slice.call(select.options);
    var fits = function (keys) {
      return function (option) {
        var attrs = optionAttrs(option);

        return keys.every(function (k) {
          return !attrs[k] || attrs[k] === wanted[k];
        });
      };
    };
    var match = options.filter(fits(Object.keys(wanted)))[0] || options.filter(fits([key]))[0];

    if (!match) {
      return;
    }

    if (select.value !== match.value) {
      select.value = match.value;
      select.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      pressAttrs(choice);
    }
  }

  /**
   * Show the chosen variation on its card: its quantity and once choice, its
   * picture, and the link to its own page.
   *
   * @param {HTMLSelectElement} select The card's variation selector.
   * @return {void}
   */
  function chooseVariant(select) {
    var choice = select.closest(".subscrpt-box-choice");
    var option = select.options[select.selectedIndex];
    var id = select.value;

    choice.querySelectorAll("[data-subscrpt-box-for]").forEach(function (el) {
      el.hidden = el.getAttribute("data-subscrpt-box-for") !== id;
    });

    choice.querySelectorAll("[data-subscrpt-box-step]").forEach(function (button) {
      button.setAttribute("aria-controls", "subscrpt-box-pick-" + id);
    });

    pressAttrs(choice);

    // A variable card keeps the product's picture; its popup shows the option's.
    var media = choice.querySelector("[data-subscrpt-box-variant-image]");
    var link = choice.querySelector("[data-subscrpt-box-link]");
    var img = media ? media.querySelector("img") : link ? link.querySelector("img") : null;

    if (link && !media && option.getAttribute("data-url")) {
      link.href = option.getAttribute("data-url");
    }

    if (img && option.getAttribute("data-image")) {
      img.src = option.getAttribute("data-image");

      if (option.getAttribute("data-srcset")) {
        img.srcset = option.getAttribute("data-srcset");
      } else {
        img.removeAttribute("srcset");
      }
    }
  }

  /**
   * The variable cards' popups: open and close, attribute values, and the
   * "In your box" list. Every change goes through the card's select or its
   * quantities, so the counter, the quote and the tray follow as they do for
   * any other card.
   *
   * @param {Event} event Click inside the builder.
   * @return {void}
   */
  function variantsClick(event) {
    var target = event.target;
    var choice = target.closest && target.closest(".subscrpt-box-choice");
    var dialog = choice ? choice.querySelector("[data-subscrpt-box-dialog]") : null;

    if (!dialog) {
      return;
    }

    var select = choice.querySelector("[data-subscrpt-box-variant]");

    if (target.closest("[data-subscrpt-box-open]")) {
      dialog.subscrptWanted = {};
      pressAttrs(choice);

      if (typeof dialog.showModal === "function") {
        dialog.showModal();
      } else {
        dialog.setAttribute("open", "");
      }

      return;
    }

    // The close buttons, and a click on the backdrop, which lands on the dialog itself.
    if (target.closest("[data-subscrpt-box-close]") || target === dialog) {
      if (typeof dialog.close === "function") {
        dialog.close();
      } else {
        dialog.removeAttribute("open");
      }

      return;
    }

    var value = target.closest("[data-subscrpt-box-attr-value]");

    if (value) {
      chooseAttr(value);
      return;
    }

    var show = target.closest("[data-subscrpt-box-show]");

    if (show && select) {
      dialog.subscrptWanted = {};
      select.value = show.getAttribute("data-subscrpt-box-show");
      select.dispatchEvent(new Event("change", { bubbles: true }));
      return;
    }

    var remove = target.closest("[data-subscrpt-box-remove]");

    if (remove) {
      var input = choice.querySelector(
        '.subscrpt-box-choice__qty[data-subscrpt-box-for="' + remove.getAttribute("data-subscrpt-box-remove") + '"]',
      );

      if (input) {
        input.value = 0;
        input.dispatchEvent(new Event("input", { bubbles: true }));
      }

      // The row is gone; keep focus in the popup.
      dialog.focus();
    }
  }

  /**
   * Move a choice's quantity one step, then announce it as typed input so the
   * counter and the quote follow.
   *
   * @param {HTMLElement} button The step button.
   * @return {void}
   */
  function step(button) {
    var input = shownQty(button.closest(".subscrpt-box-choice"));

    if (!input) {
      return;
    }

    var max = parseInt(input.max, 10) || 0;
    var next = Math.max(
      0,
      (parseInt(input.value, 10) || 0) + parseInt(button.getAttribute("data-subscrpt-box-step"), 10),
    );

    input.value = max ? Math.min(max, next) : next;
    input.dispatchEvent(new Event("input", { bubbles: true }));
  }

  /**
   * Update the counter and the add-to-cart button.
   *
   * @param {HTMLElement} root Builder element.
   * @return {void}
   */
  function sync(root) {
    applyOnce(root);

    var counter = root.querySelector(".subscrpt-box-builder__counter, .subscrpt-box-form__counter");
    var rule = currentRule(root);
    var units = countUnits(root);
    var once = countOnce(root);
    var form = root.closest("form.cart") || root.closest("form");
    // The minimum is what ships every cycle; the maximum is everything in the box.
    var ready =
      !root.hasAttribute("data-subscrpt-box-held") &&
      (!rule.min || units - once >= rule.min) &&
      (!rule.max || units <= rule.max);

    if (counter) {
      if (once && rule.min && units - once < rule.min) {
        counter.textContent = format(strings.pickedNeededRecurring, [units, rule.min]);
      } else if (rule.max) {
        counter.textContent = format(strings.pickedOf, [units, rule.max]);
      } else if (rule.min && units < rule.min) {
        counter.textContent = format(strings.pickedNeeded, [units, rule.min]);
      } else {
        counter.textContent = format(strings.picked, [units]);
      }

      counter.classList.toggle("is-ready", ready && units > 0);
      counter.classList.toggle("is-over", !!rule.max && units > rule.max);
    }

    syncChoices(root, !!rule.max && units >= rule.max);

    if (form) {
      form.querySelectorAll('button[type="submit"]').forEach(function (button) {
        button.disabled = !ready;
      });
    }
  }

  /**
   * Whether a purchase option can hold the builder: its body carries the
   * eligibility marker. A layout without room in the card (classic, dropdown,
   * buttons) renders the body below the options, so it is found by the group.
   *
   * @param {HTMLElement} box  The `[data-subscrpt-buybox]`.
   * @param {HTMLElement} card One `[data-subscrpt-card]`.
   * @return {boolean} True when the option can hold it.
   */
  function canHold(box, card) {
    if (card.querySelector("[data-subscrpt-box-eligible]")) {
      return true;
    }

    var radio = card.querySelector('input[name="subscrpt_plan_group"]');
    var group = card.getAttribute("data-subscrpt-group") || (radio ? radio.value : "");
    var found = false;

    if (group) {
      box.querySelectorAll("[data-subscrpt-body-for]").forEach(function (body) {
        if (
          body.getAttribute("data-subscrpt-body-for") === group &&
          body.querySelector("[data-subscrpt-box-eligible]")
        ) {
          found = true;
        }
      });
    }

    return found;
  }

  /**
   * Show the last quote on the purchase cards that can hold the builder.
   *
   * Every such card sells the same box at the same price, so each follows the
   * quote. The card's term switch rewrites its price from the plan term, so
   * this runs again after one.
   *
   * @param {HTMLElement} root Builder element.
   * @return {void}
   */
  function writeCards(root) {
    var quote = root.cardQuote;
    var box = buyboxFor(root);

    if (!quote || !box) {
      return;
    }

    box.querySelectorAll("[data-subscrpt-card]").forEach(function (card) {
      if (!canHold(box, card)) {
        return;
      }

      var amount = card.querySelector("[data-subscrpt-card-price]");
      var regular = card.querySelector("[data-subscrpt-card-regular]");

      if (amount) {
        amount.innerHTML = quote.price_html;
      }

      if (regular) {
        regular.innerHTML = quote.regular_html;
        regular.hidden = !quote.regular_html;
      }
    });
  }

  /**
   * Ask the server what the box costs and swap the answer in.
   *
   * The server prices; this only displays. Prices are never computed here.
   *
   * @param {HTMLElement} root Builder element.
   * @return {void}
   */
  function requote(root) {
    var price = root.querySelector("[data-subscrpt-box-price]");

    if (!price || !root.dataset.quoteUrl) {
      return;
    }

    var params = new URLSearchParams();
    params.set("product_id", root.dataset.productId);
    params.set("box_id", root.dataset.boxId);

    var variation = root.closest("form") ? root.closest("form").querySelector('input[name="variation_id"]') : null;
    var plan = root.closest("form") ? root.closest("form").querySelector("[data-subscrpt-plan-id]") : null;

    if (plan && plan.value) {
      params.set("plan_id", plan.value);
    }

    if (variation && variation.value) {
      params.set("variation_id", variation.value);
    }

    root.querySelectorAll(".subscrpt-box-choice__qty").forEach(function (input) {
      var qty = Math.max(0, parseInt(input.value, 10) || 0);

      if (qty) {
        var id = input.name.replace(/^subscrpt_box_items\[(\d+)\]$/, "$1");
        var once = root.querySelector(
          '.subscrpt-box-choice__once input[name="subscrpt_box_once[' + id + ']"]:not(:disabled)',
        );

        params.set("items[" + id + "]", qty);

        if (once && once.checked) {
          params.set("once[" + id + "]", "1");
        }
      }
    });

    var asked = (root.quoteAsked = (root.quoteAsked || 0) + 1);

    fetch(root.dataset.quoteUrl + (root.dataset.quoteUrl.indexOf("?") === -1 ? "?" : "&") + params.toString(), {
      credentials: "same-origin",
    })
      .then(function (response) {
        return response.json();
      })
      .then(function (body) {
        // A slower, older answer must not overwrite a newer one.
        if (asked !== root.quoteAsked || !body || !body.success) {
          return;
        }

        var regular = price.querySelector("[data-subscrpt-box-regular]");

        price.querySelector("[data-subscrpt-box-amount]").innerHTML = body.data.price_html;

        if (regular) {
          regular.innerHTML = body.data.regular_html;
          regular.hidden = !body.data.regular_html;
        }

        var split = price.querySelector("[data-subscrpt-box-split]");

        if (split) {
          var hasOnce = !!body.data.first_html;

          split.hidden = !hasOnce;
          split.querySelector("[data-subscrpt-box-first]").innerHTML = body.data.first_html || "";
          split.querySelector("[data-subscrpt-box-then]").innerHTML = body.data.then_html || "";
          // "First box" and "Then" say what the recurring price alone would.
          price.querySelector("[data-subscrpt-box-amount]").hidden = hasOnce;

          if (hasOnce && regular) {
            regular.hidden = true;
          }
        }

        if (body.data.once_label) {
          root.querySelectorAll("[data-subscrpt-box-once-label]").forEach(function (label) {
            label.textContent = body.data.once_label;
          });
        }

        var message = root.querySelector("[data-subscrpt-box-message]");

        if (message) {
          message.textContent = body.data.message;
        }

        root.cardQuote = body.data;
        writeCards(root);
      })
      .catch(function () {
        // The last price stays; checkout prices the box again regardless.
      });
  }

  /**
   * Wire one builder.
   *
   * @param {HTMLElement} root Builder element.
   * @return {void}
   */
  function init(root) {
    root.addEventListener("input", function (event) {
      if (event.target.classList.contains("subscrpt-box-choice__qty")) {
        sync(root);
        window.clearTimeout(root.quoteTimer);
        root.quoteTimer = window.setTimeout(function () {
          requote(root);
        }, 250);
      }
    });

    root.addEventListener("click", function (event) {
      var button = event.target.closest && event.target.closest("[data-subscrpt-box-step]");

      if (button && !button.disabled) {
        step(button);
        return;
      }

      variantsClick(event);
    });

    root.addEventListener("change", function (event) {
      if (event.target.hasAttribute && event.target.hasAttribute("data-subscrpt-box-variant")) {
        chooseVariant(event.target);
        sync(root);
        return;
      }

      if (event.target.closest && event.target.closest(".subscrpt-box-choice__once")) {
        sync(root);
        requote(root);
      }
    });

    var defaults = root.querySelector(".subscrpt-box-builder__defaults");

    if (defaults) {
      defaults.addEventListener("click", function () {
        root.querySelectorAll(".subscrpt-box-choice__qty").forEach(function (input) {
          input.value = parseInt(input.dataset.default, 10) || 0;
        });

        sync(root);
        requote(root);
      });
    }

    // A variable box changes size with the chosen variation.
    var form = root.closest("form.cart");

    if (form && window.jQuery) {
      window.jQuery(form).on("found_variation reset_data", function () {
        window.setTimeout(function () {
          sync(root);
          requote(root);
        }, 0);
      });
    }

    sync(root);
  }

  /**
   * The purchase options in the builder's form.
   *
   * @param {HTMLElement} root Builder element.
   * @return {?HTMLElement} The `[data-subscrpt-buybox]`, or null.
   */
  function buyboxFor(root) {
    var form = root.closest("form");

    return form ? form.querySelector("[data-subscrpt-buybox]") : null;
  }

  /**
   * The body of the selected purchase option: the one rendered below the
   * control for its group (classic, dropdown, buttons), or the one inside its
   * card.
   *
   * @param {HTMLElement} box The `[data-subscrpt-buybox]`.
   * @return {?HTMLElement} A `[data-subscrpt-card-body]`, or null.
   */
  function selectedBody(box) {
    var select = box.querySelector('select[name="subscrpt_plan_group"]');
    var checked = box.querySelector('input[name="subscrpt_plan_group"]:checked');
    var group = select ? select.value : checked ? checked.value : "";
    var found = null;

    if (!group) {
      return null;
    }

    box.querySelectorAll("[data-subscrpt-body-for]").forEach(function (body) {
      if (!found && body.getAttribute("data-subscrpt-body-for") === group) {
        found = body;
      }
    });

    if (found) {
      return found;
    }

    box.querySelectorAll("[data-subscrpt-card]").forEach(function (card) {
      var radio = card.querySelector('input[name="subscrpt_plan_group"]');
      var own = card.getAttribute("data-subscrpt-group") || (radio ? radio.value : "");

      if (!found && own === group) {
        found = card.querySelector("[data-subscrpt-card-body]");
      }
    });

    return found;
  }

  /**
   * Hold the builder out of the order, or let it back in.
   *
   * Held, its controls are disabled — so nothing of the box posts — and the
   * add-to-cart button stays shut. Let back in, it enables what it disabled
   * and what the plan selector disabled while it sat in an unselected body
   * (marked `data-subscrpt-body-disabled`), as the selector does for the
   * selected body.
   *
   * @param {HTMLElement} root Builder element.
   * @param {boolean}     held Whether to hold it.
   * @return {void}
   */
  function hold(root, held) {
    if (held) {
      root.setAttribute("data-subscrpt-box-held", "");
    } else {
      root.removeAttribute("data-subscrpt-box-held");
    }

    var note = root.querySelector("[data-subscrpt-box-held-note]");

    if (note) {
      note.hidden = !held;
    }

    root.querySelectorAll("input, select, textarea, button").forEach(function (el) {
      if (held) {
        if (!el.disabled) {
          el.disabled = true;
          el.setAttribute("data-subscrpt-box-held", "");
        }
        return;
      }

      ["data-subscrpt-box-held", "data-subscrpt-body-disabled"].forEach(function (marker) {
        if (el.hasAttribute(marker)) {
          el.removeAttribute(marker);
          el.disabled = false;
        }
      });
    });

    sync(root);
  }

  /**
   * Move the builder into the selected option's body, so it is the one that
   * posts. It is moved, never cloned: the picks stay and post by name.
   *
   * Only a body marked `data-subscrpt-box-eligible` can hold it; under any
   * other option (installments) it is parked below the options and held.
   * With no option bodies at all — a variable product before a choice, or a
   * theme's older selector — it stays where it rendered, usable.
   *
   * @param {HTMLElement} root Builder element.
   * @return {void}
   */
  function place(root) {
    var box = buyboxFor(root);

    if (!box) {
      return;
    }

    var body = selectedBody(box);

    if (!body) {
      hold(root, false);
      return;
    }

    if (!body.querySelector("[data-subscrpt-box-eligible]")) {
      park(root, box);
      hold(root, true);
      return;
    }

    if (root.parentNode !== body) {
      body.appendChild(root);
    }

    hold(root, false);
  }

  /**
   * Take the builder out of the options before their markup is replaced, and
   * leave it, visible, just after them. Doing it twice does nothing.
   *
   * @param {HTMLElement} root Builder element.
   * @param {HTMLElement} box  The `[data-subscrpt-buybox]` about to be replaced.
   * @return {void}
   */
  function park(root, box) {
    if (box.contains(root)) {
      box.parentNode.insertBefore(root, box.nextSibling);
    }
  }

  /**
   * Every builder that sits in the same form as an element.
   *
   * @param {Element} el Element inside a form.
   * @return {HTMLElement[]} Builders.
   */
  function buildersNear(el) {
    var form = el && el.closest ? el.closest("form") : null;

    return form ? Array.prototype.slice.call(form.querySelectorAll(".subscrpt-box-builder")) : [];
  }

  // Capture runs before the plan selector's own listener, so the builder is
  // already in the newly selected body when the selector disables the rest.
  document.addEventListener(
    "change",
    function (event) {
      if (event.target && event.target.name === "subscrpt_plan_group") {
        buildersNear(event.target).forEach(function (root) {
          place(root);
          // After the plan selector's own listener has set the plan the quote names.
          window.setTimeout(function () {
            requote(root);
          }, 0);
        });
      }
    },
    true,
  );

  document.addEventListener("subscrpt_cards_before_swap", function (event) {
    buildersNear(event.target).forEach(function (root) {
      park(root, event.target);
    });
  });

  document.addEventListener("subscrpt_cards_after_swap", function (event) {
    buildersNear(event.target).forEach(function (root) {
      // The options of a variable box are rendered per variation, so the line's
      // option is only there once the variation has been found.
      preselect(root);
      place(root);
      writeCards(root);
    });
  });

  // Bubbling, so it runs after the plan selector has rewritten the card's price.
  document.addEventListener("change", function (event) {
    var target = event.target;

    if (
      target &&
      target.hasAttribute &&
      (target.hasAttribute("data-subscrpt-term") || target.hasAttribute("data-subscrpt-term-select"))
    ) {
      buildersNear(target).forEach(function (root) {
        writeCards(root);
        requote(root);
      });
    }
  });

  /**
   * Fire a change the plan selector listens for.
   *
   * @param {HTMLElement} el Control that changed.
   * @return {void}
   */
  function announce(el) {
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }

  /**
   * Select the purchase option a cart line was bought on, when the builder was
   * opened to edit it: the one-time option, or the option holding the plan
   * term. Editing changes contents only, so this is where the page starts, not
   * a choice the shopper is asked to make again.
   *
   * @param {HTMLElement} root Builder element.
   * @return {void}
   */
  function preselect(root) {
    var box = buyboxFor(root);
    var plan = root.getAttribute("data-subscrpt-edit-plan");

    if (!box || plan === null) {
      return;
    }

    var group = "";
    var term = null;

    if (root.getAttribute("data-subscrpt-edit-once") === "1") {
      group = "one_time";
    } else if (plan !== "0") {
      term = box.querySelector(
        'input[data-subscrpt-term][value="' + plan + '"], option[data-subscrpt-term-option][value="' + plan + '"]',
      );

      if (term) {
        var control = term.tagName === "OPTION" ? term.parentNode : term;
        var named = /^subscrpt_plan_term\[(.+)\]$/.exec(control.name || "");
        group = named ? named[1] : "";
      } else {
        var single = box.querySelector('[data-subscrpt-single-term="' + plan + '"]');
        var radio = single ? single.querySelector('input[name="subscrpt_plan_group"]') : null;
        group = single ? single.getAttribute("data-subscrpt-group") || (radio ? radio.value : "") : "";
      }
    }

    if (!group) {
      return;
    }

    var select = box.querySelector('select[name="subscrpt_plan_group"]');
    var chosen = select || box.querySelector('input[name="subscrpt_plan_group"][value="' + group + '"]');

    if (!chosen) {
      return;
    }

    if (select) {
      select.value = group;
    } else {
      chosen.checked = true;
    }

    announce(chosen);

    if (term) {
      if (term.tagName === "OPTION") {
        term.parentNode.value = plan;
        announce(term.parentNode);
      } else {
        term.checked = true;
        announce(term);
      }
    }
  }

  /**
   * Hold a variable box's size still while its cart line is edited: the
   * selectors cannot be changed and cannot be cleared.
   *
   * @param {HTMLElement} root Builder element.
   * @return {void}
   */
  function lockVariation(root) {
    var form = root.closest("form.variations_form");

    if (!form || !root.hasAttribute("data-subscrpt-edit-plan")) {
      return;
    }

    form.querySelectorAll(".variations select").forEach(function (select) {
      select.disabled = true;
    });
    form.querySelectorAll(".reset_variations").forEach(function (link) {
      link.style.display = "none";
    });
  }

  /**
   * Keep Modern Cart's AJAX add-to-cart small enough to arrive.
   *
   * Modern Cart re-sends the form as `formEntries`, turning
   * `subscrpt_box_items[6785]` into an array with 6785 empty slots. PHP's
   * `max_input_vars` then drops the rest of the request, nonce included, and
   * nothing is added. The native `subscrpt_box_items[id]` fields it also sends
   * carry the same picks and win in `$_POST`, so that copy is dropped.
   *
   * @return {void}
   */
  function trimModernCartRequest() {
    if (!window.jQuery) {
      return;
    }

    window.jQuery.ajaxPrefilter(function (options) {
      if (typeof options.data !== "string" || options.data.indexOf("action=moderncart_add_to_cart") === -1) {
        return;
      }

      options.data = options.data
        .split("&")
        .filter(function (pair) {
          return decodeURIComponent(pair.split("=")[0]).indexOf("formEntries[subscrpt_box_items]") !== 0;
        })
        .join("&");
    });
  }

  // ── The page around the builder: filters, paging and the box tray ──────

  /**
   * Show the cards the chosen category and search allow, the first twelve of
   * them until the shopper asks for more.
   *
   * A card with something in it always stays: hiding a pick would hide part of
   * the box being built.
   *
   * @param {HTMLElement} root Builder element.
   * @return {void}
   */
  function filterCards(root) {
    var grid = root.querySelector(".subscrpt-box-builder__grid");

    if (!grid) {
      return;
    }

    var search = root.querySelector("[data-subscrpt-box-search]");
    var term = search ? search.value.toLowerCase().trim() : "";
    var chip = root.querySelector("[data-subscrpt-box-cat].is-on");
    var cat = chip ? chip.getAttribute("data-subscrpt-box-cat") : "";
    var limit = parseInt(grid.getAttribute("data-subscrpt-box-paged"), 10) || 0;
    var showAll = root.subscrptShowAll || !!term || !!cat;
    var shown = 0;
    var matched = 0;

    grid.querySelectorAll(":scope > .subscrpt-box-choice").forEach(function (card) {
      var name = card.getAttribute("data-subscrpt-box-name") || "";
      var cats = (card.getAttribute("data-subscrpt-box-cats") || "").split(",");
      var held = Array.prototype.some.call(card.querySelectorAll(".subscrpt-box-choice__qty"), function (input) {
        return (parseInt(input.value, 10) || 0) > 0;
      });
      var match = (!term || name.indexOf(term) !== -1) && (!cat || cats.indexOf(cat) !== -1);

      if (match) {
        matched++;
      }

      var visible = held || (match && (showAll || !limit || shown < limit));

      if (visible && match) {
        shown++;
      }

      card.hidden = !visible;
    });

    var nomatch = root.querySelector("[data-subscrpt-box-nomatch]");

    if (nomatch) {
      nomatch.hidden = matched > 0;
    }

    var more = root.querySelector("[data-subscrpt-box-more]");

    if (more) {
      var left = matched - shown;

      more.parentNode.hidden = showAll || left <= 0;
      more.textContent = (more.getAttribute("data-label") || "%d").replace("%d", left);
    }
  }

  /**
   * The add-to-cart button the tray stands in for.
   *
   * @param {HTMLElement} root Builder element.
   * @return {?HTMLElement} The form's own submit button.
   */
  function realButton(root) {
    var form = root.closest("form");

    return form ? form.querySelector('button[type="submit"].single_add_to_cart_button, button[type="submit"]') : null;
  }

  /**
   * What one delivery costs, as the page currently says it.
   *
   * A box priced by its picks quotes itself; otherwise the price is the
   * selected purchase option's.
   *
   * @param {HTMLElement} root Builder element.
   * @return {string} HTML of the price, or "".
   */
  function trayPrice(root) {
    var quote = root.querySelector("[data-subscrpt-box-price]");

    if (quote) {
      var visible = Array.prototype.filter.call(quote.children, function (el) {
        return !el.hidden && el.textContent.trim();
      });

      return visible.length ? visible[visible.length - 1].innerHTML : "";
    }

    var form = root.closest("form");
    var checked = form ? form.querySelector('input[name="subscrpt_plan_group"]:checked') : null;
    var card = checked ? checked.closest("[data-subscrpt-card], label, li, div") : null;
    var price = card ? card.querySelector("[data-subscrpt-card-price]") : null;

    if (!price && form) {
      price = form.querySelector("[data-subscrpt-card-price]");
    }

    return price ? price.innerHTML : "";
  }

  /**
   * The chosen billing period, e.g. "1 month".
   *
   * @param {HTMLElement} root Builder element.
   * @return {string} Its label, or "".
   */
  function trayCadence(root) {
    var form = root.closest("form");

    if (!form) {
      return "";
    }

    var term = form.querySelector('input[name^="subscrpt_plan_term"]:checked:not(:disabled)');

    if (term) {
      var label = form.querySelector('label[for="' + term.id + '"]');

      return label ? label.textContent.replace(/\s+/g, " ").trim() : "";
    }

    var select = form.querySelector("select[data-subscrpt-term-select]:not(:disabled)");

    return select && select.selectedIndex >= 0 ? select.options[select.selectedIndex].text : "";
  }

  /**
   * Bring the tray up to date with the builder.
   *
   * @param {HTMLElement} root Builder element.
   * @return {void}
   */
  function syncTray(root) {
    var tray = root.querySelector("[data-subscrpt-box-tray]");

    if (!tray) {
      return;
    }

    var units = countUnits(root);
    var rule = currentRule(root);
    var goal = rule.max || rule.min || 0;
    var counter = root.querySelector(".subscrpt-box-builder__counter");
    var message = root.querySelector("[data-subscrpt-box-message]");
    var bar = tray.querySelector("[data-subscrpt-box-tray-bar]");
    var button = realButton(root);
    var add = tray.querySelector("[data-subscrpt-box-tray-add]");

    tray.querySelector("[data-subscrpt-box-tray-count]").textContent = counter ? counter.textContent : String(units);
    tray.querySelector("[data-subscrpt-box-tray-msg]").textContent = message ? message.textContent.trim() : "";
    tray.querySelector("[data-subscrpt-box-tray-total]").innerHTML = trayPrice(root);
    tray.querySelector("[data-subscrpt-box-tray-cadence]").textContent = trayCadence(root);

    bar.parentNode.hidden = !goal;
    bar.style.width = goal ? Math.min(100, Math.round((units / goal) * 100)) + "%" : "0";

    if (button && add) {
      add.disabled = button.disabled || button.classList.contains("disabled") || !units;

      // Editing a box in the cart says so on the real button; the tray follows.
      if (root.hasAttribute("data-subscrpt-edit-plan")) {
        add.textContent = button.textContent.trim() || add.textContent;
      }
    }
  }

  /**
   * Wire the filters and the tray to one builder.
   *
   * @param {HTMLElement} root Builder element.
   * @return {void}
   */
  function initPage(root) {
    if (!root.querySelector(".subscrpt-box-builder__grid")) {
      return;
    }

    // The tray's button presses the form's own, so the form's own button and
    // quantity go out of sight; without this script they stay as they were.
    var form = root.closest("form");

    if (form && root.querySelector("[data-subscrpt-box-tray]")) {
      form.classList.add("subscrpt-box-has-tray");
    }

    var schedule = function () {
      window.clearTimeout(root.trayTimer);
      root.trayTimer = window.setTimeout(function () {
        syncTray(root);
      }, 30);
    };

    root.addEventListener("click", function (event) {
      var chip = event.target.closest("[data-subscrpt-box-cat]");

      if (chip) {
        root.querySelectorAll("[data-subscrpt-box-cat]").forEach(function (other) {
          other.classList.toggle("is-on", other === chip);
          other.setAttribute("aria-pressed", other === chip ? "true" : "false");
        });
        filterCards(root);
        return;
      }

      if (event.target.closest("[data-subscrpt-box-more]")) {
        root.subscrptShowAll = true;
        filterCards(root);
        return;
      }

      if (event.target.closest("[data-subscrpt-box-tray-add]")) {
        var button = realButton(root);

        if (button && !button.disabled) {
          button.click();
        }
      }
    });

    root.addEventListener("input", function (event) {
      if (event.target.matches("[data-subscrpt-box-search]")) {
        filterCards(root);
      }
    });

    // The counter, the message and the price are written by the builder and
    // its quote; the tray follows whatever they say.
    if (window.MutationObserver) {
      var tray = root.querySelector("[data-subscrpt-box-tray]");
      var observer = new MutationObserver(function (mutations) {
        // The tray's own writes are not news.
        var outside = mutations.some(function (mutation) {
          return !tray || !tray.contains(mutation.target);
        });

        if (outside) {
          schedule();
        }
      });

      observer.observe(root, {
        subtree: true,
        childList: true,
        characterData: true,
        attributes: true,
        attributeFilter: ["hidden", "value"],
      });

      var button = realButton(root);

      if (button) {
        observer.observe(button, { attributes: true, attributeFilter: ["disabled", "class"] });
      }
    }

    var form = root.closest("form");

    if (form) {
      form.addEventListener("change", schedule);
      form.addEventListener("input", schedule);
      form.addEventListener("click", schedule);
    }

    filterCards(root);
    syncTray(root);
  }

  document.addEventListener("DOMContentLoaded", function () {
    if (document.querySelector(".subscrpt-box-builder")) {
      trimModernCartRequest();
    }
    document.querySelectorAll(".subscrpt-box-builder").forEach(lockVariation);
    document.querySelectorAll(".subscrpt-box-builder").forEach(preselect);
    document.querySelectorAll(".subscrpt-box-builder").forEach(place);
    document.querySelectorAll(".subscrpt-box-builder, .subscrpt-box-form").forEach(init);
    document.querySelectorAll(".subscrpt-box-builder").forEach(initPage);
  });
})();
