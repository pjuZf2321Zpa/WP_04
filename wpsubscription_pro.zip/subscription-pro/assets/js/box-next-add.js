/**
 * "Add to your next box": a subscriber adds the item to a live box from its page.
 *
 * Each button is a link to the subscription's box in My Account, so without
 * this script (or without <dialog>) it still leads somewhere the box can be
 * changed. With it, a click posts to the `subscrpt_box_next_add` endpoint
 * (`subscrptBoxNextAdd.url`, nonce on `[data-subscrpt-box-next]`) with
 * `mode=add`; where the card offers it, the subscriber's choice of "next box
 * only" rides on the item as `once`. A full box asks which item to give up (`subscrptBoxReplace.ask`)
 * and the answer goes back with `mode=set` as the whole box.
 */
(function () {
  "use strict";

  var config = window.subscrptBoxNextAdd || {};
  var NOTICE = "data-subscrpt-box-add-notice";

  /**
   * Call the endpoint.
   *
   * @param {HTMLElement} link The button.
   * @param {string} mode add or set.
   * @param {Object[]} items Rows of product_id, variation_id, qty and, for the next box only, once.
   * @return {Promise<Object>} The endpoint's answer.
   */
  function call(link, mode, items) {
    var wrap = link.closest("[data-subscrpt-box-next]");
    var body = new URLSearchParams();
    body.set("nonce", wrap ? wrap.getAttribute("data-nonce") : "");
    body.set("mode", mode);
    body.set("subscription_id", link.getAttribute("data-subscription-id"));
    body.set("items", JSON.stringify(items));

    return fetch(config.url, {
      method: "POST",
      credentials: "same-origin",
      headers: { Accept: "application/json" },
      body: body,
    }).then(function (response) {
      return response.json();
    });
  }

  /**
   * Show a notice where WooCommerce shows its own.
   *
   * @param {HTMLElement} link The button that was used.
   * @param {string} message What to say.
   * @param {boolean} ok Whether it went through.
   */
  function notify(link, message, ok) {
    var old = document.querySelector("[" + NOTICE + "]");
    if (old) {
      old.remove();
    }

    var notice = document.createElement("div");
    notice.setAttribute(NOTICE, "");
    notice.className = ok
      ? "woocommerce-message subscrpt-box-add__notice"
      : "woocommerce-error subscrpt-box-add__notice";
    notice.setAttribute("role", ok ? "status" : "alert");

    var account = link.getAttribute("data-account-url");
    if (ok && account) {
      var view = document.createElement("a");
      view.href = account;
      view.className = "button wc-forward";
      view.textContent = config.view || "View your box";
      notice.appendChild(view);
    }
    notice.appendChild(document.createTextNode(" " + message));

    var wrapper = document.querySelector(".woocommerce-notices-wrapper");
    if (wrapper) {
      wrapper.appendChild(notice);
    } else {
      var card = link.closest("[data-subscrpt-box-add]");
      card.parentNode.insertBefore(notice, card);
    }
    notice.scrollIntoView({ block: "nearest" });
  }

  /**
   * Add the item, asking first when the box is full.
   *
   * @param {HTMLElement} link The button.
   * @return {Promise<void>} Settles when the subscriber has been told.
   */
  function add(link) {
    var name = link.getAttribute("data-item-name") || "";
    var scope = link.closest("[data-subscrpt-box-next-scope]") || link.closest("li");
    var choice = scope ? scope.querySelector("[data-subscrpt-box-next-once] input:checked") : null;
    var once = !!choice && choice.value === "1";
    var items = [
      { product_id: parseInt(link.getAttribute("data-product-id"), 10) || 0, variation_id: 0, qty: 1, once: once },
    ];

    /**
     * Say how it went.
     *
     * @param {Object} result The endpoint's answer.
     */
    function told(result) {
      if (result.status !== "ok") {
        notify(link, result.message || config.failed || "", false);
        return;
      }
      if (result.added && !result.added.length && result.skipped && result.skipped.length) {
        notify(
          link,
          (once
            ? config.presentOnce || "%s is already in your next box only."
            : config.present || "%s is already in your next box."
          ).replace("%s", name),
          true,
        );
        return;
      }

      var message = (
        once ? config.addedOnce || "Added %s to your next box only." : config.added || "Added %s to your next box."
      ).replace("%s", name);

      notify(link, message, true);
      // A page that shows the box (My Account) refreshes it from this.
      link.dispatchEvent(new CustomEvent("subscrpt-box-next-added", { bubbles: true, detail: { message: message } }));
    }

    return call(link, "add", items).then(function (result) {
      if (result.status !== "needs_replace") {
        told(result);
        return;
      }

      return window.subscrptBoxReplace
        .ask({ incoming: result.incoming, current: result.current, max: result.max, trigger: link })
        .then(function (contents) {
          if (!contents) {
            return;
          }
          return call(link, "set", contents).then(told);
        });
    });
  }

  document.addEventListener("click", function (e) {
    var link = e.target.closest ? e.target.closest("[data-subscrpt-box-next-add]") : null;

    if (!link || !config.url || !window.subscrptBoxReplace || typeof HTMLDialogElement === "undefined") {
      return;
    }
    // A new tab, window or download keeps the link's own meaning.
    if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) {
      return;
    }
    e.preventDefault();

    if (link.getAttribute("aria-busy") === "true") {
      return;
    }
    link.setAttribute("aria-busy", "true");

    add(link)
      .catch(function () {
        notify(link, config.failed || "", false);
      })
      .then(function () {
        link.removeAttribute("aria-busy");
      });
  });
})();
