/**
 * Editor side of the Frequently Bought Together block.
 *
 * The block is dynamic: the front end and this preview are both the PHP
 * render behind `[subscrpt_box_together]`, so there is nothing to build here.
 */
(function (wp) {
  var el = wp.element.createElement;
  var __ = wp.i18n.__;
  var ServerSideRender = wp.serverSideRender;

  /**
   * The block's editor view: a preview of the section and a product field.
   *
   * @param {Object}   props               Block props.
   * @param {Object}   props.attributes    Block attributes.
   * @param {Function} props.setAttributes Attribute setter.
   * @return {Object} Element.
   */
  function Edit(props) {
    var product = props.attributes.product;

    return el(
      "div",
      wp.blockEditor.useBlockProps(),
      el(
        wp.blockEditor.InspectorControls,
        null,
        el(
          wp.components.PanelBody,
          { title: __("Product", "subscription-pro") },
          el(wp.components.TextControl, {
            type: "number",
            min: 0,
            label: __("Product ID", "subscription-pro"),
            help: __("Leave at 0 to use the product being viewed.", "subscription-pro"),
            value: product ? String(product) : "",
            onChange: function (value) {
              props.setAttributes({ product: parseInt(value, 10) || 0 });
            },
          }),
        ),
      ),
      el(ServerSideRender, {
        block: "subscription-pro/box-together",
        attributes: props.attributes,
        EmptyResponsePlaceholder: function () {
          return el(
            "p",
            { className: "subscrpt-together-block__empty" },
            __(
              "Frequently bought together shows here once the product can go in a box. Set a product ID, or place the block on a product page.",
              "subscription-pro",
            ),
          );
        },
      }),
    );
  }

  wp.blocks.registerBlockType("subscription-pro/box-together", {
    edit: Edit,
    save: function () {
      return null;
    },
  });
})(window.wp);
