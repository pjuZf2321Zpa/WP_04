/**
 * Persists dismissal of the "license required" notice for the current login.
 *
 * WordPress's own dismiss button only hides the notice in the DOM — it is back
 * on the next page load. This records the dismissal server-side against the
 * current session token, so it stays gone until the user logs in again.
 */
(function () {
  "use strict";

  var config = window.subscrptProLicenseNotice;

  if (!config || !config.ajaxUrl) {
    return;
  }

  document.addEventListener("click", function (event) {
    var button = event.target.closest(".notice-dismiss");

    if (!button) {
      return;
    }

    var notice = button.closest("[data-subscrpt-license-notice]");

    if (!notice) {
      return;
    }

    var body = new FormData();
    body.append("action", config.action);
    body.append("nonce", config.nonce);

    // Fire and forget: the notice is already hidden by core's handler, and a
    // failed request simply means it reappears next load rather than
    // leaving the admin in a broken state.
    window.fetch(config.ajaxUrl, {
      method: "POST",
      credentials: "same-origin",
      body: body,
    });
  });
})();
