/**
 * Required-plugins notice.
 *
 * Installs and activates every missing dependency in sequence (one AJAX call
 * each — the `install` action also activates), then reloads so the dependency
 * check runs again. One button for all plugins; mirrors the free plugin's
 * dependency-notice look.
 */
(function ($) {
  "use strict";

  var settings = window.subscrptRequiredPlugins || {};
  var i18n = settings.i18n || {};

  $(document).on("click", ".subscrpt-pro-install", function (event) {
    event.preventDefault();

    var $button = $(this);

    if ($button.hasClass("is-busy")) {
      return;
    }

    var plugins = [];

    try {
      plugins = JSON.parse($button.attr("data-plugins") || "[]");
    } catch (error) {
      plugins = [];
    }

    // Drop anything without the two fields the AJAX handler requires, so a bad
    // entry can never post an empty plugin (which the server rejects).
    plugins = plugins.filter(function (item) {
      return item && item.plugin && (item.action_type === "install" || item.action_type === "activate");
    });

    if (!plugins.length) {
      return;
    }

    $button.addClass("is-busy");

    // Run the plugins one after another — activating one can change what the
    // next needs, and it keeps a failure pinned to a single plugin.
    var chain = plugins.reduce(function (promise, item) {
      return promise.then(function () {
        return $.post(window.ajaxurl, {
          action: "sdevs_pro_install_plugin",
          plugin: item.plugin,
          action_type: item.action_type,
          _wpnonce: settings.nonce,
        }).then(function (response) {
          if (response && response.success) {
            return true;
          }

          return $.Deferred()
            .reject((response && response.data) || i18n.error)
            .promise();
        });
      });
    }, $.Deferred().resolve().promise());

    chain
      .done(function () {
        // Re-run the dependency check with every plugin now in place.
        window.location.reload();
      })
      .fail(function (message) {
        $button.removeClass("is-busy");
        window.alert(typeof message === "string" && message ? message : i18n.error);
      });
  });
})(jQuery);
