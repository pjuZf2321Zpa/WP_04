/**
 * The Boxes screen.
 *
 * Everything here writes through the REST routes in Api/BoxController, the way
 * the Plans screen does. The list behaviour — search, filter, paging — is
 * implemented here rather than inherited: it lives in the free plugin's
 * plans.js, which is bound to the Plans markup, so Boxes carries its own copy
 * instead of reaching into another screen's script.
 *
 * A change that reshapes the box — publishing, the product, a duration, a save
 * — reloads the page, so the header, the tabs' counts and the Selling panel
 * never disagree with what was stored. The message to show survives the reload
 * in sessionStorage.
 *
 * @package SpringDevs\SubscriptionPro
 */
(function ($) {
  "use strict";

  var cfg = window.subscrptBoxes || {};
  var i18n = cfg.i18n || {};
  var FLASH = "subscrptBoxFlash";

  if (!cfg.restUrl) {
    return;
  }

  /**
   * Call a box route.
   *
   * @param {string} method HTTP method.
   * @param {string} path   Path after the /boxes base, e.g. '/12/product'.
   * @param {Object} body   Optional JSON body.
   * @returns {Promise<Object>} The decoded response. A failure rejects with an
   *                            Error carrying the response body as `.data`.
   */
  function api(method, path, body) {
    return fetch(cfg.restUrl + (path || ""), {
      method: method,
      credentials: "same-origin",
      headers: {
        "Content-Type": "application/json",
        "X-WP-Nonce": cfg.nonce,
      },
      body: body ? JSON.stringify(body) : undefined,
    }).then(function (response) {
      return response
        .json()
        .catch(function () {
          return {};
        })
        .then(function (data) {
          if (!response.ok) {
            var error = new Error(data.message || i18n.genericError);
            error.data = data;
            throw error;
          }
          return data;
        });
    });
  }

  /**
   * Say something happened, without blocking the page.
   *
   * @param {string}  message What to say.
   * @param {boolean} isError Whether it went wrong.
   * @returns {void}
   */
  function notice(message, isError) {
    if (window.WPSubsToast) {
      window.WPSubsToast.show(message, isError ? "error" : "success");
      return;
    }

    var $notice = $('<div class="notice is-dismissible"><p></p></div>').addClass(
      isError ? "notice-error" : "notice-success",
    );

    $notice.find("p").text(message);
    $(".wp-subscription-admin-content").first().prepend($notice);
  }

  /**
   * Report a failure.
   *
   * @param {Error} error What went wrong.
   * @returns {void}
   */
  function fail(error) {
    notice(error && error.message ? error.message : i18n.genericError, true);
  }

  /**
   * Go somewhere, and say something once the page has loaded.
   *
   * @param {string} message What to say after the load.
   * @param {string} url     Where to go; the current page when empty.
   * @returns {void}
   */
  function reloadWith(message, url) {
    try {
      window.sessionStorage.setItem(FLASH, message || "");
    } catch (e) {
      // Storage refused: the page still reloads, just without the message.
    }

    leaving = true;

    if (url) {
      window.location.href = url;
    } else {
      window.location.reload();
    }
  }

  /**
   * Fill %d / %s / %1$s-style placeholders.
   *
   * @param {string} text   Translated text.
   * @param {Array}  values Values in order.
   * @returns {string} The text.
   */
  function format(text, values) {
    var i = 0;

    return String(text || "").replace(/%(\d+\$)?[ds]/g, function (match, position) {
      var index = position ? parseInt(position, 10) - 1 : i++;
      return values[index] !== undefined ? values[index] : "";
    });
  }

  /**
   * A sum of money as the store writes it, near enough for an example.
   *
   * @param {number} value Amount.
   * @returns {string} The amount with its currency symbol.
   */
  function money(value) {
    var decimals = parseInt(cfg.decimals, 10);

    return (cfg.currency || "") + Number(value || 0).toFixed(isNaN(decimals) ? 2 : decimals);
  }

  /**
   * The box this screen is showing.
   *
   * @returns {number} Box id, or 0 on the list.
   */
  function currentBox() {
    return parseInt($("[data-subscrpt-box]").data("subscrpt-box"), 10) || 0;
  }

  // ── Unsaved changes ──────────────────────────────────────────────────────

  var dirty = false;
  var leaving = false;

  /**
   * Show the save bar once something on the tab has changed.
   *
   * @returns {void}
   */
  function markDirty() {
    dirty = true;
    $("[data-subscrpt-savebar]").prop("hidden", false);
  }

  window.addEventListener("beforeunload", function (event) {
    if (dirty && !leaving) {
      event.preventDefault();
      event.returnValue = i18n.unsaved || "";
    }
  });

  // Any edit inside a tab's form counts, except the controls that only look —
  // a search, a filter, a page.
  $(document).on("input change", "[data-subscrpt-box-form] :input", function () {
    if ($(this).closest("[data-subscrpt-nodirty], .subscrpt-box-ptools, [data-subscrpt-pool-cat-find]").length) {
      return;
    }

    if ($(this).is("[data-subscrpt-pool-cat-find], [data-subscrpt-pool-search], [data-subscrpt-pool-category]")) {
      return;
    }

    markDirty();
  });

  $(document).on("click", "[data-subscrpt-box-discard]", function () {
    dirty = false;
    leaving = true;
    window.location.reload();
  });

  // ── Choice cards ─────────────────────────────────────────────────────────

  // A radio drawn as a card: the card that holds the checked radio is "on".
  $(document).on("change", ".subscrpt-box-choice input[type=radio]", function () {
    var name = this.name;

    $('.subscrpt-box-choice input[type=radio][name="' + name + '"]').each(function () {
      $(this).closest(".subscrpt-box-choice").toggleClass("is-on", this.checked);
    });
  });

  // ── Popover menus ────────────────────────────────────────────────────────

  /**
   * Close every open menu but one.
   *
   * @param {string} keep The menu to leave alone.
   * @returns {void}
   */
  function closeMenus(keep) {
    $("[data-subscrpt-menu]").each(function () {
      var key = $(this).data("subscrpt-menu");

      if (key !== keep) {
        $(this).prop("hidden", true);
        $('[data-subscrpt-menu-toggle="' + key + '"], [data-subscrpt-publish]')
          .filter(function () {
            return "publish" === key ? $(this).is("[data-subscrpt-publish]") : true;
          })
          .attr("aria-expanded", "false");
      }
    });
  }

  /**
   * Open or close one menu.
   *
   * @param {string} key The [data-subscrpt-menu] to toggle.
   * @param {jQuery} $button Its button.
   * @returns {void}
   */
  function toggleMenu(key, $button) {
    var $menu = $('[data-subscrpt-menu="' + key + '"]');
    var open = $menu.prop("hidden");

    closeMenus(key);
    $menu.prop("hidden", !open);
    $button.attr("aria-expanded", open ? "true" : "false");
  }

  $(document).on("click", "[data-subscrpt-menu-toggle]", function (event) {
    event.stopPropagation();
    toggleMenu($(this).data("subscrpt-menu-toggle"), $(this));
  });

  $(document).on("click", function (event) {
    if (!$(event.target).closest(".subscrpt-box-pop").length) {
      closeMenus("");
    }
  });

  $(document).on("keydown", function (event) {
    if ("Escape" === event.key) {
      closeMenus("");
    }
  });

  // A menu item that opens a dialog closes its menu first.
  $(document).on("click", ".subscrpt-box-menu [data-wpsubs-modal-open]", function () {
    closeMenus("");
  });

  // ── The list: search, status, paging ─────────────────────────────────────

  /**
   * Filter, page and re-render a browsable list.
   *
   * @param {jQuery} $scope The [data-subscrpt-browse] wrapper.
   * @returns {void}
   */
  function renderBrowse($scope) {
    var term = ($scope.find("[data-subscrpt-browse-search]").val() || "").toLowerCase().trim();
    var status =
      $scope.find('[data-subscrpt-browse-status][aria-pressed="true"]').data("subscrpt-browse-status") || "all";
    var perPage = parseInt($scope.data("per-page"), 10) || 20;
    var page = parseInt($scope.data("page"), 10) || 1;

    var $items = $scope.find("[data-subscrpt-browse-item]");
    var $matching = $items.filter(function () {
      var $item = $(this);
      var named = !term || ($item.data("name") || "").toString().indexOf(term) !== -1;

      return named && ("all" === status || $item.data("status") === status);
    });

    var total = $matching.length;
    var pages = Math.max(1, Math.ceil(total / perPage));

    if (page > pages) {
      page = pages;
      $scope.data("page", page);
    }

    $items.hide();
    $matching.slice((page - 1) * perPage, page * perPage).show();

    $scope.find("[data-subscrpt-browse-empty]").prop("hidden", 0 !== total);

    var $pager = $scope.find("[data-subscrpt-browse-pager]").empty();

    if (pages > 1) {
      for (var p = 1; p <= pages; p++) {
        $('<button type="button" class="wpsubs-btn wpsubs-btn--sm"></button>')
          .addClass(p === page ? "wpsubs-btn--primary" : "wpsubs-btn--outline")
          .css("margin-right", "4px")
          .text(p)
          .data("page", p)
          .appendTo($pager);
      }
    }
  }

  $(document).on("input", "[data-subscrpt-browse-search]", function () {
    var $scope = $(this).closest("[data-subscrpt-browse]");
    $scope.data("page", 1);
    renderBrowse($scope);
  });

  $(document).on("click", "[data-subscrpt-browse-status]", function () {
    var $scope = $(this).closest("[data-subscrpt-browse]");

    $scope.find("[data-subscrpt-browse-status]").attr("aria-pressed", "false");
    $(this).attr("aria-pressed", "true");
    $scope.data("page", 1);
    renderBrowse($scope);
  });

  $(document).on("click", "[data-subscrpt-browse-pager] button", function () {
    var $scope = $(this).closest("[data-subscrpt-browse]");
    $scope.data("page", $(this).data("page"));
    renderBrowse($scope);
  });

  $(document).on("change", "[data-subscrpt-select-all]", function () {
    $(this).closest("table").find(".wpsubs-row-check:visible").prop("checked", this.checked);
  });

  // A row opens its box, but not when the click was meant for something on it.
  $(document).on("click", "[data-box-id][data-href]", function (event) {
    if ($(event.target).closest("a, button, input, label, .wpsubs-adv-select").length) {
      return;
    }

    window.location.href = $(this).data("href");
  });

  $(document).on("keydown", "[data-box-id][data-href]", function (event) {
    if ("Enter" === event.key && event.target === this) {
      window.location.href = $(this).data("href");
    }
  });

  // ── Moving shipments through packing ─────────────────────────────────────
  //
  // "Send back" is a retry: a failed box returns to scheduled so it re-enters
  // the next pack run, rather than being hand-edited into a state.
  // An adv-select announces a choice with "wpsubs:select", not "change" — it
  // only sets its hidden input — so listening for "change" never fired.
  $(document).on("wpsubs:select", "[data-subscrpt-shipment-bulk]", function (event) {
    var action = event.originalEvent && event.originalEvent.detail ? event.originalEvent.detail.value : "";

    if (!action) {
      return;
    }

    var ids = $("[data-subscrpt-shipments] .wpsubs-row-check:checked")
      .map(function () {
        return $(this).val();
      })
      .get();

    if (!ids.length) {
      notice(i18n.selectShipments || "Tick at least one box first.", true);
      return;
    }

    api("POST", "/shipments/bulk", { ids: ids, action: action })
      .then(function () {
        // Reload rather than repaint: the counts above the list and the
        // state filter both change with the rows.
        window.location.reload();
      })
      .catch(fail);
  });

  // ── Creating a box ───────────────────────────────────────────────────────

  var productNameTouched = false;

  /**
   * Show the product name field and the summary for the switch's state.
   *
   * @returns {void}
   */
  function syncCreate() {
    var sell = $("#subscrpt-create-box-sell").is(":checked");
    var $summary = $("[data-subscrpt-create-summary]");

    $("[data-subscrpt-create-product]").prop("hidden", !sell);
    $summary.text($summary.data(sell ? "with" : "without"));
  }

  $(document).on("change", "#subscrpt-create-box-sell", syncCreate);

  // The product is named after the box until someone names it themselves.
  $(document).on("input", "#subscrpt-create-box-name", function () {
    if (!productNameTouched) {
      $("#subscrpt-create-box-product").val($(this).val());
    }
  });

  $(document).on("input", "#subscrpt-create-box-product", function () {
    productNameTouched = true;
  });

  $(document).on("click", "[data-subscrpt-create-box]", function () {
    var $button = $(this);
    var title = ($("#subscrpt-create-box-name").val() || "").trim();
    var sell = $("#subscrpt-create-box-sell").is(":checked");

    if (!title) {
      notice(i18n.nameRequired, true);
      $("#subscrpt-create-box-name").trigger("focus");
      return;
    }

    $button.prop("disabled", true);

    api("POST", "", {
      title: title,
      type: $('input[name="subscrpt-create-box-type"]:checked').val() || "build",
      create_product: sell,
      product_name: ($("#subscrpt-create-box-product").val() || "").trim() || title,
    })
      .then(function (box) {
        // Straight into the new box: the next thing to do is say what goes
        // in it, and that is the Box items tab.
        window.location.href = box.edit_url || cfg.listUrl;
      })
      .catch(function (error) {
        $button.prop("disabled", false);
        fail(error);
      });
  });

  // ── Deleting ─────────────────────────────────────────────────────────────

  /**
   * Word the confirm button for the choice made.
   *
   * @param {jQuery} $modal The delete dialog.
   * @returns {void}
   */
  function syncDelete($modal) {
    var hasProduct = !!$modal.data("product");
    var choice = $modal.find('input[name="subscrpt-delete-product"]:checked').val();
    var label = !hasProduct ? i18n.deleteOnly : "trash" === choice ? i18n.deleteTrash : i18n.deleteKeep;

    $modal.find("[data-subscrpt-delete-confirm]").text(label || "");
  }

  $(document).on("click", "[data-subscrpt-delete-open]", function (event) {
    event.stopPropagation();
    closeMenus("");

    var $trigger = $(this);
    var $modal = $("[data-subscrpt-delete-modal]");
    var product = $trigger.data("product-name") || "";
    var subs = parseInt($trigger.data("live-subs"), 10) || 0;
    var initials = String(product)
      .split(/\s+/)
      .slice(0, 2)
      .map(function (word) {
        return word.charAt(0).toUpperCase();
      })
      .join("");

    $modal.data("box", $trigger.data("subscrpt-delete-open")).data("product", product);
    $modal.find("[data-subscrpt-delete-title]").text(format(i18n.deleteTitle, [$trigger.data("box-name")]));
    $modal.find("[data-subscrpt-delete-product]").text(product);
    $modal.find("[data-subscrpt-delete-product-meta]").text($trigger.data("product-meta") || "");
    $modal.find("[data-subscrpt-delete-initials]").text(initials);
    $modal.find("[data-subscrpt-delete-product-section]").prop("hidden", !product);

    $modal
      .find("[data-subscrpt-delete-subs]")
      .prop("hidden", 0 === subs)
      .text(1 === subs ? i18n.deleteSubsOne : format(i18n.deleteSubs, [subs]));

    // Live subscriptions need the product to bill, so it cannot be trashed.
    $modal.find("[data-subscrpt-delete-trash]").prop("hidden", subs > 0);
    $modal.find("[data-subscrpt-delete-locked]").prop("hidden", 0 === subs);
    $modal
      .find('input[name="subscrpt-delete-product"][value="' + (subs > 0 ? "draft" : "trash") + '"]')
      .prop("checked", true)
      .trigger("change");

    syncDelete($modal);
    window.WPSubsModal.open($modal[0]);
  });

  $(document).on("change", 'input[name="subscrpt-delete-product"]', function () {
    syncDelete($(this).closest("[data-subscrpt-delete-modal]"));
  });

  $(document).on("click", "[data-subscrpt-delete-confirm]", function () {
    var $button = $(this);
    var $modal = $button.closest("[data-subscrpt-delete-modal]");
    var choice = $modal.find('input[name="subscrpt-delete-product"]:checked').val() || "draft";

    $button.prop("disabled", true);

    api("DELETE", "/" + $modal.data("box"), { product: choice })
      .then(function () {
        dirty = false;
        reloadWith(i18n.boxDeleted, currentBox() ? cfg.listUrl : "");
      })
      .catch(function (error) {
        $button.prop("disabled", false);
        fail(error);
      });
  });

  // ── The header ───────────────────────────────────────────────────────────

  $(document).on("click", "[data-subscrpt-box-rename-open]", function () {
    $("[data-subscrpt-box-rename-display], [data-subscrpt-box-rename-open]").hide();
    $("[data-subscrpt-box-rename-form]").prop("hidden", false).find("input").trigger("focus");
  });

  $(document).on("click", "[data-subscrpt-box-rename-cancel]", function () {
    $("[data-subscrpt-box-rename-form]").prop("hidden", true);
    $("[data-subscrpt-box-rename-display], [data-subscrpt-box-rename-open]").show();
  });

  $(document).on("keydown", "[data-subscrpt-box-rename-input]", function (event) {
    if ("Enter" === event.key) {
      $("[data-subscrpt-box-rename-save]").trigger("click");
    }
  });

  $(document).on("click", "[data-subscrpt-box-rename-save]", function () {
    var title = ($("[data-subscrpt-box-rename-input]").val() || "").trim();

    if (!title) {
      notice(i18n.nameRequired, true);
      return;
    }

    api("PUT", "/" + currentBox(), { title: title })
      .then(function () {
        reloadWith(i18n.saved);
      })
      .catch(fail);
  });

  // Publishing a box that is not ready opens the list of what is missing
  // instead; the server checks again, so a stale page cannot publish either.
  $(document).on("click", "[data-subscrpt-publish]", function (event) {
    event.stopPropagation();

    var $button = $(this);
    var status = $button.data("subscrpt-publish");

    if ("active" === status && parseInt($button.data("missing"), 10) > 0) {
      toggleMenu("publish", $button);
      return;
    }

    $button.prop("disabled", true);

    api("POST", "/" + currentBox() + "/publish", { status: status })
      .then(function () {
        reloadWith("active" === status ? i18n.published : i18n.drafted);
      })
      .catch(function (error) {
        $button.prop("disabled", false);

        if (error.data && error.data.data && error.data.data.missing) {
          // The page was stale; reloading shows the current list.
          reloadWith(error.message);
          return;
        }

        fail(error);
      });
  });

  // "Link a product" has nowhere to go but the Selling panel beside it.
  $(document).on("click", "[data-subscrpt-fix-product]", function (event) {
    event.stopPropagation();
    closeMenus("");

    var $card = $("#subscrpt-box-prodcard");
    var $toggle = $('[data-subscrpt-menu-toggle="product"]');

    if ($card[0]) {
      $card[0].scrollIntoView({ block: "nearest", behavior: "smooth" });
      $card.addClass("is-flash");
      window.setTimeout(function () {
        $card.removeClass("is-flash");
      }, 1600);
    }

    if ($toggle.length) {
      toggleMenu("product", $toggle);
    }
  });

  $(document).on("click", "[data-subscrpt-duplicate]", function () {
    api("POST", "/" + currentBox() + "/duplicate")
      .then(function (box) {
        reloadWith(i18n.duplicated, box.edit_url);
      })
      .catch(fail);
  });

  // ── The product that sells the box ───────────────────────────────────────

  /**
   * Change the box's product, then reload.
   *
   * @param {Object} body    action, and product_id for "link".
   * @param {string} message What to say afterwards.
   * @returns {Promise} The request.
   */
  function changeProduct(body, message) {
    return api("POST", "/" + currentBox() + "/product", body)
      .then(function () {
        reloadWith(message);
      })
      .catch(fail);
  }

  $(document).on("click", "[data-subscrpt-product-action]", function () {
    var action = $(this).data("subscrpt-product-action");

    closeMenus("");
    changeProduct({ action: action }, "unlink" === action ? i18n.productUnlinked : i18n.productCreated);
  });

  $(document).on("wpsubs:modal:open", "#subscrpt-link-product", function () {
    $(document.body).trigger("wc-enhanced-select-init");
  });

  $(document).on("click", "[data-subscrpt-link-product-save]", function () {
    var productId = parseInt($("[data-subscrpt-link-product]").val(), 10);

    if (!productId) {
      notice(i18n.pickProduct, true);
      return;
    }

    $(this).prop("disabled", true);
    changeProduct({ action: "link", product_id: productId }, i18n.productLinked);
  });

  // ── Saving a tab ─────────────────────────────────────────────────────────

  /**
   * Read one field off the form.
   *
   * @param {jQuery} $field The [data-subscrpt-box-field] element.
   * @returns {*} Its value.
   */
  function fieldValue($field) {
    if ($field.is("[data-subscrpt-pool]")) {
      return poolIds($field);
    }

    if ($field.is(":checkbox")) {
      return $field.is(":checked") ? 1 : 0;
    }

    if ($field.is("select[multiple]")) {
      return ($field.val() || []).map(Number);
    }

    return $field.val();
  }

  /**
   * Collect the picks out of an item table.
   *
   * @param {jQuery} $table The [data-subscrpt-items] wrapper.
   * @returns {Array} Rows of product_id, variation_id, qty.
   */
  function collectItems($table) {
    return $table
      .find("[data-subscrpt-item-row]")
      .map(function () {
        var $row = $(this);

        return {
          product_id: parseInt($row.attr("data-product-id"), 10) || 0,
          variation_id: parseInt($row.attr("data-variation-id"), 10) || 0,
          qty: parseInt($row.find("[data-subscrpt-item-qty]").val(), 10) || 1,
        };
      })
      .get();
  }

  /**
   * Read the pricing tab into the config the REST route stores.
   *
   * One measure is read off the box, never off a tier: the server drops any
   * tier on a different measure than the first, so offering one per row would
   * silently lose tiers.
   *
   * @param {jQuery} $form The pricing form.
   * @returns {Object} strategy, base_price, tiers, excluded, messages.
   */
  function collectPricing($form) {
    var measure = $form.find("[data-subscrpt-pricing-measure]").val();

    return {
      strategy: $form.find("[data-subscrpt-pricing-strategy]:checked").val() || "fixed",
      base_price: parseFloat($form.find("[data-subscrpt-pricing-base]").val()) || 0,
      tiers: readTiers($form, measure).filter(function (tier) {
        return tier.threshold > 0;
      }),
      excluded: $form
        .find("[data-subscrpt-pricing-excluded]")
        .map(function () {
          return parseInt($(this).data("subscrpt-pricing-excluded"), 10);
        })
        .get(),
      messages: {
        progress: $form.find('[data-subscrpt-pricing-message="progress"]').val(),
        success: $form.find('[data-subscrpt-pricing-message="success"]').val(),
      },
    };
  }

  /**
   * The tier rows as they stand.
   *
   * @param {jQuery} $form   The pricing form.
   * @param {string} measure quantity | amount.
   * @returns {Array} Rows of measure, threshold, type, value.
   */
  function readTiers($form, measure) {
    return $form
      .find("[data-subscrpt-tier-list] [data-subscrpt-tier]")
      .map(function () {
        var $row = $(this);

        return {
          measure: measure,
          threshold: parseFloat($row.find("[data-subscrpt-tier-threshold]").val()) || 0,
          type: $row.find("[data-subscrpt-tier-type]").val(),
          value: parseFloat($row.find("[data-subscrpt-tier-value]").val()) || 0,
        };
      })
      .get();
  }

  $(document).on("click", "[data-subscrpt-box-save]", function () {
    var $button = $(this);
    var $form = $button.closest("[data-subscrpt-box-form]");
    var payload = {};

    $form.find("[data-subscrpt-box-field]").each(function () {
      var $field = $(this);
      var name = $field.data("subscrpt-box-field");

      // A radio group is one field: only the checked one speaks for it.
      if ($field.is(":radio") && !$field.is(":checked")) {
        return;
      }

      var value = fieldValue($field);

      // "pool.products" is the one nested field, and writing the nesting
      // out here keeps the markup declarative.
      if (name.indexOf(".") !== -1) {
        var parts = name.split(".");
        payload[parts[0]] = payload[parts[0]] || {};
        payload[parts[0]][parts[1]] = value;
        return;
      }

      payload[name] = value;
    });

    $form.find("[data-subscrpt-items]").each(function () {
      payload[$(this).data("subscrpt-items")] = collectItems($(this));
    });

    $form.filter("[data-subscrpt-pricing]").each(function () {
      payload.pricing = collectPricing($(this));
    });

    if (poolState) {
      payload.pool = poolState;
    }

    $button.prop("disabled", true);

    api("PUT", "/" + currentBox(), payload)
      .then(function () {
        dirty = false;
        reloadWith(i18n.saved);
      })
      .catch(function (error) {
        $button.prop("disabled", false);
        fail(error);
      });
  });

  // ── Pricing ──────────────────────────────────────────────────────────────

  /**
   * Show only the parts of the pricing tab the chosen strategy uses, the unit
   * that matches the measure, and a worked example of the tiers.
   *
   * @param {jQuery} $form The pricing form.
   * @returns {void}
   */
  function syncPricing($form) {
    var isSum = "sum" === $form.find("[data-subscrpt-pricing-strategy]:checked").val();
    var measure = $form.find("[data-subscrpt-pricing-measure]").val();

    $form.find("[data-subscrpt-pricing-sum]").prop("hidden", !isSum);
    $form.find("[data-subscrpt-measure-unit]").each(function () {
      $(this).prop("hidden", $(this).data("subscrpt-measure-unit") !== measure);
    });
    $form
      .find("[data-subscrpt-tier-empty]")
      .prop("hidden", $form.find("[data-subscrpt-tier-list] [data-subscrpt-tier]").length > 0);

    // Five items worth 60 is the example: small enough to follow, big enough
    // to reach a first tier.
    var worth = 60;
    var reached = "amount" === measure ? worth : 5;
    var base = parseFloat($form.find("[data-subscrpt-pricing-base]").val()) || 0;
    var best = 0;

    readTiers($form, measure).forEach(function (tier) {
      if (tier.threshold > 0 && reached >= tier.threshold) {
        best = Math.max(best, "percent" === tier.type ? (worth * Math.min(100, tier.value)) / 100 : tier.value);
      }
    });

    var subject =
      "amount" === measure ? format(i18n.exampleAmount, [money(worth)]) : format(i18n.exampleItems, [5, money(worth)]);
    var pays = money(Math.max(0, worth - best) + base);
    var text = best
      ? format(i18n.exampleTier, [subject, money(best), "\u0000" + pays + "\u0001"])
      : format(i18n.exampleNone, [subject, "\u0000" + pays + "\u0001"]);

    if (base) {
      text += " " + format(i18n.exampleBase, [money(base)]);
    }

    // The total is the point of the example, so it is the bold part.
    var $example = $form.find("[data-subscrpt-pricing-example]").empty();
    var parts = text.split(/[\u0000\u0001]/);

    $example.append(document.createTextNode(parts[0] || ""));
    $example.append($("<b>").text(parts[1] || ""));
    $example.append(document.createTextNode(parts[2] || ""));
  }

  $(document).on(
    "change input",
    "[data-subscrpt-pricing-strategy], [data-subscrpt-pricing-measure], [data-subscrpt-pricing-base], [data-subscrpt-tier] :input",
    function () {
      syncPricing($(this).closest("[data-subscrpt-pricing]"));
    },
  );

  $(document).on("click", "[data-subscrpt-tier-add]", function () {
    var $form = $(this).closest("[data-subscrpt-pricing]");
    var template = $form.find("[data-subscrpt-tier-template]")[0];
    var $list = $form.find("[data-subscrpt-tier-list]");
    var $last = $list.find("[data-subscrpt-tier]").last();

    $list.append(document.importNode(template.content, true));

    // A new tier starts a step beyond the last one rather than empty.
    if ($last.length) {
      var $row = $list.find("[data-subscrpt-tier]").last();

      $row
        .find("[data-subscrpt-tier-threshold]")
        .val((parseFloat($last.find("[data-subscrpt-tier-threshold]").val()) || 0) + 5);
      $row
        .find("[data-subscrpt-tier-value]")
        .val((parseFloat($last.find("[data-subscrpt-tier-value]").val()) || 0) + 2);
      $row.find("[data-subscrpt-tier-type]").val($last.find("[data-subscrpt-tier-type]").val());
    }

    syncPricing($form);
    markDirty();
  });

  $(document).on("click", "[data-subscrpt-tier-remove]", function () {
    var $form = $(this).closest("[data-subscrpt-pricing]");

    $(this).closest("[data-subscrpt-tier]").remove();
    syncPricing($form);
    markDirty();
  });

  $(document).on("change", "[data-subscrpt-pricing-excluded-add]", function () {
    var $select = $(this);
    var id = parseInt($select.val(), 10);
    var $list = $("[data-subscrpt-pricing-excluded-list]");

    if (!id) {
      return;
    }

    if (!$list.find('[data-subscrpt-pricing-excluded="' + id + '"]').length) {
      var $chip = $('<span class="subscrpt-box-chip"></span>')
        .attr("data-subscrpt-pricing-excluded", id)
        .text($select.find("option:selected").text().trim());

      $chip.append(
        $('<button type="button" data-subscrpt-pricing-excluded-remove>&times;</button>').attr(
          "aria-label",
          i18n.remove || "Remove",
        ),
      );
      $list.find("[data-subscrpt-pricing-excluded-empty]").prop("hidden", true).before($chip);
    }

    $select.val(null).trigger("change.select2");
    markDirty();
  });

  $(document).on("click", "[data-subscrpt-pricing-excluded-remove]", function () {
    var $list = $(this).closest("[data-subscrpt-pricing-excluded-list]");

    $(this).closest("[data-subscrpt-pricing-excluded]").remove();
    $list
      .find("[data-subscrpt-pricing-excluded-empty]")
      .prop("hidden", $list.find("[data-subscrpt-pricing-excluded]").length > 0);
    markDirty();
  });

  // ── Rules and Together ───────────────────────────────────────────────────

  /**
   * Show the options that only matter while a switch is on.
   *
   * @param {jQuery} $toggle A [data-subscrpt-rule-toggle].
   * @returns {void}
   */
  function syncRule($toggle) {
    $toggle
      .closest("[data-subscrpt-rule]")
      .find("[data-subscrpt-rule-sub]")
      .first()
      .prop("hidden", !$toggle.is(":checked"));
  }

  $(document).on("change", "[data-subscrpt-rule-toggle]", function () {
    syncRule($(this));
  });

  $(document).on("change", "[data-subscrpt-together-toggle]", function () {
    var on = $(this).is(":checked");
    var $state = $("[data-subscrpt-together-state]");

    $("[data-subscrpt-together-position]").prop("hidden", !on);
    $state.text($state.data(on ? "on" : "off"));
  });

  // ── Durations ────────────────────────────────────────────────────────────

  var $durations = function () {
    return $("[data-subscrpt-durations]");
  };

  /**
   * Open the duration form, empty or filled from a row.
   *
   * @param {Object|null} duration The row's duration, or null to add one.
   * @returns {void}
   */
  function openDurationForm(duration) {
    var $form = $durations().find("[data-subscrpt-duration-form]");
    var $submit = $form.find("[data-subscrpt-duration-submit]");
    var field = function (name) {
      return $form.find('[data-duration-field="' + name + '"]');
    };

    field("id").val(duration ? duration.id : "");
    field("name").val(duration ? duration.name : "");
    field("every").val(duration ? duration.every : 1);
    field("unit").val(duration ? duration.unit : "month");
    field("price").val(duration && "" !== duration.price ? duration.price : "");
    field("trial").val(duration && duration.trial ? duration.trial : "");
    field("fee").val(duration && duration.fee ? duration.fee : "");

    $submit.text($submit.data(duration ? "save" : "add"));
    $form.prop("hidden", false);
    $durations().find("[data-subscrpt-duration-add-row]").prop("hidden", true);

    // An edited row moves the form under itself, so it reads as that row's.
    var $anchor = duration ? $('[data-subscrpt-duration="' + duration.id + '"]') : $();

    if ($anchor.length) {
      $anchor.after($form);
    } else {
      $durations().find("[data-subscrpt-duration-add-row]").before($form);
    }

    field("name").trigger("focus");
  }

  $(document).on("click", "[data-subscrpt-duration-add]", function () {
    openDurationForm(null);
  });

  $(document).on("click", "[data-subscrpt-duration-edit]", function () {
    openDurationForm($(this).closest("[data-subscrpt-duration]").data("duration"));
  });

  $(document).on("click", "[data-subscrpt-duration-cancel]", function () {
    $durations().find("[data-subscrpt-duration-form]").prop("hidden", true);
    $durations().find("[data-subscrpt-duration-add-row]").prop("hidden", false);
  });

  $(document).on("submit", "[data-subscrpt-duration-form]", function (event) {
    event.preventDefault();

    var $form = $(this);
    var value = function (name) {
      return $form.find('[data-duration-field="' + name + '"]').val();
    };
    var id = parseInt(value("id"), 10) || 0;
    var body = {
      name: (value("name") || "").trim(),
      every: parseInt(value("every"), 10) || 1,
      unit: value("unit") || "month",
      trial: parseInt(value("trial"), 10) || 0,
      fee: parseFloat(value("fee")) || 0,
    };

    if (!$form.find('[data-duration-field="price"]').is(":disabled")) {
      body.price = value("price");
    }

    $form.find("[data-subscrpt-duration-submit]").prop("disabled", true);

    api(id ? "PUT" : "POST", "/" + currentBox() + "/durations" + (id ? "/" + id : ""), body)
      .then(function () {
        reloadWith(id ? i18n.durationSaved : i18n.durationAdded);
      })
      .catch(function (error) {
        $form.find("[data-subscrpt-duration-submit]").prop("disabled", false);
        fail(error);
      });
  });

  $(document).on("change", "[data-subscrpt-duration-toggle]", function () {
    var $toggle = $(this);
    var id = $toggle.closest("[data-subscrpt-duration]").data("subscrpt-duration");

    $toggle.prop("disabled", true);

    api("PUT", "/" + currentBox() + "/durations/" + id, { on: $toggle.is(":checked") })
      .then(function () {
        reloadWith(i18n.durationSaved);
      })
      .catch(function (error) {
        $toggle.prop("disabled", false).prop("checked", !$toggle.is(":checked"));
        fail(error);
      });
  });

  $(document).on("click", "[data-subscrpt-duration-delete]", function () {
    var id = $(this).closest("[data-subscrpt-duration]").data("subscrpt-duration");

    if (!window.confirm(i18n.confirmDuration)) {
      return;
    }

    api("DELETE", "/" + currentBox() + "/durations/" + id)
      .then(function () {
        reloadWith(i18n.durationRemoved);
      })
      .catch(fail);
  });

  // This box's own durations, or a shared plan's. Choosing "shared" only opens
  // the picker; nothing changes until a plan is chosen.
  $(document).on("click", "[data-subscrpt-duration-mode]", function () {
    var mode = $(this).data("subscrpt-duration-mode");

    if ("own" === mode && "shared" === $durations().data("mode")) {
      api("POST", "/" + currentBox() + "/durations/source", { mode: "own" })
        .then(function () {
          reloadWith(i18n.ownDurations);
        })
        .catch(fail);
      return;
    }

    $("[data-subscrpt-duration-mode]").attr("aria-pressed", "false");
    $(this).attr("aria-pressed", "true");
    $("[data-subscrpt-shared-picker]").prop("hidden", "shared" !== mode);
  });

  $(document).on("click", "[data-subscrpt-shared-use]", function () {
    var groupId = parseInt($("[data-subscrpt-shared-plan]").val(), 10);

    if (!groupId) {
      notice(i18n.pickPlan, true);
      return;
    }

    api("POST", "/" + currentBox() + "/durations/source", { mode: "shared", group_id: groupId })
      .then(function () {
        reloadWith(i18n.planLinked);
      })
      .catch(fail);
  });

  // ── The pool: where a build-your-own box's items come from ───────────────

  var poolState = null;
  var poolView = { search: "", category: 0, view: "all", page: 1 };
  var poolLast = null;
  var poolRequest = 0;
  var poolTimer;

  /**
   * The pool editor, when this tab has one.
   *
   * @returns {jQuery} The [data-subscrpt-pool-editor].
   */
  function $poolEditor() {
    return $("[data-subscrpt-pool-editor]");
  }

  /**
   * Say in words what is in the box, and show the controls the source uses.
   *
   * @returns {void}
   */
  function syncPoolSource() {
    var $editor = $poolEditor();
    var rules = $editor.data("rules") || {};
    var names = $editor.data("category-names") || {};
    var source = poolState.source;
    var isProducts = "products" === source;

    $editor.find("[data-subscrpt-pool-when]").each(function () {
      $(this).prop("hidden", $(this).data("subscrpt-pool-when") !== source);
    });
    $editor.find("[data-subscrpt-pool-hide-products]").prop("hidden", isProducts);

    var $rule = $editor.find("[data-subscrpt-pool-rule]");

    if ("categories" === source) {
      var chosen = poolState.categories
        .map(function (id) {
          return names[id];
        })
        .filter(Boolean);

      if (!chosen.length) {
        $rule.text(i18n.pickCategory || "");
      } else {
        var label = chosen.length > 3 ? format(i18n.catsSelected, [chosen.length]) : chosen.join(", ");
        var parts = String(rules.categories || "%s").split("%s");

        $rule
          .empty()
          .append(document.createTextNode(parts[0] || ""))
          .append($("<b>").text(label))
          .append(document.createTextNode(parts[1] || ""));
      }
    } else {
      $rule.text(rules[source] || "");
    }

    $editor.find("[data-subscrpt-pool-cat-count]").text(format(i18n.catsSelected, [poolState.categories.length]));
    $editor
      .find("[data-subscrpt-pool-chosen-count]")
      .text(1 === poolState.products.length ? i18n.chosenOne : format(i18n.chosenCount, [poolState.products.length]));
  }

  /**
   * Fetch and draw the page of the pool the filters ask for.
   *
   * @returns {void}
   */
  function loadPool() {
    var request = ++poolRequest;
    var $editor = $poolEditor();

    $editor.find("[data-subscrpt-pool-rows]").css("opacity", 0.6);

    api("POST", "/pool", {
      pool: poolState,
      search: poolView.search,
      category: poolView.category,
      view: "products" === poolState.source ? "all" : poolView.view,
      page: poolView.page,
    })
      .then(function (data) {
        if (request !== poolRequest) {
          return;
        }

        poolLast = data;

        // The server names variations where the pool named their product.
        if (data.pool) {
          poolState.products = data.pool.products.map(Number);
          poolState.exclude = data.pool.exclude.map(Number);
          syncPoolSource();
        }

        renderPool(data);
      })
      .catch(function (error) {
        if (request === poolRequest) {
          $editor.find("[data-subscrpt-pool-rows]").css("opacity", 1);
          fail(error);
        }
      });
  }

  /**
   * Draw one page of the pool.
   *
   * @param {Object} data rows, total, in, out, matching, matching_in, categories.
   * @returns {void}
   */
  function renderPool(data) {
    var $editor = $poolEditor();
    var isProducts = "products" === poolState.source;
    var $rows = $editor.find("[data-subscrpt-pool-rows]");
    var units = undefined === data.units ? data.total : data.units;
    var pages = Math.max(1, Math.ceil(units / 10));
    var open = {};

    // A product that was open stays open across the redraw.
    $rows.find("[data-subscrpt-pool-toggle]").each(function () {
      open[$(this).data("subscrpt-pool-toggle")] = "true" === $(this).attr("aria-expanded");
    });
    $rows.empty().css("opacity", 1);

    if (poolView.page > pages) {
      poolView.page = pages;
      loadPool();
      return;
    }

    $editor.find("[data-subscrpt-pool-in]").text(data["in"]);
    $editor.find("[data-subscrpt-pool-out]").text(data.out);
    $editor.find('[data-subscrpt-pool-view-count="all"]').text(data["in"] + data.out);
    $editor.find('[data-subscrpt-pool-view-count="in"]').text(data["in"]);
    $editor.find('[data-subscrpt-pool-view-count="out"]').text(data.out);
    $editor
      .find("[data-subscrpt-pool-search]")
      .attr("placeholder", format(i18n.searchCount || "%d", [data["in"] + data.out]));

    // The category filter offers only the categories this pool spans.
    var $category = $editor.find("[data-subscrpt-pool-category]");
    var current = String(poolView.category || "");

    $category.find("option:not(:first)").remove();
    (data.categories || []).forEach(function (cat) {
      $category.append($("<option>").val(cat.id).text(cat.name));
    });
    $category.val(current).prop("hidden", (data.categories || []).length < 2 && !poolView.category);

    var groups = [];
    var byParent = {};

    data.rows.forEach(function (row) {
      var parentId = parseInt(row.parent_id, 10) || 0;

      if (!parentId) {
        groups.push({ row: row });
        return;
      }

      if (!byParent[parentId]) {
        byParent[parentId] = { parentId: parentId, rows: [] };
        groups.push(byParent[parentId]);
      }

      byParent[parentId].rows.push(row);
    });

    groups.forEach(function (group) {
      $rows.append(
        group.row
          ? poolListRow(group.row, isProducts)
          : poolListGroup(group, isProducts, !!poolView.search || !!open[group.parentId]),
      );
    });

    if (!data.rows.length) {
      $rows.append(
        $('<div class="subscrpt-box-prow subscrpt-box-prow--empty"></div>').text(
          "out" === poolView.view && !isProducts ? i18n.noneLeftOut : i18n.noMatch,
        ),
      );
    }

    var first = units ? (poolView.page - 1) * 10 + 1 : 0;

    $editor
      .find("[data-subscrpt-pool-showing]")
      .text(units ? format(i18n.showing, [first, first + groups.length - 1, units]) : i18n.zeroProducts);
    $editor.find("[data-subscrpt-pool-pages]").text(format(i18n.pageOf, [poolView.page, pages]));
    $editor.find('[data-subscrpt-pool-page="-1"]').prop("disabled", poolView.page <= 1);
    $editor.find('[data-subscrpt-pool-page="1"]').prop("disabled", poolView.page >= pages);

    // Bulk only once the list is narrowed, so it never means "the whole shop".
    var narrowed = !isProducts && (poolView.search || poolView.category) && data.total;
    var $bulk = $editor.find("[data-subscrpt-pool-bulk]").prop("hidden", !narrowed);

    if (narrowed) {
      $bulk
        .data("mode", data.matching_in ? "out" : "in")
        .text(
          data.matching_in ? format(i18n.leaveOutThese, [data.matching_in]) : format(i18n.putTheseBack, [data.total]),
        );
    }
  }

  /**
   * One product in the pool list.
   *
   * @param {Object}  row        As BoxPool::row() returns it, plus `out`. `id` may be a comma list.
   * @param {boolean} isProducts Whether the pool is chosen products.
   * @param {jQuery}  [$aside]   Shown in place of the price.
   * @returns {jQuery} The row.
   */
  function poolListRow(row, isProducts, $aside) {
    var $row = $('<div class="subscrpt-box-prow"></div>').toggleClass("is-out", !!row.out);
    var $control;

    if (isProducts) {
      $control = $('<button type="button" class="wpsubs-icon-action wpsubs-icon-action--danger"></button>')
        .attr({ "data-subscrpt-pool-remove-id": row.id, "aria-label": format(i18n.removeLabel, [row.name]) })
        .append('<span class="dashicons dashicons-no-alt" aria-hidden="true"></span>');
    } else {
      $control = $('<label class="subscrpt-box-switch"></label>')
        .append(
          $('<input type="checkbox" class="wpsubs-toggle" />')
            .attr({ "data-subscrpt-pool-exclude": row.id, "aria-label": format(i18n.inBoxLabel, [row.name]) })
            .prop("checked", !row.out),
        )
        .append('<span class="wpsubs-toggle-ui" aria-hidden="true"></span>');
    }

    var $thumb = $('<span class="subscrpt-box-thumb"></span>');

    if (row.image) {
      $thumb.append($('<img alt="">').attr("src", row.image));
    } else {
      $thumb.text((row.name || "?").charAt(0).toUpperCase());
    }

    var $name = $('<span class="subscrpt-box-prow__name"></span>').text(row.name);

    if (row.out) {
      $name.append($('<span class="subscrpt-box-lo"></span>').text(i18n.leftOutBadge));
    }

    var meta = [row.category, row.stock].filter(Boolean).join(" · ");

    return $row
      .append($control)
      .append($thumb)
      .append(
        $('<span class="subscrpt-box-prow__text"></span>')
          .append($name)
          .append($('<span class="subscrpt-box-prow__meta"></span>').text(meta)),
      )
      .append($aside || $('<span class="subscrpt-box-prow__price"></span>').text(row.price || ""))
      .append(
        $('<a class="wpsubs-icon-action" target="_blank" rel="noopener"></a>')
          .attr({ href: row.edit_url, "aria-label": i18n.openProduct })
          .append('<span class="dashicons dashicons-external" aria-hidden="true"></span>'),
      );
  }

  /**
   * A variable product in the pool list, its variations folded beneath it.
   *
   * Its switch, or its remove button, acts on every variation it lists.
   *
   * @param {Object}  group      parentId, and the rows of its variations.
   * @param {boolean} isProducts Whether the pool is chosen products.
   * @param {boolean} open       Whether its variations show.
   * @returns {jQuery} The group.
   */
  function poolListGroup(group, isProducts, open) {
    var first = group.rows[0];
    var count = group.rows.length;
    var inBox = group.rows.filter(function (row) {
      return !row.out;
    }).length;
    var $toggle = poolToggle(group.parentId, open);

    $toggle.find("span").text(format(i18n.variations, [count]));

    var $head = poolListRow(
      {
        id: group.rows
          .map(function (row) {
            return row.id;
          })
          .join(","),
        name: first.parent_name,
        image: first.image,
        category: first.category,
        stock: isProducts || !inBox || inBox === count ? "" : format(i18n.variantsIn, [inBox, count]),
        out: !inBox,
        edit_url: first.edit_url,
      },
      isProducts,
      $toggle,
    );

    var $panel = $("<div data-subscrpt-pool-panel></div>").prop("hidden", !open);

    group.rows.forEach(function (row) {
      $panel.append(poolListRow(row, isProducts).addClass("subscrpt-box-prow--child"));
    });

    return $("<div>").attr("data-subscrpt-pool-group", group.parentId).append($head).append($panel);
  }

  /**
   * The ids a pool row's control acts on.
   *
   * @param {number|string} value One id, or a comma list.
   * @returns {number[]} The ids.
   */
  function poolControlIds(value) {
    return String(value)
      .split(",")
      .map(function (id) {
        return parseInt(id, 10);
      })
      .filter(Boolean);
  }

  /**
   * Note a change to the pool: count it as unsaved, redraw the words, refetch.
   *
   * @returns {void}
   */
  function poolChanged() {
    markDirty();
    syncPoolSource();
    loadPool();
  }

  $(document).on("change", "[data-subscrpt-pool-source]", function () {
    poolState.source = $(this).val();
    poolView = { search: "", category: 0, view: "all", page: 1 };
    $poolEditor().find("[data-subscrpt-pool-search]").val("");
    $poolEditor()
      .find("[data-subscrpt-pool-view]")
      .attr("aria-pressed", "false")
      .filter('[data-subscrpt-pool-view="all"]')
      .attr("aria-pressed", "true");
    poolChanged();
  });

  $(document).on("change", "[data-subscrpt-pool-cat]", function () {
    var id = parseInt($(this).data("subscrpt-pool-cat"), 10);

    poolState.categories = poolState.categories.filter(function (cat) {
      return cat !== id;
    });

    if (this.checked) {
      poolState.categories.push(id);
    }

    $(this).closest(".subscrpt-box-cat").toggleClass("is-on", this.checked);
    poolView.category = 0;
    poolView.page = 1;
    poolChanged();
  });

  $(document).on("input", "[data-subscrpt-pool-cat-find]", function () {
    var term = ($(this).val() || "").toLowerCase().trim();

    $poolEditor()
      .find(".subscrpt-box-cat")
      .each(function () {
        $(this).prop("hidden", !!term && String($(this).data("name")).indexOf(term) === -1);
      });
  });

  $(document).on("input", "[data-subscrpt-pool-search]", function () {
    var value = ($(this).val() || "").trim();

    window.clearTimeout(poolTimer);
    poolTimer = window.setTimeout(function () {
      poolView.search = value;
      poolView.page = 1;
      loadPool();
    }, 250);
  });

  $(document).on("change", "[data-subscrpt-pool-category]", function () {
    poolView.category = parseInt($(this).val(), 10) || 0;
    poolView.page = 1;
    loadPool();
  });

  $(document).on("click", "[data-subscrpt-pool-view]", function () {
    $poolEditor().find("[data-subscrpt-pool-view]").attr("aria-pressed", "false");
    $(this).attr("aria-pressed", "true");
    poolView.view = $(this).data("subscrpt-pool-view");
    poolView.page = 1;
    loadPool();
  });

  $(document).on("click", "[data-subscrpt-pool-page]", function () {
    poolView.page = Math.max(1, poolView.page + parseInt($(this).data("subscrpt-pool-page"), 10));
    loadPool();
  });

  $(document).on("change", "[data-subscrpt-pool-exclude]", function () {
    var ids = poolControlIds($(this).attr("data-subscrpt-pool-exclude"));

    poolState.exclude = poolState.exclude.filter(function (excluded) {
      return -1 === ids.indexOf(excluded);
    });

    if (!this.checked) {
      poolState.exclude = poolState.exclude.concat(ids);
    }

    poolChanged();
  });

  $(document).on("click", "[data-subscrpt-pool-remove-id]", function () {
    var ids = poolControlIds($(this).attr("data-subscrpt-pool-remove-id"));

    poolState.products = poolState.products.filter(function (product) {
      return -1 === ids.indexOf(product);
    });
    poolChanged();
  });

  $(document).on("click", "[data-subscrpt-pool-bulk]", function () {
    var mode = $(this).data("mode");
    var matching = (poolLast && poolLast.matching) || [];
    var before = poolState.exclude.length;
    var excluded = {};

    poolState.exclude.forEach(function (id) {
      excluded[id] = true;
    });

    matching.forEach(function (id) {
      if ("out" === mode) {
        excluded[id] = true;
      } else {
        delete excluded[id];
      }
    });

    poolState.exclude = Object.keys(excluded).map(Number);
    notice(format("out" === mode ? i18n.leftOut : i18n.putBack, [Math.abs(poolState.exclude.length - before)]));
    poolChanged();
  });

  $(document).on("change", "[data-subscrpt-pool-virtual]", function () {
    poolState.virtual = this.checked;
    poolView.page = 1;
    poolChanged();
  });

  // ── Boot ─────────────────────────────────────────────────────────────────

  $(function () {
    try {
      var flash = window.sessionStorage.getItem(FLASH);

      if (null !== flash) {
        window.sessionStorage.removeItem(FLASH);

        if (flash) {
          notice(flash);
        }
      }
    } catch (e) {
      // No storage, no message.
    }

    $("[data-subscrpt-browse]").each(function () {
      renderBrowse($(this));
    });

    $("[data-subscrpt-pricing]").each(function () {
      syncPricing($(this));
    });

    $("[data-subscrpt-rule-toggle]").each(function () {
      syncRule($(this));
    });

    syncCreate();

    if ($poolEditor().length) {
      poolState = $poolEditor().data("pool");
      poolState.products = (poolState.products || []).map(Number);
      poolState.categories = (poolState.categories || []).map(Number);
      poolState.exclude = (poolState.exclude || []).map(Number);
      syncPoolSource();
      loadPool();
    }

    $("[data-subscrpt-pool]").each(function () {
      syncPool($(this));
    });

    $("[data-subscrpt-items]").each(function () {
      syncItemAdd($(this).data("subscrpt-items"));
    });
  });

  // ── Item rows ────────────────────────────────────────────────────────────

  $(document).on("click", "[data-subscrpt-item-remove]", function () {
    var $body = $(this).closest("[data-subscrpt-item-body]");

    $(this).closest("[data-subscrpt-item-row]").remove();
    $body.find("[data-subscrpt-item-empty]").prop("hidden", $body.find("[data-subscrpt-item-row]").length > 0);
    syncItemAdd($body.closest("[data-subscrpt-items]").data("subscrpt-items"));
  });

  /**
   * Hold "Add product" while the table already has a row with no product.
   *
   * One blank row at a time: a second would only be another empty line to
   * fill or remove, and a blank row is dropped on save anyway.
   *
   * @param {string} field defaults | items.
   * @returns {void}
   */
  function syncItemAdd(field) {
    var $blank = $('[data-subscrpt-items="' + field + '"]').find('[data-subscrpt-item-row][data-product-id="0"]');

    $('[data-subscrpt-item-add="' + field + '"]')
      .prop("disabled", $blank.length > 0)
      .attr("title", $blank.length ? i18n.pickFirst || "" : null);
  }

  // A repeater: each row picks its own product.
  $(document).on("click", "[data-subscrpt-item-add]", function () {
    var field = $(this).data("subscrpt-item-add");
    var template = $('[data-subscrpt-item-template="' + field + '"]')[0];
    var $body = $('[data-subscrpt-items="' + field + '"]').find("[data-subscrpt-item-body]");
    var $row = $(document.importNode(template.content, true)).children("tr");

    $body.find("[data-subscrpt-item-empty]").prop("hidden", true).before($row);

    // WooCommerce enhances only selects already in the page; this one is new.
    $(document.body).trigger("wc-enhanced-select-init");
    $row.find("[data-subscrpt-item-product]").selectWoo("open");
    syncItemAdd(field);
  });

  // The dropdown lives on <body>, outside the table; tag it so the CSS can reach it.
  $(document).on("select2:open", "[data-subscrpt-item-product]", function () {
    var instance = $(this).data("select2");

    if (instance && instance.$dropdown) {
      instance.$dropdown.find(".select2-dropdown").addClass("subscrpt-item-dropdown");
    }
  });

  // The row is saved as the picked id with no variation, as the dropdown
  // this replaces stored it. A row left alone keeps what it was saved with.
  $(document).on("change", "[data-subscrpt-item-product]", function () {
    var $row = $(this).closest("[data-subscrpt-item-row]");

    $row.attr("data-product-id", parseInt($(this).val(), 10) || 0).attr("data-variation-id", 0);
    syncItemAdd($row.closest("[data-subscrpt-items]").data("subscrpt-items"));
  });

  // ── Editions ─────────────────────────────────────────────────────────────

  // Keep a month's "N items" pill in step with its ticked chips.
  $(document).on("change", ".subscrpt-edition input[name='subscrpt_box_edition_contents[]']", function () {
    var $card = $(this).closest(".subscrpt-edition");
    var $count = $card.find("[data-subscrpt-edition-count]");
    var n = $card.find("input[name='subscrpt_box_edition_contents[]']:checked").length;

    $count.text(String($count.data(1 === n ? "one" : "many")).replace("%d", n));
  });

  // ── The pool and its picker ──────────────────────────────────────────────

  // ── The pool and its picker ──────────────────────────────────────────────

  /**
   * The product ids the pool list holds, in order.
   *
   * @param {jQuery} $pool The [data-subscrpt-pool] list.
   * @returns {number[]} Product or variation ids.
   */
  function poolIds($pool) {
    return $pool
      .find("[data-subscrpt-pool-item]")
      .map(function () {
        return parseInt($(this).data("subscrpt-pool-item"), 10);
      })
      .get();
  }

  /**
   * Say how many products the pool holds, or that it holds none.
   *
   * @param {jQuery} $pool The [data-subscrpt-pool] list.
   * @returns {void}
   */
  function syncPool($pool) {
    groupPool($pool);

    var n = $pool.find("[data-subscrpt-pool-item]").length;

    $pool.find("[data-subscrpt-pool-count]").text((i18n.poolCount || "%d products").replace("%d", n));
    $pool.find("[data-subscrpt-pool-empty]").prop("hidden", n > 0);
  }

  /**
   * A thumbnail, or the placeholder icon when the product has no image.
   *
   * @param {string} image Image URL.
   * @returns {jQuery} The thumbnail.
   */
  function poolThumb(image) {
    var $thumb = $("<span>").attr(
      "style",
      "flex:0 0 auto;width:32px;height:32px;border-radius:4px;background:var(--wpsubs-bg-subtle,#f1f2f4);border:1px solid var(--wpsubs-border);overflow:hidden;display:flex;align-items:center;justify-content:center;",
    );

    if (image) {
      $thumb.append(
        $("<img>")
          .attr({ src: image, alt: "" })
          .attr("style", "width:100%;height:100%;object-fit:cover;display:block;"),
      );
    } else {
      $thumb.append(
        '<span class="dashicons dashicons-format-image" style="font-size:16px;width:16px;height:16px;color:var(--wpsubs-text-subtle);"></span>',
      );
    }

    return $thumb;
  }

  /**
   * The chevron that opens a variable product's variations.
   *
   * Uses the accordion component's header look, not its script: that binds
   * once on load, and these rows are rebuilt on every change.
   *
   * @param {number} parentId The variable product.
   * @param {boolean} open    Whether it starts open.
   * @returns {jQuery} The button.
   */
  function poolToggle(parentId, open) {
    return $('<button type="button" class="wpsubs-accordion__header"><span></span></button>')
      .attr({ "data-subscrpt-pool-toggle": parentId, "aria-expanded": open ? "true" : "false" })
      .attr(
        "style",
        "width:auto;flex:0 0 auto;gap:6px;padding:4px 8px;border-radius:4px;background:none;font-size:12px;font-weight:400;color:var(--wpsubs-text-muted);",
      );
  }

  /**
   * One variable product in the pool list, its variations folded beneath it.
   *
   * @param {number}  parentId The variable product.
   * @param {string}  name     Its name.
   * @param {string}  image    A thumbnail.
   * @param {boolean} open     Whether its variations show.
   * @returns {jQuery} The group.
   */
  function poolGroup(parentId, name, image, open) {
    var $head = $("<div>")
      .attr("style", "display:flex;align-items:center;gap:10px;padding:8px 16px;")
      .append(poolThumb(image))
      .append(
        $("<span>")
          .attr(
            "style",
            "flex:1 1 auto;min-width:0;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;",
          )
          .text(name),
      )
      .append(poolToggle(parentId, open))
      .append(
        $(
          '<button type="button" class="wpsubs-btn wpsubs-btn--icon" data-subscrpt-pool-remove-group>&times;</button>',
        ).attr("aria-label", i18n.remove || "Remove"),
      );

    return $("<li>")
      .attr("data-subscrpt-pool-group", parentId)
      .attr("style", "margin:0;border-bottom:1px solid rgba(0,0,0,0.06);")
      .append($head)
      .append(
        $("<ul>")
          .attr("data-subscrpt-pool-panel", "")
          .attr(
            "style",
            "list-style:none;margin:0;padding:0;border-top:1px solid rgba(0,0,0,0.06);background:var(--wpsubs-surface-muted,#f9fafb);",
          )
          .prop("hidden", !open),
      );
  }

  /**
   * Fold the pool list's variations under their products.
   *
   * The rows stay the field — each variation is still its own
   * [data-subscrpt-pool-item] — so saving reads them exactly as before. A
   * group that was open stays open across the rebuild.
   *
   * @param {jQuery} $pool The [data-subscrpt-pool] list.
   * @returns {void}
   */
  function groupPool($pool) {
    var $list = $pool.find("[data-subscrpt-pool-list]");
    var open = {};
    var groups = {};

    $list.find("[data-subscrpt-pool-toggle]").each(function () {
      open[$(this).data("subscrpt-pool-toggle")] = "true" === $(this).attr("aria-expanded");
    });

    var $items = $list.find("[data-subscrpt-pool-item]").detach();

    $list.empty();

    $items.each(function () {
      var $item = $(this);
      var parentId = parseInt($item.attr("data-parent-id"), 10) || 0;

      $item.css("border-bottom", "1px solid rgba(0,0,0,0.06)");

      if (!parentId) {
        $item.css("padding-left", "16px");
        $list.append($item);
        return;
      }

      if (!groups[parentId]) {
        groups[parentId] = poolGroup(
          parentId,
          $item.attr("data-parent-name"),
          $item.find("img").attr("src"),
          !!open[parentId],
        );
        $list.append(groups[parentId]);
      }

      $item.css("padding-left", "58px");
      groups[parentId].find("[data-subscrpt-pool-panel]").append($item);
    });

    $.each(groups, function (parentId, $group) {
      var n = $group.find("[data-subscrpt-pool-item]").length;

      $group.find("[data-subscrpt-pool-toggle] span").text((i18n.variations || "%d variations").replace("%d", n));
      $group.find("[data-subscrpt-pool-item]").last().css("border-bottom", "none");
    });
  }

  /**
   * A row of the pool list, for a product the picker just added.
   *
   * @param {Object} p Product as /boxes/products returns it.
   * @returns {jQuery} The row.
   */
  function poolRow(p) {
    var $text = $("<span>")
      .attr("style", "flex:1 1 auto;min-width:0;display:flex;flex-direction:column;")
      .append(
        $("<span>")
          .attr("style", "font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;")
          .text(p.name),
      );

    if (p.sku) {
      $text.append($("<span>").attr("style", "font-size:12px;color:var(--wpsubs-text-subtle);").text(p.sku));
    }

    return $("<li>")
      .attr("data-subscrpt-pool-item", p.id)
      .attr("data-parent-id", p.parent_id || 0)
      .attr("data-parent-name", p.parent_name || "")
      .attr(
        "style",
        "margin:0;display:flex;align-items:center;gap:10px;padding:8px 16px;border-bottom:1px solid rgba(0,0,0,0.06);",
      )
      .append(poolThumb(p.image))
      .append($text)
      .append(
        $('<button type="button" class="wpsubs-btn wpsubs-btn--icon" data-subscrpt-pool-remove>&times;</button>').attr(
          "aria-label",
          i18n.remove || "Remove",
        ),
      );
  }

  /**
   * One row of the picker.
   *
   * A variable parent is a control only: it ticks its variations and carries
   * no id of its own, the way the Plans picker treats it. A product that sells
   * a box is shown but locked — a box inside a box would repeat at renewal.
   *
   * @param {Object}  p       Product or variation.
   * @param {Object}  opts    indent, control, locked.
   * @param {jQuery}  $modal  The picker.
   * @returns {jQuery} The row, with its checkbox at .data("cb").
   */
  function pickerRow(p, opts, $modal) {
    var selected = $modal.data("selected");
    var $cb = $('<input type="checkbox" class="wpsubs-checkbox" />').prop("disabled", !!opts.locked);

    if (!opts.control) {
      $cb.attr("data-subscrpt-pool-pick", p.id).prop("checked", !opts.locked && selected.has(p.id));
    }

    var $label = $("<label>")
      .attr("style", "display:flex;align-items:center;gap:10px;flex:1 1 auto;min-width:0;cursor:pointer;")
      .append($cb)
      .append(poolThumb(p.image))
      .append(
        $("<span>")
          .attr("style", "font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;")
          .text(p.name),
      );

    var note = opts.locked ? i18n.sellsBox : !opts.control && !p.available ? i18n.notForSale : "";

    if (note) {
      $label.append(
        $("<span>")
          .attr("style", "flex:0 0 auto;font-size:11px;font-style:italic;color:var(--wpsubs-text-subtle);")
          .text(note),
      );
    }

    var $li = $("<li>")
      .attr(
        "style",
        "margin:0;display:flex;align-items:center;gap:10px;padding:8px 4px;padding-left:" +
          (opts.indent ? "36px" : "4px") +
          ";border-bottom:1px solid rgba(0,0,0,0.06);",
      )
      .append($label)
      .append(
        $("<span>")
          .attr("style", "color:var(--wpsubs-text-muted);font-size:13px;flex:0 0 auto;")
          .text(p.price || ""),
      );

    if (opts.locked) {
      $li.css("opacity", "0.55");
      $label.css("cursor", "not-allowed");
    }

    return $li.data("cb", $cb);
  }

  /**
   * Tick a variable parent when all its variations are, half-tick it when some are.
   *
   * @param {jQuery} $parent   The parent's checkbox.
   * @param {jQuery} $children The variations' checkboxes.
   * @param {jQuery} $toggle   The parent's chevron, which says how many are ticked.
   * @returns {void}
   */
  function syncPickerParent($parent, $children, $toggle) {
    var on = $children.filter(":checked").length;

    $toggle
      .find("span")
      .text(
        on
          ? (i18n.variantsPicked || "%1$d of %2$d selected").replace("%1$d", on).replace("%2$d", $children.length)
          : (i18n.variations || "%d variations").replace("%d", $children.length),
      );

    $parent.prop("checked", on > 0 && on === $children.length);
    $parent.prop("indeterminate", on > 0 && on < $children.length);
  }

  /**
   * The footer tally and the select-all state, after any tick.
   *
   * The tally counts every pick, including ones the current search hides, so
   * it always says how the box will look once saved.
   *
   * @param {jQuery} $modal The picker.
   * @returns {void}
   */
  function syncPicker($modal) {
    var n = $modal.data("selected").size;
    var $boxes = $modal.find("[data-subscrpt-pool-pick]:enabled");
    var on = $boxes.filter(":checked").length;

    $modal.find("[data-subscrpt-pool-picker-count]").text((i18n.picked || "%d selected").replace("%d", n));
    $modal
      .find("[data-subscrpt-pool-picker-all]")
      .prop("disabled", 0 === $boxes.length)
      .prop("checked", $boxes.length > 0 && on === $boxes.length)
      .prop("indeterminate", on > 0 && on < $boxes.length);
  }

  /**
   * Fill the picker with a search.
   *
   * @param {jQuery} $modal The picker.
   * @param {string} search Search term.
   * @returns {void}
   */
  function loadPicker($modal, search) {
    var $list = $modal.find("[data-subscrpt-pool-picker-list]");
    var known = $modal.data("known");
    var message = function (text) {
      $list.html(
        $("<li>").attr("style", "padding:10px 4px;color:var(--wpsubs-text-subtle);font-size:13px;").text(text),
      );
    };
    var request = ($modal.data("request") || 0) + 1;

    // A slow search must not overwrite the answer to a later one.
    $modal.data("request", request);
    message(i18n.loading || "Loading…");

    api("GET", "/products?search=" + encodeURIComponent(search || ""))
      .then(function (data) {
        if ($modal.data("request") !== request) {
          return;
        }

        var products = data.products || [];

        if (!products.length) {
          message(i18n.noProducts || "No products found.");
          syncPicker($modal);
          return;
        }

        $list.empty();

        products.forEach(function (p) {
          var variations = p.variations || [];

          if (!variations.length) {
            known.set(p.id, p);
            $list.append(pickerRow(p, { locked: p.sells_box }, $modal));
            return;
          }

          var $parent = pickerRow(p, { control: true, locked: p.sells_box }, $modal);
          var $toggle = poolToggle(p.id, false);
          var $children = $();

          // Variations start folded; the chevron says how many are ticked.
          $list.append($parent.append($toggle));

          variations.forEach(function (v) {
            var $row = pickerRow(v, { indent: true, locked: p.sells_box }, $modal);

            known.set(v.id, $.extend({ parent_id: p.id, parent_name: p.name }, v));
            $children = $children.add($row.data("cb"));
            $list.append($row.attr("data-subscrpt-pool-child", p.id).css("display", "none"));
          });

          syncPickerParent($parent.data("cb"), $children, $toggle);

          $parent.data("cb").on("change", function () {
            $children.prop("checked", this.checked).trigger("change");
          });
          $children.on("change", function () {
            syncPickerParent($parent.data("cb"), $children, $toggle);
          });
        });

        $list.children().last().css("border-bottom", "none");
        syncPicker($modal);
      })
      .catch(function () {
        if ($modal.data("request") === request) {
          message(i18n.genericError);
        }
      });
  }

  // Opening starts from what the list holds now, saved or not.
  $(document).on("wpsubs:modal:open", "[data-subscrpt-pool-picker]", function () {
    var $modal = $(this);

    $modal.data("selected", new Set(poolState ? poolState.products : poolIds($("[data-subscrpt-pool]"))));
    $modal.data("known", new Map());
    $modal.find("[data-subscrpt-pool-picker-search]").val("");
    loadPicker($modal, "");
  });

  var poolSearchTimer;

  $(document).on("input", "[data-subscrpt-pool-picker-search]", function () {
    var $input = $(this);

    window.clearTimeout(poolSearchTimer);
    poolSearchTimer = window.setTimeout(function () {
      loadPicker($input.closest("[data-subscrpt-pool-picker]"), $input.val().trim());
    }, 300);
  });

  $(document).on("change", "[data-subscrpt-pool-pick]", function () {
    var $modal = $(this).closest("[data-subscrpt-pool-picker]");
    var id = parseInt($(this).data("subscrpt-pool-pick"), 10);

    if (this.checked) {
      $modal.data("selected").add(id);
    } else {
      $modal.data("selected").delete(id);
    }

    syncPicker($modal);
  });

  $(document).on("change", "[data-subscrpt-pool-picker-all]", function () {
    var $modal = $(this).closest("[data-subscrpt-pool-picker]");

    $modal
      .find("[data-subscrpt-pool-picker-list] input:enabled")
      .prop("checked", this.checked)
      .prop("indeterminate", false);
    $modal.find("[data-subscrpt-pool-pick]:enabled").each(function () {
      var id = parseInt($(this).data("subscrpt-pool-pick"), 10);

      if (this.checked) {
        $modal.data("selected").add(id);
      } else {
        $modal.data("selected").delete(id);
      }
    });

    syncPicker($modal);
  });

  // Rewrite the list from the picks, then save the tab — the picker is the
  // pool, so ticking and saving is one step, as it is on the Plans screen.
  $(document).on("click", "[data-subscrpt-pool-picker-save]", function () {
    var $modal = $(this).closest("[data-subscrpt-pool-picker]");

    // On the Box items list the picks are the chosen products, saved with the
    // rest of the tab: keep the order they had, and add new ones at the end.
    if (poolState) {
      var picked = $modal.data("selected");

      poolState.products = poolState.products.filter(function (id) {
        return picked.has(id);
      });
      picked.forEach(function (id) {
        if (poolState.products.indexOf(id) === -1) {
          poolState.products.push(id);
        }
      });

      window.WPSubsModal.close($modal[0]);
      poolChanged();
      return;
    }

    var $pool = $("[data-subscrpt-pool]");
    var $list = $pool.find("[data-subscrpt-pool-list]");
    var selected = $modal.data("selected");
    var known = $modal.data("known");
    var kept = new Set();

    $list.find("[data-subscrpt-pool-item]").each(function () {
      var id = parseInt($(this).data("subscrpt-pool-item"), 10);

      if (selected.has(id)) {
        kept.add(id);
      } else {
        $(this).remove();
      }
    });

    selected.forEach(function (id) {
      if (!kept.has(id) && known.has(id)) {
        $list.append(poolRow(known.get(id)));
      }
    });

    syncPool($pool);
    window.WPSubsModal.close($modal[0]);
    $pool.closest("[data-subscrpt-box-form]").find("[data-subscrpt-box-save]").trigger("click");
  });

  $(document).on("click", "[data-subscrpt-pool-remove]", function () {
    var $pool = $(this).closest("[data-subscrpt-pool]");

    $(this).closest("[data-subscrpt-pool-item]").remove();
    syncPool($pool);
  });

  $(document).on("click", "[data-subscrpt-pool-remove-group]", function () {
    var $pool = $(this).closest("[data-subscrpt-pool]");

    $(this).closest("[data-subscrpt-pool-group]").remove();
    syncPool($pool);
  });

  // Open or fold a variable product's variations, in the list or the picker.
  $(document).on("click", "[data-subscrpt-pool-toggle]", function () {
    var $toggle = $(this);
    var open = "true" !== $toggle.attr("aria-expanded");
    var $group = $toggle.closest("[data-subscrpt-pool-group]");

    $toggle.attr("aria-expanded", open ? "true" : "false");

    if ($group.length) {
      $group.find("[data-subscrpt-pool-panel]").prop("hidden", !open);
      return;
    }

    $toggle
      .closest("[data-subscrpt-pool-picker-list]")
      .find('[data-subscrpt-pool-child="' + $toggle.data("subscrpt-pool-toggle") + '"]')
      .css("display", open ? "flex" : "none");
  });
})(jQuery);
