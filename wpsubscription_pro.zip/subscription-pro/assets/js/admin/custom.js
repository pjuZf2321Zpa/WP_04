jQuery(document).ready(($) => {
  $("#sdevs_subscription_pro_license_form").submit((e) => {
    e.preventDefault();
    $("#sdevs_license_form_submit").hide();
    $(".spinner").addClass("is-active");
    const license_key = $("#license_key").val();
    const nonce = $("#_wpnonce").val();

    $.ajax({
      type: "POST",
      url: wcbookingpro_params.ajax_url,
      data: {
        action: "sdevs_booking_pro_license_submit",
        license_key: license_key,
        nonce: nonce,
      },
      dataType: "json",
      success: function (response) {
        if (response.success) {
          $(".sdevs-success-notice").fadeIn();
        } else {
          $(".sdevs-danger-notice").fadeIn();
          $("#license_key").val(null);
          $("#sdevs_license_form_submit").show();
          $(".spinner").removeClass("is-active");
          setTimeout(function () {
            $(".sdevs-danger-notice").fadeOut();
          }, 5000);
        }
      },
      error: function (error) {
        console.log(error);
      },
    });
  });
});
