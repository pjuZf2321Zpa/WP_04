/**
 * The box row on the product editor.
 *
 * Attaching, removing and resizing all go through the same REST routes the
 * Boxes screen uses, so a connection made here and one made there are the same
 * record.
 *
 * @package SpringDevs\SubscriptionPro
 */
(function ($) {
  "use strict";

  var cfg = window.subscrptProductBox || {};
  var i18n = cfg.i18n || {};

  if (!cfg.restUrl) {
    return;
  }

  /**
   * Call a box route.
   *
   * @param {string} method HTTP method.
   * @param {string} path   Path after the /boxes base.
   * @param {Object} body   Optional JSON body.
   * @returns {Promise<Object>} The decoded response.
   */
  function api(method, path, body) {
    return fetch(cfg.restUrl + (path || ""), {
      method: method,
      credentials: "same-origin",
      headers: {
        "Content-Type": "application/json",
        "X-WP-Nonce": cfg.nonce,
      },
      body: body ? JSON.stringify(body) : undefined,
    }).then(function (response) {
      return response
        .json()
        .catch(function () {
          return {};
        })
        .then(function (data) {
          if (!response.ok) {
            throw new Error(data.message || i18n.genericError);
          }
          return data;
        });
    });
  }

  /**
   * The product being edited.
   *
   * @returns {number} Product id.
   */
  function productId() {
    return parseInt($("[data-subscrpt-box-connect]").data("product-id"), 10) || 0;
  }

  /**
   * Read the size boxes out of one connection row.
   *
   * @param {jQuery} $row The connection row.
   * @returns {Object} min and max, as typed.
   */
  function sizeOf($row) {
    return {
      min: $row.find('[data-subscrpt-box-size="min"]').val(),
      max: $row.find('[data-subscrpt-box-size="max"]').val(),
    };
  }

  /**
   * Say what happened, next to the row.
   *
   * @param {string} message Text.
   * @param {boolean} isError Whether it failed.
   * @returns {void}
   */
  function say(message, isError) {
    var $note = $("<span/>")
      .text(message)
      .css({
        marginLeft: "8px",
        fontSize: "12px",
        color: isError ? "#b32d2e" : "#1b7442",
      });

    $("[data-subscrpt-box-connect] > div").first().append($note);

    window.setTimeout(function () {
      $note.fadeOut(200, function () {
        $note.remove();
      });
    }, 2500);
  }

  // Sell a box through this product.
  $(document).on("click", "[data-subscrpt-box-attach]", function () {
    var $button = $(this);
    var boxId = parseInt($("[data-subscrpt-box-picker]").val(), 10);

    if (!boxId) {
      say(i18n.pickBox, true);
      return;
    }

    $button.prop("disabled", true);

    api("POST", "/" + boxId + "/relations", { product_id: productId() })
      .then(function () {
        window.location.reload();
      })
      .catch(function (error) {
        $button.prop("disabled", false);
        say(error.message, true);
      });
  });

  // Stop selling it.
  $(document).on("click", "[data-subscrpt-box-detach]", function () {
    if (!window.confirm(i18n.confirmDetach)) {
      return;
    }

    api("DELETE", "/relations/" + $(this).data("subscrpt-box-detach"))
      .then(function () {
        window.location.reload();
      })
      .catch(function (error) {
        say(error.message, true);
      });
  });

  // How many items this product's box holds.
  $(document).on("click", "[data-subscrpt-box-save-size]", function () {
    var $button = $(this);
    var $row = $button.closest("[data-subscrpt-box-connection]");

    $button.prop("disabled", true);

    api("PUT", "/relations/" + $row.data("subscrpt-box-connection"), { size: sizeOf($row) })
      .then(function () {
        $button.prop("disabled", false);
        say(i18n.saved || "Saved.");
      })
      .catch(function (error) {
        $button.prop("disabled", false);
        say(error.message, true);
      });
  });
})(jQuery);
