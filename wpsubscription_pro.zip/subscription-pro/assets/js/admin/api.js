jQuery(document).ready(function ($) {
  // Handle API key regeneration
  $("#regenerate_api_key").on("click", function (e) {
    e.preventDefault();

    if (
      !confirm(
        wp.i18n.__(
          "Are you sure you want to regenerate the API key? This will invalidate the existing key.",
          "subscription-pro",
        ),
      )
    ) {
      return;
    }

    var $button = $(this);
    $button.prop("disabled", true);

    $.ajax({
      url: ajaxurl,
      type: "POST",
      data: {
        action: "subscrpt_pro_handle_ajax",
        action_type: "regenerate_api_key",
        nonce: subscrpt_pro_ajax.nonce,
      },
      success: function (response) {
        if (response.success) {
          $("#wpsubscription_api_key").val(response.data.api_key);
          alert(wp.i18n.__("API key has been regenerated successfully.", "subscription-pro"));
        } else {
          alert(
            typeof response.data === "string" && response.data
              ? response.data
              : wp.i18n.__("An error occurred. Please try again.", "subscription-pro"),
          );
        }
      },
      error: function () {
        alert(wp.i18n.__("An error occurred. Please try again.", "subscription-pro"));
      },
      complete: function () {
        $button.prop("disabled", false);
      },
    });
  });
});
