jQuery(document).ready(($) => {
  const deliveryCheckbox = $("#subscrpt_synchronize_delivery_schedule");
  const deliveryDayField = $(".subscrpt_synchronize_delivery_day_field");

  if (deliveryCheckbox.is(":checked")) {
    deliveryDayField.show();
  } else {
    deliveryDayField.hide();
  }

  $(deliveryCheckbox).on("change", function () {
    if (this.checked) {
      deliveryDayField.show();
    } else {
      deliveryDayField.hide();
    }
  });
});
