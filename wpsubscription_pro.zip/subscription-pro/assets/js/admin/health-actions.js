/* globals subscrptRecovery */
(function () {
  "use strict";

  var cfg = window.subscrptRecovery || {};
  var ajaxUrl = cfg.ajaxUrl || "";
  var nonce = cfg.nonce || "";
  var exportUrl = cfg.exportUrl || "";
  var exportNonce = cfg.exportNonce || "";

  // ── AJAX helper ───────────────────────────────────────────────────────────

  function wpAjax(action, data) {
    var body = new FormData();
    body.append("action", action);
    body.append("nonce", nonce);
    Object.keys(data).forEach(function (k) {
      body.append(k, data[k]);
    });
    return fetch(ajaxUrl, { method: "POST", body: body }).then(function (r) {
      return r.json();
    });
  }

  function escHtml(str) {
    return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  // ── Export CSV ────────────────────────────────────────────────────────────

  var exportBtn = document.getElementById("subscrpt-export-btn");
  if (exportBtn) {
    exportBtn.addEventListener("click", function () {
      var form = exportBtn.closest("form");
      var params = new URLSearchParams();
      params.set("action", "subscrpt_recovery_export");
      params.set("_wpnonce", exportNonce);
      if (form) {
        ["filter", "subscrpt_status", "subscrpt_issue", "s", "per_page"].forEach(function (name) {
          var el = form.querySelector('[name="' + name + '"]');
          if (el && el.value) {
            params.set(name, el.value);
          }
        });
      }
      window.location.href = exportUrl + "?" + params.toString();
    });
  }

  // ── Dropdowns ─────────────────────────────────────────────────────────────

  function closeAllDropdowns() {
    document.querySelectorAll(".subscrpt-dropdown-menu").forEach(function (m) {
      m.classList.add("hidden");
    });
    document.querySelectorAll(".wpsubs-row-actions--open").forEach(function (el) {
      el.classList.remove("wpsubs-row-actions--open");
      var d = el.querySelector(".wpsubs-dropdown");
      if (d) d.classList.remove("wpsubs-dropdown--open");
    });
  }

  document.addEventListener("click", function (e) {
    var trigger = e.target.closest(".subscrpt-dropdown-toggle");
    if (trigger) {
      e.stopPropagation();
      var menu = trigger.parentElement.querySelector(".subscrpt-dropdown-menu");
      var wasHidden = menu.classList.contains("hidden");
      closeAllDropdowns();
      if (wasHidden) {
        menu.classList.remove("hidden");
      }
      return;
    }
    // Bulk dropdown
    var bulkTrigger = e.target.closest("#subscrpt-bulk-dropdown-trigger");
    if (bulkTrigger) {
      e.stopPropagation();
      var bulkMenu = document.getElementById("subscrpt-bulk-dropdown-menu");
      if (bulkMenu) {
        bulkMenu.classList.toggle("hidden");
      }
      return;
    }
    // Close row dropdowns when clicking outside
    // Exclude .wpsubs-row-actions — the inline script handles those open/close
    if (!e.target.closest(".subscrpt-row-dropdown") && !e.target.closest(".wpsubs-row-actions")) {
      closeAllDropdowns();
    }
    // Close bulk dropdown when clicking outside
    if (!e.target.closest("#subscrpt-bulk-dropdown-wrap")) {
      var bulkMenu2 = document.getElementById("subscrpt-bulk-dropdown-menu");
      if (bulkMenu2) {
        bulkMenu2.classList.add("hidden");
      }
    }
  });

  // ── Checkboxes + bulk bar ─────────────────────────────────────────────────

  var bulkBar = document.getElementById("subscrpt-bulk-bar");
  var bulkCount = document.getElementById("subscrpt-bulk-count");
  var bulkLabel = document.getElementById("subscrpt-bulk-label");
  var selectAllCb = document.getElementById("subscrpt-select-all");

  function getSelectedIds() {
    return Array.from(document.querySelectorAll(".subscrpt-row-cb:checked")).map(function (cb) {
      return parseInt(cb.value, 10);
    });
  }

  function updateBulkBar() {
    if (!bulkBar) {
      return;
    }
    var ids = getSelectedIds();
    if (ids.length > 0) {
      bulkBar.classList.remove("hidden");
      bulkBar.classList.add("flex");
      if (bulkCount) {
        bulkCount.textContent = ids.length;
      }
      if (bulkLabel) {
        bulkLabel.textContent = ids.length === 1 ? "subscription selected" : "subscriptions selected";
      }
    } else {
      bulkBar.classList.add("hidden");
      bulkBar.classList.remove("flex");
    }
  }

  if (selectAllCb) {
    selectAllCb.addEventListener("change", function () {
      document.querySelectorAll(".subscrpt-row-cb").forEach(function (cb) {
        cb.checked = selectAllCb.checked;
        var row = cb.closest("tr");
        if (row) {
          row.classList.toggle("bg-blue-50", cb.checked);
        }
      });
      updateBulkBar();
    });
  }

  document.addEventListener("change", function (e) {
    if (!e.target.classList.contains("subscrpt-row-cb")) {
      return;
    }
    var row = e.target.closest("tr");
    if (row) {
      row.classList.toggle("bg-blue-50", e.target.checked);
    }
    if (selectAllCb) {
      var all = document.querySelectorAll(".subscrpt-row-cb");
      var checked = document.querySelectorAll(".subscrpt-row-cb:checked");
      selectAllCb.checked = all.length > 0 && all.length === checked.length;
      selectAllCb.indeterminate = checked.length > 0 && checked.length < all.length;
    }
    updateBulkBar();
  });

  // ── Row action state helpers ──────────────────────────────────────────────

  function setRowLoading(id) {
    var cell = document.querySelector('[data-actions-cell="' + id + '"]');
    if (!cell) {
      return;
    }
    cell.innerHTML =
      '<div class="flex justify-end">' +
      '<span class="inline-block h-4 w-4 animate-spin rounded-full border-2 border-gray-300 border-t-gray-700"></span>' +
      "</div>";
  }

  function setRowSuccess(id, message) {
    var cell = document.querySelector('[data-actions-cell="' + id + '"]');
    if (!cell) {
      return;
    }
    cell.innerHTML =
      '<div class="flex items-center justify-end gap-1">' +
      '<svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="text-green-600"><path d="M20 6 9 17l-5-5"/></svg>' +
      '<span class="text-xs text-green-600">' +
      escHtml(message) +
      "</span>" +
      "</div>";
    setTimeout(function () {
      var row = document.querySelector('[data-row-id="' + id + '"]');
      if (row) {
        row.style.transition = "opacity 0.4s";
        row.style.opacity = "0";
        setTimeout(function () {
          row.remove();
        }, 400);
      }
    }, 1200);
  }

  function setRowError(id, message) {
    var cell = document.querySelector('[data-actions-cell="' + id + '"]');
    if (!cell) {
      return;
    }
    cell.innerHTML =
      '<div class="flex items-center justify-end gap-1">' +
      '<svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="text-red-500"><circle cx="12" cy="12" r="10"/><path d="m15 9-6 6M9 9l6 6"/></svg>' +
      '<span class="text-xs text-red-600">' +
      escHtml(message) +
      "</span>" +
      "</div>";
  }

  // ── Row actions ───────────────────────────────────────────────────────────

  var ajaxActionMap = {
    retry: "subscrpt_recovery_retry",
    create_renewal: "subscrpt_recovery_create_renewal",
    send_email: "subscrpt_recovery_send_email",
    skip: "subscrpt_recovery_skip",
    unskip: "subscrpt_recovery_unskip",
  };

  document.addEventListener("click", function (e) {
    var btn = e.target.closest("[data-row-action]");
    if (!btn) {
      return;
    }
    e.preventDefault();
    closeAllDropdowns();

    var action = btn.dataset.rowAction;
    var id = parseInt(btn.dataset.subscriptionId, 10);

    if (action === "retry") {
      var confirmMsg = wp.i18n.__("Trigger a payment retry for this subscription?", "subscription-pro");
      if (!window.confirm(confirmMsg)) {
        return;
      }
    }

    if (action === "skip") {
      var skipMsg = wp.i18n.__(
        "Skip this subscription?\n\nIt will be hidden from the recovery queue. You can restore it at any time using the Skipped filter.",
        "subscription-pro",
      );
      if (!window.confirm(skipMsg)) {
        return;
      }
    }

    var ajaxAction = ajaxActionMap[action];
    if (!ajaxAction) {
      return;
    }

    setRowLoading(id);

    wpAjax(ajaxAction, { subscription_id: id })
      .then(function (res) {
        if (res.success) {
          setRowSuccess(id, (res.data && res.data.message) || wp.i18n.__("Done.", "subscription-pro"));
        } else {
          setRowError(id, (res.data && res.data.message) || wp.i18n.__("Action failed.", "subscription-pro"));
        }
      })
      .catch(function () {
        setRowError(id, wp.i18n.__("Request failed.", "subscription-pro"));
      });
  });

  // ── Admin notice helper ───────────────────────────────────────────────────

  function showNotice(message, type) {
    var wrap = document.querySelector(".wp-subscription-admin-content");
    if (!wrap) {
      return;
    }
    var notice = document.createElement("div");
    notice.className = "notice notice-" + (type || "success") + " is-dismissible";
    notice.style.cssText = "margin:0 0 16px;";
    notice.innerHTML = "<p>" + escHtml(message) + "</p>";
    wrap.insertBefore(notice, wrap.firstChild);
    setTimeout(function () {
      notice.style.transition = "opacity 0.4s";
      notice.style.opacity = "0";
      setTimeout(function () {
        notice.remove();
      }, 400);
    }, 4000);
  }

  // ── Bulk actions ──────────────────────────────────────────────────────────

  var ajaxBulkActions = ["retry", "create_renewal", "send_email", "skip", "unskip"];

  // Bulk action fires immediately on adv-select pick (no separate Apply button)
  document.addEventListener("wpsubs:select", function (e) {
    var hiddenInput = e.target && e.target.querySelector('input[type="hidden"]');
    if (!hiddenInput || hiddenInput.name !== "bulk_action") return;

    var action = hiddenInput.value;
    if (!action || !ajaxBulkActions.includes(action)) return;

    var ids = getSelectedIds();
    if (ids.length === 0) {
      window.alert(wp.i18n.__("Please select at least one subscription.", "subscription-pro"));
      // Reset the adv-select back to placeholder
      if (window.WPSubsAdvSelect) {
        var inst = e.target;
        if (inst && inst._wpsubsInst) inst._wpsubsInst.reset();
      }
      return;
    }

    if (action === "skip") {
      var skipMsg = wp.i18n.sprintf(
        /* translators: %d: number of subscriptions. */
        wp.i18n._n(
          "Skip %d subscription?\n\nIt will be hidden from the recovery queue.",
          "Skip %d subscriptions?\n\nThey will be hidden from the recovery queue.",
          ids.length,
          "subscription-pro",
        ),
        ids.length,
      );
      if (!window.confirm(skipMsg)) return;
    }

    if (action === "unskip") {
      var unskipMsg = wp.i18n.sprintf(
        /* translators: %d: number of subscriptions. */
        wp.i18n._n(
          "Return %d subscription to the recovery queue?",
          "Return %d subscriptions to the recovery queue?",
          ids.length,
          "subscription-pro",
        ),
        ids.length,
      );
      if (!window.confirm(unskipMsg)) return;
    }

    if (action === "retry") {
      var retryMsg = wp.i18n.__("Trigger a payment retry for the selected subscriptions?", "subscription-pro");
      if (!window.confirm(retryMsg)) return;
    }

    wpAjax("subscrpt_recovery_bulk", {
      subscription_ids: ids.join(","),
      bulk_action: action,
    })
      .then(function (res) {
        if (res.success) {
          ids.forEach(function (id) {
            var row = document.querySelector('[data-row-id="' + id + '"]');
            if (row) row.remove();
          });
          document.querySelectorAll(".subscrpt-row-cb").forEach(function (cb) {
            cb.checked = false;
          });
          if (selectAllCb) {
            selectAllCb.checked = false;
            selectAllCb.indeterminate = false;
          }
          setTimeout(updateBulkBar, 0);
        } else {
          window.alert((res.data && res.data.message) || wp.i18n.__("Bulk action failed.", "subscription-pro"));
        }
      })
      .catch(function () {
        window.alert(wp.i18n.__("Request failed.", "subscription-pro"));
      });
  });
})();
