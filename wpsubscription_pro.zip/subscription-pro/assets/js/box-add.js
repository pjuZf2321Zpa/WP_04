/**
 * The "Add to a box" button, when the box is already in the cart.
 *
 * The card renders its button as a link to the box's page. When the page knows
 * of a box line in the cart (`data-cart-key`) this adds the item to that line in
 * place instead, through the classic `wc-ajax` endpoint (`subscrptBoxCart`). A
 * full box asks which item to give up (`subscrptBoxReplace`) and writes the
 * answer. Without a box line, or when the script cannot act, the link works as
 * it always did.
 *
 * The cart key changes on every write, so the key the page rendered is only
 * good for the first one; every answer carries the new one, which replaces it
 * on every button of that box.
 *
 * Mini-cart: after a change, `wc_fragment_refresh` makes WooCommerce's
 * cart-fragments script refetch its fragments (classic mini-cart and count),
 * and `wc-blocks_added_to_cart` does the same for the block mini-cart.
 */
(function () {
  "use strict";

  var text = window.subscrptBoxAddText || {};
  var config = window.subscrptBoxCart;
  var NOTICE = "data-subscrpt-box-add-notice";

  /**
   * Call the endpoint.
   *
   * @param {string} action add-items or set-contents.
   * @param {string} key Cart item key of the box line.
   * @param {Object[]} items Rows of product_id, variation_id, qty, once.
   * @return {Promise<Object>} The service result.
   */
  function call(action, key, items) {
    var body = new URLSearchParams();
    body.set("nonce", config.nonce);
    body.set("action", action);
    body.set("cart_key", key);
    body.set("items", JSON.stringify(items));

    return fetch(config.url, {
      method: "POST",
      credentials: "same-origin",
      headers: { Accept: "application/json" },
      body: body,
    }).then(function (response) {
      return response.json();
    });
  }

  /**
   * Tell the page's mini-cart the cart changed.
   */
  function refreshCart() {
    if (window.jQuery) {
      window.jQuery(document.body).trigger("wc_fragment_refresh");
    }
    document.body.dispatchEvent(new CustomEvent("wc-blocks_added_to_cart", { bubbles: true }));
  }

  /**
   * Show a notice where WooCommerce shows its own.
   *
   * @param {HTMLElement} link The button that was used.
   * @param {string} message What to say.
   * @param {boolean} ok Whether it went through.
   */
  function notify(link, message, ok) {
    var old = document.querySelector("[" + NOTICE + "]");
    if (old) {
      old.remove();
    }

    var notice = document.createElement("div");
    notice.setAttribute(NOTICE, "");
    notice.className = ok
      ? "woocommerce-message subscrpt-box-add__notice"
      : "woocommerce-error subscrpt-box-add__notice";
    notice.setAttribute("role", ok ? "status" : "alert");

    if (ok && text.cartUrl) {
      var view = document.createElement("a");
      view.href = text.cartUrl;
      view.className = "button wc-forward";
      view.textContent = text.view || "View cart";
      notice.appendChild(view);
    }
    notice.appendChild(document.createTextNode(" " + message));

    var wrapper = document.querySelector(".woocommerce-notices-wrapper");
    if (wrapper) {
      wrapper.appendChild(notice);
    } else {
      var card = link.closest("[data-subscrpt-box-add]");
      card.parentNode.insertBefore(notice, card);
    }
    notice.scrollIntoView({ block: "nearest" });
  }

  /**
   * Remember the box line's new key on every button of that box.
   *
   * @param {string} boxId The box.
   * @param {string} key The key after the change.
   */
  function remember(boxId, key) {
    document.querySelectorAll('[data-subscrpt-box-add-link][data-box-id="' + boxId + '"]').forEach(function (link) {
      link.setAttribute("data-cart-key", key);
    });
  }

  /**
   * Whether the shopper chose "once" for this button's box.
   *
   * @param {HTMLElement} link The button.
   * @return {boolean} True when the "once" choice beside it is selected.
   */
  function wantsOnce(link) {
    var chosen = link.closest("li")
      ? link.closest("li").querySelector("[data-subscrpt-box-add-once] input:checked")
      : null;

    return !!chosen && chosen.value === "1";
  }

  /**
   * What the shopper is adding, as the endpoint takes it.
   *
   * @param {HTMLElement} link The button.
   * @return {Object[]} One row.
   */
  function rows(link) {
    return [
      {
        product_id: parseInt(link.getAttribute("data-product-id"), 10) || 0,
        variation_id: 0,
        qty: 1,
        once: wantsOnce(link),
      },
    ];
  }

  /**
   * Keep the link's own destination in step with the choice, so the box's page
   * opens with the item ticked once when the button is followed as a link.
   *
   * @param {Event} e The change event.
   */
  function syncLink(e) {
    var group = e.target.closest ? e.target.closest("[data-subscrpt-box-add-once]") : null;
    var link = group && group.closest("li") ? group.closest("li").querySelector("[data-subscrpt-box-add-link]") : null;

    if (!link) {
      return;
    }

    var url = new URL(link.getAttribute("href"), window.location.href);

    if (wantsOnce(link)) {
      url.searchParams.set("subscrpt_box_pick_once", "1");
    } else {
      url.searchParams.delete("subscrpt_box_pick_once");
    }

    link.setAttribute("href", url.toString());
  }

  document.addEventListener("change", syncLink);

  /**
   * Add the item to the box in the cart, asking first when the box is full.
   *
   * @param {HTMLElement} link The button.
   * @return {Promise<void>} Settles when the shopper has been told.
   */
  function add(link) {
    var boxId = link.getAttribute("data-box-id");
    var key = link.getAttribute("data-cart-key");
    var name = link.getAttribute("data-item-name") || "";

    /**
     * Say the item is in.
     *
     * @param {Object} result The service result.
     * @param {string} item Item name.
     */
    function added(result, item) {
      remember(boxId, result.cart_key);
      if (result.added && !result.added.length && result.skipped && result.skipped.length) {
        notify(link, (text.present || "%s is already in your box.").replace("%s", item), true);
        return;
      }
      refreshCart();
      notify(link, (text.added || "Added %s to your box.").replace("%s", item), true);
    }

    return call("add-items", key, rows(link)).then(function (result) {
      var item = (result.incoming && result.incoming[0] && result.incoming[0].name) || name;

      if (result.status === "ok") {
        added(result, item);
        return;
      }

      if (result.status === "invalid") {
        // The key is stale (the box left the cart) or the box cannot take it;
        // the box's page is where that gets sorted out.
        remember(boxId, "");
        window.location.href = link.href;
        return;
      }

      if (result.status !== "needs_replace") {
        notify(link, result.message || text.failed || "", false);
        return;
      }

      return window.subscrptBoxReplace
        .ask({ incoming: result.incoming, current: result.current, max: result.max, trigger: link })
        .then(function (contents) {
          if (!contents) {
            return;
          }
          return call("set-contents", result.cart_key, contents).then(function (final) {
            if (final.status === "ok") {
              added(final, item);
            } else {
              notify(link, final.message || text.failed || "", false);
            }
          });
        });
    });
  }

  document.addEventListener("click", function (e) {
    var link = e.target.closest ? e.target.closest("[data-subscrpt-box-add-link]") : null;

    if (!link || !link.getAttribute("data-cart-key") || !config || !window.subscrptBoxReplace) {
      return;
    }
    // Without <dialog> a full box cannot be asked about, so the link keeps its meaning.
    if (typeof HTMLDialogElement === "undefined") {
      return;
    }
    // A new tab, window or download keeps the link's own meaning.
    if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) {
      return;
    }
    e.preventDefault();

    if (link.getAttribute("aria-busy") === "true") {
      return;
    }
    link.setAttribute("aria-busy", "true");

    add(link)
      .catch(function () {
        notify(link, text.failed || "", false);
      })
      .then(function () {
        link.removeAttribute("aria-busy");
      });
  });
})();
