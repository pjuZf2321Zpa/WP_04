/**
 * The box's contents as a thumbnail list in the block cart and the block
 * checkout's order summary.
 *
 * WooCommerce's blocks have no per-line slot for HTML, so this decorates the
 * rendered rows: it reads each box line's `extensions[ namespace ]` from the
 * cart store (BoxCartView::store_api_data) and appends the list to the row.
 * It is plain JS with no build step. The mini-cart is deliberately left alone;
 * it shows the count that item data already carries.
 *
 * Why it is shaped this way is in design.md section 5, "Block cart, decided".
 * The markup it writes mirrors templates/box/cart-contents.php.
 */
(function () {
  "use strict";

  var config = window.subscrptBoxCartView || {};

  /**
   * WooCommerce's markup and store, in one place. None of it is a contract,
   * so a WooCommerce release that renames one is a one-line fix here.
   */
  var WC = {
    store: "wc/store/cart",
    cartRoot: ".wp-block-woocommerce-cart",
    cartRow: ".wc-block-cart-items__row[data-cart-item-key]",
    cartHost: ".wc-block-cart-item__product",
    cartImage: ".wc-block-cart-item__image",
    checkoutRoot: ".wp-block-woocommerce-checkout",
    summaryRow: ".wc-block-components-order-summary-item",
    summaryHost: ".wc-block-components-order-summary-item__description",
    summaryImage: ".wc-block-components-order-summary-item__image",
    summaryName: ".wc-block-components-product-name",
    keyAttribute: "data-cart-item-key",
  };

  var CLASSES = {
    root: "subscrpt-box-contents",
    list: "subscrpt-box-contents__list",
    item: "subscrpt-box-contents__item",
    thumb: "subscrpt-box-contents__thumb",
    name: "subscrpt-box-contents__name",
    qty: "subscrpt-box-contents__qty",
    once: "subscrpt-box-contents__once",
    cadence: "subscrpt-box-contents__cadence",
    price: "subscrpt-box-contents__price",
    edit: "subscrpt-box-contents__edit",
    collage: "subscrpt-box-collage",
    tile: "subscrpt-box-collage__tile",
    more: "subscrpt-box-collage__more",
  };

  var SIGNATURE = "data-subscrpt-signature";

  /**
   * Create an element with a class and optional text.
   *
   * @param {string} tag       Tag name.
   * @param {string} className Class.
   * @param {string} [text]    Text content.
   * @return {Element} The element.
   */
  function el(tag, className, text) {
    var node = document.createElement(tag);
    if (className) {
      node.className = className;
    }
    if (text !== undefined) {
      node.textContent = text;
    }
    return node;
  }

  /**
   * Whether a URL is one worth linking to or loading.
   *
   * @param {string} url Address from the Store API.
   * @return {boolean} True for http and https.
   */
  function isWebUrl(url) {
    return /^https?:\/\//i.test(url || "");
  }

  /**
   * The box description a cart item carries, when it is a box.
   *
   * @param {Object} cartItem Store API cart item.
   * @return {Object|null} The description, or null.
   */
  function boxOf(cartItem) {
    var data = cartItem && cartItem.extensions && cartItem.extensions[config.namespace];
    return data && data.items && data.items.length ? data : null;
  }

  /**
   * What identifies the contents a list shows, so a changed box redraws.
   *
   * @param {Object} box Description from the Store API.
   * @return {string} Signature.
   */
  function signatureOf(box) {
    return (
      box.items
        .map(function (item) {
          return [
            item.product_id,
            item.variation_id,
            item.qty,
            item.once ? 1 : 0,
            item.label || "",
            item.price_html,
          ].join(":");
        })
        .join("|") +
      "#" +
      (box.edit_url || "")
    );
  }

  /**
   * Build the list for a box.
   *
   * @param {Object} box Description from the Store API.
   * @return {Element} The list wrapper.
   */
  function buildList(box) {
    var root = el("div", CLASSES.root);
    var list = el("ul", CLASSES.list);
    var anyOnce = box.items.some(function (pick) {
      return pick.once;
    });

    root.setAttribute(SIGNATURE, signatureOf(box));

    box.items.forEach(function (pick) {
      var item = el("li", CLASSES.item);
      var name = el("span", CLASSES.name);
      var image;
      var link;

      if (isWebUrl(pick.thumbnail)) {
        image = el("img", CLASSES.thumb);
        image.src = pick.thumbnail;
        image.alt = "";
        image.width = 48;
        image.height = 48;
        image.loading = "lazy";
        item.appendChild(image);
      }

      if (isWebUrl(pick.permalink)) {
        link = el("a", "", pick.name);
        link.href = pick.permalink;
        name.appendChild(link);
      } else {
        name.textContent = pick.name;
      }

      name.appendChild(document.createTextNode(" "));
      name.appendChild(el("span", CLASSES.qty, "\u00d7 " + pick.qty));
      item.appendChild(name);

      if (pick.once) {
        item.appendChild(el("span", CLASSES.once, pick.label || config.once || "once"));
      } else if (anyOnce && pick.label) {
        item.appendChild(el("span", CLASSES.cadence, pick.label));
      }

      if (pick.price_html) {
        var price = el("span", CLASSES.price);
        // Markup WooCommerce's wc_price() made; safeHTML drops anything executable.
        price.innerHTML =
          window.wp && window.wp.dom && window.wp.dom.safeHTML ? window.wp.dom.safeHTML(pick.price_html) : "";
        item.appendChild(price);
      }

      list.appendChild(item);
    });

    root.appendChild(list);

    if (isWebUrl(box.edit_url)) {
      var edit = el("a", CLASSES.edit, config.edit || "Edit box");
      edit.href = box.edit_url;
      root.appendChild(edit);
    }

    return root;
  }

  /**
   * Put a box's list in a host, leaving it alone when it is already right.
   *
   * @param {Element} host Element the list goes at the end of.
   * @param {Object}  box  Description from the Store API.
   */
  function ensureList(host, box) {
    var existing = host.querySelector(":scope > ." + CLASSES.root);
    var signature = signatureOf(box);

    if (existing && existing.getAttribute(SIGNATURE) === signature) {
      return;
    }

    if (existing) {
      existing.remove();
    }

    host.appendChild(buildList(box));
  }

  /**
   * Build the collage that stands in for a box's placeholder image.
   * Mirrors BoxCartView::collage_html().
   *
   * @param {Object} box Description from the Store API.
   * @return {Element} The collage.
   */
  function buildCollage(box) {
    var shown = box.items.slice(0, 4);
    var more = box.items.length - 3;
    var collage = el("span", CLASSES.collage);

    collage.setAttribute("data-count", String(shown.length));
    collage.setAttribute(SIGNATURE, signatureOf(box));

    shown.forEach(function (pick, index) {
      var tile = el("span", CLASSES.tile);
      var image = el("img");

      image.src = isWebUrl(pick.thumbnail) ? pick.thumbnail : "";
      image.alt = "";
      image.loading = "lazy";
      tile.appendChild(image);

      if (3 === index && more > 1) {
        tile.appendChild(el("span", CLASSES.more, "+" + more));
      }

      collage.appendChild(tile);
    });

    return collage;
  }

  /**
   * Swap the placeholder image in a host for the box's collage, when the box
   * product has no picture of its own. WooCommerce's image stays in the DOM,
   * hidden, so React still finds the node it rendered.
   *
   * @param {Element} host Element holding WooCommerce's image.
   * @param {Object}  box  Description from the Store API.
   */
  function ensureCollage(host, box) {
    var image = host
      ? Array.prototype.filter.call(host.querySelectorAll("img"), function (candidate) {
          return !candidate.closest("." + CLASSES.collage);
        })[0]
      : null;
    var existing;

    if (!image || box.has_image) {
      return;
    }

    existing = host.querySelector("." + CLASSES.collage);

    if (existing && existing.getAttribute(SIGNATURE) === signatureOf(box)) {
      return;
    }

    if (existing) {
      existing.remove();
    }

    image.hidden = true;
    image.parentNode.insertBefore(buildCollage(box), image);
  }

  /**
   * Decorate the block cart's rows, each found by its own cart item key.
   *
   * @param {Element} root  The cart block.
   * @param {Array}   items The store's cart items.
   */
  function decorateCart(root, items) {
    root.querySelectorAll(WC.cartRow).forEach(function (row) {
      var key = row.getAttribute(WC.keyAttribute);
      var item = items.filter(function (candidate) {
        return candidate.key === key;
      })[0];
      var box = boxOf(item);
      var host = row.querySelector(WC.cartHost);

      if (box && host) {
        ensureList(host, box);
      }

      if (box) {
        ensureCollage(row.querySelector(WC.cartImage), box);
      }
    });
  }

  /**
   * A name as the shopper sees it, so the DOM's text and the Store API's
   * entity-encoded, texturized string compare equal.
   *
   * @param {string} text Name from the DOM or the Store API.
   * @return {string} Decoded, trimmed, whitespace-collapsed text.
   */
  function normalise(text) {
    var decode =
      window.wp && window.wp.htmlEntities && window.wp.htmlEntities.decodeEntities
        ? window.wp.htmlEntities.decodeEntities
        : function (value) {
            return value;
          };
    return decode(String(text)).replace(/\s+/g, " ").trim();
  }

  /**
   * Decorate the checkout's order summary.
   *
   * Its rows carry no key, but they are the store's items in order, so a row
   * is matched by position and only trusted when its name agrees.
   *
   * @param {Element} root  The checkout block.
   * @param {Array}   items The store's cart items.
   */
  function decorateSummary(root, items) {
    root.querySelectorAll(WC.summaryRow).forEach(function (row, index) {
      var item = items[index];
      var box = boxOf(item);
      var host = row.querySelector(WC.summaryHost);
      var name = row.querySelector(WC.summaryName);

      // Same-named box lines rely on WooCommerce keeping store order in the summary.
      if (box && host && name && normalise(name.textContent) === normalise(item.name)) {
        ensureList(host, box);
        ensureCollage(row.querySelector(WC.summaryImage), box);
      }
    });
  }

  /**
   * Draw every list that is missing or out of date.
   */
  function apply() {
    var select = window.wp && window.wp.data && window.wp.data.select;
    var store = select && select(WC.store);
    var items = store && store.getCartData ? store.getCartData().items : [];
    var cart = document.querySelector(WC.cartRoot);
    var checkout = document.querySelector(WC.checkoutRoot);

    if (!items || !items.length) {
      return;
    }

    if (cart) {
      decorateCart(cart, items);
    }

    if (checkout) {
      decorateSummary(checkout, items);
    }
  }

  var scheduled = false;

  /**
   * Run `apply` once per frame however many mutations arrived.
   */
  function schedule() {
    if (scheduled) {
      return;
    }
    scheduled = true;
    window.requestAnimationFrame(function () {
      scheduled = false;
      apply();
    });
  }

  /**
   * Watch the blocks for re-renders, and the store for new items.
   */
  function start() {
    var roots = [WC.cartRoot, WC.checkoutRoot]
      .map(function (selector) {
        return document.querySelector(selector);
      })
      .filter(Boolean);

    if (!roots.length || !window.MutationObserver) {
      return;
    }

    var observer = new window.MutationObserver(schedule);
    roots.forEach(function (root) {
      observer.observe(root, { childList: true, subtree: true });
    });

    if (window.wp && window.wp.data && window.wp.data.subscribe) {
      window.wp.data.subscribe(schedule);
    }

    apply();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
