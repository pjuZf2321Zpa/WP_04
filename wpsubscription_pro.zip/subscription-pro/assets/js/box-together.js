/**
 * Frequently Bought Together: swap, price, and fill the box already in the cart.
 *
 * Each section (`[data-subscrpt-together]`, on the page, in the shortcode or in
 * the block) works on its own:
 *
 * - Unticking a product ticks the next suggestion, so the count the box started
 *   with is kept. The suggestions wait in a `<template>` the server rendered,
 *   so a swap needs no request. Ticking the product again gives the suggestion
 *   back.
 * - Every change asks the quote endpoint for the box price (`data-quote-url`);
 *   nothing is priced here.
 * - When the page knows of a box line in the cart (`data-cart-key`) the button
 *   adds only the missing products to that line in place, through the classic
 *   `wc-ajax` endpoint (`subscrptBoxCart`), as `box-add.js` does. A full box
 *   asks which item to give up (`subscrptBoxReplace`) and writes the answer.
 *   Without a box line, or when the script cannot act, the form posts and the
 *   server does the same.
 *
 * The cart key changes on every write, so each answer's key replaces the one
 * the page rendered, on this section and on the "Add to a box" buttons.
 */
(function () {
  "use strict";

  var text = window.subscrptBoxTogetherText || {};
  var ROOT = "[data-subscrpt-together]";

  /**
   * The section's own state, made on first use.
   *
   * @param {HTMLElement} root Section element.
   * @return {Object} spares: waiting suggestions; tiles: tile element by product id; asked: quote counter.
   */
  function state(root) {
    if (root.subscrptTogether) {
      return root.subscrptTogether;
    }

    var own = { spares: [], tiles: {}, asked: 0 };
    var template = root.querySelector("template[data-subscrpt-together-spares]");

    root.querySelectorAll("[data-subscrpt-together-tile]").forEach(function (tile) {
      own.tiles[tile.getAttribute("data-subscrpt-together-tile")] = tile;
    });

    if (template) {
      template.content.querySelectorAll("[data-subscrpt-together-spare]").forEach(function (spare) {
        var id = spare.getAttribute("data-subscrpt-together-spare");

        own.spares.push({
          id: id,
          tile: spare.querySelector("[data-subscrpt-together-tile]"),
          row: spare.querySelector("[data-subscrpt-together-row]"),
        });
      });
    }

    root.subscrptTogether = own;

    return own;
  }

  /**
   * The rows of the list, in order.
   *
   * @param {HTMLElement} root Section element.
   * @return {HTMLElement[]} Row elements.
   */
  function rowsOf(root) {
    return Array.prototype.slice.call(
      root.querySelectorAll("[data-subscrpt-together-list] [data-subscrpt-together-row]"),
    );
  }

  /**
   * Whether a row's product is ticked.
   *
   * @param {HTMLElement} row Row element.
   * @return {boolean} True when ticked.
   */
  function isTicked(row) {
    var box = row.querySelector("[data-subscrpt-together-item]");

    return !!box && box.checked;
  }

  /**
   * Whether the shopper chose "once" for a row.
   *
   * @param {HTMLElement} row Row element.
   * @return {boolean} True when the once choice is on.
   */
  function isOnce(row) {
    var box = row.querySelector("[data-subscrpt-together-once]");

    return !!box && box.checked;
  }

  /**
   * What is ticked, as the endpoints take it.
   *
   * @param {HTMLElement} root Section element.
   * @return {Object[]} Rows of product_id, variation_id, qty, once.
   */
  function picks(root) {
    return rowsOf(root)
      .filter(isTicked)
      .map(function (row) {
        return {
          product_id: parseInt(row.getAttribute("data-subscrpt-together-row"), 10) || 0,
          variation_id: 0,
          qty: 1,
          once: isOnce(row),
        };
      });
  }

  /**
   * A row's product name.
   *
   * @param {HTMLElement} row Row element.
   * @return {string} The name.
   */
  function nameOf(row) {
    var name = row.querySelector(".subscrpt-together__name");

    return name
      ? name.textContent
          .replace(/^\s*This item:/, "")
          .replace(/\s+/g, " ")
          .trim()
      : "";
  }

  /**
   * Show the tiles of what is ticked, joined by plus signs, and settle the button.
   *
   * @param {HTMLElement} root Section element.
   */
  function layout(root) {
    var own = state(root);
    var list = root.querySelector("[data-subscrpt-together-tiles]");
    var button = root.querySelector(".subscrpt-together__submit");
    var shown = 0;

    list.textContent = "";

    rowsOf(root)
      .filter(isTicked)
      .forEach(function (row) {
        var tile = own.tiles[row.getAttribute("data-subscrpt-together-row")];

        if (!tile) {
          return;
        }
        if (shown) {
          var plus = document.createElement("li");
          plus.className = "subscrpt-together__plus";
          plus.setAttribute("aria-hidden", "true");
          plus.textContent = "+";
          list.appendChild(plus);
        }
        list.appendChild(tile);
        shown++;
      });

    if (button) {
      button.disabled = !shown;
    }
  }

  /**
   * Show or hide a row's once choice with its product's tick.
   *
   * @param {HTMLElement} row Row element.
   */
  function syncOnce(row) {
    var label = row.querySelector(".subscrpt-together__once");

    if (!label) {
      return;
    }

    label.hidden = !isTicked(row);

    if (label.hidden) {
      label.querySelector("input").checked = false;
    }
  }

  /**
   * Give back the suggestion that took a row's place, and any that took its place.
   *
   * @param {HTMLElement} root Section element.
   * @param {HTMLElement} row The row that was unticked.
   */
  function release(root, row) {
    var swap = row.subscrptSwap;

    if (!swap) {
      return;
    }

    release(root, swap.row);
    swap.row.querySelector("[data-subscrpt-together-item]").checked = false;
    syncOnce(swap.row);
    swap.row.remove();
    state(root).spares.unshift(swap);
    row.subscrptSwap = null;
  }

  /**
   * Put a message where the shopper hears it.
   *
   * @param {HTMLElement} root Section element.
   * @param {string} message What to say.
   * @param {string} [kind] "ok", "error" or empty for a plain note.
   */
  function notify(root, message, kind) {
    var area = root.querySelector("[data-subscrpt-together-notice]");

    if (!area) {
      return;
    }

    area.textContent = "";
    area.className = "subscrpt-together__notice";

    if (!message) {
      return;
    }

    if (kind === "ok") {
      area.className += " woocommerce-message";
      if (text.cartUrl) {
        var view = document.createElement("a");
        view.href = text.cartUrl;
        view.className = "button wc-forward";
        view.textContent = text.view || "View cart";
        area.appendChild(view);
      }
    } else if (kind === "error") {
      area.className += " woocommerce-error";
    }

    area.appendChild(document.createTextNode(" " + message));
  }

  /**
   * Ask the quote endpoint what the box costs with this selection and show it.
   *
   * @param {HTMLElement} root Section element.
   */
  function requote(root) {
    var url = root.getAttribute("data-quote-url");

    if (!url) {
      return;
    }

    var own = state(root);
    var params = new URLSearchParams();

    params.set("product_id", root.getAttribute("data-product-id"));
    params.set("box_id", root.getAttribute("data-box-id"));
    params.set("plan_id", root.getAttribute("data-plan-id"));

    picks(root).forEach(function (pick) {
      params.set("items[" + pick.product_id + "]", 1);
      if (pick.once) {
        params.set("once[" + pick.product_id + "]", "1");
      }
    });

    var asked = (own.asked += 1);

    root.setAttribute("aria-busy", "true");

    fetch(url + (url.indexOf("?") === -1 ? "?" : "&") + params.toString(), { credentials: "same-origin" })
      .then(function (response) {
        return response.json();
      })
      .then(function (body) {
        // A slower, older answer must not overwrite a newer one.
        if (asked !== own.asked) {
          return;
        }
        root.removeAttribute("aria-busy");

        if (!body || !body.success) {
          notify(root, text.failedPrice || "", "error");
          return;
        }

        show(root, body.data);
      })
      .catch(function () {
        if (asked === own.asked) {
          root.removeAttribute("aria-busy");
          notify(root, text.failedPrice || "", "error");
        }
      });
  }

  /**
   * Write a quote into the summary.
   *
   * @param {HTMLElement} root Section element.
   * @param {Object} quote The quote endpoint's data.
   */
  function show(root, quote) {
    var total = root.querySelector("[data-subscrpt-together-total]");
    var split = root.querySelector("[data-subscrpt-together-split]");
    var saving = root.querySelector("[data-subscrpt-together-saving]");
    var was = root.querySelector(".subscrpt-together__was");
    var now = root.querySelector(".subscrpt-together__now");
    var hasOnce = !!quote.first_html;

    if (now && quote.price_html) {
      now.innerHTML = quote.price_html;
    }
    if (was) {
      was.innerHTML = quote.regular_html || "";
      was.hidden = !quote.regular_html;
    }
    if (total) {
      total.hidden = hasOnce;
    }
    if (split) {
      split.innerHTML = hasOnce ? quote.first_html + " · " + quote.then_html : "";
      split.hidden = !hasOnce;
    }
    if (saving) {
      saving.querySelector("[data-subscrpt-together-saved]").innerHTML = quote.saving_html || "";
      saving.hidden = !quote.saving_html;
    }
  }

  /**
   * A box line's cart key changes on every write; remember the new one.
   *
   * @param {string} boxId The box.
   * @param {string} key The key after the change; empty when the line is gone.
   */
  function remember(boxId, key) {
    document.querySelectorAll(ROOT + '[data-box-id="' + boxId + '"]').forEach(function (root) {
      root.setAttribute("data-cart-key", key);
    });
    document.querySelectorAll('[data-subscrpt-box-add-link][data-box-id="' + boxId + '"]').forEach(function (link) {
      link.setAttribute("data-cart-key", key);
    });
  }

  /**
   * Tell the page's mini-cart the cart changed.
   */
  function refreshCart() {
    if (window.jQuery) {
      window.jQuery(document.body).trigger("wc_fragment_refresh");
    }
    document.body.dispatchEvent(new CustomEvent("wc-blocks_added_to_cart", { bubbles: true }));
  }

  /**
   * Call the box cart endpoint.
   *
   * @param {string} action add-items or set-contents.
   * @param {string} key Cart item key of the box line.
   * @param {Object[]} items Rows of product_id, variation_id, qty, once.
   * @return {Promise<Object>} The service result.
   */
  function call(action, key, items) {
    var body = new URLSearchParams();

    body.set("nonce", window.subscrptBoxCart.nonce);
    body.set("action", action);
    body.set("cart_key", key);
    body.set("items", JSON.stringify(items));

    return fetch(window.subscrptBoxCart.url, {
      method: "POST",
      credentials: "same-origin",
      headers: { Accept: "application/json" },
      body: body,
    }).then(function (response) {
      return response.json();
    });
  }

  /**
   * Say how many items went in, or that they were all there already.
   *
   * @param {HTMLElement} root Section element.
   * @param {Object} result The service result.
   */
  function added(root, result) {
    remember(root.getAttribute("data-box-id"), result.cart_key);

    var count = result.added ? result.added.length : 0;

    if (!count) {
      notify(root, text.present || "Already in your box.", "ok");
      return;
    }

    refreshCart();
    notify(
      root,
      (count === 1
        ? text.addedOne || "Added %d item to your box."
        : text.addedMany || "Added %d items to your box."
      ).replace("%d", count),
      "ok",
    );
  }

  /**
   * Add what is ticked to the box in the cart, asking first when the box is full.
   *
   * @param {HTMLElement} root Section element.
   * @param {HTMLElement} button The button that was used.
   * @return {Promise<void>} Settles when the shopper has been told.
   */
  function add(root, button) {
    var boxId = root.getAttribute("data-box-id");

    return call("add-items", root.getAttribute("data-cart-key"), picks(root)).then(function (result) {
      if (result.status === "ok") {
        added(root, result);
        return;
      }

      if (result.status === "invalid") {
        // The key is stale (the box left the cart) or the box cannot take it;
        // the form's own post is where that gets sorted out.
        remember(boxId, "");
        post(root);
        return;
      }

      if (result.status !== "needs_replace") {
        notify(root, result.message || text.failed || "", "error");
        return;
      }

      return window.subscrptBoxReplace
        .ask({ incoming: result.incoming, current: result.current, max: result.max, trigger: button })
        .then(function (contents) {
          if (!contents) {
            return;
          }
          return call("set-contents", result.cart_key, contents).then(function (final) {
            if (final.status === "ok") {
              final.added = result.incoming;
              added(root, final);
            } else {
              notify(root, final.message || text.failed || "", "error");
            }
          });
        });
    });
  }

  /**
   * Post the form the way the page would without the script.
   *
   * @param {HTMLElement} root Section element.
   */
  function post(root) {
    var form = root.querySelector("form");
    var button = form.querySelector('[name="add-to-cart"]');
    var field = document.createElement("input");

    // A submit() leaves the button out, and the seller's id is what WooCommerce routes on.
    field.type = "hidden";
    field.name = "add-to-cart";
    field.value = button ? button.value : "";
    form.appendChild(field);
    form.submit();
  }

  document.addEventListener("change", function (e) {
    var target = e.target;
    var root = target.closest ? target.closest(ROOT) : null;

    if (!root) {
      return;
    }

    if (target.matches("[data-subscrpt-together-item]")) {
      var row = target.closest("[data-subscrpt-together-row]");
      var list = root.querySelector("[data-subscrpt-together-list]");

      if (!target.checked) {
        var spare = state(root).spares.shift();

        if (spare) {
          list.appendChild(spare.row);
          state(root).tiles[spare.id] = spare.tile;
          spare.row.querySelector("[data-subscrpt-together-item]").checked = true;
          syncOnce(spare.row);
          row.subscrptSwap = spare;
          notify(
            root,
            (text.swapped || "%1$s was replaced by %2$s.")
              .replace("%1$s", nameOf(row))
              .replace("%2$s", nameOf(spare.row)),
          );
        }
      } else {
        release(root, row);
        notify(root, "");
      }

      syncOnce(row);
      layout(root);
      requote(root);
      return;
    }

    if (target.matches("[data-subscrpt-together-once]")) {
      requote(root);
    }
  });

  document.addEventListener("submit", function (e) {
    var form = e.target;
    var root = form.closest ? form.closest(ROOT) : null;

    if (!root || !root.getAttribute("data-cart-key") || !window.subscrptBoxCart || !window.subscrptBoxReplace) {
      return;
    }
    // Without <dialog> a full box cannot be asked about, so the form keeps its meaning.
    if (typeof HTMLDialogElement === "undefined") {
      return;
    }
    e.preventDefault();

    var button = form.querySelector(".subscrpt-together__submit");

    if (root.getAttribute("data-busy") === "true" || !picks(root).length) {
      return;
    }
    root.setAttribute("data-busy", "true");
    button.setAttribute("aria-busy", "true");

    add(root, button)
      .catch(function () {
        notify(root, text.failed || "", "error");
      })
      .then(function () {
        root.removeAttribute("data-busy");
        button.removeAttribute("aria-busy");
      });
  });
})();
