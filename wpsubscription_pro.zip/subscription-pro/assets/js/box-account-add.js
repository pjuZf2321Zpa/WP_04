/**
 * My Account's box: what the next box will cost, before it is saved.
 *
 * Two places ask. The "Add to your next box" picker asks what the box would
 * cost with the chosen item added, every cycle or for the next box only; the
 * edit form asks what it costs with every quantity as typed. Both post to the
 * subscription quote (`data-quote-url` on the panel, nonce `data-quote-nonce`),
 * which prices the renewal exactly as the renewal will be priced; this script
 * does no price arithmetic.
 *
 * The picker's button is `box-next-add.js`'s own button, so adding, the full-box
 * replace prompt and the swap all behave as they do on the item's page. This
 * script only tells it which item, and reloads the panel once it went through.
 */
(function () {
  "use strict";

  var config = window.subscrptBoxAccountAdd || {};
  var NOTICE_KEY = "subscrptBoxAccountNotice";

  /**
   * Ask the quote for a price.
   *
   * @param {HTMLElement} panel The panel.
   * @param {Object<string, number>} items product_id => qty shipped every cycle.
   * @param {Object<string, number>} once product_id => qty shipped in the next box only.
   * @return {Promise<Object|null>} The quote's data, or null when it could not be had.
   */
  function quote(panel, items, once) {
    var body = new URLSearchParams();
    body.set("nonce", panel.getAttribute("data-quote-nonce") || "");
    body.set("subscription_id", panel.getAttribute("data-subscription-id") || "");

    Object.keys(items).forEach(function (id) {
      body.set("items[" + id + "]", items[id]);
    });
    Object.keys(once).forEach(function (id) {
      body.set("once[" + id + "]", once[id]);
    });

    return fetch(panel.getAttribute("data-quote-url"), {
      method: "POST",
      credentials: "same-origin",
      headers: { Accept: "application/json" },
      body: body,
    })
      .then(function (response) {
        return response.json();
      })
      .then(function (answer) {
        return answer && answer.success ? answer.data : null;
      })
      .catch(function () {
        return null;
      });
  }

  /**
   * What the box holds now, as the two quantity maps the quote takes.
   *
   * @param {HTMLElement} panel The panel.
   * @return {{items: Object<string, number>, once: Object<string, number>}} The saved contents.
   */
  function saved(panel) {
    var out = { items: {}, once: {} };
    var rows = [];

    try {
      rows = JSON.parse(panel.getAttribute("data-contents") || "[]");
    } catch (e) {
      rows = [];
    }

    rows.forEach(function (row) {
      var bucket = row.once ? out.once : out.items;
      bucket[row.product_id] = (bucket[row.product_id] || 0) + (parseInt(row.qty, 10) || 0);
    });

    return out;
  }

  /**
   * Put a quote's "Next box" line into the panel's own line.
   *
   * @param {HTMLElement} panel The panel.
   * @param {Object} data The quote.
   */
  function showNext(panel, data) {
    var amount = panel.querySelector("[data-subscrpt-box-account-next-amount]");
    var then = panel.querySelector("[data-subscrpt-box-account-then]");

    if (amount) {
      amount.innerHTML = data.next_html;
    }
    if (then) {
      then.innerHTML = data.then_html || "";
      then.hidden = !data.has_once;
    }
  }

  /**
   * The edit form: every quantity as typed, priced before it is saved.
   *
   * @param {HTMLElement} panel The panel.
   * @param {HTMLFormElement} form The edit form.
   */
  function watchForm(panel, form) {
    var timer = null;
    var asked = 0;

    form.addEventListener("input", function (event) {
      if (!event.target.classList || !event.target.classList.contains("subscrpt-box-choice__qty")) {
        return;
      }

      window.clearTimeout(timer);
      timer = window.setTimeout(function () {
        var items = {};
        var once = {};
        var turn = ++asked;

        form.querySelectorAll("input[type=number], input[type=hidden]").forEach(function (input) {
          var qty = Math.max(0, parseInt(input.value, 10) || 0);
          var match = (input.name || "").match(/^subscrpt_box_(items|once)\[(\d+)\]$/);

          if (qty && match) {
            (match[1] === "once" ? once : items)[match[2]] = qty;
          }
        });

        quote(panel, items, once).then(function (data) {
          // A slower, older answer must not overwrite a newer one.
          if (turn === asked && data) {
            showNext(panel, data);
          }
        });
      }, 250);
    });
  }

  /**
   * The picker: tell the button which item, and price the box with it added.
   *
   * @param {HTMLElement} panel The panel.
   * @param {HTMLElement} picker The picker.
   */
  function watchPicker(panel, picker) {
    var select = picker.querySelector("[data-subscrpt-box-account-pick]");
    var button = picker.querySelector("[data-subscrpt-box-next-add]");
    var preview = picker.querySelector("[data-subscrpt-box-account-preview]");
    var onceChoice = picker.querySelector("[data-subscrpt-box-account-once-choice]");
    var asked = 0;

    /**
     * Whether "next box only" is the chosen way to send it.
     *
     * @return {boolean} True when it is.
     */
    function isOnce() {
      var chosen = picker.querySelector("input[name=subscrpt_box_account_once]:checked");

      return !!chosen && chosen.value === "1" && !onceChoice.hidden;
    }

    /**
     * Follow the select: the button's item, the once choice, and the price.
     */
    function sync() {
      var option = select.options[select.selectedIndex];
      var id = parseInt(select.value, 10) || 0;
      var offered = !!option && option.getAttribute("data-once") === "1";

      button.setAttribute("data-product-id", id ? String(id) : "");
      button.setAttribute("data-item-name", id ? option.getAttribute("data-name") || "" : "");
      button.disabled = !id;

      // An item that cannot be sent once is only ever sent every cycle.
      onceChoice.hidden = !offered;
      if (!offered) {
        picker.querySelector("input[name=subscrpt_box_account_once][value='0']").checked = true;
      }

      if (!id) {
        preview.hidden = true;
        return;
      }

      var held = saved(panel);
      var bucket = isOnce() ? held.once : held.items;
      var turn = ++asked;

      // The add skips a row that is already there, so the preview does too.
      if (!bucket[id]) {
        bucket[id] = 1;
      }

      quote(panel, held.items, held.once).then(function (data) {
        if (turn !== asked) {
          return;
        }
        preview.hidden = false;
        if (data) {
          preview.innerHTML = data.next_html;
        } else {
          preview.textContent = config.failed || "";
        }
      });
    }

    select.addEventListener("change", sync);
    picker.addEventListener("change", function (event) {
      if (event.target.name === "subscrpt_box_account_once") {
        sync();
      }
    });

    // The add went through: show the panel as it now is, with the sentence kept for after the reload.
    picker.addEventListener("subscrpt-box-next-added", function (event) {
      try {
        window.sessionStorage.setItem(NOTICE_KEY, (event.detail && event.detail.message) || "");
      } catch (e) {
        // No storage: the reload still shows the item.
      }
      window.location.reload();
    });

    sync();
  }

  /**
   * Say, once, what the add before the reload did.
   */
  function showKeptNotice() {
    var message = "";

    try {
      message = window.sessionStorage.getItem(NOTICE_KEY) || "";
      window.sessionStorage.removeItem(NOTICE_KEY);
    } catch (e) {
      return;
    }

    var wrapper = document.querySelector(".woocommerce-notices-wrapper");

    if (!message || !wrapper) {
      return;
    }

    var notice = document.createElement("div");
    notice.className = "woocommerce-message";
    notice.setAttribute("role", "status");
    notice.textContent = message;
    wrapper.appendChild(notice);
  }

  document.querySelectorAll("[data-subscrpt-box-account]").forEach(function (panel) {
    var form = panel.querySelector("[data-subscrpt-box-account-form]");
    var picker = panel.querySelector("[data-subscrpt-box-account-add]");

    if (form) {
      watchForm(panel, form);
    }
    if (picker) {
      watchPicker(panel, picker);
    }
  });

  showKeptNotice();
})();
