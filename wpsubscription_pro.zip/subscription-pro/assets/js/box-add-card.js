/**
 * The "Add to a box" purchase option.
 *
 * The option is a way into a box, not something to buy, so while it is chosen
 * the item's own add-to-cart button and quantity are hidden and the card's
 * button is the action. Every purchase-option layout names its choice
 * `subscrpt_plan_group` (radios, or a select), which is all this reads. The
 * server refuses the add as well, for a form posted any other way.
 *
 * On a variable product the purchase options are swapped per variation, and a
 * variation without them has its own card rendered hidden after the button;
 * that card shows while its variation is chosen, unless the options hold one.
 */
(function () {
  "use strict";

  var HIDDEN = "data-subscrpt-box-add-hidden";

  /**
   * The chosen purchase option's id: the select's value in the dropdown
   * layout, the checked radio's elsewhere.
   *
   * @param {HTMLElement} box The purchase-option wrapper.
   * @return {string} The group id, or "".
   */
  function chosen(box) {
    var select = box.querySelector('select[name="subscrpt_plan_group"]');
    if (select) {
      return select.value;
    }
    var radio = box.querySelector('input[name="subscrpt_plan_group"]:checked');
    return radio ? radio.value : "";
  }

  /**
   * Hide or restore the form's own add-to-cart button and quantity.
   *
   * @param {HTMLElement} box The purchase-option wrapper.
   */
  function sync(box) {
    var form = box.closest("form");
    if (!form) {
      return;
    }
    var hide = chosen(box) === "box_add";
    form.querySelectorAll(".single_add_to_cart_button, .quantity").forEach(function (el) {
      if (hide) {
        el.setAttribute(HIDDEN, "");
      } else {
        el.removeAttribute(HIDDEN);
      }
    });
  }

  document.querySelectorAll("[data-subscrpt-buybox]").forEach(function (box) {
    var variable = box.getAttribute("data-subscrpt-variable") === "1";
    if (!variable && !box.querySelector("[data-subscrpt-box-add]") && !box.querySelector('[value="box_add"]')) {
      return;
    }
    box.addEventListener("change", function (e) {
      if (e.target.name === "subscrpt_plan_group") {
        sync(box);
      }
    });
    // A variation's options replace the cards, and with them the chosen one.
    box.addEventListener("subscrpt_cards_after_swap", function () {
      sync(box);
    });
    sync(box);
  });

  /**
   * Show the hidden card of the chosen variation, and hide the others.
   *
   * @param {HTMLElement} form The variations form.
   * @param {Object|null} variation The chosen variation's data, or null for none.
   */
  function showVariationCard(form, variation) {
    var id = variation ? String(variation.variation_id) : "";
    // The variation's purchase options already offer the card.
    var inOptions = !!variation && /value="box_add"/.test(variation.subscrpt_plans_html || "");

    form.querySelectorAll("[data-subscrpt-box-add-variation]").forEach(function (card) {
      card.hidden = inOptions || card.getAttribute("data-subscrpt-box-add-variation") !== id;
    });
  }

  if (window.jQuery && document.querySelector("[data-subscrpt-box-add-variation]")) {
    window.jQuery("form.variations_form").each(function () {
      var form = this;
      window
        .jQuery(form)
        .on("found_variation", function (e, variation) {
          showVariationCard(form, variation);
        })
        .on("reset_data hide_variation", function () {
          showVariationCard(form, null);
        });
    });
  }
})();
