<?php
/**
 * Frontend context loader.
 *
 * @package SpringDevs\SubscriptionPro
 */

namespace SpringDevs\SubscriptionPro;

use SpringDevs\SubscriptionPro\Frontend\Account;
use SpringDevs\SubscriptionPro\Frontend\BoxAccount;
use SpringDevs\SubscriptionPro\Frontend\BoxAddCard;
use SpringDevs\SubscriptionPro\Frontend\BoxBuilder;
use SpringDevs\SubscriptionPro\Frontend\BoxCardPrice;
use SpringDevs\SubscriptionPro\Frontend\BoxNextAdd;
use SpringDevs\SubscriptionPro\Frontend\BoxTogetherSection;
use SpringDevs\SubscriptionPro\Frontend\Cart;
use SpringDevs\SubscriptionPro\Frontend\Checkout;
use SpringDevs\SubscriptionPro\Frontend\PlanCheckout;
use SpringDevs\SubscriptionPro\Frontend\Plans;
use SpringDevs\SubscriptionPro\Frontend\PlanTermExtras;
use SpringDevs\SubscriptionPro\Frontend\Product;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxQuote;

/**
 * Frontend handler class
 */
class Frontend {



	/**
	 * Frontend constructor.
	 */
	public function __construct() {
		Illuminate::get_instance();

		new Product();
		new Cart();
		new Checkout();
		new Account();
		if ( ! class_exists( '\SpringDevs\Subscription\Frontend\PlanGroups' ) ) {
			new Plans();
		}
		new PlanTermExtras();
		new PlanCheckout();
		new BoxBuilder();
		new BoxCardPrice();
		new BoxAddCard();
		new BoxTogetherSection();
		new BoxNextAdd();
		BoxQuote::init();
		new BoxAccount();
	}
}
