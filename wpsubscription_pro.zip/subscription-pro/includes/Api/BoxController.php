<?php
/**
 * REST routes for boxes.
 *
 * The Boxes screen writes through here rather than posting forms, the way the
 * Plans screen does. Everything is admin-only: a box decides what a customer
 * may buy, so the gate is `manage_woocommerce` on every route, with no public
 * read.
 *
 * @package SpringDevs\SubscriptionPro\Api
 */

namespace SpringDevs\SubscriptionPro\Api;

use SpringDevs\SubscriptionPro\Frontend\BoxTogetherSection;
use SpringDevs\SubscriptionPro\Illuminate\Box\Box;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxDurations;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxPool;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxProduct;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxRepository;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxSelling;
use SpringDevs\SubscriptionPro\Illuminate\Box\ShipmentRepository;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

defined( 'ABSPATH' ) || exit;

/**
 * Create, edit and connect boxes.
 */
class BoxController {

	/**
	 * REST namespace. Shared with the free plugin's plan routes on purpose:
	 * one namespace is one admin API, whichever plugin serves the route.
	 */
	const NS = 'wpsubscription/v1';

	/**
	 * Register hooks.
	 */
	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Register every box route.
	 *
	 * @return void
	 */
	public function register_routes(): void {
		$perm = array( $this, 'check_permission' );

		register_rest_route(
			self::NS,
			'/boxes',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'list_boxes' ),
					'permission_callback' => $perm,
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_box' ),
					'permission_callback' => $perm,
				),
			)
		);

		// Before the {id} route: "products" would otherwise never match, and a
		// picker search would arrive as a request for box number zero.
		register_rest_route(
			self::NS,
			'/boxes/products',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'search_products' ),
					'permission_callback' => $perm,
				),
			)
		);

		// Same reason, same place in the order.
		register_rest_route(
			self::NS,
			'/boxes/shipments/bulk',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'bulk_shipments' ),
					'permission_callback' => $perm,
				),
			)
		);

		// The Box items list pages through a pool that may not be saved yet,
		// so the pool travels in the body rather than being read off the box.
		register_rest_route(
			self::NS,
			'/boxes/pool',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'pool_page' ),
					'permission_callback' => $perm,
				),
			)
		);

		register_rest_route(
			self::NS,
			'/boxes/plan-groups',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'plan_groups' ),
					'permission_callback' => $perm,
				),
			)
		);

		register_rest_route(
			self::NS,
			'/boxes/(?P<id>\d+)/publish',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'publish_box' ),
					'permission_callback' => $perm,
				),
			)
		);

		register_rest_route(
			self::NS,
			'/boxes/(?P<id>\d+)/product',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'change_product' ),
					'permission_callback' => $perm,
				),
			)
		);

		register_rest_route(
			self::NS,
			'/boxes/(?P<id>\d+)/duplicate',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'duplicate_box' ),
					'permission_callback' => $perm,
				),
			)
		);

		register_rest_route(
			self::NS,
			'/boxes/(?P<id>\d+)/durations',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'list_durations' ),
					'permission_callback' => $perm,
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'add_duration' ),
					'permission_callback' => $perm,
				),
			)
		);

		register_rest_route(
			self::NS,
			'/boxes/(?P<id>\d+)/durations/source',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'duration_source' ),
					'permission_callback' => $perm,
				),
			)
		);

		register_rest_route(
			self::NS,
			'/boxes/(?P<id>\d+)/durations/(?P<plan>\d+)',
			array(
				array(
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => array( $this, 'update_duration' ),
					'permission_callback' => $perm,
				),
				array(
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => array( $this, 'delete_duration' ),
					'permission_callback' => $perm,
				),
			)
		);

		register_rest_route(
			self::NS,
			'/boxes/relations/(?P<id>\d+)',
			array(
				array(
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => array( $this, 'update_relation' ),
					'permission_callback' => $perm,
				),
				array(
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => array( $this, 'detach_product' ),
					'permission_callback' => $perm,
				),
			)
		);

		register_rest_route(
			self::NS,
			'/boxes/(?P<id>\d+)',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_box' ),
					'permission_callback' => $perm,
				),
				array(
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => array( $this, 'update_box' ),
					'permission_callback' => $perm,
				),
				array(
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => array( $this, 'delete_box' ),
					'permission_callback' => $perm,
				),
			)
		);

		register_rest_route(
			self::NS,
			'/boxes/(?P<id>\d+)/relations',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'attach_product' ),
					'permission_callback' => $perm,
				),
			)
		);
	}

	/**
	 * Only someone who may manage the store may shape what it sells.
	 *
	 * @return bool|WP_Error
	 */
	public function check_permission() {
		if ( current_user_can( 'manage_woocommerce' ) ) {
			return true;
		}

		return new WP_Error(
			'rest_forbidden',
			__( 'You are not allowed to manage subscription boxes.', 'subscription-pro' ),
			array( 'status' => rest_authorization_required_code() )
		);
	}

	// ---- Boxes ----

	/**
	 * Every box, with how many products sell it.
	 *
	 * @return WP_REST_Response
	 */
	public function list_boxes(): WP_REST_Response {
		$boxes = array();

		foreach ( BoxRepository::all( array( 'status' => 'any' ) ) as $box ) {
			$boxes[] = $this->present( $box );
		}

		return new WP_REST_Response( array( 'boxes' => $boxes ), 200 );
	}

	/**
	 * One box.
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_box( WP_REST_Request $request ) {
		$box = BoxRepository::find( (int) $request['id'] );

		if ( ! $box ) {
			return $this->not_found();
		}

		return new WP_REST_Response( $this->present( $box ), 200 );
	}

	/**
	 * Create a box, and with it the draft product that sells it.
	 *
	 * Both start as drafts: nothing is on sale until the merchant publishes,
	 * and a half-built box reaching a customer would be the worst kind of bug
	 * to ship. `create_product: false` makes the box alone.
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function create_box( WP_REST_Request $request ) {
		$params = $this->params( $request );
		$title  = trim( (string) ( $params['title'] ?? '' ) );

		if ( '' === $title ) {
			return new WP_Error(
				'subscrpt_box_title_required',
				__( 'Give the box a name.', 'subscription-pro' ),
				array( 'status' => 400 )
			);
		}

		$box_id = BoxRepository::save(
			array(
				'title'      => $title,
				'type'       => $params['type'] ?? Box::TYPE_CURATED,
				'status'     => Box::STATUS_DRAFT,
				'allow_edit' => 1,
				'allow_skip' => 1,
			)
		);

		if ( ! $box_id ) {
			return new WP_Error(
				'subscrpt_box_not_created',
				__( 'The box could not be created.', 'subscription-pro' ),
				array( 'status' => 500 )
			);
		}

		$box = BoxRepository::find( $box_id );

		if ( $box && ! empty( $params['create_product'] ) ) {
			$name       = trim( (string) ( $params['product_name'] ?? '' ) );
			$product_id = BoxSelling::create_product( '' !== $name ? $name : $title );

			if ( ! is_wp_error( $product_id ) ) {
				BoxSelling::link( $box, $product_id );
			}
		}

		$box = BoxRepository::find( $box_id );

		return new WP_REST_Response( $box ? $this->present( $box ) : array( 'id' => $box_id ), 201 );
	}

	/**
	 * Edit a box.
	 *
	 * Only the fields present in the request are touched; the rest keep what
	 * they had, so the Rules tab saving does not blank the Box items tab. The
	 * status is not among them: it changes through `publish`, which checks the
	 * box can go on sale and moves its product with it.
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function update_box( WP_REST_Request $request ) {
		$box = BoxRepository::find( (int) $request['id'] );

		if ( ! $box ) {
			return $this->not_found();
		}

		$current = $box->to_array();
		$params  = $this->params( $request );

		$fields = array(
			'title',
			'type',
			'size_min',
			'size_max',
			'max_per_item',
			'allow_edit',
			'lock_days',
			'allow_skip',
			'max_skips',
			'stock_rule',
			'pool',
			'defaults',
			'items',
			'pricing',
			'show_together',
		);

		$data = $current;

		foreach ( $fields as $field ) {
			if ( array_key_exists( $field, $params ) ) {
				$data[ $field ] = $params[ $field ];
			}
		}

		BoxRepository::save( $data );

		if ( isset( $params['together_position'] ) ) {
			update_option(
				BoxTogetherSection::OPTION,
				BoxTogetherSection::AFTER_TABS === $params['together_position'] ? BoxTogetherSection::AFTER_TABS : BoxTogetherSection::BEFORE_TABS
			);
		}

		$saved = BoxRepository::find( $box->id() );

		if ( $saved && array_key_exists( 'title', $params ) ) {
			BoxDurations::rename( $saved );
		}

		return new WP_REST_Response( $saved ? $this->present( $saved ) : array(), 200 );
	}

	/**
	 * Delete a box, and trash or keep the product that sells it.
	 *
	 * `product=draft` keeps the product as an unlinked draft; anything else
	 * trashes it, unless subscriptions sold through it still renew. Those keep
	 * their own snapshot of the box, so deleting never changes what an
	 * existing subscriber receives.
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function delete_box( WP_REST_Request $request ) {
		$box = BoxRepository::find( (int) $request['id'] );

		if ( ! $box ) {
			return $this->not_found();
		}

		$params = $this->params( $request );
		$result = BoxSelling::delete( $box, 'draft' === ( $params['product'] ?? '' ) ? 'draft' : 'trash' );

		return new WP_REST_Response( array_merge( array( 'deleted' => true ), $result ), 200 );
	}

	/**
	 * Put a box on sale with its product, or take both off.
	 *
	 * Publishing a box that is not ready answers 400 with `data.missing`, the
	 * list the header's popover shows.
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function publish_box( WP_REST_Request $request ) {
		$box = BoxRepository::find( (int) $request['id'] );

		if ( ! $box ) {
			return $this->not_found();
		}

		$params = $this->params( $request );

		if ( Box::STATUS_DRAFT === ( $params['status'] ?? '' ) ) {
			BoxSelling::unpublish( $box );
		} else {
			$result = BoxSelling::publish( $box );

			if ( is_wp_error( $result ) ) {
				return $result;
			}
		}

		$saved = BoxRepository::find( $box->id() );

		return new WP_REST_Response( $saved ? $this->present( $saved ) : array(), 200 );
	}

	/**
	 * Change the product that sells a box.
	 *
	 * `action` is `link` (with `product_id`), `create` (a new draft named after
	 * the box) or `unlink`. The product it replaces is set to Draft.
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function change_product( WP_REST_Request $request ) {
		$box = BoxRepository::find( (int) $request['id'] );

		if ( ! $box ) {
			return $this->not_found();
		}

		$params = $this->params( $request );
		$action = sanitize_key( (string) ( $params['action'] ?? '' ) );

		if ( 'unlink' === $action ) {
			BoxSelling::unlink( $box );
		} else {
			$product_id = 'create' === $action
				? BoxSelling::create_product( $box->title() )
				: absint( $params['product_id'] ?? 0 );

			if ( is_wp_error( $product_id ) ) {
				return $product_id;
			}

			$result = BoxSelling::link( $box, $product_id );

			if ( is_wp_error( $result ) ) {
				return $result;
			}
		}

		$saved = BoxRepository::find( $box->id() );

		return new WP_REST_Response( $saved ? $this->present( $saved ) : array(), 200 );
	}

	/**
	 * Copy a box as a draft with no product.
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function duplicate_box( WP_REST_Request $request ) {
		$box = BoxRepository::find( (int) $request['id'] );

		if ( ! $box ) {
			return $this->not_found();
		}

		$copy = BoxRepository::find( BoxSelling::duplicate( $box ) );

		if ( ! $copy ) {
			return new WP_Error( 'subscrpt_box_not_created', __( 'The box could not be copied.', 'subscription-pro' ), array( 'status' => 500 ) );
		}

		return new WP_REST_Response( $this->present( $copy ), 201 );
	}

	// ---- Durations ----

	/**
	 * A box's durations.
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function list_durations( WP_REST_Request $request ) {
		$box = BoxRepository::find( (int) $request['id'] );

		if ( ! $box ) {
			return $this->not_found();
		}

		return new WP_REST_Response( array( 'durations' => BoxDurations::all( $box ) ), 200 );
	}

	/**
	 * Add a duration to a box.
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function add_duration( WP_REST_Request $request ) {
		$box = BoxRepository::find( (int) $request['id'] );

		if ( ! $box ) {
			return $this->not_found();
		}

		$plan_id = BoxDurations::add( $box, $this->params( $request ) );

		if ( is_wp_error( $plan_id ) ) {
			return $plan_id;
		}

		return $this->durations_response( $box->id(), 201 );
	}

	/**
	 * Change a duration, or switch it on or off.
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function update_duration( WP_REST_Request $request ) {
		$box = BoxRepository::find( (int) $request['id'] );

		if ( ! $box ) {
			return $this->not_found();
		}

		$result = BoxDurations::update( $box, (int) $request['plan'], $this->params( $request ) );

		return is_wp_error( $result ) ? $result : $this->durations_response( $box->id() );
	}

	/**
	 * Remove a duration.
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function delete_duration( WP_REST_Request $request ) {
		$box = BoxRepository::find( (int) $request['id'] );

		if ( ! $box ) {
			return $this->not_found();
		}

		$result = BoxDurations::delete( $box, (int) $request['plan'] );

		return is_wp_error( $result ) ? $result : $this->durations_response( $box->id() );
	}

	/**
	 * Use the box's own durations, or a shared plan's.
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function duration_source( WP_REST_Request $request ) {
		$box = BoxRepository::find( (int) $request['id'] );

		if ( ! $box ) {
			return $this->not_found();
		}

		$params = $this->params( $request );
		$result = BoxDurations::use_source( $box, (string) ( $params['mode'] ?? 'own' ), absint( $params['group_id'] ?? 0 ) );

		return is_wp_error( $result ) ? $result : $this->durations_response( $box->id() );
	}

	/**
	 * Plan groups a box may borrow.
	 *
	 * @return WP_REST_Response
	 */
	public function plan_groups(): WP_REST_Response {
		return new WP_REST_Response( array( 'groups' => BoxDurations::shared_groups() ), 200 );
	}

	/**
	 * The box, its durations and what it still needs, after a duration change.
	 *
	 * @param int $box_id Box id.
	 * @param int $status HTTP status.
	 *
	 * @return WP_REST_Response
	 */
	private function durations_response( int $box_id, int $status = 200 ): WP_REST_Response {
		$box = BoxRepository::find( $box_id );

		return new WP_REST_Response( $box ? $this->present( $box ) : array(), $status );
	}

	// ---- The pool ----

	/**
	 * A page of a pool, saved or not.
	 *
	 * Body: `pool` (source, products, categories, exclude, virtual) and
	 * `search`, `category`, `view` (all|in|out), `page`.
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return WP_REST_Response
	 */
	public function pool_page( WP_REST_Request $request ): WP_REST_Response {
		$params = $this->params( $request );

		return new WP_REST_Response(
			BoxPool::page(
				is_array( $params['pool'] ?? null ) ? $params['pool'] : array(),
				array(
					'search'   => sanitize_text_field( (string) ( $params['search'] ?? '' ) ),
					'category' => absint( $params['category'] ?? 0 ),
					'view'     => sanitize_key( (string) ( $params['view'] ?? 'all' ) ),
					'page'     => absint( $params['page'] ?? 1 ),
					'per_page' => 10,
				)
			),
			200
		);
	}

	// ---- Connections ----

	/**
	 * Make a product the one that sells a box.
	 *
	 * The product editor's Box row posts here. A box has one product, so this
	 * replaces whatever sold it before.
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function attach_product( WP_REST_Request $request ) {
		$box = BoxRepository::find( (int) $request['id'] );

		if ( ! $box ) {
			return $this->not_found();
		}

		$params = $this->params( $request );
		$result = BoxSelling::link( $box, absint( $params['product_id'] ?? 0 ) );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$connections = BoxRepository::connections_for_box( $box->id() );

		return new WP_REST_Response( array( 'relation_id' => $connections ? (int) $connections[0]['id'] : 0 ), 201 );
	}

	/**
	 * Change one connection — the size it sells, or where it sits.
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return WP_REST_Response
	 */
	public function update_relation( WP_REST_Request $request ): WP_REST_Response {
		$updated = BoxRepository::update_relation( (int) $request['id'], $this->params( $request ) );

		return new WP_REST_Response( array( 'updated' => $updated ), 200 );
	}

	/**
	 * Stop a product selling a box.
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return WP_REST_Response
	 */
	public function detach_product( WP_REST_Request $request ): WP_REST_Response {
		$relation_id = (int) $request['id'];

		foreach ( BoxRepository::all( array( 'status' => 'any' ) ) as $box ) {
			foreach ( BoxRepository::connections_for_box( $box->id() ) as $connection ) {
				if ( (int) $connection['id'] === $relation_id ) {
					BoxSelling::unlink( $box );

					return new WP_REST_Response( array( 'deleted' => true ), 200 );
				}
			}
		}

		return new WP_REST_Response( array( 'deleted' => false ), 200 );
	}

	// ---- The product picker ----

	/**
	 * Products a merchant can attach.
	 *
	 * A product that already sells a box stays in the list: one product may
	 * sell several boxes, and hiding it here would quietly make that
	 * impossible. It is flagged instead, so the picker can say so.
	 *
	 * The box-inside-a-box rule is a different question — it is about what may
	 * go *in* a box, and `Box::pool_product_ids()` enforces it there.
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return WP_REST_Response
	 */
	public function search_products( WP_REST_Request $request ): WP_REST_Response {
		$params = $this->params( $request );
		$term   = sanitize_text_field( (string) ( $params['search'] ?? '' ) );

		$args = array(
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'fields'         => 'ids',
			'posts_per_page' => 20,
			'orderby'        => 'title',
			'order'          => 'ASC',
		);

		if ( '' !== $term ) {
			$args['s'] = $term;
		}

		$results = array();

		foreach ( get_posts( $args ) as $product_id ) {
			$product = wc_get_product( $product_id );

			if ( ! $product instanceof \WC_Product ) {
				continue;
			}

			$variations = array();

			// The pool picker offers variations beneath their parent, the way
			// the Plans picker does — a pool may hold one size and not another.
			if ( $product->is_type( 'variable' ) ) {
				foreach ( $product->get_children() as $variation_id ) {
					$variation = wc_get_product( $variation_id );

					if ( $variation instanceof \WC_Product ) {
						$variations[] = $this->picker_row( $variation );
					}
				}
			}

			$results[] = array_merge(
				$this->picker_row( $product ),
				array(
					'edit_url'   => get_edit_post_link( $product_id, 'raw' ),
					'view_url'   => get_permalink( $product_id ),
					'variable'   => $product->is_type( 'variable' ),
					'sells_box'  => BoxProduct::is_box( $product ),
					'variations' => $variations,
				)
			);
		}

		return new WP_REST_Response( array( 'products' => $results ), 200 );
	}

	/**
	 * One product or variation as the pickers show it.
	 *
	 * A variation without its own image falls back to its parent's, so a row
	 * never shows a blank thumbnail for a product that has one.
	 *
	 * @param \WC_Product $product Product or variation.
	 *
	 * @return array id, name, sku, image, price, available.
	 */
	private function picker_row( \WC_Product $product ): array {
		$image_id = (int) $product->get_image_id();

		if ( ! $image_id && $product->get_parent_id() ) {
			$image_id = (int) get_post_thumbnail_id( $product->get_parent_id() );
		}

		// A variable parent has no single price, so it shows none.
		$price = $product->is_type( 'variable' )
			? ''
			: html_entity_decode( wp_strip_all_tags( wc_price( (float) wc_get_price_to_display( $product ) ) ), ENT_QUOTES, 'UTF-8' );

		return array(
			'id'        => (int) $product->get_id(),
			'name'      => $product->get_name(),
			'sku'       => $product->get_sku(),
			'image'     => $image_id ? wp_get_attachment_image_url( $image_id, 'thumbnail' ) : '',
			'price'     => $price,
			'available' => $product->is_purchasable(),
		);
	}

	// ---- Helpers ----

	/**
	 * A box as the admin screens read it.
	 *
	 * @param Box $box Box.
	 *
	 * @return array
	 */
	private function present( Box $box ): array {
		return array_merge(
			$box->to_array(),
			array(
				'product'     => BoxSelling::product( $box->id() ),
				'durations'   => BoxDurations::all( $box ),
				'missing'     => BoxSelling::missing( $box ),
				'pool_count'  => count( $box->pool_product_ids() ),
				'item_count'  => count( $box->curated_items() ),
				'is_sellable' => $box->is_active(),
				'edit_url'    => admin_url( 'admin.php?page=wp-subscription-boxes&view=detail&box=' . $box->id() ),
			)
		);
	}

	/**
	 * Request parameters, preferring a JSON body.
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return array
	 */
	private function params( WP_REST_Request $request ): array {
		$json = $request->get_json_params();

		return is_array( $json ) && $json ? $json : (array) $request->get_params();
	}

	// ---- Shipments ----

	/**
	 * Move several shipments through packing at once.
	 *
	 * A pack run is a batch — someone picks twenty boxes and marks them all
	 * ready — so doing it one row at a time is the wrong shape for the work.
	 *
	 * "Retry" is the same mechanism pointed backwards: a shipment that failed
	 * goes back to scheduled so it re-enters the run, rather than being edited
	 * into a state by hand.
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function bulk_shipments( WP_REST_Request $request ) {
		$params = $this->params( $request );
		$ids    = array_values( array_filter( array_map( 'absint', (array) ( $params['ids'] ?? array() ) ) ) );
		$action = sanitize_key( (string) ( $params['action'] ?? '' ) );

		if ( ! $ids ) {
			return new WP_Error(
				'subscrpt_box_no_shipments',
				__( 'Choose at least one box first.', 'subscription-pro' ),
				array( 'status' => 400 )
			);
		}

		$allowed = array(
			'packing'   => ShipmentRepository::STATUS_PACKING,
			'ready'     => ShipmentRepository::STATUS_READY,
			'failed'    => ShipmentRepository::STATUS_FAILED,
			'retry'     => ShipmentRepository::STATUS_SCHEDULED,
			'scheduled' => ShipmentRepository::STATUS_SCHEDULED,
		);

		if ( ! isset( $allowed[ $action ] ) ) {
			return new WP_Error(
				'subscrpt_box_bad_action',
				__( 'That is not something a shipment can be moved to.', 'subscription-pro' ),
				array( 'status' => 400 )
			);
		}

		$note = 'retry' === $action
			? __( 'Sent back to be packed again.', 'subscription-pro' )
			: '';

		$moved   = 0;
		$skipped = 0;

		foreach ( $ids as $id ) {
			if ( ShipmentRepository::set_status( $id, $allowed[ $action ], $note ) ) {
				++$moved;
				continue;
			}

			// Already in that state, or gone. Neither is an error worth failing
			// the whole run for — the merchant selected a range, not a list.
			++$skipped;
		}

		return new WP_REST_Response(
			array(
				'moved'   => $moved,
				'skipped' => $skipped,
				'status'  => $allowed[ $action ],
			),
			200
		);
	}

	/**
	 * The standard "no such box" answer.
	 *
	 * @return WP_Error
	 */
	private function not_found(): WP_Error {
		return new WP_Error(
			'subscrpt_box_not_found',
			__( 'That box no longer exists.', 'subscription-pro' ),
			array( 'status' => 404 )
		);
	}
}
