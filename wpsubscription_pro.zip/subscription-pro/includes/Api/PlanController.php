<?php
/**
 * Subscription Plans REST controller (Pro extras).
 *
 * Groups / terms / relations CRUD lives in the free plugin's controller, which
 * Pro always runs alongside. Pro registers only its extra routes — `/plans/detach`
 * and `/plans/migrate` (classic ⇄ plan conversion) — and augments the free product
 * picker with variable products via the `subscrpt_plan_products` filter. Namespace
 * `wpsubscription/v1`, gated by `manage_woocommerce`.
 *
 * @package SpringDevs\SubscriptionPro\Api
 */

namespace SpringDevs\SubscriptionPro\Api;

use SpringDevs\Subscription\Illuminate\Plans\PlanRepository;
use SpringDevs\Subscription\Admin\PlanPresenter;
use SpringDevs\Subscription\Api\PlanController as FreePlanController;
use WP_REST_Server;
use WP_REST_Request;
use WP_Error;

/**
 * Plan REST controller.
 */
class PlanController {

	/**
	 * REST namespace.
	 *
	 * @var string
	 */
	const NS = 'wpsubscription/v1';

	/**
	 * Initialize the class.
	 */
	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
		add_filter( 'subscrpt_plan_products', array( $this, 'add_variable_products' ), 10, 2 );
	}

	/**
	 * Register all plan routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		$perm = array( $this, 'check_permission' );

		// Groups, terms and relations CRUD live in the free plugin's controller
		// ( SpringDevs\Subscription\Api\PlanController ), which Pro always runs
		// alongside. Pro registers only its extra routes here so the shared paths
		// are not double-registered.

		register_rest_route(
			self::NS,
			'/plans/detach',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'detach_product' ),
					'permission_callback' => $perm,
				),
			)
		);

		register_rest_route(
			self::NS,
			'/plans/migrate',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'migrate_product' ),
					'permission_callback' => $perm,
				),
			)
		);
	}

	/**
	 * Permission check: WooCommerce manager.
	 *
	 * @return bool|WP_Error
	 */
	public function check_permission() {
		if ( current_user_can( 'manage_woocommerce' ) ) {
			return true;
		}

		return new WP_Error(
			'rest_forbidden',
			__( 'You are not allowed to manage subscription plans.', 'subscription-pro' ),
			array( 'status' => rest_authorization_required_code() )
		);
	}

	/**
	 * Read request params, preferring a JSON body over query / form params.
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return array
	 */
	protected function read_params( WP_REST_Request $request ) {
		$json = $request->get_json_params();

		return ! empty( $json ) ? $json : $request->get_params();
	}

	/**
	 * POST /plans/detach — switch a product from plan mode to classic mode.
	 *
	 * Copies the product's first connected plan term (cadence, trial, signup fee,
	 * payment type, price) into classic per-product `_subscrpt_*` meta, then
	 * removes every plan relation for the product so the editor renders the
	 * classic panel and the storefront uses the classic subscription path.
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return \WP_REST_Response|WP_Error
	 */
	public function detach_product( WP_REST_Request $request ) {
		$params     = $this->read_params( $request );
		$product_id = isset( $params['product_id'] ) ? absint( $params['product_id'] ) : 0;
		$product    = $product_id ? wc_get_product( $product_id ) : null;

		if ( ! $product ) {
			return new WP_Error( 'subscrpt_detach_invalid', __( 'Invalid product.', 'subscription-pro' ), array( 'status' => 400 ) );
		}

		$connections = PlanRepository::get_product_connections( $product_id );

		if ( empty( $connections ) ) {
			return new WP_Error( 'subscrpt_detach_none', __( 'This product is not connected to any plan.', 'subscription-pro' ), array( 'status' => 400 ) );
		}

		// Use the first connected term as the classic configuration source.
		$first = $connections[0];
		$term  = PlanRepository::get_plan( (int) $first['plan_id'] );

		if ( ! $term ) {
			return new WP_Error( 'subscrpt_detach_term', __( 'Could not read the connected plan term.', 'subscription-pro' ), array( 'status' => 500 ) );
		}

		$type_key        = PlanRepository::type_to_string( (int) $first['group_type'] );
		$is_installments = 'installments' === $type_key;
		$rdata           = is_array( $first['relation_data'] ) ? $first['relation_data'] : array();
		$interval_option = PlanRepository::interval_to_option( (int) $term['billing_interval'] );

		// Effective recurring price + signup fee, derived from the plan term.
		if ( $is_installments ) {
			$price      = isset( $rdata['price_per_installment'] ) ? (float) $rdata['price_per_installment'] : (float) $product->get_price();
			$signup_fee = isset( $rdata['down_payment'] ) && (float) $rdata['down_payment'] > 0 ? (string) (float) $rdata['down_payment'] : '';
		} else {
			$regular    = isset( $rdata['regular_price'] ) ? (string) $rdata['regular_price'] : (string) $product->get_regular_price();
			$sale       = isset( $rdata['sale_price'] ) ? (string) $rdata['sale_price'] : '';
			$dtype      = isset( $rdata['discount_type'] ) ? (string) $rdata['discount_type'] : 'percentage';
			$dvalue     = isset( $rdata['discount_value'] ) ? (string) $rdata['discount_value'] : '0';
			$price      = (float) PlanPresenter::offer_price( $regular, $sale, $dtype, $dvalue );
			$fee        = isset( $term['signup_fee']['amount'] ) ? (float) $term['signup_fee']['amount'] : 0.0;
			$signup_fee = $fee > 0 ? (string) $fee : '';
		}

		// Free trial (count + interval).
		$trial_per    = '';
		$trial_option = '';
		if ( '' !== (string) $term['free_trial'] && (int) $term['free_trial'] > 0 ) {
			$trial_per    = (string) (int) $term['free_trial'];
			$trial_option = isset( $term['data']['free_trial_interval'] ) ? (string) $term['data']['free_trial_interval'] : 'days';
		}

		// Installments charge every 1 interval, capped at the installment count.
		$timing_per     = $is_installments ? 1 : max( 1, (int) $term['billing_frequency'] );
		$max_no_payment = $is_installments ? (int) $term['billing_frequency'] : (int) $term['billing_length'];

		$product->set_regular_price( (string) $price );
		if ( '' === (string) $product->get_sale_price() ) {
			$product->set_price( (string) $price );
		}
		$product->update_meta_data( '_subscrpt_enabled', 1 );
		$product->update_meta_data( '_subscrpt_timing_per', (string) $timing_per );
		$product->update_meta_data( '_subscrpt_timing_option', $interval_option );
		$product->update_meta_data( '_subscrpt_trial_timing_per', $trial_per );
		$product->update_meta_data( '_subscrpt_trial_timing_option', $trial_option );
		$product->update_meta_data( '_subscrpt_signup_fee', $signup_fee );
		$product->update_meta_data( '_subscrpt_payment_type', $is_installments ? 'split_payment' : 'recurring' );
		$product->update_meta_data( '_subscrpt_max_no_payment', $max_no_payment );
		$product->save();

		// Remove every plan relation for this product (across all connected terms).
		foreach ( $connections as $conn ) {
			PlanRepository::delete_relation( (int) $conn['relation_id'] );
		}

		return rest_ensure_response(
			array(
				'detached'   => true,
				'product_id' => $product_id,
			)
		);
	}

	/**
	 * POST /plans/migrate — turn a product's classic settings into a plan term.
	 *
	 * Creates a plan term from the product's classic `_subscrpt_*` meta (in a new
	 * group or an existing one), links the product to it at its current price,
	 * and — unless asked to keep the classic settings as a backup — clears them.
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return \WP_REST_Response|WP_Error
	 */
	public function migrate_product( WP_REST_Request $request ) {
		$params     = $this->read_params( $request );
		$product_id = isset( $params['product_id'] ) ? absint( $params['product_id'] ) : 0;
		$product    = $product_id ? wc_get_product( $product_id ) : null;

		if ( ! $product ) {
			return new WP_Error( 'subscrpt_migrate_invalid', __( 'Invalid product.', 'subscription-pro' ), array( 'status' => 400 ) );
		}

		if ( ! get_post_meta( $product_id, '_subscrpt_enabled', true ) ) {
			return new WP_Error( 'subscrpt_migrate_not_classic', __( 'This product has no classic subscription settings to migrate.', 'subscription-pro' ), array( 'status' => 400 ) );
		}

		$keep = ! empty( $params['keep_classic'] );
		$mode = ( isset( $params['mode'] ) && 'existing' === $params['mode'] ) ? 'existing' : 'new';

		// Read classic meta.
		$timing_per    = max( 1, (int) get_post_meta( $product_id, '_subscrpt_timing_per', true ) );
		$timing_option = (string) get_post_meta( $product_id, '_subscrpt_timing_option', true );
		$timing_option = '' !== $timing_option ? $timing_option : 'months';
		$interval_int  = array_flip( PlanRepository::INTERVAL_OPTION )[ $timing_option ] ?? 3;
		$is_split      = 'split_payment' === (string) get_post_meta( $product_id, '_subscrpt_payment_type', true );
		$max_no_pay    = (int) get_post_meta( $product_id, '_subscrpt_max_no_payment', true );
		$signup_amt    = (float) get_post_meta( $product_id, '_subscrpt_signup_fee', true );
		$trial_per     = (int) get_post_meta( $product_id, '_subscrpt_trial_timing_per', true );
		$trial_option  = (string) get_post_meta( $product_id, '_subscrpt_trial_timing_option', true );
		$price         = (string) $product->get_regular_price();

		// Resolve the target group; its type drives the term type.
		if ( 'existing' === $mode ) {
			$group_id = isset( $params['group_id'] ) ? absint( $params['group_id'] ) : 0;
			$group    = $group_id ? PlanRepository::get_group( $group_id ) : null;

			if ( ! $group ) {
				return new WP_Error( 'subscrpt_migrate_group', __( 'Select a valid plan to add this product to.', 'subscription-pro' ), array( 'status' => 400 ) );
			}

			$type_key = PlanRepository::type_to_string( (int) $group['type'] );
		} else {
			$type_key = $is_split ? 'installments' : 'recurring';
			$name     = isset( $params['plan_name'] ) ? sanitize_text_field( $params['plan_name'] ) : '';
			$name     = '' !== $name ? $name : $product->get_name();
			$group_id = PlanRepository::insert_group(
				array(
					'type'         => $type_key,
					'product_type' => 1,
					'title'        => $name,
					'status'       => 'active',
				)
			);

			if ( ! $group_id ) {
				return new WP_Error( 'subscrpt_migrate_group_create', __( 'Could not create the plan.', 'subscription-pro' ), array( 'status' => 500 ) );
			}
		}

		$is_installments = 'installments' === $type_key;

		// Build the term from the classic cadence.
		$term = array(
			'plan_group_id'     => $group_id,
			'title'             => sprintf(
				/* translators: 1: frequency number, 2: interval (day/days, month/months, …). */
				__( 'Every %1$d %2$s', 'subscription-pro' ),
				$timing_per,
				subscrpt_get_typos( $timing_per, $timing_option )
			),
			'type'              => $type_key,
			'billing_frequency' => $is_installments ? max( 1, $max_no_pay ) : $timing_per,
			'billing_interval'  => $interval_int,
			'billing_length'    => $is_installments ? 0 : $max_no_pay,
			'status'            => 'active',
		);

		if ( ! $is_installments && $signup_amt > 0 ) {
			$term['signup_fee'] = array( 'amount' => (string) $signup_amt );
		}
		if ( $trial_per > 0 ) {
			$term['free_trial'] = (string) $trial_per;
			$term['data']       = array( 'free_trial_interval' => '' !== $trial_option ? $trial_option : 'days' );
		}

		$plan_id = PlanRepository::insert_plan( $term );

		if ( ! $plan_id ) {
			return new WP_Error( 'subscrpt_migrate_term', __( 'Could not create the plan term.', 'subscription-pro' ), array( 'status' => 500 ) );
		}

		// Link the product at its current price.
		$relation_data = $is_installments
			? array(
				'price_per_installment' => $price,
				'down_payment'          => $signup_amt > 0 ? (string) $signup_amt : '',
			)
			: array(
				'regular_price' => $price,
				'sale_price'    => '',
			);

		$relation_id = PlanRepository::insert_relation(
			array(
				'plan_id' => $plan_id,
				'oid'     => $product_id,
				'vid'     => 0,
				'type'    => PlanRepository::REL_PRODUCT,
				'status'  => 'active',
				'exclude' => 0,
				'data'    => $relation_data,
			)
		);

		if ( ! $relation_id ) {
			return new WP_Error( 'subscrpt_migrate_relation', __( 'Could not link the product to the plan.', 'subscription-pro' ), array( 'status' => 500 ) );
		}

		// Clear classic meta unless kept as a backup.
		if ( ! $keep ) {
			foreach ( array(
				'_subscrpt_enabled',
				'_subscrpt_timing_per',
				'_subscrpt_timing_option',
				'_subscrpt_trial_timing_per',
				'_subscrpt_trial_timing_option',
				'_subscrpt_signup_fee',
				'_subscrpt_payment_type',
				'_subscrpt_max_no_payment',
			) as $meta_key ) {
				$product->delete_meta_data( $meta_key );
			}
			$product->save();
		}

		return rest_ensure_response(
			array(
				'migrated'   => true,
				'product_id' => $product_id,
				'group_id'   => (int) $group_id,
				'plan_id'    => (int) $plan_id,
			)
		);
	}

	/* ---- Product picker ---- */

	/**
	 * Append variable products to the free product-picker results.
	 *
	 * Free's picker (subscrpt_plan_products) returns simple products only; Pro
	 * adds variable products on top via this filter.
	 *
	 * @param array  $results Product rows from the free base.
	 * @param string $search  Current search term.
	 *
	 * @return array
	 */
	public function add_variable_products( $results, $search ) {
		if ( ! function_exists( 'wc_get_products' ) || ! class_exists( '\SpringDevs\Subscription\Api\PlanController' ) ) {
			return $results;
		}

		$products = wc_get_products(
			array(
				'status'  => 'publish',
				'type'    => 'variable',
				'limit'   => 20,
				'return'  => 'objects',
				's'       => (string) $search,
				'orderby' => 'title',
				'order'   => 'ASC',
			)
		);

		foreach ( $products as $product ) {
			$row = FreePlanController::product_row( $product );

			// Nest each variation under its parent so the picker can offset them
			// and check them all when the parent is selected.
			foreach ( $product->get_children() as $variation_id ) {
				$variation = wc_get_product( $variation_id );
				if ( ! $variation || ! $variation->exists() ) {
					continue;
				}

				$attributes = array_filter( array_values( $variation->get_variation_attributes() ) );
				$name       = $product->get_name() . ( $attributes ? ' - ' . implode( ', ', $attributes ) : '' );

				$row['variations'][] = FreePlanController::product_row( $variation, $name );
			}

			$results[] = $row;
		}

		return $results;
	}
}
