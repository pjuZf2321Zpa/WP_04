<?php
/**
 * The Boxes screen.
 *
 * Two jobs on one menu entry. **Boxes** is where a box is made and edited — the
 * list, and the detail screen behind each row. **Upcoming** and **Pick list**
 * are the daily work across every box: what ships soon, and how many of each
 * product that adds up to.
 *
 * Free registers the menu entry, renders the page header, and fires
 * `subscrpt_render_boxes_page` for pro to fill the body. That is why nothing
 * here renders a page header of its own — the page would carry two.
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

namespace SpringDevs\SubscriptionPro\Admin;

use SpringDevs\SubscriptionPro\Frontend\BoxTogetherSection;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxCycle;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxDurations;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxPool;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxProduct;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxSelling;
use SpringDevs\SubscriptionPro\Illuminate\Box\EditionRepository;
use SpringDevs\SubscriptionPro\Illuminate\Box\ShipmentRepository;

defined( 'ABSPATH' ) || exit;

/**
 * The box list, the box detail, and the two operational views.
 */
class Boxes {

	/**
	 * The page slug free registers.
	 */
	const PAGE = 'wp-subscription-boxes';

	/**
	 * Register hooks.
	 */
	public function __construct() {
		add_action( 'subscrpt_render_boxes_page', array( $this, 'render' ) );
		add_filter( 'subscrpt_admin_header_menu_items', array( $this, 'add_menu_item' ), 10, 2 );
		add_action( 'admin_init', array( $this, 'maybe_handle_actions' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
		add_action( 'wp_ajax_subscrpt_box_search_link_products', array( $this, 'search_link_products' ) );
	}

	/**
	 * Add Boxes to the WPSubscription admin header menu.
	 *
	 * @param array  $menu_items Menu items.
	 * @param string $current    Current item.
	 *
	 * @return array
	 */
	public function add_menu_item( $menu_items, $current ) {
		$menu_items[] = array(
			'slug'  => self::PAGE,
			'label' => __( 'Boxes', 'subscription-pro' ),
			'url'   => admin_url( 'admin.php?page=' . self::PAGE ),
		);

		return $menu_items;
	}

	/**
	 * Load the screen's styles and scripts.
	 *
	 * The shared `wpsubs-*` component bundle comes from the free plugin, which
	 * is a hard dependency — the screen is built on it rather than restyling
	 * the same table and modal again.
	 *
	 * @param string $hook Current admin page.
	 *
	 * @return void
	 */
	public function enqueue( $hook ): void {
		if ( false === strpos( (string) $hook, self::PAGE ) ) {
			return;
		}

		wp_enqueue_style( 'subscrpt_admin_components' );
		wp_enqueue_script( 'subscrpt_admin_components' );
		wp_enqueue_style( 'subscrpt_box_admin_css' );
		wp_enqueue_style( 'subscrpt_box_workspace' );
		wp_enqueue_script( 'wc-enhanced-select' );
		wp_enqueue_style( 'woocommerce_admin_styles' );

		wp_enqueue_script(
			'subscrpt_admin_boxes_js',
			SUBSCRIPT_PRO_URL . '/assets/js/admin/boxes.js',
			array( 'subscrpt_admin_components' ),
			SUBSCRIPT_PRO_VERSION,
			true
		);

		wp_localize_script(
			'subscrpt_admin_boxes_js',
			'subscrptBoxes',
			array(
				'restUrl' => esc_url_raw( rest_url( 'wpsubscription/v1/boxes' ) ),
				'nonce'   => wp_create_nonce( 'wp_rest' ),
				'listUrl' => admin_url( 'admin.php?page=' . self::PAGE ),
				'i18n'    => array(
					'saved'           => __( 'Saved.', 'subscription-pro' ),
					'deleted'         => __( 'Deleted.', 'subscription-pro' ),
					'nameRequired'    => __( 'Give the box a name.', 'subscription-pro' ),
					'genericError'    => __( 'Something went wrong. Please try again.', 'subscription-pro' ),
					'selectShipments' => __( 'Tick at least one box first.', 'subscription-pro' ),
					'pickFirst'       => __( 'Pick a product in the empty row first.', 'subscription-pro' ),
					'loading'         => __( 'Loading…', 'subscription-pro' ),
					'noProducts'      => __( 'No products found.', 'subscription-pro' ),
					'remove'          => __( 'Remove', 'subscription-pro' ),
					'sellsBox'        => __( 'Sells a box', 'subscription-pro' ),
					'notForSale'      => __( 'Not for sale', 'subscription-pro' ),
					/* translators: %d: number of products in the box's pool. */
					'poolCount'       => __( '%d products', 'subscription-pro' ),
					/* translators: %d: number of products ticked in the picker. */
					'picked'          => __( '%d selected', 'subscription-pro' ),
					/* translators: %d: number of variations of one product. */
					'variations'      => __( '%d variations', 'subscription-pro' ),
					/* translators: 1: variations ticked, 2: variations the product has. */
					'variantsPicked'  => __( '%1$d of %2$d selected', 'subscription-pro' ),
					/* translators: 1: variations in the box, 2: variations listed. */
					'variantsIn'      => __( '%1$d of %2$d in the box', 'subscription-pro' ),
					'published'       => __( 'Published. The box and its product are on sale.', 'subscription-pro' ),
					'drafted'         => __( 'Moved to draft. The product is hidden from the shop.', 'subscription-pro' ),
					'duplicated'      => __( 'Box copied as a draft.', 'subscription-pro' ),
					'productLinked'   => __( 'Product linked. The one it replaced is now a draft.', 'subscription-pro' ),
					'productCreated'  => __( 'Created and linked a new draft product.', 'subscription-pro' ),
					'productUnlinked' => __( 'Product unlinked and set to Draft.', 'subscription-pro' ),
					'durationAdded'   => __( 'Duration added.', 'subscription-pro' ),
					'durationSaved'   => __( 'Duration saved.', 'subscription-pro' ),
					'durationRemoved' => __( 'Duration removed.', 'subscription-pro' ),
					'planLinked'      => __( 'Now using the shared plan.', 'subscription-pro' ),
					'ownDurations'    => __( 'Back to this box’s own durations.', 'subscription-pro' ),
					'pickProduct'     => __( 'Pick a product first.', 'subscription-pro' ),
					'pickPlan'        => __( 'Choose a plan first.', 'subscription-pro' ),
					'confirmDuration' => __( 'Remove this duration? Subscriptions already on it keep renewing.', 'subscription-pro' ),
					'boxDeleted'      => __( 'Box deleted.', 'subscription-pro' ),
					/* translators: %d: products left out. */
					'leftOut'         => __( 'Left out %d products', 'subscription-pro' ),
					/* translators: %d: products put back. */
					'putBack'         => __( 'Put %d products back', 'subscription-pro' ),
					/* translators: %d: matching products still in the box. */
					'leaveOutThese'   => __( 'Leave out these %d', 'subscription-pro' ),
					/* translators: %d: matching products left out. */
					'putTheseBack'    => __( 'Put these %d back', 'subscription-pro' ),
					/* translators: 1: first row shown, 2: last row shown, 3: total. */
					'showing'         => __( 'Showing %1$d–%2$d of %3$d', 'subscription-pro' ),
					/* translators: 1: page, 2: pages. */
					'pageOf'          => __( 'Page %1$d of %2$d', 'subscription-pro' ),
					/* translators: %d: products in the list. */
					'searchCount'     => __( 'Search %d products', 'subscription-pro' ),
					'noMatch'         => __( 'No products match.', 'subscription-pro' ),
					'noneLeftOut'     => __( 'Nothing is left out. Every product here is in the box.', 'subscription-pro' ),
					'leftOutBadge'    => __( 'Left out', 'subscription-pro' ),
					'inBox'           => __( 'In the box', 'subscription-pro' ),
					'openProduct'     => __( 'Open in WooCommerce', 'subscription-pro' ),
					'zeroProducts'    => __( '0 products', 'subscription-pro' ),
					/* translators: %s: product name. */
					'inBoxLabel'      => __( '%s in the box', 'subscription-pro' ),
					/* translators: %s: product name. */
					'removeLabel'     => __( 'Remove %s', 'subscription-pro' ),
					'pickCategory'    => __( 'Choose at least one category above.', 'subscription-pro' ),
					/* translators: 1: the example box, e.g. "a box of 5 items worth $60.00", 2: discount taken, 3: what the customer pays. */
					'exampleTier'     => __( 'Example: %1$s reaches a tier and takes %2$s off. The customer pays %3$s each delivery.', 'subscription-pro' ),
					/* translators: 1: the example box, 2: what the customer pays. */
					'exampleNone'     => __( 'Example: %1$s gets no discount yet. The customer pays %2$s each delivery.', 'subscription-pro' ),
					/* translators: 1: number of items, 2: their worth. */
					'exampleItems'    => __( 'a box of %1$d items worth %2$s', 'subscription-pro' ),
					/* translators: %s: the box's worth. */
					'exampleAmount'   => __( 'a box worth %s', 'subscription-pro' ),
					/* translators: %s: base price added to every box. */
					'exampleBase'     => __( 'That includes the %s base price.', 'subscription-pro' ),
					'unsaved'         => __( 'You have unsaved changes.', 'subscription-pro' ),
					'deleteTrash'     => __( 'Delete box and trash product', 'subscription-pro' ),
					'deleteKeep'      => __( 'Delete box, keep product', 'subscription-pro' ),
					'deleteOnly'      => __( 'Delete box', 'subscription-pro' ),
					/* translators: %s: box name. */
					'deleteTitle'     => __( 'Delete "%s"?', 'subscription-pro' ),
					/* translators: %d: subscriptions still renewing. */
					'deleteSubs'      => __( '%d active subscriptions keep their contents and renew', 'subscription-pro' ),
					'deleteSubsOne'   => __( '1 active subscription keeps its contents and renews', 'subscription-pro' ),
					/* translators: %d: categories chosen. */
					'catsSelected'    => __( '%d selected', 'subscription-pro' ),
					/* translators: %d: products chosen. */
					'chosenCount'     => __( '%d chosen products', 'subscription-pro' ),
					'chosenOne'       => __( '1 chosen product', 'subscription-pro' ),
				),
				'currency' => html_entity_decode( get_woocommerce_currency_symbol(), ENT_QUOTES, 'UTF-8' ),
				'decimals' => wc_get_price_decimals(),
			)
		);
	}

	/**
	 * Products the "Use another product" modal can link.
	 *
	 * WooCommerce's own search skips drafts, yet a box's product is often one —
	 * linking or unlinking a box sets its product to Draft. Each result carries
	 * its slug and, when not published, its status, so two products with the
	 * same name can be told apart. Answers in the shape `wc-enhanced-select`
	 * reads: id => label.
	 *
	 * @return void
	 */
	public function search_link_products(): void {
		check_ajax_referer( 'search-products', 'security' );

		if ( ! current_user_can( 'edit_products' ) ) {
			wp_die( -1 );
		}

		$term = isset( $_GET['term'] ) ? sanitize_text_field( wp_unslash( $_GET['term'] ) ) : '';

		if ( '' === $term ) {
			wp_die();
		}

		$statuses = static function () {
			return [ 'publish', 'private', 'draft', 'pending', 'future' ];
		};

		add_filter( 'woocommerce_search_products_post_statuses', $statuses );
		$ids = \WC_Data_Store::load( 'product' )->search_products( $term, '', false, false, 30 );
		remove_filter( 'woocommerce_search_products_post_statuses', $statuses );

		$products = [];

		foreach ( $ids as $id ) {
			$product = wc_get_product( $id );

			if ( ! $product || ! wc_products_array_filter_readable( $product ) ) {
				continue;
			}

			$label = rawurldecode( wp_strip_all_tags( $product->get_formatted_name() ) );

			// A draft has no slug until it is first published.
			if ( $product->get_slug() ) {
				$label .= ' · ' . rawurldecode( $product->get_slug() );
			}

			if ( 'publish' !== $product->get_status() ) {
				$status = get_post_status_object( $product->get_status() );
				$label .= ' · ' . ( $status ? $status->label : $product->get_status() );
			}

			$products[ $product->get_id() ] = $label;
		}

		wp_send_json( $products );
	}

	/**
	 * Handle the screen's form posts and the CSV export.
	 *
	 * Boxes themselves are written through REST. What is left here is the CSV
	 * download, which is a file response rather than a fetch, and the edition
	 * planner's posts until the Editions tab moves onto REST too.
	 *
	 * @return void
	 */
	public function maybe_handle_actions(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! isset( $_GET['page'] ) || self::PAGE !== sanitize_text_field( wp_unslash( $_GET['page'] ) ) ) {
			return;
		}

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['subscrpt_action'] ) && 'pick_list_csv' === sanitize_text_field( wp_unslash( $_GET['subscrpt_action'] ) ) ) {
			$this->export_pick_list();
		}

		if ( empty( $_POST['subscrpt_box_edition_action'] ) ) {
			return;
		}

		$action = sanitize_text_field( wp_unslash( $_POST['subscrpt_box_edition_action'] ) );

		if ( ! isset( $_POST['subscrpt_box_edition_nonce'] )
			|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['subscrpt_box_edition_nonce'] ) ), 'subscrpt_box_edition' ) ) {
			return;
		}

		// Named for the box, because that is what it carries. It was called
		// `..._product` while editions were keyed on the product, and the field
		// kept the name after the meaning changed — which is most of how the
		// admin and the storefront ended up disagreeing about what an edition
		// belongs to.
		$box_id    = absint( $_POST['subscrpt_box_edition_box'] ?? 0 );
		$cycle_key = sanitize_text_field( wp_unslash( $_POST['subscrpt_box_edition_cycle'] ?? '' ) );

		if ( 'publish' === $action ) {
			$edition_id = absint( $_POST['subscrpt_box_edition_id'] ?? 0 );

			if ( $edition_id ) {
				EditionRepository::publish( $edition_id );
			}
		} elseif ( 'save' === $action && $box_id && $cycle_key ) {
			$contents = array();

			$posted_contents = isset( $_POST['subscrpt_box_edition_contents'] )
				? array_map( 'absint', (array) wp_unslash( $_POST['subscrpt_box_edition_contents'] ) )
				: array();

			foreach ( $posted_contents as $content_id ) {
				$contents[] = array(
					'product_id' => $content_id,
					'qty'        => 1,
				);
			}

			EditionRepository::save(
				array(
					'box_id'    => $box_id,
					'cycle_key' => $cycle_key,
					'title'     => sanitize_text_field( wp_unslash( $_POST['subscrpt_box_edition_title'] ?? '' ) ),
					'contents'  => $contents,
					'swap_pool' => array_map( 'absint', (array) ( $_POST['subscrpt_box_edition_pool'] ?? array() ) ),
				)
			);
		}

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'    => self::PAGE,
					'view'    => 'detail',
					'box'     => $box_id,
					'dtab'    => 'editions',
					'cycle'   => $cycle_key,
					'updated' => 1,
				),
				admin_url( 'admin.php' )
			) . '#subscrpt-edition-' . rawurlencode( $cycle_key )
		);
		exit;
	}

	/**
	 * The detail tabs this box has, in order.
	 *
	 * Editions exist only on an edition box. Together offers picks from the
	 * pool, and only a build-your-own box keeps them — a curated or edition
	 * box is bought with its own contents whatever the section suggested.
	 *
	 * @param array $box BoxPresenter::find().
	 *
	 * @return string[]
	 */
	private static function detail_tabs( array $box ): array {
		$tabs = array( 'contents', 'durations', 'pricing', 'rules' );

		if ( BoxProduct::TYPE_BUILD === $box['type'] ) {
			$tabs[] = 'together';
		}

		if ( BoxProduct::TYPE_EDITION === $box['type'] ) {
			$tabs[] = 'editions';
		}

		return $tabs;
	}

	/**
	 * Render the screen: the box detail, or the list with its three tabs.
	 *
	 * @return void
	 */
	public function render(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only view routing.
		$view    = isset( $_GET['view'] ) ? sanitize_key( wp_unslash( $_GET['view'] ) ) : 'list';
		$box_id  = isset( $_GET['box'] ) ? absint( $_GET['box'] ) : 0;
		$tab     = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'boxes';
		$dtab    = isset( $_GET['dtab'] ) ? sanitize_key( wp_unslash( $_GET['dtab'] ) ) : 'contents';
		$updated = ! empty( $_GET['updated'] );
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		$list_url = admin_url( 'admin.php?page=' . self::PAGE );

		if ( 'detail' === $view && $box_id ) {
			$box = BoxPresenter::find( $box_id );

			if ( $box ) {
				$tabs    = self::detail_tabs( $box );
				$dtab    = in_array( $dtab, $tabs, true ) ? $dtab : 'contents';
				$pairs   = 'together' === $dtab ? BoxPresenter::top_pairs( $box_id ) : array();
				$cycles  = 'editions' === $dtab ? EditionRepository::upcoming( $box_id, 6 ) : array();
				$choices = 'editions' === $dtab ? $this->pool_choices( $box_id ) : array();

				$categories  = 'contents' === $dtab ? BoxPool::categories() : array();
				$plan_groups = 'durations' === $dtab ? BoxDurations::shared_groups() : array();
				$position    = get_option( BoxTogetherSection::OPTION, BoxTogetherSection::BEFORE_TABS );
				$live_subs   = BoxSelling::live_subscriptions( $box['product'] ? (int) $box['product']['id'] : 0 );

				include SUBSCRIPT_PRO_PATH . '/templates/admin/boxes/detail.php';

				return;
			}

			// The box was deleted from another tab. Fall through to the list
			// rather than showing an empty detail screen for nothing.
		}

		$tab   = in_array( $tab, array( 'boxes', 'upcoming', 'picks' ), true ) ? $tab : 'boxes';
		$boxes = 'boxes' === $tab ? BoxPresenter::all() : array();

		foreach ( $boxes as $index => $listed ) {
			$boxes[ $index ]['live_subs'] = BoxSelling::live_subscriptions( $listed['product'] ? (int) $listed['product']['id'] : 0 );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only view filters.
		$cycle  = isset( $_GET['cycle'] ) ? sanitize_text_field( wp_unslash( $_GET['cycle'] ) ) : BoxCycle::current();
		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
		$box_of = isset( $_GET['box_id'] ) ? absint( $_GET['box_id'] ) : 0;
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		$cycle     = BoxCycle::start( $cycle ) ? $cycle : BoxCycle::current();
		$upcoming  = array();
		$pick_list = array();
		$cycles    = array();
		$counts    = array();
		$box_list  = array();

		if ( 'boxes' !== $tab ) {
			// Both operational tabs read shipments now. A merchant packs a month,
			// not "the next fourteen days" — and a rolling horizon could never
			// show a box that failed or was skipped, because it asked
			// subscriptions when they renewed rather than asking what shipped.
			$upcoming = ShipmentPresenter::all(
				array(
					'cycle_key' => $cycle,
					'status'    => $status ? array( $status ) : array(),
					'box_id'    => $box_of,
					'search'    => $search,
					'limit'     => 500,
				)
			);

			$cycles   = ShipmentPresenter::cycles();
			$counts   = ShipmentPresenter::counts( $cycle, (int) $box_of );
			$box_list = ShipmentPresenter::box_choices();
		}

		if ( 'picks' === $tab ) {
			// A skipped box is not packed, and a failed one is not ready to be.
			$pick_list = $this->pick_list( self::packable( $upcoming ) );
		}

		include SUBSCRIPT_PRO_PATH . '/templates/admin/boxes/list.php';
	}

	/**
	 * The shipments a picker should actually put on the bench.
	 *
	 * A skipped cycle ships nothing, and a failed one is not ready to ship, so
	 * neither belongs in the totals a warehouse packs from. They stay visible on
	 * the Upcoming tab — that is the whole point of recording them — but they
	 * must not inflate what someone is told to pick.
	 *
	 * A box bought once is recorded when the order is placed, before any money
	 * has moved, so it is packed only while its order has a paid status: held
	 * back while pending or on hold (bank transfer, cheque), joining the list on
	 * its own once paid, and leaving it again if the order is cancelled,
	 * refunded or trashed. With no order there is nothing to say it was paid.
	 * A subscription's box is judged by its shipment alone.
	 *
	 * @param array[] $shipments Presented shipments.
	 *
	 * @return array[]
	 */
	public static function packable( array $shipments ): array {
		return array_values(
			array_filter(
				$shipments,
				static function ( $row ) {
					if ( in_array( $row['status'], array( ShipmentRepository::STATUS_SKIPPED, ShipmentRepository::STATUS_FAILED ), true ) ) {
						return false;
					}

					if ( 0 !== (int) $row['subscription_id'] ) {
						return true;
					}

					$order = wc_get_order( (int) $row['order_id'] );

					return $order instanceof \WC_Order && $order->has_status( wc_get_is_paid_statuses() );
				}
			)
		);
	}

	/**
	 * The pool of a box, as id => name, for the edition planner.
	 *
	 * @param int $box_id Box id.
	 *
	 * @return array
	 */
	private function pool_choices( int $box_id ): array {
		$choices = array();

		$box = \SpringDevs\SubscriptionPro\Illuminate\Box\BoxRepository::find( $box_id );

		if ( ! $box ) {
			return $choices;
		}

		foreach ( $box->pool_product_ids() as $pool_id ) {
			$product = wc_get_product( $pool_id );

			if ( $product ) {
				$choices[ $pool_id ] = $product->get_name();
			}
		}

		return $choices;
	}


	/**
	 * What all those boxes add up to.
	 *
	 * @param array[] $upcoming Shipments for the cycle, skipped and failed already removed.
	 *
	 * @return array[] Each entry: product_id, name, sku, units, stock, short.
	 */
	public function pick_list( array $upcoming ): array {
		$totals = array();

		foreach ( $upcoming as $row ) {
			foreach ( BoxProduct::normalise_items( $row['contents'] ) as $item ) {
				$key = $item['variation_id'] ? $item['variation_id'] : $item['product_id'];

				if ( ! isset( $totals[ $key ] ) ) {
					$totals[ $key ] = 0;
				}

				$totals[ $key ] += (int) $item['qty'];
			}
		}

		$list = array();

		foreach ( $totals as $product_id => $units ) {
			$product = wc_get_product( $product_id );

			if ( ! $product instanceof \WC_Product ) {
				continue;
			}

			$stock = $product->managing_stock() ? (int) $product->get_stock_quantity() : null;

			$list[] = array(
				'product_id' => (int) $product_id,
				'name'       => $product->get_name(),
				'sku'        => $product->get_sku(),
				'units'      => $units,
				'stock'      => $stock,
				'short'      => null === $stock ? 0 : max( 0, $units - $stock ),
			);
		}

		usort(
			$list,
			static function ( $a, $b ) {
				$by_shortfall = $b['short'] <=> $a['short'];

				return 0 !== $by_shortfall ? $by_shortfall : strcasecmp( $a['name'], $b['name'] );
			}
		);

		return $list;
	}

	/**
	 * Send the pick list as CSV.
	 *
	 * @return void
	 */
	private function export_pick_list(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$cycle  = isset( $_GET['cycle'] ) ? sanitize_text_field( wp_unslash( $_GET['cycle'] ) ) : '';
		$box_of = isset( $_GET['box_id'] ) ? absint( $_GET['box_id'] ) : 0;
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		$cycle = BoxCycle::start( $cycle ) ? $cycle : BoxCycle::current();

		$list = $this->pick_list(
			self::packable(
				ShipmentPresenter::all(
					array(
						'cycle_key' => $cycle,
						'box_id'    => $box_of,
						'limit'     => 500,
					)
				)
			)
		);

		nocache_headers();
		header( 'Content-Type: text/csv; charset=' . get_option( 'blog_charset' ) );
		header( 'Content-Disposition: attachment; filename=box-pick-list-' . $cycle . '.csv' );

		$out = fopen( 'php://output', 'w' );

		fputcsv(
			$out,
			array(
				__( 'Product', 'subscription-pro' ),
				__( 'SKU', 'subscription-pro' ),
				__( 'Units to pack', 'subscription-pro' ),
				__( 'In stock', 'subscription-pro' ),
				__( 'Short by', 'subscription-pro' ),
			)
		);

		foreach ( $list as $row ) {
			fputcsv(
				$out,
				array(
					$row['name'],
					$row['sku'],
					$row['units'],
					null === $row['stock'] ? __( 'Not tracked', 'subscription-pro' ) : $row['stock'],
					$row['short'],
				)
			);
		}

		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		exit;
	}
}
