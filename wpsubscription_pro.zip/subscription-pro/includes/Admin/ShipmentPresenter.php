<?php
/**
 * Shipments, in the shape the warehouse screens read.
 *
 * Same arrangement as `BoxPresenter`: the views get names, labels, counts and
 * URLs already resolved, so a template stays markup. It also keeps one promise
 * in one place — that a shipment's own states are the only ones we write, and
 * that shipped and delivered are read from the order rather than stored.
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

namespace SpringDevs\SubscriptionPro\Admin;

use SpringDevs\SubscriptionPro\Illuminate\Box\BoxCart;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxCycle;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxProduct;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxRepository;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxSubscription;
use SpringDevs\SubscriptionPro\Illuminate\Box\ShipmentRepository;

defined( 'ABSPATH' ) || exit;

/**
 * Turns shipments into what the Upcoming and Pick list tabs render.
 */
class ShipmentPresenter {

	/**
	 * Shipments for a cycle, filtered the way the screen filters them.
	 *
	 * @param array $args cycle_key, status, box_id, search.
	 *
	 * @return array[]
	 */
	public static function all( array $args = array() ): array {
		$rows   = array();
		$search = strtolower( trim( (string) ( $args['search'] ?? '' ) ) );

		foreach ( ShipmentRepository::all( $args ) as $shipment ) {
			$row = self::present( $shipment );

			// Searching is on the customer, because that is what a merchant has
			// in front of them when someone emails about their box.
			if ( '' !== $search ) {
				$haystack = strtolower( $row['customer'] . ' ' . $row['email'] . ' ' . $row['box'] );

				if ( false === strpos( $haystack, $search ) ) {
					continue;
				}
			}

			$rows[] = $row;
		}

		return $rows;
	}

	/**
	 * One shipment as a view reads it.
	 *
	 * @param array $shipment Shipment row.
	 *
	 * @return array
	 */
	public static function present( array $shipment ): array {
		$subscription_id = (int) $shipment['subscription_id'];
		$one_time        = 0 === $subscription_id;
		$box             = $shipment['box_id'] ? BoxRepository::find( (int) $shipment['box_id'] ) : null;
		$product         = $shipment['product_id'] ? wc_get_product( (int) $shipment['product_id'] ) : null;
		$order           = $shipment['order_id'] ? wc_get_order( (int) $shipment['order_id'] ) : null;

		$customer = $one_time ? self::order_customer( $order ) : self::subscription_customer( $subscription_id );
		$name     = __( '(deleted box)', 'subscription-pro' );

		if ( $box ) {
			$name = $box->title();
		} elseif ( $product instanceof \WC_Product ) {
			// A box sold before it became a record still has a product to name
			// it by, which is better than telling the warehouse nothing.
			$name = $product->get_name();
		}

		return array_merge(
			$shipment,
			array(
				'customer'         => $customer['name'],
				'email'            => $customer['email'],
				'is_one_time'      => $one_time,
				'box'              => $name,
				'size'             => BoxProduct::count_units( $shipment['contents'] ),
				'summary'          => BoxCart::contents_summary( $shipment['contents'] ),
				'locked'           => $one_time ? false : BoxSubscription::is_locked( $subscription_id ),
				'lock'             => $one_time ? 0 : BoxSubscription::lock_timestamp( $subscription_id ),
				'ships_at_ts'      => $shipment['ships_at'] ? (int) strtotime( (string) $shipment['ships_at'] ) : 0,
				'dispatched'       => ShipmentRepository::is_dispatched( $shipment ),
				'order_url'        => $order instanceof \WC_Order ? $order->get_edit_order_url() : '',
				'order_number'     => $order instanceof \WC_Order ? $order->get_order_number() : '',
				'order_status'     => $order instanceof \WC_Order ? wc_get_order_status_name( $order->get_status() ) : '',
				'subscription_url' => $one_time ? '' : (string) get_edit_post_link( $subscription_id, 'raw' ),
				'is_failed'        => ShipmentRepository::STATUS_FAILED === $shipment['status'],
				'is_skipped'       => ShipmentRepository::STATUS_SKIPPED === $shipment['status'],
			)
		);
	}

	/**
	 * Who a subscription's box is for: the subscription's own customer.
	 *
	 * @param int $subscription_id Subscription id.
	 *
	 * @return array name, email.
	 */
	private static function subscription_customer( int $subscription_id ): array {
		$user = get_userdata( (int) get_post_field( 'post_author', $subscription_id ) );

		return array(
			'name'  => $user ? $user->display_name : __( 'Guest', 'subscription-pro' ),
			'email' => $user ? $user->user_email : '',
		);
	}

	/**
	 * Who a box bought once is for: whoever paid for the order, since there is
	 * no subscription to ask. A guest checkout still has a billing name.
	 *
	 * @param \WC_Order|false|null $order The purchase order.
	 *
	 * @return array name, email.
	 */
	private static function order_customer( $order ): array {
		if ( ! $order instanceof \WC_Order ) {
			return array(
				'name'  => __( 'Guest', 'subscription-pro' ),
				'email' => '',
			);
		}

		$name  = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
		$email = $order->get_billing_email();
		$user  = $order->get_customer_id() ? get_userdata( $order->get_customer_id() ) : false;

		if ( '' === $name && $user ) {
			$name = $user->display_name;
		}

		if ( '' === $email && $user ) {
			$email = $user->user_email;
		}

		return array(
			'name'  => '' !== $name ? $name : __( 'Guest', 'subscription-pro' ),
			'email' => $email,
		);
	}

	/**
	 * The cycles worth offering in a filter.
	 *
	 * Whatever has shipments, plus the next few months, so a merchant can look
	 * back at what went out and forward at what is coming.
	 *
	 * @return array[] Each entry: key, label.
	 */
	public static function cycles(): array {
		global $wpdb;

		$table = ShipmentRepository::table();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$known = $wpdb->get_col( "SELECT DISTINCT cycle_key FROM {$table} ORDER BY cycle_key DESC" );

		$cycles = array();

		foreach ( BoxCycle::upcoming( 3 ) as $cycle ) {
			$cycles[ $cycle['key'] ] = $cycle;
		}

		foreach ( (array) $known as $key ) {
			$cycles[ $key ] = array(
				'key'   => (string) $key,
				'label' => BoxCycle::label( (string) $key ),
			);
		}

		krsort( $cycles );

		return array_values( $cycles );
	}

	/**
	 * Boxes worth offering in a filter — the ones that actually ship.
	 *
	 * @return array<int,string>
	 */
	public static function box_choices(): array {
		$choices = array();

		foreach ( BoxRepository::all( array( 'status' => 'any' ) ) as $box ) {
			$choices[ $box->id() ] = $box->title();
		}

		return $choices;
	}

	/**
	 * How many shipments sit in each state for a cycle, with their labels.
	 *
	 * @param string $cycle_key Cycle key.
	 * @param int    $box_id    Box filter, or 0 for every box.
	 *
	 * @return array[] Each entry: status, label, count.
	 */
	public static function counts( string $cycle_key, int $box_id = 0 ): array {
		$counts = ShipmentRepository::counts_for_cycle( $cycle_key, $box_id );
		$out    = array();

		foreach ( $counts as $status => $count ) {
			$out[] = array(
				'status' => $status,
				'label'  => ShipmentRepository::status_label( $status ),
				'count'  => (int) $count,
			);
		}

		return $out;
	}
}
