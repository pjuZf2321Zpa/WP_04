<?php
/**
 * License notice and update wiring.
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

namespace SpringDevs\SubscriptionPro\Admin;

/**
 * Class Update
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */
class Update {

	/**
	 * User meta holding the session token that dismissed the notice.
	 *
	 * The token, not a boolean: WordPress issues a new session token on every
	 * login, so a stored token that no longer matches the current one means the
	 * dismissal belonged to a previous login and the notice is due again. That
	 * is "dismissed for this login" without a cleanup hook to forget.
	 */
	const DISMISSED_META = '_subscrpt_pro_license_notice_dismissed';

	/**
	 * AJAX action used to record the dismissal.
	 */
	const DISMISS_ACTION = 'subscrpt_pro_dismiss_license_notice';

	/**
	 * Initialize the class
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'update_plugin' ) );
		add_action( 'admin_notices', array( $this, 'license_notice' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_notice_assets' ) );
		add_action( 'wp_ajax_' . self::DISMISS_ACTION, array( $this, 'handle_dismiss' ) );
		add_filter( 'sdevs_pro_plugins', array( $this, 'register_plugins' ) );

		// Supplies the licence state to the free plugin's admin header, which
		// cannot ask for it directly — free must never name a symbol pro
		// declares, because it runs alone on nearly every install.
		add_filter( 'subscrpt_admin_header_license', array( $this, 'header_license_state' ) );
	}

	/**
	 * Initialize Update Package
	 */
	public function update_plugin() {
		// No-op: Updater is now handled by SureCart SDK.
	}

	/**
	 * Memoised result of the licence check for this request.
	 *
	 * @var bool|null
	 */
	private static $license_active = null;

	/**
	 * Whether the license is currently valid.
	 *
	 * Memoised, and it matters: `License::is_valid()` performs an HTTP request
	 * to the licence server whenever a key is stored, and caches the answer on
	 * the client instance — but `check_pro_license_or_alert()` constructs a new
	 * client on every call, so that cache never survives. Without this, deciding
	 * whether to show one admin notice made the request two or three times on
	 * every admin page load of a licensed site.
	 *
	 * @return bool
	 */
	private function is_license_active(): bool {
		if ( null === self::$license_active ) {
			self::$license_active = (bool) \Sdevs_Wc_Subscription_Pro::check_pro_license_or_alert( false, false );
		}

		return self::$license_active;
	}

	/**
	 * Report the licence state to the free plugin's admin header.
	 *
	 * @param mixed $state Incoming value, ignored.
	 * @return array{active: bool, url: string}
	 */
	public function header_license_state( $state ): array {
		unset( $state );

		return array(
			'active' => $this->is_license_active(),
			'url'    => admin_url( 'admin.php?page=wp-subscription-license' ),
		);
	}

	/**
	 * Whether the current screen belongs to WPSubscription.
	 *
	 * The notice is redundant on this plugin's own pages: they already show the
	 * licence gate in place of their content, and the licence page itself is
	 * where the notice sends you. It is only useful elsewhere in wp-admin.
	 *
	 * @return bool
	 */
	private function is_own_screen(): bool {
		$screen = get_current_screen();

		if ( ! $screen ) {
			return false;
		}

		return 'toplevel_page_wp-subscription' === $screen->id
			|| str_starts_with( $screen->id, 'wpsubscription_page' )
			|| str_starts_with( $screen->id, 'wp-subscription_page' );
	}

	/**
	 * Whether this login has already dismissed the notice.
	 *
	 * @return bool
	 */
	private function is_dismissed(): bool {
		$stored = get_user_meta( get_current_user_id(), self::DISMISSED_META, true );

		return '' !== $stored && $stored === wp_get_session_token();
	}

	/**
	 * Whether the notice should render on this request.
	 *
	 * @return bool
	 */
	private function should_show(): bool {
		return current_user_can( 'manage_options' )
			&& ! $this->is_own_screen()
			&& ! $this->is_dismissed()
			&& ! $this->is_license_active();
	}

	/**
	 * Enqueue the notice's stylesheet and dismissal script.
	 *
	 * Kept out of the pages stylesheet: this notice shows on *other* plugins'
	 * screens, where none of the WPSubscription admin CSS is loaded. Every
	 * colour is written as `var(--token, literal)` so it renders correctly with
	 * or without the token sheet present.
	 *
	 * @return void
	 */
	public function enqueue_notice_assets() {
		if ( ! $this->should_show() ) {
			return;
		}

		wp_enqueue_style(
			'subscrpt-pro-license-notice',
			SUBSCRIPT_PRO_ASSETS . '/css/admin/license-notice.css',
			array(),
			SUBSCRIPT_PRO_VERSION
		);

		wp_enqueue_script(
			'subscrpt-pro-license-notice',
			SUBSCRIPT_PRO_ASSETS . '/js/admin/license-notice.js',
			array(),
			SUBSCRIPT_PRO_VERSION,
			true
		);

		wp_localize_script(
			'subscrpt-pro-license-notice',
			'subscrptProLicenseNotice',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'action'  => self::DISMISS_ACTION,
				'nonce'   => wp_create_nonce( self::DISMISS_ACTION ),
			)
		);
	}

	/**
	 * Record the dismissal against the current login session.
	 *
	 * @return void
	 */
	public function handle_dismiss() {
		check_ajax_referer( self::DISMISS_ACTION, 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( null, 403 );
		}

		update_user_meta( get_current_user_id(), self::DISMISSED_META, wp_get_session_token() );

		wp_send_json_success();
	}

	/**
	 * Display license notice.
	 *
	 * @return void
	 */
	public function license_notice() {
		if ( ! $this->should_show() ) {
			return;
		}
		?>
		<div class="notice subscrpt-license-notice is-dismissible" data-subscrpt-license-notice>
			<div class="subscrpt-license-notice__body">
				<span class="subscrpt-license-notice__name"><?php esc_html_e( 'WPSubscription Pro', 'subscription-pro' ); ?></span>
				<span class="subscrpt-license-notice__text"><?php esc_html_e( 'License Required to enable pro features and get updates.', 'subscription-pro' ); ?></span>
			</div>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-subscription-license' ) ); ?>" class="subscrpt-license-notice__action">
				<?php esc_html_e( 'Activate Now', 'subscription-pro' ); ?>
			</a>
		</div>
		<?php
	}

	/**
	 * Register plugin
	 *
	 * @param array $plugins plugin lists.
	 *
	 * @return array
	 */
	public function register_plugins( array $plugins ): array {
		$plugins['subscription'] = __( 'Subscription Pro', 'subscription-pro' );

		return $plugins;
	}
}
