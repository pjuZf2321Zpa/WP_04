<?php
/**
 * Warns when the active free plugin lacks the latest purchase-options renderer.
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

namespace SpringDevs\SubscriptionPro\Admin;

/**
 * Free renders the purchase-options selector in 2.5.0+. When an older free is
 * active, Pro loads its fallback selector so product pages keep showing plans,
 * but warns that free should be updated for the latest selector layouts.
 *
 * Free in turn renders the selector beside pro only when pro says it renders
 * through free, so that a new free beside an older pro, which draws its own,
 * never shows two.
 */
class FreeRendererNotice {

	/**
	 * Hook the notice, and tell free to render the purchase options.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'admin_notices', [ $this, 'render' ] );
		add_filter( 'subscrpt_plan_selector_from_free', [ $this, 'renders_through_free' ] );
	}

	/**
	 * This pro draws no selector of its own when free provides it: free renders the purchase options.
	 *
	 * @return bool
	 */
	public function renders_through_free() {
		return true;
	}

	/**
	 * Whether free ships the purchase-options renderer.
	 *
	 * @return bool
	 */
	protected function renderer_present() {
		return class_exists( '\SpringDevs\Subscription\Frontend\PlanGroups' );
	}

	/**
	 * Print the notice for users who can act on it.
	 *
	 * @return void
	 */
	public function render() {
		if ( ! current_user_can( 'activate_plugins' ) || $this->renderer_present() ) {
			return;
		}
		?>
		<div class="notice notice-warning is-dismissible subscrpt-free-renderer-notice">
			<p>
				<?php
				echo wp_kses_post(
					sprintf(
						/* translators: %s: link to the updates screen. */
						__( 'WPSubscription Pro needs a newer WPSubscription to use the latest plan option layouts on product pages. %s', 'subscription-pro' ),
						'<a href="' . esc_url( admin_url( 'update-core.php' ) ) . '">' . esc_html__( 'Update WPSubscription.', 'subscription-pro' ) . '</a>'
					)
				);
				?>
			</p>
		</div>
		<?php
	}
}
