<?php
/**
 * License page chrome.
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

namespace SpringDevs\SubscriptionPro\Admin;

/**
 * Gives the license screen the same header as every other WPSubscription page.
 *
 * Every admin page under this menu is registered by the free plugin's
 * `Admin\Menu`, whose render callbacks print the breadcrumb header, then fire an
 * action for pro to draw the body, then print the footer. The license page is
 * the exception: it is registered by the vendored SureCart client
 * (`license/src/Settings.php`) straight from `Settings::add_page()`, so it never
 * passes through that wrapper and rendered with no breadcrumb, no page header
 * and no footer.
 *
 * The vendored client is not edited — it is third-party code that gets replaced
 * wholesale on update. Instead the submenu entry it registers is swapped for one
 * whose callback draws the chrome around the client's own form output.
 * `Settings::settings_output()` is public and self-contained: it handles its own
 * form submission and prints its own CSS, so calling it from here behaves
 * exactly as before.
 */
class License {

	/**
	 * Parent menu slug.
	 */
	const PARENT_SLUG = 'wp-subscription';

	/**
	 * This page's slug.
	 */
	const PAGE_SLUG = 'wp-subscription-license';

	/**
	 * Hook the menu swap.
	 */
	public function __construct() {
		// Priority 100: the SureCart client hooks `admin_menu` at 99, so its
		// entry has to exist before it can be replaced. The free plugin
		// reorders the submenu at 999, and reads the slug — which is unchanged
		// here — so the License item keeps its position at the bottom.
		add_action( 'admin_menu', array( $this, 'replace_submenu_page' ), 100 );
	}

	/**
	 * Point the license submenu at this class instead of the SureCart client.
	 *
	 * @return void
	 */
	public function replace_submenu_page() {
		// Both steps are required, and only doing the first is a trap:
		// remove_submenu_page() takes the item out of the $submenu global, but
		// the render callback was registered by add_submenu_page() as an action
		// on the page's hookname, and that registration survives. The page then
		// renders twice — the client's bare form, then this one below it.
		$hookname = get_plugin_page_hookname( self::PAGE_SLUG, self::PARENT_SLUG );

		remove_submenu_page( self::PARENT_SLUG, self::PAGE_SLUG );

		if ( $hookname ) {
			// Not remove_action() with the client's callback: the plugin builds
			// a new SureCart\Licensing\Client on every call, so the Settings
			// object here is never the instance that registered the callback and
			// the removal would silently not match. Nothing else hooks a page
			// hookname but its own renderer.
			remove_all_actions( $hookname );
		}

		add_submenu_page(
			self::PARENT_SLUG,
			__( 'License', 'subscription-pro' ),
			__( 'License', 'subscription-pro' ),
			'manage_options',
			self::PAGE_SLUG,
			array( $this, 'render' ),
			999
		);
	}

	/**
	 * Render the license page with the shared chrome.
	 *
	 * @return void
	 */
	public function render() {
		$menu   = $this->free_menu();
		$client = \Sdevs_Wc_Subscription_Pro::check_pro_license_or_alert( true );

		if ( $menu ) {
			$menu->render_admin_header( __( 'License', 'subscription-pro' ) );
		}
		?>
		<div class="wp-subscription-admin-content list-page">
			<?php
			wc_get_template(
				'page-header.php',
				array(
					'subscrpt_title' => __( 'License', 'subscription-pro' ),
					'subscrpt_desc'  => __( 'Activate your license to unlock pro features and receive updates.', 'subscription-pro' ),
				),
				'subscription-pro/admin/partials/',
				WP_SUBSCRIPTION_PRO_TEMPLATES . 'admin/partials/'
			);
			?>

			<?php
			/*
			 * WordPress relocates admin notices in wp-admin/js/common.js: it
			 * moves them after `.wp-header-end`, or failing that after the first
			 * heading inside a `.wrap`. The SureCart client opens its output
			 * with `<div class="wrap"><h1></h1>`, so without a marker here every
			 * notice on this screen was pulled down into the licence card's
			 * column and wrapped. Other pages in this plugin have no `.wrap` at
			 * all, which is why only this one moved.
			 */
			?>
			<hr class="wp-header-end" />

			<?php
			wc_get_template(
				'license.php',
				array(
					'subscrpt_is_active'  => $this->is_active( $client ),
					'subscrpt_masked_key' => $this->masked_key( $client ),
					'subscrpt_form'       => function () use ( $client ) {
						$this->render_client_form( $client );
					},
				),
				'subscription-pro/admin/',
				WP_SUBSCRIPTION_PRO_TEMPLATES . 'admin/'
			);
			?>
		</div>
		<?php
		if ( $menu ) {
			$menu->render_admin_footer();
		}
	}

	/**
	 * Whether the licence is currently valid.
	 *
	 * @param object|false $client SureCart licensing client.
	 * @return bool
	 */
	private function is_active( $client ): bool {
		if ( ! $client || ! method_exists( $client, 'license' ) ) {
			return false;
		}

		return (bool) $client->license()->is_valid();
	}

	/**
	 * The stored licence key, masked to its last four characters.
	 *
	 * Never the whole key: this screen is a screenshot away from a support
	 * thread, and the last four are enough to tell two keys apart.
	 *
	 * @param object|false $client SureCart licensing client.
	 * @return string Masked key, or an empty string when none is stored.
	 */
	private function masked_key( $client ): string {
		if ( ! $client || ! method_exists( $client, 'settings' ) ) {
			return '';
		}

		$key = (string) $client->settings()->license_key;

		if ( '' === $key ) {
			return '';
		}

		return str_repeat( '•', 8 ) . substr( $key, -4 );
	}

	/**
	 * Print the SureCart client's own license form.
	 *
	 * @param object|false $client SureCart licensing client.
	 * @return void
	 */
	private function render_client_form( $client ) {
		if ( ! $client || ! method_exists( $client, 'settings' ) ) {
			echo '<p>' . esc_html__( 'The licensing client is unavailable.', 'subscription-pro' ) . '</p>';
			return;
		}

		$settings = $client->settings();

		/*
		 * settings_output() reads $menu_args['page_title'], and only add_page()
		 * ever populates that array. The plugin builds a fresh licensing client
		 * on every call, so the instance rendering here is not the one add_page()
		 * was called on and the array is null — which is a PHP warning on every
		 * load of this screen.
		 *
		 * Calling add_page() here fills it in. The admin_menu hook it also adds
		 * is inert: admin_menu has already fired by the time a page callback
		 * runs, so nothing re-registers a menu.
		 */
		$settings->add_page(
			array(
				'type'        => 'submenu',
				'parent_slug' => self::PARENT_SLUG,
				'page_title'  => __( 'License', 'subscription-pro' ),
				'menu_title'  => __( 'License', 'subscription-pro' ),
				'capability'  => 'manage_options',
				'menu_slug'   => self::PAGE_SLUG,
			)
		);

		$settings->settings_output();
	}

	/**
	 * The free plugin's Menu, which owns the breadcrumb header and the footer.
	 *
	 * Guarded rather than assumed: pro requires free, but this renders during a
	 * request where free could have been deactivated, and a fatal on the licence
	 * screen would leave no way to fix the licence.
	 *
	 * @return \SpringDevs\Subscription\Admin\Menu|null
	 */
	private function free_menu() {
		if ( ! class_exists( '\SpringDevs\Subscription\Admin\Menu' ) ) {
			return null;
		}

		return new \SpringDevs\Subscription\Admin\Menu();
	}
}
