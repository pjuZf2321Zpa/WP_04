<?php
/**
 * The box on a subscription's admin page.
 *
 * A merchant handling a support ticket needs to see what is about to ship and
 * change it — including after the lock, which is exactly the case a customer
 * cannot handle themselves.
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

namespace SpringDevs\SubscriptionPro\Admin;

use SpringDevs\SubscriptionPro\Illuminate\Box\BoxCart;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxProduct;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxSubscription;

defined( 'ABSPATH' ) || exit;

/**
 * Box panel and actions on the subscription details screen.
 */
class SubscriptionBox {

	/**
	 * Register hooks.
	 */
	public function __construct() {
		add_action( 'subscrpt_details_main_top', array( $this, 'render_panel' ) );
		add_filter( 'subscrpt_admin_info_rows', array( $this, 'add_info_row' ), 10, 3 );
		add_action( 'admin_init', array( $this, 'maybe_handle_actions' ) );
	}

	/**
	 * Add a one-line box summary to the subscription info box.
	 *
	 * @param array     $rows            Info rows.
	 * @param int       $subscription_id Subscription id.
	 * @param \WC_Order $order           Parent order.
	 *
	 * @return array
	 */
	public function add_info_row( $rows, $subscription_id, $order ) {
		$subscription_id = (int) $subscription_id;

		if ( ! BoxSubscription::is_box( $subscription_id ) ) {
			return $rows;
		}

		$contents = BoxSubscription::contents( $subscription_id );
		$lock     = BoxSubscription::lock_timestamp( $subscription_id );

		$value = sprintf(
			/* translators: %d: number of items in the box. */
			_n( '%d item', '%d items', BoxProduct::count_units( $contents ), 'subscription-pro' ),
			BoxProduct::count_units( $contents )
		);

		if ( $lock ) {
			$value .= ' · ' . (
				BoxSubscription::is_locked( $subscription_id )
					? __( 'locked', 'subscription-pro' )
					: sprintf(
						/* translators: %s: date the box locks. */
						__( 'locks %s', 'subscription-pro' ),
						date_i18n( get_option( 'date_format' ), $lock )
					)
			);
		}

		$rows['subscrpt_box'] = array(
			'label' => __( 'Box', 'subscription-pro' ),
			'value' => $value,
		);

		return $rows;
	}

	/**
	 * Handle the panel's actions.
	 *
	 * @return void
	 */
	public function maybe_handle_actions(): void {
		if ( empty( $_POST['subscrpt_box_admin_action'] ) ) {
			return;
		}

		$subscription_id = absint( $_POST['subscrpt_box_subscription'] ?? 0 );
		$action          = sanitize_text_field( wp_unslash( $_POST['subscrpt_box_admin_action'] ) );

		if ( ! $subscription_id || ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		if ( ! isset( $_POST['subscrpt_box_admin_nonce'] )
			|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['subscrpt_box_admin_nonce'] ) ), 'subscrpt_box_admin_' . $subscription_id ) ) {
			return;
		}

		if ( 'skip' === $action ) {
			BoxSubscription::skip( $subscription_id, 'admin' );
		} elseif ( 'save' === $action ) {
			$items = array();

			// map_deep sanitises the quantities while keeping the product ids as keys.
			$posted_items = isset( $_POST['subscrpt_box_items'] )
				? (array) map_deep( wp_unslash( $_POST['subscrpt_box_items'] ), 'absint' )
				: array();

			foreach ( $posted_items as $product_id => $qty ) {
				$items[] = array(
					'product_id' => absint( $product_id ),
					'qty'        => (int) $qty,
				);
			}

			BoxSubscription::update_contents( $subscription_id, $items, 'admin' );
		}

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'    => 'wp-subscription-details',
					'id'      => $subscription_id,
					'updated' => 1,
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Render the box panel.
	 *
	 * @param array|int $context Details-page context, or a subscription id.
	 *
	 * @return void
	 */
	public function render_panel( $context ): void {
		$subscription_id = is_array( $context )
			? (int) ( $context['subscription_id'] ?? $context['id'] ?? 0 )
			: (int) $context;

		if ( ! $subscription_id || ! BoxSubscription::is_box( $subscription_id ) ) {
			return;
		}

		$contents  = BoxSubscription::contents( $subscription_id );
		$rules     = BoxSubscription::rules( $subscription_id );
		$lock      = BoxSubscription::lock_timestamp( $subscription_id );
		$is_locked = BoxSubscription::is_locked( $subscription_id );
		$summary   = BoxCart::contents_summary( $contents );
		$edition   = (int) get_post_meta( $subscription_id, BoxSubscription::META_EDITION, true );
		$skips     = (int) get_post_meta( $subscription_id, BoxSubscription::META_SKIPS, true );

		$choices = array();

		foreach ( BoxSubscription::allowed_products( $subscription_id ) as $product_id ) {
			$product = wc_get_product( $product_id );

			if ( $product instanceof \WC_Product ) {
				$choices[ $product_id ] = $product->get_name();
			}
		}

		$chosen = array();

		foreach ( BoxProduct::normalise_items( $contents ) as $item ) {
			$chosen[ $item['product_id'] ] = (int) $item['qty'];
		}

		include SUBSCRIPT_PRO_PATH . '/templates/admin/subscription-box.php';
	}
}
