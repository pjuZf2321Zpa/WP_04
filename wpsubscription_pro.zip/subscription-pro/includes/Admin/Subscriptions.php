<?php
/**
 * Admin subscription screen additions.
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

namespace SpringDevs\SubscriptionPro\Admin;

use SpringDevs\SubscriptionPro\Illuminate\Helper;

/**
 * Class Subscriptions
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */
class Subscriptions {

	/**
	 * Initialize the class
	 */
	public function __construct() {
		add_action( 'subscrpt_order_activities', array( $this, 'display_subscrpt_order_activities' ) );
		add_filter( 'subscrpt_admin_info_rows', array( $this, 'add_some_rows' ), 10, 3 );
		add_action( 'admin_notices', array( $this, 'scheduled_downgrade_notice' ) );
	}

	/**
	 * Show an admin notice on the subscription edit screen when a downgrade is scheduled.
	 *
	 * @return void
	 */
	public function scheduled_downgrade_notice() {
		$screen = get_current_screen();
		if ( ! $screen || 'subscrpt_order' !== $screen->post_type || 'post' !== $screen->base ) {
			return;
		}

		$subscription_id = isset( $_GET['post'] ) ? absint( wp_unslash( $_GET['post'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only screen check.
		if ( ! $subscription_id ) {
			return;
		}

		$pending = get_post_meta( $subscription_id, '_subscrpt_pending_switch', true );
		if ( empty( $pending ) || empty( $pending['new_variation_id'] ) ) {
			return;
		}

		$variation = wc_get_product( (int) $pending['new_variation_id'] );
		$plan_name = $variation ? $variation->get_name() : __( 'a different plan', 'subscription-pro' );

		$next_date = (int) get_post_meta( $subscription_id, '_subscrpt_next_date', true );
		$effective = $next_date ? date_i18n( get_option( 'date_format' ), $next_date ) : __( 'the next renewal', 'subscription-pro' );
		?>
		<div class="notice notice-warning">
			<p>
				<?php
				printf(
					/* translators: 1: target plan name, 2: effective date. */
					esc_html__( 'A downgrade to %1$s is scheduled and will take effect on %2$s.', 'subscription-pro' ),
					'<strong>' . esc_html( $plan_name ) . '</strong>',
					'<strong>' . esc_html( $effective ) . '</strong>'
				);
				?>
			</p>
		</div>
		<?php
	}

	/**
	 * Add some rows that display trial, signupfee and more ...
	 *
	 * @param array     $rows Rows.
	 * @param int       $subscription_id Subscription Id.
	 * @param \WC_Order $order Order Object.
	 *
	 * @return array
	 */
	public function add_some_rows( $rows, $subscription_id, $order ) {
		$start_date = get_post_meta( $subscription_id, '_subscrpt_start_date', true );
		$signup_fee = get_post_meta( $subscription_id, '_subscrpt_signup_fee', true );
		if ( ! empty( $trial ) ) {
			unset( $rows['start_date'] );
			$rows                       = array_slice( $rows, 0, 3, true ) +
			array(
				'signup_fee' => array(
					'label' => __( 'Signup Fee', 'subscription-pro' ),
					'value' => wc_price(
						$signup_fee,
						array(
							'currency' => $order->get_currency(),
						)
					),
				),
			) +
			array_slice( $rows, 3, count( $rows ) - 1, true );
			$rows['next_date']['value'] = wp_date( 'F d, Y', $start_date, new \DateTimeZone( 'UTC' ) );
		}

		if ( class_exists( 'WC_Stripe' ) && 'stripe' === $order->get_payment_method() ) {
			$is_auto_renew = get_post_meta( $subscription_id, '_subscrpt_auto_renew', true );
			$new_rows      = array();
			foreach ( $rows as $key => $value ) {
				$new_rows[ $key ] = $value;
				if ( 'payment_method' === $key ) {
					$new_rows['stripe_auto_renewal'] = array(
						'label' => __( 'Stripe Auto Renewal', 'subscription-pro' ),
						'value' => '0' !== $is_auto_renew ? 'On' : 'Off',
					);
				}
			}

			return $new_rows;
		}

		return $rows;
	}

	/**
	 * Display Subscription Order Activities
	 *
	 * @param int $post_id Post ID.
	 */
	public function display_subscrpt_order_activities( $post_id ) {
		// Get Subscription Activities
		$comments = Helper::get_subscription_activities( $post_id );

		if ( \Sdevs_Wc_Subscription_Pro::check_pro_license_or_alert() ) {
			if ( empty( $comments ) ) {
				echo '<div style="padding:16px 18px;"><p style="margin:0;color:var(--wpsubs-text-muted);font-size:13px;">' . esc_html__( 'No activity recorded yet.', 'subscription-pro' ) . '</p></div>';
				return;
			}
			?>
		<table class="wpsubs-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Activity', 'subscription-pro' ); ?></th>
					<th><?php esc_html_e( 'Description', 'subscription-pro' ); ?></th>
					<th><?php esc_html_e( 'Date', 'subscription-pro' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( $comments as $comment ) : ?>
					<tr>
						<td><?php echo esc_html( $comment['title'] ); ?></td>
						<td><?php echo esc_html( $comment['description'] ); ?></td>
						<td><?php echo esc_html( mysql2date( get_option( 'date_format' ) . ' - ' . get_option( 'time_format' ), $comment['date'] ) ); ?></td>
					</tr>
		<?php endforeach; ?>
			</tbody>
		</table>
			<?php
		}
	}
}
