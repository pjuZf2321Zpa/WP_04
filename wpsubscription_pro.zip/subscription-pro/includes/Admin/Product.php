<?php
/**
 * Admin product loader.
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

namespace SpringDevs\SubscriptionPro\Admin;

use SpringDevs\SubscriptionPro\Admin\Product\BoxConnect;
use SpringDevs\SubscriptionPro\Admin\Product\Simple;
use SpringDevs\SubscriptionPro\Admin\Product\Variable;

/**
 * Class Product
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */
class Product {

	/**
	 * Constructor
	 **/
	public function __construct() {
		new Simple();
		new Variable();
		new BoxConnect();
		// The product-editor plan view is owned by the free plugin's
		// SpringDevs\Subscription\Admin\Product\Plans; Pro's variable-product panel
		// (Product\Variable) reuses it. There is no Pro product-editor plan class.
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	/**
	 * Enqueue assets.
	 */
	public function enqueue_assets() {
		wp_enqueue_style( 'subscrpt_pro_admin_css' );
	}
}
