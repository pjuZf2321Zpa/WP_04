<?php
/**
 * Health admin page.
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

namespace SpringDevs\SubscriptionPro\Admin;

use SpringDevs\SubscriptionPro\Illuminate\Health\HealthEngine;

/**
 * Health admin page — WPSubscription > Health.
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */
class Health {

	/** Hook name for the health queue reminder cron event. */
	const CRON_HOOK = 'subscrpt_health_queue_reminder_cron';

	/**
	 * Initialize hooks.
	 */
	public function __construct() {
		add_action( 'subscrpt_render_health_page', array( $this, 'render_recovery_page' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'wp_ajax_subscrpt_recovery_retry', array( $this, 'ajax_retry' ) );
		add_action( 'wp_ajax_subscrpt_recovery_create_renewal', array( $this, 'ajax_create_renewal' ) );
		add_action( 'wp_ajax_subscrpt_recovery_send_email', array( $this, 'ajax_send_email' ) );
		add_action( 'wp_ajax_subscrpt_recovery_skip', array( $this, 'ajax_skip' ) );
		add_action( 'wp_ajax_subscrpt_recovery_unskip', array( $this, 'ajax_unskip' ) );
		add_action( 'wp_ajax_subscrpt_recovery_bulk', array( $this, 'ajax_bulk' ) );
		add_action( 'admin_post_subscrpt_recovery_export', array( $this, 'handle_export' ) );

		// Classic storage hooks (post-based).
		add_action( 'save_post', array( $this, 'invalidate_cache' ) );
		add_action( 'wp_trash_post', array( $this, 'invalidate_cache' ) );
		add_action( 'untrash_post', array( $this, 'invalidate_cache' ) );

		// HPOS hooks — wp_trash_post does not fire for orders stored in wc_orders table.
		add_action( 'woocommerce_trash_order', array( $this, 'invalidate_cache_for_order' ) );
		add_action( 'woocommerce_untrash_order', array( $this, 'invalidate_cache_for_order' ) );
		add_action( 'woocommerce_delete_order', array( $this, 'invalidate_cache_for_order' ) );
		add_action( 'woocommerce_update_order', array( $this, 'invalidate_cache_for_order' ) );

		// Register custom cron intervals on all request types — Cron class only loads
		// during DOING_CRON, but intervals must exist whenever wp_schedule_event() runs.
		add_filter( 'cron_schedules', array( $this, 'register_cron_intervals' ) );
		// Defer to init priority 20 (after WC textdomain at priority 0, after init_classes at priority 10).
		// maybe_schedule_cron() self-heals recurrence mismatches, so no update_option hook needed.
		add_action( 'init', array( $this, 'maybe_schedule_cron' ), 20 );
	}

	/**
	 * Register custom WP-Cron intervals needed for the health queue reminder schedule.
	 *
	 * Runs on all request types so wp_schedule_event() can validate the interval
	 * even when the Cron class is not loaded (non-cron requests).
	 *
	 * @param array $schedules Existing cron schedules.
	 * @return array
	 */
	public function register_cron_intervals( array $schedules ): array {
		if ( ! isset( $schedules['subscrpt_weekly'] ) ) {
			$schedules['subscrpt_weekly'] = array(
				'interval' => 7 * DAY_IN_SECONDS,
				'display'  => __( 'Once Weekly', 'subscription-pro' ),
			);
		}
		if ( ! isset( $schedules['subscrpt_monthly'] ) ) {
			$schedules['subscrpt_monthly'] = array(
				'interval' => 30 * DAY_IN_SECONDS,
				'display'  => __( 'Once Monthly', 'subscription-pro' ),
			);
		}
		return $schedules;
	}

	/**
	 * Schedule the health queue reminder cron, or reschedule if the recurrence
	 * no longer matches the current frequency setting.
	 *
	 * Runs on every request (init priority 20) so it self-heals when the admin
	 * changes the frequency setting without requiring a separate option hook.
	 *
	 * @return void
	 */
	public function maybe_schedule_cron(): void {
		$frequency = get_option( 'subscrpt_health_queue_email_frequency', 'subscrpt_weekly' );
		$next      = wp_next_scheduled( self::CRON_HOOK );

		if ( 'never' === $frequency ) {
			if ( $next ) {
				wp_clear_scheduled_hook( self::CRON_HOOK );
			}
			return;
		}

		if ( ! $next ) {
			wp_schedule_event( time(), $frequency, self::CRON_HOOK );
			return;
		}

		// Check whether the currently scheduled recurrence still matches the setting.
		$crons              = _get_cron_array();
		$current_recurrence = '';
		foreach ( $crons as $hooks ) {
			if ( isset( $hooks[ self::CRON_HOOK ] ) ) {
				$cron_data          = reset( $hooks[ self::CRON_HOOK ] );
				$current_recurrence = $cron_data['schedule'] ?? '';
				break;
			}
		}

		if ( $current_recurrence !== $frequency ) {
			wp_clear_scheduled_hook( self::CRON_HOOK );
			wp_schedule_event( time(), $frequency, self::CRON_HOOK );
		}
	}

	/**
	 * Clear the health queue reminder cron. Called on plugin deactivation.
	 *
	 * @return void
	 */
	public static function clear_cron(): void {
		wp_clear_scheduled_hook( self::CRON_HOOK );
	}

	/**
	 * Enqueue Tailwind CSS and the vanilla JS action handler on the recovery screen.
	 */
	public function enqueue_assets(): void {
		// The submenu hook prefix is sanitize_title() of the parent menu's
		// *translated* title, not the parent slug — "wpsubscription_page_*" in
		// English, something else in other locales — so match the slug only.
		$screen = get_current_screen();
		if ( ! $screen || ! str_ends_with( $screen->id, '_page_wp-subscription-health' ) ) {
			return;
		}

		$asset_path = plugin_dir_path( SUBSCRIPT_PRO_FILE ) . 'assets/js/admin/health-actions.js';
		wp_enqueue_script(
			'subscrpt-recovery-actions',
			plugins_url( 'assets/js/admin/health-actions.js', SUBSCRIPT_PRO_FILE ),
			array( 'wp-i18n' ),
			file_exists( $asset_path ) ? filemtime( $asset_path ) : SUBSCRIPT_PRO_VERSION,
			true
		);
		wp_set_script_translations( 'subscrpt-recovery-actions', 'subscription-pro', SUBSCRIPT_PRO_PATH . '/languages' );
	}

	/**
	 * Render the health page using a PHP template.
	 */
	public function render_recovery_page(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['_refresh'] ) && check_admin_referer( 'subscrpt_health_refresh', '_refresh' ) ) {
			HealthEngine::clear_cache();
			wp_safe_redirect( remove_query_arg( '_refresh' ) );
			exit;
		}

		$filter       = isset( $_GET['filter'] ) ? sanitize_key( wp_unslash( $_GET['filter'] ) ) : 'all';
		$search_term  = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		$per_page     = isset( $_GET['per_page'] ) ? max( 1, (int) $_GET['per_page'] ) : 20;
		$current_page = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1;
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		if ( 'skipped' === $filter ) {
			$subscriptions = HealthEngine::get_skipped_subscriptions();
			$revenue       = 0.0;
		} else {
			$subscriptions = HealthEngine::get_broken_subscriptions( $filter );
			$revenue       = HealthEngine::get_revenue_at_risk( $subscriptions );
		}

		if ( '' !== $search_term ) {
			$search_lower  = strtolower( $search_term );
			$subscriptions = array_values(
				array_filter(
					$subscriptions,
					static function ( array $sub ) use ( $search_lower ): bool {
						return false !== strpos( (string) ( $sub['id'] ?? '' ), $search_lower )
							|| false !== strpos( strtolower( (string) ( $sub['product_name'] ?? '' ) ), $search_lower )
							|| false !== strpos( strtolower( (string) ( $sub['customer_email'] ?? '' ) ), $search_lower );
					}
				)
			);
			$revenue       = HealthEngine::get_revenue_at_risk( $subscriptions );
		}

		$total_filtered = count( $subscriptions );
		$total_pages    = max( 1, (int) ceil( $total_filtered / $per_page ) );
		$current_page   = min( $current_page, $total_pages );
		$subscriptions  = array_slice( $subscriptions, ( $current_page - 1 ) * $per_page, $per_page );

		$issue_counts = array(
			'all'             => count( HealthEngine::get_broken_subscriptions( 'all' ) ),
			'overdue_renewal' => count( HealthEngine::get_broken_subscriptions( 'overdue_renewal' ) ),
			'failed_payment'  => count( HealthEngine::get_broken_subscriptions( 'failed_payment' ) ),
			'retry_needed'    => count( HealthEngine::get_broken_subscriptions( 'retry_needed' ) ),
			'stalled_renewal' => count( HealthEngine::get_broken_subscriptions( 'stalled_renewal' ) ),
			'skipped'         => count( HealthEngine::get_skipped_ids() ),
		);

		wp_localize_script(
			'subscrpt-recovery-actions',
			'subscrptRecovery',
			array(
				'nonce'       => wp_create_nonce( 'subscrpt_recovery_nonce' ),
				'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
				'exportUrl'   => admin_url( 'admin-post.php' ),
				'exportNonce' => wp_create_nonce( 'subscrpt_recovery_export' ),
			)
		);

		$currency = get_woocommerce_currency_symbol();

		include SUBSCRIPT_PRO_PATH . '/templates/admin/health.php';
	}

	/**
	 * Invalidate recovery cache when a subscription post is saved/trashed (classic storage).
	 *
	 * @param int $post_id Post ID.
	 */
	public function invalidate_cache( int $post_id ): void {
		if ( in_array( get_post_type( $post_id ), array( 'subscrpt_order', 'shop_order' ), true ) ) {
			HealthEngine::clear_cache();
		}
	}

	/**
	 * Invalidate recovery cache on any HPOS order change.
	 *
	 * The woocommerce_trash_order, woocommerce_untrash_order, woocommerce_delete_order
	 * and woocommerce_update_order hooks all pass the order ID as the first argument.
	 */
	public function invalidate_cache_for_order(): void {
		HealthEngine::clear_cache();
	}

	// -------------------------------------------------------------------------
	// AJAX handlers
	// -------------------------------------------------------------------------

	/**
	 * AJAX: retry payment for a single subscription.
	 */
	public function ajax_retry(): void {
		$this->verify_request();
		$subscription_id = $this->get_subscription_id();
		$result          = HealthEngine::retry_payment( $subscription_id );
		$this->send_json( $result );
	}

	/**
	 * AJAX: create a renewal order for a single subscription.
	 */
	public function ajax_create_renewal(): void {
		$this->verify_request();
		$subscription_id = $this->get_subscription_id();
		$result          = HealthEngine::create_renewal_order( $subscription_id );
		$this->send_json( $result );
	}

	/**
	 * AJAX: send payment update email for a single subscription.
	 */
	public function ajax_send_email(): void {
		$this->verify_request();
		$subscription_id = $this->get_subscription_id();
		$result          = HealthEngine::send_payment_update_email( $subscription_id );
		$this->send_json( $result );
	}

	/**
	 * AJAX: skip a single subscription (hide from recovery queue).
	 */
	public function ajax_skip(): void {
		$this->verify_request();
		$subscription_id = $this->get_subscription_id();
		$result          = HealthEngine::skip_subscription( $subscription_id );
		$this->send_json( $result );
	}

	/**
	 * AJAX: unskip a single subscription (return to recovery queue).
	 */
	public function ajax_unskip(): void {
		$this->verify_request();
		$subscription_id = $this->get_subscription_id();
		$result          = HealthEngine::unskip_subscription( $subscription_id );
		$this->send_json( $result );
	}

	/**
	 * AJAX: bulk action across multiple subscriptions.
	 *
	 * Expects POST fields: subscription_ids (comma-separated) and bulk_action.
	 */
	public function ajax_bulk(): void {
		$this->verify_request();

		$raw_ids = isset( $_POST['subscription_ids'] ) ? sanitize_text_field( wp_unslash( $_POST['subscription_ids'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$action  = isset( $_POST['bulk_action'] ) ? sanitize_key( wp_unslash( $_POST['bulk_action'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing

		$ids = array_filter( array_map( 'intval', explode( ',', $raw_ids ) ) );

		if ( empty( $ids ) || ! in_array( $action, array( 'retry', 'create_renewal', 'send_email', 'skip', 'unskip', 'trigger_hook' ), true ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid bulk action request.', 'subscription-pro' ) ) );
		}

		if ( 'trigger_hook' === $action ) {
			$payloads = array_map( array( HealthEngine::class, 'get_subscription_payload' ), $ids );

			/**
			 * Fires when the "Trigger Hook" bulk action is applied on the Recovery page.
			 *
			 * Use this to push recovery subscription data into a CRM, email platform,
			 * or any automation tool without performing any built-in recovery action.
			 *
			 * @param array[] $payloads One entry per selected subscription. Each item contains:
			 *   - int    $id             Subscription post ID.
			 *   - int    $customer_id    WordPress user ID.
			 *   - string $customer_email Customer email address.
			 *   - string $customer_name  Customer display name.
			 *   - int    $product_id     Product post ID.
			 *   - string $product_name   Product name.
			 *   - float  $price          Subscription price.
			 *   - string $status         Subscription status.
			 */
			do_action( 'subscrpt_recovery_trigger_hook', $payloads );

			wp_send_json_success(
				array(
					'success'  => count( $ids ),
					'failed'   => 0,
					'messages' => array(),
				)
			);
		}

		$results = array(
			'success'  => 0,
			'failed'   => 0,
			'messages' => array(),
		);

		foreach ( $ids as $id ) {
			switch ( $action ) {
				case 'retry':
					$r = HealthEngine::retry_payment( $id );
					break;
				case 'create_renewal':
					$r = HealthEngine::create_renewal_order( $id );
					break;
				case 'send_email':
					$r = HealthEngine::send_payment_update_email( $id );
					break;
				case 'skip':
					$r = HealthEngine::skip_subscription( $id );
					break;
				case 'unskip':
					$r = HealthEngine::unskip_subscription( $id );
					break;
				default:
					$r = array(
						'success' => false,
						'message' => '',
					);
			}

			if ( $r['success'] ) {
				++$results['success'];
			} else {
				++$results['failed'];
				$results['messages'][] = sprintf( '#%d: %s', $id, $r['message'] );
			}
		}

		wp_send_json_success( $results );
	}

	/**
	 * Handle CSV export download.
	 *
	 * Triggered by admin-post.php?action=subscrpt_recovery_export.
	 * Streams all broken subscriptions as a UTF-8 CSV file — no pagination limit.
	 */
	public function handle_export(): void {
		check_admin_referer( 'subscrpt_recovery_export' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized.', 'subscription-pro' ), 403 );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$filter = isset( $_GET['filter'] ) ? sanitize_key( wp_unslash( $_GET['filter'] ) ) : 'all';
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		$subscriptions = HealthEngine::get_broken_subscriptions( $filter );
		$currency      = html_entity_decode( get_woocommerce_currency_symbol(), ENT_QUOTES, 'UTF-8' );
		$filename      = 'recovery-subscriptions-' . gmdate( 'Y-m-d' ) . '.csv';

		// Disable any output buffering to avoid corrupting the download.
		while ( ob_get_level() ) {
			ob_end_clean();
		}

		header( 'Content-Type: text/csv; charset=UTF-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'Pragma: no-cache' );
		header( 'Expires: 0' );

		// BOM for Excel UTF-8 compatibility.
		echo "\xEF\xBB\xBF"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		$out = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen

		// Header row.
		fputcsv(
			$out,
			array(
				'Subscription ID',
				'Customer ID',
				'Customer Name',
				'Customer Email',
				'Product Name',
				'Product ID',
				'Variation ID',
				'Subscription Price',
				'Subscription Status',
			)
		);

		$status_map = array(
			'active'                => 'Active',
			'pending'               => 'Pending',
			'pe_cancelled'          => 'Pending Cancellation',
			'cancelled'             => 'Cancelled',
			'expired'               => 'Expired',
			'subscrpt-grace-period' => 'Grace Period',
			'subscrpt-suspended'    => 'Suspended',
		);

		foreach ( $subscriptions as $sub ) {
			$status_raw = (string) ( $sub['status'] ?? '' );

			$sub_id       = (int) ( $sub['id'] ?? 0 );
			$variation_id = (int) get_post_meta( $sub_id, '_subscrpt_variation_id', true );

			fputcsv(
				$out,
				array(
					$sub_id,
					(int) ( $sub['customer_id'] ?? 0 ),
					(string) ( $sub['customer_name'] ?? '' ),
					(string) ( $sub['customer_email'] ?? '' ),
					(string) ( $sub['product_name'] ?? '' ),
					(int) ( $sub['product_id'] ?? 0 ),
					$variation_id > 0 ? $variation_id : '',
					$currency . number_format( (float) ( $sub['price'] ?? 0 ), 2, '.', '' ),
					$status_map[ $status_raw ] ?? $status_raw,
				)
			);
		}

		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		exit;
	}

	// -------------------------------------------------------------------------
	// Private helpers
	// -------------------------------------------------------------------------

	/**
	 * Verifies nonce and capability. Dies on failure.
	 */
	private function verify_request(): void {
		check_ajax_referer( 'subscrpt_recovery_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'subscription-pro' ) ), 403 );
		}
	}

	/**
	 * Reads and validates subscription_id from POST. Dies on invalid value.
	 *
	 * @return int
	 */
	private function get_subscription_id(): int {
		$id = isset( $_POST['subscription_id'] ) ? intval( $_POST['subscription_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( $id <= 0 ) {
			wp_send_json_error( array( 'message' => __( 'Invalid subscription ID.', 'subscription-pro' ) ) );
		}
		return $id;
	}

	/**
	 * Sends JSON success or error based on the result array.
	 *
	 * @param array $result Array with 'success' bool and 'message' string keys.
	 */
	private function send_json( array $result ): void {
		if ( $result['success'] ) {
			wp_send_json_success( $result );
		} else {
			wp_send_json_error( $result );
		}
	}
}
