<?php
/**
 * Boxes, in the shape the admin screens read.
 *
 * The views never touch the repository directly: they get names, labels, counts
 * and URLs already resolved, so a template is markup and nothing else. This
 * mirrors the free plugin's `PlanPresenter`, which sits between
 * `PlanRepository` and the Plans views for the same reason.
 *
 * The REST controller keeps its own shape. That is deliberate rather than
 * duplication — JSON answers a client that re-renders, a view answers PHP that
 * prints once, and they drift for good reasons.
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

namespace SpringDevs\SubscriptionPro\Admin;

use SpringDevs\SubscriptionPro\Illuminate\Box\Box;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxDurations;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxPool;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxProduct;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxRepository;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxSelling;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxTogether;

defined( 'ABSPATH' ) || exit;

/**
 * Turns boxes into what the Boxes screens render.
 */
class BoxPresenter {

	/**
	 * Every box, newest first, keyed by id.
	 *
	 * @return array<int,array>
	 */
	public static function all(): array {
		$boxes = array();

		foreach ( BoxRepository::all( array( 'status' => 'any' ) ) as $box ) {
			$boxes[ $box->id() ] = self::present( $box );
		}

		return $boxes;
	}

	/**
	 * One box, or null when it has been deleted.
	 *
	 * @param int $box_id Box id.
	 *
	 * @return array|null
	 */
	public static function find( int $box_id ): ?array {
		$box = BoxRepository::find( $box_id );

		return $box ? self::present( $box ) : null;
	}

	/**
	 * One box as a view reads it.
	 *
	 * @param Box $box Box.
	 *
	 * @return array
	 */
	public static function present( Box $box ): array {
		$box        = BoxDurations::adopt( $box );
		$size       = $box->size();
		$pool       = $box->pool();
		$pricing    = $box->pricing();
		$pool_items = self::describe_ids( $pool['products'] );
		$durations  = BoxDurations::all( $box );
		$offered    = array_values(
			array_filter(
				$durations,
				static function ( $duration ) {
					return $duration['on'];
				}
			)
		);
		$product    = BoxSelling::product( $box->id() );
		$item_count = $box->is_customer_built() ? count( $box->pool_product_ids() ) : count( $box->curated_items() );

		foreach ( $pool_items as $index => $pool_item ) {
			$pool_items[ $index ]['counts_toward_discount'] = ! in_array( $pool_item['id'], $pricing['excluded'], true );
		}

		return array(
			'pool_skipped'   => array_values(
				array_filter(
					$pool_items,
					static function ( $item ) {
						return ! empty( $item['unusable'] );
					}
				)
			),
			'id'             => $box->id(),
			'name'           => $box->title(),
			'type'           => $box->type(),
			'type_label'     => self::type_label( $box->type() ),
			'type_icon'      => self::type_icon( $box->type() ),
			'status'         => $box->status(),
			'is_draft'       => ! $box->is_active(),
			'needs_setup'    => ! $product || ! $offered,
			'missing'        => BoxSelling::missing( $box ),
			'size'           => $size,
			'size_label'     => self::size_label( $size ),
			'rules'          => $box->rules(),
			'pricing'        => $pricing,
			'price_label'    => self::price_label( $pricing, $offered ),
			'discount_label' => self::discount_label( $pricing ),
			'show_together'  => $box->show_together(),
			'pool'           => $pool,
			'pool_items'     => $pool_items,
			'source_label'   => self::source_label( $box ),
			'item_count'     => $item_count,
			'defaults'       => self::describe_items( $box->default_items() ),
			'items'          => self::describe_items( $box->curated_items() ),
			'contents'       => self::contents_label( $box ),
			'product'        => $product,
			'plans'          => $box->plans(),
			'durations'      => $durations,
			'offered'        => $offered,
			'edited'         => self::edited( $box ),
			'detail_url'     => self::detail_url( $box->id() ),
		);
	}

	/**
	 * Where a box's items come from, in words.
	 *
	 * @param Box $box Box.
	 *
	 * @return string
	 */
	public static function source_label( Box $box ): string {
		if ( ! $box->is_customer_built() ) {
			$count = count( $box->curated_items() );

			/* translators: %d: number of items packed in the box. */
			return sprintf( _n( '%d packed item', '%d packed items', $count, 'subscription-pro' ), $count );
		}

		$pool = $box->pool();

		if ( BoxPool::SOURCE_ALL === $pool['source'] ) {
			return __( 'Whole shop', 'subscription-pro' );
		}

		if ( BoxPool::SOURCE_CATEGORIES === $pool['source'] ) {
			$count = count( $pool['categories'] ) + count( $pool['tags'] );

			return $count
				/* translators: %d: number of categories. */
				? sprintf( _n( '%d category', '%d categories', $count, 'subscription-pro' ), $count )
				: __( 'No categories yet', 'subscription-pro' );
		}

		$count = count( $pool['products'] );

		/* translators: %d: number of products chosen. */
		return sprintf( _n( '%d chosen product', '%d chosen products', $count, 'subscription-pro' ), $count );
	}

	/**
	 * What the box costs, as the Selling panel says it.
	 *
	 * @param array   $pricing Normalised pricing.
	 * @param array[] $offered Offered durations.
	 *
	 * @return string
	 */
	public static function price_label( array $pricing, array $offered ): string {
		if ( ! $offered ) {
			return __( 'Needs a duration', 'subscription-pro' );
		}

		if ( 'sum' === $pricing['strategy'] ) {
			return __( 'Adds up what is picked', 'subscription-pro' );
		}

		$cheapest = null;

		foreach ( $offered as $duration ) {
			if ( '' === $duration['price'] ) {
				continue;
			}

			if ( null === $cheapest || (float) $duration['price'] < (float) $cheapest['price'] ) {
				$cheapest = $duration;
			}
		}

		if ( ! $cheapest ) {
			return __( 'No price set', 'subscription-pro' );
		}

		return sprintf(
			/* translators: 1: price, 2: how often, e.g. "every month". */
			__( 'From %1$s %2$s', 'subscription-pro' ),
			html_entity_decode( wp_strip_all_tags( wc_price( (float) $cheapest['price'] ) ), ENT_QUOTES, 'UTF-8' ),
			$cheapest['cadence']
		);
	}

	/**
	 * The discount a bigger box earns, in a few words.
	 *
	 * @param array $pricing Normalised pricing.
	 *
	 * @return string
	 */
	public static function discount_label( array $pricing ): string {
		if ( 'sum' !== $pricing['strategy'] || ! $pricing['tiers'] ) {
			return __( 'None', 'subscription-pro' );
		}

		$percent = true;
		$best    = 0.0;

		foreach ( $pricing['tiers'] as $tier ) {
			$percent = $percent && 'percent' === $tier['type'];
			$best    = max( $best, (float) $tier['value'] );
		}

		/* translators: %s: largest percentage discount. */
		return $percent ? sprintf( __( 'Up to %s%%', 'subscription-pro' ), wc_format_localized_decimal( $best ) ) : __( 'Tiered', 'subscription-pro' );
	}

	/**
	 * The products most often held together in this box's live subscriptions.
	 *
	 * Reads the same index the storefront section ranks by, so what the merchant
	 * sees is what the shopper is offered. Each pair appears once.
	 *
	 * @param int $box_id Box id.
	 * @param int $limit  Most pairs to return.
	 *
	 * @return array[] Rows of `a` and `b` (product names) and `count`, most often first.
	 */
	public static function top_pairs( int $box_id, int $limit = 10 ): array {
		$found = array();

		foreach ( BoxTogether::pairs( $box_id ) as $first => $partners ) {
			foreach ( (array) $partners as $second => $count ) {
				$low  = min( (int) $first, (int) $second );
				$high = max( (int) $first, (int) $second );
				$key  = $low . '-' . $high;

				// Each side keeps only its best partners, so a pair can be listed from one side alone.
				if ( ! isset( $found[ $key ] ) || $found[ $key ]['count'] < (int) $count ) {
					$found[ $key ] = array(
						'a'     => $low,
						'b'     => $high,
						'count' => (int) $count,
					);
				}
			}
		}

		$found = array_values( $found );

		usort(
			$found,
			static function ( $x, $y ) {
				return array( $y['count'], $x['a'], $x['b'] ) <=> array( $x['count'], $y['a'], $y['b'] );
			}
		);

		$rows = array();

		foreach ( array_slice( $found, 0, max( 1, $limit ) ) as $pair ) {
			$one = wc_get_product( $pair['a'] );
			$two = wc_get_product( $pair['b'] );

			if ( $one && $two ) {
				$rows[] = array(
					'a'     => $one->get_name(),
					'b'     => $two->get_name(),
					'count' => $pair['count'],
				);
			}
		}

		return $rows;
	}

	/**
	 * The products selling a box.
	 *
	 * @param int $box_id Box id.
	 *
	 * @return array[]
	 */
	public static function products( int $box_id ): array {
		$rows = array();

		foreach ( BoxRepository::connections_for_box( $box_id ) as $connection ) {
			$product = wc_get_product( $connection['oid'] );

			if ( ! $product instanceof \WC_Product ) {
				// The product was deleted but the connection outlived it. Show
				// it so the merchant can clear it, rather than hiding a row
				// that still resolves to nothing on the storefront.
				$rows[] = array_merge(
					$connection,
					array(
						'name'    => __( '(deleted product)', 'subscription-pro' ),
						'missing' => true,
					)
				);

				continue;
			}

			$variation = $connection['vid'] ? wc_get_product( $connection['vid'] ) : null;

			$rows[] = array_merge(
				$connection,
				array(
					'name'        => $variation ? $variation->get_name() : $product->get_name(),
					'sku'         => $variation ? $variation->get_sku() : $product->get_sku(),
					'image'       => wp_get_attachment_image_url( (int) $product->get_image_id(), 'thumbnail' ),
					'is_variable' => $product->is_type( 'variable' ),
					'edit_url'    => get_edit_post_link( $connection['oid'], 'raw' ),
					'view_url'    => get_permalink( $connection['oid'] ),
					'missing'     => false,
				)
			);
		}

		return $rows;
	}

	/**
	 * Human label for a box type.
	 *
	 * @param string $type Box type.
	 *
	 * @return string
	 */
	public static function type_label( string $type ): string {
		$labels = array(
			Box::TYPE_CURATED => __( 'Curated', 'subscription-pro' ),
			Box::TYPE_BUILD   => __( 'Build your own', 'subscription-pro' ),
			Box::TYPE_EDITION => __( 'Monthly edition', 'subscription-pro' ),
		);

		return $labels[ $type ] ?? ucfirst( $type );
	}

	/**
	 * Dashicon for a box type.
	 *
	 * @param string $type Box type.
	 *
	 * @return string
	 */
	public static function type_icon( string $type ): string {
		$icons = array(
			Box::TYPE_CURATED => 'dashicons-products',
			Box::TYPE_BUILD   => 'dashicons-screenoptions',
			Box::TYPE_EDITION => 'dashicons-calendar-alt',
		);

		return $icons[ $type ] ?? 'dashicons-archive';
	}

	/**
	 * What the Contents column says.
	 *
	 * A build-your-own box is described by what a customer may choose from; the
	 * other two by what the merchant packs.
	 *
	 * @param Box $box Box.
	 *
	 * @return string
	 */
	private static function contents_label( Box $box ): string {
		if ( $box->is_customer_built() ) {
			$count = count( $box->pool()['products'] );

			/* translators: %d: number of products a customer may pick from. */
			return sprintf( _n( '%d product to pick from', '%d products to pick from', $count, 'subscription-pro' ), $count );
		}

		$count = count( $box->curated_items() );

		/* translators: %d: number of items packed in the box. */
		return sprintf( _n( '%d item', '%d items', $count, 'subscription-pro' ), $count );
	}

	/**
	 * How the size reads on screen.
	 *
	 * @param array $size min and max.
	 *
	 * @return string
	 */
	private static function size_label( array $size ): string {
		$min = (int) ( $size['min'] ?? 0 );
		$max = (int) ( $size['max'] ?? 0 );

		if ( ! $min && ! $max ) {
			return __( 'Any number of items', 'subscription-pro' );
		}

		if ( ! $max ) {
			/* translators: %d: minimum number of items. */
			return sprintf( __( '%d or more items', 'subscription-pro' ), $min );
		}

		if ( ! $min ) {
			/* translators: %d: maximum number of items. */
			return sprintf( _n( 'Up to %d item', 'Up to %d items', $max, 'subscription-pro' ), $max );
		}

		if ( $min === $max ) {
			/* translators: %d: exact number of items. */
			return sprintf( _n( 'Exactly %d item', 'Exactly %d items', $min, 'subscription-pro' ), $min );
		}

		/* translators: 1: minimum items, 2: maximum items. */
		return sprintf( __( 'Between %1$d and %2$d items', 'subscription-pro' ), $min, $max );
	}

	/**
	 * When the box was last touched, in words.
	 *
	 * @param Box $box Box.
	 *
	 * @return string
	 */
	private static function edited( Box $box ): string {
		$row     = $box->to_array();
		$updated = strtotime( (string) ( $row['updated_at'] ?? '' ) );

		if ( ! $updated ) {
			return __( 'Never', 'subscription-pro' );
		}

		/* translators: %s: human-readable time difference, e.g. "4 days". */
		return sprintf( __( '%s ago', 'subscription-pro' ), human_time_diff( $updated, time() ) );
	}

	/**
	 * Resolve product ids into something a view can print.
	 *
	 * @param int[] $ids Product ids.
	 *
	 * @return array[]
	 */
	private static function describe_ids( array $ids ): array {
		$items = array();

		foreach ( $ids as $id ) {
			$product   = wc_get_product( $id );
			$refusal   = self::pool_refusal( (int) $id, $product );
			$image_id  = $product ? (int) $product->get_image_id() : 0;
			$parent_id = $product ? (int) $product->get_parent_id() : 0;

			if ( ! $image_id && $parent_id ) {
				$image_id = (int) get_post_thumbnail_id( $parent_id );
			}

			// The parent lets the admin list group variations under their product.
			$items[] = array(
				'id'          => (int) $id,
				'parent_id'   => $parent_id,
				'parent_name' => $parent_id ? get_the_title( $parent_id ) : '',
				'name'        => $product ? $product->get_name() : __( '(deleted product)', 'subscription-pro' ),
				'sku'         => $product ? $product->get_sku() : '',
				'image'       => $image_id ? (string) wp_get_attachment_image_url( $image_id, 'thumbnail' ) : '',
				'missing'     => ! $product,
				'unusable'    => '' !== $refusal,
				'reason'      => $refusal,
			);
		}

		return $items;
	}

	/**
	 * Why the storefront would skip this pool entry, or '' when it would not.
	 *
	 * A pool can list a product the builder then refuses, and until now nothing
	 * said so anywhere: the merchant saw the product in the list and the shopper
	 * saw an empty grid. Naming the reason here is the whole point — "nothing is
	 * available for this box" is not a diagnosis.
	 *
	 * @param int              $id      Product id.
	 * @param \WC_Product|null $product Resolved product, if it still exists.
	 *
	 * @return string
	 */
	private static function pool_refusal( int $id, $product ): string {
		if ( ! $product instanceof \WC_Product ) {
			return __( 'Deleted, so it is skipped.', 'subscription-pro' );
		}

		if ( BoxProduct::is_box( $id ) ) {
			return __( 'Sells a box of its own, so it is skipped — a box inside a box would repeat at every renewal.', 'subscription-pro' );
		}

		if ( ! $product->is_in_stock() ) {
			return __( 'Out of stock, so it is not offered until it is back.', 'subscription-pro' );
		}

		if ( ! $product->is_purchasable() ) {
			return __( 'Has no price, so it cannot be put in a box.', 'subscription-pro' );
		}

		return '';
	}

	/**
	 * Resolve a stored selection into something a view can print.
	 *
	 * The stored snapshot already carries a name, so a deleted product still
	 * reads correctly — that is the whole point of snapshotting it.
	 *
	 * @param array $items Selection.
	 *
	 * @return array[]
	 */
	private static function describe_items( array $items ): array {
		$rows = array();

		foreach ( BoxProduct::normalise_items( $items ) as $item ) {
			$product = wc_get_product( $item['variation_id'] ? $item['variation_id'] : $item['product_id'] );

			$rows[] = array_merge(
				$item,
				array(
					'name'    => $product ? $product->get_name() : __( '(deleted product)', 'subscription-pro' ),
					'sku'     => $product ? $product->get_sku() : '',
					'missing' => ! $product,
				)
			);
		}

		return $rows;
	}

	/**
	 * The screen for one box.
	 *
	 * @param int $box_id Box id.
	 *
	 * @return string
	 */
	public static function detail_url( int $box_id ): string {
		return admin_url(
			'admin.php?page=' . Boxes::PAGE . '&view=detail&box=' . $box_id
		);
	}
}
