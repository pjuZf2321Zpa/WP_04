<?php
/**
 * Which boxes a product sells.
 *
 * The product editor used to *define* a box, in a tab of its own. It no longer
 * does: a box is a record with its own screen, and all a product says is which
 * ones it sells. That is one row, and it belongs beside the plan connection
 * rather than in a tab, because both answer the same question — what is this
 * product signed up to.
 *
 * Mounted on `subscrpt_simple_plan_panel` at a later priority than the free
 * plugin's plan view, so it lands under the plans and above the classic
 * subscription fields.
 *
 * @package SpringDevs\SubscriptionPro\Admin\Product
 */

namespace SpringDevs\SubscriptionPro\Admin\Product;

use SpringDevs\SubscriptionPro\Admin\BoxPresenter;
use SpringDevs\SubscriptionPro\Admin\Boxes;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxProduct;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxRepository;

defined( 'ABSPATH' ) || exit;

/**
 * The box connection row on a product.
 */
class BoxConnect {

	/**
	 * Register hooks.
	 */
	public function __construct() {
		// After the free plugin's plan view, which mounts on the same hook at
		// the default priority.
		add_action( 'subscrpt_simple_plan_panel', array( $this, 'render' ), 20 );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
	}

	/**
	 * Load the row's script on the product editor only.
	 *
	 * @param string $hook Current admin page.
	 *
	 * @return void
	 */
	public function enqueue( $hook ): void {
		if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
			return;
		}

		if ( 'product' !== get_post_type() ) {
			return;
		}

		wp_enqueue_style( 'subscrpt_admin_components' );
		wp_enqueue_script( 'subscrpt_admin_components' );

		// The row's own styles live with the Boxes screen's, which until now was
		// the only place that loaded them. Without this the row renders as
		// unstyled inline elements sitting on top of each other.
		wp_enqueue_style( 'subscrpt_box_admin_css' );

		wp_enqueue_script(
			'subscrpt_product_box_js',
			SUBSCRIPT_PRO_URL . '/assets/js/admin/product-box.js',
			array( 'jquery', 'subscrpt_admin_components' ),
			SUBSCRIPT_PRO_VERSION,
			true
		);

		wp_localize_script(
			'subscrpt_product_box_js',
			'subscrptProductBox',
			array(
				'restUrl' => esc_url_raw( rest_url( 'wpsubscription/v1/boxes' ) ),
				'nonce'   => wp_create_nonce( 'wp_rest' ),
				'i18n'    => array(
					'genericError'  => __( 'Something went wrong. Please try again.', 'subscription-pro' ),
					'confirmDetach' => __( 'Stop this product selling that box?', 'subscription-pro' ),
					'pickBox'       => __( 'Choose a box first.', 'subscription-pro' ),
				),
			)
		);
	}

	/**
	 * Render the row.
	 *
	 * @param int $product_id Product being edited.
	 *
	 * @return void
	 */
	public function render( $product_id ): void {
		$product_id = absint( $product_id );
		$product    = wc_get_product( $product_id );

		// Variable products connect per variation and are phase 8's problem;
		// free's plan view guards the same way here.
		if ( ! $product instanceof \WC_Product || ! $product->is_type( 'simple' ) ) {
			return;
		}

		$connections = BoxRepository::connections_for_product( $product_id );
		$available   = $this->available_boxes( $connections );
		$has_cadence = BoxProduct::has_cadence( $product_id );
		$boxes_url   = admin_url( 'admin.php?page=' . Boxes::PAGE );

		include SUBSCRIPT_PRO_PATH . '/templates/admin/product-box-connect.php';
	}

	/**
	 * Boxes this product does not already sell.
	 *
	 * A draft box is offered: connecting one is how a merchant gets it ready,
	 * and the row says it is a draft rather than hiding it.
	 *
	 * @param array[] $connections Existing connections.
	 *
	 * @return array[] Each entry: id, title, type_label, is_draft.
	 */
	private function available_boxes( array $connections ): array {
		$taken = array_map(
			static function ( $connection ) {
				return (int) $connection['box_id'];
			},
			$connections
		);

		$available = array();

		foreach ( BoxRepository::all( array( 'status' => 'any' ) ) as $box ) {
			if ( in_array( $box->id(), $taken, true ) ) {
				continue;
			}

			$available[] = array(
				'id'         => $box->id(),
				'title'      => $box->title(),
				'type_label' => BoxPresenter::type_label( $box->type() ),
				'is_draft'   => ! $box->is_active(),
			);
		}

		return $available;
	}
}
