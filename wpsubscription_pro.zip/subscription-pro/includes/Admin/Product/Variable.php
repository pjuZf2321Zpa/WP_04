<?php
/**
 * Variable-product subscription admin (Subscription product-data tab).
 *
 * @package SpringDevs\SubscriptionPro\Admin\Product
 */

namespace SpringDevs\SubscriptionPro\Admin\Product;

/**
 * Class Variable
 *
 * Renders the variable-product subscription settings in a dedicated
 * "Subscription" product-data tab (one section per variation) rather than
 * inside each variation row. Data stays per-variation (same `_subscrpt_*`
 * variation meta keys), so checkout / renewals are unchanged; only the admin
 * surface and the save path (product save instead of per-variation AJAX) move.
 *
 * @package SpringDevs\SubscriptionPro\Admin\Product
 */
class Variable {

	/**
	 * Initialize the class.
	 */
	public function __construct() {
		// Free registers the "Subscription" tab + panel shell; Pro fills the
		// variable panel with per-variation sections via this action.
		add_action( 'subscrpt_variable_subscription_panel', array( $this, 'render_panel_content' ) );
		add_action( 'woocommerce_process_product_meta', array( $this, 'save_variation_subscriptions' ) );
		add_action( 'edit_form_top', array( $this, 'display_convertation_notice' ) );
		add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes' ) );
		add_action( 'save_post_product', array( $this, 'save_data' ) );
	}

	/**
	 * Save Simple Product data
	 *
	 * @param int $post_id post ID.
	 */
	public function save_data( $post_id ) {
		if ( ! isset( $_POST['_subscript_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_subscript_nonce'] ) ), '_subscript_edit_product_nonce' ) ) {
			return;
		}

		if ( ! isset( $_POST['sdevs_variation_convertation'] ) ) {
			return false;
		}

		update_post_meta( $post_id, '_subscrpt_convertation_default_variation_for_renewal', (int) sanitize_text_field( wp_unslash( $_POST['sdevs_variation_convertation'] ) ) );
		delete_post_meta( $post_id, '_subscrpt_product_covertation' );
	}

	/**
	 * Whether this product is mid-conversion from simple to variable.
	 *
	 * The conversion flag outlives the type change — it is set when the switch
	 * begins and cleared only when a default variation is saved — so a product
	 * can carry it while still being simple, or after being changed back. Only a
	 * variable product has variations to offer, and only WC_Product_Variable has
	 * `get_available_variations()`: calling it on anything else is a fatal on the
	 * product edit screen, which takes the whole product data panel — the
	 * Subscription tab included — down with it.
	 *
	 * @return \WC_Product|null The product when the conversion applies, else null.
	 */
	private function converting_product() {
		if ( 'product' !== get_post_type() ) {
			return null;
		}

		$product = wc_get_product( get_the_ID() );

		if ( ! $product || ! $product->is_type( 'variable' ) ) {
			return null;
		}

		return 'simple_to_variable' === $product->get_meta( '_subscrpt_product_covertation' ) ? $product : null;
	}

	/**
	 * "Default renewal variation" meta box, shown while a subscription product
	 * is being converted from simple to variable.
	 */
	public function add_meta_boxes() {
		$product = $this->converting_product();

		if ( ! $product ) {
			return;
		}

		add_meta_box(
			'subscrpt_simple_to_variable_convertation',
			// Named for the plugin: this box sits among WooCommerce's own on the
			// product screen, and nothing else on it says where it came from.
			__( 'WPSubscription — Default renewal variation', 'subscription-pro' ),
			array( $this, 'subscrpt_simple_to_variable_convertation' ),
			'product',
			'normal',
			'high',
			array(
				'variations' => $product->get_available_variations(),
			)
		);
	}

	/**
	 * Subscription product simple to variable convertation.
	 *
	 * @param \WC_Product $product Product object.
	 * @param array       $args Arguments.
	 *
	 * @return void
	 */
	public function subscrpt_simple_to_variable_convertation( $product, $args ) {
		$variations = $args['args']['variations'];
		$variations = array_filter(
			$variations,
			function ( $variation ) {
				$enabled = get_post_meta( $variation['variation_id'], '_subscrpt_enabled', true );
				if ( $enabled ) {
					return true;
				}
				return false;
			}
		);
		?>
		<?php // Uses free's shared admin components, enqueued on every product screen. ?>
		<div class="wpsubs-settings-field" style="align-items:flex-start;">
			<div class="wpsubs-settings-field__label">
				<label for="sdevs_variation_convertation"><?php esc_html_e( 'Renewal variation', 'subscription-pro' ); ?></label>
			</div>
			<div class="wpsubs-settings-field__control">
				<?php if ( empty( $variations ) ) : ?>
					<p class="wpsubs-settings-field__hint" style="margin:0;">
						<?php esc_html_e( 'No subscription-enabled variations yet. Add a variation, switch its subscription on, then reload this page.', 'subscription-pro' ); ?>
					</p>
				<?php else : ?>
					<select class="wpsubs-select" name="sdevs_variation_convertation" id="sdevs_variation_convertation">
						<?php foreach ( $variations as $variation ) : ?>
							<option value="<?php echo esc_attr( $variation['variation_id'] ); ?>">
								<?php echo esc_html( self::variation_option_label( $variation ) ); ?>
							</option>
						<?php endforeach; ?>
					</select>
					<p class="wpsubs-settings-field__hint">
						<?php esc_html_e( 'Customers already subscribed to this product renew onto the variation chosen here.', 'subscription-pro' ); ?>
					</p>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Label one variation in the picker.
	 *
	 * The bare variation id told a merchant nothing about which variation they
	 * were choosing; the attribute summary is what they recognise.
	 *
	 * @param array $variation Row from WC_Product_Variable::get_available_variations().
	 * @return string
	 */
	private static function variation_option_label( $variation ) {
		$parts = array();

		foreach ( (array) ( $variation['attributes'] ?? array() ) as $value ) {
			if ( '' !== $value ) {
				$parts[] = ucfirst( str_replace( array( '-', '_' ), ' ', (string) $value ) );
			}
		}

		$id = (int) ( $variation['variation_id'] ?? 0 );

		return $parts
			/* translators: 1: variation attributes, 2: variation id. */
			? sprintf( __( '%1$s (#%2$d)', 'subscription-pro' ), implode( ' / ', $parts ), $id )
			/* translators: %d: variation ID. */
			: sprintf( __( 'Variation #%d', 'subscription-pro' ), $id );
	}

	/**
	 * Display convertation notice.
	 */
	public function display_convertation_notice() {
		if ( ! $this->converting_product() ) {
			return;
		}
		?>
		<div class="notice notice-warning">
			<p>
				<strong><?php esc_html_e( 'WPSubscription', 'subscription-pro' ); ?></strong>
				&mdash;
				<?php esc_html_e( 'this product is being converted from simple to variable. Choose the variation existing subscribers renew onto, below.', 'subscription-pro' ); ?>
			</p>
		</div>
		<?php
	}

	/**
	 * Render the variable-product subscription content inside free's
	 * Subscription tab panel: one section per variation.
	 *
	 * @param \WC_Product $product Variable product being edited.
	 *
	 * @return void
	 */
	public function render_panel_content( $product ) {
		if ( ! $product || ! $product->is_type( 'variable' ) ) {
			return;
		}

		$subscrpt_plans = '\SpringDevs\Subscription\Admin\Product\Plans';

		// Mirror the simple-product tab: a plan view (connect the product to a
		// plan group) by default, with the per-variation classic settings behind
		// the "Switch to classic settings" toggle. Falls back to just the classic
		// accordion if the free plan view is unavailable.
		if ( ! class_exists( $subscrpt_plans ) ) {
			require __DIR__ . '/views/variable-panel.php';
			return;
		}
		?>
		<div data-subscrpt-product-plans data-product-id="<?php echo esc_attr( $product->get_id() ); ?>"<?php echo $subscrpt_plans::should_default_classic( $product ) ? ' data-subscrpt-default-classic="1"' : ''; ?> style="margin-bottom:16px;">
			<?php $subscrpt_plans::render_toolbar( $product ); ?>
			<div data-subscrpt-plan-view>
				<?php $subscrpt_plans::render_plan_view( $product ); ?>
			</div>
			<div data-subscrpt-classic-view style="display:none;">
				<?php require __DIR__ . '/views/variable-panel.php'; ?>
			</div>
		</div>
		<?php
		$subscrpt_plans::render_checkout_link_modal( $product );
		$subscrpt_plans::render_modals();
	}

	/**
	 * Get a variation meta value, falling back to a default when empty.
	 *
	 * @param int    $variation_id Variation post ID.
	 * @param string $key          Meta key.
	 * @param mixed  $fallback     Value when the meta is empty.
	 *
	 * @return mixed
	 */
	protected function meta_or( $variation_id, $key, $fallback ) {
		$value = get_post_meta( $variation_id, $key, true );
		return ( '' === $value || null === $value || false === $value ) ? $fallback : $value;
	}

	/**
	 * Render one variation's subscription fields inside the tab.
	 *
	 * Field names are grouped as subscrpt_var[<variation_id>][<field>] so they
	 * are submitted with the product form and saved on product save.
	 *
	 * @param \WC_Product_Variation $variation Variation product.
	 *
	 * @return void
	 */
	protected function render_variation_section( $variation ) {
		$variation_id = $variation->get_id();
		$name         = wc_get_formatted_variation( $variation, true, false, false );
		if ( '' === $name ) {
			/* translators: %d: variation ID. */
			$name = sprintf( __( 'Variation #%d', 'subscription-pro' ), $variation_id );
		}

		$timing_types = wps_subscription_get_timing_types();

		$enabled              = (bool) get_post_meta( $variation_id, '_subscrpt_enabled', true );
		$subscrpt_time        = get_post_meta( $variation_id, '_subscrpt_timing_per', true );
		$subscrpt_timing      = get_post_meta( $variation_id, '_subscrpt_timing_option', true );
		$subscrpt_trial_time  = get_post_meta( $variation_id, '_subscrpt_trial_timing_per', true );
		$subscrpt_trial_type  = get_post_meta( $variation_id, '_subscrpt_trial_timing_option', true );
		$subscrpt_user_cancel = get_post_meta( $variation_id, '_subscrpt_user_cancel', true );
		$subscrpt_signup_fee  = get_post_meta( $variation_id, '_subscrpt_signup_fee', true );
		$subscrpt_limit       = get_post_meta( $variation_id, '_subscrpt_limit', true );

		$subscrpt_max_no_payment = $this->meta_or( $variation_id, '_subscrpt_max_no_payment', 0 );

		$subscrpt_payment_type                = $this->meta_or( $variation_id, '_subscrpt_payment_type', 'recurring' );
		$subscrpt_access_ends_timing          = $this->meta_or( $variation_id, '_subscrpt_access_ends_timing', 'after_full_duration' );
		$subscrpt_custom_access_duration_time = $this->meta_or( $variation_id, '_subscrpt_custom_access_duration_time', 1 );
		$subscrpt_custom_access_duration_type = $this->meta_or( $variation_id, '_subscrpt_custom_access_duration_type', 'months' );

		$subscrpt_delivery_timing_per           = get_post_meta( $variation_id, '_subscrpt_delivery_timing_per', true );
		$subscrpt_delivery_timing_option        = get_post_meta( $variation_id, '_subscrpt_delivery_timing_option', true );
		$subscrpt_synchronize_delivery_schedule = get_post_meta( $variation_id, '_subscrpt_synchronize_delivery_schedule', true );
		$subscrpt_synchronize_delivery_day      = get_post_meta( $variation_id, '_subscrpt_synchronize_delivery_day', true );

		$base = 'subscrpt_var[' . $variation_id . ']';

		require __DIR__ . '/views/variation-section.php';
	}

	/**
	 * Save each variation's subscription meta from the product-level tab.
	 *
	 * Runs on product save (WooCommerce verifies its own meta nonce). Iterates
	 * the product's variations so unchecked checkboxes are handled correctly.
	 *
	 * @param int $post_id Product post ID.
	 *
	 * @return void
	 */
	public function save_variation_subscriptions( $post_id ) {
		if ( ! current_user_can( 'edit_product', $post_id ) ) {
			return;
		}

		$product = wc_get_product( $post_id );
		if ( ! $product || ! $product->is_type( 'variable' ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- WC verifies woocommerce_meta_nonce; each field is sanitized individually below.
		$raw = isset( $_POST['subscrpt_var'] ) ? wp_unslash( $_POST['subscrpt_var'] ) : array();
		if ( ! is_array( $raw ) ) {
			$raw = array();
		}

		// The product-level enable flag mirrors "any variation is a subscription".
		// Enable is now per variation (plan view: each variation's toggle; classic
		// view: subscrpt_var[<vid>][enabled]); there is no product-level toggle.
		$subscrpt_any_enabled = false;

		foreach ( $product->get_children() as $variation_id ) {
			$fields  = isset( $raw[ $variation_id ] ) && is_array( $raw[ $variation_id ] ) ? $raw[ $variation_id ] : array();
			$enabled = isset( $fields['enabled'] );

			$subscrpt_any_enabled = $subscrpt_any_enabled || $enabled;

			$payment_type = isset( $fields['payment_type'] ) ? sanitize_text_field( $fields['payment_type'] ) : 'recurring';

			if ( 'split_payment' === $payment_type ) {
				$max_no_payment = isset( $fields['max_no_payment_split'] ) ? (int) $fields['max_no_payment_split'] : 2;
			} else {
				$max_no_payment = 0;
			}

			update_post_meta( $variation_id, '_subscrpt_enabled', $enabled );
			update_post_meta( $variation_id, '_subscrpt_timing_per', isset( $fields['timing_per'] ) ? sanitize_text_field( $fields['timing_per'] ) : '' );
			update_post_meta( $variation_id, '_subscrpt_timing_option', isset( $fields['timing_option'] ) ? sanitize_text_field( $fields['timing_option'] ) : '' );
			update_post_meta( $variation_id, '_subscrpt_trial_timing_per', isset( $fields['trial_timing_per'] ) ? sanitize_text_field( $fields['trial_timing_per'] ) : '' );
			update_post_meta( $variation_id, '_subscrpt_trial_timing_option', isset( $fields['trial_timing_option'] ) ? sanitize_text_field( $fields['trial_timing_option'] ) : '' );
			update_post_meta( $variation_id, '_subscrpt_cart_btn_label', '' );
			update_post_meta( $variation_id, '_subscrpt_user_cancel', isset( $fields['user_cancel'] ) ? sanitize_text_field( $fields['user_cancel'] ) : 'yes' );
			update_post_meta( $variation_id, '_subscrpt_signup_fee', isset( $fields['signup_fee'] ) ? sanitize_text_field( $fields['signup_fee'] ) : '' );
			update_post_meta( $variation_id, '_subscrpt_limit', isset( $fields['limit'] ) ? sanitize_text_field( $fields['limit'] ) : 'unlimited' );
			update_post_meta( $variation_id, '_subscrpt_max_no_payment', $max_no_payment );

			update_post_meta( $variation_id, '_subscrpt_payment_type', $payment_type );
			update_post_meta( $variation_id, '_subscrpt_access_ends_timing', isset( $fields['access_ends_timing'] ) ? sanitize_text_field( $fields['access_ends_timing'] ) : 'after_full_duration' );
			update_post_meta( $variation_id, '_subscrpt_custom_access_duration_time', isset( $fields['custom_access_duration_time'] ) ? (int) $fields['custom_access_duration_time'] : 1 );
			update_post_meta( $variation_id, '_subscrpt_custom_access_duration_type', isset( $fields['custom_access_duration_type'] ) ? sanitize_text_field( $fields['custom_access_duration_type'] ) : 'months' );

			update_post_meta( $variation_id, '_subscrpt_delivery_timing_per', isset( $fields['delivery_timing_per'] ) ? sanitize_text_field( $fields['delivery_timing_per'] ) : null );
			update_post_meta( $variation_id, '_subscrpt_delivery_timing_option', isset( $fields['delivery_timing_option'] ) ? sanitize_text_field( $fields['delivery_timing_option'] ) : null );
			update_post_meta( $variation_id, '_subscrpt_synchronize_delivery_schedule', isset( $fields['synchronize_delivery_schedule'] ) ? 'yes' : 'no' );
			update_post_meta( $variation_id, '_subscrpt_synchronize_delivery_day', isset( $fields['synchronize_delivery_day'] ) ? sanitize_text_field( $fields['synchronize_delivery_day'] ) : null );
		}

		update_post_meta( $post_id, '_subscrpt_enabled', $subscrpt_any_enabled ? 'yes' : '' );
	}
}
