<?php
/**
 * One variation's subscription settings as an accordion section.
 *
 * Uses the same native WooCommerce field markup + sdevs_subscrpt_recurring_field()
 * helper as the simple-product panel, so the layout matches. Rendered by
 * Variable::render_variation_section(), which prepares the variables below.
 * Field names are grouped as subscrpt_var[<variation_id>][<field>] so they save
 * on product save.
 *
 * @var int                    $variation_id                         Variation post ID.
 * @var string                 $name                                 Variation display name.
 * @var array                  $timing_types                         Timing option list.
 * @var bool                   $enabled                              Subscription enabled?
 * @var string                 $base                                 Field name prefix.
 * @var \WC_Product_Variation  $variation                            Variation product.
 * @var mixed                  $subscrpt_time                        Billing frequency.
 * @var mixed                  $subscrpt_timing                      Billing interval.
 * @var mixed                  $subscrpt_trial_time                  Trial length.
 * @var mixed                  $subscrpt_trial_type                  Trial interval.
 * @var mixed                  $subscrpt_user_cancel                 Allow user cancel.
 * @var mixed                  $subscrpt_signup_fee                  Signup fee.
 * @var mixed                  $subscrpt_limit                       Purchase limit.
 * @var mixed                  $subscrpt_max_no_payment              Split payment count.
 * @var string                 $subscrpt_payment_type                recurring|split_payment.
 * @var string                 $subscrpt_access_ends_timing          Access-ends option.
 * @var mixed                  $subscrpt_custom_access_duration_time Custom access length.
 * @var string                 $subscrpt_custom_access_duration_type Custom access interval.
 * @var mixed                  $subscrpt_delivery_timing_per         Delivery frequency.
 * @var mixed                  $subscrpt_delivery_timing_option      Delivery interval.
 * @var string                 $subscrpt_synchronize_delivery_schedule Sync schedule (yes/no).
 * @var mixed                  $subscrpt_synchronize_delivery_day    Sync weekday.
 *
 * @package SpringDevs\SubscriptionPro\Admin\Product
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$subscrpt_panel_id = 'subscrpt-var-panel-' . $variation_id;
?>
<div class="wpsubs-accordion__item subscrpt-var" data-variation-id="<?php echo esc_attr( $variation_id ); ?>">
	<div class="subscrpt-var__head">
		<button type="button" class="wpsubs-accordion__header wpsubs-accordion__header--chevron-start subscrpt-var__toggle" aria-controls="<?php echo esc_attr( $subscrpt_panel_id ); ?>" aria-expanded="false">
			<span class="subscrpt-var__name"><?php echo esc_html( $name ); ?></span>
		</button>
		<label class="wpsubs-settings-toggle-label subscrpt-var__enable">
			<input type="checkbox" class="wpsubs-toggle subscrpt-var-enable" id="subscrpt_var_enabled_<?php echo esc_attr( $variation_id ); ?>" name="<?php echo esc_attr( $base ); ?>[enabled]" value="yes" <?php checked( $enabled ); ?> />
			<span class="wpsubs-toggle-ui" aria-hidden="true"></span>
			<span><?php esc_html_e( 'Enable subscription', 'subscription-pro' ); ?></span>
		</label>
	</div>

	<div class="wpsubs-accordion__panel subscrpt-var__body" id="<?php echo esc_attr( $subscrpt_panel_id ); ?>" hidden>
		<div class="subscrpt-var-config options_group">
			<p class="form-field subscrpt_field">
				<label for="<?php echo esc_attr( $base ); ?>[payment_type]"><?php esc_html_e( 'Payment Type', 'subscription-pro' ); ?></label>
				<select name="<?php echo esc_attr( $base ); ?>[payment_type]" class="select short subscrpt-var-payment-type">
					<option value="recurring" <?php selected( $subscrpt_payment_type, 'recurring' ); ?>><?php esc_html_e( 'Recurring', 'subscription-pro' ); ?></option>
					<option value="split_payment" <?php selected( $subscrpt_payment_type, 'split_payment' ); ?>><?php esc_html_e( 'Split Payment', 'subscription-pro' ); ?></option>
				</select>
				<small class="description"><?php esc_html_e( 'Choose between recurring payments or split payment installments.', 'subscription-pro' ); ?></small>
			</p>

			<?php
			sdevs_subscrpt_recurring_field(
				array(
					'time' => array(
						'label' => __( 'Repeat payment every', 'subscription-pro' ),
						'name'  => $base . '[timing_per]',
						'value' => $subscrpt_time,
						'attrs' => array( 'min' => 1 ),
					),
					'type' => array(
						'name'    => $base . '[timing_option]',
						'value'   => $subscrpt_timing,
						'options' => $timing_types,
					),
					'desc' => __( 'Set how often the user will be charged (e.g. every week, month, or year).', 'subscription-pro' ),
				)
			);

			sdevs_subscrpt_recurring_field(
				array(
					'time' => array(
						'label' => __( 'Free Trial Duration', 'subscription-pro' ),
						'name'  => $base . '[trial_timing_per]',
						'value' => $subscrpt_trial_time,
						'attrs' => array( 'min' => 1 ),
					),
					'type' => array(
						'name'    => $base . '[trial_timing_option]',
						'value'   => $subscrpt_trial_type,
						'options' => $timing_types,
					),
					'desc' => __( 'Let users try the subscription for free before the first payment is collected.', 'subscription-pro' ),
				)
			);
			?>

			<p class="form-field subscrpt_field">
				<label for="<?php echo esc_attr( $base ); ?>[signup_fee]"><?php echo esc_html( sprintf( /* translators: %s: currency symbol. */ __( 'Sign-Up Fee (%s)', 'subscription-pro' ), get_woocommerce_currency_symbol() ) ); ?></label>
				<input type="text" class="short" name="<?php echo esc_attr( $base ); ?>[signup_fee]" value="<?php echo esc_attr( $subscrpt_signup_fee ); ?>" />
			</p>

			<div class="subscrpt-var-split" style="<?php echo ( 'split_payment' !== $subscrpt_payment_type ) ? 'display:none;' : ''; ?>">
				<p class="subscrpt-var-heading"><strong><?php esc_html_e( 'Split Payment', 'subscription-pro' ); ?></strong></p>
				<p class="form-field subscrpt_field">
					<label for="<?php echo esc_attr( $base ); ?>[max_no_payment_split]"><?php esc_html_e( 'Number of Payments', 'subscription-pro' ); ?></label>
					<input type="number" class="short" name="<?php echo esc_attr( $base ); ?>[max_no_payment_split]" value="<?php echo esc_attr( 'split_payment' === $subscrpt_payment_type ? $subscrpt_max_no_payment : 2 ); ?>" min="2" step="1" />
					<small class="description"><?php esc_html_e( 'Set how many installments this split payment will have. Must be greater than 1.', 'subscription-pro' ); ?></small>
				</p>
				<p class="form-field subscrpt_field">
					<label for="<?php echo esc_attr( $base ); ?>[access_ends_timing]"><?php esc_html_e( 'Access Ends Timing', 'subscription-pro' ); ?></label>
					<select name="<?php echo esc_attr( $base ); ?>[access_ends_timing]" class="select short subscrpt-var-access-ends">
						<option value="lifetime" <?php selected( $subscrpt_access_ends_timing, 'lifetime' ); ?>><?php esc_html_e( 'Lifetime access after completion', 'subscription-pro' ); ?></option>
						<option value="after_full_duration" <?php selected( $subscrpt_access_ends_timing, 'after_full_duration' ); ?>><?php esc_html_e( 'After full access duration (default)', 'subscription-pro' ); ?></option>
						<option value="custom_duration" <?php selected( $subscrpt_access_ends_timing, 'custom_duration' ); ?>><?php esc_html_e( 'Custom access duration', 'subscription-pro' ); ?></option>
					</select>
					<small class="description"><?php esc_html_e( 'Choose when access should end for split payment subscriptions.', 'subscription-pro' ); ?></small>
				</p>
				<div class="subscrpt-var-custom-duration" style="<?php echo ( 'custom_duration' !== $subscrpt_access_ends_timing ) ? 'display:none;' : ''; ?>">
					<?php
					sdevs_subscrpt_recurring_field(
						array(
							'time' => array(
								'label' => __( 'Custom Access Duration', 'subscription-pro' ),
								'name'  => $base . '[custom_access_duration_time]',
								'value' => $subscrpt_custom_access_duration_time,
								'attrs' => array( 'min' => 1 ),
							),
							'type' => array(
								'name'    => $base . '[custom_access_duration_type]',
								'value'   => $subscrpt_custom_access_duration_type,
								'options' => $timing_types,
							),
							'desc' => __( 'Define how long access should continue after the first payment is completed.', 'subscription-pro' ),
						)
					);
					?>
				</div>
			</div>

			<p class="subscrpt-var-heading"><strong><?php esc_html_e( 'Advanced Settings', 'subscription-pro' ); ?></strong></p>

			<p class="form-field subscrpt_field">
				<label for="<?php echo esc_attr( $base ); ?>[limit]"><?php esc_html_e( 'Purchase Limit', 'subscription-pro' ); ?></label>
				<select name="<?php echo esc_attr( $base ); ?>[limit]" class="select short">
					<option value="unlimited"><?php esc_html_e( 'Do not limit', 'subscription-pro' ); ?></option>
					<option value="one" <?php selected( $subscrpt_limit, 'one' ); ?>><?php esc_html_e( 'allow only one active subscription', 'subscription-pro' ); ?></option>
					<option value="only_one" <?php selected( $subscrpt_limit, 'only_one' ); ?>><?php esc_html_e( 'allow only one subscription of any status', 'subscription-pro' ); ?></option>
				</select>
			</p>

			<p class="form-field subscrpt_field">
				<label for="<?php echo esc_attr( $base ); ?>[user_cancel]"><?php esc_html_e( 'Allow User Cancellation?', 'subscription-pro' ); ?></label>
				<select name="<?php echo esc_attr( $base ); ?>[user_cancel]" class="select short">
					<option value="yes" <?php selected( $subscrpt_user_cancel, 'yes' ); ?>><?php esc_html_e( 'Yes', 'subscription-pro' ); ?></option>
					<option value="no" <?php selected( $subscrpt_user_cancel, 'no' ); ?>><?php esc_html_e( 'No', 'subscription-pro' ); ?></option>
				</select>
			</p>

			<?php if ( ! $variation->is_virtual() ) : ?>
				<p class="subscrpt-var-heading"><strong><?php esc_html_e( 'Delivery Settings', 'subscription-pro' ); ?></strong></p>
				<?php
				sdevs_subscrpt_recurring_field(
					array(
						'time' => array(
							'label' => __( 'Delivery schedule will every', 'subscription-pro' ),
							'name'  => $base . '[delivery_timing_per]',
							'value' => $subscrpt_delivery_timing_per,
							'attrs' => array( 'min' => 1 ),
						),
						'type' => array(
							'name'    => $base . '[delivery_timing_option]',
							'value'   => $subscrpt_delivery_timing_option,
							'options' => $timing_types,
						),
						'desc' => __( 'Set a delivery schedule for this variation.', 'subscription-pro' ),
					)
				);
				?>
				<p class="form-field">
					<label for="subscrpt_var_sync_<?php echo esc_attr( $variation_id ); ?>"><?php esc_html_e( 'Synchronize Schedule', 'subscription-pro' ); ?></label>
					<input type="checkbox" class="checkbox subscrpt-var-sync" id="subscrpt_var_sync_<?php echo esc_attr( $variation_id ); ?>" name="<?php echo esc_attr( $base ); ?>[synchronize_delivery_schedule]" value="yes" <?php checked( $subscrpt_synchronize_delivery_schedule, 'yes' ); ?> />
					<span class="description"><?php esc_html_e( 'Enable if you want to ship the product on a specific day.', 'subscription-pro' ); ?></span>
				</p>
				<p class="form-field subscrpt-var-sync-day" style="display:<?php echo 'yes' === $subscrpt_synchronize_delivery_schedule ? 'block' : 'none'; ?>;">
					<label for="<?php echo esc_attr( $base ); ?>[synchronize_delivery_day]"><?php esc_html_e( 'Sync Day', 'subscription-pro' ); ?></label>
					<select name="<?php echo esc_attr( $base ); ?>[synchronize_delivery_day]" class="select short">
						<?php
						$week_days = array(
							'Mon' => __( 'Monday', 'subscription-pro' ),
							'Tue' => __( 'Tuesday', 'subscription-pro' ),
							'Wed' => __( 'Wednesday', 'subscription-pro' ),
							'Thu' => __( 'Thursday', 'subscription-pro' ),
							'Fri' => __( 'Friday', 'subscription-pro' ),
							'Sat' => __( 'Saturday', 'subscription-pro' ),
							'Sun' => __( 'Sunday', 'subscription-pro' ),
						);
						foreach ( $week_days as $key => $value ) {
							echo '<option value="' . esc_attr( $key ) . '"' . selected( $subscrpt_synchronize_delivery_day, $key, false ) . '>' . esc_html( $value ) . '</option>';
						}
						?>
					</select>
				</p>
			<?php endif; ?>
		</div>
	</div>
</div>
