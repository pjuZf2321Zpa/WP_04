<?php
/**
 * Layout glue + conditional-field toggle script for the variable-product
 * Subscription tab. The accordion and the on/off switch reuse the shared
 * `wpsubs-accordion` and `wpsubs-toggle` admin components (already enqueued on
 * the product screen); only the header row layout and field spacing are added
 * here. Included once after the variation sections.
 *
 * @package SpringDevs\SubscriptionPro\Admin\Product
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<style>
	.subscrpt-var-list { padding: 6px 12px 12px; }

	/* Header row: accordion header button + enable toggle side by side. */
	.subscrpt-var__head { display: flex; align-items: stretch; }
	.subscrpt-var__head .wpsubs-accordion__header { flex: 1 1 auto; min-width: 0; }
	.subscrpt-var__name { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
	/* Enable toggle styled like the one-time-purchase toggle in the plan view. */
	.subscrpt-var__enable {
		margin: 0;
		padding: 0 14px;
		flex: 0 0 auto;
		display: inline-flex;
		align-items: center;
		gap: 6px;
		font-size: 12px;
		color: var(--wpsubs-text-muted);
	}

	/* The fields inside use WooCommerce's native options-panel layout (same as
		the simple-product panel); only add a little breathing room. */
	.subscrpt-var__body .subscrpt-var-config { padding: 10px 0; }
	.subscrpt-var__body .subscrpt-var-heading {
		margin: 16px 0 4px;
		padding-left: 12px;
		font-size: 12px;
	}
	.subscrpt-var__body .subscrpt-var-heading strong { color: #1d2327; }
</style>
<script type="text/javascript">
	jQuery(function ($) {
		var panel = $('#sdevs_subscription_options');

		// Enabling a variation opens its section so the settings are visible.
		panel.on('change', '.subscrpt-var-enable', function () {
			if (this.checked) {
				var header = $(this).closest('.subscrpt-var').find('.wpsubs-accordion__header')[0];
				if (header && 'true' !== header.getAttribute('aria-expanded')) {
					header.click();
				}
			}
		});
		panel.on('change', '.subscrpt-var-payment-type', function () {
			$(this).closest('.subscrpt-var').find('.subscrpt-var-split').toggle('split_payment' === $(this).val());
		});
		panel.on('change', '.subscrpt-var-access-ends', function () {
			$(this).closest('.subscrpt-var').find('.subscrpt-var-custom-duration').toggle('custom_duration' === $(this).val());
		});
		panel.on('change', '.subscrpt-var-sync', function () {
			$(this).closest('.subscrpt-var').find('.subscrpt-var-sync-day').toggle(this.checked);
		});
	});
</script>
