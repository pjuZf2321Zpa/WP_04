<?php
/**
 * Variable-product Subscription tab content (inside free's panel shell).
 *
 * Rendered by Variable::render_panel_content(). Lists each variation as an
 * accordion section. `$product` and `$this` (the Variable instance) are in
 * scope because this file is required from within the method.
 *
 * @var \WC_Product                                    $product Variable product.
 * @var \SpringDevs\SubscriptionPro\Admin\Product\Variable $this Variable admin instance.
 *
 * @package SpringDevs\SubscriptionPro\Admin\Product
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$variation_ids = $product->get_children();
?>
<?php if ( empty( $variation_ids ) ) : ?>
	<div class="options_group">
		<p style="padding:0 12px;"><?php esc_html_e( 'Add and save variations first, then set each one\'s subscription options here.', 'subscription-pro' ); ?></p>
	</div>
<?php else : ?>
	<div class="options_group">
		<p style="padding:0 12px;"><?php esc_html_e( 'Set the subscription options for each variation. Enable it to sell that variation as a subscription.', 'subscription-pro' ); ?></p>
	</div>
	<div class="wpsubs-accordion subscrpt-var-list" data-multi="1">
		<?php
		foreach ( $variation_ids as $subscrpt_variation_id ) {
			$subscrpt_variation = wc_get_product( $subscrpt_variation_id );
			if ( $subscrpt_variation ) {
				$this->render_variation_section( $subscrpt_variation );
			}
		}
		?>
	</div>
	<?php require __DIR__ . '/variation-tab-assets.php'; ?>
<?php endif; ?>
