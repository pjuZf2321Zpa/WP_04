<?php
/**
 * Pro settings registration.
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

namespace SpringDevs\SubscriptionPro\Admin;

/**
 * Class Settings
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */
class Settings {

	/**
	 * Initialize the class
	 */
	public function __construct() {
		add_action( 'admin_init', array( $this, 'register_settings' ) );

		// Settings UI (fields) is defined in the free plugin (ProSettingsFields); Pro only registers the options.
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
	}

	/**
	 * Register settings
	 */
	public function register_settings() {
		register_setting( 'wp_subscription_settings', 'subscrpt_renewal_price' );
		register_setting( 'wp_subscription_settings', 'subscrpt_early_renew' );
		register_setting( 'wp_subscription_settings', 'subscrpt_early_renew_visibility', array( 'sanitize_callback' => 'sanitize_key' ) );
		register_setting( 'wp_subscription_settings', 'subscrpt_early_renew_before_days', array( 'sanitize_callback' => 'absint' ) );
		register_setting( 'wp_subscription_settings', 'subscrpt_early_renew_day_of_month', array( 'sanitize_callback' => 'absint' ) );
		register_setting( 'wp_subscription_settings', 'subscrpt_early_renew_cycle_left', array( 'sanitize_callback' => 'absint' ) );
		register_setting( 'wp_subscription_settings', 'subscrpt_require_payment_on_trial' );
		register_setting( 'wp_subscription_settings', 'wpsubscription_api_key' );
		register_setting( 'wp_subscription_settings', 'wpsubscription_api_enabled' );

		// Payment Failure Handling Settings
		register_setting( 'wp_subscription_settings', 'subscrpt_default_max_payment_retries' );
		register_setting( 'wp_subscription_settings', 'subscrpt_default_payment_grace_period' );
		register_setting( 'wp_subscription_settings', 'subscrpt_enable_payment_failure_emails' );
		register_setting( 'wp_subscription_settings', 'subscrpt_payment_failure_email_delay' );
		register_setting( 'wp_subscription_settings', 'subscrpt_enable_grace_period_notifications' );
		register_setting( 'wp_subscription_settings', 'subscrpt_grace_period_warning_days' );
		register_setting( 'wp_subscription_settings', 'subscrpt_health_queue_email_frequency' );

		// License Settings.
		register_setting(
			'wp_subscription_settings',
			'subscrpt_regenerate_license_on_renewal',
			array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			)
		);
		register_setting(
			'wp_subscription_settings',
			'subscrpt_deactivate_old_license_on_renewal',
			array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			)
		);
	}

	/**
	 * Enqueue admin scripts
	 */
	public function enqueue_scripts() {
		wp_enqueue_script( 'subscrpt_admin_api_js' );
		wp_localize_script(
			'subscrpt_admin_api_js',
			'subscrptPro',
			array(
				'ajaxurl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'subscrpt_pro_ajax_nonce' ),
			)
		);
	}

	/**
	 * Get the settings sections.
	 *
	 * @return array
	 */
	public function get_settings_sections() {
		return array(
			array(
				'id'    => 'wpsubscription_general',
				'title' => __( 'General Settings', 'subscription-pro' ),
			),
			array(
				'id'    => 'wpsubscription_payment_failure',
				'title' => __( 'Payment Failure Handling', 'subscription-pro' ),
			),
			array(
				'id'    => 'wpsubscription_api',
				'title' => __( 'API Settings', 'subscription-pro' ),
			),
		);
	}

	/**
	 * Generate a new API key
	 *
	 * @return string
	 */
	private function generate_api_key() {
		$api_key = get_option( 'wpsubscription_api_key' );
		if ( empty( $api_key ) ) {
			$api_key = wp_generate_password( 32, false );
			update_option( 'wpsubscription_api_key', $api_key );
		}
		return $api_key;
	}
}
