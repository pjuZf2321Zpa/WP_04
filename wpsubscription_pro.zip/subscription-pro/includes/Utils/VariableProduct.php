<?php
/**
 * Subscription data for product variations.
 *
 * @package SpringDevs\SubscriptionPro\Utils
 */

namespace SpringDevs\SubscriptionPro\Utils;

use SpringDevs\Subscription\Utils\Product;
use SpringDevs\SubscriptionPro\Illuminate\Helper;

/**
 * Subscription data for a product variation.
 */
class VariableProduct extends Product {

	/**
	 * Get the billing interval count, at least 1.
	 *
	 * @return int
	 */
	public function get_timing_per(): int {
		return max( (int) $this->product->get_meta( '_subscrpt_timing_per' ), 1 );
	}

	/**
	 * Whether the variation has a trial and the customer has no prior subscription to it.
	 *
	 * @return bool
	 */
	public function has_trial(): bool {
		$trial_timing_per = $this->get_trial_timing_per();
		$product_id       = $this->product->get_id();

		return ( $trial_timing_per > 0 ) && Helper::check_trial( $product_id );
	}

	/**
	 * Get the sign-up fee.
	 *
	 * @return float
	 */
	public function get_signup_fee(): float {
		return (float) $this->product->get_meta( '_subscrpt_signup_fee' );
	}
}
