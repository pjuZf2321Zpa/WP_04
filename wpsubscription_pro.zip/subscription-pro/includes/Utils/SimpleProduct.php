<?php
/**
 * Subscription data for simple products.
 *
 * @package SpringDevs\SubscriptionPro\Utils
 */

namespace SpringDevs\SubscriptionPro\Utils;

use SpringDevs\Subscription\Utils\Product;

/**
 * Subscription data for a simple product.
 */
class SimpleProduct extends Product {

	/**
	 * Get the billing interval count.
	 *
	 * @return int
	 */
	public function get_timing_per(): int {
		return (int) $this->product->get_meta( '_subscrpt_timing_per' ) ?? 1;
	}

	/**
	 * Get the sign-up fee.
	 *
	 * @return float
	 */
	public function get_signup_fee(): float {
		return (float) $this->product->get_meta( '_subscrpt_signup_fee' );
	}
}
