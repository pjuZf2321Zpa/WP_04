<?php
/**
 * The box in My Account.
 *
 * "Your next box" is the screen this whole feature exists for: the thing no
 * WooCommerce subscription plugin gives a customer without sending them back
 * through checkout. It shows what is coming, when it stops being changeable,
 * and lets them change or skip it until then.
 *
 * @package SpringDevs\SubscriptionPro\Frontend
 */

namespace SpringDevs\SubscriptionPro\Frontend;

use SpringDevs\SubscriptionPro\Illuminate\Box\BoxPricing;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxProduct;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxQuote;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxSubscription;

defined( 'ABSPATH' ) || exit;

/**
 * Customer-facing box management.
 */
class BoxAccount {

	/**
	 * Register hooks.
	 */
	public function __construct() {
		add_filter( 'subscrpt_single_action_buttons', array( $this, 'action_buttons' ), 20, 4 );
		add_action( 'subscrpt_execute_actions', array( $this, 'execute_actions' ), 10, 2 );
		add_action( 'subscrpt_after_subscription_totals', array( $this, 'render_panel' ) );
		add_action( 'template_redirect', array( $this, 'maybe_save_contents' ) );
	}

	/**
	 * Add Skip next box to the subscription's actions.
	 *
	 * Editing is a panel on the page rather than a button, because it needs the
	 * product grid; the button here only jumps to it.
	 *
	 * @param array  $action_buttons Action buttons.
	 * @param int    $id             Subscription id.
	 * @param string $subscrpt_nonce Action nonce.
	 * @param string $status         Subscription status.
	 *
	 * @return array
	 */
	public function action_buttons( $action_buttons, $id, $subscrpt_nonce, $status ) {
		$id = (int) $id;

		if ( 'active' !== $status || ! BoxSubscription::is_box( $id ) ) {
			return $action_buttons;
		}

		if ( BoxSubscription::can_skip( $id ) ) {
			$action_buttons['box-skip'] = array(
				'url'   => subscrpt_get_action_url( 'box-skip', $subscrpt_nonce, $id ),
				'label' => __( 'Skip next box', 'subscription-pro' ),
			);
		}

		return $action_buttons;
	}

	/**
	 * Handle the skip action.
	 *
	 * Nonce and ownership were already checked by the free plugin's
	 * ActionController before this fires.
	 *
	 * @param int    $subscription_id Subscription id.
	 * @param string $action          Action name.
	 *
	 * @return void
	 */
	public function execute_actions( $subscription_id, $action ): void {
		if ( 'box-skip' !== $action ) {
			return;
		}

		$result = BoxSubscription::skip( (int) $subscription_id );

		if ( ! function_exists( 'wc_add_notice' ) ) {
			return;
		}

		if ( is_wp_error( $result ) ) {
			wc_add_notice( $result->get_error_message(), 'error' );

			return;
		}

		$next = (int) get_post_meta( $subscription_id, '_subscrpt_next_date', true );

		wc_add_notice(
			sprintf(
				/* translators: %s: the new renewal date. */
				__( 'Your next box is skipped. The one after it arrives around %s.', 'subscription-pro' ),
				date_i18n( get_option( 'date_format' ), $next )
			),
			'success'
		);
	}

	/**
	 * The rows a posted edit form asks for.
	 *
	 * `subscrpt_box_items` is product_id => quantity shipped every cycle, as it
	 * always was; `subscrpt_box_once` is product_id => quantity shipped in the
	 * next box only. A product asked for both ways is two rows.
	 *
	 * @param array $post The unslashed request.
	 *
	 * @return array[] Rows of product_id, qty and, for the next box only, once.
	 */
	public static function posted_items( array $post ): array {
		$items = array();

		foreach ( array(
			'subscrpt_box_items' => false,
			'subscrpt_box_once'  => true,
		) as $field => $once ) {
			if ( empty( $post[ $field ] ) || ! is_array( $post[ $field ] ) ) {
				continue;
			}

			foreach ( $post[ $field ] as $product_id => $qty ) {
				$row = array(
					'product_id' => absint( $product_id ),
					'qty'        => (int) ( is_scalar( $qty ) ? $qty : 0 ),
				);

				if ( $once ) {
					$row['once'] = true;
				}

				$items[] = $row;
			}
		}

		return $items;
	}

	/**
	 * Save contents posted from the edit panel.
	 *
	 * @return void
	 */
	public function maybe_save_contents(): void {
		if ( empty( $_POST['subscrpt_box_save'] ) ) {
			return;
		}

		$subscription_id = absint( $_POST['subscrpt_box_save'] );

		if ( ! $subscription_id ) {
			return;
		}

		if ( ! isset( $_POST['subscrpt_box_nonce'] )
			|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['subscrpt_box_nonce'] ) ), 'subscrpt_box_edit_' . $subscription_id ) ) {
			wc_add_notice( __( 'That form expired. Please try again.', 'subscription-pro' ), 'error' );

			return;
		}

		// The free plugin guards its own actions; this form is ours, so it does
		// its own ownership check rather than trusting the id in the request.
		if ( (int) get_post_field( 'post_author', $subscription_id ) !== get_current_user_id() ) {
			wc_add_notice( __( 'That subscription is not yours.', 'subscription-pro' ), 'error' );

			return;
		}

		$items = self::posted_items( wp_unslash( $_POST ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- posted_items() casts every key and quantity to an integer.

		$result = BoxSubscription::update_contents( $subscription_id, $items );

		if ( is_wp_error( $result ) ) {
			wc_add_notice( $result->get_error_message(), 'error' );

			return;
		}

		wc_add_notice( __( 'Your next box has been updated.', 'subscription-pro' ), 'success' );

		wp_safe_redirect( remove_query_arg( 'subscrpt_box' ) );
		exit;
	}

	/**
	 * Render "Your next box" under the subscription totals.
	 *
	 * @param int $subscription_id Subscription id.
	 *
	 * @return void
	 */
	public function render_panel( $subscription_id ): void {
		$subscription_id = (int) $subscription_id;

		if ( ! BoxSubscription::is_box( $subscription_id ) ) {
			return;
		}

		wp_enqueue_style( 'subscrpt_box_css' );
		BoxBuilder::enqueue_script();

		$contents  = BoxSubscription::contents( $subscription_id );
		$rules     = BoxSubscription::rules( $subscription_id );
		$lock      = BoxSubscription::lock_timestamp( $subscription_id );
		$is_locked = BoxSubscription::is_locked( $subscription_id );
		$editing   = ! empty( $_GET['subscrpt_box'] ) && 'edit' === sanitize_text_field( wp_unslash( $_GET['subscrpt_box'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		// While the gateway holds the billing schedule nothing here can change the box.
		$gateway_note = '';
		$can_edit     = BoxSubscription::can_edit( $subscription_id );

		if ( $can_edit && BoxSubscription::is_gateway_scheduled( $subscription_id ) ) {
			$can_edit     = false;
			$editing      = false;
			$gateway_note = (string) BoxSubscription::customer_refusal( $subscription_id )->get_error_message();
		}

		$is_sum = BoxPricing::STRATEGY_SUM === BoxSubscription::pricing( $subscription_id )['strategy'];

		// A fixed price is agreed for the units it was sold with: nothing can be added to it.
		$fixed_note = $can_edit && ! $is_sum
			? __( 'Your box renews at the price you agreed, whatever it holds, so it cannot take more items. Swap an item instead.', 'subscription-pro' )
			: '';

		$choices = array();

		if ( $can_edit ) {
			foreach ( BoxSubscription::allowed_products( $subscription_id ) as $product_id ) {
				$product = wc_get_product( $product_id );

				if ( $product instanceof \WC_Product && $product->is_in_stock() ) {
					$choices[] = $product;
				}
			}
		}

		$chosen      = array();
		$chosen_once = array();

		foreach ( BoxProduct::normalise_items( $contents ) as $item ) {
			if ( $item['once'] ) {
				$chosen_once[ $item['product_id'] ] = ( $chosen_once[ $item['product_id'] ] ?? 0 ) + (int) $item['qty'];
			} else {
				$chosen[ $item['product_id'] ] = ( $chosen[ $item['product_id'] ] ?? 0 ) + (int) $item['qty'];
			}
		}

		// What the next renewal charges, from the same pricing the renewal uses.
		$next = $is_sum ? BoxQuote::respond_for_subscription( $subscription_id, $chosen, $chosen_once ) : array();

		$edit_url       = add_query_arg( 'subscrpt_box', 'edit' );
		$every_label    = BoxNextAdd::every_label( $subscription_id );
		$quote_url      = class_exists( 'WC_AJAX' ) ? \WC_AJAX::get_endpoint( BoxQuote::SUBSCRIPTION_ACTION ) : add_query_arg( 'wc-ajax', BoxQuote::SUBSCRIPTION_ACTION, home_url( '/' ) );
		$quote_nonce    = wp_create_nonce( BoxQuote::EDIT_NONCE_PREFIX . $subscription_id );
		$next_add_nonce = wp_create_nonce( BoxNextAdd::NONCE_ACTION );
		$can_add        = $can_edit && $is_sum && $choices && ! $is_locked;

		if ( $can_edit && $is_sum ) {
			wp_enqueue_script( 'subscrpt_box_account_add_js' );
		}

		if ( $can_add ) {
			wp_enqueue_script( BoxNextAdd::SCRIPT_HANDLE );
		}

		include SUBSCRIPT_PRO_PATH . '/templates/myaccount/box-panel.php';
	}
}
