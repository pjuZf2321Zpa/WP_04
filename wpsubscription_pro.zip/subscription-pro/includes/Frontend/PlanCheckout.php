<?php
/**
 * Plan checkout bridge — cart → order item → subscription snapshot.
 *
 * This is the plan-gated billing path. Every hook here acts ONLY when a plan
 * was chosen (`subscrpt_plan_id` present on the cart item / order item), so the
 * legacy per-product path is byte-for-byte unchanged for non-plan items (§6).
 *
 * Covers all three plan types — Recurring, Subscribe & Save, and Installments,
 * on simple and variable products. Installments map to the split-payment engine
 * (per-installment price + down payment as signup fee + capped payment count).
 *
 * @package SpringDevs\SubscriptionPro\Frontend
 */

namespace SpringDevs\SubscriptionPro\Frontend;

use SpringDevs\Subscription\Illuminate\Plans\PlanRepository;
use SpringDevs\Subscription\Illuminate\Helper as FreeHelper;
use SpringDevs\SubscriptionPro\Illuminate\Helper;

/**
 * Class PlanCheckout
 */
class PlanCheckout {

	/**
	 * Initialize the class.
	 */
	public function __construct() {
		add_filter( 'woocommerce_add_cart_item_data', array( $this, 'add_plan_to_cart' ), 20, 3 );
		add_filter( 'woocommerce_get_cart_item_from_session', array( $this, 'restore_plan_split_total' ), 20, 2 );
		add_action( 'woocommerce_before_calculate_totals', array( $this, 'set_cart_item_price' ), 20 );
		add_action( 'woocommerce_after_calculate_totals', array( $this, 'restore_trial_price' ), 20 );
		add_action( 'woocommerce_checkout_create_order_line_item', array( $this, 'save_plan_order_item' ), 20, 3 );

		// R1: create the subscription from plan terms instead of product price.
		add_action( 'subscrpt_product_checkout', array( $this, 'create_plan_subscription' ), 9, 3 );

		// R3: force snapshot pricing for plan subs even under the global "updated" mode.
		add_filter( 'subscrpt_renewal_product_args', array( $this, 'force_snapshot_product_args' ), 20, 3 );
		add_filter( 'subscrpt_renewal_item_meta', array( $this, 'force_snapshot_item_meta' ), 20, 3 );
	}

	/**
	 * Resolve the plan term a shopper chose for a product.
	 *
	 * @param int $product_id   Product (parent) id.
	 * @param int $variation_id Variation id, or 0.
	 * @param int $plan_id      Chosen plan-term id.
	 *
	 * @return array|null Resolved plan row, or null if not valid for the product.
	 */
	private function resolve_chosen( $product_id, $variation_id, $plan_id ) {
		$plan_id = absint( $plan_id );

		if ( ! $plan_id ) {
			return null;
		}

		foreach ( PlanRepository::resolve_for_product( $product_id, $variation_id ) as $row ) {
			if ( (int) $row['plan_id'] === $plan_id ) {
				return $row;
			}
		}

		return null;
	}

	/**
	 * Resolve a fallback plan for a bare add-to-cart — a direct link with no plan
	 * chosen (`?add-to-cart=ID`). One-time purchase wins when enabled: the item
	 * stays a plain one-time line at the native price (returns 0). Otherwise the
	 * product's first plan is selected, matching the on-page selector's default.
	 *
	 * @param int $product_id   Product (parent) id.
	 * @param int $variation_id Variation id, or 0.
	 *
	 * @return int Plan-term id, or 0 to leave the item untouched.
	 */
	private function fallback_plan_id( $product_id, $variation_id ) {
		if ( ! function_exists( 'subscrpt_product_has_plan' ) || ! subscrpt_product_has_plan( $product_id, $variation_id ) ) {
			return 0;
		}

		// One-time enabled (per-variation for variable, on the product for simple)
		// → keep it a one-time line at the native price.
		$entity_id = $variation_id ? $variation_id : $product_id;
		if ( 'yes' === get_post_meta( $entity_id, '_subscrpt_one_time_enabled', true ) ) {
			return 0;
		}

		// Default to the product's first plan (same order the selector defaults to).
		foreach ( PlanRepository::resolve_for_product( $product_id, $variation_id ) as $row ) {
			return (int) $row['plan_id'];
		}

		return 0;
	}

	/**
	 * Resolve the billing terms a chosen plan row maps to.
	 *
	 * For Recurring / Subscribe & Save the line price is the offer price and the
	 * cadence is the plan's frequency × interval. For Installments the line price
	 * is the per-installment amount, the down payment rides the signup-fee key
	 * (an extra upfront charge), and `max_no_payment` caps the number of charges.
	 *
	 * @param array $row Resolved plan row.
	 *
	 * @return array{price:float,time:int,option:string,trial:?string,signup_fee:?float,type_key:string,payment_type:string,max_no_payment:int}
	 */
	private function term_terms( $row ) {
		$type_key = PlanRepository::type_to_string( (int) $row['group_type'] );
		$data     = $row['relation_data'];

		$signup_fee     = null;
		$payment_type   = 'recurring';
		$max_no_payment = 0;
		$time           = max( 1, (int) $row['billing_frequency'] );
		$regular_num    = null;
		$split_total    = null;

		if ( 'installments' === $type_key ) {
			$regular = isset( $data['regular_price'] ) ? (string) $data['regular_price'] : '';
			$selling = isset( $data['sale_price'] ) ? (string) $data['sale_price'] : '';
			$dtype   = $data['discount_type'] ?? 'percentage';
			$dvalue  = isset( $data['discount_value'] ) ? (string) $data['discount_value'] : '0';

			// The entered price is the TOTAL; each installment charges total ÷ count.
			// Cadence (time × interval) is the plan's "every N" — set above — so the
			// subscription charges the per-installment amount every cycle, `count`
			// times. billing_frequency is the cadence, NOT the payment count.
			$count          = $this->installment_count( $row );
			$total          = $this->offer_price( $regular, $selling, $dtype, $dvalue );
			$amounts        = subscrpt_split_amounts( $total, $count );
			$price          = $amounts['per_installment'];
			$regular_num    = '' !== $regular ? subscrpt_split_amounts( $regular, $count )['per_installment'] : null;
			$payment_type   = 'split_payment';
			$max_no_payment = $count;
			$split_total    = $amounts['total'];

			// A signup fee on a split plan is an extra upfront charge (as recurring).
			if ( ! empty( $row['signup_fee'] ) && is_array( $row['signup_fee'] ) && ! empty( $row['signup_fee']['amount'] ) ) {
				$signup_fee = (float) $row['signup_fee']['amount'];
			}
		} else {
			$regular = isset( $data['regular_price'] ) ? (string) $data['regular_price'] : '';
			$selling = isset( $data['sale_price'] ) ? (string) $data['sale_price'] : '';
			$dtype   = $data['discount_type'] ?? 'percentage';
			$dvalue  = isset( $data['discount_value'] ) ? (string) $data['discount_value'] : '0';

			$price       = $this->offer_price( $regular, $selling, $dtype, $dvalue );
			$regular_num = '' !== $regular ? (float) $regular : null;

			if ( ! empty( $row['signup_fee'] ) && is_array( $row['signup_fee'] ) && ! empty( $row['signup_fee']['amount'] ) ) {
				$signup_fee = (float) $row['signup_fee']['amount'];
			}
		}

		$trial = null;
		if ( Helper::plan_trial_applies( $row, $type_key ) ) {
			$trial_interval = $row['plan_data']['free_trial_interval'] ?? 'days';
			$trial          = (int) $row['free_trial'] . ' ' . $trial_interval;
		}

		// Access-ends timing lives in the plan blob. Normalize the plan vocabulary
		// (lifetime|full_duration|custom) to the subscription/template vocabulary
		// (lifetime|after_full_duration|custom_duration).
		$plan_data  = is_array( $row['plan_data'] ?? null ) ? $row['plan_data'] : array();
		$access_map = array(
			'lifetime'      => 'lifetime',
			'full_duration' => 'after_full_duration',
			'custom'        => 'custom_duration',
		);
		$access_raw = (string) ( $plan_data['access_ends'] ?? 'lifetime' );

		return array(
			'price'                  => (float) $price,
			'regular'                => null !== $regular_num ? (float) $regular_num : null,
			'time'                   => $time,
			'option'                 => PlanRepository::interval_to_option( (int) $row['billing_interval'] ),
			'trial'                  => $trial,
			'signup_fee'             => $signup_fee,
			'type_key'               => $type_key,
			'payment_type'           => $payment_type,
			'max_no_payment'         => $max_no_payment,
			'split_total'            => $split_total,
			'access_ends'            => $access_map[ $access_raw ] ?? 'lifetime',
			'access_custom_value'    => (int) ( $plan_data['access_custom_value'] ?? 1 ),
			'access_custom_interval' => (string) ( $plan_data['access_custom_interval'] ?? 'month' ),
		);
	}

	/**
	 * Number of installments for a split-payment plan (from the plan data blob;
	 * `billing_frequency` is the "every N" cadence, not the payment count).
	 *
	 * @param array $row Resolved plan row.
	 *
	 * @return int At least 1.
	 */
	private function installment_count( $row ) {
		$plan_data = is_array( $row['plan_data'] ?? null ) ? $row['plan_data'] : array();

		return max( 1, (int) ( $plan_data['installment_count'] ?? 0 ) );
	}

	/**
	 * Offer price: (sale ?? regular) minus discount. Mirrors PlanPresenter.
	 *
	 * @param string $regular        Regular price.
	 * @param string $selling        Sale price (may be empty).
	 * @param string $discount_type  percentage|fixed.
	 * @param string $discount_value Discount amount.
	 *
	 * @return float
	 */
	private function offer_price( $regular, $selling, $discount_type, $discount_value ) {
		$base     = '' !== $selling ? (float) $selling : (float) $regular;
		$discount = (float) $discount_value;

		$base = 'percentage' === $discount_type ? $base - ( $base * ( $discount / 100 ) ) : $base - $discount;

		return max( 0, $base );
	}

	/**
	 * G2: stamp the chosen plan onto the cart item.
	 *
	 * Reads `subscrpt_plan_id` from the add-to-cart request, resolves the term,
	 * and writes `subscrpt_plan_id` + a `subscription` array (reusing the
	 * `signup_fee` key — M2) so the existing engine's cart fee + display work.
	 *
	 * @param array $cart_item_data Cart item data.
	 * @param int   $product_id     Product id.
	 * @param int   $variation_id   Variation id.
	 *
	 * @return array
	 */
	public function add_plan_to_cart( $cart_item_data, $product_id, $variation_id ) {
		// Read from the request so both the product-page form (POST) and direct
		// checkout links (`?add-to-cart=ID&subscrpt_plan_id=TERM`, GET) select a plan.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- WooCommerce verifies the add-to-cart request; we only read a plan id.
		$plan_id = isset( $_REQUEST['subscrpt_plan_id'] ) ? absint( wp_unslash( $_REQUEST['subscrpt_plan_id'] ) ) : 0;

		if ( ! $plan_id ) {
			// Bare add-to-cart (direct link, no plan chosen): fall back to one-time
			// when enabled, otherwise the product's first plan.
			$plan_id = $this->fallback_plan_id( $product_id, $variation_id );
			if ( ! $plan_id ) {
				return $cart_item_data;
			}
		}

		$row = $this->resolve_chosen( $product_id, $variation_id, $plan_id );

		if ( ! $row ) {
			return $cart_item_data;
		}

		$terms = $this->term_terms( $row );

		$cart_item_data['subscrpt_plan_id']                = $plan_id;
		$cart_item_data['subscrpt_plan_group_id']          = (int) $row['plan_group_id'];
		$cart_item_data['subscrpt_plan_price']             = $terms['price'];
		$cart_item_data['subscrpt_plan_regular']           = $terms['regular'];
		$cart_item_data['subscrpt_payment_type']           = $terms['payment_type'];
		$cart_item_data['subscrpt_max_no_payment']         = $terms['max_no_payment'];
		$cart_item_data['subscrpt_split_total']            = $terms['split_total'];
		$cart_item_data['subscrpt_access_ends']            = $terms['access_ends'];
		$cart_item_data['subscrpt_access_custom_value']    = $terms['access_custom_value'];
		$cart_item_data['subscrpt_access_custom_interval'] = $terms['access_custom_interval'];
		$cart_item_data['subscription']                    = array(
			'time'       => $terms['time'],
			'type'       => $terms['option'],
			'trial'      => $terms['trial'],
			'signup_fee' => $terms['signup_fee'],
			'per_cost'   => $terms['price'],
		);

		return $cart_item_data;
	}

	/**
	 * G2: override the cart line price with the resolved plan price.
	 *
	 * @param \WC_Cart $cart Cart object.
	 *
	 * @return void
	 */
	public function set_cart_item_price( $cart ) {
		if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
			return;
		}

		foreach ( $cart->get_cart() as $cart_item ) {
			if ( ! isset( $cart_item['subscrpt_plan_price'], $cart_item['data'] ) ) {
				continue;
			}

			$plan_price   = (float) $cart_item['subscrpt_plan_price'];
			$plan_regular = isset( $cart_item['subscrpt_plan_regular'] ) ? $cart_item['subscrpt_plan_regular'] : null;

			if ( null !== $plan_regular && $plan_price < (float) $plan_regular ) {
				// Genuine plan discount → mark it as a real sale so WooCommerce (incl.
				// the blocks / Store API cart, which ignores the price-html filter)
				// renders the regular price struck-through beside the offer.
				$cart_item['data']->set_regular_price( (float) $plan_regular );
				$cart_item['data']->set_sale_price( $plan_price );
			} else {
				// No plan discount → align regular with the price so no bogus "sale"
				// shows against the native (One-Time) price.
				$cart_item['data']->set_regular_price( $plan_price );
				$cart_item['data']->set_sale_price( '' );
			}

			// Free trial: calculate at 0 now (restore_trial_price restores the display
			// price after totals); renewals charge the plan price stored on the sub.
			$cart_item['data']->set_price( empty( $cart_item['subscription']['trial'] ) ? $plan_price : 0 );
		}
	}

	/**
	 * Restore a trial plan line's display price after totals are calculated at 0,
	 * so the cart line and Recurring totals show the plan price.
	 *
	 * @param \WC_Cart $cart Cart object.
	 *
	 * @return void
	 */
	public function restore_trial_price( $cart ) {
		if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
			return;
		}

		foreach ( $cart->get_cart() as $cart_item ) {
			if (
				isset( $cart_item['subscrpt_plan_price'], $cart_item['data'] )
				&& ! empty( $cart_item['subscription']['trial'] )
			) {
				$cart_item['data']->set_price( (float) $cart_item['subscrpt_plan_price'] );
			}
		}
	}

	/**
	 * Back-fill `subscrpt_split_total` on session restore for plan items stored
	 * before it was tracked, so the cart total shows the entered plan price rather
	 * than the per-installment × count sum. Fresh items already carry it and skip.
	 *
	 * @param array $cart_item Cart item reconstructed from the session.
	 * @param array $values    Raw stored session values.
	 *
	 * @return array
	 */
	public function restore_plan_split_total( $cart_item, $values ) {
		if ( empty( $cart_item['subscrpt_plan_id'] ) || isset( $cart_item['subscrpt_split_total'] ) ) {
			return $cart_item;
		}

		$product = $cart_item['data'] ?? null;
		if ( ! $product instanceof \WC_Product ) {
			return $cart_item;
		}

		$variation_id = $product->is_type( 'variation' ) ? $product->get_id() : 0;
		$product_id   = $variation_id ? $product->get_parent_id() : $product->get_id();

		$row = $this->resolve_chosen( $product_id, $variation_id, (int) $cart_item['subscrpt_plan_id'] );
		if ( $row ) {
			$cart_item['subscrpt_split_total'] = $this->term_terms( $row )['split_total'];
		}

		return $cart_item;
	}

	/**
	 * R1: persist the chosen plan + terms onto the order line item.
	 *
	 * @param \WC_Order_Item_Product $item          Order item.
	 * @param string                 $cart_item_key Cart item key.
	 * @param array                  $cart_item     Cart item data.
	 *
	 * @return void
	 */
	public function save_plan_order_item( $item, $cart_item_key, $cart_item ) {
		if ( empty( $cart_item['subscrpt_plan_id'] ) ) {
			return;
		}

		$item->update_meta_data( '_subscrpt_plan_id', (int) $cart_item['subscrpt_plan_id'] );
		$item->update_meta_data( '_subscrpt_plan_group_id', (int) ( $cart_item['subscrpt_plan_group_id'] ?? 0 ) );
		$item->update_meta_data( '_subscrpt_plan_price', (float) ( $cart_item['subscrpt_plan_price'] ?? 0 ) );
		$item->update_meta_data( '_subscrpt_plan_payment_type', (string) ( $cart_item['subscrpt_payment_type'] ?? 'recurring' ) );
		$item->update_meta_data( '_subscrpt_plan_max_no_payment', (int) ( $cart_item['subscrpt_max_no_payment'] ?? 0 ) );
		$item->update_meta_data( '_subscrpt_plan_access_ends', (string) ( $cart_item['subscrpt_access_ends'] ?? 'lifetime' ) );
		$item->update_meta_data( '_subscrpt_plan_access_custom_value', (int) ( $cart_item['subscrpt_access_custom_value'] ?? 1 ) );
		$item->update_meta_data( '_subscrpt_plan_access_custom_interval', (string) ( $cart_item['subscrpt_access_custom_interval'] ?? 'month' ) );
		$item->update_meta_data( '_subscrpt_plan_terms', $cart_item['subscription'] ?? array() );
	}

	/**
	 * Resolve the concrete purchased product (variation for variable items).
	 *
	 * @param \WC_Order_Item $order_item Order item.
	 * @param \WC_Product    $product    Parent / simple product.
	 *
	 * @return \WC_Product|null
	 */
	private function purchased_product( $order_item, $product ) {
		$variation_id = method_exists( $order_item, 'get_variation_id' ) ? (int) $order_item->get_variation_id() : 0;

		if ( $variation_id ) {
			$variation = wc_get_product( $variation_id );
			if ( $variation ) {
				return $variation;
			}
		}

		return $product;
	}

	/**
	 * R1: create the subscription record from the order item's plan terms.
	 *
	 * Fires on `subscrpt_product_checkout` for every order item; acts only when
	 * the item carries `_subscrpt_plan_id`. Mirrors the legacy simple snapshot
	 * but sources price + cadence from the plan, not the product.
	 *
	 * @param \WC_Order_Item $order_item  Order item.
	 * @param \WC_Product    $product     Product object.
	 * @param string         $post_status Subscription status.
	 *
	 * @return void
	 */
	public function create_plan_subscription( $order_item, $product, $post_status ) {
		$plan_id = (int) $order_item->get_meta( '_subscrpt_plan_id' );

		if ( ! $plan_id ) {
			return;
		}

		$terms = $order_item->get_meta( '_subscrpt_plan_terms' );
		$terms = is_array( $terms ) ? $terms : array();

		$timing_per    = (int) ( $terms['time'] ?? 1 );
		$timing_option = (string) ( $terms['type'] ?? 'months' );
		$trial         = $terms['trial'] ?? null;
		$type          = FreeHelper::get_typos( $timing_per, $timing_option );

		wc_update_order_item_meta(
			$order_item->get_id(),
			'_subscrpt_meta',
			array(
				'time'  => $timing_per,
				'type'  => $timing_option,
				'trial' => $trial,
			)
		);

		$variation_id = method_exists( $order_item, 'get_variation_id' ) ? (int) $order_item->get_variation_id() : 0;

		// Subscribe & Save / physical plans: deliver on the billing cadence so the
		// delivery scheduler picks it up (mirrors the legacy `_subscrpt_delivery`).
		$purchased = $this->purchased_product( $order_item, $product );

		if ( $purchased && ! $purchased->is_virtual() ) {
			wc_update_order_item_meta(
				$order_item->get_id(),
				'_subscrpt_delivery',
				array(
					'delivery_time'     => $timing_per,
					'delivery_option'   => $type,
					'delivery_day_sync' => false,
					'delivery_day'      => null,
				)
			);
		}

		$subscription_id = FreeHelper::process_new_subscription_order( $order_item, $post_status, $product );

		if ( ! $subscription_id ) {
			return;
		}

		update_post_meta( $subscription_id, '_subscrpt_timing_per', $timing_per );
		update_post_meta( $subscription_id, '_subscrpt_timing_option', $timing_option );
		update_post_meta( $subscription_id, '_subscrpt_price', (float) $order_item->get_meta( '_subscrpt_plan_price' ) );
		update_post_meta( $subscription_id, '_subscrpt_plan_id', $plan_id );
		update_post_meta( $subscription_id, '_subscrpt_plan_group_id', (int) $order_item->get_meta( '_subscrpt_plan_group_id' ) );

		// Installment plans: mark as split payment so renewals are capped at the
		// installment count. The engine reads these straight off the sub post.
		$payment_type = (string) $order_item->get_meta( '_subscrpt_plan_payment_type' );
		if ( 'split_payment' === $payment_type ) {
			update_post_meta( $subscription_id, '_subscrpt_payment_type', 'split_payment' );
			update_post_meta( $subscription_id, '_subscrpt_max_no_payment', (int) $order_item->get_meta( '_subscrpt_plan_max_no_payment' ) );
			update_post_meta( $subscription_id, '_subscrpt_access_ends_timing', (string) $order_item->get_meta( '_subscrpt_plan_access_ends' ) );
			update_post_meta( $subscription_id, '_subscrpt_custom_access_duration_time', (int) $order_item->get_meta( '_subscrpt_plan_access_custom_value' ) );
			update_post_meta( $subscription_id, '_subscrpt_custom_access_duration_type', (string) $order_item->get_meta( '_subscrpt_plan_access_custom_interval' ) );
		}
		// Plans carry no cancellation setting, so fall back to the product default of allowing it.
		$user_cancel = $product->get_meta( '_subscrpt_user_cancel' );
		update_post_meta( $subscription_id, '_subscrpt_user_cancel', '' !== $user_cancel ? $user_cancel : 'yes' );

		update_post_meta( $subscription_id, '_subscrpt_order_id', $order_item->get_order_id() );
		update_post_meta( $subscription_id, '_subscrpt_order_item_id', $order_item->get_id() );

		// Variable products: record the purchased variation for display + admin.
		if ( $variation_id ) {
			update_post_meta( $subscription_id, '_subscrpt_variation_id', $variation_id );
		}

		update_post_meta( $subscription_id, '_subscrpt_trial', $trial );
		if ( $trial ) {
			update_post_meta( $subscription_id, '_subscrpt_trial_mode', 'active' === $post_status ? 'on' : 'off' );
		}

		if ( 'active' === $post_status ) {
			$start_date = time();
			$next_date  = sdevs_wp_strtotime( $timing_per . ' ' . $type, $start_date );
			if ( $trial ) {
				$start_date = sdevs_wp_strtotime( $trial );
				$next_date  = $start_date;
			}
			update_post_meta( $subscription_id, '_subscrpt_start_date', $start_date );
			update_post_meta( $subscription_id, '_subscrpt_next_date', $next_date );
		}

		// M2: signup fee already flows through the named "Signup Fee" cart fee.
		$fees = $order_item->get_order()->get_fees();
		foreach ( $fees as $fee ) {
			if ( 'Signup Fee' === $fee->get_name() ) {
				update_post_meta( $subscription_id, '_subscrpt_signup_fee', $fee->get_amount() );
			}
		}

		do_action( 'subscrpt_order_checkout', $subscription_id, $order_item );
	}

	/**
	 * Resolve the plan subscription id behind a renewal's source order item.
	 *
	 * Detection is via the subscription record (not the order item) so it holds
	 * across renewal generations — a renewal order item does not carry the plan
	 * id, but the subscription post always does.
	 *
	 * @param \WC_Order_Item|null $order_item Old order item.
	 *
	 * @return int Subscription id if it is a plan sub, else 0.
	 */
	private function plan_subscription_id( $order_item ) {
		if ( ! $order_item ) {
			return 0;
		}

		$subscription = FreeHelper::get_subscription_from_order_item_id( $order_item->get_id() );

		if ( ! $subscription || empty( $subscription->subscription_id ) ) {
			return 0;
		}

		$sub_id = (int) $subscription->subscription_id;

		return get_post_meta( $sub_id, '_subscrpt_plan_id', true ) ? $sub_id : 0;
	}

	/**
	 * R3: restore the snapshot price for a plan sub even under "updated" mode.
	 *
	 * @param array          $product_args Renewal product args (possibly overwritten by free).
	 * @param \WC_Product    $product      Product object.
	 * @param \WC_Order_Item $order_item   Old order item.
	 *
	 * @return array
	 */
	public function force_snapshot_product_args( $product_args, $product, $order_item ) {
		$sub_id = $this->plan_subscription_id( $order_item );

		if ( ! $sub_id ) {
			return $product_args;
		}

		$price = (float) get_post_meta( $sub_id, '_subscrpt_price', true );
		$qty   = method_exists( $order_item, 'get_quantity' ) ? $order_item->get_quantity() : 1;

		// Remove included tax, as the renewal callers do; WC_Order adds it back on the line total.
		if ( wc_prices_include_tax() ) {
			$tax_rates = \WC_Tax::get_rates( $product ? $product->get_tax_class() : '' );
			$price    -= array_sum( \WC_Tax::calc_inclusive_tax( $price, $tax_rates ) );
		}

		return array(
			'name'     => $product ? $product->get_name() : ( $product_args['name'] ?? '' ),
			'subtotal' => $price * $qty,
			'total'    => $price * $qty,
		);
	}

	/**
	 * R3: keep the snapshot cadence for a plan sub even under "updated" mode.
	 *
	 * @param array          $item_meta  Renewal item meta (possibly overwritten by free).
	 * @param \WC_Product    $product    Product object.
	 * @param \WC_Order_Item $order_item Old order item.
	 *
	 * @return array
	 */
	public function force_snapshot_item_meta( $item_meta, $product, $order_item = null ) {
		if ( ! $this->plan_subscription_id( $order_item ) ) {
			return $item_meta;
		}

		$snapshot = wc_get_order_item_meta( $order_item->get_id(), '_subscrpt_meta', true );

		return is_array( $snapshot ) ? $snapshot : $item_meta;
	}
}
