<?php
/**
 * Cart handling for subscription + plan products (Pro).
 *
 * @package SpringDevs\SubscriptionPro\Frontend
 */

namespace SpringDevs\SubscriptionPro\Frontend;

use SpringDevs\Subscription\Illuminate\Helper as FreeHelper;
use SpringDevs\Subscription\Illuminate\Subscription\Subscription;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxCart;

/**
 * Class Cart
 *
 * @package SpringDevs\SubscriptionPro\Frontend
 */
class Cart {

	/**
	 * Initialize the class
	 */
	public function __construct() {
		add_filter( 'woocommerce_add_cart_item_data', array( $this, 'add_to_cart_item_data' ), 10, 3 );
		add_filter( 'woocommerce_get_item_data', array( $this, 'set_line_item_meta' ), 10, 2 );
		add_action( 'woocommerce_check_cart_items', array( $this, 'check_cart_items' ) );
		add_filter( 'subscrpt_block_simple_cart_item_data', array( $this, 'add_pro_fields_data' ), 10, 2 );
		add_action( 'woocommerce_cart_calculate_fees', array( $this, 'add_cart_fee' ) );
		add_action( 'woocommerce_before_calculate_totals', array( $this, 'add_calculation_price_filter' ) );
		add_action( 'woocommerce_calculate_totals', array( $this, 'remove_calculation_price_filter' ) );
		add_action( 'woocommerce_after_calculate_totals', array( $this, 'remove_calculation_price_filter' ) );
	}

	/**
	 * Add product meta on cart item -- variable product.
	 *
	 * @param array $cart_item_data cart_item_data.
	 * @param int   $product_id Product ID.
	 * @param int   $variation_id Variation ID.
	 *
	 * @return array
	 */
	public function add_to_cart_item_data( $cart_item_data, $product_id, $variation_id ) {
		$product = wc_get_product( $product_id );
		if ( ! $product->is_type( 'variable' ) ) {
			return $cart_item_data;
		}
		$variation = Subscription::get_subs_product( $variation_id );
		if ( $variation->is_enabled() ) :
			$timing_per                 = $variation->get_timing_per();
			$timing_option              = $variation->get_timing_option();
			$type                       = FreeHelper::get_typos( $timing_per, $timing_option );
			$subscription_data          = array();
			$subscription_data['time']  = $timing_per;
			$subscription_data['type']  = $type;
			$trial_timing_per           = $variation->get_trial_timing_per();
			$subscription_data['trial'] = $variation->has_trial() ? $trial_timing_per . ' ' . FreeHelper::get_typos( $trial_timing_per, $variation->get_trial_timing_option() ) : null;

			$subscription_data['signup_fee'] = ( 0 === $variation->get_signup_fee() ) ? null : $variation->get_signup_fee();
			$subscription_data['per_cost']   = $variation->get_price();
			$cart_item_data['subscription']  = $subscription_data;
		endif;

		return $cart_item_data;
	}

	/**
	 * Remove filter after calculate calculation.
	 *
	 * @return void
	 */
	public function remove_calculation_price_filter() {
		remove_filter( 'woocommerce_product_variation_get_price', array( $this, 'set_prices_for_calculation' ), 100 );
	}

	/**
	 * Add filter before cart calculation.
	 *
	 * @return void
	 */
	public function add_calculation_price_filter() {
		add_filter( 'woocommerce_product_variation_get_price', array( $this, 'set_prices_for_calculation' ), 100, 2 );
	}

	/**
	 * Return 0 if product has trial.
	 *
	 * @param float       $price Price.
	 * @param \WC_Product $product Product object.
	 *
	 * @return float
	 */
	public function set_prices_for_calculation( $price, $product ) {
		$product = Subscription::get_subs_product( $product );
		if ( $product->is_enabled() && $product->is_type( 'variation' ) ) {
			if ( $product->has_trial() ) {
				return 0;
			}
		}

		return $price;
	}

	/**
	 * Add signup fee if available
	 *
	 * @param mixed $cart Cart.
	 *
	 * @return void
	 */
	public function add_cart_fee( $cart ) {
		$cart_items = WC()->cart->cart_contents;
		$signup_fee = 0;
		foreach ( $cart_items as $cart_item ) {
			if ( isset( $cart_item['subscription'] ) && $cart_item['subscription']['signup_fee'] ) {
				$signup_fee += (float) $cart_item['subscription']['signup_fee'];
			}
		}
		if ( $signup_fee > 0 ) {
			$cart->add_fee( 'Signup Fee', $signup_fee );
		}
	}

	/**
	 * Insert pro fields data on cart item data.
	 *
	 * @param array       $subscription_data Subscription array on cart item data.
	 * @param \WC_Product $product Product Object.
	 *
	 * @return array
	 */
	public function add_pro_fields_data( $subscription_data, $product ) {
		$subscription_data['time'] = $product->get_timing_per();
		$subscription_data['type'] = FreeHelper::get_typos( $subscription_data['time'], $product->get_timing_option() );

		$signup_fee = $product->get_signup_fee();
		if ( $signup_fee > 0 ) {
			$subscription_data['signup_fee'] = $signup_fee;
		}

		return $subscription_data;
	}

	/**
	 * Check cart items if it's valid or not?
	 *
	 * @return void
	 */
	public function check_cart_items() {
		$cart_items = WC()->cart->cart_contents;
		if ( is_array( $cart_items ) ) {
			foreach ( $cart_items as $key => $value ) {
				$product = Subscription::get_subs_product( $value['data'] );

				// Plan products are governed by the plan flow, not the legacy check:
				// a plan subscription item carries `subscrpt_plan_id`, and a One-Time
				// purchase of a plan product carries neither a plan id nor a
				// subscription snapshot — the legacy `_subscrpt_enabled` branch below
				// would otherwise wrongly drop that One-Time item from the cart.
				$subscrpt_pid = isset( $value['product_id'] ) ? (int) $value['product_id'] : 0;
				if ( isset( $value['subscrpt_plan_id'] ) || ( $subscrpt_pid && subscrpt_product_has_plan( $subscrpt_pid ) ) ) {
					continue;
				}

				if ( isset( $value['subscription'] ) ) {
					$time_chk       = ( $value['subscription']['time'] !== $product->get_timing_per() );
					$type_chk       = ( FreeHelper::get_typos( $product->get_timing_per(), $product->get_timing_option() ) !== $value['subscription']['type'] );
					$trial_chk      = ( $product->get_trial() !== $value['subscription']['trial'] );
					$signup_fee_chk = ( (float) $product->get_signup_fee() !== (float) self::product_signup_fee( $value ) );

					if ( $time_chk || $type_chk || $trial_chk || $signup_fee_chk ) {
						// remove the item.
						wc_add_notice( __( 'An item which is no longer available was removed from your cart.', 'subscription-pro' ), 'error' );
						WC()->cart->remove_cart_item( $key );
					}
				} elseif ( $product->is_enabled() ) {
					// remove the item.
					wc_add_notice( __( 'An item which is no longer available was removed from your cart.', 'subscription-pro' ), 'error' );
					WC()->cart->remove_cart_item( $key );
				}
			}
		}
	}

	/**
	 * The signup fee a line carries for its product.
	 *
	 * A box priced before its once items became a fee of their own added them
	 * to the line's fee and kept the product's own in `base_signup_fee`; that
	 * is the one to compare with the product, until pricing puts it back.
	 *
	 * @param array $cart_item Cart line.
	 *
	 * @return mixed
	 */
	private static function product_signup_fee( array $cart_item ) {
		$box = $cart_item[ BoxCart::CART_KEY ] ?? null;

		if ( is_array( $box ) && array_key_exists( 'base_signup_fee', $box ) ) {
			return $box['base_signup_fee'];
		}

		return $cart_item['subscription']['signup_fee'];
	}

	/**
	 * Set line item for display meta details.
	 *
	 * @param array $cart_item_data Cart Item Data.
	 * @param array $cart_item Cart Item.
	 *
	 * @return array
	 */
	public function set_line_item_meta( $cart_item_data, $cart_item ) {
		if ( isset( $cart_item['subscription'] ) ) {
			if ( $cart_item['subscription']['signup_fee'] ) {
				$cart_item_data[] = array(
					'key'    => __( 'Signup Fee', 'subscription-pro' ),
					'value'  => wc_price( $cart_item['subscription']['signup_fee'] ),
					'hidden' => true,
					'__experimental_woocommerce_blocks_hidden' => false,
				);
			}
		}

		return $cart_item_data;
	}
}
