<?php
/**
 * Custom CSS for the purchase options (Pro).
 *
 * The one thing Pro adds to Settings > Product page: a box of CSS, printed after
 * the store's own colours through free's `subscrpt_plan_selector_inline_css`.
 * It is arbitrary CSS, so only a user who can `edit_css` can change it, and it
 * is cleaned on the way in and again on the way out, because it is printed
 * inside a `<style>` element and must not be able to leave it.
 *
 * @package SpringDevs\SubscriptionPro
 */

namespace SpringDevs\SubscriptionPro\Frontend;

defined( 'ABSPATH' ) || exit;

/**
 * The custom CSS setting and its output.
 */
class PlanCustomCss {

	/**
	 * Option name.
	 */
	const OPTION = 'subscrpt_plan_custom_css';

	/**
	 * Register hooks.
	 */
	public function __construct() {
		add_filter( 'subscrpt_plan_selector_inline_css', array( $this, 'append' ) );
		add_filter( 'subscrpt_settings_fields', array( $this, 'add_settings_fields' ) );
		add_action( 'subscrpt_register_settings', array( $this, 'register_settings' ) );
	}

	/**
	 * Make a string safe to print inside a `<style>` element.
	 *
	 * Removes every tag and every `<`: CSS has no use for one outside a string or
	 * a comment, and a lone `<` is how a `</style>` would be rebuilt.
	 *
	 * @param mixed $css Raw CSS.
	 *
	 * @return string
	 */
	public static function sanitize( $css ): string {
		if ( ! is_string( $css ) ) {
			return '';
		}

		$css = preg_replace( '#<\s*/?\s*style#i', '', $css );
		$css = wp_strip_all_tags( (string) $css );

		return trim( str_replace( '<', '', $css ) );
	}

	/**
	 * Sanitise callback of the setting: the new CSS when the user may edit CSS,
	 * else the stored CSS unchanged — a user without the capability who saves
	 * the settings form neither changes it nor wipes it.
	 *
	 * @param mixed $value Posted value.
	 *
	 * @return string
	 */
	public function sanitize_setting( $value ): string {
		if ( ! current_user_can( 'edit_css' ) ) {
			return (string) get_option( self::OPTION, '' );
		}

		return self::sanitize( $value );
	}

	/**
	 * Append the CSS to what free prints after the purchase options' stylesheet.
	 *
	 * @param string $css Free's CSS.
	 *
	 * @return string
	 */
	public function append( $css ) {
		return (string) $css . self::sanitize( get_option( self::OPTION, '' ) );
	}

	/**
	 * Add the CSS box to the Product page group.
	 *
	 * @param array $settings_fields Settings fields.
	 *
	 * @return array
	 */
	public function add_settings_fields( $settings_fields ) {
		$settings_fields[] = array(
			'type'       => 'textarea',
			'group'      => 'product_page',
			'priority'   => 30,
			'field_data' => array(
				'id'          => self::OPTION,
				'title'       => __( 'Custom CSS', 'subscription-pro' ),
				'description' => current_user_can( 'edit_css' )
					? __( 'Added after the settings above, on every product page that offers plans. Target .subscrpt-buybox.', 'subscription-pro' )
					: __( 'Your account cannot edit CSS, so this is read only.', 'subscription-pro' ),
				'value'       => (string) get_option( self::OPTION, '' ),
				'placeholder' => '.subscrpt-buybox { }',
				'rows'        => 8,
				'disabled'    => ! current_user_can( 'edit_css' ),
			),
		);

		return $settings_fields;
	}

	/**
	 * Register the setting.
	 *
	 * @return void
	 */
	public function register_settings() {
		register_setting(
			'wp_subscription_settings',
			self::OPTION,
			array(
				'type'              => 'string',
				'sanitize_callback' => array( $this, 'sanitize_setting' ),
			)
		);
	}
}
