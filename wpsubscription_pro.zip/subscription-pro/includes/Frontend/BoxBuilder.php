<?php
/**
 * The box builder on the product page.
 *
 * It renders inside WooCommerce's own add-to-cart form, which is what makes it
 * work in a block theme too: the product template's add-to-cart block renders
 * that same form, so the builder arrives with it.
 *
 * @package SpringDevs\SubscriptionPro\Frontend
 */

namespace SpringDevs\SubscriptionPro\Frontend;

use SpringDevs\SubscriptionPro\Illuminate\Box\Box;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxCart;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxOnceLabel;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxProduct;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxQuote;
use SpringDevs\SubscriptionPro\Illuminate\Box\EditionRepository;

defined( 'ABSPATH' ) || exit;

/**
 * Renders the storefront box builder.
 */
class BoxBuilder {

	/**
	 * Purchase option types whose card can hold the builder.
	 */
	const CARD_TYPES = [ 'subscribe_save', 'recurring', 'one_time' ];

	/**
	 * Products whose builder already rendered on this request, by id, so each
	 * gets one whichever hook runs first.
	 *
	 * @var array<int, true>
	 */
	private $rendered_for = [];

	/**
	 * Register hooks.
	 */
	public function __construct() {
		add_action( 'subscrpt_plan_card_body', [ $this, 'card_body' ], 10, 3 );
		add_action( 'woocommerce_before_add_to_cart_button', array( $this, 'render' ), 20 );
		add_filter( 'woocommerce_product_single_add_to_cart_text', [ $this, 'button_text' ], 20, 2 );
		add_filter( 'woocommerce_quantity_input_args', [ $this, 'quantity_args' ], 20, 2 );
		add_filter( 'wc_stripe_should_hide_express_checkout_button_based_on_tax_setup', [ $this, 'hide_express_checkout' ] );
		add_shortcode( 'subscrpt_box', array( $this, 'shortcode' ) );
		add_filter( 'body_class', [ $this, 'body_class' ] );
	}

	/**
	 * Mark the page of a product that sells a build-your-own box.
	 *
	 * The builder is the page there, not a widget beside the gallery, so the
	 * stylesheet gives it the full width and drops the gallery.
	 *
	 * @param string[] $classes Body classes.
	 *
	 * @return string[]
	 */
	public function body_class( $classes ) {
		if ( ! function_exists( 'is_product' ) || ! is_product() ) {
			return $classes;
		}

		$product_id = (int) get_queried_object_id();

		if ( $product_id && BoxProduct::is_customer_built( $product_id ) ) {
			$classes[] = 'subscrpt-box-page';
		}

		return $classes;
	}

	/**
	 * Hide Stripe's express checkout on a box product that has no price of its own.
	 *
	 * A box priced by its picks has nothing to charge until the builder is
	 * filled, and Stripe's element throws when it is created with an amount of
	 * zero, which broke the product page script.
	 *
	 * @param bool $hide Whether Stripe already hides the buttons.
	 *
	 * @return bool
	 */
	public function hide_express_checkout( $hide ) {
		if ( $hide || ! function_exists( 'is_product' ) || ! is_product() ) {
			return $hide;
		}

		$product = wc_get_product( get_queried_object_id() );

		if ( $product && BoxProduct::is_box( $product ) && (float) $product->get_price() <= 0 ) {
			return true;
		}

		return $hide;
	}

	/**
	 * Enqueue the builder script with the sentences its counter speaks.
	 *
	 * The counter is written in the browser, so its words are translated here
	 * and handed over as `window.subscrptBoxBuilder`.
	 *
	 * @return void
	 */
	public static function enqueue_script(): void {
		if ( wp_script_is( 'subscrpt_box_builder_js', 'enqueued' ) ) {
			return;
		}

		wp_enqueue_script( 'subscrpt_box_builder_js' );
		wp_localize_script(
			'subscrpt_box_builder_js',
			'subscrptBoxBuilder',
			[
				/* translators: %d: number of items picked. */
				'picked'                => __( '%d picked', 'subscription-pro' ),
				/* translators: 1: number of items picked, 2: number the box holds. */
				'pickedOf'              => __( '%1$d of %2$d picked', 'subscription-pro' ),
				/* translators: 1: number of items picked, 2: minimum the box needs. */
				'pickedNeeded'          => __( '%1$d picked, at least %2$d needed', 'subscription-pro' ),
				/* translators: 1: number of items picked, 2: minimum that must ship every cycle. */
				'pickedNeededRecurring' => __( '%1$d picked, at least %2$d needed that are not once', 'subscription-pro' ),
			]
		);
	}

	/**
	 * The cart line the shopper came to change, when the page was opened by
	 * "Edit box".
	 *
	 * A key that is not a customer-built line of this product and this box — a
	 * line since removed, a key an earlier edit replaced, another product's —
	 * is ignored and the page is the ordinary builder.
	 *
	 * @param int $product_id Product being viewed.
	 * @param int $box_id     Box being viewed.
	 *
	 * @return array{key:string,picks:array<int,int>,once:array<int,true>,plan_id:int,one_time:bool}|array Empty when not editing.
	 */
	public function edit_context( int $product_id, int $box_id ): array {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$key  = isset( $_GET['subscrpt_box_edit'] ) ? sanitize_text_field( wp_unslash( $_GET['subscrpt_box_edit'] ) ) : '';
		$cart = function_exists( 'WC' ) ? WC()->cart : null;
		$line = $key && is_object( $cart ) ? $cart->get_cart_item( $key ) : null;

		if ( ! is_array( $line ) || empty( $line[ BoxCart::CART_KEY ]['items'] ) ) {
			return [];
		}

		if ( (int) ( $line['product_id'] ?? 0 ) !== $product_id || (int) ( $line[ BoxCart::CART_KEY ]['box_id'] ?? 0 ) !== $box_id ) {
			return [];
		}

		$box = BoxProduct::box_for( $product_id, $box_id );

		if ( ! $box || ! $box->is_customer_built() ) {
			return [];
		}

		$picks     = [];
		$recurring = [];
		$once      = [];

		foreach ( BoxProduct::normalise_items( $line[ BoxCart::CART_KEY ]['items'] ) as $item ) {
			$picks[ $item['product_id'] ] = ( $picks[ $item['product_id'] ] ?? 0 ) + (int) $item['qty'];

			if ( $item['once'] ) {
				$once[ $item['product_id'] ] = true;
			} else {
				$recurring[ $item['product_id'] ] = true;
			}
		}

		// The builder offers one choice per product, so a product held both ways
		// opens as every cycle.
		$once = array_diff_key( $once, $recurring );

		return [
			'key'      => $key,
			'picks'    => $picks,
			'once'     => $once,
			'plan_id'  => (int) ( $line['subscrpt_plan_id'] ?? 0 ),
			'one_time' => ! empty( $line[ BoxCart::CART_KEY ]['one_time'] ),
		];
	}

	/**
	 * Fix the quantity at one while a box is being edited, so WooCommerce
	 * prints it as a hidden field instead of an input that does nothing.
	 *
	 * @param array       $args    Quantity input args.
	 * @param \WC_Product $product Product.
	 *
	 * @return array
	 */
	public function quantity_args( $args, $product ) {
		if ( ! $this->is_editing( $product ) ) {
			return $args;
		}

		$args['min_value']   = 1;
		$args['max_value']   = 1;
		$args['input_value'] = 1;

		return $args;
	}

	/**
	 * Whether the page is editing a cart line of this box product.
	 *
	 * @param mixed $product Product.
	 *
	 * @return bool
	 */
	private function is_editing( $product ): bool {
		if ( ! $product instanceof \WC_Product || ! BoxProduct::is_box( $product ) ) {
			return false;
		}

		$box = $this->chosen_box( $product->get_id(), BoxProduct::boxes_for( $product->get_id() ) );

		return $box && $this->edit_context( $product->get_id(), $box->id() );
	}

	/**
	 * "Update box" on the add-to-cart button while a box is being edited.
	 *
	 * @param string      $text    Button text.
	 * @param \WC_Product $product Product.
	 *
	 * @return string
	 */
	public function button_text( $text, $product ) {
		return $this->is_editing( $product ) ? __( 'Update box', 'subscription-pro' ) : $text;
	}

	/**
	 * Render the builder for the product being viewed, where no purchase option
	 * did: a product without plans, a variable product before a variation is
	 * chosen, or a theme's plan selector that never fires the card action.
	 *
	 * @return void
	 */
	public function render(): void {
		global $product;

		if ( $product instanceof \WC_Product && ! isset( $this->rendered_for[ $product->get_id() ] ) ) {
			$this->rendered_for[ $product->get_id() ] = true;
			$this->render_for( $product );
		}
	}

	/**
	 * Mark a purchase option that can hold the builder, and render the builder
	 * inside the first one.
	 *
	 * The marker goes in every eligible body, on the page and in the markup
	 * rendered per variation; box-builder.js moves the one builder only into a
	 * selected body that carries it. The builder itself renders only on the
	 * page: the variation markup is swapped in, so a builder there would repeat
	 * its ids.
	 *
	 * @param array       $group   Plan group.
	 * @param \WC_Product $product Product being viewed, or the variation.
	 * @param string      $context 'page' or 'variation'.
	 *
	 * @return void
	 */
	public function card_body( $group, $product, $context ): void {
		if ( ! is_array( $group ) || ! in_array( $group['type'] ?? '', self::CARD_TYPES, true ) || ! BoxProduct::is_box( $product ) ) {
			return;
		}

		echo '<span data-subscrpt-box-eligible hidden></span>';

		if ( 'page' !== $context || isset( $this->rendered_for[ $product->get_id() ] ) ) {
			return;
		}

		$this->rendered_for[ $product->get_id() ] = true;
		$this->render_for( $product );
	}

	/**
	 * `[subscrpt_box id="123"]` — the builder on any page.
	 *
	 * @param array $atts Shortcode attributes.
	 *
	 * @return string
	 */
	public function shortcode( $atts ): string {
		$atts = shortcode_atts( array( 'id' => 0 ), $atts, 'subscrpt_box' );

		$product = wc_get_product( absint( $atts['id'] ) );

		if ( ! $product instanceof \WC_Product || ! BoxProduct::is_box( $product ) ) {
			return '';
		}

		ob_start();
		woocommerce_template_single_add_to_cart();

		return (string) ob_get_clean();
	}

	/**
	 * Render the builder for one product.
	 *
	 * Protected so a test can stand in for the template.
	 *
	 * @param \WC_Product $product Product.
	 *
	 * @return void
	 */
	protected function render_for( \WC_Product $product ): void {
		if ( ! BoxProduct::is_box( $product ) ) {
			return;
		}

		$product_id = $product->get_id();

		// A product may sell several boxes. Which one the shopper is looking at
		// decides everything below — the type, the rules, the choices — so it is
		// resolved first and everything else is asked of that box.
		$boxes = BoxProduct::boxes_for( $product_id );
		$box   = $this->chosen_box( $product_id, $boxes );

		if ( ! $box ) {
			return;
		}

		$box_id = $box->id();
		$type   = $box->type();
		$rules  = $box->rules();

		wp_enqueue_style( 'subscrpt_box_css' );
		self::enqueue_script();

		$edit            = $this->edit_context( $product_id, $box_id );
		$contents        = array();
		$choices         = array();
		$defaults        = array();
		$variation_sizes = array();
		$quote           = array();
		$start           = array();
		$once_offer      = array();
		$once_ticked     = array();
		$once_label      = '';
		$quote_url       = '';
		$pick_notice     = '';

		if ( BoxProduct::TYPE_BUILD === $type ) {
			foreach ( $box->pool_product_ids() as $pool_id ) {
				$pool_product = wc_get_product( $pool_id );

				// Something out of stock cannot be packed, so it is not offered.
				if ( $pool_product instanceof \WC_Product && $pool_product->is_in_stock() ) {
					$choices[] = $pool_product;
				}
			}

			foreach ( $box->default_items() as $item ) {
				$defaults[ $item['product_id'] ] = (int) $item['qty'];
			}

			// What the builder opens with: the line's picks when editing, the
			// merchant's otherwise.
			if ( $edit ) {
				$start = $edit['picks'];
			} else {
				$resolved    = $this->resolve_pick( $defaults, $box, $choices, $this->picked() );
				$start       = $resolved['start'];
				$pick_notice = $resolved['notice'];
			}

			$once_state  = $this->once_state( $box, $choices, $edit ? $edit['once'] : [], $this->picked(), $this->picked_once() );
			$once_offer  = $once_state['offer'];
			$once_ticked = $once_state['ticked'];

			$once_label = BoxOnceLabel::choice_label( BoxOnceLabel::interval_for( $product_id, $edit ? $edit['plan_id'] : 0 ) );

			// The price is the server's to say; under the fixed strategy there
			// is nothing to say and nothing to fetch.
			list( $recurring_start, $once_start ) = BoxQuote::split_once_flags( $start, $once_ticked );

			$quote = BoxQuote::respond( $product_id, $box_id, $recurring_start, $once_start );

			if ( ! empty( $quote['is_sum'] ) ) {
				$quote_url = \WC_AJAX::get_endpoint( BoxQuote::ACTION );
			}

			// A variable box sells sizes as variations, so the rule the builder
			// enforces changes with the chosen variation.
			if ( $product->is_type( 'variable' ) ) {
				foreach ( $product->get_children() as $variation_id ) {
					$variation_sizes[ $variation_id ] = BoxProduct::size( $product_id, (int) $variation_id );
				}
			}
		} else {
			$contents = $box->curated_items();

			if ( BoxProduct::TYPE_EDITION === $type ) {
				$edition = EditionRepository::published_for_date( $box_id, time() );

				if ( $edition && $edition['contents'] ) {
					$contents = $edition['contents'];
				}
			}
		}

		$choice_groups = self::group_choices( $choices );

		include SUBSCRIPT_PRO_PATH . '/templates/box/builder.php';
	}

	/**
	 * The attributes a variable card's options popup asks about: every
	 * attribute the product uses for variations, with all its values, as its
	 * own product page shows them. Which combinations the box offers is the
	 * popup's to say, from the variations on the card.
	 *
	 * @param \WC_Product $parent Variable product.
	 *
	 * @return array<string,array{label:string,values:array<string,string>}> Keyed as a variation stores it, e.g. attribute_pa_color.
	 */
	public static function variant_attributes( \WC_Product $parent ): array {
		$attrs = [];

		if ( ! $parent->is_type( 'variable' ) ) {
			return $attrs;
		}

		foreach ( $parent->get_variation_attributes() as $name => $options ) {
			$key = 'attribute_' . sanitize_title( $name );

			$attrs[ $key ] = [
				'label'  => wc_attribute_label( $name, $parent ),
				'values' => [],
			];

			foreach ( $options as $option ) {
				$term = taxonomy_exists( $name ) ? get_term_by( 'slug', $option, $name ) : false;

				$attrs[ $key ]['values'][ (string) $option ] = $term ? $term->name : (string) $option;
			}
		}

		return $attrs;
	}

	/**
	 * Fold the choices into the builder's cards: one per product, with a
	 * variable product's offered variations behind one selector on its card.
	 * Only the display is grouped — each variation still posts on its own.
	 *
	 * @param \WC_Product[] $choices What the builder offers.
	 *
	 * @return array<int,array{product:\WC_Product,variations:\WC_Product[]}>
	 */
	public static function group_choices( array $choices ): array {
		$groups = [];

		foreach ( $choices as $choice ) {
			$parent = $choice->is_type( 'variation' ) ? wc_get_product( $choice->get_parent_id() ) : null;

			if ( ! $parent ) {
				$groups[ 'p' . $choice->get_id() ] = [
					'product'    => $choice,
					'variations' => [],
				];
				continue;
			}

			$key = 'v' . $parent->get_id();

			if ( ! isset( $groups[ $key ] ) ) {
				$groups[ $key ] = [
					'product'    => $parent,
					'variations' => [],
				];
			}

			$groups[ $key ]['variations'][] = $choice;
		}

		return array_values( $groups );
	}

	/**
	 * Put one of the item an item's page sent into the builder's opening picks.
	 *
	 * @param array<int,int> $start   Opening quantities by product id.
	 * @param Box            $box     The box being built.
	 * @param \WC_Product[]  $choices What the builder offers.
	 * @param int            $pick    Product id asked for, 0 for none.
	 *
	 * @return array<int,int>
	 */
	public function with_pick( array $start, Box $box, array $choices, int $pick ): array {
		return $this->resolve_pick( $start, $box, $choices, $pick )['start'];
	}

	/**
	 * Resolve the item an item's page sent, and say so when it is not there.
	 *
	 * The item arrives as `?subscrpt_box_pick=`, a URL a shopper can edit, so it
	 * must be something this builder offers (in the pool, in stock). The
	 * opening picks are the merchant's suggestions and the pick is the
	 * shopper's choice, so when the box would be over its size the last
	 * suggested unit gives way.
	 *
	 * @param array<int,int> $start   Opening quantities by product id.
	 * @param Box            $box     The box being built.
	 * @param \WC_Product[]  $choices What the builder offers.
	 * @param int            $pick    Product id asked for, 0 for none.
	 *
	 * @return array{start:array<int,int>,notice:string} The picks, and a sentence for the shopper, empty when nothing needs saying.
	 */
	public function resolve_pick( array $start, Box $box, array $choices, int $pick ): array {
		if ( $pick <= 0 || isset( $start[ $pick ] ) ) {
			return [
				'start'  => $start,
				'notice' => '',
			];
		}

		$offered = [];

		foreach ( $choices as $choice ) {
			$offered[ $choice->get_id() ] = true;
		}

		if ( ! isset( $offered[ $pick ] ) ) {
			return [
				'start'  => $start,
				'notice' => __( 'The item you chose is not available for this box right now.', 'subscription-pro' ),
			];
		}

		$max  = $box->size()['max'];
		$held = 0;

		foreach ( $start as $id => $qty ) {
			$held += isset( $offered[ $id ] ) ? (int) $qty : 0;
		}

		if ( $max > 0 && $held + 1 > $max ) {
			foreach ( array_reverse( array_keys( $start ), true ) as $id ) {
				if ( isset( $offered[ $id ] ) && $start[ $id ] > 0 ) {
					--$start[ $id ];

					if ( $start[ $id ] <= 0 ) {
						unset( $start[ $id ] );
					}

					break;
				}
			}
		}

		$start[ $pick ] = 1;

		return [
			'start'  => $start,
			'notice' => '',
		];
	}

	/**
	 * Which items get the once choice, and which open ticked.
	 *
	 * @param Box             $box       The box being built.
	 * @param \WC_Product[]   $choices   What the builder offers.
	 * @param array<int,true> $edit_once Products the edited line holds once, empty when not editing.
	 * @param int             $pick      Product id an item's page sent, 0 for none.
	 * @param bool            $pick_once Whether that page asked for it once.
	 *
	 * @return array{offer:array<int,true>,ticked:array<int,true>}
	 */
	public function once_state( Box $box, array $choices, array $edit_once, int $pick, bool $pick_once ): array {
		$offer  = [];
		$ticked = [];

		foreach ( $choices as $choice ) {
			$id = $choice->get_id();

			if ( ! BoxOnceLabel::toggle_offered( $box, $id ) ) {
				continue;
			}

			$offer[ $id ] = true;

			if ( isset( $edit_once[ $id ] ) || ( $pick_once && $pick === $id ) ) {
				$ticked[ $id ] = true;
			}
		}

		return [
			'offer'  => $offer,
			'ticked' => $ticked,
		];
	}

	/**
	 * The item an item's page asked to start the box with.
	 *
	 * @return int Product id, 0 when none was named.
	 */
	private function picked(): int {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only, like the box id.
		return isset( $_GET['subscrpt_box_pick'] ) ? absint( $_GET['subscrpt_box_pick'] ) : 0;
	}

	/**
	 * Whether the item's page asked for the item once.
	 *
	 * @return bool
	 */
	private function picked_once(): bool {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only, like the pick.
		return ! empty( $_GET['subscrpt_box_pick_once'] );
	}

	/**
	 * The box being looked at.
	 *
	 * The choice arrives as a query argument, so switching box is an ordinary
	 * link and the whole builder re-renders for it on the server — no JavaScript,
	 * and it survives being bookmarked or shared. A id naming a box this product
	 * does not sell falls back to the first rather than erroring: it is a URL a
	 * shopper can edit, not a form submission.
	 *
	 * @param int   $product_id Product id.
	 * @param Box[] $boxes      Boxes this product sells.
	 *
	 * @return Box|null
	 */
	private function chosen_box( int $product_id, array $boxes ): ?Box {
		if ( ! $boxes ) {
			return null;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$asked = isset( $_GET['subscrpt_box_id'] ) ? absint( $_GET['subscrpt_box_id'] ) : 0;

		if ( $asked ) {
			$named = BoxProduct::box_for( $product_id, $asked );

			if ( $named ) {
				return $named;
			}
		}

		return $boxes[0];
	}
}
