<?php
/**
 * My Account subscription actions, notices and delivery schedules.
 *
 * @package SpringDevs\SubscriptionPro\Frontend
 */

namespace SpringDevs\SubscriptionPro\Frontend;

use SpringDevs\Subscription\Illuminate\Helper as FreeHelper;
use SpringDevs\SubscriptionPro\Illuminate\Helper;

/**
 * Class Account
 *
 * @package SpringDevs\SubscriptionPro\Frontend
 */
class Account {

	/**
	 * Initialize the class
	 */
	public function __construct() {
		add_filter( 'subscrpt_single_action_buttons', array( $this, 'action_buttons' ), 10, 4 );
		add_action( 'subscrpt_execute_actions', array( $this, 'execute_actions' ), 10, 2 );
		add_action( 'before_single_subscrpt_content', array( $this, 'display_scheduled_downgrade_notice' ) );
		add_action( 'subscrpt_after_subscription_totals', array( $this, 'display_delivery_schedules' ) );
	}

	/**
	 * Subscription customer page action buttons related to premium version.
	 *
	 * @param array  $action_buttons Action Buttons.
	 * @param int    $id             subscription id.
	 * @param string $subscrpt_nonce action_nonce.
	 * @param string $status         subscription status.
	 *
	 * @return array $action_buttons
	 */
	public function action_buttons( $action_buttons, $id, $subscrpt_nonce, $status ) {
		$subscription_data = FreeHelper::get_subscription_data( $id );

		$product_deleted = get_post_meta( $id, '_product_deleted', true );
		if ( 'yes' === $product_deleted ) {
			return array();
		}

		// Don't show any renewal-related buttons if payment limit is reached
		if ( function_exists( 'subscrpt_is_max_payments_reached' ) && subscrpt_is_max_payments_reached( $id ) ) {
			return $action_buttons;
		}

		$order_id = get_post_meta( $id, '_subscrpt_order_id', true );
		$order    = wc_get_order( $order_id );

		$is_auto_renew   = $subscription_data['is_auto_renew'];
		$renewal_setting = in_array( get_option( 'wp_subscription_auto_renewal_toggle', '1' ), [ 1, '1', 'true', 'yes' ], true );

		if ( $renewal_setting && class_exists( 'WC_Stripe' ) && $order && $order->get_payment_method() === 'stripe' ) {
			if ( ! $is_auto_renew ) {
				$action_buttons['auto-renew-on'] = array(
					'url'   => subscrpt_get_action_url( 'renew-on', $subscrpt_nonce, $id ),
					'label' => __( 'Turn on Auto Renewal', 'subscription-pro' ),
				);
			} else {
				$action_buttons['auto-renew-off'] = array(
					'url'   => subscrpt_get_action_url( 'renew-off', $subscrpt_nonce, $id ),
					'label' => __( 'Turn off Auto Renewal', 'subscription-pro' ),
				);
			}
		}

		if ( $this->early_renewal_allowed( (int) $id ) ) {
			$url   = subscrpt_get_action_url( 'early-renew', $subscrpt_nonce, $id );
			$label = __( 'Early Renew', 'subscription-pro' );

			$early_meta = get_post_meta( $id, '_order_waiting_early_renew_subscrpt_meta', true );
			if ( $early_meta ) {
				$early_renew_order = wc_get_order( $early_meta['order_id'] );
				if ( ! empty( $early_renew_order ) && 'pending' === $early_renew_order->get_status() ) {
					$url   = $early_renew_order->get_checkout_payment_url();
					$label = __( 'Pay for Early Renew', 'subscription-pro' );
				} elseif ( ! empty( $early_renew_order ) && ! $early_renew_order->has_status( array( 'cancelled', 'trash' ) ) ) {
					return $action_buttons;
				}
			} elseif ( ! $this->is_early_renew_window_open( $id ) ) {
				return $action_buttons;
			}

			// Allow customization of button text
			$label = apply_filters( 'subscrpt_split_payment_button_text', $label, 'early-renew', $id, $status );

			$action_buttons['early-renew'] = array(
				'url'   => $url,
				'label' => $label,
			);
		}

		return $action_buttons;
	}

	/**
	 * Execute actions thats releated to premium version.
	 *
	 * @param int    $subscription_id Subscription ID.
	 * @param string $action          Action name.
	 */
	public function execute_actions( $subscription_id, $action ) {
		if ( 'early-renew' === $action ) {
			if ( ! $this->early_renewal_allowed( (int) $subscription_id ) ) {
				wc_add_notice( __( 'Early renewal is not available for this subscription.', 'subscription-pro' ), 'error' );
				return;
			}

			if ( ! get_post_meta( $subscription_id, '_order_waiting_early_renew_subscrpt_meta', true ) && ! $this->is_early_renew_window_open( $subscription_id ) ) {
				wc_add_notice( __( 'Early renewal is not available for this subscription yet.', 'subscription-pro' ), 'error' );
				return;
			}

			Helper::create_early_renewal_order( $subscription_id );

			// Send the customer straight to payment instead of back to the subscription page.
			$early_meta        = get_post_meta( $subscription_id, '_order_waiting_early_renew_subscrpt_meta', true );
			$early_renew_order = $early_meta ? wc_get_order( $early_meta['order_id'] ) : false;
			if ( $early_renew_order && $early_renew_order->needs_payment() ) {
				wp_safe_redirect( $early_renew_order->get_checkout_payment_url() );
				exit;
			}
		} elseif ( 'cancel-downgrade' === $action ) {
			$this->cancel_scheduled_downgrade( $subscription_id );
		}
	}

	/**
	 * Whether a subscription may be renewed early at all.
	 *
	 * The feature is on, the subscription is active and it is not in a trial.
	 * The button and the action both ask this.
	 *
	 * @param int $subscription_id Subscription ID.
	 *
	 * @return bool
	 */
	protected function early_renewal_allowed( int $subscription_id ): bool {
		return '1' === get_option( 'subscrpt_early_renew', '' )
			&& 'active' === get_post_status( $subscription_id )
			&& empty( get_post_meta( $subscription_id, '_subscrpt_trial', true ) );
	}

	/**
	 * Whether the Early Renew button may show today, per the visibility setting.
	 *
	 * @param int $subscription_id Subscription ID.
	 *
	 * @return bool
	 */
	protected function is_early_renew_window_open( $subscription_id ) {
		$visibility = get_option( 'subscrpt_early_renew_visibility', 'always' );
		if ( 'always' === $visibility ) {
			return true;
		}

		$now       = time();
		$next_date = (int) get_post_meta( $subscription_id, '_subscrpt_next_date', true );

		if ( 'day_of_month' === $visibility ) {
			$day = min( max( 1, absint( get_option( 'subscrpt_early_renew_day_of_month', 25 ) ) ), (int) wp_date( 't', $now ) );
			return (int) wp_date( 'j', $now ) >= $day;
		}

		if ( $next_date <= 0 ) {
			return true;
		}

		if ( 'before_days' === $visibility ) {
			$days = max( 1, absint( get_option( 'subscrpt_early_renew_before_days', 7 ) ) );
			return $next_date - $now <= $days * DAY_IN_SECONDS;
		}

		if ( 'cycle_left' === $visibility ) {
			$order_item_id = get_post_meta( $subscription_id, '_subscrpt_order_item_id', true );
			$item_meta     = wc_get_order_item_meta( $order_item_id, '_subscrpt_meta' );
			if ( empty( $item_meta['type'] ) ) {
				return true;
			}

			$recurr_timing = ( $item_meta['time'] ?? 1 ) . ' ' . FreeHelper::get_typos( 1, $item_meta['type'] );
			$cycle_start   = sdevs_wp_strtotime( '-' . $recurr_timing, $next_date );
			$cycle_length  = $next_date - $cycle_start;
			if ( $cycle_length <= 0 ) {
				return true;
			}

			$percent = min( 100, max( 1, absint( get_option( 'subscrpt_early_renew_cycle_left', 20 ) ) ) );
			return ( $next_date - $now ) / $cycle_length * 100 <= $percent;
		}

		return true;
	}

	/**
	 * Cancel a scheduled (deferred) downgrade for a subscription.
	 *
	 * Nonce and ownership are already verified by the free ActionController before
	 * `subscrpt_execute_actions` fires.
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	protected function cancel_scheduled_downgrade( $subscription_id ) {
		$pending = get_post_meta( $subscription_id, '_subscrpt_pending_switch', true );
		if ( empty( $pending ) ) {
			return;
		}

		delete_post_meta( $subscription_id, '_subscrpt_pending_switch' );

		$comment_id = wp_insert_comment(
			array(
				'comment_author'  => 'Subscription for WooCommerce',
				'comment_content' => __( 'Scheduled downgrade cancelled by the customer.', 'subscription-pro' ),
				'comment_post_ID' => $subscription_id,
				'comment_type'    => 'order_note',
			)
		);
		update_comment_meta( $comment_id, '_subscrpt_activity', __( 'Downgrade Cancelled', 'subscription-pro' ) );
		update_comment_meta( $comment_id, '_subscrpt_activity_type', 'downgrade_cancelled' );

		if ( function_exists( 'wc_add_notice' ) ) {
			wc_add_notice( __( 'Your scheduled downgrade has been cancelled.', 'subscription-pro' ), 'success' );
		}
	}

	/**
	 * Show a notice on the subscription details page when a downgrade is scheduled.
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	public function display_scheduled_downgrade_notice( $subscription_id ) {
		$pending = get_post_meta( $subscription_id, '_subscrpt_pending_switch', true );
		if ( empty( $pending ) || empty( $pending['new_variation_id'] ) ) {
			return;
		}

		$variation = wc_get_product( (int) $pending['new_variation_id'] );
		$plan_name = $variation ? $variation->get_name() : __( 'a different plan', 'subscription-pro' );

		$next_date = (int) get_post_meta( $subscription_id, '_subscrpt_next_date', true );
		$effective = $next_date ? date_i18n( get_option( 'date_format' ), $next_date ) : __( 'the next renewal', 'subscription-pro' );

		$cancel_url = subscrpt_get_action_url( 'cancel-downgrade', wp_create_nonce( 'subscrpt_nonce' ), $subscription_id );

		wp_enqueue_style( 'subscrpt_switch_css', SUBSCRIPT_PRO_ASSETS . '/css/frontend/switch.css', [], SUBSCRIPT_PRO_VERSION );
		wp_enqueue_script( 'subscrpt_switch_js', SUBSCRIPT_PRO_ASSETS . '/js/frontend/switch.js', [], SUBSCRIPT_PRO_VERSION, true );

		$confirm_message = __( 'Cancel the scheduled downgrade? Your subscription will stay on the current plan.', 'subscription-pro' );
		?>
		<div class="subscrpt-scheduled-downgrade-notice" role="status">
			<span class="subscrpt-scheduled-downgrade-notice__icon" aria-hidden="true">
				<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>
			</span>
			<div class="subscrpt-scheduled-downgrade-notice__body">
				<p class="subscrpt-scheduled-downgrade-notice__text">
					<?php
					printf(
						/* translators: 1: target plan name, 2: effective date. */
						esc_html__( 'Your subscription will downgrade to %1$s on %2$s. You can continue accessing your current subscription till then.', 'subscription-pro' ),
						'<strong>' . esc_html( $plan_name ) . '</strong>',
						'<strong>' . esc_html( $effective ) . '</strong>'
					);
					?>
				</p>
				<a href="<?php echo esc_url( $cancel_url ); ?>" class="subscrpt-scheduled-downgrade-notice__cancel" data-subscrpt-confirm="<?php echo esc_attr( $confirm_message ); ?>"><?php esc_html_e( 'Cancel downgrade', 'subscription-pro' ); ?></a>
			</div>
		</div>
		<?php
	}

	/**
	 * Display the delivery schedules of a subscription.
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	public function display_delivery_schedules( $subscription_id ) {
		// Get product to check if it's virtual or downloadable
		$order_id      = get_post_meta( $subscription_id, '_subscrpt_order_id', true );
		$order_item_id = get_post_meta( $subscription_id, '_subscrpt_order_item_id', true );
		$order         = wc_get_order( $order_id );

		if ( ! $order ) {
			return;
		}

		$order_item = $order->get_item( $order_item_id );
		if ( ! $order_item ) {
			return;
		}

		$product = $order_item->get_product();
		if ( ! $product ) {
			return;
		}

		// Don't show delivery schedules for virtual or downloadable products
		if ( $product->is_virtual() || $product->is_downloadable() ) {
			return;
		}

		$delivery_schedules = get_posts(
			array(
				'post_type'   => 'subscrpt_delivery',
				'numberposts' => 5,
				'post_status' => array( 'waiting', 'shipped', 'in_process', 'cancelled' ),
				'meta_query'  => array(
					'relation' => 'AND',
					array(
						'key'     => '_subscrpt_subscription_id',
						'value'   => $subscription_id,
						'compare' => '=',
					),
					array(
						'key'     => '_subscrpt_shipping_on',
						'value'   => time(),
						'compare' => '>',
					),
				),
			)
		);
		?>
		<h2><?php esc_html_e( 'Delivery Schedules', 'subscription-pro' ); ?></h2>
<table class="woocommerce-table woocommerce-table--order-details shop_table order_details">
	<thead>
		<tr>
			<th class="product-name"><?php esc_html_e( 'Shipped on', 'subscription-pro' ); ?></th>
			<th class="product-total"><?php esc_html_e( 'Delivery Status', 'subscription-pro' ); ?></th>
			<th class="product-total"><?php esc_html_e( 'Delivery On', 'subscription-pro' ); ?></th>
		</tr>
	</thead>
	<tbody>
		<?php
		foreach ( $delivery_schedules as $delivery ) {
			?>
			<tr class="order_item">
				<td class="product-name">
				<?php
				$shipping_date = get_post_meta( $delivery->ID, '_subscrpt_shipping_on', true );
				$shipped_date  = get_post_meta( $delivery->ID, '_subscrpt_shipped_date', true );
				?>
					<?php echo $shipping_date ? esc_html( date_i18n( get_option( 'date_format' ), $shipping_date ) ) : '-'; ?>
				</td>
				<td class="product-total">
					<?php echo esc_html( get_post_status_object( get_post_status( $delivery->ID ) )->label ); ?>
				</td>
				<td class="product-total">
					<?php echo $shipped_date ? esc_html( date_i18n( get_option( 'date_format' ), $shipped_date ) ) : '-'; ?>
				</td>
			</tr>
			<?php
		}
		?>
		<?php if ( empty( $delivery_schedules ) ) : ?>
			<tr class="order_item">
				<td class="product-name" colspan="3"><?php esc_html_e( 'No delivery schedules found', 'subscription-pro' ); ?></td>
			</tr>
		<?php endif; ?>
		</tbody>
</table>
		<?php
	}
}
