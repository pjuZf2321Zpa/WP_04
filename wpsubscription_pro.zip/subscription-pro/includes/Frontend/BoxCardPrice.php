<?php
/**
 * The box's own price on the purchase card and the product's price line.
 *
 * Under the `sum` strategy a box costs what is in it, less the box's own
 * discount. The plan supplies only the cadence, so the plan's price, struck
 * regular price and "Save n%" badge on the card would all be wrong: they are
 * replaced here by "from $X" — the price of the cheapest box the rules accept —
 * until the builder swaps in the live quote. Fixed-strategy boxes are left alone.
 *
 * @package SpringDevs\SubscriptionPro\Frontend
 */

namespace SpringDevs\SubscriptionPro\Frontend;

use SpringDevs\Subscription\Admin\PlanPresenter;
use SpringDevs\Subscription\Illuminate\Plans\PlanRepository;
use SpringDevs\SubscriptionPro\Illuminate\Box\Box;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxPricing;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxProduct;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxQuote;

defined( 'ABSPATH' ) || exit;

/**
 * Prices a sum box on its cards.
 */
class BoxCardPrice {

	/**
	 * Register the card filter.
	 */
	public function __construct() {
		add_filter( 'subscrpt_plan_selector_groups', [ __CLASS__, 'groups' ], 20, 3 );
	}

	/**
	 * Replace the plan's price and saving on a sum box's cards with the box's.
	 *
	 * @param array       $groups  Groups built by free.
	 * @param \WC_Product $product Product or variation being rendered.
	 * @param string      $context 'page' or 'variation'.
	 *
	 * @return array
	 */
	public static function groups( $groups, $product, $context = 'page' ) {
		if ( ! is_array( $groups ) || ! $product instanceof \WC_Product ) {
			return $groups;
		}

		$box = self::sum_box( $product );

		if ( ! $box ) {
			return $groups;
		}

		$from = BoxPricing::from_price( $box );

		if ( $from <= 0 ) {
			return $groups;
		}

		$price   = BoxQuote::price_html( $from, true );
		$saving  = self::standing_discount( $box );
		$percent = $saving['percent'];

		foreach ( $groups as $index => $group ) {
			if ( ! is_array( $group ) || ! in_array( $group['type'] ?? '', BoxBuilder::CARD_TYPES, true ) ) {
				continue;
			}

			$group['price']            = $price;
			$group['old_price']        = '';
			$group['badge']            = $saving['label'];
			$group['discount_percent'] = $percent;

			foreach ( (array) ( $group['terms'] ?? [] ) as $key => $term ) {
				$term['price']            = $price;
				$term['regular_price']    = '';
				$term['saving_label']     = $saving['label'];
				$term['badge']            = $saving['label'];
				$term['discount_percent'] = $percent;
				$term['note']             = self::cadence_note( $term );

				$group['terms'][ $key ] = $term;
			}

			$groups[ $index ] = $group;
		}

		return $groups;
	}

	/**
	 * A term's note without the plan's amount: how often it bills, then
	 * whatever pro appended after the first line break (trial, signup fee).
	 *
	 * @param array $term Term, with its interval_label and note.
	 *
	 * @return string
	 */
	private static function cadence_note( array $term ): string {
		$label = trim( (string) ( $term['interval_label'] ?? '' ) );
		$note  = (string) ( $term['note'] ?? '' );
		$extra = false !== strpos( $note, '<br>' ) ? substr( $note, strpos( $note, '<br>' ) ) : '';

		if ( '' === $label ) {
			return $extra;
		}

		if ( preg_match( '/^1\s+(\S+)$/', $label, $match ) ) {
			$label = 'every ' . $match[1];
		} elseif ( preg_match( '/^\d/', $label ) ) {
			$label = 'every ' . $label;
		}

		/* translators: %s: how often the box bills, e.g. "every month". */
		return sprintf( esc_html__( 'Billed %s', 'subscription-pro' ), esc_html( $label ) ) . $extra;
	}

	/**
	 * "From $X / month" for the shop and the product summary.
	 *
	 * @param \WC_Product $product Product being priced.
	 *
	 * @return string HTML. Empty when the product is not a box priced by its contents.
	 */
	public static function product_price_html( $product ): string {
		if ( ! $product instanceof \WC_Product ) {
			return '';
		}

		$box  = self::sum_box( $product );
		$from = $box ? BoxPricing::from_price( $box ) : 0.0;

		if ( $from <= 0 ) {
			return '';
		}

		/* translators: %s: the lowest price the box can cost, as HTML. */
		$html = sprintf( esc_html__( 'From %s', 'subscription-pro' ), wc_price( $from ) );

		$cadence = self::cadence( self::parent_id( $product ) );

		return '' === $cadence ? $html : $html . ' <span class="wpsubs-subscription-timing">/ ' . esc_html( $cadence ) . '</span>';
	}

	/**
	 * The box a product sells, when it is priced by its contents.
	 *
	 * @param \WC_Product $product Product or variation.
	 *
	 * @return Box|null
	 */
	private static function sum_box( \WC_Product $product ): ?Box {
		$product_id = self::parent_id( $product );

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- which box to show, as the builder reads it.
		$asked = isset( $_GET['subscrpt_box_id'] ) ? absint( $_GET['subscrpt_box_id'] ) : 0;
		$box   = $asked ? BoxProduct::box_for( $product_id, $asked ) : null;
		$box   = $box ? $box : BoxProduct::primary_box( $product_id );

		return $box && BoxPricing::STRATEGY_SUM === $box->pricing()['strategy'] ? $box : null;
	}

	/**
	 * The product a variation belongs to, or the product itself.
	 *
	 * @param \WC_Product $product Product or variation.
	 *
	 * @return int
	 */
	private static function parent_id( \WC_Product $product ): int {
		return (int) ( $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id() );
	}

	/**
	 * The box discount a shopper gets before picking anything: the best tier
	 * that starts at zero.
	 *
	 * @param Box $box The box.
	 *
	 * @return array label (empty when none), percent (0 unless the tier is a percentage).
	 */
	private static function standing_discount( Box $box ): array {
		$none = [
			'label'   => '',
			'percent' => 0,
		];
		$best = null;

		foreach ( $box->pricing()['tiers'] as $tier ) {
			if ( $tier['threshold'] <= 0 && $tier['value'] > 0 && ( ! $best || $tier['value'] >= $best['value'] ) ) {
				$best = $tier;
			}
		}

		if ( ! $best ) {
			return $none;
		}

		if ( BoxPricing::TYPE_PERCENT === $best['type'] ) {
			return [
				/* translators: %s: discount percentage. */
				'label'   => sprintf( __( 'Save %s%%', 'subscription-pro' ), (string) ( 0 + $best['value'] ) ),
				'percent' => (int) round( $best['value'] ),
			];
		}

		return [
			/* translators: %s: discount amount. */
			'label'   => sprintf( __( 'Save %s', 'subscription-pro' ), html_entity_decode( wp_strip_all_tags( wc_price( $best['value'] ) ), ENT_QUOTES, 'UTF-8' ) ),
			'percent' => 0,
		];
	}

	/**
	 * The billing cadence of a product's first plan, as "month" or "2 weeks".
	 *
	 * @param int $product_id Product id.
	 *
	 * @return string Empty when the product has no plan.
	 */
	private static function cadence( int $product_id ): string {
		$rows = PlanRepository::resolve_for_product( $product_id );

		if ( empty( $rows ) ) {
			return '';
		}

		$freq = max( 1, (int) $rows[0]['billing_frequency'] );
		$unit = strtolower( PlanPresenter::interval_label( (int) $rows[0]['billing_interval'] ) );

		return ( 1 === $freq ? '' : $freq . ' ' ) . $unit . ( 1 === $freq ? '' : 's' );
	}
}
