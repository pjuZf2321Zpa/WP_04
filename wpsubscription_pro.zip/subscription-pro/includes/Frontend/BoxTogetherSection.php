<?php
/**
 * Frequently Bought Together on an item's page.
 *
 * An item that a box can hold is offered with what is usually bought with it,
 * as one subscription box: this item and the next ones in `BoxTogether`'s
 * order, pre-ticked, at the box's price. The form posts the classic add-to-cart
 * request to the product that sells the box, naming the seller's first
 * subscription plan, so the shopper buys a subscription and never a one-time
 * box. When the cart already holds that box, `handle_request()` puts the picks
 * into that line instead, so a box is never two lines.
 *
 * @package SpringDevs\SubscriptionPro\Frontend
 */

namespace SpringDevs\SubscriptionPro\Frontend;

use SpringDevs\Subscription\Admin\PlanPresenter;
use SpringDevs\Subscription\Illuminate\Plans\PlanRepository;
use SpringDevs\SubscriptionPro\Illuminate\Box\Box;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxCartService;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxOnceLabel;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxPricing;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxProduct;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxQuote;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxTogether;

defined( 'ABSPATH' ) || exit;

/**
 * The section, its shortcode, and the add that never makes a second box line.
 */
class BoxTogetherSection {

	/**
	 * Option choosing where on the page the section goes.
	 */
	const OPTION = 'subscrpt_box_together_position';

	/**
	 * Section above the product tabs.
	 */
	const BEFORE_TABS = 'before_tabs';

	/**
	 * Section below the product tabs.
	 */
	const AFTER_TABS = 'after_tabs';

	/**
	 * Nonce action of the form.
	 */
	const NONCE_ACTION = 'subscrpt_box_together';

	/**
	 * Result of `apply_add()` when the request is not the section's to handle.
	 */
	const STATUS_PASS = 'pass';

	/**
	 * How many further suggestions wait to be swapped in for ones the shopper unticks.
	 */
	const SPARES = 4;

	/**
	 * Products whose section their own page has printed.
	 *
	 * @var bool[]
	 */
	private $placed = [];

	/**
	 * The section the block's render callback asks.
	 *
	 * @var BoxTogetherSection|null
	 */
	private static $instance = null;

	/**
	 * Register hooks.
	 */
	public function __construct() {
		self::$instance = $this;

		add_action( 'woocommerce_after_single_product_summary', [ $this, 'render_on_page' ], self::priority() );
		add_action( 'wp_loaded', [ $this, 'handle_request' ], 15 );
		add_shortcode( 'subscrpt_box_together', [ $this, 'shortcode' ] );
		add_action( 'init', [ __CLASS__, 'register_block' ] );
		self::register_setting_hooks();
	}

	/**
	 * Hook the position setting and its field into the settings screen.
	 *
	 * The screen and the save run in the admin, where this section is not
	 * constructed, so `Admin` hooks them too. The callbacks are static, so
	 * WordPress takes a second registration of them as the same hook.
	 *
	 * @return void
	 */
	public static function register_setting_hooks(): void {
		add_action( 'subscrpt_register_settings', [ __CLASS__, 'register_settings' ] );
		add_filter( 'subscrpt_settings_fields', [ __CLASS__, 'add_settings_fields' ] );
	}

	/**
	 * Register the `subscription-pro/box-together` block.
	 *
	 * Dynamic: the editor script is hand-written, so there is no build. The
	 * editor only loads in the admin, where this section is not constructed, so
	 * `Admin` registers the block too. Whoever runs first registers it, and the
	 * render callback looks the section up when it is called, so the block
	 * renders the same on admin-ajax, where `Admin` is built first.
	 *
	 * @return void
	 */
	public static function register_block(): void {
		static $registered = false;

		if ( $registered ) {
			return;
		}

		$registered = true;
		$handle     = 'subscrpt_box_together_block_editor';

		wp_register_script(
			$handle,
			SUBSCRIPT_PRO_URL . '/assets/js/blocks/box-together.js',
			[ 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-server-side-render', 'wp-i18n' ],
			SUBSCRIPT_PRO_VERSION,
			true
		);
		wp_set_script_translations( $handle, 'subscription-pro' );

		// The editor canvas asks for the block's style before the assets class has registered it.
		if ( ! wp_style_is( 'subscrpt_box_css', 'registered' ) ) {
			wp_register_style( 'subscrpt_box_css', SUBSCRIPT_PRO_ASSETS . '/css/box.css', [], SUBSCRIPT_PRO_VERSION );
		}

		register_block_type(
			SUBSCRIPT_PRO_PATH . '/assets/blocks/box-together',
			[
				'editor_script'   => $handle,
				'style'           => 'subscrpt_box_css',
				'render_callback' => static function ( $attributes = [] ): string {
					return self::$instance ? self::$instance->render_block( $attributes ) : '';
				},
			]
		);
	}

	/**
	 * The block's front end: the shortcode's render, for the `product` attribute.
	 *
	 * @param array|string $attributes Block attributes; `product` defaults to the product being viewed.
	 *
	 * @return string
	 */
	public function render_block( $attributes = [] ): string {
		$attributes = is_array( $attributes ) ? $attributes : [];

		return $this->shortcode( [ 'product' => isset( $attributes['product'] ) ? absint( $attributes['product'] ) : 0 ] );
	}

	/**
	 * Whether a render is the product's own page printing its main content.
	 *
	 * Only then does a section count as printed: an excerpt, a loop or SEO meta
	 * running the content for the same product must not take the page's own.
	 *
	 * @param int $product_id Product id.
	 *
	 * @return bool
	 */
	private function is_own_page( int $product_id ): bool {
		return is_singular( 'product' ) && get_queried_object_id() === $product_id && in_the_loop();
	}

	/**
	 * Where the section hangs on `woocommerce_after_single_product_summary`.
	 *
	 * WooCommerce prints the product tabs at 10, so 5 is above them and 15
	 * below. Anything but the two known values is the default.
	 *
	 * @return int
	 */
	public static function priority(): int {
		return self::AFTER_TABS === self::position() ? 15 : 5;
	}

	/**
	 * The saved position, kept to the two known values.
	 *
	 * @return string
	 */
	private static function position(): string {
		return self::sanitize_position( get_option( self::OPTION, self::BEFORE_TABS ) );
	}

	/**
	 * Print the section for the product being viewed.
	 *
	 * @return void
	 */
	public function render_on_page(): void {
		global $product;

		if ( $product instanceof \WC_Product ) {
			echo $this->print_once( $product->get_id() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the template escapes.
		}
	}

	/**
	 * The shortcode: `[subscrpt_box_together product="ID"]`.
	 *
	 * @param array|string $atts Shortcode attributes; `product` defaults to the product being viewed.
	 *
	 * @return string
	 */
	public function shortcode( $atts = [] ): string {
		global $product;

		$atts       = is_array( $atts ) ? $atts : [];
		$product_id = isset( $atts['product'] ) ? absint( $atts['product'] ) : 0;

		if ( ! $product_id && $product instanceof \WC_Product ) {
			$product_id = $product->get_id();
		}

		return $product_id ? $this->print_once( $product_id ) : '';
	}

	/**
	 * The section, unless the product's own page has already printed it.
	 *
	 * A product's section is on its page once: the form is never there twice,
	 * whether the page, the shortcode or the block got there first.
	 *
	 * @param int $product_id The item being viewed.
	 *
	 * @return string
	 */
	private function print_once( int $product_id ): string {
		$own = $this->is_own_page( $product_id );

		if ( $own && ! empty( $this->placed[ $product_id ] ) ) {
			return '';
		}

		$html = $this->render( $product_id );

		if ( $own && $html ) {
			$this->placed[ $product_id ] = true;
		}

		return $html;
	}

	/**
	 * The section's HTML.
	 *
	 * @param int $product_id The item being viewed.
	 *
	 * @return string Empty when there is nothing to offer.
	 */
	public function render( int $product_id ): string {
		$together = $this->data( $product_id );

		if ( ! $together ) {
			return '';
		}

		wp_enqueue_style( 'subscrpt_box_css' );
		wp_enqueue_script( 'subscrpt_box_together_js' );

		ob_start();
		include SUBSCRIPT_PRO_PATH . '/templates/box/together.php';

		return (string) ob_get_clean();
	}

	/**
	 * What the section shows for an item.
	 *
	 * A box whose merchant switched Frequently Bought Together off offers
	 * nothing; this is the one place the page, the shortcode and the block all
	 * ask. When the item is in several boxes, the first one that can fill a
	 * section is used: `BoxProduct::boxes_containing()` lists them in the order they
	 * were connected, so that is the merchant's first.
	 *
	 * @param int $product_id The item being viewed.
	 *
	 * @return array|null Null when there is nothing worth offering.
	 */
	public function data( int $product_id ): ?array {
		$product = wc_get_product( $product_id );

		if ( ! $product instanceof \WC_Product || ! $product->is_type( 'simple' ) || BoxProduct::is_box( $product ) ) {
			return null;
		}

		foreach ( $this->boxes_containing( $product_id ) as $offer ) {
			if ( ! $offer['box']->show_together() ) {
				continue;
			}

			$together = $this->offer_data( $product_id, $offer );

			if ( $together ) {
				return $together;
			}
		}

		return null;
	}

	/**
	 * Put the picks into the box the cart already holds, instead of a new line.
	 *
	 * Only a posted section form, only when the cart has a line for that box;
	 * anything else is WooCommerce's. Nothing here redirects, which is what
	 * lets a test call it; `handle_request()` does that.
	 *
	 * @return array{status:string,message:string} `pass`, or the service's status with the sentence to show.
	 */
	public function apply_add(): array {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- the marker only selects this path; the nonce is checked below.
		if ( empty( $_POST['subscrpt_box_together'] ) ) {
			return $this->result( self::STATUS_PASS );
		}

		$box_id = isset( $_POST['subscrpt_box_id'] ) ? absint( $_POST['subscrpt_box_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$key    = $box_id ? BoxCartService::find_box_line( $box_id ) : '';

		if ( '' === $key ) {
			return $this->result( self::STATUS_PASS );
		}

		$nonce = isset( $_POST['subscrpt_box_together_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['subscrpt_box_together_nonce'] ) ) : '';

		if ( ! $nonce || ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) ) {
			return $this->result( BoxCartService::STATUS_INVALID, __( 'Your box could not be updated. Please try again.', 'subscription-pro' ) );
		}

		$items = $this->posted_items();

		if ( ! $items ) {
			return $this->result( BoxCartService::STATUS_INVALID, __( 'Nothing was selected.', 'subscription-pro' ) );
		}

		$result = BoxCartService::add_items( $key, $items );

		if ( BoxCartService::STATUS_NEEDS_REPLACE === $result['status'] ) {
			return $this->result(
				$result['status'],
				sprintf(
					/* translators: %s: link to the cart. */
					__( 'Your box is full, so nothing was added. %s to choose what to swap.', 'subscription-pro' ),
					'<a href="' . esc_url( wc_get_cart_url() ) . '">' . esc_html__( 'Open your box in the cart', 'subscription-pro' ) . '</a>'
				)
			);
		}

		if ( BoxCartService::STATUS_OK !== $result['status'] ) {
			return $this->result( $result['status'], $result['message'] );
		}

		return $this->result(
			BoxCartService::STATUS_OK,
			$result['added']
				/* translators: %d: number of items added to the box. */
				? sprintf( _n( 'Added %d item to your box.', 'Added %d items to your box.', count( $result['added'] ), 'subscription-pro' ), count( $result['added'] ) )
				: __( 'Those items are already in your box.', 'subscription-pro' )
		);
	}

	/**
	 * Apply a posted section form to the box in the cart, say how it went, and go to the cart.
	 *
	 * Runs before WooCommerce's add-to-cart handler, which would otherwise read
	 * the same form and add the box as a second line.
	 *
	 * @return void
	 */
	public function handle_request(): void {
		$result = $this->apply_add();

		if ( self::STATUS_PASS === $result['status'] ) {
			return;
		}

		wc_add_notice( $result['message'], BoxCartService::STATUS_OK === $result['status'] ? 'success' : 'error' );
		wp_safe_redirect( wc_get_cart_url() );
		exit;
	}

	/**
	 * Register the position setting.
	 *
	 * @return void
	 */
	public static function register_settings(): void {
		register_setting(
			'wp_subscription_settings',
			self::OPTION,
			[
				'type'              => 'string',
				'sanitize_callback' => [ __CLASS__, 'sanitize_position' ],
			]
		);
	}

	/**
	 * Keep the position to a known value.
	 *
	 * @param mixed $value Posted value.
	 *
	 * @return string
	 */
	public static function sanitize_position( $value ): string {
		return self::AFTER_TABS === $value ? self::AFTER_TABS : self::BEFORE_TABS;
	}

	/**
	 * Add the position to the Product page group of the settings screen.
	 *
	 * @param array $settings_fields Settings fields.
	 *
	 * @return array
	 */
	public static function add_settings_fields( $settings_fields ) {
		$settings_fields[] = [
			'type'       => 'select',
			'group'      => 'product_page',
			'priority'   => 40,
			'field_data' => [
				'id'          => self::OPTION,
				'title'       => __( 'Frequently bought together', 'subscription-pro' ),
				'description' => __( 'Where the section sits on a product page that a box can hold. The [subscrpt_box_together] shortcode places it anywhere.', 'subscription-pro' ),
				'options'     => [
					self::BEFORE_TABS => __( 'Above the product tabs', 'subscription-pro' ),
					self::AFTER_TABS  => __( 'Below the product tabs', 'subscription-pro' ),
				],
				'selected'    => self::position(),
			],
		];

		return $settings_fields;
	}

	/**
	 * The boxes that can hold a product, as Task 40 answers it.
	 *
	 * Protected so a test can say what holds it.
	 *
	 * @param int $product_id Product id.
	 *
	 * @return array[]
	 */
	protected function boxes_containing( int $product_id ): array {
		return BoxProduct::boxes_containing( $product_id );
	}

	/**
	 * The section for one box that holds the item, or null when it cannot fill one.
	 *
	 * @param int   $product_id The item being viewed.
	 * @param array $offer      One row of `BoxProduct::boxes_containing()`.
	 *
	 * @return array|null
	 */
	private function offer_data( int $product_id, array $offer ): ?array {
		$box    = $offer['box'];
		$seller = wc_get_product( (int) $offer['product_id'] );
		$plan   = $this->first_plan( (int) $offer['product_id'] );

		// A variable seller needs a size the section cannot choose.
		if ( ! $seller instanceof \WC_Product || ! $seller->is_type( 'simple' ) || ! $seller->is_purchasable() || ! $plan ) {
			return null;
		}

		$count = BoxTogether::starting_count( $box );
		$ids   = BoxTogether::suggestions( $product_id, $box, self::SPARES );

		if ( ! $ids ) {
			return null;
		}

		$rows = [];

		foreach ( $ids as $id ) {
			$rows[] = [
				'product_id'   => $id,
				'variation_id' => 0,
				'qty'          => 1,
				'once'         => false,
			];
		}

		$items  = $this->tiles( array_slice( $rows, 0, $count ), $product_id, $box, true );
		$spares = $this->tiles( array_slice( $rows, $count ), $product_id, $box, false );
		$quoted = (int) $offer['product_id'];

		return array_merge(
			$this->price_data( $box, $quoted, $plan, array_slice( $rows, 0, $count ) ),
			[
				'box'        => $box,
				'seller'     => $seller,
				'plan_id'    => (int) $plan['plan_id'],
				'cadence'    => BoxOnceLabel::every( max( 1, (int) $plan['billing_frequency'] ), (int) $plan['billing_interval'] ),
				'items'      => $items,
				'spares'     => $spares,
				'quote_url'  => BoxPricing::STRATEGY_SUM === $box->pricing()['strategy'] ? $this->quote_url() : '',
				'cart_key'   => BoxCartService::find_box_line( $box->id() ),
				'action_url' => $seller->get_permalink(),
				'nonce'      => wp_create_nonce( self::NONCE_ACTION ),
			]
		);
	}

	/**
	 * What the section shows for each product.
	 *
	 * @param array $rows       Rows of `BoxProduct::normalise_items()`.
	 * @param int   $viewed     The item being viewed.
	 * @param Box   $box        The box.
	 * @param bool  $checked    Whether they start ticked.
	 *
	 * @return array[]
	 */
	private function tiles( array $rows, int $viewed, Box $box, bool $checked ): array {
		$tiles = [];

		foreach ( BoxCartService::with_thumbnails( $rows ) as $row ) {
			$item = wc_get_product( $row['product_id'] );

			$tiles[] = [
				'product_id' => $row['product_id'],
				'name'       => $item instanceof \WC_Product ? $item->get_name() : '',
				'thumbnail'  => $row['thumbnail'],
				'price_html' => wc_price( BoxPricing::item_price( $row['product_id'] ) ),
				'url'        => $item instanceof \WC_Product ? $item->get_permalink() : '',
				'checked'    => $checked,
				'current'    => $row['product_id'] === $viewed,
				'once_offer' => BoxOnceLabel::toggle_offered( $box, $row['product_id'] ),
			];
		}

		return $tiles;
	}

	/**
	 * Where the section asks what a different pick would cost.
	 *
	 * @return string
	 */
	private function quote_url(): string {
		return class_exists( 'WC_AJAX' ) ? \WC_AJAX::get_endpoint( BoxQuote::ACTION ) : add_query_arg( [ 'wc-ajax' => BoxQuote::ACTION ], home_url( '/' ) );
	}

	/**
	 * What the box costs with these items, and what it saves.
	 *
	 * A box priced by its contents is quoted the way the builder quotes it. A
	 * fixed box is its seller's plan price. A saving is only named when the
	 * quote has a discount in it.
	 *
	 * @param Box   $box       The box.
	 * @param int   $seller_id The product that sells it.
	 * @param array $plan      The plan row offered.
	 * @param array $rows      The items, as `BoxProduct::normalise_items()` rows.
	 *
	 * @return array price_html, regular_html and saving_html; each empty when there is nothing to say.
	 */
	private function price_data( Box $box, int $seller_id, array $plan, array $rows ): array {
		$none = [
			'price_html'   => '',
			'regular_html' => '',
			'saving_html'  => '',
		];

		if ( BoxPricing::STRATEGY_SUM !== $box->pricing()['strategy'] ) {
			$data = is_array( $plan['relation_data'] ) ? $plan['relation_data'] : [];

			$none['price_html'] = wc_price(
				(float) PlanPresenter::offer_price(
					isset( $data['regular_price'] ) ? (string) $data['regular_price'] : '',
					isset( $data['sale_price'] ) ? (string) $data['sale_price'] : '',
					isset( $data['discount_type'] ) ? (string) $data['discount_type'] : 'percentage',
					isset( $data['discount_value'] ) ? (string) $data['discount_value'] : '0'
				)
			);

			return $none;
		}

		$quote  = BoxQuote::respond( $seller_id, $box->id(), $rows, [], 0, (int) $plan['plan_id'] );
		$saving = (string) ( $quote['saving_html'] ?? '' );

		return [
			'price_html'   => (string) ( $quote['price_html'] ?? '' ),
			'regular_html' => '' !== $saving ? (string) ( $quote['regular_html'] ?? '' ) : '',
			'saving_html'  => $saving,
		];
	}

	/**
	 * The first plan the purchase card would offer: the first that is not an installment.
	 *
	 * @param int $seller_id The product that sells the box.
	 *
	 * @return array|null
	 */
	private function first_plan( int $seller_id ): ?array {
		foreach ( PlanRepository::resolve_for_product( $seller_id ) as $row ) {
			if ( 'installments' !== PlanRepository::type_to_string( (int) $row['group_type'] ) && ! empty( $row['plan_id'] ) ) {
				return $row;
			}
		}

		return null;
	}

	/**
	 * The ticked products of the form, one unit each, as cart service rows.
	 *
	 * @return array[]
	 */
	private function posted_items(): array {
		$items = [];

		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- verified by apply_add(); keys are cast to ids below.
		$raw = isset( $_POST['subscrpt_box_items'] ) && is_array( $_POST['subscrpt_box_items'] ) ? wp_unslash( $_POST['subscrpt_box_items'] ) : [];

		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- verified by apply_add(); only the keys are read, as ids.
		$once = isset( $_POST['subscrpt_box_once'] ) && is_array( $_POST['subscrpt_box_once'] ) ? array_map( 'absint', array_keys( wp_unslash( $_POST['subscrpt_box_once'] ) ) ) : [];

		foreach ( array_keys( $raw ) as $product_id ) {
			$product_id = absint( $product_id );

			if ( $product_id ) {
				$items[] = [
					'product_id'   => $product_id,
					'variation_id' => 0,
					'qty'          => 1,
					'once'         => in_array( $product_id, $once, true ),
				];
			}
		}

		return $items;
	}

	/**
	 * An `apply_add()` answer.
	 *
	 * @param string $status  Status.
	 * @param string $message Sentence to show.
	 *
	 * @return array{status:string,message:string}
	 */
	private function result( string $status, string $message = '' ): array {
		return [
			'status'  => $status,
			'message' => $message,
		];
	}
}
