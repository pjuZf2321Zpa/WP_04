<?php
/**
 * The "Add to a box" card on an item's page.
 *
 * Task 40 answers which boxes can hold a product; this puts the answer on the
 * page. The card is one more purchase option beside the item's own, rendered
 * by free as a generic card whose body is ours. An item with no plans has no
 * purchase options, so the same card renders on its own after the add-to-cart
 * button. A variation is an item of its own: its card shows only while it is
 * the chosen one. The button is a link to the box's page with the item named, so it
 * posts nothing and cannot change a normal add-to-cart of the item.
 *
 * @package SpringDevs\SubscriptionPro\Frontend
 */

namespace SpringDevs\SubscriptionPro\Frontend;

use SpringDevs\Subscription\Admin\PlanPresenter;
use SpringDevs\Subscription\Illuminate\Plans\PlanRepository;
use SpringDevs\SubscriptionPro\Illuminate\Box\Box;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxCart;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxCartService;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxOnceLabel;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxPricing;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxProduct;

defined( 'ABSPATH' ) || exit;

/**
 * Offers an item to the boxes that can hold it.
 */
class BoxAddCard {

	/**
	 * The purchase option type of the card.
	 */
	const TYPE = 'box_add';

	/**
	 * Products whose card already rendered on this request, by id, so the
	 * standalone card never repeats one a purchase option rendered.
	 *
	 * @var array<int, true>
	 */
	private $rendered_for = [];

	/**
	 * Register hooks.
	 */
	public function __construct() {
		add_filter( 'subscrpt_plan_selector_groups', [ $this, 'groups' ], 30, 3 );
		add_action( 'subscrpt_plan_card_body', [ $this, 'card_body' ], 10, 3 );
		add_action( 'woocommerce_after_add_to_cart_button', [ $this, 'render_standalone' ], 15 );
		add_filter( 'woocommerce_add_to_cart_validation', [ $this, 'validate' ], 10, 4 );
	}

	/**
	 * Append the card to the purchase options of an item that a box can hold.
	 *
	 * @param array       $groups  Groups built by free.
	 * @param \WC_Product $product Product or variation being rendered.
	 * @param string      $context 'page' or 'variation'.
	 *
	 * @return array
	 */
	public function groups( $groups, $product = null, $context = 'page' ) {
		if ( ! is_array( $groups ) || ! in_array( $context, [ 'page', 'variation' ], true ) ) {
			return $groups;
		}

		$group = $product instanceof \WC_Product ? $this->group_for( $product ) : null;

		if ( $group ) {
			$groups[] = $group;
		}

		return $groups;
	}

	/**
	 * Render the card's body: the sentence and the way into each box.
	 *
	 * @param array       $group   The plan group the body belongs to.
	 * @param \WC_Product $product Product, or the variation.
	 * @param string      $context 'page' or 'variation'.
	 *
	 * @return void
	 */
	public function card_body( $group, $product, $context ): void {
		unset( $context );

		if ( ! is_array( $group ) || self::TYPE !== ( $group['type'] ?? '' ) || ! $product instanceof \WC_Product ) {
			return;
		}

		$this->rendered_for[ $product->get_id() ] = true;

		wp_enqueue_style( 'subscrpt_box_css' );
		$this->enqueue_scripts( $group );

		$standalone = false;

		include SUBSCRIPT_PRO_PATH . '/templates/box/add-card.php';
	}

	/**
	 * The card's scripts: the purchase option's switch, the button that adds in
	 * place, and the subscriber's next-box choice when the card has one.
	 *
	 * @param array $group The card's group.
	 *
	 * @return void
	 */
	private function enqueue_scripts( array $group ): void {
		wp_enqueue_script( 'subscrpt_box_add_card_js' );
		wp_enqueue_script( 'subscrpt_box_add_js' );

		if ( ! empty( $group['next'] ) ) {
			wp_enqueue_script( BoxNextAdd::SCRIPT_HANDLE );
		}
	}

	/**
	 * Render the card on its own for an item with no purchase options.
	 *
	 * @return void
	 */
	public function render_standalone(): void {
		global $product;

		if ( ! $product instanceof \WC_Product || isset( $this->rendered_for[ $product->get_id() ] ) ) {
			return;
		}

		if ( $product->is_type( 'variable' ) ) {
			$this->render_variations( $product );
			return;
		}

		$group = $this->group_for( $product );

		if ( ! $group ) {
			return;
		}

		$this->rendered_for[ $product->get_id() ] = true;

		wp_enqueue_style( 'subscrpt_box_css' );
		$this->enqueue_scripts( $group );

		$standalone = true;

		include SUBSCRIPT_PRO_PATH . '/templates/box/add-card.php';
	}

	/**
	 * Render a hidden card for each variation a box can hold.
	 *
	 * The script box-add-card.js shows the chosen variation's card, unless
	 * its purchase options already hold one. Rendered on the page for every
	 * such variation, because above WooCommerce's variation threshold the
	 * variation data loads later, where nothing can be enqueued.
	 *
	 * @param \WC_Product $parent The variable product being viewed.
	 *
	 * @return void
	 */
	private function render_variations( \WC_Product $parent ): void {
		if ( BoxProduct::is_box( $parent ) ) {
			return;
		}

		$this->rendered_for[ $parent->get_id() ] = true;

		foreach ( $parent->get_children() as $child_id ) {
			$product = wc_get_product( $child_id );
			$group   = $product instanceof \WC_Product ? $this->group_for( $product ) : null;

			if ( ! $group ) {
				continue;
			}

			wp_enqueue_style( 'subscrpt_box_css' );
			$this->enqueue_scripts( $group );

			$standalone   = true;
			$variation_id = $product->get_id();

			include SUBSCRIPT_PRO_PATH . '/templates/box/add-card.php';
		}
	}

	/**
	 * Refuse an add-to-cart whose chosen option is the box card.
	 *
	 * The card is a way into a box, not something to buy, so the item's own
	 * button cannot add the item alone while it is chosen. The script hides that
	 * button; this is for a form posted any other way.
	 *
	 * @param bool $passed       Whether the add is allowed so far.
	 * @param int  $product_id   Product being added.
	 * @param int  $quantity     Quantity being added.
	 * @param int  $variation_id Variation being added, 0 for none.
	 *
	 * @return bool
	 */
	public function validate( $passed, $product_id = 0, $quantity = 1, $variation_id = 0 ) {
		unset( $quantity );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.NonceVerification.Recommended -- WooCommerce verifies the add-to-cart request; this only reads which option was chosen.
		$group = isset( $_REQUEST['subscrpt_plan_group'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['subscrpt_plan_group'] ) ) : '';

		if ( ! $passed || self::TYPE !== $group ) {
			return $passed;
		}

		$item   = (int) $variation_id ? (int) $variation_id : (int) $product_id;
		$offers = $this->boxes_containing( $item );
		$link   = 1 === count( $offers ) ? $this->pick_url( $offers[0], $item ) : '';

		if ( '' !== $link ) {
			wc_add_notice(
				sprintf(
					/* translators: %s: link to the box. */
					__( 'This item is added through a box. %s', 'subscription-pro' ),
					'<a href="' . esc_url( $link ) . '">' . esc_html__( 'Add it to the box', 'subscription-pro' ) . '</a>'
				),
				'error'
			);
		} else {
			wc_add_notice( __( 'This item is added through a box. Choose a box with the Add to a box button.', 'subscription-pro' ), 'error' );
		}

		return false;
	}

	/**
	 * The link that opens a box's page with this item already in it.
	 *
	 * @param array $offer      One row of `BoxProduct::boxes_containing()`.
	 * @param int   $product_id The item.
	 * @param bool  $once       Whether the box's page should open with it ticked once.
	 *
	 * @return string
	 */
	public function pick_url( array $offer, int $product_id, bool $once = false ): string {
		$seller = wc_get_product( (int) $offer['product_id'] );

		if ( ! $seller instanceof \WC_Product ) {
			return '';
		}

		$args = [
			'subscrpt_box_id'   => $offer['box']->id(),
			'subscrpt_box_pick' => $product_id,
		];

		if ( $once ) {
			$args['subscrpt_box_pick_once'] = 1;
		}

		return add_query_arg( $args, $seller->get_permalink() );
	}

	/**
	 * The boxes that can hold a product, as Task 40 answers it.
	 *
	 * Protected so a test can say what holds it. The answer may be a day old;
	 * the cart validates the item again when it is added.
	 *
	 * @param int $product_id Product id.
	 *
	 * @return array[]
	 */
	protected function boxes_containing( int $product_id ): array {
		return BoxProduct::boxes_containing( $product_id );
	}

	/**
	 * The card for a product, or null when it has none to offer.
	 *
	 * A box is never an item of another box. A simple product or one variation
	 * can be an item; a variable product is offered through its variations, and
	 * a grouped or external one is not offered.
	 *
	 * @param \WC_Product $product Product being viewed, or the variation.
	 *
	 * @return array|null
	 */
	private function group_for( \WC_Product $product ): ?array {
		if ( ! $product->is_type( [ 'simple', 'variation' ] ) || BoxProduct::is_box( $product ) ) {
			return null;
		}

		$product_id = $product->get_id();
		$offers     = $this->boxes_containing( $product_id );

		if ( ! $offers ) {
			return null;
		}

		$sellers = array_count_values( array_column( $offers, 'product_id' ) );
		$boxes   = [];

		foreach ( $offers as $offer ) {
			$seller = wc_get_product( (int) $offer['product_id'] );

			if ( ! $seller instanceof \WC_Product ) {
				continue;
			}

			// The page the shopper lands on is the seller's, so that is the name
			// they know; two boxes on one page are told apart by the box's own.
			$name = $seller->get_name();

			if ( $sellers[ $offer['product_id'] ] > 1 ) {
				/* translators: 1: product name, 2: box name. */
				$name = sprintf( __( '%1$s — %2$s', 'subscription-pro' ), $name, $offer['box']->title() );
			}

			$cart_key = BoxCartService::find_box_line( (int) $offer['box']->id() );

			$boxes[] = [
				'box_id'     => $offer['box']->id(),
				'name'       => $name,
				'from'       => $this->from_label( $offer['box'], (int) $offer['product_id'] ),
				'url'        => $this->pick_url( $offer, $product_id ),
				// The choice between every cycle and once, only where the item allows it and the box has room.
				'once_offer' => BoxOnceLabel::toggle_offered( $offer['box'], $product_id ) && ! $this->is_one_time_line( $cart_key ),
				'every'      => $this->every_label( (int) $offer['product_id'] ),
				// The line this button would change; the key changes on every edit, so the script keeps its own after the first.
				'cart_key'   => $cart_key,
			];
		}

		if ( ! $boxes ) {
			return null;
		}

		return [
			'id'               => self::TYPE,
			'type'             => self::TYPE,
			'label'            => __( 'Add to a box', 'subscription-pro' ),
			'sub_label'        => $this->sub_label( $boxes ),
			'boxes'            => $boxes,
			// The subscriber's live boxes that may take it next time (Task 43).
			'next'             => BoxNextAdd::subscriptions_for( get_current_user_id(), $product_id ),
			'product_id'       => $product_id,
			'price'            => '',
			'old_price'        => '',
			'terms'            => [],
			'terms_heading'    => '',
			'badge'            => '',
			'discount_percent' => 0,
		];
	}

	/**
	 * Whether a box line in the cart was bought once, so everything in it ships once.
	 *
	 * @param string $cart_key Cart item key, empty for none.
	 *
	 * @return bool
	 */
	private function is_one_time_line( string $cart_key ): bool {
		$cart = '' !== $cart_key && function_exists( 'WC' ) ? WC()->cart : null;
		$line = is_object( $cart ) ? $cart->get_cart_item( $cart_key ) : null;

		return is_array( $line ) && ! empty( $line[ BoxCart::CART_KEY ]['one_time'] );
	}

	/**
	 * "every month", from the plans the box is sold on.
	 *
	 * @param int $seller The product that sells the box.
	 *
	 * @return string Empty when its plans do not agree on one cadence.
	 */
	private function every_label( int $seller ): string {
		$interval = BoxOnceLabel::interval_for( $seller );

		return $interval ? BoxOnceLabel::every( $interval[0], $interval[1] ) : '';
	}

	/**
	 * The sentence under the card's label.
	 *
	 * @param array[] $boxes The card's boxes.
	 *
	 * @return string
	 */
	private function sub_label( array $boxes ): string {
		if ( count( $boxes ) > 1 ) {
			/* translators: %d: number of boxes the item can go in. */
			return sprintf( _n( 'Pick it in %d box', 'Pick it in one of %d boxes', count( $boxes ), 'subscription-pro' ), count( $boxes ) );
		}

		if ( '' === $boxes[0]['from'] ) {
			/* translators: %s: box name. */
			return sprintf( __( 'Pick it in the %s', 'subscription-pro' ), $boxes[0]['name'] );
		}

		/* translators: 1: box name, 2: what it costs, e.g. "from $24.00 / month". */
		return sprintf( __( 'Pick it in the %1$s, %2$s', 'subscription-pro' ), $boxes[0]['name'], $boxes[0]['from'] );
	}

	/**
	 * What a box costs, as "from $24.00 / month".
	 *
	 * A box priced by its contents says its cheapest packing; a fixed box says
	 * its seller's cheapest subscription plan (installments cannot hold a box).
	 * The cadence is named only when every one of those plans bills on the same
	 * one, since a box sold every month and every two weeks has no single one.
	 *
	 * @param Box $box    The box.
	 * @param int $seller The product that sells it.
	 *
	 * @return string Empty when no price can be said.
	 */
	private function from_label( Box $box, int $seller ): string {
		$prices   = [];
		$cadences = [];

		foreach ( PlanRepository::resolve_for_product( $seller ) as $row ) {
			if ( 'installments' === PlanRepository::type_to_string( (int) $row['group_type'] ) ) {
				continue;
			}

			$data     = is_array( $row['relation_data'] ) ? $row['relation_data'] : [];
			$prices[] = (float) PlanPresenter::offer_price(
				isset( $data['regular_price'] ) ? (string) $data['regular_price'] : '',
				isset( $data['sale_price'] ) ? (string) $data['sale_price'] : '',
				isset( $data['discount_type'] ) ? (string) $data['discount_type'] : 'percentage',
				isset( $data['discount_value'] ) ? (string) $data['discount_value'] : '0'
			);

			$freq = max( 1, (int) $row['billing_frequency'] );
			$unit = (int) $row['billing_interval'];

			$cadences[ $freq . '-' . $unit ] = BoxOnceLabel::cadence( $freq, $unit );
		}

		$amount = BoxPricing::STRATEGY_SUM === $box->pricing()['strategy']
			? BoxPricing::from_price( $box )
			: ( $prices ? min( $prices ) : 0.0 );

		if ( $amount <= 0 ) {
			return '';
		}

		$text = sprintf(
			/* translators: %s: the lowest price the box can cost. */
			__( 'from %s', 'subscription-pro' ),
			html_entity_decode( wp_strip_all_tags( wc_price( $amount ) ), ENT_QUOTES, 'UTF-8' )
		);

		/* translators: 1: "from $24.00", 2: how often it bills, e.g. "month" or "2 weeks". */
		return 1 === count( $cadences ) ? sprintf( __( '%1$s / %2$s', 'subscription-pro' ), $text, reset( $cadences ) ) : $text;
	}
}
