<?php
/**
 * "Add to your next box": a subscriber adds an item to a live box from the item's page.
 *
 * @package SpringDevs\SubscriptionPro\Frontend
 */

namespace SpringDevs\SubscriptionPro\Frontend;

use SpringDevs\Subscription\Illuminate\Subscription\Subscription;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxCart;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxCartService;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxOnceLabel;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxPricing;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxProduct;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxSubscription;

defined( 'ABSPATH' ) || exit;

/**
 * Which live boxes may take an item, and the endpoint that puts it in.
 *
 * The endpoint answers in `BoxCartService`'s shape, so the replace prompt reads
 * a live box exactly as it reads the cart's: `status` ok, needs_replace or
 * invalid, `added`, `skipped`, `incoming`, `current`, `message`, and `max` with
 * needs_replace. There is no cart line, so `cart_key` is always '' and
 * `subscription_id` names the box instead; `code` carries the refusal's error
 * code, '' when there is none.
 *
 * POST `nonce`, `mode` (add|set), `subscription_id`, `items` (JSON rows of
 * product_id, variation_id, qty and, for an item that ships in the next box
 * only, `once`). 403 for a bad nonce or a subscription that is
 * not the current user's, 400 for an unknown mode, 200 for everything else.
 * `add` adds what is not already there and asks when the box would overflow;
 * `set` saves the rows as the whole box, which is how the prompt's answer
 * arrives. Both save through `BoxSubscription::update_contents()` as the
 * customer, so the box's rules, the lock and the price deal all hold.
 */
class BoxNextAdd {

	/**
	 * Nonce action of the endpoint.
	 */
	const NONCE_ACTION = 'subscrpt_box_next_add';

	/**
	 * The `wc-ajax` endpoint name.
	 */
	const AJAX_ENDPOINT = 'subscrpt_box_next_add';

	/**
	 * Script handle of the choice on the card.
	 */
	const SCRIPT_HANDLE = 'subscrpt_box_next_add_js';

	/**
	 * Register hooks.
	 */
	public function __construct() {
		add_action( 'wc_ajax_' . self::AJAX_ENDPOINT, [ __CLASS__, 'endpoint' ] );
		add_action( 'wc_ajax_nopriv_' . self::AJAX_ENDPOINT, [ __CLASS__, 'endpoint' ] );
	}

	/**
	 * The user's live boxes that may take a product next time, for the card.
	 *
	 * @param int $user_id    User; 0 for a guest, who has none.
	 * @param int $product_id The item.
	 *
	 * @return array[] Rows of subscription_id, name, lock (timestamp) and url.
	 */
	public static function subscriptions_for( int $user_id, int $product_id ): array {
		if ( ! $user_id || ! $product_id ) {
			return [];
		}

		$ids = get_posts(
			[
				'post_type'      => 'subscrpt_order',
				'post_status'    => 'active',
				'author'         => $user_id,
				'fields'         => 'ids',
				'posts_per_page' => 50,
			]
		);

		$rows = [];

		foreach ( (array) $ids as $id ) {
			$id = (int) $id;

			if ( ! self::offered( $id, $product_id ) ) {
				continue;
			}

			$seller = wc_get_product( (int) get_post_meta( $id, '_subscrpt_product_id', true ) );
			$box    = BoxSubscription::box( $id );

			$rows[] = [
				'subscription_id' => $id,
				'name'            => $seller instanceof \WC_Product ? $seller->get_name() : ( $box ? $box->title() : '' ),
				'lock'            => BoxSubscription::lock_timestamp( $id ),
				'url'             => self::account_url( $id ),
				// The choice between every cycle and the next box only, where the item allows one-time and the box has room.
				'once_offer'      => self::once_offered( $id, $product_id ),
				'every'           => self::every_label( $id ),
			];
		}

		return $rows;
	}

	/**
	 * May this subscription be offered the item?
	 *
	 * Not a box the customer cannot change now, nor one priced at a fixed amount
	 * (an add would ship more for the agreed price), nor one whose gateway holds
	 * the schedule.
	 *
	 * @param int $subscription_id Subscription id.
	 * @param int $product_id      The item.
	 *
	 * @return bool
	 */
	private static function offered( int $subscription_id, int $product_id ): bool {
		if ( 'active' !== get_post_status( $subscription_id ) || ! BoxSubscription::is_box( $subscription_id ) ) {
			return false;
		}

		if ( ! BoxSubscription::can_edit( $subscription_id ) || BoxSubscription::is_gateway_scheduled( $subscription_id ) ) {
			return false;
		}

		if ( BoxPricing::STRATEGY_SUM !== BoxSubscription::pricing( $subscription_id )['strategy'] ) {
			return false;
		}

		return in_array( $product_id, array_map( 'intval', BoxSubscription::allowed_products( $subscription_id ) ), true );
	}

	/**
	 * Does the live box have room for this item to ship in the next box only?
	 *
	 * Where the builder offers the same choice: the item allows a one-time
	 * purchase and the box's maximum leaves room beyond its minimum.
	 *
	 * @param int $subscription_id Subscription id.
	 * @param int $product_id      The item.
	 *
	 * @return bool
	 */
	public static function once_offered( int $subscription_id, int $product_id ): bool {
		$rules = BoxSubscription::rules( $subscription_id );

		return BoxCart::allows_one_time( $product_id, 0 )
			&& BoxOnceLabel::has_room_for( (int) ( $rules['min'] ?? 0 ), (int) ( $rules['max'] ?? 0 ) );
	}

	/**
	 * "every month": how often the subscription's box ships, for the choice's first option.
	 *
	 * @param int $subscription_id Subscription id.
	 *
	 * @return string Empty when there is no one cadence to name.
	 */
	public static function every_label( int $subscription_id ): string {
		$interval = BoxOnceLabel::interval_for(
			(int) get_post_meta( $subscription_id, '_subscrpt_product_id', true ),
			(int) get_post_meta( $subscription_id, '_subscrpt_plan_id', true )
		);

		return $interval ? BoxOnceLabel::every( $interval[0], $interval[1] ) : '';
	}

	/**
	 * Where the subscription's box is shown and changed in My Account.
	 *
	 * @param int $subscription_id Subscription id.
	 *
	 * @return string
	 */
	private static function account_url( int $subscription_id ): string {
		if ( ! function_exists( 'wc_get_endpoint_url' ) || ! class_exists( Subscription::class ) ) {
			return '';
		}

		return wc_get_endpoint_url( Subscription::get_user_endpoint( 'view_subs' ), (string) $subscription_id, wc_get_page_permalink( 'myaccount' ) );
	}

	/**
	 * The `wc-ajax` endpoint.
	 *
	 * @return void
	 */
	public static function endpoint(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified just below, from this same array.
		$request = wp_unslash( $_POST );
		$nonce   = isset( $request['nonce'] ) && is_string( $request['nonce'] ) ? sanitize_text_field( $request['nonce'] ) : '';
		$id      = isset( $request['subscription_id'] ) ? absint( $request['subscription_id'] ) : 0;

		if ( ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) ) {
			wp_send_json( self::refusal( $id, __( 'Your session has expired. Reload the page and try again.', 'subscription-pro' ) ), 403 );
		}

		$user = get_current_user_id();

		if ( ! $user || ! $id || (int) get_post_field( 'post_author', $id ) !== $user ) {
			wp_send_json( self::refusal( $id, __( 'That subscription is not yours.', 'subscription-pro' ) ), 403 );
		}

		$mode  = isset( $request['mode'] ) && is_string( $request['mode'] ) ? sanitize_text_field( $request['mode'] ) : '';
		$items = self::clean_items( $request['items'] ?? [] );

		if ( 'add' === $mode ) {
			wp_send_json( self::add( $id, $items ) );
		}

		if ( 'set' === $mode ) {
			wp_send_json( self::set( $id, $items ) );
		}

		wp_send_json( self::refusal( $id, __( 'That is not something a box can do.', 'subscription-pro' ) ), 400 );
	}

	/**
	 * Add items to the next box, asking first when it would overflow.
	 *
	 * @param int     $subscription_id Subscription id.
	 * @param array[] $items           Clean rows.
	 *
	 * @return array
	 */
	private static function add( int $subscription_id, array $items ): array {
		$stop = self::stop( $subscription_id );

		if ( $stop ) {
			return $stop;
		}

		$result  = self::refusal( $subscription_id, '' );
		$current = BoxSubscription::contents( $subscription_id );
		$present = [];

		// A once row and an every-cycle row of one product are different rows.
		foreach ( $current as $row ) {
			$present[ self::row_key( $row ) ] = true;
		}

		foreach ( BoxProduct::normalise_items( $items ) as $item ) {
			if ( isset( $present[ self::row_key( $item ) ] ) ) {
				$result['skipped'][] = $item;
			} else {
				$result['incoming'][] = $item;
			}
		}

		$result['incoming'] = BoxProduct::describe_items( $result['incoming'] );
		$result['current']  = BoxProduct::describe_items( $current );

		if ( ! $result['incoming'] ) {
			$result['status'] = BoxCartService::STATUS_OK;

			return $result;
		}

		$merged = array_merge( $current, $result['incoming'] );
		$max    = (int) ( BoxSubscription::rules( $subscription_id )['max'] ?? 0 );

		// Only an item the box can take is worth asking about.
		$allowed = array_map( 'intval', BoxSubscription::allowed_products( $subscription_id ) );

		foreach ( $result['incoming'] as $item ) {
			if ( ! in_array( $item['product_id'], $allowed, true ) ) {
				$result['message'] = sprintf(
					/* translators: %s: product name. */
					__( '%s is not available in this box.', 'subscription-pro' ),
					$item['name'] ? $item['name'] : __( 'That product', 'subscription-pro' )
				);
				$result['code'] = 'subscrpt_box_not_allowed';

				return $result;
			}
		}

		if ( $max > 0 && BoxProduct::count_units( $merged ) > $max ) {
			$result['incoming'] = BoxCartService::with_thumbnails( $result['incoming'] );
			$result['current']  = BoxCartService::with_thumbnails( $result['current'] );
			$result['max']      = $max;
			$result['status']   = BoxCartService::STATUS_NEEDS_REPLACE;
			$result['message']  = __( 'Your box is full. Choosing these items replaces what is in it now.', 'subscription-pro' );

			return $result;
		}

		$saved = BoxSubscription::update_contents( $subscription_id, $merged, 'customer' );

		if ( is_wp_error( $saved ) ) {
			$result['message'] = $saved->get_error_message();
			$result['code']    = $saved->get_error_code();

			return $result;
		}

		$result['added']  = $result['incoming'];
		$result['status'] = BoxCartService::STATUS_OK;

		return $result;
	}

	/**
	 * What makes a row the same row: product, variation and whether it ships once.
	 *
	 * @param array $row A normalised row.
	 *
	 * @return string
	 */
	private static function row_key( array $row ): string {
		return $row['product_id'] . ':' . $row['variation_id'] . ':' . ( ! empty( $row['once'] ) ? '1' : '0' );
	}

	/**
	 * Save the rows as the whole next box.
	 *
	 * @param int     $subscription_id Subscription id.
	 * @param array[] $items           Clean rows.
	 *
	 * @return array
	 */
	private static function set( int $subscription_id, array $items ): array {
		$stop = self::stop( $subscription_id );

		if ( $stop ) {
			return $stop;
		}

		$result = self::refusal( $subscription_id, '' );

		if ( ! BoxProduct::normalise_items( $items ) ) {
			$result['message'] = __( 'Choose what goes in your box.', 'subscription-pro' );

			return $result;
		}

		$saved = BoxSubscription::update_contents( $subscription_id, $items, 'customer' );

		if ( is_wp_error( $saved ) ) {
			$result['message'] = $saved->get_error_message();
			$result['code']    = $saved->get_error_code();

			return $result;
		}

		$result['status']  = BoxCartService::STATUS_OK;
		$result['current'] = BoxProduct::describe_items( BoxSubscription::contents( $subscription_id ) );

		return $result;
	}

	/**
	 * The answer when the box cannot be changed now, whatever is picked.
	 *
	 * The lock is checked here rather than left to `update_contents()` so the
	 * refusal can say when it locked.
	 *
	 * @param int $subscription_id Subscription id.
	 *
	 * @return array|null Null when the box may be changed.
	 */
	private static function stop( int $subscription_id ): ?array {
		if ( ! BoxSubscription::is_box( $subscription_id ) ) {
			return self::refusal( $subscription_id, __( 'This subscription is not a box.', 'subscription-pro' ), 'subscrpt_box_not_a_box' );
		}

		if ( 'active' !== get_post_status( $subscription_id ) ) {
			return self::refusal( $subscription_id, __( 'This subscription is not active, so its next box cannot be changed.', 'subscription-pro' ), 'subscrpt_box_not_active' );
		}

		$refusal = BoxSubscription::customer_refusal( $subscription_id );

		if ( ! $refusal ) {
			return null;
		}

		if ( 'subscrpt_box_locked' === $refusal->get_error_code() ) {
			return self::refusal(
				$subscription_id,
				sprintf(
					/* translators: %s: the date the next box locked. */
					__( 'Your next box locked on %s and is being packed, so it can no longer be changed.', 'subscription-pro' ),
					date_i18n( get_option( 'date_format' ), BoxSubscription::lock_timestamp( $subscription_id ) )
				),
				'subscrpt_box_locked'
			);
		}

		return self::refusal( $subscription_id, $refusal->get_error_message(), $refusal->get_error_code() );
	}

	/**
	 * An answer in the cart service's shape, refusing until a step says otherwise.
	 *
	 * @param int    $subscription_id Subscription id.
	 * @param string $message         Why.
	 * @param string $code            Error code, '' when there is none.
	 *
	 * @return array
	 */
	private static function refusal( int $subscription_id, string $message, string $code = '' ): array {
		return [
			'status'          => BoxCartService::STATUS_INVALID,
			'cart_key'        => '',
			'subscription_id' => $subscription_id,
			'added'           => [],
			'skipped'         => [],
			'incoming'        => [],
			'current'         => [],
			'message'         => $message,
			'code'            => $code,
		];
	}

	/**
	 * Items as whole numbers, from an array or a JSON string.
	 *
	 * @param mixed $raw Raw items.
	 *
	 * @return array[] Rows of product_id, variation_id, qty and once.
	 */
	private static function clean_items( $raw ): array {
		if ( is_string( $raw ) ) {
			$raw = json_decode( $raw, true );
		}

		if ( ! is_array( $raw ) ) {
			return [];
		}

		$items = [];

		foreach ( $raw as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			$items[] = [
				'product_id'   => absint( $item['product_id'] ?? 0 ),
				'variation_id' => absint( $item['variation_id'] ?? 0 ),
				'qty'          => absint( $item['qty'] ?? 1 ),
				'once'         => in_array( $item['once'] ?? false, [ true, 1, '1', 'true', 'yes', 'on' ], true ),
			];
		}

		return $items;
	}
}
