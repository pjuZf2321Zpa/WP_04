<?php
/**
 * Trial and signup-fee text on a storefront plan term.
 *
 * Free builds the plan selector; pro adds what free's term note leaves out —
 * the free trial and the signup fee — through `subscrpt_plan_term`.
 *
 * @package SpringDevs\SubscriptionPro\Frontend
 */

namespace SpringDevs\SubscriptionPro\Frontend;

use SpringDevs\SubscriptionPro\Illuminate\Helper;

/**
 * Appends the trial and signup-fee text to a plan term's note.
 */
class PlanTermExtras {

	/**
	 * Register the term filter.
	 */
	public function __construct() {
		add_filter( 'subscrpt_plan_term', [ __CLASS__, 'add' ], 10, 4 );
	}

	/**
	 * Append the term's trial and signup-fee text to its note.
	 *
	 * @param array       $term     Term (id, label, price, note, discount_percent, badge).
	 * @param array       $row      The resolved plan row the term was built from.
	 * @param string      $type_key Plan type key.
	 * @param \WC_Product $product  Product or variation being rendered.
	 * @return array
	 */
	public static function add( $term, $row, $type_key, $product ) {
		if ( ! is_array( $term ) || ! is_array( $row ) ) {
			return $term;
		}

		$term['note'] = ( $term['note'] ?? '' ) . self::term_extras( $row, $type_key );

		return $term;
	}

	/**
	 * Free-trial and signup-fee suffix for a term note, shown as a muted second
	 * line under the price. Empty when the term has neither.
	 *
	 * @param array  $row      Resolved plan row.
	 * @param string $type_key Plan type key.
	 * @return string
	 */
	private static function term_extras( $row, $type_key ) {
		$parts = array();

		// Free trial (recurring / subscribe & save only; never with a signup fee).
		if ( Helper::plan_trial_applies( $row, $type_key ) ) {
			$count = (int) $row['free_trial'];
			$unit  = strtolower( (string) ( $row['plan_data']['free_trial_interval'] ?? 'day' ) );
			/* translators: 1: number, 2: interval (day/week/month/year). */
			$parts[] = sprintf( _n( '%1$d %2$s free trial', '%1$d %2$ss free trial', $count, 'subscription-pro' ), $count, $unit );
		}

		// One-off signup fee charged up front.
		if ( ! empty( $row['signup_fee'] ) && is_array( $row['signup_fee'] ) && ! empty( $row['signup_fee']['amount'] ) ) {
			/* translators: %s: signup fee amount. */
			$parts[] = sprintf( __( '%s signup fee', 'subscription-pro' ), self::price_text( (float) $row['signup_fee']['amount'] ) );
		}

		return $parts ? '<br><small class="subscrpt-term-extra">' . implode( ' · ', $parts ) . '</small>' : '';
	}

	/**
	 * Plain-text formatted price — currency symbol as a real character, not an
	 * HTML entity, so it reads cleanly in the note and its data attribute.
	 *
	 * @param float $amount Amount.
	 *
	 * @return string
	 */
	private static function price_text( $amount ) {
		return html_entity_decode( wp_strip_all_tags( wc_price( $amount ) ), ENT_QUOTES, 'UTF-8' );
	}
}
