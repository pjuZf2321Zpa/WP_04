<?php
/**
 * Storefront Plans selector.
 *
 * Renders the two-level plan selector (radio card per plan group + a One-Time
 * card; term chosen by a dropdown inside the card) on the single product page
 * from real plan data (PlanRepository resolver). Live on all product pages now
 * that the add-to-cart + billing path (R1–R4, M1–M2) is wired and verified.
 *
 * @package SpringDevs\SubscriptionPro\Frontend
 */

namespace SpringDevs\SubscriptionPro\Frontend;

use SpringDevs\Subscription\Illuminate\Plans\PlanRepository;
use SpringDevs\Subscription\Admin\PlanPresenter;
use SpringDevs\SubscriptionPro\Illuminate\Helper;

/**
 * Class Plans
 */
class Plans {

	/**
	 * Initialize the class.
	 */
	public function __construct() {
		add_action( 'woocommerce_before_add_to_cart_button', array( $this, 'render_selector' ), 5 );
		add_filter( 'woocommerce_available_variation', array( $this, 'push_plans' ), 10, 3 );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	/**
	 * Whether the plan selector should render on this request.
	 *
	 * @return bool
	 */
	private function should_render() {
		return function_exists( 'is_product' ) && is_product();
	}

	/**
	 * Whether a product actually offers a subscription on the storefront: tied to
	 * a plan AND subscription-enabled (for a variable product, at least one
	 * variation is enabled). Gates whether any plan UI renders at all.
	 *
	 * @param mixed $product Product object.
	 * @return bool
	 */
	private function product_has_plans( $product ) {
		return $product instanceof \WC_Product && Helper::plan_offered( $product->get_id(), 0 );
	}

	/**
	 * Enqueue selector assets only on product pages.
	 *
	 * @return void
	 */
	public function enqueue_assets() {
		if ( ! $this->should_render() ) {
			return;
		}

		// global $product is not set yet at wp_enqueue_scripts (populated later in
		// the loop), so resolve from the queried object instead.
		$product = wc_get_product( get_queried_object_id() );

		// Only load on product pages that actually expose plans (legacy products untouched).
		if ( ! $this->product_has_plans( $product ) ) {
			return;
		}

		// Selector styles, discount badge included, are shared with (and shipped
		// by) the free plugin. Pro adds no stylesheet of its own.
		wp_enqueue_style(
			'subscrpt_plans_selector_css',
			SUBSCRPT_ASSETS . '/css/frontend/plans.css',
			array(),
			defined( 'SUBSCRPT_VERSION' ) ? SUBSCRPT_VERSION : SUBSCRIPT_PRO_VERSION
		);

		wp_enqueue_script(
			'subscrpt_plans_selector_js',
			SUBSCRIPT_PRO_URL . '/assets/js/frontend/plans.js',
			array( 'jquery' ),
			SUBSCRIPT_PRO_VERSION,
			true
		);
	}

	/**
	 * Render the plan selector inside the add-to-cart form.
	 *
	 * @return void
	 */
	public function render_selector() {
		if ( ! $this->should_render() ) {
			return;
		}

		global $product;

		// Variable products render an empty container; JS rebuilds it from the
		// selected variation's injected plan data (see push_plans + plans.js).
		// Skip products with no plan relations on any variation (legacy products,
		// untouched) — resolve_for_product( parent, 0 ) returns every vid's rows.
		if ( $product && $product->is_type( 'variable' ) ) {
			if ( ! $this->product_has_plans( $product ) ) {
				return;
			}

			echo '<div class="subscrpt-buybox" data-subscrpt-buybox data-subscrpt-variable="1">';
			echo '<p class="subscrpt-buybox__placeholder">' . esc_html__( 'Select options to see available plans.', 'subscription-pro' ) . '</p>';
			echo '</div>';
			return;
		}

		if ( ! $product ) {
			return;
		}

		$groups = $this->build_groups( $product );

		// No plans attached → nothing to render (legacy product, untouched).
		if ( empty( $groups ) ) {
			return;
		}

		// Reuse the free plugin's shared base template; Pro's extra data (One-Time
		// card, discount badge) renders through the same guarded markup.
		wc_get_template(
			'product/plan-selector.php',
			array( 'groups' => $groups ),
			'subscription',
			SUBSCRPT_TEMPLATES
		);
	}

	/**
	 * Build the storefront selector groups for a product from real plan data.
	 *
	 * Resolves the product's active plans, groups terms under their plan group,
	 * and prepends a One-Time card unless the product disables it. Prices are
	 * the resolved per-term offer prices, formatted with `wc_price()`.
	 *
	 * @param \WC_Product $product   Product (or variation) object.
	 * @param int         $parent_id Parent id for variations (0 for simple).
	 * @return array
	 */
	private function build_groups( $product, $parent_id = 0 ) {
		$product_id   = $parent_id ? $parent_id : $product->get_id();
		$variation_id = $parent_id ? $product->get_id() : 0;

		// Only offer plans for a subscription-enabled product / variation. A
		// disabled (but plan-tied) product / variation shows no selector.
		if ( ! Helper::plan_offered( $product_id, $variation_id ) ) {
			return array();
		}

		$resolved = PlanRepository::resolve_for_product( $product_id, $variation_id );

		if ( empty( $resolved ) ) {
			return array();
		}

		$groups = array();

		foreach ( $resolved as $row ) {
			$gid      = (int) $row['plan_group_id'];
			$type_key = PlanRepository::type_to_string( (int) $row['group_type'] );

			if ( ! isset( $groups[ $gid ] ) ) {
				$groups[ $gid ] = array(
					'id'               => 'grp_' . $gid,
					'type'             => $type_key,
					'label'            => $row['group_title'],
					'price'            => '',
					'old_price'        => '',
					'terms'            => array(),
					'badge'            => '',
					'discount_percent' => 0,
					'pcts'             => array(),
				);
			}

			$price_num = $this->term_price( $row, $type_key );

			// Record each term's discount percentage (offer below regular). Installments
			// price differently, so are excluded.
			$row_regular = isset( $row['relation_data']['regular_price'] ) ? (float) $row['relation_data']['regular_price'] : 0.0;
			$term_pct    = 0;
			if ( 'installments' !== $type_key && $row_regular > 0 && $price_num < $row_regular ) {
				$term_pct                 = (int) round( ( $row_regular - $price_num ) / $row_regular * 100 );
				$groups[ $gid ]['pcts'][] = $term_pct;
			}

			$groups[ $gid ]['terms'][] = array(
				'id'               => (int) $row['plan_id'],
				'label'            => $row['plan_title'],
				'price'            => wc_price( $price_num ),
				'note'             => $this->term_note( $row, $type_key, $price_num ),
				'discount_percent' => $term_pct,
				'badge'            => '',
			);
		}

		// Card header price/old_price = the first term of each group.
		//
		// The badge text (filterable) is resolved per term, not per group: the
		// terms of one group discount by different amounts and the card shows
		// one term at a time, so a single group-wide figure was wrong for every
		// term but one. The selector swaps the text as the shopper picks a term;
		// the card starts on the first term's, which is the pre-selected one.
		foreach ( $groups as &$group ) {
			$first              = $group['terms'][0];
			$group['price']     = $first['price'];
			$group['old_price'] = '';

			if ( ! empty( $group['pcts'] ) ) {
				$group['discount_percent'] = max( $group['pcts'] );
			}
			unset( $group['pcts'] );

			foreach ( $group['terms'] as &$term ) {
				$term['badge'] = ( $term['discount_percent'] > 0 && function_exists( 'subscrpt_card_badge_text' ) )
					? subscrpt_card_badge_text( $group, $product, $term['discount_percent'] )
					: '';
			}
			unset( $term );

			$group['badge'] = $group['terms'][0]['badge'];
		}
		unset( $group );

		$groups = array_values( $groups );

		// Append the One-Time card after the subscription plans, so a subscription
		// stays the pre-selected default — the selector marks the first card.
		//
		// The card and its price maths come from free's subscrpt_one_time_group(),
		// the single source both selectors share, so the free and Pro storefronts
		// can never disagree on a price. Pass $product — the variation — not its
		// parent, whose `_subscrpt_one_time_enabled` only means "any variation
		// enabled". The helper badges the card itself.
		$one_time = function_exists( 'subscrpt_one_time_group' ) ? subscrpt_one_time_group( $product ) : null;
		if ( $one_time ) {
			$groups[] = $one_time;
		}

		return $groups;
	}


	/**
	 * Compute the numeric per-term price from a resolved plan row.
	 *
	 * @param array  $row      Resolved plan row.
	 * @param string $type_key Plan type key.
	 * @return float
	 */
	private function term_price( $row, $type_key ) {
		$data = $row['relation_data'];

		$regular = isset( $data['regular_price'] ) ? (string) $data['regular_price'] : '';
		$selling = isset( $data['sale_price'] ) ? (string) $data['sale_price'] : '';
		$dtype   = $data['discount_type'] ?? 'percentage';
		$dvalue  = isset( $data['discount_value'] ) ? (string) $data['discount_value'] : '0';

		$price = PlanPresenter::offer_price( $regular, $selling, $dtype, $dvalue );

		// Installments: the entered price is the TOTAL across all payments; show the
		// amount charged per installment (total ÷ number of payments), rounded 2dp.
		if ( 'installments' === $type_key ) {
			return subscrpt_split_amounts( $price, $this->installment_count( $row ) )['per_installment'];
		}

		return $price;
	}

	/**
	 * Number of installments for a split-payment plan (from the plan's data blob;
	 * `billing_frequency` is the "every N" cadence, not the payment count).
	 *
	 * @param array $row Resolved plan row.
	 * @return int At least 1.
	 */
	private function installment_count( $row ) {
		$plan_data = is_array( $row['plan_data'] ?? null ) ? $row['plan_data'] : array();
		return max( 1, (int) ( $plan_data['installment_count'] ?? 0 ) );
	}

	/**
	 * Build a short term note (billing cadence) for the selector.
	 *
	 * @param array  $row       Resolved plan row.
	 * @param string $type_key  Plan type key.
	 * @param float  $price_num Computed term price.
	 * @return string
	 */
	private function term_note( $row, $type_key, $price_num ) {
		$interval = PlanPresenter::interval_label( (int) $row['billing_interval'] );
		$freq     = max( 1, (int) $row['billing_frequency'] );

		if ( 'installments' === $type_key ) {
			// Total = the price entered on the plan (the amount the split is divided
			// from), shown verbatim in both the product page and the cart summary.
			$count   = $this->installment_count( $row );
			$every   = 1 === $freq ? strtolower( $interval ) : $freq . ' ' . strtolower( $interval ) . 's';
			$data    = is_array( $row['relation_data'] ) ? $row['relation_data'] : array();
			$entered = PlanPresenter::offer_price(
				isset( $data['regular_price'] ) ? (string) $data['regular_price'] : '',
				isset( $data['sale_price'] ) ? (string) $data['sale_price'] : '',
				$data['discount_type'] ?? 'percentage',
				isset( $data['discount_value'] ) ? (string) $data['discount_value'] : '0'
			);
			$total   = subscrpt_split_amounts( $entered, $count )['total'];
			$note    = sprintf(
				/* translators: 1: number of payments, 2: per-payment price, 3: billing interval, 4: total price. */
				__( 'Pay %4$s in %1$d installments of %2$s, billed every %3$s.', 'subscription-pro' ),
				$count,
				$this->price_text( $price_num ),
				$every,
				$this->price_text( $total )
			);
			return $note . $this->term_extras( $row, $type_key );
		}

		$every = 1 === $freq ? strtolower( $interval ) : $freq . ' ' . strtolower( $interval ) . 's';

		// Show the regular price struck-through beside the offer when discounted.
		$data    = is_array( $row['relation_data'] ) ? $row['relation_data'] : array();
		$regular = isset( $data['regular_price'] ) && '' !== $data['regular_price'] ? (float) $data['regular_price'] : null;

		$price_disp = ( null !== $regular && $price_num < $regular )
			? '<del>' . $this->price_text( $regular ) . '</del> ' . $this->price_text( $price_num )
			: $this->price_text( $price_num );

		$note = sprintf(
			/* translators: 1: price (may include a struck-through regular price), 2: billing interval. */
			__( 'Billed %1$s / %2$s', 'subscription-pro' ),
			$price_disp,
			$every
		);

		return $note . $this->term_extras( $row, $type_key );
	}

	/**
	 * Free-trial and signup-fee suffix for a term note, shown as a muted second
	 * line under the price. Empty when the term has neither.
	 *
	 * @param array  $row      Resolved plan row.
	 * @param string $type_key Plan type key.
	 * @return string
	 */
	private function term_extras( $row, $type_key ) {
		$parts = array();

		// Free trial (recurring / subscribe & save only; never with a signup fee).
		if ( Helper::plan_trial_applies( $row, $type_key ) ) {
			$count = (int) $row['free_trial'];
			$unit  = strtolower( (string) ( $row['plan_data']['free_trial_interval'] ?? 'day' ) );
			/* translators: 1: number, 2: interval (day/week/month/year). */
			$parts[] = sprintf( _n( '%1$d %2$s free trial', '%1$d %2$ss free trial', $count, 'subscription-pro' ), $count, $unit );
		}

		// One-off signup fee charged up front.
		if ( ! empty( $row['signup_fee'] ) && is_array( $row['signup_fee'] ) && ! empty( $row['signup_fee']['amount'] ) ) {
			/* translators: %s: signup fee amount. */
			$parts[] = sprintf( __( '%s signup fee', 'subscription-pro' ), $this->price_text( (float) $row['signup_fee']['amount'] ) );
		}

		return $parts ? '<br><small class="subscrpt-term-extra">' . implode( ' · ', $parts ) . '</small>' : '';
	}

	/**
	 * Plain-text formatted price — currency symbol as a real character, not an
	 * HTML entity. `wc_price()` renders the symbol as an entity (e.g. `&#36;`);
	 * left as-is it double-encodes when the JS selector escapes the note for a
	 * variable product, showing "10.00&#36;". Decoding here keeps it "10.00$".
	 *
	 * @param float $amount Amount.
	 *
	 * @return string
	 */
	private function price_text( $amount ) {
		return html_entity_decode( wp_strip_all_tags( wc_price( $amount ) ), ENT_QUOTES, 'UTF-8' );
	}

	/**
	 * Inject per-variation plan data into each variation's JSON.
	 *
	 * WooCommerce exposes this on the `found_variation` JS event, letting the
	 * storefront swap the plan selector when the shopper picks a variation —
	 * no server round-trip (mirrors Sublium's approach).
	 *
	 * @param array                 $variation_data Variation data passed to JS.
	 * @param \WC_Product           $product        Parent product.
	 * @param \WC_Product_Variation $variation      Variation object.
	 * @return array
	 */
	public function push_plans( $variation_data, $product, $variation ) {
		if ( ! $this->should_render() ) {
			return $variation_data;
		}

		$variation_data['subscrpt_plans'] = $this->build_groups( $variation, $product->get_id() );
		return $variation_data;
	}
}
