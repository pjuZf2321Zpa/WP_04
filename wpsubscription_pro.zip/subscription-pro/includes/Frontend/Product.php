<?php
/**
 * Storefront product price display for subscriptions (Pro).
 *
 * @package SpringDevs\SubscriptionPro\Frontend
 */

namespace SpringDevs\SubscriptionPro\Frontend;

use SpringDevs\Subscription\Illuminate\Helper as FreeHelper;
use SpringDevs\Subscription\Illuminate\Subscription\Subscription;
use SpringDevs\Subscription\Illuminate\Plans\PlanRepository;
use SpringDevs\Subscription\Admin\PlanPresenter;
use SpringDevs\SubscriptionPro\Frontend\Product\Simple;
use SpringDevs\SubscriptionPro\Illuminate\Helper;
use SpringDevs\Subscription\Utils\Product as UtilsProduct;
use WC_Product;
use WC_Product_Variation;

/**
 * Class Product
 *
 * @package SpringDevs\SubscriptionPro\Frontend
 */
class Product {


	/**
	 * Initialize the class
	 */
	public function __construct() {
		new Simple();
		add_action( 'woocommerce_before_add_to_cart_quantity', array( $this, 'remove_qtybox' ) );
		// Priority 20: run after the free plugin's classic price filters (priority
		// 10) so plan products' price display is not left with the classic
		// "native price / period" suffix.
		add_filter( 'woocommerce_get_price_html', array( $this, 'change_product_price_html' ), 20, 2 );
		add_filter( 'woocommerce_available_variation', array( $this, 'change_variation_price_html' ), 10, 3 );
		add_filter( 'woocommerce_cart_item_price', array( $this, 'change_price_cart_html' ), 20, 2 );
		add_filter( 'woocommerce_cart_item_subtotal', array( $this, 'change_price_cart_html' ), 20, 2 );
		add_filter( 'woocommerce_variation_is_purchasable', array( $this, 'variable_check_if_purchasable' ), 10, 2 );
		add_filter( 'woocommerce_variation_is_visible', array( $this, 'plan_variation_is_visible' ), 10, 3 );
	}

	/**
	 * Keep plan-connected variations in the variation picker even when they have
	 * no native price.
	 *
	 * WooCommerce hides a variation whose price is empty
	 * (WC_Product_Variation::variation_is_visible), but a plan variation stores
	 * its price on the plan relation, not the native price field — so without this
	 * such variations would drop out of the picker (only ones with a native /
	 * One-Time price would show).
	 *
	 * @param bool $visible      Whether the variation is visible.
	 * @param int  $variation_id Variation id.
	 * @param int  $parent_id    Parent product id.
	 *
	 * @return bool
	 */
	public function plan_variation_is_visible( $visible, $variation_id, $parent_id ) {
		if ( ! $visible && Helper::plan_offered( (int) $parent_id, (int) $variation_id ) ) {
			return true;
		}

		return $visible;
	}

	/**
	 * Filter variation purchasable conditionaly.
	 *
	 * @param boolean              $is_purchasable true/false.
	 * @param WC_Product_Variation $variation Variation object.
	 *
	 * @return boolean
	 */
	public function variable_check_if_purchasable( $is_purchasable, $variation ) {
		// A plan-connected variation is purchasable even without a native price —
		// its price lives on the plan relation and is applied at add-to-cart.
		if ( $variation instanceof WC_Product && Helper::plan_offered( $variation->get_parent_id(), $variation->get_id() ) ) {
			return true;
		}

		$variation = Subscription::get_subs_product( $variation );
		$limit     = $variation->get_meta( '_subscrpt_limit' );
		if ( $variation->is_enabled() ) {
			if ( 'unlimited' === $limit ) {
				return true;
			}
			if ( 'one' === $limit ) {
				return ! Helper::subscription_variable_exists( $variation->get_id(), array( 'pending', 'active' ) );
			}
			if ( 'only_one' === $limit ) {
				return $variation->has_trial();
			}
		}

		return $is_purchasable;
	}

	/**
	 * Hide quantity box when customer already subscription on this product.
	 */
	public function remove_qtybox() {
		global $product;
		if ( $product->is_type( 'variable' ) ) {
			$variations      = $product->get_available_variations();
			$unexpired_items = array();
			foreach ( $variations as $variation ) {
				$variation = Subscription::get_subs_product( $variation['variation_id'] );
				$unexpired = Helper::subscription_variable_exists(
					$variation->get_id(),
					array(
						'pending',
						'active',
					)
				);
				if ( ! $variation->is_enabled() ) {
					return false;
				}
				$limit = $variation->get_limit();
				if ( $limit ) {
					if ( 'one' === $limit ) {
						if ( $unexpired ) {
							$unexpired_items[] = $variation->get_id();
						}
					}
					if ( 'only_one' === $limit ) {
						$has_trial = Helper::check_trial( $variation->get_id() );
						if ( ! $has_trial ) {
							$unexpired_items[] = $variation->get_id();
						}
					}
				} elseif ( $unexpired ) {
					$unexpired_items[] = $variation->get_id();
				}
			}
			?>
			<style>
				.quantity.hideQty {
					display: none !important;
				}
			</style>
			<script>
				jQuery(document).ready(function($) {
					let unexpired_items = <?php echo wp_json_encode( $unexpired_items ); ?>;
					$('input.variation_id').change(function() {
						if ('' != $('input.variation_id').val()) {
							let var_id = $('input.variation_id').val();
							for (let index = 0; index < unexpired_items.length; index++) {
								const element = unexpired_items[index];
								if (var_id == element) {
									$(".quantity").addClass('hideQty');
									$(".quantity input.qty").hide();
									$(".single_add_to_cart_button").hide();
									break;
								} else {
									$(".quantity").removeClass('hideQty');
									$(".quantity input.qty").show();
									$(".single_add_to_cart_button").show();
								}
							}
						}
					});
				});
			</script>
			<?php
		}
	}

	/**
	 * Add variation type (daily, weekly, yearly) with price amount
	 *
	 * @param string     $price Price HTML.
	 * @param WC_Product $product Product Object.
	 *
	 * @return string $price
	 */
	public function change_product_price_html( $price, $product ) {
		// A box priced by its contents costs what is in it, not what its plan says.
		$box_price = BoxCardPrice::product_price_html( $product );
		if ( '' !== $box_price ) {
			return $box_price;
		}

		// Simple product tied to a plan: the classic engine renders the native
		// (possibly One-Time) price with a "/ period" suffix, which is wrong. Show
		// the default plan term's price + cadence instead; the selector below lists
		// every plan option.
		if ( ! $product->is_type( 'variable' ) && Helper::plan_offered( $product->get_id() ) ) {
			return $this->simple_plan_price_html( $product );
		}

		// Variable product tied to a plan: show one price range across ALL
		// variations' plans (variation id 0 resolves every vid) in place of the
		// native variation price range.
		if ( $product->is_type( 'variable' ) && Helper::plan_offered( $product->get_id() ) ) {
			return $this->plan_price_range_html( $product->get_id(), 0 );
		}

		if ( $product->is_type( 'variable' ) ) {
			$variations    = $product->get_available_variations();
			$min_price     = (float) $product->get_variation_price();
			$max_price     = (float) $product->get_variation_price( 'max' );
			$min_variation = null;
			$max_variation = null;

			foreach ( $variations as $variation ) {
				$variation_obj = Subscription::get_subs_product( $variation['variation_id'] );
				if ( ! $variation_obj->is_enabled() ) {
					continue;
				}

				$timing_per = $variation_obj->get_timing_per();
				$time       = $timing_per === 1 ? null : $timing_per;
				$typo       = subscrpt_get_typos( $timing_per, $variation_obj->get_timing_option() );

				// Get split payment info
				$max_no_payment     = $variation_obj->get_max_no_payment();
				$split_payment_info = '';
				if ( $max_no_payment > 0 ) {
					$split_payment_info = ' x ' . $max_no_payment;
				}

				$variation_data = array(
					'id'                 => $variation_obj->get_id(),
					'time'               => $time,
					'typo'               => $typo,
					'split_payment_info' => $split_payment_info,
				);

				if ( $variation['display_price'] === $min_price ) {
					$min_variation = $variation_data;
				}
				if ( $variation['display_price'] === $max_price ) {
					$max_variation = $variation_data;
				}
			}

			if ( $min_variation || $max_variation ) {
				$price = $this->format_price_range( $min_price, $max_price, $min_variation, $max_variation );
			}
		}

		return $price;
	}

	/**
	 * Add some information(type, signup fee, trial) with price if subscription enabled.
	 *
	 * @param mixed                $data data.
	 * @param WC_Product           $product Product object.
	 * @param WC_Product_Variation $variation Variation object.
	 *
	 * @return array
	 */
	public function change_variation_price_html( $data, $product, $variation ): array {
		// Plan-connected variation: suppress the per-variation price line entirely
		// (it would otherwise show a second range, or "$0.00", just above the plan
		// selector). The product-level overall range already covers it, and the
		// picker lists that variation's own plans + cadence.
		if ( $variation instanceof WC_Product_Variation && Helper::plan_offered( $variation->get_parent_id(), $variation->get_id() ) ) {
			$data['price_html'] = '';
			return $data;
		}

		$variation = Subscription::get_subs_product( $variation );
		if ( $variation->is_enabled() ) :
			$timing_per    = $variation->get_timing_per();
			$timing_option = $variation->get_timing_option();
			$time          = $timing_per === 1 ? null : $timing_per;

			// Subscription type string
			$timing_type = FreeHelper::get_typos( $timing_per, $timing_option, true );
			$time_string = ( $time ? $time . '-' : '' ) . ucfirst( $timing_type );

			// Split payment info
			$max_no_payment = $variation->get_max_no_payment();

			$split_payment_info = '';
			if ( $max_no_payment > 0 ) {
				$split_payment_info = ' x ' . $max_no_payment;
			}

			$time_html = "<span class='wpsubs-subscription-timing'>&nbsp;/&nbsp;{$time_string}{$split_payment_info}</span>";

			// Trial & Signup fee info
			$trial_signup_string = $this->get_trial_signup_html( $variation );

			// Final price HTML
			$data['price_html'] .= $time_html . $trial_signup_string;

			// Limit check messages
			$unexpired = Helper::subscription_variable_exists( $variation->get_id(), array( 'pending', 'active' ) );

			if ( $variation->get_limit() === 'one' && $unexpired ) {
				$data['variation_description'] .= '<strong>' . __( 'You already have a subscription with this product!', 'subscription-pro' ) . '</strong>';
			} elseif ( $variation->get_limit() === 'only_one' && ! $variation->has_trial() ) {
				$data['variation_description'] .= '<strong>' . __( 'You already have a subscription with this product!', 'subscription-pro' ) . '</strong>';
			}
		endif;

		return $data;
	}

	/**
	 * Add some information(type, signup fee, trial) with price in Cart if subscription enabled.
	 *
	 * @param string $price price.
	 * @param array  $cart_item cart item.
	 *
	 * @return string
	 */
	public function change_price_cart_html( $price, $cart_item ) {
		// Plan line item: show the resolved plan price + cadence, never the native
		// (possibly One-Time) price with a bogus sale / "save" against it.
		if ( ! empty( $cart_item['subscrpt_plan_id'] ) ) {
			$plan_price = isset( $cart_item['subscrpt_plan_price'] ) ? (float) $cart_item['subscrpt_plan_price'] : 0.0;
			$sub        = isset( $cart_item['subscription'] ) && is_array( $cart_item['subscription'] ) ? $cart_item['subscription'] : array();
			$time       = isset( $sub['time'] ) ? max( 1, (int) $sub['time'] ) : 1;
			$option     = isset( $sub['type'] ) ? (string) $sub['type'] : '';
			$cadence    = '';
			if ( $option ) {
				$typo    = subscrpt_get_typos( $time, $option );
				$cadence = ' / ' . ( 1 === $time ? '' : $time . ' ' ) . strtolower( $typo );
			}

			// Show the regular price struck-through beside the offer when discounted.
			$regular    = isset( $cart_item['subscrpt_plan_regular'] ) ? $cart_item['subscrpt_plan_regular'] : null;
			$price_disp = ( null !== $regular && $plan_price < (float) $regular )
				? '<del>' . wc_price( (float) $regular ) . '</del> <ins>' . wc_price( $plan_price ) . '</ins>'
				: wc_price( $plan_price );

			return $price_disp . $cadence;
		}

		$product = wc_get_product( $cart_item['product_id'] );

		// A plan product bought as a One-Time purchase (no plan id) is a plain,
		// non-recurring line — show its price with no subscription cadence and no
		// sale strikethrough from the plan prices sharing the native price.
		if ( $product && ! $product->is_type( 'variable' ) && subscrpt_product_has_plan( $product->get_id() ) ) {
			return wc_price( (float) $product->get_price() );
		}

		if ( ! $product->is_type( 'variable' ) ) {
			return $price;
		}
		$variation = Subscription::get_subs_product( $cart_item['variation_id'] );
		if ( $variation->is_enabled() ) :
			$timing_per    = $variation->get_timing_per();
			$timing_option = $variation->get_timing_option();
			$time          = 1 === $timing_per ? null : $timing_per;
			$type          = subscrpt_get_typos( $timing_per, $timing_option );

			// Add split payment information if max_no_payment is set
			$max_no_payment     = $variation->get_max_no_payment();
			$split_payment_info = '';
			if ( $max_no_payment > 0 ) {
				$split_payment_info = ' x ' . $max_no_payment;
			}

			return $price . ' / ' . $time . ' ' . $type . $split_payment_info . $this->get_trial_signup_html( $variation );
		else :
			return $price;
		endif;
	}

	/**
	 * Trial + signup-fee suffix HTML for a subscription variation.
	 *
	 * @param UtilsProduct $variation Variation (subscription product wrapper).
	 *
	 * @return string
	 */
	private function get_trial_signup_html( UtilsProduct $variation ): string {
		$trial           = null;
		$signup_fee_html = null;

		$has_trial = $variation->has_trial();
		if ( $has_trial ) {
			$trial_timing_per    = $variation->get_trial_timing_per();
			$trial_timing_option = $variation->get_trial_timing_option();

			$trial = '<br/><small> ' . sprintf(
				// translators: %s: trial period.
				'+ %s free trial!',
				$trial_timing_per . ' ' . subscrpt_get_typos( $trial_timing_per, $trial_timing_option )
			) . '</small>';
		}

		$signup_fee = $variation->get_signup_fee();
		if ( $signup_fee > 0 ) {
			$signup_fee_html = '<br/><small> ' . sprintf(
				// translators: %s: signup fee amount.
				'+ Signup fee of %s',
				wc_price( $signup_fee )
			) . '</small>';
		}

		return $signup_fee_html . $trial;
	}

	/**
	 * Price HTML for a simple product tied to a plan: the plan price range
	 * "min – max" across every attached term (no cadence — the selector shows
	 * the per-term cadence). A single price renders without the dash.
	 *
	 * @param WC_Product $product Product object.
	 *
	 * @return string
	 */
	private function simple_plan_price_html( $product ) {
		$rows = PlanRepository::resolve_for_product( $product->get_id() );
		if ( empty( $rows ) ) {
			return '';
		}

		// A single plan term with a discount shows the regular price struck-through
		// beside the offer price ("was $X, now $Y"). Multiple terms fall back to the
		// min–max range.
		if ( 1 === count( $rows ) ) {
			$row     = $rows[0];
			$regular = $this->plan_row_regular( $row );
			$offer   = $this->plan_row_price( $row );

			if ( null !== $regular && $offer < $regular ) {
				return '<del aria-hidden="true">' . wc_price( $regular ) . '</del> <ins>' . wc_price( $offer ) . '</ins>' . $this->plan_row_cadence_html( $row );
			}

			return wc_price( $offer ) . $this->plan_row_cadence_html( $row );
		}

		return $this->plan_price_range_html( $product->get_id(), 0, true );
	}

	/**
	 * Plan price range "min – max" across every term attached to a product (or a
	 * specific variation). Installment prices carry their cadence and count, as
	 * classic split products do; other terms leave cadence to the selector.
	 * Empty when no plans are attached, or when every price is equal and
	 * $hide_single is set (the selector already lists that single price).
	 *
	 * @param int  $product_id   Product id.
	 * @param int  $variation_id Variation id (0 for a simple product).
	 * @param bool $hide_single  Return '' instead of a lone price when not a range.
	 *
	 * @return string
	 */
	private function plan_price_range_html( $product_id, $variation_id = 0, $hide_single = false ) {
		$rows = PlanRepository::resolve_for_product( (int) $product_id, (int) $variation_id );
		if ( empty( $rows ) ) {
			return '';
		}

		$prices  = array();
		$cadence = array();
		foreach ( $rows as $row ) {
			// Skip rows that belong to a disabled variation so the range spans only
			// variations actually offered as subscriptions (product-level / vid 0
			// rows always count).
			$row_vid = (int) $row['vid'];
			if ( $row_vid > 0 && empty( get_post_meta( $row_vid, '_subscrpt_enabled', true ) ) ) {
				continue;
			}
			$prices[]  = $this->plan_row_price( $row );
			$cadence[] = $this->plan_row_cadence_html( $row );
		}

		if ( empty( $prices ) ) {
			return '';
		}

		$min = min( $prices );
		$max = max( $prices );

		$min_html = wc_price( $min ) . $cadence[ array_search( $min, $prices, true ) ];
		$max_html = wc_price( $max ) . $cadence[ array_search( $max, $prices, true ) ];

		if ( $min === $max ) {
			return $hide_single ? '' : $min_html;
		}

		return $min_html . ' &ndash; ' . $max_html;
	}

	/**
	 * Effective price of a resolved plan row (installment total, else offer price).
	 *
	 * @param array $row Resolved plan row.
	 *
	 * @return float
	 */
	private function plan_row_price( $row ) {
		$type_key = PlanRepository::type_to_string( (int) $row['group_type'] );
		$data     = is_array( $row['relation_data'] ) ? $row['relation_data'] : array();

		$offer = (float) PlanPresenter::offer_price(
			isset( $data['regular_price'] ) ? (string) $data['regular_price'] : '',
			isset( $data['sale_price'] ) ? (string) $data['sale_price'] : '',
			isset( $data['discount_type'] ) ? (string) $data['discount_type'] : 'percentage',
			isset( $data['discount_value'] ) ? (string) $data['discount_value'] : '0'
		);

		// Installments store the TOTAL; show the per-installment amount (total ÷ count).
		if ( 'installments' === $type_key ) {
			return subscrpt_split_amounts( $offer, $this->installment_count( $row ) )['per_installment'];
		}

		return $offer;
	}

	/**
	 * Per-row regular price for the struck-through display: the per-installment
	 * regular for a split plan, the plain regular otherwise. Null when unset.
	 *
	 * @param array $row Resolved plan row.
	 *
	 * @return float|null
	 */
	private function plan_row_regular( $row ) {
		$data    = is_array( $row['relation_data'] ) ? $row['relation_data'] : array();
		$regular = isset( $data['regular_price'] ) && '' !== $data['regular_price'] ? (float) $data['regular_price'] : null;
		if ( null === $regular ) {
			return null;
		}

		if ( 'installments' === PlanRepository::type_to_string( (int) $row['group_type'] ) ) {
			return subscrpt_split_amounts( $regular, $this->installment_count( $row ) )['per_installment'];
		}

		return $regular;
	}

	/**
	 * Cadence suffix of an installment plan row ("/ Week x 20"), in the classic
	 * split-payment format. Empty for other plan types.
	 *
	 * @param array $row Resolved plan row.
	 *
	 * @return string
	 */
	private function plan_row_cadence_html( $row ) {
		if ( 'installments' !== PlanRepository::type_to_string( (int) $row['group_type'] ) ) {
			return '';
		}

		$timing_per  = max( 1, (int) $row['billing_frequency'] );
		$timing_type = FreeHelper::get_typos( $timing_per, PlanRepository::interval_to_option( (int) $row['billing_interval'] ), true );
		$time_string = ( 1 === $timing_per ? '' : $timing_per . '-' ) . ucfirst( $timing_type );

		return "<span class='wpsubs-subscription-timing'>&nbsp;/&nbsp;{$time_string} x " . $this->installment_count( $row ) . '</span>';
	}

	/**
	 * Number of installments for a split-payment plan (from the plan data blob;
	 * `billing_frequency` is the "every N" cadence, not the payment count).
	 *
	 * @param array $row Resolved plan row.
	 *
	 * @return int At least 1.
	 */
	private function installment_count( $row ) {
		$plan_data = is_array( $row['plan_data'] ?? null ) ? $row['plan_data'] : array();

		return max( 1, (int) ( $plan_data['installment_count'] ?? 0 ) );
	}

	/**
	 * Format a variable product's min–max price range with the subscription cadence.
	 *
	 * @param float      $min_price     Minimum variation price.
	 * @param float      $max_price     Maximum variation price.
	 * @param array|null $min_variation Min-price variation display data.
	 * @param array|null $max_variation Max-price variation display data.
	 *
	 * @return string
	 */
	private function format_price_range( $min_price, $max_price, $min_variation, $max_variation ) {
		$min_price_formatted = wc_price( $min_price );
		$max_price_formatted = wc_price( $max_price );

		if ( $min_variation && $max_variation && $min_variation['id'] === $max_variation['id'] ) {
			$variation = $min_variation;
		} elseif ( $min_variation && ! $max_variation ) {
			$variation           = $min_variation;
			$max_price_formatted = " – $max_price_formatted";
		} elseif ( ! $min_variation && $max_variation ) {
			$variation            = $max_variation;
			$min_price_formatted .= ' – ';
		} else {
			$variation            = $max_variation;
			$min_price_formatted .= ' – ';
		}

		$time_string        = $variation['time'] ? $variation['time'] . '-' : '';
		$split_payment_info = isset( $variation['split_payment_info'] ) ? $variation['split_payment_info'] : '';

		$subs_info_html = "<span class='wpsubs-subscription-timing'>&nbsp;/&nbsp;{$time_string}{$variation['typo']} {$split_payment_info}</span>";
		$price_html     = $min_price_formatted . $max_price_formatted . $subs_info_html;

		return $price_html;
	}
}
