<?php
/**
 * Detects broken subscriptions and runs recovery actions.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Health
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Health;

use SpringDevs\Subscription\Illuminate\Helper;

/**
 * Health Engine — detects broken subscriptions and executes recovery actions.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Health
 */
class HealthEngine {

	/**
	 * Returns broken subscriptions matching the given filter.
	 *
	 * Results are cached in a 5-minute transient per filter key.
	 *
	 * @param string $filter One of: all, overdue_renewal, failed_payment, retry_needed, stalled_renewal.
	 * @return array[] Enriched subscription data arrays.
	 */
	public static function get_broken_subscriptions( string $filter = 'all' ): array {
		$cache_key = 'subscrpt_recovery_' . $filter;
		$cached    = get_transient( $cache_key );

		if ( false !== $cached ) {
			return $cached;
		}

		$results = array();

		if ( 'all' === $filter || 'overdue_renewal' === $filter ) {
			$results = array_merge( $results, self::query_overdue_renewals() );
		}
		if ( 'all' === $filter || 'failed_payment' === $filter ) {
			$results = array_merge( $results, self::query_failed_payments() );
		}
		if ( 'all' === $filter || 'retry_needed' === $filter ) {
			$results = array_merge( $results, self::query_retry_needed() );
		}
		if ( 'all' === $filter || 'stalled_renewal' === $filter ) {
			$results = array_merge( $results, self::query_stalled_renewals() );
		}

		// Deduplicate by subscription ID — highest severity wins.
		$severity = array(
			'failed_payment'  => 4,
			'overdue_renewal' => 3,
			'stalled_renewal' => 2,
			'retry_needed'    => 1,
		);
		$deduped  = array();
		foreach ( $results as $row ) {
			$id = $row['id'];
			if ( ! isset( $deduped[ $id ] ) || $severity[ $row['issue_type'] ] > $severity[ $deduped[ $id ]['issue_type'] ] ) {
				$deduped[ $id ] = $row;
			}
		}

		$skipped = self::get_skipped_ids();
		$output  = array_values(
			empty( $skipped )
				? $deduped
				: array_filter( $deduped, fn( $row ) => ! in_array( (int) $row['id'], $skipped, true ) )
		);

		set_transient( $cache_key, $output, 15 * MINUTE_IN_SECONDS );
		return $output;
	}

	/**
	 * Returns the total revenue at risk across the given subscriptions.
	 *
	 * @param array[] $subscriptions Result of get_broken_subscriptions().
	 * @return float
	 */
	public static function get_revenue_at_risk( array $subscriptions ): float {
		return array_reduce(
			$subscriptions,
			function ( float $carry, array $sub ): float {
				return $carry + (float) ( $sub['price'] ?? 0 );
			},
			0.0
		);
	}

	/**
	 * Manually triggers a payment retry for a subscription.
	 *
	 * @param int $subscription_id Subscription ID.
	 * @return array{success: bool, message: string}
	 */
	public static function retry_payment( int $subscription_id ): array {
		if ( ! self::subscription_exists( $subscription_id ) ) {
			return array(
				'success' => false,
				'message' => __( 'Subscription not found.', 'subscription-pro' ),
			);
		}

		// Most recent related order — get_related_orders() returns rows ordered id DESC.
		$new_order = null;
		foreach ( Helper::get_related_orders( $subscription_id ) as $row ) {
			$order = wc_get_order( (int) $row->order_id );
			if ( $order && 'trash' !== $order->get_status() ) {
				$new_order = $order;
				break;
			}
		}

		if ( ! $new_order ) {
			return array(
				'success' => false,
				'message' => __( 'No order found to retry.', 'subscription-pro' ),
			);
		}

		// Already paid — nothing to retry.
		if ( $new_order->has_status( 'completed' ) ) {
			return array(
				'success' => false,
				'message' => __( 'Latest order is already completed — nothing to retry.', 'subscription-pro' ),
			);
		}

		// Parent order holds the gateway payment method/token used for the charge.
		$old_order = Helper::get_parent_order( $subscription_id );
		if ( ! $old_order ) {
			return array(
				'success' => false,
				'message' => __( 'Parent order not found for this subscription.', 'subscription-pro' ),
			);
		}

		/**
		 * Fires the renewal payment attempt. Gateway listeners (Mollie, Razorpay,
		 * Xendit, Stripe) charge $new_order using the method stored on $old_order.
		 *
		 * @param \WC_Order $new_order       Renewal order to charge.
		 * @param \WC_Order $old_order       Parent order holding the payment method.
		 * @param int       $subscription_id Subscription post ID.
		 * @param bool      $is_early        Whether this is an early renewal. False for a retry.
		 */
		do_action( 'subscrpt_after_create_renew_order', $new_order, $old_order, $subscription_id, false );

		self::clear_cache();

		return array(
			'success' => true,
			/* translators: %d: WooCommerce order ID */
			'message' => sprintf( __( 'Payment retry triggered for order #%d.', 'subscription-pro' ), $new_order->get_id() ),
		);
	}

	/**
	 * Creates a missing renewal order for a subscription.
	 *
	 * @param int $subscription_id Subscription ID.
	 * @return array{success: bool, order_id: int|null, message: string}
	 */
	public static function create_renewal_order( int $subscription_id ): array {
		if ( ! self::subscription_exists( $subscription_id ) ) {
			return array(
				'success'  => false,
				'order_id' => null,
				'message'  => __( 'Subscription not found.', 'subscription-pro' ),
			);
		}

		try {
			$order = Helper::create_renewal_order( $subscription_id );
		} catch ( \Exception $e ) {
			return array(
				'success'  => false,
				'order_id' => null,
				'message'  => $e->getMessage(),
			);
		}

		if ( ! $order ) {
			return array(
				'success'  => false,
				'order_id' => null,
				'message'  => __( 'Failed to create renewal order. Check subscription status and payment limits.', 'subscription-pro' ),
			);
		}

		self::clear_cache();
		return array(
			'success'  => true,
			'order_id' => $order->get_id(),
			/* translators: %d: WooCommerce order ID */
			'message'  => sprintf( __( 'Renewal order #%d created.', 'subscription-pro' ), $order->get_id() ),
		);
	}

	/**
	 * Sends the payment failure email to the subscription customer.
	 *
	 * @param int $subscription_id Subscription ID.
	 * @return array{success: bool, message: string}
	 */
	public static function send_payment_update_email( int $subscription_id ): array {
		if ( ! self::subscription_exists( $subscription_id ) ) {
			return array(
				'success' => false,
				'message' => __( 'Subscription not found.', 'subscription-pro' ),
			);
		}

		$mailer = WC()->mailer();
		if ( ! $mailer || ! isset( $mailer->emails['subscrpt_recovery_notification'] ) ) {
			return array(
				'success' => false,
				'message' => __( 'Recovery notification email class not available.', 'subscription-pro' ),
			);
		}

		// Determine the current issue type for context-aware messaging.
		$all        = self::get_broken_subscriptions( 'all' );
		$issue_type = '';
		foreach ( $all as $row ) {
			if ( (int) $row['id'] === $subscription_id ) {
				$issue_type = (string) ( $row['issue_type'] ?? '' );
				break;
			}
		}

		$recovery_email = $mailer->emails['subscrpt_recovery_notification'] ?? null;
		if ( is_object( $recovery_email ) && method_exists( $recovery_email, 'trigger' ) ) {
			$recovery_email->trigger( $subscription_id, $issue_type );
		}

		return array(
			'success' => true,
			'message' => __( 'Recovery notification sent.', 'subscription-pro' ),
		);
	}

	/**
	 * Returns subscription IDs the admin has skipped from the recovery queue.
	 *
	 * @return int[]
	 */
	public static function get_skipped_ids(): array {
		return array_map( 'intval', (array) get_option( 'subscrpt_recovery_skipped', array() ) );
	}

	/**
	 * Adds a subscription to the skip list, hiding it from the recovery queue.
	 *
	 * @param int $subscription_id Subscription post ID.
	 * @return array{success: bool, message: string}
	 */
	public static function skip_subscription( int $subscription_id ): array {
		if ( ! self::subscription_exists( $subscription_id ) ) {
			return array(
				'success' => false,
				'message' => __( 'Subscription not found.', 'subscription-pro' ),
			);
		}

		$skipped = self::get_skipped_ids();
		if ( ! in_array( $subscription_id, $skipped, true ) ) {
			$skipped[] = $subscription_id;
			update_option( 'subscrpt_recovery_skipped', $skipped, false );
		}

		self::clear_cache();

		return array(
			'success' => true,
			'message' => __( 'Subscription skipped.', 'subscription-pro' ),
		);
	}

	/**
	 * Removes a subscription from the skip list, returning it to the recovery queue.
	 *
	 * @param int $subscription_id Subscription post ID.
	 * @return array{success: bool, message: string}
	 */
	public static function unskip_subscription( int $subscription_id ): array {
		$skipped = self::get_skipped_ids();
		$updated = array_values( array_filter( $skipped, fn( $id ) => $id !== $subscription_id ) );
		update_option( 'subscrpt_recovery_skipped', $updated, false );
		self::clear_cache();

		return array(
			'success' => true,
			'message' => __( 'Subscription returned to recovery queue.', 'subscription-pro' ),
		);
	}

	/**
	 * Returns skipped subscriptions for display on the Skipped filter view.
	 *
	 * @return array[]
	 */
	public static function get_skipped_subscriptions(): array {
		$ids     = self::get_skipped_ids();
		$results = array();
		foreach ( $ids as $id ) {
			if ( self::subscription_exists( $id ) ) {
				$results[] = self::build_row( $id, 'skipped' );
			}
		}
		return $results;
	}

	/**
	 * Clears all recovery transient caches.
	 */
	public static function clear_cache(): void {
		foreach ( array( 'all', 'overdue_renewal', 'failed_payment', 'retry_needed', 'stalled_renewal' ) as $key ) {
			delete_transient( 'subscrpt_recovery_' . $key );
		}
	}

	// -------------------------------------------------------------------------
	// Private query methods
	// -------------------------------------------------------------------------

	/**
	 * Subscriptions with next_date in the past and no renewal order in the last 24 h.
	 *
	 * @return array[]
	 */
	private static function query_overdue_renewals(): array {
		global $wpdb;

		$statuses = array( 'active', 'pe_cancelled', 'expired' );
		$params   = array_merge(
			array( '_subscrpt_next_date', 'subscrpt_order' ),
			$statuses,
			array( time() )
		);
		$sql      = 'SELECT DISTINCT p.ID
			FROM ' . $wpdb->posts . ' p
			INNER JOIN ' . $wpdb->postmeta . ' pm ON p.ID = pm.post_id AND pm.meta_key = %s
			WHERE p.post_type = %s
			AND p.post_status IN (' . implode( ', ', array_fill( 0, count( $statuses ), '%s' ) ) . ')
			AND CAST( pm.meta_value AS UNSIGNED ) <= %d';

		// phpcs:disable WordPress.DB.DirectDatabaseQuery
		$ids = $wpdb->get_col( $wpdb->prepare( $sql, ...$params ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Prepared with $wpdb->prepare() below.
		// phpcs:enable WordPress.DB.DirectDatabaseQuery

		$results = array();
		foreach ( $ids as $id ) {
			$next_date = (int) get_post_meta( (int) $id, '_subscrpt_next_date', true );
			if ( self::has_renewal_order_after_due_date( (int) $id, $next_date ) ) {
				continue;
			}
			$results[] = self::build_row( $id, 'overdue_renewal' );
		}
		return $results;
	}

	/**
	 * Subscriptions in grace-period or suspended post status.
	 *
	 * @return array[]
	 */
	private static function query_failed_payments(): array {
		global $wpdb;

		$sql = $wpdb->prepare(
			'SELECT DISTINCT p.ID
			FROM ' . $wpdb->posts . ' p
			INNER JOIN ' . $wpdb->postmeta . ' pm ON p.ID = pm.post_id
			WHERE p.post_type = %s
			AND p.post_status IN ( %s, %s )
			AND pm.meta_key = %s
			AND CAST( pm.meta_value AS UNSIGNED ) > 0',
			'subscrpt_order',
			'subscrpt-grace-period',
			'subscrpt-suspended',
			'_subscrpt_payment_failure_count'
		);

		// phpcs:disable WordPress.DB.DirectDatabaseQuery
		$ids = $wpdb->get_col( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Prepared above with $wpdb->prepare().
		// phpcs:enable WordPress.DB.DirectDatabaseQuery

		$results = array();
		foreach ( $ids as $id ) {
			$status    = Helper::get_subscription_status( (int) $id );
			$results[] = self::build_row( (int) $id, 'failed_payment', array( 'sub_status' => $status ) );
		}
		return $results;
	}

	/**
	 * Subscriptions with recorded failures but no retry scheduled.
	 *
	 * @return array[]
	 */
	private static function query_retry_needed(): array {
		global $wpdb;

		$sql = $wpdb->prepare(
			'SELECT DISTINCT p.ID
			FROM ' . $wpdb->posts . ' p
			INNER JOIN ' . $wpdb->postmeta . ' pm_failure ON p.ID = pm_failure.post_id
			LEFT JOIN ' . $wpdb->postmeta . ' pm_retry ON p.ID = pm_retry.post_id AND pm_retry.meta_key = %s
			LEFT JOIN ' . $wpdb->postmeta . ' pm_next ON p.ID = pm_next.post_id AND pm_next.meta_key = %s
			WHERE p.post_type = %s
			AND p.post_status NOT IN ( %s, %s, %s )
			AND pm_failure.meta_key = %s
			AND CAST( pm_failure.meta_value AS UNSIGNED ) > 0
			AND ( pm_retry.post_id IS NULL OR pm_retry.meta_value <> %s )
			AND ( pm_next.post_id IS NULL OR CAST( pm_next.meta_value AS UNSIGNED ) <= %d )',
			'_subscrpt_retry_scheduled',
			'_subscrpt_next_date',
			'subscrpt_order',
			'trash',
			'subscrpt-grace-period',
			'subscrpt-suspended',
			'_subscrpt_payment_failure_count',
			'1',
			time()
		);

		// phpcs:disable WordPress.DB.DirectDatabaseQuery
		$ids = $wpdb->get_col( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Prepared above with $wpdb->prepare().
		// phpcs:enable WordPress.DB.DirectDatabaseQuery

		$results = array();
		foreach ( $ids as $id ) {
			$results[] = self::build_row( (int) $id, 'retry_needed' );
		}
		return $results;
	}

	/**
	 * Subscriptions whose most recent renewal order has been pending for > 24 h.
	 *
	 * @return array[]
	 */
	private static function query_stalled_renewals(): array {
		global $wpdb;

		// Fetch ALL renewal order IDs per subscription — do NOT use MAX(order_id) because
		// trashed orders can have higher IDs than the live pending one, causing it to be missed.
		// phpcs:disable WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT subscription_id, order_id
				FROM {$wpdb->prefix}subscrpt_order_relation
				WHERE type IN (%s, %s)",
				'renew',
				'early-renew'
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery

		if ( empty( $rows ) ) {
			return array();
		}

		// Build a map: subscription_id → [order_id, ...].
		$orders_by_sub = array();
		foreach ( $rows as $row ) {
			$orders_by_sub[ (int) $row['subscription_id'] ][] = (int) $row['order_id'];
		}

		$all_order_ids = array_map( 'intval', array_column( (array) $rows, 'order_id' ) );

		// wc_get_orders excludes trashed orders automatically and filters by status.
		$active_orders = wc_get_orders(
			array(
				'include' => $all_order_ids,
				'status'  => array( 'pending', 'on-hold' ),
				'limit'   => -1,
				'return'  => 'objects',
			)
		);

		if ( empty( $active_orders ) ) {
			return array();
		}

		// Index live pending/on-hold orders by ID for fast lookup.
		$live_orders = array();
		foreach ( $active_orders as $order ) {
			$live_orders[ $order->get_id() ] = $order;
		}

		$results = array();
		foreach ( $orders_by_sub as $sub_id => $sub_order_ids ) {
			if ( 'subscrpt_order' !== get_post_type( $sub_id ) ) {
				continue;
			}
			if ( 'trash' === Helper::get_subscription_status( $sub_id ) ) {
				continue;
			}

			// Find the most recent live pending/on-hold order for this subscription.
			$best_order    = null;
			$best_order_id = 0;
			foreach ( $sub_order_ids as $oid ) {
				if ( isset( $live_orders[ $oid ] ) && $oid > $best_order_id ) {
					$best_order_id = $oid;
					$best_order    = $live_orders[ $oid ];
				}
			}

			if ( ! $best_order ) {
				continue;
			}

			$results[] = self::build_row( $sub_id, 'stalled_renewal', array( 'stalled_order_id' => $best_order_id ) );
		}

		return $results;
	}

	// -------------------------------------------------------------------------
	// Helpers
	// -------------------------------------------------------------------------

	/**
	 * Checks whether a renewal order exists for the current billing cycle.
	 *
	 * @param int $subscription_id Subscription ID.
	 * @param int $next_date Next payment timestamp.
	 * @return bool
	 */
	private static function has_renewal_order_after_due_date( int $subscription_id, int $next_date ): bool {
		if ( $next_date <= 0 ) {
			return false;
		}

		$related = Helper::get_related_orders( $subscription_id );

		foreach ( $related as $row ) {
			if ( ! in_array( strtolower( $row->type ?? '' ), array( 'renew', 'early-renew' ), true ) ) {
				continue;
			}
			$order = wc_get_order( (int) $row->order_id );
			if ( ! $order || 'trash' === $order->get_status() ) {
				continue;
			}
			$created = $order->get_date_created();
			if ( $created && $created->getTimestamp() >= $next_date ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Returns a minimal subscription payload suitable for CRM/automation hooks.
	 *
	 * @param int $subscription_id Subscription post ID.
	 * @return array{id:int,customer_id:int,customer_email:string,customer_name:string,product_id:int,product_name:string,price:float,status:string}
	 */
	public static function get_subscription_payload( int $subscription_id ): array {
		$data       = Helper::get_subscription_data( $subscription_id );
		$user_id    = (int) ( $data['user_id'] ?? 0 );
		$product_id = (int) ( $data['product']['product_id'] ?? 0 );
		$user       = $user_id ? get_userdata( $user_id ) : null;
		$product    = $product_id ? wc_get_product( $product_id ) : null;

		return array(
			'id'             => $subscription_id,
			'customer_id'    => $user_id,
			'customer_email' => $user ? $user->user_email : '',
			'customer_name'  => $user ? $user->display_name : '',
			'product_id'     => $product_id,
			'product_name'   => $product ? $product->get_name() : '',
			'price'          => (float) ( $data['price'] ?? 0 ),
			'status'         => $data['status'] ?? get_post_status( $subscription_id ),
		);
	}

	/**
	 * Builds a normalised row array for a subscription.
	 *
	 * Uses Helper::get_subscription_data() as the single source for subscription meta
	 * and Helper::get_related_orders() for renewal order lookup.
	 *
	 * @param int    $subscription_id Subscription post ID.
	 * @param string $issue_type      Issue type slug.
	 * @param array  $extra           Extra key/value pairs merged into the result.
	 * @return array
	 */
	private static function build_row( int $subscription_id, string $issue_type, array $extra = array() ): array {
		$data       = Helper::get_subscription_data( $subscription_id );
		$user_id    = (int) ( $data['user_id'] ?? 0 );
		$product_id = (int) ( $data['product']['product_id'] ?? 0 );
		$user       = $user_id ? get_userdata( $user_id ) : null;
		$product    = $product_id ? wc_get_product( $product_id ) : null;

		$next_date      = $data['next_date'] ? (int) strtotime( $data['next_date'] ) : 0;
		$failure_ts     = (int) get_post_meta( $subscription_id, '_subscrpt_last_payment_failure', true );
		$issue_ts       = $failure_ts > 0 ? $failure_ts : $next_date;
		$days_since     = $issue_ts > 0 ? max( 0, (int) floor( ( time() - $issue_ts ) / DAY_IN_SECONDS ) ) : 0;
		$last_order     = 'overdue_renewal' === $issue_type ? array(
			'order_id' => 0,
			'status'   => '',
			'date'     => '',
		) : self::get_last_renewal_order_details( $subscription_id );
		$timing_per     = (int) ( $data['schedule']['timing_per'] ?? 1 );
		$timing_option  = (string) ( $data['schedule']['timing_option'] ?? '' );
		$billing_period = $timing_option
			? ( $timing_per > 1 ? $timing_per . ' ' . Helper::get_typos( $timing_per, $timing_option ) : Helper::get_typos( 1, $timing_option ) )
			: '';

		return array_merge(
			array(
				'id'                => $subscription_id,
				'customer_id'       => $user_id,
				'product_id'        => $product_id,
				'issue_type'        => $issue_type,
				'status'            => $data['status'] ?? get_post_status( $subscription_id ),
				'customer_name'     => $user ? $user->display_name : __( 'Unknown', 'subscription-pro' ),
				'customer_email'    => $user ? $user->user_email : '',
				'product_name'      => $product ? $product->get_name() : __( 'Unknown product', 'subscription-pro' ),
				'price'             => (float) ( $data['price'] ?? 0 ),
				'billing_period'    => $billing_period,
				'renewal_date'      => $next_date,
				'last_order_id'     => (int) $last_order['order_id'],
				'last_order_status' => (string) $last_order['status'],
				'last_order_date'   => (string) $last_order['date'],
				'renewal_created'   => ! empty( $last_order['order_id'] ),
				'days_since'        => $days_since,
				'failure_count'     => (int) get_post_meta( $subscription_id, '_subscrpt_payment_failure_count', true ),
				'next_retry'        => (int) get_post_meta( $subscription_id, '_subscrpt_next_retry_time', true ),
				'grace_end'         => (int) get_post_meta( $subscription_id, '_subscrpt_grace_period_end', true ),
			),
			$extra
		);
	}

	/**
	 * Gets the most recent renewal order linked to a subscription via Helper::get_related_orders().
	 *
	 * @param int $subscription_id Subscription post ID.
	 * @return array{order_id:int,status:string,date:string}
	 */
	private static function get_last_renewal_order_details( int $subscription_id ): array {
		$empty   = array(
			'order_id' => 0,
			'status'   => '',
			'date'     => '',
		);
		$related = Helper::get_related_orders( $subscription_id );

		foreach ( $related as $row ) {
			if ( ! in_array( strtolower( $row->type ?? '' ), array( 'renew', 'early-renew' ), true ) ) {
				continue;
			}
			$order_id = (int) $row->order_id;
			$order    = wc_get_order( $order_id );
			if ( ! $order || 'trash' === $order->get_status() ) {
				continue;
			}
			$created = $order->get_date_created();
			return array(
				'order_id' => $order_id,
				'status'   => $order->get_status(),
				'date'     => $created ? $created->format( 'Y-m-d H:i:s' ) : '',
			);
		}

		return $empty;
	}

	/**
	 * Confirms a post exists and is a subscrpt_order post type.
	 *
	 * @param int $subscription_id Subscription post ID.
	 * @return bool
	 */
	private static function subscription_exists( int $subscription_id ): bool {
		return 'subscrpt_order' === get_post_type( $subscription_id );
	}
}
