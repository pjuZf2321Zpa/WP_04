<?php
/**
 * Require a payment method at checkout for free-trial subscriptions.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate
 */

namespace SpringDevs\SubscriptionPro\Illuminate;

/**
 * Require a payment method at checkout for free-trial subscriptions.
 *
 * A free trial zeroes the initial order total, so WooCommerce skips the payment
 * step and no payment method is captured — renewals after the trial then fail
 * until the customer manually adds a card. When the
 * `subscrpt_require_payment_on_trial` setting is on, the cart and order are
 * forced to still require payment so the chosen gateway runs and saves a method
 * up front for the automatic renewal after the trial.
 *
 * Both the cart and the order hooks are filtered: the shortcode checkout reads
 * `WC_Cart::needs_payment()`, while the block / Store API checkout reads
 * `WC_Order::needs_payment()` on the draft order.
 *
 * Pro-only by construction (instantiated from pro's service container).
 *
 * @package SpringDevs\SubscriptionPro\Illuminate
 */
class TrialPayment {

	/**
	 * Initialize the class.
	 */
	public function __construct() {
		if ( '1' !== get_option( 'subscrpt_require_payment_on_trial', '1' ) ) {
			return;
		}

		add_filter( 'woocommerce_cart_needs_payment', [ $this, 'cart_needs_payment' ], 20, 2 );
		add_filter( 'woocommerce_order_needs_payment', [ $this, 'order_needs_payment' ], 20, 3 );
	}

	/**
	 * Force the cart to require payment when it holds a trial subscription, even
	 * though the trial makes the initial total zero.
	 *
	 * @param bool     $needs_payment Whether the cart currently needs payment.
	 * @param \WC_Cart $cart          Cart object.
	 *
	 * @return bool
	 */
	public function cart_needs_payment( $needs_payment, $cart ) {
		if ( $needs_payment || ! $cart instanceof \WC_Cart ) {
			return $needs_payment;
		}

		return $this->cart_has_trial( $cart ) ? true : $needs_payment;
	}

	/**
	 * Force the order to require payment when it holds a trial subscription.
	 *
	 * Covers the block / Store API checkout (which reads the draft order) and the
	 * customer "pay for order" page for a pending trial order.
	 *
	 * @param bool      $needs_payment        Whether the order currently needs payment.
	 * @param \WC_Order $order                Order object.
	 * @param array     $valid_order_statuses Statuses that may still take payment.
	 *
	 * @return bool
	 */
	public function order_needs_payment( $needs_payment, $order, $valid_order_statuses ) {
		if ( $needs_payment || ! $order instanceof \WC_Order ) {
			return $needs_payment;
		}

		if ( ! in_array( $order->get_status(), (array) $valid_order_statuses, true ) ) {
			return $needs_payment;
		}

		// During an active checkout the cart is the reliable signal; on the
		// pay-for-order page it is empty, so fall back to the order lines.
		if ( ( WC()->cart && $this->cart_has_trial( WC()->cart ) ) || $this->order_has_trial( $order ) ) {
			return true;
		}

		return $needs_payment;
	}

	/**
	 * Whether the cart holds at least one trial subscription line.
	 *
	 * @param \WC_Cart $cart Cart object.
	 *
	 * @return bool
	 */
	private function cart_has_trial( $cart ) {
		foreach ( $cart->get_cart() as $cart_item ) {
			if ( isset( $cart_item['subscription'] ) && ! empty( $cart_item['subscription']['trial'] ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether the order holds at least one trial subscription line. The trial
	 * rides the plan terms for plan items and `_subscrpt_meta` for classic items.
	 *
	 * @param \WC_Order $order Order object.
	 *
	 * @return bool
	 */
	private function order_has_trial( $order ) {
		foreach ( $order->get_items() as $item ) {
			$plan_terms = $item->get_meta( '_subscrpt_plan_terms' );
			if ( is_array( $plan_terms ) && ! empty( $plan_terms['trial'] ) ) {
				return true;
			}

			$meta = $item->get_meta( '_subscrpt_meta' );
			if ( is_array( $meta ) && ! empty( $meta['trial'] ) ) {
				return true;
			}
		}

		return false;
	}
}
