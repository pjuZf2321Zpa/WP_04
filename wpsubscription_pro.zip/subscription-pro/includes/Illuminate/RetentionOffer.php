<?php
/**
 * Retention offer - the discount a cancelling customer is shown.
 *
 * Free owns the settings UI, the modal step and the request; this turns an
 * accepted offer into something real. That is deliberately a plain WooCommerce
 * coupon rather than a discount on the renewal: Woo already enforces single
 * use, expiry and who may redeem it, and none of it touches renewal pricing.
 *
 * The coupon is locked to the customer's email and the subscription's product,
 * so the code cannot be passed around or spent elsewhere. A subscription gets one
 * coupon, ever: reopening the modal hands back the same unused code, and once it
 * is spent or lapsed no other is issued.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate
 */

namespace SpringDevs\SubscriptionPro\Illuminate;

use SpringDevs\Subscription\Admin\CancellationFlow;

defined( 'ABSPATH' ) || exit;

/**
 * Retention offer - the discount a cancelling customer is shown.
 */
class RetentionOffer {

	/**
	 * Post meta on the subscription holding the coupon already issued for it.
	 */
	const COUPON_META = '_subscrpt_retention_coupon';

	/**
	 * Statuses a subscription can be retained from.
	 */
	const CLAIMABLE_STATUSES = [ 'active', 'pe_cancelled' ];

	/**
	 * Initialize the class.
	 */
	public function __construct() {
		add_action( 'admin_init', [ $this, 'register_settings' ] );
		add_filter( 'subscrpt_cancellation_offer', [ $this, 'issue_offer' ], 10, 3 );
	}

	/**
	 * Register the offer settings into the Cancellation Flow group.
	 *
	 * Same group as the delay and the reason list: options.php nulls anything
	 * registered in the group it is handed but absent from the POST, so every
	 * option that page saves has to live together.
	 *
	 * @return void
	 */
	public function register_settings() {
		$group = class_exists( CancellationFlow::class )
			? CancellationFlow::OPTION_GROUP
			: 'wp_subscription_cancellation_settings';

		register_setting(
			$group,
			'subscrpt_cancellation_offer_enabled',
			[
				'type'              => 'string',
				'default'           => '',
				'sanitize_callback' => 'sanitize_text_field',
			]
		);
		register_setting(
			$group,
			'subscrpt_cancellation_offer_percent',
			[
				'type'              => 'integer',
				'default'           => 20,
				'sanitize_callback' => [ $this, 'sanitize_percent' ],
			]
		);
		register_setting(
			$group,
			'subscrpt_cancellation_offer_type',
			[
				'type'              => 'string',
				'default'           => 'percent',
				'sanitize_callback' => [ $this, 'sanitize_type' ],
			]
		);
		register_setting(
			$group,
			'subscrpt_cancellation_offer_amount',
			[
				'type'              => 'number',
				'default'           => 0,
				'sanitize_callback' => [ $this, 'sanitize_amount' ],
			]
		);
		register_setting(
			$group,
			'subscrpt_cancellation_offer_days',
			[
				'type'              => 'integer',
				'default'           => 7,
				'sanitize_callback' => [ $this, 'sanitize_days' ],
			]
		);
	}

	/**
	 * Clamp the discount to a usable percentage.
	 *
	 * @param mixed $value Submitted value.
	 * @return int
	 */
	public function sanitize_percent( $value ) {
		return max( 1, min( 100, (int) $value ) );
	}

	/**
	 * Keep the discount type to one the coupon supports.
	 *
	 * @param mixed $value Submitted value.
	 * @return string
	 */
	public function sanitize_type( $value ) {
		return 'fixed' === $value ? 'fixed' : 'percent';
	}

	/**
	 * Clamp the flat discount to a non-negative store-currency amount.
	 *
	 * @param mixed $value Submitted value.
	 * @return float
	 */
	public function sanitize_amount( $value ) {
		return max( 0, (float) wc_format_decimal( $value, wc_get_price_decimals() ) );
	}

	/**
	 * Clamp the coupon lifetime to at least a day.
	 *
	 * @param mixed $value Submitted value.
	 * @return int
	 */
	public function sanitize_days( $value ) {
		return max( 1, min( 365, (int) $value ) );
	}

	/**
	 * Issue the offer a cancelling customer accepted.
	 *
	 * @param array|null $offer           Offer so far, from an earlier filter.
	 * @param int        $subscription_id Subscription ID.
	 * @param int        $customer_id     Subscription owner.
	 *
	 * @return array|null
	 */
	public function issue_offer( $offer, $subscription_id, $customer_id ) {
		if ( ! empty( $offer ) || ! class_exists( CancellationFlow::class ) ) {
			return $offer;
		}

		if ( ! CancellationFlow::offer_enabled() || ! function_exists( 'wc_get_coupon_id_by_code' ) ) {
			return $offer;
		}

		$subscription_id = (int) $subscription_id;
		$customer_id     = (int) $customer_id;

		if ( ! $this->may_claim( $subscription_id, $customer_id ) ) {
			return $offer;
		}

		$product_id = (int) get_post_meta( $subscription_id, '_subscrpt_product_id', true );
		if ( ! $product_id ) {
			return $offer;
		}

		$user = get_userdata( $customer_id );
		if ( ! $user || empty( $user->user_email ) ) {
			return $offer;
		}

		// A free version without flat offers only ever has a percentage.
		$type    = method_exists( CancellationFlow::class, 'offer_type' ) ? CancellationFlow::offer_type() : 'percent';
		$percent = CancellationFlow::offer_percent();
		$amount  = 'fixed' === $type ? CancellationFlow::offer_amount() : $percent;

		// One coupon per subscription: hand back the unused one, never replace it.
		if ( '' !== (string) get_post_meta( $subscription_id, self::COUPON_META, true ) ) {
			$code = $this->existing_coupon( $subscription_id );
		} else {
			$code = $this->create_coupon( $subscription_id, $user->user_email, $amount, CancellationFlow::offer_days(), $type, $product_id );
		}

		if ( ! $code ) {
			return $offer;
		}

		return [
			'code'    => $code,
			'percent' => 'fixed' === $type ? 0 : $percent,
			'type'    => $type,
			'amount'  => $amount,
		];
	}

	/**
	 * Whether the logged-in customer may claim this subscription's offer.
	 *
	 * Only its owner, and only while it is still theirs to keep: active, or set
	 * to cancel at the end of the period.
	 *
	 * @param int $subscription_id Subscription ID.
	 * @param int $customer_id     Subscription owner, as the caller passed it.
	 * @return bool
	 */
	protected function may_claim( int $subscription_id, int $customer_id ): bool {
		if ( ! $subscription_id || ! $customer_id || get_current_user_id() !== $customer_id ) {
			return false;
		}

		if ( 'subscrpt_order' !== get_post_type( $subscription_id ) || (int) get_post_field( 'post_author', $subscription_id ) !== $customer_id ) {
			return false;
		}

		return in_array( get_post_status( $subscription_id ), self::CLAIMABLE_STATUSES, true );
	}

	/**
	 * The still-valid coupon already issued for this subscription, if any.
	 *
	 * @param int $subscription_id Subscription ID.
	 * @return string Coupon code, or an empty string.
	 */
	protected function existing_coupon( $subscription_id ) {
		$code = (string) get_post_meta( $subscription_id, self::COUPON_META, true );

		if ( '' === $code ) {
			return '';
		}

		$coupon_id = wc_get_coupon_id_by_code( $code );
		if ( ! $coupon_id ) {
			return '';
		}

		$coupon = new \WC_Coupon( $coupon_id );

		// Spent or lapsed.
		if ( $coupon->get_usage_count() >= 1 ) {
			return '';
		}

		$expires = $coupon->get_date_expires();
		if ( $expires && $expires->getTimestamp() < time() ) {
			return '';
		}

		return $code;
	}

	/**
	 * Create the coupon backing an accepted offer.
	 *
	 * @param int       $subscription_id Subscription ID.
	 * @param string    $email           Customer email the coupon is locked to.
	 * @param int|float $percent      Discount percentage, or the flat amount when `$type` is `fixed`.
	 * @param int       $days            Days until it expires.
	 * @param string    $type            `percent` or `fixed`.
	 * @param int       $product_id      The subscription's product, the only one the coupon discounts.
	 *
	 * @return string Coupon code, or an empty string on failure.
	 */
	protected function create_coupon( $subscription_id, $email, $percent, $days, $type = 'percent', $product_id = 0 ) {
		$code = strtolower( 'keep' . preg_replace( '/[^0-9]/', '', (string) $percent ) . '-' . wp_generate_password( 6, false, false ) );

		try {
			$coupon = new \WC_Coupon();
			$coupon->set_code( $code );
			$coupon->set_discount_type( 'fixed' === $type ? 'fixed_product' : 'percent' );
			$coupon->set_amount( $percent );
			$coupon->set_individual_use( true );
			$coupon->set_usage_limit( 1 );
			$coupon->set_usage_limit_per_user( 1 );
			$coupon->set_email_restrictions( [ $email ] );
			$coupon->set_product_ids( [ (int) $product_id ] );
			$coupon->set_date_expires( time() + ( $days * DAY_IN_SECONDS ) );
			$coupon->set_description(
				sprintf(
					/* translators: %d: subscription ID. */
					__( 'Retention offer for subscription #%d.', 'subscription-pro' ),
					(int) $subscription_id
				)
			);
			$coupon->save();
		} catch ( \Exception $e ) {
			return '';
		}

		if ( ! $coupon->get_id() ) {
			return '';
		}

		update_post_meta( $subscription_id, self::COUPON_META, $code );

		return $code;
	}
}
