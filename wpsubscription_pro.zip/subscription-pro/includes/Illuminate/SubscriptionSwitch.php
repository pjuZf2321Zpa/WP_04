<?php
/**
 * Subscription switching (upgrade and downgrade).
 *
 * @package SpringDevs\SubscriptionPro\Illuminate
 */

namespace SpringDevs\SubscriptionPro\Illuminate;

use SpringDevs\Subscription\Illuminate\Helper as FreeHelper;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class SubscriptionSwitch
 *
 * @package SpringDevs\SubscriptionPro\Illuminate
 */
class SubscriptionSwitch {
	/**
	 * Initialize the class
	 */
	public function __construct() {
		// Register subscription switch setting. UI is defined in the free plugin (ProSettingsFields).
		add_action( 'admin_init', array( $this, 'register_settings' ) );

		// Add the switch toggle button to the actions row.
		add_filter( 'subscrpt_single_action_buttons', [ $this, 'add_switch_button' ], 10, 4 );

		// Render the inline switch panel just below the actions row (revealed by the toggle).
		add_action( 'subscrpt_before_subscription_totals', [ $this, 'render_switch_panel' ] );

		// Handle the inline switch form submission (sets context, adds to cart, redirects to checkout).
		add_action( 'template_redirect', [ $this, 'handle_inline_switch_submit' ] );

		// Hide downgrade options.
		add_filter( 'woocommerce_get_children', [ $this, 'possibly_hide_downgrade_variations' ], 10, 2 );

		// Hook into product details page.
		add_action( 'wp', [ $this, 'handle_switch_subscription_selection' ], 10 );

		// Add to cart handling for switch subscription.
		add_filter( 'woocommerce_add_cart_item_data', [ $this, 'subs_switch_add_cart_item_data' ], 11, 3 );
		add_action( 'woocommerce_checkout_create_order_line_item', [ $this, 'add_switch_meta_to_order_item' ], 10, 3 );

		// Validate cart item data for switch subscription.
		add_filter( 'woocommerce_add_to_cart_validation', [ $this, 'subs_switch_validate_cart' ], 10, 5 );

		// A switch is checked out on its own.
		add_action( 'woocommerce_check_cart_items', [ $this, 'refuse_mixed_switch_cart' ] );

		// Persist url params in while adding to cart.
		add_filter( 'woocommerce_add_to_cart_redirect', [ $this, 'persist_params_on_cart_redirect' ], 10, 1 );

		// Safe redirect after switch subscription error.
		add_action( 'template_redirect', [ $this, 'maybe_redirect_after_add_to_cart_failure' ] );

		// Adjust order price.
		add_action( 'woocommerce_cart_calculate_fees', [ $this, 'switch_add_adjust_price' ], 20, 1 );

		// Apply a scheduled (deferred) downgrade when the subscription renews, before recurring coupons (priority 10).
		add_filter( 'subscrpt_before_saving_renewal_order', [ $this, 'apply_pending_downgrade_to_renewal' ], 5, 3 );

		// Keep the renewal date unchanged when a switch (upgrade/downgrade) order activates the subscription.
		add_filter( 'subscrpt_subscription_next_date', [ $this, 'preserve_next_date_on_switch' ], 10, 4 );

		// Drop any scheduled downgrade when the subscription is cancelled.
		add_action( 'subscrpt_subscription_status_changed', [ $this, 'clear_pending_switch_on_cancel' ], 10, 3 );
	}

	/**
	 * Register settings
	 */
	public function register_settings() {
		register_setting(
			'wp_subscription_settings',
			'subscrpt_switch_enabled',
			array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			)
		);
		register_setting(
			'wp_subscription_settings',
			'subscrpt_downgrade_allowed',
			array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			)
		);
		register_setting(
			'wp_subscription_settings',
			'subscrpt_switch_fee_amount',
			array(
				'type'              => 'string',
				'sanitize_callback' => array( $this, 'sanitize_switch_fee_amount' ),
			)
		);
		register_setting(
			'wp_subscription_settings',
			'subscrpt_switch_fee_type',
			array(
				'type'              => 'string',
				'sanitize_callback' => array( $this, 'sanitize_switch_fee_type' ),
			)
		);
		register_setting(
			'wp_subscription_settings',
			'subscrpt_switch_fee_apply_to',
			array(
				'type'              => 'string',
				'sanitize_callback' => array( $this, 'sanitize_switch_fee_apply_to' ),
			)
		);
	}

	/**
	 * Sanitize the switch fee amount (non-negative number).
	 *
	 * @param mixed $value Raw value.
	 *
	 * @return string
	 */
	public function sanitize_switch_fee_amount( $value ) {
		$amount = is_numeric( $value ) ? (float) $value : 0;

		return (string) max( 0, $amount );
	}

	/**
	 * Sanitize the switch fee type (flat | percent).
	 *
	 * @param mixed $value Raw value.
	 *
	 * @return string
	 */
	public function sanitize_switch_fee_type( $value ) {
		return in_array( $value, [ 'flat', 'percent' ], true ) ? $value : 'flat';
	}

	/**
	 * Sanitize the switch fee target (both | upgrade | downgrade).
	 *
	 * @param mixed $value Raw value.
	 *
	 * @return string
	 */
	public function sanitize_switch_fee_apply_to( $value ) {
		return in_array( $value, [ 'both', 'upgrade', 'downgrade' ], true ) ? $value : 'both';
	}

	/**
	 * Get Settings
	 *
	 * @param string $id Setting ID.
	 */
	public static function get_settings( $id = '' ) {
		$settings = [
			'subscrpt_switch_enabled'      => get_option( 'subscrpt_switch_enabled', '0' ) === '1',
			'subscrpt_downgrade_allowed'   => get_option( 'subscrpt_downgrade_allowed', '1' ) === '1',
			'subscrpt_switch_fee_amount'   => (float) get_option( 'subscrpt_switch_fee_amount', '0' ),
			'subscrpt_switch_fee_type'     => get_option( 'subscrpt_switch_fee_type', 'flat' ),
			'subscrpt_switch_fee_apply_to' => get_option( 'subscrpt_switch_fee_apply_to', 'both' ),
		];
		return ! empty( $id ) ? $settings[ $id ] ?? false : $settings;
	}

	/**
	 * Add the "Switch Subscription" toggle button to the actions row.
	 *
	 * The button reveals the inline switch panel (rendered below the actions row)
	 * via a CSS `:target` toggle, so no JavaScript is required.
	 *
	 * @param array  $buttons        Action buttons.
	 * @param int    $id             Subscription ID.
	 * @param string $subscrpt_nonce Subscription action nonce (unused here).
	 * @param string $status         Subscription status.
	 *
	 * @return array
	 */
	public function add_switch_button( array $buttons, int $id, string $subscrpt_nonce, string $status ): array {
		if ( ! self::get_settings( 'subscrpt_switch_enabled' ) || 'active' !== $status ) {
			return $buttons;
		}

		$current = $this->get_current_switch_product( $id );
		if ( empty( $current ) ) {
			return $buttons;
		}

		// While a downgrade is scheduled, still show the button but disabled (tooltip wired in switch.js).
		if ( get_post_meta( $id, '_subscrpt_pending_switch', true ) ) {
			$buttons['wp_subs_switch'] = [
				'url'   => '#',
				'label' => __( 'Switch Subscription', 'subscription-pro' ),
				'class' => 'subscrpt_switch_toggle subscrpt_switch_disabled',
			];

			return $buttons;
		}

		if ( empty( $this->get_switchable_variations( $current['product'], $current['variation_id'] ) ) ) {
			return $buttons;
		}

		$buttons['wp_subs_switch'] = [
			'url'   => '#',
			'label' => __( 'Switch Subscription', 'subscription-pro' ),
			'class' => 'subscrpt_switch_toggle',
		];

		return $buttons;
	}

	/**
	 * Render the inline switch picker.
	 *
	 * Rendered after the actions table, then relocated into the actions cell and
	 * toggled like an accordion by assets/js/frontend/switch.js. Shows the available
	 * plans and a checkout button; selecting a plan and submitting adds it to the
	 * cart and redirects to checkout.
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	public function render_switch_panel( $subscription_id ) {
		if ( ! self::get_settings( 'subscrpt_switch_enabled' ) ) {
			return;
		}

		if ( 'active' !== get_post_status( $subscription_id ) ) {
			return;
		}

		$current = $this->get_current_switch_product( $subscription_id );
		if ( empty( $current ) ) {
			return;
		}

		// While a downgrade is scheduled, the switch button is shown disabled; supply the tooltip text + assets.
		if ( get_post_meta( $subscription_id, '_subscrpt_pending_switch', true ) ) {
			wp_enqueue_style( 'subscrpt_switch_css', SUBSCRIPT_PRO_ASSETS . '/css/frontend/switch.css', [], SUBSCRIPT_PRO_VERSION );
			wp_enqueue_script( 'subscrpt_switch_js', SUBSCRIPT_PRO_ASSETS . '/js/frontend/switch.js', [], SUBSCRIPT_PRO_VERSION, true );
			?>
			<span id="subscrpt_switch_scheduled_tooltip" hidden><?php esc_html_e( 'A downgrade is already scheduled for this subscription.', 'subscription-pro' ); ?></span>
			<?php
			return;
		}

		$options = $this->get_switchable_variations( $current['product'], $current['variation_id'] );
		if ( empty( $options ) ) {
			return;
		}

		wp_enqueue_style( 'subscrpt_switch_css', SUBSCRIPT_PRO_ASSETS . '/css/frontend/switch.css', [], SUBSCRIPT_PRO_VERSION );
		wp_enqueue_script( 'subscrpt_switch_js', SUBSCRIPT_PRO_ASSETS . '/js/frontend/switch.js', [], SUBSCRIPT_PRO_VERSION, true );

		$nonce           = wp_create_nonce( 'subscrpt_switch_' . $subscription_id );
		$wp_button_class = function_exists( 'wc_wp_theme_get_element_class_name' ) ? wc_wp_theme_get_element_class_name( 'button' ) : '';

		$current_product = wc_get_product( $current['variation_id'] );
		$current_price   = $current_product ? (float) $current_product->get_price() : 0;
		$ratio           = $this->get_remaining_period_ratio( (int) $subscription_id );
		$next_date       = (int) get_post_meta( $subscription_id, '_subscrpt_next_date', true );
		$next_date_label = $next_date ? date_i18n( wc_date_format(), $next_date ) : '';
		?>
		<div id="subscrpt_switch_picker" class="subscrpt_switch_picker">
			<div class="subscrpt_switch_picker_inner">
				<div class="subscrpt_switch_picker_body">
					<form method="post" class="subscrpt_switch_form">
						<p class="subscrpt_switch_intro"><?php esc_html_e( 'Choose a new plan and proceed to checkout to switch.', 'subscription-pro' ); ?></p>
						<p class="subscrpt_switch_notice" hidden></p>
						<ul class="subscrpt_switch_options">
							<?php
							foreach ( $options as $variation ) :
								$term            = $this->format_variation_term( $variation );
								$variation_price = (float) $variation->get_price();
								$is_downgrade    = $variation_price < $current_price;
								$fee             = $this->get_switch_fee( $variation_price, $is_downgrade );
								$fee_label       = $fee > 0
									? sprintf( /* translators: %s: switch fee amount. */ esc_html__( '+ %s switch fee', 'subscription-pro' ), wp_kses_post( wc_price( $fee ) ) )
									: '';
								$confirm         = '';

								if ( $is_downgrade ) {
									$notice = $next_date_label
										? sprintf( /* translators: %s: renewal date. */ esc_html__( 'Your subscription will downgrade on %s. Your current subscription will remain unchanged till then.', 'subscription-pro' ), '<strong>' . esc_html( $next_date_label ) . '</strong>' )
										: esc_html__( 'Your subscription will downgrade at your next renewal. Your current subscription will remain unchanged till then.', 'subscription-pro' );

									if ( $fee > 0 ) {
										$notice .= ' ' . sprintf( /* translators: %s: switch fee amount. */ esc_html__( 'A %s switch fee will be charged today.', 'subscription-pro' ), wp_kses_post( wc_price( $fee ) ) );
									}

									$confirm = $next_date_label
										? sprintf(
											/* translators: 1: target plan name, 2: renewal date. */
											__( 'Your subscription will downgrade to %1$s on %2$s. Proceed to checkout?', 'subscription-pro' ),
											wp_strip_all_tags( $variation->get_name() ),
											$next_date_label
										)
										: sprintf(
											/* translators: %s: target plan name. */
											__( 'Your subscription will downgrade to %s at your next renewal. Proceed to checkout?', 'subscription-pro' ),
											wp_strip_all_tags( $variation->get_name() )
										);

									if ( $fee > 0 ) {
										$fee_text = html_entity_decode( wp_strip_all_tags( wc_price( $fee ) ), ENT_QUOTES, 'UTF-8' );
										$confirm .= ' ' . sprintf(
											/* translators: %s: switch fee amount. */
											__( 'A %s switch fee will be charged today.', 'subscription-pro' ),
											$fee_text
										);
									}
								} else {
									$charge_now = ( max( 0, $variation_price - $current_price ) * $ratio ) + $fee;
									$notice     = sprintf( /* translators: %s: prorated amount charged today. */ esc_html__( 'You will be charged %s today for the prorated upgrade. The full plan price applies from the next billing period.', 'subscription-pro' ), wp_kses_post( wc_price( $charge_now ) ) );

									if ( $fee > 0 ) {
										$notice .= ' ' . sprintf( /* translators: %s: switch fee amount. */ esc_html__( 'Includes a %s switch fee.', 'subscription-pro' ), wp_kses_post( wc_price( $fee ) ) );
									}

									$charge_text = html_entity_decode( wp_strip_all_tags( wc_price( $charge_now ) ), ENT_QUOTES, 'UTF-8' );
									$confirm     = sprintf(
										/* translators: 1: amount charged today, 2: target plan name. */
										__( 'You will be charged %1$s today to switch to %2$s. Proceed to checkout?', 'subscription-pro' ),
										$charge_text,
										wp_strip_all_tags( $variation->get_name() )
									);
								}
								?>
								<li class="subscrpt_switch_option">
									<label class="subscrpt_switch_option_label">
										<input type="radio" class="subscrpt_switch_option_radio" name="new_variation_id" value="<?php echo esc_attr( $variation->get_id() ); ?>" data-subscrpt-notice="<?php echo esc_attr( $notice ); ?>" data-subscrpt-confirm="<?php echo esc_attr( $confirm ); ?>" required />
										<span class="subscrpt_switch_option_main">
											<span class="subscrpt_switch_option_name"><?php echo esc_html( wp_strip_all_tags( $variation->get_name() ) ); ?></span>
											<?php if ( $term ) : ?>
												<span class="subscrpt_switch_option_term"><?php echo esc_html( $term ); ?></span>
											<?php endif; ?>
										</span>
										<span class="subscrpt_switch_option_price">
											<?php echo wp_kses_post( wc_price( $variation->get_price() ) ); ?>
											<?php if ( $fee_label ) : ?>
												<span class="subscrpt_switch_option_fee"><?php echo wp_kses_post( $fee_label ); ?></span>
											<?php endif; ?>
										</span>
									</label>
								</li>
							<?php endforeach; ?>
						</ul>
						<input type="hidden" name="wpsubs_id" value="<?php echo esc_attr( $subscription_id ); ?>" />
						<input type="hidden" name="_wpnonce" value="<?php echo esc_attr( $nonce ); ?>" />
						<div class="subscrpt_switch_actions">
							<button type="button" class="button <?php echo esc_attr( $wp_button_class ); ?> subscrpt_switch_btn subscrpt_switch_cancel"><?php esc_html_e( 'Cancel', 'subscription-pro' ); ?></button>
							<button type="submit" name="subscrpt_switch_submit" value="1" class="button <?php echo esc_attr( $wp_button_class ); ?> subscrpt_switch_btn subscrpt_switch_submit"><?php esc_html_e( 'Proceed to Checkout', 'subscription-pro' ); ?></button>
						</div>
					</form>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Resolve the current subscription product and variation from its latest order.
	 *
	 * @param int $subscription_id Subscription ID.
	 *
	 * @return array{product: \WC_Product, product_id: int, variation_id: int, order_id: int}|array Empty array when not a switchable variable subscription.
	 */
	private function get_current_switch_product( $subscription_id ) {
		$order_id = get_post_meta( $subscription_id, '_subscrpt_order_id', true );
		$order    = wc_get_order( $order_id );
		if ( ! $order ) {
			return [];
		}

		$items = $order->get_items();
		$item  = reset( $items );
		if ( ! $item instanceof \WC_Order_Item_Product ) {
			return [];
		}

		$product_id   = (int) $item->get_product_id();
		$variation_id = (int) $item->get_variation_id();
		if ( ! $variation_id ) {
			return [];
		}

		$product = wc_get_product( $product_id );
		if ( ! $product || ! $product->is_type( 'variable' ) ) {
			return [];
		}

		return [
			'product'      => $product,
			'product_id'   => $product_id,
			'variation_id' => $variation_id,
			'order_id'     => (int) $order_id,
		];
	}

	/**
	 * Get the variations a subscription can switch to.
	 *
	 * Excludes the current variation and, when downgrades are disabled, any
	 * cheaper variation (mirrors possibly_hide_downgrade_variations()).
	 *
	 * @param \WC_Product $product              Parent variable product.
	 * @param int         $current_variation_id Current variation ID.
	 *
	 * @return \WC_Product[] List of purchasable, visible variation products.
	 */
	private function get_switchable_variations( $product, $current_variation_id ) {
		$downgrade_allowed = self::get_settings( 'subscrpt_downgrade_allowed' );
		$current           = wc_get_product( $current_variation_id );
		$current_price     = $current ? (float) $current->get_price() : 0;

		$options = [];
		foreach ( $product->get_children() as $child_id ) {
			if ( (int) $child_id === (int) $current_variation_id ) {
				continue;
			}

			$variation = wc_get_product( $child_id );
			if ( ! $variation || ! $variation->is_purchasable() || ! $variation->variation_is_visible() ) {
				continue;
			}

			if ( ! $downgrade_allowed && (float) $variation->get_price() < $current_price ) {
				continue;
			}

			$options[] = $variation;
		}

		return $options;
	}

	/**
	 * Format a variation's billing term, e.g. "1 Month".
	 *
	 * @param \WC_Product $variation Variation product.
	 *
	 * @return string Empty when timing meta is unavailable.
	 */
	private function format_variation_term( $variation ) {
		$per    = (int) $variation->get_meta( '_subscrpt_timing_per' );
		$option = $variation->get_meta( '_subscrpt_timing_option' );

		if ( ! $per ) {
			$parent = wc_get_product( $variation->get_parent_id() );
			$per    = $parent ? (int) $parent->get_meta( '_subscrpt_timing_per' ) : 0;
			$option = $parent ? $parent->get_meta( '_subscrpt_timing_option' ) : $option;
		}

		if ( ! $per || empty( $option ) ) {
			return '';
		}

		return $per . ' ' . subscrpt_get_typos( $per, $option );
	}

	/**
	 * Handle the inline switch form submission.
	 *
	 * Verifies nonce + ownership, sets the switch context, adds the selected
	 * variation to a clean cart, then redirects to checkout. The existing cart
	 * pipeline (add_cart_item_data, validation, fee adjustment) handles the rest.
	 */
	public function handle_inline_switch_submit() {
		if ( empty( $_POST['subscrpt_switch_submit'] ) ) {
			return;
		}

		$subscription_id  = isset( $_POST['wpsubs_id'] ) ? absint( $_POST['wpsubs_id'] ) : 0;
		$new_variation_id = isset( $_POST['new_variation_id'] ) ? absint( $_POST['new_variation_id'] ) : 0;
		$nonce            = isset( $_POST['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ) : '';

		// Nonce + ownership.
		$subs_post = $subscription_id ? get_post( $subscription_id ) : null;
		if ( ! wp_verify_nonce( $nonce, 'subscrpt_switch_' . $subscription_id ) || ! $subs_post || (int) $subs_post->post_author !== get_current_user_id() ) {
			wc_add_notice( __( 'You are not allowed to switch this subscription.', 'subscription-pro' ), 'error' );
			return;
		}

		if ( ! $new_variation_id ) {
			wc_add_notice( __( 'Please select a plan to switch to.', 'subscription-pro' ), 'error' );
			return;
		}

		$current = $this->get_current_switch_product( $subscription_id );
		if ( empty( $current ) || is_null( WC()->cart ) ) {
			return;
		}

		// WC_Cart::add_to_cart() below does not run add-to-cart validation, so refuse here.
		if ( $this->is_refused_downgrade( $current['variation_id'], $new_variation_id ) ) {
			wc_add_notice( __( 'Downgrading this subscription is not allowed.', 'subscription-pro' ), 'error' );
			return;
		}

		// Set the switch context the cart pipeline reads.
		$this->set_switch_subscription_context(
			[
				'switch_type'       => 'upgrade', // Updated from price in subs_switch_add_cart_item_data.
				'subscription_id'   => $subscription_id,
				'order_id'          => $current['order_id'],
				'product_id'        => $current['product_id'],
				'old_variation_id'  => $current['variation_id'],
				'new_variation_id'  => 0, // Updated in subs_switch_add_cart_item_data.
				'nonce'             => wp_create_nonce( 'subscrpt_switch_' . $subscription_id ),
				'redirect_back_url' => wc_get_cart_url(),
			]
		);

		// Add the selected variation to a clean cart; validation + fee run here.
		WC()->cart->empty_cart();
		$added = WC()->cart->add_to_cart( $current['product_id'], 1, $new_variation_id );

		if ( ! $added ) {
			// Validation failed — notices were added by subs_switch_validate_cart.
			$this->unset_switch_subscription_context();
			return;
		}

		// Switch item is in the cart and carries its own switch_context copy; clear
		// the session context so later, unrelated add-to-cart actions aren't treated as switches.
		$this->unset_switch_subscription_context();

		wp_safe_redirect( wc_get_checkout_url() );
		exit;
	}

	/**
	 * Possibly hide downgrade variations.
	 *
	 * @param array       $children Array of children variation IDs.
	 * @param \WC_Product $product Product object.
	 */
	public function possibly_hide_downgrade_variations( $children, $product ) {
		// Get the current subscription context.
		$switch_context = $this->get_switch_subscription_context();

		// Check if downgrade is allowed.
		$downgrade_allowed = self::get_settings( 'subscrpt_downgrade_allowed' );

		// Return if not a subscription switch context.
		if ( empty( $switch_context ) || (int) $switch_context['product_id'] !== $product->get_id() || $downgrade_allowed ) {
			return $children;
		}

		$current_variation_id = $switch_context['old_variation_id'] ?? 0;
		$current_variation    = wc_get_product( $current_variation_id );

		foreach ( $children as $key => $child_id ) {
			$variation = wc_get_product( $child_id );

			if ( $variation->get_price() < $current_variation->get_price() ) {
				unset( $children[ $key ] );
			}
		}

		return $children;
	}

	/**
	 * Set subscription switch context in session.
	 *
	 * @param array $subscription_switch_data Subscription switch data.
	 */
	public function set_switch_subscription_context( $subscription_switch_data ) {
		// Ensure session is initialized.
		if ( ! isset( WC()->session ) || null === WC()->session ) {
			return;
		}

		WC()->session->set( 'wp_subs_switch_context', $subscription_switch_data );

		// Force save session data.
		if ( method_exists( WC()->session, 'save_data' ) ) {
			WC()->session->save_data();
		}
	}

	/**
	 * Unset subscription switch context in session.
	 */
	public function unset_switch_subscription_context() {
		// Ensure session is initialized.
		if ( ! isset( WC()->session ) || null === WC()->session ) {
			return;
		}

		WC()->session->__unset( 'wp_subs_switch_context' );
	}

	/**
	 * Get subscription switch context from session.
	 */
	public function get_switch_subscription_context() {
		// Ensure session is initialized.
		if ( ! isset( WC()->session ) || null === WC()->session ) {
			return null;
		}

		$context = WC()->session->get( 'wp_subs_switch_context' );
		return $context;
	}

	/**
	 * Handle switch subscription selection.
	 */
	public function handle_switch_subscription_selection() {
		if ( ! is_product() ) {
			return;
		}

		// Only clear context if not in a switch context AND not setting one now.
		if ( ! isset( $_GET['wp_subs_switch'] ) ) {
			$this->unset_switch_subscription_context();
			return;
		}

		$order_id        = isset( $_GET['wpsubs_order_id'] ) ? absint( $_GET['wpsubs_order_id'] ) : 0;
		$subscription_id = isset( $_GET['wpsubs_id'] ) ? absint( $_GET['wpsubs_id'] ) : 0;
		$nonce           = isset( $_GET['nonce'] ) ? sanitize_text_field( wp_unslash( $_GET['nonce'] ) ) : null;

		if ( ! $this->customer_may_switch( $subscription_id, $order_id, (string) $nonce ) ) {
			$this->unset_switch_subscription_context();
			wc_add_notice( __( 'You are not allowed to switch this subscription.', 'subscription-pro' ), 'error' );
			return;
		}

		$current = $this->get_current_switch_product( $subscription_id );
		if ( empty( $current ) ) {
			$this->unset_switch_subscription_context();
			return;
		}

		wc_add_notice( __( 'Please select an option to change the current subscription and checkout.', 'subscription-pro' ), 'notice' );

		$product_id   = $current['product_id'];
		$variation_id = $current['variation_id'];

		// Build redirect URL for errors.
		$redirect_url = '';
		$product      = wc_get_product( $product_id );
		if ( ! empty( $product ) ) {
			$product_url  = $product->get_permalink();
			$redirect_url = add_query_arg(
				[
					'wp_subs_switch'  => '',
					'wpsubs_id'       => $subscription_id,
					'wpsubs_order_id' => $order_id,
					'nonce'           => $nonce,
				],
				$product_url
			);
		}

		// Set data for switch context.
		$subscription_switch_data = [
			'switch_type'       => 'upgrade', // Default. It will be updated in 'subs_switch_add_cart_item_data' method.
			'subscription_id'   => $subscription_id,
			'order_id'          => $order_id,
			'product_id'        => $product_id,
			'old_variation_id'  => $variation_id,
			'new_variation_id'  => 0, // Default. It will be updated in 'subs_switch_add_cart_item_data' method.
			'nonce'             => $nonce,
			'redirect_back_url' => $redirect_url,
		];

		$this->set_switch_subscription_context( $subscription_switch_data );
	}

	/**
	 * Whether the current customer may start a switch of this subscription.
	 *
	 * The same conditions the switch button is shown under: switching is on, the
	 * subscription is the customer's own and active, the order is its order, and
	 * the nonce was issued for this subscription.
	 *
	 * @param int    $subscription_id Subscription ID.
	 * @param int    $order_id        Order the request names.
	 * @param string $nonce           Nonce from the request.
	 *
	 * @return bool
	 */
	private function customer_may_switch( int $subscription_id, int $order_id, string $nonce ): bool {
		$user_id = get_current_user_id();
		$post    = $subscription_id ? get_post( $subscription_id ) : null;

		if ( ! $user_id || ! $post || 'subscrpt_order' !== $post->post_type || (int) $post->post_author !== $user_id ) {
			return false;
		}

		if ( ! wp_verify_nonce( $nonce, 'subscrpt_switch_' . $subscription_id ) ) {
			return false;
		}

		if ( ! self::get_settings( 'subscrpt_switch_enabled' ) || 'active' !== get_post_status( $subscription_id ) ) {
			return false;
		}

		$own_order_id = (int) get_post_meta( $subscription_id, '_subscrpt_order_id', true );
		if ( ! $order_id || $own_order_id !== $order_id ) {
			return false;
		}

		return Helper::order_customer_owns_subscription( $subscription_id, $order_id );
	}

	/**
	 * Persist URL parameters while adding to cart.
	 *
	 * @param string $url Redirect URL.
	 */
	public function persist_params_on_cart_redirect( string $url ): string {
		if ( ! WC()->session || empty( $this->get_switch_subscription_context() ) ) {
			return $url;
		}

		$switch_context = $this->get_switch_subscription_context();

		return $switch_context['redirect_back_url'] ?? $url;
	}

	/**
	 * Add switch subscription data to cart item.
	 *
	 * @param array $cart_item_data Cart item data.
	 * @param int   $product_id Product ID.
	 * @param int   $variation_id Variation ID.
	 */
	public function subs_switch_add_cart_item_data( array $cart_item_data, int $product_id, int $variation_id = 0 ): array {
		// Get context from session.
		$switch_context = $this->get_switch_subscription_context();

		// Only treat this add-to-cart as a switch when the product matches the
		// switch context and a variation is being added. Otherwise the stored
		// context would wrongly stamp unrelated products as switches.
		if ( empty( $switch_context ) || ! $variation_id || (int) $product_id !== (int) ( $switch_context['product_id'] ?? 0 ) ) {
			return $cart_item_data;
		}

		$new_variation = wc_get_product( $variation_id );
		$old_variation = wc_get_product( $switch_context['old_variation_id'] ?? 0 );

		if ( ! $new_variation || ! $old_variation ) {
			return $cart_item_data;
		}

		$switch_type                        = ( $new_variation->get_price() < $old_variation->get_price() ) ? 'downgrade' : 'upgrade';
		$switch_context['switch_type']      = $switch_type;
		$switch_context['new_variation_id'] = $variation_id;

		$cart_item_data['wp_subs_switch'] = true;
		$cart_item_data['switch_context'] = $switch_context;

		// A fresh switch supersedes any previously scheduled downgrade.
		$subscription_id = (int) ( $switch_context['subscription_id'] ?? 0 );
		if ( $subscription_id ) {
			delete_post_meta( $subscription_id, '_subscrpt_pending_switch' );
		}

		return $cart_item_data;
	}

	/**
	 * Add switch subscription meta to order item.
	 *
	 * @param \WC_Order_Item_Product $item Order item.
	 * @param string                 $cart_item_key Cart item key.
	 * @param array                  $cart_item Cart item data.
	 */
	public function add_switch_meta_to_order_item( \WC_Order_Item_Product $item, string $cart_item_key, array $cart_item ) {
		// ! We are doing this in free version. That is running before this.
		// ? check "SpringDevs\Subscription\Frontend\Checkout::save_order_item_product_meta"

		/* // phpcs:ignore
		if ( ! empty( $cart_item['wp_subs_switch'] ?? null ) && ! empty( $cart_item['switch_context'] ?? null ) ) {
			$switch_context = $cart_item['switch_context'];

			// Add switch context data to order item meta.
			$item->add_meta_data( 'wp_subs_switch', true, true );
			$item->add_meta_data( 'wp_subs_switch_context', $switch_context, true );
		}
		*/
	}

	/**
	 * Validate cart item data for switch subscription.
	 *
	 * @param bool       $valid Whether the item is valid.
	 * @param int|string $product_id Product ID.
	 * @param int        $quantity Quantity of the product.
	 * @param int|string $variation_id Variation ID.
	 * @param array      $cart_item_data Cart item data.
	 *
	 * @return bool
	 */
	public function subs_switch_validate_cart( $valid, $product_id, $quantity, $variation_id = 0, $cart_item_data = [] ) {
		// Get context from session.
		$switch_context = $this->get_switch_subscription_context();

		// No switch is being started: refuse company for a switch already in the cart.
		if ( ! WC()->session || empty( $switch_context ) ) {
			if ( $valid && WC()->cart && self::find_switch_line( WC()->cart->get_cart() ) ) {
				wc_add_notice( __( 'A subscription switch must be checked out on its own. Complete it or remove it from your cart first.', 'subscription-pro' ), 'error' );

				return false;
			}

			return $valid;
		}

		// Normalize variation ID.
		$product_id   = is_string( $product_id ) ? absint( $product_id ) : $product_id;
		$variation_id = is_string( $variation_id ) ? absint( $variation_id ) : $variation_id;

		$chk_prod = wc_get_product( $product_id );
		if ( $chk_prod && $chk_prod->is_type( 'variation' ) ) {
			$variation_id = $product_id;
			$product_id   = $chk_prod->get_parent_id();
		}

		// Build redirect URL.
		$redirect_url = $switch_context['redirect_back_url'] ?? '';
		if ( empty( $redirect_url ) ) {
			$product      = wc_get_product( $product_id );
			$product_url  = $product->get_permalink();
			$redirect_url = add_query_arg(
				[
					'wp_subs_switch'  => '',
					'wpsubs_id'       => $switch_context['subscription_id'],
					'wpsubs_order_id' => $switch_context['order_id'],
					'nonce'           => $switch_context['nonce'],
				],
				$product_url
			);
		}

		$flag = true;

		// Check if the product ID matches the subscription product ID.
		if ( $flag && ( (int) wp_get_post_parent_id( $variation_id ) !== (int) $switch_context['product_id'] ) ) {
			$error_notice = __( 'You can only switch to another variation of your current subscription product.', 'subscription-pro' );
			wc_add_notice( $error_notice, 'error' );
			$flag = false;
		}

		// Check if the product selected is different from the current subscription product.
		if ( (int) $switch_context['old_variation_id'] === $variation_id ) {
			$error_notice = __( 'You are already subscribed to this product. Please select a different variation.', 'subscription-pro' );
			wc_add_notice( $error_notice, 'error' );
			$flag = false;
		}

		// "Allow downgrade" off: the cheaper plans are hidden, and refused here too.
		if ( $flag && $this->is_refused_downgrade( (int) $switch_context['old_variation_id'], (int) $variation_id ) ) {
			wc_add_notice( __( 'Downgrading this subscription is not allowed.', 'subscription-pro' ), 'error' );
			$flag = false;
		}

		// Prevent adding additional products to cart.
		if ( $flag && ( ! WC()->cart->is_empty() ) ) {
			$error_notice = __( 'You cannot switch a subscription while other items are in the cart. Please clear your cart and try again.', 'subscription-pro' );
			wc_add_notice( $error_notice, 'error' );

			WC()->session->set( 'wp_subs_switch_redirect_back_url', $redirect_url );

			return false;
		}

		// Clear cart if validation fails.
		if ( ! $flag ) {
			// Set redirect URL in session to redirect.
			WC()->session->set( 'wp_subs_switch_redirect_back_url', $redirect_url );

			// Clear cart.
			WC()->cart->empty_cart();
			return false;
		}
		return true;
	}

	/**
	 * Whether a switch is a downgrade the store does not allow.
	 *
	 * @param int $old_variation_id Current variation.
	 * @param int $new_variation_id Variation switched to.
	 *
	 * @return bool
	 */
	private function is_refused_downgrade( int $old_variation_id, int $new_variation_id ): bool {
		if ( self::get_settings( 'subscrpt_downgrade_allowed' ) ) {
			return false;
		}

		$old = wc_get_product( $old_variation_id );
		$new = wc_get_product( $new_variation_id );

		return $old && $new && (float) $new->get_price() < (float) $old->get_price();
	}

	/**
	 * Redirect after switch subscription error.
	 */
	public function maybe_redirect_after_add_to_cart_failure() {
		if ( ! WC()->session ) {
			return;
		}

		$redirect_url = WC()->session->get( 'wp_subs_switch_redirect_back_url' );

		if ( $redirect_url ) {
			WC()->session->__unset( 'wp_subs_switch_redirect_back_url' );
			wp_safe_redirect( $redirect_url );
			exit;
		}
	}

	/**
	 * Adjust order price for switch subscription.
	 *
	 * @param \WC_Cart $cart Cart object.
	 */
	public function switch_add_adjust_price( \WC_Cart $cart ) {
		if ( ! is_cart() && is_admin() && ! defined( 'DOING_AJAX' ) ) {
			return;
		}

		// Only the switch line is adjusted; anything else in the cart is paid in full.
		$line = self::find_switch_line( $cart->get_cart() );
		if ( ! $line ) {
			return;
		}

		$switch_context = $line['switch_context'];
		$old_variation  = wc_get_product( $switch_context['old_variation_id'] ?? 0 );
		$new_variation  = wc_get_product( $switch_context['new_variation_id'] ?? ( $line['variation_id'] ?? 0 ) );
		if ( ! $old_variation || ! $new_variation ) {
			return;
		}

		// Direction and amount come from the plans' prices, so a coupon on the line
		// cannot turn an upgrade into a downgrade or reduce what it costs.
		$old_price    = (float) $old_variation->get_price();
		$new_price    = (float) $new_variation->get_price();
		$is_downgrade = $new_price < $old_price;

		if ( $is_downgrade ) {
			// Deferred downgrade: nothing is charged now, the change applies at the next renewal.
			$charge_now = 0;
		} else {
			// Time-prorated upgrade: charge only the unused-time share of the price difference.
			$ratio      = $this->get_remaining_period_ratio( (int) ( $switch_context['subscription_id'] ?? 0 ) );
			$charge_now = ( $new_price - $old_price ) * $ratio;
		}

		// Offset the switch line so the customer is charged exactly the prorated amount for it.
		$cart->add_fee( __( 'Price Adjustment', 'subscription-pro' ), $charge_now - (float) ( $line['line_total'] ?? 0 ) );

		// Optional flat/percentage switch fee, on top of the prorated amount.
		$switch_fee = $this->get_switch_fee( $new_price, $is_downgrade );
		if ( $switch_fee > 0 ) {
			$cart->add_fee( __( 'Switch Fee', 'subscription-pro' ), $switch_fee );
		}
	}

	/**
	 * The cart line that carries a subscription switch, if any.
	 *
	 * @param array $cart_contents Cart lines.
	 *
	 * @return array|null
	 */
	private static function find_switch_line( $cart_contents ) {
		foreach ( (array) $cart_contents as $cart_item ) {
			if ( ! empty( $cart_item['wp_subs_switch'] ) && ! empty( $cart_item['switch_context'] ) && is_array( $cart_item['switch_context'] ) ) {
				return $cart_item;
			}
		}

		return null;
	}

	/**
	 * Refuse to check out a switch together with anything else.
	 *
	 * The price adjustment covers the switch line only, so a switch is its own order.
	 *
	 * @return void
	 */
	public function refuse_mixed_switch_cart() {
		if ( ! WC()->cart ) {
			return;
		}

		$cart_contents = WC()->cart->get_cart();
		if ( count( $cart_contents ) > 1 && self::find_switch_line( $cart_contents ) ) {
			wc_add_notice( __( 'A subscription switch must be checked out on its own. Remove the other items from your cart to continue.', 'subscription-pro' ), 'error' );
		}
	}

	/**
	 * Resolve the configured switch fee for the current switch direction.
	 *
	 * Reads the `subscrpt_switch_fee_amount`, `subscrpt_switch_fee_type`
	 * (flat|percent), and `subscrpt_switch_fee_apply_to` (both|upgrade|downgrade)
	 * options. A percentage fee is calculated against the new plan price.
	 *
	 * @param float $new_price    New plan price (percentage base).
	 * @param bool  $is_downgrade Whether the switch is a downgrade.
	 *
	 * @return float Fee amount (0 when no fee applies).
	 */
	private function get_switch_fee( float $new_price, bool $is_downgrade ): float {
		$amount = (float) self::get_settings( 'subscrpt_switch_fee_amount' );
		if ( $amount <= 0 ) {
			return 0;
		}

		$apply_to = self::get_settings( 'subscrpt_switch_fee_apply_to' );
		if ( 'upgrade' === $apply_to && $is_downgrade ) {
			return 0;
		}
		if ( 'downgrade' === $apply_to && ! $is_downgrade ) {
			return 0;
		}

		$type = self::get_settings( 'subscrpt_switch_fee_type' );
		$fee  = 'percent' === $type ? $new_price * ( $amount / 100 ) : $amount;

		return max( 0, $fee );
	}

	/**
	 * Calculate the unused fraction of the current billing cycle for a subscription.
	 *
	 * Remaining time is taken from `_subscrpt_next_date`; the full cycle length is
	 * derived from the billing interval (`_subscrpt_timing_per` / `_subscrpt_timing_option`)
	 * rather than start-to-next, so it stays correct after renewals. The result is
	 * clamped to 0–1 and defaults to 1 when it cannot be determined.
	 *
	 * @param int $subscription_id Subscription post ID.
	 *
	 * @return float Ratio between 0 and 1.
	 */
	private function get_remaining_period_ratio( int $subscription_id ): float {
		if ( ! $subscription_id ) {
			return 1.0;
		}

		$next_date = (int) get_post_meta( $subscription_id, '_subscrpt_next_date', true );
		if ( ! $next_date ) {
			return 1.0;
		}

		$timing_per    = (int) get_post_meta( $subscription_id, '_subscrpt_timing_per', true );
		$timing_option = get_post_meta( $subscription_id, '_subscrpt_timing_option', true );

		if ( $timing_per < 1 || empty( $timing_option ) ) {
			return 1.0;
		}

		$now       = time();
		$remaining = max( 0, $next_date - $now );
		$cycle_len = sdevs_wp_strtotime( $timing_per . ' ' . $timing_option, $now ) - $now;

		if ( $cycle_len <= 0 ) {
			return 1.0;
		}

		return min( 1.0, $remaining / $cycle_len );
	}

	/**
	 * Preserve the renewal date when a switch order activates the subscription.
	 *
	 * Free's generate_dates_for_subscription() (fired on subscrpt_subscription_activated)
	 * only computes a next date for 'new'/'renew'/'early-renew' histories; for an
	 * 'upgrade'/'downgrade' history it leaves the value null and would overwrite
	 * _subscrpt_next_date with it. A switch must not move the renewal date, so we
	 * return the existing stored date instead.
	 *
	 * @param int|null $next_date       Computed next due date (null for switch types).
	 * @param int      $subscription_id Subscription ID.
	 * @param string   $recurr_timing   Recurring timing string (unused).
	 * @param string   $type            Subscription history type.
	 *
	 * @return int|null
	 */
	public function preserve_next_date_on_switch( $next_date, $subscription_id, $recurr_timing, $type ) {
		if ( ! in_array( $type, [ 'upgrade', 'downgrade' ], true ) ) {
			return $next_date;
		}

		$existing = (int) get_post_meta( $subscription_id, '_subscrpt_next_date', true );

		return $existing ? $existing : $next_date;
	}

	/**
	 * Update subscription information after switch order is processed.
	 *
	 * Used for the immediate (upgrade) path. The deferred downgrade path applies
	 * the same changes at renewal via apply_variation_to_subscription().
	 *
	 * @param array     $switch_context Switch context information.
	 * @param object    $history Order relation information.
	 * @param \WC_Order $order Order object.
	 */
	public function subs_switch_update_subscription( $switch_context, $history, $order ) {
		$order_item   = $order->get_item( $history->order_item_id );
		$variation_id = $switch_context['new_variation_id'] ?? $order_item->get_variation_id();

		$subs_meta = wc_get_order_item_meta( $history->order_item_id, '_subscrpt_meta', true );

		$subscription_id = $switch_context['subscription_id'] ?? $history->subscription_id;

		if ( ! empty( $subs_meta ) ) {
			$this->apply_variation_to_subscription(
				(int) $subscription_id,
				(int) $variation_id,
				[
					'timing_per'    => $subs_meta['time'],
					'timing_option' => $subs_meta['type'],
					'trial'         => $subs_meta['trial'] ?? '',
					'order_id'      => $order_item->get_order_id(),
					'order_item_id' => $order_item->get_id(),
					'signup_fee'    => $this->get_signup_fee_from_order( $order_item->get_order() ),
				]
			);
		}
	}

	/**
	 * Write the new variation's product/timing/order meta onto a subscription.
	 *
	 * Shared by the immediate upgrade path (subs_switch_update_subscription) and the
	 * deferred downgrade path applied at renewal (apply_pending_downgrade_to_renewal).
	 * The renewal date (_subscrpt_next_date) is intentionally left untouched.
	 *
	 * @param int   $subscription_id Subscription post ID.
	 * @param int   $variation_id    New variation ID.
	 * @param array $args            Optional keys: timing_per, timing_option, trial, order_id, order_item_id, signup_fee.
	 */
	private function apply_variation_to_subscription( int $subscription_id, int $variation_id, array $args = [] ) {
		$variation = wc_get_product( $variation_id );

		// product related.
		if ( isset( $args['timing_per'] ) ) {
			update_post_meta( $subscription_id, '_subscrpt_timing_per', $args['timing_per'] );
		}
		if ( isset( $args['timing_option'] ) ) {
			update_post_meta( $subscription_id, '_subscrpt_timing_option', $args['timing_option'] );
		}
		if ( $variation ) {
			update_post_meta( $subscription_id, '_subscrpt_price', $variation->get_price() );
		}
		update_post_meta( $subscription_id, '_subscrpt_variation_id', $variation_id );

		// order related.
		if ( isset( $args['order_id'] ) ) {
			update_post_meta( $subscription_id, '_subscrpt_order_id', $args['order_id'] );
		}
		if ( isset( $args['order_item_id'] ) ) {
			update_post_meta( $subscription_id, '_subscrpt_order_item_id', $args['order_item_id'] );
		}

		// subscription related.
		if ( array_key_exists( 'trial', $args ) ) {
			update_post_meta( $subscription_id, '_subscrpt_trial', $args['trial'] );
		}
		if ( isset( $args['signup_fee'] ) ) {
			update_post_meta( $subscription_id, '_subscrpt_signup_fee', $args['signup_fee'] );
		}
	}

	/**
	 * Read the "Signup Fee" amount from an order's fee lines, if present.
	 *
	 * @param \WC_Order $order Order object.
	 *
	 * @return float|null Fee amount, or null when no signup fee line exists.
	 */
	private function get_signup_fee_from_order( $order ) {
		if ( ! $order ) {
			return null;
		}

		foreach ( $order->get_fees() as $fee ) {
			if ( 'Signup Fee' === $fee->get_name() ) {
				return $fee->get_amount();
			}
		}

		return null;
	}

	/**
	 * Schedule a downgrade to take effect at the next renewal instead of applying now.
	 *
	 * Stores the change as `_subscrpt_pending_switch` meta on the subscription and
	 * leaves the current variation, price, and renewal date untouched. The change is
	 * applied later by apply_pending_downgrade_to_renewal().
	 *
	 * @param array     $switch_context Switch context information.
	 * @param object    $history Order relation information.
	 * @param \WC_Order $order Switch order object.
	 */
	public function schedule_pending_downgrade( $switch_context, $history, $order ) {
		$order_item      = $order->get_item( $history->order_item_id );
		$variation_id    = $switch_context['new_variation_id'] ?? $order_item->get_variation_id();
		$subs_meta       = wc_get_order_item_meta( $history->order_item_id, '_subscrpt_meta', true );
		$subscription_id = (int) ( $switch_context['subscription_id'] ?? $history->subscription_id );

		if ( empty( $subscription_id ) || empty( $subs_meta ) ) {
			return;
		}

		$variation = wc_get_product( $variation_id );

		$pending = [
			'new_variation_id' => (int) $variation_id,
			'price'            => $variation ? $variation->get_price() : 0,
			'timing_per'       => $subs_meta['time'],
			'timing_option'    => $subs_meta['type'],
			'trial'            => $subs_meta['trial'] ?? '',
			'signup_fee'       => $this->get_signup_fee_from_order( $order_item->get_order() ),
			'order_id'         => $order_item->get_order_id(),
			'order_item_id'    => $order_item->get_id(),
			'switch_context'   => $switch_context,
		];

		update_post_meta( $subscription_id, '_subscrpt_pending_switch', $pending );

		// Activity note.
		$next_date = (int) get_post_meta( $subscription_id, '_subscrpt_next_date', true );
		$effective = $next_date ? date_i18n( get_option( 'date_format' ), $next_date ) : __( 'the next renewal', 'subscription-pro' );

		$comment_id = wp_insert_comment(
			array(
				'comment_author'  => 'Subscription for WooCommerce',
				'comment_content' => sprintf(
					// translators: %s: effective date.
					__( 'Downgrade scheduled — will take effect on %s.', 'subscription-pro' ),
					$effective
				),
				'comment_post_ID' => $subscription_id,
				'comment_type'    => 'order_note',
			)
		);
		update_comment_meta( $comment_id, '_subscrpt_activity', __( 'Downgrade Scheduled', 'subscription-pro' ) );
		update_comment_meta( $comment_id, '_subscrpt_activity_type', 'downgrade_scheduled' );

		/**
		 * Fires when a subscription downgrade is scheduled to apply at the next renewal.
		 *
		 * @param int       $subscription_id Subscription ID.
		 * @param array     $pending         Pending switch data.
		 * @param \WC_Order $order           Switch order that scheduled the downgrade.
		 */
		do_action( 'subscrpt_switch_scheduled', $subscription_id, $pending, $order );
	}

	/**
	 * Apply a scheduled downgrade when the subscription renews.
	 *
	 * Hooked on `subscrpt_before_saving_renewal_order` at priority 5 (before the
	 * recurring-coupon handler at 10). Rewrites the renewal order's subscription line
	 * item to the new variation/price and updates the subscription meta so future
	 * renewals follow suit, then clears the pending record.
	 *
	 * @param \WC_Order $new_order       The renewal order being built.
	 * @param \WC_Order $old_order       The source order.
	 * @param int       $subscription_id Subscription post ID.
	 *
	 * @return \WC_Order
	 */
	public function apply_pending_downgrade_to_renewal( $new_order, $old_order, $subscription_id ) {
		$subscription_id = (int) $subscription_id;
		$pending         = get_post_meta( $subscription_id, '_subscrpt_pending_switch', true );

		if ( empty( $pending ) || empty( $pending['new_variation_id'] ) ) {
			return $new_order;
		}

		$variation_id = (int) $pending['new_variation_id'];
		$variation    = wc_get_product( $variation_id );
		$new_price    = (float) ( $variation ? $variation->get_price() : ( $pending['price'] ?? 0 ) );

		// Rewrite the renewal order's subscription line item to the new variation/price.
		$line_item = null;
		foreach ( $new_order->get_items() as $item ) {
			$qty        = $item->get_quantity();
			$line_total = $new_price * $qty;

			// WC_Order will calculate tax on the line total; subtract inclusive tax first.
			if ( wc_prices_include_tax() ) {
				$tax_class  = $variation ? $variation->get_tax_class() : $item->get_tax_class();
				$tax_rates  = \WC_Tax::get_rates( $tax_class );
				$taxes      = \WC_Tax::calc_inclusive_tax( $new_price, $tax_rates );
				$line_total = ( $new_price - array_sum( $taxes ) ) * $qty;
			}

			if ( $variation ) {
				$item->set_product( $variation );
			}
			$item->set_subtotal( $line_total );
			$item->set_total( $line_total );
			$item->save();

			$line_item = $item;
			break; // only the subscription line item.
		}

		// Update the subscription so future renewals use the new variation/price.
		// Order references are intentionally omitted — the renewal flow sets them.
		$this->apply_variation_to_subscription(
			$subscription_id,
			$variation_id,
			[
				'timing_per'    => $pending['timing_per'] ?? null,
				'timing_option' => $pending['timing_option'] ?? null,
				'trial'         => $pending['trial'] ?? '',
				'signup_fee'    => $pending['signup_fee'] ?? null,
			]
		);

		// Activity note.
		$comment_id = wp_insert_comment(
			array(
				'comment_author'  => 'Subscription for WooCommerce',
				'comment_content' => sprintf(
					// translators: %s: renewal order ID.
					__( 'Scheduled downgrade applied on renewal order #%s.', 'subscription-pro' ),
					$new_order->get_id()
				),
				'comment_post_ID' => $subscription_id,
				'comment_type'    => 'order_note',
			)
		);
		update_comment_meta( $comment_id, '_subscrpt_activity', __( 'Downgrade Applied', 'subscription-pro' ) );
		update_comment_meta( $comment_id, '_subscrpt_activity_type', 'downgrade_applied' );

		$switch_context = $pending['switch_context'] ?? [];

		/**
		 * Action fired after a deferred downgrade is applied at renewal.
		 *
		 * @param string    $switch_type    Always 'downgrade'.
		 * @param \WC_Order $new_order       Renewal order the downgrade was applied to.
		 * @param mixed     $line_item       Renewal subscription line item.
		 * @param array     $switch_context Original switch context data.
		 */
		do_action( 'subscrpt_switch_completed', 'downgrade', $new_order, $line_item, $switch_context );

		delete_post_meta( $subscription_id, '_subscrpt_pending_switch' );

		return $new_order;
	}

	/**
	 * Remove a scheduled downgrade when the subscription is cancelled.
	 *
	 * Only `cancelled` is handled — `expired` precedes the renewal that applies the
	 * pending downgrade, so clearing on expiry would wipe it prematurely.
	 *
	 * @param int    $subscription_id Subscription ID.
	 * @param string $old_status      Previous status.
	 * @param string $new_status      New status.
	 */
	public function clear_pending_switch_on_cancel( $subscription_id, $old_status, $new_status ) {
		if ( 'cancelled' === $new_status ) {
			delete_post_meta( (int) $subscription_id, '_subscrpt_pending_switch' );
		}
	}
}
