<?php
/**
 * Mixed Cart — lets a Pro-active cart hold multiple subscriptions and/or a
 * subscription alongside normal products.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate
 */

namespace SpringDevs\SubscriptionPro\Illuminate;

/**
 * Class MixedCart
 *
 * @package SpringDevs\SubscriptionPro\Illuminate
 */
class MixedCart {

	/**
	 * Initialize the class.
	 */
	public function __construct() {
		add_filter( 'subscrpt_allow_multiple_subscriptions_in_cart', '__return_true' );
	}

	/**
	 * Whether the current cart is a "mixed cart": it holds more than one
	 * subscription item, or at least one subscription item alongside at least
	 * one normal (non-subscription) item.
	 *
	 * Mirrors, in reverse, exactly what the free plugin's
	 * `Frontend\Cart::validate_cart_items()` used to reject outright, so "mixed
	 * cart" means precisely "a cart free would have blocked before this feature".
	 *
	 * @return bool
	 */
	public static function is_mixed_cart() {
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return false;
		}

		$subscription_items = 0;
		$normal_items       = 0;

		foreach ( WC()->cart->get_cart_contents() as $cart_item ) {
			if ( isset( $cart_item['subscription'] ) ) {
				++$subscription_items;
			} else {
				++$normal_items;
			}
		}

		return $subscription_items > 1 || ( $subscription_items > 0 && $normal_items > 0 );
	}
}
