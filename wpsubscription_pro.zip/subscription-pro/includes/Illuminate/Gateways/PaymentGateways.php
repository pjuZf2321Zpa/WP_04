<?php
/**
 * Payment Gateways File
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Gateways
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Gateways;

use SpringDevs\Subscription\Admin\Integrations;
use SpringDevs\Subscription\Illuminate\Helper;
use SpringDevs\SubscriptionPro\Illuminate\Gateways\Mollie\Mollie;
use SpringDevs\SubscriptionPro\Illuminate\Gateways\Razorpay\Razorpay;
use SpringDevs\SubscriptionPro\Illuminate\Gateways\Xendit\Xendit;
use SpringDevs\SubscriptionPro\Illuminate\MixedCart;

/**
 * Payment Gateways Class
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Gateways
 */
class PaymentGateways {
	/**
	 * Constructor.
	 */
	public function __construct() {
		// Initialize gateways.
		$this->initialize_gateways();

		// init hook.
		add_action( 'init', [ $this, 'init' ] );

		// Register payment gateway settings. UI is defined in the free plugin (ProSettingsFields).
		add_action( 'subscrpt_register_settings', [ $this, 'register_settings_fields' ] );
	}

	/**
	 * Initialize Gateways
	 */
	public function initialize_gateways() {
		// Razorpay
		if ( class_exists( 'WC_Razorpay' ) ) {
			new Razorpay();
		}

		// Mollie
		if ( class_exists( 'Mollie\WooCommerce\Activation\ActivationModule' ) ) {
			new Mollie();
		}

		// Xendit
		if ( class_exists( 'WC_Xendit_CC' ) || class_exists( 'WC_Xendit_CC_Addons' ) ) {
			new Xendit();
		}
	}

	/**
	 * Initialize the class
	 */
	public function init() {
		// Remove hidden payment gateways from checkout.
		add_filter( 'woocommerce_available_payment_gateways', [ $this, 'filter_hidden_payment_gateways' ], 99 );

		// Remove blocks of the hidden payment gateways.
		add_action(
			'woocommerce_blocks_loaded',
			function () {
				add_action( 'woocommerce_blocks_payment_method_type_registration', [ $this, 'unregister_payment_gateway_block' ], 99 );
			},
			99
		);

		// JS Fallback for hiding payment gateways in blocks checkout.
		add_action( 'wp_footer', [ $this, 'hide_payment_gateways_js' ] );
	}

	/**
	 * Get Hidden Gateways
	 */
	public function get_hidden_gateways() {
		return get_option( 'hidden_payment_gateways', [] );
	}

	/**
	 * Register Settings Fields
	 */
	public function register_settings_fields() {
		register_setting(
			'wp_subscription_settings',
			'hidden_payment_gateways',
			[
				'type'              => 'array',
				'sanitize_callback' => [ $this, 'sanitize_multi_select_field' ],
			]
		);
	}

	/**
	 * Sanitize Multi Select Field
	 *
	 * @param mixed $value Field value.
	 */
	public function sanitize_multi_select_field( $value ) {
		if ( ! is_array( $value ) ) {
			return [];
		}
		// array_filter removes the empty sentinel emitted by wpsubs-searchable-select when nothing is selected.
		return array_values( array_filter( array_map( 'sanitize_text_field', $value ) ) );
	}

	/**
	 * Check cart for subscription products.
	 */
	public function cart_has_subscription_products() {
		$cart       = WC()->cart;
		$cart_items = $cart ? $cart->get_cart() : [];
		$recurrs    = Helper::get_recurrs_from_cart( $cart_items );
		return ! empty( $recurrs );
	}

	/**
	 * Filter Hidden Payment Gateways
	 *
	 * @param array $available_gateways Available gateways.
	 */
	public function filter_hidden_payment_gateways( $available_gateways ) {
		if ( ! is_checkout() && ! is_cart() ) {
			return $available_gateways;
		}

		// Only hide gateways if cart has subscription products
		$cart_has_subs = $this->cart_has_subscription_products();
		if ( ! $cart_has_subs ) {
			return $available_gateways;
		}

		// Get hidden payment gateways from settings
		$hidden_gateways = $this->get_hidden_gateways();

		// Remove hidden gateways from available gateways
		foreach ( $hidden_gateways as $gateway_id ) {
			if ( isset( $available_gateways[ $gateway_id ] ) ) {
				unset( $available_gateways[ $gateway_id ] );
			}
		}

		$available_gateways = $this->hide_mixed_cart_incompatible_gateways( $available_gateways );

		return $available_gateways;
	}

	/**
	 * Remove gateways that can't yet handle a mixed cart (2+ subscriptions, or a
	 * subscription plus a normal product) from checkout.
	 *
	 * Free's PayPal integration assumes exactly one subscription per order at
	 * checkout (and its webhook fallback only resolves the first subscription on
	 * an order) — it would silently mis-process every subscription past the first
	 * in a mixed cart, so it's hidden here rather than fixed there.
	 *
	 * @param array $available_gateways Available gateways.
	 *
	 * @return array
	 */
	private function hide_mixed_cart_incompatible_gateways( $available_gateways ) {
		if ( ! MixedCart::is_mixed_cart() ) {
			return $available_gateways;
		}

		/**
		 * Filters which gateway ids are hidden at checkout for a mixed cart.
		 *
		 * @param string[] $gateway_ids        Gateway ids to hide. Default: PayPal only.
		 * @param array    $available_gateways Available gateways before this pass.
		 */
		$incompatible_gateways = apply_filters( 'subscrpt_mixed_cart_incompatible_gateways', [ 'wp_subscription_paypal' ], $available_gateways );

		foreach ( $incompatible_gateways as $gateway_id ) {
			if ( isset( $available_gateways[ $gateway_id ] ) ) {
				unset( $available_gateways[ $gateway_id ] );

				wc_get_logger()->info(
					sprintf(
						'Hid payment gateway "%s" at checkout: cart is a mixed cart (multiple subscriptions and/or a subscription plus a normal product).',
						$gateway_id
					),
					[ 'source' => 'subscription-pro' ]
				);
			}
		}

		return $available_gateways;
	}

	/**
	 * Unregister Payment Gateway Block
	 *
	 * @param object $payment_method_registry Payment method registry.
	 */
	public function unregister_payment_gateway_block( $payment_method_registry ) {
		if ( ! is_checkout() && ! is_cart() ) {
			return;
		}

		$cart_has_subs = $this->cart_has_subscription_products();
		if ( ! $cart_has_subs ) {
			return;
		}

		// Get hidden gateways
		$hidden_gateways = $this->get_hidden_gateways();

		$all_registered = $payment_method_registry->get_all_registered();

		// Unregister each hidden gateway
		foreach ( $hidden_gateways as $gateway_id ) {
			if ( array_key_exists( $gateway_id, $all_registered ) ) {
				$payment_method_registry->unregister( $gateway_id );
			}
		}
	}

	/**
	 * Hide Payment Gateways JS
	 */
	public function hide_payment_gateways_js() {
		if ( ! is_checkout() && ! is_cart() ) {
			return;
		}

		$hidden_gateways = $this->get_hidden_gateways();

		if ( empty( $hidden_gateways ) ) {
			return;
		}

		$gateway_ids = array_map( 'esc_js', $hidden_gateways );
		?>
		<script type="text/javascript">
		(function() {
			'use strict';
			
			const hiddenGateways = <?php echo wp_json_encode( $gateway_ids ); ?>;
			
			function hidePaymentGateways() {
				hiddenGateways.forEach(function(gatewayId) {
					// Target the label by its 'for' attribute
					const selector = 'label[for="radio-control-wc-payment-method-options-' + gatewayId + '"]';
					const labels = document.querySelectorAll(selector);
					
					labels.forEach(function(label) {
						// Find the parent accordion option div
						const parentDiv = label.closest('.wc-block-components-radio-control-accordion-option');
						if (parentDiv) {
							parentDiv.style.display = 'none';
						}
					});
					
					// Also hide saved payment method tokens for this gateway
					const savedTokenSelector = 'label[for^="radio-control-wc-payment-method-saved-tokens-"][for*="' + gatewayId + '"]';
					const savedTokens = document.querySelectorAll(savedTokenSelector);
					
					savedTokens.forEach(function(token) {
						const parentDiv = token.closest('.wc-block-components-radio-control__option');
						if (parentDiv) {
							parentDiv.style.display = 'none';
						}
					});
				});
			}

			function hideExpressCheckout() {
				// Target the express payment content container
				const expressContainer = document.querySelector('.wc-block-components-express-payment__content');
				
				if (!expressContainer) {
					return;
				}
				
				hiddenGateways.forEach(function(gatewayId) {
					// Find all elements within the express payment container that have the gateway ID in their class or id
					// Example: id="express-payment-method-paymentplugins_ppcp_express" contains "ppcp"
					const selector = '[id*="' + gatewayId + '"], [class*="' + gatewayId + '"]';
					const gatewayElements = expressContainer.querySelectorAll(selector);
					
					gatewayElements.forEach(function(el) {
						if(el.style.display !== 'none'){
							el.style.display = 'none';
						}
					});
				});
			}
			
			// Continuously check for changes in the number of gateways when
			let lastGatewayCount = 0;
			function checkAndHide() {
				const currentGatewayCount = document.querySelectorAll('.wc-block-components-radio-control-accordion-option').length;
				
				// Only run hiding logic if gateway count changed
				if (currentGatewayCount !== lastGatewayCount) {
					console.log('Gateway count changed:', lastGatewayCount, '->', currentGatewayCount);

					hidePaymentGateways();
					lastGatewayCount = currentGatewayCount;
				}

				// Always attempt to hide express checkout methods
				// hideExpressCheckout();
				
				// Continue checking but only when browser is ready to paint
				requestAnimationFrame(checkAndHide);
			}

			// Start the efficient polling
			requestAnimationFrame(checkAndHide);

			// Hide express checkout on initial load
			window.addEventListener('load', function() {
				hideExpressCheckout();
			});
			
			// Also listen for WooCommerce checkout update events
			if (typeof jQuery !== 'undefined') {
				jQuery(document.body).on('updated_checkout checkout_updated', function() {
					hidePaymentGateways();
					hideExpressCheckout();
				});
			}
		})();
		</script>
		<?php
	}
}
