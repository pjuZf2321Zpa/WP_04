<?php
/**
 * Which month a box belongs to.
 *
 * Every screen in this feature has to answer "which box is this?" and the only
 * answer a merchant recognises is a month — "the October box" — not a renewal
 * timestamp. Nobody else in this market names the cycle; they all show a raw
 * date, which is why their pick lists read like database exports.
 *
 * Cycles are months on purpose. A weekly box renewing four times in October is
 * still one October box: that is what a merchant means when they plan it, pack
 * it and talk about it.
 *
 * This is the only place that decides any of that, so a cycle reads the same in
 * the shipment list, the pick list, the CSV export and the email.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Box
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Box;

defined( 'ABSPATH' ) || exit;

/**
 * Turns timestamps into cycles, and cycles into words.
 */
class BoxCycle {

	/**
	 * The cycle a timestamp falls in.
	 *
	 * @param int $timestamp Unix timestamp.
	 *
	 * @return string e.g. 2026-10.
	 */
	public static function key( int $timestamp ): string {
		return gmdate( 'Y-m', $timestamp );
	}

	/**
	 * The cycle happening now.
	 *
	 * @return string
	 */
	public static function current(): string {
		return self::key( (int) current_time( 'timestamp' ) ); // phpcs:ignore WordPress.DateTime.CurrentTimeTimestamp.Requested
	}

	/**
	 * A cycle in words, in the site's language.
	 *
	 * @param string $cycle_key Cycle key.
	 *
	 * @return string e.g. October 2026.
	 */
	public static function label( string $cycle_key ): string {
		$start = self::start( $cycle_key );

		return $start ? date_i18n( 'F Y', $start ) : $cycle_key;
	}

	/**
	 * When a cycle begins.
	 *
	 * @param string $cycle_key Cycle key.
	 *
	 * @return int Timestamp, or 0 when the key is not a cycle.
	 */
	public static function start( string $cycle_key ): int {
		if ( ! preg_match( '/^\d{4}-\d{2}$/', $cycle_key ) ) {
			return 0;
		}

		// UTC, to match `key()`, which reads the month with gmdate. Resolving
		// this one in the server's timezone instead would put a box renewing
		// near midnight on the 1st into one month and label it with another —
		// invisible on a UTC bench, and wrong on a store set to anywhere else.
		return (int) strtotime( $cycle_key . '-01 00:00:00 UTC' );
	}

	/**
	 * The half-open bounds of a cycle: start inclusive, end exclusive.
	 *
	 * @param string $cycle_key Cycle key.
	 *
	 * @return array{0:int,1:int}
	 */
	public static function bounds( string $cycle_key ): array {
		$start = self::start( $cycle_key );

		if ( ! $start ) {
			return array( 0, 0 );
		}

		return array( $start, (int) strtotime( '+1 month', $start ) );
	}

	/**
	 * Cycles from this one forward, for a planner or a filter.
	 *
	 * @param int $count How many, including the current cycle.
	 *
	 * @return array[] Each entry: key, label.
	 */
	public static function upcoming( int $count = 6 ): array {
		$cycles = array();
		$now    = (int) current_time( 'timestamp' ); // phpcs:ignore WordPress.DateTime.CurrentTimeTimestamp.Requested

		for ( $i = 0; $i < max( 1, $count ); $i++ ) {
			$stamp = (int) strtotime( "+{$i} month", $now );
			$key   = self::key( $stamp );

			$cycles[] = array(
				'key'   => $key,
				'label' => self::label( $key ),
			);
		}

		return $cycles;
	}
}
