<?php
/**
 * The box cart service over the Store API and a classic endpoint.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Box
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Box;

use Automattic\WooCommerce\StoreApi\Exceptions\RouteException;
use Automattic\WooCommerce\StoreApi\Schemas\V1\CartSchema;

defined( 'ABSPATH' ) || exit;

/**
 * Lets a page change the box line in the shopper's cart.
 *
 * The block cart and block checkout call the Store API update callback, which
 * carries WooCommerce's own Store API nonce; classic themes call the nonced
 * `wc-ajax` endpoint. Both take the same three fields, `action`, `cart_key` and
 * `items`, clean them, and hand them to `BoxCartService`.
 *
 * The contract for the scripts that call them:
 *
 * - Store API: `extensionCartUpdate( { namespace: 'subscrpt-box', data } )`
 *   resolves for every decision the service makes, `ok`, `needs_replace` and
 *   `invalid` alike; it rejects only for a malformed request (an unknown
 *   action, 400). The decision arrives on the cart that comes back, at
 *   `extensions['subscrpt-box'].result`: the service's result plus
 *   `cart_hash`, the same body the classic endpoint answers with. The result is
 *   served once, to the first cart response after the update, and is `null` in
 *   every cart after that (and in any cart nothing was updated for).
 * - Classic: POST `nonce`, `action`, `cart_key`, `items` to
 *   `subscrptBoxCart.url`. 403 for a bad nonce, 400 for an unknown action, 200
 *   with the result for everything else.
 *
 * There is no ownership check beyond that: the cart is the shopper's own
 * session cart, so a cart key that is not in it finds nothing to change.
 */
class BoxCartEndpoints {

	/**
	 * The one namespace this feature uses in the Store API, for the update
	 * callback and for the endpoint data alike.
	 */
	const STORE_API_NAMESPACE = 'subscrpt-box';

	/**
	 * Nonce action of the classic endpoint.
	 */
	const NONCE_ACTION = 'subscrpt_box_cart';

	/**
	 * The `wc-ajax` endpoint name.
	 */
	const AJAX_ENDPOINT = 'subscrpt_box_cart';

	/**
	 * Session key holding the last decision until the cart response serves it.
	 */
	const SESSION_KEY = 'subscrpt_box_result';

	/**
	 * Script handle that carries `subscrptBoxCart`.
	 */
	const SCRIPT_HANDLE = 'subscrpt_box_cart_js';

	/**
	 * Register hooks.
	 */
	public function __construct() {
		add_action( 'woocommerce_blocks_loaded', [ $this, 'register_store_api' ] );
		add_action( 'wc_ajax_' . self::AJAX_ENDPOINT, [ __CLASS__, 'classic' ] );
		add_action( 'wc_ajax_nopriv_' . self::AJAX_ENDPOINT, [ __CLASS__, 'classic' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'localise' ] );
	}

	/**
	 * Register the Store API update callback, when the block cart is there.
	 *
	 * @return void
	 */
	public function register_store_api(): void {
		if ( ! function_exists( 'woocommerce_store_api_register_update_callback' ) ) {
			return;
		}

		woocommerce_store_api_register_update_callback(
			[
				'namespace' => self::STORE_API_NAMESPACE,
				'callback'  => [ __CLASS__, 'store_api' ],
			]
		);

		if ( function_exists( 'woocommerce_store_api_register_endpoint_data' ) && class_exists( CartSchema::class ) ) {
			woocommerce_store_api_register_endpoint_data(
				[
					'endpoint'        => CartSchema::IDENTIFIER,
					'namespace'       => self::STORE_API_NAMESPACE,
					'data_callback'   => [ __CLASS__, 'cart_data' ],
					'schema_callback' => [ __CLASS__, 'cart_schema' ],
					'schema_type'     => ARRAY_A,
				]
			);
		}
	}

	/**
	 * What the cart response carries under this feature's namespace: the last
	 * decision, once, then null.
	 *
	 * @return array{result:array|null}
	 */
	public static function cart_data(): array {
		$session = function_exists( 'WC' ) ? WC()->session : null;
		$result  = null;

		if ( is_object( $session ) ) {
			$stashed = $session->get( self::SESSION_KEY );
			$result  = is_array( $stashed ) ? $stashed : null;

			if ( null !== $stashed ) {
				$session->set( self::SESSION_KEY, null );
			}
		}

		return [ 'result' => $result ];
	}

	/**
	 * The shape of `cart_data()`, for the Store API schema.
	 *
	 * @return array
	 */
	public static function cart_schema(): array {
		return [
			'result' => [
				'description' => __( 'The outcome of the last change to the box in the cart, shown once; null when there was none.', 'subscription-pro' ),
				'type'        => [ 'object', 'null' ],
				'context'     => [ 'view', 'edit' ],
				'readonly'    => true,
				'properties'  => [
					'status'    => [
						'description' => __( 'ok, needs_replace or invalid.', 'subscription-pro' ),
						'type'        => 'string',
						'enum'        => [ BoxCartService::STATUS_OK, BoxCartService::STATUS_NEEDS_REPLACE, BoxCartService::STATUS_INVALID ],
					],
					'message'   => [
						'description' => __( 'Why the change was not made, or empty.', 'subscription-pro' ),
						'type'        => 'string',
					],
					'cart_key'  => [
						'description' => __( 'Cart item key of the box line after the change.', 'subscription-pro' ),
						'type'        => 'string',
					],
					'cart_hash' => [
						'description' => __( 'The cart hash after the change.', 'subscription-pro' ),
						'type'        => 'string',
					],
					'added'     => [
						'description' => __( 'Items added by add-items.', 'subscription-pro' ),
						'type'        => 'array',
					],
					'skipped'   => [
						'description' => __( 'Items add-items left alone because the box already held them.', 'subscription-pro' ),
						'type'        => 'array',
					],
					'incoming'  => [
						'description' => __( 'Items add-items was asked to add that were not in the box.', 'subscription-pro' ),
						'type'        => 'array',
					],
					'max'       => [
						'description' => __( 'The box maximum, given when add-items needs a replacement.', 'subscription-pro' ),
						'type'        => 'integer',
					],
					'current'   => [
						'description' => __( 'What the box held when add-items was asked.', 'subscription-pro' ),
						'type'        => 'array',
					],
				],
			],
		];
	}

	/**
	 * Hand the classic endpoint's address and nonce to the page.
	 *
	 * The handle has no file of its own: the scripts that call these endpoints
	 * depend on it, and WordPress prints the data before them.
	 *
	 * @return void
	 */
	public function localise(): void {
		if ( ! function_exists( 'is_cart' ) || ! ( is_cart() || is_product() ) ) {
			return;
		}

		wp_register_script( self::SCRIPT_HANDLE, false, [], SUBSCRIPT_PRO_VERSION, true );
		wp_enqueue_script( self::SCRIPT_HANDLE );
		wp_localize_script(
			self::SCRIPT_HANDLE,
			'subscrptBoxCart',
			[
				'url'   => class_exists( 'WC_AJAX' ) ? \WC_AJAX::get_endpoint( self::AJAX_ENDPOINT ) : add_query_arg( 'wc-ajax', self::AJAX_ENDPOINT, home_url( '/' ) ),
				'nonce' => wp_create_nonce( self::NONCE_ACTION ),
			]
		);
	}

	/**
	 * The Store API update callback.
	 *
	 * Whatever the service decides is stored in the session for the cart
	 * response to serve (see `cart_data()`); only a request that is not one of
	 * ours is an error.
	 *
	 * @param array $data Request data: action, cart_key, items.
	 *
	 * @return void
	 *
	 * @throws RouteException When the action is unknown.
	 */
	public static function store_api( $data ): void {
		$result = self::run( is_array( $data ) ? $data : [] );

		if ( null === $result ) {
			// phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped -- The Store API escapes its errors.
			throw new RouteException(
				'subscrpt_box_unknown_action',
				__( 'That is not something a box cart can do.', 'subscription-pro' ),
				400
			);
			// phpcs:enable WordPress.Security.EscapeOutput.ExceptionNotEscaped
		}

		$session = function_exists( 'WC' ) ? WC()->session : null;

		if ( is_object( $session ) ) {
			$session->set( self::SESSION_KEY, self::with_hash( $result ) );
		}
	}

	/**
	 * The classic `wc-ajax` endpoint.
	 *
	 * Answers 403 without a valid nonce and 400 for an unknown action. Anything
	 * the service decides, including a box that is full, is a 200 whose `status`
	 * says which, and every answer carries the new `cart_hash`.
	 *
	 * @return void
	 */
	public static function classic(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified just below, from this same array.
		$request = wp_unslash( $_POST );
		$nonce   = isset( $request['nonce'] ) && is_string( $request['nonce'] ) ? sanitize_text_field( $request['nonce'] ) : '';

		if ( ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) ) {
			wp_send_json(
				[
					'status'  => BoxCartService::STATUS_INVALID,
					'message' => __( 'Your session has expired. Reload the page and try again.', 'subscription-pro' ),
				],
				403
			);
		}

		$result = self::run( $request );

		if ( null === $result ) {
			wp_send_json(
				[
					'status'  => BoxCartService::STATUS_INVALID,
					'message' => __( 'That is not something a box cart can do.', 'subscription-pro' ),
				],
				400
			);
		}

		$result = self::with_hash( $result );

		wp_send_json( $result );
	}

	/**
	 * The result with the cart's hash after the change.
	 *
	 * @param array $result The service's result.
	 *
	 * @return array
	 */
	private static function with_hash( array $result ): array {
		$cart = function_exists( 'WC' ) ? WC()->cart : null;

		$result['cart_hash'] = is_object( $cart ) && method_exists( $cart, 'get_cart_hash' ) ? (string) $cart->get_cart_hash() : '';

		return $result;
	}

	/**
	 * Clean the request and run its action.
	 *
	 * @param array $data Raw request data.
	 *
	 * @return array|null The service's result, or null for an action that is not one of ours.
	 */
	private static function run( array $data ): ?array {
		$action   = isset( $data['action'] ) && is_string( $data['action'] ) ? sanitize_text_field( $data['action'] ) : '';
		$cart_key = isset( $data['cart_key'] ) && is_string( $data['cart_key'] ) ? self::clean_key( $data['cart_key'] ) : '';
		$items    = self::clean_items( $data['items'] ?? [] );

		switch ( $action ) {
			case 'add-items':
				return BoxCartService::add_items( $cart_key, $items );

			case 'set-contents':
				return BoxCartService::set_contents( $cart_key, $items );
		}

		return null;
	}

	/**
	 * A cart item key is an md5, so letters and digits are all it can hold.
	 *
	 * @param string $key Raw key.
	 *
	 * @return string
	 */
	private static function clean_key( string $key ): string {
		return (string) preg_replace( '/[^A-Za-z0-9]/', '', $key );
	}

	/**
	 * Items as whole numbers and a flag, from an array or a JSON string.
	 *
	 * @param mixed $raw Raw items.
	 *
	 * @return array[] Entries of product_id, variation_id, qty and, when set, once.
	 */
	private static function clean_items( $raw ): array {
		if ( is_string( $raw ) ) {
			$raw = json_decode( $raw, true );
		}

		if ( ! is_array( $raw ) ) {
			return [];
		}

		$items = [];

		foreach ( $raw as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			$clean = [
				'product_id'   => absint( $item['product_id'] ?? 0 ),
				'variation_id' => absint( $item['variation_id'] ?? 0 ),
				'qty'          => absint( $item['qty'] ?? 1 ),
			];

			if ( in_array( $item['once'] ?? false, [ true, 1, '1', 'true', 'yes', 'on' ], true ) ) {
				$clean['once'] = true;
			}

			$items[] = $clean;
		}

		return $items;
	}
}
