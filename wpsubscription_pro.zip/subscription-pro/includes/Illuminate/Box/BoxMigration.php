<?php
/**
 * Turning boxes that live in product meta into boxes that live in rows.
 *
 * Every box built before the Boxes screen existed is a product carrying a dozen
 * `_subscrpt_box*` metas. Nothing converted them, so an upgrade would simply
 * stop those products being boxes — mid-subscription, with the renewal builder
 * finding no contents and the storefront showing no builder. The customer would
 * be the one to notice.
 *
 * This runs once, on the schema bump. It reads each legacy product and writes
 * the box it describes as a row, then connects that row back to the product it
 * came from, so the product carries on selling exactly what it sold.
 *
 * It is deliberately conservative: it never deletes the old meta. The legacy
 * read path stays until the migration has been in the wild long enough to
 * trust, and a box that already has a connection is left alone, so running it
 * twice changes nothing.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Box
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Box;

defined( 'ABSPATH' ) || exit;

/**
 * One-time conversion of meta boxes into box records.
 */
class BoxMigration {

	/**
	 * Option recording that the conversion has run.
	 */
	const DONE_OPTION = 'subscrpt_box_meta_migrated';

	/**
	 * Marker meta, from before boxes became records.
	 */
	const LEGACY_ENABLED = '_subscrpt_box';

	/**
	 * Box type meta.
	 */
	const LEGACY_TYPE = '_subscrpt_box_type';

	/**
	 * Curated contents meta.
	 */
	const LEGACY_ITEMS = '_subscrpt_box_items';

	/**
	 * Eligible-pool meta.
	 */
	const LEGACY_POOL = '_subscrpt_box_pool';

	/**
	 * Default picks meta.
	 */
	const LEGACY_DEFAULTS = '_subscrpt_box_defaults';

	/**
	 * Minimum items meta.
	 */
	const LEGACY_SIZE_MIN = '_subscrpt_box_size_min';

	/**
	 * Maximum items meta.
	 */
	const LEGACY_SIZE_MAX = '_subscrpt_box_size_max';

	/**
	 * Most units of one product meta.
	 */
	const LEGACY_MAX_PER_ITEM = '_subscrpt_box_max_per_item';

	/**
	 * Whether subscribers may change contents.
	 */
	const LEGACY_ALLOW_EDIT = '_subscrpt_box_allow_edit';

	/**
	 * Days before renewal that contents lock.
	 */
	const LEGACY_LOCK_DAYS = '_subscrpt_box_lock_days';

	/**
	 * Whether subscribers may skip a box.
	 */
	const LEGACY_ALLOW_SKIP = '_subscrpt_box_allow_skip';

	/**
	 * Most skips in a row.
	 */
	const LEGACY_MAX_SKIPS = '_subscrpt_box_max_skips';

	/**
	 * Out-of-stock behaviour.
	 */
	const LEGACY_STOCK_RULE = '_subscrpt_box_stock_rule';

	/**
	 * Convert every legacy box, unless this has already been done.
	 *
	 * @return int How many products were converted.
	 */
	public static function run(): int {
		if ( get_option( self::DONE_OPTION ) ) {
			return 0;
		}

		$converted = 0;

		foreach ( self::legacy_product_ids() as $product_id ) {
			if ( self::convert( $product_id ) ) {
				++$converted;
			}
		}

		// Editions are keyed on the box now, and the rows that need a box id are
		// exactly the ones whose boxes were just created — so this runs here,
		// after them, rather than racing them from the installer.
		EditionRepository::backfill_box_ids();

		update_option( self::DONE_OPTION, time() );
		BoxRepository::flush_cache();

		return $converted;
	}

	/**
	 * Products marked as a box in the old tab.
	 *
	 * Queries the meta directly rather than through WC_Product_Query: a product
	 * whose type WooCommerce no longer recognises still has its meta, and this
	 * has to reach those too.
	 *
	 * @return int[]
	 */
	private static function legacy_product_ids(): array {
		global $wpdb;

		// phpcs:disable WordPress.DB.DirectDatabaseQuery
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value = %s",
				self::LEGACY_ENABLED,
				'yes'
			)
		);
		// phpcs:enable

		return array_values( array_filter( array_map( 'absint', (array) $ids ) ) );
	}

	/**
	 * Convert one product, if it has not been converted already.
	 *
	 * @param int $product_id Legacy box product.
	 *
	 * @return bool Whether a box was created.
	 */
	private static function convert( int $product_id ): bool {
		// Already connected to a box: either this ran before, or a merchant has
		// since done it by hand. Either way the row wins and the meta is stale.
		if ( BoxRepository::resolve_for_product( $product_id ) ) {
			return false;
		}

		$box_id = BoxRepository::save( self::columns_from_meta( $product_id ) );

		if ( ! $box_id ) {
			return false;
		}

		BoxRepository::attach( $box_id, $product_id );

		// A variable box sold its sizes as variations, each with its own numbers.
		// Those are a fact about the connection, so they become per-variation
		// overrides on their own relations rather than separate boxes.
		foreach ( self::variation_sizes( $product_id ) as $variation_id => $size ) {
			BoxRepository::attach( $box_id, $product_id, $variation_id, array( 'size' => $size ) );
		}

		return true;
	}

	/**
	 * The box a legacy product describes, in the shape `save()` takes.
	 *
	 * @param int $product_id Legacy box product.
	 *
	 * @return array
	 */
	private static function columns_from_meta( int $product_id ): array {
		$title = get_the_title( $product_id );
		$pool  = get_post_meta( $product_id, self::LEGACY_POOL, true );
		$lock  = get_post_meta( $product_id, self::LEGACY_LOCK_DAYS, true );

		// One bound meant exactly that many. This can run after the size
		// migration has marked itself done, so it writes both bounds itself.
		$size = BoxSizeMigration::normalise(
			array(
				'min' => (int) get_post_meta( $product_id, self::LEGACY_SIZE_MIN, true ),
				'max' => (int) get_post_meta( $product_id, self::LEGACY_SIZE_MAX, true ),
			)
		);

		return array(
			// The box takes the product's own name. A merchant recognises it that
			// way, and the Boxes screen is the first place they will look for it.
			'title'        => '' === (string) $title ? __( 'Subscription box', 'subscription-pro' ) : $title,
			'type'         => (string) get_post_meta( $product_id, self::LEGACY_TYPE, true ),
			// Live boxes stay live: this product is already being sold.
			'status'       => Box::STATUS_ACTIVE,
			'size_min'     => $size['min'],
			'size_max'     => $size['max'],
			'max_per_item' => (int) get_post_meta( $product_id, self::LEGACY_MAX_PER_ITEM, true ),
			'allow_edit'   => 'yes' === get_post_meta( $product_id, self::LEGACY_ALLOW_EDIT, true ),
			'allow_skip'   => 'yes' === get_post_meta( $product_id, self::LEGACY_ALLOW_SKIP, true ),
			'max_skips'    => (int) get_post_meta( $product_id, self::LEGACY_MAX_SKIPS, true ),
			'stock_rule'   => (string) get_post_meta( $product_id, self::LEGACY_STOCK_RULE, true ),
			// An unset lock window means "use the store setting", which is not
			// zero days, so an empty string has to survive as an empty string.
			'lock_days'    => '' === (string) $lock ? '' : (int) $lock,
			'pool'         => is_array( $pool ) ? $pool : array(),
			'defaults'     => (array) get_post_meta( $product_id, self::LEGACY_DEFAULTS, true ),
			'items'        => (array) get_post_meta( $product_id, self::LEGACY_ITEMS, true ),
		);
	}

	/**
	 * Per-variation sizes on a legacy variable box.
	 *
	 * @param int $product_id Legacy box product.
	 *
	 * @return array<int,array{min:int,max:int}>
	 */
	private static function variation_sizes( int $product_id ): array {
		$product = wc_get_product( $product_id );

		if ( ! $product instanceof \WC_Product || ! $product->is_type( 'variable' ) ) {
			return array();
		}

		$sizes = array();

		foreach ( $product->get_children() as $variation_id ) {
			$min = get_post_meta( $variation_id, self::LEGACY_SIZE_MIN, true );
			$max = get_post_meta( $variation_id, self::LEGACY_SIZE_MAX, true );

			if ( '' === (string) $min && '' === (string) $max ) {
				continue;
			}

			$sizes[ (int) $variation_id ] = BoxSizeMigration::normalise(
				array(
					'min' => (int) $min,
					'max' => (int) $max,
				)
			);
		}

		return $sizes;
	}
}
