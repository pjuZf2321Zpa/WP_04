<?php
/**
 * Which products get boxed together.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Box
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Box;

defined( 'ABSPATH' ) || exit;

/**
 * The co-purchase index behind Frequently Bought Together.
 *
 * What subscribers actually hold in live boxes decides the order products are
 * suggested in. The index is one row per box in a transient, rebuilt a few
 * minutes after a box's contents change and again every night, so a product
 * page never reads the subscriptions. A store too new to have real pairs falls
 * back to the box's own starting picks, then to its pool in order.
 */
class BoxTogether {

	/**
	 * Observations a product needs before its pairs outrank the box's own picks.
	 */
	const MIN_PAIRS = 5;

	/**
	 * Fewest products a section can show: this one and something to go with it.
	 */
	const MIN_ITEMS = 2;

	/**
	 * Products suggested for a box that sets neither bound.
	 */
	const DEFAULT_COUNT = 3;

	/**
	 * Partners kept per product. The rest would never be shown.
	 */
	const PARTNERS_KEPT = 20;

	/**
	 * Single event that rebuilds one box's index.
	 */
	const REBUILD_HOOK = 'subscrpt_box_pairs_rebuild';

	/**
	 * Daily event that rebuilds every active box's index.
	 */
	const NIGHTLY_HOOK = 'subscrpt_box_pairs_nightly';

	/**
	 * Seconds a change waits, so a burst of edits costs one rebuild.
	 */
	const REBUILD_DELAY = 300;

	/**
	 * Register hooks.
	 */
	public function __construct() {
		add_action( 'subscrpt_box_contents_changed', array( $this, 'schedule_rebuild' ) );
		add_action( self::REBUILD_HOOK, array( __CLASS__, 'rebuild' ) );
		add_action( self::NIGHTLY_HOOK, array( __CLASS__, 'rebuild_all' ) );
	}

	/**
	 * Drop every scheduled rebuild: each box's pending one, whatever box it is
	 * for, and the nightly one.
	 *
	 * @return void
	 */
	public static function unschedule(): void {
		wp_unschedule_hook( self::REBUILD_HOOK );
		wp_unschedule_hook( self::NIGHTLY_HOOK );
	}

	/**
	 * Count how often each pair of products is held in the same box.
	 *
	 * A product counts once per subscription, whatever its quantity, variation
	 * or whether it ships every box or once: a subscriber holding it both ways
	 * is one observation.
	 *
	 * @param array $contents One contents list per subscription.
	 *
	 * @return array<int,array<int,int>> product => partner => subscriptions holding both.
	 */
	public static function count_pairs( array $contents ): array {
		$pairs = array();

		foreach ( $contents as $rows ) {
			$ids = array();

			foreach ( BoxProduct::normalise_items( $rows ) as $row ) {
				$ids[ $row['product_id'] ] = $row['product_id'];
			}

			foreach ( $ids as $a ) {
				foreach ( $ids as $b ) {
					if ( $a !== $b ) {
						$pairs[ $a ][ $b ] = ( $pairs[ $a ][ $b ] ?? 0 ) + 1;
					}
				}
			}
		}

		return $pairs;
	}

	/**
	 * Put suggestions in order: the most co-picked, the box's picks, the pool.
	 *
	 * The product itself leads. The list stops at `$count`, and is empty when
	 * the product cannot go in a box or fewer than `$minimum` can be found,
	 * because a section with nothing to pair is not a section.
	 *
	 * @param int      $product_id The product being viewed.
	 * @param array    $pairs      The box's index, from `pairs()`.
	 * @param int[]    $defaults   The box's starting picks, in order.
	 * @param int[]    $pool       The box's pool, in order.
	 * @param int      $count      How many to return, this product included.
	 * @param callable $eligible   Takes a product id, returns whether it can go in the box.
	 * @param int      $minimum    Fewest products worth a section.
	 *
	 * @return int[]
	 */
	public static function rank( int $product_id, array $pairs, array $defaults, array $pool, int $count, callable $eligible, int $minimum = self::MIN_ITEMS ): array {
		if ( ! $eligible( $product_id ) ) {
			return array();
		}

		$partners = $pairs[ $product_id ] ?? array();
		$ordered  = array();

		if ( array_sum( $partners ) >= self::MIN_PAIRS ) {
			$ids = array_keys( $partners );

			usort(
				$ids,
				static function ( $a, $b ) use ( $partners ) {
					$by_count = $partners[ $b ] <=> $partners[ $a ];

					return 0 !== $by_count ? $by_count : $a <=> $b;
				}
			);

			$ordered = $ids;
		}

		$ranked = array( $product_id );

		foreach ( array_merge( $ordered, $defaults, $pool ) as $id ) {
			if ( count( $ranked ) >= $count ) {
				break;
			}

			$id = (int) $id;

			if ( ! in_array( $id, $ranked, true ) && $eligible( $id ) ) {
				$ranked[] = $id;
			}
		}

		return count( $ranked ) >= max( self::MIN_ITEMS, $minimum ) ? $ranked : array();
	}

	/**
	 * How many products a section pre-selects for a box.
	 *
	 * Its minimum, else its maximum, else three. A box with no maximum has no
	 * number of its own beyond that.
	 *
	 * @param Box $box The box.
	 *
	 * @return int
	 */
	public static function starting_count( Box $box ): int {
		$size = $box->size();

		if ( $size['min'] > 0 ) {
			return $size['min'];
		}

		return $size['max'] > 0 ? $size['max'] : self::DEFAULT_COUNT;
	}

	/**
	 * Could a shopper put one unit of this product in the box?
	 *
	 * A suggestion is always one unit, so the box's per-product cap cannot be
	 * exceeded by it. Variable products are left out until a box can hold a
	 * variation.
	 *
	 * @param int $product_id Product id.
	 * @param Box $box        The box. Unused today; the signature is the seam a per-box rule would use.
	 *
	 * @return bool
	 */
	public static function eligible( int $product_id, Box $box ): bool {
		unset( $box );

		$product = wc_get_product( $product_id );

		if ( ! $product instanceof \WC_Product
			|| ! $product->is_purchasable()
			|| $product->is_type( 'variable' )
			|| BoxProduct::is_box( $product ) ) {
			return false;
		}

		return BoxStock::can_supply(
			array(
				'product_id'   => $product_id,
				'variation_id' => 0,
				'qty'          => 1,
			)
		);
	}

	/**
	 * The index for a box.
	 *
	 * @param int $box_id Box id.
	 *
	 * @return array<int,array<int,int>>
	 */
	public static function pairs( int $box_id ): array {
		$stored = get_transient( self::transient_key( $box_id ) );

		if ( is_array( $stored ) ) {
			return $stored;
		}

		return self::rebuild( $box_id );
	}

	/**
	 * Read the live subscriptions of a box and store what they hold together.
	 *
	 * One query, however many subscriptions the box has.
	 *
	 * @param int $box_id Box id.
	 *
	 * @return array<int,array<int,int>> The index that was stored.
	 */
	public static function rebuild( $box_id ): array {
		global $wpdb;

		$box_id = absint( $box_id );

		if ( ! $box_id ) {
			return array();
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT contents.meta_value
				FROM {$wpdb->postmeta} AS contents
				INNER JOIN {$wpdb->postmeta} AS held ON held.post_id = contents.post_id AND held.meta_key = %s AND held.meta_value = %s
				INNER JOIN {$wpdb->posts} AS subscription ON subscription.ID = contents.post_id
				WHERE contents.meta_key = %s AND subscription.post_type = 'subscrpt_order' AND subscription.post_status IN ( 'active', 'pe_cancelled' )", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				BoxSubscription::META_BOX,
				(string) $box_id,
				BoxSubscription::META_CONTENTS
			)
		);

		$contents = array();

		foreach ( (array) $rows as $row ) {
			$contents[] = maybe_unserialize( $row );
		}

		$pairs = self::count_pairs( array_filter( $contents, 'is_array' ) );

		foreach ( $pairs as $product_id => $partners ) {
			arsort( $partners );
			$pairs[ $product_id ] = array_slice( $partners, 0, self::PARTNERS_KEPT, true );
		}

		set_transient( self::transient_key( $box_id ), $pairs, 2 * DAY_IN_SECONDS );

		return $pairs;
	}

	/**
	 * Rebuild the index of every active box.
	 *
	 * @return void
	 */
	public static function rebuild_all(): void {
		foreach ( BoxRepository::all( array( 'status' => Box::STATUS_ACTIVE ) ) as $box ) {
			self::rebuild( $box->id() );
		}
	}

	/**
	 * Schedule one rebuild for the box a changed subscription holds.
	 *
	 * Skipped when one is already waiting for that box, so editing a box ten
	 * times in a minute rebuilds it once.
	 *
	 * @param int $subscription_id Subscription id.
	 *
	 * @return void
	 */
	public function schedule_rebuild( $subscription_id ): void {
		$box_id = (int) get_post_meta( (int) $subscription_id, BoxSubscription::META_BOX, true );

		if ( ! $box_id || wp_next_scheduled( self::REBUILD_HOOK, array( $box_id ) ) ) {
			return;
		}

		wp_schedule_single_event( time() + self::REBUILD_DELAY, self::REBUILD_HOOK, array( $box_id ) );
	}

	/**
	 * Products to suggest alongside this one in a box.
	 *
	 * @param int $product_id The product being viewed.
	 * @param Box $box        The box it would go in.
	 * @param int $spares     How many more to list after the starting picks, for a section to swap in.
	 *
	 * @return int[] This product first, then the starting picks and the spares in order; nothing when there is no section to show.
	 */
	public static function suggestions( int $product_id, Box $box, int $spares = 0 ): array {
		$defaults = array_column( $box->default_items(), 'product_id' );
		$pool     = array_map( 'intval', $box->pool_product_ids() );

		return self::rank(
			$product_id,
			self::pairs( $box->id() ),
			$defaults,
			$pool,
			self::starting_count( $box ) + max( 0, $spares ),
			// A partner learned from stored contents may have left the pool since,
			// and adding it would fail the box's own validation.
			static function ( $id ) use ( $box, $pool ) {
				return in_array( (int) $id, $pool, true ) && self::eligible( (int) $id, $box );
			},
			max( self::MIN_ITEMS, $box->size()['min'] )
		);
	}

	/**
	 * Transient holding a box's index.
	 *
	 * @param int $box_id Box id.
	 *
	 * @return string
	 */
	private static function transient_key( int $box_id ): string {
		return 'subscrpt_box_pairs_' . $box_id;
	}
}
