<?php
/**
 * How a box item says whether it ships every cycle or once.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Box
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Box;

use SpringDevs\Subscription\Illuminate\Plans\PlanRepository;

defined( 'ABSPATH' ) || exit;

/**
 * Words and eligibility for the every-cycle / once choice.
 */
class BoxOnceLabel {

	/**
	 * The label of one item.
	 *
	 * @param bool $once Whether it ships once.
	 * @param int  $freq Billing frequency of the line's plan, 0 when it has none.
	 * @param int  $unit Billing interval id: 1 day, 2 week, 3 month, 4 year.
	 *
	 * @return string Empty when the item recurs and the line has no plan to name.
	 */
	public static function item_label( bool $once, int $freq, int $unit ): string {
		if ( $once ) {
			return __( 'once', 'subscription-pro' );
		}

		return $freq > 0 && $unit > 0 ? self::every( $freq, $unit ) : '';
	}

	/**
	 * What an email says beside an item that ships in the next box only.
	 *
	 * @return string
	 */
	public static function this_box_only(): string {
		return __( 'this box only', 'subscription-pro' );
	}

	/**
	 * How often a plan bills, as "month" or "2 weeks".
	 *
	 * @param int $freq Every this many intervals.
	 * @param int $unit Billing interval id: 1 day, 2 week, 3 month, 4 year.
	 *
	 * @return string
	 */
	public static function cadence( int $freq, int $unit ): string {
		switch ( $unit ) {
			case 1:
				/* translators: %d: number of days. */
				return 1 === $freq ? __( 'day', 'subscription-pro' ) : sprintf( _n( '%d day', '%d days', $freq, 'subscription-pro' ), $freq );
			case 2:
				/* translators: %d: number of weeks. */
				return 1 === $freq ? __( 'week', 'subscription-pro' ) : sprintf( _n( '%d week', '%d weeks', $freq, 'subscription-pro' ), $freq );
			case 4:
				/* translators: %d: number of years. */
				return 1 === $freq ? __( 'year', 'subscription-pro' ) : sprintf( _n( '%d year', '%d years', $freq, 'subscription-pro' ), $freq );
			default:
				/* translators: %d: number of months. */
				return 1 === $freq ? __( 'month', 'subscription-pro' ) : sprintf( _n( '%d month', '%d months', $freq, 'subscription-pro' ), $freq );
		}
	}

	/**
	 * "every month", "every 2 weeks".
	 *
	 * Each phrase is its own string, so a language can order the words as it
	 * needs rather than have a translated "every" glued to a translated unit.
	 *
	 * @param int $freq Every this many intervals.
	 * @param int $unit Billing interval id: 1 day, 2 week, 3 month, 4 year.
	 *
	 * @return string
	 */
	public static function every( int $freq, int $unit ): string {
		$freq = max( 1, $freq );

		switch ( $unit ) {
			case 1:
				/* translators: %d: number of days. */
				return 1 === $freq ? __( 'every day', 'subscription-pro' ) : sprintf( _n( 'every %d day', 'every %d days', $freq, 'subscription-pro' ), $freq );
			case 2:
				/* translators: %d: number of weeks. */
				return 1 === $freq ? __( 'every week', 'subscription-pro' ) : sprintf( _n( 'every %d week', 'every %d weeks', $freq, 'subscription-pro' ), $freq );
			case 4:
				/* translators: %d: number of years. */
				return 1 === $freq ? __( 'every year', 'subscription-pro' ) : sprintf( _n( 'every %d year', 'every %d years', $freq, 'subscription-pro' ), $freq );
			default:
				/* translators: %d: number of months. */
				return 1 === $freq ? __( 'every month', 'subscription-pro' ) : sprintf( _n( 'every %d month', 'every %d months', $freq, 'subscription-pro' ), $freq );
		}
	}

	/**
	 * The sentence beside the once choice.
	 *
	 * @param int[] $interval `[ frequency, interval ]` from interval_for(), empty when unknown.
	 *
	 * @return string
	 */
	public static function choice_label( array $interval ): string {
		if ( ! $interval ) {
			return __( 'Once, not every box', 'subscription-pro' );
		}

		/* translators: %s: how often the box ships, e.g. "every month". */
		return sprintf( __( 'Once, not %s', 'subscription-pro' ), self::every( $interval[0], $interval[1] ) );
	}

	/**
	 * How often a product's box bills, from its plans.
	 *
	 * Installments cannot hold a box, so they are ignored. A plan id picks that
	 * plan; without one, or one the product does not carry, the answer is the
	 * cadence every plan shares, and nothing when they differ.
	 *
	 * @param int $product_id Product that sells the box.
	 * @param int $plan_id    The plan the line was bought on, 0 when unknown.
	 *
	 * @return int[] `[ frequency, interval ]`, empty when there is no one cadence to name.
	 */
	public static function interval_for( int $product_id, int $plan_id = 0 ): array {
		$found = [];

		foreach ( PlanRepository::resolve_for_product( $product_id ) as $row ) {
			if ( 'installments' === PlanRepository::type_to_string( (int) $row['group_type'] ) ) {
				continue;
			}

			$cadence = [ max( 1, (int) $row['billing_frequency'] ), (int) $row['billing_interval'] ];

			if ( $plan_id && (int) ( $row['plan_id'] ?? 0 ) === $plan_id ) {
				return $cadence;
			}

			$found[ implode( '-', $cadence ) ] = $cadence;
		}

		return 1 === count( $found ) ? reset( $found ) : [];
	}

	/**
	 * Whether a box has room for an item that ships once.
	 *
	 * The minimum counts only what recurs, so an exact box has none: a once item
	 * would leave it short.
	 *
	 * @param Box $box The box.
	 *
	 * @return bool
	 */
	public static function has_room( Box $box ): bool {
		$size = $box->size();

		return self::has_room_for( (int) $size['min'], (int) $size['max'] );
	}

	/**
	 * Whether a size rule leaves room for an item that ships once.
	 *
	 * @param int $min Smallest box, in what recurs.
	 * @param int $max Largest box, in everything that ships; 0 for none.
	 *
	 * @return bool
	 */
	public static function has_room_for( int $min, int $max ): bool {
		return 0 === $max || $max > $min;
	}

	/**
	 * Whether the builder offers the once choice for an item of a box.
	 *
	 * @param Box $box        The box.
	 * @param int $product_id The item.
	 *
	 * @return bool
	 */
	public static function toggle_offered( Box $box, int $product_id ): bool {
		return in_array( $product_id, $box->pool_product_ids(), true )
			&& BoxCart::allows_one_time( $product_id, 0 )
			&& self::has_room( $box );
	}
}
