<?php
/**
 * The box's contents in the cart.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Box
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Box;

use Automattic\WooCommerce\StoreApi\Schemas\V1\CartItemSchema;

defined( 'ABSPATH' ) || exit;

/**
 * Shows what is in the box on its cart line.
 *
 * One description of the line, `describe()`, feeds all three places it shows:
 * the classic cart and checkout review (a template), the block cart and block
 * checkout (the same description over the Store API, drawn by
 * `assets/js/box-cart-view.js`) and the item-data row, which is the count
 * alone. The mini-cart is deliberately only that count: a drawer is no place
 * for a list of thumbnails.
 */
class BoxCartView {

	/**
	 * Script handle of the block cart and checkout list.
	 */
	const SCRIPT_HANDLE = 'subscrpt_box_cart_view_js';

	/**
	 * Cart item keys whose list was drawn in this request and whose count row
	 * must therefore not repeat it.
	 *
	 * @var array<string,bool>
	 */
	private static $listed = [];

	/**
	 * Whether the classic mini-cart is rendering.
	 *
	 * @var bool
	 */
	private static $in_mini_cart = false;

	/**
	 * Register hooks.
	 */
	public function __construct() {
		add_action( 'woocommerce_blocks_loaded', [ $this, 'register_store_api' ] );
		add_action( 'woocommerce_after_cart_item_name', [ __CLASS__, 'render_list' ], 10, 2 );
		add_filter( 'woocommerce_checkout_cart_item_quantity', [ __CLASS__, 'append_list' ], 10, 3 );
		add_filter( 'woocommerce_cart_item_thumbnail', [ __CLASS__, 'collage_thumbnail' ], 10, 2 );
		add_action( 'woocommerce_before_mini_cart', [ __CLASS__, 'enter_mini_cart' ], 1 );
		add_action( 'woocommerce_after_mini_cart', [ __CLASS__, 'leave_mini_cart' ], 99 );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue' ] );
	}

	/**
	 * The size attributes of a variable box's line, as the product page reads
	 * them to pre-select a variation.
	 *
	 * @param array $cart_item Cart item.
	 *
	 * @return array<string,string> `attribute_*` => value; empty for a simple box.
	 */
	private static function variation_attributes( array $cart_item ): array {
		$attributes = [];

		foreach ( (array) ( $cart_item['variation'] ?? [] ) as $name => $value ) {
			if ( 0 === strpos( (string) $name, 'attribute_' ) && is_scalar( $value ) ) {
				$attributes[ (string) $name ] = (string) $value;
			}
		}

		return $attributes;
	}

	/**
	 * Describe a box cart line for display.
	 *
	 * @param array $cart_item Cart item.
	 *
	 * @return array box_id, box_name, count_label, has_image, items (product_id, variation_id,
	 *               name, qty, thumbnail, permalink, price_html, once, label) and edit_url;
	 *               empty for a line that is not a box.
	 */
	public static function describe( array $cart_item ): array {
		$selection = $cart_item[ BoxCart::CART_KEY ] ?? [];

		if ( empty( $selection['items'] ) ) {
			return [];
		}

		$product_id   = (int) ( $cart_item['product_id'] ?? 0 );
		$variation_id = (int) ( $cart_item['variation_id'] ?? 0 );
		$box          = BoxProduct::resolve( $product_id, $variation_id, (int) ( $selection['box_id'] ?? 0 ) );
		$priced       = $box && BoxPricing::STRATEGY_SUM === $box->pricing()['strategy'];

		// A line bought once has no plan, so nothing recurs and there is no interval to name.
		$interval = empty( $selection['one_time'] )
			? BoxOnceLabel::interval_for( $product_id, (int) ( $cart_item['subscrpt_plan_id'] ?? 0 ) )
			: [];
		$items    = [];

		foreach ( BoxProduct::normalise_items( $selection['items'] ) as $row ) {
			$packed = wc_get_product( $row['variation_id'] ? $row['variation_id'] : $row['product_id'] );

			if ( ! $packed instanceof \WC_Product ) {
				continue;
			}

			$items[] = [
				'product_id'   => $row['product_id'],
				'variation_id' => $row['variation_id'],
				'name'         => $packed->get_name(),
				'qty'          => $row['qty'],
				'thumbnail'    => self::thumbnail( $packed ),
				'permalink'    => $packed->get_permalink(),
				'price_html'   => $priced ? wc_price( BoxPricing::item_price( $row['product_id'], $row['variation_id'] ) * $row['qty'] ) : '',
				'once'         => $row['once'],
				'label'        => BoxOnceLabel::item_label( $row['once'], $interval ? $interval[0] : 0, $interval ? $interval[1] : 0 ),
			];
		}

		$units = BoxProduct::count_units( $selection['items'] );
		$host  = wc_get_product( $product_id );
		$image = isset( $cart_item['data'] ) && $cart_item['data'] instanceof \WC_Product ? (int) $cart_item['data']->get_image_id() : 0;

		return [
			'box_id'      => $box ? $box->id() : 0,
			'box_name'    => $box ? $box->title() : '',
			// A curated box ships fixed contents, so its size bounds nothing.
			'count_label' => self::count_label( $units, $box && Box::TYPE_CURATED !== $box->type() ? $box->size() : [] ),
			// Without a picture of its own the line shows its picks instead of the
			// placeholder; the store's placeholder attachment set as one is not a picture.
			'has_image'   => $image && (int) get_option( 'woocommerce_placeholder_image', 0 ) !== $image,
			'items'       => $items,
			'edit_url'    => $box && $box->is_customer_built() && $host && ! empty( $cart_item['key'] )
				? add_query_arg(
					array_merge(
						[
							'subscrpt_box_edit' => $cart_item['key'],
							'subscrpt_box_id'   => $box->id(),
						],
						self::variation_attributes( $cart_item )
					),
					$host->get_permalink()
				)
				: '',
		];
	}

	/**
	 * How many are in the box, against what it holds when that is a number.
	 *
	 * A box with a top size reads "3 of 4". Unlimited, at-least and exact boxes
	 * read "3 items": there is no ceiling to measure against, and "3 of 3" says
	 * the same thing less well.
	 *
	 * @param int   $count Units in the box.
	 * @param array $size  min and max, 0 for no bound.
	 *
	 * @return string
	 */
	public static function count_label( int $count, array $size ): string {
		$min = (int) ( $size['min'] ?? 0 );
		$max = (int) ( $size['max'] ?? 0 );

		if ( $max && $max !== $min ) {
			/* translators: 1: units in the box, 2: the most the box holds. */
			return sprintf( __( '%1$d of %2$d', 'subscription-pro' ), $count, $max );
		}

		/* translators: %d: units in the box. */
		return sprintf( _n( '%d item', '%d items', $count, 'subscription-pro' ), $count );
	}

	/**
	 * The Store API's per-item field: the description, with an empty one for
	 * every line that is not a box so the field's shape never varies.
	 *
	 * @param array $cart_item Cart item.
	 *
	 * @return array
	 */
	public static function store_api_data( $cart_item ): array {
		$view = is_array( $cart_item ) ? self::describe( $cart_item ) : [];

		return $view ? $view : [
			'box_id'      => 0,
			'box_name'    => '',
			'count_label' => '',
			'has_image'   => false,
			'items'       => [],
			'edit_url'    => '',
		];
	}

	/**
	 * The shape of `store_api_data()`, for the Store API schema.
	 *
	 * @return array
	 */
	public static function store_api_schema(): array {
		$ctx = [ 'view', 'edit' ];

		$string = static function ( $description ) use ( $ctx ) {
			return [
				'description' => $description,
				'type'        => 'string',
				'context'     => $ctx,
				'readonly'    => true,
			];
		};

		return [
			'box_id'      => [
				'description' => __( 'The box this line sells.', 'subscription-pro' ),
				'type'        => 'integer',
				'context'     => $ctx,
				'readonly'    => true,
			],
			'box_name'    => $string( __( 'The box name.', 'subscription-pro' ) ),
			'count_label' => $string( __( 'How many are in the box, for example "3 items" or "3 of 4".', 'subscription-pro' ) ),
			'has_image'   => [
				'description' => __( 'Whether the box product has a picture of its own.', 'subscription-pro' ),
				'type'        => 'boolean',
				'context'     => $ctx,
				'readonly'    => true,
			],
			'items'       => [
				'description' => __( 'What is in the box.', 'subscription-pro' ),
				'type'        => 'array',
				'context'     => $ctx,
				'readonly'    => true,
				'items'       => [
					'type'       => 'object',
					'properties' => [
						'product_id'   => [ 'type' => 'integer' ],
						'variation_id' => [ 'type' => 'integer' ],
						'name'         => [ 'type' => 'string' ],
						'qty'          => [ 'type' => 'integer' ],
						'thumbnail'    => [ 'type' => 'string' ],
						'permalink'    => [ 'type' => 'string' ],
						'price_html'   => [ 'type' => 'string' ],
						'once'         => [ 'type' => 'boolean' ],
						'label'        => [ 'type' => 'string' ],
					],
				],
			],
			'edit_url'    => $string( __( 'Where the shopper changes the box; empty when the contents are not theirs to change.', 'subscription-pro' ) ),
		];
	}

	/**
	 * Put the description on every cart item of the Store API.
	 *
	 * @return void
	 */
	public function register_store_api(): void {
		if ( ! function_exists( 'woocommerce_store_api_register_endpoint_data' ) || ! class_exists( CartItemSchema::class ) ) {
			return;
		}

		woocommerce_store_api_register_endpoint_data(
			[
				'endpoint'        => CartItemSchema::IDENTIFIER,
				'namespace'       => BoxCartEndpoints::STORE_API_NAMESPACE,
				'data_callback'   => [ __CLASS__, 'store_api_data' ],
				'schema_callback' => [ __CLASS__, 'store_api_schema' ],
				'schema_type'     => ARRAY_A,
			]
		);
	}

	/**
	 * The count row that sits among a line's other details.
	 *
	 * It is the whole of the box in the mini-cart. Where the list has just drawn
	 * for this line the row would say the same thing twice, so it steps aside,
	 * once: the classic cart and checkout draw the list before their item data.
	 *
	 * @param array $item_data Item data rows.
	 * @param array $cart_item Cart item.
	 *
	 * @return array
	 */
	public static function item_data( $item_data, $cart_item ) {
		if ( empty( $cart_item[ BoxCart::CART_KEY ]['items'] ) ) {
			return $item_data;
		}

		$key = (string) ( $cart_item['key'] ?? '' );

		if ( ! self::$in_mini_cart && '' !== $key && isset( self::$listed[ $key ] ) ) {
			unset( self::$listed[ $key ] );

			return $item_data;
		}

		$view = self::describe( $cart_item );

		if ( ! $view ) {
			return $item_data;
		}

		$item_data[] = [
			'key'     => __( 'In this box', 'subscription-pro' ),
			'value'   => $view['count_label'],
			'display' => '',
		];

		return $item_data;
	}

	/**
	 * Draw the list under the box's name in the classic cart.
	 *
	 * @param array  $cart_item     Cart item.
	 * @param string $cart_item_key Cart item key.
	 *
	 * @return void
	 */
	public static function render_list( $cart_item, $cart_item_key = '' ): void {
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the template escapes every value.
		echo self::list_html( (array) $cart_item, (string) $cart_item_key );
	}

	/**
	 * Add the list to a classic checkout review row.
	 *
	 * @param string $html          What the row already shows beside the name.
	 * @param array  $cart_item     Cart item.
	 * @param string $cart_item_key Cart item key.
	 *
	 * @return string
	 */
	public static function append_list( $html, $cart_item, $cart_item_key = '' ) {
		return $html . self::list_html( (array) $cart_item, (string) $cart_item_key );
	}

	/**
	 * The list as markup, and a note that this line's list has drawn.
	 *
	 * @param array  $cart_item Cart item.
	 * @param string $key       Cart item key.
	 *
	 * @return string Empty for a line that is not a box.
	 */
	private static function list_html( array $cart_item, string $key ): string {
		$cart_item['key'] = $key ? $key : ( $cart_item['key'] ?? '' );
		$view             = self::describe( $cart_item );

		if ( ! $view || ! $view['items'] ) {
			return '';
		}

		self::mark_listed( (string) $cart_item['key'] );
		wp_enqueue_style( 'subscrpt_box_css' );

		ob_start();
		include SUBSCRIPT_PRO_PATH . '/templates/box/cart-contents.php';

		return (string) ob_get_clean();
	}

	/**
	 * Note that a line's list has drawn.
	 *
	 * @param string $key Cart item key.
	 *
	 * @return void
	 */
	public static function mark_listed( string $key ): void {
		self::$listed[ $key ] = true;
	}

	/**
	 * Forget every line's list, for the tests.
	 *
	 * @return void
	 */
	public static function forget_listed(): void {
		self::$listed = [];
	}

	/**
	 * The classic mini-cart starts rendering.
	 *
	 * @return void
	 */
	public static function enter_mini_cart(): void {
		self::$in_mini_cart = true;
	}

	/**
	 * The classic mini-cart is done.
	 *
	 * @return void
	 */
	public static function leave_mini_cart(): void {
		self::$in_mini_cart = false;
	}

	/**
	 * Load the block cart and checkout list on a cart or checkout page that
	 * uses the block. The script itself does nothing for a cart with no box.
	 *
	 * @return void
	 */
	public function enqueue(): void {
		if ( ! function_exists( 'is_cart' ) || ! ( is_cart() || is_checkout() ) ) {
			return;
		}

		if ( ! has_block( 'woocommerce/cart' ) && ! has_block( 'woocommerce/checkout' ) ) {
			return;
		}

		wp_enqueue_style( 'subscrpt_box_css' );
		wp_enqueue_script( self::SCRIPT_HANDLE );
		wp_localize_script(
			self::SCRIPT_HANDLE,
			'subscrptBoxCartView',
			[
				'namespace' => BoxCartEndpoints::STORE_API_NAMESPACE,
				'once'      => __( 'once', 'subscription-pro' ),
				'edit'      => __( 'Edit box', 'subscription-pro' ),
			]
		);
	}

	/**
	 * The box line's thumbnail as a collage of its picks, in place of the
	 * store's placeholder, when the box product has no picture of its own.
	 *
	 * @param string $html      Thumbnail markup.
	 * @param array  $cart_item Cart item.
	 *
	 * @return string
	 */
	public static function collage_thumbnail( $html, $cart_item ) {
		if ( empty( $cart_item[ BoxCart::CART_KEY ]['items'] ) ) {
			return $html;
		}

		$view = self::describe( (array) $cart_item );

		return $view && ! $view['has_image'] ? self::collage_html( $view['items'] ) : $html;
	}

	/**
	 * Up to four picks in a square, the fourth reading "+N" when more are packed.
	 *
	 * `assets/js/box-cart-view.js` draws the same markup for the block cart.
	 *
	 * @param array $items Picks from describe().
	 *
	 * @return string
	 */
	public static function collage_html( array $items ): string {
		$shown = array_slice( $items, 0, 4 );
		$more  = count( $items ) - 3;
		$html  = '';

		foreach ( $shown as $index => $pick ) {
			$html .= sprintf(
				'<span class="subscrpt-box-collage__tile"><img src="%s" alt="" loading="lazy">%s</span>',
				esc_url( $pick['thumbnail'] ),
				3 === $index && $more > 1 ? '<span class="subscrpt-box-collage__more">+' . (int) $more . '</span>' : ''
			);
		}

		return sprintf( '<span class="subscrpt-box-collage" data-count="%d">%s</span>', count( $shown ), $html );
	}

	/**
	 * A pick's thumbnail address, from WooCommerce's own image sizes.
	 *
	 * A variation without a picture of its own shows its parent's, and a product
	 * without one shows the store's placeholder, so the list is never a gap.
	 *
	 * @param \WC_Product $product The picked product or variation.
	 *
	 * @return string
	 */
	public static function thumbnail( \WC_Product $product ): string {
		$size  = 'woocommerce_gallery_thumbnail';
		$image = (int) $product->get_image_id();

		if ( ! $image && $product->get_parent_id() ) {
			$parent = wc_get_product( $product->get_parent_id() );
			$image  = $parent instanceof \WC_Product ? (int) $parent->get_image_id() : 0;
		}

		$url = $image ? wp_get_attachment_image_url( $image, $size ) : '';

		return $url ? (string) $url : (string) wc_placeholder_img_src( $size );
	}
}
