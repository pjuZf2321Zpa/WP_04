<?php
/**
 * One box.
 *
 * A box used to be a product carrying thirteen meta keys. It is now its own
 * record, and this class is that record with its rules attached. Everything the
 * old `BoxProduct` knew about *a box* lives here; what `BoxProduct` kept is the
 * question "which boxes does this product sell?".
 *
 * Return shapes are deliberately unchanged from the product-meta era. A
 * subscription snapshots `rules()` at sign-up and reads it back years later, so
 * changing a key here would silently change the deal an existing subscriber is
 * on.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Box
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Box;

defined( 'ABSPATH' ) || exit;

/**
 * A box and the rules it sells under.
 */
class Box {

	/**
	 * The merchant packs it; contents never vary.
	 */
	const TYPE_CURATED = 'curated';

	/**
	 * The customer fills it from a pool.
	 */
	const TYPE_BUILD = 'build';

	/**
	 * The merchant publishes each cycle's contents.
	 */
	const TYPE_EDITION = 'edition';

	/**
	 * Sellable.
	 */
	const STATUS_ACTIVE = 'active';

	/**
	 * Being written, never offered to a customer.
	 */
	const STATUS_DRAFT = 'draft';

	/**
	 * Removed, kept for the subscriptions still on it.
	 */
	const STATUS_TRASH = 'trash';

	/**
	 * Swap a sold-out pick for a default one.
	 */
	const STOCK_REPLACE = 'replace';

	/**
	 * Ship the box without a sold-out pick.
	 */
	const STOCK_DROP = 'drop';

	/**
	 * The decoded database row.
	 *
	 * @var array
	 */
	private $row;

	/**
	 * Size override from the product↔box connection, if any.
	 *
	 * A product may sell the same box in several sizes, one per variation. That
	 * is a fact about the connection, not about the box, so it arrives here
	 * rather than being stored on the box.
	 *
	 * @var array
	 */
	private $override;

	/**
	 * Wrap a row.
	 *
	 * @param array $row      Decoded row from BoxRepository.
	 * @param array $override Optional connection override: min, max.
	 */
	public function __construct( array $row, array $override = array() ) {
		$this->row      = $row;
		$this->override = $override;
	}

	/**
	 * Box id.
	 *
	 * @return int
	 */
	public function id(): int {
		return (int) ( $this->row['id'] ?? 0 );
	}

	/**
	 * What the merchant called it.
	 *
	 * @return string
	 */
	public function title(): string {
		return (string) ( $this->row['title'] ?? '' );
	}

	/**
	 * Active, draft or trashed.
	 *
	 * @return string
	 */
	public function status(): string {
		$status = (string) ( $this->row['status'] ?? self::STATUS_DRAFT );

		return in_array( $status, array( self::STATUS_ACTIVE, self::STATUS_DRAFT, self::STATUS_TRASH ), true )
			? $status
			: self::STATUS_DRAFT;
	}

	/**
	 * Can a customer buy it?
	 *
	 * @return bool
	 */
	public function is_active(): bool {
		return self::STATUS_ACTIVE === $this->status();
	}

	/**
	 * Curated, build-your-own or edition.
	 *
	 * @return string
	 */
	public function type(): string {
		$type = (string) ( $this->row['type'] ?? '' );

		return in_array( $type, array( self::TYPE_CURATED, self::TYPE_BUILD, self::TYPE_EDITION ), true )
			? $type
			: self::TYPE_CURATED;
	}

	/**
	 * Does the customer choose the contents?
	 *
	 * Curated boxes are packed by the merchant; edition boxes are published by
	 * the merchant but may allow swaps, which is a different flow from building
	 * a box at checkout.
	 *
	 * @return bool
	 */
	public function is_customer_built(): bool {
		return self::TYPE_BUILD === $this->type();
	}

	/**
	 * The same box, seen through one connection's size override.
	 *
	 * @param array $override min and/or max.
	 *
	 * @return self
	 */
	public function with_override( array $override ): self {
		return new self( $this->row, $override );
	}

	/**
	 * How many items this box holds.
	 *
	 * A connection override wins when it sets either bound, which is how a
	 * variable product sells "5 items for $109" as a variation rather than as
	 * something the shopper types in.
	 *
	 * A bound of 0 is no bound: a minimum alone is "at least", a maximum alone
	 * is "at most", and equal bounds are an exact count. Boxes saved when one
	 * bound meant exactly that count are converted by `BoxSizeMigration`.
	 *
	 * @return array{min:int,max:int}
	 */
	public function size(): array {
		$min = $this->row['size_min'] ?? 0;
		$max = $this->row['size_max'] ?? 0;

		// Missing values read back as '' or null depending on the caller, so
		// both count as "not set" — otherwise an override silently means zero.
		$has_override = '' !== (string) ( $this->override['min'] ?? '' )
			|| '' !== (string) ( $this->override['max'] ?? '' );

		if ( $has_override ) {
			$min = $this->override['min'] ?? 0;
			$max = $this->override['max'] ?? 0;
		}

		$min = max( 0, (int) $min );
		$max = max( 0, (int) $max );

		return array(
			'min' => $min,
			'max' => $max,
		);
	}

	/**
	 * Most units of a single product allowed in one box.
	 *
	 * @return int 0 when only the box size limits it.
	 */
	public function max_per_item(): int {
		return max( 0, (int) ( $this->row['max_per_item'] ?? 0 ) );
	}

	/**
	 * May subscribers change what is in the next box?
	 *
	 * @return bool
	 */
	public function allow_edit(): bool {
		return ! empty( $this->row['allow_edit'] );
	}

	/**
	 * May subscribers skip a box?
	 *
	 * @return bool
	 */
	public function allow_skip(): bool {
		return ! empty( $this->row['allow_skip'] );
	}

	/**
	 * Most skips in a row. 0 means no limit.
	 *
	 * @return int
	 */
	public function max_skips(): int {
		return max( 0, (int) ( $this->row['max_skips'] ?? 0 ) );
	}

	/**
	 * What happens when a pick is sold out at renewal.
	 *
	 * @return string replace|drop
	 */
	public function stock_rule(): string {
		return self::STOCK_DROP === ( $this->row['stock_rule'] ?? '' ) ? self::STOCK_DROP : self::STOCK_REPLACE;
	}

	/**
	 * Days before renewal that contents lock.
	 *
	 * @return int
	 */
	public function lock_days(): int {
		$days = $this->row['lock_days'] ?? '';

		if ( '' === (string) $days || null === $days ) {
			$days = get_option( 'subscrpt_box_lock_days', 3 );
		}

		return max( 0, (int) $days );
	}

	/**
	 * The fixed contents of a curated box.
	 *
	 * @return array[] Each entry: product_id, variation_id, qty.
	 */
	public function curated_items(): array {
		return BoxProduct::normalise_items( $this->row['items'] ?? array() );
	}

	/**
	 * The picks a build-your-own box starts with.
	 *
	 * @return array[] Each entry: product_id, variation_id, qty.
	 */
	public function default_items(): array {
		return BoxProduct::normalise_items( $this->row['defaults'] ?? array() );
	}

	/**
	 * The pool definition a build-your-own box picks from.
	 *
	 * `source` says which list is the pool: the chosen `products`, everything in
	 * the chosen `categories` (and tags), or the whole shop. `exclude` leaves
	 * single products out of the last two. `virtual` lets downloadable and
	 * virtual products in, which are left out by default because nothing ships.
	 *
	 * @return array{source:string,products:int[],categories:int[],tags:int[],exclude:int[],virtual:bool}
	 */
	public function pool(): array {
		$pool = is_array( $this->row['pool'] ?? null ) ? $this->row['pool'] : array();

		return BoxPool::normalise( $pool );
	}

	/**
	 * The plan group whose durations sell this box.
	 *
	 * A box keeps a plan group of its own, created with its first duration, and
	 * may instead borrow a shared one from the Plans screen. Both ids are kept so
	 * switching back to the box's own durations finds them again.
	 *
	 * @return array{mode:string,own_group_id:int,shared_group_id:int}
	 */
	public function plans(): array {
		$plans = is_array( $this->row['plans'] ?? null ) ? $this->row['plans'] : array();

		return array(
			'mode'            => 'shared' === ( $plans['mode'] ?? '' ) ? 'shared' : 'own',
			'own_group_id'    => absint( $plans['own_group_id'] ?? 0 ),
			'shared_group_id' => absint( $plans['shared_group_id'] ?? 0 ),
		);
	}

	/**
	 * The plan group in use: the shared one when borrowed, else the box's own.
	 *
	 * @return int 0 when the box has no durations yet.
	 */
	public function plan_group_id(): int {
		$plans = $this->plans();

		return 'shared' === $plans['mode'] ? $plans['shared_group_id'] : $plans['own_group_id'];
	}

	/**
	 * Every product id a shopper may pick for this box.
	 *
	 * Resolves the pool's source into purchasable products, minus the
	 * exclusions. A product that itself sells a box is always removed: a box
	 * inside a box would recurse at renewal.
	 *
	 * A variable product is offered as its variations, never itself: a box has
	 * to say which size or colour ships. Category and whole-shop pools list
	 * parents, so without this a parent reached the builder as a plain pick.
	 *
	 * @return int[]
	 */
	public function pool_product_ids(): array {
		$pool = $this->pool();
		$ids  = [];

		foreach ( array_diff( BoxPool::candidate_ids( $pool ), $pool['exclude'] ) as $id ) {
			$candidate = wc_get_product( $id );

			if ( $candidate instanceof \WC_Product && $candidate->is_type( 'variable' ) ) {
				array_push( $ids, ...array_map( 'absint', $candidate->get_visible_children() ) );
				continue;
			}

			$ids[] = (int) $id;
		}

		$ids = array_values( array_unique( array_diff( $ids, $pool['exclude'] ) ) );

		$ids = array_values(
			array_filter(
				$ids,
				static function ( $id ) {
					$candidate = wc_get_product( $id );

					return $candidate instanceof \WC_Product
						&& $candidate->is_purchasable()
						&& ! BoxProduct::is_box( $candidate );
				}
			)
		);

		/**
		 * Filters the products a shopper may pick for a box.
		 *
		 * The second argument is the box id. Before boxes became their own
		 * record it was the box product's id.
		 *
		 * @param int[] $ids    Purchasable product ids.
		 * @param int   $box_id The box.
		 */
		return apply_filters( 'subscrpt_box_pool_products', $ids, $this->id() );
	}

	/**
	 * The rules a subscription copies at sign-up.
	 *
	 * Snapshotting these is the same guarantee Plans gives prices: editing the
	 * box later must never change the deal an existing subscriber is on. The
	 * keys are identical to the product-meta era, so snapshots written before
	 * this refactor still read correctly.
	 *
	 * @return array
	 */
	public function rules(): array {
		$size = $this->size();

		return array(
			'type'         => $this->type(),
			'min'          => $size['min'],
			'max'          => $size['max'],
			'max_per_item' => $this->max_per_item(),
			'allow_edit'   => $this->allow_edit(),
			'lock_days'    => $this->lock_days(),
			'allow_skip'   => $this->allow_skip(),
			'max_skips'    => $this->max_skips(),
			'stock_rule'   => $this->stock_rule(),
			'box_id'       => $this->id(),
		);
	}

	/**
	 * Validate a selection against this box's rules.
	 *
	 * Returns the first rule broken, so the shopper is told which one rather
	 * than "invalid selection".
	 *
	 * @param array      $items   Selection: entries of product_id, variation_id, qty and optionally once.
	 * @param int[]|null $allowed Allowed product ids. Resolved from the pool when null.
	 *
	 * @return true|string True when valid, else a translated message.
	 */
	public function validate( array $items, ?array $allowed = null ) {
		$items = BoxProduct::normalise_items( $items );

		// Every one of these checks used to be written out here, and again in
		// BoxSubscription::update_contents() for the My Account form. The two
		// copies had already drifted — this one enforced the per-item cap and
		// that one did not, so a subscriber could edit their box past a limit
		// the cart refused at checkout. One rule engine, asked from both places.
		// Every renewal is a box on its own, so the minimum is judged on what
		// ships every cycle; the first box holds both, so the maximum is not.
		list( $recurring ) = BoxProduct::split_once( $items );

		foreach ( BoxRules::from_size( $this->size() ) as $rule ) {
			$result = BoxRules::check(
				$rule,
				BoxRules::OP_AT_LEAST === $rule['op'] ? $recurring : $items,
				BoxRules::SCOPE_BOX
			);

			if ( is_string( $result ) ) {
				return $result;
			}
		}

		$result = BoxRules::check_per_item( $items, $this->max_per_item() );

		if ( is_string( $result ) ) {
			return $result;
		}

		$result = BoxRules::check_allowed(
			$items,
			null === $allowed ? $this->pool_product_ids() : $allowed
		);

		if ( is_string( $result ) ) {
			return $result;
		}

		return BoxRules::check_one_time( $items );
	}

	/**
	 * How the box is priced, normalised.
	 *
	 * @return array See BoxPricing::normalise_config().
	 */
	public function pricing(): array {
		return BoxPricing::normalise_config( $this->row['pricing'] ?? [] );
	}

	/**
	 * Whether the box's products offer Frequently Bought Together.
	 *
	 * @return bool
	 */
	public function show_together(): bool {
		return (bool) ( $this->row['show_together'] ?? true );
	}

	/**
	 * The row, for the admin screens and REST.
	 *
	 * @return array
	 */
	public function to_array(): array {
		return array_merge(
			$this->row,
			array(
				'id'            => $this->id(),
				'type'          => $this->type(),
				'status'        => $this->status(),
				'size'          => $this->size(),
				'pricing'       => $this->pricing(),
				'show_together' => $this->show_together(),
				'pool'          => $this->pool(),
				'plans'         => $this->plans(),
			)
		);
	}
}
