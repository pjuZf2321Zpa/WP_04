<?php
/**
 * The steps a box is built in.
 *
 * "Choose a coffee, then a grind, then how many bags" is three questions, and a
 * single grid of products cannot ask them. A step is one screenful of that
 * build: a title, an optional rule of its own, and the sections it shows.
 *
 * This is the child table the box table was shaped for — it sits under a box
 * the way `subscrpt_plan` sits under a plan group. Sections and fields live as
 * JSON inside a step rather than in tables of their own, following the same
 * rule the box table set: scalars that the code branches on are columns, so a
 * schema change shows up in dbDelta rather than hiding inside a blob; ordered,
 * list-shaped settings are JSON.
 *
 * **Every box works without a single step row.** A box with no steps is read
 * as one step, holding one section, offering the whole pool, carrying the
 * box's own size rule — so nothing existing needs migrating and a merchant who
 * never opens this feature never meets it.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Box
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Box;

defined( 'ABSPATH' ) || exit;

/**
 * Reads and writes box steps.
 */
class BoxStepRepository {

	/**
	 * A plain grid of products.
	 */
	const LAYOUT_GRID = 'grid';

	/**
	 * Sections as tabs, one visible at a time.
	 */
	const LAYOUT_TABS = 'tabs';

	/**
	 * Sections stacked, each collapsible.
	 */
	const LAYOUT_ACCORDION = 'accordion';

	/**
	 * Live.
	 */
	const STATUS_ACTIVE = 'active';

	/**
	 * Kept, not shown.
	 */
	const STATUS_DRAFT = 'draft';

	/**
	 * Fully qualified table name.
	 *
	 * @return string
	 */
	public static function table(): string {
		global $wpdb;

		return $wpdb->prefix . 'subscrpt_box_step';
	}

	/**
	 * Create or upgrade the table.
	 *
	 * @return void
	 */
	public static function create_table(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table   = self::table();
		$collate = $wpdb->get_charset_collate();

		dbDelta(
			"CREATE TABLE {$table} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				box_id bigint(20) unsigned NOT NULL,
				title varchar(191) NOT NULL DEFAULT '',
				subtitle varchar(255) NOT NULL DEFAULT '',
				layout varchar(20) NOT NULL DEFAULT 'grid',
				rule_measure varchar(20) NOT NULL DEFAULT 'quantity',
				rule_op varchar(4) NOT NULL DEFAULT '>=',
				rule_value int(11) unsigned NOT NULL DEFAULT 0,
				sort_order int(11) NOT NULL DEFAULT 0,
				status varchar(20) NOT NULL DEFAULT 'active',
				data longtext NULL,
				created_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
				updated_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
				PRIMARY KEY  (id),
				KEY step_box (box_id, sort_order),
				KEY step_status (box_id, status)
			) {$collate};"
		);
	}

	/**
	 * One step by id.
	 *
	 * @param int $id Step id.
	 *
	 * @return array|null
	 */
	public static function find( int $id ): ?array {
		global $wpdb;

		$table = self::table();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ), ARRAY_A );

		return $row ? self::decode( $row ) : null;
	}

	/**
	 * The steps a box defines, in the order they are asked.
	 *
	 * Returns the rows as stored — empty when the box has none. Callers that
	 * want a box to always have at least one step ask `steps_for()`.
	 *
	 * @param int  $box_id     Box id.
	 * @param bool $active_only Whether to skip drafts.
	 *
	 * @return array[]
	 */
	public static function for_box( int $box_id, bool $active_only = true ): array {
		global $wpdb;

		$table = self::table();

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$rows = $active_only
			? $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE box_id = %d AND status = %s ORDER BY sort_order ASC, id ASC", $box_id, self::STATUS_ACTIVE ), ARRAY_A )
			: $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE box_id = %d ORDER BY sort_order ASC, id ASC", $box_id ), ARRAY_A );
		// phpcs:enable

		return array_map( array( __CLASS__, 'decode' ), $rows ? $rows : array() );
	}

	/**
	 * The steps to build this box with, always at least one.
	 *
	 * This is the method the storefront and the admin both use. A box that
	 * defines no steps is answered with one synthesised step: the whole pool in
	 * a single section, carrying the box's own size rule. That is exactly how
	 * every box behaved before steps existed, so nothing had to be migrated and
	 * a merchant who never opens this feature never sees it.
	 *
	 * @param Box $box The box.
	 *
	 * @return array[]
	 */
	public static function steps_for( Box $box ): array {
		$steps = self::for_box( $box->id() );

		if ( $steps ) {
			return $steps;
		}

		return array( self::synthesise( $box ) );
	}

	/**
	 * Does this box actually define steps of its own?
	 *
	 * The admin asks, so it can offer "add a step" rather than presenting a
	 * synthesised one as if the merchant had made it.
	 *
	 * @param int $box_id Box id.
	 *
	 * @return bool
	 */
	public static function has_steps( int $box_id ): bool {
		return (bool) self::for_box( $box_id );
	}

	/**
	 * The single step a box without steps behaves as.
	 *
	 * @param Box $box The box.
	 *
	 * @return array
	 */
	public static function synthesise( Box $box ): array {
		$size = $box->size();

		return array(
			'id'           => 0,
			'box_id'       => $box->id(),
			'title'        => $box->is_customer_built()
				? __( 'Build your box', 'subscription-pro' )
				: __( 'What is in this box', 'subscription-pro' ),
			'subtitle'     => '',
			'layout'       => self::LAYOUT_GRID,
			'rule_measure' => BoxRules::MEASURE_QUANTITY,
			'rule_op'      => BoxRules::OP_AT_LEAST,
			'rule_value'   => 0,
			'sort_order'   => 0,
			'status'       => self::STATUS_ACTIVE,
			'synthesised'  => true,
			// The box's own size is the step's rule, so a one-step build and a
			// box with no steps enforce exactly the same thing.
			'rules'        => BoxRules::from_size( $size ),
			'conditions'   => array(),
			'fields'       => array(),
			'sections'     => array(
				array(
					'key'      => 'all',
					'title'    => '',
					'source'   => 'pool',
					'products' => array(),
					'rules'    => array(),
					'filter'   => array(),
				),
			),
		);
	}

	/**
	 * Create or update a step.
	 *
	 * @param array $data box_id, title, subtitle, layout, rule_*, sort_order,
	 *                    status, sections, fields, conditions, and id to update.
	 *
	 * @return int Step id, or 0 when it could not be written.
	 */
	public static function save( array $data ): int {
		global $wpdb;

		$box_id = absint( $data['box_id'] ?? 0 );

		if ( ! $box_id ) {
			return 0;
		}

		$layouts = array( self::LAYOUT_GRID, self::LAYOUT_TABS, self::LAYOUT_ACCORDION );
		$ops     = array( BoxRules::OP_EXACTLY, BoxRules::OP_AT_LEAST, BoxRules::OP_AT_MOST );
		$now     = current_time( 'mysql', true );

		$row = array(
			'box_id'       => $box_id,
			'title'        => sanitize_text_field( (string) ( $data['title'] ?? '' ) ),
			'subtitle'     => sanitize_text_field( (string) ( $data['subtitle'] ?? '' ) ),
			'layout'       => in_array( $data['layout'] ?? '', $layouts, true ) ? $data['layout'] : self::LAYOUT_GRID,
			'rule_measure' => BoxRules::MEASURE_AMOUNT === ( $data['rule_measure'] ?? '' ) ? BoxRules::MEASURE_AMOUNT : BoxRules::MEASURE_QUANTITY,
			'rule_op'      => in_array( $data['rule_op'] ?? '', $ops, true ) ? $data['rule_op'] : BoxRules::OP_AT_LEAST,
			'rule_value'   => max( 0, (int) ( $data['rule_value'] ?? 0 ) ),
			'sort_order'   => (int) ( $data['sort_order'] ?? 0 ),
			'status'       => self::STATUS_DRAFT === ( $data['status'] ?? '' ) ? self::STATUS_DRAFT : self::STATUS_ACTIVE,
			'data'         => wp_json_encode(
				array(
					'sections'   => self::prepare_sections( (array) ( $data['sections'] ?? array() ) ),
					'fields'     => self::prepare_fields( (array) ( $data['fields'] ?? array() ) ),
					'conditions' => self::prepare_conditions( (array) ( $data['conditions'] ?? array() ) ),
				)
			),
			'updated_at'   => $now,
		);

		$id = absint( $data['id'] ?? 0 );

		if ( $id && self::find( $id ) ) {
			$wpdb->update( self::table(), $row, array( 'id' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

			return $id;
		}

		$row['created_at'] = $now;

		$wpdb->insert( self::table(), $row ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

		return (int) $wpdb->insert_id;
	}

	/**
	 * Delete a step.
	 *
	 * @param int $id Step id.
	 *
	 * @return bool
	 */
	public static function delete( int $id ): bool {
		global $wpdb;

		return (bool) $wpdb->delete( self::table(), array( 'id' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	}

	/**
	 * Remove every step of a box, for when the box itself goes.
	 *
	 * @param int $box_id Box id.
	 *
	 * @return int How many were removed.
	 */
	public static function delete_for_box( int $box_id ): int {
		global $wpdb;

		return (int) $wpdb->delete( self::table(), array( 'box_id' => $box_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	}

	/**
	 * Coerce sections into a predictable shape.
	 *
	 * A section names itself with a key so a condition elsewhere can point at
	 * it, and keeps its own rules so "two coffees and one grinder" is one step
	 * with two sections rather than two steps.
	 *
	 * @param array $sections Raw sections.
	 *
	 * @return array[]
	 */
	private static function prepare_sections( array $sections ): array {
		$out  = array();
		$seen = array();

		foreach ( $sections as $index => $section ) {
			$section = (array) $section;
			$key     = sanitize_key( (string) ( $section['key'] ?? '' ) );

			if ( '' === $key || isset( $seen[ $key ] ) ) {
				$key = 'section_' . ( (int) $index + 1 );
			}

			$seen[ $key ] = true;

			$out[] = array(
				'key'      => $key,
				'title'    => sanitize_text_field( (string) ( $section['title'] ?? '' ) ),
				'source'   => 'products' === ( $section['source'] ?? 'pool' ) ? 'products' : 'pool',
				'products' => array_values( array_filter( array_map( 'absint', (array) ( $section['products'] ?? array() ) ) ) ),
				'rules'    => self::prepare_rules( (array) ( $section['rules'] ?? array() ) ),
				// An answer to a field can narrow what a later section offers.
				'filter'   => array(
					'field' => sanitize_key( (string) ( $section['filter']['field'] ?? '' ) ),
					'map'   => (array) ( $section['filter']['map'] ?? array() ),
				),
			);
		}

		return $out;
	}

	/**
	 * Coerce rules into a predictable shape.
	 *
	 * @param array $rules Raw rules.
	 *
	 * @return array[]
	 */
	private static function prepare_rules( array $rules ): array {
		$ops = array( BoxRules::OP_EXACTLY, BoxRules::OP_AT_LEAST, BoxRules::OP_AT_MOST );
		$out = array();

		foreach ( $rules as $rule ) {
			$rule  = (array) $rule;
			$value = max( 0, (float) ( $rule['value'] ?? 0 ) );

			if ( ! $value ) {
				continue;
			}

			$out[] = array(
				'measure' => BoxRules::MEASURE_AMOUNT === ( $rule['measure'] ?? '' ) ? BoxRules::MEASURE_AMOUNT : BoxRules::MEASURE_QUANTITY,
				'op'      => in_array( $rule['op'] ?? '', $ops, true ) ? $rule['op'] : BoxRules::OP_AT_LEAST,
				'value'   => $value,
			);
		}

		return $out;
	}

	/**
	 * Coerce fields into a predictable shape.
	 *
	 * @param array $fields Raw fields.
	 *
	 * @return array[]
	 */
	private static function prepare_fields( array $fields ): array {
		$types = array( 'radio', 'select', 'checkbox', 'text', 'textarea' );
		$out   = array();

		foreach ( $fields as $index => $field ) {
			$field = (array) $field;
			$key   = sanitize_key( (string) ( $field['key'] ?? '' ) );

			if ( '' === $key ) {
				$key = 'field_' . ( (int) $index + 1 );
			}

			$choices = array();

			foreach ( (array) ( $field['choices'] ?? array() ) as $choice ) {
				$choice = (array) $choice;
				$value  = sanitize_key( (string) ( $choice['value'] ?? '' ) );

				if ( '' === $value ) {
					continue;
				}

				$choices[] = array(
					'value' => $value,
					'label' => sanitize_text_field( (string) ( $choice['label'] ?? $value ) ),
					// An add-on price rides with the box line rather than
					// becoming a product of its own.
					'price' => (float) ( $choice['price'] ?? 0 ),
				);
			}

			$out[] = array(
				'key'       => $key,
				'type'      => in_array( $field['type'] ?? '', $types, true ) ? $field['type'] : 'radio',
				'label'     => sanitize_text_field( (string) ( $field['label'] ?? '' ) ),
				'required'  => ! empty( $field['required'] ),
				'maxlength' => max( 0, (int) ( $field['maxlength'] ?? 0 ) ),
				'price'     => (float) ( $field['price'] ?? 0 ),
				'choices'   => $choices,
			);
		}

		return $out;
	}

	/**
	 * Coerce conditions into a predictable shape.
	 *
	 * A condition is "show this when that answer was given". Kept deliberately
	 * small: one field, one operator, one value.
	 *
	 * @param array $conditions Raw conditions.
	 *
	 * @return array[]
	 */
	private static function prepare_conditions( array $conditions ): array {
		$out = array();

		foreach ( $conditions as $condition ) {
			$condition = (array) $condition;
			$field     = sanitize_key( (string) ( $condition['field'] ?? '' ) );

			if ( '' === $field ) {
				continue;
			}

			$out[] = array(
				'field'  => $field,
				'op'     => 'is_not' === ( $condition['op'] ?? 'is' ) ? 'is_not' : 'is',
				'value'  => sanitize_text_field( (string) ( $condition['value'] ?? '' ) ),
				// What the condition governs: the whole step, or one section.
				'target' => sanitize_key( (string) ( $condition['target'] ?? '' ) ),
			);
		}

		return $out;
	}

	/**
	 * Turn a database row into the shape everything else reads.
	 *
	 * @param array $row Raw row.
	 *
	 * @return array
	 */
	private static function decode( array $row ): array {
		$data = json_decode( (string) ( $row['data'] ?? '' ), true );
		$data = is_array( $data ) ? $data : array();

		unset( $row['data'] );

		$row['id']          = (int) $row['id'];
		$row['box_id']      = (int) $row['box_id'];
		$row['rule_value']  = (int) $row['rule_value'];
		$row['sort_order']  = (int) $row['sort_order'];
		$row['synthesised'] = false;
		$row['sections']    = is_array( $data['sections'] ?? null ) ? $data['sections'] : array();
		$row['fields']      = is_array( $data['fields'] ?? null ) ? $data['fields'] : array();
		$row['conditions']  = is_array( $data['conditions'] ?? null ) ? $data['conditions'] : array();

		// The step's own rule, expressed the way BoxRules takes them, so a
		// caller never has to know it came from columns.
		$row['rules'] = $row['rule_value']
			? array(
				array(
					'measure' => $row['rule_measure'],
					'op'      => $row['rule_op'],
					'value'   => $row['rule_value'],
				),
			)
			: array();

		return $row;
	}
}
