<?php
/**
 * A box that is going out, and how far through packing it is.
 *
 * Until now nothing recorded that a shipment happened. A subscription sat in
 * the Upcoming list until its renewal fired and then vanished from it, so a box
 * that failed to go out had nowhere to live and no-one to tell. The order knew
 * money had moved; nothing knew whether anything had been packed.
 *
 * A shipment adds only what an order cannot say — which box, which cycle, and
 * what state the warehouse has it in. Everything else stays on the order:
 * customer, address, contents, money. That division is deliberate, because the
 * WooCommerce order is the record a merchant already trusts and already
 * reconciles against, and a second copy of it would be a second thing to
 * disagree.
 *
 * Shipped and delivered are deliberately absent from the states written here.
 * They belong to the order and to whatever shipping plugin the store runs, and
 * are read from there rather than duplicated — see `is_dispatched()`.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Box
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Box;

defined( 'ABSPATH' ) || exit;

/**
 * Reads and writes box shipments.
 */
class ShipmentRepository {

	/**
	 * Due, nothing done to it yet.
	 */
	const STATUS_SCHEDULED = 'scheduled';

	/**
	 * Being picked and packed.
	 */
	const STATUS_PACKING = 'packing';

	/**
	 * Packed and waiting on the courier.
	 */
	const STATUS_READY = 'ready';

	/**
	 * Something stopped it — a failed renewal, a missing address, a sold-out box.
	 */
	const STATUS_FAILED = 'failed';

	/**
	 * The subscriber skipped this cycle, so nothing ships.
	 */
	const STATUS_SKIPPED = 'skipped';

	/**
	 * Every state we write, in the order a box moves through them.
	 *
	 * @return string[]
	 */
	public static function statuses(): array {
		return array(
			self::STATUS_SCHEDULED,
			self::STATUS_PACKING,
			self::STATUS_READY,
			self::STATUS_FAILED,
			self::STATUS_SKIPPED,
		);
	}

	/**
	 * What each state is called on screen.
	 *
	 * @param string $status Status key.
	 *
	 * @return string
	 */
	public static function status_label( string $status ): string {
		$labels = array(
			self::STATUS_SCHEDULED => __( 'Scheduled', 'subscription-pro' ),
			self::STATUS_PACKING   => __( 'Packing', 'subscription-pro' ),
			self::STATUS_READY     => __( 'Ready to ship', 'subscription-pro' ),
			self::STATUS_FAILED    => __( 'Failed', 'subscription-pro' ),
			self::STATUS_SKIPPED   => __( 'Skipped', 'subscription-pro' ),
		);

		return $labels[ $status ] ?? ucfirst( $status );
	}

	/**
	 * Fully qualified table name.
	 *
	 * @return string
	 */
	public static function table(): string {
		global $wpdb;

		return $wpdb->prefix . 'subscrpt_box_shipment';
	}

	/**
	 * Create or upgrade the table.
	 *
	 * The unique key on (subscription_id, cycle_key, standalone_item_id) is the
	 * point: a cycle cannot double-book. A renewal that fires twice, a retry
	 * after a failed payment, or an admin re-running something all land on the
	 * same row rather than packing the same box twice. A subscription's rows all
	 * carry standalone_item_id 0, so for them the key is (subscription, cycle)
	 * as it always was; a box bought once has no subscription, so its order line
	 * id stands in to keep two such boxes in one month apart, even on one order.
	 *
	 * @return void
	 */
	public static function create_table(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table   = self::table();
		$collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			subscription_id bigint(20) unsigned NOT NULL,
			standalone_item_id bigint(20) unsigned NOT NULL DEFAULT 0,
			order_id bigint(20) unsigned NOT NULL DEFAULT 0,
			box_id bigint(20) unsigned NOT NULL DEFAULT 0,
			product_id bigint(20) unsigned NOT NULL DEFAULT 0,
			cycle_key varchar(20) NOT NULL,
			status varchar(20) NOT NULL DEFAULT 'scheduled',
			contents longtext NULL,
			notes longtext NULL,
			ships_at datetime NULL,
			created_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			updated_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			UNIQUE KEY subscription_cycle_item (subscription_id,cycle_key,standalone_item_id),
			KEY cycle_status (cycle_key,status),
			KEY box_cycle (box_id,cycle_key),
			KEY order_id (order_id)
		) {$collate};";

		dbDelta( $sql );
	}

	/**
	 * Move an existing table to the key one-time boxes need.
	 *
	 * `dbDelta` adds a column but never changes a unique key, so this does it
	 * explicitly. Each step checks first, so running it again changes nothing.
	 *
	 * @return void
	 */
	public static function migrate_one_time_key(): void {
		global $wpdb;

		$table = self::table();

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared
		if ( ! $wpdb->get_results( "SHOW COLUMNS FROM {$table} LIKE 'standalone_item_id'" ) ) {
			$wpdb->query( "ALTER TABLE {$table} ADD COLUMN standalone_item_id bigint(20) unsigned NOT NULL DEFAULT 0 AFTER subscription_id" );
		}

		// The new key goes in before the old one comes out, so the table is
		// never without a unique key.
		if ( ! $wpdb->get_results( "SHOW INDEX FROM {$table} WHERE Key_name = 'subscription_cycle_item'" ) ) {
			$wpdb->query( "ALTER TABLE {$table} ADD UNIQUE KEY subscription_cycle_item (subscription_id,cycle_key,standalone_item_id)" );
		}

		if ( $wpdb->get_results( "SHOW INDEX FROM {$table} WHERE Key_name = 'subscription_cycle'" ) ) {
			$wpdb->query( "ALTER TABLE {$table} DROP INDEX subscription_cycle" );
		}
		// phpcs:enable
	}

	/**
	 * One shipment by id.
	 *
	 * @param int $id Shipment id.
	 *
	 * @return array|null
	 */
	public static function find( int $id ): ?array {
		global $wpdb;

		$table = self::table();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ), ARRAY_A );

		return $row ? self::decode( $row ) : null;
	}

	/**
	 * The shipment a subscription has for one cycle.
	 *
	 * Subscription rows only: a box bought once has no subscription and is
	 * found through for_standalone_item().
	 *
	 * @param int    $subscription_id Subscription id.
	 * @param string $cycle_key       Cycle key.
	 *
	 * @return array|null
	 */
	public static function for_cycle( int $subscription_id, string $cycle_key ): ?array {
		global $wpdb;

		$table = self::table();

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE subscription_id = %d AND cycle_key = %s AND standalone_item_id = 0",
				$subscription_id,
				$cycle_key
			),
			ARRAY_A
		);
		// phpcs:enable

		return $row ? self::decode( $row ) : null;
	}

	/**
	 * The shipment for a box bought once.
	 *
	 * @param int    $item_id   Order line that holds the box.
	 * @param string $cycle_key Cycle key.
	 *
	 * @return array|null
	 */
	public static function for_standalone_item( int $item_id, string $cycle_key ): ?array {
		global $wpdb;

		$table = self::table();

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE subscription_id = %d AND cycle_key = %s AND standalone_item_id = %d",
				0,
				$cycle_key,
				$item_id
			),
			ARRAY_A
		);
		// phpcs:enable

		return $row ? self::decode( $row ) : null;
	}

	/**
	 * The shipment an order is paying for.
	 *
	 * @param int $order_id Order id.
	 *
	 * @return array|null
	 */
	public static function for_order( int $order_id ): ?array {
		global $wpdb;

		$table = self::table();

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE order_id = %d ORDER BY id DESC LIMIT 1", $order_id ),
			ARRAY_A
		);
		// phpcs:enable

		return $row ? self::decode( $row ) : null;
	}

	/**
	 * Every shipment an order is paying for.
	 *
	 * An order holding several boxes bought once has a row per box.
	 *
	 * @param int $order_id Order id.
	 *
	 * @return array[]
	 */
	public static function all_for_order( int $order_id ): array {
		global $wpdb;

		$table = self::table();

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE order_id = %d ORDER BY id ASC", $order_id ),
			ARRAY_A
		);
		// phpcs:enable

		return array_map( array( __CLASS__, 'decode' ), $rows ? $rows : array() );
	}

	/**
	 * Write the shipment for a cycle, or update the one already there.
	 *
	 * Idempotent by design — see the unique key. A caller that fires twice for
	 * one cycle updates the row rather than creating a second box to pack.
	 *
	 * An existing row's status is never overwritten here: a renewal rebuilding
	 * its contents must not quietly reset a shipment the warehouse has already
	 * marked as packing. Status moves through `set_status()` alone.
	 *
	 * @param array $data subscription_id, standalone_item_id, cycle_key, order_id, box_id, product_id, contents, ships_at.
	 *                    A box bought once passes subscription_id 0, the order line as
	 *                    standalone_item_id and the order as order_id.
	 *
	 * @return int Shipment id, or 0 when it could not be written.
	 */
	public static function record( array $data ): int {
		global $wpdb;

		$subscription_id = absint( $data['subscription_id'] ?? 0 );
		$standalone      = $subscription_id ? 0 : absint( $data['standalone_item_id'] ?? 0 );
		$cycle_key       = sanitize_text_field( (string) ( $data['cycle_key'] ?? '' ) );

		if ( ( ! $subscription_id && ! ( $standalone && absint( $data['order_id'] ?? 0 ) ) ) || ! $cycle_key ) {
			return 0;
		}

		$now = current_time( 'mysql', true );

		$row = array(
			'subscription_id' => $subscription_id,
			'cycle_key'       => $cycle_key,
			'order_id'        => absint( $data['order_id'] ?? 0 ),
			'box_id'          => absint( $data['box_id'] ?? 0 ),
			'product_id'      => absint( $data['product_id'] ?? 0 ),
			'contents'        => wp_json_encode( BoxProduct::describe_items( (array) ( $data['contents'] ?? array() ) ) ),
			'updated_at'      => $now,
		);

		if ( ! empty( $data['ships_at'] ) ) {
			$row['ships_at'] = gmdate( 'Y-m-d H:i:s', (int) $data['ships_at'] );
		}

		$existing = $standalone
			? self::for_standalone_item( $standalone, $cycle_key )
			: self::for_cycle( $subscription_id, $cycle_key );

		if ( $existing ) {
			$wpdb->update( self::table(), $row, array( 'id' => (int) $existing['id'] ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

			return (int) $existing['id'];
		}

		$row['standalone_item_id'] = $standalone;
		$row['status']             = self::STATUS_SCHEDULED;
		$row['created_at']         = $now;

		$wpdb->insert( self::table(), $row ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

		return (int) $wpdb->insert_id;
	}

	/**
	 * Move a shipment to another state.
	 *
	 * @param int    $id     Shipment id.
	 * @param string $status One of the states this class writes.
	 * @param string $note   Optional note explaining the move.
	 *
	 * @return bool
	 */
	public static function set_status( int $id, string $status, string $note = '' ): bool {
		global $wpdb;

		if ( ! in_array( $status, self::statuses(), true ) ) {
			return false;
		}

		$shipment = self::find( $id );

		if ( ! $shipment || $shipment['status'] === $status ) {
			return false;
		}

		$notes = $shipment['notes'];

		if ( '' !== $note ) {
			$notes[] = array(
				'at'   => current_time( 'mysql', true ),
				'note' => $note,
			);
		}

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			self::table(),
			array(
				'status'     => $status,
				'notes'      => wp_json_encode( $notes ),
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);

		/**
		 * Fires when a box shipment changes state.
		 *
		 * A shipping plugin or fulfilment integration listens here to know a box
		 * is ready to collect, and can push its own status back onto the order.
		 *
		 * @param int    $id       Shipment id.
		 * @param string $status   New status.
		 * @param string $previous Previous status.
		 * @param array  $shipment The shipment as it was before the change.
		 */
		do_action( 'subscrpt_box_shipment_status_changed', $id, $status, (string) $shipment['status'], $shipment );

		return true;
	}

	/**
	 * Shipments, filtered the way the screens filter them.
	 *
	 * @param array $args cycle_key, status, box_id, subscription_id, search, limit, offset.
	 *
	 * @return array[]
	 */
	public static function all( array $args = array() ): array {
		global $wpdb;

		$table  = self::table();
		$where  = array( '1=1' );
		$params = array();

		if ( ! empty( $args['cycle_key'] ) ) {
			$where[]  = 'cycle_key = %s';
			$params[] = sanitize_text_field( (string) $args['cycle_key'] );
		}

		if ( ! empty( $args['status'] ) ) {
			$statuses     = array_values( array_intersect( (array) $args['status'], self::statuses() ) );
			$placeholders = implode( ',', array_fill( 0, max( 1, count( $statuses ) ), '%s' ) );
			$where[]      = "status IN ({$placeholders})";
			$params       = array_merge( $params, $statuses ? $statuses : array( '' ) );
		}

		if ( ! empty( $args['box_id'] ) ) {
			$where[]  = 'box_id = %d';
			$params[] = absint( $args['box_id'] );
		}

		if ( ! empty( $args['subscription_id'] ) ) {
			$where[]  = 'subscription_id = %d';
			$params[] = absint( $args['subscription_id'] );
		}

		$limit  = max( 1, min( 500, (int) ( $args['limit'] ?? 100 ) ) );
		$offset = max( 0, (int) ( $args['offset'] ?? 0 ) );

		$params[] = $limit;
		$params[] = $offset;

		$clause = implode( ' AND ', $where );

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE {$clause} ORDER BY ships_at ASC, id ASC LIMIT %d OFFSET %d",
				$params
			),
			ARRAY_A
		);
		// phpcs:enable

		return array_map( array( __CLASS__, 'decode' ), $rows ? $rows : array() );
	}

	/**
	 * How many shipments sit in each state for a cycle.
	 *
	 * Drives the counts above the list, so a merchant sees "18 scheduled, 4
	 * packing, 2 failed" before reading a single row.
	 *
	 * @param string $cycle_key Cycle key.
	 * @param int    $box_id    Only this box, or 0 for every box — the same filter
	 *                          the list beside the counts is using.
	 *
	 * @return array<string,int>
	 */
	public static function counts_for_cycle( string $cycle_key, int $box_id = 0 ): array {
		global $wpdb;

		$table  = self::table();
		$counts = array_fill_keys( self::statuses(), 0 );

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$where  = 'cycle_key = %s';
		$params = array( $cycle_key );

		if ( $box_id ) {
			$where   .= ' AND box_id = %d';
			$params[] = $box_id;
		}

		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT status, COUNT(*) AS total FROM {$table} WHERE {$where} GROUP BY status", $params ),
			ARRAY_A
		);
		// phpcs:enable

		foreach ( (array) $rows as $row ) {
			$counts[ (string) $row['status'] ] = (int) $row['total'];
		}

		return $counts;
	}

	/**
	 * Has this shipment actually gone out?
	 *
	 * Deliberately a read, never a state of ours. Whether a parcel has shipped
	 * or been delivered is the order's business and the shipping plugin's, and
	 * copying it here would create a second answer that drifts from the first.
	 *
	 * @param array $shipment Shipment row.
	 *
	 * @return bool
	 */
	public static function is_dispatched( array $shipment ): bool {
		$order = $shipment['order_id'] ? wc_get_order( $shipment['order_id'] ) : null;

		if ( ! $order instanceof \WC_Order ) {
			return false;
		}

		/**
		 * Filters whether a box has left the building.
		 *
		 * Shipping plugins record dispatch in their own meta, and there is no
		 * shared convention for it, so this is the seam rather than a guess.
		 *
		 * @param bool      $dispatched Whether the order looks dispatched.
		 * @param \WC_Order $order      The order carrying the box.
		 * @param array     $shipment   Shipment row.
		 */
		return (bool) apply_filters(
			'subscrpt_box_shipment_is_dispatched',
			$order->has_status( array( 'completed' ) ),
			$order,
			$shipment
		);
	}

	/**
	 * Delete a shipment.
	 *
	 * @param int $id Shipment id.
	 *
	 * @return bool
	 */
	public static function delete( int $id ): bool {
		global $wpdb;

		return (bool) $wpdb->delete( self::table(), array( 'id' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	}

	/**
	 * Turn a database row into the shape everything else reads.
	 *
	 * @param array $row Raw row.
	 *
	 * @return array
	 */
	private static function decode( array $row ): array {
		$contents = json_decode( (string) $row['contents'], true );
		$notes    = json_decode( (string) $row['notes'], true );

		$row['id']              = (int) $row['id'];
		$row['subscription_id'] = (int) $row['subscription_id'];
		$row['order_id']        = (int) $row['order_id'];
		$row['box_id']          = (int) $row['box_id'];
		$row['product_id']      = (int) $row['product_id'];
		$row['contents']        = BoxProduct::normalise_items( is_array( $contents ) ? $contents : array() );
		$row['notes']           = is_array( $notes ) ? $notes : array();
		$row['cycle_label']     = BoxCycle::label( (string) $row['cycle_key'] );
		$row['status_label']    = self::status_label( (string) $row['status'] );

		return $row;
	}
}
