<?php
/**
 * Which boxes a product sells.
 *
 * This class used to *be* the storage: thirteen meta keys on a product, read
 * and written here. A box is now its own record (`Box`, `BoxRepository`) and a
 * product merely connects to one, so what is left here is the product-facing
 * question — given this product, which box are we talking about? — plus the
 * item helpers, which only ever took selection arrays and are used from a
 * dozen places that have nothing to do with storage.
 *
 * Every accessor the old class exposed still works. They funnel through
 * `resolve()` and answer from the connected box; a product with no connection
 * is not a box, whatever meta it still carries. That meta is read only by
 * `BoxMigration`, which converts it into records on upgrade.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Box
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Box;

defined( 'ABSPATH' ) || exit;

/**
 * Resolves the box behind a product.
 */
class BoxProduct {

	/**
	 * The merchant packs it; contents never vary.
	 */
	const TYPE_CURATED = Box::TYPE_CURATED;

	/**
	 * The customer fills it from a pool.
	 */
	const TYPE_BUILD = Box::TYPE_BUILD;

	/**
	 * The merchant publishes each cycle's contents.
	 */
	const TYPE_EDITION = Box::TYPE_EDITION;

	// ---- Resolution ----

	/**
	 * Every box a product sells.
	 *
	 * @param int $product_id   Parent product id.
	 * @param int $variation_id Variation id, or 0.
	 *
	 * @return Box[]
	 */
	public static function boxes_for( int $product_id, int $variation_id = 0 ): array {
		return BoxRepository::resolve_for_product( $product_id, $variation_id );
	}

	/**
	 * One named box, if this product actually sells it.
	 *
	 * The guard matters: the box id arrives from a form post, and a customer
	 * must not be able to buy a box by id that this product does not offer.
	 *
	 * @param int $product_id   Parent product id.
	 * @param int $box_id       Box id.
	 * @param int $variation_id Variation id, or 0.
	 *
	 * @return Box|null
	 */
	public static function box_for( int $product_id, int $box_id, int $variation_id = 0 ): ?Box {
		$box_id = absint( $box_id );

		if ( ! $box_id ) {
			return null;
		}

		foreach ( self::boxes_for( $product_id, $variation_id ) as $box ) {
			if ( $box->id() === $box_id ) {
				return $box;
			}
		}

		return null;
	}

	/**
	 * The box to assume when none was named.
	 *
	 * A product selling exactly one box — the common case — never asks the
	 * customer to choose, so every caller that has only a product id lands here.
	 *
	 * @param int $product_id   Parent product id.
	 * @param int $variation_id Variation id, or 0.
	 *
	 * @return Box|null
	 */
	public static function primary_box( int $product_id, int $variation_id = 0 ): ?Box {
		$boxes = self::boxes_for( $product_id, $variation_id );

		return $boxes ? $boxes[0] : null;
	}

	/**
	 * The box behind a product.
	 *
	 * Naming a box is a different question from asking for "the" box, and the
	 * two must not share an answer. A named box this product does not sell is
	 * refused outright: the id arrives from a form post, so falling back to the
	 * primary box would quietly sell a box the product never
	 * offered, using an id the shopper supplied.
	 *
	 * @param int $product_id   Parent product id.
	 * @param int $variation_id Variation id, or 0.
	 * @param int $box_id       Explicit box id, or 0 for the primary one.
	 *
	 * @return Box|null
	 */
	public static function resolve( int $product_id, int $variation_id = 0, int $box_id = 0 ): ?Box {
		if ( $box_id ) {
			return self::box_for( $product_id, $box_id, $variation_id );
		}

		return self::primary_box( $product_id, $variation_id );
	}

	// ---- Which boxes can hold a product ----

	/**
	 * The option holding the version every cached answer is keyed on.
	 */
	const CONTAINING_VERSION_OPTION = 'subscrpt_box_containing_ver';

	/**
	 * Boxes a shopper can add this product to.
	 *
	 * Only customer-built, active boxes with an active seller count: those are
	 * the ones the cart service will accept. Variable products are left out
	 * because a variation cannot yet be a box item. The answer is held in a
	 * transient keyed on a version, so a group of products can be invalidated
	 * by bumping one option.
	 *
	 * @param int $product_id Product id.
	 *
	 * @return array[] Each entry: box (Box), product_id (seller), variation_id (always 0).
	 */
	public static function boxes_containing( int $product_id ): array {
		$product_id = absint( $product_id );

		if ( ! $product_id ) {
			return array();
		}

		$key    = 'subscrpt_box_containing_' . $product_id . '_' . self::containing_version();
		$cached = get_transient( $key );

		if ( is_array( $cached ) ) {
			return self::hydrate_containing( $cached );
		}

		$stored = self::compute_containing( $product_id );

		set_transient( $key, $stored, DAY_IN_SECONDS );

		return self::hydrate_containing( $stored );
	}

	/**
	 * Forget every cached `boxes_containing()` answer.
	 *
	 * @return void
	 */
	public static function flush_containing_cache(): void {
		update_option( self::CONTAINING_VERSION_OPTION, self::containing_version() + 1 );
	}

	/**
	 * Listen for the changes outside the box tables that alter a pool.
	 *
	 * A pool can name a category or tag, so assigning a product to one changes
	 * which boxes hold it without any box being saved.
	 *
	 * @return void
	 */
	public static function register_hooks(): void {
		add_action( 'set_object_terms', array( __CLASS__, 'on_terms_set' ), 10, 4 );
	}

	/**
	 * Flush when a product's category or tag changes.
	 *
	 * @param int    $object_id Object id.
	 * @param array  $terms     Terms as given.
	 * @param array  $tt_ids    Term taxonomy ids.
	 * @param string $taxonomy  Taxonomy.
	 *
	 * @return void
	 */
	public static function on_terms_set( $object_id, $terms = array(), $tt_ids = array(), $taxonomy = '' ): void {
		unset( $terms, $tt_ids );

		if ( ! in_array( $taxonomy, array( 'product_cat', 'product_tag' ), true ) ) {
			return;
		}

		if ( 'product' !== get_post_type( $object_id ) ) {
			return;
		}

		self::flush_containing_cache();
	}

	/**
	 * The current cache version.
	 *
	 * @return int
	 */
	private static function containing_version(): int {
		return max( 1, (int) get_option( self::CONTAINING_VERSION_OPTION, 1 ) );
	}

	/**
	 * Work out the answer from the box tables.
	 *
	 * Stored as box rows so the transient never serialises a `Box` and a cache
	 * hit costs no query.
	 *
	 * @param int $product_id Product id.
	 *
	 * @return array[] Each entry: box (row), product_id.
	 */
	private static function compute_containing( int $product_id ): array {
		$product = wc_get_product( $product_id );

		if ( ! $product instanceof \WC_Product || $product->is_type( 'variable' ) ) {
			return array();
		}

		$found = array();

		foreach ( BoxRepository::all( array( 'status' => Box::STATUS_ACTIVE ) ) as $box ) {
			if ( ! $box->is_customer_built() ) {
				continue;
			}

			$seller = self::seller_of( $box->id() );

			if ( ! $seller || ! in_array( $product_id, $box->pool_product_ids(), true ) ) {
				continue;
			}

			$found[] = array(
				'box'        => $box->to_array(),
				'product_id' => $seller,
			);
		}

		return $found;
	}

	/**
	 * The product a box is bought through.
	 *
	 * The first active relation for the whole product, else the first active
	 * one.
	 *
	 * @param int $box_id Box id.
	 *
	 * @return int Seller product id, or 0 when nothing sells it.
	 */
	private static function seller_of( int $box_id ): int {
		$first = 0;

		foreach ( BoxRepository::connections_for_box( $box_id ) as $relation ) {
			if ( 'active' !== $relation['status'] ) {
				continue;
			}

			if ( 0 === $relation['vid'] ) {
				return $relation['oid'];
			}

			$first = $first ? $first : $relation['oid'];
		}

		return $first;
	}

	/**
	 * Turn stored rows back into boxes.
	 *
	 * @param array[] $stored Entries from `compute_containing()`.
	 *
	 * @return array[]
	 */
	private static function hydrate_containing( array $stored ): array {
		$rows = array();

		foreach ( $stored as $entry ) {
			$rows[] = array(
				'box'          => new Box( $entry['box'] ),
				'product_id'   => (int) $entry['product_id'],
				'variation_id' => 0,
			);
		}

		return $rows;
	}

	// ---- The accessors every call site already uses ----

	/**
	 * Is this product a subscription box?
	 *
	 * @param \WC_Product|int $product Product or product id.
	 *
	 * @return bool
	 */
	public static function is_box( $product ): bool {
		$product = is_numeric( $product ) ? wc_get_product( $product ) : $product;

		if ( ! $product instanceof \WC_Product ) {
			return false;
		}

		// A variation is a box when its parent is.
		$product_id = $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id();

		return null !== self::resolve( (int) $product_id );
	}

	/**
	 * The box type for a product.
	 *
	 * @param \WC_Product|int $product Product or product id.
	 *
	 * @return string One of curated|build|edition. Empty when not a box.
	 */
	public static function type( $product ): string {
		$product = is_numeric( $product ) ? wc_get_product( $product ) : $product;

		if ( ! $product instanceof \WC_Product ) {
			return '';
		}

		$product_id = $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id();
		$box        = self::resolve( (int) $product_id );

		return $box ? $box->type() : '';
	}

	/**
	 * Does the customer choose this box's contents?
	 *
	 * @param \WC_Product|int $product Product or product id.
	 *
	 * @return bool
	 */
	public static function is_customer_built( $product ): bool {
		return self::TYPE_BUILD === self::type( $product );
	}

	/**
	 * Does this product bill on a schedule?
	 *
	 * A subscription box always recurs, and two places have to ask this: the
	 * connect row, which refuses to attach a box to a product with no cycle, and
	 * the cart, which refuses to sell one. It lives here rather than on either of
	 * them because a rule enforced in only one of the two places is not enforced
	 * at all — a product could be sold before it was ever connected.
	 *
	 * Checks the three ways a product can carry a cycle: the classic meta, a
	 * connected plan, and a variation's own meta.
	 *
	 * @param int $product_id Product id.
	 *
	 * @return bool
	 */
	public static function has_cadence( int $product_id ): bool {
		if ( 'yes' === get_post_meta( $product_id, '_subscrpt_enabled', true ) ) {
			return true;
		}

		if ( function_exists( 'subscrpt_product_has_plan' ) && subscrpt_product_has_plan( $product_id ) ) {
			return true;
		}

		$product = wc_get_product( $product_id );

		if ( $product instanceof \WC_Product && $product->is_type( 'variable' ) ) {
			foreach ( $product->get_children() as $subscrpt_variation_id ) {
				if ( 'yes' === get_post_meta( $subscrpt_variation_id, '_subscrpt_enabled', true ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Size limits, honouring a per-variation override.
	 *
	 * @param int $product_id   Parent product id.
	 * @param int $variation_id Variation id, or 0.
	 *
	 * @return array{min:int,max:int}
	 */
	public static function size( int $product_id, int $variation_id = 0 ): array {
		$box = self::primary_box( $product_id, $variation_id );

		return $box ? $box->size() : array(
			'min' => 0,
			'max' => 0,
		);
	}

	/**
	 * Most units of a single product allowed in one box.
	 *
	 * @param int $product_id Parent product id.
	 *
	 * @return int
	 */
	public static function max_per_item( int $product_id ): int {
		$box = self::primary_box( $product_id );

		return $box ? $box->max_per_item() : 0;
	}

	/**
	 * The curated contents of a box.
	 *
	 * @param int $product_id Parent product id.
	 *
	 * @return array[]
	 */
	public static function curated_items( int $product_id ): array {
		$box = self::primary_box( $product_id );

		return $box ? $box->curated_items() : array();
	}

	/**
	 * The picks a build-your-own box starts with.
	 *
	 * @param int $product_id Parent product id.
	 *
	 * @return array[]
	 */
	public static function default_items( int $product_id ): array {
		$box = self::primary_box( $product_id );

		return $box ? $box->default_items() : array();
	}

	/**
	 * The pool definition a build-your-own box picks from.
	 *
	 * @param int $product_id Parent product id.
	 *
	 * @return array
	 */
	public static function pool( int $product_id ): array {
		$box = self::primary_box( $product_id );

		return $box ? $box->pool() : array(
			'products'   => array(),
			'categories' => array(),
			'tags'       => array(),
			'exclude'    => array(),
		);
	}

	/**
	 * Every product id a shopper may pick for this box.
	 *
	 * @param int $product_id Parent product id.
	 *
	 * @return int[]
	 */
	public static function pool_product_ids( int $product_id ): array {
		$box = self::primary_box( $product_id );

		return $box ? $box->pool_product_ids() : array();
	}

	/**
	 * Days before renewal that this box's contents lock.
	 *
	 * @param int $product_id Parent product id.
	 *
	 * @return int
	 */
	public static function lock_days( int $product_id ): int {
		$box = self::primary_box( $product_id );

		return $box ? $box->lock_days() : max( 0, (int) get_option( 'subscrpt_box_lock_days', 3 ) );
	}

	/**
	 * The rules a subscription copies at sign-up.
	 *
	 * @param int $product_id   Parent product id.
	 * @param int $variation_id Variation id, or 0.
	 *
	 * @return array
	 */
	public static function rules( int $product_id, int $variation_id = 0 ): array {
		$box = self::primary_box( $product_id, $variation_id );

		return $box ? $box->rules() : array();
	}

	/**
	 * Validate a selection against a box's rules.
	 *
	 * @param array      $items        Selection.
	 * @param int        $product_id   Parent product id.
	 * @param int        $variation_id Variation id, or 0.
	 * @param int[]|null $allowed      Allowed product ids, or null to resolve.
	 *
	 * @return true|string
	 */
	public static function validate( array $items, int $product_id, int $variation_id = 0, ?array $allowed = null ) {
		$box = self::primary_box( $product_id, $variation_id );

		return $box ? $box->validate( $items, $allowed ) : true;
	}

	// ---- Selection helpers ----
	//
	// These never touched storage: they take a selection array and hand back a
	// selection array. A dozen callers depend on them, so they stay put.

	/**
	 * Total units in a selection.
	 *
	 * @param array $items Selection.
	 *
	 * @return int
	 */
	public static function count_units( array $items ): int {
		$count = 0;

		foreach ( self::normalise_items( $items ) as $item ) {
			$count += $item['qty'];
		}

		return $count;
	}

	/**
	 * Whether a product is a variation of a given parent.
	 *
	 * @param int $variation_id Variation id.
	 * @param int $product_id   Parent product id.
	 *
	 * @return bool
	 */
	public static function is_variation_of( int $variation_id, int $product_id ): bool {
		$variation = wc_get_product( $variation_id );

		return $variation instanceof \WC_Product
			&& $variation->is_type( 'variation' )
			&& (int) $variation->get_parent_id() === $product_id;
	}

	/**
	 * Coerce a selection into a predictable shape.
	 *
	 * Selections arrive from a form post, from a box a merchant saved, and from
	 * order-item meta written months ago. Everything downstream — the renewal
	 * builder, the pick list, the emails — reads the shape this returns.
	 *
	 * @param mixed $items Raw selection.
	 *
	 * @return array[] Each entry: product_id, variation_id, qty, once. The same
	 *                  product every cycle and once stays two entries.
	 */
	public static function normalise_items( $items ): array {
		if ( ! is_array( $items ) ) {
			return array();
		}

		$clean = array();

		foreach ( $items as $key => $item ) {
			// Accept the builder's product_id => qty map as well as full rows.
			if ( ! is_array( $item ) ) {
				$item = array(
					'product_id' => $key,
					'qty'        => $item,
				);
			}

			$product_id = absint( $item['product_id'] ?? 0 );
			$qty        = (int) ( $item['qty'] ?? 0 );

			if ( ! $product_id || $qty < 1 ) {
				continue;
			}

			$variation_id = absint( $item['variation_id'] ?? 0 );

			// The variation is what gets priced, named and shipped, so it must be one
			// of this product's own; anything else would pass the product's checks
			// and ship a different product.
			if ( $variation_id === $product_id ) {
				$variation_id = 0;
			} elseif ( $variation_id && ! self::is_variation_of( $variation_id, $product_id ) ) {
				continue;
			}

			$once         = in_array( $item['once'] ?? false, array( true, 1, '1', 'true', 'yes', 'on' ), true );
			$index        = $product_id . ':' . $variation_id . ':' . ( $once ? '1' : '0' );

			if ( isset( $clean[ $index ] ) ) {
				$clean[ $index ]['qty'] += $qty;
				continue;
			}

			$clean[ $index ] = array(
				'product_id'   => $product_id,
				'variation_id' => $variation_id,
				'qty'          => $qty,
				'once'         => $once,
			);
		}

		return array_values( $clean );
	}

	/**
	 * What a line of several boxes packs: each item of one box, that many times.
	 *
	 * @param array $items One box's selection.
	 * @param int   $boxes Boxes on the line.
	 *
	 * @return array[] Normalised items.
	 */
	public static function times( array $items, int $boxes ): array {
		$boxes = max( 1, $boxes );
		$items = self::normalise_items( $items );

		foreach ( $items as &$item ) {
			$item['qty'] *= $boxes;
		}

		unset( $item );

		return $items;
	}

	/**
	 * Split a selection into what ships every cycle and what ships once.
	 *
	 * @param array $items Selection.
	 *
	 * @return array Normalised items, recurring first and once second.
	 *
	 * @phpstan-return array{0: array, 1: array}
	 */
	public static function split_once( array $items ): array {
		$recurring = array();
		$once      = array();

		foreach ( self::normalise_items( $items ) as $item ) {
			if ( $item['once'] ) {
				$once[] = $item;
			} else {
				$recurring[] = $item;
			}
		}

		return array( $recurring, $once );
	}

	/**
	 * Add the names and SKUs a stored selection needs to survive its products.
	 *
	 * An order line has to keep reading correctly after a product is renamed or
	 * deleted, so the snapshot carries the name and SKU as of the moment it was
	 * written rather than resolving them on render.
	 *
	 * @param array $items Selection.
	 *
	 * @return array[] Each entry: product_id, variation_id, qty, once, name, sku.
	 */
	public static function describe_items( array $items ): array {
		$described = array();

		foreach ( self::normalise_items( $items ) as $item ) {
			$product = wc_get_product( $item['variation_id'] ? $item['variation_id'] : $item['product_id'] );

			$item['name'] = $product ? $product->get_name() : '';
			$item['sku']  = $product ? $product->get_sku() : '';

			$described[] = $item;
		}

		return $described;
	}
}
