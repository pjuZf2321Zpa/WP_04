<?php
/**
 * A box on an order.
 *
 * The box is one priced line carrying a snapshot of its contents, and each
 * packed product rides along as a $0 line pointing back at it. That shape is
 * what lets stock, packing slips, fulfilment plugins and analytics see real
 * SKUs while every subscription-side assumption — one product per subscription
 * — stays exactly as it was.
 *
 * The same rebuild runs for renewals, early renewals and payment retries,
 * because each of those builds a fresh order from the subscription.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Box
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Box;

defined( 'ABSPATH' ) || exit;

/**
 * Writes and reads a box on an order.
 */
class BoxOrder {

	/**
	 * Snapshot of what the box line holds.
	 */
	const META_CONTENTS = '_subscrpt_box_contents';

	/**
	 * The edition the contents came from.
	 */
	const META_EDITION = '_subscrpt_box_edition';

	/**
	 * On a content line: the box line it belongs to.
	 */
	const META_PARENT = '_subscrpt_box_parent';

	/**
	 * On a box line: its content lines have been added.
	 */
	const META_EXPANDED = '_subscrpt_box_expanded';

	/**
	 * Which box this line is, when the product sells more than one.
	 */
	const META_BOX = '_subscrpt_box_id';

	/**
	 * Which cycle this line is the box for, e.g. 2026-10.
	 *
	 * On the order so that a shipping or fulfilment plugin can answer "which
	 * month is this parcel?" from the order alone, without joining back to our
	 * shipment table or knowing it exists.
	 */
	const META_CYCLE = '_subscrpt_box_cycle';

	/**
	 * On a box line priced by its contents: the recurring price agreed at checkout.
	 */
	const META_PRICE = '_subscrpt_box_price';

	/**
	 * On a box line priced by its contents: the pricing it was sold under.
	 */
	const META_PRICING = '_subscrpt_box_pricing';

	/**
	 * Order line meta: `yes` when the box was bought once, with no subscription.
	 */
	const META_ONE_TIME = '_subscrpt_box_one_time';

	/**
	 * On a renewal's box line: the subscription it renews.
	 */
	const META_RENEWAL_OF = '_subscrpt_box_renewal_of';

	/**
	 * On a renewal's box line: the renewal date it was built for.
	 *
	 * A retry for an unpaid renewal is built for the same date, so this is
	 * what tells two orders for one box apart from two boxes.
	 */
	const META_DUE = '_subscrpt_box_due';

	/**
	 * On a fixed box's renewal line: its subtotal and total before once items were added.
	 */
	const META_AGREED_LINE = '_subscrpt_box_agreed_line';

	/**
	 * Register hooks.
	 */
	public function __construct() {
		add_action( 'woocommerce_checkout_create_order_line_item', array( $this, 'stamp_box_line' ), 20, 4 );

		// Priority 5: content lines must exist before free's subscription
		// creation loop runs at 10, and long before payment reduces stock.
		add_action( 'woocommerce_checkout_order_processed', array( $this, 'expand_order' ), 5 );
		add_action( 'woocommerce_store_api_checkout_order_processed', array( $this, 'expand_order_object' ), 5 );

		// Priority 6: after the content lines exist, before free's subscription loop.
		add_action( 'woocommerce_checkout_order_processed', array( $this, 'record_one_time_shipments_by_id' ), 6 );
		add_action( 'woocommerce_store_api_checkout_order_processed', array( $this, 'record_one_time_shipments' ), 6 );

		// Priority 8: after a pending downgrade is applied (5), before the
		// coupon listener (10), and before totals are calculated.
		add_filter( 'subscrpt_before_saving_renewal_order', array( $this, 'rebuild_renewal' ), 8, 3 );
		add_filter( 'subscrpt_before_saving_early_renewal_order', array( $this, 'rebuild_renewal' ), 8, 3 );

		// A box nobody paid for must not be packed, and one paid on retry must be.
		add_action( 'woocommerce_order_status_changed', array( $this, 'follow_payment' ), 10, 3 );
		add_action( 'woocommerce_trash_order', array( $this, 'follow_trash' ) );

		add_filter( 'woocommerce_hidden_order_itemmeta', array( $this, 'hide_box_itemmeta' ) );
		add_action( 'woocommerce_order_item_meta_end', array( $this, 'render_contents' ), 10, 4 );
		add_action( 'woocommerce_email_header', array( __CLASS__, 'enter_email' ), 1 );
		add_action( 'woocommerce_email_footer', array( __CLASS__, 'leave_email' ), 99 );
		add_filter( 'wp_mail', array( __CLASS__, 'mail_sent' ), 1 );
		add_action( 'shutdown', array( __CLASS__, 'leave_email' ) );

		// Presentation only: the lines stay on the order for stock and packing.
		add_filter( 'woocommerce_order_item_visible', array( $this, 'item_visible' ), 10, 2 );
	}

	/**
	 * Copy the cart line's selection onto the order line.
	 *
	 * Fired by both the classic checkout and the Store API.
	 *
	 * @param \WC_Order_Item_Product $item          Order line being created.
	 * @param string                 $cart_item_key Cart item key.
	 * @param array                  $values        Cart item.
	 * @param \WC_Order              $order         Order.
	 *
	 * @return void
	 */
	public function stamp_box_line( $item, $cart_item_key, $values, $order ): void {
		if ( empty( $values[ BoxCart::CART_KEY ]['items'] ) ) {
			return;
		}

		$item->add_meta_data( self::META_CONTENTS, BoxProduct::describe_items( $values[ BoxCart::CART_KEY ]['items'] ), true );

		if ( ! empty( $values[ BoxCart::CART_KEY ]['box_id'] ) ) {
			$item->add_meta_data( self::META_BOX, (int) $values[ BoxCart::CART_KEY ]['box_id'], true );
		}

		if ( ! empty( $values[ BoxCart::CART_KEY ]['one_time'] ) ) {
			$item->add_meta_data( self::META_ONE_TIME, 'yes', true );
		}

		$created = $order instanceof \WC_Order && $order->get_date_created()
			? $order->get_date_created()->getTimestamp()
			: time();

		$item->add_meta_data( self::META_CYCLE, BoxCycle::key( $created ), true );

		$quote = $values[ BoxCart::CART_KEY ]['quote'] ?? null;

		if ( ! empty( $quote['is_sum'] ) ) {
			$box = BoxProduct::resolve(
				(int) ( $values['product_id'] ?? 0 ),
				(int) ( $values['variation_id'] ?? 0 ),
				(int) ( $values[ BoxCart::CART_KEY ]['box_id'] ?? 0 )
			);

			$item->add_meta_data( self::META_PRICE, (float) $quote['recurring'], true );

			if ( $box ) {
				$item->add_meta_data( self::META_PRICING, $box->pricing(), true );
			}
		}

		if ( ! empty( $values[ BoxCart::CART_KEY ]['edition'] ) ) {
			$item->add_meta_data( self::META_EDITION, (int) $values[ BoxCart::CART_KEY ]['edition'], true );
		}
	}

	/**
	 * Add content lines after a classic checkout.
	 *
	 * @param int $order_id Order id.
	 *
	 * @return void
	 */
	public function expand_order( $order_id ): void {
		$order = wc_get_order( $order_id );

		if ( $order ) {
			self::add_content_lines( $order );
		}
	}

	/**
	 * Add content lines after a Store API checkout.
	 *
	 * @param \WC_Order $order Order.
	 *
	 * @return void
	 */
	public function expand_order_object( $order ): void {
		if ( $order instanceof \WC_Order ) {
			self::add_content_lines( $order );
		}
	}

	/**
	 * Record one-time box shipments after a classic checkout.
	 *
	 * @param int $order_id Order id.
	 *
	 * @return void
	 */
	public function record_one_time_shipments_by_id( $order_id ): void {
		$order = wc_get_order( $order_id );

		if ( $order ) {
			$this->record_one_time_shipments( $order );
		}
	}

	/**
	 * Give every box bought once on this order a shipment.
	 *
	 * A subscription box gets its shipment when its subscription is created. A
	 * one-time box has no subscription, so without this nothing would know it
	 * had to be packed.
	 *
	 * @param \WC_Order $order Order.
	 *
	 * @return void
	 */
	public function record_one_time_shipments( $order ): void {
		if ( ! $order instanceof \WC_Order ) {
			return;
		}

		$created = $order->get_date_created() ? $order->get_date_created()->getTimestamp() : time();

		foreach ( $order->get_items() as $item ) {
			if ( ! $item instanceof \WC_Order_Item_Product || 'yes' !== $item->get_meta( self::META_ONE_TIME ) ) {
				continue;
			}

			$contents = $item->get_meta( self::META_CONTENTS );

			if ( empty( $contents ) || ! is_array( $contents ) ) {
				continue;
			}

			ShipmentRepository::record(
				array(
					'subscription_id'    => 0,
					'standalone_item_id' => $item->get_id(),
					'order_id'           => $order->get_id(),
					'cycle_key'          => BoxCycle::key( $created ),
					'box_id'             => (int) $item->get_meta( self::META_BOX ),
					'product_id'         => (int) $item->get_product_id(),
					'contents'           => BoxProduct::times( $contents, (int) $item->get_quantity() ),
					'ships_at'           => $created,
				)
			);
		}
	}

	/**
	 * Put a $0 line on the order for every product in every box on it.
	 *
	 * @param \WC_Order $order Order.
	 *
	 * @return int How many lines were added.
	 */
	public static function add_content_lines( \WC_Order $order ): int {
		$added = 0;

		foreach ( $order->get_items() as $item ) {
			if ( ! $item instanceof \WC_Order_Item_Product ) {
				continue;
			}

			if ( $item->get_meta( self::META_PARENT ) || 'yes' === $item->get_meta( self::META_EXPANDED ) ) {
				continue;
			}

			$contents = $item->get_meta( self::META_CONTENTS );

			if ( empty( $contents ) || ! is_array( $contents ) ) {
				continue;
			}

			// The snapshot is one box; a line of several boxes packs each of them.
			foreach ( BoxProduct::times( $contents, (int) $item->get_quantity() ) as $packed ) {
				$product = wc_get_product( $packed['variation_id'] ? $packed['variation_id'] : $packed['product_id'] );

				if ( ! $product instanceof \WC_Product ) {
					continue;
				}

				$line_id = $order->add_product(
					$product,
					(int) $packed['qty'],
					array(
						'subtotal' => 0,
						'total'    => 0,
					)
				);

				if ( ! $line_id ) {
					continue;
				}

				wc_update_order_item_meta( $line_id, self::META_PARENT, $item->get_id() );
				++$added;
			}

			$item->update_meta_data( self::META_EXPANDED, 'yes' );
			$item->save();
		}

		if ( $added ) {
			$order->save();
		}

		return $added;
	}

	/**
	 * Rebuild a renewal order so it ships the box the subscriber has now.
	 *
	 * Free hands over a renewal order holding one line — the box product — with
	 * the price the subscription agreed. This fills that box: resolve what it
	 * should hold, drop or replace anything out of stock, stamp the snapshot,
	 * and add the content lines. A box priced by its contents is then charged
	 * for what it holds; see price_renewal_line(). Totals, taxes included, are
	 * calculated after this returns.
	 *
	 * Refunds: the box line carries the whole amount and the content lines are
	 * $0, so a renewal is refunded against the box line.
	 *
	 * @param \WC_Order $new_order       Renewal order being built.
	 * @param \WC_Order $old_order       Order it was cloned from.
	 * @param int       $subscription_id Subscription id.
	 *
	 * @return \WC_Order
	 */
	public function rebuild_renewal( $new_order, $old_order, $subscription_id ) {
		if ( ! $new_order instanceof \WC_Order ) {
			return $new_order;
		}

		$subscription_id = (int) $subscription_id;

		if ( ! BoxSubscription::is_box( $subscription_id ) ) {
			return $new_order;
		}

		$box_line = null;

		foreach ( $new_order->get_items() as $item ) {
			if ( $item instanceof \WC_Order_Item_Product && ! $item->get_meta( self::META_PARENT ) ) {
				$box_line = $item;
				break;
			}
		}

		if ( ! $box_line ) {
			return $new_order;
		}

		// An edition box takes the published edition for this renewal unless the
		// subscriber already has it, or their box has locked.
		BoxSubscription::materialise_edition( $subscription_id );

		$rules    = BoxSubscription::rules( $subscription_id );
		$contents = BoxSubscription::contents( $subscription_id );
		$notes    = array();

		$contents = BoxStock::resolve_for_box(
			$contents,
			BoxSubscription::box( $subscription_id ),
			(string) ( $rules['stock_rule'] ?? BoxStock::RULE_REPLACE ),
			$notes
		);

		/**
		 * Filters what a renewal order ships for a box.
		 *
		 * @param array     $contents        Resolved contents.
		 * @param int       $subscription_id Subscription id.
		 * @param \WC_Order $new_order       Renewal order being built.
		 */
		$contents = apply_filters( 'subscrpt_box_renewal_contents', $contents, $subscription_id, $new_order );

		// The box belongs to the month the renewal is due, not the day it runs.
		// Free moves the next date only once payment lands, so here it is still
		// the date being renewed — whether that runs early, late, or after a skip.
		$due = (int) get_post_meta( $subscription_id, '_subscrpt_next_date', true );
		$due = $due ? $due : time();

		// The snapshot keeps each row's once flag: paying for this order takes
		// exactly the once rows it carries out of the subscription.
		$box_line->update_meta_data( self::META_CONTENTS, BoxProduct::describe_items( $contents ) );
		$box_line->update_meta_data( self::META_CYCLE, BoxCycle::key( $due ) );
		$box_line->update_meta_data( self::META_RENEWAL_OF, $subscription_id );
		$box_line->update_meta_data( self::META_DUE, $due );
		$box_line->delete_meta_data( self::META_EXPANDED );

		self::price_renewal_line( $box_line, $subscription_id, $contents );

		$edition_id = (int) get_post_meta( $subscription_id, BoxSubscription::META_EDITION, true );

		if ( $edition_id ) {
			$box_line->update_meta_data( self::META_EDITION, $edition_id );
		}

		$box_line->save();

		self::add_content_lines( $new_order );

		// The renewal is a box going out, so it gets a shipment. Keyed on the
		// cycle, so a renewal that fires more than once — a retry after a failed
		// payment, say — updates one row rather than asking the warehouse to
		// pack the same box twice.
		$shipment_product = (int) get_post_meta( $subscription_id, '_subscrpt_product_id', true );
		$shipment_box     = (int) $box_line->get_meta( self::META_BOX );

		if ( ! $shipment_box ) {
			// A box sold before the id was threaded onto the line, or one still
			// resolving through the legacy meta, has no id on the order. Resolve
			// it from the product instead: a shipment that does not know its box
			// cannot be filtered or picked by box, which is most of what the
			// warehouse screens do with it.
			$resolved     = BoxProduct::resolve( $shipment_product, (int) $box_line->get_variation_id() );
			$shipment_box = $resolved ? $resolved->id() : 0;
		}

		ShipmentRepository::record(
			array(
				'subscription_id' => $subscription_id,
				'cycle_key'       => BoxCycle::key( $due ),
				'order_id'        => (int) $new_order->get_id(),
				'box_id'          => $shipment_box,
				'product_id'      => $shipment_product,
				'contents'        => BoxProduct::times( $contents, (int) $box_line->get_quantity() ),
				'ships_at'        => $due,
			)
		);

		foreach ( $notes as $note ) {
			$new_order->add_order_note( $note );
		}

		return $new_order;
	}

	/**
	 * Charge a renewal for what its box ships this cycle.
	 *
	 * A box priced by its contents is quoted from what it holds: item prices are
	 * read live, while the base price and discount come from the pricing the
	 * subscriber signed up under, not the box's current settings. Items marked
	 * for the next box only are charged the way first-box items are at checkout
	 * (BoxPricing::quote_charged_under()):
	 *
	 *     recurring = quote( recurring items )
	 *     once      = max( 0, quote( recurring + once items ) − recurring )
	 *     line      = ( recurring + once ) × boxes on the line
	 *
	 * so once items share the tier exactly as in the cart and the box is never
	 * charged less than what recurs. Only `recurring` becomes the subscription's
	 * price, so the next renewal, and anything that shows the recurring price,
	 * starts from it.
	 *
	 * A fixed box keeps the price free put on the line, and each box on it
	 * adds its once items at their own prices (BoxPricing::list_price()). The
	 * agreed amount is kept on the line, so pricing it again never adds twice.
	 *
	 * Either way the line is stored net of tax when prices include it, as free
	 * stores the agreed price, and calculate_totals() adds the tax back. The box
	 * line carries the whole amount and its content lines are $0, so a refund
	 * for a renewal is made against the box line.
	 *
	 * @param \WC_Order_Item_Product $box_line        The renewal's box line.
	 * @param int                    $subscription_id Subscription id.
	 * @param array                  $contents        What the box ships this cycle.
	 *
	 * @return void
	 */
	public static function price_renewal_line( \WC_Order_Item_Product $box_line, int $subscription_id, array $contents ): void {
		$charge = self::renewal_charge( $subscription_id, $contents );
		$boxes  = max( 1, (int) $box_line->get_quantity() );

		if ( 'none' === $charge['kind'] ) {
			return;
		}

		if ( 'sum' === $charge['kind'] ) {
			$amount = self::net_of_tax( $box_line, $charge['first'] ) * $boxes;

			$box_line->set_subtotal( $amount );
			$box_line->set_total( $amount );

			update_post_meta( $subscription_id, '_subscrpt_price', $charge['recurring'] );

			return;
		}

		// The line as it was agreed, before any once items: kept on the line so
		// that pricing it again starts from it rather than from its own answer.
		$agreed = $box_line->get_meta( self::META_AGREED_LINE );

		if ( ! $charge['has_once'] && ! is_array( $agreed ) ) {
			return;
		}

		if ( ! is_array( $agreed ) ) {
			$agreed = array(
				'subtotal' => (float) $box_line->get_subtotal(),
				'total'    => (float) $box_line->get_total(),
			);

			$box_line->update_meta_data( self::META_AGREED_LINE, $agreed );
		}

		$extra = $charge['has_once'] ? self::net_of_tax( $box_line, $charge['extra'] ) * $boxes : 0.0;

		$box_line->set_subtotal( (float) $agreed['subtotal'] + $extra );
		$box_line->set_total( (float) $agreed['total'] + $extra );
	}

	/**
	 * How a renewal prices a box holding these contents, before tax is taken off.
	 *
	 * The one place the renewal line and anything that tells a subscriber what
	 * it will charge both read, so what is shown cannot drift from what is billed.
	 *
	 * @param int   $subscription_id Subscription id.
	 * @param array $contents        What the box ships this cycle.
	 *
	 * @return array `kind` is 'sum' (the quote: first, recurring), 'fixed' (extra: the once
	 *               items at their own price), or 'none' when the line is left as it is;
	 *               `has_once` says whether the contents hold a once item.
	 */
	private static function renewal_charge( int $subscription_id, array $contents ): array {
		list( $recurring, $once ) = BoxProduct::split_once( $contents );

		$config = BoxSubscription::pricing( $subscription_id );

		if ( BoxPricing::STRATEGY_SUM === $config['strategy'] ) {
			$quote = BoxPricing::quote_charged_under( $config, $recurring, $once );

			return empty( $quote['is_sum'] )
				? array(
					'kind'     => 'none',
					'has_once' => (bool) $once,
				)
				: array(
					'kind'      => 'sum',
					'has_once'  => (bool) $once,
					'first'     => (float) $quote['first'],
					'recurring' => $quote['recurring'],
				);
		}

		return array(
			'kind'     => 'fixed',
			'has_once' => (bool) $once,
			'extra'    => $once ? BoxPricing::list_price( $once ) : 0.0,
		);
	}

	/**
	 * What the next renewal charges for a box that ships next-box-only items.
	 *
	 * The amount price_renewal_line() will put on the box line, as the customer
	 * sees prices, for the same subscription and contents.
	 *
	 * @param int   $subscription_id Subscription id.
	 * @param array $contents        What the box ships this cycle.
	 * @param int   $boxes           Boxes on the subscription's order line.
	 *
	 * @return float|null Null when the contents hold no once item, or the box is priced as it was agreed.
	 */
	public static function next_box_amount( int $subscription_id, array $contents, int $boxes ): ?float {
		$charge = self::renewal_charge( $subscription_id, $contents );
		$boxes  = max( 1, $boxes );

		if ( ! $charge['has_once'] ) {
			return null;
		}

		if ( 'sum' === $charge['kind'] ) {
			return $charge['first'] * $boxes;
		}

		if ( 'fixed' === $charge['kind'] ) {
			return self::agreed_line( $subscription_id, $boxes ) + $charge['extra'] * $boxes;
		}

		return null;
	}

	/**
	 * What the next renewal charges for this subscription's box, as it stands now.
	 *
	 * The contents are resolved as rebuild_renewal() resolves them, so an owed
	 * once item that is out of stock — which the renewal neither ships nor
	 * charges — is not counted.
	 *
	 * @param int $subscription_id Subscription id.
	 * @param int $boxes           Boxes on the subscription's order line.
	 *
	 * @return float|null See next_box_amount().
	 */
	public static function upcoming_amount( int $subscription_id, int $boxes ): ?float {
		$rules = BoxSubscription::rules( $subscription_id );
		$notes = array();

		$contents = BoxStock::resolve_for_box(
			BoxSubscription::contents( $subscription_id ),
			BoxSubscription::box( $subscription_id ),
			(string) ( $rules['stock_rule'] ?? BoxStock::RULE_REPLACE ),
			$notes
		);

		return self::next_box_amount( $subscription_id, $contents, $boxes );
	}

	/**
	 * The line a fixed box's renewal starts from, as the customer sees prices.
	 *
	 * Built as free builds the renewal's line — the agreed price, less the tax in
	 * it where prices include tax, times the line's boxes, through
	 * `subscrpt_renewal_product_args` — so a store that renews at the product's
	 * current price, or a plan held to its own snapshot, is shown what the line
	 * will be. Where prices include tax, the tax WooCommerce then adds is put
	 * back, as the renewal's total has it.
	 *
	 * @param int $subscription_id Subscription id.
	 * @param int $boxes           Boxes, when the subscription's order line cannot be found.
	 *
	 * @return float
	 */
	private static function agreed_line( int $subscription_id, int $boxes ): float {
		$price   = (float) get_post_meta( $subscription_id, '_subscrpt_price', true );
		$item_id = (int) get_post_meta( $subscription_id, '_subscrpt_order_item_id', true );
		$order   = $item_id ? wc_get_order( wc_get_order_id_by_order_item_id( $item_id ) ) : null;
		$item    = $order instanceof \WC_Order ? $order->get_item( $item_id ) : null;
		$product = $item instanceof \WC_Order_Item_Product ? $item->get_product() : null;

		if ( ! $product instanceof \WC_Product ) {
			return $price * $boxes;
		}

		$qty      = max( 1, (int) $item->get_quantity() );
		$includes = wc_prices_include_tax();
		$rates    = $includes ? \WC_Tax::get_rates( $product->get_tax_class() ) : array();
		$net      = $includes ? $price - array_sum( \WC_Tax::calc_inclusive_tax( $price, $rates ) ) : $price;

		/** This filter is documented in free's Helper::create_new_order_for_renewal(). */
		$args = apply_filters(
			'subscrpt_renewal_product_args',
			array(
				'name'     => $product->get_name(),
				'subtotal' => $net * $qty,
				'total'    => $net * $qty,
			),
			$product,
			$item
		);

		if ( ! is_array( $args ) ) {
			return $price * $qty;
		}

		$line = (float) ( $args['total'] ?? 0 );

		if ( $includes && $product->is_taxable() ) {
			$line += array_sum( \WC_Tax::calc_tax( $line, $rates, false ) );
		}

		return $line;
	}

	/**
	 * A price as the line stores it: without the tax a tax-inclusive store put in it.
	 *
	 * @param \WC_Order_Item_Product $box_line The line.
	 * @param float                  $price    Price as shown to the customer.
	 *
	 * @return float
	 */
	private static function net_of_tax( \WC_Order_Item_Product $box_line, float $price ): float {
		if ( function_exists( 'wc_prices_include_tax' ) && wc_prices_include_tax() && wc_tax_enabled() ) {
			$product = $box_line->get_product();
			$rates   = \WC_Tax::get_rates( $product ? $product->get_tax_class() : '' );
			$price  -= array_sum( \WC_Tax::calc_inclusive_tax( $price, $rates ) );
		}

		return $price;
	}

	/**
	 * Move a box's shipment with the payment for it.
	 *
	 * A renewal whose payment fails is marked failed, so the warehouse does not
	 * pack a box nobody paid for. When a retry is paid, a failed box goes back
	 * to scheduled and re-enters the next packing run. The warehouse's own
	 * progress — packing, ready to ship, skipped — is never touched here.
	 *
	 * A box bought once whose order is cancelled, refunded or trashed is
	 * marked failed too: nobody is paying for it any more.
	 *
	 * A paid renewal also takes the next-box-only items it ships out of the
	 * subscription; until then they stay, and ship with whichever renewal for
	 * that box is paid.
	 *
	 * @param int    $order_id Order id.
	 * @param string $from     Previous order status.
	 * @param string $to       New order status.
	 *
	 * @return void
	 */
	public function follow_payment( $order_id, $from, $to ) {
		foreach ( ShipmentRepository::all_for_order( (int) $order_id ) as $shipment ) {
			if ( 'failed' === $to && ShipmentRepository::STATUS_SCHEDULED === $shipment['status'] ) {
				ShipmentRepository::set_status(
					(int) $shipment['id'],
					ShipmentRepository::STATUS_FAILED,
					$shipment['subscription_id']
						? __( 'The renewal payment failed.', 'subscription-pro' )
						: __( 'The payment for this order failed.', 'subscription-pro' )
				);

				continue;
			}

			if (
				in_array( $to, array( 'cancelled', 'refunded', 'trash' ), true )
				&& ! $shipment['subscription_id']
				&& ShipmentRepository::STATUS_SCHEDULED === $shipment['status']
			) {
				ShipmentRepository::set_status(
					(int) $shipment['id'],
					ShipmentRepository::STATUS_FAILED,
					'trash' === $to
						? __( 'The order for this box was trashed.', 'subscription-pro' )
						: (
							'refunded' === $to
								? __( 'The order for this box was refunded.', 'subscription-pro' )
								: __( 'The order for this box was cancelled.', 'subscription-pro' )
						)
				);

				continue;
			}

			if ( in_array( $to, array( 'processing', 'completed' ), true ) && ShipmentRepository::STATUS_FAILED === $shipment['status'] ) {
				ShipmentRepository::set_status(
					(int) $shipment['id'],
					ShipmentRepository::STATUS_SCHEDULED,
					$shipment['subscription_id']
						? __( 'The renewal was paid.', 'subscription-pro' )
						: __( 'The order was paid.', 'subscription-pro' )
				);
			}
		}

		if ( in_array( $to, array( 'processing', 'completed' ), true ) ) {
			self::settle_once_items( (int) $order_id );
		}
	}

	/**
	 * Fail a trashed order's one-time boxes.
	 *
	 * @param int $order_id Order id.
	 *
	 * @return void
	 */
	public function follow_trash( $order_id ): void {
		$this->follow_payment( (int) $order_id, '', 'trash' );
	}

	/**
	 * Take the once items a paid renewal ships out of its subscription.
	 *
	 * Reads the rows stamped on the order's box line, not the subscription's
	 * contents, so an item added after the renewal was built stays for the box
	 * after it. Only a line rebuild_renewal() stamped counts: the first order's
	 * once items were never in the subscription.
	 *
	 * @param int $order_id Order id.
	 *
	 * @return void
	 */
	private static function settle_once_items( int $order_id ): void {
		$order = wc_get_order( $order_id );

		if ( ! $order instanceof \WC_Order ) {
			return;
		}

		foreach ( $order->get_items() as $item ) {
			if ( ! $item instanceof \WC_Order_Item_Product ) {
				continue;
			}

			$subscription_id = (int) $item->get_meta( self::META_RENEWAL_OF );
			$contents        = $item->get_meta( self::META_CONTENTS );

			if ( ! $subscription_id || ! is_array( $contents ) ) {
				continue;
			}

			BoxSubscription::settle_once_items( $subscription_id, $contents, (int) $item->get_meta( self::META_DUE ) );
		}
	}

	/**
	 * Keep the plumbing out of the admin order screen.
	 *
	 * @param array $hidden Hidden meta keys.
	 *
	 * @return array
	 */
	public function hide_box_itemmeta( $hidden ) {
		$hidden[] = self::META_CONTENTS;
		$hidden[] = self::META_EDITION;
		$hidden[] = self::META_PARENT;
		$hidden[] = self::META_EXPANDED;
		$hidden[] = self::META_BOX;
		$hidden[] = self::META_CYCLE;
		$hidden[] = self::META_PRICE;
		$hidden[] = self::META_PRICING;
		$hidden[] = self::META_ONE_TIME;
		$hidden[] = self::META_RENEWAL_OF;
		$hidden[] = self::META_DUE;
		$hidden[] = self::META_AGREED_LINE;

		return $hidden;
	}

	/**
	 * Whether an email is being built, so the list can be drawn for a mail client.
	 *
	 * @var bool
	 */
	private static $in_email = false;

	/**
	 * Note that an email's body has started or finished.
	 *
	 * The order items table prints between WooCommerce's email header and
	 * footer, which is the only thing that tells an HTML email from the
	 * order-received page: both fire the same hook with the same arguments.
	 *
	 * @param bool $in_email Whether an email is being built.
	 *
	 * @return void
	 */
	public static function set_email_context( bool $in_email ): void {
		self::$in_email = $in_email;
	}

	/**
	 * An email's header is printing: what follows is email markup.
	 *
	 * @return void
	 */
	public static function enter_email(): void {
		self::set_email_context( true );
	}

	/**
	 * An email's footer is printing: the body is over.
	 *
	 * @return void
	 */
	public static function leave_email(): void {
		self::set_email_context( false );
	}

	/**
	 * A mail is being handed over, so no email body is still being built.
	 *
	 * Covers a custom template that prints a header with no footer: the flag
	 * would otherwise stay on and put email markup in the page that follows.
	 *
	 * @param mixed $args wp_mail arguments.
	 *
	 * @return mixed Unchanged.
	 */
	public static function mail_sent( $args ) {
		self::set_email_context( false );

		return $args;
	}

	/**
	 * Keep a packed content line off the order screens and emails.
	 *
	 * The box's own line lists what is in it, so the $0 lines that carry
	 * fulfilment and stock would show every pick twice. They stay on the order.
	 *
	 * @param bool                $visible Whether the line is shown.
	 * @param \WC_Order_Item|null $item    Order line.
	 *
	 * @return bool
	 */
	public function item_visible( $visible, $item ) {
		return $visible && ! self::is_content_line( $item );
	}

	/**
	 * The picks on an order line, each with the picture and name to show.
	 *
	 * Names come from the store when the product still exists, and from the
	 * name saved on the line when it does not, so an old order never loses a row.
	 *
	 * @param \WC_Order_Item_Product $item Order line.
	 *
	 * @return array[] name, qty and thumbnail per pick; empty for a line that holds no box.
	 */
	private static function content_rows( \WC_Order_Item_Product $item ): array {
		$contents = $item->get_meta( self::META_CONTENTS );

		if ( empty( $contents ) || ! is_array( $contents ) ) {
			return array();
		}

		$saved = array();

		foreach ( $contents as $row ) {
			if ( is_array( $row ) && ! empty( $row['name'] ) ) {
				$saved[ absint( $row['product_id'] ?? 0 ) . ':' . absint( $row['variation_id'] ?? 0 ) ] = (string) $row['name'];
			}
		}

		$rows = array();

		foreach ( BoxProduct::normalise_items( $contents ) as $packed ) {
			$product = wc_get_product( $packed['variation_id'] ? $packed['variation_id'] : $packed['product_id'] );
			$name    = $product instanceof \WC_Product ? $product->get_name() : ( $saved[ $packed['product_id'] . ':' . $packed['variation_id'] ] ?? '' );

			if ( '' === $name ) {
				continue;
			}

			$rows[] = array(
				'name'      => $name,
				'qty'       => (int) $packed['qty'],
				'thumbnail' => $product instanceof \WC_Product
					? BoxCartView::thumbnail( $product )
					: (string) wc_placeholder_img_src( 'woocommerce_gallery_thumbnail' ),
			);
		}

		return $rows;
	}

	/**
	 * A pick's quantity, as the cart list words it.
	 *
	 * @param int $qty Quantity.
	 *
	 * @return string
	 */
	private static function qty_label( int $qty ): string {
		/* translators: %d: how many of this item are in the box. */
		return sprintf( __( '× %d', 'subscription-pro' ), $qty );
	}

	/**
	 * List a box's contents under its line, wherever order items are shown.
	 *
	 * The order-received page and My Account orders get the cart's list, styled
	 * by the stylesheet. An HTML email gets the same list as a table with inline
	 * styles, since a mail client loads no stylesheet; a plain-text email gets
	 * a line per pick.
	 *
	 * @param int                    $item_id    Order item id.
	 * @param \WC_Order_Item_Product $item       Order item.
	 * @param \WC_Order              $order      Order.
	 * @param bool                   $plain_text Whether the email is plain text.
	 *
	 * @return void
	 */
	public function render_contents( $item_id, $item, $order, $plain_text = false ): void {
		if ( ! $item instanceof \WC_Order_Item_Product ) {
			return;
		}

		$rows = self::content_rows( $item );

		if ( ! $rows ) {
			return;
		}

		if ( $plain_text ) {
			foreach ( $rows as $row ) {
				echo "\n  - " . wp_strip_all_tags( $row['name'] ) . ' ' . self::qty_label( $row['qty'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- plain text, tags stripped.
			}

			return;
		}

		if ( self::$in_email ) {
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- email_html escapes every value.
			echo self::email_html( $rows );

			return;
		}

		wp_enqueue_style( 'subscrpt_box_css' );

		echo '<ul class="subscrpt-box-contents subscrpt-box-contents__list">';

		foreach ( $rows as $row ) {
			printf(
				'<li class="subscrpt-box-contents__item"><img class="subscrpt-box-contents__thumb" src="%1$s" alt="" width="48" height="48" loading="lazy"><span class="subscrpt-box-contents__name">%2$s <span class="subscrpt-box-contents__qty">%3$s</span></span></li>',
				esc_url( $row['thumbnail'] ),
				esc_html( $row['name'] ),
				esc_html( self::qty_label( $row['qty'] ) )
			);
		}

		echo '</ul>';
	}

	/**
	 * The list as an HTML email wants it: a table, inline styles, absolute pictures.
	 *
	 * @param array[] $rows name, qty and thumbnail per pick.
	 *
	 * @return string
	 */
	private static function email_html( array $rows ): string {
		$html = '<table cellspacing="0" cellpadding="0" border="0" role="presentation" style="margin:8px 0 0;border:0;width:auto;">';

		foreach ( $rows as $row ) {
			$html .= sprintf(
				'<tr><td width="48" style="border:0;padding:0 10px 6px 0;vertical-align:middle;width:48px;min-width:48px;"><img src="%1$s" alt="" width="48" height="48" style="display:block;width:48px;min-width:48px;height:48px;border:0;border-radius:4px;margin:0;"></td><td style="border:0;padding:0 0 6px;vertical-align:middle;font-size:13px;line-height:1.3;">%2$s <span style="opacity:0.7;">%3$s</span></td></tr>',
				esc_url( $row['thumbnail'] ),
				esc_html( $row['name'] ),
				esc_html( self::qty_label( $row['qty'] ) )
			);
		}

		return $html . '</table>';
	}

	/**
	 * Is this order line a product packed inside a box?
	 *
	 * Pro's subscription-creation listeners call this: a box may contain a
	 * product that is itself a subscription product, and that must never start
	 * a second subscription.
	 *
	 * @param \WC_Order_Item $order_item Order line.
	 *
	 * @return bool
	 */
	public static function is_content_line( $order_item ): bool {
		return $order_item instanceof \WC_Order_Item && (bool) $order_item->get_meta( self::META_PARENT );
	}
}
