<?php
/**
 * What a build-your-own box offers.
 *
 * A pool is one of three lists: products the merchant chose one by one,
 * everything in some categories, or the whole shop. The last two follow the
 * catalogue — a product added to a chosen category later is in the box without
 * anyone touching it — so leaving one out is an exclusion, not a removal.
 *
 * The storefront and the admin ask the same question here, so the list the
 * merchant sees is the list the shopper gets.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Box
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Box;

defined( 'ABSPATH' ) || exit;

/**
 * Resolves a pool definition into products.
 */
class BoxPool {

	/**
	 * The products the merchant chose.
	 */
	const SOURCE_PRODUCTS = 'products';

	/**
	 * Everything in the chosen categories and tags.
	 */
	const SOURCE_CATEGORIES = 'categories';

	/**
	 * Every product in the store.
	 */
	const SOURCE_ALL = 'all';

	/**
	 * Fill in and clean a stored pool.
	 *
	 * A pool saved before it had a source is read by what it holds: categories
	 * or tags make it a category pool, anything else a list of products.
	 *
	 * @param mixed $pool Raw pool.
	 *
	 * @return array{source:string,products:int[],categories:int[],tags:int[],exclude:int[],virtual:bool}
	 */
	public static function normalise( $pool ): array {
		$pool = is_array( $pool ) ? $pool : [];
		$ids  = static function ( $key ) use ( $pool ) {
			return array_values( array_unique( array_filter( array_map( 'absint', (array) ( $pool[ $key ] ?? [] ) ) ) ) );
		};

		$normalised = [
			'products'   => $ids( 'products' ),
			'categories' => $ids( 'categories' ),
			'tags'       => $ids( 'tags' ),
			'exclude'    => $ids( 'exclude' ),
			'virtual'    => ! empty( $pool['virtual'] ),
		];

		$source = (string) ( $pool['source'] ?? '' );

		if ( ! in_array( $source, [ self::SOURCE_PRODUCTS, self::SOURCE_CATEGORIES, self::SOURCE_ALL ], true ) ) {
			$source = $normalised['categories'] || $normalised['tags'] ? self::SOURCE_CATEGORIES : self::SOURCE_PRODUCTS;
		}

		return array_merge( [ 'source' => $source ], $normalised );
	}

	/**
	 * Every product the pool's source names, before exclusions.
	 *
	 * Chosen products are taken as they are, variations included and in the
	 * merchant's order. A category or whole-shop pool is published products
	 * only, never a product that sells a box, and never a downloadable or
	 * virtual one unless the pool lets them in.
	 *
	 * @param array $pool Pool, as normalise() returns it.
	 *
	 * @return int[]
	 */
	public static function candidate_ids( array $pool ): array {
		$pool = self::normalise( $pool );

		if ( self::SOURCE_PRODUCTS === $pool['source'] ) {
			return $pool['products'];
		}

		$args = self::query_args( $pool );

		if ( null === $args ) {
			return [];
		}

		return array_map( 'absint', get_posts( $args ) );
	}

	/**
	 * A page of the pool, for the Box items list.
	 *
	 * A variable product is listed as its variations, as the builder offers
	 * it. A page holds per_page products, not rows: a variable product's
	 * matching variations count as one, so the list can fold them under it.
	 *
	 * The pool comes back with each variable product it names replaced by its
	 * variations, so the list's controls only ever deal in variations.
	 *
	 * @param array $pool  Pool, as normalise() returns it.
	 * @param array $query search, category (term id), view (all|in|out), page, per_page.
	 *
	 * @return array{rows:array[],total:int,units:int,in:int,out:int,matching:int[],matching_in:int,categories:array[],pool:array}
	 */
	public static function page( array $pool, array $query ): array {
		$pool       = self::normalise( $pool );
		$candidates = self::candidate_ids( $pool );
		$variations = self::variations_of( $candidates );
		$all        = self::expand( $candidates, $variations );
		$exclude    = self::expand( $pool['exclude'], $variations );
		$excluded   = array_values( array_intersect( $exclude, $all ) );
		$per_page = max( 1, (int) ( $query['per_page'] ?? 10 ) );
		$page     = max( 1, (int) ( $query['page'] ?? 1 ) );
		$search   = trim( (string) ( $query['search'] ?? '' ) );
		$category = absint( $query['category'] ?? 0 );
		$view     = (string) ( $query['view'] ?? 'all' );

		$matching = $all;

		if ( '' !== $search || $category ) {
			$matching = $all ? self::narrow( $all, $search, $category ) : [];
		}

		if ( 'in' === $view ) {
			$matching = array_values( array_diff( $matching, $excluded ) );
		} elseif ( 'out' === $view ) {
			$matching = array_values( array_intersect( $matching, $excluded ) );
		}

		// Read first: it warms the post cache the grouping below reads.
		$categories = self::categories_of( $all );
		$units      = self::units( $matching );
		$rows       = [];

		foreach ( array_slice( $units, ( $page - 1 ) * $per_page, $per_page ) as $unit ) {
			foreach ( $unit as $id ) {
				$row = self::row( $id );

				if ( $row ) {
					$row['out'] = in_array( $id, $excluded, true );
					$rows[]     = $row;
				}
			}
		}

		return [
			'rows'        => $rows,
			'total'       => count( $matching ),
			'units'       => count( $units ),
			'in'          => count( $all ) - count( $excluded ),
			'out'         => count( $excluded ),
			'matching'    => $matching,
			'matching_in' => count( array_diff( $matching, $excluded ) ),
			'categories'  => $categories,
			'pool'        => [
				'products' => self::SOURCE_PRODUCTS === $pool['source'] ? $all : $pool['products'],
				'exclude'  => $exclude,
			],
		];
	}

	/**
	 * Every product category, with how many products it holds.
	 *
	 * @return array[] Each entry: id, name, count.
	 */
	public static function categories(): array {
		$terms = get_terms(
			[
				'taxonomy'   => 'product_cat',
				'hide_empty' => false,
				'orderby'    => 'name',
			]
		);

		if ( ! is_array( $terms ) ) {
			return [];
		}

		return array_map(
			static function ( $term ) {
				return [
					'id'    => (int) $term->term_id,
					'name'  => html_entity_decode( $term->name, ENT_QUOTES, 'UTF-8' ),
					'count' => (int) $term->count,
				];
			},
			$terms
		);
	}

	/**
	 * One product as the Box items list shows it.
	 *
	 * @param int $id Product or variation id.
	 *
	 * @return array|null
	 */
	public static function row( int $id ): ?array {
		$product = wc_get_product( $id );

		if ( ! $product instanceof \WC_Product ) {
			return null;
		}

		$parent_id = $product->get_parent_id();
		$image_id  = (int) $product->get_image_id();

		if ( ! $image_id && $parent_id ) {
			$image_id = (int) get_post_thumbnail_id( $parent_id );
		}

		$terms = get_the_terms( $parent_id ? $parent_id : $id, 'product_cat' );
		$stock = $product->get_stock_quantity();

		if ( ! $product->is_in_stock() ) {
			$stock_label = __( 'Out of stock', 'subscription-pro' );
		} elseif ( null !== $stock ) {
			/* translators: %d: units in stock. */
			$stock_label = sprintf( __( '%d in stock', 'subscription-pro' ), (int) $stock );
		} else {
			$stock_label = __( 'In stock', 'subscription-pro' );
		}

		return [
			'id'       => (int) $id,
			'name'     => $product->get_name(),
			'category' => is_array( $terms ) && $terms ? html_entity_decode( $terms[0]->name, ENT_QUOTES, 'UTF-8' ) : '',
			'stock'    => $stock_label,
			'price'    => $product->is_type( 'variable' ) ? '' : html_entity_decode( wp_strip_all_tags( wc_price( (float) wc_get_price_to_display( $product ) ) ), ENT_QUOTES, 'UTF-8' ),
			'image'       => $image_id ? (string) wp_get_attachment_image_url( $image_id, 'thumbnail' ) : '',
			'edit_url'    => (string) get_edit_post_link( $parent_id ? $parent_id : $id, 'raw' ),
			'parent_id'   => (int) $parent_id,
			'parent_name' => $parent_id ? html_entity_decode( (string) get_post_field( 'post_title', $parent_id ), ENT_QUOTES, 'UTF-8' ) : '',
		];
	}

	/**
	 * The variations the builder offers for each variable product among some.
	 *
	 * @param int[] $ids Products.
	 *
	 * @return array<int,int[]> Visible variation ids, by variable product id.
	 */
	private static function variations_of( array $ids ): array {
		if ( ! $ids ) {
			return [];
		}

		$variable = get_posts(
			[
				'post_type'      => 'product',
				'post_status'    => 'any',
				'fields'         => 'ids',
				'posts_per_page' => -1,
				'post__in'       => $ids,
				'no_found_rows'  => true,
				'tax_query'      => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
					[
						'taxonomy' => 'product_type',
						'field'    => 'slug',
						'terms'    => 'variable',
					],
				],
			]
		);

		$variations = [];

		foreach ( $variable as $id ) {
			$product = wc_get_product( $id );

			if ( $product instanceof \WC_Product ) {
				$variations[ (int) $id ] = array_map( 'absint', $product->get_visible_children() );
			}
		}

		return $variations;
	}

	/**
	 * Ids with each variable product replaced by its variations, in place.
	 *
	 * @param int[]            $ids        Products and variations.
	 * @param array<int,int[]> $variations As variations_of() returns it.
	 *
	 * @return int[]
	 */
	private static function expand( array $ids, array $variations ): array {
		$expanded = [];

		foreach ( $ids as $id ) {
			if ( isset( $variations[ $id ] ) ) {
				array_push( $expanded, ...$variations[ $id ] );
				continue;
			}

			$expanded[] = (int) $id;
		}

		return array_values( array_unique( $expanded ) );
	}

	/**
	 * Products as the list pages them: each variable product's variations together.
	 *
	 * @param int[] $ids Products and variations, in candidate order.
	 *
	 * @return int[][] One entry per product, in the order each first appears.
	 */
	private static function units( array $ids ): array {
		$units = [];

		foreach ( $ids as $id ) {
			$parent = (int) wp_get_post_parent_id( $id );

			$units[ $parent ? 'p' . $parent : 'i' . $id ][] = (int) $id;
		}

		return array_values( $units );
	}

	/**
	 * The query a category or whole-shop pool runs.
	 *
	 * @param array $pool Normalised pool.
	 *
	 * @return array|null Null when a category pool has no categories yet.
	 */
	private static function query_args( array $pool ): ?array {
		$args = [
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'fields'         => 'ids',
			'posts_per_page' => -1,
			'orderby'        => 'title',
			'order'          => 'ASC',
			'no_found_rows'  => true,
		];

		if ( self::SOURCE_CATEGORIES === $pool['source'] ) {
			if ( ! $pool['categories'] && ! $pool['tags'] ) {
				return null;
			}

			$tax_query = [ 'relation' => 'OR' ];

			if ( $pool['categories'] ) {
				$tax_query[] = [
					'taxonomy' => 'product_cat',
					'field'    => 'term_id',
					'terms'    => $pool['categories'],
				];
			}

			if ( $pool['tags'] ) {
				$tax_query[] = [
					'taxonomy' => 'product_tag',
					'field'    => 'term_id',
					'terms'    => $pool['tags'],
				];
			}

			$args['tax_query'] = $tax_query; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
		}

		if ( ! $pool['virtual'] ) {
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
			$args['meta_query'] = [
				'relation' => 'AND',
				[
					'relation' => 'OR',
					[
						'key'     => '_virtual',
						'compare' => 'NOT EXISTS',
					],
					[
						'key'     => '_virtual',
						'value'   => 'yes',
						'compare' => '!=',
					],
				],
				[
					'relation' => 'OR',
					[
						'key'     => '_downloadable',
						'compare' => 'NOT EXISTS',
					],
					[
						'key'     => '_downloadable',
						'value'   => 'yes',
						'compare' => '!=',
					],
				],
			];
		}

		$sellers = BoxRepository::connected_product_ids();

		if ( $sellers ) {
			$args['post__not_in'] = $sellers; // phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_post__not_in
		}

		return $args;
	}

	/**
	 * The candidates that match a search and a category, in candidate order.
	 *
	 * @param int[]  $ids      Candidates.
	 * @param string $search   Name search.
	 * @param int    $category Category term id, or 0.
	 *
	 * @return int[]
	 */
	private static function narrow( array $ids, string $search, int $category ): array {
		$args = [
			'post_type'      => [ 'product', 'product_variation' ],
			'post_status'    => 'any',
			'fields'         => 'ids',
			'posts_per_page' => -1,
			'post__in'       => $ids,
			'no_found_rows'  => true,
		];

		if ( '' !== $search ) {
			$args['s'] = $search;
		}

		$found = array_map( 'absint', get_posts( $args ) );

		if ( $category ) {
			$found = array_values(
				array_filter(
					$found,
					static function ( $id ) use ( $category ) {
						$product = wc_get_product( $id );
						$owner   = $product && $product->get_parent_id() ? $product->get_parent_id() : $id;

						return has_term( $category, 'product_cat', $owner );
					}
				)
			);
		}

		// Keep the candidates' own order rather than the search's ranking.
		return array_values( array_intersect( $ids, $found ) );
	}

	/**
	 * The categories a set of products falls in, for the list's filter.
	 *
	 * @param int[] $ids Products.
	 *
	 * @return array[] Each entry: id, name.
	 */
	private static function categories_of( array $ids ): array {
		if ( ! $ids ) {
			return [];
		}

		$owners = [];

		foreach ( $ids as $id ) {
			$parent          = (int) wp_get_post_parent_id( $id );
			$owners[ $parent ? $parent : $id ] = true;
		}

		$terms = wp_get_object_terms( array_keys( $owners ), 'product_cat', [ 'orderby' => 'name' ] );

		if ( ! is_array( $terms ) ) {
			return [];
		}

		$seen = [];

		foreach ( $terms as $term ) {
			$seen[ (int) $term->term_id ] = [
				'id'   => (int) $term->term_id,
				'name' => html_entity_decode( $term->name, ENT_QUOTES, 'UTF-8' ),
			];
		}

		return array_values( $seen );
	}
}
