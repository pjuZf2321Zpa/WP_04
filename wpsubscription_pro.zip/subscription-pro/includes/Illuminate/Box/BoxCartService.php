<?php
/**
 * Changes the box line in the cart.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Box
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Box;

/**
 * The one place that edits what is in a box the shopper already has in their cart.
 *
 * The line is rebuilt where it stands: same position, a new cart item key
 * because the key hashes the contents, and everything else on the line and in
 * its `subscrpt_box` stash left as it was. It never goes through
 * `add_to_cart()`, so no add-to-cart validation, request reading or notice
 * runs a second time. Pricing is recomputed at `before_calculate_totals`, so
 * the new contents price themselves.
 *
 * Nothing the shopper picked is removed unless they choose it: an add that does
 * not fit returns `needs_replace` and writes nothing, and a box with no maximum
 * is never full.
 */
class BoxCartService {

	const STATUS_OK            = 'ok';
	const STATUS_NEEDS_REPLACE = 'needs_replace';
	const STATUS_INVALID       = 'invalid';

	/**
	 * Keys on a cart line that WooCommerce owns and does not hash into the key.
	 */
	const LINE_KEYS = [ 'key', 'product_id', 'variation_id', 'variation', 'quantity', 'data', 'data_hash', 'line_tax_data', 'line_subtotal', 'line_subtotal_tax', 'line_total', 'line_tax' ];

	/**
	 * Line keys `BoxCartPricing` rewrites on every totals pass.
	 */
	const PRICED_KEYS = [ 'subscrpt_plan_price', 'subscrpt_plan_regular' ];

	/**
	 * The first cart line holding a box.
	 *
	 * With no box named, only a box the shopper builds counts: a curated or
	 * edition line cannot be changed here, so it is never offered as "the box".
	 *
	 * @param int $box_id Only a line of this box, or 0 for any.
	 *
	 * @return string Cart item key, or '' when there is none.
	 */
	public static function find_box_line( int $box_id = 0 ): string {
		foreach ( self::lines() as $key => $line ) {
			if ( empty( $line[ BoxCart::CART_KEY ] ) ) {
				continue;
			}

			if ( $box_id ) {
				if ( (int) ( $line[ BoxCart::CART_KEY ]['box_id'] ?? 0 ) === $box_id ) {
					return (string) $key;
				}

				continue;
			}

			$box = self::box_of( $line );

			if ( $box && $box->is_customer_built() ) {
				return (string) $key;
			}
		}

		return '';
	}

	/**
	 * Add items to the box in the cart.
	 *
	 * Items already in the box are skipped and keep their quantity. When what
	 * is left does not fit, nothing is written; the caller asks the shopper.
	 *
	 * Both `incoming` and `current` are stored rows (product_id, variation_id,
	 * qty, once, name, sku). The returned `cart_key` may be a line of
	 * quantity above 1 when the edit made the box identical to another line.
	 *
	 * @param string $cart_key Cart item key of the box line.
	 * @param array  $items    Entries of product_id, variation_id, qty and optionally once.
	 *
	 * @return array{status:string,cart_key:string,added:array,skipped:array,incoming:array,current:array,message:string,max?:int} `max` is the box's maximum, given with needs_replace.
	 */
	public static function add_items( string $cart_key, array $items ): array {
		$result = [
			'status'   => self::STATUS_INVALID,
			'cart_key' => $cart_key,
			'added'    => [],
			'skipped'  => [],
			'incoming' => [],
			'current'  => [],
			'message'  => '',
		];

		$context = self::context( $cart_key );

		if ( is_string( $context ) ) {
			$result['message'] = $context;

			return $result;
		}

		list( $line, $box ) = $context;

		$items   = self::for_line( $line, $items );
		$current = array_values( (array) ( $line[ BoxCart::CART_KEY ]['items'] ?? [] ) );
		$present = [];

		foreach ( BoxProduct::normalise_items( $current ) as $row ) {
			$present[ $row['product_id'] . ':' . $row['variation_id'] . ':' . (int) $row['once'] ] = true;
		}

		foreach ( self::shape( $items ) as $item ) {
			if ( isset( $present[ $item['product_id'] . ':' . $item['variation_id'] . ':' . (int) $item['once'] ] ) ) {
				$result['skipped'][] = $item;
			} else {
				$result['incoming'][] = $item;
			}
		}

		$result['incoming'] = self::describe( $result['incoming'] );

		$result['current'] = $current;

		if ( ! $result['incoming'] ) {
			$result['status'] = self::STATUS_OK;

			return $result;
		}

		$pool = BoxRules::check_allowed( $result['incoming'], $box->pool_product_ids() );

		if ( is_string( $pool ) ) {
			$result['message'] = $pool;

			return $result;
		}

		$merged = array_merge( $current, $result['incoming'] );
		$max    = $box->size()['max'];

		if ( $max > 0 && BoxProduct::count_units( $merged ) > $max ) {
			$result['incoming'] = self::with_thumbnails( $result['incoming'] );
			$result['current']  = self::with_thumbnails( $result['current'] );
			$result['max']      = $max;
			$result['status']   = self::STATUS_NEEDS_REPLACE;
			$result['message']  = __( 'Your box is full. Choosing these items replaces what is in it now.', 'subscription-pro' );

			return $result;
		}

		$valid = $box->validate( $merged );

		if ( is_string( $valid ) ) {
			$result['message'] = $valid;

			return $result;
		}

		$result['cart_key'] = self::write( $cart_key, $line, $merged );
		$result['added']    = $result['incoming'];
		$result['status']   = self::STATUS_OK;

		return $result;
	}

	/**
	 * Replace everything in the box in the cart.
	 *
	 * For an edit, and for the shopper's answer to `needs_replace`.
	 *
	 * @param string $cart_key Cart item key of the box line.
	 * @param array  $items    Entries of product_id, variation_id, qty and optionally once.
	 *
	 * @return array{status:string,cart_key:string,message:string}
	 */
	public static function set_contents( string $cart_key, array $items ): array {
		$result  = [
			'status'   => self::STATUS_INVALID,
			'cart_key' => $cart_key,
			'message'  => '',
		];
		$context = self::context( $cart_key );

		if ( is_string( $context ) ) {
			$result['message'] = $context;

			return $result;
		}

		list( $line, $box ) = $context;

		$items = self::shape( self::for_line( $line, $items ) );

		if ( ! $items ) {
			$result['message'] = __( 'Choose what goes in your box.', 'subscription-pro' );

			return $result;
		}

		$valid = $box->validate( $items );

		if ( is_string( $valid ) ) {
			$result['message'] = $valid;

			return $result;
		}

		$result['cart_key'] = self::write( $cart_key, $line, self::describe( $items ) );
		$result['status']   = self::STATUS_OK;

		return $result;
	}

	/**
	 * The cart's lines.
	 *
	 * @return array
	 */
	private static function lines(): array {
		$cart = function_exists( 'WC' ) ? WC()->cart : null;

		return is_object( $cart ) ? (array) $cart->get_cart() : [];
	}

	/**
	 * The box line and its box, or the reason there is neither.
	 *
	 * @param string $cart_key Cart item key.
	 *
	 * @return array|string [ line, Box ], or a message.
	 */
	private static function context( string $cart_key ) {
		$lines = self::lines();
		$line  = $lines[ $cart_key ] ?? null;

		if ( ! is_array( $line ) || empty( $line[ BoxCart::CART_KEY ] ) ) {
			return __( 'That box is no longer in your cart.', 'subscription-pro' );
		}

		$box = self::box_of( $line );

		if ( ! $box ) {
			return __( 'This box is not available to buy right now.', 'subscription-pro' );
		}

		if ( ! $box->is_customer_built() ) {
			return __( 'What is in this box is chosen for you.', 'subscription-pro' );
		}

		return [ $line, $box ];
	}

	/**
	 * The box a cart line sells.
	 *
	 * @param array $line Cart line.
	 *
	 * @return Box|null
	 */
	private static function box_of( array $line ): ?Box {
		return BoxProduct::resolve(
			(int) ( $line['product_id'] ?? 0 ),
			(int) ( $line['variation_id'] ?? 0 ),
			(int) ( $line[ BoxCart::CART_KEY ]['box_id'] ?? 0 )
		);
	}

	/**
	 * Normalise items, keeping the once flag.
	 *
	 * @param array $items Raw items.
	 *
	 * @return array[] Entries of product_id, variation_id, qty and once.
	 */
	private static function shape( array $items ): array {
		return BoxProduct::normalise_items( $items );
	}

	/**
	 * Items as a line takes them: bought once, everything in the box ships
	 * once, so no item carries a once flag (as BoxCart::apply_edit() does).
	 *
	 * @param array $line  Cart line.
	 * @param array $items Raw items.
	 *
	 * @return array
	 */
	private static function for_line( array $line, array $items ): array {
		if ( empty( $line[ BoxCart::CART_KEY ]['one_time'] ) ) {
			return $items;
		}

		$items = self::shape( $items );

		foreach ( $items as $index => $item ) {
			$items[ $index ]['once'] = false;
		}

		return $items;
	}

	/**
	 * Add the name and SKU a stored line keeps.
	 *
	 * @param array $items Shaped items.
	 *
	 * @return array[]
	 */
	private static function describe( array $items ): array {
		return BoxProduct::describe_items( $items );
	}

	/**
	 * Give rows the picture the replace prompt shows.
	 *
	 * Only the answer carries it; what is written to the line never does.
	 *
	 * @param array $rows Stored rows.
	 *
	 * @return array[]
	 */
	public static function with_thumbnails( array $rows ): array {
		foreach ( $rows as $index => $row ) {
			$id      = (int) ( $row['variation_id'] ?? 0 ) ? (int) $row['variation_id'] : (int) ( $row['product_id'] ?? 0 );
			$product = wc_get_product( $id );
			$image   = $product instanceof \WC_Product && $product->get_image_id() ? wp_get_attachment_image_url( $product->get_image_id(), 'thumbnail' ) : '';

			$rows[ $index ]['thumbnail'] = $image ? (string) $image : (string) wc_placeholder_img_src( 'thumbnail' );
		}

		return array_values( $rows );
	}

	/**
	 * Write the new contents to the line, in place.
	 *
	 * @param string $old_key  Cart item key now.
	 * @param array  $line     The line now.
	 * @param array  $contents Stored rows for the box.
	 *
	 * @return string The line's new cart item key.
	 */
	private static function write( string $old_key, array $line, array $contents ): string {
		$cart = WC()->cart;

		$line[ BoxCart::CART_KEY ]['items'] = array_values( $contents );
		$line[ BoxCart::CART_KEY ]['size']  = BoxProduct::count_units( $contents );

		// Only what was fixed when the box was added. Pricing rewrites these on
		// every totals pass, so hashing them would key the same box differently
		// depending on when it was last priced, and two identical boxes would
		// never merge as WooCommerce merges them.
		$extra = array_diff_key( $line, array_flip( self::LINE_KEYS ), array_flip( self::PRICED_KEYS ) );
		unset( $extra[ BoxCart::CART_KEY ]['quote'] );

		// What pricing replaced, kept to undo it, and what it charges once: present only once a line was priced.
		foreach ( [ 'base_signup_fee', 'base_plan_price', 'base_plan_regular', 'base_per_cost', 'once_charge' ] as $base ) {
			unset( $extra[ BoxCart::CART_KEY ][ $base ] );
		}

		if ( isset( $extra['subscription'] ) && is_array( $extra['subscription'] ) ) {
			unset( $extra['subscription']['per_cost'], $extra['subscription']['signup_fee'] );
		}

		$new_key = (string) $cart->generate_cart_id(
			$line['product_id'],
			$line['variation_id'] ?? 0,
			$line['variation'] ?? [],
			$extra
		);

		// The line's product already carries the old contents' weight, so weigh a
		// fresh one rather than adding the new contents on top.
		$fresh = wc_get_product( $line['variation_id'] ? $line['variation_id'] : $line['product_id'] );

		if ( $fresh instanceof \WC_Product ) {
			$line['data'] = clone $fresh;
			$line         = BoxCart::add_contents_weight( $line );
		}

		$line['key'] = $new_key;
		$rebuilt     = [];
		$lines       = $cart->get_cart();

		// Another line already holds exactly these contents. WooCommerce would
		// have merged the two into one line of quantity 2; so do the same
		// rather than silently dropping the other line.
		if ( $new_key !== $old_key && isset( $lines[ $new_key ] ) ) {
			$line['quantity'] = (int) ( $line['quantity'] ?? 1 ) + (int) ( $lines[ $new_key ]['quantity'] ?? 1 );
		}

		foreach ( $lines as $key => $existing ) {
			if ( (string) $key === $old_key ) {
				$rebuilt[ $new_key ] = $line;
			} elseif ( (string) $key !== $new_key ) {
				$rebuilt[ $key ] = $existing;
			}
		}

		$cart->set_cart_contents( $rebuilt );
		$cart->set_session();
		$cart->calculate_totals();

		return $new_key;
	}
}
