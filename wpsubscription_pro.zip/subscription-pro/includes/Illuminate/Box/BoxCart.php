<?php
/**
 * A box in the cart.
 *
 * The box is one cart line carrying its contents, never several lines. Free's
 * cart validation refuses a second line whenever a subscription is present, and
 * its renewal builder re-adds exactly one product — so a box that occupied more
 * than one line could be bought but never renewed.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Box
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Box;

defined( 'ABSPATH' ) || exit;

/**
 * Validates, carries and displays a box selection in the cart.
 */
class BoxCart {

	/**
	 * Cart item data key holding the selection.
	 */
	const CART_KEY = 'subscrpt_box';

	/**
	 * Nonce action of the edit form.
	 */
	const EDIT_ACTION = 'subscrpt_box_edit';

	/**
	 * Register hooks.
	 */
	public function __construct() {
		add_action( 'wp_loaded', array( $this, 'handle_edit_request' ), 15 );
		add_filter( 'woocommerce_add_to_cart_validation', array( $this, 'validate_add_to_cart' ), 20, 4 );
		add_action( 'woocommerce_store_api_validate_add_to_cart', array( $this, 'validate_add_to_cart_store_api' ), 20, 1 );
		add_filter( 'woocommerce_add_cart_item_data', array( $this, 'add_cart_item_data' ), 20, 3 );
		add_filter( 'woocommerce_get_item_data', array( $this, 'display_cart_item_data' ), 20, 2 );
		add_action( 'woocommerce_check_cart_items', array( $this, 'check_cart_items' ) );
		add_filter( 'woocommerce_add_cart_item', array( __CLASS__, 'add_contents_weight' ), 20, 1 );
		add_filter( 'woocommerce_get_cart_item_from_session', array( __CLASS__, 'add_contents_weight' ), 20, 1 );
	}

	/**
	 * Change the contents of the box line the builder was opened on.
	 *
	 * Contents only: the line keeps the plan or one-time choice it was bought
	 * with, so a posted plan is never read. Which picks ship once is the form's
	 * to say, as it is when buying: a pick the shopper un-ticked ships every
	 * cycle. A line bought once ships everything once, so it keeps no flags.
	 * Nothing here redirects, which is what lets a test call it;
	 * `handle_edit_request()` does that.
	 *
	 * @return array{status:string,message:string} `ok`, or `invalid` with the sentence to show.
	 */
	public function apply_edit(): array {
		$nonce = isset( $_POST['subscrpt_box_edit_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['subscrpt_box_edit_nonce'] ) ) : '';

		if ( ! $nonce || ! wp_verify_nonce( $nonce, self::EDIT_ACTION ) ) {
			return [
				'status'  => BoxCartService::STATUS_INVALID,
				'message' => __( 'Your box could not be updated. Please try again.', 'subscription-pro' ),
			];
		}

		$key   = isset( $_POST['subscrpt_box_edit'] ) ? sanitize_text_field( wp_unslash( $_POST['subscrpt_box_edit'] ) ) : '';
		$items = $this->posted_selection();
		$line  = $key && WC()->cart ? WC()->cart->get_cart_item( $key ) : null;

		// The size is the line's: a variable box's variation is fixed once it is in the cart.
		$posted_variation = isset( $_POST['variation_id'] ) ? absint( $_POST['variation_id'] ) : 0;

		if ( is_array( $line ) && $posted_variation && (int) ( $line['variation_id'] ?? 0 ) !== $posted_variation ) {
			return [
				'status'  => BoxCartService::STATUS_INVALID,
				'message' => __( 'The size of a box in your cart cannot be changed here. Remove the box and add a new one.', 'subscription-pro' ),
			];
		}

		if ( is_array( $line ) && ! empty( $line[ self::CART_KEY ]['one_time'] ) ) {
			foreach ( $items as $index => $item ) {
				$items[ $index ]['once'] = false;
			}
		}

		$result = BoxCartService::set_contents( $key, $items );

		return [
			'status'  => $result['status'],
			'message' => BoxCartService::STATUS_OK === $result['status']
				? __( 'Your box was updated.', 'subscription-pro' )
				: $result['message'],
		];
	}

	/**
	 * Apply a posted box edit, say how it went, and go back to the cart.
	 *
	 * Runs before WooCommerce's add-to-cart handler, which would otherwise read
	 * the same form and add the box as a second line.
	 *
	 * @return void
	 */
	public function handle_edit_request(): void {
		if ( empty( $_POST['subscrpt_box_edit'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- apply_edit() verifies it.
			return;
		}

		$result = $this->apply_edit();

		wc_add_notice( $result['message'], BoxCartService::STATUS_OK === $result['status'] ? 'success' : 'error' );
		wp_safe_redirect( wc_get_cart_url() );
		exit;
	}

	/**
	 * Whether this add-to-cart request buys the box once.
	 *
	 * It does when no plan was posted, the product has plans, and the product (or
	 * the variation, for a variable one) allows a one-time purchase. Any other
	 * request without a plan falls back to the first plan, so it is a
	 * subscription — exactly what `PlanCheckout::fallback_plan_id()` decides.
	 *
	 * @param int $product_id   Product id.
	 * @param int $variation_id Variation id, or 0.
	 *
	 * @return bool
	 */
	public static function is_one_time_request( int $product_id, int $variation_id ): bool {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_REQUEST['subscrpt_plan_id'] ) && absint( $_REQUEST['subscrpt_plan_id'] ) ) {
			return false;
		}

		if ( ! function_exists( 'subscrpt_product_has_plan' ) || ! subscrpt_product_has_plan( $product_id, $variation_id ) ) {
			return false;
		}

		return self::allows_one_time( $product_id, $variation_id );
	}

	/**
	 * Whether the product, or its variation, is switched to sell once.
	 *
	 * @param int $product_id   Product id.
	 * @param int $variation_id Variation id, or 0.
	 *
	 * @return bool
	 */
	public static function allows_one_time( int $product_id, int $variation_id ): bool {
		return 'yes' === get_post_meta( $variation_id ? $variation_id : $product_id, '_subscrpt_one_time_enabled', true );
	}

	/**
	 * Drop one-time box lines whose product no longer allows it.
	 *
	 * A line bought once has no plan, so nothing else in the cart notices when
	 * the merchant turns one-time off underneath it; checking out would then
	 * sell a box with neither a plan nor a way to ship it again.
	 *
	 * @return void
	 */
	public function check_cart_items(): void {
		$cart = WC()->cart;

		if ( ! $cart || ! is_array( $cart->get_cart() ) ) {
			return;
		}

		foreach ( $cart->get_cart() as $key => $line ) {
			if ( empty( $line[ self::CART_KEY ]['one_time'] ) ) {
				continue;
			}

			if ( self::allows_one_time( (int) ( $line['product_id'] ?? 0 ), (int) ( $line['variation_id'] ?? 0 ) ) ) {
				continue;
			}

			wc_add_notice( __( 'This box can no longer be bought once. Choose a delivery schedule instead.', 'subscription-pro' ), 'error' );
			$cart->remove_cart_item( $key );
		}
	}

	/**
	 * Reject a box that breaks its own rules, naming the rule.
	 *
	 * @param bool $passed       Whether validation passed so far.
	 * @param int  $product_id   Product id.
	 * @param int  $quantity     Quantity.
	 * @param int  $variation_id Variation id.
	 *
	 * @return bool
	 */
	public function validate_add_to_cart( $passed, $product_id, $quantity = 1, $variation_id = 0 ) {
		if ( ! $passed || ! BoxProduct::is_box( (int) $product_id ) ) {
			return $passed;
		}

		$result = $this->validate_selection( (int) $product_id, (int) $variation_id, $this->posted_box_id() );

		if ( is_string( $result ) ) {
			wc_add_notice( $result, 'error' );

			return false;
		}

		return $passed;
	}

	/**
	 * The same check for the Store API.
	 *
	 * A build-your-own box needs a selection, and the Store API's add-to-cart
	 * request carries none — the builder posts the classic add-to-cart form,
	 * which works in block themes too. Curated and edition boxes need no
	 * selection, so they add from anywhere.
	 *
	 * @param \WC_Product $product Product being added.
	 *
	 * @throws \Exception When the box cannot be added.
	 *
	 * @return void
	 */
	public function validate_add_to_cart_store_api( $product ): void {
		if ( ! $product instanceof \WC_Product || ! BoxProduct::is_box( $product ) ) {
			return;
		}

		$product_id   = $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id();
		$variation_id = $product->is_type( 'variation' ) ? $product->get_id() : 0;

		$result = $this->validate_selection( (int) $product_id, (int) $variation_id, $this->posted_box_id() );

		if ( is_string( $result ) ) {
			throw new \Exception( esc_html( $result ) );
		}
	}

	/**
	 * Attach the chosen contents to the cart line.
	 *
	 * Two different selections produce different cart item keys, because
	 * WooCommerce hashes the cart item data — so two boxes of the same product
	 * never merge into one line with quantity 2.
	 *
	 * @param array $cart_item_data Cart item data.
	 * @param int   $product_id     Product id.
	 * @param int   $variation_id   Variation id.
	 *
	 * @return array
	 */
	public function add_cart_item_data( $cart_item_data, $product_id, $variation_id = 0 ) {
		if ( ! BoxProduct::is_box( (int) $product_id ) ) {
			return $cart_item_data;
		}

		$box_id = $this->posted_box_id();
		$items  = $this->resolve_selection( (int) $product_id, (int) $variation_id, $box_id );

		if ( ! $items ) {
			return $cart_item_data;
		}

		$cart_item_data[ self::CART_KEY ] = array(
			'items' => BoxProduct::describe_items( $items ),
			'size'  => BoxProduct::count_units( $items ),
		);

		if ( self::is_one_time_request( (int) $product_id, (int) $variation_id ) ) {
			$cart_item_data[ self::CART_KEY ]['one_time'] = true;
		}

		$box = BoxProduct::resolve( (int) $product_id, (int) $variation_id, $box_id );

		if ( $box ) {
			// Which box this line is. A product may sell several, and the order,
			// the renewal and the subscription all have to answer from the same
			// one the shopper actually bought.
			$cart_item_data[ self::CART_KEY ]['box_id'] = $box->id();
		}

		$edition = $this->current_edition( (int) $product_id, (int) $variation_id, $box_id );

		if ( $edition ) {
			$cart_item_data[ self::CART_KEY ]['edition'] = (int) $edition['id'];
		}

		return $cart_item_data;
	}

	/**
	 * Show how many are in the box beside the line's other details.
	 *
	 * The contents themselves are `BoxCartView`'s list.
	 *
	 * @param array $item_data Item data rows.
	 * @param array $cart_item Cart item.
	 *
	 * @return array
	 */
	public function display_cart_item_data( $item_data, $cart_item ) {
		return BoxCartView::item_data( $item_data, $cart_item );
	}

	/**
	 * Give the box line the weight of what is inside it.
	 *
	 * Shipping is quoted from the cart, so a box whose own weight is zero would
	 * ship for the price of an empty carton.
	 *
	 * @param array $cart_item Cart item.
	 *
	 * @return array
	 */
	public static function add_contents_weight( $cart_item ) {
		if ( empty( $cart_item[ self::CART_KEY ]['items'] ) || empty( $cart_item['data'] ) ) {
			return $cart_item;
		}

		$product = $cart_item['data'];

		if ( ! $product instanceof \WC_Product || $product->is_virtual() ) {
			return $cart_item;
		}

		$weight = (float) $product->get_weight();

		foreach ( BoxProduct::normalise_items( $cart_item[ self::CART_KEY ]['items'] ) as $item ) {
			$packed = wc_get_product( $item['variation_id'] ? $item['variation_id'] : $item['product_id'] );

			if ( $packed instanceof \WC_Product && $packed->get_weight() ) {
				$weight += (float) $packed->get_weight() * (int) $item['qty'];
			}
		}

		if ( $weight > 0 ) {
			$product->set_weight( $weight );
		}

		return $cart_item;
	}

	/**
	 * A one-line summary of a selection, e.g. "2 × Magnesium, 1 × Greens".
	 *
	 * @param array $items Selection.
	 *
	 * @return string
	 */
	public static function contents_summary( array $items ): string {
		$parts = array();

		foreach ( BoxProduct::normalise_items( $items ) as $item ) {
			$product = wc_get_product( $item['variation_id'] ? $item['variation_id'] : $item['product_id'] );
			$name    = $product ? $product->get_name() : ( $item['name'] ?? '' );

			if ( ! $name ) {
				continue;
			}

			$parts[] = sprintf( '%d × %s', (int) $item['qty'], $name );
		}

		return implode( ', ', $parts );
	}

	/**
	 * Validate whatever selection this add-to-cart request implies.
	 *
	 * @param int $product_id   Product id.
	 * @param int $variation_id Variation id.
	 * @param int $box_id       Box the form named, or 0.
	 *
	 * @return true|string True, or the message for the rule broken.
	 */
	private function validate_selection( int $product_id, int $variation_id, int $box_id = 0 ) {
		// A box always recurs. Sold from a product with no billing cycle it takes
		// the money once and never ships again — which the customer finds out and
		// the merchant does not. The connect row refuses to make that pairing;
		// this refuses to sell one that already exists.
		if ( ! BoxProduct::has_cadence( $product_id ) ) {
			return __( 'This box is not available to buy right now.', 'subscription-pro' );
		}

		$box = BoxProduct::resolve( $product_id, $variation_id, $box_id );

		// The id came off the form. `resolve()` refuses one this product does not
		// sell, so a miss here with an id posted means exactly that, and saying so
		// is better than silently selling a different box.
		if ( ! $box ) {
			return $box_id
				? __( 'That box is not sold on this product.', 'subscription-pro' )
				: __( 'This box is not available to buy right now.', 'subscription-pro' );
		}

		$items = $this->resolve_selection( $product_id, $variation_id, $box_id );

		if ( ! $items ) {
			return __( 'Choose what goes in your box before adding it to the cart.', 'subscription-pro' );
		}

		// Curated and edition contents are the merchant's, not the shopper's:
		// they are not checked against the pool, only against stock.
		if ( ! $box->is_customer_built() ) {
			return true;
		}

		return $box->validate( $items );
	}

	/**
	 * What this box would be bought with.
	 *
	 * A customer-built box takes the posted selection, falling back to the
	 * merchant's default picks. A curated box is its fixed contents. An edition
	 * box is whatever is published for the cycle being bought into.
	 *
	 * @param int $product_id   Product id.
	 * @param int $variation_id Variation id.
	 * @param int $box_id       Box the form named, or 0.
	 *
	 * @return array[]
	 */
	private function resolve_selection( int $product_id, int $variation_id, int $box_id = 0 ): array {
		$box = BoxProduct::resolve( $product_id, $variation_id, $box_id );

		if ( ! $box ) {
			return array();
		}

		$type = $box->type();

		if ( BoxProduct::TYPE_CURATED === $type ) {
			return $box->curated_items();
		}

		if ( BoxProduct::TYPE_EDITION === $type ) {
			$edition = $this->current_edition( $product_id, $variation_id, $box_id );

			if ( $edition && $edition['contents'] ) {
				return $edition['contents'];
			}

			return $box->curated_items();
		}

		$posted = $this->posted_selection();

		// Bought once, everything in the box ships once, so there is no second
		// meaning for a flag to carry and nothing recurring to count.
		if ( $posted && self::is_one_time_request( $product_id, $variation_id ) ) {
			$posted = BoxProduct::normalise_items(
				array_map(
					static function ( $row ) {
						$row['once'] = false;

						return $row;
					},
					$posted
				)
			);
		}

		return $posted ? $posted : $box->default_items();
	}

	/**
	 * The box the form named, if it named one.
	 *
	 * A product selling one box posts a hidden field; a product selling several
	 * posts the shopper's choice. Zero means "whichever box this product sells",
	 * which is what every form written before this posted.
	 *
	 * @return int
	 */
	private function posted_box_id(): int {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return isset( $_REQUEST['subscrpt_box_id'] ) ? absint( $_REQUEST['subscrpt_box_id'] ) : 0;
	}

	/**
	 * The selection the builder posted: `subscrpt_box_items[pid]=qty`, with
	 * `subscrpt_box_once[pid]=1` for each product that ships in the first box only.
	 *
	 * @return array[]
	 */
	private function posted_selection(): array {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		if ( empty( $_REQUEST['subscrpt_box_items'] ) || ! is_array( $_REQUEST['subscrpt_box_items'] ) ) {
			return array();
		}

		$raw  = wp_unslash( $_REQUEST['subscrpt_box_items'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$once = isset( $_REQUEST['subscrpt_box_once'] ) && is_array( $_REQUEST['subscrpt_box_once'] )
			? wp_unslash( $_REQUEST['subscrpt_box_once'] ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			: array();
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		$items = array();

		foreach ( (array) $raw as $product_id => $qty ) {
			$product_id = absint( $product_id );
			$qty        = (int) $qty;

			if ( ! $product_id || $qty < 1 ) {
				continue;
			}

			$items[] = array(
				'product_id'   => $product_id,
				'variation_id' => 0, // The builder posts a variation as its own product id.
				'qty'          => $qty,
				'once'         => ! empty( $once[ $product_id ] ),
			);
		}

		return BoxProduct::normalise_items( $items );
	}

	/**
	 * The edition a box bought today would ship first.
	 *
	 * @param int $product_id   Box product id.
	 * @param int $variation_id Variation id, or 0.
	 * @param int $box_id       Box the form named, or 0 for the primary one.
	 *
	 * @return array|null
	 */
	private function current_edition( int $product_id, int $variation_id = 0, int $box_id = 0 ): ?array {
		$box = BoxProduct::resolve( $product_id, $variation_id, $box_id );

		if ( ! $box || Box::TYPE_EDITION !== $box->type() ) {
			return null;
		}

		// Keyed on the box: a product selling two edition boxes has two sets of
		// editions, and asking by product would hand back whichever was found.
		return EditionRepository::published_for_date( $box->id(), time() );
	}
}
