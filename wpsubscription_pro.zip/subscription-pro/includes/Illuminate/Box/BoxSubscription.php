<?php
/**
 * A box, once someone is subscribed to it.
 *
 * Everything a subscriber can do to their next box lives here: what it holds,
 * when it locks, changing it, skipping it, and — for an edition box — becoming
 * whatever the merchant published for this cycle.
 *
 * The rules are copied onto the subscription at sign-up rather than read from
 * the product, so editing a box tomorrow never changes the deal someone bought
 * today. Plans gives prices the same guarantee.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Box
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Box;

use SpringDevs\Subscription\Illuminate\Helper as FreeHelper;

defined( 'ABSPATH' ) || exit;

/**
 * The box side of a subscription.
 */
class BoxSubscription {

	/**
	 * What the next renewal ships.
	 */
	const META_CONTENTS = '_subscrpt_box_contents';

	/**
	 * The edition those contents came from.
	 */
	const META_EDITION = '_subscrpt_box_edition';

	/**
	 * The rules as they stood at sign-up.
	 */
	const META_RULES = '_subscrpt_box_rules';

	/**
	 * Skips taken in a row.
	 */
	const META_SKIPS = '_subscrpt_box_skips';

	/**
	 * The renewal date the upcoming-box email last went out for.
	 */
	const META_NOTIFIED = '_subscrpt_box_notified';

	/**
	 * Which box this subscription holds, when the product sells more than one.
	 */
	const META_BOX = '_subscrpt_box_id';

	/**
	 * The pricing as it stood at sign-up.
	 */
	const META_PRICING = '_subscrpt_box_pricing';

	/**
	 * How many units the box was bought with.
	 */
	const META_UNITS = '_subscrpt_box_units';

	/**
	 * Renewal dates whose next-box-only items have shipped and been paid for.
	 */
	const META_ONCE_SETTLED = '_subscrpt_box_once_settled';

	/**
	 * Register hooks.
	 */
	public function __construct() {
		add_action( 'subscrpt_order_checkout', array( $this, 'copy_box_to_subscription' ), 10, 2 );
		add_action( 'subscrpt_order_checkout', array( $this, 'write_agreed_price' ), 20, 2 );
	}

	/**
	 * Renew a box priced by its contents at the price the customer agreed.
	 *
	 * Free prices a legacy product's subscription from the product, which for
	 * such a box is not what was quoted.
	 *
	 * @param int            $subscription_id Subscription id.
	 * @param \WC_Order_Item $order_item      The order line the subscription was made from.
	 *
	 * @return void
	 */
	public function write_agreed_price( $subscription_id, $order_item ): void {
		if ( ! $subscription_id || ! $order_item instanceof \WC_Order_Item_Product ) {
			return;
		}

		$price   = $order_item->get_meta( BoxOrder::META_PRICE );
		$pricing = $order_item->get_meta( BoxOrder::META_PRICING );

		if ( '' === $price || ! is_array( $pricing ) ) {
			return;
		}

		update_post_meta( $subscription_id, '_subscrpt_price', $price );
		update_post_meta( $subscription_id, self::META_PRICING, $pricing );
	}

	/**
	 * How this subscription's box is priced.
	 *
	 * @param int $subscription_id Subscription id.
	 *
	 * @return array See BoxPricing::normalise_config(). A subscription with none stored is fixed.
	 */
	public static function pricing( int $subscription_id ): array {
		return BoxPricing::normalise_config( get_post_meta( $subscription_id, self::META_PRICING, true ) );
	}

	/**
	 * Copy a box order line's contents onto the subscription it created.
	 *
	 * @param int            $subscription_id Subscription id.
	 * @param \WC_Order_Item $order_item      The order line the subscription was made from.
	 *
	 * @return void
	 */
	public function copy_box_to_subscription( $subscription_id, $order_item ): void {
		if ( ! $subscription_id || ! $order_item instanceof \WC_Order_Item_Product ) {
			return;
		}

		$contents = $order_item->get_meta( BoxOrder::META_CONTENTS );

		if ( empty( $contents ) || ! is_array( $contents ) ) {
			return;
		}

		$product_id   = (int) $order_item->get_product_id();
		$variation_id = (int) $order_item->get_variation_id();

		// Which box was bought, not which box the product happens to list first:
		// a product selling several would otherwise hold this subscriber to
		// another box's rules for the life of the subscription.
		$box_id = (int) $order_item->get_meta( BoxOrder::META_BOX );
		$box    = BoxProduct::resolve( $product_id, $variation_id, $box_id );

		// Items that ship once are not part of the box that renews: the snapshot
		// holds the recurring items only, while the first order's lines and the
		// first shipment below keep the whole selection.
		list( $recurring ) = BoxProduct::split_once( $contents );

		update_post_meta( $subscription_id, self::META_CONTENTS, BoxProduct::describe_items( $recurring ) );
		update_post_meta( $subscription_id, self::META_UNITS, BoxProduct::count_units( $recurring ) );
		update_post_meta( $subscription_id, self::META_RULES, $box ? $box->rules() : BoxProduct::rules( $product_id, $variation_id ) );
		update_post_meta( $subscription_id, self::META_SKIPS, 0 );

		if ( $box_id ) {
			update_post_meta( $subscription_id, self::META_BOX, $box_id );
		}

		$edition_id = (int) $order_item->get_meta( BoxOrder::META_EDITION );

		if ( $edition_id ) {
			update_post_meta( $subscription_id, self::META_EDITION, $edition_id );
		}

		// The first box goes out now, so it is a shipment like every renewal
		// after it. Without this the warehouse would only ever see boxes two
		// onwards, and a brand new subscriber's first box would be the one nobody
		// was told to pack.
		$order   = wc_get_order( (int) $order_item->get_order_id() );
		$created = $order instanceof \WC_Order && $order->get_date_created()
			? $order->get_date_created()->getTimestamp()
			: time();

		ShipmentRepository::record(
			array(
				'subscription_id' => (int) $subscription_id,
				'cycle_key'       => BoxCycle::key( $created ),
				'order_id'        => $order instanceof \WC_Order ? (int) $order->get_id() : 0,
				// A legacy box, or one sold before the id was threaded onto the
				// line, carries no id on the order — but it still resolves from
				// the product, and a shipment that does not know its box cannot
				// be filtered or picked by box later.
				'box_id'          => $box_id ? $box_id : ( $box ? $box->id() : 0 ),
				'product_id'      => $product_id,
				'contents'        => BoxProduct::times( $contents, (int) $order_item->get_quantity() ),
				'ships_at'        => $created,
			)
		);
	}

	/**
	 * Is this subscription a box?
	 *
	 * @param int $subscription_id Subscription id.
	 *
	 * @return bool
	 */
	public static function is_box( int $subscription_id ): bool {
		return ! empty( get_post_meta( $subscription_id, self::META_CONTENTS, true ) );
	}

	/**
	 * What the next box holds.
	 *
	 * @param int $subscription_id Subscription id.
	 *
	 * @return array[]
	 */
	public static function contents( int $subscription_id ): array {
		return BoxProduct::normalise_items( get_post_meta( $subscription_id, self::META_CONTENTS, true ) );
	}

	/**
	 * The rules this subscriber is on.
	 *
	 * Falls back to the product's current rules for a subscription created
	 * before the snapshot existed.
	 *
	 * @param int $subscription_id Subscription id.
	 *
	 * @return array
	 */
	public static function rules( int $subscription_id ): array {
		$rules = get_post_meta( $subscription_id, self::META_RULES, true );

		if ( is_array( $rules ) && $rules ) {
			return $rules;
		}

		return BoxProduct::rules(
			(int) get_post_meta( $subscription_id, '_subscrpt_product_id', true ),
			(int) get_post_meta( $subscription_id, '_subscrpt_variation_id', true )
		);
	}

	/**
	 * When this subscriber's next box stops accepting changes.
	 *
	 * Computed from the renewal date every time it is asked for, so moving a
	 * renewal date — a skip, an early renewal, an admin edit — moves the lock
	 * with it and nothing has to be kept in sync.
	 *
	 * @param int $subscription_id Subscription id.
	 *
	 * @return int Unix timestamp, or 0 when there is no renewal date.
	 */
	public static function lock_timestamp( int $subscription_id ): int {
		$next_date = (int) get_post_meta( $subscription_id, '_subscrpt_next_date', true );

		if ( ! $next_date ) {
			return 0;
		}

		$rules = self::rules( $subscription_id );

		return $next_date - ( max( 0, (int) ( $rules['lock_days'] ?? 0 ) ) * DAY_IN_SECONDS );
	}

	/**
	 * Has the next box locked?
	 *
	 * @param int $subscription_id Subscription id.
	 *
	 * @return bool
	 */
	public static function is_locked( int $subscription_id ): bool {
		$lock = self::lock_timestamp( $subscription_id );

		return $lock > 0 && time() >= $lock;
	}

	/**
	 * May this subscriber change the contents of their next box?
	 *
	 * @param int $subscription_id Subscription id.
	 *
	 * @return bool
	 */
	public static function can_edit( int $subscription_id ): bool {
		$rules = self::rules( $subscription_id );

		if ( empty( $rules['allow_edit'] ) ) {
			return false;
		}

		if ( BoxProduct::TYPE_CURATED === ( $rules['type'] ?? '' ) ) {
			return false;
		}

		return ! self::is_locked( $subscription_id );
	}

	/**
	 * The products this subscriber may pick from.
	 *
	 * A build-your-own box offers its pool. An edition box offers only what the
	 * merchant allowed swapping for that edition.
	 *
	 * @param int $subscription_id Subscription id.
	 *
	 * @return int[]
	 */
	public static function allowed_products( int $subscription_id ): array {
		$rules = self::rules( $subscription_id );

		if ( BoxProduct::TYPE_EDITION === ( $rules['type'] ?? '' ) ) {
			$edition_id = (int) get_post_meta( $subscription_id, self::META_EDITION, true );
			$edition    = $edition_id ? EditionRepository::find( $edition_id ) : null;

			return $edition && $edition['swap_pool'] ? $edition['swap_pool'] : array();
		}

		$box = self::box( $subscription_id );

		return $box ? $box->pool_product_ids() : array();
	}

	/**
	 * The box this subscription was bought as.
	 *
	 * @param int $subscription_id Subscription id.
	 *
	 * @return Box|null
	 */
	public static function box( int $subscription_id ): ?Box {
		$product_id   = (int) get_post_meta( $subscription_id, '_subscrpt_product_id', true );
		$variation_id = (int) get_post_meta( $subscription_id, '_subscrpt_variation_id', true );
		$box_id       = (int) get_post_meta( $subscription_id, self::META_BOX, true );

		if ( $box_id ) {
			$box = BoxProduct::box_for( $product_id, $box_id, $variation_id );

			// The product may have stopped selling the box since it was bought.
			return $box ? $box : BoxRepository::find( $box_id );
		}

		return BoxProduct::resolve( $product_id, $variation_id );
	}

	/**
	 * How many units a fixed price was agreed for.
	 *
	 * What sign-up recorded; for a subscription older than that record, its
	 * snapshot's maximum. Never fewer than the box renews with now; once rows are not part of that.
	 *
	 * @param int   $subscription_id Subscription id.
	 * @param array $current         What the box holds now.
	 *
	 * @return int
	 */
	public static function agreed_units( int $subscription_id, array $current ): int {
		$units = (int) get_post_meta( $subscription_id, self::META_UNITS, true );

		if ( $units <= 0 ) {
			$units = (int) ( self::rules( $subscription_id )['max'] ?? 0 );
		}

		return max( $units, BoxProduct::count_units( BoxProduct::split_once( $current )[0] ) );
	}

	/**
	 * Does a selection hold more once units of any product than the box does now?
	 *
	 * @param array $old   What the box holds now.
	 * @param array $items The new selection.
	 *
	 * @return bool
	 */
	private static function adds_once_units( array $old, array $items ): bool {
		$held = array();

		foreach ( BoxProduct::split_once( $old )[1] as $row ) {
			$key          = $row['product_id'] . ':' . $row['variation_id'];
			$held[ $key ] = ( $held[ $key ] ?? 0 ) + $row['qty'];
		}

		$wanted = array();

		foreach ( BoxProduct::split_once( $items )[1] as $row ) {
			$key            = $row['product_id'] . ':' . $row['variation_id'];
			$wanted[ $key ] = ( $wanted[ $key ] ?? 0 ) + $row['qty'];
		}

		foreach ( $wanted as $key => $qty ) {
			if ( $qty > ( $held[ $key ] ?? 0 ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * The once rows a selection adds to what the box holds now.
	 *
	 * Rows the box already owes stay as they are, so a unit is new only past
	 * the units held of that product and variation.
	 *
	 * @param array $old   What the box holds now.
	 * @param array $items The new selection.
	 *
	 * @return array[] Normalised once rows, each at the quantity added.
	 */
	private static function new_once_rows( array $old, array $items ): array {
		$held = array();

		foreach ( BoxProduct::split_once( $old )[1] as $row ) {
			$key          = $row['product_id'] . ':' . $row['variation_id'];
			$held[ $key ] = ( $held[ $key ] ?? 0 ) + $row['qty'];
		}

		$new = array();

		foreach ( BoxProduct::split_once( $items )[1] as $row ) {
			$key = $row['product_id'] . ':' . $row['variation_id'];
			$add = $row['qty'] - ( $held[ $key ] ?? 0 );

			if ( $add > 0 ) {
				$row['qty'] = $add;
				$new[]      = $row;
			}
		}

		return $new;
	}

	/**
	 * How many boxes the subscription's order line was bought for.
	 *
	 * A renewal prices its box line times this, so a quote of the next renewal does too.
	 *
	 * @param int $subscription_id Subscription id.
	 *
	 * @return int At least 1.
	 */
	public static function boxes( int $subscription_id ): int {
		$order = wc_get_order( (int) get_post_meta( $subscription_id, '_subscrpt_order_id', true ) );
		$item  = $order ? $order->get_item( (int) get_post_meta( $subscription_id, '_subscrpt_order_item_id', true ) ) : false;

		return $item ? max( 1, (int) $item->get_quantity() ) : 1;
	}

	/**
	 * Why the customer may not change this box now, whatever they pick.
	 *
	 * @param int $subscription_id Subscription id.
	 *
	 * @return \WP_Error|null Null when nothing stands in the way.
	 */
	public static function customer_refusal( int $subscription_id ): ?\WP_Error {
		$rules = self::rules( $subscription_id );

		if ( empty( $rules['allow_edit'] ) ) {
			return new \WP_Error( 'subscrpt_box_edit_disabled', __( 'This box cannot be changed.', 'subscription-pro' ) );
		}

		// The gateway bills a plan it holds, at the amount it was given; a box
		// changed here would ship for what the gateway never agreed to charge.
		if ( self::is_gateway_scheduled( $subscription_id ) ) {
			return new \WP_Error(
				'subscrpt_box_gateway_scheduled',
				__( 'Your payment provider bills this box on its own schedule, so it cannot be changed here. Contact the store to change it.', 'subscription-pro' )
			);
		}

		if ( self::is_locked( $subscription_id ) ) {
			return new \WP_Error(
				'subscrpt_box_locked',
				__( 'Your next box is already being packed, so it can no longer be changed.', 'subscription-pro' )
			);
		}

		return null;
	}

	/**
	 * Save new contents for the next box.
	 *
	 * @param int    $subscription_id Subscription id.
	 * @param array  $items           The new selection.
	 * @param string $actor           'customer' or 'admin'. An admin may edit past the lock.
	 *
	 * @return true|\WP_Error
	 */
	public static function update_contents( int $subscription_id, array $items, string $actor = 'customer' ) {
		if ( ! self::is_box( $subscription_id ) ) {
			return new \WP_Error( 'subscrpt_box_not_a_box', __( 'This subscription is not a box.', 'subscription-pro' ) );
		}

		$rules = self::rules( $subscription_id );

		if ( 'admin' !== $actor ) {
			$refusal = self::customer_refusal( $subscription_id );

			if ( $refusal ) {
				return $refusal;
			}
		}

		$items = BoxProduct::normalise_items( $items );

		// The same rule engine the cart uses. These checks were written out
		// separately here, and had already drifted from it: the cap on how many
		// of one product a box may hold was enforced at checkout and not here,
		// so a subscriber could save a box that could never have been bought.
		// A once item ships in the next box only, so it never fills the minimum
		// the renewing box must hold; the maximum and the per-item cap are about
		// everything that ships, once items included.
		list( $recurring ) = BoxProduct::split_once( $items );

		$too_few = BoxRules::check(
			array(
				'op'    => BoxRules::OP_AT_LEAST,
				'value' => (int) ( $rules['min'] ?? 0 ),
			),
			$recurring,
			BoxRules::SCOPE_BOX
		);

		if ( is_string( $too_few ) ) {
			return new \WP_Error( 'subscrpt_box_too_few', $too_few );
		}

		$too_many = BoxRules::check(
			array(
				'op'    => BoxRules::OP_AT_MOST,
				'value' => (int) ( $rules['max'] ?? 0 ),
			),
			$items,
			BoxRules::SCOPE_BOX
		);

		if ( is_string( $too_many ) ) {
			return new \WP_Error( 'subscrpt_box_too_many', $too_many );
		}

		// Admin-exempt, like the pool check below it. How many of one product a
		// box may hold is a merchandising rule aimed at shoppers, not a data
		// constraint — and a store fixing a box on a customer's behalf, often
		// after the lock, is exactly the case that needs to break it.
		if ( 'admin' !== $actor ) {
			$over_one = BoxRules::check_per_item( $items, (int) ( $rules['max_per_item'] ?? 0 ) );

			if ( is_string( $over_one ) ) {
				return new \WP_Error( 'subscrpt_box_too_many_of_one', $over_one );
			}
		}

		$old = self::contents( $subscription_id );

		if ( 'admin' !== $actor ) {
			$unlisted = self::unlisted_row( $subscription_id, $old, $items );

			if ( $unlisted ) {
				$product = wc_get_product( $unlisted['variation_id'] ? $unlisted['variation_id'] : $unlisted['product_id'] );

				return new \WP_Error(
					'subscrpt_box_not_allowed',
					sprintf(
						/* translators: %s: product name. */
						__( '%s is not available in this box.', 'subscription-pro' ),
						$product ? $product->get_name() : __( 'That product', 'subscription-pro' )
					)
				);
			}
		}

		// Up to the units the price was agreed for: a swap, or growing back after a shrink, stays allowed.
		// A once item has no price to be charged at, so a new one, or more of one the
		// store already added, is an addition; an unchanged row is kept.
		if ( 'admin' !== $actor
			&& BoxPricing::STRATEGY_FIXED === self::pricing( $subscription_id )['strategy']
			&& ( self::adds_once_units( $old, $items ) || BoxProduct::count_units( $recurring ) > self::agreed_units( $subscription_id, $old ) ) ) {
			return new \WP_Error(
				'subscrpt_box_add_fixed_price',
				__( 'Your box renews at the price you agreed, whatever it holds, so it cannot take more items. Swap an item instead.', 'subscription-pro' )
			);
		}

		// A store may sell a product once only where it allows a one-time purchase; what the box already
		// owes stays even if that was turned off since.
		if ( 'admin' !== $actor ) {
			$one_time = BoxRules::check_one_time( self::new_once_rows( $old, $items ) );

			if ( is_string( $one_time ) ) {
				return new \WP_Error( 'subscrpt_box_not_one_time', $one_time );
			}
		}

		$new = BoxProduct::describe_items( $items );

		update_post_meta( $subscription_id, self::META_CONTENTS, $new );

		self::note(
			$subscription_id,
			'admin' === $actor
				? __( 'Box contents changed by the store.', 'subscription-pro' )
				: __( 'Box contents changed by the customer.', 'subscription-pro' ),
			__( 'Box Updated', 'subscription-pro' ),
			'box_updated'
		);

		/**
		 * Fires after a box's contents are saved.
		 *
		 * @param int    $subscription_id Subscription id.
		 * @param array  $old             Contents before the change.
		 * @param array  $new             Contents after the change.
		 * @param string $actor           'customer', 'admin', or 'system' when pro changed the box itself
		 *                                (next-box-only items leaving once their renewal is paid, or a published edition applied).
		 */
		do_action( 'subscrpt_box_contents_changed', $subscription_id, $old, $new, $actor );

		return true;
	}

	/**
	 * The first posted row a customer may not put in this box, if any.
	 *
	 * A row is allowed when the product it ships is one the box offers, can be
	 * bought and is not a box itself, or when the box already holds at least as
	 * many of it. An empty list therefore means "no swaps", not "anything":
	 * an edition with no swap list, a missing edition or a deleted box offers
	 * nothing new, the same rule BoxQuote prices by.
	 *
	 * @param int     $subscription_id Subscription id.
	 * @param array[] $held            Normalised rows the box holds.
	 * @param array[] $items           Normalised rows posted.
	 *
	 * @return array|null
	 */
	private static function unlisted_row( int $subscription_id, array $held, array $items ): ?array {
		$allowed = array_map( 'intval', self::allowed_products( $subscription_id ) );
		$owned   = array();
		$wanted  = array();

		foreach ( $held as $row ) {
			$key           = $row['product_id'] . ':' . $row['variation_id'];
			$owned[ $key ] = ( $owned[ $key ] ?? 0 ) + $row['qty'];
		}

		foreach ( $items as $row ) {
			$key            = $row['product_id'] . ':' . $row['variation_id'];
			$wanted[ $key ] = ( $wanted[ $key ] ?? 0 ) + $row['qty'];
		}

		foreach ( $items as $row ) {
			$key = $row['product_id'] . ':' . $row['variation_id'];

			if ( $wanted[ $key ] <= ( $owned[ $key ] ?? 0 ) ) {
				continue;
			}

			$shipped = $row['variation_id'] ? $row['variation_id'] : $row['product_id'];
			$product = in_array( $shipped, $allowed, true ) ? wc_get_product( $shipped ) : null;

			if ( ! $product instanceof \WC_Product || ! $product->is_purchasable() || BoxProduct::is_box( $product ) ) {
				return $row;
			}
		}

		return null;
	}

	/**
	 * Take next-box-only items that have shipped and been paid for out of the box.
	 *
	 * Removes up to the units shipped of each once row, so a unit added since
	 * the renewal was built stays for the box after it. A renewal date settles
	 * once: a retry for an unpaid renewal is built for the same date, and paying
	 * both, or paying one twice, must not take out what the next box holds.
	 *
	 * @param int   $subscription_id Subscription id.
	 * @param array $shipped         The contents the paid renewal's box line carries.
	 * @param int   $due             The renewal date that order was built for.
	 *
	 * @return bool True when the contents changed.
	 */
	public static function settle_once_items( int $subscription_id, array $shipped, int $due ): bool {
		list( , $once ) = BoxProduct::split_once( $shipped );

		if ( ! $once || ! self::is_box( $subscription_id ) ) {
			return false;
		}

		$settled = get_post_meta( $subscription_id, self::META_ONCE_SETTLED, true );
		$settled = is_array( $settled ) ? array_map( 'intval', $settled ) : array();

		if ( in_array( $due, $settled, true ) ) {
			return false;
		}

		$settled[] = $due;

		// Retries share a date only with the renewal just before them, so a
		// short history is enough.
		update_post_meta( $subscription_id, self::META_ONCE_SETTLED, array_slice( $settled, -12 ) );

		$owed = array();

		foreach ( $once as $row ) {
			$owed[ $row['product_id'] . ':' . $row['variation_id'] ] = $row['qty'];
		}

		$old     = self::contents( $subscription_id );
		$kept    = array();
		$removed = false;

		foreach ( $old as $row ) {
			$key = $row['product_id'] . ':' . $row['variation_id'];

			if ( $row['once'] && ! empty( $owed[ $key ] ) ) {
				$taken         = min( $row['qty'], $owed[ $key ] );
				$owed[ $key ] -= $taken;
				$row['qty']   -= $taken;
				$removed       = true;

				if ( $row['qty'] < 1 ) {
					continue;
				}
			}

			$kept[] = $row;
		}

		if ( ! $removed ) {
			return false;
		}

		$new = BoxProduct::describe_items( $kept );

		update_post_meta( $subscription_id, self::META_CONTENTS, $new );

		self::note(
			$subscription_id,
			__( 'Next-box-only items shipped with the paid renewal and were taken out of the box.', 'subscription-pro' ),
			__( 'Box Updated', 'subscription-pro' ),
			'box_updated'
		);

		/** This action is documented in BoxSubscription::update_contents(). */
		do_action( 'subscrpt_box_contents_changed', $subscription_id, $old, $new, 'system' );

		return true;
	}

	/**
	 * May this subscriber skip their next box?
	 *
	 * @param int $subscription_id Subscription id.
	 *
	 * @return bool
	 */
	public static function can_skip( int $subscription_id ): bool {
		// Skipping moves the renewal date. On a subscription that is not active, that is the date
		// its dunning, expiry or end of access is measured from.
		if ( 'active' !== get_post_status( $subscription_id ) ) {
			return false;
		}

		$rules = self::rules( $subscription_id );

		if ( empty( $rules['allow_skip'] ) || self::is_locked( $subscription_id ) ) {
			return false;
		}

		$max_skips = (int) ( $rules['max_skips'] ?? 0 );

		if ( $max_skips && (int) get_post_meta( $subscription_id, self::META_SKIPS, true ) >= $max_skips ) {
			return false;
		}

		// A split-payment subscription owes a fixed number of payments, so
		// skipping one would change what was agreed.
		$product_id = (int) get_post_meta( $subscription_id, '_subscrpt_product_id', true );

		if ( 'split_payment' === get_post_meta( $product_id, '_subscrpt_payment_type', true ) ) {
			return false;
		}

		return ! self::is_gateway_scheduled( $subscription_id );
	}

	/**
	 * Does the gateway, rather than this site, decide when to charge?
	 *
	 * PayPal bills a plan it holds: moving the renewal date here would not stop
	 * PayPal charging on its own schedule, so skipping is not offered.
	 *
	 * @param int $subscription_id Subscription id.
	 *
	 * @return bool
	 */
	public static function is_gateway_scheduled( int $subscription_id ): bool {
		$order = wc_get_order( (int) get_post_meta( $subscription_id, '_subscrpt_order_id', true ) );

		if ( ! $order ) {
			return false;
		}

		return false !== strpos( (string) $order->get_payment_method(), 'paypal' );
	}

	/**
	 * Skip the next box.
	 *
	 * @param int    $subscription_id Subscription id.
	 * @param string $actor           'customer' or 'admin'.
	 *
	 * @return true|\WP_Error
	 */
	public static function skip( int $subscription_id, string $actor = 'customer' ) {
		if ( ! self::is_box( $subscription_id ) ) {
			return new \WP_Error( 'subscrpt_box_not_a_box', __( 'This subscription is not a box.', 'subscription-pro' ) );
		}

		if ( 'admin' !== $actor && ! self::can_skip( $subscription_id ) ) {
			return new \WP_Error(
				'subscrpt_box_skip_unavailable',
				__( 'This box cannot be skipped.', 'subscription-pro' )
			);
		}

		$next_date = (int) get_post_meta( $subscription_id, '_subscrpt_next_date', true );

		if ( ! $next_date ) {
			return new \WP_Error( 'subscrpt_box_no_next_date', __( 'This subscription has no next renewal to skip.', 'subscription-pro' ) );
		}

		$new_date = self::add_one_period( $subscription_id, $next_date );

		if ( ! $new_date || $new_date <= $next_date ) {
			return new \WP_Error( 'subscrpt_box_skip_failed', __( 'The next renewal date could not be moved.', 'subscription-pro' ) );
		}

		update_post_meta( $subscription_id, '_subscrpt_next_date', $new_date );
		update_post_meta( $subscription_id, self::META_SKIPS, (int) get_post_meta( $subscription_id, self::META_SKIPS, true ) + 1 );

		// The box that was about to ship is gone, so the next one is a new
		// cycle and deserves its own email.
		delete_post_meta( $subscription_id, self::META_NOTIFIED );

		// Tell the warehouse. A cycle the subscriber skipped has to read as
		// deliberately empty rather than simply absent, or a picker working from
		// the list packs a box nobody is paying for — and a shipment already
		// recorded for that cycle would otherwise sit there as "scheduled".
		$skipped_cycle = BoxCycle::key( $next_date );
		$existing      = ShipmentRepository::for_cycle( $subscription_id, $skipped_cycle );

		if ( $existing ) {
			ShipmentRepository::set_status(
				(int) $existing['id'],
				ShipmentRepository::STATUS_SKIPPED,
				__( 'The subscriber skipped this cycle.', 'subscription-pro' )
			);
		} else {
			$shipment_id = ShipmentRepository::record(
				array(
					'subscription_id' => $subscription_id,
					'cycle_key'       => $skipped_cycle,
					'product_id'      => (int) get_post_meta( $subscription_id, '_subscrpt_product_id', true ),
					'box_id'          => (int) get_post_meta( $subscription_id, self::META_BOX, true ),
					'ships_at'        => $next_date,
				)
			);

			if ( $shipment_id ) {
				ShipmentRepository::set_status(
					$shipment_id,
					ShipmentRepository::STATUS_SKIPPED,
					__( 'The subscriber skipped this cycle.', 'subscription-pro' )
				);
			}
		}

		self::note(
			$subscription_id,
			sprintf(
				/* translators: %s: new renewal date. */
				__( 'Box skipped. The next one is due %s.', 'subscription-pro' ),
				date_i18n( get_option( 'date_format' ), $new_date )
			),
			__( 'Box Skipped', 'subscription-pro' ),
			'box_skipped'
		);

		/**
		 * Fires after a box is skipped.
		 *
		 * @param int $subscription_id Subscription id.
		 * @param int $old_next_date   The renewal date that was skipped.
		 * @param int $new_next_date   The renewal date now due.
		 */
		do_action( 'subscrpt_box_skipped', $subscription_id, $next_date, $new_date );

		return true;
	}

	/**
	 * Move a date forward by one billing period.
	 *
	 * @param int $subscription_id Subscription id.
	 * @param int $from            Timestamp to move.
	 *
	 * @return int
	 */
	public static function add_one_period( int $subscription_id, int $from ): int {
		$per    = (int) get_post_meta( $subscription_id, '_subscrpt_timing_per', true );
		$option = (string) get_post_meta( $subscription_id, '_subscrpt_timing_option', true );

		$per = $per > 0 ? $per : 1;

		if ( ! $option ) {
			$option = 'months';
		}

		if ( class_exists( FreeHelper::class ) && method_exists( FreeHelper::class, 'get_typos' ) ) {
			$option = FreeHelper::get_typos( $per, $option );
		}

		if ( function_exists( 'sdevs_wp_strtotime' ) ) {
			return (int) sdevs_wp_strtotime( $per . ' ' . $option, $from );
		}

		return (int) strtotime( '+' . $per . ' ' . $option, $from );
	}

	/**
	 * Make this subscription's next box the published edition, if there is one.
	 *
	 * Called when the upcoming-box email becomes due, which is what makes an
	 * edition reach people: publishing alone changes nothing, so a merchant can
	 * plan months ahead and a box that has already locked is never rewritten.
	 *
	 * @param int $subscription_id Subscription id.
	 *
	 * @return bool True when the contents changed.
	 */
	public static function materialise_edition( int $subscription_id ): bool {
		$rules = self::rules( $subscription_id );

		if ( BoxProduct::TYPE_EDITION !== ( $rules['type'] ?? '' ) ) {
			return false;
		}

		if ( self::is_locked( $subscription_id ) ) {
			return false;
		}

		$next_date = (int) get_post_meta( $subscription_id, '_subscrpt_next_date', true );

		if ( ! $next_date ) {
			return false;
		}

		$product_id = (int) get_post_meta( $subscription_id, '_subscrpt_product_id', true );

		// Which box this subscriber holds, not which product sold it. A
		// subscription taken before the box id was recorded falls back to
		// resolving it from the product, which is what it always did.
		$box_id = (int) get_post_meta( $subscription_id, self::META_BOX, true );

		if ( ! $box_id ) {
			$box    = BoxProduct::resolve( $product_id );
			$box_id = $box ? $box->id() : 0;
		}

		if ( ! $box_id ) {
			return false;
		}

		$edition = EditionRepository::published_for_date( $box_id, $next_date );

		if ( ! $edition || empty( $edition['contents'] ) ) {
			return false;
		}

		if ( (int) get_post_meta( $subscription_id, self::META_EDITION, true ) === (int) $edition['id'] ) {
			return false;
		}

		$old = self::contents( $subscription_id );
		$new = BoxProduct::describe_items( $edition['contents'] );

		update_post_meta( $subscription_id, self::META_CONTENTS, $new );
		update_post_meta( $subscription_id, self::META_EDITION, (int) $edition['id'] );

		self::note(
			$subscription_id,
			sprintf(
				/* translators: %s: edition title. */
				__( 'Next box set to the published edition: %s.', 'subscription-pro' ),
				$edition['title'] ? $edition['title'] : $edition['cycle_key']
			),
			__( 'Edition Applied', 'subscription-pro' ),
			'box_edition_applied'
		);

		/** This action is documented in BoxSubscription::update_contents(). */
		do_action( 'subscrpt_box_contents_changed', $subscription_id, $old, $new, 'system' );

		return true;
	}

	/**
	 * Record something on the subscription's activity log.
	 *
	 * @param int    $subscription_id Subscription id.
	 * @param string $content         Note text.
	 * @param string $activity        Short activity label.
	 * @param string $type            Activity type key.
	 *
	 * @return void
	 */
	private static function note( int $subscription_id, string $content, string $activity, string $type ): void {
		$comment_id = wp_insert_comment(
			array(
				'comment_author'  => 'Subscription for WooCommerce',
				'comment_content' => $content,
				'comment_post_ID' => $subscription_id,
				'comment_type'    => 'order_note',
			)
		);

		if ( $comment_id ) {
			update_comment_meta( $comment_id, '_subscrpt_activity', $activity );
			update_comment_meta( $comment_id, '_subscrpt_activity_type', $type );
		}
	}
}
