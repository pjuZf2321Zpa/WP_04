<?php
/**
 * What a box costs.
 *
 * Under the `fixed` strategy a box costs what its product or plan says, and
 * this class stays out of the way. Under `sum` the box price follows its
 * contents: a base price plus every picked item at its live price, less the
 * box's own discount. The plan then supplies only the cadence; its price and
 * Subscribe & Save discount are ignored, so the two discounts never stack.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Box
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Box;

defined( 'ABSPATH' ) || exit;

/**
 * The box pricing engine.
 */
class BoxPricing {

	/**
	 * Priced by the product or its plan, as before boxes had pricing.
	 */
	const STRATEGY_FIXED = 'fixed';

	/**
	 * Priced by what is in the box.
	 */
	const STRATEGY_SUM = 'sum';

	/**
	 * A tier measured in units picked.
	 */
	const MEASURE_QUANTITY = 'quantity';

	/**
	 * A tier measured in the money value of the eligible items.
	 */
	const MEASURE_AMOUNT = 'amount';

	/**
	 * A percentage off.
	 */
	const TYPE_PERCENT = 'percent';

	/**
	 * A money amount off.
	 */
	const TYPE_FIXED = 'fixed';

	/**
	 * Turn whatever is stored into a well-formed pricing config.
	 *
	 * @param mixed $raw Stored or posted config.
	 *
	 * @return array strategy, base_price, tiers (ascending by threshold), excluded, messages.
	 */
	public static function normalise_config( $raw ): array {
		$raw = is_array( $raw ) ? $raw : [];

		$tiers = [];

		foreach ( (array) ( $raw['tiers'] ?? [] ) as $tier ) {
			if ( ! is_array( $tier ) ) {
				continue;
			}

			$type  = self::TYPE_FIXED === ( $tier['type'] ?? '' ) ? self::TYPE_FIXED : self::TYPE_PERCENT;
			$value = max( 0.0, (float) ( $tier['value'] ?? 0 ) );

			$tiers[] = [
				'measure'   => self::MEASURE_AMOUNT === ( $tier['measure'] ?? '' ) ? self::MEASURE_AMOUNT : self::MEASURE_QUANTITY,
				'threshold' => max( 0.0, (float) ( $tier['threshold'] ?? 0 ) ),
				'type'      => $type,
				'value'     => self::TYPE_PERCENT === $type ? min( 100.0, $value ) : $value,
			];
		}

		// One measure per box: a tier on another measure than the first is dropped.
		$measure = $tiers ? $tiers[0]['measure'] : '';
		$tiers   = array_values(
			array_filter(
				$tiers,
				static function ( $tier ) use ( $measure ) {
					return $tier['measure'] === $measure;
				}
			)
		);

		// One tier per threshold, the larger discount, so the order is never left to usort().
		$unique = [];

		foreach ( $tiers as $tier ) {
			$key = (string) $tier['threshold'];

			if ( ! isset( $unique[ $key ] ) || $tier['value'] > $unique[ $key ]['value'] ) {
				$unique[ $key ] = $tier;
			}
		}

		$tiers = array_values( $unique );

		usort(
			$tiers,
			static function ( $a, $b ) {
				return $a['threshold'] <=> $b['threshold'];
			}
		);

		$excluded = array_values( array_unique( array_filter( array_map( 'absint', (array) ( $raw['excluded'] ?? [] ) ) ) ) );
		$messages = is_array( $raw['messages'] ?? null ) ? $raw['messages'] : [];

		return [
			'strategy'   => self::STRATEGY_SUM === ( $raw['strategy'] ?? '' ) ? self::STRATEGY_SUM : self::STRATEGY_FIXED,
			'base_price' => max( 0.0, (float) ( $raw['base_price'] ?? 0 ) ),
			'tiers'      => $tiers,
			'excluded'   => $excluded,
			'messages'   => [
				'progress' => sanitize_text_field( (string) ( $messages['progress'] ?? '' ) ),
				'success'  => sanitize_text_field( (string) ( $messages['success'] ?? '' ) ),
			],
		];
	}

	/**
	 * The live price of one item in a box.
	 *
	 * @param int $product_id   Product.
	 * @param int $variation_id Variation, 0 for none.
	 *
	 * @return float
	 */
	public static function item_price( int $product_id, int $variation_id = 0 ): float {
		$product = wc_get_product( $variation_id ? $variation_id : $product_id );
		$price   = $product instanceof \WC_Product ? (float) $product->get_price() : 0.0;

		/**
		 * Filter the price one box item contributes to a box priced by its contents.
		 *
		 * @param float $price        The item's live price.
		 * @param int   $product_id   Product id.
		 * @param int   $variation_id Variation id, 0 for none.
		 */
		return max( 0.0, (float) apply_filters( 'subscrpt_box_item_price', $price, $product_id, $variation_id ) );
	}

	/**
	 * Price a box's contents.
	 *
	 * Rows are `BoxProduct::normalise_items()` output (product_id, variation_id,
	 * qty). The engine does not normalise; the caller does.
	 *
	 * @param array $recurring Items shipped every cycle.
	 * @param array $config    Output of normalise_config().
	 * @param array $once      Items shipped in the first box only.
	 *
	 * @return array is_sum, base, subtotal_recurring, subtotal_once, discount_recurring,
	 *               discount_once, recurring, once, first, tier, next_tier, remaining.
	 *               Money is null under the fixed strategy.
	 */
	public static function quote( array $recurring, array $config, array $once = [] ): array {
		if ( self::STRATEGY_SUM !== ( $config['strategy'] ?? '' ) ) {
			return [
				'is_sum'             => false,
				'base'               => null,
				'subtotal_recurring' => null,
				'subtotal_once'      => null,
				'discount_recurring' => null,
				'discount_once'      => null,
				'recurring'          => null,
				'once'               => null,
				'first'              => null,
				'tier'               => null,
				'next_tier'          => null,
				'remaining'          => null,
			];
		}

		$excluded = array_map( 'intval', (array) ( $config['excluded'] ?? [] ) );
		$sums     = [
			'recurring' => self::totals( $recurring, $excluded ),
			'once'      => self::totals( $once, $excluded ),
		];

		$eligible = [
			self::MEASURE_QUANTITY => $sums['recurring']['eligible_qty'] + $sums['once']['eligible_qty'],
			self::MEASURE_AMOUNT   => self::round( $sums['recurring']['eligible'] + $sums['once']['eligible'] ),
		];

		$tier      = null;
		$next_tier = null;

		foreach ( (array) ( $config['tiers'] ?? [] ) as $candidate ) {
			if ( $eligible[ $candidate['measure'] ] >= $candidate['threshold'] ) {
				$tier = $candidate;
			} elseif ( null === $next_tier ) {
				$next_tier = $candidate;
			}
		}

		$pool     = $eligible[ self::MEASURE_AMOUNT ];
		$discount = 0.0;

		if ( $tier && $pool > 0 ) {
			$discount = self::TYPE_FIXED === $tier['type'] ? min( $tier['value'], $pool ) : $pool * $tier['value'] / 100;
		}

		$discount           = self::round( $discount );
		$discount_recurring = $pool > 0 ? self::round( $discount * self::round( $sums['recurring']['eligible'] ) / $pool ) : 0.0;
		$discount_once      = self::round( $discount - $discount_recurring );

		$base      = self::round( (float) ( $config['base_price'] ?? 0 ) );
		$recurring = self::round( $base + $sums['recurring']['subtotal'] - $discount_recurring );
		$once_due  = self::round( $sums['once']['subtotal'] - $discount_once );

		return [
			'is_sum'             => true,
			'base'               => $base,
			'subtotal_recurring' => self::round( $sums['recurring']['subtotal'] ),
			'subtotal_once'      => self::round( $sums['once']['subtotal'] ),
			'discount_recurring' => $discount_recurring,
			'discount_once'      => $discount_once,
			'recurring'          => $recurring,
			'once'               => $once_due,
			'first'              => self::round( $recurring + $once_due ),
			'tier'               => $tier,
			'next_tier'          => $next_tier,
			'remaining'          => $next_tier ? self::round( $next_tier['threshold'] - $eligible[ $next_tier['measure'] ] ) : 0.0,
		];
	}

	/**
	 * Price a box's contents under that box's own pricing.
	 *
	 * Rows are `BoxProduct::normalise_items()` output (product_id, variation_id,
	 * qty). The engine does not normalise; the caller does.
	 *
	 * @param Box   $box       The box.
	 * @param array $recurring Items shipped every cycle.
	 * @param array $once      Items shipped in the first box only.
	 *
	 * @return array See quote().
	 */
	public static function quote_for_box( Box $box, array $recurring, array $once = [] ): array {
		return self::quote( $recurring, $box->pricing(), $once );
	}

	/**
	 * What a box with first-box-only items is charged, first and after.
	 *
	 * The subscription renews at the renewal quote, what recurs priced on its
	 * own. The first payment is the quote of everything in the first box, so
	 * the once amount is the difference: when once items alone reach a tier,
	 * that saving lands in the once amount and a renewal never costs more
	 * than was shown. The once amount is charged as a cart fee, and a fee is
	 * never negative, so it is floored at 0; `first` is then the renewal
	 * price, and that is what is shown and charged for the first box.
	 *
	 * @param Box   $box       The box.
	 * @param array $recurring Items shipped every cycle.
	 * @param array $once      Items shipped in the first box only.
	 *
	 * @return array See quote(), with `recurring` the renewal quote's,
	 *               `once` = max( 0, first − recurring ) and `first` = recurring + once.
	 */
	public static function quote_charged( Box $box, array $recurring, array $once ): array {
		return self::quote_charged_under( $box->pricing(), $recurring, $once );
	}

	/**
	 * What a box with once items is charged, under a given pricing.
	 *
	 * As quote_charged(), for pricing that is not the box's own: a renewal is
	 * priced under the pricing its subscription was sold with.
	 *
	 * @param array $config    Output of normalise_config().
	 * @param array $recurring Items shipped every cycle.
	 * @param array $once      Items shipped in this box only.
	 *
	 * @return array See quote_charged().
	 */
	public static function quote_charged_under( array $config, array $recurring, array $once ): array {
		$quote = self::quote( $recurring, $config, $once );

		if ( ! $once || empty( $quote['is_sum'] ) ) {
			return $quote;
		}

		$renewal = self::quote( $recurring, $config, [] );

		$quote['recurring'] = $renewal['recurring'];
		$quote['once']      = max( 0.0, self::round( (float) $quote['first'] - (float) $renewal['recurring'] ) );
		$quote['first']     = self::round( $quote['recurring'] + $quote['once'] );

		return $quote;
	}

	/**
	 * What items cost at their own prices, with no box discount.
	 *
	 * @param array $items normalise_items() rows.
	 *
	 * @return float
	 */
	public static function list_price( array $items ): float {
		$total = 0.0;

		foreach ( $items as $item ) {
			$total += self::item_price( (int) $item['product_id'], (int) $item['variation_id'] ) * (int) $item['qty'];
		}

		return self::round( $total );
	}

	/**
	 * The "from" price of a box priced by its contents.
	 *
	 * It is the price of the box's default picks when they make a box the rules
	 * accept. Otherwise it is the cheapest box that can be packed: the cheapest
	 * in-stock items in the pool, up to the per-item cap, until the minimum is
	 * filled, or a single item when the box has no minimum.
	 *
	 * @param Box $box The box.
	 *
	 * @return float 0 when the box is not priced by its contents or nothing can be packed.
	 */
	public static function from_price( Box $box ): float {
		$config = $box->pricing();

		if ( self::STRATEGY_SUM !== $config['strategy'] ) {
			return 0.0;
		}

		$defaults = $box->default_items();

		if ( $defaults && true === $box->validate( $defaults ) ) {
			return (float) self::quote( $defaults, $config )['recurring'];
		}

		$need = max( 1, $box->size()['min'] );
		$cap  = $box->max_per_item();
		$cost = [];

		foreach ( $box->pool_product_ids() as $product_id ) {
			$product = wc_get_product( $product_id );

			if ( $product instanceof \WC_Product && $product->is_in_stock() ) {
				$cost[ $product_id ] = self::item_price( $product_id );
			}
		}

		asort( $cost );

		$picks = [];

		foreach ( array_keys( $cost ) as $product_id ) {
			$take = $cap ? min( $cap, $need ) : $need;

			$picks[] = [
				'product_id'   => $product_id,
				'variation_id' => 0,
				'qty'          => $take,
			];

			$need -= $take;

			if ( $need <= 0 ) {
				break;
			}
		}

		return $picks ? (float) self::quote( $picks, $config )['recurring'] : 0.0;
	}

	/**
	 * The line telling a customer how far to the next saving, or what they save.
	 *
	 * @param array $quote  Output of quote().
	 * @param array $config Output of normalise_config().
	 *
	 * @return string Plain text, empty when there is nothing to say.
	 */
	public static function message( array $quote, array $config ): string {
		if ( empty( $quote['is_sum'] ) ) {
			return '';
		}

		$messages = (array) ( $config['messages'] ?? [] );

		if ( ! empty( $quote['next_tier'] ) ) {
			$tier      = $quote['next_tier'];
			$template  = (string) ( $messages['progress'] ?? '' );
			$template  = '' !== $template ? $template : __( 'Add {remaining} more to save {discount}.', 'subscription-pro' );
			$remaining = self::MEASURE_AMOUNT === $tier['measure']
				? self::money( (float) $quote['remaining'] )
				: (string) ceil( (float) $quote['remaining'] );
		} elseif ( ! empty( $quote['tier'] ) && $quote['tier']['value'] > 0 ) {
			$tier      = $quote['tier'];
			$template  = (string) ( $messages['success'] ?? '' );
			$template  = '' !== $template ? $template : __( 'You are saving {discount}.', 'subscription-pro' );
			$remaining = '0';
		} else {
			return '';
		}

		$discount = self::TYPE_FIXED === $tier['type']
			? self::money( (float) $tier['value'] )
			: rtrim( rtrim( number_format( (float) $tier['value'], 2, '.', '' ), '0' ), '.' ) . '%';

		return strtr(
			$template,
			[
				'{remaining}' => $remaining,
				'{discount}'  => $discount,
			]
		);
	}

	/**
	 * Subtotals of a list of items, all and eligible for the discount.
	 *
	 * @param array $items    normalise_items() rows.
	 * @param int[] $excluded Product ids that are never discounted.
	 *
	 * @return array subtotal, eligible, eligible_qty.
	 */
	private static function totals( array $items, array $excluded ): array {
		$totals = [
			'subtotal'     => 0.0,
			'eligible'     => 0.0,
			'eligible_qty' => 0,
		];

		foreach ( $items as $item ) {
			$product_id = (int) ( $item['product_id'] ?? 0 );
			$qty        = (int) ( $item['qty'] ?? 0 );
			$line       = self::item_price( $product_id, (int) ( $item['variation_id'] ?? 0 ) ) * $qty;

			$totals['subtotal'] += $line;

			if ( ! in_array( $product_id, $excluded, true ) ) {
				$totals['eligible']     += $line;
				$totals['eligible_qty'] += $qty;
			}
		}

		return $totals;
	}

	/**
	 * Round money to the store's decimals.
	 *
	 * @param float $amount Amount.
	 *
	 * @return float
	 */
	private static function round( float $amount ): float {
		$decimals = function_exists( 'wc_get_price_decimals' ) ? (int) wc_get_price_decimals() : 2;

		return round( $amount, $decimals ) + 0.0;
	}

	/**
	 * Money as plain text.
	 *
	 * @param float $amount Amount.
	 *
	 * @return string
	 */
	private static function money( float $amount ): string {
		if ( function_exists( 'wc_price' ) ) {
			$html = wc_price( $amount );

			return html_entity_decode( function_exists( 'wp_strip_all_tags' ) ? wp_strip_all_tags( $html ) : $html, ENT_QUOTES );
		}

		return number_format( $amount, 2 );
	}
}
