<?php
/**
 * Editions — the contents a merchant publishes for one billing cycle.
 *
 * An edition is how "this month's box" works: the merchant plans a cycle's
 * contents ahead, publishes it, and every subscriber's next box becomes it when
 * their upcoming-box email is due. Someone who never opens that email still
 * ships exactly what was published, which is the fallback behaviour the
 * Shopify apps charge for.
 *
 * This is the only table the box feature adds.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Box
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Box;

defined( 'ABSPATH' ) || exit;

/**
 * Reads and writes box editions.
 */
class EditionRepository {

	/**
	 * Planned, not yet reaching subscribers.
	 */
	const STATUS_DRAFT = 'draft';

	/**
	 * Live: subscribers renewing in this cycle receive it.
	 */
	const STATUS_PUBLISHED = 'published';

	/**
	 * Fully qualified table name.
	 *
	 * @return string
	 */
	public static function table(): string {
		global $wpdb;

		return $wpdb->prefix . 'subscrpt_box_edition';
	}

	/**
	 * Create or upgrade the table.
	 *
	 * Called from the installer, which is itself re-run whenever
	 * `subscrpt_pro_db_version` falls behind — an activation hook alone would
	 * never fire for an existing install taking an update.
	 *
	 * @return void
	 */
	public static function create_table(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table   = self::table();
		$collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			box_id bigint(20) unsigned NOT NULL DEFAULT 0,
			product_id bigint(20) unsigned NOT NULL,
			cycle_key varchar(20) NOT NULL,
			title varchar(191) NOT NULL DEFAULT '',
			contents longtext NULL,
			swap_pool longtext NULL,
			status varchar(20) NOT NULL DEFAULT 'draft',
			published_at datetime NULL,
			created_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			updated_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY edition_box_cycle (box_id, cycle_key),
			KEY edition_box_status (box_id, status)
		) {$collate};";

		/*
		 * The new keys are deliberately named differently from the old ones.
		 * `box_cycle` and `box_status` already exist on this table, defined over
		 * `product_id` — and dbDelta can only ADD an index, never redefine one,
		 * so reusing those names fails with "Duplicate key name" on every
		 * upgrade and leaves the box_id columns unindexed. dbDelta never drops,
		 * so the originals stay behind harmlessly on the legacy column.
		 */

		dbDelta( $sql );
	}

	/**
	 * The cycle a timestamp belongs to.
	 *
	 * Cycles are months. A weekly box renewing four times in October shares one
	 * edition, which is what a merchant planning "the October box" means.
	 *
	 * @param int $timestamp Unix timestamp.
	 *
	 * @return string e.g. 2026-10.
	 */
	public static function cycle_key( int $timestamp ): string {
		return BoxCycle::key( $timestamp );
	}

	/**
	 * One edition by id.
	 *
	 * @param int $id Edition id.
	 *
	 * @return array|null
	 */
	public static function find( int $id ): ?array {
		global $wpdb;

		$table = self::table();
		$row   = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			ARRAY_A
		);

		return $row ? self::decode( $row ) : null;
	}

	/**
	 * The edition a box has for one cycle.
	 *
	 * Keyed on the box, not the product that sells it. A product may sell two
	 * edition boxes, and before this they shared a cycle's edition — so
	 * publishing October for one of them published it for both.
	 *
	 * @param int    $box_id    Box id.
	 * @param string $cycle_key Cycle key.
	 *
	 * @return array|null
	 */
	public static function for_cycle( int $box_id, string $cycle_key ): ?array {
		global $wpdb;

		$table = self::table();
		$row   = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE box_id = %d AND cycle_key = %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$box_id,
				$cycle_key
			),
			ARRAY_A
		);

		return $row ? self::decode( $row ) : null;
	}

	/**
	 * The published edition that applies to a renewal date.
	 *
	 * Falls back to the most recent published edition before that cycle, so a
	 * merchant who publishes nothing for November keeps shipping October's box
	 * rather than an empty one. The planner flags that gap; this method makes
	 * sure it is never a broken shipment.
	 *
	 * @param int $box_id    Box id.
	 * @param int $timestamp Renewal timestamp.
	 *
	 * @return array|null
	 */
	public static function published_for_date( int $box_id, int $timestamp ): ?array {
		global $wpdb;

		$table = self::table();

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name, not input.
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$table}
				 WHERE box_id = %d AND status = %s AND cycle_key <= %s
				 ORDER BY cycle_key DESC
				 LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$box_id,
				self::STATUS_PUBLISHED,
				self::cycle_key( $timestamp )
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return $row ? self::decode( $row ) : null;
	}

	/**
	 * The next cycles for a box, planned or not.
	 *
	 * Drives the planner: every row is a month the merchant can fill, with its
	 * edition when one exists.
	 *
	 * @param int $box_id Box id.
	 * @param int $count  How many cycles ahead, including the current one.
	 *
	 * @return array[] Each entry: cycle_key, label, edition (array|null).
	 */
	public static function upcoming( int $box_id, int $count = 6 ): array {
		$cycles = array();

		foreach ( BoxCycle::upcoming( $count ) as $cycle ) {
			$cycles[] = array(
				'cycle_key' => $cycle['key'],
				'label'     => $cycle['label'],
				'edition'   => self::for_cycle( $box_id, $cycle['key'] ),
			);
		}

		return $cycles;
	}

	/**
	 * Every edition of a box, newest cycle first.
	 *
	 * @param int $box_id Box id.
	 *
	 * @return array[]
	 */
	public static function all_for_box( int $box_id ): array {
		global $wpdb;

		$table = self::table();
		$rows  = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE box_id = %d ORDER BY cycle_key DESC", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$box_id
			),
			ARRAY_A
		);

		return array_map( array( __CLASS__, 'decode' ), $rows ? $rows : array() );
	}

	/**
	 * Create or update an edition.
	 *
	 * Keyed on (product_id, cycle_key), so saving the same cycle twice updates
	 * rather than duplicating.
	 *
	 * @param array $data product_id, cycle_key, title, contents, swap_pool, status.
	 *
	 * @return int Edition id, or 0 on failure.
	 */
	public static function save( array $data ): int {
		global $wpdb;

		$box_id    = absint( $data['box_id'] ?? 0 );
		$cycle_key = sanitize_text_field( (string) ( $data['cycle_key'] ?? '' ) );

		if ( ! $box_id || ! $cycle_key ) {
			return 0;
		}

		$now = current_time( 'mysql', true );

		$row = array(
			'box_id'     => $box_id,
			// Written but no longer read. Kept for one version so an install
			// that rolls back still finds the editions it planned.
			'product_id' => absint( $data['product_id'] ?? 0 ),
			'cycle_key'  => $cycle_key,
			'title'      => sanitize_text_field( (string) ( $data['title'] ?? '' ) ),
			'contents'   => wp_json_encode( BoxProduct::describe_items( (array) ( $data['contents'] ?? array() ) ) ),
			'swap_pool'  => wp_json_encode( array_map( 'absint', (array) ( $data['swap_pool'] ?? array() ) ) ),
			'status'     => self::STATUS_PUBLISHED === ( $data['status'] ?? '' ) ? self::STATUS_PUBLISHED : self::STATUS_DRAFT,
			'updated_at' => $now,
		);

		$existing = self::for_cycle( $box_id, $cycle_key );

		if ( $existing ) {
			// Publishing is its own action, so a plain save never silently
			// unpublishes a live edition.
			if ( self::STATUS_PUBLISHED === $existing['status'] ) {
				$row['status'] = self::STATUS_PUBLISHED;
			}

			$wpdb->update( self::table(), $row, array( 'id' => (int) $existing['id'] ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

			return (int) $existing['id'];
		}

		$row['created_at'] = $now;

		$wpdb->insert( self::table(), $row ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

		return (int) $wpdb->insert_id;
	}

	/**
	 * Publish an edition.
	 *
	 * @param int $id Edition id.
	 *
	 * @return bool
	 */
	public static function publish( int $id ): bool {
		global $wpdb;

		$edition = self::find( $id );

		if ( ! $edition ) {
			return false;
		}

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			self::table(),
			array(
				'status'       => self::STATUS_PUBLISHED,
				'published_at' => current_time( 'mysql', true ),
				'updated_at'   => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);

		/**
		 * Fires when a box edition goes live.
		 *
		 * @param int    $id         Edition id.
		 * @param int    $product_id Box product id.
		 * @param string $cycle_key  Cycle the edition covers.
		 */
		do_action( 'subscrpt_box_edition_published', $id, (int) $edition['product_id'], (string) $edition['cycle_key'] );

		return true;
	}

	/**
	 * Delete an edition.
	 *
	 * @param int $id Edition id.
	 *
	 * @return bool
	 */
	public static function delete( int $id ): bool {
		global $wpdb;

		return (bool) $wpdb->delete( self::table(), array( 'id' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	}

	/**
	 * How many live subscriptions an edition would reach.
	 *
	 * Counts active box subscriptions of this product whose next renewal falls
	 * inside the cycle. The planner shows it before publishing, because
	 * "applies to 340 subscribers from 15 October" is the sentence a merchant
	 * needs before pressing the button.
	 *
	 * @param int    $box_id    Box id.
	 * @param string $cycle_key Cycle key.
	 *
	 * @return int
	 */
	public static function subscriber_count( int $box_id, string $cycle_key ): int {
		// The cycle's bounds come from BoxCycle so they are read in the same
		// timezone the cycle key was written in. Working them out here with a
		// bare strtotime put the boundary in the server's timezone, which is a
		// month out for a subscriber renewing near midnight on the first.
		list( $start, $end ) = BoxCycle::bounds( $cycle_key );

		if ( ! $start ) {
			return 0;
		}

		$products = array();

		foreach ( BoxRepository::connections_for_box( $box_id ) as $connection ) {
			$products[] = (int) $connection['oid'];
		}

		$products = array_values( array_unique( array_filter( $products ) ) );

		if ( ! $products ) {
			return 0;
		}

		$subscriptions = get_posts(
			array(
				'post_type'      => 'subscrpt_order',
				'post_status'    => array( 'active', 'pe_cancelled' ),
				'fields'         => 'ids',
				'posts_per_page' => -1,
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					'relation' => 'AND',
					array(
						'key'     => '_subscrpt_product_id',
						'value'   => $products,
						'compare' => 'IN',
					),
					array(
						'key'     => '_subscrpt_next_date',
						'value'   => array( $start, $end ),
						'compare' => 'BETWEEN',
						'type'    => 'NUMERIC',
					),
				),
			)
		);

		return count( $subscriptions );
	}

	/**
	 * Give every edition the box it belongs to.
	 *
	 * Editions were keyed on the product that sold them, from before a box was
	 * a record of its own. That was wrong as soon as one product could sell two
	 * boxes — they shared a cycle, so publishing October for one published it
	 * for both — and it was already half-changed: the admin screen saved and
	 * read editions by box id while the storefront looked them up by product
	 * id, so a published edition could never be found by the thing that ships
	 * it unless the two ids happened to match.
	 *
	 * Runs once, after the box records exist. The old column is left in place.
	 *
	 * @return int How many rows were given a box.
	 */
	public static function backfill_box_ids(): int {
		global $wpdb;

		$table = self::table();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_results( "SELECT id, product_id FROM {$table} WHERE box_id = 0", ARRAY_A );

		if ( ! $rows ) {
			return 0;
		}

		$filled = 0;

		foreach ( $rows as $row ) {
			$product_id = (int) $row['product_id'];

			// The admin already wrote the box id into this column, so a value
			// that is itself a box is taken at face value rather than resolved.
			$box = BoxRepository::find( $product_id );

			if ( ! $box ) {
				$boxes = BoxRepository::resolve_for_product( $product_id );
				$box   = $boxes ? $boxes[0] : null;
			}

			if ( ! $box ) {
				continue;
			}

			$wpdb->update( $table, array( 'box_id' => $box->id() ), array( 'id' => (int) $row['id'] ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			++$filled;
		}

		return $filled;
	}

	/**
	 * Turn a database row into the shape everything else reads.
	 *
	 * @param array $row Raw row.
	 *
	 * @return array
	 */
	private static function decode( array $row ): array {
		$contents = json_decode( (string) $row['contents'], true );
		$pool     = json_decode( (string) $row['swap_pool'], true );

		$row['id']         = (int) $row['id'];
		$row['box_id']     = (int) ( $row['box_id'] ?? 0 );
		$row['product_id'] = (int) $row['product_id'];
		$row['contents']   = BoxProduct::normalise_items( is_array( $contents ) ? $contents : array() );
		$row['swap_pool']  = array_map( 'absint', is_array( $pool ) ? $pool : array() );

		return $row;
	}
}
