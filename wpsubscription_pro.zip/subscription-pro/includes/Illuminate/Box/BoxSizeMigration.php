<?php
/**
 * Keeps old boxes exact when a single bound stops meaning "exactly".
 *
 * Until now a box with only a minimum (or only a maximum) was read as that
 * exact count. A single bound now means "at least" or "at most", so every box
 * and connection saved under the old reading has the other bound written out,
 * once, and means what it always meant.
 *
 * Subscriptions snapshot their `min` and `max` at sign-up, already normalised,
 * so live subscriptions need nothing.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Box
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Box;

defined( 'ABSPATH' ) || exit;

/**
 * One-time conversion of one-bound sizes to exact ones.
 */
class BoxSizeMigration {

	/**
	 * Option set once the conversion has run.
	 */
	const OPTION = 'subscrpt_box_size_migrated';

	/**
	 * What a size with one bound meant before: both bounds equal.
	 *
	 * @param array $size min and max; a missing bound is 0.
	 *
	 * @return array{min:int,max:int}
	 */
	public static function normalise( array $size ): array {
		$min = max( 0, (int) ( $size['min'] ?? 0 ) );
		$max = max( 0, (int) ( $size['max'] ?? 0 ) );

		if ( $min && ! $max ) {
			$max = $min;
		}

		if ( $max && ! $min ) {
			$min = $max;
		}

		return array(
			'min' => $min,
			'max' => $max,
		);
	}

	/**
	 * Convert every one-bound box and connection, once.
	 *
	 * Marked done only when every write succeeded: a run that failed part way
	 * runs again on the next load, rather than leave exact boxes read as
	 * "at least". Each write only touches rows still one-bound, so running
	 * again is safe.
	 *
	 * @return int Rows changed; 0 when it has already run.
	 */
	public static function run(): int {
		global $wpdb;

		if ( get_option( self::OPTION ) ) {
			return 0;
		}

		$box      = BoxRepository::table();
		$relation = BoxRepository::relation_table();
		$changed  = 0;

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery -- table names only, no input.
		$failed = false;

		foreach ( array(
			"UPDATE {$box} SET size_max = size_min WHERE size_min > 0 AND size_max = 0",
			"UPDATE {$box} SET size_min = size_max WHERE size_max > 0 AND size_min = 0",
		) as $sql ) {
			$result = $wpdb->query( $sql );

			if ( false === $result ) {
				$failed = true;
				continue;
			}

			$changed += (int) $result;
		}

		$rows = $wpdb->get_results( "SELECT id, data FROM {$relation} WHERE data LIKE '%\"size\"%'", ARRAY_A );

		foreach ( (array) $rows as $row ) {
			$data = json_decode( (string) $row['data'], true );
			$size = is_array( $data ) && is_array( $data['size'] ?? null ) ? $data['size'] : array();

			if ( ! $size ) {
				continue;
			}

			$fixed = self::normalise( $size );

			// An override that sets neither bound stays empty, not 0/0.
			if ( ! $fixed['min'] && ! $fixed['max'] ) {
				continue;
			}

			if ( (int) ( $size['min'] ?? 0 ) === $fixed['min'] && (int) ( $size['max'] ?? 0 ) === $fixed['max'] && isset( $size['min'], $size['max'] ) ) {
				continue;
			}

			$data['size'] = $fixed;

			if ( false === $wpdb->update( $relation, array( 'data' => wp_json_encode( $data ) ), array( 'id' => (int) $row['id'] ) ) ) {
				$failed = true;
				continue;
			}

			++$changed;
		}
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery

		if ( ! $failed ) {
			update_option( self::OPTION, 1 );
		}

		BoxRepository::flush_cache();

		return $changed;
	}
}
