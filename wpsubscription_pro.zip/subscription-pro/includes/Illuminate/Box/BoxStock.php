<?php
/**
 * What a box ships when a pick is out of stock.
 *
 * WooCommerce lets stock go negative on a renewal rather than stopping it, so a
 * box with no rule here would quietly promise something the merchant cannot
 * pack. Each box chooses: replace the pick with a default, or ship without it.
 * Either way the order says what happened, because the customer will notice.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Box
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Box;

defined( 'ABSPATH' ) || exit;

/**
 * Resolves a selection against what is actually in stock.
 */
class BoxStock {

	/**
	 * Replace an unavailable pick with a default one.
	 */
	const RULE_REPLACE = 'replace';

	/**
	 * Ship the box without the unavailable pick.
	 */
	const RULE_DROP = 'drop';

	/**
	 * Resolve a selection against stock.
	 *
	 * @param array  $items      Selection.
	 * @param int    $product_id Box product id.
	 * @param string $rule       RULE_REPLACE or RULE_DROP.
	 * @param array  $notes      Filled with human-readable notes for the order.
	 *
	 * @return array[] The selection that can actually be packed.
	 */
	public static function resolve( array $items, int $product_id, string $rule = self::RULE_REPLACE, array &$notes = array() ): array {
		return self::resolve_for_box( $items, BoxProduct::primary_box( $product_id ), $rule, $notes );
	}

	/**
	 * Resolve a selection against stock, replacing from a given box.
	 *
	 * @param array    $items Selection.
	 * @param Box|null $box   The box replacements come from.
	 * @param string   $rule  RULE_REPLACE or RULE_DROP.
	 * @param array    $notes Filled with human-readable notes for the order.
	 *
	 * @return array[] The selection that can actually be packed.
	 */
	public static function resolve_for_box( array $items, ?Box $box, string $rule, array &$notes ): array {
		$items    = BoxProduct::normalise_items( $items );
		$resolved = array();
		$notes    = array();

		foreach ( $items as $item ) {
			if ( self::can_supply( $item ) ) {
				$resolved[] = $item;
				continue;
			}

			$missing = self::name_for( $item );

			// A next-box-only pick is never substituted, whatever the rule: it is
			// left out — not shipped, not charged — and stays owed in the
			// subscription until a box it can ship in.
			if ( $item['once'] ) {
				$notes[] = sprintf(
					/* translators: %s: product that ran out. */
					__( '%s was out of stock, so it was left out of this box and will ship in the next box instead.', 'subscription-pro' ),
					$missing
				);

				continue;
			}

			if ( self::RULE_REPLACE === $rule ) {
				$replacement = self::find_replacement( $box, array_merge( $resolved, $items ) );

				if ( $replacement ) {
					$replacement['qty'] = $item['qty'];
					$resolved[]         = $replacement;

					$notes[] = sprintf(
						/* translators: 1: product that ran out, 2: product shipped instead. */
						__( '%1$s was out of stock, so this box ships %2$s instead.', 'subscription-pro' ),
						$missing,
						self::name_for( $replacement )
					);

					continue;
				}
			}

			$notes[] = sprintf(
				/* translators: %s: product that ran out. */
				__( '%s was out of stock, so this box ships without it.', 'subscription-pro' ),
				$missing
			);
		}

		return $resolved;
	}

	/**
	 * Can this pick be supplied in the quantity asked for?
	 *
	 * A product that does not manage stock is always available — that is what
	 * "do not manage stock" means, and second-guessing it would block renewals
	 * on every store that tracks stock outside WooCommerce.
	 *
	 * @param array $item Selection entry.
	 *
	 * @return bool
	 */
	public static function can_supply( array $item ): bool {
		$product = wc_get_product( $item['variation_id'] ? $item['variation_id'] : $item['product_id'] );

		if ( ! $product instanceof \WC_Product ) {
			return false;
		}

		if ( ! $product->managing_stock() ) {
			return $product->is_in_stock();
		}

		return $product->is_in_stock() && $product->has_enough_stock( max( 1, (int) $item['qty'] ) );
	}

	/**
	 * Find something to ship in place of a pick that ran out.
	 *
	 * Prefers the box's own default picks — the merchant already said those
	 * represent the box — and falls back to anything else in the pool.
	 *
	 * @param Box|null $box     The box replacements come from.
	 * @param array    $exclude Picks already in the box.
	 *
	 * @return array|null Selection entry, or null when nothing is available.
	 */
	private static function find_replacement( ?Box $box, array $exclude ) {
		$taken = array();

		foreach ( BoxProduct::normalise_items( $exclude ) as $item ) {
			$taken[] = $item['product_id'];
		}

		$candidates = array();

		foreach ( $box ? $box->default_items() : array() as $item ) {
			$candidates[] = $item;
		}

		foreach ( $box ? $box->pool_product_ids() : array() as $id ) {
			$candidates[] = array(
				'product_id'   => $id,
				'variation_id' => 0,
				'qty'          => 1,
			);
		}

		foreach ( $candidates as $candidate ) {
			$candidate = BoxProduct::normalise_items( array( $candidate ) );

			if ( ! $candidate ) {
				continue;
			}

			$candidate = $candidate[0];

			if ( in_array( $candidate['product_id'], $taken, true ) ) {
				continue;
			}

			if ( self::can_supply( $candidate ) ) {
				return $candidate;
			}
		}

		return null;
	}

	/**
	 * A name for a pick, falling back to the snapshot when the product is gone.
	 *
	 * @param array $item Selection entry.
	 *
	 * @return string
	 */
	private static function name_for( array $item ): string {
		$product = wc_get_product( $item['variation_id'] ? $item['variation_id'] : $item['product_id'] );

		if ( $product instanceof \WC_Product ) {
			return $product->get_name();
		}

		return isset( $item['name'] ) && $item['name'] ? (string) $item['name'] : __( 'A product', 'subscription-pro' );
	}
}
