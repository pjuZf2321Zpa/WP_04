<?php
/**
 * How often a box ships and bills.
 *
 * A duration is an ordinary plan term in the free plugin's tables, attached to
 * the product that sells the box. Nothing at checkout or renewal knows it was
 * made from the Boxes screen: the plan selector, the cart and the renewal read
 * it exactly as they read a plan made on the Plans screen.
 *
 * Each box gets a plan group of its own with its first duration. A box may
 * instead borrow a shared group, whose durations it then shows read-only.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Box
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Box;

use SpringDevs\Subscription\Illuminate\Plans\PlanRepository;
use WP_Error;

defined( 'ABSPATH' ) || exit;

/**
 * Reads and writes a box's durations.
 */
class BoxDurations {

	/**
	 * Billing interval names, as the plan table stores them.
	 */
	const INTERVALS = [
		'day'   => 1,
		'week'  => 2,
		'month' => 3,
		'year'  => 4,
	];

	/**
	 * Every duration the box has, offered or not.
	 *
	 * @param Box $box Box.
	 *
	 * @return array[] Each entry: id, name, every, unit, trial, fee, price, on, cadence.
	 */
	public static function all( Box $box ): array {
		$group_id = $box->plan_group_id();

		if ( ! $group_id || ! PlanRepository::get_group( $group_id ) ) {
			return [];
		}

		$product_id = BoxSelling::product_id( $box->id() );
		$rows       = [];

		foreach ( PlanRepository::get_plans( $group_id ) as $plan ) {
			$relation = $product_id ? PlanRepository::find_relation( $plan['id'], $product_id ) : 0;
			$relation = $relation ? PlanRepository::get_relation( $relation ) : null;
			$unit     = array_search( (int) $plan['billing_interval'], self::INTERVALS, true );
			$unit     = $unit ? $unit : 'month';
			$every    = max( 1, (int) $plan['billing_frequency'] );

			$rows[] = [
				'id'      => (int) $plan['id'],
				'name'    => (string) $plan['title'],
				'every'   => $every,
				'unit'    => $unit,
				'trial'   => (int) $plan['free_trial'],
				'fee'     => (float) ( $plan['signup_fee']['amount'] ?? 0 ),
				'price'   => $relation ? (string) ( $relation['data']['regular_price'] ?? '' ) : '',
				'on'      => 'active' === $plan['status'],
				'cadence' => self::cadence( $every, $unit ),
			];
		}

		return $rows;
	}

	/**
	 * The durations a customer is offered.
	 *
	 * @param Box $box Box.
	 *
	 * @return array[]
	 */
	public static function offered( Box $box ): array {
		return array_values(
			array_filter(
				self::all( $box ),
				static function ( $duration ) {
					return $duration['on'];
				}
			)
		);
	}

	/**
	 * Add a duration to the box's own plan group.
	 *
	 * @param Box   $box    Box.
	 * @param array $fields name, every, unit, trial, fee, price.
	 *
	 * @return int|WP_Error Plan id.
	 */
	public static function add( Box $box, array $fields ) {
		if ( 'shared' === $box->plans()['mode'] ) {
			return self::shared_error();
		}

		$group_id = self::own_group( $box );

		if ( ! $group_id ) {
			return new WP_Error( 'subscrpt_box_duration_failed', __( 'The duration could not be added.', 'subscription-pro' ), [ 'status' => 500 ] );
		}

		$plan_id = PlanRepository::insert_plan(
			array_merge(
				self::plan_columns( $fields ),
				[
					'plan_group_id' => $group_id,
					'type'          => 'recurring',
					'status'        => 'active',
				]
			)
		);

		if ( ! $plan_id ) {
			return new WP_Error( 'subscrpt_box_duration_failed', __( 'The duration could not be added.', 'subscription-pro' ), [ 'status' => 500 ] );
		}

		$product_id = BoxSelling::product_id( $box->id() );

		if ( $product_id ) {
			self::relate( $plan_id, $product_id, self::price( $fields, $product_id ) );
		}

		return $plan_id;
	}

	/**
	 * Change one of the box's own durations.
	 *
	 * Only the fields sent are changed, so the switch can turn a duration off
	 * without restating it.
	 *
	 * @param Box   $box     Box.
	 * @param int   $plan_id Plan id.
	 * @param array $fields  Any of name, every, unit, trial, fee, price, on.
	 *
	 * @return true|WP_Error
	 */
	public static function update( Box $box, int $plan_id, array $fields ) {
		$error = self::guard( $box, $plan_id );

		if ( is_wp_error( $error ) ) {
			return $error;
		}

		$columns = self::plan_columns( $fields, true );

		if ( array_key_exists( 'on', $fields ) ) {
			$columns['status'] = $fields['on'] ? 'active' : 'draft';
		}

		if ( $columns ) {
			PlanRepository::update_plan( $plan_id, $columns );
		}

		$product_id = BoxSelling::product_id( $box->id() );

		if ( $product_id && array_key_exists( 'price', $fields ) ) {
			self::relate( $plan_id, $product_id, self::price( $fields, $product_id ) );
		}

		return true;
	}

	/**
	 * Remove one of the box's own durations.
	 *
	 * Subscriptions already on it keep their own terms, so they renew as sold.
	 *
	 * @param Box $box     Box.
	 * @param int $plan_id Plan id.
	 *
	 * @return true|WP_Error
	 */
	public static function delete( Box $box, int $plan_id ) {
		$error = self::guard( $box, $plan_id );

		if ( is_wp_error( $error ) ) {
			return $error;
		}

		PlanRepository::delete_plan( $plan_id );

		return true;
	}

	/**
	 * Use the box's own durations, or borrow a shared plan group's.
	 *
	 * The product leaves the group it was on and joins the other, so it is never
	 * offered both at once.
	 *
	 * @param Box    $box      Box.
	 * @param string $mode     own | shared.
	 * @param int    $group_id Shared group, when borrowing.
	 *
	 * @return true|WP_Error
	 */
	public static function use_source( Box $box, string $mode, int $group_id = 0 ) {
		$plans = $box->plans();

		if ( 'shared' === $mode ) {
			$group = $group_id ? PlanRepository::get_group( $group_id ) : null;

			if ( ! $group || self::owner_box( $group ) ) {
				return new WP_Error( 'subscrpt_box_plan_missing', __( 'Choose a plan from the Plans screen.', 'subscription-pro' ), [ 'status' => 400 ] );
			}
		}

		$product_id = BoxSelling::product_id( $box->id() );

		if ( $product_id ) {
			self::detach_product( $box, $product_id );
		}

		$plans['mode'] = 'shared' === $mode ? 'shared' : 'own';

		if ( 'shared' === $mode ) {
			$plans['shared_group_id'] = $group_id;
		}

		self::save_plans( $box, $plans );

		$box = BoxRepository::find( $box->id() );

		if ( $box && $product_id ) {
			self::attach_product( $box, $product_id );
		}

		return true;
	}

	/**
	 * Take on the plan a box's product already sells through.
	 *
	 * A box with no durations of its own whose product is on a plan from the
	 * Plans screen borrows that plan, rather than reading as having no
	 * durations while the product page offers them.
	 *
	 * @param Box $box Box.
	 *
	 * @return Box The box, re-read when it changed.
	 */
	public static function adopt( Box $box ): Box {
		$plans = $box->plans();

		if ( $plans['own_group_id'] || $plans['shared_group_id'] ) {
			return $box;
		}

		$product_id = BoxSelling::product_id( $box->id() );

		if ( ! $product_id ) {
			return $box;
		}

		foreach ( PlanRepository::get_product_connections( $product_id ) as $connection ) {
			if ( self::owner_box( [ 'data' => $connection['group_data'] ] ) ) {
				continue;
			}

			$plans['mode']            = 'shared';
			$plans['shared_group_id'] = (int) $connection['plan_group_id'];

			self::save_plans( $box, $plans );

			$adopted = BoxRepository::find( $box->id() );

			return $adopted ? $adopted : $box;
		}

		return $box;
	}

	/**
	 * Plan groups a box may borrow: every group not made for a box.
	 *
	 * @return array[] Each entry: id, title, durations.
	 */
	public static function shared_groups(): array {
		$groups = [];

		foreach ( PlanRepository::get_groups() as $group ) {
			if ( self::owner_box( $group ) || 'active' !== ( $group['status'] ?? 'active' ) ) {
				continue;
			}

			$groups[] = [
				'id'        => (int) $group['id'],
				'title'     => (string) $group['title'],
				'durations' => count( PlanRepository::get_plans( $group['id'] ) ),
			];
		}

		return $groups;
	}

	/**
	 * Put the product on every duration of the box's plan group.
	 *
	 * A duration that already has a price for the product keeps it; one that
	 * has none starts at the product's own price.
	 *
	 * @param Box $box        Box.
	 * @param int $product_id Product.
	 *
	 * @return void
	 */
	public static function attach_product( Box $box, int $product_id ): void {
		$group_id = $box->plan_group_id();

		if ( ! $group_id || ! $product_id ) {
			return;
		}

		foreach ( PlanRepository::get_plans( $group_id ) as $plan ) {
			$existing = PlanRepository::find_relation( $plan['id'], $product_id );

			if ( $existing ) {
				PlanRepository::update_relation( $existing, [ 'status' => 'active' ] );
				continue;
			}

			self::relate( (int) $plan['id'], $product_id, self::price( [], $product_id ) );
		}

		self::enable_product( $product_id );
	}

	/**
	 * Take the product off every duration of the box's plan group.
	 *
	 * @param Box $box        Box.
	 * @param int $product_id Product.
	 *
	 * @return void
	 */
	public static function detach_product( Box $box, int $product_id ): void {
		$group_id = $box->plan_group_id();

		if ( ! $group_id || ! $product_id ) {
			return;
		}

		foreach ( PlanRepository::get_plans( $group_id ) as $plan ) {
			$existing = PlanRepository::find_relation( $plan['id'], $product_id );

			if ( $existing ) {
				PlanRepository::delete_relation( $existing );
			}
		}
	}

	/**
	 * Retire the box's own plan group when the box is deleted.
	 *
	 * Drafted rather than deleted: a subscription sold on one of its durations
	 * still points at the term.
	 *
	 * @param Box $box Box.
	 *
	 * @return void
	 */
	public static function retire( Box $box ): void {
		$group_id = $box->plans()['own_group_id'];

		if ( $group_id && PlanRepository::get_group( $group_id ) ) {
			PlanRepository::update_group( $group_id, [ 'status' => 'draft' ] );
		}
	}

	/**
	 * Keep the box's own plan group named after the box.
	 *
	 * @param Box $box Box.
	 *
	 * @return void
	 */
	public static function rename( Box $box ): void {
		$group_id = $box->plans()['own_group_id'];

		if ( $group_id && PlanRepository::get_group( $group_id ) ) {
			PlanRepository::update_group( $group_id, [ 'title' => $box->title() ] );
		}
	}

	/**
	 * "every month", "every 3 months".
	 *
	 * @param int    $every How many units.
	 * @param string $unit  day | week | month | year.
	 *
	 * @return string
	 */
	public static function cadence( int $every, string $unit ): string {
		$unit = isset( self::INTERVALS[ $unit ] ) ? $unit : 'month';

		// "every month" reads better than "every 1 month", so one is its own string.
		if ( 1 === $every ) {
			$single = [
				'day'   => __( 'every day', 'subscription-pro' ),
				'week'  => __( 'every week', 'subscription-pro' ),
				'month' => __( 'every month', 'subscription-pro' ),
				'year'  => __( 'every year', 'subscription-pro' ),
			];

			return $single[ $unit ];
		}

		$many = [
			/* translators: %d: number of days. */
			'day'   => __( 'every %d days', 'subscription-pro' ),
			/* translators: %d: number of weeks. */
			'week'  => __( 'every %d weeks', 'subscription-pro' ),
			/* translators: %d: number of months. */
			'month' => __( 'every %d months', 'subscription-pro' ),
			/* translators: %d: number of years. */
			'year'  => __( 'every %d years', 'subscription-pro' ),
		];

		return sprintf( $many[ $unit ], $every );
	}

	/**
	 * The box's own plan group, created on first use.
	 *
	 * @param Box $box Box.
	 *
	 * @return int
	 */
	private static function own_group( Box $box ): int {
		$plans    = $box->plans();
		$group_id = $plans['own_group_id'];

		if ( $group_id && PlanRepository::get_group( $group_id ) ) {
			return $group_id;
		}

		$group_id = PlanRepository::insert_group(
			[
				'type'         => 'recurring',
				'product_type' => 1,
				'title'        => $box->title(),
				'status'       => 'active',
				'data'         => [ 'box_id' => $box->id() ],
			]
		);

		if ( ! $group_id ) {
			return 0;
		}

		$plans['own_group_id'] = (int) $group_id;
		self::save_plans( $box, $plans );

		return (int) $group_id;
	}

	/**
	 * Write the box's plan link without touching anything else on it.
	 *
	 * @param Box   $box   Box.
	 * @param array $plans mode, own_group_id, shared_group_id.
	 *
	 * @return void
	 */
	private static function save_plans( Box $box, array $plans ): void {
		$data          = $box->to_array();
		$data['plans'] = $plans;

		BoxRepository::save( $data );
	}

	/**
	 * Refuse a change to a duration the box does not own.
	 *
	 * @param Box $box     Box.
	 * @param int $plan_id Plan id.
	 *
	 * @return true|WP_Error
	 */
	private static function guard( Box $box, int $plan_id ) {
		if ( 'shared' === $box->plans()['mode'] ) {
			return self::shared_error();
		}

		$plan = PlanRepository::get_plan( $plan_id );

		if ( ! $plan || (int) $plan['plan_group_id'] !== $box->plans()['own_group_id'] ) {
			return new WP_Error( 'subscrpt_box_duration_missing', __( 'That duration is not part of this box.', 'subscription-pro' ), [ 'status' => 404 ] );
		}

		return true;
	}

	/**
	 * The answer to editing a borrowed plan from the box.
	 *
	 * @return WP_Error
	 */
	private static function shared_error(): WP_Error {
		return new WP_Error( 'subscrpt_box_duration_shared', __( 'This box uses a shared plan. Edit its durations on the Plans screen.', 'subscription-pro' ), [ 'status' => 400 ] );
	}

	/**
	 * The box a plan group was made for, or 0 for a shared group.
	 *
	 * @param array $group Plan group.
	 *
	 * @return int
	 */
	private static function owner_box( array $group ): int {
		return absint( $group['data']['box_id'] ?? 0 );
	}

	/**
	 * Map the duration form onto plan columns.
	 *
	 * @param array $fields  name, every, unit, trial, fee.
	 * @param bool  $partial Only the fields sent.
	 *
	 * @return array
	 */
	private static function plan_columns( array $fields, bool $partial = false ): array {
		$columns = [];

		if ( ! $partial || array_key_exists( 'name', $fields ) ) {
			$name             = trim( sanitize_text_field( (string) ( $fields['name'] ?? '' ) ) );
			$columns['title'] = '' !== $name ? $name : __( 'Monthly', 'subscription-pro' );
		}

		if ( ! $partial || array_key_exists( 'every', $fields ) ) {
			$columns['billing_frequency'] = max( 1, (int) ( $fields['every'] ?? 1 ) );
		}

		if ( ! $partial || array_key_exists( 'unit', $fields ) ) {
			$columns['billing_interval'] = self::INTERVALS[ $fields['unit'] ?? 'month' ] ?? self::INTERVALS['month'];
		}

		if ( ! $partial || array_key_exists( 'trial', $fields ) ) {
			$trial                 = max( 0, (int) ( $fields['trial'] ?? 0 ) );
			$columns['free_trial'] = $trial ? (string) $trial : '';
			$columns['data']       = [ 'free_trial_interval' => 'day' ];
		}

		if ( ! $partial || array_key_exists( 'fee', $fields ) ) {
			$fee                   = max( 0.0, (float) ( $fields['fee'] ?? 0 ) );
			$columns['signup_fee'] = [ 'amount' => $fee > 0 ? wc_format_decimal( $fee ) : '' ];
		}

		return $columns;
	}

	/**
	 * The price a duration charges for the product.
	 *
	 * @param array $fields     The form, which may carry a price.
	 * @param int   $product_id Product.
	 *
	 * @return string
	 */
	private static function price( array $fields, int $product_id ): string {
		$price = trim( (string) ( $fields['price'] ?? '' ) );

		if ( '' !== $price ) {
			return (string) wc_format_decimal( max( 0.0, (float) $price ) );
		}

		$product = wc_get_product( $product_id );

		return $product instanceof \WC_Product ? (string) $product->get_regular_price() : '';
	}

	/**
	 * Attach a product to a duration at a price.
	 *
	 * @param int    $plan_id    Plan id.
	 * @param int    $product_id Product.
	 * @param string $price      Regular price.
	 *
	 * @return void
	 */
	private static function relate( int $plan_id, int $product_id, string $price ): void {
		PlanRepository::insert_relation(
			[
				'plan_id' => $plan_id,
				'oid'     => $product_id,
				'vid'     => 0,
				'type'    => PlanRepository::REL_PRODUCT,
				'status'  => 'active',
				'exclude' => 0,
				'data'    => [ 'regular_price' => $price ],
			]
		);

		self::enable_product( $product_id );
	}

	/**
	 * Mark the product as sold by subscription, as connecting a plan does.
	 *
	 * Without the purchase limit WooCommerce treats a product with no price of
	 * its own as unpurchasable, and its plan selector never renders.
	 *
	 * @param int $product_id Product.
	 *
	 * @return void
	 */
	private static function enable_product( int $product_id ): void {
		update_post_meta( $product_id, '_subscrpt_enabled', 'yes' );
		update_post_meta( $product_id, '_subscrpt_plan_connected_before', 'yes' );

		if ( '' === get_post_meta( $product_id, '_subscrpt_limit', true ) ) {
			update_post_meta( $product_id, '_subscrpt_limit', 'unlimited' );
		}
	}
}
