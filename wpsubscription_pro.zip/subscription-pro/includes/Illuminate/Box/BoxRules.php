<?php
/**
 * One rule, asked at three scopes.
 *
 * A box rule, a step rule and a section rule are the same question with a
 * different subject: how much is in here, and is that allowed. Writing three
 * engines would guarantee they drift — and they already had. `Box::validate()`
 * enforced the per-item cap and `BoxSubscription::update_contents()` did not,
 * so a subscriber could edit their box past a limit the cart refused at
 * checkout. Both call the same primitive now.
 *
 * A rule is `measure` (how much), `op` (the test) and `value`. Measures are
 * deliberately only two: how many things, and how much money — pricing in
 * phase 6 asks the second of those and needs no new vocabulary.
 *
 * Every failure answers with a sentence a shopper can act on, naming what they
 * have and what is needed. "Invalid selection" is not a rule failing, it is a
 * rule refusing to explain itself.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Box
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Box;

defined( 'ABSPATH' ) || exit;

/**
 * Evaluates box, step and section rules.
 */
class BoxRules {

	/**
	 * Count the things in the box.
	 */
	const MEASURE_QUANTITY = 'quantity';

	/**
	 * Add up what they cost.
	 */
	const MEASURE_AMOUNT = 'amount';

	/**
	 * Exactly this much.
	 */
	const OP_EXACTLY = '=';

	/**
	 * This much or more.
	 */
	const OP_AT_LEAST = '>=';

	/**
	 * This much or less.
	 */
	const OP_AT_MOST = '<=';

	/**
	 * The whole box.
	 */
	const SCOPE_BOX = 'box';

	/**
	 * One step of a build.
	 */
	const SCOPE_STEP = 'step';

	/**
	 * One section within a step.
	 */
	const SCOPE_SECTION = 'section';

	/**
	 * Does a measurement satisfy an operator?
	 *
	 * @param string    $op       One of the OP_* constants.
	 * @param int|float $measured What was counted.
	 * @param int|float $value    What the rule asks for.
	 *
	 * @return bool
	 */
	public static function passes( string $op, $measured, $value ): bool {
		switch ( $op ) {
			case self::OP_AT_LEAST:
				return $measured >= $value;

			case self::OP_AT_MOST:
				return $measured <= $value;

			case self::OP_EXACTLY:
				return abs( (float) $measured - (float) $value ) < 0.0001;
		}

		// An operator we do not know is not a rule, and must not silently refuse
		// a shopper's box.
		return true;
	}

	/**
	 * What a selection measures.
	 *
	 * @param array  $items   Selection.
	 * @param string $measure One of the MEASURE_* constants.
	 *
	 * @return int|float
	 */
	public static function measure( array $items, string $measure ) {
		if ( self::MEASURE_AMOUNT === $measure ) {
			$total = 0.0;

			foreach ( BoxProduct::normalise_items( $items ) as $item ) {
				$product = wc_get_product( $item['variation_id'] ? $item['variation_id'] : $item['product_id'] );

				if ( $product instanceof \WC_Product ) {
					$total += (float) $product->get_price() * (int) $item['qty'];
				}
			}

			return $total;
		}

		return BoxProduct::count_units( $items );
	}

	/**
	 * Check one rule, and say what went wrong in words.
	 *
	 * @param array  $rule  measure, op, value.
	 * @param array  $items Selection being judged.
	 * @param string $scope One of the SCOPE_* constants.
	 * @param string $label What to call this scope on screen, e.g. "Coffee".
	 *
	 * @return true|string True, or the sentence for the rule that failed.
	 */
	public static function check( array $rule, array $items, string $scope = self::SCOPE_BOX, string $label = '' ) {
		$value = isset( $rule['value'] ) ? (float) $rule['value'] : 0.0;

		// Zero is "no rule", not "must be empty". A box with no minimum is not a
		// box that must hold nothing.
		if ( $value <= 0 ) {
			return true;
		}

		$measure  = ( $rule['measure'] ?? self::MEASURE_QUANTITY ) === self::MEASURE_AMOUNT
			? self::MEASURE_AMOUNT
			: self::MEASURE_QUANTITY;
		$op       = (string) ( $rule['op'] ?? self::OP_AT_LEAST );
		$measured = self::measure( $items, $measure );

		if ( self::passes( $op, $measured, $value ) ) {
			return true;
		}

		return self::sentence( $op, $measure, $measured, $value, $scope, $label );
	}

	/**
	 * The box's own size, expressed as rules.
	 *
	 * Keeps one definition of "this box holds between two and four things",
	 * rather than the size columns meaning one thing here and another there.
	 *
	 * @param array $size min and max.
	 *
	 * @return array[] Rules to check in order.
	 */
	public static function from_size( array $size ): array {
		$min   = (int) ( $size['min'] ?? 0 );
		$max   = (int) ( $size['max'] ?? 0 );
		$rules = array();

		if ( $min ) {
			$rules[] = array(
				'measure' => self::MEASURE_QUANTITY,
				'op'      => self::OP_AT_LEAST,
				'value'   => $min,
			);
		}

		if ( $max ) {
			$rules[] = array(
				'measure' => self::MEASURE_QUANTITY,
				'op'      => self::OP_AT_MOST,
				'value'   => $max,
			);
		}

		return $rules;
	}

	/**
	 * Check several rules, stopping at the first that fails.
	 *
	 * The first unmet rule is the one worth saying: a shopper fixes one thing
	 * at a time, and a list of four complaints reads as a broken form.
	 *
	 * @param array[] $rules One or more rules.
	 * @param array   $items Selection being judged.
	 * @param string  $scope One of the SCOPE_* constants.
	 * @param string  $label What to call this scope on screen.
	 *
	 * @return true|string
	 */
	public static function check_all( array $rules, array $items, string $scope = self::SCOPE_BOX, string $label = '' ) {
		foreach ( $rules as $rule ) {
			$result = self::check( (array) $rule, $items, $scope, $label );

			if ( is_string( $result ) ) {
				return $result;
			}
		}

		return true;
	}

	/**
	 * No more than this many of any one product.
	 *
	 * Its own method because it measures each line rather than the whole, and
	 * because the sentence has to name the product the shopper over-picked.
	 *
	 * @param array $items        Selection.
	 * @param int   $max_per_item Cap, or 0 for none.
	 *
	 * @return true|string
	 */
	public static function check_per_item( array $items, int $max_per_item ) {
		if ( $max_per_item <= 0 ) {
			return true;
		}

		// One product is one product whether it ships every cycle or once, so
		// the two rows of a split pick are judged on their total.
		$totals = array();

		foreach ( BoxProduct::normalise_items( $items ) as $item ) {
			$key = $item['product_id'] . ':' . $item['variation_id'];

			if ( ! isset( $totals[ $key ] ) ) {
				$totals[ $key ] = array(
					'item' => $item,
					'qty'  => 0,
				);
			}

			$totals[ $key ]['qty'] += $item['qty'];
		}

		foreach ( $totals as $total ) {
			if ( $total['qty'] > $max_per_item ) {
				$item   = $total['item'];
				$picked = wc_get_product( $item['variation_id'] ? $item['variation_id'] : $item['product_id'] );

				return sprintf(
					/* translators: 1: product name, 2: maximum units. */
					__( 'You can add at most %2$d × %1$s to one box.', 'subscription-pro' ),
					$picked ? $picked->get_name() : __( 'that product', 'subscription-pro' ),
					$max_per_item
				);
			}
		}

		return true;
	}

	/**
	 * Everything picked must be something this scope offers.
	 *
	 * @param array $items   Selection.
	 * @param int[] $allowed Product ids this scope offers.
	 *
	 * @return true|string
	 */
	public static function check_allowed( array $items, array $allowed ) {
		$allowed = array_map( 'absint', $allowed );

		foreach ( BoxProduct::normalise_items( $items ) as $item ) {
			// The product that is priced and shipped: the variation when there is one.
			$shipped = $item['variation_id'] ? $item['variation_id'] : $item['product_id'];

			if ( ! in_array( $shipped, $allowed, true ) ) {
				$picked = wc_get_product( $shipped );

				return sprintf(
					/* translators: %s: product name. */
					__( '%s is not available in this box.', 'subscription-pro' ),
					$picked ? $picked->get_name() : __( 'That product', 'subscription-pro' )
				);
			}
		}

		return true;
	}

	/**
	 * An item that ships once must be a product that can be bought once.
	 *
	 * @param array $items Selection.
	 *
	 * @return true|string
	 */
	public static function check_one_time( array $items ) {
		foreach ( BoxProduct::normalise_items( $items ) as $item ) {
			if ( $item['once'] && ! BoxCart::allows_one_time( $item['product_id'], $item['variation_id'] ) ) {
				$picked = wc_get_product( $item['variation_id'] ? $item['variation_id'] : $item['product_id'] );

				return sprintf(
					/* translators: %s: product name. */
					__( '%s can only be added every cycle.', 'subscription-pro' ),
					$picked ? $picked->get_name() : __( 'That product', 'subscription-pro' )
				);
			}
		}

		return true;
	}

	/**
	 * Say what is wrong, in the words of the scope that is complaining.
	 *
	 * The box speaks about "your box", because that is what the shopper thinks
	 * they are filling. A step or a section names itself, because on a stepped
	 * build "you need two more" is useless without saying two more of what.
	 *
	 * @param string    $op       Operator.
	 * @param string    $measure  Measure.
	 * @param int|float $measured What was counted.
	 * @param int|float $value    What the rule asks for.
	 * @param string    $scope    Scope.
	 * @param string    $label    Scope label.
	 *
	 * @return string
	 */
	private static function sentence( string $op, string $measure, $measured, $value, string $scope, string $label ): string {
		if ( self::MEASURE_AMOUNT === $measure ) {
			$have = wc_price( (float) $measured );
			$want = wc_price( (float) $value );

			if ( self::OP_AT_LEAST === $op ) {
				return self::scoped(
					$scope,
					$label,
					/* translators: 1: amount chosen, 2: amount needed. */
					__( 'Your box comes to %1$s, and this box needs at least %2$s.', 'subscription-pro' ),
					/* translators: 1: section name, 2: amount chosen, 3: amount needed. */
					__( '%1$s comes to %2$s, and needs at least %3$s.', 'subscription-pro' ),
					$have,
					$want
				);
			}

			return self::scoped(
				$scope,
				$label,
				/* translators: 1: amount chosen, 2: amount allowed. */
				__( 'Your box comes to %1$s, and this box takes at most %2$s.', 'subscription-pro' ),
				/* translators: 1: section name, 2: amount chosen, 3: amount allowed. */
				__( '%1$s comes to %2$s, and takes at most %3$s.', 'subscription-pro' ),
				$have,
				$want
			);
		}

		$measured = (int) $measured;
		$value    = (int) $value;

		if ( self::OP_AT_LEAST === $op ) {
			return self::scoped(
				$scope,
				$label,
				/* translators: 1: number of items chosen, 2: minimum. */
				_n(
					'Your box holds %1$d item, and this box needs at least %2$d.',
					'Your box holds %1$d items, and this box needs at least %2$d.',
					$measured,
					'subscription-pro'
				),
				/* translators: 1: section name, 2: number chosen, 3: minimum. */
				__( '%1$s holds %2$d, and needs at least %3$d.', 'subscription-pro' ),
				$measured,
				$value
			);
		}

		if ( self::OP_EXACTLY === $op ) {
			return self::scoped(
				$scope,
				$label,
				/* translators: 1: number of items chosen, 2: exact number required. */
				__( 'Your box holds %1$d items, and this box takes exactly %2$d.', 'subscription-pro' ),
				/* translators: 1: section name, 2: number chosen, 3: exact number. */
				__( '%1$s holds %2$d, and takes exactly %3$d.', 'subscription-pro' ),
				$measured,
				$value
			);
		}

		return self::scoped(
			$scope,
			$label,
			/* translators: 1: number of items chosen, 2: maximum. */
			__( 'Your box holds %1$d items, and this box takes at most %2$d.', 'subscription-pro' ),
			/* translators: 1: section name, 2: number chosen, 3: maximum. */
			__( '%1$s holds %2$d, and takes at most %3$d.', 'subscription-pro' ),
			$measured,
			$value
		);
	}

	/**
	 * Pick the box sentence or the named one.
	 *
	 * @param string $scope     Scope.
	 * @param string $label     Scope label.
	 * @param string $box_form  Sentence when the whole box is complaining.
	 * @param string $named_form Sentence when a step or section is.
	 * @param mixed  $have      What the shopper has.
	 * @param mixed  $want      What is needed.
	 *
	 * @return string
	 */
	private static function scoped( string $scope, string $label, string $box_form, string $named_form, $have, $want ): string {
		if ( self::SCOPE_BOX === $scope || '' === $label ) {
			return sprintf( $box_form, $have, $want );
		}

		return sprintf( $named_form, $label, $have, $want );
	}
}
