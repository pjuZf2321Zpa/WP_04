<?php
/**
 * Boxes and the products that sell them.
 *
 * All SQL for the box feature lives here, mirroring the free plugin's
 * `PlanRepository`: one cached resolver for the storefront, an uncached read
 * side for the admin, and writes that flush the cache. Two tables — the box
 * itself, and the product↔box connection — with the third (steps) arriving in
 * phase 2 between them, exactly as `subscrpt_plan` sits between a plan group
 * and its relations.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Box
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Box;

defined( 'ABSPATH' ) || exit;

/**
 * Reads and writes boxes.
 */
class BoxRepository {

	/**
	 * Object cache group. Flushed on every write.
	 */
	const CACHE_GROUP = 'subscrpt_boxes';

	/**
	 * The box table.
	 *
	 * @return string
	 */
	public static function table(): string {
		global $wpdb;

		return $wpdb->prefix . 'subscrpt_box';
	}

	/**
	 * The product↔box table.
	 *
	 * @return string
	 */
	public static function relation_table(): string {
		global $wpdb;

		return $wpdb->prefix . 'subscrpt_box_relation';
	}

	/**
	 * Create or upgrade both tables.
	 *
	 * Called from the installer, which re-runs whenever `subscrpt_pro_db_version`
	 * falls behind — an activation hook alone would never fire for an existing
	 * install taking an update.
	 *
	 * @return void
	 */
	public static function create_tables(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$collate  = $wpdb->get_charset_collate();
		$box      = self::table();
		$relation = self::relation_table();

		// The rule scalars are columns rather than JSON so that a schema change
		// shows up in dbDelta instead of hiding inside a blob. The three
		// list-shaped settings stay JSON in `data`.
		dbDelta(
			"CREATE TABLE {$box} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				title varchar(191) NOT NULL DEFAULT '',
				type varchar(20) NOT NULL DEFAULT 'curated',
				status varchar(20) NOT NULL DEFAULT 'draft',
				size_min int(11) unsigned NOT NULL DEFAULT 0,
				size_max int(11) unsigned NOT NULL DEFAULT 0,
				max_per_item int(11) unsigned NOT NULL DEFAULT 0,
				allow_edit tinyint(1) NOT NULL DEFAULT 1,
				lock_days int(11) unsigned NULL,
				allow_skip tinyint(1) NOT NULL DEFAULT 1,
				max_skips int(11) unsigned NOT NULL DEFAULT 0,
				stock_rule varchar(20) NOT NULL DEFAULT 'replace',
				data longtext NULL,
				created_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
				updated_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
				PRIMARY KEY  (id),
				KEY box_status (status)
			) {$collate};"
		);

		dbDelta(
			"CREATE TABLE {$relation} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				box_id bigint(20) unsigned NOT NULL,
				oid bigint(20) unsigned NOT NULL,
				vid bigint(20) unsigned NOT NULL DEFAULT 0,
				data longtext NULL,
				sort_order int(11) NOT NULL DEFAULT 0,
				status varchar(20) NOT NULL DEFAULT 'active',
				PRIMARY KEY  (id),
				KEY box_lookup (box_id),
				KEY product_lookup (oid, vid)
			) {$collate};"
		);
	}

	// ---- Storefront resolver ----

	/**
	 * The boxes a product sells.
	 *
	 * Cached per product id; variation filtering runs in PHP on the cached set,
	 * so a product with many variations still costs one query.
	 *
	 * @param int $product_id   Product (parent) id.
	 * @param int $variation_id Variation id, or 0.
	 *
	 * @return Box[]
	 */
	public static function resolve_for_product( int $product_id, int $variation_id = 0 ): array {
		$product_id = absint( $product_id );

		if ( ! $product_id ) {
			return array();
		}

		$cache_key = 'product_' . $product_id;
		$rows      = wp_cache_get( $cache_key, self::CACHE_GROUP );

		if ( false === $rows ) {
			$batch = self::resolve_for_products( array( $product_id ) );
			$rows  = $batch[ $product_id ] ?? array();

			wp_cache_set( $cache_key, $rows, self::CACHE_GROUP );
		}

		$variation_id = absint( $variation_id );
		$chosen       = array();

		foreach ( $rows as $row ) {
			$row_vid = (int) $row['vid'];

			// vid 0 = this connection applies to every variation.
			if ( $variation_id && 0 !== $row_vid && $variation_id !== $row_vid ) {
				continue;
			}

			$box_id = (int) ( $row['box']['id'] ?? 0 );

			// A product may connect the same box twice: once for every variation,
			// and once for a named one carrying its own size. Both survive the
			// filter above, so without this the catch-all wins on sort order and
			// the variation's size is read out of the table and then ignored —
			// which is how a large box quietly ships as a small one.
			if ( isset( $chosen[ $box_id ] ) && ( 0 === $row_vid || 0 !== (int) $chosen[ $box_id ]['vid'] ) ) {
				continue;
			}

			$chosen[ $box_id ] = $row;
		}

		$boxes = array();

		foreach ( $chosen as $row ) {
			$boxes[] = new Box( $row['box'], $row['override'] );
		}

		/**
		 * Filters the boxes resolved for a product.
		 *
		 * @param Box[] $boxes        Resolved boxes.
		 * @param int   $product_id   Product id.
		 * @param int   $variation_id Variation id (0 for simple).
		 */
		return apply_filters( 'subscrpt_resolve_boxes_for_product', $boxes, $product_id, $variation_id );
	}

	/**
	 * Batch-resolve boxes for many products in one query.
	 *
	 * Primes the per-product cache and keeps a shop loop off N+1.
	 *
	 * @param int[] $product_ids Product (parent) ids.
	 *
	 * @return array<int,array> Map of product id → rows of box + override + vid.
	 */
	public static function resolve_for_products( array $product_ids ): array {
		global $wpdb;

		$product_ids = array_values( array_unique( array_filter( array_map( 'absint', $product_ids ) ) ) );

		if ( empty( $product_ids ) ) {
			return array();
		}

		$map          = array_fill_keys( $product_ids, array() );
		$box          = self::table();
		$relation     = self::relation_table();
		$placeholders = implode( ',', array_fill( 0, count( $product_ids ), '%d' ) );

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT b.*, r.id AS relation_id, r.oid, r.vid, r.data AS relation_data, r.sort_order
				FROM {$relation} r
				INNER JOIN {$box} b ON b.id = r.box_id
				WHERE r.status = 'active'
					AND b.status = %s
					AND r.oid IN ({$placeholders})
				ORDER BY r.sort_order ASC, b.id ASC",
				array_merge( array( Box::STATUS_ACTIVE ), $product_ids )
			),
			ARRAY_A
		);
		// phpcs:enable

		if ( empty( $rows ) ) {
			return $map;
		}

		foreach ( $rows as $row ) {
			$oid = (int) $row['oid'];

			if ( ! isset( $map[ $oid ] ) ) {
				continue;
			}

			$override = self::maybe_json( $row['relation_data'] );

			unset( $row['relation_data'] );

			$map[ $oid ][] = array(
				'vid'         => (int) $row['vid'],
				'relation_id' => (int) $row['relation_id'],
				'override'    => is_array( $override['size'] ?? null ) ? $override['size'] : array(),
				'box'         => self::decode( $row ),
			);
		}

		return $map;
	}

	// ---- Read side ----

	/**
	 * One box by id, whatever its status.
	 *
	 * @param int $id Box id.
	 *
	 * @return Box|null
	 */
	public static function find( int $id ): ?Box {
		global $wpdb;

		$id = absint( $id );

		if ( ! $id ) {
			return null;
		}

		$table = self::table();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ), ARRAY_A );

		return $row ? new Box( self::decode( $row ) ) : null;
	}

	/**
	 * Every box, newest first.
	 *
	 * @param array $args status — one status or 'any' (default excludes trash).
	 *
	 * @return Box[]
	 */
	public static function all( array $args = array() ): array {
		global $wpdb;

		$table  = self::table();
		$status = $args['status'] ?? '';

		if ( 'any' === $status ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
			$rows = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY updated_at DESC, id DESC", ARRAY_A );
		} elseif ( $status ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE status = %s ORDER BY updated_at DESC, id DESC", $status ), ARRAY_A );
		} else {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE status != %s ORDER BY updated_at DESC, id DESC", Box::STATUS_TRASH ), ARRAY_A );
		}

		return array_map(
			static function ( $row ) {
				return new Box( self::decode( $row ) );
			},
			$rows ? $rows : array()
		);
	}

	/**
	 * The boxes a product sells, for the product editor.
	 *
	 * The mirror of `connections_for_box()`, and the admin counterpart to
	 * `resolve_for_product()`: no cache and no status filter, because the
	 * editor has to show a draft box the merchant is still working on. The
	 * storefront resolver deliberately hides those.
	 *
	 * @param int $product_id Product id.
	 *
	 * @return array[] Each entry: relation id, box_id, vid, size override, sort_order, status, and the box's title, type and status.
	 */
	public static function connections_for_product( int $product_id ): array {
		global $wpdb;

		$product_id = absint( $product_id );

		if ( ! $product_id ) {
			return array();
		}

		$relation = self::relation_table();
		$box      = self::table();

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT r.id, r.box_id, r.oid, r.vid, r.data, r.sort_order, r.status,
						b.title AS box_title, b.type AS box_type, b.status AS box_status
				FROM {$relation} r
				INNER JOIN {$box} b ON b.id = r.box_id
				WHERE r.oid = %d
				ORDER BY r.sort_order ASC, r.id ASC",
				$product_id
			),
			ARRAY_A
		);
		// phpcs:enable

		return array_map(
			static function ( $row ) {
				$data = self::maybe_json( $row['data'] );

				return array(
					'id'         => (int) $row['id'],
					'box_id'     => (int) $row['box_id'],
					'oid'        => (int) $row['oid'],
					'vid'        => (int) $row['vid'],
					'size'       => is_array( $data['size'] ?? null ) ? $data['size'] : array(),
					'sort_order' => (int) $row['sort_order'],
					'status'     => (string) $row['status'],
					'box_title'  => (string) $row['box_title'],
					'box_type'   => (string) $row['box_type'],
					'box_status' => (string) $row['box_status'],
				);
			},
			$rows ? $rows : array()
		);
	}

	/**
	 * The products a box is attached to.
	 *
	 * Ignores the cache and the status filters so the admin reflects the live
	 * database.
	 *
	 * @param int $box_id Box id.
	 *
	 * @return array[] Each entry: id, box_id, oid, vid, size override, sort_order, status.
	 */
	public static function connections_for_box( int $box_id ): array {
		global $wpdb;

		$box_id = absint( $box_id );

		if ( ! $box_id ) {
			return array();
		}

		$relation = self::relation_table();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$relation} WHERE box_id = %d ORDER BY sort_order ASC, id ASC", $box_id ), ARRAY_A );

		return array_map(
			static function ( $row ) {
				$data = self::maybe_json( $row['data'] );

				return array(
					'id'         => (int) $row['id'],
					'box_id'     => (int) $row['box_id'],
					'oid'        => (int) $row['oid'],
					'vid'        => (int) $row['vid'],
					'size'       => is_array( $data['size'] ?? null ) ? $data['size'] : array(),
					'sort_order' => (int) $row['sort_order'],
					'status'     => (string) $row['status'],
				);
			},
			$rows ? $rows : array()
		);
	}

	/**
	 * Every product id selling any box.
	 *
	 * Replaces the old `_subscrpt_box` meta_key sweep over all products.
	 *
	 * @return int[]
	 */
	public static function connected_product_ids(): array {
		global $wpdb;

		$relation = self::relation_table();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$ids = $wpdb->get_col( "SELECT DISTINCT oid FROM {$relation} WHERE status = 'active'" );

		return array_map( 'absint', $ids ? $ids : array() );
	}

	// ---- Write side ----

	/**
	 * Create or update a box.
	 *
	 * @param array $data Box fields. An `id` updates, its absence inserts.
	 *
	 * @return int Box id, or 0 on failure.
	 */
	public static function save( array $data ): int {
		global $wpdb;

		$id  = absint( $data['id'] ?? 0 );
		$now = current_time( 'mysql', true );
		$row = self::prepare_columns( $data );

		$row['updated_at'] = $now;

		if ( $id ) {
			$wpdb->update( self::table(), $row, array( 'id' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		} else {
			$row['created_at'] = $now;

			$wpdb->insert( self::table(), $row ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

			$id = (int) $wpdb->insert_id;
		}

		self::flush_cache();

		/**
		 * Fires after a box is created or edited.
		 *
		 * @param int   $id   Box id.
		 * @param array $data The data as saved.
		 */
		do_action( 'subscrpt_box_saved', $id, $data );

		return $id;
	}

	/**
	 * Delete a box and every connection to it.
	 *
	 * Subscriptions already sold keep their own snapshot, so deleting a box
	 * never changes what an existing subscriber receives.
	 *
	 * @param int $id Box id.
	 *
	 * @return bool
	 */
	public static function delete( int $id ): bool {
		global $wpdb;

		$id = absint( $id );

		if ( ! $id ) {
			return false;
		}

		$wpdb->delete( self::relation_table(), array( 'box_id' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$deleted = $wpdb->delete( self::table(), array( 'id' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

		self::flush_cache();

		return (bool) $deleted;
	}

	/**
	 * Attach a box to a product.
	 *
	 * Idempotent on (box_id, oid, vid): attaching twice updates rather than
	 * duplicating.
	 *
	 * @param int   $box_id       Box id.
	 * @param int   $product_id   Product id.
	 * @param int   $variation_id Variation id, or 0 for every variation.
	 * @param array $data         Optional: size override, sort_order.
	 *
	 * @return int Relation id, or 0 on failure.
	 */
	public static function attach( int $box_id, int $product_id, int $variation_id = 0, array $data = array() ): int {
		global $wpdb;

		$box_id       = absint( $box_id );
		$product_id   = absint( $product_id );
		$variation_id = absint( $variation_id );

		if ( ! $box_id || ! $product_id ) {
			return 0;
		}

		$size = array();

		if ( isset( $data['size'] ) && is_array( $data['size'] ) ) {
			foreach ( array( 'min', 'max' ) as $bound ) {
				if ( '' !== (string) ( $data['size'][ $bound ] ?? '' ) ) {
					$size[ $bound ] = max( 0, (int) $data['size'][ $bound ] );
				}
			}
		}

		$row = array(
			'box_id'     => $box_id,
			'oid'        => $product_id,
			'vid'        => $variation_id,
			'data'       => wp_json_encode( array( 'size' => $size ) ),
			'sort_order' => (int) ( $data['sort_order'] ?? 0 ),
			'status'     => 'draft' === ( $data['status'] ?? '' ) ? 'draft' : 'active',
		);

		$relation = self::relation_table();

		// One product sells a box. Attaching another replaces it, wherever the
		// attach came from — the box screen or the product editor.
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$relation} WHERE box_id = %d AND oid != %d", $box_id, $product_id ) );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$existing = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$relation} WHERE box_id = %d AND oid = %d AND vid = %d", $box_id, $product_id, $variation_id ) );

		if ( $existing ) {
			$wpdb->update( $relation, $row, array( 'id' => (int) $existing ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

			$id = (int) $existing;
		} else {
			$wpdb->insert( $relation, $row ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

			$id = (int) $wpdb->insert_id;
		}

		self::flush_cache();

		/**
		 * Fires when a product is attached to a box.
		 *
		 * @param int $box_id       Box id.
		 * @param int $product_id   Product id.
		 * @param int $variation_id Variation id (0 for all).
		 */
		do_action( 'subscrpt_box_connected', $box_id, $product_id, $variation_id );

		return $id;
	}

	/**
	 * Change one connection without restating which product it joins.
	 *
	 * The admin edits a connection by its own id — the size this product sells
	 * the box in, or where it sits among several — so the row is addressed
	 * directly rather than by rebuilding its natural key. Only the fields
	 * present are touched.
	 *
	 * @param int   $relation_id Relation id.
	 * @param array $data        size (min/max), sort_order, status.
	 *
	 * @return bool
	 */
	public static function update_relation( int $relation_id, array $data ): bool {
		global $wpdb;

		$relation_id = absint( $relation_id );

		if ( ! $relation_id ) {
			return false;
		}

		$row = array();

		if ( isset( $data['size'] ) && is_array( $data['size'] ) ) {
			$size = array();

			foreach ( array( 'min', 'max' ) as $bound ) {
				if ( '' !== (string) ( $data['size'][ $bound ] ?? '' ) ) {
					$size[ $bound ] = max( 0, (int) $data['size'][ $bound ] );
				}
			}

			$row['data'] = wp_json_encode( array( 'size' => $size ) );
		}

		if ( isset( $data['sort_order'] ) ) {
			$row['sort_order'] = (int) $data['sort_order'];
		}

		if ( isset( $data['status'] ) ) {
			$row['status'] = 'draft' === $data['status'] ? 'draft' : 'active';
		}

		if ( ! $row ) {
			return false;
		}

		$updated = $wpdb->update( self::relation_table(), $row, array( 'id' => $relation_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

		self::flush_cache();

		return false !== $updated;
	}

	/**
	 * Remove one connection.
	 *
	 * @param int $relation_id Relation id.
	 *
	 * @return bool
	 */
	public static function detach( int $relation_id ): bool {
		global $wpdb;

		$deleted = $wpdb->delete( self::relation_table(), array( 'id' => absint( $relation_id ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

		self::flush_cache();

		return (bool) $deleted;
	}

	/**
	 * Drop every cached resolution.
	 *
	 * The resolver caches per product id and a write can change any of them, so
	 * the group is flushed whole rather than guessing which keys went stale. The
	 * cached answers to "which boxes hold this product" go with it.
	 *
	 * @return void
	 */
	public static function flush_cache(): void {
		BoxProduct::flush_containing_cache();

		if ( function_exists( 'wp_cache_flush_group' ) ) {
			wp_cache_flush_group( self::CACHE_GROUP );

			return;
		}

		wp_cache_flush();
	}

	// ---- Helpers ----

	/**
	 * Whitelist and sanitise the columns of a box.
	 *
	 * @param array $data Raw input.
	 *
	 * @return array
	 */
	private static function prepare_columns( array $data ): array {
		$types  = array( Box::TYPE_CURATED, Box::TYPE_BUILD, Box::TYPE_EDITION );
		$states = array( Box::STATUS_ACTIVE, Box::STATUS_DRAFT, Box::STATUS_TRASH );

		$row = array(
			'title'        => sanitize_text_field( (string) ( $data['title'] ?? '' ) ),
			'type'         => in_array( $data['type'] ?? '', $types, true ) ? $data['type'] : Box::TYPE_CURATED,
			'status'       => in_array( $data['status'] ?? '', $states, true ) ? $data['status'] : Box::STATUS_DRAFT,
			'size_min'     => max( 0, (int) ( $data['size_min'] ?? 0 ) ),
			'size_max'     => max( 0, (int) ( $data['size_max'] ?? 0 ) ),
			'max_per_item' => max( 0, (int) ( $data['max_per_item'] ?? 0 ) ),
			'allow_edit'   => empty( $data['allow_edit'] ) ? 0 : 1,
			'allow_skip'   => empty( $data['allow_skip'] ) ? 0 : 1,
			'max_skips'    => max( 0, (int) ( $data['max_skips'] ?? 0 ) ),
			'stock_rule'   => Box::STOCK_DROP === ( $data['stock_rule'] ?? '' ) ? Box::STOCK_DROP : Box::STOCK_REPLACE,
			'data'         => wp_json_encode(
				array(
					'pool'          => self::prepare_pool( $data['pool'] ?? array() ),
					'defaults'      => BoxProduct::describe_items( (array) ( $data['defaults'] ?? array() ) ),
					'items'         => BoxProduct::describe_items( (array) ( $data['items'] ?? array() ) ),
					'pricing'       => BoxPricing::normalise_config( $data['pricing'] ?? [] ),
					'show_together' => (bool) ( $data['show_together'] ?? true ),
					'plans'         => self::prepare_plans( $data['plans'] ?? array() ),
				)
			),
		);

		// An unset lock window means "use the store setting", which is not the
		// same as zero days, so it stays null rather than becoming 0.
		$row['lock_days'] = '' === (string) ( $data['lock_days'] ?? '' ) ? null : max( 0, (int) $data['lock_days'] );

		return $row;
	}

	/**
	 * Sanitise a pool definition.
	 *
	 * @param mixed $pool Raw pool.
	 *
	 * @return array
	 */
	private static function prepare_pool( $pool ): array {
		return BoxPool::normalise( $pool );
	}

	/**
	 * Sanitise the box's plan link.
	 *
	 * @param mixed $plans Raw plans.
	 *
	 * @return array
	 */
	private static function prepare_plans( $plans ): array {
		$plans = is_array( $plans ) ? $plans : array();

		return array(
			'mode'            => 'shared' === ( $plans['mode'] ?? '' ) ? 'shared' : 'own',
			'own_group_id'    => absint( $plans['own_group_id'] ?? 0 ),
			'shared_group_id' => absint( $plans['shared_group_id'] ?? 0 ),
		);
	}

	/**
	 * Turn a database row into the shape `Box` reads.
	 *
	 * @param array $row Raw row.
	 *
	 * @return array
	 */
	private static function decode( array $row ): array {
		$data = self::maybe_json( $row['data'] ?? '' );

		unset( $row['data'] );

		$row['id']            = (int) $row['id'];
		$row['pool']          = is_array( $data['pool'] ?? null ) ? $data['pool'] : array();
		$row['defaults']      = is_array( $data['defaults'] ?? null ) ? $data['defaults'] : array();
		$row['items']         = is_array( $data['items'] ?? null ) ? $data['items'] : array();
		$row['pricing']       = is_array( $data['pricing'] ?? null ) ? $data['pricing'] : [];
		$row['show_together'] = (bool) ( $data['show_together'] ?? true );
		$row['plans']         = is_array( $data['plans'] ?? null ) ? $data['plans'] : array();

		return $row;
	}

	/**
	 * Decode a JSON column, tolerating null and plain strings.
	 *
	 * @param string|null $value Raw column value.
	 *
	 * @return array
	 */
	private static function maybe_json( $value ): array {
		if ( empty( $value ) ) {
			return array();
		}

		if ( is_array( $value ) ) {
			return $value;
		}

		$decoded = json_decode( (string) $value, true );

		return is_array( $decoded ) ? $decoded : array();
	}
}
