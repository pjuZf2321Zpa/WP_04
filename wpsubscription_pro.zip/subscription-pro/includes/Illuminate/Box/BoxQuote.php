<?php
/**
 * The storefront's live box price.
 *
 * The builder never does price arithmetic. It posts what is picked and swaps
 * in what BoxPricing says, so the number on the product page, in the cart and
 * on the invoice come from one engine.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Box
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Box;

defined( 'ABSPATH' ) || exit;

/**
 * Quotes a box for the builder.
 */
class BoxQuote {

	/**
	 * The wc-ajax action.
	 */
	const ACTION = 'subscrpt_box_quote';

	/**
	 * The wc-ajax action quoting a live box.
	 */
	const SUBSCRIPTION_ACTION = 'subscrpt_box_subscription_quote';

	/**
	 * Nonce action of the My Account edit form, less the subscription id.
	 */
	const EDIT_NONCE_PREFIX = 'subscrpt_box_edit_';

	/**
	 * Register the endpoint.
	 *
	 * @return void
	 */
	public static function init(): void {
		add_action( 'wc_ajax_' . self::ACTION, [ __CLASS__, 'handle' ] );
		add_action( 'wc_ajax_' . self::SUBSCRIPTION_ACTION, [ __CLASS__, 'handle_subscription' ] );
	}

	/**
	 * Answer a quote request.
	 *
	 * Items outside the box's pool are dropped rather than refused: the
	 * builder only posts what it rendered, so anything else is not a pick.
	 *
	 * @param int   $product_id Box product.
	 * @param int   $box_id     Box.
	 * @param array $items      Picked items.
	 * @param array $once       First-box-only items.
	 * @param int   $variation_id Chosen variation, whose size the quote is "from" by; 0 for none.
	 * @param int   $plan_id      The plan the shopper chose, which names the interval; 0 for none.
	 *
	 * @return array price_html, regular_html, saving_html, is_from, message, recurring, once, is_sum, first, first_html, then_html, once_label.
	 *               `saving_html` is what the box takes off each cycle, empty without a saving. The last three describe a box with first-box-only items: what the first box
	 *               costs, and the two lines that say so. Empty without them.
	 *               Empty when the product does not sell that box.
	 */
	public static function respond( int $product_id, int $box_id, array $items, array $once = [], int $variation_id = 0, int $plan_id = 0 ): array {
		$box = BoxProduct::box_for( $product_id, $box_id, $variation_id );

		if ( ! $box ) {
			return [];
		}

		$config = $box->pricing();

		if ( BoxPricing::STRATEGY_SUM !== $config['strategy'] ) {
			return [
				'price_html'   => '',
				'regular_html' => '',
				'saving_html'  => '',
				'is_from'      => false,
				'message'      => '',
				'recurring'    => null,
				'once'         => null,
				'is_sum'       => false,
				'first'        => null,
				'first_html'   => '',
				'then_html'    => '',
				'once_label'   => '',
			];
		}

		$allowed   = $box->pool_product_ids();
		$recurring = self::within( BoxProduct::normalise_items( $items ), $allowed );
		$once      = self::within( BoxProduct::normalise_items( $once ), $allowed );
		// What is charged: renewals at what recurs alone, the first box at that
		// plus the once amount, which is never negative.
		$quote   = BoxPricing::quote_charged( $box, $recurring, $once );
		$units   = BoxProduct::count_units( $recurring ) + BoxProduct::count_units( $once );
		$is_from = $units < max( 1, $box->size()['min'] );
		$amount  = $quote['recurring'];

		if ( $is_from ) {
			$amount = BoxPricing::from_price( $box );
		}

		$regular = $is_from ? 0.0 : (float) $quote['base'] + (float) $quote['subtotal_recurring'];

		$interval = BoxOnceLabel::interval_for( $product_id, $plan_id );
		$split    = ! $is_from && $once ? self::split_html( $interval, $quote ) : [ '', '' ];

		return [
			'price_html'   => self::price_html( (float) $amount, $is_from ),
			'regular_html' => $regular > (float) $amount ? wc_price( $regular ) : '',
			'saving_html'  => ! $is_from && (float) $quote['discount_recurring'] > 0 ? wc_price( (float) $quote['discount_recurring'] ) : '',
			'is_from'      => $is_from,
			'message'      => BoxPricing::message( $quote, $config ),
			'recurring'    => $amount,
			'once'         => $quote['once'],
			'is_sum'       => true,
			'first'        => $quote['first'],
			'first_html'   => $split[0],
			'then_html'    => $split[1],
			'once_label'   => BoxOnceLabel::choice_label( $interval ),
		];
	}

	/**
	 * What a live box's next renewal charges, for the subscriber who owns it.
	 *
	 * The amount is the one the renewal builds its line with
	 * (BoxPricing::quote_charged_under(), under the pricing the subscription was
	 * sold with) and times the order line's quantity, so "Next box" is never
	 * derived a second way. Only the
	 * subscription's owner is quoted, and only a box priced by its contents: a
	 * fixed price has no sum to show.
	 *
	 * @param int   $subscription_id Subscription id.
	 * @param array $items           Items shipped every cycle, product_id => qty or rows.
	 * @param array $once            Items shipped in the next box only, product_id => qty or rows.
	 *
	 * @return array next, next_html, recurring, once, has_once, then_html, message. Empty when
	 *               the caller does not own a box priced by its contents.
	 */
	public static function respond_for_subscription( int $subscription_id, array $items, array $once = [] ): array {
		$user = get_current_user_id();

		if ( ! $user || (int) get_post_field( 'post_author', $subscription_id ) !== $user || ! BoxSubscription::is_box( $subscription_id ) ) {
			return [];
		}

		$config = BoxSubscription::pricing( $subscription_id );

		if ( BoxPricing::STRATEGY_SUM !== $config['strategy'] ) {
			return [];
		}

		// What is quoted is what saving would price: the rows the box holds as stored (the store may have put
		// them outside the pool), plus only what update_contents() would accept. The line's quantity is
		// applied as the renewal applies it.
		$held      = BoxProduct::normalise_items( BoxSubscription::contents( $subscription_id ) );
		$recurring = self::acceptable( $subscription_id, $held, BoxProduct::normalise_items( $items ), false );
		$once      = self::acceptable( $subscription_id, $held, BoxProduct::normalise_items( $once ), true );
		$quote     = BoxPricing::quote_charged_under( $config, $recurring, $once );
		$boxes     = BoxSubscription::boxes( $subscription_id );

		foreach ( [ 'first', 'recurring', 'once' ] as $key ) {
			$quote[ $key ] = (float) $quote[ $key ] * $boxes;
		}

		$then = '';

		if ( $once ) {
			$interval = BoxOnceLabel::interval_for( (int) get_post_meta( $subscription_id, '_subscrpt_product_id', true ), (int) get_post_meta( $subscription_id, '_subscrpt_plan_id', true ) );
			$then     = self::split_html( $interval, $quote )[1];
		}

		return [
			'next'      => $quote['first'],
			/* translators: %s: what the next box will cost, as HTML. */
			'next_html' => sprintf( esc_html__( 'Next box: %s', 'subscription-pro' ), wc_price( (float) $quote['first'] ) ),
			'recurring' => $quote['recurring'],
			'once'      => $quote['once'],
			'has_once'  => (bool) $once,
			'then_html' => $then,
			'message'   => BoxPricing::message( $quote, $config ),
		];
	}

	/**
	 * The posted rows a save could keep.
	 *
	 * A product the box holds is kept up to the units it holds (it may be outside the pool); any
	 * other must be in the subscription's pool. Units of a once row beyond those held also need a
	 * product the store sells once. The rest are left out of the price.
	 *
	 * @param int     $subscription_id Subscription id.
	 * @param array[] $held            Normalised rows the box holds.
	 * @param array[] $rows            Normalised rows posted, all every cycle or all once.
	 * @param bool    $once            Whether the rows are the next-box-only ones.
	 *
	 * @return array[]
	 */
	private static function acceptable( int $subscription_id, array $held, array $rows, bool $once ): array {
		$pool  = array_map( 'intval', BoxSubscription::allowed_products( $subscription_id ) );
		$owned = [];

		foreach ( $held as $row ) {
			if ( (bool) $row['once'] === $once ) {
				$key           = $row['product_id'] . ':' . $row['variation_id'];
				$owned[ $key ] = ( $owned[ $key ] ?? 0 ) + $row['qty'];
			}
		}

		$kept = [];

		foreach ( $rows as $row ) {
			$have = $owned[ $row['product_id'] . ':' . $row['variation_id'] ] ?? 0;
			$qty  = $row['qty'];

			if ( ! in_array( $row['product_id'], $pool, true ) ) {
				$qty = min( $qty, $have );
			} elseif ( $once && $qty > $have && is_string(
				BoxRules::check_one_time(
					[
						array_merge(
							$row,
							[
								'qty'  => 1,
								'once' => true,
							]
						),
					]
				)
			) ) {
				$qty = $have;
			}

			if ( $qty > 0 ) {
				$row['qty'] = $qty;
				$kept[]     = $row;
			}
		}

		return $kept;
	}

	/**
	 * The wc-ajax handler for a live box's quote.
	 *
	 * Posts the edit form's nonce for that subscription (`subscrpt_box_edit_<id>`),
	 * so it is the form's own page that asks, then checks the owner again. 403
	 * for either failing, 404 when the box has nothing to quote.
	 *
	 * @return void
	 */
	public static function handle_subscription(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Verified just below, from this same request.
		$request = wp_unslash( $_POST );
		// phpcs:enable WordPress.Security.NonceVerification.Missing
		$id    = isset( $request['subscription_id'] ) ? absint( $request['subscription_id'] ) : 0;
		$nonce = isset( $request['nonce'] ) && is_string( $request['nonce'] ) ? sanitize_text_field( $request['nonce'] ) : '';

		if ( ! $id || ! wp_verify_nonce( $nonce, self::EDIT_NONCE_PREFIX . $id ) || (int) get_post_field( 'post_author', $id ) !== get_current_user_id() ) {
			wp_send_json_error( [ 'message' => __( 'That subscription is not yours.', 'subscription-pro' ) ], 403 );
		}

		$items    = isset( $request['items'] ) && is_array( $request['items'] ) ? self::picks( $request['items'] ) : [];
		$once     = isset( $request['once'] ) && is_array( $request['once'] ) ? self::picks( $request['once'] ) : [];
		$response = self::respond_for_subscription( $id, $items, $once );

		if ( ! $response ) {
			wp_send_json_error( [ 'message' => __( 'That box has no price to show.', 'subscription-pro' ) ], 404 );
		}

		wp_send_json_success( $response );
	}

	/**
	 * The two lines for a box with first-box-only items.
	 *
	 * Where the box's plans disagree and none was chosen there is no one
	 * interval to say, so the line leaves it out.
	 *
	 * @param int[] $interval `[ frequency, interval ]`, empty when unknown.
	 * @param array $quote    Output of BoxPricing::quote_charged().
	 *
	 * @return string[] `[ first, then ]`, HTML.
	 */
	private static function split_html( array $interval, array $quote ): array {
		/* translators: %s: what the first box costs, as HTML. */
		$first = sprintf( esc_html__( 'First box %s', 'subscription-pro' ), wc_price( (float) $quote['first'] ) );

		if ( ! $interval ) {
			/* translators: %s: what each box after the first costs, as HTML. */
			return [ $first, sprintf( esc_html__( 'Then %s', 'subscription-pro' ), wc_price( (float) $quote['recurring'] ) ) ];
		}

		/* translators: 1: what each box after the first costs, as HTML. 2: how often it bills, e.g. "month" or "2 weeks". */
		$then = sprintf( esc_html__( 'Then %1$s / %2$s', 'subscription-pro' ), wc_price( (float) $quote['recurring'] ), esc_html( BoxOnceLabel::cadence( $interval[0], $interval[1] ) ) );

		return [ $first, $then ];
	}

	/**
	 * The wc-ajax handler.
	 *
	 * Read-only, so it carries no nonce; everything it reads is sanitised and
	 * the box is checked against the product.
	 *
	 * @return void
	 */
	public static function handle(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- read-only quote; picks() casts every key and value to an integer.
		$product_id = isset( $_REQUEST['product_id'] ) ? absint( $_REQUEST['product_id'] ) : 0;
		$box_id     = isset( $_REQUEST['box_id'] ) ? absint( $_REQUEST['box_id'] ) : 0;
		$variation  = isset( $_REQUEST['variation_id'] ) ? absint( $_REQUEST['variation_id'] ) : 0;
		$items      = isset( $_REQUEST['items'] ) && is_array( $_REQUEST['items'] ) ? self::picks( wp_unslash( $_REQUEST['items'] ) ) : [];
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		$flags = isset( $_REQUEST['once'] ) && is_array( $_REQUEST['once'] ) ? array_map( 'absint', wp_unslash( $_REQUEST['once'] ) ) : []; // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- read-only; every value is cast to an integer.

		list( $items, $once ) = self::split_once_flags( $items, $flags );

		$plan_id  = isset( $_REQUEST['plan_id'] ) ? absint( $_REQUEST['plan_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only quote.
		$response = self::respond( $product_id, $box_id, $items, $once, $variation, $plan_id );

		if ( ! $response ) {
			wp_send_json_error( [ 'message' => __( 'That box is not available.', 'subscription-pro' ) ], 404 );
		}

		wp_send_json_success( $response );
	}

	/**
	 * Move the picks the shopper marked once out of the recurring ones.
	 *
	 * @param array $items product_id => qty.
	 * @param array $flags product_id => truthy for each pick shipping once.
	 *
	 * @return array[] `[ recurring picks, once picks ]`, both product_id => qty.
	 */
	public static function split_once_flags( array $items, array $flags ): array {
		$once = [];

		foreach ( $flags as $product_id => $flag ) {
			$product_id = absint( $product_id );

			if ( $flag && ! empty( $items[ $product_id ] ) ) {
				$once[ $product_id ] = $items[ $product_id ];
				unset( $items[ $product_id ] );
			}
		}

		return [ $items, $once ];
	}

	/**
	 * A posted product_id => qty map, sanitised.
	 *
	 * @param array $raw Posted map.
	 *
	 * @return array
	 */
	private static function picks( array $raw ): array {
		$picks = [];

		foreach ( $raw as $product_id => $qty ) {
			$picks[ absint( $product_id ) ] = absint( is_scalar( $qty ) ? $qty : 0 );
		}

		return $picks;
	}

	/**
	 * The rows whose product the box offers.
	 *
	 * @param array $rows    normalise_items() rows.
	 * @param int[] $allowed Pool product ids.
	 *
	 * @return array
	 */
	private static function within( array $rows, array $allowed ): array {
		return array_values(
			array_filter(
				$rows,
				static function ( $row ) use ( $allowed ) {
					return in_array( $row['product_id'], $allowed, true );
				}
			)
		);
	}

	/**
	 * The price line.
	 *
	 * @param float $amount  Price.
	 * @param bool  $is_from Whether it is a "from" price.
	 *
	 * @return string HTML.
	 */
	public static function price_html( float $amount, bool $is_from ): string {
		if ( ! $is_from ) {
			return wc_price( $amount );
		}

		/* translators: %s: the lowest price the box can cost, as HTML. */
		return sprintf( esc_html__( 'from %s', 'subscription-pro' ), wc_price( $amount ) );
	}
}
