<?php
/**
 * The product that sells a box, and whether the box can go on sale.
 *
 * A box has exactly one WooCommerce product. The box decides what ships; the
 * product is what a customer adds to the cart. Publishing puts both on sale
 * together and moving to draft takes both off, so a shopper never meets a box
 * page with nothing behind it.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Box
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Box;

use WP_Error;

defined( 'ABSPATH' ) || exit;

/**
 * Links, publishes and deletes boxes with their product.
 */
class BoxSelling {

	/**
	 * Subscription statuses that still renew or may again.
	 */
	const LIVE_STATUSES = [ 'active', 'pending', 'on-hold', 'pe_cancelled' ];

	/**
	 * The product selling a box.
	 *
	 * @param int $box_id Box id.
	 *
	 * @return int 0 when none does.
	 */
	public static function product_id( int $box_id ): int {
		$connections = BoxRepository::connections_for_box( $box_id );

		return $connections ? (int) $connections[0]['oid'] : 0;
	}

	/**
	 * The product selling a box, as the admin shows it.
	 *
	 * @param int $box_id Box id.
	 *
	 * @return array|null id, name, status, status_label, edit_url, view_url, image, missing.
	 */
	public static function product( int $box_id ): ?array {
		$product_id = self::product_id( $box_id );

		if ( ! $product_id ) {
			return null;
		}

		$product = wc_get_product( $product_id );

		if ( ! $product instanceof \WC_Product ) {
			return [
				'id'           => $product_id,
				'name'         => __( '(deleted product)', 'subscription-pro' ),
				'status'       => '',
				'status_label' => __( 'Deleted', 'subscription-pro' ),
				'edit_url'     => '',
				'view_url'     => '',
				'image'        => '',
				'missing'      => true,
			];
		}

		$status = $product->get_status();
		$object = get_post_status_object( $status );

		return [
			'id'           => $product_id,
			'name'         => $product->get_name(),
			'status'       => $status,
			'status_label' => 'publish' === $status ? __( 'Published', 'subscription-pro' ) : ( $object ? $object->label : ucfirst( $status ) ),
			'edit_url'     => (string) get_edit_post_link( $product_id, 'raw' ),
			// A draft has no public page yet, so it opens as a preview.
			'view_url'     => (string) ( 'publish' === $status ? get_permalink( $product_id ) : get_preview_post_link( $product_id ) ),
			'image'        => (string) wp_get_attachment_image_url( (int) $product->get_image_id(), 'thumbnail' ),
			'missing'      => false,
		];
	}

	/**
	 * What still stops the box going on sale.
	 *
	 * @param Box $box Box.
	 *
	 * @return array[] Each entry: key (items|durations|product), title, text.
	 */
	public static function missing( Box $box ): array {
		$missing = [];

		$has_items = $box->is_customer_built() ? (bool) $box->pool_product_ids() : (bool) $box->curated_items();

		if ( ! $has_items ) {
			$missing[] = [
				'key'   => 'items',
				'title' => __( 'Add items to the box', 'subscription-pro' ),
				'text'  => $box->is_customer_built()
					? __( 'Customers have nothing to pick from.', 'subscription-pro' )
					: __( 'There is nothing to pack.', 'subscription-pro' ),
			];
		}

		if ( ! BoxDurations::offered( $box ) ) {
			$missing[] = [
				'key'   => 'durations',
				'title' => __( 'Add a duration', 'subscription-pro' ),
				'text'  => __( 'Customers need a delivery schedule to subscribe.', 'subscription-pro' ),
			];
		}

		$product = self::product( $box->id() );

		if ( ! $product || $product['missing'] ) {
			$missing[] = [
				'key'   => 'product',
				'title' => __( 'Link a product', 'subscription-pro' ),
				'text'  => __( 'A WooCommerce product is what customers buy.', 'subscription-pro' ),
			];
		}

		return $missing;
	}

	/**
	 * Create a draft product named for a box.
	 *
	 * @param string $name Product name.
	 *
	 * @return int|WP_Error Product id.
	 */
	public static function create_product( string $name ) {
		$product = new \WC_Product_Simple();

		$product->set_name( '' !== trim( $name ) ? $name : __( 'Subscription box', 'subscription-pro' ) );
		$product->set_status( 'draft' );
		$product->set_catalog_visibility( 'visible' );

		$product_id = $product->save();

		if ( ! $product_id ) {
			return new WP_Error( 'subscrpt_box_product_failed', __( 'The product could not be created.', 'subscription-pro' ), [ 'status' => 500 ] );
		}

		update_post_meta( $product_id, '_subscrpt_enabled', 'yes' );

		return (int) $product_id;
	}

	/**
	 * Make a product the one that sells a box.
	 *
	 * The product it replaces is set to Draft: its page would otherwise show a
	 * builder for a box it no longer sells. Subscriptions it already sold keep
	 * renewing with the box they were sold.
	 *
	 * @param Box $box        Box.
	 * @param int $product_id New product.
	 *
	 * @return true|WP_Error
	 */
	public static function link( Box $box, int $product_id ) {
		$product = wc_get_product( $product_id );

		if ( ! $product instanceof \WC_Product || $product->is_type( 'variation' ) ) {
			return new WP_Error( 'subscrpt_box_product_required', __( 'Pick a product to sell this box.', 'subscription-pro' ), [ 'status' => 400 ] );
		}

		$taken = BoxRepository::connections_for_product( $product_id );

		foreach ( $taken as $connection ) {
			if ( (int) $connection['box_id'] !== $box->id() ) {
				return new WP_Error(
					'subscrpt_box_product_taken',
					/* translators: %s: name of the other box. */
					sprintf( __( 'That product already sells "%s". Pick another, or create a new one.', 'subscription-pro' ), $connection['box_title'] ),
					[ 'status' => 400 ]
				);
			}
		}

		$current = self::product_id( $box->id() );

		if ( $current === $product_id ) {
			return true;
		}

		if ( $current ) {
			self::release( $box, $current );
		}

		BoxRepository::attach( $box->id(), $product_id );

		$box = BoxDurations::adopt( $box );
		BoxDurations::attach_product( $box, $product_id );

		// A box on sale puts its new product on sale too.
		if ( $box->is_active() && 'publish' !== $product->get_status() ) {
			self::set_product_status( $product_id, 'publish' );
		}

		return true;
	}

	/**
	 * Stop any product selling a box. The box stays.
	 *
	 * @param Box $box Box.
	 *
	 * @return void
	 */
	public static function unlink( Box $box ): void {
		$current = self::product_id( $box->id() );

		if ( $current ) {
			self::release( $box, $current );
		}
	}

	/**
	 * Put the box and its product on sale.
	 *
	 * @param Box $box Box.
	 *
	 * @return true|WP_Error A 400 carrying what is missing when it cannot go on sale.
	 */
	public static function publish( Box $box ) {
		$missing = self::missing( $box );

		if ( $missing ) {
			return new WP_Error(
				'subscrpt_box_not_ready',
				__( 'Finish setting up the box before publishing it.', 'subscription-pro' ),
				[
					'status'  => 400,
					'missing' => $missing,
				]
			);
		}

		self::set_box_status( $box, Box::STATUS_ACTIVE );
		self::set_product_status( self::product_id( $box->id() ), 'publish' );

		return true;
	}

	/**
	 * Take the box and its product off sale.
	 *
	 * @param Box $box Box.
	 *
	 * @return void
	 */
	public static function unpublish( Box $box ): void {
		self::set_box_status( $box, Box::STATUS_DRAFT );

		$product_id = self::product_id( $box->id() );

		if ( $product_id ) {
			self::set_product_status( $product_id, 'draft' );
		}
	}

	/**
	 * A draft copy of a box, with no product.
	 *
	 * Its durations are not copied: they belong to the product that sells the
	 * original, and a copy has none until one is linked.
	 *
	 * @param Box $box Box.
	 *
	 * @return int New box id.
	 */
	public static function duplicate( Box $box ): int {
		$data = $box->to_array();

		unset( $data['id'], $data['created_at'], $data['updated_at'] );

		/* translators: %s: name of the box copied. */
		$data['title']  = sprintf( __( '%s (copy)', 'subscription-pro' ), $box->title() );
		$data['status'] = Box::STATUS_DRAFT;
		$data['plans']  = [];

		return BoxRepository::save( $data );
	}

	/**
	 * How many subscriptions sold through a product still renew.
	 *
	 * @param int $product_id Product.
	 *
	 * @return int
	 */
	public static function live_subscriptions( int $product_id ): int {
		if ( ! $product_id ) {
			return 0;
		}

		$query = new \WP_Query(
			[
				'post_type'      => 'subscrpt_order',
				'post_status'    => self::LIVE_STATUSES,
				'fields'         => 'ids',
				'posts_per_page' => 1,
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
				'meta_query'     => [
					[
						'key'   => '_subscrpt_product_id',
						'value' => $product_id,
					],
				],
			]
		);

		return (int) $query->found_posts;
	}

	/**
	 * Delete a box, and trash or keep its product.
	 *
	 * A product with subscriptions still renewing is never trashed, whatever was
	 * asked: it is kept as a draft so those renewals have a product to bill.
	 *
	 * @param Box    $box     Box.
	 * @param string $product trash | draft.
	 *
	 * @return array{product:string} What happened to the product: trashed, drafted or none.
	 */
	public static function delete( Box $box, string $product ): array {
		$product_id = self::product_id( $box->id() );
		$outcome    = 'none';

		if ( $product_id && wc_get_product( $product_id ) ) {
			BoxDurations::detach_product( $box, $product_id );

			if ( 'trash' === $product && ! self::live_subscriptions( $product_id ) ) {
				wp_trash_post( $product_id );
				$outcome = 'trashed';
			} else {
				self::set_product_status( $product_id, 'draft' );
				$outcome = 'drafted';
			}
		}

		BoxDurations::retire( $box );
		BoxRepository::delete( $box->id() );

		return [ 'product' => $outcome ];
	}

	/**
	 * Unhook a product from a box and set it to Draft.
	 *
	 * @param Box $box        Box.
	 * @param int $product_id Product.
	 *
	 * @return void
	 */
	private static function release( Box $box, int $product_id ): void {
		BoxDurations::detach_product( $box, $product_id );

		foreach ( BoxRepository::connections_for_box( $box->id() ) as $connection ) {
			BoxRepository::detach( (int) $connection['id'] );
		}

		if ( wc_get_product( $product_id ) ) {
			self::set_product_status( $product_id, 'draft' );
		}
	}

	/**
	 * Change only a box's status.
	 *
	 * @param Box    $box    Box.
	 * @param string $status Status.
	 *
	 * @return void
	 */
	private static function set_box_status( Box $box, string $status ): void {
		$data           = $box->to_array();
		$data['status'] = $status;

		BoxRepository::save( $data );
	}

	/**
	 * Change only a product's status.
	 *
	 * @param int    $product_id Product.
	 * @param string $status     publish | draft.
	 *
	 * @return void
	 */
	private static function set_product_status( int $product_id, string $status ): void {
		$product = wc_get_product( $product_id );

		if ( $product instanceof \WC_Product && $product->get_status() !== $status ) {
			$product->set_status( $status );
			$product->save();
		}
	}
}
