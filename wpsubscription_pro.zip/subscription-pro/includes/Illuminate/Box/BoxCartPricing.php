<?php
/**
 * Prices a box line in the cart by what is in it.
 *
 * A box priced by its contents (`sum`) replaces whatever its plan or product
 * says with a quote from BoxPricing. A `fixed` box keeps its price.
 *
 * Items that ship in the first box only are charged once, as a cart fee of
 * their own: a fee is paid with the first order and never renewed. They are
 * goods, so the fee is taxed as the box product is, as the box line taxes
 * them when a renewal ships them. Under `sum` the line is priced by
 * BoxPricing::quote_charged(): it renews at the quote of what recurs alone,
 * and the once amount is the first box's quote less that, never below 0;
 * under `fixed` once items cost their own price.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Box
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Box;

defined( 'ABSPATH' ) || exit;

/**
 * Cart pricing for boxes priced by their contents.
 */
class BoxCartPricing {

	/**
	 * Hook into the cart.
	 *
	 * Priority 15 runs before PlanCheckout::set_cart_item_price() at 20, so the
	 * plan code applies the struck-through display and the trial rule to the
	 * quote it finds. Priority 30 then prices the lines no plan touched.
	 */
	public function __construct() {
		add_action( 'woocommerce_before_calculate_totals', [ $this, 'price_box_lines' ], 15 );
		add_action( 'woocommerce_before_calculate_totals', [ $this, 'price_planless_box_lines' ], 30 );
		add_action( 'woocommerce_cart_calculate_fees', [ $this, 'add_once_fees' ] );

		// After PaymentGateways' own filtering at 99.
		add_filter( 'woocommerce_available_payment_gateways', [ $this, 'withhold_varying_amount_gateways' ], 100 );
	}

	/**
	 * The keys of `subscrpt_box` that keep what pricing replaced, so it can be put back.
	 */
	const BASE_KEYS = [
		'base_plan_price'   => 'subscrpt_plan_price',
		'base_plan_regular' => 'subscrpt_plan_regular',
	];

	/**
	 * Quote every box line and write the quote where the plan code reads it.
	 *
	 * A `sum` line takes the renewal quote as its price; a `fixed` line keeps
	 * its price. Either way what ships once is kept on the line for
	 * add_once_fees(). A line whose box is gone goes back to the price it came
	 * with.
	 *
	 * @param \WC_Cart $cart Cart.
	 *
	 * @return void
	 */
	public function price_box_lines( $cart ) {
		if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
			return;
		}

		foreach ( $cart->get_cart() as $key => $cart_item ) {
			if ( ! isset( $cart_item[ BoxCart::CART_KEY ] ) || ! is_array( $cart_item[ BoxCart::CART_KEY ] ) ) {
				continue;
			}

			$box  = $this->box_of( $cart_item );
			$line = &$cart->cart_contents[ $key ];

			if ( ! $box ) {
				// A box that is gone charges nothing of its own: no quote, no once items.
				self::restore_price( $line );
				self::charge_once( $line, 0.0 );
				unset( $line );
				continue;
			}

			list( $recurring, $once ) = self::split( $line );

			if ( BoxPricing::STRATEGY_SUM === $box->pricing()['strategy'] ) {
				$quote = BoxPricing::quote_charged( $box, $recurring, $once );

				self::write_quote( $line, $quote );
				self::charge_once( $line, (float) $quote['once'] );
			} else {
				// A box switched back to fixed must not keep the quote its session remembers.
				self::restore_price( $line );
				self::charge_once( $line, self::list_price( $once ) );
			}

			unset( $line );
		}
	}

	/**
	 * Put a `sum` quote on a line, keeping what it replaces.
	 *
	 * @param array $line  Cart line, by reference.
	 * @param array $quote Output of BoxPricing::quote().
	 *
	 * @return void
	 */
	private static function write_quote( array &$line, array $quote ): void {
		$line[ BoxCart::CART_KEY ]['quote'] = $quote;

		if ( isset( $line['subscrpt_plan_price'] ) ) {
			foreach ( self::BASE_KEYS as $base => $field ) {
				if ( ! array_key_exists( $base, $line[ BoxCart::CART_KEY ] ) && array_key_exists( $field, $line ) ) {
					$line[ BoxCart::CART_KEY ][ $base ] = $line[ $field ];
				}
			}

			// The box's own discount replaces the plan's, so the regular price is the undiscounted contents.
			$line['subscrpt_plan_price']   = $quote['recurring'];
			$line['subscrpt_plan_regular'] = self::regular( $quote );
		}

		if ( isset( $line['subscription'] ) && is_array( $line['subscription'] ) ) {
			if ( ! array_key_exists( 'base_per_cost', $line[ BoxCart::CART_KEY ] ) && array_key_exists( 'per_cost', $line['subscription'] ) ) {
				$line[ BoxCart::CART_KEY ]['base_per_cost'] = $line['subscription']['per_cost'];
			}

			$line['subscription']['per_cost'] = $quote['recurring'];
		}
	}

	/**
	 * Take a `sum` quote off a line and give it back the price it came with.
	 *
	 * @param array $line Cart line, by reference.
	 *
	 * @return void
	 */
	private static function restore_price( array &$line ): void {
		unset( $line[ BoxCart::CART_KEY ]['quote'] );

		foreach ( self::BASE_KEYS as $base => $field ) {
			if ( array_key_exists( $base, $line[ BoxCart::CART_KEY ] ) ) {
				$line[ $field ] = $line[ BoxCart::CART_KEY ][ $base ];
				unset( $line[ BoxCart::CART_KEY ][ $base ] );
			}
		}

		if ( array_key_exists( 'base_per_cost', $line[ BoxCart::CART_KEY ] ) ) {
			if ( isset( $line['subscription'] ) && is_array( $line['subscription'] ) ) {
				$line['subscription']['per_cost'] = $line[ BoxCart::CART_KEY ]['base_per_cost'];
			}

			unset( $line[ BoxCart::CART_KEY ]['base_per_cost'] );
		}
	}

	/**
	 * Keep what ships once on the line, for add_once_fees() to charge.
	 *
	 * Each box in the line ships the once items, so they are charged per box.
	 * The signup fee stays the product's own: a line priced before once items
	 * left it carries the product's fee in `base_signup_fee`, and gets it back.
	 *
	 * @param array $line Cart line, by reference.
	 * @param float $once What one box's once items cost.
	 *
	 * @return void
	 */
	private static function charge_once( array &$line, float $once ): void {
		if ( ! isset( $line['subscription'] ) || ! is_array( $line['subscription'] ) ) {
			return;
		}

		if ( array_key_exists( 'base_signup_fee', $line[ BoxCart::CART_KEY ] ) ) {
			$line['subscription']['signup_fee'] = $line[ BoxCart::CART_KEY ]['base_signup_fee'];
			unset( $line[ BoxCart::CART_KEY ]['base_signup_fee'] );
		}

		if ( $once <= 0 ) {
			unset( $line[ BoxCart::CART_KEY ]['once_charge'] );

			return;
		}

		$boxes = max( 1, (int) ( $line['quantity'] ?? 1 ) );

		$line[ BoxCart::CART_KEY ]['once_charge'] = self::round( $once * $boxes );
	}

	/**
	 * Charge each box line's once items as a fee of its own.
	 *
	 * The fee is taxed as the box product is, in its tax class. WooCommerce
	 * adds a fee's tax on top of it, so where prices include tax the fee is
	 * the shown amount less the tax in it: the customer pays exactly the
	 * "First box" amount they were shown.
	 *
	 * @param \WC_Cart $cart Cart.
	 *
	 * @return void
	 */
	public function add_once_fees( $cart ) {
		foreach ( $cart->get_cart() as $key => $cart_item ) {
			$amount  = (float) ( $cart_item[ BoxCart::CART_KEY ]['once_charge'] ?? 0 );
			$product = $cart_item['data'] ?? null;

			if ( $amount <= 0 || ! $product instanceof \WC_Product ) {
				continue;
			}

			$taxable   = $product->is_taxable();
			$tax_class = $product->get_tax_class();

			if ( $taxable && wc_prices_include_tax() ) {
				$amount -= array_sum( \WC_Tax::calc_inclusive_tax( $amount, \WC_Tax::get_rates( $tax_class, $cart->get_customer() ) ) );
			}

			$cart->fees_api()->add_fee(
				[
					'id'        => 'subscrpt-box-once-' . $key,
					/* translators: %s: box product name. */
					'name'      => sprintf( __( 'Items in the first %s only', 'subscription-pro' ), $product->get_name() ),
					'amount'    => $amount,
					'taxable'   => $taxable,
					'tax_class' => $tax_class,
				]
			);
		}
	}

	/**
	 * Split a line's picks into what recurs and what ships once.
	 *
	 * A line with no subscription never renews, so all of it is one purchase
	 * and nothing is set apart.
	 *
	 * @param array $line Cart line.
	 *
	 * @return array[] `[ recurring, once ]`, both normalise_items() rows.
	 */
	private static function split( array $line ): array {
		$items = $line[ BoxCart::CART_KEY ]['items'] ?? [];

		if ( ! isset( $line['subscription'] ) || ! is_array( $line['subscription'] ) ) {
			return [ BoxProduct::normalise_items( $items ), [] ];
		}

		return BoxProduct::split_once( is_array( $items ) ? $items : [] );
	}

	/**
	 * What items cost at their own prices, with no box discount.
	 *
	 * @param array $items normalise_items() rows.
	 *
	 * @return float
	 */
	private static function list_price( array $items ): float {
		$total = 0.0;

		foreach ( $items as $item ) {
			$total += BoxPricing::item_price( (int) $item['product_id'], (int) $item['variation_id'] ) * (int) $item['qty'];
		}

		return self::round( $total );
	}

	/**
	 * Charge the quote on a `sum` box line that has no plan to carry it.
	 *
	 * @param \WC_Cart $cart Cart.
	 *
	 * @return void
	 */
	public function price_planless_box_lines( $cart ) {
		if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
			return;
		}

		foreach ( $cart->get_cart() as $cart_item ) {
			$quote = $cart_item[ BoxCart::CART_KEY ]['quote'] ?? null;

			if ( empty( $quote['is_sum'] ) || isset( $cart_item['subscrpt_plan_price'] ) || ! isset( $cart_item['data'] ) ) {
				continue;
			}

			$regular = self::regular( $quote );

			$cart_item['data']->set_regular_price( $regular );
			$cart_item['data']->set_sale_price( $quote['recurring'] < $regular ? $quote['recurring'] : '' );
			$cart_item['data']->set_price( $quote['recurring'] );
		}
	}

	/**
	 * Take away the gateways that bill a fixed amount when the cart has a box whose amount they would miss.
	 *
	 * A box priced by its contents moves with what is in it, and PayPal's
	 * agreement does not. A box that ships items once charges them as a cart
	 * fee, and PayPal's agreement charges only the product's own signup fee.
	 *
	 * @param array $gateways Available gateways, keyed by id.
	 *
	 * @return array
	 */
	public function withhold_varying_amount_gateways( $gateways ) {
		if ( ! is_array( $gateways ) || ! $this->cart_has_varying_box() ) {
			return $gateways;
		}

		/**
		 * Filters which gateway ids are withheld from a cart holding a box priced by
		 * its contents, or a subscription box that ships items once.
		 *
		 * @param string[] $gateway_ids Gateway ids to withhold. Default: PayPal only.
		 * @param array    $gateways    Available gateways before this pass.
		 */
		$withheld = (array) apply_filters( 'subscrpt_box_varying_amount_incompatible_gateways', [ 'wp_subscription_paypal' ], $gateways );

		foreach ( $withheld as $gateway_id ) {
			unset( $gateways[ $gateway_id ] );
		}

		return $gateways;
	}

	/**
	 * Does the cart hold a box priced by its contents, or a subscription box that ships items once?
	 *
	 * @return bool
	 */
	private function cart_has_varying_box(): bool {
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return false;
		}

		foreach ( WC()->cart->get_cart() as $cart_item ) {
			if ( ! empty( $cart_item[ BoxCart::CART_KEY ]['quote']['is_sum'] ) ) {
				return true;
			}

			if ( isset( $cart_item[ BoxCart::CART_KEY ] ) && self::split( $cart_item )[1] ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * What the box would cost with no box discount.
	 *
	 * @param array $quote Output of BoxPricing::quote().
	 *
	 * @return float
	 */
	private static function regular( array $quote ): float {
		$decimals = function_exists( 'wc_get_price_decimals' ) ? (int) wc_get_price_decimals() : 2;

		return round( (float) $quote['base'] + (float) $quote['subtotal_recurring'], $decimals ) + 0.0;
	}

	/**
	 * Round money to the store's decimals.
	 *
	 * @param float $amount Amount.
	 *
	 * @return float
	 */
	private static function round( float $amount ): float {
		$decimals = function_exists( 'wc_get_price_decimals' ) ? (int) wc_get_price_decimals() : 2;

		return round( $amount, $decimals ) + 0.0;
	}

	/**
	 * The box a cart line sells.
	 *
	 * @param array $cart_item Cart line.
	 *
	 * @return Box|null Null for a line that is not a box.
	 */
	private function box_of( array $cart_item ): ?Box {
		$box_id = (int) ( $cart_item[ BoxCart::CART_KEY ]['box_id'] ?? 0 );

		if ( ! $box_id ) {
			return null;
		}

		return BoxProduct::resolve( (int) ( $cart_item['product_id'] ?? 0 ), (int) ( $cart_item['variation_id'] ?? 0 ), $box_id );
	}
}
