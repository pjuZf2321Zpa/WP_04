<?php
/**
 * Health queue reminder email.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Emails
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Emails;

use SpringDevs\SubscriptionPro\Illuminate\Health\HealthEngine;
use WC_Email;

/**
 * Health Queue Reminder Email.
 *
 * Sent to the store admin on a scheduled basis when subscriptions are in the health queue.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Emails
 */
class HealthQueueReminder extends WC_Email {

	/**
	 * Number of subscriptions in the health queue.
	 *
	 * @var int
	 */
	public int $queue_count = 0;

	/**
	 * Total revenue at risk.
	 *
	 * @var float
	 */
	public float $revenue_at_risk = 0.0;

	/**
	 * URL to the health page.
	 *
	 * @var string
	 */
	public string $health_page_url = '';

	/**
	 * Initialize the class.
	 */
	public function __construct() {
		$this->id          = 'subscrpt_health_queue_reminder';
		$this->title       = __( 'Subscription Health Reminder', 'subscription-pro' );
		$this->description = __( 'Sent to the store admin on a schedule when subscriptions need attention in the health queue.', 'subscription-pro' );

		// Admin-only email — not a customer email.
		$this->customer_email = false;

		// Default recipient before parent reads saved settings.
		$this->recipient = $this->get_default_recipient();

		parent::__construct();

		// Override template paths to use pro plugin templates.
		$this->template_base  = WP_SUBSCRIPTION_PRO_TEMPLATES;
		$this->template_html  = 'emails/health-queue-reminder-html.php';
		$this->template_plain = 'emails/plains/health-queue-reminder-plain.php';
	}

	/**
	 * Add a recipient field to the WooCommerce email settings panel.
	 *
	 * @return void
	 */
	public function init_form_fields(): void {
		parent::init_form_fields();

		$this->form_fields['recipient'] = array(
			'title'       => __( 'Recipient(s)', 'subscription-pro' ),
			'type'        => 'text',
			'description' => __( 'Enter recipients (comma-separated) for this email. Defaults to the WooCommerce store email.', 'subscription-pro' ),
			'placeholder' => $this->get_default_recipient(),
			'default'     => '',
			'desc_tip'    => true,
		);
	}

	/**
	 * Get default subject.
	 *
	 * @return string
	 */
	public function get_default_subject(): string {
		return __( 'Subscription Health Reminder - {queue_count} subscription(s) need attention', 'subscription-pro' );
	}

	/**
	 * Get default heading.
	 *
	 * @return string
	 */
	public function get_default_heading(): string {
		return __( 'Subscription Health Reminder', 'subscription-pro' );
	}

	/**
	 * Get the admin recipient address.
	 *
	 * Prefers WooCommerce store email; falls back to WordPress admin email.
	 *
	 * @return string
	 */
	public function get_default_recipient(): string {
		$wc_email = get_option( 'woocommerce_email_from_address' );
		return ! empty( $wc_email ) ? $wc_email : get_option( 'admin_email' );
	}

	/**
	 * Get email subject with resolved placeholders.
	 *
	 * @return string
	 */
	public function get_subject(): string {
		$subject = parent::get_subject();
		return str_replace( '{queue_count}', (string) $this->queue_count, $subject );
	}

	/**
	 * Get the HTML email content.
	 *
	 * @return string
	 */
	public function get_content_html(): string {
		return wc_get_template_html(
			$this->template_html,
			array(
				'email_heading'   => $this->get_heading(),
				'queue_count'     => $this->queue_count,
				'revenue_at_risk' => wc_price( $this->revenue_at_risk ),
				'health_page_url' => $this->health_page_url,
				'email'           => $this,
			),
			'',
			$this->template_base
		);
	}

	/**
	 * Get the plain-text email content.
	 *
	 * @return string
	 */
	public function get_content_plain(): string {
		return wc_get_template_html(
			$this->template_plain,
			array(
				'email_heading'   => $this->get_heading(),
				'queue_count'     => $this->queue_count,
				'revenue_at_risk' => wc_price( $this->revenue_at_risk ),
				'health_page_url' => $this->health_page_url,
				'email'           => $this,
			),
			'',
			$this->template_base
		);
	}

	/**
	 * Trigger the health queue reminder email.
	 *
	 * Fetches the current health queue, skips sending if the queue is empty,
	 * and delivers the summary to the store admin.
	 *
	 * @return bool True if email was sent, false if skipped or disabled.
	 */
	public function trigger(): bool {
		if ( ! $this->is_enabled() ) {
			return false;
		}

		$subscriptions = HealthEngine::get_broken_subscriptions( 'all' );

		if ( empty( $subscriptions ) ) {
			return false;
		}

		$this->queue_count     = count( $subscriptions );
		$this->revenue_at_risk = HealthEngine::get_revenue_at_risk( $subscriptions );
		$this->health_page_url = admin_url( 'admin.php?page=wp-subscription-health' );
		// Use saved recipient field; fall back to store/admin email.
		$saved           = $this->get_option( 'recipient' );
		$this->recipient = ! empty( $saved ) ? $saved : $this->get_default_recipient();

		$this->setup_locale();
		$result = $this->send(
			$this->recipient,
			$this->get_subject(),
			$this->get_content(),
			$this->get_headers(),
			$this->get_attachments()
		);
		$this->restore_locale();

		return (bool) $result;
	}
}
