<?php
/**
 * "Your next box" — sent before the box locks.
 *
 * This is the email the whole edit window hangs on: it tells a subscriber what
 * is coming, what it costs, and by when they can change it. It also satisfies
 * Mollie's advice to tell customers the amount before each charge.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Emails
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Emails;

use SpringDevs\Subscription\Illuminate\Subscription\Subscription;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxCart;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxOrder;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxSubscription;
use SpringDevs\SubscriptionPro\Traits\Email;
use WC_Email;

defined( 'ABSPATH' ) || exit;

/**
 * The upcoming-box email.
 */
class UpcomingBox extends WC_Email {

	use Email;

	/**
	 * Initialize the class.
	 */
	public function __construct() {
		$this->customer_email = true;

		$this->id          = 'subscrpt_upcoming_box';
		$this->title       = __( 'Upcoming subscription box', 'subscription-pro' );
		$this->description = __( 'Sent to a box subscriber before their next box locks, listing what it holds and when it can no longer be changed.', 'subscription-pro' );

		parent::__construct();

		// Set the template paths directly rather than through `set_template()`.
		// That helper only knows the ids in the free plugin's own map, and the
		// pro trait's constructor — which would merge pro's ids in — never runs,
		// because this class defines a constructor of its own. Asking it for an
		// unknown id leaves the paths null and the first send fatals.
		$this->template_base  = WP_SUBSCRIPTION_PRO_TEMPLATES;
		$this->template_html  = 'emails/upcoming-box-html.php';
		$this->template_plain = 'emails/plains/upcoming-box-plain.php';

		add_action( 'subscrpt_box_notice_email_notification', array( $this, 'trigger' ) );
	}

	/**
	 * Get the email content in HTML format.
	 *
	 * @return string
	 */
	public function get_content_html(): string {
		return $this->render_template( $this->template_html );
	}

	/**
	 * Get the email content in plain text.
	 *
	 * @return string
	 */
	public function get_content_plain(): string {
		return $this->render_template( $this->template_plain );
	}

	/**
	 * Get default subject.
	 *
	 * @return string
	 */
	public function get_default_subject(): string {
		return __( 'Your next box is on its way — #{subscription_id}', 'subscription-pro' );
	}

	/**
	 * Get default heading.
	 *
	 * @return string
	 */
	public function get_default_heading(): string {
		return __( 'Your next box', 'subscription-pro' );
	}

	/**
	 * The subscriber.
	 *
	 * @return string
	 */
	public function get_recipient(): string {
		return (string) get_the_author_meta( 'email', (int) get_post_field( 'post_author', $this->subscription_id ) );
	}

	/**
	 * Send it.
	 *
	 * @param int $subscription_id Subscription id.
	 *
	 * @return void
	 */
	public function trigger( int $subscription_id ): void {
		if ( 'no' === $this->enabled || ! BoxSubscription::is_box( $subscription_id ) ) {
			return;
		}

		$this->placeholders['{subscription_id}'] = $subscription_id;
		$this->subscription_id                   = $subscription_id;

		$next_date = (int) get_post_meta( $subscription_id, '_subscrpt_next_date', true );
		$lock      = BoxSubscription::lock_timestamp( $subscription_id );
		$contents  = BoxSubscription::contents( $subscription_id );

		$view_url = wc_get_endpoint_url(
			Subscription::get_user_endpoint( 'view_subs' ),
			$subscription_id,
			wc_get_page_permalink( 'myaccount' )
		);

		$this->extra = array(
			'box_contents'      => $contents,
			'box_summary'       => BoxCart::contents_summary( $contents ),
			'box_lock_date'     => $lock ? date_i18n( get_option( 'date_format' ), $lock ) : '',
			'box_next_date'     => $next_date ? date_i18n( get_option( 'date_format' ), $next_date ) : '',
			'box_can_edit'      => BoxSubscription::can_edit( $subscription_id ),
			'box_edit_url'      => add_query_arg( 'subscrpt_box', 'edit', $view_url ) . '#subscrpt-box',
			'box_customer_name' => $this->get_customer_name(),
		);

		$this->set_table_data();

		// What the next renewal charges for this box, when it ships items the
		// recurring amount below does not cover.
		$this_box = BoxOrder::upcoming_amount( $subscription_id, max( 1, (int) $this->qty ) );

		$this->extra['box_this_amount'] = null === $this_box ? '' : html_entity_decode( wp_strip_all_tags( wc_price( $this_box ) ), ENT_QUOTES, 'UTF-8' );

		$sent = $this->send( $this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() );

		if ( $sent && $next_date ) {
			// Marked with the renewal date, not a flag: skipping a box moves
			// that date, and the new box deserves its own email.
			update_post_meta( $subscription_id, BoxSubscription::META_NOTIFIED, $next_date );
		}
	}

	/**
	 * The subscriber's display name.
	 *
	 * @return string
	 */
	public function get_customer_name(): string {
		$user_id = (int) get_post_field( 'post_author', $this->subscription_id );
		$user    = $user_id ? get_userdata( $user_id ) : null;

		return $user ? $user->display_name : '';
	}
}
