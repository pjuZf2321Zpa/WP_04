<?php
/**
 * Base class for admin-facing subscription status emails.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Emails
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Emails;

use SpringDevs\Subscription\Illuminate\Helper as FreeHelper;
use WC_Email;

/**
 * Shared behaviour for the "subscription cancelled / expired" store owner emails.
 *
 * Subclasses set the id, title, description and template paths, hook their
 * `trigger()` to the proper notification action, and supply the intro sentence
 * plus any status-specific summary rows.
 */
abstract class AdminSubscriptionStatusEmail extends WC_Email {

	/**
	 * Subscription post ID the mail is about.
	 *
	 * @var int
	 */
	public int $subscription_id = 0;

	/**
	 * Initialize the class.
	 */
	public function __construct() {
		// Admin-only email — not a customer email.
		$this->customer_email = false;

		// Default recipient before parent reads saved settings.
		$this->recipient = $this->get_default_recipient();

		parent::__construct();

		$this->template_base = WP_SUBSCRIPTION_PRO_TEMPLATES;
	}

	/**
	 * Opening sentence of the mail.
	 *
	 * @return string
	 */
	abstract protected function get_intro(): string;

	/**
	 * Status-specific summary rows, appended after the common ones.
	 *
	 * @return array<string,string> Label => value, values are plain text.
	 */
	abstract protected function get_status_rows(): array;

	/**
	 * Free-text block rendered below the summary table, e.g. a customer comment.
	 *
	 * @return array{label:string,text:string}|null
	 */
	protected function get_note(): ?array {
		return null;
	}

	/**
	 * Add a recipient field to the WooCommerce email settings panel.
	 *
	 * @return void
	 */
	public function init_form_fields(): void {
		parent::init_form_fields();

		unset( $this->form_fields['additional_content'] );

		$this->form_fields['recipient'] = [
			'title'       => __( 'Recipient(s)', 'subscription-pro' ),
			'type'        => 'text',
			'description' => __( 'Enter recipients (comma-separated) for this email. Defaults to the WooCommerce store email.', 'subscription-pro' ),
			'placeholder' => $this->get_default_recipient(),
			'default'     => '',
			'desc_tip'    => true,
		];
	}

	/**
	 * Get the admin recipient address.
	 *
	 * Prefers WooCommerce store email; falls back to WordPress admin email.
	 *
	 * @return string
	 */
	public function get_default_recipient(): string {
		$wc_email = get_option( 'woocommerce_email_from_address' );
		return ! empty( $wc_email ) ? $wc_email : get_option( 'admin_email' );
	}

	/**
	 * Get the HTML email content.
	 *
	 * @return string
	 */
	public function get_content_html(): string {
		return wc_get_template_html( $this->template_html, $this->get_template_vars(), '', $this->template_base );
	}

	/**
	 * Get the plain-text email content.
	 *
	 * @return string
	 */
	public function get_content_plain(): string {
		return wc_get_template_html( $this->template_plain, $this->get_template_vars(), '', $this->template_base );
	}

	/**
	 * Trigger the email for a subscription.
	 *
	 * @param int $subscription_id Subscription post ID.
	 *
	 * @return void
	 */
	public function trigger( int $subscription_id ) {
		if ( ! $subscription_id || ! $this->is_enabled() ) {
			return;
		}

		$this->subscription_id                   = $subscription_id;
		$this->placeholders['{subscription_id}'] = (string) $subscription_id;

		$saved           = $this->get_option( 'recipient' );
		$this->recipient = ! empty( $saved ) ? $saved : $this->get_default_recipient();

		if ( empty( $this->recipient ) ) {
			return;
		}

		$this->setup_locale();
		$this->send( $this->recipient, $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() );
		$this->restore_locale();
	}

	/**
	 * Customer display name for the subscription this mail is about.
	 *
	 * @return string
	 */
	protected function get_customer_name(): string {
		$user_id = (int) get_post_field( 'post_author', $this->subscription_id );
		$user    = $user_id ? get_userdata( $user_id ) : null;

		return $user ? $user->display_name : '';
	}

	/**
	 * Build template variables shared by the HTML and plain templates.
	 *
	 * @return array
	 */
	protected function get_template_vars(): array {
		$subscription_id = $this->subscription_id;
		$user_id         = (int) get_post_field( 'post_author', $subscription_id );
		$user            = $user_id ? get_userdata( $user_id ) : null;
		$customer_name   = $user ? $user->display_name : '';
		$customer_email  = $user ? $user->user_email : '';

		$rows = [
			[
				'label' => __( 'Subscription', 'subscription-pro' ),
				'value' => '#' . $subscription_id,
			],
			[
				'label' => __( 'Customer', 'subscription-pro' ),
				'value' => $customer_name,
				'email' => $customer_email,
			],
			[
				'label' => __( 'Product', 'subscription-pro' ),
				'value' => $this->get_product_label(),
			],
			[
				'label' => __( 'Amount', 'subscription-pro' ),
				'value' => $this->get_amount(),
			],
			[
				'label' => __( 'Started', 'subscription-pro' ),
				'value' => $this->format_date_meta( '_subscrpt_start_date' ),
			],
		];

		foreach ( $this->get_status_rows() as $label => $value ) {
			$rows[] = [
				'label' => $label,
				'value' => $value,
			];
		}

		// Drop rows with nothing worth printing.
		$rows = array_values(
			array_filter(
				$rows,
				function ( $row ) {
					return '' !== $row['value'] || ! empty( $row['email'] );
				}
			)
		);

		return [
			'email'                 => $this,
			'email_heading'         => $this->get_heading(),
			'intro'                 => $this->get_intro(),
			'subscription_id'       => $subscription_id,
			'customer_name'         => $customer_name,
			'customer_email'        => $customer_email,
			'summary_rows'          => $rows,
			'note'                  => $this->get_note(),
			'edit_subscription_url' => admin_url( 'admin.php?page=wp-subscription-details&id=' . $subscription_id ),
		];
	}

	/**
	 * Product name with quantity appended when it is more than one.
	 *
	 * @return string
	 */
	protected function get_product_label(): string {
		$order_item = $this->get_order_item();

		$name = $order_item ? $order_item->get_name() : '';
		if ( ! $name ) {
			$product_id = (int) get_post_meta( $this->subscription_id, '_subscrpt_product_id', true );
			$product    = $product_id ? wc_get_product( $product_id ) : null;
			$name       = $product ? $product->get_name() : __( 'Subscription', 'subscription-pro' );
		}

		$qty = $order_item ? (int) $order_item->get_quantity() : 0;

		return $qty > 1 ? $name . ' × ' . $qty : $name;
	}

	/**
	 * Recurring amount in text form — these mails also render as plain text.
	 *
	 * @return string
	 */
	protected function get_amount(): string {
		$amount = FreeHelper::get_subscription_recurring_price_text( $this->subscription_id, $this->get_order_item() );

		if ( ! $amount ) {
			$price  = (float) get_post_meta( $this->subscription_id, '_subscrpt_price', true );
			$amount = wc_price( $price );
		}

		// Currency symbols arrive HTML-encoded (`&#036;`); decode so the plain-text mail reads cleanly.
		return html_entity_decode( wp_strip_all_tags( (string) $amount ), ENT_QUOTES, 'UTF-8' );
	}

	/**
	 * Format a timestamp meta value with the site date format.
	 *
	 * @param string $meta_key Post meta key holding a timestamp.
	 *
	 * @return string Formatted date, or an empty string when unset.
	 */
	protected function format_date_meta( string $meta_key ): string {
		$timestamp = (int) get_post_meta( $this->subscription_id, $meta_key, true );

		return $timestamp > 0 ? wp_date( get_option( 'date_format' ), $timestamp ) : '';
	}

	/**
	 * Get the order item the subscription was created from.
	 *
	 * @return \WC_Order_Item_Product|false|null
	 */
	protected function get_order_item() {
		static $cache = [];

		if ( array_key_exists( $this->subscription_id, $cache ) ) {
			return $cache[ $this->subscription_id ];
		}

		$order_item_id = get_post_meta( $this->subscription_id, '_subscrpt_order_item_id', true );
		$order         = $order_item_id ? wc_get_order( wc_get_order_id_by_order_item_id( $order_item_id ) ) : null;

		$cache[ $this->subscription_id ] = $order ? $order->get_item( $order_item_id ) : null;

		return $cache[ $this->subscription_id ];
	}
}
