<?php
/**
 * Subscription cancelled email for the store owner.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Emails
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Emails;

use SpringDevs\Subscription\Illuminate\Cancellation;

/**
 * Mail sent to the store owner when a subscription is cancelled.
 *
 * Sent immediately, on the same free plugin action that notifies the customer.
 */
class SubscriptionCancelledAdmin extends AdminSubscriptionStatusEmail {

	/**
	 * Initialize the class.
	 */
	public function __construct() {
		$this->id          = 'subscrpt_subscription_cancelled_admin';
		$this->title       = __( 'Subscription cancelled ( Admin )', 'subscription-pro' );
		$this->description = __( 'Sent to the store owner when a subscription is cancelled.', 'subscription-pro' );

		// A customer's confirm puts an active subscription into `pe_cancelled`, and
		// the cron only finalises it to `cancelled` up to a day later. Listen to
		// both so the store owner hears at the moment of cancellation, and let
		// `trigger()` make sure only the first of the two actually sends.
		add_action( 'subscrpt_subscription_pending_cancellation', [ $this, 'trigger' ] );
		add_action( 'subscrpt_subscription_cancelled_email_notification', [ $this, 'trigger' ] );

		// A reactivated subscription can be cancelled again, and should mail again.
		add_action( 'subscrpt_subscription_resumed', [ $this, 'clear_sent_flag' ] );

		parent::__construct();

		$this->template_html  = 'emails/subscription-cancelled-admin-html.php';
		$this->template_plain = 'emails/plains/subscription-cancelled-admin-plain.php';
	}

	/**
	 * Post meta marking that the store owner has already been told about this
	 * cancellation, so the `pe_cancelled` and `cancelled` steps cannot both mail.
	 */
	const SENT_FLAG = '_subscrpt_cancel_admin_emailed';

	/**
	 * Send once per cancellation, at whichever step comes first.
	 *
	 * @param int $subscription_id Subscription post ID.
	 *
	 * @return void
	 */
	public function trigger( int $subscription_id ) {
		if ( $subscription_id && get_post_meta( $subscription_id, self::SENT_FLAG, true ) ) {
			return;
		}

		parent::trigger( $subscription_id );

		if ( $subscription_id ) {
			update_post_meta( $subscription_id, self::SENT_FLAG, '1' );
		}
	}

	/**
	 * Let a resumed subscription be reported again if it is cancelled a second time.
	 *
	 * @param int $subscription_id Subscription post ID.
	 *
	 * @return void
	 */
	public function clear_sent_flag( $subscription_id ) {
		delete_post_meta( (int) $subscription_id, self::SENT_FLAG );
	}

	/**
	 * Get default subject.
	 *
	 * @return string
	 */
	public function get_default_subject(): string {
		return __( '[{site_title}] Subscription #{subscription_id} cancelled', 'subscription-pro' );
	}

	/**
	 * Get default heading.
	 *
	 * @return string
	 */
	public function get_default_heading(): string {
		return __( 'Subscription cancelled', 'subscription-pro' );
	}

	/**
	 * Opening sentence of the mail.
	 *
	 * @return string
	 */
	protected function get_intro(): string {
		$name = $this->get_customer_name();

		if ( $name ) {
			/* translators: %s: customer name */
			return sprintf( __( '%s cancelled a subscription. Recurring revenue for it stops here.', 'subscription-pro' ), $name );
		}

		return __( 'A subscription was cancelled. Recurring revenue for it stops here.', 'subscription-pro' );
	}

	/**
	 * Cancellation specific summary rows.
	 *
	 * @return array<string,string>
	 */
	protected function get_status_rows(): array {
		$feedback = $this->get_feedback();

		$cancelled_at = ! empty( $feedback['created_at'] )
			? wp_date( get_option( 'date_format' ), strtotime( $feedback['created_at'] ) )
			: wp_date( get_option( 'date_format' ) );

		return [
			__( 'Cancelled on', 'subscription-pro' ) => (string) $cancelled_at,
			__( 'Reason given', 'subscription-pro' ) => isset( $feedback['reason_label'] ) ? (string) $feedback['reason_label'] : '',
		];
	}

	/**
	 * Show the customer's free-text cancellation comment when there is one.
	 *
	 * @return array{label:string,text:string}|null
	 */
	protected function get_note(): ?array {
		$feedback = $this->get_feedback();

		if ( empty( $feedback['comment'] ) ) {
			return null;
		}

		return [
			'label' => __( 'What the customer wrote', 'subscription-pro' ),
			'text'  => (string) $feedback['comment'],
		];
	}

	/**
	 * Latest cancellation feedback row, when the free plugin records one.
	 *
	 * @return array|null
	 */
	private function get_feedback(): ?array {
		if ( ! class_exists( Cancellation::class ) || ! method_exists( Cancellation::class, 'get_feedback' ) ) {
			return null;
		}

		return Cancellation::get_feedback( $this->subscription_id );
	}
}
