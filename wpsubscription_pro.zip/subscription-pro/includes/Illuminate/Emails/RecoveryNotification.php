<?php
/**
 * Recovery Notification Email Class.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Emails
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Emails;

use SpringDevs\Subscription\Illuminate\Helper as FreeHelper;
use SpringDevs\Subscription\Illuminate\Subscription\Subscription;
use SpringDevs\Subscription\Illuminate\Multilingual;
use WC_Email;

/**
 * Sends a subscription recovery notification to the customer.
 *
 * Triggered manually from the admin recovery table via the "Send Mail" action.
 */
class RecoveryNotification extends WC_Email {

	/**
	 * Initialize the email class.
	 */
	public function __construct() {
		$this->customer_email = true;

		$this->id          = 'subscrpt_recovery_notification';
		$this->title       = __( 'Subscription Recovery Notification', 'subscription-pro' );
		$this->description = __( 'Sent to customers when their subscription requires attention (overdue, failed payment, stalled, etc.).', 'subscription-pro' );

		$this->template_base  = WP_SUBSCRIPTION_PRO_TEMPLATES;
		$this->template_html  = 'emails/recovery-notification-html.php';
		$this->template_plain = 'emails/plains/recovery-notification-plain.php';

		parent::__construct();
	}

	/**
	 * Get default email subject.
	 *
	 * @return string
	 */
	public function get_default_subject(): string {
		return __( 'Action Required: Your Subscription #{subscription_id} Needs Attention', 'subscription-pro' );
	}

	/**
	 * Get default email heading.
	 *
	 * @return string
	 */
	public function get_default_heading(): string {
		return __( 'Your Subscription Needs Attention', 'subscription-pro' );
	}

	/**
	 * Get the recipient email address from the subscription post author.
	 *
	 * @return string
	 */
	public function get_recipient(): string {
		$user_id = (int) get_post_field( 'post_author', $this->object );
		if ( ! $user_id ) {
			return '';
		}
		$user = get_userdata( $user_id );
		return $user ? $user->user_email : '';
	}

	/**
	 * Get HTML email content.
	 *
	 * @return string
	 */
	public function get_content_html(): string {
		return wc_get_template_html(
			$this->template_html,
			$this->get_template_vars(),
			'',
			$this->template_base
		);
	}

	/**
	 * Get plain-text email content.
	 *
	 * @return string
	 */
	public function get_content_plain(): string {
		return wc_get_template_html(
			$this->template_plain,
			$this->get_template_vars(),
			'',
			$this->template_base
		);
	}

	/**
	 * Trigger the email for a given subscription.
	 *
	 * @param int    $subscription_id Subscription post ID.
	 * @param string $issue_type      Issue type slug (overdue_renewal, failed_payment, etc.).
	 * @param string $issue_note      Human-readable issue description.
	 */
	public function trigger( int $subscription_id, string $issue_type = '', string $issue_note = '' ): void {
		if ( ! $subscription_id || 'no' === $this->enabled ) {
			return;
		}

		$this->object     = $subscription_id;
		$this->issue_type = $issue_type;
		$this->issue_note = $issue_note;

		$this->placeholders['{subscription_id}'] = $subscription_id;

		$recipient = $this->get_recipient();
		if ( ! $recipient ) {
			return;
		}

		// In the customer's language, not the site's or the admin who sent it.
		// An older free has no Multilingual; the email then goes out as before.
		$switched = class_exists( Multilingual::class ) && Multilingual::switch_email_language( $this, $subscription_id );

		$this->send(
			$recipient,
			$this->get_subject(),
			$this->get_content(),
			$this->get_headers(),
			$this->get_attachments()
		);

		if ( $switched ) {
			Multilingual::restore_email_language( $this );
		}
	}

	/**
	 * Build template variable array for both HTML and plain templates.
	 *
	 * @return array
	 */
	private function get_template_vars(): array {
		$subscription_id = $this->object;
		$user_id         = (int) get_post_field( 'post_author', $subscription_id );
		$user            = $user_id ? get_userdata( $user_id ) : null;

		$product_id   = (int) get_post_meta( $subscription_id, '_subscrpt_product_id', true );
		$product      = $product_id ? wc_get_product( $product_id ) : null;
		$product_name = $product ? $product->get_name() : __( 'Subscription', 'subscription-pro' );

		// Text form, not the struck-through markup: this email renders in plain text too.
		$order_item_id = get_post_meta( $subscription_id, '_subscrpt_order_item_id', true );
		$order         = $order_item_id ? wc_get_order( wc_get_order_id_by_order_item_id( $order_item_id ) ) : null;
		$order_item    = $order ? $order->get_item( $order_item_id ) : null;
		$amount        = FreeHelper::get_subscription_recurring_price_text( $subscription_id, $order_item );

		if ( ! $amount ) {
			$price    = (float) get_post_meta( $subscription_id, '_subscrpt_price', true );
			$currency = get_woocommerce_currency_symbol();
			$amount   = $currency . number_format_i18n( $price, 2 );
		}

		$next_date_ts = (int) get_post_meta( $subscription_id, '_subscrpt_next_date', true );
		$renewal_date = $next_date_ts > 0
			? date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $next_date_ts )
			: '';

		$view_subs_endpoint    = Subscription::get_user_endpoint( 'view_subs' );
		$view_subscription_url = wc_get_endpoint_url( $view_subs_endpoint, $subscription_id, wc_get_page_permalink( 'myaccount' ) );

		return array(
			'email'                 => $this,
			'email_heading'         => $this->get_heading(),
			'subscription_id'       => $subscription_id,
			'customer_name'         => $user ? $user->display_name : '',
			'product_name'          => $product_name,
			'amount'                => $amount,
			'renewal_date'          => $renewal_date,
			'view_subscription_url' => $view_subscription_url,
		);
	}
}
