<?php
/**
 * Admin notice that a subscription was saved.
 *
 * The customer opened the cancellation flow and backed out - the opposite of
 * SubscriptionCancelledAdmin, and worth knowing for the same reason. Free's
 * throttle (Illuminate\Cancellation::record_save) already limits this to once a
 * day per subscription, so nothing extra guards it here.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Emails
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Emails;

defined( 'ABSPATH' ) || exit;

/**
 * Admin notice that a subscription was saved.
 */
class SubscriptionSavedAdmin extends AdminSubscriptionStatusEmail {

	/**
	 * Save context passed with the event.
	 *
	 * @var array
	 */
	protected array $context = [];

	/**
	 * Initialize the class.
	 */
	public function __construct() {
		$this->id          = 'subscrpt_subscription_saved_admin';
		$this->title       = __( 'Subscription saved ( Admin )', 'subscription-pro' );
		$this->description = __( 'Sent to the store owner when a customer starts cancelling and then keeps their subscription.', 'subscription-pro' );

		add_action( 'subscrpt_subscription_saved', [ $this, 'trigger' ], 10, 2 );

		parent::__construct();

		$this->template_html  = 'emails/subscription-saved-admin-html.php';
		$this->template_plain = 'emails/plains/subscription-saved-admin-plain.php';
	}

	/**
	 * Capture the save context before sending.
	 *
	 * @param int   $subscription_id Subscription post ID.
	 * @param array $context         Reason that had been selected, offer state.
	 *
	 * @return void
	 */
	public function trigger( int $subscription_id, $context = [] ) {
		$this->context = is_array( $context ) ? $context : [];

		parent::trigger( $subscription_id );
	}

	/**
	 * Get default subject.
	 *
	 * @return string
	 */
	public function get_default_subject(): string {
		return __( '[{site_title}] Subscription #{subscription_id} saved', 'subscription-pro' );
	}

	/**
	 * Get default heading.
	 *
	 * @return string
	 */
	public function get_default_heading(): string {
		return __( 'Subscription saved', 'subscription-pro' );
	}

	/**
	 * Opening sentence of the mail.
	 *
	 * @return string
	 */
	protected function get_intro(): string {
		$name = $this->get_customer_name();

		if ( $name ) {
			/* translators: %s: customer name */
			return sprintf( __( '%s started cancelling a subscription and then decided to keep it.', 'subscription-pro' ), $name );
		}

		return __( 'A customer started cancelling a subscription and then decided to keep it.', 'subscription-pro' );
	}

	/**
	 * Rows specific to a save: what nearly caused it, and how it was saved.
	 *
	 * @return array<string,string>
	 */
	protected function get_status_rows(): array {
		$rows = [];

		$reason = isset( $this->context['reason_label'] ) ? (string) $this->context['reason_label'] : '';
		if ( '' !== $reason ) {
			$rows[ __( 'Reason they had selected', 'subscription-pro' ) ] = $reason;
		}

		$rows[ __( 'Saved by', 'subscription-pro' ) ] = empty( $this->context['offer_accepted'] )
			? __( 'Changed their mind', 'subscription-pro' )
			: __( 'Accepting the retention offer', 'subscription-pro' );

		return $rows;
	}
}
