<?php
/**
 * Subscription expired email for the store owner.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Emails
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Emails;

/**
 * Mail sent to the store owner when a subscription expires.
 *
 * Hooked on the same free plugin notification action as the customer expiry
 * mail, so it inherits the free plugin's delay (`subscrpt_expired_email_delay`,
 * one hour by default) and its "still expired" re-check. A subscription that is
 * renewed inside the delay window never produces either mail.
 */
class SubscriptionExpiredAdmin extends AdminSubscriptionStatusEmail {

	/**
	 * Initialize the class.
	 */
	public function __construct() {
		$this->id          = 'subscrpt_subscription_expired_admin';
		$this->title       = __( 'Subscription expired ( Admin )', 'subscription-pro' );
		$this->description = __( 'Sent to the store owner when a subscription expires. Delayed the same as the customer expiry email.', 'subscription-pro' );

		// Trigger for this email — fires after the free plugin's expiry delay.
		add_action( 'subscrpt_subscription_expired_email_notification', [ $this, 'trigger' ] );

		parent::__construct();

		$this->template_html  = 'emails/subscription-expired-admin-html.php';
		$this->template_plain = 'emails/plains/subscription-expired-admin-plain.php';
	}

	/**
	 * Get default subject.
	 *
	 * @return string
	 */
	public function get_default_subject(): string {
		return __( '[{site_title}] Subscription #{subscription_id} expired', 'subscription-pro' );
	}

	/**
	 * Get default heading.
	 *
	 * @return string
	 */
	public function get_default_heading(): string {
		return __( 'Subscription expired', 'subscription-pro' );
	}

	/**
	 * Opening sentence of the mail.
	 *
	 * @return string
	 */
	protected function get_intro(): string {
		if ( $this->is_auto_renew_on() ) {
			return __( 'A subscription expired even though automatic renewal was on. The renewal payment never completed, so it is worth a look.', 'subscription-pro' );
		}

		return __( 'A subscription reached the end of its term and was not renewed.', 'subscription-pro' );
	}

	/**
	 * Expiry specific summary rows.
	 *
	 * @return array<string,string>
	 */
	protected function get_status_rows(): array {
		return [
			__( 'Expired on', 'subscription-pro' ) => $this->format_date_meta( '_subscrpt_next_date' ),
		];
	}

	/**
	 * Whether automatic renewal was enabled for this subscription.
	 *
	 * @return bool
	 */
	private function is_auto_renew_on(): bool {
		$meta = get_post_meta( $this->subscription_id, '_subscrpt_auto_renew', true );

		if ( in_array( $meta, [ 1, '1', 'true', 'yes' ], true ) ) {
			return true;
		}

		return function_exists( 'subscrpt_is_auto_renew_enabled' ) && (bool) subscrpt_is_auto_renew_enabled();
	}
}
