<?php
/**
 * Payment failure email.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate\Emails
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Emails;

use SpringDevs\Subscription\Illuminate\Helper;
use SpringDevs\Subscription\Illuminate\Subscription\Subscription;
use SpringDevs\SubscriptionPro\Traits\Email;
use SpringDevs\Subscription\Illuminate\Multilingual;
use WC_Email;

/**
 * Payment Failure Email Class
 */
class PaymentFailure extends WC_Email {
	use Email;

	/**
	 * Initialize the class.
	 */
	public function __construct() {
		$this->customer_email = true;

		$this->id          = 'subscrpt_payment_failure';
		$this->title       = __( 'Subscription Payment Failure', 'subscription-pro' );
		$this->description = __( 'This email is sent to customers when their subscription payment fails.', 'subscription-pro' );

		// Call parent constructor first.
		parent::__construct();

		// Set custom template paths for pro plugin.
		$this->template_base  = WP_SUBSCRIPTION_PRO_TEMPLATES;
		$this->template_html  = 'emails/payment-failure-html.php';
		$this->template_plain = 'emails/plains/payment-failure-plain.php';

		// Triggers for this email.
		add_action( 'subscrpt_payment_failure_email_notification', array( $this, 'trigger' ), 10, 4 );
	}

	/**
	 * Get default subject.
	 *
	 * @return string
	 */
	public function get_default_subject(): string {
		return __( 'Payment Failed - Subscription #{subscription_id}', 'subscription-pro' );
	}

	/**
	 * Get default heading.
	 *
	 * @return string
	 */
	public function get_default_heading(): string {
		return __( 'Payment Failed', 'subscription-pro' );
	}

	/**
	 * Get the email content in HTML format.
	 *
	 * @return string
	 */
	public function get_content_html(): string {
		return $this->render_template( $this->template_html );
	}

	/**
	 * Get the email content in Plain Format.
	 *
	 * @return string
	 */
	public function get_content_plain(): string {
		return $this->render_template( $this->template_plain );
	}

	/**
	 * Render template for email.
	 *
	 * @param string $path Template Path.
	 *
	 * @return string
	 */
	public function render_template( string $path ): string {
		if ( ! $path ) {
			return '';
		}

		$view_subs_endpoint    = Subscription::get_user_endpoint( 'view_subs' );
		$view_subscription_url = wc_get_endpoint_url( $view_subs_endpoint, $this->subscription_id, wc_get_page_permalink( 'myaccount' ) );

		return wc_get_template_html(
			$path,
			array_merge(
				array(
					'subscription_id'       => $this->subscription_id,
					'view_subscription_url' => $view_subscription_url,
					'email_heading'         => $this->get_heading(),
					'product_name'          => $this->product_name,
					'qty'                   => $this->qty,
					'amount'                => $this->amount,
					'customer_name'         => $this->get_customer_name(),
					'email'                 => $this->get_recipient(),
					'failure_count'         => $this->extra['failure_count'] ?? 1,
					'max_retries'           => $this->extra['max_retries'] ?? 3,
					'is_delayed'            => $this->extra['is_delayed'] ?? false,
					'remaining_attempts'    => $this->extra['remaining_attempts'] ?? 0,
				),
				$this->extra
			),
			'',
			$this->template_base
		);
	}

	/**
	 * Get customer name for the email template.
	 *
	 * @return string
	 */
	private function get_customer_name(): string {
		if ( ! $this->subscription_id ) {
			return '';
		}

		$customer_id = get_post_meta( $this->subscription_id, '_subscrpt_user_id', true );
		if ( ! $customer_id ) {
			return '';
		}

		$customer = get_user_by( 'id', $customer_id );
		return $customer ? $customer->display_name : '';
	}

	/**
	 * Trigger the email.
	 *
	 * @param int  $subscription_id Subscription ID.
	 * @param int  $failure_count   Failure count.
	 * @param int  $max_retries     Maximum retries.
	 * @param bool $is_delayed      Whether this is a delayed notification.
	 */
	public function trigger( int $subscription_id, $failure_count = 1, $max_retries = 3, $is_delayed = false ) {
		if ( ! $subscription_id ) {
			return;
		}

		$this->subscription_id = $subscription_id;

		// Set recipient
		$customer_id = get_post_meta( $subscription_id, '_subscrpt_user_id', true );
		if ( ! $customer_id ) {
			$subscription_data = Helper::get_subscription_data( $subscription_id );
			$customer_id       = $subscription_data['user_id'] ?? 0;
		}

		if ( ! $customer_id ) {
			return;
		}

		$customer = get_user_by( 'id', $customer_id );
		if ( ! $customer ) {
			return;
		}

		$this->recipient = $customer->user_email;

		// In the customer's language, not the site's or whoever triggered it.
		// An older free has no Multilingual; the email then goes out as before.
		$switched = class_exists( Multilingual::class ) && Multilingual::switch_email_language( $this, $subscription_id );

		// Set extra data for template
		$this->extra = array(
			'failure_count'      => $failure_count,
			'max_retries'        => $max_retries,
			'is_delayed'         => $is_delayed,
			'remaining_attempts' => max( 0, $max_retries - $failure_count ),
		);

		// Set table data for template variables
		$this->set_table_data();

		// Set subject and heading
		$this->subject = $this->get_subject();
		$this->heading = $this->get_heading();

		// Send email
		$this->send( $this->recipient, $this->subject, $this->get_content(), $this->get_headers(), $this->get_attachments() );

		if ( $switched ) {
			Multilingual::restore_email_language( $this );
		}
	}
}
