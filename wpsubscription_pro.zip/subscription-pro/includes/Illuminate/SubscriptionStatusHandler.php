<?php
/**
 * Subscription status handler.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate
 */

namespace SpringDevs\SubscriptionPro\Illuminate;

use SpringDevs\Subscription\Illuminate\Action;

/**
 * Subscription Status Handler
 *
 * Handles subscription status changes and related operations.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate
 */
class SubscriptionStatusHandler {

	/**
	 * Statuses the free plugin registers for `subscrpt_order`.
	 *
	 * From `SpringDevs\Subscription\Illuminate\Post::register_post_status()`.
	 * `wp_update_post()` does not validate `post_status`, so anything outside
	 * this list is stored without complaint and then matches no query — the
	 * subscription stays in the database and vanishes from every admin list,
	 * status filter and My Account view.
	 *
	 * @var string[]
	 */
	const VALID_STATUSES = array(
		'pending',
		'active',
		'on_hold',
		'cancelled',
		'expired',
		'completed',
		'pe_cancelled',
	);

	/**
	 * Statuses this class once accepted, mapped to the registered one.
	 *
	 * `docs/hooks.md` documented `subscrpt_change_status` with `'paused'`, and
	 * `handle_pause()` wrote it, but no such status is registered. Callers who
	 * followed the documentation corrupted their own data. Mapping the old name
	 * onto the real one fixes them rather than newly rejecting them.
	 *
	 * @var array<string, string>
	 */
	const STATUS_ALIASES = array(
		'paused'  => 'on_hold',
		'on-hold' => 'on_hold',
	);

	/**
	 * Whether the hook listeners have been registered.
	 *
	 * This class is instantiated from three places — `Illuminate::__construct()`,
	 * the plugin container in `subscription-pro.php`, and once per request in
	 * `Api\SubscriptionAction::handle_action()`, which uses it as a plain
	 * service object. Registering in the constructor therefore added every
	 * listener two or three times, so a single `do_action()` would have run each
	 * handler as many times and written the status change repeatedly.
	 *
	 * @var bool
	 */
	private static $hooks_registered = false;

	/**
	 * Initialize the class.
	 */
	public function __construct() {
		$this->register_hooks();
	}

	/**
	 * Register the listeners, once per request however often this is constructed.
	 *
	 * These five hooks are a documented public API — see `docs/hooks.md`. They
	 * are commands ("put this subscription in this state"), not notifications of
	 * a state that already changed. They must never be wired to the free
	 * plugin's `subscrpt_subscription_*` lifecycle hooks: those are fired *by*
	 * `Action::status()`, which every handler here calls, so doing that would
	 * recurse until the stack was exhausted.
	 *
	 * @return void
	 */
	private function register_hooks() {
		if ( self::$hooks_registered ) {
			return;
		}
		self::$hooks_registered = true;

		add_action( 'subscrpt_cancel_subscription', array( $this, 'handle_cancel' ) );
		add_action( 'subscrpt_pause_subscription', array( $this, 'handle_pause' ) );
		add_action( 'subscrpt_resume_subscription', array( $this, 'handle_resume' ) );
		add_action( 'subscrpt_reactivate_subscription', array( $this, 'handle_reactivation' ) );

		// Two arguments, because the documented call passes a status:
		// do_action( 'subscrpt_change_status', $subscription_id, 'active' ).
		// Registered with the default of one, PHP raised an uncaught
		// ArgumentCountError against the two required parameters below and the
		// request died — a fatal for anyone following the documentation.
		add_action( 'subscrpt_change_status', array( $this, 'handle_status_change' ), 10, 2 );
	}

	/**
	 * Handle subscription cancellation
	 *
	 * @param int $subscription_id Subscription ID.
	 * @return void
	 */
	public function handle_cancel( $subscription_id ) {
		try {
			if ( ! $this->is_valid_subscription( $subscription_id ) ) {
				$this->log_error( 'Invalid subscription ID for cancellation: ' . $subscription_id );
				return;
			}
			Action::status( 'cancelled', $subscription_id );
			$this->log_success( 'Subscription cancelled successfully: ' . $subscription_id );
		} catch ( \Exception $e ) {
			$this->log_error( 'Error cancelling subscription: ' . $e->getMessage() );
		}
	}

	/**
	 * Handle subscription pause
	 *
	 * @param int $subscription_id Subscription ID.
	 * @return void
	 */
	public function handle_pause( $subscription_id ) {
		try {
			if ( ! $this->is_valid_subscription( $subscription_id ) ) {
				$this->log_error( 'Invalid subscription ID for pause: ' . $subscription_id );
				return;
			}
			Action::status( 'on_hold', $subscription_id );
			$this->log_success( 'Subscription paused successfully: ' . $subscription_id );
		} catch ( \Exception $e ) {
			$this->log_error( 'Error pausing subscription: ' . $e->getMessage() );
		}
	}

	/**
	 * Handle subscription resume
	 *
	 * @param int $subscription_id Subscription ID.
	 * @return void
	 */
	public function handle_resume( $subscription_id ) {
		try {
			if ( ! $this->is_valid_subscription( $subscription_id ) ) {
				$this->log_error( 'Invalid subscription ID for resume: ' . $subscription_id );
				return;
			}
			Action::status( 'active', $subscription_id );
			$this->log_success( 'Subscription resumed successfully: ' . $subscription_id );
		} catch ( \Exception $e ) {
			$this->log_error( 'Error resuming subscription: ' . $e->getMessage() );
		}
	}

	/**
	 * Handle subscription status change
	 *
	 * @param int    $subscription_id Subscription ID.
	 * @param string $new_status      New status to set. Defaults to an empty.
	 *                                string so that a caller passing only the
	 *                                subscription ID is logged and ignored
	 *                                rather than raising an ArgumentCountError.
	 * @return void
	 */
	public function handle_status_change( $subscription_id, $new_status = '' ) {
		try {
			if ( ! $this->is_valid_subscription( $subscription_id ) ) {
				$this->log_error( 'Invalid subscription ID for status change: ' . $subscription_id );
				return;
			}
			$new_status = $this->normalize_status( $new_status );
			if ( ! $this->is_valid_status( $new_status ) ) {
				$this->log_error( 'Invalid status for subscription ' . $subscription_id . ': ' . $new_status );
				return;
			}
			Action::status( $new_status, $subscription_id );
			$this->log_success( 'Subscription status changed successfully: ' . $subscription_id . ' to ' . $new_status );
		} catch ( \Exception $e ) {
			$this->log_error( 'Error changing subscription status: ' . $e->getMessage() );
		}
	}

	/**
	 * Handle subscription reactivation
	 *
	 * @param int $subscription_id Subscription ID.
	 * @return void
	 */
	public function handle_reactivation( $subscription_id ) {
		try {
			if ( ! $this->is_valid_subscription( $subscription_id ) ) {
				$this->log_error( 'Invalid subscription ID for reactivation: ' . $subscription_id );
				return;
			}
			Action::status( 'active', $subscription_id );
			$this->log_success( 'Subscription reactivated successfully: ' . $subscription_id );
		} catch ( \Exception $e ) {
			$this->log_error( 'Error reactivating subscription: ' . $e->getMessage() );
		}
	}

	/**
	 * Validate if the given ID is a valid subscription
	 *
	 * @param int $subscription_id Subscription ID to validate.
	 * @return bool
	 */
	private function is_valid_subscription( $subscription_id ) {
		return get_post_type( $subscription_id ) === 'subscrpt_order';
	}

	/**
	 * Resolve a deprecated status name onto the registered one.
	 *
	 * @param mixed $status Status as supplied by the caller.
	 * @return string Registered status slug, or the input unchanged so that
	 *                is_valid_status() can reject and log it.
	 */
	private function normalize_status( $status ) {
		$status = is_string( $status ) ? strtolower( trim( $status ) ) : '';

		return isset( self::STATUS_ALIASES[ $status ] ) ? self::STATUS_ALIASES[ $status ] : $status;
	}

	/**
	 * Validate that the given status is one the free plugin registers.
	 *
	 * @param string $status Status to validate.
	 * @return bool
	 */
	private function is_valid_status( $status ) {
		return in_array( $status, self::VALID_STATUSES, true );
	}

	/**
	 * Log error message
	 *
	 * @param string $message Error message to log.
	 * @return void
	 */
	private function log_error( $message ) {
		if ( function_exists( 'wc_get_logger' ) ) {
			$logger = wc_get_logger();
			$logger->error( $message, array( 'source' => 'subscription-status-handler' ) );
		}
	}

	/**
	 * Log success message
	 *
	 * @param string $message Success message to log.
	 * @return void
	 */
	private function log_success( $message ) {
		if ( function_exists( 'wc_get_logger' ) ) {
			$logger = wc_get_logger();
			$logger->info( $message, array( 'source' => 'subscription-status-handler' ) );
		}
	}
}
