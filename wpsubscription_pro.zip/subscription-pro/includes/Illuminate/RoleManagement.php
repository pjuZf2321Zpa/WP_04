<?php
/**
 * Role Management Pro File
 *
 * @package SpringDevs\SubscriptionPro\Illuminate
 */

namespace SpringDevs\SubscriptionPro\Illuminate;

use SpringDevs\Subscription\Illuminate\RoleManagement as FreeRoleManagement;

/**
 * RoleManagement [ helper class ]
 *
 * @package SpringDevs\SubscriptionPro\Illuminate
 */
class RoleManagement extends FreeRoleManagement {
	/**
	 * Initialize the class
	 */
	public function __construct() {
		// Register role based access setting. UI is defined in the free plugin (ProSettingsFields).
		add_action( 'admin_init', array( $this, 'register_settings' ) );

		// Simple product role forms
		add_action( 'subscrpt_simple_pro_after_subs_fields', [ $this, 'add_subscription_role_forms' ] );
		add_action( 'save_post_product', [ $this, 'save_subscription_role_form_data' ] );

		// Variable product role forms
		add_action( 'woocommerce_product_after_variable_attributes', [ $this, 'add_variable_subscription_role_forms' ], 10, 3 );
		add_action( 'woocommerce_save_product_variation', [ $this, 'save_variable_subscription_role_form_data' ], 10, 2 );

		// Product visibility filter
		add_filter( 'woocommerce_product_query_meta_query', [ $this, 'control_product_visibility_based_on_roles' ], 10, 2 );
		add_filter( 'woocommerce_get_children', [ $this, 'control_variations_visibility_based_on_roles' ], 10, 2 );

		// Hiding a product from the listing does not stop a direct add-to-cart.
		add_filter( 'woocommerce_add_to_cart_validation', [ $this, 'validate_add_to_cart' ], 10, 4 );
	}

	/**
	 * Register settings
	 */
	public function register_settings() {
		register_setting(
			'wp_subscription_settings',
			'subscrpt_role_based_access',
			array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			)
		);
	}

	/**
	 * Get Settings
	 *
	 * @param string $id Setting ID.
	 */
	public static function get_settings( $id = '' ) {
		$settings = [
			'subscrpt_role_based_access' => get_option( 'subscrpt_role_based_access', '1' ) === '1',
		];
		return ! empty( $id ) ? $settings[ $id ] ?? false : $settings;
	}

	/**
	 * Add subscription role forms
	 *
	 * @param int $product_id Product ID.
	 */
	public function add_subscription_role_forms( $product_id ) {
		// Settings check.
		$is_role_based_access_enabled = self::get_settings( 'subscrpt_role_based_access' );
		if ( ! $is_role_based_access_enabled ) {
			return;
		}

		global $wp_roles;
		$roles = wp_list_pluck( $wp_roles->roles, 'name' );

		$selected_roles = get_post_meta( $product_id, '_subscrpt_visible_to_roles', true );
		$selected_roles = empty( $selected_roles ) ? [] : $selected_roles;

		?>
		<br/>
		<strong style="margin: 10px;">
			<?php esc_html_e( 'Role Based Settings', 'subscription-pro' ); ?>
		</strong>
		
		<?php
		wp_subs_multiselect_field(
			[
				'id'          => 'subscrpt_visible_to_roles',
				'label'       => __( 'Visible to', 'subscription-pro' ),
				'options'     => $roles,
				'selected'    => $selected_roles,
				'description' => __( 'Select one or more user roles to limit access to this product. Keep empty for no restrictions.', 'subscription-pro' ),
				'desc_tip'    => true,
				'style'       => 'width: 50%;',
			]
		);
		?>
		<?php
	}

	/**
	 * Add variable subscription role forms
	 *
	 * @param int    $loop Loop.
	 * @param array  $variation_data Variation Data.
	 * @param object $variation Variation.
	 */
	public function add_variable_subscription_role_forms( $loop, $variation_data, $variation ) {
		// Settings check.
		$is_role_based_access_enabled = self::get_settings( 'subscrpt_role_based_access' );
		if ( ! $is_role_based_access_enabled ) {
			return;
		}

		global $wp_roles;
		$roles        = wp_list_pluck( $wp_roles->roles, 'name' );
		$variation_id = $variation->ID;

		$selected_roles = get_post_meta( $variation_id, '_subscrpt_visible_to_roles', true );
		$selected_roles = empty( $selected_roles ) ? [] : $selected_roles;

		?>
		<div class="subscrpt_role_fields show_if_subscription_<?php echo esc_attr( $loop ); ?>">
			<br/>
			<strong><?php esc_html_e( 'Role Based Settings', 'subscription-pro' ); ?></strong>
			<p class="description"><?php esc_html_e( 'Settings dependent on user roles.', 'subscription-pro' ); ?></p>

			<?php
			wp_subs_multiselect_field(
				[
					'id'            => 'subscrpt_visible_to_roles[' . $variation_id . ']',
					'label'         => __( 'Visible to', 'subscription-pro' ),
					'options'       => $roles,
					'selected'      => $selected_roles,
					'description'   => __( 'Select one or more user roles to limit access to this variation. Keep empty for no restrictions.', 'subscription-pro' ),
					'desc_tip'      => true,
					'style'         => 'width: 100%;',
					'wrapper_class' => 'form-row',
				]
			);
			?>
		</div>
		<?php
	}

	/**
	 * Save subscription role form data
	 *
	 * @param int $product_id Product ID.
	 */
	public function save_subscription_role_form_data( $product_id ) {
		// ? escaped intentionally.
		// phpcs:disable WordPress.Security.NonceVerification
		$selected_roles = isset( $_POST['subscrpt_visible_to_roles'] )
							? array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['subscrpt_visible_to_roles'] ) )
							: [];
		// phpcs:enable WordPress.Security.NonceVerification

		// Save the selected roles as post meta.
		update_post_meta( $product_id, '_subscrpt_visible_to_roles', $selected_roles );
	}

	/**
	 * Save variable subscription role form data
	 *
	 * @param int $variation_id Variation ID.
	 * @param int $i Index.
	 */
	public function save_variable_subscription_role_form_data( $variation_id, $i ) {
		// ? escaped intentionally.
		// phpcs:disable WordPress.Security.NonceVerification
		$selected_roles = isset( $_POST['subscrpt_visible_to_roles'][ $variation_id ] )
							? array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['subscrpt_visible_to_roles'][ $variation_id ] ) )
							: [];
		// phpcs:enable WordPress.Security.NonceVerification

		// Save the selected roles as post meta.
		update_post_meta( $variation_id, '_subscrpt_visible_to_roles', $selected_roles );
	}

	/**
	 * Control product visibility based on roles
	 *
	 * @param array  $meta_query Meta query.
	 * @param object $query Query object.
	 */
	public function control_product_visibility_based_on_roles( $meta_query, $query ) {
		// Settings check.
		$is_role_based_access_enabled = self::get_settings( 'subscrpt_role_based_access' );
		if ( ! $is_role_based_access_enabled ) {
			return $meta_query;
		}

		// Do not run in admin or if not main query or if not shop or product taxonomy page
		if ( is_admin() ||
			! is_main_query() ||
			( ! is_shop() && ! is_product_taxonomy() )
		) {
			return $meta_query;
		}

		$user_roles = [];
		if ( is_user_logged_in() ) {
			$user       = wp_get_current_user();
			$user_roles = (array) $user->roles;
		}

		$role_queries = [];
		foreach ( $user_roles as $role ) {
			// The roles are stored as a serialized array, so match the quoted role:
			// a bare LIKE "customer" would also match "wholesale_customer".
			$role_queries[] = [
				'key'     => '_subscrpt_visible_to_roles',
				'value'   => '"' . $role . '"',
				'compare' => 'LIKE',
			];
		}

		$meta_query[] = [
			'relation' => 'OR',
			[
				'key'     => '_subscrpt_visible_to_roles',
				'compare' => 'NOT EXISTS', // No restriction
			],
			[
				'key'     => '_subscrpt_visible_to_roles',
				'value'   => [
					'',
					'[]',
					'a:0:{}', // Serialized empty array
				],
				'compare' => 'IN',
			],
			[
				'relation' => 'OR',
				...$role_queries,
			],
		];

		return $meta_query;
	}

	/**
	 * Control variations visibility based on roles
	 *
	 * @param array       $children Array of children variation IDs.
	 * @param \WC_Product $product Product object.
	 */
	public function control_variations_visibility_based_on_roles( $children, $product ) {
		// Settings check.
		$is_role_based_access_enabled = self::get_settings( 'subscrpt_role_based_access' );
		if ( ! $is_role_based_access_enabled ) {
			return $children;
		}

		foreach ( $children as $key => $variation_id ) {
			if ( ! self::current_user_may_buy( (int) $variation_id ) ) {
				unset( $children[ $key ] );
			}
		}

		return $children;
	}

	/**
	 * Whether the current user has a role a product or variation is restricted to.
	 *
	 * A product with no roles set is open to everyone.
	 *
	 * @param int $post_id Product or variation ID.
	 * @return bool
	 */
	public static function current_user_may_buy( int $post_id ): bool {
		$allowed_roles = get_post_meta( $post_id, '_subscrpt_visible_to_roles', true );

		if ( empty( $allowed_roles ) || ! is_array( $allowed_roles ) ) {
			return true;
		}

		if ( ! is_user_logged_in() ) {
			return false;
		}

		return ! empty( array_intersect( $allowed_roles, (array) wp_get_current_user()->roles ) );
	}

	/**
	 * Refuse to add a product, or a variation, the current user's role may not buy.
	 *
	 * @param bool $passed       Whether validation has passed so far.
	 * @param int  $product_id   Product ID.
	 * @param int  $quantity     Quantity.
	 * @param int  $variation_id Variation ID.
	 * @return bool
	 */
	public function validate_add_to_cart( $passed, $product_id, $quantity = 1, $variation_id = 0 ) {
		if ( ! $passed || ! self::get_settings( 'subscrpt_role_based_access' ) ) {
			return $passed;
		}

		$ids = array_filter( [ (int) $product_id, (int) $variation_id ] );

		foreach ( $ids as $id ) {
			if ( ! self::current_user_may_buy( $id ) ) {
				wc_add_notice( __( 'Sorry, this product is not available to your account.', 'subscription-pro' ), 'error' );

				return false;
			}
		}

		return $passed;
	}
}
