<?php
/**
 * Live QR Metabox View
 *
 * @package SubscriptionPro\Illuminate\LiveQR\views
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>

<div>
	<img id="wpsubs_qr_image" src="<?php echo esc_attr( $qr_image ); ?>" alt="<?php esc_attr_e( 'Subscription Live QR Code', 'subscription-pro' ); ?>" />

	<p style="margin:14px 0 8px;font-size:12px;font-weight:600;color:#6b7280;text-transform:uppercase;letter-spacing:0.04em;"><?php esc_html_e( 'Actions', 'subscription-pro' ); ?></p>

	<div style="display:flex;flex-wrap:wrap;gap:12px;">
		<button class="button button-primary" id="wpsubs_download_qr" style="flex:1 1 auto;"><?php esc_html_e( 'Download QR', 'subscription-pro' ); ?></button>
		<button class="button button-primary" id="wpsubs_regenerate_qr" style="flex:1 1 auto;" title="<?php esc_attr_e( 'Clean cache and regenerate the QR code', 'subscription-pro' ); ?>"><?php esc_html_e( 'Regenerate QR', 'subscription-pro' ); ?></button>
		<button class="button button-primary" id="wpsubs_send_qr" style="flex:1 1 auto;"><?php esc_html_e( 'Send in Email', 'subscription-pro' ); ?></button>
	</div>
</div>

<!-- Download Script -->
<script>
document.getElementById('wpsubs_download_qr').addEventListener('click', function (e) {
	e.preventDefault();

	const img = document.getElementById('wpsubs_qr_image');
	const canvas = document.createElement('canvas');
	const ctx = canvas.getContext('2d');
	const image = new Image();

	image.onload = function() {
		const scale = 4; // increase this for higher resolution
		const canvas = document.createElement('canvas');
		const ctx = canvas.getContext('2d');

		// Use natural size from SVG if available, else fallback
		const width = image.naturalWidth || 200;
		const height = image.naturalHeight || 200;

		canvas.width = width * scale;
		canvas.height = height * scale;

		ctx.drawImage(image, 0, 0, canvas.width, canvas.height);

		// Generate a PNG data URL from the canvas
		const pngData = canvas.toDataURL('image/png');

		const link = document.createElement('a');
		link.href = pngData;
		link.download = 'Subscription_<?php echo esc_js( $subscription_id ); ?>_QR.png';
		link.click();
	};

	// Important: ensure cross-origin safe
	image.src = img.src;
});

document.getElementById('wpsubs_regenerate_qr').addEventListener('click', function (e) {
	e.preventDefault();

	jQuery.ajax({
		url: ajaxurl,
		method: 'POST',
		data: {
			action: 'wpsubs_regenerate_qr',
			nonce: '<?php echo esc_js( wp_create_nonce( 'wpsubs_live_qr' ) ); ?>',
			subscription_id: <?php echo esc_js( $subscription_id ); ?>,
		},
		success: function (response) {
			if (response.success && response.data.qr_image) {
				alert('<?php echo esc_js( __( 'QR code regenerated successfully!', 'subscription-pro' ) ); ?>');
				
				document.getElementById('wpsubs_qr_image').src = response.data.qr_image;
			} else {
				alert('<?php echo esc_js( __( 'Failed to regenerate QR code.', 'subscription-pro' ) ); ?>');
			}
		},
		error: function (xhr, status, error) {
			console.error('AJAX request failed:', status, error);
			alert('<?php echo esc_js( __( 'Failed to regenerate QR code. Server Error!', 'subscription-pro' ) ); ?>');
		}
	});
});

document.getElementById('wpsubs_send_qr').addEventListener('click', function (e) {
	e.preventDefault();

	alert('<?php echo esc_js( __( 'We are working on this feature and it will be available soon!', 'subscription-pro' ) ); ?>');
});
</script>
