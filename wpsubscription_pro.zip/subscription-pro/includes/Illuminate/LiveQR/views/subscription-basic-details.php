<?php
/**
 * Subscription Details View
 *
 * ? This file was moved to 'template' folder. Only kept this for documentation purpose.
 * * "/templates/LiveQR/subscription-basic-details.php"
 *
 * @package SubscriptionPro\Illuminate\LiveQR\views
 */

exit( "This file was moved to the 'template' folder. Use the one from there." );
