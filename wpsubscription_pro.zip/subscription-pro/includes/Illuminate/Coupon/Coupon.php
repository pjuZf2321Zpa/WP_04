<?php
/**
 * Coupon Main File
 *
 * @package SubscriptionPro\Illuminate
 */

namespace SpringDevs\SubscriptionPro\Illuminate\Coupon;

use SpringDevs\Subscription\Illuminate\Helper as FreeHelper;

/**
 * Coupon Class
 */
class Coupon {
	/**
	 * Constructor
	 */
	public function __construct() {
		// Add subscription tab in coupon data metabox.
		add_filter( 'woocommerce_coupon_data_tabs', [ $this, 'add_subs_tab_in_coupon_menu' ] );

		// Render subscription tab content in coupon data metabox.
		add_action( 'woocommerce_coupon_data_panels', [ $this, 'render_subscription_tab_content' ] );

		// Save subscription coupon data.
		add_action( 'woocommerce_coupon_options_save', [ $this, 'save_subscription_coupon_data' ], 10, 2 );

		// Maybe add coupon to the renewal order. Early renewals fire their own filter.
		add_filter( 'subscrpt_before_saving_renewal_order', [ $this, 'maybe_add_coupon_to_renewal_order' ], 10, 3 );
		add_filter( 'subscrpt_before_saving_early_renewal_order', [ $this, 'maybe_add_coupon_to_renewal_order' ], 10, 3 );

		// Tell the free plugin which cart coupons survive into renewals, for recurring totals.
		add_filter( 'subscrpt_coupon_is_recurring', [ $this, 'is_recurring_coupon' ], 10, 2 );
		add_filter( 'subscrpt_coupon_recurring_limit', [ $this, 'get_recurring_limit' ], 10, 2 );
	}

	/**
	 * Whether a coupon's discount also applies to renewals.
	 *
	 * @param bool       $is_recurring Whether the discount recurs.
	 * @param \WC_Coupon $coupon       Coupon object.
	 *
	 * @return bool
	 */
	public function is_recurring_coupon( $is_recurring, $coupon ) {
		return $is_recurring || (bool) self::get_coupon_recurring_data( $coupon, '_wp_subs_is_recurring' );
	}

	/**
	 * How many payments a recurring coupon's discount covers. 0 means unlimited.
	 *
	 * @param int        $limit  Number of payments, including the initial one.
	 * @param \WC_Coupon $coupon Coupon object.
	 *
	 * @return int
	 */
	public function get_recurring_limit( $limit, $coupon ) {
		$coupon_limit = (int) self::get_coupon_recurring_data( $coupon, '_wp_subs_recurring_limit' );

		return $coupon_limit > 0 ? $coupon_limit : (int) $limit;
	}

	/**
	 * Add subscription table in coupon data metabox.
	 *
	 * @param array $tabs Tabs array.
	 */
	public function add_subs_tab_in_coupon_menu( $tabs ) {
		$tabs['wpsubs'] = [
			'label'    => esc_html__( 'Subscription', 'subscription-pro' ),
			'target'   => 'wpsubs_coupon_data',
			'class'    => [],
			'priority' => 30,
		];
		return $tabs;
	}

	/**
	 * Render subscription tab content in coupon data metabox.
	 */
	public function render_subscription_tab_content() {
		?>
		<div id="wpsubs_coupon_data" class="panel woocommerce_options_panel hidden">
			<?php
			woocommerce_wp_checkbox(
				[
					'id'          => '_wp_subs_is_recurring',
					'label'       => __( 'Recurring', 'subscription-pro' ),
					'description' => __( 'Apply this coupon to subscription renewal orders.', 'subscription-pro' ),
				]
			);
			woocommerce_wp_text_input(
				[
					'id'                => '_wp_subs_recurring_limit',
					'label'             => __( 'Recurring Limit', 'subscription-pro' ),
					'description'       => __( 'How many time this coupon will apply to a subscription (including the initial order).', 'subscription-pro' ) . '<br/>' . __( 'Set to 0 for no limits.', 'subscription-pro' ),
					'type'              => 'number',
					'desc_tip'          => true,
					'custom_attributes' => [
						'min' => '0',
					],
				]
			);
			?>
		</div>
		<?php
	}

	/**
	 * Save subscription coupon data.
	 *
	 * @param int        $post_id Post ID.
	 * @param \WC_Coupon $coupon Coupon object.
	 */
	public function save_subscription_coupon_data( $post_id, $coupon ) {
		// phpcs:ignore WordPress.Security.NonceVerification
		$for_recurring = isset( $_POST['_wp_subs_is_recurring'] ) ? 'yes' : 'no';

		// phpcs:ignore WordPress.Security.NonceVerification
		$recurr_limit = isset( $_POST['_wp_subs_recurring_limit'] ) ? intval( $_POST['_wp_subs_recurring_limit'] ) : '';

		// Save meta data.
		$coupon->update_meta_data( '_wp_subs_is_recurring', $for_recurring );
		$coupon->update_meta_data( '_wp_subs_recurring_limit', $recurr_limit );
		$coupon->save();
	}

	/**
	 * Get coupon recurring data.
	 *
	 * @param \WC_Coupon $coupon Coupon object.
	 * @param int        $id        (Optional) Settings Field ID.
	 */
	public static function get_coupon_recurring_data( $coupon, $id = '' ) {
		// Normalize coupon object.
		if ( ! $coupon instanceof \WC_Coupon ) {
			if ( is_string( $coupon ) || is_numeric( $coupon ) ) {
				$coupon = new \WC_Coupon( $coupon );
			} else {
				return false;
			}
		}

		$is_recurring = $coupon->get_meta( '_wp_subs_is_recurring', true ) === 'yes';

		$recurring_limit = $coupon->get_meta( '_wp_subs_recurring_limit', true );
		$recurring_limit = ! empty( $recurring_limit ) ? intval( $recurring_limit ) : 0;

		$settings = [
			'_wp_subs_is_recurring'    => $is_recurring,
			'_wp_subs_recurring_limit' => $recurring_limit,
		];

		return empty( $id ) ? $settings : $settings[ $id ] ?? false;
	}

	/**
	 * Maybe add coupon to the renewal order.
	 *
	 * @param \WC_Order $new_order New order object.
	 * @param \WC_Order $old_order Old order object.
	 * @param int       $subscription_id Subscription ID.
	 * @return \WC_Order Modified new order object.
	 */
	public function maybe_add_coupon_to_renewal_order( $new_order, $old_order, $subscription_id ) {
		$new_order_coupons = $new_order->get_coupon_codes();
		$old_order_coupons = $old_order->get_coupon_codes();

		// Return if no coupons in old order.
		if ( empty( $old_order_coupons ) ) {
			return $new_order;
		}

		/**
		 * Position of the order being created in this subscription's order sequence.
		 *
		 * Free's `create_renewal_order()` inserts the new order's relation row in
		 * `create_renewal_history()` before firing this filter, so the count already
		 * includes the renewal being built. The limit counts the initial order, so this
		 * order is within the limit while its position is less than or equal to it.
		 */
		$order_position = count( FreeHelper::get_related_orders( $subscription_id ) );

		// Maybe add coupons to the new order.
		foreach ( $old_order_coupons as $coupon_code ) {
			$coupon          = new \WC_Coupon( $coupon_code );
			$coupon_settings = self::get_coupon_recurring_data( $coupon );

			// Skip if not a recurring coupon.
			if ( ! ( $coupon_settings['_wp_subs_is_recurring'] ?? false ) ) {
				continue;
			}

			// Skip once this order is past the limit.
			if (
				( $coupon_settings['_wp_subs_recurring_limit'] ?? 0 ) > 0 &&
				$order_position > $coupon_settings['_wp_subs_recurring_limit']
			) {
				// ? Add action hook for future use.
				do_action( 'wp_subs_coupon_recurring_limit_reached', $subscription_id, $coupon );

				wp_subscrpt_write_log( sprintf( 'Skipping coupon %s for order %d as recurring limit reached.', $coupon_code, $new_order->get_id() ) );
				continue;
			}

			// Skip if coupon already applied in the new order.
			if ( in_array( $coupon_code, $new_order_coupons, true ) ) {
				continue;
			}

			// Apply coupon to the new order.
			$result = $new_order->apply_coupon( $coupon );

			// ? Log if failed to apply coupon.
			if ( is_wp_error( $result ) ) {
				wp_subscrpt_write_log( sprintf( 'Failed to apply coupon %s to order %d. Error: %s', $coupon_code, $new_order->get_id(), $result->get_error_message() ) );
			}
		}

		return $new_order;
	}
}
