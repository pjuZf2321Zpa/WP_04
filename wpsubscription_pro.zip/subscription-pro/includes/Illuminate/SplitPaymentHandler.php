<?php
/**
 * Split payment and access end timing logic.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate
 */

namespace SpringDevs\SubscriptionPro\Illuminate;

/**
 * Class SplitPaymentHandler
 *
 * Handles business logic for Payment Type and Access Ends Timing features
 *
 * @package SpringDevs\SubscriptionPro\Illuminate
 */
class SplitPaymentHandler {

	/**
	 * Calculate access end date for a split payment subscription.
	 *
	 * @param int $subscription_id Subscription ID.
	 * @return int|null Access end timestamp or null if no end date.
	 */
	public static function calculate_access_end_date( $subscription_id ) {
		$product_id = get_post_meta( $subscription_id, '_subscrpt_product_id', true );
		if ( ! $product_id ) {
			return null;
		}

		// Check if subscription has variation
		$variation_id   = get_post_meta( $subscription_id, '_subscrpt_variation_id', true );
		$product_to_use = $variation_id ? $variation_id : $product_id;

		$product = wc_get_product( $product_to_use );
		if ( ! $product ) {
			return null;
		}

		// Plan subs carry these on the subscription; classic subs on the product.
		$payment_type = get_post_meta( $subscription_id, '_subscrpt_payment_type', true );
		if ( ! $payment_type ) {
			$payment_type = $product->get_meta( '_subscrpt_payment_type' );
			$payment_type = $payment_type ? $payment_type : 'recurring';
		}

		// Only calculate for split payments
		if ( 'split_payment' !== $payment_type ) {
			return null;
		}

		$access_ends_timing = get_post_meta( $subscription_id, '_subscrpt_access_ends_timing', true );
		if ( ! $access_ends_timing ) {
			$access_ends_timing = $product->get_meta( '_subscrpt_access_ends_timing' );
			$access_ends_timing = $access_ends_timing ? $access_ends_timing : 'after_full_duration';
		}
		$start_date = get_post_meta( $subscription_id, '_subscrpt_start_date', true );

		if ( ! $start_date ) {
			return null;
		}

		switch ( $access_ends_timing ) {
			case 'lifetime':
				// Access never ends - lifetime access
				return null;

			case 'after_full_duration':
				// Access ends based on payment interval × number of payments
				return self::calculate_full_duration_end_date( $subscription_id, $product );

			case 'custom_duration':
				// Access ends based on custom duration after first payment
				return self::calculate_custom_duration_end_date( $subscription_id, $product );

			default:
				return null;
		}
	}

	/**
	 * Get the date when final payment is expected.
	 *
	 * @param int $subscription_id Subscription ID.
	 * @return int|null Final payment timestamp.
	 */
	public static function get_final_payment_date( $subscription_id ) {
		$product_id = get_post_meta( $subscription_id, '_subscrpt_product_id', true );
		if ( ! $product_id ) {
			return null;
		}

		// Use helper function that handles variations properly
		$max_payments = subscrpt_get_max_payments( $subscription_id );

		if ( ! $max_payments || intval( $max_payments ) <= 0 ) {
			return null;
		}

		$start_date    = get_post_meta( $subscription_id, '_subscrpt_start_date', true );
		$timing_per    = get_post_meta( $subscription_id, '_subscrpt_timing_per', true );
		$timing_per    = $timing_per ? $timing_per : 1;
		$timing_option = get_post_meta( $subscription_id, '_subscrpt_timing_option', true );
		$timing_option = $timing_option ? $timing_option : 'months';

		if ( ! $start_date ) {
			return null;
		}

		// Calculate final payment date: start + (payments - 1) × interval
		$interval_string    = $timing_per . ' ' . $timing_option;
		$final_payment_date = $start_date;

		for ( $i = 1; $i < $max_payments; $i++ ) {
			$final_payment_date = sdevs_wp_strtotime( $interval_string, $final_payment_date );
		}

		return $final_payment_date;
	}

	/**
	 * Get the first payment date for a subscription.
	 *
	 * @param int $subscription_id Subscription ID.
	 * @return int|null First payment timestamp.
	 */
	public static function get_first_payment_date( $subscription_id ) {
		// The first payment date is simply the start date
		$start_date = get_post_meta( $subscription_id, '_subscrpt_start_date', true );

		if ( ! $start_date ) {
			return null;
		}

		return $start_date;
	}

	/**
	 * Calculate access end date based on full duration (default behavior).
	 *
	 * @param int         $subscription_id Subscription ID.
	 * @param \WC_Product $product Product object.
	 * @return int|null Access end timestamp.
	 */
	public static function calculate_full_duration_end_date( $subscription_id, $product ) {
		$max_payments = function_exists( 'subscrpt_get_max_payments' )
			? subscrpt_get_max_payments( $subscription_id )
			: $product->get_meta( '_subscrpt_max_no_payment' );
		if ( ! $max_payments || $max_payments <= 0 ) {
			return null;
		}

		$start_date    = get_post_meta( $subscription_id, '_subscrpt_start_date', true );
		$timing_per    = get_post_meta( $subscription_id, '_subscrpt_timing_per', true );
		$timing_per    = $timing_per ? $timing_per : 1;
		$timing_option = get_post_meta( $subscription_id, '_subscrpt_timing_option', true );
		$timing_option = $timing_option ? $timing_option : 'months';

		if ( ! $start_date ) {
			return null;
		}

		// Calculate full duration: start + payments × interval
		$interval_string = $timing_per . ' ' . $timing_option;
		$end_date        = $start_date;

		for ( $i = 0; $i < $max_payments; $i++ ) {
			$end_date = sdevs_wp_strtotime( $interval_string, $end_date );
		}

		return $end_date;
	}

	/**
	 * Calculate access end date based on custom duration after first payment.
	 *
	 * @param int         $subscription_id Subscription ID.
	 * @param \WC_Product $product Product object.
	 * @return int|null Access end timestamp.
	 */
	public static function calculate_custom_duration_end_date( $subscription_id, $product ) {
		$first_payment_date = self::get_first_payment_date( $subscription_id );
		if ( ! $first_payment_date ) {
			return null;
		}

		$custom_duration_time = get_post_meta( $subscription_id, '_subscrpt_custom_access_duration_time', true );
		if ( ! $custom_duration_time ) {
			$custom_duration_time = $product->get_meta( '_subscrpt_custom_access_duration_time' );
			$custom_duration_time = $custom_duration_time ? $custom_duration_time : 1;
		}
		$custom_duration_type = get_post_meta( $subscription_id, '_subscrpt_custom_access_duration_type', true );
		if ( ! $custom_duration_type ) {
			$custom_duration_type = $product->get_meta( '_subscrpt_custom_access_duration_type' );
			$custom_duration_type = $custom_duration_type ? $custom_duration_type : 'months';
		}

		// Add custom duration to first payment date
		$custom_interval = $custom_duration_time . ' ' . $custom_duration_type;
		return sdevs_wp_strtotime( $custom_interval, $first_payment_date );
	}

	/**
	 * Check if subscription access should be expired based on access timing rules.
	 *
	 * @param int $subscription_id Subscription ID.
	 * @return bool True if access should be expired.
	 */
	public static function should_expire_access( $subscription_id ) {
		$access_end_date = self::calculate_access_end_date( $subscription_id );

		if ( ! $access_end_date ) {
			return false;
		}

		return time() >= $access_end_date;
	}

	/**
	 * Get human-readable access end date string.
	 *
	 * @param int $subscription_id Subscription ID.
	 * @return string|null Human-readable access end date.
	 */
	public static function get_access_end_date_string( $subscription_id ) {
		$access_end_date = self::calculate_access_end_date( $subscription_id );

		if ( ! $access_end_date ) {
			return null;
		}

		return date_i18n( wc_date_format(), $access_end_date );
	}

	/**
	 * Apply access timing rules when split payment is completed.
	 *
	 * @param int $subscription_id Subscription ID.
	 * @param int $payments_made Number of payments made.
	 * @param int $max_payments Maximum number of payments.
	 */
	public static function handle_split_payment_completion( $subscription_id, $payments_made, $max_payments ) {
		// Timing lives on the subscription (plan) or falls back to the product.
		$access_ends_timing = (string) get_post_meta( $subscription_id, '_subscrpt_access_ends_timing', true );
		if ( '' === $access_ends_timing ) {
			$product            = wc_get_product( get_post_meta( $subscription_id, '_subscrpt_product_id', true ) );
			$product_timing     = $product ? (string) $product->get_meta( '_subscrpt_access_ends_timing' ) : '';
			$access_ends_timing = '' !== $product_timing ? $product_timing : 'lifetime';
		}

		// Record the access window only; the sub is already `completed`, never re-activate.
		if ( 'lifetime' === $access_ends_timing ) {
			update_post_meta( $subscription_id, '_subscrpt_lifetime_access', 'yes' );
			delete_post_meta( $subscription_id, '_subscrpt_access_end_date' );
		} else {
			$access_end_date = self::calculate_access_end_date( $subscription_id );
			if ( $access_end_date ) {
				update_post_meta( $subscription_id, '_subscrpt_access_end_date', $access_end_date );
			}
		}
	}
}
