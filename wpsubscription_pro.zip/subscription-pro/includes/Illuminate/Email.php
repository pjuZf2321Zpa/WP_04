<?php
/**
 * Pro email registration.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate
 */

namespace SpringDevs\SubscriptionPro\Illuminate;

use SpringDevs\SubscriptionPro\Illuminate\Emails\HealthQueueReminder;
use SpringDevs\SubscriptionPro\Illuminate\Emails\PaymentFailure;
use SpringDevs\SubscriptionPro\Illuminate\Emails\RecoveryNotification;
use SpringDevs\SubscriptionPro\Illuminate\Emails\RenewReminder;
use SpringDevs\SubscriptionPro\Illuminate\Emails\SubscriptionCancelledAdmin;
use SpringDevs\SubscriptionPro\Illuminate\Emails\SubscriptionSavedAdmin;
use SpringDevs\SubscriptionPro\Illuminate\Emails\SubscriptionExpiredAdmin;
use SpringDevs\SubscriptionPro\Illuminate\Emails\UpcomingBox;

/**
 * Class Email
 *
 * @package SpringDevs\SubscriptionPro\Illuminate
 */
class Email {

	/**
	 * The constructor method.
	 */
	public function __construct() {
		add_filter( 'woocommerce_email_classes', array( $this, 'register_pro_emails' ) );
		add_filter( 'woocommerce_locate_template', array( $this, 'prefer_pro_email_template' ), 10, 2 );
	}

	/**
	 * Serve the pro copy of an email template whenever one exists.
	 *
	 * Some emails ship a template in both plugins (e.g. the renewal reminder).
	 * The free plugin resolves them against its own templates directory, so
	 * without this filter the free markup wins even though pro is active.
	 *
	 * Only the free plugin's default path is redirected: a theme override --
	 * whether under `yourtheme/subscription/` or `yourtheme/subscription-pro/`
	 * -- still takes precedence, and templates belonging to WooCommerce or any
	 * other plugin are left untouched.
	 *
	 * @param string $template      Absolute path WooCommerce resolved.
	 * @param string $template_name Template name, e.g. `emails/renew-reminder-html.php`.
	 *
	 * @return string
	 */
	public function prefer_pro_email_template( string $template, string $template_name ): string {
		if ( 0 !== strpos( $template_name, 'emails/' ) || ! defined( 'SUBSCRPT_TEMPLATES' ) ) {
			return $template;
		}

		// Anything but the free plugin's own default -- theme override, WooCommerce, another plugin -- wins.
		if ( SUBSCRPT_TEMPLATES . $template_name !== $template ) {
			return $template;
		}

		$pro_template = WP_SUBSCRIPTION_PRO_TEMPLATES . $template_name;
		if ( ! file_exists( $pro_template ) ) {
			return $template;
		}

		// Let a theme override the pro copy too.
		$theme_template = locate_template( array( 'subscription-pro/' . $template_name ) );

		return $theme_template ? $theme_template : $pro_template;
	}

	/**
	 * Register pro emails.
	 *
	 * @param array $emails Email classes.
	 *
	 * @return array
	 */
	public function register_pro_emails( array $emails ): array {
		$emails['subscrpt_payment_failure']       = new PaymentFailure();
		$emails['subscrpt_renew_reminder']        = new RenewReminder();
		$emails['subscrpt_recovery_notification'] = new RecoveryNotification();
		$emails['subscrpt_health_queue_reminder'] = new HealthQueueReminder();
		$emails['subscrpt_upcoming_box']          = new UpcomingBox();

		// Store owner notifications. Cancellation is immediate; expiry inherits
		// the free plugin's `subscrpt_expired_email_delay` delay.
		$emails['subscrpt_subscription_cancelled_admin'] = new SubscriptionCancelledAdmin();
		$emails['subscrpt_subscription_saved_admin']     = new SubscriptionSavedAdmin();
		$emails['subscrpt_subscription_expired_admin']   = new SubscriptionExpiredAdmin();

		return $emails;
	}
}
