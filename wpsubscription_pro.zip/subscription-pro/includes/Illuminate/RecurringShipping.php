<?php
/**
 * Shipping on a renewal.
 *
 * Neither plugin has ever put a shipping line on a renewal order: free clones
 * the addresses and nothing else, so a physical subscription ships free forever
 * after its first order. A box that arrives monthly cannot work that way.
 *
 * This is deliberately scoped to box subscriptions. Switching it on for every
 * physical subscription would start charging existing subscribers something
 * they never agreed to, which is a decision for the merchant, not a side effect
 * of installing an update.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate
 */

namespace SpringDevs\SubscriptionPro\Illuminate;

use SpringDevs\SubscriptionPro\Illuminate\Box\BoxSubscription;

defined( 'ABSPATH' ) || exit;

/**
 * Copies shipping from the previous order onto a box renewal.
 */
class RecurringShipping {

	/**
	 * Register hooks.
	 *
	 * Priority 9: after the box has finished adding its content lines (8) and
	 * before the coupon listener (10), so the shipping line is present when
	 * totals are calculated.
	 */
	public function __construct() {
		add_filter( 'subscrpt_before_saving_renewal_order', array( $this, 'add_shipping' ), 9, 3 );
		add_filter( 'subscrpt_before_saving_early_renewal_order', array( $this, 'add_shipping' ), 9, 3 );
	}

	/**
	 * Put the previous order's shipping on the renewal.
	 *
	 * Copying from the previous order rather than recalculating is the same
	 * promise the price makes: what the subscriber agreed to is what they are
	 * charged, until they change it.
	 *
	 * @param \WC_Order $new_order       Renewal order being built.
	 * @param \WC_Order $old_order       Order it was cloned from.
	 * @param int       $subscription_id Subscription id.
	 *
	 * @return \WC_Order
	 */
	public function add_shipping( $new_order, $old_order, $subscription_id ) {
		if ( ! $new_order instanceof \WC_Order || ! $old_order instanceof \WC_Order ) {
			return $new_order;
		}

		if ( ! BoxSubscription::is_box( (int) $subscription_id ) ) {
			return $new_order;
		}

		if ( 'copy' !== get_option( 'subscrpt_box_renewal_shipping', 'copy' ) ) {
			return $new_order;
		}

		// Never add a second shipping line — a retry rebuilds the same order.
		if ( $new_order->get_shipping_methods() ) {
			return $new_order;
		}

		foreach ( $old_order->get_shipping_methods() as $old_shipping ) {
			$shipping = new \WC_Order_Item_Shipping();

			$shipping->set_props(
				array(
					'method_title' => $old_shipping->get_method_title(),
					'method_id'    => $old_shipping->get_method_id(),
					'instance_id'  => $old_shipping->get_instance_id(),
					'total'        => $old_shipping->get_total(),
					'taxes'        => $old_shipping->get_taxes(),
				)
			);

			$new_order->add_item( $shipping );
		}

		return $new_order;
	}
}
