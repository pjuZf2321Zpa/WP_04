<?php
/**
 * Payment failure and retry scheduling.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate
 */

namespace SpringDevs\SubscriptionPro\Illuminate;

use SpringDevs\Subscription\Illuminate\Action;
use SpringDevs\Subscription\Illuminate\Helper as FreeHelper;

/**
 * Handle payment failures and retry scheduling for subscriptions.
 * Grace period logic is owned by the free plugin (AutoRenewal).
 */
class PaymentFailureHandler {

	/**
	 * Initialize hooks
	 */
	public static function init() {
		add_action( 'subscrpt_split_payment_failed', array( __CLASS__, 'handle_payment_failure' ), 10, 1 );
		add_action( 'subscrpt_subscription_payment_failed', array( __CLASS__, 'handle_payment_failure' ), 10, 1 );
		add_action( 'woocommerce_order_status_failed', array( __CLASS__, 'handle_order_failed' ), 10, 1 );
		add_action( 'subscrpt_subscription_activated', array( __CLASS__, 'handle_subscription_activated' ), 10, 1 );
		add_action( 'wp_loaded', array( __CLASS__, 'schedule_retry_checks' ) );
		add_action( 'subscrpt_check_payment_retries', array( __CLASS__, 'process_payment_retries' ) );
		add_action( 'subscrpt_send_delayed_failure_notification', array( __CLASS__, 'send_delayed_failure_notification' ), 10, 3 );
	}

	/**
	 * Handle payment failure for both recurring and split payments.
	 * Schedules a retry until max retries is reached, then suspends access.
	 * Grace period (if configured) is applied by the free plugin after suspension.
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	public static function handle_payment_failure( $subscription_id ) {
		$failure_count = self::increment_failure_count( $subscription_id );
		$max_retries   = self::get_max_retries( $subscription_id );

		self::log_payment_failure( $subscription_id, $failure_count );

		if ( $failure_count >= $max_retries ) {
			self::suspend_access( $subscription_id );
		} else {
			self::schedule_payment_retry( $subscription_id, $failure_count );
		}

		self::send_failure_notification( $subscription_id, $failure_count, $max_retries );
	}

	/**
	 * Handle WooCommerce order failure.
	 *
	 * @param int $order_id Order ID.
	 */
	public static function handle_order_failed( $order_id ) {
		$subscription_ids = array();
		foreach ( FreeHelper::get_subscriptions_from_order( $order_id ) as $history ) {
			// A failed early renewal is not a missed renewal: the subscription is not due yet.
			if ( 'early-renew' === $history->type ) {
				continue;
			}
			$subscription_ids[] = (int) $history->subscription_id;
		}

		foreach ( array_unique( $subscription_ids ) as $subscription_id ) {
			self::handle_payment_failure( $subscription_id );
		}
	}

	/**
	 * Reset failure count when subscription is activated after successful payment.
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	public static function handle_subscription_activated( $subscription_id ) {
		self::reset_failure_count( $subscription_id );
	}

	/**
	 * Increment failure count for subscription.
	 *
	 * @param int $subscription_id Subscription ID.
	 * @return int New failure count.
	 */
	private static function increment_failure_count( $subscription_id ) {
		$current_count = get_post_meta( $subscription_id, '_subscrpt_payment_failure_count', true );
		$current_count = $current_count ? $current_count : 0;
		$new_count     = intval( $current_count ) + 1;
		update_post_meta( $subscription_id, '_subscrpt_payment_failure_count', $new_count );
		update_post_meta( $subscription_id, '_subscrpt_last_payment_failure', time() );
		return $new_count;
	}

	/**
	 * Get maximum retry attempts.
	 *
	 * @param int $subscription_id Subscription ID.
	 * @return int Maximum retries.
	 */
	private static function get_max_retries( $subscription_id ) {
		$default_retries = get_option( 'subscrpt_default_max_payment_retries', 3 );
		return apply_filters( 'subscrpt_default_max_payment_retries', $default_retries );
	}

	/**
	 * Schedule payment retry with exponential backoff.
	 * Default base: 1h. Override via subscrpt_retry_base_delay_hours filter.
	 * Retry intervals: 1h, 2h, 4h, 8h, …
	 *
	 * @param int $subscription_id Subscription ID.
	 * @param int $failure_count Current failure count.
	 */
	private static function schedule_payment_retry( $subscription_id, $failure_count ) {
		$base_delay  = apply_filters( 'subscrpt_retry_base_delay_hours', 1 );
		$retry_delay = $base_delay * pow( 2, $failure_count - 1 );
		$retry_time  = current_time( 'timestamp' ) + ( $retry_delay * HOUR_IN_SECONDS );

		update_post_meta( $subscription_id, '_subscrpt_next_retry_time', $retry_time );
		update_post_meta( $subscription_id, '_subscrpt_retry_scheduled', 1 );

		$note = sprintf(
			/* translators: %1$d: failure count, %2$s: retry date */
			__( 'Payment failed (attempt %1$d). Next retry scheduled for %2$s', 'subscription-pro' ),
			$failure_count,
			gmdate( 'Y-m-d H:i:s', $retry_time )
		);
		$comment_id = wp_insert_comment(
			array(
				'comment_post_ID'  => $subscription_id,
				'comment_content'  => $note,
				'comment_type'     => 'subscrpt_note',
				'comment_approved' => 1,
				'user_id'          => 0,
			)
		);
		// Without these the Activities card skips the note.
		update_comment_meta( $comment_id, '_subscrpt_activity', 'Payment Retry Scheduled' );
		update_comment_meta( $comment_id, '_subscrpt_activity_type', 'payment_retry_scheduled' );
	}

	/**
	 * Suspend access for subscription.
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	private static function suspend_access( $subscription_id ) {
		update_post_meta( $subscription_id, '_subscrpt_access_suspended', 1 );
		update_post_meta( $subscription_id, '_subscrpt_access_suspended_date', current_time( 'timestamp' ) );

		Action::status( 'on_hold', $subscription_id );

		/**
		 * Fires when a subscription's access is suspended after exhausting payment retries.
		 *
		 * @param int $subscription_id Subscription ID.
		 */
		do_action( 'subscrpt_access_suspended', $subscription_id );
	}

	/**
	 * Send failure notification email, immediately or deferred based on settings.
	 *
	 * @param int $subscription_id Subscription ID.
	 * @param int $failure_count Current failure count.
	 * @param int $max_retries Maximum retries allowed.
	 */
	private static function send_failure_notification( $subscription_id, $failure_count, $max_retries ) {
		if ( ! get_option( 'subscrpt_enable_payment_failure_emails', '1' ) ) {
			return;
		}

		$customer_id = get_post_meta( $subscription_id, '_subscrpt_user_id', true );
		$customer_id = empty( $customer_id ) ? (int) get_post_field( 'post_author', $subscription_id ) : $customer_id;

		if ( ! $customer_id ) {
			subscrpt_write_log( "PaymentFailureHandler: email skipped for subscription #{$subscription_id} — customer ID not found in meta or post_author." );
			return;
		}

		if ( ! get_user_by( 'id', $customer_id ) ) {
			subscrpt_write_log( "PaymentFailureHandler: email skipped for subscription #{$subscription_id} — customer #{$customer_id} not found." );
			return;
		}

		$email_delay_hours = (int) get_option( 'subscrpt_payment_failure_email_delay', 24 );

		// Zero delay: send immediately.
		if ( 0 === $email_delay_hours ) {
			WC()->mailer();
			do_action( 'subscrpt_payment_failure_email_notification', $subscription_id, $failure_count, $max_retries, false );
			do_action( 'subscrpt_payment_failure_notification_sent', $subscription_id, $customer_id, $failure_count );
			return;
		}

		// Delay > 0: if a pending email exists, cancel and reschedule at the same original time
		// with the updated failure count (so bursts of failures produce one email).
		// If the previous email already fired, schedule fresh from the latest failure.
		$prev_failure_count = (int) get_post_meta( $subscription_id, '_subscrpt_failure_email_scheduled_count', true );
		$prev_scheduled_at  = (int) get_post_meta( $subscription_id, '_subscrpt_failure_email_scheduled_at', true );

		$last_failure_time = get_post_meta( $subscription_id, '_subscrpt_last_payment_failure', true );
		$delay_seconds     = $email_delay_hours * HOUR_IN_SECONDS;
		$scheduled_at      = (int) $last_failure_time + $delay_seconds;

		if ( $prev_failure_count && $prev_scheduled_at ) {
			$still_pending = wp_next_scheduled(
				'subscrpt_send_delayed_failure_notification',
				array( $subscription_id, $prev_failure_count, $max_retries )
			);
			if ( $still_pending ) {
				wp_unschedule_event( $still_pending, 'subscrpt_send_delayed_failure_notification', array( $subscription_id, $prev_failure_count, $max_retries ) );
				$scheduled_at = $prev_scheduled_at; // reuse original firing time
			}
		}

		wp_schedule_single_event(
			$scheduled_at,
			'subscrpt_send_delayed_failure_notification',
			array( $subscription_id, $failure_count, $max_retries )
		);

		update_post_meta( $subscription_id, '_subscrpt_failure_email_scheduled_at', $scheduled_at );
		update_post_meta( $subscription_id, '_subscrpt_failure_email_scheduled_count', $failure_count );

		subscrpt_write_log( "PaymentFailureHandler: delayed failure email scheduled for subscription #{$subscription_id} (attempt {$failure_count}/{$max_retries}), fires_at={$scheduled_at}." );
	}

	/**
	 * Schedule hourly cron to process pending payment retries.
	 */
	public static function schedule_retry_checks() {
		if ( ! wp_next_scheduled( 'subscrpt_check_payment_retries' ) ) {
			wp_schedule_event( time(), 'hourly', 'subscrpt_check_payment_retries' );
		}
	}

	/**
	 * Process payment retries — find overdue subscriptions and attempt retry.
	 */
	public static function process_payment_retries() {
		global $wpdb;

		$current_time = current_time( 'timestamp' );

		$subscriptions = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT p.ID
			FROM {$wpdb->posts} p
			INNER JOIN {$wpdb->postmeta} pm1 ON p.ID = pm1.post_id AND pm1.meta_key = '_subscrpt_retry_scheduled'
			INNER JOIN {$wpdb->postmeta} pm2 ON p.ID = pm2.post_id AND pm2.meta_key = '_subscrpt_next_retry_time'
			WHERE p.post_type = 'subscrpt_order'
			AND pm1.meta_value = '1'
			AND pm2.meta_value <= %d",
				$current_time
			)
		);

		foreach ( $subscriptions as $subscription ) {
			self::attempt_payment_retry( $subscription->ID );
		}
	}

	/**
	 * Attempt payment retry for a single subscription.
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	private static function attempt_payment_retry( $subscription_id ) {
		delete_post_meta( $subscription_id, '_subscrpt_retry_scheduled' );
		delete_post_meta( $subscription_id, '_subscrpt_next_retry_time' );

		// The customer is already renewing early. A retry would create and charge a second renewal.
		$early_order = self::get_waiting_early_renewal_order( $subscription_id );
		if ( $early_order ) {
			$comment_id = wp_insert_comment(
				array(
					'comment_post_ID'  => $subscription_id,
					/* translators: %d: early renewal order ID */
					'comment_content'  => sprintf( __( 'Payment retry skipped. Early renewal order #%d is already open for this subscription.', 'subscription-pro' ), $early_order->get_id() ),
					'comment_type'     => 'subscrpt_note',
					'comment_approved' => 1,
					'user_id'          => 0,
				)
			);
			update_comment_meta( $comment_id, '_subscrpt_activity', 'Payment Retry Skipped' );
			update_comment_meta( $comment_id, '_subscrpt_activity_type', 'payment_retry_skipped' );
			return;
		}

		$renewal_order_id = self::create_retry_renewal_order( $subscription_id );
		if ( $renewal_order_id ) {
			$note = sprintf(
				/* translators: %d: order ID */
				__( 'Payment retry attempted. Renewal order #%d created.', 'subscription-pro' ),
				$renewal_order_id
			);
			$comment_id = wp_insert_comment(
				array(
					'comment_post_ID'  => $subscription_id,
					'comment_content'  => $note,
					'comment_type'     => 'subscrpt_note',
					'comment_approved' => 1,
					'user_id'          => 0,
				)
			);
			update_comment_meta( $comment_id, '_subscrpt_activity', 'Payment Retry' );
			update_comment_meta( $comment_id, '_subscrpt_activity_type', 'payment_retry' );

			do_action( 'subscrpt_payment_retry_attempted', $subscription_id, $renewal_order_id );
		} else {
			// The retry schedule is already cleared above, so this attempt is the last one.
			Helper::record_renewal_failure( (int) $subscription_id, __( 'Payment retry could not create a renewal order, so no further retries are scheduled.', 'subscription-pro' ) );
		}
	}

	/**
	 * Get every subscription ID tied to an order.
	 *
	 * An order created from a mixed cart can have more than one subscription
	 * relation row — this must return all of them, not just the first, so a
	 * failed order flags every subscription it created.
	 *
	 * @param int $order_id Order ID.
	 * @return int[] Subscription IDs (empty array when none found).
	 */
	public static function get_subscriptions_from_order( $order_id ) {
		global $wpdb;

		$results = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT subscription_id FROM {$wpdb->prefix}subscrpt_order_relation WHERE order_id = %d",
				$order_id
			)
		);

		return array_map( 'intval', $results );
	}

	/**
	 * Get one subscription ID from order.
	 *
	 * @deprecated Kept for back-compat with any external caller of this
	 *             public method; use get_subscriptions_from_order() instead,
	 *             which correctly returns every subscription tied to the order.
	 *
	 * @param int $order_id Order ID.
	 * @return int|null Subscription ID.
	 */
	public static function get_subscription_from_order( $order_id ) {
		$subscription_ids = self::get_subscriptions_from_order( $order_id );

		return $subscription_ids ? $subscription_ids[0] : null;
	}

	/**
	 * Check if subscription supports payment retry.
	 *
	 * @param int $subscription_id Subscription ID.
	 * @return bool True if supports retry.
	 */
	public static function supports_payment_retry( $subscription_id ) {
		$product_id = get_post_meta( $subscription_id, '_subscrpt_product_id', true );
		return (bool) $product_id;
	}

	/**
	 * Get the subscription's early renewal order that is still open.
	 *
	 * A cancelled or deleted early renewal order leaves nothing open, the same rule
	 * Helper::create_early_renewal_order() applies.
	 *
	 * @param int $subscription_id Subscription ID.
	 * @return \WC_Order|null
	 */
	private static function get_waiting_early_renewal_order( $subscription_id ) {
		$early_meta = get_post_meta( $subscription_id, '_order_waiting_early_renew_subscrpt_meta', true );
		if ( empty( $early_meta['order_id'] ) ) {
			return null;
		}

		$early_order = wc_get_order( $early_meta['order_id'] );
		if ( ! $early_order || $early_order->has_status( array( 'cancelled', 'trash' ) ) ) {
			return null;
		}

		return $early_order;
	}

	/**
	 * Create retry renewal order.
	 *
	 * Allows override via `subscrpt_create_retry_renewal_order` filter; falls back to
	 * the standard renewal-order factory so Stripe/off-session gateways auto-charge.
	 *
	 * @param int $subscription_id Subscription ID.
	 * @return int|null Renewal order ID or null.
	 */
	private static function create_retry_renewal_order( $subscription_id ) {
		$override = apply_filters( 'subscrpt_create_retry_renewal_order', null, $subscription_id );
		if ( $override ) {
			return $override;
		}

		$renewal_order = FreeHelper::create_renewal_order( $subscription_id );
		return $renewal_order ? $renewal_order->get_id() : null;
	}

	/**
	 * Log payment failure as a subscription note.
	 *
	 * @param int $subscription_id Subscription ID.
	 * @param int $failure_count Failure count.
	 */
	private static function log_payment_failure( $subscription_id, $failure_count ) {
		$note = sprintf(
			/* translators: %d: failure count */
			__( 'Payment failed (attempt %d)', 'subscription-pro' ),
			$failure_count
		);

		$comment_id = wp_insert_comment(
			array(
				'comment_post_ID'  => $subscription_id,
				'comment_content'  => $note,
				'comment_type'     => 'subscrpt_note',
				'comment_approved' => 1,
				'user_id'          => 0,
			)
		);
		update_comment_meta( $comment_id, '_subscrpt_activity', 'Payment Failed' );
		update_comment_meta( $comment_id, '_subscrpt_activity_type', 'payment_failed' );

		do_action( 'subscrpt_payment_failure_logged', $subscription_id, $failure_count );
	}

	/**
	 * Reset failure count when payment succeeds.
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	public static function reset_failure_count( $subscription_id ) {
		delete_post_meta( $subscription_id, '_subscrpt_payment_failure_count' );
		delete_post_meta( $subscription_id, '_subscrpt_last_payment_failure' );
		delete_post_meta( $subscription_id, '_subscrpt_retry_scheduled' );
		delete_post_meta( $subscription_id, '_subscrpt_next_retry_time' );
		delete_post_meta( $subscription_id, '_subscrpt_access_suspended' );
		delete_post_meta( $subscription_id, '_subscrpt_access_suspended_date' );
		delete_post_meta( $subscription_id, '_subscrpt_failure_email_scheduled_at' );
		delete_post_meta( $subscription_id, '_subscrpt_failure_email_scheduled_count' );

		do_action( 'subscrpt_payment_failure_reset', $subscription_id );
	}

	/**
	 * Check if subscription access is suspended.
	 *
	 * @param int $subscription_id Subscription ID.
	 * @return bool True if suspended.
	 */
	public static function is_access_suspended( $subscription_id ) {
		return (bool) get_post_meta( $subscription_id, '_subscrpt_access_suspended', true );
	}

	/**
	 * Send delayed failure notification via WP-Cron.
	 *
	 * @param int $subscription_id Subscription ID.
	 * @param int $failure_count Failure count.
	 * @param int $max_retries Maximum retries.
	 */
	public static function send_delayed_failure_notification( $subscription_id, $failure_count, $max_retries ) {
		// Skip if payment recovered before this delayed email fired.
		if ( 'active' === get_post_status( $subscription_id ) ) {
			return;
		}

		if ( ! get_option( 'subscrpt_enable_payment_failure_emails', '1' ) ) {
			return;
		}

		$customer_id = get_post_meta( $subscription_id, '_subscrpt_user_id', true );
		$customer_id = empty( $customer_id ) ? (int) get_post_field( 'post_author', $subscription_id ) : $customer_id;

		if ( ! $customer_id ) {
			subscrpt_write_log( "PaymentFailureHandler: delayed email skipped for subscription #{$subscription_id} — customer ID not found." );
			return;
		}

		if ( ! get_user_by( 'id', $customer_id ) ) {
			subscrpt_write_log( "PaymentFailureHandler: delayed email skipped for subscription #{$subscription_id} — customer #{$customer_id} not found." );
			return;
		}

		/**
		 * Fires to send a delayed payment failure email notification.
		 *
		 * @param int  $subscription_id Subscription ID.
		 * @param int  $failure_count   Current failure count.
		 * @param int  $max_retries     Maximum retries allowed.
		 * @param bool $is_delayed      Always true for this hook.
		 */
		delete_post_meta( $subscription_id, '_subscrpt_failure_email_scheduled_at' );
		delete_post_meta( $subscription_id, '_subscrpt_failure_email_scheduled_count' );

		WC()->mailer();
		do_action( 'subscrpt_payment_failure_email_notification', $subscription_id, $failure_count, $max_retries, true );

		do_action( 'subscrpt_delayed_payment_failure_notification_sent', $subscription_id, $customer_id, $failure_count );
	}
}
