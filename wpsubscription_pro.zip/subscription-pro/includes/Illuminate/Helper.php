<?php
/**
 * Pro subscription helper utilities.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate
 */

namespace SpringDevs\SubscriptionPro\Illuminate;

use SpringDevs\Subscription\Illuminate\Helper as FreeHelper;

/**
 * Class Helper || Some Helper Methods
 *
 * @package SpringDevs\SubscriptionPro\Illuminate
 */
class Helper {

	/**
	 * Initialize the class.
	 */
	public function __construct() {
		add_filter( 'wpsubs_cart_recurring_items', [ $this, 'get_recurrs_from_cart' ], 10, 2 );
	}

	/**
	 * Get recurring items from cart.
	 *
	 * @param array $recurrs Simple Recurring items.
	 * @param array $cart_items Cart items.
	 */
	public function get_recurrs_from_cart( $recurrs, $cart_items ) {
		foreach ( $cart_items as $key => $cart_item ) {
			$product = $cart_item['data'];
			if ( in_array( $product->get_type(), [ 'variable', 'variation' ], true ) && isset( $cart_item['subscription'] ) ) {
				$cart_subscription = $cart_item['subscription'];
				// Cadence word must respect the frequency (plan items store the raw
				// plural interval, e.g. "months"): singular for 1, plural + count above.
				$sub_time = max( 1, (int) ( $cart_subscription['time'] ?? 1 ) );
				$type     = ( 1 === $sub_time ? '' : $sub_time . ' ' ) . ucfirst( FreeHelper::get_typos( $sub_time, $cart_subscription['type'] ) );

				// Shared with simple products so both types report identical discount figures.
				// Guarded: the free plugin may not yet be updated to the version that has it.
				if ( method_exists( FreeHelper::class, 'build_cart_recurring_price_data' ) ) {
					$price_data = FreeHelper::build_cart_recurring_price_data( $cart_item, $key, $type );
				} else {
					$total_amount = wc_get_price_including_tax( $product, [ 'qty' => (int) $cart_item['quantity'] ] );
					$timing_html  = "<span class='wpsubs-subscription-timing'>&nbsp;/&nbsp;{$type}</span>";
					$price_data   = [
						'price_html' => wc_price( (float) $total_amount ) . $timing_html,
						'price'      => (float) $cart_subscription['per_cost'],
					];
				}

				$recurrs[ $key ] = array_merge(
					$price_data,
					array(
						'trial_status'    => ! is_null( $cart_subscription['trial'] ),
						'start_date'      => FreeHelper::start_date( $cart_subscription['trial'] ),
						'next_date'       => FreeHelper::next_date( ( $cart_subscription['time'] ?? 1 ) . ' ' . $cart_subscription['type'], $cart_subscription['trial'] ),
						'can_user_cancel' => $product->get_meta( '_subscrpt_user_cancel' ),
						// Plan items carry their own count, where 0 means recurring.
						'max_no_payment'  => ! empty( $cart_item['subscrpt_plan_id'] )
							? (int) ( $cart_item['subscrpt_max_no_payment'] ?? 0 )
							: $product->get_meta( '_subscrpt_max_no_payment' ),
						'quantity'        => (int) $cart_item['quantity'],
					)
				);
			}
		}

		return $recurrs;
	}

	/**
	 * Check if variable subscription exits.
	 *
	 * @param int            $variation_id Variation ID.
	 * @param string | array $status       Post Status.
	 *
	 * @return WP_Post | false
	 */
	public static function subscription_variable_exists( $variation_id, $status ) {
		if ( 0 === get_current_user_id() ) {
			return false;
		}

		$args = array(
			'post_type'   => 'subscrpt_order',
			'post_status' => $status,
			'fields'      => 'ids',
			'meta_query'  => array(
				array(
					'key'   => '_subscrpt_variation_id',
					'value' => $variation_id,
				),
			),
			'author'      => get_current_user_id(),
		);

		$posts = get_posts( $args );

		if ( count( $posts ) > 0 ) {
			return $posts[0];
		}

		return false;
	}

	/**
	 * Check trial variable subscription.
	 *
	 * @param int $variation_id Variation ID.
	 *
	 * @return bool
	 */
	public static function check_trial( $variation_id ) {
		return ! self::subscription_variable_exists( $variation_id, array( 'expired', 'pending', 'active', 'on-hold', 'cancelled' ) );
	}

	/**
	 * Create renewal order when subscription expired. [wip]
	 *
	 * @param  int $subscription_id Subscription ID.
	 * @throws \WC_Data_Exception Exception.
	 * @throws \Exception Exception.
	 */
	public static function create_early_renewal_order( int $subscription_id ) {
		$show_notice = ! is_admin() && function_exists( 'wc_add_notice' ) && WC()->session;

		// A deleted or cancelled early renewal order leaves nothing to wait for.
		$early_meta = get_post_meta( $subscription_id, '_order_waiting_early_renew_subscrpt_meta', true );
		if ( $early_meta ) {
			$early_order = wc_get_order( $early_meta['order_id'] ?? 0 );
			if ( ! $early_order || $early_order->has_status( array( 'cancelled', 'trash' ) ) ) {
				delete_post_meta( $subscription_id, '_order_waiting_early_renew_subscrpt_meta' );
			}
		}

		// Only this subscription's own renewal orders can block an early renewal.
		$pending_order = self::get_pending_renewal_order( $subscription_id );
		if ( $pending_order ) {
			if ( $show_notice ) {
				if ( $pending_order->needs_payment() ) {
					$message = sprintf(
						'%s <a href="%s" class="button">%s</a>',
						esc_html__( 'You have an existing pending payment for this subscription. Please complete your current payment to proceed.', 'subscription-pro' ),
						esc_url( $pending_order->get_checkout_payment_url() ),
						esc_html__( 'Pay Pending Order', 'subscription-pro' )
					);
					wc_add_notice( $message, 'notice' );
				} else {
					wc_add_notice( __( 'Subscription early renewal order is already processing !', 'subscription-pro' ), 'error' );
				}
			}
			return;
		}

		$source = self::get_early_renewal_source( $subscription_id );
		if ( ! $source ) {
			if ( $show_notice ) {
				wc_add_notice( __( 'Subscription renewal isn\'t possible due to previous order not completed or deletion.', 'subscription-pro' ), 'error' );
			}
			self::record_renewal_failure( $subscription_id, __( 'Early renewal: no completed order holding this subscription\'s item was found.', 'subscription-pro' ) );
			return;
		}

		$old_order     = $source['order'];
		$order_item_id = $source['order_item_id'];

		$order_item = $old_order->get_item( $order_item_id );
		if ( ! $order_item instanceof \WC_Order_Item_Product ) {
			/* translators: 1: order item ID, 2: order ID. */
			self::record_renewal_failure( $subscription_id, sprintf( __( 'Early renewal: item #%1$d on order #%2$d is not a product line.', 'subscription-pro' ), $order_item_id, $old_order->get_id() ), $old_order->get_id() );
			return;
		}

		$subscription_price = (float) get_post_meta( $subscription_id, '_subscrpt_price', true );
		$qty                = $order_item->get_quantity();

		// Subtract tax from per-unit subscription price if prices include tax. WC_Order will calculate tax on line total.
		if ( wc_prices_include_tax() ) {
			$product            = ( $order_item instanceof \WC_Order_Item_Product ) ? $order_item->get_product() : null;
			$tax_class          = $product ? $product->get_tax_class() : '';
			$tax_rates          = \WC_Tax::get_rates( $tax_class );
			$taxes              = \WC_Tax::calc_inclusive_tax( $subscription_price, $tax_rates );
			$subscription_price = $subscription_price - array_sum( $taxes );
		}

		$line_total   = $subscription_price * $qty;
		$product_args = array(
			'name'     => $order_item->get_name(),
			'subtotal' => $line_total,
			'total'    => $line_total,
		);

		// creating new order.
		// The fourth argument lets free record the cause on the subscription; a free version without it ignores it.
		$new_order_data = FreeHelper::create_new_order_for_renewal( $old_order, $order_item, $product_args, $subscription_id );
		if ( ! $new_order_data ) {
			return;
		}

		$new_order         = $new_order_data['order'];
		$new_order_item_id = $new_order_data['order_item_id'];
		$order_id          = $new_order->get_id();
		self::create_early_renewal_history( $subscription_id, $new_order->get_id(), $new_order_item_id );

		update_post_meta(
			$subscription_id,
			'_order_waiting_early_renew_subscrpt_meta',
			array(
				'order_id'      => $new_order->get_id(),
				'order_item_id' => $new_order_item_id,
			)
		);

		FreeHelper::clone_order_metadata( $new_order, $old_order );
		FreeHelper::clone_stripe_metadata_for_renewal( $subscription_id, $old_order, $new_order );

		/**
		 * Filters the early renewal order before its totals are calculated and it is saved.
		 *
		 * Deliberately separate from `subscrpt_before_saving_renewal_order`: that filter also
		 * carries gateway metadata copiers and the pending-downgrade applier, which are not
		 * wanted on an early renewal. Fired after the relation row exists, so listeners that
		 * count related orders see this order's own position in the sequence.
		 *
		 * @param \WC_Order $new_order       Early renewal order being built.
		 * @param \WC_Order $old_order       Order the renewal was cloned from.
		 * @param int       $subscription_id Subscription ID.
		 */
		$new_order = apply_filters( 'subscrpt_before_saving_early_renewal_order', $new_order, $old_order, $subscription_id );

		$new_order->calculate_totals();
		$new_order->save();

		if ( ! is_admin() && function_exists( 'wc_add_notice' ) && WC()->session ) {
			/* translators: %d: early renewal order ID. */
			$message = sprintf( __( 'Early renewal order #%d created.', 'subscription-pro' ), $order_id );
			if ( $new_order->has_status( 'pending' ) ) {
				/* translators: %s: URL of the order payment page. */
				$message .= ' ' . sprintf( __( 'Please <a href="%s">pay now</a>.', 'subscription-pro' ), esc_url( $new_order->get_checkout_payment_url() ) );
			}
			wc_add_notice( $message, 'success' );
		}

		do_action( 'subscrpt_after_create_renew_order', $new_order, $old_order, $subscription_id, true );
	}

	/**
	 * Get the subscription's own renewal order that is still awaiting payment or completion.
	 *
	 * Orders belonging to other subscriptions or purchases are never considered, and
	 * deleted or cancelled orders do not count.
	 *
	 * @param int $subscription_id Subscription ID.
	 *
	 * @return \WC_Order|null
	 */
	public static function get_pending_renewal_order( int $subscription_id ) {
		foreach ( FreeHelper::get_related_orders( $subscription_id ) as $row ) {
			if ( ! in_array( $row->type ?? '', array( 'renew', 'early-renew' ), true ) ) {
				continue;
			}

			$order = wc_get_order( (int) ( $row->order_id ?? 0 ) );
			if ( $order && $order->has_status( array( 'pending', 'failed', 'on-hold', 'processing' ) ) ) {
				return $order;
			}
		}

		return null;
	}

	/**
	 * Get the completed order an early renewal is cloned from.
	 *
	 * Uses the subscription's current order when it is completed, otherwise the newest
	 * completed order in the subscription's own history.
	 *
	 * @param int $subscription_id Subscription ID.
	 *
	 * @return array|null { order: \WC_Order, order_item_id: int }
	 */
	public static function get_early_renewal_source( int $subscription_id ) {
		$candidates = array(
			(int) get_post_meta( $subscription_id, '_subscrpt_order_item_id', true ),
		);
		foreach ( FreeHelper::get_related_orders( $subscription_id ) as $row ) {
			$candidates[] = (int) ( $row->order_item_id ?? 0 );
		}

		foreach ( array_unique( array_filter( $candidates ) ) as $order_item_id ) {
			$order = wc_get_order( wc_get_order_id_by_order_item_id( $order_item_id ) );
			if ( $order && 'completed' === $order->get_status() && $order->get_item( $order_item_id ) ) {
				return array(
					'order'         => $order,
					'order_item_id' => $order_item_id,
				);
			}
		}

		return null;
	}

	/**
	 * Record why a renewal failed, on the subscription and in the WooCommerce log.
	 *
	 * Free's recorder writes the activity note. A free version that predates it
	 * gets the `wp_subscription` log entry only.
	 *
	 * @param int    $subscription_id Subscription ID.
	 * @param string $reason          Why the renewal failed, as a full sentence.
	 * @param int    $source_order_id Order the renewal was being created from, if known.
	 *
	 * @return void
	 */
	public static function record_renewal_failure( int $subscription_id, string $reason, int $source_order_id = 0 ) {
		if ( method_exists( FreeHelper::class, 'record_renewal_failure' ) ) {
			FreeHelper::record_renewal_failure( $subscription_id, $reason, $source_order_id );
			return;
		}

		wc_get_logger()->error(
			sprintf( 'Renewal failed. %s [ Subscription ID: %d, Source order ID: %d ]', $reason, $subscription_id, $source_order_id ),
			[ 'source' => 'wp_subscription' ]
		);
	}

	/**
	 * Create history for renewal.
	 *
	 * @param int $subscription_id Subscription Id.
	 * @param int $new_order_id New Order Id.
	 * @param int $new_order_item_id New Order Item Id.
	 *
	 * @return void
	 */
	public static function create_early_renewal_history( $subscription_id, $new_order_id, $new_order_item_id ) {
		global $wpdb;
		$history_table = $wpdb->prefix . 'subscrpt_order_relation';
		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$history_table,
			array(
				'subscription_id' => $subscription_id,
				'order_id'        => $new_order_id,
				'order_item_id'   => $new_order_item_id,
				'type'            => 'early-renew',
			)
		);

		$comment_id = wp_insert_comment(
			array(
				'comment_author'  => 'Subscription for WooCommerce',
				'comment_content' => sprintf( 'Subscription early renewal order created. order is %s', $new_order_id ),
				'comment_post_ID' => $subscription_id,
				'comment_type'    => 'order_note',
			)
		);
		update_comment_meta( $comment_id, '_subscrpt_activity', 'Early Renewal Order' );
		update_comment_meta( $comment_id, '_subscrpt_activity_type', 'renewal_order_early' );

		// Fire action when early renewal is triggered
		do_action( 'subscrpt_split_payment_early_renew_triggered', $subscription_id, $new_order_id, $new_order_item_id );
	}

	/**
	 * Whether an order's customer owns a subscription.
	 *
	 * A switch order may only change the subscription of the customer who placed it.
	 *
	 * @param int           $subscription_id Subscription ID.
	 * @param \WC_Order|int $order           Order or order ID.
	 *
	 * @return bool
	 */
	public static function order_customer_owns_subscription( int $subscription_id, $order ): bool {
		$order = $order instanceof \WC_Order ? $order : wc_get_order( $order );
		if ( ! $order || ! $subscription_id || 'subscrpt_order' !== get_post_type( $subscription_id ) ) {
			return false;
		}

		$customer_id = (int) $order->get_customer_id();

		return $customer_id > 0 && (int) get_post_field( 'post_author', $subscription_id ) === $customer_id;
	}

	/**
	 * Process switch order.
	 *
	 * @param int   $subscription_id Subscription Id.
	 * @param int   $order_id Order Id.
	 * @param int   $order_item_id Order Item Id.
	 * @param array $switch_context Switch Context.
	 *
	 * @return bool False when the order's customer does not own the subscription.
	 */
	public static function process_switch_order( int $subscription_id, int $order_id, int $order_item_id, array $switch_context ) {
		global $wpdb;

		if ( ! self::order_customer_owns_subscription( $subscription_id, $order_id ) ) {
			return false;
		}
		$history_table = $wpdb->prefix . 'subscrpt_order_relation';

		$switch_type = $switch_context['switch_type'] ?? 'upgrade';

		$switch_comment = 'upgrade' === $switch_type
							? __( 'Subscription upgrade order successfully created.', 'subscription-pro' )
							: __( 'Subscription downgrade order successfully created.', 'subscription-pro' );

		$subscription_switch_comment_meta      = 'upgrade' === $switch_type
											? __( 'Subscription Upgrade Order', 'subscription-pro' )
											: __( 'Subscription Downgrade Order', 'subscription-pro' );
		$subscription_switch_comment_meta_type = 'upgrade' === $switch_type
											? 'upgrade_order' : 'downgrade_order';

		$comment_id = wp_insert_comment(
			array(
				'comment_author'  => 'Subscription for WooCommerce',
				'comment_content' => sprintf(
					// translators: 1: Switch Type, 2: Order ID.
					__( '%1$s Order #%2$s', 'subscription-pro' ),
					$switch_comment,
					$order_id
				),
				'comment_post_ID' => $subscription_id,
				'comment_type'    => 'order_note',
			)
		);

		update_comment_meta( $comment_id, '_subscrpt_activity', $subscription_switch_comment_meta );
		update_comment_meta( $comment_id, '_subscrpt_activity_type', $subscription_switch_comment_meta_type );

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$history_table,
			array(
				'subscription_id' => $subscription_id,
				'order_id'        => $order_id,
				'order_item_id'   => $order_item_id,
				'type'            => $switch_context['switch_type'] ?? 'upgrade',
			)
		);

		return true;
	}

	/**
	 * Activity title to activity type mapping.
	 *
	 * ! (⁠╯⁠°⁠□⁠°⁠）⁠╯⁠︵⁠ ⁠┻⁠━⁠┻
	 *
	 * @param string $activity_title Activity Title.
	 * @return null|string Activity Type.
	 */
	protected static function get_activity_type( $activity_title ) {
		$mapping = [
			'New Subscription'                  => 'subs_created',
			'Subscription Activated'            => 'subs_activated',
			'Subscription Pending'              => 'subs_pending',
			'Subscription Cancelled'            => 'subs_cancelled',
			'Subscription Pending Cancellation' => 'subs_pe_cancel',
			'Subscription Expired'              => 'subs_expired',

			'Renewal Order'                     => 'renewal_order',
			'Early Renewal Order'               => 'early_renewal_order',
			'Early Renewal Cancelled'           => 'early_renewal_cancelled',
			'Renewal Count Updated'             => 'renewal_count',

			'Subscription Upgrade Order'        => 'upgrade_order',
			'Subscription Downgrade Order'      => 'downgrade_order',

			'Split Payment - Plan Complete (Lifetime Access)' => 'split_payment',
			'Split Payment - Plan Complete (Full Duration)' => 'split_payment',
			'Split Payment - Plan Complete (Custom Duration)' => 'split_payment',
			'Payment Summary - Complete'        => 'split_payment',
		];

		return $mapping[ $activity_title ] ?? null;
	}

	/**
	 * Get subscription activities.
	 *
	 * All activity types
	 * - subs_created, subs_activated, subs_pending, subs_cancelled, subs_pe_cancel, subs_expired,
	 * - renewal_order, early_renewal_order, early_renewal_cancelled, renewal_count,
	 * - upgrade_order, downgrade_order,
	 * - split_payment
	 *
	 * @param int   $subscription_id Subscription Id.
	 * @param array $include_types Include Types.
	 * @param array $exclude_types Exclude Types.
	 * @return array
	 */
	public static function get_subscription_activities( $subscription_id, $include_types = [], $exclude_types = [] ) {
		// Get all comments for the subscription.
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$activities = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->comments} WHERE comment_post_ID = %d ORDER BY comment_ID DESC",
				$subscription_id
			),
			ARRAY_A
		);

		// Normalize activities from comments.
		$normalized_activities = [];
		foreach ( $activities as $activity ) {
			$subscrpt_activity      = get_comment_meta( $activity['comment_ID'], '_subscrpt_activity', true );
			$subscrpt_activity_type = get_comment_meta( $activity['comment_ID'], '_subscrpt_activity_type', true );

			// Migration.
			if ( empty( $subscrpt_activity_type ) ) {
				$subscrpt_activity_type = self::get_activity_type( $subscrpt_activity );

				if ( ! empty( $subscrpt_activity_type ) ) {
					update_comment_meta( $activity['comment_ID'], '_subscrpt_activity_type', $subscrpt_activity_type );
				} else {
					// Skip if no mapping found.
					continue;
				}
			}

			$normalized_activities[] = [
				'id'          => $activity['comment_ID'],
				'type'        => $subscrpt_activity_type,
				'title'       => $subscrpt_activity,
				'description' => $activity['comment_content'],
				'date'        => $activity['comment_date'],
			];
		}

		// Filter activities based on include and exclude types.
		$filtered_activities = $normalized_activities;
		if ( ! empty( $include_types ) ) {
			foreach ( $filtered_activities as $key => $activity ) {
				if ( ! in_array( $activity['type'], $include_types, true ) ) {
					unset( $filtered_activities[ $key ] );
				}
			}
		}
		if ( ! empty( $exclude_types ) ) {
			foreach ( $filtered_activities as $key => $activity ) {
				if ( in_array( $activity['type'], $exclude_types, true ) ) {
					unset( $filtered_activities[ $key ] );
				}
			}
		}

		return $filtered_activities;
	}

	/**
	 * Whether a product / variation is offered through a plan.
	 *
	 * Guarded: older free versions don't have `subscrpt_plan_offered()`.
	 *
	 * @param int $product_id   Product id.
	 * @param int $variation_id Variation id (0 for a simple product).
	 * @return bool
	 */
	public static function plan_offered( $product_id, $variation_id = 0 ) {
		if ( ! function_exists( 'subscrpt_plan_offered' ) ) {
			return false;
		}

		return subscrpt_plan_offered( $product_id, $variation_id );
	}

	/**
	 * Whether a resolved plan row's free trial applies at checkout.
	 *
	 * Installments have no trial. A signup fee is charged together with the first
	 * payment, so a plan with one starts billing now and its trial does not apply.
	 *
	 * @param array  $row      Resolved plan row.
	 * @param string $type_key Plan type key.
	 * @return bool
	 */
	public static function plan_trial_applies( $row, $type_key ) {
		if ( 'installments' === $type_key || empty( $row['free_trial'] ) || (int) $row['free_trial'] <= 0 ) {
			return false;
		}

		return empty( $row['signup_fee'] ) || ! is_array( $row['signup_fee'] ) || empty( $row['signup_fee']['amount'] );
	}
}
