<?php
/**
 * Cancellation timing handler.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate
 */

namespace SpringDevs\SubscriptionPro\Illuminate;

/**
 * Overrides the free plugin's default cancellation timing.
 *
 * The free plugin schedules a pending cancellation to finalise 24 hours later and
 * exposes the moment via the `subscrpt_cancellation_time` filter. This class
 * registers the `subscrpt_cancellation_delay` setting and maps it onto that filter:
 *
 *  - `instant` : cancel immediately.
 *  - `period`  : cancel at the end of the billing period (next renewal date).
 *  - `24h`     : cancel 24 hours later (default).
 *
 * When Pro is inactive the filter is absent and the free 24-hour default applies,
 * so the free cancellation flow is unchanged.
 *
 * @package SpringDevs\SubscriptionPro\Illuminate
 */
class Cancellation {

	/**
	 * Initialize the class.
	 */
	public function __construct() {
		add_action( 'admin_init', [ $this, 'register_settings' ] );
		add_filter( 'subscrpt_cancellation_time', [ $this, 'filter_cancellation_time' ], 10, 2 );
	}

	/**
	 * Register the cancellation-delay setting, and the reason list for an older free.
	 *
	 * @return void
	 */
	public function register_settings() {
		// Both live on free's Cancellation Flow page, which owns its own settings
		// group. options.php nulls every option registered in the group it is
		// handed but absent from the POST, so registering these against
		// `wp_subscription_settings` would mean a Settings save wiped them.
		$group = class_exists( '\\SpringDevs\\Subscription\\Admin\\CancellationFlow' )
			? \SpringDevs\Subscription\Admin\CancellationFlow::OPTION_GROUP
			: 'wp_subscription_cancellation_settings';

		register_setting(
			$group,
			'subscrpt_cancellation_delay',
			[
				'type'              => 'string',
				'default'           => '24h',
				'sanitize_callback' => [ $this, 'sanitize_cancellation_delay' ],
			]
		);

		// The reason list is free's now: free registers and sanitizes it itself
		// from the version that ships CancellationFlow::sanitize_reasons(). On an
		// older free nothing else registers it, and options.php would drop the
		// posted list, so pro still does there. Stores update the two plugins
		// independently, and pro has no minimum-free-version gate.
		if ( ! method_exists( '\\SpringDevs\\Subscription\\Admin\\CancellationFlow', 'sanitize_reasons' ) ) {
			register_setting(
				$group,
				'subscrpt_cancellation_reasons',
				[
					'type'              => 'array',
					'default'           => [],
					'sanitize_callback' => [ $this, 'sanitize_cancellation_reasons' ],
				]
			);
		}
	}

	/**
	 * Sanitize the cancellation-reasons list — only registered against an older free.
	 *
	 * The settings form submits the ordered list as a JSON string from the reasons
	 * editor. Each label is sanitized, each key is derived from the provided slug
	 * (or the label) and de-duplicated. Empty labels are dropped.
	 *
	 * @param mixed $value Raw value (JSON string or array).
	 * @return array<int,array{key:string,label:string}>
	 */
	public function sanitize_cancellation_reasons( $value ) {
		$decoded = is_string( $value ) ? json_decode( wp_unslash( $value ), true ) : $value;
		if ( ! is_array( $decoded ) ) {
			return [];
		}

		$reasons = [];
		$seen    = [];
		foreach ( $decoded as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			$label = isset( $item['label'] ) ? sanitize_text_field( $item['label'] ) : '';
			if ( '' === $label ) {
				continue;
			}

			$key = ! empty( $item['key'] ) ? sanitize_key( $item['key'] ) : sanitize_key( $label );
			if ( '' === $key || isset( $seen[ $key ] ) ) {
				$key = $key . '_' . count( $reasons );
			}
			$seen[ $key ] = true;

			$reasons[] = [
				'key'   => $key,
				'label' => $label,
			];
		}

		return $reasons;
	}

	/**
	 * Sanitize the cancellation-delay setting against the allowed options.
	 *
	 * @param mixed $value Raw value.
	 * @return string One of: instant, period, 24h.
	 */
	public function sanitize_cancellation_delay( $value ) {
		return in_array( $value, [ 'instant', 'period', '24h' ], true ) ? $value : '24h';
	}

	/**
	 * Resolve the cancellation timestamp from the configured delay.
	 *
	 * @param int $default_time    Free plugin default (24 hours from now).
	 * @param int $subscription_id Subscription ID.
	 * @return int Unix timestamp; at or before now means cancel immediately.
	 */
	public function filter_cancellation_time( $default_time, $subscription_id ) {
		$delay = \SpringDevs\Subscription\Illuminate\Cancellation::get_settings( 'subscrpt_cancellation_delay' );
		if ( empty( $delay ) ) {
			$delay = '24h';
		}

		switch ( $delay ) {
			case 'instant':
				return time();

			case 'period':
				$next_date = (int) get_post_meta( (int) $subscription_id, '_subscrpt_next_date', true );
				return $next_date > 0 ? $next_date : (int) $default_time;

			case '24h':
			default:
				return (int) $default_time;
		}
	}
}
