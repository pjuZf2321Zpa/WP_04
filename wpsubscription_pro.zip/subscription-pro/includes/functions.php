<?php
/**
 * Global helper functions: form fields, HTML attributes, Live QR styles and SVG kses rules.
 *
 * @package SpringDevs\SubscriptionPro
 */

/**
 * Recurring field.
 *
 * @param array $args Arguments.
 *
 * @return void
 */
function sdevs_subscrpt_recurring_field( $args = array() ) {
	$args = wp_parse_args(
		$args,
		array(
			'class' => '',
			'time'  => array(
				'label' => '',
				'name'  => '',
				'value' => null,
				'attrs' => array(),
			),
			'type'  => array(
				'name'    => '',
				'value'   => null,
				'options' => array(),
			),
			'desc'  => '',
		)
	);

	$time_attrs = sdevs_subscrpt_array_to_attrs( $args['time']['attrs'] );
	?>
	<p class="form-field subscrpt_field <?php echo esc_attr( $args['class'] ); ?>">
		<label
			for="<?php echo esc_attr( $args['time']['name'] ); ?>"><?php echo esc_html( $args['time']['label'] ); ?></label>
		<input type="number" class="short" name="<?php echo esc_attr( $args['time']['name'] ); ?>"
				id="<?php echo esc_attr( $args['time']['name'] ); ?>"
				value="<?php echo esc_attr( $args['time']['value'] ); ?>" <?php echo esc_attr( $time_attrs ); ?> />
		<select name="<?php echo esc_attr( $args['type']['name'] ); ?>"
				id="<?php echo esc_attr( $args['type']['name'] ); ?>">
			<?php foreach ( $args['type']['options'] as $timing_type ) : ?>
				<option value="<?php echo esc_attr( $timing_type['value'] ); ?>"
					<?php
					if ( $args['type']['value'] === $timing_type['value'] ) {
						echo 'selected';
					}
					?>
				>
					<?php echo esc_html( $timing_type['label'] ); ?>
				</option>
			<?php endforeach; ?>
		</select>
		<small
			class="description"><?php echo esc_html( $args['desc'] ); ?></small>
	</p>
	<?php
}

/**
 * Convert an array to an HTML attribute string. A true value prints the bare key, false prints nothing.
 *
 * @param array $attributes Attribute names mapped to values.
 *
 * @return string
 */
function sdevs_subscrpt_array_to_attrs( array $attributes ): string {
	return join(
		' ',
		array_map(
			function ( $key ) use ( $attributes ) {
				if ( is_bool( $attributes[ $key ] ) ) {
						return $attributes[ $key ] ? $key : '';
				}

				return $key . '=' . $attributes[ $key ];
			},
			array_keys( $attributes )
		)
	);
}

/**
 * Enqueue the Live QR stylesheet (its templates use it).
 */
function subscrpt_pro_live_qr_styles() {
	wp_enqueue_style( 'wpsubs-pro-live-qr', SUBSCRIPT_PRO_ASSETS . '/css/live-qr.css', [], SUBSCRIPT_PRO_VERSION );
}

/**
 * Allowed HTML for admin markup that contains inline SVG icons.
 *
 * `wp_kses_post()` has no SVG in its allowlist, so running icon markup through
 * it silently removes the `<svg>` and leaves an empty box — which is exactly
 * what happened to the header stat cards. This is the post allowlist plus the
 * handful of SVG elements and attributes the admin icons actually use.
 *
 * Escaping is not dropped here: the markup still passes through kses, so an
 * `onload` or a `<script>` in a translated string cannot survive.
 *
 * @return array<string, array<string, bool>> Allowed tags and attributes.
 */
function subscrpt_pro_kses_svg(): array {
	$svg_attrs = array(
		'xmlns'           => true,
		'width'           => true,
		'height'          => true,
		'viewbox'         => true,
		'fill'            => true,
		'stroke'          => true,
		'stroke-width'    => true,
		'stroke-linecap'  => true,
		'stroke-linejoin' => true,
		'class'           => true,
		'aria-hidden'     => true,
		'focusable'       => true,
		'role'            => true,
	);

	return array_merge(
		wp_kses_allowed_html( 'post' ),
		array(
			'svg'      => $svg_attrs,
			'g'        => $svg_attrs,
			'path'     => array_merge( $svg_attrs, array( 'd' => true ) ),
			'circle'   => array_merge(
				$svg_attrs,
				array(
					'cx' => true,
					'cy' => true,
					'r'  => true,
				)
			),
			'rect'     => array_merge(
				$svg_attrs,
				array(
					'x'  => true,
					'y'  => true,
					'rx' => true,
					'ry' => true,
				)
			),
			'line'     => array_merge(
				$svg_attrs,
				array(
					'x1' => true,
					'y1' => true,
					'x2' => true,
					'y2' => true,
				)
			),
			'polyline' => array_merge( $svg_attrs, array( 'points' => true ) ),
			'polygon'  => array_merge( $svg_attrs, array( 'points' => true ) ),
		)
	);
}
