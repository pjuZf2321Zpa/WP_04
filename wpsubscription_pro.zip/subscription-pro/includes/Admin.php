<?php
/**
 * Admin context loader.
 *
 * @package SpringDevs\SubscriptionPro
 */

namespace SpringDevs\SubscriptionPro;

use SpringDevs\SubscriptionPro\Admin\Boxes;
use SpringDevs\SubscriptionPro\Admin\Delivery;
use SpringDevs\SubscriptionPro\Admin\Product;
use SpringDevs\SubscriptionPro\Admin\SubscriptionBox;
use SpringDevs\SubscriptionPro\Admin\Health;
use SpringDevs\SubscriptionPro\Admin\License;
use SpringDevs\SubscriptionPro\Admin\Settings;
use SpringDevs\SubscriptionPro\Admin\Subscriptions;
use SpringDevs\SubscriptionPro\Admin\Update;
use SpringDevs\SubscriptionPro\Frontend\BoxTogetherSection;

/**
 * The admin class
 */
class Admin {
	/**
	 * Initialize the class
	 */
	public function __construct() {
		Illuminate::get_instance();

		new Update();
		new Product();
		new Subscriptions();
		new Settings();
		new Delivery();
		new Boxes();
		new SubscriptionBox();
		new Health();
		new License();

		add_action( 'init', [ BoxTogetherSection::class, 'register_block' ] );
		BoxTogetherSection::register_setting_hooks();
	}
}
