<?php
/**
 * Plugin installer — versioning, cron schedules, and plan table creation.
 *
 * @package SpringDevs\SubscriptionPro
 */

namespace SpringDevs\SubscriptionPro;

use SpringDevs\SubscriptionPro\Illuminate\Box\BoxRepository;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxSizeMigration;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxTogether;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxStepRepository;
use SpringDevs\SubscriptionPro\Illuminate\Box\EditionRepository;
use SpringDevs\SubscriptionPro\Illuminate\Box\ShipmentRepository;

/**
 * Class Installer
 *
 * @package SpringDevs\SubscriptionPro
 */
class Installer {

	/**
	 * Pro schema version. Bump when any Pro-owned table changes.
	 *
	 * 1.1.0 adds `subscrpt_box_edition`.
	 * 1.2.0 adds `subscrpt_box` and `subscrpt_box_relation` — a box stops being
	 * a product carrying meta and becomes a record products connect to.
	 * 1.3.0 converts the boxes that were left behind in product meta, which
	 * would otherwise stop being boxes the moment the read path goes.
	 * 1.4.0 adds `subscrpt_box_shipment` — until now nothing recorded that a box
	 * went out, so a failed one had nowhere to live.
	 * 1.5.0 gives `subscrpt_box_edition` a `box_id`. Editions were keyed on the
	 * product that sold them, which two boxes on one product would share, and
	 * which the admin had already stopped agreeing with.
	 * 1.6.0 adds `subscrpt_box_step` — the steps a box is built in. A box with
	 * no step rows still behaves exactly as it did, so nothing is migrated.
	 * 1.7.0 runs `BoxSizeMigration`: one bound alone now means at least / at most,
	 * so boxes saved under the old exact-count reading get both bounds written.
	 * 1.8.0 gives `subscrpt_box_shipment` a `standalone_item_id` and moves its
	 * unique key onto it, so a box bought once can have a shipment.
	 * 1.9.0 schedules `subscrpt_box_pairs_nightly`, the rebuild of the
	 * Frequently Bought Together index; an install upgrading from before it
	 * never ran the activation hook that registers schedules.
	 *
	 * @var string
	 */
	const DB_VERSION = '1.9.0';

	/**
	 * Run the installer
	 *
	 * @return void
	 */
	public function run() {
		$this->add_version();
		$this->register_schedules();
		$this->create_tables();
	}

	/**
	 * Add time and version on DB
	 */
	public function add_version() {
		$installed = get_option( 'subscription_pro_installed' );

		if ( ! $installed ) {
			update_option( 'subscription_pro_installed', time() );
		}

		update_option( 'subscription_pro_version', SUBSCRIPT_PRO_VERSION );
	}

	/**
	 * Register schedules
	 *
	 * @return void
	 */
	public function register_schedules() {
		if ( ! wp_next_scheduled( 'subscrpt_generate_delivery_schedule' ) ) {
			wp_schedule_event( time(), 'hourly', 'subscrpt_generate_delivery_schedule' );
		}

		if ( ! wp_next_scheduled( 'subscrpt_renew_reminder_cron' ) ) {
			wp_schedule_event( time(), 'daily', 'subscrpt_renew_reminder_cron' );
		}

		if ( ! wp_next_scheduled( 'subscrpt_box_notice_cron' ) ) {
			wp_schedule_event( time(), 'daily', 'subscrpt_box_notice_cron' );
		}

		if ( ! wp_next_scheduled( BoxTogether::NIGHTLY_HOOK ) ) {
			wp_schedule_event( time(), 'daily', BoxTogether::NIGHTLY_HOOK );
		}
	}

	/**
	 * Create / upgrade plan tables on a normal request when the schema version
	 * is behind. The activation hook does not fire on existing installs, so this
	 * keeps the plan tables in sync after a plugin update.
	 *
	 * Hooked on `plugins_loaded` via the main bootstrap.
	 *
	 * @return void
	 */
	public static function maybe_upgrade() {
		if ( get_option( 'subscrpt_pro_db_version' ) === self::DB_VERSION ) {
			return;
		}

		( new self() )->create_tables();
	}

	/**
	 * Create necessary database tables
	 *
	 * @return void
	 */
	public function create_tables() {
		// The three plan tables (subscrpt_plan_group / subscrpt_plan /
		// subscrpt_plan_relation) are created by the free plugin's installer, which
		// Pro always runs alongside — Pro no longer duplicates that DDL. Pro-only
		// tables and column migrations belong here, tracked separately via the
		// `subscrpt_pro_db_version` option.
		BoxRepository::create_tables();
		EditionRepository::create_table();
		ShipmentRepository::create_table();
		ShipmentRepository::migrate_one_time_key();
		BoxStepRepository::create_table();
		BoxSizeMigration::run();

		// Converting the legacy meta boxes does NOT belong here. It has to read
		// products and their variations, and this runs at `plugins_loaded`,
		// before WooCommerce registers its post types — `wc_get_product()` there
		// returns nothing useful and the conversion loses per-variation sizes
		// without saying a word. The bootstrap hooks it on `woocommerce_init`.

		// An install that upgraded rather than activated never ran the
		// activation hook, so the box cron is scheduled here too.
		$this->register_schedules();

		update_option( 'subscrpt_pro_db_version', self::DB_VERSION );
	}
}
