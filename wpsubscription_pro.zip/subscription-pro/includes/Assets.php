<?php
/**
 * Scripts and styles.
 *
 * @package SpringDevs\SubscriptionPro
 */

namespace SpringDevs\SubscriptionPro;

/**
 * Scripts and Styles Class
 */
class Assets {

	/**
	 * Assets constructor.
	 */
	public function __construct() {
		if ( is_admin() ) {
			add_action( 'admin_enqueue_scripts', array( $this, 'register' ), 5 );
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ), 5 );
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_page_css' ) );
		} else {
			add_action( 'wp_enqueue_scripts', array( $this, 'register' ), 5 );
		}

		// Development only: bust the cache per file change. See version_asset_src().
		if ( false !== strpos( SUBSCRIPT_PRO_VERSION, '#WPSUBS' ) ) {
			add_filter( 'script_loader_src', array( $this, 'version_asset_src' ) );
			add_filter( 'style_loader_src', array( $this, 'version_asset_src' ) );
		}
	}

	/**
	 * Register our app scripts and styles
	 *
	 * @return void
	 */
	public function register() {
		$this->register_scripts( $this->get_scripts() );
		$this->localize_scripts();
		$this->register_styles( $this->get_styles() );
	}

	/**
	 * Register scripts
	 *
	 * @param array $scripts scripts.
	 *
	 * @return void
	 */
	private function register_scripts( $scripts ) {
		foreach ( $scripts as $handle => $script ) {
			$deps      = isset( $script['deps'] ) ? $script['deps'] : false;
			$in_footer = isset( $script['in_footer'] ) ? $script['in_footer'] : false;
			$version   = isset( $script['version'] ) ? $script['version'] : SUBSCRIPT_PRO_VERSION;

			wp_register_script( $handle, $script['src'], $deps, $version, $in_footer );

			if ( in_array( 'wp-i18n', (array) $deps, true ) ) {
				wp_set_script_translations( $handle, 'subscription-pro', SUBSCRIPT_PRO_PATH . '/languages' );
			}
		}
	}

	/**
	 * Hand the scripts the words they say.
	 *
	 * The replace prompt is shared by every place a box can be changed, so its
	 * words are attached to the script itself rather than to a page.
	 *
	 * @return void
	 */
	private function localize_scripts(): void {
		wp_localize_script(
			'subscrpt_box_replace_prompt_js',
			'subscrptBoxReplaceText',
			array(
				/* translators: %s: name of the item being added. */
				'title'   => __( 'Your box is full. Replace one of these with %s?', 'subscription-pro' ),
				/* translators: %s: name of the item in the box. */
				'replace' => __( 'Replace %s', 'subscription-pro' ),
				/* translators: %d: how many of the item the box holds. */
				'count'   => __( '× %d', 'subscription-pro' ),
				'keep'    => __( 'Keep my box', 'subscription-pro' ),
				'once'    => __( 'next box only', 'subscription-pro' ),
			)
		);

		wp_localize_script(
			'subscrpt_box_add_js',
			'subscrptBoxAddText',
			array(
				/* translators: %s: name of the item added to the box. */
				'added'   => __( 'Added %s to your box.', 'subscription-pro' ),
				/* translators: %s: name of the item. */
				'present' => __( '%s is already in your box.', 'subscription-pro' ),
				'view'    => __( 'View cart', 'subscription-pro' ),
				'cartUrl' => function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : '',
				'failed'  => __( 'Your box could not be changed. Try again.', 'subscription-pro' ),
			)
		);

		wp_localize_script(
			'subscrpt_box_together_js',
			'subscrptBoxTogetherText',
			array(
				/* translators: %d: number of items added to the box. */
				'addedOne'    => __( 'Added %d item to your box.', 'subscription-pro' ),
				/* translators: %d: number of items added to the box. */
				'addedMany'   => __( 'Added %d items to your box.', 'subscription-pro' ),
				'present'     => __( 'Already in your box.', 'subscription-pro' ),
				/* translators: 1: name of the product unticked, 2: name of the product ticked in its place. */
				'swapped'     => __( '%1$s was replaced by %2$s.', 'subscription-pro' ),
				'view'        => __( 'View cart', 'subscription-pro' ),
				'cartUrl'     => function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : '',
				'failed'      => __( 'Your box could not be changed. Try again.', 'subscription-pro' ),
				'failedPrice' => __( 'The price could not be worked out. Try again.', 'subscription-pro' ),
			)
		);

		wp_localize_script(
			'subscrpt_box_next_add_js',
			'subscrptBoxNextAdd',
			array(
				'url'         => class_exists( 'WC_AJAX' ) ? \WC_AJAX::get_endpoint( 'subscrpt_box_next_add' ) : add_query_arg( 'wc-ajax', 'subscrpt_box_next_add', home_url( '/' ) ),
				/* translators: %s: name of the item added to the next box. */
				'added'       => __( 'Added %s to your next box.', 'subscription-pro' ),
				/* translators: %s: name of the item. */
				'present'     => __( '%s is already in your next box.', 'subscription-pro' ),
				/* translators: %s: name of the item added to the next box only. */
				'addedOnce'   => __( 'Added %s to your next box only.', 'subscription-pro' ),
				/* translators: %s: name of the item. */
				'presentOnce' => __( '%s is already in your next box only.', 'subscription-pro' ),
				'view'        => __( 'View your box', 'subscription-pro' ),
				'failed'      => __( 'Your box could not be changed. Try again.', 'subscription-pro' ),
			)
		);

		wp_localize_script(
			'subscrpt_box_account_add_js',
			'subscrptBoxAccountAdd',
			array(
				'failed' => __( 'The price could not be worked out. Try again.', 'subscription-pro' ),
			)
		);
	}

	/**
	 * Register styles
	 *
	 * @param array $styles styles.
	 *
	 * @return void
	 */
	public function register_styles( $styles ) {
		foreach ( $styles as $handle => $style ) {
			$deps = isset( $style['deps'] ) ? $style['deps'] : false;

			wp_register_style( $handle, $style['src'], $deps, SUBSCRIPT_PRO_VERSION );
		}
	}

	/**
	 * Give this plugin's assets a version that actually changes in development.
	 *
	 * `SUBSCRIPT_PRO_VERSION` is a build-time placeholder in a git checkout, so
	 * every asset is served under the same, never-changing version string and the
	 * browser keeps its cached copy through edit after edit — e.g. admin-pages.css
	 * appearing to override newer styles when it is simply stale. Rewriting the
	 * `ver` to the file mtime busts that. On a release build the placeholder is
	 * gone and the src is returned untouched.
	 *
	 * @param string $src Asset URL, with or without a `ver` argument.
	 * @return string
	 */
	public function version_asset_src( $src ) {
		if ( false === strpos( SUBSCRIPT_PRO_VERSION, '#WPSUBS' ) ) {
			return $src;
		}

		if ( ! is_string( $src ) || 0 !== strpos( $src, SUBSCRIPT_PRO_ASSETS ) ) {
			return $src;
		}

		$path = SUBSCRIPT_PRO_PATH . '/assets' . strtok( substr( $src, strlen( SUBSCRIPT_PRO_ASSETS ) ), '?' );

		if ( ! file_exists( $path ) ) {
			return $src;
		}

		return add_query_arg( 'ver', (string) filemtime( $path ), $src );
	}

	/**
	 * Get all registered scripts
	 *
	 * @return array
	 */
	public function get_scripts(): array {
		$plugin_js_assets_path = SUBSCRIPT_PRO_ASSETS . '/js/';

		return array(
			'subscrpt_admin_product_js'      => array(
				'src'       => $plugin_js_assets_path . 'admin/product.js',
				'deps'      => array( 'jquery' ),
				'in_footer' => true,
			),
			'subscrpt_admin_delivery_js'     => array(
				'src'       => $plugin_js_assets_path . 'admin/delivery.js',
				'deps'      => array( 'jquery', 'wp-i18n' ),
				'in_footer' => true,
			),
			'subscrpt_box_builder_js'        => array(
				'src'       => $plugin_js_assets_path . 'box-builder.js',
				'deps'      => array(),
				'in_footer' => true,
			),
			'subscrpt_box_add_card_js'       => array(
				'src'       => $plugin_js_assets_path . 'box-add-card.js',
				'deps'      => array(),
				'in_footer' => true,
			),
			'subscrpt_box_replace_prompt_js' => array(
				'src'       => $plugin_js_assets_path . 'box-replace-prompt.js',
				'deps'      => array(),
				'in_footer' => true,
			),
			'subscrpt_box_add_js'            => array(
				'src'       => $plugin_js_assets_path . 'box-add.js',
				'deps'      => array( 'subscrpt_box_cart_js', 'subscrpt_box_replace_prompt_js' ),
				'in_footer' => true,
			),
			'subscrpt_box_together_js'       => array(
				'src'       => $plugin_js_assets_path . 'box-together.js',
				'deps'      => array( 'subscrpt_box_replace_prompt_js' ),
				'in_footer' => true,
			),
			'subscrpt_box_next_add_js'       => array(
				'src'       => $plugin_js_assets_path . 'box-next-add.js',
				'deps'      => array( 'subscrpt_box_replace_prompt_js' ),
				'in_footer' => true,
			),
			'subscrpt_box_account_add_js'    => array(
				'src'       => $plugin_js_assets_path . 'box-account-add.js',
				'deps'      => array(),
				'in_footer' => true,
			),
			'subscrpt_box_cart_view_js'      => array(
				'src'       => $plugin_js_assets_path . 'box-cart-view.js',
				'deps'      => array( 'wc-blocks-checkout', 'wp-data', 'wp-dom', 'wp-html-entities' ),
				'in_footer' => true,
			),
		);
	}

	/**
	 * Get registered styles
	 *
	 * @return array
	 */
	public function get_styles() {
		$plugin_css_assets_path = SUBSCRIPT_PRO_ASSETS . '/css/';

		$styles = array(
			'subscrpt_pro_admin_css'   => array(
				'src' => $plugin_css_assets_path . 'admin/admin.css',
			),
			'subscrpt_pro_admin_pages' => array(
				'src'  => $plugin_css_assets_path . 'admin/admin-pages.css',
				'deps' => array( 'subscrpt_admin_components' ),
			),
			'subscrpt_box_css'         => array(
				'src' => $plugin_css_assets_path . 'box.css',
			),
			'subscrpt_box_admin_css'   => array(
				'src'  => $plugin_css_assets_path . 'admin/boxes.css',
				'deps' => array( 'subscrpt_pro_admin_pages' ),
			),
			'subscrpt_box_workspace'   => array(
				'src'  => $plugin_css_assets_path . 'admin/box-workspace.css',
				'deps' => array( 'subscrpt_box_admin_css' ),
			),
		);

		return $styles;
	}

	/**
	 * Enqueue scripts
	 */
	public function enqueue_scripts() {
		// Match the page slug only: the screen id's prefix is sanitize_title() of
		// the parent menu's *translated* title, so it differs per locale.
		$screen = get_current_screen();
		if ( $screen && str_ends_with( $screen->id, '_page_wp-subscription-settings' ) ) {
			wp_enqueue_script(
				'subscrpt_admin_api_js',
				plugins_url( 'assets/js/admin/api.js', __DIR__ ),
				array( 'jquery', 'wp-i18n' ),
				filemtime( plugin_dir_path( __DIR__ ) . 'assets/js/admin/api.js' ),
				true
			);
			wp_set_script_translations( 'subscrpt_admin_api_js', 'subscription-pro', SUBSCRIPT_PRO_PATH . '/languages' );

			wp_localize_script(
				'subscrpt_admin_api_js',
				'subscrpt_pro_ajax',
				array(
					'nonce' => wp_create_nonce( 'subscrpt_pro_ajax_nonce' ),
				)
			);
		}
	}

	/**
	 * Enqueue the shared page chrome on every WPSubscription admin screen.
	 *
	 * The page header and the licence gate appear on Health, Statistics,
	 * Delivery and Subscriptions, so this is registered centrally rather than
	 * enqueued per page. It depends on the free plugin's admin-components
	 * stylesheet, which defines the --wpsubs-* tokens it uses.
	 *
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public function enqueue_admin_page_css( $hook ) {
		if ( ! str_starts_with( $hook, 'wpsubscription_page' )
			&& ! str_starts_with( $hook, 'wp-subscription_page' )
			&& 'toplevel_page_wp-subscription' !== $hook ) {
			return;
		}

		wp_enqueue_style( 'subscrpt_pro_admin_pages' );
	}
}
