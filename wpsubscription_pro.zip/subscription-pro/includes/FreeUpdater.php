<?php
/**
 * Keeps the free plugin current whenever pro is installed or updated.
 *
 * @package SpringDevs\SubscriptionPro
 */

namespace SpringDevs\SubscriptionPro;

/**
 * Class FreeUpdater
 *
 * Pro is built against the free plugin as it currently ships, so a site that
 * updates pro but leaves free behind runs new pro code against hooks that may
 * not exist yet. Before pro's update is unpacked, and when pro is activated,
 * free is installed or brought up to the latest wordpress.org version.
 *
 * Never blocks: a failure is logged and pro carries on.
 *
 * @package SpringDevs\SubscriptionPro
 */
class FreeUpdater {

	/**
	 * The free plugin's wordpress.org slug.
	 */
	const FREE_SLUG = 'subscription';

	/**
	 * The free plugin's basename.
	 */
	const FREE_FILE = 'subscription/subscription.php';

	/**
	 * Whether this request has already run the check.
	 *
	 * @var bool
	 */
	private static $done = false;

	/**
	 * Update free just before pro's new package is installed.
	 *
	 * Hooked early, outside `init_plugin()`, so background auto-updates and
	 * WP-CLI reach it too. Note this runs in the pro version being replaced.
	 *
	 * @param bool|\WP_Error $response   Installation response.
	 * @param array          $hook_extra Extra arguments passed to the upgrader.
	 *
	 * @return bool|\WP_Error The response, unchanged.
	 */
	public static function before_pro_install( $response, $hook_extra ) {
		if ( is_wp_error( $response ) || empty( $hook_extra['plugin'] ) ) {
			return $response;
		}

		if ( plugin_basename( SUBSCRIPT_PRO_FILE ) === $hook_extra['plugin'] ) {
			self::maybe_update_free();
		}

		return $response;
	}

	/**
	 * Install or update free to the latest wordpress.org version.
	 *
	 * @return void
	 */
	public static function maybe_update_free() {
		if ( self::$done ) {
			return;
		}
		self::$done = true;

		if ( ! wp_is_file_mod_allowed( 'subscrpt_pro_free_update' ) ) {
			return;
		}

		$unattended = wp_doing_cron() || ( defined( 'WP_CLI' ) && WP_CLI );
		if ( ! $unattended && ! current_user_can( 'install_plugins' ) ) {
			return;
		}

		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/misc.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

		$plugins   = get_plugins();
		$installed = isset( $plugins[ self::FREE_FILE ] ) ? $plugins[ self::FREE_FILE ]['Version'] : null;

		if ( null !== $installed && self::is_vcs_checkout() ) {
			return;
		}

		$api = plugins_api(
			'plugin_information',
			[
				'slug'   => self::FREE_SLUG,
				'fields' => [ 'sections' => false ],
			]
		);
		if ( is_wp_error( $api ) || empty( $api->download_link ) ) {
			self::log( is_wp_error( $api ) ? $api->get_error_message() : 'No download link from wordpress.org.' );
			return;
		}

		if ( null !== $installed && version_compare( $installed, $api->version, '>=' ) ) {
			return;
		}

		// `install()` with overwrite rather than `upgrade()`: upgrade reads the
		// package from the update_plugins transient, which can be hours stale.
		$skin     = new \Automatic_Upgrader_Skin();
		$upgrader = new \Plugin_Upgrader( $skin );
		$result   = $upgrader->install( $api->download_link, [ 'overwrite_package' => true ] );

		if ( true !== $result ) {
			$message = is_wp_error( $result ) ? $result->get_error_message() : implode( ' ', (array) $skin->get_upgrade_messages() );
			self::log( $message );
			return;
		}

		// Freshly installed: pro cannot run without it, so switch it on.
		if ( null === $installed ) {
			$activated = activate_plugin( self::FREE_FILE );
			if ( is_wp_error( $activated ) ) {
				self::log( $activated->get_error_message() );
			}
		}
	}

	/**
	 * Whether free is a version-controlled development copy.
	 *
	 * Overwriting one would destroy its working tree. Not core's
	 * `WP_Automatic_Updater::is_vcs_checkout()`: that tests `is_dir()`, and a
	 * git submodule or worktree has a `.git` file, not a directory.
	 *
	 * @return bool
	 */
	private static function is_vcs_checkout() {
		$dir = WP_PLUGIN_DIR . '/' . self::FREE_SLUG;

		foreach ( [ '.git', '.svn', '.hg' ] as $vcs ) {
			if ( file_exists( $dir . '/' . $vcs ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Record a failed install or update.
	 *
	 * @param string $message What went wrong.
	 *
	 * @return void
	 */
	private static function log( $message ) {
		$message = 'Could not install or update the free plugin: ' . $message;

		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->warning( $message, [ 'source' => 'subscription-pro' ] );
			return;
		}

		error_log( $message ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- WooCommerce may be absent here.
	}
}
