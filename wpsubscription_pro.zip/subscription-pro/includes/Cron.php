<?php
/**
 * Scheduled (wp-cron) tasks.
 *
 * @package SpringDevs\SubscriptionPro
 */

namespace SpringDevs\SubscriptionPro;

use SpringDevs\Subscription\Illuminate\Helper;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxSubscription;
use SpringDevs\SubscriptionPro\Illuminate\Emails\HealthQueueReminder;

/**
 * Scheduled (wp-cron) tasks.
 */
class Cron {

	/**
	 * Initialize the class.
	 */
	public function __construct() {
		add_action( 'subscrpt_generate_delivery_schedule', array( $this, 'generate_delivery_schedule' ) );
		add_action( 'subscrpt_renew_reminder_cron', array( $this, 'send_renew_reminder_mail' ) );
		add_action( 'subscrpt_health_queue_reminder_cron', array( $this, 'send_health_queue_reminder' ) );
		add_action( 'subscrpt_box_notice_cron', array( $this, 'send_box_notices' ) );
		// Must also register intervals here — Health class is admin-only and doesn't
		// run during cron requests, so WP can't validate subscrpt_weekly on reschedule.
		add_filter( 'cron_schedules', array( $this, 'register_cron_intervals' ) );
	}

	/**
	 * Register custom WP-Cron intervals.
	 *
	 * Registered in both Cron (cron requests) and Health (admin requests) so the
	 * intervals are always available regardless of request type.
	 *
	 * @param array $schedules Existing cron schedules.
	 * @return array
	 */
	public function register_cron_intervals( array $schedules ): array {
		if ( ! isset( $schedules['subscrpt_weekly'] ) ) {
			$schedules['subscrpt_weekly'] = array(
				'interval' => 7 * DAY_IN_SECONDS,
				'display'  => __( 'Once Weekly', 'subscription-pro' ),
			);
		}
		if ( ! isset( $schedules['subscrpt_monthly'] ) ) {
			$schedules['subscrpt_monthly'] = array(
				'interval' => 30 * DAY_IN_SECONDS,
				'display'  => __( 'Once Monthly', 'subscription-pro' ),
			);
		}
		return $schedules;
	}

	/**
	 * Generate Delivery Schedule for Subscriptions.
	 *
	 * @return void
	 */
	public function generate_delivery_schedule() {
		$batch_offset = get_option( 'subscrpt_delivery_schedule_batch_offset', 0 );
		$args         = array(
			'post_type'      => 'subscrpt_order',
			'post_status'    => array( 'active', 'pe_cancelled' ),
			'fields'         => 'ids',
			'posts_per_page' => 10,
			'offset'         => $batch_offset,
			'meta_query'     => array(
				'relation' => 'OR',
				array(
					'key'     => '_subscrpt_schedule_generated',
					'compare' => 'NOT EXISTS',
				),
				array(
					'key'     => '_subscrpt_schedule_generated',
					'value'   => time(),
					'compare' => '<=',
				),
			),
		);

		$subscriptions = get_posts( $args );

		foreach ( $subscriptions as $subscription_id ) {
			$order_id   = get_post_meta( $subscription_id, '_subscrpt_order_id', true );
			$order      = wc_get_order( $order_id );
			$order_item = $order ? $order->get_item(
				get_post_meta( $subscription_id, '_subscrpt_order_item_id', true )
			) : false;
			// A removed order or item would fatal here and stop the whole cron run, so skip that subscription.
			if ( ! $order_item instanceof \WC_Order_Item_Product ) {
				continue;
			}
			$order_item_meta = $order_item->get_meta( '_subscrpt_meta' );
			if ( ! is_array( $order_item_meta ) ) {
				continue;
			}
			$recurring          = $order_item_meta['time'] . ' ' . Helper::get_typos( $order_item_meta['time'], $order_item_meta['type'] );
			$product            = $order_item->get_product();
			$next_delivery_time = strtotime( $recurring );
		}

		update_option(
			'subscrpt_delivery_schedule_batch_offset',
			count( $subscriptions ) === 10 ? ( $batch_offset + 10 ) : 0
		);
	}

	/**
	 * Send renew reminder mail.
	 *
	 * @return void
	 */
	public function send_renew_reminder_mail() {
		// Get the number of days before renewal to send reminder
		$reminder_days = get_option( 'subscrpt_renewal_reminder_days', 7 );
		$time          = strtotime( $reminder_days . ' days' );

		$args = array(
			'post_type'   => 'subscrpt_order',
			'post_status' => array( 'active', 'pe_cancelled' ),
			'fields'      => 'ids',
			'meta_query'  => array(
				'relation' => 'AND',
				array(
					'key'     => '_subscrpt_next_date',
					'value'   => $time,
					'compare' => '<=',
				),
				// array(
				// 'key'   => '_subscrpt_trial',
				// 'compare' => 'NOT EXISTS',
				// ),
				array(
					'key'     => '_subscrpt_reminder_mail_sent',
					'compare' => 'NOT EXISTS',
				),
			),
		);

		$subscriptions = get_posts( $args );

		if ( 0 === count( $subscriptions ) ) {
			return;
		}

		// Initialize WooCommerce mailer
		if ( function_exists( 'WC' ) && WC()->mailer() ) {
			foreach ( $subscriptions as $subscription_id ) {
				do_action( 'subscrpt_renew_reminder_email_notification', $subscription_id );
			}
		}
	}

	/**
	 * Tell subscribers what their next box holds, before it locks.
	 *
	 * This is also the moment an edition reaches people: publishing an edition
	 * changes nothing on its own, so a merchant can plan months ahead and a box
	 * that has already locked is never rewritten underneath its owner.
	 *
	 * @return void
	 */
	public function send_box_notices(): void {
		if ( ! function_exists( 'WC' ) || ! WC()->mailer() ) {
			return;
		}

		$lead   = max( 0, (int) get_option( 'subscrpt_box_email_days', 10 ) );
		$window = strtotime( "+{$lead} days" );

		$subscriptions = get_posts(
			array(
				'post_type'      => 'subscrpt_order',
				'post_status'    => array( 'active', 'pe_cancelled' ),
				'fields'         => 'ids',
				'posts_per_page' => 100,
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					'relation' => 'AND',
					array(
						'key'     => BoxSubscription::META_CONTENTS,
						'compare' => 'EXISTS',
					),
					array(
						'key'     => '_subscrpt_next_date',
						'value'   => $window,
						'compare' => '<=',
						'type'    => 'NUMERIC',
					),
				),
			)
		);

		foreach ( $subscriptions as $subscription_id ) {
			$next_date = (int) get_post_meta( $subscription_id, '_subscrpt_next_date', true );

			if ( ! $next_date ) {
				continue;
			}

			// One notice per cycle: the marker is the renewal date itself, so a
			// skipped box (which moves that date) earns a fresh notice.
			if ( (int) get_post_meta( $subscription_id, BoxSubscription::META_NOTIFIED, true ) === $next_date ) {
				continue;
			}

			BoxSubscription::materialise_edition( (int) $subscription_id );

			/**
			 * Fires when a subscriber should be told what their next box holds.
			 *
			 * @param int $subscription_id Subscription id.
			 */
			do_action( 'subscrpt_box_notice_email_notification', (int) $subscription_id );
		}
	}

	/**
	 * Send the health queue reminder email to the store admin.
	 *
	 * Skips sending when the queue is empty or the email is disabled.
	 *
	 * @return void
	 */
	public function send_health_queue_reminder(): void {
		if ( ! function_exists( 'WC' ) || ! WC()->mailer() ) {
			return;
		}

		$mailer = WC()->mailer();
		$emails = $mailer->get_emails();

		if ( isset( $emails['subscrpt_health_queue_reminder'] ) ) {
			$emails['subscrpt_health_queue_reminder']->trigger();
		} else {
			// Fallback: instantiate directly if not yet registered.
			$email = new HealthQueueReminder();
			$email->trigger();
		}
	}
}
