<?php
/**
 * The service container for the plugin's business logic.
 *
 * @package SpringDevs\SubscriptionPro
 */

namespace SpringDevs\SubscriptionPro;

use SpringDevs\SubscriptionPro\Illuminate\Box\BoxCart;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxCartEndpoints;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxCartPricing;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxCartView;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxOrder;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxProduct;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxSubscription;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxTogether;
use SpringDevs\SubscriptionPro\Illuminate\Coupon\Coupon;
use SpringDevs\SubscriptionPro\Illuminate\Delivery;
use SpringDevs\SubscriptionPro\Illuminate\RecurringShipping;
use SpringDevs\SubscriptionPro\Frontend\PlanCustomCss;
use SpringDevs\SubscriptionPro\Illuminate\Order;
use SpringDevs\SubscriptionPro\Illuminate\Product;
use SpringDevs\SubscriptionPro\Illuminate\SubscriptionSwitch;
use SpringDevs\SubscriptionPro\Illuminate\Cancellation;
use SpringDevs\SubscriptionPro\Illuminate\RetentionOffer;
use SpringDevs\SubscriptionPro\Illuminate\GatewayLimitEnforcer;
use SpringDevs\SubscriptionPro\Illuminate\Gateways\PaymentGateways;
use SpringDevs\SubscriptionPro\Illuminate\Helper;
use SpringDevs\SubscriptionPro\Illuminate\LiveQR\LiveQR;
use SpringDevs\SubscriptionPro\Illuminate\MixedCart;
use SpringDevs\SubscriptionPro\Illuminate\RoleManagement;
use SpringDevs\SubscriptionPro\Illuminate\SubscriptionStatusHandler;
use SpringDevs\SubscriptionPro\Illuminate\SplitPaymentHandler;
use SpringDevs\SubscriptionPro\Illuminate\TrialPayment;
use SpringDevs\SubscriptionPro\Illuminate\Subscription\SubscriptionPro;
use SpringDevs\SubscriptionPro\Integrations\Integrations;

/**
 * Illuminate - Load classes in everywhere.
 */
class Illuminate {

	/**
	 * Singleton instance
	 *
	 * @var Illuminate|null
	 */
	private static $instance = null;

	/**
	 * Get singleton instance
	 *
	 * @return Illuminate
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Initialize the class.
	 */
	private function __construct() {
		new SubscriptionPro();
		new Helper();
		new Product();
		new Order();
		new PlanCustomCss();
		new Delivery();
		new SubscriptionSwitch();
		new GatewayLimitEnforcer();
		new SubscriptionStatusHandler();
		new TrialPayment();
		new Cancellation();
		new RetentionOffer();
		new Integrations();
		new LiveQR();
		new PaymentGateways();
		new Coupon();
		new MixedCart();

		// Subscription boxes. Every listener below returns immediately for a
		// product that is not a box, so a store without one is untouched.
		BoxProduct::register_hooks();
		new BoxCart();
		new BoxCartPricing();
		new BoxCartEndpoints();
		new BoxCartView();
		new BoxOrder();
		new BoxSubscription();
		new BoxTogether();
		new RecurringShipping();

		if ( class_exists( 'SpringDevs\Subscription\Illuminate\RoleManagement' ) ) {
			new RoleManagement();
		}

		// SplitPaymentHandler is a utility class with static methods only
		// No need to instantiate it, just ensure it's loaded
	}
}
