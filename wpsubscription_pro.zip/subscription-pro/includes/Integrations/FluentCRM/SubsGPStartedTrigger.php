<?php
/**
 * FluentCRM trigger: Subscription Grace Period Started.
 *
 * @package SpringDevs\SubscriptionPro\Integrations\FluentCRM
 */

/**
 * ? Disable some PHPCS rules.
 * @phpcs:disable WordPress.NamingConventions.ValidVariableName
 */

namespace SpringDevs\SubscriptionPro\Integrations\FluentCRM;

use FluentCrm\App\Services\Funnel\BaseTrigger;
use FluentCrm\App\Services\Funnel\FunnelHelper;
use FluentCrm\App\Services\Funnel\FunnelProcessor;
use FluentCrm\Framework\Support\Arr;
use SpringDevs\Subscription\Illuminate\Helper as FreeHelper;

/**
 * Subscription Grace Period Started Trigger Class
 */
class SubsGPStartedTrigger extends BaseTrigger {
	/**
	 * Constructor
	 */
	public function __construct() {
		$this->triggerName  = 'wpsubs_fluentcrm_status_grace_period_started';
		$this->priority     = 22;
		$this->actionArgNum = 1;
		parent::__construct();
	}

	/**
	 * Get Trigger Info
	 */
	public function getTrigger() {
		return [
			'ribbon'      => 'subscription',
			'category'    => __( 'WooCommerce', 'subscription-pro' ),
			'label'       => __( 'Subscription in Grace Period', 'subscription-pro' ),
			'icon'        => 'fc-icon-trigger',
			'description' => __( 'This funnel will start when a WP subscription enters the grace period.', 'subscription-pro' ),
		];
	}

	/**
	 * Get Funnel Settings Defaults
	 */
	public function getFunnelSettingsDefaults() {
		return [ 'contact_status' => 'subscribed' ];
	}

	/**
	 * Get Funnel Condition Defaults
	 *
	 * @param object $funnel Funnel object.
	 */
	public function getFunnelConditionDefaults( $funnel ) {
		return [
			'product_ids'  => [],
			'run_multiple' => 'no',
		];
	}

	/**
	 * Get settings fields for the trigger in funnel editor
	 *
	 * @param object $funnel Funnel object.
	 */
	public function getSettingsFields( $funnel ) {
		return [
			'title'     => __( 'Subscription in Grace Period', 'subscription-pro' ),
			'sub_title' => __( 'This Automation will start when a WP subscription enters the grace period.', 'subscription-pro' ),
			'fields'    => [
				'contact_status' => [
					'type'        => 'option_selectors',
					'option_key'  => 'editable_statuses',
					'is_multiple' => false,
					'label'       => __( 'Contact Status', 'subscription-pro' ),
					'placeholder' => __( 'Select Status', 'subscription-pro' ),
				],
			],
		];
	}

	/**
	 * Get condition fields for the trigger in funnel editor
	 *
	 * @param object $funnel Funnel object.
	 */
	public function getConditionFields( $funnel ) {
		return [
			'product_ids'  => [
				'type'               => 'rest_selector',
				'option_key'         => 'woo_products',
				'experimental_cache' => true,
				'is_multiple'        => true,
				'label'              => __( 'Target Products', 'subscription-pro' ),
				'help'               => __( 'Limit subscription products on which this automation will run (keep it blank to run for any subscription product)', 'subscription-pro' ),
			],
			'run_multiple' => [
				'type'        => 'yes_no_check',
				'label'       => '',
				'check_label' => __( 'Restart the Automation Multiple times for a contact for this event. (Only enable if you want to restart automation for the same contact)', 'fluentcampaign-pro' ), // phpcs:ignore WordPress.WP.I18n.TextDomainMismatch
				'inline_help' => __( 'If you enable, then it will restart the automation for a contact if the contact already in the automation. Otherwise, It will just skip if already exist', 'fluentcampaign-pro' ), // phpcs:ignore WordPress.WP.I18n.TextDomainMismatch
			],
		];
	}

	/**
	 * Check if the funnel is processable
	 *
	 * @param array  $args Arguments array.
	 * @param array  $user_data User Data.
	 * @param object $funnel Funnel object.
	 */
	public function isProcessable( $args, $user_data, $funnel ) {
		$subscription_id   = $args['subscription_id'] ?? 0;
		$subscription_data = FreeHelper::get_subscription_data( $subscription_id );

		$conditions = (array) $funnel->conditions;
		$subscriber = FunnelHelper::getSubscriber( $user_data['email'] ?? '' );

		// Specific Product IDs check
		if ( ! empty( $conditions['product_ids'] ) ) {
			$product_ids = $subscription_data['product'] ?? [];

			$chk = array_intersect( $conditions['product_ids'], $product_ids );

			if ( empty( $chk ) ) {
				return false;
			}
		}

		// Multiple run check
		$is_already_in_funnel = $subscriber && FunnelHelper::ifAlreadyInFunnel( $funnel->id, $subscriber->id );
		if ( $is_already_in_funnel ) {
			$multipleRun = Arr::get( $conditions, 'run_multiple', 'no' ) === 'yes';
			if ( $multipleRun ) {
				FunnelHelper::removeSubscribersFromFunnel( $funnel->id, [ $subscriber->id ] );
			} else {
				return false;
			}
		}

		return true;
	}

	/**
	 * Handle Trigger
	 *
	 * @param object $funnel Funnel object.
	 * @param array  $originalArgs Original Arguments.
	 */
	public function handle( $funnel, $originalArgs ) {
		$args            = $originalArgs[0];
		$subscription_id = $args['subscription_id'] ?? 0;

		$user_data = FunnelHelper::prepareUserData( $args['user_id'] );

		if ( ! $user_data ) {
			return false;
		}

		$is_processable = $this->isProcessable( $args, $user_data, $funnel );

		if ( ! $is_processable ) {
			return false;
		}

		$subscriber_data           = wp_parse_args( $user_data, $funnel->settings );
		$subscriber_data['status'] = ( ! empty( $subscriber_data['contact_status'] ) ) ? $subscriber_data['contact_status'] : 'subscribed';
		unset( $subscriber_data['contact_status'] );

		( new FunnelProcessor() )->startFunnelSequence(
			$funnel,
			$subscriber_data,
			[
				'source_trigger_name' => $this->triggerName,
				'source_ref_id'       => $subscription_id,
			]
		);
	}
}
