<?php
/**
 * FluentCRM integration main file.
 *
 * @package SpringDevs\SubscriptionPro\Integrations\FluentCRM
 */

namespace SpringDevs\SubscriptionPro\Integrations\FluentCRM;

use FluentCrm\App\Models\Funnel;
use SpringDevs\Subscription\Illuminate\Helper as FreeHelper;

/**
 * FluentCRM Integration Class
 */
class FluentCRM {
	/**
	 * Constructor
	 */
	public function __construct() {
		// Initialize subscription triggers
		add_action(
			'fluent_crm/after_init',
			function () {
				new SubsActiveTrigger();
				new SubsPendingTrigger();
				new SubsCancelledTrigger();
				new SubsPeCancelledTrigger();
				new SubsExpiredTrigger();
				new SubsGPStartedTrigger();
				new SubsGPEndedTrigger();
			}
		);

		// Hook into subscription status change actions
		add_action( 'subscrpt_subscription_activated', [ $this, 'subscription_activated' ] );
		add_action( 'subscrpt_subscription_pending', [ $this, 'subscription_pending' ] );
		add_action( 'subscrpt_subscription_cancelled', [ $this, 'subscription_cancelled' ] );
		add_action( 'subscrpt_subscription_pending_cancellation', [ $this, 'subscription_pe_cancelled' ] );
		add_action( 'subscrpt_subscription_expired', [ $this, 'subscription_expired' ] );

		add_action( 'subscrpt_grace_period_started', [ $this, 'subscription_grace_period_started' ] );
		add_action( 'subscrpt_grace_period_ended', [ $this, 'subscription_grace_period_ended' ] );
	}

	/**
	 * Subscription Activated
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	public function subscription_activated( $subscription_id ) {
		$trigger_name = 'wpsubs_fluentcrm_status_active';
		$payload      = $this->generate_payload( $subscription_id );

		$this->trigger_funnel( $trigger_name, $payload );
	}

	/**
	 * Subscription Pending
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	public function subscription_pending( $subscription_id ) {
		$trigger_name = 'wpsubs_fluentcrm_status_pending';
		$payload      = $this->generate_payload( $subscription_id );

		$this->trigger_funnel( $trigger_name, $payload );
	}

	/**
	 * Subscription Cancelled
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	public function subscription_cancelled( $subscription_id ) {
		$trigger_name = 'wpsubs_fluentcrm_status_cancelled';
		$payload      = $this->generate_payload( $subscription_id );

		$this->trigger_funnel( $trigger_name, $payload );
	}

	/**
	 * Subscription Pending Cancellation
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	public function subscription_pe_cancelled( $subscription_id ) {
		$trigger_name = 'wpsubs_fluentcrm_status_pe_cancelled';
		$payload      = $this->generate_payload( $subscription_id );

		$this->trigger_funnel( $trigger_name, $payload );
	}

	/**
	 * Subscription Expired
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	public function subscription_expired( $subscription_id ) {
		$trigger_name = 'wpsubs_fluentcrm_status_expired';
		$payload      = $this->generate_payload( $subscription_id );

		$this->trigger_funnel( $trigger_name, $payload );
	}

	/**
	 * Subscription Grace Period Started
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	public function subscription_grace_period_started( $subscription_id ) {
		$trigger_name = 'wpsubs_fluentcrm_status_grace_period_started';
		$payload      = $this->generate_payload( $subscription_id );

		$this->trigger_funnel( $trigger_name, $payload );
	}

	/**
	 * Subscription Grace Period Ended
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	public function subscription_grace_period_ended( $subscription_id ) {
		$trigger_name = 'wpsubs_fluentcrm_status_grace_period_ended';
		$payload      = $this->generate_payload( $subscription_id );

		$this->trigger_funnel( $trigger_name, $payload );
	}

	/**
	 * Create payload for FluentCRM Funnel Trigger
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	public function generate_payload( $subscription_id ) {
		$subscription_data = FreeHelper::get_subscription_data( $subscription_id );

		$user_id = $subscription_data['user_id'] ?? 0;
		$user    = get_user_by( 'id', $user_id );

		if ( ! $user ) {
			return [];
		}

		return [
			'user_id'         => $user_id,
			'email'           => $user->user_email,
			'subscription_id' => $subscription_id,
			'status'          => $subscription_data['status'] ?? '',
		];
	}

	/**
	 * Trigger Funnel.
	 *
	 * @param string $trigger_name Trigger Name.
	 * @param array  $payload Payload.
	 */
	public function trigger_funnel( $trigger_name, $payload ) {
		$subscription_id = $payload['subscription_id'] ?? 0;
		if ( empty( $payload ) || empty( $payload['email'] ?? '' ) ) {
			$log_message = "FluentCRM Trigger Skipped. Payload is empty [{$trigger_name} | Subscription ID: {$subscription_id}]";
			wp_subscrpt_write_log( $log_message );
			wp_subscrpt_write_debug_log( $log_message );
			return;
		}

		$funnels = Funnel::where( 'trigger_name', $trigger_name )
				->where( 'status', 'published' )
				->get();

		foreach ( $funnels as $funnel ) {
			do_action(
				'fluentcrm_funnel_start_' . $trigger_name,
				$funnel,
				[ $payload ]
			);
		}
	}
}
