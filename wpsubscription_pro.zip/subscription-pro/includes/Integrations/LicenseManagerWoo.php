<?php
/**
 * LicenseManagerWoo integration class file.
 *
 * @package SpringDevs\SubscriptionPro\Integrations
 */

namespace SpringDevs\SubscriptionPro\Integrations;

use SpringDevs\Subscription\Illuminate\Helper;
use SpringDevs\Subscription\Illuminate\Subscription\Subscription;

/**
 * Class LicenseManagerWoo
 */
class LicenseManagerWoo {

	/**
	 * Order whose license keys are being looked up.
	 *
	 * `lmfwc_get_customer_license_keys` receives the order but returns key data,
	 * so later callbacks no longer know which order it was for.
	 *
	 * @var int
	 */
	private $license_keys_order_id = 0;

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'init', [ $this, 'init' ] );

		add_filter( 'subscrpt_before_saving_renewal_order', [ $this, 'disable_license_creation_for_renewal_order' ], 10, 3 );
		add_filter( 'subscrpt_before_saving_early_renewal_order', [ $this, 'disable_license_creation_for_renewal_order' ], 10, 3 );
	}

	/**
	 * Initialize the license manager.
	 */
	public function init() {
		// Check if License Manager plugin is active.
		if ( ! $this->check_plugin() ) {
			return;
		}

		// Subscription hooks.
		add_action( 'subscrpt_subscription_activated', [ $this, 'maybe_activate_licenses' ], 10, 1 );

		add_action( 'subscrpt_subscription_cancelled', [ $this, 'maybe_deactivate_licenses' ], 10, 1 );
		add_action( 'subscrpt_subscription_expired', [ $this, 'maybe_deactivate_licenses' ], 10, 1 );

		// A failed renewal suspends the subscription rather than ending it. Without
		// this the licence stayed Active for the whole retry ladder, so a customer
		// who stopped paying kept a working key. `maybe_activate_licenses()` runs on
		// `subscrpt_subscription_activated`, so a recovered payment re-activates it.
		add_action( 'subscrpt_subscription_on_hold', [ $this, 'maybe_deactivate_licenses' ], 10, 1 );

		// With regeneration on, a renewal order issues its own keys; follow them.
		add_action( 'lmfwc_event_post_order_license_keys', [ $this, 'maybe_switch_to_regenerated_licenses' ], 10, 1 );

		// A renewal that kept its key has none of its own; hide the empty table and point to the key.
		add_filter( 'lmfwc_get_customer_license_keys', [ $this, 'remember_license_keys_order' ], 9, 1 );
		add_filter( 'lmfwc_get_customer_license_keys', [ $this, 'hide_empty_renewal_license_keys' ], 20, 1 );
		add_action( 'woocommerce_order_details_after_order_table', [ $this, 'render_renewal_license_notice' ], 11, 1 );
		add_action( 'woocommerce_email_after_order_table', [ $this, 'render_renewal_license_email_notice' ], 11, 3 );

		// Add license meta box to subscription details page.
		add_action( 'add_meta_boxes', array( $this, 'create_meta_boxes' ) );
		add_action( 'subscrpt_after_subscription_totals', [ $this, 'render_frontend_license_info' ] );
	}

	/**
	 * Check if License Manager plugin is active.
	 */
	public function check_plugin() {
		$is_plugin_active = is_plugin_active( 'license-manager-for-woocommerce/license-manager-for-woocommerce.php' );
		$is_class_exists  = class_exists( 'LicenseManagerForWooCommerce\Models\Resources\License' );

		return $is_plugin_active && $is_class_exists;
	}

	/**
	 * Create meta boxes for subscription edit page.
	 */
	public function create_meta_boxes() {
		if ( ! empty( get_post_meta( get_the_ID(), '_subscrpt_lmfwc_license_order', true ) ) ) {
			add_meta_box(
				'subscription_lmfwc_license',
				__( 'License Keys', 'subscription-pro' ),
				[ $this, 'render_license_meta_box' ],
				'subscrpt_order',
				'normal',
				'default'
			);
		}
	}

	/**
	 * Get parent order from subscription.
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	public function get_parent_order( int $subscription_id ) {
		$related_orders = Helper::get_related_orders( $subscription_id );
		$last_order     = end( $related_orders );

		if ( ! $last_order || strtolower( $last_order->type ?? '' ) !== 'new' ) {
			foreach ( $related_orders as $order ) {
				if ( strtolower( $order->type ?? '' ) === 'new' ) {
					$last_order = $order;
					break;
				}
			}
		}

		$parent_order_id = $last_order->order_id ?? 0;
		if ( $parent_order_id ) {
			$parent_order = wc_get_order( $parent_order_id );
		}
		return $parent_order_id ? $parent_order : null;
	}

	/**
	 * Get license order from subscription.
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	public function get_license_order_from_subscription( int $subscription_id ) {
		// Check if parent order have license.
		$parent_order = $this->get_parent_order( $subscription_id );

		$license_order = $parent_order;
		$license       = apply_filters( 'lmfwc_get_customer_license_keys', $parent_order );
		$license       = reset( $license )['keys'] ?? null;

		// If parent order doesn't have license, check other related orders.
		if ( ! $license ) {
			$related_orders = Helper::get_related_orders( $subscription_id );
			$related_orders = array_reverse( $related_orders );

			foreach ( $related_orders as $related_order ) {
				$order_id = $related_order->order_id ?? 0;
				$order    = wc_get_order( $order_id );
				$license  = apply_filters( 'lmfwc_get_customer_license_keys', $order );
				$license  = reset( $license )['keys'] ?? null;

				if ( $license ) {
					$license_order = $order;
					break;
				}
			}
		}

		return ! empty( $license_order ) ? $license_order : null;
	}

	/**
	 * Keep the existing license on renewal instead of issuing a new one.
	 *
	 * Hooked on both the renewal and the early renewal filters. The order holding
	 * the subscription's current keys is always recorded first, so that when
	 * regeneration is on the keys it replaces are still known.
	 *
	 * @param \WC_Order $new_order New order object.
	 * @param \WC_Order $old_order Old order object.
	 * @param int       $subscription_id Subscription ID.
	 */
	public function disable_license_creation_for_renewal_order( $new_order, $old_order, $subscription_id ) {
		// Check if License Manager plugin is active.
		if ( ! $this->check_plugin() ) {
			return $new_order;
		}

		// Check for existing license.
		$existing_license_order_id = get_post_meta( $subscription_id, '_subscrpt_lmfwc_license_order', true );
		if ( empty( $existing_license_order_id ) ) {
			$license_order = $this->get_license_order_from_subscription( $subscription_id );

			if ( $license_order ) {
				$existing_license_order_id = $license_order->get_id();
				update_post_meta( $subscription_id, '_subscrpt_lmfwc_license_order', $existing_license_order_id );
			}
		}

		// Let License Manager issue fresh keys for this order.
		if ( self::is_regeneration_enabled() ) {
			return $new_order;
		}

		// Disable license creation for renewal order if license already exists.
		if ( ! empty( $existing_license_order_id ) ) {
			$new_order->update_meta_data( 'lmfwc_order_complete', 1 );

			wp_subscrpt_write_log( 'License already exists for Subscription ID: ' . $subscription_id . ' Skipping license creation for renewal Order ID: ' . $new_order->get_id() );
		}

		return $new_order;
	}

	/**
	 * Activate licenses if subscription is active.
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	public function maybe_activate_licenses( int $subscription_id ) {
		// Get the order holding the current licenses.
		$license_order = $this->get_current_license_order( $subscription_id );
		if ( ! $license_order ) {
			wp_subscrpt_write_log( 'No license order found for subscription ID: ' . $subscription_id . ' Skipping license operations.' );
			return;
		}

		// Get license.
		$license_data = apply_filters( 'lmfwc_get_customer_license_keys', $license_order );
		if ( empty( $license_data ) ) {
			wp_subscrpt_write_log( 'No license data found for order ID: ' . $license_order->get_id() . ' Skipping license operations.' );
			return;
		}

		// Get the licenses.
		$license_keys = [];
		foreach ( $license_data as $row ) {
			foreach ( $row['keys'] as $license ) {
				$license_keys[] = $license->getDecryptedLicenseKey();
			}
		}

		// Update the license status and expiration date.
		// Get the next payment date from subscription.
		$expires_at = get_post_meta( $subscription_id, '_subscrpt_next_date', true );
		$expires_at = $expires_at ? gmdate( 'Y-m-d H:i:s', (int) $expires_at ) : null;

		foreach ( $license_keys as $license_key ) {
			$args = [
				'status'     => 3, // Possible values are: 1 for SOLD, 2 for DELIVERED, 3 for ACTIVE, and 4 for INACTIVE.
				'expires_at' => $expires_at,
				'valid_for'  => null,
			];

			lmfwc_update_license( $license_key, $args );
		}
	}

	/**
	 * Activate licenses if subscription is active.
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	public function maybe_deactivate_licenses( int $subscription_id ) {
		// Get the order holding the current licenses.
		$license_order = $this->get_current_license_order( $subscription_id );
		if ( ! $license_order ) {
			wp_subscrpt_write_log( 'No license order found for subscription ID: ' . $subscription_id . ' Skipping license operations.' );
			return;
		}

		// Get license.
		$license_data = apply_filters( 'lmfwc_get_customer_license_keys', $license_order );
		if ( empty( $license_data ) ) {
			wp_subscrpt_write_log( 'No license data found for order ID: ' . $license_order->get_id() . ' Skipping license operations.' );
			return;
		}

		// Get the licenses.
		$license_keys = [];
		foreach ( $license_data as $row ) {
			foreach ( $row['keys'] as $license ) {
				$license_keys[] = $license->getDecryptedLicenseKey();
			}
		}

		// Update the license status.
		foreach ( $license_keys as $license_key ) {
			$args = [
				'status' => 4, // Possible values are: 1 for SOLD, 2 for DELIVERED, 3 for ACTIVE, and 4 for INACTIVE.
			];

			lmfwc_update_license( $license_key, $args );
		}
	}

	/**
	 * Get the order holding the subscription's current license keys.
	 *
	 * That is the order recorded in `_subscrpt_lmfwc_license_order` — the parent
	 * order until a renewal regenerates the keys — falling back to the parent
	 * order before anything has been recorded.
	 *
	 * @param int $subscription_id Subscription ID.
	 * @return \WC_Order|null
	 */
	public function get_current_license_order( int $subscription_id ) {
		$order_id = get_post_meta( $subscription_id, '_subscrpt_lmfwc_license_order', true );
		$order    = $order_id ? wc_get_order( $order_id ) : false;

		return $order ? $order : $this->get_parent_order( $subscription_id );
	}

	/**
	 * Make a renewal order's freshly generated keys the subscription's licenses.
	 *
	 * Runs after License Manager generates keys for an order. Only acts when
	 * regeneration is enabled and the order is a renewal: the subscription is
	 * pointed at the new keys, and the previous keys are deactivated unless the
	 * store keeps them working until they expire.
	 *
	 * @param array $data Event data: `orderId` and `licenses`.
	 */
	public function maybe_switch_to_regenerated_licenses( $data ) {
		if ( ! self::is_regeneration_enabled() ) {
			return;
		}

		$order_id = absint( $data['orderId'] ?? 0 );
		if ( ! $order_id ) {
			return;
		}

		foreach ( Helper::get_subscriptions_from_order( $order_id ) as $history ) {
			if ( ! in_array( $history->type, [ 'renew', 'early-renew' ], true ) ) {
				continue;
			}

			$subscription_id   = (int) $history->subscription_id;
			$previous_order_id = (int) get_post_meta( $subscription_id, '_subscrpt_lmfwc_license_order', true );

			// The event fires once per licensed item; the first one already switched.
			if ( $previous_order_id === $order_id ) {
				continue;
			}

			if ( $previous_order_id && self::should_deactivate_previous_license() ) {
				$this->deactivate_subscription_licenses_in_order( $subscription_id, $previous_order_id );
			}

			update_post_meta( $subscription_id, '_subscrpt_lmfwc_license_order', $order_id );

			wp_subscrpt_write_log( 'License regenerated for Subscription ID: ' . $subscription_id . ' on renewal Order ID: ' . $order_id . ' Previous license Order ID: ' . $previous_order_id );
		}
	}

	/**
	 * Deactivate the keys an order issued for one subscription.
	 *
	 * An order can carry keys for several products, so only the keys of the
	 * subscription's own line item are touched.
	 *
	 * @param int $subscription_id Subscription ID.
	 * @param int $order_id        Order that issued the keys.
	 */
	private function deactivate_subscription_licenses_in_order( int $subscription_id, int $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}

		$product_id = 0;
		foreach ( Helper::get_related_orders( $subscription_id ) as $history ) {
			if ( (int) $history->order_id === $order_id ) {
				$order_item = $order->get_item( (int) $history->order_item_id );
				$product    = $order_item ? $order_item->get_product() : null;
				$product_id = $product ? $product->get_id() : 0;
				break;
			}
		}

		$license_data = apply_filters( 'lmfwc_get_customer_license_keys', $order );
		if ( ! $product_id || empty( $license_data[ $product_id ]['keys'] ) ) {
			wp_subscrpt_write_log( 'No previous license found in Order ID: ' . $order_id . ' for Subscription ID: ' . $subscription_id . ' Skipping deactivation.' );
			return;
		}

		foreach ( $license_data[ $product_id ]['keys'] as $license ) {
			lmfwc_update_license(
				$license->getDecryptedLicenseKey(),
				[
					'status' => 4, // Possible values are: 1 for SOLD, 2 for DELIVERED, 3 for ACTIVE, and 4 for INACTIVE.
				]
			);
		}
	}

	/**
	 * Whether a renewal should issue a fresh license key.
	 *
	 * @return bool
	 */
	public static function is_regeneration_enabled() {
		return '1' === get_option( 'subscrpt_regenerate_license_on_renewal', '0' );
	}

	/**
	 * Whether regenerating a key deactivates the previous one.
	 *
	 * @return bool
	 */
	public static function should_deactivate_previous_license() {
		return '1' === get_option( 'subscrpt_deactivate_old_license_on_renewal', '1' );
	}

	/**
	 * Remember which order a license key lookup is for.
	 *
	 * Runs just before License Manager turns the order into key data.
	 *
	 * @param mixed $order Order being looked up.
	 * @return mixed The order, unchanged.
	 */
	public function remember_license_keys_order( $order ) {
		$this->license_keys_order_id = $order instanceof \WC_Order ? $order->get_id() : 0;

		return $order;
	}

	/**
	 * Drop products without keys from a renewal order's license data.
	 *
	 * License Manager lists every licensed product in an order, keys or not, and
	 * only hides its "Your license key(s)" section when the list is empty. A
	 * renewal that kept the existing key has no keys of its own, so without this
	 * the order page and the order email show the section with nothing in it.
	 *
	 * @param mixed $data License data keyed by product ID.
	 * @return mixed
	 */
	public function hide_empty_renewal_license_keys( $data ) {
		$order_id                    = $this->license_keys_order_id;
		$this->license_keys_order_id = 0;

		if ( ! $order_id || ! is_array( $data ) || ! $this->get_renewal_subscription_id( $order_id ) ) {
			return $data;
		}

		return array_filter(
			$data,
			function ( $row ) {
				return ! empty( $row['keys'] );
			}
		);
	}

	/**
	 * Point the customer to the key a renewal order kept.
	 *
	 * Shown under the order details when the renewal has no keys of its own but
	 * the subscription's key lives on an earlier order.
	 *
	 * @param \WC_Order $order Order being viewed.
	 */
	public function render_renewal_license_notice( $order ) {
		$subscription_url = $this->get_kept_license_subscription_url( $order );
		if ( ! $subscription_url ) {
			return;
		}
		?>
		<section class="subscrpt-renewal-license-notice">
			<h2><?php esc_html_e( 'Your license key(s)', 'subscription-pro' ); ?></h2>
			<p>
				<?php esc_html_e( 'Your existing license key stays active for this renewal.', 'subscription-pro' ); ?>
				<a href="<?php echo esc_url( $subscription_url ); ?>"><?php esc_html_e( 'Get your key', 'subscription-pro' ); ?></a>
			</p>
		</section>
		<?php
	}

	/**
	 * Point the customer to the kept key in the renewal order emails.
	 *
	 * Mirrors License Manager: only in customer emails, and only for the order
	 * statuses it is set to deliver keys on.
	 *
	 * @param \WC_Order $order         Order the email is about.
	 * @param bool      $sent_to_admin Whether the email goes to the store admin.
	 * @param bool      $plain_text    Whether the email is plain text.
	 */
	public function render_renewal_license_email_notice( $order, $sent_to_admin, $plain_text ) {
		if ( $sent_to_admin || ! $order instanceof \WC_Order ) {
			return;
		}

		$delivery_statuses = \LicenseManagerForWooCommerce\Settings::get( 'lmfwc_license_key_delivery_options', \LicenseManagerForWooCommerce\Settings::SECTION_WOOCOMMERCE );
		if ( ! is_array( $delivery_statuses ) || ! array_key_exists( 'wc-' . $order->get_status(), $delivery_statuses ) ) {
			return;
		}

		$subscription_url = $this->get_kept_license_subscription_url( $order );
		if ( ! $subscription_url ) {
			return;
		}

		if ( $plain_text ) {
			echo "\n" . esc_html( wc_strtoupper( __( 'Your license key(s)', 'subscription-pro' ) ) ) . "\n\n";
			echo esc_html__( 'Your existing license key stays active for this renewal.', 'subscription-pro' ) . "\n";
			echo esc_html__( 'Get your key', 'subscription-pro' ) . ': ' . esc_url_raw( $subscription_url ) . "\n\n";
			return;
		}
		?>
		<h2><?php esc_html_e( 'Your license key(s)', 'subscription-pro' ); ?></h2>
		<p style="margin-bottom: 40px;">
			<?php esc_html_e( 'Your existing license key stays active for this renewal.', 'subscription-pro' ); ?>
			<a href="<?php echo esc_url( $subscription_url ); ?>"><?php esc_html_e( 'Get your key', 'subscription-pro' ); ?></a>
		</p>
		<?php
	}

	/**
	 * Get the subscription page holding the key a renewal order kept.
	 *
	 * @param mixed $order Order being shown.
	 * @return string Subscription page URL, or '' when the order is not a renewal
	 *                that kept an existing key.
	 */
	private function get_kept_license_subscription_url( $order ) {
		if ( ! $order instanceof \WC_Order ) {
			return '';
		}

		$subscription_id = $this->get_renewal_subscription_id( $order->get_id() );
		if ( ! $subscription_id || ! empty( apply_filters( 'lmfwc_get_customer_license_keys', $order ) ) ) {
			return '';
		}

		$license_order = $this->get_current_license_order( $subscription_id );
		if ( ! $license_order || $license_order->get_id() === $order->get_id() || empty( apply_filters( 'lmfwc_get_customer_license_keys', $license_order ) ) ) {
			return '';
		}

		return wc_get_endpoint_url( Subscription::get_user_endpoint( 'view_subs' ), $subscription_id, wc_get_page_permalink( 'myaccount' ) );
	}

	/**
	 * Get the subscription an order renews.
	 *
	 * @param int $order_id Order ID.
	 * @return int Subscription ID, or 0 when the order is not a renewal.
	 */
	private function get_renewal_subscription_id( int $order_id ) {
		foreach ( Helper::get_subscriptions_from_order( $order_id ) as $history ) {
			if ( in_array( $history->type, [ 'renew', 'early-renew' ], true ) ) {
				return (int) $history->subscription_id;
			}
		}

		return 0;
	}

	/**
	 * Render license meta box content.
	 *
	 * @param WP_Post $post The post object.
	 */
	public function render_license_meta_box( $post ) {
		$order_id     = get_post_meta( $post->ID, '_subscrpt_lmfwc_license_order', true );
		$order        = wc_get_order( $order_id );
		$license_data = ! empty( $order ) ? apply_filters( 'lmfwc_get_customer_license_keys', $order ) : [];
		$license_data = reset( $license_data );

		if ( empty( $license_data ) ) {
			echo '<p>' . esc_html_e( 'No license found.', 'subscription-pro' ) . '</p>';
			return;
		}

		?>
		<style>
			.subscrpt_lmfwc_license_table td{
				vertical-align: middle;
			}

			#subscription_lmfwc_license .inside table {
				border: none;
			}
		</style>

		<table class="wp-list-table widefat fixed striped table-view-list licensekeys subscrpt_lmfwc_license_table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'License Key', 'subscription-pro' ); ?></th>
					<th><?php esc_html_e( 'Order', 'subscription-pro' ); ?></th>
					<th><?php esc_html_e( 'Product', 'subscription-pro' ); ?></th>
					<th><?php esc_html_e( 'Status', 'subscription-pro' ); ?></th>
					<th><?php esc_html_e( 'Activation', 'subscription-pro' ); ?></th>
					<th><?php esc_html_e( 'Expires At', 'subscription-pro' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $license_data['keys'] ?? [] as $license ) : ?>
					<?php
						$license_key = $license->getDecryptedLicenseKey();
						$order_id    = $license->getOrderId();

						$product_id   = $license->getProductId();
						$product      = $product_id ? wc_get_product( $product_id ) : null;
						$product_name = $product ? $product->get_name() : '-';

						$status_key = $license->getStatus();
						$status_map = [
							1 => 'Sold',
							2 => 'Delivered',
							3 => 'Active',
							4 => 'Inactive',
						];
						$status     = $status_map[ $status_key ] ?? 'sold';

						$activated_count = $license->getTimesActivated() ?? 0;
						$max_count       = $license->getTimesActivatedMax() ?? '&infin;';
						$activation      = $activated_count . ' / ' . $max_count;

						$expires_at = $license->getExpiresAt();
						$expires_at = $expires_at ? wp_date( 'F j, Y - g:i A', strtotime( $expires_at ), new \DateTimeZone( 'UTC' ) ) : '-';

						$status_class      = 'lmfwc-status ' . strtolower( $status );
						$status_icon_class = 'dashicons dashicons-marker';
						if ( 'Sold' === $status ) {
							$status_icon_class = 'dashicons dashicons-yes';
						} elseif ( 'Delivered' === $status ) {
							$status_icon_class = 'lmfwc-icons delivered';
						}

						?>

					<tr>
						<td>
							<code class="lmfwc-placeholder"><?php echo esc_html( $license_key ); ?></code>
						</td>
						<td>
							<a href="<?php echo esc_url( get_edit_post_link( $order_id ) ); ?>" target="_blank">
								#<?php echo esc_html( $order_id ); ?>
							</a>
						</td>
						<td>
							<?php echo esc_html( $product_name ); ?>
						</td>
						<td>
							<div class="<?php echo esc_attr( $status_class ); ?>" style="width: 100px;">
								<span class="<?php echo esc_attr( $status_icon_class ); ?>"></span>
								<?php echo esc_html( $status ); ?>
							</div>
						</td>
						<td>
							<?php echo esc_html( $activation ); ?>
						</td>
						<td>
							<?php echo esc_html( $expires_at ); ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}


	/**
	 * Render license info on subscription details page.
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	public function render_frontend_license_info( int $subscription_id ) {
		$order_id     = get_post_meta( $subscription_id, '_subscrpt_lmfwc_license_order', true );
		$order        = wc_get_order( $order_id );
		$license_data = ! empty( $order ) ? apply_filters( 'lmfwc_get_customer_license_keys', $order ) : [];

		if ( empty( $license_data ) ) {
			return;
		}

		wp_enqueue_script( 'subscrpt_license_copy_js', SUBSCRIPT_PRO_ASSETS . '/js/frontend/license-copy.js', [], SUBSCRIPT_PRO_VERSION, true );

		?>
		<style>
			.lmfwc-myaccount-license-key {
				font-family: Consolas, monospace;
				font-size: 13px;
			}

			.subscrpt-license-key__row {
				display: flex;
				align-items: center;
				gap: 12px;
			}

			.subscrpt-license-key__row .lmfwc-myaccount-license-key {
				flex: 1 1 auto;
				min-width: 0;
				overflow-wrap: anywhere;
			}

			/* Scoped under the row so it outranks theme `button` rules. */
			.subscrpt-license-key__row .subscrpt-license-key__copy {
				flex: none;
				display: inline-flex;
				align-items: center;
				justify-content: center;
				width: 32px;
				height: 32px;
				margin: 0;
				padding: 0;
				border: 1px solid rgba(0, 0, 0, 0.15);
				border-radius: 4px;
				background: transparent;
				box-shadow: none;
				color: inherit;
				cursor: pointer;
			}

			.subscrpt-license-key__row .subscrpt-license-key__copy:hover,
			.subscrpt-license-key__row .subscrpt-license-key__copy:focus {
				background: rgba(0, 0, 0, 0.05);
				color: inherit;
			}

			.subscrpt-license-key__row .subscrpt-license-key__copy:focus-visible {
				outline: 2px solid currentColor;
				outline-offset: 2px;
			}

			.subscrpt-license-key__icon {
				display: block;
				width: 16px;
				height: 16px;
			}

			.subscrpt-license-key__icon--copied,
			.subscrpt-license-key__copy.is-copied .subscrpt-license-key__icon--copy {
				display: none;
			}

			.subscrpt-license-key__copy.is-copied .subscrpt-license-key__icon--copied {
				display: block;
				color: #16a34a;
			}
		</style>

		<h2><?php esc_html_e( 'Related Licenses', 'subscription-pro' ); ?></h2>

		<?php foreach ( $license_data as $license ) : ?>
			<table class="woocommerce-table woocommerce-table--order-details shop_table order_details">
				<thead>
					<tr>
						<th><?php echo esc_html( $license['name'] ?? 'License Key' ); ?></th>
						<th></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $license['keys'] ?? [] as $key ) : ?>
						<tr>
							<td>
								<div class="subscrpt-license-key__row">
									<span class="lmfwc-myaccount-license-key">
										<?php echo esc_html( $key->getDecryptedLicenseKey() ); ?>
									</span>
									<button
										type="button"
										class="subscrpt-license-key__copy"
										data-license-key="<?php echo esc_attr( $key->getDecryptedLicenseKey() ); ?>"
										data-label="<?php esc_attr_e( 'Copy license key', 'subscription-pro' ); ?>"
										data-copied-label="<?php esc_attr_e( 'License key copied', 'subscription-pro' ); ?>"
										data-failed-label="<?php esc_attr_e( 'Could not copy the license key', 'subscription-pro' ); ?>"
										aria-label="<?php esc_attr_e( 'Copy license key', 'subscription-pro' ); ?>"
										title="<?php esc_attr_e( 'Copy license key', 'subscription-pro' ); ?>"
									>
										<svg class="subscrpt-license-key__icon subscrpt-license-key__icon--copy" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="9" y="9" width="13" height="13" rx="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
										<svg class="subscrpt-license-key__icon subscrpt-license-key__icon--copied" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><polyline points="20 6 9 17 4 12"></polyline></svg>
									</button>
									<span class="subscrpt-license-key__status screen-reader-text" aria-live="polite"></span>
								</div>
							</td>
							
							<td>
								<?php if ( $key->getExpiresAt() ) : ?>
									<span class="lmfwc-myaccount-license-key">
										Valid until
										<br/>
										<b>
											<?php echo esc_html( wp_date( 'F j, Y  g:i A', strtotime( $key->getExpiresAt() ), new \DateTimeZone( 'UTC' ) ) ); ?>
										</b>
									</span>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endforeach; ?>

		<?php
	}
}
