<?php
/**
 * AutomatorWP filter: Subscription Status.
 *
 * @package SpringDevs\SubscriptionPro\Integrations\AutomatorWP
 */

namespace SpringDevs\SubscriptionPro\Integrations\AutomatorWP\filters;

use AutomatorWP_Integration_Filter;
use SpringDevs\Subscription\Illuminate\Helper as FreeHelper;

/**
 * Subscription Status Filter Class
 */
class SubsStatusFilter extends AutomatorWP_Integration_Filter {
	/**
	 * Integration.
	 *
	 * @var string
	 */
	public $integration = 'wp_subscription';

	/**
	 * Filter.
	 *
	 * @var string
	 */
	public $filter = 'wpsubs_awp_subs_activated';

	/**
	 * Register the filter
	 */
	public function register() {
		$subs_statuses = FreeHelper::get_verbose_status( '', true );

		// Remove 'draft', 'trash', & 'on-hold' status from the options.
		unset( $subs_statuses['draft'] );
		unset( $subs_statuses['trash'] );
		unset( $subs_statuses['on-hold'] );

		// Register the filter.
		automatorwp_register_filter(
			$this->filter,
			[
				'integration'   => $this->integration,

				'label'         => __( 'User subscription status', 'subscription-pro' ),
				'select_option' => __( 'User subscription <strong>status</strong>', 'subscription-pro' ),

				// translators: %1$s: Product. %2$s: Subscription status.
				'edit_label'    => sprintf( __( 'of %1$s is %2$s time(s)', 'subscription-pro' ), '{post}', '{status}' ),

				// translators: %1$s: Product. %2$s: Subscription status.
				'log_label'     => sprintf( __( 'Subscription of %1$s is %2$s', 'subscription-pro' ), '{post}', '{status}' ),

				'options'       => [
					'post'   => automatorwp_utilities_post_option(
						[
							'name'              => __( 'Product:', 'subscription-pro' ),
							'option_none_label' => __( 'any product', 'subscription-pro' ),
							'post_type'         => 'product',
						]
					),
					'status' => [
						'from'   => 'status',
						'fields' => [
							'status' => [
								'name'    => __( 'Status:', 'subscription-pro' ),
								'type'    => 'select',
								'options' => $subs_statuses,
								'default' => 'active',
							],
						],
					],
				],
			]
		);
	}

	/**
	 * User deserves check
	 *
	 * @param bool     $deserves_filter    True if user deserves filter, false otherwise.
	 * @param stdClass $filter             The filter object.
	 * @param int      $user_id            The user ID.
	 * @param array    $event              Event information.
	 * @param array    $filter_options     The filter's stored options.
	 * @param stdClass $automation         The trigger's automation object.
	 *
	 * @return bool True if user deserves trigger, false otherwise.
	 */
	public function user_deserves_filter( $deserves_filter, $filter, $user_id, $event, $filter_options, $automation ) {
		$product_id = $filter_options['post'];
		$status     = $filter_options['status'];

		// Bail if wrong configured.
		if ( empty( $product_id ) ) {
			$this->result = __( 'Filter did not pass. Product option has not been configured.', 'subscription-pro' );
			return false;
		}

		// Subs status check.
		$args          = [
			'user_id' => $user_id,
			'status'  => $status,
			'return'  => 'subscription_data',
		];
		$subscriptions = FreeHelper::get_subscriptions( $args );

		$chk_subs_status = count( $subscriptions ) > 0;
		if ( $product_id !== 'any' ) {
			$chk_subs_status = false;
			foreach ( $subscriptions as $subscription ) {
				if ( intval( $subscription['product']['product_id'] ) === intval( $product_id ) ) {
					$chk_subs_status = true;
					break;
				}
			}
		}

		// log the result.
		if ( $chk_subs_status ) {
			$this->result = sprintf(
				// translators: %1$s: User ID. %2$s: Product ID. %3$s: Subscription status.
				__( 'Filter passed. User (#%1$s) has subscription with the selected status. [Product ID: %2$s | Status: %3$s]', 'subscription-pro' ),
				$user_id,
				$product_id,
				$status
			);
		} else {
			$this->result = sprintf(
				// translators: %1$s: User ID. %2$s: Product ID. %3$s: Subscription status.
				__( 'Filter did not pass. User (#%1$s) does not have subscription with the selected status. [Product ID: %2$s | Status: %3$s]', 'subscription-pro' ),
				$user_id,
				$product_id,
				$status
			);
		}

		return $chk_subs_status;
	}
}
