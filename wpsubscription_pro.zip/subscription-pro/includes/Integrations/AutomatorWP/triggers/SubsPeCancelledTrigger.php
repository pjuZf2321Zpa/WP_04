<?php
/**
 * AutomatorWP trigger: Subscription Pending Cancellation.
 *
 * @package SpringDevs\SubscriptionPro\Integrations\AutomatorWP
 */

namespace SpringDevs\SubscriptionPro\Integrations\AutomatorWP\triggers;

use AutomatorWP_Integration_Trigger;
use SpringDevs\Subscription\Illuminate\Helper as FreeHelper;

/**
 * Subscription Pending Cancellation Trigger Class
 */
class SubsPeCancelledTrigger extends AutomatorWP_Integration_Trigger {
	/**
	 * Integration.
	 *
	 * @var string
	 */
	public $integration = 'wp_subscription';

	/**
	 * Trigger.
	 *
	 * @var string
	 */
	public $trigger = 'wpsubs_awp_subs_pe_cancelled';

	/**
	 * Register the trigger
	 */
	public function register() {
		automatorwp_register_trigger(
			$this->trigger,
			[
				'action'        => 'subscrpt_subscription_pending_cancellation',
				'function'      => [ $this, 'trigger_listener' ],
				'integration'   => $this->integration,

				'label'         => __( 'User subscription is pending cancellation', 'subscription-pro' ),
				'select_option' => __( 'User subscription awaiting <strong>cancellation</strong>', 'subscription-pro' ),

				// translators: %1$s: Product. %2$s: Number of times.
				'edit_label'    => sprintf( __( 'Subscription of %1$s is pending cancellation %2$s time(s)', 'subscription-pro' ), '{post}', '{times}' ),
				// translators: %1$s: Product.
				'log_label'     => sprintf( __( 'Subscription of %1$s is pending cancellation', 'subscription-pro' ), '{post}' ),

				'options'       => [
					'post'  => automatorwp_utilities_post_option(
						[
							'name'              => __( 'Product:', 'subscription-pro' ),
							'option_none_label' => __( 'any product', 'subscription-pro' ),
							'post_type'         => 'product',
						]
					),
					'times' => automatorwp_utilities_times_option(),
				],

				'tags'          => array_merge(
					automatorwp_utilities_post_tags( __( 'Product', 'subscription-pro' ) ),
					automatorwp_woocommerce_order_tags(),
					automatorwp_utilities_times_tag()
				),

				'priority'      => 10,
				'accepted_args' => 1,
			]
		);
	}

	/**
	 * Trigger listener.
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	public function trigger_listener( $subscription_id ) {
		$subscription_data = FreeHelper::get_subscription_data( $subscription_id );

		// Trigger actions.
		automatorwp_trigger_event(
			[
				'trigger'         => $this->trigger,
				'user_id'         => $subscription_data['user_id'] ?? 0,
				'subscription_id' => $subscription_id,
				'post_id'         => $subscription_data['product']['product_id'] ?? 0,
				'order_id'        => $subscription_data['order']['order_id'] ?? 0,
			]
		);
	}

	/**
	 * User deserves check
	 *
	 * @param bool     $deserves_trigger   True if user deserves trigger, false otherwise.
	 * @param stdClass $trigger            The trigger object.
	 * @param int      $user_id            The user ID.
	 * @param array    $event              Event information.
	 * @param array    $trigger_options    The trigger's stored options.
	 * @param stdClass $automation         The trigger's automation object.
	 *
	 * @return bool                          True if user deserves trigger, false otherwise.
	 */
	public function user_deserves_trigger( $deserves_trigger, $trigger, $user_id, $event, $trigger_options, $automation ) {
		// Don't deserve if post is not received
		if ( ! isset( $event['post_id'] ) ) {
			return false;
		}

		// Don't deserve if post doesn't match with the trigger option
		if ( ! automatorwp_posts_matches( $event['post_id'], $trigger_options['post'] ) ) {
			return false;
		}

		return $deserves_trigger;
	}

	/**
	 * Register the required hooks
	 */
	public function hooks() {
		// Log meta data
		add_filter( 'automatorwp_user_completed_trigger_log_meta', [ $this, 'log_meta' ], 10, 6 );

		parent::hooks();
	}

	/**
	 * Trigger custom log meta
	 *
	 * @param array    $log_meta           Log meta data.
	 * @param stdClass $trigger            The trigger object.
	 * @param int      $user_id            The user ID.
	 * @param array    $event              Event information.
	 * @param array    $trigger_options    The trigger's stored options.
	 * @param stdClass $automation         The trigger's automation object.
	 *
	 * @return array
	 */
	public function log_meta( $log_meta, $trigger, $user_id, $event, $trigger_options, $automation ) {
		// Bail if action type don't match this action
		if ( $trigger->type !== $this->trigger ) {
			return $log_meta;
		}

		$log_meta['subscription_id'] = ( isset( $event['subscription_id'] ) ? $event['subscription_id'] : 0 );

		return $log_meta;
	}
}
