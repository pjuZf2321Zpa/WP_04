<?php
/**
 * AutomatorWP integration main file.
 *
 * @package SpringDevs\SubscriptionPro\Integrations\AutomatorWP
 */

namespace SpringDevs\SubscriptionPro\Integrations\AutomatorWP;

use SpringDevs\SubscriptionPro\Integrations\AutomatorWP\filters\SubsStatusFilter;
use SpringDevs\SubscriptionPro\Integrations\AutomatorWP\triggers\{
	SubsActiveTrigger,
	SubsCancelledTrigger,
	SubsExpiredTrigger,
	SubsGracePeriodTrigger,
	SubsGracePeriodOverTrigger,
	SubsPeCancelledTrigger,
	SubsPendingTrigger,
	SubsTrialOverTrigger
};

/**
 * AutomatorWP Integration Class
 */
class AutomatorWP {
	/**
	 * Constructor
	 */
	public function __construct() {
		if ( ! $this->check_plugin() ) {
			return;
		}

		// Register app.
		add_action( 'automatorwp_init', [ $this, 'register_integration' ] );

		// Register filters.
		new SubsStatusFilter();

		// Register triggers.
		new SubsActiveTrigger();
		new SubsPendingTrigger();
		new SubsCancelledTrigger();
		new SubsPeCancelledTrigger();
		new SubsExpiredTrigger();
		new SubsTrialOverTrigger();
		new SubsGracePeriodTrigger();
		new SubsGracePeriodOverTrigger();
	}

	/**
	 * Check if target plugin is active.
	 */
	public function check_plugin() {
		$is_awp_plugin_active = is_plugin_active( 'automatorwp/automatorwp.php' );
		$is_awp_class_exists  = class_exists( 'AutomatorWP' );

		return $is_awp_plugin_active && $is_awp_class_exists;
	}

	/**
	 * Register this integration
	 */
	public function register_integration() {
		automatorwp_register_integration(
			'wp_subscription',
			[
				'label' => 'WPSubscription',
				'icon'  => SUBSCRIPT_PRO_URL . '/includes/Integrations/AutomatorWP/assets/wpsubs_logo.png',
			]
		);
	}
}
