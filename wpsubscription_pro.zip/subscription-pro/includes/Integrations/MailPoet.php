<?php
/**
 * MailPoet integration class file.
 *
 * @package SpringDevs\SubscriptionPro\Integrations
 */

namespace SpringDevs\SubscriptionPro\Integrations;

use SpringDevs\Subscription\Illuminate\Helper as FreeHelper;

/**
 * Class MailPoet
 */
class MailPoet {
	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'init', [ $this, 'init' ] );
	}

	/**
	 * Initialize
	 */
	public function init() {
		if ( ! $this->is_plugin_active() ) {
			return;
		}

		// Subscription triggers.
		add_action( 'subscrpt_subscription_activated', [ $this, 'subscription_activated' ] );
		add_action( 'subscrpt_subscription_pending', [ $this, 'subscription_pending' ] );
		add_action( 'subscrpt_subscription_cancelled', [ $this, 'subscription_cancelled' ] );
		add_action( 'subscrpt_subscription_pending_cancellation', [ $this, 'subscription_pending_cancellation' ] );
		add_action( 'subscrpt_subscription_expired', [ $this, 'subscription_expired' ] );
		add_action( 'subscrpt_subscription_trial_ended', [ $this, 'subscription_trial_ended' ] );
		add_action( 'subscrpt_grace_period_started', [ $this, 'subscription_in_grace_period' ] );
	}

	/**
	 * Plugin Check
	 */
	public function is_plugin_active() {
		$is_mailpoet_plugin_active = is_plugin_active( 'mailpoet-premium/mailpoet-premium.php' );

		return $is_mailpoet_plugin_active;
	}

	/**
	 * Get MailPoet formatted subscriber data.
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	public function get_mailpoet_formatted_subscriber_data( $subscription_id ) {
		$subscription = FreeHelper::get_subscription_data( $subscription_id );

		$user  = get_user_by( 'id', $subscription['user_id'] ?? 0 );
		$email = $user->user_email ?? '';

		$custom_data = [
			'subscription_id'        => [
				'value' => $subscription_id,
			],
			'subscription_status'    => [
				'value' => $subscription['status'] ?? '',
			],
			'user_id'                => [
				'value' => $subscription['user_id'] ?? '',
			],
			'user_email'             => [
				'value' => $email,
			],
			'schedule_timing_per'    => [
				'value' => $subscription['schedule']['timing_per'] ?? '',
			],
			'schedule_timing_option' => [
				'value' => $subscription['schedule']['timing_option'] ?? '',
			],
			'price'                  => [
				'value' => $subscription['price'] ?? 0,
			],
			'signup_fee'             => [
				'value' => $subscription['signup_fee'] ?? 0,
			],
			'product_id'             => [
				'value' => $subscription['product']['product_id'] ?? 0,
			],
			'product_variation_id'   => [
				'value' => $subscription['product']['variation_id'] ?? 0,
			],
			'order_id'               => [
				'value' => $subscription['order']['order_id'] ?? 0,
			],
			'start_date'             => [
				'value' => $subscription['start_date'] ?? '',
			],
			'next_renewal_date'      => [
				'value' => $subscription['next_date'] ?? '',
			],
		];

		return [
			'email'       => $email,
			'custom_data' => $custom_data,
		];
	}

	/**
	 * Handle subscription activated event.
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	public function subscription_activated( $subscription_id ) {
		$data = $this->get_mailpoet_formatted_subscriber_data( $subscription_id );

		// Do not proceed if email is empty.
		if ( empty( $data['email'] ) ) {
			return;
		}

		do_action( 'wpsubs_mp_subscription_activated', $data['email'], $data['custom_data'] );
	}

	/**
	 * Handle subscription pending event.
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	public function subscription_pending( $subscription_id ) {
		$data = $this->get_mailpoet_formatted_subscriber_data( $subscription_id );

		// Do not proceed if email is empty.
		if ( empty( $data['email'] ) ) {
			return;
		}

		do_action( 'wpsubs_mp_subscription_pending', $data['email'], $data['custom_data'] );
	}

	/**
	 * Handle subscription cancelled event.
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	public function subscription_cancelled( $subscription_id ) {
		$data = $this->get_mailpoet_formatted_subscriber_data( $subscription_id );

		// Do not proceed if email is empty.
		if ( empty( $data['email'] ) ) {
			return;
		}

		do_action( 'wpsubs_mp_subscription_cancelled', $data['email'], $data['custom_data'] );
	}

	/**
	 * Handle subscription pending cancellation event.
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	public function subscription_pending_cancellation( $subscription_id ) {
		$data = $this->get_mailpoet_formatted_subscriber_data( $subscription_id );

		// Do not proceed if email is empty.
		if ( empty( $data['email'] ) ) {
			return;
		}

		do_action( 'wpsubs_mp_subscription_pending_cancellation', $data['email'], $data['custom_data'] );
	}

	/**
	 * Handle subscription expired event.
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	public function subscription_expired( $subscription_id ) {
		$data = $this->get_mailpoet_formatted_subscriber_data( $subscription_id );

		// Do not proceed if email is empty.
		if ( empty( $data['email'] ) ) {
			return;
		}

		do_action( 'wpsubs_mp_subscription_expired', $data['email'], $data['custom_data'] );
	}

	/**
	 * Handle subscription trial ended event.
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	public function subscription_trial_ended( $subscription_id ) {
		$data = $this->get_mailpoet_formatted_subscriber_data( $subscription_id );

		// Do not proceed if email is empty.
		if ( empty( $data['email'] ) ) {
			return;
		}

		do_action( 'wpsubs_mp_subscription_trial_ended', $data['email'], $data['custom_data'] );
	}

	/**
	 * Handle subscription in grace period event.
	 *
	 * @param int $subscription_id Subscription ID.
	 */
	public function subscription_in_grace_period( $subscription_id ) {
		$data = $this->get_mailpoet_formatted_subscriber_data( $subscription_id );

		// Do not proceed if email is empty.
		if ( empty( $data['email'] ) ) {
			return;
		}

		do_action( 'wpsubs_mp_subscription_in_grace_period', $data['email'], $data['custom_data'] );
	}
}
