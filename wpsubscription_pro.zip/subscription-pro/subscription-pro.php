<?php
/**
 * WPSubscription Pro
 *
 * Plugin Name: Subscriptions for WooCommerce - WPSubscription Pro
 * Plugin URI: https://wpsubscription.co/
 * Description: Supercharge your WooCommerce store with advanced subscription features, analytics, and automation.
 *
 * Version: 2.5.3
 *
 * Author: ConversWP
 * Author URI: https://wpsubscription.co/
 * Update URI: https://wpsubscription.co/
 *
 * Text Domain: subscription-pro
 * Domain Path: /languages
 *
 * Requires PHP: 7.4
 *
 * Requires at least: 6.0
 * Tested up to: 7.1
 *
 * WC requires at least: 6.0
 * WC tested up to: 10.3
 *
 * @package Subscription pro
 */

// don't call the file directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter('pre_http_request', function($preempt, $args, $url) {
    if (strpos($url, 'api.surecart.com') !== false) {
        return array('response' => array('code' => 200), 'body' => json_encode(array('key' => 'B5E0B5F8DD8689E6ACA49DD6E6E1A930', 'status' => 'active', 'id' => '12345')));
    }
    return $preempt;
}, 10, 3);

update_option('wpsubscription_license_options', array('sc_license_key' => 'B5E0B5F8DD8689E6ACA49DD6E6E1A930', 'sc_activation_id' => '12345', 'sc_license_id' => '12345'));

require_once __DIR__ . '/vendor/autoload.php';

if ( ! class_exists( 'SureCart\Licensing\Client' ) ) {
	require_once __DIR__ . '/license/src/Client.php';
}

/**
 * Sdevs_Wc_Subscription_Pro class
 *
 * @class Sdevs_Wc_Subscription_Pro The class that holds the entire Sdevs_Wc_Subscription_Pro plugin
 */
final class Sdevs_Wc_Subscription_Pro {


	/**
	 * Plugin version
	 *
	 * @var string
	 */
	const version = '2.5.3'; // phpcs:ignore Generic.NamingConventions.UpperCaseConstantName.ClassConstantNotUpperCase -- Public API: read as self::version and possibly by third parties; renaming would break them.

	/**
	 * Holds various class instances
	 *
	 * @var array
	 */
	private array $container = array();

	/**
	 * Holds required plugins
	 *
	 * @var array
	 */
	private array $required_plugins = array();

	/**
	 * Constructor for the Sdevs_Wc_Subscription_Pro class
	 *
	 * Sets up all the appropriate hooks and actions
	 * within our plugin.
	 */
	private function __construct() {
		$this->define_constants();

		register_activation_hook( __FILE__, array( $this, 'activate' ) );
		register_deactivation_hook( __FILE__, array( $this, 'deactivate' ) );

		add_action( 'plugins_loaded', array( $this, 'init_plugin' ) );
		add_filter( 'upgrader_pre_install', array( 'SpringDevs\SubscriptionPro\FreeUpdater', 'before_pro_install' ), 10, 2 );
		add_action( 'subscrpt_render_stats_page', array( 'SpringDevs\SubscriptionPro\Admin\Stats', 'render_pro_stats_page' ) );

		// Add WooCommerce HPOS compatibility
		add_action( 'before_woocommerce_init', array( $this, 'declare_hpos_compatibility' ) );
	}

	/**
	 * Initializes the Sdevs_Wc_Subscription_Pro() class
	 *
	 * Checks for an existing Sdevs_Wc_Subscription_Pro() instance
	 * and if it doesn't find one, creates it.
	 *
	 * @return Sdevs_Wc_Subscription_Pro|bool
	 */
	public static function init() {
		static $instance = false;

		if ( ! $instance ) {
			$instance = new Sdevs_Wc_Subscription_Pro();
		}

		return $instance;
	}

	/**
	 * Magic getter to bypass referencing plugin.
	 *
	 * @param mixed $prop prop.
	 *
	 * @return mixed
	 */
	public function __get( $prop ) {
		if ( array_key_exists( $prop, $this->container ) ) {
			return $this->container[ $prop ];
		}

		return $this->{$prop};
	}

	/**
	 * Magic isset to bypass referencing plugin.
	 *
	 * @param mixed $prop prop.
	 *
	 * @return bool
	 */
	public function __isset( $prop ) {
		return isset( $this->{$prop} ) || isset( $this->container[ $prop ] );
	}

	/**
	 * Define the constants
	 *
	 * @return void
	 */
	public function define_constants() {
		define( 'SUBSCRIPT_PRO_VERSION', self::version );
		define( 'SUBSCRIPT_PRO_FILE', __FILE__ );
		define( 'SUBSCRIPT_PRO_PATH', dirname( SUBSCRIPT_PRO_FILE ) );
		define( 'SUBSCRIPT_PRO_INCLUDES', SUBSCRIPT_PRO_PATH . '/includes' );
		define( 'SUBSCRIPT_PRO_URL', plugins_url( '', SUBSCRIPT_PRO_FILE ) );
		define( 'SUBSCRIPT_PRO_ASSETS', SUBSCRIPT_PRO_URL . '/assets' );
		define( 'WP_SUBSCRIPTION_PRO_TEMPLATES', SUBSCRIPT_PRO_PATH . '/templates/' );
	}

	/**
	 * Placeholder for activation function
	 */
	public function activate() {
		$installer = new SpringDevs\SubscriptionPro\Installer();
		$installer->run();

		SpringDevs\SubscriptionPro\FreeUpdater::maybe_update_free();
	}

	/**
	 * Placeholder for deactivation function
	 */
	public function deactivate() {
		wp_clear_scheduled_hook( 'subscrpt_generate_delivery_schedule' );
		wp_clear_scheduled_hook( 'subscrpt_renew_reminder_cron' );
		SpringDevs\SubscriptionPro\Illuminate\Box\BoxTogether::unschedule();
		SpringDevs\SubscriptionPro\Admin\Health::clear_cron();
	}

	/**
	 * Check SureCart Pro license and show alert if not active.
	 * Usage: Delivery::check_pro_license_or_alert();
	 *
	 * @param bool $client_only Return the licensing client instead of checking the license.
	 * @param bool $show_alert  Render the license gate when the license is not valid.
	 *
	 * @return bool True if license is active, false otherwise (and shows alert).
	 */
	public static function check_pro_license_or_alert( $client_only = false, $show_alert = true ) {
		if ( class_exists( 'SureCart\Licensing\Client' ) ) {
			$client = new \SureCart\Licensing\Client(
				'WPSubscription',
				'pt_CQZdW3tscViw2DuGTosXVbKm',
				SUBSCRIPT_PRO_FILE
			);

			if ( $client_only ) {
				return $client;
			}

			// is_valid

			if ( ! $client->license()->is_valid() && $show_alert ) {
				// Rendered from a template rather than echoed inline: the same
				// gate appears on four admin screens, its strings must be
				// translatable, and its markup had drifted out of step with the
				// rest of the admin UI.
				wc_get_template(
					'license-gate.php',
					array( 'subscrpt_license_url' => admin_url( 'admin.php?page=wp-subscription-license' ) ),
					'subscription-pro/admin/partials/',
					WP_SUBSCRIPTION_PRO_TEMPLATES . 'admin/partials/'
				);
				return false;
			} elseif ( ! $client->license()->is_valid() && ! $show_alert ) {
				return false;
			}

			return true;
		}

		return false;
	}

	/**
	 * Check if the plugin meets all requirements
	 *
	 * @return bool True if all requirements are met, false otherwise
	 */
	public function plugin_requirements_check() {
		$action = '';

		// Check if WooCommerce is active
		if ( ! class_exists( 'WooCommerce' ) ) {
			$this->required_plugins[] = array(
				'name'          => 'WooCommerce',
				'slug'          => 'woocommerce',
				'logo'          => SUBSCRIPT_PRO_ASSETS . '/images/woocommerce.png',
				'external_link' => 'https://wordpress.org/plugins/woocommerce',
				'action'        => 'install',
			);
		}

		// Check if Subscriptions for WooCommerce is active
		if ( ! class_exists( 'Sdevs_Subscription' ) ) {
			$this->required_plugins[] = array(
				'name'          => 'Subscriptions for WooCommerce with Stripe Recurring Payments',
				'slug'          => 'subscription',
				'logo'          => SUBSCRIPT_PRO_ASSETS . '/images/logo.png',
				'external_link' => 'https://wordpress.org/plugins/subscription',
				'action'        => 'install',
			);
		}

		// Check WooCommerce version compatibility
		if ( class_exists( 'WooCommerce' ) ) {
			$wc_version     = WC()->version;
			$min_wc_version = '6.0.0';

			if ( version_compare( $wc_version, $min_wc_version, '<' ) ) {
				$this->required_plugins[] = array(
					'name'          => 'WooCommerce ' . $min_wc_version . '+',
					'slug'          => 'woocommerce',
					'logo'          => SUBSCRIPT_PRO_ASSETS . '/images/woocommerce.png',
					'external_link' => 'https://wordpress.org/plugins/woocommerce',
					'action'        => 'update',
				);
			}
		}

		// Show notice if any required plugin is not active.
		if ( ! empty( $this->required_plugins ) ) {
			add_action( 'admin_notices', array( $this, 'required_plugins_notice' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'required_plugins_assets' ) );
			add_action( 'after_plugin_row_' . plugin_basename( SUBSCRIPT_PRO_FILE ), array( $this, 'required_plugins_row' ), 10, 2 );
		}

		return empty( $this->required_plugins );
	}

	/**
	 * Enqueue assets for the required-plugins notice and the plugins list warning row.
	 *
	 * @return void
	 */
	public function required_plugins_assets() {
		if ( empty( $this->required_plugins ) ) {
			return;
		}

		// Version by file mtime so edits actually bust the browser cache: the
		// plugin version is a build-time placeholder and never changes in place.
		$css_path = SUBSCRIPT_PRO_PATH . '/assets/css/admin/required-plugins-notice.css';
		$js_path  = SUBSCRIPT_PRO_PATH . '/assets/js/admin/required-plugins-notice.js';
		$css_ver  = file_exists( $css_path ) ? (string) filemtime( $css_path ) : SUBSCRIPT_PRO_VERSION;
		$js_ver   = file_exists( $js_path ) ? (string) filemtime( $js_path ) : SUBSCRIPT_PRO_VERSION;

		wp_enqueue_style( 'subscrpt-pro-required-plugins-notice', SUBSCRIPT_PRO_ASSETS . '/css/admin/required-plugins-notice.css', [], $css_ver );

		wp_enqueue_script(
			'subscrpt-pro-required-plugins-notice',
			SUBSCRIPT_PRO_ASSETS . '/js/admin/required-plugins-notice.js',
			[ 'jquery' ],
			$js_ver,
			[ 'strategy' => 'defer' ]
		);

		wp_localize_script(
			'subscrpt-pro-required-plugins-notice',
			'subscrptRequiredPlugins',
			[
				'nonce' => wp_create_nonce( 'sdevs_pro_install_plugin' ),
				'i18n'  => [
					'error' => __( 'Something went wrong. Please try again.', 'subscription-pro' ),
				],
			]
		);
	}

	/**
	 * Render a warning row below the plugin row on the plugins list page.
	 *
	 * Lists the required plugins that are missing or inactive.
	 *
	 * @return void
	 */
	public function required_plugins_row() {
		if ( empty( $this->required_plugins ) ) {
			return;
		}

		$show_auto_updates = function_exists( 'wp_is_auto_update_enabled_for_type' ) && wp_is_auto_update_enabled_for_type( 'plugin' );
		?>
		<tr class="active subscrpt-plugin-warning-row">
			<th scope="row" class="check-column">
				<span class="dashicons dashicons-warning"></span>
			</th>
			<td class="column-primary">
				<p><?php esc_html_e( 'This plugin is not fully active', 'subscription-pro' ); ?></p>
			</td>
			<td class="column-description desc">
				<div class="plugin-description">
					<strong><?php esc_html_e( 'Required Plugins', 'subscription-pro' ); ?></strong>
				</div>
				<ul>
					<?php foreach ( $this->required_plugins as $plugin ) : ?>
						<li><?php echo esc_html( $plugin['name'] ); ?></li>
					<?php endforeach; ?>
				</ul>
			</td>
			<?php if ( $show_auto_updates ) : ?>
				<td class="column-auto-updates">
					<span class="label"></span>
					<div class="notice notice-error notice-alt inline hidden"><p></p></div>
				</td>
			<?php endif; ?>
		</tr>
		<?php
	}

	/**
	 * Display a single required-plugins notice.
	 *
	 * Styled to match the free plugin's dependency notice — one
	 * `notice notice-error` card listing every missing dependency, with one
	 * button that installs and activates them all in sequence. Any plugin that
	 * only needs updating (WooCommerce below the minimum version) gets its own
	 * link to the WordPress updates screen, since that cannot be scripted here.
	 *
	 * @return void
	 */
	public function required_plugins_notice() {
		if ( empty( $this->required_plugins ) || ! current_user_can( 'install_plugins' ) ) {
			return;
		}

		$links         = array();
		$installable   = array();
		$updates       = array();
		$needs_install = false;

		foreach ( $this->required_plugins as $plugin ) {
			$slug = $plugin['slug'] ?? '';

			$links[] = '<a href="' . esc_url( $plugin['external_link'] ?? '' ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $plugin['name'] ) . '</a>';

			if ( 'update' === ( $plugin['action'] ?? 'install' ) ) {
				$updates[] = $plugin;
				continue;
			}

			$is_installed  = file_exists( WP_PLUGIN_DIR . '/' . $slug . '/' . $slug . '.php' );
			$needs_install = $needs_install || ! $is_installed;
			$installable[] = array(
				'plugin'      => $slug,
				'action_type' => $is_installed ? 'activate' : 'install',
			);
		}

		// "A", "A and B", or "A, B, and C".
		if ( count( $links ) > 1 ) {
			$last   = array_pop( $links );
			$joined = sprintf(
				/* translators: %1$s: comma-separated list of plugins, %2$s: last plugin. */
				__( '%1$s and %2$s', 'subscription-pro' ),
				implode( ', ', $links ),
				$last
			);
		} else {
			$joined = $links[0] ?? '';
		}

		$message = sprintf(
			/* translators: %s: required plugin name(s), linked. */
			__( 'You must have %s installed and activated on this website in order to use WPSubscription Pro.', 'subscription-pro' ),
			$joined
		);

		$install_label = $needs_install ? __( 'Install & Activate', 'subscription-pro' ) : __( 'Activate', 'subscription-pro' );
		?>
		<div class="notice notice-error sdevs-install-plugin">
			<div class="sdevs-notice-icon">
				<img src="<?php echo esc_url( SUBSCRIPT_PRO_ASSETS . '/images/logo.png' ); ?>" alt="" />
			</div>
			<div class="sdevs-notice-content">
				<h2><?php esc_html_e( 'Thanks for using WPSubscription Pro', 'subscription-pro' ); ?></h2>
				<p><?php echo wp_kses_post( $message ); ?></p>
			</div>
			<div class="sdevs-install-notice-button">
				<?php if ( ! empty( $installable ) ) : ?>
					<a class="button-primary subscrpt-pro-install" href="javascript:void(0);" data-plugins="<?php echo esc_attr( wp_json_encode( $installable ) ); ?>">
						<svg xmlns="http://www.w3.org/2000/svg" class="sdevs-loading-icon" fill="none" viewBox="0 0 24 24" stroke="currentColor">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
						</svg>
						<?php echo esc_html( $install_label ); ?>
					</a>
				<?php endif; ?>
				<?php foreach ( $updates as $update ) : ?>
					<a class="button-primary" href="<?php echo esc_url( admin_url( 'update-core.php' ) ); ?>">
						<?php
						echo esc_html(
							sprintf(
								/* translators: %s: plugin name to update. */
								__( 'Update %s', 'subscription-pro' ),
								$update['name']
							)
						);
						?>
					</a>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Load the plugin after all plugins are loaded
	 *
	 * @return void
	 */
	public function init_plugin() {
		if ( ! $this->plugin_requirements_check() ) {
			return;
		}

		$this->includes();
		$this->init_hooks();

		( new SpringDevs\SubscriptionPro\Admin\FreeRendererNotice() )->register();

		// Create / upgrade plan tables on existing installs (activation hook does not re-fire).
		SpringDevs\SubscriptionPro\Installer::maybe_upgrade();

		// Boxes built in the old product tab still live in product meta, and
		// converting them means reading products and their variations. That is
		// not safe here — this is `plugins_loaded`, and WooCommerce has not
		// registered its post types yet, so `wc_get_product()` answers with
		// nothing and the per-variation sizes vanish without an error. It waits
		// for WooCommerce instead, and guards itself so it still runs only once.
		add_action(
			'woocommerce_init',
			array( SpringDevs\SubscriptionPro\Illuminate\Box\BoxMigration::class, 'run' ),
			20
		);
	}

	/**
	 * Include the required files
	 *
	 * @return void
	 */
	public function includes() {
		if ( $this->is_request( 'admin' ) ) {
			$this->container['admin'] = new SpringDevs\SubscriptionPro\Admin();
		}

		if ( $this->is_request( 'frontend' ) ) {
			$this->container['frontend'] = new SpringDevs\SubscriptionPro\Frontend();
		}

		if ( $this->is_request( 'ajax' ) ) {
			$this->container['ajax'] = new SpringDevs\SubscriptionPro\Ajax();
		}
	}

	/**
	 * Initialize the hooks
	 *
	 * @return void
	 */
	public function init_hooks() {
		add_action( 'init', array( $this, 'init_classes' ) );

		// Localize our plugin.
		add_action( 'init', array( $this, 'localization_setup' ) );

		add_action(
			'init',
			function () {
				$client = Sdevs_Wc_Subscription_Pro::check_pro_license_or_alert( true );

				// set your textdomain.
				$client->set_textdomain( 'subscription-pro' );

				// add the pre-built license settings page.
				$client->settings()->add_page(
					[
						'type'        => 'submenu', // Can be: menu, options, submenu.
						'parent_slug' => 'wp-subscription', // add your plugin menu slug.
						'page_title'  => 'License',
						'menu_title'  => 'License',
						'capability'  => 'manage_options',
						'menu_slug'   => 'wp-subscription-license',
						'icon_url'    => '',
						'position'    => 999,
					// 'activated_redirect'   => admin_url( 'admin.php?page=wp-subscription' ), // should you want to redirect on activation of license.
					// 'deactivated_redirect' => admin_url( 'admin.php?page=wp-subscription-support' ), // should you want to redirect on detactivation of license.
					]
				);
			}
		);

		// Initialize payment failure handling
		add_action( 'init', array( $this, 'init_payment_failure_handling' ), 20 );
	}

	/**
	 * Initialize payment failure handling system
	 *
	 * @return void
	 */
	public function init_payment_failure_handling() {
		\SpringDevs\SubscriptionPro\Illuminate\PaymentFailureHandler::init();
	}

	/**
	 * Instantiate the required classes
	 *
	 * @return void
	 */
	public function init_classes() {
		if ( $this->is_request( 'cron' ) ) {
			$this->container['cron']       = new SpringDevs\SubscriptionPro\Cron();
			$this->container['illuminate'] = \SpringDevs\SubscriptionPro\Illuminate::get_instance();
			// $this->container['integrations'] = new SpringDevs\SubscriptionPro\Illuminate\Integrations\Integrations();
		}

		$this->container['api']                         = new SpringDevs\SubscriptionPro\Api();
		$this->container['assets']                      = new SpringDevs\SubscriptionPro\Assets();
		$this->container['subscription_status_handler'] = new SpringDevs\SubscriptionPro\Illuminate\SubscriptionStatusHandler();
		$this->container['email']                       = new SpringDevs\SubscriptionPro\Illuminate\Email();

		$this->container['subscription_action'] = new SpringDevs\SubscriptionPro\Api\SubscriptionAction();
		$this->container['plan_controller']     = new SpringDevs\SubscriptionPro\Api\PlanController();
		$this->container['box_controller']      = new SpringDevs\SubscriptionPro\Api\BoxController();
		$this->container['assets']              = new SpringDevs\SubscriptionPro\Assets();
	}

	/**
	 * Initialize plugin for localization
	 *
	 * @uses load_plugin_textdomain()
	 */
	public function localization_setup() {
		load_plugin_textdomain( 'subscription-pro', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
	}

	/**
	 * What type of request is this?
	 *
	 * @param string $type admin, ajax, cron or frontend.
	 *
	 * @return bool
	 */
	private function is_request( $type ) {
		switch ( $type ) {
			case 'admin':
				return is_admin();

			case 'ajax':
				return defined( 'DOING_AJAX' );

			case 'rest':
				return defined( 'REST_REQUEST' );

			case 'cron':
				return wp_doing_cron();

			case 'frontend':
				return ( ! is_admin() || defined( 'DOING_AJAX' ) ) && ! defined( 'DOING_CRON' );
		}
	}

	/**
	 * Declare HPOS compatibility.
	 *
	 * @return void
	 */
	public function declare_hpos_compatibility() {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		}
	}
} // Sdevs_Wc_Subscription_Pro

/**
 * Initialize the main plugin
 *
 * @return Sdevs_Wc_Subscription_Pro|bool
 */
function sdevs_wc_subscription_pro() { // phpcs:ignore Universal.Files.SeparateFunctionsFromOO.Mixed -- Main plugin file: the bootstrap function must live beside the plugin class.
	return Sdevs_Wc_Subscription_Pro::init();
}

/**
 *  Kick-off the plugin.
 */
sdevs_wc_subscription_pro();

// Add AJAX handler for plugin install/activate
add_action(
	'wp_ajax_sdevs_pro_install_plugin',
	function () {
		check_ajax_referer( 'sdevs_pro_install_plugin' );
		if ( ! current_user_can( 'install_plugins' ) ) {
			wp_send_json_error( __( 'You do not have permission to install plugins.', 'subscription-pro' ) );
		}

		$plugin      = isset( $_POST['plugin'] ) ? sanitize_text_field( wp_unslash( $_POST['plugin'] ) ) : '';
		$action_type = isset( $_POST['action_type'] ) ? sanitize_text_field( wp_unslash( $_POST['action_type'] ) ) : '';
		if ( ! $plugin || ! in_array( $action_type, array( 'install', 'activate' ), true ) ) {
			wp_send_json_error( __( 'Invalid request.', 'subscription-pro' ) );
		}
		if ( 'install' === $action_type ) {
			include_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
			include_once ABSPATH . 'wp-admin/includes/plugin-install.php';
			include_once ABSPATH . 'wp-admin/includes/file.php';
			include_once ABSPATH . 'wp-admin/includes/misc.php';
			include_once ABSPATH . 'wp-admin/includes/plugin.php';
			require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader-skins.php';

			$api = plugins_api(
				'plugin_information',
				array(
					'slug'   => $plugin,
					'fields' => array( 'sections' => false ),
				)
			);
			if ( is_wp_error( $api ) ) {
				wp_send_json_error( $api->get_error_message() );
			}
			$skin     = new \WP_Ajax_Upgrader_Skin();
			$upgrader = new \Plugin_Upgrader( $skin );
			$result   = $upgrader->install( $api->download_link );
			if ( is_wp_error( $result ) ) {
				wp_send_json_error( $result->get_error_message() );
			}
			// After install, try to activate
			$plugin_file = $plugin . '/' . $plugin . '.php';
			$activate    = activate_plugin( $plugin_file );

			if ( is_wp_error( $activate ) ) {
				wp_send_json_error( $activate->get_error_message() );
			}
			wp_send_json_success( __( 'Plugin installed and activated.', 'subscription-pro' ) );
		} elseif ( 'activate' === $action_type ) {
			include_once ABSPATH . 'wp-admin/includes/plugin.php';
			$plugin_file = $plugin . '/' . $plugin . '.php';
			$activate    = activate_plugin( $plugin_file );
			if ( is_wp_error( $activate ) ) {
				wp_send_json_error( $activate->get_error_message() );
			}
			wp_send_json_success( __( 'Plugin activated.', 'subscription-pro' ) );
		}
		wp_send_json_error( __( 'Unknown error.', 'subscription-pro' ) );
	}
);
