<?php
/**
 * Silence is golden.
 *
 * @package SpringDevs\SubscriptionPro
 */
