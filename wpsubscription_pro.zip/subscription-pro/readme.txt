=== Subscription for WooCommerce - WPSubscription Pro ===
Contributors: converswp
Tags: woocommerce-subscriptions, subscriptions, subscriptions-billing, recurring-payments, woocommerce-extensions
Requires at least: 6.0
Tested up to: 7.1
Stable tag: 2.5.3
Requires PHP: 7.4
WC requires at least: 6.0
WC tested up to: 10.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Powerful subscription management system for WooCommerce with advanced features and premium support.

== Description ==

Subscriptions for WooCommerce - Pro is a comprehensive subscription management solution that enables you to sell subscription products and services through your WooCommerce store. This premium version includes advanced features for managing recurring payments, subscription lifecycles, and customer relationships.

= Key Features =

* **Advanced Subscription Management**
  * Create and manage subscription products with flexible billing cycles
  * Support for multiple subscription types (simple, variable, grouped)
  * Customizable subscription periods (daily, weekly, monthly, yearly)
  * Advanced subscription status management

* **Subscription Boxes**
  * Build-your-own boxes the shopper fills from a pool of products, curated boxes with contents you choose, and editions you publish each cycle
  * Box pricing: one price for the box, or priced by what is picked, with a base price, discount tiers by item count or amount, and products left out of the discount
  * Box sizes as exact, a range, or "at least N" with no upper limit
  * Sell a box as a subscription or as a one-time purchase
  * The box builder inside the purchase options, with the live box price
  * The cart lists what is in the box, with thumbnails and an Edit box link that changes it in place
  * Add to a box from any item's page, with a prompt to replace an item when the box is full
  * Add to your next box: subscribers add an item for every cycle or for the next box only
  * Items that ship once, in the first box only, charged on their own line of the first order
  * Subscribers change or skip their next box from My Account until it locks
  * Frequently Bought Together on product pages, from what subscribers keep together, with a shortcode, a block and a per-box switch
  * Shipments for every delivery, with an Upcoming list, bulk status actions and a monthly pick list
  * An upcoming box email before each box locks

* **Delivery Schedule Management**
  * Create and manage delivery schedules for subscription products
  * Set up recurring delivery dates
  * Customize delivery intervals
  * Track delivery history

* **Premium Support**
  * Priority email support
  * Regular updates and security patches
  * Dedicated support team

* **Advanced Reporting**
  * Detailed subscription statistics
  * Revenue tracking
  * Customer subscription history
  * Subscription performance metrics

= Requirements =

* WordPress 5.0 or higher
* WooCommerce 6.0 or higher
* WPSubscription (free) 2.4.0 or higher
* PHP 7.4 or higher
* MySQL 5.6 or higher

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/subscription-pro` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Use the Settings->Subscription Pro screen to configure the plugin.
4. Activate your license key to enable premium features.

== Frequently Asked Questions ==

= Do I need WooCommerce installed? =

Yes, this plugin requires WooCommerce to be installed and activated.

= Can I customize the subscription periods? =

Yes, you can set up custom subscription periods including daily, weekly, monthly, and yearly options.

= How do I get support? =

Premium support is available through our support portal. Please contact us with your license key for assistance.

= Can I upgrade from the free version? =

Yes, you can upgrade from the free version while maintaining all your existing subscription data.

= How can I report security bugs? =

You can report security bugs through the Patchstack Vulnerability Disclosure Program. The Patchstack team helps validate, triage and handle any security vulnerabilities. Our [security page](https://wpsubscription.co/security/) links the program for WPSubscription Pro and for the free plugin it extends. Please do not report security bugs in public support channels.

== Screenshots ==

1. Subscription product settings
2. Delivery schedule management
3. Subscription management dashboard
4. Advanced reporting interface

== Privacy Policy ==

This plugin does not collect any personal data. All subscription data is stored in your WordPress database and is subject to your website's privacy policy. 

== Changelog ==

= 2.5.3 - Nov 11, 2026 =
-   fix: Server-side checks now enforce the downgrade, early renewal, box skip, QR regeneration, REST API and role-restriction settings.
-   fix: Retention coupons are limited to one per subscription, locked to the subscription's product and only issued to the owner while the subscription can be retained.
-   fix: The Quick Details page now requires the QR code's key, and existing QR codes are rebuilt with a key the first time they are shown.
-   fix: Box item selections are validated so only allowed variations and products can be priced, shipped or swapped.
-   fix: Plan switch fees are calculated per switch line, mixed switch carts are refused at checkout, and legacy switch URLs check ownership and settings.

= 2.5.2 - Nov 08, 2026 =
-   new: WPSubscription Pro now installs or updates the free WPSubscription plugin automatically when pro is installed or updated.
-   fix: Subscription activity times on the admin subscription page now display in the site's local time instead of being shifted forward.
-   fix: A failed early renewal no longer schedules a payment retry that charges the customer again while the early-renewal order is still open.

= 2.5.1 - Oct 29, 2026 =
-   fix: Product pages showed no plan options when updating Pro to 2.5.0 before updating WPSubscription free. Pro now keeps showing plan options as a fallback.

= 2.5.0 - Oct 25, 2026 =
-   new: Sell subscription boxes! Let customers build their own box, send a box you hand-pick, or release a fresh edition every cycle, all from one Boxes screen.
-   new: Customers fill their box right on the product page and watch the price update, and what's inside shows in the cart, orders and emails.
-   new: Charge one price per box or add up what is picked, reward bigger boxes with bigger discounts, and let boxes be as big as customers like.
-   new: Choose a box's items product by product, by category or from the whole shop, give each box its own durations, and plan monthly editions in collapsible cards.
-   new: Add a product to a box from its own page, add extras to the next delivery, include items that ship only in the first box, and suggest "Frequently bought together" picks.
-   new: Subscribers can swap items or skip their next box from their account and get an email before each box ships, and you get an Upcoming list and a monthly pick list for packing.
-   new: Style your purchase options exactly how you like with your own custom CSS.
-   improved: PayPal is hidden for boxes whose price can change, so checkout always goes smoothly.
-   improved: Your plans now use the new, better-looking WPSubscription purchase options. Requires WPSubscription 2.5.0.
-   improved: When an early renewal or a payment retry fails, you now see exactly why.
-   improved: A box's screen shows only the tabs and rules that fit its type, and the cart no longer shows a curated box as "3 of 4".
-   fix: Pay-in-instalments plans no longer charge tax twice, they stop after the last payment, and catalogue prices show how often and how many.
-   fix: The Stripe Express Checkout button is hidden on a box that has no price yet, which stops a JavaScript error on its page.

= 2.4.0 - Oct 08, 2026 =
-   new: Multilingual support: renewal reminder, payment failure and recovery emails are sent in the language the customer bought in, and the rest of the plugin is translatable.
-   fix: Early renewal is no longer blocked by orders from other subscriptions or by a deleted early renewal order, and a customer with an unpaid renewal order is shown a link to pay it.
-   fix: The Regenerate API key button on the Settings screen now works.

= 2.3.0 - Oct 06, 2026 =
-   new: Flat-amount coupons for the cancellation retention offer.
-   new: Early Renew button visibility rules.
-   improved: Early Renew takes the customer straight to the payment page.
-   fix: Plans with a signup fee and a free trial charged only the signup fee. Checkout now charges the first payment with the fee, and the trial no longer applies to those plans.
-   fix: New plan subscriptions let customers cancel by default.

= 2.2.0 - Oct 01, 2026 =
-   new: Option to issue a new license key on each renewal, and to deactivate the previous key.
-   new: Copy button for license keys on the customer's subscription page.
-   fix: Early renewals no longer generate a second license key.
-   fix: Renewal orders and emails no longer show an empty license keys section.

= 2.1.0 - Sep 29, 2026 =
-   new: Multiple subscriptions in one cart. Customers can buy several subscriptions, or a subscription together with regular products, in a single checkout, and each subscription renews on its own schedule.
-   new: PayPal is hidden at checkout when the cart holds more than one subscription, or a subscription with regular products, because it supports only one subscription per order.
-   fix: A fatal error on product pages when WPSubscription Pro ran alongside an older version of WPSubscription.

= 2.0.0 - Sep 14, 2026 =
-   new: Plans support for Subscribe & Save and Split Payment types.
-   new: Connect plans to variable products.
-   new: Cancellation retention offers with a real coupon.
-   new: Cancellation reports.
-   new: Trial card collection.
-   new: License page with status and help.
-   improved: Consistent admin page headers.

= 1.18.6 - Aug 30, 2026 =
-   fix: PHP compatibility issue.

= 1.18.5 - Aug 23, 2026 =
-   new: Notify store owner when a customer cancels a subscription.
-   fix: Guest account creation.
-   fix: Guest checkout error.
-   update: Email templates.

= 1.18.4 - Aug 16, 2026 =
-   fix: Discounted amount was not showing properly.
-   fix: API settings were not saving.

= 1.18.3 - Aug 02, 2026 =
-   fix: Variation split payment price total in checkout.

= 1.18.2 - Jul 12, 2026 =
-   fix: Add to cart validation for variable products.
-   fix: Admin table paginations.
-   fix: Early renew tax issue.

= 1.18.1 - Jul 05, 2026 =
-   new: Subscription cancellation feedback.
-   new: Customize subscription cancellation behavior.

= 1.18.0 - Jun 28, 2026 =
-   new: Subscription Switch (Upgrade/Downgrade)
-   fix: Subscription details activities.
-   fix: Retry renewal.
-   security: chart.js asset loading.

= 1.17.2 - Jun 21, 2026 =
-   fix: Retry subscription payment from subscription health.
-   refactor: Moved settings to the free version.

= 1.17.1 - Jun 07, 2026 =
-   new: Delivery Schedules UI.
-   new: Reports UI.
-   new: Health UI.
-   fix: Mollie mandate error for renewals.

= 1.17.0 - May 21, 2026 =
-   new: Subscription health.
-   fix: Subscription payment failed tracking.

= 1.16.4 - May 03, 2026 =
-   fix: Same subscription quantity.
-   fix: Payment failed email template.

= 1.16.3 - Apr 12, 2026 =
-   fix: Mollie gateway not processing renewal payments automatically.
-   fix: Error caused by some integration hooks returning null.
-   fix: Language base file Project ID version.

= 1.16.2 - Apr 05, 2026 =
-   fix: Action hooks from free version.
-   fix: WP security updates.

= 1.16.1 - Mar 15, 2026 =
-   new: Role based feature settings.

= 1.16.0 - Feb 22, 2026 =
-   new: MailPoet integration.
-   new: AutomatorWP integration.
-   fix: Variable product add to cart with direct link error.
-   fix: Subscription timing inconsistencies.

= 1.15.0 - Feb 08, 2026 =
-   new: Recurring coupons.
-   new: Ability to enable/disable Quick Details QR.
-   new: Ability to enable/disable subscription switching.
-   fix: Subscription switching issue.
-   fix: Split payment options were not showing.

= 1.14.2 - Jan 18, 2026 =
-   new: Show total amount of the split payments in cart.
-   fix: Tutor LMS locking other non-subscription related courses.
-   fix: Cart showing incorrect TAX.
-   fix: WC Session check error.

= 1.14.1 - Jan 13, 2026 =
-   fix: Add to cart error.

= 1.14.0 - Jan 11, 2026 =
-   new: Fluent CRM integration.
-   fix: Split pay cart description.
-   fix: Signup fees rounding down.
-   fix: Stripe helper not found issue.

= 1.13.0 - Dec 28, 2025 =
-   new: WPFusion integration.

= 1.12.2 - Dec 21, 2025 =
-   fix: Variable prices were not showing VAT.
-   fix: Subscription details default endpoint.
-   fix: WordPress tested up to version.
-   fix: Other minor bugs.

= 1.12.1 - Dec 14, 2025 =
-   new: Custom user subscription endpoints.
-   fix: Missing translations from checkout page.

= 1.12.0 - Dec 09, 2025 =
-   new: Mollie gateway support.
-   new: Razorpay gateway support.
-   new: Xendit gateway support.
-   fix: Core subscription timing translations.
-   fix: Auto-complete orders.

= 1.11.0 - Nov 30, 2025 =
-   new: Hide selected payment gateways from subscription checkout.

= 1.10.0 - Nov 23, 2025 =
-   new: LearnDash integration.
-   new: LearnPress integration.
-   improved: Settings page.
-   dev: Made settings modular and can be added from anywhere.

= 1.9.1 - Nov 16, 2025 =
-   new: Auto complete processing orders.
-   fix: Nonce security issues.
-   fix: Type casting errors.

= 1.9.0 - Nov 09, 2025 =
-   new: Tutor LMS integration.
-   fix: Nonce security issues.

= 1.8.1 - Nov 04, 2025 =
-   fix: Output escaping security issues.

= 1.8.0 - Nov 02, 2025 =
-   new: Quick subscription check QR code.
-   new: WPSoftwareLicense integration.
-   fix: LicenseManagerWoo user end (frontend) fatal error.

= 1.7.1 - Oct 27, 2025 =
-   fix: Error due to operation with wrong type.

= 1.7.0 - Oct 26, 2025 =
-   new: Subscription upgrade.
-   new: Control product/variation visibility based on user role.
-   fix: Auto renewal on/off action visibility (for Stripe paid subscriptions only).

= 1.6.0 - Oct 20, 2025 =
-   new: Subscription grace period.
-   new: Show license from License Manager for WooCommerce plugin in Subscription details (admin & user).
-   fix: Subscription product input form not showing issue.
-   improved: Settings page.

= 1.5.0 - Oct 05, 2025 =
-   new: License Manager for WooCommerce integration.
-   improved: Updated language template files.

= 1.4.0 - Sep 25, 2025 =
-   new: Print delivery schedules list.
-   fix: Subscription, Delivery schedules filters.

= 1.3.3 - Sep 18, 2025 =
-   new: Stripe iDeal integration.
-   new: Stripe SEPA integration.

= 1.3.2 - Sep 16, 2025 =
-   new: Added renewal reminder emails.
-   new: Added language base file.

= 1.3.1 - Sep 14, 2025 =
-   fix: Free version install prompt error.

= 1.3.0 - Aug 19, 2025 =
-   new: Split Payment feature added.
-   new: Payment retry mechanisom.
-   new: WooCommerce High-Performance Order Storage (HPOS) compatibility

= 1.2.1 - Jul 16, 2025 =
-   fix: Fixed delivery date bug
-   fix: Missing lang support added
-   fix: fixed naming fetal error

= 1.2.0 - Jul 02, 2025 =
-   new: Hooks and actions added to enhance subscription workflows.
-   new: REST API support to manage subscriptions.
-   new: Refreshed Stats page for easier insights and tracking.
-   new: Events for trial ending, subscription expiry, and payment failures.
-   new: Filter options on the subscriptions list page to manage easier.
-   new: Bulk actions available on the subscriptions list for faster updates.
-   new: Filters added to the delivery schedule page for better control.
-   new: Dedicated page added to guide you on setting up payment integrations.
-   improved: Language support across the plugin.
-   fix: Quick access to documentation with a new getting started video link.

= 1.1.0 - Apr 24, 2025 =
-   New Admin interface
-   Improved UI and support for Core Plugin

= 1.0.1 - Apr 01, 2025 =
-   Initial release of the Pro version with advanced features and premium support.

= 1.0.0 - Apr 01, 2025 =
-   Initial release

