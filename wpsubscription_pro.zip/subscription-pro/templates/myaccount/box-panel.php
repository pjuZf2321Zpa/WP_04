<?php
/**
 * "Your next box" on the subscription page.
 *
 * @package SpringDevs\SubscriptionPro
 *
 * @var int          $subscription_id Subscription id.
 * @var array        $contents        What the next box holds.
 * @var array        $rules           The rules this subscriber is on.
 * @var int          $lock            When changes stop, as a timestamp.
 * @var bool         $is_locked       Whether that moment has passed.
 * @var bool         $can_edit        Whether this subscriber may change the box.
 * @var bool         $editing         Whether the edit form is open.
 * @var \WC_Product[] $choices        Products available to pick.
 * @var array        $chosen          product_id => qty currently chosen.
 * @var string       $edit_url        URL that opens the edit form.
 * @var array        $chosen_once     product_id => qty currently shipping in the next box only.
 * @var array        $next            BoxQuote::respond_for_subscription() for what the box holds; empty without a price by contents.
 * @var bool         $is_sum          Whether the box is priced by its contents.
 * @var bool         $can_add         Whether the "add to your next box" picker is offered.
 * @var string       $fixed_note      Why nothing can be added, for a fixed-price box.
 * @var string       $gateway_note    Why nothing can be changed, while the gateway holds the schedule.
 * @var string       $every_label     "every month", or empty when the plans differ.
 * @var string       $quote_url       The wc-ajax URL that quotes the box.
 * @var string       $quote_nonce     Nonce for that quote.
 * @var string       $next_add_nonce  Nonce for the add endpoint.
 */

defined( 'ABSPATH' ) || exit;

use SpringDevs\SubscriptionPro\Frontend\BoxNextAdd;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxProduct;

$subscrpt_box_date_format = get_option( 'date_format' );
?>
<section class="subscrpt-box-panel" id="subscrpt-box" data-subscrpt-box-account data-subscription-id="<?php echo esc_attr( $subscription_id ); ?>" data-quote-url="<?php echo esc_url( $quote_url ); ?>" data-quote-nonce="<?php echo esc_attr( $quote_nonce ); ?>" data-contents="<?php echo esc_attr( wp_json_encode( BoxProduct::normalise_items( $contents ) ) ); ?>">
	<header class="subscrpt-box-panel__head">
		<h2><?php esc_html_e( 'Your next box', 'subscription-pro' ); ?></h2>

		<?php if ( $is_locked ) : ?>
			<p class="subscrpt-box-panel__status is-locked">
				<?php esc_html_e( 'This box is being packed, so its contents can no longer be changed.', 'subscription-pro' ); ?>
			</p>
		<?php elseif ( $lock ) : ?>
			<p class="subscrpt-box-panel__status">
				<?php
				printf(
					/* translators: %s: date changes stop. */
					esc_html__( 'Changes lock on %s.', 'subscription-pro' ),
					esc_html( date_i18n( $subscrpt_box_date_format, $lock ) )
				);
				?>
			</p>
		<?php endif; ?>
	</header>

	<?php if ( empty( $contents ) ) : ?>
		<p><?php esc_html_e( 'This box has nothing in it yet.', 'subscription-pro' ); ?></p>
	<?php else : ?>
		<ul class="subscrpt-box-panel__contents">
			<?php
			foreach ( BoxProduct::normalise_items( $contents ) as $subscrpt_box_item ) :
				$subscrpt_box_product = wc_get_product( $subscrpt_box_item['variation_id'] ? $subscrpt_box_item['variation_id'] : $subscrpt_box_item['product_id'] );
				?>
				<li>
					<span class="subscrpt-box-panel__qty"><?php echo esc_html( $subscrpt_box_item['qty'] ); ?>&times;</span>
					<?php echo esc_html( $subscrpt_box_product ? $subscrpt_box_product->get_name() : ( $subscrpt_box_item['name'] ?? '' ) ); ?>
					<?php if ( $subscrpt_box_item['once'] ) : ?>
						<span class="subscrpt-box-panel__once"><?php esc_html_e( 'this box only', 'subscription-pro' ); ?></span>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>

	<?php if ( $next ) : ?>
		<p class="subscrpt-box-panel__next" data-subscrpt-box-account-next aria-live="polite">
			<span data-subscrpt-box-account-next-amount><?php echo wp_kses_post( $next['next_html'] ); ?></span>
			<span class="subscrpt-box-panel__then" data-subscrpt-box-account-then<?php echo $next['then_html'] ? '' : ' hidden'; ?>><?php echo wp_kses_post( $next['then_html'] ); ?></span>
		</p>
	<?php endif; ?>

	<?php if ( $gateway_note ) : ?>
		<p class="subscrpt-box-panel__note" data-subscrpt-box-account-reason><?php echo esc_html( $gateway_note ); ?></p>
	<?php elseif ( $fixed_note ) : ?>
		<p class="subscrpt-box-panel__note" data-subscrpt-box-account-reason><?php echo esc_html( $fixed_note ); ?></p>
	<?php endif; ?>

	<?php if ( $can_add ) : ?>
		<div class="subscrpt-box-account-add" data-subscrpt-box-account-add data-subscrpt-box-next data-subscrpt-box-next-scope data-nonce="<?php echo esc_attr( $next_add_nonce ); ?>">
			<p class="subscrpt-box-account-add__title"><?php esc_html_e( 'Add to your next box', 'subscription-pro' ); ?></p>
			<ul class="subscrpt-box-account-add__row">
				<li class="subscrpt-box-account-add__field">
					<label for="subscrpt-box-account-pick"><?php esc_html_e( 'Item', 'subscription-pro' ); ?></label>
					<select id="subscrpt-box-account-pick" data-subscrpt-box-account-pick>
						<option value=""><?php esc_html_e( 'Choose an item', 'subscription-pro' ); ?></option>
						<?php foreach ( $choices as $subscrpt_box_pick ) : ?>
							<option value="<?php echo esc_attr( $subscrpt_box_pick->get_id() ); ?>" data-name="<?php echo esc_attr( $subscrpt_box_pick->get_name() ); ?>" data-once="<?php echo esc_attr( BoxNextAdd::once_offered( $subscription_id, $subscrpt_box_pick->get_id() ) ? '1' : '0' ); ?>"><?php echo esc_html( $subscrpt_box_pick->get_name() ); ?></option>
						<?php endforeach; ?>
					</select>
				</li>
				<li class="subscrpt-box-account-add__field">
					<fieldset class="subscrpt-box-add__once" data-subscrpt-box-next-once>
						<legend><?php esc_html_e( 'Send it', 'subscription-pro' ); ?></legend>
						<label>
							<input type="radio" name="subscrpt_box_account_once" value="0" checked />
							<span><?php echo esc_html( '' !== $every_label ? $every_label : __( 'every box', 'subscription-pro' ) ); ?></span>
						</label>
						<label data-subscrpt-box-account-once-choice>
							<input type="radio" name="subscrpt_box_account_once" value="1" />
							<span><?php esc_html_e( 'next box only', 'subscription-pro' ); ?></span>
						</label>
					</fieldset>
				</li>
				<li class="subscrpt-box-account-add__field subscrpt-box-account-add__go">
					<button type="button" class="button" data-subscrpt-box-next-add data-subscription-id="<?php echo esc_attr( $subscription_id ); ?>" data-product-id="" data-item-name="" disabled>
						<?php esc_html_e( 'Add to my next box', 'subscription-pro' ); ?>
					</button>
				</li>
			</ul>
			<p class="subscrpt-box-account-add__preview" data-subscrpt-box-account-preview aria-live="polite" hidden></p>
		</div>
	<?php endif; ?>

	<?php if ( $can_edit && ! $editing ) : ?>
		<p class="subscrpt-box-panel__actions">
			<a class="button" href="<?php echo esc_url( $edit_url . '#subscrpt-box' ); ?>">
				<?php esc_html_e( 'Change this box', 'subscription-pro' ); ?>
			</a>
		</p>
	<?php endif; ?>

	<?php if ( $can_edit && $editing ) : ?>
		<form class="subscrpt-box-form" method="post" action="<?php echo esc_url( $edit_url . '#subscrpt-box' ); ?>" data-subscrpt-box-account-form>
			<?php wp_nonce_field( 'subscrpt_box_edit_' . $subscription_id, 'subscrpt_box_nonce' ); ?>
			<input type="hidden" name="subscrpt_box_save" value="<?php echo esc_attr( $subscription_id ); ?>" />

			<p class="subscrpt-box-form__rule">
				<?php
				if ( ! empty( $rules['min'] ) && ! empty( $rules['max'] ) && (int) $rules['min'] === (int) $rules['max'] ) {
					printf(
						/* translators: %d: exact number of items. */
						esc_html( _n( 'Pick %d item.', 'Pick %d items.', (int) $rules['max'], 'subscription-pro' ) ),
						esc_html( $rules['max'] )
					);
				} elseif ( ! empty( $rules['max'] ) ) {
					printf(
						/* translators: 1: minimum items, 2: maximum items. */
						esc_html__( 'Pick between %1$d and %2$d items.', 'subscription-pro' ),
						esc_html( (int) $rules['min'] ),
						esc_html( (int) $rules['max'] )
					);
				} elseif ( ! empty( $rules['min'] ) ) {
					printf(
						/* translators: %d: minimum number of items. */
						esc_html( _n( 'Pick at least %d item.', 'Pick at least %d items.', (int) $rules['min'], 'subscription-pro' ) ),
						esc_html( (int) $rules['min'] )
					);
				}
				?>
				<span class="subscrpt-box-form__counter" data-min="<?php echo esc_attr( (int) ( $rules['min'] ?? 0 ) ); ?>" data-max="<?php echo esc_attr( (int) ( $rules['max'] ?? 0 ) ); ?>"></span>
			</p>

			<?php if ( empty( $choices ) ) : ?>
				<p><?php esc_html_e( 'There is nothing available to swap into this box at the moment.', 'subscription-pro' ); ?></p>
			<?php else : ?>
				<ul class="subscrpt-box-form__grid">
					<?php foreach ( $choices as $subscrpt_box_choice ) : ?>
						<?php $subscrpt_box_choice_id = $subscrpt_box_choice->get_id(); ?>
						<li class="subscrpt-box-choice">
							<?php echo wp_kses_post( $subscrpt_box_choice->get_image( 'woocommerce_thumbnail' ) ); ?>
							<span class="subscrpt-box-choice__name"><?php echo esc_html( $subscrpt_box_choice->get_name() ); ?></span>
							<?php $subscrpt_box_once_ok = $is_sum && BoxNextAdd::once_offered( $subscription_id, $subscrpt_box_choice_id ); ?>
							<label class="<?php echo $subscrpt_box_once_ok ? 'subscrpt-box-choice__label' : 'screen-reader-text'; ?>" for="subscrpt-box-qty-<?php echo esc_attr( $subscrpt_box_choice_id ); ?>">
								<?php
								if ( $subscrpt_box_once_ok ) {
									echo esc_html( '' !== $every_label ? $every_label : __( 'every box', 'subscription-pro' ) );
									echo '<span class="screen-reader-text"> ' . esc_html( $subscrpt_box_choice->get_name() ) . '</span>';
								} else {
									printf(
										/* translators: %s: product name. */
										esc_html__( 'How many %s', 'subscription-pro' ),
										esc_html( $subscrpt_box_choice->get_name() )
									);
								}
								?>
							</label>
							<input
								class="subscrpt-box-choice__qty"
								id="subscrpt-box-qty-<?php echo esc_attr( $subscrpt_box_choice_id ); ?>"
								type="number"
								min="0"
								step="1"
								<?php echo ! empty( $rules['max_per_item'] ) ? 'max="' . esc_attr( (int) $rules['max_per_item'] ) . '"' : ''; ?>
								name="subscrpt_box_items[<?php echo esc_attr( $subscrpt_box_choice_id ); ?>]"
								value="<?php echo esc_attr( $chosen[ $subscrpt_box_choice_id ] ?? 0 ); ?>" />
							<?php if ( $subscrpt_box_once_ok || ! empty( $chosen_once[ $subscrpt_box_choice_id ] ) ) : ?>
								<label class="subscrpt-box-choice__label" for="subscrpt-box-once-<?php echo esc_attr( $subscrpt_box_choice_id ); ?>">
									<?php esc_html_e( 'next box only', 'subscription-pro' ); ?>
									<span class="screen-reader-text"><?php echo esc_html( $subscrpt_box_choice->get_name() ); ?></span>
								</label>
								<input
									class="subscrpt-box-choice__qty subscrpt-box-choice__qty--once"
									id="subscrpt-box-once-<?php echo esc_attr( $subscrpt_box_choice_id ); ?>"
									type="number"
									min="0"
									step="1"
									name="subscrpt_box_once[<?php echo esc_attr( $subscrpt_box_choice_id ); ?>]"
									value="<?php echo esc_attr( $chosen_once[ $subscrpt_box_choice_id ] ?? 0 ); ?>" />
							<?php endif; ?>
						</li>
					<?php endforeach; ?>
				</ul>

				<?php
				// A next-box-only item that cannot be picked now (sold out) is waiting for stock: keep it.
				$subscrpt_box_listed = array_map(
					static function ( $subscrpt_box_listed_choice ) {
						return $subscrpt_box_listed_choice->get_id();
					},
					$choices
				);

				foreach ( $chosen_once as $subscrpt_box_waiting_id => $subscrpt_box_waiting_qty ) :
					if ( in_array( $subscrpt_box_waiting_id, $subscrpt_box_listed, true ) ) {
						continue;
					}
					?>
					<input type="hidden" name="subscrpt_box_once[<?php echo esc_attr( $subscrpt_box_waiting_id ); ?>]" value="<?php echo esc_attr( $subscrpt_box_waiting_qty ); ?>" />
				<?php endforeach; ?>

				<p class="subscrpt-box-form__actions">
					<button type="submit" class="button"><?php esc_html_e( 'Save this box', 'subscription-pro' ); ?></button>
					<a class="subscrpt-box-form__cancel" href="<?php echo esc_url( remove_query_arg( 'subscrpt_box' ) . '#subscrpt-box' ); ?>">
						<?php esc_html_e( 'Cancel', 'subscription-pro' ); ?>
					</a>
				</p>
			<?php endif; ?>
		</form>
	<?php endif; ?>
</section>
