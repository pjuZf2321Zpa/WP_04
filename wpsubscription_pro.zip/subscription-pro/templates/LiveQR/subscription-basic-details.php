<?php
/**
 * Subscription Details View
 *
 * This template can be overridden by copying it to the following path
 * <your_theme>/subscription-pro/LiveQR/subscription-basic-details.php
 *
 * @package SubscriptionPro\Illuminate\LiveQR\views
 */

/**
 * Variables passed to this template:
 *
 * @var array $subscription_data
 * @var int $subscription_id
 * @var string $status
 * @var string $verbose_status
 * @var bool $is_grace_period
 * @var int $grace_remaining
 * @var string $grace_end_date
 * @var string $product_name
 * @var string $product_description
 * @var string $product_image_url
 * @var string $plan_price_formatted
 * @var string $start_date
 * @var string $next_date
 * @var string $recent_payment_date
 * @var string $payment_method
 * @var array $subscription_activities
 * @var array $settings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Load the Live QR styles.
 */
subscrpt_pro_live_qr_styles();

?>
<?php if ( ! empty( $subscription_data ) ) : ?>

<div class="subscrpt-qr">
	<div class="subscrpt-qr-card">
		<div class="subscrpt-qr-card__body">
			<div class="subscrpt-qr-head">
				<div class="subscrpt-qr-title">
					Subscription <?php echo esc_html( $subscription_data['id'] ); ?>
				</div>

				<?php if ( $is_grace_period && $grace_remaining > 0 ) : ?>
					<?php
						$grace_remaining_text = sprintf(
							// translators: Number of days remaining in grace period.
							__( 'Grace Period: %d days remaining!', 'subscription-pro' ),
							$grace_remaining
						);
					?>
					<span class="subscrpt-qr-badge subscrpt-qr-badge--warning" title="<?php echo esc_attr( $grace_remaining_text ); ?>"><span class="subscrpt-qr-badge__dot"></span>Active</span>
				<?php elseif ( 'pending' === $status ) : ?>
					<span class="subscrpt-qr-badge subscrpt-qr-badge--secondary"><span class="subscrpt-qr-badge__dot"></span><?php echo esc_html( $verbose_status ); ?></span>
				<?php elseif ( 'active' === $status ) : ?>
					<span class="subscrpt-qr-badge subscrpt-qr-badge--success"><span class="subscrpt-qr-badge__dot"></span><?php echo esc_html( $verbose_status ); ?></span>
				<?php elseif ( 'expired' === $status ) : ?>
					<span class="subscrpt-qr-badge subscrpt-qr-badge--error"><span class="subscrpt-qr-badge__dot"></span><?php echo esc_html( $verbose_status ); ?></span>
				<?php elseif ( 'cancelled' === $status ) : ?>
					<span class="subscrpt-qr-badge subscrpt-qr-badge--primary"><span class="subscrpt-qr-badge__dot"></span><?php echo esc_html( $verbose_status ); ?></span>
				<?php elseif ( 'pe_cancelled' === $status ) : ?>
					<span class="subscrpt-qr-badge subscrpt-qr-badge--warning"><span class="subscrpt-qr-badge__dot"></span><?php echo esc_html( $verbose_status ); ?></span>
				<?php endif; ?>
			</div>

			<div class="subscrpt-qr-divider"><?php esc_html_e( 'Plan Summary', 'subscription-pro' ); ?></div>
			<div>
				<div class="subscrpt-qr-row"><span class="subscrpt-qr-row__label"><?php esc_html_e( 'Plan', 'subscription-pro' ); ?></span><span><?php echo esc_html( $product_name ); ?></span></div>
				<div class="subscrpt-qr-row"><span class="subscrpt-qr-row__label"><?php esc_html_e( 'Price', 'subscription-pro' ); ?></span><span><?php echo wp_kses_post( $plan_price_formatted ); ?></span></div>
				<div class="subscrpt-qr-row"><span class="subscrpt-qr-row__label"><?php esc_html_e( 'Subscriber Since', 'subscription-pro' ); ?></span><span><?php echo wp_kses_post( $start_date ); ?></span></div>
				<div class="subscrpt-qr-row"><span class="subscrpt-qr-row__label"><?php esc_html_e( 'Expires On', 'subscription-pro' ); ?></span><span><?php echo wp_kses_post( $next_date ); ?></span></div>
				<div class="subscrpt-qr-row"><span class="subscrpt-qr-row__label"><?php esc_html_e( 'Status', 'subscription-pro' ); ?></span><span><?php echo esc_html( ( $is_grace_period && $grace_remaining > 0 ) ? __( 'In Grace Period', 'subscription-pro' ) : $verbose_status ); ?></span></div>
			</div>

			<?php if ( $is_grace_period && $grace_remaining > 0 ) : ?>
			<div class="subscrpt-qr-divider"><?php esc_html_e( 'Grace Period', 'subscription-pro' ); ?></div>
			<div>
				<div class="subscrpt-qr-row"><span class="subscrpt-qr-row__label"><?php esc_html_e( 'Remaining', 'subscription-pro' ); ?></span><span><?php echo esc_html( $grace_remaining ); ?> Days</span></div>
				<div class="subscrpt-qr-row"><span class="subscrpt-qr-row__label"><?php esc_html_e( 'Ends On', 'subscription-pro' ); ?></span><span><?php echo esc_html( $grace_end_date ); ?></span></div>
			</div>
			<?php endif; ?>

			<?php if ( $settings['show_product_details'] ) : ?>
			<div class="subscrpt-qr-divider"><?php esc_html_e( 'Product Details', 'subscription-pro' ); ?></div>
			<div class="subscrpt-qr-product">
				<img class="subscrpt-qr-product__img" src="<?php echo esc_url( $product_image_url ); ?>" alt="<?php echo esc_attr( $product_name ); ?>" />
				<div class="subscrpt-qr-product__info">
					<p class="subscrpt-qr-product__name"><?php echo esc_html( $product_name ); ?></p>
					<p class="subscrpt-qr-product__desc"><?php echo esc_html( $product_description ); ?></p>
				</div>
			</div>
			<?php endif; ?>

			<?php if ( $settings['show_billing_details'] ) : ?>
			<div class="subscrpt-qr-divider"><?php esc_html_e( 'Billing Details', 'subscription-pro' ); ?></div>
			<div>
				<div class="subscrpt-qr-row"><span class="subscrpt-qr-row__label"><?php esc_html_e( 'Next Payment', 'subscription-pro' ); ?></span><span><?php echo wp_kses_post( $next_date ); ?></span></div>
				<div class="subscrpt-qr-row"><span class="subscrpt-qr-row__label"><?php esc_html_e( 'Last Payment', 'subscription-pro' ); ?></span><span><?php echo wp_kses_post( $recent_payment_date ); ?></span></div>
				<div class="subscrpt-qr-row"><span class="subscrpt-qr-row__label"><?php esc_html_e( 'Billing Via', 'subscription-pro' ); ?></span><span><?php echo esc_html( $payment_method ); ?></span></div>
			</div>
			<?php endif; ?>

			<?php if ( $settings['show_timeline'] ) : ?>
			<div class="subscrpt-qr-divider"><?php esc_html_e( 'Timeline', 'subscription-pro' ); ?></div>
			<div>
				<?php foreach ( $subscription_activities as $activity ) : ?>
					<?php
					$activity_title = ! empty( $activity['title'] ) ? $activity['title'] : '';
					switch ( $activity['type'] ) {
						case 'subs_created':
							$activity_title = __( 'Subscription Created', 'subscription-pro' );
							break;
						case 'subs_activated':
							$activity_title = __( 'Subscription Activated', 'subscription-pro' );
							break;
						case 'subs_cancelled':
							$activity_title = __( 'Subscription Cancelled', 'subscription-pro' );
							break;
						case 'subs_expired':
							$activity_title = __( 'Subscription Expired', 'subscription-pro' );
							break;
						case 'renewal_order':
							$activity_title = __( 'Renewal Order Created', 'subscription-pro' );
							break;
						default:
							break;
					}
					$activity_date = ! empty( $activity['date'] ) ? wp_date( 'M j, Y', strtotime( $activity['date'] ), new \DateTimeZone( 'UTC' ) ) : '-';
					?>
					<div class="subscrpt-qr-timeline-item">
						<div class="subscrpt-qr-timeline__marker"><div class="subscrpt-qr-timeline__dot"></div></div>
						<div class="subscrpt-qr-timeline__content"><?php echo esc_html( $activity_title ); ?> on <strong><?php echo esc_html( $activity_date ); ?></strong></div>
					</div>
				<?php endforeach; ?>
			</div>
			<?php endif; ?>
		</div>

		<div class="subscrpt-qr-footer">
			<?php
			/* translators: %s: the WPSubscription brand name. */
			printf( esc_html__( 'Powered by %s', 'subscription-pro' ), '<strong>WPSubscription</strong>' );
			?>
		</div>
	</div>
</div>

<?php else : ?>

<div class="subscrpt-qr">
	<div class="subscrpt-qr-alert" role="alert">
		<svg class="subscrpt-qr-alert__icon" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
		</svg>
		<div>
			<div class="subscrpt-qr-alert__title"><?php esc_html_e( 'Subscription not found!', 'subscription-pro' ); ?></div>
			<div class="subscrpt-qr-alert__text"><?php esc_html_e( 'This could be an issue. Please contact support.', 'subscription-pro' ); ?></div>
		</div>
	</div>
</div>

<?php endif; ?>
