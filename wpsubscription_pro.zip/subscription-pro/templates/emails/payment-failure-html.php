<?php
/**
 * Payment Failure Email Template
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/emails/payment-failure-html.php
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WP_Subscription_Pro
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<?php do_action( 'woocommerce_email_header', $email_heading ); ?>

<p>	
	<?php
		echo esc_html(
			sprintf(
				// translators: Customer name.
				__( 'Hi %1$s,', 'subscription-pro' ),
				$customer_name
			)
		);
		?>
</p>

<?php if ( $is_delayed ) : ?>
	<p><?php esc_html_e( 'We wanted to follow up regarding your recent subscription payment failure.', 'subscription-pro' ); ?></p>
<?php endif; ?>

<p>
	<?php
	if ( $remaining_attempts > 0 ) {
		echo esc_html(
			sprintf(
				// translators: %d: number of attempts remaining
				__( 'Your subscription payment has failed. We will automatically retry the payment. You have %d attempts remaining.', 'subscription-pro' ),
				$remaining_attempts
			)
		);
	} else {
		esc_html_e( 'Your subscription payment has failed after multiple attempts.', 'subscription-pro' );
	}
	?>
</p>

<?php if ( $remaining_attempts > 0 ) : ?>
	<p><?php esc_html_e( 'Please ensure your payment method is up to date to avoid service interruption.', 'subscription-pro' ); ?></p>
<?php else : ?>
	<p><?php esc_html_e( 'Your access has been suspended. Please update your payment method and contact support to restore access.', 'subscription-pro' ); ?></p>
<?php endif; ?>

<table cellspacing="0" cellpadding="0" border="0" style="width:100%;border-collapse:separate;border-spacing:0;border:1px solid #e3e3e8;border-radius:6px;overflow:hidden;font-family:'Helvetica Neue',Helvetica,Roboto,Arial,sans-serif;font-size:14px;">
	<tbody>
		<tr>
			<th scope="row" style="width:40%;padding:10px 14px;text-align:left;vertical-align:top;font-weight:600;color:#50575e;background-color:#f6f7f7;"><?php esc_html_e( 'Subscription Id', 'subscription-pro' ); ?></th>
			<td style="padding:10px 14px;text-align:left;vertical-align:top;color:#1d2327;"><?php echo esc_html( $subscription_id ); ?></td>
		</tr>
		<tr>
			<th scope="row" style="width:40%;padding:10px 14px;text-align:left;vertical-align:top;font-weight:600;color:#50575e;background-color:#f6f7f7;border-top:1px solid #e3e3e8;"><?php esc_html_e( 'Product', 'subscription-pro' ); ?></th>
			<td style="padding:10px 14px;text-align:left;vertical-align:top;color:#1d2327;border-top:1px solid #e3e3e8;"><?php echo esc_html( $product_name ); ?></td>
		</tr>
		<tr>
			<th scope="row" style="width:40%;padding:10px 14px;text-align:left;vertical-align:top;font-weight:600;color:#50575e;background-color:#f6f7f7;border-top:1px solid #e3e3e8;"><?php esc_html_e( 'Amount', 'subscription-pro' ); ?></th>
			<td style="padding:10px 14px;text-align:left;vertical-align:top;color:#1d2327;border-top:1px solid #e3e3e8;"><?php echo wp_kses_post( $amount ); ?></td>
		</tr>
		<tr>
			<th scope="row" style="width:40%;padding:10px 14px;text-align:left;vertical-align:top;font-weight:600;color:#50575e;background-color:#f6f7f7;border-top:1px solid #e3e3e8;"><?php esc_html_e( 'Failure Count', 'subscription-pro' ); ?></th>
			<td style="padding:10px 14px;text-align:left;vertical-align:top;color:#1d2327;border-top:1px solid #e3e3e8;"><?php echo esc_html( $failure_count ); ?> / <?php echo esc_html( $max_retries ); ?></td>
		</tr>
	</tbody>
</table>

<table border="0" cellpadding="0" cellspacing="0" width="100%" style="margin:24px 0;">
	<tr>
		<td align="center">
			<a href="<?php echo esc_url( $view_subscription_url ); ?>"
				style="display:inline-block;padding:12px 24px;background-color:#7f54b3;color:#ffffff;text-decoration:none;font-size:14px;font-weight:600;border-radius:4px;">
				<?php esc_html_e( 'View subscription', 'subscription-pro' ); ?>
			</a>
		</td>
	</tr>
</table>

<p>
	<?php esc_html_e( 'If you have any questions or need assistance, please don\'t hesitate to contact our support team.', 'subscription-pro' ); ?>
</p>

<p>
	<?php esc_html_e( 'Best regards,', 'subscription-pro' ); ?><br>
	<?php echo esc_html( get_bloginfo( 'name' ) ); ?>
</p>

<?php do_action( 'woocommerce_email_footer' ); ?>
