<?php
/**
 * Subscription expired (Admin) email — HTML template.
 *
 * @var string     $email_heading         Email heading text.
 * @var string     $intro                 Opening sentence.
 * @var int        $subscription_id       Subscription post ID.
 * @var string     $customer_name         Customer display name.
 * @var string     $customer_email        Customer email address.
 * @var array      $summary_rows          List of `['label' => ..., 'value' => ..., 'email' => ...]` rows.
 * @var array|null $note                  Optional `['label' => ..., 'text' => ...]` block.
 * @var string     $edit_subscription_url Admin subscription edit URL.
 * @var object     $email                 WC_Email instance.
 *
 * This template can be overridden by copying it to:
 * yourtheme/woocommerce/emails/subscription-expired-admin-html.php
 *
 * @package SpringDevs\SubscriptionPro
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_email_header', $email_heading, $email );
?>

<p style="margin:0 0 16px;font-size:15px;line-height:1.6;"><?php echo esc_html( $intro ); ?></p>

<table cellspacing="0" cellpadding="0" border="0" style="width:100%;border-collapse:separate;border-spacing:0;border:1px solid #e3e3e8;border-radius:6px;overflow:hidden;font-family:'Helvetica Neue',Helvetica,Roboto,Arial,sans-serif;font-size:14px;">
	<tbody>
		<?php
		foreach ( $summary_rows as $index => $row ) :
			$divider = $index > 0 ? 'border-top:1px solid #e3e3e8;' : '';
			?>
			<tr>
				<th scope="row" style="width:40%;padding:10px 14px;text-align:left;vertical-align:top;font-weight:600;color:#50575e;background-color:#f6f7f7;<?php echo esc_attr( $divider ); ?>">
					<?php echo esc_html( $row['label'] ); ?>
				</th>
				<td style="padding:10px 14px;text-align:left;vertical-align:top;color:#1d2327;<?php echo esc_attr( $divider ); ?>">
					<?php echo esc_html( $row['value'] ); ?>
					<?php if ( ! empty( $row['email'] ) ) : ?>
						<br>
						<a href="mailto:<?php echo esc_attr( $row['email'] ); ?>" style="color:#7f54b3;"><?php echo esc_html( $row['email'] ); ?></a>
					<?php endif; ?>
				</td>
			</tr>
		<?php endforeach; ?>
	</tbody>
</table>

<?php if ( ! empty( $note['text'] ) ) : ?>
	<p style="margin:20px 0 6px;font-size:13px;font-weight:600;color:#50575e;text-transform:uppercase;letter-spacing:.4px;">
		<?php echo esc_html( $note['label'] ); ?>
	</p>
	<blockquote style="margin:0;padding:12px 16px;background-color:#f6f7f7;border-left:3px solid #7f54b3;font-size:14px;line-height:1.6;color:#1d2327;">
		<?php echo esc_html( $note['text'] ); ?>
	</blockquote>
<?php endif; ?>

<table border="0" cellpadding="0" cellspacing="0" width="100%" style="margin:24px 0;">
	<tr>
		<td align="center">
			<a href="<?php echo esc_url( $edit_subscription_url ); ?>"
				style="display:inline-block;padding:12px 24px;background-color:#7f54b3;color:#ffffff;text-decoration:none;font-size:14px;font-weight:600;border-radius:4px;">
				<?php esc_html_e( 'Open subscription', 'subscription-pro' ); ?>
			</a>
		</td>
	</tr>
</table>

<p style="margin:0;font-size:12px;color:#8c8f94;">
	<?php
	printf(
		/* translators: %s: site name */
		esc_html__( 'You receive this because you are an administrator of %s. Turn it off under WooCommerce → Settings → Emails.', 'subscription-pro' ),
		esc_html( get_bloginfo( 'name' ) )
	);
	?>
</p>

<?php do_action( 'woocommerce_email_footer', $email ); ?>
