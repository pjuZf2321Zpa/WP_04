<?php
/**
 * Renewal reminder email (Pro) -- HTML template.
 *
 * Served instead of the free plugin's copy while pro is active.
 *
 * @var string $email_heading         Email heading text.
 * @var int    $id                    Subscription post ID.
 * @var string $customer_name         Customer display name.
 * @var string $product_name          Product name.
 * @var string $qty                   Subscription quantity.
 * @var string $amount                Recurring amount.
 * @var int    $num_of_days_before    Days left before renewal.
 * @var string $view_subscription_url My Account subscription URL.
 * @var object $email                 WC_Email instance.
 *
 * This template can be overridden by copying it to:
 * yourtheme/subscription-pro/emails/renew-reminder-html.php
 *
 * @package SpringDevs\SubscriptionPro
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_email_header', $email_heading, $email );
?>

<?php if ( $customer_name ) : ?>
	<p style="margin:0 0 16px;">
		<?php
		printf(
			/* translators: %s: Customer display name. */
			esc_html__( 'Hello %s,', 'subscription-pro' ),
			esc_html( $customer_name )
		);
		?>
	</p>
<?php endif; ?>

<p style="margin:0 0 16px;font-size:15px;line-height:1.6;">
	<?php
	if ( ! empty( $num_of_days_before ) && $num_of_days_before > 0 ) {
		printf(
			/* translators: %d: number of days left before the renewal */
			esc_html( _n( 'Your subscription renews in %d day. Make sure your payment method is up to date.', 'Your subscription renews in %d days. Make sure your payment method is up to date.', (int) $num_of_days_before, 'subscription-pro' ) ),
			(int) $num_of_days_before
		);
	} else {
		esc_html_e( 'Your subscription renews soon. Make sure your payment method is up to date.', 'subscription-pro' );
	}
	?>
</p>

<table cellspacing="0" cellpadding="0" border="0" style="width:100%;border-collapse:separate;border-spacing:0;border:1px solid #e3e3e8;border-radius:6px;overflow:hidden;font-family:'Helvetica Neue',Helvetica,Roboto,Arial,sans-serif;font-size:14px;">
	<tbody>
		<tr>
			<th scope="row" style="width:40%;padding:10px 14px;text-align:left;vertical-align:top;font-weight:600;color:#50575e;background-color:#f6f7f7;"><?php esc_html_e( 'Subscription Id', 'subscription-pro' ); ?></th>
			<td style="padding:10px 14px;text-align:left;vertical-align:top;color:#1d2327;"><?php echo esc_html( $id ); ?></td>
		</tr>
		<tr>
			<th scope="row" style="width:40%;padding:10px 14px;text-align:left;vertical-align:top;font-weight:600;color:#50575e;background-color:#f6f7f7;border-top:1px solid #e3e3e8;"><?php esc_html_e( 'Product', 'subscription-pro' ); ?></th>
			<td style="padding:10px 14px;text-align:left;vertical-align:top;color:#1d2327;border-top:1px solid #e3e3e8;"><?php echo esc_html( $product_name ); ?></td>
		</tr>
		<tr>
			<th scope="row" style="width:40%;padding:10px 14px;text-align:left;vertical-align:top;font-weight:600;color:#50575e;background-color:#f6f7f7;border-top:1px solid #e3e3e8;"><?php esc_html_e( 'Qty', 'subscription-pro' ); ?></th>
			<td style="padding:10px 14px;text-align:left;vertical-align:top;color:#1d2327;border-top:1px solid #e3e3e8;"><?php echo esc_html( $qty ); ?></td>
		</tr>
		<tr>
			<th scope="row" style="width:40%;padding:10px 14px;text-align:left;vertical-align:top;font-weight:600;color:#50575e;background-color:#f6f7f7;border-top:1px solid #e3e3e8;"><?php esc_html_e( 'Amount', 'subscription-pro' ); ?></th>
			<td style="padding:10px 14px;text-align:left;vertical-align:top;color:#1d2327;border-top:1px solid #e3e3e8;"><?php echo wp_kses_post( $amount ); ?></td>
		</tr>
	</tbody>
</table>

<table border="0" cellpadding="0" cellspacing="0" width="100%" style="margin:24px 0;">
	<tr>
		<td align="center">
			<a href="<?php echo esc_url( $view_subscription_url ); ?>"
				style="display:inline-block;padding:12px 24px;background-color:#7f54b3;color:#ffffff;text-decoration:none;font-size:14px;font-weight:600;border-radius:4px;">
				<?php esc_html_e( 'View subscription', 'subscription-pro' ); ?>
			</a>
		</td>
	</tr>
</table>

<p style="margin:0;font-size:13px;color:#8c8f94;">
	<?php esc_html_e( 'Need to change your payment method or cancel? Manage everything from your account, or reply to this email and our team will help.', 'subscription-pro' ); ?>
</p>

<?php do_action( 'woocommerce_email_footer', $email ); ?>
