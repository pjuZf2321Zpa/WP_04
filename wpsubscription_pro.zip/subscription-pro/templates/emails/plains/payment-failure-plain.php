<?php
/**
 * Payment Failure Email Template (Plain Text)
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/emails/plain/payment-failure-plain.php
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WP_Subscription_Pro
 *
 * @var string $view_subscription_url Link to the subscription in My Account.
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

echo wp_kses_post( '= ' . $email_heading ) . " =\n\n";

/* translators: %s: Customer display name. */
echo wp_kses_post( sprintf( __( 'Hi %s,', 'subscription-pro' ), $customer_name ) ) . "\n\n";

if ( $is_delayed ) {
	echo esc_html__( 'We wanted to follow up regarding your recent subscription payment failure.', 'subscription-pro' ) . "\n\n";
}

if ( $remaining_attempts > 0 ) {
	// translators: %d: number of attempts remaining
	echo esc_html( sprintf( __( 'Your subscription payment has failed. We will automatically retry the payment. You have %d attempts remaining.', 'subscription-pro' ), $remaining_attempts ) ) . "\n\n";
} else {
	echo esc_html__( 'Your subscription payment has failed after multiple attempts.', 'subscription-pro' ) . "\n\n";
}

if ( $remaining_attempts > 0 ) {
	echo esc_html__( 'Please ensure your payment method is up to date to avoid service interruption.', 'subscription-pro' ) . "\n\n";
} else {
	echo esc_html__( 'Your access has been suspended. Please update your payment method and contact support to restore access.', 'subscription-pro' ) . "\n\n";
}

echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n\n";

/* translators: %s: Subscription ID. */
echo wp_kses_post( sprintf( __( 'Subscription Id: %s', 'subscription-pro' ), $subscription_id ) ) . "\n";

/* translators: %s: Product name. */
echo wp_kses_post( sprintf( __( 'Product: %s', 'subscription-pro' ), $product_name ) ) . "\n";

/* translators: %s: Formatted amount. */
echo wp_kses_post( sprintf( __( 'Amount: %s', 'subscription-pro' ), $amount ) ) . "\n";

// translators: %d: failure count, %d: maximum retries
echo wp_kses_post( sprintf( __( 'Failure Count: %1$d / %2$d', 'subscription-pro' ), $failure_count, $max_retries ) ) . "\n";

echo "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n\n";

echo esc_html__( 'View subscription:', 'subscription-pro' ) . ' ' . esc_url_raw( $view_subscription_url ) . "\n\n";

echo esc_html__( 'If you have any questions or need assistance, please don\'t hesitate to contact our support team.', 'subscription-pro' ) . "\n\n";

echo esc_html__( 'Best regards,', 'subscription-pro' ) . "\n";
echo wp_kses_post( get_bloginfo( 'name' ) ) . "\n\n";

echo wp_kses_post( apply_filters( 'woocommerce_email_footer_text', get_option( 'woocommerce_email_footer_text' ) ) );
