<?php
/**
 * Renewal reminder email (Pro) -- plain-text template.
 *
 * Served instead of the free plugin's copy while pro is active.
 *
 * @var string $email_heading         Email heading text.
 * @var int    $id                    Subscription post ID.
 * @var string $customer_name         Customer display name.
 * @var string $product_name          Product name.
 * @var string $qty                   Subscription quantity.
 * @var string $amount                Recurring amount.
 * @var int    $num_of_days_before    Days left before renewal.
 * @var string $view_subscription_url My Account subscription URL.
 * @var object $email                 WC_Email instance.
 *
 * This template can be overridden by copying it to:
 * yourtheme/subscription-pro/emails/plains/renew-reminder-plain.php
 *
 * @package SpringDevs\SubscriptionPro
 */

defined( 'ABSPATH' ) || exit;

$subscrpt_divider = "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n\n";

echo esc_html( '= ' . $email_heading . " =\n\n" );

if ( $customer_name ) {
	/* translators: %s: Customer display name. */
	echo esc_html( sprintf( __( 'Hello %s,', 'subscription-pro' ), $customer_name ) ) . "\n\n";
}

if ( ! empty( $num_of_days_before ) && $num_of_days_before > 0 ) {
	echo esc_html(
		sprintf(
			/* translators: %d: number of days left before the renewal */
			_n( 'Your subscription renews in %d day. Make sure your payment method is up to date.', 'Your subscription renews in %d days. Make sure your payment method is up to date.', (int) $num_of_days_before, 'subscription-pro' ),
			(int) $num_of_days_before
		)
	) . "\n\n";
} else {
	echo esc_html__( 'Your subscription renews soon. Make sure your payment method is up to date.', 'subscription-pro' ) . "\n\n";
}

echo esc_html( $subscrpt_divider );

/* translators: %s: Subscription ID. */
echo esc_html( sprintf( __( 'Subscription Id: %s', 'subscription-pro' ), $id ) ) . "\n";

/* translators: %s: Product name. */
echo esc_html( sprintf( __( 'Product: %s', 'subscription-pro' ), $product_name ) ) . "\n";

/* translators: %s: subscription quantity */
echo esc_html( sprintf( __( 'Qty: %s', 'subscription-pro' ), $qty ) ) . "\n";

/* translators: %s: Formatted amount. */
echo esc_html( sprintf( __( 'Amount: %s', 'subscription-pro' ), html_entity_decode( wp_strip_all_tags( (string) $amount ), ENT_QUOTES, 'UTF-8' ) ) ) . "\n";

echo "\n" . esc_html( $subscrpt_divider );

echo esc_html__( 'View subscription:', 'subscription-pro' ) . ' ' . esc_url_raw( $view_subscription_url ) . "\n\n";

echo esc_html__( 'Need to change your payment method or cancel? Manage everything from your account, or reply to this email and our team will help.', 'subscription-pro' ) . "\n\n";

$subscrpt_footer = apply_filters( 'woocommerce_email_footer_text', get_option( 'woocommerce_email_footer_text' ) );
echo esc_html( html_entity_decode( wp_strip_all_tags( (string) $subscrpt_footer ), ENT_QUOTES, 'UTF-8' ) );
