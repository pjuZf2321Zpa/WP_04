<?php
/**
 * Plain-text mail template: the box that is coming next (Customer).
 *
 * @var string $email_heading     Email heading.
 * @var int    $id                Subscription id.
 * @var string $product_name      Box name.
 * @var string $amount            Recurring amount, formatted.
 * @var string $box_this_amount   What this box charges when it ships once items, else empty.
 * @var array  $box_contents      What the box holds.
 * @var string $box_summary       One-line summary of the contents.
 * @var string $box_lock_date     Date changes stop.
 * @var string $box_next_date     Date the box is charged and ships.
 * @var bool   $box_can_edit      Whether the subscriber may still change it.
 * @var string $box_edit_url      Link to change it.
 * @var string $box_customer_name Subscriber's display name.
 *
 * @package SpringDevs\SubscriptionPro
 */

defined( 'ABSPATH' ) || exit;

use SpringDevs\SubscriptionPro\Illuminate\Box\BoxOnceLabel;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxProduct;

echo esc_html( '= ' . $email_heading . " =\n\n" );

if ( $box_customer_name ) {
	/* translators: %s: customer name. */
	echo esc_html( sprintf( __( 'Hi %s,', 'subscription-pro' ), $box_customer_name ) . "\n\n" );
}

if ( $box_next_date ) {
	/* translators: %s: renewal date. */
	echo esc_html( sprintf( __( 'Here is what your next box holds. It ships on %s.', 'subscription-pro' ), $box_next_date ) . "\n\n" );
} else {
	echo esc_html( __( 'Here is what your next box holds.', 'subscription-pro' ) . "\n\n" );
}

echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n\n";

/* translators: %s: subscription id. */
echo esc_html( sprintf( __( 'Subscription: #%s', 'subscription-pro' ), $id ) . "\n" );

/* translators: %s: box name. */
echo esc_html( sprintf( __( 'Box: %s', 'subscription-pro' ), $product_name ) . "\n" );

echo esc_html( __( 'Inside:', 'subscription-pro' ) . "\n" );

if ( empty( $box_contents ) ) {
	echo esc_html( '  ' . __( 'Nothing chosen yet.', 'subscription-pro' ) . "\n" );
} else {
	foreach ( BoxProduct::normalise_items( $box_contents ) as $subscrpt_box_item ) {
		$subscrpt_box_product = wc_get_product( $subscrpt_box_item['variation_id'] ? $subscrpt_box_item['variation_id'] : $subscrpt_box_item['product_id'] );

		echo esc_html(
			'  ' . sprintf(
				'%d x %s',
				(int) $subscrpt_box_item['qty'],
				$subscrpt_box_product ? $subscrpt_box_product->get_name() : ( $subscrpt_box_item['name'] ?? '' )
			) . ( $subscrpt_box_item['once'] ? ' (' . BoxOnceLabel::this_box_only() . ')' : '' ) . "\n"
		);
	}
}

if ( $box_this_amount ) {
	/* translators: %s: what the next box charges. */
	echo esc_html( sprintf( __( 'This box: %s', 'subscription-pro' ), $box_this_amount ) . "\n" );
}

/* translators: %s: recurring amount. */
echo esc_html( sprintf( __( 'Amount: %s', 'subscription-pro' ), wp_strip_all_tags( $amount ) ) . "\n" );

if ( $box_lock_date ) {
	/* translators: %s: date changes stop. */
	echo esc_html( sprintf( __( 'Changes accepted until: %s', 'subscription-pro' ), $box_lock_date ) . "\n" );
}

echo "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n\n";

if ( $box_can_edit && $box_edit_url ) {
	echo esc_html( __( 'Change this box:', 'subscription-pro' ) . "\n" );
	echo esc_url_raw( $box_edit_url ) . "\n\n";
}

echo esc_html( apply_filters( 'woocommerce_email_footer_text', get_option( 'woocommerce_email_footer_text' ) ) );
