<?php
/**
 * Recovery Notification Email Template (Plain Text).
 *
 * This template can be overridden by copying it to:
 * <your_theme>/subscription-pro/emails/plains/recovery-notification-plain.php
 *
 * @package SpringDevs\SubscriptionPro
 *
 * @var string $email_heading         Email heading text.
 * @var int    $subscription_id       Subscription post ID.
 * @var string $customer_name         Customer display name.
 * @var string $product_name          Product name.
 * @var string $amount                Formatted recurring amount.
 * @var string $renewal_date          Next renewal date string.
 * @var string $view_subscription_url Link to subscription in My Account.
 */

defined( 'ABSPATH' ) || exit;

echo esc_html( '= ' . $email_heading . " =\n\n" );

printf(
	/* translators: %s: Customer display name. */
	esc_html__( 'Hi %s,', 'subscription-pro' ),
	esc_html( $customer_name )
);
echo "\n\n";

esc_html_e( 'Your subscription requires your attention. Please review the details below and take action to avoid any interruption in your service.', 'subscription-pro' );
echo "\n\n";

echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n\n";

/* translators: %s: Subscription ID. */
echo esc_html( sprintf( __( 'Subscription Id: %s', 'subscription-pro' ), $subscription_id ) . "\n" );

/* translators: %s: Product name. */
echo esc_html( sprintf( __( 'Product: %s', 'subscription-pro' ), $product_name ) . "\n" );

/* translators: %s: Formatted amount. */
echo wp_kses_post( sprintf( __( 'Amount: %s', 'subscription-pro' ), $amount ) . "\n" );

if ( $renewal_date ) {
	/* translators: %s: Renewal date string. */
	echo esc_html( sprintf( __( 'Renewal Date: %s', 'subscription-pro' ), $renewal_date ) . "\n" );
}

echo "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n\n";

echo esc_html__( 'View subscription:', 'subscription-pro' ) . ' ' . esc_url_raw( $view_subscription_url ) . "\n\n";

echo esc_html( apply_filters( 'woocommerce_email_footer_text', get_option( 'woocommerce_email_footer_text' ) ) );
