<?php
/**
 * Health Queue Reminder Email — plain-text template.
 *
 * @var string $email_heading   Email heading text.
 * @var int    $queue_count     Number of subscriptions in the health queue.
 * @var string $revenue_at_risk Formatted revenue at risk (HTML — strip tags for plain).
 * @var string $health_page_url URL to the health page.
 * @var object $email           WC_Email instance.
 *
 * @package SpringDevs\SubscriptionPro
 */

defined( 'ABSPATH' ) || exit;

echo esc_html( $email_heading ) . "\n\n";

echo esc_html__( 'This is your scheduled subscription health summary. The following subscriptions need your attention.', 'subscription-pro' ) . "\n\n";

/* translators: %d: number of subscriptions in the health queue */
echo esc_html( sprintf( __( 'Subscriptions in queue: %d', 'subscription-pro' ), $queue_count ) ) . "\n";

/* translators: %s: formatted revenue at risk */
echo esc_html( sprintf( __( 'Revenue at risk: %s', 'subscription-pro' ), wp_strip_all_tags( $revenue_at_risk ) ) ) . "\n\n";

echo esc_html__( 'Review these subscriptions and take action to recover revenue and restore service.', 'subscription-pro' ) . "\n\n";

/* translators: %s: URL to the health page */
echo esc_html( sprintf( __( 'View Subscription Health: %s', 'subscription-pro' ), $health_page_url ) ) . "\n\n";

echo esc_html(
	sprintf(
		/* translators: %s: site name */
		__( 'You are receiving this email because you are the administrator of %s.', 'subscription-pro' ),
		get_bloginfo( 'name' )
	)
) . "\n";
