<?php
/**
 * Subscription expired (Admin) email — plain-text template.
 *
 * @var string     $email_heading         Email heading text.
 * @var string     $intro                 Opening sentence.
 * @var int        $subscription_id       Subscription post ID.
 * @var string     $customer_name         Customer display name.
 * @var string     $customer_email        Customer email address.
 * @var array      $summary_rows          List of `['label' => ..., 'value' => ..., 'email' => ...]` rows.
 * @var array|null $note                  Optional `['label' => ..., 'text' => ...]` block.
 * @var string     $edit_subscription_url Admin subscription edit URL.
 * @var object     $email                 WC_Email instance.
 *
 * This template can be overridden by copying it to:
 * yourtheme/woocommerce/emails/plains/subscription-expired-admin-plain.php
 *
 * @package SpringDevs\SubscriptionPro
 */

defined( 'ABSPATH' ) || exit;

$divider = "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n\n";

echo esc_html( '= ' . $email_heading . " =\n\n" );

echo esc_html( $intro ) . "\n\n";

echo esc_html( $divider );

foreach ( $summary_rows as $row ) {
	$value = $row['value'];
	if ( ! empty( $row['email'] ) ) {
		$value = trim( $value . ' (' . $row['email'] . ')' );
	}
	echo esc_html( $row['label'] . ': ' . $value ) . "\n";
}

if ( ! empty( $note['text'] ) ) {
	echo "\n" . esc_html( $note['label'] . ":\n" . $note['text'] ) . "\n";
}

echo "\n" . esc_html( $divider );

echo esc_html__( 'Open subscription:', 'subscription-pro' ) . ' ' . esc_url_raw( $edit_subscription_url ) . "\n\n";

echo esc_html(
	sprintf(
		/* translators: %s: site name */
		__( 'You receive this because you are an administrator of %s. Turn it off under WooCommerce → Settings → Emails.', 'subscription-pro' ),
		get_bloginfo( 'name' )
	)
) . "\n\n";

$footer_text = apply_filters( 'woocommerce_email_footer_text', get_option( 'woocommerce_email_footer_text' ) );
echo esc_html( html_entity_decode( wp_strip_all_tags( (string) $footer_text ), ENT_QUOTES, 'UTF-8' ) );
