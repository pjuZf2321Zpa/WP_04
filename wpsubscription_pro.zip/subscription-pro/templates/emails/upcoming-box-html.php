<?php
/**
 * Mail template: the box that is coming next (Customer).
 *
 * @var string $email_heading     Email heading.
 * @var int    $id                Subscription id.
 * @var string $product_name      Box name.
 * @var string $amount            Recurring amount, formatted.
 * @var string $box_this_amount   What this box charges when it ships once items, else empty.
 * @var array  $box_contents      What the box holds.
 * @var string $box_summary       One-line summary of the contents.
 * @var string $box_lock_date     Date changes stop.
 * @var string $box_next_date     Date the box is charged and ships.
 * @var bool   $box_can_edit      Whether the subscriber may still change it.
 * @var string $box_edit_url      Link to change it.
 * @var string $box_customer_name Subscriber's display name.
 *
 * @package SpringDevs\SubscriptionPro
 */

defined( 'ABSPATH' ) || exit;

use SpringDevs\SubscriptionPro\Illuminate\Box\BoxOnceLabel;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxProduct;

?>

<?php do_action( 'woocommerce_email_header', $email_heading ); ?>

<p>
	<?php
	if ( $box_customer_name ) {
		printf(
			/* translators: %s: customer name. */
			esc_html__( 'Hi %s,', 'subscription-pro' ),
			esc_html( $box_customer_name )
		);
	}
	?>
</p>

<p>
	<?php
	if ( $box_next_date ) {
		printf(
			/* translators: %s: renewal date. */
			esc_html__( 'Here is what your next box holds. It ships on %s.', 'subscription-pro' ),
			esc_html( $box_next_date )
		);
	} else {
		esc_html_e( 'Here is what your next box holds.', 'subscription-pro' );
	}
	?>
</p>

<table cellspacing="0" cellpadding="0" border="0" style="width:100%;border-collapse:separate;border-spacing:0;border:1px solid #e3e3e8;border-radius:6px;overflow:hidden;font-family:'Helvetica Neue',Helvetica,Roboto,Arial,sans-serif;font-size:14px;">
	<tbody>
		<tr>
			<th scope="row" style="width:40%;padding:10px 14px;text-align:left;vertical-align:top;font-weight:600;color:#50575e;background-color:#f6f7f7;"><?php esc_html_e( 'Subscription', 'subscription-pro' ); ?></th>
			<td style="padding:10px 14px;text-align:left;vertical-align:top;color:#1d2327;"><?php echo esc_html( '#' . $id ); ?></td>
		</tr>
		<tr>
			<th scope="row" style="width:40%;padding:10px 14px;text-align:left;vertical-align:top;font-weight:600;color:#50575e;background-color:#f6f7f7;border-top:1px solid #e3e3e8;"><?php esc_html_e( 'Box', 'subscription-pro' ); ?></th>
			<td style="padding:10px 14px;text-align:left;vertical-align:top;color:#1d2327;border-top:1px solid #e3e3e8;"><?php echo esc_html( $product_name ); ?></td>
		</tr>
		<tr>
			<th scope="row" style="width:40%;padding:10px 14px;text-align:left;vertical-align:top;font-weight:600;color:#50575e;background-color:#f6f7f7;border-top:1px solid #e3e3e8;"><?php esc_html_e( 'Inside', 'subscription-pro' ); ?></th>
			<td style="padding:10px 14px;text-align:left;vertical-align:top;color:#1d2327;border-top:1px solid #e3e3e8;">
				<?php if ( empty( $box_contents ) ) : ?>
					<?php esc_html_e( 'Nothing chosen yet.', 'subscription-pro' ); ?>
				<?php else : ?>
					<ul style="margin:0;padding-left:18px;">
						<?php
						foreach ( BoxProduct::normalise_items( $box_contents ) as $subscrpt_box_item ) :
							$subscrpt_box_product = wc_get_product( $subscrpt_box_item['variation_id'] ? $subscrpt_box_item['variation_id'] : $subscrpt_box_item['product_id'] );
							?>
							<li>
								<?php
								echo esc_html(
									sprintf(
										'%d × %s',
										(int) $subscrpt_box_item['qty'],
										$subscrpt_box_product ? $subscrpt_box_product->get_name() : ( $subscrpt_box_item['name'] ?? '' )
									)
								);

								if ( $subscrpt_box_item['once'] ) :
									?>
									<span style="color:#646970;font-size:12px;">(<?php echo esc_html( BoxOnceLabel::this_box_only() ); ?>)</span>
								<?php endif; ?>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			</td>
		</tr>
		<?php if ( $box_this_amount ) : ?>
			<tr>
				<th scope="row" style="width:40%;padding:10px 14px;text-align:left;vertical-align:top;font-weight:600;color:#50575e;background-color:#f6f7f7;border-top:1px solid #e3e3e8;"><?php esc_html_e( 'This box', 'subscription-pro' ); ?></th>
				<td style="padding:10px 14px;text-align:left;vertical-align:top;color:#1d2327;border-top:1px solid #e3e3e8;"><?php echo esc_html( $box_this_amount ); ?></td>
			</tr>
		<?php endif; ?>
		<tr>
			<th scope="row" style="width:40%;padding:10px 14px;text-align:left;vertical-align:top;font-weight:600;color:#50575e;background-color:#f6f7f7;border-top:1px solid #e3e3e8;"><?php esc_html_e( 'Amount', 'subscription-pro' ); ?></th>
			<td style="padding:10px 14px;text-align:left;vertical-align:top;color:#1d2327;border-top:1px solid #e3e3e8;"><?php echo wp_kses_post( $amount ); ?></td>
		</tr>
		<?php if ( $box_lock_date ) : ?>
			<tr>
				<th scope="row" style="width:40%;padding:10px 14px;text-align:left;vertical-align:top;font-weight:600;color:#50575e;background-color:#f6f7f7;border-top:1px solid #e3e3e8;"><?php esc_html_e( 'Changes accepted until', 'subscription-pro' ); ?></th>
				<td style="padding:10px 14px;text-align:left;vertical-align:top;color:#1d2327;border-top:1px solid #e3e3e8;"><?php echo esc_html( $box_lock_date ); ?></td>
			</tr>
		<?php endif; ?>
	</tbody>
</table>

<?php if ( $box_can_edit && $box_edit_url ) : ?>
	<p style="margin-top:18px;">
		<a href="<?php echo esc_url( $box_edit_url ); ?>" style="display:inline-block;padding:10px 18px;border-radius:4px;background:#0e5a32;color:#ffffff;text-decoration:none;font-weight:600;">
			<?php esc_html_e( 'Change this box', 'subscription-pro' ); ?>
		</a>
	</p>
<?php endif; ?>

<?php do_action( 'woocommerce_email_footer' ); ?>
