<?php
/**
 * Health Queue Reminder Email — HTML template.
 *
 * @var string $email_heading   Email heading text.
 * @var int    $queue_count     Number of subscriptions in the health queue.
 * @var string $revenue_at_risk Formatted revenue at risk (HTML).
 * @var string $health_page_url URL to the health page.
 * @var object $email           WC_Email instance.
 *
 * This template can be overridden by copying it to:
 * yourtheme/woocommerce/emails/health-queue-reminder-html.php
 *
 * @package SpringDevs\SubscriptionPro
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_email_header', $email_heading, $email );
?>

<p>
	<?php esc_html_e( 'This is your scheduled subscription health summary. The following subscriptions need your attention.', 'subscription-pro' ); ?>
</p>

<table cellspacing="0" cellpadding="0" border="0" style="width:100%;border-collapse:separate;border-spacing:0;border:1px solid #e3e3e8;border-radius:6px;overflow:hidden;font-family:'Helvetica Neue',Helvetica,Roboto,Arial,sans-serif;font-size:14px;">
	<tbody>
		<tr>
			<th scope="row" style="width:40%;padding:10px 14px;text-align:left;vertical-align:top;font-weight:600;color:#50575e;background-color:#f6f7f7;"><?php esc_html_e( 'Subscriptions in queue', 'subscription-pro' ); ?></th>
			<td style="padding:10px 14px;text-align:left;vertical-align:top;color:#1d2327;"><strong><?php echo esc_html( number_format_i18n( $queue_count ) ); ?></strong></td>
		</tr>
		<tr>
			<th scope="row" style="width:40%;padding:10px 14px;text-align:left;vertical-align:top;font-weight:600;color:#50575e;background-color:#f6f7f7;border-top:1px solid #e3e3e8;"><?php esc_html_e( 'Revenue at risk', 'subscription-pro' ); ?></th>
			<td style="padding:10px 14px;text-align:left;vertical-align:top;color:#1d2327;border-top:1px solid #e3e3e8;"><strong><?php echo wp_kses_post( $revenue_at_risk ); ?></strong></td>
		</tr>
	</tbody>
</table>

<p>
	<?php esc_html_e( 'Review these subscriptions and take action to recover revenue and restore service.', 'subscription-pro' ); ?>
</p>

<table border="0" cellpadding="0" cellspacing="0" width="100%" style="margin:24px 0;">
	<tr>
		<td align="center">
			<a href="<?php echo esc_url( $health_page_url ); ?>"
				style="display:inline-block;padding:12px 24px;background-color:#7f54b3;color:#ffffff;text-decoration:none;font-size:14px;font-weight:600;border-radius:4px;">
				<?php esc_html_e( 'View Subscription Health', 'subscription-pro' ); ?>
			</a>
		</td>
	</tr>
</table>

<p style="margin-top:24px;font-size:12px;color:#888;">
	<?php
	printf(
		/* translators: %s: site name */
		esc_html__( 'You are receiving this email because you are the administrator of %s.', 'subscription-pro' ),
		esc_html( get_bloginfo( 'name' ) )
	);
	?>
</p>

<?php do_action( 'woocommerce_email_footer', $email ); ?>
