<?php
/**
 * Recovery Notification Email Template (HTML).
 *
 * This template can be overridden by copying it to:
 * <your_theme>/subscription-pro/emails/recovery-notification-html.php
 *
 * @package SpringDevs\SubscriptionPro
 *
 * @var \WC_Email $email                Email object.
 * @var string    $email_heading        Email heading text.
 * @var int       $subscription_id      Subscription post ID.
 * @var string    $customer_name        Customer display name.
 * @var string    $product_name         Product name.
 * @var string    $amount               Formatted recurring amount.
 * @var string    $renewal_date         Next renewal date string.
 * @var string    $view_subscription_url Link to subscription in My Account.
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_email_header', $email_heading, $email );
?>

<p>
	<?php
	printf(
		/* translators: %s: Customer display name. */
		esc_html__( 'Hi %s,', 'subscription-pro' ),
		esc_html( $customer_name )
	);
	?>
</p>

<p>
	<?php esc_html_e( 'Your subscription requires your attention. Please review the details below and take action to avoid any interruption in your service.', 'subscription-pro' ); ?>
</p>

<table cellspacing="0" cellpadding="0" border="0" style="width:100%;border-collapse:separate;border-spacing:0;border:1px solid #e3e3e8;border-radius:6px;overflow:hidden;font-family:'Helvetica Neue',Helvetica,Roboto,Arial,sans-serif;font-size:14px;">
	<tbody>
		<tr>
			<th scope="row" style="width:40%;padding:10px 14px;text-align:left;vertical-align:top;font-weight:600;color:#50575e;background-color:#f6f7f7;"><?php esc_html_e( 'Subscription Id', 'subscription-pro' ); ?></th>
			<td style="padding:10px 14px;text-align:left;vertical-align:top;color:#1d2327;"><?php echo esc_html( $subscription_id ); ?></td>
		</tr>
		<tr>
			<th scope="row" style="width:40%;padding:10px 14px;text-align:left;vertical-align:top;font-weight:600;color:#50575e;background-color:#f6f7f7;border-top:1px solid #e3e3e8;"><?php esc_html_e( 'Product', 'subscription-pro' ); ?></th>
			<td style="padding:10px 14px;text-align:left;vertical-align:top;color:#1d2327;border-top:1px solid #e3e3e8;"><?php echo esc_html( $product_name ); ?></td>
		</tr>
		<tr>
			<th scope="row" style="width:40%;padding:10px 14px;text-align:left;vertical-align:top;font-weight:600;color:#50575e;background-color:#f6f7f7;border-top:1px solid #e3e3e8;"><?php esc_html_e( 'Amount', 'subscription-pro' ); ?></th>
			<td style="padding:10px 14px;text-align:left;vertical-align:top;color:#1d2327;border-top:1px solid #e3e3e8;"><?php echo wp_kses_post( $amount ); ?></td>
		</tr>
		<?php if ( $renewal_date ) : ?>
		<tr>
			<th scope="row" style="width:40%;padding:10px 14px;text-align:left;vertical-align:top;font-weight:600;color:#50575e;background-color:#f6f7f7;border-top:1px solid #e3e3e8;"><?php esc_html_e( 'Renewal Date', 'subscription-pro' ); ?></th>
			<td style="padding:10px 14px;text-align:left;vertical-align:top;color:#1d2327;border-top:1px solid #e3e3e8;"><?php echo esc_html( $renewal_date ); ?></td>
		</tr>
		<?php endif; ?>
	</tbody>
</table>

<table border="0" cellpadding="0" cellspacing="0" width="100%" style="margin:24px 0;">
	<tr>
		<td align="center">
			<a href="<?php echo esc_url( $view_subscription_url ); ?>"
				style="display:inline-block;padding:12px 24px;background-color:#7f54b3;color:#ffffff;text-decoration:none;font-size:14px;font-weight:600;border-radius:4px;">
				<?php esc_html_e( 'View subscription', 'subscription-pro' ); ?>
			</a>
		</td>
	</tr>
</table>

<?php do_action( 'woocommerce_email_footer', $email ); ?>
