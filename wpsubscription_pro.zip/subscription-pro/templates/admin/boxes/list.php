<?php
/**
 * The Boxes list screen.
 *
 * Three tabs on one page. **Boxes** is the thing itself. **Upcoming** and
 * **Pick list** are the daily work across every box — what ships soon, and how
 * many of each product to put on the bench.
 *
 * Free has already rendered the page header, so this starts at the tabs.
 *
 * @var string $tab       boxes | upcoming | picks.
 * @var array  $boxes     BoxPresenter::all(), on the Boxes tab.
 * @var array  $upcoming  Shipments for the chosen cycle, from ShipmentPresenter.
 * @var array  $pick_list Rows from Boxes::pick_list(), skipped and failed removed.
 * @var string $cycle     The cycle both operational tabs are showing.
 * @var array  $cycles    Cycles worth offering in the filter.
 * @var array  $counts    Per-status counts for this cycle.
 * @var array  $box_list  id => title of every box, for the filter.
 * @var int    $box_of    Box filter, or 0 for every box.
 * @var string $status    Status filter, or '' for all.
 * @var string $search    Customer search.
 * @var string $list_url  This screen.
 * @var bool   $updated   Whether something was just saved.
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

defined( 'ABSPATH' ) || exit;

use SpringDevs\SubscriptionPro\Admin\Boxes;

$subscrpt_tabs = array(
	'boxes'    => __( 'Boxes', 'subscription-pro' ),
	'upcoming' => __( 'Upcoming', 'subscription-pro' ),
	'picks'    => __( 'Pick list', 'subscription-pro' ),
);
?>
<div class="wp-subscription-admin-content list-page">

	<?php if ( $updated ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Saved.', 'subscription-pro' ); ?></p></div>
	<?php endif; ?>

	<div class="wpsubs-tabs subscrpt-box-listtabs">
		<div class="wpsubs-tabs__list" role="tablist">
			<?php foreach ( $subscrpt_tabs as $subscrpt_key => $subscrpt_label ) : ?>
				<a
					class="wpsubs-tabs__tab<?php echo $tab === $subscrpt_key ? ' is-active' : ''; ?>"
					href="<?php echo esc_url( add_query_arg( 'tab', $subscrpt_key, $list_url ) ); ?>"
					aria-selected="<?php echo $tab === $subscrpt_key ? 'true' : 'false'; ?>"
				>
					<?php echo esc_html( $subscrpt_label ); ?>
				</a>
			<?php endforeach; ?>
		</div>
	</div>

	<?php if ( 'boxes' === $tab ) : ?>

		<?php if ( empty( $boxes ) ) : ?>

			<div class="wpsubs-empty">
				<div class="wpsubs-empty__icon">📦</div>
				<h3 class="wpsubs-empty__title"><?php esc_html_e( 'No boxes yet', 'subscription-pro' ); ?></h3>
				<p class="wpsubs-empty__desc">
					<?php esc_html_e( 'A box is one subscription that ships several products together. Make one here, then connect the products that sell it.', 'subscription-pro' ); ?>
				</p>
				<button type="button" class="wpsubs-btn wpsubs-btn--primary" style="margin-top:20px;" data-wpsubs-modal-open="subscrpt-create-box">
					<?php esc_html_e( 'Create your first box', 'subscription-pro' ); ?>
				</button>
			</div>

		<?php else : ?>

			<?php
			$subscrpt_active  = count(
				array_filter(
					$boxes,
					static function ( $listed ) {
						return ! $listed['is_draft'];
					}
				)
			);
			$subscrpt_filters = array(
				'all'    => array( __( 'All', 'subscription-pro' ), count( $boxes ) ),
				'active' => array( __( 'Active', 'subscription-pro' ), $subscrpt_active ),
				'draft'  => array( __( 'Draft', 'subscription-pro' ), count( $boxes ) - $subscrpt_active ),
			);
			?>
			<div data-subscrpt-browse data-per-page="20">

				<div class="subscrpt-box-listhead">
					<div>
						<h2><?php esc_html_e( 'Boxes', 'subscription-pro' ); ?></h2>
						<p><?php esc_html_e( 'One subscription that ships several products together.', 'subscription-pro' ); ?></p>
					</div>
					<button type="button" class="wpsubs-btn wpsubs-btn--primary" data-wpsubs-modal-open="subscrpt-create-box">
						<span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span>
						<?php esc_html_e( 'Create box', 'subscription-pro' ); ?>
					</button>
				</div>

				<div class="subscrpt-box-listtools">
					<div class="subscrpt-box-seg" role="group" aria-label="<?php esc_attr_e( 'Filter boxes', 'subscription-pro' ); ?>">
						<?php foreach ( $subscrpt_filters as $subscrpt_key => $subscrpt_filter ) : ?>
							<button type="button" data-subscrpt-browse-status="<?php echo esc_attr( $subscrpt_key ); ?>" aria-pressed="<?php echo 'all' === $subscrpt_key ? 'true' : 'false'; ?>">
								<?php echo esc_html( $subscrpt_filter[0] ); ?> <span><?php echo esc_html( number_format_i18n( $subscrpt_filter[1] ) ); ?></span>
							</button>
						<?php endforeach; ?>
					</div>
					<input type="search" class="wpsubs-input subscrpt-box-search" placeholder="<?php esc_attr_e( 'Search boxes', 'subscription-pro' ); ?>" aria-label="<?php esc_attr_e( 'Search boxes', 'subscription-pro' ); ?>" data-subscrpt-browse-search />
				</div>

				<div class="subscrpt-box-tablewrap">
					<table class="subscrpt-box-table subscrpt-box-table--list">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Box', 'subscription-pro' ); ?></th>
								<th><?php esc_html_e( 'Items from', 'subscription-pro' ); ?></th>
								<th><?php esc_html_e( 'Sold as', 'subscription-pro' ); ?></th>
								<th><?php esc_html_e( 'Durations', 'subscription-pro' ); ?></th>
								<th><?php esc_html_e( 'Status', 'subscription-pro' ); ?></th>
								<th><?php esc_html_e( 'Edited', 'subscription-pro' ); ?></th>
								<th><span class="screen-reader-text"><?php esc_html_e( 'Actions', 'subscription-pro' ); ?></span></th>
							</tr>
						</thead>
						<tbody>
							<?php
							foreach ( $boxes as $subscrpt_box ) :
								$subscrpt_product = $subscrpt_box['product'];
								$subscrpt_has_pr  = $subscrpt_product && ! $subscrpt_product['missing'];
								?>
								<tr
									data-subscrpt-browse-item
									data-name="<?php echo esc_attr( strtolower( $subscrpt_box['name'] ) ); ?>"
									data-status="<?php echo $subscrpt_box['is_draft'] ? 'draft' : 'active'; ?>"
									data-box-id="<?php echo esc_attr( $subscrpt_box['id'] ); ?>"
									data-href="<?php echo esc_url( $subscrpt_box['detail_url'] ); ?>"
									tabindex="0"
								>
									<td>
										<a class="subscrpt-box-prod" href="<?php echo esc_url( $subscrpt_box['detail_url'] ); ?>">
											<span class="subscrpt-box-ic"><span class="dashicons <?php echo esc_attr( $subscrpt_box['type_icon'] ); ?>" aria-hidden="true"></span></span>
											<span class="subscrpt-box-prod__text">
												<span class="subscrpt-box-prod__name"><?php echo esc_html( $subscrpt_box['name'] ); ?></span>
												<span class="subscrpt-box-hint"><?php echo esc_html( $subscrpt_box['type_label'] ); ?></span>
											</span>
										</a>
									</td>
									<td>
										<span class="subscrpt-box-cell"><?php echo esc_html( $subscrpt_box['source_label'] ); ?></span>
										<?php /* translators: %d: number of items. */ ?>
										<span class="subscrpt-box-hint"><?php echo esc_html( sprintf( _n( '%d item', '%d items', $subscrpt_box['item_count'], 'subscription-pro' ), $subscrpt_box['item_count'] ) ); ?></span>
									</td>
									<td>
										<?php if ( $subscrpt_has_pr ) : ?>
											<span class="subscrpt-box-cell"><?php echo esc_html( $subscrpt_product['name'] ); ?></span>
											<span class="subscrpt-box-hint"><?php echo esc_html( $subscrpt_product['status_label'] ); ?></span>
										<?php else : ?>
											<span class="subscrpt-box-hint">&mdash;</span>
										<?php endif; ?>
									</td>
									<td>
										<?php if ( $subscrpt_box['offered'] ) : ?>
											<?php echo esc_html( implode( ', ', wp_list_pluck( $subscrpt_box['offered'], 'name' ) ) ); ?>
										<?php else : ?>
											<span class="subscrpt-box-hint">&mdash;</span>
										<?php endif; ?>
									</td>
									<td>
										<?php if ( ! $subscrpt_box['is_draft'] ) : ?>
											<span class="subscrpt-box-dot"><?php esc_html_e( 'Active', 'subscription-pro' ); ?></span>
										<?php elseif ( $subscrpt_box['needs_setup'] ) : ?>
											<span class="subscrpt-box-dot subscrpt-box-dot--warn"><?php esc_html_e( 'Needs setup', 'subscription-pro' ); ?></span>
										<?php else : ?>
											<span class="subscrpt-box-dot subscrpt-box-dot--draft"><?php esc_html_e( 'Draft', 'subscription-pro' ); ?></span>
										<?php endif; ?>
									</td>
									<td><span class="subscrpt-box-hint"><?php echo esc_html( $subscrpt_box['edited'] ); ?></span></td>
									<td>
										<span class="subscrpt-box-rowact">
											<?php if ( $subscrpt_has_pr && $subscrpt_product['view_url'] ) : ?>
												<a class="wpsubs-icon-action" href="<?php echo esc_url( $subscrpt_product['view_url'] ); ?>" target="_blank" rel="noopener" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: box name. */ __( 'Preview %s', 'subscription-pro' ), $subscrpt_box['name'] ) ); ?>">
													<span class="dashicons dashicons-visibility" aria-hidden="true"></span>
												</a>
											<?php endif; ?>
											<button
												type="button"
												class="wpsubs-icon-action wpsubs-icon-action--danger"
												data-subscrpt-delete-open="<?php echo esc_attr( $subscrpt_box['id'] ); ?>"
												data-box-name="<?php echo esc_attr( $subscrpt_box['name'] ); ?>"
												data-product-name="<?php echo esc_attr( $subscrpt_has_pr ? $subscrpt_product['name'] : '' ); ?>"
												data-product-meta="<?php echo esc_attr( $subscrpt_has_pr ? '#' . $subscrpt_product['id'] . ' · ' . $subscrpt_product['status_label'] : '' ); ?>"
												data-live-subs="<?php echo esc_attr( (string) $subscrpt_box['live_subs'] ); ?>"
												aria-label="<?php echo esc_attr( sprintf( /* translators: %s: box name. */ __( 'Delete %s', 'subscription-pro' ), $subscrpt_box['name'] ) ); ?>"
											>
												<span class="dashicons dashicons-trash" aria-hidden="true"></span>
											</button>
										</span>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>

				<p class="subscrpt-box-empty" data-subscrpt-browse-empty hidden>
					<?php esc_html_e( 'No boxes match.', 'subscription-pro' ); ?>
				</p>
				<div data-subscrpt-browse-pager class="subscrpt-box-browsepager"></div>

			</div>

		<?php endif; ?>

	<?php elseif ( 'upcoming' === $tab ) : ?>

		<p class="subscrpt-boxes__lede">
			<?php esc_html_e( 'Every box going out this month, and how far through packing it is. A locked box can no longer be changed by its subscriber. For example, tick the boxes you have packed and mark them Ready to ship.', 'subscription-pro' ); ?>
		</p>

		<?php require __DIR__ . '/partial-shipment-filters.php'; ?>

		<?php if ( empty( $upcoming ) ) : ?>
			<div class="wpsubs-empty">
				<div class="wpsubs-empty__icon">📅</div>
				<h3 class="wpsubs-empty__title"><?php esc_html_e( 'Nothing to ship in this month', 'subscription-pro' ); ?></h3>
				<p class="wpsubs-empty__desc"><?php esc_html_e( 'A box appears here as soon as it is paid for, and stays until you have packed it.', 'subscription-pro' ); ?></p>
			</div>
		<?php else : ?>

			<?php
			/*
			 * A pack run is a batch: somebody picks twenty boxes and marks them
			 * all at once. One row at a time would be the wrong shape for the
			 * work, so the list carries the same bulk control the Boxes tab has.
			 */
			?>
			<div class="wpsubs-toolbar" style="display:flex;align-items:center;gap:8px;margin-bottom:14px;">
				<span style="font-size:12.5px;color:var(--wpsubs-text-muted);">
					<?php esc_html_e( 'Tick the boxes you have handled, then:', 'subscription-pro' ); ?>
				</span>
				<?php
				wpsubs_render_adv_select(
					array(
						'name'        => 'subscrpt_shipment_bulk_action',
						'placeholder' => __( 'Mark as…', 'subscription-pro' ),
						'options'     => array(
							array(
								'value' => 'packing',
								'label' => __( 'Packing', 'subscription-pro' ),
							),
							array(
								'value' => 'ready',
								'label' => __( 'Ready to ship', 'subscription-pro' ),
							),
							array(
								'value' => 'retry',
								'label' => __( 'Send back to be packed again', 'subscription-pro' ),
							),
						),
						'attrs'       => array( 'data-subscrpt-shipment-bulk' => '1' ),
					)
				);
				?>
				<span style="flex:1 1 auto;"></span>
			</div>

			<div class="wpsubs-table-card" data-subscrpt-shipments>
				<table class="wpsubs-table subscrpt-boxes__table">
					<thead>
						<tr>
							<th class="wpsubs-col--check">
								<input type="checkbox" class="wpsubs-checkbox" data-subscrpt-select-all aria-label="<?php esc_attr_e( 'Select all shipments', 'subscription-pro' ); ?>" />
							</th>
							<th><?php esc_html_e( 'Packing', 'subscription-pro' ); ?></th>
							<th><?php esc_html_e( 'Customer', 'subscription-pro' ); ?></th>
							<th><?php esc_html_e( 'Box', 'subscription-pro' ); ?></th>
							<th><?php esc_html_e( 'Contents', 'subscription-pro' ); ?></th>
							<th><?php esc_html_e( 'Changes', 'subscription-pro' ); ?></th>
							<th><?php esc_html_e( 'Order', 'subscription-pro' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $upcoming as $subscrpt_row ) : ?>
							<tr<?php echo $subscrpt_row['is_failed'] ? ' class="subscrpt-boxes__short"' : ''; ?>>
								<td class="wpsubs-col--check">
									<input
										type="checkbox"
										class="wpsubs-checkbox wpsubs-row-check"
										value="<?php echo esc_attr( $subscrpt_row['id'] ); ?>"
										data-subscrpt-shipment="<?php echo esc_attr( $subscrpt_row['id'] ); ?>"
										aria-label="<?php esc_attr_e( 'Select this shipment', 'subscription-pro' ); ?>"
									/>
								</td>
								<td>
									<span class="subscrpt-boxes__badge is-<?php echo esc_attr( $subscrpt_row['status'] ); ?>">
										<?php echo esc_html( $subscrpt_row['status_label'] ); ?>
									</span>
									<?php if ( $subscrpt_row['dispatched'] ) : ?>
										<br /><span style="color:var(--wpsubs-text-subtle);font-size:12px;"><?php esc_html_e( 'Shipped', 'subscription-pro' ); ?></span>
									<?php endif; ?>
								</td>
								<td>
									<?php if ( $subscrpt_row['subscription_url'] ) : ?>
										<a href="<?php echo esc_url( (string) $subscrpt_row['subscription_url'] ); ?>"><?php echo esc_html( $subscrpt_row['customer'] ); ?></a>
									<?php else : ?>
										<?php echo esc_html( $subscrpt_row['customer'] ); ?>
									<?php endif; ?>
									<?php if ( $subscrpt_row['email'] ) : ?>
										<br /><span style="color:var(--wpsubs-text-subtle);font-size:12px;"><?php echo esc_html( $subscrpt_row['email'] ); ?></span>
									<?php endif; ?>
								</td>
								<td>
									<?php echo esc_html( $subscrpt_row['box'] ); ?>
									<br /><span style="color:var(--wpsubs-text-subtle);font-size:12px;">
										<?php
										printf(
											/* translators: %d: number of items in the box. */
											esc_html( _n( '%d item', '%d items', (int) $subscrpt_row['size'], 'subscription-pro' ) ),
											(int) $subscrpt_row['size']
										);
										?>
									</span>
								</td>
								<td><?php echo esc_html( $subscrpt_row['summary'] ); ?></td>
								<td>
									<?php if ( $subscrpt_row['is_skipped'] ) : ?>
										<span style="color:var(--wpsubs-text-subtle);"><?php esc_html_e( 'Skipped by the subscriber — nothing ships this month', 'subscription-pro' ); ?></span>
									<?php elseif ( $subscrpt_row['is_failed'] ) : ?>
										<span style="color:#b32d2e;"><?php esc_html_e( 'Payment failed — will not ship until it is paid', 'subscription-pro' ); ?></span>
									<?php elseif ( $subscrpt_row['is_one_time'] ) : ?>
										<span style="color:var(--wpsubs-text-subtle);"><?php esc_html_e( 'Bought once — nothing to change', 'subscription-pro' ); ?></span>
									<?php elseif ( $subscrpt_row['locked'] ) : ?>
										<span class="subscrpt-boxes__badge is-locked"><?php esc_html_e( 'Locked', 'subscription-pro' ); ?></span>
									<?php else : ?>
										<span class="subscrpt-boxes__badge is-open"><?php esc_html_e( 'Open to changes', 'subscription-pro' ); ?></span>
									<?php endif; ?>
								</td>
								<td>
									<?php if ( $subscrpt_row['order_url'] ) : ?>
										<a href="<?php echo esc_url( (string) $subscrpt_row['order_url'] ); ?>">#<?php echo esc_html( (string) $subscrpt_row['order_number'] ); ?></a>
										<br /><span style="color:var(--wpsubs-text-subtle);font-size:12px;"><?php echo esc_html( (string) $subscrpt_row['order_status'] ); ?></span>
									<?php else : ?>
										<span style="color:var(--wpsubs-text-subtle);">&mdash;</span>
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		<?php endif; ?>

	<?php else : ?>

		<?php require __DIR__ . '/partial-shipment-filters.php'; ?>

		<div class="subscrpt-boxes__picker">
			<p class="subscrpt-boxes__lede" style="margin:0;flex:1 1 auto;">
				<?php esc_html_e( 'Everything this month\'s boxes add up to. Anything short of stock is listed first. Skipped and failed boxes are left out — nobody packs those. For example, three boxes with 2 × tea each show as one line: tea, 6 units.', 'subscription-pro' ); ?>
			</p>
			<?php if ( ! empty( $pick_list ) ) : ?>
				<a
					class="wpsubs-btn wpsubs-btn--outline wpsubs-btn--sm"
					href="
					<?php
					echo esc_url(
						add_query_arg(
							array(
								'subscrpt_action' => 'pick_list_csv',
								'cycle'           => $cycle,
								'box_id'          => $box_of ? $box_of : false,
							),
							$list_url
						)
					);
					?>
							"
				>
					<span class="dashicons dashicons-download" style="font-size:15px;width:15px;height:15px;line-height:1;"></span>
					<?php esc_html_e( 'Download CSV', 'subscription-pro' ); ?>
				</a>
			<?php endif; ?>
		</div>

		<?php if ( empty( $pick_list ) ) : ?>
			<div class="wpsubs-empty">
				<div class="wpsubs-empty__icon">🧾</div>
				<h3 class="wpsubs-empty__title"><?php esc_html_e( 'Nothing to pack yet', 'subscription-pro' ); ?></h3>
				<p class="wpsubs-empty__desc"><?php esc_html_e( 'Once boxes are due, this totals every product across them.', 'subscription-pro' ); ?></p>
			</div>
		<?php else : ?>
			<div class="wpsubs-table-card">
				<table class="wpsubs-table subscrpt-boxes__table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Product', 'subscription-pro' ); ?></th>
							<th><?php esc_html_e( 'SKU', 'subscription-pro' ); ?></th>
							<th><?php esc_html_e( 'Units to pack', 'subscription-pro' ); ?></th>
							<th><?php esc_html_e( 'In stock', 'subscription-pro' ); ?></th>
							<th><?php esc_html_e( 'Short by', 'subscription-pro' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $pick_list as $subscrpt_pick ) : ?>
							<tr class="<?php echo $subscrpt_pick['short'] > 0 ? 'subscrpt-boxes__short' : ''; ?>">
								<td><?php echo esc_html( $subscrpt_pick['name'] ); ?></td>
								<td><?php echo esc_html( $subscrpt_pick['sku'] ); ?></td>
								<td><strong><?php echo esc_html( $subscrpt_pick['units'] ); ?></strong></td>
								<td>
									<?php
									echo null === $subscrpt_pick['stock']
										? esc_html__( 'Not tracked', 'subscription-pro' )
										: esc_html( $subscrpt_pick['stock'] );
									?>
								</td>
								<td>
									<?php if ( $subscrpt_pick['short'] > 0 ) : ?>
										<strong style="color:#b32d2e;"><?php echo esc_html( $subscrpt_pick['short'] ); ?></strong>
									<?php else : ?>
										<span style="color:var(--wpsubs-text-subtle);">&mdash;</span>
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		<?php endif; ?>

	<?php endif; ?>

</div>

<?php require __DIR__ . '/modal-create.php'; ?>
<?php require __DIR__ . '/modal-delete.php'; ?>
