<?php
/**
 * Box detail — Editions tab.
 *
 * An edition is what this box holds for one month. The merchant plans a cycle
 * ahead, publishes it, and every subscriber renewing in that month receives it
 * without doing anything — which is the part people pay other platforms for.
 *
 * Until now this tab was in the strip but had no template behind it, so it
 * opened an empty panel.
 *
 * Editions are keyed on the box, not on the product selling it. A product may
 * sell two edition boxes, and before that change they shared a month.
 *
 * @var array  $box     BoxPresenter::find().
 * @var int    $box_id  Box id.
 * @var array  $cycles  EditionRepository::upcoming() — cycle_key, label, edition.
 * @var array  $choices id => name of everything this box may pack.
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

defined( 'ABSPATH' ) || exit;

use SpringDevs\SubscriptionPro\Illuminate\Box\EditionRepository;

?>
<div style="padding-top:8px;max-width:820px;">

	<h3 style="margin:0 0 4px;font-size:14px;"><?php esc_html_e( 'What ships each month', 'subscription-pro' ); ?></h3>
	<p class="description" style="margin:0 0 4px;">
		<?php esc_html_e( 'Plan a month, publish it, and every subscriber renewing in that month receives it — they do not have to open an email or choose anything.', 'subscription-pro' ); ?>
	</p>
	<p class="description" style="margin:0 0 16px;">
		<?php esc_html_e( 'A month you leave unpublished keeps shipping the last published one, so a box is never empty because nobody got round to planning it.', 'subscription-pro' ); ?>
	</p>

	<?php if ( empty( $choices ) ) : ?>
		<div style="padding:14px;border-radius:8px;background:#fcf9e8;border-left:4px solid #dba617;">
			<?php esc_html_e( 'Add products on the Contents tab first — an edition is picked from what this box may pack.', 'subscription-pro' ); ?>
		</div>
	<?php else : ?>

		<?php
		// The month just saved stays open after the redirect; otherwise the first.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only view state.
		$subscrpt_open_cycle = isset( $_GET['cycle'] ) ? sanitize_text_field( wp_unslash( $_GET['cycle'] ) ) : '';
		$subscrpt_cycle_keys = wp_list_pluck( $cycles, 'cycle_key' );

		if ( ! in_array( $subscrpt_open_cycle, $subscrpt_cycle_keys, true ) ) {
			$subscrpt_open_cycle = (string) reset( $subscrpt_cycle_keys );
		}
		?>

		<?php foreach ( $cycles as $subscrpt_cycle ) : ?>
			<?php
			$subscrpt_edition   = $subscrpt_cycle['edition'];
			$subscrpt_published = $subscrpt_edition && EditionRepository::STATUS_PUBLISHED === $subscrpt_edition['status'];
			$subscrpt_chosen    = array();

			if ( $subscrpt_edition ) {
				foreach ( (array) $subscrpt_edition['contents'] as $subscrpt_item ) {
					$subscrpt_chosen[] = (int) $subscrpt_item['product_id'];
				}
			}

			$subscrpt_reach = $subscrpt_published
				? EditionRepository::subscriber_count( $box_id, $subscrpt_cycle['cycle_key'] )
				: 0;

			/* translators: %d: how many products are ticked for this month. */
			$subscrpt_count_one = __( '%d item', 'subscription-pro' );
			/* translators: %d: how many products are ticked for this month. */
			$subscrpt_count_many = __( '%d items', 'subscription-pro' );
			?>

			<details
				class="wpsubs-table-card subscrpt-edition"
				id="<?php echo esc_attr( 'subscrpt-edition-' . $subscrpt_cycle['cycle_key'] ); ?>"
				<?php echo $subscrpt_open_cycle === $subscrpt_cycle['cycle_key'] ? 'open' : ''; ?>
			>
				<summary class="subscrpt-edition__summary">
					<span class="subscrpt-edition__chevron" aria-hidden="true"></span>
					<strong class="subscrpt-edition__month"><?php echo esc_html( $subscrpt_cycle['label'] ); ?></strong>

					<?php if ( ! empty( $subscrpt_edition['title'] ) ) : ?>
						<span class="subscrpt-edition__name"><?php echo esc_html( $subscrpt_edition['title'] ); ?></span>
					<?php endif; ?>

					<?php if ( $subscrpt_published ) : ?>
						<span class="subscrpt-boxes__badge is-published"><?php esc_html_e( 'Published', 'subscription-pro' ); ?></span>
					<?php elseif ( $subscrpt_edition ) : ?>
						<span class="subscrpt-boxes__badge is-draft"><?php esc_html_e( 'Planned, not published', 'subscription-pro' ); ?></span>
					<?php else : ?>
						<span class="subscrpt-edition__muted"><?php esc_html_e( 'Nothing planned', 'subscription-pro' ); ?></span>
					<?php endif; ?>

					<span class="subscrpt-edition__spacer"></span>

					<?php if ( $subscrpt_published ) : ?>
						<span class="subscrpt-edition__muted">
							<?php
							printf(
								/* translators: %d: how many subscribers renew in this month. */
								esc_html( _n( 'Reaches %d subscriber', 'Reaches %d subscribers', $subscrpt_reach, 'subscription-pro' ) ),
								(int) $subscrpt_reach
							);
							?>
						</span>
					<?php endif; ?>

					<span
						class="subscrpt-edition__count"
						data-subscrpt-edition-count
						data-one="<?php echo esc_attr( $subscrpt_count_one ); ?>"
						data-many="<?php echo esc_attr( $subscrpt_count_many ); ?>"
					>
						<?php echo esc_html( sprintf( 1 === count( $subscrpt_chosen ) ? $subscrpt_count_one : $subscrpt_count_many, count( $subscrpt_chosen ) ) ); ?>
					</span>
				</summary>

				<form method="post" class="subscrpt-edition__form">
					<?php wp_nonce_field( 'subscrpt_box_edition', 'subscrpt_box_edition_nonce' ); ?>
					<input type="hidden" name="subscrpt_box_edition_box" value="<?php echo esc_attr( $box_id ); ?>" />
					<input type="hidden" name="subscrpt_box_edition_cycle" value="<?php echo esc_attr( $subscrpt_cycle['cycle_key'] ); ?>" />
					<?php if ( $subscrpt_edition ) : ?>
						<input type="hidden" name="subscrpt_box_edition_id" value="<?php echo esc_attr( $subscrpt_edition['id'] ); ?>" />
					<?php endif; ?>

					<div class="subscrpt-edition__body">
						<label class="subscrpt-edition__label" for="<?php echo esc_attr( 'subscrpt-edition-title-' . $subscrpt_cycle['cycle_key'] ); ?>">
							<?php esc_html_e( 'Name', 'subscription-pro' ); ?>
						</label>
						<input
							type="text"
							class="wpsubs-input subscrpt-edition__title"
							id="<?php echo esc_attr( 'subscrpt-edition-title-' . $subscrpt_cycle['cycle_key'] ); ?>"
							name="subscrpt_box_edition_title"
							value="<?php echo esc_attr( $subscrpt_edition['title'] ?? '' ); ?>"
							placeholder="<?php esc_attr_e( 'Name this month, optional', 'subscription-pro' ); ?>"
							<?php disabled( $subscrpt_published ); ?>
						/>

						<fieldset class="subscrpt-edition__holds">
							<legend class="subscrpt-edition__label"><?php esc_html_e( 'What this month holds', 'subscription-pro' ); ?></legend>

							<div class="subscrpt-edition__chips">
								<?php foreach ( $choices as $subscrpt_choice_id => $subscrpt_choice_name ) : ?>
									<label class="subscrpt-edition__chip">
										<input
											type="checkbox"
											name="subscrpt_box_edition_contents[]"
											value="<?php echo esc_attr( $subscrpt_choice_id ); ?>"
											<?php checked( in_array( (int) $subscrpt_choice_id, $subscrpt_chosen, true ) ); ?>
											<?php disabled( $subscrpt_published ); ?>
										/>
										<span class="subscrpt-edition__chip-text"><?php echo esc_html( $subscrpt_choice_name ); ?></span>
									</label>
								<?php endforeach; ?>
							</div>
						</fieldset>
					</div>

					<div class="subscrpt-edition__footer">
						<?php if ( $subscrpt_published ) : ?>
							<p class="description" style="margin:0;">
								<?php esc_html_e( 'This month is live, so its contents are fixed — subscribers have already been told what is coming.', 'subscription-pro' ); ?>
							</p>
						<?php else : ?>
							<button type="submit" name="subscrpt_box_edition_action" value="save" class="wpsubs-btn wpsubs-btn--outline wpsubs-btn--sm">
								<?php esc_html_e( 'Save plan', 'subscription-pro' ); ?>
							</button>

							<?php if ( $subscrpt_edition ) : ?>
								<button type="submit" name="subscrpt_box_edition_action" value="publish" class="wpsubs-btn wpsubs-btn--primary wpsubs-btn--sm">
									<?php esc_html_e( 'Publish this month', 'subscription-pro' ); ?>
								</button>
								<span class="subscrpt-edition__muted">
									<?php esc_html_e( 'Publishing is final — it decides what ships.', 'subscription-pro' ); ?>
								</span>
							<?php endif; ?>
						<?php endif; ?>
					</div>
				</form>
			</details>

		<?php endforeach; ?>

	<?php endif; ?>

</div>
