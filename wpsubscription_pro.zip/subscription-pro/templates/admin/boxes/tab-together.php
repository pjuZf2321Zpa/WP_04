<?php
/**
 * Box detail — Together tab.
 *
 * The "often boxed together" block on an item's product page: whether this
 * box's items show it, where on the page it sits, and the pairs it will show.
 * The pairs are read only: they are counted from live subscriptions, never
 * edited.
 *
 * @var array  $box      BoxPresenter::find().
 * @var int    $box_id   Box id.
 * @var array  $pairs    BoxPresenter::top_pairs().
 * @var string $position Where the section sits on every product page.
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

defined( 'ABSPATH' ) || exit;

use SpringDevs\SubscriptionPro\Frontend\BoxTogetherSection;

$subscrpt_positions = array(
	BoxTogetherSection::BEFORE_TABS => array( __( 'Above the description', 'subscription-pro' ), __( 'Seen sooner, right after the product summary and Add to cart.', 'subscription-pro' ), 'dashicons-arrow-up-alt' ),
	BoxTogetherSection::AFTER_TABS  => array( __( 'Below the description', 'subscription-pro' ), __( 'Out of the way, after the product details and reviews.', 'subscription-pro' ), 'dashicons-arrow-down-alt' ),
);
$subscrpt_position  = BoxTogetherSection::AFTER_TABS === $position ? BoxTogetherSection::AFTER_TABS : BoxTogetherSection::BEFORE_TABS;
$subscrpt_pair_sum  = array_sum( wp_list_pluck( $pairs, 'count' ) );
?>
<div data-subscrpt-box-form="together">

	<div class="subscrpt-box-card">
		<div class="subscrpt-box-card__head">
			<div>
				<h3><?php esc_html_e( 'Often boxed together', 'subscription-pro' ); ?></h3>
				<p><?php esc_html_e( 'On an item’s product page, shoppers see what other subscribers put in the same box with it. Built from real boxes, so it fills in as you sell.', 'subscription-pro' ); ?></p>
			</div>
			<label class="subscrpt-box-row">
				<span class="subscrpt-box-hint" data-subscrpt-together-state data-on="<?php esc_attr_e( 'Shown', 'subscription-pro' ); ?>" data-off="<?php esc_attr_e( 'Hidden', 'subscription-pro' ); ?>">
					<?php echo $box['show_together'] ? esc_html__( 'Shown', 'subscription-pro' ) : esc_html__( 'Hidden', 'subscription-pro' ); ?>
				</span>
				<input type="checkbox" class="wpsubs-toggle" data-subscrpt-box-field="show_together" data-subscrpt-together-toggle <?php checked( $box['show_together'] ); ?> aria-label="<?php esc_attr_e( 'Show on product pages', 'subscription-pro' ); ?>" />
				<span class="wpsubs-toggle-ui" aria-hidden="true"></span>
			</label>
		</div>

		<div data-subscrpt-together-position <?php echo $box['show_together'] ? '' : 'hidden'; ?>>
			<div class="subscrpt-box-card__divider"></div>
			<div class="subscrpt-box-card__head subscrpt-box-card__head--tight">
				<div>
					<h3><?php esc_html_e( 'Where on the page?', 'subscription-pro' ); ?></h3>
					<p><?php esc_html_e( 'Applies to every box.', 'subscription-pro' ); ?></p>
				</div>
			</div>
			<div class="subscrpt-box-card__body">
				<div class="subscrpt-box-choices subscrpt-box-choices--2" role="radiogroup">
					<?php foreach ( $subscrpt_positions as $subscrpt_key => $subscrpt_choice ) : ?>
						<label class="subscrpt-box-choice subscrpt-box-choice--stack<?php echo $subscrpt_position === $subscrpt_key ? ' is-on' : ''; ?>">
							<input type="radio" name="subscrpt-together-position" value="<?php echo esc_attr( $subscrpt_key ); ?>" data-subscrpt-box-field="together_position" <?php checked( $subscrpt_position, $subscrpt_key ); ?> />
							<span class="subscrpt-box-choice__icon"><span class="dashicons <?php echo esc_attr( $subscrpt_choice[2] ); ?>" aria-hidden="true"></span></span>
							<span><b><?php echo esc_html( $subscrpt_choice[0] ); ?></b><small><?php echo esc_html( $subscrpt_choice[1] ); ?></small></span>
						</label>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
	</div>

	<div class="subscrpt-box-card">
		<div class="subscrpt-box-card__head">
			<div>
				<h3><?php esc_html_e( 'Top pairs', 'subscription-pro' ); ?></h3>
				<p>
					<?php
					echo $pairs
						/* translators: %d: number of boxes counted. */
						? esc_html( sprintf( _n( 'Counted from %d box held by live subscriptions.', 'Counted from %d boxes held by live subscriptions.', $subscrpt_pair_sum, 'subscription-pro' ), $subscrpt_pair_sum ) )
						: esc_html__( 'Pairs are counted from live subscriptions of this box and appear once there are some. Until then the section suggests the box’s own picks and pool.', 'subscription-pro' );
					?>
				</p>
			</div>
		</div>
		<?php if ( $pairs ) : ?>
			<div class="subscrpt-box-tablewrap">
				<table class="subscrpt-box-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Product', 'subscription-pro' ); ?></th>
							<th><?php esc_html_e( 'Often boxed with', 'subscription-pro' ); ?></th>
							<th class="is-num"><?php esc_html_e( 'Boxes', 'subscription-pro' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $pairs as $subscrpt_pair ) : ?>
							<tr>
								<td class="is-strong"><?php echo esc_html( $subscrpt_pair['a'] ); ?></td>
								<td><?php echo esc_html( $subscrpt_pair['b'] ); ?></td>
								<td class="is-num"><?php echo esc_html( number_format_i18n( $subscrpt_pair['count'] ) ); ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		<?php endif; ?>
	</div>

	<?php require __DIR__ . '/partial-savebar.php'; ?>
</div>
