<?php
/**
 * The box's pool: the products listed, and the picker that changes them.
 *
 * Used for a build-your-own box's choices and an edition box's swap-ins — the
 * same `pool.products` field either way. The list is the field: boxes.js reads
 * the ids off its rows when the tab saves, and the picker rewrites the rows.
 *
 * @var array $box BoxPresenter::find().
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

defined( 'ABSPATH' ) || exit;

$subscrpt_thumb_style = 'flex:0 0 auto;width:32px;height:32px;border-radius:4px;background:var(--wpsubs-bg-subtle,#f1f2f4);border:1px solid var(--wpsubs-border);overflow:hidden;display:flex;align-items:center;justify-content:center;';
?>
<div class="wpsubs-table-card" data-subscrpt-box-field="pool.products" data-subscrpt-pool>
	<div style="display:flex;align-items:center;gap:12px;padding:10px 16px;border-bottom:1px solid var(--wpsubs-border);background:var(--wpsubs-bg-subtle,#f6f7f7);">
		<span data-subscrpt-pool-count style="margin-right:auto;font-size:13px;color:var(--wpsubs-text-muted);"></span>
		<button type="button" class="wpsubs-btn wpsubs-btn--outline wpsubs-btn--sm" data-wpsubs-modal-open="subscrpt-pool-picker">
			<?php esc_html_e( 'Manage products', 'subscription-pro' ); ?>
		</button>
	</div>

	<ul data-subscrpt-pool-list style="list-style:none;margin:0;padding:0;max-height:360px;overflow-y:auto;">
		<?php foreach ( $box['pool_items'] as $subscrpt_item ) : ?>
			<li
				data-subscrpt-pool-item="<?php echo esc_attr( $subscrpt_item['id'] ); ?>"
				data-parent-id="<?php echo esc_attr( $subscrpt_item['parent_id'] ); ?>"
				data-parent-name="<?php echo esc_attr( $subscrpt_item['parent_name'] ); ?>"
				style="margin:0;display:flex;align-items:center;gap:10px;padding:8px 16px;border-bottom:1px solid rgba(0,0,0,0.06);"
			>
				<span style="<?php echo esc_attr( $subscrpt_thumb_style ); ?>">
					<?php if ( ! empty( $subscrpt_item['image'] ) ) : ?>
						<img src="<?php echo esc_url( $subscrpt_item['image'] ); ?>" alt="" style="width:100%;height:100%;object-fit:cover;display:block;" />
					<?php else : ?>
						<span class="dashicons dashicons-format-image" style="font-size:16px;width:16px;height:16px;color:var(--wpsubs-text-subtle);"></span>
					<?php endif; ?>
				</span>
				<span style="flex:1 1 auto;min-width:0;display:flex;flex-direction:column;">
					<span style="font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?php echo esc_html( $subscrpt_item['name'] ); ?></span>
					<?php if ( $subscrpt_item['sku'] ) : ?>
						<span style="font-size:12px;color:var(--wpsubs-text-subtle);"><?php echo esc_html( $subscrpt_item['sku'] ); ?></span>
					<?php endif; ?>
				</span>
				<?php if ( ! empty( $subscrpt_item['unusable'] ) ) : ?>
					<span class="wpsubs-badge wpsubs-badge--warning" title="<?php echo esc_attr( $subscrpt_item['reason'] ); ?>"><?php esc_html_e( 'Skipped', 'subscription-pro' ); ?></span>
				<?php endif; ?>
				<button type="button" class="wpsubs-btn wpsubs-btn--icon" data-subscrpt-pool-remove aria-label="<?php esc_attr_e( 'Remove', 'subscription-pro' ); ?>">&times;</button>
			</li>
		<?php endforeach; ?>
	</ul>

	<p data-subscrpt-pool-empty style="margin:0;padding:16px;color:var(--wpsubs-text-subtle);font-size:13px;" <?php echo $box['pool_items'] ? 'hidden' : ''; ?>>
		<?php esc_html_e( 'Nothing here yet. Use Manage products to choose what goes in the box.', 'subscription-pro' ); ?>
	</p>
</div>

<?php require __DIR__ . '/modal-pool-picker.php'; ?>
