<?php
/**
 * Box detail — Durations tab.
 *
 * How often the box ships and bills, set on the box itself with the fields a
 * plan has. Behind the scenes each one is an ordinary plan term attached to the
 * box's product, so checkout and renewals are unchanged. Every change saves at
 * once; there is no save bar here.
 *
 * @var array $box         BoxPresenter::find().
 * @var int   $box_id      Box id.
 * @var array $plan_groups Plan groups the box may borrow.
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

defined( 'ABSPATH' ) || exit;

$subscrpt_shared   = 'shared' === $box['plans']['mode'];
$subscrpt_currency = html_entity_decode( get_woocommerce_currency_symbol(), ENT_QUOTES, 'UTF-8' );
$subscrpt_units    = array(
	'day'   => __( 'Day(s)', 'subscription-pro' ),
	'week'  => __( 'Week(s)', 'subscription-pro' ),
	'month' => __( 'Month(s)', 'subscription-pro' ),
	'year'  => __( 'Year(s)', 'subscription-pro' ),
);
$subscrpt_is_sum   = 'sum' === $box['pricing']['strategy'];
$subscrpt_plans    = admin_url( 'admin.php?page=wp-subscription-plans' );
?>
<div data-subscrpt-durations data-mode="<?php echo $subscrpt_shared ? 'shared' : 'own'; ?>">

	<div class="subscrpt-box-card">
		<div class="subscrpt-box-card__head">
			<div>
				<h3><?php esc_html_e( 'How often it ships and bills', 'subscription-pro' ); ?></h3>
				<p><?php esc_html_e( 'Customers choose one of these on the product page. Turning one off stops offering it; subscriptions already on it keep renewing.', 'subscription-pro' ); ?></p>
			</div>
			<div class="subscrpt-box-seg" role="group" aria-label="<?php esc_attr_e( 'Duration source', 'subscription-pro' ); ?>">
				<button type="button" data-subscrpt-duration-mode="own" aria-pressed="<?php echo $subscrpt_shared ? 'false' : 'true'; ?>"><?php esc_html_e( 'This box’s durations', 'subscription-pro' ); ?></button>
				<button type="button" data-subscrpt-duration-mode="shared" aria-pressed="<?php echo $subscrpt_shared ? 'true' : 'false'; ?>"><?php esc_html_e( 'A shared plan', 'subscription-pro' ); ?></button>
			</div>
		</div>

		<div class="subscrpt-box-shared" data-subscrpt-shared-picker <?php echo $subscrpt_shared ? '' : 'hidden'; ?>>
			<?php if ( $plan_groups ) : ?>
				<label class="subscrpt-box-label" for="subscrpt-shared-plan"><?php esc_html_e( 'Plan', 'subscription-pro' ); ?></label>
				<div class="subscrpt-box-row">
					<select id="subscrpt-shared-plan" class="wpsubs-input subscrpt-box-autoselect" data-subscrpt-shared-plan>
						<option value=""><?php esc_html_e( 'Choose a plan…', 'subscription-pro' ); ?></option>
						<?php foreach ( $plan_groups as $subscrpt_group ) : ?>
							<option value="<?php echo esc_attr( (string) $subscrpt_group['id'] ); ?>" <?php selected( $subscrpt_shared ? $box['plans']['shared_group_id'] : 0, $subscrpt_group['id'] ); ?>>
								<?php
								echo esc_html(
									sprintf(
										/* translators: 1: plan name, 2: number of durations. */
										_n( '%1$s (%2$d duration)', '%1$s (%2$d durations)', $subscrpt_group['durations'], 'subscription-pro' ),
										$subscrpt_group['title'],
										$subscrpt_group['durations']
									)
								);
								?>
							</option>
						<?php endforeach; ?>
					</select>
					<button type="button" class="wpsubs-btn wpsubs-btn--primary wpsubs-btn--sm" data-subscrpt-shared-use><?php esc_html_e( 'Use this plan', 'subscription-pro' ); ?></button>
				</div>
				<p class="subscrpt-box-hint subscrpt-box-hint--below">
					<?php
					printf(
						/* translators: %s: link to the Plans screen. */
						esc_html__( 'Its durations show here read-only. Change them on the %s screen.', 'subscription-pro' ),
						'<a href="' . esc_url( $subscrpt_plans ) . '">' . esc_html__( 'Plans', 'subscription-pro' ) . '</a>'
					);
					?>
				</p>
			<?php else : ?>
				<p class="subscrpt-box-hint">
					<?php
					printf(
						/* translators: %s: link to the Plans screen. */
						esc_html__( 'There are no shared plans yet. Make one on the %s screen.', 'subscription-pro' ),
						'<a href="' . esc_url( $subscrpt_plans ) . '">' . esc_html__( 'Plans', 'subscription-pro' ) . '</a>'
					);
					?>
				</p>
			<?php endif; ?>
		</div>

		<?php foreach ( $box['durations'] as $subscrpt_duration ) : ?>
			<div class="subscrpt-box-lrow<?php echo $subscrpt_duration['on'] ? '' : ' is-off'; ?>" data-subscrpt-duration="<?php echo esc_attr( (string) $subscrpt_duration['id'] ); ?>" data-duration="<?php echo esc_attr( (string) wp_json_encode( $subscrpt_duration ) ); ?>">
				<span class="subscrpt-box-ic"><span class="dashicons dashicons-calendar-alt" aria-hidden="true"></span></span>
				<div class="subscrpt-box-lrow__grow">
					<div class="subscrpt-box-lrow__title"><?php echo esc_html( $subscrpt_duration['name'] ); ?></div>
					<div class="subscrpt-box-lrow__sub">
						<?php /* translators: %s: how often, e.g. "every month". */ ?>
						<span><?php echo esc_html( sprintf( __( 'Bills and ships %s', 'subscription-pro' ), $subscrpt_duration['cadence'] ) ); ?></span>
						<?php if ( '' !== $subscrpt_duration['price'] && ! $subscrpt_is_sum ) : ?>
							<span><?php echo wp_kses_post( wc_price( (float) $subscrpt_duration['price'] ) ); ?></span>
						<?php endif; ?>
						<?php if ( $subscrpt_duration['trial'] ) : ?>
							<?php /* translators: %d: free trial length in days. */ ?>
							<span><?php echo esc_html( sprintf( __( '%d-day free trial', 'subscription-pro' ), $subscrpt_duration['trial'] ) ); ?></span>
						<?php endif; ?>
						<?php if ( $subscrpt_duration['fee'] > 0 ) : ?>
							<?php /* translators: %s: signup fee. */ ?>
							<span><?php echo wp_kses_post( sprintf( __( '%s signup fee', 'subscription-pro' ), wc_price( $subscrpt_duration['fee'] ) ) ); ?></span>
						<?php endif; ?>
					</div>
				</div>
				<?php if ( ! $subscrpt_shared ) : ?>
					<label class="subscrpt-box-switch" title="<?php esc_attr_e( 'Offer this duration', 'subscription-pro' ); ?>">
						<input type="checkbox" class="wpsubs-toggle" data-subscrpt-duration-toggle <?php checked( $subscrpt_duration['on'] ); ?> aria-label="<?php echo esc_attr( sprintf( /* translators: %s: duration name. */ __( 'Offer %s', 'subscription-pro' ), $subscrpt_duration['name'] ) ); ?>" />
						<span class="wpsubs-toggle-ui" aria-hidden="true"></span>
					</label>
					<button type="button" class="wpsubs-icon-action" data-subscrpt-duration-edit aria-label="<?php echo esc_attr( sprintf( /* translators: %s: duration name. */ __( 'Edit %s', 'subscription-pro' ), $subscrpt_duration['name'] ) ); ?>">
						<span class="dashicons dashicons-edit" aria-hidden="true"></span>
					</button>
					<button type="button" class="wpsubs-icon-action wpsubs-icon-action--danger" data-subscrpt-duration-delete aria-label="<?php echo esc_attr( sprintf( /* translators: %s: duration name. */ __( 'Remove %s', 'subscription-pro' ), $subscrpt_duration['name'] ) ); ?>">
						<span class="dashicons dashicons-trash" aria-hidden="true"></span>
					</button>
				<?php elseif ( ! $subscrpt_duration['on'] ) : ?>
					<span class="subscrpt-box-hint"><?php esc_html_e( 'Off', 'subscription-pro' ); ?></span>
				<?php endif; ?>
			</div>
		<?php endforeach; ?>

		<?php if ( ! $box['durations'] && $subscrpt_shared ) : ?>
			<div class="subscrpt-box-lrow subscrpt-box-hint"><?php esc_html_e( 'This plan has no durations yet.', 'subscription-pro' ); ?></div>
		<?php endif; ?>

		<?php if ( ! $subscrpt_shared ) : ?>
			<form class="subscrpt-box-inlineform" data-subscrpt-duration-form hidden>
				<input type="hidden" data-duration-field="id" value="" />
				<div class="subscrpt-box-fgrid">
					<div class="subscrpt-box-field">
						<label for="subscrpt-duration-name"><?php esc_html_e( 'Name', 'subscription-pro' ); ?></label>
						<input type="text" class="wpsubs-input" id="subscrpt-duration-name" data-duration-field="name" placeholder="<?php esc_attr_e( 'e.g. Monthly', 'subscription-pro' ); ?>" required />
					</div>
					<div class="subscrpt-box-field">
						<label for="subscrpt-duration-every"><?php esc_html_e( 'Bills every', 'subscription-pro' ); ?></label>
						<span class="subscrpt-box-pair">
							<input type="number" min="1" step="1" class="wpsubs-input" id="subscrpt-duration-every" data-duration-field="every" value="1" />
							<select class="wpsubs-input" data-duration-field="unit" aria-label="<?php esc_attr_e( 'Unit', 'subscription-pro' ); ?>">
								<?php foreach ( $subscrpt_units as $subscrpt_unit => $subscrpt_unit_label ) : ?>
									<option value="<?php echo esc_attr( $subscrpt_unit ); ?>" <?php selected( 'month', $subscrpt_unit ); ?>><?php echo esc_html( $subscrpt_unit_label ); ?></option>
								<?php endforeach; ?>
							</select>
						</span>
					</div>
					<div class="subscrpt-box-field">
						<label for="subscrpt-duration-price"><?php esc_html_e( 'Price', 'subscription-pro' ); ?></label>
						<input type="number" min="0" step="any" class="wpsubs-input" id="subscrpt-duration-price" data-duration-field="price" placeholder="<?php echo esc_attr( $subscrpt_currency . ' 0.00' ); ?>" <?php disabled( $subscrpt_is_sum ); ?> />
					</div>
					<div class="subscrpt-box-field">
						<label for="subscrpt-duration-trial"><?php esc_html_e( 'Free trial', 'subscription-pro' ); ?> <span class="subscrpt-box-hint"><?php esc_html_e( 'days', 'subscription-pro' ); ?></span></label>
						<input type="number" min="0" step="1" class="wpsubs-input" id="subscrpt-duration-trial" data-duration-field="trial" placeholder="0" />
					</div>
					<div class="subscrpt-box-field">
						<label for="subscrpt-duration-fee"><?php esc_html_e( 'Signup fee', 'subscription-pro' ); ?></label>
						<input type="number" min="0" step="any" class="wpsubs-input" id="subscrpt-duration-fee" data-duration-field="fee" placeholder="<?php echo esc_attr( $subscrpt_currency . ' 0.00' ); ?>" />
					</div>
				</div>
				<p class="subscrpt-box-hint">
					<?php
					echo $subscrpt_is_sum
						? esc_html__( 'This box adds up what is picked, so a duration sets only how often it ships and bills.', 'subscription-pro' )
						: esc_html__( 'Leave the price empty to use the product’s own price.', 'subscription-pro' );
					?>
				</p>
				<div class="subscrpt-box-row subscrpt-box-row--end">
					<button type="button" class="wpsubs-btn wpsubs-btn--outline wpsubs-btn--sm" data-subscrpt-duration-cancel><?php esc_html_e( 'Cancel', 'subscription-pro' ); ?></button>
					<button type="submit" class="wpsubs-btn wpsubs-btn--primary wpsubs-btn--sm" data-subscrpt-duration-submit
						data-add="<?php esc_attr_e( 'Add duration', 'subscription-pro' ); ?>"
						data-save="<?php esc_attr_e( 'Save duration', 'subscription-pro' ); ?>"
					><?php esc_html_e( 'Add duration', 'subscription-pro' ); ?></button>
				</div>
			</form>

			<div class="subscrpt-box-lrow subscrpt-box-lrow--add" data-subscrpt-duration-add-row>
				<button type="button" class="subscrpt-box-link" data-subscrpt-duration-add>
					<span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span><?php esc_html_e( 'Add a duration', 'subscription-pro' ); ?>
				</button>
			</div>
		<?php endif; ?>
	</div>

	<div class="subscrpt-box-card">
		<div class="subscrpt-box-card__head">
			<div>
				<h3><?php esc_html_e( 'Customers see', 'subscription-pro' ); ?></h3>
				<p><?php esc_html_e( 'The first duration is selected when the page opens.', 'subscription-pro' ); ?></p>
			</div>
			<?php if ( $box['product'] && ! $box['product']['missing'] && $box['product']['view_url'] ) : ?>
				<a class="wpsubs-btn wpsubs-btn--outline wpsubs-btn--sm" href="<?php echo esc_url( $box['product']['view_url'] ); ?>" target="_blank" rel="noopener">
					<span class="dashicons dashicons-visibility" aria-hidden="true"></span><?php esc_html_e( 'Preview page', 'subscription-pro' ); ?>
				</a>
			<?php endif; ?>
		</div>
		<div class="subscrpt-box-card__body">
			<div class="subscrpt-box-strip">
				<?php if ( $box['offered'] ) : ?>
					<?php foreach ( $box['offered'] as $subscrpt_index => $subscrpt_duration ) : ?>
						<span class="<?php echo 0 === $subscrpt_index ? 'is-first' : ''; ?>"><?php echo esc_html( $subscrpt_duration['name'] ); ?></span>
					<?php endforeach; ?>
				<?php else : ?>
					<span class="subscrpt-box-hint"><?php esc_html_e( 'Nothing offered yet', 'subscription-pro' ); ?></span>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>
