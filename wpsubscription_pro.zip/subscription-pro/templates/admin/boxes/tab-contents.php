<?php
/**
 * Box detail — Box items tab.
 *
 * What a box holds, which means two different questions depending on the type.
 * A build-your-own box needs a pool to choose from and the items it starts
 * with; a curated or edition box needs the list the merchant packs.
 *
 * The pool list pages through the store from the server, so a shop with
 * thousands of products is no slower to manage than one with ten. Its source,
 * categories and exclusions are edited in the browser and saved together from
 * the save bar.
 *
 * @var array $box        BoxPresenter::find().
 * @var int   $box_id     Box id.
 * @var array $categories Every product category, with counts.
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

defined( 'ABSPATH' ) || exit;

use SpringDevs\SubscriptionPro\Illuminate\Box\Box;
use SpringDevs\SubscriptionPro\Illuminate\Box\BoxPool;

$subscrpt_is_build = Box::TYPE_BUILD === $box['type'];
$subscrpt_pool     = $box['pool'];
$subscrpt_sources  = array(
	BoxPool::SOURCE_PRODUCTS   => array( __( 'Chosen products', 'subscription-pro' ), __( 'Pick each product yourself.', 'subscription-pro' ), 'dashicons-list-view' ),
	BoxPool::SOURCE_CATEGORIES => array( __( 'Categories', 'subscription-pro' ), __( 'Everything in the categories you choose, including products added later.', 'subscription-pro' ), 'dashicons-tag' ),
	BoxPool::SOURCE_ALL        => array( __( 'Whole shop', 'subscription-pro' ), __( 'Every product in your store.', 'subscription-pro' ), 'dashicons-store' ),
);
$subscrpt_rules    = array(
	BoxPool::SOURCE_ALL      => __( 'Every product in your store is in the box, including products you add later. Switch a product off to leave it out.', 'subscription-pro' ),
	/* translators: %s: the chosen category names. */
	'categories'             => __( 'Every product in %s is in the box, including products added to them later. Switch a product off to leave it out.', 'subscription-pro' ),
	BoxPool::SOURCE_PRODUCTS => __( 'Only the products you chose are in the box. Remove one to take it out.', 'subscription-pro' ),
);
?>
<div data-subscrpt-box-form="contents">

	<?php if ( $subscrpt_is_build ) : ?>

		<div
			data-subscrpt-pool-editor
			data-pool="<?php echo esc_attr( (string) wp_json_encode( $subscrpt_pool ) ); ?>"
			data-rules="<?php echo esc_attr( (string) wp_json_encode( $subscrpt_rules ) ); ?>"
			data-category-names="<?php echo esc_attr( (string) wp_json_encode( wp_list_pluck( $categories, 'name', 'id' ) ) ); ?>"
		>
			<div class="subscrpt-box-card">
				<div class="subscrpt-box-card__head">
					<div>
						<h3><?php esc_html_e( 'Where do the items come from?', 'subscription-pro' ); ?></h3>
						<p><?php esc_html_e( 'Customers build their box from these. A product that sells a box is never offered, so a box can’t contain itself.', 'subscription-pro' ); ?></p>
					</div>
				</div>
				<div class="subscrpt-box-card__body">
					<div class="subscrpt-box-choices subscrpt-box-choices--3" role="radiogroup" aria-label="<?php esc_attr_e( 'Where the items come from', 'subscription-pro' ); ?>">
						<?php foreach ( $subscrpt_sources as $subscrpt_key => $subscrpt_source ) : ?>
							<label class="subscrpt-box-choice subscrpt-box-choice--stack<?php echo $subscrpt_pool['source'] === $subscrpt_key ? ' is-on' : ''; ?>">
								<input type="radio" name="subscrpt-pool-source" value="<?php echo esc_attr( $subscrpt_key ); ?>" data-subscrpt-pool-source <?php checked( $subscrpt_pool['source'], $subscrpt_key ); ?> />
								<span class="subscrpt-box-choice__icon"><span class="dashicons <?php echo esc_attr( $subscrpt_source[2] ); ?>" aria-hidden="true"></span></span>
								<span><b><?php echo esc_html( $subscrpt_source[0] ); ?></b><small><?php echo esc_html( $subscrpt_source[1] ); ?></small></span>
							</label>
						<?php endforeach; ?>
					</div>
				</div>

				<div data-subscrpt-pool-when="categories" <?php echo BoxPool::SOURCE_CATEGORIES === $subscrpt_pool['source'] ? '' : 'hidden'; ?>>
					<div class="subscrpt-box-card__divider"></div>
					<div class="subscrpt-box-card__head subscrpt-box-card__head--tight">
						<div>
							<h3><?php esc_html_e( 'Categories', 'subscription-pro' ); ?></h3>
							<p data-subscrpt-pool-cat-count></p>
						</div>
						<input type="search" class="wpsubs-input subscrpt-box-search" data-subscrpt-pool-cat-find placeholder="<?php esc_attr_e( 'Find a category', 'subscription-pro' ); ?>" aria-label="<?php esc_attr_e( 'Find a category', 'subscription-pro' ); ?>" />
					</div>
					<div class="subscrpt-box-card__body">
						<?php if ( $categories ) : ?>
							<div class="subscrpt-box-cats">
								<?php foreach ( $categories as $subscrpt_cat ) : ?>
									<?php $subscrpt_on = in_array( $subscrpt_cat['id'], $subscrpt_pool['categories'], true ); ?>
									<label class="subscrpt-box-cat<?php echo $subscrpt_on ? ' is-on' : ''; ?>" data-name="<?php echo esc_attr( strtolower( $subscrpt_cat['name'] ) ); ?>">
										<input type="checkbox" data-subscrpt-pool-cat="<?php echo esc_attr( (string) $subscrpt_cat['id'] ); ?>" <?php checked( $subscrpt_on ); ?> />
										<span class="subscrpt-box-cat__name"><?php echo esc_html( $subscrpt_cat['name'] ); ?></span>
										<span class="subscrpt-box-cat__count"><?php echo esc_html( number_format_i18n( $subscrpt_cat['count'] ) ); ?></span>
									</label>
								<?php endforeach; ?>
							</div>
						<?php else : ?>
							<p class="subscrpt-box-hint"><?php esc_html_e( 'Your store has no product categories yet.', 'subscription-pro' ); ?></p>
						<?php endif; ?>
					</div>
				</div>

				<div data-subscrpt-pool-when="products" <?php echo BoxPool::SOURCE_PRODUCTS === $subscrpt_pool['source'] ? '' : 'hidden'; ?>>
					<div class="subscrpt-box-card__divider"></div>
					<div class="subscrpt-box-card__head">
						<div>
							<h3 data-subscrpt-pool-chosen-count></h3>
							<p><?php esc_html_e( 'Add or remove them in the product picker.', 'subscription-pro' ); ?></p>
						</div>
						<button type="button" class="wpsubs-btn wpsubs-btn--outline wpsubs-btn--sm" data-wpsubs-modal-open="subscrpt-pool-picker">
							<?php esc_html_e( 'Manage products', 'subscription-pro' ); ?>
						</button>
					</div>
				</div>
			</div>

			<div class="subscrpt-box-card" data-subscrpt-pool-list>
				<div class="subscrpt-box-card__head">
					<div>
						<h3><?php esc_html_e( 'Items in the box', 'subscription-pro' ); ?></h3>
						<p><?php esc_html_e( 'What customers choose from when they build their box.', 'subscription-pro' ); ?></p>
					</div>
					<div class="subscrpt-box-counts">
						<b data-subscrpt-pool-in>0</b><span><?php esc_html_e( 'in the box', 'subscription-pro' ); ?></span>
						<b data-subscrpt-pool-out data-subscrpt-pool-hide-products>0</b><span data-subscrpt-pool-hide-products><?php esc_html_e( 'left out', 'subscription-pro' ); ?></span>
					</div>
				</div>
				<div class="subscrpt-box-card__body">
					<div class="subscrpt-box-rule">
						<span class="subscrpt-box-rule__icon"><span class="dashicons dashicons-info-outline" aria-hidden="true"></span></span>
						<span data-subscrpt-pool-rule></span>
					</div>
				</div>

				<div class="subscrpt-box-ptools">
					<input type="search" class="wpsubs-input subscrpt-box-search" data-subscrpt-pool-search placeholder="<?php esc_attr_e( 'Search products', 'subscription-pro' ); ?>" aria-label="<?php esc_attr_e( 'Search products', 'subscription-pro' ); ?>" />
					<select class="wpsubs-input subscrpt-box-autoselect" data-subscrpt-pool-category aria-label="<?php esc_attr_e( 'Category', 'subscription-pro' ); ?>" hidden>
						<option value=""><?php esc_html_e( 'All categories', 'subscription-pro' ); ?></option>
					</select>
					<div class="subscrpt-box-seg" role="group" aria-label="<?php esc_attr_e( 'Show', 'subscription-pro' ); ?>" data-subscrpt-pool-hide-products>
						<button type="button" data-subscrpt-pool-view="all" aria-pressed="true"><?php esc_html_e( 'All', 'subscription-pro' ); ?> <span data-subscrpt-pool-view-count="all"></span></button>
						<button type="button" data-subscrpt-pool-view="in" aria-pressed="false"><?php esc_html_e( 'In the box', 'subscription-pro' ); ?> <span data-subscrpt-pool-view-count="in"></span></button>
						<button type="button" data-subscrpt-pool-view="out" aria-pressed="false"><?php esc_html_e( 'Left out', 'subscription-pro' ); ?> <span data-subscrpt-pool-view-count="out"></span></button>
					</div>
					<span class="subscrpt-box-spacer"></span>
					<button type="button" class="wpsubs-btn wpsubs-btn--outline wpsubs-btn--sm" data-subscrpt-pool-bulk hidden></button>
				</div>

				<div data-subscrpt-pool-rows aria-live="polite"></div>

				<div class="subscrpt-box-pager">
					<span data-subscrpt-pool-showing></span>
					<span class="subscrpt-box-row">
						<button type="button" class="wpsubs-btn wpsubs-btn--outline wpsubs-btn--sm" data-subscrpt-pool-page="-1" disabled><?php esc_html_e( 'Previous', 'subscription-pro' ); ?></button>
						<span data-subscrpt-pool-pages></span>
						<button type="button" class="wpsubs-btn wpsubs-btn--outline wpsubs-btn--sm" data-subscrpt-pool-page="1" disabled><?php esc_html_e( 'Next', 'subscription-pro' ); ?></button>
					</span>
				</div>
			</div>

			<label class="subscrpt-box-switchline" data-subscrpt-pool-hide-products>
				<input type="checkbox" class="wpsubs-toggle" data-subscrpt-pool-virtual <?php checked( $subscrpt_pool['virtual'] ); ?> />
				<span class="wpsubs-toggle-ui" aria-hidden="true"></span>
				<span><?php esc_html_e( 'Include downloadable and virtual products. They’re off by default because nothing ships for them.', 'subscription-pro' ); ?></span>
			</label>

			<?php require __DIR__ . '/modal-pool-picker.php'; ?>
		</div>

		<div class="subscrpt-box-card">
			<div class="subscrpt-box-card__head">
				<div>
					<h3><?php esc_html_e( 'Prefilled items', 'subscription-pro' ); ?></h3>
					<p><?php esc_html_e( 'Already in the box when a customer opens the builder, so they start from a full box and can swap anything. At renewal, a prefilled item also replaces a pick that has sold out.', 'subscription-pro' ); ?></p>
				</div>
			</div>
			<div class="subscrpt-box-card__body">
				<?php
				$subscrpt_rows  = $box['defaults'];
				$subscrpt_field = 'defaults';
				require __DIR__ . '/partial-item-rows.php';
				?>
			</div>
		</div>

	<?php else : ?>

		<div class="subscrpt-box-card">
			<div class="subscrpt-box-card__head">
				<div>
					<h3><?php esc_html_e( 'What you pack', 'subscription-pro' ); ?></h3>
					<p>
						<?php
						echo Box::TYPE_EDITION === $box['type']
							? esc_html__( 'The contents every subscriber receives, unless a published edition replaces them for a month.', 'subscription-pro' )
							: esc_html__( 'The contents every subscriber receives. A curated box ships the same to everyone.', 'subscription-pro' );
						?>
					</p>
				</div>
			</div>
			<div class="subscrpt-box-card__body">
				<?php
				$subscrpt_rows  = $box['items'];
				$subscrpt_field = 'items';
				require __DIR__ . '/partial-item-rows.php';
				?>
			</div>
		</div>

		<?php if ( Box::TYPE_EDITION === $box['type'] ) : ?>
			<div class="subscrpt-box-card">
				<div class="subscrpt-box-card__head">
					<div>
						<h3><?php esc_html_e( 'What an edition may swap in', 'subscription-pro' ); ?></h3>
						<p><?php esc_html_e( 'The pool the Editions tab picks from when you plan a month.', 'subscription-pro' ); ?></p>
					</div>
				</div>
				<div class="subscrpt-box-card__body">
					<?php require __DIR__ . '/partial-pool-picker.php'; ?>
				</div>
			</div>
		<?php endif; ?>

	<?php endif; ?>

	<?php require __DIR__ . '/partial-savebar.php'; ?>
</div>
