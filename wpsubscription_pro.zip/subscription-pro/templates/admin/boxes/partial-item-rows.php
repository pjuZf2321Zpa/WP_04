<?php
/**
 * A list of picks, with quantities.
 *
 * Used twice on the Contents tab — once for a build-your-own box's starting
 * picks, once for what a curated box packs — so everything here is keyed by
 * `$subscrpt_field` rather than by a fixed id.
 *
 * A row keeps the name it was saved with. That is the point of snapshotting it:
 * a deleted product still reads correctly instead of becoming a bare id.
 *
 * @var array  $subscrpt_rows  Rows: product_id, variation_id, qty, name, sku, missing.
 * @var string $subscrpt_field defaults | items.
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

defined( 'ABSPATH' ) || exit;

$subscrpt_list_id = 'subscrpt-box-items-' . $subscrpt_field;
?>
<div class="wpsubs-table-card" data-subscrpt-items="<?php echo esc_attr( $subscrpt_field ); ?>">
	<table class="wpsubs-table subscrpt-box-admin__table" style="max-width:none;margin:0;">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Product', 'subscription-pro' ); ?></th>
				<th class="subscrpt-box-admin__qty-col"><?php esc_html_e( 'Quantity', 'subscription-pro' ); ?></th>
				<th style="width:48px;"></th>
			</tr>
		</thead>
		<tbody id="<?php echo esc_attr( $subscrpt_list_id ); ?>" data-subscrpt-item-body>

			<?php foreach ( $subscrpt_rows as $subscrpt_row ) : ?>
				<tr
					data-subscrpt-item-row
					data-product-id="<?php echo esc_attr( $subscrpt_row['product_id'] ); ?>"
					data-variation-id="<?php echo esc_attr( $subscrpt_row['variation_id'] ); ?>"
				>
					<td>
						<select
							class="wc-product-search"
							style="width:100%;"
							data-subscrpt-item-product
							data-placeholder="<?php esc_attr_e( 'Search for a product…', 'subscription-pro' ); ?>"
							data-action="woocommerce_json_search_products_and_variations"
							aria-label="<?php esc_attr_e( 'Product', 'subscription-pro' ); ?>"
						>
							<option value="<?php echo esc_attr( $subscrpt_row['variation_id'] ? $subscrpt_row['variation_id'] : $subscrpt_row['product_id'] ); ?>" selected="selected">
								<?php
								echo esc_html( $subscrpt_row['name'] );
								echo $subscrpt_row['sku'] ? ' (' . esc_html( $subscrpt_row['sku'] ) . ')' : '';
								?>
							</option>
						</select>
						<?php if ( ! empty( $subscrpt_row['missing'] ) ) : ?>
							<span class="wpsubs-badge wpsubs-badge--draft" style="margin-top:4px;"><?php esc_html_e( 'No longer in the catalogue', 'subscription-pro' ); ?></span>
						<?php endif; ?>
					</td>
					<td>
						<input
							type="number"
							min="1"
							step="1"
							class="wpsubs-input"
							style="width:80px;"
							data-subscrpt-item-qty
							value="<?php echo esc_attr( $subscrpt_row['qty'] ); ?>"
							aria-label="<?php echo esc_attr( sprintf( /* translators: %s: product name. */ __( 'Quantity of %s', 'subscription-pro' ), $subscrpt_row['name'] ) ); ?>"
						/>
					</td>
					<td>
						<button
							type="button"
							class="wpsubs-icon-action wpsubs-icon-action--danger"
							data-subscrpt-item-remove
							title="<?php esc_attr_e( 'Remove', 'subscription-pro' ); ?>"
							aria-label="<?php echo esc_attr( sprintf( /* translators: %s: product name. */ __( 'Remove %s', 'subscription-pro' ), $subscrpt_row['name'] ) ); ?>"
						>
							<span class="dashicons dashicons-no-alt" aria-hidden="true"></span>
						</button>
					</td>
				</tr>
			<?php endforeach; ?>

			<tr data-subscrpt-item-empty <?php echo $subscrpt_rows ? 'hidden' : ''; ?>>
				<td colspan="3" style="color:var(--wpsubs-text-subtle);font-size:13px;">
					<?php esc_html_e( 'Nothing here yet. Use Add product to start a row.', 'subscription-pro' ); ?>
				</td>
			</tr>

		</tbody>
	</table>
</div>

<p style="margin:10px 0 0;">
	<button type="button" class="wpsubs-btn wpsubs-btn--outline" data-subscrpt-item-add="<?php echo esc_attr( $subscrpt_field ); ?>">
		<?php esc_html_e( '+ Add product', 'subscription-pro' ); ?>
	</button>
</p>

<?php // A blank row, cloned by "Add product"; its select is enhanced once it is in the page. ?>
<template data-subscrpt-item-template="<?php echo esc_attr( $subscrpt_field ); ?>">
	<tr data-subscrpt-item-row data-product-id="0" data-variation-id="0">
		<td>
			<select
				class="wc-product-search"
				style="width:100%;"
				data-subscrpt-item-product
				data-placeholder="<?php esc_attr_e( 'Search for a product…', 'subscription-pro' ); ?>"
				data-action="woocommerce_json_search_products_and_variations"
				aria-label="<?php esc_attr_e( 'Product', 'subscription-pro' ); ?>"
			></select>
		</td>
		<td>
			<input type="number" min="1" step="1" class="wpsubs-input" style="width:80px;" data-subscrpt-item-qty value="1" aria-label="<?php esc_attr_e( 'Quantity', 'subscription-pro' ); ?>" />
		</td>
		<td>
			<button type="button" class="wpsubs-icon-action wpsubs-icon-action--danger" data-subscrpt-item-remove title="<?php esc_attr_e( 'Remove', 'subscription-pro' ); ?>" aria-label="<?php esc_attr_e( 'Remove', 'subscription-pro' ); ?>">
				<span class="dashicons dashicons-no-alt" aria-hidden="true"></span>
			</button>
		</td>
	</tr>
</template>
