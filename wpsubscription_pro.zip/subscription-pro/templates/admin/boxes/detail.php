<?php
/**
 * One box.
 *
 * Every tab sits in the same workspace: what the box is, the tabs, and the
 * Selling panel, which always shows the product, its price and its durations.
 * The tabs are links rather than client-side panels: the router already reads
 * `dtab`, and a reload is honest about what was saved.
 *
 * @var array    $box         BoxPresenter::find().
 * @var int      $box_id      Box id.
 * @var string[] $tabs        The tabs this box has; Boxes::detail_tabs().
 * @var string   $dtab        contents | durations | pricing | rules | together | editions.
 * @var array    $pairs       Top co-purchased pairs, on the Together tab.
 * @var array    $cycles      Edition cycles, on the Editions tab.
 * @var array    $choices     Pool products as id => name, on the Editions tab.
 * @var array    $categories  Product categories, on the Box items tab.
 * @var array    $plan_groups Shared plan groups, on the Durations tab.
 * @var string   $position    Where the Together section sits on a product page.
 * @var int      $live_subs   Subscriptions still renewing through the box's product.
 * @var string   $list_url    The Boxes list.
 * @var bool     $updated     Whether something was just saved.
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

defined( 'ABSPATH' ) || exit;

use SpringDevs\SubscriptionPro\Illuminate\Box\Box;

$subscrpt_tabs = array(
	'contents'  => array( __( 'Box items', 'subscription-pro' ), $box['item_count'] ),
	'durations' => array( __( 'Durations', 'subscription-pro' ), count( $box['offered'] ) ),
	'pricing'   => array( __( 'Pricing', 'subscription-pro' ), null ),
	'rules'     => array( __( 'Rules', 'subscription-pro' ), null ),
	'together'  => array( __( 'Together', 'subscription-pro' ), null ),
	'editions'  => array( __( 'Editions', 'subscription-pro' ), null ),
);
$subscrpt_tabs = array_intersect_key( $subscrpt_tabs, array_flip( $tabs ) );

$subscrpt_detail_url = add_query_arg(
	array(
		'view' => 'detail',
		'box'  => $box_id,
	),
	$list_url
);
$subscrpt_offered    = wp_list_pluck( $box['offered'], 'name' );
$subscrpt_durations  = count( $subscrpt_offered ) > 2
	/* translators: %d: number of durations offered. */
	? sprintf( _n( '%d duration', '%d durations', count( $subscrpt_offered ), 'subscription-pro' ), count( $subscrpt_offered ) )
	: implode( ', ', $subscrpt_offered );
$subscrpt_fix_urls   = array(
	'items'     => add_query_arg( 'dtab', 'contents', $subscrpt_detail_url ),
	'durations' => add_query_arg( 'dtab', 'durations', $subscrpt_detail_url ),
	'product'   => '',
);
?>
<div class="wp-subscription-admin-content list-page subscrpt-box-ws">

	<?php if ( $updated ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Saved.', 'subscription-pro' ); ?></p></div>
	<?php endif; ?>

	<div
		data-subscrpt-box="<?php echo esc_attr( $box_id ); ?>"
		data-box-type="<?php echo esc_attr( $box['type'] ); ?>"
		data-box-status="<?php echo esc_attr( $box['status'] ); ?>"
	>

		<p class="subscrpt-box-back">
			<a href="<?php echo esc_url( $list_url ); ?>">&larr; <?php esc_html_e( 'All boxes', 'subscription-pro' ); ?></a>
		</p>

		<div class="subscrpt-box-head">
			<div class="subscrpt-box-head__main">
				<div class="subscrpt-box-head__title" data-subscrpt-box-rename>
					<h1 data-subscrpt-box-rename-display><?php echo esc_html( $box['name'] ); ?></h1>
					<button type="button" class="wpsubs-icon-action" data-subscrpt-box-rename-open aria-label="<?php esc_attr_e( 'Rename box', 'subscription-pro' ); ?>">
						<span class="dashicons dashicons-edit" aria-hidden="true"></span>
					</button>
					<span class="subscrpt-box-head__rename" data-subscrpt-box-rename-form hidden>
						<input type="text" class="wpsubs-input" data-subscrpt-box-rename-input value="<?php echo esc_attr( $box['name'] ); ?>" aria-label="<?php esc_attr_e( 'Box name', 'subscription-pro' ); ?>" />
						<button type="button" class="wpsubs-btn wpsubs-btn--primary wpsubs-btn--sm" data-subscrpt-box-rename-save><?php esc_html_e( 'Save', 'subscription-pro' ); ?></button>
						<button type="button" class="wpsubs-btn wpsubs-btn--outline wpsubs-btn--sm" data-subscrpt-box-rename-cancel><?php esc_html_e( 'Cancel', 'subscription-pro' ); ?></button>
					</span>
					<span class="subscrpt-box-dot<?php echo $box['is_draft'] ? ' subscrpt-box-dot--draft' : ''; ?>">
						<?php echo $box['is_draft'] ? esc_html__( 'Draft', 'subscription-pro' ) : esc_html__( 'Active', 'subscription-pro' ); ?>
					</span>
				</div>

				<div class="subscrpt-box-head__meta">
					<span><span class="dashicons <?php echo esc_attr( $box['type_icon'] ); ?>" aria-hidden="true"></span><?php echo esc_html( $box['type_label'] ); ?></span>
					<span><span class="dashicons dashicons-list-view" aria-hidden="true"></span><?php echo esc_html( $box['source_label'] ); ?></span>
					<span title="<?php echo esc_attr( implode( ', ', $subscrpt_offered ) ); ?>"><span class="dashicons dashicons-calendar-alt" aria-hidden="true"></span><?php echo esc_html( $subscrpt_durations ? $subscrpt_durations : __( 'No durations', 'subscription-pro' ) ); ?></span>
					<span><span class="dashicons dashicons-store" aria-hidden="true"></span>
						<?php
						echo $box['product']
							/* translators: %s: product name. */
							? esc_html( sprintf( __( 'Sold as %s', 'subscription-pro' ), $box['product']['name'] ) )
							: esc_html__( 'No product', 'subscription-pro' );
						?>
					</span>
				</div>
			</div>

			<div class="subscrpt-box-head__actions">
				<div class="subscrpt-box-pop">
					<button type="button" class="wpsubs-btn wpsubs-btn--outline subscrpt-box-iconbtn" data-subscrpt-menu-toggle="box" aria-expanded="false" aria-label="<?php esc_attr_e( 'More actions', 'subscription-pro' ); ?>">
						<span class="dashicons dashicons-ellipsis" aria-hidden="true"></span>
					</button>
					<div class="subscrpt-box-menu" data-subscrpt-menu="box" role="menu" hidden>
						<button type="button" role="menuitem" data-subscrpt-duplicate>
							<span class="dashicons dashicons-admin-page" aria-hidden="true"></span>
							<span><b><?php esc_html_e( 'Duplicate box', 'subscription-pro' ); ?></b><small><?php esc_html_e( 'A draft copy with no product.', 'subscription-pro' ); ?></small></span>
						</button>
						<div class="subscrpt-box-menu__sep"></div>
						<button
							type="button"
							role="menuitem"
							class="is-danger"
							data-subscrpt-delete-open="<?php echo esc_attr( $box_id ); ?>"
							data-box-name="<?php echo esc_attr( $box['name'] ); ?>"
							data-product-name="<?php echo esc_attr( $box['product'] && ! $box['product']['missing'] ? $box['product']['name'] : '' ); ?>"
							data-product-meta="<?php echo esc_attr( $box['product'] ? '#' . $box['product']['id'] . ' · ' . $box['product']['status_label'] : '' ); ?>"
							data-live-subs="<?php echo esc_attr( (string) $live_subs ); ?>"
						>
							<span class="dashicons dashicons-trash" aria-hidden="true"></span>
							<span><b><?php esc_html_e( 'Delete box…', 'subscription-pro' ); ?></b><small><?php esc_html_e( 'Asks what happens to its product', 'subscription-pro' ); ?></small></span>
						</button>
					</div>
				</div>

				<div class="subscrpt-box-pop">
					<?php // Publishing is the step forward; drafting takes the box off sale, so it does not get the primary colour. ?>
					<button
						type="button"
						class="wpsubs-btn <?php echo $box['is_draft'] ? 'wpsubs-btn--primary' : 'wpsubs-btn--outline'; ?>"
						data-subscrpt-publish="<?php echo $box['is_draft'] ? 'active' : 'draft'; ?>"
						data-missing="<?php echo esc_attr( (string) count( $box['missing'] ) ); ?>"
						aria-expanded="false"
					>
						<span class="dashicons <?php echo $box['is_draft'] ? 'dashicons-visibility' : 'dashicons-hidden'; ?>" aria-hidden="true"></span>
						<?php echo $box['is_draft'] ? esc_html__( 'Publish box', 'subscription-pro' ) : esc_html__( 'Move to draft', 'subscription-pro' ); ?>
					</button>
					<div class="subscrpt-box-menu subscrpt-box-menu--publish" data-subscrpt-menu="publish" role="dialog" aria-label="<?php esc_attr_e( 'Not ready to publish', 'subscription-pro' ); ?>" hidden>
						<div class="subscrpt-box-menu__head">
							<b><?php esc_html_e( 'Not ready to publish', 'subscription-pro' ); ?></b>
							<small><?php echo 1 === count( $box['missing'] ) ? esc_html__( 'Finish this first:', 'subscription-pro' ) : esc_html__( 'Finish these first:', 'subscription-pro' ); ?></small>
						</div>
						<?php foreach ( $box['missing'] as $subscrpt_missing ) : ?>
							<?php if ( 'product' === $subscrpt_missing['key'] ) : ?>
								<button type="button" class="subscrpt-box-miss" data-subscrpt-fix-product>
							<?php else : ?>
								<a class="subscrpt-box-miss" href="<?php echo esc_url( $subscrpt_fix_urls[ $subscrpt_missing['key'] ] ); ?>">
							<?php endif; ?>
								<span><b><?php echo esc_html( $subscrpt_missing['title'] ); ?></b><small><?php echo esc_html( $subscrpt_missing['text'] ); ?></small></span>
								<span class="subscrpt-box-miss__go"><?php esc_html_e( 'Fix', 'subscription-pro' ); ?></span>
							<?php echo 'product' === $subscrpt_missing['key'] ? '</button>' : '</a>'; ?>
						<?php endforeach; ?>
					</div>
				</div>
			</div>
		</div>

		<nav class="subscrpt-box-tabs" role="tablist" aria-label="<?php esc_attr_e( 'Box sections', 'subscription-pro' ); ?>">
			<?php foreach ( $subscrpt_tabs as $subscrpt_key => $subscrpt_tab ) : ?>
				<a
					class="subscrpt-box-tabs__tab<?php echo $dtab === $subscrpt_key ? ' is-active' : ''; ?>"
					href="<?php echo esc_url( add_query_arg( 'dtab', $subscrpt_key, $subscrpt_detail_url ) ); ?>"
					role="tab"
					aria-selected="<?php echo $dtab === $subscrpt_key ? 'true' : 'false'; ?>"
				>
					<?php echo esc_html( $subscrpt_tab[0] ); ?>
					<?php if ( null !== $subscrpt_tab[1] ) : ?>
						<span class="subscrpt-box-tabs__count"><?php echo esc_html( number_format_i18n( $subscrpt_tab[1] ) ); ?></span>
					<?php endif; ?>
				</a>
			<?php endforeach; ?>
		</nav>

		<div class="subscrpt-box-grid">
			<div class="subscrpt-box-grid__main" role="tabpanel">
				<?php
				$subscrpt_partial = __DIR__ . '/tab-' . $dtab . '.php';

				if ( file_exists( $subscrpt_partial ) ) {
					require $subscrpt_partial;
				}
				?>
			</div>

			<?php require __DIR__ . '/partial-selling.php'; ?>
		</div>

	</div>
</div>

<?php
require __DIR__ . '/modal-delete.php';
require __DIR__ . '/modal-link-product.php';
