<?php
/**
 * Pool entries the storefront will refuse.
 *
 * A pool can list a product the builder then skips — one that sells a box of
 * its own, one that is out of stock, one with no price — and until this existed
 * nothing said so anywhere. The merchant saw the product sitting in the list
 * and the shopper saw an empty grid reading "nothing is available for this
 * box", which is a symptom, not a diagnosis.
 *
 * @var array $box BoxPresenter::find().
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

defined( 'ABSPATH' ) || exit;

if ( empty( $box['pool_skipped'] ) ) {
	return;
}
?>
<div style="margin-top:10px;padding:10px 12px;border-radius:6px;background:#fcf9e8;border-left:4px solid #dba617;">
	<strong style="display:block;margin-bottom:6px;font-size:12.5px;">
		<?php
		printf(
			esc_html(
				/* translators: %d: how many products the builder will skip. */
				_n(
					'%d of these will not be offered',
					'%d of these will not be offered',
					count( $box['pool_skipped'] ),
					'subscription-pro'
				)
			),
			count( $box['pool_skipped'] )
		);
		?>
	</strong>

	<ul style="margin:0;padding-left:18px;font-size:12.5px;color:#50575e;">
		<?php foreach ( $box['pool_skipped'] as $subscrpt_skipped ) : ?>
			<li style="margin:0 0 2px;">
				<strong><?php echo esc_html( $subscrpt_skipped['name'] ); ?></strong>
				&mdash; <?php echo esc_html( $subscrpt_skipped['reason'] ); ?>
			</li>
		<?php endforeach; ?>
	</ul>
</div>
