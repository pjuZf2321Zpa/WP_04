<?php
/**
 * Box detail — Rules tab.
 *
 * Box size, what subscribers can change, and what happens when a pick sells
 * out. These are the rules a subscription copies at sign-up, so the wording
 * says what the subscriber experiences rather than naming the setting. An
 * option that only matters while a switch is on sits under that switch.
 *
 * @var array $box    BoxPresenter::find().
 * @var int   $box_id Box id.
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

defined( 'ABSPATH' ) || exit;

use SpringDevs\SubscriptionPro\Illuminate\Box\Box;

$subscrpt_rules = $box['rules'];

// A curated box ships the same to everyone: nobody picks or changes it, and it
// has no prefilled items or pool to replace a sold-out item from. Its rules are
// only the lock and skipping.
$subscrpt_is_curated = Box::TYPE_CURATED === $box['type'];

$subscrpt_lock = static function () use ( $subscrpt_rules ): void {
	?>
	<span class="subscrpt-box-tsub" data-subscrpt-rule-sub>
		<label for="subscrpt-box-lock-days"><?php esc_html_e( 'Lock', 'subscription-pro' ); ?></label>
		<input type="number" min="0" step="1" id="subscrpt-box-lock-days" class="wpsubs-input subscrpt-box-num" data-subscrpt-box-field="lock_days" value="<?php echo esc_attr( $subscrpt_rules['lock_days'] ); ?>" />
		<span><?php esc_html_e( 'days before it ships', 'subscription-pro' ); ?></span>
	</span>
	<?php
};
?>
<div data-subscrpt-box-form="rules">

	<?php if ( ! $subscrpt_is_curated ) : ?>
		<div class="subscrpt-box-card">
			<div class="subscrpt-box-card__head">
				<div>
					<h3><?php esc_html_e( 'Box size', 'subscription-pro' ); ?></h3>
					<p><?php esc_html_e( 'Customers can’t check out until their box fits. Use 0 for no limit.', 'subscription-pro' ); ?></p>
				</div>
			</div>
			<div class="subscrpt-box-card__body">
				<div class="subscrpt-box-fields3">
					<div class="subscrpt-box-field">
						<label for="subscrpt-box-size-min"><?php esc_html_e( 'Minimum items', 'subscription-pro' ); ?></label>
						<input type="number" min="0" step="1" id="subscrpt-box-size-min" class="wpsubs-input" data-subscrpt-box-field="size_min" value="<?php echo esc_attr( $box['size']['min'] ); ?>" />
					</div>
					<div class="subscrpt-box-field">
						<label for="subscrpt-box-size-max"><?php esc_html_e( 'Maximum items', 'subscription-pro' ); ?></label>
						<input type="number" min="0" step="1" id="subscrpt-box-size-max" class="wpsubs-input" data-subscrpt-box-field="size_max" value="<?php echo esc_attr( $box['size']['max'] ); ?>" />
					</div>
					<div class="subscrpt-box-field">
						<label for="subscrpt-box-max-per-item"><?php esc_html_e( 'Most of one product', 'subscription-pro' ); ?></label>
						<input type="number" min="0" step="1" id="subscrpt-box-max-per-item" class="wpsubs-input" data-subscrpt-box-field="max_per_item" value="<?php echo esc_attr( $subscrpt_rules['max_per_item'] ); ?>" />
					</div>
				</div>
			</div>
		</div>
	<?php endif; ?>

	<div class="subscrpt-box-card">
		<div class="subscrpt-box-card__head">
			<div>
				<h3><?php esc_html_e( 'Changing and skipping', 'subscription-pro' ); ?></h3>
				<p><?php esc_html_e( 'What subscribers can do from My Account between deliveries.', 'subscription-pro' ); ?></p>
			</div>
		</div>

		<?php if ( ! $subscrpt_is_curated ) : ?>
			<div class="subscrpt-box-trow" data-subscrpt-rule>
				<div>
					<b><?php esc_html_e( 'Change the next box', 'subscription-pro' ); ?></b>
					<small><?php esc_html_e( 'Customers swap items until the box is locked.', 'subscription-pro' ); ?></small>
					<?php $subscrpt_lock(); ?>
				</div>
				<label class="subscrpt-box-switch">
					<input type="checkbox" class="wpsubs-toggle" data-subscrpt-box-field="allow_edit" data-subscrpt-rule-toggle <?php checked( ! empty( $subscrpt_rules['allow_edit'] ) ); ?> aria-label="<?php esc_attr_e( 'Customers can change the next box', 'subscription-pro' ); ?>" />
					<span class="wpsubs-toggle-ui" aria-hidden="true"></span>
				</label>
			</div>
		<?php endif; ?>

		<div class="subscrpt-box-trow" data-subscrpt-rule>
			<div>
				<b><?php esc_html_e( 'Skip a delivery', 'subscription-pro' ); ?></b>
				<small><?php esc_html_e( 'Customers skip one delivery before the box is locked. The next renewal moves on by one period.', 'subscription-pro' ); ?></small>
				<span class="subscrpt-box-tsub" data-subscrpt-rule-sub>
					<label for="subscrpt-box-max-skips"><?php esc_html_e( 'At most', 'subscription-pro' ); ?></label>
					<input type="number" min="0" step="1" id="subscrpt-box-max-skips" class="wpsubs-input subscrpt-box-num" data-subscrpt-box-field="max_skips" value="<?php echo esc_attr( $subscrpt_rules['max_skips'] ); ?>" />
					<span><?php esc_html_e( 'in a row (0 for no limit)', 'subscription-pro' ); ?></span>
				</span>
				<?php
				if ( $subscrpt_is_curated ) {
					$subscrpt_lock();
				}
				?>
			</div>
			<label class="subscrpt-box-switch">
				<input type="checkbox" class="wpsubs-toggle" data-subscrpt-box-field="allow_skip" data-subscrpt-rule-toggle <?php checked( ! empty( $subscrpt_rules['allow_skip'] ) ); ?> aria-label="<?php esc_attr_e( 'Customers can skip a delivery', 'subscription-pro' ); ?>" />
				<span class="wpsubs-toggle-ui" aria-hidden="true"></span>
			</label>
		</div>
	</div>

	<?php if ( ! $subscrpt_is_curated ) : ?>
		<div class="subscrpt-box-card">
			<div class="subscrpt-box-card__head">
				<div>
					<h3><?php esc_html_e( 'What happens when a pick sells out?', 'subscription-pro' ); ?></h3>
					<p><?php esc_html_e( 'Choose one. It’s checked when the box is packed for renewal.', 'subscription-pro' ); ?></p>
				</div>
			</div>
			<div class="subscrpt-box-card__body">
				<div class="subscrpt-box-choices subscrpt-box-choices--2" role="radiogroup">
					<label class="subscrpt-box-choice subscrpt-box-choice--stack<?php echo 'replace' === $subscrpt_rules['stock_rule'] ? ' is-on' : ''; ?>">
						<input type="radio" name="subscrpt-stock-rule" value="replace" data-subscrpt-box-field="stock_rule" <?php checked( 'replace', $subscrpt_rules['stock_rule'] ); ?> />
						<span class="subscrpt-box-choice__icon"><span class="dashicons dashicons-update" aria-hidden="true"></span></span>
						<span><b><?php esc_html_e( 'Swap in a prefilled item', 'subscription-pro' ); ?></b><small><?php esc_html_e( 'Uses your Prefilled items list from Box items. If none of those is in stock, the pick is dropped.', 'subscription-pro' ); ?></small></span>
					</label>
					<label class="subscrpt-box-choice subscrpt-box-choice--stack<?php echo 'drop' === $subscrpt_rules['stock_rule'] ? ' is-on' : ''; ?>">
						<input type="radio" name="subscrpt-stock-rule" value="drop" data-subscrpt-box-field="stock_rule" <?php checked( 'drop', $subscrpt_rules['stock_rule'] ); ?> />
						<span class="subscrpt-box-choice__icon"><span class="dashicons dashicons-no-alt" aria-hidden="true"></span></span>
						<span><b><?php esc_html_e( 'Leave it out', 'subscription-pro' ); ?></b><small><?php esc_html_e( 'The box ships with one item fewer, and the customer pays less if the box is priced by what is picked.', 'subscription-pro' ); ?></small></span>
					</label>
				</div>
			</div>
		</div>
	<?php endif; ?>

	<?php require __DIR__ . '/partial-savebar.php'; ?>
</div>
