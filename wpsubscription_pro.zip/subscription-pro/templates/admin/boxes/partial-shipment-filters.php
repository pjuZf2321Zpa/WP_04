<?php
/**
 * Which boxes am I looking at?
 *
 * A warehouse works a month at a time, so the month is the first filter and
 * everything else narrows it. The counts are the point of the row: a merchant
 * should see "18 scheduled, 4 packing, 2 failed" before reading a single line,
 * and be one click from the two that failed.
 *
 * These are links rather than a form on purpose — every filter is then a URL
 * that can be bookmarked, shared with whoever is packing, and reloaded after
 * a bulk action without re-choosing anything.
 *
 * @var string $tab      upcoming | picks.
 * @var string $cycle    The cycle being shown.
 * @var array  $cycles   Cycles worth offering.
 * @var array  $counts   Per-status counts for this cycle.
 * @var array  $box_list id => title of every box.
 * @var int    $box_of   Box filter, or 0.
 * @var string $status   Status filter, or ''.
 * @var string $search   Customer search.
 * @var string $list_url This screen.
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

defined( 'ABSPATH' ) || exit;

$subscrpt_base = add_query_arg( 'tab', $tab, $list_url );

/**
 * A filter URL with one argument changed.
 *
 * @param string $base Base URL.
 * @param array  $args Arguments to set; false removes one.
 *
 * @return string
 */
$subscrpt_filter_url = static function ( $base, array $args ) {
	return add_query_arg( $args, $base );
};

$subscrpt_total = 0;

foreach ( $counts as $subscrpt_count ) {
	$subscrpt_total += (int) $subscrpt_count['count'];
}
?>
<div class="subscrpt-boxes__picker" style="align-items:flex-end;flex-wrap:wrap;">

	<div>
		<label for="subscrpt-cycle" style="display:block;margin:0 0 4px;font-size:12px;color:var(--wpsubs-text-muted);">
			<?php esc_html_e( 'Month', 'subscription-pro' ); ?>
		</label>
		<select
			id="subscrpt-cycle"
			class="wpsubs-input"
			onchange="window.location = this.value;"
		>
			<?php foreach ( $cycles as $subscrpt_cycle ) : ?>
				<option
					value="
					<?php
					echo esc_url(
						$subscrpt_filter_url(
							$subscrpt_base,
							array(
								'cycle'  => $subscrpt_cycle['key'],
								'status' => false,
							)
						)
					);
					?>
							"
					<?php selected( $subscrpt_cycle['key'], $cycle ); ?>
				>
					<?php echo esc_html( $subscrpt_cycle['label'] ); ?>
				</option>
			<?php endforeach; ?>
		</select>
	</div>

	<?php if ( ! empty( $box_list ) ) : ?>
		<div>
			<label for="subscrpt-box-filter" style="display:block;margin:0 0 4px;font-size:12px;color:var(--wpsubs-text-muted);">
				<?php esc_html_e( 'Box', 'subscription-pro' ); ?>
			</label>
			<select
				id="subscrpt-box-filter"
				class="wpsubs-input"
				onchange="window.location = this.value;"
			>
				<option value="
				<?php
				echo esc_url(
					$subscrpt_filter_url(
						$subscrpt_base,
						array(
							'cycle'  => $cycle,
							'box_id' => false,
						)
					)
				);
				?>
								">
					<?php esc_html_e( 'Every box', 'subscription-pro' ); ?>
				</option>
				<?php foreach ( $box_list as $subscrpt_box_id => $subscrpt_box_title ) : ?>
					<option
						value="
						<?php
						echo esc_url(
							$subscrpt_filter_url(
								$subscrpt_base,
								array(
									'cycle'  => $cycle,
									'box_id' => $subscrpt_box_id,
								)
							)
						);
						?>
								"
						<?php selected( (int) $subscrpt_box_id, (int) $box_of ); ?>
					>
						<?php echo esc_html( $subscrpt_box_title ); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</div>
	<?php endif; ?>

	<form method="get" action="<?php echo esc_url( $list_url ); ?>" style="display:flex;gap:6px;align-items:flex-end;">
		<input type="hidden" name="page" value="<?php echo esc_attr( SpringDevs\SubscriptionPro\Admin\Boxes::PAGE ); ?>" />
		<input type="hidden" name="tab" value="<?php echo esc_attr( $tab ); ?>" />
		<input type="hidden" name="cycle" value="<?php echo esc_attr( $cycle ); ?>" />
		<?php if ( $box_of ) : ?>
			<input type="hidden" name="box_id" value="<?php echo esc_attr( $box_of ); ?>" />
		<?php endif; ?>
		<div>
			<label for="subscrpt-shipment-search" style="display:block;margin:0 0 4px;font-size:12px;color:var(--wpsubs-text-muted);">
				<?php esc_html_e( 'Customer', 'subscription-pro' ); ?>
			</label>
			<input
				type="search"
				id="subscrpt-shipment-search"
				class="wpsubs-input"
				name="s"
				value="<?php echo esc_attr( $search ); ?>"
				placeholder="<?php esc_attr_e( 'Name or email…', 'subscription-pro' ); ?>"
			/>
		</div>
		<button type="submit" class="wpsubs-btn wpsubs-btn--outline"><?php esc_html_e( 'Search', 'subscription-pro' ); ?></button>
	</form>

	<span style="flex:1 1 auto;"></span>
</div>

<?php if ( $subscrpt_total ) : ?>
	<div class="subscrpt-boxes__states">
		<a
			class="subscrpt-boxes__state<?php echo '' === $status ? ' is-current' : ''; ?>"
			href="
			<?php
			echo esc_url(
				$subscrpt_filter_url(
					$subscrpt_base,
					array(
						'cycle'  => $cycle,
						'status' => false,
					)
				)
			);
			?>
			"
		>
			<?php
			printf(
				/* translators: %d: how many boxes are in this month altogether. */
				esc_html( _n( '%d box', '%d boxes', $subscrpt_total, 'subscription-pro' ) ),
				(int) $subscrpt_total
			);
			?>
		</a>

		<?php foreach ( $counts as $subscrpt_count ) : ?>
			<?php if ( ! $subscrpt_count['count'] ) : ?>
				<?php continue; ?>
			<?php endif; ?>
			<a
				class="subscrpt-boxes__state<?php echo $status === $subscrpt_count['status'] ? ' is-current' : ''; ?>"
				href="
				<?php
				echo esc_url(
					$subscrpt_filter_url(
						$subscrpt_base,
						array(
							'cycle'  => $cycle,
							'status' => $subscrpt_count['status'],
						)
					)
				);
				?>
				"
			>
				<span class="subscrpt-boxes__badge is-<?php echo esc_attr( $subscrpt_count['status'] ); ?>">
					<?php echo esc_html( $subscrpt_count['label'] ); ?>
				</span>
				<strong><?php echo esc_html( $subscrpt_count['count'] ); ?></strong>
			</a>
		<?php endforeach; ?>
	</div>
<?php endif; ?>
