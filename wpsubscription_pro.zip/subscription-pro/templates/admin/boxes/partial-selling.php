<?php
/**
 * The Selling panel beside every tab of a box.
 *
 * One box, one product, so the product lives here rather than on a tab of its
 * own: what sells the box, what it costs, what is in it, and how often it ships.
 *
 * @var array $box    BoxPresenter::find().
 * @var int   $box_id Box id.
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

defined( 'ABSPATH' ) || exit;

use SpringDevs\SubscriptionPro\Illuminate\Box\Box;

$subscrpt_product = $box['product'];
$subscrpt_initial = static function ( string $name ): string {
	$letters = '';

	foreach ( array_slice( preg_split( '/\s+/', trim( $name ) ), 0, 2 ) as $word ) {
		$letters .= function_exists( 'mb_substr' ) ? mb_substr( $word, 0, 1 ) : substr( $word, 0, 1 );
	}

	return function_exists( 'mb_strtoupper' ) ? mb_strtoupper( $letters ) : strtoupper( $letters );
};
?>
<aside class="subscrpt-box-rail" aria-label="<?php esc_attr_e( 'Selling', 'subscription-pro' ); ?>">
	<div class="subscrpt-box-card">
		<div class="subscrpt-box-card__head subscrpt-box-card__head--tight">
			<span class="subscrpt-box-eyebrow"><?php esc_html_e( 'Selling', 'subscription-pro' ); ?></span>
			<span class="subscrpt-box-dot<?php echo $box['is_draft'] ? ' subscrpt-box-dot--draft' : ''; ?>">
				<?php echo $box['is_draft'] ? esc_html__( 'Not on sale', 'subscription-pro' ) : esc_html__( 'On sale', 'subscription-pro' ); ?>
			</span>
		</div>

		<div class="subscrpt-box-card__body subscrpt-box-rail__body">

			<div class="subscrpt-box-prodcard" id="subscrpt-box-prodcard">
				<?php if ( $subscrpt_product && ! $subscrpt_product['missing'] ) : ?>
					<div class="subscrpt-box-prod">
						<span class="subscrpt-box-thumb">
							<?php if ( $subscrpt_product['image'] ) : ?>
								<img src="<?php echo esc_url( $subscrpt_product['image'] ); ?>" alt="" />
							<?php else : ?>
								<?php echo esc_html( $subscrpt_initial( $subscrpt_product['name'] ) ); ?>
							<?php endif; ?>
						</span>
						<span class="subscrpt-box-prod__text">
							<span class="subscrpt-box-prod__name"><?php echo esc_html( $subscrpt_product['name'] ); ?></span>
							<span class="subscrpt-box-prod__meta">
								<span class="subscrpt-box-wc"><span class="dashicons dashicons-store" aria-hidden="true"></span><?php esc_html_e( 'WooCommerce product', 'subscription-pro' ); ?></span>
								<span>#<?php echo esc_html( (string) $subscrpt_product['id'] ); ?> &middot; <?php echo esc_html( $subscrpt_product['status_label'] ); ?></span>
							</span>
						</span>
					</div>
					<div class="subscrpt-box-prodcard__actions">
						<a class="wpsubs-btn wpsubs-btn--outline wpsubs-btn--sm" href="<?php echo esc_url( $subscrpt_product['edit_url'] ); ?>" target="_blank" rel="noopener">
							<span class="dashicons dashicons-external" aria-hidden="true"></span><?php esc_html_e( 'Edit in WooCommerce', 'subscription-pro' ); ?>
						</a>
						<div class="subscrpt-box-pop">
							<button type="button" class="wpsubs-btn wpsubs-btn--outline wpsubs-btn--sm" data-subscrpt-menu-toggle="product" aria-expanded="false">
								<?php esc_html_e( 'Change', 'subscription-pro' ); ?>
								<span class="dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span>
							</button>
							<div class="subscrpt-box-menu subscrpt-box-menu--wide" data-subscrpt-menu="product" role="menu" hidden>
								<button type="button" role="menuitem" data-wpsubs-modal-open="subscrpt-link-product">
									<span class="dashicons dashicons-admin-links" aria-hidden="true"></span>
									<span><b><?php esc_html_e( 'Use another product', 'subscription-pro' ); ?></b><small><?php esc_html_e( 'Search your WooCommerce products. This one is unlinked and set to Draft.', 'subscription-pro' ); ?></small></span>
								</button>
								<button type="button" role="menuitem" data-subscrpt-product-action="create">
									<span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span>
									<span><b><?php esc_html_e( 'Create a new product', 'subscription-pro' ); ?></b><small><?php esc_html_e( 'A fresh draft named after the box.', 'subscription-pro' ); ?></small></span>
								</button>
								<div class="subscrpt-box-menu__sep"></div>
								<button type="button" role="menuitem" class="is-danger" data-subscrpt-product-action="unlink">
									<span class="dashicons dashicons-no-alt" aria-hidden="true"></span>
									<span><b><?php esc_html_e( 'Unlink', 'subscription-pro' ); ?></b><small><?php esc_html_e( 'The box stays. Nothing sells it until you link one.', 'subscription-pro' ); ?></small></span>
								</button>
							</div>
						</div>
					</div>
				<?php else : ?>
					<span class="subscrpt-box-dot subscrpt-box-dot--warn"><?php esc_html_e( 'No product sells this box', 'subscription-pro' ); ?></span>
					<span class="subscrpt-box-hint"><?php esc_html_e( 'Customers can’t buy it until a WooCommerce product is linked.', 'subscription-pro' ); ?></span>
					<div class="subscrpt-box-row">
						<button type="button" class="wpsubs-btn wpsubs-btn--primary wpsubs-btn--sm" data-subscrpt-product-action="create"><?php esc_html_e( 'Create product', 'subscription-pro' ); ?></button>
						<button type="button" class="wpsubs-btn wpsubs-btn--outline wpsubs-btn--sm" data-wpsubs-modal-open="subscrpt-link-product"><?php esc_html_e( 'Use existing', 'subscription-pro' ); ?></button>
					</div>
				<?php endif; ?>
			</div>

			<dl class="subscrpt-box-kv">
				<dt><?php esc_html_e( 'Price', 'subscription-pro' ); ?></dt>
				<dd><?php echo esc_html( $box['price_label'] ); ?></dd>
				<dt><?php esc_html_e( 'Items', 'subscription-pro' ); ?></dt>
				<dd>
					<?php
					echo Box::TYPE_BUILD === $box['type']
						/* translators: %d: number of products a customer can pick from. */
						? esc_html( sprintf( _n( '%d to pick from', '%d to pick from', $box['item_count'], 'subscription-pro' ), $box['item_count'] ) )
						/* translators: %d: number of items packed. */
						: esc_html( sprintf( _n( '%d packed', '%d packed', $box['item_count'], 'subscription-pro' ), $box['item_count'] ) );
					?>
				</dd>
				<?php if ( Box::TYPE_CURATED !== $box['type'] ) : ?>
					<dt><?php esc_html_e( 'Size', 'subscription-pro' ); ?></dt>
					<dd><?php echo esc_html( $box['size_label'] ); ?></dd>
				<?php endif; ?>
				<dt><?php esc_html_e( 'Discount', 'subscription-pro' ); ?></dt>
				<dd><?php echo esc_html( $box['discount_label'] ); ?></dd>
			</dl>

			<div class="subscrpt-box-stack">
				<span class="subscrpt-box-eyebrow"><?php esc_html_e( 'Durations', 'subscription-pro' ); ?></span>
				<div class="subscrpt-box-row subscrpt-box-row--tight">
					<?php if ( $box['offered'] ) : ?>
						<?php foreach ( $box['offered'] as $subscrpt_duration ) : ?>
							<span class="subscrpt-box-tag"><?php echo esc_html( $subscrpt_duration['name'] ); ?></span>
						<?php endforeach; ?>
					<?php else : ?>
						<span class="subscrpt-box-dot subscrpt-box-dot--warn"><?php esc_html_e( 'None offered', 'subscription-pro' ); ?></span>
					<?php endif; ?>
				</div>
			</div>
		</div>

		<?php if ( $subscrpt_product && ! $subscrpt_product['missing'] && $subscrpt_product['view_url'] ) : ?>
			<div class="subscrpt-box-card__foot">
				<a class="wpsubs-btn wpsubs-btn--outline wpsubs-btn--sm" href="<?php echo esc_url( $subscrpt_product['view_url'] ); ?>" target="_blank" rel="noopener">
					<span class="dashicons dashicons-visibility" aria-hidden="true"></span><?php esc_html_e( 'Preview product page', 'subscription-pro' ); ?>
				</a>
			</div>
		<?php endif; ?>
	</div>
</aside>
