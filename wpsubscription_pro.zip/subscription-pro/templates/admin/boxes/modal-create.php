<?php
/**
 * The Create box dialog.
 *
 * One dialog makes the box and the product that sells it, already linked. Both
 * start as drafts, so nothing is on sale until the merchant publishes. Turning
 * the switch off makes the box alone.
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

defined( 'ABSPATH' ) || exit;

use SpringDevs\SubscriptionPro\Illuminate\Box\Box;

$subscrpt_types = array(
	Box::TYPE_CURATED => array( __( 'Curated', 'subscription-pro' ), __( 'You pack the same box for everyone.', 'subscription-pro' ), 'dashicons-products' ),
	Box::TYPE_BUILD   => array( __( 'Build your own', 'subscription-pro' ), __( 'Customers pick from items you allow.', 'subscription-pro' ), 'dashicons-screenoptions' ),
	Box::TYPE_EDITION => array( __( 'Monthly edition', 'subscription-pro' ), __( 'You publish what each month holds.', 'subscription-pro' ), 'dashicons-calendar-alt' ),
);
?>
<div class="wpsubs-modal" id="subscrpt-create-box" hidden>
	<div class="wpsubs-modal__backdrop" data-wpsubs-modal-close></div>
	<div class="wpsubs-modal__dialog subscrpt-box-dialog" role="dialog" aria-labelledby="subscrpt-create-box-title">

		<div class="wpsubs-modal__head">
			<div>
				<h2 class="wpsubs-modal__title" id="subscrpt-create-box-title"><?php esc_html_e( 'Create box', 'subscription-pro' ); ?></h2>
				<p class="subscrpt-box-dialog__lede"><?php esc_html_e( 'Name it and choose how it’s filled. You can change all of it later.', 'subscription-pro' ); ?></p>
			</div>
			<button type="button" class="wpsubs-modal__close" data-wpsubs-modal-close aria-label="<?php esc_attr_e( 'Close', 'subscription-pro' ); ?>">&times;</button>
		</div>

		<div class="wpsubs-modal__body subscrpt-box-dialog__body">
			<div class="subscrpt-box-field">
				<label for="subscrpt-create-box-name"><?php esc_html_e( 'Name', 'subscription-pro' ); ?></label>
				<input type="text" id="subscrpt-create-box-name" class="wpsubs-input" placeholder="<?php esc_attr_e( 'e.g. Coffee Box', 'subscription-pro' ); ?>" autocomplete="off" />
			</div>

			<div class="subscrpt-box-field">
				<span class="subscrpt-box-label"><?php esc_html_e( 'How is it filled?', 'subscription-pro' ); ?></span>
				<div class="subscrpt-box-choices subscrpt-box-choices--3" role="radiogroup">
					<?php foreach ( $subscrpt_types as $subscrpt_key => $subscrpt_type ) : ?>
						<label class="subscrpt-box-choice subscrpt-box-choice--stack<?php echo Box::TYPE_BUILD === $subscrpt_key ? ' is-on' : ''; ?>">
							<input type="radio" name="subscrpt-create-box-type" value="<?php echo esc_attr( $subscrpt_key ); ?>" <?php checked( Box::TYPE_BUILD, $subscrpt_key ); ?> />
							<span class="subscrpt-box-choice__icon"><span class="dashicons <?php echo esc_attr( $subscrpt_type[2] ); ?>" aria-hidden="true"></span></span>
							<span><b><?php echo esc_html( $subscrpt_type[0] ); ?></b><small><?php echo esc_html( $subscrpt_type[1] ); ?></small></span>
						</label>
					<?php endforeach; ?>
				</div>
			</div>

			<div class="subscrpt-box-togrow">
				<label class="subscrpt-box-switch">
					<input type="checkbox" class="wpsubs-toggle" id="subscrpt-create-box-sell" checked aria-describedby="subscrpt-create-box-sell-hint" />
					<span class="wpsubs-toggle-ui" aria-hidden="true"></span>
				</label>
				<div class="subscrpt-box-togrow__grow">
					<div>
						<label for="subscrpt-create-box-sell"><b><?php esc_html_e( 'Create a product to sell it', 'subscription-pro' ); ?></b></label>
						<span class="subscrpt-box-hint" id="subscrpt-create-box-sell-hint"><?php esc_html_e( 'A subscription product, linked to this box. You can swap it for another product later.', 'subscription-pro' ); ?></span>
					</div>
					<div class="subscrpt-box-field" data-subscrpt-create-product>
						<label for="subscrpt-create-box-product"><?php esc_html_e( 'Product name', 'subscription-pro' ); ?></label>
						<input type="text" id="subscrpt-create-box-product" class="wpsubs-input" autocomplete="off" />
					</div>
				</div>
			</div>
		</div>

		<div class="wpsubs-modal__footer subscrpt-box-dialog__foot">
			<span class="subscrpt-box-hint" data-subscrpt-create-summary
				data-with="<?php esc_attr_e( 'Creates a draft box and a draft product', 'subscription-pro' ); ?>"
				data-without="<?php esc_attr_e( 'Creates a draft box only', 'subscription-pro' ); ?>"
			><?php esc_html_e( 'Creates a draft box and a draft product', 'subscription-pro' ); ?></span>
			<span class="subscrpt-box-row">
				<button type="button" class="wpsubs-btn wpsubs-btn--outline" data-wpsubs-modal-close><?php esc_html_e( 'Cancel', 'subscription-pro' ); ?></button>
				<button type="button" class="wpsubs-btn wpsubs-btn--primary" data-subscrpt-create-box><?php esc_html_e( 'Create box', 'subscription-pro' ); ?></button>
			</span>
		</div>

	</div>
</div>
