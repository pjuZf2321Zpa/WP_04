<?php
/**
 * Box detail — Pricing tab.
 *
 * Whether the box costs what its durations say, or what is picked, and the
 * discount a bigger box earns. Four cards: how it is priced, the tiers, what is
 * never discounted, and the builder's messages. A worked example under the
 * tiers recalculates as they are typed, so a tier's effect is clear before it
 * is saved.
 *
 * @var array $box    BoxPresenter::find().
 * @var int   $box_id Box id.
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

defined( 'ABSPATH' ) || exit;

$subscrpt_pricing  = $box['pricing'];
$subscrpt_is_sum   = 'sum' === $subscrpt_pricing['strategy'];
$subscrpt_measure  = $subscrpt_pricing['tiers'] ? $subscrpt_pricing['tiers'][0]['measure'] : 'quantity';
$subscrpt_currency = html_entity_decode( get_woocommerce_currency_symbol(), ENT_QUOTES, 'UTF-8' );

/**
 * One discount tier row.
 *
 * @param array  $tier     measure, threshold, type, value.
 * @param string $currency Currency symbol.
 *
 * @return void
 */
$subscrpt_tier_row = static function ( array $tier, string $currency ): void {
	?>
	<div class="subscrpt-box-tier" data-subscrpt-tier>
		<span><?php esc_html_e( 'At', 'subscription-pro' ); ?></span>
		<span data-subscrpt-measure-unit="amount"><?php echo esc_html( $currency ); ?></span>
		<input type="number" min="0" step="any" class="wpsubs-input subscrpt-box-num" data-subscrpt-tier-threshold value="<?php echo esc_attr( $tier['threshold'] ); ?>" aria-label="<?php esc_attr_e( 'Threshold', 'subscription-pro' ); ?>" />
		<span data-subscrpt-measure-unit="quantity"><?php esc_html_e( 'items,', 'subscription-pro' ); ?></span>
		<span><?php esc_html_e( 'take', 'subscription-pro' ); ?></span>
		<input type="number" min="0" step="any" class="wpsubs-input subscrpt-box-num" data-subscrpt-tier-value value="<?php echo esc_attr( $tier['value'] ); ?>" aria-label="<?php esc_attr_e( 'Discount', 'subscription-pro' ); ?>" />
		<select class="wpsubs-input subscrpt-box-autoselect" data-subscrpt-tier-type aria-label="<?php esc_attr_e( 'Discount type', 'subscription-pro' ); ?>">
			<option value="percent" <?php selected( 'percent', $tier['type'] ); ?>><?php esc_html_e( '% off', 'subscription-pro' ); ?></option>
			<?php /* translators: %s: currency symbol. */ ?>
			<option value="fixed" <?php selected( 'fixed', $tier['type'] ); ?>><?php echo esc_html( sprintf( __( '%s off', 'subscription-pro' ), $currency ) ); ?></option>
		</select>
		<span class="subscrpt-box-spacer"></span>
		<button type="button" class="wpsubs-icon-action wpsubs-icon-action--danger" data-subscrpt-tier-remove aria-label="<?php esc_attr_e( 'Remove tier', 'subscription-pro' ); ?>">
			<span class="dashicons dashicons-trash" aria-hidden="true"></span>
		</button>
	</div>
	<?php
};

$subscrpt_strategies = array(
	'fixed' => array( __( 'One price for the box', 'subscription-pro' ), __( 'Set on each duration. Every box costs the same, whatever is picked.', 'subscription-pro' ), 'dashicons-tag' ),
	'sum'   => array( __( 'Add up what is picked', 'subscription-pro' ), __( 'Each item is charged at its own price. PayPal is not offered at checkout, because it bills a fixed amount.', 'subscription-pro' ), 'dashicons-list-view' ),
);
?>
<div data-subscrpt-box-form="pricing" data-subscrpt-pricing>

	<div class="subscrpt-box-card">
		<div class="subscrpt-box-card__head">
			<div>
				<h3><?php esc_html_e( 'How is the box priced?', 'subscription-pro' ); ?></h3>
				<p><?php esc_html_e( 'What a customer pays for each delivery. You can change this later; existing subscriptions keep their price.', 'subscription-pro' ); ?></p>
			</div>
		</div>
		<div class="subscrpt-box-card__body">
			<div class="subscrpt-box-choices subscrpt-box-choices--2" role="radiogroup">
				<?php foreach ( $subscrpt_strategies as $subscrpt_key => $subscrpt_strategy ) : ?>
					<label class="subscrpt-box-choice subscrpt-box-choice--stack<?php echo $subscrpt_pricing['strategy'] === $subscrpt_key ? ' is-on' : ''; ?>">
						<input type="radio" name="subscrpt-pricing-strategy" value="<?php echo esc_attr( $subscrpt_key ); ?>" data-subscrpt-pricing-strategy <?php checked( $subscrpt_pricing['strategy'], $subscrpt_key ); ?> />
						<span class="subscrpt-box-choice__icon"><span class="dashicons <?php echo esc_attr( $subscrpt_strategy[2] ); ?>" aria-hidden="true"></span></span>
						<span><b><?php echo esc_html( $subscrpt_strategy[0] ); ?></b><small><?php echo esc_html( $subscrpt_strategy[1] ); ?></small></span>
					</label>
				<?php endforeach; ?>
			</div>
		</div>
		<div class="subscrpt-box-set" data-subscrpt-pricing-sum <?php echo $subscrpt_is_sum ? '' : 'hidden'; ?>>
			<div class="subscrpt-box-set__key">
				<label for="subscrpt-pricing-base"><b><?php esc_html_e( 'Base price', 'subscription-pro' ); ?></b></label>
				<small><?php esc_html_e( 'Packaging or handling. Never discounted.', 'subscription-pro' ); ?></small>
			</div>
			<div class="subscrpt-box-row">
				<span><?php echo esc_html( $subscrpt_currency ); ?></span>
				<input type="number" min="0" step="any" id="subscrpt-pricing-base" class="wpsubs-input subscrpt-box-num" data-subscrpt-pricing-base value="<?php echo esc_attr( $subscrpt_pricing['base_price'] ); ?>" />
				<span class="subscrpt-box-hint"><?php esc_html_e( 'Added to every box.', 'subscription-pro' ); ?></span>
			</div>
		</div>
	</div>

	<div class="subscrpt-box-card" data-subscrpt-pricing-sum <?php echo $subscrpt_is_sum ? '' : 'hidden'; ?>>
		<div class="subscrpt-box-card__head">
			<div>
				<h3><?php esc_html_e( 'Discount for bigger boxes', 'subscription-pro' ); ?></h3>
				<p><?php esc_html_e( 'The more a customer puts in, the more they save. If two tiers share a threshold, the larger discount wins.', 'subscription-pro' ); ?></p>
			</div>
			<label class="subscrpt-box-row">
				<span class="subscrpt-box-hint"><?php esc_html_e( 'Measured in', 'subscription-pro' ); ?></span>
				<select class="wpsubs-input subscrpt-box-autoselect" data-subscrpt-pricing-measure>
					<option value="quantity" <?php selected( 'quantity', $subscrpt_measure ); ?>><?php esc_html_e( 'items picked', 'subscription-pro' ); ?></option>
					<option value="amount" <?php selected( 'amount', $subscrpt_measure ); ?>><?php esc_html_e( 'amount spent', 'subscription-pro' ); ?></option>
				</select>
			</label>
		</div>

		<div data-subscrpt-tier-list>
			<?php
			foreach ( $subscrpt_pricing['tiers'] as $subscrpt_tier ) {
				$subscrpt_tier_row( $subscrpt_tier, $subscrpt_currency );
			}
			?>
		</div>
		<div class="subscrpt-box-tier subscrpt-box-hint" data-subscrpt-tier-empty <?php echo $subscrpt_pricing['tiers'] ? 'hidden' : ''; ?>>
			<?php esc_html_e( 'No tiers, so no discount.', 'subscription-pro' ); ?>
		</div>

		<template data-subscrpt-tier-template>
			<?php
			$subscrpt_tier_row(
				array(
					'threshold' => '',
					'type'      => 'percent',
					'value'     => '',
				),
				$subscrpt_currency
			);
			?>
		</template>

		<div class="subscrpt-box-lrow subscrpt-box-lrow--add">
			<button type="button" class="subscrpt-box-link" data-subscrpt-tier-add>
				<span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span><?php esc_html_e( 'Add a tier', 'subscription-pro' ); ?>
			</button>
		</div>
		<div class="subscrpt-box-card__body">
			<div class="subscrpt-box-example" data-subscrpt-pricing-example></div>
		</div>
	</div>

	<div class="subscrpt-box-card" data-subscrpt-pricing-sum <?php echo $subscrpt_is_sum ? '' : 'hidden'; ?>>
		<div class="subscrpt-box-card__head">
			<div>
				<h3><?php esc_html_e( 'Not discounted', 'subscription-pro' ); ?></h3>
				<p><?php esc_html_e( 'Charged in full and not counted toward a tier, for example gift wrap.', 'subscription-pro' ); ?></p>
			</div>
		</div>
		<div class="subscrpt-box-card__body subscrpt-box-stack">
			<div class="subscrpt-box-row subscrpt-box-row--tight" data-subscrpt-pricing-excluded-list>
				<?php foreach ( $subscrpt_pricing['excluded'] as $subscrpt_excluded ) : ?>
					<?php $subscrpt_excluded_product = wc_get_product( $subscrpt_excluded ); ?>
					<span class="subscrpt-box-chip" data-subscrpt-pricing-excluded="<?php echo esc_attr( (string) $subscrpt_excluded ); ?>">
						<?php echo esc_html( $subscrpt_excluded_product ? $subscrpt_excluded_product->get_name() : __( '(deleted product)', 'subscription-pro' ) ); ?>
						<button type="button" data-subscrpt-pricing-excluded-remove aria-label="<?php esc_attr_e( 'Count it toward the discount', 'subscription-pro' ); ?>">&times;</button>
					</span>
				<?php endforeach; ?>
				<span class="subscrpt-box-hint" data-subscrpt-pricing-excluded-empty <?php echo $subscrpt_pricing['excluded'] ? 'hidden' : ''; ?>>
					<?php esc_html_e( 'Every item counts toward the discount.', 'subscription-pro' ); ?>
				</span>
			</div>
			<div class="subscrpt-box-addproduct">
				<select
					class="wc-product-search subscrpt-box-select"
					style="width:100%;"
					data-subscrpt-pricing-excluded-add
					data-placeholder="<?php esc_attr_e( 'Add a product that is never discounted…', 'subscription-pro' ); ?>"
					data-action="woocommerce_json_search_products_and_variations"
					aria-label="<?php esc_attr_e( 'Add a product that is never discounted', 'subscription-pro' ); ?>"
				></select>
			</div>
		</div>
	</div>

	<div class="subscrpt-box-card" data-subscrpt-pricing-sum <?php echo $subscrpt_is_sum ? '' : 'hidden'; ?>>
		<div class="subscrpt-box-card__head">
			<div>
				<h3><?php esc_html_e( 'Messages in the builder', 'subscription-pro' ); ?></h3>
				<p><?php esc_html_e( 'Use {remaining} for what is left to the next tier and {discount} for what it takes off. Leave empty for the default wording.', 'subscription-pro' ); ?></p>
			</div>
		</div>
		<div class="subscrpt-box-set">
			<div class="subscrpt-box-set__key"><label for="subscrpt-pricing-progress"><b><?php esc_html_e( 'On the way to a discount', 'subscription-pro' ); ?></b></label></div>
			<input type="text" id="subscrpt-pricing-progress" class="wpsubs-input" data-subscrpt-pricing-message="progress" placeholder="<?php esc_attr_e( 'Add {remaining} more to save {discount}.', 'subscription-pro' ); ?>" value="<?php echo esc_attr( $subscrpt_pricing['messages']['progress'] ); ?>" />
		</div>
		<div class="subscrpt-box-set">
			<div class="subscrpt-box-set__key"><label for="subscrpt-pricing-success"><b><?php esc_html_e( 'Once it is earned', 'subscription-pro' ); ?></b></label></div>
			<input type="text" id="subscrpt-pricing-success" class="wpsubs-input" data-subscrpt-pricing-message="success" placeholder="<?php esc_attr_e( 'You are saving {discount}.', 'subscription-pro' ); ?>" value="<?php echo esc_attr( $subscrpt_pricing['messages']['success'] ); ?>" />
		</div>
	</div>

	<?php require __DIR__ . '/partial-savebar.php'; ?>
</div>
