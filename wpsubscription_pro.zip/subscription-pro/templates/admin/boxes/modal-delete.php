<?php
/**
 * Delete a box, saying first what goes and what stays.
 *
 * One dialog for the list and the box screen. The button that opens it carries
 * the box's name, its product and how many subscriptions still renew through
 * that product, and boxes.js writes them in.
 *
 * A product with subscriptions still renewing cannot be trashed — they need it
 * to bill — so that choice is replaced by a note and the product is kept as a
 * draft.
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

defined( 'ABSPATH' ) || exit;

?>
<div class="wpsubs-modal" id="subscrpt-delete-box" data-subscrpt-delete-modal hidden>
	<div class="wpsubs-modal__backdrop" data-wpsubs-modal-close></div>
	<div class="wpsubs-modal__dialog subscrpt-box-dialog" role="alertdialog" aria-labelledby="subscrpt-delete-box-title">

		<div class="wpsubs-modal__head">
			<div>
				<h2 class="wpsubs-modal__title" id="subscrpt-delete-box-title" data-subscrpt-delete-title></h2>
				<p class="subscrpt-box-dialog__lede"><?php esc_html_e( 'This can’t be undone.', 'subscription-pro' ); ?></p>
			</div>
			<button type="button" class="wpsubs-modal__close" data-wpsubs-modal-close aria-label="<?php esc_attr_e( 'Close', 'subscription-pro' ); ?>">&times;</button>
		</div>

		<div class="wpsubs-modal__body subscrpt-box-dialog__body">
			<div class="subscrpt-box-consq">
				<div>
					<b><?php esc_html_e( 'Deleted', 'subscription-pro' ); ?></b>
					<ul>
						<li><?php esc_html_e( 'The box and its items', 'subscription-pro' ); ?></li>
						<li><?php esc_html_e( 'Its rules, pricing and durations', 'subscription-pro' ); ?></li>
					</ul>
				</div>
				<div>
					<b><?php esc_html_e( 'Kept', 'subscription-pro' ); ?></b>
					<ul>
						<li data-subscrpt-delete-subs hidden></li>
						<li><?php esc_html_e( 'Past shipments and orders', 'subscription-pro' ); ?></li>
					</ul>
				</div>
			</div>

			<div class="subscrpt-box-stack" data-subscrpt-delete-product-section>
				<span class="subscrpt-box-label"><?php esc_html_e( 'What happens to the product that sells it?', 'subscription-pro' ); ?></span>

				<div class="subscrpt-box-prod">
					<span class="subscrpt-box-thumb" data-subscrpt-delete-initials></span>
					<span class="subscrpt-box-prod__text">
						<span class="subscrpt-box-prod__name" data-subscrpt-delete-product></span>
						<span class="subscrpt-box-hint" data-subscrpt-delete-product-meta></span>
					</span>
				</div>

				<div class="subscrpt-box-choices" role="radiogroup">
					<label class="subscrpt-box-choice" data-subscrpt-delete-trash>
						<input type="radio" name="subscrpt-delete-product" value="trash" />
						<span class="subscrpt-box-choice__icon"><span class="dashicons dashicons-trash" aria-hidden="true"></span></span>
						<span><b><?php esc_html_e( 'Move it to trash', 'subscription-pro' ); ?></b><small><?php esc_html_e( 'Restore it any time from WooCommerce → Products → Trash.', 'subscription-pro' ); ?></small></span>
					</label>
					<label class="subscrpt-box-choice">
						<input type="radio" name="subscrpt-delete-product" value="draft" />
						<span class="subscrpt-box-choice__icon"><span class="dashicons dashicons-store" aria-hidden="true"></span></span>
						<span><b><?php esc_html_e( 'Keep it as a draft', 'subscription-pro' ); ?></b><small><?php esc_html_e( 'It’s unlinked and hidden from the shop, so no one sees an empty box.', 'subscription-pro' ); ?></small></span>
					</label>
				</div>

				<p class="subscrpt-box-note" data-subscrpt-delete-locked hidden>
					<?php esc_html_e( 'Subscriptions still renew through this product, so it is kept as a draft rather than trashed.', 'subscription-pro' ); ?>
				</p>
			</div>
		</div>

		<div class="wpsubs-modal__footer">
			<button type="button" class="wpsubs-btn wpsubs-btn--outline" data-wpsubs-modal-close><?php esc_html_e( 'Cancel', 'subscription-pro' ); ?></button>
			<button type="button" class="wpsubs-btn wpsubs-btn--danger" data-subscrpt-delete-confirm></button>
		</div>

	</div>
</div>
