<?php
/**
 * Sell a box through a product that already exists.
 *
 * The product it replaces is unlinked and set to Draft, so its page does not
 * show a builder for a box it no longer sells.
 *
 * @var int $box_id Box id.
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

defined( 'ABSPATH' ) || exit;

?>
<div class="wpsubs-modal" id="subscrpt-link-product" hidden>
	<div class="wpsubs-modal__backdrop" data-wpsubs-modal-close></div>
	<div class="wpsubs-modal__dialog subscrpt-box-dialog">

		<div class="wpsubs-modal__head">
			<div>
				<h2 class="wpsubs-modal__title"><?php esc_html_e( 'Use another product', 'subscription-pro' ); ?></h2>
				<p class="subscrpt-box-dialog__lede"><?php esc_html_e( 'The product customers buy to get this box. The current one, if any, is unlinked and set to Draft.', 'subscription-pro' ); ?></p>
			</div>
			<button type="button" class="wpsubs-modal__close" data-wpsubs-modal-close aria-label="<?php esc_attr_e( 'Close', 'subscription-pro' ); ?>">&times;</button>
		</div>

		<div class="wpsubs-modal__body">
			<label for="subscrpt-link-product-search" class="subscrpt-box-label"><?php esc_html_e( 'Product', 'subscription-pro' ); ?></label>
			<select
				id="subscrpt-link-product-search"
				class="wc-product-search subscrpt-box-select"
				style="width:100%;"
				data-subscrpt-link-product
				data-placeholder="<?php esc_attr_e( 'Search for a product…', 'subscription-pro' ); ?>"
				data-action="subscrpt_box_search_link_products"
			></select>
			<p class="subscrpt-box-hint subscrpt-box-hint--below"><?php esc_html_e( 'A product that already sells another box can’t sell this one too.', 'subscription-pro' ); ?></p>
		</div>

		<div class="wpsubs-modal__footer">
			<button type="button" class="wpsubs-btn wpsubs-btn--outline" data-wpsubs-modal-close><?php esc_html_e( 'Cancel', 'subscription-pro' ); ?></button>
			<button type="button" class="wpsubs-btn wpsubs-btn--primary" data-subscrpt-link-product-save><?php esc_html_e( 'Use this product', 'subscription-pro' ); ?></button>
		</div>

	</div>
</div>
