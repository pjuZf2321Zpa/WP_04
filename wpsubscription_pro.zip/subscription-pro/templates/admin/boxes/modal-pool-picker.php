<?php
/**
 * The product picker for a box's chosen products.
 *
 * Shared by the Box items list and an edition box's swap-in pool. Ticking is
 * choosing; saving hands the ticks back to whichever list opened it.
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

defined( 'ABSPATH' ) || exit;

?>
<div class="wpsubs-modal" id="subscrpt-pool-picker" hidden data-subscrpt-pool-picker>
	<div class="wpsubs-modal__backdrop" data-wpsubs-modal-close></div>
	<div class="wpsubs-modal__dialog" style="width:min(720px, calc(100vw - 40px));">
		<div class="wpsubs-modal__head" style="align-items:flex-start;">
			<div>
				<h2 class="wpsubs-modal__title"><?php esc_html_e( 'Manage products', 'subscription-pro' ); ?></h2>
				<p style="margin:5px 0 0;color:var(--wpsubs-text-muted);font-size:13px;line-height:1.5;font-weight:400;">
					<?php esc_html_e( 'Ticked products can go in this box. Untick one to take it out.', 'subscription-pro' ); ?>
				</p>
			</div>
			<button type="button" class="wpsubs-modal__close" data-wpsubs-modal-close aria-label="<?php esc_attr_e( 'Close', 'subscription-pro' ); ?>">&times;</button>
		</div>
		<div class="wpsubs-modal__body">
			<div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;">
				<label style="display:inline-flex;align-items:center;padding-left:4px;cursor:pointer;" title="<?php esc_attr_e( 'Select all listed products', 'subscription-pro' ); ?>">
					<input type="checkbox" class="wpsubs-checkbox" data-subscrpt-pool-picker-all />
				</label>
				<div class="wpsubs-input-wrap wpsubs-input-wrap--icon-l" style="flex:1;">
					<svg class="wpsubs-input-icon" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-4.35-4.35M17 11A6 6 0 1 1 5 11a6 6 0 0 1 12 0z"/></svg>
					<input type="search" class="wpsubs-input" placeholder="<?php esc_attr_e( 'Search products…', 'subscription-pro' ); ?>" data-subscrpt-pool-picker-search />
				</div>
			</div>
			<ul data-subscrpt-pool-picker-list style="list-style:none;margin:0;padding:0;max-height:min(560px, 60vh);overflow-y:auto;display:flex;flex-direction:column;gap:2px;"></ul>
		</div>
		<div class="wpsubs-modal__footer">
			<span data-subscrpt-pool-picker-count style="margin-right:auto;font-size:13px;color:var(--wpsubs-text-muted);"></span>
			<button type="button" class="wpsubs-btn wpsubs-btn--outline" data-wpsubs-modal-close><?php esc_html_e( 'Cancel', 'subscription-pro' ); ?></button>
			<button type="button" class="wpsubs-btn wpsubs-btn--primary" data-subscrpt-pool-picker-save><?php esc_html_e( 'Save products', 'subscription-pro' ); ?></button>
		</div>
	</div>
</div>
