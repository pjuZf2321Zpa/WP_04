<?php
/**
 * The bar that appears once a tab has unsaved changes.
 *
 * One save for the whole tab, in one place, and only when there is something
 * to save — rather than a Save button under every form that is always there.
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

defined( 'ABSPATH' ) || exit;

?>
<div class="subscrpt-box-savebar" data-subscrpt-savebar role="region" aria-label="<?php esc_attr_e( 'Unsaved changes', 'subscription-pro' ); ?>" hidden>
	<span><?php esc_html_e( 'Unsaved changes', 'subscription-pro' ); ?></span>
	<span class="subscrpt-box-row">
		<button type="button" class="wpsubs-btn wpsubs-btn--sm subscrpt-box-savebar__quiet" data-subscrpt-box-discard><?php esc_html_e( 'Discard', 'subscription-pro' ); ?></button>
		<button type="button" class="wpsubs-btn wpsubs-btn--primary wpsubs-btn--sm" data-subscrpt-box-save><?php esc_html_e( 'Save', 'subscription-pro' ); ?></button>
	</span>
</div>
