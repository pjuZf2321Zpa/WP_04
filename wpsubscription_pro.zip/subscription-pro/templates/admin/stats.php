<?php
/**
 * Subscription Reports admin page template.
 *
 * @package SpringDevs\SubscriptionPro
 *
 * @var array $metrics              Comprehensive subscription metrics.
 * @var array $popular_subscriptions Popular subscriptions data.
 * @var array $trial_conversion_data Trial conversion metrics.
 * @var array $revenue_metrics      Revenue metrics.
 * @var float $revenue_at_risk      Revenue at risk from unhealthy subscriptions.
 * @var array $monthly_trends       Monthly trends data.
 * @var array $cancellation_reasons Cancellation reasons breakdown { reasons, total }.
 */

defined( 'ABSPATH' ) || exit;

// Enqueue Chart.js
\SpringDevs\Subscription\Assets::enqueue_chart_js();

// ---------------------------------------------------------------------------------------------------------- //

$currency = get_woocommerce_currency_symbol();

/**
 * Format a price amount using WooCommerce if available.
 *
 * @param float $amount Amount to format.
 * @return string Formatted price HTML.
 */
function subscrpt_format_stat_price( float $amount ): string {
	return function_exists( 'wc_price' ) ? wc_price( $amount ) : esc_html( '$' . number_format( $amount, 2 ) );
}

$refresh_url = add_query_arg( 'refresh', 'true', remove_query_arg( 'refresh' ) );

$subscrpt_page_title = __( 'Subscription Reports', 'subscription-pro' );
$subscrpt_page_desc  = __( 'Data-driven insights for your subscription business.', 'subscription-pro' );

// `list-page` on its own paints a white background with no vertical padding and
// no bottom margin — the title sat on the top edge and the gate card went
// white-on-white. Both branches use the same wrapper and the same header now.
if ( ! \Sdevs_Wc_Subscription_Pro::check_pro_license_or_alert( false, false ) ) {
	?>
	<div class="wp-subscription-admin-content list-page">
		<?php
		wc_get_template(
			'page-header.php',
			array(
				'subscrpt_title' => $subscrpt_page_title,
				'subscrpt_desc'  => $subscrpt_page_desc,
			),
			'subscription-pro/admin/partials/',
			WP_SUBSCRIPTION_PRO_TEMPLATES . 'admin/partials/'
		);
		\Sdevs_Wc_Subscription_Pro::check_pro_license_or_alert();
		?>
	</div>
	<?php
	return;
}
?>

<!-- Page content — individual cards on WP admin gray background -->
<div class="wp-subscription-admin-content list-page">

	<?php
	ob_start();
	$last_updated = (int) get_transient( 'subscrpt_stats_last_updated' );
	if ( $last_updated > 0 ) :
		?>
		<span class="subscrpt-page-header__meta-text">
			<?php
			printf(
				/* translators: %s: human-readable time difference */
				esc_html__( 'Updated %s ago', 'subscription-pro' ),
				esc_html( human_time_diff( $last_updated ) )
			);
			?>
		</span>
		<?php
	endif;
	?>
	<a href="<?php echo esc_url( $refresh_url ); ?>" class="wpsubs-btn wpsubs-btn--outline wpsubs-btn--sm">
		<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
		<?php esc_html_e( 'Refresh', 'subscription-pro' ); ?>
	</a>
	<?php
	wc_get_template(
		'page-header.php',
		array(
			'subscrpt_title' => $subscrpt_page_title,
			'subscrpt_desc'  => $subscrpt_page_desc,
			'subscrpt_meta'  => ob_get_clean(),
		),
		'subscription-pro/admin/partials/',
		WP_SUBSCRIPTION_PRO_TEMPLATES . 'admin/partials/'
	);
	?>

	<div class="wpsubs-tabs" data-tabs-query="report">
		<div class="wpsubs-tabs__list" role="tablist">
			<button class="wpsubs-tabs__tab" role="tab" id="subscrpt-report-tab-overview" data-tab-key="overview" aria-controls="subscrpt-report-panel-overview" aria-selected="true">
				<?php esc_html_e( 'Overview', 'subscription-pro' ); ?>
			</button>
			<button class="wpsubs-tabs__tab" role="tab" id="subscrpt-report-tab-cancellation" data-tab-key="cancellation" aria-controls="subscrpt-report-panel-cancellation" aria-selected="false">
				<?php esc_html_e( 'Cancellation', 'subscription-pro' ); ?>
			</button>
		</div>

	<div class="wpsubs-tab-panel" role="tabpanel" id="subscrpt-report-panel-overview" aria-labelledby="subscrpt-report-tab-overview">

	<!-- KPI stat cards -->
	<div class="subscrpt-stat-grid">

		<!-- Active Subscriptions -->
		<div class="subscrpt-stat-card">
			<div class="subscrpt-stat-card__row">
				<div class="subscrpt-stat-card__value"><?php echo esc_html( number_format_i18n( $metrics['active_subscriptions'] ) ); ?></div>
				<span class="subscrpt-stat-card__icon subscrpt-stat-card__icon--indigo">
					<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>
				</span>
			</div>
			<div class="subscrpt-stat-card__label"><?php esc_html_e( 'Active Subscriptions', 'subscription-pro' ); ?></div>
			<div class="subscrpt-stat-card__hint"><?php esc_html_e( 'Recurring revenue base', 'subscription-pro' ); ?></div>
		</div>

		<!-- MRR -->
		<div class="subscrpt-stat-card">
			<div class="subscrpt-stat-card__row">
				<div class="subscrpt-stat-card__value"><?php echo wp_kses_post( subscrpt_format_stat_price( $revenue_metrics['mrr'] ) ); ?></div>
				<span class="subscrpt-stat-card__icon subscrpt-stat-card__icon--green">
					<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
				</span>
			</div>
			<div class="subscrpt-stat-card__label"><?php esc_html_e( 'Monthly Recurring Revenue', 'subscription-pro' ); ?></div>
			<div class="subscrpt-stat-card__hint"><?php esc_html_e( 'Predictable monthly income', 'subscription-pro' ); ?></div>
		</div>

		<!-- Revenue at Risk -->
		<div class="subscrpt-stat-card">
			<div class="subscrpt-stat-card__row">
				<div class="subscrpt-stat-card__value subscrpt-stat-card__value--danger"><?php echo wp_kses_post( subscrpt_format_stat_price( $revenue_at_risk ) ); ?></div>
				<span class="subscrpt-stat-card__icon subscrpt-stat-card__icon--danger">
					<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" /></svg>
				</span>
			</div>
			<div class="subscrpt-stat-card__label"><?php esc_html_e( 'Revenue at Risk', 'subscription-pro' ); ?></div>
			<div class="subscrpt-stat-card__hint"><?php esc_html_e( 'Needs attention', 'subscription-pro' ); ?></div>
		</div>

		<!-- Churn Rate -->
		<div class="subscrpt-stat-card">
			<div class="subscrpt-stat-card__row">
				<div style="font-size:1.875rem;font-weight:700;color:<?php echo $metrics['churn_rate'] > 10 ? '#ef4444' : '#111827'; ?>;line-height:1;"><?php echo esc_html( number_format_i18n( $metrics['churn_rate'], 1 ) ); ?>%</div>
				<span class="subscrpt-stat-card__icon subscrpt-stat-card__icon--orange">
					<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 17h8m0 0V9m0 8l-8-8-4 4-6-6" /></svg>
				</span>
			</div>
			<div class="subscrpt-stat-card__label"><?php esc_html_e( 'Churn Rate', 'subscription-pro' ); ?></div>
			<div class="subscrpt-stat-card__hint"><?php esc_html_e( 'Customer retention indicator', 'subscription-pro' ); ?></div>
		</div>

		<!-- Trial Conversion -->
		<div class="subscrpt-stat-card">
			<div class="subscrpt-stat-card__row">
				<div style="font-size:1.875rem;font-weight:700;color:<?php echo $metrics['trial_conversion_rate'] < 20 ? '#f97316' : '#111827'; ?>;line-height:1;"><?php echo esc_html( number_format_i18n( $metrics['trial_conversion_rate'], 1 ) ); ?>%</div>
				<span class="subscrpt-stat-card__icon subscrpt-stat-card__icon--purple">
					<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
				</span>
			</div>
			<div class="subscrpt-stat-card__label"><?php esc_html_e( 'Trial Conversion', 'subscription-pro' ); ?></div>
			<div class="subscrpt-stat-card__hint"><?php esc_html_e( 'Trial to paid success', 'subscription-pro' ); ?></div>
		</div>

	</div>

	<!-- Revenue & Trends chart -->
	<div class="wpsubs-table-card" style="margin-bottom:16px;">
		<div style="padding:16px 20px;border-bottom:1px solid var(--wpsubs-border);">
			<h2 style="font-size:13px;font-weight:600;color:var(--wpsubs-text-muted);text-transform:uppercase;letter-spacing:0.07em;margin:0;"><?php esc_html_e( 'Revenue & Subscription Trends', 'subscription-pro' ); ?></h2>
		</div>
		<div style="padding:20px;display:grid;grid-template-columns:1fr 260px;gap:24px;align-items:start;">
			<div>
				<canvas id="mainTrendsChart" style="width:100%;height:280px;"></canvas>
			</div>
			<div>
				<p style="font-size:12px;font-weight:600;color:var(--wpsubs-text-muted);text-transform:uppercase;letter-spacing:0.07em;margin:0 0 10px;"><?php esc_html_e( 'Quick Insights', 'subscription-pro' ); ?></p>
				<div style="display:flex;flex-direction:column;gap:10px;">
					<?php if ( $metrics['trial_conversion_rate'] < 20 ) : ?>
						<div style="padding:12px;border-radius:8px;border:1px solid #fed7aa;background:#fff7ed;">
							<div style="font-size:12px;font-weight:600;color:#9a3412;margin-bottom:4px;"><?php esc_html_e( 'Low Trial Conversion', 'subscription-pro' ); ?></div>
							<div style="font-size:12px;color:#c2410c;"><?php esc_html_e( 'Below industry average. Consider improving onboarding.', 'subscription-pro' ); ?></div>
						</div>
					<?php endif; ?>
					<?php if ( $metrics['churn_rate'] > 10 ) : ?>
						<div style="padding:12px;border-radius:8px;border:1px solid #fca5a5;background:#fef2f2;">
							<div style="font-size:12px;font-weight:600;color:#991b1b;margin-bottom:4px;"><?php esc_html_e( 'High Churn Rate', 'subscription-pro' ); ?></div>
							<div style="font-size:12px;color:#b91c1c;"><?php esc_html_e( 'Focus on customer retention strategies.', 'subscription-pro' ); ?></div>
						</div>
					<?php endif; ?>
					<?php if ( $revenue_metrics['mrr'] > 0 ) : ?>
						<div style="padding:12px;border-radius:8px;border:1px solid #86efac;background:#f0fdf4;">
							<div style="font-size:12px;font-weight:600;color:#166534;margin-bottom:4px;"><?php esc_html_e( 'Revenue Growth', 'subscription-pro' ); ?></div>
							<div style="font-size:12px;color:#15803d;">
								<?php
								printf(
									/* translators: %s: formatted MRR */
									esc_html__( 'MRR is %s — great foundation!', 'subscription-pro' ),
									wp_kses_post( subscrpt_format_stat_price( $revenue_metrics['mrr'] ) )
								);
								?>
							</div>
						</div>
					<?php endif; ?>
					<div style="padding:12px;border-radius:8px;border:1px solid var(--wpsubs-border);background:var(--wpsubs-surface-muted);">
						<div style="font-size:12px;font-weight:600;color:var(--wpsubs-text);margin-bottom:4px;"><?php esc_html_e( 'Pro Tip', 'subscription-pro' ); ?></div>
						<div style="font-size:12px;color:var(--wpsubs-text-muted);"><?php esc_html_e( 'Focus on top-performing products and optimise trial conversions.', 'subscription-pro' ); ?></div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Performance metrics: 3 cards -->
	<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:16px;">

		<!-- Revenue Performance -->
		<div class="wpsubs-table-card">
			<div style="padding:16px 20px;border-bottom:1px solid var(--wpsubs-border);">
				<h2 style="font-size:13px;font-weight:600;color:var(--wpsubs-text-muted);text-transform:uppercase;letter-spacing:0.07em;margin:0;"><?php esc_html_e( 'Revenue Performance', 'subscription-pro' ); ?></h2>
			</div>
			<div style="padding:20px;display:grid;grid-template-columns:1fr 1fr;gap:16px;">
				<div>
					<div style="font-size:1.125rem;font-weight:700;color:#111827;"><?php echo wp_kses_post( subscrpt_format_stat_price( $revenue_metrics['total_revenue'] ) ); ?></div>
					<div class="subscrpt-stat-card__hint"><?php esc_html_e( 'Total Revenue', 'subscription-pro' ); ?></div>
				</div>
				<div>
					<div style="font-size:1.125rem;font-weight:700;color:#111827;"><?php echo wp_kses_post( subscrpt_format_stat_price( $revenue_metrics['arr'] ) ); ?></div>
					<div class="subscrpt-stat-card__hint"><?php esc_html_e( 'Annual Recurring', 'subscription-pro' ); ?></div>
				</div>
				<div>
					<div style="font-size:1.125rem;font-weight:700;color:#111827;"><?php echo wp_kses_post( subscrpt_format_stat_price( $revenue_metrics['net_revenue'] ) ); ?></div>
					<div class="subscrpt-stat-card__hint"><?php esc_html_e( 'Net Revenue', 'subscription-pro' ); ?></div>
				</div>
				<div>
					<div style="font-size:1.125rem;font-weight:700;color:#111827;"><?php echo wp_kses_post( subscrpt_format_stat_price( $metrics['average_subscription_value'] ) ); ?></div>
					<div class="subscrpt-stat-card__hint"><?php esc_html_e( 'Avg. Value', 'subscription-pro' ); ?></div>
				</div>
			</div>
		</div>

		<!-- Trial Performance -->
		<div class="wpsubs-table-card">
			<div style="padding:16px 20px;border-bottom:1px solid var(--wpsubs-border);">
				<h2 style="font-size:13px;font-weight:600;color:var(--wpsubs-text-muted);text-transform:uppercase;letter-spacing:0.07em;margin:0;"><?php esc_html_e( 'Trial Performance', 'subscription-pro' ); ?></h2>
			</div>
			<div style="padding:20px;display:grid;grid-template-columns:1fr 1fr;gap:16px;">
				<div>
					<div style="font-size:1.125rem;font-weight:700;color:#111827;"><?php echo esc_html( number_format_i18n( $trial_conversion_data['total_trials'] ) ); ?></div>
					<div class="subscrpt-stat-card__hint"><?php esc_html_e( 'Total Trials', 'subscription-pro' ); ?></div>
				</div>
				<div>
					<div style="font-size:1.125rem;font-weight:700;color:#111827;"><?php echo esc_html( number_format_i18n( $trial_conversion_data['converted_trials'] ) ); ?></div>
					<div class="subscrpt-stat-card__hint"><?php esc_html_e( 'Converted', 'subscription-pro' ); ?></div>
				</div>
				<div>
					<div style="font-size:1.125rem;font-weight:700;color:#111827;"><?php echo esc_html( number_format_i18n( $trial_conversion_data['active_trials'] ) ); ?></div>
					<div class="subscrpt-stat-card__hint"><?php esc_html_e( 'Active Trials', 'subscription-pro' ); ?></div>
				</div>
				<div>
					<div style="font-size:1.125rem;font-weight:700;color:#111827;"><?php echo wp_kses_post( subscrpt_format_stat_price( $trial_conversion_data['trial_revenue'] ) ); ?></div>
					<div class="subscrpt-stat-card__hint"><?php esc_html_e( 'Trial Revenue', 'subscription-pro' ); ?></div>
				</div>
			</div>
		</div>

		<!-- Subscription Breakdown -->
		<div class="wpsubs-table-card">
			<div style="padding:16px 20px;border-bottom:1px solid var(--wpsubs-border);">
				<h2 style="font-size:13px;font-weight:600;color:var(--wpsubs-text-muted);text-transform:uppercase;letter-spacing:0.07em;margin:0;"><?php esc_html_e( 'Subscription Breakdown', 'subscription-pro' ); ?></h2>
			</div>
			<div style="padding:20px;display:grid;grid-template-columns:1fr 1fr;gap:16px;">
				<div>
					<div style="font-size:1.125rem;font-weight:700;color:#111827;"><?php echo esc_html( number_format_i18n( $metrics['active_subscriptions'] ) ); ?></div>
					<div class="subscrpt-stat-card__hint"><?php esc_html_e( 'Active', 'subscription-pro' ); ?></div>
				</div>
				<div>
					<div style="font-size:1.125rem;font-weight:700;color:#111827;"><?php echo esc_html( number_format_i18n( $metrics['cancelled_subscriptions'] ) ); ?></div>
					<div class="subscrpt-stat-card__hint"><?php esc_html_e( 'Cancelled', 'subscription-pro' ); ?></div>
				</div>
				<div>
					<div style="font-size:1.125rem;font-weight:700;color:#111827;"><?php echo esc_html( number_format_i18n( $metrics['trial_subscriptions'] ) ); ?></div>
					<div class="subscrpt-stat-card__hint"><?php esc_html_e( 'Trials', 'subscription-pro' ); ?></div>
				</div>
				<div>
					<div style="font-size:1.125rem;font-weight:700;color:#111827;"><?php echo esc_html( number_format_i18n( $metrics['total_products'] ) ); ?></div>
					<div class="subscrpt-stat-card__hint"><?php esc_html_e( 'Products', 'subscription-pro' ); ?></div>
				</div>
			</div>
		</div>

	</div>

	<!-- Top Products + Action Items -->
	<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px;">

		<!-- Top Performing Products -->
		<div class="wpsubs-table-card">
			<div style="padding:16px 20px;border-bottom:1px solid var(--wpsubs-border);">
				<h2 style="font-size:13px;font-weight:600;color:var(--wpsubs-text-muted);text-transform:uppercase;letter-spacing:0.07em;margin:0;"><?php esc_html_e( 'Top Performing Products', 'subscription-pro' ); ?></h2>
			</div>
			<?php if ( ! empty( $popular_subscriptions ) ) : ?>
				<?php foreach ( array_slice( $popular_subscriptions, 0, 5 ) as $index => $sub_product ) : ?>
					<div style="display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 20px;border-bottom:1px solid var(--wpsubs-border);">
						<div style="display:flex;align-items:center;gap:12px;min-width:0;">
							<span style="display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;border-radius:50%;background:<?php echo $index < 3 ? '#eef2ff' : 'var(--wpsubs-surface-muted)'; ?>;color:<?php echo $index < 3 ? '#6366f1' : 'var(--wpsubs-text-muted)'; ?>;font-size:11px;font-weight:700;flex-shrink:0;">
								<?php echo esc_html( $index + 1 ); ?>
							</span>
							<div style="min-width:0;">
								<div class="wpsubs-cell-title" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?php echo esc_html( $sub_product['product_name'] ); ?></div>
								<div class="wpsubs-cell-id">
									<?php
									printf(
										/* translators: %s: number of subscriptions */
										esc_html__( '%s subscriptions', 'subscription-pro' ),
										esc_html( number_format_i18n( $sub_product['subscription_count'] ) )
									);
									?>
								</div>
							</div>
						</div>
						<div style="text-align:right;flex-shrink:0;">
							<div class="wpsubs-cell-title"><?php echo wp_kses_post( subscrpt_format_stat_price( $sub_product['total_revenue'] ) ); ?></div>
							<div class="wpsubs-cell-id">
								<?php
								printf(
									/* translators: %s: average revenue */
									esc_html__( '%s avg', 'subscription-pro' ),
									wp_kses_post( subscrpt_format_stat_price( $sub_product['average_revenue'] ) )
								);
								?>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			<?php else : ?>
				<div style="padding:40px 20px;text-align:center;">
					<div style="font-size:24px;margin-bottom:8px;">📊</div>
					<div style="font-size:13px;color:var(--wpsubs-text-muted);"><?php esc_html_e( 'No subscription data available yet.', 'subscription-pro' ); ?></div>
				</div>
			<?php endif; ?>
		</div>

		<!-- Action Items -->
		<div class="wpsubs-table-card">
			<div style="padding:16px 20px;border-bottom:1px solid var(--wpsubs-border);">
				<h2 style="font-size:13px;font-weight:600;color:var(--wpsubs-text-muted);text-transform:uppercase;letter-spacing:0.07em;margin:0;"><?php esc_html_e( 'Action Items', 'subscription-pro' ); ?></h2>
			</div>
			<div style="padding:16px 20px;display:flex;flex-direction:column;gap:12px;">

				<?php if ( $metrics['trial_conversion_rate'] < 20 ) : ?>
					<div style="padding:14px;border-radius:8px;border:1px solid #fed7aa;background:#fff7ed;">
						<div style="font-size:13px;font-weight:600;color:#9a3412;margin-bottom:6px;"><?php esc_html_e( 'Improve Trial Conversion', 'subscription-pro' ); ?></div>
						<ul style="margin:0;padding-left:16px;font-size:12px;color:#c2410c;line-height:1.8;">
							<li><?php esc_html_e( 'Enhance onboarding experience', 'subscription-pro' ); ?></li>
							<li><?php esc_html_e( 'Add value during trial period', 'subscription-pro' ); ?></li>
							<li><?php esc_html_e( 'Improve product messaging', 'subscription-pro' ); ?></li>
						</ul>
					</div>
				<?php endif; ?>

				<?php if ( $metrics['churn_rate'] > 10 ) : ?>
					<div style="padding:14px;border-radius:8px;border:1px solid #fca5a5;background:#fef2f2;">
						<div style="font-size:13px;font-weight:600;color:#991b1b;margin-bottom:6px;"><?php esc_html_e( 'Reduce Churn Rate', 'subscription-pro' ); ?></div>
						<ul style="margin:0;padding-left:16px;font-size:12px;color:#b91c1c;line-height:1.8;">
							<li><?php esc_html_e( 'Launch customer success programs', 'subscription-pro' ); ?></li>
							<li><?php esc_html_e( 'Schedule regular check-ins', 'subscription-pro' ); ?></li>
							<li><?php esc_html_e( 'Address product improvement requests', 'subscription-pro' ); ?></li>
						</ul>
					</div>
				<?php endif; ?>

				<?php if ( ! empty( $popular_subscriptions ) ) : ?>
					<div style="padding:14px;border-radius:8px;border:1px solid #86efac;background:#f0fdf4;">
						<div style="font-size:13px;font-weight:600;color:#166534;margin-bottom:6px;"><?php esc_html_e( 'Best Performers', 'subscription-pro' ); ?></div>
						<ul style="margin:0;padding-left:16px;font-size:12px;color:#15803d;line-height:1.8;">
							<li><?php echo esc_html( $popular_subscriptions[0]['product_name'] ); ?> — <?php echo wp_kses_post( subscrpt_format_stat_price( $popular_subscriptions[0]['total_revenue'] ) ); ?></li>
							<?php if ( isset( $popular_subscriptions[1] ) ) : ?>
								<li><?php echo esc_html( $popular_subscriptions[1]['product_name'] ); ?> — <?php echo wp_kses_post( subscrpt_format_stat_price( $popular_subscriptions[1]['total_revenue'] ) ); ?></li>
							<?php endif; ?>
						</ul>
					</div>
				<?php endif; ?>

				<div style="padding:14px;border-radius:8px;border:1px solid var(--wpsubs-border);background:var(--wpsubs-surface-muted);">
					<div style="font-size:13px;font-weight:600;color:var(--wpsubs-text);margin-bottom:6px;"><?php esc_html_e( 'Recommended Next Steps', 'subscription-pro' ); ?></div>
					<ul style="margin:0;padding-left:16px;font-size:12px;color:var(--wpsubs-text-muted);line-height:1.8;">
						<li><?php esc_html_e( 'Analyse customer feedback', 'subscription-pro' ); ?></li>
						<li><?php esc_html_e( 'Optimise pricing strategy', 'subscription-pro' ); ?></li>
						<li><?php esc_html_e( 'Expand product offerings', 'subscription-pro' ); ?></li>
					</ul>
				</div>

			</div>
		</div>

	</div>

	<!-- Detailed Analytics chart -->
	<div class="wpsubs-table-card">
		<div style="padding:16px 20px;border-bottom:1px solid var(--wpsubs-border);">
			<h2 style="font-size:13px;font-weight:600;color:var(--wpsubs-text-muted);text-transform:uppercase;letter-spacing:0.07em;margin:0;"><?php esc_html_e( 'Detailed Analytics', 'subscription-pro' ); ?></h2>
		</div>
		<div style="padding:20px;">
			<canvas id="detailedAnalyticsChart" style="width:100%;height:360px;"></canvas>
		</div>
	</div>

	</div><!-- /overview panel -->

	<div class="wpsubs-tab-panel" role="tabpanel" id="subscrpt-report-panel-cancellation" aria-labelledby="subscrpt-report-tab-cancellation" hidden>

	<!-- Cancellation Reasons -->
	<div class="wpsubs-table-card">
		<div style="padding:16px 20px;border-bottom:1px solid var(--wpsubs-border);">
			<h2 style="font-size:13px;font-weight:600;color:var(--wpsubs-text-muted);text-transform:uppercase;letter-spacing:0.07em;margin:0;"><?php esc_html_e( 'Cancellation Reasons', 'subscription-pro' ); ?></h2>
			<p style="font-size:12px;color:var(--wpsubs-text-muted);margin:4px 0 0;"><?php esc_html_e( 'Why customers cancelled, based on submitted feedback.', 'subscription-pro' ); ?></p>
		</div>
		<?php if ( ! empty( $cancellation_reasons['reasons'] ) ) : ?>
			<div style="padding:10px 20px 14px;">
				<?php
				foreach ( $cancellation_reasons['reasons'] as $reason_row ) :
					$reason_fill = max( 2, min( 100, (float) $reason_row['percent'] ) );
					?>
					<div style="display:flex;align-items:baseline;justify-content:space-between;gap:12px;padding:11px 14px;margin-bottom:6px;border-radius:8px;border:1px solid var(--wpsubs-border);background:linear-gradient(to left, var(--wpsubs-brand-light) 0, var(--wpsubs-brand-light) calc(<?php echo esc_attr( $reason_fill ); ?>% - 2px), var(--wpsubs-brand) calc(<?php echo esc_attr( $reason_fill ); ?>% - 2px), var(--wpsubs-brand) <?php echo esc_attr( $reason_fill ); ?>%, transparent <?php echo esc_attr( $reason_fill ); ?>%);">
						<span style="font-size:13px;font-weight:600;color:var(--wpsubs-text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0;"><?php echo esc_html( $reason_row['reason'] ); ?></span>
						<span style="flex-shrink:0;">
							<span style="font-size:14px;font-weight:700;color:var(--wpsubs-text);"><?php echo esc_html( $reason_row['percent'] ); ?>%</span>
							<span style="font-size:12px;color:var(--wpsubs-text-muted);margin-left:4px;">
								<?php
								printf(
									/* translators: %s: number of subscriptions. */
									esc_html__( '%s subs', 'subscription-pro' ),
									esc_html( number_format_i18n( $reason_row['count'] ) )
								);
								?>
							</span>
						</span>
					</div>
				<?php endforeach; ?>
			</div>
			<div style="padding:12px 20px;border-top:1px solid var(--wpsubs-border);font-size:12px;color:var(--wpsubs-text-muted);">
				<?php
				printf(
					/* translators: %s: total number of cancellations with feedback. */
					esc_html__( 'Total cancellations with feedback: %s', 'subscription-pro' ),
					esc_html( number_format_i18n( $cancellation_reasons['total'] ) )
				);
				?>
			</div>
		<?php else : ?>
			<div style="padding:40px 20px;text-align:center;">
				<div style="font-size:24px;margin-bottom:8px;">💬</div>
				<div style="font-size:13px;color:var(--wpsubs-text-muted);"><?php esc_html_e( 'No cancellation feedback collected yet.', 'subscription-pro' ); ?></div>
			</div>
		<?php endif; ?>
	</div>

	</div><!-- /cancellation panel -->
	</div><!-- /tabs -->

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
	// Main Trends Chart
	const mainCtx = document.getElementById('mainTrendsChart').getContext('2d');
	const months = <?php echo wp_json_encode( array_column( $monthly_trends, 'label' ) ); ?>;
	const revenue = <?php echo wp_json_encode( array_column( $monthly_trends, 'revenue' ) ); ?>;
	const actives = <?php echo wp_json_encode( array_column( $monthly_trends, 'active' ) ); ?>;

	new Chart(mainCtx, {
		type: 'bar',
		data: {
			labels: months,
			datasets: [
				{
					label: '<?php echo esc_js( __( 'Revenue', 'subscription-pro' ) ); ?>',
					data: revenue,
					type: 'bar',
					backgroundColor: 'rgba(99, 102, 241, 0.8)',
					borderColor: '#6366f1',
					borderWidth: 2,
					borderRadius: 6,
					borderSkipped: false,
					yAxisID: 'y1'
				},
				{
					label: '<?php echo esc_js( __( 'Active Subscriptions', 'subscription-pro' ) ); ?>',
					data: actives,
					type: 'line',
					borderColor: '#22c55e',
					backgroundColor: 'rgba(34, 197, 94, 0.1)',
					borderWidth: 3,
					fill: true,
					tension: 0.4,
					pointRadius: 6,
					pointHoverRadius: 9,
					pointBackgroundColor: '#22c55e',
					pointBorderColor: '#fff',
					pointBorderWidth: 2,
					yAxisID: 'y'
				}
			]
		},
		options: {
			responsive: true,
			interaction: { mode: 'index', intersect: false },
			plugins: {
				legend: {
					position: 'top',
					labels: { usePointStyle: true, padding: 20, font: { size: 12 } }
				},
				title: { display: false },
				tooltip: {
					backgroundColor: 'rgba(15,23,42,0.92)',
					titleColor: '#fff',
					bodyColor: '#cbd5e1',
					cornerRadius: 8,
					padding: 12,
					callbacks: {
						label: function(context) {
							if (context.dataset.yAxisID === 'y1') {
								return '<?php echo esc_js( __( 'Revenue', 'subscription-pro' ) ); ?>: $' + context.parsed.y.toLocaleString();
							}
							return '<?php echo esc_js( __( 'Active', 'subscription-pro' ) ); ?>: ' + context.parsed.y.toLocaleString();
						}
					}
				}
			},
			scales: {
				x: {
					grid: { color: 'rgba(0,0,0,0.04)', drawBorder: false },
					ticks: { font: { size: 11 }, color: '#94a3b8' }
				},
				y: {
					type: 'linear', display: true, position: 'left', beginAtZero: true,
					title: { display: true, text: '<?php echo esc_js( __( 'Active Subscriptions', 'subscription-pro' ) ); ?>', font: { size: 11 }, color: '#94a3b8' },
					grid: { color: 'rgba(0,0,0,0.04)', drawBorder: false },
					ticks: { font: { size: 11 }, color: '#94a3b8' }
				},
				y1: {
					type: 'linear', display: true, position: 'right', beginAtZero: true,
					grid: { drawOnChartArea: false },
					title: { display: true, text: '<?php echo esc_js( __( 'Revenue ($)', 'subscription-pro' ) ); ?>', font: { size: 11 }, color: '#94a3b8' },
					ticks: { font: { size: 11 }, color: '#94a3b8', callback: function(value) { return '$' + value.toLocaleString(); } }
				}
			}
		}
	});

	// Detailed Analytics Chart
	const detailedCtx = document.getElementById('detailedAnalyticsChart').getContext('2d');
	const totals = <?php echo wp_json_encode( array_column( $monthly_trends, 'total' ) ); ?>;
	const cancelled = <?php echo wp_json_encode( array_column( $monthly_trends, 'cancelled' ) ); ?>;
	const trials = <?php echo wp_json_encode( array_column( $monthly_trends, 'trials' ) ); ?>;
	const conversions = <?php echo wp_json_encode( array_column( $monthly_trends, 'conversions' ) ); ?>;

	const bubbleData = months.map(function(month, index) {
		return {
			x: index,
			y: totals[index],
			r: Math.max(5, (actives[index] / Math.max.apply(null, actives)) * 20),
			month: month,
			active: actives[index],
			cancelled: cancelled[index],
			trial: trials[index],
			conversion: conversions[index]
		};
	});

	const palette = ['#6366f1','#22c55e','#ef4444','#f59e0b','#8b5cf6','#06b6d4'];

	new Chart(detailedCtx, {
		type: 'bubble',
		data: {
			datasets: [{
				label: '<?php echo esc_js( __( 'Subscription Performance', 'subscription-pro' ) ); ?>',
				data: bubbleData,
				backgroundColor: bubbleData.map(function(_, i) { return palette[i % palette.length]; }),
				borderColor: bubbleData.map(function(_, i) { return palette[i % palette.length]; }),
				borderWidth: 2,
				hoverBorderColor: '#fff',
				hoverBorderWidth: 3
			}]
		},
		options: {
			responsive: true,
			plugins: {
				legend: { display: false },
				title: { display: false },
				tooltip: {
					backgroundColor: 'rgba(15,23,42,0.92)',
					titleColor: '#fff',
					bodyColor: '#cbd5e1',
					cornerRadius: 8,
					displayColors: false,
					padding: 12,
					callbacks: {
						title: function(context) { return context[0].raw.month; },
						label: function(context) {
							var d = context.raw;
							return [
								'<?php echo esc_js( __( 'Total', 'subscription-pro' ) ); ?>: ' + d.y,
								'<?php echo esc_js( __( 'Active', 'subscription-pro' ) ); ?>: ' + d.active,
								'<?php echo esc_js( __( 'Cancelled', 'subscription-pro' ) ); ?>: ' + d.cancelled,
								'<?php echo esc_js( __( 'Trials', 'subscription-pro' ) ); ?>: ' + d.trial,
								'<?php echo esc_js( __( 'Conversions', 'subscription-pro' ) ); ?>: ' + d.conversion
							];
						}
					}
				}
			},
			scales: {
				x: {
					type: 'linear',
					title: { display: true, text: '<?php echo esc_js( __( 'Month', 'subscription-pro' ) ); ?>', font: { size: 11 }, color: '#94a3b8' },
					ticks: {
						stepSize: 1,
						callback: function(value) { return (value >= 0 && value < months.length) ? months[value] : ''; },
						font: { size: 11 }, color: '#94a3b8'
					},
					grid: { color: 'rgba(0,0,0,0.04)', drawBorder: false }
				},
				y: {
					title: { display: true, text: '<?php echo esc_js( __( 'Total Subscriptions', 'subscription-pro' ) ); ?>', font: { size: 11 }, color: '#94a3b8' },
					ticks: { font: { size: 11 }, color: '#94a3b8' },
					grid: { color: 'rgba(0,0,0,0.04)', drawBorder: false }
				}
			}
		}
	});
});
</script>
