<?php
/**
 * Which boxes this product sells.
 *
 * Built on the same card the free plugin uses for a connected plan, because it
 * answers the same kind of question and should not look like a different
 * feature: an icon tile, the name with a link to its own screen, actions on the
 * right, and the details beneath a rule.
 *
 * The scoped style block is copied from that plan view for the same reason it
 * exists there — WooCommerce styles everything inside `.woocommerce_options_panel`
 * (floated labels, half-width number inputs) at a specificity a plain class
 * cannot beat. Neutralising it here, scoped to this row, is what keeps the card
 * looking like a card.
 *
 * This row never carries a billing cycle. How often the customer is charged
 * comes from the plan or the classic settings below; the box only decides what
 * ships.
 *
 * @var array[] $connections Rows from BoxRepository::connections_for_product().
 * @var array[] $available   Boxes this product does not sell yet.
 * @var bool    $has_cadence Whether the product bills on a schedule.
 * @var string  $boxes_url   The Boxes screen.
 * @var int     $product_id  Product being edited.
 *
 * @package SpringDevs\SubscriptionPro\Admin
 */

defined( 'ABSPATH' ) || exit;

?>
<style>
	/* WooCommerce's panel styling reaches every control in here. */
	#sdevs_subscription_options [data-subscrpt-box-connect] label {
		float: none;
		width: auto;
		margin: 0;
	}
	#sdevs_subscription_options [data-subscrpt-box-connect] input[type="number"] {
		float: none;
		width: 72px;
		min-width: 0;
	}
	#sdevs_subscription_options [data-subscrpt-box-connect] select {
		width: 240px;
		max-width: 100%;
	}
</style>

<div data-subscrpt-box-connect data-product-id="<?php echo esc_attr( $product_id ); ?>" style="margin-bottom:18px;">

	<?php if ( ! $has_cadence ) : ?>

		<?php
		/*
		 * A subscription box always recurs. Selling one from a product with no
		 * billing cycle would take the money once and never ship again, so the
		 * connection is refused rather than discovered by a customer.
		 */
		?>
		<div style="display:flex;align-items:flex-start;gap:10px;padding:14px;border-radius:8px;background:var(--wpsubs-surface-muted,#f9fafb);border:1px solid var(--wpsubs-border,#e5e7eb);">
			<span class="dashicons dashicons-warning" style="flex:0 0 auto;color:var(--wpsubs-warning,#b26200);"></span>
			<span style="font-size:13px;color:var(--wpsubs-text-muted);line-height:1.5;">
				<?php esc_html_e( 'This product has no billing cycle, so it cannot sell a box yet. A subscription box has to renew — without a cycle it would be paid for once and never ship again. Connect a plan or set a billing cycle first, for example every month.', 'subscription-pro' ); ?>
			</span>
		</div>

	<?php else : ?>

		<p data-subscrpt-lede style="margin:0 0 10px;font-size:13px;color:var(--wpsubs-text-muted);line-height:1.5;">
			<?php esc_html_e( 'The boxes this product sells. For example, a coffee product can sell a Starter box of 2 bags and a Deluxe box of 4.', 'subscription-pro' ); ?>
		</p>

		<?php if ( ! empty( $connections ) ) : ?>

			<div style="display:flex;flex-direction:column;gap:10px;margin-bottom:12px;">
				<?php foreach ( $connections as $subscrpt_row ) : ?>
					<?php
					$subscrpt_edit_url = add_query_arg(
						array(
							'view' => 'detail',
							'box'  => $subscrpt_row['box_id'],
						),
						$boxes_url
					);
					?>
					<div class="wpsubs-table-card" data-subscrpt-box-connection="<?php echo esc_attr( $subscrpt_row['id'] ); ?>" style="padding:12px 14px;">

						<div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
							<span style="flex:0 0 auto;display:inline-flex;align-items:center;justify-content:center;width:34px;height:34px;border-radius:var(--wpsubs-radius,8px);background:var(--wpsubs-brand-light,#fff1eb);color:var(--wpsubs-brand,#ff4d00);">
								<span class="dashicons dashicons-archive"></span>
							</span>

							<div style="flex:1 1 auto;min-width:0;display:flex;align-items:center;gap:8px;">
								<strong style="font-size:13.5px;color:var(--wpsubs-text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?php echo esc_html( $subscrpt_row['box_title'] ); ?></strong>

								<?php if ( 'active' !== $subscrpt_row['box_status'] ) : ?>
									<span class="wpsubs-badge wpsubs-badge--draft" style="flex:0 0 auto;"><?php esc_html_e( 'Draft', 'subscription-pro' ); ?></span>
								<?php endif; ?>

								<a href="<?php echo esc_url( $subscrpt_edit_url ); ?>" target="_blank" rel="noopener" style="flex:0 0 auto;display:inline-flex;align-items:center;gap:4px;font-size:12.5px;color:var(--wpsubs-text-muted);text-decoration:none;white-space:nowrap;">
									<span class="dashicons dashicons-external" style="font-size:15px;width:15px;height:15px;line-height:1;"></span>
									<?php esc_html_e( 'Edit in Boxes', 'subscription-pro' ); ?>
								</a>
							</div>

							<div style="flex:0 0 auto;display:flex;align-items:center;gap:8px;">
								<button type="button" class="wpsubs-btn wpsubs-btn--outline wpsubs-btn--sm" data-subscrpt-box-save-size>
									<span class="dashicons dashicons-yes" style="font-size:14px;width:14px;height:14px;line-height:1;"></span>
									<?php esc_html_e( 'Save size', 'subscription-pro' ); ?>
								</button>
								<button type="button" class="wpsubs-btn wpsubs-btn--outline wpsubs-btn--sm wpsubs-btn--danger" data-subscrpt-box-detach="<?php echo esc_attr( $subscrpt_row['id'] ); ?>">
									<?php esc_html_e( 'Detach', 'subscription-pro' ); ?>
								</button>
							</div>
						</div>

						<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:12px -14px 0;padding:12px 14px 0;border-top:1px solid var(--wpsubs-border,#e5e7eb);">
							<span style="flex:0 0 auto;white-space:nowrap;font-size:12.5px;color:var(--wpsubs-text-muted);">
								<?php esc_html_e( 'Items when sold through this product', 'subscription-pro' ); ?>
							</span>

							<input
								type="number"
								min="0"
								step="1"
								class="wpsubs-input"
								data-subscrpt-box-size="min"
								value="<?php echo esc_attr( $subscrpt_row['size']['min'] ?? '' ); ?>"
								placeholder="<?php esc_attr_e( 'min', 'subscription-pro' ); ?>"
								aria-label="<?php esc_attr_e( 'Fewest items for this product', 'subscription-pro' ); ?>"
							/>
							<span aria-hidden="true" style="color:var(--wpsubs-text-subtle);">&ndash;</span>
							<input
								type="number"
								min="0"
								step="1"
								class="wpsubs-input"
								data-subscrpt-box-size="max"
								value="<?php echo esc_attr( $subscrpt_row['size']['max'] ?? '' ); ?>"
								placeholder="<?php esc_attr_e( 'max', 'subscription-pro' ); ?>"
								aria-label="<?php esc_attr_e( 'Most items for this product', 'subscription-pro' ); ?>"
							/>

							<span style="font-size:12px;color:var(--wpsubs-text-subtle);">
								<?php esc_html_e( 'Leave empty to use the box’s own size.', 'subscription-pro' ); ?>
							</span>
						</div>

					</div>
				<?php endforeach; ?>
			</div>

		<?php else : ?>

			<div style="display:flex;align-items:flex-start;gap:10px;padding:14px;margin-bottom:12px;border-radius:8px;background:var(--wpsubs-surface-muted,#f9fafb);border:1px solid var(--wpsubs-border,#e5e7eb);">
				<span class="dashicons dashicons-archive" style="flex:0 0 auto;color:var(--wpsubs-text-subtle);"></span>
				<span style="font-size:13px;color:var(--wpsubs-text-muted);line-height:1.5;">
					<?php esc_html_e( 'Not selling a box yet. A box ships several products together on one subscription — the plan decides how often it is charged, the box decides what is in it.', 'subscription-pro' ); ?>
				</span>
			</div>

		<?php endif; ?>

		<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
			<?php if ( ! empty( $available ) ) : ?>
				<select data-subscrpt-box-picker class="wpsubs-input">
					<option value=""><?php esc_html_e( 'Choose a box…', 'subscription-pro' ); ?></option>
					<?php foreach ( $available as $subscrpt_box ) : ?>
						<option value="<?php echo esc_attr( $subscrpt_box['id'] ); ?>">
							<?php
							echo esc_html( $subscrpt_box['title'] );
							echo ' — ' . esc_html( $subscrpt_box['type_label'] );
							echo $subscrpt_box['is_draft'] ? ' (' . esc_html__( 'draft', 'subscription-pro' ) . ')' : '';
							?>
						</option>
					<?php endforeach; ?>
				</select>

				<button type="button" class="wpsubs-btn wpsubs-btn--outline wpsubs-btn--sm" data-subscrpt-box-attach>
					<span class="dashicons dashicons-plus-alt2" style="font-size:14px;width:14px;height:14px;line-height:1;"></span>
					<?php esc_html_e( 'Sell a box', 'subscription-pro' ); ?>
				</button>
			<?php endif; ?>

			<span style="flex:1 1 auto;"></span>

			<a href="<?php echo esc_url( $boxes_url ); ?>" style="font-size:12.5px;color:var(--wpsubs-text-muted);text-decoration:none;white-space:nowrap;">
				<?php esc_html_e( 'Manage boxes', 'subscription-pro' ); ?>
			</a>
		</div>

	<?php endif; ?>

</div>
