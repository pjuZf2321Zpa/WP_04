<?php
/**
 * The box panel on the subscription details screen.
 *
 * @package SpringDevs\SubscriptionPro
 *
 * @var int    $subscription_id Subscription id.
 * @var array  $contents        What the next box holds.
 * @var array  $rules           Rules this subscriber is on.
 * @var int    $lock            When changes stop.
 * @var bool   $is_locked       Whether that has passed.
 * @var string $summary         One-line contents summary.
 * @var int    $edition         Edition id, when the contents came from one.
 * @var int    $skips           Skips taken in a row.
 * @var array  $choices         product_id => name available to pick.
 * @var array  $chosen          product_id => qty currently chosen.
 */

defined( 'ABSPATH' ) || exit;

use SpringDevs\SubscriptionPro\Illuminate\Box\EditionRepository;

$subscrpt_box_edition_row = $edition ? EditionRepository::find( $edition ) : null;
?>
<div class="wp-subscription-admin-box subscrpt-box-admin">
	<h2><?php esc_html_e( 'Next box', 'subscription-pro' ); ?></h2>

	<p class="subscrpt-box-admin__summary">
		<?php echo esc_html( $summary ? $summary : __( 'Nothing chosen yet.', 'subscription-pro' ) ); ?>
	</p>

	<p class="description">
		<?php if ( $is_locked ) : ?>
			<?php esc_html_e( 'Locked — the customer can no longer change it. You still can.', 'subscription-pro' ); ?>
		<?php elseif ( $lock ) : ?>
			<?php
			printf(
				/* translators: %s: date the box locks. */
				esc_html__( 'The customer can change this until %s.', 'subscription-pro' ),
				esc_html( date_i18n( get_option( 'date_format' ), $lock ) )
			);
			?>
		<?php endif; ?>

		<?php if ( $subscrpt_box_edition_row ) : ?>
			<?php
			printf(
				/* translators: %s: edition name. */
				esc_html__( ' From the edition "%s".', 'subscription-pro' ),
				esc_html( $subscrpt_box_edition_row['title'] ? $subscrpt_box_edition_row['title'] : $subscrpt_box_edition_row['cycle_key'] )
			);
			?>
		<?php endif; ?>

		<?php if ( $skips ) : ?>
			<?php
			printf(
				/* translators: %d: number of skips in a row. */
				esc_html( _n( ' %d box skipped in a row.', ' %d boxes skipped in a row.', $skips, 'subscription-pro' ) ),
				esc_html( $skips )
			);
			?>
		<?php endif; ?>
	</p>

	<form method="post" class="subscrpt-box-admin__form">
		<?php wp_nonce_field( 'subscrpt_box_admin_' . $subscription_id, 'subscrpt_box_admin_nonce' ); ?>
		<input type="hidden" name="subscrpt_box_subscription" value="<?php echo esc_attr( $subscription_id ); ?>" />

		<?php if ( ! empty( $choices ) ) : ?>
			<table class="widefat striped subscrpt-box-admin__table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Product', 'subscription-pro' ); ?></th>
						<th class="subscrpt-box-admin__qty-col"><?php esc_html_e( 'Quantity', 'subscription-pro' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $choices as $subscrpt_box_choice_id => $subscrpt_box_choice_name ) : ?>
						<tr>
							<td>
								<label for="subscrpt-box-admin-<?php echo esc_attr( $subscrpt_box_choice_id ); ?>">
									<?php echo esc_html( $subscrpt_box_choice_name ); ?>
								</label>
							</td>
							<td>
								<input type="number" min="0" step="1"
									id="subscrpt-box-admin-<?php echo esc_attr( $subscrpt_box_choice_id ); ?>"
									name="subscrpt_box_items[<?php echo esc_attr( $subscrpt_box_choice_id ); ?>]"
									value="<?php echo esc_attr( $chosen[ $subscrpt_box_choice_id ] ?? 0 ); ?>" />
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php else : ?>
			<p class="description">
				<?php esc_html_e( 'This box is curated, so its contents come from the product rather than a pool.', 'subscription-pro' ); ?>
			</p>
		<?php endif; ?>

		<p class="subscrpt-box-admin__actions">
			<?php if ( ! empty( $choices ) ) : ?>
				<button type="submit" class="button button-primary" name="subscrpt_box_admin_action" value="save">
					<?php esc_html_e( 'Save contents', 'subscription-pro' ); ?>
				</button>
			<?php endif; ?>

			<button type="submit" class="button" name="subscrpt_box_admin_action" value="skip">
				<?php esc_html_e( 'Skip next box', 'subscription-pro' ); ?>
			</button>
		</p>
	</form>
</div>
