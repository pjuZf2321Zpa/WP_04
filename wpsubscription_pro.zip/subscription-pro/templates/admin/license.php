<?php
/**
 * License admin page.
 *
 * This template can be overridden by copying it to:
 * <your_theme>/subscription-pro/admin/license.php
 *
 * The activate/deactivate form itself is printed by the vendored SureCart
 * client — it owns the submission handling — so it is rendered here as a
 * callback rather than rebuilt. Everything around it is ours.
 *
 * Only locally stored values are shown. The licence server is not queried for
 * anything extra: this page already triggers one validation request, and adding
 * more would make it slow and make it fail when the server is unreachable.
 *
 * @package SpringDevs\SubscriptionPro
 *
 * @var bool     $subscrpt_is_active   Whether the licence is currently valid.
 * @var string   $subscrpt_masked_key  Stored licence key, masked, or ''.
 * @var callable $subscrpt_form        Prints the client's activate/deactivate form.
 */

defined( 'ABSPATH' ) || exit;

$subscrpt_is_active  = ! empty( $subscrpt_is_active );
$subscrpt_masked_key = isset( $subscrpt_masked_key ) ? (string) $subscrpt_masked_key : '';
?>

<div class="subscrpt-license-layout">

	<div class="subscrpt-license-layout__main">

		<div class="subscrpt-license-status">
			<?php if ( $subscrpt_is_active ) : ?>
				<span class="wpsubs-badge wpsubs-badge--active">
					<span class="wpsubs-badge__dot"></span>
					<?php esc_html_e( 'License active', 'subscription-pro' ); ?>
				</span>
				<p class="subscrpt-license-status__text">
					<?php esc_html_e( 'Pro features are unlocked on this site and updates are being delivered.', 'subscription-pro' ); ?>
				</p>
			<?php else : ?>
				<span class="wpsubs-badge wpsubs-badge--warning">
					<span class="wpsubs-badge__dot"></span>
					<?php esc_html_e( 'Not activated', 'subscription-pro' ); ?>
				</span>
				<p class="subscrpt-license-status__text">
					<?php esc_html_e( 'Pro features are locked and this site will not receive updates until a license is activated.', 'subscription-pro' ); ?>
				</p>
			<?php endif; ?>
		</div>

		<div class="subscrpt-license-panel">
			<?php
			if ( is_callable( $subscrpt_form ) ) {
				call_user_func( $subscrpt_form );
			}
			?>
		</div>

		<dl class="subscrpt-license-facts">
			<div class="subscrpt-license-facts__row">
				<dt><?php esc_html_e( 'This site', 'subscription-pro' ); ?></dt>
				<dd><?php echo esc_html( wp_parse_url( home_url(), PHP_URL_HOST ) ); ?></dd>
			</div>
			<?php
			/*
			 * The version constant holds the literal placeholder
			 * "#WPSUBS_PRO_VERSION" until scripts/release.sh substitutes it at
			 * package time, so in a source checkout there is no version to show
			 * and printing the constant puts the placeholder on screen. Skip the
			 * row rather than display it — a released build always has a real
			 * value here.
			 */
			if ( ! str_starts_with( (string) SUBSCRIPT_PRO_VERSION, '#' ) ) :
				?>
				<div class="subscrpt-license-facts__row">
					<dt><?php esc_html_e( 'Plugin version', 'subscription-pro' ); ?></dt>
					<dd><?php echo esc_html( SUBSCRIPT_PRO_VERSION ); ?></dd>
				</div>
				<?php
			endif;
			?>
			<?php if ( '' !== $subscrpt_masked_key ) : ?>
				<div class="subscrpt-license-facts__row">
					<dt><?php esc_html_e( 'License key', 'subscription-pro' ); ?></dt>
					<dd><code><?php echo esc_html( $subscrpt_masked_key ); ?></code></dd>
				</div>
			<?php endif; ?>
		</dl>

	</div>

	<aside class="subscrpt-license-layout__aside">

		<div class="subscrpt-license-help">
			<h2 class="subscrpt-license-help__title"><?php esc_html_e( 'Where is my license key?', 'subscription-pro' ); ?></h2>
			<p class="subscrpt-license-help__text">
				<?php esc_html_e( 'Your key was emailed to you when you purchased, and is listed under Licenses in your account.', 'subscription-pro' ); ?>
			</p>
			<a class="wpsubs-btn wpsubs-btn--outline wpsubs-btn--sm" href="https://my.wpsubscription.co/?utm_source=plugin&utm_medium=admin&utm_campaign=license" target="_blank" rel="noreferrer noopener">
				<?php esc_html_e( 'Open my account', 'subscription-pro' ); ?>
			</a>
		</div>

		<div class="subscrpt-license-help">
			<h2 class="subscrpt-license-help__title"><?php esc_html_e( 'One key, one site', 'subscription-pro' ); ?></h2>
			<p class="subscrpt-license-help__text">
				<?php esc_html_e( 'Each activation uses one seat on your license. Deactivate here before moving this key to another site, such as when replacing a staging site.', 'subscription-pro' ); ?>
			</p>
		</div>

		<div class="subscrpt-license-help">
			<h2 class="subscrpt-license-help__title"><?php esc_html_e( 'Need a hand?', 'subscription-pro' ); ?></h2>
			<ul class="subscrpt-license-help__links">
				<li>
					<a href="https://docs.wpsubscription.co/en?utm_source=plugin&utm_medium=admin&utm_campaign=license" target="_blank" rel="noreferrer noopener">
						<?php esc_html_e( 'Documentation', 'subscription-pro' ); ?>
					</a>
				</li>
				<li>
					<a href="https://wpsubscription.co/contact?utm_source=plugin&utm_medium=admin&utm_campaign=license" target="_blank" rel="noreferrer noopener">
						<?php esc_html_e( 'Contact support', 'subscription-pro' ); ?>
					</a>
				</li>
			</ul>
		</div>

	</aside>

</div>
