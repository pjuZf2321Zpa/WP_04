<?php
/**
 * Delivery Schedules page template
 *
 * @var array  $deliveries         Array of delivery post objects.
 * @var array  $available_statuses Array of available delivery statuses.
 * @var array  $status             Array of currently selected statuses.
 * @var string $date_filter        Selected date filter.
 * @var string $search             Search term.
 * @var array  $months             Array of months for date filter.
 * @var int    $page               Current page number.
 * @var int    $total_pages        Total number of pages.
 * @var int    $total_deliveries   Total number of deliveries.
 * @var int    $per_page           Number of items per page.
 *
 * @package SpringDevs\SubscriptionPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$selected_status = ! empty( $status ) ? reset( $status ) : '';
$filters_active  = ! empty( $selected_status ) || ! empty( $date_filter ) || ! empty( $search );
?>
<div class="wp-subscription-admin-content list-page">

	<?php
	wc_get_template(
		'page-header.php',
		array(
			'subscrpt_title' => __( 'Delivery Schedules', 'subscription-pro' ),
			'subscrpt_desc'  => __( 'Track and manage subscription delivery schedules.', 'subscription-pro' ),
		),
		'subscription-pro/admin/partials/',
		WP_SUBSCRIPTION_PRO_TEMPLATES . 'admin/partials/'
	);
	?>

	<?php if ( \Sdevs_Wc_Subscription_Pro::check_pro_license_or_alert() ) : ?>

	<form method="get" id="deliveries-form">
		<input type="hidden" name="page" value="wp-subscription-delivery" />

		<!-- Toolbar -->
		<div class="wpsubs-toolbar" style="margin-top:16px;">

			<?php
			$status_options = array(
				array(
					'value' => '',
					'label' => __( 'All Statuses', 'subscription-pro' ),
				),
				array(
					'value' => 'waiting',
					'label' => __( 'Waiting', 'subscription-pro' ),
				),
				array(
					'value' => 'in_process',
					'label' => __( 'In Process', 'subscription-pro' ),
				),
				array(
					'value' => 'shipped',
					'label' => __( 'Shipped', 'subscription-pro' ),
				),
				array(
					'value' => 'cancelled',
					'label' => __( 'Cancelled', 'subscription-pro' ),
				),
			);
			wpsubs_render_adv_select(
				array(
					'name'        => 'subscrpt_status',
					'value'       => $selected_status,
					'placeholder' => __( 'All Statuses', 'subscription-pro' ),
					'align'       => 'left',
					'options'     => $status_options,
				)
			);
			?>

			<?php
			$month_options = array(
				array(
					'value' => '',
					'label' => __( 'All Dates', 'subscription-pro' ),
				),
			);
			foreach ( $months as $val => $label ) {
				$month_options[] = array(
					'value' => $val,
					'label' => $label,
				);
			}
			wpsubs_render_adv_select(
				array(
					'name'        => 'date_filter',
					'value'       => $date_filter,
					'placeholder' => __( 'All Dates', 'subscription-pro' ),
					'align'       => 'left',
					'options'     => $month_options,
				)
			);
			?>

			<div class="wpsubs-search">
				<div class="wpsubs-input-wrap wpsubs-input-wrap--icon-l">
					<svg class="wpsubs-input-icon" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-4.35-4.35M17 11A6 6 0 105 11a6 6 0 0012 0z"/></svg>
					<input
						type="search"
						name="s"
						class="wpsubs-input"
						value="<?php echo esc_attr( $search ); ?>"
						placeholder="<?php esc_attr_e( 'Search by subscription ID...', 'subscription-pro' ); ?>"
					/>
				</div>
			</div>

			<button type="submit" name="filter_action" class="wpsubs-btn wpsubs-btn--outline">
				<?php esc_html_e( 'Filter', 'subscription-pro' ); ?>
			</button>

			<?php if ( $filters_active ) : ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-subscription-delivery' ) ); ?>" class="wpsubs-btn wpsubs-btn--outline">
					<?php esc_html_e( 'Clear', 'subscription-pro' ); ?>
				</a>
			<?php endif; ?>

			<div class="wpsubs-toolbar__spacer"></div>

			<?php
			wpsubs_render_per_page_select(
				array(
					'name'  => 'per_page',
					'value' => (string) $per_page,
					'align' => 'right',
				)
			);
			?>

			<button type="button" id="subscrpt-print-all" class="wpsubs-btn wpsubs-btn--outline">
				<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
				<?php esc_html_e( 'Print Addresses', 'subscription-pro' ); ?>
			</button>
			<button type="button" id="subscrpt-print-selected" class="wpsubs-btn wpsubs-btn--outline" style="display:none;">
				<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
				<?php esc_html_e( 'Print Selected', 'subscription-pro' ); ?>
			</button>

		</div>

		<h2 class="screen-reader-text"><?php esc_html_e( 'Delivery schedules list', 'subscription-pro' ); ?></h2>

		<?php
		$delivery_badge_map = array(
			'waiting'    => array(
				'mod'   => 'pending',
				'label' => __( 'Waiting', 'subscription-pro' ),
			),
			'in_process' => array(
				'mod'   => 'active',
				'label' => __( 'In Process', 'subscription-pro' ),
			),
			'shipped'    => array(
				'mod'   => 'active',
				'label' => __( 'Shipped', 'subscription-pro' ),
			),
			'cancelled'  => array(
				'mod'   => 'cancelled',
				'label' => __( 'Cancelled', 'subscription-pro' ),
			),
		);
		?>

		<div class="wpsubs-table-card">
			<table class="wpsubs-table">
				<thead>
					<tr>
						<th class="wpsubs-col--check">
							<input type="checkbox" id="subscrpt-select-all" class="wpsubs-checkbox" aria-label="<?php esc_attr_e( 'Select all rows', 'subscription-pro' ); ?>" />
						</th>
						<th><?php esc_html_e( 'Subscription', 'subscription-pro' ); ?></th>
						<th><?php esc_html_e( 'Customer', 'subscription-pro' ); ?></th>
						<th><?php esc_html_e( 'Status', 'subscription-pro' ); ?></th>
						<th class="wpsubs-col--nowrap"><?php esc_html_e( 'Shipping On', 'subscription-pro' ); ?></th>
						<th class="wpsubs-col--nowrap"><?php esc_html_e( 'Shipped On', 'subscription-pro' ); ?></th>
						<th><?php esc_html_e( 'Delivery Info', 'subscription-pro' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( ! empty( $deliveries ) ) : ?>
						<?php foreach ( $deliveries as $delivery ) : ?>
							<?php
							$subscription_id = get_post_meta( $delivery->ID, '_subscrpt_subscription_id', true );
							$order_item_id   = get_post_meta( $subscription_id, '_subscrpt_order_item_id', true );
							$order_id        = get_post_meta( $subscription_id, '_subscrpt_order_id', true );
							$order           = $order_id ? wc_get_order( $order_id ) : null; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- Included from a method, so this is a local, not the WP global.
							$order_item      = $order && $order_item_id ? $order->get_item( $order_item_id ) : null;

							$customer         = $order ? $order->get_formatted_billing_full_name() : '-';
							$customer_id      = $order ? $order->get_customer_id() : 0;
							$customer_url     = $customer_id ? admin_url( 'user-edit.php?user_id=' . $customer_id ) : '';
							$customer_email   = $order ? $order->get_billing_email() : '';
							$customer_display = trim( $customer );
							if ( '' === $customer_display || 'Unknown' === $customer_display ) {
								$customer_display = '-';
							}

							$name_parts = array_values( array_filter( explode( ' ', $customer_display ) ) );
							$initials   = '?';
							if ( $name_parts && '-' !== $customer_display ) {
								$initials = '';
								foreach ( array_slice( $name_parts, 0, 2 ) as $part ) {
									$initials .= strtoupper( $part[0] );
								}
							}
							$color_slot = ord( strtolower( $initials[0] ?? 'a' ) ) % 8;

							$product_name = $order_item ? $order_item->get_name() : '-';
							$product_id   = 0;
							$product_link = '';
							if ( $order_item && is_a( $order_item, 'WC_Order_Item_Product' ) ) {
								$variation_id = $order_item->get_variation_id();
								$product_id   = $order_item->get_product_id();
								$edit_id      = $variation_id !== 0 ? $variation_id : $product_id;
								$product_link = get_edit_post_link( $edit_id );
							}

							$subscription_link = $subscription_id ? get_edit_post_link( (int) $subscription_id ) : '';
							$shipping_date     = get_post_meta( $delivery->ID, '_subscrpt_shipping_on', true );
							$shipped_date      = get_post_meta( $delivery->ID, '_subscrpt_shipped_date', true );
							$delivery_info     = $order ? $order->get_formatted_shipping_address() : '';
							$current_status    = get_post_status( $delivery->ID );
							?>
							<tr>

								<!-- Checkbox -->
								<td class="wpsubs-col--check">
									<input
										type="checkbox"
										class="wpsubs-checkbox subscrpt-select-item"
										name="delivery_ids[]"
										value="<?php echo esc_attr( $delivery->ID ); ?>"
										<?php /* translators: %d: delivery ID. */ ?>
										aria-label="<?php echo esc_attr( sprintf( __( 'Select delivery %d', 'subscription-pro' ), $delivery->ID ) ); ?>"
									/>
								</td>

								<!-- Subscription: product name + subscription ID -->
								<td>
									<?php if ( $subscription_link ) : ?>
										<a href="<?php echo esc_url( $subscription_link ); ?>" class="wpsubs-cell-title" style="font-weight:600;" target="_blank" rel="noreferrer noopener">
											<?php echo esc_html( $product_name ); ?>
										</a>
									<?php else : ?>
										<span class="wpsubs-cell-title" style="font-weight:600;"><?php echo esc_html( $product_name ); ?></span>
									<?php endif; ?>
									<span class="wpsubs-cell-id">#<?php echo esc_html( $subscription_id ); ?></span>
								</td>

								<!-- Customer -->
								<td>
									<div class="wpsubs-customer">
										<div class="wpsubs-avatar" data-color="<?php echo (int) $color_slot; ?>">
											<?php echo esc_html( $initials ); ?>
										</div>
										<div class="wpsubs-customer__info">
											<?php if ( $customer_url ) : ?>
												<a href="<?php echo esc_url( $customer_url ); ?>" class="wpsubs-customer__name" target="_blank" rel="noreferrer noopener">
													<?php echo esc_html( $customer_display ); ?>
												</a>
											<?php else : ?>
												<span class="wpsubs-customer__name"><?php echo esc_html( $customer_display ); ?></span>
											<?php endif; ?>
											<?php if ( $customer_email ) : ?>
												<span class="wpsubs-customer__sub"><?php echo esc_html( $customer_email ); ?></span>
											<?php endif; ?>
										</div>
									</div>
								</td>

								<!-- Delivery status (editable) -->
								<td>
									<?php
									wpsubs_render_adv_select(
										array(
											'name'    => 'delivery_status_' . $delivery->ID,
											'value'   => $current_status,
											'align'   => 'left',
											'class'   => 'subscrpt-delivery-status-select',
											'attrs'   => array( 'data-delivery-id' => (string) $delivery->ID ),
											'options' => array_map(
												static function ( $key, $label ) {
													return array(
														'value' => $key,
														'label' => $label,
													);
												},
												array_keys( $available_statuses ),
												array_values( $available_statuses )
											),
										)
									);
									?>
								</td>

								<!-- Shipping on -->
								<td class="wpsubs-col--nowrap">
									<?php if ( $shipping_date ) : ?>
										<span class="wpsubs-cell-title" style="font-weight:400;"><?php echo esc_html( date_i18n( get_option( 'date_format' ), $shipping_date ) ); ?></span>
									<?php else : ?>
										<span style="color:var(--wpsubs-text-subtle);">&#8212;</span>
									<?php endif; ?>
								</td>

								<!-- Shipped on -->
								<td class="wpsubs-col--nowrap">
									<?php if ( $shipped_date ) : ?>
										<span class="wpsubs-cell-title" style="font-weight:400;"><?php echo esc_html( date_i18n( get_option( 'date_format' ), $shipped_date ) ); ?></span>
									<?php else : ?>
										<span style="color:var(--wpsubs-text-subtle);">&#8212;</span>
									<?php endif; ?>
								</td>

								<!-- Delivery info -->
								<td>
									<?php if ( $delivery_info ) : ?>
										<span class="wpsubs-cell-id" style="font-size:12px;line-height:1.5;"><?php echo wp_kses_post( $delivery_info ); ?></span>
									<?php else : ?>
										<span style="color:var(--wpsubs-text-subtle);">&#8212;</span>
									<?php endif; ?>
								</td>

							</tr>
						<?php endforeach; ?>
					<?php else : ?>
						<tr>
							<td colspan="7">
								<div class="wpsubs-empty">
									<div class="wpsubs-empty__icon">&#128666;</div>
									<p class="wpsubs-empty__title"><?php esc_html_e( 'No deliveries found.', 'subscription-pro' ); ?></p>
									<p class="wpsubs-empty__desc"><?php esc_html_e( 'No delivery schedules match your current filters.', 'subscription-pro' ); ?></p>
								</div>
							</td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>

			<!-- Pagination -->
			<?php
			$pg_base_args = array_filter(
				array(
					'page'            => 'wp-subscription-delivery',
					'subscrpt_status' => $selected_status,
					'date_filter'     => $date_filter,
					's'               => $search,
					'per_page'        => 20 !== $per_page ? $per_page : '',
				)
			);
			$pg_url       = static function ( int $p ) use ( $pg_base_args ): string {
				return esc_url( admin_url( 'admin.php?' . http_build_query( array_merge( $pg_base_args, array( 'paged' => $p ) ) ) ) );
			};

	if ( $total_pages > 1 ) :
		wpsubs_render_pager(
			array(
				'current'           => (int) $page,
				'total'             => (int) $total_pages,
				'info'              => true,
				'per_page'          => (int) $per_page,
				'item_count'        => (int) $total_deliveries,
				'link_url_callback' => $pg_url,
				'link_mode'         => 'url',
				/* translators: 1: first item, 2: last item, 3: total items */
				'info_format'       => __( 'Showing %1$s–%2$s of %3$s deliveries', 'subscription-pro' ),
				'context'           => 'subscription-pro-delivery',
			)
		);
			endif;
	?>

		</div>

	</form>

	<script>
	(function () {
		var form = document.getElementById( 'deliveries-form' );
		if ( ! form ) return;

		// Select-all checkbox
		var selectAll = document.getElementById( 'subscrpt-select-all' );
		if ( selectAll ) {
			selectAll.addEventListener( 'change', function () {
				document.querySelectorAll( '.subscrpt-select-item' ).forEach( function ( cb ) {
					cb.checked = selectAll.checked;
				} );
				updatePrintButton();
			} );
			document.querySelectorAll( '.subscrpt-select-item' ).forEach( function ( cb ) {
				cb.addEventListener( 'change', function () {
					var total   = document.querySelectorAll( '.subscrpt-select-item' ).length;
					var checked = document.querySelectorAll( '.subscrpt-select-item:checked' ).length;
					selectAll.indeterminate = checked > 0 && checked < total;
					selectAll.checked      = checked === total;
					updatePrintButton();
				} );
			} );
		}

		function updatePrintButton() {
			var checked = document.querySelectorAll( '.subscrpt-select-item:checked' ).length;
			var btnAll  = document.getElementById( 'subscrpt-print-all' );
			var btnSel  = document.getElementById( 'subscrpt-print-selected' );
			if ( btnAll && btnSel ) {
				btnAll.style.display = checked > 0 ? 'none' : '';
				btnSel.style.display = checked > 0 ? '' : 'none';
			}
		}

		// Auto-submit on per-page change
		document.addEventListener( 'wpsubs:select', function ( e ) {
			var hiddenInput = e.target && e.target.querySelector( 'input[type="hidden"]' );
			if ( ! hiddenInput ) return;
			if ( hiddenInput.name === 'per_page' ) {
				form.submit();
			}
		} );
	} )();
	</script>

	<?php endif; ?>

</div>
