<?php
/**
 * Subscription Health admin page template.
 *
 * @package SpringDevs\SubscriptionPro
 *
 * Variables set by Recovery::render_recovery_page():
 * @var array  $subscriptions  Broken subscription data arrays.
 * @var float  $revenue        Revenue at risk.
 * @var array  $issue_counts   Count per filter key.
 * @var string $filter         Active filter slug.
 * @var string $currency       WooCommerce currency symbol.
 *
 * Each $subscriptions item provides:
 *   id, customer_id, product_id, product_name, customer_name, customer_email,
 *   issue_type, status, price, billing_period, renewal_date,
 *   last_order_id, renewal_created, days_since, failure_count, next_retry, grace_end.
 */

defined( 'ABSPATH' ) || exit;


$subscriptions = isset( $subscriptions ) && is_array( $subscriptions ) ? $subscriptions : array();
$issue_counts  = isset( $issue_counts ) && is_array( $issue_counts ) ? $issue_counts : array();
$filter        = isset( $filter ) ? sanitize_key( $filter ) : 'all';
$revenue       = isset( $revenue ) ? (float) $revenue : 0.0;
$currency      = isset( $currency ) ? (string) $currency : '';

// phpcs:disable WordPress.Security.NonceVerification.Recommended,Generic.Formatting.MultipleStatementAlignment.NotSameWarning
$selected_issue     = isset( $filter ) ? sanitize_key( $filter ) : 'all';
$search_term        = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
$per_page           = isset( $_GET['per_page'] ) ? (int) $_GET['per_page'] : 20; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- Included from Health::render_recovery_page(), which passes $per_page in; method scope, not the WP global.
$active_form_filter = ( 'all' !== $selected_issue && '' !== $selected_issue ) || '' !== $search_term;
// phpcs:enable WordPress.Security.NonceVerification.Recommended,Generic.Formatting.MultipleStatementAlignment.NotSameWarning

$issue_badge_map = array(
	'failed_payment'  => array(
		'mod'     => 'expired',
		'label'   => __( 'Payment failed', 'subscription-pro' ),
		'tooltip' => __( 'The last payment attempt was declined or could not be processed.', 'subscription-pro' ),
	),
	'overdue_renewal' => array(
		'mod'     => 'pending-cancel',
		'label'   => __( 'Overdue renewal', 'subscription-pro' ),
		'tooltip' => __( 'The renewal date passed and no renewal order was created in time.', 'subscription-pro' ),
	),
	'retry_needed'    => array(
		'mod'     => 'pending',
		'label'   => __( 'Retry needed', 'subscription-pro' ),
		'tooltip' => __( 'A payment failed and the subscription still needs another retry attempt.', 'subscription-pro' ),
	),
	'stalled_renewal' => array(
		'mod'     => 'cancelled',
		'label'   => __( 'Stalled renewal', 'subscription-pro' ),
		'tooltip' => __( 'A renewal order exists but it has stayed pending for too long.', 'subscription-pro' ),
	),
	'skipped'         => array(
		'mod'     => 'cancelled',
		'label'   => __( 'Skipped', 'subscription-pro' ),
		'tooltip' => __( 'Manually excluded from the health queue by an admin.', 'subscription-pro' ),
	),
);

$is_skipped_view = 'skipped' === $filter;

$total_items    = (int) count( $subscriptions );
$total_all_subs = (int) array_sum( (array) wp_count_posts( 'subscrpt_order' ) );
$has_items      = ! empty( $subscriptions );
$at_risk_text   = $currency . number_format_i18n( $revenue, 2 );

$format_datetime = static function ( int $timestamp ) {
	if ( $timestamp <= 0 ) {
		return '—';
	}
	return date_i18n( get_option( 'date_format' ) . ' · ' . get_option( 'time_format' ), $timestamp );
};

$subscrpt_page_title = __( 'Subscription Health', 'subscription-pro' );
$subscrpt_page_desc  = __( 'Monitor and recover subscriptions that need attention.', 'subscription-pro' );
$subscrpt_page_docs  = 'https://docs.wpsubscription.co/en/wpsubscription-subscription-health?utm_source=plugin&utm_medium=admin&utm_campaign=docs';

// License check.
//
// The wrapper classes must match the licensed branch below, and both branches
// must render the same header — previously this one used `wp-heading-inline`
// while the licensed branch used an inline-styled 1.375rem title, so the page
// looked like a different page depending on the licence.
if ( ! \Sdevs_Wc_Subscription_Pro::check_pro_license_or_alert( false, false ) ) {
	?>
	<div class="wp-subscription-admin-content list-page">
		<?php
		wc_get_template(
			'page-header.php',
			array(
				'subscrpt_title'   => $subscrpt_page_title,
				'subscrpt_desc'    => $subscrpt_page_desc,
				'subscrpt_doc_url' => $subscrpt_page_docs,
			),
			'subscription-pro/admin/partials/',
			WP_SUBSCRIPTION_PRO_TEMPLATES . 'admin/partials/'
		);
		\Sdevs_Wc_Subscription_Pro::check_pro_license_or_alert();
		?>
	</div>
	<?php
	return;
}
?>

<div class="wp-subscription-admin-content list-page">

	<?php
	$transient_timeout = get_option( '_transient_timeout_subscrpt_recovery_all' );
	$last_fetched      = $transient_timeout ? (int) $transient_timeout - 15 * MINUTE_IN_SECONDS : 0;
	$refresh_url       = wp_nonce_url( add_query_arg( '_refresh', '1' ), 'subscrpt_health_refresh', '_refresh' );

	ob_start();
	if ( $last_fetched > 0 ) :
		?>
		<span class="subscrpt-page-header__meta-text">
			<?php
			printf(
				/* translators: %s: human-readable time difference */
				esc_html__( 'Updated %s ago', 'subscription-pro' ),
				esc_html( human_time_diff( $last_fetched ) )
			);
			?>
		</span>
		<?php
	endif;
	?>
	<a href="<?php echo esc_url( $refresh_url ); ?>" class="wpsubs-btn wpsubs-btn--outline wpsubs-btn--sm">
		<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
		<?php esc_html_e( 'Refresh', 'subscription-pro' ); ?>
	</a>
	<?php
	$subscrpt_header_meta = ob_get_clean();

	ob_start();
	?>
	<div class="subscrpt-stat-card">
		<div class="subscrpt-stat-card__row">
			<div class="subscrpt-stat-card__value"><?php echo esc_html( number_format_i18n( isset( $total_filtered ) ? $total_filtered : $total_items ) ); ?></div>
			<span class="subscrpt-stat-card__icon subscrpt-stat-card__icon--indigo">
				<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>
			</span>
		</div>
		<div class="subscrpt-stat-card__label"><?php esc_html_e( 'Subscriptions', 'subscription-pro' ); ?></div>
		<div class="subscrpt-stat-card__hint"><?php esc_html_e( 'are at risk zone', 'subscription-pro' ); ?></div>
	</div>
	<div class="subscrpt-stat-card subscrpt-stat-card--wide">
		<div class="subscrpt-stat-card__row">
			<div class="subscrpt-stat-card__value subscrpt-stat-card__value--danger"><?php echo esc_html( $at_risk_text ); ?></div>
			<span class="subscrpt-stat-card__icon subscrpt-stat-card__icon--danger">
				<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" /></svg>
			</span>
		</div>
		<div class="subscrpt-stat-card__label"><?php esc_html_e( 'Revenue at Risk', 'subscription-pro' ); ?></div>
		<div class="subscrpt-stat-card__hint"><?php esc_html_e( 'Across active issues', 'subscription-pro' ); ?></div>
	</div>
	<?php
	$subscrpt_header_aside = ob_get_clean();

	wc_get_template(
		'page-header.php',
		array(
			'subscrpt_title'   => $subscrpt_page_title,
			'subscrpt_desc'    => $subscrpt_page_desc,
			'subscrpt_doc_url' => $subscrpt_page_docs,
			'subscrpt_meta'    => $subscrpt_header_meta,
			'subscrpt_aside'   => $subscrpt_header_aside,
		),
		'subscription-pro/admin/partials/',
		WP_SUBSCRIPTION_PRO_TEMPLATES . 'admin/partials/'
	);
	?>

	<form method="get" id="subscrpt-recovery-form" style="margin-bottom:0;">
		<input type="hidden" name="page" value="wp-subscription-health" />

		<!-- Toolbar -->
		<div class="wpsubs-toolbar" style="margin-top:16px;">

			<?php
			$skipped_count = $issue_counts['skipped'] ?? 0;
			wpsubs_render_adv_select(
				array(
					'name'        => 'filter',
					'value'       => $selected_issue,
					'placeholder' => __( 'All issues', 'subscription-pro' ),
					'align'       => 'left',
					'options'     => array(
						array(
							'value' => 'all',
							'label' => __( 'All issues', 'subscription-pro' ),
						),
						array(
							'value' => 'overdue_renewal',
							'label' => __( 'Overdue Renewal', 'subscription-pro' ),
						),
						array(
							'value' => 'failed_payment',
							'label' => __( 'Failed Payment', 'subscription-pro' ),
						),
						array(
							'value' => 'retry_needed',
							'label' => __( 'Retry Needed', 'subscription-pro' ),
						),
						array(
							'value' => 'stalled_renewal',
							'label' => __( 'Stalled Renewal', 'subscription-pro' ),
						),
						array(
							'value' => 'skipped',
							/* translators: %d: number of skipped subscriptions */
							'label' => $skipped_count > 0 ? sprintf( __( 'Skipped (%d)', 'subscription-pro' ), $skipped_count ) : __( 'Skipped', 'subscription-pro' ),
						),
					),
				)
			);
			?>

			<div class="wpsubs-search">
				<div class="wpsubs-input-wrap wpsubs-input-wrap--icon-l">
					<svg class="wpsubs-input-icon" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-4.35-4.35M17 11A6 6 0 105 11a6 6 0 0012 0z"/></svg>
					<input
						id="subscrpt-search"
						type="search"
						name="s"
						class="wpsubs-input"
						value="<?php echo esc_attr( $search_term ); ?>"
						placeholder="<?php esc_attr_e( 'Search ID, product, customer...', 'subscription-pro' ); ?>"
					/>
				</div>
			</div>

			<button type="submit" name="filter_action" class="wpsubs-btn wpsubs-btn--outline">
				<?php esc_html_e( 'Filter', 'subscription-pro' ); ?>
			</button>

			<?php if ( $active_form_filter ) : ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-subscription-health' ) ); ?>" class="wpsubs-btn wpsubs-btn--outline">
					<?php esc_html_e( 'Reset', 'subscription-pro' ); ?>
				</a>
			<?php endif; ?>

			<div class="wpsubs-toolbar__spacer"></div>

			<?php
			wpsubs_render_per_page_select(
				array(
					'name'  => 'per_page',
					'value' => (string) $per_page,
					'align' => 'right',
				)
			);
			?>

			<?php
			// Bulk action select — rightmost, triggers directly on selection
			$bulk_options = array(
				array(
					'value' => 'create_renewal',
					'label' => __( 'Create Renewal', 'subscription-pro' ),
				),
				array(
					'value' => 'retry',
					'label' => __( 'Retry Payment', 'subscription-pro' ),
				),
				array(
					'value' => 'send_email',
					'label' => __( 'Send Email', 'subscription-pro' ),
				),
				array( 'divider' => true ),
				$is_skipped_view
					? array(
						'value' => 'unskip',
						'label' => __( 'Unskip', 'subscription-pro' ),
					)
					: array(
						'value'  => 'skip',
						'label'  => __( 'Skip', 'subscription-pro' ),
						'danger' => true,
					),
			);
			wpsubs_render_adv_select(
				array(
					'id'          => 'subscrpt-bulk-action',
					'name'        => 'bulk_action',
					'value'       => '',
					'placeholder' => __( 'Bulk actions', 'subscription-pro' ),
					'align'       => 'right',
					'options'     => $bulk_options,
				)
			);

			$export_url = wp_nonce_url(
				add_query_arg(
					array(
						'action' => 'subscrpt_recovery_export',
						'filter' => ( 'all' !== $selected_issue && '' !== $selected_issue ) ? $selected_issue : 'all',
					),
					admin_url( 'admin-post.php' )
				),
				'subscrpt_recovery_export'
			);
			?>

			<a href="<?php echo esc_url( $export_url ); ?>" class="wpsubs-btn wpsubs-btn--outline" style="white-space:nowrap;">
				<svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true" style="flex-shrink:0;"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
				<?php esc_html_e( 'Export CSV', 'subscription-pro' ); ?>
			</a>
		</div>

		<h2 class="screen-reader-text"><?php esc_html_e( 'Health subscriptions list', 'subscription-pro' ); ?></h2>

		<div class="wpsubs-table-card">
			<table class="wpsubs-table">
				<thead>
					<tr>
						<th class="wpsubs-col--check">
							<input type="checkbox" id="subscrpt-select-all" class="wpsubs-checkbox" aria-label="<?php esc_attr_e( 'Select all rows', 'subscription-pro' ); ?>" />
						</th>
						<th><?php esc_html_e( 'Subscription', 'subscription-pro' ); ?></th>
						<th><?php esc_html_e( 'Customer', 'subscription-pro' ); ?></th>
						<th style="white-space:nowrap;"><?php esc_html_e( 'Amount', 'subscription-pro' ); ?></th>
						<th class="wpsubs-col--nowrap"><?php esc_html_e( 'Renew Date', 'subscription-pro' ); ?></th>
						<th><?php esc_html_e( 'Renewal Order', 'subscription-pro' ); ?></th>
						<th><?php esc_html_e( 'Issue', 'subscription-pro' ); ?></th>
						<th class="wpsubs-col--actions"><?php esc_html_e( 'Actions', 'subscription-pro' ); ?></th>
					</tr>
				</thead>

				<tbody>
					<?php if ( $has_items ) : ?>
						<?php foreach ( $subscriptions as $subscription ) : ?>
							<?php
							$subscription_item = is_array( $subscription ) ? $subscription : ( is_object( $subscription ) ? get_object_vars( $subscription ) : array() );

							if ( is_object( $subscription ) && isset( $subscription->ID ) ) {
								$subscription_id   = (int) $subscription->ID;
								$subscription_data = class_exists( '\\SpringDevs\\Subscription\\Illuminate\\Helper' ) ? \SpringDevs\Subscription\Illuminate\Helper::get_subscription_data( $subscription_id ) : array();
							} else {
								$subscription_id   = (int) ( $subscription_item['id'] ?? 0 );
								$subscription_data = class_exists( '\\SpringDevs\\Subscription\\Illuminate\\Helper' ) ? \SpringDevs\Subscription\Illuminate\Helper::get_subscription_data( $subscription_id ) : array();
							}

							$product_id      = (int) ( $subscription_item['product_id'] ?? 0 );
							$product_name    = (string) ( $subscription_item['product_name'] ?? '-' );
							$issue_type      = (string) ( $subscription_item['issue_type'] ?? 'unknown' );
							$amount          = (float) ( $subscription_item['price'] ?? 0 );
							$billing_period  = (string) ( $subscription_item['billing_period'] ?? '' );
							$renewal_date    = (int) ( $subscription_item['renewal_date'] ?? 0 );
							$last_order_id   = (int) ( $subscription_item['last_order_id'] ?? 0 );
							$renewal_created = (bool) ( $subscription_item['renewal_created'] ?? false );
							$days_since      = (int) ( $subscription_item['days_since'] ?? 0 );

							$subscrpt_status = $subscription_data['status'] ?? '';
							$subscrpt_status = empty( $subscrpt_status ) ? get_post_status( $subscription_id ) : $subscrpt_status;

							$order_id      = $subscription_data['order']['order_id'] ?? 0;
							$order_item_id = $subscription_data['order']['order_item_id'] ?? 0;
							$order         = $order_id ? wc_get_order( $order_id ) : null; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
							$order_item    = $order ? $order->get_item( $order_item_id ) : null;
							$product_name  = $order_item ? $order_item->get_name() : $product_name;

							$customer       = $order ? $order->get_formatted_billing_full_name() : ( (string) ( $subscription_item['customer_name'] ?? '-' ) );
							$customer_id    = $order ? $order->get_customer_id() : 0;
							$customer_url   = $customer_id ? admin_url( 'user-edit.php?user_id=' . $customer_id ) : '';
							$customer_email = $order ? $order->get_billing_email() : ( (string) ( $subscription_item['customer_email'] ?? '' ) );

							$renewal_date = $subscription_data['next_date'] ? strtotime( $subscription_data['next_date'] ) : 0;

							$is_grace_period = isset( $subscription_data['grace_period'] ); // phpcs:ignore Generic.Formatting.MultipleStatementAlignment.NotSameWarning
							$grace_remaining = $subscription_data['grace_period']['remaining_days'] ?? 0; // phpcs:ignore Generic.Formatting.MultipleStatementAlignment.NotSameWarning

							$customer_display = trim( $customer );
							if ( '' === $customer_display || 'Unknown' === $customer_display || 'Unknown customer' === $customer_display ) {
								$customer_display = '-';
							}

							// Avatar initials.
							$name_parts = array_values( array_filter( explode( ' ', $customer_display ) ) );
							$initials   = '?';
							if ( $name_parts && '-' !== $customer_display ) {
								$initials = '';
								foreach ( array_slice( $name_parts, 0, 2 ) as $part ) {
									$initials .= strtoupper( $part[0] );
								}
							}
							$color_slot = ord( strtolower( $initials[0] ?? 'a' ) ) % 8;

							// Issue badge config.
							$issue_cfg = $issue_badge_map[ $issue_type ] ?? array(
								'mod'     => 'cancelled',
								'label'   => ucwords( str_replace( '_', ' ', $issue_type ) ),
								'tooltip' => ucwords( str_replace( '_', ' ', $issue_type ) ),
							);

							// Renewal date color based on overdue days.
							if ( $days_since > 14 ) {
								$date_style = 'color:#dc2626;';
							} elseif ( $days_since > 7 ) {
								$date_style = 'color:#f97316;';
							} else {
								$date_style = '';
							}

							$renewal_title = $days_since > 0 ? sprintf(
								/* translators: %d: Number of days overdue. */
								__( '%d days overdue', 'subscription-pro' ),
								$days_since
							) : '';
							?>
							<tr data-row-id="<?php echo esc_attr( $subscription_id ); ?>">

								<!-- Checkbox -->
								<td class="wpsubs-col--check">
									<input
										type="checkbox"
										class="wpsubs-checkbox subscrpt-row-cb"
										value="<?php echo esc_attr( $subscription_id ); ?>"
										<?php /* translators: %d: subscription ID. */ ?>
										aria-label="<?php echo esc_attr( sprintf( __( 'Select subscription %d', 'subscription-pro' ), $subscription_id ) ); ?>"
									/>
								</td>

								<!-- Subscription: product name + subscription ID -->
								<td>
									<a href="<?php echo esc_url( get_edit_post_link( $subscription_id ) ); ?>" class="wpsubs-cell-title" style="font-weight:600;" target="_blank" rel="noreferrer noopener">
										<?php echo esc_html( $product_name ); ?>
									</a>
									<span class="wpsubs-cell-id">#<?php echo esc_html( $subscription_id ); ?></span>
								</td>

								<!-- Customer avatar + name + email -->
								<td>
									<div class="wpsubs-customer">
										<div class="wpsubs-avatar" data-color="<?php echo (int) $color_slot; ?>">
											<?php echo esc_html( $initials ); ?>
										</div>
										<div class="wpsubs-customer__info">
											<?php if ( $customer_url ) : ?>
												<a href="<?php echo esc_url( $customer_url ); ?>" class="wpsubs-customer__name" target="_blank" rel="noreferrer noopener">
													<?php echo esc_html( $customer_display ); ?>
												</a>
											<?php else : ?>
												<span class="wpsubs-customer__name"><?php echo esc_html( $customer_display ); ?></span>
											<?php endif; ?>
											<?php if ( $customer_email ) : ?>
												<span class="wpsubs-customer__sub"><?php echo esc_html( $customer_email ); ?></span>
											<?php endif; ?>
										</div>
									</div>
								</td>

								<!-- Amount + billing period -->
								<td style="white-space:nowrap;">
									<span class="wpsubs-cell-title" style="font-variant-numeric:tabular-nums;"><?php echo esc_html( $currency . number_format_i18n( $amount, 2 ) ); ?></span>
									<?php if ( $billing_period ) : ?>
										<span class="wpsubs-cell-id">/ <?php echo esc_html( $billing_period ); ?></span>
									<?php endif; ?>
								</td>

								<!-- Renewal date -->
								<td class="wpsubs-col--nowrap" <?php echo $renewal_title ? 'title="' . esc_attr( $renewal_title ) . '"' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from esc_attr(). ?>>
									<?php if ( $renewal_date ) : ?>
										<span class="wpsubs-cell-title" style="font-weight:400;<?php echo esc_attr( $date_style ); ?>"><?php echo esc_html( wp_date( get_option( 'date_format' ), $renewal_date ) ); ?></span>
										<span class="wpsubs-cell-id"><?php echo esc_html( wp_date( get_option( 'time_format' ), $renewal_date ) ); ?></span>
									<?php else : ?>
										<span style="color:var(--wpsubs-text-subtle);">&#8212;</span>
									<?php endif; ?>
								</td>

								<!-- Renewal order -->
								<td>
									<?php if ( $renewal_created && $last_order_id ) : ?>
										<a href="<?php echo esc_url( get_edit_post_link( $last_order_id ) ); ?>" class="wpsubs-cell-title" target="_blank" rel="noreferrer noopener">#<?php echo esc_html( $last_order_id ); ?></a>
									<?php else : ?>
										<span class="wpsubs-badge wpsubs-badge--cancelled"><?php esc_html_e( 'Not created', 'subscription-pro' ); ?></span>
									<?php endif; ?>
								</td>

								<!-- Issue badge -->
								<td>
									<span
										class="wpsubs-badge wpsubs-badge--<?php echo esc_attr( $issue_cfg['mod'] ); ?>"
										<?php if ( ! empty( $issue_cfg['tooltip'] ) ) : ?>
											title="<?php echo esc_attr( $issue_cfg['tooltip'] ); ?>"
										<?php endif; ?>
									>
										<?php echo esc_html( $issue_cfg['label'] ); ?>
									</span>
								</td>

								<!-- Actions -->
								<td class="wpsubs-cell--actions" data-actions-cell="<?php echo esc_attr( $subscription_id ); ?>">
									<div class="wpsubs-row-actions">
										<button type="button" class="wpsubs-row-actions__trigger" aria-label="<?php esc_attr_e( 'Row actions', 'subscription-pro' ); ?>">···</button>
										<div class="wpsubs-dropdown">
											<button type="button" class="wpsubs-dropdown__item" data-row-action="create_renewal" data-subscription-id="<?php echo esc_attr( $subscription_id ); ?>" <?php echo ( $renewal_created || $last_order_id > 0 ) ? 'disabled' : ''; ?>>
												<?php esc_html_e( 'Create Renewal', 'subscription-pro' ); ?>
											</button>
											<button type="button" class="wpsubs-dropdown__item" data-row-action="retry" data-subscription-id="<?php echo esc_attr( $subscription_id ); ?>" <?php echo ! $renewal_created ? 'data-disabled' : ''; ?>>
												<?php esc_html_e( 'Retry Payment', 'subscription-pro' ); ?>
											</button>
											<button type="button" class="wpsubs-dropdown__item" data-row-action="send_email" data-subscription-id="<?php echo esc_attr( $subscription_id ); ?>">
												<?php esc_html_e( 'Send Email', 'subscription-pro' ); ?>
											</button>
											<div class="wpsubs-dropdown__divider"></div>
											<?php if ( $is_skipped_view ) : ?>
												<button type="button" class="wpsubs-dropdown__item" data-row-action="unskip" data-subscription-id="<?php echo esc_attr( $subscription_id ); ?>">
													<?php esc_html_e( 'Unskip', 'subscription-pro' ); ?>
												</button>
											<?php else : ?>
												<button type="button" class="wpsubs-dropdown__item wpsubs-dropdown__item--danger" data-row-action="skip" data-subscription-id="<?php echo esc_attr( $subscription_id ); ?>">
													<?php esc_html_e( 'Skip', 'subscription-pro' ); ?>
												</button>
											<?php endif; ?>
										</div>
									</div>
								</td>

							</tr>
						<?php endforeach; ?>
					<?php else : ?>
						<tr>
							<td colspan="8">
								<div class="wpsubs-empty">
									<div class="wpsubs-empty__icon">&#10003;</div>
									<p class="wpsubs-empty__title"><?php esc_html_e( 'All clear!', 'subscription-pro' ); ?></p>
									<p class="wpsubs-empty__desc"><?php esc_html_e( 'No subscriptions found in the health queue right now.', 'subscription-pro' ); ?></p>
								</div>
							</td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>

			<?php
			// Pagination vars passed from render_recovery_page().
			$pg_current  = isset( $current_page ) ? (int) $current_page : 1;
			$pg_total    = isset( $total_pages ) ? (int) $total_pages : 1;
			$pg_filtered = isset( $total_filtered ) ? (int) $total_filtered : $total_items;

			$pg_base_args = array_filter(
				array(
					'page'     => 'wp-subscription-health',
					'filter'   => ( 'all' !== $selected_issue && '' !== $selected_issue ) ? $selected_issue : '',
					's'        => $search_term,
					'per_page' => 20 !== $per_page ? $per_page : '',
				)
			);

			$pg_url = static function ( int $p ) use ( $pg_base_args ): string {
				return esc_url( admin_url( 'admin.php?' . http_build_query( array_merge( $pg_base_args, array( 'paged' => $p ) ) ) ) );
			};

			$pg_from = min( $pg_filtered, ( $pg_current - 1 ) * $per_page + 1 );
			$pg_to   = min( $pg_filtered, $pg_current * $per_page );
			?>
			<?php
			if ( $pg_total > 1 ) :
				wpsubs_render_pager(
					array(
						'current'           => $pg_current,
						'total'             => $pg_total,
						'info'              => true,
						'per_page'          => (int) $per_page,
						'item_count'        => (int) $pg_filtered,
						'link_url_callback' => $pg_url,
						'link_mode'         => 'url',
						/* translators: 1: first item, 2: last item, 3: total items */
						'info_format'       => __( 'Showing %1$s–%2$s of %3$s health issues', 'subscription-pro' ),
						'context'           => 'subscription-pro-health',
					)
				);
			endif;
			?>
		</div>

	</form>

</div>

<script>
(function () {
	var form = document.getElementById( 'subscrpt-recovery-form' );
	if ( ! form ) return;

	// Select-all checkbox
	var selectAll = document.getElementById( 'subscrpt-select-all' );
	if ( selectAll ) {
		selectAll.addEventListener( 'change', function () {
			document.querySelectorAll( '.subscrpt-row-cb' ).forEach( function ( cb ) {
				cb.checked = selectAll.checked;
			} );
		} );
		document.querySelectorAll( '.subscrpt-row-cb' ).forEach( function ( cb ) {
			cb.addEventListener( 'change', function () {
				var total   = document.querySelectorAll( '.subscrpt-row-cb' ).length;
				var checked = document.querySelectorAll( '.subscrpt-row-cb:checked' ).length;
				selectAll.indeterminate = checked > 0 && checked < total;
				selectAll.checked      = checked === total;
			} );
		} );
	}

	// Auto-submit on per-page change; bulk action handled by health-actions.js
	document.addEventListener( 'wpsubs:select', function ( e ) {
		var hiddenInput = e.target && e.target.querySelector( 'input[type="hidden"]' );
		if ( ! hiddenInput ) return;
		if ( hiddenInput.name === 'per_page' ) {
			form.submit();
		}
	} );

	// Row-actions dropdown open/close
	function closeAllRowMenus() {
		document.querySelectorAll( '.wpsubs-row-actions--open' ).forEach( function ( el ) {
			el.classList.remove( 'wpsubs-row-actions--open' );
			var d = el.querySelector( '.wpsubs-dropdown' );
			if ( d ) d.classList.remove( 'wpsubs-dropdown--open' );
		} );
	}

	document.addEventListener( 'click', function ( e ) {
		var trigger = e.target.closest( '.wpsubs-row-actions__trigger' );

		document.querySelectorAll( '.wpsubs-row-actions--open' ).forEach( function ( el ) {
			if ( el !== ( trigger && trigger.closest( '.wpsubs-row-actions' ) ) ) {
				el.classList.remove( 'wpsubs-row-actions--open' );
				var d = el.querySelector( '.wpsubs-dropdown' );
				if ( d ) d.classList.remove( 'wpsubs-dropdown--open' );
			}
		} );

		if ( ! trigger ) return;
		e.stopPropagation();

		var wrapper  = trigger.closest( '.wpsubs-row-actions' );
		var dropdown = wrapper && wrapper.querySelector( '.wpsubs-dropdown' );
		if ( ! wrapper || ! dropdown ) return;

		var isOpen = wrapper.classList.contains( 'wpsubs-row-actions--open' );
		wrapper.classList.toggle( 'wpsubs-row-actions--open', ! isOpen );
		dropdown.classList.toggle( 'wpsubs-dropdown--open', ! isOpen );
	} );

	document.addEventListener( 'keydown', function ( e ) {
		if ( e.key === 'Escape' ) closeAllRowMenus();
	} );
} )();
</script>
