<?php
/**
 * Shared page header for WPSubscription Pro admin pages.
 *
 * This template can be overridden by copying it to:
 * <your_theme>/subscription-pro/admin/partials/page-header.php
 *
 * There is one header for the whole product — the free plugin's
 * `wpsubs_render_page_header()` component (assets/css/admin-components/
 * page-header.css). This partial is a thin adapter so Pro's pages render through
 * that same component: it maps Pro's `meta` row to the component's action slot
 * and passes the stat-card `aside` and docs link straight through.
 *
 * @package SpringDevs\SubscriptionPro
 *
 * Variable names are prefixed because `$title` is a WordPress global — the admin
 * header uses it — and assigning to it from a template can clobber it.
 *
 * @var string $subscrpt_title   Page title.
 * @var string $subscrpt_desc    Optional description.
 * @var string $subscrpt_doc_url Optional documentation URL appended to the description.
 * @var string $subscrpt_meta    Optional HTML for the action slot (updated time, refresh).
 * @var string $subscrpt_aside   Optional HTML for the right-hand column (stat cards).
 *
 * $subscrpt_meta and $subscrpt_aside pass through wp_kses() with an allowlist that
 * includes the SVG elements the admin icons use — wp_kses_post() would strip them.
 */

defined( 'ABSPATH' ) || exit;

$subscrpt_title   = isset( $subscrpt_title ) ? (string) $subscrpt_title : '';
$subscrpt_desc    = isset( $subscrpt_desc ) ? (string) $subscrpt_desc : '';
$subscrpt_doc_url = isset( $subscrpt_doc_url ) ? (string) $subscrpt_doc_url : '';
$subscrpt_meta    = isset( $subscrpt_meta ) ? (string) $subscrpt_meta : '';
$subscrpt_aside   = isset( $subscrpt_aside ) ? (string) $subscrpt_aside : '';

// The component lives in the free plugin, which is a hard dependency; guard only
// so a broken install degrades to a bare title rather than fataling.
if ( ! function_exists( 'wpsubs_render_page_header' ) ) {
	echo '<h1>' . esc_html( $subscrpt_title ) . '</h1>';
	return;
}

wpsubs_render_page_header(
	array(
		'title'       => $subscrpt_title,
		'description' => $subscrpt_desc,
		'doc_url'     => $subscrpt_doc_url,
		'actions'     => '' !== $subscrpt_meta ? wp_kses( $subscrpt_meta, subscrpt_pro_kses_svg() ) : '',
		'aside'       => '' !== $subscrpt_aside ? wp_kses( $subscrpt_aside, subscrpt_pro_kses_svg() ) : '',
	)
);
