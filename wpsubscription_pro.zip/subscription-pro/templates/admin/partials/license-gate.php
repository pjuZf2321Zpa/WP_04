<?php
/**
 * Pro licence gate.
 *
 * This template can be overridden by copying it to:
 * <your_theme>/subscription-pro/admin/partials/license-gate.php
 *
 * Rendered in place of a page's content when the licence is not valid. Shown on
 * the Health, Statistics, Delivery and Subscriptions screens, so it is a
 * template rather than markup echoed from the plugin bootstrap.
 *
 * @package SpringDevs\SubscriptionPro
 *
 * @var string $subscrpt_license_url Admin URL of the licence page.
 */

defined( 'ABSPATH' ) || exit;

$subscrpt_license_url = isset( $subscrpt_license_url ) ? (string) $subscrpt_license_url : admin_url( 'admin.php?page=wp-subscription-license' );
?>
<div class="subscrpt-license-gate">
	<span class="subscrpt-license-gate__icon">
		<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
		</svg>
	</span>

	<h2 class="subscrpt-license-gate__title">
		<?php esc_html_e( 'Pro license required', 'subscription-pro' ); ?>
	</h2>

	<p class="subscrpt-license-gate__desc">
		<?php esc_html_e( 'Activate a valid license to use this feature and receive updates.', 'subscription-pro' ); ?>
	</p>

	<div class="subscrpt-license-gate__actions">
		<a href="<?php echo esc_url( $subscrpt_license_url ); ?>" class="wpsubs-btn wpsubs-btn--primary">
			<?php esc_html_e( 'Activate license', 'subscription-pro' ); ?>
		</a>
	</div>
</div>
