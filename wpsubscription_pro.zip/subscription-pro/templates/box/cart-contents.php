<?php
/**
 * What is in a box, on its cart line in the classic cart and checkout review.
 *
 * `assets/js/box-cart-view.js` draws the same markup for the block cart, so a
 * change to the structure here is a change there.
 *
 * @package SpringDevs\SubscriptionPro
 *
 * @var array $view Output of BoxCartView::describe(): box_name, count_label, items (each with its once flag and label), edit_url.
 */

defined( 'ABSPATH' ) || exit;

?>
<div class="subscrpt-box-contents">
	<p class="subscrpt-box-contents__title">
		<?php
		/* translators: %s: how many are in the box, for example "3 of 4". */
		echo esc_html( sprintf( __( 'In this box: %s', 'subscription-pro' ), $view['count_label'] ) );
		?>
	</p>
	<?php $subscrpt_box_any_once = in_array( true, array_column( $view['items'], 'once' ), true ); ?>
	<ul class="subscrpt-box-contents__list">
		<?php foreach ( $view['items'] as $subscrpt_pick ) : ?>
			<li class="subscrpt-box-contents__item">
				<img class="subscrpt-box-contents__thumb" src="<?php echo esc_url( $subscrpt_pick['thumbnail'] ); ?>" alt="" width="48" height="48" loading="lazy">
				<span class="subscrpt-box-contents__name">
					<?php if ( $subscrpt_pick['permalink'] ) : ?>
						<a href="<?php echo esc_url( $subscrpt_pick['permalink'] ); ?>"><?php echo esc_html( $subscrpt_pick['name'] ); ?></a>
					<?php else : ?>
						<?php echo esc_html( $subscrpt_pick['name'] ); ?>
					<?php endif; ?>
					<span class="subscrpt-box-contents__qty">
						<?php
						/* translators: %d: how many of this item are in the box. */
						echo esc_html( sprintf( __( '× %d', 'subscription-pro' ), (int) $subscrpt_pick['qty'] ) );
						?>
					</span>
				</span>
				<?php if ( $subscrpt_pick['once'] ) : ?>
					<span class="subscrpt-box-contents__once"><?php echo esc_html( $subscrpt_pick['label'] ); ?></span>
				<?php elseif ( $subscrpt_box_any_once && '' !== $subscrpt_pick['label'] ) : ?>
					<span class="subscrpt-box-contents__cadence"><?php echo esc_html( $subscrpt_pick['label'] ); ?></span>
				<?php endif; ?>
				<?php if ( $subscrpt_pick['price_html'] ) : ?>
					<span class="subscrpt-box-contents__price"><?php echo wp_kses_post( $subscrpt_pick['price_html'] ); ?></span>
				<?php endif; ?>
			</li>
		<?php endforeach; ?>
	</ul>
	<?php if ( ! empty( $view['edit_url'] ) ) : ?>
		<a class="subscrpt-box-contents__edit" href="<?php echo esc_url( $view['edit_url'] ); ?>"><?php esc_html_e( 'Edit box', 'subscription-pro' ); ?></a>
	<?php endif; ?>
</div>
