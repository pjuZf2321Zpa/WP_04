<?php
/**
 * The "Add to a box" card's body: what the item can go in, and the way there.
 *
 * Where the item allows a one-time purchase and the box has room for one, the
 * shopper also chooses "every month" or "once"; the choice rides on the link
 * (`subscrpt_box_pick_once`) or the in-place add. A subscriber's live box offers
 * the same choice, "every month" or "next box only", which rides on the add.
 *
 * Each button is a link to the box's page with the item named, so the card
 * posts nothing. A box already in the cart changes where the button goes
 * (Task 42), which is why each link says which box it is for.
 *
 * @var array $group      The card's group (label, sub_label, boxes[], and next[]: the
 *                        subscriber's live boxes that may take the item, Task 43).
 * @var \WC_Product $product Product being viewed.
 * @var bool  $standalone True when the card renders on its own, for an item with no plans.
 * @var int   $variation_id Set for a variable product's card: the variation it is for. It
 *                        renders hidden, and box-add-card.js shows it when that variation is chosen.
 *
 * @package SpringDevs\SubscriptionPro
 */

defined( 'ABSPATH' ) || exit;

$variation_id = isset( $variation_id ) ? (int) $variation_id : 0;

// The theme's primary button, as WooCommerce dresses its own add-to-cart button.
$subscrpt_box_add_element = function_exists( 'wc_wp_theme_get_element_class_name' ) ? wc_wp_theme_get_element_class_name( 'button' ) : '';
$subscrpt_box_add_classes = 'button alt' . ( $subscrpt_box_add_element ? ' ' . $subscrpt_box_add_element : '' );
?>
<div class="subscrpt-box-add<?php echo $standalone ? ' subscrpt-box-add--standalone' : ''; ?>"<?php echo $variation_id ? ' data-subscrpt-box-add-variation="' . esc_attr( $variation_id ) . '" hidden' : ''; ?> data-subscrpt-box-add>
	<?php if ( $standalone ) : ?>
		<h3 class="subscrpt-box-add__title"><?php echo esc_html( $group['label'] ); ?></h3>
	<?php endif; ?>
	<p class="subscrpt-box-add__sub"><?php echo esc_html( $group['sub_label'] ); ?></p>
	<ul class="subscrpt-box-add__list">
		<?php foreach ( $group['boxes'] as $subscrpt_box_add_entry ) : ?>
			<li class="subscrpt-box-add__item">
				<a
					class="<?php echo esc_attr( $subscrpt_box_add_classes ); ?> subscrpt-box-add__button"
					href="<?php echo esc_url( $subscrpt_box_add_entry['url'] ); ?>"
					data-subscrpt-box-add-link
					data-box-id="<?php echo esc_attr( $subscrpt_box_add_entry['box_id'] ); ?>"
					data-product-id="<?php echo esc_attr( $group['product_id'] ); ?>"
					data-item-name="<?php echo esc_attr( $product->get_name() ); ?>"
					data-cart-key="<?php echo esc_attr( $subscrpt_box_add_entry['cart_key'] ); ?>">
					<?php
					/* translators: %s: box name. */
					echo esc_html( sprintf( __( 'Add to the %s', 'subscription-pro' ), $subscrpt_box_add_entry['name'] ) );
					?>
				</a>
				<?php if ( count( $group['boxes'] ) > 1 && '' !== $subscrpt_box_add_entry['from'] ) : ?>
					<span class="subscrpt-box-add__from"><?php echo esc_html( $subscrpt_box_add_entry['from'] ); ?></span>
				<?php endif; ?>
				<?php if ( ! empty( $subscrpt_box_add_entry['once_offer'] ) ) : ?>
					<fieldset class="subscrpt-box-add__once" data-subscrpt-box-add-once>
						<legend><?php esc_html_e( 'Send it', 'subscription-pro' ); ?></legend>
						<label>
							<input type="radio" name="subscrpt_box_add_once_<?php echo esc_attr( $subscrpt_box_add_entry['box_id'] . '_' . $group['product_id'] ); ?>" value="0" checked />
							<span><?php echo esc_html( '' !== $subscrpt_box_add_entry['every'] ? $subscrpt_box_add_entry['every'] : __( 'every box', 'subscription-pro' ) ); ?></span>
						</label>
						<label>
							<input type="radio" name="subscrpt_box_add_once_<?php echo esc_attr( $subscrpt_box_add_entry['box_id'] . '_' . $group['product_id'] ); ?>" value="1" />
							<span><?php esc_html_e( 'once', 'subscription-pro' ); ?></span>
						</label>
					</fieldset>
				<?php endif; ?>
			</li>
		<?php endforeach; ?>
	</ul>
	<?php if ( ! empty( $group['next'] ) ) : ?>
		<div class="subscrpt-box-add__next" data-subscrpt-box-next data-nonce="<?php echo esc_attr( wp_create_nonce( 'subscrpt_box_next_add' ) ); ?>">
			<p class="subscrpt-box-add__next-title"><?php esc_html_e( 'Add to your next box', 'subscription-pro' ); ?></p>
			<ul class="subscrpt-box-add__list">
				<?php foreach ( $group['next'] as $subscrpt_box_next_entry ) : ?>
					<li class="subscrpt-box-add__item">
						<a
							class="<?php echo esc_attr( $subscrpt_box_add_classes ); ?> subscrpt-box-add__next-button"
							href="<?php echo esc_url( $subscrpt_box_next_entry['url'] ? add_query_arg( 'subscrpt_box', 'edit', $subscrpt_box_next_entry['url'] ) . '#subscrpt-box' : '' ); ?>"
							data-subscrpt-box-next-add
							data-subscription-id="<?php echo esc_attr( $subscrpt_box_next_entry['subscription_id'] ); ?>"
							data-product-id="<?php echo esc_attr( $group['product_id'] ); ?>"
							data-item-name="<?php echo esc_attr( $product->get_name() ); ?>"
							data-account-url="<?php echo esc_url( $subscrpt_box_next_entry['url'] ); ?>">
							<?php
							/* translators: 1: box name, 2: subscription number. */
							echo esc_html( sprintf( __( 'Add to my %1$s #%2$d', 'subscription-pro' ), $subscrpt_box_next_entry['name'], $subscrpt_box_next_entry['subscription_id'] ) );
							?>
						</a>
						<?php if ( ! empty( $subscrpt_box_next_entry['once_offer'] ) ) : ?>
							<fieldset class="subscrpt-box-add__once" data-subscrpt-box-next-once>
								<legend><?php esc_html_e( 'Send it', 'subscription-pro' ); ?></legend>
								<label>
									<input type="radio" name="subscrpt_box_next_once_<?php echo esc_attr( $subscrpt_box_next_entry['subscription_id'] . '_' . $group['product_id'] ); ?>" value="0" checked />
									<span><?php echo esc_html( '' !== $subscrpt_box_next_entry['every'] ? $subscrpt_box_next_entry['every'] : __( 'every box', 'subscription-pro' ) ); ?></span>
								</label>
								<label>
									<input type="radio" name="subscrpt_box_next_once_<?php echo esc_attr( $subscrpt_box_next_entry['subscription_id'] . '_' . $group['product_id'] ); ?>" value="1" />
									<span><?php esc_html_e( 'next box only', 'subscription-pro' ); ?></span>
								</label>
							</fieldset>
						<?php endif; ?>
						<?php if ( $subscrpt_box_next_entry['lock'] ) : ?>
							<span class="subscrpt-box-add__from">
								<?php
								/* translators: %s: date the next box stops taking changes. */
								echo esc_html( sprintf( __( 'Changes lock on %s', 'subscription-pro' ), date_i18n( get_option( 'date_format' ), $subscrpt_box_next_entry['lock'] ) ) );
								?>
							</span>
						<?php endif; ?>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	<?php endif; ?>
</div>
