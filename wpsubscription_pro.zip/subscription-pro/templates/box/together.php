<?php
/**
 * Frequently Bought Together: the tiles, the ticked list, the box price and the button.
 *
 * The form posts to the product that sells the box with the seller's first
 * subscription plan named, so it is bought as a subscription. The marker
 * `subscrpt_box_together` lets the server add into a box line the cart already
 * has instead of adding a second one.
 *
 * `assets/js/box-together.js` drives the section: unticking a product swaps in
 * the next one from the `spares` templates, the box price is re-asked of the
 * quote endpoint, and with a box line in the cart (`data-cart-key`) the button
 * adds in place. Without the script the form posts and the server does the same.
 *
 * @var array $together What `BoxTogetherSection::data()` returns.
 *                       `items` start ticked; `spares` wait in templates.
 *
 * @package SpringDevs\SubscriptionPro
 */

defined( 'ABSPATH' ) || exit;

$subscrpt_together_heading = 'subscrpt-together-' . (int) $together['box']->id();
$subscrpt_together_tile    = static function ( array $item ): void {
	?>
	<li class="subscrpt-together__tile" data-subscrpt-together-tile="<?php echo esc_attr( $item['product_id'] ); ?>">
		<img src="<?php echo esc_url( $item['thumbnail'] ); ?>" alt="" width="96" height="96" loading="lazy" />
	</li>
	<?php
};
$subscrpt_together_row     = static function ( array $item ) use ( $together ): void {
	?>
	<div class="subscrpt-together__item" data-subscrpt-together-row="<?php echo esc_attr( $item['product_id'] ); ?>">
		<label class="subscrpt-together__choice">
			<input type="checkbox" name="subscrpt_box_items[<?php echo esc_attr( $item['product_id'] ); ?>]" value="1" data-subscrpt-together-item<?php echo $item['checked'] ? ' checked' : ''; ?> />
			<span class="subscrpt-together__name">
				<?php if ( $item['current'] ) : ?>
					<strong><?php esc_html_e( 'This item:', 'subscription-pro' ); ?></strong>
				<?php endif; ?>
				<?php echo esc_html( $item['name'] ); ?>
			</span>
			<span class="subscrpt-together__price"><?php echo wp_kses_post( $item['price_html'] ); ?></span>
		</label>
		<?php if ( $item['once_offer'] ) : ?>
			<label class="subscrpt-together__once"<?php echo $item['checked'] ? '' : ' hidden'; ?>>
				<input type="checkbox" name="subscrpt_box_once[<?php echo esc_attr( $item['product_id'] ); ?>]" value="1" data-subscrpt-together-once />
				<span><?php esc_html_e( 'Send it once', 'subscription-pro' ); ?></span>
				<span class="screen-reader-text"><?php echo esc_html( $item['name'] ); ?></span>
			</label>
		<?php endif; ?>
	</div>
	<?php
};
?>
<section
	class="subscrpt-together"
	aria-labelledby="<?php echo esc_attr( $subscrpt_together_heading ); ?>"
	data-subscrpt-together
	data-product-id="<?php echo esc_attr( $together['seller']->get_id() ); ?>"
	data-box-id="<?php echo esc_attr( $together['box']->id() ); ?>"
	data-plan-id="<?php echo esc_attr( $together['plan_id'] ); ?>"
	data-cart-key="<?php echo esc_attr( $together['cart_key'] ); ?>"
	<?php if ( '' !== $together['quote_url'] ) : ?>
		data-quote-url="<?php echo esc_url( $together['quote_url'] ); ?>"
	<?php endif; ?>>
	<h2 class="subscrpt-together__title" id="<?php echo esc_attr( $subscrpt_together_heading ); ?>"><?php esc_html_e( 'Frequently bought together', 'subscription-pro' ); ?></h2>
	<form class="subscrpt-together__form" method="post" action="<?php echo esc_url( $together['action_url'] ); ?>">
		<ul class="subscrpt-together__tiles" data-subscrpt-together-tiles>
			<?php foreach ( $together['items'] as $subscrpt_together_index => $subscrpt_together_item ) : ?>
				<?php if ( $subscrpt_together_index ) : ?>
					<li class="subscrpt-together__plus" aria-hidden="true">+</li>
				<?php endif; ?>
				<?php $subscrpt_together_tile( $subscrpt_together_item ); ?>
			<?php endforeach; ?>
		</ul>
		<fieldset class="subscrpt-together__list" data-subscrpt-together-list>
			<legend class="screen-reader-text"><?php esc_html_e( 'Choose what goes in the box', 'subscription-pro' ); ?></legend>
			<?php foreach ( $together['items'] as $subscrpt_together_item ) : ?>
				<?php $subscrpt_together_row( $subscrpt_together_item ); ?>
			<?php endforeach; ?>
		</fieldset>
		<?php if ( $together['spares'] ) : ?>
			<template data-subscrpt-together-spares>
				<?php foreach ( $together['spares'] as $subscrpt_together_item ) : ?>
					<div data-subscrpt-together-spare="<?php echo esc_attr( $subscrpt_together_item['product_id'] ); ?>">
						<ul><?php $subscrpt_together_tile( $subscrpt_together_item ); ?></ul>
						<?php $subscrpt_together_row( $subscrpt_together_item ); ?>
					</div>
				<?php endforeach; ?>
			</template>
		<?php endif; ?>
		<div class="subscrpt-together__summary">
			<p class="subscrpt-together__box"><?php echo esc_html( $together['box']->title() ); ?></p>
			<?php if ( '' !== $together['price_html'] ) : ?>
				<p class="subscrpt-together__total" data-subscrpt-together-total>
					<del class="subscrpt-together__was"<?php echo '' === $together['regular_html'] ? ' hidden' : ''; ?>><?php echo wp_kses_post( $together['regular_html'] ); ?></del>
					<span class="subscrpt-together__now"><?php echo wp_kses_post( $together['price_html'] ); ?></span>
					<?php if ( '' !== $together['cadence'] ) : ?>
						<span class="subscrpt-together__cadence"><?php echo esc_html( $together['cadence'] ); ?></span>
					<?php endif; ?>
				</p>
				<p class="subscrpt-together__split" data-subscrpt-together-split hidden></p>
			<?php endif; ?>
			<?php if ( '' !== $together['saving_html'] || '' !== $together['quote_url'] ) : ?>
				<p class="subscrpt-together__saving" data-subscrpt-together-saving<?php echo '' === $together['saving_html'] ? ' hidden' : ''; ?>>
					<?php
					/* translators: %s: amount saved on each box, as HTML. */
					echo wp_kses_post( sprintf( __( 'You save %s on each box', 'subscription-pro' ), '<span data-subscrpt-together-saved>' . $together['saving_html'] . '</span>' ) );
					?>
				</p>
			<?php endif; ?>
		</div>
		<input type="hidden" name="subscrpt_box_together" value="1" />
		<input type="hidden" name="subscrpt_box_id" value="<?php echo esc_attr( $together['box']->id() ); ?>" />
		<input type="hidden" name="subscrpt_plan_id" value="<?php echo esc_attr( $together['plan_id'] ); ?>" />
		<input type="hidden" name="subscrpt_box_together_nonce" value="<?php echo esc_attr( $together['nonce'] ); ?>" />
		<button type="submit" class="button alt subscrpt-together__submit" name="add-to-cart" value="<?php echo esc_attr( $together['seller']->get_id() ); ?>">
			<?php esc_html_e( 'Add selected to cart', 'subscription-pro' ); ?>
		</button>
		<div class="subscrpt-together__notice" data-subscrpt-together-notice role="status" aria-live="polite"></div>
	</form>
</section>
