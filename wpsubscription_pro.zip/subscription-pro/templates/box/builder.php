<?php
/**
 * The box builder, inside the add-to-cart form.
 *
 * @package SpringDevs\SubscriptionPro
 *
 * @var \WC_Product   $product         The box product.
 * @var string        $type            curated | build | edition.
 * @var array         $rules           Size and per-item rules.
 * @var array         $contents        Fixed contents, for curated and edition boxes.
 * @var \WC_Product[] $choices         Products a shopper may pick.
 * @var array         $choice_groups   The same, one card per product: product and its offered variations.
 * @var array         $defaults        product_id => qty the merchant picked.
 * @var array         $start           product_id => qty the builder opens with: the cart line's when editing.
 * @var array         $edit            The cart line being edited (key, picks, once, plan_id, one_time), or empty.
 * @var array         $variation_sizes variation_id => [min, max].
 * @var int           $box_id          The box being bought.
 * @var array         $boxes           Every box this product sells.
 * @var array         $quote           The first quote, empty unless the box is priced by its contents.
 * @var array         $once_offer      product_id => true for each pick that may ship once instead of every cycle.
 * @var array         $once_ticked     product_id => true for each pick that opens as once.
 * @var string        $once_label      The sentence beside the once choice, e.g. "Once, not every month".
 * @var string        $quote_url       Where the builder asks for the next one.
 */

defined( 'ABSPATH' ) || exit;

use SpringDevs\SubscriptionPro\Illuminate\Box\BoxProduct;

?>
<div class="subscrpt-box-builder"
	data-min="<?php echo esc_attr( (int) ( $rules['min'] ?? 0 ) ); ?>"
	data-max="<?php echo esc_attr( (int) ( $rules['max'] ?? 0 ) ); ?>"
	data-sizes="<?php echo esc_attr( wp_json_encode( $variation_sizes ) ); ?>"
	<?php if ( $quote_url ) : ?>
		data-quote-url="<?php echo esc_url( $quote_url ); ?>"
		data-product-id="<?php echo esc_attr( $product->get_id() ); ?>"
		data-box-id="<?php echo esc_attr( $box_id ); ?>"
	<?php endif; ?>
	<?php if ( $edit ) : ?>
		data-subscrpt-edit-plan="<?php echo esc_attr( $edit['plan_id'] ); ?>"
		data-subscrpt-edit-once="<?php echo $edit['one_time'] ? '1' : '0'; ?>"
	<?php endif; ?>>

	<?php
	/*
	 * Which box this is. A product selling one box posts it silently; a product
	 * selling several asks, and the answer decides the contents and the rules
	 * below — so switching is a link that re-renders the whole builder rather
	 * than a control the add-to-cart button would have to understand.
	 */
	?>
	<input type="hidden" name="subscrpt_box_id" value="<?php echo esc_attr( $box_id ); ?>" />

	<?php if ( $edit ) : ?>
		<input type="hidden" name="subscrpt_box_edit" value="<?php echo esc_attr( $edit['key'] ); ?>" />
		<?php wp_nonce_field( 'subscrpt_box_edit', 'subscrpt_box_edit_nonce', false ); ?>
		<?php if ( $product->is_type( 'variable' ) ) : ?>
			<p class="subscrpt-box-builder__locked" role="note">
				<?php esc_html_e( 'The size of a box in your cart cannot be changed. To pick a different size, remove the box and add a new one.', 'subscription-pro' ); ?>
			</p>
		<?php endif; ?>
	<?php endif; ?>

	<p class="subscrpt-box-builder__held" data-subscrpt-box-held-note role="status" hidden>
		<?php esc_html_e( "Boxes can't be paid in installments. Choose Subscribe & Save or One-time.", 'subscription-pro' ); ?>
	</p>

	<?php if ( count( $boxes ) > 1 ) : ?>
		<div class="subscrpt-box-switch">
			<span class="subscrpt-box-switch__label"><?php esc_html_e( 'Choose your box', 'subscription-pro' ); ?></span>
			<p class="subscrpt-box-switch__lede" data-subscrpt-lede>
				<?php esc_html_e( 'Each box has its own contents and size. For example, a smaller box with fewer items, or a larger one with more.', 'subscription-pro' ); ?>
			</p>

			<ul class="subscrpt-box-switch__list">
				<?php foreach ( $boxes as $subscrpt_box_option ) : ?>
					<?php $subscrpt_box_current = $subscrpt_box_option->id() === $box_id; ?>
					<li>
						<a
							class="subscrpt-box-switch__option<?php echo $subscrpt_box_current ? ' is-current' : ''; ?>"
							href="<?php echo esc_url( add_query_arg( 'subscrpt_box_id', $subscrpt_box_option->id() ) ); ?>"
							<?php echo $subscrpt_box_current ? 'aria-current="true"' : ''; ?>>
							<?php echo esc_html( $subscrpt_box_option->title() ); ?>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	<?php endif; ?>

	<?php if ( BoxProduct::TYPE_BUILD !== $type ) : ?>

		<h3 class="subscrpt-box-builder__title"><?php esc_html_e( 'What is in this box', 'subscription-pro' ); ?></h3>

		<?php if ( empty( $contents ) ) : ?>
			<p><?php esc_html_e( 'The contents of this box have not been published yet.', 'subscription-pro' ); ?></p>
		<?php else : ?>
			<ul class="subscrpt-box-builder__grid">
				<?php
				foreach ( BoxProduct::normalise_items( $contents ) as $subscrpt_box_item ) :
					$subscrpt_box_product = wc_get_product( $subscrpt_box_item['variation_id'] ? $subscrpt_box_item['variation_id'] : $subscrpt_box_item['product_id'] );

					if ( ! $subscrpt_box_product ) {
						continue;
					}
					?>
					<li class="subscrpt-box-choice">
						<a class="subscrpt-box-choice__link" href="<?php echo esc_url( $subscrpt_box_product->get_permalink() ); ?>" target="_blank" rel="noopener">
							<?php echo wp_kses_post( $subscrpt_box_product->get_image( 'woocommerce_thumbnail' ) ); ?>
							<span class="subscrpt-box-choice__name">
								<?php echo esc_html( sprintf( '%d × %s', (int) $subscrpt_box_item['qty'], $subscrpt_box_product->get_name() ) ); ?>
								<span class="screen-reader-text"><?php esc_html_e( '(opens in a new tab)', 'subscription-pro' ); ?></span>
							</span>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>

		<?php if ( BoxProduct::TYPE_EDITION === $type ) : ?>
			<p class="subscrpt-box-builder__note">
				<?php esc_html_e( 'Contents change each cycle — we will email you what is coming before it ships.', 'subscription-pro' ); ?>
			</p>
		<?php endif; ?>

	<?php else : ?>

		<h3 class="subscrpt-box-builder__title"><?php esc_html_e( 'Build your box', 'subscription-pro' ); ?></h3>

		<?php if ( ! empty( $pick_notice ) ) : ?>
			<p class="subscrpt-box-builder__notice" role="status"><?php echo esc_html( $pick_notice ); ?></p>
		<?php endif; ?>

		<?php if ( empty( $choices ) ) : ?>
			<p><?php esc_html_e( 'Nothing is available for this box at the moment.', 'subscription-pro' ); ?></p>
		<?php else : ?>

			<div class="subscrpt-box-builder__rule">
				<span class="subscrpt-box-builder__counter" aria-live="polite"></span>

				<?php if ( ! empty( $defaults ) ) : ?>
					<button type="button" class="subscrpt-box-builder__defaults button">
						<?php esc_html_e( 'Start with our picks', 'subscription-pro' ); ?>
					</button>
				<?php endif; ?>
			</div>

			<?php if ( $quote_url ) : ?>
				<p class="subscrpt-box-builder__price" data-subscrpt-box-price aria-live="polite">
					<del class="subscrpt-box-builder__regular" data-subscrpt-box-regular<?php echo empty( $quote['regular_html'] ) || ! empty( $quote['first_html'] ) ? ' hidden' : ''; ?>><?php echo wp_kses_post( $quote['regular_html'] ); ?></del>
					<span data-subscrpt-box-amount<?php echo empty( $quote['first_html'] ) ? '' : ' hidden'; ?>><?php echo wp_kses_post( $quote['price_html'] ); ?></span>
					<span class="subscrpt-box-builder__split" data-subscrpt-box-split<?php echo empty( $quote['first_html'] ) ? ' hidden' : ''; ?>>
						<span class="subscrpt-box-builder__first" data-subscrpt-box-first><?php echo wp_kses_post( $quote['first_html'] ); ?></span>
						<span class="subscrpt-box-builder__then" data-subscrpt-box-then><?php echo wp_kses_post( $quote['then_html'] ); ?></span>
					</span>
				</p>
				<p class="subscrpt-box-builder__message" data-subscrpt-box-message aria-live="polite"><?php echo esc_html( $quote['message'] ); ?></p>
			<?php endif; ?>

			<?php
			// The chips offer only the categories something in the box is in.
			$subscrpt_box_cats = [];

			foreach ( $choice_groups as $subscrpt_box_group ) {
				$subscrpt_box_terms = get_the_terms( $subscrpt_box_group['product']->get_id(), 'product_cat' );

				foreach ( is_array( $subscrpt_box_terms ) ? $subscrpt_box_terms : [] as $subscrpt_box_term ) {
					$subscrpt_box_cats[ (int) $subscrpt_box_term->term_id ] = $subscrpt_box_term->name;
				}
			}

			asort( $subscrpt_box_cats );

			$subscrpt_box_paged = count( $choice_groups ) > 12;
			?>

			<?php if ( count( $choice_groups ) > 6 ) : ?>
				<div class="subscrpt-box-toolbar" data-subscrpt-box-toolbar>
					<?php if ( count( $subscrpt_box_cats ) > 1 ) : ?>
						<div class="subscrpt-box-toolbar__chips" role="group" aria-label="<?php esc_attr_e( 'Show a category', 'subscription-pro' ); ?>">
							<button type="button" class="subscrpt-box-filter is-on" data-subscrpt-box-cat="" aria-pressed="true"><?php esc_html_e( 'All', 'subscription-pro' ); ?></button>
							<?php foreach ( $subscrpt_box_cats as $subscrpt_box_cat_id => $subscrpt_box_cat_name ) : ?>
								<button type="button" class="subscrpt-box-filter" data-subscrpt-box-cat="<?php echo esc_attr( (string) $subscrpt_box_cat_id ); ?>" aria-pressed="false"><?php echo esc_html( $subscrpt_box_cat_name ); ?></button>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>
					<label class="screen-reader-text" for="subscrpt-box-search-<?php echo esc_attr( $box_id ); ?>"><?php esc_html_e( 'Search items', 'subscription-pro' ); ?></label>
					<input type="search" class="subscrpt-box-toolbar__search" id="subscrpt-box-search-<?php echo esc_attr( $box_id ); ?>" data-subscrpt-box-search placeholder="<?php esc_attr_e( 'Search items', 'subscription-pro' ); ?>" />
				</div>
			<?php endif; ?>

			<ul class="subscrpt-box-builder__grid"<?php echo $subscrpt_box_paged ? ' data-subscrpt-box-paged="12"' : ''; ?>>
				<?php
				foreach ( $choice_groups as $subscrpt_box_group ) :
					$subscrpt_box_parent   = $subscrpt_box_group['product'];
					$subscrpt_box_variable = ! empty( $subscrpt_box_group['variations'] );
					$subscrpt_box_variants = $subscrpt_box_variable ? $subscrpt_box_group['variations'] : [ $subscrpt_box_parent ];
					$subscrpt_box_card_id  = $subscrpt_box_parent->get_id();

					// The card opens on the first variation already in the box, else the first offered.
					$subscrpt_box_current = $subscrpt_box_variants[0];

					foreach ( $subscrpt_box_variants as $subscrpt_box_variant ) {
						if ( ! empty( $start[ $subscrpt_box_variant->get_id() ] ) ) {
							$subscrpt_box_current = $subscrpt_box_variant;
							break;
						}
					}

					$subscrpt_box_current_id = $subscrpt_box_current->get_id();
					?>
					<?php $subscrpt_box_card_cats = wc_get_product_cat_ids( $subscrpt_box_card_id ); ?>
					<li
						class="subscrpt-box-choice"<?php echo $subscrpt_box_variable ? ' data-subscrpt-box-variable' : ''; ?>
						data-subscrpt-box-name="<?php echo esc_attr( function_exists( 'mb_strtolower' ) ? mb_strtolower( $subscrpt_box_parent->get_name() ) : strtolower( $subscrpt_box_parent->get_name() ) ); ?>"
						data-subscrpt-box-cats="<?php echo esc_attr( implode( ',', array_map( 'intval', $subscrpt_box_card_cats ) ) ); ?>">
						<?php // A new tab, so following an item does not lose the box being built. ?>
						<?php // A variable card shows the product; its popup shows the option. ?>
						<?php $subscrpt_box_shown = $subscrpt_box_variable ? $subscrpt_box_parent : $subscrpt_box_current; ?>
						<a class="subscrpt-box-choice__link" href="<?php echo esc_url( $subscrpt_box_shown->get_permalink() ); ?>" target="_blank" rel="noopener" data-subscrpt-box-link>
							<?php echo wp_kses_post( $subscrpt_box_shown->get_image( 'woocommerce_thumbnail' ) ); ?>
							<span class="subscrpt-box-choice__name">
								<?php echo esc_html( $subscrpt_box_parent->get_name() ); ?>
								<span class="screen-reader-text"><?php esc_html_e( '(opens in a new tab)', 'subscription-pro' ); ?></span>
							</span>
						</a>

						<?php
						/*
						 * A variable product's options are chosen in a popup, as on its
						 * own product page: one row per attribute, then the quantity of
						 * the option that matches, and a list of what is already in the
						 * box. The card only summarises. The hidden select stays the
						 * source of which option is showing.
						 */
						if ( $subscrpt_box_variable ) :
							$subscrpt_box_dialog_id = 'subscrpt-box-variants-' . $subscrpt_box_card_id;
							?>
							<?php
							if ( $quote_url ) :
								$subscrpt_box_amounts = array_map(
									static function ( $variant ) {
										return (float) wc_get_price_to_display( $variant );
									},
									$subscrpt_box_variants
								);
								?>
								<span class="subscrpt-box-choice__price">
									<?php
									echo wp_kses_post(
										min( $subscrpt_box_amounts ) === max( $subscrpt_box_amounts )
											? wc_price( min( $subscrpt_box_amounts ) )
											: wc_format_price_range( min( $subscrpt_box_amounts ), max( $subscrpt_box_amounts ) )
									);
									?>
								</span>
							<?php endif; ?>

							<p class="subscrpt-box-choice__picks" data-subscrpt-box-picks aria-live="polite" hidden></p>

							<button
								type="button"
								class="subscrpt-box-choice__options"
								data-subscrpt-box-open
								aria-haspopup="dialog"
								aria-controls="<?php echo esc_attr( $subscrpt_box_dialog_id ); ?>"
								data-label-empty="<?php esc_attr_e( 'Choose options', 'subscription-pro' ); ?>"
								data-label-picked="<?php esc_attr_e( 'Change options', 'subscription-pro' ); ?>">
								<?php esc_html_e( 'Choose options', 'subscription-pro' ); ?>
							</button>

							<dialog class="subscrpt-box-variants" id="<?php echo esc_attr( $subscrpt_box_dialog_id ); ?>" data-subscrpt-box-dialog tabindex="-1" aria-labelledby="<?php echo esc_attr( $subscrpt_box_dialog_id ); ?>-title">
								<div class="subscrpt-box-variants__head">
									<h3 class="subscrpt-box-variants__title" id="<?php echo esc_attr( $subscrpt_box_dialog_id ); ?>-title"><?php echo esc_html( $subscrpt_box_parent->get_name() ); ?></h3>
									<button type="button" class="subscrpt-box-variants__close" data-subscrpt-box-close aria-label="<?php esc_attr_e( 'Close', 'subscription-pro' ); ?>">&times;</button>
								</div>

								<div class="subscrpt-box-variants__body">
									<div class="subscrpt-box-variants__media" data-subscrpt-box-variant-image>
										<?php echo wp_kses_post( $subscrpt_box_current->get_image( 'woocommerce_thumbnail' ) ); ?>
									</div>

									<div class="subscrpt-box-variants__form">
										<?php foreach ( \SpringDevs\SubscriptionPro\Frontend\BoxBuilder::variant_attributes( $subscrpt_box_parent ) as $subscrpt_box_attr_key => $subscrpt_box_attr ) : ?>
											<div class="subscrpt-box-variants__attr" data-subscrpt-box-attr="<?php echo esc_attr( $subscrpt_box_attr_key ); ?>">
												<span class="subscrpt-box-variants__label" id="<?php echo esc_attr( $subscrpt_box_dialog_id . '-' . $subscrpt_box_attr_key ); ?>"><?php echo esc_html( $subscrpt_box_attr['label'] ); ?></span>
												<div class="subscrpt-box-variants__values" role="group" aria-labelledby="<?php echo esc_attr( $subscrpt_box_dialog_id . '-' . $subscrpt_box_attr_key ); ?>">
													<?php foreach ( $subscrpt_box_attr['values'] as $subscrpt_box_value => $subscrpt_box_value_label ) : ?>
														<button type="button" class="subscrpt-box-chip" data-subscrpt-box-attr-value="<?php echo esc_attr( $subscrpt_box_value ); ?>" aria-pressed="false"><?php echo esc_html( $subscrpt_box_value_label ); ?></button>
													<?php endforeach; ?>
												</div>
											</div>
										<?php endforeach; ?>

										<select class="subscrpt-box-choice__variant" data-subscrpt-box-variant hidden tabindex="-1" aria-hidden="true">
											<?php
											foreach ( $subscrpt_box_variants as $subscrpt_box_variant ) :
												$subscrpt_box_image_id = $subscrpt_box_variant->get_image_id();
												?>
												<option
													value="<?php echo esc_attr( $subscrpt_box_variant->get_id() ); ?>"
													data-attrs="<?php echo esc_attr( (string) wp_json_encode( $subscrpt_box_variant->get_variation_attributes() ) ); ?>"
													data-image="<?php echo esc_url( $subscrpt_box_image_id ? wp_get_attachment_image_url( $subscrpt_box_image_id, 'woocommerce_thumbnail' ) : wc_placeholder_img_src( 'woocommerce_thumbnail' ) ); ?>"
													data-srcset="<?php echo esc_attr( $subscrpt_box_image_id ? (string) wp_get_attachment_image_srcset( $subscrpt_box_image_id, 'woocommerce_thumbnail' ) : '' ); ?>"
													<?php selected( $subscrpt_box_variant->get_id(), $subscrpt_box_current_id ); ?>>
													<?php echo esc_html( wc_get_formatted_variation( $subscrpt_box_variant, true, false, false ) ); ?>
												</option>
											<?php endforeach; ?>
										</select>
						<?php endif; ?>

						<?php
						// Only a box priced by its picks charges for each item; a fixed
						// price would make the item's own price misleading. Not WooCommerce's
						// `price` class: inside the product summary themes size that as the
						// page's own price.
						if ( $quote_url ) :
							foreach ( $subscrpt_box_variants as $subscrpt_box_variant ) :
								?>
								<span class="subscrpt-box-choice__price" data-subscrpt-box-for="<?php echo esc_attr( $subscrpt_box_variant->get_id() ); ?>"<?php echo $subscrpt_box_variant->get_id() === $subscrpt_box_current_id ? '' : ' hidden'; ?>>
									<?php echo wp_kses_post( $subscrpt_box_variant->get_price_html() ); ?>
								</span>
								<?php
							endforeach;
						endif;
						?>

						<?php foreach ( $subscrpt_box_variants as $subscrpt_box_variant ) : ?>
							<label class="screen-reader-text" for="subscrpt-box-pick-<?php echo esc_attr( $subscrpt_box_variant->get_id() ); ?>">
								<?php
								printf(
									/* translators: %s: product name. */
									esc_html__( 'How many %s', 'subscription-pro' ),
									esc_html( $subscrpt_box_variant->get_name() )
								);
								?>
							</label>
						<?php endforeach; ?>

						<?php
						foreach ( $subscrpt_box_variants as $subscrpt_box_variant ) :
							$subscrpt_box_choice_id = $subscrpt_box_variant->get_id();

							if ( ! isset( $once_offer[ $subscrpt_box_choice_id ] ) ) {
								continue;
							}
							?>
							<span class="subscrpt-box-choice__once-for" data-subscrpt-box-for="<?php echo esc_attr( $subscrpt_box_choice_id ); ?>"<?php echo $subscrpt_box_choice_id === $subscrpt_box_current_id ? '' : ' hidden'; ?>>
								<label class="subscrpt-box-choice__once">
									<input
										type="checkbox"
										name="subscrpt_box_once[<?php echo esc_attr( $subscrpt_box_choice_id ); ?>]"
										value="1"
										<?php checked( isset( $once_ticked[ $subscrpt_box_choice_id ] ) ); ?> />
									<span data-subscrpt-box-once-label><?php echo esc_html( $once_label ); ?></span>
								</label>
							</span>
						<?php endforeach; ?>

						<?php // One quantity per variation, all posted; the stepper shows the selected one. Last, so every card's sits on the same line. ?>
						<div class="subscrpt-box-choice__stepper">
							<button
								type="button"
								class="subscrpt-box-choice__step"
								data-subscrpt-box-step="-1"
								aria-controls="subscrpt-box-pick-<?php echo esc_attr( $subscrpt_box_current_id ); ?>"
								<?php /* translators: %s: product name. */ ?>
								aria-label="<?php echo esc_attr( sprintf( __( 'Remove one %s', 'subscription-pro' ), $subscrpt_box_parent->get_name() ) ); ?>">&minus;</button>
							<?php
							foreach ( $subscrpt_box_variants as $subscrpt_box_variant ) :
								$subscrpt_box_choice_id = $subscrpt_box_variant->get_id();
								?>
								<input
									class="subscrpt-box-choice__qty"
									id="subscrpt-box-pick-<?php echo esc_attr( $subscrpt_box_choice_id ); ?>"
									type="number"
									min="0"
									step="1"
									inputmode="numeric"
									<?php echo ! empty( $rules['max_per_item'] ) ? 'max="' . esc_attr( (int) $rules['max_per_item'] ) . '"' : ''; ?>
									name="subscrpt_box_items[<?php echo esc_attr( $subscrpt_box_choice_id ); ?>]"
									data-subscrpt-box-for="<?php echo esc_attr( $subscrpt_box_choice_id ); ?>"
									data-default="<?php echo esc_attr( $defaults[ $subscrpt_box_choice_id ] ?? 0 ); ?>"
									value="<?php echo esc_attr( $start[ $subscrpt_box_choice_id ] ?? 0 ); ?>"
									<?php echo $subscrpt_box_choice_id === $subscrpt_box_current_id ? '' : 'hidden'; ?> />
							<?php endforeach; ?>
							<button
								type="button"
								class="subscrpt-box-choice__step"
								data-subscrpt-box-step="1"
								aria-controls="subscrpt-box-pick-<?php echo esc_attr( $subscrpt_box_current_id ); ?>"
								<?php /* translators: %s: product name. */ ?>
								aria-label="<?php echo esc_attr( sprintf( __( 'Add one %s', 'subscription-pro' ), $subscrpt_box_parent->get_name() ) ); ?>">+</button>
						</div>

						<?php if ( $subscrpt_box_variable ) : ?>
									</div>
								</div>

								<div class="subscrpt-box-variants__inbox">
									<h4 class="subscrpt-box-variants__subtitle"><?php esc_html_e( 'In your box', 'subscription-pro' ); ?></h4>
									<ul class="subscrpt-box-variants__list" data-subscrpt-box-inbox data-label-remove="<?php esc_attr_e( 'Remove', 'subscription-pro' ); ?>"></ul>
									<p class="subscrpt-box-variants__empty" data-subscrpt-box-inbox-empty><?php esc_html_e( 'None of these in your box yet.', 'subscription-pro' ); ?></p>
								</div>

								<div class="subscrpt-box-variants__foot">
									<button type="button" class="button alt" data-subscrpt-box-close><?php esc_html_e( 'Done', 'subscription-pro' ); ?></button>
								</div>
							</dialog>
						<?php endif; ?>
					</li>
				<?php endforeach; ?>
			</ul>

			<p class="subscrpt-box-builder__nomatch" data-subscrpt-box-nomatch hidden><?php esc_html_e( 'No items match that search.', 'subscription-pro' ); ?></p>

			<?php if ( $subscrpt_box_paged ) : ?>
				<p class="subscrpt-box-builder__more">
					<?php /* translators: %d: items not shown yet. */ ?>
					<button type="button" class="button" data-subscrpt-box-more data-label="<?php esc_attr_e( 'Show %d more', 'subscription-pro' ); ?>"></button>
				</p>
			<?php endif; ?>

			<?php
			/*
			 * The box at a glance, pinned to the bottom of the screen while the
			 * builder is on it: how full it is, what it costs, and the button.
			 * It reads the builder's own counter, message and price, and presses
			 * the form's real add-to-cart button, so nothing here decides
			 * anything the builder does not already.
			 */
			?>
			<div class="subscrpt-box-tray" data-subscrpt-box-tray>
				<div class="subscrpt-box-tray__sum">
					<div class="subscrpt-box-tray__head">
						<strong><?php esc_html_e( 'Your box', 'subscription-pro' ); ?></strong>
						<span data-subscrpt-box-tray-count></span>
					</div>
					<div class="subscrpt-box-tray__progress" aria-hidden="true"><i data-subscrpt-box-tray-bar></i></div>
					<div class="subscrpt-box-tray__msg" data-subscrpt-box-tray-msg aria-live="polite"></div>
				</div>
				<div class="subscrpt-box-tray__total">
					<div class="subscrpt-box-tray__amount" data-subscrpt-box-tray-total></div>
					<div class="subscrpt-box-tray__cadence" data-subscrpt-box-tray-cadence></div>
				</div>
				<button type="button" class="subscrpt-box-tray__add button alt" data-subscrpt-box-tray-add><?php esc_html_e( 'Add box to cart', 'subscription-pro' ); ?></button>
			</div>

		<?php endif; ?>

	<?php endif; ?>
</div>
