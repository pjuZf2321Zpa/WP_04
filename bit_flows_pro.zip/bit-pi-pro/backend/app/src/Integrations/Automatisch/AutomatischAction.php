<?php

namespace BitApps\PiPro\src\Integrations\Automatisch;

// Prevent direct script access
if (!\defined('ABSPATH')) {
    exit;
}


use BitApps\Pi\src\Integrations\ApiRequest\ApiRequestAction;

class AutomatischAction extends ApiRequestAction
{
    // extends ApiRequestAction
}
