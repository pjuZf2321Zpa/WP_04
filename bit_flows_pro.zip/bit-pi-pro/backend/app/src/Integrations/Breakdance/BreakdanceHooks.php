<?php

namespace BitApps\PiPro\src\Integrations\Breakdance;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!\defined('ABSPATH')) {
    exit;
}

class BreakdanceHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'formSubmission' => [
                'hook'     => 'init',
                'callback' => [BreakdanceTrigger::class, 'initBreakdanceFormAction'],
            ]
        ];
    }
}
