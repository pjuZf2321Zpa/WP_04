<?php

namespace BitApps\PiPro\src\Integrations\PopupMaker;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!\defined('ABSPATH')) {
    exit;
}

class PopupMakerHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'popupFormSubmit' => [
                'hook'          => 'pum_sub_form_success',
                'callback'      => [PopupMakerTrigger::class, 'handleSubmit'],
                'priority'      => 10,
                'accepted_args' => 1,
            ],
            'popupOpened' => [
                'hook'          => 'pum_analytics_open',
                'callback'      => [PopupMakerTrigger::class, 'popupOpened'],
                'priority'      => 10,
                'accepted_args' => 2,
            ],
        ];
    }
}
