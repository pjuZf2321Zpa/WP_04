<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\PiPro\src\Integrations\PopupMaker\PopupMakerHelper;

Route::group(
    function () {
        Route::get('popup-maker/popups', [PopupMakerHelper::class, 'getPopups']);
        Route::get('popup-maker/themes', [PopupMakerHelper::class, 'getThemes']);
        Route::get('popup-maker/subscribers', [PopupMakerHelper::class, 'getSubscribers']);
        Route::get('popup-maker/subscriber-emails', [PopupMakerHelper::class, 'getSubscriberEmails']);
    }
)->middleware('nonce:admin');
