<?php

namespace BitApps\PiPro\src\Integrations\PopupMaker\Services;

use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\Deps\BitApps\WPKit\Helpers\JSON;
use PUM_DB_Subscribers;

if (!defined('ABSPATH')) {
    exit;
}

final class SubscriberService extends BaseService
{
    public function createSubscriber()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'email' => ['required', 'email'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        $subscribers = $this->subscribers();

        if (!$subscribers) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Popup Maker subscribers table is not available.', 'bit-pi'),
            ];
        }

        $email = $fieldMappings['email'];

        $data = [
            'uuid'         => wp_generate_uuid4(),
            'popup_id'     => (int) ($fieldMappings['popup_id'] ?? 0),
            'email'        => $email,
            'email_hash'   => md5($email),
            'name'         => $fieldMappings['name'] ?? '',
            'fname'        => $fieldMappings['fname'] ?? '',
            'lname'        => $fieldMappings['lname'] ?? '',
            'user_id'      => (int) ($fieldMappings['user_id'] ?? get_current_user_id()),
            'consent'      => $fieldMappings['consent'] ?? 'no',
            'consent_args' => $this->stringifyConsentArgs($fieldMappings['consent_args'] ?? ''),
            'created'      => current_time('mysql'),
        ];

        $subscriberId = $subscribers->insert($data);

        if (!$subscriberId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to create the subscriber.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => (array) $subscribers->get($subscriberId),
        ];
    }

    public function updateSubscriber()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'subscriber_id' => ['required'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        $subscribers = $this->subscribers();

        if (!$subscribers) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Popup Maker subscribers table is not available.', 'bit-pi'),
            ];
        }

        $subscriberId = (int) $fieldMappings['subscriber_id'];

        if (!$subscribers->get($subscriberId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('No subscriber found with the given id.', 'bit-pi'),
            ];
        }

        $data = $this->filterEmpty(
            [
                'email'        => $fieldMappings['email'] ?? null,
                'name'         => $fieldMappings['name'] ?? null,
                'fname'        => $fieldMappings['fname'] ?? null,
                'lname'        => $fieldMappings['lname'] ?? null,
                'popup_id'     => $fieldMappings['popup_id'] ?? null,
                'consent'      => $fieldMappings['consent'] ?? null,
                'consent_args' => $this->stringifyConsentArgs($fieldMappings['consent_args'] ?? null),
            ]
        );

        if (isset($data['email'])) {
            $data['email_hash'] = md5($data['email']);
        }

        if (empty($data)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('At least one field is required to update the subscriber.', 'bit-pi'),
            ];
        }

        if (!$subscribers->update($subscriberId, $data)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to update the subscriber.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => (array) $subscribers->get($subscriberId),
        ];
    }

    public function deleteSubscriber()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'subscriber_id' => ['required'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        $subscribers = $this->subscribers();

        if (!$subscribers) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Popup Maker subscribers table is not available.', 'bit-pi'),
            ];
        }

        $subscriberId = (int) $fieldMappings['subscriber_id'];
        $subscriber = $subscribers->get($subscriberId);

        if (!$subscriber) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('No subscriber found with the given id.', 'bit-pi'),
            ];
        }

        if (!$subscribers->delete($subscriberId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to delete the subscriber.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'subscriber_id' => $subscriberId,
                'deleted'       => true,
                'subscriber'    => (array) $subscriber,
            ],
        ];
    }

    public function getSubscriber()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'email' => ['required', 'email'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        $subscribers = $this->subscribers();

        if (!$subscribers) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Popup Maker subscribers table is not available.', 'bit-pi'),
            ];
        }

        $subscriber = $subscribers->get_by('email', $fieldMappings['email']);

        if (!$subscriber) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('No subscriber found with the given email.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => (array) $subscriber,
        ];
    }

    private function subscribers()
    {
        if (!class_exists('PUM_DB_Subscribers')) {
            return;
        }

        return PUM_DB_Subscribers::instance();
    }

    /**
     * Consent args are stored in a single column, so structured values get encoded.
     *
     * @param mixed $consentArgs
     */
    private function stringifyConsentArgs($consentArgs)
    {
        if ($consentArgs === null || $consentArgs === '') {
            return $consentArgs;
        }

        if (\is_array($consentArgs) || \is_object($consentArgs)) {
            return JSON::encode($consentArgs);
        }

        return $consentArgs;
    }
}
