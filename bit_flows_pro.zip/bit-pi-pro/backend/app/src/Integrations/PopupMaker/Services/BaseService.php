<?php

namespace BitApps\PiPro\src\Integrations\PopupMaker\Services;

use BitApps\Pi\src\Flow\NodeInfoProvider;

if (!\defined('ABSPATH')) {
    exit;
}

abstract class BaseService
{
    protected $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    protected function resolvePopup($popupId)
    {
        if (!\function_exists('pum_get_popup') || !\function_exists('pum_is_popup')) {
            return null;
        }

        $popup = pum_get_popup((int) $popupId);

        if (!pum_is_popup($popup)) {
            return null;
        }

        return $popup;
    }

    /**
     * Drops null / empty-string entries so partial updates never blank out columns.
     */
    protected function filterEmpty($data)
    {
        return array_filter(
            $data,
            static function ($value) {
                return $value !== null && $value !== '';
            }
        );
    }
}
