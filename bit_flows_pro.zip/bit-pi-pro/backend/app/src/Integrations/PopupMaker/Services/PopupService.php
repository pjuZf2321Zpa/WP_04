<?php

namespace BitApps\PiPro\src\Integrations\PopupMaker\Services;

use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\PopupMaker\PopupMakerHelper;
use PUM_Admin_Popups;
use PUM_Analytics;

if (!\defined('ABSPATH')) {
    exit;
}

final class PopupService extends BaseService
{
    private const POPUP_POST_TYPE = 'popup';

    private const SETTING_KEYS = ['theme_id', 'size', 'animation_type'];

    /**
     * Statuses a popup may be written with. WordPress silently falls back to draft for
     * anything it does not know, so a mapped value is checked before it is passed on.
     */
    private const POPUP_STATUSES = ['publish', 'draft', 'pending', 'private'];

    public function createPopup()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'title' => ['required', 'string'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        $invalidStatus = $this->rejectUnknownStatus($fieldMappings, self::POPUP_STATUSES);

        if (!empty($invalidStatus)) {
            return $invalidStatus;
        }

        $popupId = wp_insert_post(
            [
                'post_type'    => self::POPUP_POST_TYPE,
                'post_title'   => $fieldMappings['title'],
                'post_content' => $fieldMappings['content'] ?? '',
                'post_status'  => $fieldMappings['status'] ?? 'publish',
            ],
            true
        );

        if (is_wp_error($popupId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => $popupId->get_error_message(),
            ];
        }

        $this->applySettings($popupId, $fieldMappings, true);

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => PopupMakerHelper::getPopupData($popupId),
        ];
    }

    public function updatePopup()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'popup_id' => ['required'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        $invalidStatus = $this->rejectUnknownStatus($fieldMappings, self::POPUP_STATUSES);

        if (!empty($invalidStatus)) {
            return $invalidStatus;
        }

        $popupId = (int) $fieldMappings['popup_id'];

        if (!$this->resolvePopup($popupId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('No popup found with the given id.', 'bit-pi'),
            ];
        }

        $postData = $this->filterEmpty(
            [
                'post_title'   => $fieldMappings['title'] ?? null,
                'post_content' => $fieldMappings['content'] ?? null,
                'post_status'  => $fieldMappings['status'] ?? null,
            ]
        );

        if (!empty($postData)) {
            $postData['ID'] = $popupId;
            $updated = wp_update_post($postData, true);

            if (is_wp_error($updated)) {
                return [
                    'status_code' => 400,
                    'payload'     => $fieldMappings,
                    'response'    => $updated->get_error_message(),
                ];
            }
        }

        $this->applySettings($popupId, $fieldMappings, false);

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => PopupMakerHelper::getPopupData($popupId),
        ];
    }

    public function deletePopup()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'popup_id' => ['required'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        $popupId = (int) $fieldMappings['popup_id'];

        if (get_post_type($popupId) !== self::POPUP_POST_TYPE) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('No popup found with the given id.', 'bit-pi'),
            ];
        }

        $forceDelete = !empty($fieldMappings['force_delete']);
        $deleted = wp_delete_post($popupId, $forceDelete);

        if (!$deleted) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to delete the popup.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'popup_id'     => $popupId,
                'force_delete' => $forceDelete,
                'deleted'      => true,
            ],
        ];
    }

    public function changePopupStatus()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'popup_id' => ['required'],
            'status'   => ['required', 'string'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        $invalidStatus = $this->rejectUnknownStatus($fieldMappings, array_merge(self::POPUP_STATUSES, ['trash']));

        if (!empty($invalidStatus)) {
            return $invalidStatus;
        }

        $popupId = (int) $fieldMappings['popup_id'];

        if (get_post_type($popupId) !== self::POPUP_POST_TYPE) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('No popup found with the given id.', 'bit-pi'),
            ];
        }

        $updated = wp_update_post(
            [
                'ID'          => $popupId,
                'post_status' => $fieldMappings['status'],
            ],
            true
        );

        if (is_wp_error($updated)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => $updated->get_error_message(),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => PopupMakerHelper::getPopupData($popupId),
        ];
    }

    public function getPopup()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'popup_id' => ['required'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        $popupId = (int) $fieldMappings['popup_id'];

        if (!$this->resolvePopup($popupId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('No popup found with the given id.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => PopupMakerHelper::getPopupData($popupId),
        ];
    }

    public function resetPopupCounts()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'popup_id' => ['required'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        $popupId = (int) $fieldMappings['popup_id'];
        $popup = $this->resolvePopup($popupId);

        if (!$popup) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('No popup found with the given id.', 'bit-pi'),
            ];
        }

        if (!method_exists($popup, 'reset_counts')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Popup analytics reset is not supported by this Popup Maker version.', 'bit-pi'),
            ];
        }

        $popup->reset_counts();

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => PopupMakerHelper::getPopupData($popupId),
        ];
    }

    public function trackPopupEvent()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'popup_id' => ['required'],
            'event'    => ['required', 'string'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        $popupId = (int) $fieldMappings['popup_id'];
        $event = $fieldMappings['event'];

        if (!$this->resolvePopup($popupId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('No popup found with the given id.', 'bit-pi'),
            ];
        }

        if (!class_exists('PUM_Analytics')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Popup Maker analytics is not available.', 'bit-pi'),
            ];
        }

        if (!\in_array($event, PUM_Analytics::valid_events(), true)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Invalid analytics event. Use "open" or "conversion".', 'bit-pi'),
            ];
        }

        PUM_Analytics::track(
            [
                'pid'   => $popupId,
                'event' => $event,
            ]
        );

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => PopupMakerHelper::getPopupData($popupId),
        ];
    }

    /**
     * Returns a 400 envelope when a status was mapped that WordPress would not honour,
     * or null when the status is absent or allowed.
     */
    private function rejectUnknownStatus($fieldMappings, $allowedStatuses)
    {
        $status = $fieldMappings['status'] ?? '';

        if ($status === '' || \in_array($status, $allowedStatuses, true)) {
            return null;
        }

        return [
            'status_code' => 400,
            'payload'     => $fieldMappings,
            'response'    => \sprintf(
                // translators: %s: comma separated list of allowed statuses
                __('Invalid popup status. Use one of: %s.', 'bit-pi'),
                implode(', ', $allowedStatuses)
            ),
        ];
    }

    private function applySettings($popupId, $fieldMappings, $fillDefaults)
    {
        $popup = $this->resolvePopup($popupId);

        if (!$popup) {
            return;
        }

        if (!empty($fieldMappings['popup_title'])) {
            $popup->update_meta('popup_title', $fieldMappings['popup_title']);
        }

        $settings = [];

        foreach (self::SETTING_KEYS as $settingKey) {
            if (isset($fieldMappings[$settingKey]) && $fieldMappings[$settingKey] !== '') {
                $settings[$settingKey] = $fieldMappings[$settingKey];
            }
        }

        if ($fillDefaults && class_exists('PUM_Admin_Popups')) {
            $settings = PUM_Admin_Popups::fill_missing_defaults($settings);
        }

        if (!empty($settings)) {
            $popup->update_settings($settings);
        }
    }
}
