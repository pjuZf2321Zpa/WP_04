<?php

namespace BitApps\PiPro\src\Integrations\PopupMaker;

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Response;
use PUM_DB_Subscribers;

// Prevent direct script access
if (!defined('ABSPATH')) {
    exit;
}


class PopupMakerHelper
{
    public static function isPluginInstalled()
    {
        return defined('POPMAKE_VERSION') || class_exists('PUM_Model_Popup');
    }

    public static function setFields($formData)
    {
        $fieldsKey = ['name', 'fname', 'lname', 'email', 'consent'];

        if (empty($formData)) {
            return [];
        }

        $allFields = [
            ['name' => 'id', 'type' => 'text', 'label' => __('Popup Id', 'bit-pi'), 'value' => (string) $formData['popup_id']],
        ];

        foreach ($formData as $key => $item) {
            if (\in_array($key, $fieldsKey)) {
                $allFields[] = [
                    'name'  => $key,
                    'type'  => is_email($item) ? 'email' : 'text',
                    'label' => self::getLabelByKey($key),
                    'value' => $item,
                ];
            }
        }

        return $allFields;
    }

    public static function getPopupData($popupId)
    {
        $popupId = (int) $popupId;

        if (empty($popupId) || !\function_exists('pum_get_popup') || !\function_exists('pum_is_popup')) {
            return ['popup_id' => $popupId];
        }

        $popup = pum_get_popup($popupId);

        if (!pum_is_popup($popup)) {
            return ['popup_id' => $popupId];
        }

        return [
            'popup_id'         => $popup->ID,
            'name'             => get_the_title($popup->ID),
            'popup_title'      => $popup->get_title(),
            'content'          => $popup->get_content(),
            'status'           => get_post_status($popup->ID),
            'open_count'       => (int) $popup->get_event_count('open', 'current'),
            'conversion_count' => (int) $popup->get_event_count('conversion', 'current'),
            'total_opens'      => (int) $popup->get_event_count('open', 'total'),
            'settings'         => $popup->get_settings(),
            'edit_link'        => get_edit_post_link($popup->ID, ''),
        ];
    }

    public static function getPopups()
    {
        if (!self::isPluginInstalled()) {
            // translators: %s: Popup Maker
            return Response::error(\sprintf(__('%s is not installed or activated', 'bit-pi'), 'Popup Maker'));
        }

        return Response::success(self::postDropdown('popup'));
    }

    public static function getThemes()
    {
        if (!self::isPluginInstalled()) {
            // translators: %s: Popup Maker
            return Response::error(\sprintf(__('%s is not installed or activated', 'bit-pi'), 'Popup Maker'));
        }

        return Response::success(self::postDropdown('popup_theme'));
    }

    public static function getSubscribers()
    {
        return self::subscriberDropdown('ID');
    }

    public static function getSubscriberEmails()
    {
        return self::subscriberDropdown('email');
    }

    private static function subscriberDropdown($valueColumn)
    {
        if (!self::isPluginInstalled() || !class_exists('PUM_DB_Subscribers')) {
            // translators: %s: Popup Maker
            return Response::error(\sprintf(__('%s is not installed or activated', 'bit-pi'), 'Popup Maker'));
        }

        $subscribers = PUM_DB_Subscribers::instance()->query([], 'ARRAY_A');
        $options = [];

        foreach ((array) $subscribers as $subscriber) {
            $subscriber = (array) $subscriber;
            $label = $subscriber['email'] ?? '';

            if (!empty($subscriber['name'])) {
                $label = $subscriber['name'] . ' (' . $label . ')';
            }

            $options[] = [
                'value' => $subscriber[$valueColumn] ?? '',
                'label' => $label,
            ];
        }

        return Response::success($options);
    }

    private static function postDropdown($postType)
    {
        $options = [];

        $posts = get_posts(
            [
                'post_type'      => $postType,
                'post_status'    => ['publish', 'draft', 'pending', 'private'],
                'orderby'        => 'title',
                'order'          => 'ASC',
                'posts_per_page' => -1,
            ]
        );

        foreach ($posts as $post) {
            $options[] = [
                'value' => $post->ID,
                'label' => $post->post_title !== '' ? $post->post_title : \sprintf('#%d', $post->ID),
            ];
        }

        return $options;
    }

    private static function getLabelByKey($key)
    {
        $labels = [
            'fname' => 'First Name',
            'lname' => 'Last Name',
        ];

        return $labels[$key] ?? ucfirst($key);
    }
}
