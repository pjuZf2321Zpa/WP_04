<?php

namespace BitApps\PiPro\src\Integrations\PopupMaker;

// Prevent direct script access
if (!defined('ABSPATH')) {
    exit;
}


use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;

final class PopupMakerTrigger
{
    public static function handleSubmit(...$record)
    {
        $data = PopupMakerHelper::setFields($record[0]);

        self::execute('popupFormSubmit', $data);
    }

    public static function popupOpened($popupId, $args = [])
    {
        $data = [
            'popup_id'   => (int) $popupId,
            'event_data' => (array) $args,
            'popup'      => PopupMakerHelper::getPopupData($popupId),
        ];

        self::execute('popupOpened', $data);
    }

    private static function execute($machineSlug, $data)
    {
        if (!PopupMakerHelper::isPluginInstalled()) {
            return;
        }

        $flows = FlowService::exists('popupMaker', $machineSlug);

        if (!$flows || empty($data)) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $data);
    }
}
