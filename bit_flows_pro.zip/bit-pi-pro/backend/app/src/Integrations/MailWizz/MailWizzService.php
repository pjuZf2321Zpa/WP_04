<?php

namespace BitApps\PiPro\src\Integrations\MailWizz;

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Client\HttpClient;

// Prevent direct script access
if (!defined('ABSPATH')) {
    exit;
}

final class MailWizzService
{
    private HttpClient $http;

    private string $baseUrl;

    /**
     * MailWizzService constructor.
     */
    public function __construct(HttpClient $httpClient, string $baseUrl)
    {
        $this->http = $httpClient;
        $this->baseUrl = rtrim($baseUrl, '/');
    }

    /**
     * Add a new subscriber to a list.
     *
     * @param string $listId
     * @param mixed $subscriberField
     *
     * @return array
     */
    public function createSubscriber($listId, $subscriberField)
    {
        $endPoint = $this->baseUrl . '/api/index.php/lists/' . $listId . '/subscribers';

        $data = array_filter(
            $subscriberField,
            function ($value) {
                return !\is_null($value) && $value !== '';
            }
        );

        $response = $this->http->request($endPoint, 'POST', http_build_query($data));

        return [
            'response' => $response,
            'payload'  => [
                'list_id' => $listId,
                'email'   => $subscriberField['EMAIL']
            ],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Update a subscriber in a list.
     *
     * @param string $listId
     * @param string $subscriberUid
     * @param mixed $subscriberField
     *
     * @return array
     */
    public function updateSubscriber($listId, $subscriberUid, $subscriberField)
    {
        $endPoint = $this->baseUrl . '/api/index.php/lists/' . $listId . '/subscribers/' . $subscriberUid;

        $data = array_filter(
            $subscriberField,
            function ($value) {
                return !\is_null($value) && $value !== '';
            }
        );

        $response = $this->http->request($endPoint, 'PUT', http_build_query($data));

        return [
            'response' => $response,
            'payload'  => [
                'list_id'        => $listId,
                'subscriber_uid' => $subscriberUid,
                'email'          => $subscriberField['EMAIL'] ?? null
            ],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Unsubscribe a subscriber from a list by updating their status.
     *
     * @param string $listId
     * @param string $subscriberUid
     *
     * @return array
     */
    public function unsubscribe($listId, $subscriberUid)
    {
        $endPoint = $this->baseUrl . '/api/index.php/lists/' . $listId . '/subscribers/' . $subscriberUid;

        $data = [
            'details' => [
                'status' => 'unsubscribed'
            ]
        ];

        $response = $this->http->request($endPoint, 'PUT', http_build_query($data));

        return [
            'response' => $response,
            'payload'  => [
                'list_id'        => $listId,
                'subscriber_uid' => $subscriberUid,
            ],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Send a transactional email.
     *
     * @param array $fieldMapData
     *
     * @return array
     */
    public function createTransactionalEmail($fieldMapData)
    {
        $endPoint = $this->baseUrl . '/api/transactional-emails';

        $bodyParams = [
            'email[to_name]'        => $fieldMapData['to_name'] ?? null,
            'email[to_email]'       => $fieldMapData['to_email'] ?? null,
            'email[from_name]'      => $fieldMapData['from_name'] ?? null,
            'email[from_email]'     => $fieldMapData['from_email'] ?? null,
            'email[reply_to_name]'  => $fieldMapData['reply_to_name'] ?? null,
            'email[reply_to_email]' => $fieldMapData['reply_to_email'] ?? null,
            'email[subject]'        => $fieldMapData['subject'] ?? null,
            'email[body]'           => isset($fieldMapData['body']) ? base64_encode($fieldMapData['body']) : null,
            'email[plain_text]'     => $fieldMapData['plain_text'] ?? null,
            'email[send_at]'        => $fieldMapData['send_at'] ?? null,
        ];

        if (!empty($fieldMapData['attachments']) && \is_array($fieldMapData['attachments'])) {
            $attachments = [];
            foreach ($fieldMapData['attachments'] as $attachment) {
                $name = $attachment['name'] ?? 'file';
                $url = $attachment['data'] ?? ($attachment['url'] ?? null);

                if ($url && wp_http_validate_url($url)) {
                    $remoteResponse = wp_safe_remote_get($url);

                    if (!is_wp_error($remoteResponse)) {
                        $fileContent = wp_remote_retrieve_body($remoteResponse);
                        if (!empty($fileContent)) {
                            $attachments[] = [
                                'name' => $name,
                                'data' => base64_encode($fileContent)
                            ];
                        }
                    }
                }
            }

            if (!empty($attachments)) {
                $bodyParams['attachments'] = $attachments;
            }
        }

        $bodyParams = array_filter(
            $bodyParams,
            function ($v) {
                return !\is_null($v);
            }
        );

        $response = $this->http->request($endPoint, 'POST', $bodyParams);

        return [
            'response' => $response,
            'payload'  => [
                'to_email' => $bodyParams['email[to_email]'] ?? null
            ],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Search subscribers by email.
     *
     * @param mixed $listId
     * @param mixed $email
     *
     * @return array
     */
    public function searchSubscribersByEmail($listId, $email)
    {
        $endPoint = $this->baseUrl . '/api/index.php/lists/' . $listId . '/subscribers/search-by-email';

        $queryParams = [
            'EMAIL' => $email
        ];

        $endPoint = add_query_arg($queryParams, $endPoint);
        $response = $this->http->request($endPoint, 'GET', []);

        return [
            'response' => $response,
            'payload'  => [
                'list_id' => $listId,
                'email'   => $email
            ],
            'status_code' => $this->http->getResponseCode()
        ];
    }
}
