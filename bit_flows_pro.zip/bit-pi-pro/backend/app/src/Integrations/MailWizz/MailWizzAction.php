<?php

namespace BitApps\PiPro\src\Integrations\MailWizz;

// Prevent direct script access
if (!defined('ABSPATH')) {
    exit;
}


use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Authorization\AuthorizationFactory;
use BitApps\Pi\src\Authorization\AuthorizationType;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Client\HttpClient;
use InvalidArgumentException;

class MailWizzAction implements ActionInterface
{
    private NodeInfoProvider $nodeInfoProvider;

    private MailWizzService $mailWizzService;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeIntegrationAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'],
            $executedNodeAction['payload'],
            $executedNodeAction['response']
        );
    }

    private function executeMachine(string $machineSlug, array $configs, array $fieldMapData)
    {
        $listId = $configs['list-id']['value'] ?? null;

        switch ($machineSlug) {
            case 'createSubscriber':
                $subscriberField = $this->nodeInfoProvider->getFieldMapRepeaters('field-map.value', false, true, 'mailWizzField', 'value');

                return $this->mailWizzService->createSubscriber($listId, $subscriberField);

            case 'updateSubscriber':
                $subscriberField = $this->nodeInfoProvider->getFieldMapRepeaters('field-map.value', false, true, 'mailWizzField', 'value');

                return $this->mailWizzService->updateSubscriber($listId, $configs['subscriber-id']['value'] ?? null, $subscriberField);

            case 'unsubscribe':
                $subscriberUid = $configs['subscriber-id']['value'] ?? null;

                return $this->mailWizzService->unsubscribe($listId, $subscriberUid);

            case 'transactionalEmail':
                return $this->mailWizzService->createTransactionalEmail($fieldMapData);

            case 'searchSubscribersByEmail':
                return $this->mailWizzService->searchSubscribersByEmail($listId, $fieldMapData['email'] ?? '');


            default:
                throw new InvalidArgumentException(\sprintf('Unknown MailWizz machine slug: %s', $machineSlug));
        }
    }

    private function executeIntegrationAction(): array
    {
        $machineSlug = $this->nodeInfoProvider->getMachineSlug();
        $configs = $this->nodeInfoProvider->getFieldMapConfigs();
        $fieldMapData = $this->nodeInfoProvider->getFieldMapData();

        $apiKeyAuthorization = AuthorizationFactory::getAuthorizationHandler(
            AuthorizationType::API_KEY,
            $configs['connection-id']
        );

        $apiKey = $apiKeyAuthorization->getAccessToken();
        $connection = $apiKeyAuthorization->getConnection();
        $mailWizzUrl = $connection->auth_details->extraData->mailWizzUrl;

        $httpClient = new HttpClient(
            [
                'headers' => [
                    'Content-Type'    => 'application/x-www-form-urlencoded',
                    'X-Mw-Public-Key' => $apiKey,
                ],
            ]
        );

        $this->mailWizzService = new MailWizzService($httpClient, $mailWizzUrl);

        return $this->executeMachine($machineSlug, $configs, $fieldMapData);
    }
}
