<?php

namespace BitApps\PiPro\src\Integrations\BookingCalendarContactForm;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!\defined('ABSPATH')) {
    exit;
}

class BookingCalendarContactFormHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'formSubmission' => [
                'hook'     => 'dexbccf_process_data',
                'callback' => [BookingCalendarContactFormTrigger::class, 'formSubmission'],
                'priority' => 10,
            ],
        ];
    }
}
