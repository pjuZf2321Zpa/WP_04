<?php

namespace BitApps\PiPro\src\Integrations\WpFusion;

// Prevent direct script access
if (!\defined('ABSPATH')) {
    exit;
}


use BitApps\Pi\src\Integrations\ApiRequest\ApiRequestAction;

class WpFusionAction extends ApiRequestAction
{
    // extends ApiRequestAction
}
