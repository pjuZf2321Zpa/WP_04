<?php

namespace BitApps\PiPro\src\Integrations\PeepSo;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\PiPro\Deps\BitApps\WPKit\Hooks\Hooks;
use PeepSo;
use PeepSoActivityStream;
use PeepSoUser;
use PeepSoUserFollower;

if (!defined('ABSPATH')) {
    exit;
}

final class PeepSoServices
{
    private const ACTIVITY_POST_MODULE_ID = 1;

    private const SYSTEM_ROLES = ['member', 'admin', 'ban', 'register', 'verified'];

    private $nodeInfoProvider;

    private $fieldMappings;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
        $this->fieldMappings = $this->nodeInfoProvider->getFieldMapData();
    }

    public function addPostActivityStream()
    {
        $requiredClasses = ['PeepSo', 'PeepSoUser', 'PeepSoActivityStream'];
        $rules = [
            'user_email'   => ['required', 'email'],
            'post_title'   => ['required', 'string'],
            'post_content' => ['required', 'string'],
        ];

        $error = $this->validateRequirements($requiredClasses, $rules);
        if ($error) {
            return $error;
        }

        $userId = $this->getUserId();
        if (\is_array($userId)) {
            return $userId;
        }

        $postId = $this->createPost(
            $userId,
            $this->fieldMappings['post_title'],
            $this->fieldMappings['post_content']
        );
        if (\is_array($postId)) {
            return $postId;
        }

        $profileAccessibility = $this->getProfileAccessibility($userId);
        $activityData = $this->buildActivityData($userId, $postId, $profileAccessibility);

        if (!$this->insertActivity($activityData)) {
            wp_delete_post($postId, true);

            return [
                'response'    => __('Unable to create activity.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 400
            ];
        }

        if (absint($activityData['act_module_id']) === self::ACTIVITY_POST_MODULE_ID) {
            update_user_meta($userId, 'peepso_last_used_post_privacy', $profileAccessibility);
        }

        $filteredContent = $this->updatePostContentWithFilters($postId, $this->fieldMappings['post_content']);

        return [
            'response'    => $this->buildPostActivityResponse($postId, $filteredContent, $userId),
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }

    public function changeUserRole()
    {
        $requiredClasses = ['PeepSo', 'PeepSoUser'];
        $rules = [
            'user_email' => ['required', 'email'],
            'new_role'   => ['required', 'string'],
        ];

        $error = $this->validateRequirements($requiredClasses, $rules);
        if ($error) {
            return $error;
        }

        $userId = $this->getUserId();
        if (\is_array($userId)) {
            return $userId;
        }

        $newRole = $this->fieldMappings['new_role'];
        if (!$this->isValidSystemRole($newRole)) {
            return [
                'response'    => __("The selected role doesn't exist.", 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 400
            ];
        }

        $user = PeepSoUser::get_instance($userId);

        if (!$user || $user->get_id() === null) {
            return [
                'response'    => __('Invalid User.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 400
            ];
        }

        if (PeepSo::is_admin($userId) && $newRole === 'ban') {
            return [
                'response'    => __('You cannot ban administrators.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 400
            ];
        }

        $user->approve_user();
        $user->set_user_role($newRole);

        return [
            'response' => [
                'user_id'          => $userId,
                'new_role'         => $newRole,
                'user_data'        => Utility::getUserInfo($userId),
                'peepso_user_data' => $user->get_peepso_user(),
            ],
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }

    public function followUser()
    {
        $rules = [
            'user_email'        => ['required', 'email'],
            'follow_user_email' => ['required', 'email'],
        ];

        $error = $this->validateRequirements('PeepSoUserFollower', $rules);
        if ($error) {
            return $error;
        }

        $userId = $this->getUserId();
        if (\is_array($userId)) {
            return $userId;
        }

        $followUserId = $this->getUserId('follow_user_email');
        if (\is_array($followUserId)) {
            return $followUserId;
        }

        $peepsoUserFollower = new PeepSoUserFollower($followUserId, $userId, true);
        $peepsoUserFollower->set('follow', 1);

        if (!$peepsoUserFollower->follow) {
            return [
                'response'    => __('Unable to follow user.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 400
            ];
        }

        return [
            'response' => [
                'data'      => Utility::jsonEncodeDecode($peepsoUserFollower),
                'follower'  => Utility::getUserInfo($userId),
                'following' => Utility::getUserInfo($followUserId),
            ],
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }

    private function validateRequirements($classNames, array $rules)
    {
        if ($error = self::checkClassExists($classNames)) {
            return $error;
        }

        return PeepSoHelper::validateFieldMap($this->fieldMappings, $rules);
    }

    private function createPost($userId, $postTitle, $content)
    {
        $postId = wp_insert_post(
            [
                'post_title'   => $postTitle,
                'post_excerpt' => $content,
                'post_content' => $content,
                'post_status'  => 'publish',
                'post_author'  => $userId,
                'post_type'    => PeepSoActivityStream::CPT_POST,
            ]
        );

        if (!$postId || is_wp_error($postId)) {
            return [
                'response'    => __('Unable to create post.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 400
            ];
        }

        add_post_meta($postId, '_peepso_display_link_preview', 1, true);

        return $postId;
    }

    private function getProfileAccessibility($userId)
    {
        return PeepSoUser::get_instance($userId)->get_profile_accessibility();
    }

    private function buildActivityData($userId, $postId, $profileAccessibility)
    {
        $activityData = [
            'act_owner_id'    => $userId,
            'act_module_id'   => self::ACTIVITY_POST_MODULE_ID,
            'act_external_id' => $postId,
            'act_access'      => $profileAccessibility,
            'act_ip'          => PeepSo::get_ip_address(),
        ];

        $filteredData = Hooks::applyFilter('peepso_activity_insert_data', $activityData);

        return \is_array($filteredData) ? $filteredData : $activityData;
    }

    private function insertActivity(array $activityData)
    {
        global $wpdb;

        $result = $wpdb->insert($wpdb->prefix . 'peepso_activities', $activityData);

        return $result !== false;
    }

    private function updatePostContentWithFilters($postId, $content)
    {
        $filteredContent = Hooks::applyFilter('peepso_activity_post_content', $content, $postId);

        wp_update_post(
            [
                'ID'           => $postId,
                'post_content' => $filteredContent,
            ]
        );

        return $filteredContent;
    }

    private function buildPostActivityResponse($postId, $filteredContent, $userId)
    {
        $post = get_post($postId);

        return [
            'content'   => $filteredContent,
            'status'    => 'published',
            'permalink' => PeepSo::get_page('activity_status') . $post->post_title,
            'post'      => $post,
            'user'      => Utility::getUserInfo($userId),
        ];
    }

    private function isValidSystemRole($role)
    {
        return !empty($role) && \in_array($role, self::SYSTEM_ROLES, true);
    }

    private function getUserId($fieldKey = 'user_email')
    {
        $user = get_user_by('email', $this->fieldMappings[$fieldKey]);

        if (!$user) {
            return [
                'response'    => __('User not found.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 404
            ];
        }

        return $user->ID;
    }

    private static function checkClassExists($classNames)
    {
        if (!\is_array($classNames)) {
            $classNames = [$classNames];
        }

        foreach ($classNames as $className) {
            if (!class_exists($className)) {
                return [
                    // translators: %s is the class name.
                    'response'    => \sprintf(__('%s class not available.', 'bit-pi'), $className),
                    'payload'     => ['class' => $className],
                    'status_code' => 400
                ];
            }
        }
    }
}
