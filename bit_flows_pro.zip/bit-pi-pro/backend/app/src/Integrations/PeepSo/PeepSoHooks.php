<?php

namespace BitApps\PiPro\src\Integrations\PeepSo;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!\defined('ABSPATH')) {
    exit;
}

class PeepSoHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'userFollowsMember' => [
                'hook'     => 'peepso_ajax_start',
                'callback' => [PeepSoTrigger::class, 'handleUserFollowsMember'],
            ],
            'userGainsFollower' => [
                'hook'     => 'peepso_ajax_start',
                'callback' => [PeepSoTrigger::class, 'handleUserGainsFollower'],
            ],
            'userLosesFollower' => [
                'hook'     => 'peepso_ajax_start',
                'callback' => [PeepSoTrigger::class, 'handleUserLosesFollower'],
            ],
            'userUnfollowsMember' => [
                'hook'     => 'peepso_ajax_start',
                'callback' => [PeepSoTrigger::class, 'handleUserUnfollowsMember'],
            ],
            'userUpdatesAvatar' => [
                'hook'          => 'peepso_user_after_change_avatar',
                'callback'      => [PeepSoTrigger::class, 'handleUserUpdatesAvatar'],
                'accepted_args' => 4,
            ],
            'userUpdatesSpecificProfileFieldValue' => [
                'hook'     => 'peepso_ajax_start',
                'callback' => [PeepSoTrigger::class, 'handleUserUpdatesSpecificProfileFieldValue'],
            ],
            'userUpdatesSpecificProfileField' => [
                'hook'     => 'peepso_ajax_start',
                'callback' => [PeepSoTrigger::class, 'handleUserUpdatesSpecificProfileField'],
            ],
            'writeActivityPost' => [
                'hook'          => 'peepso_activity_after_add_post',
                'callback'      => [PeepSoTrigger::class, 'handleWriteActivityPost'],
                'accepted_args' => 2,
            ],
        ];
    }
}
