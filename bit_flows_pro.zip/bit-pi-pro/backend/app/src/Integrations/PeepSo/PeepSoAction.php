<?php

namespace BitApps\PiPro\src\Integrations\PeepSo;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;

if (!\defined('ABSPATH')) {
    exit;
}

class PeepSoAction implements ActionInterface
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executePeepSoAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'] ?? 200,
            $executedNodeAction['payload'] ?? [],
            $executedNodeAction['response'] ?? []
        );
    }

    private function executePeepSoAction()
    {
        if (!PeepSoHelper::isPluginActive()) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('PeepSo plugin is not active.', 'bit-pi'),
            ];
        }

        $peepSoServices = new PeepSoServices($this->nodeInfoProvider);

        $machineSlug = $this->nodeInfoProvider->getMachineSlug();

        if (!\is_callable([$peepSoServices, $machineSlug])) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('PeepSo action not found.', 'bit-pi'),
            ];
        }

        return $peepSoServices->{$machineSlug}();
    }
}
