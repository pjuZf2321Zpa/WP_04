<?php

namespace BitApps\PiPro\src\Integrations\PeepSo;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;

if (!\defined('ABSPATH')) {
    exit;
}

class PeepSoTrigger
{
    private const FOLLOW_ACTION = 'followerajax.set_follow_status';

    private const PROFILE_FIELD_ACTIONS = [
        'profilefieldsajax.savefield',
        'profilefieldsajax.save_acc',
        'profilepreferencesajax.savepreference',
    ];

    public static function handleUserFollowsMember($data)
    {
        self::handleFollowTrigger($data, 'userFollowsMember', 1);
    }

    public static function handleUserGainsFollower($data)
    {
        self::handleFollowTrigger($data, 'userGainsFollower', 1);
    }

    public static function handleUserLosesFollower($data)
    {
        self::handleFollowTrigger($data, 'userLosesFollower', 0);
    }

    public static function handleUserUnfollowsMember($data)
    {
        self::handleFollowTrigger($data, 'userUnfollowsMember', 0);
    }

    public static function handleUserUpdatesAvatar($userId, $avatarUrl = null, $avatarUrlFull = null, $avatarUrlOrig = null)
    {
        if (empty($userId)) {
            return;
        }

        $data = [
            'user'            => Utility::getUserInfo($userId),
            'avatar_url'      => $avatarUrl,
            'avatar_url_full' => $avatarUrlFull,
            'avatar_url_orig' => $avatarUrlOrig,
        ];

        self::execute('userUpdatesAvatar', $data);
    }

    public static function handleUserUpdatesSpecificProfileFieldValue($data)
    {
        self::handleSpecificProfileFieldUpdate($data, 'userUpdatesSpecificProfileFieldValue');
    }

    public static function handleUserUpdatesSpecificProfileField($data)
    {
        self::handleSpecificProfileFieldUpdate($data, 'userUpdatesSpecificProfileField');
    }

    public static function handleWriteActivityPost($postId, $activityId)
    {
        $userId = self::getPostAuthorId($postId);

        if (empty($userId)) {
            return;
        }

        $data = [
            'activity_id' => $activityId,
            'post'        => get_post($postId),
            'user'        => Utility::getUserInfo($userId),
        ];

        self::execute('writeActivityPost', $data);
    }

    private static function handleFollowTrigger($data, $machineSlug, $expectedStatus)
    {
        if ($data !== self::FOLLOW_ACTION) {
            return;
        }

        $data = self::getFollowRequestData();

        if (empty($data) || $data['follow_status'] !== $expectedStatus) {
            return;
        }

        self::execute($machineSlug, self::buildFollowTriggerData($data));
    }

    private static function handleSpecificProfileFieldUpdate($data, $machineSlug)
    {
        if (!\in_array($data, self::PROFILE_FIELD_ACTIONS)) {
            return;
        }

        $data = self::getSpecificProfileFieldRequestData();

        if (empty($data)) {
            return;
        }

        self::execute($machineSlug, $data);
    }

    private static function getFollowRequestData()
    {
        $followerId = isset($_POST['uid']) ? absint($_POST['uid']) : null;
        $userId = isset($_POST['user_id']) ? absint($_POST['user_id']) : null;
        $followStatus = isset($_POST['follow']) ? absint($_POST['follow']) : null;

        if (empty($followerId) || empty($userId) || $followStatus === null) {
            return;
        }

        return [
            'follower_id'   => $followerId,
            'user_id'       => $userId,
            'follow_status' => $followStatus,
        ];
    }

    private static function buildFollowTriggerData(array $request)
    {
        return [
            'follower'  => Utility::getUserInfo($request['follower_id']),
            'following' => Utility::getUserInfo($request['user_id']),
            'status'    => $request['follow_status'],
        ];
    }

    private static function getSpecificProfileFieldRequestData()
    {
        $fieldId = isset($_POST['id']) ? sanitize_key($_POST['id']) : null;
        $fieldValue = isset($_POST['value']) ? sanitize_text_field(wp_unslash($_POST['value'])) : null;
        $userId = isset($_POST['view_user_id']) ? absint($_POST['view_user_id']) : null;

        if (empty($fieldId) || $fieldValue === null || empty($userId)) {
            return;
        }

        return [
            'user_profile_field_id'    => $fieldId,
            'user_profile_field_value' => $fieldValue,
            'user'                     => Utility::getUserInfo($userId),
        ];
    }

    private static function getPostAuthorId($postId)
    {
        $postAuthor = get_post_field('post_author', $postId);

        return $postAuthor ? absint($postAuthor) : null;
    }

    private static function execute($machineSlug, $data)
    {
        $flows = FlowService::exists('peepSo', $machineSlug);

        if (!$flows) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $data);
    }
}
