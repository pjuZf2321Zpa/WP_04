<?php

namespace BitApps\PiPro\src\Integrations\FluentSupport;

use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\FluentSupport\helper\FluentSupportHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class FluentSupportTrigger
{
    public static function ticketCreated($ticket, $customer)
    {
        $data = FluentSupportHelper::getTicketData($ticket, $customer);

        self::execute('ticketCreated', $data);
    }

    public static function responseAddedByAgent($response, $ticket, $customer)
    {
        $data = FluentSupportHelper::getResponseData($response, $ticket, $customer);

        self::execute('responseAddedByAgent', $data);
    }

    public static function responseAddedByCustomer($response, $ticket, $customer)
    {
        $data = FluentSupportHelper::getResponseData($response, $ticket, $customer);

        self::execute('responseAddedByCustomer', $data);
    }

    public static function ticketClosedByAgent($ticket, $user)
    {
        $data = FluentSupportHelper::getTicketWithUserData($ticket, $user);

        self::execute('ticketClosedByAgent', $data);
    }

    public static function ticketClosedByCustomer($ticket, $user)
    {
        $data = FluentSupportHelper::getTicketWithUserData($ticket, $user);

        self::execute('ticketClosedByCustomer', $data);
    }

    public static function ticketClosedProduct($ticket)
    {
        $data = FluentSupportHelper::getSimpleTicketData($ticket);

        self::execute('ticketClosedProduct', $data);
    }

    public static function ticketCreatedProduct($ticket)
    {
        $data = FluentSupportHelper::getSimpleTicketData($ticket);

        self::execute('ticketCreatedProduct', $data);
    }

    public static function ticketProductRepliedAgent($response, $ticket)
    {
        $data = FluentSupportHelper::getResponseWithTicketData($response, $ticket);

        self::execute('ticketProductRepliedAgent', $data);
    }

    public static function ticketProductRepliedCustomer($response, $ticket)
    {
        $data = FluentSupportHelper::getResponseWithTicketData($response, $ticket);

        self::execute('ticketProductRepliedCustomer', $data);
    }

    private static function execute($machineSlug, $data)
    {
        $flows = FlowService::exists('fluentSupport', $machineSlug);

        if (!$flows || empty($data)) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $data);
    }
}
