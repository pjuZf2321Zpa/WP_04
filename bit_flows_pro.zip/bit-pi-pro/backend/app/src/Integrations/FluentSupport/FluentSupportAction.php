<?php

namespace BitApps\PiPro\src\Integrations\FluentSupport;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;
use BitApps\PiPro\src\Integrations\FluentSupport\helper\FluentSupportHelper;

if (!defined('ABSPATH')) {
    exit;
}

class FluentSupportAction implements ActionInterface
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeFluentSupportAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'] ?? 200,
            $executedNodeAction['payload'] ?? [],
            $executedNodeAction['response'] ?? []
        );
    }

    private function executeFluentSupportAction()
    {
        if (!FluentSupportHelper::isPluginInstalled()) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('Fluent Support plugin is not active.', 'bit-pi'),
            ];
        }

        $fluentSupportServices = new FluentSupportServices($this->nodeInfoProvider);

        $machineSlug = $this->nodeInfoProvider->getMachineSlug();

        if (!\is_callable([$fluentSupportServices, $machineSlug])) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('Fluent Support action not found.', 'bit-pi'),
            ];
        }

        return $fluentSupportServices->{$machineSlug}();
    }
}
