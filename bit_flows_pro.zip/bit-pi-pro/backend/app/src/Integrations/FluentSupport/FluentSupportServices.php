<?php

namespace BitApps\PiPro\src\Integrations\FluentSupport;

use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\PiPro\src\Integrations\FluentSupport\helper\FluentSupportHelper;
use Exception;
use FluentSupport\App\Api\Classes\Tickets;
use FluentSupport\App\Models\Agent;
use FluentSupport\App\Models\Conversation;
use FluentSupport\App\Models\Customer;
use FluentSupport\App\Models\Ticket;
use FluentSupport\App\Models\TicketTag;
use FluentSupport\App\Services\Tickets\TicketService;

if (!defined('ABSPATH')) {
    exit;
}

final class FluentSupportServices
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    /**
     * Create Ticket.
     *
     * @return array
     */
    public function createTicket()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationErrors = FluentSupportHelper::validateFieldMap(
            $fieldMappings,
            [
                'ticket_subject' => ['required', 'string'],
                'ticket_details' => ['required', 'string'],
                'customer_id'    => ['required', 'integer'],
            ]
        );

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $error = $this->checkRequiredClassExists(
            [
                '\FluentSupport\App\Services\Tickets\TicketService',
                '\FluentSupport\App\Models\Customer',
            ]
        );
        if ($error) {
            return $error;
        }

        $customer = Customer::find($fieldMappings['customer_id']);
        if (!$customer) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Customer not found in Fluent Support.', 'bit-pi'),
            ];
        }

        $data = $this->buildTicketPayload($fieldMappings);

        try {
            $ticketService = new TicketService();
            $responseData = $ticketService->storeTicket($data, $customer);

            if ($responseData) {
                return [
                    'status_code' => 200,
                    'payload'     => $fieldMappings,
                    'response'    => FluentSupportHelper::extractObjectAttributes($responseData),
                ];
            }

            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to create ticket.', 'bit-pi'),
            ];
        } catch (Exception $e) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => $e->getMessage(),
            ];
        }
    }

    /**
     * Add Tag to Ticket.
     *
     * @return array
     */
    public function addTagToTicket()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationErrors = FluentSupportHelper::validateFieldMap(
            $fieldMappings,
            [
                'ticket_id' => ['required', 'integer'],
                'tags'      => ['required', 'string']
            ]
        );

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $error = $this->checkRequiredClassExists(
            [
                '\FluentSupport\App\Models\Ticket',
                '\FluentSupport\App\Models\TicketTag',
            ]
        );
        if ($error) {
            return $error;
        }

        $ticketId = (int) $fieldMappings['ticket_id'];
        $tags = $this->extractTags($fieldMappings['tags']);

        $ticket = Ticket::find($ticketId);

        if (!$ticket) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Ticket not found.', 'bit-pi'),
            ];
        }

        $tagIds = $this->getOrCreateTagIds($tags);

        try {
            $ticket->applyTags($tagIds);

            return [
                'status_code' => 200,
                'payload'     => $fieldMappings,
                'response'    => [
                    'message'   => __('Tags added successfully.', 'bit-pi'),
                    'ticket_id' => $ticketId,
                    'tag_ids'   => $tagIds
                ],
            ];
        } catch (Exception $e) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => $e->getMessage(),
            ];
        }
    }

    /**
     * Reply to Ticket as Agent.
     *
     * @return array
     */
    public function replyToTicketAsAgent()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationErrors = FluentSupportHelper::validateFieldMap(
            $fieldMappings,
            [
                'ticket_id'     => ['required', 'integer'],
                'reply_content' => ['required', 'string'],
                'user_id'       => ['required', 'integer'],
            ]
        );

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $error = $this->checkRequiredClassExists(
            [
                '\FluentSupport\App\Models\Ticket',
                '\FluentSupport\App\Models\Conversation',
                '\FluentSupport\App\Models\Agent',
            ]
        );
        if ($error) {
            return $error;
        }

        $ticketId = (int) $fieldMappings['ticket_id'];
        $replyContent = wp_kses_post($fieldMappings['reply_content']);
        $userId = (int) $fieldMappings['user_id'];
        $conversationType = $fieldMappings['conversation_type'] ?? 'response';

        $ticket = Ticket::find($ticketId);

        if (!$ticket) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Ticket not found.', 'bit-pi'),
            ];
        }

        $agent = Agent::where('id', $userId)->first();
        if (!$agent) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Agent not found.', 'bit-pi'),
            ];
        }

        try {
            $conversation = Conversation::create($this->buildAgentConversationPayload($ticketId, $replyContent, $userId, $conversationType));

            return [
                'status_code' => 200,
                'payload'     => $fieldMappings,
                'response'    => [
                    'message'      => __('Reply added successfully.', 'bit-pi'),
                    'conversation' => FluentSupportHelper::extractObjectAttributes($conversation)
                ],
            ];
        } catch (Exception $e) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => $e->getMessage(),
            ];
        }
    }

    /**
     * Block User.
     *
     * @return array
     */
    public function blockUser()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationErrors = FluentSupportHelper::validateFieldMap(
            $fieldMappings,
            [
                'customer_email' => ['required', 'email'],
            ]
        );

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $error = $this->checkRequiredClassExists('\FluentSupport\App\Models\Customer');
        if ($error) {
            return $error;
        }

        $email = $fieldMappings['customer_email'];

        $customer = $this->findCustomerByEmail($email);

        if (!$customer) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User not found in Fluent Support.', 'bit-pi'),
            ];
        }

        try {
            $customer->update(['status' => 'blocked']);
        } catch (Exception $e) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => $e->getMessage(),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'message' => __('User successfully blocked.', 'bit-pi'),
                'email'   => $email
            ],
        ];
    }

    /**
     * Create or Obtain Customer.
     *
     * @return array
     */
    public function createOrObtainCustomer()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationErrors = FluentSupportHelper::validateFieldMap(
            $fieldMappings,
            [
                'customer_email' => ['required', 'email'],
                'first_name'     => ['required', 'string'],
                'last_name'      => ['required', 'string']
            ]
        );

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $error = $this->checkRequiredClassExists('\FluentSupport\App\Models\Customer');
        if ($error) {
            return $error;
        }

        $email = $fieldMappings['customer_email'];

        $customer = $this->findCustomerByEmail($email);

        try {
            if (!$customer) {
                $customer = Customer::create(
                    [
                        'email'      => $email,
                        'first_name' => $fieldMappings['first_name'],
                        'last_name'  => $fieldMappings['last_name']
                    ]
                );
            }
        } catch (Exception $e) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => $e->getMessage(),
            ];
        }

        if (!$customer) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to create or obtain customer.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => FluentSupportHelper::extractObjectAttributes($customer),
        ];
    }

    /**
     * Get All Tickets.
     *
     * @return array
     */
    public function getAllTickets()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $error = $this->checkRequiredClassExists(
            [
                '\FluentSupport\App\Models\Ticket',
                '\FluentSupport\App\Api\Classes\Tickets',
            ]
        );
        if ($error) {
            return $error;
        }

        try {
            $ticketsInstance = new Tickets(new Ticket());
            $response = $ticketsInstance->getTickets();

            if ($response) {
                return [
                    'status_code' => 200,
                    'payload'     => $fieldMappings,
                    'response'    => [
                        'message' => __('Tickets retrieved successfully.', 'bit-pi'),
                        'data'    => $response
                    ],
                ];
            }

            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('No tickets found.', 'bit-pi'),
            ];
        } catch (Exception $e) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => $e->getMessage(),
            ];
        }
    }

    private function checkRequiredClassExists($classNames)
    {
        if (!\is_array($classNames)) {
            $classNames = [$classNames];
        }

        foreach ($classNames as $className) {
            if (!class_exists($className)) {
                return [
                    // translators: %s is the class name that is missing.
                    'response'    => \sprintf(__('Required class %s does not exist.', 'bit-pi'), $className),
                    'payload'     => [],
                    'status_code' => 400,
                ];
            }
        }
    }

    private function buildTicketPayload($fieldMappings)
    {
        return [
            'title'       => $fieldMappings['ticket_subject'],
            'content'     => $fieldMappings['ticket_details'],
            'customer_id' => $fieldMappings['customer_id'],
            'mailbox_id'  => $fieldMappings['mailbox_id'] ?? '',
        ];
    }

    private function extractTags($tags)
    {
        return array_values(array_filter(array_map('trim', explode(',', (string) $tags))));
    }

    private function getOrCreateTagIds($tags)
    {
        $tagIds = [];

        foreach ($tags as $tagTitle) {
            $tag = TicketTag::firstOrCreate(
                ['slug' => sanitize_title($tagTitle)],
                ['title' => $tagTitle]
            );

            $tagIds[] = $tag->id;
        }

        return $tagIds;
    }

    private function buildAgentConversationPayload($ticketId, $replyContent, $userId, $conversationType)
    {
        return [
            'ticket_id'         => $ticketId,
            'content'           => $replyContent,
            'person_id'         => $userId,
            'person_type'       => 'agent',
            'conversation_type' => $conversationType,
            'source'            => 'web',
            'created_at'        => current_time('mysql'),
            'updated_at'        => current_time('mysql')
        ];
    }

    private function findCustomerByEmail($email)
    {
        return Customer::where('email', $email)->first();
    }
}
