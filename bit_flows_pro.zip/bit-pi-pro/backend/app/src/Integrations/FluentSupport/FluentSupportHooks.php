<?php

namespace BitApps\PiPro\src\Integrations\FluentSupport;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!defined('ABSPATH')) {
    exit;
}

class FluentSupportHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'ticketCreated' => [
                'hook'          => 'fluent_support/ticket_created',
                'callback'      => [FluentSupportTrigger::class, 'ticketCreated'],
                'accepted_args' => 2,
            ],
            'responseAddedByAgent' => [
                'hook'          => 'fluent_support/response_added_by_agent',
                'callback'      => [FluentSupportTrigger::class, 'responseAddedByAgent'],
                'accepted_args' => 3,
            ],
            'responseAddedByCustomer' => [
                'hook'          => 'fluent_support/response_added_by_customer',
                'callback'      => [FluentSupportTrigger::class, 'responseAddedByCustomer'],
                'accepted_args' => 3,
            ],
            'ticketClosedByAgent' => [
                'hook'          => 'fluent_support/ticket_closed_by_agent',
                'callback'      => [FluentSupportTrigger::class, 'ticketClosedByAgent'],
                'accepted_args' => 2,
            ],
            'ticketClosedByCustomer' => [
                'hook'          => 'fluent_support/ticket_closed_by_customer',
                'callback'      => [FluentSupportTrigger::class, 'ticketClosedByCustomer'],
                'accepted_args' => 2,
            ],
            'ticketClosedProduct' => [
                'hook'     => 'fluent_support/ticket_closed',
                'callback' => [FluentSupportTrigger::class, 'ticketClosedProduct'],
            ],
            'ticketCreatedProduct' => [
                'hook'     => 'fluent_support/ticket_created',
                'callback' => [FluentSupportTrigger::class, 'ticketCreatedProduct'],
            ],
            'ticketProductRepliedAgent' => [
                'hook'          => 'fluent_support/response_added_by_agent',
                'callback'      => [FluentSupportTrigger::class, 'ticketProductRepliedAgent'],
                'accepted_args' => 2,
            ],
            'ticketProductRepliedCustomer' => [
                'hook'          => 'fluent_support/response_added_by_customer',
                'callback'      => [FluentSupportTrigger::class, 'ticketProductRepliedCustomer'],
                'accepted_args' => 2,
            ],
        ];
    }
}
