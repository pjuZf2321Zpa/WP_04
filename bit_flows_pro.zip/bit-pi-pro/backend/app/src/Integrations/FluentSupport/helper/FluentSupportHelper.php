<?php

namespace BitApps\PiPro\src\Integrations\FluentSupport\helper;

use BitApps\PiPro\Deps\BitApps\WPValidator\Validator;

if (!defined('ABSPATH')) {
    exit;
}

final class FluentSupportHelper
{
    private const TICKET_LINK_PATH = 'admin.php?page=fluent-support#/tickets/%d/view';

    public static function isPluginInstalled()
    {
        return defined('FLUENT_SUPPORT_VERSION');
    }

    public static function validateFieldMap($fieldMappings, $validationRules, $payload = null)
    {
        $validator = new Validator();
        $validation = $validator->make($fieldMappings, $validationRules);

        if ($validation->fails()) {
            return [
                'response'    => $validation->errors(),
                'payload'     => $payload ?? $fieldMappings,
                'status_code' => 400
            ];
        }
    }

    public static function getTicketData($ticket, $customer)
    {
        $data = [
            'ticket'   => self::extractObjectAttributes($ticket),
            'customer' => self::extractObjectAttributes($customer)
        ];

        return self::appendTicketMeta($data, $ticket);
    }

    public static function getResponseData($response, $ticket, $customer)
    {
        $data = [
            'reply'    => self::extractObjectAttributes($response),
            'ticket'   => self::extractObjectAttributes($ticket),
            'customer' => self::extractObjectAttributes($customer)
        ];

        return self::appendTicketMeta($data, $ticket);
    }

    public static function getTicketWithUserData($ticket, $user)
    {
        $data = [
            'ticket' => self::extractObjectAttributes($ticket),
            'user'   => self::extractObjectAttributes($user)
        ];

        return self::appendTicketMeta($data, $ticket);
    }

    public static function getSimpleTicketData($ticket)
    {
        $data = [
            'ticket' => self::extractObjectAttributes($ticket)
        ];

        return self::appendTicketMeta($data, $ticket);
    }

    public static function getResponseWithTicketData($response, $ticket)
    {
        $data = [
            'response' => self::extractObjectAttributes($response),
            'ticket'   => self::extractObjectAttributes($ticket)
        ];

        return self::appendTicketMeta($data, $ticket);
    }

    public static function extractObjectAttributes($object)
    {
        if (!\is_object($object)) {
            return $object;
        }

        if (method_exists($object, 'getAttributes')) {
            return $object->getAttributes();
        }

        if (method_exists($object, 'toArray')) {
            return $object->toArray();
        }

        return get_object_vars($object);
    }

    private static function appendTicketMeta(array $data, $ticket)
    {
        if (\is_object($ticket) && method_exists($ticket, 'customData')) {
            $data['custom_data'] = $ticket->customData();
        }

        if (!empty($data['ticket']['id'])) {
            $data['ticket_link'] = self::buildTicketLink((int) $data['ticket']['id']);
        }

        return $data;
    }

    private static function buildTicketLink($ticketId)
    {
        return admin_url(\sprintf(self::TICKET_LINK_PATH, $ticketId));
    }
}
