<?php

namespace BitApps\PiPro\src\Integrations\Zendesk;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\Pi\src\Interfaces\ActionInterface;

class ZendeskAction implements ActionInterface
{
    private NodeInfoProvider $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executed = $this->executeZendeskAction();

        return Utility::formatResponseData(
            $executed['status_code'],
            $executed['payload'],
            $executed['response']
        );
    }

    private function executeZendeskAction()
    {
        $machineSlug = $this->nodeInfoProvider->getMachineSlug();
        if (empty($machineSlug)) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('Action method is required.', 'bit-pi'),
            ];
        }

        $serviceInstance = IntegrationHelper::getServiceInstanceByMachineSlug($machineSlug, $this->nodeInfoProvider);
        if (!$serviceInstance) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('Service instance not found for the given machine slug.', 'bit-pi'),
            ];
        }

        return $serviceInstance->{$machineSlug}();
    }
}
