<?php

namespace BitApps\PiPro\src\Integrations\Zendesk\Services;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\Pi\Deps\BitApps\WPKit\Helpers\JSON;

final class OrganizationService extends BaseService
{
    public function createOrganization(): array
    {
        $validationError = $this->validateFieldMap(['name' => ['required', 'string']]);
        if ($validationError) {
            return $validationError;
        }

        $payload = JSON::encode(['organization' => $this->buildOrganizationPayload($this->fieldsMapping)]);

        return $this->dispatch('/organizations.json', 'POST', $payload);
    }

    public function updateOrganization(): array
    {
        $validationError = $this->validateFieldMap(['organizationId' => ['required', 'integer']]);
        if ($validationError) {
            return $validationError;
        }

        $organizationId = $this->fieldsMapping['organizationId'] ?? '';
        $payload = JSON::encode(['organization' => $this->buildOrganizationPayload($this->fieldsMapping)]);

        return $this->dispatch(
            '/organizations/' . rawurlencode($organizationId) . '.json',
            'PUT',
            $payload
        );
    }

    public function deleteOrganization(): array
    {
        $validationError = $this->validateFieldMap(['organizationId' => ['required', 'integer']]);
        if ($validationError) {
            return $validationError;
        }

        $organizationId = $this->fieldsMapping['organizationId'] ?? '';

        return $this->dispatch(
            '/organizations/' . rawurlencode($organizationId) . '.json',
            'DELETE',
            ''
        );
    }

    public function getOrganization(): array
    {
        $validationError = $this->validateFieldMap(['organizationId' => ['required', 'integer']]);
        if ($validationError) {
            return $validationError;
        }

        $organizationId = $this->fieldsMapping['organizationId'] ?? '';

        return $this->dispatch('/organizations/' . rawurlencode($organizationId) . '.json', 'GET', '');
    }

    public function listOrganizations(): array
    {
        return $this->dispatch($this->paginate('/organizations.json'), 'GET', '');
    }

    private function buildOrganizationPayload(array $data): array
    {
        $payload = [
            'name'         => $data['name'] ?? null,
            'details'      => $data['details'] ?? null,
            'notes'        => $data['notes'] ?? null,
            'external_id'  => $data['externalId'] ?? null,
            'domain_names' => $this->stringToArrayConversion($data['domainNames'] ?? null),
            'tags'         => $this->stringToArrayConversion($data['tags'] ?? null),
        ];

        return $this->filterEmptyValues($payload);
    }
}
