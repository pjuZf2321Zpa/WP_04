<?php

namespace BitApps\PiPro\src\Integrations\Zendesk\Services;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\Pi\Deps\BitApps\WPKit\Helpers\JSON;

final class UserService extends BaseService
{
    public function createUser(): array
    {
        $validationError = $this->validateFieldMap(
            [
                'name'  => ['required', 'string'],
                'email' => ['required', 'email'],
            ]
        );

        if ($validationError) {
            return $validationError;
        }

        $payload = JSON::encode(['user' => $this->buildUserPayload($this->fieldsMapping)]);

        return $this->dispatch('/users.json', 'POST', $payload);
    }

    public function updateUser(): array
    {
        $validationError = $this->validateFieldMap(['userId' => ['required', 'integer']]);

        if ($validationError) {
            return $validationError;
        }

        $userId = $this->fieldsMapping['userId'] ?? '';
        $payload = JSON::encode(['user' => $this->buildUserPayload($this->fieldsMapping)]);

        return $this->dispatch('/users/' . rawurlencode($userId) . '.json', 'PUT', $payload);
    }

    public function createOrUpdateUser(): array
    {
        $validationError = $this->validateFieldMap(
            [
                'name'  => ['required', 'string'],
                'email' => ['required', 'email'],
            ]
        );

        if ($validationError) {
            return $validationError;
        }

        $payload = JSON::encode(['user' => $this->buildUserPayload($this->fieldsMapping)]);

        return $this->dispatch('/users/create_or_update.json', 'POST', $payload);
    }

    public function deleteUser(): array
    {
        $validationError = $this->validateFieldMap(['userId' => ['required', 'integer']]);
        if ($validationError) {
            return $validationError;
        }

        $userId = $this->fieldsMapping['userId'] ?? '';

        return $this->dispatch('/users/' . rawurlencode($userId) . '.json', 'DELETE', '');
    }

    public function suspendUser(): array
    {
        $validationError = $this->validateFieldMap(['userId' => ['required', 'integer']]);
        if ($validationError) {
            return $validationError;
        }

        $userId = $this->fieldsMapping['userId'] ?? '';
        $payload = JSON::encode(['user' => ['suspended' => true]]);

        return $this->dispatch('/users/' . rawurlencode($userId) . '.json', 'PUT', $payload);
    }

    public function getUser(): array
    {
        $validationError = $this->validateFieldMap(['userId' => ['required', 'integer']]);
        if ($validationError) {
            return $validationError;
        }

        $userId = $this->fieldsMapping['userId'] ?? '';

        return $this->dispatch('/users/' . rawurlencode($userId) . '.json', 'GET', '');
    }

    public function listUsers(): array
    {
        return $this->dispatch($this->paginate('/users.json'), 'GET', '');
    }

    public function searchUsers(): array
    {
        $validationError = $this->validateFieldMap(['query' => ['required', 'string']]);
        if ($validationError) {
            return $validationError;
        }

        $query = trim((string) ($this->fieldsMapping['query'] ?? ''));
        $path = '/users/search.json?' . http_build_query(['query' => $query]);

        return $this->dispatch($path, 'GET', '');
    }

    private function buildUserPayload(array $data): array
    {
        $payload = [
            'name'            => $data['name'] ?? null,
            'email'           => $data['email'] ?? null,
            'phone'           => $data['phone'] ?? null,
            'role'            => $data['role'] ?? null,
            'organization_id' => $data['organizationId'] ?? null,
            'external_id'     => $data['externalId'] ?? null,
            'tags'            => $this->stringToArrayConversion($data['tags'] ?? null),
        ];

        return $this->filterEmptyValues($payload);
    }
}
