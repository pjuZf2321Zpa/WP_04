<?php

namespace BitApps\PiPro\src\Integrations\Zendesk\Services;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\Pi\src\Authorization\AuthorizationFactory;
use BitApps\Pi\src\Authorization\AuthorizationType;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Client\HttpClient;

abstract class BaseService
{
    protected ?HttpClient $httpClient = null;

    protected string $baseUrl = '';

    protected array $fieldsMapping = [];

    protected ?array $bootError = null;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->fieldsMapping = (array) $nodeInfoProvider->getFieldMapData();

        $connectionId = $nodeInfoProvider->getFieldMapConfigs('connection-id.value');
        $authHandler = AuthorizationFactory::getAuthorizationHandler(
            AuthorizationType::BASIC_AUTH,
            $connectionId
        );

        $authDetails = $authHandler->getAuthDetails();

        $details = (array) ($authDetails ?? []);
        $extra = (array) ($details['extraData'] ?? []);

        $subdomain = $extra['subdomain'] ?? '';
        $username = $details['username'] ?? '';
        $password = $details['password'] ?? '';

        if (empty($subdomain) || empty($username) || empty($password)) {
            $this->bootError = [
                'status_code' => 401,
                'payload'     => $this->fieldsMapping,
                'response'    => ['error' => 'Missing Zendesk subdomain, username, or password'],
            ];

            return;
        }

        $this->baseUrl = 'https://' . $subdomain . '.zendesk.com/api/v2';
        $this->httpClient = new HttpClient(
            [
                'headers' => [
                    'Content-Type'  => 'application/json',
                    'Accept'        => 'application/json',
                    'Authorization' => 'Basic ' . base64_encode($username . '/token:' . $password),
                ],
            ]
        );
    }

    protected function paginate(string $base): string
    {
        $page = $this->fieldsMapping['page'] ?? '';
        $perPage = $this->fieldsMapping['perPage'] ?? '';

        $params = [
            'page'     => is_numeric($page) && (int) $page > 0 ? (int) $page : 1,
            'per_page' => is_numeric($perPage) && (int) $perPage > 0 ? (int) $perPage : 100,
        ];

        return $base . '?' . http_build_query($params);
    }

    protected function dispatch(string $path, string $method, string $payload): array
    {
        if ($this->bootError !== null) {
            return $this->bootError;
        }

        if ($this->httpClient === null || $this->baseUrl === '') {
            return [
                'status_code' => 401,
                'payload'     => $this->fieldsMapping,
                'response'    => ['error' => 'Zendesk client is not configured'],
            ];
        }

        $response = $this->httpClient->request($this->baseUrl . $path, $method, $payload);

        return [
            'response'    => $response,
            'payload'     => $payload,
            'status_code' => $this->httpClient->getResponseCode(),
        ];
    }

    protected function filterEmptyValues(array $payload): array
    {
        return array_filter(
            $payload,
            static function ($value) {
                return $value !== null && $value !== '';
            }
        );
    }

    protected function validateFieldMap(array $rules, ?array $fieldMappings = null): ?array
    {
        $fieldMappings = $fieldMappings ?? $this->fieldsMapping;

        return IntegrationHelper::validateFieldMap($fieldMappings, $rules);
    }

    protected function stringToArrayConversion($value): ?array
    {
        if ($value === null || $value === '') {
            return [];
        }

        if (\is_array($value)) {
            $items = $value;
        } else {
            $items = explode(',', (string) $value);
        }

        $items = array_values(
            array_filter(
                array_map('trim', $items),
                static function ($item) {
                    return $item !== '';
                }
            )
        );

        return empty($items) ? null : $items;
    }
}
