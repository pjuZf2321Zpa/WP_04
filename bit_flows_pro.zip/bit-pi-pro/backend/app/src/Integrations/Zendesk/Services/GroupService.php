<?php

namespace BitApps\PiPro\src\Integrations\Zendesk\Services;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\Pi\Deps\BitApps\WPKit\Helpers\JSON;

final class GroupService extends BaseService
{
    public function createGroup(): array
    {
        $validationError = $this->validateFieldMap(['name' => ['required', 'string']]);
        if ($validationError) {
            return $validationError;
        }

        $group = array_filter(
            [
                'name'        => $this->fieldsMapping['name'] ?? null,
                'description' => $this->fieldsMapping['description'] ?? null,
                'default'     => isset($this->fieldsMapping['isDefault'])
                    ? ($this->fieldsMapping['isDefault'] === 'true' || $this->fieldsMapping['isDefault'] === true)
                    : null,
            ],
            static function ($value) {
                return $value !== null && $value !== '';
            }
        );

        $payload = JSON::encode(['group' => $group]);

        return $this->dispatch('/groups.json', 'POST', $payload);
    }

    public function updateGroup(): array
    {
        $validationError = $this->validateFieldMap(['groupId' => ['required', 'integer']]);
        if ($validationError) {
            return $validationError;
        }

        $groupId = $this->fieldsMapping['groupId'] ?? '';
        $group = array_filter(
            [
                'name'        => $this->fieldsMapping['name'] ?? null,
                'description' => $this->fieldsMapping['description'] ?? null,
            ],
            static function ($value) {
                return $value !== null && $value !== '';
            }
        );

        $payload = JSON::encode(['group' => $group]);

        return $this->dispatch('/groups/' . rawurlencode($groupId) . '.json', 'PUT', $payload);
    }

    public function deleteGroup(): array
    {
        $validationError = $this->validateFieldMap(['groupId' => ['required', 'integer']]);
        if ($validationError) {
            return $validationError;
        }

        $groupId = $this->fieldsMapping['groupId'] ?? '';

        return $this->dispatch('/groups/' . rawurlencode($groupId) . '.json', 'DELETE', '');
    }

    public function getGroup(): array
    {
        $validationError = $this->validateFieldMap(['groupId' => ['required', 'integer']]);
        if ($validationError) {
            return $validationError;
        }

        $groupId = $this->fieldsMapping['groupId'] ?? '';

        return $this->dispatch('/groups/' . rawurlencode($groupId) . '.json', 'GET', '');
    }

    public function listGroups(): array
    {
        return $this->dispatch($this->paginate('/groups.json'), 'GET', '');
    }
}
