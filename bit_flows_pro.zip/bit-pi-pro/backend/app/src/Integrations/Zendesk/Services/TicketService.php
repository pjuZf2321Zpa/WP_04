<?php

namespace BitApps\PiPro\src\Integrations\Zendesk\Services;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\Pi\Deps\BitApps\WPKit\Helpers\JSON;

final class TicketService extends BaseService
{
    public function createTicket(): array
    {
        $validationError = $this->validateFieldMap(
            [
                'subject'     => ['required', 'string'],
                'description' => ['required', 'string'],
            ]
        );

        if ($validationError) {
            return $validationError;
        }

        $ticket = $this->buildTicketPayload($this->fieldsMapping);
        $payload = JSON::encode(['ticket' => $ticket]);

        return $this->dispatch('/tickets.json', 'POST', $payload);
    }

    public function updateTicket(): array
    {
        $validationError = $this->validateFieldMap(['ticketId' => ['required', 'integer']]);

        if ($validationError) {
            return $validationError;
        }

        $ticketId = $this->fieldsMapping['ticketId'] ?? '';
        $ticket = $this->buildTicketPayload($this->fieldsMapping, true);

        $commentBody = $this->fieldsMapping['commentBody'] ?? '';
        if ($commentBody !== '') {
            $ticket['comment'] = ['body' => $commentBody];
        }

        $payload = JSON::encode(['ticket' => $ticket]);

        return $this->dispatch('/tickets/' . rawurlencode($ticketId) . '.json', 'PUT', $payload);
    }

    public function deleteTicket(): array
    {
        $validationError = $this->validateFieldMap(['ticketId' => ['required', 'integer']]);
        if ($validationError) {
            return $validationError;
        }

        $ticketId = $this->fieldsMapping['ticketId'] ?? '';

        return $this->dispatch('/tickets/' . rawurlencode($ticketId) . '.json', 'DELETE', '');
    }

    public function addTicketComment(): array
    {
        $validationError = $this->validateFieldMap(
            [
                'ticketId'    => ['required', 'integer'],
                'commentBody' => ['required', 'string'],
            ]
        );

        if ($validationError) {
            return $validationError;
        }

        $ticketId = $this->fieldsMapping['ticketId'] ?? '';
        $comment = [
            'body'   => $this->fieldsMapping['commentBody'] ?? '',
            'public' => ($this->fieldsMapping['visibility'] ?? 'public') === 'public',
        ];

        if (!empty($this->fieldsMapping['authorId'])) {
            $comment['author_id'] = $this->fieldsMapping['authorId'];
        }

        $payload = JSON::encode(['ticket' => ['comment' => $comment]]);

        return $this->dispatch('/tickets/' . rawurlencode($ticketId) . '.json', 'PUT', $payload);
    }

    public function addTagsToTicket(): array
    {
        $validationError = $this->validateFieldMap(
            [
                'ticketId' => ['required', 'integer'],
                'tags'     => ['required', 'string'],
            ]
        );

        if ($validationError) {
            return $validationError;
        }

        $ticketId = $this->fieldsMapping['ticketId'] ?? '';
        $tags = $this->stringToArrayConversion($this->fieldsMapping['tags'] ?? null) ?? [];
        $payload = JSON::encode(['tags' => $tags]);

        return $this->dispatch('/tickets/' . rawurlencode($ticketId) . '/tags.json', 'POST', $payload);
    }

    public function removeTagsFromTicket(): array
    {
        $validationError = $this->validateFieldMap(
            [
                'ticketId' => ['required', 'integer'],
                'tags'     => ['required', 'string'],
            ]
        );
        if ($validationError) {
            return $validationError;
        }

        $ticketId = $this->fieldsMapping['ticketId'] ?? '';
        $tags = $this->stringToArrayConversion($this->fieldsMapping['tags'] ?? null) ?? [];
        $payload = JSON::encode(['tags' => $tags]);

        return $this->dispatch('/tickets/' . rawurlencode($ticketId) . '/tags.json', 'DELETE', $payload);
    }

    public function getTicket(): array
    {
        $validationError = $this->validateFieldMap(['ticketId' => ['required', 'integer']]);
        if ($validationError) {
            return $validationError;
        }

        $ticketId = $this->fieldsMapping['ticketId'] ?? '';

        return $this->dispatch('/tickets/' . rawurlencode($ticketId) . '.json', 'GET', '');
    }

    public function listTickets(): array
    {
        return $this->dispatch($this->paginate('/tickets.json'), 'GET', '');
    }

    public function searchTickets(): array
    {
        $validationError = $this->validateFieldMap(['query' => ['required', 'string']]);
        if ($validationError) {
            return $validationError;
        }

        $query = trim((string) ($this->fieldsMapping['query'] ?? ''));
        if (stripos($query, 'type:') === false) {
            $query = 'type:ticket ' . $query;
        }

        $path = '/search.json?' . http_build_query(['query' => $query]);

        return $this->dispatch($path, 'GET', '');
    }

    private function buildTicketPayload(array $data, bool $forUpdate = false): array
    {
        $payload = [
            'subject'        => $data['subject'] ?? null,
            'priority'       => $data['priority'] ?? null,
            'status'         => $data['status'] ?? null,
            'type'           => $data['type'] ?? null,
            'group_id'       => $data['groupId'] ?? null,
            'assignee_id'    => $data['assigneeId'] ?? null,
            'brand_id'       => $data['brandId'] ?? null,
            'ticket_form_id' => $data['ticketFormId'] ?? null,
            'external_id'    => $data['externalId'] ?? null,
            'tags'           => $this->stringToArrayConversion($data['tags'] ?? null),
        ];

        $ticket = $this->filterEmptyValues($payload);

        if (!$forUpdate) {
            $description = $data['description'] ?? '';
            if ($description !== '') {
                $ticket['comment'] = ['body' => $description];
            }

            if (!empty($data['requesterEmail'])) {
                $ticket['requester']['email'] = $data['requesterEmail'];
            }
            if (!empty($data['requesterName'])) {
                $ticket['requester']['name'] = $data['requesterName'];
            }
        }

        return $ticket;
    }
}
