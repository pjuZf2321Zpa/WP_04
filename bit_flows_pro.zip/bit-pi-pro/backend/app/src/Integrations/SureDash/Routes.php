<?php

if (!\defined('ABSPATH')) {
    exit;
}

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\PiPro\src\Integrations\SureDash\SureDashHelper;

Route::group(
    function () {
        Route::get('sure-dash/spaces', [SureDashHelper::class, 'getSpaces']);
        Route::get('sure-dash/members', [SureDashHelper::class, 'getMembers']);
        Route::get('sure-dash/posts', [SureDashHelper::class, 'getPosts']);
        Route::get('sure-dash/comments', [SureDashHelper::class, 'getComments']);
    }
)->middleware('nonce:admin');
