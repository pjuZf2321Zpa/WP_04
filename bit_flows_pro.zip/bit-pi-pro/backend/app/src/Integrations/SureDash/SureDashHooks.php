<?php

namespace BitApps\PiPro\src\Integrations\SureDash;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!defined('ABSPATH')) {
    exit;
}

class SureDashHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'spaceSaved' => [
                'hook'          => 'suredash_space_saved',
                'callback'      => [SureDashTrigger::class, 'spaceSaved'],
                'accepted_args' => 2,
            ],
            'spaceDeleted' => [
                'hook'     => 'suredash_space_deleted',
                'callback' => [SureDashTrigger::class, 'spaceDeleted'],
            ],
            'spaceDataUpdated' => [
                'hook'          => 'suredash_space_data_updated',
                'callback'      => [SureDashTrigger::class, 'spaceDataUpdated'],
                'accepted_args' => 3,
            ],
            'settingsUpdated' => [
                'hook'          => 'suredash_settings_updated',
                'callback'      => [SureDashTrigger::class, 'settingsUpdated'],
                'accepted_args' => 2,
            ],
            'userProfileUpdated' => [
                'hook'     => 'suredash_after_user_profile_update',
                'callback' => [SureDashTrigger::class, 'userProfileUpdated'],
            ],
            'userDataUpdated' => [
                'hook'          => 'suredash_update_user_data',
                'callback'      => [SureDashTrigger::class, 'userDataUpdated'],
                'accepted_args' => 3,
            ],
            'userRegistered' => [
                'hook'     => 'suredash_user_registered',
                'callback' => [SureDashTrigger::class, 'userRegistered'],
            ],
            'postSubmitted' => [
                'hook'          => 'suredash_after_post_submit',
                'callback'      => [SureDashTrigger::class, 'postSubmitted'],
                'accepted_args' => 2,
            ],
            'postEdited' => [
                'hook'          => 'suredash_after_post_edited',
                'callback'      => [SureDashTrigger::class, 'postEdited'],
                'accepted_args' => 2,
            ],
            'postDeleted' => [
                'hook'          => 'suredash_after_post_deleted',
                'callback'      => [SureDashTrigger::class, 'postDeleted'],
                'accepted_args' => 2,
            ],
            'commentSubmitted' => [
                'hook'          => 'suredash_after_comment_submit',
                'callback'      => [SureDashTrigger::class, 'commentSubmitted'],
                'accepted_args' => 2,
            ],
            'commentEdited' => [
                'hook'          => 'suredash_after_comment_edited',
                'callback'      => [SureDashTrigger::class, 'commentEdited'],
                'accepted_args' => 2,
            ],
            'commentDeleted' => [
                'hook'          => 'suredash_after_comment_deleted',
                'callback'      => [SureDashTrigger::class, 'commentDeleted'],
                'accepted_args' => 2,
            ],
            'fileUploaded' => [
                'hook'          => 'suredash_after_file_upload',
                'callback'      => [SureDashTrigger::class, 'fileUploaded'],
                'accepted_args' => 4,
            ],
            'itemBookmarked' => [
                'hook'          => 'suredash_item_bookmark',
                'callback'      => [SureDashTrigger::class, 'itemBookmarked'],
                'accepted_args' => 4,
            ],
            'entityReacted' => [
                'hook'          => 'suredash_entity_like_reaction',
                'callback'      => [SureDashTrigger::class, 'entityReacted'],
                'accepted_args' => 4,
            ],
            'contentCreatedForSpace' => [
                'hook'          => 'suredash_after_creating_post_content_for_space',
                'callback'      => [SureDashTrigger::class, 'contentCreatedForSpace'],
                'accepted_args' => 4,
            ],
            'communityContentDeleted' => [
                'hook'     => 'suredash_community_content_deleted',
                'callback' => [SureDashTrigger::class, 'communityContentDeleted'],
            ],
        ];
    }
}
