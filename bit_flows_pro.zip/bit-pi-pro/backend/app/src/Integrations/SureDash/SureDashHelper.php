<?php

namespace BitApps\PiPro\src\Integrations\SureDash;

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\PiPro\Deps\BitApps\WPValidator\Validator;

if (!defined('ABSPATH')) {
    exit;
}

final class SureDashHelper
{
    public static function getSpaces()
    {
        if (!defined('SUREDASHBOARD_POST_TYPE')) {
            return Response::error(__('SureDash plugin is not active.', 'bit-pi'));
        }

        $posts = get_posts(
            [
                'post_type'              => SUREDASHBOARD_POST_TYPE,
                'post_status'            => 'publish',
                'posts_per_page'         => -1,
                'orderby'                => 'title',
                'order'                  => 'ASC',
                'no_found_rows'          => true,
                'ignore_sticky_posts'    => true,
                'update_post_meta_cache' => false,
                'update_post_term_cache' => false,
            ]
        );

        $options = array_map(
            static function ($post) {
                return ['label' => $post->post_title, 'value' => $post->ID];
            },
            $posts
        );

        return Response::success($options);
    }

    public static function getMembers()
    {
        if (!defined('SUREDASHBOARD_POST_TYPE')) {
            return Response::error(__('SureDash plugin is not active.', 'bit-pi'));
        }

        $users = get_users(
            [
                'role'        => 'suredash_user',
                'orderby'     => 'display_name',
                'order'       => 'ASC',
                'number'      => -1,
                'fields'      => ['ID', 'display_name', 'user_login'],
                'count_total' => false,
            ]
        );

        $options = array_map(
            static function ($user) {
                return ['label' => $user->display_name ?: $user->user_login, 'value' => $user->ID];
            },
            $users
        );

        return Response::success($options);
    }

    public static function getPosts()
    {
        if (!defined('SUREDASHBOARD_FEED_POST_TYPE')) {
            return Response::error(__('SureDash plugin is not active.', 'bit-pi'));
        }

        $posts = get_posts(
            [
                'post_type'              => SUREDASHBOARD_FEED_POST_TYPE,
                'post_status'            => 'publish',
                'posts_per_page'         => -1,
                'orderby'                => 'date',
                'order'                  => 'DESC',
                'no_found_rows'          => true,
                'ignore_sticky_posts'    => true,
                'update_post_meta_cache' => false,
                'update_post_term_cache' => false,
            ]
        );

        $options = array_map(
            static function ($post) {
                $title = $post->post_title ?: '(Untitled #' . $post->ID . ')';

                return ['label' => $title, 'value' => $post->ID];
            },
            $posts
        );

        return Response::success($options);
    }

    public static function getComments()
    {
        if (!defined('SUREDASHBOARD_FEED_POST_TYPE')) {
            return Response::error(__('SureDash plugin is not active.', 'bit-pi'));
        }

        $comments = get_comments(
            [
                'post_type' => SUREDASHBOARD_FEED_POST_TYPE,
                'status'    => 'approve',
                'number'    => 200,
                'orderby'   => 'comment_date',
                'order'     => 'DESC',
            ]
        );

        $options = array_map(
            static function ($comment) {
                $excerpt = mb_strlen($comment->comment_content) > 60
                    ? mb_substr($comment->comment_content, 0, 60) . '...'
                    : $comment->comment_content;

                return [
                    'label' => $excerpt ?: '(Empty #' . $comment->comment_ID . ')',
                    'value' => $comment->comment_ID,
                ];
            },
            $comments
        );

        return Response::success($options);
    }

    public static function validateFieldMap($fieldMappings, $validationRules, $payload = null)
    {
        $validator = new Validator();
        $validation = $validator->make($fieldMappings, $validationRules);

        if ($validation->fails()) {
            return [
                'response'    => $validation->errors(),
                'payload'     => $payload ?? $fieldMappings,
                'status_code' => 400
            ];
        }
    }

    public static function validatePostExists($postId, $payload = null)
    {
        if (!defined('SUREDASHBOARD_FEED_POST_TYPE')) {
            return [
                'response'    => __('Post type not found.', 'bit-pi'),
                'payload'     => [],
                'status_code' => 400,
            ];
        }

        $post = get_post($postId);
        if (!$post || $post->post_type !== SUREDASHBOARD_FEED_POST_TYPE) {
            return [
                'response'    => __('Post not found.', 'bit-pi'),
                'payload'     => $payload ?? ['postId' => $postId],
                'status_code' => 404,
            ];
        }
    }
}
