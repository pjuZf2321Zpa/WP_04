<?php

namespace BitApps\PiPro\src\Integrations\SureDash\Services;

use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\PiPro\Deps\BitApps\WPKit\Hooks\Hooks;
use BitApps\PiPro\src\Integrations\SureDash\SureDashHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class InteractionService
{
    private const BOOKMARK_META_KEY = 'portal_bookmarked_items';
    private const POST_LIKES_META_KEY = 'portal_post_likes';
    private const COMMENT_LIKES_META_KEY = 'portal_comment_likes';

    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function bookmarkItem(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'itemId'   => ['required', 'integer'],
            'itemType' => ['required', 'string'],
            'userId'   => ['required', 'integer'],
        ];

        $validationError = SureDashHelper::validateFieldMap($fieldMappings, $rules);
        if ($validationError) {
            return $validationError;
        }

        $itemId = (int) $fieldMappings['itemId'];
        $itemType = $fieldMappings['itemType'];
        $userId = (int) $fieldMappings['userId'];

        $userError = $this->validateUserExists($userId, $fieldMappings);
        if ($userError) {
            return $userError;
        }

        $itemError = $this->validateBookmarkItem($itemId, $itemType, $fieldMappings);
        if ($itemError) {
            return $itemError;
        }

        $bookmarked = get_user_meta($userId, self::BOOKMARK_META_KEY, true);
        $bookmarked = \is_array($bookmarked) ? $bookmarked : [];

        if (isset($bookmarked[$itemId])) {
            $status = 'un-bookmarked';
            unset($bookmarked[$itemId]);
        } else {
            $status = 'bookmarked';
            $bookmarked[$itemId] = $itemType;
        }

        $this->updateUserMeta($userId, self::BOOKMARK_META_KEY, $bookmarked);

        Hooks::doAction('suredash_item_bookmark', $itemId, $itemType, $status, $userId);

        return [
            'response'    => ['status' => $status, 'item_id' => $itemId, 'item_type' => $itemType],
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function reactToEntity(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'entityId'   => ['required', 'integer'],
            'entityType' => ['required', 'string'],
            'userId'     => ['required', 'integer'],
        ];
        $validationError = SureDashHelper::validateFieldMap($fieldMappings, $rules);
        if ($validationError) {
            return $validationError;
        }

        $entityId = (int) $fieldMappings['entityId'];
        $entityType = $fieldMappings['entityType'];
        $userId = (int) $fieldMappings['userId'];

        $userError = $this->validateUserExists($userId, $fieldMappings);
        if ($userError) {
            return $userError;
        }

        $entityError = $this->validateReactionEntity($entityId, $entityType, $fieldMappings);
        if ($entityError) {
            return $entityError;
        }

        $likes = $this->getEntityLikes($entityId, $entityType);
        [$likes, $likeStatus] = $this->toggleEntityLike($likes, $userId);
        $this->updateEntityLikes($entityId, $entityType, $likes);

        Hooks::doAction('suredash_entity_like_reaction', $entityId, $entityType, $likeStatus, $userId);

        return [
            'response' => [
                'like_status' => $likeStatus,
                'entity_id'   => $entityId,
                'entity_type' => $entityType,
                'user_id'     => $userId,
            ],
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    private function validateUserExists(int $userId, array $payload): ?array
    {
        if (get_userdata($userId)) {
            return null;
        }

        return [
            'response'    => __('User not found.', 'bit-pi'),
            'payload'     => $payload,
            'status_code' => 404,
        ];
    }

    private function validateBookmarkItem(int $itemId, string $itemType, array $payload): ?array
    {
        if ($itemType === 'community-post') {
            return SureDashHelper::validatePostExists($itemId, $payload);
        }

        if ($itemType !== 'portal') {
            return [
                'response'    => __('Invalid item type provided.', 'bit-pi'),
                'payload'     => $payload,
                'status_code' => 400,
            ];
        }

        if (!defined('SUREDASHBOARD_POST_TYPE')) {
            return [
                'response'    => __('Space type not found.', 'bit-pi'),
                'payload'     => $payload,
                'status_code' => 400,
            ];
        }

        $space = get_post($itemId);
        if (!$space || $space->post_type !== SUREDASHBOARD_POST_TYPE) {
            return [
                'response'    => __('Space not found.', 'bit-pi'),
                'payload'     => $payload,
                'status_code' => 404,
            ];
        }

        return null;
    }

    private function validateReactionEntity(int $entityId, string $entityType, array $payload): ?array
    {
        if ($entityType === 'post') {
            return SureDashHelper::validatePostExists($entityId, $payload);
        }

        if ($entityType !== 'comment') {
            return [
                'response'    => __('Invalid entity type provided.', 'bit-pi'),
                'payload'     => $payload,
                'status_code' => 400,
            ];
        }

        if (!get_comment($entityId)) {
            return [
                'response'    => __('Comment not found.', 'bit-pi'),
                'payload'     => $payload,
                'status_code' => 404,
            ];
        }

        return null;
    }

    private function getEntityLikes(int $entityId, string $entityType): array
    {
        if ($entityType === 'post') {
            $likes = get_post_meta($entityId, self::POST_LIKES_META_KEY, true);

            return \is_array($likes) ? $likes : [];
        }

        $likes = get_comment_meta($entityId, self::COMMENT_LIKES_META_KEY, true);

        return \is_array($likes) ? $likes : [];
    }

    private function toggleEntityLike(array $likes, int $userId): array
    {
        $userKey = array_search($userId, $likes, true);

        if ($userKey !== false) {
            unset($likes[$userKey]);

            return [array_values($likes), 'unliked'];
        }

        $likes[] = $userId;

        return [$likes, 'liked'];
    }

    private function updateEntityLikes(int $entityId, string $entityType, array $likes): void
    {
        if ($entityType === 'post') {
            update_post_meta($entityId, self::POST_LIKES_META_KEY, $likes);

            return;
        }

        update_comment_meta($entityId, self::COMMENT_LIKES_META_KEY, $likes);
    }

    private function updateUserMeta(int $userId, string $metaKey, array $metaValue): void
    {
        if (\function_exists('sd_update_user_meta')) {
            sd_update_user_meta($userId, $metaKey, $metaValue);

            return;
        }

        update_user_meta($userId, $metaKey, $metaValue);
    }
}
