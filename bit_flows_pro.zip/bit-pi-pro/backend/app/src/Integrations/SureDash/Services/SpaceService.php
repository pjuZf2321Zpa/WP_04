<?php

namespace BitApps\PiPro\src\Integrations\SureDash\Services;

use BitApps\Pi\src\Flow\NodeInfoProvider;

if (!defined('ABSPATH')) {
    exit;
}

final class SpaceService
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function getAllSpaces(): array
    {
        if (!defined('SUREDASHBOARD_POST_TYPE')) {
            return [
                'response'    => __('SureDash plugin is not active.', 'bit-pi'),
                'payload'     => [],
                'status_code' => 400,
            ];
        }

        $posts = get_posts($this->getSpacesQueryArgs());

        return [
            'response'    => $posts,
            'payload'     => [],
            'status_code' => 200,
        ];
    }

    private function getSpacesQueryArgs(): array
    {
        return [
            'post_type'              => SUREDASHBOARD_POST_TYPE,
            'post_status'            => 'publish',
            'posts_per_page'         => -1,
            'orderby'                => 'title',
            'order'                  => 'ASC',
            'no_found_rows'          => true,
            'ignore_sticky_posts'    => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        ];
    }
}
