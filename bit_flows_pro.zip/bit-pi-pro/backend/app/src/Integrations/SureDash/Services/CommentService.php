<?php

namespace BitApps\PiPro\src\Integrations\SureDash\Services;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\PiPro\src\Integrations\SureDash\SureDashHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class CommentService
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function createComment(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'postId'         => ['required', 'integer'],
            'commentContent' => ['required', 'string'],
        ];

        $validationError = SureDashHelper::validateFieldMap($fieldMappings, $rules);
        if ($validationError) {
            return $validationError;
        }

        $postId = (int) $fieldMappings['postId'];
        $commentContent = $fieldMappings['commentContent'];

        $validationError = SureDashHelper::validatePostExists($postId, $fieldMappings);
        if ($validationError) {
            return $validationError;
        }

        $commentId = wp_insert_comment(
            [
                'comment_post_ID'  => $postId,
                'comment_content'  => $commentContent,
                'user_id'          => get_current_user_id(),
                'comment_approved' => 1,
            ]
        );

        if (!$commentId) {
            return [
                'response'    => __('Failed to create the comment.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 500,
            ];
        }

        $comment = get_comment($commentId);

        return [
            'response'    => $comment ? Utility::jsonEncodeDecode($comment) : ['comment_ID' => $commentId],
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function deleteComment(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = ['commentId' => ['required', 'integer']];
        $validationError = SureDashHelper::validateFieldMap($fieldMappings, $rules);
        if ($validationError) {
            return $validationError;
        }

        $commentId = (int) $fieldMappings['commentId'];
        $comment = get_comment($commentId);

        if (!$comment) {
            return [
                'response'    => __('Comment not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404,
            ];
        }

        $deleted = wp_delete_comment($commentId, true);

        if (!$deleted) {
            return [
                'response'    => __('Failed to delete the comment.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 500,
            ];
        }

        return [
            'response'    => __('Comment deleted successfully.', 'bit-pi'),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }
}
