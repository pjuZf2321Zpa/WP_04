<?php

namespace BitApps\PiPro\src\Integrations\SureDash\Services;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\PiPro\src\Integrations\SureDash\SureDashHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class UserService
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function getAllMembers(): array
    {
        $members = Utility::getUsers(
            [
                'role'    => 'suredash_user',
                'orderby' => 'display_name',
                'order'   => 'ASC',
                'number'  => -1,
            ]
        );

        return [
            'response'    => $members,
            'payload'     => [],
            'status_code' => 200,
        ];
    }

    public function updateUserProfile(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = ['ID' => ['required', 'integer']];
        $validationError = SureDashHelper::validateFieldMap($fieldMappings, $rules);

        if ($validationError) {
            return $validationError;
        }

        $userId = (int) $fieldMappings['ID'];

        $userError = $this->validateUserExists($userId, $fieldMappings);
        if ($userError) {
            return $userError;
        }

        if (\count($fieldMappings) === 1) {
            return [
                'response'    => __('No profile fields provided to update.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        $result = wp_update_user($fieldMappings);

        if (is_wp_error($result)) {
            return [
                'response'    => $result->get_error_message(),
                'payload'     => $fieldMappings,
                'status_code' => 500,
            ];
        }

        return [
            'response'    => Utility::getUserInfo($userId),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    private function validateUserExists(int $userId, array $payload): ?array
    {
        if (get_userdata($userId)) {
            return null;
        }

        return [
            'response'    => __('User not found.', 'bit-pi'),
            'payload'     => $payload,
            'status_code' => 404,
        ];
    }
}
