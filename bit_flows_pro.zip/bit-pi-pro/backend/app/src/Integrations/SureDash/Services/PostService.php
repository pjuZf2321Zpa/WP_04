<?php

namespace BitApps\PiPro\src\Integrations\SureDash\Services;

use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\PiPro\src\Integrations\SureDash\SureDashHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class PostService
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function getAllPosts(): array
    {
        if (!defined('SUREDASHBOARD_FEED_POST_TYPE')) {
            return [
                'response'    => __('SureDash plugin is not active.', 'bit-pi'),
                'payload'     => [],
                'status_code' => 400,
            ];
        }

        $posts = get_posts($this->getPostsQueryArgs());

        return [
            'response'    => $posts,
            'payload'     => [],
            'status_code' => 200,
        ];
    }

    public function createPost(): array
    {
        if (!defined('SUREDASHBOARD_FEED_POST_TYPE') || !defined('SUREDASHBOARD_FEED_TAXONOMY')) {
            return [
                'response'    => __('SureDash plugin is not active.', 'bit-pi'),
                'payload'     => [],
                'status_code' => 400,
            ];
        }

        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'postTitle' => ['required', 'string'],
            'spaceId'   => ['required', 'integer'],
        ];

        $validationError = SureDashHelper::validateFieldMap($fieldMappings, $rules);
        if ($validationError) {
            return $validationError;
        }

        $spaceId = (int) $fieldMappings['spaceId'];
        $newPostId = wp_insert_post(
            [
                'post_title'   => $fieldMappings['postTitle'],
                'post_content' => $fieldMappings['postContent'] ?? '',
                'post_type'    => SUREDASHBOARD_FEED_POST_TYPE,
                'post_status'  => $fieldMappings['postStatus'] ?? 'publish',
                'post_author'  => get_current_user_id(),
            ],
            true
        );

        if (is_wp_error($newPostId)) {
            return [
                'response'    => $newPostId->get_error_message(),
                'payload'     => $fieldMappings,
                'status_code' => 500,
            ];
        }

        // Associate the post with the space's community forum
        $feedGroupId = $this->getFeedGroupId($spaceId);

        if ($feedGroupId) {
            wp_set_post_terms($newPostId, [(int) $feedGroupId], SUREDASHBOARD_FEED_TAXONOMY);
        }

        return [
            'response'    => (array) get_post($newPostId),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function deletePost(): array
    {
        if (!defined('SUREDASHBOARD_FEED_POST_TYPE')) {
            return [
                'response'    => __('SureDash plugin is not active.', 'bit-pi'),
                'payload'     => [],
                'status_code' => 400,
            ];
        }

        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = ['postId' => ['required', 'integer']];
        $validationError = SureDashHelper::validateFieldMap($fieldMappings, $rules);

        if ($validationError) {
            return $validationError;
        }

        $postId = (int) $fieldMappings['postId'];
        $validationError = SureDashHelper::validatePostExists($postId, $fieldMappings);
        if ($validationError) {
            return $validationError;
        }

        $deleted = wp_delete_post($postId, true);

        if (!$deleted) {
            return [
                'response'    => __('Failed to delete the post.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 500,
            ];
        }

        return [
            'response'    => __('Post deleted successfully.', 'bit-pi'),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    private function getPostsQueryArgs(): array
    {
        return [
            'post_type'              => SUREDASHBOARD_FEED_POST_TYPE,
            'post_status'            => 'publish',
            'posts_per_page'         => -1,
            'orderby'                => 'date',
            'order'                  => 'DESC',
            'no_found_rows'          => true,
            'ignore_sticky_posts'    => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        ];
    }

    private function getFeedGroupId(int $spaceId)
    {
        if (\function_exists('sd_get_post_meta')) {
            return sd_get_post_meta($spaceId, 'feed_group_id', true);
        }

        return get_post_meta($spaceId, 'feed_group_id', true);
    }
}
