<?php

namespace BitApps\PiPro\src\Integrations\SureDash;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;

if (!defined('ABSPATH')) {
    exit;
}

class SureDashAction implements ActionInterface
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedAction = $this->executeSureDashAction();

        return Utility::formatResponseData(
            $executedAction['status_code'] ?? 200,
            $executedAction['payload'] ?? [],
            $executedAction['response'] ?? []
        );
    }

    private function executeSureDashAction(): array
    {
        if (!defined('SUREDASHBOARD_POST_TYPE')) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('SureDash plugin is not active.', 'bit-pi'),
            ];
        }

        $machineSlug = $this->nodeInfoProvider->getMachineSlug();
        if (empty($machineSlug)) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('Action method is required.', 'bit-pi'),
            ];
        }

        $serviceInstance = $this->getServiceInstanceByMachineSlug($machineSlug);
        if (!$serviceInstance) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => \sprintf(
                    // translators: %s: action method name
                    __('SureDash action "%s" is not registered.', 'bit-pi'),
                    $machineSlug
                ),
            ];
        }

        return $serviceInstance->{$machineSlug}();
    }

    private function getServiceInstanceByMachineSlug(string $machineSlug): ?object
    {
        $serviceFiles = scandir(__DIR__ . '/Services');

        if (!$serviceFiles) {
            return null;
        }

        foreach ($serviceFiles as $serviceFile) {
            // 1) Get service class files from Services directory
            if (!str_ends_with($serviceFile, 'Service.php')) {
                continue;
            }

            // 2) Basename + namespace => full class name
            $serviceClass = '\BitApps\PiPro\src\Integrations\SureDash\Services\\' . basename($serviceFile, '.php');

            // 3) Check if class exists before instantiating (to avoid autoloading issues)
            if (!class_exists($serviceClass)) {
                continue;
            }

            // 4) Instantiate the service class and check if the method corresponding to machine slug exists
            $serviceInstance = new $serviceClass($this->nodeInfoProvider);

            // 5) Check if the method corresponding to machine slug exists and is callable
            if (\is_callable([$serviceInstance, $machineSlug])) {
                return $serviceInstance;
            }
        }

        return null;
    }
}
