<?php

namespace BitApps\PiPro\src\Integrations\SureDash;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;

final class SureDashTrigger
{
    public static function spaceSaved($postId, $postData): void
    {
        $data = [
            'post_id'   => $postId,
            'post_data' => Utility::jsonEncodeDecode($postData),
        ];

        self::execute('spaceSaved', $data);
    }

    public static function spaceDeleted($postId): void
    {
        $post = get_post($postId);
        $data = [
            'post_id'   => $postId,
            'post_data' => $post ? Utility::jsonEncodeDecode($post) : [],
        ];
        self::execute('spaceDeleted', $data);
    }

    public static function spaceDataUpdated($postId, $oldSpaceData, $newSpaceData): void
    {
        $data = [
            'post_id'        => $postId,
            'old_space_data' => Utility::jsonEncodeDecode($oldSpaceData),
            'new_space_data' => Utility::jsonEncodeDecode($newSpaceData),
        ];

        self::execute('spaceDataUpdated', $data);
    }

    public static function settingsUpdated($oldSettings, $settings): void
    {
        $data = [
            'old_settings' => Utility::jsonEncodeDecode($oldSettings),
            'settings'     => Utility::jsonEncodeDecode($settings),
        ];

        self::execute('settingsUpdated', $data);
    }

    public static function userProfileUpdated($userId): void
    {
        $data = array_merge(['user_id' => $userId], Utility::getUserInfo((int) $userId));

        self::execute('userProfileUpdated', $data);
    }

    public static function userDataUpdated($userId, $key, $value): void
    {
        $data = [
            'user_id' => $userId,
            'key'     => $key,
            'value'   => $value,
        ];

        self::execute('userDataUpdated', $data);
    }

    public static function userRegistered($result): void
    {
        if (is_numeric($result)) {
            $userId = (int) $result;
            $data = array_merge(['user_id' => $userId], Utility::getUserInfo($userId));
        } else {
            $data = Utility::jsonEncodeDecode($result);
        }

        self::execute('userRegistered', $data);
    }

    public static function postSubmitted($postId, $filteredData): void
    {
        $post = get_post($postId);
        $data = [
            'post_id'       => $postId,
            'filtered_data' => Utility::jsonEncodeDecode($filteredData),
            'post'          => $post ? Utility::jsonEncodeDecode($post) : [],
        ];

        self::execute('postSubmitted', $data);
    }

    public static function postEdited($postId, $currentUserId): void
    {
        $post = get_post($postId);
        $data = [
            'post_id'         => $postId,
            'current_user_id' => $currentUserId,
            'post'            => $post ? Utility::jsonEncodeDecode($post) : [],
        ];

        self::execute('postEdited', $data);
    }

    public static function postDeleted($postId, $postAuthor): void
    {
        $data = [
            'post_id'     => $postId,
            'post_author' => $postAuthor,
        ];

        self::execute('postDeleted', $data);
    }

    public static function commentSubmitted($commentId, $currentUserId): void
    {
        $comment = get_comment($commentId);
        $data = [
            'comment_id'      => $commentId,
            'current_user_id' => $currentUserId,
            'comment'         => $comment ? Utility::jsonEncodeDecode($comment) : [],
        ];

        self::execute('commentSubmitted', $data);
    }

    public static function commentEdited($commentId, $currentUserId): void
    {
        $comment = get_comment($commentId);
        $data = [
            'comment_id'      => $commentId,
            'current_user_id' => $currentUserId,
            'comment'         => $comment ? Utility::jsonEncodeDecode($comment) : [],
        ];

        self::execute('commentEdited', $data);
    }

    public static function commentDeleted($commentId, $commentAuthor): void
    {
        $data = [
            'comment_id'     => $commentId,
            'comment_author' => $commentAuthor,
        ];

        self::execute('commentDeleted', $data);
    }

    public static function fileUploaded($uploadedUrl, $filePath, $fileType, $userId): void
    {
        $data = [
            'uploaded_url' => $uploadedUrl,
            'file_path'    => $filePath,
            'file_type'    => $fileType,
            'user_id'      => $userId,
        ];

        self::execute('fileUploaded', $data);
    }

    public static function itemBookmarked($itemId, $itemType, $status, $userId): void
    {
        $data = [
            'item_id'   => $itemId,
            'item_type' => $itemType,
            'status'    => $status,
            'user_id'   => $userId,
        ];

        self::execute('itemBookmarked', $data);
    }

    public static function entityReacted($entityId, $entityType, $likeStatus, $currentUserId): void
    {
        $data = [
            'entity_id'       => $entityId,
            'entity_type'     => $entityType,
            'like_status'     => $likeStatus,
            'current_user_id' => $currentUserId,
        ];

        self::execute('entityReacted', $data);
    }

    public static function contentCreatedForSpace($postId, $spaceId, $postType, $spaceType): void
    {
        $data = [
            'post_id'    => $postId,
            'space_id'   => $spaceId,
            'post_type'  => $postType,
            'space_type' => $spaceType,
        ];

        self::execute('contentCreatedForSpace', $data);
    }

    public static function communityContentDeleted($postId): void
    {
        $data = ['post_id' => $postId];

        self::execute('communityContentDeleted', $data);
    }

    private static function execute(string $machineSlug, array $data): void
    {
        $flows = FlowService::exists('sureDash', $machineSlug);

        if (!$flows) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $data);
    }
}
