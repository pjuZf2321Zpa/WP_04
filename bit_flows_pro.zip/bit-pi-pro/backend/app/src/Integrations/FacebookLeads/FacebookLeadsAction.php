<?php

namespace BitApps\PiPro\src\Integrations\FacebookLeads;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Authorization\AuthorizationFactory;
use BitApps\Pi\src\Authorization\AuthorizationType;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Client\HttpClient;

if (!defined('ABSPATH')) {
    exit;
}

class FacebookLeadsAction implements ActionInterface
{
    private NodeInfoProvider $nodeInfoProvider;

    private FacebookLeadsService $facebookLeadsService;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeFacebookLeadsAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'],
            $executedNodeAction['payload'],
            $executedNodeAction['response']
        );
    }

    private function executeMachine($machineSlug, $configs)
    {
        switch ($machineSlug) {
            case 'createTestLead':
                return $this->facebookLeadsService->createTestLead($configs['leadgen-form-id']['value'] ?? null);

            case 'deleteTestLead':
                return $this->facebookLeadsService->deleteTestLead($configs['lead-id']['value'] ?? null);

            case 'listLeads':
                return $this->facebookLeadsService->listLeads($configs['leadgen-form-id']['value'] ?? null);

            case 'getPageDetails':
                return $this->facebookLeadsService->getPageDetails($configs['page-id']['value'] ?? null);

            case 'getLeadGenFormDetails':
                return $this->facebookLeadsService->getLeadGenFormDetails($configs['leadgen-form-id']['value'] ?? null);
        }
    }

    private function executeFacebookLeadsAction()
    {
        $machineSlug = $this->nodeInfoProvider->getMachineSlug();
        $configs = $this->nodeInfoProvider->getFieldMapConfigs();

        $accessToken = AuthorizationFactory::getAuthorizationHandler(
            AuthorizationType::OAUTH2,
            $configs['connection-id'] ?? null
        )->getAccessToken();

        if (\is_array($accessToken) && isset($accessToken['error'])) {
            return [
                'status_code' => 401,
                'payload'     => [],
                'response'    => $accessToken,
            ];
        }

        $httpClient = new HttpClient(
            [
                'headers' => [
                    'Content-Type'  => 'application/json',
                    'Authorization' => $accessToken,
                ],
            ]
        );

        $this->facebookLeadsService = new FacebookLeadsService($httpClient);

        return $this->executeMachine($machineSlug, $configs);
    }
}
