<?php

namespace BitApps\PiPro\src\Integrations\FacebookLeads;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\Pi\Config;
use BitApps\Pi\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\Pi\Deps\BitApps\WPKit\Http\Request\Request;
use BitApps\Pi\Deps\BitApps\WPKit\Http\Response;
use BitApps\Pi\Helpers\Hash;
use BitApps\Pi\Model\Connection;
use BitApps\Pi\Model\Flow;
use BitApps\Pi\Model\FlowNode;
use BitApps\Pi\src\Authorization\AuthorizationFactory;
use BitApps\Pi\src\Authorization\AuthorizationType;
use BitApps\Pi\src\Flow\FlowExecutor;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Client\HttpClient;
use Throwable;

final class FacebookLeadsTrigger
{
    public const VERIFY_TOKEN = Config::SLUG . '_fb_leads_verify';

    public const API_VERSION = 'v21.0';

    private const GRAPH_API_URL = 'https://graph.facebook.com/' . self::API_VERSION;

    public function handle(Request $request)
    {
        $hubMode = $request->get('hub_mode') ?? $request->get('hub.mode') ?? '';


        if ($hubMode === 'subscribe') {
            $challenge = $request->get('hub_challenge') ?? $request->get('hub.challenge') ?? '';
            $verifyToken = $request->get('hub_verify_token') ?? $request->get('hub.verify_token') ?? '';


            if ($verifyToken === self::VERIFY_TOKEN && $challenge !== '') {
                status_header(200);
                header('Content-Type: text/plain; charset=utf-8');
                echo sanitize_text_field($challenge); // phpcs:ignore Generic.PHP.ForbiddenFunctions.FoundWithAlternative

                exit;
            }

            return Response::error('Invalid verify token');
        }

        return $this->handleLeadgenEvent($request);
    }

    /**
     * Subscribe webhook: setup app-level subscription + page subscription.
     */
    public function subscribeWebhook(Request $request)
    {
        $connectionId = (int) $request->get('connection_id');
        $pageId = $request->get('page_id');
        $pageAccessToken = $request->get('page_access_token');
        $webhookUrl = $request->get('webhook_url');

        if (empty($connectionId) || empty($pageId) || empty($pageAccessToken) || empty($webhookUrl)) {
            return Response::error('Missing required parameters');
        }

        $connection = Connection::where('id', $connectionId)
            ->where('status', Connection::STATUS['verified'])
            ->first(['id', 'auth_details']);

        if (!$connection) {
            return Response::error('Connection not found');
        }

        $authDetails = (array) $connection->auth_details;
        $appId = $authDetails['client_id'] ?? '';
        $encryptedAppSecret = $authDetails['client_secret'] ?? '';

        if (empty($appId) || empty($encryptedAppSecret)) {
            return Response::error('App credentials not found');
        }

        $appSecret = Hash::decrypt($encryptedAppSecret);

        if (empty($appSecret)) {
            return Response::error('Failed to decrypt app secret');
        }

        $callbackUrl = $webhookUrl;

        $error = $this->postSubscription(
            self::GRAPH_API_URL . '/' . $appId . '/subscriptions',
            [
                'object'       => 'page',
                'callback_url' => $callbackUrl,
                'fields'       => 'leadgen',
                'verify_token' => self::VERIFY_TOKEN,
                'access_token' => $appId . '|' . $appSecret,
            ]
        );

        if ($error) {
            return $error;
        }

        $error = $this->postSubscription(
            self::GRAPH_API_URL . '/' . $pageId . '/subscribed_apps',
            [
                'subscribed_fields' => 'leadgen',
                'access_token'      => $pageAccessToken,
            ]
        );

        if ($error) {
            return $error;
        }

        return Response::success(['success' => true]);
    }

    private function handleLeadgenEvent(Request $request)
    {
        $payload = $request->all();


        if (empty($payload['object']) || $payload['object'] !== 'page') {
            return Response::error('Invalid payload');
        }

        $entry = $this->parseEntry($payload);

        if (!$entry) {
            return Response::error('No leadgen data found');
        }

        $leadgenId = $entry['leadgen_id'] ?? null;

        if (!$leadgenId) {
            return Response::error('Missing leadgen_id');
        }

        $nodes = FlowNode::where('app_slug', 'facebookLeads')
            ->where('machine_slug', 'newLeadEvent')
            ->get(['flow_id', 'data']);

        if (empty($nodes)) {
            return Response::error('No matching flow found');
        }

        // TODO::fetch flowId along with nodes

        foreach ($nodes as $node) {
            $raw = $node->data;
            $nodeData = \is_string($raw) ? JSON::maybeDecode($raw, true) : json_decode(wp_json_encode($raw), true);
            $db = $nodeData['db'] ?? $nodeData;
            $dbPageId = $db['pageId'] ?? '';
            $dbFormId = $db['formId'] ?? '';
            $incomingPageId = $entry['page_id'] ?? '';
            $incomingFormId = $entry['form_id'] ?? '';

            if ($dbPageId != $incomingPageId || $dbFormId != $incomingFormId) {
                continue;
            }

            $flow = Flow::select(['id', 'title', 'settings', 'is_active', 'map', 'trigger_type', 'listener_type', 'is_hook_capture'])
                ->where('id', $node->flow_id)
                ->first();

            if (!$flow) {
                continue;
            }

            if ($flow->listener_type === Flow::LISTENER_TYPE['NONE'] && $flow->is_active === Flow::STATUS['IN_ACTIVE']) {
                continue;
            }

            $leadData = $this->fetchLeadDataFromService($node, $leadgenId);
            FlowExecutor::execute($flow, array_merge($entry, $leadData));
        }

        return Response::success('Accepted');
    }

    private function parseEntry(array $payload): ?array
    {
        if (isset($payload['entry'])) {
            $entries = \is_array($payload['entry']) ? $payload['entry'] : JSON::maybeDecode($payload['entry'], true);

            if (!empty($entries[0]['changes'][0]['value'])) {
                return $entries[0]['changes'][0]['value'];
            }
        }

        return null;
    }

    private function fetchLeadDataFromService(object $node, string $leadgenId): array
    {
        $raw = $node->data;
        $nodeData = \is_string($raw) ? JSON::maybeDecode($raw, true) : JSON::decode(JSON::encode($raw), true);
        $db = $nodeData['db'] ?? $nodeData;
        $connectionId = $db['connectionId'] ?? null;

        if (!$connectionId) {
            return [];
        }

        try {
            $accessToken = AuthorizationFactory::getAuthorizationHandler(
                AuthorizationType::OAUTH2,
                $connectionId
            )->getAccessToken();
        } catch (Throwable $e) {
            return [];
        }

        $httpClient = new HttpClient(
            [
                'headers' => [
                    'Content-Type'  => 'application/json',
                    'Authorization' => $accessToken,
                ],
            ]
        );

        $service = new FacebookLeadsService($httpClient);

        return $service->fetchLeadData($leadgenId);
    }

    private function postSubscription(string $url, array $body)
    {
        $response = wp_remote_post(
            $url,
            [
                'body'      => $body,
                'timeout'   => 30,
                'sslverify' => !Config::getEnv('DEV'),
            ]
        );

        if (is_wp_error($response)) {
            return Response::error('Subscription failed: ' . $response->get_error_message());
        }

        $data = JSON::maybeDecode(wp_remote_retrieve_body($response), true);


        if (!empty($data['success'])) {
            return;
        }

        $errorMsg = $data['error']['message'] ?? 'Unknown error';

        if (
            str_contains(strtolower($errorMsg), 'already subscribed')
            || str_contains(strtolower($errorMsg), 'already exists')
        ) {
            return;
        }

        return Response::error('Subscription failed: ' . $errorMsg);
    }
}
