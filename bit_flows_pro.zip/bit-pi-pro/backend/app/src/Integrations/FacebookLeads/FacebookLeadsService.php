<?php

namespace BitApps\PiPro\src\Integrations\FacebookLeads;

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Client\HttpClient;

if (!defined('ABSPATH')) {
    exit;
}

class FacebookLeadsService
{
    private const API_VERSION = 'v21.0';

    private HttpClient $http;

    private string $baseUrl;

    /**
     * FacebookLeadsService constructor.
     */
    public function __construct(HttpClient $httpClient)
    {
        $this->http = $httpClient;
        $this->baseUrl = 'https://graph.facebook.com/' . self::API_VERSION;
    }

    /**
     * Create a Test Lead.
     *
     * @param mixed $leadGenFormId
     *
     * @return array
     */
    public function createTestLead($leadGenFormId)
    {
        $endPoint = $this->baseUrl . '/' . $leadGenFormId . '/test_leads';
        $response = $this->http->request($endPoint, 'POST', []);

        return [
            'response'    => $response,
            'payload'     => ['leadGenFormId' => $leadGenFormId],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Delete a Test Lead.
     *
     * @param mixed $leadId
     *
     * @return array
     */
    public function deleteTestLead($leadId)
    {
        $endPoint = $this->baseUrl . '/' . $leadId;
        $response = $this->http->request($endPoint, 'DELETE', []);

        return [
            'response'    => $response,
            'payload'     => ['leadId' => $leadId],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * List Leads.
     *
     * @param mixed $leadId
     *
     * @return array
     */
    public function listLeads($leadId)
    {
        $endPoint = $this->baseUrl . '/' . $leadId . '/leads';
        $response = $this->http->request($endPoint, 'GET', []);

        return [
            'response'    => $response,
            'payload'     => ['leadId' => $leadId],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Get Page Details.
     *
     * @param mixed $pageId
     *
     * @return array
     */
    public function getPageDetails($pageId)
    {
        $endPoint = $this->baseUrl . '/' . $pageId;
        $response = $this->http->request($endPoint, 'GET', []);

        return [
            'response'    => $response,
            'payload'     => ['pageId' => $pageId],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Get Lead Gen Form Details.
     *
     * @param mixed $leadGenFormId
     *
     * @return array
     */
    public function getLeadGenFormDetails($leadGenFormId)
    {
        $endPoint = $this->baseUrl . '/' . $leadGenFormId;
        $response = $this->http->request($endPoint, 'GET', []);

        return [
            'response'    => $response,
            'payload'     => ['leadGenFormId' => $leadGenFormId],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Fetch lead data by leadgen ID.
     *
     * @param string $leadgenId
     *
     * @return array
     */
    public function fetchLeadData($leadgenId)
    {
        $endPoint = $this->baseUrl . '/' . $leadgenId;
        $response = (array) $this->http->request($endPoint, 'GET', []);

        if (empty($response) || isset($response['error'])) {
            return [];
        }

        $result = [];
        $fieldData = $response['field_data'] ?? [];

        foreach ($fieldData as $field) {
            $field = (array) $field;
            $fieldName = sanitize_key(str_replace([' ', '-'], '_', trim($field['name'])));
            $result['field_' . $fieldName] = $field['values'][0] ?? '';
        }

        $result['lead_id'] = $response['id'] ?? $leadgenId;
        $result['created_time'] = $response['created_time'] ?? '';

        return $result;
    }
}
