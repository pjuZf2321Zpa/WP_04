<?php

namespace BitApps\PiPro\src\Integrations\LearnDash;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;

if (!\defined('ABSPATH')) {
    exit;
}


final class LearnDashService
{
    private $nodeInfoProvider;

    private $fieldMappings;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
        $this->fieldMappings = $this->nodeInfoProvider->getFieldMapData();
    }

    /**
     * Enroll User to Course.
     *
     * @return array
     */
    public function enrollUserToCourse()
    {
        if (!$this->checkLearnDashFunctions('ld_update_course_access')) {
            return $this->getMissingFunctionsError();
        }

        if ($errors = LearnDashHelper::validateUserRelativeIds($this->fieldMappings)) {
            return $errors;
        }

        $userId = (int) $this->fieldMappings['user_id'];
        $courseId = (int) $this->fieldMappings['course_id'];

        $user = $this->getUserOrError($userId);
        if (\is_array($user) && isset($user['status_code'])) {
            return $user;
        }

        $course = $this->getPostOrError($courseId, 'sfwd-courses');
        if (\is_array($course) && isset($course['status_code'])) {
            return $course;
        }

        if ($this->isUserEnrolledInCourse($userId, $courseId)) {
            return [
                'response'    => __('User already enrolled in course.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 400
            ];
        }

        if (!ld_update_course_access($userId, $courseId)) {
            return $this->getFailureError('enroll user to course');
        }

        $responseData = [
            'user'   => $user,
            'course' => $course,
        ];

        return [
            'response'    => $responseData,
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Remove User from Course.
     *
     * @return array
     */
    public function removeUserFromCourse()
    {
        if (!$this->checkLearnDashFunctions(['learndash_user_get_enrolled_courses', 'ld_update_course_access'])) {
            return $this->getMissingFunctionsError();
        }

        if ($errors = LearnDashHelper::validateUserRelativeIds($this->fieldMappings)) {
            return $errors;
        }

        $userId = (int) $this->fieldMappings['user_id'];
        $courseId = (int) $this->fieldMappings['course_id'];

        $user = $this->getUserOrError($userId);
        if (\is_array($user) && isset($user['status_code'])) {
            return $user;
        }

        $course = $this->getPostOrError($courseId, 'sfwd-courses');
        if (\is_array($course) && isset($course['status_code'])) {
            return $course;
        }

        if (!ld_update_course_access($userId, $courseId, true)) {
            return $this->getFailureError('remove user from course');
        }

        $responseData = [
            'user'   => $user,
            'course' => $course,
        ];

        return [
            'response'    => $responseData,
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Add User to Group.
     *
     * @return array
     */
    public function addUserToGroup()
    {
        if (!$this->checkLearnDashFunctions('ld_update_group_access')) {
            return $this->getMissingFunctionsError();
        }

        if ($errors = LearnDashHelper::validateUserRelativeIds($this->fieldMappings, 'group_id')) {
            return $errors;
        }

        $userId = (int) $this->fieldMappings['user_id'];
        $groupId = (int) $this->fieldMappings['group_id'];

        $user = $this->getUserOrError($userId);
        if (\is_array($user) && isset($user['status_code'])) {
            return $user;
        }

        $group = $this->getPostOrError($groupId, 'groups');
        if (\is_array($group) && isset($group['status_code'])) {
            return $group;
        }

        if (!ld_update_group_access($userId, $groupId)) {
            return $this->getFailureError('add user to group');
        }

        $responseData = [
            'user'  => $user,
            'group' => $group,
        ];

        return [
            'response'    => $responseData,
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Remove User from Group.
     *
     * @return array
     */
    public function removeUserFromGroup()
    {
        if (!$this->checkLearnDashFunctions('ld_update_group_access')) {
            return $this->getMissingFunctionsError();
        }

        if ($errors = LearnDashHelper::validateUserRelativeIds($this->fieldMappings, 'group_id')) {
            return $errors;
        }

        $userId = (int) $this->fieldMappings['user_id'];
        $groupId = (int) $this->fieldMappings['group_id'];

        $user = $this->getUserOrError($userId);
        if (\is_array($user) && isset($user['status_code'])) {
            return $user;
        }

        $group = $this->getPostOrError($groupId, 'groups');
        if (\is_array($group) && isset($group['status_code'])) {
            return $group;
        }

        if (!ld_update_group_access($userId, $groupId, true)) {
            return $this->getFailureError('remove user from group');
        }

        $responseData = [
            'user'  => $user,
            'group' => $group,
        ];

        return [
            'response'    => $responseData,
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Mark Course Complete for User.
     *
     * @return array
     */
    public function markCourseComplete()
    {
        if (!$this->checkLearnDashFunctions(['learndash_process_mark_complete', 'learndash_get_lesson_list'])) {
            return $this->getMissingFunctionsError();
        }

        if ($errors = LearnDashHelper::validateUserRelativeIds($this->fieldMappings)) {
            return $errors;
        }

        $userId = (int) $this->fieldMappings['user_id'];
        $courseId = (int) $this->fieldMappings['course_id'];

        $user = $this->getUserOrError($userId);
        if (\is_array($user) && isset($user['status_code'])) {
            return $user;
        }

        $course = $this->getPostOrError($courseId, 'sfwd-courses');
        if (\is_array($course) && isset($course['status_code'])) {
            return $course;
        }

        $lessons = learndash_get_lesson_list($courseId, ['num' => 0]);
        $quizMapping = [];

        foreach ($lessons as $lesson) {
            $topics = learndash_get_topic_list($lesson->ID, $courseId);
            $this->processTopicsAndQuizzes($userId, $topics, $courseId, $quizMapping);

            $lessonQuizzes = learndash_get_lesson_quiz_list($lesson->ID, $userId, $courseId);
            $this->addQuizzesToMapping($lessonQuizzes, $quizMapping);

            learndash_process_mark_complete($userId, $lesson->ID, false, $courseId);
        }

        $courseQuizzes = learndash_get_course_quiz_list($courseId, $userId);

        $this->addQuizzesToMapping($courseQuizzes, $quizMapping);
        $this->trackQuizProgress($userId, $quizMapping, $courseId);

        if (!learndash_process_mark_complete($userId, $courseId)) {
            return $this->getFailureError('mark course complete for user');
        }

        $responseData = ['user' => $user, 'course' => $course];

        return [
            'response'    => $responseData,
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Mark Lesson Complete for User.
     *
     * @return array
     */
    public function markLessonComplete()
    {
        if (!$this->checkLearnDashFunctions('learndash_process_mark_complete')) {
            return $this->getMissingFunctionsError();
        }

        $rules = [
            'user_id'   => ['required', 'integer'],
            'course_id' => ['required', 'integer'],
            'lesson_id' => ['required', 'integer'],
        ];

        $errors = LearnDashHelper::validateFieldMap($this->fieldMappings, $rules);

        if ($errors) {
            return $errors;
        }

        $userId = (int) $this->fieldMappings['user_id'];
        $courseId = (int) $this->fieldMappings['course_id'];
        $lessonId = (int) $this->fieldMappings['lesson_id'];

        $user = $this->getUserOrError($userId);
        if (\is_array($user) && isset($user['status_code'])) {
            return $user;
        }

        $lesson = $this->getPostOrError($lessonId, 'sfwd-lessons');
        if (\is_array($lesson) && isset($lesson['status_code'])) {
            return $lesson;
        }

        if (!learndash_process_mark_complete($userId, $lessonId, false, $courseId)) {
            return $this->getFailureError('mark lesson complete for user');
        }

        $responseData = [
            'user'   => $user,
            'course' => get_post($courseId),
            'lesson' => $lesson,
        ];

        return [
            'response'    => $responseData,
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Mark Topic Complete for User.
     *
     * @return array
     */
    public function markTopicComplete()
    {
        if (!$this->checkLearnDashFunctions('learndash_process_mark_complete')) {
            return $this->getMissingFunctionsError();
        }

        $rules = [
            'user_id'   => ['required', 'integer'],
            'course_id' => ['required', 'integer'],
            'lesson_id' => ['required', 'integer'],
            'topic_id'  => ['required', 'integer'],
        ];

        $errors = LearnDashHelper::validateFieldMap($this->fieldMappings, $rules);

        if ($errors) {
            return $errors;
        }

        $userId = (int) $this->fieldMappings['user_id'];
        $courseId = (int) $this->fieldMappings['course_id'];
        $lessonId = (int) $this->fieldMappings['lesson_id'];
        $topicId = (int) $this->fieldMappings['topic_id'];

        $user = $this->getUserOrError($userId);
        if (\is_array($user) && isset($user['status_code'])) {
            return $user;
        }

        $topic = $this->getPostOrError($topicId, 'sfwd-topic');
        if (\is_array($topic) && isset($topic['status_code'])) {
            return $topic;
        }

        if (!learndash_process_mark_complete($userId, $topicId, false, $courseId)) {
            return $this->getFailureError('mark topic complete for user');
        }

        $responseData = [
            'user'   => $user,
            'topic'  => $topic,
            'course' => get_post($courseId),
            'lesson' => get_post($lessonId),
        ];

        return [
            'response'    => $responseData,
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Mark Quiz Complete for User.
     *
     * @return array
     */
    public function markQuizComplete()
    {
        if (!$this->checkLearnDashFunctions('learndash_process_mark_complete')) {
            return $this->getMissingFunctionsError();
        }

        if ($errors = LearnDashHelper::validateUserRelativeIds($this->fieldMappings, 'quiz_id')) {
            return $errors;
        }

        $userId = (int) $this->fieldMappings['user_id'];
        $quizId = (int) $this->fieldMappings['quiz_id'];

        $user = $this->getUserOrError($userId);
        if (\is_array($user) && isset($user['status_code'])) {
            return $user;
        }

        $quiz = $this->getPostOrError($quizId, 'sfwd-quiz');
        if (\is_array($quiz) && isset($quiz['status_code'])) {
            return $quiz;
        }

        $courseId = learndash_get_course_id($quizId);

        if (!learndash_process_mark_complete($userId, $quizId, false, $courseId)) {
            return $this->getFailureError('mark quiz complete for user');
        }

        $responseData = [
            'user'   => $user,
            'quiz'   => $quiz,
            'course' => get_post($courseId),
        ];

        return [
            'response'    => $responseData,
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Make User Group Leader.
     *
     * @return array
     */
    public function makeUserGroupLeader()
    {
        if ($errors = LearnDashHelper::validateUserRelativeIds($this->fieldMappings, 'group_id')) {
            return $errors;
        }

        $userId = (int) $this->fieldMappings['user_id'];
        $groupId = (int) $this->fieldMappings['group_id'];

        $user = $this->getUserOrError($userId);
        if (\is_array($user) && isset($user['status_code'])) {
            return $user;
        }

        $group = $this->getPostOrError($groupId, 'groups');
        if (\is_array($group) && isset($group['status_code'])) {
            return $group;
        }

        if (!ld_update_leader_group_access($userId, $groupId)) {
            return $this->getFailureError('add user as group leader');
        }

        $responseData = [
            'user'  => $user,
            'group' => $group,
        ];

        return [
            'response'    => $responseData,
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Remove User from Group Leader.
     *
     * @return array
     */
    public function removeUserFromGroupLeader()
    {
        if ($errors = LearnDashHelper::validateUserRelativeIds($this->fieldMappings, 'group_id')) {
            return $errors;
        }

        $userId = (int) $this->fieldMappings['user_id'];
        $groupId = (int) $this->fieldMappings['group_id'];

        $user = $this->getUserOrError($userId);
        if (\is_array($user) && isset($user['status_code'])) {
            return $user;
        }

        $group = $this->getPostOrError($groupId, 'groups');
        if (\is_array($group) && isset($group['status_code'])) {
            return $group;
        }

        if (ld_update_leader_group_access($userId, $groupId, true)) {
            return $this->getFailureError('remove user from group leader');
        }

        $responseData = [
            'user'  => $user,
            'group' => $group,
        ];

        return [
            'response'    => $responseData,
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Reset User Course Progress.
     *
     * @return array
     */
    public function resetUserCourseProgress()
    {
        if (!$this->checkLearnDashFunctions('learndash_delete_course_progress')) {
            return $this->getMissingFunctionsError();
        }

        if ($errors = LearnDashHelper::validateUserRelativeIds($this->fieldMappings)) {
            return $errors;
        }

        $userId = (int) $this->fieldMappings['user_id'];
        $courseId = (int) $this->fieldMappings['course_id'];

        $user = $this->getUserOrError($userId);
        if (\is_array($user) && isset($user['status_code'])) {
            return $user;
        }

        $course = $this->getPostOrError($courseId, 'sfwd-courses');
        if (\is_array($course) && isset($course['status_code'])) {
            return $course;
        }

        if (!learndash_delete_course_progress($courseId, $userId)) {
            return $this->getFailureError('reset user course progress');
        }

        $responseData = [
            'user'   => $user,
            'course' => $course,
        ];

        return [
            'response'    => $responseData,
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Get User Enrolled Courses.
     *
     * @return array
     */
    public function getUserEnrolledCourses()
    {
        if (!$this->checkLearnDashFunctions('learndash_user_get_enrolled_courses')) {
            return $this->getMissingFunctionsError();
        }

        $rules = [
            'user_id' => ['required', 'integer'],
        ];

        $errors = LearnDashHelper::validateFieldMap($this->fieldMappings, $rules);

        if ($errors) {
            return $errors;
        }

        $userId = (int) $this->fieldMappings['user_id'];

        $user = $this->getUserOrError($userId);
        if (\is_array($user) && isset($user['status_code'])) {
            return $user;
        }

        $courses = array_map(
            function ($courseId) {
                return $this->formatPost($courseId);
            },
            learndash_user_get_enrolled_courses($userId)
        );

        $responseData = [
            'user'             => $user,
            'enrolled_courses' => $courses,
        ];

        return [
            'response'    => $responseData,
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Get User Groups.
     *
     * @return array
     */
    public function getUserGroups()
    {
        if (!$this->checkLearnDashFunctions('learndash_get_users_group_ids')) {
            return $this->getMissingFunctionsError();
        }

        $rules = [
            'user_id' => ['required', 'integer'],
        ];

        $errors = LearnDashHelper::validateFieldMap($this->fieldMappings, $rules);

        if ($errors) {
            return $errors;
        }

        $userId = (int) $this->fieldMappings['user_id'];

        $user = get_userdata($userId);
        if (!$user) {
            return $this->getNotFoundError('User');
        }

        $groups = array_map(
            function ($groupId) {
                return $this->formatPost($groupId);
            },
            learndash_get_users_group_ids($userId)
        );

        $responseData = [
            'user'   => $user,
            'groups' => $groups,
        ];

        return [
            'response'    => $responseData,
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Get Course Taxonomies.
     *
     * @return array
     */
    public function getCourseTaxonomies()
    {
        $rules = [
            'course_id' => ['required', 'integer'],
            'taxonomy'  => ['required', 'string'],
        ];

        $errors = LearnDashHelper::validateFieldMap($this->fieldMappings, $rules);

        if ($errors) {
            return $errors;
        }

        $courseId = (int) $this->fieldMappings['course_id'];
        $taxonomy = $this->fieldMappings['taxonomy'];

        $course = $this->getPostOrError($courseId, 'sfwd-courses');
        if (\is_array($course) && isset($course['status_code'])) {
            return $course;
        }

        return $this->getFormattedTaxonomies($courseId, $taxonomy);
    }

    /**
     * Helper method to process topics and their quizzes for a user.
     *
     * @param array $topics
     * @param array &$quizMapping
     * @param mixed $userId
     * @param mixed $courseId
     */
    private function processTopicsAndQuizzes($userId, $topics, $courseId, &$quizMapping)
    {
        foreach ($topics as $topic) {
            learndash_process_mark_complete($userId, $topic->ID, false, $courseId);
            $topicQuizzes = learndash_get_lesson_quiz_list($topic->ID, $userId, $courseId);

            if ($topicQuizzes) {
                foreach ($topicQuizzes as $quiz) {
                    $quizMapping[$quiz['post']->ID] = 0;
                }
            }
        }
    }

    /**
     * Helper method to add quizzes to the mapping array.
     *
     * @param array $quizzes
     * @param array &$quizMapping
     */
    private function addQuizzesToMapping($quizzes, &$quizMapping)
    {
        if ($quizzes) {
            foreach ($quizzes as $quiz) {
                $quizMapping[$quiz['post']->ID] = 0;
            }
        }
    }

    /**
     * Helper method to track progress of quizzes for the user.
     *
     * @param int $userId
     * @param array $quizMapping
     * @param int $courseId
     */
    private function trackQuizProgress($userId, $quizMapping, $courseId)
    {
        if (empty($quizMapping)) {
            return;
        }

        $progressData = [];
        $userQuizMeta = get_user_meta($userId, '_sfwd-quizzes', true);
        $progressData = (array) (empty($userQuizMeta) ? [] : $userQuizMeta);

        foreach ($quizMapping as $quizId => $status) {
            $quizMeta = (array) get_post_meta($quizId, '_sfwd-quiz', true);

            if (learndash_is_quiz_complete($userId, $quizId, $courseId)) {
                continue;
            }

            $quizProgressEntry = [
                'quiz'             => $quizId,
                'score'            => 0,
                'count'            => 0,
                'pass'             => true,
                'rank'             => '-',
                'time'             => time(),
                'pro_quizid'       => $quizMeta['sfwd-quiz_quiz_pro'],
                'course'           => $courseId,
                'points'           => 0,
                'total_points'     => 0,
                'percentage'       => 100,
                'timespent'        => 0,
                'has_graded'       => false,
                'statistic_ref_id' => 0,
                'm_edit_by'        => 9999999,
                'm_edit_time'      => time(),
            ];

            $progressData[] = $quizProgressEntry;

            learndash_update_user_activity(
                [
                    'course_id'          => $courseId,
                    'user_id'            => $userId,
                    'post_id'            => $quizId,
                    'activity_type'      => 'quiz',
                    'activity_action'    => 'insert',
                    'activity_status'    => true,
                    'activity_started'   => $quizProgressEntry['time'],
                    'activity_completed' => $quizProgressEntry['time'],
                    'activity_meta'      => $quizProgressEntry,
                ]
            );
        }

        if (!empty($progressData)) {
            update_user_meta($userId, '_sfwd-quizzes', $progressData);
        }
    }

    /**
     * Check if required LearnDash function exists.
     *
     * @param array|string $functions Function name(s) to check
     */
    private function checkLearnDashFunctions($functions): bool
    {
        if (\is_string($functions)) {
            return \function_exists($functions);
        }

        foreach ((array) $functions as $function) {
            if (!\function_exists($function)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Return error response for missing LearnDash functions.
     */
    private function getMissingFunctionsError(): array
    {
        return [
            'response'    => __('LearnDash functions do not exist.', 'bit-pi'),
            'payload'     => [],
            'status_code' => 400
        ];
    }

    /**
     * Return not found error response.
     *
     * @param string $type Entity type (e.g., 'User', 'Course')
     */
    private function getNotFoundError(string $type): array
    {
        return [
            // translators: %s: Entity type (e.g., 'User', 'Course')
            'response'    => \sprintf(__('%s not found.', 'bit-pi'), $type),
            'payload'     => $this->fieldMappings,
            'status_code' => 404
        ];
    }

    /**
     * Return operation failure error response.
     *
     * @param string $operation Operation description
     */
    private function getFailureError(string $operation): array
    {
        return [
            // translators: %s: Operation description
            'response'    => \sprintf(__('Failed to %s.', 'bit-pi'), $operation),
            'payload'     => $this->fieldMappings,
            'status_code' => 500
        ];
    }

    /**
     * Get and validate user by ID.
     *
     * @param int $userId User ID
     *
     * @return array|object User object or error array
     */
    private function getUserOrError(int $userId)
    {
        $user = Utility::getUserInfo($userId);

        if (empty($user)) {
            return $this->getNotFoundError('User');
        }

        return $user;
    }

    /**
     * Get and validate post by ID and type.
     *
     * @param int    $postId Post ID
     * @param string $postType Expected post type
     *
     * @return array|object Post object or error array
     */
    private function getPostOrError(int $postId, string $postType)
    {
        $post = get_post($postId);
        if (!$post || $post->post_type !== $postType) {
            $typeMap = [
                'sfwd-courses' => 'Course',
                'sfwd-lessons' => 'Lesson',
                'sfwd-topic'   => 'Topic',
                'sfwd-quiz'    => 'Quiz',
                'groups'       => 'Group',
            ];

            return $this->getNotFoundError($typeMap[$postType] ?? 'Post');
        }

        return $post;
    }

    /**
     * Format post as simple array.
     *
     * @param int $postId Post ID
     */
    private function formatPost(int $postId): array
    {
        $post = (array) get_post($postId);

        $post['permalink'] = get_permalink($postId);

        return $post;
    }

    /**
     * Check if user is enrolled in course.
     *
     * @param int $userId User ID
     * @param int $courseId Course ID
     */
    private function isUserEnrolledInCourse(int $userId, int $courseId): bool
    {
        if (!\function_exists('learndash_user_get_enrolled_courses')) {
            return false;
        }

        $enrolledCourses = learndash_user_get_enrolled_courses($userId);

        return \in_array($courseId, $enrolledCourses, true);
    }

    /**
     * Get and format course taxonomies.
     *
     * @param int    $courseId Course ID
     * @param string $taxonomy Taxonomy name
     */
    private function getFormattedTaxonomies(int $courseId, string $taxonomy): array
    {
        $terms = get_the_terms($courseId, $taxonomy);

        if (is_wp_error($terms)) {
            return [
                'response'    => $terms->get_error_message(),
                'payload'     => $this->fieldMappings,
                'status_code' => 400
            ];
        }

        $taxonomies = [];
        if ($terms) {
            $taxonomies = array_map(
                function ($term) {
                    return [
                        'id'          => $term->term_id,
                        'name'        => $term->name,
                        'slug'        => $term->slug,
                        'description' => $term->description,
                    ];
                },
                $terms
            );
        }

        $responseData = [
            'course_id'  => $courseId,
            'taxonomy'   => $taxonomy,
            'taxonomies' => $taxonomies,
        ];

        return [
            'response'    => $responseData,
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }
}
