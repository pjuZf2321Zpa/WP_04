<?php

namespace BitApps\PiPro\src\Integrations\GoogleDocs;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Authorization\AuthorizationFactory;
use BitApps\Pi\src\Authorization\AuthorizationType;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Client\HttpClient;

if (!\defined('ABSPATH')) {
    exit;
}

class GoogleDocsAction implements ActionInterface
{
    public const AUTH_TOKEN_URL = 'https://oauth2.googleapis.com/token';

    private NodeInfoProvider $nodeInfoProvider;

    private GoogleDocsService $googleDocsService;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeGoogleDocsAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'],
            $executedNodeAction['payload'],
            $executedNodeAction['response']
        );
    }

    private function executeMachine($machineSlug, $fieldMapData, $configs)
    {
        $documentId = $configs['document-id']['value'] ?? null;

        switch ($machineSlug) {
            case 'createDocument':
                return $this->googleDocsService->createDocument($configs['folder-id']['value'] ?? null, $fieldMapData);

            case 'createDocumentFromTemplate':
                $templateDocumentId = $configs['template-document-id']['value'] ?? null;

                return $this->googleDocsService->createDocumentFromTemplate($templateDocumentId, $fieldMapData);

            case 'appendText':
                return $this->googleDocsService->appendText($documentId, $fieldMapData);

            case 'findDocument':
                return $this->googleDocsService->findDocument($fieldMapData);

            case 'getDocumentContent':
                return $this->googleDocsService->getDocumentContent($documentId);

            case 'insertImage':
                return $this->googleDocsService->insertImage($documentId, $fieldMapData);

            case 'listDocuments':
                $driveId = $this->nodeInfoProvider->getFieldMapConfigs('drive-id.value');
                $folderId = $this->nodeInfoProvider->getFieldMapConfigs('folder-id.value');
                $limit = $fieldMapData['limit'] ?? 100;

                return $this->googleDocsService->listDocuments($limit, $driveId, $folderId);

            case 'deleteDocument':
                return $this->googleDocsService->deleteDocument($documentId);
        }
    }

    private function executeGoogleDocsAction()
    {
        $machineSlug = $this->nodeInfoProvider->getMachineSlug();
        $configs = $this->nodeInfoProvider->getFieldMapConfigs();
        $fieldMapData = $this->nodeInfoProvider->getFieldMapData();

        $accessToken = AuthorizationFactory::getAuthorizationHandler(
            AuthorizationType::OAUTH2,
            $configs['connection-id']
        )->setRefreshTokenUrl(self::AUTH_TOKEN_URL)->getAccessToken();

        $httpClient = new HttpClient(
            [
                'headers' => [
                    'Content-Type'  => 'application/json',
                    'Authorization' => $accessToken,
                ],
            ]
        );

        $this->googleDocsService = new GoogleDocsService($httpClient);

        return $this->executeMachine($machineSlug, $fieldMapData, $configs);
    }
}
