<?php

namespace BitApps\PiPro\src\Integrations\GoogleDocs;

use BitApps\PiPro\Deps\BitApps\WPKit\Helpers\JSON;

if (!\defined('ABSPATH')) {
    exit;
}

class GoogleDocsService
{
    private $http;

    private $baseUrl;

    /**
     * GoogleDocsService constructor.
     *
     * @param mixed $httpClient
     */
    public function __construct($httpClient)
    {
        $this->http = $httpClient;
        $this->baseUrl = 'https://docs.googleapis.com/v1';
    }

    /**
     * Create a new document.
     *
     * @param array $fieldMapData
     * @param mixed $folderId
     *
     * @return array
     */
    public function createDocument($folderId, $fieldMapData)
    {
        $endPoint = $this->baseUrl . '/documents';

        $body = [
            'title' => $fieldMapData['title'] ?? 'Untitled Document',
        ];

        $response = $this->http->request($endPoint, 'POST', JSON::encode($body));

        if ($this->http->getResponseCode() === 200) {
            $documentId = $response->documentId;

            if ($folderId && $folderId !== 'root') {
                $this->moveDocumentToFolder($documentId, $folderId);
            }

            if (!empty($fieldMapData['insertText']['text'])) {
                unset($fieldMapData['title']);

                return $this->appendText($documentId, $fieldMapData);
            }
        }

        return [
            'response'    => $response,
            'payload'     => $body,
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Create a document from a template by copying it.
     *
     * @param string $templateDocumentId
     * @param mixed $fieldMapData
     *
     * @return array
     */
    public function createDocumentFromTemplate($templateDocumentId, $fieldMapData)
    {
        $endPoint = 'https://www.googleapis.com/drive/v3/files/' . urlencode($templateDocumentId) . '/copy?supportsAllDrives=true';

        if ($fieldMapData['parents'] && $fieldMapData['parents'] === 'root') {
            $fieldMapData['parents'] = ['root'];
        }

        $response = $this->http->request($endPoint, 'POST', JSON::encode($fieldMapData));

        return [
            'response'    => $response,
            'payload'     => [],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Append text to a document.
     *
     * @param string $documentId
     * @param mixed $fieldMapData
     *
     * @return array
     */
    public function appendText($documentId, $fieldMapData)
    {
        $endPoint = $this->baseUrl . '/documents/' . urlencode($documentId) . ':batchUpdate';

        $fieldMapData['insertText']['endOfSegmentLocation'] = ['segmentId' => ''];
        $body = ['requests' => [$fieldMapData]];

        $response = $this->http->request($endPoint, 'POST', JSON::encode($body));

        return [
            'response'    => $response,
            'payload'     => $body,
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Find a document by name.
     *
     * @param array $fieldMapData
     *
     * @return array
     */
    public function findDocument($fieldMapData)
    {
        $documentName = $fieldMapData['name'] ?? '';
        $folderId = $fieldMapData['folderId'] ?? null;

        $query = [
            "name contains '" . str_replace("'", "\\'", $documentName) . "'",
            "mimeType='application/vnd.google-apps.document'",
            'trashed=false',
        ];

        if ($folderId) {
            $query[] = "'" . str_replace("'", "\\'", $folderId) . "' in parents";
        }

        $q = implode(' and ', $query);

        $params = [
            'q'                         => $q,
            'supportsAllDrives'         => 'true',
            'fields'                    => '*',
            'pageSize'                  => 1,
            'includeItemsFromAllDrives' => 'true',
        ];

        $endPoint = 'https://www.googleapis.com/drive/v3/files?' . http_build_query($params);
        $response = $this->http->request($endPoint, 'GET', null);

        $existingFile = $response->files[0] ?? null;

        if ($existingFile) {
            return [
                'response'    => ['found' => true, 'file' => $existingFile],
                'payload'     => $fieldMapData,
                'status_code' => 200
            ];
        }

        return [
            'response'    => ['found' => false, 'file' => 'No document found with the specified name.'],
            'payload'     => $fieldMapData,
            'status_code' => 200
        ];
    }

    /**
     * Get document content as plain text.
     *
     * @param string $documentId
     *
     * @return array
     */
    public function getDocumentContent($documentId)
    {
        $endPoint = $this->baseUrl . '/documents/' . urlencode($documentId);
        $response = $this->http->request($endPoint, 'GET', []);

        $content = '';
        if (isset($response->body->content)) {
            foreach ($response->body->content as $element) {
                if (isset($element->paragraph)) {
                    foreach ($element->paragraph->elements as $textElement) {
                        if (isset($textElement->textRun)) {
                            $content .= $textElement->textRun->content;
                        }
                    }
                }
            }
        }

        return [
            'response'    => ['content' => $content, 'documentId' => $documentId],
            'payload'     => ['documentId' => $documentId],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Insert an image into a document.
     *
     * @param string $documentId
     * @param array  $fieldMapData
     *
     * @return array
     */
    public function insertImage($documentId, $fieldMapData)
    {
        $endPoint = $this->baseUrl . '/documents/' . urlencode($documentId) . ':batchUpdate';

        $insertImageRequest = $fieldMapData;

        if (isset($insertImageRequest['insertInlineImage']['objectSize']['width']['magnitude'])) {
            $insertImageRequest['insertInlineImage']['objectSize']['width']['unit'] = 'PT';
        }

        if (isset($insertImageRequest['insertInlineImage']['objectSize']['height']['magnitude'])) {
            $insertImageRequest['insertInlineImage']['objectSize']['height']['unit'] = 'PT';
        }

        $body = [
            'requests' => [$insertImageRequest]
        ];

        $response = $this->http->request($endPoint, 'POST', JSON::encode($body));

        return [
            'response'    => $response,
            'payload'     => $body,
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Delete a document.
     *
     * @param mixed $documentId
     *
     * @return array
     */
    public function deleteDocument($documentId)
    {
        $endpoint = 'https://www.googleapis.com/drive/v3/files/' . urlencode($documentId) . '?supportsAllDrives=true';

        $response = $this->http->request($endpoint, 'PATCH', JSON::encode(['trashed' => true]));

        return [
            'response'    => $response,
            'payload'     => ['document-id' => $documentId],
            'status_code' => $this->http->getResponseCode(),
        ];
    }

    /**
     * List documents from Google Drive.
     *
     * @param mixed $driveId
     * @param mixed $folderId
     * @param mixed $limit
     *
     * @return array
     */
    public function listDocuments($limit, $driveId = null, $folderId = null)
    {
        $query = "mimeType = 'application/vnd.google-apps.document' and trashed = false";

        if ($folderId && $folderId !== 'root') {
            $query .= " and '{$folderId}' in parents";
        }

        $params = [
            'q'                         => $query,
            'pageSize'                  => (int) max(1, min(1000, $limit)),
            'fields'                    => 'nextPageToken, files(id, name, mimeType, createdTime, modifiedTime, webViewLink)',
            'orderBy'                   => 'name',
            'corpora'                   => 'allDrives',
            'includeItemsFromAllDrives' => 'true',
            'supportsAllDrives'         => 'true',
        ];

        if ($driveId && $driveId !== 'root') {
            $params['driveId'] = $driveId;
            $params['corpora'] = 'drive';
        }

        $endpoint = 'https://www.googleapis.com/drive/v3/files?' . http_build_query($params);

        $response = $this->http->request($endpoint, 'GET', null);

        return [
            'response'    => $response,
            'payload'     => compact('driveId', 'folderId', 'limit'),
            'status_code' => $this->http->getResponseCode(),
        ];
    }

    /**
     * Move a document to a specific folder.
     *
     * @param string $documentId
     * @param string $folderId
     */
    private function moveDocumentToFolder($documentId, $folderId)
    {
        $fileEndPoint = 'https://www.googleapis.com/drive/v3/files/' . urlencode($documentId) . '?fields=parents&supportsAllDrives=true';
        $file = $this->http->request($fileEndPoint, 'GET', []);
        $previousParents = implode(',', $file->parents);

        $endPoint = 'https://www.googleapis.com/drive/v3/files/' . urlencode($documentId) . '?addParents=' . urlencode($folderId) . '&removeParents=' . $previousParents . '&supportsAllDrives=true';
        $this->http->request($endPoint, 'PATCH', JSON::encode([]));
    }
}
