<?php

namespace BitApps\PiPro\src\Integrations\GoogleTasks;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Authorization\AuthorizationFactory;
use BitApps\Pi\src\Authorization\AuthorizationType;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Client\HttpClient;

if (!\defined('ABSPATH')) {
    exit;
}

class GoogleTasksAction implements ActionInterface
{
    private NodeInfoProvider $nodeInfoProvider;

    private GoogleTasksService $googleTasksService;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeGoogleTasksAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'],
            $executedNodeAction['payload'],
            $executedNodeAction['response']
        );
    }

    private function executeMachine($machineSlug, $fieldMapData, $configs)
    {
        $taskListId = $configs['task-list-id']['value'] ?? null;
        $taskId = $configs['task-id']['value'] ?? null;

        switch ($machineSlug) {
            case 'createTask':
                return $this->googleTasksService->createTask($taskListId, $fieldMapData);

            case 'deleteTask':
                $taskId = $fieldMapData['taskId'] ?? $taskId;

                return $this->googleTasksService->deleteTask($taskListId, $taskId);

            case 'getTask':
                $taskId = $fieldMapData['taskId'] ?? $taskId;

                return $this->googleTasksService->getTask($taskListId, $taskId);

            case 'listTasks':
                return $this->googleTasksService->listTasks($taskListId, $fieldMapData);

            case 'updateTask':
                $taskId = $configs['task-id']['value'] ?? ($fieldMapData['taskId'] ?? null);

                return $this->googleTasksService->updateTask($taskListId, $taskId, $fieldMapData);
        }
    }

    private function executeGoogleTasksAction()
    {
        $machineSlug = $this->nodeInfoProvider->getMachineSlug();
        $configs = $this->nodeInfoProvider->getFieldMapConfigs();
        $fieldMapData = $this->nodeInfoProvider->getFieldMapData();

        $accessToken = AuthorizationFactory::getAuthorizationHandler(
            AuthorizationType::OAUTH2,
            $configs['connection-id']
        )->getAccessToken();

        $httpClient = new HttpClient(
            [
                'headers' => [
                    'Content-Type'  => 'application/json',
                    'Authorization' => $accessToken,
                ],
            ]
        );

        $this->googleTasksService = new GoogleTasksService($httpClient);

        return $this->executeMachine($machineSlug, $fieldMapData, $configs);
    }
}
