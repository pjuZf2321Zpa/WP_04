<?php

namespace BitApps\PiPro\src\Integrations\GoogleTasks;

use BitApps\PiPro\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Client\HttpClient;
use DateTime;

if (!\defined('ABSPATH')) {
    exit;
}

class GoogleTasksService
{
    private const BASE_URL = 'https://www.googleapis.com/tasks/v1';

    private HttpClient $http;

    /**
     * GoogleTasksService constructor.
     *
     * @param HttpClient $httpClient
     */
    public function __construct($httpClient)
    {
        $this->http = $httpClient;
    }

    /**
     * Create a new task in the specified task list.
     *
     * @param string $taskListId
     * @param array $taskData
     *
     * @return array
     */
    public function createTask($taskListId, $taskData)
    {
        $endPoint = self::BASE_URL . '/lists/' . urlencode($taskListId) . '/tasks';

        if (!empty($taskData['due'])) {
            $taskData['due'] = (new DateTime($taskData['due']))->format(DateTime::RFC3339);
        }

        $response = $this->http->request($endPoint, 'POST', JSON::encode($taskData));

        return [
            'response'    => $response,
            'payload'     => $taskData,
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Get a single task from the specified task list.
     *
     * @param string $taskListId
     * @param string $taskId
     *
     * @return array
     */
    public function getTask($taskListId, $taskId)
    {
        $endPoint = self::BASE_URL . '/lists/' . urlencode($taskListId) . '/tasks/' . urlencode($taskId);
        $response = $this->http->request($endPoint, 'GET', null);

        return [
            'response'    => $response,
            'payload'     => ['taskListId' => $taskListId, 'taskId' => $taskId],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * List tasks in the specified task list.
     *
     * @param string $taskListId
     * @param array $queryParams
     *
     * @return array
     */
    public function listTasks($taskListId, $queryParams = [])
    {
        $endPoint = self::BASE_URL . '/lists/' . urlencode($taskListId) . '/tasks';

        if (!empty($queryParams)) {
            $endPoint = add_query_arg($queryParams, $endPoint);
        }

        $response = $this->http->request($endPoint, 'GET', null);

        return [
            'response'    => $response,
            'payload'     => ['taskListId' => $taskListId],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Update an existing task.
     *
     * @param string $taskListId
     * @param string $taskId
     * @param array $taskData
     *
     * @return array
     */
    public function updateTask($taskListId, $taskId, $taskData)
    {
        $endPoint = self::BASE_URL . '/lists/' . urlencode($taskListId) . '/tasks/' . urlencode($taskId);

        if (!empty($taskData['due'])) {
            $taskData['due'] = (new DateTime($taskData['due']))->format(DateTime::RFC3339);
        }

        $response = $this->http->request($endPoint, 'PATCH', JSON::encode($taskData));

        return [
            'response'    => $response,
            'payload'     => $taskData,
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Delete a task.
     *
     * @param string $taskListId
     * @param string $taskId
     *
     * @return array
     */
    public function deleteTask($taskListId, $taskId)
    {
        $endPoint = self::BASE_URL . '/lists/' . urlencode($taskListId) . '/tasks/' . urlencode($taskId);
        $response = $this->http->request($endPoint, 'DELETE', null);

        return [
            'response'    => $response ?: ['success' => true],
            'payload'     => ['taskListId' => $taskListId, 'taskId' => $taskId],
            'status_code' => $this->http->getResponseCode()
        ];
    }
}
