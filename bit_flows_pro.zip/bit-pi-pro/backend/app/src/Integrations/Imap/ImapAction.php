<?php

namespace BitApps\PiPro\src\Integrations\Imap;

// Prevent direct script access
if (!defined('ABSPATH')) {
    exit;
}

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;
use RuntimeException;
use Throwable;

/**
 * Mailbox actions on an IMAP connection.
 *
 * The getEmails action searches a folder and returns the matches; saveDraft
 * stores a new message as an unsent draft; the others (markRead, markUnread,
 * moveEmail, copyEmail, deleteEmail) operate on a single message addressed by
 * UID — typically piped in from the New Email trigger's output.
 */
class ImapAction implements ActionInterface
{
    /**
     * Upper bound of messages a Get Emails search may return.
     *
     * The search fetches every match in one batched IMAP command, so the
     * ceiling is not about round trips. It bounds two other costs: time, since
     * each message still carries its full body over the wire and on a slow
     * mailbox that measures in seconds apiece; and memory, since the batch is
     * resident at once — the fetched messages plus the flattened records, both
     * holding every body. Raising this materially means weighing both.
     */
    private const SEARCH_LIMIT_MAX = 100;

    private const SEARCH_LIMIT_DEFAULT = 10;

    private NodeInfoProvider $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $service = null;

        try {
            if (!ImapService::isSupported()) {
                throw new RuntimeException(esc_html(ImapService::unsupportedMessage()));
            }

            $configs = $this->nodeInfoProvider->getFieldMapConfigs();

            $connectionId = $this->config($configs, 'connection-id');

            if ($connectionId === '') {
                throw new RuntimeException(esc_html__('No IMAP connection selected.', 'bit-pi'));
            }

            $service = ImapService::fromConnection($connectionId);

            [$input, $output] = $this->runAction($service, $configs);

            return Utility::formatResponseData(200, $input, $output);
        } catch (Throwable $th) {
            return Utility::formatResponseData(400, [], $th->getMessage());
        } finally {
            if ($service) {
                $service->disconnect();
            }
        }
    }

    /**
     * Dispatch on the machine slug.
     *
     * @param array<string, mixed> $configs
     *
     * @return array{0: array<string, mixed>, 1: array<string, mixed>}
     */
    private function runAction(ImapService $service, array $configs): array
    {
        $machineSlug = $this->nodeInfoProvider->getMachineSlug();
        $fieldMapData = $this->nodeInfoProvider->getFieldMapData();
        $folder = $this->config($configs, 'folder', 'INBOX');

        if ($machineSlug === 'getEmails') {
            return $this->getEmails($service, $configs, $fieldMapData, $folder);
        }

        if ($machineSlug === 'saveDraft') {
            return $this->saveDraft($service, $configs, $fieldMapData);
        }

        $uid = (int) trim((string) ($fieldMapData['uid'] ?? ''));

        if ($uid <= 0) {
            throw new RuntimeException(esc_html__('A message UID is required.', 'bit-pi'));
        }

        $input = ['folder' => $folder, 'uid' => $uid];

        switch ($machineSlug) {
            case 'markRead':
                $service->markRead($folder, $uid);

                break;

            case 'markUnread':
                $service->markUnread($folder, $uid);

                break;

            case 'deleteEmail':
                $service->deleteMessage($folder, $uid);

                break;

            case 'moveEmail':
            case 'copyEmail':
                $targetFolder = $this->config($configs, 'target-folder');

                if ($targetFolder === '') {
                    throw new RuntimeException(esc_html__('A target folder is required.', 'bit-pi'));
                }

                $input['target_folder'] = $targetFolder;

                if ($machineSlug === 'moveEmail') {
                    $service->moveMessage($folder, $uid, $targetFolder);
                } else {
                    $service->copyMessage($folder, $uid, $targetFolder);
                }

                break;

            default:
                throw new RuntimeException(esc_html("Unknown IMAP action: {$machineSlug}"));
        }

        return [$input, ['success' => true] + $input];
    }

    /**
     * Search a folder and return the matching messages.
     *
     * @param array<string, mixed> $configs
     * @param array<string, mixed> $fieldMapData
     *
     * @return array{0: array<string, mixed>, 1: array<string, mixed>}
     */
    private function getEmails(ImapService $service, array $configs, array $fieldMapData, string $folder): array
    {
        $filters = [
            'criteria' => $this->config($configs, 'criteria', 'all'),
            'rules'    => ImapService::normalizeCustomRules($fieldMapData['custom_rules'] ?? ''),
        ];

        $requestedLimit = (int) $this->config($configs, 'limit', (string) self::SEARCH_LIMIT_DEFAULT);
        $limit = max(1, min($requestedLimit, self::SEARCH_LIMIT_MAX));

        $records = $service->searchEmails($folder, $filters, $limit);

        return [
            ['folder' => $folder, 'limit' => $requestedLimit] + $filters,
            [
                'count'         => \count($records),
                'limit_applied' => $limit,
                'notice'        => $this->limitNotice($requestedLimit),
                'emails'        => $records,
            ],
        ];
    }

    /**
     * Save a message to a folder, usually Drafts, without sending it.
     *
     * @param array<string, mixed> $configs
     * @param array<string, mixed> $fieldMapData
     *
     * @return array{0: array<string, mixed>, 1: array<string, mixed>}
     */
    private function saveDraft(ImapService $service, array $configs, array $fieldMapData): array
    {
        $folder = $this->config($configs, 'folder');

        if ($folder === '') {
            throw new RuntimeException(esc_html__('Select the folder to save the draft in.', 'bit-pi'));
        }

        $draft = [
            'to'        => $this->splitAddresses($fieldMapData['toEmail'] ?? ''),
            'cc'        => $this->splitAddresses($fieldMapData['ccEmail'] ?? ''),
            'subject'   => trim((string) ($fieldMapData['subject'] ?? '')),
            'body'      => (string) ($fieldMapData['body'] ?? ''),
            'isHtml'    => (bool) ($configs['mail-format']['value'] ?? false),
            'inReplyTo' => $this->messageIdHeader((string) ($fieldMapData['inReplyTo'] ?? '')),
        ];

        if ($draft['to'] === []) {
            throw new RuntimeException(esc_html__('At least one recipient is required.', 'bit-pi'));
        }

        $messageId = $service->saveDraft($folder, $draft);

        $input = ['folder' => $folder] + $draft;

        return [$input, ['success' => true, 'message_id' => $messageId] + $input];
    }

    /**
     * Comma-separated addresses as a list, blanks dropped.
     *
     * @param mixed $value
     *
     * @return string[]
     */
    private function splitAddresses($value): array
    {
        return array_values(array_filter(array_map('trim', explode(',', (string) $value))));
    }

    /**
     * A Message-ID in header form. The New Email trigger outputs it without the
     * angle brackets that In-Reply-To and References require.
     */
    private function messageIdHeader(string $messageId): string
    {
        $messageId = trim($messageId, " \t\n\r\0\x0B<>");

        return $messageId === '' ? '' : '<' . $messageId . '>';
    }

    /**
     * Why fewer emails came back than were asked for, if that happened.
     *
     * A mailbox holding 102 messages with the limit set to 102 returns 100,
     * and without this the two missing ones look like a bug rather than the
     * ceiling doing its job. Always present, empty when nothing was capped,
     * so the node's output tokens stay the same between runs.
     */
    private function limitNotice(int $requestedLimit): string
    {
        if ($requestedLimit <= self::SEARCH_LIMIT_MAX) {
            return '';
        }

        return sprintf(
            /* translators: 1: number of emails requested, 2: maximum emails per run */
            __('Requested %1$d emails; returned the newest %2$d, the maximum per run.', 'bit-pi'),
            $requestedLimit,
            self::SEARCH_LIMIT_MAX
        );
    }

    /**
     * A scalar config value; selects arrive as ['value' => ...] wrappers.
     *
     * @param array<string, mixed> $configs
     */
    private function config(array $configs, string $key, string $fallback = ''): string
    {
        $value = $configs[$key]['value'] ?? $configs[$key] ?? $fallback;

        if (\is_array($value) || \is_object($value)) {
            return $fallback;
        }

        $value = trim((string) $value);

        return $value === '' ? $fallback : $value;
    }
}
