<?php

namespace BitApps\PiPro\src\Integrations\Imap;

// Prevent direct script access
if (!defined('ABSPATH')) {
    exit;
}

use BitApps\PiPro\Deps\Webklex\PHPIMAP\Client;
use BitApps\PiPro\Deps\Webklex\PHPIMAP\ClientManager;
use BitApps\PiPro\Deps\Webklex\PHPIMAP\Config;

/**
 * ClientManager that routes every config through CustomConfig.
 *
 * Guarantees the stock Config::make() — and with it the vendored default
 * config file and its unprefixed class references — is never reached.
 */
class ClientManagerConfig extends ClientManager
{
    /**
     * Skip the stock constructor so the vendored defaults never load.
     *
     * @param array|string|Config $config
     */
    public function __construct($config = [])
    {
        $this->setConfig($config);
    }

    /**
     * Wrap any given config in CustomConfig.
     *
     * @param array|string|Config $config
     */
    public function setConfig($config): ClientManager
    {
        if (!$config instanceof CustomConfig) {
            $config = CustomConfig::make($config);
        }

        $this->config = $config;

        return $this;
    }

    /**
     * Build a client for the given account settings.
     */
    public function make(array $config): Client
    {
        $name = $this->config->getDefaultAccount();
        $clientConfig = $this->config->all();
        $clientConfig['accounts'] = [$name => $config];

        return new Client(CustomConfig::make($clientConfig));
    }
}
