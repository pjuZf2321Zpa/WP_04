<?php

namespace BitApps\PiPro\src\Integrations\Imap;

// Prevent direct script access
if (!defined('ABSPATH')) {
    exit;
}

use BitApps\Pi\src\Authorization\AuthorizationFactory;
use BitApps\Pi\src\Authorization\AuthorizationType;
use BitApps\PiPro\Deps\Carbon\Carbon;
use BitApps\PiPro\Deps\Webklex\PHPIMAP\Exceptions\ImapServerErrorException;
use BitApps\PiPro\Deps\Webklex\PHPIMAP\Exceptions\InvalidMessageDateException;
use BitApps\PiPro\Deps\Webklex\PHPIMAP\Exceptions\MessageContentFetchingException;
use BitApps\PiPro\Deps\Webklex\PHPIMAP\Exceptions\MessageFlagException;
use BitApps\PiPro\Deps\Webklex\PHPIMAP\Exceptions\MessageHeaderFetchingException;
use BitApps\PiPro\Deps\Webklex\PHPIMAP\Exceptions\MessageSizeFetchingException;
use PHPMailer\PHPMailer\PHPMailer;
use RuntimeException;
use Throwable;

/**
 * Thin wrapper around webklex/php-imap.
 *
 * The library requires PHP 8.0.2+, which is above the plugin's own minimum, so
 * every entry point calls isSupported() BEFORE any Webklex symbol is referenced
 * — the classmap autoloader never loads a file whose class is never mentioned.
 */
class ImapService
{
    /**
     * The webklex/php-imap library declares "php": "^8.0.2".
     */
    public const MIN_PHP_VERSION_ID = 80002;

    /**
     * Messages pulled on the very first poll, purely to populate tokens.
     */
    public const SEED_LIMIT = 3;

    /**
     * Upper bound of emails handed to the flow in a single poll.
     */
    public const POLL_LIMIT = 50;

    private $config;

    private $client;

    public function __construct(array $config)
    {
        $this->config = $config;
    }

    public function __destruct()
    {
        $this->disconnect();
    }

    public static function isSupported(): bool
    {
        return PHP_VERSION_ID >= self::MIN_PHP_VERSION_ID;
    }

    public static function unsupportedMessage(): string
    {
        return __('The Email (IMAP) trigger requires PHP 8.0.2 or later.', 'bit-pi');
    }

    /**
     * Build a service from a stored IMAP connection.
     *
     * @param int|string $connectionId
     *
     * @throws RuntimeException when the connection is missing or unusable
     */
    public static function fromConnection($connectionId): self
    {
        $config = AuthorizationFactory::getAuthorizationHandler(
            AuthorizationType::CUSTOM,
            $connectionId,
            'imap'
        )->getAccessToken();

        if (\is_array($config) && isset($config['error'])) {
            throw new RuntimeException(esc_html($config['message'] ?? 'Failed to resolve the IMAP connection.'));
        }

        return new self((array) $config);
    }

    /**
     * Folder paths for a dropdown.
     *
     * @return array<int, array{label:string,value:string}>
     */
    public function listFolders(): array
    {
        $folders = $this->client()->getFolders(false);

        $options = [];

        foreach ($folders as $folder) {
            $path = (string) $folder->path;

            if ($path === '') {
                continue;
            }

            $options[] = ['label' => $path, 'value' => $path];
        }

        return $options;
    }

    /**
     * UIDVALIDITY of the folder — when the server changes it, previously stored
     * UIDs become meaningless and the watermark must be reset.
     *
     * @return null|int
     */
    public function uidValidity(string $folder)
    {
        try {
            $status = $this->folder($folder)->examine();
        } catch (Throwable $th) {
            return;
        }

        if (!\is_array($status)) {
            return;
        }

        $validity = $status['uidvalidity'] ?? null;

        return $validity === null ? null : (int) $validity;
    }

    /**
     * UIDs of messages newer than $afterUid, oldest first.
     *
     * Only headers are fetched here; bodies are pulled per message afterwards so
     * a large window never drags full message bodies over the wire.
     *
     * @param null|int                              $afterUid null on the first ever poll
     * @param array{criteria?:string,rules?:string} $filters
     *
     * @return array<int, int>
     */
    public function fetchNewUids(string $folder, $afterUid, int $limit, array $filters = []): array
    {
        $query = $this->folder($folder)->query()->leaveUnread()->setFetchBody(false);

        $this->applyFilters($query, $filters);

        // limit() slices the UID search result BEFORE headers are fetched, so a
        // 10k-message mailbox costs $limit header fetches, not 10k. The search
        // itself is a single cheap UID SEARCH command.
        if ($afterUid === null) {
            // First run: only the newest few, purely to populate tokens.
            $query->all()->setFetchOrder('desc')->limit($limit);
        } else {
            // Oldest first (default order), so a burst larger than the cap is
            // never stranded — the remainder arrives on the next poll.
            $query->where('CUSTOM UID ' . ($afterUid + 1) . ':*')->limit($limit);
        }

        $uids = [];

        foreach ($query->get() as $message) {
            $uid = (int) $message->uid;

            // The UID range is inclusive of $afterUid on some servers, and a
            // bare "*" can return the newest message even when none are newer.
            if ($afterUid !== null && $uid <= $afterUid) {
                continue;
            }

            $uids[] = $uid;
        }

        sort($uids);

        return $uids;
    }

    /**
     * A single message flattened into data-piping tokens.
     *
     * @return null|array<string, mixed>
     */
    public function fetchMessage(string $folder, int $uid)
    {
        $message = $this->findMessage($folder, $uid);

        if (!$message) {
            // Deleted between the UID search and this fetch — skip it rather
            // than failing the whole poll.
            return;
        }

        return $this->flattenMessage($message, $folder, $uid);
    }

    /**
     * One already-fetched message as data-piping tokens.
     *
     * Split out so a search can flatten the messages its own query returned
     * instead of asking the server for each one again.
     *
     * @param \BitApps\PiPro\Deps\Webklex\PHPIMAP\Message $message
     *
     * @return array<string, mixed>
     */
    private function flattenMessage($message, string $folder, int $uid): array
    {
        $from = $message->get('from')->first();

        $attachmentNames = [];

        foreach ($message->getAttachments() as $attachment) {
            $attachmentNames[] = (string) $attachment->getName();
        }

        return [
            'uid'              => $uid,
            'message_id'       => (string) $message->get('message_id')->first(),
            'sender_email'     => $from ? (string) ($from->mail ?? '') : '',
            'sender_name'      => $from ? $this->displayName((string) ($from->personal ?? '')) : '',
            'to'               => $this->addressList($message->get('to')),
            'cc'               => $this->addressList($message->get('cc')),
            'reply_to'         => $this->addressList($message->get('reply_to')),
            'subject'          => (string) $message->get('subject')->first(),
            'body_text'        => (string) $message->getTextBody(),
            'body_html'        => $message->hasHTMLBody() ? (string) $message->getHTMLBody() : '',
            'received_date'    => $this->formatDate($message),
            'folder'           => $folder,
            'has_attachments'  => $message->hasAttachments(),
            'attachment_count' => \count($attachmentNames),
            'attachment_names' => $attachmentNames,
        ];
    }

    /**
     * Messages matching the filters, newest first, flattened for data piping.
     *
     * @param array{criteria?:string,rules?:string} $filters
     *
     * @return array<int, array<string, mixed>>
     */
    public function searchEmails(string $folder, array $filters, int $limit): array
    {
        // softFail() so one unparseable message does not sink the batch. The
        // messages are built inside get(), where the library records a parse
        // failure and then rethrows it as GetMessagesFailedException unless
        // soft failure is on; that happens before the loop body, so the catch
        // below could never reach it. Soft failure instead drops the offending
        // message from the collection, which is the behaviour wanted here.
        // Transport errors (a dropped socket, an auth error) still throw and
        // still abort: reporting a truncated result set as a complete one would
        // make the flow treat missing mail as "no matches".
        $query = $this->folder($folder)->query()->leaveUnread()->softFail();

        $this->applyFilters($query, $filters);

        $query->all()->setFetchOrder('desc')->limit($limit);

        // The query already carries every message it matched, so they are
        // flattened here rather than re-requested one UID at a time — that
        // cost one folder listing plus a fetch per message.
        $records = [];

        foreach ($query->get() as $message) {
            // Flattening parses the fetched body and attachments, so a
            // malformed MIME structure can still fail one message here.
            try {
                $records[] = $this->flattenMessage($message, $folder, (int) $message->uid);
            } catch (
                InvalidMessageDateException
                | MessageContentFetchingException
                | MessageFlagException
                | MessageSizeFetchingException
            ) {
                continue;
            }
        }

        // setFetchOrder('desc') picks the newest N, but the collection itself
        // comes back in server order, so sort explicitly for newest first.
        usort(
            $records,
            static function ($a, $b) {
                return $b['uid'] <=> $a['uid'];
            }
        );

        return $records;
    }

    /**
     * Flag a message as read.
     *
     * The library's flag and delete calls answer true or throw — a refusal
     * comes back as an exception, never as a falsy return — so none of the
     * mutating methods here test the result.
     */
    public function markRead(string $folder, int $uid): void
    {
        $this->message($folder, $uid)->setFlag('Seen');
    }

    /**
     * Clear the read flag on a message.
     */
    public function markUnread(string $folder, int $uid): void
    {
        $this->message($folder, $uid)->unsetFlag('Seen');
    }

    public function moveMessage(string $folder, int $uid, string $targetFolder): void
    {
        $message = $this->message($folder, $uid);

        try {
            if ($message->move($targetFolder) !== null) {
                return;
            }
        } catch (ImapServerErrorException) {
            // Servers such as Zoho refuse COPY/MOVE into special-use folders
            // like Drafts; fall through to the APPEND emulation below.
        } catch (MessageHeaderFetchingException) {
            // The server has already moved the message. The library then looks
            // for it in the target folder under a guessed UID, which misses on
            // label-based folders such as Gmail's [Gmail]/Important.
            return;
        }

        // Append first, delete after — the original survives if the append fails.
        $this->appendCopy($message, $targetFolder);

        // Flag only, never expunge: see deleteMessage() for why a bare EXPUNGE
        // would take every other \Deleted message in the folder with it.
        $message->delete(false);
    }

    public function copyMessage(string $folder, int $uid, string $targetFolder): void
    {
        $message = $this->message($folder, $uid);

        try {
            if ($message->copy($targetFolder) !== null) {
                return;
            }
        } catch (ImapServerErrorException) {
            // Servers such as Zoho refuse COPY/MOVE into special-use folders
            // like Drafts; fall through to the APPEND emulation below.
        } catch (MessageHeaderFetchingException) {
            // The server has already copied the message; see moveMessage().
            return;
        }

        $this->appendCopy($message, $targetFolder);
    }

    /**
     * Flag a message as deleted.
     *
     * Expunge is deliberately skipped. The library's default would issue a bare
     * EXPUNGE, which the IMAP protocol defines over the whole selected folder,
     * not one UID — it would also permanently destroy every other message the
     * user's mail client has flagged \Deleted but not yet expunged. The server
     * removes the message on its own next expunge, as it does for any client.
     */
    public function deleteMessage(string $folder, int $uid): void
    {
        $this->message($folder, $uid)->delete(false);
    }

    /**
     * Store a new message in a folder as an unsent draft.
     *
     * IMAP has no draft command, so the message is uploaded with APPEND and
     * flagged \Draft, which is how mail clients save drafts themselves. Nothing
     * is sent: a person reviews it and sends it from their own mail client.
     *
     * @param array{to:string[],cc:string[],subject:string,body:string,isHtml:bool,inReplyTo:string} $draft
     *
     * @return string the draft's Message-ID
     */
    public function saveDraft(string $folder, array $draft): string
    {
        $mailer = $this->buildDraft($draft);

        $this->folder($folder)->appendMessage($mailer->getSentMIMEMessage(), ['\\Draft', '\\Seen']);

        return $mailer->getLastMessageID();
    }

    public function disconnect(): void
    {
        try {
            if ($this->client && $this->client->isConnected()) {
                $this->client->disconnect();
            }
        } catch (Throwable $th) {
            // Nothing actionable — the socket is going away regardless.
        }

        $this->client = null;
    }

    /**
     * Normalizes the user's Custom Email Rules into a raw IMAP SEARCH string.
     *
     * Accepts the rule dropdown's selection (one tag per rule), raw IMAP syntax
     * (SUBJECT "invoice" UNSEEN), or the n8n-style JSON array people paste from
     * its docs (["SUBJECT", "invoice"]). CR/LF are stripped: the string is
     * spliced into the SEARCH command, and a newline would otherwise allow
     * injecting a second IMAP command.
     *
     * @param mixed $rules tags as an array, or a string from the mapped field
     */
    public static function normalizeCustomRules($rules): string
    {
        if (\is_array($rules)) {
            $tags = array_map(static fn ($rule) => \is_scalar($rule) ? (string) $rule : '', $rules);

            $rules = implode(' ', $tags);
        } elseif (!\is_scalar($rules)) {
            return '';
        }

        $rules = trim((string) preg_replace('/\s+/', ' ', $rules));

        if ($rules === '' || $rules[0] !== '[') {
            return $rules;
        }

        $decoded = json_decode($rules, true);

        if (!\is_array($decoded)) {
            return $rules;
        }

        $tokens = [];

        foreach ($decoded as $token) {
            if (!\is_scalar($token)) {
                continue;
            }

            $token = (string) $token;

            // Bare uppercase words are search keywords (UNSEEN, SUBJECT, ...);
            // anything else is a value and needs quoting.
            $tokens[] = preg_match('/^[A-Z]+$/', $token)
                ? $token
                : '"' . str_replace('"', '', $token) . '"';
        }

        return implode(' ', $tokens);
    }

    /**
     * Lazily connected client.
     *
     * @throws RuntimeException on unsupported PHP or a failed connection
     */
    private function client()
    {
        if ($this->client) {
            return $this->client;
        }

        if (!self::isSupported()) {
            throw new RuntimeException(esc_html(self::unsupportedMessage()));
        }

        $encryption = $this->config['encryption'] ?? 'ssl';

        // ClientManagerConfig keeps the vendored default config file — whose
        // unprefixed class references imposter cannot rewrite — from loading.
        $clientManager = new ClientManagerConfig();

        $this->client = $clientManager->make(
            [
                'host'          => $this->config['host'] ?? '',
                'port'          => (int) ($this->config['port'] ?? 993),
                'encryption'    => $encryption === 'none' ? false : $encryption,
                'validate_cert' => (bool) ($this->config['validateCert'] ?? true),
                'username'      => $this->config['username'] ?? '',
                'password'      => $this->config['password'] ?? '',
                // Pure-socket protocol — the php imap extension is not required.
                'protocol' => 'imap',
                'timeout'  => 30,
            ]
        );

        $this->client->connect();

        return $this->client;
    }

    /**
     * Applies the trigger's server-side search filters. All conditions are
     * combined with AND by the IMAP SEARCH command, so non-matching emails are
     * excluded before any headers are fetched.
     *
     * @param mixed                $query
     * @param array<string,string> $filters
     */
    private function applyFilters($query, array $filters): void
    {
        $criteria = $filters['criteria'] ?? 'all';

        if ($criteria === 'unread') {
            $query->where('UNSEEN');
        } elseif ($criteria === 'read') {
            $query->where('SEEN');
        }

        $rules = trim((string) ($filters['rules'] ?? ''));

        if ($rules !== '') {
            // "CUSTOM " passes the raw search criteria through unvalidated.
            $query->where('CUSTOM ' . $rules);
        }
    }

    private function folder(string $folder)
    {
        $resolved = $this->client()->getFolderByPath($folder);

        if (!$resolved) {
            throw new RuntimeException(esc_html(\sprintf('IMAP folder %s was not found.', $folder)));
        }

        return $resolved;
    }

    /**
     * Recreate the message in the target folder via APPEND.
     *
     * Some servers refuse the COPY/MOVE commands into special-use folders —
     * Zoho answers "NO [CANNOT] Invalid target folder" for Drafts and
     * Templates — but every folder accepts APPEND, so the message is uploaded
     * again with its original flags and date.
     *
     * @param \BitApps\PiPro\Deps\Webklex\PHPIMAP\Message $message
     */
    private function appendCopy($message, string $targetFolder): void
    {
        $raw = $message->getHeader()->raw . "\r\n\r\n" . $message->getRawBody();

        $flags = [];

        foreach ($message->getFlags()->all() as $flag) {
            // Recent cannot be set by a client, and carrying Deleted over
            // would create the copy pre-marked for expunge.
            if (!\in_array($flag, ['Recent', 'Deleted'], true)) {
                $flags[] = '\\' . $flag;
            }
        }

        $date = $message->getDate()->first();

        $this->folder($targetFolder)->appendMessage(
            $raw,
            $flags === [] ? null : $flags,
            $date instanceof Carbon ? $date : null
        );
    }

    /**
     * Build a draft's MIME message with the PHPMailer bundled in WordPress.
     *
     * The mailer is put in SMTP mode only so To and Subject are written into
     * the message itself; in mail() mode PHPMailer leaves them for mail() to
     * add. preSend() builds the message and sends nothing.
     *
     * @param array{to:string[],cc:string[],subject:string,body:string,isHtml:bool,inReplyTo:string} $draft
     */
    private function buildDraft(array $draft): PHPMailer
    {
        if (!class_exists(PHPMailer::class)) {
            include_once ABSPATH . WPINC . '/PHPMailer/PHPMailer.php';
            include_once ABSPATH . WPINC . '/PHPMailer/Exception.php';
        }

        $from = (string) ($this->config['username'] ?? '');

        if (!PHPMailer::validateAddress($from)) {
            throw new RuntimeException(esc_html__('The connection username must be an email address to be used as the draft sender.', 'bit-pi'));
        }

        $mailer = new PHPMailer(true);
        $mailer->isSMTP();
        $mailer->CharSet = PHPMailer::CHARSET_UTF8;
        // The Message-ID takes this domain; the default is the web server's hostname.
        $mailer->Hostname = substr(strrchr($from, '@'), 1);
        $mailer->setFrom($from, '', false);

        foreach ($draft['to'] as $address) {
            $mailer->addAddress($address);
        }

        foreach ($draft['cc'] as $address) {
            $mailer->addCC($address);
        }

        $mailer->Subject = $draft['subject'];
        $mailer->isHTML($draft['isHtml']);
        $mailer->Body = $draft['body'];

        if ($draft['isHtml']) {
            $mailer->AltBody = wp_strip_all_tags($draft['body']);
        }

        // Threads the draft under the email it answers in mail clients.
        if ($draft['inReplyTo'] !== '') {
            $mailer->addCustomHeader('In-Reply-To', $draft['inReplyTo']);
            $mailer->addCustomHeader('References', $draft['inReplyTo']);
        }

        $mailer->preSend();

        return $mailer;
    }

    /**
     * A single message resolved by UID, or a clear failure.
     *
     * The leaveUnread() call keeps the lookup itself from flagging the message
     * as seen; whatever flag change the caller intends is then explicit.
     *
     * @return \BitApps\PiPro\Deps\Webklex\PHPIMAP\Message
     */
    private function message(string $folder, int $uid)
    {
        $message = $this->findMessage($folder, $uid);

        if (!$message) {
            // The folder name is unquoted on purpose — esc_html() would turn
            // quotes into &quot; in the message the user reads.
            throw new RuntimeException(
                esc_html(
                    \sprintf(
                        'No message with UID %d in folder %s. Make sure the UID and folder belong to the same mailbox as this connection.',
                        $uid,
                        $folder
                    )
                )
            );
        }

        return $message;
    }

    /**
     * The message with this UID, or null when the folder does not hold it.
     *
     * The library's getMessageByUid() never returns null — a missing UID
     * surfaces as a MessageHeaderFetchingException ("no headers found")
     * instead, so the quirk is absorbed here and callers get a plain null.
     *
     * leaveUnread() sets FT_PEEK, so looking a message up never flags it as
     * seen; any flag change a caller wants is then explicit.
     *
     * @return null|\BitApps\PiPro\Deps\Webklex\PHPIMAP\Message
     */
    private function findMessage(string $folder, int $uid)
    {
        try {
            return $this->folder($folder)->query()->leaveUnread()->getMessageByUid($uid);
        } catch (MessageHeaderFetchingException) {
            return null;
        }
    }

    /**
     * Comma-separated email addresses from an address header (To, Cc, Reply-To).
     *
     * Bare addresses, not "Name <mail>" pairs — piping targets (CRM lookups,
     * send-to fields) want the address alone.
     *
     * @param mixed $attribute
     */
    private function addressList($attribute): string
    {
        if (!$attribute) {
            return '';
        }

        $addresses = [];

        foreach ($attribute->toArray() as $address) {
            $mail = \is_object($address) ? (string) ($address->mail ?? '') : (string) $address;

            if ($mail !== '') {
                $addresses[] = $mail;
            }
        }

        return implode(', ', $addresses);
    }

    /**
     * A quoted display name (`From: "Jane Doe" <..>`) keeps its quotes through
     * header decoding, which would leak them into the sender_name token.
     */
    private function displayName(string $personal): string
    {
        $personal = trim($personal);

        if (\strlen($personal) > 1 && $personal[0] === '"' && str_ends_with($personal, '"')) {
            $personal = trim(substr($personal, 1, -1));
        }

        return $personal;
    }

    private function formatDate($message): string
    {
        $date = $message->get('date')->first();

        if (!$date) {
            return '';
        }

        try {
            return $date->format('Y-m-d H:i:s');
        } catch (Throwable $th) {
            return (string) $date;
        }
    }
}
