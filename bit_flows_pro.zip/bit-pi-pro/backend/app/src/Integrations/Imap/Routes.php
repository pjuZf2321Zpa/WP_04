<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\PiPro\src\Integrations\Imap\ImapHelper;

Route::group(
    static function () {
        Route::post('imap/get-folders', [ImapHelper::class, 'getFolders']);
    }
)->middleware('nonce:admin');
