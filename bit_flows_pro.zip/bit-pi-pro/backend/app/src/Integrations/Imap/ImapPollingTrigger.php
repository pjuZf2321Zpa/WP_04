<?php

namespace BitApps\PiPro\src\Integrations\Imap;

// Prevent direct script access
if (!defined('ABSPATH')) {
    exit;
}

use BitApps\Pi\Config;
use BitApps\Pi\src\Abstracts\AbstractPollingTrigger;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use Throwable;

/**
 * Fires a flow once per newly received email.
 *
 * ScheduleTool diffs each poll against the previous poll's cached output, which
 * would force refetching the whole mailbox every poll to stay comparable. This
 * class instead keeps its own UID watermark per node: everything it returns is,
 * by construction, a message it has never emitted before, so a poll only ever
 * reads mail beyond the watermark. The downstream Polling diff then acts only
 * as a duplicate safety net.
 */
class ImapPollingTrigger extends AbstractPollingTrigger
{
    private const STATE_OPTION_PREFIX = 'imap_state_';

    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    /**
     * UIDs are unique and monotonic within a folder for a given UIDVALIDITY.
     * message_id is carried in the payload but is not reliable as a key — it can
     * be absent or duplicated.
     */
    public function getUniquePollingFieldName(): string
    {
        return 'uid';
    }

    public function poll(): array
    {
        if (!ImapService::isSupported()) {
            return $this->error(ImapService::unsupportedMessage());
        }

        $configs = $this->nodeInfoProvider->getFieldMapConfigs();

        $connectionId = $this->config($configs, 'connection-id');
        $folder = $this->config($configs, 'folder', 'INBOX');
        $filters = $this->searchFilters($configs);

        if (!$connectionId) {
            return $this->error(__('No IMAP connection selected.', 'bit-pi'));
        }

        $service = null;

        try {
            $service = ImapService::fromConnection($connectionId);

            // The Test Run button must always show sample tokens, even when the
            // cron watermark says nothing is new. Pure read, no state writes, so
            // scheduled polling is unaffected.
            if ($this->isTestRun()) {
                $sampleUids = $service->fetchNewUids($folder, null, ImapService::SEED_LIMIT, $filters);

                return $this->success($this->fetchRecords($service, $folder, $sampleUids), $folder, null);
            }

            $state = $this->readState();
            $validity = $service->uidValidity($folder);

            // A different folder or a reset UIDVALIDITY makes the stored
            // watermark meaningless — start over instead of replaying old mail.
            $isFirstRun = $state === null
                || ($state['folder'] ?? '') !== $folder
                || ($validity !== null && ($state['validity'] ?? null) !== $validity);

            $afterUid = $isFirstRun ? null : (int) $state['uid'];
            $limit = $isFirstRun ? ImapService::SEED_LIMIT : ImapService::POLL_LIMIT;

            $uids = $service->fetchNewUids($folder, $afterUid, $limit, $filters);

            if (empty($uids)) {
                $this->writeState($folder, $afterUid, $validity);

                return $this->success([], $folder, $afterUid);
            }

            $records = $this->fetchRecords($service, $folder, $uids);

            $this->writeState($folder, max($uids), $validity);

            return $this->success($records, $folder, $afterUid);
        } catch (Throwable $th) {
            // Returning an empty output makes ScheduleTool bail before it touches
            // the poll cache, so a transient outage cannot corrupt the diff state.
            return $this->error($th->getMessage());
        } finally {
            if ($service) {
                $service->disconnect();
            }
        }
    }

    /**
     * Server-side search filters: the Criteria select lives in configs, the
     * Custom Email Rules mixInput in the field-map data payload.
     *
     * @param array<string, mixed> $configs
     *
     * @return array{criteria:string,rules:string}
     */
    private function searchFilters(array $configs): array
    {
        $data = $this->nodeInfoProvider->getFieldMapData();

        return [
            'criteria' => $this->config($configs, 'criteria', 'all'),
            'rules'    => ImapService::normalizeCustomRules((string) ($data['custom_rules'] ?? '')),
        ];
    }

    /**
     * Whether this poll was invoked by the Test Run button (admin ajax) rather
     * than a scheduled cron run.
     */
    private function isTestRun(): bool
    {
        $action = isset($_REQUEST['action']) ? sanitize_text_field(wp_unslash($_REQUEST['action'])) : '';

        return $action === Config::VAR_PREFIX . 'test-run-node';
    }

    /**
     * Fetch the given UIDs, skipping any message that can no longer be read.
     *
     * @param array<int, int> $uids
     *
     * @return array<int, array<string, mixed>>
     */
    private function fetchRecords(ImapService $service, string $folder, array $uids): array
    {
        $records = [];

        foreach ($uids as $uid) {
            $record = $service->fetchMessage($folder, $uid);

            if ($record !== null) {
                $records[] = $record;
            }
        }

        return $records;
    }

    /**
     * A config value may arrive as ['value' => x] from a select or as a bare
     * scalar once a mix input has been resolved.
     *
     * @param array<string, mixed> $configs
     */
    private function config(array $configs, string $key, string $fallback = ''): string
    {
        $value = $configs[$key]['value'] ?? $configs[$key] ?? $fallback;

        if (\is_array($value) || \is_object($value)) {
            return $fallback;
        }

        $value = trim((string) $value);

        return $value === '' ? $fallback : $value;
    }

    /**
     * The stored UID watermark, or null before the first poll has run.
     *
     * @return null|array{uid:int,validity:null|int,folder:string}
     */
    private function readState()
    {
        $state = Config::getOption(self::STATE_OPTION_PREFIX . $this->nodeInfoProvider->getNodeId());

        if (!\is_array($state) || !isset($state['uid'])) {
            return;
        }

        return $state;
    }

    /**
     * Persist the UID watermark the next poll resumes from.
     *
     * @param null|int $uid
     * @param null|int $validity
     */
    private function writeState(string $folder, $uid, $validity): void
    {
        if ($uid === null) {
            return;
        }

        Config::updateOption(
            self::STATE_OPTION_PREFIX . $this->nodeInfoProvider->getNodeId(),
            [
                'uid'      => (int) $uid,
                'validity' => $validity,
                'folder'   => $folder,
            ],
            false
        );
    }

    /**
     * The poll result handed back to the flow engine.
     *
     * @param array<int, array<string, mixed>> $records
     * @param null|int                         $afterUid
     */
    private function success(array $records, string $folder, $afterUid): array
    {
        return [
            'status' => 'success',
            'output' => $records,
            'input'  => ['folder' => $folder, 'afterUid' => $afterUid],
        ];
    }

    private function error(string $message): array
    {
        return [
            'status' => 'error',
            'output' => [],
            'input'  => ['error' => true, 'message' => $message],
        ];
    }
}
