<?php

namespace BitApps\PiPro\src\Integrations\Imap;

// Prevent direct script access
if (!defined('ABSPATH')) {
    exit;
}

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Request\Request;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Response;
use Throwable;

class ImapHelper
{
    /**
     * Folder paths for the folder dropdowns.
     *
     * Also serves as the connection check: fetching the list opens a real IMAP
     * session, so a bad host or password surfaces here as the error response
     * the frontend renders on the folder select.
     */
    public static function getFolders(Request $request): Response
    {
        $validated = $request->validate(
            [
                'connectionId' => ['required'],
            ]
        );

        if (!ImapService::isSupported()) {
            return Response::error(['message' => ImapService::unsupportedMessage()]);
        }

        try {
            $service = ImapService::fromConnection($validated['connectionId']);

            return Response::success($service->listFolders());
        } catch (Throwable $th) {
            return Response::error(['message' => $th->getMessage()]);
        }
    }
}
