<?php

namespace BitApps\PiPro\src\Integrations\Imap;

// Prevent direct script access
if (!defined('ABSPATH')) {
    exit;
}

use BitApps\PiPro\Deps\Webklex\PHPIMAP\Config;
use BitApps\PiPro\Deps\Webklex\PHPIMAP\Decoder\AttachmentDecoder;
use BitApps\PiPro\Deps\Webklex\PHPIMAP\Decoder\DecoderInterface;
use BitApps\PiPro\Deps\Webklex\PHPIMAP\Decoder\HeaderDecoder;
use BitApps\PiPro\Deps\Webklex\PHPIMAP\Decoder\MessageDecoder;
use BitApps\PiPro\Deps\Webklex\PHPIMAP\Exceptions\DecoderNotFoundException;

/**
 * Config that never loads the vendored default config file.
 *
 * The stock Config::make() requires vendor/.../config/imap.php, whose inline
 * fully-qualified class names survive imposter prefixing and fatal at include
 * time. This subclass builds the same result from ImapConfig::getConfig()
 * instead, and overrides getDecoder() because the stock fallback list names
 * the decoder classes by unprefixed FQCN as well.
 */
class CustomConfig extends Config
{
    /**
     * Build a config from the plugin-owned defaults instead of the vendored file.
     *
     * @param array|string $config
     */
    public static function make($config = []): Config
    {
        if (\is_array($config) === false) {
            $config = include $config;
        }

        $imapConfig = ImapConfig::getConfig();

        if (!empty($config)) {
            $config = self::arrayMergeRecursiveDistinct($imapConfig, $config);
        } else {
            $config = $imapConfig;
        }

        if (\is_array($config) && isset($config['default'], $config['accounts']) && $config['default']) {
            $defaultConfig = $imapConfig['accounts']['default'];

            if (isset($config['accounts'][$config['default']])) {
                $defaultConfig = array_merge($defaultConfig, $config['accounts'][$config['default']]);
            }

            if (\is_array($config['accounts'])) {
                foreach ($config['accounts'] as $accountKey => $account) {
                    $config['accounts'][$accountKey] = array_merge($defaultConfig, $account);
                }
            }
        }

        return new self($config);
    }

    /**
     * Resolve a decoder without falling back to the stock unprefixed FQCN list.
     *
     * @throws DecoderNotFoundException when no decoder is configured for the name
     */
    public function getDecoder(string $name): DecoderInterface
    {
        $defaultDecoders = $this->get(
            'decoding.decoder',
            [
                'header'     => HeaderDecoder::class,
                'message'    => MessageDecoder::class,
                'attachment' => AttachmentDecoder::class,
            ]
        );

        $options = $this->get(
            'decoding.options',
            [
                'header'     => 'utf-8',
                'message'    => 'utf-8',
                'attachment' => 'utf-8',
            ]
        );

        if (isset($defaultDecoders[$name]) && class_exists($defaultDecoders[$name])) {
            return new $defaultDecoders[$name]($options);
        }

        throw new DecoderNotFoundException();
    }

    /**
     * Merge configs recursively, replacing plain lists instead of unioning them.
     */
    private static function arrayMergeRecursiveDistinct(): array
    {
        $arrays = \func_get_args();
        $base = array_shift($arrays);

        // From https://stackoverflow.com/a/173479
        $isAssoc = static function (array $arr) {
            if ($arr === []) {
                return false;
            }

            return array_keys($arr) !== range(0, \count($arr) - 1);
        };

        if (!\is_array($base)) {
            $base = empty($base) ? [] : [$base];
        }

        foreach ($arrays as $append) {
            if (!\is_array($append)) {
                $append = [$append];
            }

            foreach ($append as $key => $value) {
                if (!\array_key_exists($key, $base) && !is_numeric($key)) {
                    $base[$key] = $value;

                    continue;
                }

                if ((\is_array($value) && $isAssoc($value)) || (\is_array($base[$key]) && $isAssoc($base[$key]))) {
                    // Merging list values recursively would union them — e.g.
                    // dispositions ['attachment'] over ['attachment', 'inline']
                    // must replace the default, not extend it.
                    $base[$key] = self::arrayMergeRecursiveDistinct($base[$key], $value);
                } elseif (is_numeric($key)) {
                    if (!\in_array($value, $base)) {
                        $base[] = $value;
                    }
                } else {
                    $base[$key] = $value;
                }
            }
        }

        return $base;
    }
}
