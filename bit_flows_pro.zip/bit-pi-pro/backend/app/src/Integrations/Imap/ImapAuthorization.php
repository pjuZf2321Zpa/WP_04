<?php

namespace BitApps\PiPro\src\Integrations\Imap;

// Prevent direct script access
if (!defined('ABSPATH')) {
    exit;
}

use BitApps\Pi\src\Authorization\AbstractBaseAuthorization;

/**
 * Resolves IMAP credentials from a stored connection.
 *
 * The password lives in the encrypted `value` key; everything else is kept in
 * `auth_details.extraData`, which is never encrypted.
 */
class ImapAuthorization extends AbstractBaseAuthorization
{
    private const DEFAULT_PORT = 993;

    /**
     * IMAP hosts of the known email providers.
     *
     * Applied server-side whenever the stored connection names one of these
     * providers, so the client only supplies credentials and a tampered host
     * value in extraData cannot redirect a preset connection elsewhere.
     * Every preset connects with SSL on port 993 with certificate validation
     * — the settings all major providers share. Hosts verified against
     * provider documentation and a live 993/TLS handshake. 'other' is
     * intentionally absent — it means manual settings.
     *
     * Hotmail and Outlook.com are separate labels for the same Microsoft
     * server; both are kept so users find their own mailbox by name.
     */
    private const PROVIDER_HOSTS = [
        'gmail'    => 'imap.gmail.com',
        'hotmail'  => 'outlook.office365.com',
        'outlook'  => 'outlook.office365.com',
        'seznam'   => 'imap.seznam.cz',
        'yandex'   => 'imap.yandex.com',
        'zoho'     => 'imap.zoho.com',
        'zoho-org' => 'imappro.zoho.com',
    ];

    /**
     * The decrypted IMAP credentials for the stored connection.
     *
     * @return array{error:bool,message:string}|array{host:string,port:int,encryption:string,username:string,password:string,validateCert:bool}
     */
    public function getAccessToken()
    {
        if (!$this->getConnection()) {
            return [
                'error'   => true,
                'message' => 'Connection not found',
            ];
        }

        $authDetails = $this->getAuthDetails();

        if (!$authDetails) {
            return [
                'error'   => true,
                'message' => 'Connection credentials are missing',
            ];
        }

        $extraData = (object) ($authDetails->extraData ?? []);

        // Connections saved before provider presets existed have no provider
        // key and fall through to their manually entered server settings.
        $presetHost = self::PROVIDER_HOSTS[$extraData->provider ?? ''] ?? null;

        $server = $presetHost !== null ? [
            'host'         => $presetHost,
            'port'         => 993,
            'encryption'   => 'ssl',
            'validateCert' => true,
        ] : [
            'host'         => $extraData->host ?? '',
            'port'         => (int) ($extraData->port ?? self::DEFAULT_PORT),
            'encryption'   => $extraData->encryption ?? 'ssl',
            'validateCert' => !isset($extraData->validateCert) || (bool) $extraData->validateCert,
        ];

        return $server + [
            'username' => $extraData->username ?? '',
            'password' => $authDetails->value ?? '',
        ];
    }
}
