<?php

namespace BitApps\PiPro\src\Integrations\Imap;

// Prevent direct script access
if (!defined('ABSPATH')) {
    exit;
}

use BitApps\PiPro\Deps\Webklex\PHPIMAP\Decoder\AttachmentDecoder;
use BitApps\PiPro\Deps\Webklex\PHPIMAP\Decoder\HeaderDecoder;
use BitApps\PiPro\Deps\Webklex\PHPIMAP\Decoder\MessageDecoder;
use BitApps\PiPro\Deps\Webklex\PHPIMAP\Events\FlagDeletedEvent;
use BitApps\PiPro\Deps\Webklex\PHPIMAP\Events\FlagNewEvent;
use BitApps\PiPro\Deps\Webklex\PHPIMAP\Events\FolderDeletedEvent;
use BitApps\PiPro\Deps\Webklex\PHPIMAP\Events\FolderMovedEvent;
use BitApps\PiPro\Deps\Webklex\PHPIMAP\Events\FolderNewEvent;
use BitApps\PiPro\Deps\Webklex\PHPIMAP\Events\MessageCopiedEvent;
use BitApps\PiPro\Deps\Webklex\PHPIMAP\Events\MessageDeletedEvent;
use BitApps\PiPro\Deps\Webklex\PHPIMAP\Events\MessageMovedEvent;
use BitApps\PiPro\Deps\Webklex\PHPIMAP\Events\MessageNewEvent;
use BitApps\PiPro\Deps\Webklex\PHPIMAP\Events\MessageRestoredEvent;
use BitApps\PiPro\Deps\Webklex\PHPIMAP\IMAP;
use BitApps\PiPro\Deps\Webklex\PHPIMAP\Support\Masks\AttachmentMask;
use BitApps\PiPro\Deps\Webklex\PHPIMAP\Support\Masks\MessageMask;

/**
 * Plugin-owned copy of webklex/php-imap's default configuration.
 *
 * The vendored default (vendor/webklex/php-imap/src/config/imap.php) refers to
 * library classes by inline fully-qualified name, which the imposter prefixer
 * does not rewrite, so including that file fatals with "Class not found" once
 * the vendor namespaces are prefixed. This copy expresses the same defaults
 * through use-imports, which imposter handles, so no vendor patching is needed.
 *
 * Values mirror webklex/php-imap 6.2 — keep them in sync when the package is
 * upgraded.
 */
class ImapConfig
{
    /**
     * The default configuration, equivalent to the vendored config/imap.php.
     */
    public static function getConfig(): array
    {
        return [
            'date_format' => 'd-M-Y',

            // The account identifier used for any missing account parameters.
            'default' => 'default',

            'accounts' => [
                'default' => [
                    'host'           => 'localhost',
                    'port'           => 993,
                    'protocol'       => 'imap',
                    'encryption'     => 'ssl',
                    'validate_cert'  => true,
                    'username'       => 'root@example.com',
                    'password'       => '',
                    'authentication' => null,
                    'proxy'          => [
                        'socket'          => null,
                        'request_fulluri' => false,
                        'username'        => null,
                        'password'        => null,
                    ],
                    'timeout'    => 30,
                    'extensions' => [],
                ],
            ],

            'options' => [
                'delimiter'              => '/',
                'fetch'                  => IMAP::FT_PEEK,
                'sequence'               => IMAP::ST_UID,
                'fetch_body'             => true,
                'fetch_flags'            => true,
                'soft_fail'              => false,
                'rfc822'                 => true,
                'debug'                  => false,
                'unescaped_search_dates' => false,
                'uid_cache'              => true,
                // A message with an unparseable Date header (real servers do
                // deliver these) falls back to the epoch instead of aborting
                // the whole fetch with InvalidMessageDateException.
                'fallback_date' => '1970-01-01 00:00:00',
                'boundary'      => '/boundary=(.*?(?=;)|(.*))/i',
                'message_key'            => 'list',
                'fetch_order'            => 'asc',
                'dispositions'           => ['attachment', 'inline'],
                'common_folders'         => [
                    'root'  => 'INBOX',
                    'junk'  => 'INBOX/Junk',
                    'draft' => 'INBOX/Drafts',
                    'sent'  => 'INBOX/Sent',
                    'trash' => 'INBOX/Trash',
                ],
                'open' => [],
            ],

            'decoding' => [
                'options' => [
                    'header'     => 'utf-8',
                    'message'    => 'utf-8',
                    'attachment' => 'utf-8',
                ],
                'decoder' => [
                    'header'     => HeaderDecoder::class,
                    'message'    => MessageDecoder::class,
                    'attachment' => AttachmentDecoder::class,
                ],
            ],

            'flags' => ['recent', 'flagged', 'answered', 'deleted', 'seen', 'draft'],

            'events' => [
                'message' => [
                    'new'      => MessageNewEvent::class,
                    'moved'    => MessageMovedEvent::class,
                    'copied'   => MessageCopiedEvent::class,
                    'deleted'  => MessageDeletedEvent::class,
                    'restored' => MessageRestoredEvent::class,
                ],
                'folder' => [
                    'new'     => FolderNewEvent::class,
                    'moved'   => FolderMovedEvent::class,
                    'deleted' => FolderDeletedEvent::class,
                ],
                'flag' => [
                    'new'     => FlagNewEvent::class,
                    'deleted' => FlagDeletedEvent::class,
                ],
            ],

            'masks' => [
                'message'    => MessageMask::class,
                'attachment' => AttachmentMask::class,
            ],
        ];
    }
}
