<?php

namespace BitApps\PiPro\src\Integrations\ModernCart;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!defined('ABSPATH')) {
    exit;
}

class ModernCartHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'cartUpdated' => [
                'hook'          => 'woocommerce_cart_updated',
                'callback'      => [ModernCartTrigger::class, 'cartUpdated'],
                'accepted_args' => 0,
            ],
        ];
    }
}
