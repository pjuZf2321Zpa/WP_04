<?php

namespace BitApps\PiPro\src\Integrations\ModernCart\helper;

use BitApps\PiPro\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Request\Request;
use ModernCart\Inc\Cart;
use ModernCart\Inc\Order_Tracking;
use WC_Product;

if (!defined('ABSPATH')) {
    exit;
}

final class ModernCartHelper
{
    public static function isPluginInstalled()
    {
        return defined('MODERNCART_VER') || class_exists('\ModernCart\Plugin_Loader');
    }

    public static function isWooCommerceAvailable()
    {
        if (!\function_exists('WC')) {
            return false;
        }

        $wooCommerce = WC();

        if ($wooCommerce && empty($wooCommerce->cart) && \function_exists('wc_load_cart')) {
            wc_load_cart();
        }

        return $wooCommerce && !empty($wooCommerce->cart);
    }

    public static function getProducts()
    {
        if (!\function_exists('wc_get_products')) {
            return [];
        }

        $products = wc_get_products(
            [
                'limit'  => -1,
                'return' => 'objects',
                'status' => ['publish', 'private'],
            ]
        );

        return array_map([self::class, 'getProductData'], $products);
    }

    public static function allProducts()
    {
        if (!\function_exists('wc_get_products')) {
            return [];
        }

        $productIds = wc_get_products(
            [
                'limit'  => -1,
                'return' => 'ids',
                'status' => ['publish', 'private'],
            ]
        );
        $options = [];

        foreach ($productIds as $productId) {
            $productId = (int) $productId;

            if (!$productId) {
                continue;
            }

            $productName = get_post_field('post_title', $productId);

            $options[] = (object) [
                'label' => $productName ?: '#' . $productId,
                'value' => $productId,
            ];
        }

        return $options;
    }

    public static function allProductVariations(Request $request)
    {
        $validatedData = $request->validate(
            [
                'productId' => ['required', 'integer'],
            ]
        );

        $product = \function_exists('wc_get_product') ? wc_get_product((int) $validatedData['productId']) : null;

        if (!$product instanceof WC_Product || !method_exists($product, 'get_children')) {
            return [];
        }

        $options = [];

        foreach ($product->get_children() as $variationId) {
            $variation = wc_get_product((int) $variationId);

            if (!$variation instanceof WC_Product) {
                continue;
            }

            $options[] = (object) [
                'label' => self::variationLabel($variation),
                'value' => $variation->get_id(),
            ];
        }

        return $options;
    }

    public static function allCartItems()
    {
        if (!self::isWooCommerceAvailable()) {
            return [];
        }

        $cart = WC()->cart;
        $options = [];

        foreach ($cart->get_cart() as $cartItemKey => $cartItem) {
            $product = $cartItem['data'] ?? null;
            $productName = $product instanceof WC_Product ? $product->get_name() : '';

            $options[] = (object) [
                'label' => ($productName ?: '#' . ($cartItem['product_id'] ?? $cartItemKey)) . ' (' . $cartItemKey . ')',
                'value' => (string) $cartItemKey,
            ];
        }

        return $options;
    }

    public static function getProductData($product)
    {
        if (is_numeric($product)) {
            $product = \function_exists('wc_get_product') ? wc_get_product((int) $product) : null;
        }

        if (!$product instanceof WC_Product) {
            return [];
        }

        return [
            'id'             => $product->get_id(),
            'name'           => $product->get_name(),
            'slug'           => $product->get_slug(),
            'type'           => $product->get_type(),
            'status'         => $product->get_status(),
            'sku'            => $product->get_sku(),
            'price'          => $product->get_price(),
            'regular_price'  => $product->get_regular_price(),
            'sale_price'     => $product->get_sale_price(),
            'stock_status'   => $product->get_stock_status(),
            'stock_quantity' => $product->get_stock_quantity(),
            'permalink'      => $product->get_permalink(),
        ];
    }

    public static function getCartItems($cart = null)
    {
        if (!$cart && !self::isWooCommerceAvailable()) {
            return [];
        }

        $cart = $cart ?: WC()->cart;
        $items = [];

        foreach ($cart->get_cart() as $cartItemKey => $cartItem) {
            $items[] = self::getCartItemData((string) $cartItemKey, $cartItem);
        }

        return $items;
    }

    public static function getCartItemData($cartItemKey, $cartItem)
    {
        $product = $cartItem['data'] ?? null;

        return [
            'cart_item_key' => $cartItemKey,
            'product_id'    => isset($cartItem['product_id']) ? (int) $cartItem['product_id'] : 0,
            'variation_id'  => isset($cartItem['variation_id']) ? (int) $cartItem['variation_id'] : 0,
            'quantity'      => isset($cartItem['quantity']) ? (int) $cartItem['quantity'] : 0,
            'line_subtotal' => isset($cartItem['line_subtotal']) ? (float) $cartItem['line_subtotal'] : 0,
            'line_total'    => isset($cartItem['line_total']) ? (float) $cartItem['line_total'] : 0,
            'product_name'  => $product instanceof WC_Product ? $product->get_name() : '',
            'product'       => self::getProductData($product),
        ];
    }

    public static function getCartTotals($cart = null)
    {
        if (!$cart && !self::isWooCommerceAvailable()) {
            return [];
        }

        $cart = $cart ?: WC()->cart;

        return [
            'subtotal'        => (float) $cart->get_displayed_subtotal(),
            'discount_total'  => (float) $cart->get_discount_total(),
            'shipping_total'  => (float) $cart->get_shipping_total(),
            'tax_total'       => (float) $cart->get_taxes_total(false, false),
            'grand_total'     => (float) $cart->get_total('number'),
            'currency'        => get_woocommerce_currency(),
            'currency_symbol' => get_woocommerce_currency_symbol(),
        ];
    }

    public static function freeShippingAmount()
    {
        if (!class_exists('\ModernCart\Inc\Cart')) {
            return 0;
        }

        return Cart::get_instance()->get_free_shipping_amount();
    }

    public static function decodeJson($value, $fallback = [])
    {
        if (\is_array($value)) {
            return $value;
        }

        if (!\is_string($value) || trim($value) === '') {
            return $fallback;
        }

        $decoded = JSON::maybeDecode(wp_unslash($value), true);

        return \is_array($decoded) ? $decoded : $fallback;
    }

    public static function flagCartSession()
    {
        if (class_exists('\ModernCart\Inc\Order_Tracking')) {
            Order_Tracking::flag_session();
        }
    }

    private static function variationLabel(WC_Product $variation)
    {
        if (method_exists($variation, 'get_formatted_name')) {
            return wp_strip_all_tags($variation->get_formatted_name());
        }

        return $variation->get_name() ?: '#' . $variation->get_id();
    }
}
