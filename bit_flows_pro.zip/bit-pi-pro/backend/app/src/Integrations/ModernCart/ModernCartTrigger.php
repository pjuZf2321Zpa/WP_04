<?php

namespace BitApps\PiPro\src\Integrations\ModernCart;

use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\ModernCart\helper\ModernCartHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class ModernCartTrigger
{
    public static function cartUpdated()
    {
        if (!ModernCartHelper::isPluginInstalled()) {
            return;
        }

        $flows = FlowService::exists('modernCart', 'cartUpdated');

        if (!$flows || !ModernCartHelper::isWooCommerceAvailable()) {
            return;
        }

        $data = [
            'items'  => ModernCartHelper::getCartItems(),
            'totals' => ModernCartHelper::getCartTotals(),
        ];

        IntegrationHelper::handleFlowForForm($flows, $data);
    }
}
