<?php

namespace BitApps\PiPro\src\Integrations\ModernCart;

use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\ModernCart\helper\ModernCartHelper;
use ModernCart\Inc\Helper;

if (!defined('ABSPATH')) {
    exit;
}

final class ModernCartService
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function getCartSummary()
    {
        if (!ModernCartHelper::isWooCommerceAvailable()) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('WooCommerce cart is not available.', 'bit-pi'),
            ];
        }

        $cart = WC()->cart;
        $subtotal = (float) $cart->get_displayed_subtotal();
        $discountTotal = (float) $cart->get_discount_total();
        $freeShippingAmount = (float) ModernCartHelper::freeShippingAmount();
        $cartTotalForShipping = max(0, $subtotal - $discountTotal);

        $response = [
            'is_empty'        => $cart->is_empty(),
            'item_count'      => class_exists('\ModernCart\Inc\Helper') ? Helper::get_cart_count() : $cart->get_cart_contents_count(),
            'items'           => ModernCartHelper::getCartItems($cart),
            'totals'          => ModernCartHelper::getCartTotals($cart),
            'applied_coupons' => array_values($cart->get_applied_coupons()),
            'free_shipping'   => [
                'threshold'   => $freeShippingAmount,
                'cart_total'  => $cartTotalForShipping,
                'remaining'   => max(0, $freeShippingAmount - $cartTotalForShipping),
                'percent'     => $freeShippingAmount > 0 ? (int) min(100, round(($cartTotalForShipping / $freeShippingAmount) * 100)) : 0,
                'is_achieved' => $freeShippingAmount > 0 && $cartTotalForShipping >= $freeShippingAmount,
            ],
        ];

        return [
            'status_code' => 200,
            'payload'     => [],
            'response'    => $response,
        ];
    }

    public function getCartItems()
    {
        if (!ModernCartHelper::isWooCommerceAvailable()) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('WooCommerce cart is not available.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => [],
            'response'    => ModernCartHelper::getCartItems(),
        ];
    }

    public function getProduct()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, ['product_id' => ['required', 'integer']]);
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $product = ModernCartHelper::getProductData((int) $fieldMappings['product_id']);

        if (empty($product)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Product not found.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => $product,
        ];
    }

    public function getProducts()
    {
        return [
            'status_code' => 200,
            'payload'     => [],
            'response'    => ModernCartHelper::getProducts(),
        ];
    }

    public function addProductToCart()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        if (!ModernCartHelper::isWooCommerceAvailable()) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('WooCommerce cart is not available.', 'bit-pi'),
            ];
        }

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, ['product_id' => ['required', 'integer']]);
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $productId = (int) $fieldMappings['product_id'];
        $quantity = isset($fieldMappings['quantity']) ? $this->toPositiveInt($fieldMappings['quantity']) : 1;
        $variationId = isset($fieldMappings['variation_id']) ? $this->toInt($fieldMappings['variation_id']) : 0;
        $variations = ModernCartHelper::decodeJson($fieldMappings['variations_json'] ?? '');
        $cart = WC()->cart;

        $cartItemKey = $cart->add_to_cart($productId, $quantity, $variationId, $variations);

        if (!$cartItemKey) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Product could not be added to the cart.', 'bit-pi'),
            ];
        }

        ModernCartHelper::flagCartSession();
        $cart->calculate_totals();

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'cart_item_key' => $cartItemKey,
                'product'       => ModernCartHelper::getProductData($productId),
                'cart'          => [
                    'items'  => ModernCartHelper::getCartItems($cart),
                    'totals' => ModernCartHelper::getCartTotals($cart),
                ],
            ],
        ];
    }

    public function updateCartQuantity()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        if (!ModernCartHelper::isWooCommerceAvailable()) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('WooCommerce cart is not available.', 'bit-pi'),
            ];
        }

        $validationErrors = IntegrationHelper::validateFieldMap(
            $fieldMappings,
            [
                'cart_item_key' => ['required', 'string'],
                'quantity'      => ['required', 'integer'],
            ]
        );
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $cartItemKey = sanitize_text_field($fieldMappings['cart_item_key']);
        $quantity = max(0, $this->toInt($fieldMappings['quantity']));
        $cart = WC()->cart;

        $cartItem = $cart->get_cart_item($cartItemKey);

        if (!$cartItem) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Cart item not found.', 'bit-pi'),
            ];
        }

        $currentQuantity = (int) ($cartItem['quantity'] ?? 0);

        if ($currentQuantity === $quantity) {
            return [
                'status_code' => 200,
                'payload'     => $fieldMappings,
                'response'    => [
                    'cart_item_key' => $cartItemKey,
                    'quantity'      => $quantity,
                    'items'         => ModernCartHelper::getCartItems($cart),
                    'totals'        => ModernCartHelper::getCartTotals($cart),
                ],
            ];
        }

        $result = $quantity === 0 ? $cart->remove_cart_item($cartItemKey) : $cart->set_quantity($cartItemKey, $quantity);

        if (!$result) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Cart quantity could not be updated.', 'bit-pi'),
            ];
        }

        $cart->calculate_totals();
        ModernCartHelper::flagCartSession();

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'cart_item_key' => $cartItemKey,
                'quantity'      => $quantity,
                'items'         => ModernCartHelper::getCartItems($cart),
                'totals'        => ModernCartHelper::getCartTotals($cart),
            ],
        ];
    }

    public function removeProductFromCart()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        if (!ModernCartHelper::isWooCommerceAvailable()) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('WooCommerce cart is not available.', 'bit-pi'),
            ];
        }

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, ['cart_item_key' => ['required', 'string']]);
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $cartItemKey = sanitize_text_field($fieldMappings['cart_item_key']);
        $cart = WC()->cart;

        if (!$cart->get_cart_item($cartItemKey)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Cart item not found.', 'bit-pi'),
            ];
        }

        $removed = $cart->remove_cart_item($cartItemKey);

        if (!$removed) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Cart item could not be removed.', 'bit-pi'),
            ];
        }

        $cart->calculate_totals();
        ModernCartHelper::flagCartSession();

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'cart_item_key' => $cartItemKey,
                'items'         => ModernCartHelper::getCartItems($cart),
                'totals'        => ModernCartHelper::getCartTotals($cart),
            ],
        ];
    }

    private function toInt($value, $default = 0)
    {
        return is_numeric($value) ? (int) $value : $default;
    }

    private function toPositiveInt($value, $default = 1)
    {
        return max(1, $this->toInt($value, $default));
    }
}
