<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\PiPro\src\Integrations\ModernCart\helper\ModernCartHelper;

Route::group(
    function () {
        Route::get('get_modern_cart_products', [ModernCartHelper::class, 'allProducts']);
        Route::get('get_modern_cart_product_variations', [ModernCartHelper::class, 'allProductVariations']);
        Route::get('get_modern_cart_cart_items', [ModernCartHelper::class, 'allCartItems']);
    }
)->middleware('nonce:admin');
