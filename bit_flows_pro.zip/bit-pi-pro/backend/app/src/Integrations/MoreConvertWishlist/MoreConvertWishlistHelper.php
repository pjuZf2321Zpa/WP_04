<?php

namespace BitApps\PiPro\src\Integrations\MoreConvertWishlist;

use BitApps\Pi\Helpers\Utility;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Response;
use WLFMC_Wishlist_Factory;

if (!defined('ABSPATH')) {
    exit;
}

final class MoreConvertWishlistHelper
{
    /**
     * Check whether MoreConvert Wishlist plugin is active.
     */
    public static function isPluginInstalled(): bool
    {
        return class_exists('WLFMC') && \function_exists('WLFMC') && class_exists('WLFMC_Wishlist_Factory');
    }

    /**
     * Convert object/array to plain array safely.
     *
     * @param mixed $data
     *
     * @return array
     */
    public static function prepareData($data)
    {
        if (empty($data)) {
            return [];
        }

        if (\is_array($data)) {
            return $data;
        }

        if (\is_object($data) && method_exists($data, 'get_data')) {
            $base = $data->get_data();
            if (method_exists($data, 'get_id')) {
                $base['id'] = $data->get_id();
            }

            return $base;
        }

        if (\is_object($data) && method_exists($data, 'toArray')) {
            return $data->toArray();
        }

        return (array) Utility::jsonEncodeDecode($data);
    }

    /**
     * Build a serialised wishlist item payload.
     *
     * @param mixed $item
     */
    public static function prepareWishlistItem($item): array
    {
        if (empty($item)) {
            return [];
        }

        $data = self::prepareData($item);

        if (\is_object($item) && method_exists($item, 'get_product_id')) {
            $data['product_id'] = $item->get_product_id();
        }

        if (\is_object($item) && method_exists($item, 'get_wishlist_id')) {
            $data['wishlist_id'] = $item->get_wishlist_id();
        }

        if (\is_object($item) && method_exists($item, 'get_quantity')) {
            $data['quantity'] = $item->get_quantity();
        }

        return $data;
    }

    /**
     * Resolve a WooCommerce product summary.
     *
     * @param int $productId
     */
    public static function prepareProductSummary($productId): array
    {
        if (!$productId || !\function_exists('wc_get_product')) {
            return [];
        }

        return self::prepareData(wc_get_product($productId));
    }

    public static function getAllWishlists($customerId = null): array
    {
        $args = [
            'show_empty'       => false,
            'orderby'          => 'ID',
            'order'            => 'ASC',
            'return_wishlists' => true,
        ];

        if ($customerId) {
            $args['customer_id'] = (int) $customerId;
        }

        $wishlists = WLFMC_Wishlist_Factory::get_wishlists($args);

        return array_map(
            [self::class, 'prepareData'],
            \is_array($wishlists) ? $wishlists : []
        );
    }

    public static function getAllCustomers($email = null)
    {
        $args = [
            'user_id'    => false,
            'session_id' => false,
            'has_items'  => false,
        ];

        if ($email) {
            $args['email'] = $email;
        }

        $customers = WLFMC_Wishlist_Factory::search_customer($args);

        return array_map(
            [self::class, 'prepareData'],
            \is_array($customers) ? $customers : []
        );
    }

    /**
     * Wishlist options for select fields.
     */
    public static function getWishlistOptions()
    {
        if (!self::isPluginInstalled()) {
            return Response::error(__('MoreConvert Wishlist for WooCommerce plugin is not active.', 'bit-pi'));
        }

        $options = [];

        $wishlists = self::getAllWishlists();
        foreach ($wishlists as $wishlist) {
            if (isset($wishlist['id']) && $wishlist['id'] !== 0) {
                $options[] = [
                    'value' => (int) $wishlist['id'],
                    'label' => (!empty($wishlist['formatted_name']) ? $wishlist['formatted_name'] : __('Wishlist', 'bit-pi')) . ' (#' . $wishlist['id'] . ')',
                ];
            }
        }

        return Response::success($options);
    }

    /**
     * Wishlist customer options for select fields.
     */
    public static function getCustomerOptions()
    {
        if (!self::isPluginInstalled()) {
            return Response::error(__('MoreConvert Wishlist for WooCommerce plugin is not active.', 'bit-pi'));
        }

        $customers = self::getAllCustomers();
        $options = [];
        foreach ($customers as $customer) {
            if (isset($customer['id']) && $customer['id'] !== 0) {
                $email = $customer['email'] ?? '';

                $name = trim(
                    ($customer['first_name'] ?? '')
                    . ' '
                    . ($customer['last_name'] ?? '')
                );

                $label = $email ? $email : ($name ? $name : __('Customer', 'bit-pi'));

                $options[] = [
                    'value' => (int) $customer['id'],
                    'label' => $label . '  (#' . $customer['id'] . ')',
                ];
            }
        }

        return Response::success($options);
    }

    /**
     * WooCommerce product options for select fields.
     */
    public static function getProductOptions()
    {
        if (!\function_exists('wc_get_products')) {
            return Response::error(__('WooCommerce is not active.', 'bit-pi'));
        }

        // Fetch ids only to avoid hydrating a full WC_Product object per row just
        // for the id + title used in the select.
        $productIds = wc_get_products(
            [
                'limit'   => -1,
                'status'  => 'publish',
                'orderby' => 'title',
                'order'   => 'ASC',
                'return'  => 'ids',
            ]
        );

        $options = [];

        foreach (\is_array($productIds) ? $productIds : [] as $productId) {
            $options[] = [
                'value' => (int) $productId,
                'label' => get_the_title($productId) . ' (#' . $productId . ')',
            ];
        }

        return Response::success($options);
    }

    /**
     * WordPress user options for select fields.
     */
    public static function getUserOptions()
    {
        $users = get_users(['fields' => ['ID', 'display_name', 'user_email']]);

        $options = [];

        foreach ($users as $user) {
            $label = $user->display_name ? $user->display_name : $user->user_email;

            $options[] = [
                'value' => (int) $user->ID,
                'label' => $label . ' (' . $user->user_email . ')',
            ];
        }

        return Response::success($options);
    }
}
