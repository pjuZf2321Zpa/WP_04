<?php

namespace BitApps\PiPro\src\Integrations\MoreConvertWishlist;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\Pi\src\Interfaces\ActionInterface;

if (!defined('ABSPATH')) {
    exit;
}

class MoreConvertWishlistAction implements ActionInterface
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executed = $this->executeMoreConvertWishlistAction();

        return Utility::formatResponseData(
            $executed['status_code'] ?? 200,
            $executed['payload'] ?? [],
            $executed['response'] ?? []
        );
    }

    private function executeMoreConvertWishlistAction(): array
    {
        if (!MoreConvertWishlistHelper::isPluginInstalled()) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('MoreConvert Wishlist for WooCommerce plugin is not active.', 'bit-pi'),
            ];
        }

        $machineSlug = $this->nodeInfoProvider->getMachineSlug();

        if (empty($machineSlug)) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('Action method is required.', 'bit-pi'),
            ];
        }

        $serviceInstance = IntegrationHelper::getServiceInstanceByMachineSlug($machineSlug, $this->nodeInfoProvider, true);
        if (!$serviceInstance) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('MoreConvert Wishlist for WooCommerce service not found for the given action method.', 'bit-pi'),
            ];
        }

        return $serviceInstance->{$machineSlug}();
    }
}
