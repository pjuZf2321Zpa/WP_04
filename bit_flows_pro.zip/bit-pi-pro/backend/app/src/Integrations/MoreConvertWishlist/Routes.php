<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\PiPro\src\Integrations\MoreConvertWishlist\MoreConvertWishlistHelper;

Route::group(
    function () {
        Route::get('more-convert-wishlist/wishlists', [MoreConvertWishlistHelper::class, 'getWishlistOptions']);
        Route::get('more-convert-wishlist/customers', [MoreConvertWishlistHelper::class, 'getCustomerOptions']);
        Route::get('more-convert-wishlist/products', [MoreConvertWishlistHelper::class, 'getProductOptions']);
        Route::get('more-convert-wishlist/users', [MoreConvertWishlistHelper::class, 'getUserOptions']);
    }
)->middleware('nonce:admin');
