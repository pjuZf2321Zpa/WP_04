<?php

namespace BitApps\PiPro\src\Integrations\MoreConvertWishlist;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use WLFMC_Wishlist_Factory;

if (!defined('ABSPATH')) {
    exit;
}

final class MoreConvertWishlistTrigger
{
    public static function wishlistItemAdded($productId, $wishlistId, $item, $type): void
    {
        $data = [
            'product_id'    => (int) $productId,
            'wishlist_id'   => (int) $wishlistId,
            'wishlist_type' => $type,
            'item'          => MoreConvertWishlistHelper::prepareWishlistItem($item),
            'product'       => MoreConvertWishlistHelper::prepareProductSummary($productId),
            'wishlist'      => self::loadWishlist($wishlistId),
        ];

        self::execute('wishlistItemAdded', $data);
    }

    public static function wishlistItemRemoved($productId, $wishlistId, $userId): void
    {
        $data = [
            'product_id'  => (int) $productId,
            'wishlist_id' => (int) $wishlistId,
            'user_id'     => (int) $userId,
            'product'     => MoreConvertWishlistHelper::prepareProductSummary($productId),
            'user'        => $userId ? Utility::getUserInfo((int) $userId) : [],
        ];

        self::execute('wishlistItemRemoved', $data);
    }

    public static function wishlistItemCreated($itemId, $item, $wishlistId): void
    {
        $itemData = MoreConvertWishlistHelper::prepareWishlistItem($item);

        $data = [
            'item_id'     => (int) $itemId,
            'wishlist_id' => (int) $wishlistId,
            'item'        => $itemData,
            'product'     => MoreConvertWishlistHelper::prepareProductSummary($itemData['product_id'] ?? null),
            'wishlist'    => self::loadWishlist($wishlistId),
        ];

        self::execute('wishlistItemCreated', $data);
    }

    public static function productAddedToCart($customerId, $wishlistId, $cartItemKey, $variationId, $quantity, $wishlistType): void
    {
        $data = [
            'customer_id'   => (int) $customerId,
            'wishlist_id'   => (int) $wishlistId,
            'cart_item_key' => (string) $cartItemKey,
            'variation_id'  => (int) $variationId,
            'quantity'      => (int) $quantity,
            'wishlist_type' => $wishlistType,
            'customer'      => self::loadCustomer($customerId),
            'wishlist'      => self::loadWishlist($wishlistId),
        ];

        self::execute('productAddedToCart', $data);
    }

    public static function wishlistCreated($wishlistId, $wishlist): void
    {
        $data = [
            'wishlist_id' => (int) $wishlistId,
            'wishlist'    => MoreConvertWishlistHelper::prepareData($wishlist),
        ];

        self::execute('wishlistCreated', $data);
    }

    public static function wishlistDeleted($wishlistId): void
    {
        self::execute('wishlistDeleted', ['wishlist_id' => (int) $wishlistId]);
    }

    public static function customerCreated($customerId, $customer): void
    {
        $customerData = MoreConvertWishlistHelper::prepareData($customer);

        $data = [
            'customer_id' => (int) $customerId,
            'customer'    => $customerData,
            'user'        => isset($customerData['user_id']) ? Utility::getUserInfo($customerData['user_id']) : [],
        ];

        self::execute('customerCreated', $data);
    }

    public static function addedToWaitlist($productId, $userId): void
    {
        self::executeListAddition('addedToWaitlist', $productId, $userId);
    }

    public static function addedToSaveForLater($productId, $userId): void
    {
        self::executeListAddition('addedToSaveForLater', $productId, $userId);
    }

    private static function executeListAddition(string $machineSlug, $productId, $userId): void
    {
        $data = [
            'product_id' => (int) $productId,
            'user_id'    => (int) $userId,
            'product'    => MoreConvertWishlistHelper::prepareProductSummary($productId),
            'user'       => $userId ? Utility::getUserInfo((int) $userId) : [],
        ];

        self::execute($machineSlug, $data);
    }

    private static function loadWishlist($wishlistId): array
    {
        if (!$wishlistId || !class_exists(WLFMC_Wishlist_Factory::class)) {
            return [];
        }

        $wishlist = WLFMC_Wishlist_Factory::get_wishlist((int) $wishlistId);

        return $wishlist ? MoreConvertWishlistHelper::prepareData($wishlist) : [];
    }

    private static function loadCustomer($customerId): array
    {
        if (!$customerId || !class_exists(WLFMC_Wishlist_Factory::class)) {
            return [];
        }

        $customer = WLFMC_Wishlist_Factory::get_customer((int) $customerId);

        return $customer ? MoreConvertWishlistHelper::prepareData($customer) : [];
    }

    private static function execute(string $machineSlug, array $data): void
    {
        $flows = FlowService::exists('moreConvertWishlist', $machineSlug);

        if (!$flows) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $data);
    }
}
