<?php

namespace BitApps\PiPro\src\Integrations\MoreConvertWishlist;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!defined('ABSPATH')) {
    exit;
}

class MoreConvertWishlistHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'wishlistItemAdded' => [
                'hook'          => 'wlfmc_added_to_wishlist',
                'callback'      => [MoreConvertWishlistTrigger::class, 'wishlistItemAdded'],
                'accepted_args' => 4,
            ],
            'wishlistItemRemoved' => [
                'hook'          => 'wlfmc_removed_from_wishlist',
                'callback'      => [MoreConvertWishlistTrigger::class, 'wishlistItemRemoved'],
                'accepted_args' => 3,
            ],
            'wishlistItemCreated' => [
                'hook'          => 'wlfmc_new_wishlist_item',
                'callback'      => [MoreConvertWishlistTrigger::class, 'wishlistItemCreated'],
                'accepted_args' => 3,
            ],
            'productAddedToCart' => [
                'hook'          => 'wlfmc_product_added_to_cart',
                'callback'      => [MoreConvertWishlistTrigger::class, 'productAddedToCart'],
                'accepted_args' => 6,
            ],
            'wishlistCreated' => [
                'hook'          => 'wlfmc_new_wishlist',
                'callback'      => [MoreConvertWishlistTrigger::class, 'wishlistCreated'],
                'accepted_args' => 2,
            ],
            'wishlistDeleted' => [
                'hook'     => 'wlfmc_deleted_wishlist',
                'callback' => [MoreConvertWishlistTrigger::class, 'wishlistDeleted'],
            ],
            'customerCreated' => [
                'hook'          => 'wlfmc_new_customer',
                'callback'      => [MoreConvertWishlistTrigger::class, 'customerCreated'],
                'accepted_args' => 2,
            ],
            'addedToWaitlist' => [
                'hook'          => 'wlfmc_adding_to_waitlist',
                'callback'      => [MoreConvertWishlistTrigger::class, 'addedToWaitlist'],
                'accepted_args' => 2,
            ],
            'addedToSaveForLater' => [
                'hook'          => 'wlfmc_adding_to_save_for_later',
                'callback'      => [MoreConvertWishlistTrigger::class, 'addedToSaveForLater'],
                'accepted_args' => 2,
            ],
        ];
    }
}
