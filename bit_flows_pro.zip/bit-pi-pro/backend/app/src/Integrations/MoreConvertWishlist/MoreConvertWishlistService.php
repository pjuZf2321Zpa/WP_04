<?php

namespace BitApps\PiPro\src\Integrations\MoreConvertWishlist;

use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use WLFMC_Customer;
use WLFMC_Wishlist;
use WLFMC_Wishlist_Factory;

if (!defined('ABSPATH')) {
    exit;
}

final class MoreConvertWishlistService
{
    private NodeInfoProvider $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function getAllWishlists(): array
    {
        return [
            'response'    => MoreConvertWishlistHelper::getAllWishlists(),
            'payload'     => [],
            'status_code' => 200,
        ];
    }

    public function getWishlistById(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $error = $this->validateRequiredId($fieldMappings);

        if ($error) {
            return $error;
        }

        $wishlist = WLFMC_Wishlist_Factory::get_wishlist((int) $fieldMappings['id']);

        if (!$wishlist) {
            return [
                'response'    => __('Wishlist not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404,
            ];
        }

        return [
            'response'    => MoreConvertWishlistHelper::prepareData($wishlist),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function getWishlistItems(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $error = $this->validateRequiredId($fieldMappings);

        if ($error) {
            return $error;
        }

        $items = WLFMC_Wishlist_Factory::get_wishlist_items(
            [
                'wishlist_id' => (int) $fieldMappings['id'],
            ]
        );

        $data = array_map(
            [MoreConvertWishlistHelper::class, 'prepareWishlistItem'],
            \is_array($items) ? $items : []
        );

        return [
            'response'    => ['items' => $data],
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function getDefaultWishlist(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $error = $this->validateRequiredId($fieldMappings);

        if ($error) {
            return $error;
        }

        $wishlist = WLFMC_Wishlist_Factory::get_default_wishlist((int) $fieldMappings['id']);

        if (!$wishlist) {
            return [
                'response'    => __('Default wishlist not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404,
            ];
        }

        return [
            'response'    => MoreConvertWishlistHelper::prepareData($wishlist),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function getWishlistsByCustomer(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $error = $this->validateRequiredId($fieldMappings);

        if ($error) {
            return $error;
        }

        return [
            'response'    => MoreConvertWishlistHelper::getAllWishlists($fieldMappings['id']),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function deleteWishlist(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $error = $this->validateRequiredId($fieldMappings);

        if ($error) {
            return $error;
        }

        $wishlist = WLFMC_Wishlist_Factory::get_wishlist((int) $fieldMappings['id']);

        if (!$wishlist) {
            return [
                'response'    => __('Wishlist not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404,
            ];
        }

        if (!method_exists($wishlist, 'delete')) {
            return [
                'response'    => __('Wishlist cannot be deleted.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        $wishlist->delete();

        return [
            'response'    => __('Wishlist deleted successfully.', 'bit-pi'),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function getCustomerById(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $error = $this->validateRequiredId($fieldMappings);
        if ($error) {
            return $error;
        }

        $customer = WLFMC_Wishlist_Factory::get_customer((int) $fieldMappings['id']);

        if (!$customer) {
            return [
                'response'    => __('Customer not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404,
            ];
        }

        return [
            'response'    => MoreConvertWishlistHelper::prepareData($customer),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function searchCustomerByEmail(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = ['email' => ['required', 'email']];
        $error = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if ($error) {
            return $error;
        }

        return [
            'response'    => MoreConvertWishlistHelper::getAllCustomers($fieldMappings['email']),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function getProductAddedCount(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $error = $this->validateRequiredId($fieldMappings);

        if ($error) {
            return $error;
        }

        $response = [
            'product_id' => (int) $fieldMappings['id'],
            'count'      => (int) WLFMC_Wishlist_Factory::get_times_added_count((int) $fieldMappings['id'])
        ];

        return [
            'response'    => $response,
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function createWishlist(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = ['name' => ['required', 'string']];
        $error = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if ($error) {
            return $error;
        }

        $wishlist = new WLFMC_Wishlist();
        $this->applyWishlistFields($wishlist, $fieldMappings);

        if (!empty($fieldMappings['customerId']) && (int) $fieldMappings['customerId'] > 0) {
            $wishlist->set_customer_id((int) $fieldMappings['customerId']);
        }

        if (!empty($fieldMappings['userId']) && (int) $fieldMappings['userId'] > 0) {
            $wishlist->set_user_id((int) $fieldMappings['userId']);
        }

        $wishlist->save();

        return [
            'response'    => MoreConvertWishlistHelper::prepareData($wishlist),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function updateWishlist(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $error = $this->validateRequiredId($fieldMappings);

        if ($error) {
            return $error;
        }

        $wishlist = WLFMC_Wishlist_Factory::get_wishlist((int) $fieldMappings['id']);

        if (!$wishlist) {
            return [
                'response'    => __('Wishlist not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404,
            ];
        }

        $this->applyWishlistFields($wishlist, $fieldMappings);

        $wishlist->save();

        return [
            'response'    => MoreConvertWishlistHelper::prepareData($wishlist),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function addProductToWishlist(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'wishlistId' => ['required', 'integer'],
            'productId'  => ['required', 'integer'],
        ];
        $error = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if ($error) {
            return $error;
        }

        $wishlist = WLFMC_Wishlist_Factory::get_wishlist((int) $fieldMappings['wishlistId']);

        if (!$wishlist) {
            return [
                'response'    => __('Wishlist not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404,
            ];
        }

        $item = $wishlist->add_product((int) $fieldMappings['productId']);

        if (!$item) {
            return [
                'response'    => __('Product could not be added. It may be invalid or already in the wishlist.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        $wishlist->save();

        return [
            'response' => [
                'added'    => true,
                'item'     => MoreConvertWishlistHelper::prepareWishlistItem($item),
                'wishlist' => MoreConvertWishlistHelper::prepareData($wishlist),
            ],
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function removeProductFromWishlist(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'wishlistId' => ['required', 'integer'],
            'productId'  => ['required', 'integer'],
        ];
        $error = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if ($error) {
            return $error;
        }

        $wishlist = WLFMC_Wishlist_Factory::get_wishlist((int) $fieldMappings['wishlistId']);

        if (!$wishlist) {
            return [
                'response'    => __('Wishlist not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404,
            ];
        }

        $removed = $wishlist->remove_product((int) $fieldMappings['productId']);

        if (!$removed) {
            return [
                'response'    => __('Product is not in the wishlist.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        $wishlist->save();

        return [
            'response' => [
                'removed'  => true,
                'wishlist' => MoreConvertWishlistHelper::prepareData($wishlist),
            ],
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function checkProductInWishlist(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'wishlistId' => ['required', 'integer'],
            'productId'  => ['required', 'integer'],
        ];
        $error = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if ($error) {
            return $error;
        }

        $item = WLFMC_Wishlist_Factory::get_wishlist_item_by_product_id(
            (int) $fieldMappings['wishlistId'],
            (int) $fieldMappings['productId']
        );

        return [
            'response' => [
                'exists' => (bool) $item,
                'item'   => $item ? MoreConvertWishlistHelper::prepareWishlistItem($item) : [],
            ],
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function getWishlistCount(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $args = [
            'user_id'    => false,
            'session_id' => false,
        ];

        if (!empty($fieldMappings['id'])) {
            $args['customer_id'] = (int) $fieldMappings['id'];
        }

        return [
            'response'    => ['count' => (int) WLFMC_Wishlist_Factory::get_wishlists_count($args)],
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function getWishlistItemsCount(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $error = $this->validateRequiredId($fieldMappings);

        if ($error) {
            return $error;
        }

        $count = WLFMC_Wishlist_Factory::get_wishlist_items_count(
            [
                'wishlist_id' => (int) $fieldMappings['id'],
                'user_id'     => false,
                'session_id'  => false,
            ]
        );

        return [
            'response' => [
                'wishlist_id' => (int) $fieldMappings['id'],
                'count'       => (int) $count,
            ],
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function getAllCustomers(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        return [
            'response'    => MoreConvertWishlistHelper::getAllCustomers(),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function createCustomer(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = ['email' => ['required', 'email']];
        $error = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if ($error) {
            return $error;
        }

        $existingCustomers = MoreConvertWishlistHelper::getAllCustomers($fieldMappings['email']);

        if (!empty($existingCustomers)) {
            return [
                'response'    => reset($existingCustomers),
                'payload'     => $fieldMappings,
                'status_code' => 200,
            ];
        }

        $customer = new WLFMC_Customer();
        $customer->set_email($fieldMappings['email']);

        if (!empty($fieldMappings['firstName'])) {
            $customer->set_first_name($fieldMappings['firstName']);
        }

        if (!empty($fieldMappings['lastName'])) {
            $customer->set_last_name($fieldMappings['lastName']);
        }

        if (!empty($fieldMappings['phone'])) {
            $customer->set_phone($fieldMappings['phone']);
        }

        if (!empty($fieldMappings['userId']) && (int) $fieldMappings['userId'] > 0) {
            $customer->set_user_id((int) $fieldMappings['userId']);
        } else {
            $customer->set_session_id(md5(uniqid('wlfmc_', true)));
        }

        $customer->save();

        return [
            'response'    => MoreConvertWishlistHelper::prepareData($customer),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function subscribeCustomer(): array
    {
        return $this->toggleCustomerSubscription(true);
    }

    public function unsubscribeCustomer(): array
    {
        return $this->toggleCustomerSubscription(false);
    }

    private function toggleCustomerSubscription(bool $subscribe): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $error = $this->validateRequiredId($fieldMappings);

        if ($error) {
            return $error;
        }

        $customer = WLFMC_Wishlist_Factory::get_customer((int) $fieldMappings['id']);

        if (!$customer) {
            return [
                'response'    => __('Customer not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404,
            ];
        }

        if ($subscribe) {
            WLFMC_Wishlist_Factory::subscribe_customer($customer);
        } else {
            WLFMC_Wishlist_Factory::unsubscribe_customer($customer);
        }

        return [
            'response' => $subscribe
                ? __('Customer subscribed successfully.', 'bit-pi')
                : __('Customer unsubscribed successfully.', 'bit-pi'),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    private function validateRequiredId(array $fieldMappings): ?array
    {
        return IntegrationHelper::validateFieldMap(
            $fieldMappings,
            ['id' => ['required', 'integer']]
        );
    }

    /**
     * Apply the shared wishlist fields (name, privacy, description, default flag)
     * used by both createWishlist and updateWishlist.
     */
    private function applyWishlistFields(WLFMC_Wishlist $wishlist, array $fieldMappings): void
    {
        if (isset($fieldMappings['name']) && $fieldMappings['name'] !== '') {
            $wishlist->set_name($fieldMappings['name']);
        }

        if (isset($fieldMappings['privacy']) && $fieldMappings['privacy'] !== '') {
            $wishlist->set_privacy((int) $fieldMappings['privacy']);
        }

        if (isset($fieldMappings['description']) && $fieldMappings['description'] !== '') {
            $wishlist->set_description($fieldMappings['description']);
        }

        if (isset($fieldMappings['isDefault']) && $fieldMappings['isDefault'] !== '') {
            $wishlist->set_is_default((int) (bool) $fieldMappings['isDefault']);
        }
    }
}
