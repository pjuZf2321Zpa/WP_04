<?php

namespace BitApps\PiPro\src\Integrations\EasyDigitalDownload;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;

if (!defined('ABSPATH')) {
    exit;
}

class EasyDigitalDownloadAction implements ActionInterface
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeEasyDigitalDownloadAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'] ?? 200,
            $executedNodeAction['payload'] ?? [],
            $executedNodeAction['response'] ?? []
        );
    }

    private function executeEasyDigitalDownloadAction()
    {
        if (!EasyDigitalDownloadHelper::isPluginActive()) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('Easy Digital Downloads plugin is not active.', 'bit-pi'),
            ];
        }

        $eddServices = new EasyDigitalDownloadServices($this->nodeInfoProvider);

        $machineSlug = $this->nodeInfoProvider->getMachineSlug();

        if (!\is_callable([$eddServices, $machineSlug])) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('Easy Digital Downloads action not found.', 'bit-pi'),
            ];
        }

        return $eddServices->{$machineSlug}();
    }
}
