<?php

namespace BitApps\PiPro\src\Integrations\EasyDigitalDownload;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!defined('ABSPATH')) {
    exit;
}

class EasyDigitalDownloadHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'purchaseProduct' => [
                'hook'     => 'edd_complete_purchase',
                'callback' => [EasyDigitalDownloadTrigger::class, 'handlePurchaseProduct'],
            ],
            'purchaseProductDiscount' => [
                'hook'          => 'edd_complete_purchase',
                'callback'      => [EasyDigitalDownloadTrigger::class, 'handlePurchaseProductDiscountCode'],
                'priority'      => 999,
                'accepted_args' => 3,
            ],
            'orderRefunded' => [
                'hook'     => 'edds_payment_refunded',
                'callback' => [EasyDigitalDownloadTrigger::class, 'handleOrderRefunded'],
            ],
            'subscriptionRenew' => [
                'hook'          => 'edd_subscription_post_renew',
                'callback'      => [EasyDigitalDownloadTrigger::class, 'handleSubscriptionRenew'],
                'accepted_args' => 4,
            ],
            'licenseKeyCreate' => [
                'hook'          => 'edd_sl_store_license',
                'callback'      => [EasyDigitalDownloadTrigger::class, 'handleLicenseStore'],
                'accepted_args' => 3,
            ],
            'licenseActivate' => [
                'hook'          => 'edd_sl_activate_license',
                'callback'      => [EasyDigitalDownloadTrigger::class, 'licenseActivate'],
                'accepted_args' => 2,
            ],
            'licenseDeactivate' => [
                'hook'          => 'edd_sl_deactivate_license',
                'callback'      => [EasyDigitalDownloadTrigger::class, 'licenseDeactivate'],
                'accepted_args' => 2,
            ],
            'statusChangedToActivate' => [
                'hook'          => 'edd_sl_post_set_status',
                'callback'      => [EasyDigitalDownloadTrigger::class, 'licenseStatusChangedToActivate'],
                'accepted_args' => 2,
            ],
            'statusChangedToInactive' => [
                'hook'          => 'edd_sl_post_set_status',
                'callback'      => [EasyDigitalDownloadTrigger::class, 'licenseStatusChangedToInactive'],
                'accepted_args' => 2,
            ],
            'statusChangedToDisabled' => [
                'hook'          => 'edd_sl_post_set_status',
                'callback'      => [EasyDigitalDownloadTrigger::class, 'licenseStatusChangedToDisabled'],
                'accepted_args' => 2,
            ],
            'statusChangedToExpire' => [
                'hook'          => 'edd_sl_post_set_status',
                'callback'      => [EasyDigitalDownloadTrigger::class, 'licenseStatusChangedToExpire'],
                'accepted_args' => 2,
            ],
            'orderCreated' => [
                'hook'     => 'edd_complete_purchase',
                'callback' => [EasyDigitalDownloadTrigger::class, 'handleOrderCreated'],
            ],
            'orderStatusChanges' => [
                'hook'          => 'edd_update_payment_status',
                'callback'      => [EasyDigitalDownloadTrigger::class, 'handleOrderStatusChanges'],
                'accepted_args' => 3,
            ],
            'licenseRenewed' => [
                'hook'          => 'edd_sl_post_license_renewal',
                'callback'      => [EasyDigitalDownloadTrigger::class, 'handleLicenseRenewed'],
                'accepted_args' => 2,
            ],
            'licenseUpdated' => [
                'hook'          => 'edd_sl_post_set_status',
                'callback'      => [EasyDigitalDownloadTrigger::class, 'handleLicenseUpdated'],
                'accepted_args' => 2,
            ],
        ];
    }
}
