<?php

namespace BitApps\PiPro\src\Integrations\EasyDigitalDownload;

use BitApps\Pi\src\Flow\NodeInfoProvider;
use EDD_Payment;
use EDD_SL_License;

if (!defined('ABSPATH')) {
    exit;
}

final class EasyDigitalDownloadServices
{
    private $nodeInfoProvider;

    private $fieldMappings;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
        $this->fieldMappings = $this->nodeInfoProvider->getFieldMapData();
    }

    public function createDiscount()
    {
        if (!EasyDigitalDownloadHelper::checkEddFunctions(['edd_add_discount', 'edd_get_discount'])) {
            return [
                'response'    => __('EDD functions not available.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 500
            ];
        }

        $rules = [
            'name'   => ['required', 'string'],
            'code'   => ['required', 'string'],
            'amount' => ['required', 'numeric'],
        ];

        if ($errors = EasyDigitalDownloadHelper::validateFieldMap($this->fieldMappings, $rules)) {
            return $errors;
        }

        $args = $this->buildDiscountArgs();
        $discountId = edd_add_discount($args);

        if (!$discountId) {
            return [
                'response'    => __('Failed to create discount.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 400
            ];
        }

        $discount = edd_get_discount($discountId);

        return [
            'response'    => EasyDigitalDownloadHelper::prepareDiscountData($discount),
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }

    public function deleteDiscount()
    {
        if (!EasyDigitalDownloadHelper::checkEddFunctions(['edd_delete_discount', 'edd_get_discount'])) {
            return [
                'response'    => __('EDD functions not available.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 500
            ];
        }

        $rules = ['discount_id' => ['required', 'integer']];

        if ($errors = EasyDigitalDownloadHelper::validateFieldMap($this->fieldMappings, $rules)) {
            return $errors;
        }

        $discountId = (int) ($this->fieldMappings['discount_id'] ?? 0);

        if (!edd_get_discount($discountId)) {
            return [
                'response'    => __('Discount not found.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 404
            ];
        }

        if (!edd_delete_discount($discountId, true)) {
            return [
                'response'    => __('Failed to delete discount.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 400
            ];
        }

        return [
            'response'    => __('Discount deleted successfully.', 'bit-pi'),
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }

    public function fetchDiscountDetails()
    {
        if (!EasyDigitalDownloadHelper::checkEddFunctions(['edd_get_discount_by'])) {
            return [
                'response'    => __('EDD functions not available.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 500
            ];
        }

        $rules = ['discount_identifier' => ['required', 'string']];

        if ($errors = EasyDigitalDownloadHelper::validateFieldMap($this->fieldMappings, $rules)) {
            return $errors;
        }

        $discount = $this->findDiscountByIdentifier($this->fieldMappings['discount_identifier']);

        if (!$discount) {
            return [
                'response'    => __('Discount not found.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 404
            ];
        }

        return [
            'response'    => EasyDigitalDownloadHelper::prepareDiscountData($discount),
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }

    public function findUserPurchasedDownload()
    {
        if (!EasyDigitalDownloadHelper::checkEddFunctions(['edd_get_payments', 'edd_get_payment_meta_downloads'])) {
            return [
                'response'    => __('EDD functions not available.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 500
            ];
        }

        $rules = ['user_email' => ['required', 'email']];

        if ($errors = EasyDigitalDownloadHelper::validateFieldMap($this->fieldMappings, $rules)) {
            return $errors;
        }

        $user = EasyDigitalDownloadHelper::getUserByEmail($this->fieldMappings['user_email']);

        if (!$user) {
            return [
                'response'    => __('User not found.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 404
            ];
        }

        $downloadId = (int) ($this->fieldMappings['download_id'] ?? 0);
        $priceId = (int) ($this->fieldMappings['price_id'] ?? 0);

        $data = $this->getUserPurchasedDownloads($user->ID, $downloadId, $priceId);

        return [
            'response'    => $data,
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }

    public function findUserSubscriptionForDownload()
    {
        $rules = [
            'user_email'  => ['required', 'email'],
            'download_id' => ['required', 'integer'],
        ];

        if ($errors = EasyDigitalDownloadHelper::validateFieldMap($this->fieldMappings, $rules)) {
            return $errors;
        }

        $user = EasyDigitalDownloadHelper::getUserByEmail($this->fieldMappings['user_email']);

        if (!$user) {
            return [
                'response'    => __('User not found.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 404
            ];
        }

        $downloadId = (int) ($this->fieldMappings['download_id'] ?? 0);
        $priceId = (int) ($this->fieldMappings['price_id'] ?? 0);

        $subscriptions = $this->getUserSubscriptions($user->ID, $downloadId, $priceId);

        return [
            'response'    => $subscriptions,
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }

    public function findUserLicenseForDownload()
    {
        global $wpdb;

        if (!$wpdb) {
            return [
                'response'    => __('Database connection not available.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 500
            ];
        }

        $rules = [
            'user_email'  => ['required', 'email'],
            'download_id' => ['required', 'integer'],
        ];

        if ($errors = EasyDigitalDownloadHelper::validateFieldMap($this->fieldMappings, $rules)) {
            return $errors;
        }

        $user = EasyDigitalDownloadHelper::getUserByEmail($this->fieldMappings['user_email']);

        if (!$user) {
            return [
                'response'    => __('User not found.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 404
            ];
        }

        $downloadId = (int) ($this->fieldMappings['download_id'] ?? 0);
        $priceId = isset($this->fieldMappings['price_id']) ? (int) $this->fieldMappings['price_id'] : null;
        $priceId = ($priceId !== null && $priceId > 0) ? $priceId : null;

        $licenses = $this->getUserLicenses($user->ID, $downloadId, $priceId);

        return [
            'response'    => $licenses,
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }

    public function createPurchase()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapRepeaters('field-map.value', false, true, 'purchaseField', 'value');

        $rules = [
            'customer_email' => ['required', 'email'],
            'download_id'    => ['required', 'integer']
        ];

        if ($errors = EasyDigitalDownloadHelper::validateFieldMap($fieldMappings, $rules)) {
            return $errors;
        }

        if (!$this->checkPurchaseFunctionsAvailable()) {
            return [
                'response'    => __('EDD plugin functions not available.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 500
            ];
        }

        $downloadId = (int) $fieldMappings['download_id'];

        if (!$this->isValidDownload($downloadId)) {
            return [
                'response'    => __('Download not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404
            ];
        }

        if (!\function_exists('edd_get_download_price')) {
            return [
                'response'    => __('EDD function edd_get_download_price not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 500
            ];
        }

        $priceId = isset($fieldMappings['price_id']) ? (int) $fieldMappings['price_id'] : null;
        $quantity = 1;
        $itemPrice = $this->getDownloadPrice($downloadId, $priceId);
        $subtotal = $itemPrice * $quantity;

        $discountCode = $fieldMappings['discount_code'] ?? '';
        $discountAmount = $this->calculateDiscountAmount($discountCode, $downloadId, $subtotal);
        $total = $subtotal - $discountAmount;

        $customerEmail = sanitize_email($fieldMappings['customer_email']);
        $userInfo = $this->buildUserInfo($fieldMappings, $customerEmail);
        $paymentData = $this->buildPaymentData($fieldMappings, $customerEmail, $subtotal, $discountAmount, $total, $userInfo, $downloadId, $priceId, $quantity);
        $paymentData['cart_details'][] = $this->buildCartDetail($downloadId, $itemPrice, $quantity, $discountAmount, $subtotal, $priceId);

        $paymentId = edd_insert_payment($paymentData);

        if (!$paymentId) {
            return [
                'response'    => __('Failed to create purchase.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400
            ];
        }

        $payment = new EDD_Payment($paymentId);

        return [
            'response'    => $this->preparePurchaseData($payment),
            'payload'     => $fieldMappings,
            'status_code' => 200
        ];
    }

    public function revokePurchase()
    {
        $rules = ['purchase_id' => ['required', 'integer']];

        if ($errors = EasyDigitalDownloadHelper::validateFieldMap($this->fieldMappings, $rules)) {
            return $errors;
        }

        if (!\function_exists('edd_update_payment_status') || !class_exists('EDD_Payment')) {
            return [
                'response'    => __('EDD plugin is not active.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 500
            ];
        }

        $paymentId = (int) $this->fieldMappings['purchase_id'];
        $payment = $this->getPaymentById($paymentId);

        if (!$payment) {
            return [
                'response'    => __('Payment/Order not found.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 404
            ];
        }

        $oldStatus = $payment->status;

        if ($oldStatus === 'revoked') {
            return [
                'response'    => __('Purchase is already revoked.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 400
            ];
        }

        if (!edd_update_payment_status($paymentId, 'revoked')) {
            return [
                'response'    => __('Failed to revoke purchase.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 400
            ];
        }

        $this->addPaymentNote($paymentId, __('Purchase revoked via Bit Pi automation.', 'bit-pi'));

        $payment = new EDD_Payment($paymentId);

        return [
            'response'    => $this->prepareRevokedOrderData($payment, $oldStatus),
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }

    public function updateLicenseStatus()
    {
        $rules = [
            'license_key' => ['required', 'string'],
            'status'      => ['required', 'string']
        ];

        if ($errors = EasyDigitalDownloadHelper::validateFieldMap($this->fieldMappings, $rules)) {
            return $errors;
        }

        if (!\function_exists('edd_software_licensing') || !class_exists('EDD_SL_License')) {
            return [
                'response'    => __('EDD Software Licensing plugin is not active.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 500
            ];
        }

        $licenseKey = $this->fieldMappings['license_key'];
        $newStatus = $this->fieldMappings['status'];

        if (!$this->isValidLicenseStatus($newStatus)) {
            return [
                'response'    => __('Invalid license status.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 400
            ];
        }

        $license = $this->getLicenseByKey($licenseKey);

        if (!$license) {
            return [
                'response'    => __('License not found.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 404
            ];
        }

        if (!$license->ID) {
            return [
                'response'    => __('Failed to load license.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 500
            ];
        }

        $oldStatus = $license->status;
        $this->updateLicenseStatusValue($license, $newStatus, $oldStatus);

        return [
            'response'    => $this->prepareLicenseData($license, $oldStatus),
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }

    public function updatePurchaseMeta()
    {
        $rules = [
            'purchase_id'   => ['required', 'integer'],
            'purchase_meta' => ['required', 'array']
        ];

        if ($errors = EasyDigitalDownloadHelper::validateFieldMap($this->fieldMappings, $rules)) {
            return $errors;
        }

        if (!class_exists('EDD_Payment')) {
            return [
                'response'    => __('EDD plugin is not active.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 500
            ];
        }

        $paymentId = (int) $this->fieldMappings['purchase_id'];
        $payment = $this->getPaymentById($paymentId);

        if (!$payment) {
            return [
                'response'    => __('Purchase not found.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 404
            ];
        }

        $updatedMeta = $this->processMetaUpdates($paymentId, $this->fieldMappings['purchase_meta']);
        $response = [
            'purchase_id'  => $paymentId,
            'updated_meta' => $updatedMeta,
            'updated_at'   => gmdate('Y-m-d H:i:s'),
        ];

        return [
            'response'    => $response,
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }

    public function updatePurchase()
    {
        $rules = ['purchase_id' => ['required', 'integer']];

        if ($errors = EasyDigitalDownloadHelper::validateFieldMap($this->fieldMappings, $rules)) {
            return $errors;
        }

        if (!class_exists('EDD_Payment')) {
            return [
                'response'    => __('EDD plugin is not active.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 500
            ];
        }

        $paymentId = (int) $this->fieldMappings['purchase_id'];
        $payment = $this->getPaymentById($paymentId);

        if (!$payment) {
            return [
                'response'    => __('Purchase not found.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 404
            ];
        }

        $updatedFields = $this->processPaymentUpdates($payment, $paymentId);
        $response = [
            'purchase_id'    => $paymentId,
            'updated_fields' => $updatedFields,
            'updated_at'     => gmdate('Y-m-d H:i:s'),
        ];

        return [
            'response'    => $response,
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }

    private function buildDiscountArgs()
    {
        return [
            'name'              => $this->fieldMappings['name'],
            'code'              => $this->fieldMappings['code'],
            'amount'            => (float) ($this->fieldMappings['amount'] ?? 0),
            'amount_type'       => $this->fieldMappings['amount_type'] ?? 'percent',
            'status'            => $this->fieldMappings['status'] ?? 'active',
            'product_reqs'      => $this->fieldMappings['product_required'] ?? [],
            'excluded_products' => $this->fieldMappings['excluded_products'] ?? [],
            'scope'             => $this->fieldMappings['scope'] ?? 'global',
            'product_condition' => $this->fieldMappings['product_condition'] ?? 'all',
            'start_date'        => $this->fieldMappings['start_date'] ?? '',
            'end_date'          => $this->fieldMappings['end_date'] ?? '',
            'min_charge_amount' => (float) ($this->fieldMappings['min_charge_amount'] ?? 0),
            'max_uses'          => (int) ($this->fieldMappings['max_uses'] ?? 0),
            'once_per_customer' => (int) ($this->fieldMappings['once_per_customer'] ?? 0),
            'categories'        => $this->fieldMappings['categories'] ?? [],
            'term_condition'    => $this->fieldMappings['term_condition'] ?? '',
        ];
    }

    private function findDiscountByIdentifier(string $identifier)
    {
        $discount = edd_get_discount_by('code', $identifier);

        if (!$discount && is_numeric($identifier)) {
            $discount = edd_get_discount_by('id', (int) $identifier);
        }

        return $discount;
    }

    private function getUserPurchasedDownloads(int $userId, int $downloadId = 0, int $priceId = 0)
    {
        $args = ['user' => $userId];

        if ($downloadId > 0) {
            $args['download'] = $downloadId;
        }

        $payments = edd_get_payments($args);
        $data = [];

        if (!$payments) {
            return $data;
        }

        foreach ($payments as $payment) {
            $paymentDownloads = edd_get_payment_meta_downloads($payment->ID);

            foreach ($paymentDownloads as $paymentDownload) {
                if (!$this->matchesDownloadCriteria($paymentDownload, $downloadId, $priceId)) {
                    continue;
                }

                $data[] = [
                    'payment_id'   => $payment->ID,
                    'download_id'  => $paymentDownload['id'],
                    'price_id'     => $paymentDownload['price_id'] ?? null,
                    'product_name' => $paymentDownload['name'],
                    'quantity'     => $paymentDownload['quantity'] ?? 1,
                    'total'        => $paymentDownload['total'] ?? 0,
                ];
            }
        }

        return $data;
    }

    private function matchesDownloadCriteria(array $paymentDownload, int $downloadId, int $priceId)
    {
        if ($downloadId > 0 && (int) ($paymentDownload['id'] ?? 0) !== $downloadId) {
            return false;
        }

        return !($priceId > 0 && (int) ($paymentDownload['price_id'] ?? 0) !== $priceId);
    }

    private function getUserSubscriptions(int $userId, int $downloadId, int $priceId = 0)
    {
        global $wpdb;

        $customer = EasyDigitalDownloadHelper::getCustomerByUserId($userId);

        if (!$customer) {
            return [];
        }

        $tableName = esc_sql($wpdb->prefix . 'edd_subscriptions');
        $query = "SELECT * FROM {$tableName} WHERE product_id = %d AND customer_id = %d AND status = 'active'";
        $params = [$downloadId, $customer->id];

        if ($priceId > 0) {
            $query .= ' AND price_id = %d';
            $params[] = $priceId;
        }

        $query .= ' ORDER BY id DESC';

        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        $result = $wpdb->get_results($wpdb->prepare($query, ...$params));

        return $result ?? [];
    }

    private function getUserLicenses(int $userId, int $downloadId, ?int $priceId = null)
    {
        global $wpdb;

        $tableName = esc_sql($wpdb->prefix . 'edd_licenses');
        $query = "SELECT * FROM {$tableName} WHERE download_id = %d AND user_id = %d AND status IN ('active', 'inactive')";
        $params = [$downloadId, $userId];

        if ($priceId !== null) {
            $query .= ' AND price_id = %d';
            $params[] = $priceId;
        }

        $query .= ' ORDER BY id DESC';

        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        $result = $wpdb->get_results($wpdb->prepare($query, ...$params));

        return $result ?? [];
    }

    private function checkPurchaseFunctionsAvailable()
    {
        return \function_exists('edd_insert_payment') && class_exists('EDD_Payment');
    }

    private function isValidDownload(int $downloadId)
    {
        $downloadPost = get_post($downloadId);

        return $downloadPost && $downloadPost->post_type === 'download';
    }

    private function getDownloadPrice(int $downloadId, ?int $priceId)
    {
        if ($priceId === null) {
            return edd_get_download_price($downloadId);
        }

        if (\function_exists('edd_get_variable_prices') && \function_exists('edd_has_variable_prices') && edd_has_variable_prices($downloadId)) {
            $variablePrices = edd_get_variable_prices($downloadId);

            if (isset($variablePrices[$priceId])) {
                return (float) $variablePrices[$priceId]['amount'];
            }

            return edd_get_download_price($downloadId);
        }

        return edd_get_download_price($downloadId, $priceId);
    }

    private function calculateDiscountAmount(string $discountCode, int $downloadId, float $subtotal)
    {
        if (empty($discountCode) || !\function_exists('edd_get_discount_by_code')) {
            return 0;
        }

        $discount = edd_get_discount_by_code($discountCode);

        if (!$discount || $discount->status !== 'active') {
            return 0;
        }

        if (!$this->isDiscountValidForProduct($discount, $downloadId, $subtotal)) {
            return 0;
        }

        return $this->computeDiscountValue($discount, $subtotal);
    }

    private function isDiscountValidForProduct($discount, int $downloadId, float $subtotal)
    {
        $productReqs = $discount->get_product_reqs();
        $excludedProducts = $discount->get_excluded_products();

        if (!empty($productReqs) && !\in_array($downloadId, $productReqs)) {
            return false;
        }

        if (!empty($excludedProducts) && \in_array($downloadId, $excludedProducts)) {
            return false;
        }

        $minAmount = $discount->get_min_charge_amount();

        return !($minAmount > 0 && $subtotal < $minAmount);
    }

    private function computeDiscountValue($discount, float $subtotal)
    {
        $discountType = $discount->get_amount_type();
        $discountValue = $discount->get_amount();

        $discountAmount = ($discountType === 'percent')
            ? ($subtotal * $discountValue) / 100
            : $discountValue;

        return min($discountAmount, $subtotal);
    }

    private function buildUserInfo(array $fieldMappings, string $customerEmail)
    {
        return [
            'id'         => email_exists($customerEmail),
            'email'      => $customerEmail,
            'first_name' => $fieldMappings['first_name'] ?? '',
            'last_name'  => $fieldMappings['last_name'] ?? '',
            'discount'   => $fieldMappings['discount_code'] ?? 'none',
            'address'    => [
                'line1'   => $fieldMappings['address_line1'] ?? '',
                'line2'   => $fieldMappings['address_line2'] ?? '',
                'city'    => $fieldMappings['city'] ?? '',
                'state'   => $fieldMappings['state'] ?? '',
                'zip'     => $fieldMappings['zip'] ?? '',
                'country' => $fieldMappings['country'] ?? '',
            ],
        ];
    }

    private function buildPaymentData(array $fieldMappings, string $customerEmail, float $subtotal, float $discountAmount, float $total, array $userInfo, int $downloadId, ?int $priceId, int $quantity)
    {
        $downloadOptions = ['quantity' => $quantity];
        if ($priceId !== null) {
            $downloadOptions['price_id'] = $priceId;
        }

        $paymentData = [
            'price'        => isset($fieldMappings['total_amount']) ? (float) $fieldMappings['total_amount'] : $total,
            'subtotal'     => $subtotal,
            'discount'     => $discountAmount,
            'date'         => gmdate('Y-m-d H:i:s'),
            'user_email'   => $customerEmail,
            'purchase_key' => wp_generate_uuid4(),
            'currency'     => $fieldMappings['currency'] ?? $this->getDefaultCurrency(),
            'downloads'    => [['id' => $downloadId, 'options' => $downloadOptions]],
            'user_info'    => $userInfo,
            'cart_details' => [],
            'status'       => $fieldMappings['status'] ?? 'pending',
            'gateway'      => $fieldMappings['payment_method'] ?? 'manual',
            'fees'         => [],
        ];

        if (\function_exists('edd_use_taxes') && \function_exists('edd_get_tax_rate') && edd_use_taxes()) {
            $taxRate = edd_get_tax_rate($userInfo['address']['country'], $userInfo['address']['state']);
            $paymentData['tax'] = $paymentData['price'] * $taxRate;
        }

        return $paymentData;
    }

    private function getDefaultCurrency()
    {
        return \function_exists('edd_get_currency') ? edd_get_currency() : 'USD';
    }

    private function buildCartDetail(int $downloadId, float $itemPrice, int $quantity, float $discountAmount, float $subtotal, ?int $priceId)
    {
        $itemOptions = [];
        if ($priceId !== null) {
            $itemOptions['price_id'] = $priceId;
        }

        return [
            'name'        => get_the_title($downloadId),
            'id'          => $downloadId,
            'item_number' => ['id' => $downloadId, 'options' => $itemOptions],
            'price'       => $itemPrice,
            'item_price'  => $itemPrice,
            'quantity'    => $quantity,
            'discount'    => $discountAmount,
            'subtotal'    => $subtotal,
            'tax'         => 0,
            'fees'        => [],
        ];
    }

    private function preparePurchaseData(EDD_Payment $payment)
    {
        return [
            'purchase_id'    => $payment->ID,
            'purchase_key'   => $payment->key,
            'customer_email' => $payment->email,
            'customer_id'    => $payment->customer_id,
            'user_id'        => $payment->user_id,
            'first_name'     => $payment->first_name,
            'last_name'      => $payment->last_name,
            'total_amount'   => $payment->total,
            'subtotal'       => $payment->subtotal,
            'tax'            => $payment->tax,
            'currency'       => $payment->currency,
            'status'         => $payment->status,
            'payment_method' => $payment->gateway,
            'date'           => $payment->date,
        ];
    }

    private function getPaymentById(int $paymentId)
    {
        $payment = new EDD_Payment($paymentId);

        return $payment->ID ? $payment : null;
    }

    private function addPaymentNote(int $paymentId, string $note)
    {
        if (\function_exists('edd_insert_payment_note')) {
            edd_insert_payment_note($paymentId, $note);
        }
    }

    private function prepareRevokedOrderData(EDD_Payment $payment, string $oldStatus)
    {
        return [
            'payment_id'     => $payment->ID,
            'purchase_key'   => $payment->key,
            'customer_email' => $payment->email,
            'customer_id'    => $payment->customer_id,
            'user_id'        => $payment->user_id,
            'old_status'     => $oldStatus,
            'new_status'     => $payment->status,
            'date_revoked'   => gmdate('Y-m-d H:i:s'),
        ];
    }

    private function isValidLicenseStatus(string $status)
    {
        $validStatuses = ['active', 'inactive', 'expired', 'disabled', 'site_inactive'];

        return \in_array($status, $validStatuses, true);
    }

    private function getLicenseByKey(string $licenseKey)
    {
        $licenseId = edd_software_licensing()->get_license_by_key($licenseKey);

        if (!$licenseId) {
            return;
        }

        return new EDD_SL_License($licenseId);
    }

    private function updateLicenseStatusValue(EDD_SL_License $license, string $newStatus, string $oldStatus)
    {
        $license->update_meta('status', $newStatus);
        $license->status = $newStatus;

        do_action('edd_sl_license_status_updated', $license->ID, $newStatus, $oldStatus);
    }

    private function prepareLicenseData(EDD_SL_License $license, string $oldStatus)
    {
        return [
            'license_id'  => $license->ID,
            'license_key' => $license->key,
            'status'      => $license->status,
            'old_status'  => $oldStatus,
            'updated_at'  => gmdate('Y-m-d H:i:s'),
        ];
    }

    private function processMetaUpdates(int $paymentId, array $metaList)
    {
        $updatedMeta = [];

        foreach ($metaList as $meta) {
            $metaKey = $meta['meta_key'] ?? '';

            if (empty($metaKey)) {
                continue;
            }

            $metaValue = $meta['meta_value'] ?? '';
            $oldValue = $this->getPaymentMeta($paymentId, $metaKey);
            $updated = $this->updatePaymentMeta($paymentId, $metaKey, $metaValue);

            $updatedMeta[] = $updated !== false
                ? ['meta_key' => $metaKey, 'old_value' => $oldValue, 'new_value' => $metaValue, 'status' => 'updated']
                : ['meta_key' => $metaKey, 'status' => 'failed'];
        }

        return $updatedMeta;
    }

    private function getPaymentMeta(int $paymentId, string $metaKey)
    {
        return \function_exists('edd_get_payment_meta')
            ? edd_get_payment_meta($paymentId, $metaKey, true)
            : get_post_meta($paymentId, $metaKey, true);
    }

    private function updatePaymentMeta(int $paymentId, string $metaKey, $metaValue)
    {
        return \function_exists('edd_update_payment_meta')
            ? edd_update_payment_meta($paymentId, $metaKey, $metaValue)
            : update_post_meta($paymentId, $metaKey, $metaValue);
    }

    private function processPaymentUpdates(EDD_Payment $payment, int $paymentId)
    {
        $updatedFields = [];

        if (!empty($this->fieldMappings['status'])) {
            $newStatus = $this->fieldMappings['status'];
            $oldStatus = $payment->status;
            $payment->status = $newStatus;
            $payment->save();
            $updatedFields['status'] = ['old_value' => $oldStatus, 'new_value' => $newStatus];
        }

        if (!empty($this->fieldMappings['note'])) {
            $note = sanitize_textarea_field($this->fieldMappings['note']);
            $this->addPaymentNote($paymentId, $note);
            $updatedFields['note'] = ['value' => $note, 'added' => true];
        }

        return $updatedFields;
    }
}
