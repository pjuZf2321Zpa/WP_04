<?php

namespace BitApps\PiPro\src\Integrations\SureFeedback;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;

if (!defined('ABSPATH')) {
    exit;
}

class SureFeedbackAction implements ActionInterface
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeSureFeedbackAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'] ?? 200,
            $executedNodeAction['payload'] ?? [],
            $executedNodeAction['response'] ?? []
        );
    }

    private function executeSureFeedbackAction()
    {
        if (!SureFeedbackHelper::isPluginActive()) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('SureFeedback (ProjectHuddle) plugin is not active.', 'bit-pi'),
            ];
        }

        $sureFeedbackService = new SureFeedbackService($this->nodeInfoProvider);

        $machineSlug = $this->nodeInfoProvider->getMachineSlug();

        if (!\is_callable([$sureFeedbackService, $machineSlug])) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('Invalid action for SureFeedback integration.', 'bit-pi'),
            ];
        }

        return $sureFeedbackService->{$machineSlug}();
    }
}
