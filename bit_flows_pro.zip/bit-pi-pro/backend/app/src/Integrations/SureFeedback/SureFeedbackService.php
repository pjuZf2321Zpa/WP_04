<?php

namespace BitApps\PiPro\src\Integrations\SureFeedback;

use BitApps\Pi\src\Flow\NodeInfoProvider;

if (!\defined('ABSPATH')) {
    exit;
}

final class SureFeedbackService
{
    private $nodeInfoProvider;

    private $fieldMappings;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
        $this->fieldMappings = $this->nodeInfoProvider->getFieldMapData();
    }

    /**
     * Create mockup project.
     *
     * @return array
     */
    public function createMockup()
    {
        $rules = [
            'post_name' => ['required', 'string'],
        ];

        if ($errors = SureFeedbackHelper::validateFieldMap($this->fieldMappings, $rules)) {
            return $errors;
        }

        $postData = [
            'post_title'  => $this->fieldMappings['post_name'],
            'post_status' => 'publish',
            'post_type'   => 'ph-project',
        ];

        $postId = wp_insert_post($postData);

        if (!$postId || is_wp_error($postId)) {
            return [
                'response'    => __('Failed to create mockup.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 400
            ];
        }

        $accessToken = get_post_meta($postId, 'access_token', true);
        $permalink = get_the_permalink($postId);
        $post = get_post($postId);

        $projectAccessLink = !empty($accessToken) ? $permalink : $permalink . '?access_token=' . rawurlencode($accessToken);
        $response = [
            'post_id'             => $postId,
            'post_title'          => $post->post_title,
            'post_type'           => $post->post_type,
            'post_status'         => $post->post_status,
            'permalink'           => $permalink,
            'project_access_link' => $projectAccessLink,
        ];

        return [
            'response'    => $response,
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }
}
