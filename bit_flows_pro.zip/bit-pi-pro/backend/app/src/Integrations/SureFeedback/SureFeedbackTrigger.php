<?php

namespace BitApps\PiPro\src\Integrations\SureFeedback;

// Prevent direct script access
if (!defined('ABSPATH')) {
    exit;
}

use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use PH\Models\Post;

final class SureFeedbackTrigger
{
    public static function handleInsertComment($comment, $request, $creating)
    {
        if (empty($creating) || !self::isSureFeedbackAvailable()) {
            return;
        }

        $commentData = self::prepareCommentData($comment);
        $commentItemId = self::getCommentItemId($commentData['comment_ID']);

        $formData = [
            'comment'  => self::formatCommentData($commentData, $commentItemId),
            'request'  => $request,
            'creating' => $creating,
        ];

        return self::execute($formData, 'insertComment');
    }

    public static function handleCommentResolved($attr, $value, $comment)
    {
        if (empty($value) || $attr !== 'resolved' || !self::isSureFeedbackAvailable()) {
            return;
        }

        $commentData = self::normalizeCommentObject($comment);
        $commentId = self::fetchCommentId($commentData['ID']);

        if (empty($commentId)) {
            return;
        }

        $commentData['website_id'] = self::getCommentProjectId($commentId);

        $commentItemId = self::getCommentItemId($commentId);
        $formData = self::formatCommentData($commentData, $commentItemId);

        return self::execute($formData, 'commentResolved');
    }

    private static function isSureFeedbackAvailable()
    {
        return class_exists('PH\Models\Post') && \function_exists('ph_get_the_title');
    }

    private static function prepareCommentData($comment)
    {
        $commentData = \is_object($comment) ? get_object_vars($comment) : $comment;
        $commentData['website_id'] = self::extractWebsiteId($commentData);

        return $commentData;
    }

    private static function extractWebsiteId($commentData)
    {
        return !empty($commentData['project_id']) ? (int) $commentData['project_id'] : '';
    }

    private static function normalizeCommentObject($comment)
    {
        return \is_object($comment) ? get_object_vars($comment) : $comment;
    }

    private static function fetchCommentId($postId)
    {
        global $wpdb;
        $commentResult = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT  comment_ID FROM {$wpdb->prefix}comments  WHERE comment_post_ID = %d LIMIT 1",
                $postId
            ),
            ARRAY_A
        );

        return $commentResult['comment_ID'] ?? '';
    }

    private static function getCommentProjectId($commentId)
    {
        return get_comment_meta($commentId, 'project_id', true) ?? '';
    }

    private static function formatCommentData($commentData, $commentItemId)
    {
        $itemData = self::buildItemData($commentItemId);
        $postId = $commentData['comment_post_ID'] ?? null;

        if (!$postId) {
            return array_merge(
                $commentData,
                $itemData,
                self::getEmptyProjectData($commentData)
            );
        }

        return array_merge(
            $commentData,
            $itemData,
            self::buildProjectData($postId, $commentData)
        );
    }

    private static function buildItemData($commentItemId)
    {
        return [
            'comment_item_id'         => $commentItemId ?? '',
            'comment_item_page_title' => $commentItemId ? get_the_title($commentItemId) : '',
            'comment_item_page_url'   => $commentItemId ? get_post_meta($commentItemId, 'page_url', true) : ''
        ];
    }

    private static function getEmptyProjectData($commentData)
    {
        return [
            'project_name'   => '',
            'commenter_name' => $commentData['comment_author'] ?? '',
            'project_type'   => '',
            'action_status'  => '',
            'project_link'   => ''
        ];
    }

    private static function buildProjectData($postId, $commentData)
    {
        $projectType = self::getProjectType($postId);
        $actionStatus = self::getActionStatus($postId);
        $projectName = self::getProjectName($postId);
        $projectLink = get_the_guid($postId);

        return [
            'project_name'   => $projectName,
            'commenter_name' => $commentData['comment_author'] ?? '',
            'project_type'   => $projectType,
            'action_status'  => $actionStatus,
            'project_link'   => $projectLink
        ];
    }

    private static function getProjectType($postId)
    {
        $postType = get_post_type($postId);

        return $postType === 'ph-website' ? __('Website', 'bit-pi') : __('Mockup', 'bit-pi');
    }

    private static function getActionStatus($postId)
    {
        $isResolved = get_post_meta($postId, 'resolved', true);

        return $isResolved ? __('Resolved', 'bit-pi') : __('Unresolved', 'bit-pi');
    }

    private static function getProjectName($postId)
    {
        $projectId = Post::get($postId)->parentsIds()['project'] ?? null;

        return $projectId ? ph_get_the_title($projectId) : '';
    }

    private static function getCommentItemId($commentId)
    {
        $id = get_comment_meta($commentId, 'item_id');

        return \is_array($id) && !empty($id) ? (int) array_shift($id) : null;
    }

    private static function execute($formData, $machineSlug)
    {
        $flows = FlowService::exists('SureFeedback', $machineSlug);

        if (!$flows) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $formData);
    }
}
