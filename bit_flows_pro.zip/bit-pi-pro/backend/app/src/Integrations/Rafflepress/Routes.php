<?php

namespace BitApps\PiPro\src\Integrations\Rafflepress;

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Router\Route;

if (!\defined('ABSPATH')) {
    exit;
}

Route::group(
    function () {
        Route::get('rafflepress/contests', [RafflepressHelper::class, 'getContests']);
    }
)->middleware('nonce:admin');
