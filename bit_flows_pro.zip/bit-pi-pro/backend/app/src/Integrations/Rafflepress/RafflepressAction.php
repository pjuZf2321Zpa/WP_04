<?php

namespace BitApps\PiPro\src\Integrations\Rafflepress;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;

if (!\defined('ABSPATH')) {
    exit;
}

class RafflepressAction implements ActionInterface
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeRafflepressAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'] ?? 200,
            $executedNodeAction['payload'] ?? [],
            $executedNodeAction['response'] ?? []
        );
    }

    private function executeRafflepressAction(): array
    {
        if (!RafflepressHelper::isPluginActive()) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('RafflePress plugin is not active.', 'bit-pi'),
            ];
        }

        $rafflePressService = new RafflepressService($this->nodeInfoProvider);

        $machineSlug = $this->nodeInfoProvider->getMachineSlug();

        if (!method_exists($rafflePressService, $machineSlug)) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('RafflePress action not found.', 'bit-pi'),
            ];
        }

        return $rafflePressService->{$machineSlug}();
    }
}
