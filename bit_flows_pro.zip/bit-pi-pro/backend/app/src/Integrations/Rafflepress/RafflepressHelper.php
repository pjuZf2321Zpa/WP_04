<?php

namespace BitApps\PiPro\src\Integrations\Rafflepress;

use BitApps\PiPro\Deps\BitApps\WPValidator\Validator;

if (!defined('ABSPATH')) {
    exit;
}

final class RafflepressHelper
{
    /**
     * Verify RafflePress availability.
     *
     * @return bool
     */
    public static function isPluginActive()
    {
        return defined('RAFFLEPRESS_BUILD') || defined('RAFFLEPRESS_PRO_BUILD');
    }

    /**
     * Perform field validation.
     *
     * @return null|array
     */
    public static function performFieldValidation(array $mappedFields, array $rules, ?array $requestPayload = null)
    {
        $validatorInstance = new Validator();
        $validationResult = $validatorInstance->make($mappedFields, $rules);

        if ($validationResult->fails()) {
            return [
                'response'    => $validationResult->errors(),
                'payload'     => $requestPayload ?? $mappedFields,
                'status_code' => 400
            ];
        }
    }

    /**
     * Retrieve active contests.
     *
     * @return array
     */
    public static function getContests()
    {
        if (!self::isPluginActive()) {
            return [];
        }

        global $wpdb;
        $tableName = $wpdb->prefix . 'rafflepress_giveaways';

        $activeContests = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, name FROM {$tableName} WHERE active = %d ORDER BY name ASC",
                1
            ),
            ARRAY_A
        );

        $contestList = [];
        if (!empty($activeContests)) {
            foreach ($activeContests as $activeContest) {
                $contestList[] = [
                    'label' => $activeContest['name'],
                    'value' => (string) $activeContest['id'],
                ];
            }
        }

        return $contestList;
    }

    /**
     * Build giveaway information dataset.
     *
     * @return array
     */
    public static function buildGiveawayDataset(int $giveawayIdentifier)
    {
        global $wpdb;

        $giveawayTable = $wpdb->prefix . 'rafflepress_giveaways';
        $giveawayInfo = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT name, starts, ends, active FROM {$giveawayTable} WHERE id = %d",
                $giveawayIdentifier
            ),
            ARRAY_A
        );

        if (empty($giveawayInfo)) {
            return [];
        }

        $tableEntries = $wpdb->prefix . 'rafflepress_entries';
        $tableParticipants = $wpdb->prefix . 'rafflepress_contestants';

        $totalEntries = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(id) FROM {$tableEntries} WHERE giveaway_id = %d",
                $giveawayIdentifier
            )
        );

        $totalParticipants = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(id) FROM {$tableParticipants} WHERE giveaway_id = %d",
                $giveawayIdentifier
            )
        );

        $dateFormat = \is_string(get_option('date_format')) ? get_option('date_format') : 'Y-m-d';

        $giveawayDataset = [
            'giveaway_id'                => $giveawayIdentifier,
            'giveaway_name'              => $giveawayInfo['name'],
            'giveaway_start_time'        => gmdate($dateFormat, strtotime($giveawayInfo['starts'])),
            'giveaway_end_time'          => gmdate($dateFormat, strtotime($giveawayInfo['ends'])),
            'giveaway_entry_total'       => $totalEntries,
            'giveaway_participant_count' => $totalParticipants,
            'giveaway_active_status'     => $giveawayInfo['active'] ? 'Active' : 'Inactive',
        ];

        return $giveawayDataset;
    }

    /**
     * Build participant information dataset.
     *
     * @return array
     */
    public static function buildParticipantDataset(int $participantIdentifier)
    {
        global $wpdb;

        $participantsTable = $wpdb->prefix . 'rafflepress_contestants';
        $participantInfo = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT fname, lname, email, status FROM {$participantsTable} WHERE id = %d",
                $participantIdentifier
            ),
            ARRAY_A
        );

        if (empty($participantInfo)) {
            return [];
        }

        $fullName = trim($participantInfo['fname'] . ' ' . $participantInfo['lname']);
        $isVerified = ($participantInfo['status'] === 'confirmed') ? 'Yes' : 'No';

        $participantDataset = [
            'participant_id'       => $participantIdentifier,
            'participant_fullname' => $fullName,
            'participant_email'    => $participantInfo['email'],
            'participant_verified' => $isVerified,
        ];

        return $participantDataset;
    }

    /**
     * Assemble complete registration data.
     *
     * @return array
     */
    public static function assembleRegistrationData(array $registrationData)
    {
        $mandatoryFields = ['giveaway_id', 'contestant_id', 'entry_option_meta'];

        foreach ($mandatoryFields as $fieldKey) {
            if (empty($registrationData[$fieldKey])) {
                return [];
            }
        }

        $extractedGiveawayId = $registrationData['giveaway_id'];
        $extractedParticipantId = $registrationData['contestant_id'];

        $giveawayDetails = self::buildGiveawayDataset($extractedGiveawayId);
        $participantDetails = self::buildParticipantDataset($extractedParticipantId);

        if (empty($giveawayDetails) || empty($participantDetails)) {
            return [];
        }

        $actionMetadata = $registrationData['entry_option_meta'];
        $performedActionId = isset($actionMetadata->id) ? $actionMetadata->id : 0;
        $performedActionName = isset($actionMetadata->name) ? $actionMetadata->name : '';

        $assembledData = array_merge($giveawayDetails, $participantDetails);
        $assembledData['action_id'] = $performedActionId;
        $assembledData['action_label'] = $performedActionName;

        return $assembledData;
    }
}
