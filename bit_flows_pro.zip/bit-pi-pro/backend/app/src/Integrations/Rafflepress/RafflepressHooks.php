<?php

namespace BitApps\PiPro\src\Integrations\Rafflepress;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!\defined('ABSPATH')) {
    exit;
}

class RafflepressHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'newRaffleEntry' => [
                'hook'     => 'rafflepress_giveaway_webhooks',
                'callback' => [RafflepressTrigger::class, 'newRaffleEntry'],
            ],
            'participantRegisteredInContest' => [
                'hook'     => 'rafflepress_post_entry_add',
                'callback' => [RafflepressTrigger::class, 'participantRegisteredInContest'],
            ],
            'entryCompletedWithSpecificTask' => [
                'hook'     => 'rafflepress_post_entry_add',
                'callback' => [RafflepressTrigger::class, 'entryCompletedWithSpecificTask'],
            ],
        ];
    }
}
