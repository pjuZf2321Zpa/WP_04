<?php

namespace BitApps\PiPro\src\Integrations\Rafflepress;

use BitApps\Pi\src\Flow\NodeInfoProvider;

if (!\defined('ABSPATH')) {
    exit;
}

final class RafflepressService
{
    private const TABLE_GIVEAWAYS = 'rafflepress_giveaways';

    private const TABLE_CONTESTANTS = 'rafflepress_contestants';

    private const TABLE_ENTRIES = 'rafflepress_entries';

    private $nodeInfoProvider;

    private $mappedFieldData;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
        $this->mappedFieldData = $this->nodeInfoProvider->getFieldMapData();
    }

    /**
     * Register participant to giveaway.
     *
     * @return array
     */
    public function registerContestParticipant()
    {
        $validationErrors = $this->validateInput();
        if ($validationErrors) {
            return $validationErrors;
        }

        $participantData = $this->extractParticipantData();
        $giveaway = $this->getGiveawayById($participantData['giveaway_id']);

        if (!$giveaway) {
            return [
                'response'    => __('Giveaway not found.', 'bit-pi'),
                'payload'     => $this->mappedFieldData,
                'status_code' => 404
            ];
        }

        if (!$this->isGiveawayActive($giveaway)) {
            return [
                'response'    => __('Giveaway is currently inactive.', 'bit-pi'),
                'payload'     => $this->mappedFieldData,
                'status_code' => 400
            ];
        }

        if ($this->participantExists($participantData['giveaway_id'], $participantData['email'])) {
            return [
                'response'    => __('Participant already registered in this giveaway.', 'bit-pi'),
                'payload'     => $this->mappedFieldData,
                'status_code' => 400
            ];
        }

        $timestamp = current_time('mysql');
        $participantId = $this->insertParticipant($participantData, $timestamp);

        if (!$participantId) {
            return [
                'response'    => __('Unable to register participant.', 'bit-pi'),
                'payload'     => $this->mappedFieldData,
                'status_code' => 400
            ];
        }

        $entryId = $this->createEntry($participantData['giveaway_id'], $participantId, $timestamp);
        $response = $this->buildParticipantResponse($giveaway, $participantData, $participantId, $entryId, $timestamp);

        return [
            'response'    => $response,
            'payload'     => $this->mappedFieldData,
            'status_code' => 200
        ];
    }

    /**
     * Get all giveaways.
     *
     * @return array
     */
    public function getAllGiveaways()
    {
        $giveaways = $this->fetchAllGiveaways();
        $giveaways = $this->unserializeRecords($giveaways);

        return [
            'response'    => $giveaways,
            'payload'     => $this->mappedFieldData,
            'status_code' => 200
        ];
    }

    /**
     * Get giveaway by ID.
     *
     * @return array
     */
    public function getGiveaway()
    {
        $validationErrors = $this->validateGiveawayId();
        if ($validationErrors) {
            return $validationErrors;
        }

        $giveawayId = (int) $this->mappedFieldData['giveaway_id'];
        $giveaway = $this->getGiveawayById($giveawayId);

        if (!$giveaway) {
            return [
                'response'    => __('Giveaway not found.', 'bit-pi'),
                'payload'     => $this->mappedFieldData,
                'status_code' => 404
            ];
        }

        return [
            'response'    => array_map('maybe_unserialize', $giveaway),
            'payload'     => $this->mappedFieldData,
            'status_code' => 200
        ];
    }

    /**
     * Get all contestants in a giveaway.
     *
     * @return array
     */
    public function getAllContestantsInGiveaway()
    {
        $validationErrors = $this->validateGiveawayId();
        if ($validationErrors) {
            return $validationErrors;
        }

        $giveawayId = (int) $this->mappedFieldData['giveaway_id'];
        $contestants = $this->fetchContestantsByGiveawayId($giveawayId);
        $contestantsList = $this->unserializeRecords($contestants);

        return [
            'response'    => $contestantsList,
            'payload'     => $this->mappedFieldData,
            'status_code' => 200
        ];
    }

    /**
     * Get prefixed table name.
     *
     * @param string $table Table name without prefix
     *
     * @return string Full table name with prefix
     */
    private function getTableName(string $table)
    {
        global $wpdb;

        return $wpdb->prefix . $table;
    }

    /**
     * Extract participant data from mapped fields.
     *
     * @return array Participant data
     */
    private function extractParticipantData()
    {
        return [
            'giveaway_id' => (int) $this->mappedFieldData['contest_id'],
            'email'       => $this->mappedFieldData['email'],
            'first_name'  => $this->mappedFieldData['first_name'] ?? '',
            'last_name'   => $this->mappedFieldData['last_name'] ?? ''
        ];
    }

    /**
     * Build participant response data.
     *
     * @param array $giveaway Giveaway data
     * @param array $participantData Participant data
     * @param int $participantId Participant ID
     * @param int $entryId Entry ID
     * @param string $timestamp Registration timestamp
     *
     * @return array Formatted participant response
     */
    private function buildParticipantResponse(array $giveaway, array $participantData, int $participantId, int $entryId, string $timestamp)
    {
        return [
            'giveaway_id'         => $participantData['giveaway_id'],
            'giveaway_title'      => $giveaway['name'],
            'participant_id'      => $participantId,
            'participant_email'   => $participantData['email'],
            'given_name'          => $participantData['first_name'],
            'family_name'         => $participantData['last_name'],
            'complete_name'       => trim($participantData['first_name'] . ' ' . $participantData['last_name']),
            'registration_status' => 'confirmed',
            'entry_identifier'    => $entryId,
            'registration_date'   => $timestamp,
        ];
    }

    /**
     * Validate input data for participant registration.
     *
     * @return null|array
     */
    private function validateInput()
    {
        $fieldRules = [
            'contest_id' => ['required', 'integer'],
            'email'      => ['required', 'email'],
        ];

        return RafflepressHelper::performFieldValidation($this->mappedFieldData, $fieldRules);
    }

    /**
     * Validate giveaway ID field.
     *
     * @return null|array
     */
    private function validateGiveawayId()
    {
        $fieldRules = ['giveaway_id' => ['required', 'integer']];

        return RafflepressHelper::performFieldValidation($this->mappedFieldData, $fieldRules);
    }

    /**
     * Fetch all giveaways from database.
     *
     * @return array
     */
    private function fetchAllGiveaways()
    {
        global $wpdb;
        $table = $this->getTableName(self::TABLE_GIVEAWAYS);

        return $wpdb->get_results(
            "SELECT * FROM {$table} ORDER BY name ASC",
            ARRAY_A
        );
    }

    /**
     * Fetch contestants by giveaway ID.
     *
     * @return array
     */
    private function fetchContestantsByGiveawayId(int $giveawayId)
    {
        global $wpdb;
        $table = $this->getTableName(self::TABLE_CONTESTANTS);

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE giveaway_id = %d ORDER BY created_at ASC",
                $giveawayId
            ),
            ARRAY_A
        );
    }

    /**
     * Unserialize array records.
     *
     * @return array
     */
    private function unserializeRecords(array $records)
    {
        return array_map(
            function ($record) {
                return array_map('maybe_unserialize', $record);
            },
            $records
        );
    }

    /**
     * Get giveaway by ID.
     *
     * @return null|array
     */
    private function getGiveawayById(int $giveawayId)
    {
        global $wpdb;
        $table = $this->getTableName(self::TABLE_GIVEAWAYS);

        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE id = %d",
                $giveawayId
            ),
            ARRAY_A
        );
    }

    /**
     * Check if giveaway is active.
     *
     * @return bool
     */
    private function isGiveawayActive(array $giveaway)
    {
        return !empty($giveaway['active']);
    }

    /**
     * Check if participant already exists for giveaway.
     *
     * @return bool
     */
    private function participantExists(int $giveawayId, string $email)
    {
        global $wpdb;
        $table = $this->getTableName(self::TABLE_CONTESTANTS);

        $existingId = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM {$table} WHERE giveaway_id = %d AND email = %s",
                $giveawayId,
                $email
            )
        );

        return !empty($existingId);
    }

    /**
     * Insert participant into database.
     *
     * @param array $participantData Participant data
     * @param string $timestamp Registration timestamp
     *
     * @return false|int
     */
    private function insertParticipant(array $participantData, string $timestamp)
    {
        global $wpdb;
        $table = $this->getTableName(self::TABLE_CONTESTANTS);

        $data = [
            'giveaway_id' => $participantData['giveaway_id'],
            'email'       => $participantData['email'],
            'fname'       => $participantData['first_name'],
            'lname'       => $participantData['last_name'],
            'status'      => 'confirmed',
            'created_at'  => $timestamp,
        ];

        $result = $wpdb->insert($table, $data, ['%d', '%s', '%s', '%s', '%s', '%s']);

        return $result !== false ? $wpdb->insert_id : false;
    }

    /**
     * Create entry record for participant.
     *
     * @return int
     */
    private function createEntry(int $giveawayId, int $participantId, string $timestamp)
    {
        global $wpdb;
        $table = $this->getTableName(self::TABLE_ENTRIES);

        $data = [
            'giveaway_id'   => $giveawayId,
            'contestant_id' => $participantId,
            'created'       => $timestamp,
        ];

        $wpdb->insert($table, $data, ['%d', '%d', '%s']);

        return $wpdb->insert_id;
    }
}
