<?php

namespace BitApps\PiPro\src\Integrations\BricksBuilder;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!\defined('ABSPATH')) {
    exit;
}

class BricksBuilderHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'bricksFormSubmit' => [
                'hook'          => 'bricks/form/custom_action',
                'callback'      => [BricksBuilderTrigger::class, 'bricksFormSubmit'],
                'priority'      => 7,
                'accepted_args' => 1,
            ],
        ];
    }
}
