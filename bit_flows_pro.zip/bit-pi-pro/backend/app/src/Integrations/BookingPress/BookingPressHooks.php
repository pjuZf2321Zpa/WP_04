<?php

namespace BitApps\PiPro\src\Integrations\BookingPress;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!defined('ABSPATH')) {
    exit;
}

class BookingPressHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'appointmentBooked' => [
                'hook'     => 'bookingpress_after_insert_appointment',
                'callback' => [BookingPressTrigger::class, 'handleAppointmentBooked'],
            ],
            'appointmentCancelled' => [
                'hook'     => 'bookingpress_after_cancel_appointment',
                'callback' => [BookingPressTrigger::class, 'handleAppointmentCancelled'],
            ],
            'appointmentStatusChanged' => [
                'hook'          => 'bookingpress_after_change_appointment_status',
                'callback'      => [BookingPressTrigger::class, 'handleAppointmentStatusChanged'],
                'accepted_args' => 2,
            ],
            'appointmentRescheduled' => [
                'hook'     => 'bookingpress_after_rescheduled_appointment',
                'callback' => [BookingPressTrigger::class, 'handleAppointmentRescheduled'],
            ],
            'appointmentUpdated' => [
                'hook'     => 'bookingpress_after_update_appointment',
                'callback' => [BookingPressTrigger::class, 'handleAppointmentUpdated'],
            ],
            'appointmentRefunded' => [
                'hook'     => 'bookingpress_after_refund_appointment',
                'callback' => [BookingPressTrigger::class, 'handleAppointmentRefunded'],
            ],
            'customerCreated' => [
                'hook' => [
                    'bookingpress_after_create_customer',
                    'bookingpress_after_create_new_customer',
                ],
                'callback' => [BookingPressTrigger::class, 'handleCustomerCreated'],
            ],
            'customerUpdated' => [
                'hook'     => 'bookingpress_after_update_customer',
                'callback' => [BookingPressTrigger::class, 'handleCustomerUpdated'],
            ],
        ];
    }
}
