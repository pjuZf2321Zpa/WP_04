<?php

namespace BitApps\PiPro\src\Integrations\BookingPress;

use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\PiPro\Deps\BitApps\WPKit\Hooks\Hooks;

if (!defined('ABSPATH')) {
    exit;
}

final class BookingPressServices
{
    private NodeInfoProvider $nodeInfoProvider;

    private array $fieldMappings;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
        $this->fieldMappings = $this->nodeInfoProvider->getFieldMapData();
    }

    /**
     * Cancel appointment by setting status to 3.
     */
    public function cancelAppointment()
    {
        $error = $this->validateFields(['appointment_id' => ['required', 'integer']]);
        if ($error) {
            return $error;
        }

        $appointmentId = \intval($this->fieldMappings['appointment_id']);
        $data = BookingPressHelper::getAppointmentData($appointmentId);

        if (empty($data)) {
            return [
                'status_code' => 404,
                'payload'     => $this->fieldMappings,
                'response'    => __('Appointment not found.', 'bit-pi'),
            ];
        }

        global $wpdb;
        $result = $wpdb->update(
            BookingPressHelper::getAppointmentTableName(),
            ['bookingpress_appointment_status'     => '3'],
            ['bookingpress_appointment_booking_id' => $appointmentId]
        );

        if ($result === false) {
            return [
                'status_code' => 400,
                'payload'     => $this->fieldMappings,
                'response'    => __('Failed to cancel appointment.', 'bit-pi'),
            ];
        }

        Hooks::doAction('bookingpress_after_cancel_appointment', $appointmentId);

        return [
            'status_code' => 200,
            'payload'     => $this->fieldMappings,
            'response'    => __('Appointment canceled successfully.', 'bit-pi'),
        ];
    }

    /**
     * Update appointment status.
     */
    public function updateAppointmentStatus()
    {
        $error = $this->validateFields(
            [
                'appointment_id' => ['required', 'integer'],
                'status'         => ['required', 'integer'],
            ]
        );

        if ($error) {
            return $error;
        }

        $appointmentId = \intval($this->fieldMappings['appointment_id']);
        $newStatus = \intval($this->fieldMappings['status']);
        $data = BookingPressHelper::getAppointmentData($appointmentId);

        if (empty($data)) {
            return [
                'status_code' => 404,
                'payload'     => $this->fieldMappings,
                'response'    => __('Appointment not found.', 'bit-pi'),
            ];
        }

        global $wpdb;
        $result = $wpdb->update(
            BookingPressHelper::getAppointmentTableName(),
            ['bookingpress_appointment_status'     => $newStatus],
            ['bookingpress_appointment_booking_id' => $appointmentId]
        );

        if ($result === false) {
            return [
                'status_code' => 400,
                'payload'     => $this->fieldMappings,
                'response'    => __('Failed to update appointment status.', 'bit-pi'),
            ];
        }

        Hooks::doAction('bookingpress_after_change_appointment_status', $appointmentId, $newStatus);

        return [
            'status_code' => 200,
            'payload'     => $this->fieldMappings,
            'response'    => BookingPressHelper::getAppointmentData($appointmentId),
        ];
    }

    /**
     * Create new customer.
     */
    public function createCustomer()
    {
        $error = $this->validateFields(
            [
                'first_name' => ['required', 'string'],
                'last_name'  => ['required', 'string'],
                'email'      => ['required', 'email'],
            ]
        );

        if ($error) {
            return $error;
        }

        global $wpdb;
        $result = $wpdb->insert(
            BookingPressHelper::getCustomerTableName(),
            $this->buildCustomerData()
        );

        if ($result === false) {
            return [
                'status_code' => 400,
                'payload'     => $this->fieldMappings,
                'response'    => __('Failed to create customer.', 'bit-pi'),
            ];
        }

        $customerId = $wpdb->insert_id;
        Hooks::doAction('bookingpress_after_create_customer', $customerId);

        return [
            'status_code' => 200,
            'payload'     => $this->fieldMappings,
            'response'    => BookingPressHelper::getCustomerData($customerId),
        ];
    }

    /**
     * Update customer.
     */
    public function updateCustomer()
    {
        $error = $this->validateFields(['customer_id' => ['required', 'integer']]);

        if ($error) {
            return $error;
        }

        $customerId = \intval($this->fieldMappings['customer_id']);
        $data = BookingPressHelper::getCustomerData($customerId);

        if (empty($data)) {
            return [
                'status_code' => 404,
                'payload'     => $this->fieldMappings,
                'response'    => __('Customer not found.', 'bit-pi'),
            ];
        }

        unset($this->fieldMappings['customer_id']);

        if (empty($this->fieldMappings)) {
            return [
                'status_code' => 400,
                'payload'     => $this->fieldMappings,
                'response'    => __('No fields to update.', 'bit-pi'),
            ];
        }

        $updateData = $this->fieldMappings;

        $firstNameUpdated = isset($this->fieldMappings['bookingpress_user_firstname']);
        $lastNameUpdated  = isset($this->fieldMappings['bookingpress_user_lastname']);

        if ($firstNameUpdated || $lastNameUpdated) {
            $firstName                            = $this->fieldMappings['bookingpress_user_firstname'] ?? $data['bookingpress_user_firstname'];
            $lastName                             = $this->fieldMappings['bookingpress_user_lastname'] ?? $data['bookingpress_user_lastname'];
            $updateData['bookingpress_customer_full_name'] = trim($firstName . ' ' . $lastName);
        }

        if (isset($this->fieldMappings['bookingpress_user_email'])) {
            $email                                    = $this->fieldMappings['bookingpress_user_email'];
            $updateData['bookingpress_user_login']    = $email;
            $updateData['bookingpress_user_name']     = $email;
        }

        global $wpdb;
        $result = $wpdb->update(
            BookingPressHelper::getCustomerTableName(),
            $updateData,
            ['bookingpress_customer_id' => $customerId]
        );

        if ($result === false) {
            return [
                'status_code' => 400,
                'payload'     => $this->fieldMappings,
                'response'    => __('Failed to update customer.', 'bit-pi'),
            ];
        }

        Hooks::doAction('bookingpress_after_update_customer', $customerId);

        return [
            'status_code' => 200,
            'payload'     => $this->fieldMappings,
            'response'    => BookingPressHelper::getCustomerData($customerId),
        ];
    }

    /**
     * Delete appointment and related payment logs.
     */
    public function deleteAppointment()
    {
        $error = $this->validateFields(['appointment_id' => ['required', 'integer']]);

        if ($error) {
            return $error;
        }

        $appointmentId = \intval($this->fieldMappings['appointment_id']);
        $data = BookingPressHelper::getAppointmentData($appointmentId);

        if (empty($data)) {
            return [
                'status_code' => 404,
                'payload'     => $this->fieldMappings,
                'response'    => __('Appointment not found.', 'bit-pi'),
            ];
        }

        global $wpdb;

        // Delete appointment
        $result = $wpdb->delete(
            BookingPressHelper::getAppointmentTableName(),
            ['bookingpress_appointment_booking_id' => $appointmentId]
        );

        if ($result === false) {
            return [
                'status_code' => 400,
                'payload'     => $this->fieldMappings,
                'response'    => __('Failed to delete appointment.', 'bit-pi'),
            ];
        }

        // Delete related payment logs
        $wpdb->delete(
            BookingPressHelper::getPaymentLogTableName(),
            ['bookingpress_appointment_booking_ref' => $appointmentId]
        );

        return [
            'status_code' => 200,
            'payload'     => $this->fieldMappings,
            'response'    => __('Appointment deleted successfully.', 'bit-pi'),
        ];
    }

    /**
     * Get appointment by ID.
     */
    public function getAppointment()
    {
        $error = $this->validateFields(['appointment_id' => ['required', 'integer']]);

        if ($error) {
            return $error;
        }

        $appointmentId = \intval($this->fieldMappings['appointment_id']);
        $data = BookingPressHelper::getAppointmentData($appointmentId);

        if (empty($data)) {
            return [
                'status_code' => 404,
                'payload'     => $this->fieldMappings,
                'response'    => __('Appointment not found.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $this->fieldMappings,
            'response'    => $data,
        ];
    }

    /**
     * Get customer by ID.
     */
    public function getCustomer()
    {
        $error = $this->validateFields(['customer_id' => ['required', 'integer']]);

        if ($error) {
            return $error;
        }

        $customerId = \intval($this->fieldMappings['customer_id']);
        $data = BookingPressHelper::getCustomerData($customerId);

        if (empty($data)) {
            return [
                'status_code' => 404,
                'payload'     => $this->fieldMappings,
                'response'    => __('Customer not found.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $this->fieldMappings,
            'response'    => $data,
        ];
    }

    /**
     * Get all appointments.
     */
    public function getAllAppointments()
    {
        $tableName = BookingPressHelper::getAppointmentTableName();
        $appointments = BookingPressHelper::getAllRecords($tableName, 'bookingpress_appointment_booking_id');

        return [
            'response'    => $appointments,
            'payload'     => [],
            'status_code' => 200,
        ];
    }

    /**
     * Get all customers.
     */
    public function getAllCustomers()
    {
        $tableName = BookingPressHelper::getCustomerTableName();
        $customers = BookingPressHelper::getAllRecords($tableName, 'bookingpress_customer_id');

        return [
            'status_code' => 200,
            'payload'     => [],
            'response'    => $customers,
        ];
    }

    /**
     * Get all services.
     */
    public function getAllServices()
    {
        $tableName = BookingPressHelper::getServiceTableName();
        $services = BookingPressHelper::getAllRecords($tableName, 'bookingpress_service_id');

        return [
            'status_code' => 200,
            'payload'     => [],
            'response'    => $services,
        ];
    }

    /**
     * Delete customer and related appointments and payment logs.
     */
    public function deleteCustomer()
    {
        $error = $this->validateFields(['customer_id' => ['required', 'integer']]);

        if ($error) {
            return $error;
        }

        $customerId = \intval($this->fieldMappings['customer_id']);
        $data = BookingPressHelper::getCustomerData($customerId);

        if (empty($data)) {
            return [
                'status_code' => 404,
                'payload'     => $this->fieldMappings,
                'response'    => __('Customer not found.', 'bit-pi'),
            ];
        }

        global $wpdb;

        // Delete customer
        $result = $wpdb->delete(
            BookingPressHelper::getCustomerTableName(),
            ['bookingpress_customer_id' => $customerId]
        );

        if ($result === false) {
            return [
                'status_code' => 400,
                'payload'     => $this->fieldMappings,
                'response'    => __('Failed to delete customer.', 'bit-pi'),
            ];
        }

        // Delete related appointments and payment logs
        $wpdb->delete(
            BookingPressHelper::getAppointmentTableName(),
            ['bookingpress_customer_id' => $customerId]
        );

        $wpdb->delete(
            BookingPressHelper::getPaymentLogTableName(),
            ['bookingpress_customer_id' => $customerId]
        );

        return [
            'status_code' => 200,
            'payload'     => $this->fieldMappings,
            'response'    => __('Customer deleted successfully.', 'bit-pi'),
        ];
    }

    /**
     * Validate field mappings and return error if validation fails.
     *
     * @param mixed $rules
     */
    private function validateFields($rules)
    {
        return BookingPressHelper::validateFieldMap($this->fieldMappings, $rules);
    }

    /**
     * Build customer data for database insertion/update.
     */
    private function buildCustomerData()
    {
        $firstName = $this->fieldMappings['first_name'];
        $lastName = $this->fieldMappings['last_name'];
        $email = $this->fieldMappings['email'];
        $fullName = trim($firstName . ' ' . $lastName);

        return [
            'bookingpress_user_login'         => $email,
            'bookingpress_user_status'        => 1,
            'bookingpress_user_type'          => 2,
            'bookingpress_user_email'         => $email,
            'bookingpress_user_name'          => $email,
            'bookingpress_customer_full_name' => $fullName,
            'bookingpress_user_firstname'     => $firstName,
            'bookingpress_user_lastname'      => $lastName,
            'bookingpress_user_phone'         => $this->fieldMappings['phone'] ?? '',
            'bookingpress_user_created'       => current_time('mysql'),
        ];
    }
}
