<?php

namespace BitApps\PiPro\src\Integrations\BookingPress;

use BitApps\PiPro\Config;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\PiPro\Deps\BitApps\WPValidator\Validator;

if (!defined('ABSPATH')) {
    exit;
}

final class BookingPressHelper
{
    /**
     * Get appointments list with ID and formatted label.
     */
    public function getAppointments()
    {
        if (!self::isBookingPressActive()) {
            return Response::error(__('BookingPress is not installed or activated', 'bit-pi'));
        }

        $tableName = self::getAppointmentTableName();
        $appointments = self::getAllRecords($tableName, 'bookingpress_appointment_booking_id');

        $result = array_map(
            function ($appointment) {
                $id = (int) $appointment['bookingpress_appointment_booking_id'];

                return [
                    'value' => $id,
                    // Translators: %d is the appointment ID.
                    'label' => \sprintf(__('Appointment #%d', 'bit-pi'), $id),
                ];
            },
            $appointments
        );

        return Response::success($result);
    }

    /**
     * Get customers list with ID and formatted label.
     */
    public function getCustomers()
    {
        if (!self::isBookingPressActive()) {
            return Response::error(__('BookingPress is not installed or activated', 'bit-pi'));
        }

        $tableName = self::getCustomerTableName();
        $customers = self::getAllRecords($tableName, 'bookingpress_customer_id');

        $result = array_map(
            function ($customer) {
                $id = (int) $customer['bookingpress_customer_id'];
                $name = trim((string) ($customer['bookingpress_customer_full_name'] ?? ''));

                return [
                    'value' => $id,
                    'label' => !empty($name)
                        // Translators: %s is the customer name.
                        ? \sprintf('%s (#%d)', $name, $id)
                        // Translators: %d is the customer ID.
                        : \sprintf(__('Customer #%d', 'bit-pi'), $id),
                ];
            },
            $customers
        );

        return Response::success($result);
    }

    /**
     * Get services list with optional "Any Service" option.
     */
    public function getServices()
    {
        if (!self::isBookingPressActive()) {
            return Response::error(__('BookingPress is not installed or activated', 'bit-pi'));
        }

        $result = [
            ['value' => 'any', 'label' => __('Any Service', 'bit-pi')],
        ];

        $tableName = self::getServiceTableName();
        $services = self::getAllRecords($tableName, 'bookingpress_service_id');

        $result = array_merge(
            $result,
            array_map(
                function ($service) {
                    return [
                        'value' => $service['bookingpress_service_id'],
                        'label' => $service['bookingpress_service_name'],
                    ];
                },
                $services
            )
        );

        return Response::success($result);
    }

    /**
     * Get record by ID from specified table and column.
     *
     * @param mixed $id
     * @param mixed $idColumn
     * @param mixed $tableName
     */
    public static function getRecordById($tableName, $id, $idColumn)
    {
        if (empty($tableName)) {
            return [];
        }

        global $wpdb;
        $record = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$tableName} WHERE {$idColumn} = %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                $id
            ),
            ARRAY_A
        );

        return $record ?: [];
    }

    /**
     * Get all records from specified table ordered by ID column.
     *
     * @param string $tableName
     * @param string $idColumn
     */
    public static function getAllRecords($tableName, $idColumn)
    {
        if (empty($tableName)) {
            return [];
        }

        global $wpdb;
        $records = $wpdb->get_results(
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            "SELECT * FROM {$tableName} ORDER BY {$idColumn} DESC",
            ARRAY_A
        );

        return $records ?: [];
    }

    /**
     * Get appointment data by ID.
     *
     * @param mixed $appointmentId
     */
    public static function getAppointmentData($appointmentId)
    {
        return self::getRecordById(self::getAppointmentTableName(), $appointmentId, 'bookingpress_appointment_booking_id');
    }

    /**
     * Get customer data by ID.
     *
     * @param mixed $customerId
     */
    public static function getCustomerData($customerId)
    {
        return self::getRecordById(self::getCustomerTableName(), $customerId, 'bookingpress_customer_id');
    }

    /**
     * Validate field mappings against rules.
     *
     * @param mixed $fieldMappings
     * @param mixed $validationRules
     * @param null|mixed $payload
     */
    public static function validateFieldMap($fieldMappings, $validationRules, $payload = null)
    {
        $validator = new Validator();
        $validation = $validator->make($fieldMappings, $validationRules);

        if ($validation->fails()) {
            return [
                'response'    => $validation->errors(),
                'payload'     => $payload ?? $fieldMappings,
                'status_code' => 400,
            ];
        }
    }

    /**
     * Check if BookingPress plugin is active.
     */
    public static function isBookingPressActive()
    {
        return class_exists('BookingPress');
    }

    /**
     * Get cached table name with fallback to global or direct generation.
     *
     * @param mixed $tableKey
     */
    public static function getTableName($tableKey)
    {
        $tableNames = [
            'appointments' => 'bookingpress_appointment_bookings',
            'payment_logs' => 'bookingpress_payment_logs',
            'customers'    => 'bookingpress_customers',
            'services'     => 'bookingpress_services',
        ];

        if (empty($tableNames[$tableKey])) {
            return;
        }

        return Config::get('WP_DB_PREFIX') . $tableNames[$tableKey];
    }

    /**
     * Get appointment table name.
     */
    public static function getAppointmentTableName()
    {
        // phpcs:ignore WordPress.DB.GlobalVariables -- We need to use global variables here to access table names defined by BookingPress plugin.
        global $tbl_bookingpress_appointment_bookings;

        if (!empty($tbl_bookingpress_appointment_bookings)) {
            return $tbl_bookingpress_appointment_bookings;
        }

        return self::getTableName('appointments');
    }

    /**
     * Get customer table name.
     */
    public static function getCustomerTableName()
    {
        // phpcs:ignore WordPress.DB.GlobalVariables -- We need to use global variables here to access table names defined by BookingPress plugin.
        global $tbl_bookingpress_customers;

        if (!empty($tbl_bookingpress_customers)) {
            return $tbl_bookingpress_customers;
        }

        return self::getTableName('customers');
    }

    /**
     * Get service table name.
     */
    public static function getServiceTableName()
    {
        // phpcs:ignore WordPress.DB.GlobalVariables -- We need to use global variables here to access table names defined by BookingPress plugin.
        global $tbl_bookingpress_services;

        if (!empty($tbl_bookingpress_services)) {
            return $tbl_bookingpress_services;
        }

        return self::getTableName('services');
    }

    /**
     * Get payment logs table name.
     */
    public static function getPaymentLogTableName()
    {
        // phpcs:ignore WordPress.DB.GlobalVariables -- We need to use global variables here to access table names defined by BookingPress plugin.
        global $tbl_bookingpress_payment_logs;

        if (!empty($tbl_bookingpress_payment_logs)) {
            return $tbl_bookingpress_payment_logs;
        }

        return self::getTableName('payment_logs');
    }
}
