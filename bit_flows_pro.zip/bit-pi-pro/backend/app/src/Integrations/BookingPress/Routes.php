<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\PiPro\src\Integrations\BookingPress\BookingPressHelper;

Route::group(
    function () {
        Route::get('bookingpress/get/appointments', [BookingPressHelper::class, 'getAppointments']);
        Route::get('bookingpress/get/customers', [BookingPressHelper::class, 'getCustomers']);
        Route::get('bookingpress/get/services', [BookingPressHelper::class, 'getServices']);
    }
)->middleware('nonce:admin');
