<?php

namespace BitApps\PiPro\src\Integrations\BookingPress;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;

final class BookingPressTrigger
{
    public static function handleAppointmentBooked($appointmentId)
    {
        self::processAppointmentEvent('appointmentBooked', $appointmentId);
    }

    public static function handleAppointmentCancelled($appointmentId)
    {
        self::processAppointmentEvent('appointmentCancelled', $appointmentId);
    }

    public static function handleAppointmentStatusChanged($appointmentId, $newStatus)
    {
        self::processAppointmentEvent('appointmentStatusChanged', $appointmentId, $newStatus);
    }

    public static function handleAppointmentRescheduled($appointmentId)
    {
        self::processAppointmentEvent('appointmentRescheduled', $appointmentId);
    }

    public static function handleAppointmentUpdated($appointmentId)
    {
        self::processAppointmentEvent('appointmentUpdated', $appointmentId);
    }

    public static function handleAppointmentRefunded($appointmentId)
    {
        self::processAppointmentEvent('appointmentRefunded', $appointmentId);
    }

    public static function handleCustomerCreated($customerId)
    {
        self::processCustomerEvent($customerId, 'customerCreated');
    }

    public static function handleCustomerUpdated($customerId)
    {
        self::processCustomerEvent($customerId, 'customerUpdated');
    }

    private static function processCustomerEvent($customerId, $machineSlug)
    {
        if (empty($customerId) || !BookingPressHelper::isBookingPressActive()) {
            return;
        }

        $data = BookingPressHelper::getCustomerData($customerId);

        if (empty($data)) {
            return;
        }

        self::execute($machineSlug, $data);
    }

    private static function processAppointmentEvent($machineSlug, $appointmentId, $newStatus = false)
    {
        if (empty($appointmentId) || !BookingPressHelper::isBookingPressActive()) {
            return;
        }

        $data = BookingPressHelper::getAppointmentData($appointmentId);

        if (empty($data)) {
            return;
        }

        $serviceId = $data['bookingpress_service_id'] ?? null;

        if ($newStatus) {
            $data['new_status'] = $newStatus;
        }

        self::execute($machineSlug, $data, $serviceId, 'service-id');
    }

    private static function execute($machineSlug, $data, $value = null, $keyName = 'form-id')
    {
        $flows = FlowService::exists('bookingPress', $machineSlug);

        if (empty($flows)) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $data, $value, $keyName);
    }
}
