<?php

namespace BitApps\PiPro\src\Integrations\BookingPress;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;

if (!defined('ABSPATH')) {
    exit;
}

class BookingPressAction implements ActionInterface
{
    private NodeInfoProvider $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeBookingPressAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'] ?? 200,
            $executedNodeAction['payload'] ?? [],
            $executedNodeAction['response'] ?? []
        );
    }

    private function executeBookingPressAction()
    {
        if (!BookingPressHelper::isBookingPressActive()) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('BookingPress plugin is not active.', 'bit-pi'),
            ];
        }

        $bookingPressServices = new BookingPressServices($this->nodeInfoProvider);

        $machineSlug = $this->nodeInfoProvider->getMachineSlug();

        if (!\is_callable([$bookingPressServices, $machineSlug])) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('BookingPress action not found.', 'bit-pi'),
            ];
        }

        return $bookingPressServices->{$machineSlug}();
    }
}
