<?php

namespace BitApps\PiPro\src\Integrations\GravityKit;

use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use GFCommon;
use GFFormsModel;

if (!\defined('ABSPATH')) {
    exit;
}

class GravityKitTrigger
{
    public static function formEntryApproved($entryId)
    {
        self::handleFormEntry($entryId, __FUNCTION__);
    }

    public static function formEntryRejected($entryId)
    {
        self::handleFormEntry($entryId, __FUNCTION__);
    }

    private static function handleFormEntry($entryId, $machineSlug)
    {
        if (!self::isRequiredClassesAvailable()) {
            return;
        }

        $flows = FlowService::exists('GravityKit', $machineSlug);
        if (!$flows) {
            return;
        }

        $formData = self::getFormData($entryId);
        if (!$formData) {
            return;
        }

        $data = [
            'entry_id'              => (int) $entryId,
            'form_id'               => (int) $formData['form_id'],
            'gravity_form'          => (int) $formData['form_id'],
            'gravity_form_entry_id' => (int) $entryId,
            'gravity_form_data'     => $formData['fields']
        ];

        IntegrationHelper::handleFlowForForm($flows, $data);
    }

    private static function isRequiredClassesAvailable()
    {
        return class_exists('GFFormsModel') && class_exists('GFCommon');
    }

    private static function getFormData($entryId)
    {
        global $wpdb;

        $formId = $wpdb->get_var(
            $wpdb->prepare(
                'SELECT form_id FROM %1s WHERE id = %d',
                "{$wpdb->prefix}gf_entry",
                $entryId
            )
        );

        if (!$formId) {
            return;
        }

        $form = GFFormsModel::get_form_meta($formId);
        if (!\is_array($form['fields'])) {
            return;
        }

        $fields = self::getFormFields($form['fields'], $entryId);

        return [
            'form_id' => $formId,
            'fields'  => $fields
        ];
    }

    private static function getFormFields($formFields, $entryId)
    {
        $fields = [];

        foreach ($formFields as $field) {
            if (isset($field['inputs']) && \is_array($field['inputs'])) {
                foreach ($field['inputs'] as $input) {
                    $label = GFCommon::get_label($field, $input['id']);
                    $metaValue = self::getFieldMetaValue($entryId, $input['id']);
                    $fields[$label] = $metaValue;
                }
            } elseif (!isset($field['displayOnly'])) {
                $label = GFCommon::get_label($field);
                $metaValue = self::getFieldMetaValue($entryId, $field['id']);
                $fields[$label] = $metaValue;
            }
        }

        return $fields;
    }

    private static function getFieldMetaValue($entryId, $fieldId)
    {
        global $wpdb;

        return $wpdb->get_var(
            $wpdb->prepare(
                'SELECT meta_value FROM %1s WHERE entry_id = %d AND meta_key = %s',
                "{$wpdb->prefix}gf_entry_meta",
                $entryId,
                $fieldId
            )
        );
    }
}
