<?php

namespace BitApps\PiPro\src\Integrations\GravityKit;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!\defined('ABSPATH')) {
    exit;
}

class GravityKitHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'formEntryApproved' => [
                'hook'     => 'gravityview/approve_entries/approved',
                'callback' => [GravityKitTrigger::class, 'formEntryApproved'],
            ],
            'formEntryRejected' => [
                'hook'     => 'gravityview/approve_entries/disapproved',
                'callback' => [GravityKitTrigger::class, 'formEntryRejected'],
            ],
        ];
    }
}
