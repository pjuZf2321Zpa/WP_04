<?php

namespace BitApps\PiPro\src\Integrations\PowerCoupons\helper;

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Response;
use DateTimeInterface;
use Power_Coupons\Includes\Power_Coupons_Utilities;
use WC_Coupon;
use WC_Order;

if (!defined('ABSPATH')) {
    exit;
}

final class PowerCouponsHelper
{
    public static function isPluginInstalled(): bool
    {
        return defined('POWER_COUPONS_VERSION') && class_exists('WC_Coupon');
    }

    public static function formatCouponCode($code): string
    {
        if (\function_exists('wc_format_coupon_code')) {
            return wc_format_coupon_code((string) $code);
        }

        return strtolower(trim(wp_strip_all_tags(wp_check_invalid_utf8((string) $code))));
    }

    public static function isPowerCoupon($coupon): bool
    {
        return class_exists(Power_Coupons_Utilities::class)
            && Power_Coupons_Utilities::is_power_coupons_coupon($coupon);
    }

    public static function getCoupon($couponIdOrCode)
    {
        if (!class_exists('WC_Coupon')) {
            return;
        }

        $coupon = new WC_Coupon($couponIdOrCode);

        return $coupon->get_id() > 0 ? $coupon : null;
    }

    public static function couponData($coupon): array
    {
        if (!$coupon instanceof WC_Coupon) {
            return [];
        }

        $couponId = $coupon->get_id();
        $post = get_post($couponId);
        $dateExpires = $coupon->get_date_expires();

        return [
            'id'                          => $couponId,
            'code'                        => $coupon->get_code(),
            'description'                 => $coupon->get_description(),
            'discount_type'               => $coupon->get_discount_type(),
            'amount'                      => (float) $coupon->get_amount(),
            'status'                      => $post ? $post->post_status : '',
            'usage_count'                 => $coupon->get_usage_count(),
            'usage_limit'                 => $coupon->get_usage_limit() ?: 0,
            'usage_limit_per_user'        => $coupon->get_usage_limit_per_user() ?: 0,
            'free_shipping'               => $coupon->get_free_shipping(),
            'minimum_amount'              => (float) $coupon->get_minimum_amount(),
            'maximum_amount'              => (float) $coupon->get_maximum_amount(),
            'individual_use'              => $coupon->get_individual_use(),
            'exclude_sale_items'          => $coupon->get_exclude_sale_items(),
            'product_ids'                 => $coupon->get_product_ids(),
            'excluded_product_ids'        => $coupon->get_excluded_product_ids(),
            'product_categories'          => $coupon->get_product_categories(),
            'excluded_product_categories' => $coupon->get_excluded_product_categories(),
            'email_restrictions'          => $coupon->get_email_restrictions(),
            'auto_apply'                  => get_post_meta($couponId, '_power_coupon_auto_apply', true) === 'yes',
            'show_in_slideout'            => get_post_meta($couponId, '_power_coupon_show_in_slideout', true) === 'yes',
            'start_date'                  => (string) get_post_meta($couponId, '_power_coupon_start_date', true),
            'expiry_date'                 => $dateExpires ? $dateExpires->date('Y-m-d') : '',
            'is_power_coupon'             => self::isPowerCoupon($coupon),
            'url_edit'                    => admin_url('post.php?post=' . $couponId . '&action=edit'),
        ];
    }

    public static function orderData($order, array $powerCoupons): array
    {
        if (!$order instanceof WC_Order) {
            return [];
        }

        $lineItems = [];
        foreach ($order->get_items() as $item) {
            $lineItems[] = self::normalizeValue($item);
        }

        $data = self::normalizeValue($order);
        $data = \is_array($data) ? $data : [];
        $data['order_id'] = $order->get_id();
        $data['line_items'] = $lineItems;
        $data['power_coupons'] = $powerCoupons;

        return $data;
    }

    public static function normalizeValue($value)
    {
        if ($value instanceof DateTimeInterface) {
            return $value->format(DATE_ATOM);
        }

        if (\is_array($value)) {
            return array_map([self::class, 'normalizeValue'], $value);
        }

        if (!\is_object($value)) {
            return $value;
        }

        if (method_exists($value, 'get_data')) {
            return self::normalizeValue($value->get_data());
        }

        if (method_exists($value, 'toArray')) {
            return self::normalizeValue($value->toArray());
        }

        return self::normalizeValue(get_object_vars($value));
    }

    public static function allCoupons()
    {
        if (!self::isPluginInstalled()) {
            return Response::error(__('Power Coupons for WooCommerce is not active.', 'bit-pi'));
        }

        $posts = get_posts(
            [
                'post_type'              => 'shop_coupon',
                'post_status'            => ['publish', 'draft', 'pending', 'private'],
                'posts_per_page'         => -1,
                'orderby'                => 'title',
                'order'                  => 'ASC',
                'no_found_rows'          => true,
                'ignore_sticky_posts'    => true,
                'update_post_meta_cache' => false,
                'update_post_term_cache' => false,
            ]
        );

        $options = array_map(
            static function ($post) {
                return [
                    // translators: %d: WooCommerce coupon post ID.
                    'label' => $post->post_title ?: \sprintf(__('Coupon #%d', 'bit-pi'), $post->ID),
                    'value' => $post->ID,
                ];
            },
            $posts
        );

        return Response::success($options);
    }

    public static function allCouponCodes()
    {
        if (!self::isPluginInstalled()) {
            return Response::error(__('Power Coupons for WooCommerce is not active.', 'bit-pi'));
        }

        $posts = get_posts(
            [
                'post_type'              => 'shop_coupon',
                'post_status'            => 'publish',
                'posts_per_page'         => -1,
                'orderby'                => 'title',
                'order'                  => 'ASC',
                'no_found_rows'          => true,
                'ignore_sticky_posts'    => true,
                'update_post_meta_cache' => false,
                'update_post_term_cache' => false,
            ]
        );

        $options = [];
        foreach ($posts as $post) {
            $code = self::formatCouponCode($post->post_title);
            if (empty($code)) {
                continue;
            }

            $options[] = [
                'label' => $code,
                'value' => $code,
            ];
        }

        return Response::success($options);
    }

    public static function allProducts()
    {
        if (!self::isPluginInstalled() || !\function_exists('wc_get_products')) {
            return Response::error(__('WooCommerce products are not available.', 'bit-pi'));
        }

        $productIds = wc_get_products(
            [
                'limit'   => -1,
                'status'  => ['publish', 'private'],
                'orderby' => 'name',
                'order'   => 'ASC',
                'return'  => 'ids',
            ]
        );

        $options = [];
        foreach (\is_array($productIds) ? $productIds : [] as $productId) {
            $options[] = [
                'label' => get_the_title($productId),
                'value' => (int) $productId,
            ];
        }

        return Response::success($options);
    }

    public static function allProductCategories()
    {
        if (!self::isPluginInstalled()) {
            return Response::error(__('WooCommerce product categories are not available.', 'bit-pi'));
        }

        $terms = get_terms(
            [
                'taxonomy'   => 'product_cat',
                'hide_empty' => false,
                'orderby'    => 'name',
                'order'      => 'ASC',
            ]
        );

        if (is_wp_error($terms)) {
            return Response::error($terms->get_error_message());
        }

        $options = array_map(
            static function ($term) {
                return [
                    'label' => $term->name,
                    'value' => $term->term_id,
                ];
            },
            $terms
        );

        return Response::success($options);
    }
}
