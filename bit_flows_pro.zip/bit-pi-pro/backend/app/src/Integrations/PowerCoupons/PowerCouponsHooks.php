<?php

namespace BitApps\PiPro\src\Integrations\PowerCoupons;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!defined('ABSPATH')) {
    exit;
}

class PowerCouponsHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'powerCouponApplied' => [
                'hook'     => 'woocommerce_applied_coupon',
                'callback' => [PowerCouponsTrigger::class, 'powerCouponApplied'],
            ],
            'powerCouponRemoved' => [
                'hook'     => 'woocommerce_removed_coupon',
                'callback' => [PowerCouponsTrigger::class, 'powerCouponRemoved'],
            ],
            'powerCouponRedeemed' => [
                'hook' => [
                    'woocommerce_checkout_order_processed',
                    'woocommerce_store_api_checkout_order_processed',
                ],
                'callback' => [PowerCouponsTrigger::class, 'powerCouponRedeemed'],
            ],
        ];
    }
}
