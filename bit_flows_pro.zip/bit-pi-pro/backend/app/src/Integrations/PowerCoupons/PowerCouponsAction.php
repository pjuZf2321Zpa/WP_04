<?php

namespace BitApps\PiPro\src\Integrations\PowerCoupons;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\Pi\src\Interfaces\ActionInterface;
use BitApps\PiPro\src\Integrations\PowerCoupons\helper\PowerCouponsHelper;

if (!defined('ABSPATH')) {
    exit;
}

class PowerCouponsAction implements ActionInterface
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executePowerCouponsAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'] ?? 200,
            $executedNodeAction['payload'] ?? [],
            $executedNodeAction['response'] ?? []
        );
    }

    private function executePowerCouponsAction(): array
    {
        if (!PowerCouponsHelper::isPluginInstalled()) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('Power Coupons for WooCommerce is not installed or activated.', 'bit-pi'),
            ];
        }

        $machineSlug = $this->nodeInfoProvider->getMachineSlug();

        if (empty($machineSlug)) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('Power Coupons action is required.', 'bit-pi'),
            ];
        }

        $serviceInstance = IntegrationHelper::getServiceInstanceByMachineSlug(
            $machineSlug,
            $this->nodeInfoProvider
        );

        if (!$serviceInstance) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('Power Coupons service not found for the given machine slug.', 'bit-pi'),
            ];
        }

        return $serviceInstance->{$machineSlug}();
    }
}
