<?php

namespace BitApps\PiPro\src\Integrations\PowerCoupons\Services;

use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\PowerCoupons\helper\PowerCouponsHelper;
use WC_Coupon;
use WP_Query;

if (!defined('ABSPATH')) {
    exit;
}

final class CouponService extends BaseService
{
    private const ALLOWED_COUPON_STATUSES = [
        'any'     => true,
        'publish' => true,
        'draft'   => true,
        'pending' => true,
        'private' => true,
        'trash'   => true,
    ];

    private const ORDER_BY_MAP = [
        'date'     => 'date',
        'modified' => 'modified',
        'title'    => 'title',
        'id'       => 'ID',
    ];

    private const ALLOWED_SORT_ORDERS = ['ASC' => true, 'DESC' => true];

    private const BOOLEAN_SETTERS = [
        'free_shipping'      => 'set_free_shipping',
        'individual_use'     => 'set_individual_use',
        'exclude_sale_items' => 'set_exclude_sale_items',
    ];

    private const DECIMAL_SETTERS = [
        'minimum_amount' => 'set_minimum_amount',
        'maximum_amount' => 'set_maximum_amount',
    ];

    private const INTEGER_SETTERS = [
        'usage_limit'          => 'set_usage_limit',
        'usage_limit_per_user' => 'set_usage_limit_per_user',
    ];

    private const LIST_SETTERS = [
        'product_ids'                 => 'set_product_ids',
        'excluded_product_ids'        => 'set_excluded_product_ids',
        'product_categories'          => 'set_product_categories',
        'excluded_product_categories' => 'set_excluded_product_categories',
    ];

    private const POWER_COUPON_META_FIELDS = [
        'auto_apply'       => '_power_coupon_auto_apply',
        'show_in_slideout' => '_power_coupon_show_in_slideout',
    ];

    public function listCoupons(): array
    {
        $fieldMappings = $this->getFieldMappings();
        $couponStatus = strtolower(trim((string) ($fieldMappings['status'] ?? 'any')));

        if (!isset(self::ALLOWED_COUPON_STATUSES[$couponStatus])) {
            return [
                'response'    => __('Invalid coupon status.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        $sortField = strtolower(trim((string) ($fieldMappings['order_by'] ?? 'date')));
        $orderByColumn = self::ORDER_BY_MAP[$sortField] ?? 'date';

        $sortDirection = strtoupper(trim((string) ($fieldMappings['order'] ?? 'DESC')));
        $sortDirection = isset(self::ALLOWED_SORT_ORDERS[$sortDirection]) ? $sortDirection : 'DESC';
        $pageNumber = max(1, absint($fieldMappings['page'] ?? 1));
        $couponsPerPage = min(100, max(1, absint($fieldMappings['per_page'] ?? 20)));

        $couponQueryArguments = [
            'post_type'      => 'shop_coupon',
            'post_status'    => $couponStatus === 'any' ? ['publish', 'draft', 'pending', 'private'] : $couponStatus,
            'posts_per_page' => $couponsPerPage,
            'paged'          => $pageNumber,
            'orderby'        => $orderByColumn,
            'order'          => $sortDirection,
            'ignore_sticky_posts'    => true,
            'update_post_term_cache' => false,
        ];

        $searchTerm = trim(wp_strip_all_tags(wp_check_invalid_utf8((string) ($fieldMappings['search'] ?? ''))));
        if ($searchTerm !== '') {
            $couponQueryArguments['s'] = $searchTerm;
        }

        $couponQuery = new WP_Query($couponQueryArguments);
        $couponSummaries = [];

        foreach ($couponQuery->posts as $couponPost) {
            $coupon = PowerCouponsHelper::getCoupon($couponPost->ID);
            if (!$coupon) {
                continue;
            }

            $couponSummaries[] = $this->buildCouponSummary($coupon);
        }

        return [
            'response' => [
                'coupons'     => $couponSummaries,
                'total'       => (int) $couponQuery->found_posts,
                'total_pages' => (int) $couponQuery->max_num_pages,
                'page'        => $pageNumber,
                'per_page'    => $couponsPerPage,
            ],
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function getCoupon(): array
    {
        $fieldMappings = $this->getFieldMappings();
        $validationRules = [
            'id' => ['required', 'integer'],
        ];
        $validationResult = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationResult)) {
            return $validationResult;
        }

        $coupon = PowerCouponsHelper::getCoupon(absint($fieldMappings['id']));
        if (!$coupon) {
            return [
                'response'    => __('Coupon not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        return [
            'response'    => PowerCouponsHelper::couponData($coupon),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function createCoupon(): array
    {
        $fieldMappings = $this->getFieldMappings();
        $validationRules = [
            'code' => ['required', 'string'],
        ];
        $validationResult = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationResult)) {
            return $validationResult;
        }

        if (!\function_exists('wc_get_coupon_id_by_code')) {
            return [
                'response'    => __('WooCommerce coupon functions are unavailable.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        $couponCode = PowerCouponsHelper::formatCouponCode($fieldMappings['code']);
        if ($couponCode === '') {
            return [
                'response'    => __('Coupon code is required.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        if (wc_get_coupon_id_by_code($couponCode)) {
            return [
                'response'    => __('A coupon with this code already exists.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 422,
            ];
        }

        $fieldMappings['code'] = $couponCode;
        $fieldMappings['discount_type'] = $fieldMappings['discount_type'] ?? 'fixed_cart';
        $fieldMappings['amount'] = $fieldMappings['amount'] ?? 0;

        $coupon = new WC_Coupon();

        $fieldErrorMessage = $this->applyCouponFieldMappings($coupon, $fieldMappings);
        if ($fieldErrorMessage) {
            return [
                'response'    => $fieldErrorMessage,
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        $couponId = $coupon->save();
        if (!$couponId) {
            return [
                'response'    => __('Failed to create coupon.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        $this->savePowerCouponMetadata($couponId, $fieldMappings, true);

        return [
            'response'    => PowerCouponsHelper::couponData($coupon),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function updateCoupon(): array
    {
        $fieldMappings = $this->getFieldMappings();
        $validationRules = [
            'id'                => ['required', 'integer'],
            'clear_start_date'  => ['nullable', 'boolean'],
            'clear_expiry_date' => ['nullable', 'boolean'],
        ];
        $validationResult = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationResult)) {
            return $validationResult;
        }

        $couponId = absint($fieldMappings['id']);
        $coupon = PowerCouponsHelper::getCoupon($couponId);
        if (!$coupon) {
            return [
                'response'    => __('Coupon not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        if (\array_key_exists('code', $fieldMappings)) {
            $couponCode = PowerCouponsHelper::formatCouponCode($fieldMappings['code']);
            if ($couponCode === '') {
                return [
                    'response'    => __('Coupon code cannot be empty.', 'bit-pi'),
                    'payload'     => $fieldMappings,
                    'status_code' => 400,
                ];
            }

            $existingCouponId = wc_get_coupon_id_by_code($couponCode);
            if ($existingCouponId && (int) $existingCouponId !== $couponId) {
                return [
                    'response'    => __('A coupon with this code already exists.', 'bit-pi'),
                    'payload'     => $fieldMappings,
                    'status_code' => 422,
                ];
            }

            $fieldMappings['code'] = $couponCode;
        }

        $fieldErrorMessage = $this->applyCouponFieldMappings($coupon, $fieldMappings);
        if ($fieldErrorMessage) {
            return [
                'response'    => $fieldErrorMessage,
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        $coupon->save();
        $this->savePowerCouponMetadata($couponId, $fieldMappings);

        return [
            'response'    => PowerCouponsHelper::couponData($coupon),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function deleteCoupon(): array
    {
        $fieldMappings = $this->getFieldMappings();
        $validationRules = [
            'id'        => ['required', 'integer'],
            'permanent' => ['nullable', 'boolean'],
        ];
        $validationResult = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationResult)) {
            return $validationResult;
        }

        $couponId = absint($fieldMappings['id']);
        $coupon = PowerCouponsHelper::getCoupon($couponId);
        if (!$coupon) {
            return [
                'response'    => __('Coupon not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        $deletePermanently = $this->toBoolean($fieldMappings['permanent'] ?? false);
        $couponCode = $coupon->get_code();
        $deleteResult = $deletePermanently ? wp_delete_post($couponId, true) : wp_trash_post($couponId);

        if (!$deleteResult) {
            return [
                'response'    => __('Failed to delete coupon.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        return [
            'response' => [
                'id'        => $couponId,
                'code'      => $couponCode,
                'permanent' => $deletePermanently,
                'message'   => $deletePermanently
                    ? __('Coupon permanently deleted.', 'bit-pi')
                    : __('Coupon moved to trash.', 'bit-pi'),
            ],
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function toggleAutoApply(): array
    {
        return $this->updateCouponBooleanMeta(
            '_power_coupon_auto_apply',
            __('Auto-apply status updated.', 'bit-pi')
        );
    }

    public function getCouponShortcode(): array
    {
        $fieldMappings = $this->getFieldMappings();
        $validationRules = [
            'id' => ['required', 'integer'],
        ];
        $validationResult = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationResult)) {
            return $validationResult;
        }

        $couponId = absint($fieldMappings['id']);
        if (get_post_type($couponId) !== 'shop_coupon') {
            return [
                'response'    => __('Coupon not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        return [
            'response'    => ['shortcode' => \sprintf('[power_coupons id=%d]', $couponId)],
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function setCouponSlideoutVisibility(): array
    {
        return $this->updateCouponBooleanMeta(
            '_power_coupon_show_in_slideout',
            __('Coupon slideout visibility updated.', 'bit-pi')
        );
    }

    private function updateCouponBooleanMeta(string $metaKey, string $confirmationMessage): array
    {
        $fieldMappings = $this->getFieldMappings();
        $validationRules = [
            'id'      => ['required', 'integer'],
            'enabled' => ['required', 'boolean'],
        ];
        $validationResult = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationResult)) {
            return $validationResult;
        }

        $couponId = absint($fieldMappings['id']);
        if (get_post_type($couponId) !== 'shop_coupon') {
            return [
                'response'    => __('Coupon not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        $isEnabled = $this->toBoolean($fieldMappings['enabled']);
        update_post_meta($couponId, $metaKey, $isEnabled ? 'yes' : 'no');

        return [
            'response' => [
                'id'      => $couponId,
                'enabled' => $isEnabled,
                'message' => $confirmationMessage,
            ],
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    private function buildCouponSummary(WC_Coupon $coupon): array
    {
        $couponId = $coupon->get_id();
        $couponPost = get_post($couponId);
        $expirationDate = $coupon->get_date_expires();

        return [
            'id'                   => $couponId,
            'code'                 => $coupon->get_code(),
            'description'          => $coupon->get_description(),
            'discount_type'        => $coupon->get_discount_type(),
            'amount'               => (float) $coupon->get_amount(),
            'status'               => $couponPost ? $couponPost->post_status : '',
            'usage_count'          => $coupon->get_usage_count(),
            'usage_limit'          => $coupon->get_usage_limit() ?: 0,
            'usage_limit_per_user' => $coupon->get_usage_limit_per_user() ?: 0,
            'free_shipping'        => $coupon->get_free_shipping(),
            'minimum_amount'       => (float) $coupon->get_minimum_amount(),
            'maximum_amount'       => (float) $coupon->get_maximum_amount(),
            'individual_use'       => $coupon->get_individual_use(),
            'exclude_sale_items'   => $coupon->get_exclude_sale_items(),
            'auto_apply'           => get_post_meta($couponId, '_power_coupon_auto_apply', true) === 'yes',
            'show_in_slideout'     => get_post_meta($couponId, '_power_coupon_show_in_slideout', true) === 'yes',
            'start_date'           => (string) get_post_meta($couponId, '_power_coupon_start_date', true),
            'expiry_date'          => $expirationDate ? $expirationDate->date('Y-m-d') : '',
            'is_power_coupon'      => PowerCouponsHelper::isPowerCoupon($coupon),
            'url_edit'             => admin_url('post.php?post=' . $couponId . '&action=edit'),
        ];
    }

    private function applyCouponFieldMappings(WC_Coupon $coupon, array $fieldMappings): string
    {
        if (\array_key_exists('code', $fieldMappings)) {
            $coupon->set_code((string) $fieldMappings['code']);
        }

        if (\array_key_exists('description', $fieldMappings)) {
            $description = trim(wp_strip_all_tags(wp_check_invalid_utf8((string) $fieldMappings['description'])));
            $coupon->set_description($description);
        }

        if (\array_key_exists('discount_type', $fieldMappings)) {
            $discountType = strtolower(trim((string) $fieldMappings['discount_type']));
            $couponTypes = \function_exists('wc_get_coupon_types') ? wc_get_coupon_types() : [];
            if (!empty($couponTypes) && !isset($couponTypes[$discountType])) {
                return __('Invalid coupon discount type.', 'bit-pi');
            }
            $coupon->set_discount_type($discountType);
        }

        if (\array_key_exists('amount', $fieldMappings)) {
            $coupon->set_amount(wc_format_decimal($fieldMappings['amount']));
        }

        foreach (self::BOOLEAN_SETTERS as $fieldKey => $setterMethod) {
            if (\array_key_exists($fieldKey, $fieldMappings)) {
                $coupon->{$setterMethod}($this->toBoolean($fieldMappings[$fieldKey]));
            }
        }

        foreach (self::DECIMAL_SETTERS as $fieldKey => $setterMethod) {
            if (\array_key_exists($fieldKey, $fieldMappings)) {
                $coupon->{$setterMethod}(wc_format_decimal($fieldMappings[$fieldKey]));
            }
        }

        foreach (self::INTEGER_SETTERS as $fieldKey => $setterMethod) {
            if (\array_key_exists($fieldKey, $fieldMappings)) {
                $coupon->{$setterMethod}(absint($fieldMappings[$fieldKey]));
            }
        }

        foreach (self::LIST_SETTERS as $fieldKey => $setterMethod) {
            if (\array_key_exists($fieldKey, $fieldMappings)) {
                $coupon->{$setterMethod}($this->toIntegerList($fieldMappings[$fieldKey]));
            }
        }

        if (\array_key_exists('email_restrictions', $fieldMappings)) {
            $coupon->set_email_restrictions($this->toStringList($fieldMappings['email_restrictions']));
        }

        $shouldClearExpiryDate = \array_key_exists('clear_expiry_date', $fieldMappings)
            && $this->toBoolean($fieldMappings['clear_expiry_date']);

        if ($shouldClearExpiryDate) {
            $coupon->set_date_expires(null);
        } elseif (\array_key_exists('expiry_date', $fieldMappings)) {
            if (!$this->isValidDate($fieldMappings['expiry_date'])) {
                return __('Expiry date must be a valid date in YYYY-MM-DD format.', 'bit-pi');
            }

            $expiryDate = trim((string) $fieldMappings['expiry_date']);
            $coupon->set_date_expires($expiryDate !== '' ? $expiryDate : null);
        }

        $shouldClearStartDate = \array_key_exists('clear_start_date', $fieldMappings)
            && $this->toBoolean($fieldMappings['clear_start_date']);

        if (
            !$shouldClearStartDate
            && \array_key_exists('start_date', $fieldMappings)
            && !$this->isValidDate($fieldMappings['start_date'])
        ) {
            return __('Start date must be a valid date in YYYY-MM-DD format.', 'bit-pi');
        }

        return '';
    }

    private function savePowerCouponMetadata(
        int $couponId,
        array $fieldMappings,
        bool $isNewCoupon = false
    ): void {
        foreach (self::POWER_COUPON_META_FIELDS as $fieldKey => $metaKey) {
            if ($isNewCoupon || \array_key_exists($fieldKey, $fieldMappings)) {
                $isEnabled = $this->toBoolean($fieldMappings[$fieldKey] ?? false);
                update_post_meta($couponId, $metaKey, $isEnabled ? 'yes' : 'no');
            }
        }

        if (
            \array_key_exists('clear_start_date', $fieldMappings)
            && $this->toBoolean($fieldMappings['clear_start_date'])
        ) {
            delete_post_meta($couponId, '_power_coupon_start_date');
        } elseif (\array_key_exists('start_date', $fieldMappings)) {
            $startDate = trim((string) $fieldMappings['start_date']);
            if ($startDate === '') {
                delete_post_meta($couponId, '_power_coupon_start_date');
            } else {
                update_post_meta($couponId, '_power_coupon_start_date', $startDate);
            }
        }
    }
}
