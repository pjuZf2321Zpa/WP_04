<?php

namespace BitApps\PiPro\src\Integrations\PowerCoupons\Services;

use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\PiPro\Deps\BitApps\WPKit\Helpers\JSON;

if (!defined('ABSPATH')) {
    exit;
}

abstract class BaseService
{
    private const TRUE_VALUES = ['1', 'true', 'yes', 'on'];

    protected NodeInfoProvider $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    protected function getFieldMappings(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        return \is_array($fieldMappings) ? $fieldMappings : [];
    }

    protected function toBoolean($inputValue): bool
    {
        if (\is_bool($inputValue)) {
            return $inputValue;
        }

        if (is_numeric($inputValue)) {
            return (float) $inputValue === 1.0;
        }

        return \in_array(strtolower(trim((string) $inputValue)), self::TRUE_VALUES, true);
    }

    protected function toIntegerList($listInput): array
    {
        $uniqueIntegers = [];
        foreach ($this->parseListInput($listInput) as $listItem) {
            $integerValue = absint($listItem);
            if ($integerValue) {
                $uniqueIntegers[$integerValue] = $integerValue;
            }
        }

        return array_values($uniqueIntegers);
    }

    protected function toStringList($listInput): array
    {
        $uniqueStrings = [];
        foreach ($this->parseListInput($listInput) as $listItem) {
            $stringValue = trim(wp_strip_all_tags(wp_check_invalid_utf8((string) $listItem)));
            if ($stringValue !== '' && $stringValue !== '0') {
                $uniqueStrings[$stringValue] = $stringValue;
            }
        }

        return array_values($uniqueStrings);
    }

    protected function isValidDate($dateValue): bool
    {
        if ($dateValue === null || $dateValue === '') {
            return true;
        }

        $dateValue = trim((string) $dateValue);
        if (!preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $dateValue, $dateParts)) {
            return false;
        }

        return checkdate((int) $dateParts[2], (int) $dateParts[3], (int) $dateParts[1]);
    }

    private function parseListInput($listInput): array
    {
        if (\is_array($listInput)) {
            return $listInput;
        }

        if (!\is_string($listInput)) {
            return [];
        }

        $listInput = trim($listInput);
        if ($listInput === '') {
            return [];
        }

        $decodedValues = JSON::maybeDecode($listInput, true);
        if (\is_array($decodedValues)) {
            return $decodedValues;
        }

        return array_map('trim', explode(',', $listInput));
    }
}
