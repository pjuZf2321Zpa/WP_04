<?php

namespace BitApps\PiPro\src\Integrations\PowerCoupons\Services;

use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\PowerCoupons\helper\PowerCouponsHelper;
use Power_Coupons\Includes\Power_Coupons_Utilities;
use Power_Coupons\Public_Folder\Power_Coupons_Frontend_Rules;
use WP_Query;

if (!defined('ABSPATH')) {
    exit;
}

final class CartService extends BaseService
{
    private const AVAILABLE_COUPON_LIMIT = 50;

    private const AUTO_APPLY_META_KEY = '_power_coupon_auto_apply';

    public function listAvailableCoupons(): array
    {
        $fieldMappings = $this->getFieldMappings();
        $cart = $this->getCart();

        if (!$cart) {
            return [
                'response'    => __('WooCommerce cart is not available.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        $appliedCouponLookup = [];
        foreach ($cart->get_applied_coupons() as $appliedCouponCode) {
            $appliedCouponLookup[PowerCouponsHelper::formatCouponCode($appliedCouponCode)] = true;
        }

        $couponRules = class_exists(Power_Coupons_Frontend_Rules::class)
            ? Power_Coupons_Frontend_Rules::get_instance()
            : null;
        $couponQuery = new WP_Query(
            [
                'post_type'              => 'shop_coupon',
                'post_status'            => 'publish',
                'posts_per_page'         => self::AVAILABLE_COUPON_LIMIT,
                'orderby'                => 'date',
                'order'                  => 'DESC',
                'no_found_rows'          => true,
                'ignore_sticky_posts'    => true,
                'update_post_term_cache' => false,
            ]
        );

        $availableCoupons = [];
        foreach ($couponQuery->posts as $couponPost) {
            $couponId = $couponPost->ID;
            $coupon = PowerCouponsHelper::getCoupon($couponId);
            if (!$coupon) {
                continue;
            }

            $expirationDate = $coupon->get_date_expires();
            $couponDateRange = [
                'expiry_date' => $expirationDate ? $expirationDate->date('Y-m-d') : '',
                'start_date'  => (string) get_post_meta($couponId, '_power_coupon_start_date', true),
            ];

            if (
                Power_Coupons_Utilities::is_coupon_expired($couponDateRange)
                || Power_Coupons_Utilities::is_coupon_not_started($couponDateRange)
            ) {
                continue;
            }

            if (
                $couponRules
                && !$couponRules->is_coupon_valid($couponId)
            ) {
                continue;
            }

            $couponCode = $coupon->get_code();
            $discountAmount = (float) $coupon->get_amount();
            $discountType = $coupon->get_discount_type();
            $availableCoupons[] = [
                'id'                 => $couponId,
                'code'               => $couponCode,
                'description'        => $coupon->get_description(),
                'amount'             => $discountAmount,
                'discount_type'      => $discountType,
                'discount_type_text' => Power_Coupons_Utilities::format_discount_amount($discountAmount, $discountType),
                'auto_apply'         => get_post_meta($couponId, self::AUTO_APPLY_META_KEY, true) === 'yes',
                'is_applied'         => isset($appliedCouponLookup[PowerCouponsHelper::formatCouponCode($couponCode)]),
                'expiry_date'        => $couponDateRange['expiry_date'],
                'start_date'         => $couponDateRange['start_date'],
                'is_power_coupon'    => PowerCouponsHelper::isPowerCoupon($coupon),
            ];
        }

        return [
            'response' => [
                'coupons' => $availableCoupons,
                'total'   => \count($availableCoupons),
            ],
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function getAppliedCoupons(): array
    {
        $fieldMappings = $this->getFieldMappings();
        $cart = $this->getCart();

        if (!$cart) {
            return [
                'response'    => __('WooCommerce cart is not available.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        $appliedCoupons = [];
        foreach ($cart->get_applied_coupons() as $couponCode) {
            $coupon = PowerCouponsHelper::getCoupon($couponCode);
            if (!$coupon) {
                continue;
            }

            $appliedCoupons[] = [
                'id'              => $coupon->get_id(),
                'code'            => $couponCode,
                'discount_amount' => (float) $cart->get_coupon_discount_amount($couponCode),
                'discount_type'   => $coupon->get_discount_type(),
                'is_power_coupon' => PowerCouponsHelper::isPowerCoupon($coupon),
            ];
        }

        return [
            'response' => [
                'coupons'    => $appliedCoupons,
                'total'      => \count($appliedCoupons),
                'cart_total' => (float) $cart->get_total('edit'),
            ],
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function applyCoupon(): array
    {
        $fieldMappings = $this->getFieldMappings();
        $validationRules = [
            'code' => ['required', 'string'],
        ];
        $validationResult = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationResult)) {
            return $validationResult;
        }

        $cart = $this->getCart();
        if (!$cart) {
            return [
                'response'    => __('WooCommerce cart is not available.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        $couponCode = PowerCouponsHelper::formatCouponCode($fieldMappings['code']);
        if ($cart->has_discount($couponCode)) {
            return [
                'response'    => __('Coupon is already applied.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 200,
            ];
        }

        $couponApplied = $cart->apply_coupon($couponCode);
        if (!$couponApplied) {
            $errorNotices = \function_exists('wc_get_notices') ? wc_get_notices('error') : [];
            if (\function_exists('wc_clear_notices')) {
                wc_clear_notices();
            }
            $errorMessage = !empty($errorNotices[0]['notice'])
                ? wp_strip_all_tags($errorNotices[0]['notice'])
                : __('Coupon could not be applied.', 'bit-pi');

            return [
                'response'    => $errorMessage,
                'payload'     => $fieldMappings,
                'status_code' => 422,
            ];
        }

        $cart->calculate_totals();

        return [
            'response'    => __('Coupon applied successfully.', 'bit-pi'),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function removeCoupon(): array
    {
        $fieldMappings = $this->getFieldMappings();
        $validationRules = [
            'code' => ['required', 'string'],
        ];
        $validationResult = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationResult)) {
            return $validationResult;
        }

        $cart = $this->getCart();
        if (!$cart) {
            return [
                'response'    => __('WooCommerce cart is not available.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        $couponCode = PowerCouponsHelper::formatCouponCode($fieldMappings['code']);
        $couponId = \function_exists('wc_get_coupon_id_by_code') ? wc_get_coupon_id_by_code($couponCode) : 0;

        if ($couponId && get_post_meta($couponId, self::AUTO_APPLY_META_KEY, true) === 'yes') {
            return [
                'response'    => __('Auto-applied coupons cannot be removed.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 422,
            ];
        }

        if (!$cart->has_discount($couponCode)) {
            return [
                'response'    => __('Coupon is not applied to the cart.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 422,
            ];
        }

        $couponRemoved = $cart->remove_coupon($couponCode);

        if (!$couponRemoved) {
            return [
                'response'    => __('Coupon could not be removed.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 422,
            ];
        }

        $cart->calculate_totals();

        return [
            'response'    => __('Coupon removed.', 'bit-pi'),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    private function getCart()
    {
        if (!\function_exists('WC')) {
            return;
        }

        $woocommerceInstance = WC();

        return $woocommerceInstance && $woocommerceInstance->cart ? $woocommerceInstance->cart : null;
    }
}
