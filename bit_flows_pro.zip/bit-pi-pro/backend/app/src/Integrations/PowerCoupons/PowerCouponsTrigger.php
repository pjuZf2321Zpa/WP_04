<?php

namespace BitApps\PiPro\src\Integrations\PowerCoupons;

use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\PowerCoupons\helper\PowerCouponsHelper;
use WC_Order;

if (!defined('ABSPATH')) {
    exit;
}

final class PowerCouponsTrigger
{
    public static function powerCouponApplied($couponCode): void
    {
        $coupon = PowerCouponsHelper::getCoupon($couponCode);

        if (!$coupon || !PowerCouponsHelper::isPowerCoupon($coupon)) {
            return;
        }

        $data = PowerCouponsHelper::couponData($coupon);
        $data['event'] = 'applied';
        $data['event_time'] = current_time('mysql');

        self::execute('powerCouponApplied', $data);
    }

    public static function powerCouponRemoved($couponCode): void
    {
        $coupon = PowerCouponsHelper::getCoupon($couponCode);

        if (!$coupon || !PowerCouponsHelper::isPowerCoupon($coupon)) {
            return;
        }

        $data = PowerCouponsHelper::couponData($coupon);
        $data['event'] = 'removed';
        $data['event_time'] = current_time('mysql');

        self::execute('powerCouponRemoved', $data);
    }

    public static function powerCouponRedeemed($order): void
    {
        if (!PowerCouponsHelper::isPluginInstalled()) {
            return;
        }

        $order = $order instanceof WC_Order ? $order : wc_get_order($order);
        if (!$order instanceof WC_Order) {
            return;
        }

        $powerCoupons = [];
        foreach ($order->get_coupon_codes() as $couponCode) {
            $coupon = PowerCouponsHelper::getCoupon($couponCode);

            if ($coupon && PowerCouponsHelper::isPowerCoupon($coupon)) {
                $powerCoupons[] = PowerCouponsHelper::couponData($coupon);
            }
        }

        if (empty($powerCoupons)) {
            return;
        }

        $data = PowerCouponsHelper::orderData($order, $powerCoupons);
        $data['event'] = 'redeemed';
        $data['event_time'] = current_time('mysql');

        self::execute('powerCouponRedeemed', $data);
    }

    private static function execute(string $machineSlug, array $data): void
    {
        $flows = FlowService::exists('powerCoupons', $machineSlug);

        if (!$flows || empty($data)) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $data);
    }
}
