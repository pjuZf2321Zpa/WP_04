<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\PiPro\src\Integrations\PowerCoupons\helper\PowerCouponsHelper;

Route::group(
    static function () {
        Route::get('powerCoupons-core/get-coupons', [PowerCouponsHelper::class, 'allCoupons']);
        Route::get('powerCoupons-core/get-coupon-codes', [PowerCouponsHelper::class, 'allCouponCodes']);
        Route::get('powerCoupons-core/get-products', [PowerCouponsHelper::class, 'allProducts']);
        Route::get('powerCoupons-core/get-product-categories', [PowerCouponsHelper::class, 'allProductCategories']);
    }
)->middleware('nonce:admin');
