<?php

namespace BitApps\PiPro\src\Integrations\B2bking\helper;

use BitApps\Pi\Helpers\Utility;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\PiPro\Deps\BitApps\WPValidator\Validator;

if (!defined('ABSPATH')) {
    exit;
}

final class B2bkingHelper
{
    public static function isPluginInstalled(): bool
    {
        return defined('B2BKINGCORE_VERSION') || class_exists('B2bking_Globalhelpercore');
    }

    public static function getGroupsForSelect()
    {
        if (!self::isPluginInstalled()) {
            return Response::error(__('B2BKing plugin is not active.', 'bit-pi'));
        }

        $posts = get_posts(
            [
                'post_type'   => 'b2bking_group',
                'post_status' => 'publish',
                'numberposts' => -1,
            ]
        );

        $groups = array_map(
            function ($post) {
                return [
                    'label' => $post->post_title,
                    'value' => $post->ID,
                ];
            },
            $posts
        );

        return Response::success($groups);
    }

    public static function getUserData(int|string $userIdOrEmail, bool $isEmail = false): array
    {
        $data = $isEmail ? Utility::getUserDataByField('email', $userIdOrEmail) : Utility::getUserInfo($userIdOrEmail);

        if (empty($data)) {
            return [];
        }

        $userId = $data['user_id'] ?? null;
        $groupId = get_user_meta($userId, 'b2bking_customergroup', true);

        $data['b2bking_group_id'] = $groupId ?: null;
        $data['b2bking_group_name'] = ($groupId && is_numeric($groupId)) ? get_the_title($groupId) : null;
        $data['b2bking_b2buser'] = get_user_meta($userId, 'b2bking_b2buser', true) === 'yes';
        $data['b2bking_approved'] = get_user_meta($userId, 'b2bking_account_approved', true) === 'yes';
        $data['b2bking_account_type'] = get_user_meta($userId, 'b2bking_account_type', true) ?: 'regular';

        $userMeta = get_user_meta($userId);
        $data['metadata'] = \is_array($userMeta) ? array_map(
            function ($metaValue) {
                return \is_array($metaValue) && \count($metaValue) === 1 ? reset($metaValue) : $metaValue;
            },
            $userMeta
        ) : [];

        return $data;
    }

    public static function validateFieldMap(array $validationRules, $payload = null): ?array
    {
        $validator = new Validator();
        $validation = $validator->make($payload, $validationRules);

        if ($validation->fails()) {
            return [
                'response'    => $validation->errors(),
                'payload'     => $payload,
                'status_code' => 422,
            ];
        }

        return null;
    }
}
