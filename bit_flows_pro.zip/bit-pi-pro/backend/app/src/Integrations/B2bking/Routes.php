<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\PiPro\src\Integrations\B2bking\helper\B2bkingHelper;

Route::group(
    function () {
        Route::get('b2bking/groups', [B2bkingHelper::class, 'getGroupsForSelect']);
    }
)->middleware('nonce:admin');
