<?php

namespace BitApps\PiPro\src\Integrations\B2bking;

use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\B2bking\helper\B2bkingHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class B2bkingTrigger
{
    public static function accountApproved($emailAddress)
    {
        $userData = B2bkingHelper::getUserData($emailAddress, true);

        if (!$userData) {
            return;
        }

        return self::execute('accountApproved', $userData);
    }

    public static function userGroupUpdated($userId, $newGroupId, $oldGroupId)
    {
        $data = [
            'new_group_id'   => $newGroupId,
            'new_group_name' => $newGroupId ? get_the_title($newGroupId) : null,
            'old_group_id'   => $oldGroupId,
            'old_group_name' => $oldGroupId ? get_the_title($oldGroupId) : null,
            'user_data'      => B2bkingHelper::getUserData($userId),
        ];

        return self::execute('userGroupUpdated', $data);
    }

    public static function newMessage($email, $message, $senderId, $postId)
    {
        $sender = B2bkingHelper::getUserData($senderId);

        $data = [
            'recipient_email'      => $email,
            'message'              => $message,
            'sender_id'            => $senderId,
            'sender_email'         => $sender['user_email'] ?? null,
            'sender_name'          => $sender['display_name'] ?? null,
            'conversation_post_id' => $postId,
            'sender'               => $sender,
        ];

        return self::execute('newMessage', $data);
    }

    private static function execute(string $machineSlug, array $data)
    {
        if (empty($data)) {
            return;
        }

        $flows = FlowService::exists('b2bking', $machineSlug);

        if (!$flows) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $data);
    }
}
