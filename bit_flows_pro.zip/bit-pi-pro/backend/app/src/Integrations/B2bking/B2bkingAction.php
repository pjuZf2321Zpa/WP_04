<?php

namespace BitApps\PiPro\src\Integrations\B2bking;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;
use BitApps\PiPro\src\Integrations\B2bking\helper\B2bkingHelper;

if (!\defined('ABSPATH')) {
    exit;
}

class B2bkingAction implements ActionInterface
{
    private NodeInfoProvider $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $result = $this->executeB2bkingAction();

        return Utility::formatResponseData(
            $result['status_code'] ?? 200,
            $result['payload'] ?? [],
            $result['response'] ?? []
        );
    }

    private function executeB2bkingAction(): array
    {
        if (!B2bkingHelper::isPluginInstalled()) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('B2BKing plugin is not active.', 'bit-pi'),
            ];
        }

        $service = new B2bkingService($this->nodeInfoProvider);
        $machineSlug = $this->nodeInfoProvider->getMachineSlug();

        if (!method_exists($service, $machineSlug)) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('B2BKing action not found.', 'bit-pi'),
            ];
        }

        return $service->{$machineSlug}();
    }
}
