<?php

namespace BitApps\PiPro\src\Integrations\B2bking;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!defined('ABSPATH')) {
    exit;
}

class B2bkingHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'accountApproved' => [
                'hook'     => 'b2bking_account_approved_finish',
                'callback' => [B2bkingTrigger::class, 'accountApproved'],
            ],
            'userGroupUpdated' => [
                'hook'          => 'b2bking_user_group_updated',
                'callback'      => [B2bkingTrigger::class, 'userGroupUpdated'],
                'accepted_args' => 3,
            ],
            'newMessage' => [
                'hook'          => 'b2bking_new_message',
                'callback'      => [B2bkingTrigger::class, 'newMessage'],
                'accepted_args' => 4,
            ],
        ];
    }
}
