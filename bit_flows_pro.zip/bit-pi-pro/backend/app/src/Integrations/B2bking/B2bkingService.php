<?php

namespace BitApps\PiPro\src\Integrations\B2bking;

use B2bking_Globalhelpercore;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\PiPro\Deps\BitApps\WPKit\Hooks\Hooks;
use BitApps\PiPro\src\Integrations\B2bking\helper\B2bkingHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class B2bkingService
{
    private NodeInfoProvider $nodeInfoProvider;

    private array $fieldMappings = [];

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
        $this->fieldMappings = $this->nodeInfoProvider->getFieldMapData();
    }

    public function updateCustomerGroup(): array
    {
        if (!class_exists('B2bking_Globalhelpercore')) {
            return [
                'response'    => __('B2bking_Globalhelpercore class not found.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 400,
            ];
        }

        $rules = [
            'user_email' => ['required', 'email'],
            'group_id'   => ['required']
        ];

        $validationError = B2bkingHelper::validateFieldMap($rules, $this->fieldMappings);
        if ($validationError) {
            return $validationError;
        }

        $userId = $this->findUserId();
        if ($userId === null) {
            return [
                'response'    => __('User not found with the provided email.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 404,
            ];
        }

        B2bking_Globalhelpercore::update_user_group($userId, absint($this->fieldMappings['group_id']));

        return [
            'response'    => __('Customer group updated successfully.', 'bit-pi'),
            'payload'     => $this->fieldMappings,
            'status_code' => 200,
        ];
    }

    public function approveCustomer(): array
    {
        $validationError = $this->validateUserEmail();
        if ($validationError) {
            return $validationError;
        }

        $userId = $this->findUserId();
        if ($userId === null) {
            return [
                'response'    => __('User not found with the provided email.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 404,
            ];
        }

        update_user_meta($userId, 'b2bking_account_approved', 'yes');
        update_user_meta($userId, 'b2bking_b2buser', 'yes');

        Hooks::doAction('b2bking_account_approved_finish', $this->fieldMappings['user_email']);

        return [
            'response'    => __('Customer approved successfully.', 'bit-pi'),
            'payload'     => $this->fieldMappings,
            'status_code' => 200,
        ];
    }

    public function enableB2bForUser(): array
    {
        $validationError = $this->validateUserEmail();
        if ($validationError) {
            return $validationError;
        }

        $userId = $this->findUserId();
        if ($userId === null) {
            return [
                'response'    => __('User not found with the provided email.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 404,
            ];
        }

        update_user_meta($userId, 'b2bking_b2buser', 'yes');

        return [
            'response'    => __('B2B enabled for user successfully.', 'bit-pi'),
            'payload'     => $this->fieldMappings,
            'status_code' => 200,
        ];
    }

    public function getCustomerInfo(): array
    {
        $validationError = $this->validateUserEmail();
        if ($validationError) {
            return $validationError;
        }

        $userData = B2bkingHelper::getUserData($this->fieldMappings['user_email'], true);

        if (!$userData) {
            return [
                'response'    => __('User not found with the provided email.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 404,
            ];
        }

        return [
            'response'    => $userData,
            'payload'     => $this->fieldMappings,
            'status_code' => 200,
        ];
    }

    public function getAllGroups(): array
    {
        $groups = get_posts(
            [
                'post_type'   => 'b2bking_group',
                'post_status' => 'publish',
                'numberposts' => -1,
            ]
        );

        return [
            'response'    => $groups,
            'payload'     => [],
            'status_code' => 200,
        ];
    }

    private function validateUserEmail(): ?array
    {
        $rules = ['user_email' => ['required', 'email']];

        return B2bkingHelper::validateFieldMap($rules, $this->fieldMappings);
    }

    private function findUserId(): ?int
    {
        $user = get_user_by('email', $this->fieldMappings['user_email']);

        return $user ? $user->ID : null;
    }
}
