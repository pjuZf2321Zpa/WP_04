<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\PiPro\src\Integrations\ElementsKit\helper\ElementsKitHelper;

Route::group(
    function () {
        Route::get('elements-kit/templates', [ElementsKitHelper::class, 'getTemplates']);
        Route::get('elements-kit/widgets', [ElementsKitHelper::class, 'getWidgets']);
        Route::get('elements-kit/contents', [ElementsKitHelper::class, 'getContents']);
    }
)->middleware('nonce:admin');
