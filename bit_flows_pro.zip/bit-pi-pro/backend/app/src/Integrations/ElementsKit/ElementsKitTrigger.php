<?php

namespace BitApps\PiPro\src\Integrations\ElementsKit;

use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\ElementsKit\helper\ElementsKitHelper;
use WP_Post;

if (!defined('ABSPATH')) {
    exit;
}

final class ElementsKitTrigger
{
    public static function templateCreated($postId, $post, $update): void
    {
        if ($update || !self::isSavableEvent($post, ElementsKitHelper::TEMPLATE_POST_TYPE)) {
            return;
        }

        self::execute('templateCreated', ElementsKitHelper::getTemplateData((int) $postId, $post));
    }

    public static function templateUpdated($postId, $post, $update): void
    {
        if (!$update || !self::isSavableEvent($post, ElementsKitHelper::TEMPLATE_POST_TYPE)) {
            return;
        }

        self::execute('templateUpdated', ElementsKitHelper::getTemplateData((int) $postId, $post));
    }

    public static function templateStatusChanged($newStatus, $oldStatus, $post): void
    {
        if (
            $newStatus === $oldStatus
            || $newStatus === 'auto-draft'
            || $oldStatus === 'new'
            || !ElementsKitHelper::isPostOfType($post, ElementsKitHelper::TEMPLATE_POST_TYPE)
        ) {
            return;
        }

        $data = array_merge(
            ElementsKitHelper::getTemplateData((int) $post->ID, $post),
            [
                'old_status' => $oldStatus,
                'new_status' => $newStatus,
            ]
        );

        self::execute('templateStatusChanged', $data);
    }

    public static function templateTrashed($postId): void
    {
        self::executeForPost('templateTrashed', $postId, ElementsKitHelper::TEMPLATE_POST_TYPE);
    }

    public static function templateDeleted($postId, $post = null): void
    {
        self::executeForPost('templateDeleted', $postId, ElementsKitHelper::TEMPLATE_POST_TYPE, $post);
    }

    public static function widgetCreated($postId, $post, $update): void
    {
        if ($update || !self::isSavableEvent($post, ElementsKitHelper::WIDGET_POST_TYPE)) {
            return;
        }

        self::execute('widgetCreated', ElementsKitHelper::getWidgetData((int) $postId, $post));
    }

    public static function widgetUpdated($postId, $post, $update): void
    {
        if (!$update || !self::isSavableEvent($post, ElementsKitHelper::WIDGET_POST_TYPE)) {
            return;
        }

        self::execute('widgetUpdated', ElementsKitHelper::getWidgetData((int) $postId, $post));
    }

    public static function widgetTrashed($postId): void
    {
        self::executeForPost('widgetTrashed', $postId, ElementsKitHelper::WIDGET_POST_TYPE);
    }

    public static function widgetDeleted($postId, $post = null): void
    {
        self::executeForPost('widgetDeleted', $postId, ElementsKitHelper::WIDGET_POST_TYPE, $post);
    }

    public static function contentCreated($postId, $post, $update): void
    {
        if ($update || !self::isSavableEvent($post, ElementsKitHelper::CONTENT_POST_TYPE)) {
            return;
        }

        self::execute('contentCreated', ElementsKitHelper::getContentData((int) $postId, $post));
    }

    public static function contentUpdated($postId, $post, $update): void
    {
        if (!$update || !self::isSavableEvent($post, ElementsKitHelper::CONTENT_POST_TYPE)) {
            return;
        }

        self::execute('contentUpdated', ElementsKitHelper::getContentData((int) $postId, $post));
    }

    public static function contentTrashed($postId): void
    {
        self::executeForPost('contentTrashed', $postId, ElementsKitHelper::CONTENT_POST_TYPE);
    }

    public static function contentDeleted($postId, $post = null): void
    {
        self::executeForPost('contentDeleted', $postId, ElementsKitHelper::CONTENT_POST_TYPE, $post);
    }

    /**
     * `save_post_{type}` also fires for the empty `auto-draft` WordPress creates when
     * "Add New" is clicked, and during an autosave pass. Neither is a real authoring
     * event, so both are filtered out before a flow is dispatched.
     *
     * @param mixed $post
     */
    private static function isSavableEvent($post, string $postType): bool
    {
        if (!ElementsKitHelper::isPostOfType($post, $postType)) {
            return false;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return false;
        }

        return $post->post_status !== 'auto-draft';
    }

    /**
     * Shared trash/delete path for the three ElementsKit CPTs.
     *
     * @param int|string $postId
     * @param null|mixed $post
     */
    private static function executeForPost(string $machineSlug, $postId, string $postType, $post = null): void
    {
        $post = $post instanceof WP_Post ? $post : get_post($postId);

        if (!ElementsKitHelper::isPostOfType($post, $postType)) {
            return;
        }

        $postId = (int) $postId;

        if ($postType === ElementsKitHelper::TEMPLATE_POST_TYPE) {
            $data = ElementsKitHelper::getTemplateData($postId, $post);
        } elseif ($postType === ElementsKitHelper::WIDGET_POST_TYPE) {
            $data = ElementsKitHelper::getWidgetData($postId, $post);
        } else {
            $data = ElementsKitHelper::getContentData($postId, $post);
        }

        self::execute($machineSlug, $data);
    }

    private static function execute(string $machineSlug, array $data): void
    {
        if (!ElementsKitHelper::isPluginInstalled()) {
            return;
        }

        $flows = FlowService::exists('elementsKit', $machineSlug);

        if (!$flows || empty($data)) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $data);
    }
}
