<?php

namespace BitApps\PiPro\src\Integrations\ElementsKit;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!defined('ABSPATH')) {
    exit;
}

class ElementsKitHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'templateCreated' => [
                'hook'          => 'save_post_elementskit_template',
                'callback'      => [ElementsKitTrigger::class, 'templateCreated'],
                'accepted_args' => 3,
            ],
            'templateUpdated' => [
                'hook'          => 'save_post_elementskit_template',
                'callback'      => [ElementsKitTrigger::class, 'templateUpdated'],
                'accepted_args' => 3,
            ],
            'templateStatusChanged' => [
                'hook'          => 'transition_post_status',
                'callback'      => [ElementsKitTrigger::class, 'templateStatusChanged'],
                'accepted_args' => 3,
            ],
            'templateTrashed' => [
                'hook'     => 'wp_trash_post',
                'callback' => [ElementsKitTrigger::class, 'templateTrashed'],
            ],
            'templateDeleted' => [
                'hook'          => 'before_delete_post',
                'callback'      => [ElementsKitTrigger::class, 'templateDeleted'],
                'accepted_args' => 2,
            ],
            'widgetCreated' => [
                'hook'          => 'save_post_elementskit_widget',
                'callback'      => [ElementsKitTrigger::class, 'widgetCreated'],
                'accepted_args' => 3,
            ],
            'widgetUpdated' => [
                'hook'          => 'save_post_elementskit_widget',
                'callback'      => [ElementsKitTrigger::class, 'widgetUpdated'],
                'accepted_args' => 3,
            ],
            'widgetTrashed' => [
                'hook'     => 'wp_trash_post',
                'callback' => [ElementsKitTrigger::class, 'widgetTrashed'],
            ],
            'widgetDeleted' => [
                'hook'          => 'before_delete_post',
                'callback'      => [ElementsKitTrigger::class, 'widgetDeleted'],
                'accepted_args' => 2,
            ],
            'contentCreated' => [
                'hook'          => 'save_post_elementskit_content',
                'callback'      => [ElementsKitTrigger::class, 'contentCreated'],
                'accepted_args' => 3,
            ],
            'contentUpdated' => [
                'hook'          => 'save_post_elementskit_content',
                'callback'      => [ElementsKitTrigger::class, 'contentUpdated'],
                'accepted_args' => 3,
            ],
            'contentTrashed' => [
                'hook'     => 'wp_trash_post',
                'callback' => [ElementsKitTrigger::class, 'contentTrashed'],
            ],
            'contentDeleted' => [
                'hook'          => 'before_delete_post',
                'callback'      => [ElementsKitTrigger::class, 'contentDeleted'],
                'accepted_args' => 2,
            ],
        ];
    }
}
