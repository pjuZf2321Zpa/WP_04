<?php

namespace BitApps\PiPro\src\Integrations\ElementsKit\helper;

use BitApps\Pi\Helpers\Utility;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Response;
use WP_Post;

if (!defined('ABSPATH')) {
    exit;
}

final class ElementsKitHelper
{
    public const TEMPLATE_POST_TYPE = 'elementskit_template';

    public const WIDGET_POST_TYPE = 'elementskit_widget';

    public const CONTENT_POST_TYPE = 'elementskit_content';


    public const TEMPLATE_TYPE_META = 'elementskit_template_type';

    public const TEMPLATE_ACTIVATION_META = 'elementskit_template_activation';

    public const TEMPLATE_CONDITION_META = 'elementskit_template_condition_a';

    public const TEMPLATE_CONDITION_SINGULAR_META = 'elementskit_template_condition_singular';

    public const TEMPLATE_CONDITION_SINGULAR_ID_META = 'elementskit_template_condition_singular_id';

    public const WIDGET_DATA_META = 'elementskit_custom_widget_data';

    public const PAGE_TEMPLATE_META = '_wp_page_template';

    public const EDIT_MODE_META = '_elementor_edit_mode';

    /**
     * Elementor keeps the whole serialized document in these keys. They can run to
     * hundreds of kilobytes per template, so they are kept out of the trigger meta
     * bag — the curated top-level keys carry everything a flow actually maps.
     */
    public const EXCLUDED_META_KEYS = ['_elementor_data', '_elementor_css', '_elementor_page_assets', '_elementor_controls_usage'];

    /**
     * ElementsKit Lite has no version constant, so the god class is the marker.
     */
    public static function isPluginInstalled(): bool
    {
        return class_exists('ElementsKit_Lite\Plugin');
    }

    public static function isPostOfType($post, string $postType): bool
    {
        if (!$post instanceof WP_Post) {
            return false;
        }

        return $post->post_type === $postType;
    }

    public static function getTemplateData(int $postId, $post = null): array
    {
        $post = $post instanceof WP_Post ? $post : get_post($postId);

        if (!$post) {
            return [];
        }

        return [
            'template_id'           => $post->ID,
            'title'                 => $post->post_title,
            'status'                => $post->post_status,
            'type'                  => get_post_meta($post->ID, self::TEMPLATE_TYPE_META, true),
            'activation'            => get_post_meta($post->ID, self::TEMPLATE_ACTIVATION_META, true),
            'condition'             => get_post_meta($post->ID, self::TEMPLATE_CONDITION_META, true),
            'condition_singular'    => get_post_meta($post->ID, self::TEMPLATE_CONDITION_SINGULAR_META, true),
            'condition_singular_id' => get_post_meta($post->ID, self::TEMPLATE_CONDITION_SINGULAR_ID_META, true),
            'author'                => Utility::getUserInfo($post->post_author),
            'created_at'            => $post->post_date,
            'updated_at'            => $post->post_modified,
            'edit_url'              => self::getElementorEditUrl($post->ID),
            'meta'                  => self::getFilteredMeta($post->ID),
        ];
    }

    public static function getWidgetData(int $postId, $post = null): array
    {
        $post = $post instanceof WP_Post ? $post : get_post($postId);

        if (!$post) {
            return [];
        }

        return [
            'widget_id'   => $post->ID,
            'title'       => $post->post_title,
            'status'      => $post->post_status,
            'widget_data' => Utility::normalizeData(get_post_meta($post->ID, self::WIDGET_DATA_META, true)),
            'author'      => Utility::getUserInfo($post->post_author),
            'created_at'  => $post->post_date,
            'updated_at'  => $post->post_modified,
            'edit_url'    => self::getElementorEditUrl($post->ID),
            'meta'        => self::getFilteredMeta($post->ID),
        ];
    }

    public static function getContentData(int $postId, $post = null): array
    {
        $post = $post instanceof WP_Post ? $post : get_post($postId);

        if (!$post) {
            return [];
        }

        return [
            'content_id' => $post->ID,
            'title'      => $post->post_title,
            'content'    => $post->post_content,
            'status'     => $post->post_status,
            'parent_id'  => (int) $post->post_parent,
            'permalink'  => get_permalink($post),
            'author'     => Utility::getUserInfo($post->post_author),
            'created_at' => $post->post_date,
            'updated_at' => $post->post_modified,
            'edit_url'   => self::getElementorEditUrl($post->ID),
            'meta'       => self::getFilteredMeta($post->ID),
        ];
    }

    public static function getElementorEditUrl(int $postId): string
    {
        return add_query_arg(['post' => $postId, 'action' => 'elementor'], admin_url('post.php'));
    }

    public static function getFilteredMeta(int $postId): array
    {
        $meta = Utility::getPostMetadata($postId);

        if (!\is_array($meta)) {
            return [];
        }

        return array_diff_key($meta, array_flip(self::EXCLUDED_META_KEYS));
    }

    /**
     * Every post of the given ElementsKit CPT.
     *
     * @return WP_Post[]
     */
    public static function getPostsOfType(string $postType): array
    {
        return get_posts(
            [
                'post_type'              => $postType,
                'post_status'            => ['publish', 'draft', 'pending', 'future', 'private'],
                'posts_per_page'         => -1,
                'orderby'                => 'title',
                'order'                  => 'ASC',
                'no_found_rows'          => true,
                'ignore_sticky_posts'    => true,
                'update_post_meta_cache' => false,
                'update_post_term_cache' => false,
            ]
        );
    }

    /**
     * Template select options.
     *
     * @return array|Response
     */
    public static function getTemplates()
    {
        return self::buildPostOptions(self::TEMPLATE_POST_TYPE, __('Untitled Template', 'bit-pi'));
    }

    /**
     * Widget select options.
     *
     * @return array|Response
     */
    public static function getWidgets()
    {
        return self::buildPostOptions(self::WIDGET_POST_TYPE, __('Untitled Widget', 'bit-pi'));
    }

    /**
     * Dynamic content select options.
     *
     * @return array|Response
     */
    public static function getContents()
    {
        return self::buildPostOptions(self::CONTENT_POST_TYPE, __('Untitled Item', 'bit-pi'));
    }

    public static function normalizeStatus($status): string
    {
        return \in_array($status, ['publish', 'draft', 'pending', 'private', 'future'], true) ? $status : 'publish';
    }

    public static function normalizeTemplateType($type): string
    {
        return \in_array($type, ['header', 'footer', 'section'], true) ? $type : 'section';
    }

    public static function normalizeActivation($activation): string
    {
        return \in_array($activation, ['yes', true, 'true', 1, '1'], true) ? 'yes' : 'no';
    }

    /**
     * Label/value options for one ElementsKit CPT.
     *
     * @return array|Response
     */
    private static function buildPostOptions(string $postType, string $fallbackLabel)
    {
        if (!self::isPluginInstalled()) {
            return Response::error(__('ElementsKit Lite plugin is not active.', 'bit-pi'));
        }

        $options = array_map(
            static function ($post) use ($fallbackLabel) {
                return [
                    'label' => ($post->post_title ?: $fallbackLabel) . ' (#' . $post->ID . ')',
                    'value' => $post->ID,
                ];
            },
            self::getPostsOfType($postType)
        );

        return Response::success($options);
    }
}
