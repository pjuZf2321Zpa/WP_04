<?php

namespace BitApps\PiPro\src\Integrations\ElementsKit\Services;

use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\ElementsKit\helper\ElementsKitHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class TemplateService extends BaseService
{
    public function createTemplate(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'title' => ['required', 'string'],
            'type'  => ['required', 'string'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $templateId = wp_insert_post(
            [
                'post_title'  => $fieldMappings['title'],
                'post_type'   => ElementsKitHelper::TEMPLATE_POST_TYPE,
                'post_status' => ElementsKitHelper::normalizeStatus($fieldMappings['status'] ?? 'publish'),
                'post_author' => get_current_user_id(),
            ],
            true
        );

        if (is_wp_error($templateId)) {
            return [
                'response'    => $templateId->get_error_message(),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        $templateId = (int) $templateId;

        $this->seedElementorMeta($templateId);
        $this->writeTemplateMeta($templateId, $fieldMappings, true);

        return [
            'response'    => ElementsKitHelper::getTemplateData($templateId),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function updateTemplate(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = ['template_id' => ['required', 'integer']];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $templateId = (int) $fieldMappings['template_id'];

        $notFound = $this->validatePostExists(
            $templateId,
            ElementsKitHelper::TEMPLATE_POST_TYPE,
            $fieldMappings,
            __('ElementsKit template not found.', 'bit-pi')
        );

        if (!empty($notFound)) {
            return $notFound;
        }

        $postData = ['ID' => $templateId];

        if (!empty($fieldMappings['title'])) {
            $postData['post_title'] = $fieldMappings['title'];
        }

        if (!empty($fieldMappings['status'])) {
            $postData['post_status'] = ElementsKitHelper::normalizeStatus($fieldMappings['status']);
        }

        $metaKeys = ['type', 'activation', 'condition', 'condition_singular', 'condition_singular_id'];
        $hasMetaChange = \count(
            array_filter(
                $metaKeys,
                function ($key) use ($fieldMappings) {
                    return $this->isProvided($fieldMappings, $key);
                }
            )
        ) > 0;

        if (\count($postData) <= 1 && !$hasMetaChange) {
            return [
                'response'    => __('No fields to update.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        if (\count($postData) > 1) {
            $updated = wp_update_post($postData, true);

            if (is_wp_error($updated)) {
                return [
                    'response'    => $updated->get_error_message(),
                    'payload'     => $fieldMappings,
                    'status_code' => 400,
                ];
            }
        }

        $this->writeTemplateMeta($templateId, $fieldMappings, false);

        return [
            'response'    => ElementsKitHelper::getTemplateData($templateId),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function updateTemplateActivation(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'template_id' => ['required', 'integer'],
            'activation'  => ['required', 'string'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $templateId = (int) $fieldMappings['template_id'];

        $notFound = $this->validatePostExists(
            $templateId,
            ElementsKitHelper::TEMPLATE_POST_TYPE,
            $fieldMappings,
            __('ElementsKit template not found.', 'bit-pi')
        );

        if (!empty($notFound)) {
            return $notFound;
        }

        update_post_meta(
            $templateId,
            ElementsKitHelper::TEMPLATE_ACTIVATION_META,
            ElementsKitHelper::normalizeActivation($fieldMappings['activation'])
        );

        return [
            'response'    => ElementsKitHelper::getTemplateData($templateId),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function getTemplate(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = ['template_id' => ['required', 'integer']];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $templateId = (int) $fieldMappings['template_id'];

        $notFound = $this->validatePostExists(
            $templateId,
            ElementsKitHelper::TEMPLATE_POST_TYPE,
            $fieldMappings,
            __('ElementsKit template not found.', 'bit-pi')
        );

        if (!empty($notFound)) {
            return $notFound;
        }

        return [
            'response'    => ElementsKitHelper::getTemplateData($templateId),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function getAllTemplates(): array
    {
        $response = array_map(
            static function ($template) {
                return ElementsKitHelper::getTemplateData((int) $template->ID, $template);
            },
            ElementsKitHelper::getPostsOfType(ElementsKitHelper::TEMPLATE_POST_TYPE)
        );

        return [
            'response'    => $response,
            'payload'     => [],
            'status_code' => 200,
        ];
    }

    public function deleteTemplate(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = ['template_id' => ['required', 'integer']];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $templateId = (int) $fieldMappings['template_id'];

        $notFound = $this->validatePostExists(
            $templateId,
            ElementsKitHelper::TEMPLATE_POST_TYPE,
            $fieldMappings,
            __('ElementsKit template not found.', 'bit-pi')
        );

        if (!empty($notFound)) {
            return $notFound;
        }

        return $this->deleteRecord(
            $templateId,
            $fieldMappings,
            __('Failed to delete the ElementsKit template.', 'bit-pi'),
            __('ElementsKit template deleted successfully.', 'bit-pi')
        );
    }

    /**
     * Write the ElementsKit display meta. On create every key is stamped so the
     * template matches what the plugin's own editor writes; on update only the
     * supplied keys are touched so untouched conditions survive.
     */
    private function writeTemplateMeta(int $templateId, array $fieldMappings, bool $isCreate): void
    {
        $hasType = $this->isProvided($fieldMappings, 'type');

        $type = $hasType
            ? ElementsKitHelper::normalizeTemplateType($fieldMappings['type'])
            : get_post_meta($templateId, ElementsKitHelper::TEMPLATE_TYPE_META, true);

        if ($isCreate || $hasType) {
            update_post_meta($templateId, ElementsKitHelper::TEMPLATE_TYPE_META, $type);
        }

        if ($isCreate || $this->isProvided($fieldMappings, 'activation')) {
            update_post_meta(
                $templateId,
                ElementsKitHelper::TEMPLATE_ACTIVATION_META,
                ElementsKitHelper::normalizeActivation($fieldMappings['activation'] ?? 'no')
            );
        }

        // A "section" template renders on demand, so it never carries display conditions.
        $isSection = $type === 'section';

        $conditionMap = [
            ElementsKitHelper::TEMPLATE_CONDITION_META             => 'condition',
            ElementsKitHelper::TEMPLATE_CONDITION_SINGULAR_META    => 'condition_singular',
            ElementsKitHelper::TEMPLATE_CONDITION_SINGULAR_ID_META => 'condition_singular_id',
        ];

        foreach ($conditionMap as $metaKey => $fieldKey) {
            if (!$isCreate && !$this->isProvided($fieldMappings, $fieldKey)) {
                continue;
            }

            update_post_meta($templateId, $metaKey, $isSection ? '' : ($fieldMappings[$fieldKey] ?? ''));
        }
    }

    /**
     * The update machine offers a "Keep Current" choice that submits an empty
     * string, so an empty value means "not supplied" rather than "clear it".
     */
    private function isProvided(array $fieldMappings, string $key): bool
    {
        return isset($fieldMappings[$key]) && $fieldMappings[$key] !== '';
    }
}
