<?php

namespace BitApps\PiPro\src\Integrations\ElementsKit\Services;

use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\ElementsKit\helper\ElementsKitHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class DynamicContentService extends BaseService
{
    public function createContent(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = ['title' => ['required', 'string']];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $invalidParent = $this->validateParent($fieldMappings, 0);

        if (!empty($invalidParent)) {
            return $invalidParent;
        }

        $contentId = wp_insert_post(
            [
                'post_title'   => $fieldMappings['title'],
                'post_content' => $fieldMappings['content'] ?? '',
                'post_type'    => ElementsKitHelper::CONTENT_POST_TYPE,
                'post_status'  => ElementsKitHelper::normalizeStatus($fieldMappings['status'] ?? 'publish'),
                'post_parent'  => (int) ($fieldMappings['parent_id'] ?? 0),
                'post_author'  => get_current_user_id(),
            ],
            true
        );

        if (is_wp_error($contentId)) {
            return [
                'response'    => $contentId->get_error_message(),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        $contentId = (int) $contentId;

        $this->seedElementorMeta($contentId);

        return [
            'response'    => ElementsKitHelper::getContentData($contentId),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function updateContent(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = ['content_id' => ['required', 'integer']];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $contentId = (int) $fieldMappings['content_id'];

        $notFound = $this->validatePostExists(
            $contentId,
            ElementsKitHelper::CONTENT_POST_TYPE,
            $fieldMappings,
            __('ElementsKit dynamic content item not found.', 'bit-pi')
        );

        if (!empty($notFound)) {
            return $notFound;
        }

        $invalidParent = $this->validateParent($fieldMappings, $contentId);

        if (!empty($invalidParent)) {
            return $invalidParent;
        }

        $postData = ['ID' => $contentId];

        if (!empty($fieldMappings['title'])) {
            $postData['post_title'] = $fieldMappings['title'];
        }

        if (isset($fieldMappings['content'])) {
            $postData['post_content'] = $fieldMappings['content'];
        }

        if (!empty($fieldMappings['status'])) {
            $postData['post_status'] = ElementsKitHelper::normalizeStatus($fieldMappings['status']);
        }

        if (isset($fieldMappings['parent_id'])) {
            $postData['post_parent'] = (int) $fieldMappings['parent_id'];
        }

        if (\count($postData) <= 1) {
            return [
                'response'    => __('No fields to update.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        $updated = wp_update_post($postData, true);

        if (is_wp_error($updated)) {
            return [
                'response'    => $updated->get_error_message(),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        return [
            'response'    => ElementsKitHelper::getContentData($contentId),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function getContent(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = ['content_id' => ['required', 'integer']];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $contentId = (int) $fieldMappings['content_id'];

        $notFound = $this->validatePostExists(
            $contentId,
            ElementsKitHelper::CONTENT_POST_TYPE,
            $fieldMappings,
            __('ElementsKit dynamic content item not found.', 'bit-pi')
        );

        if (!empty($notFound)) {
            return $notFound;
        }

        return [
            'response'    => ElementsKitHelper::getContentData($contentId),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function getAllContents(): array
    {
        $response = array_map(
            static function ($content) {
                return ElementsKitHelper::getContentData((int) $content->ID, $content);
            },
            ElementsKitHelper::getPostsOfType(ElementsKitHelper::CONTENT_POST_TYPE)
        );

        return [
            'response'    => $response,
            'payload'     => [],
            'status_code' => 200,
        ];
    }

    /**
     * The CPT is hierarchical, and WordPress does not stop a post from becoming its own
     * parent — that produces an ancestor loop. A mapped value can also point at any post,
     * so the parent is confirmed to be a dynamic content item before it is written.
     *
     * @param int $contentId the item being written, or 0 on create
     */
    private function validateParent(array $fieldMappings, int $contentId): ?array
    {
        if (!isset($fieldMappings['parent_id']) || $fieldMappings['parent_id'] === '') {
            return null;
        }

        $parentId = (int) $fieldMappings['parent_id'];

        if ($parentId === 0) {
            return null;
        }

        if ($parentId === $contentId) {
            return [
                'response'    => __('A dynamic content item cannot be its own parent.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 422,
            ];
        }

        if (!ElementsKitHelper::isPostOfType(get_post($parentId), ElementsKitHelper::CONTENT_POST_TYPE)) {
            return [
                'response'    => __('The selected parent is not an ElementsKit dynamic content item.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404,
            ];
        }

        return null;
    }

    public function deleteContent(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = ['content_id' => ['required', 'integer']];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $contentId = (int) $fieldMappings['content_id'];

        $notFound = $this->validatePostExists(
            $contentId,
            ElementsKitHelper::CONTENT_POST_TYPE,
            $fieldMappings,
            __('ElementsKit dynamic content item not found.', 'bit-pi')
        );

        if (!empty($notFound)) {
            return $notFound;
        }

        return $this->deleteRecord(
            $contentId,
            $fieldMappings,
            __('Failed to delete the ElementsKit dynamic content item.', 'bit-pi'),
            __('ElementsKit dynamic content item deleted successfully.', 'bit-pi')
        );
    }
}
