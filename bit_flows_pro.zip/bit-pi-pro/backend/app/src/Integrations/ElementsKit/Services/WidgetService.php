<?php

namespace BitApps\PiPro\src\Integrations\ElementsKit\Services;

use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\ElementsKit\helper\ElementsKitHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class WidgetService extends BaseService
{
    public function getWidget(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = ['widget_id' => ['required', 'integer']];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $widgetId = (int) $fieldMappings['widget_id'];

        $notFound = $this->validatePostExists(
            $widgetId,
            ElementsKitHelper::WIDGET_POST_TYPE,
            $fieldMappings,
            __('ElementsKit widget not found.', 'bit-pi')
        );

        if (!empty($notFound)) {
            return $notFound;
        }

        return [
            'response'    => ElementsKitHelper::getWidgetData($widgetId),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function getAllWidgets(): array
    {
        $response = array_map(
            static function ($widget) {
                return ElementsKitHelper::getWidgetData((int) $widget->ID, $widget);
            },
            ElementsKitHelper::getPostsOfType(ElementsKitHelper::WIDGET_POST_TYPE)
        );

        return [
            'response'    => $response,
            'payload'     => [],
            'status_code' => 200,
        ];
    }

    public function deleteWidget(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = ['widget_id' => ['required', 'integer']];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $widgetId = (int) $fieldMappings['widget_id'];

        $notFound = $this->validatePostExists(
            $widgetId,
            ElementsKitHelper::WIDGET_POST_TYPE,
            $fieldMappings,
            __('ElementsKit widget not found.', 'bit-pi')
        );

        if (!empty($notFound)) {
            return $notFound;
        }

        return $this->deleteRecord(
            $widgetId,
            $fieldMappings,
            __('Failed to delete the ElementsKit widget.', 'bit-pi'),
            __('ElementsKit widget deleted successfully.', 'bit-pi')
        );
    }
}
