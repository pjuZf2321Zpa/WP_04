<?php

namespace BitApps\PiPro\src\Integrations\ElementsKit\Services;

use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\PiPro\src\Integrations\ElementsKit\helper\ElementsKitHelper;

if (!defined('ABSPATH')) {
    exit;
}

abstract class BaseService
{
    protected $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    protected function validatePostExists(int $postId, string $postType, array $payload, string $notFoundMessage): ?array
    {
        $post = get_post($postId);

        if (!ElementsKitHelper::isPostOfType($post, $postType)) {
            return [
                'response'    => $notFoundMessage,
                'payload'     => $payload,
                'status_code' => 404,
            ];
        }

        return null;
    }

    /**
     * ElementsKit CPTs are Elementor documents — the plugin's own writers always
     * stamp these two meta keys, so every created record here does the same.
     */
    protected function seedElementorMeta(int $postId): void
    {
        update_post_meta($postId, ElementsKitHelper::PAGE_TEMPLATE_META, 'elementor_canvas');
        update_post_meta($postId, ElementsKitHelper::EDIT_MODE_META, 'builder');
    }

    protected function deleteRecord(int $postId, array $fieldMappings, string $failureMessage, string $successMessage): array
    {
        $deleted = wp_delete_post($postId, !empty($fieldMappings['force_delete']));

        if (!$deleted) {
            return [
                'response'    => $failureMessage,
                'payload'     => $fieldMappings,
                'status_code' => 500,
            ];
        }

        return [
            'response'    => $successMessage,
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }
}
