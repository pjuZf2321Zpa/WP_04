<?php

namespace BitApps\PiPro\src\Integrations\Masteriyo;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!\defined('ABSPATH')) {
    exit;
}

class MasteriyoHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'courseCompleted' => [
                'hook'          => 'masteriyo_course_progress_status_changed',
                'callback'      => [MasteriyoTrigger::class, 'courseCompleted'],
                'accepted_args' => 4,
            ],
            'lessonCompleted' => [
                'hook'          => 'masteriyo_new_course_progress_item',
                'callback'      => [MasteriyoTrigger::class, 'lessonCompleted'],
                'accepted_args' => 2,
            ],
            'quizPassed' => [
                'hook'          => 'masteriyo_quiz_attempt_status_changed',
                'callback'      => [MasteriyoTrigger::class, 'quizPassed'],
                'accepted_args' => 3,
            ],
            'quizFailed' => [
                'hook'          => 'masteriyo_quiz_attempt_status_changed',
                'callback'      => [MasteriyoTrigger::class, 'quizFailed'],
                'accepted_args' => 3,
            ],
        ];
    }
}
