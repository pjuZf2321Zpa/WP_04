<?php

namespace BitApps\PiPro\src\Integrations\Masteriyo;

// Prevent direct script access
if (!\defined('ABSPATH')) {
    exit;
}

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;

final class MasteriyoTrigger
{
    public static function courseCompleted($courseId, $oldStatus, $newStatus, $courseProgress)
    {
        if (
            $newStatus !== 'completed'
            || !\function_exists('masteriyo_get_course')
            || !method_exists($courseProgress, 'get_course_id')
            || !method_exists($courseProgress, 'get_user_id')
        ) {
            return;
        }

        $course = masteriyo_get_course($courseProgress->get_course_id());
        $userId = $courseProgress->get_user_id();

        $data = [
            'user'            => Utility::getUserInfo($userId),
            'course_id'       => $courseId,
            'course'          => $course,
            'course_progress' => $courseProgress,
            'old_status'      => $oldStatus,
            'new_status'      => $newStatus,
        ];

        self::execute(__FUNCTION__, $data);
    }

    public static function lessonCompleted($itemId, $object)
    {
        if (
            !method_exists($object, 'get_item_type')
            || $object->get_item_type() !== 'lesson'
            || !\function_exists('masteriyo_get_lesson')
            || !method_exists($object, 'get_item_id')
            || !method_exists($object, 'get_user_id')
        ) {
            return;
        }

        $lesson = masteriyo_get_lesson($object->get_item_id());
        $userId = $object->get_user_id();

        $data = [
            'user'      => Utility::getUserInfo($userId),
            'lesson_id' => $itemId,
            'lesson'    => $lesson,
            'data'      => $object,
        ];

        self::execute(__FUNCTION__, $data);
    }

    public static function quizPassed($attempt, $oldStatus, $newStatus)
    {
        self::executeQuizTriggers(__FUNCTION__, $attempt, $oldStatus, $newStatus, 'pass');
    }

    public static function quizFailed($attempt, $oldStatus, $newStatus)
    {
        self::executeQuizTriggers(__FUNCTION__, $attempt, $oldStatus, $newStatus, 'fail');
    }

    /**
     * Execute quiz-related triggers.
     *
     * @param string $machineSlug
     * @param object $attempt
     * @param string $oldStatus
     * @param string $newStatus
     * @param string $triggerType
     */
    private static function executeQuizTriggers($machineSlug, $attempt, $oldStatus, $newStatus, $triggerType = 'pass')
    {
        if (
            !\function_exists('masteriyo_get_quiz')
            || !\is_object($attempt)
            || !method_exists($attempt, 'get_quiz_id')
            || !method_exists($attempt, 'get_course_id')
            || !method_exists($attempt, 'get_earned_marks')
            || !method_exists($attempt, 'get_user_id')
        ) {
            return;
        }

        $quizId = $attempt->get_quiz_id();
        $quiz = masteriyo_get_quiz($quizId);

        if (empty($quiz)) {
            return;
        }

        if (!method_exists($quiz, 'get_pass_mark')) {
            return;
        }

        $failed = $attempt->get_earned_marks() < $quiz->get_pass_mark();

        if (($triggerType === 'pass' && $failed) || ($triggerType === 'fail' && !$failed)) {
            return;
        }

        $userId = $attempt->get_user_id();
        $courseId = $attempt->get_course_id();
        $data = [
            'user'         => Utility::getUserInfo($userId),
            'quiz_id'      => $quizId,
            'quiz'         => $quiz,
            'course_id'    => $courseId,
            'course'       => masteriyo_get_course($courseId),
            'earned_marks' => $attempt->get_earned_marks(),
            'pass_mark'    => $quiz->get_pass_mark(),
            'attempt'      => $attempt,
            'old_status'   => $oldStatus,
            'new_status'   => $newStatus,
        ];

        self::execute($machineSlug, $data);
    }

    /**
     * Execute the trigger.
     *
     * @param string $machineSlug
     * @param array  $data
     */
    private static function execute($machineSlug, $data)
    {
        $flows = FlowService::exists('Masteriyo', $machineSlug);

        if (!$flows) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $data);
    }
}
