<?php

namespace BitApps\PiPro\src\Integrations\SeoPress;

use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\PiPro\src\Integrations\SeoPress\helper\SeoPressHelper;

if (!\defined('ABSPATH')) {
    exit;
}

final class SeoPressService
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    /**
     * Get Post Meta.
     *
     * @return array
     */
    public function getPostMeta()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $validationRules = ['post_id' => ['required', 'integer']];

        $validationErrors = SeoPressHelper::validateFieldMap($fieldMappings, $validationRules);
        if ($validationErrors) {
            return $validationErrors;
        }

        $postId = $fieldMappings['post_id'];
        $seoMetaData = SeoPressHelper::getPostSeoMeta($postId);

        if (empty($seoMetaData)) {
            return [
                'response'    => __('Post not found or has no SEO meta.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404
            ];
        }

        return [
            'response'    => $seoMetaData,
            'payload'     => $fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Update Post Meta.
     *
     * @return array
     */
    public function updatePostMeta()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $seoMetaData = $this->nodeInfoProvider->getFieldMapRepeaters(
            'field-map.value',
            false,
            true,
            'seoField',
            'value'
        );

        $validationRules = ['post_id' => ['required', 'integer']];
        $validationErrors = SeoPressHelper::validateFieldMap($fieldMappings, $validationRules);

        if ($validationErrors) {
            return $validationErrors;
        }

        if (empty($seoMetaData)) {
            return [
                'response'    => __('No SEO meta data provided to update.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400
            ];
        }

        $postId = $fieldMappings['post_id'];

        if (!get_post($postId)) {
            return [
                'response'    => __('Post not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404
            ];
        }

        SeoPressHelper::updatePostSeoMeta($postId, $seoMetaData);
        $updatedSeoMeta = SeoPressHelper::getPostSeoMeta($postId);

        return [
            'response'    => $updatedSeoMeta,
            'payload'     => $fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Get All Posts with Meta.
     *
     * @return array
     */
    public function getAllPostsWithMeta()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $validationRules = ['post_type' => ['required', 'string']];

        $validationErrors = SeoPressHelper::validateFieldMap($fieldMappings, $validationRules);
        if ($validationErrors) {
            return $validationErrors;
        }

        $postType = $fieldMappings['post_type'];
        $postsPerPage = !empty($fieldMappings['per_page']) ? (int) $fieldMappings['per_page'] : 10;
        $currentPage = !empty($fieldMappings['page']) ? (int) $fieldMappings['page'] : 1;

        $postsWithSeoMeta = SeoPressHelper::getAllPostsWithSeoMeta($postType, $postsPerPage, $currentPage);

        return [
            'response'    => $postsWithSeoMeta,
            'payload'     => $fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Get Title Template.
     *
     * @return array
     */
    public function getTitleTemplate()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $validationRules = ['post_type' => ['required', 'string']];

        $validationErrors = SeoPressHelper::validateFieldMap($fieldMappings, $validationRules);
        if ($validationErrors) {
            return $validationErrors;
        }

        $postType = $fieldMappings['post_type'];
        $titleTemplate = SeoPressHelper::getTitleTemplate($postType);
        $response = [
            'template'  => $titleTemplate,
            'post_type' => $postType
        ];

        return [
            'response'    => $response,
            'payload'     => $fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Get All Title Template.
     *
     * @return array
     */
    public function getAllTitleTemplate()
    {
        $allTemplates = SeoPressHelper::getTitleTemplate();

        return [
            'response'    => $allTemplates,
            'payload'     => [],
            'status_code' => 200
        ];
    }
}
