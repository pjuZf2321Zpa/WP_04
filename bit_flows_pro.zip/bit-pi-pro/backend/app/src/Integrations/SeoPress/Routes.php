<?php

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\PiPro\src\Integrations\SeoPress\helper\SeoPressHelper;

if (!defined('ABSPATH')) {
    exit;
}

Route::group(
    function () {
        Route::get('seopress/get-post-types', [SeoPressHelper::class, 'getPostTypes']);
        Route::post('seopress/get-posts', [SeoPressHelper::class, 'getPosts']);
    }
)->middleware('nonce:admin');
