<?php

namespace BitApps\PiPro\src\Integrations\SeoPress;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!\defined('ABSPATH')) {
    exit;
}

class SeoPressHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'seoMetaboxSaved' => [
                'hook'          => 'seopress_seo_metabox_save',
                'callback'      => [SeoPressTrigger::class, 'seoMetaboxSaved'],
                'accepted_args' => 2,
            ],
            'seoMetaboxSavedForTaxonomy' => [
                'hook'          => 'seopress_seo_metabox_term_save',
                'callback'      => [SeoPressTrigger::class, 'seoMetaboxSavedForTaxonomy'],
                'accepted_args' => 2,
            ],
            'contentAnalysisSaved' => [
                'hook'          => 'seopress_content_analysis_saved',
                'callback'      => [SeoPressTrigger::class, 'contentAnalysisSaved'],
                'accepted_args' => 4,
            ],
        ];
    }
}
