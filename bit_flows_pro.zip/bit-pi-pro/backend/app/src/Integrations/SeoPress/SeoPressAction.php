<?php

namespace BitApps\PiPro\src\Integrations\SeoPress;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;
use BitApps\PiPro\src\Integrations\SeoPress\helper\SeoPressHelper;

if (!\defined('ABSPATH')) {
    exit;
}

class SeoPressAction implements ActionInterface
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeSeoPressAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'] ?? 200,
            $executedNodeAction['payload'] ?? [],
            $executedNodeAction['response'] ?? []
        );
    }

    private function executeSeoPressAction()
    {
        if (!SeoPressHelper::isPluginInstalled()) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('SEOPress plugin is not active.', 'bit-pi'),
            ];
        }

        $seoPressService = new SeoPressService($this->nodeInfoProvider);

        $machineSlug = $this->nodeInfoProvider->getMachineSlug();

        if (!method_exists($seoPressService, $machineSlug)) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('SEOPress action not found.', 'bit-pi'),
            ];
        }

        return $seoPressService->{$machineSlug}();
    }
}
