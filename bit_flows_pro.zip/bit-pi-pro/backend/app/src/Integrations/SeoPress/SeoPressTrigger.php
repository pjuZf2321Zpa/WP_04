<?php

namespace BitApps\PiPro\src\Integrations\SeoPress;

use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\SeoPress\helper\SeoPressHelper;
use WP_Post;

if (!\defined('ABSPATH')) {
    exit;
}

final class SeoPressTrigger
{
    /**
     * Handles SEO metabox save event.
     *
     * @param int   $postId  Post ID
     * @param array $seoTabs Saved SEO tabs data
     */
    public static function seoMetaboxSaved($postId, $seoTabs)
    {
        if (!self::shouldProcessTrigger($postId)) {
            return;
        }

        $seoMeta = self::prepareSeoMetaData(
            $postId,
            [
                'seo_tabs' => $seoTabs,
            ]
        );

        self::executeFlow(__FUNCTION__, $seoMeta);
    }

    /**
     * Handles SEO metabox data is saved for a taxonomy term.
     *
     * @param int   $termId  Term ID
     * @param array $data $_POST data
     */
    public static function seoMetaboxSavedForTaxonomy($termId, $data)
    {
        if (!SeoPressHelper::isPluginInstalled()) {
            return;
        }

        $data['term_data'] = get_term($termId);

        self::executeFlow(__FUNCTION__, $data);
    }

    /**
     * Handles content analysis save event.
     *
     * @param int   $postId   Post ID
     * @param array $items    Analysis items
     * @param array $keywords Target keywords
     * @param array $data     Analysis data
     */
    public static function contentAnalysisSaved($postId, $items, $keywords, $data)
    {
        if (!SeoPressHelper::isPluginInstalled()) {
            return;
        }

        $post = get_post($postId);
        if (!$post) {
            return;
        }

        $analysisData = self::buildContentAnalysisData($post, $items, $keywords, $data);

        self::executeFlow(__FUNCTION__, $analysisData);
    }

    /**
     * Validates if the trigger should be processed.
     *
     * @param int $postId Post ID
     *
     * @return bool
     */
    private static function shouldProcessTrigger($postId)
    {
        if (!SeoPressHelper::isPluginInstalled()) {
            return false;
        }

        return !self::isInvalidPost($postId);
    }

    /**
     * Checks if post is revision or autosave.
     *
     * @param int $postId Post ID
     *
     * @return bool
     */
    private static function isInvalidPost($postId)
    {
        return wp_is_post_revision($postId) || wp_is_post_autosave($postId);
    }

    /**
     * Prepares SEO meta data with additional fields.
     *
     * @param int   $postId         Post ID
     * @param array $additionalData Additional data to merge
     *
     * @return array
     */
    private static function prepareSeoMetaData($postId, array $additionalData = [])
    {
        $seoMeta = SeoPressHelper::getPostSeoMeta($postId);
        $seoMeta['saved_at'] = current_time('mysql');

        return array_merge($seoMeta, $additionalData);
    }

    /**
     * Builds content analysis data structure.
     *
     * @param WP_Post $post     Post object
     * @param array    $items    Analysis items
     * @param array    $keywords Target keywords
     * @param array    $data     Analysis data
     *
     * @return array
     */
    private static function buildContentAnalysisData($post, $items, $keywords, $data)
    {
        return [
            'post_data'       => $post,
            'post_url'        => get_permalink($post->ID),
            'analysis_items'  => $items,
            'target_keywords' => $keywords,
            'analysis_data'   => $data,
            'analysis_date'   => current_time('mysql'),
        ];
    }

    /**
     * Executes the flow if flows exist.
     *
     * @param string $functionName Function name to check flows
     * @param array  $data         Data to pass to flow
     */
    private static function executeFlow($functionName, array $data)
    {
        $flows = FlowService::exists('seoPress', $functionName);

        if (!$flows) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $data);
    }
}
