<?php

namespace BitApps\PiPro\src\Integrations\SeoPress\helper;

use BitApps\Pi\Deps\BitApps\WPKit\Http\Request\Request;
use BitApps\PiPro\Deps\BitApps\WPValidator\Validator;
use WP_Post_Type;
use WP_Query;

if (!\defined('ABSPATH')) {
    exit;
}

final class SeoPressHelper
{
    /**
     * Check if SEOPress plugin is installed.
     *
     * @return bool
     */
    public static function isPluginInstalled()
    {
        return \defined('SEOPRESS_VERSION');
    }

    /**
     * Validate field map.
     *
     * @param array $fieldMappings
     * @param array $validationRules
     * @param null|array $payload
     *
     * @return null|array
     */
    public static function validateFieldMap($fieldMappings, $validationRules, $payload = null)
    {
        $validator = new Validator();
        $validation = $validator->make($fieldMappings, $validationRules);

        if ($validation->fails()) {
            return [
                'response'    => $validation->errors(),
                'payload'     => $payload ?? $fieldMappings,
                'status_code' => 400
            ];
        }
    }

    /**
     * Get SEO meta data for a post.
     *
     * @param int $postId
     *
     * @return array
     */
    public static function getPostSeoMeta($postId)
    {
        $post = get_post($postId);

        if (!$post) {
            return [];
        }

        $seoMetaKeys = self::getSeoMetaKeys();
        $seoMetaData = [
            'post_id'    => $postId,
            'post_title' => $post->post_title,
            'post_type'  => $post->post_type,
        ];

        foreach ($seoMetaKeys as $metaKey) {
            $seoMetaData[$metaKey] = self::getSingleSeoMeta($postId, $metaKey);
        }

        return $seoMetaData;
    }

    /**
     * Update SEO meta data for a post.
     *
     * @param int   $postId
     * @param array $metaData
     *
     * @return bool
     */
    public static function updatePostSeoMeta($postId, $metaData)
    {
        if (!self::postExists($postId)) {
            return false;
        }

        foreach ($metaData as $fieldKey => $fieldValue) {
            self::updateSingleSeoMeta($postId, $fieldKey, $fieldValue);
        }

        return true;
    }

    /**
     * Get all posts with SEO meta.
     *
     * @param string $postType
     * @param int    $perPage
     * @param int    $page
     *
     * @return array
     */
    public static function getAllPostsWithSeoMeta($postType = 'post', $perPage = 10, $page = 1)
    {
        $queryArgs = self::buildPostQueryArgs($postType, $perPage, $page);
        $query = new WP_Query($queryArgs);

        return self::extractSeoMetaFromQuery($query);
    }

    /**
     * Get title template for post type.
     *
     * @param null|string $postType
     *
     * @return null|array|string
     */
    public static function getTitleTemplate($postType = null)
    {
        $options = get_option('seopress_titles_option_name');

        if (empty($postType)) {
            return $options;
        }

        return self::extractTitleTemplateFromOptions($options, $postType);
    }

    /**
     * Get post types for API endpoint.
     *
     * @return array
     */
    public static function getPostTypes()
    {
        $postTypeObjects = get_post_types(['public' => true], 'objects');
        $formattedPostTypes = [];

        foreach ($postTypeObjects as $postTypeObject) {
            if (self::shouldIncludePostType($postTypeObject)) {
                $formattedPostTypes[] = self::formatPostTypeForApi($postTypeObject);
            }
        }

        return $formattedPostTypes;
    }

    /**
     * Get posts by post type for API endpoint.
     *
     * @return array
     */
    public static function getPosts(Request $request)
    {
        $validatedData = $request->validate(
            [
                'post_type' => ['required', 'string', 'sanitize:text']
            ]
        );

        $postType = sanitize_text_field($validatedData['post_type']) ?? 'post';
        $queryArgs = self::buildFetchPostsQueryArgs($postType);
        $query = new WP_Query($queryArgs);

        return self::extractPostsFromQuery($query);
    }

    /**
     * Get single SEO meta value for a post.
     *
     * @param int $postId
     * @param string $metaKey
     *
     * @return string
     */
    private static function getSingleSeoMeta($postId, $metaKey)
    {
        return (string) get_post_meta($postId, $metaKey, true);
    }

    /**
     * Get all SEO meta keys for retrieval.
     *
     * @return array
     */
    private static function getSeoMetaKeys()
    {
        return [
            '_seopress_titles_title',
            '_seopress_titles_desc',
            '_seopress_robots_canonical',
            '_seopress_robots_index',
            '_seopress_robots_follow',
            '_seopress_robots_archive',
            '_seopress_robots_snippet',
            '_seopress_robots_imageindex',
            '_seopress_analysis_target_kw',
            '_seopress_robots_primary_cat',
            '_seopress_social_fb_title',
            '_seopress_social_fb_desc',
            '_seopress_social_fb_img',
            '_seopress_social_twitter_title',
            '_seopress_social_twitter_desc',
            '_seopress_social_twitter_img',
        ];
    }

    /**
     * Check if post exists.
     *
     * @param int $postId
     *
     * @return bool
     */
    private static function postExists($postId)
    {
        return (bool) get_post($postId);
    }

    /**
     * Update single SEO meta value.
     *
     * @param int $postId
     * @param string $metaKey
     * @param string $metaValue
     *
     * @return bool
     */
    private static function updateSingleSeoMeta($postId, $metaKey, $metaValue)
    {
        return update_post_meta($postId, $metaKey, $metaValue);
    }

    /**
     * Build query arguments for posts.
     *
     * @param string $postType
     * @param int $perPage
     * @param int $page
     *
     * @return array
     */
    private static function buildPostQueryArgs($postType, $perPage, $page)
    {
        return [
            'post_type'      => $postType,
            'posts_per_page' => $perPage,
            'paged'          => $page,
            'post_status'    => 'publish',
        ];
    }

    /**
     * Extract SEO meta from query results.
     *
     * @param WP_Query $query
     *
     * @return array
     */
    private static function extractSeoMetaFromQuery($query)
    {
        $postsWithMeta = [];

        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $postsWithMeta[] = self::getPostSeoMeta(get_the_ID());
            }
            wp_reset_postdata();
        }

        return $postsWithMeta;
    }

    /**
     * Build title template option key for post type.
     *
     * @param string $postType
     *
     * @return string
     */
    private static function buildTitleTemplateKey($postType)
    {
        $baseKey = 'seopress_titles_single_titles';

        if ($postType !== 'post' && $postType !== 'page') {
            return $baseKey . '_' . $postType;
        }

        return $baseKey . '.' . $postType;
    }

    /**
     * Get title template from options.
     *
     * @param array $options
     * @param string $postType
     *
     * @return null|string
     */
    private static function extractTitleTemplateFromOptions($options, $postType)
    {
        $baseKey = 'seopress_titles_single_titles';

        if (isset($options[$baseKey][$postType])) {
            return $options[$baseKey][$postType];
        }

        $templateKey = self::buildTitleTemplateKey($postType);

        return $options[$templateKey] ?? null;
    }

    /**
     * Format post type for API response.
     *
     * @param WP_Post_Type $postTypeObject
     *
     * @return array
     */
    private static function formatPostTypeForApi($postTypeObject)
    {
        return [
            'label' => $postTypeObject->labels->singular_name,
            'value' => $postTypeObject->name
        ];
    }

    /**
     * Filter out excluded post types.
     *
     * @param WP_Post_Type $postTypeObject
     *
     * @return bool
     */
    private static function shouldIncludePostType($postTypeObject)
    {
        return $postTypeObject->name !== 'attachment';
    }

    /**
     * Build query arguments for fetching posts.
     *
     * @param string $postType
     *
     * @return array
     */
    private static function buildFetchPostsQueryArgs($postType)
    {
        return [
            'post_type'      => $postType,
            'posts_per_page' => 100,
            'post_status'    => 'any',
            'orderby'        => 'title',
            'order'          => 'ASC'
        ];
    }

    /**
     * Format post for API response.
     *
     * @return array
     */
    private static function formatPostForApi()
    {
        return [
            'label' => get_the_title(),
            'value' => (string) get_the_ID()
        ];
    }

    /**
     * Extract posts from query for API.
     *
     * @param WP_Query $query
     *
     * @return array
     */
    private static function extractPostsFromQuery($query)
    {
        $formattedPosts = [];

        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $formattedPosts[] = self::formatPostForApi();
            }
            wp_reset_postdata();
        }

        return $formattedPosts;
    }
}
