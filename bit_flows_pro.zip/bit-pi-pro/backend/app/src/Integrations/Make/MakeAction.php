<?php

namespace BitApps\PiPro\src\Integrations\Make;

// Prevent direct script access
if (!\defined('ABSPATH')) {
    exit;
}


use BitApps\Pi\src\Integrations\ApiRequest\ApiRequestAction;

class MakeAction extends ApiRequestAction
{
    // extends ApiRequestAction
}
