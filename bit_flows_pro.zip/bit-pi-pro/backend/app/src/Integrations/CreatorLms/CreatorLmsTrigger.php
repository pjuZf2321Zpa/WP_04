<?php

namespace BitApps\PiPro\src\Integrations\CreatorLms;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class CreatorLmsTrigger
{
    public static function studentEnrolledInCourse($arg1, $arg2 = null, $arg3 = null)
    {
        $studentId = 0;
        $courseId = 0;
        $orderId = 0;

        // creator_lms_manual_student_enrollment($student_id, $course_id)
        if (is_numeric($arg1) && is_numeric($arg2)) {
            $studentId = (int) $arg1;
            $courseId = (int) $arg2;
            $orderId = is_numeric($arg3) ? (int) $arg3 : 0;
        } else {
            // creator_lms_after_enrolled_student($order_id)
            $orderId = (int) $arg1;
            $enrollment = CreatorLmsHelper::getEnrollmentByOrderId($orderId);

            if (!empty($enrollment)) {
                $studentId = (int) $enrollment['user_id'];
                $courseId = (int) $enrollment['course_id'];
            }
        }

        if (!$studentId || !$courseId) {
            return;
        }

        $data = [
            'user_id'   => $studentId,
            'course_id' => $courseId,
            'order_id'  => $orderId,
            'user'      => Utility::getUserInfo($studentId),
            'course'    => CreatorLmsHelper::getCourseData($courseId),
            'timestamp' => current_time('mysql'),
        ];

        self::execute('studentEnrolledInCourse', $data);
    }

    public static function studentCompletedCourse($studentId, $courseId, $orderId = 0)
    {
        $studentId = (int) $studentId;
        $courseId = (int) $courseId;

        if (!$studentId || !$courseId) {
            return;
        }

        $data = [
            'user_id'         => $studentId,
            'course_id'       => $courseId,
            'order_id'        => (int) $orderId,
            'completion_date' => current_time('mysql'),
            'user'            => Utility::getUserInfo($studentId),
            'course'          => CreatorLmsHelper::getCourseData($courseId),
        ];

        self::execute('studentCompletedCourse', $data);
    }

    public static function studentCompletedLesson($lessonId, $courseId, $studentId)
    {
        $lessonId = (int) $lessonId;
        $courseId = (int) $courseId;
        $studentId = (int) $studentId;

        if (!$lessonId || !$courseId || !$studentId) {
            return;
        }

        $data = [
            'user_id'         => $studentId,
            'course_id'       => $courseId,
            'lesson_id'       => $lessonId,
            'completion_date' => current_time('mysql'),
            'user'            => Utility::getUserInfo($studentId),
            'course'          => CreatorLmsHelper::getCourseData($courseId),
            'lesson'          => CreatorLmsHelper::getLessonData($lessonId),
        ];

        self::execute('studentCompletedLesson', $data);
    }

    public static function courseCreated($courseId)
    {
        $courseId = (int) $courseId;

        if (!$courseId) {
            return;
        }

        $courseData = CreatorLmsHelper::getCourseData($courseId);

        $data = [
            'course_id'  => $courseId,
            'course'     => $courseData,
            'created_by' => Utility::getUserInfo(get_current_user_id()),
            'created_at' => current_time('mysql'),
        ];

        self::execute('courseCreated', $data);
    }

    public static function courseUpdated($courseId)
    {
        $courseId = (int) $courseId;

        if (!$courseId) {
            return;
        }

        $courseData = CreatorLmsHelper::getCourseData($courseId);

        $data = [
            'course_id'  => $courseId,
            'course'     => $courseData,
            'updated_by' => Utility::getUserInfo(get_current_user_id()),
            'updated_at' => current_time('mysql'),
        ];

        self::execute('courseUpdated', $data);
    }

    /**
     * Execute trigger flow.
     *
     * @param string $machineSlug
     * @param array  $data
     */
    private static function execute($machineSlug, $data)
    {
        $flows = FlowService::exists('creatorLms', $machineSlug);

        if (!$flows) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $data);
    }
}
