<?php

namespace BitApps\PiPro\src\Integrations\CreatorLms;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!defined('ABSPATH')) {
    exit;
}

class CreatorLmsHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'studentEnrolledInCourse' => [
                'hook'          => ['creator_lms_after_enrolled_student', 'creator_lms_manual_student_enrollment'],
                'callback'      => [CreatorLmsTrigger::class, 'studentEnrolledInCourse'],
                'accepted_args' => 3,
            ],
            'studentCompletedCourse' => [
                'hook'          => 'creator_lms_course_completed',
                'callback'      => [CreatorLmsTrigger::class, 'studentCompletedCourse'],
                'accepted_args' => 3,
            ],
            'studentCompletedLesson' => [
                'hook'          => 'creator_lms_lesson_completed',
                'callback'      => [CreatorLmsTrigger::class, 'studentCompletedLesson'],
                'accepted_args' => 3,
            ],
            'courseCreated' => [
                'hook'     => 'creatorlms_new_course',
                'callback' => [CreatorLmsTrigger::class, 'courseCreated'],
            ],
            'courseUpdated' => [
                'hook'     => 'creatorlms_update_course',
                'callback' => [CreatorLmsTrigger::class, 'courseUpdated'],
            ],
        ];
    }
}
