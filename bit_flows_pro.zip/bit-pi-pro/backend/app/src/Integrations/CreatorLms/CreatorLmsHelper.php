<?php

namespace BitApps\PiPro\src\Integrations\CreatorLms;

use BitApps\Pi\Deps\BitApps\WPKit\Http\Request\Request;
use BitApps\Pi\Helpers\Utility;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Response;

if (!defined('ABSPATH')) {
    exit;
}

final class CreatorLmsHelper
{
    private const ENROLLMENT_TABLE_SUFFIX = 'crlms_user_enrollment';

    public static function isPluginActive()
    {
        return class_exists('CreatorLms') && \function_exists('crlms_get_course');
    }

    public static function getCoursePostType()
    {
        return defined('CREATOR_LMS_COURSE_CPT') ? CREATOR_LMS_COURSE_CPT : 'crlms-course';
    }

    public static function getLessonPostType()
    {
        return defined('CREATOR_LMS_LESSON_CPT') ? CREATOR_LMS_LESSON_CPT : 'crlms-lesson';
    }

    public static function getAllCourses()
    {
        if (!self::isPluginActive()) {
            // translators: %s: Plugin name.
            return Response::error(\sprintf(__('%s is not installed or activated', 'bit-pi'), 'Creator LMS'));
        }

        $courses = get_posts(
            [
                'post_type'   => self::getCoursePostType(),
                'post_status' => 'publish',
                'numberposts' => -1,
                'orderby'     => 'title',
                'order'       => 'ASC',
            ]
        );

        return Response::success(self::mapPostOptions($courses));
    }

    public static function getAllLessons(Request $request)
    {
        if (!self::isPluginActive()) {
            // translators: %s: Plugin name.
            return Response::error(\sprintf(__('%s is not installed or activated', 'bit-pi'), 'Creator LMS'));
        }

        $validatedData = $request->validate(
            [
                'courseId' => ['required', 'integer'],
            ]
        );

        global $wpdb;
        $query = $wpdb->prepare(
            "SELECT DISTINCT p.ID, p.post_title
                FROM {$wpdb->posts} p
                INNER JOIN {$wpdb->prefix}crlms_content_relationship cr ON p.ID = cr.content_id
                INNER JOIN {$wpdb->prefix}crlms_chapter_relationship chr ON cr.chapter_id = chr.chapter_id
                WHERE p.post_status = 'publish'
                AND p.post_type = %s
                AND chr.course_id = %d
                ORDER BY p.post_title ASC",
            self::getLessonPostType(),
            (int) $validatedData['courseId']
        );

        $lessons = $wpdb->get_results($query);

        return Response::success(self::mapPostOptions($lessons));
    }

    public static function getEnrollmentByOrderId($orderId)
    {
        if (empty($orderId)) {
            return;
        }

        return self::getLatestEnrollmentByOrderId((int) $orderId);
    }

    public static function getEnrollmentByUserAndCourse($userId, $courseId)
    {
        if (empty($userId) || empty($courseId)) {
            return;
        }

        return self::getLatestEnrollmentByUserAndCourse((int) $userId, (int) $courseId);
    }

    public static function getCoursePost($courseId)
    {
        return self::getValidatedPostByType((int) $courseId, self::getCoursePostType());
    }

    public static function getLessonPost($lessonId)
    {
        return self::getValidatedPostByType((int) $lessonId, self::getLessonPostType());
    }

    public static function getCourseData($courseId)
    {
        $courseId = (int) $courseId;

        if (!$courseId) {
            return [];
        }

        if (\function_exists('crlms_get_course')) {
            $course = crlms_get_course($courseId);

            if ($course) {
                return [
                    'id'          => $course->get_id(),
                    'title'       => $course->get_name(),
                    'description' => $course->get_description(),
                    'permalink'   => $course->get_permalink(),
                    'status'      => $course->get_status(),
                ];
            }
        }

        $coursePost = self::getCoursePost($courseId);

        if (!$coursePost) {
            return [];
        }

        return [
            'id'          => $coursePost->ID,
            'title'       => $coursePost->post_title,
            'description' => $coursePost->post_content,
            'permalink'   => get_permalink($coursePost->ID),
            'status'      => $coursePost->post_status,
        ];
    }

    public static function getLessonData($lessonId)
    {
        $lessonId = (int) $lessonId;

        if (!$lessonId) {
            return [];
        }

        $lessonPost = self::getLessonPost($lessonId);

        if (!$lessonPost) {
            return [];
        }

        return [
            'id'        => $lessonPost->ID,
            'title'     => $lessonPost->post_title,
            'permalink' => get_permalink($lessonPost->ID),
            'status'    => $lessonPost->post_status,
        ];
    }

    public static function getAllCourseData()
    {
        $courses = self::getCoursePosts(['publish', 'draft', 'pending', 'private']);

        return array_values(
            array_filter(
                array_map(
                    static function ($course) {
                        return self::getCourseData($course->ID);
                    },
                    $courses
                )
            )
        );
    }

    public static function getCourseLessonsData($courseId)
    {
        $courseId = (int) $courseId;

        if (!$courseId) {
            return [];
        }

        global $wpdb;
        $query = $wpdb->prepare(
            "SELECT DISTINCT p.ID
                FROM {$wpdb->posts} p
                INNER JOIN {$wpdb->prefix}crlms_content_relationship cr ON p.ID = cr.content_id
                INNER JOIN {$wpdb->prefix}crlms_chapter_relationship chr ON cr.chapter_id = chr.chapter_id
                WHERE p.post_status IN ('publish', 'draft', 'pending', 'private')
                AND p.post_type = %s
                AND chr.course_id = %d
                ORDER BY p.post_title ASC",
            self::getLessonPostType(),
            $courseId
        );

        $lessonIds = $wpdb->get_col($query);

        return array_values(
            array_filter(
                array_map(
                    static function ($lessonId) {
                        return self::getLessonData($lessonId);
                    },
                    $lessonIds
                )
            )
        );
    }

    public static function prepareEnrollmentData($enrollmentData)
    {
        if (empty($enrollmentData) || !\is_array($enrollmentData)) {
            return [];
        }

        $studentId = !empty($enrollmentData['user_id']) ? (int) $enrollmentData['user_id'] : 0;
        $courseId = !empty($enrollmentData['course_id']) ? (int) $enrollmentData['course_id'] : 0;

        return [
            'enrollment' => $enrollmentData,
            'user'       => $studentId ? Utility::getUserInfo($studentId) : [],
            'course'     => $courseId ? self::getCourseData($courseId) : [],
        ];
    }

    /**
     * Retrieves all enrollment records, ordered by most recent first.
     *
     * @return null|array
     */
    public static function getAllEnrollments()
    {
        global $wpdb;

        return $wpdb->get_results(
            'SELECT * FROM ' . self::getEnrollmentTableName() . ' ORDER BY id DESC',
            ARRAY_A
        );
    }

    /**
     * Retrieves the latest enrollment record by a specific column and value.
     *
     * @param string $column Allowed columns: membership_id, course_id, user_id, order_id
     * @param int    $value
     *
     * @return null|array
     */
    public static function getLatestEnrollmentByColumn($column, $value)
    {
        global $wpdb;

        $allowedColumns = ['membership_id', 'course_id', 'user_id', 'order_id'];

        if (!\in_array($column, $allowedColumns, true)) {
            return;
        }

        $table = self::getEnrollmentTableName();

        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE {$column} = %d ORDER BY id DESC LIMIT 1",
                (int) $value
            ),
            ARRAY_A
        );
    }

    /**
     * Gets the name of the enrollment table, including the WordPress table prefix.
     *
     * @return string
     */
    public static function getEnrollmentTableName()
    {
        global $wpdb;

        return $wpdb->prefix . self::ENROLLMENT_TABLE_SUFFIX;
    }

    /**
     * Maps an array of posts to a format suitable for dropdown options.
     *
     * @param array $posts
     *
     * @return array
     */
    private static function mapPostOptions($posts)
    {
        return array_map(
            static function ($post) {
                return [
                    'label' => $post->post_title,
                    'value' => $post->ID,
                ];
            },
            $posts
        );
    }

    private static function getCoursePosts($postStatus = ['publish'])
    {
        return get_posts(
            [
                'post_type'   => self::getCoursePostType(),
                'post_status' => $postStatus,
                'numberposts' => -1,
                'orderby'     => 'title',
                'order'       => 'ASC',
            ]
        );
    }

    /**
     * Validates that a post with the given ID exists and matches the expected post type.
     *
     * @param int    $id
     * @param string $postType
     *
     * @return mixed
     */
    private static function getValidatedPostByType($id, $postType)
    {
        $post = get_post($id);

        if (!$post || $postType !== $post->post_type) {
            return;
        }

        return $post;
    }

    /**
     * Retrieves the latest enrollment record for a given order ID.
     *
     * @param int $orderId
     *
     * @return null|array
     */
    private static function getLatestEnrollmentByOrderId($orderId)
    {
        global $wpdb;

        return $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM ' . self::getEnrollmentTableName() . ' WHERE order_id = %d ORDER BY id DESC LIMIT 1',
                $orderId
            ),
            ARRAY_A
        );
    }

    /**
     * Retrieves the latest enrollment record for a given user ID and course ID.
     *
     * @param int $userId
     * @param int $courseId
     *
     * @return null|array
     */
    private static function getLatestEnrollmentByUserAndCourse($userId, $courseId)
    {
        global $wpdb;

        return $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM ' . self::getEnrollmentTableName() . ' WHERE user_id = %d AND course_id = %d ORDER BY id DESC LIMIT 1',
                $userId,
                $courseId
            ),
            ARRAY_A
        );
    }
}
