<?php

namespace BitApps\PiPro\src\Integrations\CreatorLms;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\PiPro\Deps\BitApps\WPValidator\Validator;
use CreatorLms\Data\Student;
use WP_User;

if (!defined('ABSPATH')) {
    exit;
}

final class CreatorLmsService
{
    private $nodeInfoProvider;

    private $fieldMappings;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
        $this->fieldMappings = $this->nodeInfoProvider->getFieldMapData();
    }

    /**
     * Create student.
     *
     * @return array
     */
    public function createStudent()
    {
        $payload = $this->fieldMappings;
        unset($payload['password']); // Remove password from payload for security

        $validationError = $this->validateFieldMap(
            [
                'user_email' => ['required', 'email'],
                'password'   => ['nullable', 'string', 'min:8'],
            ],
            $payload
        );

        if ($validationError) {
            return $validationError;
        }

        if (email_exists($this->fieldMappings['user_email'])) {
            return [
                'response'    => __('A student account already exists with this email.', 'bit-pi'),
                'payload'     => $payload,
                'status_code' => 400,
            ];
        }

        if (!\function_exists('creator_lms_create_new_student')) {
            return [
                'response'    => __('Creator LMS student creation function is not available.', 'bit-pi'),
                'payload'     => $payload,
                'status_code' => 500,
            ];
        }

        $args = $this->prepareStudentNameArgs();

        $studentId = creator_lms_create_new_student(
            $this->fieldMappings['user_email'],
            $this->fieldMappings['username'] ?? '',
            $this->fieldMappings['password'] ?? '',
            $args
        );

        if (is_wp_error($studentId)) {
            return [
                'response'    => $studentId->get_error_message(),
                'payload'     => $payload,
                'status_code' => 400,
            ];
        }

        $studentId = (int) $studentId;
        $this->markAsCreatorLmsStudent($studentId);

        return [
            'response'    => Utility::getUserInfo($studentId),
            'payload'     => $payload,
            'status_code' => 200,
        ];
    }

    /**
     * Update student data.
     *
     * @return array
     */
    public function updateStudentData()
    {
        $validationError = $this->validateFieldMap(
            [
                'user_email' => ['required', 'email'],
            ]
        );

        if ($validationError) {
            return $validationError;
        }

        $student = $this->getStudentByEmail($this->fieldMappings['user_email']);
        if (!$student) {
            return [
                'response'    => __('Student not found with the provided email.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 404,
            ];
        }

        $updateData = $this->prepareStudentUpdateData((int) $student->ID);
        if (isset($updateData['status_code'])) {
            return $updateData;
        }

        $updated = wp_update_user($updateData);

        if (is_wp_error($updated)) {
            return [
                'response'    => $updated->get_error_message(),
                'payload'     => $this->fieldMappings,
                'status_code' => 400,
            ];
        }

        return [
            'response'    => Utility::getUserInfo((int) $student->ID),
            'payload'     => $this->fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Enroll user in course.
     *
     * @return array
     */
    public function enrollUserInCourse()
    {
        $validationError = $this->validateFieldMap(
            [
                'user_email' => ['required', 'email', 'sanitize:email'],
                'course_id'  => ['required', 'integer'],
            ]
        );

        if ($validationError) {
            return $validationError;
        }

        $courseId = (int) $this->fieldMappings['course_id'];
        $userEmail = $this->fieldMappings['user_email'];

        $student = $this->getStudentByEmail($userEmail);
        if (!$student) {
            return [
                'response'    => __('Student not found with the provided email.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 404,
            ];
        }

        if (!CreatorLmsHelper::getCoursePost($courseId)) {
            return [
                'response'    => __('Course not found.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 404,
            ];
        }

        $studentId = (int) $student->ID;
        $this->markAsCreatorLmsStudent($studentId);

        global $wpdb;
        $enrollmentTable = CreatorLmsHelper::getEnrollmentTableName();

        $existingEnrollment = CreatorLmsHelper::getEnrollmentByUserAndCourse($studentId, $courseId);

        if (!empty($existingEnrollment) && 'enrolled' === ($existingEnrollment['status'] ?? '')) {
            return [
                'response'    => __('Student is already enrolled in this course.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 400,
            ];
        }

        $enrollmentData = [
            'user_id'    => $studentId,
            'course_id'  => $courseId,
            'status'     => 'enrolled',
            'progress'   => 'running',
            'start_date' => current_time('mysql'),
        ];

        $inserted = $wpdb->insert(
            $enrollmentTable,
            $enrollmentData,
            ['%d', '%d', '%s', '%s', '%s']
        );

        if (!$inserted) {
            return [
                'response'    => __('Failed to enroll student in course.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 500,
            ];
        }

        do_action('creator_lms_manual_student_enrollment', $studentId, $courseId);

        $response = [
            'enrollment_id' => (int) $wpdb->insert_id,
            'student_id'    => $studentId,
            'course_id'     => $courseId,
            'status'        => 'enrolled',
            'start_date'    => $enrollmentData['start_date'],
        ];

        return [
            'response'    => $response,
            'payload'     => $this->fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Create course.
     *
     * @return array
     */
    public function createCourse()
    {
        $validationError = $this->validateFieldMap(
            [
                'course_title'       => ['required', 'string', 'sanitize:text'],
                'course_description' => ['required', 'string', 'sanitize:text'],
            ]
        );

        if ($validationError) {
            return $validationError;
        }

        $courseTitle = $this->fieldMappings['course_title'];
        $courseDescription = $this->fieldMappings['course_description'];
        $courseStatus = !empty($this->fieldMappings['course_status'])
            ? $this->fieldMappings['course_status']
            : 'draft';

        $courseClass = \function_exists('creator_lms_is_pro') && creator_lms_is_pro()
            ? '\CreatorLmsPro\Data\Course'
            : '\CreatorLms\Data\Course';

        if (!class_exists($courseClass)) {
            return [
                'response'    => __('Course model class is not available.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 500,
            ];
        }

        $course = new $courseClass();
        $course->set_name($courseTitle);
        $course->set_description($courseDescription);
        $course->set_status($courseStatus);
        $course->save();

        $courseId = (int) $course->get_id() ?? 0;

        if (!$courseId) {
            return [
                'response'    => __('Failed to create course.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 500,
            ];
        }

        return [
            'response'    => CreatorLmsHelper::getCourseData($courseId),
            'payload'     => $this->fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Mark lesson completed.
     *
     * @return array
     */
    public function markLessonCompleted()
    {
        $validationError = $this->validateFieldMap(
            [
                'user_email' => ['required', 'email'],
                'course_id'  => ['required', 'integer'],
                'lesson_id'  => ['required', 'integer'],
            ]
        );

        if ($validationError) {
            return $validationError;
        }

        $courseId = (int) $this->fieldMappings['course_id'];
        $lessonId = (int) $this->fieldMappings['lesson_id'];
        $userEmail = $this->fieldMappings['user_email'];

        $studentUser = $this->getStudentByEmail($userEmail);
        if (!$studentUser) {
            return [
                'response'    => __('Student not found with the provided email.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 404,
            ];
        }

        if (!CreatorLmsHelper::getCoursePost($courseId)) {
            return [
                'response'    => __('Course not found.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 404,
            ];
        }

        if (!CreatorLmsHelper::getLessonPost($lessonId)) {
            return [
                'response'    => __('Lesson not found.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 404,
            ];
        }

        if (!class_exists(Student::class)) {
            return [
                'response'    => __('Student service is unavailable.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 500,
            ];
        }

        $studentUserId = (int) $studentUser->ID;
        $student = new Student($studentUserId);

        if (!$student->maybe_enrolled($courseId)) {
            return [
                'response'    => __('Student is not enrolled in this course.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 400,
            ];
        }

        if ($student->maybe_completed($lessonId)) {
            return [
                'response'    => __('Lesson is already marked as completed.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 400,
            ];
        }

        $progressId = $student->complete_lesson($lessonId, $courseId);
        $completionRate = (int) $student->get_over_all_completion_rate($courseId);

        if (!$progressId) {
            return [
                'response'    => __('Failed to mark lesson as completed.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 500,
            ];
        }

        do_action('creator_lms_after_lesson_completed', $lessonId, $courseId, $studentUserId);

        if ($completionRate >= 100) {
            $orderId = $this->markEnrollmentCompleted($studentUserId, $courseId);
            do_action('creator_lms_course_completed', $studentUserId, $courseId, $orderId);
        }

        do_action('creator_lms_course_completion_rate', $studentUserId, $courseId, $completionRate);
        do_action('creator_lms_lesson_completed', $lessonId, $courseId, $studentUserId);

        $response = [
            'progress_id'     => $progressId,
            'lesson_id'       => $lessonId,
            'course_id'       => $courseId,
            'student_user_id' => $studentUserId,
            'completion_rate' => $completionRate,
        ];

        return [
            'response'    => $response,
            'payload'     => $this->fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Get all courses.
     *
     * @return array
     */
    public function getAllCourses()
    {
        return [
            'response'    => CreatorLmsHelper::getAllCourseData(),
            'payload'     => [],
            'status_code' => 200,
        ];
    }

    /**
     * Get course by ID.
     *
     * @return array
     */
    public function getCourseById()
    {
        $validationError = $this->validateFieldMap(
            [
                'course_id' => ['required', 'integer'],
            ]
        );

        if ($validationError) {
            return $validationError;
        }

        $courseId = (int) $this->fieldMappings['course_id'];
        $course = CreatorLmsHelper::getCourseData($courseId);

        if (empty($course)) {
            return [
                'response'    => __('Course not found.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 404,
            ];
        }

        return [
            'response'    => $course,
            'payload'     => $this->fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Get course lessons.
     *
     * @return array
     */
    public function getCourseLessons()
    {
        $validationError = $this->validateFieldMap(
            [
                'course_id' => ['required', 'integer'],
            ]
        );

        if ($validationError) {
            return $validationError;
        }

        $courseId = (int) $this->fieldMappings['course_id'];
        $course = CreatorLmsHelper::getCourseData($courseId);

        if (empty($course)) {
            return [
                'response'    => __('Course not found.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 404,
            ];
        }

        $response = [
            'course'  => $course,
            'lessons' => CreatorLmsHelper::getCourseLessonsData($courseId),
        ];

        return [
            'response'    => $response,
            'payload'     => $this->fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Get enrollment by order ID.
     *
     * @return array
     */
    public function getEnrollmentByOrderId()
    {
        $validationError = $this->validateFieldMap(
            [
                'order_id' => ['required', 'integer'],
            ]
        );

        if ($validationError) {
            return $validationError;
        }

        $enrollment = CreatorLmsHelper::getLatestEnrollmentByColumn('order_id', (int) $this->fieldMappings['order_id']);

        return [
            'response'    => $enrollment,
            'payload'     => $this->fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Get enrollment by course ID.
     *
     * @return array
     */
    public function getEnrollmentByCourseId()
    {
        $validationError = $this->validateFieldMap(
            [
                'course_id' => ['required', 'integer'],
            ]
        );

        if ($validationError) {
            return $validationError;
        }

        $enrollment = CreatorLmsHelper::getLatestEnrollmentByColumn('course_id', (int) $this->fieldMappings['course_id']);

        return [
            'response'    => $enrollment,
            'payload'     => $this->fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Get enrollment by user ID.
     *
     * @return array
     */
    public function getEnrollmentByUserId()
    {
        $validationError = $this->validateFieldMap(
            [
                'user_id' => ['required', 'integer'],
            ]
        );

        if ($validationError) {
            return $validationError;
        }

        $enrollment = CreatorLmsHelper::getLatestEnrollmentByColumn('user_id', (int) $this->fieldMappings['user_id']);

        return [
            'response'    => $enrollment,
            'payload'     => $this->fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Get enrollment by student and course.
     *
     * @return array
     */
    public function getEnrollmentByUserAndCourse()
    {
        $validationError = $this->validateFieldMap(
            [
                'user_email' => ['required', 'email'],
                'course_id'  => ['required', 'integer'],
            ]
        );

        if ($validationError) {
            return $validationError;
        }

        $student = $this->getStudentByEmail($this->fieldMappings['user_email']);
        if (!$student) {
            return [
                'response'    => __('Student not found with the provided email.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 404,
            ];
        }

        $enrollment = CreatorLmsHelper::prepareEnrollmentData(
            CreatorLmsHelper::getEnrollmentByUserAndCourse((int) $student->ID, (int) $this->fieldMappings['course_id'])
        );

        if (empty($enrollment)) {
            return [
                'response'    => __('Enrollment not found for the provided student and course.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 404,
            ];
        }

        return [
            'response'    => $enrollment,
            'payload'     => $this->fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Get all courses.
     *
     * @return array
     */
    public function getAllEnrollments()
    {
        return [
            'response'    => CreatorLmsHelper::getAllEnrollments(),
            'payload'     => [],
            'status_code' => 200,
        ];
    }

    /**
     * Validate action field mapping.
     *
     * @param array $validationRules
     * @param mixed $payload
     *
     * @return null|array
     */
    private function validateFieldMap($validationRules, $payload = [])
    {
        $validator = new Validator();
        $validation = $validator->make($this->fieldMappings, $validationRules);

        if ($validation->fails()) {
            return [
                'response'    => $validation->errors(),
                'payload'     => empty($payload) ? $this->fieldMappings : $payload,
                'status_code' => 400,
            ];
        }
    }

    /**
     * Get student by email.
     *
     * @param string $email
     *
     * @return false|WP_User
     */
    private function getStudentByEmail($email)
    {
        return get_user_by('email', sanitize_email($email));
    }

    /**
     * Mark user as Creator LMS student by setting necessary user meta.
     *
     * @param int $studentId
     */
    private function markAsCreatorLmsStudent($studentId)
    {
        update_user_meta($studentId, '_is_creator_lms_student', 'yes');
        update_user_meta($studentId, '_is_creator_lms_user', 'yes');
    }

    /**
     * Build Creator LMS student creation args from optional mapped fields.
     *
     * @return array
     */
    private function prepareStudentNameArgs()
    {
        $args = [];

        if (!empty($this->fieldMappings['first_name'])) {
            $args['first_name'] = $this->fieldMappings['first_name'];
        }

        if (!empty($this->fieldMappings['last_name'])) {
            $args['last_name'] = $this->fieldMappings['last_name'];
        }

        return $args;
    }

    /**
     * Prepare student update data based on mapped fields, including validation for email updates.
     *
     * @param int $studentId
     *
     * @return array
     */
    private function prepareStudentUpdateData($studentId)
    {
        $updateData = ['ID' => $studentId];

        if (!empty($this->fieldMappings['new_email'])) {
            $newEmail = $this->fieldMappings['new_email'];

            if (!is_email($newEmail)) {
                return [
                    'response'    => __('Invalid new email address.', 'bit-pi'),
                    'payload'     => $this->fieldMappings,
                    'status_code' => 400,
                ];
            }

            $existingUser = get_user_by('email', $newEmail);
            if ($existingUser && (int) $existingUser->ID !== $studentId) {
                return [
                    'response'    => __('The new email is already in use by another user.', 'bit-pi'),
                    'payload'     => $this->fieldMappings,
                    'status_code' => 400,
                ];
            }

            $updateData['user_email'] = $newEmail;
        }

        if (!empty($this->fieldMappings['first_name'])) {
            $updateData['first_name'] = $this->fieldMappings['first_name'];
        }

        if (!empty($this->fieldMappings['last_name'])) {
            $updateData['last_name'] = $this->fieldMappings['last_name'];
        }

        if (!empty($this->fieldMappings['display_name'])) {
            $updateData['display_name'] = $this->fieldMappings['display_name'];
        }

        if (\count($updateData) === 1) {
            return [
                'response'    => __('No fields provided to update.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 400,
            ];
        }

        return $updateData;
    }

    /**
     * Update latest enrollment record end date and return related order id.
     *
     * @param int $studentUserId
     * @param int $courseId
     *
     * @return int
     */
    private function markEnrollmentCompleted($studentUserId, $courseId)
    {
        global $wpdb;

        $enrollmentTable = CreatorLmsHelper::getEnrollmentTableName();
        $enrollmentData = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$enrollmentTable} WHERE user_id = %d AND course_id = %d ORDER BY id DESC LIMIT 1",
                $studentUserId,
                $courseId
            ),
            ARRAY_A
        );

        if (empty($enrollmentData)) {
            return 0;
        }

        $orderId = !empty($enrollmentData['order_id']) ? (int) $enrollmentData['order_id'] : 0;

        if (!empty($enrollmentData['id'])) {
            $wpdb->update(
                $enrollmentTable,
                ['end_date' => current_time('mysql')],
                ['id'       => (int) $enrollmentData['id']],
                ['%s'],
                ['%d']
            );
        }

        return $orderId;
    }
}
