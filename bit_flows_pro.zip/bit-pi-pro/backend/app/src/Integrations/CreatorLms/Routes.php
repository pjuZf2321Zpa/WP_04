<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\PiPro\src\Integrations\CreatorLms\CreatorLmsHelper;

Route::group(
    function () {
        Route::get('get_creatorlms_courses', [CreatorLmsHelper::class, 'getAllCourses']);
        Route::post('get_creatorlms_lessons', [CreatorLmsHelper::class, 'getAllLessons']);
    }
)->middleware('nonce:admin');
