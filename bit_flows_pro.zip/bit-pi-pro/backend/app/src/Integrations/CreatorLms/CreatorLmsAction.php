<?php

namespace BitApps\PiPro\src\Integrations\CreatorLms;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;

if (!defined('ABSPATH')) {
    exit;
}

class CreatorLmsAction implements ActionInterface
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeCreatorLmsAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'] ?? 200,
            $executedNodeAction['payload'] ?? [],
            $executedNodeAction['response'] ?? []
        );
    }

    private function executeCreatorLmsAction()
    {
        if (!CreatorLmsHelper::isPluginActive()) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('Creator LMS plugin is not active.', 'bit-pi'),
            ];
        }

        $creatorLmsService = new CreatorLmsService($this->nodeInfoProvider);
        $machineSlug = $this->nodeInfoProvider->getMachineSlug();

        if (!\is_callable([$creatorLmsService, $machineSlug])) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('Creator LMS action not found.', 'bit-pi'),
            ];
        }

        return $creatorLmsService->{$machineSlug}();
    }
}
