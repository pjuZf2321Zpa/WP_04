<?php

namespace BitApps\PiPro\src\Integrations\ProfilePress;

use BitApps\Pi\src\Flow\NodeInfoProvider;
use ProfilePress\Core\Membership\Models\Customer\CustomerEntity;
use ProfilePress\Core\Membership\Models\Customer\CustomerFactory;
use ProfilePress\Core\Membership\Models\Order\OrderFactory;

if (!defined('ABSPATH')) {
    exit;
}

final class ProfilePressServices
{
    private $nodeInfoProvider;

    private $fieldMappings;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
        $this->fieldMappings = $this->nodeInfoProvider->getFieldMapData();
    }

    /**
     * Add new order.
     *
     * @return array
     */
    public function addNewOrder()
    {
        $missingDependency = ProfilePressHelper::getMissingDependency(
            [
                '\ProfilePress\Core\Membership\Models\Customer\CustomerFactory',
                '\ProfilePress\Core\Membership\Services\Calculator',
                '\ProfilePress\Core\Membership\Models\Order\OrderFactory',
                '\ProfilePressVendor\Carbon\CarbonImmutable',
            ],
            ['ppress_get_plan', 'ppress_subscribe_user_to_plan', 'ppress_clean'],
        );

        if ($missingDependency) {
            return [
                'response' => \sprintf(
                    // translators: 1. Type of the missing dependency (function or class), 2. Name of the missing dependency.
                    __('Required ProfilePress %1$s %2$s does not exist.', 'bit-pi'),
                    $missingDependency['type'],
                    $missingDependency['name']
                ),
                'payload'     => [],
                'status_code' => 400
            ];
        }

        $rules = [
            'plan_id'     => ['required', 'integer'],
            'customer_id' => ['required', 'integer'],
        ];

        if ($errors = ProfilePressHelper::validateFieldMap($this->fieldMappings, $rules)) {
            return $errors;
        }

        $planId = absint($this->fieldMappings['plan_id']);
        $customerId = absint($this->fieldMappings['customer_id']);

        $plan = ppress_get_plan($planId);
        if (!$plan || empty($plan->id)) {
            return [
                'response'    => __('The selected plan does not exist.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 404
            ];
        }

        $customer = CustomerFactory::fromId($customerId);
        if (!$customer || !$customer->user_exists()) {
            return [
                'response'    => __('The selected customer does not exist.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 404
            ];
        }

        $response = ProfilePressHelper::subscribeUserToPlan(
            $this->fieldMappings,
            $plan,
            $planId,
            $customerId,
        );

        if (is_wp_error($response)) {
            return [
                'response'    => $response->get_error_message(),
                'payload'     => $this->fieldMappings,
                'status_code' => 400
            ];
        }

        if (empty($response['order_id'])) {
            return [
                'response'    => __('Order creation failed.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 400
            ];
        }

        $order = OrderFactory::fromId(absint($response['order_id']));

        $billingKeys = ['billing_address', 'billing_city', 'billing_country', 'billing_state', 'billing_postcode', 'billing_phone'];
        foreach ($billingKeys as $key) {
            $order->{$key} = ppress_clean($this->fieldMappings[$key] ?? '', 'sanitize_text_field');
        }

        $order->save();

        return [
            'response'    => ProfilePressHelper::getOrderData($order),
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Add or update ProfilePress customer.
     *
     * @return array
     */
    public function addOrUpdateCustomer()
    {
        $payload = $this->fieldMappings;
        unset($payload['password']);

        $rules = [
            'user_email' => ['required', 'email'],
            'user_name'  => ['required', 'string'],
        ];

        if ($errors = ProfilePressHelper::validateFieldMap($this->fieldMappings, $rules, $payload)) {
            return $errors;
        }

        $missingDependency = ProfilePressHelper::getMissingDependency(
            [
                '\ProfilePress\Core\Membership\Models\Customer\CustomerFactory',
                '\ProfilePress\Core\Membership\Models\Customer\CustomerEntity',
            ]
        );

        if ($missingDependency) {
            return [
                'response' => \sprintf(
                    // translators: 1. Type of the missing dependency (function or class), 2. Name of the missing dependency.
                    __('Required ProfilePress %1$s %2$s does not exist.', 'bit-pi'),
                    $missingDependency['type'],
                    $missingDependency['name']
                ),
                'payload'     => $payload,
                'status_code' => 400
            ];
        }

        $userId = ProfilePressHelper::createOrUpdateCustomer($this->fieldMappings);

        if (is_wp_error($userId)) {
            return [
                'response'    => $userId->get_error_message(),
                'payload'     => $payload,
                'status_code' => 400
            ];
        }

        ProfilePressHelper::updateCustomerMetaData($this->fieldMappings, $userId);

        $customer = CustomerFactory::fromUserId($userId);
        if (!$customer->exists()) {
            $newCustomer = new CustomerEntity();
            $newCustomer->user_id = $userId;
            $customerId = $newCustomer->save();

            if (empty($customerId)) {
                return [
                    'response'    => __('Error creating customer record.', 'bit-pi'),
                    'payload'     => $payload,
                    'status_code' => 400
                ];
            }

            $customer = CustomerFactory::fromId(absint($customerId));
        }

        return [
            'response'    => ProfilePressHelper::getCustomerData($customer),
            'payload'     => $payload,
            'status_code' => 200
        ];
    }

    /**
     * Get customer details by ID.
     *
     * @return array
     */
    public function getCustomerDetailsById()
    {
        return $this->getDetailsById(
            '\ProfilePress\Core\Membership\Models\Customer\CustomerFactory',
            'getCustomerData',
            'customer_id'
        );
    }

    /**
     * Get order details by ID.
     *
     * @return array
     */
    public function getOrderDetailsById()
    {
        return $this->getDetailsById(
            '\ProfilePress\Core\Membership\Models\Order\OrderFactory',
            'getOrderData',
            'order_id'
        );
    }

    /**
     * Get plan details by ID.
     *
     * @return array
     */
    public function getPlanDetailsById()
    {
        return $this->getDetailsById(
            '\ProfilePress\Core\Membership\Models\Plan\PlanFactory',
            'getPlanData',
            'plan_id'
        );
    }

    /**
     * Get subscription details by ID.
     *
     * @return array
     */
    public function getSubscriptionDetailsById()
    {
        return $this->getDetailsById(
            '\ProfilePress\Core\Membership\Models\Subscription\SubscriptionFactory',
            'getSubscriptionData',
            'subscription_id'
        );
    }

    /**
     * Generic method to get details by ID (customer, order, plan, subscription).
     *
     * @param string $factoryClass the corresponding factory class
     * @param string $getDataMethod the method to call for getting data
     * @param string $idField the name of the ID field in fieldMappings
     *
     * @return array
     */
    private function getDetailsById($factoryClass, $getDataMethod, $idField)
    {
        $missingDependency = ProfilePressHelper::getMissingDependency($factoryClass);
        if ($missingDependency) {
            return [
                'response' => \sprintf(
                    // translators: 1. Type of the missing dependency (function or class), 2. Name of the missing dependency.
                    __('Required ProfilePress %1$s %2$s does not exist.', 'bit-pi'),
                    $missingDependency['type'],
                    $missingDependency['name']
                ),
                'payload'     => [],
                'status_code' => 400
            ];
        }

        $rules = [$idField => ['required', 'integer']];
        if ($errors = ProfilePressHelper::validateFieldMap($this->fieldMappings, $rules)) {
            return $errors;
        }

        $id = absint($this->fieldMappings[$idField]);
        $object = $factoryClass::fromId($id);

        if (!$object || !$object->exists()) {
            return [
                'response'    => __('No record found.', 'bit-pi'),
                'payload'     => $this->fieldMappings,
                'status_code' => 404
            ];
        }

        switch ($getDataMethod) {
            case 'getCustomerData':
                $responseData = ProfilePressHelper::getCustomerData($object);

                break;

            case 'getOrderData':
                $responseData = ProfilePressHelper::getOrderData($object);

                break;

            case 'getPlanData':
                $responseData = ProfilePressHelper::getPlanData($object);

                break;

            case 'getSubscriptionData':
                $responseData = ProfilePressHelper::getSubscriptionData($object);

                break;

            default:
                return [
                    'response'    => __('Invalid data retrieval method.', 'bit-pi'),
                    'payload'     => $this->fieldMappings,
                    'status_code' => 400
                ];
        }

        return [
            'response'    => $responseData,
            'payload'     => $this->fieldMappings,
            'status_code' => 200
        ];
    }
}
