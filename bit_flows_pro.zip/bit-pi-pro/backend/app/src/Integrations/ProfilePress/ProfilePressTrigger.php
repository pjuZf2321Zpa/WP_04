<?php

namespace BitApps\PiPro\src\Integrations\ProfilePress;

use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use ProfilePress\Core\Membership\Models\Customer\CustomerFactory;
use ProfilePress\Core\Membership\Models\Subscription\SubscriptionEntity;

if (!defined('ABSPATH')) {
    exit;
}

class ProfilePressTrigger
{
    public static function customerUpdated($customerId)
    {
        if (empty($customerId) || !class_exists('\ProfilePress\Core\Membership\Models\Customer\CustomerFactory')) {
            return;
        }

        $customer = CustomerFactory::fromId(absint($customerId));

        if (!$customer || !$customer->exists()) {
            return;
        }

        self::execute(__FUNCTION__, ProfilePressHelper::getCustomerData($customer));
    }

    public static function subscriptionActivated($subscription)
    {
        if (
            !class_exists('\ProfilePress\Core\Membership\Models\Subscription\SubscriptionEntity')
            || !$subscription instanceof SubscriptionEntity
        ) {
            return;
        }

        self::execute(__FUNCTION__, ProfilePressHelper::getSubscriptionData($subscription));
    }

    private static function execute($machineSlug, $data)
    {
        $flows = FlowService::exists('profilePress', $machineSlug);

        if (!$flows) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $data);
    }
}
