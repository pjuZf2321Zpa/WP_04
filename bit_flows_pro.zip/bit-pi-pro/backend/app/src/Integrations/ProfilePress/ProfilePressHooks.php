<?php

namespace BitApps\PiPro\src\Integrations\ProfilePress;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!\defined('ABSPATH')) {
    exit;
}

class ProfilePressHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'customerUpdated' => [
                'hook'     => 'ppress_customer_updated',
                'callback' => [ProfilePressTrigger::class, 'customerUpdated'],
            ],
            'subscriptionActivated' => [
                'hook'     => 'ppress_subscription_activated',
                'callback' => [ProfilePressTrigger::class, 'subscriptionActivated'],
            ],
        ];
    }
}
