<?php

namespace BitApps\PiPro\src\Integrations\ProfilePress;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;

if (!\defined('ABSPATH')) {
    exit;
}

class ProfilePressAction implements ActionInterface
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeProfilePressAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'] ?? 200,
            $executedNodeAction['payload'] ?? [],
            $executedNodeAction['response'] ?? []
        );
    }

    private function executeProfilePressAction()
    {
        if (!ProfilePressHelper::isPluginActive()) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('ProfilePress plugin is not active.', 'bit-pi'),
            ];
        }

        $profilePressServices = new ProfilePressServices($this->nodeInfoProvider);

        $machineSlug = $this->nodeInfoProvider->getMachineSlug();

        if (!method_exists($profilePressServices, $machineSlug)) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('ProfilePress action not found.', 'bit-pi'),
            ];
        }

        return $profilePressServices->{$machineSlug}();
    }
}
