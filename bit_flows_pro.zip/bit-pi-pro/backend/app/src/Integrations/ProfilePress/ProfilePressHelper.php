<?php

namespace BitApps\PiPro\src\Integrations\ProfilePress;

use BitApps\PiPro\Deps\BitApps\WPValidator\Validator;
use Exception;
use ProfilePressVendor\Carbon\CarbonImmutable;
use WP_Error;

if (!defined('ABSPATH')) {
    exit;
}

final class ProfilePressHelper
{
    /**
     * Check if ProfilePress plugin is active.
     *
     * @return bool
     */
    public static function isPluginActive()
    {
        return defined('PPRESS_VERSION_NUMBER');
    }

    /**
     * Get the first missing function or class dependency.
     *
     * @param array|string $functions
     * @param array|string $classes
     *
     * @return null|array{type:string,name:string}
     */
    public static function getMissingDependency($classes = [], $functions = [])
    {
        if (!\is_array($classes)) {
            $classes = [$classes];
        }

        if (!\is_array($functions)) {
            $functions = [$functions];
        }

        foreach ($classes as $class) {
            if (!class_exists($class)) {
                return [
                    'type' => 'class',
                    'name' => $class,
                ];
            }
        }

        foreach ($functions as $function) {
            if (!\function_exists($function)) {
                return [
                    'type' => 'function',
                    'name' => $function,
                ];
            }
        }
    }

    /**
     * Validate field map.
     *
     * @param array      $fieldMappings   the data to validate
     * @param array      $validationRules the validation rules to apply
     * @param null|array $payload         optional payload to return on validation failure
     *
     * @return null|array returns null when validation passes (no errors), or an array
     *                    containing the validation errors, payload, and status code when it fails
     */
    public static function validateFieldMap($fieldMappings, $validationRules, $payload = null)
    {
        $validator = new Validator();
        $validation = $validator->make($fieldMappings, $validationRules);

        if ($validation->fails()) {
            return [
                'response'    => $validation->errors(),
                'payload'     => $payload ?? $fieldMappings,
                'status_code' => 400
            ];
        }
    }

    /**
     * Create or update a ProfilePress customer.
     *
     * @param array $fieldMappings
     *
     * @return int|WP_Error
     */
    public static function createOrUpdateCustomer($fieldMappings)
    {
        $userdata = [
            'user_login' => $fieldMappings['user_name'] ?? '',
            'user_email' => $fieldMappings['user_email'] ?? '',
            'user_pass'  => $fieldMappings['password'] ?? wp_generate_password(),
            'first_name' => $fieldMappings['first_name'] ?? '',
            'last_name'  => $fieldMappings['last_name'] ?? '',
        ];

        $user = get_user_by('email', $fieldMappings['user_email']);
        if (!$user) {
            $user = get_user_by('login', $fieldMappings['user_name']);
        }

        if ($user) {
            $userdata['ID'] = $user->ID;
            $userdata = array_filter($userdata);

            return wp_update_user(wp_slash($userdata));
        }

        return wp_insert_user(wp_slash($userdata));
    }

    /**
     * Update ProfilePress customer meta data.
     *
     * @param array $fieldMappings
     * @param int $userId
     */
    public static function updateCustomerMetaData($fieldMappings, $userId)
    {
        $billingKeys = ['ppress_billing_address', 'ppress_billing_city', 'ppress_billing_country', 'ppress_billing_state', 'ppress_billing_postcode', 'ppress_billing_phone'];

        foreach ($billingKeys as $billingKey) {
            $metaKey = $billingKey;
            $metaValue = $fieldMappings[$billingKey] ?? '';

            update_user_meta($userId, $metaKey, $metaValue);
        }
    }

    /**
     * Subscribe user to a plan.
     *
     * @param array $fieldMappings
     * @param object $plan
     * @param int $planId
     * @param int $customerId
     *
     * @return array|WP_Error
     */
    public static function subscribeUserToPlan($fieldMappings, $plan, $planId, $customerId)
    {
        $dateCreated = current_time('mysql');

        if (isset($fieldMappings['order_date'])) {
            try {
                $dateCreated = CarbonImmutable::parse(
                    $fieldMappings['order_date'],
                    wp_timezone()
                )
                    ->setTimeFromTimeString(CarbonImmutable::now(wp_timezone())->toTimeString())
                    ->utc()
                    ->toDateTimeString();
            } catch (Exception $e) {
                return new WP_Error('invalid_date_format', $e->getMessage());
            }
        }

        $orderData = [
            'amount'         => $fieldMappings['amount'] ?? $plan->get_price(),
            'order_status'   => $fieldMappings['order_status'] ?? 'pending',
            'payment_method' => $fieldMappings['payment_method'] ?? '',
            'transaction_id' => $fieldMappings['transaction_id'] ?? '',
            'date_created'   => $dateCreated,
        ];

        $sendReceipt = $fieldMappings['send_receipt'] ?? false;

        return ppress_subscribe_user_to_plan($planId, $customerId, $orderData, $sendReceipt);
    }

    /**
     * Get customer data.
     *
     * @param object $customer
     *
     * @return array
     */
    public static function getCustomerData($customer)
    {
        return [
            'id'             => $customer->get_id(),
            'user_id'        => $customer->get_user_id(),
            'first_name'     => $customer->get_first_name(),
            'last_name'      => $customer->get_last_name(),
            'name'           => $customer->get_name(),
            'email'          => $customer->get_email(),
            'total_spend'    => $customer->total_spend,
            'purchase_count' => $customer->purchase_count,
            'private_note'   => $customer->get_private_note(),
            'last_login'     => $customer->last_login,
            'date_created'   => $customer->date_created,
        ];
    }

    /**
     * Get subscription data.
     *
     * @param object $subscription
     *
     * @return array
     */
    public static function getSubscriptionData($subscription)
    {
        return [
            'id'                        => $subscription->get_id(),
            'parent_order_id'           => $subscription->get_parent_order_id(),
            'plan_id'                   => $subscription->get_plan_id(),
            'customer_id'               => $subscription->get_customer_id(),
            'billing_frequency'         => $subscription->billing_frequency,
            'initial_amount'            => $subscription->get_initial_amount(),
            'recurring_amount'          => $subscription->get_recurring_amount(),
            'initial_tax'               => $subscription->get_initial_tax(),
            'initial_tax_rate'          => $subscription->get_initial_tax_rate(),
            'recurring_tax'             => $subscription->get_recurring_tax(),
            'recurring_tax_rate'        => $subscription->get_recurring_tax_rate(),
            'total_payments'            => $subscription->get_total_payments(),
            'trial_period'              => $subscription->trial_period,
            'profile_id'                => $subscription->get_profile_id(),
            'status'                    => $subscription->get_status(),
            'status_label'              => $subscription->get_status_label(),
            'payment_method'            => $subscription->get_payment_method(),
            'expiration_date'           => $subscription->expiration_date,
            'formatted_expiration_date' => $subscription->get_formatted_expiration_date(),
            'created_date'              => $subscription->created_date,
            'notes'                     => $subscription->get_notes(),
            'is_active'                 => $subscription->is_active(),
            'is_expired'                => $subscription->is_expired(),
            'is_recurring'              => $subscription->is_recurring(),
            'is_lifetime'               => $subscription->is_lifetime(),
            'has_trial'                 => $subscription->has_trial(),
            'times_billed'              => $subscription->get_times_billed(),
            'completed_order_count'     => $subscription->get_completed_order_count(),
        ];
    }

    /**
     * Get order data.
     *
     * @param object $order
     *
     * @return array
     */
    public static function getOrderData($order)
    {
        return [
            'id'                    => $order->get_id(),
            'order_key'             => $order->get_order_key(),
            'order_number'          => $order->get_order_number(),
            'reduced_order_key'     => $order->get_reduced_order_key(),
            'plan_id'               => $order->get_plan_id(),
            'customer_id'           => $order->get_customer_id(),
            'subscription_id'       => $order->get_subscription_id(),
            'order_type'            => $order->order_type,
            'transaction_id'        => $order->get_transaction_id(),
            'payment_method'        => $order->payment_method,
            'payment_method_title'  => $order->get_payment_method_title(),
            'status'                => $order->status,
            'coupon_code'           => $order->coupon_code,
            'subtotal'              => $order->get_subtotal(),
            'tax'                   => $order->get_tax(),
            'tax_rate'              => $order->get_tax_rate(),
            'discount'              => $order->get_discount(),
            'total'                 => $order->get_total(),
            'billing_address'       => $order->billing_address,
            'billing_city'          => $order->billing_city,
            'billing_state'         => $order->billing_state,
            'billing_postcode'      => $order->billing_postcode,
            'billing_country'       => $order->billing_country,
            'billing_phone'         => $order->billing_phone,
            'customer_full_address' => $order->get_customer_full_address(),
            'customer_tax_id'       => $order->get_customer_tax_id(),
            'customer_email'        => $order->get_customer_email(),
            'mode'                  => $order->mode,
            'currency'              => $order->currency,
            'ip_address'            => $order->ip_address,
            'date_created'          => $order->date_created,
            'date_completed'        => $order->date_completed,
            'is_new_order'          => $order->is_new_order(),
            'is_renewal_order'      => $order->is_renewal_order(),
            'is_completed'          => $order->is_completed(),
            'is_failed'             => $order->is_failed(),
            'is_pending'            => $order->is_pending(),
            'is_refunded'           => $order->is_refunded(),
            'is_refundable'         => $order->is_refundable(),
        ];
    }

    /**
     * Get plan data.
     *
     * @param object $plan
     *
     * @return array
     */
    public static function getPlanData($plan)
    {
        return [
            'id'                  => $plan->get_id(),
            'name'                => $plan->get_name(),
            'description'         => $plan->description,
            'user_role'           => $plan->user_role,
            'order_note'          => $plan->order_note,
            'price'               => $plan->get_price(),
            'billing_frequency'   => $plan->get_billing_frequency(),
            'subscription_length' => $plan->get_subscription_length(),
            'total_payments'      => $plan->get_total_payments(),
            'signup_fee'          => $plan->get_signup_fee(),
            'free_trial'          => $plan->get_free_trial(),
            'status'              => $plan->status,
            'is_active'           => $plan->is_active(),
            'is_recurring'        => $plan->is_recurring(),
            'is_auto_renew'       => $plan->is_auto_renew(),
            'is_lifetime'         => $plan->is_lifetime(),
            'has_free_trial'      => $plan->has_free_trial(),
            'has_signup_fee'      => $plan->has_signup_fee(),
            'has_downloads'       => $plan->has_downloads(),
            'downloads'           => $plan->get_downloads(),
            'checkout_url'        => $plan->get_checkout_url(),
            'edit_plan_url'       => $plan->get_edit_plan_url(),
            'group_id'            => $plan->get_group_id(),
            'meta_data'           => $plan->meta_data,
        ];
    }
}
