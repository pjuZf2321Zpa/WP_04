<?php

namespace BitApps\PiPro\src\Integrations\WpTableBuilder\helper;

use DOMDocument;
use DOMNode;
use DOMNodeList;
use DOMXPath;

if (!defined('ABSPATH')) {
    exit;
}

final class WpTableBuilderRowColumnHelper
{
    private const META_KEY_CONTENT = '_wptb_content_';

    private const CELL_TYPE_TEXT = 'text';

    private const DEFAULT_ALIGN_VERTICAL = 'middle';

    private const DEFAULT_ALIGN_HORIZONTAL = 'left';

    /**
     * Get table content from post meta.
     *
     * @param int $tableId
     *
     * @return null|array Returns array with 'content' and 'is_html' keys
     */
    public static function getTableContent($tableId)
    {
        $content = get_post_meta($tableId, self::META_KEY_CONTENT, true);

        return [
            'content' => $content,
            'is_html' => self::isHtmlContent($content)
        ];
    }

    /**
     * Parse table content from JSON or HTML.
     *
     * @param string $content
     *
     * @return null|array
     */
    public static function parseTableContent($content)
    {
        if (empty($content)) {
            return;
        }

        $content = self::extractContentString($content);

        return self::isHtmlContent($content)
            ? self::parseHtmlTable($content)
            : self::parseJsonContent($content);
    }

    /**
     * Get row from table.
     *
     * @param array $tableData
     * @param int   $rowIndex
     *
     * @return null|array Row data or null if not found
     */
    public static function getRow($tableData, $rowIndex)
    {
        if (!self::rowExists($tableData, $rowIndex)) {
            return;
        }

        return self::formatRowData($tableData['rows'][$rowIndex], $rowIndex);
    }

    /**
     * Get column from table.
     *
     * @param array $tableData
     * @param int   $columnIndex
     *
     * @return null|array Column data or null if not found
     */
    public static function getColumn($tableData, $columnIndex)
    {
        if (!isset($tableData['rows']) || empty($tableData['rows'])) {
            return;
        }

        $columnCells = self::extractColumnCells($tableData['rows'], $columnIndex);

        return empty($columnCells) ? null : $columnCells;
    }

    /**
     * Get cell value.
     *
     * @param array $tableData
     * @param int   $rowIndex
     * @param int   $columnIndex
     *
     * @return null|mixed Cell value or null if not found
     */
    public static function getCellValue($tableData, $rowIndex, $columnIndex)
    {
        if (!self::cellExists($tableData, $rowIndex, $columnIndex)) {
            return;
        }

        return self::extractCellValue($tableData['rows'][$rowIndex]['cells'][$columnIndex]);
    }

    /**
     * Get all rows as array.
     *
     * @param array $tableData
     *
     * @return array
     */
    public static function getAllRows($tableData)
    {
        if (!isset($tableData['rows'])) {
            return [];
        }

        $rows = [];
        foreach ($tableData['rows'] as $index => $row) {
            $rows[] = self::formatRowData($row, $index);
        }

        return $rows;
    }

    /**
     * Parse HTML table content to extract data structure.
     *
     * @param string $html
     *
     * @return null|array
     */
    private static function parseHtmlTable($html)
    {
        if (empty($html)) {
            return;
        }

        $dom = self::createDomDocument($html);
        $xpath = new DOMXPath($dom);
        $table = $xpath->query('//table')->item(0);

        if (!$table) {
            return;
        }

        $tableData = self::initializeTableData();
        $rows = self::extractTableRows($xpath, $table);
        $maxCols = self::parseRowsData($rows, $xpath, $tableData);
        $tableData['props']['cols'] = $maxCols;

        return $tableData;
    }

    /**
     * Get inner HTML of a DOMNode.
     *
     * @param DOMNode $node
     *
     * @return string
     */
    private static function getInnerHTML($node)
    {
        $innerHTML = '';
        foreach ($node->childNodes as $child) {
            $innerHTML .= $node->ownerDocument->saveHTML($child);
        }

        return $innerHTML;
    }

    /**
     * Extract cell value from cell structure.
     *
     * @param array $cell
     *
     * @return mixed
     */
    private static function extractCellValue($cell)
    {
        return $cell['props']['content'] ?? '';
    }

    /**
     * Check if content is HTML.
     *
     * @param string $content
     *
     * @return bool
     */
    private static function isHtmlContent($content)
    {
        return !empty($content) && str_contains($content, '<table');
    }

    /**
     * Extract content string from array or string.
     *
     * @param mixed $content
     *
     * @return string
     */
    private static function extractContentString($content)
    {
        return \is_array($content) && isset($content['content']) ? $content['content'] : $content;
    }

    /**
     * Parse JSON content.
     *
     * @param string $content
     *
     * @return null|array
     */
    private static function parseJsonContent($content)
    {
        $decoded = json_decode($content, true);

        return json_last_error() === JSON_ERROR_NONE ? $decoded : null;
    }

    /**
     * Check if row exists in table data.
     *
     * @param array $tableData
     * @param int   $rowIndex
     *
     * @return bool
     */
    private static function rowExists($tableData, $rowIndex)
    {
        return isset($tableData['rows'][$rowIndex]);
    }

    /**
     * Check if cell exists in table data.
     *
     * @param array $tableData
     * @param int   $rowIndex
     * @param int   $columnIndex
     *
     * @return bool
     */
    private static function cellExists($tableData, $rowIndex, $columnIndex)
    {
        return isset($tableData['rows'][$rowIndex]['cells'][$columnIndex]);
    }

    /**
     * Format row data for response.
     *
     * @param array $row
     * @param int   $index
     *
     * @return array
     */
    private static function formatRowData($row, $index)
    {
        return [
            'index' => $index,
            'cells' => array_map([self::class, 'extractCellValue'], $row['cells']),
            'props' => $row['props'] ?? []
        ];
    }

    /**
     * Extract column cells from rows.
     *
     * @param array $rows
     * @param int   $columnIndex
     *
     * @return array
     */
    private static function extractColumnCells($rows, $columnIndex)
    {
        $columnCells = [];

        foreach ($rows as $rowIndex => $row) {
            if (isset($row['cells'][$columnIndex])) {
                $columnCells[] = [
                    'row'   => $rowIndex,
                    'value' => self::extractCellValue($row['cells'][$columnIndex])
                ];
            }
        }

        return $columnCells;
    }

    /**
     * Create DOMDocument from HTML.
     *
     * @param string $html
     *
     * @return DOMDocument
     */
    private static function createDomDocument($html)
    {
        $dom = new DOMDocument();

        $previousUseInternalErrors = libxml_use_internal_errors(true);

        try {
            $dom->substituteEntities = false;

            $htmlContent = \function_exists('mb_convert_encoding')
                ? mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8')
                : $html;

            $dom->loadHTML(
                $htmlContent,
                \LIBXML_HTML_NOIMPLIED | \LIBXML_HTML_NODEFDTD | \LIBXML_NONET
            );
        } finally {
            libxml_clear_errors();
            libxml_use_internal_errors($previousUseInternalErrors);
        }

        return $dom;
    }

    /**
     * Initialize table data structure.
     *
     * @return array
     */
    private static function initializeTableData()
    {
        return [
            'rows'  => [],
            'props' => ['cols' => 0]
        ];
    }

    /**
     * Extract table rows from DOM.
     *
     * @param DOMXPath $xpath
     * @param DOMNode  $table
     *
     * @return DOMNodeList
     */
    private static function extractTableRows($xpath, $table)
    {
        $tbody = $xpath->query('.//tbody', $table)->item(0);

        return $tbody
            ? $xpath->query('.//tr', $tbody)
            : $xpath->query('.//tr', $table);
    }

    /**
     * Parse rows data from DOM elements.
     *
     * @param DOMNodeList $rows
     * @param DOMXPath     $xpath
     * @param array        &$tableData
     *
     * @return int Max columns
     */
    private static function parseRowsData($rows, $xpath, &$tableData)
    {
        $maxCols = 0;

        foreach ($rows as $trElement) {
            $rowData = self::buildRowDataFromElement($trElement, $xpath);
            $maxCols = max($maxCols, \count($rowData['cells']));
            $tableData['rows'][] = $rowData;
        }

        return $maxCols;
    }

    /**
     * Build row data from DOM element.
     *
     * @param DOMNode  $trElement
     * @param DOMXPath $xpath
     *
     * @return array
     */
    private static function buildRowDataFromElement($trElement, $xpath)
    {
        $rowData = [
            'cells' => [],
            'props' => self::extractRowProperties($trElement)
        ];

        $cells = $xpath->query('.//td | .//th', $trElement);
        foreach ($cells as $cellElement) {
            $rowData['cells'][] = self::buildCellFromElement($cellElement, $xpath);
        }

        return $rowData;
    }

    /**
     * Extract row properties from DOM element.
     *
     * @param DOMNode $trElement
     *
     * @return array
     */
    private static function extractRowProperties($trElement)
    {
        $props = [
            'background'  => '',
            'highlighted' => ''
        ];

        if ($trElement->hasAttribute('style')) {
            $style = $trElement->getAttribute('style');
            if (preg_match('/background-color:\s*([^;]+)/i', $style, $matches)) {
                $props['background'] = sanitize_text_field(trim($matches[1]));
            }
        }

        return $props;
    }

    /**
     * Build cell data from DOM element.
     *
     * @param DOMNode  $cellElement
     * @param DOMXPath $xpath
     *
     * @return array
     */
    private static function buildCellFromElement($cellElement, $xpath)
    {
        return [
            'type'  => self::CELL_TYPE_TEXT,
            'props' => [
                'content'       => self::extractCellContent($cellElement, $xpath),
                'colspan'       => self::extractCellAttribute($cellElement, 'colspan'),
                'rowspan'       => self::extractCellAttribute($cellElement, 'rowspan'),
                'verticalAlign' => self::extractVerticalAlignment($cellElement),
                'textAlign'     => self::DEFAULT_ALIGN_HORIZONTAL
            ],
            'innerElements' => []
        ];
    }

    /**
     * Extract cell content from DOM element.
     *
     * @param DOMNode  $cellElement
     * @param DOMXPath $xpath
     *
     * @return string
     */
    private static function extractCellContent($cellElement, $xpath)
    {
        $textContainer = $xpath->query('.//*[@class="wptb-text-container"] | .//*[@class="wptb-ph-element"]', $cellElement)->item(0);

        return $textContainer
            ? wp_kses_post(trim(self::getInnerHTML($textContainer)))
            : sanitize_text_field(trim($cellElement->textContent));
    }

    /**
     * Extract cell attribute value.
     *
     * @param DOMNode $cellElement
     * @param string  $attribute
     *
     * @return int
     */
    private static function extractCellAttribute($cellElement, $attribute)
    {
        return $cellElement->hasAttribute($attribute)
            ? (int) $cellElement->getAttribute($attribute)
            : 1;
    }

    /**
     * Extract vertical alignment from cell element.
     *
     * @param DOMNode $cellElement
     *
     * @return string
     */
    private static function extractVerticalAlignment($cellElement)
    {
        return $cellElement->hasAttribute('data-wptb-cell-vertical-alignment')
            ? sanitize_text_field($cellElement->getAttribute('data-wptb-cell-vertical-alignment'))
            : self::DEFAULT_ALIGN_VERTICAL;
    }
}
