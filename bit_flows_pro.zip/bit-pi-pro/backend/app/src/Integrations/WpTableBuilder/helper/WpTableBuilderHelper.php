<?php

namespace BitApps\PiPro\src\Integrations\WpTableBuilder\helper;

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\PiPro\Deps\BitApps\WPValidator\Validator;
use WP_Post;

if (!defined('ABSPATH')) {
    exit;
}

final class WpTableBuilderHelper
{
    /**
     * Check if WP Table Builder plugin is installed.
     *
     * @return bool
     */
    public static function isPluginInstalled()
    {
        return defined('WPTB_PLUGIN_DIR');
    }

    /**
     * Validate field map.
     *
     * @param array $fieldMappings
     * @param array $validationRules
     * @param array $payload
     *
     * @return null|array
     */
    public static function validateFieldMap($fieldMappings, $validationRules, $payload = null)
    {
        $validator = new Validator();
        $validation = $validator->make($fieldMappings, $validationRules);

        if ($validation->fails()) {
            return [
                'response'    => $validation->errors(),
                'payload'     => $payload ?? $fieldMappings,
                'status_code' => 400
            ];
        }
    }

    /**
     * Prepare table data for response.
     *
     * @param WP_Post $table
     *
     * @return array
     */
    public static function prepareTableData($table)
    {
        if (!$table) {
            return [];
        }

        $isPrebuilt = get_post_meta($table->ID, '_wptb_prebuilt_', true);
        $tableContent = get_post_meta($table->ID, '_wptb_content_', true);
        $content = WpTableBuilderRowColumnHelper::parseTableContent($tableContent ?? '');

        return [
            'id'          => $table->ID,
            'title'       => $table->post_title,
            'content'     => $content,
            'status'      => $table->post_status,
            'author'      => $table->post_author,
            'date'        => $table->post_date,
            'modified'    => $table->post_modified,
            'is_prebuilt' => $isPrebuilt === '1',
            'permalink'   => get_permalink($table->ID),
            'edit_link'   => admin_url('admin.php?page=wptb-builder&table=' . $table->ID),
        ];
    }

    /**
     * Get all tables.
     *
     * @param array $args
     *
     * @return array
     */
    public static function getTables($args = [])
    {
        $defaultArgs = [
            'post_type'      => 'wptb-tables',
            'post_status'    => 'any',
            'posts_per_page' => 100,
        ];

        $args = array_merge($defaultArgs, $args);

        $tables = get_posts($args);

        return array_map([self::class, 'prepareTableData'], $tables);
    }

    /**
     * Get table by ID.
     *
     * @param int $tableId
     *
     * @return null|array
     */
    public static function getTable($tableId)
    {
        $table = get_post($tableId);

        if (!$table || $table->post_type !== 'wptb-tables') {
            return;
        }

        return self::prepareTableData($table);
    }

    /**
     * Get all tables as select options.
     *
     * @return array
     */
    public static function getAllTable()
    {
        if (!self::isPluginInstalled()) {
            // translators: %s: Plugin name
            return Response::error(\sprintf(__('%s plugin is not active.', 'bit-pi'), 'WP Table Builder'));
        }

        $tables = self::getTables(['posts_per_page' => -1]);
        $options = [];

        foreach ($tables as $table) {
            if (empty($table['id'])) {
                continue;
            }

            $title = empty($table['title']) ? __('Untitled Table', 'bit-pi') : $table['title'];

            $options[] = (object) [
                'value' => (string) $table['id'],
                'label' => "#{$table['id']} - {$title}",
            ];
        }

        return Response::success($options);
    }
}
