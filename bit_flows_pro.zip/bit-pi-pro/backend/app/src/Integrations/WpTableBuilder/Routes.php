<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\PiPro\src\Integrations\WpTableBuilder\helper\WpTableBuilderHelper;

Route::group(
    function () {
        Route::get('wptablebuilder/get/tables', [WpTableBuilderHelper::class, 'getAllTable']);
    }
)->middleware('nonce:admin');
