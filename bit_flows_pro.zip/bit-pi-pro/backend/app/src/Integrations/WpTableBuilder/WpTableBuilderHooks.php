<?php

namespace BitApps\PiPro\src\Integrations\WpTableBuilder;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!defined('ABSPATH')) {
    exit;
}

class WpTableBuilderHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'tableCreated' => [
                'hook'          => 'wp_insert_post',
                'callback'      => [WpTableBuilderTrigger::class, 'tableCreated'],
                'priority'      => 20,
                'accepted_args' => 3,
            ],
            'tableUpdated' => [
                'hook'          => 'post_updated',
                'callback'      => [WpTableBuilderTrigger::class, 'tableUpdated'],
                'priority'      => 20,
                'accepted_args' => 3,
            ],
            'tableTrashed' => [
                'hook'          => 'transition_post_status',
                'callback'      => [WpTableBuilderTrigger::class, 'tableTrashed'],
                'priority'      => 20,
                'accepted_args' => 3,
            ],
            'tableRestored' => [
                'hook'          => 'transition_post_status',
                'callback'      => [WpTableBuilderTrigger::class, 'tableRestored'],
                'priority'      => 20,
                'accepted_args' => 3,
            ],
        ];
    }
}
