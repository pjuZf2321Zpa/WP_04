<?php

namespace BitApps\PiPro\src\Integrations\WpTableBuilder;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;

if (!defined('ABSPATH')) {
    exit;
}

class WpTableBuilderAction implements ActionInterface
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeWpTableBuilderAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'] ?? 200,
            $executedNodeAction['payload'] ?? [],
            $executedNodeAction['response'] ?? []
        );
    }

    private function executeWpTableBuilderAction()
    {
        if (!defined('WPTB_PLUGIN_DIR')) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('WP Table Builder plugin is not active.', 'bit-pi'),
            ];
        }

        $wpTableBuilderService = new WpTableBuilderService($this->nodeInfoProvider);

        $machineSlug = $this->nodeInfoProvider->getMachineSlug();

        if (!\is_callable([$wpTableBuilderService, $machineSlug])) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('WP Table Builder action not found.', 'bit-pi'),
            ];
        }

        return $wpTableBuilderService->{$machineSlug}();
    }
}
