<?php

namespace BitApps\PiPro\src\Integrations\WpTableBuilder;

use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\PiPro\src\Integrations\WpTableBuilder\helper\WpTableBuilderHelper;
use BitApps\PiPro\src\Integrations\WpTableBuilder\helper\WpTableBuilderRowColumnHelper;
use WP_Error;
use WP_Post;

if (!defined('ABSPATH')) {
    exit;
}

final class WpTableBuilderService
{
    private const POST_TYPE = 'wptb-tables';

    private const CONTENT_META_KEY = '_wptb_content_';

    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    /**
     * Get all tables.
     *
     * @return array
     */
    public function getAllTable()
    {
        $tables = $this->fetchTables();
        $preparedTables = $this->prepareTablesData($tables);

        return [
            'response'    => ['data' => $preparedTables],
            'payload'     => [],
            'status_code' => 200
        ];
    }

    /**
     * Get table by ID.
     *
     * @return array
     */
    public function getTableById()
    {
        $fieldMappings = $this->getFieldMappings();

        $validationError = WpTableBuilderHelper::validateFieldMap(
            $fieldMappings,
            [
                'table_id' => ['required', 'integer']
            ]
        );
        if ($validationError) {
            return $validationError;
        }

        $table = $this->findTableById($fieldMappings['table_id']);
        if (!$table) {
            return [
                'response'    => __('Table not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404
            ];
        }

        return [
            'response'    => WpTableBuilderHelper::prepareTableData($table),
            'payload'     => $fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Create table.
     *
     * @return array
     */
    public function createTable()
    {
        $fieldMappings = $this->getFieldMappings();

        $validationError = WpTableBuilderHelper::validateFieldMap(
            $fieldMappings,
            [
                'title'   => ['required', 'string'],
                'content' => ['required', 'string']
            ]
        );
        if ($validationError) {
            return $validationError;
        }

        $tableId = $this->insertTable($fieldMappings['title']);
        if (is_wp_error($tableId)) {
            return [
                'response'    => $tableId->get_error_message(),
                'payload'     => $fieldMappings,
                'status_code' => 400
            ];
        }

        $this->updateTableContent($tableId, $fieldMappings['content']);

        return [
            'response'    => WpTableBuilderHelper::prepareTableData(get_post($tableId)),
            'payload'     => $fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Update table.
     *
     * @return array
     */
    public function updateTable()
    {
        $fieldMappings = $this->getFieldMappings();

        $validationError = WpTableBuilderHelper::validateFieldMap(
            $fieldMappings,
            [
                'table_id' => ['required', 'integer'],
                'title'    => ['nullable', 'string'],
                'content'  => ['nullable', 'string'],
            ]
        );
        if ($validationError) {
            return $validationError;
        }

        if (!$this->hasUpdateData($fieldMappings)) {
            return [
                'response'    => __('At least one of title or content must be provided for update.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400
            ];
        }

        $table = $this->findTableById($fieldMappings['table_id']);
        if (!$table) {
            return [
                'response'    => __('Table not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404
            ];
        }

        $updateResult = $this->performTableUpdate($fieldMappings);
        if (is_wp_error($updateResult)) {
            return [
                'response'    => $updateResult->get_error_message(),
                'payload'     => $fieldMappings,
                'status_code' => 400
            ];
        }

        return [
            'response'    => WpTableBuilderHelper::prepareTableData(get_post($fieldMappings['table_id'])),
            'payload'     => $fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Delete table.
     *
     * @return array
     */
    public function deleteTable()
    {
        $fieldMappings = $this->getFieldMappings();

        $validationError = WpTableBuilderHelper::validateFieldMap(
            $fieldMappings,
            [
                'table_id' => ['required', 'integer']
            ]
        );
        if ($validationError) {
            return $validationError;
        }

        $table = $this->findTableById($fieldMappings['table_id']);
        if (!$table) {
            return [
                'response'    => __('Table not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404
            ];
        }

        $deleteResult = $this->performTableDelete($fieldMappings['table_id'], $fieldMappings['force_delete'] ?? false);
        if (!$deleteResult) {
            return [
                'response'    => __('Failed to delete table.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400
            ];
        }

        return [
            'response'    => __('Table deleted successfully.', 'bit-pi'),
            'payload'     => $fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Get row from table.
     *
     * @return array
     */
    public function getRowFromTable()
    {
        $fieldMappings = $this->getFieldMappings();

        $validationError = WpTableBuilderHelper::validateFieldMap(
            $fieldMappings,
            [
                'table_id'  => ['required', 'integer'],
                'row_index' => ['required', 'integer']
            ]
        );
        if ($validationError) {
            return $validationError;
        }

        $tableData = $this->getTableContent($fieldMappings['table_id']);
        if (!$tableData) {
            return [
                'response'    => __('Invalid table content.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400
            ];
        }

        $row = WpTableBuilderRowColumnHelper::getRow($tableData, $fieldMappings['row_index']);
        if (!$row) {
            return [
                'response'    => __('Row not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404
            ];
        }

        return [
            'response'    => $row,
            'payload'     => $fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * List all rows from table.
     *
     * @return array
     */
    public function listRowsInTable()
    {
        $fieldMappings = $this->getFieldMappings();

        $validationError = WpTableBuilderHelper::validateFieldMap(
            $fieldMappings,
            [
                'table_id' => ['required', 'integer']
            ]
        );
        if ($validationError) {
            return $validationError;
        }

        $tableData = $this->getTableContent($fieldMappings['table_id']);
        if (!$tableData) {
            return [
                'response'    => __('Invalid table content.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400
            ];
        }

        $rows = WpTableBuilderRowColumnHelper::getAllRows($tableData);

        return [
            'response'    => ['data' => $rows],
            'payload'     => $fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Get column from table.
     *
     * @return array
     */
    public function getColumnFromTable()
    {
        $fieldMappings = $this->getFieldMappings();

        $validationError = WpTableBuilderHelper::validateFieldMap(
            $fieldMappings,
            [
                'table_id'     => ['required', 'integer'],
                'column_index' => ['required', 'integer']
            ]
        );
        if ($validationError) {
            return $validationError;
        }

        $tableData = $this->getTableContent($fieldMappings['table_id']);
        if (!$tableData) {
            return [
                'response'    => __('Invalid table content.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400
            ];
        }

        $column = WpTableBuilderRowColumnHelper::getColumn($tableData, $fieldMappings['column_index']);
        if (!$column) {
            return [
                'response'    => __('Column not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404
            ];
        }

        return [
            'response'    => ['data' => $column],
            'payload'     => $fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Get cell value from table.
     *
     * @return array
     */
    public function getCellFromTable()
    {
        $fieldMappings = $this->getFieldMappings();

        $validationError = WpTableBuilderHelper::validateFieldMap(
            $fieldMappings,
            [
                'table_id'     => ['required', 'integer'],
                'row_index'    => ['required', 'integer'],
                'column_index' => ['required', 'integer']
            ]
        );
        if ($validationError) {
            return $validationError;
        }

        $tableData = $this->getTableContent($fieldMappings['table_id']);
        if (!$tableData) {
            return [
                'response'    => __('Invalid table content.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400
            ];
        }

        $value = WpTableBuilderRowColumnHelper::getCellValue(
            $tableData,
            $fieldMappings['row_index'],
            $fieldMappings['column_index']
        );

        if ($value === null) {
            return [
                'response'    => __('Cell not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404
            ];
        }

        return [
            'response'    => ['value' => $value],
            'payload'     => $fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Get field mappings from node info provider.
     *
     * @return array
     */
    private function getFieldMappings()
    {
        return $this->nodeInfoProvider->getFieldMapData();
    }

    /**
     * Fetch all tables from database.
     *
     * @return array
     */
    private function fetchTables()
    {
        return get_posts(
            [
                'post_type'      => self::POST_TYPE,
                'post_status'    => 'any',
                'posts_per_page' => -1
            ]
        );
    }

    /**
     * Prepare multiple tables data for response.
     *
     * @param array $tables
     *
     * @return array
     */
    private function prepareTablesData($tables)
    {
        return array_map([WpTableBuilderHelper::class, 'prepareTableData'], $tables);
    }

    /**
     * Find table by ID and verify it's a valid table post type.
     *
     * @param int $tableId
     *
     * @return null|WP_Post
     */
    private function findTableById($tableId)
    {
        $table = get_post($tableId);

        return ($table && $table->post_type === self::POST_TYPE) ? $table : null;
    }

    /**
     * Insert new table post.
     *
     * @param string $title
     *
     * @return int|WP_Error
     */
    private function insertTable($title)
    {
        return wp_insert_post(
            [
                'post_title'  => $title,
                'post_type'   => self::POST_TYPE,
                'post_status' => 'draft',
            ]
        );
    }

    /**
     * Update table content meta.
     *
     * @param int    $tableId
     * @param string $content
     *
     * @return bool
     */
    private function updateTableContent($tableId, $content)
    {
        if (empty($content)) {
            return false;
        }

        return update_post_meta($tableId, self::CONTENT_META_KEY, $content);
    }

    /**
     * Check if field mappings have data to update.
     *
     * @param array $fieldMappings
     *
     * @return bool
     */
    private function hasUpdateData($fieldMappings)
    {
        return !empty($fieldMappings['title']) || !empty($fieldMappings['content']);
    }

    /**
     * Perform table update operation.
     *
     * @param array $fieldMappings
     *
     * @return bool|int|WP_Error
     */
    private function performTableUpdate($fieldMappings)
    {
        $result = true;

        if (!empty($fieldMappings['title'])) {
            $result = wp_update_post(
                [
                    'ID'         => $fieldMappings['table_id'],
                    'post_title' => $fieldMappings['title'],
                ]
            );

            if (is_wp_error($result)) {
                return $result;
            }
        }

        if (!empty($fieldMappings['content'])) {
            $this->updateTableContent($fieldMappings['table_id'], $fieldMappings['content']);
        }

        return $result;
    }

    /**
     * Perform table delete operation.
     *
     * @param int  $tableId
     * @param bool $forceDelete
     *
     * @return null|false|WP_Post
     */
    private function performTableDelete($tableId, $forceDelete)
    {
        return $forceDelete ? wp_delete_post($tableId, true) : wp_trash_post($tableId);
    }

    /**
     * Get parsed table content.
     *
     * @param int $tableId
     *
     * @return null|array
     */
    private function getTableContent($tableId)
    {
        $contentData = WpTableBuilderRowColumnHelper::getTableContent($tableId);

        return WpTableBuilderRowColumnHelper::parseTableContent($contentData['content']);
    }
}
