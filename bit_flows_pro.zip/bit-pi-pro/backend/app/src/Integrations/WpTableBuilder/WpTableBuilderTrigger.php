<?php

namespace BitApps\PiPro\src\Integrations\WpTableBuilder;

use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\WpTableBuilder\helper\WpTableBuilderHelper;
use WP_Post;

if (!defined('ABSPATH')) {
    exit;
}

final class WpTableBuilderTrigger
{
    private const POST_TYPE = 'wptb-tables';

    private const STATUS_TRASH = 'trash';

    private const STATUS_PUBLISH = 'publish';

    /**
     * Handle table created trigger.
     *
     * @param int     $postId Post ID
     * @param WP_Post $post   Post object
     * @param bool    $update Whether this is an update
     */
    public static function tableCreated($postId, $post, $update)
    {
        if (!self::isNewTable($post, $update)) {
            return;
        }

        $tableData = WpTableBuilderHelper::prepareTableData($post);
        self::execute('tableCreated', $tableData);
    }

    /**
     * Handle table updated trigger.
     *
     * @param int     $postId     Post ID
     * @param WP_Post $post       Updated post object
     * @param WP_Post $postBefore Previous post object
     */
    public static function tableUpdated($postId, $post, $postBefore)
    {
        if (!self::isValidTablePost($post)) {
            return;
        }

        $tableData = WpTableBuilderHelper::prepareTableData($post);
        $tableData['old_data'] = WpTableBuilderHelper::prepareTableData($postBefore);

        self::execute('tableUpdated', $tableData);
    }

    /**
     * Handle table trashed trigger.
     *
     * @param string  $newStatus New post status
     * @param string  $oldStatus Old post status
     * @param WP_Post $post      Post object
     */
    public static function tableTrashed($newStatus, $oldStatus, $post)
    {
        if (!self::isStatusTransition($post, $newStatus, self::STATUS_TRASH)) {
            return;
        }

        $tableData = WpTableBuilderHelper::prepareTableData($post);
        self::execute('tableTrashed', $tableData);
    }

    /**
     * Handle table restored trigger.
     *
     * @param string  $newStatus New post status
     * @param string  $oldStatus Old post status
     * @param WP_Post $post      Post object
     */
    public static function tableRestored($newStatus, $oldStatus, $post)
    {
        if (!self::isStatusTransition($post, $oldStatus, self::STATUS_TRASH)) {
            return;
        }

        $tableData = WpTableBuilderHelper::prepareTableData($post);
        self::execute('tableRestored', $tableData);
    }

    /**
     * Check if post is a valid table post.
     *
     * @param WP_Post $post Post object
     *
     * @return bool
     */
    private static function isValidTablePost($post)
    {
        return isset($post->post_type) && $post->post_type === self::POST_TYPE;
    }

    /**
     * Check if this is a new table creation (not an update).
     *
     * @param WP_Post $post   Post object
     * @param bool    $update Whether this is an update
     *
     * @return bool
     */
    private static function isNewTable($post, $update)
    {
        return !$update && self::isValidTablePost($post);
    }

    /**
     * Check if post status is transitioning to/from a specific status.
     *
     * @param WP_Post $post          Post object
     * @param string  $statusToCheck Status to verify
     * @param string  $expectedValue Expected status value
     *
     * @return bool
     */
    private static function isStatusTransition($post, $statusToCheck, $expectedValue)
    {
        return self::isValidTablePost($post) && $statusToCheck === $expectedValue;
    }

    /**
     * Execute the trigger by finding and handling matching flows.
     *
     * @param string $machineSlug Machine slug identifier
     * @param array  $data        Data to pass to flows
     */
    private static function execute($machineSlug, $data)
    {
        $flows = FlowService::exists('wpTableBuilder', $machineSlug);

        if (!$flows) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $data);
    }
}
