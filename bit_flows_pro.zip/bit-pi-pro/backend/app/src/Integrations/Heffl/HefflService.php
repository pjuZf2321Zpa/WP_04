<?php

namespace BitApps\PiPro\src\Integrations\Heffl;

// Prevent direct script access
if (!defined('ABSPATH')) {
    exit;
}

use BitApps\Pi\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Client\HttpClient;

final class HefflService
{
    private HttpClient $http;

    private string $baseUrl;

    public function __construct(HttpClient $httpClient, string $baseUrl)
    {
        $this->http = $httpClient;
        $this->baseUrl = rtrim($baseUrl, '/');
    }

    public function createLead(array $configs, array $fieldMapData): array
    {
        $payload = $this->compactPayload(
            [
                'name'            => $fieldMapData['name'] ?? null,
                'email'           => $fieldMapData['email'] ?? null,
                'mobile'          => $fieldMapData['mobile'] ?? null,
                'secondaryMobile' => $fieldMapData['secondaryMobile'] ?? null,
                'title'           => $fieldMapData['title'] ?? null,
                'value'           => isset($fieldMapData['value']) && $fieldMapData['value'] !== ''
                ? (float) $fieldMapData['value']
                : null,
                'website'         => $fieldMapData['website'] ?? null,
                'sourceId'        => $configs['lead-source-id']['value'] ?? null,
                'stageId'         => $configs['lead-stage-id']['value'] ?? null,
            ]
        );

        $response = $this->http->request(
            $this->baseUrl . '/leads',
            'POST',
            JSON::encode($payload)
        );

        return [
            'response'    => $response,
            'payload'     => $payload,
            'status_code' => $this->http->getResponseCode(),
        ];
    }

    public function createClient(array $configs, array $fieldMapData): array
    {
        $type = $configs['client-type']['value'] ?? 'company';

        $payload = $this->compactPayload(
            [
                'type'      => $type,
                'name'      => $fieldMapData['name'] ?? null,
                'firstName' => $fieldMapData['firstName'] ?? null,
                'lastName'  => $fieldMapData['lastName'] ?? null,
                'email'     => $fieldMapData['email'] ?? null,
                'phone'     => $fieldMapData['phone'] ?? null,
                'website'   => $fieldMapData['website'] ?? null,
                'taxNumber' => $fieldMapData['taxNumber'] ?? null,
            ]
        );

        $response = $this->http->request(
            $this->baseUrl . '/clients',
            'POST',
            JSON::encode($payload)
        );

        return [
            'response'    => $response,
            'payload'     => $payload,
            'status_code' => $this->http->getResponseCode(),
        ];
    }

    public function createDeal(array $configs, array $fieldMapData): array
    {
        $payload = $this->compactPayload(
            [
                'title'             => $fieldMapData['title'] ?? null,
                'pipelineId'        => $configs['pipeline-id']['value'] ?? null,
                'stageId'           => $configs['stage-id']['value'] ?? null,
                'clientId'          => $configs['client-id']['value'] ?? null,
                'sourceId'          => $configs['lead-source-id']['value'] ?? null,
                'priority'          => $configs['priority']['value'] ?? null,
                'price'             => isset($fieldMapData['price']) && $fieldMapData['price'] !== ''
                ? (float) $fieldMapData['price']
                : null,
                'expectedCloseDate' => $fieldMapData['expectedCloseDate'] ?? null,
            ]
        );

        $response = $this->http->request(
            $this->baseUrl . '/deals',
            'POST',
            JSON::encode($payload)
        );

        return [
            'response'    => $response,
            'payload'     => $payload,
            'status_code' => $this->http->getResponseCode(),
        ];
    }

    private function compactPayload(array $payload): array
    {
        return array_filter(
            $payload,
            static function ($value) {
                return $value !== null && $value !== '';
            }
        );
    }
}
