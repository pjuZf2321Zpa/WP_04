<?php

namespace BitApps\PiPro\src\Integrations\Heffl;

// Prevent direct script access
if (!defined('ABSPATH')) {
    exit;
}

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Client\HttpClient;
use BitApps\PiPro\src\Integrations\Heffl\Helpers\Common;
use InvalidArgumentException;

class HefflAction implements ActionInterface
{
    private const CREATE_LEAD = 'createLead';

    private const CREATE_CLIENT = 'createClient';

    private const CREATE_DEAL = 'createDeal';

    private NodeInfoProvider $nodeInfoProvider;

    private HefflService $hefflService;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $configs = $this->nodeInfoProvider->getFieldMapConfigs();
        $fieldMapData = $this->nodeInfoProvider->getFieldMapData();
        $machineSlug = $this->nodeInfoProvider->getMachineSlug();

        $connectionId = (int) ($configs['connection-id']['value'] ?? 0);

        if (!$connectionId) {
            return Utility::formatResponseData(
                401,
                $configs,
                ['error' => 'No connection selected'],
                'No connection selected for Heffl CRM.'
            );
        }

        $headers = Common::getAuthorizationHeader($connectionId);

        if (isset($headers['error'])) {
            return Utility::formatResponseData(
                401,
                $configs,
                $headers,
                $headers['message'] ?? 'Failed to authenticate with Heffl CRM. Verify your API key.'
            );
        }

        $this->hefflService = new HefflService(
            new HttpClient(['headers' => $headers]),
            Common::BASE_URL
        );

        $result = $this->executeMachine($machineSlug, $configs, $fieldMapData);

        return Utility::formatResponseData(
            $result['status_code'],
            $result['payload'],
            $result['response']
        );
    }

    private function executeMachine(string $machineSlug, array $configs, array $fieldMapData): array
    {
        switch ($machineSlug) {
            case self::CREATE_LEAD:
                return $this->hefflService->createLead($configs, $fieldMapData);

            case self::CREATE_CLIENT:
                return $this->hefflService->createClient($configs, $fieldMapData);

            case self::CREATE_DEAL:
                return $this->hefflService->createDeal($configs, $fieldMapData);

            default:
                throw new InvalidArgumentException('Unknown Heffl machine slug: ' . $machineSlug);
        }
    }
}
