<?php

namespace BitApps\PiPro\src\Integrations\Heffl\Helpers;

// Prevent direct script access
if (!defined('ABSPATH')) {
    exit;
}

use BitApps\Pi\src\Authorization\AuthorizationFactory;
use BitApps\Pi\src\Authorization\AuthorizationType;

class Common
{
    public const BASE_URL = 'https://api.heffl.com/api/v1';

    /**
     * Build authorization headers for Heffl requests.
     *
     * @return array Either header map (success) or `['error' => true, 'message' => string]` from
     *               the underlying authorization handler (e.g. connection missing, decrypt failed).
     */
    public static function getAuthorizationHeader(int $connectionId): array
    {
        $apiKey = AuthorizationFactory::getAuthorizationHandler(
            AuthorizationType::API_KEY,
            $connectionId
        )->getAccessToken();

        if (\is_array($apiKey) && isset($apiKey['error'])) {
            return $apiKey;
        }

        if (!\is_string($apiKey) || $apiKey === '') {
            return [
                'error'   => true,
                'message' => __('Failed to resolve Heffl API key', 'bit-pi'),
            ];
        }

        return [
            'x-api-key'    => $apiKey,
            'Content-Type' => 'application/json',
            'Accept'       => 'application/json',
        ];
    }
}
