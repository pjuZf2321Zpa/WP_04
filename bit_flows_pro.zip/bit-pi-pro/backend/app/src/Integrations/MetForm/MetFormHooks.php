<?php

namespace BitApps\PiPro\src\Integrations\MetForm;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!\defined('ABSPATH')) {
    exit;
}

class MetFormHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'formSubmit' => [
                'hook'          => ['metform_after_store_form_data'],
                'callback'      => [MetFormTrigger::class, 'handleSubmit'],
                'priority'      => 10,
                'accepted_args' => 4,
            ],
        ];
    }
}
