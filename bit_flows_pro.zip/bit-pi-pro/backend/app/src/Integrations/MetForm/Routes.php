<?php

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\PiPro\src\Integrations\MetForm\MetFormHelper;

if (!defined('ABSPATH')) {
    exit;
}

Route::group(
    function () {
        Route::post('met-forms/get-forms', [MetFormHelper::class, 'getForms']);
    }
)->middleware('nonce', 'isAdmin');
