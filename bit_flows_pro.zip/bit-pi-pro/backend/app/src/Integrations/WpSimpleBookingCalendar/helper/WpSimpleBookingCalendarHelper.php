<?php

namespace BitApps\PiPro\src\Integrations\WpSimpleBookingCalendar\helper;

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Request\Request;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Response;

if (!defined('ABSPATH')) {
    exit;
}

final class WpSimpleBookingCalendarHelper
{
    public static function isPluginInstalled()
    {
        return \defined('WPSBC_VERSION') && \function_exists('wpsbc_get_calendar');
    }

    public static function getCalendarData($calendar)
    {
        $calendar = \is_object($calendar) ? $calendar : wpsbc_get_calendar((int) $calendar);

        if (!\is_object($calendar)) {
            return [];
        }

        $data = $calendar->to_array();
        $data['calendar_id'] = (int) $data['id'];
        $data['meta'] = self::flattenMeta(wpsbc_get_calendar_meta($data['id']));

        return $data;
    }

    public static function getEventData($event)
    {
        $event = \is_object($event) ? $event : wpsbc_get_event((int) $event);

        if (!\is_object($event)) {
            return [];
        }

        $data = $event->to_array();
        $data['event_id'] = (int) $data['id'];
        $data['date'] = self::formatDate($data['date_year'], $data['date_month'], $data['date_day']);

        $calendar = wpsbc_get_calendar((int) $data['calendar_id']);
        $data['calendar_name'] = \is_object($calendar) ? $calendar->get('name') : '';

        $legendItem = wpsbc_get_legend_item((int) $data['legend_item_id']);
        $data['legend_item_name'] = \is_object($legendItem) ? $legendItem->get('name') : '';
        $data['legend_item_color'] = \is_object($legendItem) ? $legendItem->get('color') : '';
        $data['meta'] = self::flattenMeta(wpsbc_get_event_meta($data['id']));

        return $data;
    }

    public static function getLegendItemData($legendItem)
    {
        $legendItem = \is_object($legendItem) ? $legendItem : wpsbc_get_legend_item((int) $legendItem);

        if (!\is_object($legendItem)) {
            return [];
        }

        $data = $legendItem->to_array();
        $data['legend_item_id'] = (int) $data['id'];

        $calendar = wpsbc_get_calendar((int) $data['calendar_id']);
        $data['calendar_name'] = \is_object($calendar) ? $calendar->get('name') : '';
        $data['meta'] = self::flattenMeta(wpsbc_get_legend_item_meta($data['id']));

        return $data;
    }

    public static function getSavedCalendarData($postData)
    {
        $formData = $postData['form_data'] ?? [];
        $calendarId = (int) ($formData['calendar_id'] ?? 0);

        if ($calendarId <= 0) {
            return [];
        }

        return [
            'calendar_id'   => $calendarId,
            'calendar_name' => $formData['calendar_name'] ?? '',
            'current_year'  => (int) ($postData['current_year'] ?? 0),
            'current_month' => (int) ($postData['current_month'] ?? 0),
            'events'        => $postData['calendar_data'] ?? [],
            'calendar'      => self::getCalendarData($calendarId),
        ];
    }

    public static function formatDate($year, $month, $day)
    {
        return \sprintf('%04d-%02d-%02d', (int) $year, (int) $month, (int) $day);
    }

    public static function parseDate($date)
    {
        $dateTime = is_numeric($date)
            ? date_create('@' . (int) $date)
            : date_create((string) $date, wp_timezone());

        if (!$dateTime) {
            return null;
        }

        $dateTime->setTimezone(wp_timezone());

        return [
            'year'  => (int) $dateTime->format('Y'),
            'month' => (int) $dateTime->format('n'),
            'day'   => (int) $dateTime->format('j'),
        ];
    }

    public static function getLegendItemIdsByCalendar($calendarId)
    {
        global $wpdb;

        return array_map(
            'intval',
            $wpdb->get_col($wpdb->prepare("SELECT id FROM {$wpdb->prefix}wpsbc_legend_items WHERE calendar_id = %d", (int) $calendarId))
        );
    }

    public static function flattenMeta($meta)
    {
        if (!\is_array($meta)) {
            return [];
        }

        $flattened = [];

        foreach ($meta as $key => $values) {
            $values = array_map('maybe_unserialize', (array) $values);
            $flattened[$key] = \count($values) === 1 ? reset($values) : $values;
        }

        return $flattened;
    }

    public static function getAllLegendItems($calendarId = 0)
    {
        if ($calendarId > 0) {
            return (array) wpsbc_get_legend_items(['calendar_id' => $calendarId]);
        }

        $legendItems = [];

        foreach ((array) wpsbc_get_calendars() as $calendar) {
            foreach ((array) wpsbc_get_legend_items(['calendar_id' => $calendar->get('id')]) as $legendItem) {
                $legendItems[] = $legendItem;
            }
        }

        return $legendItems;
    }

    public static function getCalendars(Request $request)
    {
        if (!self::isPluginInstalled()) {
            return Response::error(__('WP Simple Booking Calendar plugin is not active.', 'bit-pi'));
        }

        $options = [];

        if (!empty($request->get('with_any'))) {
            $options[] = ['value' => 'any', 'label' => __('Any Calendar', 'bit-pi')];
        }

        foreach ((array) wpsbc_get_calendars(['orderby' => 'name', 'order' => 'ASC']) as $calendar) {
            $options[] = [
                'value' => (int) $calendar->get('id'),
                'label' => $calendar->get('name') . ' (#' . $calendar->get('id') . ')',
            ];
        }

        return Response::success($options);
    }

    public static function getLegendItems(Request $request)
    {
        if (!self::isPluginInstalled()) {
            return Response::error(__('WP Simple Booking Calendar plugin is not active.', 'bit-pi'));
        }

        $calendarId = (int) $request->get('calendar_id', 0);
        $calendarNames = [];
        $options = [];

        foreach (self::getAllLegendItems($calendarId) as $legendItem) {
            $legendCalendarId = (int) $legendItem->get('calendar_id');

            if (!isset($calendarNames[$legendCalendarId])) {
                $calendar = wpsbc_get_calendar($legendCalendarId);
                $calendarNames[$legendCalendarId] = \is_object($calendar) ? $calendar->get('name') : '#' . $legendCalendarId;
            }

            $label = $calendarId > 0
                ? $legendItem->get('name')
                : $calendarNames[$legendCalendarId] . ' - ' . $legendItem->get('name');

            $options[] = [
                'value' => (int) $legendItem->get('id'),
                'label' => $label . ' (#' . $legendItem->get('id') . ')',
            ];
        }

        return Response::success($options);
    }

    public static function getEvents()
    {
        if (!self::isPluginInstalled()) {
            return Response::error(__('WP Simple Booking Calendar plugin is not active.', 'bit-pi'));
        }

        $calendarNames = [];
        $options = [];

        foreach ((array) wpsbc_get_events(['orderby' => 'id', 'order' => 'DESC']) as $event) {
            $eventCalendarId = (int) $event->get('calendar_id');

            if (!isset($calendarNames[$eventCalendarId])) {
                $calendar = wpsbc_get_calendar($eventCalendarId);
                $calendarNames[$eventCalendarId] = \is_object($calendar) ? $calendar->get('name') : '#' . $eventCalendarId;
            }

            $options[] = [
                'value' => (int) $event->get('id'),
                'label' => $calendarNames[$eventCalendarId] . ' - '
                    . self::formatDate($event->get('date_year'), $event->get('date_month'), $event->get('date_day'))
                    . ' (#' . $event->get('id') . ')',
            ];
        }

        return Response::success($options);
    }
}
