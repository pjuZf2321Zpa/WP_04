<?php

namespace BitApps\PiPro\src\Integrations\WpSimpleBookingCalendar;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!defined('ABSPATH')) {
    exit;
}

class WpSimpleBookingCalendarHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'calendarCreated' => [
                'hook'          => 'wpsbc_insert_calendar',
                'callback'      => [WpSimpleBookingCalendarTrigger::class, 'calendarCreated'],
            ],
            'calendarUpdated' => [
                'hook'          => 'wpsbc_update_calendar',
                'callback'      => [WpSimpleBookingCalendarTrigger::class, 'calendarUpdated'],
            ],
            'calendarTrashed' => [
                'hook'          => 'wpsbc_update_calendar',
                'callback'      => [WpSimpleBookingCalendarTrigger::class, 'calendarTrashed'],
                'accepted_args' => 2,
            ],
            'calendarRestored' => [
                'hook'          => 'wpsbc_update_calendar',
                'callback'      => [WpSimpleBookingCalendarTrigger::class, 'calendarRestored'],
                'accepted_args' => 2,
            ],
            'calendarDeleted' => [
                'hook'     => 'wpsbc_pre_delete_calendar',
                'callback' => [WpSimpleBookingCalendarTrigger::class, 'calendarDeleted'],
            ],
            'calendarDataSaved' => [
                'hook'     => 'wpsbc_save_calendar_data',
                'callback' => [WpSimpleBookingCalendarTrigger::class, 'calendarDataSaved'],
            ],
            'eventCreated' => [
                'hook'          => 'wpsbc_insert_event',
                'callback'      => [WpSimpleBookingCalendarTrigger::class, 'eventCreated'],
            ],
            'eventUpdated' => [
                'hook'          => 'wpsbc_update_event',
                'callback'      => [WpSimpleBookingCalendarTrigger::class, 'eventUpdated'],
            ],
            'eventDeleted' => [
                'hook'     => 'wpsbc_pre_delete_event',
                'callback' => [WpSimpleBookingCalendarTrigger::class, 'eventDeleted'],
            ],
            'legendItemCreated' => [
                'hook'          => 'wpsbc_insert_legend_item',
                'callback'      => [WpSimpleBookingCalendarTrigger::class, 'legendItemCreated'],
            ],
            'legendItemUpdated' => [
                'hook'          => 'wpsbc_update_legend_item',
                'callback'      => [WpSimpleBookingCalendarTrigger::class, 'legendItemUpdated'],
            ],
            'legendItemDeleted' => [
                'hook'     => 'wpsbc_pre_delete_legend_item',
                'callback' => [WpSimpleBookingCalendarTrigger::class, 'legendItemDeleted'],
            ],
        ];
    }
}
