<?php

namespace BitApps\PiPro\src\Integrations\WpSimpleBookingCalendar\Services;

use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\WpSimpleBookingCalendar\helper\WpSimpleBookingCalendarHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class CalendarService extends BaseService
{
    public function createCalendar()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'name' => ['required', 'string'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $calendarId = wpsbc_insert_calendar(
            [
                'name'          => $fieldMappings['name'],
                'date_created'  => current_time('mysql'),
                'date_modified' => current_time('mysql'),
                'status'        => 'active',
                'ical_hash'     => wpsbc_generate_ical_hash(),
            ]
        );

        if (!$calendarId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to create calendar.', 'bit-pi'),
            ];
        }

        foreach (wpsbc_get_default_legend_items_data() as $legendItemData) {
            $translations = $legendItemData['translations'] ?? [];
            unset($legendItemData['translations']);

            $legendItemData['calendar_id'] = $calendarId;
            $legendItemId = wpsbc_insert_legend_item($legendItemData);

            foreach ($translations as $languageCode => $translation) {
                wpsbc_add_legend_item_meta($legendItemId, 'translation_' . $languageCode, $translation);
            }
        }

        $copyCalendarId = (int) ($fieldMappings['copy_legend_calendar_id'] ?? 0);

        if ($copyCalendarId > 0) {
            $this->copyLegendItems($copyCalendarId, $calendarId);
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => WpSimpleBookingCalendarHelper::getCalendarData($calendarId),
        ];
    }

    public function updateCalendar()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'calendar_id' => ['required', 'integer'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $calendar = $this->findCalendar($fieldMappings['calendar_id'], $fieldMappings);

        if (\is_array($calendar)) {
            return $calendar;
        }

        $calendarData = ['date_modified' => current_time('mysql')];

        if (!empty($fieldMappings['name'])) {
            $calendarData['name'] = $fieldMappings['name'];
        }

        if (!empty($fieldMappings['status'])) {
            $calendarData['status'] = $fieldMappings['status'];
        }

        return $this->updateCalendarRecord((int) $fieldMappings['calendar_id'], $calendarData, $fieldMappings);
    }

    public function trashCalendar()
    {
        return $this->changeCalendarStatus('trash');
    }

    public function restoreCalendar()
    {
        return $this->changeCalendarStatus('active');
    }

    public function deleteCalendar()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'calendar_id' => ['required', 'integer'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $calendarId = (int) $fieldMappings['calendar_id'];
        $calendar = $this->findCalendar($calendarId, $fieldMappings);

        if (\is_array($calendar)) {
            return $calendar;
        }

        $calendarData = WpSimpleBookingCalendarHelper::getCalendarData($calendar);

        if (!wpsbc_delete_calendar($calendarId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to delete calendar.', 'bit-pi'),
            ];
        }

        foreach (WpSimpleBookingCalendarHelper::getLegendItemIdsByCalendar($calendarId) as $legendItemId) {
            wpsbc_delete_legend_item($legendItemId);

            foreach (array_keys((array) wpsbc_get_legend_item_meta($legendItemId)) as $metaKey) {
                wpsbc_delete_legend_item_meta($legendItemId, $metaKey);
            }
        }

        foreach ((array) wpsbc_get_events(['calendar_id' => $calendarId]) as $event) {
            $eventId = (int) $event->get('id');
            wpsbc_delete_event($eventId);

            foreach (array_keys((array) wpsbc_get_event_meta($eventId)) as $metaKey) {
                wpsbc_delete_event_meta($eventId, $metaKey);
            }
        }

        foreach (array_keys((array) wpsbc_get_calendar_meta($calendarId)) as $metaKey) {
            wpsbc_delete_calendar_meta($calendarId, $metaKey);
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => array_merge($calendarData, ['deleted' => true]),
        ];
    }

    public function getCalendar()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'calendar_id' => ['required', 'integer'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $calendar = $this->findCalendar($fieldMappings['calendar_id'], $fieldMappings);

        if (\is_array($calendar)) {
            return $calendar;
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => WpSimpleBookingCalendarHelper::getCalendarData($calendar),
        ];
    }

    public function getCalendars()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $args = ['orderby' => 'id', 'order' => 'DESC'];

        if (!empty($fieldMappings['status']) && $fieldMappings['status'] !== 'any') {
            $args['status'] = $fieldMappings['status'];
        }

        if (!empty($fieldMappings['search'])) {
            $args['search'] = $fieldMappings['search'];
        }

        $calendars = [];

        foreach ((array) wpsbc_get_calendars($args) as $calendar) {
            $calendars[] = WpSimpleBookingCalendarHelper::getCalendarData($calendar);
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => $calendars,
        ];
    }

    private function changeCalendarStatus($status)
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'calendar_id' => ['required', 'integer'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $calendar = $this->findCalendar($fieldMappings['calendar_id'], $fieldMappings);

        if (\is_array($calendar)) {
            return $calendar;
        }

        return $this->updateCalendarRecord(
            (int) $fieldMappings['calendar_id'],
            ['status' => $status, 'date_modified' => current_time('mysql')],
            $fieldMappings
        );
    }

    private function updateCalendarRecord($calendarId, $calendarData, $fieldMappings)
    {
        if (!wpsbc_update_calendar($calendarId, $calendarData)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to update calendar.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => WpSimpleBookingCalendarHelper::getCalendarData($calendarId),
        ];
    }

    private function copyLegendItems($sourceCalendarId, $targetCalendarId)
    {
        foreach ((array) wpsbc_get_legend_items(['calendar_id' => $sourceCalendarId]) as $legendItem) {
            $legendItemData = $legendItem->to_array();
            $legendItemData['calendar_id'] = $targetCalendarId;
            unset($legendItemData['id']);

            $legendItemId = wpsbc_insert_legend_item($legendItemData);

            if (!$legendItemId) {
                continue;
            }

            foreach ((array) wpsbc_get_legend_item_meta($legendItem->get('id')) as $metaKey => $metaValues) {
                foreach ((array) $metaValues as $metaValue) {
                    wpsbc_add_legend_item_meta($legendItemId, $metaKey, maybe_unserialize($metaValue));
                }
            }
        }
    }
}
