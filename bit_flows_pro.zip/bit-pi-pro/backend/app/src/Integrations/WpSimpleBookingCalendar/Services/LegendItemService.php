<?php

namespace BitApps\PiPro\src\Integrations\WpSimpleBookingCalendar\Services;

use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\WpSimpleBookingCalendar\helper\WpSimpleBookingCalendarHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class LegendItemService extends BaseService
{
    public function createLegendItem()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'calendar_id' => ['required', 'integer'],
            'name'        => ['required', 'string'],
            'color'       => ['required', 'string'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $calendarId = (int) $fieldMappings['calendar_id'];
        $calendar = $this->findCalendar($calendarId, $fieldMappings);

        if (\is_array($calendar)) {
            return $calendar;
        }

        $existingLegendItems = wpsbc_get_legend_items(['calendar_id' => $calendarId, 'number' => 1]);
        $isDefault = isset($fieldMappings['is_default']) && $fieldMappings['is_default'] !== ''
            ? (int) $fieldMappings['is_default']
            : (empty($existingLegendItems) ? 1 : 0);

        $legendItemId = wpsbc_insert_legend_item(
            [
                'name'        => $fieldMappings['name'],
                'type'        => 'single',
                'color'       => [trim($fieldMappings['color'])],
                'color_text'  => $fieldMappings['color_text'] ?? '',
                'is_visible'  => isset($fieldMappings['is_visible']) && $fieldMappings['is_visible'] !== '' ? (int) $fieldMappings['is_visible'] : 1,
                'is_default'  => $isDefault,
                'calendar_id' => $calendarId,
            ]
        );

        if (!$legendItemId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to create legend item.', 'bit-pi'),
            ];
        }

        if ($isDefault) {
            $this->clearOtherDefaults($calendarId, $legendItemId);
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => WpSimpleBookingCalendarHelper::getLegendItemData($legendItemId),
        ];
    }

    public function updateLegendItem()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'legend_item_id' => ['required', 'integer'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $legendItem = $this->findLegendItem($fieldMappings['legend_item_id'], $fieldMappings);

        if (\is_array($legendItem)) {
            return $legendItem;
        }

        $legendItemData = [];

        foreach (['name', 'color_text'] as $field) {
            if (isset($fieldMappings[$field]) && $fieldMappings[$field] !== '') {
                $legendItemData[$field] = $fieldMappings[$field];
            }
        }

        if (!empty($fieldMappings['color'])) {
            $legendItemData['color'] = [trim($fieldMappings['color'])];
        }

        if (empty($legendItemData)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('No fields provided to update.', 'bit-pi'),
            ];
        }

        return $this->updateLegendItemRecord((int) $fieldMappings['legend_item_id'], $legendItemData, $fieldMappings);
    }

    public function deleteLegendItem()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'legend_item_id' => ['required', 'integer'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $legendItemId = (int) $fieldMappings['legend_item_id'];
        $legendItem = $this->findLegendItem($legendItemId, $fieldMappings);

        if (\is_array($legendItem)) {
            return $legendItem;
        }

        $legendItemData = WpSimpleBookingCalendarHelper::getLegendItemData($legendItem);

        if (!wpsbc_delete_legend_item($legendItemId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to delete legend item.', 'bit-pi'),
            ];
        }

        foreach (array_keys((array) wpsbc_get_legend_item_meta($legendItemId)) as $metaKey) {
            wpsbc_delete_legend_item_meta($legendItemId, $metaKey);
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => array_merge($legendItemData, ['deleted' => true]),
        ];
    }

    public function setDefaultLegendItem()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'legend_item_id' => ['required', 'integer'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $legendItemId = (int) $fieldMappings['legend_item_id'];
        $legendItem = $this->findLegendItem($legendItemId, $fieldMappings);

        if (\is_array($legendItem)) {
            return $legendItem;
        }

        $this->clearOtherDefaults((int) $legendItem->get('calendar_id'), $legendItemId);

        return $this->updateLegendItemRecord($legendItemId, ['is_default' => 1], $fieldMappings);
    }

    public function setLegendItemVisibility()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'legend_item_id' => ['required', 'integer'],
            'is_visible'     => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $legendItemId = (int) $fieldMappings['legend_item_id'];
        $legendItem = $this->findLegendItem($legendItemId, $fieldMappings);

        if (\is_array($legendItem)) {
            return $legendItem;
        }

        return $this->updateLegendItemRecord($legendItemId, ['is_visible' => (int) $fieldMappings['is_visible']], $fieldMappings);
    }

    public function getLegendItem()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'legend_item_id' => ['required', 'integer'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $legendItem = $this->findLegendItem($fieldMappings['legend_item_id'], $fieldMappings);

        if (\is_array($legendItem)) {
            return $legendItem;
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => WpSimpleBookingCalendarHelper::getLegendItemData($legendItem),
        ];
    }

    public function getLegendItems()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'calendar_id' => ['required', 'integer'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $calendar = $this->findCalendar($fieldMappings['calendar_id'], $fieldMappings);

        if (\is_array($calendar)) {
            return $calendar;
        }

        $args = ['calendar_id' => (int) $fieldMappings['calendar_id']];

        if (isset($fieldMappings['is_visible']) && $fieldMappings['is_visible'] !== '' && $fieldMappings['is_visible'] !== 'any') {
            $args['is_visible'] = (int) $fieldMappings['is_visible'];
        }

        $legendItems = [];

        foreach ((array) wpsbc_get_legend_items($args) as $legendItem) {
            $legendItems[] = WpSimpleBookingCalendarHelper::getLegendItemData($legendItem);
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => $legendItems,
        ];
    }

    private function clearOtherDefaults($calendarId, $keepLegendItemId)
    {
        foreach ((array) wpsbc_get_legend_items(['calendar_id' => $calendarId, 'is_default' => 1]) as $legendItem) {
            if ((int) $legendItem->get('id') !== (int) $keepLegendItemId) {
                wpsbc_update_legend_item($legendItem->get('id'), ['is_default' => 0]);
            }
        }
    }

    private function updateLegendItemRecord($legendItemId, $legendItemData, $fieldMappings)
    {
        if (!wpsbc_update_legend_item($legendItemId, $legendItemData)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to update legend item.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => WpSimpleBookingCalendarHelper::getLegendItemData($legendItemId),
        ];
    }
}
