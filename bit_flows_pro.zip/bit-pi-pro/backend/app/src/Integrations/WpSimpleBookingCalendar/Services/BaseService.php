<?php

namespace BitApps\PiPro\src\Integrations\WpSimpleBookingCalendar\Services;

use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\PiPro\src\Integrations\WpSimpleBookingCalendar\helper\WpSimpleBookingCalendarHelper;

if (!defined('ABSPATH')) {
    exit;
}

abstract class BaseService
{
    protected $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    protected function findCalendar($calendarId, $fieldMappings)
    {
        $calendar = wpsbc_get_calendar((int) $calendarId);

        if (!\is_object($calendar)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Calendar not found.', 'bit-pi'),
            ];
        }

        return $calendar;
    }

    protected function findEvent($eventId, $fieldMappings)
    {
        $event = wpsbc_get_event((int) $eventId);

        if (!\is_object($event)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Event not found.', 'bit-pi'),
            ];
        }

        return $event;
    }

    protected function findLegendItem($legendItemId, $fieldMappings)
    {
        $legendItem = wpsbc_get_legend_item((int) $legendItemId);

        if (!\is_object($legendItem)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Legend item not found.', 'bit-pi'),
            ];
        }

        return $legendItem;
    }

    protected function findEventByDate($calendarId, $date)
    {
        $events = wpsbc_get_events(
            [
                'calendar_id' => (int) $calendarId,
                'date_year'   => $date['year'],
                'date_month'  => $date['month'],
                'date_day'    => $date['day'],
                'number'      => 1,
            ]
        );

        return !empty($events) && \is_array($events) ? $events[0] : null;
    }

    protected function upsertEvent($calendarId, $legendItemId, $date, $description, $tooltip)
    {
        $eventData = [
            'legend_item_id' => (int) $legendItemId,
            'description'    => (string) $description,
            'tooltip'        => (string) $tooltip,
        ];

        $existingEvent = $this->findEventByDate($calendarId, $date);

        if (\is_object($existingEvent)) {
            $updated = wpsbc_update_event($existingEvent->get('id'), $eventData);

            return $updated ? (int) $existingEvent->get('id') : false;
        }

        $eventData['calendar_id'] = (int) $calendarId;
        $eventData['date_year'] = $date['year'];
        $eventData['date_month'] = $date['month'];
        $eventData['date_day'] = $date['day'];

        return wpsbc_insert_event($eventData);
    }

    protected function invalidDateResponse($fieldMappings, $fieldLabel)
    {
        return [
            'status_code' => 400,
            'payload'     => $fieldMappings,
            // translators: %s is the date field label.
            'response'    => \sprintf(__('%s is not a valid date. Use the YYYY-MM-DD format.', 'bit-pi'), $fieldLabel),
        ];
    }

    protected function parseDate($date)
    {
        return WpSimpleBookingCalendarHelper::parseDate($date);
    }
}
