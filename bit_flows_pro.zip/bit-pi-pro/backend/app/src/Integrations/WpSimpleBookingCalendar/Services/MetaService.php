<?php

namespace BitApps\PiPro\src\Integrations\WpSimpleBookingCalendar\Services;

use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\WpSimpleBookingCalendar\helper\WpSimpleBookingCalendarHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class MetaService extends BaseService
{
    public function updateCalendarMeta()
    {
        return $this->updateMeta('calendar_id', 'findCalendar', 'wpsbc_update_calendar_meta', 'wpsbc_get_calendar_meta');
    }

    public function getCalendarMeta()
    {
        return $this->getMeta('calendar_id', 'findCalendar', 'wpsbc_get_calendar_meta');
    }

    public function updateEventMeta()
    {
        return $this->updateMeta('event_id', 'findEvent', 'wpsbc_update_event_meta', 'wpsbc_get_event_meta');
    }

    public function getEventMeta()
    {
        return $this->getMeta('event_id', 'findEvent', 'wpsbc_get_event_meta');
    }

    public function updateLegendItemMeta()
    {
        return $this->updateMeta('legend_item_id', 'findLegendItem', 'wpsbc_update_legend_item_meta', 'wpsbc_get_legend_item_meta');
    }

    public function getLegendItemMeta()
    {
        return $this->getMeta('legend_item_id', 'findLegendItem', 'wpsbc_get_legend_item_meta');
    }

    private function updateMeta($idField, $finder, $updateFunction, $getFunction)
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            $idField   => ['required', 'integer'],
            'meta_key' => ['required', 'string'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $objectId = (int) $fieldMappings[$idField];
        $record = $this->{$finder}($objectId, $fieldMappings);

        if (\is_array($record)) {
            return $record;
        }

        $updateFunction($objectId, $fieldMappings['meta_key'], $fieldMappings['meta_value'] ?? '');

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                $idField   => $objectId,
                'meta_key' => $fieldMappings['meta_key'],
                'meta'     => WpSimpleBookingCalendarHelper::flattenMeta($getFunction($objectId)),
            ],
        ];
    }

    private function getMeta($idField, $finder, $getFunction)
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            $idField => ['required', 'integer'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $objectId = (int) $fieldMappings[$idField];
        $record = $this->{$finder}($objectId, $fieldMappings);

        if (\is_array($record)) {
            return $record;
        }

        $metaKey = $fieldMappings['meta_key'] ?? '';

        if ($metaKey !== '') {
            return [
                'status_code' => 200,
                'payload'     => $fieldMappings,
                'response'    => [
                    $idField     => $objectId,
                    'meta_key'   => $metaKey,
                    'meta_value' => maybe_unserialize($getFunction($objectId, $metaKey, true)),
                ],
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                $idField => $objectId,
                'meta'   => WpSimpleBookingCalendarHelper::flattenMeta($getFunction($objectId)),
            ],
        ];
    }
}
