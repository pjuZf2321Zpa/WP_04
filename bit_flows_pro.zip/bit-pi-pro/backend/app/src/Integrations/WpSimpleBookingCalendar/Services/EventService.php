<?php

namespace BitApps\PiPro\src\Integrations\WpSimpleBookingCalendar\Services;

use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\WpSimpleBookingCalendar\helper\WpSimpleBookingCalendarHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class EventService extends BaseService
{
    public function createEvent()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'calendar_id'    => ['required', 'integer'],
            'legend_item_id' => ['required', 'integer'],
            'date'           => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $error = $this->validateCalendarAndLegendItem($fieldMappings);

        if ($error) {
            return $error;
        }

        $date = $this->parseDate($fieldMappings['date']);

        if (!$date) {
            return $this->invalidDateResponse($fieldMappings, __('Date', 'bit-pi'));
        }

        $eventId = $this->upsertEvent(
            $fieldMappings['calendar_id'],
            $fieldMappings['legend_item_id'],
            $date,
            $fieldMappings['description'] ?? '',
            $fieldMappings['tooltip'] ?? ''
        );

        if (!$eventId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to create event.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => WpSimpleBookingCalendarHelper::getEventData($eventId),
        ];
    }

    public function bookDateRange()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'calendar_id'    => ['required', 'integer'],
            'legend_item_id' => ['required', 'integer'],
            'start_date'     => ['required'],
            'end_date'       => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $error = $this->validateCalendarAndLegendItem($fieldMappings);

        if ($error) {
            return $error;
        }

        $startDate = $this->parseDate($fieldMappings['start_date']);
        $endDate = $this->parseDate($fieldMappings['end_date']);

        if (!$startDate) {
            return $this->invalidDateResponse($fieldMappings, __('Start Date', 'bit-pi'));
        }

        if (!$endDate) {
            return $this->invalidDateResponse($fieldMappings, __('End Date', 'bit-pi'));
        }

        $current = date_create(WpSimpleBookingCalendarHelper::formatDate($startDate['year'], $startDate['month'], $startDate['day']), wp_timezone());
        $end = date_create(WpSimpleBookingCalendarHelper::formatDate($endDate['year'], $endDate['month'], $endDate['day']), wp_timezone());

        if ($current > $end) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Start Date must be before or equal to End Date.', 'bit-pi'),
            ];
        }

        $events = [];

        while ($current <= $end) {
            $date = [
                'year'  => (int) $current->format('Y'),
                'month' => (int) $current->format('n'),
                'day'   => (int) $current->format('j'),
            ];

            $eventId = $this->upsertEvent(
                $fieldMappings['calendar_id'],
                $fieldMappings['legend_item_id'],
                $date,
                $fieldMappings['description'] ?? '',
                $fieldMappings['tooltip'] ?? ''
            );

            if ($eventId) {
                $events[] = WpSimpleBookingCalendarHelper::getEventData($eventId);
            }

            $current->modify('+1 day');
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'calendar_id'  => (int) $fieldMappings['calendar_id'],
                'events_count' => \count($events),
                'events'       => $events,
            ],
        ];
    }

    public function updateEvent()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'event_id' => ['required', 'integer'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $event = $this->findEvent($fieldMappings['event_id'], $fieldMappings);

        if (\is_array($event)) {
            return $event;
        }

        $eventData = [];

        if (!empty($fieldMappings['legend_item_id'])) {
            $legendItem = $this->findLegendItem($fieldMappings['legend_item_id'], $fieldMappings);

            if (\is_array($legendItem)) {
                return $legendItem;
            }

            $eventData['legend_item_id'] = (int) $fieldMappings['legend_item_id'];
        }

        if (isset($fieldMappings['description'])) {
            $eventData['description'] = $fieldMappings['description'];
        }

        if (isset($fieldMappings['tooltip'])) {
            $eventData['tooltip'] = $fieldMappings['tooltip'];
        }

        if (empty($eventData)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('No fields provided to update.', 'bit-pi'),
            ];
        }

        if (!wpsbc_update_event((int) $fieldMappings['event_id'], $eventData)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to update event.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => WpSimpleBookingCalendarHelper::getEventData((int) $fieldMappings['event_id']),
        ];
    }

    public function deleteEvent()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'event_id' => ['required', 'integer'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $event = $this->findEvent($fieldMappings['event_id'], $fieldMappings);

        if (\is_array($event)) {
            return $event;
        }

        return $this->deleteEventRecord($event, $fieldMappings);
    }

    public function deleteEventByDate()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'calendar_id' => ['required', 'integer'],
            'date'        => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $calendar = $this->findCalendar($fieldMappings['calendar_id'], $fieldMappings);

        if (\is_array($calendar)) {
            return $calendar;
        }

        $date = $this->parseDate($fieldMappings['date']);

        if (!$date) {
            return $this->invalidDateResponse($fieldMappings, __('Date', 'bit-pi'));
        }

        $event = $this->findEventByDate($fieldMappings['calendar_id'], $date);

        if (!\is_object($event)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('No event found on the given date.', 'bit-pi'),
            ];
        }

        return $this->deleteEventRecord($event, $fieldMappings);
    }

    public function getEvent()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'event_id' => ['required', 'integer'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $event = $this->findEvent($fieldMappings['event_id'], $fieldMappings);

        if (\is_array($event)) {
            return $event;
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => WpSimpleBookingCalendarHelper::getEventData($event),
        ];
    }

    public function getEvents()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'calendar_id' => ['required', 'integer'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $calendar = $this->findCalendar($fieldMappings['calendar_id'], $fieldMappings);

        if (\is_array($calendar)) {
            return $calendar;
        }

        $args = [
            'calendar_id' => (int) $fieldMappings['calendar_id'],
            'orderby'     => 'id',
            'order'       => 'ASC',
        ];

        foreach (['date_year', 'date_month', 'date_day', 'legend_item_id'] as $filter) {
            if (!empty($fieldMappings[$filter])) {
                $args[$filter] = (int) $fieldMappings[$filter];
            }
        }

        $events = [];

        foreach ((array) wpsbc_get_events($args) as $event) {
            $events[] = WpSimpleBookingCalendarHelper::getEventData($event);
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => $events,
        ];
    }

    private function validateCalendarAndLegendItem($fieldMappings)
    {
        $calendar = $this->findCalendar($fieldMappings['calendar_id'], $fieldMappings);

        if (\is_array($calendar)) {
            return $calendar;
        }

        $legendItem = $this->findLegendItem($fieldMappings['legend_item_id'], $fieldMappings);

        if (\is_array($legendItem)) {
            return $legendItem;
        }

        if ((int) $legendItem->get('calendar_id') !== (int) $fieldMappings['calendar_id']) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Legend item does not belong to the selected calendar.', 'bit-pi'),
            ];
        }

        return null;
    }

    private function deleteEventRecord($event, $fieldMappings)
    {
        $eventId = (int) $event->get('id');
        $eventData = WpSimpleBookingCalendarHelper::getEventData($event);

        if (!wpsbc_delete_event($eventId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to delete event.', 'bit-pi'),
            ];
        }

        foreach (array_keys((array) wpsbc_get_event_meta($eventId)) as $metaKey) {
            wpsbc_delete_event_meta($eventId, $metaKey);
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => array_merge($eventData, ['deleted' => true]),
        ];
    }
}
