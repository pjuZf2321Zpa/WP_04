<?php

namespace BitApps\PiPro\src\Integrations\WpSimpleBookingCalendar;

use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\WpSimpleBookingCalendar\helper\WpSimpleBookingCalendarHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class WpSimpleBookingCalendarTrigger
{
    public static function calendarCreated($calendarId)
    {
        self::execute('calendarCreated', WpSimpleBookingCalendarHelper::getCalendarData($calendarId));
    }

    public static function calendarUpdated($calendarId)
    {
        self::execute('calendarUpdated', WpSimpleBookingCalendarHelper::getCalendarData($calendarId), $calendarId);
    }

    public static function calendarTrashed($calendarId, $data)
    {
        if (($data['status'] ?? '') !== 'trash') {
            return;
        }

        self::execute('calendarTrashed', WpSimpleBookingCalendarHelper::getCalendarData($calendarId), $calendarId);
    }

    public static function calendarRestored($calendarId, $data)
    {
        if (($data['status'] ?? '') !== 'active') {
            return;
        }

        self::execute('calendarRestored', WpSimpleBookingCalendarHelper::getCalendarData($calendarId), $calendarId);
    }

    public static function calendarDeleted($calendarId)
    {
        self::execute('calendarDeleted', WpSimpleBookingCalendarHelper::getCalendarData($calendarId), $calendarId);
    }

    public static function calendarDataSaved($postData)
    {
        $data = WpSimpleBookingCalendarHelper::getSavedCalendarData((array) $postData);

        self::execute('calendarDataSaved', $data, $data['calendar_id'] ?? null);
    }

    public static function eventCreated($eventId)
    {
        $eventData = WpSimpleBookingCalendarHelper::getEventData($eventId);

        self::execute('eventCreated', $eventData, $eventData['calendar_id'] ?? null);
    }

    public static function eventUpdated($eventId)
    {
        $eventData = WpSimpleBookingCalendarHelper::getEventData($eventId);

        self::execute('eventUpdated', $eventData, $eventData['calendar_id'] ?? null);
    }

    public static function eventDeleted($eventId)
    {
        $eventData = WpSimpleBookingCalendarHelper::getEventData($eventId);

        self::execute('eventDeleted', $eventData, $eventData['calendar_id'] ?? null);
    }

    public static function legendItemCreated($legendItemId)
    {
        $legendItemData = WpSimpleBookingCalendarHelper::getLegendItemData($legendItemId);

        self::execute('legendItemCreated', $legendItemData, $legendItemData['calendar_id'] ?? null);
    }

    public static function legendItemUpdated($legendItemId)
    {
        $legendItemData = WpSimpleBookingCalendarHelper::getLegendItemData($legendItemId);

        self::execute('legendItemUpdated', $legendItemData, $legendItemData['calendar_id'] ?? null);
    }

    public static function legendItemDeleted($legendItemId)
    {
        $legendItemData = WpSimpleBookingCalendarHelper::getLegendItemData($legendItemId);

        self::execute('legendItemDeleted', $legendItemData, $legendItemData['calendar_id'] ?? null);
    }

    private static function execute($machineSlug, $data, $calendarId = null)
    {
        if (!WpSimpleBookingCalendarHelper::isPluginInstalled()) {
            return;
        }

        $flows = FlowService::exists('wpSimpleBookingCalendar', $machineSlug);

        if (!$flows || empty($data)) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $data, $calendarId, 'calendar-id');
    }
}
