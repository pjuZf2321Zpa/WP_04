<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\PiPro\src\Integrations\WpSimpleBookingCalendar\helper\WpSimpleBookingCalendarHelper;

Route::group(
    function () {
        Route::get('wp-simple-booking-calendar/calendars', [WpSimpleBookingCalendarHelper::class, 'getCalendars']);
        Route::get('wp-simple-booking-calendar/legend-items', [WpSimpleBookingCalendarHelper::class, 'getLegendItems']);
        Route::get('wp-simple-booking-calendar/events', [WpSimpleBookingCalendarHelper::class, 'getEvents']);
    }
)->middleware('nonce:admin');
