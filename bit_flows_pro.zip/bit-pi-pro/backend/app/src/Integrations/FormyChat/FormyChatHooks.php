<?php

namespace BitApps\PiPro\src\Integrations\FormyChat;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!defined('ABSPATH')) {
    exit;
}

class FormyChatHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'leadCreated' => [
                'hook'          => 'formychat_lead_created',
                'callback'      => [FormyChatTrigger::class, 'handleLeadCreated'],
                'accepted_args' => 2,
            ],
            'formSubmitted' => [
                'hook'     => 'formychat_form_submitted',
                'callback' => [FormyChatTrigger::class, 'handleFormSubmitted'],
            ],
        ];
    }
}
