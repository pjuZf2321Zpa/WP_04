<?php

namespace BitApps\PiPro\src\Integrations\FormyChat;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;

if (!defined('ABSPATH')) {
    exit;
}

class FormyChatAction implements ActionInterface
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeFormyChatAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'] ?? 200,
            $executedNodeAction['payload'] ?? [],
            $executedNodeAction['response'] ?? []
        );
    }

    private function executeFormyChatAction()
    {
        if (!defined('FORMYCHAT_VERSION')) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('FormyChat plugin is not active.', 'bit-pi'),
            ];
        }

        $formyChatService = new FormyChatService($this->nodeInfoProvider);

        $machineSlug = $this->nodeInfoProvider->getMachineSlug();

        if (!method_exists($formyChatService, $machineSlug)) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('FormyChat action not found.', 'bit-pi'),
            ];
        }

        return $formyChatService->{$machineSlug}();
    }
}
