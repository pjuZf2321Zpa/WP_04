<?php

namespace BitApps\PiPro\src\Integrations\FormyChat;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;

if (!defined('ABSPATH')) {
    exit;
}

class FormyChatTrigger
{
    public static function handleLeadCreated($formData, $leadId)
    {
        self::execute('leadCreated', $formData, ['lead_id' => $leadId]);
    }

    public static function handleFormSubmitted($formData)
    {
        self::execute('formSubmitted', $formData);
    }

    private static function execute($machineSlug, $data, $additionalData = [])
    {
        $data = array_merge(
            $additionalData,
            (array) Utility::jsonEncodeDecode($data)
        );

        $flows = FlowService::exists('formyChat', $machineSlug);

        if (!$flows) {
            return;
        }

        $widgetId = $data['widget_id'] ?? null;

        IntegrationHelper::handleFlowForForm($flows, $data, $widgetId, 'widget-id');
    }
}
