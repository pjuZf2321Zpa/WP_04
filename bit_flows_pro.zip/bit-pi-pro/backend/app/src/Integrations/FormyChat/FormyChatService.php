<?php

namespace BitApps\PiPro\src\Integrations\FormyChat;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use FormyChat\Models\Lead;
use FormyChat\Models\Widget;

if (!defined('ABSPATH')) {
    exit;
}

final class FormyChatService
{
    private const DEFAULT_PER_PAGE = 20;

    private const DEFAULT_PAGE = 1;

    private NodeInfoProvider $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function createLead(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationError = FormyChatHelper::validateFieldMap($fieldMappings, ['widget_id' => ['required', 'integer']]);

        if ($validationError) {
            return $validationError;
        }

        $fieldData = $this->nodeInfoProvider->getFieldMapRepeaters('field.value', false, true, 'key', 'value');
        $metaData = $this->nodeInfoProvider->getFieldMapRepeaters('meta.value', false, true, 'key', 'value');

        $leadData = [
            'widget_id' => (int) $fieldMappings['widget_id'],
            'field'     => empty($fieldData) ? [] : $fieldData,
            'meta'      => empty($metaData) ? [] : $metaData,
            'note'      => $fieldMappings['note'] ?? '',
            'form'      => 'formychat',
        ];

        $leadModelError = $this->ensureModelExists(Lead::class, $leadData);

        if ($leadModelError) {
            return $leadModelError;
        }

        $leadId = Lead::create($leadData);

        if (empty($leadId)) {
            return [
                'response'    => __('Failed to create lead.', 'bit-pi'),
                'payload'     => $leadData,
                'status_code' => 400,
            ];
        }

        return [
            'response'    => Utility::jsonEncodeDecode(Lead::find($leadId)),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function getLead(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationError = FormyChatHelper::validateFieldMap($fieldMappings, ['lead_id' => ['required', 'integer']]);
        if ($validationError) {
            return $validationError;
        }

        $leadModelError = $this->ensureModelExists(Lead::class, $fieldMappings);
        if ($leadModelError) {
            return $leadModelError;
        }

        $lead = Lead::find((int) $fieldMappings['lead_id']);

        if (empty($lead)) {
            return [
                'response'    => __('Lead not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404,
            ];
        }

        return [
            'response'    => Utility::jsonEncodeDecode($lead),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function getLeads(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $leadModelError = $this->ensureModelExists(Lead::class, $fieldMappings);
        if ($leadModelError) {
            return $leadModelError;
        }

        return [
            'response'    => Utility::jsonEncodeDecode(Lead::get($this->buildLeadQueryArgs($fieldMappings)) ?? []),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function getWidget(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationError = FormyChatHelper::validateFieldMap($fieldMappings, ['widget_id' => ['required', 'integer']]);

        if ($validationError) {
            return $validationError;
        }

        $widgetModelError = $this->ensureModelExists(Widget::class, $fieldMappings);
        if ($widgetModelError) {
            return $widgetModelError;
        }

        $widget = Widget::find((int) $fieldMappings['widget_id']);

        if (empty($widget)) {
            return [
                'response'    => __('Widget not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404,
            ];
        }

        return [
            'response'    => Utility::jsonEncodeDecode($widget),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    private function ensureModelExists(string $modelClass, array $payload): ?array
    {
        if (!class_exists($modelClass)) {
            return [
                // translators: %s is the model class name.
                'response'    => \sprintf(__('%s Model not found.', 'bit-pi'), $modelClass),
                'payload'     => $payload,
                'status_code' => 400,
            ];
        }

        return null;
    }

    private function buildLeadQueryArgs(array $fieldMappings): array
    {
        $args = [
            'per_page' => self::DEFAULT_PER_PAGE,
            'page'     => self::DEFAULT_PAGE,
        ];

        if (!empty($fieldMappings['widget_id'])) {
            $args['widget_id'] = $fieldMappings['widget_id'];
        }

        if (!empty($fieldMappings['order'])) {
            $args['order'] = $fieldMappings['order'];
        }

        if (!empty($fieldMappings['per_page'])) {
            $args['per_page'] = $fieldMappings['per_page'];
        }

        if (!empty($fieldMappings['page'])) {
            $args['page'] = $fieldMappings['page'];
        }

        return $args;
    }
}
