<?php

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\PiPro\src\Integrations\FormyChat\FormyChatHelper;

if (!defined('ABSPATH')) {
    exit;
}

Route::group(
    function () {
        Route::post('formy-chat/get-widgets', [FormyChatHelper::class, 'getWidgets']);
        Route::post('formy-chat/get-widget-fields', [FormyChatHelper::class, 'getWidgetFields']);
    }
)->middleware('nonce', 'isAdmin');
