<?php

namespace BitApps\PiPro\src\Integrations\FormyChat;

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Request\Request;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\PiPro\Deps\BitApps\WPValidator\Validator;
use FormyChat\App;
use FormyChat\Models\Widget;

if (!defined('ABSPATH')) {
    exit;
}

final class FormyChatHelper
{
    private const DEFAULT_DROPDOWN_NAME = 'dropdown';

    private const DEFAULT_DROPDOWN_POSITION = 'before_message';

    private const DROPDOWN_POSITIONS = [
        'before_message' => ['field' => 'message', 'offset' => 0],
        'after_name'     => ['field' => 'name', 'offset' => 1],
        'after_email'    => ['field' => 'email', 'offset' => 1],
        'after_phone'    => ['field' => 'phone', 'offset' => 1],
    ];

    public function getWidgets(Request $request)
    {
        if (!class_exists(Widget::class)) {
            return Response::error(__('FormyChat is not installed or activated', 'bit-pi'));
        }

        $validated = $request->validate(['isTrigger' => ['required', 'boolean']]);
        $widgetOptions = !empty($validated['isTrigger']) ? [['label' => __('Any widget', 'bit-pi'), 'value' => 'any']] : [];

        $widgets = Widget::get_names();

        if (!\is_array($widgets) || empty($widgets)) {
            return Response::success($widgetOptions);
        }

        foreach ($widgets as $widget) {
            if (!\is_object($widget) || !isset($widget->id, $widget->name)) {
                continue;
            }

            $widgetOptions[] = [
                'label' => (string) $widget->name,
                'value' => (int) $widget->id,
            ];
        }

        return Response::success($widgetOptions);
    }

    public function getWidgetFields(Request $request)
    {
        if (!class_exists(Widget::class) || !class_exists(App::class)) {
            return Response::error(__('FormyChat is not installed or activated', 'bit-pi'));
        }

        $validated = $request->validate(['widgetId' => ['required', 'integer']]);
        $widgetId = (int) $validated['widgetId'];

        $widget = Widget::find($widgetId);

        if (!$widget) {
            return Response::error(__('Widget not found', 'bit-pi'));
        }

        $fields = App::form_fields();
        if (!\is_array($fields)) {
            $fields = [];
        }

        $dropdown = $this->getCustomDropdownConfig($widget);

        if ($this->hasCustomDropdown($dropdown)) {
            $fields = $this->insertDropdownField($fields, $dropdown);
        }

        return Response::success($this->buildFieldOptions($fields));
    }

    public static function validateFieldMap($fieldMappings, $validationRules, $payload = null)
    {
        $validator = new Validator();
        $validation = $validator->make($fieldMappings, $validationRules);

        if ($validation->fails()) {
            return [
                'response'    => $validation->errors(),
                'payload'     => $payload ?? $fieldMappings,
                'status_code' => 400
            ];
        }
    }

    private function getCustomDropdownConfig($widget): array
    {
        if (!isset($widget->config['form']) || !\is_array($widget->config['form'])) {
            return [];
        }

        if (!isset($widget->config['form']['custom_dropdown']) || !\is_array($widget->config['form']['custom_dropdown'])) {
            return [];
        }

        return $widget->config['form']['custom_dropdown'];
    }

    private function hasCustomDropdown(array $dropdown): bool
    {
        return !empty($dropdown['enabled']) && !empty($dropdown['options']) && \is_array($dropdown['options']);
    }

    private function insertDropdownField(array $fields, array $dropdown): array
    {
        $dropdownField = [
            'name'  => !empty($dropdown['name']) ? $dropdown['name'] : self::DEFAULT_DROPDOWN_NAME,
            'label' => !empty($dropdown['label']) ? $dropdown['label'] : '',
        ];

        $insertIndex = $this->resolveDropdownInsertIndex(
            $fields,
            isset($dropdown['position']) ? (string) $dropdown['position'] : self::DEFAULT_DROPDOWN_POSITION
        );

        array_splice($fields, $insertIndex, 0, [$dropdownField]);

        return $fields;
    }

    private function resolveDropdownInsertIndex(array $fields, string $position): int
    {
        $positionConfig = self::DROPDOWN_POSITIONS[$position] ?? self::DROPDOWN_POSITIONS[self::DEFAULT_DROPDOWN_POSITION];
        $targetIndex = $this->findFieldIndexByName($fields, $positionConfig['field']);

        if ($targetIndex === null) {
            return \count($fields);
        }

        return $targetIndex + $positionConfig['offset'];
    }

    private function findFieldIndexByName(array $fields, string $fieldName): ?int
    {
        foreach ($fields as $index => $field) {
            if (!\is_array($field) || empty($field['name'])) {
                continue;
            }

            if ((string) $field['name'] === $fieldName) {
                return $index;
            }
        }

        return null;
    }

    private function buildFieldOptions(array $fields): array
    {
        $options = [];

        foreach ($fields as $field) {
            if (!\is_array($field) || empty($field['name'])) {
                continue;
            }

            $name = (string) $field['name'];
            $options[] = [
                'label' => !empty($field['label']) ? (string) $field['label'] : $name,
                'value' => $name,
            ];
        }

        return $options;
    }
}
