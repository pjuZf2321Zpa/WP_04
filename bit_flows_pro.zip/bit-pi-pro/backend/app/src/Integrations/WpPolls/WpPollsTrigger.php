<?php

namespace BitApps\PiPro\src\Integrations\WpPolls;

use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;

if (!\defined('ABSPATH')) {
    exit;
}

final class WpPollsTrigger
{
    /**
     * Handle poll submission trigger.
     */
    public static function pollSubmitted()
    {
        $pollId = self::getPollIdFromRequest();
        if (!$pollId) {
            return;
        }

        $rawAnswerIds = $_POST['poll_' . $pollId] ?? null;
        if (!$rawAnswerIds) {
            return;
        }

        if (!self::verifyNonce($pollId)) {
            return;
        }

        $flows = FlowService::exists('wpPolls', 'pollSubmitted');
        if (!$flows) {
            return;
        }

        $selectedAnswerIds = self::sanitizeAnswerIds($rawAnswerIds);
        $data = self::getPollData($selectedAnswerIds, $pollId);

        IntegrationHelper::handleFlowForForm($flows, $data);
    }

    /**
     * Get poll ID from POST request.
     *
     * @return null|int
     */
    private static function getPollIdFromRequest()
    {
        $pollId = $_POST['poll_id'] ?? null;

        if (empty($pollId)) {
            return;
        }

        return absint($pollId);
    }

    /**
     * Verify nonce for security.
     *
     * @param int $pollId Poll ID
     *
     * @return bool
     */
    private static function verifyNonce($pollId)
    {
        return check_ajax_referer(
            'poll_' . $pollId . '-nonce',
            'poll_' . $pollId . '_nonce',
            false
        );
    }

    /**
     * Sanitize answer IDs (array or single value).
     *
     * @param mixed $rawAnswerIds Raw answer IDs
     *
     * @return string
     */
    private static function sanitizeAnswerIds($rawAnswerIds)
    {
        if (\is_array($rawAnswerIds)) {
            return self::sanitizeAnswerIdsArray($rawAnswerIds);
        }

        return self::sanitizeSingleAnswerId($rawAnswerIds);
    }

    /**
     * Sanitize array of answer IDs.
     *
     * @param array $rawAnswerIds Raw answer IDs array
     *
     * @return string
     */
    private static function sanitizeAnswerIdsArray($rawAnswerIds)
    {
        $sanitizedAnswerIds = array_map('intval', $rawAnswerIds);
        $filteredAnswerIds = array_filter($sanitizedAnswerIds);

        return implode(',', $filteredAnswerIds);
    }

    /**
     * Sanitize single answer ID.
     *
     * @param mixed $rawAnswerId Raw answer ID
     *
     * @return string
     */
    private static function sanitizeSingleAnswerId($rawAnswerId)
    {
        return (string) (int) $rawAnswerId;
    }

    /**
     * Get poll data from database.
     *
     * @param string $selectedAnswerIds Selected answer IDs
     * @param int    $pollId            Poll ID
     *
     * @return array
     */
    private static function getPollData($selectedAnswerIds, $pollId)
    {
        global $wpdb;

        $query = self::buildPollQuery($wpdb, $selectedAnswerIds, $pollId);
        $pollData = $wpdb->get_row($query, ARRAY_A);

        if (empty($pollData)) {
            return self::getDefaultPollData($pollId);
        }

        return self::formatPollData($pollData);
    }

    /**
     * Build SQL query for fetching poll data.
     *
     * @param object $wpdb              WordPress database object
     * @param string $selectedAnswerIds Selected answer IDs
     * @param int    $pollId            Poll ID
     *
     * @return string
     */
    private static function buildPollQuery($wpdb, $selectedAnswerIds, $pollId)
    {
        $pollsqTable = $wpdb->prefix . 'pollsq';
        $pollsaTable = $wpdb->prefix . 'pollsa';

        return $wpdb->prepare(
            "SELECT
                question.pollq_id AS poll_id,
                question.pollq_question AS question,
                question.pollq_timestamp AS start_date,
                question.pollq_expiry AS end_date,
                GROUP_CONCAT(DISTINCT answer.polla_answers ORDER BY answer.polla_aid SEPARATOR ', ') AS answers,
                GROUP_CONCAT(DISTINCT CASE WHEN FIND_IN_SET(answer.polla_aid, %s) THEN answer.polla_answers END ORDER BY answer.polla_aid SEPARATOR ', ') AS selected_answers
            FROM {$pollsqTable} AS question
            LEFT JOIN {$pollsaTable} AS answer ON question.pollq_id = answer.polla_qid
            WHERE question.pollq_id = %d
            GROUP BY question.pollq_id, question.pollq_question, question.pollq_timestamp, question.pollq_expiry
            LIMIT 1",
            $selectedAnswerIds,
            $pollId
        );
    }

    /**
     * Get default poll data when query returns empty.
     *
     * @param int $pollId Poll ID
     *
     * @return array
     */
    private static function getDefaultPollData($pollId)
    {
        return ['poll_id' => $pollId];
    }

    /**
     * Format poll data with proper date formatting.
     *
     * @param array $pollData Raw poll data
     *
     * @return array
     */
    private static function formatPollData($pollData)
    {
        $pollData['start_date'] = self::formatStartDate($pollData['start_date']);
        $pollData['end_date'] = self::formatEndDate($pollData['end_date']);

        return $pollData;
    }

    /**
     * Format start date timestamp.
     *
     * @param mixed $timestamp Start date timestamp
     *
     * @return string
     */
    private static function formatStartDate($timestamp)
    {
        return !empty($timestamp) ? gmdate('Y-m-d H:i:s', $timestamp) : '';
    }

    /**
     * Format end date timestamp.
     *
     * @param mixed $timestamp End date timestamp
     *
     * @return string
     */
    private static function formatEndDate($timestamp)
    {
        if (empty($timestamp) || $timestamp <= 0) {
            return 'Not set';
        }

        return gmdate('Y-m-d H:i:s', $timestamp);
    }
}
