<?php

namespace BitApps\PiPro\src\Integrations\WpPolls;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!\defined('ABSPATH')) {
    exit;
}

class WpPollsHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'pollSubmitted' => [
                'hook'     => 'wp_polls_vote_poll_success',
                'callback' => [WpPollsTrigger::class, 'pollSubmitted'],
            ]
        ];
    }
}
