<?php

namespace BitApps\PiPro\src\Integrations\WpSimplePay;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\Services\FlowService;
use BitApps\PiPro\src\Integrations\IntegrationHelper;

if (!\defined('ABSPATH')) {
    exit;
}

class WpSimplePayTrigger
{
    public static function paymentCompleted($type, $object)
    {
        self::execute(__FUNCTION__, $type, $object);
    }

    public static function subscriptionCreated($type, $object)
    {
        self::execute(__FUNCTION__, $type, $object);
    }

    public static function subscriptionRenewed($type, $object)
    {
        self::execute(__FUNCTION__, $type, $object);
    }

    private static function execute($machineSlug, $type, $object)
    {
        $data = [
            'type' => $type,
            'data' => Utility::jsonEncodeDecode($object),
        ];

        $flows = FlowService::exists('wpSimplePay', $machineSlug);
        if (!$flows) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $data);
    }
}
