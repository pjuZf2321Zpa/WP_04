<?php

namespace BitApps\PiPro\src\Integrations\WpSimplePay;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!\defined('ABSPATH')) {
    exit;
}

class WpSimplePayHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'paymentCompleted' => [
                'hook'          => 'simpay_webhook_payment_intent_succeeded',
                'callback'      => [WpSimplePayTrigger::class, 'paymentCompleted'],
                'priority'      => 20,
                'accepted_args' => 2,
            ],
            'subscriptionCreated' => [
                'hook'          => 'simpay_webhook_subscription_created',
                'callback'      => [WpSimplePayTrigger::class, 'subscriptionCreated'],
                'priority'      => 20,
                'accepted_args' => 2,
            ],
            'subscriptionRenewed' => [
                'hook'          => 'simpay_webhook_invoice_payment_succeeded',
                'callback'      => [WpSimplePayTrigger::class, 'subscriptionRenewed'],
                'priority'      => 20,
                'accepted_args' => 2,
            ],
        ];
    }
}
