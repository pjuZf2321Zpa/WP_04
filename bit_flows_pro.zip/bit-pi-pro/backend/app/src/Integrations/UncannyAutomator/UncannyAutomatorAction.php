<?php

namespace BitApps\PiPro\src\Integrations\UncannyAutomator;

// Prevent direct script access
if (!\defined('ABSPATH')) {
    exit;
}


use BitApps\Pi\src\Integrations\ApiRequest\ApiRequestAction;

class UncannyAutomatorAction extends ApiRequestAction
{
    // extends ApiRequestAction
}
