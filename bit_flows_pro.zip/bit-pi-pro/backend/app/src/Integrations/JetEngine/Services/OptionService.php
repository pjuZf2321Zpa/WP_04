<?php

namespace BitApps\PiPro\src\Integrations\JetEngine\Services;

use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\PiPro\src\Integrations\JetEngine\JetEngineHelper;

if (!\defined('ABSPATH')) {
    exit;
}

/**
 * OptionService Class.
 *
 * Handles JetEngine Option Pages operations including
 * fetching, updating fields, and retrieving field values.
 */
final class OptionService
{
    private NodeInfoProvider $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    /**
     * Retrieve all option pages.
     *
     * @return array<string, mixed> Response array with option pages
     */
    public function getAllOptionPages(): array
    {
        return [
            'response'    => JetEngineHelper::fetchOptionPages(),
            'payload'     => [],
            'status_code' => 200,
        ];
    }

    /**
     * Retrieve specific option page by slug.
     *
     * @return array<string, mixed> Response array with option page data
     */
    public function getOptionPageBySlug(): array
    {
        $fieldMappings = $this->getFieldMappings();

        $validationError = $this->validateSlugField($fieldMappings);
        if ($validationError) {
            return $validationError;
        }

        $optionPage = JetEngineHelper::fetchOptionPages($fieldMappings['slug']);

        if (empty($optionPage)) {
            return [
                'response'    => __('Option page not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404,
            ];
        }

        return [
            'response'    => $optionPage,
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Update option page field value.
     *
     * @return array<string, mixed> Response array with updated option page data
     */
    public function updateOptionPageField(): array
    {
        $fieldMappings = $this->getFieldMappings();

        $validationError = $this->validateUpdateFieldRequest($fieldMappings);
        if ($validationError) {
            return $validationError;
        }

        $this->saveOptionFieldValue(
            $fieldMappings['option_page'],
            $fieldMappings['field_name'],
            $fieldMappings['field_value']
        );

        return [
            'response'    => JetEngineHelper::fetchOptionPages($fieldMappings['option_page']),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Retrieve option field value(s) from option page.
     *
     * @return array<string, mixed> Response array with field value(s)
     */
    public function getOptionFieldValue(): array
    {
        $fieldMappings = $this->getFieldMappings();

        $validationError = $this->validateOptionPageField($fieldMappings);
        if ($validationError) {
            return $validationError;
        }

        $optionPage = $fieldMappings['option_page'];
        $fieldName = $fieldMappings['field_name'] ?? '';
        $pageOptions = $this->fetchOptionPageData($optionPage);

        // If specific field names requested, extract only those
        if (!empty($fieldName)) {
            $result = $this->extractSpecificFieldValues($pageOptions, $fieldName);

            return [
                'response'    => $result,
                'payload'     => $fieldMappings,
                'status_code' => 200,
            ];
        }

        return [
            'response'    => $pageOptions,
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Extract field mappings from node provider.
     *
     * @return array<string, mixed> Field mappings
     */
    private function getFieldMappings(): array
    {
        return $this->nodeInfoProvider->getFieldMapData();
    }

    /**
     * Validate slug field requirement.
     *
     * @param array<string, mixed> $fieldMappings Field data to validate
     *
     * @return null|array<string, mixed> Error response or null if valid
     */
    private function validateSlugField(array $fieldMappings): ?array
    {
        return JetEngineHelper::validateFieldMap(
            $fieldMappings,
            ['slug' => ['required', 'string']]
        );
    }

    /**
     * Validate update field request requirements.
     *
     * @param array<string, mixed> $fieldMappings Field data to validate
     *
     * @return null|array<string, mixed> Error response or null if valid
     */
    private function validateUpdateFieldRequest(array $fieldMappings): ?array
    {
        return JetEngineHelper::validateFieldMap(
            $fieldMappings,
            [
                'option_page' => ['required', 'string'],
                'field_name'  => ['required', 'string'],
                'field_value' => ['required'],
            ]
        );
    }

    /**
     * Validate option_page field requirement.
     *
     * @param array<string, mixed> $fieldMappings Field data to validate
     *
     * @return null|array<string, mixed> Error response or null if valid
     */
    private function validateOptionPageField(array $fieldMappings): ?array
    {
        return JetEngineHelper::validateFieldMap(
            $fieldMappings,
            ['option_page' => ['required', 'string']]
        );
    }

    /**
     * Save field value to option page.
     *
     * @param string $optionPage Option page slug
     * @param string $fieldName  Field name to update
     * @param mixed  $fieldValue New field value
     */
    private function saveOptionFieldValue(string $optionPage, string $fieldName, $fieldValue): void
    {
        $pageOptions = get_option($optionPage, []);
        $pageOptions[$fieldName] = $fieldValue;
        update_option($optionPage, $pageOptions);
    }

    /**
     * Fetch option page data from WordPress options.
     *
     * @param string $optionPage Option page slug
     *
     * @return array<string, mixed> Option page data
     */
    private function fetchOptionPageData(string $optionPage): array
    {
        return get_option($optionPage, []);
    }

    /**
     * Extract specific field values from page options.
     *
     * @param array<string, mixed> $pageOptions All page options
     * @param string               $fieldNames  Comma-separated field names
     *
     * @return array<string, mixed> Filtered field values
     */
    private function extractSpecificFieldValues(array $pageOptions, string $fieldNames): array
    {
        $requestedFields = array_map('trim', explode(',', $fieldNames));
        $result = [];

        foreach ($requestedFields as $fieldName) {
            if (isset($pageOptions[$fieldName])) {
                $result[$fieldName] = $pageOptions[$fieldName];
            }
        }

        return $result;
    }
}
