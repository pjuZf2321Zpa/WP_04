<?php

namespace BitApps\PiPro\src\Integrations\JetEngine\Services;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\PiPro\src\Integrations\JetEngine\JetEngineHelper;

if (!\defined('ABSPATH')) {
    exit;
}

/**
 * CptService Class.
 *
 * Handles all JetEngine post-related operations including create, update,
 * meta field management, and repeater field operations.
 */
final class CptService
{
    private NodeInfoProvider $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    /**
     * Create a new post with meta fields.
     *
     * @return array<string, mixed> Response array with status, payload, and response data
     */
    public function createPost(): array
    {
        $fieldMappings = $this->getFieldMappings();
        $metaFields = $this->extractMetaFields();

        $validationError = $this->validateCreatePostRequest($fieldMappings);
        if ($validationError) {
            return $validationError;
        }

        $postData = $this->buildPostData($fieldMappings);
        $postId = wp_insert_post($postData, true);

        if (is_wp_error($postId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => $postId->get_error_message(),
            ];
        }

        $this->saveMetaFields($postId, $metaFields);

        return [
            'response'    => $this->fetchPostWithMetadata($postId),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Update an existing post and its meta fields.
     *
     * @return array<string, mixed> Response array with status, payload, and response data
     */
    public function updatePost(): array
    {
        $fieldMappings = $this->getFieldMappings();
        $metaFields = $this->extractMetaFields();

        $validationError = $this->validateUpdatePostRequest($fieldMappings);
        if ($validationError) {
            return $validationError;
        }

        $postId = (int) $fieldMappings['post_id'];
        $updateData = $this->buildPostUpdateData($fieldMappings, $postId);

        if (empty($updateData)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('No fields to update.', 'bit-pi'),
            ];
        }

        $result = wp_update_post($updateData, true);
        if (is_wp_error($result)) {
            return [
                'status_code' => 400,
                'payload'     => $updateData,
                'response'    => $result->get_error_message(),
            ];
        }

        $this->saveMetaFields($postId, $metaFields);

        return [
            'response'    => $this->fetchPostWithMetadata($postId),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Update post meta fields only.
     *
     * @return array<string, mixed> Response array with status, payload, and response data
     */
    public function updatePostMeta(): array
    {
        $fieldMappings = $this->getFieldMappings();
        $metaFields = $this->extractMetaFields();

        $validationError = $this->validatePostMetaUpdateRequest($fieldMappings, $metaFields);
        if ($validationError) {
            return $validationError;
        }

        $postId = (int) $fieldMappings['post_id'];
        $this->saveMetaFields($postId, $metaFields);

        return [
            'response'    => $this->fetchPostWithMetadata($postId),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Update a specific post meta field by name.
     *
     * @return array<string, mixed> Response array with status, payload, and response data
     */
    public function updateFieldById(): array
    {
        $fieldMappings = $this->getFieldMappings();

        $validationError = $this->validateSingleFieldUpdate($fieldMappings);
        if ($validationError) {
            return $validationError;
        }

        $postId = (int) $fieldMappings['post_id'];

        if (!get_post($postId)) {
            return [
                'response'    => __('Post not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404,
            ];
        }

        $result = update_post_meta(
            $postId,
            $fieldMappings['field_name'],
            $fieldMappings['field_value']
        );

        if (!$result) {
            return [
                'response'    => __('Failed to update the field.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 500,
            ];
        }

        return [
            'response'    => $this->fetchPostWithMetadata($postId),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Add repeater items to custom post type fields.
     *
     * @return array<string, mixed> Response array with status, payload, and response data
     */
    public function addRepeaterItemToCustomPostType(): array
    {
        $fieldMappings = $this->getFieldMappings();
        $repeaterFields = $this->extractRepeaterFields();

        $validationError = $this->validateRepeaterFieldsRequest($fieldMappings, $repeaterFields);
        if ($validationError) {
            return $validationError;
        }

        $postId = (int) $fieldMappings['post_id'];
        $groupedData = $this->organizeRepeaterFieldsByName($repeaterFields);
        $this->appendRepeaterItemsToPost($postId, $groupedData);

        return [
            'response'    => $this->fetchPostWithMetadata($postId),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Retrieve post data by ID.
     *
     * @return array<string, mixed> Response array with post data
     */
    public function getPostById(): array
    {
        $fieldMappings = $this->getFieldMappings();

        $validationError = $this->validateFieldMappings(
            $fieldMappings,
            ['post_id' => ['required', 'integer']]
        );

        if ($validationError) {
            return $validationError;
        }

        $postData = $this->fetchPostWithMetadata((int) $fieldMappings['post_id']);

        if (!$postData) {
            return [
                'response'    => __('Post not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404,
            ];
        }

        return [
            'response'    => $postData,
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Retrieve posts by post type.
     *
     * @return array<string, mixed> Response array with posts
     */
    public function getPostsByPostType(): array
    {
        $fieldMappings = $this->getFieldMappings();
        $validationError = $this->validateFieldMappings(
            $fieldMappings,
            ['post_type' => ['required', 'string']]
        );

        if ($validationError) {
            return $validationError;
        }

        return [
            'response'    => JetEngineHelper::fetchPostsByType($fieldMappings['post_type']),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Retrieve all public post types.
     *
     * @return array<string, mixed> Response array with post types
     */
    public function getAllPostTypes(): array
    {
        $postTypeArgs = [
            'public'          => true,
            'capability_type' => 'post',
        ];

        return [
            'response'    => get_post_types($postTypeArgs, 'object'),
            'payload'     => [],
            'status_code' => 200,
        ];
    }

    /**
     * Extract field mappings from node provider.
     *
     * @return array<string, mixed> Field mappings
     */
    private function getFieldMappings(): array
    {
        return $this->nodeInfoProvider->getFieldMapData();
    }

    /**
     * Extract meta fields from repeater configuration.
     *
     * @return array<string, mixed> Meta fields
     */
    private function extractMetaFields(): array
    {
        return $this->nodeInfoProvider->getFieldMapRepeaters(
            'meta-fields.value',
            false,
            true,
            'metaKey',
            'metaValue'
        );
    }

    /**
     * Extract repeater fields from configuration.
     *
     * @return array<int, array<string, mixed>> Repeater fields
     */
    private function extractRepeaterFields(): array
    {
        return $this->nodeInfoProvider->getFieldMapRepeaters('repeater-fields.value', false, false);
    }

    /**
     * Validate field mappings against specified rules.
     *
     * @param array<string, mixed> $fieldMappings Field data to validate
     * @param array<string, array> $rules         Validation rules
     *
     * @return null|array<string, mixed> Error response or null if valid
     */
    private function validateFieldMappings(array $fieldMappings, array $rules): ?array
    {
        return JetEngineHelper::validateFieldMap($fieldMappings, $rules);
    }

    /**
     * Validate create post request data.
     *
     * @param array<string, mixed> $fieldMappings Field data to validate
     *
     * @return null|array<string, mixed> Error response or null if valid
     */
    private function validateCreatePostRequest(array $fieldMappings): ?array
    {
        return $this->validateFieldMappings(
            $fieldMappings,
            [
                'post_type'  => ['required', 'string'],
                'post_title' => ['required', 'string'],
            ]
        );
    }

    /**
     * Validate update post request data.
     *
     * @param array<string, mixed> $fieldMappings Field data to validate
     *
     * @return null|array<string, mixed> Error response or null if valid
     */
    private function validateUpdatePostRequest(array $fieldMappings): ?array
    {
        $validationError = $this->validateFieldMappings(
            $fieldMappings,
            [
                'post_type' => ['required', 'string'],
                'post_id'   => ['required', 'integer'],
            ]
        );

        if ($validationError) {
            return $validationError;
        }

        return $this->ensurePostExists(
            (int) $fieldMappings['post_id'],
            $fieldMappings['post_type'],
            $fieldMappings
        );
    }

    /**
     * Validate post with meta fields request.
     *
     * @param array<string, mixed>        $fieldMappings Field data
     * @param array<string, mixed>|string $metaFields    Meta fields data
     *
     * @return null|array<string, mixed> Error response or null if valid
     */
    private function validatePostMetaUpdateRequest(array $fieldMappings, $metaFields): ?array
    {
        $validationError = $this->validateUpdatePostRequest($fieldMappings);
        if ($validationError) {
            return $validationError;
        }

        if (empty($metaFields) || !\is_array($metaFields)) {
            return [
                'response'    => __('Meta fields are required.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        return null;
    }

    /**
     * Validate single field update request.
     *
     * @param array<string, mixed> $fieldMappings Field data to validate
     *
     * @return null|array<string, mixed> Error response or null if valid
     */
    private function validateSingleFieldUpdate(array $fieldMappings): ?array
    {
        return $this->validateFieldMappings(
            $fieldMappings,
            [
                'post_id'     => ['required', 'integer'],
                'field_name'  => ['required', 'string'],
                'field_value' => ['required'],
            ]
        );
    }

    /**
     * Validate repeater fields request.
     *
     * @param array<string, mixed>         $fieldMappings    Field data
     * @param array<int, array>|mixed      $repeaterFields   Repeater fields data
     *
     * @return null|array<string, mixed> Error response or null if valid
     */
    private function validateRepeaterFieldsRequest(array $fieldMappings, $repeaterFields): ?array
    {
        $validationError = $this->validateUpdatePostRequest($fieldMappings);
        if ($validationError) {
            return $validationError;
        }

        if (empty($repeaterFields) || !\is_array($repeaterFields)) {
            return [
                'response'    => __('Repeater fields are required.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        return null;
    }

    /**
     * Ensure post exists and matches expected type.
     *
     * @param int                  $postId           Post ID to verify
     * @param string               $expectedPostType Expected post type
     * @param array<string, mixed> $fieldMappings    Field mappings for error response
     *
     * @return null|array<string, mixed> Error response or null if valid
     */
    private function ensurePostExists(int $postId, string $expectedPostType, array $fieldMappings): ?array
    {
        $post = get_post($postId);

        if (!$post) {
            return [
                'response'    => __('Post not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404,
            ];
        }

        if ($post->post_type !== $expectedPostType) {
            return [
                'response'    => __('Post type mismatch.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        return null;
    }

    /**
     * Build post data for creation with defaults.
     *
     * @param array<string, mixed> $fieldMappings Input field mappings
     *
     * @return array<string, mixed> Prepared post data
     */
    private function buildPostData(array $fieldMappings): array
    {
        if (empty($fieldMappings['post_author'])) {
            $fieldMappings['post_author'] = get_current_user_id();
        }

        return $fieldMappings;
    }

    /**
     * Build update data excluding empty and system fields.
     *
     * @param array<string, mixed> $fieldMappings Input field mappings
     * @param int                  $postId         Post ID to update
     *
     * @return array<string, mixed> Filtered update data
     */
    private function buildPostUpdateData(array $fieldMappings, int $postId): array
    {
        $updateData = [];

        foreach ($fieldMappings as $key => $value) {
            if ($key !== 'post_id' && $value !== null && $value !== '') {
                $updateData[$key] = $value;
            }
        }

        if (!empty($updateData)) {
            $updateData['ID'] = $postId;
        }

        return $updateData;
    }

    /**
     * Organize repeater fields by repeater name into grouped structure.
     *
     * @param array<int, array<string, mixed>> $repeaterFields Raw repeater field data
     *
     * @return array<string, array<int, array<string, mixed>>> Grouped repeater data
     */
    private function organizeRepeaterFieldsByName(array $repeaterFields): array
    {
        $groupedData = [];
        $rowIndexes = [];

        foreach ($repeaterFields as $mapping) {
            $this->addFieldToRepeaterGroup(
                $groupedData,
                $rowIndexes,
                $mapping['repeaterName'],
                $mapping['itemName'],
                $mapping['itemValue']
            );
        }

        return $groupedData;
    }

    /**
     * Add a field value to the appropriate repeater group and row.
     *
     * @param array<string, array>  $groupedData  Reference to grouped data array
     * @param array<string, int>    $rowIndexes   Reference to row index tracker
     * @param string                $repeaterName Name of the repeater field
     * @param string                $fieldName    Name of the individual field
     * @param mixed                 $fieldValue   Value to set
     */
    private function addFieldToRepeaterGroup(
        array &$groupedData,
        array &$rowIndexes,
        string $repeaterName,
        string $fieldName,
        $fieldValue
    ): void {
        if (!isset($groupedData[$repeaterName])) {
            $groupedData[$repeaterName] = [];
            $rowIndexes[$repeaterName] = 0;
        }

        $currentIndex = $rowIndexes[$repeaterName];

        // Start new row if field already exists in current row
        if (isset($groupedData[$repeaterName][$currentIndex][$fieldName])) {
            ++$rowIndexes[$repeaterName];
            $currentIndex = $rowIndexes[$repeaterName];
        }

        $groupedData[$repeaterName][$currentIndex][$fieldName] = $fieldValue;
    }

    /**
     * Append new repeater items to existing post meta.
     *
     * @param int                                           $postId      Post ID
     * @param array<string, array<int, array<string, mixed>>> $groupedData Organized repeater data
     */
    private function appendRepeaterItemsToPost(int $postId, array $groupedData): void
    {
        foreach ($groupedData as $repeaterName => $newItems) {
            $existingItems = $this->fetchExistingRepeaterItems($postId, $repeaterName);
            $mergedItems = $this->mergeRepeaterItemArrays($existingItems, $newItems);
            update_post_meta($postId, $repeaterName, $mergedItems);
        }
    }

    /**
     * Fetch existing repeater items from post meta.
     *
     * @param int    $postId       Post ID
     * @param string $repeaterName Repeater field name
     *
     * @return array<int|string, mixed> Existing repeater items
     */
    private function fetchExistingRepeaterItems(int $postId, string $repeaterName): array
    {
        $existingData = get_post_meta($postId, $repeaterName, true);
        $existingData = maybe_unserialize($existingData);

        return \is_array($existingData) ? $existingData : [];
    }

    /**
     * Merge new items into existing repeater array.
     *
     * @param array<int|string, array<string, mixed>> $existingItems Current repeater items
     * @param array<int, array<string, mixed>>        $newItems      New items to add
     *
     * @return array<int|string, array<string, mixed>> Merged repeater items
     */
    private function mergeRepeaterItemArrays(array $existingItems, array $newItems): array
    {
        $nextIndex = \count($existingItems);

        foreach ($newItems as $newItem) {
            $existingItems['item-' . $nextIndex] = $newItem;
            ++$nextIndex;
        }

        return $existingItems;
    }

    /**
     * Save meta fields to a post, serializing complex values.
     *
     * @param int                  $postId     Post ID
     * @param array<string, mixed> $metaFields Meta fields to save
     */
    private function saveMetaFields(int $postId, array $metaFields): void
    {
        foreach ($metaFields as $metaKey => $metaValue) {
            if (\is_array($metaValue) || \is_object($metaValue)) {
                $metaValue = maybe_serialize($metaValue);
            }

            update_post_meta($postId, $metaKey, $metaValue);
        }
    }

    /**
     * Fetch post data with all metadata.
     *
     * @param int $postId Post ID to retrieve
     *
     * @return null|array<string, mixed> Post data with metadata or null if not found
     */
    private function fetchPostWithMetadata(int $postId): ?array
    {
        $post = get_post($postId);

        if (!$post) {
            return null;
        }

        $postData = (array) $post;
        $postData['meta_fields'] = Utility::getPostMetadata($postId);

        return $postData;
    }
}
