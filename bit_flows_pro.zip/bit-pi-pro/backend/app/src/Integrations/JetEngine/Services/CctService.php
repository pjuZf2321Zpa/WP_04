<?php

namespace BitApps\PiPro\src\Integrations\JetEngine\Services;

use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\PiPro\src\Integrations\JetEngine\JetEngineHelper;

if (!\defined('ABSPATH')) {
    exit;
}

/**
 * CctService Class.
 *
 * Handles JetEngine Custom Content Types (CCT) operations including
 * CRUD operations, repeater fields, and field-based queries.
 */
final class CctService
{
    private NodeInfoProvider $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    /**
     * Retrieve all available content types.
     *
     * @return array<string, mixed> Response array with content types
     */
    public function getAllContentTypes(): array
    {
        return [
            'response'    => JetEngineHelper::fetchContentTypes(),
            'payload'     => [],
            'status_code' => 200,
        ];
    }

    /**
     * Retrieve items by content type.
     *
     * @return array<string, mixed> Response array with CCT items
     */
    public function getItemsByContentType(): array
    {
        $fieldMappings = $this->getFieldMappings();

        $validationError = $this->validateContentTypeField($fieldMappings);
        if ($validationError) {
            return $validationError;
        }

        $cctItems = JetEngineHelper::fetchCctItems($fieldMappings['content_type']);

        if (empty($cctItems)) {
            return [
                'response'    => __('Content type items not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404,
            ];
        }

        return [
            'response'    => $cctItems,
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Retrieve specific CCT item by ID.
     *
     * @return array<string, mixed> Response array with CCT item data
     */
    public function getContentTypeItemById(): array
    {
        $fieldMappings = $this->getFieldMappings();

        $validationError = $this->validateContentTypeWithItemId($fieldMappings);
        if ($validationError) {
            return $validationError;
        }

        $cctItem = JetEngineHelper::fetchCctItems(
            $fieldMappings['content_type'],
            (int) $fieldMappings['cct_item_id']
        );

        if (empty($cctItem)) {
            return [
                'response'    => __('Content type item not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404,
            ];
        }

        return [
            'response'    => $cctItem,
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Create new Custom Content Type item.
     *
     * @return array<string, mixed> Response array with created item data
     */
    public function createCustomContentTypeItem(): array
    {
        $fieldMappings = $this->getFieldMappings();
        $cctFields = $this->extractCctFieldsFromRepeater();

        $validationError = $this->validateContentTypeField($fieldMappings);
        if ($validationError) {
            return $validationError;
        }

        $fieldsValidationError = $this->validateCctFieldsData($cctFields, $fieldMappings);
        if ($fieldsValidationError) {
            return $fieldsValidationError;
        }

        $insertId = $this->performCctItemInsert($fieldMappings['content_type'], $cctFields);

        if (!$insertId) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('Failed to create CCT item.', 'bit-pi'),
            ];
        }

        return [
            'response'    => JetEngineHelper::fetchCctItems($fieldMappings['content_type'], $insertId),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Update existing Custom Content Type item.
     *
     * @return array<string, mixed> Response array with updated item data
     */
    public function updateCustomContentTypeItem(): array
    {
        $fieldMappings = $this->getFieldMappings();
        $cctFields = $this->extractCctFieldsFromRepeater();

        $validationError = $this->validateContentTypeWithItemId($fieldMappings);
        if ($validationError) {
            return $validationError;
        }

        $fieldsValidationError = $this->validateCctFieldsData($cctFields, $fieldMappings);
        if ($fieldsValidationError) {
            return $fieldsValidationError;
        }

        $result = $this->performCctItemUpdate(
            $fieldMappings['content_type'],
            (int) $fieldMappings['cct_item_id'],
            $cctFields
        );

        if (!$result) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('Failed to update CCT item.', 'bit-pi'),
            ];
        }

        return [
            'response' => JetEngineHelper::fetchCctItems(
                $fieldMappings['content_type'],
                (int) $fieldMappings['cct_item_id']
            ),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Add repeater items to Custom Content Type.
     *
     * @return array<string, mixed> Response array with updated item data
     */
    public function addRepeaterItemToCustomContentType(): array
    {
        $fieldMappings = $this->getFieldMappings();
        $repeaterFields = $this->extractRepeaterFieldsFromRepeater();

        $validationError = $this->validateRepeaterFieldsRequest($fieldMappings, $repeaterFields);
        if ($validationError) {
            return $validationError;
        }

        $cctItemId = (int) $fieldMappings['cct_item_id'];
        $contentType = $fieldMappings['content_type'];

        $cctValidationError = $this->ensureCctItemExists($cctItemId, $contentType, $fieldMappings);
        if ($cctValidationError) {
            return $cctValidationError;
        }

        $groupedData = $this->organizeRepeaterFieldsByName($repeaterFields);
        $this->appendRepeaterItemsToCct($contentType, $cctItemId, $groupedData);

        return [
            'response'    => JetEngineHelper::fetchCctItems($contentType, $cctItemId),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Query CCT records by field criteria.
     *
     * @return array<string, mixed> Response array with query results
     */
    public function getCustomContentTypeRecordsByField(): array
    {
        $fieldMappings = $this->getFieldMappings();

        $validationError = $this->validateFieldSearchRequest($fieldMappings);
        if ($validationError) {
            return $validationError;
        }

        $queryParams = $this->buildQueryParameters($fieldMappings);
        $results = $this->executeCctFieldQuery($queryParams);
        $items = $this->unserializeQueryResults($results);

        return [
            'response'    => $items,
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Validate repeater fields request.
     *
     * @param array<string, mixed> $fieldMappings   Field data
     * @param mixed                $repeaterFields  Repeater fields data
     *
     * @return null|array<string, mixed> Error response or null if valid
     */
    private function validateRepeaterFieldsRequest(array $fieldMappings, $repeaterFields): ?array
    {
        $validationError = JetEngineHelper::validateFieldMap(
            $fieldMappings,
            [
                'content_type' => ['required', 'string'],
                'cct_item_id'  => ['required', 'integer'],
            ]
        );

        if ($validationError) {
            return $validationError;
        }

        if (empty($repeaterFields) || !\is_array($repeaterFields)) {
            return [
                'response'    => __('Repeater fields are required.', 'bit-pi'),
                'status_code' => 400,
                'payload'     => $fieldMappings,
            ];
        }

        return null;
    }

    /**
     * Ensure CCT item exists before operations.
     *
     * @param int                  $cctItemId     CCT item ID to verify
     * @param string               $contentType   Content type slug
     * @param array<string, mixed> $fieldMappings Field mappings for error response
     *
     * @return null|array<string, mixed> Error response or null if exists
     */
    private function ensureCctItemExists(int $cctItemId, string $contentType, array $fieldMappings): ?array
    {
        $item = JetEngineHelper::fetchCctItems($contentType, $cctItemId);

        if (empty($item)) {
            return [
                'response'    => __('CCT item not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404,
            ];
        }

        return null;
    }

    /**
     * Organize repeater fields by name into grouped structure.
     *
     * @param array<int, array<string, mixed>> $repeaterFields Raw repeater field data
     *
     * @return array<string, array<int, array<string, mixed>>> Grouped repeater data
     */
    private function organizeRepeaterFieldsByName(array $repeaterFields): array
    {
        $groupedData = [];
        $rowIndexes = [];

        foreach ($repeaterFields as $mapping) {
            $repeaterName = $mapping['repeaterName'];
            $fieldName = $mapping['itemName'];
            $fieldValue = $mapping['itemValue'];

            if (!isset($groupedData[$repeaterName])) {
                $groupedData[$repeaterName] = [];
                $rowIndexes[$repeaterName] = 0;
            }

            $currentIndex = $rowIndexes[$repeaterName];

            // Start new row if field already exists in current row
            if (isset($groupedData[$repeaterName][$currentIndex][$fieldName])) {
                ++$rowIndexes[$repeaterName];
                $currentIndex = $rowIndexes[$repeaterName];
            }

            $groupedData[$repeaterName][$currentIndex][$fieldName] = $fieldValue;
        }

        return $groupedData;
    }

    /**
     * Append new repeater items to CCT record.
     *
     * @param string                                              $contentType Content type slug
     * @param int                                                 $cctItemId   CCT item ID
     * @param array<string, array<int, array<string, mixed>>>    $groupedData Organized repeater data
     */
    private function appendRepeaterItemsToCct(string $contentType, int $cctItemId, array $groupedData): void
    {
        $repeaterData = [];

        foreach ($groupedData as $repeaterName => $newItems) {
            $existingItems = $this->fetchExistingCctRepeaterItems($contentType, $cctItemId, $repeaterName);
            $mergedItems = $this->mergeRepeaterItemArrays($existingItems, $newItems);
            $repeaterData[$repeaterName] = maybe_serialize($mergedItems);
        }

        $this->performCctItemUpdate($contentType, $cctItemId, $repeaterData);
    }

    /**
     * Fetch existing repeater items from CCT record.
     *
     * @param string $contentType  Content type slug
     * @param int    $cctItemId    CCT item ID
     * @param string $repeaterName Repeater field name
     *
     * @return array<int|string, mixed> Existing repeater items
     */
    private function fetchExistingCctRepeaterItems(string $contentType, int $cctItemId, string $repeaterName): array
    {
        $item = JetEngineHelper::fetchCctItems($contentType, $cctItemId);

        if (empty($item) || !isset($item[0][$repeaterName])) {
            return [];
        }

        $existingData = maybe_unserialize($item[0][$repeaterName]);

        return \is_array($existingData) ? $existingData : [];
    }

    /**
     * Merge new items into existing repeater array.
     *
     * @param array<int|string, array<string, mixed>> $existingItems Current repeater items
     * @param array<int, array<string, mixed>>        $newItems      New items to add
     *
     * @return array<int|string, array<string, mixed>> Merged repeater items
     */
    private function mergeRepeaterItemArrays(array $existingItems, array $newItems): array
    {
        $nextIndex = \count($existingItems);

        foreach ($newItems as $newItem) {
            $existingItems['item-' . $nextIndex] = $newItem;
            ++$nextIndex;
        }

        return $existingItems;
    }

    /**
     * Validate content_type field.
     */
    private function validateContentTypeField(array $fieldMappings): ?array
    {
        $rules = ['content_type' => ['required', 'string']];

        return JetEngineHelper::validateFieldMap($fieldMappings, $rules);
    }

    /**
     * Validate content_type and cct_item_id fields.
     */
    private function validateContentTypeWithItemId(array $fieldMappings): ?array
    {
        $rules = [
            'content_type' => ['required', 'string'],
            'cct_item_id'  => ['required', 'integer'],
        ];

        return JetEngineHelper::validateFieldMap($fieldMappings, $rules);
    }

    /**
     * Validate field search request parameters.
     */
    private function validateFieldSearchRequest(array $fieldMappings): ?array
    {
        $rules = [
            'content_type' => ['required', 'string'],
            'field_name'   => ['required', 'string'],
        ];

        return JetEngineHelper::validateFieldMap($fieldMappings, $rules);
    }

    /**
     * Extract field mappings from node provider.
     *
     * @return array<string, mixed> Field mappings
     */
    private function getFieldMappings(): array
    {
        return $this->nodeInfoProvider->getFieldMapData();
    }

    /**
     * Extract CCT fields from repeater configuration.
     *
     * @return array<string, mixed>|string CCT fields data
     */
    private function extractCctFieldsFromRepeater()
    {
        return $this->nodeInfoProvider->getFieldMapRepeaters('cct-fields.value', false, true, 'cctField');
    }

    /**
     * Extract repeater fields from configuration.
     *
     * @return array<int, array<string, mixed>>|string Repeater fields data
     */
    private function extractRepeaterFieldsFromRepeater()
    {
        return $this->nodeInfoProvider->getFieldMapRepeaters('repeater-fields.value', false, false);
    }

    /**
     * Validate CCT fields data is not empty.
     *
     * @param mixed                $cctFields     CCT fields data
     * @param array<string, mixed> $fieldMappings Field mappings for error response
     *
     * @return null|array<string, mixed> Error response or null if valid
     */
    private function validateCctFieldsData($cctFields, array $fieldMappings): ?array
    {
        if (empty($cctFields) || !\is_array($cctFields)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('CCT fields are required.', 'bit-pi'),
            ];
        }

        return null;
    }

    /**
     * Insert new CCT item into database.
     *
     * @param string               $contentType Content type slug
     * @param array<string, mixed> $cctFields   Field data to insert
     *
     * @return false|int Insert ID on success, false on failure
     */
    private function performCctItemInsert(string $contentType, array $cctFields)
    {
        global $wpdb;

        $tableName = $wpdb->prefix . 'jet_cct_' . $contentType;
        $result = $wpdb->insert($tableName, $cctFields);

        return $result ? $wpdb->insert_id : false;
    }

    /**
     * Update existing CCT item in database.
     *
     * @param string               $contentType Content type slug
     * @param int                  $itemId      Item ID to update
     * @param array<string, mixed> $cctFields   Field data to update
     *
     * @return bool True on success, false on failure
     */
    private function performCctItemUpdate(string $contentType, int $itemId, array $cctFields): bool
    {
        global $wpdb;

        $tableName = $wpdb->prefix . 'jet_cct_' . $contentType;
        $result = $wpdb->update($tableName, $cctFields, ['_ID' => $itemId]);

        return $result !== false;
    }

    /**
     * Build query parameters from field mappings.
     *
     * @param array<string, mixed> $fieldMappings Field mappings
     *
     * @return array<string, mixed> Query parameters
     */
    private function buildQueryParameters(array $fieldMappings): array
    {
        return [
            'content_type' => $fieldMappings['content_type'],
            'field_name'   => $fieldMappings['field_name'],
            'field_value'  => $fieldMappings['field_value'] ?? '',
            'operator'     => $fieldMappings['operator'] ?? 'equals',
            'limit'        => (int) ($fieldMappings['limit'] ?? 0),
            'offset'       => (int) ($fieldMappings['offset'] ?? 0),
        ];
    }

    /**
     * Execute CCT field-based query.
     *
     * @param array<string, mixed> $params Query parameters
     *
     * @return array<int, array<string, mixed>> Query results
     */
    private function executeCctFieldQuery(array $params): array
    {
        global $wpdb;

        $tableName = $wpdb->prefix . 'jet_cct_' . $params['content_type'];
        $where = $this->buildWhereClause($params['field_name'], $params['field_value'], $params['operator']);
        $limitClause = $this->buildLimitClause($params['limit'], $params['offset']);

        $query = "SELECT * FROM `{$tableName}`{$where}{$limitClause}";

        return $wpdb->get_results($query, ARRAY_A) ?? [];
    }

    /**
     * Build WHERE clause based on operator type.
     *
     * @param string $fieldName  Field name to query
     * @param string $fieldValue Field value to match
     * @param string $operator   Comparison operator
     *
     * @return string WHERE clause SQL
     */
    private function buildWhereClause(string $fieldName, string $fieldValue, string $operator): string
    {
        global $wpdb;

        switch ($operator) {
            case 'equals':
                return $wpdb->prepare(" WHERE `{$fieldName}` = %s", $fieldValue);

            case 'not_equals':
                return $wpdb->prepare(" WHERE `{$fieldName}` != %s", $fieldValue);

            case 'contains':
                return $wpdb->prepare(" WHERE `{$fieldName}` LIKE %s", '%' . $wpdb->esc_like($fieldValue) . '%');

            case 'greater_than':
                return $wpdb->prepare(" WHERE `{$fieldName}` > %s", $fieldValue);

            case 'less_than':
                return $wpdb->prepare(" WHERE `{$fieldName}` < %s", $fieldValue);

            case 'is_empty':
                return " WHERE (`{$fieldName}` IS NULL OR `{$fieldName}` = '')";

            case 'is_not_empty':
                return " WHERE (`{$fieldName}` IS NOT NULL AND `{$fieldName}` != '')";

            case 'is_true':
                return " WHERE `{$fieldName}` = '1' OR `{$fieldName}` = 'true'";

            case 'is_false':
                return " WHERE `{$fieldName}` = '0' OR `{$fieldName}` = 'false' OR `{$fieldName}` = ''";

            default:
                return '';
        }
    }

    /**
     * Build LIMIT clause for pagination.
     *
     * @param int $limit  Maximum number of rows
     * @param int $offset Starting offset
     *
     * @return string LIMIT clause SQL
     */
    private function buildLimitClause(int $limit, int $offset): string
    {
        if ($limit <= 0) {
            return '';
        }

        global $wpdb;

        return $wpdb->prepare(' LIMIT %d OFFSET %d', $limit, $offset);
    }

    /**
     * Unserialize query results recursively.
     *
     * @param array<int, array<string, mixed>> $results Raw query results
     *
     * @return array<int, array<string, mixed>> Unserialized results
     */
    private function unserializeQueryResults(array $results): array
    {
        return array_map(
            static function ($item) {
                return array_map('maybe_unserialize', $item);
            },
            $results
        );
    }
}
