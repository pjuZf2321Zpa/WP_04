<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\PiPro\src\Integrations\JetEngine\JetEngineHelper;

Route::group(
    function () {
        Route::get('get_all_post_types_jet_engine', [JetEngineHelper::class, 'getAllPostTypes']);
        Route::get('get_all_forms_jet_engine', [JetEngineHelper::class, 'getAllForms']);
        Route::get('get_all_posts_jet_engine', [JetEngineHelper::class, 'getPostsByType']);
        Route::post('get_post_meta_fields_jet_engine', [JetEngineHelper::class, 'getPostMetaFields']);
        Route::post('get_cct_fields_jet_engine', [JetEngineHelper::class, 'getCctFields']);
        Route::get('get_all_content_types_jet_engine', [JetEngineHelper::class, 'getAllContentTypes']);
        Route::get('get_all_option_pages_jet_engine', [JetEngineHelper::class, 'getAllOptionPages']);
    }
)->middleware('nonce:admin');
