<?php

namespace BitApps\PiPro\src\Integrations\JetEngine;

if (!\defined('ABSPATH')) {
    exit;
}

use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use WP_Post;

/**
 * JetEngineTrigger Class.
 *
 * Handles all JetEngine trigger events including forms, post meta,
 * custom content types, option pages, and templates.
 */
final class JetEngineTrigger
{
    /**
     * Trigger when JetEngine form is submitted.
     *
     * @param object $handler Form handler object
     * @param bool   $success Whether submission was successful
     */
    public static function formSubmitted($handler, bool $success): void
    {
        if (!self::isValidFormSubmission($handler, $success)) {
            return;
        }

        $data = self::buildFormSubmissionData($handler);
        self::executeFlow(__FUNCTION__, $data, $handler->form);
    }

    /**
     * Trigger when post meta data is updated.
     *
     * @param int    $metaId   Meta ID
     * @param int    $postId    Post ID
     * @param string $metaKey   Meta key
     * @param mixed  $metaValue Meta value
     */
    public static function postMetaData(int $metaId, int $postId, string $metaKey, $metaValue): void
    {
        $postData = get_post($postId);

        if (!$postData) {
            return;
        }

        $data = self::buildPostMetaData($postData, $metaKey, $metaValue);
        self::executeFlow(__FUNCTION__, $data, $postData->post_type, 'post-type-id');
    }

    /**
     * Trigger when custom content type item is created.
     *
     * @param array<string, mixed> $item   Created item data
     * @param int                  $itemId Item ID
     */
    public static function customContentTypeItemCreated(array $item, int $itemId): void
    {
        $contentType = self::extractContentTypeFromAction('created-item');
        $data = self::buildContentTypeItemData($item, $itemId, $contentType);

        self::executeFlow(__FUNCTION__, $data, $contentType, 'content-type');
    }

    /**
     * Trigger when custom content type item is updated.
     *
     * @param array<string, mixed> $item     Updated item data
     * @param array<string, mixed> $prevItem Previous item data
     */
    public static function customContentTypeItemUpdated(array $item, array $prevItem): void
    {
        if (empty($prevItem)) {
            return;
        }

        $contentType = self::extractContentTypeFromAction('updated-item');
        $data = self::buildContentTypeUpdateData($item, $prevItem, $contentType);

        self::executeFlow(__FUNCTION__, $data, $contentType, 'content-type');
    }

    /**
     * Trigger when option page field is updated.
     */
    public static function optionPageFieldUpdated(): void
    {
        $optionPage = self::extractOptionPageSlugFromAction();
        $data = self::buildOptionPageData($optionPage);

        self::executeFlow(__FUNCTION__, $data, $optionPage, 'option-page');
    }

    /**
     * Trigger when new listing template is created.
     *
     * @param int                  $templateId Template ID
     * @param array<string, mixed> $postData   Template post data
     */
    public static function newListingTemplate(int $templateId, array $postData): void
    {
        $data = self::buildListingTemplateData($templateId, $postData);
        self::executeFlow(__FUNCTION__, $data);
    }

    /**
     * Trigger when post type is deleted.
     *
     * @param string $postTypeSlug Post type slug
     */
    public static function postTypeDeleted(string $postTypeSlug): void
    {
        $data = self::buildPostTypeDeletedData($postTypeSlug);
        self::executeFlow(__FUNCTION__, $data);
    }

    /**
     * Trigger when post type slug is updated.
     *
     * @param string $newSlug New post type slug
     * @param string $oldSlug Old post type slug
     */
    public static function postTypeSlugUpdated(string $newSlug, string $oldSlug): void
    {
        $data = self::buildPostTypeSlugUpdateData($newSlug, $oldSlug);
        self::executeFlow(__FUNCTION__, $data);
    }

    /**
     * Validate form submission prerequisites.
     *
     * @param mixed $handler Form handler object
     * @param bool  $success Submission success status
     *
     * @return bool True if valid, false otherwise
     */
    private static function isValidFormSubmission($handler, bool $success): bool
    {
        return $success && !empty($handler);
    }

    /**
     * Build form submission data array.
     *
     * @param object $handler Form handler object
     *
     * @return array<string, mixed> Form submission data
     */
    private static function buildFormSubmissionData($handler): array
    {
        return [
            'form_id'    => $handler->form,
            'form_data'  => $handler->form_data,
            'form_refer' => $handler->refer,
        ];
    }

    /**
     * Build post meta data array.
     *
     * @param WP_Post $postData  Post object
     * @param string   $metaKey   Meta key
     * @param mixed    $metaValue Meta value
     *
     * @return array<string, mixed> Post meta data
     */
    private static function buildPostMetaData(WP_Post $postData, string $metaKey, $metaValue): array
    {
        return array_merge(
            (array) $postData,
            [
                'meta_key'   => $metaKey,
                'meta_value' => $metaValue,
            ]
        );
    }

    /**
     * Build content type item data array.
     *
     * @param array<string, mixed> $item        Item data
     * @param int                  $itemId      Item ID
     * @param string               $contentType Content type slug
     *
     * @return array<string, mixed> Content type item data
     */
    private static function buildContentTypeItemData(array $item, int $itemId, string $contentType): array
    {
        return [
            'item'         => $item,
            'item_id'      => $itemId,
            'content_type' => $contentType,
        ];
    }

    /**
     * Build content type update data array.
     *
     * @param array<string, mixed> $item        Updated item data
     * @param array<string, mixed> $prevItem    Previous item data
     * @param string               $contentType Content type slug
     *
     * @return array<string, mixed> Content type update data
     */
    private static function buildContentTypeUpdateData(array $item, array $prevItem, string $contentType): array
    {
        return [
            'item'         => $item,
            'prev_item'    => $prevItem,
            'content_type' => $contentType,
        ];
    }

    /**
     * Build option page data array.
     *
     * @param string $optionPage Option page slug
     *
     * @return array<string, mixed> Option page data
     */
    private static function buildOptionPageData(string $optionPage): array
    {
        return [
            'updated_fields' => get_option($optionPage, []),
            'option_page'    => $optionPage,
        ];
    }

    /**
     * Build listing template data array.
     *
     * @param int                  $templateId Template ID
     * @param array<string, mixed> $postData   Post data
     *
     * @return array<string, mixed> Listing template data
     */
    private static function buildListingTemplateData(int $templateId, array $postData): array
    {
        return [
            'template_id' => $templateId,
            'post_data'   => $postData,
        ];
    }

    /**
     * Build post type deleted data array.
     *
     * @param string $postTypeSlug Post type slug
     *
     * @return array<string, mixed> Post type deleted data
     */
    private static function buildPostTypeDeletedData(string $postTypeSlug): array
    {
        return ['post_type_slug' => $postTypeSlug];
    }

    /**
     * Build post type slug update data array.
     *
     * @param string $newSlug New slug
     * @param string $oldSlug Old slug
     *
     * @return array<string, mixed> Slug update data
     */
    private static function buildPostTypeSlugUpdateData(string $newSlug, string $oldSlug): array
    {
        return [
            'old_slug' => $oldSlug,
            'new_slug' => $newSlug,
        ];
    }

    /**
     * Extract content type slug from current action hook.
     *
     * @param string $actionType Action type ('created-item' or 'updated-item')
     *
     * @return string Content type slug
     */
    private static function extractContentTypeFromAction(string $actionType): string
    {
        return str_replace(
            'jet-engine/custom-content-types/' . $actionType . '/',
            '',
            current_action()
        );
    }

    /**
     * Extract option page slug from current action hook.
     *
     * @return string Option page slug
     */
    private static function extractOptionPageSlugFromAction(): string
    {
        return str_replace(
            'jet-engine/options-pages/after-save/',
            '',
            current_action()
        );
    }

    /**
     * Execute flow for the given trigger.
     *
     * @param string               $machineSlug Trigger machine slug
     * @param array<string, mixed> $data        Trigger data
     * @param mixed                $value       Filter value (optional)
     * @param string               $keyName     Filter key name
     */
    private static function executeFlow(string $machineSlug, array $data, $value = null, string $keyName = 'form-id'): void
    {
        $flows = FlowService::exists('jetEngine', $machineSlug);

        if (!$flows) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $data, $value, $keyName);
    }
}
