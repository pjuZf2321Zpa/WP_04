<?php

namespace BitApps\PiPro\src\Integrations\JetEngine;

// Prevent direct script access
if (!\defined('ABSPATH')) {
    exit;
}

use BitApps\Pi\Deps\BitApps\WPKit\Http\Request\Request;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\PiPro\Deps\BitApps\WPValidator\Validator;
use Jet_Engine\Modules\Custom_Content_Types\Module;
use WP_Post;
use WP_Query;

/**
 * JetEngine Helper Class.
 *
 * Provides helper methods for interacting with JetEngine plugin features including
 * post types, custom content types (CCT), option pages, and meta fields.
 */
final class JetEngineHelper
{
    /**
     * System fields to exclude from CCT field lists.
     */
    private const EXCLUDED_CCT_FIELDS = ['_ID', 'cct_author_id', 'cct_created', 'cct_modified', 'cct_status'];

    /**
     * Retrieve all public post types.
     *
     * @return array<int, array{value: string, label: string}> List of post types
     */
    public static function fetchPublicPostTypes(): array
    {
        $postTypeArgs = [
            'public'          => true,
            'capability_type' => 'post',
        ];

        $postTypes = get_post_types($postTypeArgs, 'object');
        $formattedTypes = [];

        foreach ($postTypes as $postType) {
            $formattedTypes[] = [
                'value' => $postType->name,
                'label' => $postType->label,
            ];
        }

        return $formattedTypes;
    }

    /**
     * Retrieve all JetEngine booking forms.
     *
     * @return array<int, array{value: int|string, label: string}> List of booking forms
     */
    public static function fetchBookingForms(): array
    {
        $forms = get_posts(
            [
                'post_type'      => 'jet-engine-booking',
                'posts_per_page' => -1,
                'post_status'    => 'publish',
                'orderby'        => 'title',
                'order'          => 'ASC',
            ]
        );

        $formattedForms = [['value' => 'any', 'label' => __('Any Form', 'bit-pi')]];

        foreach ($forms as $form) {
            $formattedForms[] = [
                'value' => $form->ID,
                'label' => $form->post_title,
            ];
        }

        return $formattedForms;
    }

    /**
     * Retrieve Custom Content Type item(s) by content type and optional item ID.
     *
     * @param string   $contentType The CCT slug
     * @param null|int $itemId      Optional specific item ID to retrieve
     *
     * @return array<int|string, mixed> CCT item(s) data or empty array
     */
    public static function fetchCctItems(string $contentType, ?int $itemId = null): array
    {
        global $wpdb;

        if (empty($contentType)) {
            return [];
        }

        $tableName = $wpdb->prefix . 'jet_cct_' . $contentType;

        // Check if table exists
        if (!self::cctTableExists($tableName)) {
            return [];
        }

        $query = "SELECT * FROM `{$tableName}`";
        $preparedQuery = $query;

        if ($itemId !== null) {
            $query .= ' WHERE `_ID` = %d';
            $preparedQuery = $wpdb->prepare($query, $itemId);
        }

        $results = $wpdb->get_results($preparedQuery, ARRAY_A);

        if (empty($results)) {
            return [];
        }

        return self::unserializeArrayRecursive($results);
    }

    /**
     * Retrieve all JetEngine Custom Content Types.
     *
     * @return array<int, array<string, mixed>> List of content types
     */
    public static function fetchContentTypes(): array
    {
        if (!class_exists('Jet_Engine')) {
            return [];
        }

        global $wpdb;

        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM `{$wpdb->prefix}jet_post_types` WHERE `status` = %s",
                'content-type'
            ),
            ARRAY_A
        );

        if (empty($results)) {
            return [];
        }

        return self::unserializeArrayRecursive($results);
    }

    /**
     * Retrieve JetEngine Option Pages by optional slug.
     *
     * @param null|string $slug Optional slug to filter by
     *
     * @return array<int, array<string, mixed>> List of option pages
     */
    public static function fetchOptionPages(?string $slug = null): array
    {
        if (!class_exists('Jet_Engine')) {
            return [];
        }

        global $wpdb;

        $query = "SELECT * FROM `{$wpdb->prefix}jet_post_types` WHERE `status` = %s";
        $params = ['page'];

        if (!empty($slug)) {
            $query .= ' AND `slug` = %s';
            $params[] = $slug;
        }

        $results = $wpdb->get_results($wpdb->prepare($query, ...$params), ARRAY_A);

        if (empty($results)) {
            return [];
        }

        return self::unserializeArrayRecursive($results);
    }

    /**
     * Retrieve all public post types with "Any" option.
     *
     * @return Response Success response with post types
     */
    public static function getAllPostTypes(): Response
    {
        $types = self::fetchPublicPostTypes();

        array_unshift(
            $types,
            [
                'value' => 'any-post-type',
                'label' => __('Any Post Type', 'bit-pi'),
            ]
        );

        return Response::success($types);
    }

    /**
     * Retrieve all booking forms.
     *
     * @return Response Success response with forms
     */
    public static function getAllForms(): Response
    {
        return Response::success(self::fetchBookingForms());
    }

    /**
     * Retrieve posts by post type.
     *
     * @param string $postType The post type slug
     *
     * @return WP_Post[] Array of post objects
     */
    public static function fetchPostsByType(string $postType): array
    {
        $query = new WP_Query(
            [
                'post_type'      => $postType,
                'posts_per_page' => -1,
                'post_status'    => 'any',
                'orderby'        => 'title',
                'order'          => 'ASC',
                'no_found_rows'  => true,
            ]
        );

        return $query->posts;
    }

    /**
     * Get posts by type from request parameter.
     *
     * @return Response Success response with formatted post list
     */
    public static function getPostsByType(): Response
    {
        $postType = isset($_GET['postType']) ? sanitize_text_field($_GET['postType']) : 'post';

        $posts = self::fetchPostsByType($postType);
        $formattedPosts = array_map(
            static function ($post) {
                return [
                    'value' => $post->ID,
                    'label' => $post->post_title . ' (ID: ' . $post->ID . ')',
                ];
            },
            $posts
        );

        return Response::success($formattedPosts);
    }

    /**
     * Retrieve JetEngine meta fields for a specific post type.
     *
     * @param Request $request The HTTP request object
     *
     * @return Response Success response with meta fields
     */
    public static function getPostMetaFields(Request $request): Response
    {
        $validatedData = $request->validate(
            [
                'post_type' => ['required', 'string', 'sanitize:text'],
            ]
        );

        if (!\function_exists('jet_engine') || empty(jet_engine()->meta_boxes->meta_fields)) {
            return Response::success([]);
        }

        $postType = $validatedData['post_type'] ?? 'post';
        $metaFields = jet_engine()->meta_boxes->meta_fields[$postType] ?? [];

        if (empty($metaFields)) {
            return Response::success([]);
        }

        foreach ($metaFields as $field) {
            if (empty($field['name'])) {
                continue;
            }

            $formattedFields[] = [
                'value' => $field['name'],
                'label' => $field['title'] ?? $field['name'],
            ];
        }

        return Response::success(array_values($formattedFields));
    }

    /**
     * Retrieve CCT fields for a specific content type.
     *
     * @param Request $request The HTTP request object
     *
     * @return Response Success response with CCT fields
     */
    public static function getCctFields(Request $request): Response
    {
        $validatedData = $request->validate(
            [
                'content_type' => ['required', 'string', 'sanitize:text'],
            ]
        );

        if (!class_exists('\Jet_Engine\Modules\Custom_Content_Types\Module')) {
            return Response::success([]);
        }

        $contentType = Module::instance()->manager->get_content_types($validatedData['content_type']);
        $cctFields = $contentType->get_fields_list() ?? [];

        if (empty($cctFields)) {
            return Response::success([]);
        }

        $formattedFields = [];
        foreach ($cctFields as $key => $label) {
            if (\in_array($key, self::EXCLUDED_CCT_FIELDS, true)) {
                continue;
            }

            $formattedFields[] = [
                'value' => $key,
                'label' => $label,
            ];
        }

        return Response::success($formattedFields);
    }

    /**
     * Retrieve all Content Types formatted for display.
     *
     * @return Response Success response with formatted content types
     */
    public static function getAllContentTypes(): Response
    {
        $contentTypes = self::fetchContentTypes();

        $formattedTypes = array_map(
            static function ($type) {
                return [
                    'value' => $type['slug'],
                    'label' => $type['args']['name'] ?? $type['slug'],
                ];
            },
            $contentTypes
        );

        return Response::success($formattedTypes);
    }

    /**
     * Retrieve all Option Pages formatted for display.
     *
     * @return Response Success response with formatted option pages
     */
    public static function getAllOptionPages(): Response
    {
        $optionPages = self::fetchOptionPages();

        $formattedPages = array_map(
            static function ($page) {
                return [
                    'value' => $page['slug'],
                    'label' => $page['labels']['name'] ?? $page['slug'],
                ];
            },
            $optionPages
        );

        return Response::success($formattedPages);
    }

    /**
     * Validate field mappings against rules.
     *
     * @param array<string, mixed> $fieldMappings Field data to validate
     * @param array<string, array> $rules         Validation rules
     * @param array<string, mixed> $payload       Optional custom payload for error response
     *
     * @return null|array<string, mixed> Error response array or null if valid
     */
    public static function validateFieldMap(array $fieldMappings, array $rules, ?array $payload = null): ?array
    {
        $validator = new Validator();
        $validation = $validator->make($fieldMappings, $rules);

        if ($validation->fails()) {
            return [
                'response'    => $validation->errors(),
                'payload'     => $payload ?? $fieldMappings,
                'status_code' => 400,
            ];
        }

        return null;
    }

    /**
     * Check if a CCT table exists in the database.
     *
     * @param string $tableName The table name to check
     *
     * @return bool True if table exists, false otherwise
     */
    private static function cctTableExists(string $tableName): bool
    {
        global $wpdb;

        return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $tableName)) === $tableName;
    }

    /**
     * Recursively unserialize array values.
     *
     * @param array<int|string, mixed> $data The data to unserialize
     *
     * @return array<int|string, mixed> Unserialized data
     */
    private static function unserializeArrayRecursive(array $data): array
    {
        return array_map(
            static function ($item) {
                return \is_array($item) ? array_map('maybe_unserialize', $item) : $item;
            },
            $data
        );
    }
}
