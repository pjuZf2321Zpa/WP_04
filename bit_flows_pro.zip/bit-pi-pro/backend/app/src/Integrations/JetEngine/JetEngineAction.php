<?php

namespace BitApps\PiPro\src\Integrations\JetEngine;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;

if (!\defined('ABSPATH')) {
    exit;
}


class JetEngineAction implements ActionInterface
{
    /**
     * Action routing map - maps machine slugs to their respective service categories
     * This provides explicit documentation of available actions and improves maintainability.
     */
    private const ACTION_SERVICE_MAP = [
        // Post Actions
        'createPost'                      => 'CptService',
        'updatePost'                      => 'CptService',
        'updatePostMeta'                  => 'CptService',
        'updateFieldById'                 => 'CptService',
        'updateCustomPostTypeFields'      => 'CptService',
        'addRepeaterItemToCustomPostType' => 'CptService',
        'getPostsByPostType'              => 'CptService',
        'getPostById'                     => 'CptService',
        'getAllPostTypes'                 => 'CptService',

        // CCT (Custom Content Type) Actions
        'getItemsByContentType'              => 'CctService',
        'getContentTypeItemById'             => 'CctService',
        'getAllContentTypes'                 => 'CctService',
        'createCustomContentTypeItem'        => 'CctService',
        'updateCustomContentTypeItem'        => 'CctService',
        'addRepeaterItemToCustomContentType' => 'CctService',
        'getCustomContentTypeRecordsByField' => 'CctService',

        // Option Page Actions
        'getOptionPageBySlug'   => 'OptionService',
        'getAllOptionPages'     => 'OptionService',
        'updateOptionPageField' => 'OptionService',
        'getOptionFieldValue'   => 'OptionService',
    ];

    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeJetEngineAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'] ?? 200,
            $executedNodeAction['payload'] ?? [],
            $executedNodeAction['response'] ?? []
        );
    }

    /**
     * Get the service class for a given action.
     *
     * @param string $machineSlug The action machine slug
     *
     * @return null|string The service class or null if not found
     */
    private static function getServiceClass(string $machineSlug): ?string
    {
        return self::ACTION_SERVICE_MAP[$machineSlug] ?? null;
    }

    private function executeJetEngineAction()
    {
        if (!class_exists('Jet_Engine')) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('JetEngine plugin is not active.', 'bit-pi'),
            ];
        }

        $machineSlug = $this->nodeInfoProvider->getMachineSlug();
        if (empty($machineSlug)) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('Action method is required.', 'bit-pi'),
            ];
        }

        $className = self::getServiceClass($machineSlug);
        if (!$className) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => \sprintf(
                    // translators: %s: action method name
                    __('JetEngine action "%s" is not registered.', 'bit-pi'),
                    $machineSlug
                ),
            ];
        }

        $serviceClass = '\BitApps\PiPro\src\Integrations\JetEngine\Services\\' . $className;

        $jetEngineService = new $serviceClass($this->nodeInfoProvider);

        return $jetEngineService->{$machineSlug}();
    }
}
