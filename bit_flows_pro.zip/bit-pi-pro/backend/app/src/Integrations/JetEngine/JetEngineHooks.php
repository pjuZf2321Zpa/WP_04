<?php

namespace BitApps\PiPro\src\Integrations\JetEngine;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!\defined('ABSPATH')) {
    exit;
}

/**
 * JetEngine trigger hooks registration.
 *
 * Handles the registration of all JetEngine-related WordPress hooks
 * including forms, post types, custom content types, and option pages.
 *
 * @since 1.0.0
 */
class JetEngineHooks implements HookRegisterInterface
{
    /**
     * Register all JetEngine hooks.
     *
     * @return array Array of hook configurations
     */
    public function register(): array
    {
        $hooks = $this->getStaticHooks();
        $hooks = array_merge($hooks, $this->getCustomContentTypeHooks());

        return array_merge($hooks, $this->getOptionPageHooks());
    }

    /**
     * Get static hook configurations.
     *
     * These hooks are always registered regardless of JetEngine configuration.
     *
     * @return array Array of static hook configurations
     */
    private function getStaticHooks(): array
    {
        return [
            'formSubmitted' => [
                'hook'          => 'jet-engine/forms/handler/after-send',
                'callback'      => [JetEngineTrigger::class, 'formSubmitted'],
                'accepted_args' => 2,
            ],
            'postMetaData' => [
                'hook'          => 'updated_post_meta',
                'callback'      => [JetEngineTrigger::class, 'postMetaData'],
                'accepted_args' => 4,
            ],
            'newListingTemplate' => [
                'hook'          => 'jet-engine/templates/created',
                'callback'      => [JetEngineTrigger::class, 'newListingTemplate'],
                'accepted_args' => 2,
            ],
            'postTypeDeleted' => [
                'hook'     => 'jet-engine/post-types/deleted-post-type',
                'callback' => [JetEngineTrigger::class, 'postTypeDeleted'],
            ],
            'postTypeSlugUpdated' => [
                'hook'          => 'jet-engine/post-types/updated-post-type-slug',
                'callback'      => [JetEngineTrigger::class, 'postTypeSlugUpdated'],
                'accepted_args' => 2,
            ],
        ];
    }

    /**
     * Get custom content type hook configurations.
     *
     * Dynamically generates hooks for all custom content types
     * registered in JetEngine (both created and updated items).
     *
     * @return array Array of custom content type hook configurations
     */
    private function getCustomContentTypeHooks(): array
    {
        $hooks = [];
        $contentTypes = JetEngineHelper::fetchContentTypes();

        if (empty($contentTypes)) {
            return $hooks;
        }

        $createdHooks = [];
        $updatedHooks = [];

        foreach ($contentTypes as $contentType) {
            $slug = !empty($contentType['args']['slug']) ? $contentType['args']['slug'] : $contentType['slug'];

            $createdHooks[] = 'jet-engine/custom-content-types/created-item/' . $slug;
            $updatedHooks[] = 'jet-engine/custom-content-types/updated-item/' . $slug;
        }

        if (!empty($createdHooks)) {
            $hooks['customContentTypeItemCreated'] = [
                'hook'          => $createdHooks,
                'callback'      => [JetEngineTrigger::class, 'customContentTypeItemCreated'],
                'accepted_args' => 2,
            ];
        }

        if (!empty($updatedHooks)) {
            $hooks['customContentTypeItemUpdated'] = [
                'hook'          => $updatedHooks,
                'callback'      => [JetEngineTrigger::class, 'customContentTypeItemUpdated'],
                'accepted_args' => 2,
            ];
        }

        return $hooks;
    }

    /**
     * Get option page hook configurations.
     *
     * Dynamically generates hooks for all option pages
     * registered in JetEngine.
     *
     * @return array Array of option page hook configurations
     */
    private function getOptionPageHooks(): array
    {
        $hooks = [];
        $optionPages = JetEngineHelper::fetchOptionPages();

        if (empty($optionPages)) {
            return $hooks;
        }

        $optionPageHooks = array_map(
            function ($optionPage) {
                return 'jet-engine/options-pages/after-save/' . $optionPage['slug'];
            },
            $optionPages
        );

        if (!empty($optionPageHooks)) {
            $hooks['optionPageFieldUpdated'] = [
                'hook'          => $optionPageHooks,
                'callback'      => [JetEngineTrigger::class, 'optionPageFieldUpdated'],
                'accepted_args' => 0,
            ];
        }

        return $hooks;
    }
}
