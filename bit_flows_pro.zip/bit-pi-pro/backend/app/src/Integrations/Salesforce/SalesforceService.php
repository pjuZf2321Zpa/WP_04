<?php

namespace BitApps\PiPro\src\Integrations\Salesforce;

use BitApps\Pi\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Client\HttpClient;

if (!defined('ABSPATH')) {
    exit;
}

class SalesforceService
{
    private $http;

    private $baseUrl;

    /**
     * Salesforce constructor.
     *
     * @param HttpClient $httpClient
     * @param string     $instanceUrl
     */
    public function __construct($httpClient, $instanceUrl)
    {
        $this->http = $httpClient;
        $this->baseUrl = $instanceUrl . '/services/data/v59.0';
    }

    /**
     * Create an Account.
     *
     * @param array $accountFields
     *
     * @return array
     */
    public function createAccount($accountFields)
    {
        $endPoint = $this->baseUrl . '/sobjects/Account';

        $response = $this->http->request(
            $endPoint,
            'POST',
            JSON::encode($accountFields)
        );

        return [
            'response'    => $response,
            'payload'     => $accountFields,
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Create a Lead.
     *
     * @param array $leadFields
     *
     * @return array
     */
    public function createLead($leadFields)
    {
        $endPoint = $this->baseUrl . '/sobjects/Lead';

        $response = $this->http->request(
            $endPoint,
            'POST',
            JSON::encode($leadFields)
        );

        return [
            'response'    => $response,
            'payload'     => $leadFields,
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Create a Task.
     *
     * @param array $taskFields
     *
     * @return array
     */
    public function createTask($taskFields)
    {
        $endPoint = $this->baseUrl . '/sobjects/Task';

        $response = $this->http->request(
            $endPoint,
            'POST',
            JSON::encode($taskFields)
        );

        return [
            'response'    => $response,
            'payload'     => $taskFields,
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Create an Opportunity.
     *
     * @param array $opportunityFields
     *
     * @return array
     */
    public function createOpportunity($opportunityFields)
    {
        $endPoint = $this->baseUrl . '/sobjects/Opportunity';

        $response = $this->http->request(
            $endPoint,
            'POST',
            JSON::encode($opportunityFields)
        );

        return [
            'response'    => $response,
            'payload'     => $opportunityFields,
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Create a Case.
     *
     * @param array $caseFields
     *
     * @return array
     */
    public function createCase($caseFields)
    {
        $endPoint = $this->baseUrl . '/sobjects/Case';

        $response = $this->http->request(
            $endPoint,
            'POST',
            JSON::encode($caseFields)
        );

        return [
            'response'    => $response,
            'payload'     => $caseFields,
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Create a Contact.
     *
     * @param array $contactFields
     *
     * @return array
     */
    public function createContact($contactFields)
    {
        $endPoint = $this->baseUrl . '/sobjects/Contact';

        $response = $this->http->request(
            $endPoint,
            'POST',
            JSON::encode($contactFields)
        );

        return [
            'response'    => $response,
            'payload'     => $contactFields,
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Update a Contact.
     *
     * @param string $contactId
     * @param array  $contactFields
     *
     * @return array
     */
    public function updateContact($contactId, $contactFields)
    {
        $endPoint = $this->baseUrl . '/sobjects/Contact/' . $contactId;

        $response = $this->http->request(
            $endPoint,
            'PATCH',
            JSON::encode($contactFields)
        );

        if (empty($response)) {
            $response = 'Contact updated successfully.';
        }

        return [
            'response'    => $response,
            'payload'     => ['contactId' => $contactId, 'contactFields' => $contactFields],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Update a Lead.
     *
     * @param string $leadId
     * @param array  $leadFields
     *
     * @return array
     */
    public function updateLead($leadId, $leadFields)
    {
        $endPoint = $this->baseUrl . '/sobjects/Lead/' . $leadId;

        $response = $this->http->request(
            $endPoint,
            'PATCH',
            JSON::encode($leadFields)
        );

        if (empty($response)) {
            $response = 'Lead updated successfully.';
        }

        return [
            'response'    => $response,
            'payload'     => ['leadId' => $leadId, 'leadFields' => $leadFields],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Update a Task.
     *
     * @param string $taskId
     * @param array  $taskFields
     *
     * @return array
     */
    public function updateTask($taskId, $taskFields)
    {
        $endPoint = $this->baseUrl . '/sobjects/Task/' . $taskId;

        $response = $this->http->request(
            $endPoint,
            'PATCH',
            JSON::encode($taskFields)
        );

        if (empty($response)) {
            $response = 'Task updated successfully.';
        }

        return [
            'response'    => $response,
            'payload'     => ['taskId' => $taskId, 'taskFields' => $taskFields],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Update an Account.
     *
     * @param string $accountId
     * @param array  $accountFields
     *
     * @return array
     */
    public function updateAccount($accountId, $accountFields)
    {
        $endPoint = $this->baseUrl . '/sobjects/Account/' . $accountId;

        $response = $this->http->request(
            $endPoint,
            'PATCH',
            JSON::encode($accountFields)
        );

        if (empty($response)) {
            $response = 'Account updated successfully.';
        }

        return [
            'response'    => $response,
            'payload'     => ['accountId' => $accountId, 'accountFields' => $accountFields],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Create an Attachment.
     *
     * @param array $attachmentFields
     *
     * @return array
     */
    public function createAttachment($attachmentFields)
    {
        $endPoint = $this->baseUrl . '/sobjects/Attachment';

        $response = $this->http->request(
            $endPoint,
            'POST',
            JSON::encode($attachmentFields)
        );

        return [
            'response'    => $response,
            'payload'     => $attachmentFields,
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Get a User by ID.
     *
     * @param string $userId
     *
     * @return array
     */
    public function getUser($userId)
    {
        $endPoint = $this->baseUrl . '/sobjects/User/' . $userId;

        $response = $this->http->request(
            $endPoint,
            'GET',
            []
        );

        return [
            'response'    => $response,
            'payload'     => ['userId' => $userId],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Get All Users with optional limit.
     *
     * @param null|int $limit
     *
     * @return array
     */
    public function getAllUsers($limit)
    {
        $sanitizedLimit = 200;
        if ($limit !== null) {
            $limit = (int) $limit;
            if ($limit > 0 && $limit <= 2000) {
                $sanitizedLimit = $limit;
            }
        }

        $query = 'SELECT Id, Name, Email FROM User LIMIT ' . $sanitizedLimit;
        $endPoint = $this->baseUrl . '/query?q=' . urlencode($query);

        $response = $this->http->request(
            $endPoint,
            'GET',
            []
        );

        return [
            'response'    => $response,
            'payload'     => ['limit' => $sanitizedLimit],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Get a Contact by ID.
     *
     * @param string $contactId
     *
     * @return array
     */
    public function getContact($contactId)
    {
        $endPoint = $this->baseUrl . '/sobjects/Contact/' . $contactId;

        $response = $this->http->request(
            $endPoint,
            'GET',
            []
        );

        return [
            'response'    => $response,
            'payload'     => ['contactId' => $contactId],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Get the Industry picklist values for a Lead.
     *
     * @return array
     */
    public function getLeadIndustries()
    {
        return $this->getIndustriesByModule('Lead', 'Industry');
    }

    /**
     * Get the Industry picklist values for an Account.
     *
     * @return array
     */
    public function getAccountIndustries()
    {
        return $this->getIndustriesByModule('Account', 'Industry');
    }

    /**
     * Get the picklist values for a specific field in a Salesforce object (module).
     *
     * @param string $module Salesforce object API name (e.g. 'Lead', 'Account')
     * @param string $fieldName  Field API name (e.g. 'Industry')
     *
     * @return array
     */
    public function getIndustriesByModule($module, $fieldName)
    {
        $endPoint = $this->baseUrl . '/sobjects/' . $module . '/describe';

        $response = $this->http->request(
            $endPoint,
            'GET',
            []
        );

        $picklistValues = [];
        if (isset($response->fields) && \is_array($response->fields)) {
            foreach ($response->fields as $field) {
                if (isset($field->name) && $field->name === $fieldName) {
                    $picklistValues = $field->picklistValues ?? [];

                    break;
                }
            }
        }

        return [
            'response'    => $picklistValues,
            'payload'     => ['object' => $module, 'field' => $fieldName],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Add Contact to Campaign.
     *
     * @param array $data
     *
     * @return array
     */
    public function addContactToCampaign($data)
    {
        $endPoint = $this->baseUrl . '/sobjects/CampaignMember';

        $response = $this->http->request(
            $endPoint,
            'POST',
            JSON::encode($data)
        );

        return [
            'response'    => $response,
            'payload'     => $data,
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Add Lead to Campaign.
     *
     * @param array $data
     *
     * @return array
     */
    public function addLeadToCampaign($data)
    {
        $endPoint = $this->baseUrl . '/sobjects/CampaignMember';

        $response = $this->http->request(
            $endPoint,
            'POST',
            JSON::encode($data)
        );

        return [
            'response'    => $response,
            'payload'     => $data,
            'status_code' => $this->http->getResponseCode()
        ];
    }
}
