<?php

namespace BitApps\PiPro\src\Integrations\Salesforce;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Authorization\AuthorizationFactory;
use BitApps\Pi\src\Authorization\AuthorizationType;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Client\HttpClient;

if (!defined('ABSPATH')) {
    exit;
}

class SalesforceAction implements ActionInterface
{
    private NodeInfoProvider $nodeInfoProvider;

    private SalesforceService $salesforceService;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeSalesforceAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'],
            $executedNodeAction['payload'],
            $executedNodeAction['response']
        );
    }

    /**
     * Execute the appropriate Salesforce action based on the machine slug.
     *
     * @param string $machineSlug Machine identifier
     * @param array  $fieldMapData Field map data
     * @param array  $configs Configuration values
     * @param array  $fields Associative array of all field types (accountFields, leadFields, etc.)
     *
     * @return array
     */
    private function executeMachine($machineSlug, $fieldMapData, $configs, $fields)
    {
        switch ($machineSlug) {
            case 'createAccount':
                return $this->salesforceService->createAccount($fields['accountFields']);

            case 'createLead':
                return $this->salesforceService->createLead($fields['leadFields']);

            case 'createTask':
                return $this->salesforceService->createTask($fields['taskFields']);

            case 'createOpportunity':
                return $this->salesforceService->createOpportunity($fields['opportunityFields']);

            case 'createCase':
                return $this->salesforceService->createCase($fields['caseFields']);

            case 'createContact':
                return $this->salesforceService->createContact($fields['contactFields']);

            case 'updateContact':
                return $this->salesforceService->updateContact(
                    $configs['contact-id']['value'],
                    $fields['contactFields']
                );

            case 'updateLead':
                return $this->salesforceService->updateLead(
                    $configs['lead-selector']['value'],
                    $fields['leadFields']
                );

            case 'updateTask':
                return $this->salesforceService->updateTask(
                    $configs['task-selector']['value'],
                    $fields['taskFields']
                );

            case 'updateAccount':
                return $this->salesforceService->updateAccount(
                    $configs['account-selector']['value'],
                    $fields['accountFields']
                );

            case 'createAttachment':
                return $this->salesforceService->createAttachment($fields['attachmentFields']);

            case 'getUser':
                $userId = $configs['user-id']['value'] ?? '';

                return $this->salesforceService->getUser($userId);

            case 'getAllUsers':
                return $this->salesforceService->getAllUsers($fieldMapData['limit'] ?? null);

            case 'getContact':
                $contactId = $configs['contact-id']['value'] ?? '';

                return $this->salesforceService->getContact($contactId);

            case 'addContactToCampaign':
                return $this->salesforceService->addContactToCampaign($fieldMapData);

            case 'addLeadToCampaign':
                return $this->salesforceService->addLeadToCampaign($fieldMapData);

            case 'getLeadIndustries':
                return $this->salesforceService->getLeadIndustries();

            case 'getAccountIndustries':
                return $this->salesforceService->getAccountIndustries();

            case 'addIndustryToLead':
                return $this->salesforceService->updateLead(
                    $configs['lead-selector']['value'] ?? '',
                    ['Industry' => $configs['lead-industry']['value'] ?? '']
                );

            case 'addIndustryToAccount':
                return $this->salesforceService->updateAccount(
                    $configs['account-selector']['value'] ?? '',
                    ['Industry' => $configs['account-industry']['value'] ?? '']
                );

            default:
                return [
                    'response'    => ['error' => "Unsupported action: {$machineSlug}"],
                    'payload'     => ['machineSlug' => $machineSlug],
                    'status_code' => 400
                ];
        }
    }

    private function executeSalesforceAction()
    {
        $machineSlug = $this->nodeInfoProvider->getMachineSlug();
        $configs = $this->nodeInfoProvider->getFieldMapConfigs();
        $fieldMapData = $this->nodeInfoProvider->getFieldMapData();

        $fields = [
            'accountFields'     => $this->nodeInfoProvider->getFieldMapRepeaters('account-fields.value', false, true, 'salesforce-account-fields'),
            'leadFields'        => $this->nodeInfoProvider->getFieldMapRepeaters('lead-fields.value', false, true, 'salesforce-lead-fields'),
            'taskFields'        => $this->nodeInfoProvider->getFieldMapRepeaters('task-fields.value', false, true, 'salesforce-task-fields'),
            'opportunityFields' => $this->nodeInfoProvider->getFieldMapRepeaters('opportunity-fields.value', false, true, 'salesforce-opportunity-fields'),
            'caseFields'        => $this->nodeInfoProvider->getFieldMapRepeaters('case-fields.value', false, true, 'salesforce-case-fields'),
            'contactFields'     => $this->nodeInfoProvider->getFieldMapRepeaters('contact-fields.value', false, true, 'salesforce-contact-fields'),
            'attachmentFields'  => $this->nodeInfoProvider->getFieldMapRepeaters('attachment-fields.value', false, true, 'salesforce-attachment-fields')
        ];

        $authorizationHandler = AuthorizationFactory::getAuthorizationHandler(
            AuthorizationType::OAUTH2,
            $configs['connection-id']
        );

        $accessToken = $authorizationHandler->getAccessToken();
        $authDetails = $authorizationHandler->getAuthDetails();
        $instanceUrl = $authDetails['instance_url'] ?? '';

        $httpClient = new HttpClient(
            [
                'headers' => [
                    'Content-Type'  => 'application/json',
                    'Authorization' => $accessToken
                ],
            ]
        );

        $this->salesforceService = new SalesforceService($httpClient, $instanceUrl);

        return $this->executeMachine($machineSlug, $fieldMapData, $configs, $fields);
    }
}
