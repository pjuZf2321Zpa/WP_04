<?php

namespace BitApps\PiPro\src\Integrations\AutomatorWp;

// Prevent direct script access
if (!\defined('ABSPATH')) {
    exit;
}


use BitApps\Pi\src\Integrations\ApiRequest\ApiRequestAction;

class AutomatorWpAction extends ApiRequestAction
{
    // extends ApiRequestAction
}
