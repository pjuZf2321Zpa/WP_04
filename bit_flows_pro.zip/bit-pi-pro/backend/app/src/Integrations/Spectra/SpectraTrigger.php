<?php

namespace BitApps\PiPro\src\Integrations\Spectra;

// Prevent direct script access
if (!\defined('ABSPATH')) {
    exit;
}


use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;

class SpectraTrigger
{
    public static function spectraHandler(...$args)
    {
        $flows = FlowService::exists('spectra', 'spectraFormSubmit');

        IntegrationHelper::handleFlowForForm($flows, $args);
    }
}
