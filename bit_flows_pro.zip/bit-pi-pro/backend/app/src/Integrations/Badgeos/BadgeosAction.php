<?php

namespace BitApps\PiPro\src\Integrations\Badgeos;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;

if (!\defined('ABSPATH')) {
    exit;
}

class BadgeosAction implements ActionInterface
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeBadgeosAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'] ?? 200,
            $executedNodeAction['payload'] ?? [],
            $executedNodeAction['response'] ?? []
        );
    }

    private function executeBadgeosAction()
    {
        if (!class_exists('BadgeOS')) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('BadgeOS plugin is not active.', 'bit-pi'),
            ];
        }

        $badgeosService = new BadgeosService($this->nodeInfoProvider);

        $machineSlug = $this->nodeInfoProvider->getMachineSlug();

        if (!method_exists($badgeosService, $machineSlug)) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('BadgeOS action not found.', 'bit-pi'),
            ];
        }

        return $badgeosService->{$machineSlug}();
    }
}
