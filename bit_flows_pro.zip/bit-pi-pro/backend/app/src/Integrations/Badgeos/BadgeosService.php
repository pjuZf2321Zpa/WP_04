<?php

namespace BitApps\PiPro\src\Integrations\Badgeos;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\PiPro\Deps\BitApps\WPValidator\Validator;

if (!\defined('ABSPATH')) {
    exit;
}

final class BadgeosService
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function awardAchievementToUser()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'user_id'        => ['required', 'integer'],
            'achievement_id' => ['required', 'integer'],
        ];

        $errors = self::validateFieldMap($fieldMappings, $rules);

        if ($errors) {
            return $errors;
        }

        $userId = \intval($fieldMappings['user_id']);
        $achievementId = \intval($fieldMappings['achievement_id']);

        if (empty(Utility::getUserInfo($userId))) {
            return [
                'response'    => __('User not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400
            ];
        }

        if (!\function_exists('badgeos_award_achievement_to_user') || !\function_exists('badgeos_get_user_achievements')) {
            return [
                'response'    => __('BadgeOS plugin is not active.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400
            ];
        }

        if (!badgeos_is_achievement($achievementId)) {
            return [
                'response'    => __('Failed to award achievement. Please check if the achievement ID is valid.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400
            ];
        }

        badgeos_award_achievement_to_user($achievementId, $userId);

        return [
            'response'    => badgeos_get_user_achievements(['user_id' => $userId]),
            'payload'     => $fieldMappings,
            'status_code' => 200
        ];
    }

    public static function validateFieldMap($fieldMappings, $validationRules, $payload = null)
    {
        $validator = new Validator();
        $validation = $validator->make($fieldMappings, $validationRules);

        if ($validation->fails()) {
            return [
                'response'    => $validation->errors(),
                'payload'     => $payload ?? $fieldMappings,
                'status_code' => 400
            ];
        }
    }
}
