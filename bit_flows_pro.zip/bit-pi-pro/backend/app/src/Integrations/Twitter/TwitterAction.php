<?php

namespace BitApps\PiPro\src\Integrations\Twitter;

// Prevent direct script access
if (!defined('ABSPATH')) {
    exit;
}

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Authorization\AuthorizationFactory;
use BitApps\Pi\src\Authorization\AuthorizationType;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Client\HttpClient;
use InvalidArgumentException;

class TwitterAction implements ActionInterface
{
    private const CREATE_TWEET = 'createTweet';

    private const DELETE_TWEET = 'deleteTweet';

    private const LIKE_TWEET = 'likeTweet';

    private const RETWEET_POST = 'retweetPost';

    private const REPLY_TO_TWEET = 'replyToTweet';

    private const FOLLOW_USER = 'followUser';

    private const SEND_DM = 'sendDm';

    private const SEARCH_TWEETS = 'searchTweets';

    private NodeInfoProvider $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $machineSlug = $this->nodeInfoProvider->getMachineSlug();
        $connectionId = $this->nodeInfoProvider->getFieldMapConfigs('connection-id.value');

        if (!$connectionId) {
            return Utility::formatResponseData(
                401,
                [],
                ['error' => 'No connection selected'],
                __('No connection selected for X (Twitter).', 'bit-pi')
            );
        }

        $accessToken = AuthorizationFactory::getAuthorizationHandler(
            AuthorizationType::CUSTOM,
            (int) $connectionId,
            'twitter'
        )->getAccessToken();

        if (\is_array($accessToken) && isset($accessToken['error'])) {
            return Utility::formatResponseData(
                401,
                [],
                $accessToken,
                $accessToken['message'] ?? __('Failed to authenticate with X (Twitter). Reconnect your account.', 'bit-pi')
            );
        }

        $service = new TwitterService(new HttpClient(), (string) $accessToken);

        return $this->executeAction($machineSlug, $service);
    }

    private function executeAction(string $machineSlug, TwitterService $service): array
    {
        $fieldMapData = $this->nodeInfoProvider->getFieldMapData();

        switch ($machineSlug) {
            case self::CREATE_TWEET:
                return $service->createTweet($fieldMapData);

            case self::DELETE_TWEET:
                return $service->deleteTweet($fieldMapData);

            case self::LIKE_TWEET:
                return $service->likeTweet($fieldMapData);

            case self::RETWEET_POST:
                return $service->retweetPost($fieldMapData);

            case self::REPLY_TO_TWEET:
                return $service->replyToTweet($fieldMapData);

            case self::FOLLOW_USER:
                return $service->followUser($fieldMapData);

            case self::SEND_DM:
                return $service->sendDm($fieldMapData);

            case self::SEARCH_TWEETS:
                return $service->searchTweets($fieldMapData);

            default:
                throw new InvalidArgumentException('Unknown Twitter machine slug: ' . $machineSlug);
        }
    }
}
