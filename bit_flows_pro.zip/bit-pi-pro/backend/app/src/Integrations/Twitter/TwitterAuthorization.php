<?php

namespace BitApps\PiPro\src\Integrations\Twitter;

use BitApps\Pi\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\Pi\Helpers\Hash;
use BitApps\Pi\src\Authorization\AbstractBaseAuthorization;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * X (Twitter) is a confidential OAuth2 client: the token endpoint requires HTTP
 * Basic auth — base64(client_id:client_secret) — in the Authorization header and
 * rejects client_secret sent in the body. The shared OAuth2Authorization refresh
 * sends the secret in the body with no header, so X returns
 * "unauthorized_client / Missing valid authorization header". This handler
 * refreshes the access token the way X expects.
 */
class TwitterAuthorization extends AbstractBaseAuthorization
{
    private const TOKEN_URL = 'https://api.x.com/2/oauth2/token';

    public function getAccessToken()
    {
        $connection = $this->getConnection();

        if (!$connection) {
            return [
                'error'   => true,
                'message' => 'Connection not found',
            ];
        }

        $authDetails = (array) $connection->auth_details;

        $accessToken = $this->decrypt($authDetails['access_token'] ?? '');
        $generatedAt = $authDetails['generated_at'] ?? 0;
        $expiresIn = (int) ($authDetails['expires_in'] ?? 0);

        if ($accessToken !== '' && !$this->isTokenExpired($generatedAt, $expiresIn)) {
            return 'Bearer ' . $accessToken;
        }

        return $this->refreshAccessToken($connection, $authDetails);
    }

    private function refreshAccessToken($connection, array $authDetails)
    {
        $clientId = $authDetails['client_id'] ?? '';
        $clientSecret = $this->decrypt($authDetails['client_secret'] ?? '');
        $refreshToken = $this->decrypt($authDetails['refresh_token'] ?? '');

        if ($clientId === '' || $clientSecret === '' || $refreshToken === '') {
            return [
                'error'   => true,
                'message' => 'Missing X (Twitter) OAuth credentials for token refresh.',
            ];
        }

        $body = http_build_query(
            [
                'grant_type'    => 'refresh_token',
                'refresh_token' => $refreshToken,
                'client_id'     => $clientId,
            ]
        );

        $headers = [
            'Authorization' => 'Basic ' . base64_encode($clientId . ':' . $clientSecret),
            'Content-Type'  => 'application/x-www-form-urlencoded',
        ];

        $response = $this->http->request(self::TOKEN_URL, 'POST', $body, $headers);
        $data = (object) (\is_string($response) ? JSON::maybeDecode($response) : $response);

        if ($this->http->getResponseCode() !== 200 || isset($data->error) || !isset($data->access_token)) {
            return [
                'error'    => true,
                'message'  => $data->error_description ?? $data->error ?? 'X (Twitter) token refresh failed',
                'response' => $data,
            ];
        }

        $authDetails['access_token'] = Hash::encrypt($data->access_token);
        if (isset($data->refresh_token)) {
            $authDetails['refresh_token'] = Hash::encrypt($data->refresh_token);
        }
        $authDetails['expires_in'] = $data->expires_in ?? 7200;
        $authDetails['generated_at'] = time();

        $update = $this->updateConnection($connection, $authDetails);
        if (isset($update['error'])) {
            return $update;
        }

        return 'Bearer ' . $data->access_token;
    }

    private function decrypt($value): string
    {
        if (!\is_string($value) || $value === '') {
            return '';
        }

        return (string) Hash::decrypt($value);
    }
}
