<?php

namespace BitApps\PiPro\src\Integrations\Twitter;

// Prevent direct script access
if (!defined('ABSPATH')) {
    exit;
}

use BitApps\Pi\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\Pi\Helpers\Utility;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Client\HttpClient;

final class TwitterService
{
    private const BASE_URL = 'https://api.x.com/2';

    private HttpClient $http;

    private string $accessToken;

    public function __construct(HttpClient $httpClient, string $accessToken)
    {
        $this->http = $httpClient;
        $this->accessToken = $accessToken;
    }

    public function createTweet(array $fieldMapData): array
    {
        $payload = ['text' => $fieldMapData['text'] ?? ''];

        $response = $this->post('/tweets', $payload);

        return Utility::formatResponseData($this->http->getResponseCode(), $payload, $response);
    }

    public function deleteTweet(array $fieldMapData): array
    {
        $tweetId = $fieldMapData['tweetId'] ?? '';
        $payload = ['tweetId' => $tweetId];

        $response = $this->request('DELETE', "/tweets/{$tweetId}", []);

        return Utility::formatResponseData($this->http->getResponseCode(), $payload, $response);
    }

    public function likeTweet(array $fieldMapData): array
    {
        return $this->postAsUser('likes', ['tweet_id' => $fieldMapData['tweetId'] ?? '']);
    }

    public function retweetPost(array $fieldMapData): array
    {
        return $this->postAsUser('retweets', ['tweet_id' => $fieldMapData['tweetId'] ?? '']);
    }

    public function replyToTweet(array $fieldMapData): array
    {
        $payload = [
            'text'  => $fieldMapData['text'] ?? '',
            'reply' => [
                'in_reply_to_tweet_id' => $fieldMapData['tweetId'] ?? '',
            ],
        ];

        $response = $this->post('/tweets', $payload);

        return Utility::formatResponseData($this->http->getResponseCode(), $payload, $response);
    }

    public function followUser(array $fieldMapData): array
    {
        return $this->postAsUser('following', ['target_user_id' => $fieldMapData['targetUserId'] ?? '']);
    }

    public function sendDm(array $fieldMapData): array
    {
        $participantId = $fieldMapData['participantId'] ?? '';
        $payload = ['text' => $fieldMapData['message'] ?? ''];

        $response = $this->post("/dm_conversations/with/{$participantId}/messages", $payload);

        return Utility::formatResponseData($this->http->getResponseCode(), $payload, $response);
    }

    public function searchTweets(array $fieldMapData): array
    {
        $query = $fieldMapData['query'] ?? '';
        $maxResults = isset($fieldMapData['maxResults']) && $fieldMapData['maxResults'] !== ''
            ? (int) $fieldMapData['maxResults']
            : 10;

        $queryParams = http_build_query(
            [
                'query'       => $query,
                'max_results' => $maxResults,
            ]
        );

        $response = $this->request('GET', "/tweets/search/recent?{$queryParams}", []);

        return Utility::formatResponseData(
            $this->http->getResponseCode(),
            ['query' => $query, 'maxResults' => $maxResults],
            $response
        );
    }

    private function getAuthenticatedUserId(): string
    {
        $response = $this->request('GET', '/users/me', []);
        $decoded = (array) JSON::maybeDecode($response, true);
        $data = (array) ($decoded['data'] ?? []);

        return (string) ($data['id'] ?? '');
    }

    /**
     * POST to an endpoint scoped to the authenticated user
     * (e.g. /users/{id}/likes). Resolves the user id once and guards against
     * an unresolved id before calling the API.
     */
    private function postAsUser(string $segment, array $payload): array
    {
        $userId = $this->getAuthenticatedUserId();
        if ($userId === '') {
            return Utility::formatResponseData(400, $payload, ['error' => 'Could not resolve the authenticated X user.']);
        }

        $response = $this->post("/users/{$userId}/{$segment}", $payload);

        return Utility::formatResponseData($this->http->getResponseCode(), $payload, $response);
    }

    private function post(string $path, array $body): mixed
    {
        return $this->request('POST', $path, $body);
    }

    private function request(string $method, string $path, array $body): mixed
    {
        $headers = [
            'Authorization' => $this->accessToken,
            'Content-Type'  => 'application/json',
        ];

        return $this->http->request(
            self::BASE_URL . $path,
            $method,
            $method !== 'GET' ? JSON::encode($body) : null,
            $headers
        );
    }
}
