<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\PiPro\src\Integrations\MailPoet\MailPoetHelper;
use BitApps\PiPro\src\Integrations\MailPoet\MailPoetTrigger;

Route::group(
    function () {
        Route::get('mailpoet/get', [MailPoetTrigger::class, 'getAll']);
        Route::post('mailpoet/get_lists', [MailPoetHelper::class, 'getLists']);
        Route::get('mailpoet/get_subscriber_fields', [MailPoetHelper::class, 'getSubscriberFields']);
    }
)->middleware('nonce:admin');
