<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\PiPro\src\Integrations\FluentCart\FluentCartHelper;

Route::group(
    function () {
        Route::get('fluent-cart/customers', [FluentCartHelper::class, 'getCustomers']);
        Route::get('fluent-cart/products', [FluentCartHelper::class, 'getProducts']);
        Route::get('fluent-cart/product-categories', [FluentCartHelper::class, 'getProductCategories']);
        Route::get('fluent-cart/product-brands', [FluentCartHelper::class, 'getProductBrands']);
        Route::get('fluent-cart/shipping-class', [FluentCartHelper::class, 'getShippingClass']);
    }
)->middleware('nonce:admin');
