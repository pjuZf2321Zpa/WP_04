<?php

namespace BitApps\PiPro\src\Integrations\WpCafe;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;
use BitApps\PiPro\src\Integrations\WpCafe\helper\WpCafeHelper;

if (!\defined('ABSPATH')) {
    exit;
}

class WpCafeAction implements ActionInterface
{
    private NodeInfoProvider $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeWpCafeAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'] ?? 200,
            $executedNodeAction['payload'] ?? [],
            $executedNodeAction['response'] ?? []
        );
    }

    private function executeWpCafeAction()
    {
        if (!WpCafeHelper::isPluginInstalled()) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('WP Cafe plugin is not active.', 'bit-pi'),
            ];
        }

        $wpCafeServices = new WpCafeServices($this->nodeInfoProvider);

        $machineSlug = $this->nodeInfoProvider->getMachineSlug();

        if (!method_exists($wpCafeServices, $machineSlug)) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('WP Cafe action not found.', 'bit-pi'),
            ];
        }

        return $wpCafeServices->{$machineSlug}();
    }
}
