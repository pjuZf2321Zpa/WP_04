<?php

namespace BitApps\PiPro\src\Integrations\WpCafe;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!\defined('ABSPATH')) {
    exit;
}

class WpCafeHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'reservationCreated' => [
                'hook'     => 'wpcafe_after_reservation_create',
                'callback' => [WpCafeTrigger::class, 'reservationCreated'],
                'priority' => 20,
            ],
            'reservationUpdated' => [
                'hook'     => 'wpcafe_after_reservation_update',
                'callback' => [WpCafeTrigger::class, 'reservationUpdated'],
                'priority' => 20,
            ],
            'reservationDeleted' => [
                'hook'     => 'wpcafe_after_reservation_delete',
                'callback' => [WpCafeTrigger::class, 'reservationDeleted'],
                'priority' => 20,
            ],
            'reservationCancelled' => [
                'hook'     => 'wpcafe_after_reservation_cancelled',
                'callback' => [WpCafeTrigger::class, 'reservationCancelled'],
                'priority' => 20,
            ],
            'reservationNotificationCreated' => [
                'hook'          => 'global_notification_hook',
                'callback'      => [WpCafeTrigger::class, 'reservationNotificationCreated'],
                'priority'      => 20,
                'accepted_args' => 2,
            ],
            'reservationNotificationCancelled' => [
                'hook'          => 'global_notification_hook',
                'callback'      => [WpCafeTrigger::class, 'reservationNotificationCancelled'],
                'priority'      => 20,
                'accepted_args' => 2,
            ],
            'orderNotificationCreated' => [
                'hook'          => 'global_notification_hook',
                'callback'      => [WpCafeTrigger::class, 'orderNotificationCreated'],
                'priority'      => 20,
                'accepted_args' => 2,
            ],
        ];
    }
}
