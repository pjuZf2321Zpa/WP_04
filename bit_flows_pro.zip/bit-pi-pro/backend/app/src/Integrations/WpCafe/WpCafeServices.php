<?php

namespace BitApps\PiPro\src\Integrations\WpCafe;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\PiPro\src\Integrations\WpCafe\helper\WpCafeHelper;
use WpCafe\Models\Location_Model;
use WpCafe\Models\Reservation_Model;
use WpCafe\Resources\Reservation_Resource;

if (!\defined('ABSPATH')) {
    exit;
}

final class WpCafeServices
{
    private NodeInfoProvider $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    /**
     * Create Reservation.
     *
     * @return array
     */
    public function createReservation()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapRepeaters('field-map.value', false, true, 'wpCafeField', 'value');

        $rules = [
            'name'        => ['required', 'string'],
            'email'       => ['required', 'email'],
            'phone'       => ['required', 'string'],
            'date'        => ['required', 'string'],
            'start_time'  => ['required', 'string'],
            'total_guest' => ['required', 'integer'],
        ];

        $validationErrors = WpCafeHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $capacityValidation = Reservation_Model::validate_guest_capacity(
            $fieldMappings['total_guest'] ?? 1,
            $fieldMappings['date'] ?? '',
            $fieldMappings['start_time'] ?? '',
            $fieldMappings['end_time'] ?? '',
            $fieldMappings['branch_id'] ?? ''
        );

        if (is_wp_error($capacityValidation)) {
            return [
                'response'    => $capacityValidation->get_error_message(),
                'payload'     => $fieldMappings,
                'status_code' => 400
            ];
        }

        $fieldMappings['invoice'] = 'WPC' . wp_rand(1000, 9999);

        $reservation = Reservation_Model::create($fieldMappings);
        if (is_wp_error($reservation)) {
            return [
                'response'    => $reservation->get_error_message(),
                'payload'     => $fieldMappings,
                'status_code' => 400
            ];
        }

        if (\function_exists('WC') && WC()->session) {
            $this->setSessionData($reservation);
        }

        $response = new Reservation_Resource($reservation);

        do_action('wpcafe_after_reservation_create', $reservation);

        return [
            'response'    => Utility::jsonEncodeDecode($response),
            'payload'     => $fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Update Reservation.
     *
     * @return array
     */
    public function updateReservation()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'reservation_id' => ['required', 'integer'],
        ];

        $errors = WpCafeHelper::validateFieldMap($fieldMappings, $rules);

        if ($errors) {
            return $errors;
        }

        $reservation = Reservation_Model::find($fieldMappings['reservation_id']);

        if (!$reservation) {
            return [
                'response'    => __('Reservation not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404
            ];
        }

        unset($fieldMappings['reservation_id']);

        $oldStatus = $reservation->status;
        $updated = $reservation->update($fieldMappings);

        if (!$updated) {
            return [
                'response'    => __('Failed to update reservation.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400
            ];
        }

        if ($oldStatus !== 'cancelled' && $reservation->status === 'cancelled') {
            do_action('wpcafe_after_reservation_cancelled', $reservation);
        }

        do_action('wpcafe_after_reservation_update', $reservation);

        return [
            'response'    => Utility::jsonEncodeDecode($reservation),
            'payload'     => $fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Delete Reservation.
     *
     * @return array
     */
    public function deleteReservation()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = ['reservation_id' => ['required', 'integer']];

        $errors = WpCafeHelper::validateFieldMap($fieldMappings, $rules);

        if ($errors) {
            return $errors;
        }

        $reservation = Reservation_Model::find($fieldMappings['reservation_id']);

        if (!$reservation) {
            return [
                'response'    => __('Reservation not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404
            ];
        }

        $deleted = $reservation->delete();

        if (!$deleted) {
            return [
                'response'    => __('Failed to delete reservation.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400
            ];
        }

        do_action('wpcafe_after_reservation_delete', $deleted);

        return [
            'response'    => Utility::jsonEncodeDecode($deleted),
            'payload'     => $fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Get Reservation by ID.
     *
     * @return array
     */
    public function getReservationById()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = ['reservation_id' => ['required', 'integer']];

        $errors = WpCafeHelper::validateFieldMap($fieldMappings, $rules);

        if ($errors) {
            return $errors;
        }

        $reservation = Reservation_Model::find($fieldMappings['reservation_id']);

        if (!$reservation) {
            return [
                'response'    => __('Reservation not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404
            ];
        }

        return [
            'response'    => Utility::jsonEncodeDecode($reservation),
            'payload'     => $fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Get All Reservations.
     *
     * @return array
     */
    public function getAllReservations()
    {
        $reservations = Reservation_Model::all();

        return [
            'response'    => Utility::jsonEncodeDecode($reservations),
            'payload'     => [],
            'status_code' => 200
        ];
    }

    /**
     * Get All Locations.
     *
     * @return array
     */
    public function getAllLocations()
    {
        $locations = Location_Model::all();

        return [
            'response'    => Utility::jsonEncodeDecode($locations),
            'payload'     => [],
            'status_code' => 200
        ];
    }

    /**
     * Set reservation data in WooCommerce session.
     *
     * @param object $reservation
     */
    private function setSessionData($reservation)
    {
        $sessionData = [
            'reservation_id'   => $reservation->id,
            'reservation_date' => $reservation->date ?? '',
            'start_time'       => $reservation->start_time ?? '',
            'end_time'         => $reservation->end_time ?? '',
            'name'             => $reservation->name ?? '',
            'email'            => $reservation->email ?? '',
            'phone'            => $reservation->phone ?? '',
            'total_guest'      => $reservation->total_guest ?? '',
            'notes'            => $reservation->notes ?? '',
            'branch_name'      => $reservation->branch_name ?? ''
        ];

        // Add custom fields if they exist
        if (!empty($reservation->custom_fields)) {
            $sessionData['custom_fields'] = $reservation->custom_fields;
        }

        WC()->session->set('wpc_reservation_data', $sessionData);
    }
}
