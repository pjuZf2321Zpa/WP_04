<?php

namespace BitApps\PiPro\src\Integrations\WpCafe;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;

if (!\defined('ABSPATH')) {
    exit;
}

final class WpCafeTrigger
{
    public static function reservationCreated($reservation)
    {
        $reservationData = Utility::jsonEncodeDecode($reservation);

        self::execute($reservationData, __FUNCTION__);
    }

    public static function reservationUpdated($reservation)
    {
        $reservationData = Utility::jsonEncodeDecode($reservation);

        self::execute($reservationData, __FUNCTION__);
    }

    public static function reservationDeleted($reservation)
    {
        if (is_numeric($reservation)) {
            $reservation = ['id' => $reservation];
        }

        $reservationData = Utility::jsonEncodeDecode($reservation);

        self::execute($reservationData, __FUNCTION__);
    }

    public static function reservationCancelled($reservation)
    {
        $reservationData = Utility::jsonEncodeDecode($reservation);

        self::execute($reservationData, __FUNCTION__);
    }

    public static function reservationNotificationCreated($eventType, $notificationData)
    {
        self::executeOnEventTypeMatch($eventType, $notificationData, 'reservation_created', __FUNCTION__);
    }

    public static function reservationNotificationCancelled($eventType, $notificationData)
    {
        self::executeOnEventTypeMatch($eventType, $notificationData, 'reservation_cancelled', __FUNCTION__);
    }

    public static function orderNotificationCreated($eventType, $notificationData)
    {
        self::executeOnEventTypeMatch($eventType, $notificationData, 'order_created', __FUNCTION__);
    }

    private static function executeOnEventTypeMatch($eventType, $notificationData, $expectedEventType, $machineSlug)
    {
        if ($eventType !== $expectedEventType) {
            return;
        }

        self::execute($notificationData, $machineSlug);
    }

    private static function execute($data, $machineSlug)
    {
        if (empty($data)) {
            return;
        }

        $flows = FlowService::exists('wpCafe', $machineSlug);

        if (!$flows) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $data);
    }
}
