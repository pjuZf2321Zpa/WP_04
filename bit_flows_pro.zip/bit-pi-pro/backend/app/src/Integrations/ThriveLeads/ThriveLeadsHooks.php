<?php

namespace BitApps\PiPro\src\Integrations\ThriveLeads;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!\defined('ABSPATH')) {
    exit;
}

class ThriveLeadsHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'formSubmitted' => [
                'hook'     => 'tcb_api_form_submit',
                'callback' => [ThriveLeadsTrigger::class, 'formSubmitted'],
            ],
            'registrationFormSubmitted' => [
                'hook'          => 'thrive_register_form_through_wordpress_user',
                'callback'      => [ThriveLeadsTrigger::class, 'registrationFormSubmitted'],
                'accepted_args' => 2,
            ],
        ];
    }
}
