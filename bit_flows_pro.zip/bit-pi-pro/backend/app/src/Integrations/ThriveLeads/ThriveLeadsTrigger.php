<?php

namespace BitApps\PiPro\src\Integrations\ThriveLeads;

use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;

if (!\defined('ABSPATH')) {
    exit;
}

class ThriveLeadsTrigger
{
    public static function formSubmitted($data)
    {
        if (empty($data)) {
            return;
        }

        self::execute(__FUNCTION__, $data);
    }

    public static function registrationFormSubmitted($userId, $data)
    {
        if (empty($data)) {
            return;
        }

        $data['user_id'] = $userId;

        self::execute(__FUNCTION__, $data);
    }

    private static function execute($machineSlug, $data)
    {
        $flows = FlowService::exists('thriveLeads', $machineSlug);
        if (!$flows) {
            return;
        }

        $sanitizedData = self::sanitizeData($data);

        IntegrationHelper::handleFlowForForm($flows, $sanitizedData);
    }

    private static function sanitizeData($data)
    {
        unset($data['password'], $data['confirm_password']);

        return $data;
    }
}
