<?php

namespace BitApps\PiPro\src\Integrations\Wsms\helper;

use WP_SMS\Newsletter;

if (!defined('ABSPATH')) {
    exit;
}

final class WsmsHelper
{
    public static function isPluginInstalled()
    {
        return defined('WP_SMS_VERSION');
    }

    public static function extractObjectAttributes($object)
    {
        if (!\is_object($object)) {
            return $object;
        }

        if (method_exists($object, 'getAttributes')) {
            return $object->getAttributes();
        }

        if (method_exists($object, 'toArray')) {
            return $object->toArray();
        }

        return get_object_vars($object);
    }

    /**
     * Trigger payload: SMS sent / logged (wp_sms_log_after_save).
     *
     * @param mixed $result
     * @param mixed $sender
     * @param mixed $message
     * @param mixed $to
     * @param mixed $response
     * @param mixed $status
     * @param mixed $media
     */
    public static function getSmsSentData($result, $sender, $message, $to, $response, $status, $media)
    {
        return [
            'result'     => $result,
            'sender'     => $sender,
            'message'    => $message,
            'recipient'  => \is_array($to) ? implode(',', $to) : $to,
            'recipients' => $to,
            'response'   => self::extractObjectAttributes($response),
            'status'     => $status,
            'media'      => $media,
        ];
    }

    /**
     * Trigger payload: subscriber added (wp_sms_add_subscriber).
     *
     * @param mixed $name
     * @param mixed $mobile
     * @param mixed $status
     * @param mixed $subscriberId
     */
    public static function getSubscriberAddedData($name, $mobile, $status, $subscriberId)
    {
        return self::buildSubscriberData(
            [
                'subscriber_id' => $subscriberId,
                'name'          => $name,
                'mobile'        => $mobile,
                'status'        => $status,
            ],
            $subscriberId
        );
    }

    /**
     * Trigger payload: subscriber verified (wp_sms_verify_subscriber).
     *
     * @param mixed $name
     * @param mixed $mobile
     * @param mixed $activation
     * @param mixed $subscriberId
     */
    public static function getSubscriberVerifiedData($name, $mobile, $activation, $subscriberId)
    {
        return self::buildSubscriberData(
            [
                'subscriber_id' => $subscriberId,
                'name'          => $name,
                'mobile'        => $mobile,
                'activation'    => $activation,
            ],
            $subscriberId
        );
    }

    /**
     * Trigger payload: number unsubscribed via URL (wp_sms_number_unsubscribed_through_url).
     *
     * @param mixed $number
     */
    public static function getNumberUnsubscribedData($number)
    {
        return ['number' => $number];
    }

    /**
     * Trigger payload: OTP generated (wp_sms_otp_generated).
     *
     * @param mixed $code
     * @param mixed $phoneNumber
     * @param mixed $agent
     */
    public static function getOtpGeneratedData($code, $phoneNumber, $agent)
    {
        return [
            'otp'          => $code,
            'phone_number' => $phoneNumber,
            'agent'        => $agent,
        ];
    }

    /**
     * Dropdown list: subscriber groups.
     */
    public static function getAllGroups()
    {
        if (!self::isPluginInstalled() || !class_exists('\WP_SMS\Newsletter')) {
            return [];
        }

        $groups = Newsletter::getGroups();
        $result = [];

        foreach ($groups ?: [] as $group) {
            $result[] = [
                'label' => $group->name,
                'value' => (int) $group->ID,
            ];
        }

        return $result;
    }

    /**
     * Dropdown list: subscribers.
     */
    public static function getAllSubscribers()
    {
        global $wpdb;

        if (!self::isPluginInstalled()) {
            return [];
        }

        // Newest subscribers first (by ID) for the dropdown.
        $table = $wpdb->prefix . 'sms_subscribes';
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name only, no user input
        $subscribers = $wpdb->get_results("SELECT ID, name, mobile FROM `{$table}` ORDER BY ID DESC");
        $result = [];

        foreach ($subscribers ?: [] as $subscriber) {
            $label = trim(\sprintf('%s (%s)', $subscriber->name ?? '', $subscriber->mobile ?? ''));

            $result[] = [
                'label' => $label !== '' ? $label : 'Subscriber #' . $subscriber->ID,
                'value' => (int) $subscriber->ID,
            ];
        }

        return $result;
    }

    private static function buildSubscriberData(array $data, $subscriberId)
    {
        if ($subscriberId && class_exists('\WP_SMS\Newsletter')) {
            $subscriber = Newsletter::getSubscriber($subscriberId);

            if ($subscriber) {
                $data['subscriber'] = self::extractObjectAttributes($subscriber);
            }
        }

        return $data;
    }
}
