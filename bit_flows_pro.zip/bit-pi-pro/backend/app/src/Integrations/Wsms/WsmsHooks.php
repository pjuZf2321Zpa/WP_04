<?php

namespace BitApps\PiPro\src\Integrations\Wsms;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!defined('ABSPATH')) {
    exit;
}

class WsmsHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'smsSent' => [
                'hook'          => 'wp_sms_log_after_save',
                'callback'      => [WsmsTrigger::class, 'smsSent'],
                'accepted_args' => 7,
            ],
            'subscriberAdded' => [
                'hook'          => 'wp_sms_add_subscriber',
                'callback'      => [WsmsTrigger::class, 'subscriberAdded'],
                'accepted_args' => 4,
            ],
            'subscriberVerified' => [
                'hook'          => 'wp_sms_verify_subscriber',
                'callback'      => [WsmsTrigger::class, 'subscriberVerified'],
                'accepted_args' => 4,
            ],
            'numberUnsubscribed' => [
                'hook'     => 'wp_sms_number_unsubscribed_through_url',
                'callback' => [WsmsTrigger::class, 'numberUnsubscribed'],
            ],
            'otpGenerated' => [
                'hook'          => 'wp_sms_otp_generated',
                'callback'      => [WsmsTrigger::class, 'otpGenerated'],
                'accepted_args' => 3,
            ],
        ];
    }
}
