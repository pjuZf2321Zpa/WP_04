<?php

namespace BitApps\PiPro\src\Integrations\Wsms;

use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\Wsms\helper\WsmsHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class WsmsTrigger
{
    public static function smsSent($result, $sender, $message, $to, $response, $status, $media)
    {
        $data = WsmsHelper::getSmsSentData($result, $sender, $message, $to, $response, $status, $media);

        self::execute('smsSent', $data);
    }

    public static function subscriberAdded($name, $mobile, $status, $subscriberId)
    {
        $data = WsmsHelper::getSubscriberAddedData($name, $mobile, $status, $subscriberId);

        self::execute('subscriberAdded', $data);
    }

    public static function subscriberVerified($name, $mobile, $activation, $subscriberId)
    {
        $data = WsmsHelper::getSubscriberVerifiedData($name, $mobile, $activation, $subscriberId);

        self::execute('subscriberVerified', $data);
    }

    public static function numberUnsubscribed($number)
    {
        $data = WsmsHelper::getNumberUnsubscribedData($number);

        self::execute('numberUnsubscribed', $data);
    }

    public static function otpGenerated($code, $phoneNumber, $agent)
    {
        $data = WsmsHelper::getOtpGeneratedData($code, $phoneNumber, $agent);

        self::execute('otpGenerated', $data);
    }

    private static function execute($machineSlug, $data)
    {
        if (!WsmsHelper::isPluginInstalled()) {
            return;
        }

        $flows = FlowService::exists('wsms', $machineSlug);

        if (!$flows || empty($data)) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $data);
    }
}
