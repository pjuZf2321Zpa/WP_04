<?php

namespace BitApps\PiPro\src\Integrations\Wsms;

use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\Wsms\helper\WsmsHelper;
use WP_SMS\Gateway;
use WP_SMS\Newsletter;

if (!defined('ABSPATH')) {
    exit;
}

final class WsmsService
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    /**
     * Send an SMS (or MMS) through the active WSMS gateway.
     *
     * @return array
     */
    public function sendSms()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationErrors = IntegrationHelper::validateFieldMap(
            $fieldMappings,
            [
                'to'      => ['required', 'string'],
                'message' => ['required', 'string'],
            ]
        );

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('wp_sms_send')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Required WSMS function is missing.', 'bit-pi'),
            ];
        }

        $recipients = $this->splitList($fieldMappings['to']);

        if (empty($recipients)) {
            return [
                'status_code' => 422,
                'payload'     => $fieldMappings,
                'response'    => __('At least one valid recipient number is required.', 'bit-pi'),
            ];
        }

        $isFlash = $this->toBool($fieldMappings['is_flash'] ?? false);
        $from = !empty($fieldMappings['sender_id']) ? $fieldMappings['sender_id'] : null;
        $mediaUrls = [];

        if (!empty($fieldMappings['media_urls'])) {
            $mediaUrls = array_values(array_filter(array_map('esc_url_raw', $this->splitList($fieldMappings['media_urls']))));
        }

        $response = wp_sms_send(
            $recipients,
            $fieldMappings['message'],
            $isFlash,
            $from,
            $mediaUrls
        );

        if (is_wp_error($response)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => $response->get_error_message(),
            ];
        }

        // Not every gateway returns a WP_Error on failure — some return false or
        // an empty payload. Treat a falsy/empty response as a failed send.
        if ($response === false || $response === null || $response === '' || $response === []) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('The SMS gateway did not confirm delivery.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => WsmsHelper::extractObjectAttributes($response),
        ];
    }

    /**
     * Add a newsletter subscriber.
     *
     * @return array
     */
    public function addSubscriber()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationErrors = IntegrationHelper::validateFieldMap(
            $fieldMappings,
            [
                'name'   => ['required', 'string'],
                'mobile' => ['required', 'string'],
            ]
        );

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $error = $this->ensureNewsletterAvailable();
        if ($error) {
            return $error;
        }

        $result = Newsletter::addSubscriber(
            $fieldMappings['name'],
            $fieldMappings['mobile'],
            $this->resolveGroupId($fieldMappings),
            $this->resolveStatus($fieldMappings)
        );

        return $this->normalizePluginResult($result, $fieldMappings, __('Failed to add subscriber.', 'bit-pi'));
    }

    /**
     * Update an existing newsletter subscriber.
     *
     * @return array
     */
    public function updateSubscriber()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationErrors = IntegrationHelper::validateFieldMap(
            $fieldMappings,
            [
                'subscriber_id' => ['required', 'integer'],
                'name'          => ['required', 'string'],
                'mobile'        => ['required', 'string'],
            ]
        );

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $error = $this->ensureNewsletterAvailable();
        if ($error) {
            return $error;
        }

        $subscriberId = (int) $fieldMappings['subscriber_id'];
        $existing = Newsletter::getSubscriber($subscriberId);

        if (!$existing) {
            return [
                'status_code' => 422,
                'payload'     => $fieldMappings,
                'response'    => __('Subscriber not found.', 'bit-pi'),
            ];
        }

        // Preserve the subscriber's current group/status when those optional
        // fields are left unmapped — otherwise the plugin overwrites them
        // (blanking the group, forcing the status to Active).
        $groupId = isset($fieldMappings['group_id']) && $fieldMappings['group_id'] !== ''
            ? (int) $fieldMappings['group_id']
            : ($existing->group_ID ?? '');

        $status = isset($fieldMappings['status']) && $fieldMappings['status'] !== ''
            ? $fieldMappings['status']
            : ($existing->status ?? '1');

        $result = Newsletter::updateSubscriber(
            $subscriberId,
            $fieldMappings['name'],
            $fieldMappings['mobile'],
            $groupId,
            $status
        );

        return $this->normalizePluginResult($result, $fieldMappings, __('Failed to update subscriber.', 'bit-pi'));
    }

    /**
     * Delete a subscriber by mobile number.
     *
     * @return array
     */
    public function deleteSubscriber()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationErrors = IntegrationHelper::validateFieldMap(
            $fieldMappings,
            [
                'mobile' => ['required', 'string'],
            ]
        );

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $error = $this->ensureNewsletterAvailable();
        if ($error) {
            return $error;
        }

        // deleteSubscriberByNumber() routes the group id through processGroupId(),
        // which json_decode()s it and requires an array — a plain int yields a
        // WP_Error. Pass the JSON-array shape the plugin expects.
        $groupId = !empty($fieldMappings['group_id'])
            ? wp_json_encode([(int) $fieldMappings['group_id']])
            : null;

        $result = Newsletter::deleteSubscriberByNumber(
            $fieldMappings['mobile'],
            $groupId
        );

        return $this->normalizePluginResult($result, $fieldMappings, __('Failed to delete subscriber.', 'bit-pi'));
    }

    /**
     * Add a subscriber group.
     *
     * @return array
     */
    public function addGroup()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationErrors = IntegrationHelper::validateFieldMap(
            $fieldMappings,
            [
                'name' => ['required', 'string'],
            ]
        );

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $error = $this->ensureNewsletterAvailable();
        if ($error) {
            return $error;
        }

        $result = Newsletter::addGroup($fieldMappings['name']);

        return $this->normalizePluginResult($result, $fieldMappings, __('Failed to add group.', 'bit-pi'));
    }

    /**
     * Update a subscriber group.
     *
     * @return array
     */
    public function updateGroup()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationErrors = IntegrationHelper::validateFieldMap(
            $fieldMappings,
            [
                'group_id' => ['required', 'integer'],
                'name'     => ['required', 'string'],
            ]
        );

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $error = $this->ensureNewsletterAvailable();
        if ($error) {
            return $error;
        }

        $result = Newsletter::updateGroup(
            (int) $fieldMappings['group_id'],
            $fieldMappings['name']
        );

        return $this->normalizePluginResult($result, $fieldMappings, __('Failed to update group.', 'bit-pi'));
    }

    /**
     * Delete a subscriber group.
     *
     * @return array
     */
    public function deleteGroup()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationErrors = IntegrationHelper::validateFieldMap(
            $fieldMappings,
            [
                'group_id' => ['required', 'integer'],
            ]
        );

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $error = $this->ensureNewsletterAvailable();
        if ($error) {
            return $error;
        }

        $result = Newsletter::deleteGroup((int) $fieldMappings['group_id']);

        if (empty($result)) {
            return [
                'status_code' => 422,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to delete group, or the group does not exist.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'message'  => __('Group deleted successfully.', 'bit-pi'),
                'group_id' => (int) $fieldMappings['group_id'],
            ],
        ];
    }

    /**
     * Get a single subscriber by ID.
     *
     * @return array
     */
    public function getSubscriber()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationErrors = IntegrationHelper::validateFieldMap(
            $fieldMappings,
            [
                'subscriber_id' => ['required', 'integer'],
            ]
        );

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $error = $this->ensureNewsletterAvailable();
        if ($error) {
            return $error;
        }

        $subscriber = Newsletter::getSubscriber((int) $fieldMappings['subscriber_id']);

        if (!$subscriber) {
            return [
                'status_code' => 422,
                'payload'     => $fieldMappings,
                'response'    => __('Subscriber not found.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => WsmsHelper::extractObjectAttributes($subscriber),
        ];
    }

    /**
     * Get subscriber(s) matching a mobile number.
     *
     * @return array
     */
    public function getSubscriberByMobile()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationErrors = IntegrationHelper::validateFieldMap(
            $fieldMappings,
            [
                'mobile' => ['required', 'string'],
            ]
        );

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $error = $this->ensureNewsletterAvailable();
        if ($error) {
            return $error;
        }

        $subscribers = Newsletter::getSubscriberByMobile($fieldMappings['mobile'], false);

        if (empty($subscribers)) {
            return [
                'status_code' => 422,
                'payload'     => $fieldMappings,
                'response'    => __('No subscriber found for the given mobile number.', 'bit-pi'),
            ];
        }

        // getSubscriberByMobile($single=false) merges exact + normalized matches
        // without dedup, so the same row can appear twice — dedup by ID here.
        $data = [];
        $seen = [];

        foreach ($subscribers as $subscriber) {
            $row = WsmsHelper::extractObjectAttributes($subscriber);
            $id = \is_array($row) ? ($row['ID'] ?? null) : null;

            if (empty($id) || isset($seen[$id])) {
                continue;
            }

            $seen[$id] = true;
            $data[] = $row;
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'subscribers' => $data,
                'count'       => \count($data),
            ],
        ];
    }

    /**
     * List subscribers, optionally filtered by group and active status.
     *
     * @return array
     */
    public function getSubscribers()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $error = $this->ensureNewsletterAvailable();
        if ($error) {
            return $error;
        }

        $groupIds = !empty($fieldMappings['group_id']) ? [(int) $fieldMappings['group_id']] : null;
        $onlyActive = $this->toBool($fieldMappings['only_active'] ?? false);
        $columns = ['ID', 'name', 'mobile', 'status', 'group_ID', 'date'];

        $subscribers = Newsletter::getSubscribers($groupIds, $onlyActive, $columns);
        $data = array_map([WsmsHelper::class, 'extractObjectAttributes'], $subscribers ?: []);

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'subscribers' => $data,
                'count'       => \count($data),
            ],
        ];
    }

    /**
     * Get a single subscriber group by ID.
     *
     * @return array
     */
    public function getGroup()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationErrors = IntegrationHelper::validateFieldMap(
            $fieldMappings,
            [
                'group_id' => ['required', 'integer'],
            ]
        );

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $error = $this->ensureNewsletterAvailable();
        if ($error) {
            return $error;
        }

        $group = Newsletter::getGroup((int) $fieldMappings['group_id']);

        if (!$group) {
            return [
                'status_code' => 422,
                'payload'     => $fieldMappings,
                'response'    => __('Group not found.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => WsmsHelper::extractObjectAttributes($group),
        ];
    }

    /**
     * List all subscriber groups.
     *
     * @return array
     */
    public function getGroups()
    {
        $error = $this->ensureNewsletterAvailable();
        if ($error) {
            return $error;
        }

        $groups = Newsletter::getGroups();
        $data = array_map([WsmsHelper::class, 'extractObjectAttributes'], $groups ?: []);

        return [
            'status_code' => 200,
            'payload'     => [],
            'response'    => [
                'groups' => $data,
                'count'  => \count($data),
            ],
        ];
    }

    /**
     * Count subscribers, optionally within a group.
     *
     * @return array
     */
    public function getSubscriberCount()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $error = $this->ensureNewsletterAvailable();
        if ($error) {
            return $error;
        }

        $groupId = !empty($fieldMappings['group_id']) ? (int) $fieldMappings['group_id'] : null;
        $total = Newsletter::getTotal($groupId);

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'count'    => (int) $total,
                'group_id' => $groupId,
            ],
        ];
    }

    /**
     * Get the groups a mobile number is subscribed to.
     *
     * @return array
     */
    public function getSubscriberGroupsByNumber()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationErrors = IntegrationHelper::validateFieldMap(
            $fieldMappings,
            [
                'mobile' => ['required', 'string'],
            ]
        );

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $error = $this->ensureNewsletterAvailable();
        if ($error) {
            return $error;
        }

        $groups = Newsletter::getSubscriberGroupsByNumber(
            $fieldMappings['mobile'],
            $this->toBool($fieldMappings['only_active'] ?? false)
        );

        if (is_wp_error($groups)) {
            return [
                'status_code' => 422,
                'payload'     => $fieldMappings,
                'response'    => $groups->get_error_message(),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'groups' => $groups,
                'count'  => \is_array($groups) ? \count($groups) : 0,
            ],
        ];
    }

    /**
     * Get the current SMS gateway credit / balance.
     *
     * @return array
     */
    public function getSmsBalance()
    {
        if (!class_exists('\WP_SMS\Gateway')) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('Required WSMS Gateway class is missing.', 'bit-pi'),
            ];
        }

        $credit = Gateway::credit();

        if (is_wp_error($credit)) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => $credit->get_error_message(),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => [],
            'response'    => ['balance' => WsmsHelper::extractObjectAttributes($credit)],
        ];
    }

    private function ensureNewsletterAvailable(): ?array
    {
        if (!class_exists('\WP_SMS\Newsletter')) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('Required WSMS Newsletter class is missing.', 'bit-pi'),
            ];
        }

        return null;
    }

    /**
     * WSMS Newsletter methods return ['result' => 'success'|'error', 'message' => ...].
     *
     * @param mixed $result
     * @param mixed $fallbackMessage
     */
    private function normalizePluginResult($result, array $fieldMappings, $fallbackMessage)
    {
        if (\is_array($result) && 'success' === ($result['result'] ?? '')) {
            return [
                'status_code' => 200,
                'payload'     => $fieldMappings,
                'response'    => $result,
            ];
        }

        $message = \is_array($result) && !empty($result['message']) ? $result['message'] : $fallbackMessage;

        // WSMS returns "No change has been occurred." when an update matched the
        // row but changed nothing (idempotent no-op) — surface that as success.
        if (\is_string($message) && stripos($message, 'No change') !== false) {
            return [
                'status_code' => 200,
                'payload'     => $fieldMappings,
                'response'    => ['message' => $message, 'changed' => false],
            ];
        }

        return [
            'status_code' => 422,
            'payload'     => $fieldMappings,
            'response'    => $message,
        ];
    }

    private function resolveGroupId(array $fieldMappings)
    {
        return !empty($fieldMappings['group_id']) ? (int) $fieldMappings['group_id'] : '';
    }

    private function resolveStatus(array $fieldMappings)
    {
        return isset($fieldMappings['status']) && $fieldMappings['status'] !== ''
            ? $fieldMappings['status']
            : '1';
    }

    private function toBool($value)
    {
        return \in_array($value, ['1', 1, true, 'true', 'yes'], true);
    }

    /**
     * Split a comma / newline separated string into trimmed values. Splits only
     * on commas and line breaks — NOT on internal whitespace — so a single number
     * formatted with spaces (e.g. "+1 555 123 4567") stays one recipient.
     *
     * @param mixed $value
     *
     * @return array
     */
    private function splitList($value)
    {
        if (\is_array($value)) {
            return array_values(array_filter(array_map('trim', $value)));
        }

        $parts = preg_split('/[,\r\n]+/', (string) $value);

        return array_values(array_filter(array_map('trim', $parts ?: [])));
    }
}
