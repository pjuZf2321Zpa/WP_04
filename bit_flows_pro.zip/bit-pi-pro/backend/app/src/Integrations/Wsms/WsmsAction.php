<?php

namespace BitApps\PiPro\src\Integrations\Wsms;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\Pi\src\Interfaces\ActionInterface;
use BitApps\PiPro\src\Integrations\Wsms\helper\WsmsHelper;

if (!defined('ABSPATH')) {
    exit;
}

class WsmsAction implements ActionInterface
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeWsmsAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'] ?? 200,
            $executedNodeAction['payload'] ?? [],
            $executedNodeAction['response'] ?? []
        );
    }

    private function executeWsmsAction()
    {
        if (!WsmsHelper::isPluginInstalled()) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('WSMS (WP SMS) plugin is not active.', 'bit-pi'),
            ];
        }

        $machineSlug = $this->nodeInfoProvider->getMachineSlug();
        $wsmsService = IntegrationHelper::getServiceInstanceByMachineSlug($machineSlug, $this->nodeInfoProvider, true);

        if (empty($wsmsService)) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('WSMS service not found.', 'bit-pi'),
            ];
        }

        return $wsmsService->{$machineSlug}();
    }
}
