<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\PiPro\src\Integrations\Wsms\helper\WsmsHelper;

Route::group(
    function () {
        Route::get('wsms/get-groups', [WsmsHelper::class, 'getAllGroups']);
        Route::get('wsms/get-subscribers', [WsmsHelper::class, 'getAllSubscribers']);
    }
)->middleware('nonce:admin');
