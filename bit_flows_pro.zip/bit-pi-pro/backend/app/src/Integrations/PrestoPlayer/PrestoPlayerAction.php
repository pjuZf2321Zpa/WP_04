<?php

namespace BitApps\PiPro\src\Integrations\PrestoPlayer;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;
use BitApps\PiPro\src\Integrations\PrestoPlayer\helper\PrestoPlayerHelper;

if (!\defined('ABSPATH')) {
    exit;
}

class PrestoPlayerAction implements ActionInterface
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executePrestoPlayerAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'] ?? 200,
            $executedNodeAction['payload'] ?? [],
            $executedNodeAction['response'] ?? []
        );
    }

    private function executePrestoPlayerAction()
    {
        if (!PrestoPlayerHelper::isPluginInstalled()) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('Presto Player plugin is not active.', 'bit-pi'),
            ];
        }

        $prestoPlayerService = new PrestoPlayerService($this->nodeInfoProvider);

        $machineSlug = $this->nodeInfoProvider->getMachineSlug();

        if (!method_exists($prestoPlayerService, $machineSlug)) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('Presto Player action not found.', 'bit-pi'),
            ];
        }

        return $prestoPlayerService->{$machineSlug}();
    }
}
