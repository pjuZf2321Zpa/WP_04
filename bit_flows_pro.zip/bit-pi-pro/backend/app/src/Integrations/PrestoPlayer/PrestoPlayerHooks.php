<?php

namespace BitApps\PiPro\src\Integrations\PrestoPlayer;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!\defined('ABSPATH')) {
    exit;
}

class PrestoPlayerHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'videoCompleted' => [
                'hook'          => 'presto_player_progress',
                'callback'      => [PrestoPlayerTrigger::class, 'videoCompleted'],
                'accepted_args' => 3,
            ],
            'videoWatched' => [
                'hook'          => 'presto_player_progress',
                'callback'      => [PrestoPlayerTrigger::class, 'videoWatched'],
                'accepted_args' => 3,
            ],
        ];
    }
}
