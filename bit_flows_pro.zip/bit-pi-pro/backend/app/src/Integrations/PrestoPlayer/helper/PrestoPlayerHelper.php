<?php

namespace BitApps\PiPro\src\Integrations\PrestoPlayer\helper;

use BitApps\PiPro\Deps\BitApps\WPValidator\Validator;

if (!\defined('ABSPATH')) {
    exit;
}

final class PrestoPlayerHelper
{
    /**
     * Check if Presto Player plugin is installed.
     *
     * @return bool
     */
    public static function isPluginInstalled()
    {
        return \function_exists('presto_player_plugin');
    }

    /**
     * Validate field map.
     *
     * @param array $fieldMappings
     * @param array $validationRules
     * @param null|array $payload
     *
     * @return null|array
     */
    public static function validateFieldMap($fieldMappings, $validationRules, $payload = null)
    {
        $validator = new Validator();
        $validation = $validator->make($fieldMappings, $validationRules);

        if ($validation->fails()) {
            return [
                'response'    => $validation->errors(),
                'payload'     => $payload ?? $fieldMappings,
                'status_code' => 400
            ];
        }
    }
}
