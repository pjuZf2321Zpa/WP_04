<?php

namespace BitApps\PiPro\src\Integrations\PrestoPlayer;

use BitApps\Pi\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\PiPro\src\Integrations\PrestoPlayer\helper\PrestoPlayerHelper;

if (!\defined('ABSPATH')) {
    exit;
}

final class PrestoPlayerService
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    /**
     * Create Media Hub.
     *
     * @return array
     */
    public function createMediaHub()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'media_hub_title' => ['required', 'string'],
            'post_author_id'  => ['required', 'integer']
        ];

        $validationError = PrestoPlayerHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validationError)) {
            return $validationError;
        }

        $title = $fieldMappings['media_hub_title'];
        $postAuthorId = absint($fieldMappings['post_author_id']);

        $videoUrl = key_exists('media_hub_youtube_video_url', $fieldMappings) ? $fieldMappings['media_hub_youtube_video_url'] : '';
        $basicVideoUrl = key_exists('media_hub_video_url', $fieldMappings) ? $fieldMappings['media_hub_video_url'] : '';
        $preset = key_exists('video_preset', $fieldMappings) ? $fieldMappings['video_preset'] : 4;

        if (empty($videoUrl) && empty($basicVideoUrl)) {
            return [
                'response'    => __('Either YouTube video URL or Video URL must be provided.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400
            ];
        }

        $mediaHubPost = [];

        if (!empty($videoUrl)) {
            $mediaHubPost = self::prepareYoutubeVideoData($videoUrl, $title, $preset, $postAuthorId);
        }

        if (!empty($basicVideoUrl)) {
            $mediaHubPost = self::prepareSelfHostedVideoData($basicVideoUrl, $title, $preset, $postAuthorId);
        }

        if (empty($mediaHubPost)) {
            return [
                'response'    => __('Invalid video URL provided.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400
            ];
        }

        $postId = wp_insert_post($mediaHubPost);

        if (is_wp_error($postId)) {
            return [
                'response'    => $postId->get_error_message() ?? __('There was an error creating the media hub.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400
            ];
        }

        $post = get_post($postId);

        return [
            'response' => [
                'post_id'     => $postId,
                'post_title'  => $post->post_title,
                'post_type'   => $post->post_type,
                'post_status' => $post->post_status,
                'post_url'    => get_permalink($postId)
            ],
            'payload'     => $fieldMappings,
            'status_code' => 200
        ];
    }

    private static function prepareYoutubeVideoData($videoUrl, $postTitle, $preset, $postAuthorId)
    {
        $pattern = '/(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]*\/\S+\/|(?:v|e(?:mbed)?)\/?|(?:watch\?v=))|youtu\.be\/)([a-zA-Z0-9_-]+)/';
        $videoUrl = esc_url_raw($videoUrl);

        if (filter_var($videoUrl, FILTER_VALIDATE_URL) === false || preg_match($pattern, $videoUrl, $matches) !== 1) {
            return;
        }

        $videoId = $matches[1];
        $blockData = [
            'id'       => 1,
            'src'      => esc_url($videoUrl),
            'preset'   => absint($preset),
            'video_id' => $videoId
        ];

        $postContent = '<!-- wp:presto-player/reusable-edit -->
                <div class="wp-block-presto-player-reusable-edit">
                <!-- wp:presto-player/youtube ' . JSON::encode($blockData) . ' /-->
                </div><!-- /wp:presto-player/reusable-edit -->';

        return [
            'post_title'   => $postTitle,
            'post_content' => $postContent,
            'post_status'  => 'publish',
            'post_type'    => 'pp_video_block',
            'post_author'  => $postAuthorId,
        ];
    }

    private static function prepareSelfHostedVideoData($videoUrl, $postTitle, $preset, $postAuthorId)
    {
        if (filter_var($videoUrl, FILTER_VALIDATE_URL) === false) {
            return;
        }

        $postContent = '<!-- wp:presto-player/reusable-edit -->
            <div class="wp-block-presto-player-reusable-edit">
            <!-- wp:presto-player/self-hosted {"id":1,"attachment_id":null,"src":"' . esc_url($videoUrl) . '","preset":' . absint($preset) . '} /-->
            </div><!-- /wp:presto-player/reusable-edit -->';

        return [
            'post_title'   => $postTitle,
            'post_content' => $postContent,
            'post_status'  => 'publish',
            'post_type'    => 'pp_video_block',
            'post_author'  => $postAuthorId,
        ];
    }
}
