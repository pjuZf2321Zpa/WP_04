<?php

namespace BitApps\PiPro\src\Integrations\PrestoPlayer;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use PrestoPlayer\Models\Video;

if (!\defined('ABSPATH')) {
    exit;
}

final class PrestoPlayerTrigger
{
    public static function videoCompleted($videoId, $percent, $visitTime)
    {
        self::handleVideoProgress($videoId, $percent, $visitTime, 'videoCompleted');
    }

    public static function videoWatched($videoId, $percent, $visitTime)
    {
        self::handleVideoProgress($videoId, $percent, $visitTime, 'videoWatched');
    }

    public static function handleVideoProgress($videoId, $percent, $visitTime, $MachineSlug)
    {
        if (empty($videoId) || empty($percent) || ($MachineSlug === 'videoCompleted' && $percent < 100)) {
            return;
        }

        $flows = FlowService::exists('prestoPlayer', $MachineSlug);

        if (!$flows) {
            return;
        }

        $data = self::prepareVideoData($videoId, $percent, $visitTime);

        if (empty($data)) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $data);
    }

    private static function prepareVideoData($videoId, $percent, $visitTime)
    {
        if (!class_exists('PrestoPlayer\Models\Video')) {
            return [];
        }

        $userId = get_current_user_id();

        $data = [
            'user_id'          => $userId,
            'video_id'         => $videoId,
            'video_percentage' => $percent,
            'visit_time'       => $visitTime,
            'user_data'        => Utility::getUserInfo($userId),
        ];

        $video = new Video($videoId);
        $data['video'] = $video->toArray();


        if (isset($data['video']['post_id'])) {
            $postId = $data['video']['post_id'];

            $data['post'] = get_post($postId);
            $data['media_tags'] = get_the_terms($postId, 'pp_video_tag') ?? [];
        }

        return $data;
    }
}
