<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\PiPro\src\Integrations\WpErp\WpErpHelper;

Route::group(
    function () {
        Route::get('wperp/contact-groups', [WpErpHelper::class, 'getContactGroups']);
        Route::get('wperp/life-stages', [WpErpHelper::class, 'getLifeStages']);
        Route::get('wperp/contact-fields', [WpErpHelper::class, 'getContactFields']);
        Route::get('wperp/company-fields', [WpErpHelper::class, 'getCompanyFields']);
        Route::get('wperp/employee-fields', [WpErpHelper::class, 'getEmployeeFields']);
        Route::get('wperp/departments', [WpErpHelper::class, 'getDepartments']);
        Route::get('wperp/designations', [WpErpHelper::class, 'getDesignations']);
        Route::get('wperp/employees', [WpErpHelper::class, 'getEmployees']);
        Route::get('wperp/contacts', [WpErpHelper::class, 'getContacts']);
        Route::get('wperp/companies', [WpErpHelper::class, 'getCompanies']);
    }
)->middleware('nonce:admin');
