<?php

namespace BitApps\PiPro\src\Integrations\WpErp\Services;

use BitApps\PiPro\src\Integrations\WpErp\WpErpHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class HrmService extends BaseService
{
    public function createEmployee()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapRepeaters('field-map.value', false, true, 'erpField', 'value');
        $fields = $this->nodeInfoProvider->getFieldMapData();

        if (!empty($fields['department'])) {
            $fieldMappings['department'] = $fields['department'];
        }

        if (!empty($fields['designation'])) {
            $fieldMappings['designation'] = $fields['designation'];
        }

        $rules = [
            'first_name' => ['required', 'string'],
            'last_name'  => ['required', 'string'],
            'user_email' => ['required', 'email'],
        ];

        if (empty($fields['user_email']) && !empty($fields['email'])) {
            $fieldMappings['user_email'] = $fields['email'];
        }

        $validationErrors = $this->validateFieldMap($fieldMappings, $rules);
        if ($validationErrors) {
            return $validationErrors;
        }
        $validationErrors = $this->validateFunctionExists('erp_hr_employee_create', $fieldMappings);
        if ($validationErrors) {
            return $validationErrors;
        }

        $userId = erp_hr_employee_create($fieldMappings);

        $errorResponse = WpErpHelper::getWpErrorResponse($userId, $fieldMappings);
        if ($errorResponse) {
            return $errorResponse;
        }

        if (\is_string($userId)) {
            return [
                'response'    => $userId,
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        return [
            'response'    => ['user_id' => $userId],
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function updateEmployee()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapRepeaters('field-map.value', false, true, 'erpField', 'value');
        $fields = $this->nodeInfoProvider->getFieldMapData();
        $fieldMappings['user_id'] = $fields['user_id'] ?? null;

        if (isset($fields['department'])) {
            $fieldMappings['department'] = $fields['department'];
        }

        if (isset($fields['designation'])) {
            $fieldMappings['designation'] = $fields['designation'];
        }

        $validationErrors = $this->validateFieldMap($fieldMappings, ['user_id' => ['required', 'integer']]);
        if ($validationErrors) {
            return $validationErrors;
        }
        $validationErrors = $this->validateFunctionExists('erp_hr_employee_create', $fieldMappings);
        if ($validationErrors) {
            return $validationErrors;
        }

        $userId = erp_hr_employee_create($fieldMappings);

        $errorResponse = WpErpHelper::getWpErrorResponse($userId, $fieldMappings);
        if ($errorResponse) {
            return $errorResponse;
        }

        return [
            'response'    => ['user_id' => $userId],
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function getAllEmployees()
    {
        $validationErrors = $this->validateFunctionExists('erp_hr_get_employees');
        if ($validationErrors) {
            return $validationErrors;
        }

        $employees = erp_hr_get_employees(['number' => -1]);

        return [
            'response'    => array_map([WpErpHelper::class, 'normalizeData'], (array) $employees),
            'payload'     => [],
            'status_code' => 200,
        ];
    }

    public function getEmployeeById()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationErrors = $this->validateFieldMap(
            $fieldMappings,
            ['user_id' => ['required', 'integer']]
        );

        if ($validationErrors) {
            return $validationErrors;
        }
        $validationErrors = $this->validateFunctionExists('erp_hr_get_employee', $fieldMappings);
        if ($validationErrors) {
            return $validationErrors;
        }

        $employee = erp_hr_get_employee($fieldMappings['user_id']);

        return [
            'response'    => WpErpHelper::normalizeData($employee),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function createDepartment()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        if (empty($fieldMappings['lead'])) {
            $fieldMappings['lead'] = 0;
        }
        if (empty($fieldMappings['parent'])) {
            $fieldMappings['parent'] = 0;
        }

        $validationErrors = $this->validateFieldMap($fieldMappings, ['title' => ['required', 'string']]);
        if ($validationErrors) {
            return $validationErrors;
        }
        $validationErrors = $this->validateFunctionExists('erp_hr_create_department', $fieldMappings);
        if ($validationErrors) {
            return $validationErrors;
        }

        $departmentId = erp_hr_create_department($fieldMappings);

        $errorResponse = WpErpHelper::getWpErrorResponse($departmentId, $fieldMappings);
        if ($errorResponse) {
            return $errorResponse;
        }

        return [
            'response'    => ['department_id' => $departmentId],
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function createDesignation()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationErrors = $this->validateFieldMap($fieldMappings, ['title' => ['required', 'string']]);
        if ($validationErrors) {
            return $validationErrors;
        }
        $validationErrors = $this->validateFunctionExists('erp_hr_create_designation', $fieldMappings);
        if ($validationErrors) {
            return $validationErrors;
        }

        $designationId = erp_hr_create_designation($fieldMappings);

        $errorResponse = WpErpHelper::getWpErrorResponse($designationId, $fieldMappings);
        if ($errorResponse) {
            return $errorResponse;
        }

        return [
            'response'    => ['designation_id' => $designationId],
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function createHoliday()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'title' => ['required', 'string'],
            'start' => ['required'],
            'end'   => ['required'],
        ];

        $validationErrors = $this->validateFieldMap($fieldMappings, $rules);
        if ($validationErrors) {
            return $validationErrors;
        }
        $validationErrors = $this->validateFunctionExists('erp_hr_leave_insert_holiday', $fieldMappings);
        if ($validationErrors) {
            return $validationErrors;
        }

        $holidayId = erp_hr_leave_insert_holiday($fieldMappings);

        $errorResponse = WpErpHelper::getWpErrorResponse($holidayId, $fieldMappings);
        if ($errorResponse) {
            return $errorResponse;
        }

        return [
            'response'    => ['holiday_id' => $holidayId],
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }
}
