<?php

namespace BitApps\PiPro\src\Integrations\WpErp\Services;

use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\PiPro\Deps\BitApps\WPValidator\Validator;
use BitApps\PiPro\src\Integrations\WpErp\WpErpHelper;

if (!defined('ABSPATH')) {
    exit;
}

abstract class BaseService
{
    protected $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    /**
     * Validate required WP ERP function(s) exist before usage.
     *
     * @param array|string $functionNames
     * @param array        $payload
     * @param mixed $requiresCrm
     * @param mixed $isAccounting
     *
     * @return null|array
     */
    protected function validateFunctionExists($functionNames, $payload = [], $requiresCrm = false, $isAccounting = false)
    {
        if (!\is_array($functionNames)) {
            $functionNames = [$functionNames];
        }

        foreach ($functionNames as $functionName) {
            if (\function_exists($functionName)) {
                continue;
            }

            if ($isAccounting) {
                return [
                    'response'    => __('WP ERP Accounting module is not available', 'bit-pi'),
                    'payload'     => $payload,
                    'status_code' => 400,
                ];
            }

            if ($requiresCrm && !WpErpHelper::isCrmActive()) {
                return [
                    'response'    => __('WP ERP CRM module is not available', 'bit-pi'),
                    'payload'     => $payload,
                    'status_code' => 400,
                ];
            }

            return [
                'response' => \sprintf(
                    // translators: %s: WP ERP function name.
                    __('Required WP ERP function %s is not available', 'bit-pi'),
                    $functionName
                ),
                'payload'     => $payload,
                'status_code' => 400,
            ];
        }
    }

    /**
     * Validate field mapping data against provided rules.
     *
     * @param array $fieldMappings
     * @param array $validationRules
     * @param array $payload
     *
     * @return null|array
     */
    protected function validateFieldMap($fieldMappings, $validationRules, $payload = null)
    {
        $validator = new Validator();
        $validation = $validator->make($fieldMappings, $validationRules);

        if ($validation->fails()) {
            return [
                'response'    => $validation->errors(),
                'payload'     => $payload ?? $fieldMappings,
                'status_code' => 400,
            ];
        }
    }
}
