<?php

namespace BitApps\PiPro\src\Integrations\WpErp\Services;

use BitApps\PiPro\Deps\BitApps\WPKit\Hooks\Hooks;
use BitApps\PiPro\src\Integrations\WpErp\WpErpHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class CrmService extends BaseService
{
    public function createContact()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapRepeaters('field-map.value', false, true, 'erpField', 'value');
        $fields = $this->nodeInfoProvider->getFieldMapData();

        if (isset($fields['life_stage'])) {
            $fieldMappings['life_stage'] = $fields['life_stage'];
        }

        $fieldMappings['type'] = 'contact';

        $rules = [
            'first_name' => ['required', 'string'],
            'email'      => ['required', 'email'],
        ];

        $validationErrors = $this->validateFieldMap($fieldMappings, $rules);
        if ($validationErrors) {
            return $validationErrors;
        }
        $validationErrors = $this->validateFunctionExists('erp_insert_people', $fieldMappings);
        if ($validationErrors) {
            return $validationErrors;
        }

        $result = erp_insert_people($fieldMappings);

        $errorResponse = WpErpHelper::getWpErrorResponse($result, $fieldMappings);
        if ($errorResponse) {
            return $errorResponse;
        }

        $contactId = \is_object($result) ? $result->id : $result;

        if (isset($fields['group_id']) && !empty($contactId) && \function_exists('erp_crm_create_new_contact_subscriber')) {
            foreach ((array) $fields['group_id'] as $groupId) {
                erp_crm_create_new_contact_subscriber(
                    [
                        'group_id' => $groupId,
                        'user_id'  => $contactId,
                    ]
                );
            }
        }

        return [
            'response'    => (array) WpErpHelper::fetchDataByField($contactId),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function updateContact()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapRepeaters('field-map.value', false, true, 'erpField', 'value');
        $fields = $this->nodeInfoProvider->getFieldMapData();

        if (isset($fields['life_stage'])) {
            $fieldMappings['life_stage'] = $fields['life_stage'];
        }

        $fieldMappings['id'] = $fields['contact_id'] ?? null;
        $fieldMappings['type'] = 'contact';

        $validationErrors = $this->validateFieldMap($fieldMappings, ['id' => ['required']]);
        if ($validationErrors) {
            return $validationErrors;
        }
        $validationErrors = $this->validateFunctionExists('erp_insert_people', $fieldMappings);
        if ($validationErrors) {
            return $validationErrors;
        }

        $result = erp_insert_people($fieldMappings);

        $errorResponse = WpErpHelper::getWpErrorResponse($result, $fieldMappings);
        if ($errorResponse) {
            return $errorResponse;
        }

        $id = \is_object($result) ? $result->id : $result;

        return [
            'response'    => (array) WpErpHelper::fetchDataByField($id),
            'payload'     => $fields,
            'status_code' => 200,
        ];
    }

    public function deleteContact()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $payload = [
            'id'   => $fieldMappings['contact_id'] ?? null,
            'hard' => !empty($fieldMappings['force_delete']),
            'type' => 'contact'
        ];

        $validationErrors = $this->validateFieldMap(
            $payload,
            ['id' => ['required', 'integer']]
        );

        if ($validationErrors) {
            return $validationErrors;
        }

        $validationErrors = $this->validateFunctionExists('erp_delete_people', $payload);
        if ($validationErrors) {
            return $validationErrors;
        }

        $result = erp_delete_people($payload);

        $errorResponse = WpErpHelper::getWpErrorResponse($result, $payload);
        if ($errorResponse) {
            return $errorResponse;
        }

        return [
            'response'    => __('Contact deleted successfully.', 'bit-pi'),
            'payload'     => $payload,
            'status_code' => 200,
        ];
    }

    public function getAllContacts()
    {
        $validationErrors = $this->validateFunctionExists('erp_get_peoples');
        if ($validationErrors) {
            return $validationErrors;
        }

        $contacts = erp_get_peoples(['type' => 'contact', 'number' => -1]);

        return [
            'response'    => array_map([WpErpHelper::class, 'normalizeData'], (array) $contacts),
            'payload'     => [],
            'status_code' => 200,
        ];
    }

    public function getContactById()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $validationErrors = $this->validateFieldMap(
            $fieldMappings,
            ['id' => ['required', 'integer']]
        );

        if ($validationErrors) {
            return $validationErrors;
        }
        $validationErrors = $this->validateFunctionExists('erp_get_people_by', $fieldMappings);
        if ($validationErrors) {
            return $validationErrors;
        }

        return [
            'response'    => WpErpHelper::fetchDataByField($fieldMappings['id']),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function getContactByEmail()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $validationErrors = $this->validateFieldMap(
            $fieldMappings,
            ['email' => ['required', 'email']]
        );

        if ($validationErrors) {
            return $validationErrors;
        }
        $validationErrors = $this->validateFunctionExists('erp_get_people_by', $fieldMappings);
        if ($validationErrors) {
            return $validationErrors;
        }

        return [
            'response'    => WpErpHelper::fetchDataByField($fieldMappings['email'], 'email'),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function createCompany()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapRepeaters('field-map.value', false, true, 'erpField', 'value');
        $fieldMappings['type'] = 'company';

        $rules = [
            'company' => ['required', 'string'],
            'email'   => ['required', 'email'],
        ];

        $validationErrors = $this->validateFieldMap($fieldMappings, $rules);
        if ($validationErrors) {
            return $validationErrors;
        }
        $validationErrors = $this->validateFunctionExists('erp_insert_people', $fieldMappings);
        if ($validationErrors) {
            return $validationErrors;
        }

        $result = erp_insert_people($fieldMappings);

        $errorResponse = WpErpHelper::getWpErrorResponse($result, $fieldMappings);
        if ($errorResponse) {
            return $errorResponse;
        }

        $companyId = \is_object($result) ? $result->id : $result;

        return [
            'response'    => (array) WpErpHelper::fetchDataByField($companyId),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function updateCompany()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapRepeaters('field-map.value', false, true, 'erpField', 'value');
        $fields = $this->nodeInfoProvider->getFieldMapData();

        $fieldMappings['id'] = $fields['company_id'] ?? null;
        $fieldMappings['type'] = 'company';

        $validationErrors = $this->validateFieldMap(
            $fieldMappings,
            ['id' => ['required', 'integer']]
        );

        if ($validationErrors) {
            return $validationErrors;
        }

        $validationErrors = $this->validateFunctionExists('erp_insert_people', $fieldMappings);
        if ($validationErrors) {
            return $validationErrors;
        }

        $result = erp_insert_people($fieldMappings);

        $errorResponse = WpErpHelper::getWpErrorResponse($result, $fieldMappings);
        if ($errorResponse) {
            return $errorResponse;
        }

        $id = \is_object($result) ? $result->id : $result;

        return [
            'response'    => (array) WpErpHelper::fetchDataByField($id),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function deleteCompany()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $payload = [
            'id'   => $fieldMappings['company_id'] ?? null,
            'hard' => !empty($fieldMappings['force_delete']),
            'type' => 'company'
        ];

        $validationErrors = $this->validateFieldMap(
            $payload,
            ['id' => ['required', 'integer']]
        );

        if ($validationErrors) {
            return $validationErrors;
        }
        $validationErrors = $this->validateFunctionExists('erp_delete_people', $payload);
        if ($validationErrors) {
            return $validationErrors;
        }

        $result = erp_delete_people($payload);

        $errorResponse = WpErpHelper::getWpErrorResponse($result, $payload);
        if ($errorResponse) {
            return $errorResponse;
        }

        return [
            'response'    => __('Company deleted successfully.', 'bit-pi'),
            'payload'     => $payload,
            'status_code' => 200
        ];
    }

    public function getAllCompanies()
    {
        $validationErrors = $this->validateFunctionExists('erp_get_peoples');
        if ($validationErrors) {
            return $validationErrors;
        }

        $companies = erp_get_peoples(['type' => 'company', 'number' => -1]);

        return [
            'response'    => array_map([WpErpHelper::class, 'normalizeData'], (array) $companies),
            'payload'     => [],
            'status_code' => 200,
        ];
    }

    public function createContactGroup()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $rules = ['name' => ['required', 'string']];

        $validationErrors = $this->validateFieldMap($fieldMappings, $rules);
        if ($validationErrors) {
            return $validationErrors;
        }
        $validationErrors = $this->validateFunctionExists('erp_crm_save_contact_group', $fieldMappings, true);
        if ($validationErrors) {
            return $validationErrors;
        }

        $result = erp_crm_save_contact_group($fieldMappings);

        return [
            'response'    => WpErpHelper::normalizeData($result),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function getAllContactGroups()
    {
        $validationErrors = $this->validateFunctionExists('erp_crm_get_contact_groups', [], true);
        if ($validationErrors) {
            return $validationErrors;
        }

        $groups = erp_crm_get_contact_groups(['number' => -1]);

        return [
            'response'    => array_map([WpErpHelper::class, 'normalizeData'], (array) $groups),
            'payload'     => [],
            'status_code' => 200,
        ];
    }

    public function addContactToGroup()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $rules = [
            'contact_id' => ['required', 'integer'],
            'group_id'   => ['required']
        ];

        $validationErrors = $this->validateFieldMap($fieldMappings, $rules);
        if ($validationErrors) {
            return $validationErrors;
        }
        $validationErrors = $this->validateFunctionExists('erp_crm_create_new_contact_subscriber', $fieldMappings, true);
        if ($validationErrors) {
            return $validationErrors;
        }

        $results = [];
        $groupIds = $this->normalizeGroupIds($fieldMappings['group_id']);

        foreach ($groupIds as $groupId) {
            $result = erp_crm_create_new_contact_subscriber(
                [
                    'group_id' => $groupId,
                    'user_id'  => $fieldMappings['contact_id'],
                ]
            );

            if (is_wp_error($result)) {
                $results[] = ['group_id' => $groupId, 'error' => $result->get_error_message()];

                continue;
            }

            $results[] = WpErpHelper::normalizeData($result);
        }

        return [
            'response'    => $results,
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function removeContactFromGroup()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        if (!WpErpHelper::isCrmActive()) {
            return [
                'response'    => __('WP ERP CRM module is not available', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        $rules = [
            'contact_id' => ['required', 'integer'],
            'group_id'   => ['required']
        ];

        $validationErrors = $this->validateFieldMap($fieldMappings, $rules);
        if ($validationErrors) {
            return $validationErrors;
        }

        global $wpdb;

        $results = [];
        $groupIds = $this->normalizeGroupIds($fieldMappings['group_id']);

        foreach ((array) $groupIds as $groupId) {
            $deleted = $wpdb->delete(
                $wpdb->prefix . 'erp_crm_contact_subscriber',
                ['user_id' => $fieldMappings['contact_id'], 'group_id' => $groupId],
                ['%d', '%d']
            );

            if ($deleted) {
                Hooks::doAction('erp_crm_delete_contact_subscriber', $fieldMappings['contact_id'], $groupId);
            }

            $results[] = ['group_id' => $groupId, 'removed' => (bool) $deleted];
        }

        return [
            'response'    => $results,
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function addNote()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $rules = [
            'contact_id' => ['required', 'integer'],
            'message'    => ['required', 'string'],
        ];

        $validationErrors = $this->validateFieldMap($fieldMappings, $rules);
        if ($validationErrors) {
            return $validationErrors;
        }
        $validationErrors = $this->validateFunctionExists('erp_crm_save_customer_feed_data', $fieldMappings, true);
        if ($validationErrors) {
            return $validationErrors;
        }

        $result = erp_crm_save_customer_feed_data(
            [
                'user_id'    => $fieldMappings['contact_id'],
                'created_by' => get_current_user_id(),
                'message'    => $fieldMappings['message'],
                'type'       => 'log_activity',
                'log_type'   => 'note',
                'start_date' => current_time('mysql'),
            ]
        );

        return [
            'response'    => \is_object($result) ? (array) $result : $result,
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function createTask()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $rules = [
            'title'      => ['required', 'string'],
            'contact_id' => ['required', 'integer'],
        ];

        $validationErrors = $this->validateFieldMap($fieldMappings, $rules);
        if ($validationErrors) {
            return $validationErrors;
        }
        $validationErrors = $this->validateFunctionExists('erp_crm_save_customer_feed_data', $fieldMappings, true);
        if ($validationErrors) {
            return $validationErrors;
        }

        $defaultTime = current_time('mysql');

        $result = erp_crm_save_customer_feed_data(
            [
                'user_id'    => $fieldMappings['contact_id'],
                'created_by' => get_current_user_id(),
                'message'    => $fieldMappings['title'] . (!empty($fieldMappings['message']) ? "\n" . $fieldMappings['message'] : ''),
                'type'       => 'tasks',
                'log_type'   => '',
                'start_date' => !empty($fieldMappings['start_date']) ? $fieldMappings['start_date'] : $defaultTime,
                'end_date'   => !empty($fieldMappings['end_date']) ? $fieldMappings['end_date'] : $defaultTime,
                'extra'      => base64_encode(
                    wp_json_encode(
                        [
                            'invite_contact' => [$fieldMappings['assigned_to'] ?? get_current_user_id()],
                        ]
                    )
                ),
            ]
        );

        return [
            'response'    => WpErpHelper::normalizeData($result),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    private function normalizeGroupIds($groupIds)
    {
        return \is_array($groupIds) ? $groupIds : [$groupIds];
    }
}
