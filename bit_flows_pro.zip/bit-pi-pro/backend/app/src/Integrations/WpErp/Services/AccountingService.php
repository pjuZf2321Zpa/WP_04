<?php

namespace BitApps\PiPro\src\Integrations\WpErp\Services;

use BitApps\PiPro\src\Integrations\WpErp\WpErpHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class AccountingService extends BaseService
{
    public function createExpense()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $validationErrors = $this->validateFunctionExists('erp_acct_insert_expense', $fieldMappings, false, true);
        if ($validationErrors) {
            return $validationErrors;
        }

        $rules = ['amount' => ['required', 'numeric']];
        $validationErrors = $this->validateFieldMap($fieldMappings, $rules);

        if ($validationErrors) {
            return $validationErrors;
        }

        $currentTime = current_time('mysql');

        $result = erp_acct_insert_expense(
            [
                'people_id'        => $fieldMappings['people_id'] ?? 0,
                'voucher_date'     => !empty($fieldMappings['voucher_date']) ? $fieldMappings['voucher_date'] : $currentTime,
                'trn_date'         => !empty($fieldMappings['trn_date']) ? $fieldMappings['trn_date'] : $currentTime,
                'amount'           => $fieldMappings['amount'] ?? 0,
                'ref'              => $fieldMappings['ref'] ?? '',
                'check_no'         => $fieldMappings['check_no'] ?? '',
                'name'             => $fieldMappings['name'] ?? '',
                'particulars'      => $fieldMappings['particulars'] ?? '',
                'status'           => $fieldMappings['status'] ?? 1,
                'trn_by'           => $fieldMappings['trn_by'] ?? 1,
                'trn_by_ledger_id' => $fieldMappings['ledger_id'] ?? 0,
                'attachments'      => '',
                'billing_address'  => '',
                'bill_details'     => [],
            ]
        );

        $errorResponse = WpErpHelper::getWpErrorResponse($result, $fieldMappings);
        if ($errorResponse) {
            return $errorResponse;
        }

        return [
            'response'    => \is_array($result) ? $result : ['id' => $result],
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function createPayment()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $validationErrors = $this->validateFunctionExists('erp_acct_insert_payment', $fieldMappings, false, true);
        if ($validationErrors) {
            return $validationErrors;
        }

        $rules = ['amount' => ['required', 'numeric']];
        $validationErrors = $this->validateFieldMap($fieldMappings, $rules);

        if ($validationErrors) {
            return $validationErrors;
        }

        $currentTime = current_time('mysql');

        $result = erp_acct_insert_payment(
            [
                'customer_id'         => $fieldMappings['customer_id'] ?? 0,
                'trn_date'            => !empty($fieldMappings['trn_date']) ? $fieldMappings['trn_date'] : $currentTime,
                'amount'              => $fieldMappings['amount'] ?? 0,
                'particulars'         => $fieldMappings['particulars'] ?? '',
                'ref'                 => $fieldMappings['ref'] ?? '',
                'deposit_to'          => $fieldMappings['deposit_to'] ?? 0,
                'status'              => $fieldMappings['status'] ?? 1,
                'trn_by'              => $fieldMappings['trn_by'] ?? 1,
                'attachments'         => '',
                'invoice_no'          => '',
                'bill_details'        => [],
                'pay_invoice_details' => [],
                'particulars_items'   => [],
            ]
        );

        $errorResponse = WpErpHelper::getWpErrorResponse($result, $fieldMappings);
        if ($errorResponse) {
            return $errorResponse;
        }

        return [
            'response'    => \is_array($result) ? $result : ['id' => $result],
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }
}
