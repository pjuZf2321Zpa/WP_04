<?php

namespace BitApps\PiPro\src\Integrations\WpErp;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;

final class WpErpTrigger
{
    public static function handleContactCreated($id, $contact, $type)
    {
        if ($type !== 'contact') {
            return;
        }

        $data = [
            'id'   => $id,
            'type' => $type,
            'data' => WpErpHelper::normalizeData($contact),
        ];

        self::execute('contactCreated', $data);
    }

    public static function handleCompanyCreated($id, $company, $type)
    {
        if ($type !== 'company') {
            return;
        }

        $data = [
            'id'   => $id,
            'type' => $type,
            'data' => WpErpHelper::normalizeData($company),
        ];

        self::execute('companyCreated', $data);
    }

    public static function handleContactUpdated($currentData, $oldData)
    {
        $data = [
            'current_data' => WpErpHelper::normalizeData($currentData),
            'old_data'     => WpErpHelper::normalizeData($oldData),
        ];

        self::execute('contactUpdated', $data);
    }

    public static function handleContactDeleted($contact, $type = null, $force = false)
    {
        $data = [
            'contact' => WpErpHelper::normalizeData($contact),
            'type'    => $type,
            'force'   => $force,
        ];

        self::execute('contactDeleted', $data);
    }

    public static function handleContactOwnerAssigned($data)
    {
        self::execute('contactOwnerAssigned', WpErpHelper::normalizeData($data));
    }

    public static function handleContactUnsubscribed($id, $groupId)
    {
        $data = [
            'contact_id' => $id,
            'group_id'   => $groupId,
            'contact'    => WpErpHelper::fetchDataByField($id)
        ];

        self::execute('contactUnsubscribed', $data);
    }

    public static function handleAddedToGroup($subscriber, $hashId = null)
    {
        $groupId = \is_object($subscriber) ? ($subscriber->group_id ?? null) : ($subscriber['group_id'] ?? null);
        $userId = \is_object($subscriber) ? ($subscriber->user_id ?? null) : ($subscriber['user_id'] ?? null);

        $data = [
            'group_id'   => $groupId,
            'contact_id' => $userId,
            'hash_id'    => $hashId,
            'contact'    => WpErpHelper::fetchDataByField($userId),
        ];

        self::execute('addedToGroup', $data);
    }

    public static function handleRemovedFromGroup($userId, $groupId)
    {
        $data = [
            'group_id'   => $groupId,
            'contact_id' => $userId,
            'contact'    => WpErpHelper::fetchDataByField($userId),
        ];


        self::execute('removedFromGroup', $data);
    }

    public static function handleNoteAdded($saveData)
    {
        self::execute('noteAdded', WpErpHelper::normalizeData($saveData));
    }

    public static function handleTaskAssigned($AssignData, $saveData)
    {
        $data = WpErpHelper::normalizeData($saveData);
        $data['assigned_data'] = WpErpHelper::normalizeData($AssignData);

        self::execute('taskAssigned', $data);
    }

    public static function handleContactGroupCreated($result)
    {
        self::execute('contactGroupCreated', WpErpHelper::normalizeData($result));
    }

    public static function handleEmployeeCreated($id, $employee)
    {
        $data = WpErpHelper::normalizeData($employee);
        $data['employee_id'] = $id;

        self::execute('employeeCreated', $data);
    }

    public static function handleEmployeeUpdated($userId, $oldData)
    {
        $data = [
            'user_id'  => $userId,
            'old_data' => WpErpHelper::normalizeData($oldData),
        ];

        if (\function_exists('erp_hr_get_employee')) {
            $employee = erp_hr_get_employee($userId);
            $data['employee'] = WpErpHelper::normalizeData($employee);
        }

        self::execute('employeeUpdated', $data);
    }

    public static function handleEmployeeDeleted($userId, $force)
    {
        $data = [
            'user_id' => $userId,
            'force'   => $force,
        ];

        self::execute('employeeDeleted', $data);
    }

    public static function handleDepartmentCreated($id, $fields)
    {
        $data = WpErpHelper::normalizeData($fields);
        $data['department_id'] = $id;

        self::execute('departmentCreated', $data);
    }

    public static function handleDesignationCreated($id, $fields)
    {
        $data = WpErpHelper::normalizeData($fields);
        $data['designation_id'] = $id;

        self::execute('designationCreated', $data);
    }

    public static function handleLeaveRequestCreated($requestId, $request, $leaves = null)
    {
        $data = WpErpHelper::normalizeData($request);
        $data['request_id'] = $requestId;

        if ($leaves !== null) {
            $data['leaves'] = WpErpHelper::normalizeData($leaves);
        }

        self::execute('leaveRequestCreated', $data);
    }

    public static function handleLeaveRequestApproved($requestId, $request)
    {
        $data = WpErpHelper::normalizeData($request);
        $data['request_id'] = $requestId;

        self::execute('leaveRequestApproved', $data);
    }

    public static function handleLeaveRequestRejected($requestId, $request)
    {
        $data = WpErpHelper::normalizeData($request);
        $data['request_id'] = $requestId;

        self::execute('leaveRequestRejected', $data);
    }

    public static function handleHolidayCreated($id, $args)
    {
        $data = WpErpHelper::normalizeData($args);
        $data['holiday_id'] = $id;

        self::execute('holidayCreated', $data);
    }

    public static function handleBillCreated($data, $voucherNo)
    {
        self::executeAccounting('billCreated', $data, ['voucher_no' => $voucherNo]);
    }

    public static function handleBillUpdated($data, $billId)
    {
        self::executeAccounting('billUpdated', $data, ['bill_id' => $billId]);
    }

    public static function handleSalesCreated($data, $voucherNo)
    {
        self::executeAccounting('salesCreated', $data, ['voucher_no' => $voucherNo]);
    }

    public static function handleSalesUpdated($data, $invoiceNo)
    {
        self::executeAccounting('salesUpdated', $data, ['invoice_no' => $invoiceNo]);
    }

    public static function handlePurchaseCreated($data, $voucherNo)
    {
        self::executeAccounting('purchaseCreated', $data, ['voucher_no' => $voucherNo]);
    }

    public static function handlePurchaseUpdated($data, $purchaseId)
    {
        self::executeAccounting('purchaseUpdated', $data, ['purchase_id' => $purchaseId]);
    }

    public static function handleExpenseCreated($data, $voucherNo)
    {
        self::executeAccounting('expenseCreated', $data, ['voucher_no' => $voucherNo]);
    }

    public static function handlePaymentCreated($data, $voucherNo)
    {
        self::executeAccounting('paymentCreated', $data, ['voucher_no' => $voucherNo]);
    }

    public static function handlePayBillCreated($data, $voucherNo)
    {
        self::executeAccounting('payBillCreated', $data, ['voucher_no' => $voucherNo]);
    }

    public static function handlePayPurchaseCreated($data, $voucherNo)
    {
        self::executeAccounting('payPurchaseCreated', $data, ['voucher_no' => $voucherNo]);
    }

    private static function execute(string $machineSlug, array $data): void
    {
        $flows = FlowService::exists('wpErp', $machineSlug);

        if (!$flows) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $data);
    }

    private static function executeAccounting(string $machineSlug, $data, array $extra = []): void
    {
        self::execute($machineSlug, array_merge((array) $data, $extra));
    }
}
