<?php

namespace BitApps\PiPro\src\Integrations\WpErp;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;
use ReflectionClass;

if (!defined('ABSPATH')) {
    exit;
}

class WpErpAction implements ActionInterface
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeErpAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'] ?? 200,
            $executedNodeAction['payload'] ?? [],
            $executedNodeAction['response'] ?? []
        );
    }

    /**
     * Dispatch the configured WP ERP action.
     *
     * Validates that WP ERP is active and a machine slug is set, resolves the
     * service that handles the slug, then invokes the matching method.
     *
     * @return array{status_code: int, payload: array, response: mixed} result with HTTP status code, payload, and response message
     */
    private function executeErpAction()
    {
        if (!WpErpHelper::isErpActive()) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('WP ERP is not installed or activated', 'bit-pi'),
            ];
        }

        $machineSlug = $this->nodeInfoProvider->getMachineSlug();
        if (empty($machineSlug)) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('Action method is required.', 'bit-pi'),
            ];
        }

        $serviceInstance = $this->getServiceInstanceByMachineSlug($machineSlug);
        if (!$serviceInstance) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => \sprintf(
                    // translators: %s: action method name
                    __('WP ERP action "%s" is not registered.', 'bit-pi'),
                    $machineSlug
                ),
            ];
        }

        return $serviceInstance->{$machineSlug}();
    }

    /**
     * Resolve the service instance that handles the given machine slug.
     *
     * Scans the Services directory for *Service.php classes, instantiates each
     * instantiable class, and returns the first whose method matches the slug.
     *
     * @param string $machineSlug action method name to resolve a handler for
     *
     * @return null|object service instance exposing $machineSlug, or null if none found
     */
    private function getServiceInstanceByMachineSlug(string $machineSlug): ?object
    {
        $serviceFiles = scandir(__DIR__ . '/Services');

        if (!$serviceFiles) {
            return null;
        }

        foreach ($serviceFiles as $serviceFile) {
            if (!str_ends_with($serviceFile, 'Service.php')) {
                continue;
            }

            $serviceClass = '\BitApps\PiPro\src\Integrations\WpErp\Services\\' . basename($serviceFile, '.php');

            if (!class_exists($serviceClass)) {
                continue;
            }

            $serviceClassReflection = new ReflectionClass($serviceClass);
            if (!$serviceClassReflection->isInstantiable()) {
                continue;
            }

            $serviceInstance = new $serviceClass($this->nodeInfoProvider);

            if (\is_callable([$serviceInstance, $machineSlug])) {
                return $serviceInstance;
            }
        }

        return null;
    }
}
