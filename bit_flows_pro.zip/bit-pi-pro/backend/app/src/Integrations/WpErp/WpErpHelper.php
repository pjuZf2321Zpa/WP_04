<?php

namespace BitApps\PiPro\src\Integrations\WpErp;

use BitApps\Pi\Helpers\Utility;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Response;

if (!defined('ABSPATH')) {
    exit;
}

final class WpErpHelper
{
    private const ERP_PLUGIN_INDEX = 'erp/wp-erp.php';

    private static $isErpActive;

    private static $isCrmActive;

    public static function getContactGroups()
    {
        if (!self::isErpActive()) {
            // translators: %s: WP ERP
            return Response::error(\sprintf(__('%s is not installed or activated', 'bit-pi'), 'WP ERP'));
        }

        $groups = [];
        if (\function_exists('erp_crm_get_contact_groups')) {
            $groups = array_map(
                function ($group) {
                    $group = (array) $group;

                    return [
                        'value' => $group['id'] ?? '',
                        'label' => $group['name'] ?? '',
                    ];
                },
                (array) erp_crm_get_contact_groups(['number' => -1])
            );
        }

        return Response::success($groups);
    }

    public static function getLifeStages()
    {
        if (!self::isErpActive()) {
            // translators: %s: WP ERP
            return Response::error(\sprintf(__('%s is not installed or activated', 'bit-pi'), 'WP ERP'));
        }

        $stages = [];

        if (\function_exists('\erp_crm_get_life_stages_dropdown_raw')) {
            foreach ((array) erp_crm_get_life_stages_dropdown_raw() as $value => $label) {
                $stages[] = ['value' => $value, 'label' => $label];
            }
        }

        return Response::success($stages);
    }

    public static function getContactFields()
    {
        return Response::success(self::peopleFields('contact'));
    }

    public static function getCompanyFields()
    {
        return Response::success(self::peopleFields('company'));
    }

    public static function getEmployeeFields()
    {
        $fields = [
            ['value' => 'first_name',       'label' => __('First Name', 'bit-pi'), 'required' => true],
            ['value' => 'last_name',        'label' => __('Last Name', 'bit-pi'), 'required' => true],
            ['value' => 'middle_name',      'label' => __('Middle Name', 'bit-pi'), 'required' => false],
            ['value' => 'user_email',       'label' => __('Email', 'bit-pi'), 'required' => true],
            ['value' => 'phone',            'label' => __('Phone', 'bit-pi'), 'required' => false],
            ['value' => 'mobile',           'label' => __('Mobile', 'bit-pi'), 'required' => false],
            ['value' => 'employee_id',      'label' => __('Employee ID', 'bit-pi'), 'required' => false],
            ['value' => 'date_of_birth',    'label' => __('Date of Birth', 'bit-pi'), 'required' => false],
            ['value' => 'hiring_date',      'label' => __('Hiring Date', 'bit-pi'), 'required' => false],
            ['value' => 'location',         'label' => __('Location', 'bit-pi'), 'required' => false],
            ['value' => 'type',             'label' => __('Employment Type', 'bit-pi'), 'required' => false],
            ['value' => 'status',           'label' => __('Status', 'bit-pi'), 'required' => false],
            ['value' => 'gender',           'label' => __('Gender', 'bit-pi'), 'required' => false],
            ['value' => 'marital_status',   'label' => __('Marital Status', 'bit-pi'), 'required' => false],
            ['value' => 'nationality',      'label' => __('Nationality', 'bit-pi'), 'required' => false],
            ['value' => 'reporting_to',     'label' => __('Reporting To', 'bit-pi'), 'required' => false],
            ['value' => 'pay_rate',         'label' => __('Pay Rate', 'bit-pi'), 'required' => false],
            ['value' => 'pay_type',         'label' => __('Pay Type', 'bit-pi'), 'required' => false],
            ['value' => 'personal_email',   'label' => __('Personal Email', 'bit-pi'), 'required' => false],
            ['value' => 'street_1',         'label' => __('Street 1', 'bit-pi'), 'required' => false],
            ['value' => 'street_2',         'label' => __('Street 2', 'bit-pi'), 'required' => false],
            ['value' => 'city',             'label' => __('City', 'bit-pi'), 'required' => false],
            ['value' => 'state',            'label' => __('State', 'bit-pi'), 'required' => false],
            ['value' => 'postal_code',      'label' => __('Postal Code', 'bit-pi'), 'required' => false],
            ['value' => 'country',          'label' => __('Country', 'bit-pi'), 'required' => false],
        ];

        return Response::success($fields);
    }

    public static function getDepartments()
    {
        if (!self::isErpActive()) {
            // translators: %s: WP ERP
            return Response::error(\sprintf(__('%s is not installed or activated', 'bit-pi'), 'WP ERP'));
        }

        $out = [];

        if (\function_exists('erp_hr_get_departments')) {
            foreach ((array) erp_hr_get_departments(['number' => -1, 'no_object' => true]) as $dept) {
                $dept = (array) $dept;
                $out[] = [
                    'value' => $dept['id'] ?? '',
                    'label' => $dept['title'] ?? '',
                ];
            }
        }

        return Response::success($out);
    }

    public static function getDesignations()
    {
        if (!self::isErpActive()) {
            // translators: %s: WP ERP
            return Response::error(\sprintf(__('%s is not installed or activated', 'bit-pi'), 'WP ERP'));
        }

        $out = [];

        if (\function_exists('erp_hr_get_designations')) {
            foreach ((array) erp_hr_get_designations(['number' => -1, 'no_object' => true]) as $desig) {
                $desig = (array) $desig;
                $out[] = [
                    'value' => $desig['id'] ?? '',
                    'label' => $desig['title'] ?? '',
                ];
            }
        }

        return Response::success($out);
    }

    public static function getEmployees()
    {
        if (!self::isErpActive()) {
            // translators: %s: WP ERP
            return Response::error(\sprintf(__('%s is not installed or activated', 'bit-pi'), 'WP ERP'));
        }

        $out = [];

        if (\function_exists('erp_hr_get_employees_dropdown_raw')) {
            foreach ((array) erp_hr_get_employees_dropdown_raw() as $value => $label) {
                if ($value === -1 || $value === '-1') {
                    continue;
                }

                $out[] = ['value' => $value, 'label' => $label];
            }
        }

        return Response::success($out);
    }

    public static function getContacts()
    {
        if (!self::isErpActive()) {
            // translators: %s: WP ERP
            return Response::error(\sprintf(__('%s is not installed or activated', 'bit-pi'), 'WP ERP'));
        }

        $out = [];

        if (\function_exists('erp_get_peoples')) {
            $peoples = erp_get_peoples(['type' => 'contact', 'number' => -1]);

            foreach ((array) $peoples as $people) {
                $arr = \is_object($people) && method_exists($people, 'toArray') ? $people->toArray() : (array) $people;
                $name = trim(($arr['first_name'] ?? '') . ' ' . ($arr['last_name'] ?? ''));
                $out[] = [
                    'value' => $arr['id'] ?? '',
                    'label' => $name !== '' ? $name : ($arr['email'] ?? ''),
                ];
            }
        }

        return Response::success($out);
    }

    public static function getCompanies()
    {
        if (!self::isErpActive()) {
            // translators: %s: WP ERP
            return Response::error(\sprintf(__('%s is not installed or activated', 'bit-pi'), 'WP ERP'));
        }

        $out = [];

        if (\function_exists('erp_get_peoples')) {
            $peoples = erp_get_peoples(['type' => 'company', 'number' => -1]);

            foreach ((array) $peoples as $people) {
                $arr = \is_object($people) && method_exists($people, 'toArray') ? $people->toArray() : (array) $people;
                $out[] = [
                    'value' => $arr['id'] ?? '',
                    'label' => $arr['company'] ?? ($arr['email'] ?? ''),
                ];
            }
        }

        return Response::success($out);
    }

    public static function isErpActive(): bool
    {
        if (self::$isErpActive === null) {
            self::$isErpActive = \function_exists('is_plugin_active')
                ? is_plugin_active(self::ERP_PLUGIN_INDEX)
                : \function_exists('erp_insert_people');
        }

        return self::$isErpActive;
    }

    public static function isCrmActive(): bool
    {
        if (self::$isCrmActive === null) {
            self::$isCrmActive = \function_exists('erp_crm_get_contact_groups') || class_exists('\WeDevs\ERP\CRM\Models\ContactGroup');
        }

        return self::$isCrmActive;
    }

    public static function normalizeData($data): array
    {
        if (empty($data)) {
            return [];
        }

        if (\is_object($data) && method_exists($data, 'toArray')) {
            return $data->toArray();
        }

        if (\is_object($data) && method_exists($data, 'to_array')) {
            return $data->to_array();
        }

        return (array) Utility::jsonEncodeDecode($data);
    }

    public static function getWpErrorResponse($result, array $payload)
    {
        if (!is_wp_error($result)) {
            return;
        }

        return [
            'response'    => $result->get_error_message(),
            'payload'     => $payload,
            'status_code' => 400,
        ];
    }

    public static function fetchDataByField($fieldValue, $fieldKey = 'id')
    {
        if (empty($fieldValue)) {
            return [];
        }

        if (!\function_exists('erp_get_people_by')) {
            return [];
        }

        $data = erp_get_people_by($fieldKey, $fieldValue);

        return self::normalizeData($data);
    }

    private static function peopleFields(string $type): array
    {
        $required = $type === 'company'
            ? ['company', 'email']
            : ['first_name', 'email'];

        $fields = [
            ['value' => 'first_name',  'label' => __('First Name', 'bit-pi')],
            ['value' => 'last_name',   'label' => __('Last Name', 'bit-pi')],
            ['value' => 'email',       'label' => __('Email', 'bit-pi')],
            ['value' => 'company',     'label' => __('Company', 'bit-pi')],
            ['value' => 'phone',       'label' => __('Phone', 'bit-pi')],
            ['value' => 'mobile',      'label' => __('Mobile', 'bit-pi')],
            ['value' => 'website',     'label' => __('Website', 'bit-pi')],
            ['value' => 'fax',         'label' => __('Fax', 'bit-pi')],
            ['value' => 'notes',       'label' => __('Notes', 'bit-pi')],
            ['value' => 'street_1',    'label' => __('Street 1', 'bit-pi')],
            ['value' => 'street_2',    'label' => __('Street 2', 'bit-pi')],
            ['value' => 'city',        'label' => __('City', 'bit-pi')],
            ['value' => 'state',       'label' => __('State', 'bit-pi')],
            ['value' => 'postal_code', 'label' => __('Postal Code', 'bit-pi')],
            ['value' => 'country',     'label' => __('Country', 'bit-pi')],
            ['value' => 'currency',    'label' => __('Currency', 'bit-pi')],
        ];

        return array_map(
            static function ($field) use ($required) {
                $field['required'] = \in_array($field['value'], $required, true);

                return $field;
            },
            $fields
        );
    }
}
