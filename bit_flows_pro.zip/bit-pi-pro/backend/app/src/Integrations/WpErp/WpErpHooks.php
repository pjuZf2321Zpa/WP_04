<?php

namespace BitApps\PiPro\src\Integrations\WpErp;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!defined('ABSPATH')) {
    exit;
}

class WpErpHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'contactCreated' => [
                'hook'          => 'erp_people_created',
                'callback'      => [WpErpTrigger::class, 'handleContactCreated'],
                'accepted_args' => 3,
            ],
            'companyCreated' => [
                'hook'          => 'erp_people_created',
                'callback'      => [WpErpTrigger::class, 'handleCompanyCreated'],
                'accepted_args' => 3,
            ],
            'contactUpdated' => [
                'hook'          => 'erp_crm_log_customer_edit',
                'callback'      => [WpErpTrigger::class, 'handleContactUpdated'],
                'accepted_args' => 2,
            ],
            'contactDeleted' => [
                'hook'          => 'erp_crm_log_customer_del',
                'callback'      => [WpErpTrigger::class, 'handleContactDeleted'],
                'accepted_args' => 3,
            ],
            'contactOwnerAssigned' => [
                'hook'     => 'erp_crm_assign_contact_owner',
                'callback' => [WpErpTrigger::class, 'handleContactOwnerAssigned'],
            ],
            'contactUnsubscribed' => [
                'hook'          => 'erp_crm_pre_unsubscribed_contact',
                'callback'      => [WpErpTrigger::class, 'handleContactUnsubscribed'],
                'accepted_args' => 2,
            ],
            'addedToGroup' => [
                'hook'          => 'erp_crm_create_contact_subscriber',
                'callback'      => [WpErpTrigger::class, 'handleAddedToGroup'],
                'accepted_args' => 2,
            ],
            'removedFromGroup' => [
                'hook'          => 'erp_crm_delete_contact_subscriber',
                'callback'      => [WpErpTrigger::class, 'handleRemovedFromGroup'],
                'accepted_args' => 2,
            ],
            'noteAdded' => [
                'hook'     => 'erp_crm_save_customer_new_note_feed',
                'callback' => [WpErpTrigger::class, 'handleNoteAdded'],
            ],
            'taskAssigned' => [
                'hook'          => 'erp_crm_after_assign_task_to_user',
                'callback'      => [WpErpTrigger::class, 'handleTaskAssigned'],
                'accepted_args' => 2,
            ],
            'contactGroupCreated' => [
                'hook'     => 'erp_crm_create_contact_group',
                'callback' => [WpErpTrigger::class, 'handleContactGroupCreated'],
            ],

            'employeeCreated' => [
                'hook'          => 'erp_hr_employee_new',
                'callback'      => [WpErpTrigger::class, 'handleEmployeeCreated'],
                'accepted_args' => 2,
            ],
            'employeeUpdated' => [
                'hook'          => 'erp_hr_employee_update',
                'callback'      => [WpErpTrigger::class, 'handleEmployeeUpdated'],
                'accepted_args' => 2,
            ],
            'employeeDeleted' => [
                'hook'          => 'erp_hr_delete_employee',
                'callback'      => [WpErpTrigger::class, 'handleEmployeeDeleted'],
                'accepted_args' => 2,
            ],
            'departmentCreated' => [
                'hook'          => 'erp_hr_dept_new',
                'callback'      => [WpErpTrigger::class, 'handleDepartmentCreated'],
                'accepted_args' => 2,
            ],
            'designationCreated' => [
                'hook'          => 'erp_hr_desig_new',
                'callback'      => [WpErpTrigger::class, 'handleDesignationCreated'],
                'accepted_args' => 2,
            ],
            'leaveRequestCreated' => [
                'hook'          => 'erp_hr_leave_new',
                'callback'      => [WpErpTrigger::class, 'handleLeaveRequestCreated'],
                'accepted_args' => 3,
            ],
            'leaveRequestApproved' => [
                'hook'          => 'erp_hr_leave_request_approved',
                'callback'      => [WpErpTrigger::class, 'handleLeaveRequestApproved'],
                'accepted_args' => 2,
            ],
            'leaveRequestRejected' => [
                'hook'          => 'erp_hr_leave_request_rejected',
                'callback'      => [WpErpTrigger::class, 'handleLeaveRequestRejected'],
                'accepted_args' => 2,
            ],
            'holidayCreated' => [
                'hook'          => 'erp_hr_new_holiday',
                'callback'      => [WpErpTrigger::class, 'handleHolidayCreated'],
                'accepted_args' => 2,
            ],

            'billCreated' => [
                'hook'          => 'erp_acct_after_bill_create',
                'callback'      => [WpErpTrigger::class, 'handleBillCreated'],
                'accepted_args' => 2,
            ],
            'billUpdated' => [
                'hook'          => 'erp_acct_after_bill_update',
                'callback'      => [WpErpTrigger::class, 'handleBillUpdated'],
                'accepted_args' => 2,
            ],
            'salesCreated' => [
                'hook'          => 'erp_acct_after_sales_create',
                'callback'      => [WpErpTrigger::class, 'handleSalesCreated'],
                'accepted_args' => 2,
            ],
            'salesUpdated' => [
                'hook'          => 'erp_acct_after_sales_update',
                'callback'      => [WpErpTrigger::class, 'handleSalesUpdated'],
                'accepted_args' => 2,
            ],
            'purchaseCreated' => [
                'hook'          => 'erp_acct_after_purchase_create',
                'callback'      => [WpErpTrigger::class, 'handlePurchaseCreated'],
                'accepted_args' => 2,
            ],
            'purchaseUpdated' => [
                'hook'          => 'erp_acct_after_purchase_update',
                'callback'      => [WpErpTrigger::class, 'handlePurchaseUpdated'],
                'accepted_args' => 2,
            ],
            'expenseCreated' => [
                'hook'          => 'erp_acct_after_expense_create',
                'callback'      => [WpErpTrigger::class, 'handleExpenseCreated'],
                'accepted_args' => 2,
            ],
            'paymentCreated' => [
                'hook'          => 'erp_acct_after_payment_create',
                'callback'      => [WpErpTrigger::class, 'handlePaymentCreated'],
                'accepted_args' => 2,
            ],
            'payBillCreated' => [
                'hook'          => 'erp_acct_after_pay_bill_create',
                'callback'      => [WpErpTrigger::class, 'handlePayBillCreated'],
                'accepted_args' => 2,
            ],
            'payPurchaseCreated' => [
                'hook'          => 'erp_acct_after_pay_purchase_create',
                'callback'      => [WpErpTrigger::class, 'handlePayPurchaseCreated'],
                'accepted_args' => 2,
            ],
        ];
    }
}
