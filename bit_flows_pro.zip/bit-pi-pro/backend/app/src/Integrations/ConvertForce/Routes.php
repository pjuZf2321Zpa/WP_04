<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\PiPro\src\Integrations\ConvertForce\helper\ConvertForceHelper;

Route::group(
    function () {
        Route::get('convert-force/campaigns', [ConvertForceHelper::class, 'getCampaigns']);
    }
)->middleware('nonce:admin');
