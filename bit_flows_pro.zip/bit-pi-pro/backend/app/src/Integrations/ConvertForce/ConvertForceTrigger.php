<?php

namespace BitApps\PiPro\src\Integrations\ConvertForce;

use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\ConvertForce\helper\ConvertForceHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class ConvertForceTrigger
{
    public static function campaignCreated($postId, $post, $update): void
    {
        if ($update || !ConvertForceHelper::isConvertForceCampaign($post)) {
            return;
        }

        self::execute('campaignCreated', ConvertForceHelper::getCampaignData((int) $postId, $post));
    }

    public static function campaignUpdated($postId, $post, $update): void
    {
        if (!$update || !ConvertForceHelper::isConvertForceCampaign($post)) {
            return;
        }

        self::execute('campaignUpdated', ConvertForceHelper::getCampaignData((int) $postId, $post));
    }

    public static function campaignStatusChanged($newStatus, $oldStatus, $post): void
    {
        if ($newStatus === $oldStatus || !ConvertForceHelper::isConvertForceCampaign($post)) {
            return;
        }

        $data = array_merge(
            ConvertForceHelper::getCampaignData((int) $post->ID, $post),
            [
                'old_status' => $oldStatus,
                'new_status' => $newStatus,
            ]
        );

        self::execute('campaignStatusChanged', $data);
    }

    public static function campaignDeleted($postId, $post = null): void
    {
        $post = $post instanceof \WP_Post ? $post : get_post($postId);

        if (!ConvertForceHelper::isConvertForceCampaign($post)) {
            return;
        }

        self::execute('campaignDeleted', ConvertForceHelper::getCampaignData((int) $postId, $post));
    }

    private static function execute(string $machineSlug, array $data): void
    {
        if (!ConvertForceHelper::isPluginInstalled()) {
            return;
        }

        $flows = FlowService::exists('convertForce', $machineSlug);

        if (!$flows || empty($data)) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $data);
    }
}
