<?php

namespace BitApps\PiPro\src\Integrations\ConvertForce;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!defined('ABSPATH')) {
    exit;
}

class ConvertForceHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'campaignCreated' => [
                'hook'          => 'save_post_convertforce-popup',
                'callback'      => [ConvertForceTrigger::class, 'campaignCreated'],
                'accepted_args' => 3,
            ],
            'campaignUpdated' => [
                'hook'          => 'save_post_convertforce-popup',
                'callback'      => [ConvertForceTrigger::class, 'campaignUpdated'],
                'accepted_args' => 3,
            ],
            'campaignStatusChanged' => [
                'hook'          => 'transition_post_status',
                'callback'      => [ConvertForceTrigger::class, 'campaignStatusChanged'],
                'accepted_args' => 3,
            ],
            'campaignDeleted' => [
                'hook'          => 'before_delete_post',
                'callback'      => [ConvertForceTrigger::class, 'campaignDeleted'],
                'accepted_args' => 2,
            ],
            'campaignTrashed' => [
                'hook'          => 'wp_trash_post',
                'callback'      => [ConvertForceTrigger::class, 'campaignDeleted'],
                'accepted_args' => 1,
            ],
        ];
    }
}
