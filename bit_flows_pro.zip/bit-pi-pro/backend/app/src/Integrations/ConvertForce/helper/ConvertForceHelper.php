<?php

namespace BitApps\PiPro\src\Integrations\ConvertForce\helper;

use BitApps\Pi\Helpers\Utility;
use BitApps\PiPro\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Response;
use WP_Post;

if (!defined('ABSPATH')) {
    exit;
}

final class ConvertForceHelper
{
    public const POST_TYPE = 'convertforce-popup';

    public const META_KEY = '_convertforce_conversion';

    public static function isPluginInstalled(): bool
    {
        return defined('CONVERTFORCE_VERSION');
    }

    public static function isConvertForceCampaign($post): bool
    {
        if (!$post instanceof WP_Post) {
            return false;
        }

        return $post->post_type === self::POST_TYPE;
    }

    public static function getCampaignData(int $postId, $post = null): array
    {
        $post = $post instanceof WP_Post ? $post : get_post($postId);

        if (!$post) {
            return [];
        }

        $meta = get_post_meta($postId, self::META_KEY, true);

        return [
            'campaign_id'        => $post->ID,
            'title'              => get_the_title($post),
            'content'            => $post->post_content,
            'status'             => $post->post_status,
            'author_id'          => (int) $post->post_author,
            'created_at'         => $post->post_date,
            'updated_at'         => $post->post_modified,
            'meta'               => \is_array($meta) ? $meta : [],
            'display_options'    => \is_array($meta) ? ($meta['displayOptions'] ?? []) : [],
            'display_conditions' => \is_array($meta) ? ($meta['displayConditions'] ?? []) : [],
            'post'               => Utility::jsonEncodeDecode($post),
        ];
    }

    public static function getCampaigns()
    {
        if (!self::isPluginInstalled()) {
            return Response::error(__('ConvertForce Popup Builder plugin is not active.', 'bit-pi'));
        }

        $options = array_map(
            static function ($campaign) {
                $title = $campaign->post_title ?: __('Untitled Campaign', 'bit-pi');

                return [
                    'label' => $title . ' (#' . $campaign->ID . ')',
                    'value' => $campaign->ID,
                ];
            },
            self::getCampaignPosts()
        );

        return Response::success($options);
    }

    public static function getCampaignPosts(): array
    {
        return get_posts(
            [
                'post_type'              => self::POST_TYPE,
                'post_status'            => ['publish', 'draft', 'pending', 'future', 'private'],
                'posts_per_page'         => -1,
                'orderby'                => 'title',
                'order'                  => 'ASC',
                'no_found_rows'          => true,
                'ignore_sticky_posts'    => true,
                'update_post_meta_cache' => false,
                'update_post_term_cache' => false,
            ]
        );
    }

    public static function normalizeStatus($status): string
    {
        return \in_array($status, ['publish', 'draft', 'pending', 'private'], true) ? $status : 'draft';
    }

    public static function normalizeJsonField($value): ?array
    {
        if ($value === null || $value === '') {
            return null;
        }

        if (\is_array($value)) {
            return $value;
        }

        if (!\is_string($value)) {
            return null;
        }

        $decoded = JSON::maybeDecode(wp_unslash($value), true);

        return \is_array($decoded) ? $decoded : null;
    }
}
