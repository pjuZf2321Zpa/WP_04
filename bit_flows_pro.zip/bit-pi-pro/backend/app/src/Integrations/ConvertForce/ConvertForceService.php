<?php

namespace BitApps\PiPro\src\Integrations\ConvertForce;

use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\ConvertForce\helper\ConvertForceHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class ConvertForceService
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function createCampaign(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $rules = ['title' => ['required', 'string']];
        $validationError = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validationError)) {
            return $validationError;
        }

        $postData = [
            'post_title'   => $fieldMappings['title'],
            'post_content' => $fieldMappings['content'] ?? '',
            'post_type'    => ConvertForceHelper::POST_TYPE,
            'post_status'  => ConvertForceHelper::normalizeStatus($fieldMappings['status'] ?? 'draft'),
            'post_author'  => get_current_user_id(),
        ];

        $campaignId = wp_insert_post($postData, true);

        if (is_wp_error($campaignId)) {
            return [
                'response'    => $campaignId->get_error_message(),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        $this->updateCampaignMeta((int) $campaignId, $fieldMappings);

        return [
            'response'    => ConvertForceHelper::getCampaignData((int) $campaignId),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function getCampaign(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $rules = ['campaignId' => ['required', 'integer']];
        $validationError = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validationError)) {
            return $validationError;
        }

        $campaignId = (int) $fieldMappings['campaignId'];
        $validationError = $this->validateCampaignExists($campaignId, $fieldMappings);

        if (!empty($validationError)) {
            return $validationError;
        }

        return [
            'response'    => ConvertForceHelper::getCampaignData($campaignId),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function getAllCampaigns(): array
    {
        $response = array_map(
            static function ($campaign) {
                return ConvertForceHelper::getCampaignData((int) $campaign->ID, $campaign);
            },
            ConvertForceHelper::getCampaignPosts()
        );

        return [
            'response'    => $response,
            'payload'     => [],
            'status_code' => 200,
        ];
    }

    public function updateCampaign(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $rules = ['campaignId' => ['required', 'integer']];
        $validationError = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validationError)) {
            return $validationError;
        }

        $campaignId = (int) $fieldMappings['campaignId'];
        $validationError = $this->validateCampaignExists($campaignId, $fieldMappings);

        if (!empty($validationError)) {
            return $validationError;
        }

        $postData = ['ID' => $campaignId];

        if (isset($fieldMappings['title']) && $fieldMappings['title'] !== '') {
            $postData['post_title'] = $fieldMappings['title'];
        }

        if (isset($fieldMappings['content'])) {
            $postData['post_content'] = $fieldMappings['content'];
        }

        if (!empty($fieldMappings['status'])) {
            $postData['post_status'] = ConvertForceHelper::normalizeStatus($fieldMappings['status']);
        }

        if (\count($postData) <= 1) {
            return [
                'response'    => __('No fields to update.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        $updated = wp_update_post($postData, true);
        if (is_wp_error($updated)) {
            return [
                'response'    => $updated->get_error_message(),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        $this->updateCampaignMeta($campaignId, $fieldMappings);

        return [
            'response'    => ConvertForceHelper::getCampaignData($campaignId),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function updateCampaignStatus(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $rules = [
            'campaignId' => ['required', 'integer'],
            'status'     => ['required', 'string'],
        ];
        $validationError = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validationError)) {
            return $validationError;
        }

        $campaignId = (int) $fieldMappings['campaignId'];
        $validationError = $this->validateCampaignExists($campaignId, $fieldMappings);

        if (!empty($validationError)) {
            return $validationError;
        }

        $updated = wp_update_post(
            [
                'ID'          => $campaignId,
                'post_status' => ConvertForceHelper::normalizeStatus($fieldMappings['status']),
            ],
            true
        );

        if (is_wp_error($updated)) {
            return [
                'response'    => $updated->get_error_message(),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        return [
            'response'    => ConvertForceHelper::getCampaignData($campaignId),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    public function deleteCampaign(): array
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $rules = ['campaignId' => ['required', 'integer']];
        $validationError = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validationError)) {
            return $validationError;
        }

        $campaignId = (int) $fieldMappings['campaignId'];
        $validationError = $this->validateCampaignExists($campaignId, $fieldMappings);

        if (!empty($validationError)) {
            return $validationError;
        }

        $deleted = wp_delete_post($campaignId, !empty($fieldMappings['forceDelete']));

        if (!$deleted) {
            return [
                'response'    => __('Failed to delete the campaign.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 500,
            ];
        }

        return [
            'response'    => __('Campaign deleted successfully.', 'bit-pi'),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    private function validateCampaignExists(int $campaignId, array $payload): ?array
    {
        $post = get_post($campaignId);

        if (!$post || !ConvertForceHelper::isConvertForceCampaign($post)) {
            return [
                'response'    => __('ConvertForce campaign not found.', 'bit-pi'),
                'payload'     => $payload,
                'status_code' => 404,
            ];
        }

        return null;
    }

    private function updateCampaignMeta(int $campaignId, array $fieldMappings): void
    {
        $meta = get_post_meta($campaignId, ConvertForceHelper::META_KEY, true);

        if (!\is_array($meta)) {
            $meta = [];
        }

        $displayOptions = ConvertForceHelper::normalizeJsonField($fieldMappings['displayOptions'] ?? null);
        $displayConditions = ConvertForceHelper::normalizeJsonField($fieldMappings['displayConditions'] ?? null);

        if (\is_array($displayOptions)) {
            $meta['displayOptions'] = $displayOptions;
        }

        if (\is_array($displayConditions)) {
            $meta['displayConditions'] = $displayConditions;
        }

        if (!empty($meta)) {
            update_post_meta($campaignId, ConvertForceHelper::META_KEY, $meta);
        }
    }
}
