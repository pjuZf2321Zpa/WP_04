<?php

namespace BitApps\PiPro\src\Integrations\ThriveAutomator;

// Prevent direct script access
if (!\defined('ABSPATH')) {
    exit;
}


use BitApps\Pi\src\Integrations\ApiRequest\ApiRequestAction;

class ThriveAutomatorAction extends ApiRequestAction
{
    // extends ApiRequestAction
}
