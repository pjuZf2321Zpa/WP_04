<?php

namespace BitApps\PiPro\src\Integrations\Charitable;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\Charitable\helper\CharitableHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class CharitableTrigger
{
    public static function donationCreated($donationId)
    {
        self::execute('donationCreated', CharitableHelper::getDonationData($donationId));
    }

    public static function donationUpdated($donationId)
    {
        self::execute('donationUpdated', CharitableHelper::getDonationData($donationId));
    }

    public static function donationStatusChanged($newStatus, $oldStatus, $post)
    {
        if (!CharitableHelper::isDonationStatusTransition($newStatus, $oldStatus, $post)) {
            return;
        }

        $data = CharitableHelper::getDonationData($post->ID);

        if (empty($data)) {
            return;
        }

        $data['new_status'] = $newStatus;
        $data['old_status'] = $oldStatus;

        self::execute('donationStatusChanged', $data);
    }

    public static function donationCompleted($newStatus, $oldStatus, $post)
    {
        self::executeStatusTrigger('donationCompleted', 'charitable-completed', $newStatus, $oldStatus, $post);
    }

    public static function donationRefunded($newStatus, $oldStatus, $post)
    {
        self::executeStatusTrigger('donationRefunded', 'charitable-refunded', $newStatus, $oldStatus, $post);
    }

    public static function donationCancelled($newStatus, $oldStatus, $post)
    {
        self::executeStatusTrigger('donationCancelled', 'charitable-cancelled', $newStatus, $oldStatus, $post);
    }

    public static function donationFailed($newStatus, $oldStatus, $post)
    {
        self::executeStatusTrigger('donationFailed', 'charitable-failed', $newStatus, $oldStatus, $post);
    }

    public static function donationPending($newStatus, $oldStatus, $post)
    {
        self::executeStatusTrigger('donationPending', 'charitable-pending', $newStatus, $oldStatus, $post);
    }

    public static function campaignCreated($type, $campaignId)
    {
        if ($type !== 'insert') {
            return;
        }

        self::execute('campaignCreated', CharitableHelper::getCampaignData($campaignId));
    }

    public static function campaignUpdated($type, $campaignId)
    {
        if ($type !== 'update') {
            return;
        }

        self::execute('campaignUpdated', CharitableHelper::getCampaignData($campaignId));
    }

    public static function campaignSavedInBuilder($campaignId, $campaignSettings = [], $campaignPost = [], $isPreview = false)
    {
        if ($isPreview) {
            return;
        }

        $data = CharitableHelper::getCampaignData($campaignId);

        if (empty($data)) {
            return;
        }

        $data['builder_settings'] = Utility::normalizeData($campaignSettings);
        $data['builder_fields'] = Utility::normalizeData($campaignPost);

        self::execute('campaignSavedInBuilder', $data);
    }

    public static function campaignEnded($campaignId)
    {
        self::execute('campaignEnded', CharitableHelper::getCampaignData($campaignId));
    }

    public static function donorCreated($donorId)
    {
        self::execute('donorCreated', CharitableHelper::getDonorData($donorId));
    }

    public static function donorConsentChanged($consentChanged, $statementChanged, $donorId)
    {
        $data = CharitableHelper::getDonorData($donorId);

        if (empty($data)) {
            return;
        }

        $data['consent_changed'] = (bool) $consentChanged;
        $data['statement_changed'] = (bool) $statementChanged;

        self::execute('donorConsentChanged', $data);
    }

    public static function userCreated($userId, $values = [])
    {
        self::execute('userCreated', self::userDataWithSubmission($userId, $values));
    }

    public static function userUpdated($userId, $values = [])
    {
        self::execute('userUpdated', self::userDataWithSubmission($userId, $values));
    }

    public static function userVerified($user)
    {
        if (!\is_object($user) || empty($user->ID)) {
            return;
        }

        self::execute('userVerified', CharitableHelper::getUserData($user->ID));
    }

    public static function profileUpdated($submitted)
    {
        if (!\is_array($submitted)) {
            return;
        }

        $userId = isset($submitted['ID']) ? (int) $submitted['ID'] : get_current_user_id();

        self::execute('profileUpdated', self::userDataWithSubmission($userId, $submitted));
    }

    private static function executeStatusTrigger($machineSlug, $targetStatus, $newStatus, $oldStatus, $post)
    {
        if ($newStatus !== $targetStatus || !CharitableHelper::isDonationStatusTransition($newStatus, $oldStatus, $post)) {
            return;
        }

        $data = CharitableHelper::getDonationData($post->ID);

        if (empty($data)) {
            return;
        }

        $data['old_status'] = $oldStatus;

        self::execute($machineSlug, $data);
    }

    private static function userDataWithSubmission($userId, $values)
    {
        $data = CharitableHelper::getUserData($userId);

        if (empty($data)) {
            return [];
        }

        $data['submitted'] = Utility::normalizeData(CharitableHelper::withoutSecrets($values));

        return $data;
    }

    private static function execute($machineSlug, $data)
    {
        if (!CharitableHelper::isPluginInstalled()) {
            return;
        }

        $flows = FlowService::exists('charitable', $machineSlug);

        if (!$flows || empty($data)) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $data);
    }
}
