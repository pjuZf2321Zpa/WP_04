<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\PiPro\src\Integrations\Charitable\helper\CharitableHelper;

Route::group(
    function () {
        Route::get('charitable/campaigns', [CharitableHelper::class, 'getCampaignOptions']);
        Route::get('charitable/donations', [CharitableHelper::class, 'getDonationOptions']);
        Route::get('charitable/donors', [CharitableHelper::class, 'getDonorOptions']);
        Route::get('charitable/donation-statuses', [CharitableHelper::class, 'getDonationStatusOptions']);
        Route::get('charitable/campaign-statuses', [CharitableHelper::class, 'getCampaignStatusOptions']);
        Route::get('charitable/users', [CharitableHelper::class, 'getUserOptions']);
        Route::get('charitable/roles', [CharitableHelper::class, 'getRoleOptions']);
        Route::get('charitable/campaign-categories', [CharitableHelper::class, 'getCampaignCategoryOptions']);
        Route::get('charitable/campaign-tags', [CharitableHelper::class, 'getCampaignTagOptions']);
    }
)->middleware('nonce:admin');
