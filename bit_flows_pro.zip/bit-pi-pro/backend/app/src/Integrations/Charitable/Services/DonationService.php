<?php

namespace BitApps\PiPro\src\Integrations\Charitable\Services;

use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\Charitable\helper\CharitableHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class DonationService extends BaseService
{
    private const USER_FIELDS = [
        'email'      => 'string',
        'first_name' => 'string',
        'last_name'  => 'string',
        'company'    => 'string',
        'phone'      => 'string',
        'address'    => 'string',
        'address_2'  => 'string',
        'city'       => 'string',
        'state'      => 'string',
        'postcode'   => 'string',
        'country'    => 'string',
    ];

    public function createDonation()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'campaign_id' => ['required', 'integer'],
            'amount'      => ['required', 'numeric'],
            'email'       => ['required', 'email'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('charitable_create_donation')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Charitable donation functions are not available.', 'bit-pi'),
            ];
        }

        $campaignId = (int) $fieldMappings['campaign_id'];

        if (!CharitableHelper::campaignExists($campaignId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('The selected campaign does not exist.', 'bit-pi'),
            ];
        }

        $args = [
            'campaigns' => [
                [
                    'campaign_id' => $campaignId,
                    'amount'      => (float) $fieldMappings['amount'],
                ],
            ],
            'user'   => $this->collectFields($fieldMappings, self::USER_FIELDS),
            'status' => isset($fieldMappings['status']) ? $fieldMappings['status'] : 'charitable-completed',
        ];

        $args += $this->collectFields(
            $fieldMappings,
            [
                'gateway'  => 'string',
                'note'     => 'string',
                'user_id'  => 'int',
                'donor_id' => 'int',
            ]
        );

        $meta = $this->repeaterMap('donation-meta');

        if (!empty($meta)) {
            $args['meta'] = $meta;
        }

        $donationId = (int) charitable_create_donation($args);

        if ($donationId <= 0) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to create the donation.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => CharitableHelper::getDonationData($donationId),
        ];
    }

    public function updateDonationStatus()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'donation_id' => ['required', 'integer'],
            'status'      => ['required', 'string'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $donation = $this->findDonation($fieldMappings['donation_id']);

        if (!$donation) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Donation not found in Charitable.', 'bit-pi'),
            ];
        }

        if (!charitable_is_valid_donation_status($fieldMappings['status'])) {
            return [
                'status_code' => 422,
                'payload'     => $fieldMappings,
                'response'    => __('The given status is not a valid Charitable donation status.', 'bit-pi'),
            ];
        }

        $donation->update_status($fieldMappings['status']);

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => CharitableHelper::getDonationData($fieldMappings['donation_id']),
        ];
    }

    public function addDonationNote()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'donation_id' => ['required', 'integer'],
            'note'        => ['required', 'string'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $donation = $this->findDonation($fieldMappings['donation_id']);

        if (!$donation) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Donation not found in Charitable.', 'bit-pi'),
            ];
        }

        $donation->update_donation_log($fieldMappings['note']);

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => $donation->get_donation_log((int) $fieldMappings['donation_id']),
        ];
    }

    public function deleteDonation()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = ['donation_id' => ['required', 'integer']];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $donationId = (int) $fieldMappings['donation_id'];

        if (!CharitableHelper::donationExists($donationId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Donation not found in Charitable.', 'bit-pi'),
            ];
        }

        $forceDelete = !empty($fieldMappings['force_delete']) && filter_var($fieldMappings['force_delete'], FILTER_VALIDATE_BOOLEAN);
        $deleted = wp_delete_post($donationId, $forceDelete);

        if (!$deleted) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to delete the donation.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => __('Donation deleted successfully.', 'bit-pi'),
        ];
    }

    public function getDonation()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = ['donation_id' => ['required', 'integer']];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $data = CharitableHelper::getDonationData($fieldMappings['donation_id']);

        if (empty($data)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Donation not found in Charitable.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => $data,
        ];
    }

    public function getDonationByKey()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = ['donation_key' => ['required', 'string']];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $donationId = (int) charitable_get_donation_by_key($fieldMappings['donation_key']);
        $data = CharitableHelper::getDonationData($donationId);

        if (empty($data)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('No donation matches the given donation key.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => $data,
        ];
    }

    public function getDonations()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $limit = isset($fieldMappings['number']) ? (int) $fieldMappings['number'] : 0;

        $args = [
            'post_type'      => CharitableHelper::DONATION_POST_TYPE,
            'post_status'    => empty($fieldMappings['status']) ? CharitableHelper::getDonationStatusKeys() : $fieldMappings['status'],
            'posts_per_page' => $limit > 0 ? $limit : -1,
            'fields'         => 'ids',
        ];

        if (!empty($fieldMappings['campaign_id'])) {
            $donationIds = $this->getDonationIdsByCampaign((int) $fieldMappings['campaign_id']);

            if (empty($donationIds)) {
                return [
                    'status_code' => 200,
                    'payload'     => $fieldMappings,
                    'response'    => [],
                ];
            }

            $args['post__in'] = $donationIds;
        }

        $donations = [];

        foreach (get_posts($args) as $donationId) {
            $donations[] = CharitableHelper::getDonationData($donationId);
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => $donations,
        ];
    }

    private function getDonationIdsByCampaign($campaignId)
    {
        global $wpdb;

        $tableName = $wpdb->prefix . 'charitable_campaign_donations';

        $query = $wpdb->prepare('SELECT DISTINCT donation_id FROM ' . $tableName . ' WHERE campaign_id = %d', $campaignId);

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $ids = $wpdb->get_col($query);

        return array_map('intval', (array) $ids);
    }

    private function findDonation($donationId)
    {
        $donationId = (int) $donationId;

        if (!CharitableHelper::donationExists($donationId) || !\function_exists('charitable_get_donation')) {
            return false;
        }

        return charitable_get_donation($donationId, true);
    }
}
