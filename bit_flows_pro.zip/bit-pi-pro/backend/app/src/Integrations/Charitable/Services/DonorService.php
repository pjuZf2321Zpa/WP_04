<?php

namespace BitApps\PiPro\src\Integrations\Charitable\Services;

use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\Charitable\helper\CharitableHelper;
use Charitable_User;

if (!defined('ABSPATH')) {
    exit;
}

final class DonorService extends BaseService
{
    public function createDonor()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = ['email' => ['required', 'email']];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!class_exists('Charitable_User')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Required Charitable class Charitable_User is missing.', 'bit-pi'),
            ];
        }

        $existingDonorId = (int) charitable_get_table('donors')->get_donor_id_by_email($fieldMappings['email']);

        if ($existingDonorId > 0) {
            return [
                'status_code' => 422,
                'payload'     => $fieldMappings,
                // translators: %d is the existing donor id.
                'response' => \sprintf(__('A donor with this email address already exists (donor ID %d).', 'bit-pi'), $existingDonorId),
            ];
        }

        $userId = isset($fieldMappings['user_id']) ? (int) $fieldMappings['user_id'] : 0;
        $user = new Charitable_User($userId);

        $donorId = (int) $user->add_donor(
            $this->collectFields(
                $fieldMappings,
                [
                    'email'      => 'string',
                    'first_name' => 'string',
                    'last_name'  => 'string',
                ]
            )
        );

        if ($donorId <= 0) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => CharitableHelper::pullNoticeErrors() ?: __('Failed to create the donor.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => CharitableHelper::getDonorData($donorId),
        ];
    }

    public function updateDonor()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'donor_id' => ['required', 'integer'],
            'email'    => ['nullable', 'email'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $donorId = (int) $fieldMappings['donor_id'];

        if (empty(CharitableHelper::getDonorData($donorId))) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Donor not found in Charitable.', 'bit-pi'),
            ];
        }

        $data = $this->collectFields(
            $fieldMappings,
            [
                'email'           => 'string',
                'first_name'      => 'string',
                'last_name'       => 'string',
                'user_id'         => 'int',
                'contact_consent' => 'bool',
            ]
        );

        if (isset($data['contact_consent'])) {
            $data['contact_consent'] = $data['contact_consent'] ? 1 : 0;
        }

        if (empty($data)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('No fields provided to update.', 'bit-pi'),
            ];
        }

        $emailOwnerId = isset($data['email']) ? (int) charitable_get_table('donors')->get_donor_id_by_email($data['email']) : 0;

        if ($emailOwnerId > 0 && $emailOwnerId !== $donorId) {
            return [
                'status_code' => 422,
                'payload'     => $fieldMappings,
                // translators: %d is the donor id that already uses the email address.
                'response' => \sprintf(__('This email address already belongs to another donor (donor ID %d).', 'bit-pi'), $emailOwnerId),
            ];
        }

        $updated = charitable_get_table('donors')->update($donorId, $data);

        if (!$updated) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => CharitableHelper::pullNoticeErrors() ?: __('Failed to update the donor.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => CharitableHelper::getDonorData($donorId),
        ];
    }

    public function getDonor()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = ['donor_id' => ['required', 'integer']];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $data = CharitableHelper::getDonorData($fieldMappings['donor_id']);

        if (empty($data)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Donor not found in Charitable.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => $data,
        ];
    }

    public function getDonorByEmail()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = ['email' => ['required', 'email']];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $donorId = (int) charitable_get_donor_id_by_email($fieldMappings['email']);
        $data = CharitableHelper::getDonorData($donorId);

        if (empty($data)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('No donor matches the given email address.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => $data,
        ];
    }

    public function getDonors()
    {
        global $wpdb;

        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $limit = isset($fieldMappings['number']) ? (int) $fieldMappings['number'] : 0;
        $tableName = $wpdb->prefix . 'charitable_donors';

        $query = 'SELECT donor_id FROM ' . $tableName . ' ORDER BY donor_id DESC';

        if ($limit > 0) {
            $query = $wpdb->prepare($query . ' LIMIT %d', $limit);
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
        $donorIds = $wpdb->get_col($query);

        $donors = [];

        foreach ((array) $donorIds as $donorId) {
            $donors[] = CharitableHelper::getDonorData($donorId);
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => $donors,
        ];
    }
}
