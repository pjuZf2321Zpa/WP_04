<?php

namespace BitApps\PiPro\src\Integrations\Charitable\Services;

use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\Charitable\helper\CharitableHelper;
use Charitable_User;

if (!defined('ABSPATH')) {
    exit;
}

final class UserService extends BaseService
{
    private const CORE_FIELDS = [
        'user_email'   => 'string',
        'user_login'   => 'string',
        'user_pass'    => 'string',
        'user_url'     => 'string',
        'display_name' => 'string',
        'nickname'     => 'string',
        'first_name'   => 'string',
        'last_name'    => 'string',
        'role'         => 'string',
    ];

    private const META_FIELDS = [
        'address'      => 'string',
        'address_2'    => 'string',
        'city'         => 'string',
        'state'        => 'string',
        'postcode'     => 'string',
        'country'      => 'string',
        'phone'        => 'string',
        'organisation' => 'string',
        'description'  => 'string',
    ];

    public function createUserProfile()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = ['user_email' => ['required', 'email']];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!class_exists('Charitable_User')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Required Charitable class Charitable_User is missing.', 'bit-pi'),
            ];
        }

        if (email_exists($fieldMappings['user_email'])) {
            return [
                'status_code' => 422,
                'payload'     => $fieldMappings,
                'response'    => __('A user with that email address already exists.', 'bit-pi'),
            ];
        }

        if (!empty($fieldMappings['role']) && !wp_roles()->is_role($fieldMappings['role'])) {
            return [
                'status_code' => 422,
                'payload'     => $fieldMappings,
                'response'    => __('The given role does not exist.', 'bit-pi'),
            ];
        }

        $coreValues = $this->collectFields($fieldMappings, self::CORE_FIELDS);

        if (empty($coreValues['user_login'])) {
            $coreValues['user_login'] = $coreValues['user_email'];
        }

        if (empty($coreValues['user_pass'])) {
            $coreValues['user_pass'] = wp_generate_password(20, true, true);
        }

        $userId = wp_insert_user($coreValues);

        if (is_wp_error($userId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => $userId->get_error_message(),
            ];
        }

        $profileError = $this->applyProfile((int) $userId, $fieldMappings);

        if ($profileError !== null) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => $profileError,
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => CharitableHelper::getUserData($userId),
        ];
    }

    public function updateUserProfile()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'user_id'    => ['required', 'integer'],
            'user_email' => ['nullable', 'email'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $userId = (int) $fieldMappings['user_id'];

        if (!get_userdata($userId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User not found.', 'bit-pi'),
            ];
        }

        if (!class_exists('Charitable_User')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Required Charitable class Charitable_User is missing.', 'bit-pi'),
            ];
        }

        $emailOwnerId = empty($fieldMappings['user_email']) ? false : email_exists($fieldMappings['user_email']);

        if ($emailOwnerId && (int) $emailOwnerId !== $userId) {
            return [
                'status_code' => 422,
                'payload'     => $fieldMappings,
                'response'    => __('This email address already belongs to another user.', 'bit-pi'),
            ];
        }

        if (!empty($fieldMappings['role']) && !wp_roles()->is_role($fieldMappings['role'])) {
            return [
                'status_code' => 422,
                'payload'     => $fieldMappings,
                'response'    => __('The given role does not exist.', 'bit-pi'),
            ];
        }

        $profileError = $this->applyProfile($userId, $fieldMappings);

        if ($profileError !== null) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => $profileError,
            ];
        }

        if (!empty($fieldMappings['role'])) {
            get_userdata($userId)->set_role($fieldMappings['role']);
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => CharitableHelper::getUserData($userId),
        ];
    }

    public function markUserVerified()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = ['user_id' => ['required', 'integer']];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $userId = (int) $fieldMappings['user_id'];

        if (!get_userdata($userId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User not found.', 'bit-pi'),
            ];
        }

        if (!class_exists('Charitable_User')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Required Charitable class Charitable_User is missing.', 'bit-pi'),
            ];
        }

        $verified = !isset($fieldMappings['verified']) || filter_var($fieldMappings['verified'], FILTER_VALIDATE_BOOLEAN);

        $user = new Charitable_User($userId);
        $user->mark_as_verified($verified);

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => __('User verification status updated successfully.', 'bit-pi'),
        ];
    }

    public function getUserProfile()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = ['user_id' => ['required', 'integer']];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $data = CharitableHelper::getUserData($fieldMappings['user_id']);

        if (empty($data)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User not found.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => $data,
        ];
    }

    private function applyProfile($userId, array $fieldMappings)
    {
        $submitted = $this->collectFields($fieldMappings, self::CORE_FIELDS + self::META_FIELDS);

        unset($submitted['user_pass'], $submitted['user_login'], $submitted['role']);

        if (empty($submitted)) {
            return;
        }

        $keys = array_keys($submitted);
        $user = new Charitable_User($userId);

        if (array_intersect($keys, $user->get_core_keys()) && !$user->update_core_user($submitted)) {
            return CharitableHelper::pullNoticeErrors() ?: __('Failed to update the user profile.', 'bit-pi');
        }

        $user->update_donor_record($submitted, $keys);
        $user->update_user_meta($submitted, $keys);
    }
}
