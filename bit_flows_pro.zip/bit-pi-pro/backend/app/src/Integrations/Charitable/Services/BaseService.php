<?php

namespace BitApps\PiPro\src\Integrations\Charitable\Services;

use BitApps\Pi\src\Flow\NodeInfoProvider;

if (!defined('ABSPATH')) {
    exit;
}

abstract class BaseService
{
    protected $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    protected function config($id)
    {
        return $this->nodeInfoProvider->getFieldMapConfigs($id . '.value');
    }

    protected function collectFields(array $fieldMappings, array $keys)
    {
        $payload = [];

        foreach ($keys as $key => $type) {
            if (!isset($fieldMappings[$key]) || $fieldMappings[$key] === '') {
                continue;
            }

            $payload[$key] = $this->castValue($fieldMappings[$key], $type);
        }

        return $payload;
    }

    protected function toList($value)
    {
        if (\is_array($value)) {
            return $value;
        }

        if ($value === null || $value === '') {
            return [];
        }

        return array_filter(array_map('trim', explode(',', (string) $value)), 'strlen');
    }

    protected function repeaterMap($repeaterId, $keyColumn = 'key', $valueColumn = 'value')
    {
        $values = $this->nodeInfoProvider->getFieldMapRepeaters(
            $repeaterId . '.value',
            false,
            true,
            $keyColumn,
            $valueColumn
        );

        return \is_array($values) ? $values : [];
    }

    protected function repeaterRows($repeaterId)
    {
        $values = $this->nodeInfoProvider->getFieldMapRepeaters($repeaterId . '.value', false, false);

        return \is_array($values) ? $values : [];
    }

    private function castValue($value, $type)
    {
        if ($type === 'int') {
            return (int) $value;
        }

        if ($type === 'float') {
            return (float) $value;
        }

        if ($type === 'bool') {
            return filter_var($value, FILTER_VALIDATE_BOOLEAN);
        }

        return $value;
    }
}
