<?php

namespace BitApps\PiPro\src\Integrations\Charitable\Services;

use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\Charitable\helper\CharitableHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class CampaignService extends BaseService
{
    private const OPTIONAL_FIELDS = [
        'title'                       => 'string',
        'content'                     => 'string',
        'description'                 => 'string',
        'status'                      => 'string',
        'creator'                     => 'int',
        'image'                       => 'int',
        'goal'                        => 'float',
        'end_date'                    => 'string',
        'minimum_donation_amount'     => 'float',
        'suggested_donations_default' => 'float',
        'allow_custom_donations'      => 'bool',
    ];

    public function createCampaign()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = ['title' => ['required', 'string']];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('charitable_create_campaign')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Charitable campaign functions are not available.', 'bit-pi'),
            ];
        }

        return $this->saveCampaign($this->buildArgs($fieldMappings));
    }

    public function updateCampaign()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = ['campaign_id' => ['required', 'integer']];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $campaignId = (int) $fieldMappings['campaign_id'];

        if (!CharitableHelper::campaignExists($campaignId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Campaign not found in Charitable.', 'bit-pi'),
            ];
        }

        if (!\function_exists('charitable_create_campaign')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Charitable campaign functions are not available.', 'bit-pi'),
            ];
        }

        $args = $this->buildArgs($fieldMappings);
        $args['ID'] = $campaignId;

        return $this->saveCampaign($args);
    }

    public function deleteCampaign()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = ['campaign_id' => ['required', 'integer']];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $campaignId = (int) $fieldMappings['campaign_id'];

        if (!CharitableHelper::campaignExists($campaignId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Campaign not found in Charitable.', 'bit-pi'),
            ];
        }

        $forceDelete = !empty($fieldMappings['force_delete']) && filter_var($fieldMappings['force_delete'], FILTER_VALIDATE_BOOLEAN);
        $deleted = wp_delete_post($campaignId, $forceDelete);

        if (!$deleted) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to delete the campaign.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => __('Campaign deleted successfully.', 'bit-pi')
        ];
    }

    public function getCampaign()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = ['campaign_id' => ['required', 'integer']];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $data = CharitableHelper::getCampaignData($fieldMappings['campaign_id']);

        if (empty($data)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Campaign not found in Charitable.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => $data,
        ];
    }

    public function getCampaigns()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $campaigns = [];
        $limit = isset($fieldMappings['number']) ? (int) $fieldMappings['number'] : 0;

        $args = [
            'post_type'      => CharitableHelper::CAMPAIGN_POST_TYPE,
            'post_status'    => empty($fieldMappings['status']) ? 'any' : $fieldMappings['status'],
            'posts_per_page' => $limit > 0 ? $limit : -1,
            'fields'         => 'ids',
        ];

        foreach (get_posts($args) as $campaignId) {
            $campaigns[] = CharitableHelper::getCampaignData($campaignId);
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => $campaigns,
        ];
    }

    private function buildArgs(array $fieldMappings)
    {
        $args = $this->collectFields($fieldMappings, self::OPTIONAL_FIELDS);

        if (!empty($fieldMappings['categories'])) {
            $args['categories'] = CharitableHelper::resolveTermIds(
                $this->toList($fieldMappings['categories']),
                CharitableHelper::CATEGORY_TAXONOMY
            );
        }

        if (!empty($fieldMappings['tags'])) {
            $args['tags'] = CharitableHelper::resolveTermIds(
                $this->toList($fieldMappings['tags']),
                CharitableHelper::TAG_TAXONOMY
            );
        }

        $suggestedDonations = $this->repeaterRows('suggested-donations');

        if (!empty($suggestedDonations)) {
            $args['suggested_donations'] = $suggestedDonations;
        }

        return $args;
    }

    private function saveCampaign(array $args)
    {
        $campaignId = (int) charitable_create_campaign($args);

        if ($campaignId <= 0) {
            return [
                'status_code' => 400,
                'payload'     => $args,
                'response'    => __('Failed to save the campaign.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $args,
            'response'    => CharitableHelper::getCampaignData($campaignId),
        ];
    }
}
