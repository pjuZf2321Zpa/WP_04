<?php

namespace BitApps\PiPro\src\Integrations\Charitable\helper;

use BitApps\Pi\Helpers\Utility;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Response;
use WP_Post;

if (!defined('ABSPATH')) {
    exit;
}

final class CharitableHelper
{
    public const CAMPAIGN_POST_TYPE = 'campaign';

    public const DONATION_POST_TYPE = 'donation';

    public const CATEGORY_TAXONOMY = 'campaign_category';

    public const TAG_TAXONOMY = 'campaign_tag';

    public static function isPluginInstalled()
    {
        return class_exists('Charitable') && \function_exists('charitable');
    }

    public static function getDonationStatusKeys()
    {
        return \function_exists('charitable_get_valid_donation_statuses')
            ? array_keys(charitable_get_valid_donation_statuses())
            : [];
    }

    public static function isDonationStatusTransition($newStatus, $oldStatus, $post)
    {
        return $post instanceof WP_Post
            && $post->post_type === self::DONATION_POST_TYPE
            && $newStatus !== $oldStatus
            && !\in_array($oldStatus, ['new', 'auto-draft'], true)
            && \in_array($newStatus, self::getDonationStatusKeys(), true);
    }

    public static function pullNoticeErrors()
    {
        if (!\function_exists('charitable_get_notices')) {
            return '';
        }

        $notices = charitable_get_notices();
        $errors = array_map('wp_strip_all_tags', (array) $notices->get_errors());
        $notices->clear_notices_by_type('error');

        return implode(' ', array_filter($errors));
    }

    public static function withoutSecrets($values)
    {
        if (!\is_array($values)) {
            return $values;
        }

        unset($values['user_pass'], $values['user_pass_repeat'], $values['current_pass']);

        return $values;
    }

    public static function getDonationData($donationId)
    {
        $donationId = (int) $donationId;

        if ($donationId <= 0 || !\function_exists('charitable_get_donation')) {
            return [];
        }

        wp_cache_delete($donationId, 'charitable_donation');

        $donation = charitable_get_donation($donationId);

        if (!$donation) {
            return [];
        }

        $campaigns = [];

        foreach ((array) $donation->get_campaign_donations() as $campaignDonation) {
            $campaigns[] = Utility::normalizeData($campaignDonation);
        }

        $donorId = (int) $donation->get_donor_id();

        return [
            'donation_id'    => $donationId,
            'donation_key'   => $donation->get_donation_key(),
            'status'         => $donation->get_status(),
            'status_label'   => $donation->get_status_label(),
            'total'          => $donation->get_total_donation_amount(),
            'currency'       => $donation->get_currency(),
            'gateway'        => $donation->get_gateway(),
            'gateway_label'  => $donation->get_gateway_label(),
            'transaction_id' => $donation->get_gateway_transaction_id(),
            'date'           => $donation->get_date('Y-m-d H:i:s'),
            'note'           => $donation->get_notes(),
            'test_mode'      => $donation->get_test_mode(false),
            'campaigns'      => $campaigns,
            'donor_id'       => $donorId,
            'donor'          => self::getDonorData($donorId),
            'meta'           => Utility::getPostMetadata($donationId),
        ];
    }

    public static function getCampaignData($campaignId)
    {
        $campaignId = (int) $campaignId;

        if ($campaignId <= 0) {
            return [];
        }

        $post = get_post($campaignId);

        if (!$post || $post->post_type !== self::CAMPAIGN_POST_TYPE) {
            return [];
        }

        $data = [
            'campaign_id' => $campaignId,
            'title'       => $post->post_title,
            'content'     => $post->post_content,
            'status'      => $post->post_status,
            'permalink'   => get_permalink($campaignId),
            'date'        => $post->post_date,
            'creator'     => Utility::getUserInfo($post->post_author),
            'categories'  => self::getTermNames($campaignId, self::CATEGORY_TAXONOMY),
            'tags'        => self::getTermNames($campaignId, self::TAG_TAXONOMY),
            'meta'        => Utility::getPostMetadata($campaignId),
        ];

        if (\function_exists('charitable_get_campaign')) {
            $campaign = charitable_get_campaign($campaignId);

            if ($campaign) {
                $data['goal'] = $campaign->get_goal();
                $data['donated_amount'] = $campaign->get_donated_amount();
                $data['percent_donated'] = $campaign->get_percent_donated_raw();
                $data['donor_count'] = $campaign->get_donor_count();
                $data['end_date'] = $campaign->get_end_date('Y-m-d H:i:s');
                $data['has_ended'] = $campaign->has_ended();
            }
        }

        return $data;
    }

    public static function getDonorData($donorId)
    {
        $donorId = (int) $donorId;

        if ($donorId <= 0 || !\function_exists('charitable_get_table')) {
            return [];
        }

        $rows = charitable_get_table('donors')->get_personal_data_by_donor_id($donorId);
        $donor = \is_array($rows) ? reset($rows) : $rows;

        if (!$donor) {
            return [];
        }

        $data = Utility::normalizeData($donor);
        $data['donor_id'] = $donorId;

        if (!empty($data['user_id'])) {
            $data['user'] = Utility::getUserInfo($data['user_id']);
        }

        return $data;
    }

    public static function getUserData($userId)
    {
        $userId = (int) $userId;

        if ($userId <= 0) {
            return [];
        }

        $data = Utility::getUserInfo($userId);

        if (empty($data)) {
            return [];
        }

        $data['meta'] = Utility::getUserMetadata($userId);

        if (\function_exists('charitable_get_table')) {
            $donorId = (int) charitable_get_table('donors')->get_donor_id($userId);

            if ($donorId > 0) {
                $data['donor_id'] = $donorId;
                $data['donor'] = self::getDonorData($donorId);
            }
        }

        return $data;
    }

    public static function getTermNames($campaignId, $taxonomy)
    {
        $terms = wp_get_object_terms($campaignId, $taxonomy, ['fields' => 'names']);

        return is_wp_error($terms) ? [] : $terms;
    }

    public static function donationExists($donationId)
    {
        return get_post_type((int) $donationId) === self::DONATION_POST_TYPE;
    }

    public static function campaignExists($campaignId)
    {
        return get_post_type((int) $campaignId) === self::CAMPAIGN_POST_TYPE;
    }

    public static function resolveTermIds($terms, $taxonomy)
    {
        $termIds = [];

        foreach ((array) $terms as $term) {
            if (is_numeric($term)) {
                $termIds[] = (int) $term;

                continue;
            }

            $existing = get_term_by('name', $term, $taxonomy);

            if ($existing) {
                $termIds[] = (int) $existing->term_id;

                continue;
            }

            $created = wp_insert_term($term, $taxonomy);

            if (!is_wp_error($created)) {
                $termIds[] = (int) $created['term_id'];
            }
        }

        return $termIds;
    }

    public static function getCampaignOptions()
    {
        $options = [];

        foreach (get_posts(['post_type' => self::CAMPAIGN_POST_TYPE, 'post_status' => 'any', 'posts_per_page' => -1]) as $campaign) {
            $options[] = ['value' => $campaign->ID, 'label' => $campaign->post_title];
        }

        return Response::success($options);
    }

    public static function getDonationOptions()
    {
        $options = [];

        foreach (get_posts(['post_type' => self::DONATION_POST_TYPE, 'post_status' => self::getDonationStatusKeys(), 'posts_per_page' => -1]) as $donation) {
            $options[] = [
                'value' => $donation->ID,
                // translators: %1$d is the donation id, %2$s is the donation title.
                'label' => \sprintf(__('#%1$d - %2$s', 'bit-pi'), $donation->ID, html_entity_decode($donation->post_title, ENT_QUOTES, 'UTF-8')),
            ];
        }

        return Response::success($options);
    }

    public static function getDonorOptions()
    {
        global $wpdb;

        $options = [];
        $tableName = $wpdb->prefix . 'charitable_donors';

        $query = $wpdb->prepare(
            'SELECT donor_id, email, first_name, last_name FROM ' . $tableName . ' ORDER BY donor_id DESC LIMIT %d',
            5000
        );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $donors = $wpdb->get_results($query);

        foreach ((array) $donors as $donor) {
            $name = trim($donor->first_name . ' ' . $donor->last_name);

            $options[] = [
                'value' => (int) $donor->donor_id,
                'label' => $name === '' ? $donor->email : $name . ' (' . $donor->email . ')',
            ];
        }

        return Response::success($options);
    }

    public static function getDonationStatusOptions()
    {
        $options = [];

        if (\function_exists('charitable_get_valid_donation_statuses')) {
            foreach (charitable_get_valid_donation_statuses() as $status => $label) {
                $options[] = ['value' => $status, 'label' => $label];
            }
        }

        return Response::success($options);
    }

    public static function getCampaignStatusOptions()
    {
        return Response::success(
            [
                ['value' => 'publish', 'label' => __('Published', 'bit-pi')],
                ['value' => 'draft', 'label' => __('Draft', 'bit-pi')],
                ['value' => 'pending', 'label' => __('Pending Review', 'bit-pi')],
                ['value' => 'private', 'label' => __('Private', 'bit-pi')],
                ['value' => 'trash', 'label' => __('Trash', 'bit-pi')],
            ]
        );
    }

    public static function getUserOptions()
    {
        $options = [];

        foreach (get_users(['fields' => ['ID', 'display_name', 'user_email']]) as $user) {
            $options[] = [
                'value' => (int) $user->ID,
                'label' => $user->display_name . ' (' . $user->user_email . ')',
            ];
        }

        return Response::success($options);
    }

    public static function getRoleOptions()
    {
        $options = [];

        foreach (wp_roles()->get_names() as $role => $name) {
            $options[] = ['value' => $role, 'label' => translate_user_role($name)];
        }

        return Response::success($options);
    }

    public static function getCampaignCategoryOptions()
    {
        return Response::success(self::getTermOptions(self::CATEGORY_TAXONOMY));
    }

    public static function getCampaignTagOptions()
    {
        return Response::success(self::getTermOptions(self::TAG_TAXONOMY));
    }

    private static function getTermOptions($taxonomy)
    {
        $terms = get_terms(['taxonomy' => $taxonomy, 'hide_empty' => false]);

        if (is_wp_error($terms)) {
            return [];
        }

        $options = [];

        foreach ($terms as $term) {
            $options[] = ['value' => (int) $term->term_id, 'label' => $term->name];
        }

        return $options;
    }
}
