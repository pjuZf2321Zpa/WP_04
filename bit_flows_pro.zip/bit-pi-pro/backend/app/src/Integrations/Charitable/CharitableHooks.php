<?php

namespace BitApps\PiPro\src\Integrations\Charitable;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!defined('ABSPATH')) {
    exit;
}

class CharitableHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'donationCreated' => [
                'hook'     => 'charitable_after_save_donation',
                'callback' => [CharitableTrigger::class, 'donationCreated'],
            ],
            'donationUpdated' => [
                'hook'     => 'charitable_donation_save',
                'callback' => [CharitableTrigger::class, 'donationUpdated'],
            ],
            'donationStatusChanged' => [
                'hook'          => 'transition_post_status',
                'callback'      => [CharitableTrigger::class, 'donationStatusChanged'],
                'accepted_args' => 3,
            ],
            'donationCompleted' => [
                'hook'          => 'transition_post_status',
                'callback'      => [CharitableTrigger::class, 'donationCompleted'],
                'accepted_args' => 3,
            ],
            'donationRefunded' => [
                'hook'          => 'transition_post_status',
                'callback'      => [CharitableTrigger::class, 'donationRefunded'],
                'accepted_args' => 3,
            ],
            'donationCancelled' => [
                'hook'          => 'transition_post_status',
                'callback'      => [CharitableTrigger::class, 'donationCancelled'],
                'accepted_args' => 3,
            ],
            'donationFailed' => [
                'hook'          => 'transition_post_status',
                'callback'      => [CharitableTrigger::class, 'donationFailed'],
                'accepted_args' => 3,
            ],
            'donationPending' => [
                'hook'          => 'transition_post_status',
                'callback'      => [CharitableTrigger::class, 'donationPending'],
                'accepted_args' => 3,
            ],
            'campaignCreated' => [
                'hook'          => 'charitable_campaign_processor_save_core',
                'callback'      => [CharitableTrigger::class, 'campaignCreated'],
                'accepted_args' => 2,
            ],
            'campaignUpdated' => [
                'hook'          => 'charitable_campaign_processor_save_core',
                'callback'      => [CharitableTrigger::class, 'campaignUpdated'],
                'accepted_args' => 2,
            ],
            'campaignSavedInBuilder' => [
                'hook'          => 'charitable_builder_save_campaign',
                'callback'      => [CharitableTrigger::class, 'campaignSavedInBuilder'],
                'accepted_args' => 4,
            ],
            'campaignEnded' => [
                'hook'     => 'charitable_campaign_end',
                'callback' => [CharitableTrigger::class, 'campaignEnded'],
            ],
            'donorCreated' => [
                'hook'     => 'charitable_after_insert_donor',
                'callback' => [CharitableTrigger::class, 'donorCreated'],
            ],
            'donorConsentChanged' => [
                'hook'          => 'charitable_donor_contact_consent_changed',
                'callback'      => [CharitableTrigger::class, 'donorConsentChanged'],
                'accepted_args' => 3,
            ],
            'userCreated' => [
                'hook'          => 'charitable_after_insert_user',
                'callback'      => [CharitableTrigger::class, 'userCreated'],
                'accepted_args' => 2,
            ],
            'userUpdated' => [
                'hook'          => 'charitable_after_save_user',
                'callback'      => [CharitableTrigger::class, 'userUpdated'],
                'accepted_args' => 2,
            ],
            'userVerified' => [
                'hook'     => 'charitable_user_verified',
                'callback' => [CharitableTrigger::class, 'userVerified'],
            ],
            'profileUpdated' => [
                'hook'     => 'charitable_profile_updated',
                'callback' => [CharitableTrigger::class, 'profileUpdated'],
            ],
        ];
    }
}
