<?php

namespace BitApps\PiPro\src\Integrations\BuddyPress\Services;

use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\BuddyPress\helper\BuddyPressHelper;

if (!\defined('ABSPATH')) {
    exit;
}

final class MemberService extends BaseService
{
    public function deleteUserAccount()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'user_id' => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('bp_core_delete_account')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Members functions not found.', 'bit-pi'),
            ];
        }

        $result = bp_core_delete_account(absint($fieldMappings['user_id']));

        return [
            'status_code' => $result ? 200 : 400,
            'payload'     => $fieldMappings,
            'response'    => $result ? __('User account deleted.', 'bit-pi') : __('Failed to delete user account.', 'bit-pi'),
        ];
    }

    public function setMemberType()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'user_id'     => ['required', 'integer'],
            'member_type' => ['required', 'string'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('bp_set_member_type')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Member Type functions not found.', 'bit-pi'),
            ];
        }

        $result = bp_set_member_type(
            absint($fieldMappings['user_id']),
            $fieldMappings['member_type']
        );

        return [
            'status_code' => $result ? 200 : 400,
            'payload'     => $fieldMappings,
            'response'    => $result ? __('Member type set.', 'bit-pi') : __('Failed to set member type.', 'bit-pi'),
        ];
    }

    public function getUser()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'user_id' => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('get_userdata')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('WordPress user functions not found.', 'bit-pi'),
            ];
        }

        $user = get_userdata(absint($fieldMappings['user_id']));

        if (!$user) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User not found.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => BuddyPressHelper::extractObjectAttributes($user),
        ];
    }

    public function getUserByEmail()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'email' => ['required', 'email'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('get_user_by')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('WordPress user functions not found.', 'bit-pi'),
            ];
        }

        $user = get_user_by('email', $fieldMappings['email']);

        if (!$user) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User not found.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => BuddyPressHelper::extractObjectAttributes($user),
        ];
    }

    public function getMemberType()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'user_id' => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('bp_get_member_type')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Member Type functions not found.', 'bit-pi'),
            ];
        }

        $memberType = bp_get_member_type(absint($fieldMappings['user_id']));

        if ($memberType === false) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('No member type found for this user.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => ['member_type' => $memberType],
        ];
    }
}
