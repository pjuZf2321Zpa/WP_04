<?php

namespace BitApps\PiPro\src\Integrations\BuddyPress\Services;

use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\BuddyPress\helper\BuddyPressHelper;

if (!\defined('ABSPATH')) {
    exit;
}

final class MessageService extends BaseService
{
    public function sendMessage()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'subject'    => ['required', 'string'],
            'content'    => ['required', 'string'],
            'recipients' => ['required', 'string'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('messages_new_message')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Messages component is not active.', 'bit-pi'),
            ];
        }

        $recipientEmails = array_map('trim', explode(',', $fieldMappings['recipients']));
        $recipientIds = [];

        foreach ($recipientEmails as $email) {
            if (!is_email($email)) {
                $recipientId = \is_numeric($email) ? absint($email) : 0;
            } else {
                $recipientId = email_exists($email);
            }

            if (!$recipientId) {
                continue;
            }

            $recipientIds[] = $recipientId;
        }

        if (empty($recipientIds)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('No valid recipients found.', 'bit-pi'),
            ];
        }

        $args = [
            'subject'    => $fieldMappings['subject'],
            'content'    => $fieldMappings['content'],
            'recipients' => $recipientIds,
            'error_type' => 'wp_error',
        ];

        if (!empty($fieldMappings['sender_id'])) {
            $args['sender_id'] = absint($fieldMappings['sender_id']);
        }

        if (!empty($fieldMappings['thread_id'])) {
            $args['thread_id'] = absint($fieldMappings['thread_id']);
        }

        $messageSent = messages_new_message($args);

        if (!$messageSent || \is_wp_error($messageSent)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => \is_wp_error($messageSent) ? $messageSent->get_error_message() : __('Failed to send message.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => ['thread_id' => $messageSent],
        ];
    }

    public function deleteThread()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'thread_id' => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('messages_delete_thread')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Messages component is not active.', 'bit-pi'),
            ];
        }

        $userId = !empty($fieldMappings['user_id']) ? absint($fieldMappings['user_id']) : 0;

        $result = messages_delete_thread(absint($fieldMappings['thread_id']), $userId);

        return [
            'status_code' => $result ? 200 : 400,
            'payload'     => $fieldMappings,
            'response'    => $result ? __('Thread deleted.', 'bit-pi') : __('Failed to delete thread.', 'bit-pi'),
        ];
    }

    public function markThreadRead()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'thread_id' => ['required', 'integer'],
            'user_id'   => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('messages_mark_thread_read')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Messages component is not active.', 'bit-pi'),
            ];
        }

        $result = messages_mark_thread_read(absint($fieldMappings['thread_id']), absint($fieldMappings['user_id']));

        return [
            'status_code' => $result ? 200 : 400,
            'payload'     => $fieldMappings,
            'response'    => $result ? __('Thread marked as read.', 'bit-pi') : __('Failed to mark thread as read.', 'bit-pi'),
        ];
    }

    public function sendNotice()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'subject' => ['required', 'string'],
            'message' => ['required', 'string'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('messages_send_notice')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Messages component is not active.', 'bit-pi'),
            ];
        }

        $result = messages_send_notice($fieldMappings['subject'], $fieldMappings['message']);

        return [
            'status_code' => $result ? 200 : 400,
            'payload'     => $fieldMappings,
            'response'    => $result ? __('Notice sent.', 'bit-pi') : __('Failed to send notice.', 'bit-pi'),
        ];
    }

    public function getThread()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'thread_id' => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\class_exists('BP_Messages_Thread')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Messages component is not active.', 'bit-pi'),
            ];
        }

        $thread = new \BP_Messages_Thread(absint($fieldMappings['thread_id']));

        if (empty($thread->messages)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Thread not found.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => BuddyPressHelper::extractObjectAttributes($thread),
        ];
    }

    public function getMessages()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'thread_id' => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\class_exists('BP_Messages_Thread')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Messages component is not active.', 'bit-pi'),
            ];
        }

        $messages = \BP_Messages_Thread::get_messages(absint($fieldMappings['thread_id']));

        if (empty($messages)) {
            return [
                'status_code' => 200,
                'payload'     => $fieldMappings,
                'response'    => [],
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => $messages,
        ];
    }
}
