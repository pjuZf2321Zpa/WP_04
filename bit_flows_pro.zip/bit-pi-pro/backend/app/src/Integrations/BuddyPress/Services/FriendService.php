<?php

namespace BitApps\PiPro\src\Integrations\BuddyPress\Services;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\BuddyPress\helper\BuddyPressHelper;

if (!\defined('ABSPATH')) {
    exit;
}

final class FriendService extends BaseService
{
    public function sendFriendRequest()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'initiator_id' => ['required', 'integer'],
            'friend_id'    => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('friends_add_friend')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Friends component is not active.', 'bit-pi'),
            ];
        }

        $result = friends_add_friend(
            absint($fieldMappings['initiator_id']),
            absint($fieldMappings['friend_id'])
        );

        return [
            'status_code' => $result ? 200 : 400,
            'payload'     => $fieldMappings,
            'response'    => $result ? __('Friend request sent.', 'bit-pi') : __('Failed to send friend request.', 'bit-pi'),
        ];
    }

    public function acceptFriendship()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'friendship_id' => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('friends_accept_friendship')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Friends component is not active.', 'bit-pi'),
            ];
        }

        $result = friends_accept_friendship(absint($fieldMappings['friendship_id']));

        return [
            'status_code' => $result ? 200 : 400,
            'payload'     => $fieldMappings,
            'response'    => $result ? __('Friendship accepted.', 'bit-pi') : __('Failed to accept friendship.', 'bit-pi'),
        ];
    }

    public function rejectFriendship()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'friendship_id' => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('friends_reject_friendship')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Friends component is not active.', 'bit-pi'),
            ];
        }

        $result = friends_reject_friendship(absint($fieldMappings['friendship_id']));

        return [
            'status_code' => $result ? 200 : 400,
            'payload'     => $fieldMappings,
            'response'    => $result ? __('Friendship rejected.', 'bit-pi') : __('Failed to reject friendship.', 'bit-pi'),
        ];
    }

    public function removeFriend()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'initiator_id' => ['required', 'integer'],
            'friend_id'    => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('friends_remove_friend')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Friends component is not active.', 'bit-pi'),
            ];
        }

        $result = friends_remove_friend(
            absint($fieldMappings['initiator_id']),
            absint($fieldMappings['friend_id'])
        );

        return [
            'status_code' => $result ? 200 : 400,
            'payload'     => $fieldMappings,
            'response'    => $result ? __('Friendship removed.', 'bit-pi') : __('Failed to remove friendship.', 'bit-pi'),
        ];
    }

    public function getFriends()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'user_id' => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('friends_get_friend_user_ids')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Friends component is not active.', 'bit-pi'),
            ];
        }

        $friendIds = friends_get_friend_user_ids(absint($fieldMappings['user_id']));
        $friends = [];

        if (!empty($friendIds)) {
            foreach ($friendIds as $friendId) {
                $friends[] = Utility::getUserInfo($friendId);
            }
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => $friends,
        ];
    }

    public function checkFriendship()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'initiator_id' => ['required', 'integer'],
            'friend_id'    => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('friends_check_friendship')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Friends component is not active.', 'bit-pi'),
            ];
        }

        $result = friends_check_friendship(
            absint($fieldMappings['initiator_id']),
            absint($fieldMappings['friend_id'])
        );

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => ['friendship_status' => $result],
        ];
    }
}
