<?php

namespace BitApps\PiPro\src\Integrations\BuddyPress\Services;

use BitApps\Pi\src\Integrations\IntegrationHelper;

if (!\defined('ABSPATH')) {
    exit;
}

final class SettingsService extends BaseService
{
    public function updateNotificationSettings()
    {
        $fieldData = $this->nodeInfoProvider->getFieldMapData();
        $fieldMappings = $this->nodeInfoProvider->getFieldMapRepeaters('settings.value', false, true, 'key', 'value');

        $userEmail = $fieldData['user_email'] ?? '';

        if (empty($userEmail)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User email is required.', 'bit-pi'),
            ];
        }

        if (empty($fieldMappings)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('At least one setting key-value pair is required.', 'bit-pi'),
            ];
        }

        if (!\function_exists('bp_settings_update_notification_settings')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Settings functions not found.', 'bit-pi'),
            ];
        }

        $userId = email_exists($userEmail);

        if (empty($userId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User not found with provided email.', 'bit-pi'),
            ];
        }

        bp_settings_update_notification_settings($userId, $fieldMappings);

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => __('Notification settings updated.', 'bit-pi'),
        ];
    }
}
