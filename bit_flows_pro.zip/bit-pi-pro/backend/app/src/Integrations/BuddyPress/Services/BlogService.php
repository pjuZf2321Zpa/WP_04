<?php

namespace BitApps\PiPro\src\Integrations\BuddyPress\Services;

use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\BuddyPress\helper\BuddyPressHelper;

if (!\defined('ABSPATH')) {
    exit;
}

final class BlogService extends BaseService
{
    public function recordBlog()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'blog_id' => ['required', 'integer'],
            'user_id' => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('bp_blogs_record_blog')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Blogs component is not active.', 'bit-pi'),
            ];
        }

        bp_blogs_record_blog(
            absint($fieldMappings['blog_id']),
            absint($fieldMappings['user_id']),
            !empty($fieldMappings['no_activity'])
        );

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => ['blog_id' => absint($fieldMappings['blog_id']), 'user_id' => absint($fieldMappings['user_id'])],
        ];
    }

    public function listBlogs()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        if (!\function_exists('bp_blogs_get_blogs')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Blogs component is not active.', 'bit-pi'),
            ];
        }

        $args = [];
        if (!empty($fieldMappings['user_id'])) {
            $args['user_id'] = absint($fieldMappings['user_id']);
        }

        $blogs = bp_blogs_get_blogs($args);
        $result = [];

        if (!empty($blogs['blogs'])) {
            foreach ($blogs['blogs'] as $blog) {
                $result[] = BuddyPressHelper::extractObjectAttributes($blog);
            }
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => $result,
        ];
    }
}
