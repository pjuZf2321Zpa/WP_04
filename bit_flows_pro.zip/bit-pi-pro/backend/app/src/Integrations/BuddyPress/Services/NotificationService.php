<?php

namespace BitApps\PiPro\src\Integrations\BuddyPress\Services;

use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\BuddyPress\helper\BuddyPressHelper;

if (!\defined('ABSPATH')) {
    exit;
}

final class NotificationService extends BaseService
{
    public function addNotification()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'user_id'           => ['required', 'integer'],
            'component_name'    => ['required', 'string'],
            'component_action'  => ['required', 'string'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('bp_notifications_add_notification')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Notifications component is not active.', 'bit-pi'),
            ];
        }

        $args = [
            'user_id'           => absint($fieldMappings['user_id']),
            'component_name'    => $fieldMappings['component_name'],
            'component_action'  => $fieldMappings['component_action'],
            'item_id'           => isset($fieldMappings['item_id']) ? absint($fieldMappings['item_id']) : 0,
            'secondary_item_id' => isset($fieldMappings['secondary_item_id']) ? absint($fieldMappings['secondary_item_id']) : 0,
            'date_notified'     => \function_exists('bp_core_current_time') ? bp_core_current_time() : current_time('mysql'),
            'is_new'            => 1,
        ];

        $notificationId = bp_notifications_add_notification($args);

        if (!$notificationId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to add notification.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => ['notification_id' => $notificationId],
        ];
    }

    public function markNotificationRead()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'notification_id' => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('bp_notifications_mark_notification')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Notifications component is not active.', 'bit-pi'),
            ];
        }

        $result = bp_notifications_mark_notification(absint($fieldMappings['notification_id']), false);

        return [
            'status_code' => $result ? 200 : 400,
            'payload'     => $fieldMappings,
            'response'    => $result ? __('Notification marked as read.', 'bit-pi') : __('Failed to mark notification.', 'bit-pi'),
        ];
    }

    public function getNotifications()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'user_id' => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('bp_notifications_get_notifications_for_user')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Notifications component is not active.', 'bit-pi'),
            ];
        }

        $notifications = bp_notifications_get_notifications_for_user(
            absint($fieldMappings['user_id']),
            'object'
        );

        if (is_array($notifications) && !empty($fieldMappings['is_new'])) {
            $notifications = array_filter(
                $notifications,
                function ($notification) use ($fieldMappings) {
                    $isNew = (int) $fieldMappings['is_new'];

                    return $notification->is_new === $isNew;
                }
            );
            $notifications = array_values($notifications);
        }

        $result = [];
        if (!empty($notifications)) {
            foreach ($notifications as $notification) {
                $result[] = BuddyPressHelper::extractObjectAttributes($notification);
            }
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => $result,
        ];
    }
}
