<?php

namespace BitApps\PiPro\src\Integrations\BuddyPress\Services;

use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\BuddyPress\helper\BuddyPressHelper;

if (!\defined('ABSPATH')) {
    exit;
}

final class ActivityService extends BaseService
{
    public function createActivity()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'component' => ['required', 'string'],
            'type'      => ['required', 'string'],
            'content'   => ['required', 'string'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('bp_activity_add')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Activity functions not found.', 'bit-pi'),
            ];
        }

        $userId = 0;

        if (!empty($fieldMappings['user_email'])) {
            $userId = email_exists($fieldMappings['user_email']);
        }

        if (empty($userId)) {
            $userId = get_current_user_id();
        }

        $args = [
            'user_id'    => $userId,
            'component'  => $fieldMappings['component'],
            'type'       => $fieldMappings['type'],
            'content'    => $fieldMappings['content'],
            'action'     => $fieldMappings['action'] ?? '',
            'primary_link' => $fieldMappings['primary_link'] ?? '',
            'item_id'      => isset($fieldMappings['item_id']) ? absint($fieldMappings['item_id']) : false,
            'secondary_item_id' => isset($fieldMappings['secondary_item_id']) ? absint($fieldMappings['secondary_item_id']) : false,
            'hide_sitewide'  => !empty($fieldMappings['hide_sitewide']),
        ];

        $activityId = bp_activity_add($args);

        if (!$activityId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to create activity.', 'bit-pi'),
            ];
        }

        $response = ['activity_id' => $activityId];

        if (\function_exists('bp_activity_get_specific')) {
            $activity = bp_activity_get_specific(['activity_ids' => $activityId]);

            if (!empty($activity['activities'][0])) {
                $response['activity'] = BuddyPressHelper::extractObjectAttributes($activity['activities'][0]);
            }
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => $response,
        ];
    }

    public function createActivityComment()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'activity_id' => ['required', 'integer'],
            'content'     => ['required', 'string'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('bp_activity_new_comment')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Activity functions not found.', 'bit-pi'),
            ];
        }

        $userId = 0;

        if (!empty($fieldMappings['user_email'])) {
            $userId = email_exists($fieldMappings['user_email']);
        }

        if (empty($userId)) {
            $userId = get_current_user_id();
        }

        $args = [
            'activity_id' => absint($fieldMappings['activity_id']),
            'content'     => $fieldMappings['content'],
            'user_id'     => $userId,
            'parent_id'   => isset($fieldMappings['parent_id']) ? absint($fieldMappings['parent_id']) : absint($fieldMappings['activity_id']),
        ];

        $commentId = bp_activity_new_comment($args);

        if (!$commentId || \is_wp_error($commentId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => \is_wp_error($commentId) ? $commentId->get_error_message() : __('Failed to create activity comment.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => ['comment_id' => $commentId, 'activity_id' => $args['activity_id']],
        ];
    }

    public function favoriteActivity()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'activity_id' => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('bp_activity_add_user_favorite')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Activity functions not found.', 'bit-pi'),
            ];
        }

        $userId = !empty($fieldMappings['user_email']) ? email_exists($fieldMappings['user_email']) : get_current_user_id();

        if (!$userId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User not found.', 'bit-pi'),
            ];
        }

        $result = bp_activity_add_user_favorite(absint($fieldMappings['activity_id']), $userId);

        return [
            'status_code' => $result ? 200 : 400,
            'payload'     => $fieldMappings,
            'response'    => $result ? __('Activity favorited.', 'bit-pi') : __('Failed to favorite activity.', 'bit-pi'),
        ];
    }

    public function deleteActivity()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'activity_id' => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('bp_activity_delete_by_activity_id')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Activity functions not found.', 'bit-pi'),
            ];
        }

        $result = bp_activity_delete_by_activity_id(absint($fieldMappings['activity_id']));

        return [
            'status_code' => $result ? 200 : 400,
            'payload'     => $fieldMappings,
            'response'    => $result ? __('Activity deleted.', 'bit-pi') : __('Failed to delete activity.', 'bit-pi'),
        ];
    }

    public function getActivity()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        if (!\function_exists('bp_activity_get')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Activity functions not found.', 'bit-pi'),
            ];
        }

        $args = ['max' => isset($fieldMappings['max']) ? absint($fieldMappings['max']) : 20];

        if (!empty($fieldMappings['user_id'])) {
            $args['filter']['user_id'] = absint($fieldMappings['user_id']);
        }

        if (!empty($fieldMappings['component'])) {
            $args['filter']['component'] = $fieldMappings['component'];
        }

        if (!empty($fieldMappings['type'])) {
            $args['filter']['type'] = $fieldMappings['type'];
        }

        if (!empty($fieldMappings['item_id'])) {
            $args['filter']['item_id'] = absint($fieldMappings['item_id']);
        }

        $activities = bp_activity_get($args);

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => array_map([BuddyPressHelper::class, 'extractObjectAttributes'], $activities['activities'] ?? []),
        ];
    }

    public function getActivityById()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'activity_ids' => ['required', 'string'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('bp_activity_get_specific')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Activity functions not found.', 'bit-pi'),
            ];
        }

        $ids = array_map('absint', explode(',', $fieldMappings['activity_ids']));
        $result = bp_activity_get_specific(['activity_ids' => $ids]);

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => array_map([BuddyPressHelper::class, 'extractObjectAttributes'], $result['activities'] ?? []),
        ];
    }
}
