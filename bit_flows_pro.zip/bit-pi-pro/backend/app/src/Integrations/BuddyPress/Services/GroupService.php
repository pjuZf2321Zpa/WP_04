<?php

namespace BitApps\PiPro\src\Integrations\BuddyPress\Services;

use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\BuddyPress\helper\BuddyPressHelper;

if (!\defined('ABSPATH')) {
    exit;
}

final class GroupService extends BaseService
{
    public function createGroup()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'name'       => ['required', 'string'],
            'creator_id' => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('groups_create_group')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Groups functions not found.', 'bit-pi'),
            ];
        }

        $args = [
            'name'        => $fieldMappings['name'],
            'creator_id'  => absint($fieldMappings['creator_id']),
            'description' => $fieldMappings['description'] ?? '',
            'slug'        => $fieldMappings['slug'] ?? '',
            'status'      => $fieldMappings['status'] ?? 'public',
            'parent_id'   => isset($fieldMappings['parent_id']) ? absint($fieldMappings['parent_id']) : 0,
            'enable_forum' => isset($fieldMappings['enable_forum']) ? (int) $fieldMappings['enable_forum'] : 0,
        ];

        $groupId = groups_create_group($args);

        if (!$groupId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to create group.', 'bit-pi'),
            ];
        }

        if (!empty($fieldMappings['group_type']) && \function_exists('bp_groups_set_group_type')) {
            bp_groups_set_group_type($groupId, $fieldMappings['group_type']);
        }

        $response = ['group_id' => $groupId];

        if (\function_exists('groups_get_group')) {
            $group = groups_get_group($groupId);
            $response['group'] = BuddyPressHelper::extractObjectAttributes($group);
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => $response,
        ];
    }

    public function updateGroupDetails()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'group_id' => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('groups_edit_base_group_details')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Groups functions not found.', 'bit-pi'),
            ];
        }

        $args = ['group_id' => absint($fieldMappings['group_id'])];

        if (isset($fieldMappings['name'])) {
            $args['name'] = $fieldMappings['name'];
        }

        if (isset($fieldMappings['description'])) {
            $args['description'] = $fieldMappings['description'];
        }

        if (isset($fieldMappings['slug'])) {
            $args['slug'] = $fieldMappings['slug'];
        }

        if (isset($fieldMappings['notify_members'])) {
            $args['notify_members'] = (bool) $fieldMappings['notify_members'];
        }

        $result = groups_edit_base_group_details($args);

        return [
            'status_code' => $result ? 200 : 400,
            'payload'     => $fieldMappings,
            'response'    => $result ? __('Group details updated.', 'bit-pi') : __('Failed to update group details.', 'bit-pi'),
        ];
    }

    public function updateGroupSettings()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'group_id' => ['required', 'integer'],
            'status'   => ['required', 'string'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('groups_edit_group_settings')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Groups functions not found.', 'bit-pi'),
            ];
        }

        $groupId = absint($fieldMappings['group_id']);
        $enableForum = isset($fieldMappings['enable_forum']) ? (bool) $fieldMappings['enable_forum'] : false;
        $status = $fieldMappings['status'];
        $inviteStatus = !empty($fieldMappings['invite_status']) ? $fieldMappings['invite_status'] : false;
        $parentId = isset($fieldMappings['parent_id']) ? absint($fieldMappings['parent_id']) : false;

        $result = groups_edit_group_settings($groupId, $enableForum, $status, $inviteStatus, $parentId);

        return [
            'status_code' => $result ? 200 : 400,
            'payload'     => $fieldMappings,
            'response'    => $result ? __('Group settings updated.', 'bit-pi') : __('Failed to update group settings.', 'bit-pi'),
        ];
    }

    public function deleteGroup()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'group_id' => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('groups_delete_group')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Groups functions not found.', 'bit-pi'),
            ];
        }

        $result = groups_delete_group(absint($fieldMappings['group_id']));

        return [
            'status_code' => $result ? 200 : 400,
            'payload'     => $fieldMappings,
            'response'    => $result ? __('Group deleted.', 'bit-pi') : __('Failed to delete group.', 'bit-pi'),
        ];
    }

    public function joinGroup()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'group_id' => ['required', 'integer'],
            'user_id'  => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('groups_join_group')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Groups functions not found.', 'bit-pi'),
            ];
        }

        $result = groups_join_group(absint($fieldMappings['group_id']), absint($fieldMappings['user_id']));

        return [
            'status_code' => $result ? 200 : 400,
            'payload'     => $fieldMappings,
            'response'    => $result ? __('User joined group.', 'bit-pi') : __('Failed to join group.', 'bit-pi'),
        ];
    }

    public function leaveGroup()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'group_id' => ['required', 'integer'],
            'user_id'  => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('groups_leave_group')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Groups functions not found.', 'bit-pi'),
            ];
        }

        $result = groups_leave_group(absint($fieldMappings['group_id']), absint($fieldMappings['user_id']));

        return [
            'status_code' => $result ? 200 : 400,
            'payload'     => $fieldMappings,
            'response'    => $result ? __('User left group.', 'bit-pi') : __('Failed to leave group.', 'bit-pi'),
        ];
    }

    public function inviteUserToGroup()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'group_id' => ['required', 'integer'],
            'user_id'  => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('groups_invite_user')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Groups functions not found.', 'bit-pi'),
            ];
        }

        $args = [
            'group_id' => absint($fieldMappings['group_id']),
            'user_id'  => absint($fieldMappings['user_id']),
            'content'  => $fieldMappings['message'] ?? '',
        ];

        if (!empty($fieldMappings['inviter_id'])) {
            $args['inviter_id'] = absint($fieldMappings['inviter_id']);
        }

        $result = groups_invite_user($args);

        return [
            'status_code' => $result ? 200 : 400,
            'payload'     => $fieldMappings,
            'response'    => $result ? __('Invitation sent.', 'bit-pi') : __('Failed to send invitation.', 'bit-pi'),
        ];
    }

    public function acceptGroupInvite()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'group_id' => ['required', 'integer'],
            'user_id'  => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('groups_accept_invite')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Groups functions not found.', 'bit-pi'),
            ];
        }

        $result = groups_accept_invite(absint($fieldMappings['user_id']), absint($fieldMappings['group_id']));

        return [
            'status_code' => $result ? 200 : 400,
            'payload'     => $fieldMappings,
            'response'    => $result ? __('Invitation accepted.', 'bit-pi') : __('Failed to accept invitation.', 'bit-pi'),
        ];
    }

    public function removeMemberFromGroup()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'group_id' => ['required', 'integer'],
            'user_id'  => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('groups_remove_member')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Groups functions not found.', 'bit-pi'),
            ];
        }

        $result = groups_remove_member(absint($fieldMappings['user_id']), absint($fieldMappings['group_id']));

        return [
            'status_code' => $result ? 200 : 400,
            'payload'     => $fieldMappings,
            'response'    => $result ? __('Member removed from group.', 'bit-pi') : __('Failed to remove member.', 'bit-pi'),
        ];
    }

    public function promoteMember()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'group_id' => ['required', 'integer'],
            'user_id'  => ['required', 'integer'],
            'status'   => ['required', 'string'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('groups_promote_member')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Groups functions not found.', 'bit-pi'),
            ];
        }

        $result = groups_promote_member(
            absint($fieldMappings['user_id']),
            absint($fieldMappings['group_id']),
            $fieldMappings['status']
        );

        return [
            'status_code' => $result ? 200 : 400,
            'payload'     => $fieldMappings,
            'response'    => $result ? __('Member promoted.', 'bit-pi') : __('Failed to promote member.', 'bit-pi'),
        ];
    }

    public function demoteMember()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'group_id' => ['required', 'integer'],
            'user_id'  => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('groups_demote_member')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Groups functions not found.', 'bit-pi'),
            ];
        }

        $result = groups_demote_member(absint($fieldMappings['user_id']), absint($fieldMappings['group_id']));

        return [
            'status_code' => $result ? 200 : 400,
            'payload'     => $fieldMappings,
            'response'    => $result ? __('Member demoted.', 'bit-pi') : __('Failed to demote member.', 'bit-pi'),
        ];
    }

    public function banMember()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'group_id' => ['required', 'integer'],
            'user_id'  => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('groups_ban_member')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Groups functions not found.', 'bit-pi'),
            ];
        }

        $result = groups_ban_member(absint($fieldMappings['user_id']), absint($fieldMappings['group_id']));

        return [
            'status_code' => $result ? 200 : 400,
            'payload'     => $fieldMappings,
            'response'    => $result ? __('Member banned.', 'bit-pi') : __('Failed to ban member.', 'bit-pi'),
        ];
    }

    public function unbanMember()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'group_id' => ['required', 'integer'],
            'user_id'  => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('groups_unban_member')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Groups functions not found.', 'bit-pi'),
            ];
        }

        $result = groups_unban_member(absint($fieldMappings['user_id']), absint($fieldMappings['group_id']));

        return [
            'status_code' => $result ? 200 : 400,
            'payload'     => $fieldMappings,
            'response'    => $result ? __('Member unbanned.', 'bit-pi') : __('Failed to unban member.', 'bit-pi'),
        ];
    }

    public function sendMembershipRequest()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'group_id' => ['required', 'integer'],
            'user_id'  => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('groups_send_membership_request')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Groups functions not found.', 'bit-pi'),
            ];
        }

        $args = [
            'user_id'  => absint($fieldMappings['user_id']),
            'group_id' => absint($fieldMappings['group_id']),
            'content'  => $fieldMappings['message'] ?? '',
        ];

        $result = groups_send_membership_request($args);

        return [
            'status_code' => $result ? 200 : 400,
            'payload'     => $fieldMappings,
            'response'    => $result ? __('Membership request sent.', 'bit-pi') : __('Failed to send membership request.', 'bit-pi'),
        ];
    }

    public function acceptMembershipRequest()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'group_id' => ['required', 'integer'],
            'user_id'  => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('groups_accept_membership_request')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Groups functions not found.', 'bit-pi'),
            ];
        }

        $result = groups_accept_membership_request(0, absint($fieldMappings['user_id']), absint($fieldMappings['group_id']));

        return [
            'status_code' => $result ? 200 : 400,
            'payload'     => $fieldMappings,
            'response'    => $result ? __('Membership request accepted.', 'bit-pi') : __('Failed to accept membership request.', 'bit-pi'),
        ];
    }

    public function getGroup()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'group_id' => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('groups_get_group')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Groups functions not found.', 'bit-pi'),
            ];
        }

        $group = groups_get_group(absint($fieldMappings['group_id']));

        if (empty($group->id)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Group not found.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => BuddyPressHelper::extractObjectAttributes($group),
        ];
    }

    public function listGroups()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        if (!\function_exists('groups_get_groups')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Groups functions not found.', 'bit-pi'),
            ];
        }

        $args = [
            'max'   => !empty($fieldMappings['max']) ? absint($fieldMappings['max']) : 20,
        ];

        if (!empty($fieldMappings['user_id'])) {
            $args['user_id'] = absint($fieldMappings['user_id']);
        }

        if (!empty($fieldMappings['search_terms'])) {
            $args['search_terms'] = sanitize_text_field($fieldMappings['search_terms']);
        }

        $result = groups_get_groups($args);
        $groups = [];

        if (!empty($result['groups'])) {
            foreach ($result['groups'] as $group) {
                $groups[] = BuddyPressHelper::extractObjectAttributes($group);
            }
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => $groups,
        ];
    }

    public function getGroupMembers()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'group_id' => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('groups_get_group_members')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Groups functions not found.', 'bit-pi'),
            ];
        }

        $members = groups_get_group_members(['group_id' => absint($fieldMappings['group_id'])]);

        if (empty($members['members'])) {
            return [
                'status_code' => 200,
                'payload'     => $fieldMappings,
                'response'    => [],
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => array_map([BuddyPressHelper::class, 'extractObjectAttributes'], array_values($members['members'])),
        ];
    }
}
