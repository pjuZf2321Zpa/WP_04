<?php

namespace BitApps\PiPro\src\Integrations\BuddyPress\Services;

use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\BuddyPress\helper\BuddyPressHelper;

if (!\defined('ABSPATH')) {
    exit;
}

final class ProfileService extends BaseService
{
    public function setProfileFieldData()
    {
        $fieldData = $this->nodeInfoProvider->getFieldMapData();
        $fieldMappings = $this->nodeInfoProvider->getFieldMapRepeaters('field-map.value', false, true, 'field', 'value');
        $userEmail = $fieldData['user_email'] ?? '';

        if (empty($userEmail)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User email is required.', 'bit-pi'),
            ];
        }

        if (empty($fieldMappings)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('At least one field mapping is required.', 'bit-pi'),
            ];
        }

        if (!\function_exists('xprofile_set_field_data')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Extended Profile functions not found.', 'bit-pi'),
            ];
        }

        $userId = email_exists($userEmail);

        if (empty($userId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User not found with provided email.', 'bit-pi'),
            ];
        }

        $updatedFields = [];
        foreach ($fieldMappings as $fieldId => $value) {
            xprofile_set_field_data(absint($fieldId), $userId, $value);

            if (\function_exists('xprofile_get_field_data')) {
                $updatedFields[$fieldId] = xprofile_get_field_data(absint($fieldId), $userId);
            }
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => ['updated_fields' => $updatedFields],
        ];
    }

    public function deleteProfileFieldData()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'field_id' => ['required', 'integer'],
            'user_id'  => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('xprofile_delete_field_data')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Extended Profile functions not found.', 'bit-pi'),
            ];
        }

        $result = xprofile_delete_field_data($fieldMappings['field_id'], absint($fieldMappings['user_id']));

        return [
            'status_code' => $result ? 200 : 400,
            'payload'     => $fieldMappings,
            'response'    => $result ? __('Profile field data deleted.', 'bit-pi') : __('Failed to delete profile field data.', 'bit-pi'),
        ];
    }

    public function getProfileFieldData()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'field_id' => ['required', 'integer'],
            'user_id'  => ['required', 'integer'],
        ];

        $validatedFieldMap = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!\function_exists('xprofile_get_field_data')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyPress Extended Profile functions not found.', 'bit-pi'),
            ];
        }

        $fieldData = xprofile_get_field_data(
            absint($fieldMappings['field_id']),
            absint($fieldMappings['user_id'])
        );

        if (empty($fieldData)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('No field data found.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => ['field_data' => $fieldData],
        ];
    }
}
