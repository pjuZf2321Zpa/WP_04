<?php

namespace BitApps\PiPro\src\Integrations\BuddyPress;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!\defined('ABSPATH')) {
    exit;
}

class BuddyPressHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'activityCreated' => [
                'hook'     => 'bp_activity_after_save',
                'callback' => [BuddyPressTrigger::class, 'activityCreated'],
            ],
            'activityUpdatePosted' => [
                'hook'          => 'bp_activity_posted_update',
                'callback'      => [BuddyPressTrigger::class, 'activityUpdatePosted'],
                'accepted_args' => 3,
            ],
            'activityFavorited' => [
                'hook'          => 'bp_activity_add_user_favorite',
                'callback'      => [BuddyPressTrigger::class, 'activityFavorited'],
                'accepted_args' => 2,
            ],
            'activityUnfavorited' => [
                'hook'          => 'bp_activity_remove_user_favorite',
                'callback'      => [BuddyPressTrigger::class, 'activityUnfavorited'],
                'accepted_args' => 2,
            ],
            'activityDeleted' => [
                'hook'     => 'bp_activity_deleted_activities',
                'callback' => [BuddyPressTrigger::class, 'activityDeleted'],
            ],
            'groupCreated' => [
                'hook'          => 'groups_create_group',
                'callback'      => [BuddyPressTrigger::class, 'groupCreated'],
                'accepted_args' => 3,
            ],
            'groupUpdated' => [
                'hook'          => 'groups_update_group',
                'callback'      => [BuddyPressTrigger::class, 'groupUpdated'],
                'accepted_args' => 2,
            ],
            'groupDeleted' => [
                'hook'     => 'groups_delete_group',
                'callback' => [BuddyPressTrigger::class, 'groupDeleted'],
            ],
            'groupMemberJoined' => [
                'hook'          => 'groups_join_group',
                'callback'      => [BuddyPressTrigger::class, 'groupMemberJoined'],
                'accepted_args' => 2,
            ],
            'groupMemberLeft' => [
                'hook'          => 'groups_leave_group',
                'callback'      => [BuddyPressTrigger::class, 'groupMemberLeft'],
                'accepted_args' => 2,
            ],
            'groupMemberPromoted' => [
                'hook'          => 'groups_promote_member',
                'callback'      => [BuddyPressTrigger::class, 'groupMemberPromoted'],
                'accepted_args' => 3,
            ],
            'groupMemberDemoted' => [
                'hook'          => 'groups_demote_member',
                'callback'      => [BuddyPressTrigger::class, 'groupMemberDemoted'],
                'accepted_args' => 2,
            ],
            'groupMemberBanned' => [
                'hook'          => 'groups_ban_member',
                'callback'      => [BuddyPressTrigger::class, 'groupMemberBanned'],
                'accepted_args' => 2,
            ],
            'groupMemberUnbanned' => [
                'hook'          => 'groups_unban_member',
                'callback'      => [BuddyPressTrigger::class, 'groupMemberUnbanned'],
                'accepted_args' => 2,
            ],
            'groupMemberRemoved' => [
                'hook'          => 'groups_remove_member',
                'callback'      => [BuddyPressTrigger::class, 'groupMemberRemoved'],
                'accepted_args' => 2,
            ],
            'groupInviteSent' => [
                'hook'          => 'groups_invite_user',
                'callback'      => [BuddyPressTrigger::class, 'groupInviteSent'],
                'accepted_args' => 2,
            ],
            'groupInviteAccepted' => [
                'hook'          => 'groups_accept_invite',
                'callback'      => [BuddyPressTrigger::class, 'groupInviteAccepted'],
                'accepted_args' => 2,
            ],
            'groupMembershipRequested' => [
                'hook'          => 'groups_membership_requested',
                'callback'      => [BuddyPressTrigger::class, 'groupMembershipRequested'],
                'accepted_args' => 3,
            ],
            'groupMembershipAccepted' => [
                'hook'          => 'groups_membership_accepted',
                'callback'      => [BuddyPressTrigger::class, 'groupMembershipAccepted'],
                'accepted_args' => 2,
            ],
            'friendshipRequested' => [
                'hook'          => 'friends_friendship_requested',
                'callback'      => [BuddyPressTrigger::class, 'friendshipRequested'],
                'accepted_args' => 3,
            ],
            'friendshipAccepted' => [
                'hook'          => 'friends_friendship_accepted',
                'callback'      => [BuddyPressTrigger::class, 'friendshipAccepted'],
                'accepted_args' => 4,
            ],
            'friendshipDeleted' => [
                'hook'          => 'friends_friendship_deleted',
                'callback'      => [BuddyPressTrigger::class, 'friendshipDeleted'],
                'accepted_args' => 3,
            ],
            'messageSent' => [
                'hook'     => 'messages_message_sent',
                'callback' => [BuddyPressTrigger::class, 'messageSent'],
            ],
            'threadDeleted' => [
                'hook'          => 'messages_delete_thread',
                'callback'      => [BuddyPressTrigger::class, 'threadDeleted'],
                'accepted_args' => 2,
            ],
            'threadMarkedRead' => [
                'hook'          => 'messages_thread_mark_as_read',
                'callback'      => [BuddyPressTrigger::class, 'threadMarkedRead'],
                'accepted_args' => 2,
            ],
            'noticeSent' => [
                'hook'          => 'messages_send_notice',
                'callback'      => [BuddyPressTrigger::class, 'noticeSent'],
                'accepted_args' => 3,
            ],
            'notificationAfterSave' => [
                'hook'     => 'bp_notification_after_save',
                'callback' => [BuddyPressTrigger::class, 'notificationAfterSave'],
            ],
            'profileUpdated' => [
                'hook'          => 'xprofile_updated_profile',
                'callback'      => [BuddyPressTrigger::class, 'profileUpdated'],
                'accepted_args' => 5,
            ],
            'profileFieldSaved' => [
                'hook'     => 'xprofile_field_after_save',
                'callback' => [BuddyPressTrigger::class, 'profileFieldSaved'],
            ],
            'userActivated' => [
                'hook'          => 'bp_core_activated_user',
                'callback'      => [BuddyPressTrigger::class, 'userActivated'],
                'accepted_args' => 3,
            ],
            'userDeleted' => [
                'hook'     => 'bp_core_deleted_account',
                'callback' => [BuddyPressTrigger::class, 'userDeleted'],
            ],
            'memberTypeSet' => [
                'hook'          => 'bp_set_member_type',
                'callback'      => [BuddyPressTrigger::class, 'memberTypeSet'],
                'accepted_args' => 3,
            ],
            'memberTypeRemoved' => [
                'hook'          => 'bp_remove_member_type',
                'callback'      => [BuddyPressTrigger::class, 'memberTypeRemoved'],
                'accepted_args' => 2,
            ],
            'generalSettingsSaved' => [
                'hook'          => 'bp_core_general_settings_after_save',
                'callback'      => [BuddyPressTrigger::class, 'generalSettingsSaved'],
                'accepted_args' => 2,
            ],
            'blogPostPublished' => [
                'hook'          => 'bp_blogs_new_blog_post',
                'callback'      => [BuddyPressTrigger::class, 'blogPostPublished'],
                'accepted_args' => 3,
            ],
            'blogCommentAdded' => [
                'hook'          => 'bp_blogs_new_blog_comment',
                'callback'      => [BuddyPressTrigger::class, 'blogCommentAdded'],
                'accepted_args' => 3,
            ],
        ];
    }
}
