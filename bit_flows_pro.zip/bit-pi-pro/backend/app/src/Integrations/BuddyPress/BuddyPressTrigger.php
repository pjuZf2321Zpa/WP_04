<?php

namespace BitApps\PiPro\src\Integrations\BuddyPress;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\BuddyPress\helper\BuddyPressHelper;

if (!\defined('ABSPATH')) {
    exit;
}

final class BuddyPressTrigger
{
    public static function activityCreated($activity)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        $data = ['activity' => BuddyPressHelper::extractObjectAttributes($activity)];

        self::execute('activityCreated', $data);
    }

    public static function activityUpdatePosted($content, $userId, $activityId)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        $data = [
            'content'     => $content,
            'user'        => Utility::getUserInfo($userId),
            'activity_id' => $activityId,
        ];

        self::execute('activityUpdatePosted', $data);
    }

    public static function activityFavorited($activityId, $userId)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        $data = [
            'activity_id' => $activityId,
            'user'        => Utility::getUserInfo($userId),
        ];

        self::execute('activityFavorited', $data);
    }

    public static function activityUnfavorited($activityId, $userId)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        $data = [
            'activity_id' => $activityId,
            'user'        => Utility::getUserInfo($userId),
        ];

        self::execute('activityUnfavorited', $data);
    }

    public static function activityDeleted($activityIds)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        $data = ['activity_ids' => $activityIds];

        self::execute('activityDeleted', $data);
    }

    public static function groupCreated($groupId, $member, $group)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        $data = self::getGroupWithUserData($groupId, $group->creator_id ?? 0);

        self::execute('groupCreated', $data);
    }

    public static function groupUpdated($groupId, $group)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        $data = [

            'group_id' => $groupId,
            'group'    => BuddyPressHelper::extractObjectAttributes($group),
        ];

        self::execute('groupUpdated', $data);
    }

    public static function groupDeleted($groupId)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        $data = ['group_id' => $groupId];

        self::execute('groupDeleted', $data);
    }

    public static function groupMemberJoined($groupId, $userId)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        self::execute('groupMemberJoined', self::getGroupWithUserData($groupId, $userId));
    }

    public static function groupMemberLeft($groupId, $userId)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        self::execute('groupMemberLeft', self::getGroupWithUserData($groupId, $userId));
    }

    public static function groupMemberPromoted($groupId, $userId, $status)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        $data = self::getGroupWithUserData($groupId, $userId);
        $data['new_status'] = $status;

        self::execute('groupMemberPromoted', $data);
    }

    public static function groupMemberDemoted($groupId, $userId)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        self::execute('groupMemberDemoted', self::getGroupWithUserData($groupId, $userId));
    }

    public static function groupMemberBanned($groupId, $userId)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        self::execute('groupMemberBanned', self::getGroupWithUserData($groupId, $userId));
    }

    public static function groupMemberUnbanned($groupId, $userId)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        self::execute('groupMemberUnbanned', self::getGroupWithUserData($groupId, $userId));
    }

    public static function groupMemberRemoved($groupId, $userId)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        self::execute('groupMemberRemoved', self::getGroupWithUserData($groupId, $userId));
    }

    public static function groupInviteSent($r, $created)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        $data = [
            'invitation_id' => $created,
            'group'         => isset($r['group_id']) && \function_exists('groups_get_group') ? BuddyPressHelper::extractObjectAttributes(groups_get_group($r['group_id'])) : [],
            'user'          => isset($r['user_id']) ? Utility::getUserInfo($r['user_id']) : [],
            'inviter'       => isset($r['inviter_id']) ? Utility::getUserInfo($r['inviter_id']) : [],
        ];

        self::execute('groupInviteSent', $data);
    }

    public static function groupInviteAccepted($userId, $groupId)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        self::execute('groupInviteAccepted', self::getGroupWithUserData($groupId, $userId));
    }

    public static function groupMembershipRequested($userId, $admins, $groupId)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        $data = self::getGroupWithUserData($groupId, $userId);
        $data['admins'] = array_map(
            function ($adminId) {
                return Utility::getUserInfo($adminId);
            },
            $admins
        );

        self::execute('groupMembershipRequested', $data);
    }

    public static function groupMembershipAccepted($userId, $groupId)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        self::execute('groupMembershipAccepted', self::getGroupWithUserData($groupId, $userId));
    }

    public static function friendshipRequested($friendshipId, $initiatorUserId, $friendUserId)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        $data = [
            'friendship_id' => $friendshipId,
            'initiator'     => Utility::getUserInfo($initiatorUserId),
            'friend'        => Utility::getUserInfo($friendUserId),
        ];

        self::execute('friendshipRequested', $data);
    }

    public static function friendshipAccepted($id, $initiatorUserId, $friendUserId, $friendship)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        $data = [
            'friendship_id' => $id,
            'initiator'     => Utility::getUserInfo($initiatorUserId),
            'friend'        => Utility::getUserInfo($friendUserId),
            'friendship'    => BuddyPressHelper::extractObjectAttributes($friendship),
        ];

        self::execute('friendshipAccepted', $data);
    }

    public static function friendshipDeleted($friendshipId, $initiatorUserId, $friendUserId)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        $data = [
            'friendship_id' => $friendshipId,
            'initiator'     => Utility::getUserInfo($initiatorUserId),
            'friend'        => Utility::getUserInfo($friendUserId),
        ];

        self::execute('friendshipDeleted', $data);
    }

    public static function messageSent($message)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        $data = [
            'message' => BuddyPressHelper::extractObjectAttributes($message),
            'sender'  => isset($message->sender_id) ? Utility::getUserInfo($message->sender_id) : null,
        ];

        if (!empty($message->recipients)) {
            $recipients = [];
            foreach ($message->recipients as $recipient) {
                if (isset($recipient->user_id)) {
                    $recipients[] = Utility::getUserInfo($recipient->user_id);
                }
            }
            $data['recipients'] = $recipients;
        }

        self::execute('messageSent', $data);
    }

    public static function threadDeleted($threadIds, $userId)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        $data = [
            'thread_ids' => \is_array($threadIds) ? $threadIds : [$threadIds],
            'user'       => Utility::getUserInfo($userId),
        ];

        self::execute('threadDeleted', $data);
    }

    public static function threadMarkedRead($threadId, $userId)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        $data = [
            'thread_id' => $threadId,
            'user'      => Utility::getUserInfo($userId),
        ];

        self::execute('threadMarkedRead', $data);
    }

    public static function noticeSent($subject, $message, $notice)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        $data = [
            'subject' => $subject,
            'message' => $message,
            'notice'  => BuddyPressHelper::extractObjectAttributes($notice),
        ];

        self::execute('noticeSent', $data);
    }

    public static function notificationAfterSave($notification)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        $data = [
            'notification'    => BuddyPressHelper::extractObjectAttributes($notification),
            'is_new'          => $notification->is_new ?? 1,
            'component_name'  => $notification->component_name ?? '',
            'component_action' => $notification->component_action ?? '',
        ];

        if (isset($notification->user_id)) {
            $data['user'] = Utility::getUserInfo($notification->user_id);
        }

        self::execute('notificationAfterSave', $data);
    }

    public static function profileUpdated($userId, $postedFieldIds, $errors, $oldValues, $newValues)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        $data = [
            'user'             => Utility::getUserInfo($userId),
            'posted_field_ids' => $postedFieldIds,
            'errors'           => $errors,
            'old_values'       => $oldValues,
            'new_values'       => $newValues,
        ];

        if (\function_exists('xprofile_get_field')) {
            $postedFields = [];
            foreach ($postedFieldIds as $fieldId) {
                $field = xprofile_get_field($fieldId);
                if ($field && isset($newValues[$fieldId])) {
                    $postedFields[$field->name] = $newValues[$fieldId];
                }
            }
            $data['posted_fields'] = $postedFields;
        }

        self::execute('profileUpdated', $data);
    }

    public static function profileFieldSaved($field)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        $data = ['field' => BuddyPressHelper::extractObjectAttributes($field)];

        self::execute('profileFieldSaved', $data);
    }

    public static function userActivated($userId)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        $data = Utility::getUserInfo($userId);

        self::execute('userActivated', $data);
    }

    public static function userDeleted($userId)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        $data = ['user_id' => $userId];

        self::execute('userDeleted', $data);
    }

    public static function memberTypeSet($userId, $memberType, $append)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        $data = Utility::getUserInfo($userId);
        $data['member_type'] = $memberType;
        $data['append'] = $append;

        self::execute('memberTypeSet', $data);
    }

    public static function memberTypeRemoved($userId, $memberType)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        $data = Utility::getUserInfo($userId);
        $data['removed_type'] = $memberType;

        self::execute('memberTypeRemoved', $data);
    }

    public static function generalSettingsSaved($userId, $redirectTo)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        $data = [
            'user'        => Utility::getUserInfo($userId),
            'redirect_to' => $redirectTo,
        ];

        self::execute('generalSettingsSaved', $data);
    }

    public static function blogPostPublished($postId, $post, $userId)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        $data = [
            'post_id' => $postId,
            'post'    => BuddyPressHelper::extractObjectAttributes($post),
            'user'    => Utility::getUserInfo($userId),
        ];

        self::execute('blogPostPublished', $data);
    }

    public static function blogCommentAdded($commentId, $comment, $userId)
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return;
        }

        $data = [
            'comment_id' => $commentId,
            'comment'    => BuddyPressHelper::extractObjectAttributes($comment),
            'user'       => Utility::getUserInfo($userId),
        ];

        self::execute('blogCommentAdded', $data);
    }

    private static function getGroupWithUserData($groupId, $userId)
    {
        $data = [];
        $data['user'] = Utility::getUserInfo($userId);

        if (\function_exists('groups_get_group')) {
            $group = groups_get_group($groupId);

            if ($group) {
                $data['group'] = BuddyPressHelper::extractObjectAttributes($group);

                if (\function_exists('bp_groups_get_group_type')) {
                    $data['group']['type'] = bp_groups_get_group_type($groupId, false);
                }

                if (\function_exists('bp_get_group_cover_url')) {
                    $data['group']['cover_url'] = bp_get_group_cover_url($group);
                }

                if (\function_exists('bp_get_group_avatar_url')) {
                    $data['group']['avatar_url'] = bp_get_group_avatar_url($group);
                }

                if (isset($group->creator_id)) {
                    $data['group']['creator'] = Utility::getUserInfo($group->creator_id);
                }
            }
        }

        return $data;
    }

    private static function execute($machineSlug, $data)
    {
        $flows = FlowService::exists('buddyPress', $machineSlug);

        if (!$flows) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $data);
    }
}
