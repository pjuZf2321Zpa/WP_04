<?php

if (!\defined('ABSPATH')) {
    exit;
}

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\PiPro\src\Integrations\BuddyPress\helper\BuddyPressHelper;

Route::group(
    function () {
        Route::post('buddypress/get-all-groups', [BuddyPressHelper::class, 'getAllGroups']);
        Route::post('buddypress/get-all-member-types', [BuddyPressHelper::class, 'getAllMemberTypes']);
        Route::post('buddypress/get-all-group-types', [BuddyPressHelper::class, 'getAllGroupTypes']);
        Route::post('buddypress/get-extended-profile-fields', [BuddyPressHelper::class, 'getExtendedProfileFields']);
        Route::post('buddypress/get-all-users', [BuddyPressHelper::class, 'getAllUsers']);
        Route::post('buddypress/get-all-activities', [BuddyPressHelper::class, 'getAllActivities']);
    }
)->middleware('nonce:admin');
