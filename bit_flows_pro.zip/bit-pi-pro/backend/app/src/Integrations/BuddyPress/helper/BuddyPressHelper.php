<?php

namespace BitApps\PiPro\src\Integrations\BuddyPress\helper;

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Response;

if (!defined('ABSPATH')) {
    exit;
}

final class BuddyPressHelper
{
    public static function isPluginInstalled()
    {
        return class_exists('BuddyPress');
    }

    public static function extractObjectAttributes($object)
    {
        if (!\is_object($object)) {
            return $object;
        }

        if (method_exists($object, 'getAttributes')) {
            return $object->getAttributes();
        }

        if (method_exists($object, 'toArray')) {
            return $object->toArray();
        }

        return get_object_vars($object);
    }

    public static function getAllGroups()
    {
        if (!self::isPluginInstalled()) {
            return Response::error(__('BuddyPress plugin is not active.', 'bit-pi'));
        }

        if (!\function_exists('groups_get_groups')) {
            return Response::error(__('BuddyPress Groups functions not found.', 'bit-pi'));
        }

        $groupsData = groups_get_groups();
        $groups = $groupsData['groups'] ?? [];

        $data = array_map(
            function ($group) {
                return [
                    'label' => $group->name,
                    'value' => $group->id,
                ];
            },
            $groups
        );

        return Response::success($data);
    }

    public static function getAllMemberTypes()
    {
        if (!self::isPluginInstalled()) {
            return Response::error(__('BuddyPress plugin is not active.', 'bit-pi'));
        }

        if (!\function_exists('bp_get_member_types')) {
            return Response::error(__('BuddyPress Member Type functions not found.', 'bit-pi'));
        }

        $types = bp_get_member_types([], 'objects');
        $data = [];

        foreach ($types as $key => $type) {
            $data[] = [
                'label' => $type->labels['name'],
                'value' => $key,
            ];
        }

        return Response::success($data);
    }

    public static function getAllGroupTypes()
    {
        if (!self::isPluginInstalled()) {
            return Response::error(__('BuddyPress plugin is not active.', 'bit-pi'));
        }

        if (!\function_exists('bp_groups_get_group_types')) {
            return Response::error(__('BuddyPress Group type functions not found.', 'bit-pi'));
        }

        $types = bp_groups_get_group_types([], 'objects');
        $data = [];

        foreach ($types as $key => $type) {
            $data[] = [
                'label' => $type->labels['name'],
                'value' => $key,
            ];
        }

        return Response::success($data);
    }

    public static function getExtendedProfileFields()
    {
        if (!self::isPluginInstalled()) {
            return Response::error(__('BuddyPress plugin is not active.', 'bit-pi'));
        }

        if (!\function_exists('bp_xprofile_get_groups')) {
            return Response::error(__('BuddyPress Extended Profile functions not found.', 'bit-pi'));
        }

        $groups = bp_xprofile_get_groups(['fetch_fields' => true]);
        $data = [];

        foreach ($groups as $group) {
            if (empty($group->fields)) {
                continue;
            }

            $items = array_map(
                function ($field) {
                    return [
                        'value' => $field->id,
                        'label' => $field->name,
                    ];
                },
                $group->fields
            );

            $data = array_merge($data, $items);
        }

        return Response::success($data);
    }

    public static function getAllUsers()
    {
        if (!self::isPluginInstalled()) {
            return Response::error(__('BuddyPress plugin is not active.', 'bit-pi'));
        }

        $data = array_map(
            function ($user) {
                return [
                    'value' => $user->ID,
                    'label' => $user->display_name . ' (' . $user->user_email . ')',
                ];
            },
            get_users()
        );

        return Response::success($data);
    }

    public static function getAllActivities()
    {
        if (!self::isPluginInstalled()) {
            return Response::error(__('BuddyPress plugin is not active.', 'bit-pi'));
        }

        if (!\function_exists('bp_activity_get')) {
            return Response::error(__('BuddyPress Activity functions not found.', 'bit-pi'));
        }

        $activitiesData = bp_activity_get();
        $activities = $activitiesData['activities'] ?? [];

        $data = array_map(
            function ($activity) {
                $label = isset($activity->action) ? wp_strip_all_tags($activity->action) : 'Activity #' . $activity->id;

                return [
                    'value' => $activity->id,
                    'label' => mb_strlen($label) > 80 ? mb_substr($label, 0, 77) . '...' : $label,
                ];
            },
            $activities
        );

        return Response::success($data);
    }
}
