<?php

namespace BitApps\PiPro\src\Integrations\BuddyPress;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\Pi\src\Interfaces\ActionInterface;
use BitApps\PiPro\src\Integrations\BuddyPress\helper\BuddyPressHelper;

if (!\defined('ABSPATH')) {
    exit;
}

class BuddyPressAction implements ActionInterface
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeBuddyPressAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'] ?? 200,
            $executedNodeAction['payload'] ?? [],
            $executedNodeAction['response'] ?? []
        );
    }

    private function executeBuddyPressAction()
    {
        if (!BuddyPressHelper::isPluginInstalled()) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('BuddyPress plugin is not active.', 'bit-pi'),
            ];
        }

        $machineSlug = $this->nodeInfoProvider->getMachineSlug();

        $serviceInstance = IntegrationHelper::getServiceInstanceByMachineSlug(
            $machineSlug,
            $this->nodeInfoProvider
        );

        if (!$serviceInstance) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('BuddyPress service not found for the given machine slug.', 'bit-pi'),
            ];
        }

        return $serviceInstance->{$machineSlug}();
    }
}
