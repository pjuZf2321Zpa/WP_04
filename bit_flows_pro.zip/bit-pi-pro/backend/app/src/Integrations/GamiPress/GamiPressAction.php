<?php

namespace BitApps\PiPro\src\Integrations\GamiPress;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;

if (!\defined('ABSPATH')) {
    exit;
}

class GamiPressAction implements ActionInterface
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeGamiPressAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'] ?? 200,
            $executedNodeAction['payload'] ?? [],
            $executedNodeAction['response'] ?? []
        );
    }

    private function executeGamiPressAction()
    {
        if (!GamiPressHelper::isPluginActive()) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('GamiPress plugin is not active.', 'bit-pi'),
            ];
        }

        $gamiPressService = new GamiPressService($this->nodeInfoProvider);
        $machineSlug = $this->nodeInfoProvider->getMachineSlug();

        if (!method_exists($gamiPressService, $machineSlug)) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('GamiPress action not found.', 'bit-pi'),
            ];
        }

        return $gamiPressService->{$machineSlug}();
    }
}
