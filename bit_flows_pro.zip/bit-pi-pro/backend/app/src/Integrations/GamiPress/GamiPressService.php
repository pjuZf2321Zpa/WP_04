<?php

namespace BitApps\PiPro\src\Integrations\GamiPress;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;

if (!\defined('ABSPATH')) {
    exit;
}

final class GamiPressService
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function awardRankToUser()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $errors = $this->validate(
            $fieldMappings,
            [
                'user_id' => ['required', 'integer'],
                'rank_id' => ['required', 'integer'],
            ]
        );

        if ($errors) {
            return $errors;
        }

        if (!\function_exists('gamipress_award_rank_to_user')) {
            return $this->error(__('GamiPress award rank function not found.', 'bit-pi'), $fieldMappings);
        }

        $userId = \absint($fieldMappings['user_id']);
        $rankId = \absint($fieldMappings['rank_id']);

        if (!$this->userExists($userId)) {
            return $this->error(__('User not found.', 'bit-pi'), $fieldMappings);
        }

        if (!$this->postExists($rankId)) {
            return $this->error(__('Rank not found.', 'bit-pi'), $fieldMappings);
        }

        gamipress_award_rank_to_user($userId, $rankId, 0, ['admin_id' => \get_current_user_id()]);

        return $this->success(
            $fieldMappings,
            [
                'rank_id' => $rankId,
                'user'    => Utility::getUserInfo($userId),
            ]
        );
    }

    public function awardAchievementToUser()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $errors = $this->validate(
            $fieldMappings,
            [
                'user_id'        => ['required', 'integer'],
                'achievement_id' => ['required', 'integer'],
            ]
        );

        if ($errors) {
            return $errors;
        }

        if (!\function_exists('gamipress_award_achievement_to_user')) {
            return $this->error(__('GamiPress award achievement function not found.', 'bit-pi'), $fieldMappings);
        }

        $userId = \absint($fieldMappings['user_id']);
        $achievementId = \absint($fieldMappings['achievement_id']);

        if (!$this->userExists($userId)) {
            return $this->error(__('User not found.', 'bit-pi'), $fieldMappings);
        }

        if (!$this->postExists($achievementId)) {
            return $this->error(__('Achievement not found.', 'bit-pi'), $fieldMappings);
        }

        gamipress_award_achievement_to_user($achievementId, $userId);

        return $this->success(
            $fieldMappings,
            [
                'achievement_id' => $achievementId,
                'user'           => Utility::getUserInfo($userId),
            ]
        );
    }

    public function awardPointsToUser()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $errors = $this->validate(
            $fieldMappings,
            [
                'user_id'    => ['required', 'integer'],
                'point_type' => ['required', 'string'],
                'points'     => ['required', 'integer'],
            ]
        );

        if ($errors) {
            return $errors;
        }

        if (!\function_exists('gamipress_award_points_to_user') || !\function_exists('gamipress_get_user_points')) {
            return $this->error(__('GamiPress points functions not found.', 'bit-pi'), $fieldMappings);
        }

        $userId = \absint($fieldMappings['user_id']);
        $pointType = \sanitize_text_field($fieldMappings['point_type']);
        $points = \absint($fieldMappings['points']);

        if (!$this->userExists($userId)) {
            return $this->error(__('User not found.', 'bit-pi'), $fieldMappings);
        }

        if ($points <= 0) {
            return $this->error(__('Points must be greater than zero.', 'bit-pi'), $fieldMappings);
        }

        $previousPoints = \intval(gamipress_get_user_points($userId, $pointType));
        gamipress_award_points_to_user($userId, $points, $pointType);
        $newPoints = \intval(gamipress_get_user_points($userId, $pointType));

        return $this->success(
            $fieldMappings,
            [
                'point_type'      => $pointType,
                'points'          => $points,
                'previous_points' => $previousPoints,
                'new_points'      => $newPoints,
                'user'            => Utility::getUserInfo($userId),
            ]
        );
    }

    public function revokeRankFromUser()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $errors = $this->validate(
            $fieldMappings,
            [
                'user_id' => ['required', 'integer'],
                'rank_id' => ['required', 'integer'],
            ]
        );

        if ($errors) {
            return $errors;
        }

        if (!\function_exists('gamipress_get_user_rank_id') || !\function_exists('gamipress_revoke_rank_to_user')) {
            return $this->error(__('GamiPress revoke rank functions not found.', 'bit-pi'), $fieldMappings);
        }

        $userId = \absint($fieldMappings['user_id']);
        $rankId = \absint($fieldMappings['rank_id']);
        $rank = \get_post($rankId);

        if (!$this->userExists($userId)) {
            return $this->error(__('User not found.', 'bit-pi'), $fieldMappings);
        }

        if (!$rank) {
            return $this->error(__('Rank not found.', 'bit-pi'), $fieldMappings);
        }

        $userRankId = gamipress_get_user_rank_id($userId, $rank->post_type);

        if (empty($userRankId) || \intval($userRankId) !== $rankId) {
            return $this->error(__('The user does not have the selected rank.', 'bit-pi'), $fieldMappings);
        }

        gamipress_revoke_rank_to_user($userId, $userRankId, 0, ['admin_id' => \get_current_user_id()]);

        return $this->success(
            $fieldMappings,
            [
                'rank_id' => $rankId,
                'user'    => Utility::getUserInfo($userId),
            ]
        );
    }

    public function revokeAllPointsFromUser()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $errors = $this->validate(
            $fieldMappings,
            [
                'user_id'    => ['required', 'integer'],
                'point_type' => ['required', 'string'],
            ]
        );

        if ($errors) {
            return $errors;
        }

        if (!\function_exists('gamipress_get_user_points') || !\function_exists('gamipress_deduct_points_to_user')) {
            return $this->error(__('GamiPress points functions not found.', 'bit-pi'), $fieldMappings);
        }

        $userId = \absint($fieldMappings['user_id']);
        $pointType = \sanitize_text_field($fieldMappings['point_type']);

        if (!$this->userExists($userId)) {
            return $this->error(__('User not found.', 'bit-pi'), $fieldMappings);
        }

        $previousPoints = \intval(gamipress_get_user_points($userId, $pointType));

        if ($previousPoints > 0) {
            gamipress_deduct_points_to_user($userId, $previousPoints, $pointType);
        }

        $newPoints = \intval(gamipress_get_user_points($userId, $pointType));

        return $this->success(
            $fieldMappings,
            [
                'point_type'      => $pointType,
                'points'          => $previousPoints,
                'previous_points' => $previousPoints,
                'new_points'      => $newPoints,
                'user'            => Utility::getUserInfo($userId),
            ]
        );
    }

    public function revokeAchievementFromUser()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $errors = $this->validate(
            $fieldMappings,
            [
                'user_id'        => ['required', 'integer'],
                'achievement_id' => ['required', 'integer'],
            ]
        );

        if ($errors) {
            return $errors;
        }

        if (!\function_exists('gamipress_revoke_achievement_to_user')) {
            return $this->error(__('GamiPress revoke achievement function not found.', 'bit-pi'), $fieldMappings);
        }

        $userId = \absint($fieldMappings['user_id']);
        $achievementId = \absint($fieldMappings['achievement_id']);

        if (!$this->userExists($userId)) {
            return $this->error(__('User not found.', 'bit-pi'), $fieldMappings);
        }

        if (!$this->postExists($achievementId)) {
            return $this->error(__('Achievement not found.', 'bit-pi'), $fieldMappings);
        }

        if (\function_exists('gamipress_get_user_achievements')) {
            $achievements = gamipress_get_user_achievements(
                [
                    'user_id'        => $userId,
                    'achievement_id' => $achievementId,
                ]
            );

            if (empty($achievements)) {
                return $this->error(__('The user does not have the selected achievement.', 'bit-pi'), $fieldMappings);
            }
        }

        gamipress_revoke_achievement_to_user($achievementId, $userId);

        return $this->success(
            $fieldMappings,
            [
                'achievement_id' => $achievementId,
                'user'           => Utility::getUserInfo($userId),
            ]
        );
    }

    public function revokePointsFromUser()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();
        $errors = $this->validate(
            $fieldMappings,
            [
                'user_id'    => ['required', 'integer'],
                'point_type' => ['required', 'string'],
                'points'     => ['required', 'integer'],
            ]
        );

        if ($errors) {
            return $errors;
        }

        if (!\function_exists('gamipress_get_user_points') || !\function_exists('gamipress_deduct_points_to_user')) {
            return $this->error(__('GamiPress points functions not found.', 'bit-pi'), $fieldMappings);
        }

        $userId = \absint($fieldMappings['user_id']);
        $pointType = \sanitize_text_field($fieldMappings['point_type']);
        $points = \absint($fieldMappings['points']);

        if (!$this->userExists($userId)) {
            return $this->error(__('User not found.', 'bit-pi'), $fieldMappings);
        }

        if ($points <= 0) {
            return $this->error(__('Points must be greater than zero.', 'bit-pi'), $fieldMappings);
        }

        $previousPoints = \intval(gamipress_get_user_points($userId, $pointType));
        $deductPoints = \min($previousPoints, $points);

        if ($deductPoints > 0) {
            gamipress_deduct_points_to_user($userId, $deductPoints, $pointType);
        }

        $newPoints = \intval(gamipress_get_user_points($userId, $pointType));

        return $this->success(
            $fieldMappings,
            [
                'point_type'      => $pointType,
                'points'          => $deductPoints,
                'requested_points' => $points,
                'previous_points' => $previousPoints,
                'new_points'      => $newPoints,
                'user'            => Utility::getUserInfo($userId),
            ]
        );
    }

    private function validate($fieldMappings, $rules)
    {
        return GamiPressHelper::validateFieldMap($fieldMappings, $rules);
    }

    private function success($payload, $response)
    {
        return [
            'response'    => $response,
            'payload'     => $payload,
            'status_code' => 200,
        ];
    }

    private function error($message, $payload)
    {
        return [
            'response'    => $message,
            'payload'     => $payload,
            'status_code' => 400,
        ];
    }

    private function userExists($userId): bool
    {
        return !empty(Utility::getUserInfo($userId));
    }

    private function postExists($postId): bool
    {
        return !empty(\get_post($postId));
    }
}
