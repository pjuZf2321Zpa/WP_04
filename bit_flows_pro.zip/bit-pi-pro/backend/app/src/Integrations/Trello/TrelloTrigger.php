<?php

namespace BitApps\PiPro\src\Integrations\Trello;

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\Pi\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\Pi\Deps\BitApps\WPKit\Http\Request\Request;
use BitApps\Pi\Deps\BitApps\WPKit\Http\Response;
use BitApps\Pi\Helpers\Hash;
use BitApps\Pi\Model\Flow;
use BitApps\Pi\Model\FlowNode;
use BitApps\Pi\src\Flow\FlowExecutor;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Client\HttpClient;

final class TrelloTrigger
{
    private const BASE_URL = 'https://api.trello.com/1';

    private const EVENT_LIST = [
        'action_create_card'                 => 'newCard',
        'action_move_card_from_list_to_list' => 'cardMoveToList',
        'action_add_label_to_board'          => 'newLabel',
        'action_create_label'                => 'newLabel',
        'action_add_label_to_card'           => 'newLabel',
        'action_update_card'                 => 'cardUpdated',
        'action_renamed_card'                => 'cardUpdated',
        'action_changed_description_of_card' => 'cardUpdated',
        'action_added_a_due_date'            => 'cardUpdated',
        'action_changed_a_due_date'          => 'cardUpdated',
        'action_archived_card'               => 'cardUpdated',
        'action_unarchived_card'             => 'cardUpdated',
        'action_added_member_to_card'        => 'cardUpdated',
        'action_removed_member_from_card'    => 'cardUpdated',
        'action_completed_checkitem'         => 'cardUpdated',
        'action_marked_checkitem_incomplete' => 'cardUpdated',
        'action_add_attachment_to_card'      => 'cardUpdated',
    ];

    public function handle(Request $request)
    {
        $payload = $request->all();

        $translationKey = $payload['action']['display']['translationKey'] ?? null;

        if (empty($translationKey)) {
            return Response::success('Ignored');
        }

        $machineSlug = self::EVENT_LIST[$translationKey] ?? null;

        if (!$machineSlug) {
            return Response::success('Ignored');
        }

        $nodes = FlowNode::with('flow')
            ->where('app_slug', 'trello')
            ->where('machine_slug', $machineSlug)
            ->get();

        if (empty($nodes)) {
            return Response::success('Accepted');
        }

        foreach ($nodes as $node) {
            if (!$this->isEventMatchingNodeConfig($machineSlug, $payload, $node)) {
                continue;
            }

            $flow = $node->flow;

            if (!$flow) {
                continue;
            }

            if ($flow->listener_type === Flow::LISTENER_TYPE['NONE'] && (int) $flow->is_active === Flow::STATUS['IN_ACTIVE']) {
                continue;
            }

            FlowExecutor::execute($flow, $payload);
        }

        return Response::success('Accepted');
    }

    public function setTrelloWebhook(Request $request)
    {
        $encryptedApiKey = $request->get('key');
        $encryptedApiToken = $request->get('token');
        $callbackUrl = $request->get('endpoint');
        $idModel = $request->get('idModel');

        if (empty($encryptedApiKey) || empty($encryptedApiToken) || empty($callbackUrl) || empty($idModel)) {
            return Response::error('Missing required parameters');
        }

        $apiKey = Hash::decrypt($encryptedApiKey);
        $apiToken = Hash::decrypt($encryptedApiToken);

        if (empty($apiKey) || empty($apiToken)) {
            return Response::error('Failed to decrypt API credentials');
        }

        $httpClient = new HttpClient(
            [
                'headers' => [
                    'Content-Type'  => 'application/json',
                    'Authorization' => "OAuth oauth_consumer_key=\"{$apiKey}\", oauth_token=\"{$apiToken}\"",
                ],
            ]
        );

        $endpoint = self::BASE_URL . '/webhooks?key=' . $apiKey . '&token=' . $apiToken;

        $body = JSON::encode(
            [
                'callbackURL' => $callbackUrl,
                'idModel'     => $idModel,
                'description' => 'Trello Webhook',
            ]
        );

        $response = $httpClient->request($endpoint, 'POST', $body);
        $statusCode = $httpClient->getResponseCode();

        if ($statusCode >= 200 && $statusCode < 300) {
            return Response::success('Webhook created successfully on Trello.');
        }

        $errorMessage = 'Failed to create Trello webhook.';

        if (\is_object($response) && isset($response->message)) {
            $errorMessage = $response->message;
        } elseif (\is_string($response)) {
            $errorMessage = $response;
        }

        return Response::error($errorMessage);
    }

    private function isEventMatchingNodeConfig(string $machineSlug, array $payload, object $node): bool
    {
        $nodeData = $node->data;
        $db = $nodeData->db ?? $nodeData;

        $entities = $payload['action']['display']['entities'] ?? [];
        $actionData = $payload['action']['data'] ?? [];

        switch ($machineSlug) {
            case 'newCard':
                return $this->matchesListId($db, $entities, $actionData);

            case 'cardMoveToList':
                return $this->matchesListAfter($db, $entities, $actionData)
                    && $this->matchesCardId($db, $entities, $actionData);

            case 'newLabel':
                return $this->matchesBoardId($db, $actionData);

            default:
                return true;
        }
    }

    private function matchesListId(object $db, array $entities, array $actionData): bool
    {
        $dbListId = $db->listId ?? null;

        if (empty($dbListId)) {
            return true;
        }

        $incomingListId = $entities['list']['id'] ?? $actionData['list']['id'] ?? null;

        return empty($incomingListId) || $incomingListId === $dbListId;
    }

    private function matchesListAfter(object $db, array $entities, array $actionData): bool
    {
        $dbListId = $db->listId ?? null;

        if (empty($dbListId)) {
            return true;
        }

        $listAfterId = $entities['listAfter']['id'] ?? $actionData['listAfter']['id'] ?? null;

        return empty($listAfterId) || $listAfterId === $dbListId;
    }

    private function matchesCardId(object $db, array $entities, array $actionData): bool
    {
        $dbCardId = $db->cardId ?? null;

        if (empty($dbCardId)) {
            return true;
        }

        $incomingCardId = $entities['card']['id'] ?? $actionData['card']['id'] ?? null;

        return empty($incomingCardId) || $incomingCardId === $dbCardId;
    }

    private function matchesBoardId(object $db, array $actionData): bool
    {
        $dbBoardId = $db->boardId ?? null;

        if (empty($dbBoardId)) {
            return true;
        }

        $incomingBoardId = $actionData['board']['id'] ?? null;

        return empty($incomingBoardId) || $incomingBoardId === $dbBoardId;
    }
}
