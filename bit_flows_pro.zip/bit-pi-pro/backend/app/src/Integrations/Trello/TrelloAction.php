<?php

namespace BitApps\PiPro\src\Integrations\Trello;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Authorization\AuthorizationFactory;
use BitApps\Pi\src\Authorization\AuthorizationType;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Client\HttpClient;

if (!defined('ABSPATH')) {
    exit;
}

class TrelloAction implements ActionInterface
{
    private NodeInfoProvider $nodeInfoProvider;

    private TrelloService $trelloService;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeTrelloAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'],
            $executedNodeAction['payload'],
            $executedNodeAction['response']
        );
    }

    private function executeMachine($machineSlug, $fieldMapData, $configs)
    {
        $cardId = $configs['card-id']['value'] ?? null;
        $boardId = $configs['board-id']['value'] ?? null;
        $labelId = $configs['label-id']['value'] ?? null;
        $listId = $configs['list-id']['value'] ?? null;
        $memberId = $configs['member-id']['value'] ?? null;
        $attachmentId = $configs['attachment-id']['value'] ?? null;
        $checklistId = $configs['checklist-id']['value'] ?? null;
        $checkItemId = $configs['checkitem-id']['value'] ?? null;

        switch ($machineSlug) {
            case 'createCard':
                $fieldMapData['idList'] = $listId;

                return $this->trelloService->createCard($fieldMapData);

            case 'getCard':
                return $this->trelloService->getCard($cardId);

            case 'updateCard':
                return $this->trelloService->updateCard($cardId, $fieldMapData);

            case 'deleteCard':
                return $this->trelloService->deleteCard($cardId);

            case 'createBoard':
                return $this->trelloService->createBoard($fieldMapData);

            case 'getBoard':
                return $this->trelloService->getBoard($boardId);

            case 'updateBoard':
                return $this->trelloService->updateBoard($boardId, $fieldMapData);

            case 'deleteBoard':
                return $this->trelloService->deleteBoard($boardId);

            case 'createLabel':
                $fieldMapData['idBoard'] = $boardId;

                return $this->trelloService->createLabel($fieldMapData);

            case 'getLabel':
                return $this->trelloService->getLabel($labelId);

            case 'updateLabel':
                return $this->trelloService->updateLabel($labelId, $fieldMapData);

            case 'deleteLabel':
                return $this->trelloService->deleteLabel($labelId);

            case 'listLabels':
                return $this->trelloService->listLabels($boardId);

            case 'addLabelToCard':
                return $this->trelloService->addLabelToCard($cardId, $labelId);

            case 'removeLabelFromCard':
                return $this->trelloService->removeLabelFromCard($cardId, $labelId);

            case 'addBoardMember':
                return $this->trelloService->addBoardMember($boardId, $memberId, $fieldMapData);

            case 'getBoardMembers':
                return $this->trelloService->getBoardMembers($boardId);

            case 'inviteBoardMember':
                return $this->trelloService->inviteBoardMember($boardId, $fieldMapData);

            case 'removeBoardMember':
                return $this->trelloService->removeBoardMember($boardId, $memberId);

            case 'createAttachment':
                return $this->trelloService->createAttachment($cardId, $fieldMapData);

            case 'getAttachment':
                return $this->trelloService->getAttachment($cardId, $attachmentId);

            case 'getManyAttachments':
                return $this->trelloService->getManyAttachments($cardId);

            case 'deleteAttachment':
                return $this->trelloService->deleteAttachment($cardId, $attachmentId);

            case 'createChecklist':
                $fieldMapData['idCard'] = $cardId;

                return $this->trelloService->createChecklist($fieldMapData);

            case 'getChecklist':
                return $this->trelloService->getChecklist($checklistId);

            case 'getManyChecklists':
                return $this->trelloService->getManyChecklists($cardId);

            case 'deleteChecklist':
                return $this->trelloService->deleteChecklist($checklistId);

            case 'createChecklistItem':
                return $this->trelloService->createChecklistItem($checklistId, $fieldMapData);

            case 'updateChecklistItem':
                return $this->trelloService->updateChecklistItem($cardId, $checkItemId, $fieldMapData);

            case 'deleteChecklistItem':
                return $this->trelloService->deleteChecklistItem($cardId, $checkItemId);

            case 'getChecklistItems':
                return $this->trelloService->getChecklistItems($checklistId);

            case 'getCompletedChecklistItems':
                return $this->trelloService->getCompletedChecklistItems($cardId);

            default:
                return [
                    'status_code' => 400,
                    'payload'     => [],
                    'response'    => ['error' => 'Invalid action']
                ];
        }
    }

    private function executeTrelloAction()
    {
        $machineSlug = $this->nodeInfoProvider->getMachineSlug();
        $configs = $this->nodeInfoProvider->getFieldMapConfigs();
        $fieldMapData = $this->nodeInfoProvider->getFieldMapData();
        $connectionId = $this->nodeInfoProvider->getFieldMapConfigs('connection-id.value');

        $authHandler = AuthorizationFactory::getAuthorizationHandler(
            AuthorizationType::API_KEY,
            $connectionId
        );

        $authDetails = $authHandler->getAuthDetails();
        $apiKey = $authDetails->key;
        $apiToken = $authDetails->value;

        $httpClient = new HttpClient(
            [
                'headers' => [
                    'Content-Type'  => 'application/json',
                    'Authorization' => "OAuth oauth_consumer_key=\"{$apiKey}\", oauth_token=\"{$apiToken}\"",
                ],
            ]
        );

        $this->trelloService = new TrelloService($httpClient);

        return $this->executeMachine($machineSlug, $fieldMapData, $configs);
    }
}
