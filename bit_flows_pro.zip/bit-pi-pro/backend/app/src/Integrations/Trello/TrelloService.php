<?php

namespace BitApps\PiPro\src\Integrations\Trello;

use BitApps\PiPro\Deps\BitApps\WPKit\Helpers\JSON;

if (!defined('ABSPATH')) {
    exit;
}

class TrelloService
{
    private const BASE_URL = 'https://api.trello.com/1';

    private $http;

    /**
     * TrelloService constructor.
     *
     * @param mixed $httpClient
     */
    public function __construct($httpClient)
    {
        $this->http = $httpClient;
    }

    /**
     * Create a new card on a Trello board.
     *
     * @param array $data
     *
     * @return array
     */
    public function createCard($data)
    {
        $endpoint = self::BASE_URL . '/cards';
        $response = $this->http->request($endpoint, 'POST', JSON::encode($data));

        return [
            'response'    => $response,
            'payload'     => $data,
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Get details of a specific Trello card.
     *
     * @param string $cardId
     *
     * @return array
     */
    public function getCard($cardId)
    {
        $endpoint = self::BASE_URL . '/cards/' . $cardId;
        $response = $this->http->request($endpoint, 'GET', []);

        return [
            'response'    => $response,
            'payload'     => ['cardId' => $cardId],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Update an existing Trello card.
     *
     * @param string $cardId
     * @param array  $data
     *
     * @return array
     */
    public function updateCard($cardId, $data)
    {
        $endpoint = self::BASE_URL . '/cards/' . $cardId;
        $response = $this->http->request($endpoint, 'PUT', JSON::encode($data));

        return [
            'response'    => $response,
            'payload'     => $data,
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Delete a Trello card.
     *
     * @param string $cardId
     *
     * @return array
     */
    public function deleteCard($cardId)
    {
        $endpoint = self::BASE_URL . '/cards/' . $cardId;
        $response = $this->http->request($endpoint, 'DELETE', []);

        if (isset($response->limits)) {
            $response = 'Deleted Successfully';
        }

        return [
            'response'    => $response,
            'payload'     => ['cardId' => $cardId],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Create a new Trello board.
     *
     * @param array $data
     *
     * @return array
     */
    public function createBoard($data)
    {
        $endpoint = self::BASE_URL . '/boards';
        $response = $this->http->request($endpoint, 'POST', JSON::encode($data));

        return [
            'response'    => $response,
            'payload'     => $data,
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Get details of a specific Trello board.
     *
     * @param string $boardId
     *
     * @return array
     */
    public function getBoard($boardId)
    {
        $endpoint = self::BASE_URL . '/boards/' . $boardId;
        $response = $this->http->request($endpoint, 'GET', []);


        return [
            'response'    => $response,
            'payload'     => ['boardId' => $boardId],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Update an existing Trello board.
     *
     * @param string $boardId
     * @param array  $data
     *
     * @return array
     */
    public function updateBoard($boardId, $data)
    {
        $endpoint = self::BASE_URL . "/boards/{$boardId}";
        $response = $this->http->request($endpoint, 'PUT', JSON::encode($data));

        return [
            'response'    => $response,
            'payload'     => $data,
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Delete a Trello board.
     *
     * @param string $boardId
     *
     * @return array
     */
    public function deleteBoard($boardId)
    {
        $endpoint = self::BASE_URL . '/boards/' . $boardId;
        $response = $this->http->request($endpoint, 'DELETE', []);

        if (\is_object($response) && property_exists($response, '_value')) {
            $response = 'Deleted Successfully';
        }

        return [
            'response'    => $response,
            'payload'     => ['boardId' => $boardId],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Create a new label on a Trello board.
     *
     * @param array  $data
     *
     * @return array
     */
    public function createLabel($data)
    {
        $endpoint = self::BASE_URL . '/labels';
        $response = $this->http->request($endpoint, 'POST', JSON::encode($data));

        return [
            'response'    => $response,
            'payload'     => $data,
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Get details of a specific Trello label.
     *
     * @param string $labelId
     *
     * @return array
     */
    public function getLabel($labelId)
    {
        $endpoint = self::BASE_URL . "/labels/{$labelId}";
        $response = $this->http->request($endpoint, 'GET', []);

        return [
            'response'    => $response,
            'payload'     => ['labelId' => $labelId],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Update an existing Trello label.
     *
     * @param string $labelId
     * @param array  $data
     *
     * @return array
     */
    public function updateLabel($labelId, $data)
    {
        $endpoint = self::BASE_URL . "/labels/{$labelId}";
        $response = $this->http->request($endpoint, 'PUT', JSON::encode($data));

        return [
            'response'    => $response,
            'payload'     => $data,
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Delete a Trello label.
     *
     * @param string $labelId
     *
     * @return array
     */
    public function deleteLabel($labelId)
    {
        $endpoint = self::BASE_URL . '/labels/' . $labelId;
        $response = $this->http->request($endpoint, 'DELETE', []);

        if (isset($response->limits)) {
            $response = 'Deleted Successfully';
        }

        return [
            'response'    => $response,
            'payload'     => ['labelId' => $labelId],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * List all labels available on a Trello board.
     *
     * @param string $boardId
     *
     * @return array
     */
    public function listLabels($boardId)
    {
        $endpoint = self::BASE_URL . '/boards/' . $boardId . '/labels';
        $response = $this->http->request($endpoint, 'GET', []);

        return [
            'response'    => $response,
            'payload'     => ['boardId' => $boardId],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Add an existing label to a Trello card.
     *
     * @param string $cardId
     * @param string $labelId
     *
     * @return array
     */
    public function addLabelToCard($cardId, $labelId)
    {
        $endpoint = self::BASE_URL . '/cards/' . $cardId . '/idLabels';
        $data = ['value' => $labelId];
        $response = $this->http->request($endpoint, 'POST', JSON::encode($data));

        return [
            'response'    => $response,
            'payload'     => $data,
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Remove a label from a Trello card.
     *
     * @param string $cardId
     * @param string $labelId
     *
     * @return array
     */
    public function removeLabelFromCard($cardId, $labelId)
    {
        $endpoint = self::BASE_URL . '/cards/' . $cardId . '/idLabels/' . $labelId;
        $response = $this->http->request($endpoint, 'DELETE', []);

        if (\is_object($response) && property_exists($response, '_value')) {
            $response = 'Removed Successfully';
        }

        return [
            'response'    => $response,
            'payload'     => ['cardId' => $cardId, 'labelId' => $labelId],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Add a member to a Trello board.
     *
     * @param string $boardId
     * @param array  $data
     * @param mixed $memberId
     *
     * @return array
     */
    public function addBoardMember($boardId, $memberId, $data)
    {
        $endpoint = self::BASE_URL . '/boards/' . $boardId . '/members/' . $memberId;
        $response = $this->http->request($endpoint, 'PUT', JSON::encode($data));

        return [
            'response'    => $response,
            'payload'     => $data,
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Get all members of a Trello board.
     *
     * @param string $boardId
     *
     * @return array
     */
    public function getBoardMembers($boardId)
    {
        $endpoint = self::BASE_URL . '/boards/' . $boardId . '/members';
        $response = $this->http->request($endpoint, 'GET', []);

        return [
            'response'    => $response,
            'payload'     => ['boardId' => $boardId],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Invite a new member to a Trello board.
     *
     * @param string $boardId
     * @param array  $data
     *
     * @return array
     */
    public function inviteBoardMember($boardId, $data)
    {
        $endpoint = self::BASE_URL . '/boards/' . $boardId . '/members';
        $response = $this->http->request($endpoint, 'PUT', JSON::encode($data));

        return [
            'response'    => $response,
            'payload'     => $data,
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Remove a member from a Trello board.
     *
     * @param string $boardId
     * @param string $idMember
     *
     * @return array
     */
    public function removeBoardMember($boardId, $idMember)
    {
        $endpoint = self::BASE_URL . '/boards/' . $boardId . '/members/' . $idMember;
        $response = $this->http->request($endpoint, 'DELETE', []);

        return [
            'response'    => $response,
            'payload'     => ['boardId' => $boardId, 'idMember' => $idMember],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Create an attachment on a Trello card.
     *
     * @param string $cardId
     * @param array  $data
     *
     * @return array
     */
    public function createAttachment($cardId, $data)
    {
        $endpoint = self::BASE_URL . '/cards/' . $cardId . '/attachments';
        $response = $this->http->request($endpoint, 'POST', JSON::encode($data));

        return [
            'response'    => $response,
            'payload'     => $data,
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Get a specific attachment from a Trello card.
     *
     * @param string $cardId
     * @param string $attachmentId
     *
     * @return array
     */
    public function getAttachment($cardId, $attachmentId)
    {
        $endpoint = self::BASE_URL . '/cards/' . $cardId . '/attachments/' . $attachmentId;
        $response = $this->http->request($endpoint, 'GET', []);

        return [
            'response'    => $response,
            'payload'     => ['cardId' => $cardId, 'attachmentId' => $attachmentId],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * List all attachments on a Trello card.
     *
     * @param string $cardId
     *
     * @return array
     */
    public function getManyAttachments($cardId)
    {
        $endpoint = self::BASE_URL . '/cards/' . $cardId . '/attachments';
        $response = $this->http->request($endpoint, 'GET', []);

        return [
            'response'    => $response,
            'payload'     => ['cardId' => $cardId],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Delete an attachment from a Trello card.
     *
     * @param string $cardId
     * @param string $attachmentId
     *
     * @return array
     */
    public function deleteAttachment($cardId, $attachmentId)
    {
        $endpoint = self::BASE_URL . '/cards/' . $cardId . '/attachments/' . $attachmentId;
        $response = $this->http->request($endpoint, 'DELETE', []);

        if (isset($response->limits)) {
            $response = 'Deleted Successfully';
        }

        return [
            'response'    => $response,
            'payload'     => ['cardId' => $cardId, 'attachmentId' => $attachmentId],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Create a new checklist on a Trello card.
     *
     * @param array  $data
     *
     * @return array
     */
    public function createChecklist($data)
    {
        $endpoint = self::BASE_URL . '/checklists';
        $response = $this->http->request($endpoint, 'POST', JSON::encode($data));

        return [
            'response'    => $response,
            'payload'     => $data,
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Get details of a specific Trello checklist.
     *
     * @param string $checklistId
     *
     * @return array
     */
    public function getChecklist($checklistId)
    {
        $endpoint = self::BASE_URL . '/checklists/' . $checklistId;
        $response = $this->http->request($endpoint, 'GET', []);

        return [
            'response'    => $response,
            'payload'     => ['checklistId' => $checklistId],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * List all checklists on a Trello card.
     *
     * @param string $cardId
     *
     * @return array
     */
    public function getManyChecklists($cardId)
    {
        $endpoint = self::BASE_URL . '/cards/' . $cardId . '/checklists';
        $response = $this->http->request($endpoint, 'GET', []);

        return [
            'response'    => $response,
            'payload'     => ['cardId' => $cardId],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Delete a Trello checklist.
     *
     * @param string $checklistId
     *
     * @return array
     */
    public function deleteChecklist($checklistId)
    {
        $endpoint = self::BASE_URL . '/checklists/' . $checklistId;
        $response = $this->http->request($endpoint, 'DELETE', []);

        if (isset($response->limits)) {
            $response = 'Deleted Successfully';
        }


        return [
            'response'    => $response,
            'payload'     => ['checklistId' => $checklistId],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Create a new item in a Trello checklist.
     *
     * @param string $checklistId
     * @param array  $data
     *
     * @return array
     */
    public function createChecklistItem($checklistId, $data)
    {
        $endpoint = self::BASE_URL . '/checklists/' . $checklistId . '/checkItems';
        $response = $this->http->request($endpoint, 'POST', JSON::encode($data));

        return [
            'response'    => $response,
            'payload'     => $data,
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Update an item in Trello checklist.
     *
     * @param string $cardId
     * @param string $checkItemId
     * @param array  $data
     *
     * @return array
     */
    public function updateChecklistItem($cardId, $checkItemId, $data)
    {
        $endpoint = self::BASE_URL . "/cards/{$cardId}/checkItem/{$checkItemId}";
        $response = $this->http->request($endpoint, 'PUT', JSON::encode($data));

        return [
            'response'    => $response,
            'payload'     => $data,
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * Delete an item from a Trello checklist.
     *
     * @param string $cardId
     * @param string $checkItemId
     *
     * @return array
     */
    public function deleteChecklistItem($cardId, $checkItemId)
    {
        $endpoint = self::BASE_URL . '/cards/' . $cardId . '/checkItem/' . $checkItemId;
        $response = $this->http->request($endpoint, 'DELETE', []);

        if (isset($response->limits)) {
            $response = 'Deleted Successfully';
        }

        return [
            'response'    => $response,
            'payload'     => ['cardId' => $cardId, 'checkItemId' => $checkItemId],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * List all items in a Trello checklist.
     *
     * @param string $checklistId
     *
     * @return array
     */
    public function getChecklistItems($checklistId)
    {
        $endpoint = self::BASE_URL . '/checklists/' . $checklistId . '/checkItems';
        $response = $this->http->request($endpoint, 'GET', []);

        return [
            'response'    => $response,
            'payload'     => ['checklistId' => $checklistId],
            'status_code' => $this->http->getResponseCode()
        ];
    }

    /**
     * List all completed items in Trello checklists on a card.
     *
     * @param string $cardId
     *
     * @return array
     */
    public function getCompletedChecklistItems($cardId)
    {
        $endpoint = self::BASE_URL . '/cards/' . $cardId . '/checkItemStates?filter=complete';
        $response = $this->http->request($endpoint, 'GET', []);

        return [
            'response'    => $response,
            'payload'     => ['cardId' => $cardId],
            'status_code' => $this->http->getResponseCode()
        ];
    }
}
