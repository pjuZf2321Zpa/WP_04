<?php

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\PiPro\src\Integrations\Trello\TrelloTrigger;

if (!defined('ABSPATH')) {
    exit;
}

Route::group(
    function () {
        Route::post('trello/set-trello-webhook', [TrelloTrigger::class, 'setTrelloWebhook']);
    }
)->middleware('nonce:admin');
