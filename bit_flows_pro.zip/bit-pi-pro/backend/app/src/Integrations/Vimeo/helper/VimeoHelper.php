<?php

namespace BitApps\PiPro\src\Integrations\Vimeo\helper;

if (!defined('ABSPATH')) {
    exit;
}

final class VimeoHelper
{
    /**
     * Best-effort check that a URL points at the raw video FILE (pull-compatible),
     * not a web page such as YouTube/Vimeo/Drive. Known page hosts are rejected
     * outright; otherwise a HEAD request rejects an HTML content type. When the URL
     * cannot be probed (HEAD unsupported / unreachable), Vimeo's pull makes the call.
     *
     * @param string $url
     *
     * @return bool
     */
    public static function isDirectVideoUrl($url)
    {
        $host = strtolower((string) wp_parse_url($url, PHP_URL_HOST));

        $pageHosts = [
            'youtube.com', 'www.youtube.com', 'm.youtube.com', 'youtu.be',
            'vimeo.com', 'www.vimeo.com', 'player.vimeo.com',
            'dailymotion.com', 'www.dailymotion.com', 'dai.ly',
            'drive.google.com', 'dropbox.com', 'www.dropbox.com',
            'facebook.com', 'www.facebook.com', 'fb.watch',
        ];

        if (\in_array($host, $pageHosts, true)) {
            return false;
        }

        $response = wp_safe_remote_head($url, ['timeout' => 10, 'redirection' => 5]);

        if (is_wp_error($response)) {
            return true;
        }

        // Some hosts/CDNs reject HEAD (e.g. 405) and answer with an HTML error page;
        // a non-2xx probe is inconclusive, so defer to Vimeo's pull rather than block it.
        $responseCode = wp_remote_retrieve_response_code($response);
        if ($responseCode < 200 || $responseCode >= 300) {
            return true;
        }

        $contentType = wp_remote_retrieve_header($response, 'content-type');

        if (\is_array($contentType)) {
            $contentType = $contentType[0] ?? '';
        }

        $contentType = strtolower((string) $contentType);

        if ($contentType === '') {
            return true;
        }

        return !str_starts_with($contentType, 'text/html') && !str_starts_with($contentType, 'application/xhtml');
    }
}
