<?php

namespace BitApps\PiPro\src\Integrations\Vimeo;

use BitApps\Pi\src\Authorization\AuthorizationFactory;
use BitApps\Pi\src\Authorization\AuthorizationType;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Client\HttpClient;
use BitApps\PiPro\src\Integrations\Vimeo\helper\VimeoHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class VimeoService
{
    private const BASE_URL = 'https://api.vimeo.com';

    private const ACCEPT_HEADER = 'application/vnd.vimeo.*+json;version=3.4';

    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function uploadVideo()
    {
        $data = $this->nodeInfoProvider->getFieldMapData();

        $validatedFieldMap = IntegrationHelper::validateFieldMap($data, ['link' => ['required', 'url']]);
        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        if (!VimeoHelper::isDirectVideoUrl($data['link'])) {
            return [
                'status_code' => 400,
                'payload'     => $data,
                'response'    => __('The video URL must be a direct link to the raw video file (e.g. https://…/clip.mp4), not a YouTube/Vimeo/Drive/Dropbox web page.', 'bit-pi'),
            ];
        }

        $body = ['upload' => ['approach' => 'pull', 'link' => $data['link']]];

        if (isset($data['name']) && $data['name'] !== '') {
            $body['name'] = $data['name'];
        }

        if (isset($data['description']) && $data['description'] !== '') {
            $body['description'] = $data['description'];
        }

        $privacyView = $this->config('privacy-view');
        if (!empty($privacyView)) {
            $body['privacy'] = ['view' => $privacyView];
        }

        return $this->request('POST', '/me/videos', $body);
    }

    public function editVideo()
    {
        $data = $this->nodeInfoProvider->getFieldMapData();
        $videoId = $this->config('video-id');

        $validatedFieldMap = IntegrationHelper::validateFieldMap(['video_id' => $videoId], ['video_id' => ['required']]);
        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        $body = [];

        if (isset($data['name']) && $data['name'] !== '') {
            $body['name'] = $data['name'];
        }

        if (isset($data['description']) && $data['description'] !== '') {
            $body['description'] = $data['description'];
        }

        $privacyView = $this->config('privacy-view');
        if (!empty($privacyView)) {
            $body['privacy'] = ['view' => $privacyView];
        }

        return $this->request('PATCH', '/videos/' . rawurlencode((string) $videoId), $body);
    }

    public function deleteVideo()
    {
        $videoId = $this->config('video-id');

        $validatedFieldMap = IntegrationHelper::validateFieldMap(['video_id' => $videoId], ['video_id' => ['required']]);
        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        return $this->request('DELETE', '/videos/' . rawurlencode((string) $videoId));
    }

    public function addComment()
    {
        $data = $this->nodeInfoProvider->getFieldMapData();
        $videoId = $this->config('video-id');

        $validatedFieldMap = IntegrationHelper::validateFieldMap(
            ['video_id' => $videoId, 'text' => $data['text'] ?? null],
            ['video_id' => ['required'], 'text' => ['required']]
        );
        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        return $this->request('POST', '/videos/' . rawurlencode((string) $videoId) . '/comments', ['text' => $data['text']]);
    }

    public function createShowcase()
    {
        $data = $this->nodeInfoProvider->getFieldMapData();

        $validatedFieldMap = IntegrationHelper::validateFieldMap($data, ['name' => ['required', 'string']]);
        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        $body = ['name' => $data['name']];

        if (!empty($data['description'])) {
            $body['description'] = $data['description'];
        }

        return $this->request('POST', '/me/albums', $body);
    }

    public function addVideoToShowcase()
    {
        $showcaseId = $this->config('showcase-id');
        $videoId = $this->config('video-id');

        $validatedFieldMap = IntegrationHelper::validateFieldMap(
            ['showcase_id' => $showcaseId, 'video_id' => $videoId],
            ['showcase_id' => ['required'], 'video_id' => ['required']]
        );
        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        return $this->request(
            'PUT',
            '/me/albums/' . rawurlencode((string) $showcaseId) . '/videos/' . rawurlencode((string) $videoId)
        );
    }

    public function createFolder()
    {
        $data = $this->nodeInfoProvider->getFieldMapData();

        $validatedFieldMap = IntegrationHelper::validateFieldMap($data, ['name' => ['required', 'string']]);
        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        return $this->request('POST', '/me/projects', ['name' => $data['name']]);
    }

    public function addVideoToFolder()
    {
        $folderId = $this->config('folder-id');
        $videoId = $this->config('video-id');

        $validatedFieldMap = IntegrationHelper::validateFieldMap(
            ['folder_id' => $folderId, 'video_id' => $videoId],
            ['folder_id' => ['required'], 'video_id' => ['required']]
        );
        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        return $this->request(
            'PUT',
            '/me/projects/' . rawurlencode((string) $folderId) . '/videos/' . rawurlencode((string) $videoId)
        );
    }

    public function addVideoToChannel()
    {
        $channelId = $this->config('channel-id');
        $videoId = $this->config('video-id');

        $validatedFieldMap = IntegrationHelper::validateFieldMap(
            ['channel_id' => $channelId, 'video_id' => $videoId],
            ['channel_id' => ['required'], 'video_id' => ['required']]
        );
        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        return $this->request(
            'PUT',
            '/channels/' . rawurlencode((string) $channelId) . '/videos/' . rawurlencode((string) $videoId)
        );
    }

    public function likeVideo()
    {
        $videoId = $this->config('video-id');

        $validatedFieldMap = IntegrationHelper::validateFieldMap(['video_id' => $videoId], ['video_id' => ['required']]);
        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        return $this->request('PUT', '/me/likes/' . rawurlencode((string) $videoId));
    }

    public function addToWatchLater()
    {
        $videoId = $this->config('video-id');

        $validatedFieldMap = IntegrationHelper::validateFieldMap(['video_id' => $videoId], ['video_id' => ['required']]);
        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        return $this->request('PUT', '/me/watchlater/' . rawurlencode((string) $videoId));
    }

    public function uploadTextTrack()
    {
        $data = $this->nodeInfoProvider->getFieldMapData();
        $videoId = $this->config('video-id');

        $validatedFieldMap = IntegrationHelper::validateFieldMap(
            ['video_id' => $videoId, 'language' => $data['language'] ?? null],
            ['video_id' => ['required'], 'language' => ['required', 'string']]
        );
        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        $body = [
            'type'     => $this->config('track-type') ?: 'captions',
            'language' => $data['language'],
        ];

        if (!empty($data['name'])) {
            $body['name'] = $data['name'];
        }

        return $this->request('POST', '/videos/' . rawurlencode((string) $videoId) . '/texttracks', $body);
    }

    public function getVideo()
    {
        $videoId = $this->config('video-id');

        $validatedFieldMap = IntegrationHelper::validateFieldMap(['video_id' => $videoId], ['video_id' => ['required']]);
        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        return $this->request('GET', '/videos/' . rawurlencode((string) $videoId));
    }

    public function listVideos()
    {
        $data = $this->nodeInfoProvider->getFieldMapData();

        $query = [];
        if (isset($data['query']) && $data['query'] !== '') {
            $query['query'] = $data['query'];
        }
        if (isset($data['per_page']) && $data['per_page'] !== '') {
            $query['per_page'] = $data['per_page'];
        }

        return $this->request('GET', '/me/videos', null, $query);
    }

    public function getUser()
    {
        return $this->request('GET', '/me');
    }

    public function listShowcases()
    {
        return $this->request('GET', '/me/albums');
    }

    public function listFolders()
    {
        return $this->request('GET', '/me/projects');
    }

    public function listChannels()
    {
        return $this->request('GET', '/me/channels');
    }

    public function listComments()
    {
        $videoId = $this->config('video-id');

        $validatedFieldMap = IntegrationHelper::validateFieldMap(['video_id' => $videoId], ['video_id' => ['required']]);
        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        return $this->request('GET', '/videos/' . rawurlencode((string) $videoId) . '/comments');
    }

    public function getShowcase()
    {
        $showcaseId = $this->config('showcase-id');

        $validatedFieldMap = IntegrationHelper::validateFieldMap(['showcase_id' => $showcaseId], ['showcase_id' => ['required']]);
        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        return $this->request('GET', '/me/albums/' . rawurlencode((string) $showcaseId));
    }

    public function listShowcaseVideos()
    {
        $showcaseId = $this->config('showcase-id');

        $validatedFieldMap = IntegrationHelper::validateFieldMap(['showcase_id' => $showcaseId], ['showcase_id' => ['required']]);
        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        return $this->request('GET', '/me/albums/' . rawurlencode((string) $showcaseId) . '/videos');
    }

    public function getFolder()
    {
        $folderId = $this->config('folder-id');

        $validatedFieldMap = IntegrationHelper::validateFieldMap(['folder_id' => $folderId], ['folder_id' => ['required']]);
        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        return $this->request('GET', '/me/projects/' . rawurlencode((string) $folderId));
    }

    public function listFolderVideos()
    {
        $folderId = $this->config('folder-id');

        $validatedFieldMap = IntegrationHelper::validateFieldMap(['folder_id' => $folderId], ['folder_id' => ['required']]);
        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        return $this->request('GET', '/me/projects/' . rawurlencode((string) $folderId) . '/videos');
    }

    public function getChannel()
    {
        $channelId = $this->config('channel-id');

        $validatedFieldMap = IntegrationHelper::validateFieldMap(['channel_id' => $channelId], ['channel_id' => ['required']]);
        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        return $this->request('GET', '/channels/' . rawurlencode((string) $channelId));
    }

    public function listChannelVideos()
    {
        $channelId = $this->config('channel-id');

        $validatedFieldMap = IntegrationHelper::validateFieldMap(['channel_id' => $channelId], ['channel_id' => ['required']]);
        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        return $this->request('GET', '/channels/' . rawurlencode((string) $channelId) . '/videos');
    }

    public function searchVideos()
    {
        $data = $this->nodeInfoProvider->getFieldMapData();

        $validatedFieldMap = IntegrationHelper::validateFieldMap($data, ['query' => ['required', 'string']]);
        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        $query = ['query' => $data['query']];
        if (isset($data['per_page']) && $data['per_page'] !== '') {
            $query['per_page'] = $data['per_page'];
        }

        return $this->request('GET', '/videos', null, $query);
    }

    public function listTextTracks()
    {
        $videoId = $this->config('video-id');

        $validatedFieldMap = IntegrationHelper::validateFieldMap(['video_id' => $videoId], ['video_id' => ['required']]);
        if (!empty($validatedFieldMap)) {
            return $validatedFieldMap;
        }

        return $this->request('GET', '/videos/' . rawurlencode((string) $videoId) . '/texttracks');
    }

    public function listLikes()
    {
        return $this->request('GET', '/me/likes');
    }

    public function listWatchLater()
    {
        return $this->request('GET', '/me/watchlater');
    }

    private function config($id)
    {
        return $this->nodeInfoProvider->getFieldMapConfigs($id . '.value');
    }

    private function request($method, $path, $body = null, array $query = [])
    {
        $connectionId = $this->nodeInfoProvider->getFieldMapConfigs('connection-id.value');

        $accessToken = AuthorizationFactory::getAuthorizationHandler(
            AuthorizationType::BEARER_TOKEN,
            $connectionId
        )->getAccessToken();

        if (\is_array($accessToken) && isset($accessToken['error'])) {
            return ['status_code' => 401, 'payload' => $body ?? $query, 'response' => $accessToken];
        }

        $url = self::BASE_URL . $path;
        if (!empty($query)) {
            $url .= '?' . http_build_query($query);
        }

        $headers = [
            'Accept'        => self::ACCEPT_HEADER,
            'Authorization' => $accessToken,
            'Content-Type'  => 'application/json',
        ];

        $http = new HttpClient();
        $requestBody = $body === null ? [] : JSON::encode($body);
        $response = $http->request($url, $method, $requestBody, $headers);

        return [
            'status_code' => $http->getResponseCode(),
            'payload'     => $body ?? $query,
            'response'    => $response,
        ];
    }
}
