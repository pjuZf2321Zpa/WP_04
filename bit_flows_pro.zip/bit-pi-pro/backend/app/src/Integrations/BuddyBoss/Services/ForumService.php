<?php

namespace BitApps\PiPro\src\Integrations\BuddyBoss\Services;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\BuddyBoss\helper\BuddyBossHelper;

if (!\defined('ABSPATH')) {
    exit;
}

final class ForumService extends BaseService
{
    public function createForum()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'title'     => ['required'],
            'author_id' => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('bbp_insert_forum')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Forums component is not active.', 'bit-pi'),
            ];
        }

        $authorId = $this->getUserId($fieldMappings['author_id']);

        if (!$authorId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Forum author not found.', 'bit-pi'),
            ];
        }

        $visibilities = [
            'publish' => bbp_get_public_status_id(),
            'public'  => bbp_get_public_status_id(),
            'private' => bbp_get_private_status_id(),
            'hidden'  => bbp_get_hidden_status_id(),
        ];
        $visibility = empty($fieldMappings['visibility']) ? bbp_get_public_status_id() : ($visibilities[strtolower(trim((string) $fieldMappings['visibility']))] ?? null);

        if (!$visibility) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Invalid visibility. Use publish, private or hidden.', 'bit-pi'),
            ];
        }

        $parentId = empty($fieldMappings['parent_id']) ? 0 : (int) $fieldMappings['parent_id'];

        if ($parentId && !bbp_is_forum($parentId)) {
            return [
                'status_code' => 404,
                'payload'     => $fieldMappings,
                'response'    => __('Parent forum not found.', 'bit-pi'),
            ];
        }

        $forumId = bbp_insert_forum(
            [
                'post_title'   => (string) $fieldMappings['title'],
                'post_content' => $fieldMappings['content'] ?? '',
                'post_status'  => $visibility,
                'post_parent'  => $parentId,
                'post_author'  => $authorId,
            ]
        );

        if (!$forumId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to create forum.', 'bit-pi'),
            ];
        }

        if ($visibility === bbp_get_private_status_id()) {
            bbp_privatize_forum($forumId, bbp_get_public_status_id());
        } elseif ($visibility === bbp_get_hidden_status_id()) {
            bbp_hide_forum($forumId, bbp_get_public_status_id());
        }

        bbp_update_forum(['forum_id' => $forumId, 'post_parent' => $parentId]);

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => BuddyBossHelper::getForumPostData($forumId),
        ];
    }

    public function closeForum()
    {
        return $this->toggleForumStatus('bbp_close_forum');
    }

    public function openForum()
    {
        return $this->toggleForumStatus('bbp_open_forum');
    }

    public function closeTopic()
    {
        return $this->updateTopic('bbp_close_topic', __('Topic is already closed.', 'bit-pi'));
    }

    public function openTopic()
    {
        return $this->updateTopic('bbp_open_topic', __('Topic is already open.', 'bit-pi'));
    }

    public function stickTopic()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        return $this->updateTopic('bbp_stick_topic', __('Failed to stick topic.', 'bit-pi'), [!empty($fieldMappings['super_sticky'])]);
    }

    public function unstickTopic()
    {
        return $this->updateTopic('bbp_unstick_topic', __('Failed to unstick topic.', 'bit-pi'));
    }

    public function subscribeUserToTopic()
    {
        return $this->updateUserEngagement('bbp_add_user_topic_subscription', 'topic_id', __('User is already subscribed to this topic.', 'bit-pi'));
    }

    public function unsubscribeUserFromForum()
    {
        return $this->updateUserEngagement('bbp_remove_user_forum_subscription', 'forum_id', __('User is not subscribed to this forum.', 'bit-pi'));
    }

    public function unsubscribeUserFromTopic()
    {
        return $this->updateUserEngagement('bbp_remove_user_topic_subscription', 'topic_id', __('User is not subscribed to this topic.', 'bit-pi'));
    }

    public function favoriteTopic()
    {
        return $this->updateUserEngagement('bbp_add_user_favorite', 'topic_id', __('Topic is already in the user favorites.', 'bit-pi'));
    }

    public function unfavoriteTopic()
    {
        return $this->updateUserEngagement('bbp_remove_user_favorite', 'topic_id', __('Topic is not in the user favorites.', 'bit-pi'));
    }

    public function getTopicSubscribers()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'topic_id' => ['required', 'integer'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('bbp_get_topic_subscribers')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Forums component is not active.', 'bit-pi'),
            ];
        }

        $subscriberIds = (array) bbp_get_topic_subscribers((int) $fieldMappings['topic_id']);
        cache_users(\array_slice($subscriberIds, 0, 500));
        $subscribers = array_map([Utility::class, 'getUserInfo'], \array_slice($subscriberIds, 0, 500));

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'total'       => \count($subscriberIds),
                'subscribers' => $subscribers,
            ],
        ];
    }

    private function toggleForumStatus($functionName)
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'forum_id' => ['required', 'integer'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists($functionName)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Forums component is not active.', 'bit-pi'),
            ];
        }

        $forumId = (int) $fieldMappings['forum_id'];

        if (!bbp_is_forum($forumId)) {
            return [
                'status_code' => 404,
                'payload'     => $fieldMappings,
                'response'    => __('Forum not found.', 'bit-pi'),
            ];
        }

        $functionName($forumId);

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => array_merge(BuddyBossHelper::getForumPostData($forumId), ['forum_status' => bbp_get_forum_status($forumId)]),
        ];
    }

    private function updateTopic($functionName, $failureMessage, $extraArgs = [])
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'topic_id' => ['required', 'integer'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists($functionName)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Forums component is not active.', 'bit-pi'),
            ];
        }

        $topicId = (int) $fieldMappings['topic_id'];

        if (!bbp_is_topic($topicId)) {
            return [
                'status_code' => 404,
                'payload'     => $fieldMappings,
                'response'    => __('Topic not found.', 'bit-pi'),
            ];
        }

        if (!$functionName($topicId, ...$extraArgs)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => $failureMessage,
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => BuddyBossHelper::getTopicData($topicId),
        ];
    }

    private function updateUserEngagement($functionName, $itemKey, $failureMessage)
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'user_id' => ['required'],
            $itemKey  => ['required', 'integer'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists($functionName)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Forums component is not active.', 'bit-pi'),
            ];
        }

        $userId = $this->getUserId($fieldMappings['user_id']);

        if (!$userId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User not found.', 'bit-pi'),
            ];
        }

        $itemId = (int) $fieldMappings[$itemKey];
        $itemExists = $itemKey === 'forum_id' ? bbp_is_forum($itemId) : bbp_is_topic($itemId);

        if (!$itemExists) {
            return [
                'status_code' => 404,
                'payload'     => $fieldMappings,
                'response'    => $itemKey === 'forum_id' ? __('Forum not found.', 'bit-pi') : __('Topic not found.', 'bit-pi'),
            ];
        }

        if (!$functionName($userId, $itemId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => $failureMessage,
            ];
        }

        $item = $itemKey === 'forum_id' ? ['forum' => BuddyBossHelper::getForumPostData($itemId)] : BuddyBossHelper::getTopicData($itemId);

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => array_merge(['user' => Utility::getUserInfo($userId)], $item),
        ];
    }
}
