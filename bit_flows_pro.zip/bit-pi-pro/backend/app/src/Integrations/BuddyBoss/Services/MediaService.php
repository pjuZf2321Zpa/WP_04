<?php

namespace BitApps\PiPro\src\Integrations\BuddyBoss\Services;

use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\BuddyBoss\helper\BuddyBossHelper;
use BP_Document_Folder;
use BP_Media_Album;

if (!\defined('ABSPATH')) {
    exit;
}

final class MediaService extends BaseService
{
    private const GROUP_ITEM_SETTINGS = [
        'album'  => ['bp_is_group_albums_support_enabled', 'bp_group_get_album_status'],
        'folder' => ['bp_is_group_document_support_enabled', 'bp_group_get_document_status'],
    ];

    public function createAlbum()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'title'   => ['required'],
            'user_id' => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('bp_album_add')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Photos component is not active.', 'bit-pi'),
            ];
        }

        $userId = $this->getUserId($fieldMappings['user_id']);

        if (!$userId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User not found.', 'bit-pi'),
            ];
        }

        $groupId = empty($fieldMappings['group_id']) ? 0 : (int) $fieldMappings['group_id'];
        $placement = self::resolvePlacement($groupId, $userId, $fieldMappings['privacy'] ?? '', 'album', array_keys(bp_media_get_visibility_levels()));

        if (isset($placement['error'])) {
            return [
                'status_code' => $placement['status_code'],
                'payload'     => $fieldMappings,
                'response'    => $placement['error'],
            ];
        }

        $albumId = bp_album_add(
            [
                'user_id'    => $userId,
                'group_id'   => $placement['group_id'] ?: false,
                'title'      => (string) $fieldMappings['title'],
                'privacy'    => $placement['privacy'],
                'error_type' => 'wp_error',
            ]
        );

        if (empty($albumId) || is_wp_error($albumId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => is_wp_error($albumId) ? $albumId->get_error_message() : __('Failed to create album.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => BuddyBossHelper::getRecordData(new BP_Media_Album($albumId)),
        ];
    }

    public function createDocumentFolder()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'title'   => ['required'],
            'user_id' => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('bp_folder_add')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Documents component is not active.', 'bit-pi'),
            ];
        }

        $userId = $this->getUserId($fieldMappings['user_id']);

        if (!$userId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User not found.', 'bit-pi'),
            ];
        }

        $parentId = empty($fieldMappings['parent_folder_id']) ? 0 : (int) $fieldMappings['parent_folder_id'];
        $groupId = empty($fieldMappings['group_id']) ? 0 : (int) $fieldMappings['group_id'];
        $privacy = $fieldMappings['privacy'] ?? '';

        if ($parentId) {
            $parent = new BP_Document_Folder($parentId);

            if (empty($parent->id)) {
                return [
                    'status_code' => 404,
                    'payload'     => $fieldMappings,
                    'response'    => __('Parent folder not found.', 'bit-pi'),
                ];
            }

            if (empty($parent->group_id) && (int) $parent->user_id !== $userId) {
                return [
                    'status_code' => 400,
                    'payload'     => $fieldMappings,
                    'response'    => __('The parent folder belongs to another user.', 'bit-pi'),
                ];
            }

            $groupId = (int) $parent->group_id;
            $privacy = $parent->privacy;
        }

        $placement = self::resolvePlacement($groupId, $userId, $privacy, 'folder', array_keys(bp_document_get_visibility_levels()));

        if (isset($placement['error'])) {
            return [
                'status_code' => $placement['status_code'],
                'payload'     => $fieldMappings,
                'response'    => $placement['error'],
            ];
        }

        $folderId = bp_folder_add(
            [
                'user_id'    => $userId,
                'group_id'   => $placement['group_id'] ?: false,
                'title'      => (string) $fieldMappings['title'],
                'privacy'    => $placement['privacy'],
                'parent'     => $parentId,
                'error_type' => 'wp_error',
            ]
        );

        if (empty($folderId) || is_wp_error($folderId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => is_wp_error($folderId) ? $folderId->get_error_message() : __('Failed to create document folder.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => BuddyBossHelper::getRecordData(new BP_Document_Folder($folderId)),
        ];
    }

    private static function resolvePlacement($groupId, $userId, $privacy, $itemType, $privacyLevels)
    {
        if ($groupId) {
            if (!\function_exists('groups_get_group') || empty(groups_get_group($groupId)->id)) {
                return ['status_code' => 404, 'error' => __('Group not found.', 'bit-pi')];
            }

            if (!self::canAddToGroup($userId, $groupId, $itemType)) {
                return ['status_code' => 400, 'error' => __('The user cannot add items to this group.', 'bit-pi')];
            }

            return ['group_id' => $groupId, 'privacy' => 'grouponly'];
        }

        $privacy = empty($privacy) ? 'public' : strtolower(trim((string) $privacy));

        if (!\in_array($privacy, $privacyLevels, true)) {
            return ['status_code' => 400, 'error' => __('Invalid privacy value.', 'bit-pi')];
        }

        return ['group_id' => 0, 'privacy' => $privacy];
    }

    private static function canAddToGroup($userId, $groupId, $itemType)
    {
        [$isSupportEnabled, $getStatus] = self::GROUP_ITEM_SETTINGS[$itemType];

        if (!\function_exists($isSupportEnabled) || !\function_exists($getStatus) || !$isSupportEnabled()) {
            return false;
        }

        if (user_can($userId, 'bp_moderate')) {
            return true;
        }

        if (!groups_is_user_member($userId, $groupId)) {
            return false;
        }

        $status = $getStatus($groupId);
        $isAdmin = groups_is_user_admin($userId, $groupId);

        return $status === 'members'
            || ($status === 'mods' && ($isAdmin || groups_is_user_mod($userId, $groupId)))
            || ($status === 'admins' && $isAdmin);
    }
}
