<?php

namespace BitApps\PiPro\src\Integrations\BuddyBoss\Services;

use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\PiPro\src\Integrations\BuddyBoss\helper\BuddyBossHelper;

if (!\defined('ABSPATH')) {
    exit;
}

abstract class BaseService
{
    protected $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    protected function getUserId($user)
    {
        $wpUser = BuddyBossHelper::getUser($user);

        return $wpUser ? (int) $wpUser->ID : 0;
    }

    protected function actAsUser($userId, callable $callback)
    {
        $loggedInUserId = static function () use ($userId) {
            return $userId;
        };

        add_filter('bp_loggedin_user_id', $loggedInUserId);

        try {
            return $callback();
        } finally {
            remove_filter('bp_loggedin_user_id', $loggedInUserId);
        }
    }
}
