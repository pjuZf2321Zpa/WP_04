<?php

namespace BitApps\PiPro\src\Integrations\BuddyBoss\Services;

use BP_Activity_Activity;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\BuddyBoss\helper\BuddyBossHelper;

if (!\defined('ABSPATH')) {
    exit;
}

final class ActivityService extends BaseService
{
    public function createActivityComment()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'activity_id'       => ['required', 'integer'],
            'user_id'           => ['required'],
            'content'           => ['required'],
            'parent_comment_id' => ['nullable', 'integer'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('bp_activity_new_comment')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Activity component is not active.', 'bit-pi'),
            ];
        }

        $userId = $this->getUserId($fieldMappings['user_id']);

        if (!$userId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User not found.', 'bit-pi'),
            ];
        }

        $activity = BuddyBossHelper::getActivityData($fieldMappings['activity_id']);

        if (!isset($activity['user'])) {
            return [
                'status_code' => 404,
                'payload'     => $fieldMappings,
                'response'    => __('Activity not found.', 'bit-pi'),
            ];
        }

        $isComment = ($activity['type'] ?? '') === 'activity_comment';
        $rootId = $isComment ? (int) $activity['item_id'] : (int) $activity['id'];
        $parentId = empty($fieldMappings['parent_comment_id']) ? (int) $activity['id'] : (int) $fieldMappings['parent_comment_id'];

        if ($parentId !== $rootId) {
            $parent = BuddyBossHelper::getActivityData($parentId);

            if (($parent['type'] ?? '') !== 'activity_comment' || (int) ($parent['item_id'] ?? 0) !== $rootId) {
                return [
                    'status_code' => 400,
                    'payload'     => $fieldMappings,
                    'response'    => __('The parent comment does not belong to this activity.', 'bit-pi'),
                ];
            }
        }

        $commentId = bp_activity_new_comment(
            [
                'activity_id' => $rootId,
                'parent_id'   => $parentId,
                'content'     => (string) $fieldMappings['content'],
                'user_id'     => $userId,
                'error_type'  => 'wp_error',
            ]
        );

        if (empty($commentId) || is_wp_error($commentId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => is_wp_error($commentId) ? $commentId->get_error_message() : __('Failed to create activity comment.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => BuddyBossHelper::getActivityData($commentId),
        ];
    }

    public function deleteActivity()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'activity_id' => ['required', 'integer'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('bp_activity_delete')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Activity component is not active.', 'bit-pi'),
            ];
        }

        $activityId = (int) $fieldMappings['activity_id'];
        $activity = BuddyBossHelper::getActivityData($activityId);

        $deleted = ($activity['type'] ?? '') === 'activity_comment'
            ? bp_activity_delete_comment((int) $activity['item_id'], $activityId)
            : bp_activity_delete(['id' => $activityId]);

        if (!$deleted) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to delete activity.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => $activity,
        ];
    }

    public function addActivityReaction()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'activity_id' => ['required', 'integer'],
            'user_id'     => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('bp_activity_add_user_favorite') || !\function_exists('bb_load_reaction')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Activity reactions are not available.', 'bit-pi'),
            ];
        }

        $userId = $this->getUserId($fieldMappings['user_id']);

        if (!$userId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User not found.', 'bit-pi'),
            ];
        }

        $reactionId = empty($fieldMappings['reaction_id']) ? bb_load_reaction()->bb_reactions_reaction_id() : (int) $fieldMappings['reaction_id'];

        $reacted = bp_activity_add_user_favorite(
            (int) $fieldMappings['activity_id'],
            $userId,
            [
                'type'        => self::getReactionItemType($fieldMappings['activity_id']),
                'reaction_id' => $reactionId,
                'error_type'  => 'wp_error',
            ]
        );

        if (empty($reacted) || is_wp_error($reacted)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => is_wp_error($reacted) ? $reacted->get_error_message() : __('Failed to add reaction.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'reaction' => BuddyBossHelper::getReactionData($reactionId),
                'activity' => BuddyBossHelper::getActivityData($fieldMappings['activity_id']),
            ],
        ];
    }

    public function removeActivityReaction()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'activity_id' => ['required', 'integer'],
            'user_id'     => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('bp_activity_remove_user_favorite')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Activity component is not active.', 'bit-pi'),
            ];
        }

        $userId = $this->getUserId($fieldMappings['user_id']);

        if (!$userId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User not found.', 'bit-pi'),
            ];
        }

        $itemType = self::getReactionItemType($fieldMappings['activity_id']);

        if (\function_exists('bb_load_reaction')) {
            $reactedId = bb_load_reaction()->bb_user_reacted_reaction_id(
                [
                    'item_id'   => (int) $fieldMappings['activity_id'],
                    'item_type' => $itemType,
                    'user_id'   => $userId,
                ]
            );

            if (empty($reactedId)) {
                return [
                    'status_code' => 400,
                    'payload'     => $fieldMappings,
                    'response'    => __('The user has not reacted to this activity.', 'bit-pi'),
                ];
            }
        }

        $removed = bp_activity_remove_user_favorite(
            (int) $fieldMappings['activity_id'],
            $userId,
            [
                'type'       => $itemType,
                'error_type' => 'wp_error',
            ]
        );

        if (empty($removed) || is_wp_error($removed)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => is_wp_error($removed) ? $removed->get_error_message() : __('Failed to remove reaction.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => BuddyBossHelper::getActivityData($fieldMappings['activity_id']),
        ];
    }

    public function getActivity()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'activity_id' => ['required', 'integer'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $activity = BuddyBossHelper::getActivityData($fieldMappings['activity_id']);

        if (!isset($activity['user'])) {
            return [
                'status_code' => 404,
                'payload'     => $fieldMappings,
                'response'    => __('Activity not found.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => $activity,
        ];
    }

    private static function getReactionItemType($activityId)
    {
        $activity = new BP_Activity_Activity((int) $activityId);

        return $activity->type === 'activity_comment' ? 'activity_comment' : 'activity';
    }
}
