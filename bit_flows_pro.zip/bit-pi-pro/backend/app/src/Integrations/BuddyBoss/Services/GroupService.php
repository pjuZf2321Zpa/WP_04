<?php

namespace BitApps\PiPro\src\Integrations\BuddyBoss\Services;

use BBP_Forums_Group_Extension;
use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\BuddyBoss\helper\BuddyBossHelper;

if (!\defined('ABSPATH')) {
    exit;
}

final class GroupService extends BaseService
{
    private const LIST_LIMIT = 500;

    public function updateGroupDetails()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'group_id' => ['required', 'integer'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('groups_edit_base_group_details')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Groups component is not active.', 'bit-pi'),
            ];
        }

        $group = groups_get_group((int) $fieldMappings['group_id']);

        if (empty($group->id)) {
            return [
                'status_code' => 404,
                'payload'     => $fieldMappings,
                'response'    => __('Group not found.', 'bit-pi'),
            ];
        }

        $updated = $this->actAsUser(
            (int) $group->creator_id,
            static function () use ($group, $fieldMappings) {
                return groups_edit_base_group_details(
                    [
                        'group_id'       => $group->id,
                        'name'           => empty($fieldMappings['name']) ? null : $fieldMappings['name'],
                        'slug'           => empty($fieldMappings['slug']) ? null : $fieldMappings['slug'],
                        'description'    => empty($fieldMappings['description']) ? $group->description : $fieldMappings['description'],
                        'notify_members' => !empty($fieldMappings['notify_members']),
                        'parent_id'      => false,
                    ]
                );
            }
        );

        if (!$updated) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to update group details.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => BuddyBossHelper::getGroupData($group->id),
        ];
    }

    public function updateGroupSettings()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'group_id' => ['required', 'integer'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('groups_edit_group_settings')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Groups component is not active.', 'bit-pi'),
            ];
        }

        $group = groups_get_group((int) $fieldMappings['group_id']);

        if (empty($group->id)) {
            return [
                'status_code' => 404,
                'payload'     => $fieldMappings,
                'response'    => __('Group not found.', 'bit-pi'),
            ];
        }

        $status = empty($fieldMappings['status']) ? $group->status : $fieldMappings['status'];

        if (!groups_is_valid_status($status)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Invalid group privacy.', 'bit-pi'),
            ];
        }

        $settingTypes = [
            'invite_status'        => 'invite',
            'activity_feed_status' => 'activity_feed',
            'media_status'         => 'media',
            'document_status'      => 'document',
            'video_status'         => 'video',
            'album_status'         => 'album',
            'message_status'       => 'message',
        ];

        foreach ($settingTypes as $field => $settingType) {
            $allowedStatuses = \function_exists('bb_groups_get_settings_status') ? bb_groups_get_settings_status($settingType) : ['members', 'mods', 'admins'];

            if (!empty($fieldMappings[$field]) && !\in_array($fieldMappings[$field], $allowedStatuses, true)) {
                // translators: %s: Group setting field name.
                $message = \sprintf(__('Invalid value for %s.', 'bit-pi'), $field);

                return [
                    'status_code' => 400,
                    'payload'     => $fieldMappings,
                    'response'    => $message,
                ];
            }
        }

        $enableForum = $group->enable_forum;
        $forumChoice = self::parseForumChoice($fieldMappings['enable_forum'] ?? null);

        if ($forumChoice === false) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Invalid value for enable_forum. Use yes or no.', 'bit-pi'),
            ];
        }

        if ($forumChoice !== null) {
            $enableForum = $forumChoice === 'yes' ? 1 : 0;
        }

        if ($forumChoice === 'yes' && !self::isGroupForumsActive()) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss group forums are not active. Turn on the Forums component and group forums first.', 'bit-pi'),
            ];
        }

        $updated = groups_edit_group_settings(
            $group->id,
            $enableForum,
            $status,
            empty($fieldMappings['invite_status']) ? false : $fieldMappings['invite_status'],
            empty($fieldMappings['activity_feed_status']) ? false : $fieldMappings['activity_feed_status'],
            false,
            empty($fieldMappings['media_status']) ? false : $fieldMappings['media_status'],
            empty($fieldMappings['document_status']) ? false : $fieldMappings['document_status'],
            empty($fieldMappings['video_status']) ? false : $fieldMappings['video_status'],
            empty($fieldMappings['album_status']) ? false : $fieldMappings['album_status'],
            empty($fieldMappings['message_status']) ? false : $fieldMappings['message_status']
        );

        if (!$updated) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to update group settings.', 'bit-pi'),
            ];
        }

        if ($forumChoice !== null && self::isGroupForumsActive()) {
            self::setGroupForum($group->id, (bool) $enableForum);
        }

        do_action('groups_group_settings_edited', $group->id);

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => BuddyBossHelper::getGroupData($group->id),
        ];
    }

    public function deleteGroup()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'group_id' => ['required', 'integer'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('groups_delete_group')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Groups component is not active.', 'bit-pi'),
            ];
        }

        $group = BuddyBossHelper::getGroupData($fieldMappings['group_id']);

        if (!isset($group['creator'])) {
            return [
                'status_code' => 404,
                'payload'     => $fieldMappings,
                'response'    => __('Group not found.', 'bit-pi'),
            ];
        }

        if (!groups_delete_group((int) $fieldMappings['group_id'])) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to delete group.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => $group,
        ];
    }

    public function promoteGroupMember()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'group_id' => ['required', 'integer'],
            'user_id'  => ['required'],
            'role'     => ['required', 'string'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $roles = ['mod' => 'mod', 'moderator' => 'mod', 'admin' => 'admin', 'organizer' => 'admin'];
        $role = $roles[strtolower(trim($fieldMappings['role']))] ?? null;

        if (!$role) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Invalid role. Use mod or admin.', 'bit-pi'),
            ];
        }

        return $this->changeGroupMemberRole('groups_promote_member', $fieldMappings, [$role]);
    }

    public function demoteGroupMember()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'group_id' => ['required', 'integer'],
            'user_id'  => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        return $this->changeGroupMemberRole('groups_demote_member', $fieldMappings);
    }

    public function banGroupMember()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'group_id' => ['required', 'integer'],
            'user_id'  => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        return $this->changeGroupMemberRole('groups_ban_member', $fieldMappings);
    }

    public function unbanGroupMember()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'group_id' => ['required', 'integer'],
            'user_id'  => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        return $this->changeGroupMemberRole('groups_unban_member', $fieldMappings);
    }

    public function inviteUserToGroup()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'group_id'   => ['required', 'integer'],
            'user_id'    => ['required'],
            'inviter_id' => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('groups_invite_user')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Groups component is not active.', 'bit-pi'),
            ];
        }

        $userId = $this->getUserId($fieldMappings['user_id']);
        $inviterId = $this->getUserId($fieldMappings['inviter_id']);

        if (!$userId || !$inviterId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Invitee or inviter user not found.', 'bit-pi'),
            ];
        }

        $groupId = (int) $fieldMappings['group_id'];

        if (empty(groups_get_group($groupId)->id)) {
            return [
                'status_code' => 404,
                'payload'     => $fieldMappings,
                'response'    => __('Group not found.', 'bit-pi'),
            ];
        }

        if (groups_is_user_member($userId, $groupId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User is already a member of the group.', 'bit-pi'),
            ];
        }

        $invitationId = groups_invite_user(
            [
                'user_id'     => $userId,
                'group_id'    => $groupId,
                'inviter_id'  => $inviterId,
                'content'     => $fieldMappings['message'] ?? '',
                'send_invite' => 1,
            ]
        );

        if (!$invitationId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to invite user to the group.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'invitation_id' => $invitationId,
                'user'          => Utility::getUserInfo($userId),
                'inviter'       => Utility::getUserInfo($inviterId),
                'group'         => BuddyBossHelper::getGroupData($groupId),
            ],
        ];
    }

    public function acceptGroupInvitation()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'group_id' => ['required', 'integer'],
            'user_id'  => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('groups_accept_invite')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Groups component is not active.', 'bit-pi'),
            ];
        }

        $userId = $this->getUserId($fieldMappings['user_id']);

        if (!$userId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User not found.', 'bit-pi'),
            ];
        }

        if (!groups_accept_invite($userId, (int) $fieldMappings['group_id'])) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('No pending invitation found for this user and group.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'user'  => Utility::getUserInfo($userId),
                'group' => BuddyBossHelper::getGroupData($fieldMappings['group_id']),
            ],
        ];
    }

    public function rejectGroupInvitation()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'group_id' => ['required', 'integer'],
            'user_id'  => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('groups_reject_invite')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Groups component is not active.', 'bit-pi'),
            ];
        }

        $userId = $this->getUserId($fieldMappings['user_id']);

        if (!$userId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User not found.', 'bit-pi'),
            ];
        }

        if (!groups_reject_invite($userId, (int) $fieldMappings['group_id'])) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('No pending invitation found for this user and group.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'user'  => Utility::getUserInfo($userId),
                'group' => BuddyBossHelper::getGroupData($fieldMappings['group_id']),
            ],
        ];
    }

    public function sendGroupMembershipRequest()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'group_id' => ['required', 'integer'],
            'user_id'  => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('groups_send_membership_request')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Groups component is not active.', 'bit-pi'),
            ];
        }

        $userId = $this->getUserId($fieldMappings['user_id']);

        if (!$userId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User not found.', 'bit-pi'),
            ];
        }

        $requestId = groups_send_membership_request(
            [
                'user_id'  => $userId,
                'group_id' => (int) $fieldMappings['group_id'],
                'content'  => $fieldMappings['message'] ?? '',
            ]
        );

        if (!$requestId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to send membership request.', 'bit-pi'),
            ];
        }

        $joined = $requestId === true;

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'request_id' => $joined ? 0 : (int) $requestId,
                'joined'     => $joined,
                'user'       => Utility::getUserInfo($userId),
                'group'      => BuddyBossHelper::getGroupData($fieldMappings['group_id']),
            ],
        ];
    }

    public function acceptGroupMembershipRequest()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'group_id' => ['required', 'integer'],
            'user_id'  => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('groups_accept_membership_request')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Groups component is not active.', 'bit-pi'),
            ];
        }

        $userId = $this->getUserId($fieldMappings['user_id']);

        if (!$userId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User not found.', 'bit-pi'),
            ];
        }

        if (!groups_accept_membership_request(false, $userId, (int) $fieldMappings['group_id'])) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('No pending membership request found for this user and group.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'user'  => Utility::getUserInfo($userId),
                'group' => BuddyBossHelper::getGroupData($fieldMappings['group_id']),
            ],
        ];
    }

    public function rejectGroupMembershipRequest()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'group_id' => ['required', 'integer'],
            'user_id'  => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('groups_reject_membership_request')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Groups component is not active.', 'bit-pi'),
            ];
        }

        $userId = $this->getUserId($fieldMappings['user_id']);

        if (!$userId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User not found.', 'bit-pi'),
            ];
        }

        if (!groups_reject_membership_request(false, $userId, (int) $fieldMappings['group_id'])) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('No pending membership request found for this user and group.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'user'  => Utility::getUserInfo($userId),
                'group' => BuddyBossHelper::getGroupData($fieldMappings['group_id']),
            ],
        ];
    }

    public function setGroupType()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'group_id'   => ['required', 'integer'],
            'group_type' => ['required', 'string'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('bp_groups_set_group_type')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Group Types are not available.', 'bit-pi'),
            ];
        }

        if (empty(groups_get_group((int) $fieldMappings['group_id'])->id)) {
            return [
                'status_code' => 404,
                'payload'     => $fieldMappings,
                'response'    => __('Group not found.', 'bit-pi'),
            ];
        }

        $types = bp_groups_set_group_type((int) $fieldMappings['group_id'], $fieldMappings['group_type'], !empty($fieldMappings['append']));

        if (empty($types) || is_wp_error($types)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to set group type.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => BuddyBossHelper::getGroupData($fieldMappings['group_id']),
        ];
    }

    public function removeGroupType()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'group_id'   => ['required', 'integer'],
            'group_type' => ['required', 'string'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('bp_groups_remove_group_type')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Group Types are not available.', 'bit-pi'),
            ];
        }

        $groupId = (int) $fieldMappings['group_id'];

        if (!\in_array($fieldMappings['group_type'], (array) bp_groups_get_group_type($groupId, false), true)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Group does not have this group type.', 'bit-pi'),
            ];
        }

        $removed = bp_groups_remove_group_type($groupId, $fieldMappings['group_type']);

        if (empty($removed) || is_wp_error($removed)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Group does not have this group type.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => BuddyBossHelper::getGroupData($fieldMappings['group_id']),
        ];
    }

    public function getGroup()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'group_id' => ['required', 'integer'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('groups_get_group')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Groups component is not active.', 'bit-pi'),
            ];
        }

        $group = BuddyBossHelper::getGroupData($fieldMappings['group_id']);

        if (!isset($group['creator'])) {
            return [
                'status_code' => 404,
                'payload'     => $fieldMappings,
                'response'    => __('Group not found.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => $group,
        ];
    }

    public function getGroupMembers()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'group_id' => ['required', 'integer'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('groups_get_group_members')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Groups component is not active.', 'bit-pi'),
            ];
        }

        $roles = empty($fieldMappings['roles']) ? ['admin', 'mod', 'member'] : array_map('strtolower', array_map('trim', Utility::convertStringToArray($fieldMappings['roles'])));
        $invalidRoles = array_diff($roles, ['admin', 'mod', 'member', 'banned']);

        if (!empty($invalidRoles)) {
            // translators: %s: Comma-separated invalid role names.
            $message = \sprintf(__('Invalid roles: %s. Use admin, mod, member or banned.', 'bit-pi'), implode(', ', $invalidRoles));

            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => $message,
            ];
        }

        $result = groups_get_group_members(
            [
                'group_id'   => (int) $fieldMappings['group_id'],
                'group_role' => $roles,
                'per_page'   => self::LIST_LIMIT,
                'page'       => 1,
            ]
        );

        cache_users(wp_list_pluck($result['members'] ?? [], 'ID'));

        $members = [];

        foreach ($result['members'] ?? [] as $member) {
            $members[] = array_merge(
                Utility::getUserInfo($member->ID),
                [
                    'is_admin'  => (bool) ($member->is_admin ?? false),
                    'is_mod'    => (bool) ($member->is_mod ?? false),
                    'is_banned' => (bool) ($member->is_banned ?? false),
                ]
            );
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'total'   => $result['count'] ?? \count($members),
                'members' => $members,
            ],
        ];
    }

    public function getUserGroups()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'user_id' => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('groups_get_user_groups')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Groups component is not active.', 'bit-pi'),
            ];
        }

        $userId = $this->getUserId($fieldMappings['user_id']);

        if (!$userId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User not found.', 'bit-pi'),
            ];
        }

        $userGroups = groups_get_user_groups($userId, self::LIST_LIMIT, 1);

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'total'  => $userGroups['total'] ?? 0,
                'groups' => array_map([BuddyBossHelper::class, 'getGroupData'], $userGroups['groups'] ?? []),
            ],
        ];
    }

    private static function parseForumChoice($value)
    {
        if ($value === null || $value === '') {
            return;
        }

        $choices = ['enable' => 'yes', 'disable' => 'no'];
        $value = \is_string($value) ? strtolower(trim($value)) : $value;
        $value = $choices[$value] ?? $value;
        $enabled = filter_var($value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);

        if ($enabled === null) {
            return false;
        }

        return $enabled ? 'yes' : 'no';
    }

    private static function isGroupForumsActive()
    {
        return bp_is_active('forums') && \function_exists('bbp_is_group_forums_active') && bbp_is_group_forums_active() && class_exists('BBP_Forums_Group_Extension');
    }

    private static function setGroupForum($groupId, $enable)
    {
        $groupForumExtension = new BBP_Forums_Group_Extension();
        $forumIds = array_values(bbp_get_group_forum_ids($groupId));
        $lastForumId = 0;

        if ($enable && empty($forumIds)) {
            $lastForumId = (int) groups_get_groupmeta($groupId, 'last_forum_id');
            $lastGroupIds = $lastForumId ? array_filter((array) get_post_meta($lastForumId, '_last_bbp_group_ids', true)) : [];

            if (
                \in_array($groupId, array_map('intval', $lastGroupIds), true)
                && bbp_get_forum($lastForumId)
                && $groupForumExtension->forum_can_associate_with_group($lastForumId, $groupId, false)
            ) {
                $forumIds = [$lastForumId];
            }
        }

        foreach ($forumIds as $index => $forumId) {
            if (!bbp_get_forum($forumId)) {
                $groupForumExtension->remove_forum(['forum_id' => $forumId, 'group_id' => $groupId]);
                unset($forumIds[$index]);
            }
        }

        $forumIds = array_values($forumIds);
        $forumId = (int) ($forumIds[0] ?? 0);

        bbp_update_forum_group_ids($forumId, [$groupId]);
        bbp_update_group_forum_ids($groupId, $forumIds);

        $group = $groupForumExtension->toggle_group_forum($groupId, $enable, $forumId);

        if (!$enable) {
            return;
        }

        foreach (array_filter([$lastForumId, $forumId]) as $associatedForumId) {
            delete_post_meta($associatedForumId, '_last_bbp_group_ids');
        }

        groups_delete_groupmeta($groupId, 'last_forum_id');

        if ($forumId) {
            return;
        }

        $forumStatuses = [
            'hidden'  => bbp_get_hidden_status_id(),
            'private' => bbp_get_private_status_id(),
        ];

        $forumId = bbp_insert_forum(
            [
                'post_parent'  => bbp_get_group_forums_root_id(),
                'post_title'   => $group->name,
                'post_content' => $group->description,
                'post_status'  => $forumStatuses[$group->status] ?? bbp_get_public_status_id(),
            ]
        );

        $groupForumExtension->new_forum(['forum_id' => $forumId, 'group_id' => $groupId]);
    }

    private function changeGroupMemberRole($functionName, $fieldMappings, $extraArgs = [])
    {
        if (!\function_exists($functionName)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Groups component is not active.', 'bit-pi'),
            ];
        }

        $userId = $this->getUserId($fieldMappings['user_id']);
        $groupId = (int) $fieldMappings['group_id'];

        if (!$userId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User not found.', 'bit-pi'),
            ];
        }

        $isMember = $functionName === 'groups_unban_member' ? groups_is_user_banned($userId, $groupId) : groups_is_user_member($userId, $groupId);

        if (!$isMember) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User is not a member of the group.', 'bit-pi'),
            ];
        }

        $isOrganizer = (bool) groups_is_user_admin($userId, $groupId);

        if ($functionName === 'groups_ban_member' && $isOrganizer) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Group organizers cannot be banned. Demote the organizer first.', 'bit-pi'),
            ];
        }

        $removesOrganizer = $isOrganizer && ($functionName === 'groups_demote_member' || ($extraArgs[0] ?? '') === 'mod');

        if ($removesOrganizer && \count((array) groups_get_group_admins($groupId)) < 2) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('This group must have at least one organizer.', 'bit-pi'),
            ];
        }

        $grantItemAdmin = static function () {
            return true;
        };

        add_filter('bp_is_item_admin', $grantItemAdmin);

        try {
            $updated = $functionName($userId, $groupId, ...$extraArgs);
        } finally {
            remove_filter('bp_is_item_admin', $grantItemAdmin);
        }

        if (!$updated) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to update the group member.', 'bit-pi'),
            ];
        }

        $followUpHooks = [
            'groups_promote_member' => 'groups_promoted_member',
            'groups_demote_member'  => 'groups_demoted_member',
            'groups_ban_member'     => 'groups_banned_member',
            'groups_unban_member'   => 'groups_unbanned_member',
        ];

        do_action($followUpHooks[$functionName], $userId, $groupId);

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'user'  => Utility::getUserInfo($userId),
                'group' => BuddyBossHelper::getGroupData($groupId),
            ],
        ];
    }
}
