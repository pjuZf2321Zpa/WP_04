<?php

namespace BitApps\PiPro\src\Integrations\BuddyBoss\Services;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BP_Friends_Friendship;

if (!\defined('ABSPATH')) {
    exit;
}

final class ConnectionService extends BaseService
{
    public function acceptConnectionRequest()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'initiator_id' => ['required'],
            'friend_id'    => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('friends_accept_friendship')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Connections component is not active.', 'bit-pi'),
            ];
        }

        $initiatorId = $this->getUserId($fieldMappings['initiator_id']);
        $friendId = $this->getUserId($fieldMappings['friend_id']);
        $friendshipId = ($initiatorId && $friendId) ? BP_Friends_Friendship::get_friendship_id($initiatorId, $friendId) : 0;

        if (empty($friendshipId) || !$this->actAsUser($friendId, fn () => friends_accept_friendship($friendshipId))) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('No pending connection request found between these users.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'friendship_id' => $friendshipId,
                'initiator'     => Utility::getUserInfo($initiatorId),
                'friend'        => Utility::getUserInfo($friendId),
            ],
        ];
    }

    public function rejectConnectionRequest()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'initiator_id' => ['required'],
            'friend_id'    => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('friends_reject_friendship')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Connections component is not active.', 'bit-pi'),
            ];
        }

        $initiatorId = $this->getUserId($fieldMappings['initiator_id']);
        $friendId = $this->getUserId($fieldMappings['friend_id']);
        $friendshipId = ($initiatorId && $friendId) ? BP_Friends_Friendship::get_friendship_id($initiatorId, $friendId) : 0;

        if (empty($friendshipId) || !$this->actAsUser($friendId, fn () => friends_reject_friendship($friendshipId))) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('No pending connection request found between these users.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'friendship_id' => $friendshipId,
                'initiator'     => Utility::getUserInfo($initiatorId),
                'friend'        => Utility::getUserInfo($friendId),
            ],
        ];
    }

    public function withdrawConnectionRequest()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'initiator_id' => ['required'],
            'friend_id'    => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('friends_withdraw_friendship')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Connections component is not active.', 'bit-pi'),
            ];
        }

        $initiatorId = $this->getUserId($fieldMappings['initiator_id']);
        $friendId = $this->getUserId($fieldMappings['friend_id']);

        if (!$initiatorId || !$friendId || !$this->actAsUser($initiatorId, fn () => friends_withdraw_friendship($initiatorId, $friendId))) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('No pending connection request found between these users.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'initiator' => Utility::getUserInfo($initiatorId),
                'friend'    => Utility::getUserInfo($friendId),
            ],
        ];
    }

    public function getConnections()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'user_id' => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('friends_get_friend_user_ids')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Connections component is not active.', 'bit-pi'),
            ];
        }

        $userId = $this->getUserId($fieldMappings['user_id']);

        if (!$userId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User not found.', 'bit-pi'),
            ];
        }

        $connections = array_map([Utility::class, 'getUserInfo'], friends_get_friend_user_ids($userId));

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'total'       => \count($connections),
                'connections' => $connections,
            ],
        ];
    }

    public function checkConnectionStatus()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'user_id'   => ['required'],
            'friend_id' => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('friends_check_friendship_status')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Connections component is not active.', 'bit-pi'),
            ];
        }

        $userId = $this->getUserId($fieldMappings['user_id']);
        $friendId = $this->getUserId($fieldMappings['friend_id']);

        if (!$userId || !$friendId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('One or both users not found.', 'bit-pi'),
            ];
        }

        $status = friends_check_friendship_status($userId, $friendId);

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'status'       => $status,
                'is_connected' => $status === 'is_friend',
                'user'         => Utility::getUserInfo($userId),
                'friend'       => Utility::getUserInfo($friendId),
            ],
        ];
    }
}
