<?php

namespace BitApps\PiPro\src\Integrations\BuddyBoss\Services;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BP_Activity_Follow;
use BP_XProfile_ProfileData;

if (!\defined('ABSPATH')) {
    exit;
}

final class MemberService extends BaseService
{
    public function removeMemberProfileType()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'user_id'      => ['required'],
            'profile_type' => ['required', 'string'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('bp_remove_member_type')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Profile Types are not available.', 'bit-pi'),
            ];
        }

        $userId = $this->getUserId($fieldMappings['user_id']);

        if (!$userId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User not found.', 'bit-pi'),
            ];
        }

        $removed = bp_remove_member_type($userId, $fieldMappings['profile_type']);

        if (empty($removed) || is_wp_error($removed)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User does not have this profile type.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'user'          => Utility::getUserInfo($userId),
                'profile_types' => bp_get_member_type($userId, false),
            ],
        ];
    }

    public function getMemberProfileType()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'user_id' => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('bp_get_member_type')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Profile Types are not available.', 'bit-pi'),
            ];
        }

        $userId = $this->getUserId($fieldMappings['user_id']);

        if (!$userId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User not found.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'user'          => Utility::getUserInfo($userId),
                'profile_types' => bp_get_member_type($userId, false) ?: [],
            ],
        ];
    }

    public function getMemberProfile()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'user_id' => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $userId = $this->getUserId($fieldMappings['user_id']);

        if (!$userId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User not found.', 'bit-pi'),
            ];
        }

        $profileFields = [];

        if (class_exists('BP_XProfile_ProfileData')) {
            $allFields = $this->actAsUser(
                $userId,
                static function () use ($userId) {
                    return BP_XProfile_ProfileData::get_all_for_user($userId);
                }
            );

            foreach ($allFields as $fieldName => $field) {
                if (\is_array($field) && \array_key_exists('field_data', $field)) {
                    $profileFields[$fieldName] = maybe_unserialize($field['field_data']);
                }
            }
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => array_merge(
                Utility::getUserInfo($userId),
                [
                    'profile_url'    => \function_exists('bp_core_get_user_domain') ? bp_core_get_user_domain($userId) : '',
                    'profile_types'  => \function_exists('bp_get_member_type') ? (bp_get_member_type($userId, false) ?: []) : [],
                    'last_activity'  => \function_exists('bp_get_user_last_activity') ? bp_get_user_last_activity($userId) : '',
                    'profile_fields' => $profileFields,
                ]
            ),
        ];
    }

    public function deleteProfileFieldData()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'user_id'  => ['required'],
            'field_id' => ['required', 'integer'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('xprofile_delete_field_data')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Extended Profile component is not active.', 'bit-pi'),
            ];
        }

        $userId = $this->getUserId($fieldMappings['user_id']);

        if (!$userId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User not found.', 'bit-pi'),
            ];
        }

        if (!xprofile_delete_field_data((int) $fieldMappings['field_id'], $userId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to delete profile field data.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'field_id' => (int) $fieldMappings['field_id'],
                'user'     => Utility::getUserInfo($userId),
            ],
        ];
    }

    public function markMemberAsSpammer()
    {
        return $this->updateSpammerStatus('spam');
    }

    public function unmarkMemberAsSpammer()
    {
        return $this->updateSpammerStatus('ham');
    }

    public function getFollowers()
    {
        return $this->getFollowList('bp_get_followers', 'followers');
    }

    public function getFollowing()
    {
        return $this->getFollowList('bp_get_following', 'following');
    }

    private function updateSpammerStatus($status)
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'user_id' => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('bp_core_process_spammer_status')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Members functions not found.', 'bit-pi'),
            ];
        }

        $userId = $this->getUserId($fieldMappings['user_id']);

        if (!$userId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User not found.', 'bit-pi'),
            ];
        }

        if (!bp_core_process_spammer_status($userId, $status)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to update spammer status. Super admins cannot be marked as spammers.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => array_merge(Utility::getUserInfo($userId), ['is_spammer' => $status === 'spam']),
        ];
    }

    private function getFollowList($functionName, $responseKey)
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'user_id' => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists($functionName)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Follow functions not found.', 'bit-pi'),
            ];
        }

        $userId = $this->getUserId($fieldMappings['user_id']);

        if (!$userId) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User not found.', 'bit-pi'),
            ];
        }

        $userIds = (array) $functionName(['user_id' => $userId, 'page' => 1, 'per_page' => 500]);
        cache_users($userIds);
        $counts = class_exists('BP_Activity_Follow') ? BP_Activity_Follow::get_counts($userId) : [];

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'total'      => $counts[$responseKey] ?? \count($userIds),
                $responseKey => array_map([Utility::class, 'getUserInfo'], $userIds),
            ],
        ];
    }
}
