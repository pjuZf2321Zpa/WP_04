<?php

namespace BitApps\PiPro\src\Integrations\BuddyBoss\Services;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\BuddyBoss\helper\BuddyBossHelper;
use BP_Messages_Message;
use BP_Messages_Thread;

if (!\defined('ABSPATH')) {
    exit;
}

final class MessageService extends BaseService
{
    public function replyToConversation()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'thread_id' => ['required', 'integer'],
            'sender_id' => ['required'],
            'content'   => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('messages_new_message')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Messages component is not active.', 'bit-pi'),
            ];
        }

        $senderId = $this->getUserId($fieldMappings['sender_id']);
        $threadId = (int) $fieldMappings['thread_id'];

        if (!$senderId || !BP_Messages_Thread::check_access($threadId, $senderId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Sender is not a participant of this conversation.', 'bit-pi'),
            ];
        }

        $uploadKeys = array_flip(['group', 'media', 'document', 'video', 'gif_data']);
        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $requestUploads = array_intersect_key($_POST, $uploadKeys);
        $_POST = array_diff_key($_POST, $uploadKeys);

        try {
            $messageId = $this->actAsUser(
                $senderId,
                fn () => messages_new_message(
                    [
                        'thread_id'  => $threadId,
                        'sender_id'  => $senderId,
                        'content'    => (string) $fieldMappings['content'],
                        'error_type' => 'wp_error',
                        'return'     => 'id',
                    ]
                )
            );
        } finally {
            $_POST = array_merge($_POST, $requestUploads);
        }

        if (empty($messageId) || is_wp_error($messageId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => is_wp_error($messageId) ? $messageId->get_error_message() : __('Failed to send reply.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => array_merge(['message_id' => $messageId], $this->actAsUser($senderId, fn () => BuddyBossHelper::getThreadData($threadId))),
        ];
    }

    public function deleteConversation()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'thread_id' => ['required', 'integer'],
            'user_id'   => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('messages_delete_thread')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Messages component is not active.', 'bit-pi'),
            ];
        }

        $userId = $this->getUserId($fieldMappings['user_id']);
        $threadId = (int) $fieldMappings['thread_id'];

        if (!$userId || !BP_Messages_Thread::check_access($threadId, $userId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User is not a participant of this conversation.', 'bit-pi'),
            ];
        }

        if (!$this->actAsUser($userId, fn () => messages_delete_thread($threadId, $userId))) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to delete conversation.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'thread_id' => $threadId,
                'user'      => Utility::getUserInfo($userId),
            ],
        ];
    }

    public function markConversationRead()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'thread_id' => ['required', 'integer'],
            'user_id'   => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('messages_mark_thread_read')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Messages component is not active.', 'bit-pi'),
            ];
        }

        $userId = $this->getUserId($fieldMappings['user_id']);
        $threadId = (int) $fieldMappings['thread_id'];

        if (!$userId || !BP_Messages_Thread::check_access($threadId, $userId)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User is not a participant of this conversation.', 'bit-pi'),
            ];
        }

        $updated = $this->actAsUser($userId, fn () => messages_mark_thread_read($threadId, $userId));

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'thread_id'  => $threadId,
                'was_unread' => !empty($updated),
                'user'       => Utility::getUserInfo($userId),
            ],
        ];
    }

    public function sendSiteNotice()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'subject' => ['required'],
            'message' => ['required'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!\function_exists('messages_send_notice')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Messages component is not active.', 'bit-pi'),
            ];
        }

        $grantModerate = static function ($canDo, $capability) {
            return $capability === 'bp_moderate' ? true : $canDo;
        };

        add_filter('bp_current_user_can', $grantModerate, 10, 2);

        try {
            $sent = messages_send_notice((string) $fieldMappings['subject'], (string) $fieldMappings['message']);
        } finally {
            remove_filter('bp_current_user_can', $grantModerate, 10);
        }

        if (!$sent) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Failed to send site notice.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => [
                'subject' => (string) $fieldMappings['subject'],
                'message' => (string) $fieldMappings['message'],
            ],
        ];
    }

    public function getConversation()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = [
            'thread_id' => ['required', 'integer'],
        ];

        $validationErrors = IntegrationHelper::validateFieldMap($fieldMappings, $validationRules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        if (!class_exists('BP_Messages_Thread')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('BuddyBoss Messages component is not active.', 'bit-pi'),
            ];
        }

        $threadId = (int) $fieldMappings['thread_id'];
        $activeRecipients = array_filter(BP_Messages_Thread::get_recipients_for_thread($threadId), fn ($recipient) => empty($recipient->is_deleted));
        $participantId = (int) (current(wp_list_pluck($activeRecipients, 'user_id')) ?: 0);

        if (!$participantId || !$this->actAsUser($participantId, fn () => BP_Messages_Thread::is_valid($threadId))) {
            return [
                'status_code' => 404,
                'payload'     => $fieldMappings,
                'response'    => __('Conversation not found.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fieldMappings,
            'response'    => $this->actAsUser($participantId, fn () => $this->getThreadWithMessages($threadId)),
        ];
    }

    private function getThreadWithMessages($threadId)
    {
        $result = BP_Messages_Message::get(
            [
                'include_threads' => [$threadId],
                'is_deleted'      => false,
                'order'           => 'DESC',
                'per_page'        => 200,
            ]
        );
        $messages = [];

        foreach (array_reverse((array) ($result['messages'] ?? [])) as $message) {
            $messages[] = array_merge(Utility::normalizeData($message), ['sender' => Utility::getUserInfo($message->sender_id)]);
        }

        return array_merge(BuddyBossHelper::getThreadData($threadId), ['messages' => $messages]);
    }
}
