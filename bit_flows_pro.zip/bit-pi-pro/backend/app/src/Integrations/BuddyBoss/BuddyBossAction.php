<?php

namespace BitApps\PiPro\src\Integrations\BuddyBoss;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\BuddyBoss\helper\BuddyBossHelper;

if (!\defined('ABSPATH')) {
    exit;
}

class BuddyBossAction implements ActionInterface
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeBuddyBossAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'] ?? 200,
            $executedNodeAction['payload'] ?? [],
            $executedNodeAction['response'] ?? []
        );
    }

    private function executeBuddyBossAction()
    {
        if (!BuddyBossHelper::isPluginInstalled()) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('BuddyBoss plugin is not active.', 'bit-pi'),
            ];
        }

        $buddyBossService = new BuddyBossService($this->nodeInfoProvider);

        $machineSlug = $this->nodeInfoProvider->getMachineSlug();

        if (method_exists($buddyBossService, $machineSlug)) {
            $result = $buddyBossService->{$machineSlug}();

            $result['response'] = self::withoutUserSecrets($result['response'] ?? []);

            return $result;
        }

        $serviceInstance = IntegrationHelper::getServiceInstanceByMachineSlug($machineSlug, $this->nodeInfoProvider);

        if (!$serviceInstance) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('BuddyBoss action not found.', 'bit-pi'),
            ];
        }

        return $serviceInstance->{$machineSlug}();
    }

    private static function withoutUserSecrets($data)
    {
        if (\is_object($data)) {
            $data = get_object_vars($data);
        }

        if (!\is_array($data)) {
            return $data;
        }

        unset($data['user_pass'], $data['user_activation_key']);

        foreach ($data as $key => $value) {
            if (\is_array($value) || \is_object($value)) {
                $data[$key] = self::withoutUserSecrets($value);
            }
        }

        return $data;
    }
}
