<?php

namespace BitApps\PiPro\src\Integrations\BuddyBoss;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!\defined('ABSPATH')) {
    exit;
}

class BuddyBossHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'userCreatesGroup' => [
                'hook'     => 'groups_group_create_complete',
                'callback' => [BuddyBossTrigger::class, 'userCreatesGroup'],
            ],
            'userAcceptsFriendshipRequest' => [
                'hook'          => 'friends_friendship_accepted',
                'callback'      => [BuddyBossTrigger::class, 'userAcceptsFriendshipRequest'],
                'accepted_args' => 4
            ],
            'userAccountActivated' => [
                'hook'     => 'bp_core_activated_user',
                'callback' => [BuddyBossTrigger::class, 'userAccountActivated'],
            ],
            'userGainsFollower' => [
                'hook'     => 'bp_start_following',
                'callback' => [BuddyBossTrigger::class, 'userGainsFollower'],
            ],
            'userJoinsPublicGroup' => [
                'hook'          => 'groups_join_group',
                'callback'      => [BuddyBossTrigger::class, 'userJoinsPublicGroup'],
                'accepted_args' => 2
            ],
            'userJoinsPrivateGroup' => [
                'hook'          => ['groups_membership_accepted', 'groups_accept_invite'],
                'callback'      => [BuddyBossTrigger::class, 'userJoinsPrivateGroup'],
                'accepted_args' => 2
            ],
            'userJoinsSpecificTypeGroup' => [
                'hook'          => 'groups_join_group',
                'callback'      => [BuddyBossTrigger::class, 'userJoinsSpecificTypeGroup'],
                'accepted_args' => 2
            ],
            'userLeavesGroup' => [
                'hook'          => 'groups_leave_group',
                'callback'      => [BuddyBossTrigger::class, 'userLeavesGroup'],
                'accepted_args' => 2
            ],
            'userLeavesPrivateGroup' => [
                'hook'          => ['groups_leave_group', 'groups_remove_member'],
                'callback'      => [BuddyBossTrigger::class, 'userLeavesPrivateGroup'],
                'accepted_args' => 2
            ],
            'userProfileTypeSetToSpecificType' => [
                'hook'          => 'bp_set_member_type',
                'callback'      => [BuddyBossTrigger::class, 'userProfileTypeSetToSpecificType'],
                'accepted_args' => 3
            ],
            'userReceivesPrivateMessage' => [
                'hook'          => 'messages_message_sent',
                'callback'      => [BuddyBossTrigger::class, 'userReceivesPrivateMessage'],
                'accepted_args' => 5
            ],
            'userRequestsAccessPrivateGroup' => [
                'hook'          => 'groups_membership_requested',
                'callback'      => [BuddyBossTrigger::class, 'userRequestsAccessPrivateGroup'],
                'accepted_args' => 3
            ],
            'userSendsFriendshipRequest' => [
                'hook'          => 'friends_friendship_requested',
                'callback'      => [BuddyBossTrigger::class, 'userSendsFriendshipRequest'],
                'accepted_args' => 3
            ],
            'userUpdatesProfile' => [
                'hook'          => 'xprofile_updated_profile',
                'callback'      => [BuddyBossTrigger::class, 'userUpdatesProfile'],
                'accepted_args' => 5
            ],
            'activityUpdatePosted' => [
                'hook'          => ['bp_activity_posted_update', 'bp_activity_after_save'],
                'callback'      => [BuddyBossTrigger::class, 'activityUpdatePosted'],
                'accepted_args' => 3,
            ],
            'groupActivityPosted' => [
                'hook'          => ['bp_groups_posted_update', 'bp_activity_after_save'],
                'callback'      => [BuddyBossTrigger::class, 'groupActivityPosted'],
                'accepted_args' => 4,
            ],
            'activityCommentPosted' => [
                'hook'     => 'bp_activity_comment_posted',
                'callback' => [BuddyBossTrigger::class, 'activityCommentPosted'],
            ],
            'activityDeleted' => [
                'hook'          => 'bp_activity_after_delete',
                'callback'      => [BuddyBossTrigger::class, 'activityDeleted'],
                'accepted_args' => 2,
            ],
            'reactionAdded' => [
                'hook'          => 'bb_reaction_after_add_user_item_reaction',
                'callback'      => [BuddyBossTrigger::class, 'reactionAdded'],
                'accepted_args' => 2,
            ],
            'reactionRemoved' => [
                'hook' => [
                    'bb_reaction_after_remove_user_item_reaction',
                    'bb_reaction_before_remove_user_item_reactions',
                    'bb_reaction_after_remove_user_item_reactions',
                ],
                'callback'      => [BuddyBossTrigger::class, 'reactionRemoved'],
                'accepted_args' => 3,
            ],
            'forumCreated' => [
                'hook'          => 'transition_post_status',
                'callback'      => [BuddyBossTrigger::class, 'forumCreated'],
                'accepted_args' => 3,
            ],
            'forumUpdated' => [
                'hook'          => 'post_updated',
                'callback'      => [BuddyBossTrigger::class, 'forumUpdated'],
                'accepted_args' => 3,
            ],
            'topicCreated' => [
                'hook'     => 'bbp_new_topic',
                'callback' => [BuddyBossTrigger::class, 'topicCreated'],
            ],
            'topicUpdated' => [
                'hook'          => 'post_updated',
                'callback'      => [BuddyBossTrigger::class, 'topicUpdated'],
                'accepted_args' => 3,
            ],
            'topicClosed' => [
                'hook'     => 'bbp_closed_topic',
                'callback' => [BuddyBossTrigger::class, 'topicClosed'],
            ],
            'topicOpened' => [
                'hook'     => 'bbp_opened_topic',
                'callback' => [BuddyBossTrigger::class, 'topicOpened'],
            ],
            'topicTrashed' => [
                'hook'     => 'bbp_trashed_topic',
                'callback' => [BuddyBossTrigger::class, 'topicTrashed'],
            ],
            'topicSpammed' => [
                'hook'     => 'bbp_spammed_topic',
                'callback' => [BuddyBossTrigger::class, 'topicSpammed'],
            ],
            'replyCreated' => [
                'hook'          => 'bbp_new_reply',
                'callback'      => [BuddyBossTrigger::class, 'replyCreated'],
                'accepted_args' => 7,
            ],
            'replyUpdated' => [
                'hook'          => 'post_updated',
                'callback'      => [BuddyBossTrigger::class, 'replyUpdated'],
                'accepted_args' => 3,
            ],
            'replyTrashed' => [
                'hook'     => 'bbp_trashed_reply',
                'callback' => [BuddyBossTrigger::class, 'replyTrashed'],
            ],
            'replySpammed' => [
                'hook'     => 'bbp_spammed_reply',
                'callback' => [BuddyBossTrigger::class, 'replySpammed'],
            ],
            'topicFavorited' => [
                'hook'          => 'bbp_add_user_favorite',
                'callback'      => [BuddyBossTrigger::class, 'topicFavorited'],
                'accepted_args' => 2,
            ],
            'topicUnfavorited' => [
                'hook'          => 'bbp_remove_user_favorite',
                'callback'      => [BuddyBossTrigger::class, 'topicUnfavorited'],
                'accepted_args' => 2,
            ],
            'forumSubscribed' => [
                'hook'          => 'bb_create_subscription',
                'callback'      => [BuddyBossTrigger::class, 'forumSubscribed'],
                'accepted_args' => 2,
            ],
            'forumUnsubscribed' => [
                'hook'     => ['bb_subscriptions_before_delete_subscription', 'bb_delete_subscription'],
                'callback' => [BuddyBossTrigger::class, 'forumUnsubscribed'],
            ],
            'topicSubscribed' => [
                'hook'          => 'bb_create_subscription',
                'callback'      => [BuddyBossTrigger::class, 'topicSubscribed'],
                'accepted_args' => 2,
            ],
            'topicUnsubscribed' => [
                'hook'     => ['bb_subscriptions_before_delete_subscription', 'bb_delete_subscription'],
                'callback' => [BuddyBossTrigger::class, 'topicUnsubscribed'],
            ],
            'groupDetailsUpdated' => [
                'hook'          => 'groups_details_updated',
                'callback'      => [BuddyBossTrigger::class, 'groupDetailsUpdated'],
                'accepted_args' => 3,
            ],
            'groupDeleted' => [
                'hook'     => ['groups_before_delete_group', 'groups_delete_group'],
                'callback' => [BuddyBossTrigger::class, 'groupDeleted'],
            ],
            'groupMemberPromoted' => [
                'hook'          => ['groups_promote_member', 'groups_member_after_save'],
                'callback'      => [BuddyBossTrigger::class, 'groupMemberPromoted'],
                'accepted_args' => 3,
            ],
            'groupMemberDemoted' => [
                'hook'          => ['groups_demote_member', 'groups_member_after_save'],
                'callback'      => [BuddyBossTrigger::class, 'groupMemberDemoted'],
                'accepted_args' => 2,
            ],
            'groupMemberBanned' => [
                'hook'          => ['groups_ban_member', 'groups_member_after_save'],
                'callback'      => [BuddyBossTrigger::class, 'groupMemberBanned'],
                'accepted_args' => 2,
            ],
            'groupMemberUnbanned' => [
                'hook'          => ['groups_unban_member', 'groups_member_after_save'],
                'callback'      => [BuddyBossTrigger::class, 'groupMemberUnbanned'],
                'accepted_args' => 2,
            ],
            'groupMemberRemoved' => [
                'hook'          => ['groups_remove_member', 'groups_member_after_remove'],
                'callback'      => [BuddyBossTrigger::class, 'groupMemberRemoved'],
                'accepted_args' => 2,
            ],
            'groupInvitationSent' => [
                'hook'          => 'groups_invite_user',
                'callback'      => [BuddyBossTrigger::class, 'groupInvitationSent'],
                'accepted_args' => 2,
            ],
            'groupInvitationRejected' => [
                'hook'          => ['bp_invitation_before_delete', 'groups_reject_invite'],
                'callback'      => [BuddyBossTrigger::class, 'groupInvitationRejected'],
                'accepted_args' => 3,
            ],
            'groupInvitationRevoked' => [
                'hook'          => 'groups_uninvite_user',
                'callback'      => [BuddyBossTrigger::class, 'groupInvitationRevoked'],
                'accepted_args' => 3,
            ],
            'groupMembershipRequestRejected' => [
                'hook'          => 'groups_membership_rejected',
                'callback'      => [BuddyBossTrigger::class, 'groupMembershipRequestRejected'],
                'accepted_args' => 2,
            ],
            'groupTypeSet' => [
                'hook'          => 'set_object_terms',
                'callback'      => [BuddyBossTrigger::class, 'groupTypeSet'],
                'accepted_args' => 6,
            ],
            'groupTypeRemoved' => [
                'hook'          => 'deleted_term_relationships',
                'callback'      => [BuddyBossTrigger::class, 'groupTypeRemoved'],
                'accepted_args' => 3,
            ],
            'memberRegistered' => [
                'hook'          => 'bp_core_signup_user',
                'callback'      => [BuddyBossTrigger::class, 'memberRegistered'],
                'accepted_args' => 5,
            ],
            'profilePhotoUpdated' => [
                'hook'     => 'xprofile_avatar_uploaded',
                'callback' => [BuddyBossTrigger::class, 'profilePhotoUpdated'],
            ],
            'profileTypeRemoved' => [
                'hook'          => 'deleted_term_relationships',
                'callback'      => [BuddyBossTrigger::class, 'profileTypeRemoved'],
                'accepted_args' => 3,
            ],
            'memberSuspended' => [
                'hook'          => 'bp_suspend_hide_user',
                'callback'      => [BuddyBossTrigger::class, 'memberSuspended'],
                'accepted_args' => 3,
            ],
            'memberUnsuspended' => [
                'hook'          => 'bp_suspend_unhide_user',
                'callback'      => [BuddyBossTrigger::class, 'memberUnsuspended'],
                'accepted_args' => 4,
            ],
            'memberMarkedAsSpammer' => [
                'hook'     => 'bp_make_spam_user',
                'callback' => [BuddyBossTrigger::class, 'memberMarkedAsSpammer'],
            ],
            'memberUnmarkedAsSpammer' => [
                'hook'     => 'bp_make_ham_user',
                'callback' => [BuddyBossTrigger::class, 'memberUnmarkedAsSpammer'],
            ],
            'accountDeleted' => [
                'hook'     => ['bp_core_pre_delete_account', 'bp_core_deleted_account'],
                'callback' => [BuddyBossTrigger::class, 'accountDeleted'],
            ],
            'userUnfollowed' => [
                'hook'     => 'bp_stop_following',
                'callback' => [BuddyBossTrigger::class, 'userUnfollowed'],
            ],
            'emailInvitationSent' => [
                'hook'          => 'bp_member_invite_submit',
                'callback'      => [BuddyBossTrigger::class, 'emailInvitationSent'],
                'accepted_args' => 2,
            ],
            'invitedMemberActivated' => [
                'hook'          => 'bp_invites_member_invite_activate_user',
                'callback'      => [BuddyBossTrigger::class, 'invitedMemberActivated'],
                'accepted_args' => 3,
            ],
            'connectionRequestRejected' => [
                'hook'          => 'friends_friendship_rejected',
                'callback'      => [BuddyBossTrigger::class, 'connectionRequestRejected'],
                'accepted_args' => 2,
            ],
            'connectionRequestWithdrawn' => [
                'hook'          => 'friends_friendship_withdrawn',
                'callback'      => [BuddyBossTrigger::class, 'connectionRequestWithdrawn'],
                'accepted_args' => 2,
            ],
            'connectionRemoved' => [
                'hook'          => 'friends_friendship_deleted',
                'callback'      => [BuddyBossTrigger::class, 'connectionRemoved'],
                'accepted_args' => 3,
            ],
            'siteNoticeSent' => [
                'hook'          => 'messages_send_notice',
                'callback'      => [BuddyBossTrigger::class, 'siteNoticeSent'],
                'accepted_args' => 2,
            ],
            'photoUploaded' => [
                'hook'     => ['bp_media_before_save', 'bp_media_after_save', 'bp_media_add'],
                'callback' => [BuddyBossTrigger::class, 'photoUploaded'],
            ],
            'photoDeleted' => [
                'hook'     => 'bp_media_after_delete',
                'callback' => [BuddyBossTrigger::class, 'photoDeleted'],
            ],
            'documentUploaded' => [
                'hook'     => ['bp_document_before_save', 'bp_document_after_save', 'bp_document_add'],
                'callback' => [BuddyBossTrigger::class, 'documentUploaded'],
            ],
            'documentDeleted' => [
                'hook'     => 'bp_document_after_delete',
                'callback' => [BuddyBossTrigger::class, 'documentDeleted'],
            ],
            'videoUploaded' => [
                'hook'     => ['bp_video_before_save', 'bp_video_after_save', 'bp_video_add'],
                'callback' => [BuddyBossTrigger::class, 'videoUploaded'],
            ],
            'videoDeleted' => [
                'hook'     => 'bp_video_after_delete',
                'callback' => [BuddyBossTrigger::class, 'videoDeleted'],
            ],
            'memberBlocked' => [
                'hook'     => 'bp_moderation_after_save',
                'callback' => [BuddyBossTrigger::class, 'memberBlocked'],
            ],
            'memberReported' => [
                'hook'     => 'bp_moderation_after_save',
                'callback' => [BuddyBossTrigger::class, 'memberReported'],
            ],
            'contentReported' => [
                'hook'     => 'bp_moderation_after_save',
                'callback' => [BuddyBossTrigger::class, 'contentReported'],
            ],
            'pollCreated' => [
                'hook'          => 'bb_poll_after_add_poll',
                'callback'      => [BuddyBossTrigger::class, 'pollCreated'],
                'accepted_args' => 2,
            ],
            'pollVoted' => [
                'hook'          => 'bb_poll_after_add_poll_vote',
                'callback'      => [BuddyBossTrigger::class, 'pollVoted'],
                'accepted_args' => 2,
            ],
            'pollVoteRemoved' => [
                'hook'          => 'bb_poll_after_remove_poll_votes',
                'callback'      => [BuddyBossTrigger::class, 'pollVoteRemoved'],
                'accepted_args' => 3,
            ],
        ];
    }
}
