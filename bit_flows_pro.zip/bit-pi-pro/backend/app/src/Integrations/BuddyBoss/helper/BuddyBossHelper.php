<?php

namespace BitApps\PiPro\src\Integrations\BuddyBoss\helper;

use BitApps\Pi\Helpers\Utility;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\PiPro\Deps\BitApps\WPValidator\Validator;
use BP_Activity_Activity;
use BP_Messages_Thread;

if (!\defined('ABSPATH')) {
    exit;
}

final class BuddyBossHelper
{
    public static function isPluginInstalled()
    {
        return \function_exists('buddypress') && isset(buddypress()->buddyboss) && buddypress()->buddyboss;
    }

    public static function validateFieldMap($fieldMappings, $rules, $payload = null)
    {
        $validator = new Validator();
        $validation = $validator->make($fieldMappings, $rules);

        if ($validation->fails()) {
            return [
                'response'    => $validation->errors(),
                'payload'     => $payload ?? $fieldMappings,
                'status_code' => 400
            ];
        }
    }

    public static function getUser($user)
    {
        if (is_numeric($user)) {
            return get_user_by('id', (int) $user);
        }

        return \is_string($user) && $user !== '' ? get_user_by('email', trim($user)) : false;
    }

    public static function preparedPostActionResponse($activityId, $userId, $groupId = null)
    {
        $response = [
            'activity_id' => $activityId,
            'user_id'     => $userId,
        ];

        if ($groupId !== null) {
            $response['group_id'] = $groupId;
        }

        if (!\function_exists('bp_activity_get_specific') || !isset($response['activity_id'])) {
            return $response;
        }

        $activity = bp_activity_get_specific(['activity_ids' => $response['activity_id']]);

        if (!empty($activity['activities'])) {
            $response['activities'] = Utility::jsonEncodeDecode($activity);
        }

        return $response;
    }

    public static function prepareActivityPayload($fieldMappings, $component = 'activity', $userId = null, $groupId = null, $userActivityId = null)
    {
        $payloadData = [
            'action'        => $fieldMappings['activity_action'] ?? '',
            'content'       => $fieldMappings['activity_content'] ?? '',
            'primary_link'  => $fieldMappings['activity_action_link'] ?? '',
            'hide_sitewide' => $fieldMappings['hide_sitewide'] ?? false,
            'component'     => $component,
            'type'          => 'activity_update',
            'user_id'       => $userId,
        ];

        if ($groupId !== null) {
            $payloadData['item_id'] = $groupId;
        }

        if ($userActivityId !== null) {
            $payloadData['secondary_item_id'] = $userActivityId;
        }

        return $payloadData;
    }

    public static function getGroupsTypes()
    {
        if (!self::isPluginInstalled()) {
            return Response::error(__('BuddyBoss plugin is not active.', 'bit-pi'));
        }

        if (!\function_exists('bp_groups_get_group_types')) {
            return Response::error(__('BuddyBoss Group types functions not found.', 'bit-pi'));
        }

        $data = [];
        $types = bp_groups_get_group_types([], 'objects');

        foreach ($types as $key => $type) {
            $data[] = [
                'label' => $type->labels['singular_name'] ?? $type->labels['name'] ?? $key,
                'value' => $key
            ];
        }

        return Response::success($data);
    }

    public static function getAllGroups()
    {
        if (!self::isPluginInstalled()) {
            return Response::error(__('BuddyBoss plugin is not active.', 'bit-pi'));
        }

        if (!\function_exists('groups_get_groups')) {
            return Response::error(__('BuddyBoss Groups functions not found.', 'bit-pi'));
        }

        $groups = groups_get_groups(['per_page' => -1, 'show_hidden' => true]);

        $data = [];
        if (!empty($groups['groups'])) {
            foreach ($groups['groups'] as $group) {
                $data[] = [
                    'label' => $group->name,
                    'value' => $group->id
                ];
            }
        }

        return Response::success($data);
    }

    public static function getAllProfileTypes()
    {
        if (!self::isPluginInstalled()) {
            return Response::error(__('BuddyBoss plugin is not active.', 'bit-pi'));
        }

        if (!\function_exists('bp_get_member_types')) {
            return Response::error(__('BuddyBoss member type functions not found.', 'bit-pi'));
        }

        $types = bp_get_member_types([], 'objects');
        $data = [];

        foreach ($types as $key => $type) {
            $data[] = [
                'label' => $type->labels['singular_name'] ?? $type->labels['name'] ?? $key,
                'value' => $key
            ];
        }

        return Response::success($data);
    }

    public static function getAllForums()
    {
        if (!self::isPluginInstalled()) {
            return Response::error(__('BuddyBoss plugin is not active.', 'bit-pi'));
        }

        if (!\function_exists('bbp_get_forum_post_type')) {
            return Response::error(__('BuddyBoss Forum functions not found.', 'bit-pi'));
        }

        $forums = get_posts(
            [
                'post_type'      => bbp_get_forum_post_type(),
                'posts_per_page' => -1,
                'post_status'    => ['publish', 'private', 'hidden']
            ]
        );

        $data = [];
        foreach ($forums as $forum) {
            $data[] = [
                'label' => $forum->post_title,
                'value' => $forum->ID
            ];
        }

        return Response::success($data);
    }

    public static function getExtendedProfileFields()
    {
        if (!self::isPluginInstalled()) {
            return Response::error(__('BuddyBoss plugin is not active.', 'bit-pi'));
        }

        if (!\function_exists('bp_xprofile_get_groups')) {
            return Response::error(__('BuddyBoss Extended Profile functions not found.', 'bit-pi'));
        }

        $groups = bp_xprofile_get_groups(['fetch_fields' => true]);
        $data = [];

        foreach ($groups as $group) {
            if (!empty($group->fields)) {
                foreach ($group->fields as $field) {
                    $data[] = [
                        'value' => $field->id,
                        'label' => $field->name,
                    ];
                }
            }
        }

        return Response::success($data);
    }

    public static function getAllUsers()
    {
        if (!self::isPluginInstalled()) {
            return Response::error(__('BuddyBoss plugin is not active.', 'bit-pi'));
        }

        $data = array_map(
            function ($user) {
                return [
                    'label' => $user->display_name . ' (' . $user->user_email . ')',
                    'value' => (int) $user->ID,
                ];
            },
            get_users(['fields' => ['ID', 'display_name', 'user_email']])
        );

        return Response::success($data);
    }

    public static function getAllActivities()
    {
        if (!self::isPluginInstalled()) {
            return Response::error(__('BuddyBoss plugin is not active.', 'bit-pi'));
        }

        if (!\function_exists('bp_activity_get')) {
            return Response::error(__('BuddyBoss Activity functions not found.', 'bit-pi'));
        }

        $activities = bp_activity_get(
            [
                'show_hidden'       => true,
                'per_page'          => 200,
                'update_meta_cache' => false,
            ]
        );
        $data = [];

        foreach ($activities['activities'] ?? [] as $activity) {
            $summary = wp_strip_all_tags($activity->content ?: $activity->action);

            $data[] = [
                'label' => '#' . $activity->id . ' - ' . wp_trim_words(html_entity_decode($summary, ENT_QUOTES), 12, '…'),
                'value' => (int) $activity->id,
            ];
        }

        return Response::success($data);
    }

    public static function getAllTopics()
    {
        if (!self::isPluginInstalled()) {
            return Response::error(__('BuddyBoss plugin is not active.', 'bit-pi'));
        }

        if (!\function_exists('bbp_get_topic_post_type')) {
            return Response::error(__('BuddyBoss Forum functions not found.', 'bit-pi'));
        }

        $topics = get_posts(
            [
                'post_type'              => bbp_get_topic_post_type(),
                'posts_per_page'         => 500,
                'post_status'            => [bbp_get_public_status_id(), bbp_get_closed_status_id()],
                'no_found_rows'          => true,
                'update_post_meta_cache' => false,
                'update_post_term_cache' => false,
            ]
        );

        $data = [];

        foreach ($topics as $topic) {
            $data[] = [
                'label' => $topic->post_title,
                'value' => $topic->ID,
            ];
        }

        return Response::success($data);
    }

    public static function getAllReactions()
    {
        if (!self::isPluginInstalled()) {
            return Response::error(__('BuddyBoss plugin is not active.', 'bit-pi'));
        }

        if (!\function_exists('bb_active_reactions')) {
            return Response::error(__('BuddyBoss Reaction functions not found.', 'bit-pi'));
        }

        $data = [];

        foreach (bb_active_reactions() as $reaction) {
            $data[] = [
                'label' => $reaction['name'],
                'value' => (int) $reaction['id'],
            ];
        }

        return Response::success($data);
    }

    public static function getActivityData($activityId)
    {
        if (!class_exists('BP_Activity_Activity')) {
            return ['id' => (int) $activityId];
        }

        $activity = new BP_Activity_Activity((int) $activityId);

        if (empty($activity->id)) {
            return ['id' => (int) $activityId];
        }

        $data = Utility::normalizeData($activity);
        unset($data['errors'], $data['error_type']);

        $data['permalink'] = \function_exists('bp_activity_get_permalink') ? bp_activity_get_permalink($activity->id, $activity) : '';
        $data['user'] = Utility::getUserInfo($activity->user_id);

        return $data;
    }

    public static function getGroupData($groupId)
    {
        if (!\function_exists('groups_get_group')) {
            return ['id' => (int) $groupId];
        }

        $group = groups_get_group((int) $groupId);

        if (empty($group->id)) {
            return ['id' => (int) $groupId];
        }

        $data = Utility::normalizeData($group);
        unset($data['args']);

        $data['total_member_count'] = $group->total_member_count;
        $data['last_activity'] = $group->last_activity;
        $data['type'] = \function_exists('bp_groups_get_group_type') ? bp_groups_get_group_type($group->id, false) : '';
        $data['permalink'] = \function_exists('bp_get_group_permalink') ? bp_get_group_permalink($group) : '';
        $data['avatar_url'] = \function_exists('bp_get_group_avatar_url') ? bp_get_group_avatar_url($group) : '';
        $data['cover_url'] = \function_exists('bp_get_group_cover_url') ? bp_get_group_cover_url($group) : '';
        $data['creator'] = Utility::getUserInfo($group->creator_id);
        $data['settings'] = self::getGroupSettings($group->id);

        return $data;
    }

    public static function getGroupSettings($groupId)
    {
        $settingGetters = [
            'invite_status'        => 'bp_group_get_invite_status',
            'activity_feed_status' => 'bp_group_get_activity_feed_status',
            'media_status'         => 'bp_group_get_media_status',
            'album_status'         => 'bp_group_get_album_status',
            'document_status'      => 'bp_group_get_document_status',
            'video_status'         => 'bp_group_get_video_status',
            'message_status'       => 'bp_group_get_message_status',
        ];

        $settings = [];

        foreach ($settingGetters as $setting => $getter) {
            if (\function_exists($getter)) {
                $settings[$setting] = $getter($groupId);
            }
        }

        $forumIds = \function_exists('bbp_get_group_forum_ids') ? bbp_get_group_forum_ids($groupId) : [];
        $settings['forum_id'] = (int) ($forumIds[0] ?? 0);

        return $settings;
    }

    public static function getForumPostData($postId)
    {
        $post = empty($postId) ? null : get_post((int) $postId);

        if (!$post) {
            return [];
        }

        $data = Utility::normalizeData($post);
        $data['permalink'] = get_permalink($post);
        $data['author'] = Utility::getUserInfo($post->post_author);

        return $data;
    }

    public static function getTopicData($topicId)
    {
        $forumId = \function_exists('bbp_get_topic_forum_id') ? bbp_get_topic_forum_id($topicId) : 0;

        return [
            'topic' => self::getForumPostData($topicId),
            'forum' => self::getForumPostData($forumId),
        ];
    }

    public static function getReplyData($replyId)
    {
        $topicId = \function_exists('bbp_get_reply_topic_id') ? bbp_get_reply_topic_id($replyId) : 0;

        return array_merge(['reply' => self::getForumPostData($replyId)], self::getTopicData($topicId));
    }

    public static function getRecordData($record)
    {
        $data = Utility::normalizeData($record);
        unset($data['errors'], $data['error_type']);

        if (!empty($record->attachment_id)) {
            $data['attachment_url'] = wp_get_attachment_url($record->attachment_id);
        }

        $data['user'] = Utility::getUserInfo($record->user_id ?? 0);

        return $data;
    }

    public static function getThreadData($threadId)
    {
        if (!class_exists('BP_Messages_Thread')) {
            return ['thread_id' => (int) $threadId];
        }

        $thread = new BP_Messages_Thread((int) $threadId);
        $recipients = [];

        foreach ((array) $thread->recipients as $recipient) {
            if (!empty($recipient->user_id)) {
                $recipients[] = Utility::getUserInfo($recipient->user_id);
            }
        }

        return [
            'thread_id'         => (int) $threadId,
            'subject'           => $thread->last_message_subject,
            'last_message'      => $thread->last_message_content,
            'last_message_date' => $thread->last_message_date,
            'last_sender'       => Utility::getUserInfo($thread->last_sender_id),
            'total_messages'    => $thread->total_messages,
            'recipients'        => $recipients,
        ];
    }

    public static function getReactionData($reactionId)
    {
        $reactions = \function_exists('bb_active_reactions') ? bb_active_reactions() : [];

        return $reactions[$reactionId] ?? ['id' => (int) $reactionId];
    }

    public static function getModerationData($moderation)
    {
        $data = Utility::normalizeData($moderation);
        unset($data['errors'], $data['error_type']);

        $data['reporter'] = Utility::getUserInfo($moderation->user_id);

        if (!empty($moderation->category_id)) {
            $category = get_term((int) $moderation->category_id);
            $data['category'] = ($category && !is_wp_error($category)) ? $category->name : '';
        }

        if ($moderation->item_type === 'user') {
            $data['reported_user'] = Utility::getUserInfo($moderation->item_id);

            return $data;
        }

        if (\function_exists('bp_moderation_get_content_owner_id')) {
            $ownerIds = bp_moderation_get_content_owner_id($moderation->item_id, $moderation->item_type);
            $data['content_owner'] = \is_array($ownerIds) ? array_map([Utility::class, 'getUserInfo'], $ownerIds) : Utility::getUserInfo($ownerIds);
            $data['content_url'] = bp_moderation_get_permalink($moderation->item_id, $moderation->item_type);
        }

        return $data;
    }

    public static function getMemberInviteData($inviteId)
    {
        $invite = get_post((int) $inviteId);

        return [
            'invite_id'     => (int) $inviteId,
            'invitee_email' => get_post_meta($inviteId, '_bp_invitee_email', true),
            'invitee_name'  => get_post_meta($inviteId, '_bp_invitee_name', true),
            'inviter_name'  => get_post_meta($inviteId, '_bp_inviter_name', true),
            'member_type'   => get_post_meta($inviteId, '_bp_invitee_member_type', true),
            'message'       => $invite ? $invite->post_content : '',
            'date'          => $invite ? $invite->post_date : '',
        ];
    }

    public static function getSignupProfileFields($usermeta)
    {
        $fields = [];

        foreach ((array) $usermeta as $key => $value) {
            if (!preg_match('/^field_(\d+)$/', (string) $key, $matches)) {
                continue;
            }

            $field = \function_exists('xprofile_get_field') ? xprofile_get_field((int) $matches[1]) : null;
            $fields[$field->name ?? $key] = $value;
        }

        return $fields;
    }

    public static function getPollData($pollId)
    {
        if (!\function_exists('bb_load_polls')) {
            return ['id' => (int) $pollId];
        }

        $poll = bb_load_polls()->bb_get_poll((int) $pollId);

        if (empty($poll)) {
            return ['id' => (int) $pollId];
        }

        $data = Utility::normalizeData($poll);
        $data['options'] = Utility::normalizeData(bb_load_polls()->bb_get_poll_options(['poll_id' => $poll->id]));
        $data['user'] = Utility::getUserInfo($poll->user_id);

        return $data;
    }

    public static function getPollVoteData($voteId, $vote)
    {
        $poll = self::getPollData($vote['poll_id'] ?? 0);
        $optionId = (int) ($vote['option_id'] ?? 0);
        $votedOption = [];

        foreach ($poll['options'] ?? [] as $option) {
            if ((int) ($option['id'] ?? 0) === $optionId) {
                $votedOption = $option;

                break;
            }
        }

        return [
            'vote_id' => (int) $voteId,
            'option'  => $votedOption,
            'user'    => Utility::getUserInfo($vote['user_id'] ?? 0),
            'poll'    => $poll,
        ];
    }

    public static function getUserReactionData($userReactionId, $userReaction)
    {
        $itemType = $userReaction['item_type'] ?? '';
        $itemId = (int) ($userReaction['item_id'] ?? 0);

        return [
            'user_reaction_id' => (int) $userReactionId,
            'item_type'        => $itemType,
            'item_id'          => $itemId,
            'reaction'         => self::getReactionData($userReaction['reaction_id'] ?? 0),
            'user'             => Utility::getUserInfo($userReaction['user_id'] ?? 0),
            'activity'         => \in_array($itemType, ['activity', 'activity_comment'], true) ? self::getActivityData($itemId) : [],
        ];
    }

    public static function getGroupMemberData($groupId, $userId)
    {
        return [
            'user'  => Utility::getUserInfo($userId),
            'group' => self::getGroupData($groupId),
        ];
    }
}
