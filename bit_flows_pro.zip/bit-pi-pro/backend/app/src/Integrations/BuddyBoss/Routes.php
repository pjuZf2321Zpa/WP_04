<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\PiPro\src\Integrations\BuddyBoss\helper\BuddyBossHelper;

Route::group(
    function () {
        Route::post('buddyboss/get-group-types', [BuddyBossHelper::class, 'getGroupsTypes']);
        Route::post('buddyboss/get-all-groups', [BuddyBossHelper::class, 'getAllGroups']);
        Route::post('buddyboss/get-all-profile-types', [BuddyBossHelper::class, 'getAllProfileTypes']);
        Route::post('buddyboss/get-all-forums', [BuddyBossHelper::class, 'getAllForums']);
        Route::post('buddyboss/get-extended-profile-fields', [BuddyBossHelper::class, 'getExtendedProfileFields']);
        Route::post('buddyboss/get-all-users', [BuddyBossHelper::class, 'getAllUsers']);
        Route::post('buddyboss/get-all-activities', [BuddyBossHelper::class, 'getAllActivities']);
        Route::post('buddyboss/get-all-topics', [BuddyBossHelper::class, 'getAllTopics']);
        Route::post('buddyboss/get-all-reactions', [BuddyBossHelper::class, 'getAllReactions']);
    }
)->middleware('nonce', 'isAdmin');
