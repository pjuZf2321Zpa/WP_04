<?php

namespace BitApps\PiPro\src\Integrations\BuddyBoss;

use BB_Subscriptions;
use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\BuddyBoss\helper\BuddyBossHelper;
use BP_Activity_Activity;
use BP_Invitation;
use WP_Post;

if (!\defined('ABSPATH')) {
    exit;
}

final class BuddyBossTrigger
{
    private static $pendingDeletions = [];

    private static $handledReports = [];

    private static $newRecords = [];

    private static $newRecordIds = [];

    private static $pendingMemberChanges = [];

    private static $pendingSubscriptionDeletions = [];

    public static function userCreatesGroup($groupId)
    {
        if (!\function_exists('groups_get_group')) {
            return;
        }

        $group = groups_get_group($groupId);
        $data = (array) Utility::jsonEncodeDecode($group);

        if (\function_exists('bp_groups_get_group_type')) {
            $data['type'] = bp_groups_get_group_type($groupId, false);
        }

        if (\function_exists('bp_get_group_cover_url')) {
            $data['cover_url'] = bp_get_group_cover_url($group);
        }

        if (\function_exists('bp_get_group_avatar_url')) {
            $data['avatar_url'] = bp_get_group_avatar_url($group);
        }

        if (isset($group->creator_id)) {
            $data['creator_data'] = Utility::getUserInfo($group->creator_id);
        }

        return self::execute(__FUNCTION__, $data);
    }

    public static function userAcceptsFriendshipRequest($id, $initiatorUserId, $friendUserId, $friendship)
    {
        self::executeUserFriendshipTrigger(__FUNCTION__, $id, $initiatorUserId, $friendUserId, $friendship);
    }

    public static function userAccountActivated($userId)
    {
        $data = Utility::getUserInfo($userId);

        return self::execute(__FUNCTION__, $data);
    }

    public static function userGainsFollower($follow)
    {
        if (!\is_object($follow) || !property_exists($follow, 'follower_id') || !property_exists($follow, 'leader_id')) {
            return;
        }

        $data = (array) Utility::jsonEncodeDecode($follow);
        $data['follower'] = Utility::getUserInfo($follow->follower_id);
        $data['leader'] = Utility::getUserInfo($follow->leader_id);

        return self::execute(__FUNCTION__, $data);
    }

    public static function userJoinsPublicGroup($groupId, $userId)
    {
        self::executeUserGroupTrigger(__FUNCTION__, $groupId, $userId, 'public');
    }

    public static function userJoinsPrivateGroup($userId, $groupId)
    {
        self::executeUserGroupTrigger(__FUNCTION__, $groupId, $userId);
    }

    public static function userJoinsSpecificTypeGroup($groupId, $userId)
    {
        self::executeUserGroupTrigger(__FUNCTION__, $groupId, $userId, null);
    }

    public static function userLeavesGroup($groupId, $userId)
    {
        self::executeUserGroupTrigger(__FUNCTION__, $groupId, $userId, 'public');
    }

    public static function userLeavesPrivateGroup($groupId, $userId)
    {
        self::executeUserGroupTrigger(__FUNCTION__, $groupId, $userId, 'private');
    }

    public static function userProfileTypeSetToSpecificType($userId, $memberType, $append)
    {
        $data = Utility::getUserInfo($userId);
        $data['member_type'] = $memberType;
        $data['append'] = $append;

        return self::execute(__FUNCTION__, $data);
    }

    public static function userReceivesPrivateMessage($message)
    {
        if (
            !\is_object($message)
            || !property_exists($message, 'id')
            || !property_exists($message, 'sender_id')
            || !property_exists($message, 'recipients')
        ) {
            return;
        }

        $data = [
            'message' => (array) Utility::jsonEncodeDecode($message),
            'sender'  => Utility::getUserInfo($message->sender_id)
        ];

        if (!empty($message->recipients)) {
            foreach ($message->recipients as $recipient) {
                if (empty($recipient->user_id) || $recipient->user_id == $message->sender_id) {
                    continue;
                }

                $data['recipients'][] = Utility::getUserInfo($recipient->user_id);
            }
        }

        return self::execute(__FUNCTION__, $data);
    }

    public static function userRequestsAccessPrivateGroup($userId, $admins, $groupId)
    {
        self::executeUserGroupTrigger(__FUNCTION__, $groupId, $userId, null);
    }

    public static function userSendsFriendshipRequest($friendshipId, $initiatorUserId, $friendUserId)
    {
        self::executeUserFriendshipTrigger(__FUNCTION__, $friendshipId, $initiatorUserId, $friendUserId);
    }

    public static function userUpdatesProfile($userId, $postedFieldIds, $errors, $oldValues, $newValues)
    {
        $data = [
            'user'             => Utility::getUserInfo($userId),
            'posted_field_ids' => $postedFieldIds,
            'errors'           => $errors,
            'old_values'       => $oldValues,
            'new_values'       => $newValues
        ];

        if (\function_exists('xprofile_get_field')) {
            foreach ($postedFieldIds as $fieldId) {
                $field = xprofile_get_field($fieldId);

                if ($field && isset($field->data->value)) {
                    $data['posted_fields'][$field->name] = $field->data->value;
                }
            }
        }

        return self::execute(__FUNCTION__, $data);
    }

    public static function activityUpdatePosted(...$hookArgs)
    {
        $activityId = self::getPostedActivityId($hookArgs, 2, 'activity');

        if (!$activityId) {
            return;
        }

        return self::execute(__FUNCTION__, BuddyBossHelper::getActivityData($activityId));
    }

    public static function groupActivityPosted(...$hookArgs)
    {
        $activityId = self::getPostedActivityId($hookArgs, 3, 'groups');

        if (!$activityId) {
            return;
        }

        $data = [
            'activity' => BuddyBossHelper::getActivityData($activityId),
            'group'    => BuddyBossHelper::getGroupData((new BP_Activity_Activity($activityId))->item_id),
        ];

        return self::execute(__FUNCTION__, $data);
    }

    public static function activityCommentPosted($commentId)
    {
        if (empty($commentId) || !empty($GLOBALS['bb_activity_comment_edit'])) {
            return;
        }

        $comment = BuddyBossHelper::getActivityData($commentId);

        $data = [
            'comment'  => $comment,
            'activity' => BuddyBossHelper::getActivityData($comment['item_id'] ?? 0),
        ];

        return self::execute(__FUNCTION__, $data);
    }

    public static function activityDeleted($activities, $deleteArgs = [])
    {
        $deleteArgs = (array) $deleteArgs;

        if (($deleteArgs['type'] ?? '') === 'activity_comment' && !empty($deleteArgs['item_id']) && empty($deleteArgs['id'])) {
            return;
        }

        $activities = array_filter(
            (array) $activities,
            static function ($activity) {
                return !\in_array($activity->privacy ?? '', ['media', 'document', 'video'], true);
            }
        );

        self::executeForEachRecord(__FUNCTION__, $activities);
    }

    public static function reactionAdded($userReactionId, $userReaction)
    {
        return self::execute(__FUNCTION__, BuddyBossHelper::getUserReactionData($userReactionId, (array) $userReaction));
    }

    public static function reactionRemoved(...$hookArgs)
    {
        $hook = current_filter();

        if ($hook === 'bb_reaction_after_remove_user_item_reaction') {
            [$userReactionId, $deleted, $userReaction] = array_pad($hookArgs, 3, null);

            if (empty($deleted) || empty($userReaction)) {
                return;
            }

            return self::execute(__FUNCTION__, BuddyBossHelper::getUserReactionData($userReactionId, (array) $userReaction));
        }

        $removal = (array) ($hook === 'bb_reaction_before_remove_user_item_reactions' ? ($hookArgs[0] ?? []) : ($hookArgs[1] ?? []));

        if (empty($removal['user_id']) || empty($removal['item_id']) || !\is_scalar($removal['item_id'])) {
            return;
        }

        $pendingKey = 'reaction_' . ($removal['item_type'] ?? '') . '_' . $removal['item_id'] . '_' . $removal['user_id'];

        if ($hook === 'bb_reaction_before_remove_user_item_reactions') {
            self::$pendingDeletions[$pendingKey] = bb_load_reaction()->bb_user_reacted_reaction_id($removal);

            return;
        }

        $removal['reaction_id'] = self::$pendingDeletions[$pendingKey] ?? 0;
        unset(self::$pendingDeletions[$pendingKey]);

        if (empty($hookArgs[0])) {
            return;
        }

        return self::execute(__FUNCTION__, BuddyBossHelper::getUserReactionData(current((array) ($hookArgs[2] ?? [])), $removal));
    }

    public static function forumCreated($newStatus, $oldStatus, $post)
    {
        if (!self::isForumPost($post) || !self::isLiveForumStatus($newStatus) || !\in_array($oldStatus, ['new', 'auto-draft', 'draft', 'pending', 'future'], true)) {
            return;
        }

        return self::execute(__FUNCTION__, BuddyBossHelper::getForumPostData($post->ID));
    }

    public static function forumUpdated($forumId, $forumAfter, $forumBefore)
    {
        if (!self::isForumPost($forumAfter) || !self::isLiveForumStatus($forumAfter->post_status) || !self::isLiveForumStatus($forumBefore->post_status)) {
            return;
        }

        $changedFields = array_filter(
            ['post_title', 'post_content', 'post_status', 'post_parent'],
            static function ($field) use ($forumAfter, $forumBefore) {
                return $forumAfter->{$field} !== $forumBefore->{$field};
            }
        );

        if (empty($changedFields)) {
            return;
        }

        return self::execute(__FUNCTION__, BuddyBossHelper::getForumPostData($forumId));
    }

    public static function topicCreated($topicId)
    {
        if (\function_exists('bbp_is_topic_spam') && bbp_is_topic_spam($topicId)) {
            return;
        }

        return self::execute(__FUNCTION__, BuddyBossHelper::getTopicData($topicId));
    }

    public static function topicUpdated($topicId, $topicAfter, $topicBefore)
    {
        if (!\function_exists('bbp_get_topic_post_type') || !self::isContentEdit(bbp_get_topic_post_type(), $topicAfter, $topicBefore, ['post_content', 'post_title'])) {
            return;
        }

        return self::execute(__FUNCTION__, BuddyBossHelper::getTopicData($topicId));
    }

    public static function topicClosed($topicId)
    {
        return self::execute(__FUNCTION__, BuddyBossHelper::getTopicData($topicId));
    }

    public static function topicOpened($topicId)
    {
        return self::execute(__FUNCTION__, BuddyBossHelper::getTopicData($topicId));
    }

    public static function topicTrashed($topicId)
    {
        if (doing_action('bbp_trash_forum')) {
            return;
        }

        return self::execute(__FUNCTION__, BuddyBossHelper::getTopicData($topicId));
    }

    public static function topicSpammed($topicId)
    {
        return self::execute(__FUNCTION__, BuddyBossHelper::getTopicData($topicId));
    }

    public static function replyCreated($replyId, $topicId, $forumId, $anonymousData, $replyAuthor, $isEdit, $replyToId)
    {
        if (\function_exists('bbp_is_reply_spam') && bbp_is_reply_spam($replyId)) {
            return;
        }

        $data = BuddyBossHelper::getReplyData($replyId);
        $data['reply_to'] = BuddyBossHelper::getForumPostData($replyToId);

        return self::execute(__FUNCTION__, $data);
    }

    public static function replyUpdated($replyId, $replyAfter, $replyBefore)
    {
        if (!\function_exists('bbp_get_reply_post_type') || !self::isContentEdit(bbp_get_reply_post_type(), $replyAfter, $replyBefore, ['post_content'])) {
            return;
        }

        return self::execute(__FUNCTION__, BuddyBossHelper::getReplyData($replyId));
    }

    public static function replyTrashed($replyId)
    {
        if (doing_action('wp_trash_post')) {
            return;
        }

        return self::execute(__FUNCTION__, BuddyBossHelper::getReplyData($replyId));
    }

    public static function replySpammed($replyId)
    {
        return self::execute(__FUNCTION__, BuddyBossHelper::getReplyData($replyId));
    }

    public static function topicFavorited($userId, $topicId)
    {
        return self::execute(__FUNCTION__, array_merge(['user' => Utility::getUserInfo($userId)], BuddyBossHelper::getTopicData($topicId)));
    }

    public static function topicUnfavorited($userId, $topicId)
    {
        if (doing_action('bbp_trash_topic') || doing_action('bbp_delete_topic')) {
            return;
        }

        return self::execute(__FUNCTION__, array_merge(['user' => Utility::getUserInfo($userId)], BuddyBossHelper::getTopicData($topicId)));
    }

    public static function forumSubscribed($subscription, $subscriptionId)
    {
        if (!\is_int($subscriptionId) || ($subscription['type'] ?? '') !== 'forum') {
            return;
        }

        $data = [
            'user'  => Utility::getUserInfo($subscription['user_id']),
            'forum' => BuddyBossHelper::getForumPostData($subscription['item_id']),
        ];

        return self::execute(__FUNCTION__, $data);
    }

    public static function forumUnsubscribed($subscriptionId)
    {
        $subscription = self::getDeletedSubscription($subscriptionId, 'forum');

        if (!$subscription) {
            return;
        }

        $data = [
            'user'  => Utility::getUserInfo($subscription['user_id']),
            'forum' => BuddyBossHelper::getForumPostData($subscription['item_id']),
        ];

        return self::execute(__FUNCTION__, $data);
    }

    public static function topicSubscribed($subscription, $subscriptionId)
    {
        if (!\is_int($subscriptionId) || ($subscription['type'] ?? '') !== 'topic') {
            return;
        }

        return self::execute(__FUNCTION__, array_merge(['user' => Utility::getUserInfo($subscription['user_id'])], BuddyBossHelper::getTopicData($subscription['item_id'])));
    }

    public static function topicUnsubscribed($subscriptionId)
    {
        $subscription = self::getDeletedSubscription($subscriptionId, 'topic');

        if (!$subscription) {
            return;
        }

        return self::execute(__FUNCTION__, array_merge(['user' => Utility::getUserInfo($subscription['user_id'])], BuddyBossHelper::getTopicData($subscription['item_id'])));
    }

    public static function groupDetailsUpdated($groupId, $oldGroup, $notifyMembers)
    {
        $data = [
            'group'          => BuddyBossHelper::getGroupData($groupId),
            'old_group'      => Utility::normalizeData($oldGroup),
            'notify_members' => (bool) $notifyMembers,
        ];

        return self::execute(__FUNCTION__, $data);
    }

    public static function groupDeleted($groupId)
    {
        $pendingKey = 'group_' . $groupId;

        if (current_filter() === 'groups_before_delete_group') {
            self::$pendingDeletions[$pendingKey] = BuddyBossHelper::getGroupData($groupId);

            return;
        }

        $data = self::$pendingDeletions[$pendingKey] ?? ['id' => (int) $groupId];
        unset(self::$pendingDeletions[$pendingKey]);

        return self::execute(__FUNCTION__, $data);
    }

    public static function groupMemberPromoted(...$hookArgs)
    {
        return self::executeAfterMemberChange(
            __FUNCTION__,
            $hookArgs,
            static function ($member, $role) {
                return $role === 'admin' ? !empty($member->is_admin) : !empty($member->is_mod);
            }
        );
    }

    public static function groupMemberDemoted(...$hookArgs)
    {
        return self::executeAfterMemberChange(
            __FUNCTION__,
            $hookArgs,
            static function ($member) {
                return empty($member->is_admin) && empty($member->is_mod);
            }
        );
    }

    public static function groupMemberBanned(...$hookArgs)
    {
        return self::executeAfterMemberChange(
            __FUNCTION__,
            $hookArgs,
            static function ($member) {
                return !empty($member->is_banned);
            }
        );
    }

    public static function groupMemberUnbanned(...$hookArgs)
    {
        return self::executeAfterMemberChange(
            __FUNCTION__,
            $hookArgs,
            static function ($member) {
                return empty($member->is_banned);
            }
        );
    }

    public static function groupMemberRemoved(...$hookArgs)
    {
        return self::executeAfterMemberChange(__FUNCTION__, $hookArgs);
    }

    public static function groupInvitationSent($invitation, $invitationId)
    {
        if (empty($invitationId)) {
            return;
        }

        $data = BuddyBossHelper::getGroupMemberData($invitation['group_id'] ?? 0, $invitation['user_id'] ?? 0);
        $data['invitation_id'] = (int) $invitationId;
        $data['inviter'] = Utility::getUserInfo($invitation['inviter_id'] ?? 0);
        $data['message'] = $invitation['content'] ?? '';

        return self::execute(__FUNCTION__, $data);
    }

    public static function groupInvitationRejected(...$hookArgs)
    {
        if (current_filter() === 'bp_invitation_before_delete') {
            $invitation = (array) ($hookArgs[0] ?? []);

            if (($invitation['class'] ?? '') === 'BP_Groups_Invitation_Manager' && ($invitation['type'] ?? '') === 'invite' && !empty($invitation['user_id']) && !empty($invitation['item_id'])) {
                self::$pendingDeletions['invite_' . $invitation['user_id'] . '_' . $invitation['item_id']] = !empty(BP_Invitation::get(array_merge($invitation, ['fields' => 'ids'])));
            }

            return;
        }

        [$userId, $groupId, $inviterId] = array_pad($hookArgs, 3, 0);
        $pendingKey = 'invite_' . $userId . '_' . $groupId;
        $hadInvitation = self::$pendingDeletions[$pendingKey] ?? false;
        unset(self::$pendingDeletions[$pendingKey]);

        if (!$hadInvitation) {
            return;
        }

        $data = BuddyBossHelper::getGroupMemberData($groupId, $userId);
        $data['inviter'] = Utility::getUserInfo($inviterId);

        return self::execute(__FUNCTION__, $data);
    }

    public static function groupInvitationRevoked($groupId, $userId, $inviterId)
    {
        $data = BuddyBossHelper::getGroupMemberData($groupId, $userId);
        $data['inviter'] = Utility::getUserInfo($inviterId);

        return self::execute(__FUNCTION__, $data);
    }

    public static function groupMembershipRequestRejected($userId, $groupId)
    {
        return self::execute(__FUNCTION__, BuddyBossHelper::getGroupMemberData($groupId, $userId));
    }

    public static function groupTypeSet($groupId, $terms, $termTaxonomyIds, $taxonomy, $append, $oldTermTaxonomyIds)
    {
        if ($taxonomy !== 'bp_group_type') {
            return;
        }

        foreach (self::getTypeNames(array_diff((array) $termTaxonomyIds, (array) $oldTermTaxonomyIds), $taxonomy) as $groupType) {
            $data = [
                'group'      => BuddyBossHelper::getGroupData($groupId),
                'group_type' => $groupType,
                'append'     => (bool) $append,
            ];

            self::execute(__FUNCTION__, $data);
        }
    }

    public static function groupTypeRemoved($groupId, $termTaxonomyIds, $taxonomy)
    {
        if ($taxonomy !== 'bp_group_type' || self::isCascadeDeletion()) {
            return;
        }

        foreach (self::getTypeNames($termTaxonomyIds, $taxonomy) as $groupType) {
            $data = [
                'group'      => BuddyBossHelper::getGroupData($groupId),
                'group_type' => $groupType,
            ];

            self::execute(__FUNCTION__, $data);
        }
    }

    public static function memberRegistered($userId, $userLogin, $userPassword, $userEmail, $usermeta)
    {
        $data = [
            'user_id'        => $userId,
            'user_login'     => $userLogin,
            'user_email'     => $userEmail,
            'user'           => Utility::getUserInfo($userId),
            'profile_fields' => BuddyBossHelper::getSignupProfileFields($usermeta),
        ];

        return self::execute(__FUNCTION__, $data);
    }

    public static function profilePhotoUpdated($userId)
    {
        $data = Utility::getUserInfo($userId);
        $data['profile_photo_url'] = \function_exists('bp_core_fetch_avatar')
            ? bp_core_fetch_avatar(['item_id' => $userId, 'html' => false, 'type' => 'full'])
            : '';

        return self::execute(__FUNCTION__, $data);
    }

    public static function profileTypeRemoved($userId, $termTaxonomyIds, $taxonomy)
    {
        if (!\function_exists('bp_get_member_type_tax_name') || $taxonomy !== bp_get_member_type_tax_name() || self::isCascadeDeletion()) {
            return;
        }

        foreach (self::getTypeNames($termTaxonomyIds, $taxonomy) as $profileType) {
            $data = Utility::getUserInfo($userId);
            $data['profile_type'] = $profileType;

            self::execute(__FUNCTION__, $data);
        }
    }

    public static function memberSuspended($userId, $hideSitewide = 0, $args = [])
    {
        $action = $args['action'] ?? '';

        if ($action !== 'suspended' && !($action === '' && (int) $hideSitewide === 1)) {
            return;
        }

        return self::execute(__FUNCTION__, Utility::getUserInfo($userId));
    }

    public static function memberUnsuspended($userId, $hideSitewide = 0, $forceAll = false, $args = [])
    {
        if (($args['action'] ?? '') !== 'unsuspended') {
            return;
        }

        return self::execute(__FUNCTION__, Utility::getUserInfo($userId));
    }

    public static function memberMarkedAsSpammer($userId)
    {
        return self::execute(__FUNCTION__, Utility::getUserInfo($userId));
    }

    public static function memberUnmarkedAsSpammer($userId)
    {
        return self::execute(__FUNCTION__, Utility::getUserInfo($userId));
    }

    public static function accountDeleted($userId)
    {
        $pendingKey = 'user_' . $userId;

        if (current_filter() === 'bp_core_pre_delete_account') {
            self::$pendingDeletions[$pendingKey] = Utility::getUserInfo($userId);

            return;
        }

        $data = self::$pendingDeletions[$pendingKey] ?? ['user_id' => (int) $userId];
        unset(self::$pendingDeletions[$pendingKey]);

        return self::execute(__FUNCTION__, $data);
    }

    public static function userUnfollowed($follow)
    {
        if (!\is_object($follow) || !property_exists($follow, 'follower_id') || !property_exists($follow, 'leader_id')) {
            return;
        }

        $data = Utility::normalizeData($follow);
        $data['follower'] = Utility::getUserInfo($follow->follower_id);
        $data['leader'] = Utility::getUserInfo($follow->leader_id);

        return self::execute(__FUNCTION__, $data);
    }

    public static function emailInvitationSent($inviterId, $inviteId)
    {
        $data = BuddyBossHelper::getMemberInviteData($inviteId);
        $data['inviter'] = Utility::getUserInfo($inviterId);

        return self::execute(__FUNCTION__, $data);
    }

    public static function invitedMemberActivated($userId, $inviterId, $inviteId)
    {
        $data = [
            'user'    => Utility::getUserInfo($userId),
            'inviter' => Utility::getUserInfo($inviterId),
            'invite'  => BuddyBossHelper::getMemberInviteData($inviteId),
        ];

        return self::execute(__FUNCTION__, $data);
    }

    public static function connectionRequestRejected($friendshipId, $friendship)
    {
        if (!\is_object($friendship)) {
            return;
        }

        return self::executeUserFriendshipTrigger(__FUNCTION__, $friendshipId, $friendship->initiator_user_id, $friendship->friend_user_id, $friendship);
    }

    public static function connectionRequestWithdrawn($friendshipId, $friendship)
    {
        if (!\is_object($friendship)) {
            return;
        }

        return self::executeUserFriendshipTrigger(__FUNCTION__, $friendshipId, $friendship->initiator_user_id, $friendship->friend_user_id, $friendship);
    }

    public static function connectionRemoved($friendshipId, $initiatorUserId, $friendUserId)
    {
        return self::executeUserFriendshipTrigger(__FUNCTION__, $friendshipId, $initiatorUserId, $friendUserId);
    }

    public static function siteNoticeSent($subject, $message)
    {
        $data = [
            'subject' => $subject,
            'message' => $message,
            'sent_by' => Utility::getUserInfo(get_current_user_id()),
        ];

        return self::execute(__FUNCTION__, $data);
    }

    public static function photoUploaded($media)
    {
        return self::executeForNewRecord(__FUNCTION__, $media);
    }

    public static function photoDeleted($medias)
    {
        $photos = array_filter((array) $medias, fn ($media) => \is_object($media) && ($media->type ?? 'photo') === 'photo');

        self::executeForEachRecord(__FUNCTION__, $photos);
    }

    public static function documentUploaded($document)
    {
        return self::executeForNewRecord(__FUNCTION__, $document);
    }

    public static function documentDeleted($documents)
    {
        self::executeForEachRecord(__FUNCTION__, $documents);
    }

    public static function videoUploaded($video)
    {
        return self::executeForNewRecord(__FUNCTION__, $video);
    }

    public static function videoDeleted($videos)
    {
        self::executeForEachRecord(__FUNCTION__, $videos);
    }

    public static function memberBlocked($moderation)
    {
        if (!\is_object($moderation) || $moderation->item_type !== 'user' || !empty($moderation->user_report)) {
            return;
        }

        return self::executeModerationTrigger(__FUNCTION__, $moderation);
    }

    public static function memberReported($moderation)
    {
        if (!\is_object($moderation) || $moderation->item_type !== 'user' || empty($moderation->user_report)) {
            return;
        }

        return self::executeModerationTrigger(__FUNCTION__, $moderation);
    }

    public static function contentReported($moderation)
    {
        if (!\is_object($moderation) || $moderation->item_type === 'user') {
            return;
        }

        return self::executeModerationTrigger(__FUNCTION__, $moderation);
    }

    public static function pollCreated($pollId, $poll)
    {
        if (empty($poll['item_id']) || ($poll['item_type'] ?? '') !== 'activity' || !empty($GLOBALS['bp_activity_edit'])) {
            return;
        }

        if (\function_exists('bp_activity_get_meta') && bp_activity_get_meta($poll['item_id'], 'bb_poll_id', true)) {
            return;
        }

        $data = BuddyBossHelper::getPollData($pollId);
        $data['activity'] = BuddyBossHelper::getActivityData($poll['item_id']);

        return self::execute(__FUNCTION__, $data);
    }

    public static function pollVoted($voteId, $vote)
    {
        $pollVotes = bb_load_polls()->bb_get_poll_votes(
            [
                'id'        => (int) $voteId,
                'poll_id'   => (int) ($vote['poll_id'] ?? 0),
                'option_id' => (int) ($vote['option_id'] ?? 0),
            ]
        );

        if (empty($pollVotes['poll_votes'])) {
            return;
        }

        return self::execute(__FUNCTION__, BuddyBossHelper::getPollVoteData($voteId, (array) $vote));
    }

    public static function pollVoteRemoved($deleted, $vote, $removedVotes)
    {
        if (empty($deleted) || empty($vote['user_id'])) {
            return;
        }

        $data = [
            'user'          => Utility::getUserInfo($vote['user_id'] ?? 0),
            'poll'          => BuddyBossHelper::getPollData($vote['poll_id'] ?? 0),
            'removed_votes' => Utility::normalizeData($removedVotes),
        ];

        return self::execute(__FUNCTION__, $data);
    }

    private static function executeUserFriendshipTrigger($machineSlug, $friendshipId, $initiatorUserId, $friendUserId, $friendship = null)
    {
        $data = [
            'friendship_id' => $friendshipId,
            'initiator'     => Utility::getUserInfo($initiatorUserId),
            'friend'        => Utility::getUserInfo($friendUserId)
        ];

        if ($friendship !== null) {
            $data['friendship'] = Utility::jsonEncodeDecode($friendship);
        }

        return self::execute($machineSlug, $data);
    }

    private static function executeUserGroupTrigger($machineSlug, $groupId, $userId, $expectedStatus = null)
    {
        if (!\function_exists('groups_get_group')) {
            return;
        }

        $group = groups_get_group($groupId);
        if ($expectedStatus && (empty($group->status) || $group->status !== $expectedStatus)) {
            return;
        }

        $data = [
            'user'  => Utility::getUserInfo($userId),
            'group' => (array) Utility::jsonEncodeDecode($group)
        ];

        if (empty($data['group']['type']) && \function_exists('bp_groups_get_group_type')) {
            $data['group']['type'] = bp_groups_get_group_type($groupId, false);
        }

        return self::execute($machineSlug, $data);
    }

    private static function executeForEachRecord($machineSlug, $records)
    {
        if (self::isCascadeDeletion()) {
            return;
        }

        foreach ((array) $records as $record) {
            self::execute($machineSlug, BuddyBossHelper::getRecordData($record));
        }
    }

    private static function executeForNewRecord($machineSlug, $record)
    {
        if (!\is_object($record)) {
            return;
        }

        $recordKey = spl_object_id($record);

        if (str_ends_with(current_filter(), '_before_save')) {
            if (empty($record->id)) {
                self::$newRecords[$recordKey] = true;
            } else {
                unset(self::$newRecords[$recordKey]);
            }

            return;
        }

        if (str_ends_with(current_filter(), '_after_save')) {
            if (isset(self::$newRecords[$recordKey])) {
                unset(self::$newRecords[$recordKey]);
                self::$newRecordIds[$machineSlug . '_' . $record->id] = true;
            }

            return;
        }

        $recordIdKey = $machineSlug . '_' . ($record->id ?? 0);

        if (!isset(self::$newRecordIds[$recordIdKey])) {
            return;
        }

        unset(self::$newRecordIds[$recordIdKey]);

        return self::execute($machineSlug, BuddyBossHelper::getRecordData($record));
    }

    private static function executeAfterMemberChange($machineSlug, $hookArgs, $isChangeApplied = null)
    {
        $member = $hookArgs[0] ?? null;

        if (!\is_object($member)) {
            [$groupId, $userId, $role] = array_pad($hookArgs, 3, '');
            self::$pendingMemberChanges[$machineSlug][$groupId . '_' . $userId] = (string) $role;

            return;
        }

        $memberKey = $member->group_id . '_' . $member->user_id;

        if (!isset(self::$pendingMemberChanges[$machineSlug][$memberKey])) {
            return;
        }

        $role = self::$pendingMemberChanges[$machineSlug][$memberKey];
        unset(self::$pendingMemberChanges[$machineSlug][$memberKey]);

        if ($isChangeApplied && !$isChangeApplied($member, $role)) {
            return;
        }

        $data = BuddyBossHelper::getGroupMemberData($member->group_id, $member->user_id);

        if ($role !== '') {
            $data['role'] = $role;
        }

        return self::execute($machineSlug, $data);
    }

    private static function getPostedActivityId($hookArgs, $activityIdIndex, $component)
    {
        if (current_filter() === 'bp_activity_after_save') {
            $activity = $hookArgs[0] ?? null;

            if (!\is_object($activity) || !doing_action('bb_activity_publish') || $activity->component !== $component) {
                return 0;
            }

            return self::isPublishedPost($activity) ? (int) $activity->id : 0;
        }

        $activityId = (int) ($hookArgs[$activityIdIndex] ?? 0);

        if (!$activityId || !empty($GLOBALS['bp_activity_edit']) || !class_exists('BP_Activity_Activity')) {
            return 0;
        }

        if ($component === 'groups' && bp_activity_get_meta($activityId, '_is_edited', true)) {
            return 0;
        }

        return self::isPublishedPost(new BP_Activity_Activity($activityId)) ? $activityId : 0;
    }

    private static function isPublishedPost($activity)
    {
        if (\in_array($activity->privacy ?? '', ['media', 'document', 'video'], true)) {
            return false;
        }

        return !\function_exists('bb_get_activity_scheduled_status') || ($activity->status ?? '') !== bb_get_activity_scheduled_status();
    }

    private static function getDeletedSubscription($subscriptionId, $type)
    {
        if (current_filter() === 'bb_subscriptions_before_delete_subscription') {
            $subscription = class_exists('BB_Subscriptions') ? new BB_Subscriptions($subscriptionId) : null;

            if ($subscription && $subscription->type === $type && !doing_action('bbp_delete_topic') && !doing_action('bbp_delete_forum')) {
                self::$pendingSubscriptionDeletions[$type . '_' . $subscriptionId] = ['user_id' => (int) $subscription->user_id, 'item_id' => (int) $subscription->item_id];
            }

            return;
        }

        $pendingKey = $type . '_' . $subscriptionId;
        $subscription = self::$pendingSubscriptionDeletions[$pendingKey] ?? null;
        unset(self::$pendingSubscriptionDeletions[$pendingKey]);

        return $subscription;
    }

    private static function getTypeNames($termTaxonomyIds, $taxonomy)
    {
        $names = [];

        foreach ((array) $termTaxonomyIds as $termTaxonomyId) {
            $term = get_term_by('term_taxonomy_id', (int) $termTaxonomyId, $taxonomy);

            if ($term && !is_wp_error($term)) {
                $names[] = $term->name;
            }
        }

        return $names;
    }

    private static function isCascadeDeletion()
    {
        foreach (['delete_user', 'wpmu_delete_user', 'bp_make_spam_user', 'groups_delete_group'] as $hook) {
            if (doing_action($hook)) {
                return true;
            }
        }

        return false;
    }

    private static function isForumPost($post)
    {
        return $post instanceof WP_Post && \function_exists('bbp_get_forum_post_type') && $post->post_type === bbp_get_forum_post_type();
    }

    private static function isLiveForumStatus($status)
    {
        return \in_array($status, ['publish', 'private', 'hidden'], true);
    }

    private static function isContentEdit($postType, $postAfter, $postBefore, $editableFields)
    {
        if (!$postAfter instanceof WP_Post || !$postBefore instanceof WP_Post) {
            return false;
        }

        if ($postAfter->post_type !== $postType || $postBefore->post_type !== $postType) {
            return false;
        }

        if ($postAfter->post_status !== $postBefore->post_status || !\in_array($postAfter->post_status, ['publish', 'closed', 'private', 'hidden'], true)) {
            return false;
        }

        foreach ($editableFields as $field) {
            if ($postAfter->{$field} !== $postBefore->{$field}) {
                return true;
            }
        }

        return false;
    }

    private static function executeModerationTrigger($machineSlug, $moderation)
    {
        $reportKey = $machineSlug . '_' . $moderation->id . '_' . $moderation->user_id;

        if (isset(self::$handledReports[$reportKey])) {
            return;
        }

        self::$handledReports[$reportKey] = true;

        return self::execute($machineSlug, BuddyBossHelper::getModerationData($moderation));
    }

    private static function execute($machineSlug, $data)
    {
        $flows = FlowService::exists('buddyBoss', $machineSlug);

        if (!$flows) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $data);
    }
}
