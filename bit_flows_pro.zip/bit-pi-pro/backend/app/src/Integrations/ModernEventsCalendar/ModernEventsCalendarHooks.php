<?php

namespace BitApps\PiPro\src\Integrations\ModernEventsCalendar;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!\defined('ABSPATH')) {
    exit;
}

class ModernEventsCalendarHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'bookingCompleted' => [
                'hook'     => 'mec_booking_completed',
                'callback' => [ModernEventsCalendarTrigger::class, 'bookingCompleted'],
            ],
            'bookingConfirmed' => [
                'hook'     => 'mec_booking_confirmed',
                'callback' => [ModernEventsCalendarTrigger::class, 'bookingConfirmed'],
            ],
            'bookingPending' => [
                'hook'     => 'mec_booking_pended',
                'callback' => [ModernEventsCalendarTrigger::class, 'bookingPending'],
            ],
            'bookingCancelled' => [
                'hook'     => 'mec_booking_canceled',
                'callback' => [ModernEventsCalendarTrigger::class, 'bookingCancelled'],
            ],
            'eventCreated' => [
                'hook'          => 'mec_save_event_data',
                'callback'      => [ModernEventsCalendarTrigger::class, 'eventCreated'],
                'accepted_args' => 2,
            ],
        ];
    }
}
