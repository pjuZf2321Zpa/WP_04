<?php

namespace BitApps\PiPro\src\Integrations\ModernEventsCalendar;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;
use BitApps\PiPro\src\Integrations\ModernEventsCalendar\helper\ModernEventsCalendarHelper;

if (!\defined('ABSPATH')) {
    exit;
}

class ModernEventsCalendarAction implements ActionInterface
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeModernEventsCalendarAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'] ?? 200,
            $executedNodeAction['payload'] ?? [],
            $executedNodeAction['response'] ?? []
        );
    }

    private function executeModernEventsCalendarAction()
    {
        if (!ModernEventsCalendarHelper::isPluginInstalled()) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('Modern Events Calendar plugin is not active.', 'bit-pi'),
            ];
        }

        $modernEventsCalendarService = new ModernEventsCalendarService($this->nodeInfoProvider);

        $machineSlug = $this->nodeInfoProvider->getMachineSlug();

        if (!method_exists($modernEventsCalendarService, $machineSlug)) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('Modern Events Calendar action not found.', 'bit-pi'),
            ];
        }

        return $modernEventsCalendarService->{$machineSlug}();
    }
}
