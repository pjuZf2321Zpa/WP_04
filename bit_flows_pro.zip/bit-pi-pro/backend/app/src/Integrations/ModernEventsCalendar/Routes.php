<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\PiPro\src\Integrations\ModernEventsCalendar\helper\ModernEventsCalendarHelper;

Route::group(
    function () {
        Route::get('modern-events-calendar/get/events', [ModernEventsCalendarHelper::class, 'getAllEvents']);
        Route::get('modern-events-calendar/get/tickets', [ModernEventsCalendarHelper::class, 'getEventTickets']);
    }
)->middleware('nonce:admin');
