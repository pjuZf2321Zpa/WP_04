<?php

namespace BitApps\PiPro\src\Integrations\ModernEventsCalendar;

use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\PiPro\src\Integrations\ModernEventsCalendar\helper\ModernEventsCalendarHelper;
use Exception;
use MEC_feature_books;
use MEC_gateway_pay_locally;
use WP_Post;
use WP_User;

if (!defined('ABSPATH')) {
    exit;
}

final class ModernEventsCalendarService
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function getAllEvents()
    {
        $bookingManager = $this->getBookingManager();
        if ($bookingManager === null) {
            return [
                'response'    => __('MEC_feature_books class not found.', 'bit-pi'),
                'payload'     => [],
                'status_code' => 400,
            ];
        }

        $eventIds = $bookingManager->main->get_all_event_ids();

        return [
            'response'    => array_map([self::class, 'compileEventData'], $eventIds),
            'payload'     => [],
            'status_code' => 200,
        ];
    }

    public function getNextUpcomingEvent()
    {
        $bookingManager = $this->getBookingManager();
        if ($bookingManager === null) {
            return [
                'response'    => __('MEC_feature_books class not found.', 'bit-pi'),
                'payload'     => [],
                'status_code' => 400,
            ];
        }

        return [
            'response'    => $bookingManager->main->get_next_upcoming_event(),
            'payload'     => [],
            'status_code' => 200,
        ];
    }

    public function getUpcomingEvents()
    {
        $bookingManager = $this->getBookingManager();
        if ($bookingManager === null) {
            return [
                'response'    => __('MEC_feature_books class not found.', 'bit-pi'),
                'payload'     => [],
                'status_code' => 400,
            ];
        }

        $eventIds = $bookingManager->main->get_upcoming_event_ids();

        return [
            'response'    => array_map([self::class, 'compileEventData'], $eventIds),
            'payload'     => [],
            'status_code' => 200,
        ];
    }

    public function getExpiredEvents()
    {
        $bookingManager = $this->getBookingManager();
        if ($bookingManager === null) {
            return [
                'response'    => __('MEC_feature_books class not found.', 'bit-pi'),
                'payload'     => [],
                'status_code' => 400,
            ];
        }

        $eventIds = $bookingManager->main->get_expired_event_ids();

        return [
            'response'    => array_map([self::class, 'compileEventData'], $eventIds),
            'payload'     => [],
            'status_code' => 200,
        ];
    }

    public function getEventTickets()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationError = $this->validateEventId($fieldMappings);
        if (!empty($validationError)) {
            return $validationError;
        }

        $bookingManager = $this->getBookingManager();
        if ($bookingManager === null) {
            return [
                'response'    => __('MEC_feature_books class not found.', 'bit-pi'),
                'payload'     => [],
                'status_code' => 400,
            ];
        }

        $tickets = $bookingManager->main->get_full_tickets(absint($fieldMappings['event_id']));

        return [
            'response'    => self::compileTicketData($tickets),
            'payload'     => [],
            'status_code' => 200,
        ];
    }

    /**
     * Register user for an event.
     *
     * @return array
     */
    public function registerUserForEvent()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $validationError = $this->validateRegistrationFields($fieldMappings);
        if (!empty($validationError)) {
            return $validationError;
        }

        $classCheckError = $this->checkRequiredClasses($fieldMappings);
        if ($classCheckError !== null) {
            return $classCheckError;
        }

        $sanitizedData = $this->sanitizeRegistrationData($fieldMappings);

        $userValidation = $this->validateUserAndEvent($sanitizedData, $fieldMappings);
        if ($userValidation['error']) {
            return $userValidation['response'];
        }

        try {
            $reservationId = $this->processEventRegistration($userValidation['wpUser'], $sanitizedData);

            return [
                'response'    => ModernEventsCalendarHelper::buildBookingData($reservationId),
                'payload'     => $fieldMappings,
                'status_code' => 200,
            ];
        } catch (Exception $exception) {
            return [
                'response'    => __('Error: ', 'bit-pi') . $exception->getMessage(),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }
    }

    private static function compileEventData($eventId)
    {
        $eventPost = get_post($eventId);
        $hasValidEventPost = $eventPost instanceof WP_Post;

        return [
            'event_id'        => $eventId,
            'title'           => get_the_title($eventId),
            'content'         => $hasValidEventPost ? $eventPost->post_content : '',
            'event_meta'      => $hasValidEventPost ? get_post_meta($eventId) : [],
            'event_post_data' => $hasValidEventPost ? $eventPost : null
        ];
    }

    private static function compileTicketData($tickets)
    {
        $ticketLists = [];

        foreach ($tickets as $ticketId => $ticket) {
            $ticket['id'] = $ticketId;
            $ticketLists[] = $ticket;
        }

        return $ticketLists;
    }

    /**
     * Get booking manager instance.
     *
     * @return null|MEC_feature_books
     */
    private function getBookingManager()
    {
        if (!class_exists('\MEC_feature_books')) {
            return;
        }

        return new MEC_feature_books();
    }

    /**
     * Validate event ID field.
     *
     * @param array $fieldMappings
     *
     * @return array
     */
    private function validateEventId($fieldMappings)
    {
        $rules = [
            'event_id' => ['required', 'integer'],
        ];

        return ModernEventsCalendarHelper::validateFieldMap($fieldMappings, $rules);
    }

    /**
     * Validate registration fields.
     *
     * @param array $fieldMappings
     *
     * @return array
     */
    private function validateRegistrationFields($fieldMappings)
    {
        $rules = [
            'event_id'   => ['required', 'integer'],
            'ticket_id'  => ['required', 'integer'],
            'user_email' => ['required', 'email']
        ];

        return ModernEventsCalendarHelper::validateFieldMap($fieldMappings, $rules);
    }

    /**
     * Check required MEC classes exist.
     *
     * @param array $fieldMappings
     *
     * @return null|array
     */
    private function checkRequiredClasses($fieldMappings)
    {
        $requiredClasses = [
            '\MEC_gateway_pay_locally' => __('MEC_gateway_pay_locally class not found.', 'bit-pi'),
            '\MEC_feature_books'       => __('MEC_feature_books class not found.', 'bit-pi'),
        ];

        foreach ($requiredClasses as $class => $message) {
            if (!class_exists($class)) {
                return [
                    'status_code' => 400,
                    'payload'     => $fieldMappings,
                    'response'    => $message,
                ];
            }
        }
    }

    /**
     * Sanitize registration data.
     *
     * @param array $fieldMappings
     *
     * @return array
     */
    private function sanitizeRegistrationData($fieldMappings)
    {
        return [
            'event_id'   => absint($fieldMappings['event_id']),
            'ticket_id'  => absint($fieldMappings['ticket_id']),
            'user_email' => sanitize_email($fieldMappings['user_email'])
        ];
    }

    /**
     * Validate user and event existence.
     *
     * @param array $sanitizedData
     * @param array $fieldMappings
     *
     * @return array
     */
    private function validateUserAndEvent($sanitizedData, $fieldMappings)
    {
        $wpUser = get_user_by('email', $sanitizedData['user_email']);

        if (!$wpUser) {
            return [
                'error'    => true,
                'response' => [
                    'status_code' => 400,
                    'payload'     => $fieldMappings,
                    'response'    => __('User with email not found.', 'bit-pi')
                ]
            ];
        }

        $eventPost = get_post($sanitizedData['event_id']);
        if (!$eventPost || $eventPost->post_type !== 'mec-events') {
            return [
                'error'    => true,
                'response' => [
                    'status_code' => 400,
                    'payload'     => $fieldMappings,
                    'response'    => __('Event with ID not found.', 'bit-pi')
                ]
            ];
        }

        return [
            'error'  => false,
            'wpUser' => $wpUser
        ];
    }

    /**
     * Process event registration.
     *
     * @param WP_User $wpUser
     * @param array    $sanitizedData
     *
     * @return int Reservation ID
     */
    private function processEventRegistration($wpUser, $sanitizedData)
    {
        $paymentGateway = new MEC_gateway_pay_locally();
        $bookingManager = new MEC_feature_books();

        $participantInfo = $this->buildParticipantInfo($wpUser);
        $registeredUserId = $paymentGateway->register_user($participantInfo);

        $eventTimestamp = $this->getEventTimestamp($sanitizedData['event_id']);
        $bookingService = $bookingManager->getBook();

        $ticketsCollection = $this->buildTicketsCollection($participantInfo, $sanitizedData['ticket_id']);
        $calculatedPricing = $this->calculatePricing($bookingService, $sanitizedData);

        $transactionData = $this->buildTransactionData(
            $ticketsCollection,
            $eventTimestamp,
            $sanitizedData['event_id'],
            $calculatedPricing
        );

        $temporaryTransactionId = $bookingService->temporary($transactionData);

        $reservationArgs = $this->buildReservationArgs($wpUser, $registeredUserId);
        $reservationId = $bookingService->add($reservationArgs, $temporaryTransactionId, ',' . $sanitizedData['ticket_id'] . ',');

        $this->updateReservationMeta($reservationId, $ticketsCollection, $participantInfo, $paymentGateway);
        $this->triggerBookingActions($reservationId);

        return $reservationId;
    }

    /**
     * Build participant information array.
     *
     * @param WP_User $wpUser
     *
     * @return array
     */
    private function buildParticipantInfo($wpUser)
    {
        return [
            'email' => $wpUser->user_email,
            'name'  => $wpUser->display_name,
            'reg'   => []
        ];
    }

    /**
     * Get event timestamp.
     *
     * @param int   $eventId
     *
     * @return string
     */
    private function getEventTimestamp($eventId)
    {
        $eventScheduleMeta = get_post_meta($eventId, 'mec_date', true);

        if (!\is_array($eventScheduleMeta) || !isset($eventScheduleMeta['start']) || !isset($eventScheduleMeta['end'])) {
            throw new Exception(__('Event start date and end date are missing.', 'bit-pi'));
        }

        $bookingManager = new MEC_feature_books();
        $bookingService = $bookingManager->getBook();

        return $bookingService->timestamp($eventScheduleMeta['start'], $eventScheduleMeta['end']);
    }

    /**
     * Build tickets collection array.
     *
     * @param array $participantInfo
     * @param int   $ticketId
     *
     * @return array
     */
    private function buildTicketsCollection($participantInfo, $ticketId)
    {
        return [
            array_merge(
                $participantInfo,
                [
                    'id'         => $ticketId,
                    'count'      => 1,
                    'variations' => [],
                    'reg'        => $participantInfo['reg']
                ]
            )
        ];
    }

    /**
     * Calculate pricing details.
     *
     * @param object $bookingService
     * @param array  $sanitizedData
     *
     * @return array
     */
    private function calculatePricing($bookingService, $sanitizedData)
    {
        $ticketsRawData = [$sanitizedData['ticket_id'] => 1];
        $availableTickets = get_post_meta($sanitizedData['event_id'], 'mec_tickets', true);

        return $bookingService->get_price_details($ticketsRawData, $sanitizedData['event_id'], $availableTickets, []);
    }

    /**
     * Build transaction data array.
     *
     * @param array  $ticketsCollection
     * @param string $eventTimestamp
     * @param int    $eventId
     * @param array  $calculatedPricing
     *
     * @return array
     */
    private function buildTransactionData($ticketsCollection, $eventTimestamp, $eventId, $calculatedPricing)
    {
        return [
            'tickets'       => $ticketsCollection,
            'date'          => $eventTimestamp,
            'event_id'      => $eventId,
            'price_details' => $calculatedPricing,
            'total'         => $calculatedPricing['total'],
            'discount'      => 0,
            'price'         => $calculatedPricing['total'],
            'coupon'        => null,
            'fields'        => []
        ];
    }

    /**
     * Build reservation arguments.
     *
     * @param WP_User $wpUser
     * @param int      $registeredUserId
     *
     * @return array
     */
    private function buildReservationArgs($wpUser, $registeredUserId)
    {
        return [
            'post_author' => $registeredUserId,
            'post_type'   => 'mec-books',
            'post_title'  => \sprintf('%s - %s', $wpUser->display_name, $wpUser->user_email)
        ];
    }

    /**
     * Update reservation post meta.
     *
     * @param int                      $reservationId
     * @param array                    $ticketsCollection
     * @param array                    $participantInfo
     * @param MEC_gateway_pay_locally $paymentGateway
     */
    private function updateReservationMeta($reservationId, $ticketsCollection, $participantInfo, $paymentGateway)
    {
        update_post_meta($reservationId, 'mec_attendees', $ticketsCollection);
        update_post_meta($reservationId, 'mec_reg', $participantInfo['reg']);
        update_post_meta($reservationId, 'mec_gateway', 'MEC_gateway_pay_locally');
        update_post_meta($reservationId, 'mec_gateway_label', $paymentGateway->title());
        update_post_meta($reservationId, 'mec_book_date_submit', wp_date('Y-m-d H:i:s'));
    }

    /**
     * Trigger booking action hooks.
     *
     * @param int $reservationId
     */
    private function triggerBookingActions($reservationId)
    {
        do_action('mec_booking_pended', $reservationId);
        do_action('mec_booking_completed', $reservationId);
    }
}
