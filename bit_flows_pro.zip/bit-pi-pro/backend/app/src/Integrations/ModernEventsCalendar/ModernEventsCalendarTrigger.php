<?php

namespace BitApps\PiPro\src\Integrations\ModernEventsCalendar;

use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\ModernEventsCalendar\helper\ModernEventsCalendarHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class ModernEventsCalendarTrigger
{
    public static function bookingCompleted($reservationId)
    {
        self::handleBookingEvent(__FUNCTION__, $reservationId);
    }

    public static function bookingConfirmed($reservationId)
    {
        self::handleBookingEvent(__FUNCTION__, $reservationId);
    }

    public static function bookingPending($reservationId)
    {
        self::handleBookingEvent(__FUNCTION__, $reservationId);
    }

    public static function bookingCancelled($reservationId)
    {
        self::handleBookingEvent(__FUNCTION__, $reservationId);
    }

    public static function eventCreated($eventPostId, $eventData)
    {
        if (empty($eventPostId) || empty($eventData)) {
            return;
        }

        $eventPost = get_post($eventPostId);

        if (empty($eventPost)) {
            return;
        }

        $data = [
            'event_data' => $eventData,
            'post_id'    => $eventPostId,
            'title'      => get_the_title($eventPostId),
            'content'    => $eventPost->post_content ?? '',
            'post_meta'  => get_post_meta($eventPostId),
            'post'       => $eventPost
        ];

        self::execute(__FUNCTION__, $data);
    }

    private static function handleBookingEvent($machineSlug, $reservationId)
    {
        if (empty($reservationId)) {
            return;
        }

        $bookingData = ModernEventsCalendarHelper::buildBookingData($reservationId);

        if (empty($bookingData)) {
            return;
        }

        self::execute($machineSlug, $bookingData);
    }

    private static function execute($machineSlug, $data)
    {
        $flows = FlowService::exists('modernEventsCalendar', $machineSlug);

        if (!$flows) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $data);
    }
}
