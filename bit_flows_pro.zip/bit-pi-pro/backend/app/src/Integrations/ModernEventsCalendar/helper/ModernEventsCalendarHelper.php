<?php

namespace BitApps\PiPro\src\Integrations\ModernEventsCalendar\helper;

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Request\Request;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\PiPro\Deps\BitApps\WPValidator\Validator;
use MEC_feature_books;

if (!defined('ABSPATH')) {
    exit;
}

final class ModernEventsCalendarHelper
{
    /**
     * Check if Modern Events Calendar plugin is installed.
     *
     * @return bool
     */
    public static function isPluginInstalled()
    {
        return defined('MEC_ABSPATH');
    }

    /**
     * Validate field map.
     *
     * @param array      $fieldMappings
     * @param array      $validationRules
     * @param null|array $payload
     *
     * @return null|array
     */
    public static function validateFieldMap($fieldMappings, $validationRules, $payload = null)
    {
        $validator = new Validator();
        $validation = $validator->make($fieldMappings, $validationRules);

        if ($validation->fails()) {
            return [
                'response'    => $validation->errors(),
                'payload'     => $payload ?? $fieldMappings,
                'status_code' => 400
            ];
        }
    }

    /**
     * Get all Modern Events Calendar events as select options.
     *
     * @return array
     */
    public static function getAllEvents()
    {
        if (!self::isPluginInstalled() || !class_exists('\MEC_feature_books')) {
            return Response::error(__('Modern Events Calendar plugin is not active.', 'bit-pi'), 400);
        }

        $bookingManager = new MEC_feature_books();
        $eventIds = $bookingManager->main->get_all_event_ids();
        $eventOptions = [];

        foreach ($eventIds as $eventId) {
            $eventOptions[] = [
                'value' => (string) $eventId,
                'label' => get_the_title($eventId),
            ];
        }

        return Response::success($eventOptions);
    }

    /**
     * Get ticket options by event ID.
     *
     * @return array
     */
    public static function getEventTickets(Request $request)
    {
        if (!self::isPluginInstalled() || !class_exists('\MEC_feature_books')) {
            return Response::error(__('Modern Events Calendar plugin is not active.', 'bit-pi'), 400);
        }

        $validatedData = $request->validate(
            [
                'eventId' => ['required', 'integer'],
            ]
        );

        $bookingManager = new MEC_feature_books();
        $tickets = $bookingManager->main->get_full_tickets(absint($validatedData['eventId']));
        $ticketOptions = [];

        foreach ($tickets as $ticketId => $ticket) {
            $ticketOptions[] = [
                'value' => (string) $ticketId,
                'label' => $ticket['name'] ?? (string) $ticketId,
            ];
        }

        return Response::success($ticketOptions);
    }

    /**
     * Build comprehensive booking data with associated event details.
     *
     * @param int $reservationId Booking/Reservation ID
     *
     * @return array Compiled booking information
     */
    public static function buildBookingData($reservationId)
    {
        $mecEventId = get_post_meta($reservationId, 'mec_event_id', true);
        $mecEventId = is_numeric($mecEventId) ? (int) $mecEventId : 0;

        if (!$mecEventId) {
            return [];
        }

        $eventPost = get_post($mecEventId);

        if (!$eventPost) {
            return [];
        }

        $bookingInfo = self::compileBookingDetails($reservationId);
        $participantsList = self::extractParticipantsData($reservationId);
        $ticketsList = self::extractTicketsInformation($mecEventId);
        $schedulingData = self::compileEventSchedule($mecEventId);
        $taxonomyData = self::extractEventTaxonomies($mecEventId);

        return [
            'event_id'           => $mecEventId,
            'title'              => get_the_title($mecEventId),
            'description'        => $eventPost->post_content ?? '',
            'categories'         => $taxonomyData['categories'],
            'start_date'         => $schedulingData['formatted_start_date'],
            'start_time'         => $schedulingData['formatted_start_time'],
            'end_date'           => $schedulingData['formatted_end_date'],
            'end_time'           => $schedulingData['formatted_end_time'],
            'location'           => $taxonomyData['venue'],
            'organizer'          => $taxonomyData['organizer'],
            'cost'               => get_post_meta($mecEventId, 'mec_cost', true),
            'featured_image_id'  => get_post_thumbnail_id($mecEventId),
            'featured_image_url' => get_the_post_thumbnail_url($mecEventId),
            'tickets'            => $ticketsList,
            'attendees'          => $participantsList,
            'booking'            => $bookingInfo
        ];
    }

    /**
     * Compile booking transaction details.
     *
     * @param int $reservationId Booking ID
     *
     * @return array Booking details
     */
    private static function compileBookingDetails($reservationId)
    {
        $participantsMeta = get_post_meta($reservationId, 'mec_attendees', true);
        $participantsCount = \is_array($participantsMeta) ? \count($participantsMeta) : 0;

        return [
            'title'               => get_the_title($reservationId),
            'transaction_id'      => get_post_meta($reservationId, 'mec_transaction_id', true),
            'amount_payable'      => get_post_meta($reservationId, 'mec_payable', true),
            'price'               => get_post_meta($reservationId, 'mec_price', true),
            'time'                => get_post_meta($reservationId, 'mec_booking_time', true),
            'payment_gateway'     => get_post_meta($reservationId, 'mec_gateway_label', true),
            'confirmation_status' => self::determineConfirmationState($reservationId),
            'verification_status' => self::determineVerificationState($reservationId),
            'attendees_count'     => $participantsCount
        ];
    }

    /**
     * Extract participants data from booking.
     *
     * @param int $reservationId Booking ID
     *
     * @return array Participants list
     */
    private static function extractParticipantsData($reservationId)
    {
        $participantsList = [];
        $participantsMeta = get_post_meta($reservationId, 'mec_attendees', true);

        if (!\is_array($participantsMeta) || empty($participantsMeta)) {
            return $participantsList;
        }

        foreach ($participantsMeta as $participant) {
            $participantsList[] = [
                'id'    => $participant['id'] ?? '',
                'email' => $participant['email'] ?? '',
                'name'  => $participant['name'] ?? ''
            ];
        }

        return $participantsList;
    }

    /**
     * Extract tickets information for event.
     *
     * @param int $mecEventId Event ID
     *
     * @return array Tickets list
     */
    private static function extractTicketsInformation($mecEventId)
    {
        $ticketsList = [];
        $ticketsMeta = get_post_meta($mecEventId, 'mec_tickets', true);

        if (!\is_array($ticketsMeta) || empty($ticketsMeta)) {
            return $ticketsList;
        }

        foreach ($ticketsMeta as $ticketData) {
            $ticketsList[] = [
                'id'          => $ticketData['id'] ?? '',
                'name'        => $ticketData['name'] ?? '',
                'description' => $ticketData['description'] ?? '',
                'price'       => $ticketData['price'] ?? '',
                'price_label' => $ticketData['price_label'] ?? '',
                'limit'       => $ticketData['limit'] ?? ''
            ];
        }

        return $ticketsList;
    }

    /**
     * Compile event schedule information.
     *
     * @param int $mecEventId Event ID
     *
     * @return array Schedule data
     */
    private static function compileEventSchedule($mecEventId)
    {
        $startDateTime = get_post_meta($mecEventId, 'mec_start_datetime', true);
        $endDateTime = get_post_meta($mecEventId, 'mec_end_datetime', true);

        $formattedStartDate = $startDateTime;
        $formattedStartTime = $startDateTime;
        $formattedEndDate = $endDateTime;
        $formattedEndTime = $endDateTime;

        $startTimestamp = \is_string($startDateTime) && !empty($startDateTime) ? strtotime($startDateTime) : false;
        if ($startTimestamp !== false) {
            $formattedStartDate = wp_date('F j, Y', $startTimestamp);
            $formattedStartTime = wp_date('g:i A', $startTimestamp);
        }

        $endTimestamp = \is_string($endDateTime) && !empty($endDateTime) ? strtotime($endDateTime) : false;
        if ($endTimestamp !== false) {
            $formattedEndDate = wp_date('F j, Y', $endTimestamp);
            $formattedEndTime = wp_date('g:i A', $endTimestamp);
        }

        return [
            'formatted_start_date' => $formattedStartDate,
            'formatted_start_time' => $formattedStartTime,
            'formatted_end_date'   => $formattedEndDate,
            'formatted_end_time'   => $formattedEndTime
        ];
    }

    /**
     * Extract event taxonomies (categories, venue, organizer).
     *
     * @param int $mecEventId Event ID
     *
     * @return array Taxonomy data
     */
    private static function extractEventTaxonomies($mecEventId)
    {
        $categoriesString = null;
        $categoriesTerms = get_the_terms($mecEventId, 'mec_category');

        if (!empty($categoriesTerms) && !is_wp_error($categoriesTerms)) {
            $categoryNamesList = wp_list_pluck($categoriesTerms, 'name');
            $categoriesString = implode(', ', $categoryNamesList);
        }

        return [
            'categories' => $categoriesString,
            'venue'      => self::resolveVenueName($mecEventId),
            'organizer'  => self::resolveOrganizerName($mecEventId)
        ];
    }

    /**
     * Determine booking confirmation state.
     *
     * @param int $reservationId Booking ID
     *
     * @return string Confirmation state
     */
    private static function determineConfirmationState($reservationId)
    {
        $confirmationFlag = get_post_meta($reservationId, 'mec_confirmed', true);

        switch ((int) $confirmationFlag) {
            case 1:
                return 'Confirmed';

            case -1:
                return 'Rejected';

            default:
                return 'Pending';
        }
    }

    /**
     * Determine booking verification state.
     *
     * @param int $reservationId Booking ID
     *
     * @return string Verification state
     */
    private static function determineVerificationState($reservationId)
    {
        $verificationFlag = get_post_meta($reservationId, 'mec_verified', true);

        switch ((int) $verificationFlag) {
            case 1:
                return 'Verified';

            case -1:
                return 'Canceled';

            default:
                return 'Waiting';
        }
    }

    /**
     * Resolve organizer name from event meta.
     *
     * @param int $mecEventId Event ID
     *
     * @return null|string Organizer name
     */
    private static function resolveOrganizerName($mecEventId)
    {
        $organizerIdentifier = get_post_meta($mecEventId, 'mec_organizer_id', true);

        if (empty($organizerIdentifier) || !is_numeric($organizerIdentifier)) {
            return;
        }

        $organizerTermData = get_term((int) $organizerIdentifier, 'mec_organizer');

        if (is_wp_error($organizerTermData) || !$organizerTermData || empty($organizerTermData->name)) {
            return;
        }

        return $organizerTermData->name;
    }

    /**
     * Resolve venue name from event meta.
     *
     * @param int $mecEventId Event ID
     *
     * @return null|string Venue name
     */
    private static function resolveVenueName($mecEventId)
    {
        $venueIdentifier = get_post_meta($mecEventId, 'mec_location_id', true);

        if (empty($venueIdentifier) || !is_numeric($venueIdentifier)) {
            return;
        }

        $venueTermData = get_term((int) $venueIdentifier, 'mec_location');

        if (is_wp_error($venueTermData) || !$venueTermData || empty($venueTermData->name)) {
            return;
        }

        return $venueTermData->name;
    }
}
