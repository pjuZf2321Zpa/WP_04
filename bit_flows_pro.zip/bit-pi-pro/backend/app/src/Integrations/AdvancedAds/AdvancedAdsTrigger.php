<?php

namespace BitApps\PiPro\src\Integrations\AdvancedAds;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;

if (!\defined('ABSPATH')) {
    exit;
}

final class AdvancedAdsTrigger
{
    public static function adStatusChange($adNewStatus, $adOldStatus, $ad)
    {
        self::handleAdStatusChangedTriggers(__FUNCTION__, $adNewStatus, $adOldStatus, $ad);
    }

    public static function adStatusSetDraftToPending($ad)
    {
        self::handleAdStatusChangedTriggers(__FUNCTION__, 'pending', 'draft', $ad);
    }

    public static function adStatusSetDraftToPublish($ad)
    {
        self::handleAdStatusChangedTriggers(__FUNCTION__, 'publish', 'draft', $ad);
    }

    public static function adStatusSetDraftToExpired($ad)
    {
        self::handleAdStatusChangedTriggers(__FUNCTION__, 'advanced_ads_expired', 'draft', $ad);
    }

    public static function adStatusSetPendingToDraft($ad)
    {
        self::handleAdStatusChangedTriggers(__FUNCTION__, 'draft', 'pending', $ad);
    }

    public static function adStatusSetPendingToPublish($ad)
    {
        self::handleAdStatusChangedTriggers(__FUNCTION__, 'publish', 'pending', $ad);
    }

    public static function adStatusSetPendingToExpired($ad)
    {
        self::handleAdStatusChangedTriggers(__FUNCTION__, 'advanced_ads_expired', 'pending', $ad);
    }

    public static function adStatusSetPublishToPending($ad)
    {
        self::handleAdStatusChangedTriggers(__FUNCTION__, 'pending', 'publish', $ad);
    }

    public static function adStatusSetPublishToDraft($ad)
    {
        self::handleAdStatusChangedTriggers(__FUNCTION__, 'draft', 'publish', $ad);
    }

    public static function adStatusSetPublishToExpired($ad)
    {
        self::handleAdStatusChangedTriggers(__FUNCTION__, 'advanced_ads_expired', 'publish', $ad);
    }

    public static function adStatusSetExpiredToPending($ad)
    {
        self::handleAdStatusChangedTriggers(__FUNCTION__, 'pending', 'advanced_ads_expired', $ad);
    }

    public static function adStatusSetExpiredToPublish($ad)
    {
        self::handleAdStatusChangedTriggers(__FUNCTION__, 'publish', 'advanced_ads_expired', $ad);
    }

    public static function adStatusSetExpiredToDraft($ad)
    {
        self::handleAdStatusChangedTriggers(__FUNCTION__, 'draft', 'advanced_ads_expired', $ad);
    }

    /**
     * Handle Ad Status Changed Triggers.
     *
     * @param string $machineSlug
     * @param string $adNewStatus
     * @param string $adOldStatus
     * @param object $ad
     */
    private static function handleAdStatusChangedTriggers($machineSlug, $adNewStatus, $adOldStatus, $ad)
    {
        if (!self::isPluginInstalled()) {
            return;
        }

        if (\is_object($ad) && property_exists($ad, 'ID')) {
            $ad = wp_advads_get_ad($ad->ID);
        }

        $adData = \is_object($ad) && method_exists($ad, 'get_data') ? $ad->get_data() : Utility::jsonEncodeDecode($ad);

        $data = [
            'ad_data'    => $adData,
            'old_status' => $adOldStatus,
            'new_status' => $adNewStatus,
        ];

        $flows = FlowService::exists('AdvancedAds', $machineSlug);

        if (!$flows) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $data);
    }

    private static function isPluginInstalled()
    {
        return class_exists('Advanced_Ads') && \function_exists('wp_advads_get_ad');
    }
}
