<?php

namespace BitApps\PiPro\src\Integrations\AdvancedAds;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\PiPro\Deps\BitApps\WPValidator\Validator;

if (!\defined('ABSPATH')) {
    exit;
}

final class AdvancedAdsServices
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    /**
     * Set Ad Status.
     *
     * @return array
     */
    public function setAdStatus()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'ad_id'     => ['required', 'integer'],
            'ad_status' => ['required', 'string'],
        ];

        $errors = self::validateFieldMap($fieldMappings, $rules);

        if ($errors) {
            return $errors;
        }

        return self::processAdStatusChange($fieldMappings['ad_id'], $fieldMappings['ad_status'], $fieldMappings);
    }

    /**
     * Validate field map.
     *
     * @param array $fieldMappings
     * @param array $validationRules
     * @param null|array $payload
     *
     * @return null|array
     */
    public static function validateFieldMap($fieldMappings, $validationRules, $payload = null)
    {
        $validator = new Validator();
        $validation = $validator->make($fieldMappings, $validationRules);

        if ($validation->fails()) {
            return [
                'response'    => $validation->errors(),
                'payload'     => $payload ?? $fieldMappings,
                'status_code' => 400
            ];
        }
    }

    /**
     * Process Ad Status Change (publish, expired, or custom status).
     *
     * @param int $adId
     * @param string $adStatus
     * @param array $fieldMappings
     *
     * @return array
     */
    private static function processAdStatusChange($adId, $adStatus, $fieldMappings)
    {
        if (empty(wp_advads_get_ad($adId))) {
            return [
                'response'    => __('Ad not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404
            ];
        }

        if ($adStatus === 'publish') {
            wp_publish_post($adId);
        } elseif ($adStatus === 'advanced_ads_expired') {
            self::setAdAsExpired($adId);
        } else {
            wp_update_post(
                [
                    'ID'          => $adId,
                    'post_status' => $adStatus,
                ]
            );
        }

        clean_post_cache($adId);

        $ad = wp_advads_get_ad($adId);
        $adData = \is_object($ad) && method_exists($ad, 'get_data') ? $ad->get_data() : Utility::jsonEncodeDecode($ad);

        return [
            'response'    => $adData,
            'payload'     => $fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Set Ad as expired.
     *
     * @param int $adId
     */
    private static function setAdAsExpired($adId)
    {
        $adOptions = get_post_meta($adId, 'advanced_ads_ad_options', true);
        $newExpiryDate = (int) strtotime(current_time('Y-m-d H:i:s'));

        if (\is_array($adOptions)) {
            $adOptions['expiry_date'] = $newExpiryDate;
        }

        update_post_meta($adId, 'advanced_ads_ad_options', $adOptions);
        update_post_meta($adId, 'advanced_ads_expiration_time', gmdate('Y-m-d H:i:s', $newExpiryDate));
    }
}
