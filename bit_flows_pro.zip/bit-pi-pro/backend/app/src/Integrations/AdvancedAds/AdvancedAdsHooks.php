<?php

namespace BitApps\PiPro\src\Integrations\AdvancedAds;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!\defined('ABSPATH')) {
    exit;
}

class AdvancedAdsHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'adStatusChange' => [
                'hook'          => 'transition_post_status',
                'callback'      => [AdvancedAdsTrigger::class, 'adStatusChange'],
                'accepted_args' => 3,
            ],
            'adStatusSetDraftToPending' => [
                'hook'     => 'advanced-ads-ad-status-draft-to-pending',
                'callback' => [AdvancedAdsTrigger::class, 'adStatusSetDraftToPending'],
            ],
            'adStatusSetDraftToPublish' => [
                'hook'     => 'advanced-ads-ad-status-draft-to-publish',
                'callback' => [AdvancedAdsTrigger::class, 'adStatusSetDraftToPublish'],
            ],
            'adStatusSetDraftToExpired' => [
                'hook'     => 'advanced-ads-ad-status-draft-to-advanced_ads_expired',
                'callback' => [AdvancedAdsTrigger::class, 'adStatusSetDraftToExpired'],
            ],
            'adStatusSetPendingToDraft' => [
                'hook'     => 'advanced-ads-ad-status-pending-to-draft',
                'callback' => [AdvancedAdsTrigger::class, 'adStatusSetPendingToDraft'],
            ],
            'adStatusSetPendingToPublish' => [
                'hook'     => 'advanced-ads-ad-status-pending-to-publish',
                'callback' => [AdvancedAdsTrigger::class, 'adStatusSetPendingToPublish'],
            ],
            'adStatusSetPendingToExpired' => [
                'hook'     => 'advanced-ads-ad-status-pending-to-advanced_ads_expired',
                'callback' => [AdvancedAdsTrigger::class, 'adStatusSetPendingToExpired'],
            ],
            'adStatusSetPublishToPending' => [
                'hook'     => 'advanced-ads-ad-status-publish-to-pending',
                'callback' => [AdvancedAdsTrigger::class, 'adStatusSetPublishToPending'],
            ],
            'adStatusSetPublishToDraft' => [
                'hook'     => 'advanced-ads-ad-status-publish-to-draft',
                'callback' => [AdvancedAdsTrigger::class, 'adStatusSetPublishToDraft'],
            ],
            'adStatusSetPublishToExpired' => [
                'hook'     => 'advanced-ads-ad-status-publish-to-advanced_ads_expired',
                'callback' => [AdvancedAdsTrigger::class, 'adStatusSetPublishToExpired'],
            ],
            'adStatusSetExpiredToPending' => [
                'hook'     => 'advanced-ads-ad-status-advanced_ads_expired-to-pending',
                'callback' => [AdvancedAdsTrigger::class, 'adStatusSetExpiredToPending'],
            ],
            'adStatusSetExpiredToPublish' => [
                'hook'     => 'advanced-ads-ad-status-advanced_ads_expired-to-publish',
                'callback' => [AdvancedAdsTrigger::class, 'adStatusSetExpiredToPublish'],
            ],
            'adStatusSetExpiredToDraft' => [
                'hook'     => 'advanced-ads-ad-status-advanced_ads_expired-to-draft',
                'callback' => [AdvancedAdsTrigger::class, 'adStatusSetExpiredToDraft'],
            ],
        ];
    }
}
