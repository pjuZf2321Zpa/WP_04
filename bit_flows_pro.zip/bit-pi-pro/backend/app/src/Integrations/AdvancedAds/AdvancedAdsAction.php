<?php

namespace BitApps\PiPro\src\Integrations\AdvancedAds;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;

if (!\defined('ABSPATH')) {
    exit;
}

class AdvancedAdsAction implements ActionInterface
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeAdvancedAdsAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'] ?? 200,
            $executedNodeAction['payload'] ?? [],
            $executedNodeAction['response'] ?? []
        );
    }

    private function executeAdvancedAdsAction()
    {
        if (!class_exists('Advanced_Ads') || !\function_exists('wp_advads_get_ad')) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('Advanced Ads plugin is not active.', 'bit-pi'),
            ];
        }

        $advancedAdsServices = new AdvancedAdsServices($this->nodeInfoProvider);

        $machineSlug = $this->nodeInfoProvider->getMachineSlug();

        if (!method_exists($advancedAdsServices, $machineSlug)) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('Advanced Ads action not found.', 'bit-pi'),
            ];
        }

        return $advancedAdsServices->{$machineSlug}();
    }
}
