<?php

namespace BitApps\PiPro\src\Integrations\BetterMessages;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!\defined('ABSPATH')) {
    exit;
}

class BetterMessagesHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'newMessageReceived' => [
                'hook'     => 'better_messages_message_sent',
                'callback' => [BetterMessagesTrigger::class, 'newMessageReceived'],
            ],
        ];
    }
}
