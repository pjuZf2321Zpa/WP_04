<?php

namespace BitApps\PiPro\src\Integrations\BetterMessages;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;

if (!\defined('ABSPATH')) {
    exit;
}

class BetterMessagesAction implements ActionInterface
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeBetterMessagesAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'] ?? 200,
            $executedNodeAction['payload'] ?? [],
            $executedNodeAction['response'] ?? []
        );
    }

    private function executeBetterMessagesAction()
    {
        if (!class_exists('Better_Messages_Functions')) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('Better Messages plugin is not active.', 'bit-pi'),
            ];
        }

        $betterMessagesService = new BetterMessagesService($this->nodeInfoProvider);
        $machineSlug = $this->nodeInfoProvider->getMachineSlug();

        if (!method_exists($betterMessagesService, $machineSlug)) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('Better Messages action not found.', 'bit-pi'),
            ];
        }

        return $betterMessagesService->{$machineSlug}();
    }
}
