<?php

namespace BitApps\PiPro\src\Integrations\BetterMessages;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;

if (!\defined('ABSPATH')) {
    exit;
}

final class BetterMessagesTrigger
{
    public static function newMessageReceived($message)
    {
        if (!\function_exists('Better_Messages') || !\is_object($message) || !property_exists($message, 'id')) {
            return;
        }

        $message = Better_Messages()->functions->get_message($message->id);

        if (\is_object($message)) {
            $message = get_object_vars($message);
        }

        if (isset($message['sender_id'])) {
            $message['sender_data'] = Utility::getUserInfo($message['sender_id']);
        }

        $flows = FlowService::exists('BetterMessages', __FUNCTION__);

        if (!$flows) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $message);
    }
}
