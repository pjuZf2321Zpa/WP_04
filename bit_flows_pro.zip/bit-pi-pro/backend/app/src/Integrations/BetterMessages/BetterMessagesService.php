<?php

namespace BitApps\PiPro\src\Integrations\BetterMessages;

use BitApps\Pi\Deps\BitApps\WPValidator\Validator;
use BitApps\Pi\src\Flow\NodeInfoProvider;

if (!\defined('ABSPATH')) {
    exit;
}

final class BetterMessagesService
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    /**
     * Post Message to Chatroom.
     *
     * @return array
     */
    public function postMessageToChatroom()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'sender_user_email' => ['required', 'email'],
            'chatroom_id'       => ['required', 'integer'],
            'message_content'   => ['required', 'string']
        ];

        if ($validationError = self::validateFieldMap($fieldMappings, $rules)) {
            return $validationError;
        }

        $senderUserEmail = $fieldMappings['sender_user_email'];
        $chatroomId = (int) $fieldMappings['chatroom_id'];
        $messageSubject = $fieldMappings['message_subject'] ?? '';
        $messageContent = $fieldMappings['message_content'];

        $senderId = email_exists($senderUserEmail);
        if ($senderId === false) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('User does not exist with the provided email.', 'bit-pi'),
            ];
        }

        if (!\function_exists('Better_Messages_Chats') || !\function_exists('Better_Messages')) {
            return [
                'response'    => __('Better Messages functions are not available.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        $chat = Better_Messages_Chats();

        if (!$chat->is_chat_room($chatroomId)) {
            return [
                'response'    => __('Invalid chatroom ID.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        $threadId = $chat->get_chat_thread_id($chatroomId);
        $isParticipant = Better_Messages()->functions->is_user_participant($threadId, $senderId);

        if (!$isParticipant && !$chat->add_to_chat($senderId, $chatroomId)) {
            return [
                'response'    => __('Sender could not join the chatroom.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        $data = [
            'sender_id'  => $senderId,
            'thread_id'  => $threadId,
            'subject'    => $messageSubject,
            'content'    => $messageContent,
            'return'     => 'message_id',
            'error_type' => 'wp_error',
        ];

        $messageId = Better_Messages()->functions->new_message($data);

        if (is_wp_error($messageId)) {
            return [
                'response'    => $messageId->get_error_message() ?? __('Failed to post message to chatroom.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        return [
            'response'    => Better_Messages()->functions->get_message($messageId),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Send Private Message to User.
     *
     * @return array
     */
    public function sendPrivateMessage()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'sender_user_email'   => ['required', 'email'],
            'receiver_user_email' => ['required', 'email'],
            'message_content'     => ['required', 'string']
        ];

        if ($validationError = self::validateFieldMap($fieldMappings, $rules)) {
            return $validationError;
        }

        $senderUserEmail = $fieldMappings['sender_user_email'];
        $receiverUserEmail = $fieldMappings['receiver_user_email'];
        $messageContent = $fieldMappings['message_content'];

        $messageSubject = $fieldMappings['message_subject'] ?? '';
        $uniqueTag = $fieldMappings['unique_tag'] ?? '';

        $senderId = email_exists($senderUserEmail);
        $receiverId = email_exists($receiverUserEmail);

        if ($senderId === false || $receiverId === false) {
            return [
                'response'    => __('Sender or Receiver user does not exist with the provided email.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        if (!\function_exists('Better_Messages')) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => __('Better Messages functions are not available.', 'bit-pi'),
            ];
        }

        $data = [
            'sender_id'  => $senderId,
            'recipients' => $receiverId,
            'subject'    => $messageSubject,
            'content'    => $messageContent,
            'return'     => 'message_id',
            'error_type' => 'wp_error',
        ];

        if ($uniqueTag !== '') {
            $threadId = Better_Messages()->functions->get_unique_conversation_id(
                [$senderId, $receiverId],
                $uniqueTag,
                $messageSubject
            );

            $data = [
                'thread_id'  => $threadId,
                'sender_id'  => $senderId,
                'content'    => $messageContent,
                'return'     => 'message_id',
                'error_type' => 'wp_error',
            ];
        }

        $result = Better_Messages()->functions->new_message($data);

        if (is_wp_error($result)) {
            return [
                'status_code' => 400,
                'payload'     => $fieldMappings,
                'response'    => $result->get_error_message() ?? __('Failed to send private message.', 'bit-pi'),
            ];
        }

        return [
            'response'    => Better_Messages()->functions->get_message($result),
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Validate field map.
     *
     * @param array $fieldMappings
     * @param array $rules
     * @param array $payload
     *
     * @return null|array
     */
    public static function validateFieldMap($fieldMappings, $rules, $payload = null)
    {
        $validator = new Validator();
        $validation = $validator->make($fieldMappings, $rules);

        if ($validation->fails()) {
            return [
                'response'    => $validation->errors(),
                'payload'     => $payload ?? $fieldMappings,
                'status_code' => 400
            ];
        }
    }
}
