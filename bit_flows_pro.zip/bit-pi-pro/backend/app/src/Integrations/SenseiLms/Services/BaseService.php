<?php

namespace BitApps\PiPro\src\Integrations\SenseiLms\Services;

use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Integrations\IntegrationHelper;

if (!defined('ABSPATH')) {
    exit;
}

abstract class BaseService
{
    protected const POST_STATUSES = ['publish', 'draft', 'pending', 'private'];

    protected $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    /**
     * Validate the user email and resolve the selected course.
     *
     * @param array $fields
     *
     * @return array the resolved `user` and `course_id`, or an error envelope
     */
    protected function resolveUserAndCourse($fields)
    {
        $validationErrors = IntegrationHelper::validateFieldMap(
            $fields,
            ['user_email' => ['required', 'email']]
        );
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $courseId = $this->resourceId('course-id');
        if (!$courseId) {
            return [
                'status_code' => 422,
                'payload'     => $fields,
                'response'    => __('Please select a course.', 'bit-pi'),
            ];
        }

        $postError = $this->ensurePostType($courseId, 'course', __('Course not found.', 'bit-pi'), $fields);
        if ($postError) {
            return $postError;
        }

        $user = $this->findUser($fields['user_email']);
        if (!$user) {
            return [
                'status_code' => 404,
                'payload'     => $fields,
                'response'    => __('User not found with the provided email.', 'bit-pi'),
            ];
        }

        return ['user' => $user, 'course_id' => $courseId];
    }

    /**
     * Validate the user email and resolve the selected lesson.
     *
     * @param array $fields
     *
     * @return array the resolved `user` and `lesson_id`, or an error envelope
     */
    protected function resolveUserAndLesson($fields)
    {
        $validationErrors = IntegrationHelper::validateFieldMap(
            $fields,
            ['user_email' => ['required', 'email']]
        );
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $lessonId = $this->resourceId('lesson-id');
        if (!$lessonId) {
            return [
                'status_code' => 422,
                'payload'     => $fields,
                'response'    => __('Please select a lesson.', 'bit-pi'),
            ];
        }

        $postError = $this->ensurePostType($lessonId, 'lesson', __('Lesson not found.', 'bit-pi'), $fields);
        if ($postError) {
            return $postError;
        }

        $user = $this->findUser($fields['user_email']);
        if (!$user) {
            return [
                'status_code' => 404,
                'payload'     => $fields,
                'response'    => __('User not found with the provided email.', 'bit-pi'),
            ];
        }

        return ['user' => $user, 'lesson_id' => $lessonId];
    }

    /**
     * Read a config dropdown selection. Returns 0 when empty or set to "any".
     *
     * @param string $key
     *
     * @return int
     */
    protected function resourceId($key)
    {
        $value = $this->nodeInfoProvider->getFieldMapConfigs($key . '.value');

        if (empty($value) || $value === 'any') {
            return 0;
        }

        return (int) $value;
    }

    protected function findUser($email)
    {
        return get_user_by('email', $email);
    }

    protected function ensurePostType($postId, $postType, $message, $fields)
    {
        $post = get_post($postId);

        if (!$post || $post->post_type !== $postType) {
            return [
                'status_code' => 404,
                'payload'     => $fields,
                'response'    => $message,
            ];
        }
    }

    protected function ensureClassExists($className, $fields)
    {
        if (!class_exists($className)) {
            return [
                // translators: %s is the class name that is missing.
                'response'    => \sprintf(__('Required Sensei class %s does not exist.', 'bit-pi'), $className),
                'payload'     => $fields,
                'status_code' => 400,
            ];
        }
    }

    /**
     * Build a wp_insert_post argument array from common content fields.
     *
     * @param string $postType
     * @param array  $fields
     *
     * @return array
     */
    protected function buildPostArgs($postType, $fields)
    {
        $postStatus = !empty($fields['post_status']) ? $fields['post_status'] : 'publish';

        if (!\in_array($postStatus, self::POST_STATUSES, true)) {
            $postStatus = 'publish';
        }

        $postArgs = [
            'post_type'    => $postType,
            'post_status'  => $postStatus,
            'post_title'   => $fields['post_title'],
            'post_content' => isset($fields['post_content']) ? wp_kses_post($fields['post_content']) : '',
            'post_excerpt' => $fields['post_excerpt'] ?? '',
        ];

        if (!empty($fields['author_email'])) {
            $author = $this->findUser($fields['author_email']);

            if ($author) {
                $postArgs['post_author'] = $author->ID;
            }
        }

        return $postArgs;
    }
}
