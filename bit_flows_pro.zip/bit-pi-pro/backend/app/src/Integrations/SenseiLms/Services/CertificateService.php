<?php

namespace BitApps\PiPro\src\Integrations\SenseiLms\Services;

use BitApps\PiPro\src\Integrations\SenseiLms\helper\SenseiLmsHelper;
use Woothemes_Sensei_Certificate_Data_Store;
use WooThemes_Sensei_Certificates;
use Woothemes_Sensei_Certificates_Utils;

if (!defined('ABSPATH')) {
    exit;
}

final class CertificateService extends BaseService
{
    /**
     * Create a certificate for a user (requires the Sensei Certificates addon).
     *
     * @return array
     */
    public function createCertificate()
    {
        $fields = $this->nodeInfoProvider->getFieldMapData();

        $addonError = $this->ensureCertificatesAddon('Woothemes_Sensei_Certificate_Data_Store', $fields);
        if ($addonError) {
            return $addonError;
        }

        $userCourse = $this->resolveUserAndCourse($fields);
        if (!\is_array($userCourse) || isset($userCourse['status_code'])) {
            return $userCourse;
        }

        $certificateStore = new Woothemes_Sensei_Certificate_Data_Store();
        $certificateId = $certificateStore->insert($userCourse['user']->ID, $userCourse['course_id']);

        if (is_wp_error($certificateId)) {
            $message = $certificateId->get_error_message();

            if ($message === '') {
                $message = __('A certificate already exists for this user and course.', 'bit-pi');
            }

            return [
                'status_code' => 400,
                'payload'     => $fields,
                'response'    => $message,
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fields,
            'response'    => [
                'message'        => __('Certificate created successfully.', 'bit-pi'),
                'certificate_id' => $certificateId,
                'user_id'        => $userCourse['user']->ID,
                'course_id'      => $userCourse['course_id'],
            ],
        ];
    }

    /**
     * Get a user's certificate for a course (requires the Sensei Certificates addon).
     *
     * @return array
     */
    public function getUserCertificate()
    {
        $fields = $this->nodeInfoProvider->getFieldMapData();

        $addonError = $this->ensureCertificatesAddon('WooThemes_Sensei_Certificates', $fields);
        if ($addonError) {
            return $addonError;
        }

        $userCourse = $this->resolveUserAndCourse($fields);
        if (!\is_array($userCourse) || isset($userCourse['status_code'])) {
            return $userCourse;
        }

        $userId = $userCourse['user']->ID;
        $courseId = $userCourse['course_id'];

        $certificates = WooThemes_Sensei_Certificates::instance();
        $certificateId = $certificates->get_certificate_id($courseId, $userId);

        if (empty($certificateId)) {
            return [
                'status_code' => 404,
                'payload'     => $fields,
                'response'    => __('No certificate found for this user and course.', 'bit-pi'),
            ];
        }

        $hash = class_exists('Woothemes_Sensei_Certificates_Utils')
            ? Woothemes_Sensei_Certificates_Utils::get_certificate_hash($courseId, $userId)
            : '';

        return [
            'status_code' => 200,
            'payload'     => $fields,
            'response'    => [
                'user_id'          => $userId,
                'course_id'        => $courseId,
                'certificate_id'   => $certificateId,
                'certificate_url'  => $certificates->get_certificate_url($courseId, $userId),
                'certificate_hash' => $hash,
            ],
        ];
    }

    /**
     * Guard that the Sensei Certificates addon (and the required class) is active.
     *
     * @param string $className
     * @param array  $fields
     *
     * @return null|array
     */
    private function ensureCertificatesAddon($className, $fields)
    {
        if (!SenseiLmsHelper::isCertificatesInstalled() || !class_exists($className)) {
            return [
                'status_code' => 400,
                'payload'     => $fields,
                'response'    => __('Sensei LMS Certificates addon is not active.', 'bit-pi'),
            ];
        }
    }
}
