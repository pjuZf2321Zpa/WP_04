<?php

namespace BitApps\PiPro\src\Integrations\SenseiLms\Services;

use BitApps\Pi\src\Integrations\IntegrationHelper;
use Sensei_Utils;

if (!defined('ABSPATH')) {
    exit;
}

final class LessonService extends BaseService
{
    private const LESSON_STATUSES = ['in-progress', 'ungraded', 'graded', 'passed', 'failed'];

    /**
     * Start a lesson for a user.
     *
     * @return array
     */
    public function startLessonForUser()
    {
        $fields = $this->nodeInfoProvider->getFieldMapData();

        $userLesson = $this->resolveUserAndLesson($fields);
        if (!\is_array($userLesson) || isset($userLesson['status_code'])) {
            return $userLesson;
        }

        $classError = $this->ensureClassExists('Sensei_Utils', $fields);
        if ($classError) {
            return $classError;
        }

        $markComplete = (($fields['mark_complete'] ?? 'no') === 'yes');

        $activityId = Sensei_Utils::user_start_lesson($userLesson['user']->ID, $userLesson['lesson_id'], $markComplete);

        return [
            'status_code' => 200,
            'payload'     => $fields,
            'response'    => [
                'message'     => __('Lesson started for user successfully.', 'bit-pi'),
                'activity_id' => $activityId,
                'user_id'     => $userLesson['user']->ID,
                'lesson_id'   => $userLesson['lesson_id'],
                'completed'   => $markComplete,
            ],
        ];
    }

    /**
     * Update a user's lesson status.
     *
     * @return array
     */
    public function updateLessonStatus()
    {
        $fields = $this->nodeInfoProvider->getFieldMapData();

        $validationErrors = IntegrationHelper::validateFieldMap(
            $fields,
            [
                'user_email' => ['required', 'email'],
                'status'     => ['required', 'string'],
            ]
        );
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $userLesson = $this->resolveUserAndLesson($fields);
        if (!\is_array($userLesson) || isset($userLesson['status_code'])) {
            return $userLesson;
        }

        $status = $fields['status'];

        if (!\in_array($status, self::LESSON_STATUSES, true)) {
            return [
                'status_code' => 422,
                'payload'     => $fields,
                'response'    => \sprintf(
                    // translators: %s is the list of allowed status values.
                    __('Invalid lesson status. Allowed values: %s', 'bit-pi'),
                    implode(', ', self::LESSON_STATUSES)
                ),
            ];
        }

        $classError = $this->ensureClassExists('Sensei_Utils', $fields);
        if ($classError) {
            return $classError;
        }

        $commentId = Sensei_Utils::update_lesson_status($userLesson['user']->ID, $userLesson['lesson_id'], $status, []);

        if (!$commentId) {
            return [
                'status_code' => 400,
                'payload'     => $fields,
                'response'    => __('Failed to update the lesson status.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fields,
            'response'    => [
                'message'    => __('Lesson status updated successfully.', 'bit-pi'),
                'comment_id' => $commentId,
                'user_id'    => $userLesson['user']->ID,
                'lesson_id'  => $userLesson['lesson_id'],
                'status'     => $status,
            ],
        ];
    }

    /**
     * Reset a user's lesson progress.
     *
     * @return array
     */
    public function resetLessonForUser()
    {
        $fields = $this->nodeInfoProvider->getFieldMapData();

        $userLesson = $this->resolveUserAndLesson($fields);
        if (!\is_array($userLesson) || isset($userLesson['status_code'])) {
            return $userLesson;
        }

        $classError = $this->ensureClassExists('Sensei_Utils', $fields);
        if ($classError) {
            return $classError;
        }

        Sensei_Utils::sensei_remove_user_from_lesson($userLesson['lesson_id'], $userLesson['user']->ID);

        return [
            'status_code' => 200,
            'payload'     => $fields,
            'response'    => [
                'message'   => __('Lesson progress reset successfully.', 'bit-pi'),
                'user_id'   => $userLesson['user']->ID,
                'lesson_id' => $userLesson['lesson_id'],
            ],
        ];
    }

    /**
     * Get a user's status for a lesson.
     *
     * @return array
     */
    public function getLessonStatus()
    {
        $fields = $this->nodeInfoProvider->getFieldMapData();

        $userLesson = $this->resolveUserAndLesson($fields);
        if (!\is_array($userLesson) || isset($userLesson['status_code'])) {
            return $userLesson;
        }

        $classError = $this->ensureClassExists('Sensei_Utils', $fields);
        if ($classError) {
            return $classError;
        }

        $userId = $userLesson['user']->ID;
        $lessonId = $userLesson['lesson_id'];

        $status = Sensei_Utils::user_lesson_status($lessonId, $userId);

        return [
            'status_code' => 200,
            'payload'     => $fields,
            'response'    => [
                'user_id'   => $userId,
                'lesson_id' => $lessonId,
                'started'   => (bool) Sensei_Utils::user_started_lesson($lessonId, $userId),
                'completed' => Sensei_Utils::user_completed_lesson($lessonId, $userId),
                'status'    => ($status && isset($status->comment_approved)) ? $status->comment_approved : '',
            ],
        ];
    }

    /**
     * Create a lesson and link it to a course.
     *
     * @return array
     */
    public function createLesson()
    {
        $fields = $this->nodeInfoProvider->getFieldMapData();

        $validationErrors = IntegrationHelper::validateFieldMap($fields, ['post_title' => ['required', 'string']]);
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $courseId = $this->resourceId('course-id');
        if (!$courseId) {
            return [
                'status_code' => 422,
                'payload'     => $fields,
                'response'    => __('Please select a course for the lesson.', 'bit-pi'),
            ];
        }

        $postError = $this->ensurePostType($courseId, 'course', __('Course not found.', 'bit-pi'), $fields);
        if ($postError) {
            return $postError;
        }

        $postId = wp_insert_post($this->buildPostArgs('lesson', $fields), true);

        if (is_wp_error($postId)) {
            return [
                'status_code' => 400,
                'payload'     => $fields,
                'response'    => $postId->get_error_message(),
            ];
        }

        update_post_meta($postId, '_lesson_course', $courseId);

        return [
            'status_code' => 200,
            'payload'     => $fields,
            'response'    => [
                'message'    => __('Lesson created successfully.', 'bit-pi'),
                'lesson_id'  => $postId,
                'course_id'  => $courseId,
                'lesson_url' => get_permalink($postId),
            ],
        ];
    }
}
