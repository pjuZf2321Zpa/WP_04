<?php

namespace BitApps\PiPro\src\Integrations\SenseiLms\Services;

use BitApps\Pi\src\Integrations\IntegrationHelper;
use Sensei_Course_Enrolment;
use Sensei_Utils;

if (!defined('ABSPATH')) {
    exit;
}

final class CourseService extends BaseService
{
    /**
     * Start a course for a user.
     *
     * @return array
     */
    public function startCourseForUser()
    {
        $fields = $this->nodeInfoProvider->getFieldMapData();

        $userCourse = $this->resolveUserAndCourse($fields);
        if (!\is_array($userCourse) || isset($userCourse['status_code'])) {
            return $userCourse;
        }

        $classError = $this->ensureClassExists('Sensei_Utils', $fields);
        if ($classError) {
            return $classError;
        }

        $activityId = Sensei_Utils::user_start_course($userCourse['user']->ID, $userCourse['course_id']);

        return [
            'status_code' => 200,
            'payload'     => $fields,
            'response'    => [
                'message'     => __('Course started for user successfully.', 'bit-pi'),
                'activity_id' => $activityId,
                'user_id'     => $userCourse['user']->ID,
                'course_id'   => $userCourse['course_id'],
            ],
        ];
    }

    /**
     * Mark a course as complete for a user.
     *
     * @return array
     */
    public function completeCourseForUser()
    {
        $fields = $this->nodeInfoProvider->getFieldMapData();

        $userCourse = $this->resolveUserAndCourse($fields);
        if (!\is_array($userCourse) || isset($userCourse['status_code'])) {
            return $userCourse;
        }

        $classError = $this->ensureClassExists('Sensei_Utils', $fields);
        if ($classError) {
            return $classError;
        }

        Sensei_Utils::user_start_course($userCourse['user']->ID, $userCourse['course_id']);
        Sensei_Utils::user_complete_course($userCourse['course_id'], $userCourse['user']->ID, true);

        // user_complete_course() returns the progress comment id (always truthy) and only
        // completes the course once every lesson is done, so verify the real completion.
        if (!Sensei_Utils::user_completed_course($userCourse['course_id'], $userCourse['user']->ID)) {
            return [
                'status_code' => 400,
                'payload'     => $fields,
                'response'    => __('Course could not be marked complete. The learner still has lessons to finish.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fields,
            'response'    => [
                'message'   => __('Course marked as complete successfully.', 'bit-pi'),
                'user_id'   => $userCourse['user']->ID,
                'course_id' => $userCourse['course_id'],
            ],
        ];
    }

    /**
     * Reset a user's course progress.
     *
     * @return array
     */
    public function resetCourseForUser()
    {
        $fields = $this->nodeInfoProvider->getFieldMapData();

        $userCourse = $this->resolveUserAndCourse($fields);
        if (!\is_array($userCourse) || isset($userCourse['status_code'])) {
            return $userCourse;
        }

        $classError = $this->ensureClassExists('Sensei_Utils', $fields);
        if ($classError) {
            return $classError;
        }

        Sensei_Utils::sensei_remove_user_from_course($userCourse['course_id'], $userCourse['user']->ID);

        return [
            'status_code' => 200,
            'payload'     => $fields,
            'response'    => [
                'message'   => __('Course progress reset successfully.', 'bit-pi'),
                'user_id'   => $userCourse['user']->ID,
                'course_id' => $userCourse['course_id'],
            ],
        ];
    }

    /**
     * Get a user's progress for a course.
     *
     * @return array
     */
    public function getCourseProgress()
    {
        $fields = $this->nodeInfoProvider->getFieldMapData();

        $userCourse = $this->resolveUserAndCourse($fields);
        if (!\is_array($userCourse) || isset($userCourse['status_code'])) {
            return $userCourse;
        }

        $classError = $this->ensureClassExists('Sensei_Utils', $fields);
        if ($classError) {
            return $classError;
        }

        $userId = $userCourse['user']->ID;
        $courseId = $userCourse['course_id'];

        $status = Sensei_Utils::user_course_status($courseId, $userId);
        $statusValue = ($status && isset($status->comment_approved)) ? $status->comment_approved : '';
        $percent = ($status && isset($status->comment_ID)) ? get_comment_meta($status->comment_ID, 'percent', true) : '';

        $isEnrolled = false;
        if (class_exists('Sensei_Course_Enrolment')) {
            $isEnrolled = Sensei_Course_Enrolment::get_course_instance($courseId)->is_enrolled($userId);
        }

        return [
            'status_code' => 200,
            'payload'     => $fields,
            'response'    => [
                'user_id'     => $userId,
                'course_id'   => $courseId,
                'is_enrolled' => $isEnrolled,
                'started'     => (bool) Sensei_Utils::user_started_course($courseId, $userId),
                'completed'   => Sensei_Utils::user_completed_course($courseId, $userId),
                'status'      => $statusValue,
                'percent'     => $percent !== '' ? (int) $percent : null,
            ],
        ];
    }

    /**
     * Create a course.
     *
     * @return array
     */
    public function createCourse()
    {
        $fields = $this->nodeInfoProvider->getFieldMapData();

        $validationErrors = IntegrationHelper::validateFieldMap($fields, ['post_title' => ['required', 'string']]);
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $postId = wp_insert_post($this->buildPostArgs('course', $fields), true);

        if (is_wp_error($postId)) {
            return [
                'status_code' => 400,
                'payload'     => $fields,
                'response'    => $postId->get_error_message(),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fields,
            'response'    => [
                'message'    => __('Course created successfully.', 'bit-pi'),
                'course_id'  => $postId,
                'course_url' => get_permalink($postId),
            ],
        ];
    }
}
