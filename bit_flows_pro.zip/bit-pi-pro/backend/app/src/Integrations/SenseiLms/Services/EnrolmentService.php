<?php

namespace BitApps\PiPro\src\Integrations\SenseiLms\Services;

use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\SenseiLms\helper\SenseiLmsHelper;
use Sensei_Course_Enrolment;
use Sensei_Course_Manual_Enrolment_Provider;
use Sensei_Learner;

if (!defined('ABSPATH')) {
    exit;
}

final class EnrolmentService extends BaseService
{
    /**
     * Enroll a user in a course (manual enrolment provider).
     *
     * @return array
     */
    public function enrollUserInCourse()
    {
        return $this->handleManualEnrolment('enrol_learner', __('User enrolled in course successfully.', 'bit-pi'));
    }

    /**
     * Withdraw a user from a course (manual enrolment provider).
     *
     * @return array
     */
    public function withdrawUserFromCourse()
    {
        return $this->handleManualEnrolment('withdraw_learner', __('User withdrawn from course successfully.', 'bit-pi'));
    }

    /**
     * List the learners enrolled in a course.
     *
     * @return array
     */
    public function listEnrolledLearners()
    {
        $fields = $this->nodeInfoProvider->getFieldMapData();

        $courseId = $this->resourceId('course-id');
        if (!$courseId) {
            return [
                'status_code' => 422,
                'payload'     => $fields,
                'response'    => __('Please select a course.', 'bit-pi'),
            ];
        }

        $postError = $this->ensurePostType($courseId, 'course', __('Course not found.', 'bit-pi'), $fields);
        if ($postError) {
            return $postError;
        }

        $classError = $this->ensureClassExists('Sensei_Course_Enrolment', $fields);
        if ($classError) {
            return $classError;
        }

        $userIds = Sensei_Course_Enrolment::get_course_instance($courseId)->get_enrolled_user_ids();

        // Prime the user cache in a single query so the per-learner getLearner() lookups hit cache.
        if (!empty($userIds) && \function_exists('cache_users')) {
            cache_users($userIds);
        }

        $learners = [];
        foreach ($userIds as $userId) {
            $learners[] = SenseiLmsHelper::getLearner($userId);
        }

        return [
            'status_code' => 200,
            'payload'     => $fields,
            'response'    => [
                'course_id' => $courseId,
                'count'     => \count($learners),
                'learners'  => $learners,
            ],
        ];
    }

    /**
     * List the courses a user is enrolled in.
     *
     * @return array
     */
    public function getUserEnrolledCourses()
    {
        $fields = $this->nodeInfoProvider->getFieldMapData();

        $validationErrors = IntegrationHelper::validateFieldMap($fields, ['user_email' => ['required', 'email']]);
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $user = $this->findUser($fields['user_email']);
        if (!$user) {
            return [
                'status_code' => 404,
                'payload'     => $fields,
                'response'    => __('User not found with the provided email.', 'bit-pi'),
            ];
        }

        $classError = $this->ensureClassExists('Sensei_Learner', $fields);
        if ($classError) {
            return $classError;
        }

        $query = Sensei_Learner::instance()->get_enrolled_courses_query($user->ID);

        $courses = [];
        foreach ($query->posts as $course) {
            $courses[] = SenseiLmsHelper::getCoursePayload($course);
        }

        return [
            'status_code' => 200,
            'payload'     => $fields,
            'response'    => [
                'user_id' => $user->ID,
                'count'   => \count($courses),
                'courses' => $courses,
            ],
        ];
    }

    /**
     * Shared enrol/withdraw flow for the manual enrolment provider.
     *
     * @param string $method
     * @param string $successMessage
     *
     * @return array
     */
    private function handleManualEnrolment($method, $successMessage)
    {
        $fields = $this->nodeInfoProvider->getFieldMapData();

        $userCourse = $this->resolveUserAndCourse($fields);
        if (!\is_array($userCourse) || isset($userCourse['status_code'])) {
            return $userCourse;
        }

        if (!class_exists('Sensei_Course_Manual_Enrolment_Provider')) {
            return $this->ensureClassExists('Sensei_Course_Manual_Enrolment_Provider', $fields);
        }

        // The provider returns true on success (including an idempotent no-op when the
        // learner is already in the requested state) and false only on a genuine failure.
        $result = Sensei_Course_Manual_Enrolment_Provider::instance()->{$method}($userCourse['user']->ID, $userCourse['course_id']);

        if (!$result) {
            return [
                'status_code' => 400,
                'payload'     => $fields,
                'response'    => __('Failed to update the course enrolment.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fields,
            'response'    => [
                'message'   => $successMessage,
                'user_id'   => $userCourse['user']->ID,
                'course_id' => $userCourse['course_id'],
            ],
        ];
    }
}
