<?php

namespace BitApps\PiPro\src\Integrations\SenseiLms\Services;

use BitApps\Pi\src\Integrations\IntegrationHelper;
use Sensei_Quiz;
use Sensei_Utils;

if (!defined('ABSPATH')) {
    exit;
}

final class QuizService extends BaseService
{
    /**
     * Grade a user's quiz.
     *
     * @return array
     */
    public function gradeQuiz()
    {
        $fields = $this->nodeInfoProvider->getFieldMapData();

        $validationErrors = IntegrationHelper::validateFieldMap(
            $fields,
            [
                'user_email' => ['required', 'email'],
                'grade'      => ['required', 'numeric'],
            ]
        );
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $quizId = $this->resourceId('quiz-id');
        if (!$quizId) {
            return [
                'status_code' => 422,
                'payload'     => $fields,
                'response'    => __('Please select a quiz.', 'bit-pi'),
            ];
        }

        $postError = $this->ensurePostType($quizId, 'quiz', __('Quiz not found.', 'bit-pi'), $fields);
        if ($postError) {
            return $postError;
        }

        $user = $this->findUser($fields['user_email']);
        if (!$user) {
            return [
                'status_code' => 404,
                'payload'     => $fields,
                'response'    => __('User not found with the provided email.', 'bit-pi'),
            ];
        }

        $classError = $this->ensureClassExists('Sensei_Utils', $fields);
        if ($classError) {
            return $classError;
        }

        $grade = (float) $fields['grade'];
        $gradeType = !empty($fields['grade_type']) ? $fields['grade_type'] : 'auto';

        $graded = Sensei_Utils::sensei_grade_quiz($quizId, $grade, $user->ID, $gradeType);

        if (!$graded) {
            return [
                'status_code' => 400,
                'payload'     => $fields,
                'response'    => __('Failed to grade the quiz. The learner may not have submitted this quiz yet.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fields,
            'response'    => [
                'message'    => __('Quiz graded successfully.', 'bit-pi'),
                'user_id'    => $user->ID,
                'quiz_id'    => $quizId,
                'grade'      => $grade,
                'grade_type' => $gradeType,
            ],
        ];
    }

    /**
     * Get a user's grade for a quiz.
     *
     * @return array
     */
    public function getQuizGrade()
    {
        $fields = $this->nodeInfoProvider->getFieldMapData();

        $validationErrors = IntegrationHelper::validateFieldMap($fields, ['user_email' => ['required', 'email']]);
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $quizId = $this->resourceId('quiz-id');
        if (!$quizId) {
            return [
                'status_code' => 422,
                'payload'     => $fields,
                'response'    => __('Please select a quiz.', 'bit-pi'),
            ];
        }

        $postError = $this->ensurePostType($quizId, 'quiz', __('Quiz not found.', 'bit-pi'), $fields);
        if ($postError) {
            return $postError;
        }

        $user = $this->findUser($fields['user_email']);
        if (!$user) {
            return [
                'status_code' => 404,
                'payload'     => $fields,
                'response'    => __('User not found with the provided email.', 'bit-pi'),
            ];
        }

        $classError = $this->ensureClassExists('Sensei_Quiz', $fields);
        if ($classError) {
            return $classError;
        }

        $lessonId = (int) get_post_meta($quizId, '_quiz_lesson', true);
        if (!$lessonId) {
            return [
                'status_code' => 404,
                'payload'     => $fields,
                'response'    => __('Quiz is not linked to a lesson.', 'bit-pi'),
            ];
        }

        return [
            'status_code' => 200,
            'payload'     => $fields,
            'response'    => [
                'user_id'   => $user->ID,
                'quiz_id'   => $quizId,
                'lesson_id' => $lessonId,
                'grade'     => Sensei_Quiz::get_user_quiz_grade($lessonId, $user->ID),
            ],
        ];
    }
}
