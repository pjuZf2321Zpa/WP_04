<?php

namespace BitApps\PiPro\src\Integrations\SenseiLms;

use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\src\Integrations\SenseiLms\helper\SenseiLmsHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class SenseiLmsTrigger
{
    public static function courseEnrolmentStatusChanged($userId, $courseId, $isEnrolled)
    {
        $data = [
            'learner'     => SenseiLmsHelper::getLearner($userId),
            'course'      => SenseiLmsHelper::getCoursePayload($courseId),
            'is_enrolled' => (bool) $isEnrolled,
        ];

        self::execute('courseEnrolmentStatusChanged', $data, $courseId, 'course-id');
    }

    public static function learnerManuallyEnrolled($userId, $courseId)
    {
        $data = [
            'learner' => SenseiLmsHelper::getLearner($userId),
            'course'  => SenseiLmsHelper::getCoursePayload($courseId),
        ];

        self::execute('learnerManuallyEnrolled', $data, $courseId, 'course-id');
    }

    public static function learnerManuallyWithdrawn($userId, $courseId)
    {
        $data = [
            'learner' => SenseiLmsHelper::getLearner($userId),
            'course'  => SenseiLmsHelper::getCoursePayload($courseId),
        ];

        self::execute('learnerManuallyWithdrawn', $data, $courseId, 'course-id');
    }

    public static function learnerStartedCourse($userId, $courseId)
    {
        $data = [
            'learner' => SenseiLmsHelper::getLearner($userId),
            'course'  => SenseiLmsHelper::getCoursePayload($courseId),
        ];

        self::execute('learnerStartedCourse', $data, $courseId, 'course-id');
    }

    public static function learnerCompletedCourse($userId, $courseId)
    {
        $data = [
            'learner' => SenseiLmsHelper::getLearner($userId),
            'course'  => SenseiLmsHelper::getCoursePayload($courseId),
        ];

        self::execute('learnerCompletedCourse', $data, $courseId, 'course-id');
    }

    public static function courseStatusUpdated($status, $userId, $courseId, $commentId = 0, $previousStatus = null)
    {
        $data = [
            'learner'         => SenseiLmsHelper::getLearner($userId),
            'course'          => SenseiLmsHelper::getCoursePayload($courseId),
            'status'          => $status,
            'previous_status' => $previousStatus,
            'comment_id'      => $commentId,
        ];

        self::execute('courseStatusUpdated', $data, $courseId, 'course-id');
    }

    public static function learnerStartedLesson($userId, $lessonId)
    {
        $data = [
            'learner' => SenseiLmsHelper::getLearner($userId),
            'lesson'  => SenseiLmsHelper::getLessonPayload($lessonId),
        ];

        self::execute('learnerStartedLesson', $data, $lessonId, 'lesson-id');
    }

    public static function learnerCompletedLesson($userId, $lessonId)
    {
        $data = [
            'learner' => SenseiLmsHelper::getLearner($userId),
            'lesson'  => SenseiLmsHelper::getLessonPayload($lessonId),
        ];

        self::execute('learnerCompletedLesson', $data, $lessonId, 'lesson-id');
    }

    public static function lessonStatusUpdated($status, $userId, $lessonId, $commentId = 0)
    {
        $data = [
            'learner'    => SenseiLmsHelper::getLearner($userId),
            'lesson'     => SenseiLmsHelper::getLessonPayload($lessonId),
            'status'     => $status,
            'comment_id' => $commentId,
        ];

        self::execute('lessonStatusUpdated', $data, $lessonId, 'lesson-id');
    }

    public static function learnerSubmittedQuiz($userId, $quizId, $grade = null, $quizPassPercentage = null, $quizGradeType = null)
    {
        $data = [
            'learner'         => SenseiLmsHelper::getLearner($userId),
            'quiz'            => SenseiLmsHelper::getQuizPayload($quizId),
            'grade'           => $grade,
            'pass_percentage' => $quizPassPercentage,
            'grade_type'      => $quizGradeType,
        ];

        self::execute('learnerSubmittedQuiz', $data, $quizId, 'quiz-id');
    }

    public static function quizGradedForLearner($userId, $quizId, $grade = null, $quizPassmark = null, $quizGradeType = null)
    {
        $data = [
            'learner'    => SenseiLmsHelper::getLearner($userId),
            'quiz'       => SenseiLmsHelper::getQuizPayload($quizId),
            'grade'      => $grade,
            'passmark'   => $quizPassmark,
            'passed'     => ($grade !== null && $quizPassmark !== null) ? ((float) $grade >= (float) $quizPassmark) : null,
            'grade_type' => $quizGradeType,
        ];

        self::execute('quizGradedForLearner', $data, $quizId, 'quiz-id');
    }

    public static function learnerResetCourse($userId, $courseId)
    {
        $data = [
            'learner' => SenseiLmsHelper::getLearner($userId),
            'course'  => SenseiLmsHelper::getCoursePayload($courseId),
        ];

        self::execute('learnerResetCourse', $data, $courseId, 'course-id');
    }

    public static function learnerResetLesson($userId, $lessonId)
    {
        $data = [
            'learner' => SenseiLmsHelper::getLearner($userId),
            'lesson'  => SenseiLmsHelper::getLessonPayload($lessonId),
        ];

        self::execute('learnerResetLesson', $data, $lessonId, 'lesson-id');
    }

    public static function teacherAssignedToCourse($newTeacher, $courseId)
    {
        $data = [
            'teacher'    => SenseiLmsHelper::getLearner($newTeacher),
            'course'     => SenseiLmsHelper::getCoursePayload($courseId),
            'teacher_id' => (int) $newTeacher,
        ];

        self::execute('teacherAssignedToCourse', $data, $courseId, 'course-id');
    }

    public static function certificateIssued($metaId, $postId, $metaKey = '', $metaValue = '')
    {
        if ($metaKey !== 'certificate_hash') {
            return;
        }

        $post = get_post($postId);

        if (!$post || $post->post_type !== 'certificate') {
            return;
        }

        $learnerId = get_post_meta($postId, 'learner_id', true);
        $courseId = get_post_meta($postId, 'course_id', true);

        $data = [
            'certificate' => [
                'certificate_id'   => $postId,
                'certificate_hash' => $metaValue !== '' ? $metaValue : get_post_meta($postId, 'certificate_hash', true),
                'certificate_url'  => get_permalink($postId),
            ],
            'learner' => SenseiLmsHelper::getLearner($learnerId),
            'course'  => SenseiLmsHelper::getCoursePayload($courseId),
        ];

        self::execute('certificateIssued', $data);
    }

    private static function execute($machineSlug, $data, $value = null, $keyName = null)
    {
        if (!SenseiLmsHelper::isPluginInstalled()) {
            return;
        }

        $flows = FlowService::exists('senseiLms', $machineSlug);

        if (!$flows || empty($data)) {
            return;
        }

        if ($value !== null && $keyName !== null) {
            IntegrationHelper::handleFlowForForm($flows, $data, $value, $keyName);

            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $data);
    }
}
