<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\PiPro\src\Integrations\SenseiLms\helper\SenseiLmsHelper;

Route::group(
    static function () {
        Route::get('get_sensei_all_course', [SenseiLmsHelper::class, 'getCourses']);
        Route::get('get_sensei_all_lesson', [SenseiLmsHelper::class, 'getLessons']);
        Route::get('get_sensei_all_quiz', [SenseiLmsHelper::class, 'getQuizzes']);
    }
)->middleware('nonce:admin');
