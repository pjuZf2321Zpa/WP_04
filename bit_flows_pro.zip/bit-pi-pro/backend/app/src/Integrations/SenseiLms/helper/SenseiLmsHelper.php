<?php

namespace BitApps\PiPro\src\Integrations\SenseiLms\helper;

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Response;
use WP_Post;

if (!defined('ABSPATH')) {
    exit;
}

final class SenseiLmsHelper
{
    public static function isPluginInstalled()
    {
        return defined('SENSEI_LMS_VERSION');
    }

    public static function isCertificatesInstalled()
    {
        return defined('SENSEI_CERTIFICATES_VERSION');
    }

    /**
     * Build a learner/user data payload.
     *
     * @param int $userId
     *
     * @return array
     */
    public static function getLearner($userId)
    {
        $user = get_userdata((int) $userId);

        if (!$user) {
            return ['user_id' => (int) $userId];
        }

        return [
            'user_id'      => $user->ID,
            'user_login'   => $user->user_login,
            'user_email'   => $user->user_email,
            'display_name' => $user->display_name,
            'first_name'   => $user->first_name,
            'last_name'    => $user->last_name,
        ];
    }

    /**
     * Build a course data payload.
     *
     * @param int|WP_Post $course a course ID or an already-loaded course post
     *
     * @return array
     */
    public static function getCoursePayload($course)
    {
        $course = $course instanceof WP_Post ? $course : get_post((int) $course);

        if (!$course) {
            return ['course_id' => 0];
        }

        return [
            'course_id'          => $course->ID,
            'course_title'       => $course->post_title,
            'course_description' => $course->post_content,
            'course_url'         => get_permalink($course->ID),
        ];
    }

    /**
     * Build a lesson data payload, including its parent course.
     *
     * @param int $lessonId
     *
     * @return array
     */
    public static function getLessonPayload($lessonId)
    {
        $lesson = get_post((int) $lessonId);

        if (!$lesson) {
            return ['lesson_id' => (int) $lessonId];
        }

        $data = [
            'lesson_id'          => $lesson->ID,
            'lesson_title'       => $lesson->post_title,
            'lesson_description' => $lesson->post_content,
            'lesson_url'         => get_permalink($lesson->ID),
        ];

        $courseId = get_post_meta($lesson->ID, '_lesson_course', true);

        if ($courseId) {
            $data += self::getCoursePayload($courseId);
        }

        return $data;
    }

    /**
     * Build a quiz data payload, including its parent lesson and course.
     *
     * @param int $quizId
     *
     * @return array
     */
    public static function getQuizPayload($quizId)
    {
        $quiz = get_post((int) $quizId);

        if (!$quiz) {
            return ['quiz_id' => (int) $quizId];
        }

        $data = [
            'quiz_id'    => $quiz->ID,
            'quiz_title' => $quiz->post_title,
            'quiz_url'   => get_permalink($quiz->ID),
        ];

        $lessonId = get_post_meta($quiz->ID, '_quiz_lesson', true);

        if ($lessonId) {
            $data += self::getLessonPayload($lessonId);
        }

        return $data;
    }

    /**
     * Courses dropdown. The "Any" option is included only for trigger filtering
     * (when the request carries the `withAny` flag), never for action selects.
     */
    public static function getCourses()
    {
        if (!self::isPluginInstalled()) {
            return self::pluginInactiveResponse();
        }

        return Response::success(self::postOptions('course', __('Any Course', 'bit-pi')));
    }

    /**
     * Lessons dropdown. When a courseId query param is present, lessons are
     * filtered to that course via the `_lesson_course` meta. The "Any" option is
     * included only for trigger filtering (the `withAny` flag).
     */
    public static function getLessons()
    {
        if (!self::isPluginInstalled()) {
            return self::pluginInactiveResponse();
        }

        $courseId = isset($_GET['courseId']) ? sanitize_text_field(wp_unslash($_GET['courseId'])) : '';

        $metaQuery = null;

        if ($courseId && $courseId !== 'any') {
            $metaQuery = [
                'key'     => '_lesson_course',
                'value'   => $courseId,
                'compare' => '=',
            ];
        }

        return Response::success(self::postOptions('lesson', __('Any Lesson', 'bit-pi'), $metaQuery));
    }

    /**
     * Quizzes dropdown. The "Any" option is included only for trigger filtering
     * (the `withAny` flag).
     */
    public static function getQuizzes()
    {
        if (!self::isPluginInstalled()) {
            return self::pluginInactiveResponse();
        }

        return Response::success(self::postOptions('quiz', __('Any Quiz', 'bit-pi')));
    }

    private static function pluginInactiveResponse()
    {
        // translators: %s is the plugin name.
        return Response::error(\sprintf(__('%s is not installed or activated.', 'bit-pi'), 'Sensei LMS'));
    }

    /**
     * Whether the dropdown should prepend an "Any" option. Triggers send the
     * `withAny` flag (to allow matching any resource); actions do not.
     *
     * @return bool
     */
    private static function shouldIncludeAny()
    {
        return isset($_GET['withAny']) && filter_var(wp_unslash($_GET['withAny']), FILTER_VALIDATE_BOOLEAN);
    }

    /**
     * Build a select-options list for a Sensei post type.
     *
     * @param string     $postType
     * @param string     $anyLabel
     * @param null|array $metaQuery
     *
     * @return array
     */
    private static function postOptions($postType, $anyLabel, $metaQuery = null)
    {
        $options = [];

        if (self::shouldIncludeAny()) {
            $options[] = ['label' => $anyLabel, 'value' => 'any'];
        }

        $queryArgs = [
            'post_type'   => $postType,
            'post_status' => 'publish',
            'numberposts' => -1,
        ];

        if ($metaQuery) {
            $queryArgs['meta_query'] = [$metaQuery];
        }

        foreach (get_posts($queryArgs) as $post) {
            $options[] = [
                'label' => $post->post_title,
                'value' => $post->ID,
            ];
        }

        return $options;
    }
}
