<?php

namespace BitApps\PiPro\src\Integrations\SenseiLms;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!defined('ABSPATH')) {
    exit;
}

class SenseiLmsHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'courseEnrolmentStatusChanged' => [
                'hook'          => 'sensei_course_enrolment_status_changed',
                'callback'      => [SenseiLmsTrigger::class, 'courseEnrolmentStatusChanged'],
                'accepted_args' => 3,
            ],
            'learnerManuallyEnrolled' => [
                'hook'          => 'sensei_manual_enrolment_learner_enrolled',
                'callback'      => [SenseiLmsTrigger::class, 'learnerManuallyEnrolled'],
                'accepted_args' => 2,
            ],
            'learnerManuallyWithdrawn' => [
                'hook'          => 'sensei_manual_enrolment_learner_withdrawn',
                'callback'      => [SenseiLmsTrigger::class, 'learnerManuallyWithdrawn'],
                'accepted_args' => 2,
            ],
            'learnerStartedCourse' => [
                'hook'          => 'sensei_user_course_start',
                'callback'      => [SenseiLmsTrigger::class, 'learnerStartedCourse'],
                'accepted_args' => 2,
            ],
            'learnerCompletedCourse' => [
                'hook'          => 'sensei_user_course_end',
                'callback'      => [SenseiLmsTrigger::class, 'learnerCompletedCourse'],
                'accepted_args' => 2,
            ],
            'courseStatusUpdated' => [
                'hook'          => 'sensei_course_status_updated',
                'callback'      => [SenseiLmsTrigger::class, 'courseStatusUpdated'],
                'accepted_args' => 5,
            ],
            'learnerStartedLesson' => [
                'hook'          => 'sensei_user_lesson_start',
                'callback'      => [SenseiLmsTrigger::class, 'learnerStartedLesson'],
                'accepted_args' => 2,
            ],
            'learnerCompletedLesson' => [
                'hook'          => 'sensei_user_lesson_end',
                'callback'      => [SenseiLmsTrigger::class, 'learnerCompletedLesson'],
                'accepted_args' => 2,
            ],
            'lessonStatusUpdated' => [
                'hook'          => 'sensei_lesson_status_updated',
                'callback'      => [SenseiLmsTrigger::class, 'lessonStatusUpdated'],
                'accepted_args' => 4,
            ],
            'learnerSubmittedQuiz' => [
                'hook'          => 'sensei_user_quiz_submitted',
                'callback'      => [SenseiLmsTrigger::class, 'learnerSubmittedQuiz'],
                'accepted_args' => 5,
            ],
            'quizGradedForLearner' => [
                'hook'          => 'sensei_user_quiz_grade',
                'callback'      => [SenseiLmsTrigger::class, 'quizGradedForLearner'],
                'accepted_args' => 5,
            ],
            'learnerResetCourse' => [
                'hook'          => 'sensei_user_course_reset',
                'callback'      => [SenseiLmsTrigger::class, 'learnerResetCourse'],
                'accepted_args' => 2,
            ],
            'learnerResetLesson' => [
                'hook'          => 'sensei_user_lesson_reset',
                'callback'      => [SenseiLmsTrigger::class, 'learnerResetLesson'],
                'accepted_args' => 2,
            ],
            'teacherAssignedToCourse' => [
                'hook'          => 'sensei_course_new_teacher_assigned',
                'callback'      => [SenseiLmsTrigger::class, 'teacherAssignedToCourse'],
                'accepted_args' => 2,
            ],
            'certificateIssued' => [
                'hook'          => 'added_post_meta',
                'callback'      => [SenseiLmsTrigger::class, 'certificateIssued'],
                'accepted_args' => 4,
            ],
        ];
    }
}
