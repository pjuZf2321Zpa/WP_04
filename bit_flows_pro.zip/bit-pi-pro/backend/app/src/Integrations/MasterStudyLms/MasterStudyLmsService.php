<?php

namespace BitApps\PiPro\src\Integrations\MasterStudyLms;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Integrations\IntegrationHelper;

if (!defined('ABSPATH')) {
    exit;
}

final class MasterStudyLmsService
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    /**
     * Enroll user to a course.
     *
     * @return array
     */
    public function enrollUserToCourse()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'course_id'  => ['required', 'integer'],
            'user_email' => ['required', 'email'],
        ];

        $errors = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if ($errors) {
            return $errors;
        }

        $courseId = (int) $fieldMappings['course_id'];
        $email = $fieldMappings['user_email'];
        $userId = email_exists($email);

        if (!$userId) {
            return [
                'response'    => __('User not found with the provided email.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404,
            ];
        }

        if (MasterStudyLmsHelper::isEnrolled($courseId, $userId)) {
            return [
                'response'    => __('User already enrolled in course.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        if (!MasterStudyLmsHelper::enroll($courseId, $email)) {
            return [
                'response'    => __('Failed to enroll user in course.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 500,
            ];
        }

        return [
            'response' => [
                'user_id'   => $userId,
                'course_id' => $courseId,
                'user'      => Utility::getUserInfo($userId),
            ],
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Unenroll user from a course.
     *
     * @return array
     */
    public function unenrollUserFromCourse()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'course_id'  => ['required', 'integer'],
            'user_email' => ['required', 'email'],
        ];

        $errors = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if ($errors) {
            return $errors;
        }

        $courseId = (int) $fieldMappings['course_id'];
        $userId = email_exists($fieldMappings['user_email']);

        if (!$userId) {
            return [
                'response'    => __('User not found with the provided email.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404,
            ];
        }

        if (!MasterStudyLmsHelper::isEnrolled($courseId, $userId)) {
            return [
                'response'    => __('User is not enrolled in course.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        MasterStudyLmsHelper::unenroll($courseId, $userId);

        return [
            'response' => [
                'user_id'   => $userId,
                'course_id' => $courseId,
                'user'      => Utility::getUserInfo($userId),
            ],
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Mark a whole course complete for the user.
     *
     * @return array
     */
    public function markCourseCompleteForUser()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'course_id'  => ['required', 'integer'],
            'user_email' => ['required', 'email'],
        ];

        $errors = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if ($errors) {
            return $errors;
        }

        $courseId = (int) $fieldMappings['course_id'];
        $email = $fieldMappings['user_email'];
        $userId = email_exists($email);

        if (!$userId) {
            return [
                'response'    => __('User not found with the provided email.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404,
            ];
        }

        $materialIds = MasterStudyLmsHelper::getCourseMaterialIds($courseId);

        if (empty($materialIds)) {
            return [
                'response'    => __('Course does not have any lessons or quizzes added.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400,
            ];
        }

        if (
            !MasterStudyLmsHelper::isEnrolled($courseId, $userId)
            && !MasterStudyLmsHelper::enroll($courseId, $email)
        ) {
            return [
                'response'    => __('Failed to enroll user in course.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 500,
            ];
        }

        MasterStudyLmsHelper::completeCourse($courseId, $userId, $materialIds);

        return [
            'response' => [
                'user_id'   => $userId,
                'course_id' => $courseId,
                'user'      => Utility::getUserInfo($userId),
            ],
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }

    /**
     * Mark a lesson complete for the user.
     *
     * @return array
     */
    public function markLessonCompleteForUser()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'course_id'  => ['required', 'integer'],
            'lesson_id'  => ['required', 'integer'],
            'user_email' => ['required', 'email'],
        ];

        $errors = IntegrationHelper::validateFieldMap($fieldMappings, $rules);

        if ($errors) {
            return $errors;
        }

        $courseId = (int) $fieldMappings['course_id'];
        $lessonId = (int) $fieldMappings['lesson_id'];
        $email = $fieldMappings['user_email'];
        $userId = email_exists($email);

        if (!$userId) {
            return [
                'response'    => __('User not found with the provided email.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404,
            ];
        }

        if (!MasterStudyLmsHelper::courseHasMaterial($courseId, $lessonId)) {
            return [
                'response'    => __('Lesson not found in the selected course.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 404,
            ];
        }

        if (
            !MasterStudyLmsHelper::isEnrolled($courseId, $userId)
            && !MasterStudyLmsHelper::enroll($courseId, $email)
        ) {
            return [
                'response'    => __('Failed to enroll user in course.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 500,
            ];
        }

        MasterStudyLmsHelper::completeMaterial($courseId, $userId, $lessonId);

        return [
            'response' => [
                'user_id'   => $userId,
                'course_id' => $courseId,
                'user'      => Utility::getUserInfo($userId),
            ],
            'payload'     => $fieldMappings,
            'status_code' => 200,
        ];
    }
}
