<?php

namespace BitApps\PiPro\src\Integrations\MasterStudyLms;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\Pi\src\Interfaces\ActionInterface;

if (!defined('ABSPATH')) {
    exit;
}

class MasterStudyLmsAction implements ActionInterface
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeMasterStudyLmsAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'] ?? 200,
            $executedNodeAction['payload'] ?? [],
            $executedNodeAction['response'] ?? []
        );
    }

    private function executeMasterStudyLmsAction()
    {
        if (!defined('STM_LMS_VERSION') || !class_exists('MasterStudy\Lms\Repositories\StudentsRepository')) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('MasterStudy LMS plugin is not active or its version is unsupported.', 'bit-pi'),
            ];
        }

        $machineSlug = $this->nodeInfoProvider->getMachineSlug();
        $serviceInstance = IntegrationHelper::getServiceInstanceByMachineSlug($machineSlug, $this->nodeInfoProvider, true);

        if (empty($serviceInstance)) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('MasterStudy LMS service not found.', 'bit-pi'),
            ];
        }

        return $serviceInstance->{$machineSlug}();
    }
}
