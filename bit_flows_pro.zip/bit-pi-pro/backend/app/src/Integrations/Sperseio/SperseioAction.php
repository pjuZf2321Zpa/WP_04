<?php

namespace BitApps\PiPro\src\Integrations\Sperseio;

// Prevent direct script access
if (!\defined('ABSPATH')) {
    exit;
}


use BitApps\Pi\src\Integrations\ApiRequest\ApiRequestAction;

class SperseioAction extends ApiRequestAction
{
    // extends ApiRequestAction
}
