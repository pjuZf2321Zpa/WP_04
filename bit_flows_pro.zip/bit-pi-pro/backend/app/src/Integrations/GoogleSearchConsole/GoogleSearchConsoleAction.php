<?php

namespace BitApps\PiPro\src\Integrations\GoogleSearchConsole;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\Pi\src\Interfaces\ActionInterface;

if (!defined('ABSPATH')) {
    exit;
}

class GoogleSearchConsoleAction implements ActionInterface
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeGoogleSearchConsoleAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'] ?? 200,
            $executedNodeAction['payload'] ?? [],
            $executedNodeAction['response'] ?? []
        );
    }

    private function executeGoogleSearchConsoleAction()
    {
        $machineSlug = $this->nodeInfoProvider->getMachineSlug();
        $serviceInstance = IntegrationHelper::getServiceInstanceByMachineSlug($machineSlug, $this->nodeInfoProvider, true);

        if (!$serviceInstance) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('Google Search Console service not found.', 'bit-pi'),
            ];
        }

        return $serviceInstance->{$machineSlug}();
    }
}
