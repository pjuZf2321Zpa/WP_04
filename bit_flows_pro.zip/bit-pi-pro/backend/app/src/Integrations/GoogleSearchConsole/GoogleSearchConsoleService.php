<?php

namespace BitApps\PiPro\src\Integrations\GoogleSearchConsole;

use BitApps\Pi\src\Authorization\AuthorizationFactory;
use BitApps\Pi\src\Authorization\AuthorizationType;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Client\HttpClient;
use DateTime;
use DateTimeZone;
use Exception;

if (!defined('ABSPATH')) {
    exit;
}

final class GoogleSearchConsoleService
{
    public const BASE_URL = 'https://searchconsole.googleapis.com';

    public const REFRESH_TOKEN_URL = 'https://oauth2.googleapis.com/token';

    private const WEBMASTERS_PATH = '/webmasters/v3/sites';

    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function listSites()
    {
        return $this->send('GET', self::WEBMASTERS_PATH);
    }

    public function getSite()
    {
        $siteUrl = $this->config('site-url');

        $validationRules = ['site_url' => ['required']];
        $validationErrors = IntegrationHelper::validateFieldMap(['site_url' => $siteUrl], $validationRules);
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        return $this->send('GET', $this->sitePath($siteUrl));
    }

    public function addSite()
    {
        $data = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = ['siteUrl' => ['required']];
        $validationErrors = IntegrationHelper::validateFieldMap($data, $validationRules);
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        return $this->send('PUT', $this->sitePath($data['siteUrl']), null, [], ['siteUrl' => $data['siteUrl']]);
    }

    public function deleteSite()
    {
        $siteUrl = $this->config('site-url');

        $validationRules = ['site_url' => ['required']];
        $validationErrors = IntegrationHelper::validateFieldMap(['site_url' => $siteUrl], $validationRules);
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        return $this->send('DELETE', $this->sitePath($siteUrl), null, [], ['siteUrl' => $siteUrl]);
    }

    public function listSitemaps()
    {
        $siteUrl = $this->config('site-url');
        $data = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = ['site_url' => ['required']];
        $validationErrors = IntegrationHelper::validateFieldMap(['site_url' => $siteUrl], $validationRules);
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $query = [];
        if (!empty($data['sitemapIndex'])) {
            $query['sitemapIndex'] = $data['sitemapIndex'];
        }

        return $this->send('GET', $this->sitePath($siteUrl) . '/sitemaps', null, $query, ['siteUrl' => $siteUrl]);
    }

    public function getSitemap()
    {
        $siteUrl = $this->config('site-url');
        $feedpath = $this->config('feedpath');

        $validationRules = ['site_url' => ['required'], 'feedpath' => ['required']];
        $validationErrors = IntegrationHelper::validateFieldMap(['site_url' => $siteUrl, 'feedpath' => $feedpath], $validationRules);
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        return $this->send('GET', $this->sitemapPath($siteUrl, $feedpath), null, [], ['siteUrl' => $siteUrl, 'feedpath' => $feedpath]);
    }

    public function submitSitemap()
    {
        $siteUrl = $this->config('site-url');
        $data = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = ['site_url' => ['required'], 'feedpath' => ['required', 'url']];
        $validationErrors = IntegrationHelper::validateFieldMap(
            ['site_url' => $siteUrl, 'feedpath' => $data['feedpath'] ?? null],
            $validationRules
        );
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        return $this->send('PUT', $this->sitemapPath($siteUrl, $data['feedpath']), null, [], ['siteUrl' => $siteUrl, 'feedpath' => $data['feedpath']]);
    }

    public function deleteSitemap()
    {
        $siteUrl = $this->config('site-url');
        $feedpath = $this->config('feedpath');

        $validationRules = ['site_url' => ['required'], 'feedpath' => ['required']];
        $validationErrors = IntegrationHelper::validateFieldMap(['site_url' => $siteUrl, 'feedpath' => $feedpath], $validationRules);
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        return $this->send('DELETE', $this->sitemapPath($siteUrl, $feedpath), null, [], ['siteUrl' => $siteUrl, 'feedpath' => $feedpath]);
    }

    public function querySearchAnalytics()
    {
        $siteUrl = $this->config('site-url');
        $data = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = ['site_url' => ['required'], 'startDate' => ['required'], 'endDate' => ['required']];
        $validationErrors = IntegrationHelper::validateFieldMap(
            ['site_url' => $siteUrl, 'startDate' => $data['startDate'] ?? null, 'endDate' => $data['endDate'] ?? null],
            $validationRules
        );
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $startDate = $this->toApiDate($data['startDate']);
        $endDate = $this->toApiDate($data['endDate']);

        if ($startDate === null || $endDate === null) {
            return [
                'status_code' => 400,
                'payload'     => $data,
                'response'    => __('Start date and end date must be valid dates (YYYY-MM-DD or a relative expression such as "-28 days").', 'bit-pi'),
            ];
        }

        if ($startDate > $endDate) {
            return [
                'status_code' => 400,
                'payload'     => $data,
                'response'    => __('Start date must not be later than end date.', 'bit-pi'),
            ];
        }

        $body = ['startDate' => $startDate, 'endDate' => $endDate];

        $dimensions = $this->toList($this->config('dimensions'));
        if (!empty($dimensions)) {
            $body['dimensions'] = $dimensions;
        }

        foreach (['search-type' => 'type', 'aggregation-type' => 'aggregationType', 'data-state' => 'dataState'] as $configId => $bodyKey) {
            $value = $this->config($configId);
            if (!empty($value)) {
                $body[$bodyKey] = $value;
            }
        }

        foreach (['rowLimit', 'startRow'] as $numericKey) {
            if (isset($data[$numericKey]) && is_numeric($data[$numericKey])) {
                $body[$numericKey] = (int) $data[$numericKey];
            }
        }

        $filters = $this->filters();
        if (!empty($filters)) {
            $body['dimensionFilterGroups'] = [['groupType' => 'and', 'filters' => $filters]];
        }

        return $this->send('POST', $this->sitePath($siteUrl) . '/searchAnalytics/query', $body);
    }

    public function inspectUrl()
    {
        $siteUrl = $this->config('site-url');
        $data = $this->nodeInfoProvider->getFieldMapData();

        $validationRules = ['site_url' => ['required'], 'inspectionUrl' => ['required', 'url']];
        $validationErrors = IntegrationHelper::validateFieldMap(
            ['site_url' => $siteUrl, 'inspectionUrl' => $data['inspectionUrl'] ?? null],
            $validationRules
        );
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $body = [
            'siteUrl'       => $siteUrl,
            'inspectionUrl' => $data['inspectionUrl'],
        ];

        if (!empty($data['languageCode'])) {
            $body['languageCode'] = $data['languageCode'];
        }

        return $this->send('POST', '/v1/urlInspection/index:inspect', $body);
    }

    private function filters()
    {
        $rows = $this->nodeInfoProvider->getFieldMapRepeaters('filters.value', false, false);

        $filters = [];
        foreach ((array) $rows as $row) {
            if (empty($row['dimension']) || !isset($row['expression']) || $row['expression'] === '') {
                continue;
            }

            $filters[] = [
                'dimension'  => $row['dimension'],
                'operator'   => empty($row['operator']) ? 'equals' : $row['operator'],
                'expression' => $row['expression'],
            ];
        }

        return $filters;
    }

    private function toList($value)
    {
        if (\is_string($value)) {
            $value = explode(',', $value);
        }

        if (!\is_array($value)) {
            return [];
        }

        return array_values(array_filter(array_map('trim', $value), 'strlen'));
    }

    // Search Console reports in Pacific Time, so relative dates resolve there.
    private function toApiDate($value)
    {
        if (!\is_string($value) && !is_numeric($value)) {
            return;
        }

        try {
            return (new DateTime(trim((string) $value), new DateTimeZone('America/Los_Angeles')))->format('Y-m-d');
        } catch (Exception $exception) {
            return;
        }
    }

    private function sitePath($siteUrl)
    {
        return self::WEBMASTERS_PATH . '/' . rawurlencode((string) $siteUrl);
    }

    private function sitemapPath($siteUrl, $feedpath)
    {
        return $this->sitePath($siteUrl) . '/sitemaps/' . rawurlencode((string) $feedpath);
    }

    private function config($id)
    {
        return $this->nodeInfoProvider->getFieldMapConfigs($id . '.value');
    }

    private function send($method, $path, $body = null, array $query = [], array $payload = [])
    {
        $connectionId = $this->nodeInfoProvider->getFieldMapConfigs('connection-id.value');

        $accessToken = AuthorizationFactory::getAuthorizationHandler(
            AuthorizationType::OAUTH2,
            $connectionId
        )->setRefreshTokenUrl(self::REFRESH_TOKEN_URL)->getAccessToken();

        $payload = $body ?? ($payload ?: $query);

        if (\is_array($accessToken) && isset($accessToken['error'])) {
            return ['status_code' => 401, 'payload' => $payload, 'response' => $accessToken];
        }

        $url = self::BASE_URL . $path;
        if (!empty($query)) {
            $url .= '?' . http_build_query($query);
        }

        $headers = [
            'Accept'        => 'application/json',
            'Authorization' => $accessToken,
            'Content-Type'  => 'application/json',
        ];

        if ($method === 'PUT' && $body === null) {
            $headers['Content-Length'] = '0';
        }

        $http = new HttpClient();
        $requestBody = $body === null ? [] : JSON::encode($body);
        $response = $http->request($url, $method, $requestBody, $headers);
        $statusCode = $http->getResponseCode();

        if ($response === '' && $statusCode >= 200 && $statusCode < 300) {
            $response = ['success' => true];
        }

        return [
            'status_code' => $statusCode,
            'payload'     => $payload,
            'response'    => $response,
        ];
    }
}
