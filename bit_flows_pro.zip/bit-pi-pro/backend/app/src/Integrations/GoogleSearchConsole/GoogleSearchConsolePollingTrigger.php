<?php

namespace BitApps\PiPro\src\Integrations\GoogleSearchConsole;

use BitApps\Pi\src\Abstracts\AbstractPollingTrigger;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\PiPro\Deps\BitApps\WPKit\Helpers\JSON;

if (!defined('ABSPATH')) {
    exit;
}

class GoogleSearchConsolePollingTrigger extends AbstractPollingTrigger
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function poll(): array
    {
        $service = new GoogleSearchConsoleService($this->nodeInfoProvider);
        $isSiteFeed = $this->nodeInfoProvider->getMachineSlug() === 'newSite';

        $result = $isSiteFeed ? $service->listSites() : $service->listSitemaps();
        $listKey = $isSiteFeed ? 'siteEntry' : 'sitemap';

        $statusCode = $result['status_code'] ?? 500;
        if ($statusCode < 200 || $statusCode >= 300) {
            return ['status' => 'error', 'output' => $result['response'] ?? [], 'input' => $result['payload'] ?? []];
        }

        $response = JSON::decode(JSON::encode($result['response'] ?? []), true) ?? [];

        return [
            'status' => 'success',
            'output' => $response[$listKey] ?? [],
            'input'  => $result['payload'] ?? [],
        ];
    }

    public function getUniquePollingFieldName(): string
    {
        return $this->nodeInfoProvider->getMachineSlug() === 'newSite' ? 'siteUrl' : 'path';
    }

    public function getPollingType(): string
    {
        return $this->nodeInfoProvider->getMachineSlug() === 'sitemapStatusChanged' ? self::TYPE_UPDATED : self::TYPE_NEW;
    }
}
