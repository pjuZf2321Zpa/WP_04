<?php

namespace BitApps\PiPro\src\Integrations\WpAllImport;

use BitApps\Pi\src\Integrations\HookRegisterInterface;

if (!\defined('ABSPATH')) {
    exit;
}

class WpAllImportHooks implements HookRegisterInterface
{
    public function register(): array
    {
        return [
            'importCompleted' => [
                'hook'          => 'pmxi_after_xml_import',
                'callback'      => [WpAllImportTrigger::class, 'importCompleted'],
                'accepted_args' => 2,
            ],
            'importFailed' => [
                'hook'          => 'pmxi_after_xml_import',
                'callback'      => [WpAllImportTrigger::class, 'importFailed'],
                'accepted_args' => 2,
            ],
            'postTypeImported' => [
                'hook'          => 'pmxi_saved_post',
                'callback'      => [WpAllImportTrigger::class, 'postTypeImported'],
                'accepted_args' => 3,
            ],
        ];
    }
}
