<?php

namespace BitApps\PiPro\src\Integrations\WpAllImport;

use BitApps\Pi\Services\FlowService;
use BitApps\Pi\src\Integrations\IntegrationHelper;

if (!defined('ABSPATH')) {
    exit;
}

class WpAllImportTrigger
{
    public static function importCompleted($importId, $importData)
    {
        if (
            empty($importId)
             || !\is_object($importData)
             || (isset($importData->failed) && (int) $importData->failed !== 0)
        ) {
            return;
        }

        $data = [
            'import_id' => $importId,
            'import'    => $importData,
        ];

        self::execute(__FUNCTION__, $data);
    }

    public static function importFailed($importId, $importData)
    {
        if (
            empty($importId)
             || !\is_object($importData)
             || (isset($importData->failed) && (int) $importData->failed === 0)
        ) {
            return;
        }

        $data = [
            'import_id' => $importId,
            'import'    => $importData,
        ];

        self::execute(__FUNCTION__, $data);
    }

    public static function postTypeImported($postId, $xmlNode, $isUpdate)
    {
        if (empty($postId)) {
            return;
        }

        $post = get_post($postId);

        if (!$post) {
            return;
        }

        $data = [
            'post_id'   => $postId,
            'post'      => $post,
            'xml_node'  => $xmlNode,
            'is_update' => $isUpdate,
        ];

        self::execute(__FUNCTION__, $data);
    }

    private static function execute($machineSlug, $data)
    {
        $flows = FlowService::exists('wpAllImport', $machineSlug);
        if (!$flows) {
            return;
        }

        IntegrationHelper::handleFlowForForm($flows, $data);
    }
}
