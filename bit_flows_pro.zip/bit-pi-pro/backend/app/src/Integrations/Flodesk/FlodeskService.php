<?php

namespace BitApps\PiPro\src\Integrations\Flodesk;

use BitApps\Pi\Config;
use BitApps\Pi\src\Authorization\AuthorizationFactory;
use BitApps\Pi\src\Authorization\AuthorizationType;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Integrations\IntegrationHelper;
use BitApps\PiPro\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\Client\HttpClient;

if (!defined('ABSPATH')) {
    exit;
}

final class FlodeskService
{
    public const BASE_URL = 'https://api.flodesk.com/v1';

    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function createOrUpdateSubscriber()
    {
        $payload = $this->buildSubscriberPayload();

        $validationRules = ['email' => ['required', 'email']];
        $validationErrors = IntegrationHelper::validateFieldMap($payload, $validationRules);
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        return $this->send('POST', '/subscribers', $payload);
    }

    public function getSubscriber()
    {
        $subscriberId = $this->config('subscriber-id');

        $validationRules = ['subscriber_id' => ['required']];
        $validationErrors = IntegrationHelper::validateFieldMap(['subscriber_id' => $subscriberId], $validationRules);
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        return $this->send('GET', '/subscribers/' . $this->encodeIdentifier($subscriberId));
    }

    public function listSubscribers()
    {
        $data = $this->nodeInfoProvider->getFieldMapData();

        return $this->send(
            'GET',
            '/subscribers',
            null,
            [
                'status'     => $this->config('status'),
                'segment_id' => $this->config('segment-id'),
                'page'       => $data['page'] ?? null,
                'per_page'   => $data['perPage'] ?? null,
            ]
        );
    }

    public function unsubscribeSubscriber()
    {
        $subscriberId = $this->config('subscriber-id');

        $validationRules = ['subscriber_id' => ['required']];
        $validationErrors = IntegrationHelper::validateFieldMap(['subscriber_id' => $subscriberId], $validationRules);
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        return $this->send('POST', '/subscribers/' . $this->encodeIdentifier($subscriberId) . '/unsubscribe');
    }

    public function addSubscriberToSegments()
    {
        return $this->changeSubscriberSegments('POST');
    }

    public function removeSubscriberFromSegments()
    {
        return $this->changeSubscriberSegments('DELETE');
    }

    public function createSegment()
    {
        $data = $this->nodeInfoProvider->getFieldMapData();

        $payload = [
            'name'  => $data['name'] ?? null,
            'color' => $this->config('color-id'),
        ];

        $validationRules = [
            'name'  => ['required', 'string'],
            'color' => ['required', 'string'],
        ];
        $validationErrors = IntegrationHelper::validateFieldMap($payload, $validationRules);
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        return $this->send('POST', '/segments', $payload);
    }

    public function listSegments()
    {
        $data = $this->nodeInfoProvider->getFieldMapData();

        return $this->send(
            'GET',
            '/segments',
            null,
            [
                'page'     => $data['page'] ?? null,
                'per_page' => $data['perPage'] ?? null,
            ]
        );
    }

    public function getSegment()
    {
        $segmentId = $this->config('segment-id');

        $validationRules = ['segment_id' => ['required']];
        $validationErrors = IntegrationHelper::validateFieldMap(['segment_id' => $segmentId], $validationRules);
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        return $this->send('GET', '/segments/' . rawurlencode((string) $segmentId));
    }

    public function listSegmentColors()
    {
        return $this->send('GET', '/segments/colors');
    }

    public function createCustomField()
    {
        $data = $this->nodeInfoProvider->getFieldMapData();

        $payload = ['label' => $data['label'] ?? null];

        $validationRules = ['label' => ['required', 'string']];
        $validationErrors = IntegrationHelper::validateFieldMap($payload, $validationRules);
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        return $this->send('POST', '/custom-fields', $payload);
    }

    public function listCustomFields()
    {
        return $this->send('GET', '/custom-fields/all');
    }

    public function listWorkflows()
    {
        $data = $this->nodeInfoProvider->getFieldMapData();

        return $this->send(
            'GET',
            '/workflows',
            null,
            [
                'statuses' => $this->config('status'),
                'page'     => $data['page'] ?? null,
                'perPage'  => $data['perPage'] ?? null,
            ]
        );
    }

    public function addSubscriberToWorkflow()
    {
        $workflowId = $this->config('workflow-id');
        $subscriberId = $this->config('subscriber-id');

        $validationRules = [
            'workflow_id'   => ['required'],
            'subscriber_id' => ['required'],
        ];
        $validationErrors = IntegrationHelper::validateFieldMap(
            ['subscriber_id' => $subscriberId, 'workflow_id' => $workflowId],
            $validationRules
        );
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        return $this->send(
            'POST',
            '/workflows/' . rawurlencode((string) $workflowId) . '/subscribers',
            $this->buildSubscriberReference($subscriberId)
        );
    }

    public function removeSubscriberFromWorkflow()
    {
        $workflowId = $this->config('workflow-id');
        $subscriberId = $this->config('subscriber-id');

        $validationRules = [
            'workflow_id'   => ['required'],
            'subscriber_id' => ['required'],
        ];
        $validationErrors = IntegrationHelper::validateFieldMap(
            ['subscriber_id' => $subscriberId, 'workflow_id' => $workflowId],
            $validationRules
        );
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        return $this->send(
            'DELETE',
            '/workflows/' . rawurlencode((string) $workflowId)
                . '/subscribers/' . $this->encodeIdentifier($subscriberId)
        );
    }

    private function changeSubscriberSegments($method)
    {
        $subscriberId = $this->config('subscriber-id');
        $segmentIds = array_values((array) ($this->config('segment-ids') ?: []));

        $validationRules = [
            'segment_ids'   => ['required', 'array'],
            'subscriber_id' => ['required'],
        ];
        $validationErrors = IntegrationHelper::validateFieldMap(
            ['segment_ids' => $segmentIds, 'subscriber_id' => $subscriberId],
            $validationRules
        );
        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        return $this->send(
            $method,
            '/subscribers/' . $this->encodeIdentifier($subscriberId) . '/segments',
            ['segment_ids' => $segmentIds]
        );
    }

    private function buildSubscriberPayload(): array
    {
        $data = $this->nodeInfoProvider->getFieldMapData();

        $payload = [];

        foreach (['email' => 'email', 'first_name' => 'firstName', 'last_name' => 'lastName'] as $key => $path) {
            if (isset($data[$path]) && $data[$path] !== '') {
                $payload[$key] = $data[$path];
            }
        }

        $customFields = (array) $this->nodeInfoProvider->getFieldMapRepeaters(
            'subscriber-field-row.value',
            false,
            true,
            'subscriberField',
            'value'
        );

        if ($customFields !== []) {
            $payload['custom_fields'] = (object) $customFields;
        }

        $segmentIds = $this->config('segment-ids');

        if (!empty($segmentIds)) {
            $payload['segment_ids'] = array_values((array) $segmentIds);
        }

        $doubleOptin = $this->config('double-optin');

        if ($doubleOptin !== null && $doubleOptin !== '') {
            $payload['double_optin'] = filter_var($doubleOptin, FILTER_VALIDATE_BOOLEAN);
        }

        return $payload;
    }

    private function encodeIdentifier($identifier): string
    {
        return str_replace('%40', '@', rawurlencode((string) $identifier));
    }

    private function buildSubscriberReference($subscriberId): array
    {
        if (\is_string($subscriberId) && strpos($subscriberId, '@') !== false) {
            return ['email' => $subscriberId];
        }

        return ['id' => $subscriberId];
    }

    private function config($id)
    {
        return $this->nodeInfoProvider->getFieldMapConfigs($id . '.value');
    }

    private function send($method, $path, $body = null, array $query = [])
    {
        $connectionId = $this->nodeInfoProvider->getFieldMapConfigs('connection-id.value');

        $basicAuthToken = AuthorizationFactory::getAuthorizationHandler(
            AuthorizationType::BASIC_AUTH,
            $connectionId
        )->getAccessToken();

        if (\is_array($basicAuthToken) && isset($basicAuthToken['error'])) {
            return [
                'status_code' => 401,
                'payload'     => $body ?? $query,
                'response'    => $basicAuthToken,
            ];
        }

        if (empty($basicAuthToken)) {
            return [
                'status_code' => 401,
                'payload'     => $body ?? $query,
                'response'    => __('Flodesk connection is not authorized.', 'bit-pi'),
            ];
        }

        $url = self::BASE_URL . $path . $this->buildQuery($query);

        $headers = [
            'Authorization' => $basicAuthToken,
            'Content-Type'  => 'application/json',
            'User-Agent'    => get_bloginfo('name') . ' (' . Config::get('SITE_URL') . ')',
        ];

        $http = new HttpClient();
        $requestBody = $body === null ? null : JSON::encode($body);
        $response = $http->request($url, $method, $requestBody, $headers);

        return [
            'status_code' => $http->getResponseCode(),
            'payload'     => $body ?? $query,
            'response'    => $response,
        ];
    }

    private function buildQuery(array $query)
    {
        $filtered = array_filter(
            $query,
            static fn ($value) => $value !== null && $value !== '' && $value !== []
        );

        if ($filtered === []) {
            return '';
        }

        return '?' . http_build_query($filtered);
    }
}
