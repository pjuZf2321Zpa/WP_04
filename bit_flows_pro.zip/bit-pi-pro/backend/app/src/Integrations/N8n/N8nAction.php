<?php

namespace BitApps\PiPro\src\Integrations\N8n;

// Prevent direct script access
if (!\defined('ABSPATH')) {
    exit;
}


use BitApps\Pi\src\Integrations\ApiRequest\ApiRequestAction;

class N8nAction extends ApiRequestAction
{
    // extends ApiRequestAction
}
