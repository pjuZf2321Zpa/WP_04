<?php

namespace BitApps\PiPro\src\Integrations\MyCred;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Interfaces\ActionInterface;
use BitApps\PiPro\src\Integrations\MyCred\helper\MyCredHelper;

if (!\defined('ABSPATH')) {
    exit;
}

class MyCredAction implements ActionInterface
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    public function execute(): array
    {
        $executedNodeAction = $this->executeMyCredAction();

        return Utility::formatResponseData(
            $executedNodeAction['status_code'] ?? 200,
            $executedNodeAction['payload'] ?? [],
            $executedNodeAction['response'] ?? []
        );
    }

    private function executeMyCredAction()
    {
        if (!MyCredHelper::isPluginInstalled()) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('myCred plugin is not active.', 'bit-pi'),
            ];
        }

        $myCredServices = new MyCredServices($this->nodeInfoProvider);

        $machineSlug = $this->nodeInfoProvider->getMachineSlug();

        if (!method_exists($myCredServices, $machineSlug)) {
            return [
                'status_code' => 400,
                'payload'     => [],
                'response'    => __('myCred action not found.', 'bit-pi'),
            ];
        }

        return $myCredServices->{$machineSlug}();
    }
}
