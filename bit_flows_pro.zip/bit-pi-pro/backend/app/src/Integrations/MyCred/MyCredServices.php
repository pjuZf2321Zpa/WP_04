<?php

namespace BitApps\PiPro\src\Integrations\MyCred;

use BitApps\Pi\Helpers\Utility;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\PiPro\src\Integrations\MyCred\helper\MyCredHelper;

if (!\defined('ABSPATH')) {
    exit;
}

final class MyCredServices
{
    private $nodeInfoProvider;

    public function __construct(NodeInfoProvider $nodeInfoProvider)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
    }

    /**
     * Award Points to User.
     *
     * @return array
     */
    public function awardPoints()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'user_id' => ['required', 'integer'],
            'points'  => ['required', 'integer']
        ];

        $validationErrors = MyCredHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $userId = $fieldMappings['user_id'];
        $points = $fieldMappings['points'];
        $pointType = $fieldMappings['point_type'] ?? '';
        $description = $fieldMappings['description'] ?? __('Awarded by Bit Flows', 'bit-pi');

        if (!\function_exists('mycred_add')) {
            return [
                'response'    => __('myCred function mycred_add not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400
            ];
        }

        mycred_add('Points', absint($userId), $points, $description, '', '', $pointType);

        $response = [
            'points'      => $points,
            'point_type'  => $pointType,
            'description' => $description,
            'user'        => Utility::getUserInfo($userId),
        ];

        return [
            'response'    => $response,
            'payload'     => $fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Revoke Points from User.
     *
     * @return array
     */
    public function revokePoints()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'user_id' => ['required', 'integer'],
            'points'  => ['required', 'integer']
        ];

        $validationErrors = MyCredHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }


        $userId = $fieldMappings['user_id'];
        $points = $fieldMappings['points'];
        $pointType = $fieldMappings['point_type'] ?? '';
        $description = $fieldMappings['description'] ?? __('Revoked by Bit Flows', 'bit-pi');

        if (!\function_exists('mycred_subtract') || !\function_exists('mycred_get_types')) {
            return [
                'response'    => __('myCred functions not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400
            ];
        }

        // If point_type is -1, revoke from all point types
        if ($pointType == '-1') {
            $pointTypes = mycred_get_types();

            if (\is_array($pointTypes)) {
                foreach ($pointTypes as $key => $value) {
                    mycred_subtract($value, absint($userId), absint(-$points), $description, '', '', $key);
                }
            }
        } else {
            mycred_subtract('Points', absint($userId), absint(-$points), $description, '', '', $pointType);
        }

        $response = [
            'points'      => $points,
            'point_type'  => $pointType,
            'description' => $description,
            'user'        => Utility::getUserInfo($userId),
        ];

        return [
            'response'    => $response,
            'payload'     => $fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Award Badge to User.
     *
     * @return array
     */
    public function awardBadge()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'user_id'  => ['required', 'integer'],
            'badge_id' => ['required', 'integer']
        ];

        $validationErrors = MyCredHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $userId = $fieldMappings['user_id'];
        $badgeId = $fieldMappings['badge_id'];

        if (!\function_exists('mycred_get_badge') || !\function_exists('mycred_assign_badge_to_user')) {
            return [
                'response'    => __('myCred badge functions not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400
            ];
        }

        $badge = mycred_get_badge($badgeId);

        if (!$badge) {
            return [
                'response'    => __('Badge not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400
            ];
        }

        mycred_assign_badge_to_user($userId, $badgeId);

        $response = [
            'badge_id' => $badgeId,
            'badge'    => $badge,
            'user'     => Utility::getUserInfo($userId),
        ];

        return [
            'response'    => $response,
            'payload'     => $fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Revoke Badge from User.
     *
     * @return array
     */
    public function revokeBadge()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'user_id'  => ['required', 'integer'],
            'badge_id' => ['required', 'integer']
        ];

        $validationErrors = MyCredHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $userId = $fieldMappings['user_id'];
        $badgeId = $fieldMappings['badge_id'];

        if (!\function_exists('mycred_get_users_badges') || !\function_exists('mycred_delete_user_meta')) {
            return [
                'response'    => __('myCred badge functions not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400
            ];
        }

        $badges = mycred_get_users_badges(absint($userId));

        if (empty($badges) || !\is_array($badges)) {
            return [
                'response'    => __('The user does not have badges.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400
            ];
        }

        $badgeFound = false;
        foreach ($badges as $key => $value) {
            if ($badgeId == $key) {
                $metaKey = 'mycred_badge' . $key;

                mycred_delete_user_meta(absint($userId), $metaKey);

                $badgeFound = true;

                break;
            }
        }

        if (!$badgeFound) {
            return [
                'response'    => __('The user does not have the selected badge.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400
            ];
        }

        return [
            'response'    => __('Badge revoked successfully.', 'bit-pi'),
            'payload'     => $fieldMappings,
            'status_code' => 200
        ];
    }

    /**
     * Award Rank to User.
     *
     * @return array
     */
    public function awardRank()
    {
        $fieldMappings = $this->nodeInfoProvider->getFieldMapData();

        $rules = [
            'user_id' => ['required', 'integer'],
            'rank_id' => ['required', 'integer']
        ];

        $validationErrors = MyCredHelper::validateFieldMap($fieldMappings, $rules);

        if (!empty($validationErrors)) {
            return $validationErrors;
        }

        $userId = $fieldMappings['user_id'];
        $rankId = $fieldMappings['rank_id'];

        if (!\function_exists('mycred_get_rank') || !\function_exists('mycred_save_users_rank')) {
            return [
                'response'    => __('myCred rank functions not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400
            ];
        }

        $rankDetail = mycred_get_rank($rankId);

        if (!$rankDetail) {
            return [
                'response'    => __('Rank not found.', 'bit-pi'),
                'payload'     => $fieldMappings,
                'status_code' => 400
            ];
        }

        $pointTypeId = $rankDetail->point_type->cred_id ?? '';

        mycred_save_users_rank($userId, $rankId, $pointTypeId);

        $response = [
            'rank_id'      => $rankId,
            'rank_details' => $rankDetail,
            'user'         => Utility::getUserInfo($userId),
        ];

        return [
            'response'    => $response,
            'payload'     => $fieldMappings,
            'status_code' => 200
        ];
    }
}
