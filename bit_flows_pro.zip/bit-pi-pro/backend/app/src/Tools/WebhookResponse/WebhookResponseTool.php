<?php

namespace BitApps\PiPro\src\Tools\WebhookResponse;

// Prevent direct script access
if (!defined('ABSPATH')) {
    exit;
}

use BitApps\Pi\Helpers\MixInputHandler;
use BitApps\Pi\Model\FlowLog;
use BitApps\Pi\src\DTO\FlowToolResponseDTO;
use BitApps\Pi\src\Flow\GlobalNodeVariables;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Tools\FlowToolsFactory;
use BitApps\PiPro\Deps\BitApps\WPKit\Helpers\JSON;
use BitApps\PiPro\src\Flow\WebhookResponseState;

/**
 * Answers the webhook caller with a status, body and headers of the flow's choosing.
 *
 * A webhook normally gets back "Accepted" the moment the flow is queued. When a
 * flow holds this node the run happens inside the webhook request instead, so
 * whatever the flow works out can be handed back to whoever called it. The flow
 * carries on afterwards — the response is only the reply, not the end.
 *
 * The node answers as text, JSON, HTML or XML — each carrying its own
 * Content-Type unless the flow sets one — or as a redirect, which turns the
 * reply into a Location header for the caller's browser to follow.
 */
class WebhookResponseTool
{
    /**
     * Returned when the node is configured with no status of its own.
     *
     * @var int
     */
    private const DEFAULT_STATUS_CODE = 200;

    /**
     * Sent when a redirect is asked for with a status outside the 3xx range.
     *
     * @var int
     */
    private const DEFAULT_REDIRECT_STATUS_CODE = 302;

    /**
     * A header name as HTTP defines it: a token, per RFC 7230 section 3.2.6.
     *
     * @var string
     */
    private const HEADER_NAME_PATTERN = '/^[A-Za-z0-9!#$%&\'*+.^_`|~-]+$/';

    /**
     * The Content-Type each response shape carries when the flow sets none.
     *
     * @var array<string, string>
     */
    private const CONTENT_TYPES = [
        'text' => 'text/plain; charset=utf-8',
        'json' => 'application/json; charset=utf-8',
        'html' => 'text/html; charset=utf-8',
        'xml'  => 'application/xml; charset=utf-8',
    ];

    protected $nodeInfoProvider;

    private $flowHistoryId;

    public function __construct(NodeInfoProvider $nodeInfoProvider, $flowHistory)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
        $this->flowHistoryId = $flowHistory;
    }

    public function execute()
    {
        $flowId = $this->nodeInfoProvider->getFlowId();

        $nodeId = $this->nodeInfoProvider->getNodeId();

        $config = $this->nodeInfoProvider->getData()[WebhookResponseState::MACHINE_SLUG] ?? [];

        $config = \is_array($config) ? $config : [];

        $responseType = $config['responseType'] ?? 'text';

        if ($responseType !== 'redirect' && !isset(self::CONTENT_TYPES[$responseType])) {
            $responseType = 'text';
        }

        $statusCode = $this->resolveStatusCode($config['statusCode'] ?? null);

        $headers = $this->resolveHeaders($config['headers'] ?? []);

        $details = [
            'app_slug'     => FlowToolsFactory::APP_SLUG,
            'machine_slug' => WebhookResponseState::MACHINE_SLUG,
        ];

        if ($responseType === 'redirect') {
            // Only http and https. esc_url_raw() alone would also pass mailto:,
            // tel:, ftp: and everything else in wp_allowed_protocols(), which the
            // error message below promises it does not.
            $location = esc_url_raw($this->resolveToString($config['redirectUrl'] ?? ''), ['http', 'https']);

            if ($location === '') {
                $errorMessage = 'Redirect needs a valid http or https URL';

                return FlowToolResponseDTO::create(
                    FlowLog::STATUS['ERROR'],
                    $config,
                    ['error' => $errorMessage],
                    $errorMessage,
                    $details,
                );
            }

            $headers['Location'] = $location;

            $body = '';

            // A redirect only happens when the status says so.
            if ($statusCode < 300 || $statusCode > 399) {
                $statusCode = self::DEFAULT_REDIRECT_STATUS_CODE;
            }
        } else {
            $body = $this->resolveToString($config['body'] ?? '');

            if (!$this->hasContentTypeHeader($headers)) {
                $headers['Content-Type'] = self::CONTENT_TYPES[$responseType];
            }
        }

        $isDelivered = WebhookResponseState::capture($flowId, $statusCode, $body, $headers);

        $deliveryNote = $this->describeDelivery($isDelivered);

        $output = [
            'status_code'    => $statusCode,
            'body'           => $body,
            'headers'        => $headers,
            'sent_to_caller' => $isDelivered,
            'delivery_note'  => $deliveryNote,
        ];

        $nodeVariableInstance = GlobalNodeVariables::getInstance($this->flowHistoryId, $flowId);

        $nodeVariableInstance->setVariables($nodeId, $output);

        $nodeVariableInstance->setNodeResponse($nodeId, $output);

        return FlowToolResponseDTO::create(
            FlowLog::STATUS['SUCCESS'],
            $config,
            $output,
            $deliveryNote,
            $details,
        );
    }

    /**
     * What happened to this response, in words the flow history can show.
     */
    private function describeDelivery(bool $isDelivered): string
    {
        if ($isDelivered) {
            return 'Response sent to the webhook caller';
        }

        if (WebhookResponseState::hasResponse()) {
            return 'Skipped: an earlier Respond to Webhook node already answered this call';
        }

        return 'No webhook caller is waiting on this run, so nothing was sent';
    }

    /**
     * The status code to answer with, kept inside the range HTTP defines.
     *
     * @param mixed $rawStatusCode
     */
    private function resolveStatusCode($rawStatusCode): int
    {
        $statusCode = MixInputHandler::replaceMixTagValue($rawStatusCode ?? '');

        if (!is_numeric($statusCode)) {
            return self::DEFAULT_STATUS_CODE;
        }

        return max(100, min(599, (int) $statusCode));
    }

    /**
     * A mapped value as a string, whatever shape it arrived in.
     *
     * @param mixed $rawValue
     */
    private function resolveToString($rawValue): string
    {
        $value = MixInputHandler::replaceMixTagValue($rawValue ?? '');

        if (\is_string($value)) {
            return $value;
        }

        return \is_scalar($value) ? (string) $value : (string) JSON::encode($value);
    }

    /**
     * The headers to send, dropping anything HTTP would not accept as a name.
     *
     * A newline inside a value would end the header and let the rest of it be
     * read as headers of its own, so those characters come out.
     *
     * @param mixed $rawHeaders
     */
    private function resolveHeaders($rawHeaders): array
    {
        $headers = [];

        foreach ((array) $rawHeaders as $row) {
            $row = (array) $row;

            $name = trim($this->resolveToString($row['key'] ?? ''));

            if ($name === '' || !preg_match(self::HEADER_NAME_PATTERN, $name)) {
                continue;
            }

            $value = $this->resolveToString($row['value'] ?? '');

            $headers[$name] = str_replace(["\r", "\n", "\0"], '', $value);
        }

        return $headers;
    }

    private function hasContentTypeHeader(array $headers): bool
    {
        foreach (array_keys($headers) as $name) {
            if (strtolower($name) === 'content-type') {
                return true;
            }
        }

        return false;
    }
}
