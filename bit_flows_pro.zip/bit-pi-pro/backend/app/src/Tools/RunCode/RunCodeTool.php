<?php

namespace BitApps\PiPro\src\Tools\RunCode;

// Prevent direct script access
if (!defined('ABSPATH')) {
    exit;
}

use BitApps\Pi\Config;
use BitApps\Pi\Helpers\MixInputHandler;
use BitApps\Pi\Model\FlowLog;
use BitApps\Pi\src\DTO\FlowToolResponseDTO;
use BitApps\Pi\src\Flow\GlobalNodeVariables;
use BitApps\Pi\src\Flow\NodeInfoProvider;
use BitApps\Pi\src\Tools\FlowToolsFactory;
use BitApps\PiPro\Deps\BitApps\WPKit\Helpers\JSON;
use Closure;
use RuntimeException;
use Throwable;

/**
 * Run PHP Code tool — executes admin-authored PHP at flow runtime.
 *
 * Threat model & guards:
 * - Capability gating: the PHP is authored only when a flow node is saved, an
 *   admin-only path (manage_options via the node-save endpoint). A flow run
 *   (incl. public webhooks) executes that already-stored, admin-written code —
 *   never code supplied by the request. Equivalent risk to WP's plugin editor.
 * - No untrusted input in source: mix tags ({{...}}) are NOT spliced into the
 *   source. Each tag is resolved to its runtime value and exposed through a
 *   $data array (positional), so webhook/step data is data, never code.
 * - Suspicious-code guard: obvious obfuscation/backdoor patterns are blocked
 *   before execution (see isCodeNotAllowed()).
 * - Isolation & recovery: the code runs in a generated closure file (no access
 *   to tool internals), echoed output is buffered and discarded, and Throwables
 *   are caught so a bad snippet returns an error result instead of a fatal.
 */
class RunCodeTool
{
    public const MACHINE_SLUG = 'runCode';

    protected $nodeInfoProvider;

    private $flowHistoryId;

    public function __construct(NodeInfoProvider $nodeInfoProvider, $flowHistory)
    {
        $this->nodeInfoProvider = $nodeInfoProvider;
        $this->flowHistoryId = $flowHistory;
    }

    public function execute()
    {
        $flowId = $this->nodeInfoProvider->getFlowId();
        $nodeId = $this->nodeInfoProvider->getNodeId();
        $nodeVariableInstance = GlobalNodeVariables::getInstance($this->flowHistoryId, $flowId);

        $codeValue = $this->nodeInfoProvider->getData()['runCode']['code'] ?? [];
        $resolved = $this->resolveCode($codeValue);
        $source = $resolved['source'];

        if ($this->isCodeNotAllowed($source)) {
            return FlowToolResponseDTO::create(
                FlowLog::STATUS['ERROR'],
                ['code' => $source],
                ['result' => 'Restricted code detected and blocked'],
                'Restricted code detected and blocked.',
                [
                    'app_slug'     => FlowToolsFactory::APP_SLUG,
                    'machine_slug' => self::MACHINE_SLUG,
                ]
            );
        }

        $status = FlowLog::STATUS['SUCCESS'];
        $message = 'Code executed successfully';
        $result = null;
        $runtimeFile = null;
        $initialBufferLevel = ob_get_level();

        try {
            $runtimeFile = $this->createRuntimeFile($source);
            $runner = $this->loadRuntimeFile($runtimeFile);

            if (!($runner instanceof Closure)) {
                throw new RuntimeException('Invalid PHP code.');
            }

            // Buffer so any echo in user code doesn't leak into the response; discard it.
            ob_start();
            $result = $runner($resolved['data']);
            ob_end_clean();
        } catch (Throwable $exception) {
            while (ob_get_level() > $initialBufferLevel) {
                ob_end_clean();
            }

            $errorMessage = $exception->getMessage();
            $status = FlowLog::STATUS['ERROR'];
            $result = $errorMessage;
            $message = 'Code execution failed: ' . $errorMessage;
        } finally {
            if (!empty($runtimeFile)) {
                $this->deleteRuntimeFile($runtimeFile);
            }
        }

        $output = ['result' => $result];

        $nodeVariableInstance->setVariables($nodeId, $output);
        $nodeVariableInstance->setNodeResponse($nodeId, $output);

        return FlowToolResponseDTO::create(
            $status,
            ['code' => $source],
            $output,
            $message,
            [
                'app_slug'     => FlowToolsFactory::APP_SLUG,
                'machine_slug' => self::MACHINE_SLUG,
            ]
        );
    }

    /**
     * Walk the MixInput tree: literal segments become PHP source, each tag is
     * resolved into $data[$i] and referenced as `$data[$i]` in the source. The
     * source is also what gets logged — resolved tag *values* are never inlined,
     * so secrets carried by a previous step don't leak into the flow log.
     *
     * @param mixed $codeValue MixInput tree (array) or plain string
     *
     * @return array{source: string, data: array}
     */
    private function resolveCode($codeValue): array
    {
        $tree = \is_string($codeValue) ? JSON::maybeDecode($codeValue, true) : $codeValue;

        if (!\is_array($tree)) {
            $source = \is_string($codeValue) ? $codeValue : '';

            return ['source' => $source, 'data' => []];
        }

        $source = '';
        $data = [];

        foreach ($tree as $segment) {
            $segment = (array) $segment;
            $type = $segment['type'] ?? 'string';

            if ($type === 'string') {
                $source .= $segment['value'] ?? '';

                continue;
            }

            $index = \count($data);
            $data[$index] = MixInputHandler::replaceMixTagValue([$segment]);
            $source .= '$data[' . $index . ']';
        }

        return ['source' => $source, 'data' => $data];
    }

    private function createRuntimeFile(string $source): string
    {
        $tempDir = get_temp_dir();
        $runtimeDir = trailingslashit($tempDir) . Config::SLUG;

        if (!wp_mkdir_p($runtimeDir)) {
            throw new RuntimeException('Unable to create runtime directory.');
        }

        $runtimeId = md5($source . microtime(true) . wp_rand());
        $filePath = trailingslashit($runtimeDir) . $runtimeId . '.php';
        $namespace = 'BitApps\PiPro\RunCodeRuntime\Code_' . $runtimeId;
        $content = "<?php\n\nnamespace {$namespace};\n\nif (!defined('ABSPATH')) {\n    exit;\n}\n\nreturn static function (array \$data) {\n" . $source . "\n};\n";

        // Direct write is required: the file is included locally right after, so
        // WP_Filesystem (which may be an FTP/SSH transport) is unsuitable here.
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
        if (file_put_contents($filePath, $content, LOCK_EX) === false) {
            throw new RuntimeException('Unable to write runtime PHP file.');
        }

        return $filePath;
    }

    private function loadRuntimeFile(string $runtimeFile)
    {
        $realPath = realpath($runtimeFile);
        $tempDir = get_temp_dir();
        $allowedDir = realpath(trailingslashit($tempDir) . Config::SLUG);

        if (!$realPath || !$allowedDir || !str_starts_with($realPath, $allowedDir . DIRECTORY_SEPARATOR)) {
            throw new RuntimeException('Invalid runtime PHP file path.');
        }

        // phpcs:ignore WordPressVIPMinimum.Files.IncludingFile.UsingVariable
        return include $realPath;
    }

    private function deleteRuntimeFile(string $runtimeFile): void
    {
        if (file_exists($runtimeFile)) {
            wp_delete_file($runtimeFile);
        }
    }

    /**
     * Block code-execution primitives (eval, shell_exec, system, exec,
     * passthru, popen, proc_open, backticks) before executing — these are never
     * legitimate in a data-transform snippet. This is a secondary tripwire only;
     * the real gate is that the code is admin-authored (manage_options); see the
     * class docblock.
     */
    private function isCodeNotAllowed(string $code): bool
    {
        $scannable = $this->stripCommentsAndStrings($code);

        return (bool) preg_match('/\b(eval|shell_exec|system|exec|passthru|popen|proc_open)\s*\(|`[^`]*`/i', $scannable);
    }

    /**
     * Return a copy of $code with comment bodies and string-literal contents
     * removed, so the pattern guards only ever match real executable tokens.
     * Without this, a keyword or backtick inside a comment/string (e.g. the
     * default "Use `return` ..." hint) trips the guard as a false positive.
     *
     * Function-call syntax is preserved: `system('x')` keeps `system(` and a
     * bare backtick operator keeps its `` `` `` delimiters, so both stay blocked.
     * If tokenizing fails, the raw code is returned (fail closed — over-block).
     */
    private function stripCommentsAndStrings(string $code): string
    {
        try {
            $tokens = @token_get_all("<?php\n" . $code);
        } catch (Throwable $exception) {
            return $code;
        }

        $droppedTypes = [
            T_COMMENT,
            T_DOC_COMMENT,
            T_CONSTANT_ENCAPSED_STRING,
            T_ENCAPSED_AND_WHITESPACE,
            T_OPEN_TAG,
        ];

        $scannable = '';

        foreach ($tokens as $token) {
            if (\is_string($token)) {
                $scannable .= $token;

                continue;
            }

            if (\in_array($token[0], $droppedTypes, true)) {
                continue;
            }

            $scannable .= $token[1];
        }

        return $scannable;
    }
}
