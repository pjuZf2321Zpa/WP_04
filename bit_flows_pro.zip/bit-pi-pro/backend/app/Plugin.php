<?php

namespace BitApps\PiPro;

// Prevent direct script access
if (!defined('ABSPATH')) {
    exit;
}


/*
 * Main class for the plugin.
 *
 * @since 1.0.0-alpha
 */

use BitApps\Pi\Config as freeConfig;
use BitApps\Pi\Providers\RewriteRuleProvider;
use BitApps\PiPro\Config as proConfig;
use BitApps\PiPro\Deps\BitApps\WPKit\Hooks\Hooks;
use BitApps\PiPro\Deps\BitApps\WPKit\Http\RequestType;
use BitApps\PiPro\Deps\BitApps\WPKit\Migration\MigrationHelper;
use BitApps\PiPro\Deps\BitApps\WPKit\Utils\Capabilities;
use BitApps\PiPro\Deps\BitApps\WPTelemetry\Telemetry\Telemetry;
use BitApps\PiPro\Deps\BitApps\WPTelemetry\Telemetry\TelemetryConfig;
use BitApps\PiPro\HTTP\Controllers\HumanInTheLoopController;
use BitApps\PiPro\HTTP\Controllers\McpOAuthAuthorizeController;
use BitApps\PiPro\HTTP\Controllers\PluginImprovementController;
use BitApps\PiPro\HTTP\Middleware\AdminCheckerMiddleware;
use BitApps\PiPro\HTTP\Middleware\NonceCheckerMiddleware;
use BitApps\PiPro\Providers\HookProvider;
use BitApps\PiPro\Providers\InstallerProvider;
use BitApps\PiPro\src\AllowTrackingTelemetryFallback;
use BitApps\PiPro\src\Cron\CustomScheduleManager;
use BitApps\PiPro\src\McpServer\WellKnownDocumentHandler;
use BitApps\PiPro\Utils\PluginCommonConfig;
use BitApps\PiPro\Utils\ProPluginUpdater;
use BitApps\PiPro\Utils\Services\LicenseService;
use BitApps\PiPro\Views\Layout;

final class Plugin
{
    private const FREE_PLUGIN_LOADED_HOOK = 'bit_pi_loaded';

    /**
     * Main instance of the plugin.
     *
     * @since 1.0.0-alpha
     *
     * @var null|Plugin
     */
    private static $_instance;

    private $_registeredMiddleware = [];

    /**
     * Initialize the Plugin with hooks.
     */
    public function __construct()
    {
        $this->registerInstaller();

        Hooks::addAction('plugins_loaded', [$this, 'loaded'], 11, 1);
    }

    public function registerInstaller()
    {
        $installerProvider = new InstallerProvider();
        $installerProvider->register();
    }

    /**
     * Load the plugin.
     */
    public function loaded()
    {
        if (!did_action(self::FREE_PLUGIN_LOADED_HOOK)) {
            return;
        }

        if (!freeConfig::getEnv('DEV')) {
            $this->initWPTelemetry();
        }

        Hooks::doAction(proConfig::withPrefix('loaded'));

        // The /.well-known discovery documents are answered before WordPress
        // routes the request, so they never depend on rewrite rules having
        // been flushed. Registered here rather than in registerProviders(),
        // which itself runs on init and would already be too late.
        Hooks::addAction('init', [new WellKnownDocumentHandler(), 'handleWellKnownRequest'], 0);
        Hooks::addAction('init', [$this, 'registerProviders'], 8);
        Hooks::addFilter('plugin_action_links_' . proConfig::get('BASENAME'), [$this, 'actionLinks']);
        Hooks::addFilter(proConfig::withPrefix('telemetry_data'), [$this, 'addProPluginInfo']);
        $this->maybeMigrateDB();
        $this->setPluginCommonConfig();
        Hooks::addFilter(proConfig::withPrefix('telemetry_additional_data'), [new PluginImprovementController(), 'filterTrackingData']);
    }

    public function initWPTelemetry()
    {
        AllowTrackingTelemetryFallback::migrateFromFreeIfAbsent();
        TelemetryConfig::setSlug(freeConfig::SLUG);
        TelemetryConfig::setTitle(freeConfig::TITLE);
        TelemetryConfig::setVersion(freeConfig::VERSION);
        TelemetryConfig::setPrefix(proConfig::VAR_PREFIX);
        TelemetryConfig::setServerBaseUrl(proConfig::TELEMETRY_SERVER_BASE_URL);
        TelemetryConfig::setTermsUrl(proConfig::TELEMETRY_TERMS_URL);
        TelemetryConfig::setPolicyUrl(proConfig::TELEMETRY_POLICY_URL);
        Telemetry::report()->init();
        Telemetry::feedback()->init();
    }

    public function addProPluginInfo($data)
    {
        $licenseData = LicenseService::getLicenseData();

        $data['pro'] = [
            'version'    => proConfig::VERSION,
            'hasLicense' => !empty($licenseData['key']),
            'license'    => $licenseData['key'],
            'status'     => $licenseData['status'],
            'expireAt'   => $licenseData['expireIn'],
        ];

        return $data;
    }

    public function setPluginCommonConfig()
    {
        PluginCommonConfig::setFreePluginVersion(freeConfig::VERSION);
        PluginCommonConfig::setProPluginVersion(proConfig::VERSION);
        PluginCommonConfig::setFreePluginSlug(freeConfig::SLUG);
        PluginCommonConfig::setProPluginSlug(proConfig::SLUG);
        PluginCommonConfig::setFreePluginPrefix(freeConfig::VAR_PREFIX);
        PluginCommonConfig::setProPluginPrefix(proConfig::VAR_PREFIX);
        PluginCommonConfig::setApiEndPoint('https://wp-api.bitapps.pro');
    }

    public function middlewares()
    {
        return [
            'nonce'   => NonceCheckerMiddleware::class,
            'isAdmin' => AdminCheckerMiddleware::class,
        ];
    }

    public function getMiddleware($name)
    {
        if (isset($this->_registeredMiddleware[$name])) {
            return $this->_registeredMiddleware[$name];
        }

        $middlewares = $this->middlewares();

        if (isset($middlewares[$name]) && class_exists($middlewares[$name]) && method_exists($middlewares[$name], 'handle')) {
            $this->_registeredMiddleware[$name] = new $middlewares[$name]();
        } else {
            return false;
        }

        return $this->_registeredMiddleware[$name];
    }

    /**
     * Instantiate the Provider class.
     */
    public function registerProviders()
    {
        global $wp_version;

        if (version_compare($wp_version, '6.5', '<') && !did_action(proConfig::FREE_PLUGIN_PREFIX . 'loaded')) {
            return PluginDependencyHandler::checkDependencyForProPlugin();
        }

        if (RequestType::is('admin')) {
            new Layout();
            new ProPluginUpdater();
        }

        $requestUri = isset($_SERVER['REQUEST_URI']) ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'])) : '';

        if (!RequestType::is(RequestType::API) && !RequestType::is(RequestType::AJAX) && !RequestType::is(RequestType::CRON) && !str_contains($requestUri, 'wp-content')) {
            $rewriteRules = get_option('rewrite_rules');
            $hitlCallbackRoute = '^' . freeConfig::SLUG . '/hitl/callback/([^/]+)/?$';
            $needsFlush = !isset($rewriteRules[$hitlCallbackRoute]);
            new RewriteRuleProvider(freeConfig::SLUG . '/hitl/callback/{token}', $needsFlush);
            Hooks::addAction('template_include', [new HumanInTheLoopController(), 'handleCallback']);

            $mcpAuthorizeRoute = '^' . freeConfig::SLUG . '/mcp-authorize/?$';
            $mcpNeedsFlush = !isset($rewriteRules[$mcpAuthorizeRoute]);
            new RewriteRuleProvider(freeConfig::SLUG . '/mcp-authorize', $mcpNeedsFlush);
            Hooks::addAction('template_include', [new McpOAuthAuthorizeController(), 'handleAuthorizePage']);
        }

        (new CustomScheduleManager())->initSchedules();


        new HookProvider();
    }

    /**
     * Plugin action links.
     *
     * @param array $links Array of links
     *
     * @return array
     */
    public function actionLinks($links)
    {
        $linksToAdd = proConfig::get('PLUGIN_PAGE_LINKS');
        foreach ($linksToAdd as $link) {
            $links[] = '<a href="' . $link['url'] . '">' . $link['title'] . '</a>';
        }

        return $links;
    }

    public static function maybeMigrateDB()
    {
        if (!Capabilities::check('manage_options')) {
            return;
        }

        if (version_compare(proConfig::getOption('db_version'), proConfig::DB_VERSION, '<')) {
            MigrationHelper::migrate(InstallerProvider::migration());
        }
    }

    /**
     * Retrieves the main instance of the plugin.
     *
     * @since 1.0.0-alpha
     *
     * @return Plugin plugin main instance
     */
    public static function instance()
    {
        return self::$_instance;
    }

    /**
     * Loads the plugin main instance and initializes it.
     *
     * @return bool True if the plugin main instance could be loaded, false otherwise
     *
     * @since 1.0.0-alpha
     */
    public static function load()
    {
        if (self::$_instance !== null) {
            return false;
        }

        self::$_instance = new self();

        return true;
    }
}
