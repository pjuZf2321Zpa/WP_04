<?php

namespace BitApps\PiPro\Services;

// Prevent direct script access
if (!defined('ABSPATH')) {
    exit;
}


use BitApps\Pi\Model\CustomApp;
use BitApps\Pi\Model\CustomMachine;
use BitApps\PiPro\Config;
use BitApps\PiPro\Deps\BitApps\WPKit\Helpers\JSON;

/**
 * Serves node/integration schemas to the MCP server. Built-in app schemas
 * come from the build-time generated catalog (pnpm generate:mcp-catalog);
 * custom apps are merged in from the database at runtime.
 */
class McpNodeCatalogService
{
    /**
     * Decoded catalog, cached for the request.
     *
     * @var null|array
     */
    private static $catalog;

    /**
     * Searches apps by slug, name, machine label or tag, best match first.
     *
     * @param string $query matches app slug, app name, machine label or tag
     * @param int    $limit how many apps to return; the caller owns the default
     *
     * @return array[] light results: {appSlug, name, triggers: slugs, actions: slugs}
     */
    public function search($query, $limit)
    {
        $query = strtolower(trim((string) $query));
        $matched = [];

        foreach ($this->apps() as $app) {
            $score = $query === '' ? 0 : $this->relevance($app, $query);

            if ($score === null) {
                continue;
            }

            $matched[] = ['score' => $score, 'app' => $app];
        }

        // Best match first. A term like "woocommerce" also appears in the
        // machine labels of a dozen unrelated add-ons, and every app carries
        // its full trigger/action list, so an unranked result set spends
        // thousands of tokens before reaching the app that was asked for.
        usort(
            $matched,
            static function ($a, $b) {
                return $b['score'] <=> $a['score'];
            }
        );

        $results = [];

        foreach (\array_slice($matched, 0, $limit) as $entry) {
            $app = $entry['app'];

            $results[] = [
                'appSlug'  => $app['appSlug'],
                'name'     => $app['name'],
                'triggers' => $this->machineSummaries($app['triggers']),
                'actions'  => $this->machineSummaries($app['actions']),
            ];
        }

        return $results;
    }

    /**
     * Returns one machine entry, or null when the app/machine is unknown.
     *
     * @return null|array machine entry plus appSlug/type
     */
    private function getSchema($appSlug, $machineSlug)
    {
        foreach ($this->apps() as $app) {
            if ($app['appSlug'] !== $appSlug) {
                continue;
            }

            foreach (['triggers', 'actions'] as $type) {
                foreach ($app[$type] as $machine) {
                    if ($machine['machineSlug'] === $machineSlug) {
                        return array_merge($machine, ['appSlug' => $appSlug, 'type' => rtrim($type, 's')]);
                    }
                }
            }

            return null;
        }

        return null;
    }

    public function isKnownMachine($appSlug, $machineSlug)
    {
        // "tools" nodes (condition, iterator, router...) are built-in, not catalog entries
        if ($appSlug === 'tools') {
            return true;
        }

        return (bool) $this->getSchema($appSlug, $machineSlug);
    }

    /**
     * Loads built-in catalog apps and merges DB-backed custom apps.
     *
     * @return array[] built-in catalog apps + DB-backed custom apps
     */
    private function apps()
    {
        if (self::$catalog !== null) {
            return self::$catalog;
        }

        $catalogFile = Config::get('BASEDIR') . DIRECTORY_SEPARATOR . 'data' . DIRECTORY_SEPARATOR . 'mcp-node-catalog.json';
        $decoded = is_readable($catalogFile) ? JSON::decode(file_get_contents($catalogFile), true) : null;
        $apps = isset($decoded['apps']) && \is_array($decoded['apps']) ? $decoded['apps'] : [];

        return self::$catalog = array_merge($apps, $this->builtInApps(), $this->customApps());
    }

    /**
     * Built-in nodes that the generated catalog does not cover.
     *
     * The catalog JSON is built from the frontend integration machines, so the
     * flow tools and the Schedule trigger — which have no integration
     * directory — were invisible to search_apps. An AI that cannot find a
     * condition or a router authors a linear chain instead of a branched flow,
     * so they are declared here.
     *
     * @return array[]
     */
    private function builtInApps()
    {
        return [$this->toolsApp(), $this->scheduleApp()];
    }

    /**
     * The flow tools palette as a catalog entry.
     *
     * These are configured structurally — through the blueprint map, the node
     * data key, or ordinary field_mapping — rather than through a config
     * schema, so each machine points at the authoring guide.
     *
     * @return array
     */
    private function toolsApp()
    {
        $machines = [
            'condition'        => 'Condition',
            'router'           => 'Router',
            'iterator'         => 'Iterator',
            'repeater'         => 'Repeater/Loop',
            'jsonParser'       => 'JSON Parser',
            'xml'              => 'XML',
            'csv'              => 'CSV',
            'dateTime'         => 'Date Time',
            'delay'            => 'Delay',
            'imageHelper'      => 'Image Helper',
            'aiAgent'          => 'AI Agent',
            'runCode'          => 'Run PHP Code',
            'respondToWebhook' => 'Respond to Webhook',
        ];

        $actions = [];

        foreach ($machines as $slug => $label) {
            $actions[] = ['machineSlug' => $slug, 'label' => $label];
        }

        return [
            'appSlug'  => 'tools',
            'name'     => 'Flow Tools (built-in)',
            'tags'     => [
                'tool', 'condition', 'filter', 'branch', 'if', 'router', 'parallel', 'split',
                'iterator', 'loop', 'repeater', 'json', 'parser', 'xml', 'csv', 'delay', 'wait',
                'date', 'time', 'image', 'ai agent', 'code', 'php', 'webhook response', 'respond',
            ],
            'triggers' => [],
            'actions'  => $actions,
        ];
    }

    /**
     * The built-in Schedule trigger, which starts a flow on a recurring clock.
     *
     * @return array
     */
    private function scheduleApp()
    {
        return [
            'appSlug'  => 'schedule',
            'name'     => 'Schedule (built-in)',
            'tags'     => ['schedule', 'cron', 'recurring', 'daily', 'weekly', 'hourly', 'timer'],
            'triggers' => [
                ['machineSlug' => 'everyDay', 'label' => 'Schedule'],
            ],
            'actions'  => [],
        ];
    }

    private function customApps()
    {
        // get() answers a Collection, and a plain array only when nothing
        // matched, so this must not be guarded with is_array() — that test
        // fails for every non-empty result and hid custom apps entirely.
        $customApps = CustomApp::where('status', 1)->get(['id', 'name', 'slug']);

        $apps = [];

        foreach ($customApps as $customApp) {
            $machines = CustomMachine::where('custom_app_id', $customApp->id)
                ->where('status', 1)
                ->get(['name', 'slug', 'app_type', 'trigger_type', 'config']);

            $triggers = [];
            $actions = [];

            foreach ($machines as $machine) {
                $entry = [
                    'machineSlug' => $machine->slug,
                    'label'       => $machine->name,
                ];

                if ($machine->app_type === 'trigger') {
                    $triggers[] = $entry;
                } else {
                    $actions[] = $entry;
                }
            }

            $apps[] = [
                'appSlug'  => $customApp->slug,
                'name'     => $customApp->name . ' (custom app)',
                'tags'     => ['custom app'],
                'triggers' => $triggers,
                'actions'  => $actions,
            ];
        }

        return $apps;
    }

    /**
     * How well an app answers the query: higher is better, null means no match.
     *
     * The app's own identity outranks a mention buried in one of its machine
     * labels, so searching "woocommerce" returns WooCommerce before the
     * add-ons that merely integrate with it.
     *
     * @param array  $app
     * @param string $query lower-cased search term
     *
     * @return null|int
     */
    private function relevance($app, $query)
    {
        $slug = strtolower($app['appSlug']);
        $name = strtolower($app['name']);

        if ($slug === $query || $name === $query) {
            return 4;
        }

        if (str_starts_with($slug, $query) || str_starts_with($name, $query)) {
            return 3;
        }

        if (str_contains($slug, $query) || str_contains($name, $query)) {
            return 2;
        }

        foreach (isset($app['tags']) ? $app['tags'] : [] as $tag) {
            if (str_contains(strtolower($tag), $query)) {
                return 1;
            }
        }

        foreach (array_merge($app['triggers'], $app['actions']) as $machine) {
            if (str_contains(strtolower($machine['label']), $query)) {
                return 0;
            }
        }

        return null;
    }

    private function machineSummaries($machines)
    {
        return array_map(
            static function ($machine) {
                return $machine['machineSlug'] . ' — ' . $machine['label'];
            },
            $machines
        );
    }
}
