<?php

namespace BitApps\PiPro\Services;

// Prevent direct script access
if (!defined('ABSPATH')) {
    exit;
}


use BitApps\Pi\Model\Connection;
use BitApps\Pi\Model\Webhook;

/**
 * Validates AI-authored flow blueprints before they touch the database.
 * Errors are fatal (blueprint rejected); warnings are returned to the AI
 * so it can self-correct but do not block the save.
 */
class McpFlowBlueprintValidatorService
{
    private const NODE_ID_PATTERN = '/^(new|\d+)-\d+(-\d+)?$/';

    private const BRANCH_ID_PATTERN = '/^(new|\d+)-\d+-\d+$/';

    private array $errors = [];

    private array $warnings = [];

    /**
     * Validates a blueprint and returns errors and warnings.
     *
     * @param mixed $blueprint
     *
     * @return array{valid: bool, errors: string[], warnings: string[]}
     */
    public function validate($blueprint)
    {
        $this->errors = [];
        $this->warnings = [];

        if (!\is_array($blueprint)) {
            return $this->result('Blueprint must be a JSON object');
        }

        foreach (['map', 'data', 'nodes'] as $key) {
            if (empty($blueprint[$key]) || !\is_array($blueprint[$key])) {
                $this->errors[] = "Blueprint is missing required key: {$key}";
            }
        }

        if ($this->errors) {
            return $this->result();
        }

        $nodeIds = $this->validateNodes($blueprint['nodes']);
        $this->validateMap($blueprint['map'], $nodeIds);
        $this->validateCanvasData($blueprint['data'], $nodeIds);

        return $this->result();
    }

    /**
     * Validates the nodes array and returns the collected node ids.
     *
     * @return string[] validated node ids
     */
    private function validateNodes($nodes)
    {
        $nodeIds = [];
        $catalog = new McpNodeCatalogService();

        foreach ($nodes as $index => $node) {
            if (!\is_array($node)) {
                $this->errors[] = "nodes[{$index}] must be an object";

                continue;
            }

            $nodeId = isset($node['node_id']) ? $node['node_id'] : null;

            if (!\is_string($nodeId) || !preg_match(self::NODE_ID_PATTERN, $nodeId)) {
                $this->errors[] = "nodes[{$index}].node_id must match \"{flowId}-{n}\" (use \"new-{n}\" for new flows)";

                continue;
            }

            $nodeIds[] = $nodeId;

            $appSlug = isset($node['app_slug']) ? $node['app_slug'] : null;
            $machineSlug = isset($node['machine_slug']) ? $node['machine_slug'] : null;

            if (!$appSlug || !$machineSlug) {
                $this->errors[] = "Node {$nodeId} is missing app_slug or machine_slug";

                continue;
            }

            if (!$catalog->isKnownMachine($appSlug, $machineSlug)) {
                $this->errors[] = "Node {$nodeId}: unknown machine {$appSlug}/{$machineSlug}. Use search_apps to find valid slugs.";

                continue;
            }

            $this->validateFieldMapping($node, $nodeId, $appSlug);
        }

        if ($nodeIds !== array_unique($nodeIds)) {
            $this->errors[] = 'Duplicate node_id values in nodes';
        }

        return $nodeIds;
    }

    /**
     * Checks the two ids a blueprint may reference against live rows.
     *
     * Everything else in field_mapping is left alone: flows are authored as
     * structure and configured in the builder, so an empty mapping is the
     * normal case rather than something to warn about.
     */
    private function validateFieldMapping($node, $nodeId, $appSlug)
    {
        $fieldMapping = isset($node['field_mapping']) ? $node['field_mapping'] : null;

        if ($fieldMapping === null) {
            return;
        }

        if (!\is_array($fieldMapping)) {
            $this->errors[] = "Node {$nodeId}: field_mapping must be an object or null";

            return;
        }

        $configs = isset($fieldMapping['configs']) && \is_array($fieldMapping['configs']) ? $fieldMapping['configs'] : [];
        $connectionId = $configs['connection-id']['value'] ?? null;
        $webhookId = $configs['webhook-id']['value'] ?? null;

        if ($connectionId !== null) {
            $connection = Connection::findOne(['id' => (int) $connectionId]);

            if (!$connection) {
                $this->errors[] = "Node {$nodeId}: connection-id {$connectionId} does not exist. Use list_connections.";
            } elseif ($connection->app_slug !== $appSlug) {
                $this->errors[] = "Node {$nodeId}: connection {$connection->id} belongs to app \"{$connection->app_slug}\", not \"{$appSlug}\"";
            } elseif ((int) $connection->status !== Connection::STATUS['verified']) {
                $this->warnings[] = "Node {$nodeId}: connection {$connection->id} is not verified yet";
            }
        }

        if ($webhookId !== null && !Webhook::findOne(['id' => (int) $webhookId])) {
            $this->errors[] = "Node {$nodeId}: webhook-id {$webhookId} does not exist. Use create_webhook first.";
        }
    }

    private function validateMap($map, $nodeIds)
    {
        $mapIds = [];
        $this->collectMapIds($map, $mapIds);

        if (!isset($map['id']) || !isset($map['type']) || $map['type'] !== 'trigger') {
            $this->errors[] = 'map root must be the trigger node ({"id":..., "type":"trigger", ...})';
        }

        foreach ($mapIds as $mapId => $mapType) {
            if ($this->livesOnlyInMap($mapId, $mapType)) {
                continue;
            }

            if (!\in_array($mapId, $nodeIds, true)) {
                $this->errors[] = "map references node \"{$mapId}\" which is not defined in nodes";
            }
        }
    }

    /**
     * Whether an id names a condition branch rather than a node.
     *
     * Branches are "{flowId}-{n}-{m}" — the node id with the branch index
     * appended. They appear in the map and as edge sourceHandles, never as a
     * nodes[] row or a canvas box.
     *
     * @param mixed $id
     *
     * @return bool
     */
    private function isConditionBranchId($id)
    {
        return \is_string($id) && preg_match(self::BRANCH_ID_PATTERN, $id) === 1;
    }

    /**
     * Whether a map entry is one that never carries a nodes[] row.
     *
     * Routers and condition branches exist only in the map and on the canvas —
     * a flow built in the editor stores no row for either. Branches are matched
     * by type, falling back to their {flowId}-{n}-{m} id shape for blueprints
     * that leave the type off.
     *
     * @param string $mapId
     * @param string $mapType
     *
     * @return bool
     */
    private function livesOnlyInMap($mapId, $mapType)
    {
        return \in_array($mapType, ['router', 'condition-logic', 'default-condition-logic'], true)
            || $this->isConditionBranchId($mapId);
    }

    private function collectMapIds($map, &$ids)
    {
        if (!\is_array($map)) {
            return;
        }

        if (isset($map['id']) && \is_string($map['id'])) {
            $ids[$map['id']] = isset($map['type']) && \is_string($map['type']) ? $map['type'] : '';
        }

        if (isset($map['next'])) {
            if (\is_array($map['next']) && isset($map['next'][0])) {
                foreach ($map['next'] as $branch) {
                    $this->collectMapIds($branch, $ids);
                }
            } else {
                $this->collectMapIds($map['next'], $ids);
            }
        }
    }

    private function validateCanvasData($data, $nodeIds)
    {
        if (empty($data['nodes']) || !\is_array($data['nodes'])) {
            $this->warnings[] = 'data.nodes (canvas layout) is empty — the flow will not render nicely in the visual editor';

            return;
        }

        $canvasIds = array_column($data['nodes'], 'id');

        // A condition branch is an edge, not a box. Giving it a canvas entry
        // draws an empty node under the condition — one per branch.
        foreach ($canvasIds as $canvasId) {
            if ($this->isConditionBranchId($canvasId)) {
                $this->errors[] = "data.nodes must not contain an entry for condition branch \"{$canvasId}\" — branches are drawn as edges, using the branch id as the edge sourceHandle";
            }
        }

        foreach ($nodeIds as $nodeId) {
            if (!\in_array($nodeId, $canvasIds, true)) {
                $this->warnings[] = "data.nodes has no canvas entry for node {$nodeId}";
            }
        }

        if (empty($data['edges'])) {
            $this->warnings[] = 'data.edges is empty — nodes will appear disconnected in the visual editor';
        }
    }

    private function result($fatal = null)
    {
        if ($fatal !== null) {
            $this->errors[] = $fatal;
        }

        return [
            'valid'    => !$this->errors,
            'errors'   => $this->errors,
            'warnings' => $this->warnings,
        ];
    }
}
