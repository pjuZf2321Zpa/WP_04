<?php

use BitApps\Pi\Config as FreePluginConfig;
use BitApps\PiPro\HTTP\Controllers\McpOAuthController;
use BitApps\PiPro\HTTP\Controllers\McpServerController;

if (!defined('ABSPATH')) {
    exit;
}

/*
 * Not Route::. The WPKit router envelopes every response as {status, code,
 * data} and resolves a WP_REST_Request parameter to an empty object, which
 * breaks JSON-RPC and the RFC 7591 / 8414 / 9728 documents — those carry
 * required fields at the top level, so a client registering against an
 * enveloped reply fails with "client_id Field required".
 *
 * TODO:: Convert this to use the WPKit router once it can return a raw
 * response and run a per-route auth callback.
 */
$mcpNamespace = FreePluginConfig::SLUG . '/v1';
$mcpController = new McpServerController();
$mcpOAuthController = new McpOAuthController();

register_rest_route(
    $mcpNamespace,
    '/mcp',
    [
        [
            'methods'             => 'POST',
            'callback'            => [$mcpController, 'handle'],
            'permission_callback' => [$mcpController, 'checkAuth'],
        ],
        [
            'methods'             => ['GET', 'DELETE'],
            'callback'            => [$mcpController, 'methodNotAllowed'],
            'permission_callback' => '__return_true',
        ],
    ]
);

register_rest_route(
    $mcpNamespace,
    '/mcp-oauth/register',
    [
        'methods'             => 'POST',
        'callback'            => [$mcpOAuthController, 'register'],
        'permission_callback' => '__return_true',
    ]
);

register_rest_route(
    $mcpNamespace,
    '/mcp-oauth/token',
    [
        'methods'             => 'POST',
        'callback'            => [$mcpOAuthController, 'token'],
        'permission_callback' => '__return_true',
    ]
);

register_rest_route(
    $mcpNamespace,
    '/mcp-oauth/resource-metadata',
    [
        'methods'             => 'GET',
        'callback'            => [$mcpOAuthController, 'resourceMetadata'],
        'permission_callback' => '__return_true',
    ]
);

register_rest_route(
    $mcpNamespace,
    '/mcp-oauth/authorization-server-metadata',
    [
        'methods'             => 'GET',
        'callback'            => [$mcpOAuthController, 'authorizationServerMetadata'],
        'permission_callback' => '__return_true',
    ]
);
