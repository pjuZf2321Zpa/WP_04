<?php

use BitApps\PiPro\Deps\BitApps\WPKit\Http\Router\Route;
use BitApps\PiPro\HTTP\Controllers\CustomAppExportImportController;
use BitApps\PiPro\HTTP\Controllers\FlowExportImportController;
use BitApps\PiPro\HTTP\Controllers\FlowRunController;
use BitApps\PiPro\HTTP\Controllers\McpConnectedClientController;
use BitApps\PiPro\HTTP\Controllers\PluginImprovementController;
use BitApps\PiPro\Utils\HTTP\Controllers\LicenseController;
use BitApps\PiPro\Utils\HTTP\Controllers\PluginUpdateController;

if (!defined('ABSPATH')) {
    exit;
}

if (!headers_sent()) {
    header('Access-Control-Allow-Methods: POST, GET, OPTIONS, PUT, DELETE');
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');
    header('Access-Control-Allow-Origin: *');

    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        status_header(200);

        exit;
    }
}
Route::group(
    function () {
        Route::get('flow-export/{flow_id}', [FlowExportImportController::class, 'export']);
        Route::get('custom-app-export/{custom_app_id}', [CustomAppExportImportController::class, 'export']);
        Route::post('custom-app-import', [CustomAppExportImportController::class, 'import']);
        Route::post('flow-import/{flow_id}', [FlowExportImportController::class, 'import']);
        Route::get('flow-run-existing-data', [FlowRunController::class, 'flowRunWithExistingData']);
        Route::get('update-plugin', [PluginUpdateController::class, 'updatePlugin']);
        Route::post('license/activate', [LicenseController::class, 'activateLicense']);
        Route::post('license/deactivate', [LicenseController::class, 'deactivateLicense']);
        Route::get('license/check', [LicenseController::class, 'checkLicenseStatus']);
        Route::get('plugin/update-check', [PluginUpdateController::class, 'isPluginUpdateAvailable']);
        Route::get('plugin-improvement', [PluginImprovementController::class, 'getOpt']);
        Route::post('plugin-improvement', [PluginImprovementController::class, 'updateOpt']);
        Route::get('mcp-server/info', [McpConnectedClientController::class, 'info']);
        Route::post('mcp-server/settings', [McpConnectedClientController::class, 'updateSettings']);
        Route::get('mcp-server/api-key', [McpConnectedClientController::class, 'apiKey']);
        Route::post('mcp-server/api-key/generate', [McpConnectedClientController::class, 'generateApiKey']);
        Route::post('mcp-server/api-key/revoke', [McpConnectedClientController::class, 'revokeApiKey']);
        Route::get('mcp-server/clients', [McpConnectedClientController::class, 'clients']);
        Route::post('mcp-server/clients/revoke', [McpConnectedClientController::class, 'revoke']);
    }
)->middleware('nonce', 'isAdmin');
