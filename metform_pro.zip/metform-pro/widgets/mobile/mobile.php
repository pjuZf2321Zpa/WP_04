<?php
namespace Elementor;

use MetForm\Utils\Util;

defined( 'ABSPATH' ) || exit;

Class MetForm_Input_Mobile extends Widget_Base{
	use \MetForm\Traits\Common_Controls;
	use \MetForm\Traits\Conditional_Controls;
    
    public function get_name(){
        return 'mf-mobile';
    }

	public function get_icon(){
		return 'mf-widget-icon icon-metform_mobile_number';
	}

    public function get_title(){
        return esc_html__( 'Mobile', 'metform-pro' );
	}

	public function has_widget_inner_wrapper(): bool {
		return ! Plugin::$instance->experiments->is_feature_active('e_optimized_markup');
	}
	
	public function show_in_panel() {
        return 'metform-form' == get_post_type();
	}

	public function get_categories() {
		return [ 'metform-pro' ];
	}
	
	public function get_keywords() {
        return ['metform-pro', 'input', 'mobile', 'number', 'phone', 'country code'];
    }

	public function get_help_url() {
        return 'https://wpmet.com/doc/premium-input-field-list/#mobile';
    }

    protected function register_controls(){

        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'metform-pro' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->input_content_controls(['NO_PLACEHOLDER']);

        $this->end_controls_section();

        $this->start_controls_section(
			'settings_section',
			[
				'label' => esc_html__( 'Settings', 'metform-pro' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->input_setting_controls(['VALIDATION']);

		$country_list = Util::country_list();
		$this->add_control(
			'country_code',
			[
				'label'		=> __( 'Default Country', 'metform-pro' ),
				'type'		=> Controls_Manager::SELECT,
				'default'	=> 'us',
				'options'	=> $country_list,
			]
		);

		$this->add_control(
			'mf_mobile_same_format',
			[
				'label' => esc_html__( 'Get Same Number Format?', 'metform-pro' ),
				'type' => Controls_Manager::SWITCHER,
				'yes' => esc_html__( 'Yes', 'metform-pro' ),
				'no' => esc_html__( 'No', 'metform-pro' ),
				'return_value' => 'yes',
				'default' => 'no',
				'description' => esc_html__('Do you want to get same format in the entry after submit? Make it "Yes".', 'metform-pro'),
			]
		);

		$this->end_controls_section();

		if(class_exists('\MetForm_Pro\Base\Package')){
			$this->input_conditional_control();
		}

        $this->start_controls_section(
			'label_section',
			[
				'label' => esc_html__( 'Label', 'metform-pro' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'conditions' => [
					'relation' => 'or',
					'terms' => [
						[
							'name' => 'mf_input_label_status',
							'operator' => '===',
							'value' => 'yes',
						],
						[
							'name' => 'mf_input_required',
							'operator' => '===',
							'value' => 'yes',
						],
					],
                ],
			]
        );

		$this->input_label_controls();

        $this->end_controls_section();

        $this->start_controls_section(
			'input_section',
			[
				'label' => esc_html__( 'Input', 'metform-pro' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

        $this->input_controls();

        $this->end_controls_section();
		
		$this->start_controls_section(
			'help_text_section',
			[
				'label' => esc_html__( 'Help Text', 'metform-pro' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'mf_input_help_text!' => ''
				]
			]
		);
		
		$this->input_help_text_controls();

        $this->end_controls_section();
        
	}
    
    protected function render(){
		$settings = $this->get_settings_for_display();
		$inputWrapStart = $inputWrapEnd = '';
		extract($settings);
		$id = $this->get_id();

		$render_on_editor = true;
		$is_edit_mode = 'metform-form' === get_post_type() && \Elementor\Plugin::$instance->editor->is_edit_mode();

		/**
		 * Loads the below markup on 'Editor' view, only when 'metform-form' post type
		 */
		if ( $is_edit_mode ):
			$inputWrapStart = '<div class="mf-form-wrapper"></div><script type="text" class="mf-template">return html`';
			$inputWrapEnd = '`</script>';
		endif;

		$class = (isset($settings['mf_conditional_logic_form_list']) ? 'mf-conditional-input' : '');

		$configData = [
            'message' 		=> $errorMessage 	= isset($mf_input_validation_warning_message) ? !empty($mf_input_validation_warning_message) ? $mf_input_validation_warning_message : esc_html__('This field is required.', 'metform-pro') : esc_html__('This field is required.', 'metform-pro'),
            'minLength'		=> isset($mf_input_min_length) ? $mf_input_min_length : 1,
            'maxLength'		=> isset($mf_input_max_length) ? $mf_input_max_length : '',
            'type'			=> isset($mf_input_validation_type) ? $mf_input_validation_type : '',
            'required'		=> isset($mf_input_required) && $mf_input_required == 'yes' ? true : false,
		];
		
		?>

		<?php echo $inputWrapStart; ?>

		<div className="mf-input-wrapper">
			<?php if ( 'yes' == $mf_input_label_status ): ?>
				<label className="mf-input-label" htmlFor="mf-input-mobile-<?php echo esc_attr( $this->get_id() ); ?>">
					<?php echo Util::esc_mflt_react_entity( $mf_input_label, $render_on_editor ); ?>
					<span className="mf-input-required-indicator"><?php echo esc_html( ($mf_input_required === 'yes') ? '*' : '' );?></span>
				</label>
			<?php endif; ?>

			<${props.ReactPhoneInput}
				inputProps=${{
					name: "<?php echo esc_attr($mf_input_name); ?>"
				}}
				inputExtraProps=${{
					required: true,
				}}
				key=${parent.state.resetKey}
				searchPlaceholder="<?php echo esc_html__('Search', 'metform-pro');?>"
				inputClass="mf-input mf-input-mobile"
				country="<?php echo esc_attr( $country_code ); ?>"
				enableSearch=${true}
				countryCodeEditable=${false}
				enableAreaCodes=${false}
				value=${parent.state.mobileWidget["<?php echo esc_attr($mf_input_name); ?>"] ? parent.state.mobileWidget["<?php echo esc_attr($mf_input_name); ?>"] : 
				(parent.state.formData["<?php echo esc_attr($mf_input_name); ?>"] ? parent.state.formData["<?php echo esc_attr($mf_input_name); ?>"] : '')}
				}
				name="<?php echo esc_attr($mf_input_name); ?>"
				id="mf-input-mobile-<?php echo esc_attr($this->get_id()); ?>"
				onChange=${(value, country) => {
					return parent.handleOnChangePhoneInput(value, "<?php echo esc_attr($mf_input_name); ?>", country)
				} }
				onBlur=${(event, country) => {
					let value = event.target.value;
					if(value && "<?php echo esc_attr($mf_mobile_same_format); ?>" != "yes"){
						value = value.replace(/[^\d]/g, '');
					}
					parent.handleOnChangePhoneInput(value, "<?php echo esc_attr($mf_input_name); ?>", country)
				} }
				/>
			<?php if ( !$is_edit_mode ) : ?>
				<input
					type="hidden"
					name="<?php echo esc_attr( $mf_input_name ); ?>"
					className="mf-input mf-mobile-hidden"
					style="display:none;"
					value=${ parent.getValue( '<?php echo esc_attr( $mf_input_name ); ?>' ) }
					ref=${ (el) => parent.activateValidation(<?php echo json_encode($configData); ?>, el) }
					/>
				<${validation.ErrorMessage}
					errors=${validation.errors}
					name="<?php echo esc_attr( $mf_input_name ); ?>"
					as=${html`<span className="mf-error-message"></span>`}
					/>
			<?php endif; ?>
			
			<?php echo '' != $mf_input_help_text ? '<span className="mf-input-help">'. Util::esc_mflt_react_entity( $mf_input_help_text, $render_on_editor ) .'</span>' : ''; ?>
		</div>

		<?php echo $inputWrapEnd; ?>

		<?php
    }

}
