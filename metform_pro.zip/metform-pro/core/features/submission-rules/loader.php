<?php

namespace MetForm_Pro\Core\Features\Submission_Rules;

use MetForm_Pro\Traits\Singleton;

defined('ABSPATH') || exit;

if (!defined('METFORM_PRO_FEATURE_HOOKS')) {
	return; // Older MetForm free still runs this feature itself.
}

/**
 * Required Login and Limit Total Entries.
 *
 * Blocks a submission before anything is stored when the form needs a
 * logged-in user or has reached its entry limit.
 */
class Submission_Rules
{
	use Singleton;

	public function init()
	{
		add_action('metform/form_settings/slot/require_login', [$this, 'render_require_login_setting']);
		add_action('metform/form_settings/slot/limit_total_entries', [$this, 'render_limit_total_entries_setting']);

		add_filter('metform/entries/submit/pre_check', [$this, 'pre_check'], 10, 4);
	}

	/**
	 * @param null|\WP_Error $result        A WP_Error from an earlier handler, or null.
	 * @param int            $form_id
	 * @param array          $form_data
	 * @param array          $form_settings
	 *
	 * @return null|\WP_Error
	 */
	public function pre_check($result, $form_id, $form_data, $form_settings)
	{
		if (is_wp_error($result)) {
			return $result;
		}

		$form_settings = is_array($form_settings) ? $form_settings : [];

		// The failure codes and messages must stay as they are: the submission
		// failure log and the frontend both use them.
		$require_login = isset($form_settings['require_login']) ? (int) $form_settings['require_login'] : 0;

		if ($require_login === 1 && !is_user_logged_in()) {
			return new \WP_Error('login_required', esc_html__('You must be logged in to submit form.', 'metform-pro'));
		}

		if (isset($form_settings['limit_total_entries_status']) && (int) $form_settings['limit_total_entries_status'] === 1) {
			$limit       = isset($form_settings['limit_total_entries']) ? $form_settings['limit_total_entries'] : null;
			$entry_count = \MetForm\Core\Entries\Action::instance()->get_entry_count($form_id);

			if ($entry_count >= $limit) {
				return new \WP_Error('entry_limit', esc_html__('Form submission limit exceeded.', 'metform-pro'));
			}
		}

		return $result;
	}

	public function render_require_login_setting()
	{
		?>
		<div class="mf-input-group mf-box-style">
			<label class="attr-input-label">
				<input type="checkbox" value="1" name="require_login" class="mf-admin-control-input mf-form-modalinput-require_login">
				<span><?php esc_html_e('Required Login:', 'metform-pro'); ?></span>
			</label>
			<span class='mf-input-help'><?php esc_html_e('Without login, users can\'t submit the form.', 'metform-pro'); ?></span>
		</div>
		<?php
	}

	public function render_limit_total_entries_setting()
	{
		?>
		<div class="mf-input-group mf-box-style">
			<div class="mf-input-group-inner">
				<label class="attr-input-label">
					<input type="checkbox" value="1" name="limit_total_entries_status" class="mf-admin-control-input mf-form-modalinput-limit_status">
					<span><?php esc_html_e('Limit Total Entries:', 'metform-pro'); ?></span>
				</label>
				<div class="mf-input-group" id='limit_status'>
					<input type="number" min="1" name="limit_total_entries" class="mf-form-modalinput-limit_total_entries attr-form-control">
				</div>
			</div>
			<span class='mf-input-help mf-limit-help'><?php esc_html_e('Limit the total number of submissions for this form.', 'metform-pro'); ?></span>
		</div>
		<?php
	}
}

Submission_Rules::instance()->init();
