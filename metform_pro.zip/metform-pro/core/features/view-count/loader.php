<?php

namespace MetForm_Pro\Core\Features\View_Count;

use MetForm\Core\Forms\Action as Forms_Action;
use MetForm_Pro\Plugin;
use MetForm_Pro\Traits\Singleton;

defined('ABSPATH') || exit;

if (!defined('METFORM_PRO_FEATURE_HOOKS')) {
	return; // Older MetForm free still runs this feature itself.
}

/**
 * Count Views: the form sends one request per render and the counter goes up
 * by one, but only for forms that have "Count views" turned on.
 */
class View_Count
{
	use Singleton;

	/**
	 * Free's Views/Conversion column reads this key, so it must not change.
	 */
	const META_KEY = 'metform_form__count_views';

	public function init()
	{
		add_action('metform/form_settings/slot/count_views', [$this, 'render_setting']);
		add_filter('metform/form/wrapper_attributes', [$this, 'add_views_endpoint'], 10, 3);
		add_action('rest_api_init', [$this, 'register_routes']);
	}

	/**
	 * Site visitors call this route, so it is registered directly instead of
	 * through \MetForm_Pro\Base\Api, whose permission check needs manage_options.
	 */
	public function register_routes()
	{
		register_rest_route(Plugin::METFORM_PRO_PREFIX . '/v1', '/forms/views/(?P<id>\d+)', [
			'methods'             => \WP_REST_Server::CREATABLE,
			'callback'            => [$this, 'count_view'],
			'permission_callback' => '__return_true',
		]);
	}

	public function count_view(\WP_REST_Request $request)
	{
		$form_id = absint($request['id']);

		if (!$form_id || 'metform-form' !== get_post_type($form_id)) {
			return null;
		}

		$form_settings = Forms_Action::instance()->get_all_data($form_id);

		if (!isset($form_settings['count_views']) || $form_settings['count_views'] != '1') {
			return null;
		}

		$count = (int) Forms_Action::instance()->get_count_views($form_id);
		$count++;
		update_post_meta($form_id, self::META_KEY, $count);

		return $count;
	}

	public function add_views_endpoint($attrs, $form_id, $form_settings)
	{
		$attrs = is_array($attrs) ? $attrs : [];

		if (is_numeric($form_id) && is_array($form_settings) && isset($form_settings['count_views']) && $form_settings['count_views'] == '1') {
			$attrs['data-views-endpoint'] = rest_url(Plugin::METFORM_PRO_PREFIX . '/v1/forms/views/' . absint($form_id));
		}

		return $attrs;
	}

	public function render_setting()
	{
		?>
		<div class="mf-input-group mf-box-style">
			<label class="attr-input-label">
				<input type="checkbox" value="1" name="count_views" class="mf-admin-control-input mf-form-modalinput-count_views">
				<span><?php esc_html_e('Count views:', 'metform-pro'); ?></span>
			</label>
			<span class='mf-input-help'><?php esc_html_e('Track form views.', 'metform-pro'); ?></span>
		</div>
		<?php
	}
}

View_Count::instance()->init();
