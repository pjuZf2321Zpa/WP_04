<?php

namespace MetForm_Pro\Core\Features\Quiz;

use MetForm_Pro\Base\Assets_Enqueue;
use MetForm_Pro\Traits\Singleton;
use MetForm_Pro\Core\Features\Quiz\Overview_Chart;

defined('ABSPATH') || exit;

class Integration
{
    use Singleton;

    public function init()
    {
        
        // Include include mf-chart.js file
        add_action('admin_enqueue_scripts', [$this, 'enqueue_files']);

        // Require quiz related files
        require_once 'overview_chart.php';

        add_action('metform_after_entries_table_data', [$this, 'add_quiz_data_to_entries_table'], 10, 3);
    }

    public function enqueue_files($hook){
        $screen = get_current_screen(); 

        if('post.php' === $hook && 'metform-entry' === $screen->post_type){

            // Load the css files only when needed
            Assets_Enqueue::get_style( 'mf-quiz-admin-styles' );
            Assets_Enqueue::get_script( 'mf-charts' );
        }
    }

    public function add_quiz_data_to_entries_table($form_id, $form_data, $map_data)
    {
        $form_settings = \MetForm\Core\Forms\Action::instance()->get_all_data($form_id);
        if(isset($form_settings['form_type']) && $form_settings['form_type'] === 'quiz-form'){

            $quiz_overview = $this->get_quiz_overview_details($form_data);

            if(!$quiz_overview || !$quiz_overview['total_questions']) return;

            $correct_percentage = round($quiz_overview['correct_parcentage'], 2);
            $wrong_percentage   = round(100 - $quiz_overview['correct_parcentage'], 2);

            $overview_chart_html = Overview_Chart::get_quiz_overview_data_chart($correct_percentage, $wrong_percentage);

            $output = "
            <tr class='mf-data-label'>
                <td colspan='2'>
                    <strong class='mf-quiz-result-heading'>". __('QUIZ RESULT', 'metform-pro') ."</strong>
                </td>
            </tr>
            <tr class='mf-data-value'>
                <td colspan='2'>
                    <div class='mf-quiz-result-wrapper'>

                        <div class='mf-quiz-stats-grid'>
                            <div class='mf-quiz-stat-card'>
                                <span class='mf-stat-label'>". __('Total Questions', 'metform-pro') ."</span>
                                <span class='mf-stat-value'>".esc_html($quiz_overview['total_questions'])."</span>
                            </div>
                            <div class='mf-quiz-stat-card'>
                                <span class='mf-stat-label'>". __('Correct Answers', 'metform-pro') ."</span>
                                <span class='mf-stat-value'>".esc_html($quiz_overview['total_correct_answers'])."</span>
                            </div>
                            <div class='mf-quiz-stat-card'>
                                <span class='mf-stat-label'>". __('Wrong Answers', 'metform-pro') ."</span>
                                <span class='mf-stat-value'>".esc_html($quiz_overview['wrong_asnwer'])."</span>
                            </div>
                            <div class='mf-quiz-stat-card'>
                                <span class='mf-stat-label'>". __('Correct Percentage', 'metform-pro') ."</span>
                                <span class='mf-stat-value'>".esc_html($correct_percentage)."%</span>
                            </div>
                            <div class='mf-quiz-stat-card'>
                                <span class='mf-stat-label'>". __('Total Marks', 'metform-pro') ."</span>
                                <span class='mf-stat-value'>".esc_html($quiz_overview['total_marks'])."</span>
                            </div>
                        </div>

                        <div class='mf-quiz-chart-area'>
                            {$overview_chart_html}
                        </div>

                    </div>
                </td>
            </tr>";

            echo $output;
        }
    }

    protected function get_quiz_overview_details($form_data) {

        $total_questions = 0;
        $total_correct_answers = 0;
        $wrong_asnwer = 0;
        $correct_parcentage = 0;
        $total_marks = 0;

        if(
            isset($form_data['wrong-answer']) && 
            isset($form_data['quiz-marks']) && 
            isset($form_data['total-question']) && 
            isset($form_data['right-answer'])
        ){
            if(!empty($form_data['wrong-answer'])){
                $sanitized_wrong = sanitize_text_field($form_data['wrong-answer']);
                $wrong_asnwer = count(array_filter(explode(",", $sanitized_wrong)));
            }
            if(!empty($form_data['right-answer'])){
                $sanitized_right = sanitize_text_field($form_data['right-answer']);
                $total_correct_answers = count(array_filter(explode(",", $sanitized_right)));
            }

            $total_questions = intval($form_data['total-question']);
            $total_marks = floatval($form_data['quiz-marks']);

            $total_answered_questions = $wrong_asnwer + $total_correct_answers;

            if($total_answered_questions){
                $correct_parcentage = ($total_correct_answers / $total_answered_questions) * 100;
            } else {
                $correct_parcentage = 0;
            }
            

        } else {
            return false;
        }

        return [
            'total_questions' => $total_questions,
            'total_correct_answers' => $total_correct_answers,
            'wrong_asnwer' => $wrong_asnwer,
            'correct_parcentage' => $correct_parcentage,
            'total_marks' => $total_marks
        ];
    }
}

Integration::instance()->init();
