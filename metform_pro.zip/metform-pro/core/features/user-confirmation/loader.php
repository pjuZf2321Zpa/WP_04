<?php

namespace MetForm_Pro\Core\Features\User_Confirmation;

use MetForm\Core\Entries\Action as Entries_Action;
use MetForm\Core\Entries\Form_Data;
use MetForm\Core\Entries\Metform_Shortcode;
use MetForm_Pro\Traits\Singleton;

defined('ABSPATH') || exit;

if (!defined('METFORM_PRO_FEATURE_HOOKS')) {
	return; // Older MetForm free still runs this feature itself.
}

/**
 * Confirmation mail to user, with an optional copy of the submitted data.
 */
class User_Confirmation
{
	use Singleton;

	public function init()
	{
		add_action('metform/form_settings/slot/user_confirmation', [$this, 'render_settings']);
		add_action('metform/entries/submit/notify_user', [$this, 'send_user_email'], 10, 2);
	}

	/**
	 * @param object $response The submit response free sends back to the browser.
	 * @param array  $context  Submission context, see free `Entries\Action::get_hook_context()`.
	 */
	public function send_user_email($response, $context)
	{
		$form_settings = isset($context['form_settings']) && is_array($context['form_settings']) ? $context['form_settings'] : [];

		if (!isset($form_settings['enable_user_notification']) || $form_settings['enable_user_notification'] != 1) {
			return;
		}

		$form_id   = $context['form_id'];
		$form_data = is_array($context['form_data']) ? $context['form_data'] : [];
		$file_info = $context['file_upload_info'];

		// get user mail from form data
		$user_mail       = null;
		$all_email_names = Entries_Action::instance()->get_input_name_by_widget_type('mf-email', $context['fields']) ?? [];
		foreach ($all_email_names as $_email_key) {
			if (!empty($form_data[$_email_key])) {
				$user_mail = $form_data[$_email_key];
				break;
			}
		}

		$subject  = isset($form_settings['user_email_subject']) ? $form_settings['user_email_subject'] : get_bloginfo('name');
		$from     = isset($form_settings['user_email_from']) ? $form_settings['user_email_from'] : null;
		$reply_to = isset($form_settings['user_email_reply_to']) ? $form_settings['user_email_reply_to'] : null;
		$body     = nl2br(isset($form_settings['user_email_body']) ? $form_settings['user_email_body'] : '');

		$user_email_attached_submission_copy = isset($form_settings['user_email_attach_submission_copy']) ? $form_settings['user_email_attach_submission_copy'] : null;

		// Replace shortcodes. Values going into the HTML body are escaped, or a
		// submitter could inject markup through any field the template uses.
		// Header fields stay raw here; mf_sanitize_header_field() handles them below.
		$body     = Metform_Shortcode::instance()->get_process_shortcode($body, true);
		$reply_to = Metform_Shortcode::instance()->get_process_shortcode($reply_to);
		$subject  = Metform_Shortcode::instance()->get_process_shortcode($subject);

		if ($user_email_attached_submission_copy == "1") {
			$body      = "<html><body><h2 style='text-align: center;'>" . get_the_title($form_id) . "</h2><h4 style='text-align: center;'>" . $body . "</h4>";
			$form_html = Form_Data::format_data_for_mail($form_id, $form_data, $file_info);
			$body     .= $form_html . "</body></html>";
		} else {
			$body = "<html><body><h2 style='text-align: center;'>" . get_the_title($form_id) . "</h2><h4 style='text-align: center;'>" . $body . "</h4>" . "</body></html>";
		}

		$body = apply_filters('metform_confirmation_user_email_body', $body, $form_id, $form_data, $file_info, $form_settings);

		// Prevent email header (CRLF) injection from user-supplied field values
		// injected via shortcodes such as [mf-email].
		$from      = Entries_Action::mf_sanitize_header_field($from);
		$reply_to  = Entries_Action::mf_sanitize_header_field($reply_to);
		$subject   = Entries_Action::mf_sanitize_header_field($subject);
		$user_mail = Entries_Action::mf_sanitize_header_field($user_mail);

		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";

		$headers .= 'From: ' . $from . "\r\n" .
			'Reply-To: ' . $reply_to . "\r\n" .
			'X-Mailer: PHP/' . phpversion();

		if (!$user_mail) {
			if (current_user_can('manage_options')) {
				$response->status       = 0;
				$response->failure_type = 'email';
				$response->error[]      = esc_html__('Mail not found.', 'metform-pro');
			}
		} else {
			$status = wp_mail($user_mail, $subject, $body, $headers);
			if (current_user_can('manage_options')) {
				if (empty($status)) {
					$response->failure_type = 'email';
					$response->error[]      = esc_html__('Please setup your SMTP mail server.', 'metform-pro');
					$response->status       = 0;
				}
			}
		}
	}

	public function render_settings()
	{
		?>
		<div class="mf-input-group mf-box-style">
			<label class="attr-input-label">
				<input type="checkbox" value="1" name="enable_user_notification" class="mf-admin-control-input mf-form-user-enable">
				<span><?php esc_html_e('Confirmation mail to user :', 'metform-pro'); ?></span>
			</label>
			<span class='mf-input-help'>
				<?php esc_html_e('Want to send a submission copy to user by email? Active this one. ', 'metform-pro'); ?>
				<strong><?php esc_html_e('This form must include at least one required Email field.', 'metform-pro'); ?></strong>
			</span>
		</div>

		<div class="mf-input-group mf-form-user-confirmation ">
			<?php do_action('after_confirmation_mail_to_user_switch'); ?>
		</div>

		<div class="mf-input-group mf-form-user-confirmation mf-form-top-spacing mf-form-bottom-spacing">
			<label for="attr-input-label" class="attr-input-label"><?php esc_html_e('Email Subject:', 'metform-pro'); ?></label>
			<input type="text" name="user_email_subject" class="mf-form-user-email-subject attr-form-control" placeholder="<?php esc_attr_e('Email subject', 'metform-pro'); ?>">
			<span class='mf-input-help'><?php esc_html_e('Enter here email subject.', 'metform-pro'); ?></span>
		</div>

		<div class="mf-input-group mf-form-user-confirmation mf-form-bottom-spacing">
			<label for="attr-input-label" class="attr-input-label"><?php esc_html_e('Email From:', 'metform-pro'); ?></label>
			<input type="email" name="user_email_from" class="mf-form-user-email-from attr-form-control" placeholder="<?php esc_attr_e('From email', 'metform-pro'); ?>">
			<span class='mf-input-help'><?php esc_html_e('Enter the email by which you want to send email to user.', 'metform-pro'); ?></span>
		</div>

		<div class="mf-input-group mf-form-user-confirmation mf-form-bottom-spacing">
			<label for="attr-input-label" class="attr-input-label"><?php esc_html_e('Email Reply To:', 'metform-pro'); ?></label>
			<input type="email" name="user_email_reply_to" class="mf-form-user-reply-to attr-form-control" placeholder="<?php esc_attr_e('Reply to email', 'metform-pro'); ?>">
			<span class='mf-input-help'><?php esc_html_e('Enter email where user can reply/ you want to get reply.', 'metform-pro'); ?></span>
		</div>

		<div class="mf-input-group mf-form-user-confirmation mf-form-bottom-spacing">
			<label for="attr-input-label" class="attr-input-label"><?php esc_html_e('Thank you message :', 'metform-pro'); ?></label>
			<textarea name="user_email_body" id="" class="mf-form-user-email-body attr-form-control" cols="30" rows="3" placeholder="<?php esc_attr_e('Thank you message!', 'metform-pro'); ?>"></textarea>
			<span class='mf-input-help'><?php esc_html_e('Enter here your message to include it in email body. Which will be send to user.', 'metform-pro'); ?></span>
		</div>

		<div class="mf-input-group mf-box-style">
			<label class="attr-input-label">
				<input type="checkbox" value="1" name="user_email_attach_submission_copy" class="mf-admin-control-input mf-form-user-submission-copy">
				<span><?php esc_html_e('Want to send a copy of submitted form to user ?', 'metform-pro'); ?></span>
			</label>
		</div>
		<?php
	}
}

User_Confirmation::instance()->init();
