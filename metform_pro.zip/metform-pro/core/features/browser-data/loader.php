<?php

namespace MetForm_Pro\Core\Features\Browser_Data;

use MetForm_Pro\Traits\Singleton;

defined('ABSPATH') || exit;

if (!defined('METFORM_PRO_FEATURE_HOOKS')) {
	return; // Older MetForm free still runs this feature itself.
}

/**
 * Capture User Browser Data: stores the visitor's IP and user agent on each entry.
 */
class Browser_Data
{
	use Singleton;

	/**
	 * Free's "Browser Data" entry meta box reads this key, so it must not change.
	 */
	const META_KEY = 'metform_form__entry_browser_data';

	public function init()
	{
		add_action('metform/form_settings/slot/capture_browser_data', [$this, 'render_setting']);
		add_action('metform/entries/after_insert', [$this, 'store_browser_data'], 10, 4);
	}

	public function store_browser_data($entry_id, $form_id, $form_data, $form_settings)
	{
		if (empty($entry_id) || !is_array($form_settings)) {
			return;
		}

		if (isset($form_settings['capture_user_browser_data']) && $form_settings['capture_user_browser_data'] == '1') {
			update_post_meta($entry_id, self::META_KEY, $this->get_browser_data());
		}
	}

	public function get_browser_data()
	{
		if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
			$ip = sanitize_text_field(wp_unslash($_SERVER['HTTP_CLIENT_IP']));
		} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			$ip = sanitize_text_field(wp_unslash($_SERVER['HTTP_X_FORWARDED_FOR']));
		} else {
			$ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';
		}

		$user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : '';

		return [
			'IP'         => $ip,
			'User_Agent' => $user_agent,
		];
	}

	public function render_setting()
	{
		?>
		<div class="mf-input-group mf-box-style">
			<label class="attr-input-label">
				<input type="checkbox" value="1" name="capture_user_browser_data" class="mf-admin-control-input mf-form-modalinput-capture_user_browser_data">
				<span><?php esc_html_e('Capture User Browser Data:', 'metform-pro'); ?></span>
			</label>
			<span class='mf-input-help'><?php esc_html_e('Store user\'s browser data (ip, browser name, etc)', 'metform-pro'); ?></span>
		</div>
		<?php
	}
}

Browser_Data::instance()->init();
