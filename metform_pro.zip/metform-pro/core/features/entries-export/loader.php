<?php

namespace MetForm_Pro\Core\Features\Entries_Export;

use MetForm_Pro\Plugin;
use MetForm_Pro\Traits\Singleton;

defined('ABSPATH') || exit;

if (!defined('METFORM_PRO_FEATURE_HOOKS')) {
	return; // Older MetForm free still runs this feature itself.
}

/**
 * Export CSV: the "CSV" button in the forms list.
 */
class Entries_Export
{
	use Singleton;

	public function init()
	{
		new Api();

		add_filter('metform/forms/list/csv_export_url', [$this, 'export_url'], 10, 2);
	}

	/**
	 * Free shows the real CSV button when this returns a URL.
	 */
	public function export_url($url, $form_id)
	{
		return add_query_arg(
			'_wpnonce',
			wp_create_nonce('wp_rest'),
			rest_url(Plugin::METFORM_PRO_PREFIX . '/v1/entries/export/' . absint($form_id))
		);
	}
}

Entries_Export::instance()->init();
