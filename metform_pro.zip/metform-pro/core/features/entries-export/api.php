<?php

namespace MetForm_Pro\Core\Features\Entries_Export;

defined('ABSPATH') || exit;

/**
 * GET metform-pro/v1/entries/export/{form_id}
 *
 * The base class limits the route to users with manage_options.
 */
class Api extends \MetForm_Pro\Base\Api
{
	public function config()
	{
		$this->prefix = 'entries';
		$this->param  = '/(?P<id>\d+)';
	}

	public function get_export()
	{
		if (!current_user_can('manage_options')) {
			return;
		}

		return Export::instance()->export_data(absint($this->request['id']));
	}
}
