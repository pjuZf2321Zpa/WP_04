<?php

namespace MetForm_Pro\Core\Features\Scroll_Control;

use MetForm\Utils\Util;
use MetForm_Pro\Traits\Singleton;

defined('ABSPATH') || exit;

if (!defined('METFORM_PRO_FEATURE_HOOKS')) {
	return; // Older MetForm free still runs this feature itself.
}

/**
 * Stop Vertical Scrolling: the form doesn't scroll to the message after submit.
 */
class Scroll_Control
{
	use Singleton;

	public function init()
	{
		add_action('metform/form_settings/slot/stop_vertical_scrolling', [$this, 'render_setting']);
		add_filter('metform/form/wrapper_attributes', [$this, 'add_stop_scroll_attribute'], 10, 3);
	}

	/**
	 * Professional and Agency plans, old Pro licences, and sites that already
	 * used the setting. Same rule as before the code moved to Pro.
	 */
	public function has_access()
	{
		return Util::is_using_feature('mf_stop_vertical_scrolling')
			|| Util::is_old_pro_user()
			|| Util::is_mid_tier()
			|| Util::is_top_tier();
	}

	public function add_stop_scroll_attribute($attrs, $form_id, $form_settings)
	{
		$attrs = is_array($attrs) ? $attrs : [];

		// No tier check here, same as before: the setting can only be turned on
		// from the settings modal, which does the tier check.
		if (is_array($form_settings) && isset($form_settings['mf_stop_vertical_scrolling']) && $form_settings['mf_stop_vertical_scrolling'] == '1') {
			$attrs['data-stop-vertical-effect'] = '1';
		}

		return $attrs;
	}

	public function render_setting()
	{
		if (!$this->has_access()) {
			if (function_exists('mf_dummy_switch_input')) {
				mf_dummy_switch_input([
					'label' => __('Stop Vertical Scrolling', 'metform-pro'),
					'help'  => __('Stop scrolling effect when submitting the form.', 'metform-pro'),
					'badge' => __('Pro', 'metform-pro'),
				]);
			}
			return;
		}
		?>
		<div class="mf-input-group mf-box-style">
			<label class="attr-input-label">
				<input type="checkbox" value="1" name="mf_stop_vertical_scrolling" class="mf-admin-control-input mf-form-modalinput-stop_vertical_scrolling">
				<span><?php esc_html_e('Stop Vertical Scrolling:', 'metform-pro'); ?></span>
			</label>
			<span class='mf-input-help'><?php esc_html_e('Stop scrolling effect when submitting the form.', 'metform-pro'); ?></span>
		</div>
		<?php
	}
}

Scroll_Control::instance()->init();
