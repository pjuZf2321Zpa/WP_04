<?php

namespace MetForm_Pro\Core\Integrations\Messaging\Slack;

use MetForm\Utils\Util;
use MetForm_Pro\Traits\Singleton;

defined('ABSPATH') || exit;

if (!defined('METFORM_PRO_FEATURE_HOOKS')) {
	return; // Older MetForm free still runs this integration itself.
}

/**
 * Slack: post each submission to the form's incoming webhook.
 */
class Integration
{
	use Singleton;

	public function init()
	{
		add_action('metform/form_settings/slot/slack', [$this, 'render_settings']);

		// Priority 20: runs after Mailchimp (10), as before the move.
		add_action('metform/entries/submit/integrations', [$this, 'post_to_webhook'], 20, 2);
	}

	/**
	 * Professional and Agency plans, old Pro licences, and sites that already
	 * used Slack. Same rule as before the code moved to Pro.
	 */
	public function has_access()
	{
		return Util::is_using_feature('mf_slack')
			|| Util::is_old_pro_user()
			|| Util::is_mid_tier()
			|| Util::is_top_tier();
	}

	/**
	 * @param object $response The submit response free sends back to the browser.
	 * @param array  $context  Submission context, see free `Entries\Action::get_hook_context()`.
	 */
	public function post_to_webhook($response, $context)
	{
		$form_settings = isset($context['form_settings']) && is_array($context['form_settings']) ? $context['form_settings'] : [];
		$form_data     = isset($context['form_data']) && is_array($context['form_data']) ? $context['form_data'] : [];
		$fields        = isset($context['fields']) && is_array($context['fields']) ? $context['fields'] : [];
		$email_name    = isset($context['email_name']) ? $context['email_name'] : null;

		if (!isset($form_settings['mf_slack']) || $form_settings['mf_slack'] != '1') {
			return;
		}

		if ($email_name == null || !isset($form_data[$email_name]) || $form_data[$email_name] == '') {
			return;
		}

		// The form has a "Listing Opt-in" field and the visitor did not tick it.
		if (array_key_exists('mf-listing-optin', $fields) && !isset($form_data['mf-listing-optin'])) {
			return;
		}

		$url = isset($form_settings['mf_slack_webhook']) ? $form_settings['mf_slack_webhook'] : '';

		$slack  = new Slack();
		$result = $slack->call_webhook($form_data, ['url' => $url, 'email_name' => $email_name]);

		$response->status = isset($result['status']) ? $result['status'] : 0;
		if ($response->status == 0) {
			$response->failure_type = 'integration';
			$response->error        = [esc_html__('Problem with your slack integration.', 'metform-pro')];
		}
	}

	public function render_settings()
	{
		if (!$this->has_access()) {
			if (function_exists('mf_dummy_switch_input')) {
				mf_dummy_switch_input([
					'label' => __('Slack:', 'metform-pro'),
					'help'  => __('Integrate slack with this form.', 'metform-pro'),
					'badge' => __('Pro', 'metform-pro'),
				]);
			}
			return;
		}
		?>
		<div class="mf-box-style">
			<div class="mf-input-group">
				<label class="attr-input-label">
					<input type="checkbox" value="1" name="mf_slack" class="mf-admin-control-input mf-form-modalinput-slack">
					<span><?php esc_html_e('Slack:', 'metform-pro'); ?></span>
				</label>
				<span class='mf-input-help'><?php esc_html_e('Integrate slack with this form. ', 'metform-pro'); ?><strong><?php esc_html_e('slack info.', 'metform-pro'); ?></strong></span>
			</div>

			<div class="mf-input-group mf-slack mf-form-top-spacing">
				<label for="attr-input-label" class="attr-input-label"><?php esc_html_e('Slack webhook:', 'metform-pro'); ?></label>
				<input type="text" name="mf_slack_webhook" class="mf-slack-web-hook attr-form-control" placeholder="<?php esc_attr_e('Slack webhook', 'metform-pro'); ?>">
				<span class='mf-input-help'><?php esc_html_e('Enter here slack web hook. ', 'metform-pro'); ?><a href="http://slack.com/apps/A0F7XDUAZ-incoming-webhooks"><?php esc_html_e('create from here', 'metform-pro'); ?></a></span>
			</div>
		</div>
		<?php
	}
}

Integration::instance()->init();
