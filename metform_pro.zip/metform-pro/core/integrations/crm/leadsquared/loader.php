<?php

namespace MetForm_Pro\Core\Integrations\Crm\Leadsquared;

use MetForm_Pro\Traits\Singleton;
use MetForm_Pro\Utils\Render;
use MetForm\Utils\Util;

defined('ABSPATH') || exit;

class Integration {

    use Singleton;

    private $parent_id;
    private $sub_tab_id;
    private $sub_tab_title;

    private static $data_centers = [
        'in21' => 'India (Mumbai)',
        'in22' => 'India (Hyderabad)',
        'us11' => 'United States',
        'sg'   => 'Singapore',
        'me61' => 'Middle East',
        'ir31' => 'Ireland (EU)',
        'ca12' => 'Canada',
    ];

    public function init() {

        $this->parent_id     = 'mf_crm';
        $this->sub_tab_id    = 'leadsquared';
        $this->sub_tab_title = 'LeadSquared';

        add_action('metform_after_store_form_data', [$this, 'capture_lead'], 10, 4);
        add_action('metform_settings_subtab_' . $this->parent_id, [$this, 'sub_tab'], 30);
        add_action('metform_settings_subtab_content_' . $this->parent_id, [$this, 'sub_tab_content'], 30);
        add_action('wp_ajax_mf_leadsquared_save_settings', [$this, 'save_settings']);
        add_action('wp_ajax_mf_leadsquared_test_connection', [$this, 'test_connection']);
        add_action('wp_ajax_mf_leadsquared_get_attributes', [$this, 'get_attributes']);
    }

    public function capture_lead($form_id, $form_data, $form_settings, $attributes) {
        $leadsquared = new Leadsquared();
        $leadsquared->capture_lead($form_id, $form_data, $form_settings, $attributes);
    }

    public function sub_tab() {
        $is_active = isset($_GET['mf_crm_tab']) && sanitize_key($_GET['mf_crm_tab']) === 'leadsquared' ? 'active' : null;
        Render::sub_tab($this->sub_tab_title, $this->sub_tab_id, $is_active);
    }

    public function sub_tab_content() {
        $is_active = isset($_GET['mf_crm_tab']) && sanitize_key($_GET['mf_crm_tab']) === 'leadsquared' ? 'active' : '';
        Render::sub_tab_content($this->sub_tab_id, [$this, 'contents'], $is_active);
    }

    public function contents() {

        if (method_exists(Util::class, 'is_top_tier')
            && !Util::is_top_tier()
            && !Util::is_using_settings_option('mf_leadsquared_data_center')
            && !Util::is_using_feature('mf_leadsquared')
            && !Util::is_old_pro_user()
        ) {
            $alert_heading = esc_html__('Upgrade to integrate LeadSquared with your forms!', 'metform-pro');
            $alert_description = esc_html__('Get premium access to integrate LeadSquared CRM with your forms.', 'metform-pro');

            if (!Util::is_mid_tier() && !Util::is_top_tier()) {
                $alert_heading = esc_html__('LeadSquared Integration is Exclusive To Higher Tiers!', 'metform-pro');
                $alert_description = esc_html__('Get access by upgrading to MetForm Agency Plan.', 'metform-pro');
            }

            Util::mf_pro_alert_notice([
                'heading'     => $alert_heading,
                'description' => $alert_description,
            ]);
            return;
        }

        $selected_data_center = get_option('mf_leadsquared_data_center', 'in21');
        $access_key           = get_option('mf_leadsquared_access_key', '');
        $secret_key           = get_option('mf_leadsquared_secret_key', '');
        $nonce                = wp_create_nonce('mf_leadsquared_settings');

        ?>
        <div class="mf-setting-input-group">
            <div class="mf-setting-field">
                <label class="mf-setting-label" for="mf_leadsquared_data_center">
                    <?php esc_html_e('Select Data Center:', 'metform-pro'); ?>
                </label>
                <select class="mf-setting-input attr-form-control"
                        id="mf_leadsquared_data_center"
                        name="mf_leadsquared_data_center">
                    <?php foreach (self::$data_centers as $value => $label) : ?>
                        <option value="<?php echo esc_attr($value); ?>" <?php selected($selected_data_center, $value); ?>>
                            <?php echo esc_html($label); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mf-setting-field" style="margin-top: 14px;">
                <label class="mf-setting-label" for="mf_leadsquared_access_key">
                    <?php esc_html_e('Access Key:', 'metform-pro'); ?>
                </label>
                <div style="position:relative; display:flex; align-items:center;">
                    <input type="password"
                           id="mf_leadsquared_access_key"
                           name="mf_leadsquared_access_key"
                           value="<?php echo esc_attr($access_key); ?>"
                           class="mf-setting-input attr-form-control"
                           style="padding-right:40px;"
                           placeholder="<?php esc_attr_e('Enter your LeadSquared Access Key', 'metform-pro'); ?>">
                    <button type="button" class="mf-ls-toggle-pw" data-target="mf_leadsquared_access_key"
                            style="position:absolute;right:10px;background:none;border:none;cursor:pointer;padding:0;color:#666;">
                        <span class="dashicons dashicons-visibility"></span>
                    </button>
                </div>
            </div>

            <div class="mf-setting-field" style="margin-top: 14px;">
                <label class="mf-setting-label" for="mf_leadsquared_secret_key">
                    <?php esc_html_e('Secret Key:', 'metform-pro'); ?>
                </label>
                <div style="position:relative; display:flex; align-items:center;">
                    <input type="password"
                           id="mf_leadsquared_secret_key"
                           name="mf_leadsquared_secret_key"
                           value="<?php echo esc_attr($secret_key); ?>"
                           class="mf-setting-input attr-form-control"
                           style="padding-right:40px;"
                           placeholder="<?php esc_attr_e('Enter your LeadSquared Secret Key', 'metform-pro'); ?>">
                    <button type="button" class="mf-ls-toggle-pw" data-target="mf_leadsquared_secret_key"
                            style="position:absolute;right:10px;background:none;border:none;cursor:pointer;padding:0;color:#666;">
                        <span class="dashicons dashicons-visibility"></span>
                    </button>
                </div>
            </div>

            <p class="description" style="margin-top: 10px;">
                <?php
                    printf(
                        /* translators: %s: LeadSquared help article URL */
                        esc_html__('You can find your Access Key and Secret Key in LeadSquared under Settings > API & Webhooks. %s', 'metform-pro'),
                        '<a href="https://help.leadsquared.com/how-do-i-obtain-api-access-keys-in-leadsquared/" target="_blank" rel="noopener noreferrer">' . esc_html__('Learn more', 'metform-pro') . '</a>'
                    );
                ?>
            </p>

            <div style="margin-top: 14px;">
                <button type="button"
                        id="mf_leadsquared_test_btn"
                        class="button mf-setting-btn"
                        data-nonce="<?php echo esc_attr($nonce); ?>">
                    <?php esc_html_e('Test Connection', 'metform-pro'); ?>
                </button>

                <span id="mf_leadsquared_status_msg" style="margin-left: 10px;"></span>
            </div>
        </div>

        <script type="text/javascript">
            jQuery(document).ready(function($) {
                var $testBtn      = $('#mf_leadsquared_test_btn');
                var $statusMsg    = $('#mf_leadsquared_status_msg');
                var lsNonce       = <?php echo wp_json_encode( $nonce ); ?>;

                // Strip invisible/control characters on paste
                $('#mf_leadsquared_access_key, #mf_leadsquared_secret_key').on('paste', function() {
                    var $input = $(this);
                    setTimeout(function() {
                        $input.val($input.val().replace(/[\s​-‍﻿\r\n\t]/g, ''));
                    }, 0);
                });

                // Save via AJAX when the main "Save Changes" button is clicked (only when LeadSquared tab is visible)
                $('#submit, .mf-settings-form-submit-btn').on('click', function() {
                    if ($('#leadsquared').is(':visible')) {
                        $.post(ajaxurl, {
                            action:      'mf_leadsquared_save_settings',
                            nonce:       lsNonce,
                            data_center: $('#mf_leadsquared_data_center').val(),
                            access_key:  $.trim($('#mf_leadsquared_access_key').val()),
                            secret_key:  $.trim($('#mf_leadsquared_secret_key').val())
                        });
                    }
                });

                // Show/hide password toggle
                $(document).on('click', '.mf-ls-toggle-pw', function() {
                    var targetId = $(this).data('target');
                    var $input   = $('#' + targetId);
                    var $icon    = $(this).find('.dashicons');
                    if ($input.attr('type') === 'password') {
                        $input.attr('type', 'text');
                        $icon.removeClass('dashicons-visibility').addClass('dashicons-hidden');
                    } else {
                        $input.attr('type', 'password');
                        $icon.removeClass('dashicons-hidden').addClass('dashicons-visibility');
                    }
                });

                $testBtn.on('click', function() {
                    $statusMsg.text('<?php echo esc_js(__('Testing...', 'metform-pro')); ?>');
                    $statusMsg.css('color', '');
                    $.post(ajaxurl, {
                        action:      'mf_leadsquared_test_connection',
                        nonce:       lsNonce,
                        data_center: $('#mf_leadsquared_data_center').val(),
                        access_key:  $.trim($('#mf_leadsquared_access_key').val()),
                        secret_key:  $.trim($('#mf_leadsquared_secret_key').val())
                    }, function(response) {
                        $statusMsg.text(response.data || '');
                        $statusMsg.css('color', response.success ? 'green' : 'red');
                    }).fail(function() {
                        $statusMsg.text('<?php echo esc_js(__('Request failed.', 'metform-pro')); ?>');
                        $statusMsg.css('color', 'red');
                    });
                });
            });
        </script>
        <?php
    }

    public function save_settings() {
        if (!isset($_POST['nonce'])
            || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'mf_leadsquared_settings')
            || !current_user_can('manage_options')
        ) {
            wp_send_json_error(esc_html__("You're not permitted", 'metform-pro'));
        }

        $data_center = isset($_POST['data_center']) ? sanitize_text_field(wp_unslash($_POST['data_center'])) : 'in21';

        $allowed_data_centers = array_keys(self::$data_centers);
        if (!in_array($data_center, $allowed_data_centers, true)) {
            $data_center = 'in21';
        }

        $access_key = isset($_POST['access_key']) ? preg_replace('/\s+/', '', $_POST['access_key']) : '';
        $secret_key = isset($_POST['secret_key']) ? preg_replace('/\s+/', '', $_POST['secret_key']) : '';

        update_option('mf_leadsquared_data_center', $data_center);
        update_option('mf_leadsquared_access_key', $access_key);
        update_option('mf_leadsquared_secret_key', $secret_key);

        wp_send_json_success(esc_html__('Settings saved successfully.', 'metform-pro'));
    }

    public function test_connection() {
        if (!isset($_POST['nonce'])
            || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'mf_leadsquared_settings')
            || !current_user_can('manage_options')
        ) {
            wp_send_json_error(esc_html__("You're not permitted", 'metform-pro'));
        }

        $access_key  = isset($_POST['access_key'])  ? preg_replace('/\s+/', '', $_POST['access_key'])  : get_option('mf_leadsquared_access_key');
        $secret_key  = isset($_POST['secret_key'])  ? preg_replace('/\s+/', '', $_POST['secret_key'])  : get_option('mf_leadsquared_secret_key');

        $data_center = isset($_POST['data_center']) ? sanitize_text_field(wp_unslash($_POST['data_center'])) : get_option('mf_leadsquared_data_center', 'in21');

        $allowed_data_centers = array_keys(self::$data_centers);
        if (!in_array($data_center, $allowed_data_centers, true)) {
            $data_center = 'in21';
        }

        if (empty($access_key) || empty($secret_key)) {
            wp_send_json_error(esc_html__('Please enter your Access Key and Secret Key.', 'metform-pro'));
            return;
        }

        $leadsquared = new Leadsquared();
        $base_url    = $leadsquared->get_api_base_url_for($data_center);
        $test_url    = $base_url . '/v2/LeadManagement.svc/Leads.GetByEmailAddress'
                     . '?accessKey=' . urlencode($access_key)
                     . '&secretKey=' . urlencode($secret_key)
                     . '&emailAddress=' . urlencode('test@test.com');

        $response = wp_remote_get($test_url, [
            'timeout' => 15,
            'headers' => [
                'Content-Type' => 'application/json',
            ],
        ]);

        if (is_wp_error($response)) {
            wp_send_json_error($response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);

        if ($code === 200 || $code === 404) {
            wp_send_json_success(esc_html__('Connection successful! Your credentials are valid.', 'metform-pro'));
        }

        if ($code === 401 || $code === 403) {
            wp_send_json_error(esc_html__('Invalid credentials. Please check your Access Key and Secret Key.', 'metform-pro'));
        }

        wp_send_json_error(
            sprintf(
                /* translators: %d: HTTP response code */
                esc_html__('Unexpected response (HTTP %d). Please verify your data center and credentials.', 'metform-pro'),
                $code
            )
        );
    }

    public function get_attributes() {
        $nonce = isset( $_SERVER['HTTP_X_WP_NONCE'] )
            ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_WP_NONCE'] ) )
            : '';

        if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
            wp_send_json_error( esc_html__( 'Nonce mismatch.', 'metform-pro' ) );
            return;
        }

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( esc_html__( 'Access denied.', 'metform-pro' ) );
            return;
        }

        $access_key = get_option( 'mf_leadsquared_access_key' );
        $secret_key = get_option( 'mf_leadsquared_secret_key' );

        if ( empty( $access_key ) || empty( $secret_key ) ) {
            wp_send_json_error( esc_html__( 'No credentials saved.', 'metform-pro' ) );
            return;
        }

        // Default fields always shown even if API call fails
        $default_fields = [
            [ 'value' => 'FirstName',      'label' => 'First Name' ],
            [ 'value' => 'LastName',       'label' => 'Last Name' ],
            [ 'value' => 'EmailAddress',   'label' => 'Email Address' ],
            [ 'value' => 'Phone',          'label' => 'Phone' ],
            [ 'value' => 'Mobile',         'label' => 'Mobile' ],
            [ 'value' => 'Company',        'label' => 'Company' ],
            [ 'value' => 'Website',        'label' => 'Website' ],
            [ 'value' => 'JobTitle',       'label' => 'Job Title' ],
            [ 'value' => 'Industry',       'label' => 'Industry' ],
            [ 'value' => 'Source',         'label' => 'Source' ],
            [ 'value' => 'SourceCampaign', 'label' => 'Source Campaign' ],
            [ 'value' => 'SourceMedium',   'label' => 'Source Medium' ],
            [ 'value' => 'Notes',          'label' => 'Notes' ],
            [ 'value' => 'DoNotEmail',     'label' => 'Do Not Email' ],
            [ 'value' => 'DoNotCall',      'label' => 'Do Not Call' ],
        ];

        $leadsquared = new Leadsquared();
        $base_url    = $leadsquared->get_api_base_url();

        // Fetch any one lead to read its field schema
        $probe_url = $base_url . '/v2/LeadManagement.svc/Leads.Get'
                   . '?accessKey=' . urlencode( $access_key )
                   . '&secretKey=' . urlencode( $secret_key );

        $probe_body = wp_json_encode( [
            'Parameter' => [ 'LookupName' => 'EmailAddress', 'LookupValue' => '' ],
            'Columns'   => [ 'Include_CSV' => 'ProspectID' ],
            'Sorting'   => [ 'ColumnName' => 'CreatedOn', 'Direction' => '0' ],
            'Paging'    => [ 'PageIndex' => 1, 'PageSize' => 1 ],
        ] );

        $probe_response = wp_remote_post( $probe_url, [
            'timeout' => 15,
            'headers' => [ 'Content-Type' => 'application/json' ],
            'body'    => $probe_body,
        ] );

        $prospect_id = '';
        if ( ! is_wp_error( $probe_response ) && wp_remote_retrieve_response_code( $probe_response ) === 200 ) {
            $probe_parsed = json_decode( wp_remote_retrieve_body( $probe_response ), true );
            if ( is_array( $probe_parsed ) && ! empty( $probe_parsed[0]['ProspectID'] ) ) {
                $prospect_id = $probe_parsed[0]['ProspectID'];
            }
        }

        if ( empty( $prospect_id ) ) {
            wp_send_json_success( $default_fields );
        }

        $url = $base_url . '/v2/LeadManagement.svc/Leads.GetById'
             . '?accessKey=' . urlencode( $access_key )
             . '&secretKey=' . urlencode( $secret_key )
             . '&id=' . urlencode( $prospect_id );

        $response = wp_remote_get( $url, [
            'timeout' => 15,
            'headers' => [ 'Content-Type' => 'application/json' ],
        ] );

        // Skip fields that are internal/system and not useful for form mapping
        $skip = [
            'ProspectID', 'ProspectAutoId', 'ProspectActivityId_Max', 'ProspectActivityId_Min',
            'StatusCode', 'StatusReason', 'DeletionStatusCode', 'IsLead', 'RelatedProspectId',
            'NotableEvent', 'NotableEventdate', 'LastVisitDate', 'RelatedLandingPageId',
            'FirstLandingPageSubmissionId', 'FirstLandingPageSubmissionDate',
            'ProspectActivityName_Max', 'ProspectActivityDate_Max', 'ProspectActivityDate_Min',
            'Web_Referrer', 'Web_RefKeyword', 'LeadLastModifiedOn', 'ConversionReferrerURL',
            'SourceReferrerURL', 'SourceIPAddress', 'Latitude', 'Longitude',
            'Score', 'EngagementScore', 'ProspectStage', 'QualityScore01',
            'OwnerId', 'CreatedBy', 'CreatedByName', 'CreatedOn', 'LeadConversionDate',
            'ModifiedBy', 'ModifiedByName', 'ModifiedOn', 'TotalVisits', 'PageViewsPerVisit',
            'AvgTimePerVisit', 'OwnerIdName', 'OwnerIdEmailAddress', 'Origin',
            'MailingPreferences', 'Groups', 'DoNotTrack', 'DoNotSMS', 'TimeZone',
            'TwitterId', 'PhotoUrl', 'FacebookId', 'LinkedInId', 'SkypeId',
            'SourceReferrer', 'SourceContent',
        ];

        if ( is_wp_error( $response ) ) {
            wp_send_json_success( $default_fields );
        }

        $code = wp_remote_retrieve_response_code( $response );
        if ( $code !== 200 ) {
            wp_send_json_success( $default_fields );
        }

        $body   = wp_remote_retrieve_body( $response );
        $parsed = json_decode( $body, true );

        // No leads found — return defaults
        if ( ! is_array( $parsed ) || empty( $parsed ) ) {
            wp_send_json_success( $default_fields );
        }

        // Build attribute list from the first lead's keys
        $lead       = $parsed[0];
        $attributes = [];
        $seen       = [];

        foreach ( array_keys( $lead ) as $key ) {
            if ( in_array( $key, $skip, true ) ) {
                continue;
            }
            $label        = preg_replace( '/([a-z])([A-Z])/', '$1 $2', $key );
            $label        = str_replace( 'mx_', '', $label );
            $attributes[] = [
                'value' => sanitize_text_field( $key ),
                'label' => sanitize_text_field( $label ),
            ];
            $seen[] = $key;
        }

        // Merge in defaults for any standard field not already present
        foreach ( $default_fields as $df ) {
            if ( ! in_array( $df['value'], $seen, true ) ) {
                $attributes[] = $df;
            }
        }

        wp_send_json_success( $attributes );
    }
}

Integration::instance()->init();
