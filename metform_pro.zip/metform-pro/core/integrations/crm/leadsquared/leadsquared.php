<?php

namespace MetForm_Pro\Core\Integrations\Crm\Leadsquared;

defined('ABSPATH') || exit;

class Leadsquared {

    private static $data_centers = [
        'in21' => 'https://api-in21.leadsquared.com',
        'in22' => 'https://api-in22.leadsquared.com',
        'us11' => 'https://api-us11.leadsquared.com',
        'sg'   => 'https://api.leadsquared.com',
        'me61' => 'https://api-me61.leadsquared.com',
        'ir31' => 'https://api-ir31.leadsquared.com',
        'ca12' => 'https://api-ca12.leadsquared.com',
    ];

    public function capture_lead($form_id, $form_data, $form_settings, $attributes) {
        if (!isset($form_settings['mf_leadsquared']) || $form_settings['mf_leadsquared'] != '1') {
            return;
        }

        $access_key = get_option('mf_leadsquared_access_key');
        $secret_key = get_option('mf_leadsquared_secret_key');

        if (empty($access_key) || empty($secret_key)) {
            return;
        }

        $field_mapping = get_post_meta($form_id, 'mf_leadsquared_fields', true);
        $field_mapping = json_decode($field_mapping, true);

        if (!is_array($field_mapping) || empty($field_mapping)) {
            return;
        }

        $lead_data = [];

        foreach ($field_mapping as $mf_field => $ls_attribute) {
            if (!empty($ls_attribute) && isset($form_data[$mf_field])) {
                $lead_data[] = [
                    'Attribute' => sanitize_text_field($ls_attribute),
                    'Value'     => sanitize_text_field($form_data[$mf_field]),
                ];
            }
        }

        $static_fields = get_post_meta($form_id, 'mf_leadsquared_static', true);
        $static_fields = json_decode($static_fields, true);

        if (is_array($static_fields)) {
            foreach ($static_fields as $attr => $val) {
                if (!empty($attr)) {
                    $lead_data[] = [
                        'Attribute' => sanitize_text_field($attr),
                        'Value'     => sanitize_text_field($val),
                    ];
                }
            }
        }

        if (empty($lead_data)) {
            return;
        }

        $base_url = $this->get_api_base_url();
        $url = $base_url . '/v2/LeadManagement.svc/Lead.Capture'
             . '?accessKey=' . urlencode($access_key)
             . '&secretKey=' . urlencode($secret_key);

        $request_body = wp_json_encode($lead_data);

        $response = wp_remote_post($url, [
            'timeout' => 30,
            'headers' => [
                'Content-Type' => 'application/json',
            ],
            'body' => $request_body,
        ]);

        $msg = [];

        if (is_wp_error($response)) {
            $msg['status'] = 0;
            $msg['msg']    = $response->get_error_message();
        } else {
            $code = wp_remote_retrieve_response_code($response);
            $msg['status'] = ($code >= 200 && $code < 300) ? 1 : 0;
            $msg['msg']    = ($msg['status'] === 1)
                ? esc_html__('Lead captured on LeadSquared.', 'metform-pro')
                : esc_html__('LeadSquared API error.', 'metform-pro');
        }

        return $msg;
    }

    public function get_api_base_url() {
        return $this->get_api_base_url_for( get_option('mf_leadsquared_data_center', 'in21') );
    }

    public function get_api_base_url_for( $data_center ) {
        if (!isset(self::$data_centers[$data_center])) {
            $data_center = 'in21';
        }

        return self::$data_centers[$data_center];
    }
}
