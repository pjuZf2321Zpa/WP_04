<?php

namespace MetForm_Pro\Core\Integrations\Email\Mailchimp;

defined('ABSPATH') || exit;

/**
 * GET metform-pro/v1/mailchimp/store_list/{form_id}  fetch the audiences from Mailchimp and cache them
 * GET metform-pro/v1/mailchimp/get_list/{form_id}    read the cached audiences
 *
 * The base class limits both routes to users with manage_options.
 */
class Api extends \MetForm_Pro\Base\Api
{
	public function config()
	{
		$this->prefix = 'mailchimp';
		$this->param  = '/(?P<id>\d+)';
	}

	public function get_get_list()
	{
		if (!current_user_can('manage_options')) {
			return;
		}

		$post_id = absint($this->request['id']);

		return get_option('wpmet_get_mailchimp_list_' . $post_id);
	}

	public function get_store_list()
	{
		$nonce = $this->request->get_header('X-WP-Nonce');

		if (!current_user_can('manage_options')) {
			return;
		}

		if (!wp_verify_nonce($nonce, 'wp_rest')) {
			return [
				'status'  => 'fail',
				'message' => [__('Nonce mismatch.', 'metform-pro')],
			];
		}

		$post_id = absint($this->request['id']);
		$data    = \MetForm\Core\Forms\Action::instance()->get_all_data($post_id);
		$api_key = isset($data['mf_mailchimp_api_key']) ? $data['mf_mailchimp_api_key'] : '';

		if (!preg_match('/^[a-z0-9]{32}-[a-z0-9]{3,4}$/', $api_key)) {
			return [
				'status'  => 'fail',
				'message' => [__('Invalid_api_key.', 'metform-pro')],
			];
		}

		$mailchimp_list = json_decode(wp_remote_retrieve_body(Mail_Chimp::get_list($api_key)));

		update_option('wpmet_get_mailchimp_list_' . $post_id, $mailchimp_list);

		return get_option('wpmet_get_mailchimp_list_' . $post_id, $mailchimp_list);
	}
}
