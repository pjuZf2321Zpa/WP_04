<?php

namespace MetForm_Pro\Core\Integrations\Email\Mailchimp;

use MetForm\Utils\Util;
use MetForm_Pro\Traits\Singleton;

defined('ABSPATH') || exit;

if (!defined('METFORM_PRO_FEATURE_HOOKS')) {
	return; // Older MetForm free still runs this integration itself.
}

/**
 * Mailchimp: subscribe the submitter to the audience chosen in the form settings.
 */
class Integration
{
	use Singleton;

	public function init()
	{
		new Api();

		add_action('metform/form_settings/slot/mailchimp', [$this, 'render_settings']);
		add_action('metform/entries/submit/integrations', [$this, 'subscribe'], 10, 2);
	}

	/**
	 * @param object $response The submit response free sends back to the browser.
	 * @param array  $context  Submission context, see free `Entries\Action::get_hook_context()`.
	 */
	public function subscribe($response, $context)
	{
		$form_settings = isset($context['form_settings']) && is_array($context['form_settings']) ? $context['form_settings'] : [];
		$form_data     = isset($context['form_data']) && is_array($context['form_data']) ? $context['form_data'] : [];
		$fields        = isset($context['fields']) && is_array($context['fields']) ? $context['fields'] : [];
		$email_name    = isset($context['email_name']) ? $context['email_name'] : null;

		if (!isset($form_settings['mf_mail_chimp']) || $form_settings['mf_mail_chimp'] != '1') {
			return;
		}

		if ($email_name == null || !isset($form_data[$email_name]) || $form_data[$email_name] == '') {
			return;
		}

		// The form has a "Listing Opt-in" field and the visitor did not tick it.
		if (array_key_exists('mf-listing-optin', $fields) && !isset($form_data['mf-listing-optin'])) {
			return;
		}

		$mail_chimp = new Mail_Chimp();
		$result     = $mail_chimp->call_api($form_data, ['auth' => $form_settings, 'email_name' => $email_name]);

		$response->status = isset($result['status']) ? $result['status'] : 0;
		if ($response->status == 0) {
			$response->failure_type = 'integration';
			$response->error        = [esc_html__('Problem with your mailchimp integration.', 'metform-pro')];
		}
	}

	public function render_settings()
	{
		$refresh_icon_path = '<path fill="#4D4E50" d="M13.425 3.774A6.25 6.25 0 0 0 10.704.781 6.72 6.72 0 0 0 6.712.055 6.313 6.313 0 0 0 3.084 1.87L1.27 3.593V1.325A.715.715 0 0 0 .544.6C.091.6 0 .962 0 1.325v4.082c0 .09.09.09.09.09s0 .091.091.091l.091.091.09.09h4.083c.363 0 .725-.271.725-.634s-.362-.726-.725-.726H2.358l1.724-1.633c.726-.725 1.814-1.27 2.812-1.45 1.088-.182 2.177.09 3.175.543.907.545 1.723 1.361 2.177 2.359.453.998.544 2.086.272 3.175a5.26 5.26 0 0 1-1.633 2.72c-.816.817-1.905 1.27-2.993 1.27-1.089.091-2.177-.271-3.084-.816-.908-.635-1.633-1.45-1.996-2.54-.09-.272-.454-.544-.816-.362-.363.09-.545.544-.363.816.453 1.27 1.36 2.45 2.449 3.175 1.088.726 2.268 1.088 3.538 1.088h.362c1.361-.09 2.722-.634 3.72-1.542 1.088-.907 1.814-2.086 2.086-3.447a5.573 5.573 0 0 0-.363-3.99Z"/>';
		?>
		<div class="mf-box-style">
			<div class="mf-input-group">
				<label class="attr-input-label">
					<input type="checkbox" value="1" name="mf_mail_chimp" class="mf-admin-control-input mf-form-modalinput-mail_chimp">
					<span><?php esc_html_e('Mail Chimp:', 'metform-pro'); ?></span>
				</label>
				<span class='mf-input-help'><?php esc_html_e('Integrate mailchimp with this form. ', 'metform-pro'); ?><strong><?php esc_html_e('This form must include at least one required Email field. ', 'metform-pro'); ?><a target="_blank" href="<?php echo esc_url(get_dashboard_url() . 'admin.php?page=metform-menu-settings#mf-newsletter_integration'); ?>"><?php esc_html_e('Configure Mail Chimp.', 'metform-pro'); ?></a></strong></span>
			</div>

			<div class="mf-input-group mf-mailchimp mf-form-top-spacing" style="margin-bottom: 4px;">
				<label for="attr-input-label" class="attr-input-label">
					<span><?php esc_html_e('MailChimp List ID:', 'metform-pro'); ?></span>
					<span class="refresh-icon">
						<svg xmlns="http://www.w3.org/2000/svg" width="14" height="13" fill="none" class="metfrom-btn-refresh-mailchimp-list">
							<?php Util::metform_content_renderer($refresh_icon_path); ?>
						</svg>
					</span>
				</label>

				<select class="attr-form-control mailchimp_list">

				</select>
				<input type="hidden" name="mf_mailchimp_list_id" class="mf-mailchimp-list-id attr-form-control" placeholder="<?php esc_attr_e('Mailchimp contact list id', 'metform-pro'); ?>">
			</div>
		</div>
		<?php
	}
}

Integration::instance()->init();
