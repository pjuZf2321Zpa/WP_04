<?php
/**
 * Handles Stripe payment workflows.
 *
 * @package MetForm_Pro
 */

namespace MetForm_Pro\Core\Integrations\Payment;

defined('ABSPATH') || exit;

/**
 * Creates Stripe PaymentIntents for MetForm entries.
 *
 * @since 1.0.0
 */
class Stripe
{
    use \MetForm\Traits\Singleton;

	/**
	 * Stores the singleton instance.
	 *
	 * @since 1.0.0
	 * @var Stripe|null
	 */
	private static $instance;

	/**
	 * Stores the active Stripe secret key.
	 *
	 * @since 1.0.0
	 * @var string|null
	 */
	private $live_keys = null;

	/**
	 * Stores the form ID metadata key.
	 *
	 * @since 1.0.0
	 * @var string
	 */
	private $key_form_id;

	/**
	 * Stores the form data metadata key.
	 *
	 * @since 1.0.0
	 * @var string
	 */
	private $key_form_data;

	/**
	 * Stores the payment status metadata key.
	 *
	 * @since 1.0.0
	 * @var string
	 */
	private $key_payment_status;

	/**
	 * Stores the payment invoice metadata key.
	 *
	 * @since 1.0.0
	 * @var string
	 */
	private $key_payment_invoice;

	/**
	 * Stores the current entry ID.
	 *
	 * @since 1.0.0
	 * @var int|string
	 */
	private $entry_id;

	/**
	 * Stores the current form ID.
	 *
	 * @since 1.0.0
	 * @var int|string
	 */
	private $form_id;

	/**
	 * Stores the submitted form data.
	 *
	 * @since 1.0.0
	 * @var array
	 */
	private $form_data;

	/**
	 * Stores the current form settings.
	 *
	 * @since 1.0.0
	 * @var array
	 */
	private $form_settings;

	/**
	 * Stores payment widget input names.
	 *
	 * @since 1.0.0
	 * @var array|string
	 */
	private $payment_input_name;

	/**
	 * Stores the current payment status.
	 *
	 * @since 1.0.0
	 * @var string
	 */
	private $payment_status;

	/**
	 * Stores mapped form field data.
	 *
	 * @since 1.0.0
	 * @var array|string
	 */
	private $map_data;

	/**
	 * Stores the payment first-name field.
	 *
	 * @since 1.0.0
	 * @var array|string
	 */
	private $payment_first_name;

	/**
	 * Stores the payment last-name field.
	 *
	 * @since 1.0.0
	 * @var array|string
	 */
	private $payment_last_name;

	/**
	 * Initializes payment metadata keys.
	 *
	 * @since 1.0.0
	 */
    public function __construct()
    {
        $this->key_form_id = 'metform_entries__form_id';
        $this->key_form_data = 'metform_entries__form_data';
        //$this->key_form_settings = 'metform_form__form_setting';
        $this->key_payment_status = 'metform_entries__payment_status';
        $this->key_payment_invoice = 'metform_entries__payment_invoice';
    }

	/**
	 * Processes a Stripe payment action for an entry.
	 *
	 * @since 1.0.0
	 *
	 * @param array $args Payment route arguments.
	 * @return array|string Payment response or configuration error message.
	 */
    public function init(array $args)
    {

        $this->entry_id = $args['entry_id'];

        $type = $args['action'];

        $token = isset($args['token']) ? $args['token'] : '';
        if (empty($token)) {
            return esc_html__('Invalid payment token.', 'metform-pro');
        }

        $this->form_data = get_post_meta($this->entry_id, $this->key_form_data, true);

        $this->form_id = get_post_meta($this->entry_id, $this->key_form_id, true);

        $this->payment_status = get_post_meta($this->entry_id, $this->key_payment_status, true);

        $this->map_data = '';
        $this->payment_input_name = '';
        $this->payment_first_name = '';
        $this->payment_last_name = '';

        // metform loaded
        if (did_action('metform/after_load')) {
            $this->form_settings = \MetForm\Core\Forms\Action::instance()->get_all_data($this->form_id);
            $this->map_data = \MetForm\Core\Entries\Action::instance()->get_fields($this->form_id);
            $this->payment_input_name = \MetForm\Core\Entries\Action::instance()->get_input_name_by_widget_type('mf-payment-method', $this->map_data);
            $this->payment_first_name = \MetForm\Core\Entries\Action::instance()->get_input_name_by_widget_type('mf-listing-fname', $this->map_data);
            $this->payment_last_name = \MetForm\Core\Entries\Action::instance()->get_input_name_by_widget_type('mf-listing-lname', $this->map_data);
        }

        // check payment status
        if ($this->payment_status == 'paid') {
            return esc_html__('Already has been payment received.', 'metform-pro');
        }

        // check payment method enable
        if (!$this->form_settings['mf_stripe']) {
            return esc_html__('Please enable payment method to form settings.', 'metform-pro');
        }

        $widget = is_array($this->payment_input_name) ? current($this->payment_input_name) : '';

        $amount_filed = isset($this->map_data[$widget]->mf_input_payment_field_name) ? $this->map_data[$widget]->mf_input_payment_field_name : '';

        $submitted_amount = isset($this->form_data[$amount_filed]) ? floatval($this->form_data[$amount_filed]) : 0;
        if (empty($submitted_amount) || $submitted_amount <= 0) {
            return esc_html__('Please set amount filed in payment widget.', 'metform-pro');
        }

        $expected_amount = \MetForm_Pro\Utils\Helper::calculate_expected_amount(
            $amount_filed,
            $this->map_data,
            $this->form_data,
            $this->payment_input_name
        );

        if ($expected_amount === false || $expected_amount <= 0) {
            return esc_html__('Invalid payment amount. Please try again.', 'metform-pro');
        }

        if (abs($submitted_amount - $expected_amount) > 0.01) {
            return esc_html__('Invalid payment amount. Please try again.', 'metform-pro');
        }

        $amount = (int) round($expected_amount * 100);

        // set key for check payment
        $livekey = isset($this->form_settings['mf_stripe_live_secret_key']) ? $this->form_settings['mf_stripe_live_secret_key'] : '';
        $livekey_test = isset($this->form_settings['mf_stripe_test_secret_key']) ? $this->form_settings['mf_stripe_test_secret_key'] : '';
        $sandbox = isset($this->form_settings['mf_stripe_sandbox']) ? true : false;

        $this->live_keys = ($sandbox) ? $livekey_test : $livekey;
        if (empty($this->live_keys)  || strlen($this->live_keys) < 6) {
            return esc_html__('Please set Stripe Secret Keys.', 'metform-pro');
        }

	    $currency = $this->form_settings['mf_payment_currency'] ?? 'USD';
	    $config['token'] = $token;
        $config['amount'] = $amount;
        $config['currency'] = $currency;
        $res = $this->stripe_verify($config);

        // success URl
        $success_url = get_site_url() . '/';
        if (isset($this->form_settings['success_url']) && filter_var($this->form_settings['success_url'], FILTER_VALIDATE_URL)) {
            $success_url = $this->form_settings['success_url'];
        }
        $url_success = [];
        $url_success['entry_id'] = $this->entry_id;
        $success_url = \MetForm_Pro\Utils\Helper::url_generate($success_url, $url_success);


        $settings = \MetForm\Core\Admin\Base::instance()->get_settings_option();

        if ($res['status']) {
            $txn_id = !empty($res['get']['invoice']) ? $res['get']['invoice'] : $res['get']['balance_transaction'];
            $txn_id = !empty($txn_id) ? $txn_id : $res['get']['id'];
            update_post_meta($this->entry_id, 'metform_entries__payment_trans', $txn_id);
            update_post_meta($this->entry_id, 'metform_entries__payment_trans_data', serialize($res['get']));
            update_post_meta($this->entry_id, 'metform_entries__payment_status', 'paid');

            if(isset($settings['mf_thank_you_page']) && !empty($settings['mf_thank_you_page'])){
                $redirect_url = get_page_link($settings['mf_thank_you_page']) . '?id=' . $this->entry_id;
            } else {
                $redirect_url = '';
            }
            

            return [
                'status' => 'success',
                'message' => esc_html__('Successfully payment received.', 'metform-pro'),
                'redirect_url' =>  $redirect_url,
                'data' => $res['get'],


            ];
        } else {
			if (isset($res['get']['status']) && 'canceled' === $res['get']['status']) {
				update_post_meta($this->entry_id, 'metform_entries__payment_status', 'failed');
			}

            // cancel URl
            if(isset($settings['mf_cancel_page']) && !empty($settings['mf_cancel_page'])){
                $cancel_url = get_page_link($settings['mf_cancel_page']) . '?id=' . $this->entry_id;
            } else {
                $cancel_url = '';
            }
            return [
                'status' => 'faild',
                'message' => $res['get'],
                'redirect_url' =>  $cancel_url,
            ];
        }
    }


	/**
	 * Creates and verifies a Stripe PaymentIntent.
	 *
	 * @since 1.0.0
	 *
	 * @param array $config Payment token, amount, and currency configuration.
	 * @return array Payment result and normalized provider data.
	 */
    public function stripe_verify($config)
    {
        $token = isset($config['token']) ? $config['token'] : '';
        $amount_cent = absint(isset($config['amount']) ? $config['amount'] : 0);
        $currency = strtolower(sanitize_key(isset($config['currency']) ? $config['currency'] : 'USD'));

        $client = new Stripe\PaymentClient($this->live_keys);
        $intent = $client->create_payment_intent(
            array(
                'amount' => $amount_cent,
                'currency' => $currency,
                'confirm' => 'true',
                'automatic_payment_methods' => array(
                    'enabled' => 'true',
                    'allow_redirects' => 'never',
                ),
                'payment_method_data' => array(
                    'type' => 'card',
                    'card' => array('token' => sanitize_text_field($token)),
                ),
                'metadata' => array(
                    'entry_id' => (string) $this->entry_id,
                    'form_id' => (string) $this->form_id,
                ),
            ),
            'mf-stripe-payment-' . $this->entry_id . '-' . substr(hash('sha256', $token), 0, 24)
        );

        if (is_wp_error($intent)) {
            return array('status' => false, 'get' => $intent->get_error_message());
        }

        $charge = isset($intent['charges']['data'][0]) ? $intent['charges']['data'][0] : array();
        $payment_data = array(
            'id' => isset($intent['id']) ? sanitize_text_field($intent['id']) : '',
            'livemode' => !empty($intent['livemode']),
            'amount' => isset($intent['amount']) ? absint($intent['amount']) : $amount_cent,
            'currency' => isset($intent['currency']) ? sanitize_key($intent['currency']) : $currency,
            'paid' => isset($intent['status']) && 'succeeded' === $intent['status'],
            'status' => isset($intent['status']) ? sanitize_key($intent['status']) : '',
            'refunded' => !empty($charge['refunded']),
            'amount_refunded' => isset($charge['amount_refunded']) ? absint($charge['amount_refunded']) : 0,
            'balance_transaction' => isset($charge['balance_transaction']) ? sanitize_text_field($charge['balance_transaction']) : '',
            'captured' => !empty($charge['captured']),
            'created' => isset($intent['created']) ? absint($intent['created']) : 0,
            'failure_code' => isset($intent['last_payment_error']['code']) ? sanitize_key($intent['last_payment_error']['code']) : '',
            'failure_message' => isset($intent['last_payment_error']['message']) ? sanitize_text_field($intent['last_payment_error']['message']) : '',
            'invoice' => isset($intent['invoice']) ? sanitize_text_field($intent['invoice']) : '',
        );

        return array(
            'status' => 'succeeded' === $payment_data['status'],
            'get' => $payment_data,
        );
    }

	/**
	 * Gets the singleton instance.
	 *
	 * @since 1.0.0
	 *
	 * @return Stripe Singleton instance.
	 */
    public static function instance()
    {
        if (!self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
}
