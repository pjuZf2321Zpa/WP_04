<?php
/**
 * Registers payment scripts and provider callbacks.
 *
 * @package MetForm_Pro
 */

namespace MetForm_Pro\Core\Integrations\Payment;

defined( 'ABSPATH' ) || exit;

/**
 * Processes asynchronous PayPal and Stripe payment notifications.
 *
 * @since 1.0.0
 */
class Process {

	/**
	 * Registers payment hooks.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
    public function __construct() {
		 add_action( 'wp_ajax_metforms-paypal-ipn', array( $this, 'paypal_ipn_listener') );
         add_action( 'wp_ajax_nopriv_metforms-paypal-ipn', array( $this, 'paypal_ipn_listener') );

         // script for stripe
         add_action( 'wp_enqueue_scripts', [$this, '_script' ] );
		 add_action( 'rest_api_init', array( $this, 'register_webhook_routes' ) );
	}

	/**
	 * Registers provider webhook REST routes.
	 *
	 * @since 4.1.0
	 *
	 * @return void
	 */
	public function register_webhook_routes() {
		register_rest_route( 'metform/v1', '/payment/stripe/webhook', array(
			'methods' => 'POST',
			'callback' => array( $this, 'stripe_webhook' ),
			'permission_callback' => '__return_true',
		) );
	}

	/**
	 * Processes a Stripe webhook after HMAC verification.
	 *
	 * @since 4.1.0
	 *
	 * @param \WP_REST_Request $request Webhook REST request.
	 * @return \WP_REST_Response Webhook acknowledgement response.
	 */
	public function stripe_webhook( \WP_REST_Request $request ) {
		$payload = $request->get_body();
		$decoded = json_decode( $payload, true );
		$entry_id = isset( $decoded['data']['object']['metadata']['entry_id'] ) ? absint( $decoded['data']['object']['metadata']['entry_id'] ) : 0;
		if ( ! $entry_id || empty( $decoded['id'] ) ) {
			return new \WP_REST_Response( null, 400 );
		}
		$form_id = absint( get_post_meta( $entry_id, 'metform_entries__form_id', true ) );
		$settings = \MetForm\Core\Forms\Action::instance()->get_all_data( $form_id );
		$sandbox = ! empty( $settings['mf_stripe_sandbox'] );
		$key = $sandbox ? 'mf_stripe_test_webhook_secret' : 'mf_stripe_live_webhook_secret';
		$secret = isset( $settings[ $key ] ) ? $settings[ $key ] : '';
		if ( empty( $secret ) ) {
			return new \WP_REST_Response( null, 400 );
		}
		$verifier = new Stripe\WebhookVerifier();
		$event = $verifier->verify( $payload, $request->get_header( 'stripe-signature' ), $secret );
		if ( is_wp_error( $event ) ) {
			return new \WP_REST_Response( null, 400 );
		}
		$event_key = 'mf_stripe_event_' . sanitize_key( $event['id'] );
		if ( get_transient( $event_key ) ) {
			return new \WP_REST_Response( null, 200 );
		}
		set_transient( $event_key, 1, WEEK_IN_SECONDS );
		if ( 'payment_intent.succeeded' === $event['type'] ) {
			update_post_meta( $entry_id, 'metform_entries__payment_status', 'paid' );
			update_post_meta( $entry_id, 'metform_entries__payment_trans', sanitize_text_field( $event['data']['object']['id'] ) );
		} elseif ( in_array( $event['type'], array( 'payment_intent.canceled', 'payment_intent.payment_failed' ), true ) ) {
			update_post_meta( $entry_id, 'metform_entries__payment_status', 'failed' );
		}
		return new \WP_REST_Response( null, 200 );
	}

	/**
	 * Processes the legacy PayPal IPN callback.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	 public function paypal_ipn_listener() {
        $form_id  = !empty($_REQUEST['form_id']) ? absint($_REQUEST['form_id']) : 0;
        $entry_id = !empty($_REQUEST['entry_id']) ? absint($_REQUEST['entry_id']) : 0;
		$form_settings = array();

        // metform loaded
        if( did_action( 'metform/after_load' ) ){
            $form_settings = \MetForm\Core\Forms\Action::instance()->get_all_data($form_id);
        }

        $ipn = new Ipn\PaypalIpn();

        if( !empty($form_settings['mf_paypal_sandbox']) ){
            $ipn->useSandbox();
        }
        $verified = $ipn->verifyIPN();

        $txn_id = !empty($_REQUEST['txn_id']) ? sanitize_text_field(wp_unslash($_REQUEST['txn_id'])) : '';
		$receiver_email = !empty($_REQUEST['receiver_email']) ? sanitize_email(wp_unslash($_REQUEST['receiver_email'])) : '';
		$expected_email = isset($form_settings['mf_paypal_email']) ? sanitize_email($form_settings['mf_paypal_email']) : '';
		$item_number = !empty($_REQUEST['item_number']) ? absint($_REQUEST['item_number']) : 0;
		$payment_status = !empty($_REQUEST['payment_status']) ? sanitize_key(wp_unslash($_REQUEST['payment_status'])) : '';
		$replayed = $txn_id && get_transient('mf_paypal_ipn_' . sanitize_key($txn_id));

		if ( $verified && $txn_id && ! $replayed && $entry_id === $item_number && 'completed' === strtolower($payment_status) && $expected_email && hash_equals(strtolower($expected_email), strtolower($receiver_email)) ) {
            $sanitized_request = array_map('sanitize_text_field', array_map('wp_unslash', $_REQUEST));
            update_post_meta( $entry_id, 'metform_entries__payment_trans', $txn_id);
            update_post_meta( $entry_id, 'metform_entries__payment_trans_data', serialize($sanitized_request));
            update_post_meta( $entry_id, 'metform_entries__payment_status', 'paid');
			set_transient('mf_paypal_ipn_' . sanitize_key($txn_id), 1, WEEK_IN_SECONDS);
        }

        header("HTTP/1.1 200 OK");

        return;
    }

	/**
	 * Registers the provider-hosted Stripe Checkout script.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
    public function _script(){
		// Registers the provider-hosted payment script.
		wp_register_script( 'stripe-checkout', 'https://checkout.stripe.com/checkout.js', array('jquery'), '1.0.0', false);	
	}
}
