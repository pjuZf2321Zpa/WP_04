<?php
/**
 * Verifies Stripe webhook signatures.
 *
 * @package MetForm_Pro
 */

namespace MetForm_Pro\Core\Integrations\Payment\Stripe;

defined( 'ABSPATH' ) || exit;

/**
 * Verifies Stripe webhook signatures without a provider SDK.
 *
 * @since 4.1.0
 */
class WebhookVerifier {

	/**
	 * Maximum accepted webhook age in seconds.
	 *
	 * @since 4.1.0
	 * @var int
	 */
	const TOLERANCE = 300;

	/**
	 * Verifies and decodes a Stripe webhook payload.
	 *
	 * @since 4.1.0
	 *
	 * @param string   $payload          Raw request body.
	 * @param string   $signature_header Stripe-Signature header value.
	 * @param string   $secret           Webhook signing secret.
	 * @param int|null $now              Optional current Unix timestamp for testing.
	 * @return array|\WP_Error Decoded event on success, otherwise an error.
	 */
	public function verify( $payload, $signature_header, $secret, $now = null ) {
		$parts = array();
		foreach ( explode( ',', (string) $signature_header ) as $item ) {
			$pair = explode( '=', trim( $item ), 2 );
			if ( 2 === count( $pair ) ) {
				$parts[ $pair[0] ][] = $pair[1];
			}
		}

		$timestamp = isset( $parts['t'][0] ) ? absint( $parts['t'][0] ) : 0;
		$now       = null === $now ? time() : absint( $now );
		if ( ! $timestamp || abs( $now - $timestamp ) > self::TOLERANCE ) {
			return new \WP_Error( 'stripe_webhook_timestamp', __( 'Invalid webhook timestamp.', 'metform-pro' ) );
		}

		$expected = hash_hmac( 'sha256', $timestamp . '.' . $payload, $secret );
		$valid    = false;
		foreach ( isset( $parts['v1'] ) ? $parts['v1'] : array() as $signature ) {
			if ( hash_equals( $expected, $signature ) ) {
				$valid = true;
				break;
			}
		}
		if ( ! $valid ) {
			return new \WP_Error( 'stripe_webhook_signature', __( 'Invalid webhook signature.', 'metform-pro' ) );
		}

		$event = json_decode( $payload, true );
		return is_array( $event ) ? $event : new \WP_Error( 'stripe_webhook_payload', __( 'Invalid webhook payload.', 'metform-pro' ) );
	}
}
