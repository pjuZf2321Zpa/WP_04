<?php
/**
 * Handles Stripe REST API requests.
 *
 * @package MetForm_Pro
 */

namespace MetForm_Pro\Core\Integrations\Payment\Stripe;

defined( 'ABSPATH' ) || exit;

/**
 * Handles Stripe REST API communication through the WordPress HTTP API.
 *
 * @since 4.1.0
 */
class PaymentClient {

	/**
	 * Stripe API base URL.
	 *
	 * @since 4.1.0
	 * @var string
	 */
	const API_URL = 'https://api.stripe.com/v1/';

	/**
	 * HTTP request timeout in seconds.
	 *
	 * @since 4.1.0
	 * @var int
	 */
	const TIMEOUT = 15;

	/**
	 * Stripe secret API key.
	 *
	 * @since 4.1.0
	 * @var string
	 */
	private $secret_key;

	/**
	 * Constructs the Stripe payment client.
	 *
	 * @since 4.1.0
	 *
	 * @param string $secret_key Stripe secret API key.
	 */
	public function __construct( $secret_key ) {
		$this->secret_key = (string) $secret_key;
	}

	/**
	 * Creates and confirms a PaymentIntent using a provider token.
	 *
	 * @since 4.1.0
	 *
	 * @param array  $data            Request fields.
	 * @param string $idempotency_key Stable key for this entry and operation.
	 * @return array|\WP_Error PaymentIntent data on success, otherwise an error.
	 */
	public function create_payment_intent( array $data, $idempotency_key ) {
		return $this->request( 'POST', 'payment_intents', $data, $idempotency_key );
	}

	/**
	 * Retrieves a PaymentIntent.
	 *
	 * @since 4.1.0
	 *
	 * @param string $intent_id PaymentIntent identifier.
	 * @return array|\WP_Error PaymentIntent data on success, otherwise an error.
	 */
	public function get_payment_intent( $intent_id ) {
		return $this->request( 'GET', 'payment_intents/' . rawurlencode( $intent_id ) );
	}

	/**
	 * Creates a refund.
	 *
	 * @since 4.1.0
	 *
	 * @param array  $data            Refund request fields.
	 * @param string $idempotency_key Stable key for the refund operation.
	 * @return array|\WP_Error Refund data on success, otherwise an error.
	 */
	public function create_refund( array $data, $idempotency_key ) {
		return $this->request( 'POST', 'refunds', $data, $idempotency_key );
	}

	/**
	 * Sends a Stripe API request.
	 *
	 * @since 4.1.0
	 *
	 * @param string $method          HTTP request method.
	 * @param string $path            API path relative to the Stripe base URL.
	 * @param array  $data            Optional request fields.
	 * @param string $idempotency_key Optional idempotency key.
	 * @return array|\WP_Error Decoded provider response on success, otherwise an error.
	 */
	public function request( $method, $path, array $data = array(), $idempotency_key = '' ) {
		$headers = array(
			'Authorization' => 'Bearer ' . $this->secret_key,
			'Content-Type'  => 'application/x-www-form-urlencoded',
		);

		if ( '' !== $idempotency_key ) {
			$headers['Idempotency-Key'] = sanitize_key( $idempotency_key );
		}

		$args = array(
			'method'      => $method,
			'timeout'     => self::TIMEOUT,
			'redirection' => 0,
			'sslverify'   => true,
			'headers'     => $headers,
		);

		if ( 'GET' !== $method ) {
			$args['body'] = http_build_query( $data, '', '&' );
		}

		$response = wp_remote_request( self::API_URL . ltrim( $path, '/' ), $args );
		if ( is_wp_error( $response ) ) {
			return new \WP_Error( 'stripe_connection_error', __( 'The payment provider could not be reached. Please try again.', 'metform-pro' ) );
		}

		$status = wp_remote_retrieve_response_code( $response );
		$body   = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( $status < 200 || $status >= 300 || ! is_array( $body ) ) {
			$message = isset( $body['error']['message'] ) ? sanitize_text_field( $body['error']['message'] ) : __( 'The payment provider rejected the request.', 'metform-pro' );
			$code    = isset( $body['error']['code'] ) ? sanitize_key( $body['error']['code'] ) : 'provider_error';
			return new \WP_Error( 'stripe_' . $code, $message, array( 'status' => $status ) );
		}

		return $body;
	}
}
