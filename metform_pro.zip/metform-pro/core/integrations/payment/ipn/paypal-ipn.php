<?php
/**
 * Verifies legacy PayPal IPN callbacks.
 *
 * @package MetForm_Pro
 */

namespace MetForm_Pro\Core\Integrations\Payment\Ipn;

/**
 * Verifies PayPal IPN messages through the WordPress HTTP API.
 *
 * @since 1.0.0
 */
class PaypalIpn {
	/**
	 * Whether to use the PayPal sandbox.
	 *
	 * @since 1.0.0
	 * @var bool
	 */
    private $use_sandbox = false;

	/**
	 * Legacy local-certificate preference.
	 *
	 * @since 1.0.0
	 * @var bool
	 */
    private $use_local_certs = true;

	/**
	 * PayPal production IPN verification URL.
	 *
	 * @since 1.0.0
	 * @var string
	 */
     const VERIFY_URI = 'https://ipnpb.paypal.com/cgi-bin/webscr';

	/**
	 * PayPal sandbox IPN verification URL.
	 *
	 * @since 1.0.0
	 * @var string
	 */
     const SANDBOX_VERIFY_URI = 'https://ipnpb.sandbox.paypal.com/cgi-bin/webscr';

	/**
	 * PayPal response returned for a valid IPN message.
	 *
	 * @since 1.0.0
	 * @var string
	 */
     const VALID = 'VERIFIED';

	/**
	 * PayPal response returned for an invalid IPN message.
	 *
	 * @since 1.0.0
	 * @var string
	 */
     const INVALID = 'INVALID';

	/**
	 * Enables PayPal sandbox verification.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
     public function useSandbox()
     {
         $this->use_sandbox = true;
     }
 
	/**
	 * Gets the PayPal IPN verification URL.
	 *
	 * @since 1.0.0
	 *
	 * @return string PayPal IPN verification URL.
	 */
     public function getPaypalUri()
     {
         if ($this->use_sandbox) {
             return self::SANDBOX_VERIFY_URI;
         } else {
             return self::VERIFY_URI;
         }
     }
 
	/**
	 * Disables the legacy local-certificate preference.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
     public function usePHPCerts()
    {
        $this->use_local_certs = false;
    }

	/**
	 * Verifies the current PayPal IPN request.
	 *
	 * @since 1.0.0
	 *
	 * @return bool Whether PayPal verified the IPN message.
	 */
     public function verifyIPN()
     {
         if ( ! count($_POST)) {
			 return false;
         }
 
         $raw_post_data = file_get_contents('php://input');
         $raw_post_array = explode('&', $raw_post_data);
         $myPost = array();
         foreach ($raw_post_array as $keyval) {
             $keyval = explode('=', $keyval);
             if (count($keyval) == 2) {
                 if ($keyval[0] === 'payment_date') {
                     if (substr_count($keyval[1], '+') === 1) {
                         $keyval[1] = str_replace('+', '%2B', $keyval[1]);
                     }
                 }
                 $myPost[$keyval[0]] = urldecode($keyval[1]);
             }
         }
 
         $req = 'cmd=_notify-validate';
         $get_magic_quotes_exists = false;
         if (function_exists('get_magic_quotes_gpc')) {
             $get_magic_quotes_exists = true;
         }
         foreach ($myPost as $key => $value) {
             if ($get_magic_quotes_exists == true && get_magic_quotes_gpc() == 1) {
                 $value = urlencode(stripslashes($value));
             } else {
                 $value = urlencode($value);
             }
             $req .= "&$key=$value";
         }
 
		 $response = wp_remote_request($this->getPaypalUri(), array(
			 'method' => 'POST',
			 'timeout' => 15,
			 'redirection' => 0,
			 'sslverify' => true,
			 'headers' => array('Content-Type' => 'application/x-www-form-urlencoded'),
			 'body' => $req,
		 ));
		 if (is_wp_error($response)) {
			 return false;
		 }
		 $http_code = wp_remote_retrieve_response_code($response);
		 if (200 !== $http_code) {
			 return false;
		 }
		 $res = wp_remote_retrieve_body($response);
        if (trim($res) === self::VALID) {
             return true;
         } else {
             return false;
         }
     }

}
