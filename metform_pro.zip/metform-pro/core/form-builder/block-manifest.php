<?php
namespace MetForm_Pro\Core\FormBuilder;

use MetForm\Core\FormBuilder\Block_Base;

defined( 'ABSPATH' ) || exit;

/**
 * Extends MetForm Free's Form Builder block manifest with Pro-only blocks.
 *
 * The filter is registered while Pro's plugin file loads, before Free
 * evaluates `metform/form_builder/blocks` on `plugins_loaded`.
 *
 * Next Step / Prev Step / Progress Step remain in the Free plugin. All block
 * definitions below remain owned and autoloaded by MetForm Pro.
 */
final class Block_Manifest {
	/**
	 * Registers the Pro extension of Free's block manifest.
	 *
	 * @return void
	 */
	public function init(): void {
		add_filter( 'metform/form_builder/blocks', array( $this, 'append_blocks' ) );
	}

	/**
	 * Appends Pro-only block instances in their existing menu order.
	 *
	 * @param Block_Base[] $blocks Registered Free block instances.
	 *
	 * @return Block_Base[] Combined Free and Pro block instances.
	 */
	public function append_blocks( array $blocks ): array {
		$pro_blocks = array(
			new Blocks\Calculation\Calculation(),
			new Blocks\Colorpicker\Colorpicker(),
			new Blocks\Creditcard\Creditcard(),
			new Blocks\Imageselect\Imageselect(),
			new Blocks\Likedislike\Likedislike(),
			new Blocks\Maplocation\Maplocation(),
			new Blocks\Mobile\Mobile(),
			new Blocks\Paymentmethod\Paymentmethod(),
			new Blocks\Signature\Signature(),
			new Blocks\Simplerepeater\Simplerepeater(),
			new Blocks\TextEditor\TextEditor(),
			new Blocks\Toggleselect\Toggleselect(),
		);

		foreach ( $pro_blocks as $block ) {
			if ( $block instanceof Block_Base ) {
				$blocks[] = $block;
			}
		}

		return $blocks;
	}
}
