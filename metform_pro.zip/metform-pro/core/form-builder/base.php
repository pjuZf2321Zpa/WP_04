<?php
/**
 * MetForm Pro's Form Builder integration.
 *
 * @package MetForm_Pro\Core\FormBuilder
 */

namespace MetForm_Pro\Core\FormBuilder;

use MetForm\Core\FormBuilder\Block_Base;
use MetForm\Core\FormBuilder\Block_Registry;
use MetForm\Core\FormBuilder\Document\Repository;
use MetForm\Core\Forms\Action as Forms_Action;
use MetForm_Pro\Base\Assets_Enqueue;
use MetForm_Pro\Traits\Singleton;

defined( 'ABSPATH' ) || exit;

/**
 * Boots Pro block registration and asset integration for the Form Builder.
 *
 * @since 4.0.4
 */
final class Base {
	use Singleton;

	/**
	 * Extends Free's block manifest and wires Pro block asset hooks.
	 *
	 * Does nothing when the active MetForm (Free) has no standalone Form
	 * Builder — every Pro block extends Free's Block_Base and registers into
	 * its Block_Registry, so instantiating one there would fatal. This is
	 * feature-detected rather than version-checked: Free builds with and
	 * without the Form Builder have shipped under the same version number.
	 *
	 * @since 4.0.4
	 * @return void
	 */
	public function init(): void {
		( new Block_Manifest() )->init();

		add_action( 'metform/form_builder/frontend/enqueue_scripts', array( $this, 'enqueue_block_assets' ) );
		add_action( 'metform/form_builder/editor/enqueue_scripts', array( $this, 'enqueue_block_assets' ), 10, 2 );
		add_action( 'metform/form_builder/editor/enqueue_scripts', array( $this, 'enqueue_editor_canvas_style' ) );
		add_action(
			'elementor/preview/enqueue_scripts',
			function () {
				Assets_Enqueue::get_script( 'metform-pro-form-builder-frontend' );
			}
		);
		add_filter( 'metform/form_builder/extra_wrapper_attributes', array( $this, 'filter_wrapper_attributes' ), 10, 3 );
	}

	/**
	 * Injects data-save-progress="true" when enabled in form settings.
	 *
	 * @param string $extra_attributes Existing extra attributes string.
	 * @param int    $form_id          Form ID.
	 * @param array  $form_settings    Form settings.
	 * @return string
	 */
	public function filter_wrapper_attributes( string $extra_attributes, int $form_id, array $form_settings ): string {
		if ( ! empty( $form_settings['mf_save_progress'] ) ) {
			$extra_attributes .= ' data-save-progress="true"';
		}
		return $extra_attributes;
	}

	/**
	 * Enqueues get_frontend_assets() handles for Pro blocks used in the
	 * saved form document — or, when `$all_blocks` is set, for every
	 * registered Pro block regardless of what's currently saved.
	 *
	 * @since 4.0.4
	 *
	 * @param int  $form_id    Unused — accepted only because both hooks this
	 *                         is attached to pass one.
	 * @param bool $all_blocks Enqueue every registered Pro block's assets
	 *                         instead of only the ones used in the saved
	 *                         document.
	 *
	 * @return void
	 */
	public function enqueue_block_assets( $form_id = 0, bool $all_blocks = false ) {
		$form_settings = Forms_Action::instance()->get_all_data( absint( $form_id ) );
		if ( ! empty( $form_settings['mf_save_progress'] ) ) {
			Assets_Enqueue::get_script( 'metform-pro-save-progress' );
		}

		$document = Repository::get( absint( $form_id ) );
		$blocks   = $all_blocks
			? Block_Registry::instance()->all()
			: Block_Registry::instance()->used_in_document( is_array( $document ) ? $document : array() );
		foreach ( $blocks as $block ) {
			if ( 0 !== strpos( get_class( $block ), __NAMESPACE__ . '\\' ) ) {
				continue;
			}
			foreach ( $block->get_frontend_assets() as $handle ) {
				if ( 'stripe-checkout' === $handle ) {
					wp_enqueue_script( 'stripe-checkout' );
					continue;
				}
				Assets_Enqueue::get( $handle );
			}
		}
	}

	/**
	 * Enqueues the editor-canvas-only, #metform-builder-root-prefixed
	 * copy of every Pro block's CSS — see src/editor-canvas/style.scss's
	 * header comment for why this is a separate style handle from
	 * enqueue_block_assets() above. Hooked ONLY onto
	 * 'metform/form_builder/editor/enqueue_scripts' (never the frontend
	 * hook) — this style has no purpose outside the wp-admin editor canvas.
	 *
	 * @since 4.0.5
	 *
	 * @param int $form_id Unused — accepted only because the hook this is
	 *                      attached to passes one.
	 *
	 * @return void
	 */
	public function enqueue_editor_canvas_style( $form_id = 0 ) {
		Assets_Enqueue::get_style( 'metform-pro-form-builder-editor-canvas' );
	}
}
