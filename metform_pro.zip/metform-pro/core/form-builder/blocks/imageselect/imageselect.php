<?php
namespace MetForm_Pro\Core\FormBuilder\Blocks\Imageselect;

use MetForm\Core\FormBuilder\Block_Base;
use MetForm\Core\FormBuilder\Dynamic_Css\Css_Value_Formatter;
use MetForm\Core\FormBuilder\Dynamic_Css\Responsive_Value;
use MetForm\Core\FormBuilder\Rendering\Render_Context;

defined( 'ABSPATH' ) || exit;

final class Imageselect extends Block_Base {
	private const INDICATORS           = array( 'border', 'checkmark', 'both' );
	private const CHECKMARK_INDICATORS = array( 'checkmark', 'both' ); // Modes that render the checkmark badge.
	private const SIZE_MODES           = array( 'fixed', 'ratio' );
	private const ASPECT_RATIOS        = array( '1/1', '4/3', '3/2', '16/9', 'custom' );
	private const CHECK_POSITIONS      = array( 'top-right', 'top-left', 'bottom-right', 'bottom-left' );
	private const DEFAULT_COLUMNS      = 3;

	public function get_name(): string {
		return 'imageselect'; }
	public function get_title(): string {
		return __( 'Image Select', 'metform-pro' ); }
	public function get_icon(): string {
		return 'LayoutGrid'; }
	public function get_category(): string {
		return 'Advanced'; }

	public function get_capabilities(): array {
		return array(
			'acceptsChildren' => false,
			'isField'         => true,
		);
	}

	/**
	 * The compiled frontend/form-builder bundle handle this block needs —
	 * enqueued only when this block is actually present, via this plugin's
	 * own Base::enqueue_block_assets() (mirrors canvas.php's identical
	 * per-block loop in the free plugin, which never sees Pro blocks).
	 */
	public function get_frontend_assets(): array {
		return array( 'metform-pro-form-builder-frontend' );
	}

	public function get_default_settings(): array {
		return array(
			'label'                => __( 'Image Select', 'metform-pro' ),
			'labelPosition'        => 'top',
			'name'                 => '',
			'helpText'             => '',
			'required'             => false,
			'showLabel'            => true,
			'multiSelect'          => false,
			'columns'              => '3',
			'showLabels'           => true,
			'selectionIndicator'   => 'border',
			'checkmarkPosition'    => 'top-right',
			'imageSizeMode'        => 'fixed',
			'imageHeight'          => '80px',
			'imageAspectRatio'     => '1/1',
			'imageRatioCustom'     => '',
			'options'              => array(
				array(
					'label'    => 'Option 1',
					'value'    => 'option-1',
					'imageUrl' => '',
					'imageAlt' => '',
					'disabled' => false,
				),
				array(
					'label'    => 'Option 2',
					'value'    => 'option-2',
					'imageUrl' => '',
					'imageAlt' => '',
					'disabled' => false,
				),
				array(
					'label'    => 'Option 3',
					'value'    => 'option-3',
					'imageUrl' => '',
					'imageAlt' => '',
					'disabled' => false,
				),
			),
			'quizPoint'            => 0,
			'quizAddNegativePoint' => false,
			'quizNegativePoint'    => 0,
			'styles'               => array(),
		);
	}

	public function get_property_schema(): array {
		return array(
			'label'                => array( 'type' => 'string' ),
			'labelPosition'        => array(
				'type'       => 'string',
				'enum'       => array( 'top', 'left' ),
				'responsive' => true,
			),
			'name'                 => array( 'type' => 'field_name' ),
			'helpText'             => array( 'type' => 'string' ),
			'required'             => array( 'type' => 'boolean' ),
			'showLabel'            => array( 'type' => 'boolean' ),
			'requiredMessage'      => array( 'type' => 'string' ),
			'multiSelect'          => array( 'type' => 'boolean' ),
			// Plain '1'–'6' on older forms, `{ desktop, tablet, mobile }` once a
			// breakpoint override is set; clamped to 1–6 in sanitize_columns().
			'columns'              => array( 'type' => 'responsive_string' ),
			'showLabels'           => array( 'type' => 'boolean' ),
			'selectionIndicator'   => array(
				'type' => 'string',
				'enum' => self::INDICATORS,
			),
			'checkmarkPosition'    => array(
				'type' => 'string',
				'enum' => self::CHECK_POSITIONS,
			),
			'imageSizeMode'        => array(
				'type' => 'string',
				'enum' => self::SIZE_MODES,
			),
			'imageHeight'          => array(
				'type'       => 'string',
				'responsive' => true,
			),
			'imageAspectRatio'     => array(
				'type'       => 'string',
				'enum'       => self::ASPECT_RATIOS,
				'responsive' => true,
			),
			'imageRatioCustom'     => array( 'type' => 'string' ),
			'options'              => array( 'type' => 'object' ),
			'quizPoint'            => array( 'type' => 'number' ),
			'quizAddNegativePoint' => array( 'type' => 'boolean' ),
			'quizNegativePoint'    => array( 'type' => 'number' ),
		);
	}

	private function typography_selector( string $el ): string {
		return "{{WRAPPER}} {$el} { font-family: {{FONT_FAMILY}}; font-size: {{FONT_SIZE}}; font-weight: {{FONT_WEIGHT}}; font-style: {{FONT_STYLE}}; text-transform: {{TEXT_TRANSFORM}}; text-decoration: {{TEXT_DECORATION}}; line-height: {{LINE_HEIGHT}}; letter-spacing: {{LETTER_SPACING}}; word-spacing: {{WORD_SPACING}}; }";
	}

	/**
	 * Conditions are evaluated in the editor against the element's *saved*
	 * props, and block defaults are only written when a block is first
	 * inserted — so on a form saved before a setting existed, that key is
	 * undefined. Every condition below is therefore written to give the same
	 * result for "undefined" as for the setting's default value (e.g.
	 * `imageSizeMode! => ratio` rather than `imageSizeMode => fixed`).
	 */
	public function register_controls(): array {
		return array(
			'content' => array(
				array(
					'type'        => 'section',
					'key'         => 'content',
					'label'       => __( 'Content', 'metform-pro' ),
					'defaultOpen' => true,
				),
				array(
					'type'    => 'toggle',
					'key'     => 'showLabel',
					'label'   => __( 'Show Label', 'metform-pro' ),
					'default' => true,
				),
				array(
					'type'      => 'text',
					'key'       => 'label',
					'label'     => __( 'Label', 'metform-pro' ),
					'default'   => __( 'Image Select', 'metform-pro' ),
					'condition' => array( 'showLabel!' => false ),
				),
				array(
					'type'       => 'select',
					'key'        => 'labelPosition',
					'label'      => __( 'Label Position', 'metform-pro' ),
					'default'    => 'top',
					'options'    => array(
						array(
							'label' => __( 'Top', 'metform-pro' ),
							'value' => 'top',
						),
						array(
							'label' => __( 'Left', 'metform-pro' ),
							'value' => 'left',
						),
					),
					'condition'  => array( 'showLabel!' => false ),
					'responsive' => true,
				),
				array(
					'type'  => 'text',
					'key'   => 'name',
					'label' => __( 'Name', 'metform-pro' ),
					'help'  => __( 'Name is must required. Enter name without space or any special character. use only underscore/ hyphen (_/-) for multiple word. Name must be different.', 'metform-pro' ),
				),
				array(
					'type'  => 'text',
					'key'   => 'helpText',
					'label' => __( 'Help Text', 'metform-pro' ),
					'help'  => __( 'Shown below the field to guide users', 'metform-pro' ),
				),
				array(
					'type'    => 'toggle',
					'key'     => 'multiSelect',
					'label'   => __( 'Multiple Select', 'metform-pro' ),
					'default' => false,
					'help'    => __( 'Allow selecting more than one option at a time.', 'metform-pro' ),
				),
				array(
					'type'       => 'select',
					'key'        => 'columns',
					'label'      => __( 'Columns', 'metform-pro' ),
					'default'    => '3',
					'options'    => array_map(
						static fn( $n ) => array(
							'label' => (string) $n,
							'value' => (string) $n,
						),
						range( 1, 6 )
					),
					'responsive' => true,
				),
				array(
					'type'    => 'select',
					'key'     => 'imageSizeMode',
					'label'   => __( 'Image Size Mode', 'metform-pro' ),
					'default' => 'fixed',
					'options' => array(
						array(
							'label' => __( 'Fixed height', 'metform-pro' ),
							'value' => 'fixed',
						),
						array(
							'label' => __( 'Aspect ratio', 'metform-pro' ),
							'value' => 'ratio',
						),
					),
				),
				array(
					'type'       => 'range',
					'key'        => 'imageHeight',
					'label'      => __( 'Image Height', 'metform-pro' ),
					'default'    => '80px',
					'units'      => array( 'px' ),
					'min'        => 40,
					'max'        => 240,
					'step'       => 5,
					'help'       => __( 'Height of the image area inside each card.', 'metform-pro' ),
					'condition'  => array( 'imageSizeMode!' => 'ratio' ),
					'responsive' => true,
				),
				array(
					'type'       => 'select',
					'key'        => 'imageAspectRatio',
					'label'      => __( 'Aspect Ratio', 'metform-pro' ),
					'default'    => '1/1',
					'options'    => array(
						array(
							'label' => '1:1',
							'value' => '1/1',
						),
						array(
							'label' => '4:3',
							'value' => '4/3',
						),
						array(
							'label' => '3:2',
							'value' => '3/2',
						),
						array(
							'label' => '16:9',
							'value' => '16/9',
						),
						array(
							'label' => __( 'Custom', 'metform-pro' ),
							'value' => 'custom',
						),
					),
					'help'       => __( 'Width to height of the image area; the card height follows its width.', 'metform-pro' ),
					'condition'  => array( 'imageSizeMode' => 'ratio' ),
					'responsive' => true,
				),
				array(
					'type'        => 'text',
					'key'         => 'imageRatioCustom',
					'label'       => __( 'Custom Ratio', 'metform-pro' ),
					'placeholder' => '5:4',
					'help'        => __( 'Width and height separated by a colon, e.g. 5:4 or 2.35:1.', 'metform-pro' ),
					'condition'   => array(
						'imageSizeMode'    => 'ratio',
						'imageAspectRatio' => 'custom',
					),
				),
				array(
					'type'    => 'toggle',
					'key'     => 'showLabels',
					'label'   => __( 'Show Option Labels', 'metform-pro' ),
					'default' => true,
				),
				array(
					'type'    => 'select',
					'key'     => 'selectionIndicator',
					'label'   => __( 'Indicator', 'metform-pro' ),
					'default' => 'border',
					'options' => array(
						array(
							'label' => __( 'Border only', 'metform-pro' ),
							'value' => 'border',
						),
						array(
							'label' => __( 'Checkmark only', 'metform-pro' ),
							'value' => 'checkmark',
						),
						array(
							'label' => __( 'Border + Checkmark', 'metform-pro' ),
							'value' => 'both',
						),
					),
					'help'    => __( 'How a selected card is visually marked.', 'metform-pro' ),
				),
				array(
					'type'      => 'select',
					'key'       => 'checkmarkPosition',
					'label'     => __( 'Checkmark Position', 'metform-pro' ),
					'default'   => 'top-right',
					'options'   => array(
						array(
							'label' => __( 'Top Right', 'metform-pro' ),
							'value' => 'top-right',
						),
						array(
							'label' => __( 'Top Left', 'metform-pro' ),
							'value' => 'top-left',
						),
						array(
							'label' => __( 'Bottom Right', 'metform-pro' ),
							'value' => 'bottom-right',
						),
						array(
							'label' => __( 'Bottom Left', 'metform-pro' ),
							'value' => 'bottom-left',
						),
					),
					'help'      => __( 'Corner of the image the checkmark badge sits in.', 'metform-pro' ),
					'condition' => array( 'selectionIndicator' => self::CHECKMARK_INDICATORS ),
				),
				// Last, as in Select/Radio/Checkbox: the repeater grows with every option.
				array(
					'type'       => 'repeater',
					'key'        => 'options',
					'label'      => __( 'Options', 'metform-pro' ),
					'default'    => array(
						array(
							'label'    => 'Option 1',
							'value'    => 'option-1',
							'imageUrl' => '',
							'imageAlt' => '',
							'disabled' => false,
						),
						array(
							'label'    => 'Option 2',
							'value'    => 'option-2',
							'imageUrl' => '',
							'imageAlt' => '',
							'disabled' => false,
						),
						array(
							'label'    => 'Option 3',
							'value'    => 'option-3',
							'imageUrl' => '',
							'imageAlt' => '',
							'disabled' => false,
						),
					),
					'titleField' => 'label',
					'addLabel'   => __( 'ADD OPTION', 'metform-pro' ),
					'min'        => 1,
					'fields'     => array(
						array(
							'type'  => 'text',
							'key'   => 'label',
							'label' => __( 'Label', 'metform-pro' ),
						),
						array(
							'type'  => 'text',
							'key'   => 'value',
							'label' => __( 'Value', 'metform-pro' ),
						),
						array(
							'type'  => 'image',
							'key'   => 'imageUrl',
							'label' => __( 'Image', 'metform-pro' ),
						),
						array(
							'type'        => 'text',
							'key'         => 'imageAlt',
							'label'       => __( 'Alt Text', 'metform-pro' ),
							'placeholder' => __( 'Describe the image', 'metform-pro' ),
						),
						array(
							'type'  => 'toggle',
							'key'   => 'disabled',
							'label' => __( 'Disabled', 'metform-pro' ),
						),
						// Hidden outside quiz forms only — a saved value is left as-is.
						array(
							'type'      => 'toggle',
							'key'       => 'isQuizAnswer',
							'label'     => __( 'Correct Answer', 'metform-pro' ),
							'condition' => array( '$form.formType' => 'quiz-form' ),
						),
					),
				),

				array(
					'type'        => 'section',
					'key'         => 'settings',
					'label'       => __( 'Settings', 'metform-pro' ),
					'defaultOpen' => false,
				),
				array(
					'type'    => 'toggle',
					'key'     => 'required',
					'label'   => __( 'Required', 'metform-pro' ),
					'default' => false,
				),
				array(
					'type'      => 'text',
					'key'       => 'requiredMessage',
					'label'     => __( 'Required Message', 'metform-pro' ),
					'help'      => __( 'Shown when no option is selected.', 'metform-pro' ),
					'condition' => array( 'required' => true ),
				),

				array(
					'type'        => 'section',
					'key'         => 'quiz',
					'label'       => __( 'Quiz Settings', 'metform-pro' ),
					'defaultOpen' => false,
					'condition'   => array( '$form.formType' => 'quiz-form' ),
				),
				array(
					'type'      => 'number',
					'key'       => 'quizPoint',
					'label'     => __( 'Points', 'metform-pro' ),
					'default'   => 0,
					'min'       => 0,
					'help'      => __( "Note: if the point and the negative point both are set at zero, we won't consider it a question.", 'metform-pro' ),
					'condition' => array( '$form.formType' => 'quiz-form' ),
				),
				array(
					'type'      => 'toggle',
					'key'       => 'quizAddNegativePoint',
					'label'     => __( 'Deduct Points for Wrong Answer', 'metform-pro' ),
					'default'   => false,
					'condition' => array( '$form.formType' => 'quiz-form' ),
				),
				array(
					'type'      => 'number',
					'key'       => 'quizNegativePoint',
					'label'     => __( 'Points to Deduct', 'metform-pro' ),
					'default'   => 0,
					'min'       => 0,
					'step'      => 0.5,
					'condition' => array(
						'$form.formType'       => 'quiz-form',
						'quizAddNegativePoint' => true,
					),
				),
			),
			// Style controls keep their original relative order: the generated
			// CSS is emitted in this order, so moving one across another could
			// change the cascade (and the per-form CSS cache output).
			'style'   => array(
				array(
					'type'        => 'section',
					'label'       => __( 'Label', 'metform-pro' ),
					'defaultOpen' => true,
					'condition'   => array( 'showLabel!' => false ),
				),
				array(
					'type'      => 'color',
					'key'       => 'styles.labelColor',
					'label'     => __( 'Label Color', 'metform-pro' ),
					'default'   => '#374151',
					'selector'  => '{{WRAPPER}} .mfb-label { color: {{VALUE}}; }',
					'condition' => array( 'showLabel!' => false ),
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.labelTypography',
					'label'          => __( 'Label Typography', 'metform-pro' ),
					'selector'       => $this->typography_selector( '.mfb-label' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
					'condition'      => array( 'showLabel!' => false ),
				),
				array(
					'type'  => 'section',
					'label' => __( 'Help Text & Error', 'metform-pro' ),
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.helpTextColor',
					'label'    => __( 'Help Text Color', 'metform-pro' ),
					'default'  => '#6b7280',
					'selector' => '{{WRAPPER}} .mfb-field__help { color: {{VALUE}}; }',
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.errorColor',
					'label'    => __( 'Error Color', 'metform-pro' ),
					'default'  => '#ef4444',
					'selector' => '{{WRAPPER}} .mfb-field__error { color: {{VALUE}}; }',
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.helpTextTypography',
					'label'          => __( 'Help Text Typography', 'metform-pro' ),
					'selector'       => $this->typography_selector( '.mfb-field__help' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.errorTypography',
					'label'          => __( 'Error Typography', 'metform-pro' ),
					'selector'       => $this->typography_selector( '.mfb-field__error' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
				),

				array(
					'type'  => 'section',
					'label' => __( 'Card', 'metform-pro' ),
				),
				array(
					'type'       => 'range',
					'key'        => 'styles.gap',
					'label'      => __( 'Gap', 'metform-pro' ),
					'default'    => '0.625rem',
					'units'      => array( 'px', 'rem' ),
					'selector'   => '{{WRAPPER}} .mfb-imgsel__grid { gap: {{VALUE}}; }',
					'responsive' => true,
				),
				array(
					'type' => 'tabs',
					'tab'  => array( 'normal', 'selected' ),
				),
				array(
					'type'     => 'background',
					'key'      => 'styles.cardBg',
					'label'    => __( 'Background', 'metform-pro' ),
					'tab'      => 'normal',
					'default'  => array(
						'type'  => 'classic',
						'color' => '#ffffff',
					),
					'selector' => '{{WRAPPER}} .mfb-imgsel__card { {{VALUE}} }',
				),
				// The normal-state card border color is in the Border control
				// below (with a fallback to the old 'styles.cardBorderColor').
				array(
					'type'     => 'background',
					'key'      => 'styles.cardSelBg',
					'label'    => __( 'Background', 'metform-pro' ),
					'help'     => __( 'Not used in "Checkmark only" mode.', 'metform-pro' ),
					'tab'      => 'selected',
					'default'  => array(
						'type'  => 'classic',
						'color' => '#eff6ff',
					),
					'selector' => '{{WRAPPER}} .mfb-imgsel__grid:not(.mfb-imgsel__grid--checkmark) .mfb-imgsel__card:has(.mfb-imgsel__input-native:checked) { {{VALUE}} }',
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.cardSelBorderColor',
					'label'    => __( 'Border Color', 'metform-pro' ),
					'help'     => __( 'Not used in "Checkmark only" mode.', 'metform-pro' ),
					'tab'      => 'selected',
					'default'  => '#3b82f6',
					'selector' => '{{WRAPPER}} .mfb-imgsel__grid:not(.mfb-imgsel__grid--checkmark) .mfb-imgsel__card:has(.mfb-imgsel__input-native:checked) { border-color: {{VALUE}}; }',
				),
				// No `tab` from here on, so these render below the Normal/Selected tabs.
				array(
					'type'           => 'border',
					'key'            => 'styles.cardBorder',
					'label'          => __( 'Border', 'metform-pro' ),
					'selector'       => '{{WRAPPER}} .mfb-imgsel__card { {{VALUE}} }',
					'responsive'     => true,
					'responsiveKeys' => array( 'width', 'radius' ),
					'legacy'         => array(
						'color' => array(
							'key'     => 'styles.cardBorderColor',
							'default' => '#e5e7eb',
						),
					),
				),
				array(
					'type'     => 'boxShadow',
					'key'      => 'styles.cardShadow',
					'label'    => __( 'Box Shadow', 'metform-pro' ),
					'selector' => '{{WRAPPER}} .mfb-imgsel__card { box-shadow: {{VALUE}}; }',
				),
				array(
					'type'     => 'select',
					'key'      => 'styles.imageFit',
					'label'    => __( 'Image Fit', 'metform-pro' ),
					'default'  => 'cover',
					'options'  => array(
						array(
							'label' => __( 'Cover', 'metform-pro' ),
							'value' => 'cover',
						),
						array(
							'label' => __( 'Contain', 'metform-pro' ),
							'value' => 'contain',
						),
						array(
							'label' => __( 'Fill', 'metform-pro' ),
							'value' => 'fill',
						),
						array(
							'label' => __( 'None', 'metform-pro' ),
							'value' => 'none',
						),
					),
					'selector' => '{{WRAPPER}} .mfb-imgsel__img { object-fit: {{VALUE}}; }',
				),
				array(
					'type'     => 'background',
					'key'      => 'styles.imagePlaceholderBg',
					'label'    => __( 'Image Area Background', 'metform-pro' ),
					'help'     => __( 'Shown behind "Contain" images and options without an image.', 'metform-pro' ),
					'default'  => array(
						'type'  => 'classic',
						'color' => '#f3f4f6',
					),
					'selector' => '{{WRAPPER}} .mfb-imgsel__img-wrap { {{VALUE}} }',
				),

				array(
					'type'      => 'section',
					'label'     => __( 'Checkmark', 'metform-pro' ),
					'condition' => array( 'selectionIndicator' => self::CHECKMARK_INDICATORS ),
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.checkBg',
					'label'    => __( 'Background', 'metform-pro' ),
					'default'  => '#3b82f6',
					'selector' => '{{WRAPPER}} .mfb-imgsel__check { background-color: {{VALUE}}; }',
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.checkColor',
					'label'    => __( 'Icon Color', 'metform-pro' ),
					'default'  => '#ffffff',
					'selector' => '{{WRAPPER}} .mfb-imgsel__check-icon { stroke: {{VALUE}}; }',
				),
			),
		);
	}

	private function render_card( array $opt, string $name, string $input_type, string $indicator, bool $show_labels, bool $required = false ): string {
		$value     = (string) ( $opt['value'] ?? '' );
		$label     = (string) ( $opt['label'] ?? '' );
		$image_url = (string) ( $opt['imageUrl'] ?? '' );
		// The image sits inside the input's <label>, so its alt joins the
		// input's accessible name — fall back to the option label only when
		// that label isn't already rendered as visible text.
		$image_alt      = (string) ( $opt['imageAlt'] ?? '' );
		$image_alt      = '' !== $image_alt ? $image_alt : ( $show_labels ? '' : $label );
		$disabled       = ! empty( $opt['disabled'] );
		$show_check     = in_array( $indicator, self::CHECKMARK_INDICATORS, true );
		$is_quiz_answer = ! empty( $opt['isQuizAnswer'] );

		ob_start();
		?>
<label class="mfb-imgsel__card">
	<input type="<?php echo esc_attr( $input_type ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>" class="mfb-imgsel__input-native" <?php echo $disabled ? 'disabled' : ''; ?> <?php echo $required ? 'required' : ''; ?> <?php echo $is_quiz_answer ? 'data-quiz-answer="true"' : ''; ?>>
	<div class="mfb-imgsel__img-wrap">
		<?php if ( $image_url ) : ?>
		<img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $image_alt ); ?>" class="mfb-imgsel__img">
		<?php endif; ?>
		<?php // Kept (hidden) next to a real image so the frontend script can swap it in if the image fails to load. ?>
		<div class="mfb-imgsel__img-placeholder"<?php echo $image_url ? ' hidden' : ''; ?>><svg class="mfb-imgsel__placeholder-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg></div>
		<?php if ( $show_check ) : ?>
		<div class="mfb-imgsel__check"><svg class="mfb-imgsel__check-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></div>
		<?php endif; ?>
	</div>
		<?php if ( $show_labels && '' !== $label ) : ?>
	<span class="mfb-imgsel__label"><?php echo esc_html( $label ); ?></span>
	<?php endif; ?>
</label>
		<?php
		return (string) ob_get_clean();
	}

	public function render_markup( array $settings, Render_Context $context ): string {
		$options         = is_array( $settings['options'] ?? null ) ? $settings['options'] : array();
		$multi           = ! empty( $settings['multiSelect'] );
		$columns_setting = $settings['columns'] ?? self::DEFAULT_COLUMNS;
		$columns         = self::sanitize_columns( is_array( $columns_setting ) ? ( $columns_setting['desktop'] ?? null ) : $columns_setting ) ?? self::DEFAULT_COLUMNS;
		// Desktop values inline; tablet/mobile overrides come from
		// build_dynamic_css() (!important media rules on the same vars).
		$image_height       = self::sanitize_height( Responsive_Value::resolve( $settings['imageHeight'] ?? '', 'desktop', '' ) ) ?? '80px';
		$aspect_ratio       = 'ratio' === ( $settings['imageSizeMode'] ?? 'fixed' ) ? self::resolve_aspect_ratio( $settings, 'desktop' ) : '';
		$indicator          = self::pick( $settings['selectionIndicator'] ?? null, self::INDICATORS );
		$check_position     = self::pick( $settings['checkmarkPosition'] ?? null, self::CHECK_POSITIONS );
		$show_labels        = (bool) ( $settings['showLabels'] ?? true );
		$name               = (string) ( $settings['name'] ?? '' );
		$input_type         = $multi ? 'checkbox' : 'radio';
		$input_name         = $multi ? $name . '[]' : $name;
		$is_required        = ! empty( $settings['required'] );
		$required_this_card = ! $multi && $is_required;

		$cards = '';
		if ( empty( $options ) ) {
			$cards = '<p class="mfb-imgsel__empty">' . esc_html__( 'No options added yet.', 'metform-pro' ) . '</p>';
		} else {
			foreach ( $options as $opt ) {
				if ( ! is_array( $opt ) ) {
					continue;
				}

				$card_required = $required_this_card && empty( $opt['disabled'] );
				$cards        .= $this->render_card( $opt, $input_name, $input_type, $indicator, $show_labels, $card_required );
			}
		}

		$required_message = (string) ( $settings['requiredMessage'] ?? '' );
		$group_attrs      = $multi && $is_required
			? ' data-mf-required="1"' . ( $required_message !== '' ? ' data-mf-required-message="' . esc_attr( $required_message ) . '"' : '' )
			: ( ! $multi && $is_required && $required_message !== '' ? ' data-mf-required-message="' . esc_attr( $required_message ) . '"' : '' );

		$grid_classes = array(
			'mfb-imgsel__grid',
			'mfb-imgsel__grid--' . $indicator,
			'mfb-imgsel__grid--check-' . $check_position,
		);
		$grid_style   = '--mfb-imgsel-cols: ' . $columns . '; --mfb-imgsel-img-h: ' . $image_height . ';';
		if ( '' !== $aspect_ratio ) {
			$grid_classes[] = 'mfb-imgsel__grid--ratio';
			$grid_style    .= ' --mfb-imgsel-ratio: ' . $aspect_ratio . ';';
		}

		return sprintf(
			'<div class="%1$s" style="%2$s" role="%3$s"%4$s>%5$s</div>',
			esc_attr( implode( ' ', $grid_classes ) ),
			esc_attr( $grid_style ),
			$multi ? 'group' : 'radiogroup',
			$group_attrs, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			$cards // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		);
	}

	/**
	 * Adds the tablet/mobile column overrides on top of the style-control
	 * CSS. Desktop columns stay on the grid's inline `--mfb-imgsel-cols`
	 * (set in render_markup()), so forms saved before Columns became
	 * responsive render exactly as before; `!important` lets a breakpoint
	 * override win over that inline value. Same `@media` queries as every
	 * other responsive control (Responsive_Value::get_breakpoints()),
	 * which the editor's device preview already honours since it resizes
	 * the canvas iframe.
	 */
	public function build_dynamic_css( array $settings, string $class_name ): string {
		$css     = parent::build_dynamic_css( $settings, $class_name );
		$columns = $settings['columns'] ?? null;
		$height  = $settings['imageHeight'] ?? null;
		$ratio   = $settings['imageAspectRatio'] ?? null;

		foreach ( Responsive_Value::get_breakpoints() as $slot => $media ) {
			$decls = '';
			if ( Responsive_Value::is_responsive( $columns ) ) {
				$count = self::sanitize_columns( $columns[ $slot ] ?? null );
				if ( null !== $count ) {
					$decls .= " --mfb-imgsel-cols: {$count} !important;";
				}
			}
			if ( in_array( $slot, Responsive_Value::overridden_slots( $height ), true ) ) {
				$value = self::sanitize_height( $height[ $slot ] );
				if ( null !== $value ) {
					$decls .= " --mfb-imgsel-img-h: {$value} !important;";
				}
			}
			if ( in_array( $slot, Responsive_Value::overridden_slots( $ratio ), true ) ) {
				$decls .= ' --mfb-imgsel-ratio: ' . self::resolve_aspect_ratio( $settings, $slot ) . ' !important;';
			}
			if ( '' !== $decls ) {
				$css .= "{$media} { .{$class_name} .mfb-imgsel__grid {{$decls} } }";
			}
		}
		return $css;
	}

	/** A CSS length for Image Height, or null when it isn't one. */
	private static function sanitize_height( $value ): ?string {
		$value = is_scalar( $value ) ? trim( (string) $value ) : '';
		return preg_match( '/^\d{1,4}(?:\.\d+)?(?:px|rem|em|%|vh)?$/', $value ) ? $value : null;
	}

	/** Returns $value when it's one of $allowed, else the first allowed value (the default). */
	private static function pick( $value, array $allowed ): string {
		return in_array( $value, $allowed, true ) ? $value : $allowed[0];
	}

	/** Clamps a saved column count to 1–6; null when unset/non-numeric (so the caller can inherit). */
	private static function sanitize_columns( $value ): ?int {
		if ( null === $value || '' === $value || ! is_numeric( $value ) ) {
			return null;
		}
		return max( 1, min( 6, (int) $value ) );
	}

	/**
	 * Resolves the Aspect Ratio setting to a CSS `aspect-ratio` value
	 * ("W / H"). A custom ratio accepts "W:H", "W/H" or a single number;
	 * anything else falls back to 1 / 1 rather than emitting invalid CSS.
	 */
	private static function resolve_aspect_ratio( array $settings, string $slot = 'desktop' ): string {
		$preset = self::pick( Responsive_Value::resolve( $settings['imageAspectRatio'] ?? null, $slot, null ), self::ASPECT_RATIOS );
		$raw    = 'custom' === $preset ? trim( (string) ( $settings['imageRatioCustom'] ?? '' ) ) : $preset;

		if ( preg_match( '/^(\d{1,4}(?:\.\d{1,3})?)\s*[:\/]\s*(\d{1,4}(?:\.\d{1,3})?)$/', $raw, $m ) && (float) $m[1] > 0 && (float) $m[2] > 0 ) {
			return ( (float) $m[1] + 0 ) . ' / ' . ( (float) $m[2] + 0 );
		}
		if ( preg_match( '/^\d{1,4}(?:\.\d{1,3})?$/', $raw ) && (float) $raw > 0 ) {
			return ( (float) $raw + 0 ) . ' / 1';
		}
		return '1 / 1';
	}
}
