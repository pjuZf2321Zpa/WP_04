<?php
namespace MetForm_Pro\Core\FormBuilder\Blocks\Simplerepeater;

use MetForm\Core\FormBuilder\Block_Base;
use MetForm\Core\FormBuilder\Dynamic_Css\Responsive_Value;
use MetForm\Core\FormBuilder\Icons\Block_Icon;
use MetForm\Core\FormBuilder\Rendering\Render_Context;
use MetForm\Core\FormBuilder\Shared\Option_Controls;

defined( 'ABSPATH' ) || exit;

final class Simplerepeater extends Block_Base {
	private const FIELD_TYPES     = array( 'text', 'email', 'number', 'url', 'switch', 'range', 'checkbox', 'radio', 'select' );
	private const TEXT_LIKE_TYPES = array( 'text', 'email', 'number', 'url' );
	private const LABELABLE_TYPES = array( 'text', 'email', 'number', 'url', 'switch', 'range', 'select' );

	public function get_name(): string {
		return 'simplerepeater'; }
	public function get_title(): string {
		return __( 'Simple Repeater', 'metform-pro' ); }
	public function get_icon(): string {
		return 'ListPlus'; }
	public function get_category(): string {
		return 'Advanced'; }

	public function get_capabilities(): array {
		return array(
			'acceptsChildren' => false,
			'isField'         => true,
		);
	}

	/**
	 * The compiled frontend/form-builder bundle handle this block needs —
	 * enqueued only when this block is actually present, via this plugin's
	 * own Base::enqueue_block_assets() (mirrors editor/canvas.php's identical
	 * per-block loop in the free plugin, which never sees Pro blocks).
	 */
	public function get_frontend_assets(): array {
		return array( 'metform-pro-form-builder-frontend' );
	}

	public function get_default_settings(): array {
		return array(
			'label'            => __( 'Repeater Field', 'metform-pro' ),
			'labelPosition'    => 'top',
			'name'             => '',
			'helpText'         => '',
			'required'         => false,
			'showLabel'        => true,
			'layout'           => 'block',
			'useButtonIcon'    => false,
			'addButtonText'    => __( 'Add', 'metform-pro' ),
			'addButtonIcon'    => '',
			'removeButtonText' => __( 'Remove', 'metform-pro' ),
			'removeButtonIcon' => '',
			'fields'           => array(
				array(
					'showLabel'   => true,
					'label'       => __( 'Field 1', 'metform-pro' ),
					'type'        => 'text',
					'name'        => '',
					'placeholder' => '',
				),
			),
			'styles'           => array(),
		);
	}

	public function get_property_schema(): array {
		return array(
			'showLabel'        => array( 'type' => 'boolean' ),
			'label'            => array( 'type' => 'string' ),
			'labelPosition'    => array(
				'type'       => 'string',
				'enum'       => array( 'top', 'left' ),
				'responsive' => true,
			),
			'name'             => array( 'type' => 'field_name' ),
			'helpText'         => array( 'type' => 'string' ),
			'layout'           => array(
				'type'       => 'string',
				'enum'       => array( 'block', 'inline' ),
				'responsive' => true,
			),
			'useButtonIcon'    => array( 'type' => 'boolean' ),
			'addButtonText'    => array( 'type' => 'string' ),
			'addButtonIcon'    => array( 'type' => 'icon_value' ),
			'removeButtonText' => array( 'type' => 'string' ),
			'removeButtonIcon' => array( 'type' => 'icon_value' ),
			'fields'           => array( 'type' => 'object' ),
			'required'         => array( 'type' => 'boolean' ),
			'requiredMessage'  => array( 'type' => 'string' ),
		);
	}

	private function typography_selector( string $el ): string {
		return "{{WRAPPER}} {$el} { font-family: {{FONT_FAMILY}}; font-size: {{FONT_SIZE}}; font-weight: {{FONT_WEIGHT}}; font-style: {{FONT_STYLE}}; text-transform: {{TEXT_TRANSFORM}}; text-decoration: {{TEXT_DECORATION}}; line-height: {{LINE_HEIGHT}}; letter-spacing: {{LETTER_SPACING}}; word-spacing: {{WORD_SPACING}}; }";
	}

	public function register_controls(): array {
		$field_type_options = array(
			array(
				'label' => __( 'Text', 'metform-pro' ),
				'value' => 'text',
			),
			array(
				'label' => __( 'Email', 'metform-pro' ),
				'value' => 'email',
			),
			array(
				'label' => __( 'Number', 'metform-pro' ),
				'value' => 'number',
			),
			array(
				'label' => __( 'URL', 'metform-pro' ),
				'value' => 'url',
			),
			array(
				'label' => __( 'Switch', 'metform-pro' ),
				'value' => 'switch',
			),
			array(
				'label' => __( 'Range', 'metform-pro' ),
				'value' => 'range',
			),
			array(
				'label' => __( 'Checkbox', 'metform-pro' ),
				'value' => 'checkbox',
			),
			array(
				'label' => __( 'Radio', 'metform-pro' ),
				'value' => 'radio',
			),
			array(
				'label' => __( 'Select', 'metform-pro' ),
				'value' => 'select',
			),
		);

		return array(
			'content' => array(
				array(
					'type'        => 'section',
					'key'         => 'content',
					'label'       => __( 'Content', 'metform-pro' ),
					'defaultOpen' => true,
				),
				array(
					'type'    => 'toggle',
					'key'     => 'showLabel',
					'label'   => __( 'Show Label', 'metform-pro' ),
					'default' => true,
				),
				array(
					'type'      => 'text',
					'key'       => 'label',
					'label'     => __( 'Label', 'metform-pro' ),
					'default'   => __( 'Repeater Field', 'metform-pro' ),
					'inline'    => true,
					'condition' => array( 'showLabel!' => false ),
				),
				array(
					'type'       => 'select',
					'key'        => 'labelPosition',
					'label'      => __( 'Label Position', 'metform-pro' ),
					'default'    => 'top',
					'inline'     => true,
					'options'    => array(
						array(
							'label' => __( 'Top', 'metform-pro' ),
							'value' => 'top',
						),
						array(
							'label' => __( 'Left', 'metform-pro' ),
							'value' => 'left',
						),
					),
					'condition'  => array( 'showLabel!' => false ),
					'responsive' => true,
				),
				array(
					'type'   => 'text',
					'key'    => 'name',
					'label'  => __( 'Name', 'metform-pro' ),
					'inline' => true,
					'help'   => __( 'Name is must required. Enter name without space or any special character. use only underscore/ hyphen (_/-) for multiple word. Name must be different.', 'metform-pro' ),
				),
				array(
					'type'  => 'text',
					'key'   => 'helpText',
					'label' => __( 'Help Text', 'metform-pro' ),
					'help'  => __( 'Shown below the field to guide users', 'metform-pro' ),
				),
				array(
					'type'       => 'select',
					'key'        => 'layout',
					'label'      => __( 'Layout', 'metform-pro' ),
					'default'    => 'block',
					'options'    => array(
						array(
							'label' => __( 'Block', 'metform-pro' ),
							'value' => 'block',
						),
						array(
							'label' => __( 'Inline', 'metform-pro' ),
							'value' => 'inline',
						),
					),
					'responsive' => true,
				),

				array(
					'type'    => 'toggle',
					'key'     => 'useButtonIcon',
					'label'   => __( 'Use Icon Inside Button', 'metform-pro' ),
					'default' => false,
				),
				array(
					'type'    => 'text',
					'key'     => 'addButtonText',
					'label'   => __( 'Add Button Text', 'metform-pro' ),
					'default' => __( 'Add', 'metform-pro' ),
				),
				array(
					'type'      => 'icon',
					'key'       => 'addButtonIcon',
					'label'     => __( 'Add Button Icon', 'metform-pro' ),
					'condition' => array( 'useButtonIcon' => true ),
				),
				array(
					'type'    => 'text',
					'key'     => 'removeButtonText',
					'label'   => __( 'Remove Button Text', 'metform-pro' ),
					'default' => __( 'Remove', 'metform-pro' ),
				),
				array(
					'type'      => 'icon',
					'key'       => 'removeButtonIcon',
					'label'     => __( 'Remove Button Icon', 'metform-pro' ),
					'condition' => array( 'useButtonIcon' => true ),
				),

				array(
					'type'        => 'repeater',
					'key'         => 'fields',
					'label'       => __( 'Repeater Input List', 'metform-pro' ),
					'default'     => array(
						array(
							'showLabel'   => true,
							'label'       => __( 'Field 1', 'metform-pro' ),
							'type'        => 'text',
							'name'        => '',
							'placeholder' => '',
						),
					),
					// New rows start labelled and named-from-label, like the first.
					'itemDefault' => array(
						'showLabel'   => true,
						'label'       => '',
						'type'        => 'text',
						'name'        => '',
						'placeholder' => '',
					),
					'titleField'  => 'label',
					'addLabel'    => __( 'ADD FIELD', 'metform-pro' ),
					'min'         => 1,
					'fields'      => array(
						array(
							'type'  => 'toggle',
							'key'   => 'showLabel',
							'label' => __( 'Show Label', 'metform-pro' ),
						),
						array(
							'type'  => 'text',
							'key'   => 'label',
							'label' => __( 'Label', 'metform-pro' ),
							'help'  => __( 'What visitors see, and the column name in entries.', 'metform-pro' ),
						),
						array(
							'type'    => 'select',
							'key'     => 'type',
							'label'   => __( 'Input Type', 'metform-pro' ),
							'options' => $field_type_options,
						),
						array(
							'type'      => 'text',
							'key'       => 'placeholder',
							'label'     => __( 'Placeholder', 'metform-pro' ),
							'condition' => array( 'type!' => array( 'switch', 'checkbox', 'radio', 'range' ) ),
						),
						array(
							'type'      => 'text',
							'key'       => 'options',
							'label'     => __( 'Options (comma-separated)', 'metform-pro' ),
							'help'      => __( 'e.g. Option A, Option B, Option C', 'metform-pro' ),
							'condition' => array( 'type' => array( 'select', 'radio', 'checkbox' ) ),
						),
						array(
							'type'      => 'number',
							'key'       => 'min',
							'label'     => __( 'Min', 'metform-pro' ),
							'default'   => 0,
							'condition' => array( 'type' => 'range' ),
						),
						array(
							'type'      => 'number',
							'key'       => 'max',
							'label'     => __( 'Max', 'metform-pro' ),
							'default'   => 100,
							'condition' => array( 'type' => 'range' ),
						),
						array(
							'type'      => 'toggle',
							'key'       => 'showProgress',
							'label'     => __( 'Show Progress Bar', 'metform-pro' ),
							'default'   => true,
							'condition' => array( 'type' => 'range' ),
						),
						array(
							'type'  => 'text',
							'key'   => 'name',
							'label' => __( 'Input Name (optional)', 'metform-pro' ),
							'help'  => __( 'Key used in the submitted data. Leave empty to create it from the label.', 'metform-pro' ),
						),
					),
				),

				array(
					'type'        => 'section',
					'key'         => 'settings',
					'label'       => __( 'Settings', 'metform-pro' ),
					'defaultOpen' => false,
				),
				array(
					'type'    => 'toggle',
					'key'     => 'required',
					'label'   => __( 'Required', 'metform-pro' ),
					'default' => false,
				),
				array(
					'type'      => 'text',
					'key'       => 'requiredMessage',
					'label'     => __( 'Required Message', 'metform-pro' ),
					'help'      => __( 'Shown when no rows have been added.', 'metform-pro' ),
					'condition' => array( 'required' => true ),
				),
			),

			'style'   => array(
				array(
					'type'        => 'section',
					'label'       => __( 'Label', 'metform-pro' ),
					'defaultOpen' => true,
					'condition'   => array( 'showLabel!' => false ),
				),
				array(
					'type'      => 'color',
					'key'       => 'styles.labelColor',
					'label'     => __( 'Label Color', 'metform-pro' ),
					'default'   => '#374151',
					'selector'  => '{{WRAPPER}} .mfb-label { color: {{VALUE}}; }',
					'condition' => array( 'showLabel!' => false ),
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.labelTypography',
					'label'          => __( 'Label Typography', 'metform-pro' ),
					'selector'       => $this->typography_selector( '.mfb-label' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
					'condition'      => array( 'showLabel!' => false ),
				),
				array(
					'type'  => 'section',
					'label' => __( 'Help Text & Error', 'metform-pro' ),
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.helpTextColor',
					'label'    => __( 'Help Text Color', 'metform-pro' ),
					'default'  => '#6b7280',
					'selector' => '{{WRAPPER}} .mfb-field__help { color: {{VALUE}}; }',
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.errorColor',
					'label'    => __( 'Error Color', 'metform-pro' ),
					'default'  => '#ef4444',
					'selector' => '{{WRAPPER}} .mfb-field__error { color: {{VALUE}}; }',
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.helpTextTypography',
					'label'          => __( 'Help Text Typography', 'metform-pro' ),
					'selector'       => $this->typography_selector( '.mfb-field__help' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.errorTypography',
					'label'          => __( 'Error Typography', 'metform-pro' ),
					'selector'       => $this->typography_selector( '.mfb-field__error' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
				),

				array(
					'type'  => 'section',
					'label' => __( 'Container', 'metform-pro' ),
				),
				array(
					'type'     => 'background',
					'key'      => 'styles.containerBg',
					'label'    => __( 'Background', 'metform-pro' ),
					'default'  => array(
						'type'  => 'classic',
						'color' => '#ffffff',
					),
					'selector' => '{{WRAPPER}} .mfb-simplerep__row { {{VALUE}} }',
				),
				array(
					'type'           => 'border',
					'key'            => 'styles.containerBorder',
					'label'          => __( 'Border', 'metform-pro' ),
					// No default: rows have no border/radius unless one is set here.
					'selector'       => '{{WRAPPER}} .mfb-simplerep__row { border-style: {{BORDER_TYPE}}; border-width: {{TOP}} {{RIGHT}} {{BOTTOM}} {{LEFT}}; border-color: {{COLOR}}; border-radius: {{RADIUS_TOP}} {{RADIUS_RIGHT}} {{RADIUS_BOTTOM}} {{RADIUS_LEFT}}; }',
					'responsive'     => true,
					'responsiveKeys' => array( 'width', 'radius' ),
				),
				array(
					'type'       => 'dimensions',
					'key'        => 'styles.containerBorderRadius',
					'label'      => __( 'Border Radius', 'metform-pro' ),
					'selector'   => '{{WRAPPER}} .mfb-simplerep__row { border-radius: {{TOP}} {{RIGHT}} {{BOTTOM}} {{LEFT}}; }',
					'responsive' => true,
				),

				array(
					'type'  => 'section',
					'label' => __( 'Add Button', 'metform-pro' ),
				),
				array(
					'type'     => 'background',
					'key'      => 'styles.addButtonBg',
					'label'    => __( 'Background', 'metform-pro' ),
					'default'  => array(
						'type'  => 'classic',
						'color' => '#2563eb',
					),
					'selector' => '{{WRAPPER}} .mfb-simplerep__add-btn { {{VALUE}} }',
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.addButtonColor',
					'label'    => __( 'Text Color', 'metform-pro' ),
					'default'  => '#ffffff',
					'selector' => '{{WRAPPER}} .mfb-simplerep__add-btn { color: {{VALUE}}; }',
				),
				array(
					'type'           => 'border',
					'key'            => 'styles.addButtonBorder',
					'label'          => __( 'Border', 'metform-pro' ),
					'default'        => array(
						'borderType' => 'solid',
						'width'      => array(
							'top'    => '0px',
							'right'  => '0px',
							'bottom' => '0px',
							'left'   => '0px',
						),
						'color'      => '#2563eb',
						'radius'     => array(
							'top'    => '6px',
							'right'  => '6px',
							'bottom' => '6px',
							'left'   => '6px',
						),
					),
					'selector'       => '{{WRAPPER}} .mfb-simplerep__add-btn { {{VALUE}} }',
					'responsive'     => true,
					'responsiveKeys' => array( 'width', 'radius' ),
				),
				array(
					'type'       => 'dimensions',
					'key'        => 'styles.addButtonPadding',
					'label'      => __( 'Padding', 'metform-pro' ),
					'default'    => array(
						'top'    => '8px',
						'right'  => '16px',
						'bottom' => '8px',
						'left'   => '16px',
					),
					'selector'   => '{{WRAPPER}} .mfb-simplerep__add-btn { padding: {{TOP}} {{RIGHT}} {{BOTTOM}} {{LEFT}}; }',
					'responsive' => true,
				),
			),

		);
	}

	private function parse_options( string $raw ): array {
		$parts = array_map( 'trim', explode( ',', $raw ) );
		return array_values( array_filter( $parts, static fn( string $s ) => '' !== $s ) );
	}

	/**
	 * The repeater's sub-fields with a display label and a submitted name
	 * always resolved, so no sub-field is ever silently dropped (an empty
	 * Input Name used to skip the field entirely):
	 *
	 * - name:  the Input Name if set, else a slug of the label
	 *          ("Phone Number" → "phone_number"), else "field_{n}"; made
	 *          unique inside this repeater ("_2", "_3", …).
	 * - label: the Label if set, else the name made readable ("field_1" →
	 *          "Field 1" — older forms only had a name), else "Field {n}".
	 *
	 * Also used by Map_Block_Document so entries show these same labels.
	 *
	 * @param mixed $raw The block's `fields` setting.
	 * @return array<int,array> Sub-fields with string `name` and `label`.
	 */
	public static function normalize_fields( $raw ): array {
		$fields = is_array( $raw ) ? array_values( array_filter( $raw, 'is_array' ) ) : array();
		$used   = array();

		foreach ( $fields as $i => $field ) {
			$n     = $i + 1;
			$label = trim( (string) ( $field['label'] ?? '' ) );
			$name  = self::slug( (string) ( $field['name'] ?? '' ) );
			if ( '' === $name ) {
				$name = self::slug( $label );
			}
			if ( '' === $name ) {
				$name = 'field_' . $n;
			}
			$base   = $name;
			$suffix = 2;
			while ( isset( $used[ $name ] ) ) {
				$name = $base . '_' . $suffix++;
			}
			$used[ $name ] = true;

			if ( '' === $label ) {
				$label = ucfirst( trim( str_replace( array( '_', '-' ), ' ', (string) ( $field['name'] ?? '' ) ) ) );
			}
			if ( '' === $label ) {
				/* translators: %d: sub-field position in the repeater. */
				$label = sprintf( __( 'Field %d', 'metform-pro' ), $n );
			}

			$fields[ $i ]['name']  = $name;
			$fields[ $i ]['label'] = $label;
		}

		return $fields;
	}

	/** Lowercase a-z/0-9/_/- only, other runs → "_" ("Phone Number" → "phone_number"). */
	private static function slug( string $text ): string {
		$text = strtolower( remove_accents( trim( $text ) ) );
		$text = preg_replace( '/[^a-z0-9_-]+/', '_', $text );
		return trim( (string) $text, '_-' );
	}

	private function resolve_field_type( array $field ): string {
		$type = $field['type'] ?? 'text';
		return in_array( $type, self::FIELD_TYPES, true ) ? $type : 'text';
	}

	private function label_target_id( string $type, string $id_prefix ): string {
		return 'switch' === $type ? $id_prefix . '-switch' : $id_prefix;
	}

	private function render_field_control( array $field, string $name, string $id_prefix, bool $required = false ): string {
		$type         = $this->resolve_field_type( $field );
		$placeholder  = (string) ( $field['placeholder'] ?? '' );
		$common_class = 'mfb-field__input mfb-simplerep__input';

		if ( in_array( $type, self::TEXT_LIKE_TYPES, true ) ) {
			$html_type = 'url' === $type ? 'url' : $type;
			return sprintf(
				'<input id="%1$s" type="%2$s" name="%3$s" placeholder="%4$s" class="%5$s" %6$s>',
				esc_attr( $id_prefix ),
				esc_attr( $html_type ),
				esc_attr( $name ),
				esc_attr( $placeholder ),
				esc_attr( $common_class ),
				$required ? 'required' : ''
			);
		}

		if ( 'switch' === $type ) {
			$switch_id = $id_prefix . '-switch';
			return sprintf(
				'<span class="mfb-switch__toggle"><input type="checkbox" id="%1$s" name="%2$s" value="1" class="mfb-switch__input-native"><span class="mfb-switch__track mfb-switch__track--off" aria-hidden="true"><span class="mfb-switch__thumb"></span></span></span>',
				esc_attr( $switch_id ),
				esc_attr( $name )
			);
		}

		if ( 'range' === $type ) {
			$min           = (float) ( $field['min'] ?? 0 );
			$max           = (float) ( $field['max'] ?? 100 );
			$show_progress = false !== ( $field['showProgress'] ?? true );
			$value         = $min;
			$pct           = $max === $min ? 0 : max( 0, min( 100, ( ( $value - $min ) / ( $max - $min ) ) * 100 ) );
			$style         = $show_progress
				? sprintf( 'background: linear-gradient(to right, #2563eb 0%%, #2563eb %1$s%%, #d1d5db %1$s%%, #d1d5db 100%%);', esc_attr( (string) $pct ) )
				: '';
			return sprintf(
				'<div class="mfb-range__stage"><span class="mfb-range__value">%1$s</span><input id="%2$s" type="range" name="%3$s" min="%4$s" max="%5$s" value="%1$s" style="%6$s" class="mfb-range__input"></div>',
				esc_html( (string) $value ),
				esc_attr( $id_prefix ),
				esc_attr( $name ),
				esc_attr( (string) $min ),
				esc_attr( (string) $max ),
				esc_attr( $style )
			);
		}

		if ( 'checkbox' === $type ) {
			$options = $this->parse_options( (string) ( $field['options'] ?? '' ) );
			$rows    = '';
			foreach ( $options as $opt ) {
				$input_html = sprintf(
					'<span class="mfb-option__box-wrap"><input type="checkbox" name="%1$s[]" value="%2$s" class="mfb-option__input-native"><span class="mfb-option__input mfb-field-option__input-checkbox" aria-hidden="true"><svg class="mfb-option__check-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span></span>',
					esc_attr( $name ),
					esc_attr( $opt )
				);
				$rows      .= Option_Controls::render_option_label( $input_html, array( 'label' => $opt ), 'after' );
			}
			return sprintf( '<div class="mfb-field-option__group">%s</div>', $rows ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		if ( 'radio' === $type ) {
			$options = $this->parse_options( (string) ( $field['options'] ?? '' ) );
			$rows    = '';
			$first   = true;
			foreach ( $options as $opt ) {
				$input_html = sprintf(
					'<input type="radio" name="%1$s" value="%2$s" class="mfb-option__input mfb-field-option__input-radio" %3$s>',
					esc_attr( $name ),
					esc_attr( $opt ),
					$required && $first ? 'required' : ''
				);
				$first      = false;
				$rows      .= Option_Controls::render_option_label( $input_html, array( 'label' => $opt ), 'after' );
			}
			return sprintf( '<div class="mfb-field-option__group">%s</div>', $rows ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		// select
		$options     = $this->parse_options( (string) ( $field['options'] ?? '' ) );
		$option_html = '';
		if ( $placeholder ) {
			$option_html .= sprintf( '<option value="" disabled selected>%s</option>', esc_html( $placeholder ) );
		}
		foreach ( $options as $opt ) {
			$option_html .= sprintf( '<option value="%1$s">%2$s</option>', esc_attr( $opt ), esc_html( $opt ) );
		}
		return sprintf(
			'<select id="%1$s" name="%2$s" class="%3$s" %4$s>%5$s</select>',
			esc_attr( $id_prefix ),
			esc_attr( $name ),
			esc_attr( $common_class ),
			$required ? 'required' : '',
			$option_html // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		);
	}

	/**
	 * Renders an add/remove button's icon span via Free's shared icon resolver.
	 *
	 * The raw value is passed through as-is (not cast to string), so an icon
	 * key ("fas-star") or an Icon API `{type:'icon', collection, name}` array
	 * resolves to inline SVG instead of the literal "Array". Anything that is
	 * neither a string nor an array renders nothing.
	 *
	 * @param mixed $icon Raw `addButtonIcon`/`removeButtonIcon` value.
	 * @return string Icon span markup, or '' when there is no icon.
	 */
	private function render_button_icon( $icon ): string {
		if ( ! is_string( $icon ) && ! is_array( $icon ) ) {
			return '';
		}

		$icon = self::adapt_icon_for_free( $icon );
		if ( '' === $icon ) {
			return '';
		}

		[$icon_raw, $icon_data_attr, $icon_inner] = Button::resolve_icon( $icon );
		if ( ! $icon_raw ) {
			return '';
		}

		return sprintf(
			'<span class="mfb-simplerep__btn-icon"%s aria-hidden="true">%s</span>',
			$icon_data_attr,
			$icon_inner
		);
	}

	/**
	 * Adapts an icon value to what the active MetForm (Free) can render.
	 *
	 * Free 4.4.0+ (which has Icon_Library) renders every shape itself. An
	 * older Free's resolver doesn't know icon keys, so "fas-star" is mapped
	 * back to the "fas fa-star" class it renders with its icon font; the
	 * earliest resolver (before Icon_Resolver) only accepts strings, so an
	 * Icon API array is dropped rather than passed to it.
	 *
	 * @param string|array $icon Stored icon value.
	 * @return string|array The value to hand Button::resolve_icon(), or '' to render nothing.
	 */
	private static function adapt_icon_for_free( $icon ) {
		if ( class_exists( Icon_Library::class ) ) {
			return $icon;
		}

		if ( is_string( $icon ) && preg_match( '/^(fas|far|fab)-([a-z0-9]+(?:-[a-z0-9]+)*)$/', $icon, $matches ) ) {
			return $matches[1] . ' fa-' . $matches[2];
		}

		if ( is_array( $icon ) && ! class_exists( Icon_Resolver::class ) ) {
			return '';
		}

		return $icon;
	}

	/**
	 * Per-breakpoint values of layout (applied through a markup class
	 * on desktop). See Block_Base::get_responsive_markup_rules().
	 *
	 * @since 4.4.1
	 */
	protected function get_responsive_markup_rules(): array {
		return array_merge(
			parent::get_responsive_markup_rules(),
			array(
				'layout' => array(
					'block'  => '{{WRAPPER}} .mfb-simplerep__list { flex-direction: column; flex-wrap: nowrap; } {{WRAPPER}} .mfb-simplerep__list .mfb-simplerep__row { flex: 0 1 auto; }',
					'inline' => '{{WRAPPER}} .mfb-simplerep__list { flex-direction: row; flex-wrap: wrap; } {{WRAPPER}} .mfb-simplerep__list .mfb-simplerep__row { flex: 1 1 220px; }',
				),
			)
		);
	}

	public function render_markup( array $settings, Render_Context $context ): string {
		$id               = $context->get_element_id();
		$fields           = self::normalize_fields( $settings['fields'] ?? null );
		$name             = (string) ( $settings['name'] ?? '' );
		$layout           = 'inline' === Responsive_Value::resolve( $settings['layout'] ?? 'block', 'desktop', 'block' ) ? 'inline' : 'block';
		$add_text         = (string) ( $settings['addButtonText'] ?: __( 'Add', 'metform-pro' ) );
		$remove_text      = (string) ( $settings['removeButtonText'] ?: __( 'Remove', 'metform-pro' ) );
		$use_icon         = ! empty( $settings['useButtonIcon'] );
		$add_icon_html    = '';
		$remove_icon_html = '';
		if ( $use_icon ) {
			$add_icon_html    = Block_Icon::icon(
				$settings['addButtonIcon'] ?? '',
				'mfb-simplerep__btn-icon',
				array( 'aria-hidden' => 'true' ),
				'span'
			);
			$remove_icon_html = Block_Icon::icon(
				$settings['removeButtonIcon'] ?? '',
				'mfb-simplerep__btn-icon',
				array( 'aria-hidden' => 'true' ),
				'span'
			);
		}

		$required = ! empty( $settings['required'] );

		ob_start();
		if ( empty( $fields ) ) {
			?>
			<p class="mfb-simplerep__empty"><?php esc_html_e( 'No fields configured yet.', 'metform-pro' ); ?></p>
			<?php
		} else {
			?>
			<div class="mfb-simplerep__list <?php echo 'inline' === $layout ? 'mfb-simplerep__inline' : ''; ?>">
				<div class="mfb-simplerep__row" data-mfb-simplerep-row="0">
					<?php
					foreach ( $fields as $field ) :
						$field_name       = $field['name'];
						$field_label      = $field['label'];
						$full_name        = $name . '[0][' . $field_name . ']';
						$field_id         = $id . '-0-' . sanitize_html_class( $field_name );
						$show_field_label = false !== ( $field['showLabel'] ?? true );
						$field_type       = $this->resolve_field_type( $field );
						?>
					<div class="mfb-simplerep__field" data-mfb-simplerep-type="<?php echo esc_attr( $field_type ); ?>">
						<?php
						if ( $show_field_label && '' !== $field_label ) :
							$is_labelable = in_array( $field_type, self::LABELABLE_TYPES, true );
							?>
							<?php if ( $is_labelable ) : ?>
						<label class="mfb-simplerep__field-label" for="<?php echo esc_attr( $this->label_target_id( $field_type, $field_id ) ); ?>"><?php echo esc_html( $field_label ); ?></label>
						<?php else : ?>
						<span class="mfb-simplerep__field-label"><?php echo esc_html( $field_label ); ?></span>
						<?php endif; ?>
						<?php endif; ?>
						<?php echo $this->render_field_control( $field, $full_name, $field_id, $required ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</div>
						<?php endforeach; ?>
					<button type="button" class="mfb-simplerep__remove-btn" data-mfb-simplerep-remove disabled>
						<?php echo $remove_icon_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php echo esc_html( $remove_text ); ?>
					</button>
				</div>
			</div>
			<button type="button" class="mfb-simplerep__add-btn" data-mfb-simplerep-add>
				<?php echo $add_icon_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php echo esc_html( $add_text ); ?>
			</button>
			<?php
		}
		return (string) ob_get_clean();
	}
}
