<?php
namespace MetForm_Pro\Core\FormBuilder\Blocks\Creditcard;

use MetForm\Core\FormBuilder\Block_Base;
use MetForm\Core\FormBuilder\Rendering\Render_Context;

defined( 'ABSPATH' ) || exit;

final class Creditcard extends Block_Base {
	public function get_name(): string {
		return 'creditcard'; }
	public function get_title(): string {
		return __( 'Credit Card', 'metform-pro' ); }
	public function get_icon(): string {
		return 'CreditCard'; }
	public function get_category(): string {
		return 'Advanced'; }

	public function get_capabilities(): array {
		return array(
			'acceptsChildren' => false,
			'isField'         => true,
		);
	}

	/**
	 * The compiled frontend/form-builder bundle handle this block needs —
	 * enqueued only when this block is actually present, via this plugin's
	 * own Base::enqueue_block_assets() (mirrors canvas.php's identical
	 * per-block loop in the free plugin, which never sees Pro blocks).
	 */
	public function get_frontend_assets(): array {
		return array( 'metform-pro-form-builder-frontend' );
	}

	public function get_default_settings(): array {
		return array(
			'showLabel'               => true,
			'labelPosition'           => 'top',
			'label'                   => __( 'Credit Card', 'metform-pro' ),
			'name'                    => '',
			'helpText'                => '',
			'required'                => false,
			'requiredMessage'         => '',
			'disabled'                => false,
			'showHolderName'          => true,
			'fieldOrder'              => 'number-first',
			'numberPlaceholder'       => __( 'Card Number', 'metform-pro' ),
			'holderPlaceholder'       => __( 'Name on Card', 'metform-pro' ),
			'expiryPlaceholder'       => 'MM/YY',
			'cvvPlaceholder'          => __( 'CVV', 'metform-pro' ),
			'allowedBrands'           => array(),
			'invalidNumberMessage'    => '',
			'unsupportedBrandMessage' => '',
			'invalidExpiryMessage'    => '',
			'invalidCvvMessage'       => '',
			'__className'             => '',
			'styles'                  => array(),
		);
	}

	public function get_property_schema(): array {
		return array(
			'showLabel'               => array( 'type' => 'boolean' ),
			'label'                   => array( 'type' => 'string' ),
			'labelPosition'           => array(
				'type'       => 'string',
				'enum'       => array( 'top', 'left' ),
				'responsive' => true,
			),
			'name'                    => array( 'type' => 'field_name' ),
			'helpText'                => array( 'type' => 'string' ),
			'required'                => array( 'type' => 'boolean' ),
			'requiredMessage'         => array( 'type' => 'string' ),
			'disabled'                => array( 'type' => 'boolean' ),
			'showHolderName'          => array( 'type' => 'boolean' ),
			'fieldOrder'              => array(
				'type' => 'string',
				'enum' => array( 'number-first', 'name-first' ),
			),
			'numberPlaceholder'       => array( 'type' => 'string' ),
			'holderPlaceholder'       => array( 'type' => 'string' ),
			'expiryPlaceholder'       => array( 'type' => 'string' ),
			'cvvPlaceholder'          => array( 'type' => 'string' ),
			'allowedBrands'           => array( 'type' => 'array' ),
			'invalidNumberMessage'    => array( 'type' => 'string' ),
			'unsupportedBrandMessage' => array( 'type' => 'string' ),
			'invalidExpiryMessage'    => array( 'type' => 'string' ),
			'invalidCvvMessage'       => array( 'type' => 'string' ),
			'__className'             => array( 'type' => 'css_class' ),
		);
	}

	private static function typography_selector( string $el ): string {
		return "{{WRAPPER}} {$el} { font-family: {{FONT_FAMILY}}; font-size: {{FONT_SIZE}}; font-weight: {{FONT_WEIGHT}}; font-style: {{FONT_STYLE}}; text-transform: {{TEXT_TRANSFORM}}; text-decoration: {{TEXT_DECORATION}}; line-height: {{LINE_HEIGHT}}; letter-spacing: {{LETTER_SPACING}}; word-spacing: {{WORD_SPACING}}; }";
	}

	public function register_controls(): array {
		$field_selector = '.mfb-creditcard__group input';

		return array(
			'content' => array_merge(
				array(
					array(
						'type'        => 'section',
						'key'         => 'content',
						'label'       => __( 'Content', 'metform-pro' ),
						'defaultOpen' => true,
					),
					'condition' => array( 'showLabel!' => false ),
				),
				array(
					array(
						'type'    => 'toggle',
						'key'     => 'showLabel',
						'label'   => __( 'Show Label', 'metform-pro' ),
						'default' => true,
					),
					array(
						'type'      => 'text',
						'key'       => 'label',
						'label'     => __( 'Label', 'metform-pro' ),
						'default'   => __( 'Credit Card', 'metform-pro' ),
						'condition' => array( 'showLabel!' => false ),
					),
					array(
						'type'       => 'select',
						'key'        => 'labelPosition',
						'label'      => __( 'Label Position', 'metform-pro' ),
						'default'    => 'top',
						'options'    => array(
							array(
								'label' => __( 'Top', 'metform-pro' ),
								'value' => 'top',
							),
							array(
								'label' => __( 'Left', 'metform-pro' ),
								'value' => 'left',
							),
						),
						'condition'  => array( 'showLabel!' => false ),
						'responsive' => true,
					),
					array(
						'type'  => 'text',
						'key'   => 'name',
						'label' => __( 'Name', 'metform-pro' ),
						'help'  => __( 'Name is must required. Enter name without space or any special character. use only underscore/ hyphen (_/-) for multiple word. Name must be different.', 'metform-pro' ),
					),
					array(
						'type'  => 'text',
						'key'   => 'helpText',
						'label' => __( 'Help Text', 'metform-pro' ),
						'help'  => __( 'Shown below the field to guide users', 'metform-pro' ),
					),
					array(
						'type'    => 'toggle',
						'key'     => 'showHolderName',
						'label'   => __( 'Show Name on Card', 'metform-pro' ),
						'help'    => __( 'Adds a field for the name printed on the card.', 'metform-pro' ),
						'default' => true,
					),
					array(
						'type'      => 'select',
						'key'       => 'fieldOrder',
						'label'     => __( 'Field Order', 'metform-pro' ),
						'default'   => 'number-first',
						'condition' => array( 'showHolderName!' => false ),
						'options'   => array(
							array(
								'label' => __( 'Card Number first', 'metform-pro' ),
								'value' => 'number-first',
							),
							array(
								'label' => __( 'Name on Card first', 'metform-pro' ),
								'value' => 'name-first',
							),
						),
					),

					// Sub-fields, in their default on-form order.
					array(
						'type'    => 'text',
						'key'     => 'numberPlaceholder',
						'label'   => __( 'Card Number Placeholder', 'metform-pro' ),
						'help'    => __( 'Leave blank to use the default.', 'metform-pro' ),
						'default' => __( 'Card Number', 'metform-pro' ),
					),
					array(
						'type'      => 'text',
						'key'       => 'holderPlaceholder',
						'label'     => __( 'Name on Card Placeholder', 'metform-pro' ),
						'help'      => __( 'Leave blank to use the default.', 'metform-pro' ),
						'default'   => __( 'Name on Card', 'metform-pro' ),
						'condition' => array( 'showHolderName!' => false ),
					),
					array(
						'type'    => 'text',
						'key'     => 'expiryPlaceholder',
						'label'   => __( 'Expiry Date Placeholder', 'metform-pro' ),
						'help'    => __( 'Leave blank to use the default.', 'metform-pro' ),
						'default' => 'MM/YY',
					),
					array(
						'type'    => 'text',
						'key'     => 'cvvPlaceholder',
						'label'   => __( 'CVV Placeholder', 'metform-pro' ),
						'help'    => __( 'Leave blank to use the default.', 'metform-pro' ),
						'default' => __( 'CVV', 'metform-pro' ),
					),

					array(
						'type'        => 'section',
						'key'         => 'settings',
						'label'       => __( 'Settings', 'metform-pro' ),
						'defaultOpen' => false,
					),
					array(
						'type'    => 'toggle',
						'key'     => 'required',
						'label'   => __( 'Required', 'metform-pro' ),
						'default' => false,
					),
					array(
						'type'      => 'text',
						'key'       => 'requiredMessage',
						'label'     => __( 'Required Message', 'metform-pro' ),
						'help'      => __( 'Shown when the field is left empty.', 'metform-pro' ),
						'condition' => array( 'required' => true ),
					),
					array(
						'type'    => 'toggle',
						'key'     => 'disabled',
						'label'   => __( 'Disabled', 'metform-pro' ),
						'help'    => __( 'Visitors can’t type in any of the card fields.', 'metform-pro' ),
						'default' => false,
					),
					array(
						'type'    => 'select2',
						'key'     => 'allowedBrands',
						'label'   => __( 'Accepted Card Brands', 'metform-pro' ),
						'help'    => __( 'Leave empty to accept all supported brands.', 'metform-pro' ),
						'default' => array(),
						'options' => array(
							array(
								'label' => 'Visa',
								'value' => 'Visa',
							),
							array(
								'label' => 'Mastercard',
								'value' => 'Mastercard',
							),
							array(
								'label' => __( 'American Express', 'metform-pro' ),
								'value' => 'Amex',
							),
							array(
								'label' => 'Discover',
								'value' => 'Discover',
							),
							array(
								'label' => 'Diners Club',
								'value' => 'Diners',
							),
							array(
								'label' => 'JCB',
								'value' => 'JCB',
							),
						),
					),
					array(
						'type'  => 'text',
						'key'   => 'invalidNumberMessage',
						'label' => __( 'Invalid Card Number Message', 'metform-pro' ),
						'help'  => __( 'Default: "Please enter a valid card number."', 'metform-pro' ),
					),
					array(
						'type'  => 'text',
						'key'   => 'unsupportedBrandMessage',
						'label' => __( 'Card Not Accepted Message', 'metform-pro' ),
						'help'  => __( 'Shown when the card type isn’t in Accepted Card Brands. Default: "This card type is not accepted."', 'metform-pro' ),
					),
					array(
						'type'  => 'text',
						'key'   => 'invalidExpiryMessage',
						'label' => __( 'Invalid Expiry Date Message', 'metform-pro' ),
						'help'  => __( 'Default: "Please enter a valid expiry date (MM/YY)."', 'metform-pro' ),
					),
					array(
						'type'  => 'text',
						'key'   => 'invalidCvvMessage',
						'label' => __( 'Invalid CVV Message', 'metform-pro' ),
						'help'  => __( 'Default: "CVV must be 3 digits (4 for American Express)."', 'metform-pro' ),
					),
				)
			),
			'style'   => array(
				array(
					'type'        => 'section',
					'label'       => __( 'Label', 'metform-pro' ),
					'defaultOpen' => true,
					'condition'   => array( 'showLabel!' => false ),
				),
				array(
					'type'      => 'color',
					'key'       => 'styles.labelColor',
					'label'     => __( 'Label Color', 'metform-pro' ),
					'default'   => '#374151',
					'selector'  => '{{WRAPPER}} .mfb-label { color: {{VALUE}}; }',
					'condition' => array( 'showLabel!' => false ),
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.labelTypography',
					'label'          => __( 'Label Typography', 'metform-pro' ),
					'selector'       => self::typography_selector( '.mfb-label' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
					'condition'      => array( 'showLabel!' => false ),
				),
				array(
					'type'  => 'section',
					'label' => __( 'Help Text & Error', 'metform-pro' ),
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.helpTextColor',
					'label'    => __( 'Help Text Color', 'metform-pro' ),
					'default'  => '#6b7280',
					'selector' => '{{WRAPPER}} .mfb-field__help { color: {{VALUE}}; }',
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.errorColor',
					'label'    => __( 'Error Color', 'metform-pro' ),
					'default'  => '#ef4444',
					'selector' => '{{WRAPPER}} .mfb-field__error { color: {{VALUE}}; }',
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.helpTextTypography',
					'label'          => __( 'Help Text Typography', 'metform-pro' ),
					'selector'       => self::typography_selector( '.mfb-field__help' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.errorTypography',
					'label'          => __( 'Error Typography', 'metform-pro' ),
					'selector'       => self::typography_selector( '.mfb-field__error' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
				),

				array(
					'type'  => 'section',
					'label' => __( 'Field', 'metform-pro' ),
				),
				array(
					'type' => 'tabs',
					'tab'  => array( 'normal', 'hover', 'focus' ),
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.color',
					'label'    => __( 'Text Color', 'metform-pro' ),
					'tab'      => 'normal',
					'default'  => '#111827',
					'selector' => "{{WRAPPER}} {$field_selector} { color: {{VALUE}}; }",
				),
				array(
					'type'     => 'background',
					'key'      => 'styles.background',
					'label'    => __( 'Background', 'metform-pro' ),
					'tab'      => 'normal',
					'default'  => array(
						'type'  => 'classic',
						'color' => '#ffffff',
					),
					'selector' => "{{WRAPPER}} {$field_selector} { {{VALUE}} }",
				),
				// The normal-state border color is in the Border control
				// below (with a fallback to this block's old standalone
				// 'styles.borderColor').
				array(
					'type'     => 'color',
					'key'      => 'styles.hoverColor',
					'label'    => __( 'Text Color', 'metform-pro' ),
					'tab'      => 'hover',
					'default'  => '#111827',
					'selector' => "{{WRAPPER}} {$field_selector}:hover { color: {{VALUE}}; }",
				),
				array(
					'type'     => 'background',
					'key'      => 'styles.hoverBackground',
					'label'    => __( 'Background', 'metform-pro' ),
					'tab'      => 'hover',
					'default'  => array(
						'type'  => 'classic',
						'color' => '#ffffff',
					),
					'selector' => "{{WRAPPER}} {$field_selector}:hover { {{VALUE}} }",
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.hoverBorderColor',
					'label'    => __( 'Hover Border Color', 'metform-pro' ),
					'tab'      => 'hover',
					'default'  => '#9ca3af',
					'selector' => "{{WRAPPER}} {$field_selector}:hover { border-color: {{VALUE}}; }",
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.focusColor',
					'label'    => __( 'Text Color', 'metform-pro' ),
					'tab'      => 'focus',
					'default'  => '#111827',
					'selector' => "{{WRAPPER}} {$field_selector}:focus { color: {{VALUE}}; }",
				),
				array(
					'type'     => 'background',
					'key'      => 'styles.focusBackground',
					'label'    => __( 'Background', 'metform-pro' ),
					'tab'      => 'focus',
					'default'  => array(
						'type'  => 'classic',
						'color' => '#ffffff',
					),
					'selector' => "{{WRAPPER}} {$field_selector}:focus { {{VALUE}} }",
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.focusBorderColor',
					'label'    => __( 'Focus Border Color', 'metform-pro' ),
					'tab'      => 'focus',
					'default'  => '#3b82f6',
					'selector' => "{{WRAPPER}} {$field_selector}:focus { border-color: {{VALUE}}; outline-color: {{VALUE}}; }",
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.placeholderColor',
					'label'    => __( 'Placeholder Color', 'metform-pro' ),
					'default'  => '#9ca3af',
					'selector' => "{{WRAPPER}} {$field_selector}::placeholder { color: {{VALUE}}; opacity: 1; }",
				),

				array(
					'type'  => 'section',
					'label' => __( 'Layout', 'metform-pro' ),
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.typography',
					'label'          => __( 'Typography', 'metform-pro' ),
					'selector'       => self::typography_selector( $field_selector ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
				),
				array(
					'type'       => 'range',
					'key'        => 'styles.width',
					'label'      => __( 'Width', 'metform-pro' ),
					'default'    => '100%',
					'units'      => array( 'px', '%', 'em', 'rem' ),
					'selector'   => '{{WRAPPER}} .mfb-creditcard__group { width: {{VALUE}}; }',
					'responsive' => true,
				),
				array(
					'type'       => 'range',
					'key'        => 'styles.gap',
					'label'      => __( 'Row Gap', 'metform-pro' ),
					'default'    => '10px',
					'units'      => array( 'px' ),
					'min'        => 0,
					'max'        => 40,
					'selector'   => '{{WRAPPER}} .mfb-creditcard__group { gap: {{VALUE}}; }',
					'responsive' => true,
				),
				array(
					'type'       => 'range',
					'key'        => 'styles.bottomRowGap',
					'label'      => __( 'Expiry / CVV Gap', 'metform-pro' ),
					'default'    => '10px',
					'units'      => array( 'px' ),
					'min'        => 0,
					'max'        => 40,
					'selector'   => '{{WRAPPER}} .mfb-creditcard__bottom-row { gap: {{VALUE}}; }',
					'responsive' => true,
				),
				array(
					'type'       => 'number',
					'key'        => 'styles.expiryFlex',
					'label'      => __( 'Expiry Width Ratio', 'metform-pro' ),
					'default'    => 2,
					'min'        => 1,
					'max'        => 4,
					'step'       => 1,
					'selector'   => '{{WRAPPER}} .mfb-creditcard__expiry { flex: {{VALUE}}; }',
					'responsive' => true,
				),
				array(
					'type'       => 'number',
					'key'        => 'styles.cvvFlex',
					'label'      => __( 'CVV Width Ratio', 'metform-pro' ),
					'default'    => 1,
					'min'        => 1,
					'max'        => 4,
					'step'       => 1,
					'selector'   => '{{WRAPPER}} .mfb-creditcard__cvv { flex: {{VALUE}}; }',
					'responsive' => true,
				),
				array(
					'type'       => 'dimensions',
					'key'        => 'styles.padding',
					'label'      => __( 'Field Padding', 'metform-pro' ),
					'default'    => array(
						'top'    => '10px',
						'right'  => '16px',
						'bottom' => '10px',
						'left'   => '16px',
					),
					'selector'   => "{{WRAPPER}} {$field_selector} { padding: {{TOP}} {{RIGHT}} {{BOTTOM}} {{LEFT}}; }",
					'responsive' => true,
				),

				array(
					'type'  => 'section',
					'label' => __( 'Border', 'metform-pro' ),
				),
				// Style, width, color and radius of the fields' normal state;
				// the Hover/Focus Border Color swatches above override the
				// color (`:hover`/`:focus` are one pseudo-class more specific).
				array(
					'type'           => 'border',
					'key'            => 'styles.border',
					'label'          => __( 'Border', 'metform-pro' ),
					'default'        => array(
						'borderType' => 'solid',
						'width'      => array(
							'top'    => '1px',
							'right'  => '1px',
							'bottom' => '1px',
							'left'   => '1px',
						),
						'radius'     => array(
							'top'    => '6px',
							'right'  => '6px',
							'bottom' => '6px',
							'left'   => '6px',
						),
					),
					'selector'       => "{{WRAPPER}} {$field_selector} { {{VALUE}} }",
					'responsive'     => true,
					'responsiveKeys' => array( 'width', 'radius' ),
					'widthFallback'  => '1px',
					'legacy'         => array(
						'color' => array(
							'key'     => 'styles.borderColor',
							'default' => '#d1d5db',
						),
					),
				),
				array(
					'type'     => 'boxShadow',
					'key'      => 'styles.boxShadow',
					'label'    => __( 'Box Shadow', 'metform-pro' ),
					'selector' => "{{WRAPPER}} {$field_selector} { box-shadow: {{VALUE}}; }",
				),
			),
		);
	}

	/** One `<input>`, matching index.jsx's per-field markup shape/attributes. */
	private function render_input( string $type_attr, string $name, string $class, string $placeholder, string $autocomplete, bool $disabled, bool $required, ?string $id = null ): string {
		return sprintf(
			'<input%1$s type="%2$s" inputmode="numeric" autocomplete="%3$s" name="%4$s" class="mfb-field__input %5$s" placeholder="%6$s" %7$s %8$s>',
			null !== $id ? ' id="' . esc_attr( $id ) . '"' : '',
			esc_attr( $type_attr ),
			esc_attr( $autocomplete ),
			esc_attr( $name ),
			esc_attr( $class ),
			esc_attr( $placeholder ),
			$disabled ? 'disabled' : '',
			$required ? 'required' : ''
		);
	}

	public function render_markup( array $settings, Render_Context $context ): string {
		$id   = $context->get_element_id();
		$name = (string) ( $settings['name'] ?? '' );
		$key  = '' !== $name ? $name : $id;

		$is_disabled = ! empty( $settings['disabled'] );
		$is_required = ! empty( $settings['required'] );
		$show_holder = false !== ( $settings['showHolderName'] ?? true );
		$name_first  = $show_holder && 'name-first' === ( $settings['fieldOrder'] ?? 'number-first' );

		$number_field = $this->render_input(
			'text',
			$key,
			'mfb-creditcard__number',
			(string) ( $settings['numberPlaceholder'] ?: __( 'Card Number', 'metform-pro' ) ),
			'cc-number',
			$is_disabled,
			$is_required,
			$id
		);

		$holder_field = $show_holder
			? sprintf(
				'<input type="text" autocomplete="cc-name" name="%1$s" class="mfb-field__input mfb-creditcard__holder" placeholder="%2$s" %3$s %4$s>',
				esc_attr( $key . '_holder' ),
				esc_attr( (string) ( $settings['holderPlaceholder'] ?: __( 'Name on Card', 'metform-pro' ) ) ),
				$is_disabled ? 'disabled' : '',
				$is_required ? 'required' : ''
			)
			: '';

		$ordered_fields = $name_first ? ( $holder_field . $number_field ) : ( $number_field . $holder_field );

		$expiry_field = $this->render_input(
			'text',
			$key . '_expiry',
			'mfb-creditcard__expiry',
			(string) ( $settings['expiryPlaceholder'] ?: 'MM/YY' ),
			'cc-exp',
			$is_disabled,
			$is_required
		);

		$cvv_field = $this->render_input(
			'text',
			$key . '_cvv',
			'mfb-creditcard__cvv',
			(string) ( $settings['cvvPlaceholder'] ?: __( 'CVV', 'metform-pro' ) ),
			'cc-csc',
			$is_disabled,
			$is_required
		);

		$allowed_brands = array_values( array_filter( array_map( 'strval', (array) ( $settings['allowedBrands'] ?? array() ) ) ) );
		$group_attrs    = sprintf(
			' data-mf-allowed-brands="%1$s" data-mf-invalid-number-message="%2$s" data-mf-unsupported-brand-message="%3$s" data-mf-invalid-expiry-message="%4$s" data-mf-invalid-cvv-message="%5$s"',
			esc_attr( implode( ',', $allowed_brands ) ),
			esc_attr( (string) ( $settings['invalidNumberMessage'] ?? '' ) ),
			esc_attr( (string) ( $settings['unsupportedBrandMessage'] ?? '' ) ),
			esc_attr( (string) ( $settings['invalidExpiryMessage'] ?? '' ) ),
			esc_attr( (string) ( $settings['invalidCvvMessage'] ?? '' ) )
		);

		return sprintf(
			'<div class="mfb-creditcard__group"%5$s>%1$s<input type="hidden" name="%2$s" value="" class="mfb-creditcard__type"><div class="mfb-creditcard__bottom-row">%3$s%4$s</div></div>',
			$ordered_fields, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			esc_attr( $key . '--type' ),
			$expiry_field, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			$cvv_field, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			$group_attrs // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		);
	}
}
