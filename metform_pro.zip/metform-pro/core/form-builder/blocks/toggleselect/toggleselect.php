<?php
namespace MetForm_Pro\Core\FormBuilder\Blocks\Toggleselect;

use MetForm\Core\FormBuilder\Block_Base;
use MetForm\Core\FormBuilder\Dynamic_Css\Responsive_Value;
use MetForm\Core\FormBuilder\Rendering\Render_Context;

defined( 'ABSPATH' ) || exit;

final class Toggleselect extends Block_Base {
	public function get_name(): string {
		return 'toggleselect'; }
	public function get_title(): string {
		return __( 'Toggle Select', 'metform-pro' ); }
	public function get_icon(): string {
		return 'ToggleLeft'; }
	public function get_category(): string {
		return 'Advanced'; }

	public function get_capabilities(): array {
		return array(
			'acceptsChildren' => false,
			'isField'         => true,
		);
	}

	/**
	 * The compiled frontend/form-builder bundle handle this block needs —
	 * enqueued only when this block is actually present, via this plugin's
	 * own Base::enqueue_block_assets() (mirrors canvas.php's identical
	 * per-block loop in the free plugin, which never sees Pro blocks).
	 */
	public function get_frontend_assets(): array {
		return array( 'metform-pro-form-builder-frontend' );
	}

	public function get_default_settings(): array {
		return array(
			'label'                => __( 'Toggle Select', 'metform-pro' ),
			'labelPosition'        => 'top',
			'name'                 => '',
			'helpText'             => '',
			'required'             => false,
			'showLabel'            => true,
			'layout'               => 'horizontal',
			'options'              => array(
				array(
					'label'     => 'Option 1',
					'value'     => 'option-1',
					'disabled'  => false,
					'isDefault' => false,
				),
				array(
					'label'     => 'Option 2',
					'value'     => 'option-2',
					'disabled'  => false,
					'isDefault' => false,
				),
				array(
					'label'     => 'Option 3',
					'value'     => 'option-3',
					'disabled'  => false,
					'isDefault' => false,
				),
			),
			'quizPoint'            => 0,
			'quizAddNegativePoint' => false,
			'quizNegativePoint'    => 0,
			'styles'               => array(),
		);
	}

	public function get_property_schema(): array {
		return array(
			'label'                => array( 'type' => 'string' ),
			'labelPosition'        => array(
				'type'       => 'string',
				'enum'       => array( 'top', 'left' ),
				'responsive' => true,
			),
			'name'                 => array( 'type' => 'field_name' ),
			'helpText'             => array( 'type' => 'string' ),
			'required'             => array( 'type' => 'boolean' ),
			'showLabel'            => array( 'type' => 'boolean' ),
			'requiredMessage'      => array( 'type' => 'string' ),
			'layout'               => array(
				'type'       => 'string',
				'enum'       => array( 'horizontal', 'vertical' ),
				'responsive' => true,
			),
			'options'              => array( 'type' => 'object' ),
			'quizPoint'            => array( 'type' => 'number' ),
			'quizAddNegativePoint' => array( 'type' => 'boolean' ),
			'quizNegativePoint'    => array( 'type' => 'number' ),
		);
	}

	private function typography_selector( string $el ): string {
		return "{{WRAPPER}} {$el} { font-family: {{FONT_FAMILY}}; font-size: {{FONT_SIZE}}; font-weight: {{FONT_WEIGHT}}; font-style: {{FONT_STYLE}}; text-transform: {{TEXT_TRANSFORM}}; text-decoration: {{TEXT_DECORATION}}; line-height: {{LINE_HEIGHT}}; letter-spacing: {{LETTER_SPACING}}; word-spacing: {{WORD_SPACING}}; }";
	}

	public function register_controls(): array {
		return array(
			'content' => array(
				array(
					'type'        => 'section',
					'key'         => 'content',
					'label'       => __( 'Content', 'metform-pro' ),
					'defaultOpen' => true,
				),
				array(
					'type'    => 'toggle',
					'key'     => 'showLabel',
					'label'   => __( 'Show Label', 'metform-pro' ),
					'default' => true,
				),
				array(
					'type'      => 'text',
					'key'       => 'label',
					'label'     => __( 'Label', 'metform-pro' ),
					'default'   => __( 'Toggle Select', 'metform-pro' ),
					'condition' => array( 'showLabel!' => false ),
				),
				array(
					'type'       => 'select',
					'key'        => 'labelPosition',
					'label'      => __( 'Label Position', 'metform-pro' ),
					'default'    => 'top',
					'options'    => array(
						array(
							'label' => __( 'Top', 'metform-pro' ),
							'value' => 'top',
						),
						array(
							'label' => __( 'Left', 'metform-pro' ),
							'value' => 'left',
						),
					),
					'condition'  => array( 'showLabel!' => false ),
					'responsive' => true,
				),
				array(
					'type'  => 'text',
					'key'   => 'name',
					'label' => __( 'Name', 'metform-pro' ),
					'help'  => __( 'Name is must required. Enter name without space or any special character. use only underscore/ hyphen (_/-) for multiple word. Name must be different.', 'metform-pro' ),
				),
				array(
					'type'  => 'text',
					'key'   => 'helpText',
					'label' => __( 'Help Text', 'metform-pro' ),
					'help'  => __( 'Shown below the field to guide users', 'metform-pro' ),
				),
				array(
					'type'       => 'select',
					'key'        => 'layout',
					'label'      => __( 'Option Display', 'metform-pro' ),
					'default'    => 'horizontal',
					'options'    => array(
						array(
							'label' => __( 'Horizontal', 'metform-pro' ),
							'value' => 'horizontal',
						),
						array(
							'label' => __( 'Vertical', 'metform-pro' ),
							'value' => 'vertical',
						),
					),
					'responsive' => true,
				),
				array(
					'type'       => 'repeater',
					'key'        => 'options',
					'label'      => __( 'Options', 'metform-pro' ),
					'default'    => array(
						array(
							'label'     => 'Option 1',
							'value'     => 'option-1',
							'disabled'  => false,
							'isDefault' => false,
						),
						array(
							'label'     => 'Option 2',
							'value'     => 'option-2',
							'disabled'  => false,
							'isDefault' => false,
						),
						array(
							'label'     => 'Option 3',
							'value'     => 'option-3',
							'disabled'  => false,
							'isDefault' => false,
						),
					),
					'titleField' => 'label',
					'addLabel'   => __( 'ADD OPTION', 'metform-pro' ),
					'min'        => 1,
					'fields'     => array(
						array(
							'type'  => 'text',
							'key'   => 'label',
							'label' => __( 'Label', 'metform-pro' ),
						),
						array(
							'type'  => 'text',
							'key'   => 'value',
							'label' => __( 'Value', 'metform-pro' ),
						),
						array(
							'type'  => 'toggle',
							'key'   => 'disabled',
							'label' => __( 'Disabled', 'metform-pro' ),
						),
						array(
							'type'  => 'toggle',
							'key'   => 'isDefault',
							'label' => __( 'Default Selected', 'metform-pro' ),
						),
						array(
							'type'  => 'toggle',
							'key'   => 'isQuizAnswer',
							'label' => __( 'Correct Answer', 'metform-pro' ),
						),
					),
				),

				array(
					'type'        => 'section',
					'key'         => 'settings',
					'label'       => __( 'Settings', 'metform-pro' ),
					'defaultOpen' => false,
				),
				array(
					'type'    => 'toggle',
					'key'     => 'required',
					'label'   => __( 'Required', 'metform-pro' ),
					'default' => false,
				),
				array(
					'type'      => 'text',
					'key'       => 'requiredMessage',
					'label'     => __( 'Required Message', 'metform-pro' ),
					'help'      => __( 'Shown when no option is selected.', 'metform-pro' ),
					'condition' => array( 'required' => true ),
				),

				array(
					'type'        => 'section',
					'key'         => 'quiz',
					'label'       => __( 'Quiz Settings', 'metform-pro' ),
					'defaultOpen' => false,
					'condition'   => array( '$form.formType' => 'quiz-form' ),
				),
				array(
					'type'      => 'number',
					'key'       => 'quizPoint',
					'label'     => __( 'Points', 'metform-pro' ),
					'default'   => 0,
					'min'       => 0,
					'help'      => __( "Note: if the point and the negative point both are set at zero, we won't consider it a question.", 'metform-pro' ),
					'condition' => array( '$form.formType' => 'quiz-form' ),
				),
				array(
					'type'      => 'toggle',
					'key'       => 'quizAddNegativePoint',
					'label'     => __( 'Deduct Points for Wrong Answer', 'metform-pro' ),
					'default'   => false,
					'condition' => array( '$form.formType' => 'quiz-form' ),
				),
				array(
					'type'      => 'number',
					'key'       => 'quizNegativePoint',
					'label'     => __( 'Points to Deduct', 'metform-pro' ),
					'default'   => 0,
					'min'       => 0,
					'step'      => 0.5,
					'condition' => array(
						'$form.formType'       => 'quiz-form',
						'quizAddNegativePoint' => true,
					),
				),
			),
			'style'   => array(
				array(
					'type'        => 'section',
					'label'       => __( 'Label', 'metform-pro' ),
					'defaultOpen' => true,
					'condition'   => array( 'showLabel!' => false ),
				),
				array(
					'type'      => 'color',
					'key'       => 'styles.labelColor',
					'label'     => __( 'Label Color', 'metform-pro' ),
					'default'   => '#374151',
					'selector'  => '{{WRAPPER}} .mfb-label { color: {{VALUE}}; }',
					'condition' => array( 'showLabel!' => false ),
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.labelTypography',
					'label'          => __( 'Label Typography', 'metform-pro' ),
					'selector'       => $this->typography_selector( '.mfb-label' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
					'condition'      => array( 'showLabel!' => false ),
				),
				array(
					'type'  => 'section',
					'label' => __( 'Help Text & Error', 'metform-pro' ),
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.helpTextColor',
					'label'    => __( 'Help Text Color', 'metform-pro' ),
					'default'  => '#6b7280',
					'selector' => '{{WRAPPER}} .mfb-field__help { color: {{VALUE}}; }',
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.errorColor',
					'label'    => __( 'Error Color', 'metform-pro' ),
					'default'  => '#ef4444',
					'selector' => '{{WRAPPER}} .mfb-field__error { color: {{VALUE}}; }',
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.helpTextTypography',
					'label'          => __( 'Help Text Typography', 'metform-pro' ),
					'selector'       => $this->typography_selector( '.mfb-field__help' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.errorTypography',
					'label'          => __( 'Error Typography', 'metform-pro' ),
					'selector'       => $this->typography_selector( '.mfb-field__error' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
				),

				array(
					'type'  => 'section',
					'label' => __( 'Button', 'metform-pro' ),
				),
				array(
					'type' => 'tabs',
					'tab'  => array( 'normal', 'selected' ),
				),
				array(
					'type'     => 'background',
					'key'      => 'styles.buttonBg',
					'label'    => __( 'Background', 'metform-pro' ),
					'tab'      => 'normal',
					'default'  => array(
						'type'  => 'classic',
						'color' => '#ffffff',
					),
					'selector' => '{{WRAPPER}} .mfb-toggle__btn { {{VALUE}} }',
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.buttonColor',
					'label'    => __( 'Text Color', 'metform-pro' ),
					'tab'      => 'normal',
					'default'  => '#374151',
					'selector' => '{{WRAPPER}} .mfb-toggle__btn { color: {{VALUE}}; }',
				),
				array(
					'type'           => 'border',
					'key'            => 'styles.buttonBorder',
					'label'          => __( 'Border', 'metform-pro' ),
					'tab'            => 'normal',
					'default'        => array(
						'borderType' => 'solid',
						'width'      => array(
							'top'    => '1px',
							'right'  => '1px',
							'bottom' => '1px',
							'left'   => '1px',
						),
						'color'      => '#d1d5db',
						'radius'     => array(
							'top'    => '6px',
							'right'  => '6px',
							'bottom' => '6px',
							'left'   => '6px',
						),
					),
					'selector'       => '{{WRAPPER}} .mfb-toggle__btn { {{VALUE}} }',
					'responsive'     => true,
					'responsiveKeys' => array( 'width', 'radius' ),
				),
				array(
					'type'     => 'background',
					'key'      => 'styles.buttonSelBg',
					'label'    => __( 'Background', 'metform-pro' ),
					'tab'      => 'selected',
					'default'  => array(
						'type'  => 'classic',
						'color' => '#2563eb',
					),
					'selector' => '{{WRAPPER}} .mfb-toggle__btn:has(.mfb-toggle__input-native:checked) { {{VALUE}} }',
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.buttonSelColor',
					'label'    => __( 'Text Color', 'metform-pro' ),
					'tab'      => 'selected',
					'default'  => '#ffffff',
					'selector' => '{{WRAPPER}} .mfb-toggle__btn:has(.mfb-toggle__input-native:checked) { color: {{VALUE}}; }',
				),
				array(
					'type'           => 'border',
					'key'            => 'styles.buttonSelBorder',
					'label'          => __( 'Border', 'metform-pro' ),
					'tab'            => 'selected',
					'default'        => array(
						'borderType' => 'solid',
						'width'      => array(
							'top'    => '1px',
							'right'  => '1px',
							'bottom' => '1px',
							'left'   => '1px',
						),
						'color'      => '#2563eb',
						'radius'     => array(
							'top'    => '6px',
							'right'  => '6px',
							'bottom' => '6px',
							'left'   => '6px',
						),
					),
					'selector'       => '{{WRAPPER}} .mfb-toggle__btn:has(.mfb-toggle__input-native:checked) { {{VALUE}} }',
					'responsive'     => true,
					'responsiveKeys' => array( 'width', 'radius' ),
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.buttonTypography',
					'label'          => __( 'Typography', 'metform-pro' ),
					'selector'       => $this->typography_selector( '.mfb-toggle__btn' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
				),
				array(
					'type'  => 'section',
					'label' => __( 'Spacing', 'metform-pro' ),
				),
				array(
					'type'       => 'range',
					'key'        => 'styles.buttonGap',
					'label'      => __( 'Gap Between Buttons', 'metform-pro' ),
					'default'    => '8px',
					'selector'   => '{{WRAPPER}} .mfb-toggle__group { gap: {{VALUE}}; }',
					'responsive' => true,
				),
			),
		);
	}

	/**
	 * A bare `required` on the first radio in the group is enough for the browser to require "at least one checked" across it — see radio.php's identical reasoning.
	 * `checked` mirrors radio.php's/checkbox.php's `isDefault` handling — without it no option could ever render pre-selected, and a required group with no default would show as blank/unanswered on first load even when the admin configured one.
	 */
	private function render_option( array $opt, string $name, bool $required = false ): string {
		$is_quiz_answer = ! empty( $opt['isQuizAnswer'] );
		return sprintf(
			'<label class="mfb-toggle__btn"><input type="radio" name="%1$s" value="%2$s" class="mfb-toggle__input-native" %3$s %4$s %5$s %6$s><span class="mfb-toggle__btn-text">%7$s</span></label>',
			esc_attr( $name ),
			esc_attr( (string) ( $opt['value'] ?? '' ) ),
			! empty( $opt['disabled'] ) ? 'disabled' : '',
			$required ? 'required' : '',
			! empty( $opt['isDefault'] ) ? 'checked' : '',
			$is_quiz_answer ? 'data-quiz-answer="true"' : '',
			esc_html( (string) ( $opt['label'] ?? '' ) )
		);
	}

	/**
	 * Per-breakpoint values of layout (applied through a markup class
	 * on desktop). See Block_Base::get_responsive_markup_rules().
	 *
	 * @since 4.4.1
	 */
	protected function get_responsive_markup_rules(): array {
		return array_merge(
			parent::get_responsive_markup_rules(),
			array(
				'layout' => array(
					'vertical'   => '{{WRAPPER}} .mfb-toggle__group { flex-direction: column; flex-wrap: nowrap; }',
					'horizontal' => '{{WRAPPER}} .mfb-toggle__group { flex-direction: row; flex-wrap: wrap; }',
				),
			)
		);
	}

	public function render_markup( array $settings, Render_Context $context ): string {
		$name            = (string) ( $settings['name'] ?? '' );
		$options         = is_array( $settings['options'] ?? null ) ? $settings['options'] : array();
		$group_classes   = 'mfb-toggle__group' . ( 'horizontal' === Responsive_Value::resolve( $settings['layout'] ?? 'horizontal', 'desktop', 'horizontal' ) ? ' mfb-toggle__horizontal' : '' );
		$required        = ! empty( $settings['required'] );
		$default_claimed = false;

		$rows = '';
		foreach ( $options as $opt ) {
			if ( ! is_array( $opt ) ) {
				continue;
			}
			if ( $default_claimed ) {
				$opt['isDefault'] = false;
			} elseif ( ! empty( $opt['isDefault'] ) ) {
				$default_claimed = true;
			}
			$rows    .= $this->render_option( $opt, $name, $required );
			$required = false;
		}

		return sprintf( '<div class="%1$s">%2$s</div>', esc_attr( $group_classes ), $rows ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
