<?php
namespace MetForm_Pro\Core\FormBuilder\Blocks\TextEditor;

use MetForm\Core\FormBuilder\Block_Base;
use MetForm\Core\FormBuilder\Rendering\Render_Context;
use MetForm\Core\FormBuilder\Rendering\Field_Renderer;
use MetForm\Core\FormBuilder\Shared\Input_Controls;

defined( 'ABSPATH' ) || exit;

/**
 * Text Editor block for the MetForm Form Builder.
 *
 * Provides rich-text editing powered by Quill with full legacy parity
 * to MetForm Pro's MetForm_Text_Editor (mf-text-editor) Elementor widget.
 * Features server-rendered visual shell for zero-delay frontend rendering,
 * real-time HTML synchronization, and client/server validation integration.
 *
 * @package MetForm_Pro\Core\FormBuilder\Blocks\TextEditor
 */
final class TextEditor extends Block_Base {

	public function get_name(): string {
		return 'text-editor';
	}

	public function get_title(): string {
		return __( 'Text Editor', 'metform-pro' );
	}

	public function get_icon(): string {
		return 'FileEdit';
	}

	public function get_category(): string {
		return 'Advanced';
	}

	public function get_capabilities(): array {
		return array(
			'acceptsChildren' => false,
			'isField'         => true,
		);
	}

	public function get_frontend_assets(): array {
		return array( 'metform-pro-form-builder-frontend' );
	}

	public function get_default_settings(): array {
		return array(
			'showLabel'       => true,
			'label'           => __( 'Text Editor', 'metform-pro' ),
			'labelPosition'   => 'top',
			'name'            => 'mf-text-editor',
			'placeholder'     => '',
			'helpText'        => '',
			'defaultValue'    => '',
			'editorSize'      => '200px',
			'required'        => false,
			'requiredMessage' => '',
			'__className'     => '',
			'styles'          => array(),
		);
	}

	public function get_property_schema(): array {
		return array(
			'showLabel'       => array( 'type' => 'boolean' ),
			'label'           => array( 'type' => 'string' ),
			'labelPosition'   => array(
				'type'       => 'string',
				'enum'       => array( 'top', 'left' ),
				'responsive' => true,
			),
			'name'            => array( 'type' => 'field_name' ),
			'placeholder'     => array( 'type' => 'string' ),
			'helpText'        => array( 'type' => 'string' ),
			'defaultValue'    => array( 'type' => 'string' ),
			'editorSize'      => array(
				'type' => 'string',
				'enum' => array( '100px', '200px', '500px' ),
			),
			'required'        => array( 'type' => 'boolean' ),
			'requiredMessage' => array( 'type' => 'string' ),
			'__className'     => array( 'type' => 'css_class' ),
		);
	}

	private static function typography_selector( string $el ): string {
		return "{{WRAPPER}} {$el} { font-family: {{FONT_FAMILY}}; font-size: {{FONT_SIZE}}; font-weight: {{FONT_WEIGHT}}; font-style: {{FONT_STYLE}}; text-transform: {{TEXT_TRANSFORM}}; text-decoration: {{TEXT_DECORATION}}; line-height: {{LINE_HEIGHT}}; letter-spacing: {{LETTER_SPACING}}; word-spacing: {{WORD_SPACING}}; }";
	}

	public function register_controls(): array {
		return array(
			'content' => array(
				array(
					'type'        => 'section',
					'key'         => 'content',
					'label'       => __( 'Content', 'metform-pro' ),
					'defaultOpen' => true,
				),
				array(
					'type'    => 'toggle',
					'key'     => 'showLabel',
					'label'   => __( 'Show Label', 'metform-pro' ),
					'default' => true,
				),
				array(
					'type'      => 'text',
					'key'       => 'label',
					'label'     => __( 'Label', 'metform-pro' ),
					'default'   => __( 'Text Editor', 'metform-pro' ),
					'inline'    => true,
					'condition' => array( 'showLabel!' => false ),
				),
				array(
					'type'       => 'select',
					'key'        => 'labelPosition',
					'label'      => __( 'Label Position', 'metform-pro' ),
					'default'    => 'top',
					'inline'     => true,
					'options'    => array(
						array(
							'label' => __( 'Top', 'metform-pro' ),
							'value' => 'top',
						),
						array(
							'label' => __( 'Left', 'metform-pro' ),
							'value' => 'left',
						),
					),
					'condition'  => array( 'showLabel!' => false ),
					'responsive' => true,
				),
				array(
					'type'   => 'text',
					'key'    => 'name',
					'label'  => __( 'Name', 'metform-pro' ),
					'inline' => true,
					'help'   => __( 'Name is must required. Enter name without space or any special character. use only underscore/ hyphen (_/-) for multiple word. Name must be different.', 'metform-pro' ),
				),
				array(
					'type'   => 'text',
					'key'    => 'placeholder',
					'label'  => __( 'Placeholder', 'metform-pro' ),
					'inline' => true,
				),
				array(
					'type'  => 'text',
					'key'   => 'helpText',
					'label' => __( 'Help Text', 'metform-pro' ),
					'help'  => __( 'Shown below the field to guide users', 'metform-pro' ),
				),
				array(
					'type'  => 'textarea',
					'key'   => 'defaultValue',
					'label' => __( 'Default Value', 'metform-pro' ),
					'help'  => __( 'Pre-filled formatted HTML content when the form first loads', 'metform-pro' ),
				),
				array(
					'type'        => 'section',
					'key'         => 'settings',
					'label'       => __( 'Settings', 'metform-pro' ),
					'defaultOpen' => false,
				),
				array(
					'type'    => 'select',
					'key'     => 'editorSize',
					'label'   => __( 'Editor Size', 'metform-pro' ),
					'default' => '200px',
					'inline'  => true,
					'options' => array(
						array(
							'label' => __( 'Small (100px)', 'metform-pro' ),
							'value' => '100px',
						),
						array(
							'label' => __( 'Medium (200px)', 'metform-pro' ),
							'value' => '200px',
						),
						array(
							'label' => __( 'Large (500px)', 'metform-pro' ),
							'value' => '500px',
						),
					),
				),
				array(
					'type'    => 'toggle',
					'key'     => 'required',
					'label'   => __( 'Required', 'metform-pro' ),
					'default' => false,
				),
				array(
					'type'      => 'text',
					'key'       => 'requiredMessage',
					'label'     => __( 'Required Message', 'metform-pro' ),
					'default'   => '',
					'help'      => __( 'Shown when the editor is left empty.', 'metform-pro' ),
					'condition' => array( 'required' => true ),
				),
			),
			'style'   => array(
				array(
					'type'        => 'section',
					'label'       => __( 'Label', 'metform-pro' ),
					'defaultOpen' => true,
					'condition'   => array( 'showLabel!' => false ),
				),
				array(
					'type'      => 'color',
					'key'       => 'styles.labelColor',
					'label'     => __( 'Label Color', 'metform-pro' ),
					'default'   => '#374151',
					'selector'  => '{{WRAPPER}} .mfb-label { color: {{VALUE}}; }',
					'condition' => array( 'showLabel!' => false ),
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.labelTypography',
					'label'          => __( 'Label Typography', 'metform-pro' ),
					'selector'       => self::typography_selector( '.mfb-label' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
					'condition'      => array( 'showLabel!' => false ),
				),
				array(
					'type'  => 'section',
					'label' => __( 'Help Text & Error', 'metform-pro' ),
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.helpTextColor',
					'label'    => __( 'Help Text Color', 'metform-pro' ),
					'default'  => '#6b7280',
					'selector' => '{{WRAPPER}} .mfb-field__help { color: {{VALUE}}; }',
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.errorColor',
					'label'    => __( 'Error Color', 'metform-pro' ),
					'default'  => '#ef4444',
					'selector' => '{{WRAPPER}} .mfb-field__error { color: {{VALUE}}; }',
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.helpTextTypography',
					'label'          => __( 'Help Text Typography', 'metform-pro' ),
					'selector'       => self::typography_selector( '.mfb-field__help' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.errorTypography',
					'label'          => __( 'Error Typography', 'metform-pro' ),
					'selector'       => self::typography_selector( '.mfb-field__error' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
				),
				array(
					'type'  => 'section',
					'label' => __( 'Editor Container', 'metform-pro' ),
				),
				array(
					'type'       => 'range',
					'key'        => 'styles.minHeight',
					'label'      => __( 'Min Height', 'metform-pro' ),
					'default'    => '200px',
					'units'      => array( 'px' ),
					'min'        => 60,
					'max'        => 800,
					'step'       => 10,
					'selector'   => '{{WRAPPER}} .ql-container, {{WRAPPER}} .ql-editor { min-height: {{VALUE}}; }',
					'responsive' => true,
				),
				array(
					'type'       => 'dimensions',
					'key'        => 'styles.editorPadding',
					'label'      => __( 'Editor Padding', 'metform-pro' ),
					'default'    => array(
						'top'    => '12px',
						'right'  => '15px',
						'bottom' => '12px',
						'left'   => '15px',
					),
					'selector'   => '{{WRAPPER}} .ql-editor { padding: {{TOP}} {{RIGHT}} {{BOTTOM}} {{LEFT}}; }',
					'responsive' => true,
				),
				array(
					'type'       => 'dimensions',
					'key'        => 'styles.wrapperMargin',
					'label'      => __( 'Wrapper Margin', 'metform-pro' ),
					'default'    => array(
						'top'    => '0px',
						'right'  => '0px',
						'bottom' => '0px',
						'left'   => '0px',
					),
					'selector'   => '{{WRAPPER}} .mfb-text-editor__wrap { margin: {{TOP}} {{RIGHT}} {{BOTTOM}} {{LEFT}}; }',
					'responsive' => true,
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.editorBg',
					'label'    => __( 'Editor Background', 'metform-pro' ),
					'default'  => '#ffffff',
					'selector' => '{{WRAPPER}} .ql-container { background-color: {{VALUE}}; }',
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.toolbarBg',
					'label'    => __( 'Toolbar Background', 'metform-pro' ),
					'default'  => '#f9fafb',
					'selector' => '{{WRAPPER}} .ql-toolbar { background-color: {{VALUE}}; }',
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.typography',
					'label'          => __( 'Content Typography', 'metform-pro' ),
					'selector'       => self::typography_selector( '.ql-editor' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
				),
				array(
					'type'           => 'border',
					'key'            => 'styles.border',
					'label'          => __( 'Border', 'metform-pro' ),
					'default'        => array(
						'borderType' => 'solid',
						'width'      => array(
							'top'    => '1px',
							'right'  => '1px',
							'bottom' => '1px',
							'left'   => '1px',
						),
						'color'      => '#d1d5db',
						'radius'     => array(),
					),
					'selector'       => '{{WRAPPER}} .mfb-text-editor__wrap { {{VALUE}} }',
					'responsive'     => true,
					'responsiveKeys' => array( 'width', 'radius' ),
				),
			),
		);
	}

	public function build_dynamic_css( array $settings, string $style_class ): string {

		$parent_css = parent::build_dynamic_css( $settings, $style_class );
		$base_css   = "
.{$style_class} .mfb-text-editor__wrap { display: block; width: 100%; box-sizing: border-box; overflow: hidden; }
.{$style_class} .ql-toolbar.ql-snow { display: flex !important; flex-wrap: wrap !important; align-items: center !important; gap: 4px 6px !important; padding: 6px 10px !important; background-color: #f9fafb !important; border: none !important; border-bottom: 1px solid #d1d5db !important; box-sizing: border-box !important; }
.{$style_class} .ql-toolbar.ql-snow .ql-formats { display: inline-flex !important; align-items: center !important; gap: 2px !important; margin: 0 !important; padding-right: 6px !important; border-right: 1px solid #e5e7eb !important; }
.{$style_class} .ql-toolbar.ql-snow .ql-formats:last-child { border-right: none !important; padding-right: 0 !important; }
.{$style_class} .ql-toolbar.ql-snow button { display: inline-flex !important; align-items: center !important; justify-content: center !important; width: 28px !important; height: 26px !important; padding: 3px !important; margin: 0 !important; border: 1px solid transparent !important; border-radius: 4px !important; background: transparent !important; cursor: pointer !important; box-sizing: border-box !important; }
.{$style_class} .ql-toolbar.ql-snow button:hover { background-color: #e5e7eb !important; border-color: #d1d5db !important; }
.{$style_class} .ql-toolbar.ql-snow button.ql-active { background-color: #e0e7ff !important; border-color: #c7d2fe !important; }
.{$style_class} .ql-toolbar.ql-snow button svg { display: block !important; width: 18px !important; height: 18px !important; }
.{$style_class} .ql-toolbar.ql-snow .ql-stroke { stroke: #374151 !important; stroke-linecap: round !important; stroke-linejoin: round !important; stroke-width: 2 !important; fill: none !important; }
.{$style_class} .ql-toolbar.ql-snow .ql-stroke.ql-thin { stroke-width: 1 !important; }
.{$style_class} .ql-toolbar.ql-snow .ql-fill { fill: #374151 !important; stroke: none !important; }
.{$style_class} .ql-toolbar.ql-snow .ql-even { fill-rule: evenodd !important; }
.{$style_class} .ql-container.ql-snow { border: none !important; background-color: #ffffff !important; box-sizing: border-box !important; }
.{$style_class} .ql-container { min-height: var(--mfb-te-min-h, 200px); }
.{$style_class} .ql-editor { box-sizing: border-box !important; padding: 12px 15px !important; font-size: 14px !important; line-height: 1.6 !important; min-height: inherit !important; outline: none !important; }
";
		return $base_css . $parent_css;
	}
	public function render_markup( array $settings, Render_Context $context ): string {
		$id   = $context->get_element_id();
		$name = (string) ( $settings['name'] ?? '' );
		if ( '' === trim( $name ) ) {
			$name = 'mf-text-editor';
		}
		$placeholder      = (string) ( $settings['placeholder'] ?? '' );
		$default_value    = (string) ( $settings['defaultValue'] ?? '' );
		$editor_size      = in_array( $settings['editorSize'] ?? '200px', array( '100px', '200px', '500px' ), true ) ? $settings['editorSize'] : '200px';
		$validation_attrs = Input_Controls::validation_attributes( $settings );
		$toolbar_id       = $id . '-toolbar';
		$editor_id        = $id . '-editor';
		$input_id         = $id . '-input';

		ob_start();
		?>
		<div class="mfb-text-editor__wrap" data-mf-text-editor data-min-height="<?php echo esc_attr( $editor_size ); ?>" data-placeholder="<?php echo esc_attr( $placeholder ); ?>" style="--mfb-te-min-h: <?php echo esc_attr( $editor_size ); ?>;">
			<div id="<?php echo esc_attr( $toolbar_id ); ?>" class="ql-toolbar ql-snow" aria-label="<?php esc_attr_e( 'Text Editor Toolbar', 'metform-pro' ); ?>">
				<span class="ql-formats">
					<button type="button" class="ql-header" value="1" title="<?php esc_attr_e( 'Heading 1', 'metform-pro' ); ?>">
						<svg viewBox="0 0 18 18"><path class="ql-fill" d="M10,4V14a1,1,0,0,1-2,0V10H3v4a1,1,0,0,1-2,0V4A1,1,0,0,1,3,4V8H8V4a1,1,0,0,1,2,0Zm6.06787,9.209H14.98975V7.59863a.54085.54085,0,0,0-.605-.60547h-.62744a1.01119,1.01119,0,0,0-.748.29688L11.645,8.56641a.5435.5435,0,0,0-.022.8584l.28613.30762a.53861.53861,0,0,0,.84717.0332l.09912-.08789a1.2137,1.2137,0,0,0,.2417-.35254h.02246s-.01123.30859-.01123.60547V13.209H12.041a.54085.54085,0,0,0-.605.60547v.43945a.54085.54085,0,0,0,.605.60547h4.02686a.54085.54085,0,0,0,.605-.60547v-.43945A.54085.54085,0,0,0,16.06787,13.209Z"/></svg>
					</button>
					<button type="button" class="ql-header" value="2" title="<?php esc_attr_e( 'Heading 2', 'metform-pro' ); ?>">
						<svg viewBox="0 0 18 18"><path class="ql-fill" d="M16.73926,13.209H14.54687V12.793a3.46884,3.46884,0,0,0,1.23242-1.02344,2.23847,2.23847,0,0,0,.47364-1.4082,2.02985,2.02985,0,0,0-.605-1.50733,2.41725,2.41725,0,0,0-1.74853-.59424,2.69769,2.69769,0,0,0-1.89209.68213,2.46387,2.46387,0,0,0-.748,1.8374h1.49609a1.1444,1.1444,0,0,1,.35205-.8584,1.19835,1.19835,0,0,1,.84717-.3081,1.11059,1.11059,0,0,1,.7915.28613,1.03159,1.03159,0,0,1,.30811.78125,1.27218,1.27218,0,0,1-.36328.92432,4.896,4.896,0,0,1-1.34229,1.02344L11.53516,15.145V16h5.2041Zm-6.73926-9.209H8V8H3V4H1V14H3V10H8v4h2Z"/></svg>
					</button>
				</span>
				<span class="ql-formats">
					<button type="button" class="ql-bold" title="<?php esc_attr_e( 'Bold', 'metform-pro' ); ?>">
						<svg viewBox="0 0 18 18"><path class="ql-stroke" d="M5,4H9.5A2.5,2.5,0,0,1,12,6.5v0A2.5,2.5,0,0,1,9.5,9H5A0,0,0,0,1,5,9V4A0,0,0,0,1,5,4Z"></path><path class="ql-stroke" d="M5,9h5.5A2.5,2.5,0,0,1,13,11.5v0A2.5,2.5,0,0,1,10.5,14H5a0,0,0,0,1,0,0V9A0,0,0,0,1,5,9Z"></path></svg>
					</button>
					<button type="button" class="ql-italic" title="<?php esc_attr_e( 'Italic', 'metform-pro' ); ?>">
						<svg viewBox="0 0 18 18"><line class="ql-stroke" x1="7" x2="13" y1="4" y2="4"></line><line class="ql-stroke" x1="5" x2="11" y1="14" y2="14"></line><line class="ql-stroke" x1="8" x2="10" y1="14" y2="4"></line></svg>
					</button>
					<button type="button" class="ql-underline" title="<?php esc_attr_e( 'Underline', 'metform-pro' ); ?>">
						<svg viewBox="0 0 18 18"><path class="ql-stroke" d="M5,3V9a4,4,0,0,0,8,0V3"></path><line class="ql-stroke" x1="3" x2="15" y1="15" y2="15"></line></svg>
					</button>
					<button type="button" class="ql-strike" title="<?php esc_attr_e( 'Strikethrough', 'metform-pro' ); ?>">
						<svg viewBox="0 0 18 18"><line class="ql-stroke ql-thin" x1="15.5" x2="2.5" y1="8.5" y2="9.5"></line><path class="ql-fill" d="M9.007,12.042l-.094-.006A4.542,4.542,0,0,1,6.03,11.065a.479.479,0,0,1-.077-.665.485.485,0,0,1,.672-.073A3.6,3.6,0,0,0,8.8,11.082h.1a2.128,2.128,0,0,0,1.344-.374,1.066,1.066,0,0,0,.391-.875,1.084,1.084,0,0,0-.4-.887,2.83,2.83,0,0,0-1.428-.466l-1.042-.143a4.017,4.017,0,0,1-2.18-.941A2.164,2.164,0,0,1,4.8,5.719a2.148,2.148,0,0,1,.791-1.722,3.585,3.585,0,0,1,2.379-.747h.1a4.238,4.238,0,0,1,2.624.872.482.482,0,0,1,.069.676.478.478,0,0,1-.676.065,3.315,3.315,0,0,0-2.13-.7H7.864a2.531,2.531,0,0,0-1.637.5,1.218,1.218,0,0,0-.482.989,1.139,1.139,0,0,0,.432.936,2.836,2.836,0,0,0,1.488.476l1.042.144a3.9,3.9,0,0,1,2.18.966,2.176,2.176,0,0,1,.792,1.725,2.136,2.136,0,0,1-.822,1.724A3.682,3.682,0,0,1,9.007,12.042Z"></path></svg>
					</button>
				</span>
				<span class="ql-formats">
					<button type="button" class="ql-blockquote" title="<?php esc_attr_e( 'Blockquote', 'metform-pro' ); ?>">
						<svg viewBox="0 0 18 18"><rect class="ql-fill ql-stroke" height="3" width="3" x="4" y="5"></rect><rect class="ql-fill ql-stroke" height="3" width="3" x="11" y="5"></rect><path class="ql-even ql-fill ql-stroke" d="M7,8c0,4.031-3,5-3,5"></path><path class="ql-even ql-fill ql-stroke" d="M14,8c0,4.031-3,5-3,5"></path></svg>
					</button>
					<button type="button" class="ql-code-block" title="<?php esc_attr_e( 'Code Block', 'metform-pro' ); ?>">
						<svg viewBox="0 0 18 18"><polyline class="ql-even ql-stroke" points="5 7 2 10 5 13"></polyline><polyline class="ql-even ql-stroke" points="13 7 16 10 13 13"></polyline><line class="ql-stroke" x1="10" x2="8" y1="5" y2="15"></line></svg>
					</button>
				</span>
				<span class="ql-formats">
					<button type="button" class="ql-list" value="ordered" title="<?php esc_attr_e( 'Numbered List', 'metform-pro' ); ?>">
						<svg viewBox="0 0 18 18"><line class="ql-stroke" x1="7" x2="15" y1="4" y2="4"></line><line class="ql-stroke" x1="7" x2="15" y1="9" y2="9"></line><line class="ql-stroke" x1="7" x2="15" y1="14" y2="14"></line><line class="ql-stroke ql-thin" x1="2.5" x2="4.5" y1="12" y2="12"></line><path class="ql-fill" d="M2.927,3.619a.669.669,0,0,1,.848-.593A1.56,1.56,0,0,0,4.5,3.2V2.8H2.5V2H5V5.5H4.2V4.185a2.535,2.535,0,0,1-1.047-.367A.428.428,0,0,1,2.927,3.619ZM4.4,7.8H2V7.1a1.989,1.989,0,0,1,1.066-1.78,1.4,1.4,0,0,0,.7-.87.414.414,0,0,0-.407-.51.488.488,0,0,0-.46.33.376.376,0,0,1-.468.236l-.372-.1a.381.381,0,0,1-.266-.462A1.218,1.218,0,0,1,3.013,3.1a1.29,1.29,0,0,1,1.385.275,1.2,1.2,0,0,1,.286,1.246,2.247,2.247,0,0,1-.856,1.229H4.4ZM2,14V13.3a1.458,1.458,0,0,1,.77-1.3,1.1,1.1,0,0,0,.547-.79.378.378,0,0,0-.376-.445.419.419,0,0,0-.411.314.368.368,0,0,1-.453.242l-.373-.1a.376.376,0,0,1-.252-.463A1.177,1.177,0,0,1,2.53,9.88a1.272,1.272,0,0,1,1.32.25,1.139,1.139,0,0,1,.287,1.185,1.968,1.968,0,0,1-.737,1.035V14Z"></path></svg>
					</button>
					<button type="button" class="ql-list" value="bullet" title="<?php esc_attr_e( 'Bullet List', 'metform-pro' ); ?>">
						<svg viewBox="0 0 18 18"><line class="ql-stroke" x1="6" x2="15" y1="4" y2="4"></line><line class="ql-stroke" x1="6" x2="15" y1="9" y2="9"></line><line class="ql-stroke" x1="6" x2="15" y1="14" y2="14"></line><line class="ql-stroke" x1="3" x2="3" y1="4" y2="4"></line><line class="ql-stroke" x1="3" x2="3" y1="9" y2="9"></line><line class="ql-stroke" x1="3" x2="3" y1="14" y2="14"></line></svg>
					</button>
				</span>
				<span class="ql-formats">
					<button type="button" class="ql-direction" value="rtl" title="<?php esc_attr_e( 'Text Direction', 'metform-pro' ); ?>">
						<svg viewBox="0 0 18 18"><polygon class="ql-fill" points="3 11 5 9 3 7 3 11"></polygon><line class="ql-stroke" x1="15" x2="11" y1="4" y2="4"></line><polyline class="ql-stroke" points="11 4 8 4 8 14"></polyline><line class="ql-stroke" x1="13" x2="13" y1="4" y2="14"></line><line class="ql-stroke" x1="11" x2="11" y1="4" y2="14"></line></svg>
					</button>
				</span>
				<span class="ql-formats">
					<button type="button" class="ql-align" value="" title="<?php esc_attr_e( 'Align Left', 'metform-pro' ); ?>">
						<svg viewBox="0 0 18 18"><line class="ql-stroke" x1="3" x2="15" y1="9" y2="9"></line><line class="ql-stroke" x1="3" x2="13" y1="14" y2="14"></line><line class="ql-stroke" x1="3" x2="9" y1="4" y2="4"></line></svg>
					</button>
					<button type="button" class="ql-align" value="center" title="<?php esc_attr_e( 'Align Center', 'metform-pro' ); ?>">
						<svg viewBox="0 0 18 18"><line class="ql-stroke" x1="15" x2="3" y1="9" y2="9"></line><line class="ql-stroke" x1="14" x2="4" y1="14" y2="14"></line><line class="ql-stroke" x1="12" x2="6" y1="4" y2="4"></line></svg>
					</button>
					<button type="button" class="ql-align" value="right" title="<?php esc_attr_e( 'Align Right', 'metform-pro' ); ?>">
						<svg viewBox="0 0 18 18"><line class="ql-stroke" x1="15" x2="3" y1="9" y2="9"></line><line class="ql-stroke" x1="15" x2="5" y1="14" y2="14"></line><line class="ql-stroke" x1="15" x2="9" y1="4" y2="4"></line></svg>
					</button>
					<button type="button" class="ql-align" value="justify" title="<?php esc_attr_e( 'Justify', 'metform-pro' ); ?>">
						<svg viewBox="0 0 18 18"><line class="ql-stroke" x1="15" x2="3" y1="4" y2="4"></line><line class="ql-stroke" x1="15" x2="3" y1="9" y2="9"></line><line class="ql-stroke" x1="15" x2="3" y1="14" y2="14"></line></svg>
					</button>
				</span>
				<span class="ql-formats">
					<button type="button" class="ql-clean" title="<?php esc_attr_e( 'Clear Formatting', 'metform-pro' ); ?>">
						<svg viewBox="0 0 18 18"><line class="ql-stroke" x1="5" x2="13" y1="3" y2="3"></line><line class="ql-stroke" x1="6" x2="12" y1="3" y2="15"></line><line class="ql-stroke" x1="8" x2="10" y1="15" y2="15"></line><polyline class="ql-stroke" points="12 12 14 14 16 12"></polyline></svg>
					</button>
				</span>
			</div>

			<?php // Editor Size is only the default height (the --mfb-te-min-h var above); the responsive Min Height control overrides it per breakpoint. ?>
			<div class="ql-container ql-snow">
				<div id="<?php echo esc_attr( $editor_id ); ?>" class="ql-editor" contenteditable="true" data-placeholder="<?php echo esc_attr( $placeholder ); ?>">
					<?php echo wp_kses_post( $default_value ); ?>
				</div>
			</div>

			<input
				type="hidden"
				id="<?php echo esc_attr( $input_id ); ?>"
				name="<?php echo esc_attr( $name ); ?>"
				class="mfb-text-editor__input"
				data-mf-text-editor-input
				value="<?php echo esc_attr( $default_value ); ?>"
				<?php echo $validation_attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			/>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	public function get_wrap_options( array $settings, Render_Context $context ): array {
		// Keep the parent's `style_class` so the wrapper carries the element
		// class every generated `{{WRAPPER}}` rule (Style + Advanced) targets.
		$opts              = parent::get_wrap_options( $settings, $context );
		$opts['label_for'] = $context->get_element_id() . '-input';

		return $opts;
	}
}
