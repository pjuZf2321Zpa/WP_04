<?php
namespace MetForm_Pro\Core\FormBuilder\Blocks\Paymentmethod;

use MetForm\Core\FormBuilder\Block_Base;
use MetForm\Core\FormBuilder\Dynamic_Css\Responsive_Value;
use MetForm\Core\FormBuilder\Rendering\Render_Context;

defined( 'ABSPATH' ) || exit;

final class Paymentmethod extends Block_Base {
	private const AVAILABLE_METHODS = array( 'paypal', 'stripe' );
	private const DISPLAY_OPTIONS   = array( 'inline-block', 'block' );

	public function get_name(): string {
		return 'paymentmethod';
	}

	public function get_title(): string {
		return __( 'Payment Method', 'metform-pro' );
	}

	public function get_icon(): string {
		return 'CreditCard';
	}

	public function get_category(): string {
		return 'Advanced';
	}

	public function get_capabilities(): array {
		return array(
			'acceptsChildren' => false,
			'isField'         => true,
		);
	}

	public function get_frontend_assets(): array {
		return array( 'metform-pro-form-builder-frontend', 'stripe-checkout' );
	}

	public function get_default_settings(): array {
		return array(
			'label'                => __( 'Payment Method', 'metform-pro' ),
			'labelPosition'        => 'top',
			'name'                 => 'mf-payment-method',
			'helpText'             => '',
			'required'             => false,
			'showLabel'            => true,
			'requiredMessage'      => '',
			'displayOption'        => 'inline-block',
			'paymentMethods'       => array( 'paypal', 'stripe' ),
			'defaultPaymentMethod' => 'paypal',
			'paymentFieldName'     => '',
			'paymentFieldAmount'   => '',
			'styles'               => array(),
		);
	}

	public function get_property_schema(): array {
		return array(
			'label'                => array( 'type' => 'string' ),
			'labelPosition'        => array(
				'type'       => 'string',
				'enum'       => array( 'top', 'left' ),
				'responsive' => true,
			),
			'name'                 => array( 'type' => 'field_name' ),
			'helpText'             => array( 'type' => 'string' ),
			'required'             => array( 'type' => 'boolean' ),
			'showLabel'            => array( 'type' => 'boolean' ),
			'requiredMessage'      => array( 'type' => 'string' ),
			'displayOption'        => array(
				'type'       => 'string',
				'enum'       => self::DISPLAY_OPTIONS,
				'responsive' => true,
			),
			'paymentMethods'       => array( 'type' => 'array' ),
			'defaultPaymentMethod' => array(
				'type' => 'string',
				'enum' => self::AVAILABLE_METHODS,
			),
			'paymentFieldName'     => array( 'type' => 'string' ),
			'paymentFieldAmount'   => array( 'type' => 'string' ),
		);
	}

	private function typography_selector( string $el ): string {
		return "{{WRAPPER}} {$el} { font-family: {{FONT_FAMILY}}; font-size: {{FONT_SIZE}}; font-weight: {{FONT_WEIGHT}}; font-style: {{FONT_STYLE}}; text-transform: {{TEXT_TRANSFORM}}; text-decoration: {{TEXT_DECORATION}}; line-height: {{LINE_HEIGHT}}; letter-spacing: {{LETTER_SPACING}}; word-spacing: {{WORD_SPACING}}; }";
	}

	public function register_controls(): array {
		return array(
			'content' => array(
				array(
					'type'        => 'section',
					'key'         => 'content',
					'label'       => __( 'Content', 'metform-pro' ),
					'defaultOpen' => true,
				),
				array(
					'type'    => 'toggle',
					'key'     => 'showLabel',
					'label'   => __( 'Show Label', 'metform-pro' ),
					'default' => true,
				),
				array(
					'type'      => 'text',
					'key'       => 'label',
					'label'     => __( 'Label', 'metform-pro' ),
					'default'   => __( 'Payment Method', 'metform-pro' ),
					'condition' => array( 'showLabel!' => false ),
				),
				array(
					'type'       => 'select',
					'key'        => 'labelPosition',
					'label'      => __( 'Label Position', 'metform-pro' ),
					'default'    => 'top',
					'options'    => array(
						array(
							'label' => __( 'Top', 'metform-pro' ),
							'value' => 'top',
						),
						array(
							'label' => __( 'Left', 'metform-pro' ),
							'value' => 'left',
						),
					),
					'condition'  => array( 'showLabel!' => false ),
					'responsive' => true,
				),
				array(
					'type'    => 'text',
					'key'     => 'name',
					'label'   => __( 'Name', 'metform-pro' ),
					'default' => 'mf-payment-method',
					'help'    => __( 'Name is required. Enter name without spaces or special characters. Use only underscore/hyphen (_/-).', 'metform-pro' ),
				),
				array(
					'type'  => 'text',
					'key'   => 'helpText',
					'label' => __( 'Help Text', 'metform-pro' ),
					'help'  => __( 'Shown below the field to guide users', 'metform-pro' ),
				),
				array(
					'type'       => 'select',
					'key'        => 'displayOption',
					'label'      => __( 'Option Display', 'metform-pro' ),
					'default'    => 'inline-block',
					'options'    => array(
						array(
							'label' => __( 'Horizontal', 'metform-pro' ),
							'value' => 'inline-block',
						),
						array(
							'label' => __( 'Vertical', 'metform-pro' ),
							'value' => 'block',
						),
					),
					'help'       => __( 'Payment method options display orientation.', 'metform-pro' ),
					'responsive' => true,
				),
				array(
					'type'    => 'select2',
					'key'     => 'paymentMethods',
					'label'   => __( 'Payment Methods', 'metform-pro' ),
					'default' => array( 'paypal', 'stripe' ),
					'options' => array(
						array(
							'label' => __( 'PayPal', 'metform-pro' ),
							'value' => 'paypal',
						),
						array(
							'label' => __( 'Stripe', 'metform-pro' ),
							'value' => 'stripe',
						),
					),
					'help'    => __( 'Select supported payment gateways for this form.', 'metform-pro' ),
				),
				array(
					'type'    => 'select',
					'key'     => 'defaultPaymentMethod',
					'label'   => __( 'Default Payment Method', 'metform-pro' ),
					'default' => 'paypal',
					'options' => array(
						array(
							'label' => __( 'PayPal', 'metform-pro' ),
							'value' => 'paypal',
						),
						array(
							'label' => __( 'Stripe', 'metform-pro' ),
							'value' => 'stripe',
						),
					),
					'help'    => __( 'Pre-selected payment method on load.', 'metform-pro' ),
				),

				array(
					'type'        => 'section',
					'key'         => 'integration',
					'label'       => __( 'Integrate Amount Field', 'metform-pro' ),
					'defaultOpen' => true,
				),
				array(
					'type'        => 'text',
					'key'         => 'paymentFieldName',
					'label'       => __( 'Field Name', 'metform-pro' ),
					'placeholder' => 'total-price',
					'help'        => __( 'Set the amount field name (e.g. calculation, number, or select field name) for payment calculation.', 'metform-pro' ),
				),
				array(
					'type'        => 'text',
					'key'         => 'paymentFieldAmount',
					'label'       => __( 'Fixed Amount (Optional)', 'metform-pro' ),
					'placeholder' => '10.00',
					'help'        => __( 'Optional fixed amount if not using a dynamic field.', 'metform-pro' ),
				),

				array(
					'type'        => 'section',
					'key'         => 'settings',
					'label'       => __( 'Settings', 'metform-pro' ),
					'defaultOpen' => false,
				),
				array(
					'type'    => 'toggle',
					'key'     => 'required',
					'label'   => __( 'Required', 'metform-pro' ),
					'default' => false,
				),
				array(
					'type'      => 'text',
					'key'       => 'requiredMessage',
					'label'     => __( 'Required Message', 'metform-pro' ),
					'help'      => __( 'Shown when no payment method is selected.', 'metform-pro' ),
					'condition' => array( 'required' => true ),
				),
			),
			'style'   => array(
				array(
					'type'        => 'section',
					'label'       => __( 'Label', 'metform-pro' ),
					'defaultOpen' => true,
					'condition'   => array( 'showLabel!' => false ),
				),
				array(
					'type'      => 'color',
					'key'       => 'styles.labelColor',
					'label'     => __( 'Label Color', 'metform-pro' ),
					'default'   => '#374151',
					'selector'  => '{{WRAPPER}} .mfb-label { color: {{VALUE}}; }',
					'condition' => array( 'showLabel!' => false ),
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.labelTypography',
					'label'          => __( 'Label Typography', 'metform-pro' ),
					'selector'       => $this->typography_selector( '.mfb-label' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
					'condition'      => array( 'showLabel!' => false ),
				),
				array(
					'type'  => 'section',
					'label' => __( 'Help Text & Error', 'metform-pro' ),
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.helpTextColor',
					'label'    => __( 'Help Text Color', 'metform-pro' ),
					'default'  => '#6b7280',
					'selector' => '{{WRAPPER}} .mfb-field__help { color: {{VALUE}}; }',
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.errorColor',
					'label'    => __( 'Error Color', 'metform-pro' ),
					'default'  => '#ef4444',
					'selector' => '{{WRAPPER}} .mfb-field__error { color: {{VALUE}}; }',
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.helpTextTypography',
					'label'          => __( 'Help Text Typography', 'metform-pro' ),
					'selector'       => $this->typography_selector( '.mfb-field__help' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.errorTypography',
					'label'          => __( 'Error Typography', 'metform-pro' ),
					'selector'       => $this->typography_selector( '.mfb-field__error' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
				),

				array(
					'type'  => 'section',
					'label' => __( 'Card Options', 'metform-pro' ),
				),
				array(
					'type'       => 'range',
					'key'        => 'styles.cardWidth',
					'label'      => __( 'Card Width', 'metform-pro' ),
					'default'    => '200px',
					'units'      => array( 'px' ),
					'min'        => 80,
					'max'        => 400,
					'step'       => 5,
					'selector'   => '{{WRAPPER}} .mfb-payment-method__card { width: {{VALUE}}; }',
					'responsive' => true,
				),
				array(
					'type'       => 'range',
					'key'        => 'styles.gap',
					'label'      => __( 'Gap', 'metform-pro' ),
					'default'    => '0.75rem',
					'units'      => array( 'px', 'rem' ),
					'selector'   => '{{WRAPPER}} .mfb-payment-method__grid { gap: {{VALUE}}; }',
					'responsive' => true,
				),
				array(
					'type' => 'tabs',
					'tab'  => array( 'normal', 'selected' ),
				),
				array(
					'type'     => 'background',
					'key'      => 'styles.cardBg',
					'label'    => __( 'Background', 'metform-pro' ),
					'tab'      => 'normal',
					'default'  => array(
						'type'  => 'classic',
						'color' => '#ffffff',
					),
					'selector' => '{{WRAPPER}} .mfb-payment-method__card { {{VALUE}} }',
				),
				array(
					'type'     => 'background',
					'key'      => 'styles.cardSelBg',
					'label'    => __( 'Background', 'metform-pro' ),
					'tab'      => 'selected',
					'default'  => array(
						'type'  => 'classic',
						'color' => '#eff6ff',
					),
					'selector' => '{{WRAPPER}} .mfb-payment-method__card:has(.mfb-payment-method__input:checked) { {{VALUE}} }',
				),
				// Border color no longer varies by state (selection is already
				// shown via the Background tabs above + the checkmark badge) —
				// this single control is the only place border color is set,
				// so its own Color sub-field stays enabled (default showColor).
				array(
					'type'           => 'border',
					'key'            => 'styles.cardBorder',
					'label'          => __( 'Border', 'metform-pro' ),
					'default'        => array(
						'borderType' => 'solid',
						'width'      => array(
							'top'    => '2px',
							'right'  => '2px',
							'bottom' => '2px',
							'left'   => '2px',
						),
						'color'      => '#e5e7eb',
					),
					'selector'       => '{{WRAPPER}} .mfb-payment-method__card { {{VALUE}} }',
					'responsive'     => true,
					'responsiveKeys' => array( 'width', 'radius' ),
				),
				array(
					'type'     => 'boxShadow',
					'key'      => 'styles.cardShadow',
					'label'    => __( 'Box Shadow', 'metform-pro' ),
					'selector' => '{{WRAPPER}} .mfb-payment-method__card { box-shadow: {{VALUE}}; }',
				),
			),
		);
	}

	private function render_option( string $method, string $name, bool $is_checked, bool $is_required, string $image_url ): string {
		$method_label = 'paypal' === $method ? 'PayPal' : ( 'stripe' === $method ? 'Stripe' : ucfirst( $method ) );
		ob_start();
		?>
		<div class="mfb-payment-method__option mfb-payment-method__option--<?php echo esc_attr( $method ); ?>">
			<label class="mfb-payment-method__card">
				<input
					type="radio"
					class="mfb-payment-method__input mf-input mf-payment-method-input"
					name="<?php echo esc_attr( $name ); ?>"
					value="<?php echo esc_attr( $method ); ?>"
					data-payment-method="<?php echo esc_attr( $method ); ?>"
					<?php echo $is_checked ? 'checked' : ''; ?>
					<?php echo $is_required ? 'required' : ''; ?>
				/>
				<div class="mfb-payment-method__img-wrap">
					<img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $method_label ); ?>" class="mfb-payment-method__img" />
					<div class="mfb-payment-method__check" aria-hidden="true">
						<svg class="mfb-payment-method__check-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
							<polyline points="20 6 9 17 4 12"></polyline>
						</svg>
					</div>
				</div>
			</label>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Per-breakpoint values of displayOption (applied through a markup class
	 * on desktop). See Block_Base::get_responsive_markup_rules().
	 *
	 * @since 4.4.1
	 */
	protected function get_responsive_markup_rules(): array {
		return array_merge(
			parent::get_responsive_markup_rules(),
			array(
				'displayOption' => array(
					'inline-block' => '{{WRAPPER}} .mfb-payment-method__grid { flex-direction: row; flex-wrap: wrap; align-items: stretch; }',
					'block'        => '{{WRAPPER}} .mfb-payment-method__grid { flex-direction: column; flex-wrap: nowrap; align-items: flex-start; }',
				),
			)
		);
	}

	public function render_markup( array $settings, Render_Context $context ): string {
		$name = sanitize_text_field( (string) ( $settings['name'] ?? 'mf-payment-method' ) ) ?: 'mf-payment-method';
		// Desktop value; tablet/mobile come from build_responsive_markup_css().
		$display_option = (string) Responsive_Value::resolve( $settings['displayOption'] ?? 'inline-block', 'desktop', 'inline-block' );
		$display_option = in_array( $display_option, self::DISPLAY_OPTIONS, true ) ? $display_option : 'inline-block';

		$raw_methods = $settings['paymentMethods'] ?? self::AVAILABLE_METHODS;
		if ( is_string( $raw_methods ) ) {
			$raw_methods = explode( ',', $raw_methods );
		}
		if ( ! is_array( $raw_methods ) ) {
			$raw_methods = self::AVAILABLE_METHODS;
		}

		$methods = array();
		foreach ( $raw_methods as $m ) {
			$m = sanitize_key( trim( (string) $m ) );
			if ( in_array( $m, self::AVAILABLE_METHODS, true ) && ! in_array( $m, $methods, true ) ) {
				$methods[] = $m;
			}
		}

		if ( empty( $methods ) ) {
			$methods = self::AVAILABLE_METHODS;
		}

		$default_method = (string) ( $settings['defaultPaymentMethod'] ?? 'paypal' );
		if ( ! in_array( $default_method, $methods, true ) ) {
			$default_method = reset( $methods );
		}

		$is_required          = ! empty( $settings['required'] );
		$required_message     = (string) ( $settings['requiredMessage'] ?? '' );
		$payment_field_name   = (string) ( $settings['paymentFieldName'] ?? '' );
		$payment_field_amount = (string) ( $settings['paymentFieldAmount'] ?? '' );

		$plugin_url   = defined( 'METFORM_PRO_URL' ) ? METFORM_PRO_URL : plugin_dir_url( dirname( __DIR__, 4 ) );
		$options_html = '';

		foreach ( $methods as $method ) {
			$method = sanitize_key( $method );
			if ( ! in_array( $method, self::AVAILABLE_METHODS, true ) ) {
				continue;
			}
			$image_url     = $plugin_url . 'build/assets/images/payment-method/' . $method . '.png';
			$is_checked    = ( $method === $default_method );
			$options_html .= $this->render_option( $method, $name, $is_checked, $is_required, $image_url );
		}

		$grid_class    = 'inline-block' === $display_option ? 'mfb-payment-method__grid mfb-layout--horizontal' : 'mfb-payment-method__grid mfb-layout--vertical';
		$required_attr = $is_required ? ' data-mf-required="1"' : '';
		$msg_attr      = ( $is_required && '' !== $required_message ) ? ' data-mf-required-message="' . esc_attr( $required_message ) . '"' : '';

		return sprintf(
			'<div class="mfb-payment-method__wrap %1$s" role="radiogroup" data-mf-payment-name="%2$s" data-mf-default-payment-method="%3$s" data-mf-amount-field="%4$s" data-mf-amount-fixed="%5$s"%6$s%7$s>%8$s</div>',
			esc_attr( $grid_class ),
			esc_attr( $name ),
			esc_attr( $default_method ),
			esc_attr( $payment_field_name ),
			esc_attr( $payment_field_amount ),
			$required_attr, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			$msg_attr, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			$options_html // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		);
	}
}
