<?php
namespace MetForm_Pro\Core\FormBuilder\Blocks\Likedislike;

use MetForm\Core\FormBuilder\Block_Base;
use MetForm\Core\FormBuilder\Rendering\Render_Context;

defined( 'ABSPATH' ) || exit;

final class Likedislike extends Block_Base {
	private const ICON_PATHS = array(
		'like'    => 'M15.9 4.5C15.9 3 14.418 2 13.26 2c-.806 0-.869.612-.993 1.82-.055.53-.121 1.174-.267 1.93-.386 2.002-1.72 4.56-2.996 5.325V17C9 19.25 9.75 20 13 20h3.773c2.176 0 2.703-1.433 2.899-1.964l.013-.036c.114-.306.358-.547.638-.82.31-.306.664-.653.927-1.18.311-.623.27-1.177.233-1.67-.023-.299-.044-.575.017-.83.064-.27.146-.475.225-.671.143-.356.275-.686.275-1.329 0-1.5-.748-2.498-2.315-2.498H15.5S15.9 6 15.9 4.5zM5.5 10A1.5 1.5 0 0 0 4 11.5v7a1.5 1.5 0 0 0 3 0v-7A1.5 1.5 0 0 0 5.5 10z',
		'dislike' => 'M8.1 20.5c0 1.5 1.482 2.5 2.64 2.5.806 0 .869-.613.993-1.82.055-.53.121-1.174.267-1.93.386-2.002 1.72-4.56 2.996-5.325V8C15 5.75 14.25 5 11 5H7.227C5.051 5 4.524 6.432 4.328 6.964A15.85 15.85 0 0 1 4.315 7c-.114.306-.358.546-.638.82-.31.306-.664.653-.927 1.18-.311.623-.27 1.177-.233 1.67.023.299.044.575-.017.83-.064.27-.146.475-.225.671-.143.356-.275.686-.275 1.329 0 1.5.748 2.498 2.315 2.498H8.5S8.1 19 8.1 20.5zM18.5 15a1.5 1.5 0 0 0 1.5-1.5v-7a1.5 1.5 0 0 0-3 0v7a1.5 1.5 0 0 0 1.5 1.5z',
	);

	public function get_name(): string {
		return 'likedislike'; }
	public function get_title(): string {
		return __( 'Like / Dislike', 'metform-pro' ); }
	public function get_icon(): string {
		return 'ThumbsUp'; }
	public function get_category(): string {
		return 'Advanced'; }

	public function get_capabilities(): array {
		return array(
			'acceptsChildren' => false,
			'isField'         => true,
		);
	}

	/**
	 * The compiled frontend/form-builder bundle handle this block needs —
	 * enqueued only when this block is actually present, via this plugin's
	 * own Base::enqueue_block_assets() (mirrors canvas.php's identical
	 * per-block loop in the free plugin, which never sees Pro blocks).
	 */
	public function get_frontend_assets(): array {
		return array( 'metform-pro-form-builder-frontend' );
	}

	public function get_default_settings(): array {
		return array(
			'label'           => __( 'Like / Dislike', 'metform-pro' ),
			'labelPosition'   => 'top',
			'name'            => '',
			'helpText'        => '',
			'required'        => false,
			'requiredMessage' => '',
			'showLabel'       => true,
			'styles'          => array(),
		);
	}

	public function get_property_schema(): array {
		return array(
			'label'           => array( 'type' => 'string' ),
			'labelPosition'   => array(
				'type'       => 'string',
				'enum'       => array( 'top', 'left' ),
				'responsive' => true,
			),
			'name'            => array( 'type' => 'field_name' ),
			'helpText'        => array( 'type' => 'string' ),
			'required'        => array( 'type' => 'boolean' ),
			'requiredMessage' => array( 'type' => 'string' ),
			'showLabel'       => array( 'type' => 'boolean' ),
		);
	}

	private function typography_selector( string $el ): string {
		return "{{WRAPPER}} {$el} { font-family: {{FONT_FAMILY}}; font-size: {{FONT_SIZE}}; font-weight: {{FONT_WEIGHT}}; font-style: {{FONT_STYLE}}; text-transform: {{TEXT_TRANSFORM}}; text-decoration: {{TEXT_DECORATION}}; line-height: {{LINE_HEIGHT}}; letter-spacing: {{LETTER_SPACING}}; word-spacing: {{WORD_SPACING}}; }";
	}

	public function register_controls(): array {
		return array(
			'content' => array(
				array(
					'type'        => 'section',
					'key'         => 'content',
					'label'       => __( 'Content', 'metform-pro' ),
					'defaultOpen' => true,
				),
				array(
					'type'    => 'toggle',
					'key'     => 'showLabel',
					'label'   => __( 'Show Label', 'metform-pro' ),
					'default' => true,
				),
				array(
					'type'      => 'text',
					'key'       => 'label',
					'label'     => __( 'Label', 'metform-pro' ),
					'default'   => __( 'Like / Dislike', 'metform-pro' ),
					'condition' => array( 'showLabel!' => false ),
				),
				array(
					'type'       => 'select',
					'key'        => 'labelPosition',
					'label'      => __( 'Label Position', 'metform-pro' ),
					'default'    => 'top',
					'options'    => array(
						array(
							'label' => __( 'Top', 'metform-pro' ),
							'value' => 'top',
						),
						array(
							'label' => __( 'Left', 'metform-pro' ),
							'value' => 'left',
						),
					),
					'condition'  => array( 'showLabel!' => false ),
					'responsive' => true,
				),
				array(
					'type'  => 'text',
					'key'   => 'name',
					'label' => __( 'Name', 'metform-pro' ),
					'help'  => __( 'Name is must required. Enter name without space or any special character. use only underscore/ hyphen (_/-) for multiple word. Name must be different.', 'metform-pro' ),
				),
				array(
					'type'  => 'text',
					'key'   => 'helpText',
					'label' => __( 'Help Text', 'metform-pro' ),
					'help'  => __( 'Shown below the field to guide users', 'metform-pro' ),
				),

				array(
					'type'        => 'section',
					'key'         => 'settings',
					'label'       => __( 'Settings', 'metform-pro' ),
					'defaultOpen' => false,
				),
				array(
					'type'    => 'toggle',
					'key'     => 'required',
					'label'   => __( 'Required', 'metform-pro' ),
					'default' => false,
				),
				array(
					'type'      => 'text',
					'key'       => 'requiredMessage',
					'label'     => __( 'Required Message', 'metform-pro' ),
					'help'      => __( 'Shown when neither option is selected.', 'metform-pro' ),
					'condition' => array( 'required' => true ),
				),
			),
			'style'   => array(
				array(
					'type'        => 'section',
					'label'       => __( 'Label', 'metform-pro' ),
					'defaultOpen' => true,
					'condition'   => array( 'showLabel!' => false ),
				),
				array(
					'type'      => 'color',
					'key'       => 'styles.labelColor',
					'label'     => __( 'Label Color', 'metform-pro' ),
					'default'   => '#374151',
					'selector'  => '{{WRAPPER}} .mfb-label { color: {{VALUE}}; }',
					'condition' => array( 'showLabel!' => false ),
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.labelTypography',
					'label'          => __( 'Label Typography', 'metform-pro' ),
					'selector'       => $this->typography_selector( '.mfb-label' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
					'condition'      => array( 'showLabel!' => false ),
				),
				array(
					'type'  => 'section',
					'label' => __( 'Help Text & Error', 'metform-pro' ),
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.helpTextColor',
					'label'    => __( 'Help Text Color', 'metform-pro' ),
					'default'  => '#6b7280',
					'selector' => '{{WRAPPER}} .mfb-field__help { color: {{VALUE}}; }',
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.errorColor',
					'label'    => __( 'Error Color', 'metform-pro' ),
					'default'  => '#ef4444',
					'selector' => '{{WRAPPER}} .mfb-field__error { color: {{VALUE}}; }',
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.helpTextTypography',
					'label'          => __( 'Help Text Typography', 'metform-pro' ),
					'selector'       => $this->typography_selector( '.mfb-field__help' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.errorTypography',
					'label'          => __( 'Error Typography', 'metform-pro' ),
					'selector'       => $this->typography_selector( '.mfb-field__error' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
				),

				array(
					'type'  => 'section',
					'label' => __( 'Like Dislike Icons', 'metform-pro' ),
				),
				array(
					'type'       => 'range',
					'key'        => 'styles.iconSize',
					'label'      => __( 'Icon Size', 'metform-pro' ),
					'default'    => '30px',
					'units'      => array( 'px' ),
					'min'        => 12,
					'max'        => 64,
					'step'       => 1,
					'selector'   => '{{WRAPPER}} .mfb-likedislike__icon { width: {{VALUE}}; height: {{VALUE}}; }',
					'responsive' => true,
				),
				array(
					'type'       => 'range',
					'key'        => 'styles.iconGap',
					'label'      => __( 'Icon Gap', 'metform-pro' ),
					'default'    => '0px',
					'units'      => array( 'px' ),
					'min'        => 0,
					'max'        => 40,
					'step'       => 1,
					'selector'   => '{{WRAPPER}} .mfb-likedislike__group { gap: {{VALUE}}; }',
					'responsive' => true,
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.likeColor',
					'label'    => __( 'Like Icon Color', 'metform-pro' ),
					'default'  => '#6b7280',
					'selector' => '{{WRAPPER}} .mfb-likedislike__btn--like .mfb-likedislike__icon { color: {{VALUE}}; }',
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.likeActiveColor',
					'label'    => __( 'Like Active Color', 'metform-pro' ),
					'default'  => '#16a34a',
					'selector' => '{{WRAPPER}} .mfb-likedislike__btn--like .mfb-likedislike__input-native:checked ~ .mfb-likedislike__icon { color: {{VALUE}}; }',
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.dislikeColor',
					'label'    => __( 'Dislike Icon Color', 'metform-pro' ),
					'default'  => '#6b7280',
					'selector' => '{{WRAPPER}} .mfb-likedislike__btn--dislike .mfb-likedislike__icon { color: {{VALUE}}; }',
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.dislikeActiveColor',
					'label'    => __( 'Dislike Active Color', 'metform-pro' ),
					'default'  => '#dc2626',
					'selector' => '{{WRAPPER}} .mfb-likedislike__btn--dislike .mfb-likedislike__input-native:checked ~ .mfb-likedislike__icon { color: {{VALUE}}; }',
				),
			),
		);
	}

	/**
	 * Hand-drawn inline filled SVG — same pattern as Rating::render_icon_svg(),
	 * one of `self::ICON_PATHS` per modifier. `fill-rule="evenodd"` on the
	 * `<path>` is required here (unlike Rating's shapes) for the cuff/hand
	 * cutouts to render correctly instead of solid-filling.
	 */
	private function render_icon_svg( string $modifier ): string {
		return sprintf(
			'<svg class="mfb-likedislike__icon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="%s"/></svg>',
			esc_attr( self::ICON_PATHS[ $modifier ] ?? '' )
		);
	}

	/**
	 * A bare `required` on the first ('like') radio is enough for the
	 * browser to require "at least one checked" across the pair — see
	 * radio.php's identical reasoning.
	 */
	private function render_button( string $name, string $value, string $modifier, string $aria_label, bool $required = false ): string {
		return sprintf(
			'<label class="mfb-likedislike__btn mfb-likedislike__btn--%1$s"><input type="radio" name="%2$s" value="%1$s" class="mfb-likedislike__input-native" aria-label="%4$s" %3$s>%5$s</label>',
			esc_attr( $modifier ),
			esc_attr( $name ),
			$required ? 'required' : '',
			esc_attr( $aria_label ),
			$this->render_icon_svg( $modifier ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		);
	}

	public function render_markup( array $settings, Render_Context $context ): string {
		$name     = (string) ( $settings['name'] ?? '' );
		$required = ! empty( $settings['required'] );
		return '<div class="mfb-likedislike__group" role="radiogroup">'
			. $this->render_button( $name, 'like', 'like', __( 'Like', 'metform-pro' ), $required )
			. $this->render_button( $name, 'dislike', 'dislike', __( 'Dislike', 'metform-pro' ) )
			. '</div>';
	}
}
