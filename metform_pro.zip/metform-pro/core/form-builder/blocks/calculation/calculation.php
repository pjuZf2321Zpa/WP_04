<?php
namespace MetForm_Pro\Core\FormBuilder\Blocks\Calculation;

use RuntimeException;
use MetForm\Core\FormBuilder\Block_Base;
use MetForm\Core\FormBuilder\Rendering\Render_Context;

defined( 'ABSPATH' ) || exit;

/**
 * Moved from metform\core\form-builder\blocks\calculation\calculation.php
 * (namespace MetForm\Core\FormBuilder\Blocks\Calculation) into MetForm Pro,
 * per PRO_BLOCK_SEPARATION_PLAN.md — Calculation is a MetForm Pro-origin
 * widget (metform-pro\widgets\calculation\calculation.php in the old
 * Elementor implementation) and should not ship inside the free plugin.
 *
 * Behavior is unchanged from the free-plugin version: still extends the
 * free plugin's Block_Base/Render_Context/Field_Renderer (a legitimate
 * runtime PHP dependency — MetForm Pro already hard-requires MetForm to be
 * active, exactly like every old Elementor Pro widget already `use`s
 * MetForm\Traits\* from the free plugin). Only the namespace changed, from
 * MetForm\Core\FormBuilder\Blocks\Calculation to
 * MetForm_Pro\Core\FormBuilder\Blocks\Calculation, so metform-pro's own
 * autoloader (which only resolves the MetForm_Pro\ prefix against this
 * plugin's own directory) can find it.
 *
 * See the original class's full doc comment (still accurate) in
 * metform\core\form-builder\blocks\calculation\calculation.php's history —
 * not repeated here to avoid drift between two copies of the same prose;
 * only the behavior-relevant contract is restated below.
 *
 * A read-only field that shows the result of an arithmetic expression over
 * other fields' values, and submits that result as its own named field.
 * PHP render() always shows the true initial-state result (every
 * referenced field defaults to 0); live recalculation as the visitor types
 * is frontend/blocks/calculation/index.js (this plugin's own copy, see
 * that file's doc for why it now carries its own duplicated evaluator
 * instead of reaching into the free plugin's editor bundle).
 *
 * Trust boundary unchanged: core/entries/action.php's
 * Action::recompute_calculation_fields() (free plugin) recomputes this
 * field's value server-side from the submitted values before the entry is
 * stored — never trust the client-submitted number directly.
 */
final class Calculation extends Block_Base {
	public function get_name(): string {
		return 'calculation'; }
	public function get_title(): string {
		return __( 'Calculation', 'metform-pro' ); }
	public function get_icon(): string {
		return 'Calculator'; }
	public function get_category(): string {
		return 'Advanced'; }

	public function get_capabilities(): array {
		return array(
			'acceptsChildren' => false,
			'isField'         => true,
		);
	}

	/**
	 * The compiled frontend/form-builder bundle handle this block needs —
	 * enqueued only when a Calculation block is actually present through
	 * this plugin's asset integration after the block joins Free's shared
	 * registry via `metform/form_builder/blocks`.
	 */
	public function get_frontend_assets(): array {
		return array( 'metform-pro-form-builder-frontend' );
	}

	public function get_default_settings(): array {
		return array(
			'showLabel'     => true,
			'labelPosition' => 'top',
			'label'         => __( 'Calculation', 'metform-pro' ),
			'name'          => '',
			'helpText'      => '',
			'prefix'        => '$',
			'required'      => false,
			'expression'    => 'price * qty',
			'decimals'      => 2,
			'__className'   => '',
			'styles'        => array(),
		);
	}

	public function get_property_schema(): array {
		return array(
			'showLabel'     => array( 'type' => 'boolean' ),
			'labelPosition' => array(
				'type'       => 'string',
				'enum'       => array( 'top', 'left' ),
				'responsive' => true,
			),
			'label'         => array( 'type' => 'string' ),
			'name'          => array( 'type' => 'field_name' ),
			'helpText'      => array( 'type' => 'string' ),
			'prefix'        => array( 'type' => 'string' ),
			'required'      => array( 'type' => 'boolean' ),
			'expression'    => array( 'type' => 'string' ),
			'decimals'      => array( 'type' => 'number' ),
			'__className'   => array( 'type' => 'css_class' ),
		);
	}

	private static function typography_selector( string $el ): string {
		return "{{WRAPPER}} {$el} { font-family: {{FONT_FAMILY}}; font-size: {{FONT_SIZE}}; font-weight: {{FONT_WEIGHT}}; font-style: {{FONT_STYLE}}; text-transform: {{TEXT_TRANSFORM}}; text-decoration: {{TEXT_DECORATION}}; line-height: {{LINE_HEIGHT}}; letter-spacing: {{LETTER_SPACING}}; word-spacing: {{WORD_SPACING}}; }";
	}

	/** 1:1 with the free plugin's original Calculation::register_controls() — unchanged. */
	public function register_controls(): array {
		return array(
			'content' => array(
				array(
					'type'        => 'section',
					'key'         => 'content',
					'label'       => __( 'Content', 'metform-pro' ),
					'defaultOpen' => true,
				),
				array(
					'type'    => 'toggle',
					'key'     => 'showLabel',
					'label'   => __( 'Show Label', 'metform-pro' ),
					'default' => true,
				),
				array(
					'type'      => 'text',
					'key'       => 'label',
					'label'     => __( 'Label', 'metform-pro' ),
					'default'   => __( 'Calculation', 'metform-pro' ),
					'condition' => array( 'showLabel!' => false ),
				),
				array(
					'type'       => 'select',
					'key'        => 'labelPosition',
					'label'      => __( 'Label Position', 'metform-pro' ),
					'default'    => 'top',
					'options'    => array(
						array(
							'label' => __( 'Top', 'metform-pro' ),
							'value' => 'top',
						),
						array(
							'label' => __( 'Left', 'metform-pro' ),
							'value' => 'left',
						),
					),
					'responsive' => true,
					'condition'  => array( 'showLabel!' => false ),
				),
				array(
					'type'  => 'text',
					'key'   => 'name',
					'label' => __( 'Name', 'metform-pro' ),
					'help'  => __( 'Name is must required. Enter name without space or any special character. use only underscore/ hyphen (_/-) for multiple word. Name must be different.', 'metform-pro' ),
				),
				array(
					'type'  => 'text',
					'key'   => 'helpText',
					'label' => __( 'Help Text', 'metform-pro' ),
					'help'  => __( 'Shown below the field to guide users', 'metform-pro' ),
				),
				array(
					'type'    => 'text',
					'key'     => 'prefix',
					'label'   => __( 'Prefix', 'metform-pro' ),
					'default' => '$',
					'help'    => __( 'Shown before the computed result, e.g. a currency symbol', 'metform-pro' ),
				),
				array(
					'type'        => 'expression',
					'key'         => 'expression',
					'label'       => __( 'Expression', 'metform-pro' ),
					'default'     => 'price * qty',
					'placeholder' => 'price * qty',
					'help'        => __( "Arithmetic over other fields' Field Name values. Supports + − × ÷ %, parentheses, and round(), min(), max(), abs().", 'metform-pro' ),
				),
				array(
					'type'    => 'number',
					'key'     => 'decimals',
					'label'   => __( 'Decimal Places', 'metform-pro' ),
					'default' => 2,
					'min'     => 0,
					'max'     => 10,
				),

				array(
					'type'        => 'section',
					'key'         => 'settings',
					'label'       => __( 'Settings', 'metform-pro' ),
					'defaultOpen' => false,
				),
				array(
					'type'    => 'toggle',
					'key'     => 'required',
					'label'   => __( 'Required', 'metform-pro' ),
					'default' => false,
				),
			),
			'style'   => array(
				array(
					'type'        => 'section',
					'label'       => __( 'Label', 'metform-pro' ),
					'defaultOpen' => true,
					'condition'   => array( 'showLabel!' => false ),
				),
				array(
					'type'      => 'color',
					'key'       => 'styles.labelColor',
					'label'     => __( 'Label Color', 'metform-pro' ),
					'default'   => '#374151',
					'selector'  => '{{WRAPPER}} .mfb-label { color: {{VALUE}}; }',
					'condition' => array( 'showLabel!' => false ),
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.labelTypography',
					'label'          => __( 'Label Typography', 'metform-pro' ),
					'selector'       => self::typography_selector( '.mfb-label' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
					'condition'      => array( 'showLabel!' => false ),
				),
				array(
					'type'  => 'section',
					'label' => __( 'Help Text', 'metform-pro' ),
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.helpTextColor',
					'label'    => __( 'Help Text Color', 'metform-pro' ),
					'default'  => '#6b7280',
					'selector' => '{{WRAPPER}} .mfb-field__help { color: {{VALUE}}; }',
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.errorColor',
					'label'    => __( 'Error Color', 'metform-pro' ),
					'default'  => '#ef4444',
					'selector' => '{{WRAPPER}} .mfb-field__error { color: {{VALUE}}; }',
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.helpTextTypography',
					'label'          => __( 'Help Text Typography', 'metform-pro' ),
					'selector'       => self::typography_selector( '.mfb-field__help' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.errorTypography',
					'label'          => __( 'Error Typography', 'metform-pro' ),
					'selector'       => self::typography_selector( '.mfb-field__error' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
				),

				array(
					'type'  => 'section',
					'label' => __( 'Result', 'metform-pro' ),
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.resultColor',
					'label'    => __( 'Result Text Color', 'metform-pro' ),
					'default'  => '#111827',
					'selector' => '{{WRAPPER}} .mfb-calculation__result { color: {{VALUE}}; }',
				),
				array(
					'type'     => 'background',
					'key'      => 'styles.resultBackground',
					'label'    => __( 'Result Background', 'metform-pro' ),
					'default'  => array(
						'type'  => 'classic',
						'color' => '#f9fafb',
					),
					'selector' => '{{WRAPPER}} .mfb-calculation__field { {{VALUE}} }',
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.resultTypography',
					'label'          => __( 'Result Typography', 'metform-pro' ),
					'selector'       => self::typography_selector( '.mfb-calculation__result' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
				),
				array(
					'type'           => 'border',
					'key'            => 'styles.resultBorder',
					'label'          => __( 'Border', 'metform-pro' ),
					'default'        => array(
						'borderType' => 'solid',
						'width'      => array(
							'top'    => '1px',
							'right'  => '1px',
							'bottom' => '1px',
							'left'   => '1px',
						),
						'color'      => '#d1d5db',
						'radius'     => array(
							'top'    => '6px',
							'right'  => '6px',
							'bottom' => '6px',
							'left'   => '6px',
						),
					),
					'selector'       => '{{WRAPPER}} .mfb-calculation__field { {{VALUE}} }',
					'responsive'     => true,
					'responsiveKeys' => array( 'width', 'radius' ),
				),

				array(
					'type'  => 'section',
					'label' => __( 'Prefix', 'metform-pro' ),
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.prefixColor',
					'label'    => __( 'Prefix Color', 'metform-pro' ),
					'default'  => '#6b7280',
					'selector' => '{{WRAPPER}} .mfb-calculation__prefix { color: {{VALUE}}; }',
				),
				array(
					'type'     => 'background',
					'key'      => 'styles.prefixBackground',
					'label'    => __( 'Prefix Background', 'metform-pro' ),
					'default'  => array(
						'type'  => 'classic',
						'color' => 'transparent',
					),
					'selector' => '{{WRAPPER}} .mfb-calculation__prefix { {{VALUE}} }',
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.prefixTypography',
					'label'          => __( 'Prefix Typography', 'metform-pro' ),
					'selector'       => self::typography_selector( '.mfb-calculation__prefix' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
				),

				array(
					'type'  => 'section',
					'label' => __( 'Spacing', 'metform-pro' ),
				),
				array(
					'type'       => 'dimensions',
					'key'        => 'styles.padding',
					'label'      => __( 'Padding', 'metform-pro' ),
					'default'    => array(
						'top'    => '10px',
						'right'  => '16px',
						'bottom' => '10px',
						'left'   => '16px',
					),
					'selector'   => '{{WRAPPER}} .mfb-calculation__result { padding: {{TOP}} {{RIGHT}} {{BOTTOM}} {{LEFT}}; }',
					'responsive' => true,
				),
				array(
					'type'       => 'dimensions',
					'key'        => 'styles.margin',
					'label'      => __( 'Margin', 'metform-pro' ),
					'default'    => array(
						'top'    => '0px',
						'right'  => '0px',
						'bottom' => '0px',
						'left'   => '0px',
					),
					'selector'   => '{{WRAPPER}} .mfb-calculation__field { margin: {{TOP}} {{RIGHT}} {{BOTTOM}} {{LEFT}}; }',
					'responsive' => true,
				),
			),
		);
	}

	/**
	 * Formats a raw evaluated number: `result.toFixed(decimals)`-equivalent.
	 * Returns '' for null/non-finite.
	 */
	private static function format_result( ?float $result, int $decimals ): string {
		if ( null === $result || ! is_finite( $result ) ) {
			return '';
		}
		return number_format( $result, $decimals, '.', '' );
	}

	public function render_markup( array $settings, Render_Context $context ): string {
		$id         = $context->get_element_id();
		$name       = (string) ( $settings['name'] ?? '' );
		$expression = (string) ( $settings['expression'] ?? ( $settings['equation'] ?? '' ) );
		$decimals   = is_numeric( $settings['decimals'] ?? null ) ? (int) $settings['decimals'] : 2;
		$required   = ! empty( $settings['required'] );
		$prefix     = (string) ( $settings['prefix'] ?? '' );

		// True initial state: no field has been typed into yet, so every
		// referenced field name resolves to 0 per Expression_Evaluator's
		// own "missing field -> 0" rule.
		try {
			$result     = Expression_Evaluator::evaluate( $expression, array() );
			$eval_error = null;
		} catch ( RuntimeException $e ) {
			$result     = null;
			$eval_error = $e->getMessage();
		}
		$display = self::format_result( $result, $decimals );

		ob_start();
		?>
<div class="mfb-calculation__field">
		<?php if ( '' !== $prefix ) : ?>
	<span class="mfb-calculation__prefix"><?php echo esc_html( $prefix ); ?></span>
	<?php endif; ?>
	<span class="mfb-calculation__result" data-mfb-calculation-display><?php echo '' !== $display ? esc_html( $display ) : '&mdash;'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
</div>
		<?php /* Carries the (initially server-computed, then live-recalculated) result under the field's real name for submission. See class doc for the trust-boundary note — this value is never trusted as-is. */ ?>
<input
	type="hidden"
	id="<?php echo esc_attr( $id ); ?>"
	name="<?php echo esc_attr( $name ); ?>"
	class="mfb-calculation__value"
	value="<?php echo esc_attr( $display ); ?>"
	data-mfb-calculation-expression="<?php echo esc_attr( $expression ); ?>"
	data-mfb-calculation-decimals="<?php echo esc_attr( (string) $decimals ); ?>"
		<?php echo $required ? 'data-mf-required="1"' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
>
		<?php if ( null !== $eval_error ) : ?>
<p class="mfb-field__error"><?php echo esc_html( $eval_error ); ?></p>
		<?php endif; ?>
		</div>
		<?php
		return (string) ob_get_clean();
	}
}
