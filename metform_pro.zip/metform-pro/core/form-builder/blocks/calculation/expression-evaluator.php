<?php
namespace MetForm_Pro\Core\FormBuilder\Blocks\Calculation;

use RuntimeException;

defined( 'ABSPATH' ) || exit;

/**
 * Moved unchanged from metform\core\form-builder\blocks\calculation\
 * expression-evaluator.php — namespace updated to
 * MetForm_Pro\Core\FormBuilder\Blocks\Calculation, logic untouched.
 *
 * PHP twin of frontend/blocks/calculation/evaluator.js (this plugin's own
 * copy — see that file's doc comment for why it's now a standalone
 * duplicate rather than importing across the metform/metform-pro plugin
 * boundary). Keep the two in sync by hand if either changes, same as the
 * free plugin's original pair did.
 *
 * No `eval`/`create_function`/dynamic code execution anywhere — a plain
 * hand-written tokenizer + recursive-descent parser.
 *
 * Grammar:
 *   expr   := term (('+'|'-') term)*
 *   term   := unary (('*'|'/'|'%') unary)*
 *   unary  := ('-'|'+') unary | primary
 *   primary:= NUMBER | IDENT '(' args ')' | IDENT | '(' expr ')'
 *   args   := expr (',' expr)*
 * Bare identifiers resolve against $variables (other fields' submitted
 * values by name); an identifier immediately followed by '(' calls a
 * built-in function (round/min/max/abs).
 */
final class Expression_Evaluator {
	/**
	 * Tokenizes an arithmetic expression string into number/ident/operator
	 * tokens.
	 *
	 * @throws RuntimeException On an invalid number or unrecognized character.
	 * @return array<int, array{type: string, value?: int|float|string}>
	 */
	public static function tokenize( string $expression ): array {
		$tokens = array();
		$len    = strlen( $expression );
		$i      = 0;

		while ( $i < $len ) {
			$ch = $expression[ $i ];

			if ( ctype_space( $ch ) ) {
				++$i;
				continue;
			}

			if ( ctype_digit( $ch ) || '.' === $ch ) {
				$j = $i;
				while ( $j < $len && ( ctype_digit( $expression[ $j ] ) || '.' === $expression[ $j ] ) ) {
					++$j;
				}
				$raw = substr( $expression, $i, $j - $i );
				if ( ! preg_match( '/^\d+(\.\d+)?$|^\.\d+$/', $raw ) ) {
					throw new RuntimeException( "Invalid number \"{$raw}\"" );
				}
				$tokens[] = array(
					'type'  => 'number',
					'value' => (float) $raw,
				);
				$i        = $j;
				continue;
			}

			if ( ctype_alpha( $ch ) || '_' === $ch ) {
				$j = $i;
				// Field Name allows hyphens ("mf-number", "mf-number-2" --
				// see sanitize_key() in get_property_schema()'s field_name
				// type), so an identifier's *continuation* chars include
				// '-', not just alnum/underscore. It still can't *start*
				// with '-' (that stays the subtraction/unary-minus operator
				// token below), so "price - tax" with surrounding spaces
				// still subtracts; only a hyphen glued directly onto a
				// preceding identifier char is swallowed into the name,
				// matching how the editor's "Insert field" button writes
				// the name intact. Keep in sync with this file's JS twin
				// (frontend/blocks/calculation/evaluator.js).
				while ( $j < $len && ( ctype_alnum( $expression[ $j ] ) || '_' === $expression[ $j ] || '-' === $expression[ $j ] ) ) {
					++$j;
				}
				$tokens[] = array(
					'type'  => 'ident',
					'value' => substr( $expression, $i, $j - $i ),
				);
				$i        = $j;
				continue;
			}

			if ( false !== strpos( '+-*/%(),', $ch ) ) {
				$tokens[] = array( 'type' => $ch );
				++$i;
				continue;
			}

			throw new RuntimeException( "Unexpected character \"{$ch}\" in expression" );
		}

		return $tokens;
	}

	/**
	 * Extracts the bare field-name identifiers referenced in an expression.
	 *
	 * @return string[] Unique referenced field names, in first-seen order.
	 */
	public static function get_referenced_fields( string $expression ): array {
		if ( '' === trim( $expression ) ) {
			return array();
		}
		try {
			$tokens = self::tokenize( $expression );
		} catch ( RuntimeException $e ) {
			return array();
		}
		$names = array();
		$count = count( $tokens );
		foreach ( $tokens as $i => $tok ) {
			if ( 'ident' === $tok['type'] && ! ( $i + 1 < $count && '(' === $tokens[ $i + 1 ]['type'] ) ) {
				$names[ $tok['value'] ] = true;
			}
		}
		return array_keys( $names );
	}

	private static function call_function( string $name, array $args ): float {
		switch ( $name ) {
			case 'round':
				$x      = $args[0] ?? 0;
				$places = $args[1] ?? 0;
				$factor = 10 ** $places;
				return round( $x * $factor ) / $factor;
			case 'min':
				if ( empty( $args ) ) {
					throw new RuntimeException( 'min() requires at least one argument' );
				}
				return min( $args );
			case 'max':
				if ( empty( $args ) ) {
					throw new RuntimeException( 'max() requires at least one argument' );
				}
				return max( $args );
			case 'abs':
				return abs( $args[0] ?? 0 );
			default:
				throw new RuntimeException( "Unknown function \"{$name}()\"" );
		}
	}

	/**
	 * Recursive-descent parse + evaluate.
	 *
	 * @throws RuntimeException On any parse/eval error (unknown function,
	 *                           division by zero, mismatched parens, ...).
	 */
	private static function parse( array $tokens, array $variables ): float {
		$pos     = 0;
		$n       = count( $tokens );
		$peek    = static function () use ( $tokens, &$pos, $n ) {
			return $pos < $n ? $tokens[ $pos ] : null;
		};
		$consume = static function () use ( $tokens, &$pos ) {
			return $tokens[ $pos++ ];
		};

		$parse_expr    = null;
		$parse_term    = null;
		$parse_unary   = null;
		$parse_primary = null;
		$parse_args    = null;

		$parse_expr = function () use ( &$parse_term, $peek, $consume, &$parse_expr ) {
			$value = $parse_term();
			while ( ( $tok = $peek() ) && ( '+' === $tok['type'] || '-' === $tok['type'] ) ) {
				$op    = $consume()['type'];
				$rhs   = $parse_term();
				$value = '+' === $op ? $value + $rhs : $value - $rhs;
			}
			return $value;
		};

		$parse_term = function () use ( &$parse_unary, $peek, $consume ) {
			$value = $parse_unary();
			while ( ( $tok = $peek() ) && in_array( $tok['type'], array( '*', '/', '%' ), true ) ) {
				$op  = $consume()['type'];
				$rhs = $parse_unary();
				if ( ( '/' === $op || '%' === $op ) && 0 == $rhs ) {
					throw new RuntimeException( 'Division by zero' );
				}
				if ( '*' === $op ) {
					$value = $value * $rhs;
				} elseif ( '/' === $op ) {
					$value = $value / $rhs;
				} else {
					$value = fmod( $value, $rhs );
				}
			}
			return $value;
		};

		$parse_unary = function () use ( &$parse_primary, &$parse_unary, $peek, $consume ) {
			$tok = $peek();
			if ( $tok && '-' === $tok['type'] ) {
				$consume();
				return -$parse_unary();
			}
			if ( $tok && '+' === $tok['type'] ) {
				$consume();
				return $parse_unary();
			}
			return $parse_primary();
		};

		$parse_args = function () use ( &$parse_expr, $peek, $consume ) {
			$args = array();
			$tok  = $peek();
			if ( $tok && ')' !== $tok['type'] ) {
				$args[] = $parse_expr();
				while ( ( $tok = $peek() ) && ',' === $tok['type'] ) {
					$consume();
					$args[] = $parse_expr();
				}
			}
			$tok = $peek();
			if ( ! $tok || ')' !== $tok['type'] ) {
				throw new RuntimeException( 'Missing closing parenthesis' );
			}
			$consume();
			return $args;
		};

		$parse_primary = function () use ( &$parse_expr, $peek, $consume, $parse_args, $variables ) {
			$tok = $peek();
			if ( ! $tok ) {
				throw new RuntimeException( 'Unexpected end of expression' );
			}

			if ( 'number' === $tok['type'] ) {
				$consume();
				return (float) $tok['value'];
			}

			if ( 'ident' === $tok['type'] ) {
				$consume();
				$next = $peek();
				if ( $next && '(' === $next['type'] ) {
					$consume();
					$args = $parse_args();
					return self::call_function( $tok['value'], $args );
				}
				$raw = $variables[ $tok['value'] ] ?? null;
				if ( null === $raw || '' === $raw ) {
					return 0.0;
				}
				$num = is_numeric( $raw ) ? (float) $raw : NAN;
				return is_finite( $num ) ? $num : 0.0;
			}

			if ( '(' === $tok['type'] ) {
				$consume();
				$value = $parse_expr();
				$next  = $peek();
				if ( ! $next || ')' !== $next['type'] ) {
					throw new RuntimeException( 'Missing closing parenthesis' );
				}
				$consume();
				return $value;
			}

			throw new RuntimeException( "Unexpected token \"{$tok['type']}\"" );
		};

		$result = $parse_expr();
		if ( $pos !== $n ) {
			throw new RuntimeException( 'Unexpected trailing input' );
		}
		return $result;
	}

	/**
	 * Evaluates an arithmetic expression against a set of field values.
	 *
	 * @param string               $expression The formula (e.g. "price * qty").
	 * @param array<string, mixed> $variables Other fields' submitted values, by name.
	 * @throws RuntimeException On any parse/eval error — callers should catch.
	 */
	public static function evaluate( string $expression, array $variables = array() ): ?float {
		if ( '' === trim( $expression ) ) {
			return null;
		}
		$tokens = self::tokenize( $expression );
		if ( empty( $tokens ) ) {
			return null;
		}
		return self::parse( $tokens, $variables );
	}
}
