<?php
namespace MetForm_Pro\Core\FormBuilder\Blocks\Colorpicker;

use MetForm\Core\FormBuilder\Block_Base;
use MetForm\Core\FormBuilder\Rendering\Render_Context;
use MetForm\Core\FormBuilder\Shared\Input_Controls;

defined( 'ABSPATH' ) || exit;


final class Colorpicker extends Block_Base {
	public function get_name(): string {
		return 'colorpicker'; }
	public function get_title(): string {
		return __( 'Color Picker', 'metform-pro' ); }
	public function get_icon(): string {
		return 'Pipette'; }
	public function get_category(): string {
		return 'Advanced'; }

	public function get_capabilities(): array {
		return array(
			'acceptsChildren' => false,
			'isField'         => true,
		);
	}

	/**
	 * The compiled frontend/form-builder bundle handle this block needs —
	 * enqueued only when this block is actually present, via this plugin's
	 * own Base::enqueue_block_assets() (mirrors canvas.php's identical
	 * per-block loop in the free plugin, which never sees Pro blocks).
	 */
	public function get_frontend_assets(): array {
		return array( 'metform-pro-form-builder-frontend' );
	}

	public function get_default_settings(): array {
		return array(
			'label'         => __( 'Color Picker', 'metform-pro' ),
			'labelPosition' => 'top',
			'name'          => '',
			'placeholder'   => '#000000',
			'helpText'      => '',
			'required'      => false,
			'showLabel'     => true,
			'allowAlpha'    => false,
			'presetColors'  => array(),
			'styles'        => array(),
		);
	}

	public function get_property_schema(): array {
		return array(
			'label'         => array( 'type' => 'string' ),
			'labelPosition' => array(
				'type'       => 'string',
				'enum'       => array( 'top', 'left' ),
				'responsive' => true,
			),
			'name'          => array( 'type' => 'field_name' ),
			'placeholder'   => array( 'type' => 'string' ),
			'helpText'      => array( 'type' => 'string' ),
			'required'      => array( 'type' => 'boolean' ),
			'showLabel'     => array( 'type' => 'boolean' ),
			'allowAlpha'    => array( 'type' => 'boolean' ),
			'presetColors'  => array( 'type' => 'object' ),
		);
	}

	public function register_controls(): array {
		return array(
			'content' => array(
				array(
					'type'        => 'section',
					'key'         => 'content',
					'label'       => __( 'Content', 'metform-pro' ),
					'defaultOpen' => true,
				),
				array(
					'type'    => 'toggle',
					'key'     => 'showLabel',
					'label'   => __( 'Show Label', 'metform-pro' ),
					'default' => true,
				),
				array(
					'type'      => 'text',
					'key'       => 'label',
					'label'     => __( 'Label', 'metform-pro' ),
					'default'   => __( 'Color Picker', 'metform-pro' ),
					'condition' => array( 'showLabel!' => false ),
				),
				array(
					'type'       => 'select',
					'key'        => 'labelPosition',
					'label'      => __( 'Label Position', 'metform-pro' ),
					'default'    => 'top',
					'options'    => array(
						array(
							'label' => __( 'Top', 'metform-pro' ),
							'value' => 'top',
						),
						array(
							'label' => __( 'Left', 'metform-pro' ),
							'value' => 'left',
						),
					),
					'condition'  => array( 'showLabel!' => false ),
					'responsive' => true,
				),
				array(
					'type'  => 'text',
					'key'   => 'name',
					'label' => __( 'Name', 'metform-pro' ),
					'help'  => __( 'Name is must required. Enter name without space or any special character. use only underscore/ hyphen (_/-) for multiple word. Name must be different.', 'metform-pro' ),
				),
				array(
					'type'    => 'text',
					'key'     => 'placeholder',
					'label'   => __( 'Placeholder', 'metform-pro' ),
					'default' => '#000000',
				),
				array(
					'type'  => 'text',
					'key'   => 'helpText',
					'label' => __( 'Help Text', 'metform-pro' ),
					'help'  => __( 'Shown below the field to guide users', 'metform-pro' ),
				),
				array(
					'type'    => 'toggle',
					'key'     => 'allowAlpha',
					'label'   => __( 'Enable Opacity', 'metform-pro' ),
					'default' => false,
					'help'    => __( 'Adds an alpha slider so users can pick semi-transparent colors (stored as rgba()).', 'metform-pro' ),
				),
				array(
					'type'       => 'repeater',
					'key'        => 'presetColors',
					'label'      => __( 'Preset Colors', 'metform-pro' ),
					'default'    => array(),
					'titleField' => 'color',
					'addLabel'   => __( 'ADD COLOR', 'metform-pro' ),
					'help'       => __( 'Quick-pick swatches shown at the top of the color picker popup.', 'metform-pro' ),
					'fields'     => array(
						array(
							'type'  => 'color',
							'key'   => 'color',
							'label' => __( 'Color', 'metform-pro' ),
						),
					),
				),

				array(
					'type'        => 'section',
					'key'         => 'settings',
					'label'       => __( 'Settings', 'metform-pro' ),
					'defaultOpen' => false,
				),
				array(
					'type'    => 'toggle',
					'key'     => 'required',
					'label'   => __( 'Required', 'metform-pro' ),
					'default' => false,
				),
			),
			'style'   => Input_Controls::style(
				'input',
				array(
					array(
						'type'  => 'section',
						'label' => __( 'Swatch', 'metform-pro' ),
					),
					array(
						'type'       => 'range',
						'key'        => 'styles.swatchSize',
						'label'      => __( 'Swatch Size', 'metform-pro' ),
						'default'    => '40px',
						'units'      => array( 'px' ),
						'min'        => 24,
						'max'        => 72,
						'step'       => 1,
						'selector'   => '{{WRAPPER}} .mfb-colorpicker__swatch { width: {{VALUE}}; height: {{VALUE}}; }',
						'responsive' => true,
					),
					array(
						'type'           => 'border',
						'key'            => 'styles.swatchBorder',
						'label'          => __( 'Swatch Border', 'metform-pro' ),
						'default'        => array(
							'borderType' => 'solid',
							'width'      => array(
								'top'    => '1px',
								'right'  => '1px',
								'bottom' => '1px',
								'left'   => '1px',
							),
							'color'      => '#d1d5db',
							'radius'     => array(
								'top'    => '8px',
								'right'  => '8px',
								'bottom' => '8px',
								'left'   => '8px',
							),
						),
						'selector'       => '{{WRAPPER}} .mfb-colorpicker__swatch { {{VALUE}} }',
						'responsive'     => true,
						'responsiveKeys' => array( 'width', 'radius' ),
					),
				),
				array( 'styles.width', 'styles.padding', 'styles.border', 'styles.borderColor' )
			),
		);
	}

	/** '#RRGGBB' (any case) -> 'r, g, b' for building an rgba() string. Falls back to black. */
	private function hex_to_rgb_triplet( string $hex ): string {
		if ( ! preg_match( '/^#([0-9a-fA-F]{6})$/', $hex, $m ) ) {
			return '0, 0, 0';
		}
		$r = hexdec( substr( $m[1], 0, 2 ) );
		$g = hexdec( substr( $m[1], 2, 2 ) );
		$b = hexdec( substr( $m[1], 4, 2 ) );
		return "$r, $g, $b";
	}

	public function render_markup( array $settings, Render_Context $context ): string {
		$id                  = $context->get_element_id();
		$name                = (string) ( $settings['name'] ?? '' );
		$placeholder         = (string) ( $settings['placeholder'] ?? '#000000' );
		$raw_value           = (string) ( $settings['value'] ?? $settings['defaultValue'] ?? '' );
		$value               = preg_match( '/^#[0-9a-fA-F]{6}$/', $raw_value ) ? strtolower( $raw_value ) : '';
		$display_placeholder = preg_match( '/^#[0-9a-fA-F]{6}$/', $placeholder ) ? strtolower( $placeholder ) : '#000000';
		$required            = ! empty( $settings['required'] );
		$allow_alpha         = ! empty( $settings['allowAlpha'] );
		$native_name         = $allow_alpha ? $name . '--local' : $name;

		$preset_colors = array();
		if ( ! empty( $settings['presetColors'] ) && is_array( $settings['presetColors'] ) ) {
			foreach ( $settings['presetColors'] as $preset ) {
				$color = (string) ( $preset['color'] ?? '' );
				if ( preg_match( '/^#[0-9a-fA-F]{6}$/', $color ) ) {
					$preset_colors[] = strtolower( $color );
				}
			}
		}

		$swatch_color = $value !== '' ? $value : $display_placeholder;

		ob_start();
		?>
		<div class="mfb-colorpicker__wrap" <?php echo $allow_alpha ? 'data-mf-colorpicker-alpha' : ''; ?> data-mf-colorpicker-placeholder="<?php echo esc_attr( $display_placeholder ); ?>">
			<input type="hidden" id="<?php echo esc_attr( $id ); ?>-input" name="<?php echo esc_attr( $native_name ); ?>" class="mfb-colorpicker__native" value="<?php echo esc_attr( $value ); ?>" data-mf-colorpicker-hex-input <?php echo $allow_alpha ? '' : ( $required ? 'required' : '' ); ?>>
			<?php
			if ( $allow_alpha ) :
				$seeded_rgba = $value !== '' ? 'rgba(' . $this->hex_to_rgb_triplet( $value ) . ', 1)' : '';
				?>
				<input type="hidden" name="<?php echo esc_attr( $name ); ?>" class="mfb-colorpicker__combined" value="<?php echo esc_attr( $seeded_rgba ); ?>" <?php echo $required ? 'required' : ''; ?>>
			<?php endif; ?>

			<div class="mfb-colorpicker__card">
				<button type="button" id="<?php echo esc_attr( $id ); ?>" class="mfb-colorpicker__trigger" data-mf-colorpicker-trigger aria-haspopup="true" aria-expanded="false" aria-controls="<?php echo esc_attr( $id ); ?>-panel">
					<span class="mfb-colorpicker__swatch" data-mf-colorpicker-swatch style="background-color: <?php echo esc_attr( $swatch_color ); ?>;"></span>
					<span class="mfb-colorpicker__info">
						<span class="mfb-colorpicker__value" data-mf-colorpicker-value><?php echo esc_html( $value !== '' ? strtoupper( $value ) : $display_placeholder ); ?></span>
						<span class="mfb-colorpicker__hint"><?php esc_html_e( 'Tap to choose a color', 'metform-pro' ); ?></span>
					</span>
					<span class="mfb-colorpicker__chevron" data-mf-colorpicker-chevron aria-hidden="true"></span>
				</button>

				<div id="<?php echo esc_attr( $id ); ?>-panel" class="mfb-colorpicker__panel" data-mf-colorpicker-panel>
					<div class="mfb-colorpicker__sv" data-mf-colorpicker-sv>
						<div class="mfb-colorpicker__sv-white"></div>
						<div class="mfb-colorpicker__sv-black"></div>
						<div class="mfb-colorpicker__sv-thumb" data-mf-colorpicker-sv-thumb></div>
					</div>

					<div class="mfb-colorpicker__hue-row">
						<div class="mfb-colorpicker__hue" data-mf-colorpicker-hue>
							<div class="mfb-colorpicker__hue-thumb" data-mf-colorpicker-hue-thumb></div>
						</div>
						<button type="button" class="mfb-colorpicker__eyedropper" data-mf-colorpicker-eyedropper hidden aria-label="<?php esc_attr_e( 'Pick color from screen', 'metform-pro' ); ?>">
							<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m2 22 1-4 9.5-9.5"></path><path d="m13.5 7.5 3-3L20 8l-3 3"></path><path d="M17.5 4.5 19.5 6.5"></path><path d="m8.5 15.5 3 3"></path></svg>
						</button>
					</div>

					<div class="mfb-colorpicker__fields">
						<label class="mfb-colorpicker__field">
							<input type="text" inputmode="numeric" autocomplete="off" data-mf-colorpicker-r value="0">
							<span><?php esc_html_e( 'R', 'metform-pro' ); ?></span>
						</label>
						<label class="mfb-colorpicker__field">
							<input type="text" inputmode="numeric" autocomplete="off" data-mf-colorpicker-g value="0">
							<span><?php esc_html_e( 'G', 'metform-pro' ); ?></span>
						</label>
						<label class="mfb-colorpicker__field">
							<input type="text" inputmode="numeric" autocomplete="off" data-mf-colorpicker-b value="0">
							<span><?php esc_html_e( 'B', 'metform-pro' ); ?></span>
						</label>
						<?php if ( $allow_alpha ) : ?>
							<label class="mfb-colorpicker__field">
								<input type="text" inputmode="numeric" autocomplete="off" data-mf-colorpicker-a value="100">
								<span><?php esc_html_e( 'A', 'metform-pro' ); ?></span>
							</label>
						<?php endif; ?>
					</div>

					<?php if ( $allow_alpha ) : ?>
						<div class="mfb-colorpicker__row">
							<span class="mfb-colorpicker__row-label"><?php esc_html_e( 'Opacity', 'metform-pro' ); ?></span>
							<input type="range" class="mfb-colorpicker__alpha" data-mf-colorpicker-alpha-range min="0" max="100" step="1" value="100" aria-label="<?php esc_attr_e( 'Opacity', 'metform-pro' ); ?>">
							<span class="mfb-colorpicker__alpha-value" data-mf-colorpicker-alpha-value>100%</span>
						</div>
					<?php endif; ?>

					<?php if ( ! empty( $preset_colors ) ) : ?>
						<div class="mfb-colorpicker__row">
							<span class="mfb-colorpicker__row-label"><?php esc_html_e( 'Presets', 'metform-pro' ); ?></span>
							<div class="mfb-colorpicker__presets" data-mf-colorpicker-presets>
								<?php foreach ( $preset_colors as $preset_color ) : ?>
									<button type="button" class="mfb-colorpicker__preset <?php echo $preset_color === $value ? 'mfb-colorpicker__preset--active' : ''; ?>" data-color="<?php echo esc_attr( $preset_color ); ?>" style="background-color: <?php echo esc_attr( $preset_color ); ?>;" aria-label="<?php echo esc_attr( $preset_color ); ?>" aria-pressed="<?php echo $preset_color === $value ? 'true' : 'false'; ?>"></button>
								<?php endforeach; ?>
							</div>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php
		return (string) ob_get_clean();
	}
}
