<?php
namespace MetForm_Pro\Core\FormBuilder\Blocks\Maplocation;

use MetForm\Core\FormBuilder\Block_Base;
use MetForm\Core\FormBuilder\Rendering\Render_Context;
use MetForm\Core\FormBuilder\Shared\Input_Controls;
use MetForm\Core\FormBuilder\Dynamic_Css\Responsive_Value;

defined( 'ABSPATH' ) || exit;

final class Maplocation extends Block_Base {
	public function get_name(): string {
		return 'maplocation'; }
	public function get_title(): string {
		return __( 'Google Map Location', 'metform-pro' ); }
	public function get_icon(): string {
		return 'MapPin'; }
	public function get_category(): string {
		return 'Advanced'; }

	public function get_capabilities(): array {
		return array(
			'acceptsChildren' => false,
			'isField'         => true,
		);
	}

	public function get_frontend_assets(): array {
		return array(
			'metform-pro-form-builder-frontend',
			'maps-api',
		);
	}

	public function get_default_settings(): array {
		return array(
			'showLabel'       => true,
			'label'           => __( 'Google Map Location', 'metform-pro' ),
			'labelPosition'   => 'top',
			'name'            => '',
			'placeholder'     => __( 'Search location...', 'metform-pro' ),
			'helpText'        => '',
			'required'        => false,
			'requiredMessage' => '',
			'showClearIcon'   => false,
			'showMap'         => false,
			'clickable'       => true,
			'draggableMarker' => true,
			'defaultLat'      => '23.8103',
			'defaultLng'      => '90.4125',
			'defaultZoom'     => 8,
			'mapHeight'       => 300,
			'styles'          => array(),
		);
	}

	public function get_property_schema(): array {
		return array(
			'showLabel'       => array( 'type' => 'boolean' ),
			'label'           => array( 'type' => 'string' ),
			'labelPosition'   => array(
				'type'       => 'string',
				'enum'       => array( 'top', 'left' ),
				'responsive' => true,
			),
			'name'            => array( 'type' => 'field_name' ),
			'placeholder'     => array( 'type' => 'string' ),
			'helpText'        => array( 'type' => 'string' ),
			'required'        => array( 'type' => 'boolean' ),
			'requiredMessage' => array( 'type' => 'string' ),
			'showClearIcon'   => array( 'type' => 'boolean' ),
			'showMap'         => array( 'type' => 'boolean' ),
			'clickable'       => array( 'type' => 'boolean' ),
			'draggableMarker' => array( 'type' => 'boolean' ),
			'defaultLat'      => array( 'type' => 'string' ),
			'defaultLng'      => array( 'type' => 'string' ),
			'defaultZoom'     => array( 'type' => 'integer' ),
			'mapHeight'       => array(
				'type'       => 'integer',
				'responsive' => true,
			),
		);
	}

	public function register_controls(): array {
		return array(
			'content' => array(
				array(
					'type'        => 'section',
					'key'         => 'content',
					'label'       => __( 'Content', 'metform-pro' ),
					'defaultOpen' => true,
				),
				array(
					'type'    => 'toggle',
					'key'     => 'showLabel',
					'label'   => __( 'Show Label', 'metform-pro' ),
					'default' => true,
				),
				array(
					'type'      => 'text',
					'key'       => 'label',
					'label'     => __( 'Label', 'metform-pro' ),
					'default'   => __( 'Google Map Location', 'metform-pro' ),
					'inline'    => true,
					'condition' => array( 'showLabel!' => false ),
				),
				array(
					'type'       => 'select',
					'key'        => 'labelPosition',
					'label'      => __( 'Label Position', 'metform-pro' ),
					'default'    => 'top',
					'inline'     => true,
					'options'    => array(
						array(
							'label' => __( 'Top', 'metform-pro' ),
							'value' => 'top',
						),
						array(
							'label' => __( 'Left', 'metform-pro' ),
							'value' => 'left',
						),
					),
					'condition'  => array( 'showLabel!' => false ),
					'responsive' => true,
				),
				array(
					'type'   => 'text',
					'key'    => 'name',
					'label'  => __( 'Name', 'metform-pro' ),
					'inline' => true,
					'help'   => __( 'Name is must required. Enter name without space or any special character. use only underscore/ hyphen (_/-) for multiple word. Name must be different.', 'metform-pro' ),
				),
				array(
					'type'    => 'text',
					'key'     => 'placeholder',
					'label'   => __( 'Placeholder', 'metform-pro' ),
					'default' => __( 'Search location...', 'metform-pro' ),
					'inline'  => true,
				),
				array(
					'type'  => 'text',
					'key'   => 'helpText',
					'label' => __( 'Help Text', 'metform-pro' ),
					'help'  => __( 'Shown below the field to guide users', 'metform-pro' ),
				),
				array(
					'type'    => 'toggle',
					'key'     => 'showClearIcon',
					'label'   => __( 'Show Clear Button', 'metform-pro' ),
					'default' => false,
					'help'    => __( 'Shows a clear button inside the field to reset address and map.', 'metform-pro' ),
				),

				array(
					'type'        => 'section',
					'key'         => 'map_settings',
					'label'       => __( 'Map Settings', 'metform-pro' ),
					'defaultOpen' => false,
				),
				array(
					'type'    => 'toggle',
					'key'     => 'showMap',
					'label'   => __( 'Show Interactive Map', 'metform-pro' ),
					'default' => false,
					'help'    => __( 'Shows an interactive map below the address search input.', 'metform-pro' ),
				),
				array(
					'type'      => 'toggle',
					'key'       => 'clickable',
					'label'     => __( 'Click Map to Pick Point', 'metform-pro' ),
					'default'   => true,
					'condition' => array( 'showMap' => true ),
				),
				array(
					'type'      => 'toggle',
					'key'       => 'draggableMarker',
					'label'     => __( 'Draggable Marker', 'metform-pro' ),
					'default'   => true,
					'condition' => array( 'showMap' => true ),
				),
				array(
					'type'      => 'text',
					'key'       => 'defaultLat',
					'label'     => __( 'Default Latitude', 'metform-pro' ),
					'default'   => '23.8103',
					'condition' => array( 'showMap' => true ),
				),
				array(
					'type'      => 'text',
					'key'       => 'defaultLng',
					'label'     => __( 'Default Longitude', 'metform-pro' ),
					'default'   => '90.4125',
					'condition' => array( 'showMap' => true ),
				),
				array(
					'type'      => 'range',
					'key'       => 'defaultZoom',
					'label'     => __( 'Default Zoom', 'metform-pro' ),
					'default'   => 8,
					'min'       => 1,
					'max'       => 20,
					'step'      => 1,
					'condition' => array( 'showMap' => true ),
				),
				array(
					'type'       => 'range',
					'key'        => 'mapHeight',
					'label'      => __( 'Map Height (px)', 'metform-pro' ),
					'default'    => 300,
					'min'        => 150,
					'max'        => 800,
					'step'       => 10,
					'units'      => array( 'px' ),
					'condition'  => array( 'showMap' => true ),
					'responsive' => true,
				),

				array(
					'type'        => 'section',
					'key'         => 'settings',
					'label'       => __( 'Settings', 'metform-pro' ),
					'defaultOpen' => false,
				),
				array(
					'type'    => 'toggle',
					'key'     => 'required',
					'label'   => __( 'Required', 'metform-pro' ),
					'default' => false,
				),
				array(
					'type'      => 'text',
					'key'       => 'requiredMessage',
					'label'     => __( 'Required Message', 'metform-pro' ),
					'condition' => array( 'required' => true ),
				),
			),
			'style'   => Input_Controls::style(
				'input',
				array(
					array(
						'type'      => 'section',
						'label'     => __( 'Map Canvas', 'metform-pro' ),
						'condition' => array( 'showMap' => true ),
					),
					array(
						'type'           => 'border',
						'key'            => 'styles.mapBorder',
						'label'          => __( 'Map Border', 'metform-pro' ),
						'default'        => array(
							'borderType' => 'solid',
							'width'      => array(
								'top'    => '1px',
								'right'  => '1px',
								'bottom' => '1px',
								'left'   => '1px',
							),
							'color'      => '#e5e7eb',
							'radius'     => array(
								'top'    => '6px',
								'right'  => '6px',
								'bottom' => '6px',
								'left'   => '6px',
							),
						),
						'selector'       => '{{WRAPPER}} .mfb-map__canvas { {{VALUE}} overflow: hidden; }',
						'responsive'     => true,
						'responsiveKeys' => array( 'width', 'radius' ),
					),
					array(
						'type'       => 'dimensions',
						'key'        => 'styles.mapMargin',
						'label'      => __( 'Map Margin', 'metform-pro' ),
						'default'    => array(
							'top'    => '10px',
							'right'  => '0px',
							'bottom' => '0px',
							'left'   => '0px',
						),
						'selector'   => '{{WRAPPER}} .mfb-map__canvas { margin: {{TOP}} {{RIGHT}} {{BOTTOM}} {{LEFT}}; }',
						'responsive' => true,
					),
				)
			),
		);
	}

	/**
	 * Adds per-breakpoint Map Height overrides. The desktop height is the
	 * map canvas's inline style; these `!important` media rules win over it.
	 *
	 * @since 4.4.1
	 *
	 * @param array<string, mixed> $settings   Block settings.
	 * @param string               $class_name Scoped selector.
	 * @return string CSS.
	 */
	public function build_dynamic_css( array $settings, string $class_name ): string {
		$css     = parent::build_dynamic_css( $settings, $class_name );
		$setting = $settings['mapHeight'] ?? null;
		foreach ( Responsive_Value::get_breakpoints() as $slot => $media ) {
			if ( ! in_array( $slot, Responsive_Value::overridden_slots( $setting ), true ) ) {
				continue;
			}
			$height = self::map_height( $setting[ $slot ] );
			if ( null !== $height ) {
				$css .= "{$media} { .{$class_name} .mfb-map__canvas { height: {$height}px !important; } }";
			}
		}
		return $css;
	}

	/** Map height in px (a positive integer), or null. */
	private static function map_height( $value ): ?int {
		$height = is_scalar( $value ) ? (int) $value : 0; // "300" / 300 / "300px".
		return $height > 0 ? $height : null;
	}

	public function render_markup( array $settings, Render_Context $context ): string {
		$id          = $context->get_element_id();
		$name        = (string) ( $settings['name'] ?? '' );
		$placeholder = (string) ( $settings['placeholder'] ?? __( 'Search location...', 'metform-pro' ) );
		$required    = ! empty( $settings['required'] );
		$show_clear  = ! empty( $settings['showClearIcon'] );
		$show_map    = ! empty( $settings['showMap'] );

		$map_lat  = ! empty( $settings['defaultLat'] ) ? (string) $settings['defaultLat'] : '23.8103';
		$map_lng  = ! empty( $settings['defaultLng'] ) ? (string) $settings['defaultLng'] : '90.4125';
		$map_zoom = ! empty( $settings['defaultZoom'] ) ? (int) $settings['defaultZoom'] : 8;
		// Desktop height inline; tablet/mobile come from build_dynamic_css().
		$map_height    = self::map_height( Responsive_Value::resolve( $settings['mapHeight'] ?? null, 'desktop', null ) ) ?? 300;
		$map_clickable = ! empty( $settings['clickable'] ) ? '1' : '0';
		$map_draggable = ! empty( $settings['draggableMarker'] ) ? '1' : '0';

		ob_start();
		?>
		<div class="mfb-map__group">
			<div class="mfb-map__input-wrap">
				<input
					id="<?php echo esc_attr( $id ); ?>"
					type="text"
					name="<?php echo esc_attr( $name ); ?>"
					class="mfb-field__input mfb-map__input"
					placeholder="<?php echo esc_attr( $placeholder ); ?>"
					autocomplete="off"
					data-mf-map-input
					<?php echo $required ? 'required data-mf-required="true"' : ''; ?>
				>
				<?php if ( $show_clear ) : ?>
					<button type="button" class="mfb-map__clear-btn" aria-label="<?php esc_attr_e( 'Clear address', 'metform-pro' ); ?>" title="<?php esc_attr_e( 'Clear address', 'metform-pro' ); ?>">
						<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
							<line x1="18" y1="6" x2="6" y2="18"></line>
							<line x1="6" y1="6" x2="18" y2="18"></line>
						</svg>
					</button>
				<?php endif; ?>
			</div>

			<?php if ( $show_map ) : ?>
				<div
					class="mfb-map__canvas"
					id="<?php echo esc_attr( $id ); ?>-map"
					data-lat="<?php echo esc_attr( $map_lat ); ?>"
					data-lng="<?php echo esc_attr( $map_lng ); ?>"
					data-zoom="<?php echo esc_attr( (string) $map_zoom ); ?>"
					data-height="<?php echo esc_attr( (string) $map_height ); ?>"
					data-clickable="<?php echo esc_attr( $map_clickable ); ?>"
					data-draggable="<?php echo esc_attr( $map_draggable ); ?>"
					style="height: <?php echo esc_attr( (string) $map_height ); ?>px;"
				>
					<?php if ( $context->is_editor() ) : ?>
						<div class="mfb-map__canvas-placeholder">
							<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
								<path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
								<circle cx="12" cy="10" r="3"></circle>
							</svg>
							<span><?php esc_html_e( 'Interactive Google Map Preview', 'metform-pro' ); ?></span>
						</div>
					<?php endif; ?>
				</div>

				<input type="hidden" name="<?php echo esc_attr( $name ); ?>_lat" class="mfb-map__lat" data-mf-map-lat>
				<input type="hidden" name="<?php echo esc_attr( $name ); ?>_lng" class="mfb-map__lng" data-mf-map-lng>
			<?php endif; ?>
		</div>
		<?php
		return (string) ob_get_clean();
	}
}
