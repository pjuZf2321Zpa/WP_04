<?php
namespace MetForm_Pro\Core\FormBuilder\Blocks\Signature;

use MetForm\Core\FormBuilder\Block_Base;
use MetForm\Core\FormBuilder\Rendering\Render_Context;

defined( 'ABSPATH' ) || exit;

/**
 * Wave 4, block 3/11 (§5.5 checklist).
 *
 * Ported from src/form-builder/blocks/signature/manifest.js +
 * blocks/signature/index.jsx. Uses Field_Renderer::wrap() — the React
 * component's own markup (`mfb-field__wrapper` > `mfb-field__row` >
 * FormLabel + `mfb-field__control`) is already exactly Field_Renderer's
 * shape.
 *
 * UNLIKE every other Wave 1/4 "native-HTML-only simplification" block
 * (date/time/colorpicker/number/fileupload), a signature pad has NO native
 * HTML equivalent — freehand pointer-drawing onto a `<canvas>` and encoding
 * it as a data URL is only possible with JS. There is nothing to fall back
 * to. So this block's PHP output is a real, correctly-styled static shell —
 * canvas box, "Sign here" placeholder, a `hidden` icon-only reset button
 * overlaid in the pad's own corner, and a hidden input carrying the
 * eventual `image/png` data URL under the field's `name` — that a frontend
 * JS module then progressively enhances:
 * src/frontend/form-builder/blocks/signature/index.js wires up
 * pointerdown/pointermove/pointerup drawing on the canvas (mirroring
 * index.jsx's resize/redraw/commit logic), populates the hidden input via
 * canvas.toDataURL(), and reveals/wires the reset button once a signature
 * exists (hiding it again after Clear). That module is loaded on the
 * public frontend only (via the root src/frontend/form-builder/index.js
 * bundle) — it does NOT reach the React editor canvas (a separate webpack
 * entry). The canvas's static preview gets its default look (canvas box,
 * placeholder, reset button) from the
 * shared src/form-builder/blocks/server-rendered-base.scss stylesheet
 * instead (§3 of PHP_MIGRATION_MASTER_PLAN.md) — this block used to print
 * that same CSS per-instance via a `render_base_style()` PHP method; that
 * method is gone now that the shared stylesheet covers it. The canvas
 * stays a non-drawable static preview by design; only the frontend is
 * meant to be drawable.
 * Without JS (e.g. disabled in the visitor's browser), the field degrades
 * to exactly the static shell described above — no worse than before this
 * module existed.
 *
 * Known gap: the `required` setting cannot be enforced by the browser's
 * OWN constraint validation (a `required` attribute on `type="hidden"` has
 * no effect per the HTML spec — hidden inputs are excluded from it
 * entirely). The frontend module's initRequiredGuard() works around this
 * with its own submit-time check instead (see that function's doc) — but
 * this is still only client-side; true zero-trust enforcement per §4.4
 * still needs a matching server-side check on submit handling, which does
 * not exist yet for any Wave 4 block.
 */
final class Signature extends Block_Base {
	public function get_name(): string {
		return 'signature'; }
	public function get_title(): string {
		return __( 'Signature', 'metform-pro' ); }
	public function get_icon(): string {
		return 'Signature'; }
	public function get_category(): string {
		return 'Advanced'; }

	public function get_capabilities(): array {
		return array(
			'acceptsChildren' => false,
			'isField'         => true,
		);
	}

	/**
	 * The compiled frontend/form-builder bundle handle this block needs —
	 * enqueued only when this block is actually present, via this plugin's
	 * own Base::enqueue_block_assets() (mirrors canvas.php's identical
	 * per-block loop in the free plugin, which never sees Pro blocks).
	 */
	public function get_frontend_assets(): array {
		return array( 'metform-pro-form-builder-frontend' );
	}

	public function get_default_settings(): array {
		return array(
			'showLabel'     => true,
			'labelPosition' => 'top',
			'label'         => __( 'Signature', 'metform-pro' ),
			'name'          => '',
			'helpText'      => '',
			'required'      => false,
			'__className'   => '',
			'styles'        => array(
				'penColor' => '#111827',
				'penWidth' => 2,
			),
		);
	}

	public function get_property_schema(): array {
		return array(
			'showLabel'     => array( 'type' => 'boolean' ),
			'labelPosition' => array(
				'type'       => 'string',
				'enum'       => array( 'top', 'left' ),
				'responsive' => true,
			),
			'label'         => array( 'type' => 'string' ),
			'name'          => array( 'type' => 'field_name' ),
			'helpText'      => array( 'type' => 'string' ),
			'required'      => array( 'type' => 'boolean' ),
			'__className'   => array( 'type' => 'css_class' ),
		);
	}

	private static function typography_selector( string $el ): string {
		return "{{WRAPPER}} {$el} { font-family: {{FONT_FAMILY}}; font-size: {{FONT_SIZE}}; font-weight: {{FONT_WEIGHT}}; font-style: {{FONT_STYLE}}; text-transform: {{TEXT_TRANSFORM}}; text-decoration: {{TEXT_DECORATION}}; line-height: {{LINE_HEIGHT}}; letter-spacing: {{LETTER_SPACING}}; word-spacing: {{WORD_SPACING}}; }";
	}

	public function register_controls(): array {
		return array(
			'content' => array(
				array(
					'type'        => 'section',
					'key'         => 'content',
					'label'       => __( 'Content', 'metform-pro' ),
					'defaultOpen' => true,
				),
				array(
					'type'    => 'toggle',
					'key'     => 'showLabel',
					'label'   => __( 'Show Label', 'metform-pro' ),
					'default' => true,
				),
				array(
					'type'      => 'text',
					'key'       => 'label',
					'label'     => __( 'Label', 'metform-pro' ),
					'default'   => __( 'Signature', 'metform-pro' ),
					'condition' => array( 'showLabel!' => false ),
				),
				array(
					'type'       => 'select',
					'key'        => 'labelPosition',
					'label'      => __( 'Label Position', 'metform-pro' ),
					'default'    => 'top',
					'options'    => array(
						array(
							'label' => __( 'Top', 'metform-pro' ),
							'value' => 'top',
						),
						array(
							'label' => __( 'Left', 'metform-pro' ),
							'value' => 'left',
						),
					),
					'condition'  => array( 'showLabel!' => false ),
					'responsive' => true,
				),
				array(
					'type'  => 'text',
					'key'   => 'name',
					'label' => __( 'Name', 'metform-pro' ),
					'help'  => __( 'Name is must required. Enter name without space or any special character. use only underscore/ hyphen (_/-) for multiple word. Name must be different.', 'metform-pro' ),
				),
				array(
					'type'  => 'text',
					'key'   => 'helpText',
					'label' => __( 'Help Text', 'metform-pro' ),
					'help'  => __( 'Shown below the field to guide users', 'metform-pro' ),
				),

				array(
					'type'        => 'section',
					'key'         => 'settings',
					'label'       => __( 'Settings', 'metform-pro' ),
					'defaultOpen' => false,
				),
				array(
					'type'    => 'toggle',
					'key'     => 'required',
					'label'   => __( 'Required', 'metform-pro' ),
					'default' => false,
				),
			),
			'style'   => array(
				array(
					'type'        => 'section',
					'label'       => __( 'Label', 'metform-pro' ),
					'defaultOpen' => true,
					'condition'   => array( 'showLabel!' => false ),
				),
				array(
					'type'      => 'color',
					'key'       => 'styles.labelColor',
					'label'     => __( 'Label Color', 'metform-pro' ),
					'default'   => '#374151',
					'selector'  => '{{WRAPPER}} .mfb-label { color: {{VALUE}}; }',
					'condition' => array( 'showLabel!' => false ),
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.helpTextColor',
					'label'    => __( 'Help Text Color', 'metform-pro' ),
					'default'  => '#6b7280',
					'selector' => '{{WRAPPER}} .mfb-field__help { color: {{VALUE}}; }',
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.errorColor',
					'label'    => __( 'Error Color', 'metform-pro' ),
					'default'  => '#ef4444',
					'selector' => '{{WRAPPER}} .mfb-field__error { color: {{VALUE}}; }',
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.labelTypography',
					'label'          => __( 'Label Typography', 'metform-pro' ),
					'selector'       => self::typography_selector( '.mfb-label' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
					'condition'      => array( 'showLabel!' => false ),
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.helpTextTypography',
					'label'          => __( 'Help Text Typography', 'metform-pro' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
					'selector'       => self::typography_selector( '.mfb-field__help' ),
				),
				array(
					'type'           => 'typography',
					'key'            => 'styles.errorTypography',
					'label'          => __( 'Error Typography', 'metform-pro' ),
					'selector'       => self::typography_selector( '.mfb-field__error' ),
					'responsive'     => true,
					'responsiveKeys' => array( 'fontSize', 'lineHeight', 'letterSpacing', 'wordSpacing' ),
				),

				array(
					'type'  => 'section',
					'label' => __( 'Canvas', 'metform-pro' ),
				),
				array(
					'type'     => 'background',
					'key'      => 'styles.canvasBackground',
					'label'    => __( 'Canvas Background', 'metform-pro' ),
					'default'  => array(
						'type'  => 'classic',
						'color' => '#ffffff',
					),
					'selector' => '{{WRAPPER}} .mfb-signature__canvas { {{VALUE}} }',
				),
				array(
					'type'           => 'border',
					'key'            => 'styles.canvasBorder',
					'label'          => __( 'Canvas Border', 'metform-pro' ),
					'default'        => array(
						'borderType' => 'solid',
						'width'      => array(
							'top'    => '1px',
							'right'  => '1px',
							'bottom' => '1px',
							'left'   => '1px',
						),
						'color'      => '#d1d5db',
						'radius'     => array(
							'top'    => '6px',
							'right'  => '6px',
							'bottom' => '6px',
							'left'   => '6px',
						),
					),
					'selector'       => '{{WRAPPER}} .mfb-signature__canvas { {{VALUE}} }',
					'responsive'     => true,
					'responsiveKeys' => array( 'width', 'radius' ),
				),
				array(
					'type'       => 'range',
					'key'        => 'styles.canvasHeight',
					'label'      => __( 'Canvas Height', 'metform-pro' ),
					'default'    => '160px',
					'units'      => array( 'px' ),
					'min'        => 80,
					'max'        => 400,
					'step'       => 5,
					'selector'   => '{{WRAPPER}} .mfb-signature__canvas { height: {{VALUE}}; }',
					'responsive' => true,
				),

				array(
					'type'  => 'section',
					'label' => __( 'Pen', 'metform-pro' ),
				),
				array(
					'type'    => 'color',
					'key'     => 'styles.penColor',
					'label'   => __( 'Pen Color', 'metform-pro' ),
					'default' => '#111827',
				),
				array(
					'type'    => 'number',
					'key'     => 'styles.penWidth',
					'label'   => __( 'Pen Stroke Width', 'metform-pro' ),
					'default' => 2,
					'min'     => 1,
					'max'     => 8,
				),

				array(
					'type'  => 'section',
					'label' => __( 'Buttons', 'metform-pro' ),
				),
				array(
					'type'     => 'color',
					'key'      => 'styles.clearButtonColor',
					'label'    => __( 'Clear Button Color', 'metform-pro' ),
					'default'  => '#6b7280',
					'selector' => '{{WRAPPER}} .mfb-signature__clear { color: {{VALUE}}; }',
				),
			),
		);
	}

	public function render_markup( array $settings, Render_Context $context ): string {
		$id        = $context->get_element_id();
		$name      = (string) ( $settings['name'] ?? '' );
		$required  = ! empty( $settings['required'] );
		$pen_color = (string) ( $settings['styles']['penColor'] ?? '#111827' );
		$pen_width = (string) ( $settings['styles']['penWidth'] ?? 2 );
		$canvas_id = $id . '-canvas';

		ob_start();
		?>
		<div class="mfb-signature__wrapper">
			<?php /* data-pen-color/data-pen-width: read by src/frontend/form-builder/blocks/signature/index.js to match the canvas stroke to this block's Pen style controls (those two controls have no `selector`, by design — they're drawing parameters, not CSS — so they never reach Style_Engine at all; this is how the frontend JS module learns them instead). tabindex + id: the label's `for` points here (not the hidden input, which can never receive focus) so clicking/tapping the label at least focuses the drawable surface. */ ?>
			<canvas id="<?php echo esc_attr( $canvas_id ); ?>" class="mfb-signature__canvas" tabindex="0" role="img" aria-label="<?php esc_attr_e( 'Signature drawing area', 'metform-pro' ); ?>" data-pen-color="<?php echo esc_attr( $pen_color ); ?>" data-pen-width="<?php echo esc_attr( $pen_width ); ?>"></canvas>
			<span class="mfb-signature__placeholder"><?php esc_html_e( 'Sign here', 'metform-pro' ); ?></span>
			<?php /* Icon-only reset button, overlaid inside the pad's own corner instead of a separate text "Clear" toolbar below it. Starts `hidden` — the frontend JS module (initSignatureField/setEmpty) only reveals it once a signature actually exists, and hides it again after Clear. Inert without that module — see class doc — but a real <button>, not a decorative span, so it matches the eventual working state exactly. */ ?>
			<button type="button" class="mfb-signature__clear" aria-label="<?php esc_attr_e( 'Clear signature', 'metform-pro' ); ?>" title="<?php esc_attr_e( 'Clear signature', 'metform-pro' ); ?>" hidden>
				<svg class="mfb-signature__clear-icon" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
					<polyline points="1 4 1 10 7 10"></polyline>
					<path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"></path>
				</svg>
			</button>
		</div>
		<?php /* Carries the eventual image/png data URL under the field's real name for submission — empty until the JS module populates it. See class doc's "Known gap" for why `required` cannot be enforced on this hidden input by the browser alone. */ ?>
		<input
			type="hidden"
			id="<?php echo esc_attr( $id ); ?>"
			name="<?php echo esc_attr( $name ); ?>"
			value=""
			data-mf-signature-input
			<?php echo $required ? 'data-mf-required="1"' : ''; ?>
		>
		<?php
		return (string) ob_get_clean();
	}

	public function get_wrap_options( array $settings, Render_Context $context ): array {
		// Keep the parent's `style_class` so the wrapper carries the element
		// class every generated `{{WRAPPER}}` rule (Style + Advanced) targets.
		$opts              = parent::get_wrap_options( $settings, $context );
		$opts['label_for'] = $context->get_element_id() . '-canvas';

		return $opts;
	}
}
