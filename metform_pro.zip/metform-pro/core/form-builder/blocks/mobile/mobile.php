<?php
namespace MetForm_Pro\Core\FormBuilder\Blocks\Mobile;

use MetForm\Core\FormBuilder\Block_Base;
use MetForm\Core\FormBuilder\Rendering\Render_Context;
use MetForm\Core\FormBuilder\Shared\Input_Controls;

defined( 'ABSPATH' ) || exit;

final class Mobile extends Block_Base {
	public function get_name(): string {
		return 'mobile'; }
	public function get_title(): string {
		return __( 'Mobile', 'metform-pro' ); }
	public function get_icon(): string {
		return 'Smartphone'; }
	public function get_category(): string {
		return 'Advanced'; }

	public function get_capabilities(): array {
		return array(
			'acceptsChildren' => false,
			'isField'         => true,
		);
	}

	/**
	 * The compiled frontend/form-builder bundle handle this block needs —
	 * enqueued only when this block is actually present, via this plugin's
	 * own Base::enqueue_block_assets() (mirrors canvas.php's identical
	 * per-block loop in the free plugin, which never sees Pro blocks).
	 */
	public function get_frontend_assets(): array {
		return array( 'metform-pro-form-builder-frontend' );
	}

	public function get_default_settings(): array {
		return array_merge(
			Input_Controls::default_props( __( 'Mobile', 'metform-pro' ) ),
			array(
				'defaultCountry'    => 'US',
				'autoDetectCountry' => false,
				'allowedCountries'  => '',
				'outputFormat'      => 'phone_only',
				'countryPosition'   => 'left',
				'showFlag'          => true,
				'showDialCode'      => true,
				'placeholder'       => '555 000 0000',
				'validation'        => array(
					'type'    => 'pattern',
					'value'   => '^[0-9\\s\\-().+]{6,15}$',
					'message' => __( 'Please enter a valid phone number.', 'metform-pro' ),
				),
			)
		);
	}

	public function get_property_schema(): array {
		return array_merge(
			Input_Controls::schema(),
			array(
				'defaultCountry'    => array( 'type' => 'string' ),
				'autoDetectCountry' => array( 'type' => 'boolean' ),
				'allowedCountries'  => array( 'type' => 'string' ),
				'outputFormat'      => array(
					'type' => 'string',
					'enum' => array( 'phone_only', 'with_dial_code' ),
				),
				'countryPosition'   => array(
					'type' => 'string',
					'enum' => array( 'left', 'right' ),
				),
				'showFlag'          => array( 'type' => 'boolean' ),
				'showDialCode'      => array( 'type' => 'boolean' ),
			)
		);
	}

	/** Matches manifest.js's COUNTRY_OPTIONS: {label: "Name (+dial)", value: code}. */
	private function country_options(): array {
		$options = array();
		foreach ( Countries::all() as $c ) {
			$options[] = array(
				'label' => "{$c['name']} ({$c['dial']})",
				'value' => $c['code'],
			);
		}
		return $options;
	}

	public function register_controls(): array {
		return array(
			'content' => Input_Controls::content(
				__( 'Mobile', 'metform-pro' ),
				array(),
				true,
				null,
				array(
					array(
						'type'    => 'select',
						'key'     => 'defaultCountry',
						'label'   => __( 'Default Country', 'metform-pro' ),
						'default' => 'US',
						'options' => $this->country_options(),
						'help'    => __( 'Country shown when the form first loads.', 'metform-pro' ),
					),
					array(
						'type'    => 'toggle',
						'key'     => 'autoDetectCountry',
						'label'   => __( 'Auto-Detect Country', 'metform-pro' ),
						'default' => false,
						'help'    => __( "Automatically select the country matching the visitor's browser locale (e.g. en-US → United States). Only applies when no value has been entered yet.", 'metform-pro' ),
					),
					array(
						'type'        => 'text',
						'key'         => 'allowedCountries',
						'label'       => __( 'Allowed Countries', 'metform-pro' ),
						'default'     => '',
						'placeholder' => 'US, CA, GB, AU',
						'help'        => __( 'Comma-separated ISO codes to restrict the dropdown. Leave blank to show all countries.', 'metform-pro' ),
					),
					array(
						'type'    => 'select',
						'key'     => 'outputFormat',
						'label'   => __( 'Output Format', 'metform-pro' ),
						'default' => 'phone_only',
						'options' => array(
							array(
								'label' => __( 'Phone number only', 'metform-pro' ),
								'value' => 'phone_only',
							),
							array(
								'label' => __( 'With dial code (e.g. +1 555 123 4567)', 'metform-pro' ),
								'value' => 'with_dial_code',
							),
						),
						'help'    => __( 'Controls what gets stored in the form submission.', 'metform-pro' ),
					),
					array(
						'type'    => 'toggle',
						'key'     => 'showFlag',
						'label'   => __( 'Show Flag', 'metform-pro' ),
						'default' => true,
					),
					array(
						'type'    => 'toggle',
						'key'     => 'showDialCode',
						'label'   => __( 'Show Dial Code', 'metform-pro' ),
						'default' => true,
					),
					array(
						'type'    => 'select',
						'key'     => 'countryPosition',
						'label'   => __( 'Country Button Position', 'metform-pro' ),
						'default' => 'left',
						'options' => array(
							array(
								'label' => __( 'Left', 'metform-pro' ),
								'value' => 'left',
							),
							array(
								'label' => __( 'Right', 'metform-pro' ),
								'value' => 'right',
							),
						),
					),
				)
			),
			'style'   => Input_Controls::style(
				'input',
				array(
					array(
						'type'  => 'section',
						'label' => __( 'Country Button', 'metform-pro' ),
					),
					array(
						'type'     => 'background',
						'key'      => 'styles.countryBtnBg',
						'label'    => __( 'Button Background', 'metform-pro' ),
						'default'  => array(
							'type'  => 'classic',
							'color' => '#f9fafb',
						),
						'selector' => '{{WRAPPER}} .mfb-mobile__country-select { {{VALUE}} }',
					),
					array(
						'type'     => 'color',
						'key'      => 'styles.countryBtnColor',
						'label'    => __( 'Dial Code Color', 'metform-pro' ),
						'default'  => '#374151',
						'selector' => '{{WRAPPER}} .mfb-mobile__country-select { color: {{VALUE}}; }',
					),
					array(
						'type'     => 'color',
						'key'      => 'styles.countryBtnBorder',
						'label'    => __( 'Button Border Color', 'metform-pro' ),
						'default'  => '#d1d5db',
						'selector' => '{{WRAPPER}} .mfb-mobile__country-select { border-color: {{VALUE}}; }',
					),
				)
			),
		);
	}

	/** Builds the visible country list — respects the allowedCountries whitelist, matches index.jsx's visibleCountries useMemo. */
	private function visible_countries( string $allowed_raw ): array {
		$trimmed = trim( $allowed_raw );
		if ( '' === $trimmed ) {
			return Countries::all();
		}
		$allowed  = array_filter( array_map( static fn( string $c ) => strtoupper( trim( $c ) ), explode( ',', $trimmed ) ) );
		$filtered = array_values( array_filter( Countries::all(), static fn( array $c ) => in_array( $c['code'], $allowed, true ) ) );
		return ! empty( $filtered ) ? $filtered : Countries::all();
	}


	private function render_country_select( array $countries, array $current, string $name, string $id, bool $show_dial, string $position, bool $show_flag ): string {
		$option_html = '';
		foreach ( $countries as $c ) {
			$flag         = Countries::flag_emoji( $c['code'] );
			$label        = $show_dial ? "{$c['name']} ({$c['dial']})" : $c['name'];
			$option_html .= sprintf(
				'<option value="%1$s" data-dial="%2$s" data-flag="%3$s" data-name="%4$s" %5$s>%6$s</option>',
				esc_attr( $c['code'] ),
				esc_attr( $c['dial'] ),
				esc_attr( $flag ),
				esc_attr( $c['name'] ),
				$c['code'] === $current['code'] ? 'selected' : '',
				esc_html( $label )
			);
		}
		$select = sprintf(
			'<select id="%1$s" name="%2$s_country" class="mfb-mobile__country-select%3$s%6$s" aria-label="%4$s" data-search-placeholder="%7$s" data-no-results-text="%8$s">%5$s</select>',
			esc_attr( $id ),
			esc_attr( $name ),
			$show_flag ? ' mfb-mobile__country-select--has-flag' : '',
			esc_attr( __( 'Country code', 'metform-pro' ) ),
			$option_html, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			$show_dial ? ' mfb-mobile__country-select--has-dial' : '',
			esc_attr( __( 'Search', 'metform-pro' ) ),
			esc_attr( __( 'No countries found', 'metform-pro' ) )
		);

		if ( ! $show_flag ) {
			return sprintf( '<span class="mfb-mobile__country-wrap%1$s">%2$s</span>', 'right' === $position ? ' mfb-mobile--right' : '', $select ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		$flag_overlay = sprintf(
			'<span class="mfb-mobile__flag" data-mf-mobile-flag aria-hidden="true">%s</span>',
			esc_html( Countries::flag_emoji( $current['code'] ) )
		);

		return sprintf(
			'<span class="mfb-mobile__country-wrap%1$s">%2$s%3$s</span>',
			'right' === $position ? ' mfb-mobile--right' : '',
			$flag_overlay, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			$select // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		);
	}

	public function render_markup( array $settings, Render_Context $context ): string {
		$id               = $context->get_element_id();
		$name             = (string) ( $settings['name'] ?? '' );
		$position         = 'right' === ( $settings['countryPosition'] ?? 'left' ) ? 'right' : 'left';
		$show_dial        = false !== ( $settings['showDialCode'] ?? true );
		$show_flag        = false !== ( $settings['showFlag'] ?? true );
		$auto_detect      = ! empty( $settings['autoDetectCountry'] );
		$validation_attrs = Input_Controls::validation_attributes( $settings );

		$visible      = $this->visible_countries( (string) ( $settings['allowedCountries'] ?? '' ) );
		$default_code = (string) ( $settings['defaultCountry'] ?: 'US' );
		$current      = null;
		foreach ( $visible as $c ) {
			if ( $c['code'] === $default_code ) {
				$current = $c;
				break;
			}
		}
		if ( null === $current ) {
			$current = $visible[0] ?? Countries::find( 'US' );
		}

		$country_select = $this->render_country_select( $visible, $current, $name, $id . '-country', $show_dial, $position, $show_flag );
		$with_dial_code = 'with_dial_code' === ( $settings['outputFormat'] ?? 'phone_only' );
		$default_local  = (string) ( $settings['defaultValue'] ?? '' );

		// Dial code now renders as real, editable text baked directly into the
		// phone field's own value (e.g. "+216 555 000 0000") instead of the
		// country button, which shows only the flag, or a decorative overlay
		// span. index.js swaps the leading "<dial> " text for the new one
		// whenever the country changes, without touching whatever the visitor
		// already typed after it (see syncDialValue() / data-mf-dial-code).
		$field_value = $show_dial ? trim( $current['dial'] . ' ' . $default_local ) : $default_local;

		$phone_input = sprintf(
			'<input id="%1$s" type="tel" name="%2$s" class="mfb-field__input mfb-mobile__phone-input%3$s" value="%4$s" placeholder="%5$s" autocomplete="tel-national" %6$s%7$s%8$s>',
			esc_attr( $id ),
			esc_attr( $with_dial_code ? $name . '--local' : $name ),
			'right' === $position ? ' mfb-mobile--right' : '',
			esc_attr( $field_value ),
			esc_attr( (string) ( $settings['placeholder'] ?: '555 000 0000' ) ),
			$validation_attrs, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			$with_dial_code ? ' data-mf-mobile-local' : '',
			$show_dial ? sprintf( ' data-mf-dial-code="%s"', esc_attr( $current['dial'] ) ) : ''
		);

		$combined_field = $with_dial_code
			? sprintf(
				'<input type="hidden" name="%1$s" class="mfb-mobile__combined" value="%2$s">',
				esc_attr( $name ),
				esc_attr( '' !== trim( $default_local ) ? trim( $current['dial'] . ' ' . $default_local ) : '' )
			)
			: '';

		return sprintf(
			'<div class="mfb-mobile__input-wrap"%1$s>%2$s%3$s</div>',
			$auto_detect ? ' data-mf-mobile-autodetect="1"' : '',
			'right' === $position ? ( $phone_input . $country_select ) : ( $country_select . $phone_input ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			$combined_field // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		);
	}
}
