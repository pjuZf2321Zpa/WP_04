<?php
namespace MetForm_Pro\Core\FormBuilder\Blocks\Mobile;

defined( 'ABSPATH' ) || exit;

final class Countries {
	/** @return array<int, array{code: string, name: string, dial: string}> */
	public static function all(): array {
		return array(
			array(
				'code' => 'US',
				'name' => 'United States',
				'dial' => '+1',
			),
			array(
				'code' => 'GB',
				'name' => 'United Kingdom',
				'dial' => '+44',
			),
			array(
				'code' => 'CA',
				'name' => 'Canada',
				'dial' => '+1',
			),
			array(
				'code' => 'AU',
				'name' => 'Australia',
				'dial' => '+61',
			),
			array(
				'code' => 'IN',
				'name' => 'India',
				'dial' => '+91',
			),
			array(
				'code' => 'DE',
				'name' => 'Germany',
				'dial' => '+49',
			),
			array(
				'code' => 'FR',
				'name' => 'France',
				'dial' => '+33',
			),
			array(
				'code' => 'JP',
				'name' => 'Japan',
				'dial' => '+81',
			),
			array(
				'code' => 'BR',
				'name' => 'Brazil',
				'dial' => '+55',
			),
			array(
				'code' => 'MX',
				'name' => 'Mexico',
				'dial' => '+52',
			),
			array(
				'code' => 'KR',
				'name' => 'South Korea',
				'dial' => '+82',
			),
			array(
				'code' => 'CN',
				'name' => 'China',
				'dial' => '+86',
			),
			array(
				'code' => 'AF',
				'name' => 'Afghanistan',
				'dial' => '+93',
			),
			array(
				'code' => 'AL',
				'name' => 'Albania',
				'dial' => '+355',
			),
			array(
				'code' => 'DZ',
				'name' => 'Algeria',
				'dial' => '+213',
			),
			array(
				'code' => 'AS',
				'name' => 'American Samoa',
				'dial' => '+1-684',
			),
			array(
				'code' => 'AD',
				'name' => 'Andorra',
				'dial' => '+376',
			),
			array(
				'code' => 'AO',
				'name' => 'Angola',
				'dial' => '+244',
			),
			array(
				'code' => 'AI',
				'name' => 'Anguilla',
				'dial' => '+1-264',
			),
			array(
				'code' => 'AG',
				'name' => 'Antigua and Barbuda',
				'dial' => '+1-268',
			),
			array(
				'code' => 'AR',
				'name' => 'Argentina',
				'dial' => '+54',
			),
			array(
				'code' => 'AM',
				'name' => 'Armenia',
				'dial' => '+374',
			),
			array(
				'code' => 'AW',
				'name' => 'Aruba',
				'dial' => '+297',
			),
			array(
				'code' => 'AT',
				'name' => 'Austria',
				'dial' => '+43',
			),
			array(
				'code' => 'AZ',
				'name' => 'Azerbaijan',
				'dial' => '+994',
			),
			array(
				'code' => 'BS',
				'name' => 'Bahamas',
				'dial' => '+1-242',
			),
			array(
				'code' => 'BH',
				'name' => 'Bahrain',
				'dial' => '+973',
			),
			array(
				'code' => 'BD',
				'name' => 'Bangladesh',
				'dial' => '+880',
			),
			array(
				'code' => 'BB',
				'name' => 'Barbados',
				'dial' => '+1-246',
			),
			array(
				'code' => 'BY',
				'name' => 'Belarus',
				'dial' => '+375',
			),
			array(
				'code' => 'BE',
				'name' => 'Belgium',
				'dial' => '+32',
			),
			array(
				'code' => 'BZ',
				'name' => 'Belize',
				'dial' => '+501',
			),
			array(
				'code' => 'BJ',
				'name' => 'Benin',
				'dial' => '+229',
			),
			array(
				'code' => 'BM',
				'name' => 'Bermuda',
				'dial' => '+1-441',
			),
			array(
				'code' => 'BT',
				'name' => 'Bhutan',
				'dial' => '+975',
			),
			array(
				'code' => 'BO',
				'name' => 'Bolivia',
				'dial' => '+591',
			),
			array(
				'code' => 'BQ',
				'name' => 'Bonaire',
				'dial' => '+599',
			),
			array(
				'code' => 'BA',
				'name' => 'Bosnia and Herzegovina',
				'dial' => '+387',
			),
			array(
				'code' => 'BW',
				'name' => 'Botswana',
				'dial' => '+267',
			),
			array(
				'code' => 'IO',
				'name' => 'British Indian Ocean Ter.',
				'dial' => '+246',
			),
			array(
				'code' => 'VG',
				'name' => 'British Virgin Islands',
				'dial' => '+1-284',
			),
			array(
				'code' => 'BN',
				'name' => 'Brunei',
				'dial' => '+673',
			),
			array(
				'code' => 'BG',
				'name' => 'Bulgaria',
				'dial' => '+359',
			),
			array(
				'code' => 'BF',
				'name' => 'Burkina Faso',
				'dial' => '+226',
			),
			array(
				'code' => 'BI',
				'name' => 'Burundi',
				'dial' => '+257',
			),
			array(
				'code' => 'KH',
				'name' => 'Cambodia',
				'dial' => '+855',
			),
			array(
				'code' => 'CM',
				'name' => 'Cameroon',
				'dial' => '+237',
			),
			array(
				'code' => 'CV',
				'name' => 'Cape Verde',
				'dial' => '+238',
			),
			array(
				'code' => 'KY',
				'name' => 'Cayman Islands',
				'dial' => '+1-345',
			),
			array(
				'code' => 'CF',
				'name' => 'Central African Republic',
				'dial' => '+236',
			),
			array(
				'code' => 'TD',
				'name' => 'Chad',
				'dial' => '+235',
			),
			array(
				'code' => 'CL',
				'name' => 'Chile',
				'dial' => '+56',
			),
			array(
				'code' => 'CI',
				'name' => 'Ivory Coast',
				'dial' => '+225',
			),
			array(
				'code' => 'CK',
				'name' => 'Cook Islands',
				'dial' => '+682',
			),
			array(
				'code' => 'CO',
				'name' => 'Colombia',
				'dial' => '+57',
			),
			array(
				'code' => 'KM',
				'name' => 'Comoros',
				'dial' => '+269',
			),
			array(
				'code' => 'CG',
				'name' => 'Congo (Republic)',
				'dial' => '+242',
			),
			array(
				'code' => 'CD',
				'name' => 'Congo (Dem. Republic)',
				'dial' => '+243',
			),
			array(
				'code' => 'CR',
				'name' => 'Costa Rica',
				'dial' => '+506',
			),
			array(
				'code' => 'HR',
				'name' => 'Croatia',
				'dial' => '+385',
			),
			array(
				'code' => 'CU',
				'name' => 'Cuba',
				'dial' => '+53',
			),
			array(
				'code' => 'CW',
				'name' => 'Curacao',
				'dial' => '+599',
			),
			array(
				'code' => 'CY',
				'name' => 'Cyprus',
				'dial' => '+357',
			),
			array(
				'code' => 'CZ',
				'name' => 'Czech Republic',
				'dial' => '+420',
			),
			array(
				'code' => 'DK',
				'name' => 'Denmark',
				'dial' => '+45',
			),
			array(
				'code' => 'DJ',
				'name' => 'Djibouti',
				'dial' => '+253',
			),
			array(
				'code' => 'DM',
				'name' => 'Dominica',
				'dial' => '+1-767',
			),
			array(
				'code' => 'DO',
				'name' => 'Dominican Republic',
				'dial' => '+1-809',
			),
			array(
				'code' => 'TL',
				'name' => 'East Timor',
				'dial' => '+670',
			),
			array(
				'code' => 'EC',
				'name' => 'Ecuador',
				'dial' => '+593',
			),
			array(
				'code' => 'EG',
				'name' => 'Egypt',
				'dial' => '+20',
			),
			array(
				'code' => 'SV',
				'name' => 'El Salvador',
				'dial' => '+503',
			),
			array(
				'code' => 'GQ',
				'name' => 'Equatorial Guinea',
				'dial' => '+240',
			),
			array(
				'code' => 'ER',
				'name' => 'Eritrea',
				'dial' => '+291',
			),
			array(
				'code' => 'EE',
				'name' => 'Estonia',
				'dial' => '+372',
			),
			array(
				'code' => 'ET',
				'name' => 'Ethiopia',
				'dial' => '+251',
			),
			array(
				'code' => 'FK',
				'name' => 'Falkland Islands',
				'dial' => '+500',
			),
			array(
				'code' => 'FO',
				'name' => 'Faroe Islands',
				'dial' => '+298',
			),
			array(
				'code' => 'FJ',
				'name' => 'Fiji',
				'dial' => '+679',
			),
			array(
				'code' => 'FI',
				'name' => 'Finland',
				'dial' => '+358',
			),
			array(
				'code' => 'GF',
				'name' => 'French Guiana',
				'dial' => '+594',
			),
			array(
				'code' => 'PF',
				'name' => 'French Polynesia',
				'dial' => '+689',
			),
			array(
				'code' => 'GA',
				'name' => 'Gabon',
				'dial' => '+241',
			),
			array(
				'code' => 'GM',
				'name' => 'Gambia',
				'dial' => '+220',
			),
			array(
				'code' => 'GE',
				'name' => 'Georgia',
				'dial' => '+995',
			),
			array(
				'code' => 'GH',
				'name' => 'Ghana',
				'dial' => '+233',
			),
			array(
				'code' => 'GI',
				'name' => 'Gibraltar',
				'dial' => '+350',
			),
			array(
				'code' => 'GL',
				'name' => 'Greenland',
				'dial' => '+299',
			),
			array(
				'code' => 'GD',
				'name' => 'Grenada',
				'dial' => '+1-473',
			),
			array(
				'code' => 'GP',
				'name' => 'Guadeloupe',
				'dial' => '+590',
			),
			array(
				'code' => 'GU',
				'name' => 'Guam',
				'dial' => '+1-671',
			),
			array(
				'code' => 'GT',
				'name' => 'Guatemala',
				'dial' => '+502',
			),
			array(
				'code' => 'GG',
				'name' => 'Guernsey',
				'dial' => '+44-1481',
			),
			array(
				'code' => 'GN',
				'name' => 'Guinea',
				'dial' => '+224',
			),
			array(
				'code' => 'GW',
				'name' => 'Guinea-Bissau',
				'dial' => '+245',
			),
			array(
				'code' => 'GY',
				'name' => 'Guyana',
				'dial' => '+592',
			),
			array(
				'code' => 'HT',
				'name' => 'Haiti',
				'dial' => '+509',
			),
			array(
				'code' => 'HN',
				'name' => 'Honduras',
				'dial' => '+504',
			),
			array(
				'code' => 'HK',
				'name' => 'Hong Kong',
				'dial' => '+852',
			),
			array(
				'code' => 'HU',
				'name' => 'Hungary',
				'dial' => '+36',
			),
			array(
				'code' => 'IS',
				'name' => 'Iceland',
				'dial' => '+354',
			),
			array(
				'code' => 'ID',
				'name' => 'Indonesia',
				'dial' => '+62',
			),
			array(
				'code' => 'IR',
				'name' => 'Iran',
				'dial' => '+98',
			),
			array(
				'code' => 'IQ',
				'name' => 'Iraq',
				'dial' => '+964',
			),
			array(
				'code' => 'IE',
				'name' => 'Ireland',
				'dial' => '+353',
			),
			array(
				'code' => 'IM',
				'name' => 'Isle of Man',
				'dial' => '+44-1624',
			),
			array(
				'code' => 'IL',
				'name' => 'Israel',
				'dial' => '+972',
			),
			array(
				'code' => 'IT',
				'name' => 'Italy',
				'dial' => '+39',
			),
			array(
				'code' => 'JM',
				'name' => 'Jamaica',
				'dial' => '+1-876',
			),
			array(
				'code' => 'JE',
				'name' => 'Jersey',
				'dial' => '+44-1534',
			),
			array(
				'code' => 'JO',
				'name' => 'Jordan',
				'dial' => '+962',
			),
			array(
				'code' => 'KZ',
				'name' => 'Kazakhstan',
				'dial' => '+7',
			),
			array(
				'code' => 'KE',
				'name' => 'Kenya',
				'dial' => '+254',
			),
			array(
				'code' => 'KI',
				'name' => 'Kiribati',
				'dial' => '+686',
			),
			array(
				'code' => 'KW',
				'name' => 'Kuwait',
				'dial' => '+965',
			),
			array(
				'code' => 'KG',
				'name' => 'Kyrgyzstan',
				'dial' => '+996',
			),
			array(
				'code' => 'LA',
				'name' => 'Laos',
				'dial' => '+856',
			),
			array(
				'code' => 'LV',
				'name' => 'Latvia',
				'dial' => '+371',
			),
			array(
				'code' => 'LB',
				'name' => 'Lebanon',
				'dial' => '+961',
			),
			array(
				'code' => 'LS',
				'name' => 'Lesotho',
				'dial' => '+266',
			),
			array(
				'code' => 'LR',
				'name' => 'Liberia',
				'dial' => '+231',
			),
			array(
				'code' => 'LY',
				'name' => 'Libya',
				'dial' => '+218',
			),
			array(
				'code' => 'LI',
				'name' => 'Liechtenstein',
				'dial' => '+423',
			),
			array(
				'code' => 'LT',
				'name' => 'Lithuania',
				'dial' => '+370',
			),
			array(
				'code' => 'LU',
				'name' => 'Luxembourg',
				'dial' => '+352',
			),
			array(
				'code' => 'MO',
				'name' => 'Macao',
				'dial' => '+853',
			),
			array(
				'code' => 'MG',
				'name' => 'Madagascar',
				'dial' => '+261',
			),
			array(
				'code' => 'MW',
				'name' => 'Malawi',
				'dial' => '+265',
			),
			array(
				'code' => 'MY',
				'name' => 'Malaysia',
				'dial' => '+60',
			),
			array(
				'code' => 'MV',
				'name' => 'Maldives',
				'dial' => '+960',
			),
			array(
				'code' => 'ML',
				'name' => 'Mali',
				'dial' => '+223',
			),
			array(
				'code' => 'MT',
				'name' => 'Malta',
				'dial' => '+356',
			),
			array(
				'code' => 'MH',
				'name' => 'Marshall Islands',
				'dial' => '+692',
			),
			array(
				'code' => 'MQ',
				'name' => 'Martinique',
				'dial' => '+596',
			),
			array(
				'code' => 'MR',
				'name' => 'Mauritania',
				'dial' => '+222',
			),
			array(
				'code' => 'MU',
				'name' => 'Mauritius',
				'dial' => '+230',
			),
			array(
				'code' => 'YT',
				'name' => 'Mayotte',
				'dial' => '+262',
			),
			array(
				'code' => 'FM',
				'name' => 'Micronesia',
				'dial' => '+691',
			),
			array(
				'code' => 'MD',
				'name' => 'Moldova',
				'dial' => '+373',
			),
			array(
				'code' => 'MC',
				'name' => 'Monaco',
				'dial' => '+377',
			),
			array(
				'code' => 'MN',
				'name' => 'Mongolia',
				'dial' => '+976',
			),
			array(
				'code' => 'ME',
				'name' => 'Montenegro',
				'dial' => '+382',
			),
			array(
				'code' => 'MS',
				'name' => 'Montserrat',
				'dial' => '+1-664',
			),
			array(
				'code' => 'MA',
				'name' => 'Morocco',
				'dial' => '+212',
			),
			array(
				'code' => 'MZ',
				'name' => 'Mozambique',
				'dial' => '+258',
			),
			array(
				'code' => 'MM',
				'name' => 'Myanmar',
				'dial' => '+95',
			),
			array(
				'code' => 'NA',
				'name' => 'Namibia',
				'dial' => '+264',
			),
			array(
				'code' => 'NR',
				'name' => 'Nauru',
				'dial' => '+674',
			),
			array(
				'code' => 'NP',
				'name' => 'Nepal',
				'dial' => '+977',
			),
			array(
				'code' => 'NL',
				'name' => 'Netherlands',
				'dial' => '+31',
			),
			array(
				'code' => 'NC',
				'name' => 'New Caledonia',
				'dial' => '+687',
			),
			array(
				'code' => 'NZ',
				'name' => 'New Zealand',
				'dial' => '+64',
			),
			array(
				'code' => 'NI',
				'name' => 'Nicaragua',
				'dial' => '+505',
			),
			array(
				'code' => 'NE',
				'name' => 'Niger',
				'dial' => '+227',
			),
			array(
				'code' => 'NG',
				'name' => 'Nigeria',
				'dial' => '+234',
			),
			array(
				'code' => 'NU',
				'name' => 'Niue',
				'dial' => '+683',
			),
			array(
				'code' => 'NF',
				'name' => 'Norfolk Island',
				'dial' => '+672',
			),
			array(
				'code' => 'KP',
				'name' => 'North Korea',
				'dial' => '+850',
			),
			array(
				'code' => 'MP',
				'name' => 'Northern Mariana Islands',
				'dial' => '+1-670',
			),
			array(
				'code' => 'NO',
				'name' => 'Norway',
				'dial' => '+47',
			),
			array(
				'code' => 'OM',
				'name' => 'Oman',
				'dial' => '+968',
			),
			array(
				'code' => 'PK',
				'name' => 'Pakistan',
				'dial' => '+92',
			),
			array(
				'code' => 'PW',
				'name' => 'Palau',
				'dial' => '+680',
			),
			array(
				'code' => 'PS',
				'name' => 'Palestinian Territory',
				'dial' => '+970',
			),
			array(
				'code' => 'PA',
				'name' => 'Panama',
				'dial' => '+507',
			),
			array(
				'code' => 'PG',
				'name' => 'Papua New Guinea',
				'dial' => '+675',
			),
			array(
				'code' => 'PY',
				'name' => 'Paraguay',
				'dial' => '+595',
			),
			array(
				'code' => 'PE',
				'name' => 'Peru',
				'dial' => '+51',
			),
			array(
				'code' => 'PH',
				'name' => 'Philippines',
				'dial' => '+63',
			),
			array(
				'code' => 'PN',
				'name' => 'Pitcairn',
				'dial' => '+870',
			),
			array(
				'code' => 'PL',
				'name' => 'Poland',
				'dial' => '+48',
			),
			array(
				'code' => 'PT',
				'name' => 'Portugal',
				'dial' => '+351',
			),
			array(
				'code' => 'PR',
				'name' => 'Puerto Rico',
				'dial' => '+1-787',
			),
			array(
				'code' => 'QA',
				'name' => 'Qatar',
				'dial' => '+974',
			),
			array(
				'code' => 'RE',
				'name' => 'Reunion',
				'dial' => '+262',
			),
			array(
				'code' => 'RO',
				'name' => 'Romania',
				'dial' => '+40',
			),
			array(
				'code' => 'RU',
				'name' => 'Russia',
				'dial' => '+7',
			),
			array(
				'code' => 'RW',
				'name' => 'Rwanda',
				'dial' => '+250',
			),
			array(
				'code' => 'BL',
				'name' => 'Saint Barthelemy',
				'dial' => '+590',
			),
			array(
				'code' => 'SH',
				'name' => 'Saint Helena',
				'dial' => '+290',
			),
			array(
				'code' => 'KN',
				'name' => 'Saint Kitts and Nevis',
				'dial' => '+1-869',
			),
			array(
				'code' => 'LC',
				'name' => 'Saint Lucia',
				'dial' => '+1-758',
			),
			array(
				'code' => 'MF',
				'name' => 'Saint Martin',
				'dial' => '+590',
			),
			array(
				'code' => 'PM',
				'name' => 'Saint Pierre and Miquelon',
				'dial' => '+508',
			),
			array(
				'code' => 'VC',
				'name' => 'Saint Vincent',
				'dial' => '+1-784',
			),
			array(
				'code' => 'WS',
				'name' => 'Samoa',
				'dial' => '+685',
			),
			array(
				'code' => 'SM',
				'name' => 'San Marino',
				'dial' => '+378',
			),
			array(
				'code' => 'ST',
				'name' => 'Sao Tome and Principe',
				'dial' => '+239',
			),
			array(
				'code' => 'SA',
				'name' => 'Saudi Arabia',
				'dial' => '+966',
			),
			array(
				'code' => 'SN',
				'name' => 'Senegal',
				'dial' => '+221',
			),
			array(
				'code' => 'RS',
				'name' => 'Serbia',
				'dial' => '+381',
			),
			array(
				'code' => 'SC',
				'name' => 'Seychelles',
				'dial' => '+248',
			),
			array(
				'code' => 'SL',
				'name' => 'Sierra Leone',
				'dial' => '+232',
			),
			array(
				'code' => 'SG',
				'name' => 'Singapore',
				'dial' => '+65',
			),
			array(
				'code' => 'SX',
				'name' => 'Sint Maarten',
				'dial' => '+599',
			),
			array(
				'code' => 'SK',
				'name' => 'Slovakia',
				'dial' => '+421',
			),
			array(
				'code' => 'SI',
				'name' => 'Slovenia',
				'dial' => '+386',
			),
			array(
				'code' => 'SB',
				'name' => 'Solomon Islands',
				'dial' => '+677',
			),
			array(
				'code' => 'SO',
				'name' => 'Somalia',
				'dial' => '+252',
			),
			array(
				'code' => 'ZA',
				'name' => 'South Africa',
				'dial' => '+27',
			),
			array(
				'code' => 'SS',
				'name' => 'South Sudan',
				'dial' => '+211',
			),
			array(
				'code' => 'ES',
				'name' => 'Spain',
				'dial' => '+34',
			),
			array(
				'code' => 'LK',
				'name' => 'Sri Lanka',
				'dial' => '+94',
			),
			array(
				'code' => 'SD',
				'name' => 'Sudan',
				'dial' => '+249',
			),
			array(
				'code' => 'SR',
				'name' => 'Suriname',
				'dial' => '+597',
			),
			array(
				'code' => 'SJ',
				'name' => 'Svalbard and Jan Mayen',
				'dial' => '+47',
			),
			array(
				'code' => 'SZ',
				'name' => 'Swaziland',
				'dial' => '+268',
			),
			array(
				'code' => 'SE',
				'name' => 'Sweden',
				'dial' => '+46',
			),
			array(
				'code' => 'CH',
				'name' => 'Switzerland',
				'dial' => '+41',
			),
			array(
				'code' => 'SY',
				'name' => 'Syria',
				'dial' => '+963',
			),
			array(
				'code' => 'TW',
				'name' => 'Taiwan',
				'dial' => '+886',
			),
			array(
				'code' => 'TJ',
				'name' => 'Tajikistan',
				'dial' => '+992',
			),
			array(
				'code' => 'TZ',
				'name' => 'Tanzania',
				'dial' => '+255',
			),
			array(
				'code' => 'TH',
				'name' => 'Thailand',
				'dial' => '+66',
			),
			array(
				'code' => 'TG',
				'name' => 'Togo',
				'dial' => '+228',
			),
			array(
				'code' => 'TK',
				'name' => 'Tokelau',
				'dial' => '+690',
			),
			array(
				'code' => 'TO',
				'name' => 'Tonga',
				'dial' => '+676',
			),
			array(
				'code' => 'TT',
				'name' => 'Trinidad and Tobago',
				'dial' => '+1-868',
			),
			array(
				'code' => 'TN',
				'name' => 'Tunisia',
				'dial' => '+216',
			),
			array(
				'code' => 'TR',
				'name' => 'Turkey',
				'dial' => '+90',
			),
			array(
				'code' => 'TM',
				'name' => 'Turkmenistan',
				'dial' => '+993',
			),
			array(
				'code' => 'TC',
				'name' => 'Turks and Caicos Islands',
				'dial' => '+1-649',
			),
			array(
				'code' => 'TV',
				'name' => 'Tuvalu',
				'dial' => '+688',
			),
			array(
				'code' => 'UG',
				'name' => 'Uganda',
				'dial' => '+256',
			),
			array(
				'code' => 'UA',
				'name' => 'Ukraine',
				'dial' => '+380',
			),
			array(
				'code' => 'AE',
				'name' => 'United Arab Emirates',
				'dial' => '+971',
			),
			array(
				'code' => 'UY',
				'name' => 'Uruguay',
				'dial' => '+598',
			),
			array(
				'code' => 'UZ',
				'name' => 'Uzbekistan',
				'dial' => '+998',
			),
			array(
				'code' => 'VU',
				'name' => 'Vanuatu',
				'dial' => '+678',
			),
			array(
				'code' => 'VA',
				'name' => 'Vatican',
				'dial' => '+379',
			),
			array(
				'code' => 'VE',
				'name' => 'Venezuela',
				'dial' => '+58',
			),
			array(
				'code' => 'VN',
				'name' => 'Vietnam',
				'dial' => '+84',
			),
			array(
				'code' => 'VI',
				'name' => 'U.S. Virgin Islands',
				'dial' => '+1-340',
			),
			array(
				'code' => 'WF',
				'name' => 'Wallis and Futuna',
				'dial' => '+681',
			),
			array(
				'code' => 'EH',
				'name' => 'Western Sahara',
				'dial' => '+212',
			),
			array(
				'code' => 'YE',
				'name' => 'Yemen',
				'dial' => '+967',
			),
			array(
				'code' => 'ZM',
				'name' => 'Zambia',
				'dial' => '+260',
			),
			array(
				'code' => 'ZW',
				'name' => 'Zimbabwe',
				'dial' => '+263',
			),
		);
	}

	/** Matches countries.js's findCountry(): the named country, or the first in the list as a fallback. */
	public static function find( string $code ): array {
		foreach ( self::all() as $c ) {
			if ( $c['code'] === $code ) {
				return $c;
			}
		}
		$all = self::all();
		return $all[0];
	}

	public static function flag_emoji( string $code ): string {
		$code = strtoupper( trim( $code ) );
		if ( 2 !== strlen( $code ) || ! ctype_alpha( $code ) ) {
			return '';
		}
		$flag = '';
		foreach ( str_split( $code ) as $letter ) {
			$flag .= mb_chr( 0x1F1E6 + ( ord( $letter ) - 65 ), 'UTF-8' );
		}
		return $flag;
	}
}
