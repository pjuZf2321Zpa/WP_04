<?php
/**
 * Class to Build the Helper
 */

namespace KadenceWP\KadenceBlocksPro\Uplink;

/**
 * Class to Build the Helper.
 *
 * @package Kadence Blocks
 */
class Helper {
	/**
	 * The Helper data
	 * 
	 * @var string Helper data
	 */
	const DATA = '7fae5de142a2368d4217ab14844958fec6e5de94';
}
