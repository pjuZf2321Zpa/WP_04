<?php declare( strict_types=1 );

namespace KadenceWP\KadenceBlocksPro\Contracts;

use KadenceWP\KadenceBlocksPro\Container;

/**
 * Providers should extend this abstract in order to have access to the
 * container instance to register their bindings/hooks.
 *
 * @since 2.8.20
 */
abstract class Provider {

	/**
	 * @var Container
	 */
	protected Container $container;

	/**
	 * @since 2.8.20
	 *
	 * @param Container $container
	 */
	public function __construct( Container $container ) {
		$this->container = $container;
	}

	/**
	 * Registers the provider's hooks/bindings.
	 *
	 * @since 2.8.20
	 *
	 * @return void
	 */
	abstract public function register(): void;
}
