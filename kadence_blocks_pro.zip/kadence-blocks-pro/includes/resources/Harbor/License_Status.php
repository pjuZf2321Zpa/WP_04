<?php declare( strict_types=1 );

namespace KadenceWP\KadenceBlocksPro\Harbor;

use KadenceWP\KadenceBlocksPro\Harbor\Contracts\License_Source;
use KadenceWP\KadenceBlocksPro\Harbor\Licensing\Legacy_License_Source;
use KadenceWP\KadenceBlocksPro\Harbor\Licensing\Unified_License_Source;

/**
 * Resolves the active license source for admin UI and key lookups.
 *
 * Resolution rules:
 * 1. Legacy (Kadence) active → Legacy source
 * 2. Unified active → Unified source
 * 3. Neither active → Unified source (default entry / inactive UI)
 * 4. Both active → Legacy source (Kadence preferred)
 *
 * @since 2.8.20
 */
final class License_Status {

	/**
	 * Legacy license source.
	 *
	 * @var License_Source
	 */
	private License_Source $legacy;

	/**
	 * Unified license source.
	 *
	 * @var License_Source
	 */
	private License_Source $unified;

	/**
	 * Presenter that maps a resolved source into the UI status payload.
	 *
	 * @var License_Status_Presenter
	 */
	private License_Status_Presenter $presenter;

	/**
	 * Constructor.
	 *
	 * @since 2.8.20
	 *
	 * @param Legacy_License_Source    $legacy    Legacy source.
	 * @param Unified_License_Source   $unified   Unified source.
	 * @param License_Status_Presenter $presenter UI status presenter.
	 */
	public function __construct( Legacy_License_Source $legacy, Unified_License_Source $unified, License_Status_Presenter $presenter ) {
		$this->legacy    = $legacy;
		$this->unified   = $unified;
		$this->presenter = $presenter;
	}

	/**
	 * Resolve the license source using the preference rules above.
	 *
	 * Always returns a source. When neither license is active, returns the
	 * unified source so the inactive UI defaults to the unified entry flow,
	 * unless Harbor is not available.
	 *
	 * @since 2.8.20
	 *
	 * @return License_Source
	 */
	public function resolve(): License_Source {
		// Kadence wins whenever it is active (including when both are), or when Harbor is not available.
		if ( $this->legacy->is_active() || ! function_exists( 'lw_harbor_get_product_activation_base_url' ) ) {
			return $this->legacy;
		}

		// Unified when it is active, also unified is the default.
		return $this->unified;
	}

	/**
	 * Get the unified Harbor license key when the Kadence product is active.
	 *
	 * Independent of source preference — always reads the unified key.
	 *
	 * @since 2.8.20
	 *
	 * @return string The unified license key, or an empty string if not found.
	 */
	public function get_unified_key(): string {
		if ( ! function_exists( 'lw_harbor_get_product_activation_base_url' ) ) {
			return '';
		}

		return $this->unified->get_key();
	}

	/**
	 * License status payload for the settings sidebar UI.
	 *
	 * @since 2.8.20
	 *
	 * @return array{
	 *     type: 'none'|'unified'|'kadence',
	 *     maskedKey: string,
	 *     fullKey: string,
	 *     expires: string,
	 *     manageUrl: string
	 * }
	 */
	public function get_ui_status(): array {
		return $this->presenter->present( $this->resolve() );
	}
}
