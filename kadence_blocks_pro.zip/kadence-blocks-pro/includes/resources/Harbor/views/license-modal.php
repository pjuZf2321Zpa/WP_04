<?php declare( strict_types=1 );

namespace KadenceWP\KadenceBlocksPro\Harbor;

use function KadenceWP\KadenceBlocks\StellarWP\Uplink\get_license_field;

/**
 * Admin license modal sidebar view.
 *
 * @package Kadence Blocks Pro
 *
 * @var string $product_slug The product slug for legacy license field rendering.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="license-section sidebar-section components-panel">
	<div class="components-panel__body is-opened">
		<div id="kt-license-modal-root" class="kt-license-modal-root" aria-busy="true">
			<div class="kt-skeleton kt-license-skeleton" role="status" aria-label="<?php esc_attr_e( 'Loading license…', 'kadence-blocks-pro' ); ?>">
				<div class="kt-skeleton__row kt-license-skeleton__header">
					<span class="kt-skeleton__bone kt-license-skeleton__title"></span>
				</div>
				<span class="kt-skeleton__bone kt-license-skeleton__badge"></span>
				<span class="kt-skeleton__bone kt-license-skeleton__type"></span>
				<span class="kt-skeleton__bone kt-license-skeleton__key"></span>
				<span class="kt-skeleton__bone kt-license-skeleton__meta"></span>
				<span class="kt-skeleton__bone kt-license-skeleton__button"></span>
			</div>
		</div>
	</div>
</div>
<div id="kt-legacy-license-field" hidden>
	<?php
	if ( function_exists( '\\KadenceWP\\KadenceBlocks\\StellarWP\\Uplink\\get_license_field' ) ) {
		get_license_field()->render_single( $product_slug, false, true );
	}
	?>
</div>
