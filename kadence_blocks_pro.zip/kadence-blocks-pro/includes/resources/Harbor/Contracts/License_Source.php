<?php declare( strict_types=1 );

namespace KadenceWP\KadenceBlocksPro\Harbor\Contracts;

/**
 * A source of license data (Kadence Uplink or Harbor unified).
 *
 * @since 2.8.20
 */
interface License_Source {

	/**
	 * Whether this license type is currently active/authorized.
	 *
	 * @since 2.8.20
	 *
	 * @return bool
	 */
	public function is_active(): bool;

	/**
	 * Machine-readable license type for the admin UI.
	 *
	 * @since 2.8.20
	 *
	 * @return 'kadence'|'unified'
	 */
	public function get_type(): string;

	/**
	 * The full license key for this source, or empty when unavailable.
	 *
	 * @since 2.8.20
	 *
	 * @return string
	 */
	public function get_key(): string;

	/**
	 * URL for managing this license, or empty when the source has none.
	 *
	 * @since 2.8.20
	 *
	 * @return string
	 */
	public function get_manage_url(): string;
}
