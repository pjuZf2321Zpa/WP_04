<?php declare( strict_types=1 );

namespace KadenceWP\KadenceBlocksPro\Harbor;

use KadenceWP\KadenceBlocksPro\Harbor\Contracts\License_Source;

/**
 * Maps a resolved license source into the JS-facing status payload.
 *
 * @since 2.8.20
 */
final class License_Status_Presenter {

	/**
	 * Build the UI status payload for a resolved license source.
	 *
	 * @since 2.8.20
	 *
	 * @param License_Source $source The resolved license source.
	 *
	 * @return array{
	 *     type: 'none'|'unified'|'kadence',
	 *     maskedKey: string,
	 *     fullKey: string,
	 *     expires: string,
	 *     manageUrl: string
	 * }
	 */
	public function present( License_Source $source ): array {
		$key = $source->get_key();
		if ( '' === $key ) {
			return $this->empty_ui_status();
		}

		$status              = $this->empty_ui_status();
		$status['type']      = $source->get_type();
		$status['maskedKey'] = $this->mask_key( $key );
		$status['fullKey']   = $key;
		$status['manageUrl'] = $source->get_manage_url();

		return $status;
	}

	/**
	 * Empty UI status payload used when no source has an active key.
	 *
	 * @since 2.8.20
	 *
	 * @return array{
	 *     type: 'none',
	 *     maskedKey: string,
	 *     fullKey: string,
	 *     expires: string,
	 *     manageUrl: string
	 * }
	 */
	private function empty_ui_status(): array {
		return [
			'type'      => 'none',
			'maskedKey' => '',
			'fullKey'   => '',
			'expires'   => '',
			'manageUrl' => '',
		];
	}

	/**
	 * Mask a license key for display (e.g. LWSW-••••••••••••-9KQ2).
	 *
	 * @since 2.8.20
	 *
	 * @param string $key The full license key.
	 *
	 * @return string
	 */
	private function mask_key( string $key ): string {
		$key = trim( $key );
		if ( '' === $key ) {
			return '';
		}

		$parts = explode( '-', $key );
		if ( count( $parts ) >= 2 ) {
			$first = $parts[0];
			$last  = (string) end( $parts );
			$tail  = strlen( $last ) > 4 ? substr( $last, -4 ) : $last;

			return $first . '-' . str_repeat( '•', 12 ) . '-' . $tail;
		}

		if ( strlen( $key ) <= 8 ) {
			return str_repeat( '•', strlen( $key ) );
		}

		return substr( $key, 0, 4 ) . str_repeat( '•', max( 4, strlen( $key ) - 8 ) ) . substr( $key, -4 );
	}
}
