<?php declare( strict_types=1 );

namespace KadenceWP\KadenceBlocksPro\Harbor\Licensing;

use KadenceWP\KadenceBlocksPro\Harbor\Contracts\License_Source;

/**
 * Shared helpers for license sources.
 *
 * Subclasses declare a `TYPE` constant; {@see get_type()} reads it via late
 * static binding.
 *
 * @since 2.8.20
 */
abstract class Abstract_License_Source implements License_Source {

	/**
	 * UI type label for this source. Subclasses override with their type.
	 *
	 * @since 2.8.20
	 *
	 * @var string
	 */
	protected const TYPE = '';

	/**
	 * {@inheritdoc}
	 */
	public function get_type(): string {
		return static::TYPE;
	}
}
