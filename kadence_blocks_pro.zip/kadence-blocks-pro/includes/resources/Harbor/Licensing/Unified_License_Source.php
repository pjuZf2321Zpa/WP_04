<?php declare( strict_types=1 );

namespace KadenceWP\KadenceBlocksPro\Harbor\Licensing;

/**
 * Harbor unified (Liquid Web) license source.
 *
 * @since 2.8.20
 */
final class Unified_License_Source extends Abstract_License_Source {

	/**
	 * UI type label for this source.
	 *
	 * @since 2.8.20
	 *
	 * @var string
	 */
	protected const TYPE = 'unified';

	/**
	 * {@inheritdoc}
	 */
	public function is_active(): bool {
		return '' !== $this->get_key();
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_key(): string {
		if ( ! lw_harbor_is_product_license_active( 'kadence' ) ) {
			return '';
		}

		$key = lw_harbor_get_unified_license_key();

		return ! empty( $key ) ? $key : '';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_manage_url(): string {
		return (string) lw_harbor_get_license_page_url();
	}
}
