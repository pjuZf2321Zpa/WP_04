<?php declare( strict_types=1 );

namespace KadenceWP\KadenceBlocksPro\Harbor\Licensing;

use function KadenceWP\KadenceBlocks\StellarWP\Uplink\get_license_key;
use function KadenceWP\KadenceBlocks\StellarWP\Uplink\get_resource;

/**
 * Kadence (Uplink) license source.
 *
 * Preferred over the unified Harbor license when both are active.
 *
 * @since 2.8.20
 */
final class Legacy_License_Source extends Abstract_License_Source {

	/**
	 * UI type label for this source.
	 *
	 * @since 2.8.20
	 *
	 * @var string
	 */
	protected const TYPE = 'kadence';

	/**
	 * Uplink resource slug for Kadence Blocks Pro.
	 *
	 * @since 2.8.20
	 *
	 * @var string
	 */
	private const SLUG = 'kadence-blocks-pro';

	/**
	 * {@inheritdoc}
	 */
	public function is_active(): bool {
		$key = $this->get_key();

		if ( '' === $key ) {
			return false;
		}

		if ( function_exists( 'kadence_blocks_is_legacy_key_valid' ) ) {
			return kadence_blocks_is_legacy_key_valid( self::SLUG, $key );
		}

		$resource = get_resource( self::SLUG );

		return (bool) ( $resource && $resource->has_valid_license() );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_key(): string {
		$key = get_license_key( self::SLUG );

		return ! empty( $key ) ? $key : '';
	}

	/**
	 * {@inheritdoc}
	 *
	 * Uplink has no generic manage/renew URL for this product.
	 */
	public function get_manage_url(): string {
		return '';
	}
}
