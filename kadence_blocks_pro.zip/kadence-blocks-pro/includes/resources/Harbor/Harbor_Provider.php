<?php declare( strict_types=1 );

namespace KadenceWP\KadenceBlocksPro\Harbor;

use KadenceWP\KadenceBlocksPro\Contracts\Provider;
use KadenceWP\KadenceBlocksPro\Harbor\License_Modal\Assets;
use KadenceWP\KadenceBlocksPro\Harbor\License_Modal\Renderer;

/**
 * Mounts the React license modal UI on kadence-blocks' settings sidebar.
 *
 * All other Harbor bootstrapping (Harbor::init(), the license/notice glue,
 * legacy-license reporting, etc.) stays owned by kadence-blocks'
 * `Harbor_Provider`, since kadence-blocks-pro cannot function without
 * kadence-blocks already active. This provider only adds what the license
 * modal itself needs on top of that.
 *
 * @since 2.8.20
 */
final class Harbor_Provider extends Provider {

	/**
	 * Register the Harbor provider.
	 *
	 * @since 2.8.20
	 *
	 * @return void
	 */
	public function register(): void {
		if ( ! function_exists( 'lw_harbor_get_product_activation_base_url' ) ) {
			return;
		}

		$this->container->singleton( License_Status::class );

		// Legacy Uplink license fields are replaced by the React license modal UI,
		// except on network-authorized multisites
		if ( kadence_blocks_is_network_authorize_enabled() ) {
			return;
		}

		add_filter( 'kadence_blocks_pro_should_display_uplink_license_field', '__return_false' );
		// Enqueues the license modal UI assets on the kadence-blocks settings page.
		add_action( 'admin_enqueue_scripts', $this->container->callback( Assets::class, 'enqueue' ) );

		// Renders the license modal UI on kadence-blocks' settings sidebar.
		add_action( 'kadence_blocks_dash_side_panel', $this->container->callback( Renderer::class, 'render' ) );
	}
}
