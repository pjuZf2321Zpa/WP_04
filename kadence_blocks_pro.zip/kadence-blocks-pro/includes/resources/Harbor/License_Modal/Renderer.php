<?php declare( strict_types=1 );

namespace KadenceWP\KadenceBlocksPro\Harbor\License_Modal;

/**
 * Renders the license modal markup in the settings sidebar.
 *
 * @since 2.8.20
 */
final class Renderer {

	/**
	 * Renders the license modal markup.
	 *
	 * @since 2.8.20
	 *
	 * @return void
	 */
	public function render(): void {
		$product_slug = 'kadence-blocks-pro';

		include dirname( __DIR__ ) . '/views/license-modal.php';
	}
}
