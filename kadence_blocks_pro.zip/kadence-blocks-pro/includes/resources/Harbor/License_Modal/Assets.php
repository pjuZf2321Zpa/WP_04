<?php declare( strict_types=1 );

namespace KadenceWP\KadenceBlocksPro\Harbor\License_Modal;

use KadenceWP\KadenceBlocksPro\Harbor\License_Status;
use function lw_harbor_get_licensed_domain;
use function lw_harbor_get_product_activation_base_url;
use function lw_harbor_has_unified_license_key;
use function lw_harbor_is_product_license_active;

/**
 * Enqueues scripts and styles for the license modal UI.
 *
 * @since 2.8.20
 */
final class Assets {

	/**
	 * License status resolver.
	 *
	 * @var License_Status
	 */
	private License_Status $license_status;

	/**
	 * Constructor.
	 *
	 * @since 2.8.20
	 *
	 * @param License_Status $license_status License status resolver.
	 */
	public function __construct( License_Status $license_status ) {
		$this->license_status = $license_status;
	}

	/**
	 * Enqueue license modal scripts and styles when on the Kadence Blocks settings page.
	 *
	 * @since 2.8.20
	 *
	 * @return void
	 */
	public function enqueue(): void {
		if ( ! $this->is_settings_page() ) {
			return;
		}

		$asset = function_exists( 'kadence_blocks_pro_get_asset_file' )
			? kadence_blocks_pro_get_asset_file( 'dist/admin-license-modal' )
			: [
				'dependencies' => [ 'wp-api-fetch', 'wp-components', 'wp-date', 'wp-element', 'wp-i18n' ],
				'version'      => KBP_VERSION,
			];

		wp_enqueue_script(
			'admin-kadence-license-modal',
			KBP_URL . 'dist/admin-license-modal.js',
			$asset['dependencies'],
			$asset['version'],
			true
		);
		wp_enqueue_style(
			'admin-kadence-license-modal',
			KBP_URL . 'dist/admin-license-modal.css',
			[ 'wp-components' ],
			$asset['version']
		);

		// The slug Harbor knows this product by, which is not the legacy Uplink slug.
		$harbor_slug = 'kadence';

		wp_localize_script(
			'admin-kadence-license-modal',
			'kadenceLicenseModalParams',
			[
				'ajaxurl'        => admin_url( 'admin-ajax.php' ),
				'wpnonce'        => wp_create_nonce( 'kadence-blocks-manage' ),
				'licenseStatus'  => $this->license_status->get_ui_status(),
				'accountPageUrl' => 'https://software.liquidweb.com/',
				'domain'         => lw_harbor_get_licensed_domain(),
				'harbor'         => [
					'licensePath'   => '/liquidweb/harbor/v1/license',
					'keyPrefix'     => 'LWSW-',
					'productSlug'   => $harbor_slug,
					'hasKey'        => lw_harbor_has_unified_license_key(),
					'isActivated'   => lw_harbor_is_product_license_active( $harbor_slug ),
					'activationUrl' => lw_harbor_get_product_activation_base_url(),
				],
			]
		);
		wp_set_script_translations( 'admin-kadence-license-modal', 'kadence-blocks-pro' );
	}

	/**
	 * Determine if the current screen is the Kadence Blocks settings page.
	 *
	 * @since 2.8.20
	 *
	 * @return bool
	 */
	private function is_settings_page(): bool {
		$page = get_current_screen();

		return $page && 'toplevel_page_kadence-blocks' === $page->id;
	}
}
