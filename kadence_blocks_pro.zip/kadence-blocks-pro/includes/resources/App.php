<?php declare( strict_types=1 );

namespace KadenceWP\KadenceBlocksPro;

use InvalidArgumentException;
use KadenceWP\KadenceBlocksPro\Harbor\Harbor_Provider;

/**
 * The Kadence Blocks Pro application container/bootstrap.
 *
 * A deliberately small counterpart to kadence-blocks' own App/Provider
 * pattern — just enough to host the ported Harbor_Provider.
 *
 * @since 2.8.20
 */
final class App {

	private static self $instance;

	/**
	 * @var Container
	 */
	private Container $container;

	/**
	 * Add any custom providers here.
	 *
	 * @note The order is important.
	 *
	 * @var class-string<\KadenceWP\KadenceBlocksPro\Contracts\Provider>[]
	 */
	private $providers = [
		Harbor_Provider::class,
	];

	/**
	 * @since 2.8.20
	 *
	 * @param Container $container
	 */
	private function __construct( Container $container ) {
		$this->container = $container;

		$this->init();
	}

	/**
	 * @param Container|null $container
	 *
	 * @since 2.8.20
	 *
	 * @return self
	 * @throws InvalidArgumentException If no container is provided.
	 */
	public static function instance( ?Container $container = null ): App {
		if ( ! isset( self::$instance ) ) {
			if ( ! $container ) {
				throw new InvalidArgumentException( 'You need to provide a concrete Container instance!' );
			}

			self::$instance = new self( $container );
		}

		return self::$instance;
	}

	/**
	 * @since 2.8.20
	 *
	 * @return Container
	 */
	public function container(): Container {
		return $this->container;
	}

	/**
	 * @since 2.8.20
	 *
	 * @return void
	 */
	private function init(): void {
		foreach ( $this->providers as $provider ) {
			( new $provider( $this->container ) )->register();
		}
	}
}
