<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Constants\Cookies;
use ACPT\Constants\ExtraFields;
use ACPT\Constants\MetaTypes;
use ACPT\Constants\Visibility;
use ACPT\Core\API\V1\Controllers\TableRecordController;
use ACPT\Core\Helper\CCTFieldShape;
use ACPT\Core\Helper\Id;
use ACPT\Core\Models\Meta\MetaFieldModel;
use ACPT\Core\Models\Meta\MetaGroupModel;
use ACPT\Core\Models\Table\TableModel;
use ACPT\Core\Repository\TableRecordRepository;
use ACPT\Core\Repository\TableRepository;
use ACPT\Core\Validators\MetaDataValidator;
use ACPT\Utils\Checker\BoxVisibilityChecker;
use ACPT\Utils\Checker\FieldVisibilityChecker;
use ACPT\Utils\Checker\ValidationRulesChecker;
use ACPT\Utils\Data\Meta;
use ACPT\Utils\Data\Sanitizer;
use ACPT\Utils\Data\TableRecord;
use ACPT\Utils\PHP\Arrays;
use ACPT\Utils\PHP\Cookie;
use ACPT\Utils\PHP\DateNormalizer;
use ACPT\Utils\PHP\GeoLocation;
use ACPT\Utils\PHP\Request;
use ACPT\Utils\Wordpress\Files;
use ACPT\Utils\Wordpress\WPAttachment;
use JetBrains\PhpStorm\NoReturn;

abstract class AbstractSaveMetaCommand implements LogFormatInterface
{
    /**
     * @var Request
     */
    protected Request $request;

    /**
     * @var array<string, mixed>
     */
    protected ?array $data = [];

    /**
     * @var array<string, mixed>|null
     */
    protected ?array $files;

    /**
     * AbstractSaveMetaCommand constructor.
     *
     * @param Request $request
     */
    public function __construct(Request $request)
    {
        $this->request = $request;

        if (!empty($request->postParams())) {
            $this->data = $request->postParams();
        } else {
            // bulk edit
            if (!empty($request->request('_wpnonce')) && !wp_verify_nonce($request->request('_wpnonce'), 'bulk-posts')) {
                return;
            }

            $this->data = $request->requestAll();
        }

        $this->files = $request->files();
        ;
    }

    /**
     * @param MetaFieldModel $fieldModel
     *
     * @return bool
     */
    protected function hasField(MetaFieldModel $fieldModel): bool
    {
        $key = $fieldModel->getDbName();

        // @phpstan-ignore-next-line notIdentical.alwaysTrue
        if (isset($this->WooCommerceLoopIndex) && $this->WooCommerceLoopIndex !== null) {
            $key .= "_" . $this->WooCommerceLoopIndex;
        }

        $key .= "_id";

        return (
            isset($this->data[$key]) &&
            $this->data[$key] === $fieldModel->getId()
        );
    }

    /**
     * WordPress core Bulk Edit (edit.php?bulk_edit=...) treats a blank input as
     * "no change". ACPT renders its quick-edit inputs in the Bulk Edit panel too,
     * so a field left blank there must be skipped instead of blanking the value
     * on every selected post. Ticket #1369.
     *
     * @param MetaFieldModel $fieldModel
     *
     * @return bool
     */
    protected function isBlankBulkEditField(MetaFieldModel $fieldModel): bool
    {
        if (!$this->request->hasRequest('bulk_edit')) {
            return false;
        }

        $value = $this->data[$fieldModel->getDbName()] ?? null;

        if (is_array($value)) {
            $value = array_filter($value, static function ($item) {
                return $item !== '' && $item !== null;
            });
        }

        return $value === null || $value === '' || $value === [];
    }

    /**
     * Whether the current WP user is allowed to write this field, per the
     * field's own Permissions rules. Mirrors the verdict AbstractField::
     * setPermissions() already computes for the render path: a field with no
     * permissions configured is writable by everyone (PermissionTrait default);
     * otherwise the current user must have the `edit` capability for it
     * (READ_ONLY / NO_SHOW both resolve `edit => false`). Ticket #1243.
     *
     * @param MetaFieldModel $fieldModel
     * @return bool
     */
    protected function currentUserCanEditField(MetaFieldModel $fieldModel): bool
    {
        if (!$fieldModel->hasPermissions()) {
            return true;
        }

        $permissions = $fieldModel->userPermissions();

        return !empty($permissions['edit']);
    }

    /**
     * Phase 1: Validate a field without touching the DB.
     * Returns an array of error message strings (empty = valid).
     *
     * @param MetaFieldModel $fieldModel
     * @param string|int     $elementId
     *
     * @return string[]
     */
    protected function validateField(MetaFieldModel $fieldModel, $elementId): array
    {
        $errors    = [];
        $data      = $this->data;
        $fieldType = $fieldModel->getType();
        $key       = $fieldModel->getDbName();

        // @phpstan-ignore-next-line notIdentical.alwaysTrue
        if (isset($this->WooCommerceLoopIndex) && $this->WooCommerceLoopIndex !== null) {
            $key .= "_" . $this->WooCommerceLoopIndex;
        }

        // File fields are validated at save time (tmp_name availability), skip here
        if (isset($this->files[$key])) {
            return [];
        }

        if (!isset($data[$key])) {
            return [];
        }

        $rawValue = $data[$key];

        // Basic type validation
        try {
            MetaDataValidator::validate($fieldType, $rawValue, $fieldModel->isRequired());
        } catch (\Exception $e) {
            $errors[] = $e->getMessage();
        }

        // @lite-strip-start
        // Min / max attribute validation
        try {
            $fieldModel->validateAgainstMaxAndMin($rawValue);
        } catch (\Exception $e) {
            $errors[] = $e->getMessage();
        }

        // Custom validation rules
        if (!empty($fieldModel->getValidationRules())) {
            // the third argument keeps MIN/MAX meaning the same thing here as it does in
            // the browser: DataValidateAttributes routes those two rules to
            // -minlength/-maxlength for a textual field and to -min/-max otherwise
            $checker = new ValidationRulesChecker($rawValue, $fieldModel->getValidationRules(), $fieldModel->isTextual(), $fieldModel->isRequired());
            $checker->validate();

            if (!$checker->isValid()) {
                foreach ($checker->getErrors() as $error) {
                    $errors[] = $error;
                }
            }
        }
        // @lite-strip-end

        // Multiple file fields
        if (
            $fieldType === MetaFieldModel::AUDIO_MULTI_TYPE ||
            $fieldType === MetaFieldModel::GALLERY_TYPE ||
            $fieldType === MetaFieldModel::VIDEO_MULTI_TYPE
        ) {
            foreach ($rawValue as $imagePath) {
                $attachment = WPAttachment::fromUrl($imagePath);

                try {
                    $fieldModel->validateImageDimension($attachment->getPath());
                    $fieldModel->validateFileMimeType($attachment->getPath());
                    $fieldModel->validateFileSize($attachment->getFileSize());
                } catch (\Exception $e) {
                    $errors[] = $e->getMessage();
                }
            }
        }

        // Single file fields
        if (
            $fieldType === MetaFieldModel::AUDIO_TYPE ||
            $fieldType === MetaFieldModel::IMAGE_TYPE ||
            $fieldType === MetaFieldModel::FILE_TYPE  ||
            $fieldType === MetaFieldModel::VIDEO_TYPE
        ) {
            $attachment = WPAttachment::fromUrl($rawValue);

            try {
                $fieldModel->validateImageDimension($attachment->getPath());
                $fieldModel->validateFileMimeType($attachment->getPath());
                $fieldModel->validateFileSize($attachment->getFileSize());
            } catch (\Exception $e) {
                $errors[] = $e->getMessage();
            }
        }

        // ID field
        if ($fieldType === MetaFieldModel::ID_TYPE) {
            $idStrategy = $fieldModel->getAdvancedOption('id_strategy') ?? Id::UUID_V1;

            if (!Id::isValid($rawValue, $idStrategy)) {
                $errors[] = "ID format is not valid";
            }
        }

        // Relational min/max blocks
        if ($fieldType === MetaFieldModel::POST_TYPE) {
            // @phpstan-ignore-next-line function.alreadyNarrowedType
            $rawValues        = is_array($rawValue) ? $rawValue : explode(",", $rawValue);
            $numberOfElements = Arrays::count($rawValues);
            $errors           = array_merge($errors, $this->checkMinMaxBlocksErrors($data, $fieldModel->getDbName(), $numberOfElements));
        }

        if (
            $fieldType === MetaFieldModel::POST_OBJECT_MULTI_TYPE ||
            $fieldType === MetaFieldModel::TERM_OBJECT_MULTI_TYPE ||
            $fieldType === MetaFieldModel::USER_MULTI_TYPE
        ) {
            $numberOfElements = is_array($rawValue) ? Arrays::count($rawValue) : 0;
            $errors           = array_merge($errors, $this->checkMinMaxBlocksErrors($data, $fieldModel->getDbName(), $numberOfElements));
        }

        if ($fieldType === MetaFieldModel::REPEATER_TYPE && is_array($rawValue)) {
            $numberOfElements = count(array_values($rawValue)[0]);
            $errors           = array_merge($errors, $this->checkMinMaxBlocksErrors($data, $fieldModel->getDbName(), $numberOfElements));
        }

        if ($fieldType === MetaFieldModel::FLEXIBLE_CONTENT_TYPE && is_array($rawValue)) {
            $numberOfBlocks = Arrays::count($rawValue);
            $errors         = array_merge($errors, $this->checkMinMaxBlocksErrors($data, $fieldModel->getDbName(), $numberOfBlocks));
        }

        return $errors;
    }

    /**
     * Phase 2: Persist a single field to the DB.
     * Call this only after all fields have been validated.
     *
     * @param MetaFieldModel $fieldModel
     * @param string|int     $elementId
     * @param string         $belongsTo
     *
     * @throws \Exception
     */
    protected function persistField(MetaFieldModel $fieldModel, $elementId, $belongsTo): void
    {
        $data                  = $this->data;
        $idName                = $fieldModel->getDbName();
        $fieldType             = $fieldModel->getType();
        $allowHtml             = false;
        $allowDangerousContent = false;
        $key                   = $idName;

        if ($fieldModel->isAWooCommerceProductAttribute()) {
            $idName = $elementId;
        }

        // @phpstan-ignore-next-line notIdentical.alwaysTrue
        if (isset($this->WooCommerceLoopIndex) && $this->WooCommerceLoopIndex !== null) {
            $key .= "_" . $this->WooCommerceLoopIndex;
        }

        // Handle file uploads from comment forms
        if (isset($this->files[$key])) {
            $rawFile = $this->files[$key];

            if (!empty($rawFile['tmp_name'])) {
                $fileUploaded = Files::uploadFile($rawFile['tmp_name'], $rawFile['name']);

                if ($fileUploaded !== false) {
                    Meta::save($elementId, $belongsTo, (string)$idName, $fileUploaded['url']);
                    Meta::save($elementId, $belongsTo, $idName . '_id', $fileUploaded['attachmentId']);
                    Meta::save($elementId, $belongsTo, $idName . '_type', $fieldModel->getType());
                }
            }

            return;
        }

        if (isset($data[$key])) {
            $rawValue = $data[$key];

            // Relational field
            if ($fieldType === MetaFieldModel::POST_TYPE) {
                $command = new HandleRelationsCommand($fieldModel, $rawValue, $elementId, $belongsTo);
                $command->execute();

                return;
            }

            // ACPT_Plugin's Request is built when the plugin loads, before WP adds magic
            // quotes, so this value is NOT slashed: it is sanitized and stored as is
            // (Meta::save(..., false)). Unslashing it stripped every backslash, JSON
            // escapes included (#1380).
            $value = $rawValue;

            if (is_array($value)) {
                if ($fieldType === MetaFieldModel::REPEATER_TYPE || $fieldType === MetaFieldModel::FLEXIBLE_CONTENT_TYPE) {
                    foreach ($value as $blockName => $fields) {
                        if (!is_array($fields)) {
                            do_action("acpt/error", new \UnexpectedValueException(
                                "Skipped reindex for block \"$blockName\" on field \"$idName\": expected array, got " . gettype($fields)
                            ));
                            unset($value[$blockName]);
                            continue;
                        }

                        $value[$blockName] = Arrays::reindex($fields);
                    }
                } else {
                    $value = Arrays::reindex($value);
                }
            }

            // Other relational fields — normalise to array
            if (
                $fieldType === MetaFieldModel::POST_OBJECT_MULTI_TYPE ||
                $fieldType === MetaFieldModel::TERM_OBJECT_MULTI_TYPE ||
                $fieldType === MetaFieldModel::USER_MULTI_TYPE
            ) {
                if (!empty($value) && !is_array($value)) {
                    $value = explode(",", $value);
                }
            }

            // Password hashing
            if ($fieldType === MetaFieldModel::PASSWORD_TYPE) {
                $algo = $fieldModel->getAdvancedOption("algorithm") ?? PASSWORD_DEFAULT;

                switch ($algo) {
                    case "PASSWORD_BCRYPT":
                        $value = password_hash($value, PASSWORD_BCRYPT);
                        break;
                    case "PASSWORD_ARGON2I":
                        $value = password_hash($value, PASSWORD_ARGON2I);
                        break;
                    case "PASSWORD_ARGON2ID":
                        $value = password_hash($value, PASSWORD_ARGON2ID);
                        break;
                    default:
                        $value = password_hash($value, PASSWORD_DEFAULT);
                        break;
                }
            }

            // Date / time normalisation
            if (
                $fieldType === MetaFieldModel::DATE_TIME_TYPE  ||
                $fieldType === MetaFieldModel::DATE_TYPE        ||
                $fieldType === MetaFieldModel::TIME_TYPE        ||
                $fieldType === MetaFieldModel::DATE_RANGE_TYPE
            ) {
                switch ($fieldType) {
                    case MetaFieldModel::DATE_TIME_TYPE:
                        $defaultFormat = "Y-m-d H:i:s";
                        break;
                    case MetaFieldModel::TIME_TYPE:
                        $defaultFormat = "H:i:s";
                        break;
                    default:
                        $defaultFormat = "Y-m-d";
                        break;
                }

                $format         = $data[$idName . "_format"] ?? $defaultFormat;
                $dateTimeObject = \DateTime::createFromFormat($format, $value);

                // Fallback for quick/bulk edit format
                if (!$dateTimeObject instanceof \DateTime) {
                    $dateTimeObject = \DateTime::createFromFormat("Y-m-d\TH:i", $value);
                }

                if ($dateTimeObject instanceof \DateTime) {
                    $value = $dateTimeObject->format($defaultFormat);
                } elseif (is_string($value) && $value !== '') {
                    $value = $this->normalizeDisplayDate($fieldModel, $fieldType, $value);
                }
            }

            // HTML flags
            if ($fieldType === MetaFieldModel::TEXT_TYPE || $fieldType === MetaFieldModel::TEXTAREA_TYPE) {
                $allowHtml             = $fieldModel->getAdvancedOption("allow_html") ?? false;
                $allowDangerousContent = $fieldModel->getAdvancedOption("allow_dangerous_content") ?? false;
            }

            if ($fieldType === MetaFieldModel::HTML_TYPE || $fieldType === MetaFieldModel::EDITOR_TYPE) {
                $allowHtml             = true;
                $allowDangerousContent = $fieldModel->getAdvancedOption("allow_dangerous_content") ?? false;
            }

            Meta::save(
                $elementId,
                $belongsTo,
                (string)$idName,
                Sanitizer::toMetaStorage($fieldType, Sanitizer::sanitizeRawData($fieldType, $this->convertMetaDataToDBFormat($value), [
                    'allow_dangerous_content' => $allowDangerousContent,
                    'allow_html' => $allowHtml,
                    'unslashed' => true,
                ])),
                false
            );

            // Address: geocode if coordinates not already provided
            if ($fieldType === MetaFieldModel::ADDRESS_TYPE) {
                $address = Sanitizer::sanitizeRawData($fieldType, $this->convertMetaDataToDBFormat($value));

                if (!empty($address) && empty($data[$idName . '_lat']) && empty($data[$idName . '_lng'])) {
                    $coordinates = GeoLocation::getCoordinates($address);
                    $data[$idName . '_lat'] = $coordinates['lat'];
                    $data[$idName . '_lng'] = $coordinates['lng'];

                    if (empty($data[$idName . '_city'])) {
                        $city = GeoLocation::getCity($coordinates['lat'], $coordinates['lng']);

                        if (!empty($city)) {
                            $data[$idName . '_city'] = $city;
                        }
                    }

                    if (empty($data[$idName . '_country'])) {
                        $country = GeoLocation::getCountry($coordinates['lat'], $coordinates['lng']);

                        if (!empty($country)) {
                            $data[$idName . '_country'] = $country;
                        }
                    }
                }
            }

            // Image: optionally set as post thumbnail
            if (
                $fieldType === MetaFieldModel::IMAGE_TYPE &&
                $fieldModel->getAdvancedOption('set_thumbnail') == 1 &&
                $belongsTo === MetaTypes::CUSTOM_POST_TYPE
            ) {
                if (!empty($data[$idName . '_attachment_id'])) {
                    set_post_thumbnail((int) $elementId, (int) $data[$idName . '_attachment_id']);
                } else {
                    delete_post_meta((int) $elementId, '_thumbnail_id');
                }
            }

            // Gallery / image slider: set first image as post thumbnail
            if (
                ($fieldType === MetaFieldModel::GALLERY_TYPE || $fieldType === MetaFieldModel::IMAGE_SLIDER_TYPE) &&
                $fieldModel->getAdvancedOption('set_thumbnail') == 1 &&
                $belongsTo === MetaTypes::CUSTOM_POST_TYPE
            ) {
                if (!empty($data[$idName . '_attachment_id'])) {
                    $firstImageId = explode(",", $data[$idName . '_attachment_id']);
                    set_post_thumbnail((int) $elementId, (int) $firstImageId[0]);
                } else {
                    delete_post_meta((int) $elementId, '_thumbnail_id');
                }
            }

            // Term fields: sync with post taxonomy
            if (
                ($fieldType === MetaFieldModel::TERM_OBJECT_TYPE || $fieldType === MetaFieldModel::TERM_OBJECT_MULTI_TYPE) &&
                $fieldModel->getAdvancedOption('sync_taxonomy') == 1 &&
                $belongsTo === MetaTypes::CUSTOM_POST_TYPE
            ) {
                $termValues = is_array($value) ? $value : [$value];
                $taxonomies = [];

                foreach ($termValues as $termId) {
                    if (!empty($termId)) {
                        $term = get_term($termId);

                        if ($term instanceof \WP_Term) {
                            $taxonomies[$term->taxonomy][] = (int) $term->term_id;
                        }
                    }
                }

                foreach ($taxonomies as $taxonomy => $terms) {
                    wp_set_post_terms((int) $elementId, $terms, $taxonomy);
                }
            }

            // Extra fields
            foreach (ExtraFields::ALLOWED_VALUES as $extra) {
                if (isset($data[$key . '_' . $extra])) {
                    Meta::save(
                        $elementId,
                        $belongsTo,
                        $idName . '_' . $extra,
                        Sanitizer::sanitizeRawData(MetaFieldModel::TEXT_TYPE, $data[$key . '_' . $extra], ['unslashed' => true]),
                        false
                    );
                }
            }
        } else {

            // Blank the field only if it already exists in the DB
            $existing = Meta::fetch($elementId, $belongsTo, (string)$idName);

            if ($existing !== null) {
                Meta::save($elementId, $belongsTo, (string)$idName, '');

                foreach (ExtraFields::ALLOWED_VALUES as $extra) {
                    $existingExtra = Meta::fetch($elementId, $belongsTo, $idName . '_' . $extra);

                    if ($existingExtra !== null) {
                        Meta::save($elementId, $belongsTo, $idName . '_' . $extra, '');
                    }
                }

                // Blank synced taxonomy terms
                if (
                    ($fieldType === MetaFieldModel::TERM_OBJECT_TYPE || $fieldType === MetaFieldModel::TERM_OBJECT_MULTI_TYPE) &&
                    $fieldModel->getAdvancedOption('sync_taxonomy') == 1 &&
                    $belongsTo === MetaTypes::CUSTOM_POST_TYPE
                ) {
                    foreach (get_post_taxonomies((int) $elementId) as $taxonomy) {
                        wp_set_post_terms((int) $elementId, [], $taxonomy);
                    }
                }
            }
        }

        do_action("acpt/save_meta_field", $this, $fieldModel, $elementId, $belongsTo);
    }

    /**
     * The submitted values, shaped like the payload ACPTConditionalRules.js posts to
     * the live check, so conditions are judged on what is being saved rather than on
     * the stored values.
     *
     * @param array<array<string, mixed>> $fieldEntries
     *
     * @return array<int, array<string, mixed>>
     */
    private function submittedLiveData(array $fieldEntries): array
    {
        $liveData = [];

        foreach ($fieldEntries as $entry) {
            /** @var MetaFieldModel $fieldModel */
            $fieldModel = $entry['field'];
            $key        = $fieldModel->getDbName();

            // @phpstan-ignore-next-line notIdentical.alwaysTrue
            if (isset($this->WooCommerceLoopIndex) && $this->WooCommerceLoopIndex !== null) {
                $key .= "_" . $this->WooCommerceLoopIndex;
            }

            $liveData[] = [
                'id'     => $key,
                'formId' => $fieldModel->getId(),
                'value'  => $this->data[$key] ?? null,
            ];
        }

        return $liveData;
    }

    /**
     * @param MetaFieldModel           $fieldModel
     * @param int|string               $elementId
     * @param string                   $belongsTo
     * @param array<int, array<string, mixed>> $liveData
     *
     * @return bool
     */
    private function isHiddenByConditions(MetaFieldModel $fieldModel, $elementId, string $belongsTo, array $liveData): bool
    {
        if (
            $fieldModel->hasVisibilityConditions() &&
            !FieldVisibilityChecker::check(Visibility::IS_BACKEND, $elementId, $belongsTo, $fieldModel, $liveData)
        ) {
            return true;
        }

        $boxModel = $fieldModel->getBox();

        return $boxModel->hasVisibilityConditions() &&
            !BoxVisibilityChecker::check(Visibility::IS_BACKEND, $boxModel, $elementId, $belongsTo, $liveData);
    }

    /**
     * Validate all fields first, then persist them inside a DB transaction.
     * Redirects back with all collected errors if any validation fails.
     *
     * Each entry in $fieldEntries must be an associative array with keys:
     *   - 'field'     => MetaFieldModel
     *   - 'elementId' => string|int
     *   - 'belongsTo' => string
     *
     * @param array<array<string, mixed>> $fieldEntries
     */
    protected function validateAndSaveFields(array $fieldEntries): void
    {
        // --- Phase 1: validate each field individually. A field that fails
        // validation is excluded from Phase 2 below, but no longer blocks
        // every other field on the post from being persisted. ---
        $errors       = [];
        $validEntries = [];
        $liveData     = $this->submittedLiveData($fieldEntries);

        foreach ($fieldEntries as $entry) {
            // Server-side permission enforcement (ticket #1243). A field's own
            // Permissions tab is honoured on the render path (AbstractField::
            // setPermissions() -> READ_ONLY / NO_SHOW), but the save path never
            // checked it — a crafted POST carrying a restricted field's hidden
            // trackers was persisted regardless. If the current user has no
            // `edit` verdict on this field, silently drop the write and log it
            // (the normal UI would not have submitted it — this only fires on a
            // hand-crafted request, so it is not a user-facing validation error).
            if (!$this->currentUserCanEditField($entry['field'])) {
                do_action("acpt/error", new \Exception(sprintf(
                    'Blocked a write to meta field "%s" — the current user does not have edit permission on it (field-level Permissions).',
                    $entry['field']->getName()
                )));
                continue;
            }

            // the user never saw a field its conditions hide, and the browser no longer
            // submits it as required: rejecting it here named a field nobody could fill
            // in (#1437). Its submitted value is still saved, as for any optional field.
            if ($this->isHiddenByConditions($entry['field'], $entry['elementId'], $entry['belongsTo'], $liveData)) {
                $validEntries[] = $entry;
                continue;
            }

            try {
                $fieldErrors = $this->validateField($entry['field'], $entry['elementId']);
            } catch (\Throwable $e) {
                do_action("acpt/error", $e);
                $fieldErrors = [$e->getMessage()];
            }

            if (!empty($fieldErrors)) {
                $errors = array_merge($errors, $fieldErrors);
                continue;
            }

            $validEntries[] = $entry;
        }

        // --- Phase 2: persist each valid field independently. One field's
        // failure must not discard fields already persisted earlier in
        // this same request. ---
        global $wpdb;

        $wpdb->query('START TRANSACTION');

        foreach ($validEntries as $entry) {
            try {
                $this->persistField($entry['field'], $entry['elementId'], $entry['belongsTo']);
            } catch (\Throwable $e) {
                do_action("acpt/error", $e);
                $errors[] = $e->getMessage();
            }
        }

        $wpdb->query('COMMIT');

        if (!empty($errors)) {
            $this->redirectWithErrors($errors);
        }
    }

    /**
     * Store errors in a cookie and redirect back to the previous page.
     *
     * @param array<string>|array<string, string[]> $messages
     *
     * @return void
     */
    protected function redirectWithErrors(array $messages): void
    {
        foreach ($messages as $message) {
            // @phpstan-ignore-next-line instanceof.alwaysFalse
            if ($message instanceof \Exception) {
                do_action("acpt/error", $message);
            }
        }

        Cookie::set(Cookies::ACPT_ERRORS, array_map(static function ($field, $errors) {

            // @phpstan-ignore-next-line function.impossibleType
            $message = (is_array($errors)) ? $field . ': ' . implode(', ', $errors) : $errors;

            return [
                'level'   => 'warning',
                'message' => $message,
            ];
        }, array_keys($messages), $messages));

        wp_safe_redirect($this->request->httpReferer());

        // the test suite throws here: the exit would end the whole PHPUnit process, silently and with code 0
        do_action('acpt/save_meta/before_exit', $messages);

        exit();
    }

    /**
     * The admin date pickers submit the field's display format (e.g. "08.10.2026"
     * on a German site) and no longer send a "_format" companion, so convert it
     * to the canonical storage format here (#1389). Unparseable values are
     * returned unchanged.
     *
     * @param MetaFieldModel $fieldModel
     * @param string         $fieldType
     * @param string         $value
     * @return string
     */
    private function normalizeDisplayDate(MetaFieldModel $fieldModel, string $fieldType, string $value): string
    {
        $dateFormat = $fieldModel->getAdvancedOption('date_format') ?: get_option('date_format');
        $timeFormat = $fieldModel->getAdvancedOption('time_format') ?: get_option('time_format');

        $toDate = static function (string $date) use ($dateFormat): ?string {
            return DateNormalizer::toDate($date, $dateFormat) ?? DateNormalizer::toDate($date);
        };

        switch ($fieldType) {
            case MetaFieldModel::DATE_TYPE:
                $normalized = $toDate($value);
                break;

            case MetaFieldModel::DATE_TIME_TYPE:
                $normalized = DateNormalizer::toDateTime($value, $dateFormat . ' ' . $timeFormat) ?? DateNormalizer::toDateTime($value);
                $normalized = $normalized !== null ? str_replace('T', ' ', $normalized) : null;
                break;

            case MetaFieldModel::TIME_TYPE:
                $normalized = DateNormalizer::toTime($value, $timeFormat) ?? DateNormalizer::toTime($value);
                break;

            case MetaFieldModel::DATE_RANGE_TYPE:
                $parts = explode(' - ', $value, 2);
                $from  = isset($parts[1]) ? $toDate(trim($parts[0])) : null;
                $to    = isset($parts[1]) ? $toDate(trim($parts[1])) : null;
                $normalized = ($from !== null && $to !== null) ? $from . ' - ' . $to : null;
                break;

            default:
                $normalized = null;
        }

        return $normalized ?? $value;
    }

    /**
     * Normalise raw data before saving to DB.
     * Converts relationship values from comma-separated strings to arrays.
     *
     * @param mixed $rawValue
     *
     * @return mixed
     * @throws \Exception
     */
    protected function convertMetaDataToDBFormat($rawValue)
    {
        if (!is_array($rawValue)) {
            return $rawValue;
        }

        foreach ($rawValue as $fieldLabel => $fieldValue) {
            if (!is_array($fieldValue)) {
                continue;
            }

            foreach ($fieldValue as $index => $nestedValue) {

                // POST inside a nested block
                if (isset($nestedValue['blocks']) && is_array($nestedValue['blocks'])) {
                    foreach ($nestedValue['blocks'] as $blockIndex => $blockFields) {
                        if (!is_array($blockFields)) {
                            continue;
                        }

                        foreach ($blockFields as $fieldName => $fieldValues) {
                            if (!is_array($fieldValues)) {
                                continue;
                            }

                            foreach ($fieldValues as $fIndex => $fValue) {
                                if (!is_array($fValue)) {
                                    continue;
                                }

                                foreach ($fValue as $cIndex => $field) {
                                    if (isset($field['type']) && $field['type'] === MetaFieldModel::POST_TYPE) {
                                        $rawValue[$fieldLabel][$index]["blocks"][$blockIndex][$fieldName][$fIndex][$cIndex]['value']
                                            = explode(",", $field['value']);
                                    }
                                }
                            }
                        }
                    }
                } elseif (isset($nestedValue['original_name'])) {

                    // POST inside a repeater
                    if (isset($nestedValue['type']) && $nestedValue['type'] === MetaFieldModel::POST_TYPE) {
                        $rawValue[$fieldLabel][$index]['value'] = is_array($rawValue[$fieldLabel][$index]['value'])
                            ? $rawValue[$fieldLabel][$index]['value']
                            : explode(",", $rawValue[$fieldLabel][$index]['value']);
                    }

                    // POST inside a nested repeater
                    if (isset($nestedValue['type']) && is_array($nestedValue) && $nestedValue['type'] === MetaFieldModel::REPEATER_TYPE) {
                        $nestedKey              = array_keys($nestedValue)[0];
                        $secondLevelNestedValues = $nestedValue[$nestedKey];

                        foreach ($secondLevelNestedValues as $cindex => $secondLevelNestedValue) {
                            if (
                                isset($rawValue[$fieldLabel][$index][$nestedKey][$cindex]['type']) &&
                                $rawValue[$fieldLabel][$index][$nestedKey][$cindex]['type'] === MetaFieldModel::POST_TYPE
                            ) {
                                $rawValue[$fieldLabel][$index][$nestedKey][$cindex]['value']
                                    = explode(",", $rawValue[$fieldLabel][$index][$nestedKey][$cindex]['value']);
                            }
                        }
                    }
                }
            }

            // POST inside a block
            // @phpstan-ignore-next-line function.alreadyNarrowedType
            if ($fieldLabel !== 'blocks' || !is_array($fieldValue)) {
                continue;
            }

            foreach ($fieldValue as $blockIndex => $blockFields) {
                if (!is_array($blockFields)) {
                    continue;
                }

                foreach ($blockFields as $fieldName => $fieldValues) {
                    if (!is_array($fieldValues)) {
                        continue;
                    }

                    foreach ($fieldValues as $fIndex => $fValue) {
                        if (!is_array($fValue)) {
                            continue;
                        }

                        foreach ($fValue as $cIndex => $field) {
                            if (isset($field['type']) && $field['type'] === MetaFieldModel::POST_TYPE) {
                                $rawValue["blocks"][$blockIndex][$fieldName][$fIndex][$cIndex]['value']
                                    = explode(",", $field['value']);
                            }

                            // POST inside a 2nd-level block
                            if (!isset($field['blocks'])) {
                                continue;
                            }

                            foreach ($field['blocks'] as $bBlockIndex => $bBlockFields) {
                                foreach ($bBlockFields as $ffieldName => $ffieldValues) {
                                    foreach ($ffieldValues as $ffIndex => $ffieldValue) {
                                        foreach ($ffieldValue as $ccIndex => $ffield) {
                                            if (isset($ffield['type']) && $ffield['type'] === MetaFieldModel::POST_TYPE) {
                                                $rawValue["blocks"][$blockIndex][$fieldName][$fIndex][$cIndex]["blocks"][$bBlockIndex][$ffieldName][$ffIndex][$ccIndex]['value']
                                                    = explode(",", $ffield['value']);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        return $rawValue;
    }

    /**
     * @return array<string, mixed>
     */
    public function logFormat(): array
    {
        return [
            "class" => static::class,
            'data'  => $this->data,
            'files' => $this->files,
        ];
    }

    // @lite-strip-start
    /**
     * Returns an array of error messages for min/max block violations.
     * Empty array means no violations.
     *
     * @param array<string, mixed>  $data
     * @param string                $idName
     * @param int                   $numberOfElements
     *
     * @return array<string>
     */
    private function checkMinMaxBlocksErrors(array $data, string $idName, int $numberOfElements): array
    {
        $errors      = [];
        $minimumBlocks = $data[$idName . '_min_blocks'] ?? null;
        $maximumBlocks = $data[$idName . '_max_blocks'] ?? null;

        if ($minimumBlocks && $numberOfElements < $minimumBlocks) {
            $errors[] = 'There was an error during saving data. Minimum number of elements is: ' . $minimumBlocks;
        }

        if ($maximumBlocks && $numberOfElements > $maximumBlocks) {
            $errors[] = 'There was an error during saving data. Maximum number of elements is: ' . $maximumBlocks;
        }

        return $errors;
    }

    // -------------------------------------------------------------------------
    // CCT
    // -------------------------------------------------------------------------

    /**
     * @param MetaGroupModel $metaGroup
     * @param array<string, mixed> $context
     * @return void
     */
    protected function saveCCTData(MetaGroupModel $metaGroup, array $context = []): void
    {
        if (!$metaGroup->isCCTCopy()) {
            return;
        }

        // This runs inside a loop over every meta group attached to the
        // element being saved (see e.g. SaveCustomPostTypeMetaCommand::execute()).
        // A failure here must not abort that loop -- log and continue, so one
        // broken/misconfigured CCT-copy group can't silently block every
        // other (unrelated) meta group on the same element from saving.
        try {
            $controller = new TableRecordController();
            $tableName = $metaGroup->getName();
            $data = $this->request->post($tableName, []);

            // No full table payload in this request (e.g. quick/bulk edit uses
            // cct_fields[table][col] instead) — the generator's save_post hook
            // handles CCT saving for that flow.
            if (empty($data)) {
                return;
            }

            if (is_numeric($data['id'] ?? null)) {
                $data['id'] = (int)$data['id'];
            }

            // No record id in the form, but this element already has a record:
            // update it instead of creating a new one that can't be linked to the
            // element (its location is already taken), which looked like the data
            // was never saved (#1416)
            if (empty($data['id'])) {
                $tableModel = TableRepository::getByName($tableName);

                if ($tableModel instanceof TableModel && $tableModel->hasIdStrategy()) {
                    $existingId = TableRecord::fetch($tableModel, $context, 'id');

                    if (is_numeric($existingId)) {
                        $data['id'] = (int)$existingId;
                    }
                }
            }

            $data['locations'] = $this->resolveLocationRule($tableName, $context, $data['id'] ?? null);
            $files = $this->request->files();

            if (!empty($data['id'])) {
                $controller->update($tableName, $data['id'], $data, $files);
            } else {
                $controller->create($tableName, $data, $files);
            }

            // the rows read (and cached) before the save are stale now
            TableRecord::invalidate($tableName);

            $this->setCCTPostThumbnail($tableName, $data, $context);
        } catch (\Throwable $exception) {
            do_action('acpt/error', $exception);
            $this->notifyCCTSaveError($metaGroup->getName(), $exception);
        }
    }

    /**
     * Apply the "Set as post thumbnail" option of the table's Image, Gallery and
     * Image slider columns, as persistField() does for meta fields: the CCT save
     * never did, so the option had no effect (#1425). Only columns sent in this
     * save are applied, so a save that doesn't include the column keeps the
     * current thumbnail.
     *
     * @param string               $tableName
     * @param array<string, mixed> $data    The submitted record
     * @param array<string, mixed> $context
     *
     * @return void
     * @throws \Exception
     */
    private function setCCTPostThumbnail(string $tableName, array $data, array $context): void
    {
        $postId = (int)($context['postId'] ?? 0);
        $tableModel = TableRepository::getByName($tableName);

        if ($postId <= 0 || !$tableModel instanceof TableModel) {
            return;
        }

        $imageTypes = [MetaFieldModel::IMAGE_TYPE, MetaFieldModel::GALLERY_TYPE, MetaFieldModel::IMAGE_SLIDER_TYPE];

        foreach ($tableModel->getColumns() as $column) {
            $uiField = $column->getUiField();

            if (
                !in_array($uiField->type, $imageTypes, true) ||
                $uiField->getAdvancedOption('set_thumbnail') != 1 ||
                !array_key_exists($column->getName(), $data)
            ) {
                continue;
            }

            // Image: {url, attachment_id}; Gallery/Image slider: [{url, attachment_id}, ...]
            $value = TableRecord::fetch($tableModel, $context, $column->getName());
            $image = ($uiField->type === MetaFieldModel::IMAGE_TYPE) ? $value : ($value[0] ?? null);
            $attachmentId = 0;

            if (is_array($image)) {
                $attachmentId = (int)($image[CCTFieldShape::KEY_ATTACHMENT_ID] ?? 0);

                if ($attachmentId <= 0 && !empty($image[CCTFieldShape::KEY_URL])) {
                    $attachmentId = attachment_url_to_postid((string)$image[CCTFieldShape::KEY_URL]);
                }
            }

            if ($attachmentId > 0) {
                set_post_thumbnail($postId, $attachmentId);
            } else {
                delete_post_meta($postId, '_thumbnail_id');
            }
        }
    }

    /**
     * @var array<int, array<string, string>>
     */
    private static array $cctSaveErrors = [];

    /**
     * Show a CCT save failure on the next admin page: it used to be only logged,
     * so the post saved and the table data was silently lost (#1416).
     * No redirect here (unlike redirectWithErrors()): the other meta groups of
     * the element must still be saved.
     *
     * @param string $tableName
     * @param \Throwable $exception
     *
     * @return void
     */
    private function notifyCCTSaveError(string $tableName, \Throwable $exception): void
    {
        if (headers_sent()) {
            return;
        }

        // displayNotice() prints the message as it is
        self::$cctSaveErrors[] = [
            'level'   => 'error',
            'message' => esc_html(sprintf(
                'The data of the table "%s" was not saved: %s',
                $tableName,
                $exception->getMessage()
            )),
        ];

        Cookie::set(Cookies::ACPT_ERRORS, self::$cctSaveErrors);
    }

    /**
     * Resolves location-specific rules based on the provided rules, context, and optional identifier.
     *
     * @param string $tableName The table name associated with the location rules.
     * @param array<string, mixed> $context An array of contextual information to assist in rule resolution.
     * @param int|string|null $id An optional identifier to append specific location values for a given rule.
     *
     * @return array<array<string, mixed>> The processed array of location rules. Returns an empty array if no rules are provided.
     */
    private function resolveLocationRule(string $tableName, array $context = [], $id = null): array
    {
        $rules =(!empty($id)) ? TableRecordRepository::getRecordLocations($tableName, $id) : [];

        // adding the new rule
        $newRuleContext = TableRecord::resolveContext($context);

        if (!empty($newRuleContext)) {
            $rules[] = [
                'location_rule' => $newRuleContext['locationRule'],
                'location_value' => $newRuleContext['locationValue'],
            ];
        }

        // avoid duplicate rules
        $rules = array_unique($rules, SORT_REGULAR);
        $rules = array_values($rules);

        return  $rules;
    }
    // @lite-strip-end
}
