<?php

namespace ACPT\Admin;

use ACPT\Core\API\AJAX\Controllers\AbstractController;
use ACPT\Core\API\AJAX\Controllers\ApiKeysController; // @lite-strip-line
use ACPT\Core\API\AJAX\Controllers\BulkActionController;
use ACPT\Core\API\AJAX\Controllers\CacheController;
use ACPT\Core\API\AJAX\Controllers\CustomPostTypeController;
use ACPT\Core\API\AJAX\Controllers\DatasetController; // @lite-strip-line
use ACPT\Core\API\AJAX\Controllers\FileController; // @lite-strip-line
use ACPT\Core\API\AJAX\Controllers\FormController; // @lite-strip-line
use ACPT\Core\API\AJAX\Controllers\GlobalsController;
use ACPT\Core\API\AJAX\Controllers\IntegrationController; // @lite-strip-line
use ACPT\Core\API\AJAX\Controllers\LicenseController;
use ACPT\Core\API\AJAX\Controllers\MetaController;
use ACPT\Core\API\AJAX\Controllers\OptionPageController; // @lite-strip-line
use ACPT\Core\API\AJAX\Controllers\PermissionController;
use ACPT\Core\API\AJAX\Controllers\TableController; // @lite-strip-line
use ACPT\Core\API\AJAX\Controllers\TableGroupController; // @lite-strip-line
use ACPT\Core\API\AJAX\Controllers\TaxonomyController;
use ACPT\Core\API\AJAX\Controllers\WordPressController;
use ACPT\Core\API\AJAX\Middleware\AdminPermissionsMiddleware;
use ACPT\Core\API\AJAX\Middleware\AjaxNonceVerifierMiddleware;
use ACPT\Core\API\AJAX\Middleware\EditorPermissionsMiddleware;
use ACPT\Utils\PHP\Request;

/**
 * The admin ajax handler
 *
 * @since      1.0.0
 * @package    advanced-custom-post-type
 * @subpackage advanced-custom-post-type/admin
 * @author     Mauro Cassani <maurocassani1978@gmail.com>
 */
class ACPT_Ajax
{
    public const ACTION_PREFIX = 'wp_ajax_';
    public const ACTION_PREFIX_NO_PRIV = 'wp_ajax_nopriv_';

    /**
     * @var Request
     */
    protected Request $request;

    /**
     * @param Request $request
     */
    public function __construct(Request $request)
    {
        $this->request = $request;
    }

    /**
     * @return array<int, mixed>
     */
    public function routes(): array
    {
        $adminAuth = [new AdminPermissionsMiddleware()];
        $editorAuth = [new EditorPermissionsMiddleware()];
        $authWithNonce = [new AdminPermissionsMiddleware(), new AjaxNonceVerifierMiddleware()];
        $public = [];

        return [
            // A
            $this->route('analyzeFileAction', FileController::class, $adminAuth), // @lite-strip-line
            $this->route('assocPostTypeToTaxonomyAction', CustomPostTypeController::class, $adminAuth),
            $this->route('assocTaxonomyToPostTypeAction', CustomPostTypeController::class, $adminAuth),

            // B
            $this->route('bulkActionsAction', BulkActionController::class, $adminAuth),

            // C
            $this->route('cacheConnectionTestAction', CacheController::class, $adminAuth),
            $this->route('cacheStatsAction', CacheController::class, $adminAuth),
            $this->route('checkBlockNameAction', WordPressController::class, $adminAuth), // @lite-strip-line
            $this->route('checkIsVisibleAction', MetaController::class, $public, true), // @lite-strip-line
            $this->route('checkIsVisibleAction', MetaController::class, $adminAuth), // @lite-strip-line
            $this->route('checkMetaBoxFieldNameAction', MetaController::class, $adminAuth),
            $this->route('checkMetaBoxNameAction', MetaController::class, $adminAuth),
            $this->route('checkPostTypeNameAction', WordPressController::class, $adminAuth),
            $this->route('checkTableNameAction', TableController::class, $adminAuth), // @lite-strip-line
            $this->route('checkTaxonomySlugAction', TaxonomyController::class, $adminAuth),
            $this->route('checkTwigCodeAction', WordPressController::class, $adminAuth), // @lite-strip-line
            $this->route('copyMetaBlockAction', MetaController::class, $adminAuth), // @lite-strip-line
            $this->route('copyMetaBlocksAction', MetaController::class, $adminAuth), // @lite-strip-line
            $this->route('copyMetaBoxAction', MetaController::class, $adminAuth),
            $this->route('copyMetaBoxesAction', MetaController::class, $adminAuth),
            $this->route('copyMetaFieldAction', MetaController::class, $adminAuth),
            $this->route('copyMetaFieldsAction', MetaController::class, $adminAuth),
            $this->route('copyOptionPageAction', OptionPageController::class, $adminAuth), // @lite-strip-line
            $this->route('copyOptionPagesAction', OptionPageController::class, $adminAuth), // @lite-strip-line
            $this->route('copyTableColumnAction', TableController::class, $adminAuth), // @lite-strip-line
            $this->route('createPostAndLinkItAction', CustomPostTypeController::class, $editorAuth), // @lite-strip-line

            // D
            $this->route('deactivateLicenseAction', LicenseController::class, $adminAuth), // @lite-strip-line
            $this->route('deleteApiKeyAction', ApiKeysController::class, $adminAuth), // @lite-strip-line
            $this->route('deleteBlockAction', WordPressController::class, $adminAuth), // @lite-strip-line
            $this->route('deleteCacheItemAction', CacheController::class, $adminAuth),
            $this->route('deleteCustomPostTypeAction', CustomPostTypeController::class, $adminAuth),
            $this->route('deleteDatasetAction', DatasetController::class, $adminAuth), // @lite-strip-line
            $this->route('deleteFormAction', FormController::class, $adminAuth), // @lite-strip-line
            $this->route('deleteMetaAction', MetaController::class, $adminAuth),
            $this->route('deleteMetaFieldValueAction', MetaController::class, $adminAuth), // @lite-strip-line
            $this->route('deleteOptionPagesAction', OptionPageController::class, $adminAuth), // @lite-strip-line
            $this->route('deletePageAction', OptionPageController::class, $adminAuth), // @lite-strip-line
            $this->route('deleteTableAction', TableController::class, $adminAuth), // @lite-strip-line
            $this->route('deleteTableGroupAction', TableGroupController::class, $adminAuth), // @lite-strip-line
            $this->route('deleteTableRecordAction', TableController::class, $adminAuth), // @lite-strip-line
            $this->route('deleteTableTemplateAction', TableController::class, $adminAuth), // @lite-strip-line
            $this->route('deleteTaxonomyAction', TaxonomyController::class, $adminAuth),
            $this->route('deleteWPMLConfigAction', IntegrationController::class, $adminAuth), // @lite-strip-line
            $this->route('doShortcodeAction', MetaController::class, $editorAuth),
            $this->route('duplicateAction', BulkActionController::class, $adminAuth),
            // @lite-strip-start

            // E
            $this->route('emailTemplatePreviewAction', FormController::class, $adminAuth),
            $this->route('evaluateCodeAction', MetaController::class, $public, true),
            $this->route('evaluateCodeAction', MetaController::class, $adminAuth),
            $this->route('exportCodeAction', MetaController::class, $adminAuth),
            $this->route('exportFileAction', FileController::class, $adminAuth),
            // @lite-strip-end

            // F
            $this->route('fetchAllFindBelongsAction', MetaController::class, $editorAuth),
            $this->route('fetchAllMetaAction', MetaController::class, $editorAuth),
            $this->route('fetchApiKeysAction', ApiKeysController::class, $adminAuth), // @lite-strip-line
            $this->route('fetchApiKeysCountAction', ApiKeysController::class, $adminAuth), // @lite-strip-line
            $this->route('fetchAttachmentsAction', WordPressController::class, $adminAuth),
            $this->route('fetchBlockBindingValuesAction', MetaController::class, $editorAuth), // @lite-strip-line
            $this->route('fetchBlocksAction', WordPressController::class, $adminAuth), // @lite-strip-line
            $this->route('fetchChangelogAction', LicenseController::class, $adminAuth), // @lite-strip-line
            $this->route('fetchCommentsAction', WordPressController::class, $adminAuth),
            $this->route('fetchCustomPostTypesAction', CustomPostTypeController::class, $adminAuth),
            $this->route('fetchDatasetsAction', DatasetController::class, $adminAuth), // @lite-strip-line
            $this->route('fetchElementsAction', MetaController::class, $editorAuth),
            $this->route('fetchFindAction', MetaController::class, $editorAuth),
            $this->route('fetchFindFromBelongsToAction', MetaController::class, $editorAuth),
            // @lite-strip-start
            $this->route('fetchFormFieldsAction', FormController::class, $adminAuth),
            $this->route('fetchFormPreviewElementAction', FormController::class, $adminAuth),
            $this->route('fetchFormSubmissionsAction', FormController::class, $adminAuth),
            $this->route('fetchFormsAction', FormController::class, $adminAuth),
            $this->route('fetchHeadersAndFootersAction', FormController::class, $adminAuth),
            $this->route('fetchTableColumnsForFormAction', FormController::class, $adminAuth),
            $this->route('fetchLicenseAction', LicenseController::class, $adminAuth),
            $this->route('fetchLogsAction', LicenseController::class, $adminAuth),
            // @lite-strip-end
            $this->route('fetchMetaAction', MetaController::class, $editorAuth),
            $this->route('fetchMetaFieldAction', MetaController::class, $editorAuth),
            $this->route('fetchMetaFieldsFlatMapAction', MetaController::class, $editorAuth),
            $this->route('fetchMetaFieldsFromBelongsToAction', MetaController::class, $editorAuth),
            $this->route('fetchMetaKeysAction', MetaController::class, $adminAuth), // @lite-strip-line
            $this->route('fetchCCTColumnValueAction', MetaController::class, $editorAuth), // @lite-strip-line
            $this->route('fetchMetaValueAction', MetaController::class, $editorAuth),
            $this->route('fetchOptionPageAction', OptionPageController::class, $adminAuth), // @lite-strip-line
            $this->route('fetchOptionPagesAction', OptionPageController::class, $adminAuth), // @lite-strip-line
            $this->route('fetchOptionPagesMetaAction', OptionPageController::class, $adminAuth), // @lite-strip-line
            $this->route('fetchPageTemplatesAction', WordPressController::class, $adminAuth),
            $this->route('fetchPermissionAction', PermissionController::class, $adminAuth), // @lite-strip-line
            $this->route('fetchPostStatusesAction', WordPressController::class, $adminAuth),
            $this->route('fetchPostTypeTaxonomiesAction', CustomPostTypeController::class, $editorAuth),
            $this->route('fetchPostTypePostsAction', WordPressController::class, $editorAuth),
            $this->route('fetchPostTypesAction', WordPressController::class, $editorAuth),
            $this->route('fetchPreviewLinkAction', MetaController::class, $adminAuth),
            $this->route('fetchRegisteredTaxonomiesAction', TaxonomyController::class, $editorAuth),
            $this->route('fetchSettingsAction', PermissionController::class, $adminAuth),
            // @lite-strip-start
            $this->route('fetchTableRecordsAction', TableController::class, $adminAuth),
            $this->route('fetchTableStatsAction', TableController::class, $adminAuth),
            $this->route('fetchTablesAction', TableController::class, $adminAuth),
            $this->route('fetchTableGroupsAction', TableGroupController::class, $adminAuth),
            $this->route('fetchTableTemplatesAction', TableController::class, $adminAuth),
            // @lite-strip-end
            $this->route('fetchTaxonomiesAction', TaxonomyController::class, $adminAuth),
            $this->route('fetchTermsAction', TaxonomyController::class, $editorAuth),
            $this->route('fetchUsersAction', WordPressController::class, $editorAuth),
            $this->route('flushCacheAction', CacheController::class, $adminAuth),

            // G
            // @lite-strip-start
            $this->route('generateApiKeyAction', ApiKeysController::class, $adminAuth),
            $this->route('generateEmbedAction', MetaController::class, $editorAuth),
            $this->route('generateFlexibleBlockAction', MetaController::class, $editorAuth),
            $this->route('generateFlexibleGroupedFieldsAction', MetaController::class, $editorAuth),
            // Public for logged-in users too: the no-priv route already serves anyone, and an
            // admin-only check kept editors (and logged-in form users) from adding rows (#1408)
            $this->route('generateGroupedFieldsAction', MetaController::class, $public, true),
            $this->route('generateGroupedFieldsAction', MetaController::class, $public),
            // @lite-strip-end
            $this->route('generateGutenbergTemplateAction', MetaController::class, $adminAuth),
            // @lite-strip-start
            $this->route('generateIdAction', MetaController::class, $public, true),
            $this->route('generateIdAction', MetaController::class, $public),
            // Editor level, like fetchTermsAction/fetchUsersAction: with the admin-only check the
            // Post/Term/User selects stayed on "Loading..." for every non-admin user (#1412)
            $this->route('generateRelationalFieldOptionsAction', MetaController::class, $editorAuth),
            $this->route('getRepeaterDataAction', MetaController::class, $editorAuth),
            // @lite-strip-end
            $this->route('globalSettingsAction', GlobalsController::class, $adminAuth),

            // H
            $this->route('healthCheckAction', GlobalsController::class, $adminAuth),

            // I
            $this->route('importDatasetAction', DatasetController::class, $adminAuth), // @lite-strip-line
            $this->route('importSettingsAction', FileController::class, $adminAuth), // @lite-strip-line
            $this->route('installMissingDependenciesAction', LicenseController::class, $adminAuth), // @lite-strip-line
            $this->route('isBBThemeBuilderActiveAction', IntegrationController::class, $adminAuth), // @lite-strip-line
            $this->route('isOxygenBuilderActiveAction', IntegrationController::class, $adminAuth), // @lite-strip-line
            $this->route('isWPGraphQLActiveAction', IntegrationController::class, $adminAuth), // @lite-strip-line

            // L
            // Any logged-in user: the field scripts load on every edit screen, and the
            // translations they fetch are not admin data (#1412)
            $this->route('languagesAction', LicenseController::class, $public),
            // @lite-strip-start

            // M
            $this->route('mathEvalAction', MetaController::class, $editorAuth),
            // @lite-strip-end

            // R
            $this->route('regeneratePostLabelsAction', CustomPostTypeController::class, $adminAuth),
            $this->route('regenerateTaxonomyLabelsAction', TaxonomyController::class, $adminAuth),
            $this->route('resetCustomPostTypesAction', CustomPostTypeController::class, $adminAuth),
            $this->route('resetTaxonomiesAction', TaxonomyController::class, $adminAuth),
            $this->route('runRepairAction', GlobalsController::class, $adminAuth),

            // S
            $this->route('saveBlockAction', WordPressController::class, $adminAuth), // @lite-strip-line
            $this->route('saveBlockBindingValuesAction', MetaController::class, $authWithNonce), // @lite-strip-line
            $this->route('saveCustomPostTypeAction', CustomPostTypeController::class, $adminAuth),
            $this->route('saveDatasetAction', DatasetController::class, $adminAuth), // @lite-strip-line
            $this->route('saveFormAction', FormController::class, $adminAuth), // @lite-strip-line
            $this->route('saveFormFieldsAction', FormController::class, $adminAuth), // @lite-strip-line
            $this->route('saveFormSubmissionAction', FormController::class, $adminAuth), // @lite-strip-line
            $this->route('saveMetaAction', MetaController::class, $adminAuth),
            $this->route('saveMetaFieldValueAction', MetaController::class, $adminAuth), // @lite-strip-line
            $this->route('saveOptionPagesAction', OptionPageController::class, $adminAuth), // @lite-strip-line
            $this->route('savePermissionAction', PermissionController::class, $adminAuth), // @lite-strip-line
            $this->route('saveSettingsAction', PermissionController::class, $authWithNonce),
            $this->route('saveTableAction', TableController::class, $adminAuth), // @lite-strip-line
            $this->route('saveTableGroupAction', TableGroupController::class, $adminAuth), // @lite-strip-line
            $this->route('saveTableRecordAction', TableController::class, $adminAuth), // @lite-strip-line
            $this->route('saveTableTemplate', TableController::class, $adminAuth), // @lite-strip-line
            $this->route('saveTaxonomyAction', TaxonomyController::class, $adminAuth),
            $this->route('saveWPMLConfigAction', IntegrationController::class, $adminAuth), // @lite-strip-line
            $this->route('sluggifyAction', WordPressController::class, $editorAuth),
            $this->route('syncPostsAction', CustomPostTypeController::class, $adminAuth),
            $this->route('syncTaxonomiesAction', TaxonomyController::class, $adminAuth),
            // @lite-strip-start

            // T
            $this->route('tableSchemaAction', TableController::class, $adminAuth),

            // W
            $this->route('wpmlConfigAction', IntegrationController::class, $adminAuth),
            // @lite-strip-end
        ];
    }

    /**
     * @param string                           $action
     * @param class-string<AbstractController> $controllerClass
     * @param array<int, mixed>                $middlewares
     * @param bool                             $isNoPriv
     * @return array{0: string, 1: class-string<AbstractController>, 2: string, 3: array<int, mixed>}
     */
    protected function route(string $action, string $controllerClass, array $middlewares = [], bool $isNoPriv = false): array
    {
        return [$this->prefixAction($action, $isNoPriv), $controllerClass, $action, $middlewares];
    }

    /**
     * Prefixes the given action with a predefined constant based on the privilege flag.
     *
     * @param string $action
     * @param bool $isNoPriv
     * @return string
     */
    protected function prefixAction(string $action, bool $isNoPriv = false): string
    {
        if ($isNoPriv) {
            return self::ACTION_PREFIX_NO_PRIV . $action;
        }

        return self::ACTION_PREFIX . $action;
    }
}
