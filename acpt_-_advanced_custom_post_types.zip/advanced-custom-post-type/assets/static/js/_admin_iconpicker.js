import {$$, useTranslation} from "./_admin_commons.js";
import {determineSVGAspectRatio} from "./_admin_helpers.js";

var $ = jQuery.noConflict();
const ICONIFY_API_ROOT = 'https://api.iconify.design/';

// SVG markup of the icons already fetched, keyed by "prefix:name".
// Loading every result as its own "<prefix>/<name>.svg" made ~96 requests per
// search, and Iconify answers 429 (rate limited, without CORS headers) after a
// few searches: broken images, and icons that could no longer be picked (#1413).
// Results are now fetched in one "<prefix>.json?icons=..." request per icon set.
const iconSvgCache = {};

/**
 * @param {object} data the "<prefix>.json" response
 * @param {string} name
 * @return {string|null}
 */
const iconifyDataToSvg = (data, name) => {
    let icon = data.icons ? data.icons[name] : null;

    // aliases point to another icon of the same set
    if(!icon && data.aliases && data.aliases[name] && data.icons){
        icon = data.icons[data.aliases[name].parent];
    }

    if(!icon || !icon.body){
        return null;
    }

    const left = icon.left ?? data.left ?? 0;
    const top = icon.top ?? data.top ?? 0;
    const width = icon.width ?? data.width ?? 16;
    const height = icon.height ?? data.height ?? 16;

    return `<svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="${left} ${top} ${width} ${height}">${icon.body}</svg>`;
};

/**
 * Fetch the SVG markup of the given icons ("prefix:name"), one request per icon set.
 *
 * @param {string[]} icons
 * @return {Promise<void>}
 */
const fetchIconSvgs = (icons) => {
    const byPrefix = {};

    icons.forEach((icon) => {
        const [prefix, name] = icon.split(':');

        if(prefix && name && !iconSvgCache[icon]){
            (byPrefix[prefix] = byPrefix[prefix] || []).push(name);
        }
    });

    return Promise.all(Object.keys(byPrefix).map((prefix) => {
        return fetch(`${ICONIFY_API_ROOT}${encodeURIComponent(prefix)}.json?icons=${byPrefix[prefix].map(encodeURIComponent).join(',')}`)
            .then((response) => response.ok ? response.json() : null)
            .then((data) => {
                if(!data){
                    return;
                }

                byPrefix[prefix].forEach((name) => {
                    const svg = iconifyDataToSvg(data, name);

                    if(svg){
                        iconSvgCache[`${prefix}:${name}`] = svg;
                    }
                });
            })
            .catch((error) => console.error(error));
    }));
};

export const handleIconFieldsEvents = () => {

    // open the modal
    $('body').on('click', '.acpt-icon-picker-button', function(e) {
        e.preventDefault();

        const $this = $(this);

        const targetId = $this.data('target-id');
        const targetModalId = targetId+'_modal';
        const targetModal = $$('#'+targetModalId);
        console.log(targetModalId);

        (targetModal.hasClass('hidden')) ? targetModal.removeClass('hidden') : targetModal.addClass('hidden');
    });

    // choose between upload or browse icons
    $('body').on('click', '.acpt-icon-picker-selector > li', function(e){
        e.preventDefault();

        const $this = $(this);
        const selector = $this.parent('ul');
        const value = $this.data('value');

        if(value === 'upload'){
            selector.siblings(".acpt-icon-picker-upload").removeClass('hidden');
            selector.addClass("hidden");
        } else if(value === 'browse'){
            selector.siblings(".acpt-icon-picker-browse").removeClass('hidden');
            selector.addClass("hidden");
        }

        selector.prev(".acpt-icon-picker-back").removeClass('hidden');
    });

    // back to selector
    $('body').on('click', '.acpt-icon-picker-back', function(e){
        e.preventDefault();

        const $this = $(this);
        const selector = $this.next('ul');
        $this.addClass('hidden');
        selector.siblings(".acpt-icon-picker-upload").addClass('hidden');
        selector.siblings(".acpt-icon-picker-browse").addClass('hidden');
        selector.removeClass("hidden");
    });

    // change icon size
    $('body').on('change', '.acpt-icon-picker-size > input', function(e) {
        e.preventDefault();

        const $this = $(this);
        const targetId = $this.data('target-id');
        let svg = $(`.acpt-icon-picker-preview[data-target-id="${targetId}"]`).html();
        const aspectRatio = determineSVGAspectRatio(svg);
        const width = $this.val();
        const height = Math.ceil(width * aspectRatio);
        const widthPattern = /width=\"(.*?)\"/;
        const heightPattern = /height=\"(.*?)\"/;
        const checkWidthProp = widthPattern.test(svg);
        const checkHeightProp = heightPattern.test(svg);

        if(checkWidthProp && checkHeightProp){
            svg = svg.replace(widthPattern, `width="${width}px"`);
            svg = svg.replace(heightPattern, `height="${height}px"`);
        } else {
            svg = svg.replace("<svg ", `<svg width="${width}px" `);
            svg = svg.replace("<svg ", `<svg height="${height}px" `);
        }

        $(`.acpt-icon-picker-preview[data-target-id="${targetId}"]`).html(svg);
        $(`.acpt-icon-picker-value[data-target-id="${targetId}"]`).val(svg);
    });

    // clear icon field
    $('body').on('click', '.acpt-icon-picker-delete', function(e) {
        e.preventDefault();

        const $this = $(this);
        const targetId = $this.data('target-id');

        $(`.acpt-icon-picker-preview[data-target-id="${targetId}"]`).html('');
        $(`#${targetId}`).val('');
        $this.addClass('hidden');
        $(`.acpt-icon-picker-preview-wrapper[data-target-id="${targetId}"]`).addClass('hidden');
        $(`.acpt-icon-picker-size[data-target-id="${targetId}"]`).addClass('hidden');
        $(`.acpt-icon-picker-stroke[data-target-id="${targetId}"]`).addClass('hidden');
        $(`.acpt-icon-picker-fill[data-target-id="${targetId}"]`).addClass('hidden');
    });

    // upload a custom SVG icon
    $('body').on('change', '.acpt-icon-picker-upload > input', function(e) {
        e.preventDefault();

        const $this = $(this);
        const targetId = $this.data('target-id');
        const file =  $this.prop('files')[0];
        const read = new FileReader();

        read.readAsBinaryString(file);
        read.onloadend = function(){
            const svgString = read.result;
            const parser = new DOMParser();
            const doc = parser.parseFromString(svgString, "image/svg+xml");
            const svg = doc.querySelector("svg").outerHTML;

            $(`.acpt-icon-picker-value[data-target-id="${targetId}"]`).val(svg);
            const targetModal = $('#'+targetId+'_modal');
            $('.acpt-icon-picker-preview[data-target-id="'+targetId+'"]').html(svg);
            $(`.acpt-icon-picker-preview-wrapper[data-target-id="${targetId}"]`).removeClass('hidden');
            $(`.acpt-icon-picker-size[data-target-id="${targetId}"]`).removeClass('hidden');
            $(`.acpt-icon-picker-stroke[data-target-id="${targetId}"]`).removeClass('hidden');
            $(`.acpt-icon-picker-fill[data-target-id="${targetId}"]`).removeClass('hidden');
            $(`.acpt-icon-picker-size[data-target-id="${targetId}"] > input`).val('24');
            $(`input.acpt-icon-picker-stroke[data-target-id="${targetId}"]`).val('#777777');
            $(`input.acpt-icon-picker-fill[data-target-id="${targetId}"]`).val('#777777');
            (targetModal.hasClass('hidden')) ? targetModal.removeClass('hidden') : targetModal.addClass('hidden');
        }
    });

    // browse icons
    $('body').on('click', '.acpt-icon-picker-provider', function (e) {

        const $this = $(this);
        ($this.hasClass('active')) ? $this.removeClass('active') : $this.addClass('active');

        let visibleProviders = [];
        $('.acpt-icon-picker-provider.active').each(function() {
            const provider =  $(this).data('value');
            visibleProviders.push(provider);
        });

        $('.acpt-icon-picker-icon').each(function () {
            const provider =  $(this).data('prefix');
            const $this = $(this);

            if(visibleProviders.length > 0){
                (visibleProviders.includes(provider)) ? $this.removeClass('hidden') : $this.addClass('hidden');
            } else {
                $this.removeClass('hidden');
            }
        });
    });

    // search icons
    // Debounced, and only the latest query renders: a search on every keystroke
    // loaded ~96 icon images each time, and the Iconify API answered with 429
    // (rate limited) after a few searches, leaving broken images and icons that
    // could no longer be picked (#1409).
    let searchTimer = null;
    let searchRequest = null;

    $('body').on('input', '.acpt-icon-picker-search', function(e) {

        const $this = $(this);
        const search = e.target.value.trim();
        const results = $this.next('.acpt-icon-picker-results');
        const targetId = results.data('target-id');

        clearTimeout(searchTimer);

        if(searchRequest){
            searchRequest.abort();
            searchRequest = null;
        }

        if(search.length < 3){
            return;
        }

        searchTimer = setTimeout(function() {
            searchRequest = $.ajax({
                type: 'GET',
                url: `${ICONIFY_API_ROOT}search?query=${encodeURIComponent(search)}&limit=96`,
                success: async function(data) {
                    searchRequest = null;

                    // a newer query was typed meanwhile
                    if($this.val().trim() !== search){
                        return;
                    }

                    const icons = Array.isArray(data.icons) ? data.icons : [];
                    await fetchIconSvgs(icons);

                    if($this.val().trim() !== search){
                        return;
                    }

                    results.html('');

                    // create the filter by provider
                    if(data.collections){

                        const providers = Object.keys(data.collections).sort();
                        let providerFilter = `<div class="acpt-icon-picker-providers">`;

                        providers.forEach((provider) => {
                            if(data.collections[provider] && data.collections[provider]?.name){
                                providerFilter += `<div data-target-id="${targetId}" data-value="${provider}" class="acpt-icon-picker-provider">${data.collections[provider]?.name}</div>`;
                            }
                        });

                        providerFilter += `</div>`;

                        results.append(providerFilter);
                    }

                    // append icons
                    const found = icons.filter((icon) => iconSvgCache[icon]);

                    if(found.length > 0){
                        found.forEach((icon)=>{
                            const prefix = icon.split(':')[0];
                            const svg = iconSvgCache[icon].replace('width="1em" height="1em"', 'width="32" height="32" aria-hidden="true"');
                            results.append(`<div data-target-id="${targetId}" data-value="${icon}" data-prefix="${prefix}" class="acpt-icon-picker-icon" title="${icon}">${svg}</div>`);
                        });
                    } else if(icons.length > 0) {
                        results.append(`<div>${useTranslation("There was an error fetching icons, retry later.")}</div>`);
                    } else {
                        results.append(`<div>${useTranslation("Sorry, no result match.")}</div>`);
                    }

                    const deleteButton = $(`.acpt-icon-picker-delete[data-target-id="${targetId}"]`);
                    deleteButton.removeClass('hidden');
                },
                error: function(xhr) {
                    searchRequest = null;

                    if(xhr.statusText === 'abort'){
                        return;
                    }

                    console.error(xhr);
                    results.html(useTranslation("There was an error fetching icons, retry later."));
                },
            });
        }, 400);
    });

    // pick ad icon from iconify
    $('body').on('click', '.acpt-icon-picker-icon', function(e) {
        e.preventDefault();

        const $this = $(this);
        const value = $this.data('value');
        const targetId = $this.data('target-id');
        const iconSplitted = value.split(':');
        const prefix = iconSplitted[0];
        const iconName = iconSplitted[1];
        const svgUrl = `${ICONIFY_API_ROOT}${prefix}/${iconName}.svg`;

        const applyIcon = function(svg) {
            const aspectRatio = determineSVGAspectRatio(svg);
            const width = 24;
            const height = Math.ceil(width * aspectRatio);

            svg = svg.replace(/width=\"(.*?)\"/, `width="${width}px"`);
            svg = svg.replace(/height=\"(.*?)\"/, `height="${height}px"`);
            $(`.acpt-icon-picker-value[data-target-id="${targetId}"]`).val(svg);
            const targetModal = $('#'+targetId+'_modal');
            $('.acpt-icon-picker-preview[data-target-id="'+targetId+'"]').html(svg);
            $(`.acpt-icon-picker-preview-wrapper[data-target-id="${targetId}"]`).removeClass('hidden');
            $(`.acpt-icon-picker-size[data-target-id="${targetId}"]`).removeClass('hidden');
            $(`.acpt-icon-picker-stroke[data-target-id="${targetId}"]`).removeClass('hidden');
            $(`.acpt-icon-picker-fill[data-target-id="${targetId}"]`).removeClass('hidden');
            $(`.acpt-icon-picker-size[data-target-id="${targetId}"] > input`).val('24');
            $(`input.acpt-icon-picker-stroke[data-target-id="${targetId}"]`).val('#777777');
            $(`input.acpt-icon-picker-fill[data-target-id="${targetId}"]`).val('#777777');
            (targetModal.hasClass('hidden')) ? targetModal.removeClass('hidden') : targetModal.addClass('hidden');
        };

        // the markup is already here from the search: no request needed
        if(iconSvgCache[value]){
            applyIcon(iconSvgCache[value]);

            return;
        }

        $.ajax({
            type: 'GET',
            url: svgUrl,
            success: function(data) {
                applyIcon(data.children[0].outerHTML);
            },
            error: function(error) {
                console.error(error);

                $(`.acpt-icon-picker-results[data-target-id="${targetId}"]`).append(`<div>${useTranslation("There was an error fetching icons, retry later.")}</div>`);
            },
        });
    });

    // close icon picker
    $('body').on('click', '.close-acpt-icon-picker', function(e) {
        e.preventDefault();

        const $this = $(this);
        const targetModalId = $this.data('target-id');
        const targetModal = $$('#'+targetModalId);

        (targetModal.hasClass('hidden')) ? targetModal.removeClass('hidden') : targetModal.addClass('hidden');
    });
};
