<?php

/**
 * **************************
 * Settings
 * **************************
 */
require_once __DIR__.'/_inc/settings/blocks.php'; // @lite-strip-line
require_once __DIR__.'/_inc/settings/forms.php'; // @lite-strip-line
require_once __DIR__.'/_inc/settings/posts.php';
require_once __DIR__.'/_inc/settings/tax.php';
require_once __DIR__.'/_inc/settings/option_pages.php'; // @lite-strip-line
require_once __DIR__.'/_inc/settings/meta.php';
require_once __DIR__.'/_inc/settings/tables.php'; // @lite-strip-line
require_once __DIR__.'/_inc/settings/table_groups.php'; // @lite-strip-line

/**
 * **************************
 * Values
 * **************************
 */
require_once __DIR__.'/_inc/values/meta_get.php';
require_once __DIR__.'/_inc/values/meta_set.php';
