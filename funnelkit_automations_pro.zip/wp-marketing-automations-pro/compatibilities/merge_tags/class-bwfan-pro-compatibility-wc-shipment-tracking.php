<?php

#[\AllowDynamicProperties]
class BWFAN_WC_Shipment_Tracking extends BWFAN_Merge_Tag {

	private static $instance = null;

	public function __construct() {
		$this->tag_name        = 'wc_shipment_tracking';
		$this->tag_description = __( 'WooCommerce Shipment Tracking details', 'wp-marketing-automations-pro' );
		add_shortcode( 'bwfan_wc_shipment_tracking', array( $this, 'parse_shortcode' ) );
	}

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Show the html in popup for the merge tag.
	 */
	public function get_view() {
		$tracking_fields = $this->get_view_data();
		$this->get_back_button();
		?>
        <div class="bwfan_mtag_wrap">
            <div class="bwfan_label">
                <label for="" class="bwfan-label-title"><?php esc_html_e( 'Select Shipment Tracking Field', 'wp-marketing-automations-pro' ); ?></label>
            </div>
            <div class="bwfan_label_val">
                <select id="" class="bwfan-input-wrapper bwfan_tag_select" name="data">
					<?php
					foreach ( $tracking_fields as $slug => $name ) {
						echo '<option value="' . esc_attr( $slug ) . '">' . esc_html( $name ) . '</option>';
					}
					?>
                </select>
            </div>
        </div>
		<?php

		$this->date_format();

		if ( $this->support_fallback ) {
			$this->get_fallback();
		}

		$this->get_preview();
		$this->get_copy_button();
	}

	public function get_view_data() {
		return array(
			'tracking_number'             => __( 'Tracking Number', 'wp-marketing-automations-pro' ),
			'formatted_tracking_provider' => __( 'Tracking Provider', 'wp-marketing-automations-pro' ),
			'formatted_tracking_link'     => __( 'Tracking Link', 'wp-marketing-automations-pro' ),
			'date_shipped'                => __( 'Date Shipped', 'wp-marketing-automations-pro' ),
			'shipping_formatted'          => __( 'Formatted', 'wp-marketing-automations-pro' ),
		);
	}

	/**
	 * Parse the merge tag and return its value.
	 *
	 * @param $attr
	 *
	 * @return mixed|string|void
	 */
	public function parse_shortcode( $attr ) {
		$item_key = ( isset( $attr['data'] ) && ! empty( $attr['data'] ) ) ? $attr['data'] : 'tracking_number';

		$date_format = get_option( 'date_format', 'Y-m-d' );
		$parameters  = array(
			'format' => ! empty( $attr['format'] ) ? $attr['format'] : $date_format,
		);
		if ( isset( $attr['modify'] ) && ! empty( $attr['modify'] ) ) {
			$parameters['modify'] = $attr['modify'];
		}
		$parameters['is_gmt'] = ! empty( $attr['is_gmt'] ) && 'false' !== $attr['is_gmt'];

		if ( true === BWFAN_Merge_Tag_Loader::get_data( 'is_preview' ) ) {
			return $this->get_dummy_preview( $item_key, $parameters );
		}

		$order_id = absint( BWFAN_Merge_Tag_Loader::get_data( 'wc_order_id' ) );
		$order_id = empty( $order_id ) && ! empty( BWFAN_Merge_Tag_Loader::get_data( 'order_id' ) ) ? BWFAN_Merge_Tag_Loader::get_data( 'order_id' ) : $order_id;
		if ( empty( $order_id ) ) {
			return '';
		}

		$tracking_items = wc_shipment_tracking()->actions->get_tracking_items( $order_id, true );
		if ( count( $tracking_items ) < 1 ) {
			return '';
		}

		if ( 'shipping_formatted' === $item_key ) {
			$return_value = $this->get_formatted_shipping( $tracking_items, $parameters );

			return $this->parse_shortcode_output( $return_value, $attr );
		}

		$return_value = 'date_shipped' === $item_key ? implode( ', ', array_map( function ( $item ) use ( $parameters ) {
			return $this->format_shipped_date( $item['date_shipped'], $parameters );
		}, $tracking_items ) ) : implode( ', ', array_column( $tracking_items, $item_key ) );

		return $this->parse_shortcode_output( $return_value, $attr );
	}

	/**
	 * Format a shipped date in store time, or in GMT when is_gmt is set
	 *
	 * A shipped date picked in WCST is stored as midnight UTC of that day, and WCST shows that day on every
	 * site. Such a date keeps its calendar day in store time too, instead of moving to the previous day on
	 * sites west of UTC. A shipped date added without a day (the moment it was added) converts like any other.
	 *
	 * @param int $timestamp Shipped date as stored by WCST.
	 * @param array $parameters Date formatting parameters (format, modify, is_gmt).
	 *
	 * @return string
	 */
	public function format_shipped_date( $timestamp, $parameters ) {
		$is_gmt = ! empty( $parameters['is_gmt'] );

		if ( ! $is_gmt && ! empty( $timestamp ) && is_numeric( $timestamp ) && 0 === absint( $timestamp ) % DAY_IN_SECONDS ) {
			$timestamp = new DateTime( gmdate( 'Y-m-d', absint( $timestamp ) ), wp_timezone() );
		}

		return $this->format_datetime( $timestamp, $parameters, $is_gmt );
	}

	/**
	 * Format shipping information.
	 *
	 * @param array $tracking_items Tracking items array.
	 * @param array|string $parameters Date formatting parameters (format, modify, is_gmt), or just a date format.
	 *
	 * @return string Formatted shipping information.
	 */
	public function get_formatted_shipping( $tracking_items, $parameters ) {
		$parameters = is_array( $parameters ) ? $parameters : array( 'format' => $parameters );

		$formatted_shipping = array_map( function ( $item ) use ( $parameters ) {
			$output = "{$item['formatted_tracking_provider']} ({$item['tracking_number']})";
			$output .= "\n{$item['formatted_tracking_link']}";
			$output .= "\n" . $this->format_shipped_date( $item['date_shipped'], $parameters );

			return $output;
		}, $tracking_items );

		return implode( "\n\n", $formatted_shipping );
	}

	/**
	 * Show dummy value of the current merge tag.
	 *
	 * @param string $item_key Shipment tracking field key.
	 * @param array  $parameters Date formatting parameters.
	 *
	 * @return string
	 */
	public function get_dummy_preview( $item_key = 'tracking_number', $parameters = [] ) {
		switch ( $item_key ) {
			case 'tracking_number':
				return '123456789';
			case 'formatted_tracking_provider':
				return 'UPS';
			case 'formatted_tracking_link':
				return 'https://example.com/track/123456789';
			case 'date_shipped':
				return $this->format_datetime( time(), $parameters, ! empty( $parameters['is_gmt'] ) );
			case 'shipping_formatted':
				return "UPS (123456789)\nhttps://example.com/track/123456789\n" . $this->format_datetime( time(), $parameters, ! empty( $parameters['is_gmt'] ) );
			default:
				return '';
		}
	}

	/**
	 * Return merge tag schema
	 *
	 * @return array[]
	 */
	public function get_setting_schema() {
		$tracking_data = $this->get_view_data();
		$options       = [];
		foreach ( $tracking_data as $track_key => $data ) {
			$options[] = [
				'value' => $track_key,
				'label' => $data,
			];
		}

		$date_formats = [];
		foreach ( $this->date_formats as $data ) {
			if ( isset( $data['format'] ) ) {
				$date_formats[] = [
					'value' => $data['format'],
					'label' => wp_date( $data['format'] ),
				];
			}
		}

		return [
			[
				'id'          => 'data',
				'type'        => 'select',
				'options'     => $options,
				'label'       => __( 'Select Shipment Tracking Field', 'wp-marketing-automations-pro' ),
				"class"       => 'bwfan-input-wrapper',
				"placeholder" => __( 'Select', 'wp-marketing-automations-pro' ),
				"required"    => false,
				"description" => ""
			],
			[
				'id'          => 'format',
				'type'        => 'select',
				'options'     => $date_formats,
				'label'       => __( 'Select Date Format', 'wp-marketing-automations-pro' ),
				"class"       => 'bwfan-input-wrapper',
				"placeholder" => __( 'Select', 'wp-marketing-automations-pro' ),
				"required"    => false,
				"description" => "",
				'toggler'     => array(
					'fields'   => array(
						array(
							'id'    => 'data',
							'value' => 'date_shipped',
						),
						array(
							'id'    => 'data',
							'value' => 'shipping_formatted',
						),
					),
					'relation' => 'OR',
				)
			],
			[
				'id'          => 'modify',
				'label'       => __( 'Modify (Optional)', 'wp-marketing-automations-pro' ),
				'type'        => 'text',
				'class'       => '',
				'placeholder' => __( 'e.g. +2 months, -1 day, +6 hours', 'wp-marketing-automations-pro' ),
				'required'    => false,
				'toggler'     => array(
					'fields'   => array(
						array(
							'id'    => 'data',
							'value' => 'date_shipped',
						),
						array(
							'id'    => 'data',
							'value' => 'shipping_formatted',
						),
					),
					'relation' => 'OR',
				)
			],
			[
				'id'            => 'is_gmt',
				'type'          => 'checkbox',
				'checkboxlabel' => __( 'In GMT time ( Default in store time )', 'wp-marketing-automations-pro' ),
				'description'   => '',
				'toggler'       => array(
					'fields'   => array(
						array(
							'id'    => 'data',
							'value' => 'date_shipped',
						),
						array(
							'id'    => 'data',
							'value' => 'shipping_formatted',
						),
					),
					'relation' => 'OR',
				)
			],
		];
	}
}

BWFAN_Merge_Tag_Loader::register( 'wc_order', 'BWFAN_WC_Shipment_Tracking' );
