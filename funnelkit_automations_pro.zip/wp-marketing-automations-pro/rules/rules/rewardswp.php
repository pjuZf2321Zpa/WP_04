<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( function_exists( 'bwfan_is_rewardswp_active' ) && bwfan_is_rewardswp_active() ) {

	/**
	 * Rule: RewardsWP Points Balance
	 */
	#[\AllowDynamicProperties]
	class BWFAN_Rule_RWP_Points_Balance extends BWFAN_Rule_Base {

		public function __construct() {
			$this->v2 = true;
			parent::__construct( 'rwp_points_balance' );
		}

		public function get_rule_type() {
			return 'Number';
		}

		public function get_condition_input_type() {
			return 'Text';
		}

		public function is_match_v2( $automation_data, $rule_data ) {
			if ( ! isset( $automation_data['global'] ) || ! is_array( $automation_data['global'] ) ) {
				return $this->return_is_match( false, $rule_data );
			}

			$user_id = isset( $automation_data['global']['user_id'] )
				? absint( $automation_data['global']['user_id'] ) : 0;

			if ( empty( $user_id ) ) {
				return $this->return_is_match( false, $rule_data );
			}

			$balance = 0;
			if ( function_exists( 'Awesomemotive\Rewardswp\Helpers\get_member_by' ) ) {
				$member = \Awesomemotive\Rewardswp\Helpers\get_member_by( 'user_id', $user_id );
				if ( $member ) {
					$balance = intval( $member->points_balance );
				}
			}

			$value = (int) $rule_data['data'];

			switch ( $rule_data['rule'] ) {
				case '==':
					$result = $balance === $value;
					break;
				case '!=':
					$result = $balance !== $value;
					break;
				case '>':
					$result = $balance > $value;
					break;
				case '<':
					$result = $balance < $value;
					break;
				case '>=':
					$result = $balance >= $value;
					break;
				case '<=':
					$result = $balance <= $value;
					break;
				default:
					$result = false;
					break;
			}

			return $this->return_is_match( $result, $rule_data );
		}

		public function is_match( $rule_data ) {
			return false;
		}

		public function get_possible_rule_operators() {
			return array(
				'==' => __( 'is equal to', 'wp-marketing-automations-pro' ),
				'!=' => __( 'is not equal to', 'wp-marketing-automations-pro' ),
				'>'  => __( 'is greater than', 'wp-marketing-automations-pro' ),
				'<'  => __( 'is less than', 'wp-marketing-automations-pro' ),
				'>=' => __( 'is greater or equal to', 'wp-marketing-automations-pro' ),
				'<=' => __( 'is less or equal to', 'wp-marketing-automations-pro' ),
			);
		}
	}

	/**
	 * Rule: RewardsWP Member Status
	 */
	#[\AllowDynamicProperties]
	class BWFAN_Rule_RWP_Member_Status extends BWFAN_Rule_Base {

		public function __construct() {
			$this->v2 = true;
			parent::__construct( 'rwp_member_status' );
		}

		public function get_options( $term = '' ) {
			return array(
				'active'   => __( 'Active', 'wp-marketing-automations-pro' ),
				'blocked'  => __( 'Blocked', 'wp-marketing-automations-pro' ),
				'excluded' => __( 'Excluded', 'wp-marketing-automations-pro' ),
				'inactive' => __( 'Inactive', 'wp-marketing-automations-pro' ),
				'guest'    => __( 'Guest', 'wp-marketing-automations-pro' ),
			);
		}

		public function get_rule_type() {
			return 'Select';
		}

		public function get_condition_values_nice_names( $values ) {
			$status_labels = array(
				'active'   => __( 'Active', 'wp-marketing-automations-pro' ),
				'blocked'  => __( 'Blocked', 'wp-marketing-automations-pro' ),
				'excluded' => __( 'Excluded', 'wp-marketing-automations-pro' ),
				'inactive' => __( 'Inactive', 'wp-marketing-automations-pro' ),
				'guest'    => __( 'Guest', 'wp-marketing-automations-pro' ),
			);

			$return = array();
			foreach ( $values as $value ) {
				$return[ $value ] = isset( $status_labels[ $value ] ) ? $status_labels[ $value ] : $value;
			}

			return $return;
		}

		public function is_match_v2( $automation_data, $rule_data ) {
			if ( ! isset( $automation_data['global'] ) || ! is_array( $automation_data['global'] ) ) {
				return $this->return_is_match( false, $rule_data );
			}

			$user_id = isset( $automation_data['global']['user_id'] )
				? absint( $automation_data['global']['user_id'] ) : 0;

			if ( empty( $user_id ) ) {
				return $this->return_is_match( false, $rule_data );
			}

			$status = '';
			if ( function_exists( 'Awesomemotive\Rewardswp\Helpers\get_member_by' ) ) {
				$member = \Awesomemotive\Rewardswp\Helpers\get_member_by( 'user_id', $user_id );
				if ( $member ) {
					$status = $member->get_status();
				}
			}

			$data = isset( $rule_data['data'] ) ? $rule_data['data'] : '';
			$rule = isset( $rule_data['rule'] ) ? $rule_data['rule'] : '==';

			if ( is_array( $data ) ) {
				switch ( $rule ) {
					case '==':
						$result = in_array( $status, $data, true );
						break;
					case '!=':
						$result = ! in_array( $status, $data, true );
						break;
					default:
						$result = false;
						break;
				}
			} else {
				switch ( $rule ) {
					case '==':
						$result = $status === $data;
						break;
					case '!=':
						$result = $status !== $data;
						break;
					default:
						$result = false;
						break;
				}
			}

			return $this->return_is_match( $result, $rule_data );
		}

		public function is_match( $rule_data ) {
			return false;
		}
	}

	/**
	 * Rule: RewardsWP Total Referrals
	 */
	#[\AllowDynamicProperties]
	class BWFAN_Rule_RWP_Total_Referrals extends BWFAN_Rule_Base {

		public function __construct() {
			$this->v2 = true;
			parent::__construct( 'rwp_total_referrals' );
		}

		public function get_rule_type() {
			return 'Number';
		}

		public function get_condition_input_type() {
			return 'Text';
		}

		public function is_match_v2( $automation_data, $rule_data ) {
			if ( ! isset( $automation_data['global'] ) || ! is_array( $automation_data['global'] ) ) {
				return $this->return_is_match( false, $rule_data );
			}

			$user_id = isset( $automation_data['global']['user_id'] )
				? absint( $automation_data['global']['user_id'] ) : 0;

			if ( empty( $user_id ) ) {
				return $this->return_is_match( false, $rule_data );
			}

			$total_referrals = 0;
			if ( function_exists( 'Awesomemotive\Rewardswp\Helpers\get_member_by' ) ) {
				$member = \Awesomemotive\Rewardswp\Helpers\get_member_by( 'user_id', $user_id );
				if ( $member ) {
					$total_referrals = intval( $member->total_referrals );
				}
			}

			$value = (int) $rule_data['data'];

			switch ( $rule_data['rule'] ) {
				case '==':
					$result = $total_referrals === $value;
					break;
				case '!=':
					$result = $total_referrals !== $value;
					break;
				case '>':
					$result = $total_referrals > $value;
					break;
				case '<':
					$result = $total_referrals < $value;
					break;
				case '>=':
					$result = $total_referrals >= $value;
					break;
				case '<=':
					$result = $total_referrals <= $value;
					break;
				default:
					$result = false;
					break;
			}

			return $this->return_is_match( $result, $rule_data );
		}

		public function is_match( $rule_data ) {
			return false;
		}

		public function get_possible_rule_operators() {
			return array(
				'==' => __( 'is equal to', 'wp-marketing-automations-pro' ),
				'!=' => __( 'is not equal to', 'wp-marketing-automations-pro' ),
				'>'  => __( 'is greater than', 'wp-marketing-automations-pro' ),
				'<'  => __( 'is less than', 'wp-marketing-automations-pro' ),
				'>=' => __( 'is greater or equal to', 'wp-marketing-automations-pro' ),
				'<=' => __( 'is less or equal to', 'wp-marketing-automations-pro' ),
			);
		}
	}

	// Register rules
	$rwp_points_balance  = new BWFAN_Rule_RWP_Points_Balance();
	$rwp_member_status   = new BWFAN_Rule_RWP_Member_Status();
	$rwp_total_referrals = new BWFAN_Rule_RWP_Total_Referrals();
}
