<?php
/**
 * MasterStudy LMS automation rules (mirrors LearnDash-style groups).
 */
if ( ! function_exists( 'bwfan_is_masterstudy_active' ) || ! bwfan_is_masterstudy_active() ) {
	return;
}

if ( ! class_exists( 'BWFAN_Rule_Base' ) ) {
	return;
}

if ( ! function_exists( 'bwfan_masterstudy_search_rule_selected_ids' ) ) {
	/**
	 * v2 Search rule `data`: list of { key, label }, one row, or numeric id.
	 *
	 * @param mixed $data Rule value from automation UI.
	 *
	 * @return int[]
	 */
	function bwfan_masterstudy_search_rule_selected_ids( $data ) {
		$ids = array();
		if ( null === $data || '' === $data ) {
			return $ids;
		}
		if ( is_scalar( $data ) && '' !== $data && ! is_bool( $data ) && is_numeric( $data ) ) {
			$i = absint( $data );

			return $i ? array( $i ) : $ids;
		}
		if ( is_object( $data ) ) {
			$data = (array) $data;
			if ( isset( $data['key'] ) ) {
				$i = absint( $data['key'] );

				return $i ? array( $i ) : $ids;
			}
			if ( isset( $data['id'] ) ) {
				$i = absint( $data['id'] );

				return $i ? array( $i ) : $ids;
			}

			return $ids;
		}
		if ( ! is_array( $data ) ) {
			return $ids;
		}
		if ( isset( $data['key'] ) && ! array_key_exists( 0, $data ) ) {
			$i = absint( $data['key'] );

			return $i ? array( $i ) : $ids;
		}
		if ( isset( $data['id'] ) && ! array_key_exists( 0, $data ) ) {
			$i = absint( $data['id'] );

			return $i ? array( $i ) : $ids;
		}
		foreach ( $data as $item ) {
			if ( is_array( $item ) && isset( $item['key'] ) ) {
				$i = absint( $item['key'] );
			} elseif ( is_object( $item ) && isset( $item->key ) ) {
				$i = absint( $item->key );
			} elseif ( is_numeric( $item ) ) {
				$i = absint( $item );
			} else {
				continue;
			}
			if ( $i ) {
				$ids[] = $i;
			}
		}

		return array_values( array_unique( $ids, SORT_REGULAR ) );
	}
}

#[\AllowDynamicProperties]
class BWFAN_Rule_Masterstudy_Course extends BWFAN_Rule_Base {
	public function __construct() {
		$this->v2 = true;
		$this->v1 = false;
		parent::__construct( 'masterstudy_course' );
	}

	/** v2 Methods: START */

	public function get_options( $term = '' ) {
		return $this->get_possible_rule_values( $term );
	}

	public function get_rule_type() {
		return 'Search';
	}

	public function is_match_v2( $automation_data, $rule_data ) {
		if ( ! isset( $automation_data['global'] ) || ! is_array( $automation_data['global'] ) ) {
			return $this->return_is_match( false, $rule_data );
		}

		$course_id = isset( $automation_data['global']['course_id'] ) ? absint( $automation_data['global']['course_id'] ) : 0;
		$lesson_id = isset( $automation_data['global']['lesson_id'] ) ? absint( $automation_data['global']['lesson_id'] ) : 0;
		$quiz_id   = isset( $automation_data['global']['quiz_id'] ) ? absint( $automation_data['global']['quiz_id'] ) : 0;

		if ( class_exists( 'BWFAN_Masterstudy_Common' ) ) {
			$course_id = BWFAN_Masterstudy_Common::resolve_event_course_id( $course_id, $lesson_id, $quiz_id );
		}

		$course_id    = absint( $course_id );
		$selected_ids = bwfan_masterstudy_search_rule_selected_ids( isset( $rule_data['data'] ) ? $rule_data['data'] : null );
		$result       = false;
		$rule_op      = isset( $rule_data['rule'] ) ? $rule_data['rule'] : '';

		if ( empty( $selected_ids ) ) {
			return $this->return_is_match( false, $rule_data );
		}

		switch ( $rule_op ) {
			case 'is':
				$result = in_array( $course_id, $selected_ids, true );
				break;
			case 'is_not':
				$result = ! in_array( $course_id, $selected_ids, true );
				break;
			default:
				$result = false;
		}

		return $this->return_is_match( $result, $rule_data );
	}

	/** v2 Methods: END */

	public function get_possible_rule_operators() {
		return array(
			'is'     => __( 'is', 'wp-marketing-automations-pro' ),
			'is_not' => __( 'is not', 'wp-marketing-automations-pro' ),
		);
	}

	public function get_condition_input_type() {
		return 'Search';
	}

	public function get_possible_rule_values( $term = '' ) {
		$courses = array();

		if ( ! post_type_exists( 'stm-courses' ) ) {
			return $courses;
		}

		$args = array(
			'post_type'              => 'stm-courses',
			'posts_per_page'         => 20,
			'post_status'            => 'publish',
			'orderby'                => 'title',
			'order'                  => 'ASC',
			'fields'                 => 'ids',
			'no_found_rows'          => true,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
		);
		if ( ! empty( $term ) ) {
			$args['s'] = sanitize_text_field( $term );
		}

		$query = new WP_Query( $args );
		foreach ( $query->posts as $course_id ) {
			$course_id = absint( $course_id );
			if ( ! $course_id ) {
				continue;
			}
			$courses[ $course_id ] = get_the_title( $course_id ) . '(#' . $course_id . ')';
		}
		wp_reset_postdata();

		return $courses;
	}


}

#[\AllowDynamicProperties]
class BWFAN_Rule_Masterstudy_Lesson extends BWFAN_Rule_Base {
	public function __construct() {
		$this->v2 = true;
		$this->v1 = false;
		parent::__construct( 'masterstudy_lesson' );
	}

	/** v2 Methods: START */

	public function get_options( $term = '' ) {
		return $this->get_possible_rule_values( $term );
	}

	public function get_rule_type() {
		return 'Search';
	}

	public function is_match_v2( $automation_data, $rule_data ) {
		if ( ! isset( $automation_data['global'] ) || ! is_array( $automation_data['global'] ) ) {
			return $this->return_is_match( false, $rule_data );
		}
		$lesson_id    = isset( $automation_data['global']['lesson_id'] ) ? absint( $automation_data['global']['lesson_id'] ) : 0;
		$selected_ids = bwfan_masterstudy_search_rule_selected_ids( isset( $rule_data['data'] ) ? $rule_data['data'] : null );
		$result       = false;
		$rule_op      = isset( $rule_data['rule'] ) ? $rule_data['rule'] : '';

		if ( empty( $selected_ids ) ) {
			return $this->return_is_match( false, $rule_data );
		}

		switch ( $rule_op ) {
			case 'is':
				$result = in_array( $lesson_id, $selected_ids, true );
				break;
			case 'is_not':
				$result = ! in_array( $lesson_id, $selected_ids, true );
				break;
			default:
				$result = false;
				break;
		}

		return $this->return_is_match( $result, $rule_data );
	}

	/** v2 Methods: END */

	public function get_possible_rule_operators() {
		return array(
			'is'     => __( 'is', 'wp-marketing-automations-pro' ),
			'is_not' => __( 'is not', 'wp-marketing-automations-pro' ),
		);
	}

	public function get_condition_input_type() {
		return 'Search';
	}

	public function get_possible_rule_values( $term = '' ) {
		$result = array();

		if ( ! post_type_exists( 'stm-lessons' ) ) {
			return $result;
		}

		$args = array(
			'post_type'              => 'stm-lessons',
			'post_status'            => 'publish',
			'posts_per_page'         => 20,
			'orderby'                => 'title',
			'order'                  => 'ASC',
			'fields'                 => 'ids',
			'no_found_rows'          => true,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
		);
		if ( ! empty( $term ) ) {
			$args['s'] = sanitize_text_field( $term );
		}

		$query = new WP_Query( $args );
		foreach ( $query->posts as $lesson_id ) {
			$lesson_id = absint( $lesson_id );
			if ( ! $lesson_id ) {
				continue;
			}
			if ( class_exists( 'BWFAN_Masterstudy_Common' ) ) {
				$label                = BWFAN_Masterstudy_Common::get_lesson_search_label( $lesson_id );
				$result[ $lesson_id ] = is_string( $label ) && '' !== $label ? $label : get_the_title( $lesson_id );
			} else {
				$result[ $lesson_id ] = get_the_title( $lesson_id );
			}
		}
		wp_reset_postdata();

		return $result;
	}


}

#[\AllowDynamicProperties]
class BWFAN_Rule_Masterstudy_Quiz extends BWFAN_Rule_Base {
	public function __construct() {
		$this->v2 = true;
		$this->v1 = false;
		parent::__construct( 'masterstudy_quiz' );
	}

	/** v2 Methods: START */

	public function get_options( $term = '' ) {
		return $this->get_possible_rule_values( $term );
	}

	public function get_rule_type() {
		return 'Search';
	}

	public function is_match_v2( $automation_data, $rule_data ) {
		if ( ! isset( $automation_data['global'] ) || ! is_array( $automation_data['global'] ) ) {
			return $this->return_is_match( false, $rule_data );
		}
		$quiz_id      = isset( $automation_data['global']['quiz_id'] ) ? absint( $automation_data['global']['quiz_id'] ) : 0;
		$selected_ids = bwfan_masterstudy_search_rule_selected_ids( isset( $rule_data['data'] ) ? $rule_data['data'] : null );
		$result       = false;
		$rule_op      = isset( $rule_data['rule'] ) ? $rule_data['rule'] : '';

		if ( empty( $selected_ids ) ) {
			return $this->return_is_match( false, $rule_data );
		}

		switch ( $rule_op ) {
			case 'is':
				$result = in_array( $quiz_id, $selected_ids, true );
				break;
			case 'is_not':
				$result = ! in_array( $quiz_id, $selected_ids, true );
				break;
			default:
				$result = false;
				break;
		}

		return $this->return_is_match( $result, $rule_data );
	}

	/** v2 Methods: END */

	public function get_possible_rule_operators() {
		return array(
			'is'     => __( 'is', 'wp-marketing-automations-pro' ),
			'is_not' => __( 'is not', 'wp-marketing-automations-pro' ),
		);
	}

	public function get_condition_input_type() {
		return 'Search';
	}

	public function get_possible_rule_values( $term = '' ) {
		$result = array();

		if ( ! post_type_exists( 'stm-quizzes' ) ) {
			return $result;
		}

		$args = array(
			'post_type'              => 'stm-quizzes',
			'post_status'            => 'publish',
			'posts_per_page'         => 200,
			'orderby'                => 'title',
			'order'                  => 'ASC',
			'fields'                 => 'ids',
			'no_found_rows'          => true,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
		);
		if ( ! empty( $term ) ) {
			$args['s'] = sanitize_text_field( $term );
		}

		$query = new WP_Query( $args );
		foreach ( $query->posts as $quiz_id ) {
			$quiz_id = absint( $quiz_id );
			if ( ! $quiz_id ) {
				continue;
			}
			$result[ $quiz_id ] = get_the_title( $quiz_id ) . '(#' . $quiz_id . ')';
		}
		wp_reset_postdata();

		return $result;
	}


}

#[\AllowDynamicProperties]
class BWFAN_Rule_Masterstudy_Quiz_Percentage extends BWFAN_Rule_Base {
	public function __construct() {
		$this->v2 = true;
		$this->v1 = false;
		parent::__construct( 'masterstudy_quiz_percentage' );
	}

	public function get_possible_rule_operators() {
		return array(
			'==' => __( 'is equal to', 'wp-marketing-automations-pro' ),
			'!=' => __( 'is not equal to', 'wp-marketing-automations-pro' ),
			'>'  => __( 'is greater than', 'wp-marketing-automations-pro' ),
			'<'  => __( 'is less than', 'wp-marketing-automations-pro' ),
			'>=' => __( 'is greater or equal to', 'wp-marketing-automations-pro' ),
			'<=' => __( 'is less or equal to', 'wp-marketing-automations-pro' ),
		);
	}

	public function get_condition_input_type() {
		return 'Text';
	}

	/** v2 Methods: START */

	public function is_match_v2( $automation_data, $rule_data ) {
		if ( ! isset( $automation_data['global'] ) || ! is_array( $automation_data['global'] ) ) {
			return $this->return_is_match( false, $rule_data );
		}
		if ( ! isset( $automation_data['global']['progress'] ) ) {
			return $this->return_is_match( false, $rule_data );
		}

		$percentage = (float) $automation_data['global']['progress'];
		$value      = (float) $rule_data['data'];
		$epsilon    = 0.0001;
		$result     = false;
		$rule_op    = isset( $rule_data['rule'] ) ? $rule_data['rule'] : '';

		switch ( $rule_op ) {
			case '==':
				$result = abs( $percentage - $value ) < $epsilon;
				break;
			case '!=':
				$result = abs( $percentage - $value ) >= $epsilon;
				break;
			case '>':
				$result = $percentage > $value;
				break;
			case '<':
				$result = $percentage < $value;
				break;
			case '>=':
				$result = $percentage >= $value;
				break;
			case '<=':
				$result = $percentage <= $value;
				break;
			default:
				$result = false;
		}

		return $this->return_is_match( $result, $rule_data );
	}

	/** v2 Methods: END */
}

#[\AllowDynamicProperties]
class BWFAN_Rule_Masterstudy_Course_Progress extends BWFAN_Rule_Base {
	public function __construct() {
		$this->v2 = true;
		$this->v1 = false;
		parent::__construct( 'masterstudy_course_progress' );
	}

	public function get_possible_rule_operators() {
		return array(
			'==' => __( 'is equal to', 'wp-marketing-automations-pro' ),
			'!=' => __( 'is not equal to', 'wp-marketing-automations-pro' ),
			'>'  => __( 'is greater than', 'wp-marketing-automations-pro' ),
			'<'  => __( 'is less than', 'wp-marketing-automations-pro' ),
			'>=' => __( 'is greater or equal to', 'wp-marketing-automations-pro' ),
			'<=' => __( 'is less or equal to', 'wp-marketing-automations-pro' ),
		);
	}

	public function get_condition_input_type() {
		return 'Text';
	}

	/** v2 Methods: START */

	public function is_match_v2( $automation_data, $rule_data ) {
		if ( ! isset( $automation_data['global'] ) || ! is_array( $automation_data['global'] ) ) {
			return $this->return_is_match( false, $rule_data );
		}

		$user_id   = isset( $automation_data['global']['user_id'] ) ? absint( $automation_data['global']['user_id'] ) : 0;
		$course_id = isset( $automation_data['global']['course_id'] ) ? absint( $automation_data['global']['course_id'] ) : 0;
		$lesson_id = isset( $automation_data['global']['lesson_id'] ) ? absint( $automation_data['global']['lesson_id'] ) : 0;
		$quiz_id   = isset( $automation_data['global']['quiz_id'] ) ? absint( $automation_data['global']['quiz_id'] ) : 0;

		if ( class_exists( 'BWFAN_Masterstudy_Common' ) ) {
			$course_id = BWFAN_Masterstudy_Common::resolve_event_course_id( $course_id, $lesson_id, $quiz_id );
		}

		if ( ! $user_id || ! $course_id || ! class_exists( 'BWFAN_Masterstudy_Common' ) ) {
			return $this->return_is_match( false, $rule_data );
		}

		$db_progress = BWFAN_Masterstudy_Common::get_user_course_progress_percent( $user_id, $course_id );
		if ( null === $db_progress && isset( $automation_data['global']['progress'] ) ) {
			$db_progress = (float) $automation_data['global']['progress'];
		}
		if ( null === $db_progress ) {
			return $this->return_is_match( false, $rule_data );
		}

		$value   = (float) $rule_data['data'];
		$epsilon = 0.0001;
		$result  = false;
		$rule_op = isset( $rule_data['rule'] ) ? $rule_data['rule'] : '';

		switch ( $rule_op ) {
			case '==':
				$result = abs( $db_progress - $value ) < $epsilon;
				break;
			case '!=':
				$result = abs( $db_progress - $value ) >= $epsilon;
				break;
			case '>':
				$result = $db_progress > $value;
				break;
			case '<':
				$result = $db_progress < $value;
				break;
			case '>=':
				$result = $db_progress >= $value;
				break;
			case '<=':
				$result = $db_progress <= $value;
				break;
			default:
				$result = false;
				break;
		}

		return $this->return_is_match( $result, $rule_data );
	}

	/** v2 Methods: END */


}

#[\AllowDynamicProperties]
class BWFAN_Rule_Masterstudy_Quiz_Passed extends BWFAN_Rule_Base {
	public function __construct() {
		$this->v2 = true;
		$this->v1 = false;
		parent::__construct( 'masterstudy_quiz_passed' );
	}

	/** v2 Methods: START */

	public function get_options( $term = '' ) {
		return $this->get_possible_rule_values();
	}

	public function get_rule_type() {
		return 'Select';
	}

	public function is_match_v2( $automation_data, $rule_data ) {
		if ( ! isset( $automation_data['global'] ) || ! is_array( $automation_data['global'] ) ) {
			return $this->return_is_match( false, $rule_data );
		}

		$passed = isset( $automation_data['global']['quiz_passed'] ) ? (int) $automation_data['global']['quiz_passed'] : 0;
		$result = ( 1 === $passed );

		return $this->return_is_match( ( 'yes' === $rule_data['data'] ) ? $result : ! $result, $rule_data );
	}

	/** v2 Methods: END */

	public function get_possible_rule_operators() {
		return null;
	}

	public function get_possible_rule_values() {
		return array(
			'yes' => __( 'Yes', 'wp-marketing-automations-pro' ),
			'no'  => __( 'No', 'wp-marketing-automations-pro' ),
		);
	}
}
