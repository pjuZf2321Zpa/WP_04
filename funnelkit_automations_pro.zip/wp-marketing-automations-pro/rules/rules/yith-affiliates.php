<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( function_exists( 'bwfan_is_yith_affiliates_active' ) && bwfan_is_yith_affiliates_active() ) {

	/**
	 * Current YITH affiliate status (slug), resolved from `affiliate_id` or `user_id` in event global data.
	 */
	#[\AllowDynamicProperties]
	class BWFAN_Rule_Yith_Affiliate_Status extends BWFAN_Rule_Base {

		public function __construct() {
			$this->v2    = true;
			$this->title = __( 'Affiliate status', 'wp-marketing-automations-pro' );
			parent::__construct( 'yith_affiliate_status' );
		}

		public function get_rule_type() {
			return 'Search';
		}

		public function get_condition_input_type() {
			return 'Chosen_Select';
		}

		public function get_possible_rule_operators() {
			return array(
				'any'  => __( 'matches any of', 'wp-marketing-automations-pro' ),
				'none' => __( 'matches none of', 'wp-marketing-automations-pro' ),
			);
		}

		public function get_options( $term = '' ) {
			if ( ! class_exists( 'YITH_WCAF_Affiliates' ) ) {
				return array();
			}

			$opts = array();
			foreach ( YITH_WCAF_Affiliates::get_available_statuses() as $row ) {
				if ( ! isset( $row['slug'], $row['name'] ) ) {
					continue;
				}
				$opts[ $row['slug'] ] = $row['name'];
			}

			$t = is_string( $term ) ? trim( $term ) : '';
			if ( '' === $t ) {
				return $opts;
			}

			$filtered = array();
			$t_lower    = strtolower( $t );
			foreach ( $opts as $slug => $label ) {
				if ( false !== stripos( (string) $slug, $t_lower ) || false !== stripos( (string) $label, $t_lower ) ) {
					$filtered[ $slug ] = $label;
				}
			}

			return $filtered;
		}

		public function get_ui_preview_data() {
			return $this->get_options();
		}

		public function get_condition_values_nice_names( $values ) {
			$labels = $this->get_options();

			$return = array();
			foreach ( $values as $value ) {
				$return[ $value ] = isset( $labels[ $value ] ) ? $labels[ $value ] : $value;
			}

			return $return;
		}

		/**
		 * @param array $automation_data
		 *
		 * @return string|null Status slug or null if not resolved.
		 */
		private function get_affiliate_status_slug( $automation_data ) {
			if ( ! isset( $automation_data['global'] ) || ! is_array( $automation_data['global'] ) ) {
				return null;
			}

			$global       = $automation_data['global'];
			$affiliate_id = isset( $global['affiliate_id'] ) ? absint( $global['affiliate_id'] ) : 0;
			$user_id      = isset( $global['user_id'] ) ? absint( $global['user_id'] ) : 0;

			$affiliate = null;

			if ( class_exists( 'YITH_WCAF_Affiliate_Factory' ) ) {
				if ( $affiliate_id ) {
					try {
						$affiliate = YITH_WCAF_Affiliate_Factory::get_affiliate_by_id( $affiliate_id );
					} catch ( Throwable $e ) {
						$affiliate = null;
					}
				}
				if ( ! $affiliate && $user_id ) {
					try {
						$affiliate = YITH_WCAF_Affiliate_Factory::get_affiliate_by_user_id( $user_id );
					} catch ( Throwable $e ) {
						$affiliate = null;
					}
				}
			}

			if ( ! $affiliate || ! is_callable( array( $affiliate, 'get_status' ) ) ) {
				return null;
			}

			return $affiliate->get_status();
		}

		/**
		 * Normalize saved condition values (Chosen_Select rows or legacy scalars) to status slugs.
		 *
		 * @param mixed $data Rule value payload.
		 *
		 * @return string[]
		 */
		private function normalize_selected_statuses( $data ) {
			if ( null === $data || '' === $data ) {
				return array();
			}
			if ( ! is_array( $data ) ) {
				return array( (string) $data );
			}
			if ( empty( $data ) ) {
				return array();
			}
			$first = reset( $data );
			if ( is_array( $first ) && array_key_exists( 'key', $first ) ) {
				return array_values( array_filter( array_map( function ( $row ) {
					return isset( $row['key'] ) ? (string) $row['key'] : '';
				}, $data ) ) );
			}

			return array_values( array_filter( array_map( 'strval', $data ) ) );
		}

		public function is_match_v2( $automation_data, $rule_data ) {
			$status = $this->get_affiliate_status_slug( $automation_data );
			if ( null === $status || '' === $status ) {
				return $this->return_is_match( false, $rule_data );
			}

			$data = isset( $rule_data['data'] ) ? $rule_data['data'] : '';
			$rule = isset( $rule_data['rule'] ) ? $rule_data['rule'] : 'any';

			$saved = $this->normalize_selected_statuses( $data );

			switch ( $rule ) {
				case 'any':
					if ( empty( $saved ) ) {
						return $this->return_is_match( false, $rule_data );
					}
					$result = in_array( $status, $saved, true );
					break;
				case 'none':
					if ( empty( $saved ) ) {
						return $this->return_is_match( false, $rule_data );
					}
					$result = ! in_array( $status, $saved, true );
					break;
				default:
					$result = false;
					break;
			}

			return $this->return_is_match( $result, $rule_data );
		}

		public function is_match( $rule_data ) {
			return false;
		}

		public function ui_view() {
			esc_html_e( 'YITH affiliate status', 'wp-marketing-automations-pro' );
			?>
			<% var ops = JSON.parse('<?php echo wp_json_encode( $this->get_possible_rule_operators() ); ?>'); %>
			<%= ops[operator] %>
			<% var chosen = []; %>
			<% _.each(condition, function( value, key ){ %>
			<% chosen.push(uiData[value]); %>
			<% }); %>
			<%= chosen.join(" / ") %>
			<?php
		}
	}
}


if ( bwfan_is_yith_affiliates_active() ) {

	#[\AllowDynamicProperties]
	class BWFAN_Rule_Yith_Affiliate_Total_Earnings extends BWFAN_Rule_Base {

		public function __construct() {
			$this->v2 = true;
			parent::__construct( 'yith_affiliate_total_earnings' );
		}

		public function get_condition_input_type() {
			return 'Text';
		}

		public function is_match_v2( $automation_data, $rule_data ) {
			if ( ! isset( $automation_data['global'] ) || ! is_array( $automation_data['global'] ) ) {
				return $this->return_is_match( false, $rule_data );
			}

			$affiliate_id = isset( $automation_data['global']['affiliate_id'] ) ? absint( $automation_data['global']['affiliate_id'] ) : 0;
			if ( empty( $affiliate_id ) || ! class_exists( 'YITH_WCAF_Affiliate_Factory' ) ) {
				return $this->return_is_match( false, $rule_data );
			}

			try {
				$affiliate = YITH_WCAF_Affiliate_Factory::get_affiliate_by_id( $affiliate_id );
				if ( ! $affiliate || ! is_callable( array( $affiliate, 'get_earnings' ) ) ) {
					return $this->return_is_match( false, $rule_data );
				}

				$decimal        = apply_filters( 'bwfan_get_decimal_values', 2 );
				$total_earnings = round( (float) $affiliate->get_earnings(), $decimal );
			} catch ( Throwable $e ) {
				return $this->return_is_match( false, $rule_data );
			}

			$value   = (float) $rule_data['data'];
			$epsilon = 0.00001;
			$result  = false;

			switch ( $rule_data['rule'] ) {
				case '==':
					$result = abs( $total_earnings - $value ) < $epsilon;
					break;
				case '!=':
					$result = abs( $total_earnings - $value ) >= $epsilon;
					break;
				case '>':
					$result = $total_earnings > $value;
					break;
				case '<':
					$result = $total_earnings < $value;
					break;
				case '>=':
					$result = $total_earnings >= $value;
					break;
				case '<=':
					$result = $total_earnings <= $value;
					break;
				default:
					$result = false;
					break;
			}

			return $this->return_is_match( $result, $rule_data );
		}

		public function is_match( $rule_data ) {
			return $this->return_is_match( false, $rule_data );
		}

		public function ui_view() {
			?>
            Yith Affiliate Total Earnings
            <% var ops = JSON.parse('<?php echo wp_json_encode( $this->get_possible_rule_operators() ); ?>'); %>
            <%= ops[operator] %>
            <%= condition %>
			<?php
		}

		public function get_possible_rule_operators() {
			return array(
				'==' => __( 'is equal to', 'wp-marketing-automations-pro' ),
				'!=' => __( 'is not equal to', 'wp-marketing-automations-pro' ),
				'>'  => __( 'is greater than', 'wp-marketing-automations-pro' ),
				'<'  => __( 'is less than', 'wp-marketing-automations-pro' ),
				'>=' => __( 'is greater or equal to', 'wp-marketing-automations-pro' ),
				'<=' => __( 'is less or equal to', 'wp-marketing-automations-pro' ),
			);
		}

	}

	#[\AllowDynamicProperties]
	class BWFAN_Rule_Yith_Affiliate_Paid_Amount extends BWFAN_Rule_Base {

		public function __construct() {
			$this->v2 = true;
			parent::__construct( 'yith_affiliate_paid_amount' );
		}

		public function get_condition_input_type() {
			return 'Text';
		}

		public function is_match_v2( $automation_data, $rule_data ) {
			if ( ! isset( $automation_data['global'] ) || ! is_array( $automation_data['global'] ) ) {
				return $this->return_is_match( false, $rule_data );
			}

			$affiliate_id = isset( $automation_data['global']['affiliate_id'] ) ? absint( $automation_data['global']['affiliate_id'] ) : 0;
			if ( empty( $affiliate_id ) || ! class_exists( 'YITH_WCAF_Affiliate_Factory' ) ) {
				return $this->return_is_match( false, $rule_data );
			}

			try {
				$affiliate = YITH_WCAF_Affiliate_Factory::get_affiliate_by_id( $affiliate_id );
				if ( ! $affiliate || ! is_callable( array( $affiliate, 'get_paid' ) ) ) {
					return $this->return_is_match( false, $rule_data );
				}

				$decimal     = apply_filters( 'bwfan_get_decimal_values', 2 );
				$paid_amount = round( (float) $affiliate->get_paid(), $decimal );
			} catch ( Throwable $e ) {
				return $this->return_is_match( false, $rule_data );
			}

			$value   = (float) $rule_data['data'];
			$epsilon = 0.00001;
			$result  = false;

			switch ( $rule_data['rule'] ) {
				case '==':
					$result = abs( $paid_amount - $value ) < $epsilon;
					break;
				case '!=':
					$result = abs( $paid_amount - $value ) >= $epsilon;
					break;
				case '>':
					$result = $paid_amount > $value;
					break;
				case '<':
					$result = $paid_amount < $value;
					break;
				case '>=':
					$result = $paid_amount >= $value;
					break;
				case '<=':
					$result = $paid_amount <= $value;
					break;
				default:
					$result = false;
					break;
			}

			return $this->return_is_match( $result, $rule_data );
		}

		public function is_match( $rule_data ) {
			return $this->return_is_match( false, $rule_data );
		}

		public function ui_view() {
			?>
            Yith Affiliate Paid Amount
            <% var ops = JSON.parse('<?php echo wp_json_encode( $this->get_possible_rule_operators() ); ?>'); %>
            <%= ops[operator] %>
            <%= condition %>
			<?php
		}

		public function get_possible_rule_operators() {
			return array(
				'==' => __( 'is equal to', 'wp-marketing-automations-pro' ),
				'!=' => __( 'is not equal to', 'wp-marketing-automations-pro' ),
				'>'  => __( 'is greater than', 'wp-marketing-automations-pro' ),
				'<'  => __( 'is less than', 'wp-marketing-automations-pro' ),
				'>=' => __( 'is greater or equal to', 'wp-marketing-automations-pro' ),
				'<=' => __( 'is less or equal to', 'wp-marketing-automations-pro' ),
			);
		}

	}

	#[\AllowDynamicProperties]
	class BWFAN_Rule_Yith_Affiliate_Rate extends BWFAN_Rule_Base {

		public function __construct() {
			$this->v2 = true;
			parent::__construct( 'yith_affiliate_rate' );
		}

		public function get_condition_input_type() {
			return 'Text';
		}

		public function is_match_v2( $automation_data, $rule_data ) {
			if ( ! isset( $automation_data['global'] ) || ! is_array( $automation_data['global'] ) ) {
				return $this->return_is_match( false, $rule_data );
			}

			$affiliate_id = isset( $automation_data['global']['affiliate_id'] ) ? absint( $automation_data['global']['affiliate_id'] ) : 0;
			if ( empty( $affiliate_id ) || ! class_exists( 'YITH_WCAF_Affiliate_Factory' ) ) {
				return $this->return_is_match( false, $rule_data );
			}

			try {
				$affiliate = YITH_WCAF_Affiliate_Factory::get_affiliate_by_id( $affiliate_id );
				if ( ! $affiliate || ! is_callable( array( $affiliate, 'get_rate' ) ) ) {
					return $this->return_is_match( false, $rule_data );
				}

				$decimal = apply_filters( 'bwfan_get_decimal_values', 2 );
				$rate    = round( (float) $affiliate->get_rate(), $decimal );
			} catch ( Throwable $e ) {
				return $this->return_is_match( false, $rule_data );
			}

			$value   = (float) $rule_data['data'];
			$epsilon = 0.00001;
			$result  = false;

			switch ( $rule_data['rule'] ) {
				case '==':
					$result = abs( $rate - $value ) < $epsilon;
					break;
				case '!=':
					$result = abs( $rate - $value ) >= $epsilon;
					break;
				case '>':
					$result = $rate > $value;
					break;
				case '<':
					$result = $rate < $value;
					break;
				case '>=':
					$result = $rate >= $value;
					break;
				case '<=':
					$result = $rate <= $value;
					break;
				default:
					$result = false;
					break;
			}

			return $this->return_is_match( $result, $rule_data );
		}

		public function is_match( $rule_data ) {
			return $this->return_is_match( false, $rule_data );
		}

		public function ui_view() {
			?>
            Yith Affiliate Rate
            <% var ops = JSON.parse('<?php echo wp_json_encode( $this->get_possible_rule_operators() ); ?>'); %>
            <%= ops[operator] %>
            <%= condition %>
			<?php
		}

		public function get_possible_rule_operators() {
			return array(
				'==' => __( 'is equal to', 'wp-marketing-automations-pro' ),
				'!=' => __( 'is not equal to', 'wp-marketing-automations-pro' ),
				'>'  => __( 'is greater than', 'wp-marketing-automations-pro' ),
				'<'  => __( 'is less than', 'wp-marketing-automations-pro' ),
				'>=' => __( 'is greater or equal to', 'wp-marketing-automations-pro' ),
				'<=' => __( 'is less or equal to', 'wp-marketing-automations-pro' ),
			);
		}

	}

}
