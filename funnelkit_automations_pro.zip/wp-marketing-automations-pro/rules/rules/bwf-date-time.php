<?php


#[\AllowDynamicProperties]
class BWFAN_DateTime_Rule_Common {

	public static function is_match( $operator, $value, $selected_value ) {
		if ( empty( $operator ) ) {
			return false;
		}
		switch ( $operator ) {
			case '==':
				$result = $value === $selected_value;
				break;
			case '!=':
				$result = $value !== $selected_value;
				break;
			case '>':
				$result = $value > $selected_value;
				break;
			case '<':
				$result = $value < $selected_value;
				break;
			case '>=':
				$result = $value >= $selected_value;
				break;
			case '<=':
				$result = $value <= $selected_value;
				break;
			default:
				$result = false;
				break;
		}

		return $result;
	}
}

#[\AllowDynamicProperties]
class BWFAN_Rule_Current_Year extends BWFAN_Rule_Base {

	public function __construct() {
		$this->v2 = true;
		$this->v1 = false;
		parent::__construct( 'current_year' );
	}

	/** v2 Methods: START */
	public function get_options( $term = '' ) {
		return $this->get_possible_rule_values();
	}

	public function get_rule_type() {
		return 'Select';
	}

	public function is_match_v2( $automation_data, $rule_data ) {
		$result = false;

		if ( ! isset( $automation_data['global'] ) || ! is_array( $automation_data['global'] ) ) {
			return $this->return_is_match( $result, $rule_data );
		}

		$current_year  = date_i18n( 'Y' );
		$selected_year = $rule_data['data'];
		$result        = BWFAN_DateTime_Rule_Common::is_match( $rule_data['rule'], $current_year, $selected_year );

		return $this->return_is_match( $result, $rule_data );
	}

	public function get_possible_rule_operators() {
		return array(
			'==' => __( 'is', 'wp-marketing-automations-pro' ),
			'!=' => __( 'is not', 'wp-marketing-automations-pro' ),
			'>'  => __( 'is after', 'wp-marketing-automations-pro' ),
			'<'  => __( 'is before', 'wp-marketing-automations-pro' ),
			'>=' => __( 'is on or after', 'wp-marketing-automations-pro' ),
			'<=' => __( 'is on or before', 'wp-marketing-automations-pro' ),
		);
	}

	public function get_possible_rule_values() {
		$years        = array();
		$current_year = date_i18n( 'Y' );
		$end_year     = intval( $current_year ) + 25;
		for ( $year = $current_year; $year <= $end_year; $year ++ ) {
			$localized_year = date_i18n( 'Y', strtotime( $year . '-01-01' ) );
			$years[ $year ] = $localized_year;
		}

		return $years;
	}
}

#[\AllowDynamicProperties]
class BWFAN_Rule_Current_Month extends BWFAN_Rule_Base {

	public function __construct() {
		$this->v2 = true;
		$this->v1 = false;
		parent::__construct( 'current_month' );
	}

	/** v2 Methods: START */
	public function get_options( $term = '' ) {
		return $this->get_possible_rule_values();
	}

	public function get_rule_type() {
		return 'Select';
	}

	public function is_match_v2( $automation_data, $rule_data ) {
		$result = false;

		if ( ! isset( $automation_data['global'] ) || ! is_array( $automation_data['global'] ) ) {
			return $this->return_is_match( $result, $rule_data );
		}
		if ( ! isset( $rule_data['data'] ) ) {
			return $this->return_is_match( $result, $rule_data );
		}
		$current_month  = intval( date_i18n( 'n' ) );
		$selected_month = intval( $rule_data['data'] );
		$result         = BWFAN_DateTime_Rule_Common::is_match( $rule_data['rule'], $current_month, $selected_month );

		return $this->return_is_match( $result, $rule_data );
	}

	public function get_possible_rule_operators() {
		return array(
			'==' => __( 'is', 'wp-marketing-automations-pro' ),
			'!=' => __( 'is not', 'wp-marketing-automations-pro' ),
			'>'  => __( 'is after', 'wp-marketing-automations-pro' ),
			'<'  => __( 'is before', 'wp-marketing-automations-pro' ),
			'>=' => __( 'is on or after', 'wp-marketing-automations-pro' ),
			'<=' => __( 'is on or before', 'wp-marketing-automations-pro' ),
		);
	}

	public function get_possible_rule_values() {
		$months = range( 1, 12 );

		$localized_months = array_map( function ( $month ) {
			return date_i18n( 'F', mktime( 0, 0, 0, $month, 1 ) );
		}, $months );

		return array_combine( $months, $localized_months );
	}

}

#[\AllowDynamicProperties]
class BWFAN_Rule_Current_Day_Of_Month extends BWFAN_Rule_Base {

	public function __construct() {
		$this->v2 = true;
		$this->v1 = false;
		parent::__construct( 'current_day_of_month' );
	}

	/** v2 Methods: START */
	public function get_options( $term = '' ) {
		return $this->get_possible_rule_values();
	}

	public function get_rule_type() {
		return 'Select';
	}

	public function is_match_v2( $automation_data, $rule_data ) {
		$result = false;

		if ( ! isset( $automation_data['global'] ) || ! is_array( $automation_data['global'] ) ) {
			return $this->return_is_match( $result, $rule_data );
		}
		if ( ! isset( $rule_data['data'] ) ) {
			return $this->return_is_match( $result, $rule_data );
		}

		$current_day  = intval( date_i18n( 'j' ) );
		$selected_day = intval( $rule_data['data'] );
		$result       = BWFAN_DateTime_Rule_Common::is_match( $rule_data['rule'], $current_day, $selected_day );

		return $this->return_is_match( $result, $rule_data );
	}

	public function get_possible_rule_operators() {
		return array(
			'==' => __( 'is', 'wp-marketing-automations-pro' ),
			'!=' => __( 'is not', 'wp-marketing-automations-pro' ),
			'>'  => __( 'is after', 'wp-marketing-automations-pro' ),
			'<'  => __( 'is before', 'wp-marketing-automations-pro' ),
			'>=' => __( 'is on or after', 'wp-marketing-automations-pro' ),
			'<=' => __( 'is on or before', 'wp-marketing-automations-pro' ),
		);
	}

	public function get_possible_rule_values() {
		$days      = range( 1, 31 );
		$day_array = array_combine( $days, $days );

		return $day_array;
	}

}

#[\AllowDynamicProperties]
class BWFAN_Rule_Current_Day_Of_Week extends BWFAN_Rule_Base {

	public function __construct() {
		$this->v2 = true;
		$this->v1 = false;
		parent::__construct( 'current_day_of_week' );
	}

	/** v2 Methods: START */
	public function get_options( $term = '' ) {
		return $this->get_possible_rule_values();
	}

	public function get_rule_type() {
		return 'Select';
	}

	public function is_match_v2( $automation_data, $rule_data ) {
		$result = false;

		if ( ! isset( $automation_data['global'] ) || ! is_array( $automation_data['global'] ) ) {
			return $this->return_is_match( $result, $rule_data );
		}

		$current_day_of_week  = date( 'l' );
		$selected_day_of_week = $rule_data['data'];
		$result               = BWFAN_DateTime_Rule_Common::is_match( $rule_data['rule'], $current_day_of_week, $selected_day_of_week );

		return $this->return_is_match( $result, $rule_data );
	}

	public function get_possible_rule_operators() {
		return array(
			'==' => __( 'is', 'wp-marketing-automations-pro' ),
			'!=' => __( 'is not', 'wp-marketing-automations-pro' ),
		);
	}

	public function get_possible_rule_values() {
		$days_of_week = array(
			'Sunday'    => __( 'Sunday', 'wp-marketing-automations-pro' ),
			'Monday'    => __( 'Monday', 'wp-marketing-automations-pro' ),
			'Tuesday'   => __( 'Tuesday', 'wp-marketing-automations-pro' ),
			'Wednesday' => __( 'Wednesday', 'wp-marketing-automations-pro' ),
			'Thursday'  => __( 'Thursday', 'wp-marketing-automations-pro' ),
			'Friday'    => __( 'Friday', 'wp-marketing-automations-pro' ),
			'Saturday'  => __( 'Saturday', 'wp-marketing-automations-pro' )
		);

		return $days_of_week;
	}
}

#[\AllowDynamicProperties]
class BWFAN_Rule_Current_Time extends BWFAN_Rule_Base {

	public function __construct() {
		$this->v2 = true;
		$this->v1 = false;
		parent::__construct( 'current_time' );
	}

	/** v2 Methods: START */
	public function get_rule_type() {
		return 'time';
	}

	public function is_match_v2( $automation_data, $rule_data ) {

		if ( ! isset( $automation_data['global'] ) || ! is_array( $automation_data['global'] ) ) {
			return $this->return_is_match( false, $rule_data );
		}
		if ( empty( $rule_data['data'] ) ) {
			return $this->return_is_match( false, $rule_data );
		}

		$current_time  = strtotime( $this->get_current_time_string( $automation_data, $rule_data ) );
		$selected_time = strtotime( $rule_data['data'] );
		$result        = BWFAN_DateTime_Rule_Common::is_match( $rule_data['rule'], $current_time, $selected_time );

		return $this->return_is_match( $result, $rule_data );
	}

	/**
	 * Get the current time (H:i) the rule is evaluated against.
	 *
	 * Defaults to the store timezone. The timezone can be switched per automation / step
	 * via the `bwfan_rule_current_time_timezone` filter, for example to evaluate the rule
	 * in the contact's timezone:
	 *
	 *  add_filter( 'bwfan_rule_current_time_timezone', function ( $timezone, $automation_data ) {
	 *      $cid = isset( $automation_data['global']['cid'] ) ? absint( $automation_data['global']['cid'] ) : 0;
	 *      if ( empty( $cid ) ) {
	 *          return $timezone;
	 *      }
	 *      $contact = new WooFunnels_Contact( '', '', '', $cid );
	 *
	 *      return ( $contact->get_id() > 0 && ! empty( $contact->get_timezone() ) ) ? $contact->get_timezone() : $timezone;
	 *  }, 10, 2 );
	 *
	 * `$automation_data['global']` carries `cid` and `automation_id` to key the decision on. `step_id` is only
	 * present when the lite Conditional Controller sets it, so check isset() before relying on it.
	 * An empty or invalid timezone falls back to the store timezone.
	 *
	 * @param array $automation_data
	 * @param array $rule_data
	 *
	 * @return string Current time as H:i
	 */
	protected function get_current_time_string( $automation_data, $rule_data ) {
		$store_timezone = wp_timezone_string();
		$timezone       = apply_filters( 'bwfan_rule_current_time_timezone', $store_timezone, $automation_data, $rule_data );

		/** Store timezone, keep the existing behaviour */
		if ( empty( $timezone ) || ! is_string( $timezone ) || $timezone === $store_timezone ) {
			return date_i18n( 'H:i' );
		}

		try {
			$datetime = new DateTime( 'now', new DateTimeZone( $timezone ) );
		} catch ( Throwable $e ) {
			BWFAN_Common::log_test_data( 'Invalid timezone ' . $timezone . ' for current_time rule. Error: ' . $e->getMessage(), 'current-time-rule' );

			return date_i18n( 'H:i' );
		}

		/** Same offset as the store right now (e.g. Asia/Kolkata vs +05:30), keep the existing behaviour */
		if ( $datetime->getOffset() === ( new DateTime( 'now', wp_timezone() ) )->getOffset() ) {
			return date_i18n( 'H:i' );
		}

		return $datetime->format( 'H:i' );
	}


	public function get_possible_rule_operators() {
		return array(
			'==' => __( 'is', 'wp-marketing-automations-pro' ),
			'!=' => __( 'is not', 'wp-marketing-automations-pro' ),
			'>'  => __( 'is after', 'wp-marketing-automations-pro' ),
			'<'  => __( 'is before', 'wp-marketing-automations-pro' ),
			'>=' => __( 'is on or after', 'wp-marketing-automations-pro' ),
			'<=' => __( 'is on or before', 'wp-marketing-automations-pro' )
		);
	}

}

#[\AllowDynamicProperties]
class BWFAN_Rule_Current_Date_Time extends BWFAN_Rule_Base {

	public function __construct() {
		$this->v2 = true;
		$this->v1 = false;
		parent::__construct( 'current_date_time' );
	}

	/** v2 Methods: START */
	public function get_rule_type() {
		return 'datetime';
	}

	public function is_match_v2( $automation_data, $rule_data ) {
		$result = false;

		if ( ! isset( $automation_data['global'] ) || ! is_array( $automation_data['global'] ) ) {
			return $this->return_is_match( $result, $rule_data );
		}
		if ( empty( $rule_data['data'] ) ) {
			return $this->return_is_match( $result, $rule_data );
		}
		$current_datetime  = date_i18n( 'Y-m-d\TH:i' );
		$datetime          = new DateTime( $rule_data['data'] );
		$selected_datetime = $datetime->format( 'Y-m-d\TH:i' );
		$result            = BWFAN_DateTime_Rule_Common::is_match( $rule_data['rule'], $current_datetime, $selected_datetime );

		return $this->return_is_match( $result, $rule_data );
	}

	public function get_possible_rule_operators() {
		return array(
			'==' => __( 'is', 'wp-marketing-automations-pro' ),
			'!=' => __( 'is not', 'wp-marketing-automations-pro' ),
			'>'  => __( 'is after', 'wp-marketing-automations-pro' ),
			'<'  => __( 'is before', 'wp-marketing-automations-pro' ),
			'>=' => __( 'is on or after', 'wp-marketing-automations-pro' ),
			'<=' => __( 'is on or before', 'wp-marketing-automations-pro' )
		);
	}

}



