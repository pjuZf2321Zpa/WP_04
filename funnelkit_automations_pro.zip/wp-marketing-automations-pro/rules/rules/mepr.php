<?php

if ( ! class_exists( 'BWFAN_Rule_Mepr_Product' ) ) {

	#[\AllowDynamicProperties]
	class BWFAN_Rule_Mepr_Product extends BWFAN_Rule_Base {
		public function __construct() {
			$this->v2 = true;
			$this->v1 = false;
			parent::__construct( 'mepr_product' );
		}

		/** v2 Methods: START */

		public function get_options( $term = '' ) {
			return $this->get_possible_rule_values();
		}

		public function get_rule_type() {
			return 'Select';
		}

		public function is_match_v2( $automation_data, $rule_data ) {
			$result = false;
			if ( ! isset( $automation_data['global'] ) || ! is_array( $automation_data['global'] ) ) {
				return $this->return_is_match( $result, $rule_data );
			}

			$product_id = isset( $automation_data['global']['product_id'] ) ? $automation_data['global']['product_id'] : 0;

			if ( empty( $product_id ) ) {
				$result = ( 'is_not' === $rule_data['rule'] ) ? true : $result;

				return $this->return_is_match( $result, $rule_data );
			}

			$value      = absint( $rule_data['data'] );
			$product_id = absint( $product_id );

			switch ( $rule_data['rule'] ) {
				case 'is':
					$result = $product_id === $value;
					break;
				case 'is_not':
					$result = $product_id !== $value;
					break;
				default:
					$result = false;
					break;
			}

			return $this->return_is_match( $result, $rule_data );
		}

		/** v2 Methods: END */

		public function get_possible_rule_operators() {
			$operators = array(
				'is'     => __( 'is', 'wp-marketing-automations-pro' ),
				'is_not' => __( 'is not', 'wp-marketing-automations-pro' ),
			);

			return $operators;
		}

		public function get_possible_rule_values() {
			$result = array();

			$one_time_products = BWFAN_PRO_Common::get_mepr_one_time_subscription_products();
			$rec_products      = BWFAN_PRO_Common::get_mepr_recurring_subscription_products();
			$products          = array_merge( $one_time_products, $rec_products );

			foreach ( $products as $product ) {
				$result[ $product['id'] ] = $product['text'];
			}

			return $result;
		}


	}
}

#[\AllowDynamicProperties]
class BWFAN_Rule_Mepr_Membership_Status extends BWFAN_Rule_Base {
	public function __construct() {
		$this->v2 = true;
		$this->v1 = false;
		parent::__construct( 'mepr_membership_status' );
	}

	/** v2 Methods: START */

	public function get_options( $term = '' ) {
		return $this->get_possible_rule_values();
	}

	public function get_rule_type() {
		return 'Search';
	}

	public function is_match_v2( $automation_data, $rule_data ) {
		$result = false;
		if ( ! isset( $automation_data['global'] ) || ! is_array( $automation_data['global'] ) ) {
			return $this->return_is_match( $result, $rule_data );
		}
		if ( ! isset( $automation_data['global']['user_id'] ) || ! isset( $automation_data['global']['product_id'] ) ) {
			return $this->return_is_match( $result, $rule_data );
		}
		$type              = $rule_data['rule'];
		$membership_status = self::get_mepr_transactions( $automation_data['global']['user_id'], $automation_data['global']['product_id'] );
		if ( empty( $membership_status ) ) {
			return $this->return_is_match( $result, $rule_data );
		}

		$data = array_map( function ( $status ) {
			return $status['key'];
		}, $rule_data['data'] );
		if ( ! is_array( $data ) || empty( $data ) ) {
			return $this->return_is_match( $result, $rule_data );
		}

		switch ( $type ) {
			case 'is':
				$result = in_array( $membership_status, $data, true );
				break;
			case 'is_not':
				$result = ! in_array( $membership_status, $data, true );
				break;
			default:
				$result = false;
				break;
		}

		return $this->return_is_match( $result, $rule_data );
	}

	/** v2 Methods: END */

	public function get_possible_rule_operators() {
		$operators = array(
			'is'     => __( 'is', 'wp-marketing-automations-pro' ),
			'is_not' => __( 'is not', 'wp-marketing-automations-pro' ),
		);

		return $operators;
	}

	public function get_possible_rule_values() {
		$operators = array(
			'pending'  => __( 'Pending', 'wp-marketing-automations-pro' ),
			'failed'   => __( 'Failed', 'wp-marketing-automations-pro' ),
			'refunded' => __( 'Refunded', 'wp-marketing-automations-pro' ),
			'complete' => __( 'Completed', 'wp-marketing-automations-pro' ),
		);

		return $operators;
	}

	public static function get_mepr_transactions( $user_id, $membership_id ) {
		global $wpdb;
		$status = '';
		try {
			$query = $wpdb->prepare( "SELECT `status` FROM {$wpdb->prefix}mepr_transactions WHERE product_id = %d AND user_id = %d", $membership_id, $user_id );

			$status = $wpdb->get_var( $query );
		} catch ( Error $e ) {
			BWFAN_Common::log_test_data( 'Error in getting membership status: ' . $e->getMessage(), 'memberpress_status', true );
		}

		return $status;
	}
}

#[\AllowDynamicProperties]
class BWFAN_Rule_Mepr_Active_Membership extends BWFAN_Rule_Base {
	public function __construct() {
		$this->v2 = true;
		$this->v1 = false;
		parent::__construct( 'mepr_active_membership' );
	}

	/** v2 Methods: START */

	public function get_options( $term = '' ) {
		return $this->get_possible_rule_values();
	}

	public function get_rule_type() {
		return 'Search';
	}

	public function is_match_v2( $automation_data, $rule_data ) {
		$result = false;
		if ( ! isset( $automation_data['global'] ) || ! is_array( $automation_data['global'] ) ) {
			return $this->return_is_match( $result, $rule_data );
		}
		if ( ! isset( $automation_data['global']['user_id'] ) || ! isset( $automation_data['global']['product_id'] ) || empty( $rule_data['data'] ) ) {
			return $this->return_is_match( $result, $rule_data );
		}
		$type      = $rule_data['rule'];
		$is_active = self::get_mepr_active_status( $automation_data['global']['user_id'], $rule_data['data'] );

		switch ( $type ) {
			case 'is':
				$result = $is_active;
				break;
			case 'is_not':
				$result = ! $is_active;
				break;
			default:
				$result = false;
				break;
		}

		return $this->return_is_match( $result, $rule_data );
	}


	/** v2 Methods: END */

	public function get_possible_rule_operators() {
		$operators = array(
			'is'     => __( 'is', 'wp-marketing-automations-pro' ),
			'is_not' => __( 'is not', 'wp-marketing-automations-pro' ),
		);

		return $operators;
	}

	public function get_possible_rule_values() {
		$result = array();

		$one_time_products = BWFAN_PRO_Common::get_mepr_one_time_subscription_products();
		$rec_products      = BWFAN_PRO_Common::get_mepr_recurring_subscription_products();
		$products          = array_merge( $one_time_products, $rec_products );

		foreach ( $products as $product ) {
			$result[ $product['id'] ] = $product['text'];
		}

		return $result;
	}

	public static function get_mepr_active_status( $user_id, $membership_ids ) {
		$is_active = false;
		foreach ( $membership_ids as $membership_id ) {
			$mepr_user = new \MeprUser( $user_id );
			$is_active = $mepr_user->is_already_subscribed_to( $membership_id['key'] );

			if ( $is_active ) {
				break;
			}
		}

		return $is_active;
	}

}