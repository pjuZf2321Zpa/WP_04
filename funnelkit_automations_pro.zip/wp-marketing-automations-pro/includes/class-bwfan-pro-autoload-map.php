<?php
/**
 * Classmap for lazy-autoloaded, side-effect-free Pro classes.
 *
 * These files were previously eager-loaded on every request (the DB-model
 * directory glob in BWFAN_Pro_DB::load_db_classes). They are pure class
 * definitions with no file-scope side effects and no load-and-wire
 * class_exists() guards, so the autoloader can resolve them on first
 * reference instead — keeping ~92 KB of model code off the hot path.
 *
 * STRICT inclusion rule — only add a class here if ALL hold:
 *   1. Pure-def: no file-scope register()/get_instance()/init()/new/add_action/define.
 *   2. Every class_exists() guard for it is bail-if-unavailable or self-redeclare
 *      (NEVER a "load-and-wire" guard, e.g. if(!class_exists){ require; ::get_instance(); }).
 *   3. Not also defined in Lite (no Lite-shared model or CRM which-copy-wins handoff).
 *      Sole exception: the WooFunnels license classes at the bottom — every copy
 *      (Lite core, Funnel Builder Pro, here) is byte-identical and
 *      class_exists()-guarded, so which copy wins is immaterial.
 *
 * @package BWFAN_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'BWFAN_Model_Broadcast'        => 'includes/db/lazy/class-bwfan-model-broadcast.php',
	'BWFAN_Model_Link_Triggers'    => 'includes/db/lazy/class-bwfan-modal-link-triggers.php',
	'BWFAN_Model_Bulk_Action'      => 'includes/db/lazy/class-bwfan-modal-bulk-actions.php',
	'BWFAN_Model_Form_Feeds'       => 'includes/db/lazy/class-bwfan-model-form-feeds.php',
	'BWFAN_Model_Stripe_Offer'     => 'includes/db/lazy/class-bwfan-model-stripe-offer.php',
	'BWFAN_Model_WCS_Subscriber'   => 'includes/db/lazy/class-bwfan-model-wcs-subscriber.php',
	'BWF_Model_Contact_WLM_Fields' => 'includes/db/lazy/class-bwf-model-contact-wlm-fields.php',
	'BWFAN_Rest_API_DB_Model'      => 'includes/db/lazy/class-bwfan-public-api-db-model.php',
	'BWFCRM_Model_Automations'     => 'includes/db/lazy/class-bwfcrm-model-automations.php',

	/*
	 * CRM abstracts — previously eager-loaded by the register_abstract() glob in
	 * class-marketing-automation-crm.php. Pure class defs; PHP autoloads the
	 * parent when a subclass file (filters/, importers/, api/, forms/, …) loads.
	 */
	'BWFAN_Rest_API_Base'            => 'crm/includes/abstracts/class-bwfan-rest-api-base.php',
	'BWFCRM\Actions\Base'            => 'crm/includes/abstracts/class-bwfcrm-action-base.php',
	'BWFCRM\Calls\Base'              => 'crm/includes/abstracts/class-bwfcrm-calls-base.php',
	'BWFCRM_API_Base'                => 'crm/includes/abstracts/class-bwfcrm-api-base.php',
	'BWFCRM_API_Controller'          => 'crm/includes/abstracts/class-bwfcrm-api-controller.php',
	'BWFCRM_API_Start_Import_Base'   => 'crm/includes/abstracts/class-bwfcrm-api-start-import-base.php',
	'BWFCRM_Custom_Filter_Base'      => 'crm/includes/abstracts/class-bwfcrm-custom-filter-base.php',
	'BWFCRM_Email_Webhook_Base'      => 'crm/includes/abstracts/class-bwfcrm-email-webhook-base.php',
	'BWFAN_Filter_Base'              => 'crm/includes/abstracts/class-bwfcrm-filter-base.php',
	'BWFCRM_Form_Base'               => 'crm/includes/abstracts/class-bwfcrm-form-base.php',
	'BWFCRM_Import_Export_Type'      => 'crm/includes/abstracts/class-bwfcrm-import-export-types.php',
	'BWFCRM_Importer_Base'           => 'crm/includes/abstracts/class-bwfcrm-importer-base.php',
	'BWFCRM_Merge_Tag_Base'          => 'crm/includes/abstracts/class-bwfcrm-merge-tag-base.php',
	'BWFCRM_Transactional_Mail_Base' => 'crm/includes/abstracts/class-bwfcrm-transactional-mail-base.php',

	/*
	 * CRM support classes — previously eager-required in core() /
	 * load_dependencies_support(). Static-call utility classes, never
	 * instantiated by BWFCRM_Core::register_classes(); all consumers reference
	 * them by name (static call / new / class_exists-guarded runtime paths), so
	 * the autoloader resolves them on first use.
	 */
	'BWFAN_Rest_API_Common'          => 'crm/includes/class-bwfan-rest-api-common.php',
	'BWFCRM_Audience'                => 'crm/includes/class-bwfcrm-audience.php',
	'BWFCRM_Broadcast_Processing'    => 'crm/includes/class-bwfcrm-broadcast-processing.php',
	'BWFCRM_Broadcast_Helper'        => 'crm/includes/class-bwfcrm-broadcast-helper.php',
	'BWFCRM_Broadcast_V2_Email_Controller' => 'crm/includes/controllers/class-bwfcrm-broadcast-v2-email-controller.php',
	'BWFAN_Mail_Handler_Controller'  => 'crm/includes/controllers/class-bwfan-mail-handler-controller.php',
	'BWFCRM_Category'                => 'crm/includes/class-bwfcrm-category.php',
	'BWFCRM_Dashboards'              => 'crm/includes/class-bwfcrm-dashboards.php',
	'BWFCRM_Filters'                 => 'crm/includes/class-bwfcrm-filters.php',
	'BWFCRM_Form_Feed'               => 'crm/includes/class-bwfcrm-form-feed.php',
	'BWFCRM_Plugin_Dependency'       => 'crm/includes/class-bwfcrm-plugin-dependency.php',
	'BWFCRM_Reports'                 => 'crm/includes/class-bwfcrm-reports.php',
	'BWFCRM_Templates'               => 'crm/includes/class-bwfcrm-templates.php',
	'BWFAN_Engagement_Tracking'      => 'includes/class-bwfan-engagement-tracking.php',

	/*
	 * CRM actions — previously self-registering at file scope, which blocked
	 * them from this map. Their registrations now live in the declared array
	 * inside BWFCRM_Actions_Handler::load_actions()
	 * (crm/includes/class-bwfcrm-actions.php); the files are pure class
	 * definitions and satisfy rule 1.
	 */
	'BWFCRM\Actions\Autonami\Add_To_Lists'         => 'modules/autonami/crm-actions/class-bwfcrm-action-add-lists.php',
	'BWFCRM\Actions\Autonami\Add_Tags'             => 'modules/autonami/crm-actions/class-bwfcrm-action-add-tags.php',
	'BWFCRM\Actions\Autonami\Add_To_Automation'    => 'modules/autonami/crm-actions/class-bwfcrm-action-add-to-automation.php',
	'BWFCRM\Actions\Autonami\Delete_Contacts'      => 'modules/autonami/crm-actions/class-bwfcrm-action-delete-contacts.php',
	'BWFCRM\Actions\Autonami\End_Automation'       => 'modules/autonami/crm-actions/class-bwfcrm-action-end-automation.php',
	'BWFCRM\Actions\Autonami\Remove_Lists'         => 'modules/autonami/crm-actions/class-bwfcrm-action-remove-lists.php',
	'BWFCRM\Actions\Autonami\Remove_Tags'          => 'modules/autonami/crm-actions/class-bwfcrm-action-remove-tags.php',
	'BWFCRM\Actions\Autonami\Subscribe_Contacts'   => 'modules/autonami/crm-actions/class-bwfcrm-action-subscribe-contacts.php',
	'BWFCRM\Actions\Autonami\Unsubscribe_Contacts' => 'modules/autonami/crm-actions/class-bwfcrm-action-unsubscribe-contacts.php',
	'BWFCRM\Actions\Autonami\Update_Fields'        => 'modules/autonami/crm-actions/class-bwfcrm-action-update-field.php',

	/*
	 * CRM calls — same story as the CRM actions above; registrations moved to
	 * the declared array inside BWFCRM_Calls_Handler::load_calls()
	 * (crm/includes/class-bwfcrm-calls.php). The crm-actions'
	 * class_exists() guards and `new Calls\X` sites autoload these on first
	 * use.
	 */
	'BWFCRM\Calls\Autonami\Add_To_Lists'         => 'modules/autonami/calls/class-bwfcrm-call-add-lists.php',
	'BWFCRM\Calls\Autonami\Add_Tags'             => 'modules/autonami/calls/class-bwfcrm-call-add-tags.php',
	'BWFCRM\Calls\Autonami\Add_To_Automation'    => 'modules/autonami/calls/class-bwfcrm-call-add-to-automation.php',
	'BWFCRM\Calls\Autonami\Delete_Contacts'      => 'modules/autonami/calls/class-bwfcrm-call-delete-contacts.php',
	'BWFCRM\Calls\Autonami\End_Automation'       => 'modules/autonami/calls/class-bwfcrm-call-end-automation.php',
	'BWFCRM\Calls\Autonami\Remove_Lists'         => 'modules/autonami/calls/class-bwfcrm-call-remove-lists.php',
	'BWFCRM\Calls\Autonami\Remove_Tags'          => 'modules/autonami/calls/class-bwfcrm-call-remove-tags.php',
	'BWFCRM\Calls\Autonami\Subscribe_Contacts'   => 'modules/autonami/calls/class-bwfcrm-call-subscribe-contacts.php',
	'BWFCRM\Calls\Autonami\Unsubscribe_Contacts' => 'modules/autonami/calls/class-bwfcrm-call-unsubscribe-contacts.php',
	'BWFCRM\Calls\Autonami\Update_Fields'        => 'modules/autonami/calls/class-bwfcrm-call-update-field.php',

	/*
	 * WooFunnels license classes (activation, daily status check, plugin
	 * updater). Being relocated out of the free plugin's shared core (WP.org
	 * review: no update-checker code in the .org zip). Funnel Builder Pro
	 * ships its copy under modules/funnel-builder-powerpack/license/; this is
	 * the FunnelKit Automations Pro copy, byte-identical to it.
	 *
	 * Pro ships them BEFORE the free plugin drops them: the updater lives in
	 * these classes, so a site that updated the free plugin first, on a Pro
	 * build without them, would never be offered another Pro update.
	 *
	 * This autoloader registers at file scope, ahead of the free core's
	 * (plugins_loaded:-99), so this copy is the one that serves from now on.
	 * Nothing else moves: the /license REST route, the settings-screen license
	 * UI and every woofunnels_plugins_info read stay in the free plugin (option
	 * reads, not update-checker code), and the free core keeps the glue hooks
	 * (fk_fb_every_day -> license_check, funnelkit_license_update -> transient
	 * clear, unlicensed-plugin notice, pro_status) behind class_exists()
	 * guards. If that core ever drops those hooks, port Funnel Builder Pro's
	 * license-module.php. Check: bin/tests/test-license-fallback.php.
	 */
	'WooFunnels_Licenses'           => 'includes/license/class-woofunnels-licenses.php',
	'WooFunnels_License_Controller' => 'includes/license/class-woofunnels-license-controller.php',
	'WooFunnels_License_check'      => 'includes/license/class-woofunnels-license-check.php',
);
