<?php
/**
 * bwfan_wcs_subscriber table class
 *
 */

#[\AllowDynamicProperties]
class BWFAN_DB_Table_WCS_Subscriber extends BWFAN_DB_Tables_Base {
	public $table_name = 'bwfan_wcs_subscriber';

	/**
	 * Get table's columns
	 *
	 * @return string[]
	 */
	public function get_columns() {
		return [
			"ID",
			"cid",
			"user_id",
			"l_order_date",
			"next_renewal_date",
			"active_subscriptions",
			"subscription_products",
			"active_subs_product",
			"active_subs_count",
			"inactive_subs_count",
			"renewal_count"
		];
	}

	/**
	 * Get a query for create table
	 *
	 * @return string
	 */
	public function get_create_table_query() {
		global $wpdb;
		$collate = $this->get_collation();

		return "CREATE TABLE {$wpdb->prefix}$this->table_name (
 		  `ID` int(10) UNSIGNED NOT NULL auto_increment,
		  `cid` int(10) UNSIGNED NULL,
		  `user_id` int(10) UNSIGNED NULL,
		  `l_order_date` datetime DEFAULT NULL,
		  `next_renewal_date` datetime DEFAULT NULL,
		  `active_subscriptions` longtext,
		  `subscription_products` longtext,
		  `active_subs_product` longtext,
		  `active_subs_count` smallint(5) UNSIGNED DEFAULT 0,
		  `inactive_subs_count` smallint(5) UNSIGNED DEFAULT 0,
		  `renewal_count` smallint(5) UNSIGNED DEFAULT 0,
		  PRIMARY KEY (`ID`),
		  UNIQUE KEY `cid` (`cid`),
		  KEY `user_id` (`user_id`)
		  ) $collate;";
	}
}
