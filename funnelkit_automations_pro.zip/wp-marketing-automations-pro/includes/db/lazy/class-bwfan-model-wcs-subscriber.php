<?php

if ( ! class_exists( 'BWFAN_Model_WCS_Subscriber' ) ) {
	#[\AllowDynamicProperties]
	class BWFAN_Model_WCS_Subscriber extends BWFAN_Model {

		public static $primary_key = 'ID';

		/**
		 * Get wcs subscriber by cid
		 *
		 * @param $cid
		 *
		 * @return array
		 */
		public static function get_subscriber( $cid ) {
			global $wpdb;

			$query = "SELECT * FROM {$wpdb->prefix}bwfan_wcs_subscriber WHERE `cid`= %d";

			//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$result = $wpdb->get_row( $wpdb->prepare( $query, $cid ), ARRAY_A );
			if ( empty( $result ) ) {
				return [];
			}

			$result['active_subscriptions']  = ! empty( $result['active_subscriptions'] ) ? json_decode( $result['active_subscriptions'], true ) : [];
			$result['subscription_products'] = ! empty( $result['subscription_products'] ) ? json_decode( $result['subscription_products'], true ) : [];
			$result['active_subs_product']   = ! empty( $result['active_subs_product'] ) ? json_decode( $result['active_subs_product'], true ) : [];

			return $result;
		}
	}
}
