<?php
/**
 * CRM campaign model call.
 *
 * @package Model
 */

/**
 * Campaign Class
 */
#[\AllowDynamicProperties]
class BWFAN_Model_Broadcast extends BWFAN_Model {

	/**
	 * Campaign table fields
	 *
	 * @var array
	 */
	protected static $table_fields = array(
		'id',
		'title',
		'description',
		'type',
		'status',
		'count',
		'processed',
		'created_by',
		'offset',
		'modified_by',
		'execution_time',
		'created_at',
		'data',
	);

	/**
	 * Table order option
	 *
	 * @var array
	 */
	protected static $order_option = array(
		'ASC',
		'DESC',
	);

	/**
	 * Get all campaigns
	 *
	 * @param string $search search string.
	 * @param int $limit data limit.
	 * @param int $offset data offset.
	 * @param string $order data order.
	 * @param string $type broadcast type.
	 * @param string $status broadcast status.
	 * @param string $category broadcast category.
	 *
	 * @return array
	 */
	public static function get_campaigns( $search, $limit, $offset, $order, $type = '', $status = 'all', $category = '' ) {
		global $wpdb;
		$broadcast_table = self::_table();

		/** data not pulled as for large data API calls sometimes fail */
		$broadcast_query = "SELECT `id`, `title`, `category`,`type`, `execution_time`, `status`, `created_at`, `count` FROM $broadcast_table WHERE 1=1 AND `parent` = 0";
		$count_filter    = array(
			'parent' => array(
				'type'     => '%d',
				'value'    => 0,
				'operator' => 'LIKE',
			)
		);
		if ( ! empty( $search ) ) {
			$broadcast_query .= $wpdb->prepare( " AND title LIKE %s", '%' . $wpdb->esc_like( $search ) . '%' );
			$count_filter    = array(
				'title' => array(
					'type'     => '%s',
					'value'    => "%$search%",
					'operator' => 'LIKE',
				),
			);
		}

		if ( ! empty( $type ) ) {
			$broadcast_query      .= $wpdb->prepare( " AND type = %d", $type );
			$count_filter['type'] = array(
				'type'     => '%d',
				'value'    => $type,
				'operator' => 'LIKE',
			);
		}

		if ( $status !== 'all' ) {
			$broadcast_status = '';
			switch ( $status ) {
				case 'scheduled':
					$broadcast_status = [ 2 ];
					break;
				case 'ongoing':
					$broadcast_status = [ 3 ];
					break;
				case 'completed':
					$broadcast_status = [ 4 ];
					break;
				case 'paused':
					$broadcast_status = [ 5, 6 ];
					break;
				case 'cancelled':
					$broadcast_status = [ 7 ];
					break;
			}

			if ( ! empty( $broadcast_status ) ) {
				$count_filter['status'] = array(
					'type'     => '%d',
					'value'    => $broadcast_status,
					'operator' => 'IN',
				);

				$broadcast_status = '(' . implode( ',', $broadcast_status ) . ')';
				$broadcast_query  .= " AND status IN $broadcast_status";
			}
		}
		if ( ! empty( $category ) ) {

			$category_ids = array_map( 'absint', explode( ',', $category ) );
			$conditions   = [];
			global $wpdb;
			foreach ( $category_ids as $category_id ) {
				$conditions[] = $wpdb->prepare( "category LIKE %s", '%"' . $category_id . '"%' );
			}
			$broadcast_query .= " AND (" . implode( ' OR ', $conditions ) . ")";
			$count_filter    = array(
				'category' => array(
					'type'     => '%s',
					'value'    => "%$category%",
					'operator' => 'LIKE',
				),
			);
		}
		$order            = ( 'DESC' === strtoupper( (string) $order ) ) ? 'DESC' : 'ASC';
		$broadcast_query .= " ORDER BY id $order LIMIT " . absint( $offset ) . "," . absint( $limit );
		$broadcasts      = self::get_results( $broadcast_query );
		if ( empty( $search ) && ! empty( $broadcasts ) ) {
			$broadcasts_ids = array_map( function ( $broadcast ) {
				return $broadcast['id'];
			}, $broadcasts );

			$broadcasts = self::include_child_broadcast( $broadcasts_ids, $broadcasts );
		}
		$total = self::count( $count_filter );

		$message = __( 'Got all broadcasts', 'wp-marketing-automations-pro' );
		if ( empty( $broadcasts ) ) {
			$message = __( 'No Broadcast found', 'wp-marketing-automations-pro' );
		}

		return array(
			'data'    => array(
				'campaigns' => self::get_formatted_campaign_data( $broadcasts ),
			),
			'message' => $message,
			'total'   => $total,
		);
	}


	static function count( $data = array() ) {
		global $wpdb;

		$sql        = 'SELECT COUNT(*) AS `count` FROM ' . self::_table() . ' WHERE 1=1';
		$sql_params = [];
		if ( is_array( $data ) && count( $data ) > 0 ) {
			foreach ( $data as $key => $val ) {
				if ( 'IN' === $val['operator'] ) {
					$placeholder = array_fill( 0, count( $val['value'] ), $val['type'] );
					$placeholder = implode( ", ", $placeholder );

					$sql .= " AND `{$key}` {$val['operator']} ({$placeholder})";

					$sql_params = array_merge( $sql_params, $val['value'] );
				} else {
					$sql          .= " AND `{$key}` {$val['operator']} {$val['type']}";
					$sql_params[] = $val['value'];
				}
			}

			if ( ! empty( $sql_params ) ) {
				$sql = $wpdb->prepare( $sql, $sql_params ); // WPCS: unprepared SQL OK
			}
		}

		return $wpdb->get_var( $sql ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	public static function include_open_click_rate( $broadcasts_ids, $broadcasts, $only_engagement_data = false ) {
		global $wpdb;
		$engagement_table  = $wpdb->prefix . 'bwfan_engagement_tracking ';
		/**
		 * Rates are per mail actually sent, not per engagement row.
		 *
		 * The v2 flow creates every recipient's engagement before the first mail goes out, so
		 * COUNT(ID) is the whole audience from the moment preparation finishes - a broadcast that
		 * has sent 5k of 100k with 2k opens would report 2% instead of 40%, and would stay
		 * diluted at the end by every contact recorded as an error at send time. NULLIF keeps the
		 * division safe before anything has been sent; MySQL returns NULL, which reads as 0.
		 */
		$engagement_fields = 'con.`oid`, (SUM(IF(con.`open`>0, 1, 0))/NULLIF(SUM(IF(con.`c_status`=2, 1, 0)), 0)) * 100 AS `open_rate`, SUM(IF(con.`c_status`=2, 1, 0)) AS `sent`, (SUM(IF(con.`click`>0, 1, 0))/NULLIF(SUM(IF(con.`c_status`=2, 1, 0)), 0)) * 100 AS `click_rate`';

		$broadcasts_ids = implode( ',', array_map( 'absint', (array) $broadcasts_ids ) );

		$engagement_query = "SELECT $engagement_fields FROM $engagement_table AS con WHERE con.`oid` IN ($broadcasts_ids) AND con.`type` = 2 GROUP BY con.`oid`";
		$engagements      = self::get_results( $engagement_query );

		if ( true === $only_engagement_data ) {
			return $engagements;
		}

		foreach ( $engagements as $engagement ) {
			$broadcasts = array_map( function ( $broadcast ) use ( $engagement ) {
				if ( $broadcast['id'] === $engagement['oid'] ) {
					unset( $engagement['oid'] );

					return array_merge( $broadcast, $engagement );
				}

				return $broadcast;
			}, $broadcasts );
		}

		return $broadcasts;
	}

	public static function include_child_broadcast( $broadcasts_ids, $broadcasts ) {
		$child_broadcasts = self::get_broadcast_child( $broadcasts_ids );

		if ( empty( $child_broadcasts ) ) {
			return $broadcasts;
		}

		$child = array();
		foreach ( $child_broadcasts as $child_broadcast ) {
			$child[ absint( $child_broadcast['parent'] ) ][] = $child_broadcast;
		}
		$broadcasts = array_map( function ( $broadcast ) use ( $child ) {
			$broadcast_id = absint( $broadcast['id'] );
			if ( isset( $child[ $broadcast_id ] ) ) {
				$child_broadcasts      = array_map( function ( $child_broadcast ) {
					/** Get grand child */
					$grand_child = self::get_broadcast_child( $child_broadcast['id'] );

					if ( ! empty( $grand_child ) ) {
						$child_broadcast['children'] = $grand_child;
					}

					return $child_broadcast;

				}, $child[ $broadcast_id ] );
				$broadcast['children'] = $child_broadcasts;
			}

			return $broadcast;
		}, $broadcasts );

		return $broadcasts;
	}

	public static function get_broadcast_child( $broadcast_ids, $return_ids = false ) {
		$broadcast_table = self::_table();
		$broadcast_query = "SELECT `id`, `title`, `type`, `data`, `created_at`, `execution_time`, `status`, `count`, `parent` FROM $broadcast_table WHERE 1=1";
		if ( is_array( $broadcast_ids ) ) {
			$broadcast_ids   = implode( ',', array_map( 'absint', $broadcast_ids ) );
			$broadcast_query .= " AND `parent` in ($broadcast_ids)";
		} elseif ( is_numeric( $broadcast_ids ) ) {
			$broadcast_query .= " AND `parent` = $broadcast_ids";
		}
		$broadcast_query  .= ' ORDER BY `id`';
		$child_broadcasts = self::get_results( $broadcast_query );
		$broadcasts_ids   = array_map( function ( $child_broadcast ) {
			return $child_broadcast['id'];
		}, $child_broadcasts );
		if ( empty( $broadcasts_ids ) ) {
			return array();
		}

		if ( true === $return_ids ) {
			return $broadcasts_ids;
		}

		$child_broadcasts = self::include_conversion_into_campaigns( $child_broadcasts );

		return self::get_formatted_campaign_data( $child_broadcasts );
	}

	public static function include_conversion_into_campaigns( $campaigns, $only_conversion_data = false ) {
		global $wpdb;
		if ( ! is_array( $campaigns ) || 0 === count( $campaigns ) ) {
			return $campaigns;
		}

		$ids = array_map( function ( $campaign ) {
			return isset( $campaign['id'] ) ? absint( $campaign['id'] ) : false;
		}, $campaigns );

		$ids = implode( ',', array_filter( $ids ) );

		$query       = "SELECT `oid`, count(`ID`) AS `conversions`, SUM(`wctotal`) AS `revenue` FROM {$wpdb->prefix}bwfan_conversions WHERE `oid` IN ($ids) AND `otype` = 2 GROUP BY `oid`";
		$conversions = $wpdb->get_results( $query, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( true === $only_conversion_data ) {
			return $conversions;
		}
		$campaigns = array_map( function ( $campaign ) use ( $conversions ) {
			if ( ! isset( $campaign['id'] ) ) {
				return false;
			}

			foreach ( $conversions as $conversion ) {
				if ( absint( $campaign['id'] ) === absint( $conversion['oid'] ) ) {
					return array_replace( $campaign, $conversion );
				}
			}

			return $campaign;
		}, $campaigns );

		return array_filter( $campaigns );
	}

	/**
	 * Get campaign details
	 *
	 * @param $campaign_id
	 * @param false $steps
	 * @param bool $ab_mode
	 *
	 * @return array
	 */
	public static function get_campaign( $campaign_id, $steps = false, $ab_mode = false ) {
		global $wpdb;

		/** Default response, returned as-is when no broadcast could be loaded below */
		$response = array(
			'data'    => array(),
			'message' => __( 'No broadcast found for the given ID.', 'wp-marketing-automations-pro' ),
			'status'  => 404,
		);

		$campaign = self::get_specific_rows( 'id', $campaign_id );
		if ( ! is_array( $campaign ) || ! isset( $campaign[0] ) || ! isset( $campaign[0]['id'] ) || absint( $campaign[0]['id'] ) !== absint( $campaign_id ) ) {
			return $response;
		}

		/** Check if status is draft or scheduled */
		if ( in_array( absint( $campaign[0]['status'] ), array( BWFCRM_Campaigns::$CAMPAIGN_DRAFT, BWFCRM_Campaigns::$CAMPAIGN_SCHEDULED ) ) && ! $ab_mode ) {
			$data = self::get_formatted_campaign_data( $campaign )[0];

			/** Built by the same helper the running branch below uses, so both say the same thing */
			$campaign_notice = self::get_campaign_notice_data( $data['status'] ?? '', $data['data'] ?? [], $data );

			/** Still creating only while the flag reads 0 - once it is 1 the engagements are all in */
			$data['engagement_creating'] = isset( $data['data']['engagements_created'] ) && 0 === intval( $data['data']['engagements_created'] );
			$data['notice_data']         = $campaign_notice;

			return array(
				'data'    => $data,
				'status'  => 200,
				'message' => __( 'Broadcast loaded', 'wp-marketing-automations-pro' ),
			);
		}

		$campaign_notice = [];

		/** Get Broadcast */
		$broadcast = array();
		if ( ! $ab_mode ) {
			$broadcast_table = self::_table();
			$query           = "SELECT * from {$broadcast_table} WHERE `id` = '$campaign_id' LIMIT 0, 1";
			$broadcast       = $wpdb->get_row( $query, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		}

		/** Check if the broadcast is grandchild */
		if ( isset( $broadcast['parent'] ) && ! empty( absint( $broadcast['parent'] ) ) ) {
			$parent = absint( $broadcast['parent'] );
			$parent = self::get( $parent );
			if ( is_array( $parent ) && isset( $parent['parent'] ) && ! empty( absint( $parent['parent'] ) ) ) {
				$broadcast['is_unopen_grandchild'] = true;
			}
		}

		/** Get broadcast's engagement Data grouped by TID (Template ID) */
		$engagement_table = $wpdb->prefix . 'bwfan_engagement_tracking';
		/** Per mail sent rather than per engagement row - see the note in include_open_click_rate() */
		$columns          = 'SUM(`open`) AS `open_count`, (SUM(IF(`open`>0, 1, 0))/NULLIF(SUM(IF(`c_status`=2, 1, 0)), 0)) * 100 AS `open_rate`, SUM(`click`) AS `click_count`, (SUM(IF(`click`>0, 1, 0))/NULLIF(SUM(IF(`c_status`=2, 1, 0)), 0)) * 100 AS `click_rate`, SUM(IF(`c_status`=2, 1, 0)) AS `sent`, `tid`';
		$group_sql        = $ab_mode ? 'GROUP BY `tid`' : '';
		$query            = "SELECT $columns FROM {$engagement_table} WHERE `oid` = '$campaign_id' AND `type` = 2 $group_sql";
		$engagements      = $wpdb->get_results( $query, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		/** Get Conversions Grouped by TID */
		$conversions = array();
		if ( ! empty( $engagements ) ) {
			$campaign = array_map( function ( $data ) {
				$data['data'] = json_decode( $data['data'], true );

				return $data;
			}, $campaign );

			$template_ids = [];
			if ( isset( $campaign[0]['data']['content'] ) ) {
				foreach ( $campaign[0]['data']['content'] as $content ) {
					if ( isset( $content['template_id'] ) ) {
						$template_ids[] = $content['template_id'];
					}
				}
			}
			$conversions = self::get_conversions_by_tids( $campaign_id, $ab_mode, $template_ids );
		}

		/** Combine Engagements and Conversion data by TID */
		$final_broadcast = array();

		/**
		 * In A/B mode conversions are keyed by tid, otherwise it already holds the totals.
		 * Used as the per-engagement fallback so a tid missing from the conversions result
		 * reports zero instead of inheriting the previously matched tid's numbers.
		 */
		$default_conversion_data = array( 'conversions' => 0, 'revenue' => 0 );
		if ( ! $ab_mode && isset( $conversions['conversions'] ) ) {
			$default_conversion_data = $conversions;
		}

		if ( ! empty( $engagements ) ) {
			foreach ( $engagements as $engagement ) {
				$tid             = absint( $engagement['tid'] );
				$broadcast['id'] = $campaign_id;
				$engagement      = array_replace( $engagement, $broadcast );
				$conversion_data = $default_conversion_data;
				if ( isset( $conversions[ $tid ] ) && is_array( $conversions[ $tid ] ) ) {
					$conversion_data = $conversions[ $tid ];
				}
				$engagement        = array_replace( $engagement, $conversion_data );
				$final_broadcast[] = $engagement;
			}
		}

		if ( empty( $final_broadcast ) ) {
			$final_broadcast[] = $broadcast;
		}

		$campaign = $final_broadcast;
		if ( is_array( $campaign ) && count( $campaign ) > 0 && isset( $campaign[0]['id'] ) && ! empty( $campaign[0]['id'] ) ) {
			$campaign = self::get_formatted_campaign_data( $campaign );
			$campaign = $ab_mode ? $campaign : $campaign[0];
		} else {
			$campaign = false;
		}
		// handle broadcast notice data.
		$campaign_notice = [];
		if ( ! $ab_mode ) {
			$campaign_notice = self::get_campaign_notice_data( $campaign['status'], $campaign['data'] ?? [], $campaign );
		}

		if ( ! empty( $campaign ) ) {
			if ( ! empty( $campaign_notice ) ) {
				$campaign['notice_data'] = $campaign_notice;
			}

			$response['data']    = $campaign;
			$response['status']  = 200;
			$response['message'] = __( 'Broadcast loaded for ID: ', 'wp-marketing-automations-pro' ) . $campaign_id;
		}
		if ( $steps ) {
			$response['data']['step'] = 1;
		}

		return $response;
	}

	/**
	 * Get campaign notice data
	 *
	 * @param string $campaign_status campaign status.
	 * @param array $data campaign data.
	 * @param array $broadcast Broadcast row, read for `execution_time`, `count`, `e_processed` and `processed`
	 *
	 * @return array
	 */
	public static function get_campaign_notice_data( $campaign_status = '', $data = [], $broadcast = [] ) {
		if ( empty( $campaign_status ) || empty( $data ) ) {
			return [];
		}
		$campaign_notice = [];
		$campaign_status = absint( $campaign_status );

		/**
		 * Read once for both of the progress notices below.
		 *
		 * `count` is the audience size, `e_processed` the recipients prepared so far and
		 * `processed` the mails actually sent - all three live on the broadcast row, so they are
		 * absent on the get_broadcast_stats() call that builds this notice from the data blob
		 * alone. Every use below is gated on the count being there rather than defaulted, so that
		 * caller keeps the plain wording instead of announcing "0 of 0".
		 */
		$total_recipients = isset( $broadcast['count'] ) ? absint( $broadcast['count'] ) : 0;
		$execution_ts     = ! empty( $broadcast['execution_time'] ) ? strtotime( $broadcast['execution_time'] ) : 0;
		$now_ts           = current_time( 'timestamp', 1 );

		/** execution_time is stored in UTC and this is read by a human, so print it on the site's clock */
		$starts_at = $execution_ts > 0 ? get_date_from_gmt( $broadcast['execution_time'], get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) ) : '';

		/**
		 * Recipients are still being prepared for this broadcast.
		 *
		 * Running counts, because that is where most of the preparation happens. A broadcast is
		 * prepared up to an hour early and it starts while the broadcast is still scheduled, but on
		 * any sizeable audience it carries on well past the execution time - by which point the
		 * broadcast has been moved to running, and the notice would disappear at exactly the moment
		 * it is worth showing. Smart sending puts the flag back to 0 a second time, when the winner
		 * is declared and the rest of the recipients are prepared, and the broadcast is running
		 * throughout that too.
		 *
		 * Scheduled counts as well, but only inside the hour the preparation actually runs in. It
		 * is the only thing that explains the missing Edit Broadcast button, which the report hides
		 * on `engagement_creating`. Hitting the daily send cap part way through pushes
		 * execution_time out by hours, so without the window a stalled broadcast would go on
		 * claiming to be preparing recipients for as long as it sat there. The hour is the one
		 * get_broadcasts_by_status() picks v2 broadcasts up in.
		 */
		if ( isset( $data['engagements_created'] ) && 0 === intval( $data['engagements_created'] ) ) {
			$preparing = BWFCRM_Campaigns::$CAMPAIGN_RUNNING === $campaign_status;

			if ( ! $preparing && BWFCRM_Campaigns::$CAMPAIGN_SCHEDULED === $campaign_status && $execution_ts > 0 ) {
				$preparing = $execution_ts <= ( $now_ts + HOUR_IN_SECONDS );
			}

			if ( $preparing ) {
				$prepared = isset( $broadcast['e_processed'] ) ? absint( $broadcast['e_processed'] ) : 0;

				/**
				 * The count is only printed when the row carries one and it still bounds the
				 * progress. `count` is a snapshot of the audience taken when the broadcast was
				 * scheduled, and a segment that has shrunk since would otherwise read as
				 * "12,600 of 12,500 ready".
				 */
				if ( $total_recipients > 0 && $prepared <= $total_recipients ) {
					/* translators: 1: recipients prepared so far, 2: total audience size */
					$msg = sprintf( __( 'Preparing recipients - %1$s of %2$s ready.', 'wp-marketing-automations-pro' ), number_format_i18n( $prepared ), number_format_i18n( $total_recipients ) );
				} else {
					$msg = __( 'Preparing the recipients of this broadcast.', 'wp-marketing-automations-pro' );
				}

				/**
				 * The start time is worth printing only while it is still ahead. Preparation runs
				 * well past the execution time on any sizeable audience, and "sending starts at
				 * 6:30 pm" read at 7:10 pm is the opposite of reassuring.
				 */
				if ( $execution_ts > $now_ts && '' !== $starts_at ) {
					/* translators: %s: local date and time sending begins */
					$msg .= ' ' . sprintf( __( 'Sending starts at %s.', 'wp-marketing-automations-pro' ), $starts_at );
				} else {
					$msg .= ' ' . __( 'Sending begins as soon as this finishes.', 'wp-marketing-automations-pro' );
				}

				$campaign_notice[] = array(
					'msg'  => $msg,
					'type' => 'info',
				);
			}
		}

		/**
		 * Prepared, and now waiting on the clock.
		 *
		 * v2 creates every engagement up to an hour before the execution time, so a broadcast can
		 * sit fully prepared with nothing sent - and once it has moved to running, "ongoing" next
		 * to a zero sent count reads like a stall. Nothing else on the screen explains the gap.
		 *
		 * Only while nothing has gone out yet: after the first mail the sent count speaks for
		 * itself, and a broadcast delayed part way through (the daily send cap pushes
		 * execution_time out) would otherwise claim its whole audience was still queued.
		 */
		if ( isset( $data['engagements_created'] ) && 1 === intval( $data['engagements_created'] )
		     && $total_recipients > 0
		     && 0 === ( isset( $broadcast['processed'] ) ? absint( $broadcast['processed'] ) : 0 )
		     && in_array( $campaign_status, array( BWFCRM_Campaigns::$CAMPAIGN_SCHEDULED, BWFCRM_Campaigns::$CAMPAIGN_RUNNING ), true ) ) {

			if ( $execution_ts > $now_ts && '' !== $starts_at ) {
				/* translators: 1: total audience size, 2: local date and time sending begins */
				$msg = sprintf( __( 'All %1$s recipients are queued. Sending begins at %2$s.', 'wp-marketing-automations-pro' ), number_format_i18n( $total_recipients ), $starts_at );
			} else {
				/* translators: %s: total audience size */
				$msg = sprintf( __( 'All %s recipients are queued. Sending starts within a few minutes.', 'wp-marketing-automations-pro' ), number_format_i18n( $total_recipients ) );
			}

			$campaign_notice[] = array(
				'msg'  => $msg,
				'type' => 'info',
			);
		}

		/** The reason is read straight off the data blob - the `$campaign` this used to test for does not exist here, so it always fell through to the fallback and the reason never reached the screen */
		if ( BWFCRM_Campaigns::$CAMPAIGN_HALT === $campaign_status ) {
			$campaign_notice[] = array(
				'msg'    => sprintf( '%s %s', "<b>" . __( 'Broadcast Halted:', 'wp-marketing-automations-pro' ) . " </b>", ! empty( $data['halt_reason'] ) ? $data['halt_reason'] : __( 'Unknown error occurred', 'wp-marketing-automations-pro' ) ),
				'isHtml' => true,
				'type'   => 'warning',
			);
		}

		if ( BWFCRM_Campaigns::$CAMPAIGN_RUNNING === $campaign_status && isset( $data['smart_send']['enable'] ) && 1 === intval( $data['smart_send']['enable'] ) && ( isset( $data['hold_broadcast'] ) && 1 === intval( $data['hold_broadcast'] ) ) ) {
			/** Counted defensively: content is an array on every broadcast that reaches this point, and count() on anything else is fatal on PHP 8 */
			$value             = isset( $data['content'] ) && is_array( $data['content'] ) ? count( $data['content'] ) : 0;
			$value             = ( 2 === $value ) ? __( 'two', 'wp-marketing-automations-pro' ) : __( 'three', 'wp-marketing-automations-pro' );
			$message           = sprintf( __( 'We\'ve sent %s email variants to %s of your contacts. The version with the highest open rate will be sent to the rest.', 'wp-marketing-automations-pro' ), $value, intval( $data['smart_send']['percent'] ) . '%' );
			$campaign_notice[] = array(
				'msg'  => $message,
				'type' => 'info',
			);
		}

		/**
		 * Paused by repeated send failures.
		 *
		 * Keyed on the status rather than on the size of the list. v1 pauses after 20 consecutive
		 * failures and empties the list on the first success, so its count was the threshold; v2
		 * pauses after BWFCRM_Broadcast_V2_Email_Controller::$CONSECUTIVE_FAILURE_LIMIT of them and
		 * then keeps every failure of the run, because update_status_to_ongoing() reads the list
		 * back to re-open those engagements on resume. Counting to 20 here therefore stayed silent
		 * on a v2 broadcast that had just paused, and spoke up on one that was still sending.
		 */
		/**
		 * Decided per flow. v2 writes `failed_cids` only when it pauses, so the list being there
		 * is the verdict. v1 writes it on every failure and empties it on the next success, so
		 * on that flow the list means "recent failures", not "paused by them" - a v1 broadcast
		 * paused by hand with a few recent failures showed this notice and sent the admin after
		 * an SMTP fault that did not exist. v1's own threshold is the correct test there.
		 */
		$paused_by_failures = ! empty( $data['v2'] )
			? ! empty( $data['failed_cids'] )
			: ( isset( $data['failed_cids'] ) && count( (array) $data['failed_cids'] ) >= 20 );

		if ( BWFCRM_Campaigns::$CAMPAIGN_PAUSED === $campaign_status && $paused_by_failures ) {
			$message = __( 'Broadcast has been paused because consecutive emails failed to send through your email service provider. Please check the email logs, verify your SMTP plugin and email service configuration, and resolve any connection or authentication issues. Once resolved, you can resume the broadcast.', 'wp-marketing-automations-pro' );

			$failed_reason = ! empty( $data['failed_reason'] ) ? implode( '<br/>', (array) $data['failed_reason'] ) : '';
			if ( ! empty( $failed_reason ) ) {
				/** translators: 1: the advice above, 2: the error the provider returned */
				$message = sprintf( __( '%1$s<br/><br/>The error message received from the provider is: "%2$s"', 'wp-marketing-automations-pro' ), $message, $failed_reason );
			}

			$campaign_notice[] = array(
				'msg'    => $message,
				'type'   => 'error',
				'isHtml' => true,
			);
		}

		return $campaign_notice;
	}

	/**
	 * Get conversions group by template id of broadcast
	 *
	 * @param $broadcast_id
	 * @param $ab_mode
	 * @param $tids
	 *
	 * @return array|int[]
	 */
	public static function get_conversions_by_tids( $broadcast_id, $ab_mode = true, $tids = [] ) {
		if ( empty( $tids ) ) {
			return [ 'conversions' => 0, 'revenue' => 0 ];
		}
		global $wpdb;
		$conversion_table = $wpdb->prefix . 'bwfan_conversions';
		$engagement_table = $wpdb->prefix . 'bwfan_engagement_tracking';

		$args        = [ $broadcast_id, 2 ];
		$placeholder = array_fill( 0, count( $tids ), '%d' );
		$placeholder = implode( ", ", $placeholder );
		$args        = array_merge( $args, $tids );

		$columns = 'COUNT(con.ID) AS conversions, COALESCE(SUM(con.wctotal), 0) AS `revenue`, et.`tid` ';

		/**
		 * Scope the joined conversions to the same source as the engagement row.
		 * `trackid` only points at an engagement row, it does not identify the source, so
		 * without `oid`/`otype` in the ON clause a conversion recorded against another
		 * broadcast or automation gets counted into this broadcast's totals.
		 * These stay in the ON clause so tids with no conversions still return a 0 row.
		 */
		$query          = $wpdb->prepare( "SELECT $columns FROM {$engagement_table} AS `et` LEFT JOIN {$conversion_table} AS `con` ON et.`ID` = con.`trackid` AND con.`oid` = et.`oid` AND con.`otype` = et.`type` WHERE et.`oid` = %d AND et.`type` = %d AND et.`tid` IN ($placeholder) GROUP BY et.`tid`", $args );
		$converted_tids = $wpdb->get_results( $query, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( empty( $converted_tids ) ) {
			return [];
		}

		$conversion_data  = array();
		$conversion_count = 0;
		$revenue          = 0;
		foreach ( $converted_tids as $conversions ) {
			$tid = $conversions['tid'];
			if ( false === $ab_mode ) {
				$conversion_count += isset( $conversions['conversions'] ) ? intval( $conversions['conversions'] ) : 0;
				$revenue          += isset( $conversions['revenue'] ) ? floatval( $conversions['revenue'] ) : 0;
				continue;
			}
			$conversion_data[ intval( $tid ) ] = $conversions;
		}

		if ( false === $ab_mode ) {
			return [
				'conversions' => $conversion_count,
				'revenue'     => $revenue
			];
		}

		return $conversion_data;
	}

	/**
	 * Get un-subscribers count of a broadcast campaign
	 *
	 * @param $campaign_id
	 *
	 * @return int
	 */
	public static function get_campaign_unsubscribers( $campaign_id ) {
		global $wpdb;
		$query = "SELECT COUNT(*) FROM {$wpdb->prefix}bwfan_message_unsubscribe WHERE `automation_id` = $campaign_id AND `c_type` = 2";

		return intval( $wpdb->get_var( $query ) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * Create a new campaign
	 *
	 * @param string $title campaign title.
	 * @param string $desc campaign description.
	 * @param int $type campaign type.
	 * @param int $created_by created user id.
	 *
	 * @return array
	 */
	public static function create_campaign( $title, $desc, $type, $created_by, $createUnopen = false ) {
		$status  = 404;
		$data    = array();
		$message = __( 'Unable to create broadcast.', 'wp-marketing-automations-pro' );

		$db_arr = array(
			'title'         => $title,
			'description'   => $desc,
			'created_by'    => $created_by,
			'type'          => $type,
			'modified_by'   => $created_by,
			'created_at'    => current_time( 'mysql', 1 ),
			'last_modified' => current_time( 'mysql', 1 ),
		);

		/** Create as Unopen Broadcast */
		if ( ! empty( $createUnopen ) ) {
			/** Set Parent ID of broadcast */
			$parent           = absint( $createUnopen );
			$db_arr['parent'] = $parent;

			$parent = self::get( $parent );
			if ( ! empty( $parent['data'] ) ) {
				$parent_data = json_decode( $parent['data'], true );

				/** Remove Unnecessary Parent data */
				if ( is_array( $parent_data ) ) {
					unset( $parent_data['exclude'] );
					unset( $parent_data['filters'] );
					unset( $parent_data['is_promotional'] );
					unset( $parent_data['halt_reason'] );

					unset( $parent_data['winner'] );
					if ( isset( $parent_data['smart_send_stat'] ) ) {
						unset( $parent_data['smart_send_stat'] );
					}
					unset( $parent_data['hold_broadcast'] );
					unset( $parent_data['smart_sending_done'] );
				}

				$db_arr['data'] = wp_json_encode( $parent_data );
			}
		}

		self::insert( $db_arr );
		$campaign_id = self::insert_id();

		if ( $campaign_id ) {
			$campaign = self::get_specific_rows( 'id', $campaign_id );
			$data     = self::get_formatted_campaign_data( $campaign )[0];
			$status   = 200;
			$message  = __( 'Broadcast created', 'wp-marketing-automations-pro' );
		}

		return array(
			'data'    => $data,
			'message' => $message,
			'status'  => $status,
		);
	}

	/**
	 * Delete a particular campaign
	 *
	 * @param int $campaign_id campaign Id.
	 *
	 * @return  array
	 */
	public static function delete_campaign( $campaign_id ) {
		$status  = 404;
		$data    = array();
		$message = __( 'Unable to delete the broadcast.', 'wp-marketing-automations-pro' );

		BWFCRM_Category::handle_category_count_decrease( $campaign_id ?? [], BWFCRM_Category::$BROADCAST );

		$campaign = self::delete( $campaign_id );

		if ( (bool) $campaign ) {
			$data    = array();
			$status  = 200;
			$message = __( 'Broadcast deleted', 'wp-marketing-automations-pro' );
			self::remove_parent_from_child( [ $campaign_id ] );
		}

		return array(
			'data'    => $data,
			'message' => $message,
			'status'  => $status,
		);
	}

	/**
	 * Update campaign
	 *
	 * @param int $campaign_id campaign id.
	 * @param int $step step id.
	 * @param array $data campaign data to update.
	 *
	 * @return array
	 */
	public static function update_campaign( $campaign_id, $step, $data ) {
		$status          = 404;
		$res_data        = array();
		$message         = __( 'Unable to update the broadcast.', 'wp-marketing-automations-pro' );
		$campaign        = self::get_specific_rows( 'id', $campaign_id );
		$current_user_id = get_current_user_id();

		/** checking if user not exists than return in broadcast update */
		if ( empty( $current_user_id ) ) {
			$message = __( 'Permission denied, no valid user available', 'wp-marketing-automations-pro' );

			return array(
				'data'    => $res_data,
				'status'  => $status,
				'message' => $message,
			);
		}

		if ( empty( $campaign ) ) {
			return array(
				'data'    => $res_data,
				'status'  => $status,
				'message' => $message,
			);
		}

		$campaign_data = isset( $campaign[0]['data'] ) && ! empty( $campaign[0]['data'] ) ? json_decode( $campaign[0]['data'], true ) : array();

		/** Snapshot before this call edits it, so a step can tell what it actually changed */
		$previous_data = is_array( $campaign_data ) ? $campaign_data : array();
		$error         = false;

		/**
		 * Audience inputs compared by meaning, not by encoding: a flag that was never stored reads
		 * as false, and an exclusion list is the same list whatever its order or the type of its
		 * ids. Without this a title-only save on a row that predates one of the keys counted as an
		 * audience change - resetting a prepared run, or refusing the save on a locked one.
		 */
		$audience_norm = static function ( $key, $value ) {
			if ( 'exclude' === $key ) {
				$ids = array_values( array_unique( array_map( 'absint', (array) $value ) ) );
				sort( $ids );

				return wp_json_encode( $ids );
			}

			return ( empty( $value ) || 'false' === $value ) ? 0 : 1;
		};

		/**
		 * The data blob a step writes: only the keys that step owns, merged over a fresh read.
		 *
		 * $campaign_data is the row as it was read at the top of this call. A worker on a prepared
		 * or running broadcast writes engagements_created, the failure counters and the top-up
		 * cursor between that read and the write below, and writing the whole snapshot back
		 * reverted every one of them - engagements_created back to 0 sent the dispatcher into
		 * creation on a broadcast that was already sending. Everything a step does not own is
		 * whatever the row holds now.
		 */
		$merged_data = static function ( array $keys ) use ( &$campaign_data, $campaign_id ) {
			$stored = self::get( absint( $campaign_id ) );
			$fresh  = ! empty( $stored['data'] ) ? json_decode( $stored['data'], true ) : null;
			$base   = is_array( $fresh ) ? $fresh : $campaign_data;

			return wp_json_encode( array_replace( $base, array_intersect_key( $campaign_data, array_flip( $keys ) ) ) );
		};

		/**
		 * A finished broadcast keeps what it sent with. The screen never offers Edit on a completed
		 * or cancelled row, but the wizard opens for any status through the `edit=true` URL, and
		 * every step below wrote through: the audience count on the report moved, the content the
		 * report links to changed, and step 4 put a finished broadcast back on the calendar. Only
		 * the name and description may still change; everything else is a duplicate's job.
		 */
		$finished = self::is_finished_status( $campaign[0]['status'] ?? 0 );

		if ( 1 == $step ) {
			if ( empty( $data['title'] ) ) {
				$error   = true;
				$message = __( 'Broadcast name is required.', 'wp-marketing-automations-pro' );
			}
			if ( ! $error && ( intval( $data['type'] ) <= 0 || ! in_array( intval( $data['type'] ), array( 1, 2, 3 ), true ) ) ) {
				$error   = true;
				$message = __( 'Broadcast type is required.', 'wp-marketing-automations-pro' );
			}
			if ( ! $error ) {
				$campaign_data['is_promotional']    = $data['promotional'];
				$campaign_data['ab_type']           = $data['ab_type'];
				$campaign_data['exclude']           = $data['exclude'];
				$campaign_data['includeSoftBounce'] = isset( $data['includeSoftBounce'] ) ? $data['includeSoftBounce'] : false;
				$campaign_data['includeUnverified'] = isset( $data['includeUnverified'] ) ? $data['includeUnverified'] : false;
				/**
				 * Only when an audience input actually moved.
				 *
				 * is_promotional, exclude and includeUnverified are each an input to
				 * get_broadcast_query_args(), so a change to any of them invalidates a prepared
				 * run. Title, description and type ride along in the same step though, and
				 * resetting on those as well would throw a prepared broadcast away because
				 * somebody fixed a typo in its name - deleting every engagement and, on a large
				 * list, leaving no time to rebuild before the execution time.
				 *
				 * includeSoftBounce belongs here for the same reason: it is an input to
				 * get_broadcast_query_args(), so flipping it changes who the broadcast reaches
				 * and a run prepared under the old answer is no longer the right audience.
				 */
				$audience_keys = array( 'is_promotional', 'exclude', 'includeSoftBounce', 'includeUnverified' );
				$audience_changed = false;
				foreach ( $audience_keys as $key ) {
					$before = $audience_norm( $key, $previous_data[ $key ] ?? null );
					$after  = $audience_norm( $key, $campaign_data[ $key ] ?? null );
					if ( $before !== $after ) {
						$audience_changed = true;
						break;
					}
				}

				/** Same refusal the content step makes - see audience_locked() */
				if ( $audience_changed && ( $finished || self::audience_locked( $campaign[0], $previous_data ) ) ) {
					return $finished ? self::finished_response() : self::audience_locked_response();
				}

				self::update( array(
					'title'         => $data['title'],
					'type'          => $data['type'],
					'description'   => $data['description'],
					'modified_by'   => $current_user_id,
					'data'          => $merged_data( array( 'is_promotional', 'ab_type', 'exclude', 'includeSoftBounce', 'includeUnverified' ) ),
					'last_modified' => current_time( 'mysql', 1 ),
				), array(
					'id' => $campaign_id,
				) );

				if ( $audience_changed ) {
					self::reset_prepared_broadcast( $campaign_id );
				}
			}
		}

		if ( 2 == $step ) {
			if ( $finished ) {
				return self::finished_response();
			}

			$campaign_data['filters'] = $data['filters'];
			$campaign_data['exclude'] = $data['exclude'];
			$total_count              = isset( $data['count'] ) ? $data['count'] : 0;

			/**
			 * The stored filters are compared in the form the wizard was handed them: get_campaign()
			 * runs them through prepare_stored_filters_for_admin() (legacy-format conversion, label
			 * refresh) and the wizard posts that back, so the raw blob against the posted copy read
			 * as a change on every pass whenever a tag or list had been renamed since the save.
			 */
			$stored_filters = $previous_data['filters'] ?? null;
			if ( is_array( $stored_filters ) && class_exists( 'BWFAN_PRO_Common' ) && method_exists( 'BWFAN_PRO_Common', 'prepare_stored_filters_for_admin' ) ) {
				$stored_filters = BWFAN_PRO_Common::prepare_stored_filters_for_admin( $stored_filters );
			}
			$audience_changed = BWFCRM_Campaigns::content_fingerprint( $stored_filters ) !== BWFCRM_Campaigns::content_fingerprint( $data['filters'] ?? null )
								|| $audience_norm( 'exclude', $previous_data['exclude'] ?? null ) !== $audience_norm( 'exclude', $data['exclude'] ?? null );

			/** Same refusal the content step makes - see audience_locked() */
			if ( $audience_changed && self::audience_locked( $campaign[0], $previous_data ) ) {
				return self::audience_locked_response();
			}

			$columns = array(
				'data'          => $merged_data( array( 'filters', 'exclude' ) ),
				'modified_by'   => $current_user_id,
				'last_modified' => current_time( 'mysql', 1 ),
			);

			/**
			 * `count` belongs to the preparation once there is one: it is what the engagements were
			 * built against and what progress and the smart-send percentage are measured on. The
			 * wizard's live figure only replaces it when the audience actually changed - and then
			 * the reset below rebuilds the engagements to match - or when nothing was prepared yet.
			 */
			if ( $audience_changed || empty( $previous_data['prepared_for'] ) ) {
				$columns['count'] = $total_count;
			}

			self::update( $columns, array(
				'id' => $campaign_id,
			) );

			/** The audience changed, so anything prepared against the old one has to go */
			if ( $audience_changed ) {
				self::reset_prepared_broadcast( $campaign_id );
			}
		}

		if ( 3 == $step ) {
			if ( $finished ) {
				return self::finished_response();
			}

			/**
			 * The second door onto the same content, guarded like the first.
			 *
			 * BWFCRM_Campaigns::save_broadcast_content() refuses a content change on a prepared
			 * broadcast that can no longer be reset; this step writes data.content too, so without
			 * the same test it swaps the body underneath a send in flight and the reset below
			 * silently returns false. Engagements already created keep the old body and an old
			 * template id, and the ones created after get the new one.
			 *
			 * Both the comparison and the status test are borrowed from that method rather than
			 * written again. wp_json_encode() is order sensitive and the stored blob has been
			 * through a json round trip while the incoming content has not, so comparing them
			 * directly reports a save that changed nothing as a change - and here that means a
			 * 400 on an edit that was a no-op.
			 */
			$new_content = isset( $data['content'] ) ? $data['content'] : array();

			/** Checking utm is enabled or not */
			if ( is_array( $new_content ) ) {
				$new_content = array_map( function ( $content ) {
					/** if utm is disabled then unset utm parameters */
					if ( empty( $content['utmEnabled'] ) ) {
						unset( $content['utm'] );
					}

					return $content;
				}, $new_content );
			}

			/**
			 * Compared after normalisation, against the value that is about to be stored.
			 *
			 * The utm strip below used to run after this test, so the stored side had `utm`
			 * removed while the incoming side still carried it - the editor posts it back
			 * whatever utmEnabled says. Every save of an unchanged variant with utm disabled
			 * therefore read as a content change, which throws a prepared run away and, on a
			 * broadcast that has started, refuses the save with the 400 below.
			 */
			$content_changing = isset( $data['content'] )
								&& BWFCRM_Campaigns::content_fingerprint( $previous_data['content'] ?? array() ) !== BWFCRM_Campaigns::content_fingerprint( $new_content );

			/**
			 * v2 only. The refusal protects engagements built ahead of the send with the content
			 * baked in; v1 reads the content from the row on every run, so an edit to a running
			 * or paused SMS or WhatsApp broadcast simply applies from the next run, as it always has.
			 */
			if ( $content_changing && ! empty( $previous_data['prepared_for'] )
				 && BWFCRM_Broadcast_Helper::is_v2_broadcast( $campaign[0] )
				 && ! BWFCRM_Campaigns::is_content_editable_status( $campaign[0]['status'] ) ) {
				return array(
					'data'    => array(),
					'status'  => 400,
					'message' => __( 'This broadcast is already sending, so its content can no longer be changed. Pause and duplicate it if you need to send different content.', 'wp-marketing-automations-pro' ),
				);
			}

			$campaign_data['content'] = $new_content;

			$campaign_data['senders_name']  = isset( $data['senders_name'] ) ? $data['senders_name'] : '';
			$campaign_data['senders_email'] = isset( $data['senders_email'] ) ? $data['senders_email'] : '';
			$campaign_data['replyto']       = isset( $data['replyto'] ) ? $data['replyto'] : '';
			$campaign_data['smart_send']    = isset( $data['smart_send'] ) ? $data['smart_send'] : '';

			if ( ! $error ) {
				self::update( array(
					'data'          => $merged_data( array( 'content', 'senders_name', 'senders_email', 'replyto', 'smart_send' ) ),
					'modified_by'   => $current_user_id,
					'last_modified' => current_time( 'mysql', 1 ),
				), array(
					'id' => $campaign_id,
				) );

				/**
				 * Only when the content actually moved, as the sibling door already does.
				 *
				 * This step writes senders_name, senders_email, replyto and smart_send alongside
				 * the content, and none of those is baked into an engagement - format_contact_mail()
				 * reads them off the blob at send. Resetting on them threw a prepared run away
				 * because somebody corrected the reply-to address: every engagement deleted and the
				 * audience rebuilt, which on a large list is not something the remaining lead time
				 * can absorb.
				 */
				if ( $content_changing ) {
					self::reset_prepared_broadcast( $campaign_id );
				}
			}
		}

		if ( 4 == $step ) {
			if ( $finished ) {
				return self::finished_response();
			}

			$schedule_time = isset( $data['schedule_time'] ) ? $data['schedule_time'] : '';

			try {
				$schedule_date = new DateTime( $schedule_time );
				/** No `data` here: this step changes nothing in the blob, and writing the snapshot back only reverted what a worker wrote meanwhile */
				self::update( array(
					'execution_time' => $schedule_date->format( 'Y-m-d H:i:s' ),
					'status'         => 2,
					'modified_by'    => $current_user_id,
					'last_modified'  => date( 'Y-m-d H:i:s', time() - 6 ),
				), array(
					'id' => $campaign_id,
				) );

				/**
				 * Picking a new time is a deliberate re-schedule, so whatever was prepared for the
				 * old one is thrown away and built again nearer the new time - the audience is
				 * snapshotted an hour before the send, and a broadcast moved to next week should
				 * take the list as it stands then, not as it stood when it was first scheduled.
				 *
				 * This is also what makes the marker safe to test by presence: retry delays move
				 * execution_time without going through here, and they leave the preparation alone.
				 * A broadcast that was never prepared has no marker, so this does nothing at all.
				 *
				 * Saving the time it already had is not a re-schedule. The wizard's final step posts this
				 * whatever was edited, with the picker pre-filled from execution_time, so without the
				 * comparison every pass through the wizard tore a prepared broadcast down to rebuild the
				 * same list - on a large audience, with no time left to rebuild it before the send.
				 */
				$stored_time = ! empty( $campaign[0]['execution_time'] ) ? strtotime( $campaign[0]['execution_time'] ) : 0;
				if ( empty( $stored_time ) || $stored_time !== strtotime( $schedule_date->format( 'Y-m-d H:i:s' ) ) ) {
					self::reset_prepared_broadcast( $campaign_id );
				}

				/** Start the campaign if scheduled time is less than or equal to current time (i.e.: on Broadcast Now) */
				if ( strtotime( $schedule_time ) <= time() ) {
					$campaign_data = self::get( absint( $campaign_id ) );
					if ( ! is_array( $campaign_data ) || empty( $campaign_data ) ) {
						$error   = true;
						$message = __( 'Broadcast not found', 'wp-marketing-automations-pro' );
					} else {
						BWFCRM_Core()->campaigns->process_single_scheduled_broadcasts( $campaign_data );
						BWFCRM_Common::reschedule_broadcast_action();
					}
				} else {
					BWFAN_PRO_Common::validate_scheduled_recurring_actions();
				}
			} catch ( Exception $e ) {
				$error   = true;
				$message = $e->getMessage();
			}

		}

		if ( ! $error ) {
			$res_data = self::get_formatted_campaign_data( self::get_specific_rows( 'id', $campaign_id ) )[0];
			$status   = 200;
			$message  = __( 'Broadcast updated', 'wp-marketing-automations-pro' );
		}

		return array(
			'data'    => $res_data,
			'status'  => $status,
			'message' => $message,
		);
	}

	/**
	 * Clone campaign
	 *
	 * @param int $campaign_id campaign id.
	 * @param int $created_by user id.
	 *
	 * @return array
	 */
	public static function clone_campaign( $campaign_id, $created_by, $send_to_unopen = false ) {
		$status         = 404;
		$data           = array();
		$message        = __( 'Broadcast details missing.', 'wp-marketing-automations-pro' );
		$campaign       = self::get_specific_rows( 'id', $campaign_id );
		$broadcast_data = method_exists( 'BWFAN_Model_Broadcast', 'get_data_by_id' ) ? BWFAN_Model_Broadcast::get_data_by_id( $campaign_id ) : [];

		if ( ! empty( $campaign ) ) {
			$campaign      = $campaign[0];
			$clone_title   = true === $send_to_unopen ? $campaign['title'] . ' ' . __( '(Unopen Broadcast)', 'wp-marketing-automations-pro' ) : $campaign['title'] . ' ' . __( '(Copy)', 'wp-marketing-automations-pro' );
			$campaign_data = ! empty( $campaign['data'] ) ? json_decode( $campaign['data'], true ) : array();
			if ( is_array( $campaign_data ) ) {
				unset( $campaign_data['halt_reason'] );
				unset( $campaign_data['winner'] );
				unset( $campaign_data['hold_broadcast'] );
				unset( $campaign_data['smart_sending_done'] );
				/**
				 * includeSoftBounce and includeUnverified both ride along untouched: a duplicate,
				 * and a resend of the contacts who did not open, mail the audience their source
				 * did. Dropping either quietly narrowed the copy against the broadcast it came
				 * from - and on the resend path the same two keys are what the send gate reads,
				 * so the walk and the gate have to be given the same answer.
				 */
				unset( $campaign_data['engagements_created'] );
				unset( $campaign_data['offset'] );
				unset( $campaign_data['processed'] );
				unset( $campaign_data['prepared_for'], $campaign_data['prep_id'] );
				unset( $campaign_data['v2'] );

				/**
				 * The top up window belongs to the run that was cloned, not to the clone. Carried
				 * over, topup_done would close the clone's window before it ever opened and
				 * topup_offset would start its cursor above a contact id from another broadcast's
				 * audience.
				 */
				unset( $campaign_data['topup_done'] );
				unset( $campaign_data['topup_offset'] );
				unset( $campaign_data['consecutive_failures'], $campaign_data['render_failures'] );
				if ( isset( $campaign_data['smart_send_stat'] ) ) {
					unset( $campaign_data['smart_send_stat'] );
				}
				if ( isset( $campaign_data['failed_cids'] ) ) {
					unset( $campaign_data['failed_cids'] );
				}
				if ( isset( $campaign_data['failed_reason'] ) ) {
					unset( $campaign_data['failed_reason'] );
				}
				if ( isset( $campaign_data['content'] ) ) {
					$content = $campaign_data['content'];
					foreach ( $content as $key => $value ) {
						if ( isset( $value['utm'] ) && isset( $value['utm']['name'] ) ) {
							$campaign_data['content'][ intval( $key ) ]['utm']['name'] = $clone_title;
						}
					}
				}
			}

			if ( true === $send_to_unopen ) {
				$campaign_data['parent'] = absint( $campaign_id );
			}

			if ( empty( $broadcast_data ) ) {
				$broadcast_data = [];
			}

			$existing_category = isset( $broadcast_data[ $campaign_id ]['category'] ) ? json_decode( $broadcast_data[ $campaign_id ]['category'], true ) : [];
			if ( ! empty( $existing_category ) ) {
				BWFCRM_Category::update_term_counts( array_fill_keys( $existing_category, 1 ), $existing_category, BWFCRM_Category::$BROADCAST );
			}

			$db_arr = array(
				'title'         => $clone_title,
				'description'   => $campaign['description'],
				'created_by'    => $created_by,
				'type'          => $campaign['type'],
				'parent'        => $campaign['parent'],
				'count'         => 0,
				'modified_by'   => $created_by,
				'data'          => wp_json_encode( $campaign_data ),
				'created_at'    => current_time( 'mysql', 1 ),
				'last_modified' => current_time( 'mysql', 1 ),
				'category'      => $campaign['category'],
			);

			self::insert( $db_arr );
			$campaign_id = self::insert_id();

			if ( $campaign_id ) {
				$campaign = self::get_specific_rows( 'id', $campaign_id );
				$data     = self::get_formatted_campaign_data( $campaign )[0];
				$status   = 200;
				$message  = __( 'Broadcast cloned', 'wp-marketing-automations-pro' );
				if ( true === $send_to_unopen ) {
					$message = __( 'Broadcast created', 'wp-marketing-automations-pro' );
				}
			}

		}

		return array(
			'data'    => $data,
			'status'  => $status,
			'message' => $message,
		);
	}

	/**
	 * Returns formatted data
	 *
	 * @param array $data campaign data.
	 *
	 * @return array
	 */
	public static function get_formatted_campaign_data( $data ) {
		if ( empty( $data ) ) {
			return [];
		}
		$final_data = array();
		foreach ( $data as $campaign ) {
			$category_ids = ! empty( $campaign['category'] ) && BWFAN_Common::is_json( $campaign['category'] ) ? json_decode( $campaign['category'], true ) : [];

			$campaign_data = BWFAN_PRO_Common::decode_stored_data_column( $campaign['data'] ?? null );
			if ( is_array( $campaign_data ) ) {
				if ( ! empty( $campaign_data['filters'] ) ) {
					$campaign_data['filters'] = BWFAN_PRO_Common::prepare_stored_filters_for_admin( $campaign_data['filters'] );
				}
				$campaign['data'] = $campaign_data;
			}

			/** Setting default values 0 if not found */
			$campaign['click_count'] = ( isset( $campaign['click_count'] ) && absint( $campaign['click_count'] ) > 0 ) ? $campaign['click_count'] : 0;
			$campaign['click_rate']  = ( isset( $campaign['click_rate'] ) && floatval( $campaign['click_rate'] ) > 0 ) ? number_format( $campaign['click_rate'], 2 ) : 0;
			$campaign['open_count']  = ( isset( $campaign['open_count'] ) && absint( $campaign['open_count'] ) > 0 ) ? $campaign['open_count'] : 0;
			$campaign['open_rate']   = ( isset( $campaign['open_rate'] ) && floatval( $campaign['open_rate'] ) > 0 ) ? number_format( $campaign['open_rate'], 2 ) : 0;
			$campaign['revenue']     = ( isset( $campaign['revenue'] ) && floatval( $campaign['revenue'] ) > 0 ) ? $campaign['revenue'] : 0;
			$campaign['conversions'] = ( isset( $campaign['conversions'] ) && absint( $campaign['conversions'] ) > 0 ) ? $campaign['conversions'] : 0;
			$campaign['sent']        = ( isset( $campaign['sent'] ) && absint( $campaign['sent'] ) > 0 ) ? $campaign['sent'] : 0;
			$campaign['subject']     = isset( $campaign['tid'] ) && ! empty( $campaign['tid'] ) ? self::get_template_subject( $campaign['tid'] ) : '';
			$campaign['parent']      = isset( $campaign['parent'] ) && absint( $campaign['parent'] ) > 0 ? absint( $campaign['parent'] ) : 0;
			$campaign['unsubs']      = isset( $campaign['id'] ) ? self::get_campaign_unsubscribers( absint( $campaign['id'] ) ) : 0;
			$campaign['created_at']  = isset( $campaign['created_at'] ) ? get_date_from_gmt( $campaign['created_at'] ) : '';
			$campaign['category']    = method_exists( 'BWFCRM_Category', 'get_category_by_id' ) ? BWFCRM_Category::get_category_by_id( BWFCRM_Category::$BROADCAST, $category_ids ) : [];
			$final_data[]            = $campaign;
		}

		return $final_data;
	}

	public static function get_template_subject( $tid ) {
		$template = BWFAN_Model_Templates::get( absint( $tid ) );
		if ( empty( $template ) || ! is_array( $template ) || ! isset( $template['subject'] ) ) {
			return '';
		}

		return $template['subject'];
	}

	public static function get_broadcasts_by_status( $status = 1, $check_execution_time = false, $v2 = false ) {
		global $wpdb;
		$table_name = self::_table();

		/** Wildcards stay outside esc_like() so only the literal part is escaped */
		$v2_like = '%' . $wpdb->esc_like( '"v2":1' ) . '%';

		/**
		 * Fetch the v2 and the non-v2 broadcasts due for processing in one query.
		 *
		 * v2 broadcasts are picked an hour early so their engagements can be created ahead of
		 * the execution time, and while still scheduled (2) as well as running (3). Non-v2 ones
		 * are only picked once they are running (3) and actually due, which is what the old
		 * `get_broadcasts_by_status( $CAMPAIGN_RUNNING, true )` call used to return.
		 *
		 * Both sets come back ordered by execution time so the earliest scheduled broadcast is
		 * processed first regardless of which flow it belongs to.
		 */
		if ( true === $v2 ) {
			$query = $wpdb->prepare( "SELECT * FROM $table_name
				WHERE ( `status` IN ( %d, %d ) AND `execution_time` <= %s AND `data` LIKE %s )
				   OR ( `status` = %d AND `execution_time` <= %s AND `data` NOT LIKE %s )
				ORDER BY `execution_time` ASC",
				BWFCRM_Campaigns::$CAMPAIGN_SCHEDULED,
				BWFCRM_Broadcast_Processing::$CAMPAIGN_RUNNING,
				gmdate( 'Y-m-d H:i:s', time() + HOUR_IN_SECONDS ),
				$v2_like,
				BWFCRM_Broadcast_Processing::$CAMPAIGN_RUNNING,
				current_time( 'mysql', 1 ),
				$v2_like
			);

			$broadcasts = $wpdb->get_results( $query, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL

			return self::get_formatted_campaign_data( $broadcasts );
		}

		$query      = "SELECT * FROM $table_name WHERE `status` = %s";
		$query_args = array( $status );

		if ( $check_execution_time ) {
			$query        .= ' AND `execution_time` <= %s';
			$query_args[] = current_time( 'mysql', 1 );
		}

		/**
		 * v2 broadcasts are dispatched by the branch above, so an old-signature call must not
		 * pick them up and hand them to the legacy sender as well.
		 *
		 * The NULL arm is not decoration: `NULL NOT LIKE '...'` evaluates to NULL, which fails
		 * the WHERE, so a bare NOT LIKE silently drops every broadcast whose data column has
		 * never been written - none of which are v2.
		 */
		$query        .= " AND ( `data` IS NULL OR `data` NOT LIKE %s )";
		$query_args[] = $v2_like;

		/** Fetch running broadcasts order by execution time ascending */
		if ( BWFCRM_Broadcast_Processing::$CAMPAIGN_RUNNING === intval( $status ) ) {
			$query .= " ORDER BY `execution_time` ASC";
		}

		$query      = $wpdb->prepare( $query, $query_args );
		$broadcasts = $wpdb->get_results( $query, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL

		return self::get_formatted_campaign_data( $broadcasts );
	}

	/**
	 * Scheduled broadcasts that are ready to be set up
	 *
	 * Email is picked up an hour before its execution time because the v2 flow has to create the
	 * engagements before the send starts. SMS and WhatsApp stay on the v1 flow, which does all of
	 * its work at send time, so they are picked up only once they are actually due - exactly as
	 * before. Pulling them in early would buy nothing and freeze their audience an hour ahead of
	 * schedule, since this pass is what snapshots `count` and the last contact id.
	 *
	 * @return array
	 */
	public static function get_scheduled_broadcasts_to_run() {
		global $wpdb;
		$table_name = self::_table();

		$query = $wpdb->prepare( "SELECT * FROM $table_name
			WHERE `status` = %d
			  AND ( ( `type` = %d AND `execution_time` <= %s ) OR ( `type` <> %d AND `execution_time` <= %s ) )
			ORDER BY `execution_time` ASC",
			BWFCRM_Campaigns::$CAMPAIGN_SCHEDULED,
			BWFCRM_Campaigns::$CAMPAIGN_EMAIL,
			gmdate( 'Y-m-d H:i:s', time() + HOUR_IN_SECONDS ),
			BWFCRM_Campaigns::$CAMPAIGN_EMAIL,
			current_time( 'mysql', 1 )
		);

		$campaigns = $wpdb->get_results( $query, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL

		return self::get_formatted_campaign_data( $campaigns );
	}

	public static function update_status_to_run( $broadcast, $offset, $campaign_data, $contact_count ) {
		/**
		 * The row, or just its id.
		 *
		 * This took a bare id before the v2 split and still has to: the arity did not change, so an
		 * integer from an older caller would have gone into $broadcast['id'] and come back out of
		 * absint() as 0 - a write against broadcast 0, silently doing nothing. Only the id is read
		 * here in any case; the blob comes from a fresh read below.
		 */
		$campaign_id = is_array( $broadcast ) ? absint( $broadcast['id'] ?? 0 ) : absint( $broadcast );

		/**
		 * Only the keys preparation produces go into the blob, merged over a fresh read.
		 *
		 * $campaign_data is the row as the dispatcher fetched it at the start of its pass, and
		 * between that fetch and this write sit the audience count - seconds on a large segment -
		 * and the template upsert. An admin save inside that window (content, senders, smart send,
		 * filters) was overwritten by the stale copy, and because this write also carried
		 * `prepared_for`, the save's own reset_prepared_broadcast() was undone with it: the
		 * broadcast read as prepared, against the content the admin had just replaced, and no
		 * pass ever prepared it again. Everything other than these keys belongs to the
		 * editor or to the run, and preparation has no business restating it.
		 *
		 * `content` is included because the template upsert writes the template ids into it.
		 */
		$prep_data = array();
		foreach ( array( 'content', 'v2', 'engagements_created', 'prepared_for', 'prep_id' ) as $key ) {
			if ( is_array( $campaign_data ) && array_key_exists( $key, $campaign_data ) ) {
				$prep_data[ $key ] = $campaign_data[ $key ];
			}
		}

		$stored = self::get( $campaign_id );
		$b_data = ! empty( $stored['data'] ) ? json_decode( $stored['data'], true ) : array();
		if ( ! is_array( $b_data ) ) {
			/** Row unreadable or blob corrupt: the caller's copy is the best available fallback */
			$b_data = is_array( $campaign_data ) ? $campaign_data : array();
		}

		/**
		 * The content this pass prepared has to still be the content the row holds.
		 *
		 * $prep_data['content'] was read at the start of the pass; between that read and this write
		 * sit the audience count and the template upsert, seconds on a large segment. A content save
		 * landing in that window was overwritten here - and its own reset_prepared_broadcast() had
		 * been a no-op, since no marker existed yet - so the engagements were built from the body
		 * the admin had just replaced, and nothing ever prepared the broadcast again. On a mismatch
		 * nothing is written: the next pass reads the new content and prepares that.
		 */
		if ( isset( $prep_data['content'], $b_data['content'] ) && self::content_without_template_ids( $b_data['content'] ) !== self::content_without_template_ids( $prep_data['content'] ) ) {
			if ( class_exists( 'BWFCRM_Broadcast_Helper' ) ) {
				BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $campaign_id . ' content changed while it was being prepared, leaving it for the next pass' );
			}

			return;
		}
		$b_data = array_replace( $b_data, $prep_data );

		$updated_data = array(
			'offset'        => $offset,
			'data'          => json_encode( $b_data ),
			'count'         => absint( $contact_count ),
			'last_modified' => date( 'Y-m-d H:i:s', time() - 6 ),

			/**
			 * Preparation snapshots the audience, so the creation cursor starts from the top with
			 * it. Every path that re-prepares a broadcast already zeroes these, but leaving them to
			 * the caller is what let a re-prepared broadcast resume creation from a cursor left by
			 * the run it was replacing - walking straight past every contact above it. Recreating
			 * an engagement that already exists is not a risk here: creation checks the batch
			 * against the engagement table before it writes anything.
			 */
			'e_offset'      => 0,
			'e_processed'   => 0,
		);

		/**
		 * From the caller's row when it passed one, otherwise off the read above.
		 *
		 * An id-only caller has no execution_time to offer, and strtotime( null ) is false, which
		 * every timestamp is greater than - so the broadcast would be promoted to running whatever
		 * its schedule said.
		 */
		$execution_time = ( is_array( $broadcast ) && ! empty( $broadcast['execution_time'] ) ) ? $broadcast['execution_time'] : ( $stored['execution_time'] ?? '' );

		/** If current time is greater than execution time then update status to running status */
		if ( ! empty( $execution_time ) && time() >= strtotime( $execution_time ) ) {
			$updated_data['status'] = BWFCRM_Campaigns::$CAMPAIGN_RUNNING;
		}
		self::update( $updated_data, array(
			'id' => absint( $campaign_id ),
		) );
	}

	/**
	 * Fingerprint of a content array with the template ids left out
	 *
	 * The template upsert is the one thing preparation adds to the content, so two copies that
	 * differ only there are the same content.
	 *
	 * @param mixed $content
	 *
	 * @return string
	 */
	private static function content_without_template_ids( $content ) {
		if ( is_array( $content ) ) {
			foreach ( $content as $i => $variant ) {
				if ( is_array( $variant ) ) {
					unset( $content[ $i ]['template_id'] );
				}
			}
			/** The template upsert rebuilds the list from 0, so a stored copy with a gap in its keys is still the same content */
			$content = array_values( $content );
		}

		return BWFCRM_Campaigns::content_fingerprint( $content );
	}

	/**
	 * Halt a broadcast, without overwriting what another worker wrote meanwhile
	 *
	 * Every caller hands over the whole data blob it read when its run started, having added one
	 * key to it. Writing that back wholesale drops everything a sibling worker has set since - a
	 * smart send winner, an accumulated failure list - and writes the run's stale values over the
	 * current ones. Only `halt_reason` is taken from it, and only once the status change has
	 * actually taken, so a halt this method refused cannot touch the row at all.
	 *
	 * @param int $campaign_id
	 * @param array $campaign_data The caller's blob; only `halt_reason` is read from it
	 *
	 * @return void
	 */
	public static function update_status_to_halt( $campaign_id, $campaign_data ) {
		global $wpdb;

		$campaign_id = absint( $campaign_id );

		$wpdb->query( $wpdb->prepare( "UPDATE " . self::_table() . "
			SET `status` = %d, `last_modified` = %s
			WHERE `id` = %d AND `status` IN ( %d, %d )",
			BWFCRM_Campaigns::$CAMPAIGN_HALT,
			current_time( 'mysql', 1 ),
			$campaign_id,
			BWFCRM_Campaigns::$CAMPAIGN_RUNNING,
			BWFCRM_Campaigns::$CAMPAIGN_SCHEDULED
		) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		/**
		 * Nothing is written unless the status actually moved. On a broadcast the guard above just
		 * refused - one an admin cancelled or completed while this worker was mid-batch - a reason
		 * written anyway would describe a halt that never happened.
		 */
		if ( empty( $wpdb->rows_affected ) ) {
			return;
		}

		/**
		 * The reason alone, not the caller's whole blob.
		 *
		 * Taking the blob would merge a snapshot read minutes ago over keys a sibling worker has
		 * moved since - the top up cursor, the smart send winner - for no gain, since the reason
		 * is the only key any caller of this method changes.
		 */
		$halt_reason = is_array( $campaign_data ) && isset( $campaign_data['halt_reason'] ) ? $campaign_data['halt_reason'] : '';

		if ( '' !== $halt_reason ) {
			self::update_broadcast_data( $campaign_id, array( 'halt_reason' => $halt_reason ) );
		}
	}

	/**
	 * Drop the keys a finished broadcast has no further use for
	 *
	 * The data blob doubles as the run's scratch pad - where the preparation had got to, which
	 * contacts failed, whether the smart send window was open - and once the broadcast is complete
	 * none of it is read again. `failed_cids` is the reason this is worth doing rather than merely
	 * tidy: it holds one integer per failed contact and is never trimmed, so a bad send can leave
	 * tens of thousands of them in a column that is read in full every time the broadcast is
	 * loaded, listed or reported on.
	 *
	 * What describes the broadcast rather than the run stays: the audience (`filters`, `exclude`,
	 * `is_promotional`, `includeSoftBounce`, `includeUnverified`), the templates (`content`), the
	 * smart send settings with the `winner` and `smart_send_stat` the report renders, and `v2`,
	 * which records which flow sent it. `failed_reason` stays too - it is a handful of strings and
	 * the only surviving trace of what the mail provider objected to.
	 *
	 * @param array $data Stored broadcast data
	 *
	 * @return array
	 */
	private static function strip_completed_run_data( $data ) {
		if ( ! is_array( $data ) || empty( $data ) ) {
			return array();
		}

		$run_keys = array(
			'prepared_for',
			'prep_id',
			'topup_offset',
			'topup_done',
			'offset',
			'processed',
			'hold_broadcast',
			/** Legacy: the smart send window is execution_time now, but old blobs still carry this */
			'hold_until',
			'failed_cids',
			'halt_reason',
			'consecutive_failures',
			'render_failures',
		);

		foreach ( $run_keys as $key ) {
			unset( $data[ $key ] );
		}

		return $data;
	}
	

	/**
	 * Mark a broadcast finished
	 *
	 * @param int $campaign_id
	 * @param array $campaign_data Caller's copy of the data blob, used only if the row cannot be read
	 * @param int $processed
	 * @param int $count
	 *
	 * @return void
	 */
	public static function update_status_to_complete( $campaign_id, $campaign_data, $processed, $count ) {
		global $wpdb;

		$campaign_id = absint( $campaign_id );

		/**
		 * The blob is read back here rather than taken from the caller.
		 *
		 * A v2 pipeline picks its copy up when the send loop starts and can hold it for the whole
		 * call, while another pipeline on the same broadcast writes a winner or a failure list in
		 * the meantime - writing the stale copy back at the end would drop that. The stored one
		 * therefore wins, and the caller's copy is only a fallback for a row that cannot be read.
		 */
		$broadcast = self::get( $campaign_id );
		$data      = ! empty( $broadcast['data'] ) ? json_decode( $broadcast['data'], true ) : array();
		if ( ! is_array( $data ) || empty( $data ) ) {
			$data = is_array( $campaign_data ) ? $campaign_data : array();
		}

		$data = self::strip_completed_run_data( $data );

		/**
		 * Guarded on the status a sending broadcast can actually hold, so a pipeline that finishes
		 * its last batch after an admin paused or cancelled the broadcast cannot flip it back.
		 * Scheduled is in the list because a v2 broadcast starts sending on the tick its execution
		 * time arrives, which can be the tick before the scheduler moves it to running.
		 */
		/**
		 * `count` is raised in SQL, never overwritten. The caller's $count is a snapshot from
		 * when its send loop started; a sibling pipeline's top-up can have raised the stored
		 * value since, and writing the snapshot back would shrink the audience the report shows.
		 */
		$wpdb->query( $wpdb->prepare( "UPDATE " . self::_table() . "
			SET `data` = %s, `status` = %d, `count` = GREATEST( `count`, %d ), `last_modified` = %s
			WHERE `id` = %d AND `status` IN ( %d, %d )",
			wp_json_encode( $data ),
			BWFCRM_Campaigns::$CAMPAIGN_COMPLETED,
			max( absint( $processed ), absint( $count ) ),
			current_time( 'mysql', 1 ),
			$campaign_id,
			BWFCRM_Broadcast_Processing::$CAMPAIGN_RUNNING,
			BWFCRM_Campaigns::$CAMPAIGN_SCHEDULED
		) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * Move a campaign's send progress forward
	 *
	 * `processed` is incremented in SQL rather than overwritten, and `offset` only ever moves
	 * down. Several pipelines can be sending the same broadcast at once and each holds its own
	 * snapshot of these counters, so writing absolutes would let one pipeline's value erase the
	 * other's - two pipelines starting at 100 and sending 15 each would both write 115 instead
	 * of 130, which also feeds the smart-send percentage.
	 *
	 * Contacts are walked descending, so the offset is the lowest contact id reached so far.
	 *
	 * @param int $campaign_id
	 * @param int $offset Lowest contact id this batch reached
	 * @param int $processed_delta How many contacts this batch processed
	 *
	 * @return void
	 */
	public static function increment_campaign_offsets( $campaign_id, $offset, $processed_delta = 1 ) {
		global $wpdb;
		$table_name = self::_table();

		$wpdb->query( $wpdb->prepare( "UPDATE {$table_name}
			SET `offset` = IF( `offset` = 0, %d, LEAST( `offset`, %d ) ),
				`processed` = `processed` + %d,
				`last_modified` = %s
			WHERE `id` = %d",
			absint( $offset ),
			absint( $offset ),
			absint( $processed_delta ),
			current_time( 'mysql', 1 ),
			absint( $campaign_id )
		) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * Deprecated. Use increment_campaign_offsets() instead.
	 *
	 * The third argument here is an absolute processed count, which is what this method has always
	 * meant and what any caller outside this plugin still passes. increment_campaign_offsets() took
	 * over the name's old body with the third argument reinterpreted as a delta, so leaving that
	 * rename in place would have turned every such call into a runaway counter - same arity, same
	 * types, no error. This keeps the original behaviour under the original name.
	 *
	 * @param int $campaign_id
	 * @param int $offset
	 * @param int $processed Absolute number of contacts processed so far
	 *
	 * @return void
	 */
	public static function update_campaign_offsets( $campaign_id, $offset, $processed ) {
		self::update( array(
			'offset'        => absint( $offset ),
			'processed'     => absint( $processed ),
			'last_modified' => current_time( 'mysql', 1 ),
		), array(
			'id' => absint( $campaign_id ),
		) );
	}

	/**
	 * Add what a top up batch produced to the campaign's totals
	 *
	 * Incremented in SQL for the same reason increment_campaign_offsets() is: `count` and
	 * `e_processed` are read into each worker's own snapshot, and several workers can be on the
	 * same broadcast, so writing the absolute totals one of them happens to hold would erase what
	 * the others added. `count` in particular is what every screen reports against.
	 *
	 * @param int $campaign_id
	 * @param int $created How many engagements this batch created
	 *
	 * @return void
	 */
	public static function increment_topup_counters( $campaign_id, $created ) {
		global $wpdb;

		$created = absint( $created );
		if ( empty( $created ) ) {
			return;
		}

		$wpdb->query( $wpdb->prepare( "UPDATE " . self::_table() . "
			SET `count` = `count` + %d,
				`e_processed` = `e_processed` + %d,
				`last_modified` = %s
			WHERE `id` = %d",
			$created,
			$created,
			current_time( 'mysql', 1 ),
			absint( $campaign_id )
		) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * Pause a broadcast that is sending
	 *
	 * Guarded on the statuses a sending broadcast can hold, which is the same pair
	 * update_status_to_complete() accepts and for the same reason: a v2 broadcast begins sending
	 * on the tick its execution time arrives, which can be the tick before the dispatcher moves it
	 * to running. Accepting only running meant the failure gate could not pause it on exactly that
	 * tick - and with the failure count now persisted it would burn one mail per tick instead.
	 *
	 * The guard is what stops a worker finishing its last batch from flipping a broadcast an admin
	 * has just cancelled, completed or unscheduled back to paused.
	 *
	 * @param int $campaign_id
	 *
	 * @return bool
	 */
	public static function update_status_to_pause( $campaign_id ) {
		global $wpdb;

		$rows = $wpdb->query( $wpdb->prepare( "UPDATE " . self::_table() . "
			SET `status` = %d, `last_modified` = %s
			WHERE `id` = %d AND `status` IN ( %d, %d )",
			BWFCRM_Campaigns::$CAMPAIGN_PAUSED,
			current_time( 'mysql', 1 ),
			absint( $campaign_id ),
			BWFCRM_Campaigns::$CAMPAIGN_RUNNING,
			BWFCRM_Campaigns::$CAMPAIGN_SCHEDULED
		) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return ! empty( $rows );
	}

	/**
	 * Update status to ongoing
	 *
	 * @param $broadcast_id
	 *
	 * @return bool
	 */
	public static function update_status_to_ongoing( $broadcast_id ) {
		$broadcast = self::get( intval( $broadcast_id ) );

		/**
		 * Nothing below is safe to run on a broadcast that is not actually paused.
		 *
		 * The row update at the end is guarded on PAUSED and simply matches nothing otherwise,
		 * but reopen_failed_engagements() is not - and the endpoint behind this accepts any
		 * campaign id, so a double-clicked Resume, or one clicked on a broadcast that completed
		 * between the page rendering and the click, used to flip every errored engagement of the
		 * broadcast back to draft. That destroys the record of why each of them failed, including
		 * the reasons get_unsendable_reason() wrote deliberately, and on a completed broadcast
		 * those rows then sit in draft for good.
		 */
		if ( ! is_array( $broadcast ) || empty( $broadcast ) || BWFCRM_Campaigns::$CAMPAIGN_PAUSED !== absint( $broadcast['status'] ) ) {
			return false;
		}

		$b_data = ! empty( $broadcast['data'] ) ? json_decode( $broadcast['data'], true ) : array();
		$b_data = is_array( $b_data ) ? $b_data : array();

		/**
		 * Back to the status the broadcast held before the pause, not always to running.
		 *
		 * A v2 broadcast can be paused while it is still preparing, an hour ahead of its
		 * execution time. Promoting it to running then showed "Running" on a broadcast that had
		 * not started and put a row the rest of the code never expects - running with a future
		 * execution time - on the table. Scheduled is what the dispatcher would have left it at,
		 * and maybe_start_due_broadcast() moves it to running at the due time as for any other
		 * prepared row.
		 *
		 * Only that case. A future execution time alone is not proof the broadcast has not
		 * started: a smart send parks a running broadcast at execution_time + hours with the test
		 * batch already delivered, and one paused in that window must come back as running or the
		 * report loses its "waiting for the winner" notice until the window ends. Hence the hold
		 * flag and the sent count are checked as well. A broadcast paused mid-send has its
		 * execution time in the past and goes back to running as before.
		 */
		$not_started   = ! empty( $broadcast['execution_time'] ) && strtotime( $broadcast['execution_time'] ) > time()
						 && empty( $b_data['hold_broadcast'] ) && 0 === absint( $broadcast['processed'] ?? 0 );

		/**
		 * Never back to running without a preparation to run.
		 *
		 * update_status_to_pause() accepts a scheduled row, so a broadcast can be paused before the
		 * dispatcher ever prepared it - no `prepared_for` on email, `count` still 0 on SMS and
		 * WhatsApp. Once its execution time had passed, the clock alone said running, and a running
		 * row nothing prepared either spun the v1 loop on an empty offset every tick, or - carrying
		 * a `v2` flag copied from the broadcast it was duplicated from - walked the v2 send loop
		 * straight to complete having mailed nobody. Scheduled instead: the next scheduled pass
		 * prepares it and update_status_to_run() promotes it, since it is due. `count` alone is not
		 * the test for email, a duplicate copies its parent's count.
		 */
		/**
		 * An email row with mails already sent and no marker is a v1 run paused before this
		 * build - the marker did not exist then. That run is resumed as it was, on the v1 path,
		 * rather than sent back to scheduled to be rebuilt as v2 under a half-sent report.
		 */
		$unprepared = BWFCRM_Campaigns::$CAMPAIGN_EMAIL === absint( $broadcast['type'] ?? 0 )
			? ( empty( $b_data['prepared_for'] ) && 0 === absint( $broadcast['processed'] ?? 0 ) )
			: absint( $broadcast['count'] ?? 0 ) < 1;

		$resume_status = ( $not_started || $unprepared ) ? BWFCRM_Campaigns::$CAMPAIGN_SCHEDULED : BWFCRM_Campaigns::$CAMPAIGN_RUNNING;

		$updated_columns = array(
			'status' => $resume_status,
		);

		$is_v2 = BWFCRM_Broadcast_Helper::is_v2_broadcast( $broadcast );

		/**
		 * The run of failures that tripped the pause is over, so the count of it goes with the
		 * pause. Cleared unconditionally: the counter survives across runs precisely so a slow
		 * failing provider still reaches the limit, which also means resuming without clearing it
		 * would pause the broadcast again on the first failure after the resume. The build-failure
		 * counter is cleared for the same reason.
		 */
		$data_changed = false;
		foreach ( array( 'consecutive_failures', 'render_failures' ) as $counter ) {
			if ( isset( $b_data[ $counter ] ) ) {
				unset( $b_data[ $counter ] );
				$data_changed = true;
			}
		}

		/** Cleared for both flows - the pause that wrote them is over either way */
		$failed_cids = array();
		if ( ! empty( $b_data['failed_cids'] ) ) {
			$failed_cids = array_values( array_filter( array_map( 'absint', (array) $b_data['failed_cids'] ) ) );
			unset( $b_data['failed_cids'], $b_data['failed_reason'] );
			$data_changed = true;
		}

		if ( $data_changed ) {
			$updated_columns['data'] = json_encode( $b_data );
		}

		/**
		 * v2 keeps the record of what failed on the engagement rows themselves, so a resume re-opens
		 * every errored engagement of the broadcast instead of the contact ids that happened to be
		 * in the data blob.
		 *
		 * That list only ever holds the failures of the run that tripped the pause: a send that
		 * failed earlier and was followed by a success is never written there, so going by the blob
		 * would leave those contacts failed for good. Reading the rows also costs one statement no
		 * matter how many failures there were, instead of growing the blob with every one of them.
		 */
		if ( $is_v2 ) {
			/**
			 * One statement: the status and the cleaned blob move together.
			 *
			 * Both have to be written before the reopen walk, because that walk carries a time
			 * budget and can legitimately stop early - flipping the status after it would leave a
			 * short walk's rows sitting in draft on a broadcast the dispatcher no longer fetches,
			 * since paused is not among the statuses it selects, and nothing would ever send them.
			 *
			 * Writing the blob afterwards instead is what has to be avoided: the broadcast is live
			 * for the whole walk, so a worker can set topup_offset, engagements_created or the
			 * smart send winner in that window, and a `data` write built from the snapshot read at
			 * the top of this method would erase every one of them. Folding it into the promoting
			 * UPDATE closes the window entirely.
			 *
			 * `processed` is decremented inside the walk, per chunk, for the same early-stop reason.
			 */
			$promoted = self::update( $updated_columns, array(
				'id'     => intval( $broadcast_id ),
				'status' => BWFCRM_Campaigns::$CAMPAIGN_PAUSED,
			) );

			if ( empty( $promoted ) ) {
				/** Somebody else moved it between the read above and here */
				return false;
			}

			self::reopen_failed_engagements( $broadcast_id );

			return true;
		}

		/** Delete failed engagements if failed contact ids found in data */
		if ( ! empty( $failed_cids ) ) {
			/**
			 * v1 walks the contacts itself, so it has to be pointed back above the highest failed
			 * one - contacts are walked descending and the fetch excludes the offset itself. Read
			 * with max() rather than off index 0, since a list that survived a json round trip is
			 * not guaranteed to still start with its highest id, and a missing index 0 would put
			 * the offset back to 0 and re-send the broadcast from the top.
			 *
			 * v2 claims its work from the engagement table, so its offset is only a progress
			 * marker - the re-opened rows are what it picks up, and moving the offset would mean
			 * nothing to it.
			 */
			$updated_columns['offset']    = max( $failed_cids ) + 1;
			$updated_columns['processed'] = max( 0, intval( $broadcast['processed'] ) - count( $failed_cids ) );

			/** Still paused at this point, so no worker can be rebuilding what this deletes */
			self::delete_failed_engagements( $broadcast_id, $failed_cids, $broadcast );
		}

		$rows = self::update( $updated_columns, array(
			'id'     => intval( $broadcast_id ),
			'status' => BWFCRM_Campaigns::$CAMPAIGN_PAUSED,
		) );

		return ! empty( $rows );
	}

	/**
	 * Put a v2 broadcast's failed engagements back in the send queue
	 *
	 * Only the ones worth trying again. An errored engagement is not necessarily a failed send:
	 * the send loop writes the same status for contacts it deliberately refused - deleted since
	 * the broadcast was prepared, unsubscribed, hard bounced, no address on record - and for mails
	 * it could not build at all. Sweeping those back into draft alongside the provider failures
	 * re-claims them, re-checks them and fails them again identically, adding another error_msg
	 * row to the meta table on every cycle, and drops `processed` by their count on the report
	 * because the caller subtracts whatever this returns.
	 *
	 * Which of the two a row is gets decided by asking the same question the send asks -
	 * get_unsendable_reason(), against the contact as it stands right now - rather than by
	 * recording a verdict when it failed. That keeps one source of truth for what "unsendable"
	 * means, which matters because the audience rules have already drifted apart once between the
	 * query and the send. It is also the more accurate answer: a contact who has re-subscribed or
	 * had a bad address corrected since the failure is mailable again, and a stored verdict would
	 * have written them off for good.
	 *
	 * Read in chunks, because a large broadcast can hold tens of thousands of errored rows. Resume
	 * is an admin action taken once, so a handful of extra queries costs nothing.
	 *
	 * @param int $broadcast_id
	 *
	 * @return int How many engagements were re-opened
	 */
	public static function reopen_failed_engagements( $broadcast_id ) {
		global $wpdb;

		$broadcast_id = absint( $broadcast_id );
		$broadcast    = self::get( $broadcast_id );
		$data         = ! empty( $broadcast['data'] ) ? json_decode( $broadcast['data'], true ) : array();
		$data         = is_array( $data ) ? $data : array();

		$table    = $wpdb->prefix . 'bwfan_engagement_tracking';
		$cursor   = 0;
		$reopened = 0;
		$started  = microtime( true );
		$budget   = (float) apply_filters( 'bwfan_broadcast_reopen_time_budget', 15 );

		do {
			/**
			 * Checked at the top, so every path through the loop is bounded.
			 *
			 * This is a synchronous REST request, and a broadcast holding hundreds of thousands of
			 * errored rows would otherwise run thousands of queries in one call and hit
			 * max_execution_time or a gateway timeout. At the foot of the loop the chunk that
			 * finds nothing worth retrying skips the check on its way round, which is exactly the
			 * expensive case: rows the send refused - unsubscribed, hard bounced, contact deleted -
			 * are written as errors too, so a broadcast full of them walks every chunk untimed.
			 *
			 * Stopping early is safe. The status is already RUNNING, so the rows reopened so far
			 * go out on the next tick; the rest stay errored, which is where they started.
			 */
			if ( ( microtime( true ) - $started ) > $budget ) {
				break;
			}

			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT ID, cid FROM {$table}
				WHERE oid = %d AND type = %d AND c_status = %d AND ID > %d
				ORDER BY ID ASC LIMIT 500",
				$broadcast_id,
				BWFAN_Email_Conversations::$TYPE_CAMPAIGN,
				BWFAN_Email_Conversations::$STATUS_ERROR,
				$cursor
			), ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

			if ( ! is_array( $rows ) || empty( $rows ) ) {
				break;
			}

			$cursor = absint( end( $rows )['ID'] );
			$states = BWFCRM_Broadcast_Helper::get_contact_send_states( $rows );

			/**
			 * The contact read failed, so nothing about this chunk is known. Stop rather than
			 * guess: reading it as "every contact has gone" would re-open nothing and quietly
			 * strand the provider failures a resume exists to retry.
			 */
			if ( false === $states ) {
				break;
			}

			$retry = array();
			foreach ( $rows as $row ) {
				$state = $states[ absint( $row['cid'] ) ] ?? array();
				if ( '' === BWFCRM_Broadcast_Helper::get_unsendable_reason( $state, $data ) ) {
					$retry[] = absint( $row['ID'] );
				}
			}

			if ( empty( $retry ) ) {
				continue;
			}

			/**
			 * The row must still be the errored row this chunk read.
			 *
			 * get_contact_send_states() sits between the SELECT and this write, so the window is
			 * not instantaneous, and two Resume clicks can both read PAUSED before either writes.
			 * Without these predicates the second one would drag rows a worker has since sent
			 * back into draft and the contact would be mailed twice. Re-asserting them also makes
			 * a retry after a partial run harmless.
			 */
			$placeholders = implode( ',', array_fill( 0, count( $retry ), '%d' ) );
			$args         = array_merge(
				array( BWFAN_Email_Conversations::$STATUS_DRAFT, current_time( 'mysql', 1 ), $broadcast_id, BWFAN_Email_Conversations::$TYPE_CAMPAIGN, BWFAN_Email_Conversations::$STATUS_ERROR ),
				$retry
			);

			$affected = $wpdb->query( $wpdb->prepare( "UPDATE {$table}
				SET c_status = %d, claim_id = 0, updated_at = %s
				WHERE oid = %d AND type = %d AND c_status = %d AND ID IN ( $placeholders )", $args ) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL

			$affected = absint( $affected );
			$reopened += $affected;

			/**
			 * Counted down as we go, not once at the end. This runs inside the Resume request, and
			 * a broadcast large enough to need many chunks can exhaust the request before the walk
			 * finishes; writing per chunk means whatever was reopened is already accounted for.
			 */
			if ( $affected > 0 ) {
				$wpdb->query( $wpdb->prepare( "UPDATE " . self::_table() . "
					SET `processed` = GREATEST( 0, CAST( `processed` AS SIGNED ) - %d ), `last_modified` = %s
					WHERE `id` = %d", $affected, current_time( 'mysql', 1 ), $broadcast_id ) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			}
		} while ( true );

		return $reopened;
	}

	public static function update_status_to_draft( $campaign_id ) {
		$campaign = self::get_specific_rows( 'id', $campaign_id );
		$data     = [];
		if ( ! empty( $campaign ) ) {
			$campaign      = $campaign[0];
			$campaign_data = ! empty( $campaign['data'] ) ? json_decode( $campaign['data'], true ) : array();

			/**
			 * Not gated on engagements_created any more.
			 *
			 * That key is written for email broadcasts only, so an SMS or WhatsApp broadcast kept
			 * every one of these - `prepared_for` above all, which marks the broadcast as prepared
			 * for an execution time it no longer has. is_broadcast_prepared() then skipped the
			 * count on the next schedule, and the content guards read it as a send in flight and
			 * refused edits on a draft.
			 */
			if ( is_array( $campaign_data ) && ! empty( $campaign_data ) ) {
				unset( $campaign_data['engagements_created'] );
				unset( $campaign_data['offset'] );
				unset( $campaign_data['processed'] );
				unset( $campaign_data['prepared_for'], $campaign_data['prep_id'] );

				/**
				 * The top up window belongs to the run being thrown away. Left behind, topup_done
				 * would close the window on the next run before it ever opened, and topup_offset
				 * would start its cursor above contacts that no longer have an engagement.
				 */
				unset( $campaign_data['topup_done'] );
				unset( $campaign_data['topup_offset'] );
				unset( $campaign_data['consecutive_failures'], $campaign_data['render_failures'] );
				$data = $campaign_data;
			}
		}

		/**
		 * Clear this broadcast's engagements in the background so a re-run starts clean.
		 *
		 * Scheduled for every broadcast rather than only the v2 ones, because v1 also leaves
		 * engagement rows behind for the contacts it already processed. The processing loop
		 * skips any broadcast that has this action pending, so a restart cannot race the
		 * deletion.
		 */
		global $wpdb;

		$set    = "`status` = %d, `execution_time` = NULL, `offset` = 0, `processed` = 0, `e_processed` = 0, `e_offset` = 0, `last_modified` = %s";
		$params = array( BWFCRM_Campaigns::$CAMPAIGN_DRAFT, current_time( 'mysql', 1 ) );

		if ( ! empty( $data ) ) {
			$set     .= ", `data` = %s";
			$params[] = wp_json_encode( $data );
		}

		array_push( $params, absint( $campaign_id ), BWFCRM_Campaigns::$CAMPAIGN_RUNNING, BWFCRM_Campaigns::$CAMPAIGN_COMPLETED, BWFCRM_Campaigns::$CAMPAIGN_CANCELLED );

		/**
		 * Guarded like halt, pause and complete. The endpoint takes any id, so without the guard a
		 * running broadcast was pulled back to draft under its own send and a completed one had
		 * its totals zeroed and its history queued for deletion. The cleanup is queued only once
		 * the row has actually left its status, so a refused unschedule touches nothing.
		 *
		 * Cancelled is refused for the same reason completed is - is_finished_status() calls both
		 * final and the screen offers Unschedule on scheduled alone. It also has to be refused for
		 * the cleanup's sake: delete_engagements() decides whether to keep a v2 broadcast's error
		 * rows by re-reading the status a minute later, so a cancelled row flipped to draft here
		 * reads as a draft by then and its failed recipients are deleted with the unsent ones -
		 * the very history the cancel path preserves.
		 */
		$rows = $wpdb->query( $wpdb->prepare( "UPDATE " . self::_table() . " SET {$set} WHERE `id` = %d AND `status` NOT IN ( %d, %d, %d )", $params ) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL
		if ( empty( $rows ) ) {
			return false;
		}

		self::schedule_engagement_cleanup( $campaign_id );

		return true;
	}

	public static function update_status_to_cancel( $campaign_id ) {
		$campaign_id = absint( $campaign_id );

		/**
		 * Clear whatever was prepared but never sent.
		 *
		 * A cancel lands on a broadcast that is scheduled or running, and on the v2 flow that is
		 * exactly when engagements exist for contacts nobody has written to yet - they are created
		 * up to an hour before the send. Left behind they are never read again and never cleaned,
		 * and a broadcast put back on the calendar later would resume creation from a cursor that
		 * points into that abandoned run. The background action only removes engagements that
		 * never went out, so everything this broadcast did send stays on the record with its opens,
		 * clicks and revenue.
		 */
		$broadcast = self::get( $campaign_id );
		$data      = ! empty( $broadcast['data'] ) ? json_decode( $broadcast['data'], true ) : array();
		$data      = is_array( $data ) ? $data : array();

		global $wpdb;

		$set    = "`status` = %d, `execution_time` = NULL, `last_modified` = %s";
		$params = array( BWFCRM_Campaigns::$CAMPAIGN_CANCELLED, current_time( 'mysql', 1 ) );

		if ( ! empty( $data ) ) {
			/**
			 * Only the creation cursor is reset. `offset` and `processed` are what the report
			 * counts as sent, so unlike the draft path - which throws the whole run away - they
			 * are left exactly as the cancelled run left them.
			 */
			unset( $data['engagements_created'], $data['prepared_for'], $data['prep_id'], $data['topup_done'], $data['topup_offset'] );

			/** The run's own counters go with it, or a cancelled-then-rescheduled broadcast starts one failure short of pausing again */
			unset( $data['consecutive_failures'], $data['render_failures'], $data['failed_cids'], $data['failed_reason'], $data['hold_broadcast'], $data['hold_until'] );

			$set     .= ", `data` = %s, `e_processed` = 0, `e_offset` = 0";
			$params[] = wp_json_encode( $data );
		}

		array_push( $params, $campaign_id, BWFCRM_Campaigns::$CAMPAIGN_SCHEDULED, BWFCRM_Campaigns::$CAMPAIGN_RUNNING, BWFCRM_Campaigns::$CAMPAIGN_PAUSED );

		/**
		 * Guarded on the statuses a cancel makes sense from - the ones the screen offers it on.
		 * The endpoint takes any id, so without the guard a completed broadcast was flipped to
		 * cancelled, its execution time cleared and a cleanup queued against its history. The
		 * cleanup is only queued once a row actually changed.
		 */
		$rows = $wpdb->query( $wpdb->prepare( "UPDATE " . self::_table() . " SET {$set} WHERE `id` = %d AND `status` IN ( %d, %d, %d )", $params ) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL
		if ( empty( $rows ) ) {
			return false;
		}

		self::schedule_engagement_cleanup( $campaign_id );

		return true;
	}

	/**
	 * Queue the background clean-up of a broadcast's unsent engagements
	 *
	 * The action deletes only the engagements that never went out, in batches, and unschedules
	 * itself once there are none left. The processing loop skips any broadcast that has this
	 * action pending, so a broadcast restarted meanwhile cannot race the deletion.
	 *
	 * @param int $campaign_id
	 *
	 * @return void
	 */
	public static function schedule_engagement_cleanup( $campaign_id ) {
		/** absint on both sides: the scheduler matches on the json of these args, so "12" and 12 are different actions */
		$args = array(
			'broadcast_id' => absint( $campaign_id ),
		);

		if ( ! self::has_engagement_cleanup_queued( $campaign_id ) ) {
			bwf_schedule_recurring_action( time(), MINUTE_IN_SECONDS, 'bwfan_delete_unscheduled_broadcast_data', $args );
		}
	}

	/**
	 * Whether the audience of this broadcast is frozen
	 *
	 * A v2 broadcast that is running or paused has its engagements built already and the send
	 * loop claims those rows. A filter or an exclusion saved now changed the count on screen and
	 * nothing else - resume still mailed the frozen set, excluded contacts included, because
	 * reset_prepared_broadcast() only acts on a scheduled row. The same test the content step
	 * makes, for the same reason.
	 *
	 * @param array $campaign Raw broadcast row
	 * @param array $previous_data Decoded data blob
	 *
	 * @return bool
	 */
	public static function audience_locked( $campaign, $previous_data ) {
		return is_array( $campaign ) && ! empty( $previous_data['prepared_for'] )
			&& BWFCRM_Broadcast_Helper::is_v2_broadcast( $campaign )
			&& ! BWFCRM_Campaigns::is_content_editable_status( $campaign['status'] ?? 0 );
	}

	/** Completed and cancelled: the run is over and its report is final */
	public static function is_finished_status( $status ) {
		return in_array( absint( $status ), array( BWFCRM_Campaigns::$CAMPAIGN_COMPLETED, BWFCRM_Campaigns::$CAMPAIGN_CANCELLED ), true );
	}

	/** The update_campaign() response for an edit refused on a finished broadcast */
	public static function finished_response() {
		return array(
			'data'    => array(),
			'status'  => 400,
			'message' => __( 'This broadcast has finished, so its recipients, content and schedule can no longer be changed. Duplicate it to send again.', 'wp-marketing-automations-pro' ),
		);
	}

	/** The update_campaign() response for a refused audience change */
	public static function audience_locked_response() {
		return array(
			'data'    => array(),
			'status'  => 400,
			'message' => __( 'This broadcast is already sending, so its recipients can no longer be changed. Pause and duplicate it if you need a different audience.', 'wp-marketing-automations-pro' ),
		);
	}

	/**
	 * Whether an engagement cleanup for this broadcast is still queued
	 *
	 * bwf_has_action_scheduled() matches on hook and args alone, whatever the row's status. A
	 * cleanup whose worker died mid-run - a PHP timeout or an OOM kill on a large delete - left
	 * its row at status 1 for good, and every later tick read that as "cleanup pending": the
	 * dispatcher skipped the broadcast, the re-arm sites saw it as already scheduled, and the
	 * broadcast sat unprocessable with nothing in the logs to say why. Only a pending (0) or a
	 * running (1) row means work is actually queued, and a row still marked running long after
	 * its slot is a worker that is not coming back. The hook is this plugin's own, so that row
	 * is dropped here rather than left to poison the pair forever.
	 *
	 * @param int $campaign_id
	 *
	 * @return bool
	 */
	public static function has_engagement_cleanup_queued( $campaign_id ) {
		global $wpdb;

		$hook = 'bwfan_delete_unscheduled_broadcast_data';
		$args = wp_json_encode( array( 'broadcast_id' => absint( $campaign_id ) ) );

		$stale = $wpdb->get_col( $wpdb->prepare( "SELECT `id` FROM {$wpdb->prefix}bwf_actions WHERE `hook` = %s AND `args` = %s AND `status` = 1 AND `e_time` < %d", $hook, $args, time() - 10 * MINUTE_IN_SECONDS ) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( ! empty( $stale ) && class_exists( 'BWF_AS_Actions_Crud' ) ) {
			BWF_AS_Actions_Crud::delete_actions( array_map( 'absint', $stale ) );
		}

		$queued = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}bwf_actions WHERE `hook` = %s AND `args` = %s AND `status` IN ( 0, 1 )", $hook, $args ) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return absint( $queued ) > 0;
	}

	/**
	 * Undo the preparation of a scheduled broadcast whose audience or content has just changed
	 *
	 * A v2 email broadcast is prepared up to an hour before it is due: the audience is counted,
	 * the templates are written, and the engagements are created with every merge tag already
	 * resolved against the content as it stood. Editing the broadcast inside that window used to
	 * leave the two out of step - is_broadcast_prepared() keeps the set-up pass from running
	 * again, so the new filters were never counted and the new content never reached a template
	 * row, while the engagements already created still carried the old copy. With A/B content the
	 * stored template id then matched nothing in the new content and the send fell back to
	 * whichever variant the counter landed on.
	 *
	 * Dropping the marker puts the broadcast back to unprepared, so the next pass sets it up from
	 * the top, and the engagements of the discarded run are cleared in the background.
	 *
	 * Scheduled broadcasts only. A running one is past the point where its audience can be
	 * rebuilt, and a draft has nothing prepared to undo.
	 *
	 * @param int $campaign_id
	 *
	 * @return bool Whether the preparation was dropped
	 */
	public static function reset_prepared_broadcast( $campaign_id ) {
		$campaign_id = absint( $campaign_id );
		$broadcast   = self::get( $campaign_id );

		if ( ! is_array( $broadcast ) || empty( $broadcast ) || BWFCRM_Campaigns::$CAMPAIGN_SCHEDULED !== absint( $broadcast['status'] ) ) {
			return false;
		}

		$data = ! empty( $broadcast['data'] ) ? json_decode( $broadcast['data'], true ) : array();
		if ( ! is_array( $data ) || ! isset( $data['prepared_for'] ) ) {
			return false;
		}

		unset( $data['prepared_for'], $data['prep_id'], $data['engagements_created'], $data['topup_done'], $data['topup_offset'] );

		/**
		 * The counters of the run being thrown away go with it, exactly as update_status_to_ongoing()
		 * drops them on a resume.
		 *
		 * Both are persisted across runs on purpose - a provider that fails slowly, or a template
		 * that throws, has to reach its limit over several Action Scheduler passes - and both are
		 * only ever zeroed by a send or a build that succeeds. Left behind they carry into the run
		 * that replaces this one: a broadcast halted at ten build failures, whose template the admin
		 * has just fixed, sits at the limit again, so the first recipient whose own data still throws
		 * halts the whole broadcast having mailed nobody. The same holds for a pause one failure away.
		 *
		 * halt_reason and the failed lists belong to the discarded run too - the engagements they
		 * describe are deleted by the cleanup queued below.
		 */
		unset( $data['consecutive_failures'], $data['render_failures'], $data['failed_cids'], $data['failed_reason'], $data['halt_reason'] );

		self::update( array(
			'data'          => wp_json_encode( $data ),
			'e_processed'   => 0,
			'e_offset'      => 0,
			'last_modified' => current_time( 'mysql', 1 ),
		), array(
			'id' => $campaign_id,
		) );

		self::schedule_engagement_cleanup( $campaign_id );

		return true;
	}

	public static function get_interaction_stats_by_date_range( $intervals, $oid ) {
		global $wpdb;

		$campaign = self::get( $oid );
		$mode     = absint( $campaign['type'] );

		$open_queries = array_map( function ( $interval ) {
			return "SUM(ROUND ( ( LENGTH(o_interaction) - LENGTH( REPLACE ( o_interaction, '$interval', '') ) ) / LENGTH('$interval') )) AS '$interval'";
		}, $intervals );
		$open_queries = implode( ' , ', $open_queries );

		$click_queries = array_map( function ( $interval ) {
			return "SUM(ROUND ( ( LENGTH(c_interaction) - LENGTH( REPLACE ( c_interaction, '$interval', '') ) ) / LENGTH('$interval') )) AS '$interval'";
		}, $intervals );
		$click_queries = implode( ' , ', $click_queries );

		$open_query  = "SELECT $open_queries FROM {$wpdb->prefix}bwfan_engagement_tracking WHERE `oid` = $oid AND `type` = 2";
		$click_query = "SELECT $click_queries FROM {$wpdb->prefix}bwfan_engagement_tracking WHERE `oid` = $oid AND `type` = 2";

		return array(
			//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL
			'open'  => ! empty( $open_queries ) && BWFCRM_Campaigns::$CAMPAIGN_EMAIL === $mode ? $wpdb->get_results( $open_query, ARRAY_A ) : array(),
			//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL
			'click' => ! empty( $click_queries ) ? $wpdb->get_results( $click_query, ARRAY_A ) : array(),
		);
	}

	/**
	 * Get top broadcast
	 *
	 * @param $type
	 *
	 * @return array|object|stdClass[]|null
	 */
	public static function get_top_broadcast( $type = 1 ) {
		global $wpdb;
		$campaign_table = $wpdb->prefix . 'bwfan_broadcast';

		if ( ! bwfan_is_woocommerce_active() ) {
			$base_query = "SELECT COALESCE(b.`id`,'') AS `id`, COALESCE(b.`title`,'') AS `title`, COALESCE(b.`processed`,0) AS `count`, SUM(IF(open>0, 1, 0)) AS `open_count` FROM {$campaign_table} AS b LEFT JOIN {$wpdb->prefix}bwfan_engagement_tracking AS et ON et.oid = b.id WHERE b.`type` = %d AND et.type = 2 GROUP BY et.`oid` ORDER BY `open_count` DESC LIMIT 0,5";
		} else {
			$conversion_table = $wpdb->prefix . 'bwfan_conversions';
			$base_query       = "SELECT COALESCE(cm.`id`,'') AS `id`, COALESCE(cm.`title`,'') AS `title`, cm.`type`, COALESCE(cm.`processed`,0) AS `count`, SUM(c.`wctotal`) AS `total_revenue` FROM $campaign_table AS cm LEFT JOIN $conversion_table AS c ON c.`oid` = cm.`id` WHERE c.`otype` = 2 AND cm.`type` = %d GROUP BY cm.`id` ORDER BY `total_revenue` DESC LIMIT 0,5";
		}

		return $wpdb->get_results( $wpdb->prepare( $base_query, $type ), ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * Park a broadcast for its smart send window
	 *
	 * The blob is read here rather than taken from the caller, because both callers reach this
	 * from inside a run holding the copy they read when that run started: on the v2 path the test
	 * batch has been sent since, and consecutive_failures, failed_cids and render_failures
	 * written during it would all be rolled back by this one statement, restarting the failure
	 * gate's count from zero. Only hold_broadcast is this method's to write.
	 *
	 * @param int $broadcast_id
	 * @param int $hours_to_delay Window length, pushed onto execution_time
	 *
	 * @return bool
	 */
	public static function hold_broadcast_for_smart_send( $broadcast_id, $hours_to_delay ) {
		$broadcast                = self::get( absint( $broadcast_id ) );
		$b_data                   = ! empty( $broadcast['data'] ) ? json_decode( $broadcast['data'], true ) : array();
		$b_data                   = ! is_array( $b_data ) ? array() : $b_data;
		$b_data['hold_broadcast'] = 1;

		/** Legacy key: dropped here so a blob written before the window moved onto execution_time is cleaned up */
		unset( $b_data['hold_until'] );

		return self::set_delay( $broadcast_id, $hours_to_delay, 'H', $b_data );
	}

	public static function remove_hold_flag_smart_sending( $broadcast_id ) {
		$broadcast                    = self::get( absint( $broadcast_id ) );
		$b_data                       = ! empty( $broadcast['data'] ) ? json_decode( $broadcast['data'], true ) : array();
		$b_data                       = ! is_array( $b_data ) ? array() : $b_data;
		$b_data['smart_sending_done'] = 1;
		if ( isset( $b_data['hold_broadcast'] ) ) {
			unset( $b_data['hold_broadcast'] );
		}

		/** Legacy deadline, from before the window became execution_time - cleared so old blobs do not keep it */
		if ( isset( $b_data['hold_until'] ) ) {
			unset( $b_data['hold_until'] );
		}

		return ! ! self::update( array(
			'data'          => json_encode( $b_data ),
			'last_modified' => current_time( 'mysql', 1 ),
		), array(
			'id' => absint( $broadcast_id ),
		) );
	}

	public static function declare_the_winner_email( $broadcast_id, $winner_data ) {
		if ( empty( $winner_data ) ) {
			return false;
		}
		$broadcast = self::get( intval( $broadcast_id ) );
		$b_data    = ! empty( $broadcast['data'] ) ? json_decode( $broadcast['data'], true ) : array();
		$b_data    = ! is_array( $b_data ) ? array() : $b_data;

		$b_data                       = array_replace( $b_data, $winner_data );
		$b_data['smart_sending_done'] = 1;
		if ( isset( $b_data['hold_broadcast'] ) ) {
			unset( $b_data['hold_broadcast'] );
		}

		/** Legacy deadline, from before the window became execution_time - cleared so old blobs do not keep it */
		if ( isset( $b_data['hold_until'] ) ) {
			unset( $b_data['hold_until'] );
		}

		/**
		 * Only v2 goes back into creation once the winner is known - it has to build the remaining
		 * engagements with the winning template. v1 walks its contacts as it sends and never reads
		 * this flag, but the report does: writing it there left an SMS or WhatsApp smart send
		 * claiming to be preparing its recipients for the rest of the run.
		 */
		if ( BWFCRM_Broadcast_Helper::is_v2_broadcast( $broadcast ) ) {
			$b_data['engagements_created'] = 0;
		}

		return ! ! self::update( array(
			'data'          => json_encode( $b_data ),
			'last_modified' => current_time( 'mysql', 1 ),
		), array(
			'id' => intval( $broadcast_id ),
		) );
	}

	public static function update_broadcast_data( $broadcast_id, $data ) {
		if ( ! is_array( $data ) ) {
			return false;
		}

		$broadcast = self::get( absint( $broadcast_id ) );
		$b_data    = ! empty( $broadcast['data'] ) ? json_decode( $broadcast['data'], true ) : array();
		$b_data    = ! is_array( $b_data ) ? array() : $b_data;
		$b_data    = array_replace( $b_data, $data );

		return ! ! self::update( array(
			'data'          => json_encode( $b_data ),
			'last_modified' => current_time( 'mysql', 1 ),
		), array(
			'id' => absint( $broadcast_id ),
		) );
	}

	/**
	 * Get first broadcast id
	 */
	public static function get_first_broadcast_id() {
		global $wpdb;
		$query = 'SELECT MIN(`id`) FROM ' . self::_table();

		return $wpdb->get_var( $query ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	public static function get_broadcast_data( $broadcast_ids ) {
		// Handle single broadcast ID for backward compatibility
		if ( ! is_array( $broadcast_ids ) ) {
			$broadcast = self::get( absint( $broadcast_ids ) );
			if ( ! is_array( $broadcast ) || empty( $broadcast ) || empty( $broadcast['data'] ) ) {
				return array();
			}

			$data = json_decode( $broadcast['data'], true );

			return ( ! is_array( $data ) || empty( $data ) ) ? array() : $data;
		}

		// Handle multiple broadcast IDs using get_results
		if ( empty( $broadcast_ids ) ) {
			return array();
		}

		$broadcast_ids = array_map( 'absint', $broadcast_ids );
		$id_list       = implode( ',', $broadcast_ids );

		$query      = "SELECT * FROM {table_name} WHERE id IN ($id_list)";
		$broadcasts = self::get_results( $query );
		if ( empty( $broadcasts ) ) {
			return array();
		}

		// Process results into associative array
		$broadcast_data = array();
		foreach ( $broadcasts as $broadcast ) {
			$data                                         = ! empty( $broadcast['data'] ) ? json_decode( $broadcast['data'], true ) : array();
			$broadcast_data[ absint( $broadcast['id'] ) ] = is_array( $data ) ? $data : array();
		}

		return $broadcast_data;
	}

	public static function get_broadcast_basic_stats( $oid ) {
		global $wpdb;

		$tracking_table  = "{$wpdb->prefix}bwfan_engagement_tracking";
		$broadcast_table = self::_table();

		/** Per mail sent rather than per engagement row - see the note in include_open_click_rate() */
		$query = $wpdb->prepare( "SELECT oid as id, SUM(open) as open_count, (SUM(IF(open>0, 1, 0))/NULLIF(SUM(IF(c_status=2, 1, 0)), 0)) * 100 as open_rate, SUM(click) as click_count, (SUM(IF(click>0, 1, 0))/NULLIF(SUM(IF(c_status=2, 1, 0)), 0)) * 100 as click_rate, SUM(IF(c_status=2, 1, 0)) as sent FROM {$tracking_table} WHERE oid = %d AND type= %d", absint( $oid ), BWFAN_Email_Conversations::$TYPE_CAMPAIGN );
		$stats = $wpdb->get_row( $query, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$stats = ! is_array( $stats ) ? array() : self::get_formatted_campaign_data( array( $stats ) )[0];

		/** `e_processed`, `processed` and `execution_time` come along for get_campaign_notice_data() - the progress notices read all three off the row */
		$query   = $wpdb->prepare( "SELECT id,count,status, last_modified, data, e_processed, processed, execution_time FROM {$broadcast_table} WHERE id = %d LIMIT 0, 1", $oid );
		$b_stats = $wpdb->get_row( $query, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$b_stats = ! is_array( $b_stats ) ? array() : $b_stats;

		$stats                = array_replace( $stats, $b_stats );
		$stats['notice_data'] = [];
		if ( isset( $stats['status'] ) && ! in_array( absint( $stats['status'] ), [
				BWFCRM_Campaigns::$CAMPAIGN_DRAFT,
				BWFCRM_Campaigns::$CAMPAIGN_SCHEDULED,
				BWFCRM_Campaigns::$CAMPAIGN_COMPLETED,
			], true ) ) {
			$campaign_data = ! empty( $b_stats['data'] ) ? json_decode( $b_stats['data'], true ) : array();
			if ( ! empty( $campaign_data ) ) {
				/** The row is passed on so this poll says the same thing get_campaign() does - without it the notice has no audience size and falls back to the plain wording forever */
				$stats['notice_data'] = self::get_campaign_notice_data( $stats['status'], $campaign_data, $b_stats );
			}
		}
		unset( $stats['data'] );

		return $stats;
	}

	/**
	 * Return broadcast count by type
	 *
	 * @return int[]
	 */
	public static function get_broadcast_total_count() {
		global $wpdb;
		$response = [
			'all' => 0,
			'1'   => 0,
			'2'   => 0,
			'3'   => 0,
		];
		$all      = 0;
		$table    = self::_table();
		$query    = "SELECT type, COUNT(*) as count FROM {$table} WHERE 1=1 AND parent=0 GROUP BY type ";
		$result   = $wpdb->get_results( $query, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		if ( empty( $result ) ) {
			return $response;
		}
		foreach ( $result as $row ) {
			$response[ $row['type'] ] = intval( $row['count'] );
			$all                      += intval( $row['count'] );
		}
		$response['all'] = $all;

		return $response;
	}

	/**
	 * Return broadcast count by status
	 *
	 * @param int $type broadcast type
	 *
	 * @return int[]
	 */
	public static function get_broadcast_total_count_by_status( $type = 1 ) {
		global $wpdb;
		$response = [
			'2' => 0,
			'3' => 0,
			'4' => 0,
			'5' => 0,
			'6' => 0,
			'7' => 0,
		];
		$all      = 0;
		$table    = self::_table();
		$query    = $wpdb->prepare( "SELECT `status`, COUNT(*) as `count` FROM {$table} WHERE 1=1 AND `parent`=0 AND `type`=%d GROUP BY `status`", $type );
		$result   = $wpdb->get_results( $query, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		if ( empty( $result ) ) {
			return $response;
		}
		foreach ( $result as $row ) {
			$response[ $row['status'] ] = intval( $row['count'] );
			$all                        += intval( $row['count'] );
		}
		$response['status_all'] = $all;

		return $response;
	}

	/**
	 * Push a broadcast's next run further out
	 *
	 * The new time is taken only when it is later than the one already stored. Every caller means
	 * "try again after this long" - the daily send cap, a URL shortener that would not respond, the
	 * smart send window - and none of them means "run sooner".
	 *
	 * Writing `now + delay` outright did mean exactly that whenever execution_time was still in the
	 * future. A v2 email broadcast is fetched up to an hour before its execution time so its
	 * engagements can be created in advance, and the daily cap is checked on everything that fetch
	 * returns, so a cap hit during that hour used to drag a broadcast scheduled for 6pm down to
	 * `now + 10 minutes` and send it well before the time the user picked. It also collapsed a
	 * running smart send window, which is measured by this very column.
	 *
	 * Resolved in SQL rather than by reading the row first, so two workers delaying the same
	 * broadcast cannot each write their own value over the other's.
	 *
	 * @param int $broadcast_id
	 * @param string|int $delay_time Length of the delay
	 * @param string $time_type DateInterval time unit - M minutes, H hours
	 * @param array $b_data Data blob to write alongside, optional
	 *
	 * @return bool
	 */
	public static function set_delay( $broadcast_id, $delay_time = "10", $time_type = "M", $b_data = [] ) {
		global $wpdb;

		$execute_time = new DateTime( 'now' );
		$execute_time->add( new DateInterval( "PT{$delay_time}{$time_type}" ) );
		$execute_time = $execute_time->format( 'Y-m-d H:i:s' );

		/** COALESCE first: execution_time is nullable, and GREATEST() against a NULL is NULL */
		$set    = "`execution_time` = GREATEST( COALESCE( `execution_time`, %s ), %s ), `last_modified` = %s";
		$params = array( $execute_time, $execute_time, current_time( 'mysql', 1 ) );

		if ( is_array( $b_data ) && ! empty( $b_data ) ) {
			$set      .= ", `data` = %s";
			$params[] = wp_json_encode( $b_data );
		}

		$params[] = absint( $broadcast_id );

		return false !== $wpdb->query( $wpdb->prepare( "UPDATE " . self::_table() . " SET {$set} WHERE `id` = %d", $params ) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL
	}

	/**
	 * Remove parent from child's broadcast
	 *
	 * @param $ids
	 *
	 * @return bool|int|mysqli_result|resource|void|null
	 */
	public static function remove_parent_from_child( $ids ) {
		if ( empty( $ids ) ) {
			return false;
		}
		global $wpdb;

		$child_ids = BWFAN_Model_Broadcast::get_broadcast_child( $ids, true );
		if ( empty( $child_ids ) ) {
			return;
		}

		$table       = self::_table();
		$placeholder = array_fill( 0, count( $child_ids ), '%d' );
		$placeholder = implode( ", ", $placeholder );
		$query       = "UPDATE `{$table}` SET `parent` = 0 WHERE `id` IN ( $placeholder )";
		$query       = $wpdb->prepare( $query, $child_ids );

		return $wpdb->query( $query ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * Get broadcast title
	 *
	 * @param $search
	 * @param $limit
	 * @param $offset
	 *
	 * @return array|object|stdClass[]|null
	 */
	public static function get_broadcasts_titles( $search = '', $limit = 10, $offset = 0 ) {
		$broadcast_table = self::_table();

		$broadcast_query = "SELECT `id`, `title` FROM $broadcast_table WHERE `parent` = 0";
		global $wpdb;
		if ( ! empty( $search ) ) {
			$broadcast_query .= $wpdb->prepare( " AND title LIKE %s", '%' . $wpdb->esc_like( $search ) . '%' );
		}
		if ( ! empty( $limit ) ) {
			$broadcast_query .= $wpdb->prepare( " LIMIT %d, %d", $offset, $limit );
		}

		return self::get_results( $broadcast_query );
	}

	/**
	 * Get broadcast template's stats & winner
	 *
	 * @param $bid
	 * @param $mode
	 *
	 * @return array|stdClass[]
	 */
	public static function get_broadcast_tids_stats( $bid, $mode ) {
		global $wpdb;

		$engagement_table = $wpdb->prefix . 'bwfan_engagement_tracking';
		$columns          = 'SUM(IF(`open`>0, 1, 0)) AS `opened`, SUM(IF(`click`>0, 1, 0)) AS `clicked`, SUM(IF(`c_status`=2, 1, 0)) AS `sent`, `tid`';

		$interaction = ( BWFAN_Email_Conversations::$MODE_SMS === intval( $mode ) ) ? 'clicked' : 'opened';
		$interaction = apply_filters( 'bwfan_most_interacted_template_based_on', $interaction, $mode, $bid );
		$interaction = in_array( $interaction, array( 'opened', 'clicked', 'sent' ), true ) ? $interaction : 'opened';

		$query = "SELECT $columns FROM {$engagement_table} WHERE `oid` = %d AND `type` = 2 GROUP BY `tid` ORDER BY `$interaction` DESC";
		$data  = $wpdb->get_results( $wpdb->prepare( $query, $bid ), ARRAY_A );//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL
		if ( empty( $data ) ) {
			return [];
		}

		$tids        = array_column( $data, 'tid' );
		$conversions = BWFAN_Model_Broadcast::get_conversions_by_tids( $bid, true, $tids );
		$winner      = intval( $data[0]['tid'] );

		$stats = [];
		foreach ( $data as $row ) {
			if ( isset( $conversions[ $row['tid'] ] ) ) {
				$row['revenue'] = $conversions[ $row['tid'] ]['revenue'] ?? 0;
			}
			$stats[ $row['tid'] ] = $row;
		}

		return array( 'winner' => $winner, 'smart_send_stat' => $stats );
	}

	/**
	 * Get formatted smart stats
	 *
	 * @param array $data
	 *
	 * @return array
	 */
	public static function get_formatted_smart_stat( $data = [], $only_formatted = false ) {
		if ( empty( $data ) || ! is_array( $data ) ) {
			return [];
		}

		return array_map( function ( $stat ) use ( $only_formatted ) {
			$clicked = intval( $stat['clicked'] );
			$opened  = intval( $stat['opened'] );
			$sent    = intval( $stat['sent'] );
			$revenue = floatval( $stat['revenue'] );

			$open_rate  = ( $sent > 0 ) ? number_format( ( $opened / $sent ) * 100, 2 ) : 0;
			$click_rate = ( $sent > 0 ) ? number_format( ( $clicked / $sent ) * 100, 2 ) : 0;

			$click_to_open_rate = ( empty( $clicked ) || empty( $opened ) ) ? 0 : number_format( ( $clicked / $opened ) * 100, 2 );

			$stat['formatted_data'] = [
				[
					'l' => __( 'Sent', 'wp-marketing-automations-pro' ),
					'v' => empty( $sent ) ? '-' : $sent,
				],
				[
					'l' => __( 'Open Rate', 'wp-marketing-automations-pro' ),
					'v' => empty( $opened ) ? '-' : $open_rate . '% (' . $opened . ')',
				],
				[
					'l' => __( 'Click Rate', 'wp-marketing-automations-pro' ),
					'v' => empty( $clicked ) ? '-' : $click_rate . '% (' . $clicked . ')',
				],
				[
					'l' => __( 'Click to Open Rate', 'wp-marketing-automations-pro' ),
					'v' => empty( $click_to_open_rate ) ? '-' : $click_to_open_rate . '%',
				],
			];

			if ( bwfan_is_woocommerce_active() ) {
				$currency_symbol          = get_woocommerce_currency_symbol();
				$stat['formatted_data'][] = [
					'l' => __( 'Revenue', 'wp-marketing-automations-pro' ),
					'v' => empty( $revenue ) ? '-' : html_entity_decode( $currency_symbol . $revenue, ENT_QUOTES | ENT_HTML401 ),
				];
			}

			return $only_formatted ? $stat['formatted_data'] : $stat;
		}, $data );
	}

	/**
	 * Update broadcast data with status
	 *
	 * @param $broadcast_id
	 * @param $data
	 * @param $update_status
	 * @param $offset
	 * @param $processed
	 *
	 * @return bool
	 */
	public static function update_broadcast_data_with_status( $broadcast_id, $data = [], $update_status = false, $offset = null, $processed = null ) {
		$updated_data = [];
		if ( ! empty( $data ) && is_array( $data ) ) {
			$updated_data['data'] = json_encode( $data );
		}

		if ( false !== $update_status ) {
			$updated_data['status'] = $update_status;
		}
		if ( ! is_null( $offset ) ) {
			$updated_data['offset'] = $offset;
		}
		if ( ! is_null( $processed ) ) {
			$updated_data['processed'] = $processed;
		}

		if ( empty( $updated_data ) ) {
			return false;
		}
		$updated_data['last_modified'] = current_time( 'mysql', 1 );

		return ! ! self::update( $updated_data, array(
			'id' => absint( $broadcast_id ),
		) );

	}

	/**
	 * Delete failed engagements
	 *
	 * @param $broadcast_id
	 * @param $failed_cids
	 *
	 * @return bool|int|mysqli_result|null
	 */
	public static function delete_failed_engagements( $broadcast_id, $failed_cids, $broadcast = [] ) {
		global $wpdb;

		$placeholder = array_fill( 0, count( $failed_cids ), '%d' );
		$placeholder = implode( ", ", $placeholder );
		$args        = array_merge( [ $broadcast_id ], $failed_cids );

		if ( BWFCRM_Broadcast_Helper::is_v2_broadcast( $broadcast ) ) {
			$query = $wpdb->prepare( "UPDATE  {$wpdb->prefix}bwfan_engagement_tracking SET `c_status` = '1' WHERE `oid`=%d AND `type`=2 AND `cid` IN ( $placeholder )", $args );
		} else {
			$query = $wpdb->prepare( "DELETE FROM {$wpdb->prefix}bwfan_engagement_tracking WHERE `oid`=%d AND `type`=2 AND `cid` IN ( $placeholder )", $args );
		}

		return $wpdb->query( $query ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL
	}

	/**
	 * Get data with categories id.
	 *
	 * @param $category_ids
	 * @param $get_model_class
	 * @param $type
	 *
	 * @return array|object|stdClass[]|null
	 */
	public static function get_data_with_categories( $category_ids ) {
		if ( ! is_array( $category_ids ) ) {
			$category_ids = [ $category_ids ];
		}

		global $wpdb;
		$conditions = [];
		foreach ( $category_ids as $category_id ) {
			$conditions[] = $wpdb->prepare( 'category LIKE %s', '%"' . absint( $category_id ) . '"%' );
		}

		$sql = 'SELECT id AS ID, category
           FROM {table_name}
           WHERE ' . implode( ' OR ', $conditions );

		return self::get_results( $sql );
	}

}
