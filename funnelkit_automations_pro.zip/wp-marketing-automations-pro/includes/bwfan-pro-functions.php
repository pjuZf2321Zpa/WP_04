<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Paid Membership Pro Detection
 */
if ( ! function_exists( 'bwfan_is_paid_membership_pro_active' ) ) {
	function bwfan_is_paid_membership_pro_active() {
		return BWFAN_PRO_Plugin_Dependency::paid_membership_active_check();
	}
}

/**
 * Thrive Lead Form Detection
 */
if ( ! function_exists( 'bwfan_is_tve_active' ) ) {
	function bwfan_is_tve_active() {
		return BWFAN_PRO_Plugin_Dependency::tve_active_check();
	}
}
/**
 * Thrive Lead architech Detection
 */
if ( ! function_exists( 'bwfan_is_tve_architect_active' ) ) {
	function bwfan_is_tve_architect_active() {
		return BWFAN_PRO_Plugin_Dependency::tve_architect_active_check();
	}
}

/**
 * Learndash Detection
 */
if ( ! function_exists( 'bwfan_is_learndash_active' ) ) {
	function bwfan_is_learndash_active() {
		return BWFAN_PRO_Plugin_Dependency::learndash_active_check();
	}
}

/**
 * MasterStudy LMS Detection
 */
if ( ! function_exists( 'bwfan_is_masterstudy_active' ) ) {
	function bwfan_is_masterstudy_active() {
		return BWFAN_PRO_Plugin_Dependency::masterstudy_active_check();
	}
}

/**
 * MasterStudy LMS Pro Detection
 */
if ( ! function_exists( 'bwfan_is_masterstudy_pro_active' ) ) {
	function bwfan_is_masterstudy_pro_active() {
		return BWFAN_PRO_Plugin_Dependency::masterstudy_pro_active_check();
	}
}

/**
 * Ninja Forms Detection
 */
if ( ! function_exists( 'bwfan_is_ninja_forms_active' ) ) {
	function bwfan_is_ninja_forms_active() {
		return BWFAN_PRO_Plugin_Dependency::ninja_forms_active_check();
	}
}

/**
 * Fluent Forms Detection
 */
if ( ! function_exists( 'bwfan_is_fluent_forms_active' ) ) {
	function bwfan_is_fluent_forms_active() {
		return BWFAN_PRO_Plugin_Dependency::fluent_forms_active_check();
	}
}

/**
 * SureForms Detection
 */
if ( ! function_exists( 'bwfan_is_sureforms_active' ) ) {
	function bwfan_is_sureforms_active() {
		return BWFAN_PRO_Plugin_Dependency::sureforms_active_check();
	}
}

/**
 * Caldera Forms Detection
 */
if ( ! function_exists( 'bwfan_is_caldera_forms_active' ) ) {
	function bwfan_is_caldera_forms_active() {
		return BWFAN_PRO_Plugin_Dependency::caldera_forms_active_check();
	}
}

/**
 * Optin Forms Detection
 */
if ( ! function_exists( 'bwfan_is_optin_forms_active' ) ) {
	function bwfan_is_optin_forms_active() {
		return BWFAN_PRO_Plugin_Dependency::optin_forms_active_check();
	}
}
/**
 * Forminator Forms Detection
 */
if ( ! function_exists( 'bwfan_is_forminator_forms_active' ) ) {
	function bwfan_is_forminator_forms_active() {
		return BWFAN_PRO_Plugin_Dependency::forminator_forms_active_check();
	}
}

/**
 * Wishlist plugin Detection
 */
if ( ! function_exists( 'bwfan_is_wc_wishlist_active' ) ) {
	function bwfan_is_wc_wishlist_active() {
		return BWFAN_PRO_Plugin_Dependency::wc_wishlist_active_check();
	}
}

/**
 *
 * Weglot language plugin
 */
if ( ! function_exists( 'bwfan_is_weglot_active' ) ) {
	function bwfan_is_weglot_active() {
		return BWFAN_PRO_Plugin_Dependency::weglot_active_check();
	}
}

/**
 *
 * Linguise language plugin
 */
if ( ! function_exists( 'bwfan_is_linguise_active' ) ) {
	function bwfan_is_linguise_active() {
		return BWFAN_PRO_Plugin_Dependency::linguise_active_check();
	}
}

/**
 * Wishlist Member plugin by Wishlist Products
 */

if ( ! function_exists( 'bwfan_is_wlm_active' ) ) {
	function bwfan_is_wlm_active() {
		return BWFAN_PRO_Plugin_Dependency::wlm_active_check();
	}
}

/**
 * Woocommerce Advanced Shipping
 */
if ( ! function_exists( 'bwfan_is_woocommerce_advanced_shipping_pro_active' ) ) {
	function bwfan_is_woocommerce_advanced_shipping_pro_active() {
		return BWFAN_PRO_Plugin_Dependency::wc_advanced_shipping_active_check();
	}
}

/**
 * Advanced Coupons for woocommerce free
 */
if ( ! function_exists( 'bwfan_is_advanced_coupon_for_woocommerce_active' ) ) {
	function bwfan_is_advanced_coupon_for_woocommerce_active() {
		return BWFAN_PRO_Plugin_Dependency::wc_advanced_coupons_active_check();
	}
}

if ( ! function_exists( 'bwfan_is_loyalty_program_for_woocommerce_active' ) ) {
	function bwfan_is_loyalty_program_for_woocommerce_active() {
		return BWFAN_PRO_Plugin_Dependency::wc_loyalty_program_active_check();
	}
}

/**
 * Funnel Builder Lite
 */
if ( ! function_exists( 'bwfan_is_funnel_active' ) ) {
	function bwfan_is_funnel_active() {
		return BWFAN_PRO_Plugin_Dependency::bwfan_is_funnel_active_check();
	}
}

/**
 * Yith Affiliates plugin Detection
 */
if ( ! function_exists( 'bwfan_is_yith_affiliates_active' ) ) {
	function bwfan_is_yith_affiliates_active() {
		return BWFAN_PRO_Plugin_Dependency::yith_affiliates_active_check();
	}
}

/**
 * Yith Wishlist plugin Detection
 */
if ( ! function_exists( 'bwfan_is_yith_wishlist_active' ) ) {
	function bwfan_is_yith_wishlist_active() {
		return BWFAN_PRO_Plugin_Dependency::yith_wishlist_active_check();
	}
}
/**
 * TI WC Wishlist plugin Detection
 */
if ( ! function_exists( 'bwfan_is_ti_wc_wishlist_active' ) ) {
	function bwfan_is_ti_wc_wishlist_active() {
		return BWFAN_PRO_Plugin_Dependency::ti_wc_wishlist_active_check();
	}
}

/**
 * XL Next move plugin Detection
 */
if ( ! function_exists( 'bwfan_is_xl_nextmove_thankyou_active' ) ) {
	function bwfan_is_xl_nextmove_thankyou_active() {
		return BWFAN_PRO_Plugin_Dependency::xl_nextmove_thankyou_active_check();
	}
}

/**
 * WooCommerce Orders Tracking Premium plugin Detection
 */
if ( ! function_exists( 'bwfan_wc_order_tracking_active' ) ) {
	function bwfan_wc_order_tracking_active() {
		return BWFAN_PRO_Plugin_Dependency::wc_order_tracking_active_check();
	}
}

/**
 * RewardsWP Detection
 */
if ( ! function_exists( 'bwfan_is_rewardswp_active' ) ) {
	function bwfan_is_rewardswp_active() {
		return BWFAN_PRO_Plugin_Dependency::rewardswp_active_check();
	}
}

/**
 * Check if RewardsWP version 1.3.0 or above is active.
 *
 * @return bool
 */
if ( ! function_exists( 'bwfan_is_rewardswp_v130_or_above' ) ) {
	function bwfan_is_rewardswp_v130_or_above() {
		return defined( 'AM_REWARDSWP_VERSION' ) && version_compare( AM_REWARDSWP_VERSION, '1.3.0', '>=' );
	}
}

/**
 * Resolve a RewardsWP member from merge tag loader data.
 *
 * Tries rwp_member_id first, then falls back to email, user_id, and contact_id.
 *
 * @param array $get_data Merge tag loader data array.
 *
 * @return object|null RewardsWP Member object or null.
 */
if ( ! function_exists( 'bwfan_get_rewardswp_member_from_data' ) ) {
	function bwfan_get_rewardswp_member_from_data( $get_data ) {
		if ( ! function_exists( 'Awesomemotive\Rewardswp\Helpers\get_member_by' ) ) {
			return null;
		}

		/** Try by rwp_member_id */
		$member_id = isset( $get_data['rwp_member_id'] ) ? intval( $get_data['rwp_member_id'] ) : 0;
		if ( ! empty( $member_id ) && function_exists( 'Awesomemotive\Rewardswp\Helpers\get_member' ) ) {
			$member = \Awesomemotive\Rewardswp\Helpers\get_member( $member_id );
			if ( $member ) {
				return $member;
			}
		}

		/** Try by email */
		$email = isset( $get_data['email'] ) ? $get_data['email'] : '';
		if ( ! empty( $email ) && is_email( $email ) ) {
			$member = \Awesomemotive\Rewardswp\Helpers\get_member_by( 'email', $email );
			if ( $member ) {
				return $member;
			}
		}

		/** Try by user_id */
		$user_id = isset( $get_data['user_id'] ) ? intval( $get_data['user_id'] ) : 0;
		if ( ! empty( $user_id ) ) {
			$member = \Awesomemotive\Rewardswp\Helpers\get_member_by( 'user_id', $user_id );
			if ( $member ) {
				return $member;
			}
		}

		/** Try by contact_id - resolve to user_id first */
		$contact_id = isset( $get_data['contact_id'] ) ? intval( $get_data['contact_id'] ) : 0;
		if ( ! empty( $contact_id ) && class_exists( 'WooFunnels_Contact' ) ) {
			$contact = new WooFunnels_Contact( '', '', '', $contact_id );
			if ( ! $contact instanceof WooFunnels_Contact || empty( $contact->get_id() ) ) {
				$wp_id = $contact->get_wpid();
				if ( ! empty( $wp_id ) ) {
					$member = \Awesomemotive\Rewardswp\Helpers\get_member_by( 'user_id', $wp_id );
					if ( $member ) {
						return $member;
					}
				}

				/** Try contact email as last resort */
				$contact_email = $contact->get_email();
				if ( ! empty( $contact_email ) && is_email( $contact_email ) ) {
					$member = \Awesomemotive\Rewardswp\Helpers\get_member_by( 'email', $contact_email );
					if ( $member ) {
						return $member;
					}
				}
			}
		}

		return null;
	}
}

/**
 * FunnelKit stripe payment gateway
 */
if ( ! function_exists( 'bwfan_is_fk_stripe_active' ) ) {
	function bwfan_is_fk_stripe_active() {
		return BWFAN_PRO_Plugin_Dependency::bwfan_is_fk_stripe_active();
	}
}

/**
 * FunnelKit stripe payment gateway
 */
if ( ! function_exists( 'bwfan_is_funnel_builder_pro_active' ) ) {
	function bwfan_is_funnel_builder_pro_active() {
		return BWFAN_PRO_Plugin_Dependency::bwfan_is_funnel_builder_pro_active();
	}
}

/**
 * Sublium plugin Detection
 */
if ( ! function_exists( 'bwfan_is_sublium_active' ) ) {
	function bwfan_is_sublium_active() {
		return BWFAN_PRO_Plugin_Dependency::sublium_active_check();
	}
}

/**
 * Sublium Pro plugin Detection
 */
if ( ! function_exists( 'bwfan_is_sublium_pro_active' ) ) {
	function bwfan_is_sublium_pro_active() {
		return BWFAN_PRO_Plugin_Dependency::sublium_pro_active_check();
	}
}
