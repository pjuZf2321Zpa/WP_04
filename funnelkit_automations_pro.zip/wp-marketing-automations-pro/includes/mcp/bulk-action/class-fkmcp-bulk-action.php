<?php

defined( 'ABSPATH' ) || exit;

/**
 * Bulk contact changes over MCP (start-bulk-action, get-bulk-action,
 * update-bulk-action, list-bulk-actions), run by the admin Bulk Actions engine
 * (BWFCRM_Bulk_Action_Handler): the call starts a run and returns; the engine works
 * through the contacts in the background, 20 per batch, and the AI checks back.
 *
 * Narrow on purpose:
 * - Tags, lists, subscribe, unsubscribe and field values. The engine also deletes,
 *   ends automations and adds to automations; none of that is reachable from here.
 * - Subscribe is the engine's resubscribe(): it removes opt-outs for any status, so
 *   the review counts the Unsubscribed, Bounced and Complaint contacts it would undo.
 * - Fields: never email, status (a second way to (un)subscribe), phone or the system
 *   columns, and never an empty value (the engine skips it, so nothing would change).
 * - Automations never run (enable_automation_run false): a tag added in bulk would
 *   otherwise start "Tag added" automations, and their emails, for every contact.
 * - Review then confirm, with the contact count bound to the token, and one AI run
 *   at a time per user. update-bulk-action changes only runs started from here.
 */
class FKMCP_Bulk_Action {
	const MAX_IDS = 1000;

	const MAX_TERMS = 50;

	const LIST_MAX = 20;

	/** No progress for this long while running reads as stalled. */
	const STALL_SECONDS = 120;

	/** The engine's run lock expiry (bwfcrm_bulk_action_running_timeout default). */
	const LOCK_SECONDS = 300;

	/** The confirm refuses when the count moved more than this share since review. */
	const DRIFT = 0.1;

	/** Input op => [engine action slug, term type, created key]. */
	const ACTIONS = array(
		'add_tags'     => array( 'add_tags', 'tag', 'tags' ),
		'remove_tags'  => array( 'remove_tags', 'tag', 'tags' ),
		'add_lists'    => array( 'add_to_lists', 'list', 'lists' ),
		'remove_lists' => array( 'remove_lists', 'list', 'lists' ),
	);

	const TARGETS = array( 'contact_ids', 'audience_id', 'filters' );

	const START_KEYS = array( 'contact_ids', 'audience_id', 'filters', 'add_tags', 'remove_tags', 'add_lists', 'remove_lists', 'subscribe', 'unsubscribe', 'update_fields', 'create_missing', 'title', 'mode', 'review_token', 'reviewed_total', 'confirmed' );

	const MAX_FIELDS = 20;

	/** Contact columns update_fields never sets in bulk: identity, opt-in state, phone, system data. */
	const NEVER_FIELDS = array( 'email', 'status', 'contact_no', 'wp_id', 'points', 'source', 'creation_date', 'disable_events' );

	/** Built-in columns update_fields may set; everything else must resolve to a custom field id. */
	const COLUMN_FIELDS = array( 'f_name', 'l_name', 'country', 'state', 'timezone' );

	/** Statuses whose opt-out subscribe removes, counted at review: status filter value => output key. */
	const OPTED_OUT = array(
		'3' => 'unsubscribed',
		'2' => 'bounced',
		'4' => 'soft_bounced',
		'5' => 'complaint',
	);

	/** bwfan_bulk_action.status. */
	const STATUS = array(
		0 => 'draft',
		1 => 'running',
		2 => 'done',
		3 => 'stopped',
	);

	/**
	 * The engine and its table, as a map so a self-check can replace them.
	 *
	 * now(): int; count( array $target ): int - contacts the run would reach;
	 * audience( int $id ): array|null - saved conditions, null when no such audience;
	 * insert( array $row ): int; get( int $id ): array|null - row with actions and meta decoded;
	 * list( int $limit, int $status ): array - newest first, status 0 for any;
	 * set_status( int $id, int $status ): bool; schedule( int $id ); resume( int $id ); unschedule( int $id );
	 * log_counts( string $file ): array{applied: int, skipped: int, failed: int}|null;
	 * running( int $uid, int $except ): int - this user's running AI run, 0 for none;
	 * lock( int $uid ): bool - false while another start of this user holds it; unlock( int $uid ).
	 *
	 * @var array<string, callable>
	 */
	public static $store = array(
		'now'        => array( __CLASS__, 'store_now' ),
		'count'      => array( __CLASS__, 'store_count' ),
		'audience'   => array( __CLASS__, 'store_audience' ),
		'insert'     => array( __CLASS__, 'store_insert' ),
		'get'        => array( __CLASS__, 'store_get' ),
		'list'       => array( __CLASS__, 'store_list' ),
		'set_status' => array( __CLASS__, 'store_set_status' ),
		'schedule'   => array( __CLASS__, 'store_schedule' ),
		'resume'     => array( __CLASS__, 'store_resume' ),
		'unschedule' => array( __CLASS__, 'store_unschedule' ),
		'log_counts' => array( __CLASS__, 'store_log_counts' ),
		'running'    => array( __CLASS__, 'store_running' ),
		'lock'       => array( __CLASS__, 'store_lock' ),
		'unlock'     => array( __CLASS__, 'store_unlock' ),
	);

	/**
	 * start-bulk-action: mode "review" checks and counts, writes nothing; the confirm
	 * (review_token + reviewed_total + confirmed) creates the run and schedules it.
	 *
	 * @param array    $input
	 * @param callable $terms   fn( array $items, string $type, bool $create ): array<{id, value}>|WP_Error.
	 * @param callable      $filters fn( mixed $filters ): array|WP_Error - the filter-contacts check.
	 * @param callable|null $fields  fn( array $fields ): array|WP_Error - field names to ids, choice values checked.
	 *
	 * @return array|WP_Error
	 */
	public static function start( array $input, callable $terms, callable $filters, $fields = null ) {
		$input   = self::normalised( $input );
		$unknown = array_diff( array_keys( $input ), self::START_KEYS );
		if ( $unknown ) {
			/* translators: %s: input keys */
			return self::invalid( sprintf( __( 'Not an input of this tool: %s. Tags, lists, subscribe, unsubscribe and update_fields can be changed in bulk here, and automations never run.', 'wp-marketing-automations-pro' ), implode( ', ', $unknown ) ) );
		}

		$ops = array_intersect_key( $input, self::ACTIONS );
		$ops = array_filter( $ops, function ( $items ) {
			return array() !== $items && null !== $items;
		} );
		$sub   = ! empty( $input['subscribe'] ); // real bools by now: "false" was normalised
		$unsub = ! empty( $input['unsubscribe'] );
		if ( array() === $ops && ! $sub && ! $unsub && ! isset( $input['update_fields'] ) ) {
			return self::invalid( __( 'Pass at least one of add_tags, remove_tags, add_lists, remove_lists, subscribe, unsubscribe, update_fields.', 'wp-marketing-automations-pro' ) );
		}
		if ( $sub && $unsub ) {
			return self::invalid( __( 'subscribe and unsubscribe cannot both be true in one run. Pick one.', 'wp-marketing-automations-pro' ) );
		}
		foreach ( $ops as $op => $items ) {
			if ( ! is_array( $items ) || count( $items ) > self::MAX_TERMS ) {
				/* translators: 1: input key, 2: maximum */
				return self::invalid( sprintf( __( '%1$s must be a list of at most %2$d tag or list names or ids.', 'wp-marketing-automations-pro' ), $op, self::MAX_TERMS ) );
			}
		}

		$set = self::fields_plan( $input, $fields );
		if ( is_wp_error( $set ) ) {
			return $set;
		}

		$target = self::target( $input, $filters );
		if ( is_wp_error( $target ) ) {
			return $target;
		}

		$running = self::running_for( get_current_user_id() );
		if ( $running > 0 ) {
			return self::busy( $running );
		}

		$create = ! empty( $input['create_missing'] ); // a real bool by now: "false" was normalised
		$plan   = self::plan( $ops, $terms, $create, false );
		if ( is_wp_error( $plan ) ) {
			return $plan;
		}

		$total = (int) call_user_func( self::$store['count'], $target['query'] );
		if ( $total < 1 ) {
			return self::invalid( __( 'The target matches no contact, so nothing would change. Check it with filter-contacts count_only.', 'wp-marketing-automations-pro' ) );
		}

		$changes = array( 'subscribe' => $sub, 'unsubscribe' => $unsub, 'update_fields' => $set['engine'] );
		$hash    = hash( 'sha256', (string) wp_json_encode( array( $target['query'], $plan['names'], $create, $changes ) ) );

		if ( isset( $input['mode'] ) && 'review' === $input['mode'] ) {
			$issued   = FKMCP_Review::issue( $hash, array( 'bulk' ), 0, 'bulk:' . $total );
			$warnings = array( __( 'Automations do not run for these changes: no automation starts (Tag added, Added to list, Contact subscribed or unsubscribed, Field updated), and no automation email is sent.', 'wp-marketing-automations-pro' ) );
			$opted    = $sub ? self::opted_out( $target['query'] ) : array();
			if ( $opted ) {
				$names = array( 'unsubscribed' => __( 'Unsubscribed', 'wp-marketing-automations-pro' ), 'bounced' => __( 'Bounced', 'wp-marketing-automations-pro' ), 'soft_bounced' => __( 'Soft Bounced', 'wp-marketing-automations-pro' ), 'complaint' => __( 'Complaint', 'wp-marketing-automations-pro' ) );
				$parts = array();
				foreach ( $opted as $key => $n ) {
					$parts[] = $n . ' ' . $names[ $key ];
				}
				/* translators: %s: counts per status, e.g. "12 Unsubscribed, 3 Complaint" */
				$warnings[] = sprintf( __( 'Subscribe removes opt-outs: %s contact(s) become Subscribed and will get marketing emails again. They asked not to be mailed, or their address bounced or reported spam; mailing them again can break consent rules and hurt sending reputation. Show these numbers to the user before the yes.', 'wp-marketing-automations-pro' ), implode( ', ', $parts ) );
			}
			if ( $unsub ) {
				$warnings[] = __( 'Unsubscribed contacts stop getting marketing emails. Only a subscribe of the same contacts undoes it.', 'wp-marketing-automations-pro' );
			}
			if ( $set['engine'] ) {
				$warnings[] = __( 'The new field values replace what each contact has now; the old values are not kept.', 'wp-marketing-automations-pro' );
			}
			if ( isset( $target['query']['contact_ids'] ) && $total < count( $target['query']['contact_ids'] ) ) {
				$missing    = count( $target['query']['contact_ids'] ) - $total;
				/* translators: 1: ids that are not contacts, 2: ids given */
				$warnings[] = sprintf( __( '%1$d of the %2$d ids are not contacts and are skipped.', 'wp-marketing-automations-pro' ), $missing, count( $target['query']['contact_ids'] ) );
			}

			return array(
				'result'          => 'review',
				'total'           => $total,
				'target'          => $target['summary'],
				'actions'         => $plan['names'],
				'subscribe'       => $sub,
				'unsubscribe'     => $unsub,
				'update_fields'   => $set['shown'],
				'status_now'      => $sub ? $opted : null,
				'to_create'       => $plan['to_create'],
				'automations_run' => false,
				'warnings'        => $warnings,
				'review_token'    => $issued['token'],
				'reviewed_total'  => $total,
				'expires'         => $issued['expires'],
			);
		}

		if ( empty( $input['review_token'] ) ) {
			return new WP_Error( 'fkmcp_review_required', __( 'Review first: call with mode "review", show the user the count, the target and the tags and lists, and after their yes send the same input with review_token, reviewed_total and confirmed: true.', 'wp-marketing-automations-pro' ) );
		}

		$reviewed = isset( $input['reviewed_total'] ) && is_numeric( $input['reviewed_total'] ) ? (int) $input['reviewed_total'] : -1;
		$check    = FKMCP_Review::check( $input['review_token'], $hash, ! empty( $input['confirmed'] ) ? array( 'bulk' ) : array(), 0, 'bulk:' . $reviewed );
		if ( is_wp_error( $check ) ) {
			return 'fkmcp_review_required' === $check->get_error_code()
				? new WP_Error( 'fkmcp_review_required', __( 'Send confirmed: true once the user said yes to the review.', 'wp-marketing-automations-pro' ) )
				: new WP_Error( 'fkmcp_review_stale', __( 'The review no longer matches: the target, the tags or lists, or reviewed_total differ from the reviewed ones, or the token expired or was used. Run mode "review" again.', 'wp-marketing-automations-pro' ) );
		}

		// Two starts at the same moment (clients can call tools in parallel) both pass the
		// one-run check above; the lock lets one through, and the check runs again inside it.
		$uid = get_current_user_id();
		if ( ! call_user_func( self::$store['lock'], $uid ) ) {
			return new WP_Error( 'fkmcp_bulk_running', __( 'Another bulk action of yours is being started right now; one runs at a time. Check list-bulk-actions in a few seconds.', 'wp-marketing-automations-pro' ) );
		}

		try {
			return self::begin( $input, $ops, $terms, $create, $plan, $target, $total, $reviewed, $changes, $set['shown'] );
		} finally {
			call_user_func( self::$store['unlock'], $uid );
		}
	}

	/** The confirm's writes, inside the per-user lock. */
	private static function begin( array $input, array $ops, callable $terms, $create, array $plan, array $target, $total, $reviewed, array $changes, array $shown ) {
		$running = self::running_for( get_current_user_id() );
		if ( $running > 0 ) {
			return self::busy( $running );
		}

		if ( abs( $total - $reviewed ) > max( 1, (int) ceil( $reviewed * self::DRIFT ) ) ) {
			/* translators: 1: contacts at review, 2: contacts now */
			return new WP_Error( 'fkmcp_review_stale', sprintf( __( 'The target matched %1$d contacts at review and matches %2$d now. Run mode "review" again and show the user the new count.', 'wp-marketing-automations-pro' ), $reviewed, $total ) );
		}

		if ( ! FKMCP_Review::consume( $input['review_token'] ) ) {
			return new WP_Error( 'fkmcp_review_stale', __( 'This review was already used. Run mode "review" again.', 'wp-marketing-automations-pro' ) );
		}

		$made = $create && ( $plan['to_create']['tags'] || $plan['to_create']['lists'] ) ? self::plan( $ops, $terms, true, true ) : $plan;
		if ( is_wp_error( $made ) ) {
			return $made;
		}

		$meta = array(
			'enable_automation_run' => false,
			'source'                => 'mcp',
		);
		if ( isset( $target['query']['contact_ids'] ) ) {
			$meta['include_ids'] = $target['query']['contact_ids'];
		} else {
			$meta['contactFilters'] = $target['query']['filters'];
		}

		$title = isset( $input['title'] ) && is_string( $input['title'] ) ? trim( sanitize_text_field( $input['title'] ) ) : '';
		$now   = (int) call_user_func( self::$store['now'] );

		// The engine runs the actions in this order; each data is an array (it adds its own keys to some).
		$actions = $made['engine'];
		if ( $changes['subscribe'] ) {
			$actions['subscribe_contacts'] = array();
		}
		if ( $changes['unsubscribe'] ) {
			$actions['unsubscribe_contacts'] = array();
		}
		if ( $changes['update_fields'] ) {
			$actions['update_fields'] = $changes['update_fields'];
		}

		$id = (int) call_user_func(
			self::$store['insert'],
			array(
				/* translators: %s: date and time, UTC */
				'title'      => '' !== $title ? mb_substr( $title, 0, 200 ) : sprintf( __( 'AI bulk change (%s)', 'wp-marketing-automations-pro' ), gmdate( 'Y-m-d H:i:s', $now ) ),
				'status'     => 1,
				'count'      => $total,
				'created_by' => get_current_user_id(),
				'created_at' => gmdate( 'Y-m-d H:i:s', $now ),
				'updated_at' => gmdate( 'Y-m-d H:i:s', $now ),
				'actions'    => $actions,
				'meta'       => $meta,
			)
		);

		if ( $id < 1 ) {
			return new WP_Error( 'fkmcp_create_failed', __( 'The bulk action could not be saved, so nothing changed. Try again; if it fails again, use Contacts > Bulk Actions in the admin.', 'wp-marketing-automations-pro' ) );
		}

		call_user_func( self::$store['schedule'], $id );
		self::log( sprintf( 'BULK_STARTED id=%d total=%d ops=%s', $id, $total, implode( ',', array_keys( $actions ) ) ) );

		return array(
			'result'              => 'started',
			'bulk_action_id'      => $id,
			'status'              => 'running',
			'total'               => $total,
			'actions'             => $made['names'],
			'subscribe'           => $changes['subscribe'],
			'unsubscribe'         => $changes['unsubscribe'],
			'update_fields'       => $shown,
			'created'             => $made['created'],
			'check_after_seconds' => self::check_after( null, $total ),
			'admin_url'           => self::admin_url(),
			'next'                => array( self::next_get( $id ) ),
		);
	}

	/**
	 * get-bulk-action. Reads only.
	 *
	 * @param array $input bulk_action_id.
	 *
	 * @return array|WP_Error
	 */
	public static function get( array $input ) {
		$row = self::row( $input );

		return is_wp_error( $row ) ? $row : self::describe( $row, true );
	}

	/**
	 * update-bulk-action: stop, or resume a stopped or stalled run. Runs started from MCP only.
	 *
	 * @param array $input bulk_action_id, action.
	 *
	 * @return array|WP_Error
	 */
	public static function update( array $input ) {
		$action = isset( $input['action'] ) ? $input['action'] : '';
		if ( ! in_array( $action, array( 'stop', 'resume' ), true ) ) {
			return self::invalid( __( 'action must be stop or resume.', 'wp-marketing-automations-pro' ) );
		}

		$row = self::row( $input );
		if ( is_wp_error( $row ) ) {
			return $row;
		}

		$id = (int) $row['ID'];
		if ( ! self::from_mcp( $row ) ) {
			return new WP_Error( 'fkmcp_forbidden', __( 'This bulk action was made in the admin, so it is changed there: Contacts > Bulk Actions.', 'wp-marketing-automations-pro' ) );
		}

		$status = (int) $row['status'];
		if ( 2 === $status ) {
			return self::invalid( __( 'This bulk action has finished; there is nothing to stop or resume. Start a new one to change more contacts.', 'wp-marketing-automations-pro' ) );
		}

		if ( 'stop' === $action ) {
			if ( 1 !== $status ) {
				return self::invalid( __( 'This bulk action is not running.', 'wp-marketing-automations-pro' ) );
			}
			call_user_func( self::$store['set_status'], $id, 3 );
			call_user_func( self::$store['unschedule'], $id );
			self::log( sprintf( 'BULK_STOPPED id=%d', $id ) );

			return array( 'result' => 'updated', 'next' => array() ) + self::describe( self::fresh( $row, 3 ), false );
		}

		if ( 1 === $status && ! self::stalled( $row ) ) {
			return self::invalid( __( 'This bulk action is moving; resume is only for a stopped or stalled run. Check it again with get-bulk-action.', 'wp-marketing-automations-pro' ) );
		}

		$other = self::running_for( get_current_user_id(), $id );
		if ( $other > 0 ) {
			return self::busy( $other );
		}

		if ( 3 === $status || 0 === $status ) {
			call_user_func( self::$store['set_status'], $id, 1 );
		}
		call_user_func( self::$store['resume'], $id );
		self::log( sprintf( 'BULK_RESUMED id=%d', $id ) );

		$fresh = call_user_func( self::$store['get'], $id );

		return array( 'result' => 'updated', 'next' => array( self::next_get( $id ) ) ) + self::describe( is_array( $fresh ) ? $fresh : self::fresh( $row, 1 ), false );
	}

	/**
	 * list-bulk-actions. Reads only.
	 *
	 * @param array $input status?, limit?.
	 *
	 * @return array|WP_Error
	 */
	public static function all( array $input ) {
		$limit  = isset( $input['limit'] ) && is_numeric( $input['limit'] ) ? max( 1, min( self::LIST_MAX, (int) $input['limit'] ) ) : self::LIST_MAX;
		$status = 0;
		if ( ! empty( $input['status'] ) ) {
			$status = (int) array_search( $input['status'], self::STATUS, true );
			if ( $status < 1 ) {
				return self::invalid( __( 'status must be running, done or stopped.', 'wp-marketing-automations-pro' ) );
			}
		}

		$items = array();
		foreach ( (array) call_user_func( self::$store['list'], $limit, $status ) as $row ) {
			$items[] = self::describe( $row, false );
		}

		return array(
			'items'     => $items,
			'admin_url' => self::admin_url(),
		);
	}

	/** @return array{query: array, summary: array}|WP_Error */
	private static function target( array $input, callable $filters ) {
		$given = array_values( array_filter( self::TARGETS, function ( $key ) use ( $input ) {
			return isset( $input[ $key ] );
		} ) );

		if ( 1 !== count( $given ) ) {
			return self::invalid( __( 'Pass exactly one target: contact_ids, audience_id or filters.', 'wp-marketing-automations-pro' ) );
		}

		if ( 'contact_ids' === $given[0] ) {
			$ids = $input['contact_ids'];
			if ( ! is_array( $ids ) || array() === $ids ) {
				return self::invalid( __( 'contact_ids must list at least one contact id.', 'wp-marketing-automations-pro' ) );
			}
			foreach ( $ids as $id ) {
				if ( ! ( is_int( $id ) || ( is_string( $id ) && ctype_digit( $id ) ) ) || (int) $id < 1 ) {
					return self::invalid( __( 'contact_ids must be positive integers (contact ids from list-contacts or filter-contacts).', 'wp-marketing-automations-pro' ) );
				}
			}
			$ids = array_values( array_unique( array_map( 'intval', $ids ) ) );
			if ( count( $ids ) > self::MAX_IDS ) {
				/* translators: %d: maximum */
				return self::invalid( sprintf( __( 'contact_ids takes at most %d ids. For more, pass filters or audience_id.', 'wp-marketing-automations-pro' ), self::MAX_IDS ) );
			}

			return array(
				'query'   => array( 'contact_ids' => $ids ),
				'summary' => array( 'type' => 'contact_ids', 'ids' => count( $ids ) ),
			);
		}

		if ( 'audience_id' === $given[0] ) {
			$aid = $input['audience_id'];
			if ( ! ( is_int( $aid ) || ( is_string( $aid ) && ctype_digit( $aid ) ) ) || (int) $aid < 1 ) {
				return self::invalid( __( 'audience_id must be a positive integer. Call list-audiences for valid ids.', 'wp-marketing-automations-pro' ) );
			}
			$saved = call_user_func( self::$store['audience'], (int) $aid );
			if ( null === $saved ) {
				return new WP_Error( 'fkmcp_not_found', __( 'No saved audience with that id. Call list-audiences for valid ids.', 'wp-marketing-automations-pro' ) );
			}
			if ( ! is_array( $saved ) || array() === $saved ) {
				return self::invalid( __( 'This saved audience has no conditions, so it would be every contact. Pass filters instead.', 'wp-marketing-automations-pro' ) );
			}

			return array(
				'query'   => array( 'filters' => $saved ),
				'summary' => array( 'type' => 'audience', 'audience_id' => (int) $aid ),
			);
		}

		if ( ! is_array( $input['filters'] ) || array() === $input['filters'] ) {
			return self::invalid( __( 'filters needs at least one group with one condition (as filter-contacts takes them).', 'wp-marketing-automations-pro' ) );
		}
		$clean = call_user_func( $filters, $input['filters'] );
		if ( is_wp_error( $clean ) ) {
			return $clean;
		}
		if ( ! is_array( $clean ) || array() === $clean ) {
			return self::invalid( __( 'filters needs at least one group with one condition (as filter-contacts takes them).', 'wp-marketing-automations-pro' ) );
		}

		// Stored as the admin wizard stores them ([{key, label}] for a Search filter): the Bulk Actions screen reads names from there.
		$errors = new FKMCP_Definition_Errors();
		$clean  = FKMCP_Broadcast_Audience::validate_for_bulk( array_values( array_map( 'array_values', $clean ) ), 'filters', $errors );
		if ( null === $clean ) {
			$error = $errors->to_wp_error();

			return new WP_Error( 'fkmcp_invalid_input', $error->get_error_message(), $error->get_error_data() );
		}

		return array(
			'query'   => array( 'filters' => array_values( $clean ) ),
			'summary' => array( 'type' => 'filters', 'groups' => count( $clean ) ),
		);
	}


	/**
	 * Terms per op, resolved without creating anything. With $create, unknown names to add
	 * are listed in to_create; with $make as well they are created now. Names to remove are
	 * never created, and a number is never coined as a name.
	 *
	 * @return array{engine: array, names: array, to_create: array, created: array}|WP_Error
	 */
	private static function plan( array $ops, callable $terms, $create, $make ) {
		$plan = array(
			'engine'    => array(),
			'names'     => array(),
			'to_create' => array( 'tags' => array(), 'lists' => array() ),
			'created'   => array( 'tags' => array(), 'lists' => array() ),
		);
		$seen = array();

		foreach ( self::ACTIONS as $op => $spec ) {
			if ( ! isset( $ops[ $op ] ) ) {
				continue;
			}
			list( $slug, $type, $key ) = $spec;
			$items  = array_values( $ops[ $op ] );
			$adding = 0 === strpos( $op, 'add_' );
			$pairs  = call_user_func( $terms, $items, $type, false );
			$coin   = array();

			if ( is_wp_error( $pairs ) && $create && $adding && 'fkmcp_unknown_term' === $pairs->get_error_code() ) {
				$data    = (array) $pairs->get_error_data();
				$unknown = isset( $data['unknown'] ) ? array_values( (array) $data['unknown'] ) : array();
				if ( $unknown && ! array_filter( $unknown, 'is_numeric' ) ) {
					$coin  = array_map( 'strval', $unknown );
					$known = array_values( array_filter( $items, function ( $item ) use ( $unknown ) {
						return ! in_array( $item, $unknown, true );
					} ) );
					$pairs = $make ? call_user_func( $terms, $items, $type, true ) : ( $known ? call_user_func( $terms, $known, $type, false ) : array() );
				}
			}

			if ( is_wp_error( $pairs ) ) {
				return $pairs;
			}

			foreach ( $pairs as $pair ) {
				$mark = $type . ':' . (int) $pair['id'];
				if ( isset( $seen[ $mark ] ) && $seen[ $mark ] !== $adding ) {
					/* translators: %s: tag or list name */
					return self::invalid( sprintf( __( '"%s" is both added and removed. Keep it in one of the two.', 'wp-marketing-automations-pro' ), $pair['value'] ) );
				}
				$seen[ $mark ] = $adding;
			}

			$plan['engine'][ $slug ] = array_values( array_map( function ( $pair ) {
				return array( 'id' => (int) $pair['id'], 'value' => (string) $pair['value'] );
			}, $pairs ) );

			// What the AI is shown: term names are stored text, and coined ones come from the call.
			$shown                = array_map( array( 'FKMCP_Definition_Errors', 'untrust' ), $coin );
			$names                = array_map( array( 'FKMCP_Definition_Errors', 'untrust' ), array_column( $plan['engine'][ $slug ], 'value' ) );
			$plan['names'][ $op ] = $make ? $names : array_merge( $names, $shown );

			if ( $coin ) {
				$plan[ $make ? 'created' : 'to_create' ][ $key ] = array_merge( $plan[ $make ? 'created' : 'to_create' ][ $key ], $shown );
			}
		}

		return $plan;
	}

	/**
	 * update_fields checked and resolved: engine is {field id or column: value} as the admin
	 * wizard stores it; shown is {the name the AI gave: stored value} for the review.
	 *
	 * @return array{engine: array, shown: array}|WP_Error
	 */
	private static function fields_plan( array $input, $fields ) {
		if ( ! isset( $input['update_fields'] ) ) {
			return array( 'engine' => array(), 'shown' => array() );
		}

		$given = $input['update_fields'];
		if ( ! is_array( $given ) || array() === $given || array_keys( $given ) === range( 0, count( $given ) - 1 ) ) {
			return self::invalid( __( 'update_fields must be an object {field: value}: custom fields by name or slug, or f_name, l_name, country, state, timezone.', 'wp-marketing-automations-pro' ) );
		}
		if ( count( $given ) > self::MAX_FIELDS ) {
			/* translators: %d: maximum */
			return self::invalid( sprintf( __( 'update_fields takes at most %d fields in one run.', 'wp-marketing-automations-pro' ), self::MAX_FIELDS ) );
		}

		// Cleaned as apply_field cleans a single contact's values: merge tags print a field
		// unescaped into emails, and the review must show what is stored. Line breaks stay.
		foreach ( $given as $key => $value ) {
			$given[ $key ] = is_array( $value ) ? array_map( array( __CLASS__, 'clean_value' ), $value ) : self::clean_value( $value );
		}

		foreach ( $given as $key => $value ) {
			$slug = strtolower( trim( (string) $key ) );
			if ( in_array( $slug, self::NEVER_FIELDS, true ) ) {
				/* translators: %s: column name */
				return self::invalid( sprintf( __( '%s cannot be set in bulk here. Email, status (use subscribe or unsubscribe), phone and the system columns are changed per contact or in the admin.', 'wp-marketing-automations-pro' ), $slug ) );
			}
			$values = is_array( $value ) ? $value : array( $value );
			$empty  = array() === $values;
			foreach ( $values as $one ) {
				$empty = $empty || ! is_scalar( $one ) || '' === trim( (string) $one );
			}
			if ( $empty ) {
				/* translators: %s: field name */
				return self::invalid( sprintf( __( 'update_fields.%s has no value. A field cannot be emptied in bulk: the engine skips an empty value, so nothing would change.', 'wp-marketing-automations-pro' ), $key ) );
			}
		}

		if ( ! is_callable( $fields ) ) {
			return self::invalid( __( 'update_fields is not available on this site.', 'wp-marketing-automations-pro' ) );
		}
		$resolved = call_user_func( $fields, $given );
		if ( is_wp_error( $resolved ) ) {
			return $resolved;
		}
		if ( ! is_array( $resolved ) || count( $resolved ) !== count( $given ) ) {
			return self::invalid( __( 'update_fields names the same field twice. Send each field once.', 'wp-marketing-automations-pro' ) );
		}
		foreach ( array_keys( $resolved ) as $key ) {
			if ( ! is_int( $key ) && ! in_array( $key, self::COLUMN_FIELDS, true ) ) {
				/* translators: %s: column name */
				return self::invalid( sprintf( __( '%s cannot be set in bulk here.', 'wp-marketing-automations-pro' ), $key ) );
			}
		}

		$shown = array();
		foreach ( array_combine( array_keys( $given ), array_values( $resolved ) ) as $name => $value ) {
			$shown[ FKMCP_Definition_Errors::untrust( (string) $name ) ] = FKMCP_Definition_Errors::untrust( $value );
		}

		return array( 'engine' => $resolved, 'shown' => $shown );
	}

	/** A field value without markup; numbers as given, anything else unchanged for the empty check to refuse. */
	private static function clean_value( $value ) {
		return is_string( $value ) ? sanitize_textarea_field( $value ) : $value;
	}

	/**
	 * Contacts in the target per opted-out status (only those with any), for the
	 * subscribe review: one count each, the target with one status condition added.
	 *
	 * @return array<string, int>
	 */
	private static function opted_out( array $query ) {
		$out = array();
		foreach ( self::OPTED_OUT as $status => $key ) {
			$cond = array( 'filter' => 'status', 'rule' => 'is', 'data' => (string) $status );
			$q    = $query;
			if ( isset( $q['contact_ids'] ) ) {
				$q['filters'] = array( array( $cond ) );
			} else {
				foreach ( $q['filters'] as $g => $group ) {
					$q['filters'][ $g ][] = $cond;
				}
			}
			$n = (int) call_user_func( self::$store['count'], $q );
			if ( $n > 0 ) {
				$out[ $key ] = $n;
			}
		}

		return $out;
	}

	/** The id of this user's running AI run, other than $except, or 0. */
	private static function running_for( $uid, $except = 0 ) {
		return (int) call_user_func( self::$store['running'], (int) $uid, (int) $except );
	}

	/**
	 * Input as clients send it: core's schema check accepts "true" / "false" / "1" / "0" for a
	 * boolean and "a,b" or one value for a list, then passes the raw value on.
	 */
	private static function normalised( array $input ) {
		foreach ( array( 'create_missing', 'confirmed', 'subscribe', 'unsubscribe' ) as $key ) {
			if ( isset( $input[ $key ] ) && ! is_bool( $input[ $key ] ) ) {
				$input[ $key ] = is_string( $input[ $key ] ) ? ! in_array( strtolower( trim( $input[ $key ] ) ), array( 'false', '0', '' ), true ) : (bool) $input[ $key ];
			}
		}

		// Names split on commas only: "Black Friday" is one tag.
		foreach ( array_keys( self::ACTIONS ) as $op ) {
			if ( isset( $input[ $op ] ) && is_scalar( $input[ $op ] ) ) {
				$input[ $op ] = is_string( $input[ $op ] ) ? array_values( array_filter( array_map( 'trim', explode( ',', $input[ $op ] ) ), 'strlen' ) ) : array( $input[ $op ] );
			}
		}

		if ( isset( $input['contact_ids'] ) && is_scalar( $input['contact_ids'] ) ) {
			$input['contact_ids'] = is_string( $input['contact_ids'] ) ? array_values( array_filter( preg_split( '/[\s,]+/', $input['contact_ids'] ), 'strlen' ) ) : array( $input['contact_ids'] );
		}

		return $input;
	}

	private static function busy( $id ) {
		/* translators: %d: bulk action id */
		return new WP_Error( 'fkmcp_bulk_running', sprintf( __( 'Bulk action %d you started is still running; one runs at a time. Check it with get-bulk-action, or stop it with update-bulk-action, then start this one.', 'wp-marketing-automations-pro' ), $id ) );
	}

	/** @return array|WP_Error */
	private static function row( array $input ) {
		$id = isset( $input['bulk_action_id'] ) ? $input['bulk_action_id'] : null;
		if ( ! ( is_int( $id ) || ( is_string( $id ) && ctype_digit( $id ) ) ) || (int) $id < 1 ) {
			return self::invalid( __( 'bulk_action_id must be a positive integer, from start-bulk-action or list-bulk-actions.', 'wp-marketing-automations-pro' ) );
		}

		$row = call_user_func( self::$store['get'], (int) $id );
		if ( ! is_array( $row ) || empty( $row['ID'] ) ) {
			return new WP_Error( 'fkmcp_not_found', __( 'No bulk action with that id. Call list-bulk-actions for recent ones.', 'wp-marketing-automations-pro' ) );
		}

		return $row;
	}

	private static function from_mcp( array $row ) {
		return isset( $row['meta']['source'] ) && 'mcp' === $row['meta']['source'];
	}

	private static function stalled( array $row ) {
		if ( 1 !== (int) $row['status'] ) {
			return false;
		}
		$now = (int) call_user_func( self::$store['now'] );

		// A worker holding the engine's run lock is busy, not stuck, until the lock expires.
		if ( ! empty( $row['meta']['is_running'] ) && ! empty( $row['meta']['running_since'] ) && ( $now - (int) $row['meta']['running_since'] ) <= self::LOCK_SECONDS ) {
			return false;
		}

		$updated = isset( $row['updated_at'] ) ? strtotime( $row['updated_at'] . ' UTC' ) : false;

		return false !== $updated && ( $now - $updated ) > self::STALL_SECONDS;
	}

	private static function fresh( array $row, $status ) {
		$row['status']     = $status;
		$row['updated_at'] = gmdate( 'Y-m-d H:i:s', (int) call_user_func( self::$store['now'] ) );

		return $row;
	}

	private static function describe( array $row, $with_outcome ) {
		$status    = (int) $row['status'];
		$total     = max( 0, (int) $row['count'] );
		$processed = max( 0, (int) $row['offset'] );
		$percent   = 2 === $status || 0 === $total ? 100 : (int) min( 100, floor( $processed * 100 / $total ) );
		$stalled   = self::stalled( $row );
		$eta       = null;

		if ( 1 === $status && $processed > 0 && $processed < $total ) {
			$began = strtotime( $row['created_at'] . ' UTC' );
			$last  = strtotime( $row['updated_at'] . ' UTC' );
			if ( false !== $began && false !== $last && $last > $began ) {
				$eta = (int) ceil( ( $total - $processed ) * ( $last - $began ) / $processed );
			}
		}

		$names = array();
		foreach ( self::ACTIONS as $op => $spec ) {
			if ( isset( $row['actions'][ $spec[0] ] ) && is_array( $row['actions'][ $spec[0] ] ) ) {
				$names[ $op ] = array_values( array_map( array( 'FKMCP_Definition_Errors', 'untrust' ), array_column( $row['actions'][ $spec[0] ], 'value' ) ) );
			}
		}

		$out = array(
			'bulk_action_id'      => (int) $row['ID'],
			'title'               => FKMCP_Definition_Errors::untrust( isset( $row['title'] ) ? (string) $row['title'] : '' ),
			'status'              => isset( self::STATUS[ $status ] ) ? self::STATUS[ $status ] : 'draft',
			'percent'             => $percent,
			'processed'           => min( $processed, max( $total, $processed ) ),
			'total'               => $total,
			'actions'             => $names,
			'subscribe'           => isset( $row['actions']['subscribe_contacts'] ),
			'unsubscribe'         => isset( $row['actions']['unsubscribe_contacts'] ),
			'update_fields'       => isset( $row['actions']['update_fields'] ) && is_array( $row['actions']['update_fields'] ) ? array_map( array( 'FKMCP_Definition_Errors', 'untrust' ), $row['actions']['update_fields'] ) : array(),
			'started_by_ai'       => self::from_mcp( $row ),
			'stalled'             => $stalled,
			'eta_seconds'         => $eta,
			'check_after_seconds' => 1 === $status ? self::check_after( $eta, $total ) : null,
			'created_at'          => isset( $row['created_at'] ) ? (string) $row['created_at'] : '',
			'updated_at'          => isset( $row['updated_at'] ) ? (string) $row['updated_at'] : '',
		);

		if ( $with_outcome ) {
			$out['outcome']   = 2 === $status && ! empty( $row['meta']['log_file'] ) ? call_user_func( self::$store['log_counts'], basename( (string) $row['meta']['log_file'] ) ) : null;
			$out['admin_url'] = self::admin_url();
			$out['next']      = $stalled && self::from_mcp( $row ) ? array(
				array(
					'tool' => 'funnelkit-update-bulk-action',
					'why'  => __( 'No progress for over 2 minutes: the background worker has not picked it up. Resume runs a few seconds of it now and schedules the rest again.', 'wp-marketing-automations-pro' ),
					'args' => array( 'bulk_action_id' => (int) $row['ID'], 'action' => 'resume' ),
				),
			) : array();
		}

		return $out;
	}

	/** Half the time left, between 15 seconds and 2 minutes; 30 seconds before any progress is seen. */
	private static function check_after( $eta, $total ) {
		if ( null === $eta ) {
			return $total > 500 ? 60 : 30;
		}

		return (int) max( 15, min( 120, ceil( $eta / 2 ) ) );
	}

	private static function next_get( $id ) {
		return array(
			'tool' => 'funnelkit-get-bulk-action',
			'why'  => __( 'Progress of this run. Tell the user it is running in the background, then check after check_after_seconds; say done only when status is done.', 'wp-marketing-automations-pro' ),
			'args' => array( 'bulk_action_id' => (int) $id ),
		);
	}

	private static function admin_url() {
		return BWFAN_MCP_Links::app( 'autonami', '/bulk-actions' );
	}

	private static function invalid( $message ) {
		return new WP_Error( 'fkmcp_invalid_input', $message );
	}

	private static function log( $line ) {
		if ( class_exists( 'BWFAN_MCP_Log' ) ) {
			BWFAN_MCP_Log::event( $line );
		}
	}

	// ─── The engine, as the admin Bulk Actions screen uses it ───────────

	public static function store_now() {
		return time();
	}

	/** The same contact query the engine pages through (BWFCRM_Bulk_Action_Handler::populate_contacts), counted. */
	public static function store_count( array $target ) {
		if ( ! class_exists( 'BWFCRM_Contact' ) ) {
			return 0;
		}
		if ( class_exists( 'BWFCRM_Load_Filters' ) ) {
			BWFCRM_Load_Filters::maybe_load_filters();
		}

		$info = array( 'only_count' => true, 'grab_totals' => true ); // total_count only comes back with grab_totals
		if ( isset( $target['contact_ids'] ) ) {
			$info['include_ids'] = $target['contact_ids'];
		}
		$res = BWFCRM_Contact::get_contacts( '', 0, 0, isset( $target['filters'] ) ? $target['filters'] : array(), $info, OBJECT, true );

		return is_array( $res ) && isset( $res['total_count'] ) ? (int) $res['total_count'] : 0;
	}

	/** By type as well as id: tags and lists share the terms table. */
	public static function store_audience( $id ) {
		$rows = class_exists( 'BWFAN_Model_Terms' ) ? BWFAN_Model_Terms::get_terms( 3, 0, 1, '', array( (int) $id ) ) : array();
		$row  = is_array( $rows ) && $rows ? reset( $rows ) : null;
		if ( ! is_array( $row ) || ! isset( $row['ID'] ) || (int) $row['ID'] !== (int) $id ) {
			return null;
		}

		$data = BWFAN_PRO_Common::decode_stored_data_column( isset( $row['data'] ) ? $row['data'] : null );

		return is_array( $data ) && ! empty( $data['filters'] ) && is_array( $data['filters'] ) ? $data['filters'] : array();
	}

	/** As BWFCRM_API_Bulk_Actions::create_bulk_action() with only_action: the log file first, then the row. */
	public static function store_insert( array $row ) {
		self::protect_log_dir();

		$file   = 'FKA-Bulk-Action-' . time() . '-' . wp_generate_password( 5, false ) . '-log.csv';
		$handle = fopen( BWFCRM_BULK_ACTION_LOG_DIR . '/' . $file, 'wb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- the engine appends to this file with fopen/fputcsv.
		if ( false === $handle ) {
			return 0;
		}
		fputcsv( $handle, array_merge( array( 'Contact ID' ), array_keys( $row['actions'] ) ), ',', '"', '\\' );
		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose

		$row['meta']['log_file'] = $file;
		$row['actions']          = wp_json_encode( $row['actions'] );
		$row['meta']             = wp_json_encode( $row['meta'] );

		return (int) BWFAN_Model_Bulk_Action::bwfan_create_new_bulk_action( $row );
	}

	public static function store_get( $id ) {
		$row = BWFAN_Model_Bulk_Action::bwfan_get_bulk_action( (int) $id, false );

		return is_array( $row ) && ! empty( $row['ID'] ) ? self::decoded( $row ) : null;
	}

	public static function store_list( $limit, $status ) {
		global $wpdb;
		$table = $wpdb->prefix . 'bwfan_bulk_action';
		$where = $status > 0 ? $wpdb->prepare( ' WHERE `status` = %d', (int) $status ) : '';
		$rows  = $wpdb->get_results( "SELECT * FROM {$table}{$where} ORDER BY `ID` DESC LIMIT " . absint( $limit ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- table name from prefix, where prepared, limit absint.

		return array_map( array( __CLASS__, 'decoded' ), is_array( $rows ) ? $rows : array() );
	}

	public static function store_set_status( $id, $status ) {
		return BWFAN_Model_Bulk_Action::update_bulk_action_data( (int) $id, array( 'status' => (int) $status, 'updated_at' => current_time( 'mysql', 1 ) ) );
	}

	public static function store_schedule( $id ) {
		BWFCRM_Core()->bulk_action->schedule_bulk_action( (int) $id );
	}

	/**
	 * What the admin screen's status poll does for a run that is not being worked on:
	 * schedule it again, and work on it for 5 seconds in this request.
	 *
	 * On its own handler: the shared one keeps an "ended" flag for the whole request, so
	 * after it finished one run it would work through a second without marking it done
	 * or releasing its lock. The engine's lock still keeps a busy worker out.
	 */
	public static function store_resume( $id ) {
		$id = (int) $id;
		self::store_unschedule( $id );
		bwf_schedule_recurring_action( time() + 60, 60, 'bwfcrm_bulk_action_process', array( 'bulk_action_id' => $id ), 'bwfcrm' );

		$handler = new BWFCRM_Bulk_Action_Handler();
		remove_action( 'bwfcrm_bulk_action_process', array( $handler, 'process_bulk_action' ) ); // its constructor hooks it; the shared handler already is
		$handler->process_bulk_action( $id, 5 );
	}

	public static function store_unschedule( $id ) {
		if ( bwf_has_action_scheduled( 'bwfcrm_bulk_action_process', array( 'bulk_action_id' => (int) $id ), 'bwfcrm' ) ) {
			bwf_unschedule_actions( 'bwfcrm_bulk_action_process', array( 'bulk_action_id' => (int) $id ), 'bwfcrm' );
		}
	}

	/**
	 * Per contact from the run's log: failed when any action says no, applied when one says yes,
	 * skipped otherwise. Null when the log is gone or over 5 MB.
	 */
	public static function store_log_counts( $file ) {
		$path = BWFCRM_BULK_ACTION_LOG_DIR . '/' . basename( $file );
		if ( ! is_readable( $path ) && defined( 'BWFCRM_BULK_ACTION_LOG_DIR_BACKUP' ) ) {
			$path = BWFCRM_BULK_ACTION_LOG_DIR_BACKUP . '/' . basename( $file );
		}
		if ( ! is_readable( $path ) || filesize( $path ) > 5 * MB_IN_BYTES ) {
			return null;
		}

		$handle = fopen( $path, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
		if ( false === $handle ) {
			return null;
		}

		$counts = array( 'applied' => 0, 'skipped' => 0, 'failed' => 0 );
		fgetcsv( $handle, 0, ',', '"', '\\' );
		while ( false !== ( $line = fgetcsv( $handle, 0, ',', '"', '\\' ) ) ) { // phpcs:ignore Generic.CodeAnalysis.AssignmentInCondition.FoundInWhileCondition
			$cells = array_slice( (array) $line, 1 );
			if ( array() === $cells ) {
				continue;
			}
			$no  = array_filter( $cells, function ( $c ) {
				return 0 === strpos( (string) $c, 'no' );
			} );
			$yes = in_array( 'yes', $cells, true );
			++$counts[ $no ? 'failed' : ( $yes ? 'applied' : 'skipped' ) ];
		}
		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose

		return $counts;
	}

	public static function store_running( $uid, $except ) {
		global $wpdb;

		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM {$wpdb->prefix}bwfan_bulk_action WHERE `status` = 1 AND created_by = %d AND ID <> %d AND meta LIKE %s ORDER BY ID DESC LIMIT 1", (int) $uid, (int) $except, '%' . $wpdb->esc_like( '"source":"mcp"' ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- live state, never cached.
	}

	/** A MySQL named lock: atomic, per user, and freed by the server if the request dies. */
	public static function store_lock( $uid ) {
		global $wpdb;

		return '1' === (string) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK( %s, 0 )', self::lock_name( $uid ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	public static function store_unlock( $uid ) {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( 'SELECT RELEASE_LOCK( %s )', self::lock_name( $uid ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/** Under MySQL's 64 characters, and per database so two sites on one server do not share it. */
	private static function lock_name( $uid ) {
		global $wpdb;

		return 'fkmcp_bulk_' . substr( md5( DB_NAME . '|' . $wpdb->prefix ), 0, 12 ) . '_' . (int) $uid;
	}

	/** The run logs hold contact ids: no listing, no direct download (the admin serves them through PHP). */
	public static function protect_log_dir() {
		if ( ! defined( 'BWFCRM_BULK_ACTION_LOG_DIR' ) ) {
			return;
		}
		$dir = BWFCRM_BULK_ACTION_LOG_DIR;
		if ( ! file_exists( $dir . '/' ) ) {
			wp_mkdir_p( $dir );
		}
		if ( ! file_exists( $dir . '/.htaccess' ) ) {
			file_put_contents( $dir . '/.htaccess', "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}
		if ( ! file_exists( $dir . '/index.php' ) ) {
			file_put_contents( $dir . '/index.php', "<?php\n// Silence is golden.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}
	}

	/** A table row with actions and meta decoded. */
	public static function decoded( array $row ) {
		foreach ( array( 'actions', 'meta' ) as $col ) {
			$val         = isset( $row[ $col ] ) && is_string( $row[ $col ] ) ? json_decode( $row[ $col ], true ) : ( isset( $row[ $col ] ) ? $row[ $col ] : array() );
			$row[ $col ] = is_array( $val ) ? $val : array();
		}

		return $row;
	}
}
