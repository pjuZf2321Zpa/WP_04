<?php

defined( 'ABSPATH' ) || exit;

/**
 * A broadcast draft made over MCP: the wizard's Information, Contacts and
 * Content steps, written through the broadcast model the wizard itself uses.
 *
 * The model's fourth step schedules or sends. Nothing here can reach it: every
 * write goes through step(), which refuses any step but 1, 2 and 3, and the
 * saved row is read back and must still be an unscheduled draft.
 *
 * Everything is checked before the first write, so a refused call leaves no row.
 *
 * update() changes a draft and nothing else: the row must be a draft when it is read,
 * again just before each step is written, and still when it is read back. Broadcasts have no
 * edit lock. The status is re-read before each write, but a user who schedules in between can
 * have one step land on a scheduled broadcast; the read-back reports it.
 *
 * A transactional broadcast (promotional off) also reaches unsubscribed contacts. The wizard
 * hides that setting unless the site switches it on, and its review step never shows it, so a
 * person checking the draft could not see it. Neither tool makes or keeps one unless
 * transactional_allowed() says the site shows the setting.
 */
class FKMCP_Broadcast_Draft {
	const TITLE_MAX = 255;

	const DESCRIPTION_MAX = 1000;

	const MAX_EXCLUDE = 500;

	/** Transient prefix for client_ref (10 minutes). */
	const REF_PREFIX = 'fkmcp_cb_';

	/** Channel name => the broadcast type the model stores. */
	const CHANNELS = array(
		'email'    => 1,
		'sms'      => 2,
		'whatsapp' => 3,
	);

	const INPUT_KEYS = array( 'title', 'description', 'channel', 'promotional', 'include_unverified', 'include_soft_bounce', 'exclude_contact_ids', 'filters', 'audience_id', 'all_contacts', 'ab_type', 'variants', 'smart_send', 'sender', 'client_ref' );

	/** update(): the create keys less channel (it cannot change) and client_ref (an update repeats safely). */
	const UPDATE_KEYS = array( 'broadcast_id', 'title', 'description', 'promotional', 'include_unverified', 'include_soft_bounce', 'exclude_contact_ids', 'filters', 'audience_id', 'all_contacts', 'ab_type', 'variants', 'smart_send', 'sender' );

	/** Input flag => [ the key the model stores it under, the wizard's default ]. */
	const FLAGS = array(
		'promotional'         => array( 'is_promotional', true ),
		'include_unverified'  => array( 'includeUnverified', false ),
		'include_soft_bounce' => array( 'includeSoftBounce', true ),
	);

	/**
	 * The broadcast model, as a map so a self-check can record every call.
	 *
	 * create( title, description, type, user id ), update( id, step, data ) and delete( id )
	 * return {data, status, message}; get( id ) returns the raw row or null.
	 *
	 * @var array<string, callable>
	 */
	public static $model = array(
		'create' => array( 'BWFAN_Model_Broadcast', 'create_campaign' ),
		'update' => array( 'BWFAN_Model_Broadcast', 'update_campaign' ),
		'delete' => array( 'BWFAN_Model_Broadcast', 'delete_campaign' ),
		'get'    => array( 'BWFAN_Model_Broadcast', 'get' ),
	);

	/**
	 * Whether this site shows the wizard's transactional setting: the same filter the wizard reads.
	 *
	 * @return bool
	 */
	public static function transactional_allowed() {
		return true === apply_filters( 'bwfan_show_broadcast_unsubscribe_field', false );
	}

	/** Said with every transactional draft a tool saves. */
	private static function transactional_warning() {
		return __( 'Transactional: this broadcast also reaches unsubscribed, bounced and complained contacts.', 'wp-marketing-automations-pro' );
	}

	/** @return string[] The warning for smart sending on a channel that cannot tell which variant did better. */
	private static function smart_warnings( $type, $step3 ) {
		$on = 3 === (int) $type && is_array( $step3 ) && isset( $step3['smart_send'] ) && is_array( $step3['smart_send'] ) && ! empty( $step3['smart_send']['enable'] );

		return $on ? array( __( 'WhatsApp has no open tracking, so the winner is arbitrary.', 'wp-marketing-automations-pro' ) ) : array();
	}

	/**
	 * @param array $input The create-broadcast input.
	 *
	 * @return array|WP_Error The summary of the new draft (or of the earlier one a client_ref names).
	 */
	public static function create( array $input ) {
		$errors = new FKMCP_Definition_Errors();

		foreach ( array_diff( array_keys( $input ), self::INPUT_KEYS ) as $key ) {
			$errors->add( (string) $key, __( 'is not an input of this tool. It only makes a draft: status, scheduling and sending are set in the admin. Remove this key.', 'wp-marketing-automations-pro' ) );
		}

		$title       = self::checked_title( isset( $input['title'] ) ? $input['title'] : null, $errors );
		$description = array_key_exists( 'description', $input ) ? self::checked_description( $input['description'], $errors ) : '';

		$channel = array_key_exists( 'channel', $input ) ? $input['channel'] : 'email';
		$type    = is_string( $channel ) && isset( self::CHANNELS[ $channel ] ) ? self::CHANNELS[ $channel ] : 0;
		if ( 0 === $type ) {
			$errors->add( 'channel', __( 'must be email, sms or whatsapp. Leave it out for email.', 'wp-marketing-automations-pro' ), array_keys( self::CHANNELS ) );
		}

		$flags   = self::checked_flags( $input, array_combine( array_keys( self::FLAGS ), array_column( self::FLAGS, 1 ) ), $errors, __( 'must be the boolean true or false, not a string or a number. Leave it out for the default.', 'wp-marketing-automations-pro' ) );
		$exclude = array_key_exists( 'exclude_contact_ids', $input ) ? self::checked_exclude( $input['exclude_contact_ids'], $errors ) : array();

		if ( ! $flags['promotional'] && ! self::transactional_allowed() ) {
			$errors->add( 'promotional', self::not_allowed_message() );
		}

		$ref = array_key_exists( 'client_ref', $input ) ? $input['client_ref'] : null;
		if ( null !== $ref && ( ! is_string( $ref ) || '' === $ref || mb_strlen( $ref ) > 64 ) ) {
			$errors->add( 'client_ref', __( 'must be a string of 1 to 64 characters. Leave it out if you do not need a retry to return the same draft.', 'wp-marketing-automations-pro' ) );
		}

		if ( 0 !== $type ) {
			$problem = self::channel_problem( $channel );
			if ( '' !== $problem ) {
				return new WP_Error( 'fkmcp_channel_unavailable', $problem );
			}
		}

		$audience = FKMCP_Broadcast_Audience::resolve( $input, $errors );

		// promotional was checked above; content reads it only to know whether the email is transactional.
		$content = 0 === $type ? null : FKMCP_Broadcast_Content::build( array( 'promotional' => $flags['promotional'] ) + $input, $type, $errors );

		if ( $errors->has() || null === $audience || null === $content ) {
			return self::invalid( $errors );
		}

		$ab = isset( $input['ab_type'] ) ? $input['ab_type'] : 'standard'; // content refused anything but standard and ab.

		try {
			$count = FKMCP_Broadcast_Audience::count(
				array(
					'id'     => 0,
					'type'   => $type,
					'parent' => 0,
					'data'   => array(
						'filters'           => $audience['filters'],
						'exclude'           => $exclude,
						'is_promotional'    => $flags['promotional'],
						'includeSoftBounce' => $flags['include_soft_bounce'],
						'includeUnverified' => $flags['include_unverified'],
					),
				)
			);
		} catch ( Throwable $e ) {
			BWFAN_MCP_Log::event( 'BROADCAST_DRAFT_COUNT_FAILED class=' . get_class( $e ) );

			return new WP_Error( 'fkmcp_create_failed', __( 'The audience could not be counted, so nothing was saved. Try again; if it fails again, build this broadcast in the admin.', 'wp-marketing-automations-pro' ) );
		}

		if ( $count < 1 ) {
			/* translators: %s: channel (email, sms or whatsapp) */
			return new WP_Error( 'fkmcp_invalid_input', sprintf( __( 'No contact matches this audience for %s (email needs an address; SMS and WhatsApp need a phone number). Nothing was saved.', 'wp-marketing-automations-pro' ), $channel ) );
		}

		// Agents retry on timeouts: a repeated client_ref hands back the first draft while it is still one.
		$ref_key = '';
		if ( null !== $ref ) {
			$ref_key = self::REF_PREFIX . get_current_user_id() . '_' . md5( $ref );
			$first   = absint( get_transient( $ref_key ) );

			if ( $first > 0 ) {
				// A read that fails is no reuse: the call goes on and creates.
				try {
					$earlier = self::call( 'get', array( $first ) );
				} catch ( Throwable $e ) {
					$earlier = null;
				}

				if ( self::is_draft( $earlier, $first ) ) {
					return self::reused( $first, $earlier );
				}
			}
		}

		$id = 0;
		try {
			$made = self::call( 'create', array( $title, $description, $type, get_current_user_id() ) );
			$id   = self::ok( $made ) && isset( $made['data']['id'] ) ? absint( $made['data']['id'] ) : 0;
			if ( $id < 1 ) {
				return new WP_Error( 'fkmcp_create_failed', __( 'The broadcast could not be created. Nothing was kept. Try again; if it fails again, create it in the admin.', 'wp-marketing-automations-pro' ) );
			}

			self::step(
				$id,
				1,
				array(
					'title'             => $title,
					'description'       => $description,
					'type'              => $type,
					'promotional'       => $flags['promotional'],
					'ab_type'           => $ab,
					'exclude'           => $exclude,
					'includeSoftBounce' => $flags['include_soft_bounce'],
					'includeUnverified' => $flags['include_unverified'],
				)
			);
			self::step(
				$id,
				2,
				array(
					'filters' => $audience['filters'],
					'exclude' => $exclude,
					'count'   => $count,
				)
			);
			self::step( $id, 3, $content['step3'] );

			$row = self::call( 'get', array( $id ) );
		} catch ( Throwable $e ) {
			return self::rollback( $id, get_class( $e ), __( 'The broadcast could not be saved.', 'wp-marketing-automations-pro' ) );
		}

		if ( ! self::is_draft( $row, $id ) ) {
			return self::rollback( $id, 'not_draft', __( 'The draft was not kept: it did not read back as a draft.', 'wp-marketing-automations-pro' ) );
		}

		BWFAN_MCP_Log::event( sprintf( 'BROADCAST_DRAFT_CREATED id=%d channel=%s variants=%d count=%d', $id, $channel, count( $content['variants_out'] ), $count ) );

		$warnings = array_merge( $content['warnings'], self::smart_warnings( $type, $content['step3'] ) );
		if ( ! $flags['promotional'] ) {
			$warnings[] = self::transactional_warning();
		}

		$summary = self::summary(
			$id,
			array(
				'title'        => $title,
				'type'         => $type,
				'promotional'  => $flags['promotional'],
				'ab_type'      => $ab,
				'audience'     => $audience,
				'count'        => $count,
				'step3'        => $content['step3'],
				'variants_out' => $content['variants_out'],
				'warnings'     => $warnings,
			)
		);

		if ( '' !== $ref_key ) {
			set_transient( $ref_key, $id, 10 * MINUTE_IN_SECONDS );
		}

		return $summary;
	}

	/**
	 * Changes a draft, and only a draft, through steps 1 to 3. Send only what changes.
	 *
	 * What is written:
	 * - step 1 when title, description, a flag, exclude_contact_ids or ab_type is sent: all eight
	 *   keys, the unsent ones as stored;
	 * - step 2 when an audience key is sent, or when a flag or the exclusions change who is
	 *   reached: then the stored filters are recounted, if this tool would accept them;
	 * - step 3 when variants, sender or smart_send is sent. The model replaces the content, the
	 *   sender and smart sending together, so without variants the stored content goes back as it is.
	 *
	 * A flag missing from the stored row (a draft the admin never saved step 1 for) is read by the
	 * send as off, while the wizard shows its default: promotional on, soft bounces included,
	 * unverified left out. A missing promotional flag would mail unsubscribed contacts, so no update
	 * leaves one behind: any call that writes a step also writes step 1 with the wizard's defaults,
	 * names each one in a warning, and recounts the audience if that changed who is reached.
	 *
	 * Where there is no audience stored either, there is nothing to recount: step 1 is written and
	 * the caller is told the audience is not set yet.
	 *
	 * A draft stored as transactional is changed only where transactional_allowed(); elsewhere the
	 * call must send promotional: true, which makes it a normal broadcast and recounts it.
	 *
	 * smart_send: false switches smart sending off; step 3 is then written without it.
	 *
	 * Nothing is rolled back and nothing is ever deleted: this is the user's own draft. A write
	 * that fails after an earlier step was saved says which steps were saved.
	 *
	 * @param array $input broadcast_id and any of the UPDATE_KEYS.
	 *
	 * @return array|WP_Error The summary of the draft as it reads after the update, with steps_written.
	 */
	public static function update( array $input ) {
		$errors = new FKMCP_Definition_Errors();

		foreach ( array_diff( array_keys( $input ), self::UPDATE_KEYS ) as $key ) {
			$errors->add(
				(string) $key,
				'channel' === $key
					? __( 'cannot be changed: a draft keeps the channel it was created with. Remove this key; for another channel create a new broadcast with create-broadcast.', 'wp-marketing-automations-pro' )
					: __( 'is not an input of this tool. It only changes a draft: status, scheduling and sending are set in the admin. Remove this key.', 'wp-marketing-automations-pro' )
			);
		}

		$id = isset( $input['broadcast_id'] ) && is_int( $input['broadcast_id'] ) ? $input['broadcast_id'] : 0;
		if ( $id < 1 ) {
			$errors->add( 'broadcast_id', __( 'is required: the id of a draft, a positive integer. Call list-broadcasts for ids.', 'wp-marketing-automations-pro' ) );

			return self::invalid( $errors );
		}

		try {
			$row = self::call( 'get', array( $id ) );
		} catch ( Throwable $e ) {
			return new WP_Error( 'fkmcp_update_failed', __( 'The broadcast could not be read, so nothing was changed. Try again.', 'wp-marketing-automations-pro' ) );
		}

		if ( ! is_array( $row ) || ! isset( $row['id'] ) || (int) $row['id'] !== $id ) {
			return new WP_Error( 'fkmcp_not_found', __( 'No broadcast with that id. Call list-broadcasts for valid ids.', 'wp-marketing-automations-pro' ) );
		}

		if ( ! self::is_draft( $row, $id ) ) {
			return new WP_Error( 'fkmcp_not_draft', __( 'Only a draft can be changed here; this one is scheduled, sending or finished. Nothing was changed. Tell the user to change it in the admin.', 'wp-marketing-automations-pro' ) );
		}

		$type = isset( $row['type'] ) ? (int) $row['type'] : 0;
		if ( ! in_array( $type, self::CHANNELS, true ) || ! empty( $row['parent'] ) ) {
			// A resend's audience is its parent's unopened contacts: a count made here would be wrong.
			return new WP_Error( 'fkmcp_invalid_input', __( 'This draft cannot be changed here: it is a resend of another broadcast, or its channel is not email, sms or whatsapp. Nothing was changed. Tell the user to change it in the admin.', 'wp-marketing-automations-pro' ) );
		}

		$data = isset( $row['data'] ) ? $row['data'] : array();
		$data = is_string( $data ) ? json_decode( $data, true ) : $data;
		$data = is_array( $data ) ? $data : array();

		$sent = function ( array $keys ) use ( $input ) {
			return array() !== array_intersect_key( $input, array_flip( $keys ) );
		};

		$write1        = $sent( array( 'title', 'description', 'promotional', 'include_unverified', 'include_soft_bounce', 'exclude_contact_ids', 'ab_type' ) );
		$audience_sent = isset( $input['filters'] ) || isset( $input['audience_id'] ) || isset( $input['all_contacts'] );
		$has_variants  = array_key_exists( 'variants', $input );
		$write3        = $has_variants || $sent( array( 'sender', 'smart_send' ) );
		$smart_off     = array_key_exists( 'smart_send', $input ) && false === $input['smart_send'];

		if ( ! $write1 && ! $audience_sent && ! $write3 ) {
			$errors->add( 'broadcast_id', __( 'Nothing to change: send at least one more key, and only the ones that change.', 'wp-marketing-automations-pro' ) );
		}

		// Step 1: the stored values, overlaid with the sent ones.
		$title       = array_key_exists( 'title', $input ) ? self::checked_title( $input['title'], $errors ) : ( isset( $row['title'] ) ? (string) $row['title'] : '' );
		$description = array_key_exists( 'description', $input ) ? self::checked_description( $input['description'], $errors ) : ( isset( $row['description'] ) ? (string) $row['description'] : '' );
		$was         = array(); // as the send reads the stored row: a missing flag is off
		$base        = array(); // what step 1 writes for a flag that is not sent
		$defaulted   = array();
		foreach ( self::FLAGS as $key => $flag ) {
			$stored       = isset( $data[ $flag[0] ] );
			$was[ $key ]  = $stored && ! empty( $data[ $flag[0] ] );
			$base[ $key ] = $stored ? $was[ $key ] : $flag[1];
			if ( ! $stored && ! array_key_exists( $key, $input ) ) {
				$defaulted[ $key ] = $flag[1];
			}
		}
		$flags = self::checked_flags( $input, $base, $errors, __( 'must be the boolean true or false, not a string or a number. Leave it out to keep the stored value.', 'wp-marketing-automations-pro' ) );

		// Every update writes a step, so a draft that would stay or become transactional is settled here, before anything is counted.
		if ( ! $flags['promotional'] && ! self::transactional_allowed() ) {
			if ( array_key_exists( 'promotional', $input ) ) {
				if ( false === $input['promotional'] ) { // anything else was reported above
					$errors->add( 'promotional', self::not_allowed_message() );
				}
			} else {
				$errors->add( 'promotional', __( 'This draft is transactional (it also reaches unsubscribed contacts), and such a draft cannot be changed here on this site. Send promotional: true in this call to make it a normal broadcast, or tell the user to edit it in the admin.', 'wp-marketing-automations-pro' ) );
			}
		}

		// A draft is never left with a flag missing: whatever this call writes, step 1 goes with it.
		$write1 = $write1 || ( count( array_filter( array_intersect_key( $data, array_flip( array_column( self::FLAGS, 0 ) ) ), function ( $value ) {
			return null !== $value;
		} ) ) < count( self::FLAGS ) && ( $audience_sent || $write3 ) );

		if ( $write1 && ! array_key_exists( 'title', $input ) && ( '' === $title || '0' === $title ) ) {
			$errors->add( 'title', __( 'is needed: this draft has no usable title stored, and the information step cannot be saved without one. Send title.', 'wp-marketing-automations-pro' ) );
		}

		$exclude_was = array_values( array_unique( array_filter( array_map( 'absint', isset( $data['exclude'] ) && is_array( $data['exclude'] ) ? $data['exclude'] : array() ) ) ) );
		$exclude     = array_key_exists( 'exclude_contact_ids', $input ) ? self::checked_exclude( $input['exclude_contact_ids'], $errors ) : $exclude_was;

		$ab_was = isset( $data['ab_type'] ) && 'ab' === $data['ab_type'] ? 'ab' : 'standard';
		$ab     = $ab_was;
		if ( array_key_exists( 'ab_type', $input ) ) {
			if ( 'standard' === $input['ab_type'] || 'ab' === $input['ab_type'] ) {
				$ab = $input['ab_type'];
				if ( $ab !== $ab_was && ! $has_variants ) {
					$errors->add( 'ab_type', __( 'cannot change without variants in the same call: standard takes exactly 1 variant, ab takes 2 or 3. Send variants too, or leave ab_type out.', 'wp-marketing-automations-pro' ) );
				}
			} elseif ( ! $has_variants ) { // with variants, content reports it
				$errors->add( 'ab_type', __( 'must be standard (one variant) or ab (two or three variants).', 'wp-marketing-automations-pro' ), array( 'standard', 'ab' ) );
			}
		}

		// Step 3.
		$step3        = null;
		$variants_out = null;
		$warnings     = array();
		if ( $has_variants ) {
			$channel = (string) array_search( $type, self::CHANNELS, true );
			if ( '' !== self::channel_problem( $channel ) ) {
				/* translators: %s: channel (sms or whatsapp) */
				return new WP_Error( 'fkmcp_channel_unavailable', sprintf( __( 'This draft\'s channel (%s) is not connected on this site right now; connect it, or change this draft\'s content in the admin. Nothing was changed.', 'wp-marketing-automations-pro' ), $channel ) );
			}

			$built = FKMCP_Broadcast_Content::build( array( 'promotional' => $flags['promotional'] ) + array_intersect_key( $input, array_flip( $smart_off ? array( 'variants', 'ab_type', 'sender' ) : array( 'variants', 'ab_type', 'smart_send', 'sender' ) ) ), $type, $errors, $data );
			if ( null !== $built ) {
				$step3        = $built['step3'];
				$variants_out = $built['variants_out'];
				$warnings     = $built['warnings'];
			}
		} elseif ( $write3 ) {
			$content = self::stored_content( $row );
			$total   = null === $content ? 0 : count( $content );
			if ( 'standard' === $ab ? 1 !== $total : ( $total < 2 || $total > 3 ) ) {
				$errors->add( 'variants', __( 'are needed: the content stored in this draft is missing or does not fit its ab_type (standard takes exactly 1 variant, ab takes 2 or 3), so it cannot be kept. Send variants again in this call: 2 or 3 for ab, or set ab_type: "standard" with one variant.', 'wp-marketing-automations-pro' ) );
				$content = null;
			}

			$sender = 1 === $type ? FKMCP_Broadcast_Content::email_sender( $input, $data, $errors ) : FKMCP_Broadcast_Content::global_sender_values( $input, $errors );
			$smart  = array_key_exists( 'smart_send', $input ) && ! $smart_off ? FKMCP_Broadcast_Content::smart_send( $input['smart_send'], $ab, null === $content ? array() : $content, $errors ) : null;

			if ( null !== $content && null !== $sender ) {
				$step3 = array(
					'content'       => $content,
					'senders_name'  => $sender['name'],
					'senders_email' => $sender['email'],
					'replyto'       => $sender['reply_to'],
				);
				if ( null !== $smart ) {
					$step3['smart_send'] = $smart;
				}
				$warnings[] = __( 'The content was kept exactly as it is stored: only the sender or smart sending changed. Send variants to change the content.', 'wp-marketing-automations-pro' );
			}
		}

		// The model stores no smart sending when the key is left out, so the stored one is sent again where it still applies.
		$smart_was = isset( $data['smart_send'] ) && is_array( $data['smart_send'] ) && ! empty( $data['smart_send']['enable'] ) ? $data['smart_send'] : null;
		if ( null !== $step3 && null !== $smart_was && ! array_key_exists( 'smart_send', $input ) ) {
			$percent = isset( $smart_was['percent'] ) && is_numeric( $smart_was['percent'] ) ? (int) $smart_was['percent'] : 0;
			$usable  = $percent >= 1 && $percent <= 99 && isset( $smart_was['hours'] ) && is_numeric( $smart_was['hours'] ) && (int) $smart_was['hours'] >= 1;

			if ( $usable && 'ab' === $ab && count( $step3['content'] ) >= 2 ) {
				$step3['smart_send'] = $smart_was;
			} else {
				$warnings[] = __( 'Smart sending was turned off: it needs ab_type ab, 2 or 3 variants, a percent of 1 to 99 and at least 1 hour, and the stored setting no longer fits. Send smart_send to set it again.', 'wp-marketing-automations-pro' );
			}
		}

		if ( null !== $step3 ) {
			$warnings = array_merge( $warnings, self::smart_warnings( $type, $step3 ) );
		}

		// Step 2: a new audience, or the stored one recounted because who is reached changed.
		$sorted   = function ( array $ids ) {
			sort( $ids );

			return $ids;
		};
		$moved    = $write1 && ( $flags !== $was || $sorted( $exclude ) !== $sorted( $exclude_was ) );
		$write2   = $audience_sent || $moved;
		$audience = null;
		$filters  = null;
		$unset    = false; // no audience is stored, and only the defaults written for missing flags would move it
		if ( $audience_sent ) {
			$audience = FKMCP_Broadcast_Audience::resolve( $input, $errors );
			$filters  = null === $audience ? null : $audience['filters'];
		} elseif ( $moved ) {
			$filters = self::stored_filters( $data );
			$unset   = ! isset( $data['filters'] ) && array() === array_diff_key( array_diff_assoc( $flags, $was ), $defaulted ) && $sorted( $exclude ) === $sorted( $exclude_was );
			if ( $unset ) {
				$write2 = false;
			} elseif ( null === $filters ) {
				$errors->add( 'audience', __( 'must be sent again: this change alters who gets the broadcast, and the audience stored in this draft cannot be recounted here (it was never set, or it has a status condition or a filter this tool does not accept). Send filters, audience_id or all_contacts: true in this call, or tell the user to make this change in the admin.', 'wp-marketing-automations-pro' ) );
			}
		}

		if ( $errors->has() ) {
			return self::invalid( $errors );
		}

		$plan = array();
		if ( $write1 ) {
			$plan[1] = array(
				'title'             => $title,
				'description'       => $description,
				'type'              => $type,
				'promotional'       => $flags['promotional'],
				'ab_type'           => $ab,
				'exclude'           => $exclude,
				'includeSoftBounce' => $flags['include_soft_bounce'],
				'includeUnverified' => $flags['include_unverified'],
			);
		}

		if ( $write2 ) {
			// With step 1 not written the stored flags are counted as they are, missing ones included.
			$reach = array(
				'is_promotional'    => $flags['promotional'],
				'includeSoftBounce' => $flags['include_soft_bounce'],
				'includeUnverified' => $flags['include_unverified'],
			);

			try {
				$count = FKMCP_Broadcast_Audience::count(
					array(
						'id'     => 0,
						'type'   => $type,
						'parent' => 0,
						'data'   => array(
							'filters' => $filters,
							'exclude' => $exclude,
						) + ( $write1 ? $reach : array_intersect_key( $data, $reach ) ),
					)
				);
			} catch ( Throwable $e ) {
				BWFAN_MCP_Log::event( 'BROADCAST_DRAFT_COUNT_FAILED class=' . get_class( $e ) );

				return new WP_Error( 'fkmcp_update_failed', __( 'The audience could not be counted, so nothing was changed. Try again; if it fails again, tell the user to make this change in the admin.', 'wp-marketing-automations-pro' ) );
			}

			if ( $count < 1 ) {
				/* translators: %s: channel (email, sms or whatsapp) */
				return new WP_Error( 'fkmcp_invalid_input', sprintf( __( 'No contact matches this audience for %s (email needs an address; SMS and WhatsApp need a phone number). Nothing was changed.', 'wp-marketing-automations-pro' ), (string) array_search( $type, self::CHANNELS, true ) ) );
			}

			$plan[2] = array(
				'filters' => $filters,
				'exclude' => $exclude,
				'count'   => $count,
			);
		}

		if ( null !== $step3 ) {
			$plan[3] = $step3;
		}

		// What the caller must be told, by the step that makes it true: a call that stops early reports only what was saved.
		$notes = array(
			1 => array(),
			3 => $warnings,
		);
		if ( $write1 ) {
			foreach ( $defaulted as $key => $default ) {
				/* translators: 1: the input key (promotional, include_unverified or include_soft_bounce), 2: true or false */
				$notes[1][] = sprintf( __( '%1$s was not set in this draft, so it was saved as %2$s, the default the admin shows. Send %1$s to choose.', 'wp-marketing-automations-pro' ), $key, $default ? 'true' : 'false' );
			}
		}
		if ( $write1 && $unset ) {
			$notes[1][] = __( 'The audience is not set yet, so nothing was counted. Send filters, audience_id or all_contacts: true, or have the user choose it in the admin.', 'wp-marketing-automations-pro' );
		}
		// Step 1 is first in every plan that has it, so once a step is saved this is how the draft reads.
		$transactional = ! $flags['promotional'];
		$told          = function ( array $steps ) use ( $notes, $transactional ) {
			return array_merge(
				in_array( 3, $steps, true ) ? $notes[3] : array(),
				in_array( 1, $steps, true ) ? $notes[1] : array(),
				$transactional && array() !== $steps ? array( self::transactional_warning() ) : array()
			);
		};

		$done = array();
		foreach ( $plan as $step => $payload ) {
			try {
				if ( ! self::is_draft( self::call( 'get', array( $id ) ), $id ) ) {
					return self::stopped( 'fkmcp_not_draft', $id, $done, array_keys( $plan ), __( 'This broadcast stopped being a draft while this update ran (it was scheduled, or removed); nothing more was changed.', 'wp-marketing-automations-pro' ), $told( $done ) );
				}

				self::step( $id, $step, $payload );
			} catch ( Throwable $e ) {
				/* translators: %d: the step of the broadcast that failed (1, 2 or 3) */
				return self::stopped( 'fkmcp_update_failed', $id, $done, array_keys( $plan ), sprintf( __( 'Step %d of the broadcast could not be saved; nothing more was changed.', 'wp-marketing-automations-pro' ), $step ), $told( $done ) );
			}

			$done[] = $step;
		}

		try {
			$row = self::call( 'get', array( $id ) );
		} catch ( Throwable $e ) {
			return self::stopped( 'fkmcp_update_failed', $id, $done, array_keys( $plan ), __( 'The steps below were saved, but the broadcast could not be read back, so its state now is not known.', 'wp-marketing-automations-pro' ), $told( $done ) );
		}

		if ( ! self::is_draft( $row, $id ) ) {
			return self::stopped( 'fkmcp_not_draft', $id, $done, array_keys( $plan ), __( 'The update was written, but the broadcast did not read back as a draft: it was scheduled or removed while this update ran.', 'wp-marketing-automations-pro' ), $told( $done ) );
		}

		BWFAN_MCP_Log::event( sprintf( 'BROADCAST_DRAFT_UPDATED id=%d steps=%s', $id, implode( ',', $done ) ) );

		$parts             = self::row_parts( $row );
		$parts['warnings'] = $told( $done );
		if ( null !== $audience ) {
			$parts['audience'] = $audience;
		}
		if ( null !== $variants_out ) {
			$parts['variants_out'] = $variants_out; // built in this call, so each designed one gets a preview link
		}

		return array_merge( self::summary( $id, $parts ), array( 'steps_written' => $done ) );
	}

	/** @return string The title, or '' after an error. */
	private static function checked_title( $value, FKMCP_Definition_Errors $errors ) {
		$title = is_string( $value ) ? trim( $value ) : '';

		// The model's step 1 tests the title with empty(), which "0" fails: refused here, before anything is written.
		if ( '' === $title || '0' === $title || mb_strlen( $title ) > self::TITLE_MAX || sanitize_text_field( $title ) !== $title ) {
			$errors->add( 'title', __( 'is required, at most 255 characters, and not just "0". Use plain text: single spaces, no HTML, no % codes.', 'wp-marketing-automations-pro' ) );

			return '';
		}

		return $title;
	}

	/** @return string The description, or '' after an error. */
	private static function checked_description( $value, FKMCP_Definition_Errors $errors ) {
		$description = is_string( $value ) ? trim( $value ) : null;

		if ( null === $description || mb_strlen( $description ) > self::DESCRIPTION_MAX || sanitize_textarea_field( $description ) !== $description ) {
			$errors->add( 'description', __( 'must be at most 1000 characters. Use plain text: single spaces, no HTML, no % codes. Leave it out for none.', 'wp-marketing-automations-pro' ) );

			return '';
		}

		return $description;
	}

	/**
	 * The model reads any non-empty string as true, "false" included: only a real boolean goes through.
	 *
	 * @param array<string, bool> $flags   The value of each flag when it is not sent.
	 * @param string              $message For a value that is not a boolean.
	 *
	 * @return array<string, bool>
	 */
	private static function checked_flags( array $input, array $flags, FKMCP_Definition_Errors $errors, $message ) {
		foreach ( array_keys( $flags ) as $key ) {
			if ( ! array_key_exists( $key, $input ) ) {
				continue;
			}
			if ( ! is_bool( $input[ $key ] ) ) {
				$errors->add( $key, $message );

				continue;
			}
			$flags[ $key ] = $input[ $key ];
		}

		return $flags;
	}

	/** @return int[] The ids, without repeats; empty after an error. */
	private static function checked_exclude( $ids, FKMCP_Definition_Errors $errors ) {
		$valid = is_array( $ids ) && count( $ids ) <= self::MAX_EXCLUDE;
		foreach ( $valid ? $ids : array() as $id ) {
			$valid = $valid && is_int( $id ) && $id > 0;
		}

		if ( ! $valid ) {
			$errors->add( 'exclude_contact_ids', __( 'must be a list of at most 500 contact ids, each a positive integer. To leave out more contacts, use filters.', 'wp-marketing-automations-pro' ) );

			return array();
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * The stored variants, to hand back to step 3 unchanged. Each variant is an array, as the model
	 * reads it; everything inside is decoded as it is stored, so an empty object stays {} and is not
	 * re-encoded as [].
	 *
	 * @return array[]|null Null when there is no usable content.
	 */
	private static function stored_content( array $row ) {
		$data    = isset( $row['data'] ) ? $row['data'] : null;
		$data    = is_string( $data ) ? json_decode( $data ) : ( is_array( $data ) ? (object) $data : null );
		$content = is_object( $data ) && isset( $data->content ) && is_array( $data->content ) ? array_values( $data->content ) : array();

		foreach ( $content as $i => $variant ) {
			if ( ! is_object( $variant ) && ! is_array( $variant ) ) {
				return null;
			}
			$content[ $i ] = (array) $variant;
		}

		return array() === $content ? null : $content;
	}

	/**
	 * The stored filters, when a count made with them can be trusted: an empty list (all contacts),
	 * or filters this tool would accept from a caller. A draft built elsewhere may hold a status
	 * condition or a filter this site no longer has; those are not counted.
	 *
	 * @return array|null
	 */
	private static function stored_filters( array $data ) {
		if ( ! isset( $data['filters'] ) || ! is_array( $data['filters'] ) ) {
			return null;
		}

		if ( array() === $data['filters'] ) {
			return array();
		}

		return null === FKMCP_Broadcast_Audience::validate_filters( $data['filters'], 'filters', new FKMCP_Definition_Errors() ) ? null : $data['filters'];
	}

	/**
	 * An update that ended early. The draft is the user's: nothing is undone and nothing is deleted.
	 *
	 * @param string   $code     fkmcp_not_draft or fkmcp_update_failed.
	 * @param int[]    $done     Steps saved.
	 * @param int[]    $plan     Steps this call set out to save.
	 * @param string   $message  What happened.
	 * @param string[] $warnings What the saved steps changed that the caller must still be told.
	 *
	 * @return WP_Error
	 */
	private static function stopped( $code, $id, array $done, array $plan, $message, array $warnings ) {
		$warnings = FKMCP_Definition_Errors::untrust( array_values( $warnings ) );
		$left     = array_values( array_diff( $plan, $done ) );
		$names    = array(
			1 => __( 'step 1 (information)', 'wp-marketing-automations-pro' ),
			2 => __( 'step 2 (audience)', 'wp-marketing-automations-pro' ),
			3 => __( 'step 3 (content)', 'wp-marketing-automations-pro' ),
		);
		$list     = function ( array $steps ) use ( $names ) {
			return array() === $steps ? __( 'none', 'wp-marketing-automations-pro' ) : implode( ', ', array_intersect_key( $names, array_flip( $steps ) ) );
		};

		BWFAN_MCP_Log::event( sprintf( 'BROADCAST_DRAFT_UPDATE_STOPPED id=%d code=%s saved=%s left=%s', $id, $code, implode( ',', $done ), implode( ',', $left ) ) );

		return new WP_Error(
			$code,
			/* translators: 1: the steps saved, 2: the steps not saved */
			$message . ' ' . sprintf( __( 'Saved: %1$s. Not saved: %2$s. Nothing was deleted. Tell the user, and have them check the broadcast in the admin before anything is tried again.', 'wp-marketing-automations-pro' ), $list( $done ), $list( $left ) )
				/* translators: %s: notes about what the saved steps changed */
				. ( array() === $warnings ? '' : ' ' . sprintf( __( 'From the steps that were saved: %s', 'wp-marketing-automations-pro' ), implode( ' ', $warnings ) ) ),
			array(
				'broadcast_id'      => $id,
				'steps_written'     => $done,
				'steps_not_written' => $left,
				'warnings'          => $warnings,
			)
		);
	}

	/**
	 * @param string $channel email, sms or whatsapp.
	 *
	 * @return string '' when a broadcast can be sent on the channel, else why not and what to do.
	 */
	public static function channel_problem( $channel ) {
		if ( 'email' === $channel ) {
			return '';
		}

		// A connector that throws while it is asked is not a channel to build a draft on.
		try {
			return self::connector_problem( $channel );
		} catch ( Throwable $e ) {
			return __( 'This channel could not be checked on this site, so nothing was saved. Use channel email, or create this broadcast in the admin.', 'wp-marketing-automations-pro' );
		}
	}

	private static function connector_problem( $channel ) {
		if ( 'sms' === $channel ) {
			$ready = is_callable( array( 'BWFCRM_Common', 'get_sms_provider_integration' ) ) && ! is_wp_error( BWFCRM_Common::get_sms_provider_integration() );

			return $ready ? '' : __( 'SMS is not available on this site: no SMS service is connected. Ask the user to connect one under Settings > Connectors, or use channel email. Nothing was saved.', 'wp-marketing-automations-pro' );
		}

		if ( 'whatsapp' === $channel ) {
			$ready = is_callable( array( 'BWFAN_Common', 'is_whatsapp_services_enabled' ) ) && BWFAN_Common::is_whatsapp_services_enabled();

			return $ready ? '' : __( 'WhatsApp is not available on this site: no WhatsApp service is connected. Ask the user to connect one under Settings > Connectors, or use channel email. Nothing was saved.', 'wp-marketing-automations-pro' );
		}

		return __( 'channel must be email, sms or whatsapp.', 'wp-marketing-automations-pro' );
	}

	/**
	 * What a tool returns about a draft. Text that came from the site or the caller is
	 * cleaned for the agent; a variant's html is used for its preview link and never returned.
	 *
	 * @param int   $id
	 * @param array $parts {title, type, promotional, ab_type, audience: {mode, summary, removed}|null, count, step3, variants_out, warnings}.
	 *                     A null audience reports the count alone.
	 *
	 * @return array
	 */
	public static function summary( $id, array $parts ) {
		$id       = (int) $id;
		$type     = (int) $parts['type'];
		$step3    = $parts['step3'];
		$variants = array();

		foreach ( $parts['variants_out'] as $variant ) {
			$index = (int) $variant['index'];
			$one   = array( 'index' => $index );
			if ( isset( $variant['subject'] ) ) {
				$one['subject'] = FKMCP_Definition_Errors::untrust( (string) $variant['subject'] );
			}
			$one['format']   = (string) $variant['format'];
			$one['designed'] = ! empty( $variant['designed'] );

			if ( 1 !== $type ) {
				$one['body_chars'] = isset( $step3['content'][ $index ]['body'] ) ? mb_strlen( (string) $step3['content'][ $index ]['body'] ) : 0;
			}
			if ( $one['designed'] && isset( $variant['html'] ) ) {
				$one += self::preview( (string) $variant['html'], isset( $variant['subject'] ) ? (string) $variant['subject'] : '' );
			}

			$variants[] = $one;
		}

		$smart = isset( $step3['smart_send'] ) && is_array( $step3['smart_send'] ) && ! empty( $step3['smart_send']['enable'] ) && isset( $step3['smart_send']['percent'], $step3['smart_send']['hours'] ) ? $step3['smart_send'] : null;

		return array(
			'broadcast_id' => $id,
			'title'        => FKMCP_Definition_Errors::untrust( (string) $parts['title'] ),
			'channel'      => (string) array_search( $type, self::CHANNELS, true ),
			'status'       => 'draft',
			'promotional'  => ! empty( $parts['promotional'] ),
			'ab_type'      => (string) $parts['ab_type'],
			'audience'     => ( null === $parts['audience'] ? array() : array(
				'mode'    => (string) $parts['audience']['mode'],
				'summary' => FKMCP_Definition_Errors::untrust( array_values( $parts['audience']['summary'] ) ),
				'removed' => FKMCP_Definition_Errors::untrust( array_values( $parts['audience']['removed'] ) ),
			) ) + array( 'count' => (int) $parts['count'] ),
			'variants'     => $variants,
			'smart_send'   => null === $smart ? null : array(
				'percent' => (int) $smart['percent'],
				'hours'   => (int) $smart['hours'],
			),
			'sender'       => 1 !== $type ? null : FKMCP_Definition_Errors::untrust(
				array(
					'name'     => isset( $step3['senders_name'] ) && is_scalar( $step3['senders_name'] ) ? (string) $step3['senders_name'] : '',
					'email'    => isset( $step3['senders_email'] ) && is_scalar( $step3['senders_email'] ) ? (string) $step3['senders_email'] : '',
					'reply_to' => isset( $step3['replyto'] ) && is_scalar( $step3['replyto'] ) ? (string) $step3['replyto'] : '',
				)
			),
			'warnings'     => FKMCP_Definition_Errors::untrust( array_values( $parts['warnings'] ) ),
			'edit_url'     => BWFAN_MCP_Links::app( 'autonami', '/broadcast/' . $id ),
			'next_step'    => 'Open edit_url, check Contacts and Content, then review and schedule on the last step. Scheduling and sending are not available here.',
			'reused'       => false,
		);
	}

	/**
	 * The draft an earlier call with the same client_ref made, as its row reads now. The audience
	 * is its stored count alone and there are no preview links: neither is rebuilt for a retry.
	 */
	private static function reused( $id, array $row ) {
		$parts             = self::row_parts( $row );
		$parts['warnings'] = array( __( 'reused: this is the draft made by the earlier call', 'wp-marketing-automations-pro' ) );

		return array_merge( self::summary( $id, $parts ), array( 'reused' => true ) );
	}

	/** What summary() needs, read from a stored row: the count alone for the audience, and no html to preview. */
	private static function row_parts( array $row ) {
		$data     = isset( $row['data'] ) ? $row['data'] : array();
		$data     = is_string( $data ) ? json_decode( $data, true ) : $data;
		$data     = is_array( $data ) ? $data : array();
		$type     = isset( $row['type'] ) && in_array( (int) $row['type'], self::CHANNELS, true ) ? (int) $row['type'] : 1;
		$variants = array();

		foreach ( isset( $data['content'] ) && is_array( $data['content'] ) ? array_values( $data['content'] ) : array() as $index => $stored ) {
			$format  = 1 === $type && is_array( $stored ) && isset( $stored['type'] ) && is_string( $stored['type'] ) ? $stored['type'] : 'text';
			$variant = array( 'index' => $index );
			if ( 1 === $type && is_array( $stored ) && isset( $stored['subject'] ) && is_scalar( $stored['subject'] ) ) {
				$variant['subject'] = (string) $stored['subject'];
			}
			$variants[] = $variant + array(
				'format'   => 1 === $type ? $format : 'text',
				'designed' => 1 === $type && 'block' === $format,
			);
		}

		$data['content'] = isset( $data['content'] ) && is_array( $data['content'] ) ? array_values( $data['content'] ) : array();

		return array(
			'title'        => isset( $row['title'] ) ? (string) $row['title'] : '',
			'type'         => $type,
			'promotional'  => ! empty( $data['is_promotional'] ), // as the send reads it: missing is off
			'ab_type'      => isset( $data['ab_type'] ) && 'ab' === $data['ab_type'] ? 'ab' : 'standard',
			'audience'     => null,
			'count'        => isset( $row['count'] ) ? (int) $row['count'] : 0,
			'step3'        => $data,
			'variants_out' => $variants,
			'warnings'     => array(),
		);
	}

	/** Why promotional: false is refused where the site does not show the wizard's setting. */
	private static function not_allowed_message() {
		return __( 'Transactional broadcasts (which also reach unsubscribed contacts) cannot be made here on this site; create it in the admin. Leave promotional out for a normal broadcast.', 'wp-marketing-automations-pro' );
	}

	/** Every problem found, as one error. The shared collector words its summary for an Automation definition; this one is a broadcast. */
	private static function invalid( FKMCP_Definition_Errors $errors ) {
		$error = $errors->to_wp_error();
		$data  = $error->get_error_data();
		$total = count( $data['errors'] ) + (int) $data['more'];
		$lines = explode( "\n", $error->get_error_message(), 2 );

		return new WP_Error(
			'fkmcp_invalid_input',
			/* translators: %d: number of problems found in the input */
			sprintf( _n( 'The broadcast has %d problem. Nothing was saved.', 'The broadcast has %d problems. Nothing was saved.', $total, 'wp-marketing-automations-pro' ), $total ) . ( isset( $lines[1] ) ? "\n" . $lines[1] : '' ),
			$data
		);
	}

	/**
	 * The only door to the model's update. Step 4 schedules or sends, so it has no way through.
	 *
	 * @throws LogicException   For any step but 1, 2 and 3; the model is not called.
	 * @throws RuntimeException When the model refuses the write.
	 */
	private static function step( $id, $step, array $data ) {
		if ( ! in_array( $step, array( 1, 2, 3 ), true ) ) {
			throw new LogicException( 'A broadcast draft is written through steps 1, 2 and 3 only.' );
		}

		if ( ! self::ok( self::call( 'update', array( $id, $step, $data ) ) ) ) {
			throw new RuntimeException( 'Broadcast step ' . $step . ' was refused.' );
		}
	}

	private static function call( $name, array $args ) {
		if ( ! isset( self::$model[ $name ] ) || ! is_callable( self::$model[ $name ] ) ) {
			throw new RuntimeException( 'The broadcast model is not available.' );
		}

		return call_user_func_array( self::$model[ $name ], $args );
	}

	private static function ok( $response ) {
		return is_array( $response ) && isset( $response['status'] ) && 200 === (int) $response['status'];
	}

	/** A stored row that is this broadcast, a draft, and not on the calendar. */
	private static function is_draft( $row, $id ) {
		if ( ! is_array( $row ) || ! isset( $row['id'], $row['status'] ) || (int) $row['id'] !== (int) $id || 1 !== (int) $row['status'] ) {
			return false;
		}

		return empty( $row['execution_time'] ) || 0 === strpos( (string) $row['execution_time'], '0000-00-00' );
	}

	/**
	 * Deletes the draft this call created, by its id and nothing else, and says so.
	 *
	 * @param int    $id      0 when the failure came before a row existed.
	 * @param string $reason  For the log.
	 * @param string $message What went wrong, for the agent.
	 *
	 * @return WP_Error
	 */
	private static function rollback( $id, $reason, $message ) {
		$gone = $id < 1;

		if ( ! $gone ) {
			try {
				$gone = self::ok( self::call( 'delete', array( $id ) ) );
			} catch ( Throwable $e ) {
				$gone = false;
			}

			// A delete that reported failure on a row that is not there has nothing left to remove.
			if ( ! $gone ) {
				try {
					$gone = empty( self::call( 'get', array( $id ) ) );
				} catch ( Throwable $e ) {
					$gone = false;
				}
			}
		}

		BWFAN_MCP_Log::event( sprintf( 'BROADCAST_DRAFT_ROLLED_BACK id=%d reason=%s deleted=%d', $id, FKMCP_Definition_Errors::clean( $reason, 100 ), $gone ? 1 : 0 ) );

		if ( $gone ) {
			return new WP_Error( 'fkmcp_create_failed', $message . ' ' . __( 'Nothing was kept. Try again; if it fails again, create the broadcast in the admin.', 'wp-marketing-automations-pro' ) );
		}

		/* translators: %d: broadcast id */
		return new WP_Error( 'fkmcp_create_failed', $message . ' ' . sprintf( __( 'Its unfinished draft #%d could not be removed: tell the user to delete it on the Broadcasts screen. Do not retry until then.', 'wp-marketing-automations-pro' ), $id ), array( 'broadcast_id' => $id ) );
	}

	/** A sample-data preview link for a designed email. A failure costs the link, never the save. */
	private static function preview( $html, $title ) {
		$page = null;

		if ( is_callable( array( 'FKMCP_Pack_Email_Design', 'automation_preview' ) ) ) {
			try {
				$page = FKMCP_Pack_Email_Design::automation_preview( $html, $title );
			} catch ( Throwable $e ) {
				$page = null;
			}
		}

		return array(
			'preview_url' => is_array( $page ) && isset( $page['url'] ) && is_string( $page['url'] ) ? $page['url'] : null,
			'expires'     => is_array( $page ) && isset( $page['expires'] ) && is_string( $page['expires'] ) ? $page['expires'] : null,
		);
	}
}
