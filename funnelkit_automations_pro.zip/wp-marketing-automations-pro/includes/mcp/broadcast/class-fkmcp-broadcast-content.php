<?php

defined( 'ABSPATH' ) || exit;

/**
 * The content of a broadcast draft made over MCP: the variants, the A/B and smart
 * send settings and the sender, turned into the step 3 payload the broadcast model
 * stores, exactly as the wizard saves it for email, SMS and WhatsApp.
 *
 * Nothing here writes. Every problem is added to the error list with the path of the
 * input at fault, and build() then returns null, so a caller that gets null has
 * stored nothing. Stored editor types are the wizard's own: block, rich, html, wc.
 *
 * Counts are real integers only: 15.0 and "15" are refused rather than guessed at.
 * Flags are real booleans only.
 */
class FKMCP_Broadcast_Content {
	const MAX_VARIANTS = 3;

	const SUBJECT_MAX = 255;

	const NAME_MAX = 255;

	/** Bytes of body_html, as in an automation's email step. */
	const BODY_MAX = 204800;

	/** Bytes of design JSON. */
	const DESIGN_MAX = 102400;

	const DESIGN_SETTINGS_MAX = 20480;

	/** Characters in an SMS or WhatsApp message. */
	const TEXT_MAX = 1600;

	const URL_MAX = 2000;

	/** What a UTM value may hold: Lite writes it into every link's query string and href unencoded. */
	const UTM_PATTERN = '/^[A-Za-z0-9_.+%-]{1,100}$/D';

	const EMAIL_KEYS = array( 'subject', 'preheader', 'design', 'design_settings', 'template_id', 'body_html', 'format', 'utm' );

	const TEXT_KEYS = array( 'body', 'utm' );

	const WHATSAPP_KEYS = array( 'body', 'utm', 'image' );

	const SENDER_KEYS = array( 'name', 'email', 'reply_to' );

	const UTM_KEYS = array( 'source', 'medium', 'name', 'term', 'content' );

	const SMART_KEYS = array( 'percent', 'hours' );

	/** The stored editor type for each body_html format. */
	const FORMATS = array( 'rich', 'html' );

	/** What a saved template's mode column is stored as. Mode 4 (legacy drag and drop) has no entry. */
	const MODE_TYPES = array(
		1 => 'rich',
		2 => 'wc',
		3 => 'html',
		5 => 'block',
	);

	/** Tags that only mean something in an email. */
	const EMAIL_ONLY_TAGS = array( 'mail_footer', 'unsubscribe_link', 'business_name', 'business_address' );

	/** @var callable ( array $design, array $settings, array $input ): array|WP_Error - FKMCP_Pack_Email_Design::broadcast_design */
	public static $designer = array( 'FKMCP_Pack_Email_Design', 'broadcast_design' );

	/** @var callable ( array $ids ): array - saved templates by id. */
	public static $template_loader = array( 'FKMCP_Email_Step', 'load_templates' );

	/** @var callable ( array $row, array $input ): array|WP_Error - FKMCP_Pack_Email_Design::broadcast_copy */
	public static $copier = array( 'FKMCP_Pack_Email_Design', 'broadcast_copy' );

	/** @var callable (): array{name: string, email: string, reply_to: string} - the global sender. */
	public static $globals = array( 'FKMCP_Broadcast_Content', 'global_sender' );

	/** @var callable (): bool - whether WooCommerce is active. */
	public static $woocommerce = array( 'FKMCP_Broadcast_Content', 'woocommerce_active' );

	/**
	 * @param array                   $input  variants, and optionally ab_type, smart_send, sender and promotional.
	 * @param int                     $type   1 email, 2 SMS, 3 WhatsApp.
	 * @param FKMCP_Definition_Errors $errors
	 * @param array                   $stored On an update: ab_type, senders_name, senders_email and replyto as stored.
	 *
	 * @return array{step3: array, variants_out: array, warnings: string[]}|null Null when an error was added.
	 */
	public static function build( array $input, $type, FKMCP_Definition_Errors $errors, array $stored = array() ) {
		$before = $errors->count();

		if ( ! in_array( $type, array( 1, 2, 3 ), true ) ) {
			$errors->add( 'channel', __( 'must be email, sms or whatsapp.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$ab            = self::ab_type( $input, $stored, $errors );
		$transactional = false;
		if ( array_key_exists( 'promotional', $input ) ) {
			if ( ! is_bool( $input['promotional'] ) ) {
				$errors->add( 'promotional', __( 'must be true or false.', 'wp-marketing-automations-pro' ) );
			} else {
				$transactional = false === $input['promotional'];
			}
		}

		$variants = self::variant_list( $input, $ab, $errors );
		$content  = array();
		$out      = array();
		$warnings = array();

		if ( null !== $variants ) {
			$tags      = self::tags();
			if ( array() === $tags ) {
				$warnings[] = __( 'merge tags could not be checked on this site.', 'wp-marketing-automations-pro' );
			}
			$budget    = uniqid( 'fkmcp-bc-', true );
			$templates = 1 === $type ? self::templates( $variants, $errors ) : array();

			foreach ( $variants as $i => $variant ) {
				$path = 'variants[' . $i . ']';
				if ( ! is_array( $variant ) ) {
					$errors->add( $path, __( 'must be an object.', 'wp-marketing-automations-pro' ) );

					continue;
				}

				$built = 1 === $type
					? self::email_variant( $variant, $path, $templates, $transactional, $budget, $tags, $errors, $warnings )
					: self::text_variant( $variant, $path, 3 === $type, $tags, $errors, $warnings );

				if ( null !== $built ) {
					$content[] = $built['row'];
					$out[]     = array( 'index' => $i ) + $built['out'];
				}
			}
		}

		$smart  = array_key_exists( 'smart_send', $input ) ? self::smart_send( $input['smart_send'], $ab, $variants, $errors ) : null;
		$sender = 1 === $type ? self::email_sender( $input, $stored, $errors ) : self::global_sender_values( $input, $errors );

		if ( $errors->count() > $before || null === $sender ) {
			return null;
		}

		$step3 = array(
			'content'       => $content,
			'senders_name'  => $sender['name'],
			'senders_email' => $sender['email'],
			'replyto'       => $sender['reply_to'],
		);
		if ( null !== $smart ) {
			$step3['smart_send'] = $smart;
		}

		return array(
			'step3'        => $step3,
			'variants_out' => $out,
			'warnings'     => $warnings,
		);
	}

	// ─── global sender and environment ─────────────────────────────

	/** The From name, From email and Reply-To in Settings. */
	public static function global_sender() {
		$settings = class_exists( 'BWFAN_Common' ) && is_callable( array( 'BWFAN_Common', 'get_global_settings' ) ) ? BWFAN_Common::get_global_settings() : array();
		$settings = is_array( $settings ) ? $settings : array();
		$read     = function ( $key ) use ( $settings ) {
			return isset( $settings[ $key ] ) && is_scalar( $settings[ $key ] ) ? (string) $settings[ $key ] : '';
		};

		return array(
			'name'     => $read( 'bwfan_email_from_name' ),
			'email'    => $read( 'bwfan_email_from' ),
			'reply_to' => $read( 'bwfan_email_reply_to' ),
		);
	}

	public static function woocommerce_active() {
		return class_exists( 'WooCommerce' );
	}

	/** @return string[] The broadcast's merge tag names; empty when they cannot be read, which skips the unknown-tag check. */
	private static function tags() {
		if ( ! is_callable( array( 'FKMCP_Pack_Email_Design', 'broadcast_merge_tags' ) ) ) {
			return array();
		}

		try {
			return array_map( 'strval', (array) FKMCP_Pack_Email_Design::broadcast_merge_tags() );
		} catch ( Throwable $e ) {
			return array();
		}
	}

	private static function globals() {
		$globals = is_callable( self::$globals ) ? call_user_func( self::$globals ) : array();
		$globals = is_array( $globals ) ? $globals : array();

		return array(
			'name'     => isset( $globals['name'] ) ? (string) $globals['name'] : '',
			'email'    => isset( $globals['email'] ) ? (string) $globals['email'] : '',
			'reply_to' => isset( $globals['reply_to'] ) ? (string) $globals['reply_to'] : '',
		);
	}

	// ─── A/B, variant list, smart send ─────────────────────────────

	/** @return string|null standard or ab; null after an error. */
	private static function ab_type( array $input, array $stored, FKMCP_Definition_Errors $errors ) {
		if ( array_key_exists( 'ab_type', $input ) ) {
			if ( 'standard' !== $input['ab_type'] && 'ab' !== $input['ab_type'] ) {
				$errors->add( 'ab_type', __( 'must be standard (one variant) or ab (two or three variants).', 'wp-marketing-automations-pro' ), array( 'standard', 'ab' ) );

				return null;
			}

			return $input['ab_type'];
		}

		return isset( $stored['ab_type'] ) && 'ab' === $stored['ab_type'] ? 'ab' : 'standard';
	}

	/** @return array|null The variants to build; null when there is nothing usable to build. */
	private static function variant_list( array $input, $ab, FKMCP_Definition_Errors $errors ) {
		$variants = isset( $input['variants'] ) ? $input['variants'] : null;

		if ( ! is_array( $variants ) || array() === $variants || array_keys( $variants ) !== range( 0, count( $variants ) - 1 ) ) {
			$errors->add( 'variants', __( 'is required: a list of 1 to 3 variant objects.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$count = count( $variants );
		if ( 'standard' === $ab && 1 !== $count ) {
			$errors->add( 'variants', __( 'standard takes exactly 1 variant. For a test of 2 or 3 variants send ab_type ab.', 'wp-marketing-automations-pro' ) );
		} elseif ( 'ab' === $ab && ( $count < 2 || $count > self::MAX_VARIANTS ) ) {
			$errors->add( 'variants', __( 'ab takes 2 or 3 variants. For one variant send ab_type standard.', 'wp-marketing-automations-pro' ) );
		}

		// More than the limit is never built: each design runs the renderer.
		return $count > self::MAX_VARIANTS ? null : $variants;
	}

	/**
	 * Public so an update that keeps the stored content can still check a new smart_send.
	 *
	 * @return array|null {enable, percent, hours}; null when absent or refused.
	 */
	public static function smart_send( $smart, $ab, $variants, FKMCP_Definition_Errors $errors ) {
		if ( ! is_array( $smart ) || array() === $smart ) {
			$errors->add( 'smart_send', __( 'must be an object {percent, hours}. To send one split with no test and winner leave smart_send out.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		if ( 'standard' === $ab ) {
			$errors->add( 'smart_send', __( 'only goes with ab_type ab: a winner needs two or three variants to choose from. Remove smart_send, or send ab_type ab with 2 or 3 variants.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		// A wrong variant count is already reported at variants.
		if ( 'ab' !== $ab || ! is_array( $variants ) || count( $variants ) < 2 ) {
			return null;
		}

		$before = $errors->count();
		self::unknown_keys( $smart, self::SMART_KEYS, 'smart_send', $errors );

		$percent = isset( $smart['percent'] ) ? $smart['percent'] : null;
		$hours   = isset( $smart['hours'] ) ? $smart['hours'] : null;
		if ( ! is_int( $percent ) || $percent < 1 || $percent > 99 ) {
			$errors->add( 'smart_send.percent', __( 'must be a whole number from 1 to 99: the share of contacts that get the test.', 'wp-marketing-automations-pro' ) );
		}
		if ( ! is_int( $hours ) || $hours < 1 || $hours > 168 ) {
			$errors->add( 'smart_send.hours', __( 'must be a whole number of hours from 1 to 168: how long to wait before the winner is sent to the rest.', 'wp-marketing-automations-pro' ) );
		}

		return $errors->count() > $before ? null : array(
			'enable'  => true,
			'percent' => $percent,
			'hours'   => $hours,
		);
	}

	// ─── email variants ────────────────────────────────────────────

	/** Saved templates for every template_id in the call, one lookup. */
	private static function templates( array $variants, FKMCP_Definition_Errors $errors ) {
		$ids = array();
		foreach ( $variants as $variant ) {
			if ( is_array( $variant ) && isset( $variant['template_id'] ) && is_int( $variant['template_id'] ) && $variant['template_id'] > 0 ) {
				$ids[] = $variant['template_id'];
			}
		}

		if ( array() === $ids ) {
			return array();
		}

		if ( ! is_callable( self::$template_loader ) ) {
			$errors->add( 'variants', __( 'this site cannot read saved email templates right now; try again later, or send design.', 'wp-marketing-automations-pro' ) );

			return array();
		}

		try {
			$rows = call_user_func( self::$template_loader, array_values( array_unique( $ids ) ) );
		} catch ( Throwable $e ) {
			$rows = array();
		}

		return is_array( $rows ) ? $rows : array();
	}

	/** @return array{row: array, out: array}|null */
	private static function email_variant( array $v, $path, array $templates, $transactional, $budget, array $tags, FKMCP_Definition_Errors $errors, array &$warnings ) {
		$before = $errors->count();
		self::unknown_keys( $v, self::EMAIL_KEYS, $path, $errors );

		$given = array_values( array_intersect( array( 'design', 'template_id', 'body_html' ), array_keys( $v ) ) );
		if ( 1 !== count( $given ) ) {
			$errors->add( $path, __( 'needs exactly one of design (the block editor, the default), template_id (a saved template) or body_html with format.', 'wp-marketing-automations-pro' ) );
		}
		if ( array_key_exists( 'design_settings', $v ) && ! array_key_exists( 'design', $v ) ) {
			$errors->add( $path . '.design_settings', __( 'only goes with design.', 'wp-marketing-automations-pro' ) );
		}
		if ( array_key_exists( 'body_html', $v ) && ! array_key_exists( 'format', $v ) ) {
			$errors->add( $path . '.format', __( 'is required with body_html. Emails are designed in the block editor by default: send design instead. Use body_html with format rich or html only when the user asked for a rich-text or HTML email.', 'wp-marketing-automations-pro' ), self::FORMATS );
		} elseif ( array_key_exists( 'format', $v ) && ! array_key_exists( 'body_html', $v ) ) {
			$errors->add( $path . '.format', __( 'only goes with body_html. A template sets its own format and a design is always the block editor.', 'wp-marketing-automations-pro' ) );
		}

		$source = 1 === count( $given ) ? $given[0] : '';
		$body   = null;
		switch ( $source ) {
			case 'design':
				$body = self::designed_body( $v, $path, $transactional, $budget, $errors, $warnings );
				break;
			case 'template_id':
				$body = self::template_body( $v['template_id'], $path, $templates, $transactional, $tags, $errors, $warnings );
				break;
			case 'body_html':
				$body = self::html_body( $v, $path, $tags, $errors );
				break;
		}

		// A template that was refused has already said why; its missing subject adds nothing.
		$subject = 'template_id' === $source && null === $body && ! array_key_exists( 'subject', $v ) ? '' : self::subject( $v, $path, null === $body ? '' : $body['subject'], $tags, $errors );

		$preheader = self::preheader( $v, $path, null === $body ? '' : $body['preheader'], $tags, $errors );

		$utm = self::utm( $v, $path, $errors, $warnings );

		if ( $errors->count() > $before || null === $body || null === $utm ) {
			return null;
		}

		$row = array(
			'type'      => $body['type'],
			'subject'   => $subject,
			'preheader' => $preheader,
			'body'      => $body['body'],
		);
		if ( null !== $body['block'] ) {
			$row['block'] = $body['block'];
		}
		$row = $row + self::utm_keys( $utm );

		$out = array(
			'subject'  => $subject,
			'format'   => $body['type'],
			'designed' => null !== $body['block'],
		);
		if ( null !== $body['block'] ) {
			$out['html'] = $body['body'];
		}

		return array( 'row' => $row, 'out' => $out );
	}

	/**
	 * @return array|null {type, body, block, subject, preheader}
	 */
	private static function designed_body( array $v, $path, $transactional, $budget, FKMCP_Definition_Errors $errors, array &$warnings ) {
		$design = $v['design'];
		if ( ! is_array( $design ) || array() === $design || strlen( (string) wp_json_encode( $design ) ) > self::DESIGN_MAX ) {
			$errors->add( $path . '.design', __( 'must be a non-empty block list (the tree create-email-template takes), at most 100 KB.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$settings = array();
		if ( array_key_exists( 'design_settings', $v ) ) {
			if ( ! is_array( $v['design_settings'] ) || strlen( (string) wp_json_encode( $v['design_settings'] ) ) > self::DESIGN_SETTINGS_MAX ) {
				$errors->add( $path . '.design_settings', __( 'must be an object of design settings, at most 20 KB.', 'wp-marketing-automations-pro' ) );

				return null;
			}
			$settings = $v['design_settings'];
		}

		if ( ! is_callable( self::$designer ) ) {
			$errors->add( $path . '.design', __( 'this site cannot build designed emails right now; try again later.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		try {
			$built = call_user_func(
				self::$designer,
				$design,
				$settings,
				array(
					'transactional' => $transactional,
					'budget'        => $budget,
				)
			);
		} catch ( Throwable $e ) {
			$errors->add( $path . '.design', __( 'the design could not be built; check it with audit-email-design.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$copy = self::checked( $built, $path . '.design', $errors, $warnings, $path );
		if ( null === $copy || '' === trim( (string) $copy['html'] ) || empty( $copy['block'] ) ) {
			if ( null !== $copy ) {
				$errors->add( $path . '.design', __( 'built no email; check it with audit-email-design.', 'wp-marketing-automations-pro' ) );
			}

			return null;
		}

		return array(
			'type'      => 'block',
			'body'      => (string) $copy['html'],
			'block'     => self::object_settings( $copy['block'] ),
			'subject'   => '',
			'preheader' => '',
		);
	}

	/**
	 * A designer's or copier's answer: its error, its blocking findings (each one an error at
	 * $path), and its warnings (added to $warnings under $label).
	 *
	 * @return array|null The answer; null after an error.
	 */
	private static function checked( $built, $path, FKMCP_Definition_Errors $errors, array &$warnings, $label ) {
		if ( is_wp_error( $built ) ) {
			$errors->add( $path, FKMCP_Definition_Errors::clean( $built->get_error_message(), 300 ) );

			return null;
		}

		if ( ! is_array( $built ) ) {
			$errors->add( $path, __( 'could not be checked right now; try again later.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		if ( ! empty( $built['blocking'] ) ) {
			foreach ( (array) $built['blocking'] as $finding ) {
				$code    = FKMCP_Definition_Errors::clean( esc_html( isset( $finding['code'] ) ? $finding['code'] : '' ), 100 );
				$where   = FKMCP_Definition_Errors::clean( esc_html( isset( $finding['path'] ) ? $finding['path'] : '' ), 100 );
				$message = FKMCP_Definition_Errors::clean( isset( $finding['message'] ) ? $finding['message'] : '', 300 );
				if ( '' === $where ) {
					/* translators: 1: finding code, 2: message */
					$errors->add( $path, sprintf( __( '%1$s: %2$s', 'wp-marketing-automations-pro' ), $code, $message ) );
				} else {
					/* translators: 1: finding code, 2: where in the design, 3: message */
					$errors->add( $path, sprintf( __( '%1$s at %2$s: %3$s', 'wp-marketing-automations-pro' ), $code, $where, $message ) );
				}
			}

			return null;
		}

		foreach ( isset( $built['warnings'] ) ? (array) $built['warnings'] : array() as $warning ) {
			$warnings[] = $label . ': ' . FKMCP_Definition_Errors::clean( $warning, 300 );
		}

		return $built + array( 'html' => '', 'block' => null );
	}

	/** @return array|null {type, body, block, subject, preheader} */
	private static function template_body( $id, $path, array $templates, $transactional, array $tags, FKMCP_Definition_Errors $errors, array &$warnings ) {
		$at = $path . '.template_id';
		if ( ! is_int( $id ) || ! isset( $templates[ $id ] ) || ! is_array( $templates[ $id ] ) ) {
			$errors->add( $at, __( 'is not a saved email template (list-email-templates).', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$row  = $templates[ $id ];
		$mode = isset( $row['mode'] ) ? (int) $row['mode'] : 0;
		if ( 4 === $mode ) {
			$errors->add( $at, __( 'is a legacy drag-and-drop template; open it in the builder and save it in the block editor first.', 'wp-marketing-automations-pro' ) );

			return null;
		}
		if ( ! isset( self::MODE_TYPES[ $mode ] ) ) {
			$errors->add( $at, __( 'is not a supported template type. Use a template made in the block editor, or send design.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$subject   = isset( $row['subject'] ) ? (string) $row['subject'] : '';
		$html      = isset( $row['template'] ) ? (string) $row['template'] : '';
		$data      = isset( $row['data'] ) && is_string( $row['data'] ) ? json_decode( $row['data'], true ) : ( isset( $row['data'] ) ? $row['data'] : array() );
		$preheader = is_array( $data ) && isset( $data['preheader'] ) && is_string( $data['preheader'] ) ? $data['preheader'] : '';

		if ( 5 === $mode ) {
			if ( ! is_callable( self::$copier ) ) {
				$errors->add( $at, __( 'this site cannot re-check designed email templates right now; try again later.', 'wp-marketing-automations-pro' ) );

				return null;
			}

			try {
				$copy = call_user_func( self::$copier, $row, array( 'transactional' => $transactional ) );
			} catch ( Throwable $e ) {
				$errors->add( $at, __( 'could not be re-checked right now; try again later.', 'wp-marketing-automations-pro' ) );

				return null;
			}

			$copy = self::checked( $copy, $at, $errors, $warnings, $path );
			if ( null === $copy ) {
				return null;
			}

			$stored = (string) $copy['html'];
			if ( '' === trim( $stored ) || empty( $copy['block'] ) ) {
				$errors->add( $at, __( 'has no design; open it in the block editor and save it first.', 'wp-marketing-automations-pro' ) );

				return null;
			}
			if ( ! FKMCP_Pack_Email_Design::footer_ok( $stored ) ) {
				$errors->add( $at, self::footer_message( __( 'The template', 'wp-marketing-automations-pro' ) ) );

				return null;
			}

			return array(
				'type'      => 'block',
				'body'      => $stored,
				'block'     => self::object_settings( $copy['block'] ),
				'subject'   => $subject,
				'preheader' => $preheader,
			);
		}

		if ( 2 === $mode && ! ( is_callable( self::$woocommerce ) && call_user_func( self::$woocommerce ) ) ) {
			$errors->add( $at, __( 'is a WooCommerce email template, and WooCommerce is not active.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		// The same check body_html gets: a saved body may name tags only an automation provides.
		$before = $errors->count();
		self::check_tags( $html, $tags, $at, $errors );
		$body = $errors->count() > $before ? null : self::plain_body( $html, 3 === $mode ? 'html' : 'rich', $at, __( 'The template', 'wp-marketing-automations-pro' ), $errors );

		return null === $body ? null : array(
			'type'      => self::MODE_TYPES[ $mode ],
			'body'      => $body,
			'block'     => null,
			'subject'   => $subject,
			'preheader' => $preheader,
		);
	}

	/** @return array|null {type, body, block, subject, preheader} */
	private static function html_body( array $v, $path, array $tags, FKMCP_Definition_Errors $errors ) {
		$at = $path . '.body_html';
		if ( ! is_string( $v['body_html'] ) ) {
			$errors->add( $at, __( 'must be HTML text.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$format = isset( $v['format'] ) ? $v['format'] : null;
		if ( array_key_exists( 'format', $v ) && ! in_array( $format, self::FORMATS, true ) ) {
			$errors->add( $path . '.format', __( 'must be rich or html. For a block design send design; for a saved WooCommerce template send template_id.', 'wp-marketing-automations-pro' ), self::FORMATS );

			return null;
		}

		self::check_tags( $v['body_html'], $tags, $at, $errors );

		$body = null === $format ? null : self::plain_body( $v['body_html'], $format, $at, __( 'The email body', 'wp-marketing-automations-pro' ), $errors );

		return null === $body ? null : array(
			'type'      => $format,
			'body'      => $body,
			'block'     => null,
			'subject'   => '',
			'preheader' => '',
		);
	}

	/**
	 * A body the agent or a legacy template supplied: kses, the entity-decoded forbidden-markup
	 * check the automation step runs, and the broadcast footer rule.
	 *
	 * @return string|null The body as it is stored; null after an error.
	 */
	private static function plain_body( $html, $format, $path, $who, FKMCP_Definition_Errors $errors ) {
		$html = (string) $html;
		if ( '' === trim( $html ) || strlen( $html ) > self::BODY_MAX ) {
			$errors->add( $path, __( 'is empty or larger than 200 KB.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		self::load( 'BWFCRM_Email_Design_Tree', '/crm/includes/block-editor/email-design/class-bwfcrm-email-design-tree.php' );
		self::load( 'FKMCP_Step_Builder', '/includes/mcp/automation/class-fkmcp-step-builder.php' );

		$clean = 'html' === $format ? wp_kses( $html, FKMCP_Step_Builder::email_html() ) : wp_kses_post( $html );

		// Lite's send path decodes entities in the whole body, so entity-encoded markup becomes live.
		// Every "<" kses left opens a tag it accepted; blank those and read what decoding can still turn into markup.
		if ( BWFCRM_Email_Design_Tree::forbidden_markup( str_replace( '<', ' ', $clean ) ) ) {
			$errors->add( $path, __( 'holds entity-encoded markup (a script, style, frame or form tag, an event handler, or a javascript:, vbscript: or data: link) that becomes live when the email is sent; remove it.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		if ( ! FKMCP_Pack_Email_Design::footer_ok( $clean ) ) {
			$errors->add( $path, self::footer_message( $who ) );

			return null;
		}

		return $clean;
	}

	private static function footer_message( $who ) {
		/* translators: %s: what is missing the footer, e.g. "The email body" */
		return sprintf( __( '%s needs {{mail_footer}}, or {{unsubscribe_link}}, {{business_name}} and {{business_address}}, because a broadcast email must carry its unsubscribe footer.', 'wp-marketing-automations-pro' ), $who );
	}

	private static function subject( array $v, $path, $default, array $tags, FKMCP_Definition_Errors $errors ) {
		$given = array_key_exists( 'subject', $v );
		if ( $given && ! is_string( $v['subject'] ) ) {
			$errors->add( $path . '.subject', __( 'is required: the email subject as text, at most 255 characters.', 'wp-marketing-automations-pro' ) );

			return '';
		}

		if ( $given && '' !== trim( $v['subject'] ) && sanitize_text_field( $v['subject'] ) !== trim( $v['subject'] ) ) {
			$errors->add( $path . '.subject', __( 'contains HTML, control characters or repeated whitespace that would be changed when saved; remove them.', 'wp-marketing-automations-pro' ) );

			return '';
		}

		$subject = sanitize_text_field( $given ? $v['subject'] : $default );
		if ( '' !== $subject && mb_strlen( $subject ) <= self::SUBJECT_MAX ) {
			self::check_tags( $subject, $tags, $given ? $path . '.subject' : $path . '.template_id', $errors );

			return $subject;
		}

		if ( ! $given && array_key_exists( 'template_id', $v ) && '' === $subject ) {
			$errors->add( $path . '.template_id', __( 'has no subject: send subject too.', 'wp-marketing-automations-pro' ) );
		} elseif ( ! $given && array_key_exists( 'template_id', $v ) ) {
			$errors->add( $path . '.template_id', __( 'has a subject longer than 255 characters: send subject too.', 'wp-marketing-automations-pro' ) );
		} else {
			$errors->add( $path . '.subject', __( 'is required: the email subject as text, at most 255 characters.', 'wp-marketing-automations-pro' ) );
		}

		return '';
	}

	/**
	 * The variant's preheader, or the saved template's when the variant sends none. A saved one is
	 * the template's own data: it is cleaned, not refused, and a problem in it is reported at template_id.
	 */
	private static function preheader( array $v, $path, $default, array $tags, FKMCP_Definition_Errors $errors ) {
		if ( array_key_exists( 'preheader', $v ) ) {
			$at = $path . '.preheader';
			if ( ! is_string( $v['preheader'] ) || mb_strlen( $v['preheader'] ) > self::SUBJECT_MAX ) {
				$errors->add( $at, __( 'must be text of at most 255 characters.', 'wp-marketing-automations-pro' ) );

				return '';
			}
			if ( '' !== trim( $v['preheader'] ) && sanitize_text_field( $v['preheader'] ) !== trim( $v['preheader'] ) ) {
				$errors->add( $at, __( 'contains HTML, control characters or repeated whitespace that would be changed when saved; remove them.', 'wp-marketing-automations-pro' ) );

				return '';
			}
		} else {
			$at = $path . '.template_id';
			if ( mb_strlen( $default ) > self::SUBJECT_MAX ) {
				$errors->add( $at, __( 'has a preheader longer than 255 characters: send preheader too.', 'wp-marketing-automations-pro' ) );

				return '';
			}
		}

		$preheader = sanitize_text_field( array_key_exists( 'preheader', $v ) ? $v['preheader'] : $default );
		self::check_tags( $preheader, $tags, $at, $errors );

		return $preheader;
	}

	// ─── SMS and WhatsApp variants ─────────────────────────────────

	/** @return array{row: array, out: array}|null */
	private static function text_variant( array $v, $path, $whatsapp, array $tags, FKMCP_Definition_Errors $errors, array &$warnings ) {
		$before = $errors->count();
		self::unknown_keys( $v, $whatsapp ? self::WHATSAPP_KEYS : self::TEXT_KEYS, $path, $errors );

		$body = self::text_body( $v, $path, $whatsapp, $tags, $errors );
		$utm  = self::utm( $v, $path, $errors, $warnings );
		$img  = $whatsapp && array_key_exists( 'image', $v ) ? self::image( $v['image'], $path . '.image', $errors ) : null;

		if ( $errors->count() > $before || null === $body || null === $utm ) {
			return null;
		}

		$row = array(
			'body' => $body,
			'type' => 'block',
		) + self::utm_keys( $utm );

		if ( null !== $img ) {
			$row['whatsAppImage']        = true;
			$row['whatsAppImageSetting'] = $img;
		}

		return array(
			'row' => $row,
			'out' => array(
				'format'   => 'text',
				'designed' => false,
			),
		);
	}

	private static function text_body( array $v, $path, $whatsapp, array $tags, FKMCP_Definition_Errors $errors ) {
		$at = $path . '.body';
		if ( ! isset( $v['body'] ) || ! is_string( $v['body'] ) ) {
			$errors->add( $at, __( 'is required: the message as plain text, 1 to 1600 characters.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		if ( '' === trim( $v['body'] ) ) {
			$errors->add( $at, __( 'is required: the message as plain text, 1 to 1600 characters.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$body = sanitize_textarea_field( $v['body'] );
		if ( $body !== trim( $v['body'] ) ) {
			$errors->add( $at, __( 'is plain text: remove HTML or control characters, which would be changed when saved.', 'wp-marketing-automations-pro' ) );

			return null;
		}
		if ( mb_strlen( $body ) > self::TEXT_MAX ) {
			/* translators: %d: character count */
			$errors->add( $at, sprintf( __( 'is %d characters; the limit is 1600.', 'wp-marketing-automations-pro' ), mb_strlen( $body ) ) );

			return null;
		}

		$before = $errors->count();
		if ( false !== strpos( $body, '{{' ) && preg_match_all( '/\{\{(.*?)\}\}/s', $body, $m ) ) {
			foreach ( array_unique( $m[1] ) as $inner ) {
				$tag = strtok( trim( $inner ), " \t\n" );
				if ( false !== $tag && in_array( strtolower( $tag ), self::EMAIL_ONLY_TAGS, true ) ) {
					/* translators: 1: merge tag name, 2: channel name */
					$errors->add( $at, sprintf( __( 'uses {{%1$s}}, which is email-only. Leave it out of %2$s.', 'wp-marketing-automations-pro' ), mb_substr( sanitize_key( $tag ), 0, 80 ), $whatsapp ? __( 'a WhatsApp message', 'wp-marketing-automations-pro' ) : __( 'an SMS message', 'wp-marketing-automations-pro' ) ) );
				}
			}
		}
		if ( $errors->count() > $before ) {
			return null;
		}

		self::check_tags( $body, $tags, $at, $errors );

		return $errors->count() > $before ? null : $body;
	}

	/** @return array|null {position, imageURL} */
	private static function image( $image, $path, FKMCP_Definition_Errors $errors ) {
		if ( ! is_array( $image ) || array() === $image ) {
			$errors->add( $path, __( 'must be an object {url, position?}.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$before = $errors->count();
		self::unknown_keys( $image, array( 'url', 'position' ), $path, $errors );

		$position = 'after';
		if ( array_key_exists( 'position', $image ) ) {
			if ( 'after' !== $image['position'] && 'before' !== $image['position'] ) {
				$errors->add( $path . '.position', __( 'must be after (the default) or before the message text.', 'wp-marketing-automations-pro' ), array( 'after', 'before' ) );
			} else {
				$position = $image['position'];
			}
		}

		$url = isset( $image['url'] ) && is_string( $image['url'] ) ? trim( $image['url'] ) : '';
		if ( '' === $url || strlen( $url ) > self::URL_MAX || ! preg_match( '#^https?://[^\x00-\x20<>"\\\\]+$#i', $url ) || ! wp_http_validate_url( $url ) ) {
			$errors->add( $path . '.url', __( 'must be a public http or https address of an image, at most 2000 characters.', 'wp-marketing-automations-pro' ) );
		}

		return $errors->count() > $before ? null : array(
			'position' => $position,
			'imageURL' => $url,
		);
	}

	// ─── UTM ───────────────────────────────────────────────────────

	/**
	 * @return array|null {enabled: bool, utm: array}; null after an error. Enabled only when source and
	 *                    medium are both given, as the wizard requires; a partial utm is dropped with a warning.
	 */
	private static function utm( array $v, $path, FKMCP_Definition_Errors $errors, array &$warnings ) {
		$off = array( 'enabled' => false, 'utm' => array() );
		if ( ! array_key_exists( 'utm', $v ) ) {
			return $off;
		}

		$at = $path . '.utm';
		if ( ! is_array( $v['utm'] ) ) {
			$errors->add( $at, __( 'must be an object {source, medium, name?, term?, content?}.', 'wp-marketing-automations-pro' ) );

			return null;
		}
		if ( array() === $v['utm'] ) {
			return $off;
		}

		$before = $errors->count();
		self::unknown_keys( $v['utm'], self::UTM_KEYS, $at, $errors );

		$values = array();
		foreach ( self::UTM_KEYS as $key ) {
			$value = '';
			if ( isset( $v['utm'][ $key ] ) ) {
				if ( ! is_string( $v['utm'][ $key ] ) ) {
					$errors->add( $at . '.' . $key, __( 'must be text.', 'wp-marketing-automations-pro' ) );
				} else {
					// Lite adds these to every link's query string and href without encoding them.
					$value = str_replace( ' ', '+', trim( $v['utm'][ $key ] ) );
					if ( '' !== $value && ! preg_match( self::UTM_PATTERN, $value ) ) {
						$errors->add( $at . '.' . $key, __( 'must be 1 to 100 characters: use letters, digits and _ - . + only.', 'wp-marketing-automations-pro' ) );
						$value = '';
					}
				}
			}
			$values[ $key ] = $value;
		}

		if ( $errors->count() > $before ) {
			return null;
		}

		if ( '' === $values['source'] || '' === $values['medium'] ) {
			/* translators: %s: path of the variant */
			$warnings[] = sprintf( __( '%s: UTM tracking is off because it needs both source and medium.', 'wp-marketing-automations-pro' ), $path );

			return $off;
		}

		return array( 'enabled' => true, 'utm' => $values );
	}

	private static function utm_keys( array $utm ) {
		return $utm['enabled'] ? array( 'utmEnabled' => true, 'utm' => $utm['utm'] ) : array( 'utmEnabled' => false );
	}

	// ─── sender ────────────────────────────────────────────────────

	/**
	 * Public so an update that keeps the stored content can still merge a new sender over the stored one.
	 *
	 * @return array{name: string, email: string, reply_to: string}|null
	 */
	public static function email_sender( array $input, array $stored, FKMCP_Definition_Errors $errors ) {
		$sender = array_key_exists( 'sender', $input ) ? $input['sender'] : array();
		if ( ! is_array( $sender ) ) {
			$errors->add( 'sender', __( 'must be an object {name, email, reply_to}.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$before = $errors->count();
		self::unknown_keys( $sender, self::SENDER_KEYS, 'sender', $errors );
		foreach ( self::SENDER_KEYS as $key ) {
			if ( array_key_exists( $key, $sender ) && ! is_string( $sender[ $key ] ) ) {
				$errors->add( 'sender.' . $key, __( 'must be text.', 'wp-marketing-automations-pro' ) );
			}
		}
		if ( $errors->count() > $before ) {
			return null;
		}

		$globals  = self::globals();
		$pick     = function ( $key, $stored_key, $keep_empty ) use ( $sender, $stored, $globals ) {
			if ( array_key_exists( $key, $sender ) ) {
				return trim( $sender[ $key ] );
			}
			if ( isset( $stored[ $stored_key ] ) && is_string( $stored[ $stored_key ] ) && ( $keep_empty || '' !== trim( $stored[ $stored_key ] ) ) ) {
				return trim( $stored[ $stored_key ] );
			}

			return trim( $globals[ $key ] );
		};
		$name     = sanitize_text_field( $pick( 'name', 'senders_name', false ) );
		$email    = $pick( 'email', 'senders_email', false );
		$reply_to = $pick( 'reply_to', 'replyto', true );

		if ( '' === $name || mb_strlen( $name ) > self::NAME_MAX ) {
			$errors->add( 'sender', __( 'has no usable From name (1 to 255 characters). Send sender.name, or set the From name in Settings so every broadcast has one.', 'wp-marketing-automations-pro' ) );
		}
		if ( strlen( $email ) > 254 || ! is_email( $email ) ) {
			$errors->add( 'sender', __( 'has no valid From email. Send sender.email, or set the From email in Settings.', 'wp-marketing-automations-pro' ) );
		}
		if ( '' !== $reply_to && ( strlen( $reply_to ) > 254 || ! is_email( $reply_to ) ) ) {
			$errors->add( 'sender', __( 'reply_to is not a valid email. Send sender.reply_to as an email or an empty string, or fix the Reply-To in Settings.', 'wp-marketing-automations-pro' ) );
		}

		return $errors->count() > $before ? null : array(
			'name'     => $name,
			'email'    => $email,
			'reply_to' => $reply_to,
		);
	}

	/** SMS and WhatsApp: the wizard posts the global values, whatever they are. */
	public static function global_sender_values( array $input, FKMCP_Definition_Errors $errors ) {
		if ( array_key_exists( 'sender', $input ) ) {
			$errors->add( 'sender', __( 'only applies to email. SMS and WhatsApp broadcasts use the From name, email and Reply-To in Settings; leave sender out.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		return self::globals();
	}

	// ─── shared ────────────────────────────────────────────────────

	/**
	 * A block's settings stored as an object, so an empty set encodes as {} (the editor reads an
	 * object) and not []. Everything else in the block is left exactly as it came.
	 *
	 * @param array|object $block
	 *
	 * @return array|object
	 */
	private static function object_settings( $block ) {
		if ( is_object( $block ) ) {
			if ( isset( $block->settings ) && is_array( $block->settings ) ) {
				$block           = clone $block;
				$block->settings = (object) $block->settings;
			}

			return $block;
		}

		if ( isset( $block['settings'] ) && is_array( $block['settings'] ) ) {
			$block['settings'] = (object) $block['settings'];
		}

		return $block;
	}

	private static function unknown_keys( array $given, array $allowed, $path, FKMCP_Definition_Errors $errors ) {
		foreach ( array_keys( $given ) as $key ) {
			if ( ! in_array( $key, $allowed, true ) ) {
				$errors->add( $path . '.' . $key, __( 'is not a field of this object.', 'wp-marketing-automations-pro' ), $allowed );
			}
		}
	}

	/** Each merge tag named in $text must be one the broadcast knows. Skipped when the list could not be read. */
	private static function check_tags( $text, array $allowed, $path, FKMCP_Definition_Errors $errors ) {
		if ( array() === $allowed || false === strpos( (string) $text, '{{' ) || ! preg_match_all( '/\{\{(.*?)\}\}/s', (string) $text, $m ) ) {
			return;
		}

		foreach ( array_unique( $m[1] ) as $inner ) {
			$tag = strtok( trim( $inner ), " \t\n" );
			if ( false === $tag || '' === $tag || in_array( $tag, $allowed, true ) ) {
				continue;
			}

			/* translators: %s: merge tag name */
			$errors->add( $path, sprintf( __( 'uses the merge tag {{%s}}, which a broadcast does not provide. Use the contact, contact field and general tags.', 'wp-marketing-automations-pro' ), mb_substr( sanitize_key( substr( $tag, 0, 64 ) ), 0, 80 ) ) );
		}
	}

	private static function load( $class, $file ) {
		if ( ! class_exists( $class, false ) ) {
			require_once BWFAN_PRO_PLUGIN_DIR . $file; // one class, no side effects
		}
	}
}
