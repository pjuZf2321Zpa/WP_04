<?php

defined( 'ABSPATH' ) || exit;

/**
 * The audience of a broadcast draft made over MCP: inline filters, a copy of
 * a saved audience, or an explicit "all contacts".
 *
 * The contact query drops a condition it cannot read, and a broadcast with no
 * surviving condition goes to everyone. So nothing here is skipped or guessed:
 * a condition is either stored exactly as the engine reads it, or the whole
 * call is refused with the path of the problem.
 */
class FKMCP_Broadcast_Audience {
	const MAX_GROUPS = 10;

	const MAX_CONDITIONS = 10;

	/** Ids in one Search condition: each may cost a lookup. */
	const MAX_IDS = 50;

	/** Ids in all the Search conditions of one audience together. */
	const MAX_TOTAL_IDS = 100;

	/** Filters the contact query drops when they are given more than one id: slug => what the id is. */
	const SINGLE_ID = array( 'wlm_level' => 'membership level' );

	const TEXT_LIMIT = 200;

	const LINE_LIMIT = 300;

	/** Days: the ceiling when the filter names none (a century). */
	const MAX_DAYS = 36500;

	/**
	 * Text the contact query searches its own WHERE clause for, to decide whether to add
	 * the forced status and unsubscribe rules. A stored value is part of that clause, so
	 * a value holding one of these switches the rules off for the whole broadcast.
	 */
	const ENGINE_MARKERS = array( 'c.status', 'bwfan_message_unsubscribe' );

	/** @var callable|null fn(): array. The filter registry, as BWFCRM_Load_Filters::get_filters() returns it. */
	public static $catalogue = null;

	/** @var callable|null fn( string $slug, string[] $keys ): array<string, string>. The keys that exist, with their labels. */
	public static $lookup = null;

	/** @var callable|null fn( int $id ): array{name: string, filters: mixed}|null. A saved audience. */
	public static $audience = null;

	/** @var callable|null fn( array $row_like ): int. The recipient count. */
	public static $counter = null;

	/** @var int Search ids seen in the audience being checked. */
	private static $ids = 0;

	/**
	 * @param array                   $input  The tool input: exactly one of filters, audience_id, all_contacts.
	 * @param FKMCP_Definition_Errors $errors
	 *
	 * @return array{mode: string, filters: array, removed: string[], summary: string[]}|null Null when an error was added.
	 */
	public static function resolve( array $input, FKMCP_Definition_Errors $errors ) {
		$given = array();
		foreach ( array( 'filters', 'audience_id', 'all_contacts' ) as $key ) {
			if ( isset( $input[ $key ] ) ) {
				$given[] = $key;
			}
		}

		if ( 1 !== count( $given ) ) {
			$errors->add( 'audience', __( 'Pass exactly one of filters, audience_id or all_contacts: true, and leave the other two out. To send to every eligible contact pass all_contacts: true.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		if ( 'all_contacts' === $given[0] ) {
			if ( true !== $input['all_contacts'] ) {
				$errors->add( 'all_contacts', __( 'all_contacts must be the boolean true. To target fewer contacts leave it out and pass filters or audience_id.', 'wp-marketing-automations-pro' ) );

				return null;
			}

			return array(
				'mode'    => 'all_contacts',
				'filters' => array(),
				'removed' => array(),
				'summary' => array( __( 'All contacts', 'wp-marketing-automations-pro' ) ),
			);
		}

		if ( 'filters' === $given[0] ) {
			if ( array() === $input['filters'] ) {
				$errors->add( 'filters', __( 'filters is empty. To send to every eligible contact pass all_contacts: true instead; otherwise add at least one group with one condition.', 'wp-marketing-automations-pro' ) );

				return null;
			}

			$catalogue = self::catalogue();
			$filters   = self::check( $input['filters'], 'filters', $errors, $catalogue, true );

			return null === $filters ? null : array(
				'mode'    => 'filters',
				'filters' => $filters,
				'removed' => array(),
				'summary' => self::summary( $filters, $catalogue ),
			);
		}

		$id = $input['audience_id'];
		if ( ! ( is_int( $id ) || ( is_string( $id ) && ctype_digit( $id ) ) ) || (int) $id < 1 ) {
			$errors->add( 'audience_id', __( 'audience_id must be a positive integer. Call list-audiences for valid ids.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$saved = self::load_audience( (int) $id );
		if ( ! is_array( $saved ) ) {
			$errors->add( 'audience_id', __( 'No saved audience with that id. Call list-audiences for valid ids.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$stored = isset( $saved['filters'] ) ? $saved['filters'] : array();
		if ( ! is_array( $stored ) || array() === $stored ) {
			$errors->add( 'audience_id', __( 'This saved audience has no conditions. To send to every eligible contact pass all_contacts: true instead.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		if ( ! self::is_list( $stored ) ) {
			$errors->add( 'audience_id', __( 'This saved audience is stored in an old format that cannot be copied safely. Open it in the admin and re-save it, or pass filters instead.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$catalogue = self::catalogue();
		$removed   = array();
		$kept      = self::strip( $stored, $catalogue, $removed );

		if ( array() === $kept ) {
			$errors->add( 'audience_id', __( 'Nothing is left of this saved audience once its status conditions and unavailable filters are removed, so it would go to everyone. Pass all_contacts: true if that is intended, or pass filters.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$filters = self::check( $kept, 'audience_id.filters', $errors, $catalogue, false );

		return null === $filters ? null : array(
			'mode'    => 'audience',
			'filters' => $filters,
			'removed' => $removed,
			'summary' => self::summary( $filters, $catalogue ),
		);
	}

	/**
	 * @param mixed                   $filters OR-groups of AND-conditions {filter, rule, data}.
	 * @param string                  $path    Where the filters sit in the input, for error paths.
	 * @param FKMCP_Definition_Errors $errors
	 *
	 * @return array|null The filters as the engine and the wizard store them, or null when an error was added.
	 */
	public static function validate_filters( $filters, $path, FKMCP_Definition_Errors $errors ) {
		return self::check( $filters, (string) $path, $errors, self::catalogue(), true );
	}

	/**
	 * validate_filters() for a saved audience: the same checks, a status condition refused with
	 * $status_message, and the readable summary from the same catalogue read.
	 *
	 * @param mixed                   $filters
	 * @param string                  $path
	 * @param FKMCP_Definition_Errors $errors
	 * @param string                  $status_message Why a status condition is refused here.
	 *
	 * @return array{filters: array, summary: string[]}|null Null when an error was added.
	 */
	public static function validate_for_audience( $filters, $path, FKMCP_Definition_Errors $errors, $status_message ) {
		$catalogue = self::catalogue();
		$clean     = self::check( $filters, (string) $path, $errors, $catalogue, true, (string) $status_message );

		return null === $clean ? null : array(
			'filters' => $clean,
			'summary' => self::summary( $clean, $catalogue ),
		);
	}

	/**
	 * validate_filters() for a Bulk Actions run: the same checks and the same stored shape
	 * (a Search filter's data as [{key, label}], as the admin wizard saves it), with a
	 * status condition allowed - a bulk run has no unsubscribe rules of its own to switch off.
	 *
	 * @param mixed                   $filters
	 * @param string                  $path
	 * @param FKMCP_Definition_Errors $errors
	 *
	 * @return array|null The filters as the engine and the admin store them, or null when an error was added.
	 */
	public static function validate_for_bulk( $filters, $path, FKMCP_Definition_Errors $errors ) {
		return self::check( $filters, (string) $path, $errors, self::catalogue(), true, '', true );
	}

	/**
	 * The number of contacts the send would reach, by the send path's own arguments. Reads only.
	 *
	 * @param array $row_like {id, type, parent: 0, data: {filters, exclude, is_promotional, includeSoftBounce, includeUnverified}}.
	 *
	 * @return int
	 */
	public static function count( array $row_like ) {
		if ( is_callable( self::$counter ) ) {
			return (int) call_user_func( self::$counter, $row_like );
		}

		if ( ! class_exists( 'BWFCRM_Broadcast_Helper' ) || ! class_exists( 'BWFCRM_Contact' ) ) {
			return 0;
		}

		$args = BWFCRM_Broadcast_Helper::get_broadcast_query_args( $row_like );
		if ( ! is_array( $args ) ) {
			return 0;
		}

		if ( ! isset( $args['props']['exclude_unsubs'] ) || false === $args['props']['exclude_unsubs'] ) {
			$args['props']['exclude_unsubs'] = apply_filters( 'bwfan_force_exclude_unsubscribe_contact', false );
		}

		// Without only_count a limit of 0 loads every matching contact.
		$args['props']['only_count'] = true;

		$res = BWFCRM_Contact::get_contacts( '', 0, 0, $args['filters'], $args['props'] );

		return isset( $res['total_count'] ) ? (int) $res['total_count'] : 0;
	}

	/**
	 * @param bool $strict_list True for caller input, which must be plain lists. A stripped saved
	 *                          audience keeps its original indexes so the paths still point at it.
	 */
	private static function check( $filters, $path, FKMCP_Definition_Errors $errors, array $catalogue, $strict_list, $status_message = '', $allow_status = false ) {
		$before = $errors->count();

		if ( array() === $catalogue ) {
			$errors->add( $path, __( 'The contact filters are not available on this site, so an audience cannot be checked. Pass all_contacts: true, or try again once FunnelKit Automations Pro is fully loaded.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		if ( ! is_array( $filters ) || ( $strict_list && ! self::is_list( $filters ) ) || array() === $filters ) {
			$errors->add( $path, __( 'filters must be a list of groups, each a list of conditions: [[{filter, rule, data}]].', 'wp-marketing-automations-pro' ) );

			return null;
		}

		if ( count( $filters ) > self::MAX_GROUPS ) {
			/* translators: %d: the most groups allowed */
			$errors->add( $path, sprintf( __( 'At most %d groups are allowed. Merge groups, or save the audience in the admin.', 'wp-marketing-automations-pro' ), self::MAX_GROUPS ) );

			return null;
		}

		$clean     = array();
		self::$ids = 0;

		foreach ( $filters as $g => $group ) {
			$group_path = $path . '[' . $g . ']';

			if ( ! is_array( $group ) || ( $strict_list && ! self::is_list( $group ) ) ) {
				$errors->add( $group_path, __( 'Each entry of filters must be a group: a list of conditions. Wrap this condition in a list, e.g. [[{filter, rule, data}]].', 'wp-marketing-automations-pro' ) );
				continue;
			}

			if ( array() === $group ) {
				$errors->add( $group_path, __( 'This group is empty, and an empty group matches every contact. Remove it or add a condition.', 'wp-marketing-automations-pro' ) );
				continue;
			}

			if ( count( $group ) > self::MAX_CONDITIONS ) {
				/* translators: %d: the most conditions allowed in a group */
				$errors->add( $group_path, sprintf( __( 'At most %d conditions are allowed in a group. Remove some, or save the audience in the admin.', 'wp-marketing-automations-pro' ), self::MAX_CONDITIONS ) );
				continue;
			}

			$clean_group = array();
			foreach ( $group as $c => $condition ) {
				$one = self::condition( $condition, $group_path . '[' . $c . ']', $errors, $catalogue, $status_message, $allow_status );
				if ( null !== $one ) {
					$clean_group[] = $one;
				}
			}

			$clean[] = $clean_group;
		}

		if ( self::$ids > self::MAX_TOTAL_IDS ) {
			/* translators: %d: the most ids allowed in one audience */
			$errors->add( $path, sprintf( __( 'too many ids in one audience (max %d); use a tag, list or saved audience for larger sets', 'wp-marketing-automations-pro' ), self::MAX_TOTAL_IDS ) );
		}

		return $errors->count() > $before ? null : $clean;
	}

	/** One condition, normalised, or null when an error was added. */
	private static function condition( $condition, $path, FKMCP_Definition_Errors $errors, array $catalogue, $status_message = '', $allow_status = false ) {
		if ( ! is_array( $condition ) ) {
			$errors->add( $path, __( 'A condition must be an object {filter, rule, data}.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$extra = array_diff( array_map( 'strval', array_keys( $condition ) ), array( 'filter', 'rule', 'data' ) );
		if ( $extra ) {
			/* translators: %s: the unexpected keys */
			$errors->add( $path, sprintf( __( 'A condition takes only filter, rule and data. Remove: %s.', 'wp-marketing-automations-pro' ), implode( ', ', array_slice( $extra, 0, 5 ) ) ) );

			return null;
		}

		$slug = isset( $condition['filter'] ) ? $condition['filter'] : null;
		if ( ! is_string( $slug ) || '' === $slug ) {
			$errors->add( $path . '.filter', __( 'filter must be a filter slug. Call list-contact-filters for the valid slugs.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		if ( 'status' === $slug && ! $allow_status ) {
			$errors->add( $path . '.filter', '' !== $status_message ? $status_message : __( 'status cannot be filtered in a broadcast: the broadcast decides it from promotional, include_unverified and include_soft_bounce. Build status-based audiences in the admin.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		if ( ! isset( $catalogue[ $slug ] ) ) {
			$errors->add(
				$path . '.filter',
				/* translators: %s: the filter slug given */
				sprintf( __( '"%s" is not a filter on this site (a removed custom field or an inactive plugin, perhaps). Call list-contact-filters for the valid slugs.', 'wp-marketing-automations-pro' ), $slug ),
				$errors->full() ? null : self::closest( $slug, array_keys( $catalogue ) )
			);

			return null;
		}

		$def       = $catalogue[ $slug ];
		$type      = $def['type'];
		$operators = $def['operators'];

		if ( ! in_array( $type, array( 'Search', 'Select', 'Text', 'Number', 'Days', 'Date' ), true ) ) {
			/* translators: 1: filter slug, 2: its type */
			$errors->add( $path . '.filter', sprintf( __( 'Filter %1$s (type %2$s) cannot be set here. Build an audience with it in the admin and pass its audience_id, or use another filter.', 'wp-marketing-automations-pro' ), $slug, $type ) );

			return null;
		}

		$rule = array_key_exists( 'rule', $condition ) && null !== $condition['rule'] ? $condition['rule'] : '';
		if ( array() === $operators ) {
			if ( '' !== $rule ) {
				/* translators: %s: filter slug */
				$errors->add( $path . '.rule', sprintf( __( 'Filter %s takes no rule. Leave rule out or pass "".', 'wp-marketing-automations-pro' ), $slug ) );

				return null;
			}
		} elseif ( ! is_string( $rule ) || ! isset( $operators[ $rule ] ) ) {
			/* translators: %s: filter slug */
			$errors->add( $path . '.rule', sprintf( __( 'rule must be one of the operators of filter %s.', 'wp-marketing-automations-pro' ), $slug ), array_map( 'strval', array_keys( $operators ) ) );

			return null;
		}

		$data  = array_key_exists( 'data', $condition ) ? $condition['data'] : null;
		$empty = null === $data || '' === $data || array() === $data;

		if ( 'is_blank' === $rule || 'is_not_blank' === $rule ) {
			if ( ! $empty ) {
				/* translators: %s: the operator */
				$errors->add( $path . '.data', sprintf( __( 'The %s rule takes no data. Leave data out.', 'wp-marketing-automations-pro' ), $rule ) );

				return null;
			}

			return array( 'filter' => $slug, 'rule' => $rule, 'data' => '' );
		}

		if ( $empty ) {
			$errors->add( $path . '.data', __( 'data is required: a condition with no value matches every contact.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$data = self::data( $slug, $def, $rule, $data, $path . '.data', $errors );
		if ( null === $data ) {
			return null;
		}

		// Last, on the value exactly as it will be stored: whatever its type, and whether typed or read from the site.
		if ( self::has_marker( $data ) ) {
			$errors->add( $path . '.data', __( 'This value is not allowed: it contains "c.status" or "bwfan_message_unsubscribe", which the contact query reads as its own status and unsubscribe rules. Use a different value.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		return array( 'filter' => $slug, 'rule' => $rule, 'data' => $data );
	}

	/** The value as the engine reads it, or null when an error was added. */
	private static function data( $slug, array $def, $rule, $data, $path, FKMCP_Definition_Errors $errors ) {
		$range = 'between' === $rule || 'not_between' === $rule;

		switch ( $def['type'] ) {
			case 'Search':
				return self::search_data( $slug, $def, $data, $path, $errors );

			case 'Select':
				$given = is_string( $data ) || is_int( $data ) ? (string) $data : null;
				if ( null === $given || ! isset( $def['options'][ $given ] ) ) {
					/* translators: %s: filter slug */
					$errors->add( $path, sprintf( __( 'data must be one option value of filter %s (the value, not its label).', 'wp-marketing-automations-pro' ), $slug ), array_map( 'strval', array_keys( $def['options'] ) ) );

					return null;
				}

				return $given;

			case 'Text':
				$data = is_int( $data ) ? (string) $data : $data;
				if ( ! is_string( $data ) || '' === trim( $data ) || mb_strlen( $data ) > self::TEXT_LIMIT ) {
					/* translators: %d: the most characters allowed */
					$errors->add( $path, sprintf( __( 'data must be a non-empty string of at most %d characters.', 'wp-marketing-automations-pro' ), self::TEXT_LIMIT ) );

					return null;
				}

				// The engine splits a text value on commas, and an empty piece matches every contact.
				foreach ( explode( ',', $data ) as $piece ) {
					if ( '' === trim( $piece ) ) {
						$errors->add( $path, __( 'A comma in a text value separates alternatives, and one of them is empty here, which would match every contact. Remove the stray comma, or put a value on each side of it.', 'wp-marketing-automations-pro' ) );

						return null;
					}
				}

				return $data;

			case 'Number':
				$number = self::whole( $data );
				if ( null === $number ) {
					$errors->add( $path, __( 'data must be a whole number, 0 or more: the contact query reads nothing else.', 'wp-marketing-automations-pro' ) );

					return null;
				}

				return (string) $number; // stored as the admin's input saves it: its fields show a number as empty

			case 'Days':
				$max = isset( $def['extra_props']['max'] ) && is_numeric( $def['extra_props']['max'] ) ? (int) $def['extra_props']['max'] : self::MAX_DAYS;

				if ( $range ) {
					$from = self::is_range( $data ) ? self::whole( $data['from'] ) : null;
					$to   = null !== $from ? self::whole( $data['to'] ) : null;
					if ( null === $to || $from > $to || 0 === $to || $to > $max ) {
						/* translators: 1: the operator, 2: the most days allowed */
						$errors->add( $path, sprintf( __( 'With the %1$s rule, data must be {from, to}: two whole numbers of days, from not above to, and to between 1 and %2$d.', 'wp-marketing-automations-pro' ), $rule, $max ) );

						return null;
					}

					return array( 'from' => (string) $from, 'to' => (string) $to );
				}

				$days = self::whole( $data );
				$min  = isset( $def['extra_props']['min'] ) && is_numeric( $def['extra_props']['min'] ) ? (int) $def['extra_props']['min'] : 1;
				if ( null === $days || $days < $min || $days > $max ) {
					/* translators: 1: the fewest days allowed, 2: the most days allowed */
					$errors->add( $path, sprintf( __( 'data must be a whole number of days from %1$d to %2$d (a single number, not {from, to}, for this rule). A lower or empty value is dropped by the contact query and matches every contact.', 'wp-marketing-automations-pro' ), $min, $max ) );

					return null;
				}

				return (string) $days;

			case 'Date':
				if ( $range ) {
					$ok = self::is_range( $data ) && self::is_date( $data['from'] ) && self::is_date( $data['to'] ) && $data['from'] <= $data['to'];
					if ( ! $ok ) {
						/* translators: %s: the operator */
						$errors->add( $path, sprintf( __( 'With the %s rule, data must be {from, to}: two Y-m-d dates, from not after to.', 'wp-marketing-automations-pro' ), $rule ) );

						return null;
					}

					return array( 'from' => $data['from'], 'to' => $data['to'] );
				}

				if ( ! self::is_date( $data ) ) {
					$errors->add( $path, __( 'data must be one real date as Y-m-d, e.g. 2026-01-31.', 'wp-marketing-automations-pro' ) );

					return null;
				}

				return $data;
		}

		return null;
	}

	/** Search data as the wizard stores it: [{key, label}], every key checked to exist. */
	private static function search_data( $slug, array $def, $data, $path, FKMCP_Definition_Errors $errors ) {
		if ( ! is_array( $data ) || ! self::is_list( $data ) ) {
			/* translators: %s: filter slug */
			$errors->add( $path, sprintf( __( 'data for filter %s must be a list of ids, e.g. [12, 15].', 'wp-marketing-automations-pro' ), $slug ) );

			return null;
		}

		if ( count( $data ) > self::MAX_IDS ) {
			/* translators: %d: the most ids allowed */
			$errors->add( $path, sprintf( __( 'At most %d ids are allowed in one condition. Split it, or save the audience in the admin.', 'wp-marketing-automations-pro' ), self::MAX_IDS ) );

			return null;
		}

		if ( isset( self::SINGLE_ID[ $slug ] ) && 1 !== count( $data ) ) {
			/* translators: 1: filter slug, 2: what one id of it is */
			$errors->add( $path, sprintf( __( 'Filter %1$s takes exactly one %2$s: given two or more, the contact query drops the condition and matches every contact. Pass one id; for several, use one group per id.', 'wp-marketing-automations-pro' ), $slug, self::SINGLE_ID[ $slug ] ) );

			return null;
		}

		// Counted before any lookup: past the cap nothing more is read, and check() reports it once.
		self::$ids += count( $data );
		if ( self::$ids > self::MAX_TOTAL_IDS ) {
			return null;
		}

		$keys = array();
		foreach ( $data as $i => $item ) {
			$key = is_array( $item ) && isset( $item['key'] ) ? $item['key'] : $item;
			$key = is_int( $key ) ? (string) $key : $key;

			if ( ! is_string( $key ) || '' === trim( $key ) || strlen( $key ) > 100 ) {
				$errors->add( $path . '[' . $i . ']', __( 'Each entry must be an id (an integer, a numeric string, or {key}).', 'wp-marketing-automations-pro' ) );

				return null;
			}

			$keys[ $i ] = $key;
		}

		$known = array() !== $def['options'] ? $def['options'] : self::lookup( $slug, array_values( array_unique( $keys ) ) );
		$pairs = array();
		$bad   = false;

		foreach ( $keys as $i => $key ) {
			if ( ! isset( $known[ $key ] ) ) {
				$bad = true;
				$errors->add(
					$path . '[' . $i . ']',
					ctype_digit( $key )
						/* translators: 1: the id given, 2: filter slug */
						? sprintf( __( 'Nothing with id %1$s exists for filter %2$s (deleted, perhaps). Look the id up again and pass only ids that exist.', 'wp-marketing-automations-pro' ), $key, $slug )
						/* translators: 1: the value given, 2: filter slug */
						: sprintf( __( '"%1$s" is not a known id of filter %2$s. It takes ids, not display names (a role slug, country code or coupon code for those three filters): look the id up first.', 'wp-marketing-automations-pro' ), $key, $slug )
				);
				continue;
			}

			$pairs[ $key ] = array( 'key' => $key, 'label' => (string) $known[ $key ] );
		}

		return $bad ? null : array_values( $pairs );
	}

	/**
	 * The keys that exist for a Search filter, with their labels.
	 *
	 * Tags, lists and automations are read by id. Countries and coupon codes have a
	 * source of their own, because their label helpers echo back any value. Every other
	 * filter is asked to label one id at a time: several of the helpers pair
	 * labels to ids by position, which is only right for a single id.
	 *
	 * @return array<string, string>
	 */
	private static function lookup( $slug, array $keys ) {
		if ( is_callable( self::$lookup ) ) {
			return (array) call_user_func( self::$lookup, $slug, $keys );
		}

		$found  = array();
		$digits = array_values( array_filter( $keys, 'ctype_digit' ) );

		if ( 'tags' === $slug || 'lists' === $slug ) {
			$class = 'tags' === $slug ? 'BWFCRM_Tag' : 'BWFCRM_Lists';
			if ( array() === $digits || ! class_exists( $class ) ) {
				return array();
			}

			$rows = 'tags' === $slug ? BWFCRM_Tag::get_tags( $digits ) : BWFCRM_Lists::get_lists( $digits );
			foreach ( is_array( $rows ) ? $rows : array() as $row ) {
				if ( isset( $row['ID'], $row['name'] ) ) {
					$found[ (string) $row['ID'] ] = (string) $row['name'];
				}
			}

			return $found;
		}

		if ( 'country' === $slug ) {
			$countries = function_exists( 'bwf_get_countries_data' ) ? bwf_get_countries_data() : array();

			return is_array( $countries ) ? array_map( 'strval', array_intersect_key( $countries, array_flip( $keys ) ) ) : array();
		}

		if ( 'used_coupons' === $slug ) {
			foreach ( function_exists( 'wc_get_coupon_id_by_code' ) ? $keys : array() as $code ) {
				if ( wc_get_coupon_id_by_code( $code ) > 0 ) {
					$found[ $code ] = $code;
				}
			}

			return $found;
		}

		// Read by id: the automation filters' label helpers warn on an id they cannot find.
		if ( 0 === strpos( $slug, 'automation_' ) ) {
			$rows = array() !== $digits && class_exists( 'BWFCRM_Common' ) ? BWFCRM_Common::get_automation_title_by_ids( array_map( 'absint', $digits ) ) : array();
			foreach ( is_array( $rows ) ? $rows : array() as $row ) {
				if ( isset( $row['id'], $row['title'] ) ) {
					$found[ (string) $row['id'] ] = (string) $row['title'];
				}
			}

			return $found;
		}

		$class = class_exists( 'BWFCRM_Load_Filters' ) && isset( BWFCRM_Load_Filters::$filter_classes[ $slug ] ) ? BWFCRM_Load_Filters::$filter_classes[ $slug ] : '';
		if ( ! is_string( $class ) || '' === $class || ! class_exists( $class ) ) {
			return array();
		}

		$filter = new $class( array() );

		// Roles are keyed by slug; everything else here by a numeric id.
		foreach ( 'role' === $slug ? $keys : $digits as $key ) {
			try {
				$pairs = $filter->get_value_as_key_label( array( $key ) );
			} catch ( Throwable $e ) {
				continue;
			}

			$pair  = is_array( $pairs ) && 1 === count( $pairs ) ? reset( $pairs ) : null;
			$label = is_array( $pair ) && isset( $pair['key'], $pair['label'] ) && is_scalar( $pair['label'] ) && (string) $pair['key'] === $key ? trim( (string) $pair['label'] ) : '';

			// '-' is what the helpers answer for an id they could not find.
			if ( '' !== $label && '-' !== $label ) {
				$found[ $key ] = $label;
			}
		}

		return $found;
	}

	/**
	 * A saved audience's conditions without what a broadcast must not carry: status
	 * conditions and filters this site no longer has. Indexes are kept, so a later
	 * error still points at the stored condition.
	 *
	 * @param string[] $removed One sentence per removal, appended.
	 */
	private static function strip( array $stored, array $catalogue, array &$removed ) {
		$kept = array();

		foreach ( $stored as $g => $group ) {
			if ( ! is_array( $group ) || array() === $group ) {
				$kept[ $g ] = $group;
				continue;
			}

			$number = is_int( $g ) ? $g + 1 : $g;

			foreach ( $group as $c => $condition ) {
				$slug = is_array( $condition ) && isset( $condition['filter'] ) && is_string( $condition['filter'] ) ? $condition['filter'] : null;

				if ( 'status' === $slug ) {
					/* translators: %s: the group's position */
					$removed[] = self::line( sprintf( __( 'Removed the status condition from group %s: a broadcast decides status from promotional, include_unverified and include_soft_bounce.', 'wp-marketing-automations-pro' ), $number ) );
					unset( $group[ $c ] );
				} elseif ( null !== $slug && ! isset( $catalogue[ $slug ] ) ) {
					/* translators: 1: filter slug, 2: the group's position */
					$removed[] = self::line( sprintf( __( 'Removed the "%1$s" condition from group %2$s: that filter is not available on this site.', 'wp-marketing-automations-pro' ), $slug, $number ) );
					unset( $group[ $c ] );
				}
			}

			if ( array() === $group ) {
				/* translators: %s: the group's position */
				$removed[] = self::line( sprintf( __( 'Dropped group %s: it had no conditions left.', 'wp-marketing-automations-pro' ), $number ) );
				continue;
			}

			$kept[ $g ] = $group;
		}

		return $kept;
	}

	/** One readable line per group, from the catalogue's filter and operator labels. */
	private static function summary( array $filters, array $catalogue ) {
		$lines = array();

		foreach ( $filters as $group ) {
			$parts = array();

			foreach ( $group as $condition ) {
				$def   = $catalogue[ $condition['filter'] ];
				$data  = $condition['data'];
				$value = '';

				if ( 'Search' === $def['type'] && is_array( $data ) ) {
					$value = implode( ', ', array_column( $data, 'label' ) );
				} elseif ( is_array( $data ) ) {
					/* translators: 1: start of a range, 2: end of a range */
					$value = sprintf( __( '%1$s to %2$s', 'wp-marketing-automations-pro' ), $data['from'], $data['to'] );
				} elseif ( 'Select' === $def['type'] ) {
					$value = $def['options'][ $data ];
				} else {
					$value = (string) $data;
				}

				if ( '' !== $value && 'Days' === $def['type'] && '' !== $def['value_label'] ) {
					$value .= ' ' . $def['value_label'];
				}

				$operator = '' !== $condition['rule'] ? $def['operators'][ $condition['rule'] ] : '';
				$parts[]  = $def['name'] . ': ' . trim( $operator . ' ' . $value );
			}

			$lines[] = self::line( implode( ' ' . __( 'AND', 'wp-marketing-automations-pro' ) . ' ', $parts ) );
		}

		return $lines;
	}

	/** Site text on its way to the agent: markup and line breaks out, capped. */
	private static function line( $text ) {
		return FKMCP_Definition_Errors::clean( $text, self::LINE_LIMIT );
	}

	/**
	 * The registry flattened to slug => {type, name, operators, options, value_label, extra_props},
	 * read once per call. Custom fields are in it, so a bwf_cf{id} slug is valid only while its field exists.
	 */
	private static function catalogue() {
		if ( is_callable( self::$catalogue ) ) {
			$groups = call_user_func( self::$catalogue );
		} else {
			$groups = function_exists( 'BWFCRM_Core' ) && isset( BWFCRM_Core()->filters ) && is_object( BWFCRM_Core()->filters ) ? BWFCRM_Core()->filters->get_filters() : array();
		}

		$flat = array();

		foreach ( is_array( $groups ) ? $groups : array() as $group ) {
			foreach ( isset( $group['rules'] ) && is_array( $group['rules'] ) ? $group['rules'] : array() as $rule ) {
				$slug = isset( $rule['slug'] ) && is_scalar( $rule['slug'] ) ? (string) $rule['slug'] : '';
				if ( '' === $slug || isset( $flat[ $slug ] ) ) {
					continue;
				}

				$options = array();
				foreach ( isset( $rule['options'] ) && is_array( $rule['options'] ) ? $rule['options'] : array() as $value => $label ) {
					if ( is_array( $label ) && isset( $label['key'] ) && is_scalar( $label['key'] ) ) {
						$options[ (string) $label['key'] ] = isset( $label['label'] ) && is_scalar( $label['label'] ) ? (string) $label['label'] : (string) $label['key'];
					} elseif ( is_scalar( $label ) ) {
						$options[ (string) $value ] = (string) $label;
					}
				}

				$operators = array();
				foreach ( isset( $rule['operators'] ) && is_array( $rule['operators'] ) ? $rule['operators'] : array() as $operator => $label ) {
					$operators[ (string) $operator ] = is_scalar( $label ) ? (string) $label : (string) $operator;
				}

				$flat[ $slug ] = array(
					'type'        => isset( $rule['type'] ) && is_scalar( $rule['type'] ) ? (string) $rule['type'] : '',
					'name'        => isset( $rule['name'] ) && is_scalar( $rule['name'] ) && '' !== (string) $rule['name'] ? (string) $rule['name'] : $slug,
					'operators'   => $operators,
					'options'     => $options,
					'value_label' => isset( $rule['value_label'] ) && is_scalar( $rule['value_label'] ) ? (string) $rule['value_label'] : '',
					'extra_props' => isset( $rule['extra_props'] ) && is_array( $rule['extra_props'] ) ? $rule['extra_props'] : array(),
				);
			}
		}

		return $flat;
	}

	/** A saved audience (a bwfan_terms row of type 3) as {name, filters}, or null. */
	private static function load_audience( $id ) {
		if ( is_callable( self::$audience ) ) {
			return call_user_func( self::$audience, $id );
		}

		if ( ! class_exists( 'BWFAN_Model_Terms' ) || ! class_exists( 'BWFAN_PRO_Common' ) ) {
			return null;
		}

		// By type as well as id: a tag or a list lives in the same table.
		$rows = BWFAN_Model_Terms::get_terms( 3, 0, 1, '', array( $id ) );
		$row  = is_array( $rows ) && $rows ? reset( $rows ) : null;
		if ( ! is_array( $row ) || ! isset( $row['ID'] ) || (int) $row['ID'] !== $id ) {
			return null;
		}

		$data = BWFAN_PRO_Common::decode_stored_data_column( isset( $row['data'] ) ? $row['data'] : null );

		return array(
			'name'    => isset( $row['name'] ) ? (string) $row['name'] : '',
			'filters' => is_array( $data ) && isset( $data['filters'] ) ? $data['filters'] : array(),
		);
	}

	/** A whole number of 0 or more from an int or a digit string; null for anything else. */
	private static function whole( $value ) {
		if ( is_int( $value ) ) {
			return $value >= 0 ? $value : null;
		}

		return is_string( $value ) && ctype_digit( $value ) && strlen( $value ) < 10 ? (int) $value : null;
	}

	private static function is_date( $value ) {
		if ( ! is_string( $value ) || 1 !== preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) ) {
			return false;
		}

		list( $year, $month, $day ) = array_map( 'intval', explode( '-', $value ) );

		return checkdate( $month, $day, $year );
	}

	/** Exactly the two keys from and to, in either order. */
	private static function is_range( $value ) {
		return is_array( $value ) && 2 === count( $value ) && isset( $value['from'], $value['to'] );
	}

	/** True when any string in the value holds an engine marker, whatever its case or spacing. */
	private static function has_marker( $value ) {
		if ( is_array( $value ) ) {
			foreach ( $value as $item ) {
				if ( self::has_marker( $item ) ) {
					return true;
				}
			}

			return false;
		}

		if ( ! is_string( $value ) ) {
			return false;
		}

		$flat = preg_replace( '/[\s\x00]+/', '', strtolower( $value ) );

		foreach ( self::ENGINE_MARKERS as $marker ) {
			if ( false !== strpos( $flat, $marker ) ) {
				return true;
			}
		}

		return false;
	}

	private static function is_list( array $value ) {
		return array_values( $value ) === $value;
	}

	/** The registered slugs nearest to a mistyped one. */
	private static function closest( $slug, array $slugs ) {
		$slug = substr( $slug, 0, 60 );
		$near = array();

		foreach ( $slugs as $candidate ) {
			$candidate = (string) $candidate;
			if ( 'status' === $candidate || strlen( $candidate ) > 60 ) {
				continue;
			}

			$near[ $candidate ] = levenshtein( $slug, $candidate );
		}

		asort( $near );

		return array_slice( array_keys( $near ), 0, 3 );
	}
}
