<?php

defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/class-fkmcp-pack-pro-abilities.php';

/**
 * Pro's read-only tools: broadcasts, audiences, segment filters, analytics.
 * Self-gates on BWFAN_PRO_VERSION.
 */
class FKMCP_Pack_Pro extends FKMCP_Pack_Pro_Abilities {
	/** Broadcast status codes as BWFAN_Model_Broadcast files them (5 and 6 are both paused). */
	/** get-automation's definition past this many bytes of JSON is left out. */
	const DEFINITION_MAX = 61440;

	const BROADCAST_STATUS = array( 1 => 'draft', 2 => 'scheduled', 3 => 'ongoing', 4 => 'completed', 5 => 'paused', 6 => 'paused', 7 => 'cancelled' );

	/** Broadcast type codes. */
	const BROADCAST_CHANNEL = array( 1 => 'email', 2 => 'sms' );

	const LIST_BROADCAST_KEYS = array( 'id', 'title', 'type', 'status', 'execution_time', 'created_at', 'count', 'unsubs' );

	const GET_BROADCAST_KEYS = array( 'id', 'title', 'description', 'type', 'status', 'execution_time', 'created_at', 'last_modified', 'count', 'processed', 'subject', 'parent' );

	const GET_AUDIENCE_KEYS = array( 'ID', 'name', 'type', 'created_at', 'updated_at' );

	const LIST_AUDIENCE_KEYS = array( 'ID', 'name', 'type', 'created_at', 'updated_at' );

	const LINK_TRIGGER_KEYS = array( 'ID', 'title', 'status', 'total_clicked', 'created_at', 'updated_at' );

	const EMAIL_ANALYTICS_KEYS = array( 'ID', 'oid', 'tid', 'type', 'sent', 'open_count', 'open_rate', 'click_count', 'click_rate', 'conversions', 'revenue', 'title', 'subject' );

	const TRAIL_DATA_KEYS = array( 'event', 'nice_name', 'source', 'label', 'title', 'date', 'status', 'msg', 'reason' );

	const TRAIL_STEP_STATUS = array(
		1 => 'Success',
		2 => 'Wait',
		3 => 'Failed',
		4 => 'Skipped',
	);

	/** Page size the email-analytics controller is asked for, per call. */
	const ANALYTICS_PAGE_SIZE = 100;

	/** A report window answers at most this many days; longer asks get the latest part plus next. */
	const WINDOW_MAX_DAYS = 366;

	/** Earlier parts of a too-long window handed back as next calls (about 5 years in all). */
	const WINDOW_MAX_CHUNKS = 4;

	/**
	 * Ceiling on rows get-email-performance pulls for one window. It ranks in PHP
	 * because the controller can only order by oid, so it has to read the whole
	 * window - this bounds that. Raise it, or push ORDER BY into
	 * BWFCRM_Reports, if real stores start hitting the cap.
	 */
	const PERFORMANCE_MAX_ROWS = 500;

	/** Transient prefix for create-automation's client_ref (10 minutes). */
	const CREATE_REF_PREFIX = 'fkmcp_ca_';

	/** get-webhook-sample: stop flattening once this many fields are collected - a stored payload is untrusted size, so the cap applies while walking, not after. */
	const WEBHOOK_FIELD_CAP = 200;

	/**
	 * Store text on its way out to the model: markup stripped, length capped,
	 * objects dropped.
	 *
	 * Contact names, phone numbers, custom-field values and stored step
	 * payloads are not authored by the site owner — anyone who can fill a
	 * checkout or opt-in form writes them, and the model reads them in the same
	 * turn it can call the write abilities (send-email-to-contact,
	 * delete-contact). That is the injection path this bounds: markup-dressed
	 * payloads ("<system>…") and unbounded blobs.
	 *
	 * It is deliberately NOT a defence against plain prose - nothing at this
	 * layer can be. The "data, never instructions" line in the descriptions of
	 * the abilities that return this text is what covers that half, and the
	 * client's own approval step covers the write it would try to drive.
	 *
	 * @param mixed $value
	 * @param int   $depth
	 *
	 * @return mixed
	 */
	public static function untrust( $value, $depth = 0 ) {
		if ( ! class_exists( 'FKMCP_Definition_Errors', false ) ) {
			require_once __DIR__ . '/automation/class-fkmcp-definition-errors.php';
		}

		return FKMCP_Definition_Errors::untrust( $value, $depth );
	}

	/**
	 * Loads the definition classes on demand. Only the creation tools call
	 * it, so tools/list and every other MCP call pay nothing for them
	 * (spec §0.2.1).
	 *
	 * @return void
	 */
	public static function load_definition_classes() {
		static $loaded = false;

		if ( $loaded ) {
			return;
		}

		foreach ( array( 'definition-errors', 'part-registry', 'field-translator', 'search-resolver', 'special-fields', 'step-tree', 'saved-tree', 'automation-editor', 'rule-translator', 'step-builder', 'email-step', 'review', 'review-sheet', 'graph-builder', 'definition-builder', 'step-reader' ) as $name ) {
			require_once __DIR__ . '/automation/class-fkmcp-' . $name . '.php';
		}

		$loaded = true;
	}

	/**
	 * describe-automation-part reads a part's schema; it never builds a step
	 * tree or an Automation, so it needs only the registry, the schema
	 * translators, step-tree (FKMCP_Rule_Translator::registry()'s option_map()
	 * uses FKMCP_Step_Tree::is_list() for every trigger whose rules carry
	 * options) and their hard dependencies - not the saved-tree, editor,
	 * email-step, review or graph-builder classes load_definition_classes()
	 * also loads. A later call to load_definition_classes() in the same
	 * request still loads the rest (require_once is a no-op for what this
	 * already loaded).
	 *
	 * @return void
	 */
	public static function load_definition_classes_for_describe() {
		static $loaded = false;

		if ( $loaded ) {
			return;
		}

		foreach ( array( 'definition-errors', 'part-registry', 'field-translator', 'search-resolver', 'special-fields', 'step-tree', 'rule-translator', 'step-builder' ) as $name ) {
			require_once __DIR__ . '/automation/class-fkmcp-' . $name . '.php';
		}

		$loaded = true;
	}

	/**
	 * Loads the broadcast draft classes on demand. Only the broadcast write
	 * tools call it, so tools/list and every other MCP call pay nothing for them.
	 *
	 * @return void
	 */
	public static function load_broadcast_classes() {
		static $loaded = false;

		if ( $loaded ) {
			return;
		}

		foreach ( array( 'automation/class-fkmcp-definition-errors', 'automation/class-fkmcp-email-step', 'automation/class-fkmcp-step-builder', 'broadcast/class-fkmcp-broadcast-audience', 'broadcast/class-fkmcp-broadcast-content', 'broadcast/class-fkmcp-broadcast-draft' ) as $name ) {
			require_once __DIR__ . '/' . $name . '.php';
		}

		// Its merge-tag list and design seam serve every channel; the host loads it with this pack, a direct caller may not have.
		if ( ! class_exists( 'FKMCP_Pack_Email_Design', false ) ) {
			require_once __DIR__ . '/class-fkmcp-pack-email-design.php';
		}

		$loaded = true;
	}

	/**
	 * create-broadcast. Always a draft: the tool has no way to schedule or send.
	 *
	 * @param array $input
	 *
	 * @return array|WP_Error
	 */
	public function create_broadcast( $input = array() ) {
		self::load_broadcast_classes();

		return FKMCP_Broadcast_Draft::create( (array) $input );
	}

	/**
	 * update-broadcast. Drafts only, and it stays a draft: the tool has no way to schedule or send.
	 *
	 * @param array $input
	 *
	 * @return array|WP_Error
	 */
	public function update_broadcast( $input = array() ) {
		self::load_broadcast_classes();

		return FKMCP_Broadcast_Draft::update( (array) $input );
	}

	/**
	 * Loads the saved-audience classes on demand: only create-audience and update-audience call it.
	 *
	 * @return void
	 */
	public static function load_audience_classes() {
		foreach ( array( 'automation/class-fkmcp-definition-errors', 'broadcast/class-fkmcp-broadcast-audience', 'audience/class-fkmcp-audience' ) as $name ) {
			require_once __DIR__ . '/' . $name . '.php';
		}
	}

	/**
	 * create-audience.
	 *
	 * @param array $input
	 *
	 * @return array|WP_Error
	 */
	public function create_audience( $input = array() ) {
		self::load_audience_classes();

		return FKMCP_Audience::create( (array) $input );
	}

	/**
	 * update-audience. The name never changes.
	 *
	 * @param array $input
	 *
	 * @return array|WP_Error
	 */
	public function update_audience( $input = array() ) {
		self::load_audience_classes();

		return FKMCP_Audience::update( (array) $input );
	}

	public static function load_bulk_action_classes() {
		foreach ( array( 'automation/class-fkmcp-definition-errors', 'automation/class-fkmcp-review', 'broadcast/class-fkmcp-broadcast-audience', 'bulk-action/class-fkmcp-bulk-action' ) as $name ) {
			require_once __DIR__ . '/' . $name . '.php';
		}
	}

	/**
	 * start-bulk-action: terms, filters and fields go through the same checks as
	 * manage-contact-tags-lists, filter-contacts and update-contact.
	 *
	 * @param array $input
	 *
	 * @return array|WP_Error
	 */
	public function start_bulk_action( $input = array() ) {
		self::load_bulk_action_classes();

		return FKMCP_Bulk_Action::start(
			(array) $input,
			function ( $items, $type, $create ) {
				return $this->resolve_terms( $items, $type, $create );
			},
			function ( $filters ) {
				return $this->validate_filters( $filters );
			},
			function ( $fields ) {
				return $this->resolve_fields( $fields );
			}
		);
	}

	public function get_bulk_action( $input = array() ) {
		self::load_bulk_action_classes();

		return FKMCP_Bulk_Action::get( (array) $input );
	}

	public function update_bulk_action( $input = array() ) {
		self::load_bulk_action_classes();

		return FKMCP_Bulk_Action::update( (array) $input );
	}

	public function list_bulk_actions( $input = array() ) {
		self::load_bulk_action_classes();

		return FKMCP_Bulk_Action::all( (array) $input );
	}

	/** A seam so a self-check can hand in a builder that throws. */
	protected function definition_builder() {
		return new FKMCP_Definition_Builder( $this );
	}

	/** Adds the words for a Broadcast row's numeric status and type. */
	private static function broadcast_labels( array $row ) {
		if ( array_key_exists( 'status', $row ) ) {
			$code                = (int) $row['status'];
			$row['status_label'] = isset( self::BROADCAST_STATUS[ $code ] ) ? self::BROADCAST_STATUS[ $code ] : null;
		}

		if ( array_key_exists( 'type', $row ) ) {
			$code           = (int) $row['type'];
			$row['channel'] = isset( self::BROADCAST_CHANNEL[ $code ] ) ? self::BROADCAST_CHANNEL[ $code ] : null;
		}

		return $row;
	}

	public function list_broadcasts( $input = array() ) {
		$page   = BWFAN_MCP_Format::paginate( (array) $input );
		$params = array( 'limit' => $page['limit'], 'offset' => $page['offset'] );

		if ( ! empty( $input['status'] ) ) {
			$params['status'] = sanitize_text_field( $input['status'] );
		}

		if ( ! empty( $input['search'] ) ) {
			$params['search'] = sanitize_text_field( $input['search'] );
		}

		$response = BWFAN_MCP_Dispatch::call( 'list-broadcasts', $params );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$data       = isset( $response['result'] ) && is_array( $response['result'] ) ? $response['result'] : array();
		$collection = BWFAN_MCP_Format::collection( $data, self::LIST_BROADCAST_KEYS, 'campaigns' );

		if ( ! is_wp_error( $collection ) && isset( $collection['items'] ) && is_array( $collection['items'] ) ) {
			$collection['items'] = array_map( array( __CLASS__, 'broadcast_labels' ), $collection['items'] );
		}

		if ( null === $collection['total'] ) {
			// success_response() omits total_count when it is zero, so an empty
			// page means no broadcasts — report that as 0, not as "unknown".
			$collection['total'] = isset( $response['total_count'] )
				? (int) $response['total_count']
				: ( empty( $collection['items'] ) ? 0 : null );
		}

		return $collection;
	}

	/**
	 * A positive id from $input[ $key ], or a refusal naming where ids come from. The schema
	 * requires these keys over MCP; a direct call (tests, other code) can still leave one out.
	 *
	 * @return int|WP_Error
	 */
	private static function required_id( $input, $key, $list_tool ) {
		$id = is_array( $input ) && isset( $input[ $key ] ) && is_numeric( $input[ $key ] ) ? (int) $input[ $key ] : 0;

		/* translators: 1: input key, 2: tool that lists the ids */
		return $id > 0 ? $id : new WP_Error( 'fkmcp_invalid_input', sprintf( __( '%1$s is required: an id from %2$s.', 'wp-marketing-automations-pro' ), $key, $list_tool ) );
	}

	public function get_broadcast( $input = array() ) {
		$campaign_id = self::required_id( $input, 'campaign_id', 'list-broadcasts' );
		if ( is_wp_error( $campaign_id ) ) {
			return $campaign_id;
		}

		$response = BWFAN_MCP_Dispatch::call( 'get-broadcast', array(), array( 'campaign_id' => $campaign_id ) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$row = isset( $response['result'] ) && is_array( $response['result'] ) ? $response['result'] : array();

		return self::broadcast_labels( BWFAN_MCP_Format::pick( $row, self::GET_BROADCAST_KEYS ) );
	}

	public function get_broadcast_stats( $input = array() ) {
		$campaign_id = self::required_id( $input, 'campaign_id', 'list-broadcasts' );
		if ( is_wp_error( $campaign_id ) ) {
			return $campaign_id;
		}

		$response = BWFAN_MCP_Dispatch::call( 'get-broadcast', array(), array( 'campaign_id' => $campaign_id ) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$row = isset( $response['result'] ) && is_array( $response['result'] ) ? $response['result'] : array();

		$stats = BWFAN_MCP_Format::pick( $row, array( 'title', 'status', 'sent', 'open_count', 'open_rate', 'click_count', 'click_rate', 'conversions', 'revenue', 'unsubs' ) );
		$stats = self::broadcast_labels( $stats );

		return array_merge( array( 'campaign_id' => $campaign_id ), $stats );
	}

	public function list_audiences( $input = array() ) {
		$page   = BWFAN_MCP_Format::paginate( (array) $input );
		$params = array( 'limit' => $page['limit'], 'offset' => $page['offset'] );

		if ( ! empty( $input['search'] ) ) {
			$params['search'] = sanitize_text_field( $input['search'] );
		}

		$response = BWFAN_MCP_Dispatch::call( 'list-audiences', $params );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$collection = BWFAN_MCP_Format::collection( $response, self::LIST_AUDIENCE_KEYS, 'result' );

		if ( null === $collection['total'] && empty( $collection['items'] ) ) {
			// Zero audiences, not an unknown count - total_count is omitted at 0.
			$collection['total'] = 0;
		}

		return $collection;
	}

	public function get_audience( $input = array() ) {
		$audience_id = self::required_id( $input, 'audience_id', 'list-audiences' );
		if ( is_wp_error( $audience_id ) ) {
			return $audience_id;
		}

		$response = BWFAN_MCP_Dispatch::call( 'get-audience', array(), array( 'audience_id' => $audience_id ) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$row = isset( $response['result'] ) && is_array( $response['result'] ) ? $response['result'] : array();

		$item = BWFAN_MCP_Format::pick( $row, self::GET_AUDIENCE_KEYS );

		$raw  = isset( $row['data'] ) ? $row['data'] : null;
		$data = ( is_object( $raw ) || is_array( $raw ) ) ? json_decode( wp_json_encode( $raw ), true ) : array();
		$data = is_array( $data ) ? $data : array();

		$item['description'] = isset( $data['desc'] ) && is_scalar( $data['desc'] ) ? $data['desc'] : null;
		$item['filters']     = isset( $data['filters'] ) && is_array( $data['filters'] ) ? $data['filters'] : array();

		return $item;
	}

	public function get_automation_run( $input = array() ) {
		$input = (array) $input;
		$aid   = isset( $input['automation_id'] ) ? absint( $input['automation_id'] ) : 0;
		$tid   = isset( $input['run_id'] ) && is_string( $input['run_id'] ) ? sanitize_text_field( $input['run_id'] ) : '';
		$cid   = isset( $input['contact_id'] ) ? absint( $input['contact_id'] ) : 0;

		if ( empty( $aid ) ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'automation_id is required.', 'wp-marketing-automations-pro' ) );
		}

		if ( '' === $tid && empty( $cid ) ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'Pass run_id (from list-automation-contacts) or contact_id.', 'wp-marketing-automations-pro' ) );
		}

		if ( '' === $tid ) {
			$tid = $this->resolve_trail_id( $aid, $cid );

			if ( '' === $tid ) {
				return new WP_Error( 'fkmcp_not_found', __( 'No run found for this Contact in the Automation.', 'wp-marketing-automations-pro' ) );
			}
		}

		$response = BWFAN_MCP_Dispatch::call( 'get-contact-trail', array( 'tid' => $tid ), array( 'automation_id' => $aid ) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$rows         = isset( $response['result'] ) && is_array( $response['result'] ) ? $response['result'] : array();
		$include_data = ! empty( $input['include_data'] );
		$steps        = array();

		foreach ( $rows as $row ) {
			// Rows without a type are React-flow edges — presentation only.
			if ( ! is_array( $row ) || empty( $row['type'] ) ) {
				continue;
			}

			$data = isset( $row['data'] ) && is_array( $row['data'] ) ? $row['data'] : array();
			// Step payloads carry rendered merge tags and third-party error
			// text — store data, not site-owner copy — so both shapes go
			// through untrust(). include_data is the widest surface here: it
			// is the whole stored blob, capped per string and per depth.
			$keep = self::untrust( $include_data ? $data : BWFAN_MCP_Format::pick( $data, self::TRAIL_DATA_KEYS ) );

			if ( isset( $keep['status'] ) && isset( self::TRAIL_STEP_STATUS[ intval( $keep['status'] ) ] ) ) {
				$keep['status'] = self::TRAIL_STEP_STATUS[ intval( $keep['status'] ) ];
			}

			$steps[] = array(
				'id'   => isset( $row['id'] ) ? $row['id'] : '',
				'type' => $row['type'],
				'data' => $keep,
			);
		}

		return array(
			'automation_id' => $aid,
			'run_id'        => $tid,
			'steps'         => $steps,
		);
	}

	/**
	 * Latest trail id for a contact in an automation — active runs first
	 * (bwfan_automation_contact), then finished ones
	 * (bwfan_automation_complete_contact).
	 */
	private function resolve_trail_id( $aid, $cid ) {
		global $wpdb;

		foreach ( array( 'bwfan_automation_contact', 'bwfan_automation_complete_contact' ) as $table ) {
			$trail = $wpdb->get_var( $wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- MySQL cannot bind an identifier; $table is a literal from the array above and never reaches here from input. Both values are bound.
				"SELECT `trail` FROM {$wpdb->prefix}{$table} WHERE `cid` = %d AND `aid` = %d ORDER BY `ID` DESC LIMIT 1",
				$cid,
				$aid
			) );

			if ( ! empty( $trail ) ) {
				return (string) $trail;
			}
		}

		return '';
	}

	public function list_link_triggers( $input = array() ) {
		$page = BWFAN_MCP_Format::paginate( (array) $input );

		// No status filter: the controller discards a falsy one anyway, and
		// every trigger regardless of state is what this ability advertises.
		$response = BWFAN_MCP_Dispatch::call( 'list-link-triggers', array(
			'limit'  => $page['limit'],
			'offset' => $page['offset'],
		) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$rows  = isset( $response['result'] ) && is_array( $response['result'] ) ? $response['result'] : array();
		$items = array();

		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$item = BWFAN_MCP_Format::pick( $row, self::LINK_TRIGGER_KEYS );

			$data = isset( $row['data'] ) && is_array( $row['data'] ) ? $row['data'] : array();

			$item['redirect_url'] = isset( $data['redirect_url'] ) && is_scalar( $data['redirect_url'] ) ? $data['redirect_url'] : null;
			$item['actions']      = isset( $data['actions'] ) && is_array( $data['actions'] ) ? array_values( array_keys( $data['actions'] ) ) : array();

			$items[] = $item;
		}

		return array(
			'items' => $items,
			'total' => isset( $response['total_count'] ) ? (int) $response['total_count'] : ( empty( $rows ) ? 0 : null ),
		);
	}

	public function get_email_analytics( $input = array() ) {
		$input = (array) $input;
		$page  = BWFAN_MCP_Format::paginate( $input, self::ANALYTICS_PAGE_SIZE, self::ANALYTICS_PAGE_SIZE );

		/**
		 * Always send an explicit window. Left unset, the controller falls back
		 * to its own 7-day default while get-email-performance defaults to 30, and an
		 * agent comparing the two reads the difference as a data problem rather
		 * than two different questions. One resolver, one default.
		 */
		$window = $this->resolve_window( array(
			'after'  => isset( $input['after'] ) ? $input['after'] : '',
			'before' => isset( $input['before'] ) ? $input['before'] : '',
		) );

		if ( is_wp_error( $window ) ) {
			return $window;
		}

		$params = array(
			'limit'  => $page['limit'],
			'offset' => $page['offset'],
			'after'  => $window['after'] . ' 00:00:00',
			'before' => $window['before'] . ' 23:59:59',
		);

		$response = BWFAN_MCP_Dispatch::call( 'get-email-analytics', $params );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$rows  = isset( $response['result'] ) && is_array( $response['result'] ) ? $response['result'] : array();
		$items = array();

		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$item = BWFAN_MCP_Format::pick( $row, self::EMAIL_ANALYTICS_KEYS );

			// SUM() over the conversions LEFT JOIN yields NULL when nothing
			// matched; normalise like get-email-performance does.
			$item['conversions'] = isset( $item['conversions'] ) ? (int) $item['conversions'] : 0;
			$item['revenue']     = isset( $item['revenue'] ) ? round( (float) $item['revenue'], 2 ) : 0.0;

			$items[] = $item;
		}

		$total = isset( $response['total_count'] ) ? (int) $response['total_count'] : ( empty( $rows ) ? 0 : null );

		return array(
			'items'     => $items,
			'total'     => $total,
			'window'    => array( 'after' => $window['after'], 'before' => $window['before'] ),
			'limit'     => $page['limit'],
			'offset'    => $page['offset'],
			// total counts the whole range, not this page - so more remains
			// whenever the rows seen so far fall short of it.
			'truncated' => null !== $total && $total > ( $page['offset'] + count( $items ) ),
		) + self::window_tail( $window, 'get-email-analytics', $input );
	}

	public function filter_contacts( $input = array() ) {
		$page = BWFAN_MCP_Format::paginate( (array) $input );

		$params = array(
			'limit'       => $page['limit'],
			'offset'      => $page['offset'],
			'grab_totals' => true,
		);

		$applied = array();

		// Checked before either branch runs: reporting an unknown filter slug
		// when the real mistake was passing both would send the agent hunting
		// through list-contact-filters for a problem it does not have.
		if ( ! empty( $input['audience_id'] ) && ! empty( $input['filters'] ) ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'Pass audience_id or filters, not both.', 'wp-marketing-automations-pro' ) );
		}

		if ( ! empty( $input['audience_id'] ) ) {
			$audience_id = (int) $input['audience_id'];

			if ( ! class_exists( 'BWFCRM_Audience' ) ) {
				return new WP_Error( 'fkmcp_plugin_missing', __( 'FunnelKit audiences are not available.', 'wp-marketing-automations-pro' ) );
			}

			$audience = new BWFCRM_Audience( $audience_id );

			if ( ! $audience->is_audience_exists() ) {
				return new WP_Error( 'fkmcp_not_found', __( 'No audience with that id. Call list-audiences for valid ids.', 'wp-marketing-automations-pro' ) );
			}

			$params['audience_id'] = $audience_id;
			$applied['audience_id'] = $audience_id;
		}

		if ( ! empty( $input['filters'] ) ) {
			$filters = $this->validate_filters( $input['filters'] );

			if ( is_wp_error( $filters ) ) {
				return $filters;
			}

			$params['filters'] = $filters;
			$applied['filters'] = count( $filters );
		}

		if ( ! empty( $input['search'] ) ) {
			$params['search'] = sanitize_text_field( $input['search'] );
		}

		if ( ! empty( $input['count_only'] ) ) {
			$params['only_count'] = true;
		}

		$response = BWFAN_MCP_Dispatch::call( 'filter-contacts', $params );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$collection = BWFAN_MCP_Format::collection( $response, FKMCP_Pack_Lite::CONTACT_KEYS, 'result' );

		// Names, phone and field values are visitor-entered: untrust() before
		// they reach the model, which can call the write abilities next.
		$collection['items'] = array_map( static function ( $row ) {
			return self::untrust( FKMCP_Pack_Lite::decorate_contact_row( $row ) );
		}, $collection['items'] );

		if ( null === $collection['total'] ) {
			$collection['total'] = isset( $response['total_count'] ) ? (int) $response['total_count'] : 0;
		}

		$collection['applied'] = $applied;

		return $collection;
	}

	private function validate_filters( $filters ) {
		if ( ! is_array( $filters ) ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'filters must be an array of condition groups.', 'wp-marketing-automations-pro' ) );
		}

		if ( ! class_exists( 'BWFCRM_Load_Filters' ) ) {
			return new WP_Error( 'fkmcp_plugin_missing', __( 'FunnelKit contact filters are not available.', 'wp-marketing-automations-pro' ) );
		}

		BWFCRM_Load_Filters::maybe_load_filters();

		$clean   = array();
		$unknown = array();

		foreach ( $filters as $g => $group ) {
			if ( ! is_array( $group ) || array() === $group ) {
				continue;
			}

			$clean_group = array();

			foreach ( $group as $c => $condition ) {
				if ( ! is_array( $condition ) || empty( $condition['filter'] ) || ! is_string( $condition['filter'] ) ) {
					return new WP_Error( 'fkmcp_invalid_input', __( 'Every filter condition needs a string `filter` slug.', 'wp-marketing-automations-pro' ) );
				}

				$slug = $condition['filter'];

				if ( 0 === strpos( $slug, 'bwf_cf' ) ) {
					$field_id   = (int) str_replace( 'bwf_cf', '', $slug );
					$filter_obj = class_exists( 'BWFAN_Filter_BWF_CF' ) ? new BWFAN_Filter_BWF_CF( array(), $field_id ) : null;

					if ( null === $filter_obj || ! $filter_obj->is_field_valid ) {
						$unknown[] = $slug;
						continue;
					}
				} elseif ( ! isset( BWFCRM_Load_Filters::$filter_classes[ $slug ] ) || ! class_exists( BWFCRM_Load_Filters::$filter_classes[ $slug ] ) ) {
					$unknown[] = $slug;
					continue;
				} else {
					$class      = BWFCRM_Load_Filters::$filter_classes[ $slug ];
					$filter_obj = new $class( array() );
				}

				$rule = isset( $condition['rule'] ) && is_string( $condition['rule'] ) ? sanitize_key( $condition['rule'] ) : '';

				// The contact query drops a condition whose rule the filter does not have, and then matches every contact.
				$refused = self::refused_rule( $filter_obj, $slug, $rule, 'filters[' . $g . '][' . $c . '].rule' );
				if ( null !== $refused ) {
					return $refused;
				}

				$data = $this->normalise_filter_data( $slug, isset( $filter_obj ) ? $filter_obj : null, $rule, isset( $condition['data'] ) ? $condition['data'] : '' );

				if ( is_wp_error( $data ) ) {
					return $data;
				}

				$clean_group[] = array(
					'filter' => $slug,
					'rule'   => $rule,
					'data'   => $data,
				);
			}

			if ( $clean_group ) {
				$clean[] = $clean_group;
			}
		}

		if ( $unknown ) {
			return new WP_Error(
				'fkmcp_invalid_input',
				__( 'Unknown filter slugs. Call list-contact-filters for the valid vocabulary.', 'wp-marketing-automations-pro' ),
				array( 'unknown' => array_values( array_unique( $unknown ) ) )
			);
		}

		if ( array() === $clean ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'filters contained no usable conditions.', 'wp-marketing-automations-pro' ) );
		}

		return $clean;
	}

	/**
	 * A WP_Error when $rule is not one of the filter's operators (the ones list-contact-filters
	 * shows), or when the filter has none and a rule was given; null when the rule is fine.
	 */
	private static function refused_rule( $filter, $slug, $rule, $at ) {
		if ( ! is_object( $filter ) || ! method_exists( $filter, 'get_possible_operators' ) ) {
			return null;
		}

		$operators = array_map( 'strval', array_keys( (array) $filter->get_possible_operators() ) );

		if ( array() === $operators ) {
			return '' === $rule ? null : new WP_Error(
				'fkmcp_invalid_input',
				/* translators: 1: where the rule is in the input, 2: filter slug */
				sprintf( __( '%1$s: filter %2$s takes no rule. Leave rule out or pass "".', 'wp-marketing-automations-pro' ), $at, $slug )
			);
		}

		if ( in_array( $rule, $operators, true ) ) {
			return null;
		}

		return new WP_Error(
			'fkmcp_invalid_input',
			/* translators: 1: where the rule is in the input, 2: filter slug, 3: its operators */
			sprintf( __( '%1$s: rule must be one of the operators of filter %2$s: %3$s.', 'wp-marketing-automations-pro' ), $at, $slug, implode( ', ', $operators ) ),
			array( 'allowed' => $operators )
		);
	}

	/** How many options a refusal lists. */
	const FILTER_OPTIONS_LISTED = 12;

	/**
	 * Filter values as the engine stores them. The engine casts whatever it is
	 * handed - a Select label becomes 0, a tag name matches nothing - and each
	 * answers a confident wrong set. So a value not already in stored form
	 * is looked up through the filter's own options - a Select's list,
	 * or the search a Search filter's picker runs - and a value that maps to
	 * nothing, or to more than one option, is an error, never a guess.
	 */
	private function normalise_filter_data( $slug, $filter, $rule, $data ) {
		if ( ! is_object( $filter ) || in_array( $rule, array( 'is_blank', 'is_not_blank' ), true ) || null === $data || '' === $data || array() === $data ) {
			return $data;
		}

		$type = method_exists( $filter, 'get_type' ) ? (string) $filter->get_type() : '';

		if ( 'Select' === $type && method_exists( $filter, 'get_options' ) ) {
			$options = $filter->get_options();
			$options = is_array( $options ) ? $options : array();

			if ( array() === $options ) {
				return $data;
			}

			return $this->map_filter_values(
				$slug,
				$data,
				function () use ( $options ) {
					return $options;
				}
			);
		}

		if ( 'tags' === $slug || 'lists' === $slug ) {
			$pairs = $this->resolve_terms( (array) $data, 'tags' === $slug ? 'tag' : 'list' );

			return is_wp_error( $pairs ) ? $pairs : array_map( 'intval', array_column( $pairs, 'id' ) );
		}

		if ( 'Search' !== $type ) {
			return $data;
		}

		// A number is a stored id (or a code that is all digits) and goes as given.
		$names = array_filter(
			(array) $data,
			function ( $one ) {
				return ! is_numeric( $one );
			}
		);

		if ( array() === $names ) {
			return $data;
		}

		if ( ! method_exists( $filter, 'get_options' ) || ! $this->can_search_filter_options() ) {
			$first = reset( $names );

			return new WP_Error(
				'fkmcp_invalid_input',
				sprintf(
					/* translators: 1: the value given, 2: filter slug. */
					__( '"%1$s" cannot be checked against filter %2$s here: values other than ids are looked up only on a REST request by a user with FunnelKit Automations access. Pass the id.', 'wp-marketing-automations-pro' ),
					is_scalar( $first ) ? (string) $first : gettype( $first ),
					$slug
				)
			);
		}

		return $this->map_filter_values(
			$slug,
			$data,
			function ( $given ) use ( $filter ) {
				$found = $filter->get_options( $given );

				return is_array( $found ) ? $found : array();
			},
			function () use ( $filter ) {
				$all = $filter->get_options( '' );

				return is_array( $all ) ? $all : array();
			}
		);
	}

	/**
	 * Whether a Search filter's picker search can run on this request. Some
	 * of them (the product ones) go through BWFAN_Common::check_nonce(), which
	 * ends the request with a JSON reply unless it is a REST request by a user
	 * holding one of BWFAN_Common::access_capabilities() - the way MCP calls
	 * arrive. Anywhere else, names are refused instead of looked up.
	 */
	private function can_search_filter_options() {
		$rest = ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ( function_exists( 'wp_is_rest_endpoint' ) && wp_is_rest_endpoint() );

		if ( ! $rest || ! class_exists( 'BWFAN_Common' ) || ! is_user_logged_in() ) {
			return false;
		}

		$caps = method_exists( 'BWFAN_Common', 'access_capabilities' ) ? BWFAN_Common::access_capabilities() : array( 'manage_options' );

		foreach ( (array) $caps as $cap ) {
			if ( current_user_can( $cap ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Each given value as the option value it names. A number passes as
	 * given; anything else is matched against $search( $value ) by the value
	 * itself, the value in another case (us -> US), then the label in any
	 * case, with a "(#id)" ending ignored (a product's label is "Name (#12)";
	 * a variation's adds its attributes). When that misses and the value
	 * could still be a key - the search found nothing, or its keys are not
	 * all numbers (a country's search reads names, not codes) - $all() is
	 * tried, fetched once for every value. A miss or a tie is refused with
	 * the options that came closest.
	 *
	 * @param string        $slug   Filter slug.
	 * @param mixed         $data   One value or a list.
	 * @param callable      $search Options for a typed value: value => label.
	 * @param callable|null $all    Every option, when the typed search misses;
	 *                              given for a Search filter, whose numbers
	 *                              are stored ids and pass as given.
	 */
	private function map_filter_values( $slug, $data, $search, $all = null ) {
		$numbers_as_given = null !== $all;
		$every            = null;
		$scalar           = ! is_array( $data );
		$mapped           = array();

		foreach ( $scalar ? array( $data ) : $data as $one ) {
			if ( $numbers_as_given && is_numeric( $one ) ) {
				$mapped[] = $one;
				continue;
			}

			$given   = is_scalar( $one ) ? trim( (string) $one ) : '';
			$options = (array) call_user_func( $search, $given );
			$hits    = self::filter_option_hits( $options, $given );

			if ( array() === $hits && null !== $all && ( array() === $options || self::has_text_key( $options ) ) ) {
				$every = null === $every ? (array) call_user_func( $all ) : $every;
				$hits  = self::filter_option_hits( $every, $given );

				if ( array() === $hits && array() === $options ) {
					$options = self::options_containing( $every, $given );
				}
			}

			if ( 1 !== count( $hits ) ) {
				return $this->filter_option_refusal( $slug, array() === $hits ? $options : $hits, $given, count( $hits ) > 1 );
			}

			$mapped[] = (string) key( $hits );
		}

		return $scalar ? $mapped[0] : $mapped;
	}

	/**
	 * The options $given names, in one pass: those whose value is $given, or
	 * failing that whose value is $given in another case, or failing that
	 * whose label is $given in any case (with a "(#id)" ending dropped).
	 */
	private static function filter_option_hits( array $options, $given ) {
		if ( '' === $given ) {
			return array();
		}

		$exact = array();
		$case  = array();
		$label = array();

		foreach ( $options as $value => $text ) {
			$value = (string) $value;

			if ( $value === $given ) {
				$exact[ $value ] = $text;
				break;
			}

			if ( 0 === strcasecmp( $value, $given ) ) {
				$case[ $value ] = $text;
				continue;
			}

			if ( array() !== $case || ! is_scalar( $text ) ) {
				continue;
			}

			$text = trim( (string) $text );

			if ( 0 === strcasecmp( $text, $given ) || ( ')' === substr( $text, -1 ) && 0 === strcasecmp( rtrim( (string) preg_replace( '/\s*\(#\d+\)$/', '', $text ) ), $given ) ) ) {
				$label[ $value ] = $text;
			}
		}

		if ( array() !== $exact ) {
			return $exact;
		}

		return array() !== $case ? $case : $label;
	}

	/** Whether any option value is not a number: a code the given value may be, unlike an id. */
	private static function has_text_key( array $options ) {
		foreach ( array_keys( $options ) as $value ) {
			if ( ! is_numeric( $value ) ) {
				return true;
			}
		}

		return false;
	}

	/** The options whose value or label contains $given; all of them when none does. */
	private static function options_containing( array $options, $given ) {
		$near = array();

		foreach ( $options as $value => $text ) {
			if ( false !== stripos( (string) $value, $given ) || ( is_scalar( $text ) && false !== stripos( (string) $text, $given ) ) ) {
				$near[ $value ] = $text;
			}
		}

		return array() === $near ? $options : $near;
	}

	private function filter_option_refusal( $slug, array $options, $given, $tie = false ) {
		$listed = array_slice( $options, 0, self::FILTER_OPTIONS_LISTED, true );
		$pairs  = array();

		foreach ( $listed as $value => $label ) {
			$pairs[] = $value . ' = ' . ( is_scalar( $label ) ? $label : $value );
		}

		if ( $tie ) {
			$message = sprintf(
				/* translators: 1: the value given, 2: filter slug, 3: value = label pairs. */
				__( '"%1$s" names more than one value of filter %2$s: %3$s. Pass the value.', 'wp-marketing-automations-pro' ),
				$given,
				$slug,
				implode( ', ', $pairs )
			);
		} elseif ( array() === $pairs ) {
			$message = sprintf(
				/* translators: 1: the value given, 2: filter slug. */
				__( '"%1$s" is not a value of filter %2$s, and nothing like it was found.', 'wp-marketing-automations-pro' ),
				$given,
				$slug
			);
		} else {
			$message = sprintf(
				/* translators: 1: the value given, 2: filter slug, 3: value = label pairs. */
				__( '"%1$s" is not a value of filter %2$s. Options: %3$s.', 'wp-marketing-automations-pro' ),
				$given,
				$slug,
				implode( ', ', $pairs )
			);

			if ( count( $listed ) < count( $options ) ) {
				$message .= ' ' . __( 'Pass the value, or its name exactly as listed.', 'wp-marketing-automations-pro' );
			}
		}

		return new WP_Error( 'fkmcp_invalid_input', $message, array( 'options' => $listed ) );
	}

	public function list_contact_filters( $input = array() ) {
		if ( ! class_exists( 'BWFCRM_Load_Filters' ) ) {
			return new WP_Error( 'fkmcp_plugin_missing', __( 'FunnelKit contact filters are not available.', 'wp-marketing-automations-pro' ) );
		}

		$registry = BWFCRM_Load_Filters::get_instance()->get_filters();

		if ( ! is_array( $registry ) ) {
			return new WP_Error( 'fkmcp_dispatch_failed', __( 'Filter registry unavailable.', 'wp-marketing-automations-pro' ) );
		}

		$by_slug = array();

		foreach ( $registry as $group ) {
			if ( ! is_array( $group ) ) {
				continue;
			}

			$title = isset( $group['title'] ) && is_scalar( $group['title'] ) ? (string) $group['title'] : '';
			$slug  = sanitize_title( $title );

			if ( '' === $slug ) {
				continue;
			}

			$by_slug[ $slug ] = array( 'title' => $title, 'rules' => isset( $group['rules'] ) && is_array( $group['rules'] ) ? $group['rules'] : array() );
		}

		$asked  = ! empty( $input['group'] ) && is_string( $input['group'] ) ? trim( $input['group'] ) : '';
		$wanted = sanitize_title( $asked );

		if ( '' !== $asked && '' === $wanted ) {
			return new WP_Error(
				'fkmcp_invalid_input',
				sprintf(
					/* translators: %s: comma-separated group slugs. */
					__( 'group must name one of: %s.', 'wp-marketing-automations-pro' ),
					implode( ', ', array_keys( $by_slug ) )
				),
				array( 'allowed' => array_keys( $by_slug ) )
			);
		}

		// Slug or title match exactly; otherwise a fragment that names one group ("contact" -> contact-details).
		if ( '' !== $wanted && ! isset( $by_slug[ $wanted ] ) ) {
			$matches = array();

			foreach ( array_keys( $by_slug ) as $slug ) {
				if ( false !== strpos( $slug, $wanted ) ) {
					$matches[] = $slug;
				}
			}

			if ( 1 === count( $matches ) ) {
				$wanted = $matches[0];
			} else {
				return new WP_Error(
					'fkmcp_invalid_input',
					sprintf(
						/* translators: 1: the group asked for, 2: comma-separated group slugs. */
						__( 'Unknown filter group "%1$s". Groups: %2$s.', 'wp-marketing-automations-pro' ),
						$asked,
						implode( ', ', $matches ? $matches : array_keys( $by_slug ) )
					),
					array( 'allowed' => $matches ? $matches : array_keys( $by_slug ) )
				);
			}
		}

		$groups = array();

		foreach ( $by_slug as $group_slug => $group ) {
			if ( '' !== $wanted && $group_slug !== $wanted ) {
				continue;
			}

			$rules = isset( $group['rules'] ) && is_array( $group['rules'] ) ? $group['rules'] : array();
			$items = array();

			foreach ( $rules as $rule ) {
				if ( ! is_array( $rule ) || empty( $rule['slug'] ) ) {
					continue;
				}

				$item = array(
					'slug'      => (string) $rule['slug'],
					'name'      => isset( $rule['name'] ) && is_scalar( $rule['name'] ) ? (string) $rule['name'] : (string) $rule['slug'],
					'type'      => isset( $rule['type'] ) && is_scalar( $rule['type'] ) ? (string) $rule['type'] : null,

					'operators' => isset( $rule['operators'] ) && is_array( $rule['operators'] ) ? array_map( 'strval', array_keys( $rule['operators'] ) ) : array(),
				);

				if ( '' !== $wanted ) {
					$options = isset( $rule['options'] ) && is_array( $rule['options'] ) ? $rule['options'] : array();
					$flat    = array();

					foreach ( $options as $value => $label ) {
						if ( is_array( $label ) && isset( $label['key'] ) ) {
							$flat[] = array( 'value' => (string) $label['key'], 'label' => isset( $label['label'] ) && is_scalar( $label['label'] ) ? (string) $label['label'] : (string) $label['key'] );
						} elseif ( is_scalar( $label ) ) {
							$flat[] = array( 'value' => (string) $value, 'label' => (string) $label );
						}

						if ( count( $flat ) >= 100 ) {
							break;
						}
					}

					// Option labels are read from the database — tag and list
					// names, custom-field options — and integrations can mint
					// those from external data, so they are store text too.
					$item['options']           = self::untrust( $flat );
					$item['options_truncated'] = count( $options ) > count( $flat );
				}

				$items[] = $item;
			}

			$groups[] = array(
				'group'   => (string) $group_slug,
				'title'   => isset( $group['title'] ) && is_scalar( $group['title'] ) ? (string) $group['title'] : (string) $group_slug,
				'filters' => $items,
			);
		}

		return array( 'groups' => $groups );
	}

	public function get_email_performance( $input = array() ) {
		$entity = isset( $input['entity'] ) ? (string) $input['entity'] : '';

		if ( ! in_array( $entity, array( 'email', 'broadcast', 'automation' ), true ) ) {
			return new WP_Error(
				'fkmcp_invalid_input',
				__( 'Unknown entity.', 'wp-marketing-automations-pro' ),
				array( 'allowed' => array( 'email', 'broadcast', 'automation' ), 'note' => 'For carts use get-cart-analytics.' )
			);
		}

		$metric  = ! empty( $input['metric'] ) && is_string( $input['metric'] ) ? $input['metric'] : 'revenue';
		$allowed = array( 'sent', 'open_count', 'open_rate', 'click_count', 'click_rate', 'conversions', 'revenue' );

		if ( ! in_array( $metric, $allowed, true ) ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'Unknown metric.', 'wp-marketing-automations-pro' ), array( 'allowed' => $allowed ) );
		}

		$window = $this->resolve_window( $input );

		if ( is_wp_error( $window ) ) {
			return $window;
		}

		$rows = $this->fetch_email_rows( $window['after'], $window['before'], $entity );

		if ( is_wp_error( $rows ) ) {
			return $rows;
		}

		// One name for the entity's id across every entity: the aggregate rows
		// call it id, so the per-email rows do too rather than making the model
		// branch on entity to read the same field back.
		$items = 'email' === $entity ? $this->rename_oid_to_id( $rows['items'] ) : $this->aggregate_by_oid( $rows['items'] );

		usort( $items, static function ( $a, $b ) use ( $metric ) {
			return ( $b[ $metric ] ?? 0 ) <=> ( $a[ $metric ] ?? 0 );
		} );

		$limit = isset( $input['limit'] ) ? max( 1, min( 50, (int) $input['limit'] ) ) : 10;

		$result = array(
			'entity'    => $entity,
			'metric'    => $metric,
			'window'    => array( 'after' => $window['after'], 'before' => $window['before'] ),
			'items'     => array_slice( $items, 0, $limit ),
			'totals'    => $this->sum_rows( $rows['items'] ),

			'truncated' => $rows['truncated'],
		) + self::window_tail( $window, 'get-email-performance', $input );

		if ( ! empty( $input['compare'] ) && 'previous_period' === $input['compare'] ) {
			$length      = strtotime( $window['before'] ) - strtotime( $window['after'] );
			$prev_before = gmdate( 'Y-m-d', strtotime( $window['after'] ) - DAY_IN_SECONDS );
			$prev_after  = gmdate( 'Y-m-d', strtotime( $window['after'] ) - DAY_IN_SECONDS - $length );

			$prev = $this->fetch_email_rows( $prev_after, $prev_before, $entity );

			if ( ! is_wp_error( $prev ) ) {
				$previous = $this->sum_rows( $prev['items'] );
				$delta    = array();

				foreach ( $result['totals'] as $key => $value ) {
					$delta[ $key ] = round( $value - ( $previous[ $key ] ?? 0 ), 2 );
				}

				$result['compare'] = array(
					'window'    => array( 'after' => $prev_after, 'before' => $prev_before ),
					'previous'  => $previous,
					'delta'     => $delta,
					// The prior window is capped independently of the current
					// one; without this a delta could be short on either side.
					'truncated' => $prev['truncated'],
				);
			}
		}

		return $result;
	}

	private function resolve_window( $input ) {
		$after  = ! empty( $input['after'] ) && is_string( $input['after'] ) ? $input['after'] : '';
		$before = ! empty( $input['before'] ) && is_string( $input['before'] ) ? $input['before'] : '';

		foreach ( array( 'after' => $after, 'before' => $before ) as $name => $value ) {
			if ( '' !== $value && ! preg_match( '/^\d{4}-\d{2}-\d{2}( \d{2}:\d{2}:\d{2})?$/', $value ) ) {
				return new WP_Error( 'fkmcp_invalid_input', __( 'Dates must be Y-m-d or Y-m-d H:i:s.', 'wp-marketing-automations-pro' ), array( 'field' => $name ) );
			}
		}

		// ponytail: whole days - every caller adds 00:00:00 / 23:59:59, so a time part is dropped.
		$after  = substr( $after, 0, 10 );
		$before = substr( $before, 0, 10 );

		$now = current_time( 'timestamp' );

		if ( '' === $before ) {
			$before = gmdate( 'Y-m-d', $now );
		}

		if ( '' === $after ) {
			$after = gmdate( 'Y-m-d', strtotime( $before ) - 30 * DAY_IN_SECONDS );
		}

		if ( strtotime( $after ) > strtotime( $before ) ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'after must not be later than before.', 'wp-marketing-automations-pro' ) );
		}

		$max = self::WINDOW_MAX_DAYS * DAY_IN_SECONDS;

		if ( strtotime( $before ) - strtotime( $after ) <= $max ) {
			return array( 'after' => $after, 'before' => $before );
		}

		// Too long to answer fast: answer the latest part and hand the rest back,
		// newest first, as ready calls - never a silently shorter window.
		$asked   = strtotime( $after );
		$after   = gmdate( 'Y-m-d', strtotime( $before ) - $max );
		$earlier = array();
		$end     = strtotime( $after ) - DAY_IN_SECONDS;

		while ( $end >= $asked && count( $earlier ) < self::WINDOW_MAX_CHUNKS ) {
			$start     = max( $asked, $end - $max );
			$earlier[] = array( 'after' => gmdate( 'Y-m-d', $start ), 'before' => gmdate( 'Y-m-d', $end ) );
			$end       = $start - DAY_IN_SECONDS;
		}

		return array(
			'after'     => $after,
			'before'    => $before,
			'shortened' => array(
				'asked_after'  => gmdate( 'Y-m-d', $asked ),
				'asked_before' => $before,
				'more_earlier' => $end >= $asked,
			),
			'earlier'   => $earlier,
		);
	}

	/**
	 * window_shortened + next for a report that resolve_window() shortened:
	 * one call per earlier part, same tool and arguments, in tools/list spelling.
	 *
	 * @param array  $window resolve_window() result.
	 * @param string $tool   Ability slug without the funnelkit/ prefix.
	 * @param array  $input  The call's input; its window and paging keys are replaced.
	 */
	private static function window_tail( $window, $tool, $input ) {
		$args = array_diff_key( (array) $input, array_flip( array( 'after', 'before', 'days', 'window', 'offset' ) ) );
		$next = array();

		foreach ( isset( $window['earlier'] ) ? $window['earlier'] : array() as $part ) {
			$next[] = array(
				'tool' => 'funnelkit-' . $tool,
				/* translators: 1: start date, 2: end date */
				'why'  => sprintf( __( 'Earlier part of the asked window: %1$s to %2$s.', 'wp-marketing-automations-pro' ), $part['after'], $part['before'] ),
				'args' => $args + $part,
			);
		}

		return array(
			'window_shortened' => isset( $window['shortened'] ) ? $window['shortened'] : null,
			'next'             => $next,
		);
	}

	/**
	 * Every row in the window, in one call, capped at PERFORMANCE_MAX_ROWS.
	 *
	 * The controller orders by oid and never by the requested metric, so a
	 * partial read would rank an arbitrary slice and report its partial sums as
	 * totals. Reading the window whole is what makes both correct; `truncated`
	 * says when the cap stopped that from being true. One call, not pages: each
	 * call re-runs the controller's all-time conversions aggregate.
	 */
	private function fetch_email_rows( $after, $before, $entity ) {
		$params = array(
			'after'  => $after . ' 00:00:00',
			'before' => $before . ' 23:59:59',
		);

		if ( 'automation' === $entity ) {
			$params['type'] = 1;
		} elseif ( 'broadcast' === $entity ) {
			$params['type'] = 2;
		}

		$items = array();
		$seen  = array();
		$total = null;

		$params['limit']  = self::PERFORMANCE_MAX_ROWS;
		$params['offset'] = 0;

		$response = BWFAN_MCP_Dispatch::call( 'get-email-analytics', $params );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		// Counts every group in the window regardless of the limit, so it is
		// the honest denominator for `truncated`.
		if ( isset( $response['total_count'] ) ) {
			$total = (int) $response['total_count'];
		}

		$rows = isset( $response['result'] ) && is_array( $response['result'] ) ? $response['result'] : array();

		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			/**
			 * The controller's own GROUP BY key: summing a row twice is worse
			 * than missing it, since totals would read high with nothing to
			 * show it. Cheap insurance - the rows are already in memory.
			 */
			$key = sprintf(
				'%d:%d:%d',
				isset( $row['oid'] ) ? (int) $row['oid'] : 0,
				isset( $row['tid'] ) ? (int) $row['tid'] : 0,
				isset( $row['type'] ) ? (int) $row['type'] : 0
			);

			if ( isset( $seen[ $key ] ) ) {
				continue;
			}

			$seen[ $key ] = true;

			$items[] = array(
				'oid'         => isset( $row['oid'] ) ? (int) $row['oid'] : null,
				'tid'         => isset( $row['tid'] ) ? (int) $row['tid'] : null,
				'type'        => isset( $row['type'] ) ? (int) $row['type'] : null,
				'title'       => $this->email_row_title( $row ),
				'subject'     => isset( $row['subject'] ) && is_scalar( $row['subject'] ) ? $row['subject'] : null,
				'sent'        => isset( $row['sent'] ) ? (int) $row['sent'] : 0,
				'open_count'  => isset( $row['open_count'] ) ? (int) $row['open_count'] : 0,
				'open_rate'   => isset( $row['open_rate'] ) ? round( (float) $row['open_rate'], 2 ) : 0.0,
				'click_count' => isset( $row['click_count'] ) ? (int) $row['click_count'] : 0,
				'click_rate'  => isset( $row['click_rate'] ) ? round( (float) $row['click_rate'], 2 ) : 0.0,
				'conversions' => isset( $row['conversions'] ) ? (int) $row['conversions'] : 0,
				'revenue'     => isset( $row['revenue'] ) ? round( (float) $row['revenue'], 2 ) : 0.0,
			);
		}


		if ( null === $total ) {
			$total = count( $items );
		}

		return array( 'items' => $items, 'truncated' => $total > count( $items ) );
	}

	/**
	 * Per-email rows carry the controller's own column name, `oid`. Only the
	 * response is renamed - the internal rows keep `oid` because
	 * aggregate_by_oid() and the dedupe key are built on it.
	 *
	 * @param array $items
	 *
	 * @return array
	 */
	private function rename_oid_to_id( array $items ) {
		return array_map( static function ( $item ) {
			// One row per email: its own (template) id first, then the
			// Automation or Broadcast it belongs to - rows of one Automation
			// share oid, so oid alone cannot tell them apart.
			$renamed = array(
				'id'          => ! empty( $item['tid'] ) ? (int) $item['tid'] : null,
				'parent_id'   => isset( $item['oid'] ) ? $item['oid'] : null,
				'parent_type' => isset( $item['type'] ) ? ( 2 === (int) $item['type'] ? 'broadcast' : 'automation' ) : null,
			);

			unset( $item['oid'], $item['tid'] );

			return $renamed + $item;
		}, $items );
	}

	/**
	 * The reports controller titles an Automation's emails from automationmeta
	 * `title`, which the visual (v2) engine never writes - so every v2 row came
	 * back blank. Fall back to the Automation's own name.
	 */
	private function email_row_title( array $row ) {
		$title = isset( $row['title'] ) && is_scalar( $row['title'] ) ? (string) $row['title'] : '';

		if ( '' !== $title || 1 !== (int) ( isset( $row['type'] ) ? $row['type'] : 0 ) || empty( $row['oid'] ) ) {
			return '' !== $title ? $title : null;
		}

		static $names = array();
		$oid = (int) $row['oid'];

		if ( ! array_key_exists( $oid, $names ) ) {
			$names[ $oid ] = null;

			if ( function_exists( 'BWFAN_Core' ) && isset( BWFAN_Core()->automations ) && method_exists( BWFAN_Core()->automations, 'get_automation_data_meta' ) ) {
				$meta          = BWFAN_Core()->automations->get_automation_data_meta( $oid );
				foreach ( array( 'title', 'name' ) as $key ) {
					if ( is_array( $meta ) && ! empty( $meta[ $key ] ) && is_scalar( $meta[ $key ] ) ) {
						$names[ $oid ] = (string) $meta[ $key ];
						break;
					}
				}
			}
		}

		return $names[ $oid ];
	}

	private function aggregate_by_oid( array $items ) {
		$grouped = array();

		foreach ( $items as $item ) {
			if ( empty( $item['oid'] ) ) {
				continue;
			}

			$oid = (int) $item['oid'];

			if ( ! isset( $grouped[ $oid ] ) ) {
				$grouped[ $oid ] = array(
					'id'          => $oid,
					'title'       => $item['title'],
					'emails'      => 0,
					'sent'        => 0,
					'open_count'  => 0,
					'click_count' => 0,
					'conversions' => 0,
					'revenue'     => 0.0,
				);
			}

			$grouped[ $oid ]['emails']      += 1;
			$grouped[ $oid ]['sent']        += $item['sent'];
			$grouped[ $oid ]['open_count']  += $item['open_count'];
			$grouped[ $oid ]['click_count'] += $item['click_count'];
			$grouped[ $oid ]['conversions'] += $item['conversions'];
			$grouped[ $oid ]['revenue']      = round( $grouped[ $oid ]['revenue'] + $item['revenue'], 2 );

			if ( empty( $grouped[ $oid ]['title'] ) && ! empty( $item['title'] ) ) {
				$grouped[ $oid ]['title'] = $item['title'];
			}
		}

		foreach ( $grouped as &$row ) {
			$row['open_rate']  = $row['sent'] > 0 ? round( $row['open_count'] / $row['sent'] * 100, 2 ) : 0.0;
			$row['click_rate'] = $row['sent'] > 0 ? round( $row['click_count'] / $row['sent'] * 100, 2 ) : 0.0;
		}
		unset( $row );

		return array_values( $grouped );
	}

	private function sum_rows( array $items ) {
		$totals = array( 'sent' => 0, 'open_count' => 0, 'click_count' => 0, 'conversions' => 0, 'revenue' => 0.0 );

		foreach ( $items as $item ) {
			$totals['sent']        += isset( $item['sent'] ) ? (int) $item['sent'] : 0;
			$totals['open_count']  += isset( $item['open_count'] ) ? (int) $item['open_count'] : 0;
			$totals['click_count'] += isset( $item['click_count'] ) ? (int) $item['click_count'] : 0;
			$totals['conversions'] += isset( $item['conversions'] ) ? (int) $item['conversions'] : 0;
			$totals['revenue']      = round( $totals['revenue'] + ( isset( $item['revenue'] ) ? (float) $item['revenue'] : 0 ), 2 );
		}

		return $totals;
	}

	/** The overview's sections, in output order; include picks a subset. */
	const OVERVIEW_SECTIONS = array( 'totals', 'top_emails', 'top_automations', 'latest_broadcast', 'carts' );

	public function get_automations_overview( $input = array() ) {
		$input   = (array) $input;
		$include = isset( $input['include'] ) && is_array( $input['include'] ) ? array_values( array_intersect( self::OVERVIEW_SECTIONS, $input['include'] ) ) : self::OVERVIEW_SECTIONS;
		$days  = array( 'today' => 0, 'last_7d' => 7, 'last_30d' => 30 );
		$now   = current_time( 'timestamp' );

		// Three ways to say the window, one survivor: after/before beats days
		// beats the window preset. Precedence rather than refusal, because a
		// client that materialises the schema default sends window every call.
		if ( isset( $input['after'] ) || isset( $input['before'] ) ) {
			if ( empty( $input['after'] ) || ! is_string( $input['after'] ) ) {
				return new WP_Error( 'fkmcp_invalid_input', __( 'before needs after: an open-ended past window is unbounded.', 'wp-marketing-automations-pro' ) );
			}

			$resolved = $this->resolve_window( array(
				'after'  => $input['after'],
				'before' => isset( $input['before'] ) && is_string( $input['before'] ) ? $input['before'] : '',
			) );

			if ( is_wp_error( $resolved ) ) {
				return $resolved;
			}

			// The email aggregates scale with the window: past a year,
			// resolve_window() answers the latest part and window_tail() hands back the rest.
			$after  = $resolved['after'];
			$before = $resolved['before'];
		} elseif ( isset( $input['days'] ) && '' !== $input['days'] ) {
			if ( ! is_numeric( $input['days'] ) || (int) $input['days'] < 0 || (int) $input['days'] > 365 ) {
				return new WP_Error( 'fkmcp_invalid_input', __( 'days must be 0-365.', 'wp-marketing-automations-pro' ) );
			}

			$before = gmdate( 'Y-m-d', $now );
			$after  = gmdate( 'Y-m-d', $now - (int) $input['days'] * DAY_IN_SECONDS );
		} else {
			$window = isset( $input['window'] ) && is_string( $input['window'] ) ? $input['window'] : 'last_7d';

			if ( ! isset( $days[ $window ] ) ) {
				return new WP_Error( 'fkmcp_invalid_input', __( 'Unknown window.', 'wp-marketing-automations-pro' ), array( 'allowed' => array_keys( $days ) ) );
			}

			$before = gmdate( 'Y-m-d', $now );
			$after  = gmdate( 'Y-m-d', $now - $days[ $window ] * DAY_IN_SECONDS );
		}

		$start = $after . ' 00:00:00';
		$end   = $before . ' 23:59:59';

		$pulse = self::window_tail( isset( $resolved ) ? $resolved : array(), 'get-automations-overview', $input ) + array(
			'window'                   => array( 'after' => $after, 'before' => $before ),
			'skipped'                  => array_values( array_diff( self::OVERVIEW_SECTIONS, $include ) ),
			'new_contacts'             => null,
			'unsubscribers'            => null,
			'emails_sent'              => null,
			'revenue'                  => null,
			'top_emails'               => null,
			'top_emails_truncated'     => null,
			'top_automations_all_time' => null,
			'latest_broadcast'         => null,
			'broadcast_scan_truncated' => null,
			'carts'                    => null,
		);
		$pulse['next'] = array_merge( $pulse['next'], $this->overview_pointers( $pulse['skipped'], $after, $before ) );

		if ( in_array( 'totals', $include, true ) ) {
			$pulse['new_contacts']  = $this->dashboard_scalar( array( 'BWFCRM_Dashboards', 'get_total_contacts' ), $start, $end );
			$pulse['unsubscribers'] = $this->dashboard_scalar( array( 'BWFCRM_Dashboards', 'get_unsubscribers_total' ), $start, $end );
			$pulse['emails_sent']   = $this->dashboard_scalar( array( 'BWFCRM_Dashboards', 'get_total_email_sents' ), $start, $end );
			$pulse['revenue']       = $this->dashboard_scalar( array( 'BWFCRM_Dashboards', 'get_total_revenue' ), $start, $end );
		}

		if ( in_array( 'top_emails', $include, true ) ) {
			$top = $this->get_email_performance( array( 'entity' => 'email', 'metric' => 'revenue', 'after' => $after, 'before' => $before, 'limit' => 3 ) );

			$pulse['top_emails'] = is_wp_error( $top ) ? null : $top['items'];

			// The 500-row cap applies to this ranking too. Dropped, the pulse hands
			// back a partial top-3 that reads as the definitive one - the exact
			// thing truncated exists to stop on get-email-performance itself.
			$pulse['top_emails_truncated'] = is_wp_error( $top ) ? null : $top['truncated'];
		}

		if ( in_array( 'top_automations', $include, true ) && class_exists( 'BWFAN_Dashboards' ) && method_exists( 'BWFAN_Dashboards', 'get_top_automations' ) ) {
			$tops = BWFAN_Dashboards::get_top_automations();

			if ( is_array( $tops ) ) {
				$pulse['top_automations_all_time'] = array_map( static function ( $row ) {
					return BWFAN_MCP_Format::pick( is_array( $row ) ? $row : array(), array( 'aid', 'name', 'event', 'total_revenue' ) );
				}, array_slice( $tops, 0, 5 ) );
			}
		}

		// The newest Broadcast that ran inside the window. The list is
		// newest-first by creation and has no date filter, and a scheduled
		// send can put an in-window run date behind an out-of-window creation,
		// so walk up to 500 rows with no early exit on old dates and say when
		// the cap cut the walk short.
		if ( in_array( 'latest_broadcast', $include, true ) ) {
			$pulse['broadcast_scan_truncated'] = false;
		}

		for ( $bpage = 0; in_array( 'latest_broadcast', $include, true ) && $bpage < 10; $bpage ++ ) {
			$latest = $this->list_broadcasts( array( 'limit' => 50, 'offset' => $bpage * 50 ) );

			if ( is_wp_error( $latest ) || empty( $latest['items'] ) ) {
				break;
			}

			foreach ( $latest['items'] as $row ) {
				$ran = isset( $row['execution_time'] ) && is_string( $row['execution_time'] ) ? substr( $row['execution_time'], 0, 10 ) : '';

				if ( in_array( (int) ( isset( $row['status'] ) ? $row['status'] : 0 ), array( 3, 4 ), true ) && $ran >= $after && $ran <= $before ) {
					$pulse['latest_broadcast'] = $row;
					break 2;
				}
			}

			if ( count( $latest['items'] ) < 50 ) {
				break;
			}

			if ( 9 === $bpage ) {
				$pulse['broadcast_scan_truncated'] = true;
			}
		}

		$carts = in_array( 'carts', $include, true ) ? BWFAN_MCP_Dispatch::call( 'get-cart-analytics', array( 'after' => $start, 'before' => $end ) ) : null;

		if ( is_array( $carts ) && isset( $carts['result']['totals'] ) && is_array( $carts['result']['totals'] ) ) {
			$pulse['carts'] = BWFAN_MCP_Format::pick( $carts['result']['totals'], array( 'recoverable_carts', 'potential_revenue', 'recovered_cart', 'recovered_revenue', 'recovery_rate', 'lost_cart' ) );
		}

		return $pulse;
	}

	/**
	 * One ready call per section the overview skipped, for the same window.
	 * Only tools this store registers: no pointer to a tool the agent can't call.
	 */
	private function overview_pointers( $skipped, $after, $before ) {
		$span  = ( strtotime( $before ) - strtotime( $after ) ) / DAY_IN_SECONDS;
		$calls = array(
			'top_emails'       => array( 'get-email-performance', __( 'Top 3 emails by revenue in this window.', 'wp-marketing-automations-pro' ), array( 'entity' => 'email', 'metric' => 'revenue', 'after' => $after, 'before' => $before, 'limit' => 3 ) ),
			'top_automations'  => array( 'get-top-automations', __( 'All-time top 5 Automations by revenue, as the overview reports them; add after/before for this window only.', 'wp-marketing-automations-pro' ), array( 'limit' => 5 ) ),
			'latest_broadcast' => array( 'list-broadcasts', __( 'Newest completed Broadcasts by creation. The latest one that ran in this window is the newest whose execution_time falls in it (it may be none); get-broadcast-stats gives its numbers.', 'wp-marketing-automations-pro' ), array( 'status' => 'completed', 'limit' => 5 ) ),
			'carts'            => array( 'get-cart-analytics', __( 'Cart recovery for this window.', 'wp-marketing-automations-pro' ), array( 'after' => $after, 'before' => $before, 'interval' => $span <= 31 ? 'day' : 'week' ) ),
		);
		$next  = array();

		foreach ( $skipped as $section ) {
			if ( isset( $calls[ $section ] ) && wp_has_ability( 'funnelkit/' . $calls[ $section ][0] ) ) {
				$next[] = array( 'tool' => 'funnelkit-' . $calls[ $section ][0], 'why' => $calls[ $section ][1], 'args' => $calls[ $section ][2] );
			}
		}

		return $next;
	}

	/**
	 * Automations ranked by attributed WooCommerce revenue: all-time (what the
	 * overview's top_automations_all_time shows) or within after/before. One
	 * grouped query on the conversions table; its date column is UTC.
	 */
	public function get_top_automations( $input = array() ) {
		$input  = (array) $input;
		$limit  = isset( $input['limit'] ) ? max( 1, min( 10, (int) $input['limit'] ) ) : 5;
		$window = null;
		$tail   = array( 'window_shortened' => null, 'next' => array() );
		$params = array();
		$where  = '';

		if ( ! empty( $input['after'] ) || ! empty( $input['before'] ) ) {
			$resolved = $this->resolve_window( $input );

			if ( is_wp_error( $resolved ) ) {
				return $resolved;
			}

			$window   = array( 'after' => $resolved['after'], 'before' => $resolved['before'] );
			$tail     = self::window_tail( $resolved, 'get-top-automations', $input );
			$where    = ' AND c.`date` BETWEEN %s AND %s';
			$params[] = get_gmt_from_date( $window['after'] . ' 00:00:00' );
			$params[] = get_gmt_from_date( $window['before'] . ' 23:59:59' );
		}

		global $wpdb;
		$params[] = $limit;
		$rows     = $wpdb->get_results( $wpdb->prepare( "SELECT a.`ID` AS aid, a.`title` AS name, a.`event`, SUM(c.`wctotal`) AS total_revenue, COUNT(c.`ID`) AS conversions FROM {$wpdb->prefix}bwfan_conversions AS c INNER JOIN {$wpdb->prefix}bwfan_automations AS a ON a.`ID` = c.`oid` WHERE c.`otype` = 1{$where} GROUP BY a.`ID` ORDER BY total_revenue DESC LIMIT %d", $params ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $where is a fixed placeholder string; values are bound.

		$items = array();
		foreach ( (array) $rows as $row ) {
			$aid     = (int) $row['aid'];
			$items[] = array(
				'aid'           => $aid,
				'name'          => '' !== (string) $row['name'] ? $row['name'] : BWFAN_Model_Automationmeta::get_meta( $aid, 'title' ),
				'event'         => BWFAN_Common::get_automation_event_name( $row['event'] ),
				'total_revenue' => round( (float) $row['total_revenue'], 2 ),
				'conversions'   => (int) $row['conversions'],
			);
		}

		return array(
			'window' => $window,
			'items'  => $items,
		) + $tail;
	}

	private function dashboard_scalar( $callback, $start, $end ) {
		if ( ! class_exists( $callback[0] ) || ! method_exists( $callback[0], $callback[1] ) ) {
			return null;
		}

		try {
			$rows = call_user_func( $callback, $start, $end, '', '' );
		} catch ( Throwable $e ) {
			// Throwable, not Error: a dashboard query raising an Exception must
			// still leave the other sections of the pulse intact.
			return null;
		}

		if ( ! is_array( $rows ) || ! isset( $rows[0] ) || ! is_array( $rows[0] ) ) {
			return null;
		}

		foreach ( $rows[0] as $value ) {
			if ( is_numeric( $value ) ) {
				return $value + 0;
			}

			// SUM() over nothing yields NULL. The section computed fine and the
			// answer is zero — a null here would read as "unavailable", which
			// is the one thing it is not.
			if ( null === $value ) {
				return 0;
			}
		}

		return null;
	}

	// ─── Write abilities ────────────────────────────────────────────

	/** Contact by id (wins) or email. Returns BWFCRM_Contact or WP_Error. */
	private function resolve_contact( $input ) {
		$cid   = isset( $input['contact_id'] ) ? absint( $input['contact_id'] ) : 0;
		$email = isset( $input['email'] ) && is_string( $input['email'] ) ? sanitize_email( $input['email'] ) : '';

		if ( empty( $cid ) && '' === $email ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'Pass contact_id or email.', 'wp-marketing-automations-pro' ) );
		}

		$contact = new BWFCRM_Contact( ! empty( $cid ) ? $cid : $email );

		if ( ! $contact->is_contact_exists() ) {
			return new WP_Error( 'fkmcp_not_found', __( 'No Contact found for the given contact_id/email.', 'wp-marketing-automations-pro' ) );
		}

		return $contact;
	}

	/**
	 * Tag/list names or ids → existing terms as {id, value} pairs (the shape
	 * parse_terms_request() expects). Fail-closed: any value matching nothing
	 * aborts the whole call, unmatched values echoed back. Never creates terms.
	 */
	public function resolve_terms( $items, $type, $create_missing = false, &$created = array() ) {
		/**
		 * One fetch per type per request. Reading the whole table is what
		 * every other get_tags()/get_lists() caller in this plugin does, so
		 * one is house rate — but this is the first place that resolves more
		 * than once in a request: filter-contacts calls it per filter
		 * condition (up to 100), manage-contact-tags-lists once per operation,
		 * with add_ and remove_ pulling the identical rows back to back.
		 *
		 * Terms cannot change under a request except where this method creates
		 * them, and that path folds its own new pairs in below.
		 */
		static $memo = array();

		if ( ! isset( $memo[ $type ] ) ) {
			$all = 'tag' === $type ? BWFCRM_Tag::get_tags() : BWFCRM_Lists::get_lists();
			$all = is_array( $all ) ? $all : array();

			$memo[ $type ] = array( 'by_id' => array(), 'by_name' => array() );

			foreach ( $all as $term ) {
				$pair = array( 'id' => (int) $term['ID'], 'value' => (string) $term['name'] );

				$memo[ $type ]['by_id'][ (int) $term['ID'] ]                              = $pair;
				$memo[ $type ]['by_name'][ strtolower( trim( (string) $term['name'] ) ) ] = $pair;
			}
		}

		$by_id   = $memo[ $type ]['by_id'];
		$by_name = $memo[ $type ]['by_name'];

		$pairs   = array();
		$unknown = array();

		foreach ( (array) $items as $item ) {
			if ( is_numeric( $item ) && isset( $by_id[ (int) $item ] ) ) {
				$pairs[ (int) $item ] = $by_id[ (int) $item ];
				continue;
			}

			$key = strtolower( trim( (string) $item ) );

			if ( '' !== $key && isset( $by_name[ $key ] ) ) {
				$pairs[ $by_name[ $key ]['id'] ] = $by_name[ $key ];
				continue;
			}

			$unknown[] = $item;
		}

		// A number is an id lookup gone wrong, never a name to coin - only
		// non-numeric names are created, and only when the caller opted in.
		if ( ! empty( $unknown ) && $create_missing && ! array_filter( $unknown, 'is_numeric' ) && class_exists( 'BWFCRM_Term' ) && class_exists( 'BWFCRM_Term_Type' ) ) {
			$made = BWFCRM_Term::get_or_create_terms(
				array_map(
					static function ( $name ) {
						// parse_terms_request() reads value; its docblock's
						// 'name' key is stale.
						return array( 'id' => 0, 'value' => trim( (string) $name ) );
					},
					$unknown
				),
				'tag' === $type ? BWFCRM_Term_Type::$TAG : BWFCRM_Term_Type::$LIST,
				true,
				true
			);

			$rows = array();

			if ( is_array( $made ) ) {
				// Both buckets: every one of these names was absent from the
				// store we just read, so "existing" only catches a race.
				foreach ( array( 'created', 'existing' ) as $bucket ) {
					if ( ! empty( $made[ $bucket ] ) ) {
						$rows = array_merge( $rows, (array) BWFCRM_Term::get_collection_array( $made[ $bucket ] ) );
					}
				}
			}

			$made_by_name = array();

			foreach ( $rows as $row ) {
				$row = (array) $row;

				if ( isset( $row['ID'], $row['name'] ) ) {
					$pair                                                   = array( 'id' => (int) $row['ID'], 'value' => (string) $row['name'] );
					$made_by_name[ strtolower( trim( $row['name'] ) ) ]     = $pair;
				}
			}

			// Into the memo as well: manage-contact-tags-lists resolves each
			// operation in turn, so a remove_tags naming what add_tags just
			// coined would otherwise read the list from before it existed.
			foreach ( $made_by_name as $key => $pair ) {
				$memo[ $type ]['by_id'][ $pair['id'] ] = $pair;
				$memo[ $type ]['by_name'][ $key ]      = $pair;
			}

			$left = array();

			foreach ( $unknown as $item ) {
				$key = strtolower( trim( (string) $item ) );

				if ( isset( $made_by_name[ $key ] ) ) {
					$pairs[ $made_by_name[ $key ]['id'] ] = $made_by_name[ $key ];
					$created[]                            = $made_by_name[ $key ];
				} else {
					$left[] = $item;
				}
			}

			$unknown = $left;
		}

		if ( ! empty( $unknown ) ) {
			return new WP_Error(
				'fkmcp_unknown_term',
				sprintf(
					/* translators: 1: tag or list, 2: unmatched values. */
					__( 'Unknown %1$s(s): %2$s. Use list-tags / list-contact-lists for valid names, or pass ids.', 'wp-marketing-automations-pro' ),
					$type,
					implode( ', ', array_map( 'strval', $unknown ) )
				),
				array( 'unknown' => $unknown )
			);
		}

		return array_values( $pairs );
	}

	/**
	 * The §6 value-mapping contract: field slug/name → numeric field ID, and
	 * for choice fields (select/radio/checkbox) the given value/label → the
	 * exact stored option string, case-insensitively. Fail-closed both ways.
	 */
	/**
	 * Contact columns that list-custom-fields advertises next to the custom
	 * fields. apply_field's set_data() writes them by slug (and maps a country
	 * name to its code), so they pass through as slugs; custom fields go by id.
	 */
	const CONTACT_COLUMN_FIELDS = array( 'f_name', 'l_name', 'contact_no', 'country', 'state', 'timezone' );

	private function resolve_fields( $fields ) {
		$defs = BWFCRM_Fields::get_custom_fields();
		$defs = is_array( $defs ) ? $defs : array();

		$by_key = array();

		foreach ( $defs as $def ) {
			if ( ! isset( $def['ID'] ) ) {
				continue;
			}

			if ( ! empty( $def['slug'] ) ) {
				$by_key[ strtolower( (string) $def['slug'] ) ] = $def;
			}

			if ( ! empty( $def['name'] ) ) {
				$by_key[ strtolower( (string) $def['name'] ) ] = $def;
			}
		}

		$choice_types = array( 4, 5, 6 ); // select, radio, checkbox

		$resolved = array();

		foreach ( (array) $fields as $key => $value ) {
			$slug = strtolower( trim( (string) $key ) );
			$def  = $by_key[ $slug ] ?? null;

			if ( null === $def && in_array( $slug, self::CONTACT_COLUMN_FIELDS, true ) ) {
				$resolved[ $slug ] = is_scalar( $value ) ? sanitize_text_field( (string) $value ) : '';
				continue;
			}

			if ( null === $def ) {
				return new WP_Error(
					'fkmcp_unknown_field',
					sprintf(
						/* translators: %s: field key. */
						__( 'Unknown field "%s". Call get-automations-context include=["fields"] for the schema.', 'wp-marketing-automations-pro' ),
						$key
					)
				);
			}

			if ( isset( $def['type'] ) && in_array( (int) $def['type'], $choice_types, true ) ) {
				// meta arrives decoded from get_custom_fields(), raw JSON from SELECT *.
				$meta    = isset( $def['meta'] ) ? $def['meta'] : array();
				$meta    = is_string( $meta ) ? json_decode( $meta, true ) : $meta;
				$options = is_array( $meta ) && isset( $meta['options'] ) && is_array( $meta['options'] ) ? $meta['options'] : array();

				$map = array();
				foreach ( $options as $option ) {
					$map[ strtolower( trim( (string) $option ) ) ] = (string) $option;
				}

				$values  = is_array( $value ) ? $value : array( $value );
				$stored  = array();

				foreach ( $values as $one ) {
					$canonical = $map[ strtolower( trim( (string) $one ) ) ] ?? null;

					if ( null === $canonical ) {
						return new WP_Error(
							'fkmcp_unknown_option',
							sprintf(
								/* translators: 1: given value, 2: field name, 3: valid options. */
								__( '"%1$s" is not a valid option for field "%2$s". Valid options: %3$s.', 'wp-marketing-automations-pro' ),
								$one,
								$def['name'],
								implode( ', ', $options )
							),
							array( 'valid_options' => $options )
						);
					}

					$stored[] = $canonical;
				}

				$value = is_array( $value ) ? $stored : $stored[0];
			}

			$resolved[ (int) $def['ID'] ] = $value;
		}

		return $resolved;
	}

	/**
	 * apply_field answers a failed write with HTTP 200 and an empty result, so
	 * is_wp_error() alone would read a dropped update as success. Every caller
	 * goes through here rather than repeating the soft-fail check.
	 */
	private function apply_fields_to_contact( $cid, $fields ) {
		$response = BWFAN_MCP_Dispatch::write( 'apply-contact-fields', array( 'contact_id' => $cid, 'fields' => $fields ), array( 'contact_id' => $cid ) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		if ( isset( $response['result'] ) && '' === $response['result'] ) {
			return new WP_Error( 'fkmcp_update_failed', isset( $response['message'] ) ? $response['message'] : __( 'Unable to update fields.', 'wp-marketing-automations-pro' ) );
		}

		return $response;
	}

	/**
	 * These tools mutate over several dispatches and cannot roll back, so a
	 * failure halfway leaves real changes behind. Re-stamp the error with what
	 * already landed: a bare error reads as "nothing happened" and the agent
	 * retries, applying the earlier steps twice.
	 *
	 * @param WP_Error $error
	 * @param array    $done
	 *
	 * @return WP_Error
	 */
	private function partial_failure( $error, array $done ) {
		if ( empty( $done ) ) {
			return $error;
		}

		$data                           = (array) $error->get_error_data();
		$data['applied_before_failure'] = $done;

		return new WP_Error( $error->get_error_code(), $error->get_error_message(), $data );
	}

	public function create_contact( $input = array() ) {
		$input = (array) $input;
		$email = isset( $input['email'] ) ? sanitize_email( $input['email'] ) : '';

		if ( '' === $email || ! is_email( $email ) ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'A valid email is required.', 'wp-marketing-automations-pro' ) );
		}

		$prepared = $this->prepare_contact_changes( $input );

		if ( is_wp_error( $prepared ) ) {
			return $prepared;
		}

		list( $fields, $input ) = $prepared;

		$existing = new BWFCRM_Contact( $email );

		if ( $existing->is_contact_exists() ) {
			return new WP_Error(
				'fkmcp_exists',
				__( 'A Contact with this email already exists; use update-contact.', 'wp-marketing-automations-pro' ),
				array( 'contact_id' => (int) $existing->get_id() )
			);
		}

		$body = array( 'email' => $email );

		foreach ( array( 'f_name', 'l_name', 'contact_no' ) as $prop ) {
			if ( ! empty( $input[ $prop ] ) ) {
				$body[ $prop ] = sanitize_text_field( $input[ $prop ] );
			}
		}

		if ( ! empty( $input['tags'] ) ) {
			$body['tags'] = $input['tags'];
		}
		if ( ! empty( $input['lists'] ) ) {
			$body['lists'] = $input['lists'];
		}

		$response = BWFAN_MCP_Dispatch::write( 'create-contact', $body );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$row = isset( $response['result'] ) && is_array( $response['result'] ) ? $response['result'] : array();

		// Custom fields persist via apply_field — create_contact's constructor
		// path does not save numeric field keys.
		if ( ! empty( $fields ) && ! empty( $row['id'] ) ) {
			$applied = $this->apply_fields_to_contact( (int) $row['id'], $fields );

			if ( is_wp_error( $applied ) ) {
				// The Contact is already saved. Say so, or a retry creates
				// nothing and reports "already exists" for a half-built row.
				return $this->partial_failure( $applied, array( 'created' => (int) $row['id'] ) );
			}
		}

		return array(
			'result'  => 'created',
			'contact' => self::untrust( FKMCP_Pack_Lite::decorate_contact_row( BWFAN_MCP_Format::pick( $row, FKMCP_Pack_Lite::CONTACT_KEYS ) ) ),
		);
	}

	public function update_contact( $input = array() ) {
		$input   = (array) $input;
		$contact = $this->resolve_contact( $input );

		if ( is_wp_error( $contact ) ) {
			return $contact;
		}

		$prepared = $this->prepare_contact_changes( $input );

		if ( is_wp_error( $prepared ) ) {
			return $prepared;
		}

		list( $fields, $input ) = $prepared;

		$cid = $contact->get_id();

		// apply_field persists both system columns (f_name, …) and
		// numeric custom-field ids; update_contact's meta path does not.
		$field_payload = $fields;

		foreach ( array( 'f_name', 'l_name', 'contact_no' ) as $prop ) {
			if ( ! empty( $input[ $prop ] ) ) {
				$field_payload[ $prop ] = sanitize_text_field( $input[ $prop ] );
			}
		}

		if ( empty( $field_payload ) && empty( $input['tags'] ) && empty( $input['lists'] ) ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'Nothing to change: pass f_name, l_name, contact_no, fields, tags or lists.', 'wp-marketing-automations-pro' ) );
		}

		$done = array();

		if ( ! empty( $field_payload ) ) {
			$response = $this->apply_fields_to_contact( $cid, $field_payload );

			if ( is_wp_error( $response ) ) {
				return $response;
			}

			$done['fields'] = count( $field_payload );
		}

		foreach ( array( 'tags' => 'assign-contact-tags', 'lists' => 'assign-contact-lists' ) as $param => $slug ) {
			if ( empty( $input[ $param ] ) ) {
				continue;
			}

			$response = BWFAN_MCP_Dispatch::write( $slug, array( 'contact_id' => $cid, $param => $input[ $param ] ), array( 'contact_id' => $cid ) );

			if ( is_wp_error( $response ) ) {
				return $this->partial_failure( $response, $done );
			}

			$done[ $param ] = count( (array) $input[ $param ] );
		}

		return array( 'result' => 'updated', 'contact_id' => $cid, 'applied' => $done );
	}

	/**
	 * Resolves custom fields and tag/list names to what the controllers take.
	 *
	 * @return array|WP_Error array( $fields, $input )
	 */
	private function prepare_contact_changes( array $input ) {
		$fields = array();

		if ( ! empty( $input['fields'] ) ) {
			$fields = $this->resolve_fields( (array) $input['fields'] );

			if ( is_wp_error( $fields ) ) {
				return $fields;
			}
		}

		foreach ( array( 'tags', 'lists' ) as $term_type ) {
			if ( ! empty( $input[ $term_type ] ) ) {
				$resolved = $this->resolve_terms( $input[ $term_type ], rtrim( $term_type, 's' ) );

				if ( is_wp_error( $resolved ) ) {
					return $resolved;
				}

				$input[ $term_type ] = $resolved;
			}
		}

		return array( $fields, $input );
	}

	public function manage_contact_tags_lists( $input = array() ) {
		$input   = (array) $input;
		$contact = $this->resolve_contact( $input );

		if ( is_wp_error( $contact ) ) {
			return $contact;
		}

		$ops = array(
			'add_tags'     => array( 'tag', 'assign-contact-tags', 'tags' ),
			'remove_tags'  => array( 'tag', 'remove-contact-tags', 'tags' ),
			'add_lists'    => array( 'list', 'assign-contact-lists', 'lists' ),
			'remove_lists' => array( 'list', 'remove-contact-lists', 'lists' ),
		);

		$requested = array_filter( array_intersect_key( $input, $ops ) );

		if ( empty( $requested ) ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'Pass at least one of add_tags, remove_tags, add_lists, remove_lists.', 'wp-marketing-automations-pro' ) );
		}

		// Resolve everything first — fail-closed before any mutation. Term
		// creation (create_missing) only runs when its whole batch resolves,
		// and only for the add operations.
		$create_missing = ! empty( $input['create_missing'] );
		$resolved       = array();
		$created        = array( 'tags' => array(), 'lists' => array() );

		foreach ( $requested as $op => $items ) {
			$made = array();
			$ids  = $this->resolve_terms( $items, $ops[ $op ][0], $create_missing && 0 === strpos( $op, 'add_' ), $made );

			if ( is_wp_error( $ids ) ) {
				return $ids;
			}

			$resolved[ $op ] = $ids;

			if ( ! empty( $made ) ) {
				$created[ $ops[ $op ][2] ] = array_merge( $created[ $ops[ $op ][2] ], $made );
			}
		}

		$done = array();

		foreach ( $resolved as $op => $pairs ) {
			list( , $slug, $param ) = $ops[ $op ];

			// Assign endpoints expect {id, value} pairs; delete endpoints plain ids.
			$payload = 0 === strpos( $op, 'remove_' ) ? array_column( $pairs, 'id' ) : $pairs;

			// The delete endpoints answer 500 when none of the ids were on the
			// Contact, so a repeat of a finished removal would read as an outage.
			if ( 0 === strpos( $op, 'remove_' ) ) {
				$present = $this->terms_present( $contact->get_id(), $ops[ $op ][0] );
				$payload = null === $present ? $payload : array_values( array_intersect( array_map( 'intval', $payload ), $present ) );

				if ( array() === $payload ) {
					$done[ $op ] = array(
						'requested' => count( $pairs ),
						'applied'   => 0,
						'message'   => __( 'None of these were on the Contact.', 'wp-marketing-automations-pro' ),
					);
					continue;
				}
			}

			$response = BWFAN_MCP_Dispatch::write(
				$slug,
				array( 'contact_id' => $contact->get_id(), $param => $payload ),
				array( 'contact_id' => $contact->get_id() )
			);

			if ( is_wp_error( $response ) ) {
				return $this->partial_failure( $response, $done );
			}

			$row = isset( $response['result'] ) && is_array( $response['result'] ) ? $response['result'] : array();

			/**
			 * Requested is not applied: the assign endpoints skip terms the
			 * Contact already has and say so only in the message, and the
			 * delete endpoints report no count at all. Echo what each one
			 * actually gives rather than asserting a number it never returned.
			 */
			$applied = null;

			foreach ( array( 'tags_added', 'list_added' ) as $key ) {
				if ( isset( $row[ $key ] ) && is_array( $row[ $key ] ) ) {
					$applied = count( $row[ $key ] );
				}
			}

			if ( null === $applied && 0 === strpos( $op, 'remove_' ) ) {
				$applied = $this->terms_removed( $contact->get_id(), $ops[ $op ][0], array_column( $pairs, 'id' ) );
			}

			$done[ $op ] = array(
				'requested' => count( $pairs ),
				'applied'   => $applied,
				'message'   => isset( $response['message'] ) && is_scalar( $response['message'] ) ? (string) $response['message'] : '',
			);
		}

		return array(
			'result'     => 'done',
			'contact_id' => $contact->get_id(),
			'applied'    => $done,
			'created'    => array_filter( $created ),
		);
	}

	/** The tag or list ids on a Contact right now, read fresh; null when it cannot be read. */
	private function terms_present( $cid, $type ) {
		$fresh = new BWFCRM_Contact( (int) $cid );

		if ( ! $fresh->is_contact_exists() || ! isset( $fresh->contact ) || ! is_object( $fresh->contact ) ) {
			return null;
		}

		$ids = 'tag' === $type ? $fresh->contact->get_tags() : $fresh->contact->get_lists();

		return array_map( 'intval', is_array( $ids ) ? $ids : array() );
	}

	/** The delete endpoints report no count: read the Contact back and count what is gone. */
	private function terms_removed( $cid, $type, array $ids ) {
		$left = $this->terms_present( $cid, $type );

		return null === $left ? null : count( array_diff( array_map( 'intval', $ids ), $left ) );
	}

	public function change_contact_status( $input = array() ) {
		$input   = (array) $input;
		$contact = $this->resolve_contact( $input );

		if ( is_wp_error( $contact ) ) {
			return $contact;
		}

		$action  = isset( $input['action'] ) && is_string( $input['action'] ) ? $input['action'] : '';
		$allowed = array( 'unsubscribe', 'resubscribe', 'verify', 'unverify', 'bounced', 'softbounced', 'complaint' );

		if ( ! in_array( $action, $allowed, true ) ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'Unknown status action.', 'wp-marketing-automations-pro' ), array( 'allowed' => $allowed ) );
		}

		$response = BWFAN_MCP_Dispatch::write(
			'contact-status-action',
			array( 'contact_id' => $contact->get_id(), 'status' => $action ),
			array( 'contact_id' => $contact->get_id() )
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$row = isset( $response['result'] ) && is_array( $response['result'] ) ? $response['result'] : array();

		return array(
			'result'     => 'done',
			'contact_id' => $contact->get_id(),
			'status'     => isset( $row['status'] ) ? $row['status'] : null,
		);
	}

	public function add_contact_note( $input = array() ) {
		$input   = (array) $input;
		$contact = $this->resolve_contact( $input );

		if ( is_wp_error( $contact ) ) {
			return $contact;
		}

		$body = isset( $input['body'] ) && is_string( $input['body'] ) ? trim( $input['body'] ) : '';

		if ( '' === $body ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'body is required.', 'wp-marketing-automations-pro' ) );
		}

		$type = $this->note_type( isset( $input['type'] ) ? $input['type'] : 'others' );

		if ( is_wp_error( $type ) ) {
			return $type;
		}

		$note = array(
			'title' => isset( $input['title'] ) && is_string( $input['title'] ) ? sanitize_text_field( $input['title'] ) : '',
			'body'  => wp_kses_post( $body ),
			'type'  => $type,
		);

		$response = BWFAN_MCP_Dispatch::write(
			'create-contact-note',
			array( 'contact_id' => $contact->get_id(), 'notes' => $note ),
			array( 'contact_id' => $contact->get_id() )
		);

		return is_wp_error( $response ) ? $response : array( 'result' => 'added', 'contact_id' => $contact->get_id() );
	}

	public function get_contact_notes( $input = array() ) {
		$input   = (array) $input;
		$contact = $this->resolve_contact( $input );

		if ( is_wp_error( $contact ) ) {
			return $contact;
		}

		$page     = BWFAN_MCP_Format::paginate( $input );
		$response = BWFAN_MCP_Dispatch::call(
			'get-contact-notes',
			array( 'limit' => $page['limit'], 'offset' => $page['offset'] ),
			array( 'contact_id' => $contact->get_id() )
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$labels     = $this->note_types();
		$collection = BWFAN_MCP_Format::collection( $response, array( 'id', 'title', 'body', 'type', 'date_time', 'created_date', 'modified_date', 'created_username' ), 'result' );

		foreach ( $collection['items'] as &$note ) {
			$type                    = isset( $note['type'] ) ? (string) $note['type'] : '';
			$note['id']              = isset( $note['id'] ) ? (int) $note['id'] : 0;
			$note['type_label']      = isset( $labels[ $type ] ) ? $labels[ $type ] : null;
			$note['created_by_name'] = isset( $note['created_username'] ) && '' !== trim( (string) $note['created_username'] ) ? trim( (string) $note['created_username'] ) : null;
			unset( $note['created_username'] );
		}
		unset( $note );

		// The controller leaves total_count out of an empty page, and its shared instance can carry
		// the last call's count: an empty first page is 0 notes, an empty later page is unknown.
		if ( array() === $collection['items'] ) {
			$collection['total'] = 0 === $page['offset'] ? 0 : null;
		}

		$collection['contact_id'] = $contact->get_id();

		return $collection;
	}

	public function update_contact_note( $input = array() ) {
		$input   = (array) $input;
		$contact = $this->resolve_contact( $input );

		if ( is_wp_error( $contact ) ) {
			return $contact;
		}

		$note_id = isset( $input['note_id'] ) ? absint( $input['note_id'] ) : 0;
		$row     = $note_id > 0 ? BWFAN_Model_Contact_Note::get( $note_id ) : array();

		// Lite's update matches on note id and contact id and reports success on 0 rows, so check first.
		if ( ! is_array( $row ) || empty( $row['cid'] ) || absint( $row['cid'] ) !== (int) $contact->get_id() ) {
			return new WP_Error( 'fkmcp_not_found', __( 'No note with that note_id on this Contact. Read the ids with get-contact-notes.', 'wp-marketing-automations-pro' ) );
		}

		$note = array();

		if ( isset( $input['title'] ) && is_string( $input['title'] ) && '' !== trim( $input['title'] ) ) {
			$note['title'] = sanitize_text_field( $input['title'] );
		}

		if ( isset( $input['body'] ) && is_string( $input['body'] ) && '' !== trim( $input['body'] ) ) {
			$note['body'] = wp_kses_post( trim( $input['body'] ) );
		}

		if ( isset( $input['type'] ) ) {
			$type = $this->note_type( $input['type'] );

			if ( is_wp_error( $type ) ) {
				return $type;
			}

			$note['type'] = $type;
		}

		if ( empty( $note ) ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'Pass at least one of title, body or type to change.', 'wp-marketing-automations-pro' ) );
		}

		$note['modified_by'] = get_current_user_id();

		$response = BWFAN_MCP_Dispatch::write(
			'update-contact-note',
			array( 'contact_id' => $contact->get_id(), 'note_id' => $note_id, 'notes' => $note ),
			array( 'contact_id' => $contact->get_id(), 'note_id' => $note_id )
		);

		return is_wp_error( $response ) ? $response : array( 'result' => 'updated', 'contact_id' => $contact->get_id(), 'note_id' => $note_id );
	}

	public function create_tags( $input = array() ) {
		$names = $this->clean_names( isset( $input['names'] ) ? $input['names'] : array() );

		if ( empty( $names ) ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'Pass at least one tag name.', 'wp-marketing-automations-pro' ) );
		}

		// Lite finds existing names in SQL (case-insensitive) but matches them in PHP case-sensitively,
		// so "vip" next to "VIP" would become a second tag: send each existing name as it is stored.
		$stored = array();
		foreach ( (array) BWFCRM_Term::get_terms( BWFCRM_Term_Type::$TAG, array(), $names, 0, 0, ARRAY_A, 'exact' ) as $row ) {
			if ( isset( $row['name'] ) ) {
				$stored[ strtolower( (string) $row['name'] ) ] = (string) $row['name'];
			}
		}
		foreach ( $names as $i => $name ) {
			if ( isset( $stored[ strtolower( $name ) ] ) ) {
				$names[ $i ] = $stored[ strtolower( $name ) ];
			}
		}

		$response = BWFAN_MCP_Dispatch::write( 'create-tags', array( 'tags' => $names ) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$tags = array();
		foreach ( isset( $response['result'] ) && is_array( $response['result'] ) ? $response['result'] : array() as $row ) {
			if ( is_array( $row ) && isset( $row['ID'], $row['name'] ) ) {
				$tags[] = array( 'tag_id' => (int) $row['ID'], 'name' => (string) $row['name'] );
			}
		}

		return array( 'result' => 'done', 'tags' => $tags );
	}

	public function update_tag( $input = array() ) {
		$tag_id = isset( $input['tag_id'] ) ? absint( $input['tag_id'] ) : 0;
		$name   = $this->clean_name( isset( $input['name'] ) ? $input['name'] : '' );

		if ( '' === $name ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'name is required.', 'wp-marketing-automations-pro' ) );
		}

		$row = $tag_id > 0 ? BWFCRM_Term::get_terms( BWFCRM_Term_Type::$TAG, array( $tag_id ) ) : array();

		if ( empty( $row[0]['name'] ) ) {
			return new WP_Error( 'fkmcp_not_found', __( 'No tag with that tag_id. Read the ids with list-tags.', 'wp-marketing-automations-pro' ) );
		}

		$taken = $this->term_named( BWFCRM_Term_Type::$TAG, $name, $tag_id );
		if ( $taken ) {
			/* translators: %d: tag id */
			return new WP_Error( 'fkmcp_exists', sprintf( __( 'Another tag already has that name: tag_id %d.', 'wp-marketing-automations-pro' ), $taken ) );
		}

		// Lite looks the new name up before comparing it with the old one, case-insensitively, so it
		// refuses the tag's own name and any case-only change as "already exists".
		$current = (string) $row[0]['name'];
		if ( $name === $current ) {
			return array( 'result' => 'updated', 'tag_id' => $tag_id, 'name' => $name );
		}
		if ( 0 === strcasecmp( $name, $current ) ) {
			BWFAN_Model_Terms::update( array( 'name' => $name ), array( 'ID' => $tag_id ) );

			return array( 'result' => 'updated', 'tag_id' => $tag_id, 'name' => $name );
		}

		$response = BWFAN_MCP_Dispatch::write( 'update-tag', array( 'tag_id' => $tag_id, 'tag_name' => $name ), array( 'tag_id' => $tag_id ) );

		return is_wp_error( $response ) ? $response : array( 'result' => 'updated', 'tag_id' => $tag_id, 'name' => $name );
	}

	public function create_list( $input = array() ) {
		$name = $this->clean_name( isset( $input['name'] ) ? $input['name'] : '' );

		if ( '' === $name ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'name is required.', 'wp-marketing-automations-pro' ) );
		}

		$taken = $this->term_named( BWFCRM_Term_Type::$LIST, $name );
		if ( $taken ) {
			/* translators: %d: list id */
			return new WP_Error( 'fkmcp_exists', sprintf( __( 'A list with that name already exists: list_id %d.', 'wp-marketing-automations-pro' ), $taken ) );
		}

		$body = array( 'name' => $name );
		if ( isset( $input['description'] ) && is_string( $input['description'] ) ) {
			$body['description'] = sanitize_text_field( $input['description'] );
		}

		$response = BWFAN_MCP_Dispatch::write( 'create-list', $body );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		// create_single_list() answers ID 0: it reads the list's array before save() sets the id.
		$list_id = isset( $response['result']['ID'] ) ? (int) $response['result']['ID'] : 0;

		return array( 'result' => 'created', 'list_id' => $list_id > 0 ? $list_id : $this->term_named( BWFCRM_Term_Type::$LIST, $name ), 'name' => $name );
	}

	public function update_list( $input = array() ) {
		$list_id = isset( $input['list_id'] ) ? absint( $input['list_id'] ) : 0;
		$list    = new BWFCRM_Lists( $list_id );

		// BWFCRM_Lists (and Lite's update_list()) load any term id, so a tag's id would rename the tag.
		if ( $list_id < 1 || ! $list->is_exists() || empty( BWFCRM_Term::get_terms( BWFCRM_Term_Type::$LIST, array( $list_id ) ) ) ) {
			return new WP_Error( 'fkmcp_not_found', __( 'No list with that list_id. Read the ids with list-contact-lists.', 'wp-marketing-automations-pro' ) );
		}

		$has_name = isset( $input['name'] );
		$has_desc = isset( $input['description'] ) && is_string( $input['description'] );
		$name     = $has_name ? $this->clean_name( $input['name'] ) : (string) $list->get_name();

		if ( ( ! $has_name && ! $has_desc ) || '' === $name ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'Pass a name or a description to change.', 'wp-marketing-automations-pro' ) );
		}

		$taken = $this->term_named( BWFCRM_Term_Type::$LIST, $name, $list_id );
		if ( $taken ) {
			/* translators: %d: list id */
			return new WP_Error( 'fkmcp_exists', sprintf( __( 'Another list already has that name: list_id %d.', 'wp-marketing-automations-pro' ), $taken ) );
		}

		// Lite's update_list() blanks the description when none is sent, so the current one goes along.
		$description = $has_desc ? sanitize_text_field( $input['description'] ) : (string) $list->get_description();

		// Lite checks a changed name against every list, case-insensitively, so a case-only rename finds
		// the list itself and is refused: write the name first, then Lite sees it unchanged.
		$current = (string) $list->get_name();
		if ( $name !== $current && 0 === strcasecmp( $name, $current ) ) {
			BWFAN_Model_Terms::update( array( 'name' => $name ), array( 'ID' => $list_id ) );
			$current = $name;
		}

		// Lite's save() reports a list it did not change as a 500, so Lite is called only for a real change.
		if ( $name === $current && $description === (string) $list->get_description() ) {
			return array( 'result' => 'updated', 'list_id' => $list_id, 'name' => $name, 'description' => $description );
		}

		$response = BWFAN_MCP_Dispatch::write( 'update-list', array( 'list_id' => $list_id, 'list_name' => $name, 'description' => $description ), array( 'list_id' => $list_id ) );

		return is_wp_error( $response ) ? $response : array( 'result' => 'updated', 'list_id' => $list_id, 'name' => $name, 'description' => $description );
	}

	public function list_field_groups( $input = array() ) {
		$items = array();

		foreach ( (array) BWFCRM_Group::get_groups( array() ) as $group ) {
			if ( is_array( $group ) && isset( $group['id'], $group['name'] ) ) {
				$items[] = array( 'group_id' => (int) $group['id'], 'name' => (string) $group['name'] );
			}
		}

		return array( 'items' => $items );
	}

	public function create_field_group( $input = array() ) {
		$name = $this->clean_name( isset( $input['name'] ) ? $input['name'] : '' );

		if ( '' === $name ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'name is required.', 'wp-marketing-automations-pro' ) );
		}

		// Lite's add_group() does not check, so a second call would make a second group of the same name.
		$taken = BWFCRM_Group::get_groupby_name( $name );
		if ( ! empty( $taken[0]['ID'] ) ) {
			/* translators: %d: field group id */
			return new WP_Error( 'fkmcp_exists', sprintf( __( 'A field group with that name already exists: group_id %d.', 'wp-marketing-automations-pro' ), (int) $taken[0]['ID'] ) );
		}

		$response = BWFAN_MCP_Dispatch::write( 'create-field-group', array( 'group_name' => $name ) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		return array( 'result' => 'created', 'group_id' => isset( $response['result'][0]['id'] ) ? (int) $response['result'][0]['id'] : 0, 'name' => $name );
	}

	public function update_field_group( $input = array() ) {
		$group_id = isset( $input['group_id'] ) ? absint( $input['group_id'] ) : 0;
		$name     = $this->clean_name( isset( $input['name'] ) ? $input['name'] : '' );
		$group    = $group_id > 0 ? BWFCRM_Group::get_groupby_id( $group_id ) : array();

		if ( empty( $group[0] ) ) {
			return new WP_Error( 'fkmcp_not_found', __( 'No field group with that group_id. Read the ids with list-field-groups.', 'wp-marketing-automations-pro' ) );
		}

		if ( '' === $name ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'name is required.', 'wp-marketing-automations-pro' ) );
		}

		// Lite reports an update that changes no row as a failure.
		if ( $name === (string) $group[0]['name'] ) {
			return array( 'result' => 'updated', 'group_id' => $group_id, 'name' => $name );
		}

		$taken = BWFCRM_Group::get_groupby_name( $name );
		if ( ! empty( $taken[0]['ID'] ) && (int) $taken[0]['ID'] !== $group_id ) {
			/* translators: %d: field group id */
			return new WP_Error( 'fkmcp_exists', sprintf( __( 'Another field group already has that name: group_id %d.', 'wp-marketing-automations-pro' ), (int) $taken[0]['ID'] ) );
		}

		$response = BWFAN_MCP_Dispatch::write( 'update-field-group', array( 'group_id' => $group_id, 'group_name' => $name ), array( 'group_id' => $group_id ) );

		return is_wp_error( $response ) ? $response : array( 'result' => 'updated', 'group_id' => $group_id, 'name' => $name );
	}

	public function create_custom_field( $input = array() ) {
		$name = $this->clean_name( isset( $input['name'] ) ? $input['name'] : '' );
		$type = isset( $input['type'] ) && is_string( $input['type'] ) && isset( self::FIELD_TYPES[ $input['type'] ] ) ? $input['type'] : '';
		$slug = sanitize_title( $name );

		if ( '' === $name || '' === $slug ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'name is required.', 'wp-marketing-automations-pro' ) );
		}

		if ( '' === $type ) {
			/* translators: %s: comma-separated field types */
			return new WP_Error( 'fkmcp_invalid_input', sprintf( __( 'Unknown field type. Use one of: %s.', 'wp-marketing-automations-pro' ), implode( ', ', array_keys( self::FIELD_TYPES ) ) ) );
		}

		if ( in_array( $slug, BWFCRM_Fields::$reserved_keys, true ) ) {
			/* translators: %s: field slug */
			return new WP_Error( 'fkmcp_invalid_input', sprintf( __( '%s is a built-in Contact key; pick another name.', 'wp-marketing-automations-pro' ), $slug ) );
		}

		$options = $this->clean_names( isset( $input['options'] ) ? $input['options'] : array(), false );
		$choice  = $this->is_choice_type( self::FIELD_TYPES[ $type ] );

		if ( $choice && empty( $options ) ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'A select, radio or checkbox field needs options.', 'wp-marketing-automations-pro' ) );
		}

		if ( ! $choice && ! empty( $options ) ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'Only select, radio and checkbox fields take options.', 'wp-marketing-automations-pro' ) );
		}

		$existing = BWFCRM_Fields::get_fieldby_name( $name );
		if ( ! empty( $existing[0]['ID'] ) ) {
			/* translators: %d: field id */
			return new WP_Error( 'fkmcp_exists', sprintf( __( 'A field with that name already exists: field_id %d.', 'wp-marketing-automations-pro' ), (int) $existing[0]['ID'] ) );
		}

		$field = array(
			'name'        => $name,
			'type'        => self::FIELD_TYPES[ $type ],
			'options'     => $options,
			'placeholder' => isset( $input['placeholder'] ) && is_string( $input['placeholder'] ) ? sanitize_text_field( $input['placeholder'] ) : '',
			'mode'        => 1,
			'vmode'       => 1,
			'search'      => isset( $input['searchable'] ) && false === $input['searchable'] ? 2 : 1,
		);

		$response = BWFAN_MCP_Dispatch::write( 'create-custom-field', array( 'field' => $field, 'group_id' => isset( $input['group_id'] ) ? absint( $input['group_id'] ) : 0 ) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$row = isset( $response['result'] ) && is_array( $response['result'] ) ? $response['result'] : array();

		return array(
			'result'    => 'created',
			'field_id'  => isset( $row['ID'] ) ? (int) $row['ID'] : 0,
			'slug'      => isset( $row['slug'] ) ? (string) $row['slug'] : $slug,
			'name'      => $name,
			'type'      => $type,
			'merge_tag' => isset( $row['merge_tag'] ) && '' !== $row['merge_tag'] ? (string) $row['merge_tag'] : null,
		);
	}

	/**
	 * The safe subset of Lite's update_field(): name, placeholder, group and
	 * new options. Lite rebuilds the field's meta from only the keys it is
	 * sent, adds or drops the column index from `search`, and moves a field
	 * sent without a group_id to group 0, so the current options,
	 * placeholder, search and group always go along; type and mode never do,
	 * so neither changes.
	 */
	public function update_custom_field( $input = array() ) {
		$field_id = isset( $input['field_id'] ) ? absint( $input['field_id'] ) : 0;
		$row      = $field_id > 0 ? BWFAN_Model_Fields::get_field_by_id( $field_id ) : array();

		if ( empty( $row['ID'] ) ) {
			return new WP_Error( 'fkmcp_not_found', __( 'No custom field with that field_id. Read the ids with list-custom-fields.', 'wp-marketing-automations-pro' ) );
		}

		if ( 1 !== (int) $row['mode'] ) {
			return new WP_Error( 'fkmcp_refused', __( 'That field is built in and cannot be edited.', 'wp-marketing-automations-pro' ) );
		}

		$meta        = isset( $row['meta'] ) ? (array) $row['meta'] : array();
		$options     = isset( $meta['options'] ) ? array_values( (array) $meta['options'] ) : array();
		$placeholder = isset( $meta['placeholder'] ) ? (string) $meta['placeholder'] : '';
		$changed     = false;
		// Lite's fields controller defaults group_id to '', so a field sent without one lands in group 0.
		$body        = array( 'field_id' => $field_id, 'slug' => (string) $row['slug'], 'search' => (int) $row['search'], 'group_id' => isset( $row['gid'] ) ? (int) $row['gid'] : 0 );

		if ( isset( $input['name'] ) ) {
			$name = $this->clean_name( $input['name'] );
			if ( '' === $name ) {
				return new WP_Error( 'fkmcp_invalid_input', __( 'name cannot be empty.', 'wp-marketing-automations-pro' ) );
			}

			// By label: a renamed field keeps its old slug, so get_fieldby_name() (a slug lookup) misses it.
			$other = BWFAN_Model_Fields::get_results( 'SELECT ID FROM {table_name} WHERE name = %s AND ID != %d LIMIT 1', array( $name, $field_id ) );
			if ( ! empty( $other[0]['ID'] ) ) {
				/* translators: %d: field id */
				return new WP_Error( 'fkmcp_exists', sprintf( __( 'Another field already has that name: field_id %d.', 'wp-marketing-automations-pro' ), (int) $other[0]['ID'] ) );
			}

			$body['name'] = $name;
			$changed      = true;
		}

		if ( isset( $input['placeholder'] ) && is_string( $input['placeholder'] ) && '' !== trim( $input['placeholder'] ) ) {
			$placeholder = sanitize_text_field( $input['placeholder'] );
			$changed     = true;
		}

		if ( isset( $input['group_id'] ) ) {
			$body['group_id'] = absint( $input['group_id'] );
			$changed          = true;
		}

		if ( isset( $input['add_options'] ) ) {
			if ( ! $this->is_choice_type( (int) $row['type'] ) ) {
				return new WP_Error( 'fkmcp_invalid_input', __( 'Only select, radio and checkbox fields take options.', 'wp-marketing-automations-pro' ) );
			}

			$options = $this->clean_names( array_merge( $options, (array) $input['add_options'] ), false );
			$changed = true;
		}

		if ( ! $changed ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'Pass at least one of name, placeholder, group_id or add_options.', 'wp-marketing-automations-pro' ) );
		}

		$body['options']     = $options;
		$body['placeholder'] = $placeholder;

		$response = BWFAN_MCP_Dispatch::write( 'update-custom-field', $body, array( 'field_id' => $field_id ) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		return array(
			'result'   => 'updated',
			'field_id' => $field_id,
			'slug'     => (string) $row['slug'],
			'name'     => isset( $body['name'] ) ? $body['name'] : (string) $row['name'],
			'options'  => array_map( 'strval', $options ),
		);
	}

	/** Select, radio and checkbox: the field types that carry options. */
	private function is_choice_type( $code ) {
		return in_array( (int) $code, array( self::FIELD_TYPES['select'], self::FIELD_TYPES['radio'], self::FIELD_TYPES['checkbox'] ), true );
	}

	private function clean_name( $value ) {
		return is_string( $value ) ? trim( sanitize_text_field( $value ) ) : '';
	}

	/** Trimmed, sanitised, non-empty strings, each once; case-insensitive for names, exact for options. */
	private function clean_names( $values, $fold_case = true ) {
		$out  = array();
		$seen = array();

		foreach ( is_array( $values ) ? $values : array() as $value ) {
			$value = $this->clean_name( $value );
			$key   = $fold_case ? strtolower( $value ) : $value;

			if ( '' !== $value && ! isset( $seen[ $key ] ) ) {
				$seen[ $key ] = true;
				$out[]        = $value;
			}
		}

		return $out;
	}

	/** Id of the tag or list with this name (any case), other than $except; 0 when none. */
	private function term_named( $type, $name, $except = 0 ) {
		foreach ( (array) BWFCRM_Term::get_terms( $type, array(), $name, 0, 0, ARRAY_A, 'exact' ) as $row ) {
			if ( isset( $row['ID'] ) && (int) $row['ID'] !== (int) $except && 0 === strcasecmp( (string) $row['name'], $name ) ) {
				return (int) $row['ID'];
			}
		}

		return 0;
	}

	/** The store's note types, value => label: Lite's list plus whatever bwfcrm_contact_note_types adds. */
	private function note_types() {
		$types = array();

		foreach ( (array) BWFAN_Common::get_contact_notes_type() as $type ) {
			if ( is_array( $type ) && isset( $type['value'] ) && '' !== (string) $type['value'] ) {
				$types[ (string) $type['value'] ] = isset( $type['label'] ) ? wp_strip_all_tags( (string) $type['label'] ) : (string) $type['value'];
			}
		}

		return $types;
	}

	/** A type the store lists, or a refusal that names them all. */
	private function note_type( $value ) {
		$types = $this->note_types();

		// A store's filter may add a value that is not a key ("Follow Up"): match it as given first.
		if ( is_string( $value ) && isset( $types[ $value ] ) ) {
			return $value;
		}

		$type = is_string( $value ) ? sanitize_key( $value ) : '';

		if ( isset( $types[ $type ] ) ) {
			return $type;
		}

		/* translators: %s: comma-separated note type values */
		return new WP_Error( 'fkmcp_invalid_input', sprintf( __( 'Unknown note type. Use one of: %s.', 'wp-marketing-automations-pro' ), implode( ', ', array_keys( $types ) ) ) );
	}

	/**
	 * confirm alone is a flag the caller sets on itself — an agent that has
	 * been told "the admin already approved this" satisfies it as easily as a
	 * real approval does. confirm_email is the part that cannot be asserted
	 * into existence: it has to match the Contact this call actually resolved,
	 * so a delete must name a specific address the caller looked up first.
	 * Same reason GitHub makes you type the repository name.
	 *
	 * It is not a defence against an instruction carrying a real address. It
	 * does end blind deletion, and it turns a wrong-target delete (resolved by
	 * contact_id, user meant someone else) into a refusal instead of a loss.
	 */
	public function delete_contact( $input = array() ) {
		$input   = (array) $input;
		$confirm = isset( $input['confirm_email'] ) && is_string( $input['confirm_email'] ) ? sanitize_email( $input['confirm_email'] ) : '';

		if ( true !== ( $input['confirm'] ?? null ) || '' === $confirm ) {
			return new WP_Error( 'fkmcp_confirm_required', __( 'Deletion is irreversible. Pass confirm=true and confirm_email (the Contact\'s exact email address) after the user has explicitly confirmed.', 'wp-marketing-automations-pro' ) );
		}

		$contact = $this->resolve_contact( $input );

		if ( is_wp_error( $contact ) ) {
			return $contact;
		}

		$cid   = $contact->get_id();
		$email = $contact->contact->get_email();

		// Compared against the resolved Contact, not against the input: passing
		// contact_id and a confirm_email for somebody else must refuse, which is
		// exactly the mixed-up-target case this guard exists for.
		if ( strtolower( $confirm ) !== strtolower( (string) $email ) ) {
			return new WP_Error(
				'fkmcp_confirm_mismatch',
				__( 'confirm_email does not match the Contact resolved for deletion. Nothing was deleted. Read the Contact back and confirm the address with the user.', 'wp-marketing-automations-pro' ),
				array( 'contact_id' => $cid )
			);
		}

		$response = BWFAN_MCP_Dispatch::write( 'delete-contact-row', array( 'contact_id' => $cid ), array( 'contact_id' => $cid ) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		return array( 'result' => 'deleted', 'contact_id' => $cid, 'email' => $email );
	}

	public function send_email_to_contact( $input = array() ) {
		$input   = (array) $input;
		$contact = $this->resolve_contact( $input );

		if ( is_wp_error( $contact ) ) {
			return $contact;
		}

		$subject = isset( $input['subject'] ) && is_string( $input['subject'] ) ? sanitize_text_field( $input['subject'] ) : '';
		$body    = isset( $input['body'] ) && is_string( $input['body'] ) ? $input['body'] : '';

		if ( '' === $subject || '' === trim( $body ) ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'subject and body are required.', 'wp-marketing-automations-pro' ) );
		}

		// Mail the AI asks for is marketing-adjacent: only a subscribed contact may receive it.
		// The admin's own Send Message button (same controller) still reaches any Contact but a hard-bounced one, by the admin's choice.
		$status = $contact->get_display_status();
		$status = is_wp_error( $status ) ? 0 : (int) $status;

		if ( BWFCRM_Contact::$DISPLAY_STATUS_SUBSCRIBED !== $status ) {
			$labels = array(
				BWFCRM_Contact::$DISPLAY_STATUS_UNSUBSCRIBED => __( 'unsubscribed', 'wp-marketing-automations-pro' ),
				BWFCRM_Contact::$DISPLAY_STATUS_UNVERIFIED   => __( 'unverified', 'wp-marketing-automations-pro' ),
				BWFCRM_Contact::$DISPLAY_STATUS_BOUNCED      => __( 'bounced', 'wp-marketing-automations-pro' ),
				BWFCRM_Contact::$DISPLAY_STATUS_SOFT_BOUNCED => __( 'soft bounced', 'wp-marketing-automations-pro' ),
				BWFCRM_Contact::$DISPLAY_STATUS_COMPLAINT    => __( 'marked as a complaint', 'wp-marketing-automations-pro' ),
			);
			$label  = isset( $labels[ $status ] ) ? $labels[ $status ] : __( 'not subscribed', 'wp-marketing-automations-pro' );

			/* translators: %s: the contact's status, e.g. "unsubscribed" */
			return new WP_Error( 'fkmcp_contact_not_subscribed', sprintf( __( 'Not sent: this Contact is %s. Only subscribed Contacts can be emailed from here. Do not resubscribe or verify the Contact to get around this; only the Contact can opt back in.', 'wp-marketing-automations-pro' ), $label ) );
		}

		$response = BWFAN_MCP_Dispatch::write(
			'send-contact-message',
			array(
				'contact_id' => $contact->get_id(),
				'type'       => 'email',
				'title'      => $subject,
				'message'    => wp_kses_post( $body ),
			),
			array( 'contact_id' => $contact->get_id() )
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		return array( 'result' => 'sent', 'contact_id' => $contact->get_id(), 'channel' => 'email' );
	}

	// ─── Automation creation ────────────────────────────────────────

	public function list_recipes( $input = array() ) {
		$input    = (array) $input;
		$response = BWFAN_MCP_Dispatch::call( 'list-recipes', ! empty( $input['sync'] ) ? array( 'sync' => 'true' ) : array() );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$rows   = isset( $response['result']['data'] ) && is_array( $response['result']['data'] ) ? $response['result']['data'] : array();
		$group  = isset( $input['group'] ) && is_string( $input['group'] ) ? strtolower( $input['group'] ) : '';
		$search = isset( $input['search'] ) && is_string( $input['search'] ) ? strtolower( trim( $input['search'] ) ) : '';
		$items  = array();

		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) || empty( $row['slug'] ) ) {
				continue;
			}

			$item = array(
				'slug'        => (string) $row['slug'],
				'name'        => isset( $row['name'] ) ? (string) $row['name'] : '',
				'description' => isset( $row['description'] ) ? (string) $row['description'] : null,
			);

			foreach ( array( 'group', 'subgroup', 'tag' ) as $list ) {
				$item[ $list ] = isset( $row[ $list ] ) && is_array( $row[ $list ] ) ? array_values( array_map( 'strval', array_filter( $row[ $list ], 'is_scalar' ) ) ) : array();
			}

			if ( '' !== $group && ! in_array( $group, array_map( 'strtolower', $item['group'] ), true ) ) {
				continue;
			}

			if ( '' !== $search && false === strpos( strtolower( $item['name'] . ' ' . $item['description'] ), $search ) ) {
				continue;
			}

			$items[] = $item;
		}

		return array(
			'items' => $items,
			'total' => count( $items ),
		);
	}

	/**
	 * create-automation. Always an inactive draft (status 2): there is no
	 * status input, and the integrity check forces 2 back if anything else
	 * turned up. Activation stays a human action in the builder.
	 */
	public function create_automation( $input = array() ) {
		$input  = (array) $input;
		$source = isset( $input['source'] ) && is_string( $input['source'] ) ? $input['source'] : '';
		$title  = isset( $input['title'] ) && is_scalar( $input['title'] ) ? trim( mb_substr( sanitize_text_field( (string) $input['title'] ), 0, self::CREATE_TITLE_MAX ) ) : '';

		// Agents retry on timeouts; a repeated client_ref hands back the
		// first Automation. Check-then-set, so two calls racing
		// with the same ref can still both create - retries are sequential.
		$ref_key     = '';
		$plan        = null;
		$categories  = null;
		$review_mode = 'definition' === $source && isset( $input['mode'] ) && 'review' === $input['mode'];

		// Only the definition pipeline is reviewed (spec §4.1); on any other source these would be
		// silently ignored and the call would save, so refuse them before anything else runs.
		if ( 'definition' !== $source && array() !== array_intersect_key( $input, array( 'mode' => 1, 'review_token' => 1, 'confirmed_steps' => 1 ) ) ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'mode, review_token and confirmed_steps apply only to source=definition.', 'wp-marketing-automations-pro' ) );
		}

		// The schema's enum already refuses it; a direct caller asking for anything but a review must never get a save.
		if ( 'definition' === $source && isset( $input['mode'] ) && 'review' !== $input['mode'] ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'mode must be "review", or left out to save.', 'wp-marketing-automations-pro' ) );
		}

		// A review never reads (or sets) client_ref: it must not hand back an earlier create.
		if ( ! $review_mode && isset( $input['client_ref'] ) && is_scalar( $input['client_ref'] ) && '' !== (string) $input['client_ref'] ) {
			$ref_key = self::CREATE_REF_PREFIX . get_current_user_id() . '_' . md5( (string) $input['client_ref'] );
			$first   = absint( get_transient( $ref_key ) );

			if ( $first > 0 && ! empty( BWFAN_Model_Automations::get( $first ) ) ) {
				return array_merge( $this->automation_summary( $first ), array( 'reused' => true ) );
			}
		}

		switch ( $source ) {
			case 'recipe':
				$slug = isset( $input['recipe_slug'] ) && is_string( $input['recipe_slug'] ) ? sanitize_key( $input['recipe_slug'] ) : '';

				if ( '' === $slug ) {
					return new WP_Error( 'fkmcp_invalid_input', __( 'recipe_slug is required for source=recipe (see list-recipes).', 'wp-marketing-automations-pro' ) );
				}

				// Lite's handler fetches the recipe, checks its plugin
				// dependencies and imports it; nothing is created when either fails.
				$response = self::guarded_create(
					'recipe',
					'' !== $title ? $title : $slug,
					static function () use ( $slug, $title ) {
						return BWFAN_MCP_Dispatch::call( 'create-automation-recipe', array_filter( array( 'recipe_slug' => $slug, 'title' => $title ) ) );
					}
				);
				break;

			case 'duplicate':
				$source_id = isset( $input['automation_id'] ) ? absint( $input['automation_id'] ) : 0;

				if ( ! $source_id ) {
					return new WP_Error( 'fkmcp_invalid_input', __( 'automation_id is required for source=duplicate (see list-automations).', 'wp-marketing-automations-pro' ) );
				}

				$row       = $source_id ? BWFAN_Model_Automations::get( $source_id ) : array();

				if ( empty( $row ) ) {
					return new WP_Error( 'fkmcp_not_found', __( 'No Automation found for the given automation_id.', 'wp-marketing-automations-pro' ) );
				}

				if ( 2 !== (int) $row['v'] ) {
					return new WP_Error( 'fkmcp_invalid_input', __( 'Only Next Gen automations can be copied.', 'wp-marketing-automations-pro' ) );
				}

				$response = self::guarded_create(
					'duplicate',
					$row['title'] . ' (Copy)',
					static function () use ( $source_id ) {
						return BWFAN_MCP_Dispatch::write( 'duplicate-automation', array(), array( 'automation_id' => $source_id ) );
					}
				);
				break;

			case 'blank':
				if ( '' === $title ) {
					return new WP_Error( 'fkmcp_invalid_input', __( 'title is required for source=blank.', 'wp-marketing-automations-pro' ) );
				}

				// version => 2 always: dispatch skips the route defaults, and
				// without it the handler builds a legacy (V1) Automation.
				$response = BWFAN_MCP_Dispatch::write( 'create-automation-blank', array( 'title' => $title, 'version' => 2 ) );
				break;

			case 'definition':
				if ( '' === $title ) {
					return new WP_Error( 'fkmcp_invalid_input', __( 'title is required for source=definition.', 'wp-marketing-automations-pro' ) );
				}

				self::load_definition_classes();
				FKMCP_Rule_Translator::reset(); // its static memo would otherwise outlive the request under WP-CLI or Action Scheduler.

				if ( empty( $input['definition'] ) ) {
					return new WP_Error( 'fkmcp_invalid_input', __( 'definition is required for source=definition: {trigger, steps}.', 'wp-marketing-automations-pro' ) );
				}

				$create    = ! empty( $input['create_missing'] );
				$problems  = new FKMCP_Definition_Errors();
				$cat_specs = $this->validate_categories( isset( $input['categories'] ) ? $input['categories'] : null, $create, $problems );

				// Categories are validated read-only before build(), into the same collector,
				// so their problems arrive with the definition's and nothing is written until
				// both validate; build() only then creates its own pending tags/lists (spec §0.1.9, §9).
				// A dry build writes nothing; finish() makes its one write (create_missing terms) only
				// once the review gate let the save through. The seed is the definition as sent, so a
				// commit must resend it byte for byte (reordered keys are a stale review).
				$builder = $this->definition_builder();
				try {
					$plan = $builder->build(
						isset( $input['definition'] ) ? $input['definition'] : null,
						array(
							'create_missing' => $create,
							'errors'         => $problems,
							'dry'            => true,
							'branch_seed'    => hash( 'sha256', wp_json_encode( isset( $input['definition'] ) ? $input['definition'] : null ) . '|0' ),
						)
					);
				} catch ( Throwable $e ) {
					BWFAN_MCP_Log::event( 'AUTOMATION_BUILD_FAILED class=' . get_class( $e ) );

					return new WP_Error( 'fkmcp_create_failed', __( 'The Automation could not be built from this definition. Nothing was saved.', 'wp-marketing-automations-pro' ) );
				}

				if ( is_wp_error( $plan ) ) {
					return $plan;
				}

				// A new Automation has no Create Coupon rows yet, so any id here is another row's (or none): the code would send blank.
				$coupons = FKMCP_Automation_Editor::coupon_problems( $plan['export']['step_data'], $plan['paths'], array() );
				if ( ! empty( $coupons ) ) {
					$errors = new FKMCP_Definition_Errors();
					foreach ( $coupons as $coupon ) {
						/* translators: %d: a step id */
						$errors->add( $coupon['path'], sprintf( __( 'uses wc_dynamic_coupon id="%d", but this Automation\'s Create Coupon steps don\'t exist yet. Create it without the code, get the tag from list-coupons with its automation_id, then add the tag with update-automation.', 'wp-marketing-automations-pro' ), $coupon['id'] ) );
					}

					return $errors->to_wp_error();
				}

				// The hash covers everything the save writes: the plan, and the title and categories beside it.
				$gate = $this->review_gate( $plan, array( 'title' => $title, 'categories' => $cat_specs, 'create_missing' => $create ), $input, $review_mode, 0, '' );
				if ( null !== $gate ) {
					return $gate; // a review result, or a refusal; nothing but a review token was written.
				}

				try {
					$plan = $builder->finish( $plan );
				} catch ( Throwable $e ) {
					BWFAN_MCP_Log::event( 'AUTOMATION_BUILD_FAILED class=' . get_class( $e ) );

					// Tags/lists made before the throw are named; the draft itself was never written.
					return self::with_orphaned_terms( new WP_Error( 'fkmcp_create_failed', __( 'The Automation was not saved: creating its tags or lists failed. Try again.', 'wp-marketing-automations-pro' ) ), $builder->created_terms() );
				}
				if ( is_wp_error( $plan ) ) {
					return $plan;
				}

				if ( null !== $cat_specs ) {
					$categories = $this->create_categories( $cat_specs );

					if ( is_wp_error( $categories ) ) {
						return self::with_orphaned_terms( $categories, $plan['created_terms'] );
					}
				}

				$response = $this->import_plan( $title, $plan );

				if ( is_wp_error( $response ) ) {
					return self::with_orphaned_terms( $response, self::orphaned_so_far( $plan, $categories ) );
				}
				break;

			default:
				return new WP_Error( 'fkmcp_invalid_input', __( 'source must be recipe, duplicate, blank or definition.', 'wp-marketing-automations-pro' ) );
		}

		if ( is_wp_error( $response ) ) {
			return self::creation_error( $response );
		}

		$result = isset( $response['result'] ) && is_array( $response['result'] ) ? $response['result'] : array();
		$new_id = absint( isset( $result['automation_id'] ) ? $result['automation_id'] : ( isset( $result['ID'] ) ? $result['ID'] : 0 ) );

		if ( 0 === $new_id ) {
			return new WP_Error( 'fkmcp_create_failed', __( 'The Automation could not be created. Nothing was saved.', 'wp-marketing-automations-pro' ) );
		}

		if ( 'duplicate' === $source && '' !== $title ) {
			BWFAN_Model_Automations_V2::update_automation( $new_id, array( 'title' => $title ) );
		}

		if ( 'blank' === $source ) {
			// Recipe import and duplicate fire it; blank create does not.
			do_action( 'bwfan_automation_saved', $new_id );
		}

		$fork_warnings = array();
		try {
			if ( null !== $plan ) {
				$this->apply_post_refs( $new_id, $plan );
			}
			self::save_graph( $new_id );
			if ( null !== $plan && in_array( 7, array_map( 'intval', array_column( $plan['export']['step_data'], 'type' ) ), true ) ) {
				self::save_mail_steps( $new_id ); // a definition with a split only.
			}
			$problem = $this->creation_problem( $new_id, null !== $plan && ! empty( $plan['joins'] ) ? $plan['joins'] : array(), $fork_warnings, null !== $plan );
		} catch ( Throwable $e ) {
			$problem = 'integrity check failed: ' . $e->getMessage();
		}

		if ( '' !== $problem ) {
			$rolled_back = self::rollback_draft( $new_id, $source, $problem );
			$error       = new WP_Error( 'fkmcp_create_incomplete', __( 'The draft was not kept: it did not pass the check made right after creating it. Try again, or create it in the builder.', 'wp-marketing-automations-pro' ) );
			$error       = self::with_rollback_failure( $error, $new_id, $rolled_back );

			// The rollback deletes the draft, never the tags/lists/categories build()
			// or create_categories() may already have made - those are harmless and
			// are reported here rather than silently left unmentioned (spec §0.1.9).
			return self::with_orphaned_terms( $error, null !== $plan ? self::orphaned_so_far( $plan, $categories ) : array() );
		}

		BWFAN_MCP_Log::event( sprintf( 'AUTOMATION_CREATED id=%d source=%s', $new_id, $source ) . ( null !== $plan ? ' steps=' . (int) $plan['step_count'] : '' ) );

		if ( '' !== $ref_key ) {
			set_transient( $ref_key, $new_id, 10 * MINUTE_IN_SECONDS );
		}

		$rows    = self::step_rows( $new_id ); // read once: the summary and the previews below share it.
		$summary = array_merge( $this->automation_summary( $new_id, $rows ), array( 'reused' => false ) );

		if ( null !== $plan ) {
			$emails     = FKMCP_Email_Step::previews( $plan['emails'], $rows, self::path_to_id( $new_id, $rows, $plan['emails'] ) );
			$warnings   = array_merge( $plan['warnings'], $fork_warnings, self::preview_warnings( $emails ) );
			$assigned   = array();

			// Categories are assigned only after the integrity check above passed.
			if ( null !== $categories && ! empty( $categories['ids'] ) && class_exists( 'BWFCRM_Category' ) ) {
				if ( BWFCRM_Category::assign_categories( array( $new_id ), $categories['assign'], BWFCRM_Category::$AUTOMATION ) ) {
					$assigned = $categories['ids'];
				} else {
					$warnings[] = __( 'The categories were created but could not be assigned to the Automation; assign them in the builder.', 'wp-marketing-automations-pro' );
				}
			}

			$summary += array(
				'warnings'          => $warnings,
				'sensitive_actions' => $plan['sensitive'],
				'emails'            => $emails,
				'created_terms'     => self::orphaned_so_far( $plan, $categories ),
				'categories'        => $assigned,
				'awaiting_sample'   => $plan['awaiting_sample'],
				'webhook_url'       => $this->webhook_url( $new_id, $plan ),
			);
		}

		return $summary;
	}

	/**
	 * Review before save (spec §4). Returns null to go on and save, a review result
	 * (mode review), or a WP_Error. Nothing here writes except the review token, and
	 * the token is consumed last, only after every other check passed.
	 *
	 * @param array       $plan        the dry plan.
	 * @param array       $extra       what else the save writes (title, categories…), hashed with the plan.
	 * @param array       $input       the tool input (review_token, confirmed_steps).
	 * @param bool        $review_mode mode "review".
	 * @param int         $aid         update only: the automation id; 0 on create.
	 * @param string      $revision    update only: the revision sent; '' on create.
	 * @param array|null  $changes     update only: path => new|changed|unchanged|removed, plus trigger/title/categories.
	 * @param array       $old         update only: path => old sidebar, for before_display.
	 * @param array       $removed     update only: removed step entries, each with its removed:<id> path.
	 * @param array|null  $old_meta    update only: the old trigger meta, for before_display.
	 * @param string      $title_now   update only: the current title, shown when no title was sent (site text).
	 */
	private function review_gate( array $plan, array $extra, array $input, $review_mode, $aid, $revision, $changes = null, array $old = array(), array $removed = array(), $old_meta = null, $title_now = '' ) {
		$hash  = FKMCP_Review::plan_hash( $plan, $extra );
		$token = isset( $input['review_token'] ) ? $input['review_token'] : null;

		if ( $review_mode ) {
			$sheet    = FKMCP_Review_Sheet::steps( $plan, $changes, $old );
			$required = array();
			if ( null === $changes || ! empty( $changes['trigger'] ) ) {
				$required[] = 'trigger';
			}
			if ( null === $changes ? '' !== (string) $extra['title'] : ! empty( $changes['title'] ) ) {
				$required[] = 'title';
			}
			if ( null === $changes ? null !== $extra['categories'] : ! empty( $changes['categories'] ) ) {
				$required[] = 'categories';
			}
			foreach ( $sheet as $s ) {
				$required[] = $s['path'];
			}
			foreach ( $removed as $r ) {
				$required[] = $r['path'];
			}
			$issued = FKMCP_Review::issue( $hash, $required, $aid, $revision );

			return array(
				'mode'              => 'review',
				'review'            => array(
					'title'          => array(
						'value'  => null === $extra['title'] ? self::untrust( (string) $title_now ) : (string) $extra['title'], // update without a title keeps the current one
						'change' => null === $changes ? 'new' : ( ! empty( $changes['title'] ) ? 'changed' : 'unchanged' ),
					),
					'trigger'        => FKMCP_Review_Sheet::trigger( $plan, null === $changes || empty( $changes['trigger'] ) ? null : $old_meta ) + array( 'change' => null === $changes ? 'new' : ( ! empty( $changes['trigger'] ) ? 'changed' : 'unchanged' ) ),
					'categories'     => null === $extra['categories'] ? null : $this->review_categories( $extra['categories'] ),
					'steps'          => $sheet,
					'removed'        => $removed,
					'required_steps' => $required,
				),
				'review_token'      => $issued['token'],
				'expires'           => $issued['expires'],
				'warnings'          => self::untrust( array_values( (array) $plan['warnings'] ) ),
				'sensitive_actions' => array_map(
					function ( $s ) {
						$s['reason'] = self::untrust( (string) $s['reason'] ); // a fkmcp_definition_sensitive_actions filter may supply it.

						return $s;
					},
					(array) $plan['sensitive']
				),
				'emails'            => $plan['emails'],
			);
		}

		if ( ! isset( $input['review_token'] ) ) { // presence only; the token itself is compared with hash_equals in FKMCP_Review::check().
			return FKMCP_Review::required_setting() ? FKMCP_Review::required( array( 'all of them (no review_token was sent)' ) ) : null;
		}

		$ok = FKMCP_Review::check( $token, $hash, isset( $input['confirmed_steps'] ) ? $input['confirmed_steps'] : null, $aid, $revision );
		if ( true !== $ok ) {
			return $ok;
		}

		return FKMCP_Review::consume( $token ) ? null : FKMCP_Review::stale();
	}

	/** Category specs as the sheet shows them: names, and which would be created. */
	private function review_categories( array $specs ) {
		$names   = array();
		$creates = array();
		foreach ( $specs as $spec ) {
			$names[] = self::untrust( (string) $spec['value'] );
			if ( 0 === (int) $spec['id'] ) {
				$creates[] = self::untrust( (string) $spec['value'] );
			}
		}

		return array( 'values' => $names, 'creates' => $creates, 'change' => 'new' );
	}

	/** A seam so the sandbox can fail an update after its writes and prove the restore. */
	protected function after_update_writes( $aid ) {
	}

	/**
	 * update-automation (spec §16): replace an inactive draft's whole definition in
	 * place. Every guard runs before any write: V2, inactive, no contacts, the
	 * revision, the shared edit lock, and create's own validation. Anything that
	 * fails after the snapshot puts the automation back exactly as it was.
	 */
	public function update_automation( $input = array() ) {
		$input = (array) $input;
		$aid   = isset( $input['automation_id'] ) ? absint( $input['automation_id'] ) : 0;
		$sent  = isset( $input['revision'] ) && is_string( $input['revision'] ) ? strtolower( $input['revision'] ) : '';
		$title = null;

		if ( 0 === $aid || 1 !== preg_match( '/^[a-f0-9]{32}$/', $sent ) ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'automation_id and revision are required; read the revision with get-automation.', 'wp-marketing-automations-pro' ) );
		}

		// The schema's enum already refuses it; a direct caller asking for anything but a review must never get a save.
		if ( isset( $input['mode'] ) && 'review' !== $input['mode'] ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'mode must be "review", or left out to save.', 'wp-marketing-automations-pro' ) );
		}

		if ( array_key_exists( 'title', $input ) ) {
			$title = is_scalar( $input['title'] ) ? trim( mb_substr( sanitize_text_field( (string) $input['title'] ), 0, self::CREATE_TITLE_MAX ) ) : '';
			if ( '' === $title ) {
				return new WP_Error( 'fkmcp_invalid_input', __( 'title cannot be empty; leave it out to keep the current one.', 'wp-marketing-automations-pro' ) );
			}
		}

		self::load_definition_classes();

		$refused = $this->update_refusal( FKMCP_Automation_Editor::main_row( $aid ) ); // a live one is classified inside the lock
		if ( null !== $refused ) {
			return $refused;
		}

		if ( ! BWFAN_Automation_V2::edit_lock( $aid, 0 ) ) {
			return new WP_Error( 'fkmcp_busy', __( 'The Automation is being saved right now. Try again in a moment.', 'wp-marketing-automations-pro' ) );
		}

		try {
			return $this->update_locked( $aid, $sent, $title, $input );
		} finally {
			BWFAN_Automation_V2::edit_unlock( $aid );
		}
	}

	/**
	 * Why this automation can't be edited here at all, or null. Runs before the lock, and again
	 * inside it. Active ones and ones with contacts pass: update_locked() classifies them as live.
	 */
	private function update_refusal( $row ) {
		if ( empty( $row ) ) {
			return new WP_Error( 'fkmcp_not_found', __( 'No Automation found for the given automation_id.', 'wp-marketing-automations-pro' ) );
		}
		if ( 2 !== (int) $row['v'] ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'Only Next Gen automations can be edited here.', 'wp-marketing-automations-pro' ) );
		}

		return null;
	}

	/**
	 * set-automation-status (spec §7.2). The agent asks the user "Are you sure?" first;
	 * confirmed must be literally true. Activation refuses an automation that cannot run.
	 * Written through Lite's toggle_state() so bwfan_automation_saved fires.
	 */
	public function set_automation_status( $input = array() ) {
		$input  = (array) $input;
		$aid    = isset( $input['automation_id'] ) ? absint( $input['automation_id'] ) : 0;
		$status = isset( $input['status'] ) && in_array( $input['status'], array( 'active', 'inactive' ), true ) ? $input['status'] : '';

		if ( 0 === $aid || '' === $status ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'automation_id and status (active or inactive) are required.', 'wp-marketing-automations-pro' ) );
		}

		if ( true !== ( isset( $input['confirmed'] ) ? $input['confirmed'] : null ) ) {
			return new WP_Error(
				'fkmcp_confirm_required',
				'active' === $status
					? __( 'Ask the user "Are you sure you want to activate this Automation? It will start running for real contacts." and call again with confirmed: true only after they say yes.', 'wp-marketing-automations-pro' )
					: __( 'Ask the user "Are you sure you want to deactivate this Automation?" and call again with confirmed: true only after they say yes.', 'wp-marketing-automations-pro' )
			);
		}

		self::load_definition_classes();
		$refused = $this->update_refusal( FKMCP_Automation_Editor::main_row( $aid ) );
		if ( null !== $refused ) {
			return $refused;
		}

		if ( ! BWFAN_Automation_V2::edit_lock( $aid, 0 ) ) {
			return new WP_Error( 'fkmcp_busy', __( 'The Automation is being saved in the builder right now. Try again in a moment.', 'wp-marketing-automations-pro' ) );
		}

		try {
			// Inside the lock: it may have been deleted since the first read.
			$row     = FKMCP_Automation_Editor::main_row( $aid );
			$refused = $this->update_refusal( $row );
			if ( null !== $refused ) {
				return $refused;
			}

			$from     = 1 === (int) $row['status'] ? 1 : 2;
			$to       = 'active' === $status ? 1 : 2;
			$rows     = null;
			$warnings = array();

			if ( $from !== $to ) {
				if ( 1 === $to ) {
					$rows    = self::step_rows( $aid );
					$problem = $this->activation_problem( $aid, $row, $rows );
					if ( '' !== $problem ) {
						/* translators: %s: why it cannot run */
						return new WP_Error( 'fkmcp_invalid_input', sprintf( __( 'This Automation cannot be activated yet: %s. Fix it in the builder or with update-automation, then try again.', 'wp-marketing-automations-pro' ), $problem ) );
					}
				}

				// The row is written before bwfan_automation_saved fires, so a listener that throws
				// can leave the status changed: the read-back below decides what to report.
				$thrown = null;
				try {
					BWFAN_Core()->automations->toggle_state( $aid, array( 'status' => $to ) );
				} catch ( Throwable $e ) {
					$thrown = $e;
				}
				BWFAN_Automation_V2::unset_instance( $aid );

				$after = FKMCP_Automation_Editor::main_row( $aid );
				$now   = empty( $after ) ? 0 : (int) $after['status'];
				if ( $to !== $now ) {
					BWFAN_MCP_Log::event(
						null !== $thrown
							? sprintf( 'AUTOMATION_STATUS_FAILED id=%d from=%d to=%d error=%s', $aid, $from, $to, get_class( $thrown ) )
							: sprintf( 'AUTOMATION_STATUS_FAILED id=%d from=%d to=%d reason=no_write', $aid, $from, $to )
					);

					return new WP_Error(
						'fkmcp_update_failed',
						1 === $now
							? __( 'The status could not be changed; the Automation is still active. Nothing else was touched.', 'wp-marketing-automations-pro' )
							: __( 'The status could not be changed; the Automation is still inactive. Nothing else was touched.', 'wp-marketing-automations-pro' )
					);
				}
				BWFAN_MCP_Log::event( sprintf( 'AUTOMATION_STATUS_CHANGED id=%d from=%d to=%d', $aid, $from, $to ) );
				if ( null !== $thrown ) {
					BWFAN_MCP_Log::event( sprintf( 'AUTOMATION_STATUS_FOLLOWUP_FAILED id=%d error=%s', $aid, get_class( $thrown ) ) );
					$warnings[] = __( 'Saved, but a follow-up step failed; check the automation in the builder.', 'wp-marketing-automations-pro' );
				}
			}

			$out          = $this->automation_summary( $aid, $rows );
			$out['title'] = self::untrust( $out['title'] ); // site text going back to the agent.
			$out          = array_merge(
				$out,
				array(
					'previous_status' => 1 === $from ? 'active' : 'inactive',
					'changed'         => $from !== $to,
					'contacts'        => (int) FKMCP_Automation_Editor::contact_count( $aid ),
				)
			);
			if ( ! empty( $warnings ) ) {
				$out['warnings'] = $warnings;
			}

			return $out;
		} finally {
			BWFAN_Automation_V2::edit_unlock( $aid );
		}
	}

	/** Read-only: why an automation cannot be activated, or ''. $rows: its live step rows. */
	private function activation_problem( $aid, array $row, array $rows ) {
		$live = array_filter(
			$rows,
			function ( $r ) {
				return 1 === (int) $r['status'];
			}
		);
		if ( empty( $live ) || 0 === absint( $row['start'] ) ) {
			return __( 'it has no active steps', 'wp-marketing-automations-pro' );
		}
		if ( empty( $row['event'] ) || null === FKMCP_Part_Registry::event( (string) $row['event'] ) ) {
			return __( 'its trigger is not available on this site', 'wp-marketing-automations-pro' );
		}
		$meta  = BWFAN_Model_Automationmeta::get_automation_meta( $aid, false );
		$graph = self::graph_problem( $row, (array) $meta, $rows );
		if ( '' !== $graph ) {
			return FKMCP_Definition_Errors::clean( $graph, 200 );
		}
		$incomplete = self::incomplete_steps( $rows );
		if ( ! empty( $incomplete ) ) {
			/* translators: %s: comma-separated step ids */
			return sprintf( _n( 'step %s is incomplete - finish it in the builder', 'steps %s are incomplete - finish them in the builder', count( $incomplete ), 'wp-marketing-automations-pro' ), implode( ', ', array_slice( $incomplete, 0, 10 ) ) . ( count( $incomplete ) > 10 ? ', ...' : '' ) );
		}
		if ( FKMCP_Definition_Builder::awaiting_sample( (string) $row['event'], isset( $meta['event_meta'] ) && is_array( $meta['event_meta'] ) ? $meta['event_meta'] : array() ) ) {
			return __( 'its webhook trigger has not received a test request yet (send one, then get-webhook-sample)', 'wp-marketing-automations-pro' );
		}

		return '';
	}

	private function update_locked( $aid, $sent, $title, array $input ) {
		$snap = FKMCP_Automation_Editor::snapshot( $aid );

		// Inside the lock: it may have been deleted, activated, or got a contact since the first
		// check. First, so a deleted one is not_found (not stale), and restore() always has a row.
		$refused = $this->update_refusal( $snap['row'] );
		if ( null !== $refused ) {
			return $refused;
		}
		$contacts = FKMCP_Automation_Editor::contact_count( $aid ); // one query, always: the live warning shows the real number
		$is_live  = 2 !== (int) $snap['row']['status'] || $contacts > 0;

		$live    = array_filter( $snap['rows'], function ( $row ) {
			return ! in_array( (int) $row['status'], array( 3, 4 ), true );
		} );
		$current = BWFAN_Automation_V2::get_revision( $aid, $live );

		if ( ! hash_equals( $current, $sent ) ) {
			return new WP_Error( 'fkmcp_stale', __( 'The Automation changed since you read it. Read it again with get-automation and redo your change.', 'wp-marketing-automations-pro' ), array( 'revision' => $current ) );
		}

		$create = ! empty( $input['create_missing'] );

		// Before build(): it writes create_missing's tags and lists, and a live update never uses them.
		if ( $is_live && $create ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'create_missing does nothing on a live Automation (only email content is saved); leave it out.', 'wp-marketing-automations-pro' ) );
		}

		FKMCP_Rule_Translator::reset();

		$steps_meta = (array) FKMCP_Automation_Editor::meta_value( $snap, 'steps' );
		$positions  = FKMCP_Saved_Tree::positions( $steps_meta, (array) FKMCP_Automation_Editor::meta_value( $snap, 'links' ), (array) FKMCP_Automation_Editor::meta_value( $snap, 'merger_points' ), $live );
		$branch_ids = array();
		$kept       = array();
		$kept_ids   = array();
		foreach ( $positions as $path => $position ) {
			if ( isset( $position['branch_ids'] ) ) {
				$branch_ids[ $path ] = $position['branch_ids'];
			}
			if ( 'email' === $position['type'] && isset( $live[ $position['id'] ] ) ) {
				$krow        = $live[ $position['id'] ];
				$kdata       = json_decode( (string) $krow['data'], true );
				$kept[ $path ] = array(
					'action'        => (string) $krow['action'],
					'data'          => (string) $krow['data'],
					'status'        => (int) $krow['status'],
					'transactional' => ! empty( $kdata['sidebarData']['bwfan_email_data']['data']['isTransactional'] ),
				);
				$kept_ids[ (int) $position['id'] ] = $kept[ $path ];
			}
		}

		$old_event = (string) $snap['row']['event'];
		$old_meta  = FKMCP_Automation_Editor::meta_value( $snap, 'event_meta' );
		$old_meta  = is_array( $old_meta ) ? $old_meta : array();
		$sample    = 'autonami_webhook_received' === $old_event && ! empty( $old_meta['webhook_data'] ) && is_array( $old_meta['webhook_data'] ) ? $old_meta['webhook_data'] : null;
		$flat      = array();
		$skipped   = 0;
		if ( null !== $sample ) {
			self::flatten_sample( $sample, array(), $flat, $skipped );
		}

		$problems   = new FKMCP_Definition_Errors();
		$cat_specs  = $this->validate_categories( isset( $input['categories'] ) ? $input['categories'] : null, $create, $problems );
		$categories = null;

		// A dry build writes nothing; finish() makes its one write (create_missing terms) only once the
		// review gate let the save through (as create does).
		$builder = $this->definition_builder();
		try {
			$plan = $builder->build(
				isset( $input['definition'] ) ? $input['definition'] : null,
				array(
					'dry'            => true,
					'create_missing' => $create,
					'errors'         => $problems,
					'branch_ids'     => $branch_ids,
					'webhook_sample' => $sample,
					'webhook_paths'  => null === $sample ? null : array_map( 'strval', array_keys( $flat ) ),
					'automation_id'  => $aid,
					'kept'           => $kept,
					'kept_ids'       => $kept_ids,
					'branch_seed'    => hash( 'sha256', wp_json_encode( isset( $input['definition'] ) ? $input['definition'] : null ) . '|' . $aid ),
				)
			);
		} catch ( Throwable $e ) {
			BWFAN_MCP_Log::event( 'AUTOMATION_UPDATE_BUILD_FAILED class=' . get_class( $e ) );

			return new WP_Error( 'fkmcp_update_failed', __( 'The Automation could not be built from this definition. Nothing was changed.', 'wp-marketing-automations-pro' ) );
		}

		if ( is_wp_error( $plan ) ) {
			return $plan;
		}

		$reuse   = FKMCP_Automation_Editor::match( $plan['paths'], $plan['types'], $positions, $live );
		$coupons = FKMCP_Automation_Editor::coupon_problems( $plan['export']['step_data'], $plan['paths'], $reuse );
		if ( ! empty( $coupons ) ) {
			$errors = new FKMCP_Definition_Errors();
			foreach ( $coupons as $coupon ) {
				/* translators: %d: a step id */
				$errors->add( $coupon['path'], sprintf( __( 'uses wc_dynamic_coupon id="%d", which is not a Create Coupon step this update keeps in place.', 'wp-marketing-automations-pro' ), $coupon['id'] ) );
			}

			return self::with_orphaned_terms( $errors->to_wp_error(), $plan['created_terms'] );
		}

		// Review before save (spec §4). Every refusal above (stale revision, create_missing on live, the
		// definition, coupons) and the live ones below run before review_gate(), so none of them can burn
		// a token, and nothing is written until the gate returns null. The hash covers what the update
		// writes beyond the plan: which rows are kept (removed ones follow from reuse and the snapshot the
		// revision binds), the title, categories, and whether the live writer or the full one runs.
		$review_mode = isset( $input['mode'] ) && 'review' === $input['mode'];
		$extra       = array( 'aid' => $aid, 'reuse' => $reuse, 'title' => $title, 'categories' => $cat_specs, 'create_missing' => $create, 'confirm_live' => null, 'live' => $is_live );

		if ( $is_live ) {
			$change = $this->live_plan( $plan, $reuse, $positions, $live, $old_meta, $old_event, null !== $title || null !== $cat_specs, $input, $contacts );
			if ( is_wp_error( $change ) ) {
				return $change;
			}
			// Before the gate: a missing confirm_live never consumes the token.
			if ( ! $review_mode && ! empty( $change['writes'] ) && true !== ( isset( $input['confirm_live'] ) ? $input['confirm_live'] : null ) ) { // exactly boolean true: "true" and 1 are not a confirmation
				return new WP_Error(
					'fkmcp_confirm_live',
					__( 'This Automation is live. Only its email content would change; send confirm_live: true to save it.', 'wp-marketing-automations-pro' ),
					array(
						'paths'         => $change['paths'],
						'ignored_paths' => $change['ignored_paths'],
					)
				);
			}

			$shown   = $plan; // warnings are not hashed: the sheet gets the live ones too
			$changes = null;
			$old     = array();
			if ( $review_mode ) { // only the changed emails are listed; ignored steps become a warning line
				$changes = array();
				foreach ( $plan['paths'] as $i => $p ) {
					$changes[ $p ] = in_array( $p, $change['paths'], true ) ? 'changed' : 'unchanged';
					if ( 'changed' === $changes[ $p ] && isset( $reuse[ $i + 1 ], $live[ $reuse[ $i + 1 ] ] ) ) {
						$data      = json_decode( (string) $live[ $reuse[ $i + 1 ] ]['data'], true );
						$old[ $p ] = isset( $data['sidebarData'] ) && is_array( $data['sidebarData'] ) ? $data['sidebarData'] : array();
					}
				}
				$shown['warnings'] = array_merge( $plan['warnings'], $change['warnings'] );
				if ( ! empty( $change['ignored_paths'] ) ) {
					/* translators: %s: step paths, comma separated */
					$shown['warnings'][] = sprintf( __( 'On a live Automation only email content is saved; these steps would be left as they are: %s.', 'wp-marketing-automations-pro' ), implode( ', ', $change['ignored_paths'] ) );
				}
			}
			$gate = $this->review_gate( $shown, $extra, $input, $review_mode, $aid, $current, $changes, $old, array(), $old_meta, (string) $snap['row']['title'] );
			if ( null !== $gate ) {
				return is_array( $gate ) ? $gate + array( 'revision' => $current ) : $gate;
			}

			// No finish(): create_missing was refused on live before build(), so there is no term to make.
			return $this->write_live_emails( $aid, $snap, $change, $plan, (int) $contacts, $positions );
		}

		$warnings = array();
		if ( $old_event !== $plan['event'] ) {
			foreach ( $plan['emails'] as $email ) {
				if ( ! empty( $email['kept'] ) ) {
					/* translators: %s: the step's path, e.g. steps[0] */
					$warnings[] = sprintf( __( '%s: this kept email was not re-checked for the new trigger\'s merge tags.', 'wp-marketing-automations-pro' ), $email['path'] );
				}
			}
		}

		$changes = null;
		$shown   = $plan; // warnings are not hashed: the sheet gets the kept-email ones too
		$rc      = array( 'old' => array(), 'removed' => array() );
		if ( $review_mode ) { // only the sheet needs the classification; a commit is checked against the token's own list
			try {
				$rc = FKMCP_Automation_Editor::review_changes( $plan, $reuse, $snap['rows'], $positions, $steps_meta );
			} catch ( Throwable $e ) {
				BWFAN_MCP_Log::event( 'AUTOMATION_UPDATE_REVIEW_FAILED class=' . get_class( $e ) );

				return new WP_Error( 'fkmcp_update_failed', __( 'The update could not be reviewed. Nothing was changed.', 'wp-marketing-automations-pro' ) );
			}
			$changes = $rc['changes'] + array(
				'trigger'    => $plan['event'] !== $old_event || self::meta_for_compare( $plan['event_meta'] ) !== self::meta_for_compare( $old_meta ),
				'title'      => null !== $title && $title !== (string) $snap['row']['title'],
				'categories' => null !== $cat_specs, // sending categories always counts
			);
			$shown['warnings'] = array_merge( $plan['warnings'], $warnings );
		}
		$gate = $this->review_gate( $shown, $extra, $input, $review_mode, $aid, $current, $changes, $rc['old'], $rc['removed'], $old_meta, (string) $snap['row']['title'] );
		if ( null !== $gate ) {
			return is_array( $gate ) ? $gate + array( 'revision' => $current ) : $gate; // a review, or a refusal; nothing but a review token was written.
		}

		try {
			$plan = $builder->finish( $plan );
		} catch ( Throwable $e ) {
			BWFAN_MCP_Log::event( 'AUTOMATION_UPDATE_BUILD_FAILED class=' . get_class( $e ) );

			// Tags/lists made before the throw are named; the Automation itself was not touched.
			return self::with_orphaned_terms( new WP_Error( 'fkmcp_update_failed', __( 'The Automation was not changed: creating its tags or lists failed. Try again.', 'wp-marketing-automations-pro' ) ), $builder->created_terms() );
		}
		if ( is_wp_error( $plan ) ) {
			return $plan;
		}

		if ( null !== $cat_specs ) {
			$categories = $this->create_categories( $cat_specs );
			if ( is_wp_error( $categories ) ) {
				return self::with_orphaned_terms( $categories, $plan['created_terms'] );
			}
		}

		$removed = array_values( array_diff( FKMCP_Automation_Editor::graph_ids( $steps_meta ), array_values( $reuse ) ) );
		$rows    = array();

		try {
			$real = $this->write_update( $aid, $plan, $reuse, $snap, $old_meta, $old_event, $title );
			$this->after_update_writes( $aid );
			$rows    = self::step_rows( $aid ); // read once: the check, the summary and the revision share it.
			$problem = $this->update_problem( $aid, $plan, $real, $removed, $warnings, $rows );
		} catch ( Throwable $e ) {
			$problem = 'update failed: ' . $e->getMessage();
		}

		if ( '' !== $problem ) {
			BWFAN_MCP_Log::event( sprintf( 'AUTOMATION_UPDATE_ROLLED_BACK id=%d reason=%s', $aid, FKMCP_Definition_Errors::clean( $problem, 200 ) ) ); // one line, capped: it can carry an exception message.
			$error = new WP_Error( 'fkmcp_update_incomplete', __( 'The update was not kept: it did not pass the check made right after saving. The Automation is back as it was.', 'wp-marketing-automations-pro' ) );
			try {
				FKMCP_Automation_Editor::restore( $aid, $snap );
			} catch ( Throwable $e ) {
				BWFAN_MCP_Log::event( sprintf( 'UPDATE_RESTORE_FAILED id=%d', $aid ) );
				$error = new WP_Error( 'fkmcp_update_incomplete', __( 'The update failed, and putting the Automation back as it was also failed. Check it in the builder before activating it.', 'wp-marketing-automations-pro' ) );
			}

			return self::with_orphaned_terms( $error, self::orphaned_so_far( $plan, $categories ) );
		}

		$emails   = FKMCP_Email_Step::previews( $plan['emails'], $rows, self::path_to_id( $aid, $rows, $plan['emails'] ) );
		$warnings = array_merge( $plan['warnings'], $warnings, self::preview_warnings( $emails ) );
		$assigned = null;
		if ( null !== $categories && class_exists( 'BWFCRM_Category' ) ) {
			if ( BWFCRM_Category::assign_categories( array( $aid ), $categories['assign'], BWFCRM_Category::$AUTOMATION ) || empty( $categories['ids'] ) ) {
				$assigned = $categories['ids'];
			} else {
				$warnings[] = __( 'The categories could not be assigned to the Automation; assign them in the builder.', 'wp-marketing-automations-pro' );
			}
		}

		do_action( 'bwfan_automation_saved', $aid );
		BWFAN_MCP_Log::event( sprintf( 'AUTOMATION_UPDATED id=%d steps=%d', $aid, (int) $plan['step_count'] ) );

		$summary = array_merge(
			$this->automation_summary( $aid, $rows ),
			array(
				'revision'          => BWFAN_Automation_V2::get_revision( $aid, $rows ),
				'removed_steps'     => $removed,
				'warnings'          => $warnings,
				'sensitive_actions' => $plan['sensitive'],
				'emails'            => $emails,
				'created_terms'     => self::orphaned_so_far( $plan, $categories ),
				'awaiting_sample'   => $plan['awaiting_sample'],
				'webhook_url'       => $this->webhook_url( $aid, $plan ),
			)
		);
		if ( null !== $assigned ) {
			$summary['categories'] = $assigned;
		}

		return $summary;
	}

	/**
	 * A live Automation (active, or contacts in it): only email content can change (spec §3.5).
	 * Returns live_email_changes()' {writes, paths, ignored_paths, warnings}, or the refusal. Writes
	 * nothing: update_locked() checks confirm_live and the review gate, then write_live_emails() saves.
	 * create_missing was already refused before build(), so no term exists here to report.
	 */
	private function live_plan( array $plan, array $reuse, array $positions, array $live, array $old_meta, $old_event, $sent_title_or_categories, array $input, $contacts = 0 ) {
		$change  = null;
		$trigger = isset( $input['definition']['trigger'] ) && is_array( $input['definition']['trigger'] ) ? $input['definition']['trigger'] : array();
		$reason  = $sent_title_or_categories ? 'a title or categories were sent; leave them out' : FKMCP_Automation_Editor::live_trigger_change( $trigger, $plan, $old_meta, $old_event );
		if ( '' === $reason ) {
			try {
				$change = FKMCP_Automation_Editor::live_email_changes( $positions, $plan, $reuse, $live, FKMCP_Definition_Builder::remap( $plan, $reuse )['rows'] );
			} catch ( Throwable $e ) {
				$change = 'a step is added, removed, moved or changed type'; // remap() throws for a step with no kept row
			}
			$reason = is_string( $change ) ? $change : '';
		}
		if ( '' !== $reason ) {
			// Contacts keep it locked even when switched off (they carry on in it), so only a copy can take the change.
			if ( $contacts > 0 ) {
				/* translators: 1: why the change is more than email content, 2: the number of contacts in the Automation */
				return new WP_Error( 'fkmcp_invalid_input', sprintf( _n( 'This Automation has %2$d contact in it, so only email content can change (%1$s), even when it is switched off. To change it, copy it with create-automation source=duplicate, change the copy with update-automation, then, once the user agrees, switch the copy on and this one off with set-automation-status. Contacts already in this one finish here.', 'This Automation has %2$d contacts in it, so only email content can change (%1$s), even when it is switched off. To change it, copy it with create-automation source=duplicate, change the copy with update-automation, then, once the user agrees, switch the copy on and this one off with set-automation-status. Contacts already in this one finish here.', (int) $contacts, 'wp-marketing-automations-pro' ), $reason, (int) $contacts ) );
			}

			/* translators: %s: why the change is more than email content */
			return new WP_Error( 'fkmcp_invalid_input', sprintf( __( 'This Automation is switched on, so only email content can change (%s). Once the user agrees, switch it off with set-automation-status and update it, or change a copy (create-automation source=duplicate) instead.', 'wp-marketing-automations-pro' ), $reason ) );
		}

		return $change;
	}

	/**
	 * The live email-only write (spec §3.5): each write sets the data column of one email
	 * row, scoped by ID and aid, under the lock. No main row, graph, meta or status write,
	 * and no creation_problem() (it forces status 2). A failed write or a read-back that
	 * differs puts back the data of the rows written, and only those: the engine may have
	 * written other rows (a split's runtime) meanwhile. No writes: no save event, no log.
	 */
	private function write_live_emails( $aid, array $snap, array $change, array $plan, $contacts, array $positions ) {
		$writes  = $change['writes'];
		$problem = '';
		$rows    = array();
		try {
			foreach ( $writes as $w ) {
				if ( false === BWFAN_Model_Automation_Step::update( array( 'data' => $w['set']['data'] ), array( 'ID' => $w['id'], 'aid' => $aid ) ) ) {
					throw new RuntimeException( 'an email row could not be updated' );
				}
			}
			$this->after_update_writes( $aid );
			$rows = self::step_rows( $aid ); // one read: the check, the summary and the revision share it
			foreach ( $writes as $w ) {
				if ( ! isset( $rows[ $w['id'] ] ) || (string) $rows[ $w['id'] ]['data'] !== $w['set']['data'] ) {
					$problem = sprintf( 'email step %d did not read back as written', $w['id'] );
					break;
				}
			}
		} catch ( Throwable $e ) {
			$problem = 'live update failed: ' . $e->getMessage();
		}

		if ( '' !== $problem ) {
			BWFAN_MCP_Log::event( sprintf( 'AUTOMATION_UPDATE_ROLLED_BACK id=%d reason=%s', $aid, FKMCP_Definition_Errors::clean( $problem, 200 ) ) );
			$error = new WP_Error( 'fkmcp_update_incomplete', __( 'The update was not kept: it did not pass the check made right after saving. The Automation is back as it was.', 'wp-marketing-automations-pro' ) );
			$restored = true;
			foreach ( $writes as $w ) { // every written row is tried, even after one fails
				try {
					$restored = false !== BWFAN_Model_Automation_Step::update( array( 'data' => $snap['rows'][ $w['id'] ]['data'] ), array( 'ID' => $w['id'], 'aid' => $aid ) ) && $restored;
				} catch ( Throwable $e ) {
					$restored = false;
				}
			}
			if ( ! $restored ) {
				BWFAN_MCP_Log::event( sprintf( 'UPDATE_RESTORE_FAILED id=%d', $aid ) );
				$error = new WP_Error( 'fkmcp_update_incomplete', __( 'The update failed, and putting the Automation back as it was also failed. Check it in the builder before activating it.', 'wp-marketing-automations-pro' ) );
			}
			BWFAN_Automation_V2::unset_instance( $aid );

			return self::with_orphaned_terms( $error, $plan['created_terms'] );
		}

		if ( ! empty( $writes ) ) {
			BWFAN_Automation_V2::unset_instance( $aid );
			do_action( 'bwfan_automation_saved', $aid );
			BWFAN_MCP_Log::event( sprintf( 'AUTOMATION_UPDATED_LIVE_EMAILS id=%d emails=%d', $aid, count( $writes ) ) );
		}

		// Previews only for an email this call actually wrote: a path in $positions whose row id is
		// among $writes. A no-op ($writes empty) leaves $path_to_id empty, so previews() makes none.
		$written_ids = array_column( $writes, 'id' );
		$path_to_id  = array();
		foreach ( $positions as $path => $position ) {
			if ( in_array( $position['id'], $written_ids, true ) ) {
				$path_to_id[ $path ] = $position['id'];
			}
		}
		$emails = FKMCP_Email_Step::previews( $plan['emails'], $rows, $path_to_id );

		$warnings = array_merge( $plan['warnings'], $change['warnings'], self::preview_warnings( $emails ) );
		if ( ! empty( $change['ignored_paths'] ) ) {
			/* translators: %s: step paths, comma separated */
			$warnings[] = sprintf( __( 'On a live Automation only email content is saved; these steps were left as they are: %s.', 'wp-marketing-automations-pro' ), implode( ', ', $change['ignored_paths'] ) );
		}
		$warnings[] = empty( $writes )
			/* translators: %d: contacts in the Automation */
			? sprintf( __( 'This Automation is live with %d contact(s); no email changed, so nothing was saved.', 'wp-marketing-automations-pro' ), $contacts )
			/* translators: %d: contacts in the Automation */
			: sprintf( __( 'This Automation is live with %d contact(s); new sends use the new email. Contacts already past this step are not affected.', 'wp-marketing-automations-pro' ), $contacts );

		return array_merge(
			$this->automation_summary( $aid, $rows ),
			array(
				'revision'          => BWFAN_Automation_V2::get_revision( $aid, $rows ),
				'removed_steps'     => array(),
				'warnings'          => $warnings,
				'sensitive_actions' => array(),
				'emails'            => $emails,
				'created_terms'     => $plan['created_terms'],
				'awaiting_sample'   => $plan['awaiting_sample'],
				'webhook_url'       => $this->webhook_url( $aid, $plan ),
			)
		);
	}

	/**
	 * Every write of an update, in the only safe order: new rows (their ids are
	 * needed by the remap), the remap in memory, the rows that changed, the main
	 * row, then one graph save. Returns remap()'s output. Throws on a failed write.
	 */
	private function write_update( $aid, array $plan, array $reuse, array $snap, array $old_meta, $old_event, $title ) {
		$map      = $reuse;
		$inserted = array();
		$now      = current_time( 'mysql', 1 );

		foreach ( $plan['export']['step_data'] as $temp => $row ) {
			if ( isset( $map[ $temp ] ) ) {
				continue;
			}
			$id = BWFAN_Model_Automation_Step::create_new_automation_step(
				array(
					'aid'        => $aid,
					'type'       => (int) $row['type'],
					'action'     => $row['action'],
					'data'       => $row['data'],
					'status'     => (int) $row['status'],
					'created_at' => $now,
					'updated_at' => $now,
				)
			);
			if ( empty( $id ) ) {
				throw new RuntimeException( 'a step row could not be inserted' );
			}
			$map[ $temp ]      = (int) $id;
			$inserted[ $temp ] = (int) $id;
		}

		$real = FKMCP_Definition_Builder::remap( $plan, $map );

		foreach ( $inserted as $temp => $id ) {
			if ( $real['rows'][ $id ]['data'] !== $plan['export']['step_data'][ $temp ]['data'] && false === BWFAN_Model_Automation_Step::update( array( 'data' => $real['rows'][ $id ]['data'] ), array( 'ID' => $id, 'aid' => $aid ) ) ) {
				throw new RuntimeException( 'a step reference could not be written' );
			}
		}

		foreach ( FKMCP_Automation_Editor::row_writes( $snap['rows'], $real['rows'], array_values( $reuse ) ) as $write ) {
			if ( false === BWFAN_Model_Automation_Step::update( $write['set'], array( 'ID' => $write['id'], 'aid' => $aid ) ) ) {
				throw new RuntimeException( 'a step row could not be updated' );
			}
		}

		$main = array(
			'event'  => $plan['event'],
			'source' => $plan['source'],
		);
		if ( null !== $title ) {
			$main['title'] = $title;
		}
		if ( false === BWFAN_Model_Automations_V2::update_automation( $aid, $main ) ) {
			throw new RuntimeException( 'the automation row could not be updated' );
		}

		BWFAN_Automation_V2::unset_instance( $aid );
		$v2 = BWFAN_Automation_V2::get_instance( $aid );
		$v2->fetch_automation_metadata( false );

		$meta = array( 'event_meta' => FKMCP_Automation_Editor::event_meta( $plan, $old_meta, $old_event ) );
		if ( null === FKMCP_Automation_Editor::meta_value( $snap, 'step_iteration_array' ) ) {
			$meta['step_iteration_array'] = ''; // duplicate() writes no row, and the repair only updates rows that exist (see save_graph()).
		}
		$v2->update_automation_meta_data( $meta, $real['steps'], $plan['export']['meta']['links'], $plan['export']['meta']['count'] );

		// V2 compares start against its cached copy, and writes 'end' for an empty graph: set it outright.
		BWFAN_Model_Automations_V2::update_automation( $aid, array( 'start' => $real['start'] ) );

		// V2 writes merger_points and split_steps only when they are non-empty: clear what a removed fork or split left behind.
		$has_split = in_array( 7, array_map( 'intval', array_column( $plan['export']['step_data'], 'type' ) ), true );
		$reset     = array();
		if ( empty( $plan['joins'] ) && ! empty( FKMCP_Automation_Editor::meta_value( $snap, 'merger_points' ) ) ) {
			$reset['merger_points'] = maybe_serialize( array() );
		}
		if ( ! $has_split && ! empty( FKMCP_Automation_Editor::meta_value( $snap, 'split_steps' ) ) ) {
			$reset['split_steps'] = maybe_serialize( array() );
		}
		if ( ! empty( $reset ) ) {
			BWFAN_Model_Automationmeta::update_automation_meta_values( $aid, $reset );
		}
		BWFAN_Automation_V2::unset_instance( $aid );

		if ( $has_split ) {
			self::save_mail_steps( $aid );
		}

		return $real;
	}

	/** create's integrity check, plus: every kept or new step is live, and every removed one is not. */
	private function update_problem( $aid, array $plan, array $real, array $removed, array &$warnings, array $rows ) {
		$problem = $this->creation_problem( $aid, ! empty( $plan['joins'] ) ? $plan['joins'] : array(), $warnings, true, $rows );
		if ( '' !== $problem ) {
			return $problem;
		}
		foreach ( array_keys( $real['rows'] ) as $id ) {
			if ( ! isset( $rows[ $id ] ) ) {
				return sprintf( 'step %d is not live after the update', $id );
			}
		}
		foreach ( $removed as $id ) {
			if ( isset( $rows[ $id ] ) ) {
				return sprintf( 'removed step %d is still live', $id );
			}
		}

		return '';
	}

	/** Trigger meta without the keys update carries over or the receiver rewrites, keys sorted: for "did the trigger change". */
	private static function meta_for_compare( $meta ) {
		$meta = is_array( $meta ) ? $meta : array();
		unset( $meta['bwfan_unique_key'], $meta['webhook_data'], $meta['received_at'], $meta['referer'] );
		$sorted = function ( $value ) use ( &$sorted ) {
			if ( is_array( $value ) ) {
				ksort( $value );
				$value = array_map( $sorted, $value );
			}

			return $value;
		};

		return $sorted( $meta );
	}

	/** Tags/lists from the plan plus any categories, merged for reporting - never for rollback. */
	private static function orphaned_so_far( array $plan, $categories ) {
		return array_merge( $plan['created_terms'], is_array( $categories ) ? $categories['created_terms'] : array() );
	}

	/**
	 * Names created terms in a WP_Error's message (FKMCP_Search_Resolver::with_created_terms(),
	 * the one builder of that message): a write already happened, so the result must say so
	 * rather than claim nothing was created (spec §0.1.9). The base message is scoped to the
	 * draft (never "nothing was created" wording), so the two never contradict each other.
	 * Returns $error untouched when nothing was created - the only case a recipe/duplicate/blank
	 * create reaches, where the definition classes aren't loaded.
	 */
	private static function with_orphaned_terms( WP_Error $error, array $created_terms ) {
		return empty( $created_terms ) ? $error : FKMCP_Search_Resolver::with_created_terms( $error, $created_terms );
	}

	/**
	 * A controller's own refusal (a missing recipe dependency, "Recipe not
	 * found") is an answer the agent can relay, so a 4xx keeps its message.
	 * Anything else stays foreign for the log wrapper to hide behind an id.
	 */
	private static function creation_error( WP_Error $error ) {
		$code = $error->get_error_code();

		// fkmcp_refused is Lite's dispatch relaying the same controller refusal (Lite ≥ 3.9).
		if ( 0 === strpos( (string) $code, 'fkmcp_' ) && 'fkmcp_refused' !== $code ) {
			return $error;
		}

		$data   = $error->get_error_data( $code );
		$status = is_array( $data ) && isset( $data['status'] ) ? (int) $data['status'] : 0;
		$text   = wp_strip_all_tags( (string) $error->get_error_message( $code ) );

		if ( $status >= 400 && $status < 500 && '' !== $text ) {
			return new WP_Error( 'fkmcp_create_failed', $text, array( 'status' => $status ) ); // the controller's refusal, not a server fault
		}

		return $error;
	}

	public function describe_automation_part( $input = array() ) {
		$input = (array) $input;
		$kind  = isset( $input['kind'] ) ? (string) $input['kind'] : '';
		// sanitize_key() alone has no length limit; a slug/event this long is
		// never a real one, so cap it before it's echoed back in an error or
		// used to build a transient/option key anywhere downstream.
		$slug  = isset( $input['slug'] ) ? substr( sanitize_key( $input['slug'] ), 0, 100 ) : '';
		$event = isset( $input['event'] ) ? substr( sanitize_key( $input['event'] ), 0, 100 ) : '';

		if ( ! in_array( $kind, array( 'event', 'action', 'rules', 'goal' ), true ) ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'kind must be "event", "action", "rules" or "goal".', 'wp-marketing-automations-pro' ) );
		}

		if ( 'action' === $kind && '' === $event ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'kind=action needs event: the trigger slug the action will run under.', 'wp-marketing-automations-pro' ) );
		}

		self::load_definition_classes_for_describe();

		$scrub   = array( __CLASS__, 'untrust' );
		$special = new FKMCP_Special_Fields( new FKMCP_Search_Resolver( $this ), $scrub );
		$needs   = array();
		$reason  = null;

		if ( 'rules' === $kind ) {
			$part = FKMCP_Part_Registry::event( $slug );
			if ( null === $part ) {
				/* translators: %s: closest trigger slugs */
				return new WP_Error( 'fkmcp_not_found', sprintf( __( 'No trigger with that slug. Closest: %s.', 'wp-marketing-automations-pro' ), implode( ', ', FKMCP_Field_Translator::closest( $slug, FKMCP_Part_Registry::event_slugs() ) ) ) );
			}

			$rows = ( new FKMCP_Rule_Translator( $slug, new FKMCP_Search_Resolver( $this ) ) )->describe( $scrub );

			return array(
				'kind'             => 'rules',
				'slug'             => $slug,
				'name'             => $part['name'],
				'buildable'        => ! empty( $rows ),
				'reason'           => empty( $rows ) ? __( 'This trigger offers no condition rules an assistant can set.', 'wp-marketing-automations-pro' ) : null,
				'needs'            => array(),
				'sensitive'        => false,
				'settings_schema'  => new stdClass(),
				'defaults'         => new stdClass(),
				'merge_tags'       => array(),
				'delay_merge_tags' => array(),
				'rules'            => $rows,
			);
		}

		if ( 'goal' === $kind ) {
			$part = FKMCP_Part_Registry::goal( $slug );
			if ( null === $part ) {
				/* translators: %s: the goal slugs on this site */
				return new WP_Error( 'fkmcp_not_found', sprintf( __( 'No goal with that slug. Goals: %s.', 'wp-marketing-automations-pro' ), implode( ', ', FKMCP_Field_Translator::closest( $slug, array_keys( FKMCP_Part_Registry::goals() ), 25 ) ) ) );
			}

			// bwfan_goal_run is set through the step's if_not_met, never in settings.
			$fields = array_values( array_filter( $part['fields'], function ( $f ) {
				return ! isset( $f['id'] ) || 'bwfan_goal_run' !== $f['id'];
			} ) );
			$defaults = $part['defaults'];
			unset( $defaults['bwfan_goal_run'] );
			$reason = FKMCP_Field_Translator::unbuildable_reason( $fields, $special );

			return array(
				'kind'             => 'goal',
				'slug'             => $slug,
				'name'             => (string) call_user_func( $scrub, $part['name'] ),
				'buildable'        => null === $reason,
				'reason'           => $reason,
				'needs'            => array(),
				'sensitive'        => false,
				'settings_schema'  => ( new FKMCP_Field_Translator( $fields, $defaults, array( 'special' => $special, 'scrub' => $scrub ) ) )->schema(),
				'defaults'         => empty( $defaults ) ? new stdClass() : $defaults,
				'merge_tags'       => array(),
				'delay_merge_tags' => array(),
			);
		}

		if ( 'event' === $kind ) {
			$part = FKMCP_Part_Registry::event( $slug );
			if ( null === $part ) {
				/* translators: %s: closest trigger slugs */
				return new WP_Error( 'fkmcp_not_found', sprintf( __( 'No trigger with that slug. Closest: %s.', 'wp-marketing-automations-pro' ), implode( ', ', FKMCP_Field_Translator::closest( $slug, FKMCP_Part_Registry::event_slugs() ) ) ) );
			}
			$ctx = array(
				'guarded' => FKMCP_Part_Registry::guarded_fields( $slug ),
				'aliases' => array( 'run' => 'bwfan_automation_run', 'enter_on_active_contact' => 'enter_automation_on_active_contact' ),
			);
		} else {
			// The trigger itself must exist before an action lookup under it
			// means anything - otherwise an unknown/missing event silently
			// empties FKMCP_Part_Registry::actions() and the not-found path
			// below would offer "Closest: ." with nothing in it.
			if ( null === FKMCP_Part_Registry::event( $event ) ) {
				/* translators: %s: closest trigger slugs */
				return new WP_Error( 'fkmcp_not_found', sprintf( __( 'No trigger with that event slug. Closest: %s.', 'wp-marketing-automations-pro' ), implode( ', ', FKMCP_Field_Translator::closest( $event, FKMCP_Part_Registry::event_slugs() ) ) ) );
			}
			$part = FKMCP_Part_Registry::action( $slug, $event );
			if ( null === $part ) {
				$locked = FKMCP_Part_Registry::locked_reason( $slug, $event );
				if ( null === $locked ) {
					/* translators: %s: closest action slugs */
					return new WP_Error( 'fkmcp_not_found', sprintf( __( 'No action with that slug for this trigger. Closest: %s.', 'wp-marketing-automations-pro' ), implode( ', ', FKMCP_Field_Translator::closest( $slug, array_keys( FKMCP_Part_Registry::actions( $event ) ) ) ) ) );
				}

				return array( 'kind' => 'action', 'slug' => $slug, 'name' => $slug, 'buildable' => false, 'reason' => $locked, 'needs' => array(), 'sensitive' => null !== FKMCP_Part_Registry::sensitive_reason( $slug ), 'settings_schema' => new stdClass(), 'defaults' => new stdClass(), 'merge_tags' => array(), 'delay_merge_tags' => array() );
			}
			$need = FKMCP_Part_Registry::connector_need( $part['integration'] );
			if ( null !== $need ) {
				$needs[] = $need;
				/* translators: %s: e.g. connect Keap */
				$reason  = sprintf( __( 'The site needs to %s first.', 'wp-marketing-automations-pro' ), $need );
			}
			if ( FKMCP_Part_Registry::is_denied( $slug ) ) {
				$reason = __( 'This site does not allow assistants to add this action.', 'wp-marketing-automations-pro' );
			}
			$ctx = array();
		}

		$unbuildable = FKMCP_Field_Translator::unbuildable_reason( $part['fields'], $special );

		// wp_sendemail is the builder's own internal email-step action, not a
		// usable catalogue action: its field type (emaileditor) was never
		// going to be supported, so point the agent at the real path instead
		// of the generic "field type … can't be filled yet" message.
		if ( 'action' === $kind && 'wp_sendemail' === $slug && null !== $unbuildable ) {
			// design leads: a block-editor design is the default email.
			$unbuildable = FKMCP_Step_Builder::email_action_reason();
		}

		$reason     = null !== $reason ? $reason : $unbuildable;
		$translator = new FKMCP_Field_Translator( $part['fields'], $part['defaults'], $ctx + array( 'special' => $special, 'scrub' => $scrub ) );
		$wrap       = function ( $names ) {
			return array_slice( array_map( function ( $n ) {
				return '{{' . $n . '}}';
			}, array_keys( $names ) ), 0, 300 );
		};

		return array(
			'kind'             => $kind,
			'slug'             => $slug,
			'name'             => $part['name'],
			'buildable'        => null === $reason,
			'reason'           => $reason,
			'needs'            => $needs,
			'sensitive'        => 'action' === $kind && null !== FKMCP_Part_Registry::sensitive_reason( $slug ),
			'settings_schema'  => $translator->schema(),
			'defaults'         => empty( $part['defaults'] ) ? new stdClass() : $part['defaults'],
			'merge_tags'       => 'event' === $kind ? $wrap( FKMCP_Part_Registry::merge_tags( $slug ) ) : array(),
			'delay_merge_tags' => 'event' === $kind ? $wrap( FKMCP_Part_Registry::merge_tags( $slug, true ) ) : array(),
		);
	}

	/**
	 * Runs one create through Lite (import, duplicate, recipe) and removes the
	 * draft it leaves when it throws.
	 *
	 * Lite inserts the automation row - and records its id via
	 * set_automation_id() - before it builds step rows, writes meta or fires
	 * bwfan_automation_saved; a Throwable from any of those leaves a
	 * half-built draft sitting in the table with nothing rolled back. Note
	 * the id before the call and compare it after a catch, so that draft is
	 * found and removed the same way a later integrity failure is.
	 *
	 * get_automation_id() is required (Lite ≥ 3.8.6, which every tool that
	 * reaches here already requires - see MIN_LITE_FOR_CREATION). If it is
	 * somehow missing there is no safe way to identify which row is ours:
	 * guessing (e.g. the highest id in the table) risks deleting another
	 * admin's automation that is being created at the same moment, so this
	 * skips the rollback and says a draft may have been left behind instead.
	 *
	 * @return mixed|WP_Error What $create returned, or the refusal after a throw.
	 */
	private static function guarded_create( $source, $title, callable $create ) {
		$automations = BWFAN_Core()->automations;
		$has_id      = method_exists( $automations, 'get_automation_id' );
		$before      = $has_id ? absint( $automations->get_automation_id() ) : 0;

		try {
			return $create();
		} catch ( Throwable $e ) {
			BWFAN_MCP_Log::event( sprintf( 'AUTOMATION_CREATE_THREW source=%s class=%s', $source, get_class( $e ) ) );

			if ( ! $has_id ) {
				return new WP_Error( 'fkmcp_create_incomplete', sprintf( /* translators: %s: the Automation's title */ __( 'An unfinished draft may remain; check Automations for "%s".', 'wp-marketing-automations-pro' ), $title ) );
			}

			$leaked = absint( $automations->get_automation_id() );
			$error  = new WP_Error( 'fkmcp_create_incomplete', __( 'The automation was not saved.', 'wp-marketing-automations-pro' ) );

			if ( $leaked > 0 && $leaked !== $before ) {
				$error = self::with_rollback_failure( $error, $leaked, self::rollback_draft( $leaked, $source, $source . ' create threw: ' . $e->getMessage() ) );
			}

			return $error;
		}
	}

	/** The plan's single entry through Lite's own importer (the path recipes take). */
	private function import_plan( $title, array $plan ) {
		$id = self::guarded_create(
			'definition',
			$title,
			static function () use ( $title, $plan ) {
				return BWFAN_Core()->automations->import( array( FKMCP_Definition_Builder::export_entry( $title, $plan ) ), $title, array(), false );
			}
		);

		if ( is_wp_error( $id ) ) {
			return $id;
		}

		if ( ! is_numeric( $id ) || (int) $id <= 0 ) {
			return new WP_Error( 'fkmcp_create_failed', __( 'The automation was not saved.', 'wp-marketing-automations-pro' ) );
		}

		return array( 'result' => array( 'automation_id' => (int) $id ) );
	}

	/**
	 * Deletes a failed/leaked draft through the same delete-automations path
	 * Phase 1 rollback uses, logging AUTOMATION_CREATE_ROLLED_BACK. Used by
	 * both rollback sites so the logic - and the try/catch around a dispatch
	 * call that could itself throw - exists once.
	 *
	 * @return bool True once the row is gone; false if the delete threw,
	 *              was refused, or left the row (logged as ROLLBACK_FAILED, id only).
	 */
	private static function rollback_draft( $id, $source, $reason ) {
		// The reason can carry a third-party exception message: one line, capped, so it can't forge log entries.
		// Inline, not FKMCP_Definition_Errors::clean(): a recipe/duplicate rollback runs without the definition classes.
		$reason = mb_substr( trim( (string) preg_replace( '/[\x00-\x1F\x7F]+/', ' ', (string) $reason ) ), 0, 200 );

		try {
			$response = BWFAN_MCP_Dispatch::write( 'delete-automations', array( 'automation_ids' => array( $id ) ) );
		} catch ( Throwable $e ) {
			$response = null;
		}

		// The controller answers a refused or skipped delete with a WP_Error, or not at all: the row decides.
		if ( is_wp_error( $response ) || ! empty( BWFAN_Model_Automations::get( $id ) ) ) {
			BWFAN_MCP_Log::event( sprintf( 'ROLLBACK_FAILED id=%d', $id ) );

			return false;
		}

		BWFAN_MCP_Log::event( sprintf( 'AUTOMATION_CREATE_ROLLED_BACK id=%d source=%s reason=%s', $id, $source, $reason ) );

		return true;
	}

	/**
	 * When rollback_draft() itself failed, appends a sentence naming the
	 * still-there draft so the agent can tell the user to remove it by hand -
	 * the original error's code and message stay the lead, never replaced.
	 */
	private static function with_rollback_failure( WP_Error $error, $id, $rolled_back ) {
		if ( $rolled_back ) {
			return $error;
		}

		$message = rtrim( wp_strip_all_tags( $error->get_error_message() ), " \t\n\r\0\x0B." ) . '. '
			. sprintf( /* translators: %d: the automation id */ __( 'The unfinished draft #%d could not be removed; delete it from Automations.', 'wp-marketing-automations-pro' ), $id );

		return new WP_Error( $error->get_error_code(), $message, $error->get_error_data() );
	}

	/**
	 * References import() can't remap (the dynamic coupon names a step row id):
	 * temp id → node id → the real stepId import() gave that node.
	 * Throws on anything unresolved, so the caller rolls back.
	 */
	private function apply_post_refs( $aid, array $plan ) {
		if ( empty( $plan['post_refs'] ) ) {
			return;
		}

		$meta = BWFAN_Model_Automationmeta::get_automation_meta( $aid, false );
		$real = array();
		foreach ( isset( $meta['steps'] ) && is_array( $meta['steps'] ) ? $meta['steps'] : array() as $node ) {
			if ( isset( $node['id'], $node['stepId'] ) && is_numeric( $node['stepId'] ) ) {
				$real[ (string) $node['id'] ] = (int) $node['stepId'];
			}
		}

		foreach ( $plan['post_refs'] as $ref ) {
			$from_node = isset( $plan['node_ids'][ $ref['temp'] - 1 ] ) ? $plan['node_ids'][ $ref['temp'] - 1 ] : '';
			$to_node   = isset( $plan['node_ids'][ $ref['target_temp'] - 1 ] ) ? $plan['node_ids'][ $ref['target_temp'] - 1 ] : '';
			$from      = isset( $real[ $from_node ] ) ? $real[ $from_node ] : 0;
			$to        = isset( $real[ $to_node ] ) ? $real[ $to_node ] : 0;
			$row       = $from ? BWFAN_Model_Automation_Step::get_step_data_by_id( $from ) : array();
			$data      = isset( $row['data'] ) ? json_decode( (string) $row['data'], true ) : null;

			if ( ! $from || ! $to || ! is_array( $data ) || ! isset( $data['sidebarData'] ) || ! is_array( $data['sidebarData'] ) ) {
				throw new RuntimeException( 'a step reference could not be resolved after import' );
			}

			$slot = &$data['sidebarData'];
			foreach ( $ref['key_path'] as $key ) {
				if ( ! is_array( $slot ) || ! array_key_exists( $key, $slot ) ) {
					throw new RuntimeException( 'a step reference could not be resolved after import' );
				}
				$slot = &$slot[ $key ];
			}
			$slot = $to;
			unset( $slot );

			BWFAN_Model_Automation_Step::update( array( 'data' => wp_json_encode( $data ) ), array( 'ID' => $from ) );
		}
	}

	/**
	 * Automation categories by id or exact name, read-only: shape, the max of
	 * 20, and whether every name/id exists. Returns {id, value} pairs ready
	 * for BWFCRM_Category::add_categories(), or null when categories wasn't
	 * sent. Problems go into $errors with categories[i] paths, the collector
	 * build() then fills with the definition's own, so both arrive in one
	 * round trip. Nothing is created here: the spec requires nothing is
	 * written before the whole input (definition + categories) validates.
	 */
	private function validate_categories( $value, $create, FKMCP_Definition_Errors $errors ) {
		if ( null === $value ) {
			return null;
		}

		if ( ! class_exists( 'BWFCRM_Category' ) ) {
			$errors->add( 'categories', __( 'Automation categories are not available on this site.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		if ( ! is_array( $value ) || count( $value ) > 20 ) {
			$errors->add( 'categories', __( 'must be a list of at most 20 ids or names.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		// One batched lookup for every existing category (spec §0.2.3), plus - since that
		// call is capped at 500 rows - a second batched lookup for any ids this call was
		// actually given, so an id past the first 500 still resolves.
		$by_id   = array();
		$by_name = array();
		foreach ( (array) BWFCRM_Category::get_categories( BWFCRM_Category::$AUTOMATION, array(), '', '', 500 ) as $cat ) {
			$by_id[ (int) $cat['ID'] ] = (string) $cat['name'];
			$name                      = strtolower( trim( (string) $cat['name'] ) );
			if ( ! isset( $by_name[ $name ] ) ) {
				$by_name[ $name ] = array( 'id' => (int) $cat['ID'], 'name' => (string) $cat['name'] );
			}
		}

		$requested_ids = array_values( array_unique( array_filter( $value, 'is_int' ) ) );
		if ( ! empty( $requested_ids ) ) {
			foreach ( (array) BWFCRM_Category::get_categories( BWFCRM_Category::$AUTOMATION, $requested_ids, '', '', count( $requested_ids ) ) as $cat ) {
				$by_id[ (int) $cat['ID'] ] = (string) $cat['name'];
			}
		}

		$seen  = array(); // id => true, de-duplicated
		$specs = array(); // {id, value} for a not-yet-created name only
		foreach ( array_values( $value ) as $i => $item ) {
			$path = 'categories[' . $i . ']';

			if ( is_int( $item ) && isset( $by_id[ $item ] ) ) {
				$seen[ $item ] = true;
			} elseif ( is_string( $item ) && '' !== trim( $item ) && mb_strlen( $item ) <= 100 && isset( $by_name[ strtolower( trim( $item ) ) ] ) ) {
				$seen[ $by_name[ strtolower( trim( $item ) ) ]['id'] ] = true;
			} elseif ( $create && is_string( $item ) && '' !== trim( $item ) && mb_strlen( $item ) <= 100 && false === strpos( $item, '{{' ) ) {
				$sanitized = sanitize_text_field( $item );

				if ( '' === $sanitized ) {
					$errors->add( $path, __( 'sanitizes to an empty name.', 'wp-marketing-automations-pro' ) );
					continue;
				}

				$specs[] = array( 'id' => 0, 'value' => $sanitized );
			} else {
				/* translators: %s: the value given */
				$errors->add( $path, sprintf( __( 'is not a category on this site: "%s".', 'wp-marketing-automations-pro' ), mb_substr( wp_strip_all_tags( is_scalar( $item ) ? (string) $item : '' ), 0, 80 ) ), array_values( array_unique( $by_id ) ) );
			}
		}

		foreach ( array_keys( $seen ) as $id ) {
			$specs[] = array( 'id' => $id, 'value' => $by_id[ $id ] );
		}

		return $specs;
	}

	/**
	 * Creates any missing categories from validate_categories()'s specs and
	 * fetches the existing ones, in the one shape both
	 * BWFCRM_Category::assign_categories() needs and this tool reports:
	 * `assign` for the former, `ids`/`created_terms` for the latter.
	 */
	private function create_categories( array $specs ) {
		if ( empty( $specs ) ) {
			return array( 'assign' => array( 'created' => array(), 'existing' => array() ), 'ids' => array(), 'created_terms' => array() );
		}

		$made = BWFCRM_Category::add_categories( $specs, BWFCRM_Category::$AUTOMATION );

		if ( false === $made || ! is_array( $made ) ) {
			return new WP_Error( 'fkmcp_create_failed', __( 'Automation categories could not be created.', 'wp-marketing-automations-pro' ) );
		}

		$ids           = array();
		$created_terms = array();
		foreach ( array( 'created', 'existing' ) as $bucket ) {
			foreach ( (array) BWFCRM_Term::get_collection_array( isset( $made[ $bucket ] ) ? $made[ $bucket ] : array() ) as $term ) {
				$ids[] = (int) $term['ID'];
				if ( 'created' === $bucket ) {
					$created_terms[] = array( 'type' => 'category', 'id' => (int) $term['ID'], 'name' => (string) $term['name'] );
				}
			}
		}

		return array( 'assign' => $made, 'ids' => array_values( array_unique( $ids ) ), 'created_terms' => $created_terms );
	}

	/** Webhook triggers: the URL to paste into the sending service, with its real id and key. */
	private function webhook_url( $aid, array $plan ) { // $plan needs only need_unique_key + event, so Task 12 reuses it.
		if ( empty( $plan['need_unique_key'] ) ) {
			return null;
		}

		$event = FKMCP_Part_Registry::event( $plan['event'] );
		$meta  = BWFAN_Model_Automationmeta::get_meta( $aid, 'event_meta' );
		$key   = is_array( $meta ) && isset( $meta['bwfan_unique_key'] ) ? (string) $meta['bwfan_unique_key'] : '';

		foreach ( null !== $event ? $event['fields'] : array() as $field ) {
			if ( ! empty( $field['webhook_url'] ) && '' !== $key ) {
				return str_replace( array( '{{automationId}}', '{{uniqueKey}}' ), array( (string) (int) $aid, rawurlencode( $key ) ), (string) $field['webhook_url'] );
			}
		}

		return null;
	}

	public function get_webhook_sample( $input = array() ) {
		$aid = isset( $input['automation_id'] ) ? absint( $input['automation_id'] ) : 0;
		$row = $aid ? BWFAN_Model_Automations::get( $aid ) : array();

		if ( empty( $row ) ) {
			return new WP_Error( 'fkmcp_not_found', __( 'No Automation found for the given automation_id.', 'wp-marketing-automations-pro' ) );
		}

		self::load_definition_classes();
		$event = FKMCP_Part_Registry::event( (string) $row['event'] );

		if ( null === $event || empty( $event['need_unique_key'] ) ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'This Automation\'s trigger is not a webhook.', 'wp-marketing-automations-pro' ) );
		}

		$webhook_url = BWFAN_MCP_Permissions::can_write() ? $this->webhook_url( $aid, array( 'need_unique_key' => true, 'event' => (string) $row['event'] ) ) : null;

		// need_unique_key also covers the Connectors add-on's 8 webhook triggers, but only
		// the built-in one stores what it received (event_meta['webhook_data'] - see
		// modules/autonami/events/class-bwfan-autonami-webhook-received.php:126). For every
		// other such trigger, `received` would stay false forever and the agent would loop
		// asking the user to resend a test request that already arrived and was discarded.
		if ( 'autonami_webhook_received' !== (string) $row['event'] ) {
			return array(
				'automation_id'    => $aid,
				'received'         => false,
				'received_at'      => null,
				'referer'          => null,
				'fields'           => array(),
				'email_candidates' => array(),
				'skipped'          => 0,
				'sample_supported' => false,
				'note'             => __( "This trigger's requests aren't stored for sampling; map its fields in the builder.", 'wp-marketing-automations-pro' ),
				'webhook_url'      => $webhook_url,
			);
		}

		$meta    = (array) BWFAN_Model_Automationmeta::get_meta( $aid, 'event_meta' );
		$sample  = isset( $meta['webhook_data'] ) && is_array( $meta['webhook_data'] ) ? $meta['webhook_data'] : array();
		$out     = array();
		$skipped = 0;

		self::flatten_sample( $sample, array(), $out, $skipped );

		$fields = array();
		$emails = array();

		foreach ( $out as $path => $value ) {
			$clean    = self::untrust( is_scalar( $value ) ? (string) $value : '' );
			$fields[] = array( 'path' => (string) $path, 'sample' => $clean );
			if ( is_string( $value ) && is_email( $value ) ) {
				$emails[] = (string) $path;
			}
		}

		$received = ! empty( $sample );
		$note     = null;

		if ( ! $received ) {
			$note = null !== $webhook_url
				? __( 'No test request has arrived yet. Send one to webhook_url, then call this again.', 'wp-marketing-automations-pro' )
				: __( "No test request has arrived yet. Ask someone with write access to copy the webhook URL from the Automation's trigger in the builder and send a test request, then call this again.", 'wp-marketing-automations-pro' );
		}

		return array(
			'automation_id'    => $aid,
			'received'         => $received,
			'received_at'      => ! empty( $meta['received_at'] ) ? gmdate( 'c', absint( $meta['received_at'] ) ) : null,
			'referer'          => ! empty( $meta['referer'] ) ? self::untrust( (string) $meta['referer'] ) : null,
			'fields'           => $fields,
			'email_candidates' => $emails,
			'skipped'          => $skipped,
			'sample_supported' => true,
			'note'             => $note,
			'webhook_url'      => $webhook_url,
		);
	}

	/**
	 * The builder's flattening (Lite's get_webhook_fields(),
	 * merge_tags/class-bwfan-wp-webhook-data.php:126-143): dot-joined keys,
	 * array indices as path segments. An empty array is listed as its own
	 * leaf with an empty sample, same as Lite's version - its "recurse only
	 * into a non-empty array" check (class-bwfan-wp-webhook-data.php:134)
	 * falls through to the same leaf assignment an empty array would hit
	 * (line 139) rather than skipping it. A top-level list keeps its leading
	 * index (e.g. "0.sku"): that's what the runtime {{wp_webhook_data}} walk
	 * resolves, even though the builder's field *picker* drops that leading
	 * "0" for display.
	 *
	 * Stops at WEBHOOK_FIELD_CAP fields and 10 levels deep while it walks,
	 * rather than flattening a whole untrusted stored payload and slicing
	 * the result afterwards. A path is dropped - and counted in $skipped,
	 * by reference - rather than returned when any segment isn't
	 * byte-for-byte what untrust() would leave it as, contains '.' (the
	 * runtime's explode('.') walk can't resolve a literal dot), contains a
	 * control character, or the joined path is over 255 characters:
	 * fail-closed, since every path this tool returns becomes a
	 * merge-tag/bwfan_email_map_key argument the agent passes straight back in.
	 */
	private static function flatten_sample( array $data, array $segments, array &$out, &$skipped, $depth = 0 ) {
		if ( $depth > 10 || count( $out ) >= self::WEBHOOK_FIELD_CAP ) {
			return;
		}

		foreach ( $data as $key => $value ) {
			if ( count( $out ) >= self::WEBHOOK_FIELD_CAP ) {
				return;
			}

			$segment = (string) $key;

			if ( self::bad_webhook_path_segment( $segment ) ) {
				++$skipped;
				continue;
			}

			$path_segments   = $segments;
			$path_segments[] = $segment;

			if ( is_array( $value ) ) {
				if ( empty( $value ) ) {
					self::add_webhook_leaf( $out, $skipped, $path_segments, '' );
					continue;
				}
				self::flatten_sample( $value, $path_segments, $out, $skipped, $depth + 1 );
				continue;
			}

			self::add_webhook_leaf( $out, $skipped, $path_segments, $value );
		}
	}

	/** A path segment unsafe to hand back as (part of) a dotted path - see flatten_sample(). */
	private static function bad_webhook_path_segment( $segment ) {
		return $segment !== self::untrust( $segment )
			|| false !== strpos( $segment, '.' )
			|| (bool) preg_match( '/[\x00-\x1F\x7F]/', $segment );
	}

	/** Joins segments into one path, dropping (and counting) it if that path is too long to be a safe merge-tag argument. */
	private static function add_webhook_leaf( array &$out, &$skipped, array $segments, $value ) {
		$path = implode( '.', $segments );

		if ( mb_strlen( $path ) > 255 ) {
			++$skipped;
			return;
		}

		$out[ $path ] = $value;
	}

	/**
	 * Why a just-created Automation is not fit to keep, or '' when it is: the
	 * row is V2 and inactive, every graph node's stepId has a step row of this
	 * Automation, and `start` is the first node's row (0 with no steps).
	 * A status other than 2 is forced back to 2 rather than failed.
	 *
	 * @param int $aid
	 *
	 * @return string
	 */
	private function creation_problem( $aid, array $joins = array(), array &$warnings = array(), $definition = false, $rows = null ) {
		$row = BWFAN_Model_Automations::get( $aid );

		if ( empty( $row ) ) {
			return 'row missing';
		}

		if ( 2 !== (int) $row['v'] ) {
			return 'not a Next Gen automation';
		}

		if ( 2 !== (int) $row['status'] ) {
			BWFAN_Model_Automations_V2::update_automation( $aid, array( 'status' => 2 ) );
			BWFAN_MCP_Log::event( sprintf( 'AUTOMATION_STATUS_FORCED id=%d from=%d', $aid, (int) $row['status'] ) );

			$row = BWFAN_Model_Automations::get( $aid );

			if ( empty( $row ) || 2 !== (int) $row['status'] ) {
				return 'status could not be set to inactive';
			}
		}

		$meta = BWFAN_Model_Automationmeta::get_automation_meta( $aid, false );
		$rows = null === $rows ? self::step_rows( $aid ) : $rows; // update_problem() passes the rows it read after the writes.

		return self::graph_problem( $row, $meta, $rows, $joins, $warnings, $definition );
	}

	/**
	 * The read-only part of creation_problem(): every graph node's stepId has a
	 * step row, `start` is the first node's row, and, when $joins is given, every
	 * fork is whole; with $definition, the goal and jump references too. Writes
	 * nothing; activation_problem() runs it on a saved Automation.
	 *
	 * @return string '' or what is wrong.
	 */
	private static function graph_problem( array $row, array $meta, array $rows, array $joins = array(), array &$warnings = array(), $definition = false ) {
		$nodes = isset( $meta['steps'] ) && is_array( $meta['steps'] ) ? $meta['steps'] : array();
		$links = isset( $meta['links'] ) && is_array( $meta['links'] ) ? $meta['links'] : array();
		$by_id = array();
		$start = 0;

		foreach ( $nodes as $node ) {
			$sid = self::node_step_id( $node );

			if ( 0 === $sid ) {
				continue;
			}

			if ( ! isset( $rows[ $sid ] ) ) {
				return sprintf( 'graph node %s has no step row', isset( $node['id'] ) ? (string) $node['id'] : '?' );
			}

			if ( isset( $node['id'] ) ) {
				$by_id[ (string) $node['id'] ] = $sid;
			}
		}

		foreach ( $links as $link ) {
			if ( is_array( $link ) && isset( $link['source'], $link['target'] ) && 'start' === $link['source'] ) {
				$start = isset( $by_id[ (string) $link['target'] ] ) ? $by_id[ (string) $link['target'] ] : 0;
				break;
			}
		}

		if ( $start !== absint( $row['start'] ) ) {
			return sprintf( 'start is %d, the first step is %d', absint( $row['start'] ), $start );
		}

		if ( ! empty( $joins ) ) {
			$problem = self::fork_problem( $nodes, $links, $meta, $joins, $rows, $warnings );
			if ( '' !== $problem ) {
				return $problem;
			}
		}

		if ( $definition ) {
			$problem = self::goal_problem( $row, $nodes, $rows );
			if ( '' !== $problem ) {
				return $problem;
			}

			$problem = self::ref_problem( $rows );
			if ( '' !== $problem ) {
				return $problem;
			}
		}

		return '';
	}

	/**
	 * Every fork a definition built is still whole after import() and the graph
	 * save (spec §15.2): it has at least two lanes and none of them is its own
	 * join, every lane head exists, every other node has exactly one way out
	 * (the runtime keeps one target per source), and the builder's merger point
	 * is the join we built. A branches fork's chips are exactly its row's branch
	 * ids plus else: routing rebuilds "{n}-branch-{id}" from the row, so a chip
	 * that isn't one loses its contacts. Every chip is listed before every real
	 * step (FKMCP_Graph_Builder::tree()), so Lite's intval() collision can't
	 * occur; any mismatch is a real fault.
	 */
	private static function fork_problem( array $nodes, array $links, array $meta, array $joins, array $rows, array &$warnings ) {
		$types = array();
		$by_id = array();
		foreach ( $nodes as $node ) {
			if ( is_array( $node ) && isset( $node['id'] ) ) {
				$id           = (string) $node['id'];
				$types[ $id ] = isset( $node['type'] ) ? (string) $node['type'] : '';
				$by_id[ $id ] = $node;
			}
		}

		$out = array();
		foreach ( $links as $link ) {
			if ( is_array( $link ) && isset( $link['source'], $link['target'] ) ) {
				$out[ (string) $link['source'] ][] = (string) $link['target'];
			}
		}

		foreach ( $joins as $n => $join ) {
			$n     = (string) $n;
			$heads = isset( $out[ $n ] ) ? $out[ $n ] : array();

			if ( ! isset( $types[ $n ] ) ) {
				return sprintf( 'fork %s is missing', $n );
			}
			if ( count( $heads ) < 2 ) {
				return sprintf( 'fork %s has %d lanes', $n, count( $heads ) );
			}
			foreach ( $heads as $head ) {
				if ( $head === (string) $join ) {
					return sprintf( 'fork %s links straight to its join', $n );
				}
				if ( ! isset( $types[ $head ] ) ) {
					return sprintf( 'fork %s lane head %s is missing', $n, $head );
				}
			}

			if ( 'branches' === $types[ $n ] && ! self::branch_chips_match( $n, $heads, $by_id, $rows ) ) {
				return sprintf( 'fork %s branch chips do not match its branch ids', $n );
			}

			if ( 'split' === $types[ $n ] && ! self::split_chips_match( $n, $heads, $by_id, $rows ) ) {
				return sprintf( 'fork %s split paths do not match its split_path', $n );
			}
		}

		foreach ( $types as $id => $type ) {
			if ( 'end' === $id || isset( $joins[ $id ] ) ) {
				continue;
			}
			$ways = isset( $out[ $id ] ) ? count( $out[ $id ] ) : 0;
			if ( 1 !== $ways ) {
				return sprintf( 'node %s has %d ways out, not one', $id, $ways );
			}
		}

		$mergers = isset( $meta['merger_points'] ) && is_array( $meta['merger_points'] ) ? $meta['merger_points'] : array();
		foreach ( $joins as $n => $join ) {
			$n   = (string) $n;
			$got = isset( $mergers[ $n ] ) ? (string) $mergers[ $n ] : '';

			if ( $got === (string) $join ) {
				continue;
			}

			return sprintf( 'fork %s merges at %s, not %s', $n, '' === $got ? 'nothing' : $got, $join );
		}

		return '';
	}

	/** The lane heads of branches fork $n are exactly "{n}-branch-{id}" for each row branch id, plus "{n}-branch-else", each carrying its own id. */
	private static function branch_chips_match( $n, array $heads, array $by_id, array $rows ) {
		$sid  = self::node_step_id( $by_id[ $n ] );
		$data = isset( $rows[ $sid ]['data'] ) ? $rows[ $sid ]['data'] : null;
		$data = is_string( $data ) ? json_decode( $data, true ) : $data;
		$defs = isset( $data['sidebarData']['branches'] ) && is_array( $data['sidebarData']['branches'] ) ? $data['sidebarData']['branches'] : null;

		if ( null === $defs ) {
			return false;
		}

		$want = array( $n . '-branch-else' );
		foreach ( $defs as $def ) {
			if ( ! is_array( $def ) || ! isset( $def['id'] ) || ! is_scalar( $def['id'] ) ) {
				return false;
			}
			$want[] = $n . '-branch-' . $def['id'];
		}

		foreach ( $heads as $head ) {
			$bid = isset( $by_id[ $head ]['data']['branchId'] ) && is_scalar( $by_id[ $head ]['data']['branchId'] ) ? (string) $by_id[ $head ]['data']['branchId'] : '';
			if ( $head !== $n . '-branch-' . $bid ) {
				return false;
			}
		}

		sort( $want );
		sort( $heads );

		return $want === $heads;
	}

	/**
	 * Split fork $n's lane heads are exactly "{n}-path-1".."{n}-path-P", with P the
	 * row's split_path (the runtime picks a path number up to split_path and follows
	 * that chip), each chip's stepId equal to its id (without it Lite's
	 * get_step_iteration_array() drops the chip's links) and data.path equal to k.
	 */
	private static function split_chips_match( $n, array $heads, array $by_id, array $rows ) {
		$sid  = self::node_step_id( $by_id[ $n ] );
		$data = isset( $rows[ $sid ]['data'] ) ? $rows[ $sid ]['data'] : null;
		$data = is_string( $data ) ? json_decode( $data, true ) : $data;
		$p    = isset( $data['sidebarData']['split_path'] ) && is_numeric( $data['sidebarData']['split_path'] ) ? (int) $data['sidebarData']['split_path'] : 0;

		if ( $p < 2 || $p > 3 || count( $heads ) !== $p ) {
			return false;
		}

		$want = array();
		for ( $k = 1; $k <= $p; $k++ ) {
			$chip = $n . '-path-' . $k;
			$node = isset( $by_id[ $chip ] ) ? $by_id[ $chip ] : null;
			if ( null === $node || ! isset( $node['stepId'] ) || $chip !== (string) $node['stepId'] || ! isset( $node['data']['path'] ) || $k !== (int) $node['data']['path'] ) {
				return false;
			}
			$want[] = $chip;
		}

		sort( $heads );

		return $want === $heads;
	}

	/**
	 * Every goal node's row is a live goal (type 3, status 1, an action naming its
	 * event, a valid bwfan_goal_run), and the main row's benchmark column lists
	 * exactly those goals: the goal event finds contacts through that column only,
	 * so a missing or stale entry would leave a contact at a "wait" goal forever.
	 */
	private static function goal_problem( array $row, array $nodes, array $rows ) {
		$want = array();

		foreach ( $nodes as $node ) {
			if ( ! is_array( $node ) || ! isset( $node['type'] ) || 'benchmark' !== $node['type'] ) {
				continue;
			}

			$sid    = self::node_step_id( $node );
			$step   = isset( $rows[ $sid ] ) ? $rows[ $sid ] : null;
			$action = is_array( $step ) ? json_decode( (string) $step['action'], true ) : null;
			$data   = is_array( $step ) ? json_decode( (string) $step['data'], true ) : null;

			if ( null === $step || 3 !== (int) $step['type'] || 1 !== (int) $step['status'] || empty( $action['benchmark'] ) ) {
				return sprintf( 'goal node %s is not a live goal row', isset( $node['id'] ) ? (string) $node['id'] : '?' );
			}
			if ( ! isset( $data['sidebarData']['bwfan_goal_run'] ) || ! in_array( $data['sidebarData']['bwfan_goal_run'], array( 'wait', 'continue', 'end' ), true ) ) {
				return sprintf( 'goal %d has no valid bwfan_goal_run', $sid );
			}

			$want[ (int) $sid ] = (string) $action['benchmark'];
		}

		$have = isset( $row['benchmark'] ) && '' !== (string) $row['benchmark'] ? json_decode( (string) $row['benchmark'], true ) : array();
		$have = is_array( $have ) ? $have : array();
		$norm = array();
		foreach ( $have as $k => $v ) {
			$norm[ (int) $k ] = (string) $v;
		}

		ksort( $want );
		ksort( $norm );

		return $want === $norm ? '' : 'the benchmark column does not list exactly the goals';
	}

	/**
	 * Every jump and date-wait skip points at "end" or at a live (status 1) step of
	 * this same automation: import()'s update_jumped_step_data() leaves a target it
	 * can't map unchanged, and a stray id would point at another automation's row.
	 */
	private static function ref_problem( array $rows ) {
		foreach ( $rows as $sid => $step ) {
			$data = is_string( $step['data'] ) ? json_decode( $step['data'], true ) : null;
			$sb   = isset( $data['sidebarData'] ) && is_array( $data['sidebarData'] ) ? $data['sidebarData'] : array();

			if ( 6 === (int) $step['type'] ) {
				$to = isset( $sb['jump_to']['step'] ) ? $sb['jump_to']['step'] : null;
			} elseif ( 1 === (int) $step['type'] && ! empty( $sb['data']['enable_step_skip'] ) ) {
				$to = isset( $sb['data']['skip_to_step']['step'] ) ? $sb['data']['skip_to_step']['step'] : null;
			} else {
				continue;
			}

			if ( 'end' === $to ) {
				continue;
			}

			$target = is_numeric( $to ) ? (int) $to : 0;
			if ( $target <= 0 || $target === (int) $sid || ! isset( $rows[ $target ] ) || 1 !== (int) $rows[ $target ]['status'] ) {
				return sprintf( 'step %d points at %s, not a live step of this automation', $sid, is_scalar( $to ) ? (string) $to : '?' );
			}
		}

		return '';
	}

	/**
	 * Runs the builder's own graph save over what import() / duplicate() left.
	 *
	 * import() copies step_iteration_array with the source's step ids,
	 * duplicate() writes none, and neither writes merger_points or split_steps; the builder only repairs
	 * that on the first GET, when merger_points is missing. A draft activated
	 * from the list without being opened would run on ids that no longer
	 * exist. This is that same repair call, made up front. A blank Automation
	 * has no graph and is left alone.
	 *
	 * @param int $aid
	 *
	 * @return void
	 */
	private static function save_graph( $aid ) {
		$automation = BWFAN_Automation_V2::get_instance( $aid );

		if ( is_wp_error( $automation ) || ! empty( $automation->error ) ) {
			return;
		}

		$automation->fetch_automation_metadata( false );
		$meta = $automation->get_automation_meta_data();

		if ( empty( $meta['steps'] ) || ! is_array( $meta['steps'] ) ) {
			return;
		}

		// duplicate() writes no step_iteration_array row, and the repair only
		// updates rows that exist - the split-test traversal reads this one.
		if ( ! isset( $meta['step_iteration_array'] ) ) {
			$meta['step_iteration_array'] = '';
		}

		$automation->update_automation_meta_data( $meta, $meta['steps'], isset( $meta['links'] ) ? $meta['links'] : array(), isset( $meta['count'] ) ? $meta['count'] : 0 );
	}

	/**
	 * Writes each split's sidebarData.mail_steps as the builder's step save does: Lite's
	 * BWFAN_API_Automation_Controller::save_mail_steps() runs on every step save, and Pro's
	 * A/B path stats read only this key. Per path ("p-1", ...): its email row ids, then its
	 * SMS ones, from the split_steps meta save_graph() just wrote (Lite computes it in
	 * update_automation_meta_data()), real row ids only. The same model helpers are
	 * called instead of the controller, whose constructor registers REST routes. Only
	 * the mail_steps key is replaced; the rest of the row's data is kept. A failed
	 * write throws, so the caller rolls the draft back.
	 *
	 * Batched, not per-split: one get_messaging_steps() for every split's ids together (one
	 * for email, one for SMS), and one step_rows() read for every split row's current data,
	 * instead of 2 lookups per path plus a get_step_data() per split. `IN (...)` on the
	 * primary key comes back in ascending id order regardless of list size, so slicing the
	 * combined result per path with array_intersect() (which keeps the left side's order)
	 * gives the same per-path order a separate query would have.
	 *
	 * @param int $aid
	 *
	 * @return void
	 */
	private static function save_mail_steps( $aid ) {
		$meta        = BWFAN_Model_Automationmeta::get_automation_meta( $aid, false );
		$split_steps = isset( $meta['split_steps'] ) && is_array( $meta['split_steps'] ) ? $meta['split_steps'] : array();

		if ( empty( $split_steps ) ) {
			return;
		}

		$real = function ( $step_ids ) {
			// Only real row ids: a condition's "9yes"/"9no" pseudo-nodes are in split_steps too, and
			// get_messaging_steps() casts them with %d (no aid filter), so Lite's own save would list
			// row 9 of any automation. That id is never this split's step.
			return array_values( array_filter( array_map( function ( $v ) {
				return is_int( $v ) || ctype_digit( (string) $v ) ? (string) absint( $v ) : null;
			}, (array) $step_ids ), function ( $v ) {
				return null !== $v;
			} ) );
		};

		$all_ids = array();
		foreach ( $split_steps as $paths ) {
			foreach ( (array) $paths as $step_ids ) {
				$all_ids = array_merge( $all_ids, $real( $step_ids ) );
			}
		}
		$all_ids = array_values( array_unique( $all_ids ) );

		$email_ids = empty( $all_ids ) ? array() : BWFAN_Model_Automation_Step::get_messaging_steps( $all_ids );
		$sms_ids   = empty( $all_ids ) ? array() : BWFAN_Model_Automation_Step::get_messaging_steps( $all_ids, '_sms' );
		$rows      = self::step_rows( $aid );

		foreach ( $split_steps as $step_id => $paths ) {
			$mail_steps = array();
			foreach ( (array) $paths as $path_name => $step_ids ) {
				$path_ids                 = $real( $step_ids );
				$mail_steps[ $path_name ] = empty( $path_ids ) ? array() : array_merge(
					array_values( array_intersect( $email_ids, $path_ids ) ),
					array_values( array_intersect( $sms_ids, $path_ids ) )
				);
			}

			$sid  = absint( $step_id );
			$data = isset( $rows[ $sid ]['data'] ) ? $rows[ $sid ]['data'] : null;
			$data = is_string( $data ) ? json_decode( $data, true ) : $data;
			$data = is_array( $data ) ? $data : array();

			$data['sidebarData']               = isset( $data['sidebarData'] ) && is_array( $data['sidebarData'] ) ? $data['sidebarData'] : array();
			$data['sidebarData']['mail_steps'] = $mail_steps;

			if ( false === BWFAN_Model_Automation_Step::update( array( 'data' => wp_json_encode( $data ) ), array( 'ID' => $sid ) ) ) {
				throw new RuntimeException( 'the split step ' . $sid . ' mail steps could not be saved' );
			}
		}
	}

	/** A graph node's step row id; 0 for start/end and the split/branch chips, which have none. */
	private static function node_step_id( $node ) {
		if ( ! is_array( $node ) || empty( $node['stepId'] ) ) {
			return 0;
		}

		$sid = (string) $node['stepId'];

		if ( false !== strpos( $sid, '-path-' ) || false !== strpos( $sid, '-branch-' ) ) {
			return 0;
		}

		return absint( $sid );
	}

	/** The Automation's live step rows (archived ones excluded), keyed by id. */
	private static function step_rows( $aid ) {
		$found = BWFAN_Model_Automation_Step::get_all_automation_steps( $aid );
		$rows  = array();

		foreach ( isset( $found['steps'] ) && is_array( $found['steps'] ) ? $found['steps'] : array() as $step ) {
			if ( is_array( $step ) && ! empty( $step['ID'] ) ) {
				$rows[ absint( $step['ID'] ) ] = $step;
			}
		}

		return $rows;
	}

	/**
	 * Every path's real row id, from the graph just saved (M5a Task 7): one meta
	 * read, a cache hit after creation_problem()/update_problem() already forced
	 * a fresh one for this $aid in this request. Feeds FKMCP_Email_Step::previews(),
	 * which only needs it for a designed email written this call: none, no walk.
	 */
	private static function path_to_id( $aid, array $rows, array $emails ) {
		$designed = false;
		foreach ( $emails as $email ) {
			$designed = $designed || ( ! empty( $email['designed'] ) && empty( $email['kept'] ) );
		}
		if ( ! $designed ) {
			return array();
		}

		$meta = BWFAN_Model_Automationmeta::get_automation_meta( $aid );
		$out  = array();

		foreach ( FKMCP_Saved_Tree::positions(
			isset( $meta['steps'] ) && is_array( $meta['steps'] ) ? $meta['steps'] : array(),
			isset( $meta['links'] ) && is_array( $meta['links'] ) ? $meta['links'] : array(),
			isset( $meta['merger_points'] ) && is_array( $meta['merger_points'] ) ? $meta['merger_points'] : array(),
			$rows
		) as $path => $position ) {
			$out[ $path ] = $position['id'];
		}

		return $out;
	}

	/** Warnings for any email previews() could not make; drops previews()' internal preview_error flag, so emails[] matches the schema. */
	private static function preview_warnings( array &$emails ) {
		$warnings = array();

		foreach ( $emails as &$email ) {
			if ( ! empty( $email['preview_error'] ) ) {
				/* translators: %s: the step's path, e.g. steps[0] */
				$warnings[] = sprintf( __( 'A preview could not be made for %s.', 'wp-marketing-automations-pro' ), $email['path'] );
			}
			unset( $email['preview_error'] );
		}
		unset( $email );

		return $warnings;
	}

	/** Step ids saved incomplete (status 2), ascending: what the builder still needs configured. */
	private static function incomplete_steps( array $rows ) {
		$ids = array();
		foreach ( $rows as $sid => $step ) {
			if ( 2 === (int) $step['status'] ) {
				$ids[] = $sid;
			}
		}
		sort( $ids );

		return $ids;
	}

	/** What create-automation returns about an Automation, reused or new. */
	private function automation_summary( $aid, $rows = null ) {
		$row     = BWFAN_Model_Automations::get( $aid );
		$rows    = null === $rows ? self::step_rows( $aid ) : $rows;
		$actions = array();

		foreach ( $rows as $sid => $step ) {
			$action = isset( $step['action'] ) && is_string( $step['action'] ) ? json_decode( $step['action'], true ) : null;

			if ( 2 === (int) $step['type'] && is_array( $action ) && ! empty( $action['action'] ) && is_string( $action['action'] ) ) {
				$actions[ $action['action'] ] = true;
			}
		}

		$incomplete = self::incomplete_steps( $rows );

		return array(
			'automation_id'    => (int) $aid,
			'title'            => isset( $row['title'] ) ? (string) $row['title'] : '',
			'status'           => isset( $row['status'] ) && 1 === (int) $row['status'] ? 'active' : 'inactive',
			'event'            => ! empty( $row['event'] ) ? (string) $row['event'] : null,
			'step_count'       => count( $rows ),
			'incomplete_steps' => $incomplete,
			'actions'          => array_keys( $actions ),
			'admin_url'        => BWFAN_MCP_Links::app( 'autonami', '/automation/' . (int) $aid ),
		);
	}

	/**
	 * get-automation: each step's definition path, from the same saved-tree walk
	 * update-automation uses, so keep and template_id can name a step. One read of
	 * the step rows; nothing written. Any failure returns the result undecorated.
	 *
	 * @param array|mixed $automation Lite's get_automation() result so far.
	 * @param int         $aid        The requested automation id.
	 * @param array|mixed $result     The REST GET automation payload (untrusted structure).
	 *
	 * @return array|mixed
	 */
	public static function decorate_get_automation( $automation, $aid, $result ) {
		try {
			if ( ! is_array( $automation ) || ! isset( $automation['steps'] ) || ! is_array( $automation['steps'] ) || ! is_array( $result ) ) {
				return $automation;
			}
			require_once __DIR__ . '/automation/class-fkmcp-saved-tree.php';

			$nodes   = isset( $result['steps'] ) && is_array( $result['steps'] ) ? $result['steps'] : array();
			$links   = isset( $result['links'] ) && is_array( $result['links'] ) ? $result['links'] : array();
			$mergers = isset( $result['meta']['merger_points'] ) && is_array( $result['meta']['merger_points'] ) ? $result['meta']['merger_points'] : array();
			$rows    = self::step_rows( absint( $aid ) );

			$sid_of = array();
			foreach ( $nodes as $node ) {
				if ( is_array( $node ) && isset( $node['id'], $node['stepId'] ) && is_numeric( $node['stepId'] ) ) {
					$sid_of[ (string) $node['id'] ] = (int) $node['stepId'];
				}
			}
			$path_of   = array();
			$positions = FKMCP_Saved_Tree::positions( $nodes, $links, $mergers, $rows );
			foreach ( $positions as $path => $position ) {
				$path_of[ $position['id'] ] = array( $path, $position['type'] );
			}

			foreach ( $automation['steps'] as &$step ) {
				if ( ! is_array( $step ) ) {
					continue;
				}
				$sid = isset( $step['id'], $sid_of[ (string) $step['id'] ] ) ? $sid_of[ (string) $step['id'] ] : 0;
				if ( ! $sid || ! isset( $path_of[ $sid ] ) ) {
					continue;
				}
				$step['path']            = $path_of[ $sid ][0];
				$step['definition_type'] = $path_of[ $sid ][1];

				// M5a ruling #1: email steps also carry the saved template they were copied from, when they have one.
				if ( 'email' === $path_of[ $sid ][1] ) {
					$ref = self::kept_email_template_ref( isset( $rows[ $sid ] ) ? $rows[ $sid ] : null );
					if ( null !== $ref ) {
						$step['template_ref'] = $ref;
					}
				}
			}
			unset( $step );

			$automation = self::with_definition( $automation, $result, $positions, $rows );
		} catch ( Throwable $e ) {
			BWFAN_MCP_Log::event( 'FKMCP_GET_AUTOMATION_DECORATE_FAILED class=' . get_class( $e ) );
		}

		return $automation;
	}

	/**
	 * The whole Automation as the definition update-automation takes: each placed
	 * row read back by FKMCP_Step_Reader and nested at its saved-tree path. Any
	 * row the definition can't express makes the definition null, with the reason
	 * per path in definition_unavailable; steps[] stays as it is either way.
	 *
	 * @param array $automation get-automation's result so far.
	 * @param array $result     The builder API's result (data, meta).
	 * @param array $positions  FKMCP_Saved_Tree::positions(): path => {id, type}.
	 * @param array $rows       Step rows by id.
	 *
	 * @return array
	 */
	private static function with_definition( array $automation, array $result, array $positions, array $rows ) {
		// The reader needs the registry and translators only, not the builders or the review.
		self::load_definition_classes_for_describe();
		require_once __DIR__ . '/automation/class-fkmcp-step-reader.php';

		$event   = isset( $result['data']['event'] ) ? (string) $result['data']['event'] : '';
		$missing = array();

		// A builder node no path reaches (an old or hand-edited graph): the definition would drop it.
		$placed = array_flip( array_map( 'intval', array_column( $positions, 'id' ) ) );
		foreach ( (array) $automation['steps'] as $step ) {
			if ( is_array( $step ) && ! isset( $step['path'] ) && in_array( isset( $step['type'] ) ? $step['type'] : '', array( 'action', 'wait', 'conditional', 'benchmark', 'branches', 'split', 'jump', 'exit' ), true ) ) {
				$missing[] = array( 'path' => null, 'reason' => sprintf( 'step %s is not reachable from the start', (string) $step['id'] ) );
			}
		}

		$ref_of = array();
		foreach ( $rows as $id => $row ) {
			$data = isset( $row['data'] ) && is_string( $row['data'] ) ? json_decode( $row['data'], true ) : ( isset( $row['data'] ) ? (array) $row['data'] : array() );
			$sd   = isset( $data['sidebarData'] ) && is_array( $data['sidebarData'] ) ? $data['sidebarData'] : array();
			$to   = 6 === (int) $row['type'] && isset( $sd['jump_to']['step'] ) ? $sd['jump_to']['step'] : ( 1 === (int) $row['type'] && ! empty( $sd['data']['enable_step_skip'] ) && isset( $sd['data']['skip_to_step']['step'] ) ? $sd['data']['skip_to_step']['step'] : null );
			if ( is_numeric( $to ) && isset( $placed[ (int) $to ] ) ) {
				$ref_of[ (int) $to ] = 's' . (int) $to;
			}
		}

		// The rule registry loads every rule class: only when a condition or branches step needs it.
		$rule_types = array();
		if ( array_intersect( array_column( $positions, 'type' ), array( 'condition', 'branches' ) ) ) {
			foreach ( FKMCP_Rule_Translator::registry( $event ) as $slug => $rule ) {
				$rule_types[ $slug ] = $rule['type'];
			}
		}

		$steps = array();
		foreach ( $positions as $path => $position ) {
			$row = isset( $rows[ $position['id'] ] ) ? $rows[ $position['id'] ] : null;
			if ( ! is_array( $row ) ) {
				$missing[] = array( 'path' => $path, 'reason' => 'the step row is gone' );
				continue;
			}
			$part = null;
			if ( 'action' === $position['type'] || 'goal' === $position['type'] ) {
				$act  = isset( $row['action'] ) && is_string( $row['action'] ) ? json_decode( $row['action'], true ) : ( isset( $row['action'] ) ? (array) $row['action'] : array() );
				$part = 'goal' === $position['type'] ? FKMCP_Part_Registry::goal( isset( $act['benchmark'] ) ? (string) $act['benchmark'] : '' ) : FKMCP_Part_Registry::action( isset( $act['action'] ) ? (string) $act['action'] : '', $event );
			}
			$one = FKMCP_Step_Reader::step( $row, array( 'ref_of' => $ref_of, 'rule_types' => $rule_types, 'part' => is_array( $part ) ? $part : null ) );
			if ( is_wp_error( $one ) ) {
				$missing[] = array( 'path' => $path, 'reason' => $one->get_error_message() );
				continue;
			}
			if ( isset( $ref_of[ (int) $position['id'] ] ) ) {
				$one = array( 'ref' => $ref_of[ (int) $position['id'] ] ) + $one;
			}
			self::place( $steps, $path, self::with_lanes( $one, $row ) );
		}

		$meta    = isset( $result['meta']['event_meta'] ) && is_array( $result['meta']['event_meta'] ) ? $result['meta']['event_meta'] : (array) BWFAN_Model_Automationmeta::get_meta( (int) $automation['ID'], 'event_meta' );
		$event_d = FKMCP_Part_Registry::event( $event );
		$trigger = is_array( $event_d ) ? FKMCP_Step_Reader::trigger( $meta, $event, $event_d ) : new WP_Error( 'fkmcp_reader_unsupported', '' === $event ? 'the automation has no trigger' : 'the trigger is not one this store lists' );
		if ( is_wp_error( $trigger ) ) {
			$missing[] = array( 'path' => 'trigger', 'reason' => $trigger->get_error_message() );
		}

		$definition = array( 'trigger' => $trigger, 'steps' => $steps );
		if ( empty( $missing ) && strlen( (string) wp_json_encode( $definition ) ) > self::DEFINITION_MAX ) {
			$missing[] = array( 'path' => null, 'reason' => 'the definition is longer than 60 KB' );
		}

		$automation['definition'] = empty( $missing ) ? $definition : null;
		if ( ! empty( $missing ) ) {
			$automation['definition_unavailable'] = $missing;
		}

		return $automation;
	}

	/** A fork's empty lanes, filled as its children are placed. */
	private static function with_lanes( array $step, array $row ) {
		switch ( $step['type'] ) {
			case 'condition':
				return $step + array( 'yes' => array(), 'no' => array() );
			case 'branches':
				foreach ( $step['branches'] as $b => $branch ) {
					$step['branches'][ $b ]['steps'] = array();
				}

				return $step + array( 'else' => array() );
			case 'split':
				$data = isset( $row['data'] ) && is_string( $row['data'] ) ? json_decode( $row['data'], true ) : array();
				$n    = isset( $data['sidebarData']['split_path'] ) ? max( 0, min( 3, (int) $data['sidebarData']['split_path'] ) ) : 0;

				return $step + array( 'paths' => array_fill( 0, $n, array() ) );
		}

		return $step;
	}

	/** Sets $tree at a saved-tree path such as steps[2].branches[0].steps[1] or steps[3].paths[1][0]. */
	private static function place( array &$tree, $path, array $step ) {
		preg_match_all( '/([a-z]+)|\[(\d+)\]/', (string) $path, $m, PREG_SET_ORDER );
		array_shift( $m ); // the leading "steps" is $tree itself.

		$node = &$tree;
		foreach ( $m as $token ) {
			$key = isset( $token[2] ) && '' !== $token[2] ? (int) $token[2] : $token[1];
			if ( ! isset( $node[ $key ] ) || ! is_array( $node[ $key ] ) ) {
				$node[ $key ] = array();
			}
			$node = &$node[ $key ];
		}
		$node = $step;
		unset( $node );
	}

	/** { id, revision } from a step row's sidebarData.bwfan_email_data.data.template_ref, or null. */
	private static function kept_email_template_ref( $row ) {
		if ( ! is_array( $row ) || ! isset( $row['data'] ) ) {
			return null;
		}

		$data = is_string( $row['data'] ) ? json_decode( $row['data'], true ) : $row['data'];
		$ref  = isset( $data['sidebarData']['bwfan_email_data']['data']['template_ref'] ) ? $data['sidebarData']['bwfan_email_data']['data']['template_ref'] : null;

		if ( ! is_array( $ref ) || ! isset( $ref['id'], $ref['revision'] ) ) {
			return null;
		}

		return array(
			'id'       => (int) $ref['id'],
			'revision' => (string) $ref['revision'],
		);
	}

	/** update-email-settings input keys that steer the call rather than name a field. */
	const EMAIL_SETTINGS_CONTROLS = array( 'mode', 'review_token', 'confirmed_fields', 'confirm_from_email', 'confirm_reply_to' );

	/** Free mailbox domains: a From address on one fails the receiver's DMARC check for this store. ponytail: the common ones only; extend if support sees others. */
	const FREE_MAILBOXES = array( 'gmail.com', 'googlemail.com', 'yahoo.com', 'ymail.com', 'hotmail.com', 'outlook.com', 'live.com', 'msn.com', 'aol.com', 'icloud.com', 'me.com', 'mac.com', 'proton.me', 'protonmail.com', 'gmx.com', 'gmx.de', 'mail.com', 'yandex.com', 'zoho.com' );

	/**
	 * update-email-settings: review first, then save the same values with the review token,
	 * every changed field confirmed and any changed address typed by the user.
	 *
	 * @param array $input
	 *
	 * @return array|WP_Error
	 */
	public function update_email_settings( $input = array() ) {
		$input   = is_array( $input ) ? $input : array();
		$current = self::email_settings_now();
		$host    = self::store_host();
		$plan    = self::email_settings_plan( $input, $current, $host );

		if ( ! empty( $plan['errors'] ) ) {
			$lines = array();
			foreach ( $plan['errors'] as $field => $why ) {
				$lines[] = $field . ': ' . $why;
			}

			return new WP_Error( 'fkmcp_invalid_input', __( 'Nothing was saved. Fix these fields:', 'wp-marketing-automations-pro' ) . ' ' . implode( '; ', $lines ) );
		}

		if ( empty( $plan['changes'] ) ) {
			return new WP_Error( 'fkmcp_invalid_input', __( 'Nothing to change: pass at least one field with a value different from the current one (get-email-settings shows them).', 'wp-marketing-automations-pro' ) );
		}

		require_once __DIR__ . '/automation/class-fkmcp-review.php';

		$new      = wp_list_pluck( $plan['changes'], 'new' );
		$hash     = hash( 'sha256', (string) wp_json_encode( $new ) );
		$revision = 'email-settings:' . substr( hash( 'sha256', (string) wp_json_encode( $current ) ), 0, 16 ); // stale when someone else saves meanwhile
		$changes  = array();
		foreach ( $plan['changes'] as $field => $change ) {
			$changes[] = array( 'field' => $field, 'label' => self::email_settings_label( $field ) ) + $change;
		}
		$must_type = array();
		foreach ( array( 'from_email' => 'confirm_from_email', 'reply_to' => 'confirm_reply_to' ) as $field => $key ) {
			if ( isset( $plan['changes'][ $field ] ) ) {
				$must_type[ $field ] = $key;
			}
		}

		if ( isset( $input['mode'] ) && 'review' === $input['mode'] ) {
			$issued = FKMCP_Review::issue( $hash, array_keys( $plan['changes'] ), 0, $revision );

			return array(
				'result'         => 'review',
				'changes'        => $changes,
				'warnings'       => $plan['warnings'],
				'review_token'   => $issued['token'],
				'expires'        => $issued['expires'],
				'confirm_needed' => array_values( $must_type ),
				'settings_url'   => self::email_settings_url(),
			);
		}

		if ( empty( $input['review_token'] ) ) {
			return new WP_Error( 'fkmcp_review_required', __( 'Review first: call with mode "review", show the user every change and warning, and after their yes send the same values with review_token and confirmed_fields.', 'wp-marketing-automations-pro' ) );
		}

		$check = FKMCP_Review::check( $input['review_token'], $hash, isset( $input['confirmed_fields'] ) ? $input['confirmed_fields'] : array(), 0, $revision );
		if ( is_wp_error( $check ) ) {
			return 'fkmcp_review_required' === $check->get_error_code()
				/* translators: %s: field names */
				? new WP_Error( 'fkmcp_review_required', sprintf( __( 'Confirm every changed field with the user and list it in confirmed_fields. Still to confirm: %s.', 'wp-marketing-automations-pro' ), implode( ', ', array_diff( array_keys( $plan['changes'] ), (array) ( isset( $input['confirmed_fields'] ) ? $input['confirmed_fields'] : array() ) ) ) ) )
				: new WP_Error( 'fkmcp_review_stale', __( 'The review no longer matches: the values differ from the reviewed ones, the settings changed since, or the token expired or was used. Run mode "review" again and confirm the new sheet.', 'wp-marketing-automations-pro' ) );
		}

		foreach ( $must_type as $field => $key ) {
			if ( ! isset( $input[ $key ] ) || ! is_string( $input[ $key ] ) || trim( $input[ $key ] ) !== $plan['changes'][ $field ]['new'] ) {
				/* translators: 1: input key, 2: field name */
				return new WP_Error( 'fkmcp_confirm_required', sprintf( __( 'Ask the user to type the new address and send it as %1$s; it must match the new %2$s exactly. Nothing was saved.', 'wp-marketing-automations-pro' ), $key, $field ) );
			}
		}

		if ( ! FKMCP_Review::consume( $input['review_token'] ) ) {
			return new WP_Error( 'fkmcp_review_stale', __( 'This review was already used. Run mode "review" again.', 'wp-marketing-automations-pro' ) );
		}

		$old  = get_option( 'bwfan_global_settings', array() );
		$old  = is_array( $old ) ? $old : array();
		$save = $old; // only the reviewed keys change; every other setting stays as stored
		foreach ( $new as $field => $value ) {
			$save[ self::EMAIL_SETTINGS_FIELDS[ $field ] ] = $value;
		}
		update_option( 'bwfan_global_settings', $save, true );
		do_action( 'bwfan_after_save_global_settings', $old, $save ); // the same hook the Settings screen's Save fires

		return array(
			'result'       => 'updated',
			'changes'      => $changes,
			'warnings'     => $plan['warnings'],
			'settings_url' => self::email_settings_url(),
		);
	}

	/**
	 * The field rules, with no side effects: what would change, what is refused and why, and what to warn about.
	 *
	 * @param array  $input   tool input.
	 * @param array  $current bwfan_global_settings as emails use it (saved values over defaults).
	 * @param string $host    the store's host, for the From domain check.
	 *
	 * @return array{changes: array, errors: array, warnings: array}
	 */
	public static function email_settings_plan( array $input, array $current, $host ) {
		$changes  = array();
		$errors   = array();
		$warnings = array();

		foreach ( $input as $field => $value ) {
			if ( in_array( $field, self::EMAIL_SETTINGS_CONTROLS, true ) ) {
				continue;
			}
			if ( ! isset( self::EMAIL_SETTINGS_FIELDS[ $field ] ) ) {
				$errors[ $field ] = __( 'not a field this tool changes (bounce handling, sending limits and the email provider are changed in Settings)', 'wp-marketing-automations-pro' );
				continue;
			}
			if ( ! is_string( $value ) ) {
				$errors[ $field ] = __( 'must be text', 'wp-marketing-automations-pro' );
				continue;
			}

			$value = trim( $value );
			$why   = self::email_settings_refusal( $field, $value );
			if ( null !== $why ) {
				$errors[ $field ] = $why;
				continue;
			}
			if ( 'footer' === $field ) {
				$value = wp_kses_post( $value );
			} elseif ( in_array( $field, array( 'from_email', 'reply_to' ), true ) ) {
				$value = sanitize_email( $value );
			}

			$key = self::EMAIL_SETTINGS_FIELDS[ $field ];
			$was = isset( $current[ $key ] ) && is_scalar( $current[ $key ] ) ? trim( (string) $current[ $key ] ) : '';
			if ( $value !== $was ) {
				$changes[ $field ] = array( 'old' => $was, 'new' => $value );
			}
		}

		if ( isset( $changes['from_email'] ) ) {
			$domain = strtolower( (string) substr( strrchr( $changes['from_email']['new'], '@' ), 1 ) );
			$host   = strtolower( preg_replace( '/^www\./', '', (string) $host ) );
			if ( in_array( $domain, self::FREE_MAILBOXES, true ) ) {
				/* translators: %s: email domain */
				$warnings[] = sprintf( __( 'From is a free mailbox (%s): mail providers often send these to spam or reject them, because only that provider may send as its addresses. Use an address on your own domain.', 'wp-marketing-automations-pro' ), $domain );
			} elseif ( '' !== $host && $domain !== $host && ! self::ends_with( $domain, '.' . $host ) && ! self::ends_with( $host, '.' . $domain ) ) {
				/* translators: 1: email domain, 2: store domain */
				$warnings[] = sprintf( __( 'From is on %1$s, not the store domain %2$s: make sure that domain lets this site send for it (SPF/DKIM), or emails may land in spam.', 'wp-marketing-automations-pro' ), $domain, $host );
			}
		}

		if ( isset( $changes['footer'] ) ) {
			$address_key = self::EMAIL_SETTINGS_FIELDS['business_address'];
			$address     = isset( $changes['business_address'] ) ? $changes['business_address']['new'] : ( isset( $current[ $address_key ] ) ? trim( (string) $current[ $address_key ] ) : '' );
			$footer      = $changes['footer']['new'];
			if ( false === strpos( $footer, '{{business_address}}' ) && ( '' === $address || false === strpos( $footer, $address ) ) ) {
				$warnings[] = __( 'The footer shows no business address: anti-spam laws require a postal address in every marketing email. Add {{business_address}}.', 'wp-marketing-automations-pro' );
			}
		}

		return array(
			'changes'  => $changes,
			'errors'   => $errors,
			'warnings' => $warnings,
		);
	}

	/** Why a trimmed value is refused, or null. */
	private static function email_settings_refusal( $field, $value ) {
		$length = function_exists( 'mb_strlen' ) ? mb_strlen( $value ) : strlen( $value );

		if ( 'footer' === $field ) {
			if ( $length > 5000 ) {
				return __( 'at most 5000 characters', 'wp-marketing-automations-pro' );
			}

			return false === strpos( $value, '{{unsubscribe_link}}' ) ? __( 'must keep {{unsubscribe_link}}: every marketing email needs a way to unsubscribe', 'wp-marketing-automations-pro' ) : null;
		}

		if ( in_array( $field, array( 'from_email', 'reply_to' ), true ) ) {
			return is_email( $value ) && sanitize_email( $value ) === $value ? null : __( 'not a valid email address', 'wp-marketing-automations-pro' );
		}

		$max = 'business_address' === $field ? 250 : 100;
		if ( 0 === $length || $length > $max ) {
			/* translators: %d: maximum characters */
			return sprintf( __( 'must be 1-%d characters', 'wp-marketing-automations-pro' ), $max );
		}
		if ( preg_match( '/[\r\n<>]|{{/', $value ) ) {
			return __( 'plain text only: no line breaks, HTML or merge tags', 'wp-marketing-automations-pro' );
		}

		return null;
	}

	/** The six values as emails use them now: saved settings over Lite's defaults (From falls back to the WooCommerce or admin email). */
	private static function email_settings_now() {
		$all = class_exists( 'BWFAN_Common' ) && method_exists( 'BWFAN_Common', 'get_global_settings' ) ? BWFAN_Common::get_global_settings() : get_option( 'bwfan_global_settings', array() );

		return is_array( $all ) ? array_intersect_key( $all, array_flip( self::EMAIL_SETTINGS_FIELDS ) ) : array();
	}

	private static function email_settings_label( $field ) {
		$labels = array(
			'business_name'    => __( 'Business Name', 'wp-marketing-automations-pro' ),
			'business_address' => __( 'Business Address', 'wp-marketing-automations-pro' ),
			'from_name'        => __( 'From Name', 'wp-marketing-automations-pro' ),
			'from_email'       => __( 'From Email', 'wp-marketing-automations-pro' ),
			'reply_to'         => __( 'Reply To Email', 'wp-marketing-automations-pro' ),
			'footer'           => __( 'Footer Text', 'wp-marketing-automations-pro' ),
		);

		return $labels[ $field ];
	}

	private static function email_settings_url() {
		return BWFAN_MCP_Links::app( 'autonami', '/settings' );
	}

	private static function store_host() {
		return (string) wp_parse_url( home_url(), PHP_URL_HOST );
	}

	private static function ends_with( $haystack, $needle ) {
		return '' !== $needle && substr( $haystack, -strlen( $needle ) ) === $needle;
	}
}
