<?php

defined( 'ABSPATH' ) || exit;

/**
 * React-Flow nodes and links in the shape the builder's dispatcher makes
 * them (verified against recipe #38). Positions are placeholders: the
 * builder re-runs ELK layout on every load.
 */
class FKMCP_Graph_Builder {
	private $next = 3;

	public function line( array $items ) {
		$nodes = array(
			array( 'id' => 'start', 'type' => 'start', 'data' => array(), 'hidden' => false, 'position' => array( 'x' => 250, 'y' => 25 ) ),
			array( 'id' => 'end', 'type' => 'end', 'data' => array(), 'hidden' => false, 'position' => array( 'x' => 250, 'y' => 600 ) ),
		);
		$links    = array();
		$node_ids = array();
		$prev     = 'start';
		$prev_hid = false;

		foreach ( array_values( $items ) as $i => $item ) {
			$id           = (string) $this->next++;
			$node_ids[ $i ] = $id;
			$nodes[]      = array(
				'id'          => $id,
				'type'        => (string) $item['node'],
				'stepId'      => (int) $item['temp'],
				'step_status' => 1,
				'hidden'      => false,
				'data'        => array(),
				'position'    => array( 'x' => 0, 'y' => 0 ),
			);
			$links[]      = self::link( $prev . '-' . $id, $prev, $id, $prev_hid );
			$prev         = $id;
			$prev_hid     = 'exit' === $item['node'];
		}

		$links[] = self::link( $prev_hid ? $prev . '-end' : 'endlink', $prev, 'end', $prev_hid );

		return array(
			'steps'      => $nodes,
			'links'      => $links,
			'count'      => (string) ( $this->next - 1 < 2 ? 2 : $this->next - 1 ),
			'node_ids'   => array_values( $node_ids ),
			'start_temp' => empty( $items ) ? 0 : (int) $items[0]['temp'],
		);
	}

	/** @var array[] tree(): nodes and links being built */
	private $t_nodes = array();

	private $t_links = array();

	/** @var string[] tree(): flat index => node id */
	private $t_ids = array();

	/** @var array tree(): fork node id => join node id | 'end' */
	private $t_joins = array();

	private $t_endlink = false;

	/**
	 * The builder's graph for a tree of steps, as the React dispatcher builds
	 * it (spec §15.2): a condition's yes/no pseudo-nodes and edges, a
	 * branches step's chips and edges, a split's path chips (each path burns
	 * a node id) and edges, hidden links out of exits and jumps, and every
	 * lane linking on to its fork's join. For a tree with no forks this is
	 * exactly line()'s output.
	 *
	 * @param FKMCP_Step_Tree $tree  The flattened definition.
	 * @param array[]         $nodes i => {node, temp, branches?: [{id, name}]}.
	 *
	 * @return array {steps, links, count, node_ids, start_temp, joins}
	 */
	public function tree( FKMCP_Step_Tree $tree, array $nodes ) {
		$this->t_nodes   = array(
			array( 'id' => 'start', 'type' => 'start', 'data' => array(), 'hidden' => false, 'position' => array( 'x' => 250, 'y' => 25 ) ),
			array( 'id' => 'end', 'type' => 'end', 'data' => array(), 'hidden' => false, 'position' => array( 'x' => 250, 'y' => 600 ) ),
		);
		$this->t_links   = array();
		$this->t_ids     = array();
		$this->t_joins   = array();
		$this->t_endlink = false;

		foreach ( array_keys( $tree->items ) as $i ) {
			$this->t_ids[ $i ] = (string) $this->next++;

			// A split burns one id per path, as the builder's setSplitNodePath() does (SA:1567-1631);
			// the chips themselves are named {n}-path-{k} and use none of them.
			if ( isset( $nodes[ $i ]['node'] ) && 'split' === $nodes[ $i ]['node'] && isset( $tree->lanes[ $i ] ) ) {
				$this->next += count( $tree->lanes[ $i ] );
			}
		}

		$top = $tree->lists[0]['items'];
		$this->out( 'start', empty( $top ) ? 'end' : $this->t_ids[ $top[0] ], false );
		$this->emit( $tree, $nodes, 0, 'end' );

		// Chips first (spec §15.2): Lite's get_steps_node_id() keeps the LAST node whose
		// intval( stepId ) equals a fork's row id, so a chip ("5-branch-…", "5-path-1")
		// listed after a real step with row id 5 shadows it, and that fork's merger becomes 0 —
		// which ends a contact's journey on a disabled fork or a site without Pro. With every
		// chip listed before every real step, the real step is always the last match. Node
		// order means nothing else to the runtime (it routes by id).
		$chips = array();
		$rest  = array();
		foreach ( array_slice( $this->t_nodes, 2 ) as $node ) {
			if ( in_array( $node['type'], array( 'branchpath', 'splitpath' ), true ) ) {
				$chips[] = $node;
			} else {
				$rest[] = $node;
			}
		}
		$this->t_nodes = array_merge( array_slice( $this->t_nodes, 0, 2 ), $chips, $rest );

		return array(
			'steps'      => $this->t_nodes,
			'links'      => $this->t_links,
			'count'      => (string) max( 2, $this->next - 1 ),
			'node_ids'   => array_values( $this->t_ids ),
			'start_temp' => empty( $top ) ? 0 : (int) $nodes[ $top[0] ]['temp'],
			'joins'      => $this->t_joins,
		);
	}

	private function emit( FKMCP_Step_Tree $tree, array $nodes, $lid, $after ) {
		$items = $tree->lists[ $lid ]['items'];

		foreach ( $items as $k => $i ) {
			$id   = $this->t_ids[ $i ];
			$next = isset( $items[ $k + 1 ] ) ? $this->t_ids[ $items[ $k + 1 ] ] : $after;

			$this->t_nodes[] = array(
				'id'          => $id,
				'type'        => (string) $nodes[ $i ]['node'],
				'stepId'      => (int) $nodes[ $i ]['temp'],
				'step_status' => 1,
				'hidden'      => false,
				'data'        => array(),
				'position'    => array( 'x' => 0, 'y' => 0 ),
			);

			if ( isset( $tree->lanes[ $i ] ) ) {
				$this->fork( $tree, $nodes, $i, $next );
				continue;
			}

			$this->out( $id, $next, in_array( $nodes[ $i ]['node'], array( 'exit', 'jump' ), true ) );
		}
	}

	private function fork( FKMCP_Step_Tree $tree, array $nodes, $i, $join ) {
		$n                   = $this->t_ids[ $i ];
		$lanes               = $tree->lanes[ $i ];
		$this->t_joins[ $n ] = $join;

		if ( 'split' === $nodes[ $i ]['node'] ) {
			$k = 0;
			foreach ( $lanes as $lid ) {
				++$k;
				$chip            = $n . '-path-' . $k;
				$this->t_nodes[] = array(
					'id'          => $chip,
					'type'        => 'splitpath',
					'stepId'      => $chip,
					'step_status' => 2,
					'hidden'      => false,
					'data'        => array( 'path' => $k ),
					'position'    => array( 'x' => 0, 'y' => 0 ),
				);
				$this->t_links[] = self::link( $n . '-indx-' . $k, $n, $chip, false, 'split-edge' );
				// The builder names the chip's link after its target when the path was created: the join (SA:1600-1606).
				$this->lane( $tree, $nodes, $lid, $chip, $join, 'split-' . $n . '-path-' . $k . '-target-' . $join );
			}

			return;
		}

		if ( 'conditional' === $nodes[ $i ]['node'] ) {
			$heads = array(
				'yes' => $n . 'yes',
				'no'  => $n . 'no',
			);

			foreach ( $heads as $dir => $head ) {
				$this->t_nodes[] = array(
					'id'             => $head,
					'sourcePosition' => 'bottom',
					'targetPosition' => 'top',
					'type'           => 'yesNoNode',
					'hidden'         => false,
					'position'       => array( 'x' => 0, 'y' => 0 ),
					'data'           => array(
						'direction' => $dir,
						'parent'    => $n,
					),
				);
			}

			// yes before no: the runtime's lost-result fallback follows the last fork edge.
			foreach ( $heads as $dir => $head ) {
				$this->t_links[] = self::link( $head . 'edge', $n, $head, false, $dir );
			}

			$k = 0;
			foreach ( $heads as $head ) {
				$this->lane( $tree, $nodes, $lanes[ $k++ ], $head, $join, null );
			}

			return;
		}

		$defs   = isset( $nodes[ $i ]['branches'] ) ? $nodes[ $i ]['branches'] : array();
		$defs[] = array(
			'id'   => 'else',
			'name' => __( 'Everyone Else', 'wp-marketing-automations-pro' ),
			'else' => true,
		);

		if ( count( $defs ) !== count( $lanes ) ) {
			throw new LogicException( 'branches lanes and branch ids are out of step' );
		}

		foreach ( $defs as $order => $def ) {
			$chip            = $n . '-branch-' . $def['id'];
			$this->t_nodes[] = array(
				'id'             => $chip,
				'type'           => 'branchpath',
				'stepId'         => $chip,
				'step_status'    => 2,
				'hidden'         => false,
				'sourcePosition' => 'bottom',
				'targetPosition' => 'top',
				'position'       => array( 'x' => 0, 'y' => 0 ),
				'data'           => array(
					'branchId' => (string) $def['id'],
					'name'     => (string) $def['name'],
					'isElse'   => ! empty( $def['else'] ),
					'parent'   => $n,
					'order'    => $order,
				),
			);
			$this->t_links[] = self::link( $n . '-branch-edge-' . $def['id'], $n, $chip, false, 'branches-edge' );
		}

		foreach ( $defs as $k => $def ) {
			$chip = $n . '-branch-' . $def['id'];
			$this->lane( $tree, $nodes, $lanes[ $k ], $chip, $join, $chip . '-target-end' );
		}
	}

	/** A lane: its head links to the lane's first step, or straight to the join when the lane is empty. */
	private function lane( FKMCP_Step_Tree $tree, array $nodes, $lid, $head, $join, $link_id ) {
		$items  = $tree->lists[ $lid ]['items'];
		$target = empty( $items ) ? $join : $this->t_ids[ $items[0] ];

		if ( null === $link_id ) {
			$this->out( $head, $target, false );
		} else {
			$this->t_links[] = self::link( $link_id, $head, $target, false );
		}

		$this->emit( $tree, $nodes, $lid, $join );
	}

	/** One outgoing link; the first visible link to end is 'endlink', as line() names it. */
	private function out( $source, $target, $hidden ) {
		if ( 'end' === $target && ! $hidden && ! $this->t_endlink ) {
			$this->t_endlink = true;
			$id              = 'endlink';
		} else {
			$id = $source . '-' . $target;
		}

		$this->t_links[] = self::link( $id, $source, $target, $hidden );
	}

	private static function link( $id, $source, $target, $hidden, $handle = '' ) {
		$link = array( 'id' => $id, 'source' => $source, 'target' => $target, 'label' => '', 'sourceHandle' => $handle, 'animated' => false );

		if ( $hidden ) {
			$link['isHidden'] = true;
		}

		return $link;
	}
}
