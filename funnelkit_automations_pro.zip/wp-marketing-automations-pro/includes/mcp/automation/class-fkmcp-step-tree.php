<?php

defined( 'ABSPATH' ) || exit;

/**
 * A definition's steps as one flat index space. Every step, however deeply it
 * sits inside condition, branches or split lanes, gets a flat index i in
 * pre-order (a fork, then each of its lanes in order, then whatever follows
 * the fork), its path the way errors print it (steps[2].yes[0]), and the list it lives in.
 * The definition builder validates and translates over that flat index, as M1
 * did; the lanes and joins stay here for the graph and for "does step a always
 * run before step b" questions (spec §15.2-§15.3).
 *
 * Only the tree's own shape is checked here: lane containers, nesting depth,
 * branch count and the total number of steps. Step contents are the builder's.
 */
class FKMCP_Step_Tree {
	/** Forks nested inside forks, at most (spec §0.1.2). */
	const DEPTH_MAX = 10;

	/** Branches per branches step: the builder's MAX_BRANCHES (branches.js:46). */
	const BRANCHES_MAX = 10;

	const FORKS = array( 'condition', 'branches', 'split' );

	/** Paths per split step: the builder offers 2 or 3 (split.js:50-63). */
	const SPLIT_PATHS_MAX = 3;

	/** @var array[] i => {step, path, type, list, pos, depth} */
	public $items = array();

	/** @var array[] list id => {owner: the fork's i, or -1 for the top level; lane; items: int[]} */
	public $lists = array();

	/** @var array[] fork i => its lane list ids, in lane order (yes, no | each branch, else) */
	public $lanes = array();

	/** @var array i => the jump's or date-wait skip's target: a flat index, or 'end'. Set by the builder once refs are known. */
	public $targets = array();

	public function set_target( $i, $target ) {
		$this->targets[ $i ] = $target;
	}

	private function __construct() {
	}

	/**
	 * @param array                   $steps  The definition's steps, already known to be a JSON list.
	 * @param int                     $max    The most steps allowed, counting every lane.
	 * @param FKMCP_Definition_Errors $errors Where shape problems go.
	 *
	 * @return self|null Null after adding an error when the tree's own shape is wrong.
	 */
	public static function flatten( array $steps, $max, FKMCP_Definition_Errors $errors ) {
		$tree = new self();

		return $tree->walk( $steps, 'top', -1, 'steps', 0, $max, $errors ) ? $tree : null;
	}

	public static function is_list( $value ) {
		if ( ! is_array( $value ) ) {
			return false;
		}

		return empty( $value ) || array_keys( $value ) === range( 0, count( $value ) - 1 );
	}

	/** The step a contact reaches after $i: the next one in its list, or that list's join. */
	public function next_of( $i ) {
		$list = $this->items[ $i ]['list'];
		$pos  = array_search( $i, $this->lists[ $list ]['items'], true );

		if ( isset( $this->lists[ $list ]['items'][ $pos + 1 ] ) ) {
			return $this->lists[ $list ]['items'][ $pos + 1 ];
		}

		return $this->join_of_list( $list );
	}

	/** Where a lane rejoins: whatever follows its fork, recursively; 'end' at the top level. */
	public function join_of_list( $lid ) {
		$owner = $this->lists[ $lid ]['owner'];

		return $owner < 0 ? 'end' : $this->next_of( $owner );
	}

	/** Where fork $i's lanes meet again: the builder's merger point. */
	public function join_of( $i ) {
		return $this->next_of( $i );
	}

	/**
	 * The steps (or 'end') a contact can move to straight after $i. An exit ends
	 * the run; a jump goes only to its target; a wait with a skip may also go to
	 * the skip's target (when its date has passed); a fork goes to each lane head.
	 */
	public function successors( $i ) {
		$type = $this->items[ $i ]['type'];

		if ( 'exit' === $type ) {
			return array();
		}

		if ( 'jump' === $type ) {
			$target = isset( $this->targets[ $i ] ) ? $this->targets[ $i ] : 'end';

			return 'end' === $target ? array() : array( $target );
		}

		$out = array();

		if ( isset( $this->lanes[ $i ] ) ) {
			foreach ( $this->lanes[ $i ] as $lid ) {
				$out[] = empty( $this->lists[ $lid ]['items'] ) ? $this->join_of( $i ) : $this->lists[ $lid ]['items'][0];
			}
		} else {
			$out[] = $this->next_of( $i );
			if ( isset( $this->targets[ $i ] ) && 'end' !== $this->targets[ $i ] ) {
				$out[] = $this->targets[ $i ];
			}
		}

		// Strict de-duplication: on PHP 7.4, 0 == 'end' is true, so array_unique() would merge them.
		$unique = array();
		foreach ( $out as $s ) {
			if ( ! in_array( $s, $unique, true ) ) {
				$unique[] = $s;
			}
		}

		return $unique;
	}

	/**
	 * True when a contact at $from can reach $to without passing through a wait:
	 * the loop a jump or skip from $to back to $from would spin with no pause (no
	 * loop counter exists at runtime). A delay wait is a pause on its next path,
	 * but a skip edge is not: once a date has passed, the runtime moves to the
	 * skip target at once (Lite class-bwfan-automation-controller.php:185-194,
	 * 713-765), and a fixed-date wait is no pause at all. See unpaused(); $from
	 * follows the same rule.
	 */
	public function reaches_without_wait( $from, $to ) {
		$seen  = array( $from => true );
		$queue = array( $from );

		while ( ! empty( $queue ) ) {
			$n = array_shift( $queue );

			foreach ( $this->unpaused( $n ) as $s ) {
				if ( 'end' === $s ) {
					continue;
				}
				if ( $s === $to ) {
					return true;
				}
				if ( isset( $seen[ $s ] ) ) {
					continue;
				}
				$seen[ $s ] = true;
				$queue[]    = $s;
			}
		}

		return false;
	}

	/**
	 * Where a contact goes straight after $i with no pause. Only a delay wait (a
	 * relative duration of at least a minute; no kind means delay) pauses, and
	 * only on its next path. A fixed-date wait stops pausing once its date has
	 * passed (Lite process_wait() sets a past e_time), so it is followed fully.
	 */
	private function unpaused( $i ) {
		if ( 'wait' !== $this->items[ $i ]['type'] ) {
			return $this->successors( $i );
		}

		$step = $this->items[ $i ]['step'];
		if ( 'delay' !== ( isset( $step['kind'] ) ? $step['kind'] : 'delay' ) ) {
			return $this->successors( $i );
		}

		return isset( $this->targets[ $i ] ) ? array( $this->targets[ $i ] ) : array();
	}

	/**
	 * True when step $a runs before step $b on every path: $a sits earlier in
	 * $b's own list, or in one of the lists enclosing it.
	 */
	public function always_before( $a, $b ) {
		$list = $this->items[ $a ]['list'];
		$pos  = $this->items[ $a ]['pos'];

		for ( $n = $b; $n >= 0; $n = $this->lists[ $this->items[ $n ]['list'] ]['owner'] ) {
			if ( $n !== $b && $n === $a ) {
				return true;
			}
			if ( $this->items[ $n ]['list'] === $list ) {
				return $pos < $this->items[ $n ]['pos'];
			}
		}

		return false;
	}

	private function walk( array $steps, $lane, $owner, $prefix, $depth, $max, FKMCP_Definition_Errors $errors, $in_split = false ) {
		$lid                 = count( $this->lists );
		$this->lists[ $lid ] = array(
			'owner' => $owner,
			'lane'  => $lane,
			'items' => array(),
		);

		if ( $owner >= 0 ) {
			$this->lanes[ $owner ][] = $lid;
		}

		foreach ( array_values( $steps ) as $pos => $step ) {
			if ( count( $this->items ) >= $max ) {
				/* translators: %d: maximum number of steps */
				$errors->add( 'steps', sprintf( __( 'has more than %d steps.', 'wp-marketing-automations-pro' ), $max ) );

				return false;
			}

			$i    = count( $this->items );
			$path = $prefix . '[' . $pos . ']';
			$type = is_array( $step ) && isset( $step['type'] ) && is_string( $step['type'] ) ? $step['type'] : null;

			$this->items[ $i ]              = array(
				'step'     => $step,
				'path'     => $path,
				'type'     => $type,
				'list'     => $lid,
				'pos'      => $pos,
				'depth'    => $depth,
				'in_split' => $in_split,
				'top'      => -1 === $owner,
			);
			$this->lists[ $lid ]['items'][] = $i;

			if ( ! in_array( $type, self::FORKS, true ) ) {
				continue;
			}

			if ( $depth >= self::DEPTH_MAX ) {
				/* translators: %d: maximum nesting depth */
				$errors->add( $path, sprintf( __( 'nests conditions, branches or splits more than %d deep.', 'wp-marketing-automations-pro' ), self::DEPTH_MAX ) );

				return false;
			}

			$this->lanes[ $i ] = array();
			$lanes             = self::lanes_of( $step, $path, $errors );

			if ( null === $lanes ) {
				return false;
			}

			foreach ( $lanes as $key => $lane_def ) {
				if ( ! $this->walk( $lane_def['steps'], $key, $i, $lane_def['path'], $depth + 1, $max, $errors, $in_split || 'split' === $type ) ) {
					return false;
				}
			}
		}

		return true;
	}

	/** A fork's lanes as {key => {path, steps}}; null after an error when one isn't a list. */
	private static function lanes_of( array $step, $path, FKMCP_Definition_Errors $errors ) {
		$lanes = array();

		if ( 'condition' === $step['type'] ) {
			foreach ( array( 'yes', 'no' ) as $key ) {
				$lanes[ $key ] = array(
					'path'  => $path . '.' . $key,
					'steps' => array_key_exists( $key, $step ) ? $step[ $key ] : array(),
				);
			}
		} elseif ( 'split' === $step['type'] ) {
			$paths = isset( $step['paths'] ) && self::is_list( $step['paths'] ) ? $step['paths'] : array();

			if ( count( $paths ) > self::SPLIT_PATHS_MAX ) {
				/* translators: %d: maximum number of split paths */
				$errors->add( $path . '.paths', sprintf( __( 'has more than %d paths.', 'wp-marketing-automations-pro' ), self::SPLIT_PATHS_MAX ) );

				return null;
			}

			foreach ( $paths as $k => $steps ) {
				$lanes[ 'p' . ( $k + 1 ) ] = array(
					'path'  => $path . '.paths[' . $k . ']',
					'steps' => $steps,
				);
			}
		} else {
			$branches = isset( $step['branches'] ) && self::is_list( $step['branches'] ) ? $step['branches'] : array();

			if ( count( $branches ) > self::BRANCHES_MAX ) {
				/* translators: %d: maximum number of branches */
				$errors->add( $path . '.branches', sprintf( __( 'has more than %d branches.', 'wp-marketing-automations-pro' ), self::BRANCHES_MAX ) );

				return null;
			}

			foreach ( $branches as $b => $branch ) {
				if ( is_array( $branch ) ) {
					$lanes[ 'b' . $b ] = array(
						'path'  => $path . '.branches[' . $b . '].steps',
						'steps' => array_key_exists( 'steps', $branch ) ? $branch['steps'] : array(),
					);
				}
			}

			$lanes['else'] = array(
				'path'  => $path . '.else',
				'steps' => array_key_exists( 'else', $step ) ? $step['else'] : array(),
			);
		}

		foreach ( $lanes as $lane ) {
			if ( ! self::is_list( $lane['steps'] ) ) {
				$errors->add( $lane['path'], __( 'must be a JSON list of steps.', 'wp-marketing-automations-pro' ) );

				return null;
			}
		}

		return $lanes;
	}
}
