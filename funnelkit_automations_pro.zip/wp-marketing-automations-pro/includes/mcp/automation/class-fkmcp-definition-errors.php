<?php

defined( 'ABSPATH' ) || exit;

/**
 * Every problem in a definition, found in one pass, so the agent can fix
 * them all in one round trip. Capped: past the cap the definition is not
 * worth listing further, and a longer list only burns the agent's context.
 *
 * The MCP adapter hands an agent only a WP_Error's message, never its data,
 * so the list travels inside the message.
 */
class FKMCP_Definition_Errors {
	const LIMIT = 20;

	const ALLOWED_LIMIT = 25;

	const MESSAGE_LIMIT = 300;

	/** One allowed entry, or a path, once scrubbed. */
	const TEXT_LIMIT = 200;

	/** The whole message an agent reads. */
	const TOTAL_LIMIT = 4000;

	/** Per-string ceiling on store text handed to the model. See untrust(). */
	const UNTRUSTED_MAX_CHARS = 500;

	/** How deep untrust() walks a stored payload before it stops descending. */
	const UNTRUSTED_MAX_DEPTH = 4;

	/** @var array<int, array{path: string, message: string, allowed?: array}> */
	private $errors = array();

	private $dropped = 0;

	/**
	 * The one choke point for every problem's text: much of it is site or
	 * third-party data (a worksheet name, an option label, a connector's
	 * message), so tags, line breaks and control characters never reach the
	 * agent, and nothing is unbounded (spec §0.1.3).
	 *
	 * @param string     $path    Where in the definition, e.g. steps[2].settings.tags[0].
	 * @param string     $message What is wrong, in one sentence.
	 * @param array|null $allowed Valid values the agent can pick from.
	 */
	public function add( $path, $message, ?array $allowed = null ) {
		if ( $this->full() ) {
			++$this->dropped;

			return;
		}

		$error = array(
			'path'    => self::clean( $path, self::TEXT_LIMIT ),
			'message' => self::clean( $message, self::MESSAGE_LIMIT ),
		);

		if ( null !== $allowed ) {
			$clean = array();
			foreach ( array_slice( array_values( $allowed ), 0, self::ALLOWED_LIMIT ) as $entry ) {
				$clean[] = is_scalar( $entry ) ? self::clean( $entry, self::TEXT_LIMIT ) : '';
			}
			$error['allowed'] = array_values( array_filter( $clean, 'strlen' ) );
		}

		$this->errors[] = $error;
	}

	/** Past the cap: further problems are only counted, so callers skip work (a closest() scan) for them. */
	public function full() {
		return count( $this->errors ) >= self::LIMIT;
	}

	/**
	 * Tags stripped, control/format/separator characters and whitespace runs
	 * collapsed to one space, capped. Shared by every definition class that
	 * shows site text to an agent (the translator's and special fields'
	 * fallback scrub too), so there is one definition of "clean".
	 */
	public static function clean( $text, $max ) {
		$text = wp_strip_all_tags( (string) $text );
		$flat = preg_replace( '/[\p{Cc}\p{Cf}\p{Z}\s]+/u', ' ', $text );

		// Invalid UTF-8 makes /u bail to null: fall back to a byte-level class, as BWFAN_MCP_Log::scrub() does.
		$text = null !== $flat ? $flat : preg_replace( '/[\x00-\x20\x7F]+/', ' ', $text );

		return mb_substr( trim( $text ), 0, (int) $max );
	}

	/**
	 * Store text on its way out to the model: markup stripped, length capped, objects dropped.
	 * The single implementation FKMCP_Pack_Pro::untrust() delegates to - moved here so it stays
	 * reachable where the pack itself isn't loaded (e.g. this file's unit harness).
	 *
	 * @param mixed $value
	 * @param int   $depth
	 *
	 * @return mixed
	 */
	public static function untrust( $value, $depth = 0 ) {
		if ( is_string( $value ) ) {
			// Breaks removed as well as tags: newlines are how planted text
			// fakes a boundary ("\n\nSYSTEM:") in a rendered tool result.
			return mb_substr( wp_strip_all_tags( $value, true ), 0, self::UNTRUSTED_MAX_CHARS );
		}

		if ( is_array( $value ) ) {
			// A payload nested deeper than this is a structure, not a message:
			// drop it rather than walk an arbitrary tree from the database.
			if ( $depth >= self::UNTRUSTED_MAX_DEPTH ) {
				return array();
			}

			$clean = array();

			foreach ( $value as $key => $item ) {
				$clean[ $key ] = self::untrust( $item, $depth + 1 );
			}

			return $clean;
		}

		// Objects have no place in an ability response; scalars pass as they are.
		return is_scalar( $value ) || null === $value ? $value : null;
	}

	public function has() {
		return ! empty( $this->errors );
	}

	public function count() {
		return count( $this->errors );
	}

	public function all() {
		return $this->errors;
	}

	public function to_wp_error() {
		$total = count( $this->errors ) + $this->dropped;
		$lines = array();
		$used  = 0;
		$shown = 0;

		foreach ( $this->errors as $error ) {
			$line = '- ' . $error['path'] . ': ' . $error['message'];

			// Allowed values are appended only while the line stays within MESSAGE_LIMIT; data keeps them all.
			if ( ! empty( $error['allowed'] ) ) {
				$tail = '';
				foreach ( $error['allowed'] as $entry ) {
					$next = ( '' === $tail ? ' Allowed: ' : $tail . ', ' ) . $entry;
					if ( mb_strlen( $line . $next . '.' ) > self::MESSAGE_LIMIT ) {
						break;
					}
					$tail = $next;
				}
				$line .= '' === $tail ? '' : $tail . '.';
			}

			$line = mb_substr( $line, 0, self::MESSAGE_LIMIT );

			// Leave room for the summary and the "and N more" line.
			if ( $used + mb_strlen( $line ) + 1 > self::TOTAL_LIMIT - 200 ) {
				break;
			}

			$lines[] = $line;
			$used   += mb_strlen( $line ) + 1;
			++$shown;
		}

		$more = $total - $shown;
		if ( $more > 0 ) {
			/* translators: %d: number of further problems not listed */
			$lines[] = sprintf( __( '- and %d more.', 'wp-marketing-automations-pro' ), $more );
		}

		$summary = sprintf(
			/* translators: %d: number of problems found in the definition */
			_n( 'The definition has %d problem. Nothing was created.', 'The definition has %d problems. Nothing was created.', $total, 'wp-marketing-automations-pro' ),
			$total
		);

		return new WP_Error(
			'fkmcp_invalid_input',
			mb_substr( $summary . "\n" . implode( "\n", $lines ), 0, self::TOTAL_LIMIT ),
			array( 'errors' => $this->errors, 'more' => $this->dropped )
		);
	}
}
