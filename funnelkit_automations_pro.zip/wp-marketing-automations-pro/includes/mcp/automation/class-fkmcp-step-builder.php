<?php

defined( 'ABSPATH' ) || exit;

/**
 * Step rows exactly as the builder saves them (verified against recipe #38
 * and lab draft #73). Each builder returns a row spec:
 * {type, action, sidebar, status, node, refs, warnings, transactional?}.
 */
class FKMCP_Step_Builder {
	const EMAIL_KEYS = array( 'type', 'ref', 'subject', 'body_html', 'preheader', 'format', 'to', 'transactional', 'template_id', 'keep', 'design', 'design_settings' );

	const WAIT_KEYS = array( 'type', 'ref', 'kind', 'delay', 'at_time', 'in_contact_timezone', 'weekdays', 'date', 'time', 'skip_to', 'field', 'offset', 'occurrence', 'merge_tag' );

	const FORMATS = array( 'rich' => 1, 'woocommerce' => 2, 'html' => 3 );

	const UNITS = array( 'min' => 60, 'hours' => 3600, 'days' => 86400, 'weeks' => 604800, 'months' => 2592000 );

	const KINDS = array( 'delay', 'until_date', 'until_field_date', 'until_merge_tag_date' );

	/** Why wp_sendemail can't be an action step: describe-automation-part and create give the same pointer. */
	public static function email_action_reason() {
		return sprintf(
			/* translators: %s: the email step's settings keys, e.g. design, subject, transactional, preheader, to */
			__( 'This is the builder\'s own email step, not a usable action here; use a step of type email instead. It takes %s: design is a block-editor design, the default. template_id (a saved template) is the alternative to design; body_html with format only when the user asked for a rich or HTML email.', 'wp-marketing-automations-pro' ),
			implode( ', ', array_values( array_intersect( array( 'design', 'subject', 'transactional', 'preheader', 'to' ), self::EMAIL_KEYS ) ) )
		);
	}

	/**
	 * The builder's own occurrence choices per date kind (Lite delay.js):
	 * field date getCustomOccurrence() :1506 (fulldatetime only for a date &
	 * time field), merge-tag date the variable panel's select :2330-2345.
	 */
	const OCCURRENCES = array(
		'until_field_date'     => array( 'fulldatetime', 'daymonth', 'daymonthyear' ),
		'until_merge_tag_date' => array( 'daymonth', 'daymonthyear' ),
	);

	/**
	 * Offset units, saved exactly as the builder saves them (Lite delay.js):
	 * getTimeDelayTypeOptions() :1546 adds minutes/hours only for fulldatetime;
	 * the merge-tag panel's select :2505-2520 offers days/weeks only.
	 */
	const OFFSET_UNITS = array( 'days', 'weeks' );

	const OFFSET_UNITS_FULLDATETIME = array( 'minutes', 'hours', 'days', 'weeks' );

	/** A ref, shared with FKMCP_Special_Fields (the dynamic-coupon "$step" marker) and FKMCP_Definition_Builder. */
	const REF_PATTERN = '/^[a-z0-9_-]{1,64}$/';

	const SUBJECT_MAX = 255;

	const BODY_MAX = 204800;

	const DESIGN_SETTINGS_MAX = 20480;

	// ─── email ────────────────────────────────────────────────────

	public static function email( array $step, $path, FKMCP_Definition_Errors $errors, array $ctx ) {
		$before = $errors->count();
		self::unknown_keys( $step, self::EMAIL_KEYS, $path, $errors );
		$tags = isset( $ctx['merge_tags'] ) ? $ctx['merge_tags'] : array();

		$tpl = null;
		if ( array_key_exists( 'template_id', $step ) ) {
			if ( array_key_exists( 'design', $step ) ) {
				// Checked first, before the template is loaded or re-validated: the same conflict the
				// design branch below reports, so design + template_id never pays for a lookup it refuses anyway.
				$errors->add( $path . '.design', __( 'Send design on its own: not with body_html, template_id or format.', 'wp-marketing-automations-pro' ) );
			} elseif ( array_key_exists( 'body_html', $step ) ) {
				$errors->add( $path . '.template_id', __( 'Send template_id or body_html, not both.', 'wp-marketing-automations-pro' ) );
			} elseif ( array_key_exists( 'format', $step ) ) {
				$errors->add( $path . '.format', __( 'is set by the template when template_id is used.', 'wp-marketing-automations-pro' ) );
			} elseif ( ! is_int( $step['template_id'] ) || ! isset( $ctx['templates'][ $step['template_id'] ] ) ) {
				$errors->add( $path . '.template_id', __( 'is not a saved email template (list-email-templates).', 'wp-marketing-automations-pro' ) );
			} else {
				$tpl = FKMCP_Email_Step::template_body( $step, $ctx['templates'][ $step['template_id'] ], $path, $errors, $ctx );
			}
			if ( null === $tpl ) {
				return null;
			}
			$step += array( 'subject' => $tpl['subject_default'], 'preheader' => $tpl['preheader_default'] );
			if ( 5 !== $tpl['mode'] ) {
				$step['body_html'] = $tpl['template'];
				$step['format']    = array_search( $tpl['mode'], self::FORMATS, true );
			}
		}

		if ( array_key_exists( 'design', $step ) ) {
			if ( array_key_exists( 'body_html', $step ) || array_key_exists( 'template_id', $step ) || array_key_exists( 'format', $step ) ) {
				$errors->add( $path . '.design', __( 'Send design on its own: not with body_html, template_id or format.', 'wp-marketing-automations-pro' ) );
			} elseif ( ! is_array( $step['design'] ) || array() === $step['design'] || strlen( (string) wp_json_encode( $step['design'] ) ) > self::BODY_MAX ) {
				$errors->add( $path . '.design', __( 'must be a non-empty block list (the tree create-email-template takes), at most 200 KB.', 'wp-marketing-automations-pro' ) );
			} elseif ( array_key_exists( 'design_settings', $step ) && ( ! is_array( $step['design_settings'] ) || strlen( (string) wp_json_encode( $step['design_settings'] ) ) > self::DESIGN_SETTINGS_MAX ) ) {
				$errors->add( $path . '.design_settings', __( 'must be an object of design settings, at most 20 KB.', 'wp-marketing-automations-pro' ) );
			} else {
				$tpl = FKMCP_Email_Step::design_body( $step, $path, $errors, $ctx );
			}
			if ( null === $tpl ) {
				return null;
			}
		} elseif ( array_key_exists( 'design_settings', $step ) ) {
			$errors->add( $path . '.design_settings', __( 'only goes with design.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		if ( null === $tpl && ! array_key_exists( 'body_html', $step ) ) {
			$errors->add( $path, __( 'needs design (block editor, the default), template_id (a saved template), or body_html with format.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$subject = isset( $step['subject'] ) && is_string( $step['subject'] ) ? trim( $step['subject'] ) : '';
		if ( '' === $subject || mb_strlen( $subject ) > self::SUBJECT_MAX ) {
			/* translators: %d: maximum length */
			$errors->add( $path . '.subject', sprintf( __( 'is required, at most %d characters.', 'wp-marketing-automations-pro' ), self::SUBJECT_MAX ) );
		} else {
			FKMCP_Field_Translator::check_merge_tags( $subject, $tags, $path . '.subject', $errors );
		}

		// A mode 1-3 template's body and format were not sent by the agent: report their problems at template_id.
		$body_path = null === $tpl ? $path . '.body_html' : $path . '.template_id';

		if ( null === $tpl || 5 !== $tpl['mode'] ) {
			$body = isset( $step['body_html'] ) && is_string( $step['body_html'] ) ? $step['body_html'] : '';
			if ( '' === trim( $body ) || strlen( $body ) > self::BODY_MAX ) {
				$errors->add(
					$body_path,
					null === $tpl
						/* translators: %d: maximum size in bytes */
						? sprintf( __( 'is required, at most %d bytes.', 'wp-marketing-automations-pro' ), self::BODY_MAX )
						/* translators: %d: maximum size in bytes */
						: sprintf( __( 'the template\'s body is empty or larger than %d bytes.', 'wp-marketing-automations-pro' ), self::BODY_MAX )
				);
			} else {
				FKMCP_Field_Translator::check_merge_tags( $body, $tags, $body_path, $errors );
			}
		} else {
			$body = '';
		}

		$preheader = isset( $step['preheader'] ) ? $step['preheader'] : '';
		if ( ! is_string( $preheader ) || mb_strlen( $preheader ) > self::SUBJECT_MAX ) {
			$errors->add( $path . '.preheader', __( 'must be text of at most 255 characters.', 'wp-marketing-automations-pro' ) );
			$preheader = '';
		} else {
			FKMCP_Field_Translator::check_merge_tags( $preheader, $tags, $path . '.preheader', $errors );
		}

		if ( ! isset( $step['transactional'] ) || ! is_bool( $step['transactional'] ) ) {
			$errors->add( $path . '.transactional', __( 'is required: true for order, account or service notices (sent even to unsubscribed contacts), false for marketing (skips unsubscribed contacts, needs the unsubscribe footer).', 'wp-marketing-automations-pro' ) );
		}
		$transactional = ! empty( $step['transactional'] );

		// Agent-sent body_html needs an explicit format (block is the default); a mode 1-3 template's
		// body_html (set above from template_id) already carries its own format, so this never fires for it.
		if ( array_key_exists( 'body_html', $step ) && ! isset( $step['format'] ) ) {
			$errors->add( $path . '.format', __( 'is required with body_html. Emails are designed in the block editor by default: send design instead. Use body_html with format rich, html or woocommerce only when the user asked for a rich-text or HTML email.', 'wp-marketing-automations-pro' ) );
		}
		$format = isset( $step['format'] ) ? $step['format'] : 'rich';
		if ( ! isset( self::FORMATS[ $format ] ) || ( 'woocommerce' === $format && empty( $ctx['woocommerce'] ) ) ) {
			if ( null !== $tpl ) {
				$errors->add( $path . '.template_id', __( 'is a WooCommerce email template, and WooCommerce is not active.', 'wp-marketing-automations-pro' ) );
			} else {
				$errors->add( $path . '.format', __( 'must be rich, html, or woocommerce (only with WooCommerce active).', 'wp-marketing-automations-pro' ), empty( $ctx['woocommerce'] ) ? array( 'rich', 'html' ) : array_keys( self::FORMATS ) );
			}
			$format = 'rich';
		}

		$to = self::recipients( isset( $step['to'] ) ? $step['to'] : '{{contact_email}}', $tags, $path . '.to', $errors );

		if ( $errors->count() > $before ) {
			return null;
		}

		$template = 'html' === $format ? wp_kses( $body, self::email_html() ) : wp_kses_post( $body );
		$warnings = array();
		$designed = null !== $tpl && 5 === $tpl['mode'];

		// Lite's send path html_entity_decode()s the whole body (class-bwfan-wp-sendemail.php:609,646), so kses
		// keeping &lt;script&gt; as text is not enough. Every "<" left here opens a tag kses accepted (a
		// whole-document email's <style> too) and kses drops any other: blank those, and read the rest - what
		// decoding can still turn into markup - with the design validator's own check. I &lt;3 you passes.
		if ( ! $designed ) {
			if ( ! class_exists( 'BWFCRM_Email_Design_Tree', false ) ) {
				require_once BWFAN_PRO_PLUGIN_DIR . '/crm/includes/block-editor/email-design/class-bwfcrm-email-design-tree.php'; // one class, no side effects
			}
			if ( BWFCRM_Email_Design_Tree::forbidden_markup( str_replace( '<', ' ', $template ) ) ) {
				$errors->add( $body_path, __( 'holds entity-encoded markup (a script, style, frame or form tag, an event handler, or a javascript:, vbscript: or data: link) that becomes live when the email is sent; remove it.', 'wp-marketing-automations-pro' ) );

				return null;
			}
		}

		if ( ! $designed && ! $transactional && false === strpos( $template, '{{mail_footer' ) && ! ( false !== strpos( $template, 'unsubscribe_link' ) && false !== strpos( $template, 'business_name' ) && false !== strpos( $template, 'business_address' ) ) ) {
			$template  .= "\n<p>{{mail_footer}}</p>";
			$warnings[] = __( 'This marketing email had no unsubscribe footer, so {{mail_footer}} was added at the end.', 'wp-marketing-automations-pro' );
		}

		if ( null !== $tpl ) {
			$warnings = array_merge( $warnings, $tpl['warnings'] );
		}

		$data = array(
			'preheader'          => sanitize_text_field( $preheader ),
			'utmEnabled'         => false,
			'utm'                => array( 'source' => 'Newsletter', 'medium' => 'email', 'name' => '', 'content' => '', 'term' => '' ),
			'isTransactional'    => $transactional,
			'overrideSenderInfo' => false,
		);
		if ( null !== $tpl && null !== $tpl['ref'] ) {
			$data['template_ref'] = $tpl['ref'];
		}
		if ( $designed ) {
			$data['block'] = $tpl['block'];
		}

		return array(
			'type'          => 2,
			'action'        => array( 'action' => 'wp_sendemail', 'intergration' => 'wp' ),
			'sidebar'       => array(
				'bwfan_email_to'   => $to,
				'bwfan_email_data' => array(
					'subject'  => sanitize_text_field( $subject ),
					'data'     => $data,
					'mode'     => $designed ? 5 : self::FORMATS[ $format ],
					'template' => $designed ? $tpl['template'] : $template,
				),
			),
			'status'        => 1,
			'node'          => 'action',
			'refs'          => array(),
			'warnings'      => $warnings,
			'transactional' => $transactional,
			'designed'      => $designed,
			'template_id'   => null !== $tpl && null !== $tpl['ref'] ? $tpl['ref']['id'] : null,
		);
	}

	private static function recipients( $to, array $tags, $path, FKMCP_Definition_Errors $errors ) {
		if ( ! is_string( $to ) || strlen( $to ) > 500 ) {
			$errors->add( $path, __( 'must be a comma list of emails or merge tags.', 'wp-marketing-automations-pro' ) );

			return '';
		}

		$parts = array_filter( array_map( 'trim', explode( ',', $to ) ), 'strlen' );
		if ( empty( $parts ) || count( $parts ) > 10 ) {
			$errors->add( $path, __( 'must name 1 to 10 recipients.', 'wp-marketing-automations-pro' ) );

			return '';
		}

		foreach ( $parts as $part ) {
			if ( preg_match( '/^\{\{[^{}]+\}\}$/', $part ) ) {
				FKMCP_Field_Translator::check_merge_tags( $part, $tags, $path, $errors );
			} elseif ( ! is_email( $part ) ) {
				/* translators: %s: the invalid entry */
				$errors->add( $path, sprintf( __( '"%s" is not an email address or a merge tag.', 'wp-marketing-automations-pro' ), mb_substr( wp_strip_all_tags( $part ), 0, 80 ) ) );
			}
		}

		return implode( ',', $parts );
	}

	/** Post HTML plus what whole-document email HTML needs; never script, iframe, handlers or meta (a refresh meta redirects). */
	public static function email_html() {
		$allowed = wp_kses_allowed_html( 'post' );
		$attrs   = array( 'style' => true, 'class' => true, 'id' => true, 'align' => true, 'valign' => true, 'width' => true, 'height' => true, 'bgcolor' => true, 'border' => true, 'cellpadding' => true, 'cellspacing' => true, 'role' => true, 'dir' => true, 'lang' => true );

		foreach ( array( 'html', 'head', 'body', 'title', 'center', 'table', 'thead', 'tbody', 'tfoot', 'tr', 'td', 'th', 'div', 'span', 'p', 'img', 'a', 'font' ) as $tag ) {
			$allowed[ $tag ] = array_merge( isset( $allowed[ $tag ] ) ? $allowed[ $tag ] : array(), $attrs );
		}

		$allowed['style'] = array( 'type' => true, 'media' => true );
		$allowed['img']  += array( 'src' => true, 'alt' => true );
		$allowed['a']    += array( 'href' => true, 'target' => true, 'rel' => true, 'title' => true );

		return $allowed;
	}

	// ─── wait ─────────────────────────────────────────────────────

	public static function wait( array $step, $path, FKMCP_Definition_Errors $errors, array $ctx ) {
		$before = $errors->count();
		self::unknown_keys( $step, self::WAIT_KEYS, $path, $errors );
		$kind = isset( $step['kind'] ) ? $step['kind'] : 'delay';

		if ( ! in_array( $kind, self::KINDS, true ) ) {
			$errors->add( $path . '.kind', __( 'is not a wait kind.', 'wp-marketing-automations-pro' ), self::KINDS );

			return null;
		}

		$refs = array();
		$data = null;

		switch ( $kind ) {
			case 'delay':
				$data = self::delay( $step, $path, $errors );
				break;
			case 'until_date':
				$data = self::until_date( $step, $path, $errors, $refs );
				break;
			case 'until_field_date':
			case 'until_merge_tag_date':
				$data = self::until_dynamic( $kind, $step, $path, $errors, $ctx, $refs );
				break;
		}

		if ( $errors->count() > $before || null === $data ) {
			return null;
		}

		return array(
			'type'     => 1,
			'action'   => null,
			'sidebar'  => array( 'type' => array_search( $kind, self::KINDS, true ) + 1, 'data' => $data ),
			'status'   => 1,
			'node'     => 'wait',
			'refs'     => $refs,
			'warnings' => array(),
		);
	}

	private static function delay( array $step, $path, FKMCP_Definition_Errors $errors ) {
		$delay = isset( $step['delay'] ) && is_array( $step['delay'] ) ? $step['delay'] : array();
		$value = isset( $delay['value'] ) ? $delay['value'] : null;
		$unit  = isset( $delay['unit'] ) ? $delay['unit'] : '';

		if ( ! is_int( $value ) || $value < 1 || ! isset( self::UNITS[ $unit ] ) ) {
			$errors->add( $path . '.delay', __( 'must be {value: a whole number ≥ 1, unit: min|hours|days|weeks|months}.', 'wp-marketing-automations-pro' ), array_keys( self::UNITS ) );

			return null;
		}

		$seconds = $value * self::UNITS[ $unit ];
		if ( $seconds < 60 || $seconds > 365 * 86400 ) {
			$errors->add( $path . '.delay', __( 'must be between 1 minute and 365 days (a month counts as 30 days).', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$data = array( 'day_delay' => array( 'unit' => $unit, 'text' => (string) $value ) );

		if ( isset( $step['at_time'] ) ) {
			$time = self::time( $step['at_time'], $path . '.at_time', $errors );
			if ( null !== $time ) {
				$data['enable_time_delay'] = true;
				$data['time_delay']        = array( 'time' => $time, 'in_contact_timezone' => ! empty( $step['in_contact_timezone'] ) );
			}
		}
		if ( ! isset( $data['time_delay'] ) ) {
			$data['time_delay'] = array();
		}

		if ( isset( $step['weekdays'] ) ) {
			$days = is_array( $step['weekdays'] ) ? array_values( array_unique( $step['weekdays'] ) ) : array( 0 );
			foreach ( $days as $day ) {
				if ( ! is_int( $day ) || $day < 1 || $day > 7 ) {
					$errors->add( $path . '.weekdays', __( 'must be days 1 (Sunday) to 7 (Saturday).', 'wp-marketing-automations-pro' ) );

					return null;
				}
			}
			$data['enable_week_delay'] = true;
			$data['week_delay']        = array_map( 'strval', $days );
		} else {
			$data['week_delay'] = array();
		}

		return $data;
	}

	private static function until_date( array $step, $path, FKMCP_Definition_Errors $errors, array &$refs ) {
		$date = isset( $step['date'] ) && is_string( $step['date'] ) ? $step['date'] : '';
		$ts   = preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $date, $m ) && checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) ? strtotime( $date . ' 23:59:59' ) : false;

		if ( false === $ts ) {
			$errors->add( $path . '.date', __( 'must be a date, YYYY-MM-DD.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$skip = self::skip( $step, $path, $errors, $refs );
		if ( $ts < time() && ! $skip['enable_step_skip'] ) {
			$errors->add( $path . '.date', __( 'is in the past; set skip_to, or the step would run at once.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$time = self::time( isset( $step['time'] ) ? $step['time'] : '10:00', $path . '.time', $errors );

		return array(
			'date'             => $m[2] . '/' . $m[3] . '/' . $m[1],
			'time_delay'       => array( 'time' => (string) $time, 'in_contact_timezone' => ! empty( $step['in_contact_timezone'] ) ),
			'enable_step_skip' => $skip['enable_step_skip'],
			'skip_to_step'     => $skip['skip_to_step'],
		);
	}

	private static function until_dynamic( $kind, array $step, $path, FKMCP_Definition_Errors $errors, array $ctx, array &$refs ) {
		$time       = self::time( isset( $step['time'] ) ? $step['time'] : '10:00', $path . '.time', $errors );
		$occurrence = isset( $step['occurrence'] ) ? $step['occurrence'] : null;
		$tz         = ! empty( $step['in_contact_timezone'] );
		$data       = array();

		// Required (spec §15.1): which part of the date counts changes when the wait ends, so never guess it.
		if ( ! in_array( $occurrence, self::OCCURRENCES[ $kind ], true ) ) {
			$errors->add( $path . '.occurrence', __( 'is required: which part of the date to wait for.', 'wp-marketing-automations-pro' ), self::OCCURRENCES[ $kind ] );

			return null;
		}

		if ( 'until_field_date' === $kind ) {
			$want  = isset( $step['field'] ) ? $step['field'] : '';
			$found = null;
			foreach ( (array) call_user_func( $ctx['contact_fields'] ) as $field ) {
				if ( (string) $field['ID'] === (string) $want || (string) $field['slug'] === (string) $want ) {
					$found = $field;
				}
			}
			if ( null === $found || ! in_array( (int) $found['type'], array( 7, 8 ), true ) ) {
				$errors->add( $path . '.field', __( 'must be a contact field of type date or date & time.', 'wp-marketing-automations-pro' ) );

				return null;
			}
			if ( 'fulldatetime' === $occurrence && 8 !== (int) $found['type'] ) {
				$errors->add( $path . '.occurrence', __( 'fulldatetime needs a date & time field.', 'wp-marketing-automations-pro' ) );

				return null;
			}
			// A string, as the builder's SelectControl saves it (delay.js custom_field.field = val).
			$data['custom_field'] = array( 'field' => (string) (int) $found['ID'], 'time' => (string) $time, 'in_contact_timezone' => $tz, 'custom_field_label' => wp_strip_all_tags( (string) $found['name'] ) );
		} else {
			$tag = isset( $step['merge_tag'] ) && is_string( $step['merge_tag'] ) ? trim( $step['merge_tag'] ) : '';
			$ok  = preg_match( '/^\{\{\s*([a-z0-9_]+)[^{}]*\}\}$/', $tag, $mm ) && isset( $ctx['delay_tags'][ $mm[1] ] );
			if ( ! $ok ) {
				$errors->add( $path . '.merge_tag', __( 'must be one date merge tag this trigger provides.', 'wp-marketing-automations-pro' ), array_map( function ( $t ) {
					return '{{' . $t . '}}';
				}, array_keys( isset( $ctx['delay_tags'] ) ? $ctx['delay_tags'] : array() ) ) );

				return null;
			}
			$data['variable_field'] = array( 'variable' => $tag, 'time' => (string) $time, 'in_contact_timezone' => $tz );
		}

		$data['enable_time_delay'] = false;
		$data['time_delay']        = array();
		if ( isset( $step['offset'] ) ) {
			$o     = is_array( $step['offset'] ) ? $step['offset'] : array();
			$units = 'fulldatetime' === $occurrence ? self::OFFSET_UNITS_FULLDATETIME : self::OFFSET_UNITS;
			if ( ! isset( $o['value'], $o['unit'], $o['timing'] ) || ! is_int( $o['value'] ) || $o['value'] < 1 || ! in_array( $o['unit'], $units, true ) || ! in_array( $o['timing'], array( 'before', 'after' ), true ) ) {
				$errors->add( $path . '.offset', __( 'must be {value ≥ 1, unit, timing: before|after}; minutes and hours only with occurrence fulldatetime.', 'wp-marketing-automations-pro' ), $units );

				return null;
			}
			$data['enable_time_delay'] = true;
			$data['time_delay']        = array( 'duration' => (string) $o['value'], 'type' => $o['unit'], 'timing' => $o['timing'] );
		}

		$data['occurrence'] = $occurrence;
		$skip               = self::skip( $step, $path, $errors, $refs );

		return array_merge( $data, $skip );
	}

	/** skip_to: a ref (marker, resolved by the definition builder) or "end". */
	private static function skip( array $step, $path, FKMCP_Definition_Errors $errors, array &$refs ) {
		if ( ! isset( $step['skip_to'] ) ) {
			return array( 'enable_step_skip' => false, 'skip_to_step' => array( 'step' => 0, 'name' => '' ) );
		}

		if ( 'end' === $step['skip_to'] ) {
			return array( 'enable_step_skip' => true, 'skip_to_step' => array( 'step' => 'end', 'name' => 'End Automation' ) );
		}

		if ( is_array( $step['skip_to'] ) && isset( $step['skip_to']['$step'] ) && is_string( $step['skip_to']['$step'] ) && preg_match( self::REF_PATTERN, $step['skip_to']['$step'] ) ) {
			$refs[] = array( 'key_path' => array( 'data', 'skip_to_step' ), 'ref' => $step['skip_to']['$step'] );

			return array( 'enable_step_skip' => true, 'skip_to_step' => array( 'step' => 0, 'name' => '' ) );
		}

		$errors->add( $path . '.skip_to', __( 'must be "end" or {"$step": "<ref>"}.', 'wp-marketing-automations-pro' ) );

		return array( 'enable_step_skip' => false, 'skip_to_step' => array( 'step' => 0, 'name' => '' ) );
	}

	private static function time( $value, $path, FKMCP_Definition_Errors $errors ) {
		if ( ! is_string( $value ) || ! preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', $value ) ) {
			$errors->add( $path, __( 'must be a time, HH:MM (24-hour).', 'wp-marketing-automations-pro' ) );

			return null;
		}

		return $value;
	}

	// ─── exit / action ────────────────────────────────────────────

	/** As the builder leaves it: exits are never re-saved, so status stays at the add-step default of 0 (#107). */
	public static function exit_step() {
		return array( 'type' => 5, 'action' => null, 'sidebar' => null, 'status' => 0, 'node' => 'exit', 'refs' => array(), 'warnings' => array() );
	}

	public static function action( array $descriptor, array $saved ) {
		return array(
			'type'     => 2,
			'action'   => array( 'action' => (string) $descriptor['slug'], 'intergration' => (string) $descriptor['integration'] ),
			'sidebar'  => $saved,
			'status'   => 1,
			'node'     => 'action',
			'refs'     => array(),
			'warnings' => array(),
		);
	}

	/** Shared with FKMCP_Definition_Builder (action/exit steps have no Step_Builder key list of their own). */
	public static function unknown_keys( array $step, array $known, $path, FKMCP_Definition_Errors $errors ) {
		foreach ( array_diff( array_keys( $step ), $known ) as $key ) {
			$errors->add( $path . '.' . $key, __( 'is not a setting of this step.', 'wp-marketing-automations-pro' ), $known );
		}
	}
}
