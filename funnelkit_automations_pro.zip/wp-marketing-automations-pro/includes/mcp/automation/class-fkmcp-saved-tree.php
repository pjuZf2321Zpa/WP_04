<?php

defined( 'ABSPATH' ) || exit;

/**
 * A saved graph read back as the definition's tree positions (steps[2],
 * steps[2].yes[0], steps[1].branches[0].steps[0], steps[1].else[0],
 * steps[3].paths[1][0]), the same strings FKMCP_Step_Tree gives the new
 * definition. update-automation uses them to keep a step's row id, and its
 * history, when the new definition has a step of the same type in the same
 * place (spec §16). Pure: no queries, no writes.
 *
 * It never guesses. A fork with no merger point (a legacy draft the builder
 * never saved), a node with no live row, or a link back to a node already
 * placed ends that walk, and the steps after it simply get new rows.
 */
class FKMCP_Saved_Tree {

	/** Saved row type => definition step type; 2 is email or action (type_of()). */
	const TYPES = array(
		1 => 'wait',
		3 => 'goal',
		4 => 'condition',
		5 => 'exit',
		6 => 'jump',
		7 => 'split',
		8 => 'branches',
	);

	/** @var array node id => node */
	private $nodes = array();

	/** @var array source node id => its first target */
	private $next = array();

	/** @var array fork node id => join node id */
	private $mergers = array();

	/** @var array row id => row */
	private $rows = array();

	/** @var array node id => true, once placed */
	private $seen = array();

	/** @var array path => {id, type, branch_ids?} */
	private $out = array();

	public static function positions( array $nodes, array $links, array $mergers, array $rows ) {
		$tree          = new self();
		$tree->mergers = $mergers;
		$tree->rows    = $rows;

		foreach ( $nodes as $node ) {
			if ( is_array( $node ) && isset( $node['id'] ) && is_scalar( $node['id'] ) ) {
				$tree->nodes[ (string) $node['id'] ] = $node;
			}
		}

		foreach ( $links as $link ) {
			if ( ! is_array( $link ) || ! isset( $link['source'], $link['target'] ) || ! is_scalar( $link['source'] ) || ! is_scalar( $link['target'] ) ) {
				continue;
			}
			if ( ! isset( $tree->next[ (string) $link['source'] ] ) ) {
				$tree->next[ (string) $link['source'] ] = (string) $link['target']; // forks are followed through their chips, never this.
			}
		}

		if ( isset( $tree->next['start'] ) ) {
			$tree->walk( $tree->next['start'], 'end', 'steps' );
		}

		return $tree->out;
	}

	public static function type_of( array $row ) {
		$type = isset( $row['type'] ) ? (int) $row['type'] : 0;

		if ( 2 === $type ) {
			$action = isset( $row['action'] ) && is_string( $row['action'] ) ? json_decode( $row['action'], true ) : null;

			return isset( $action['action'] ) && 'wp_sendemail' === $action['action'] ? 'email' : 'action';
		}

		return isset( self::TYPES[ $type ] ) ? self::TYPES[ $type ] : '';
	}

	private function walk( $id, $stop, $prefix ) {
		for ( $k = 0; '' !== $id && $id !== $stop && 'end' !== $id; ++$k ) {
			if ( isset( $this->seen[ $id ] ) || ! isset( $this->nodes[ $id ] ) ) {
				return;
			}
			$this->seen[ $id ] = true;

			$node = $this->nodes[ $id ];
			$sid  = isset( $node['stepId'] ) && is_numeric( $node['stepId'] ) ? (int) $node['stepId'] : 0;
			if ( $sid <= 0 || ! isset( $this->rows[ $sid ] ) || ! is_array( $this->rows[ $sid ] ) ) {
				return;
			}

			$type               = self::type_of( $this->rows[ $sid ] );
			$path               = $prefix . '[' . $k . ']';
			$this->out[ $path ] = array(
				'id'   => $sid,
				'type' => $type,
			);

			if ( in_array( $type, array( 'condition', 'branches', 'split' ), true ) ) {
				if ( ! isset( $this->mergers[ $id ] ) || ! is_scalar( $this->mergers[ $id ] ) ) {
					return; // no merger point: the builder never saved this graph; don't guess where its lanes meet.
				}
				$join = (string) $this->mergers[ $id ];
				$this->lanes( $id, $type, $this->rows[ $sid ], $join, $path );
				$id = $join;
				continue;
			}

			$id = isset( $this->next[ $id ] ) ? $this->next[ $id ] : '';
		}
	}

	private function lanes( $id, $type, array $row, $join, $path ) {
		$data    = isset( $row['data'] ) && is_string( $row['data'] ) ? json_decode( $row['data'], true ) : null;
		$sidebar = isset( $data['sidebarData'] ) && is_array( $data['sidebarData'] ) ? $data['sidebarData'] : array();
		$heads   = array();

		if ( 'condition' === $type ) {
			$heads = array(
				$path . '.yes' => $id . 'yes',
				$path . '.no'  => $id . 'no',
			);
		} elseif ( 'branches' === $type ) {
			$ids      = array();
			$branches = isset( $sidebar['branches'] ) && is_array( $sidebar['branches'] ) ? array_values( $sidebar['branches'] ) : array();
			foreach ( $branches as $b => $branch ) {
				if ( is_array( $branch ) && isset( $branch['id'] ) && is_scalar( $branch['id'] ) ) {
					$ids[] = (string) $branch['id'];
					$heads[ $path . '.branches[' . $b . '].steps' ] = $id . '-branch-' . $branch['id'];
				}
			}
			$heads[ $path . '.else' ]         = $id . '-branch-else';
			$this->out[ $path ]['branch_ids'] = $ids;
		} else {
			$count = isset( $sidebar['split_path'] ) && is_numeric( $sidebar['split_path'] ) ? min( 3, max( 0, (int) $sidebar['split_path'] ) ) : 0;
			for ( $p = 1; $p <= $count; $p++ ) {
				$heads[ $path . '.paths[' . ( $p - 1 ) . ']' ] = $id . '-path-' . $p;
			}
		}

		foreach ( $heads as $prefix => $chip ) {
			if ( isset( $this->next[ $chip ] ) ) {
				$this->walk( $this->next[ $chip ], $join, $prefix );
			}
		}
	}
}
