<?php

defined( 'ABSPATH' ) || exit;

/**
 * The inverse of FKMCP_Step_Builder, FKMCP_Rule_Translator and the definition
 * builder's goal/fork rows: one saved step row back into the definition step
 * update-automation accepts (spec §3, §15). Pure: no queries, no hooks. Lanes
 * (yes/no, branches[].steps, else, paths) are the caller's: it nests the rows
 * by their FKMCP_Saved_Tree path.
 *
 * Anything the definition cannot express comes back as a WP_Error
 * fkmcp_reader_unsupported, so the caller reports it instead of guessing.
 */
class FKMCP_Step_Reader {

	/** Row types (bwfan_automation_step.type) as the builder saves them (spec §15). */
	const WAIT     = 1;
	const ACTION   = 2;
	const GOAL     = 3;
	const COND     = 4;
	const STOP     = 5;
	const JUMP     = 6;
	const SPLIT    = 7;
	const BRANCHES = 8;

	/** A setting whose id names a credential is never read back (same words as Lite's step settings). */
	const SECRET_KEY_PATTERN = '/(^|[_-])(api[_-]?key|private[_-]?key|access[_-]?key|secret|token|password|passwd|pass)([_-]|$)/i';

	/** Same as Lite's FKMCP_Pack_Lite::SECRET_ROW_NAME_PATTERN: a header/key-value row named like a credential. */
	const SECRET_ROW_NAME_PATTERN = '/(auth|token|secret|cookie|passw|api[_-]?key|signature|bearer)/i';

	/** Same as Lite's FKMCP_Pack_Lite::CAPABILITY_URL_PATTERN: webhook URLs that are the credential. */
	const CAPABILITY_URL_PATTERN = '#^https?://(hooks\.zapier\.com|hook\.[a-z0-9]+\.make\.com|hook\.integromat\.com|connect\.pabbly\.com|webhooks\.integrately\.com)/#i';

	/** Trigger fields the definition names differently (FKMCP_Definition_Builder::TRIGGER_ALIASES, reversed). */
	const TRIGGER_NAMES = array(
		'bwfan_automation_run'               => 'run',
		'enter_automation_on_active_contact' => 'enter_on_active_contact',
	);

	/**
	 * @param array $row One bwfan_automation_step row: ID, type, action, data (JSON or decoded).
	 * @param array $ctx ref_of: row id => ref of every jump/skip target; rule_types: rule slug => type;
	 *                   part: the action's or goal's descriptor {fields, defaults}, null for other steps.
	 *
	 * @return array|WP_Error
	 */
	public static function step( array $row, array $ctx ) {
		$data    = self::decode( isset( $row['data'] ) ? $row['data'] : null );
		$sidebar = isset( $data['sidebarData'] ) ? $data['sidebarData'] : null;
		$action  = self::decode( isset( $row['action'] ) ? $row['action'] : null );

		switch ( (int) $row['type'] ) {
			case self::WAIT:
				return self::wait( is_array( $sidebar ) ? $sidebar : array(), $ctx );

			case self::ACTION:
				$slug = isset( $action['action'] ) ? (string) $action['action'] : '';
				if ( 'wp_sendemail' === $slug ) {
					return array( 'type' => 'email', 'keep' => (int) $row['ID'] ); // by id, not position: moving or deleting emails keeps the right one.
				}
				$settings = self::part_settings( $ctx, is_array( $sidebar ) ? $sidebar : array(), $slug );

				return is_wp_error( $settings ) ? $settings : array( 'type' => 'action', 'action' => $slug, 'settings' => $settings );

			case self::GOAL:
				$saved = is_array( $sidebar ) ? $sidebar : array();
				$run   = isset( $saved['bwfan_goal_run'] ) ? (string) $saved['bwfan_goal_run'] : 'wait';
				unset( $saved['bwfan_goal_run'] );
				$event    = isset( $action['benchmark'] ) ? (string) $action['benchmark'] : '';
				$settings = self::part_settings( $ctx, $saved, $event );
				if ( is_array( $settings ) ) {
					unset( $settings['bwfan_goal_run'] ); // if_not_met carries it; the goal's defaults list it too.
				}

				return is_wp_error( $settings ) ? $settings : array( 'type' => 'goal', 'event' => $event, 'settings' => $settings, 'if_not_met' => $run );

			case self::COND:
				return array( 'type' => 'condition', 'rules' => self::rules( is_array( $sidebar ) ? $sidebar : array(), self::rule_types( $ctx ) ) );

			case self::BRANCHES:
				$branches = array();
				foreach ( isset( $sidebar['branches'] ) && is_array( $sidebar['branches'] ) ? $sidebar['branches'] : array() as $branch ) {
					$branches[] = array(
						'name'  => isset( $branch['name'] ) ? (string) $branch['name'] : '',
						'rules' => self::rules( isset( $branch['rules'] ) && is_array( $branch['rules'] ) ? $branch['rules'] : array(), self::rule_types( $ctx ) ),
					);
				}

				return array( 'type' => 'branches', 'branches' => $branches );

			case self::SPLIT:
				return array(
					'type'  => 'split',
					'title' => isset( $sidebar['title'] ) ? (string) $sidebar['title'] : '',
					'desc'  => isset( $sidebar['desc'] ) ? (string) $sidebar['desc'] : '',
				);

			case self::JUMP:
				$to = self::target( isset( $sidebar['jump_to']['step'] ) ? $sidebar['jump_to']['step'] : null, $ctx );

				return is_wp_error( $to ) ? $to : array( 'type' => 'jump', 'to' => $to );

			case self::STOP:
				return array( 'type' => 'exit' );
		}

		return self::unsupported( sprintf( 'step type %d has no definition', (int) $row['type'] ) );
	}

	/**
	 * [[{filter, rule, data}]] as saved → [[{rule, operator, value}]] (spec §15.4, read backwards).
	 *
	 * @param array $groups     Outer list OR, inner AND.
	 * @param array $rule_types Rule slug => rule type (FKMCP_Rule_Translator::registry()).
	 *
	 * @return array
	 */
	public static function rules( array $groups, array $rule_types ) {
		$out = array();

		foreach ( $groups as $group ) {
			$rules = array();
			foreach ( is_array( $group ) ? $group : array() as $rule ) {
				if ( ! is_array( $rule ) ) {
					continue;
				}
				$slug    = isset( $rule['filter'] ) ? (string) $rule['filter'] : '';
				$rules[] = array(
					'rule'     => $slug,
					'operator' => isset( $rule['rule'] ) ? (string) $rule['rule'] : '',
					'value'    => self::rule_value( isset( $rule_types[ $slug ] ) ? $rule_types[ $slug ] : '', isset( $rule['data'] ) ? $rule['data'] : null ),
				);
			}
			$out[] = $rules;
		}

		return $out;
	}

	/**
	 * The trigger block: {event, run, enter_on_active_contact, settings}.
	 *
	 * @param array  $meta  The automation's event_meta.
	 * @param string $event Trigger slug.
	 * @param array  $part  The event's descriptor {fields, defaults}.
	 *
	 * @return array|WP_Error
	 */
	public static function trigger( array $meta, $event, array $part ) {
		$out = array( 'event' => (string) $event );

		foreach ( self::TRIGGER_NAMES as $id => $name ) {
			if ( array_key_exists( $id, $meta ) ) {
				$out[ $name ] = 'run' === $name ? (string) $meta[ $id ] : self::truthy( $meta[ $id ] );
			}
		}

		$fields = array_values(
			array_filter(
				isset( $part['fields'] ) ? (array) $part['fields'] : array(),
				function ( $field ) {
					return ! isset( $field['id'], self::TRIGGER_NAMES[ $field['id'] ] );
				}
			)
		);
		$settings = self::settings( $fields, $meta, isset( $part['defaults'] ) ? (array) $part['defaults'] : array() );

		if ( is_wp_error( $settings ) ) {
			return $settings;
		}

		$out['settings'] = $settings;

		return $out;
	}

	// ─── waits ────────────────────────────────────────────────────

	private static function wait( array $saved, array $ctx ) {
		$data = isset( $saved['data'] ) && is_array( $saved['data'] ) ? $saved['data'] : array();
		$type = isset( $saved['type'] ) ? (int) $saved['type'] : 1;

		if ( 1 === $type ) {
			$out = array(
				'type'  => 'wait',
				'kind'  => 'delay',
				'delay' => array(
					'value' => isset( $data['day_delay']['text'] ) ? (int) $data['day_delay']['text'] : 0,
					'unit'  => isset( $data['day_delay']['unit'] ) ? (string) $data['day_delay']['unit'] : '',
				),
			);
			if ( ! empty( $data['enable_time_delay'] ) && ! empty( $data['time_delay']['time'] ) ) {
				$out['at_time']             = (string) $data['time_delay']['time'];
				$out['in_contact_timezone'] = self::truthy( isset( $data['time_delay']['in_contact_timezone'] ) ? $data['time_delay']['in_contact_timezone'] : false );
			}
			if ( ! empty( $data['enable_week_delay'] ) && ! empty( $data['week_delay'] ) && is_array( $data['week_delay'] ) ) {
				$out['weekdays'] = array_map( 'intval', array_values( $data['week_delay'] ) );
			}

			return $out;
		}

		if ( 2 === $type ) {
			$date = isset( $data['date'] ) ? (string) $data['date'] : '';
			if ( ! preg_match( '#^(\d{2})/(\d{2})/(\d{4})$#', $date, $m ) ) {
				return self::unsupported( 'the wait date is not a saved MM/DD/YYYY date' );
			}
			$out = array(
				'type'                => 'wait',
				'kind'                => 'until_date',
				'date'                => $m[3] . '-' . $m[1] . '-' . $m[2],
				'time'                => isset( $data['time_delay']['time'] ) ? (string) $data['time_delay']['time'] : '10:00',
				'in_contact_timezone' => self::truthy( isset( $data['time_delay']['in_contact_timezone'] ) ? $data['time_delay']['in_contact_timezone'] : false ),
			);

			return self::with_skip( $out, $data, $ctx );
		}

		if ( 3 === $type || 4 === $type ) {
			$src = 3 === $type ? ( isset( $data['custom_field'] ) ? (array) $data['custom_field'] : array() ) : ( isset( $data['variable_field'] ) ? (array) $data['variable_field'] : array() );
			$out = array( 'type' => 'wait' );
			if ( 3 === $type ) {
				$out['kind']  = 'until_field_date';
				$out['field'] = isset( $src['field'] ) ? (string) $src['field'] : '';
			} else {
				$out['kind']      = 'until_merge_tag_date';
				$out['merge_tag'] = isset( $src['variable'] ) ? (string) $src['variable'] : '';
			}
			$out['time']                = isset( $src['time'] ) ? (string) $src['time'] : '10:00';
			$out['in_contact_timezone'] = self::truthy( isset( $src['in_contact_timezone'] ) ? $src['in_contact_timezone'] : false );
			if ( ! empty( $data['enable_time_delay'] ) && isset( $data['time_delay']['duration'] ) ) {
				$out['offset'] = array(
					'value'  => (int) $data['time_delay']['duration'],
					'unit'   => isset( $data['time_delay']['type'] ) ? (string) $data['time_delay']['type'] : '',
					'timing' => isset( $data['time_delay']['timing'] ) ? (string) $data['time_delay']['timing'] : '',
				);
			}
			$out['occurrence'] = isset( $data['occurrence'] ) ? (string) $data['occurrence'] : '';

			return self::with_skip( $out, $data, $ctx );
		}

		return self::unsupported( sprintf( 'wait type %d has no definition', $type ) );
	}

	private static function with_skip( array $out, array $data, array $ctx ) {
		if ( empty( $data['enable_step_skip'] ) ) {
			return $out;
		}

		$to = self::target( isset( $data['skip_to_step']['step'] ) ? $data['skip_to_step']['step'] : null, $ctx );
		if ( is_wp_error( $to ) ) {
			return $to;
		}
		$out['skip_to'] = $to;

		return $out;
	}

	/** A saved jump/skip target: "end", or the ref the caller gave that row. */
	private static function target( $step, array $ctx ) {
		if ( 'end' === $step ) {
			return 'end';
		}

		$refs = isset( $ctx['ref_of'] ) ? (array) $ctx['ref_of'] : array();
		if ( is_numeric( $step ) && isset( $refs[ (int) $step ] ) ) {
			return array( '$step' => (string) $refs[ (int) $step ] );
		}

		return self::unsupported( 'the skip or jump target is not in the automation' );
	}

	// ─── part settings (actions, goals, trigger) ─────────────────

	private static function part_settings( array $ctx, array $saved, $slug ) {
		if ( empty( $ctx['part'] ) || ! is_array( $ctx['part'] ) ) {
			return self::unsupported( sprintf( '%s is not a part this store lists', $slug ) );
		}

		return self::settings( isset( $ctx['part']['fields'] ) ? (array) $ctx['part']['fields'] : array(), $saved, isset( $ctx['part']['defaults'] ) ? (array) $ctx['part']['defaults'] : array() );
	}

	/**
	 * Saved values keyed by field id → what FKMCP_Field_Translator::normalise()
	 * takes: every field that applies, defaults included - a guarded field must be
	 * sent explicitly even when it holds the default ("any"). A field the saved
	 * settings never set reads as its default, as the builder shows it.
	 */
	private static function settings( array $fields, array $saved, array $defaults = array() ) {
		$out   = array();
		$saved = array_merge( $defaults, $saved );

		foreach ( $fields as $field ) {
			$id   = isset( $field['id'] ) ? (string) $field['id'] : '';
			$type = isset( $field['type'] ) ? (string) $field['type'] : '';

			if ( '' === $id || ! array_key_exists( $id, $saved ) || in_array( $type, FKMCP_Field_Translator::DISPLAY, true ) || ! FKMCP_Field_Translator::applies( $field, $saved ) ) {
				continue;
			}
			$empty = null === $saved[ $id ] || '' === $saved[ $id ] || array() === $saved[ $id ];
			if ( preg_match( self::SECRET_KEY_PATTERN, $id ) && ! $empty ) {
				return self::unsupported( sprintf( '%s holds a credential; edit it in the builder', $id ) );
			}
			if ( 'bwf_form_submit' === $type ) {
				if ( ! $empty ) {
					$out[ $id ] = self::form_map( $saved[ $id ] );
				}
				continue;
			}
			if ( ! in_array( $type, FKMCP_Field_Translator::PLAIN, true ) ) {
				if ( $empty ) {
					continue;
				}

				return self::unsupported( sprintf( '%s is a %s field, set in the builder only', $id, $type ) );
			}

			if ( self::holds_secret( $saved[ $id ] ) ) {
				return self::unsupported( sprintf( '%s holds a credential or a webhook URL; edit it in the builder', $id ) );
			}

			$value = self::field_value( $field, $saved[ $id ] );
			if ( is_wp_error( $value ) ) {
				return $value;
			}
			$out[ $id ] = $value;
		}

		return $out;
	}

	/** A saved form field map (bwfan_{role}_field_map => field key) as create-automation takes it. */
	private static function form_map( $saved ) {
		$out = array();
		foreach ( FKMCP_Field_Translator::FORM_MAP_ROLES as $role ) {
			$key = 'bwfan_' . $role . '_field_map';
			if ( is_array( $saved ) && isset( $saved[ $key ] ) && is_scalar( $saved[ $key ] ) && '' !== (string) $saved[ $key ] ) {
				$out[ $role ] = (string) $saved[ $key ];
			}
		}

		return $out;
	}

	private static function field_value( array $field, $value ) {
		switch ( (string) $field['type'] ) {
			case 'checkbox':
			case 'toggle':
				return self::truthy( $value );

			case 'search':
			case 'custom_search':
				return self::ids( $value );

			case 'expression':
				return self::settings( isset( $field['fields'] ) ? (array) $field['fields'] : array(), is_array( $value ) ? $value : array() );

			case 'repeater':
				$rows = array();
				foreach ( is_array( $value ) ? array_values( $value ) : array() as $row ) {
					$one = self::settings( isset( $field['fields'] ) ? (array) $field['fields'] : array(), is_array( $row ) ? $row : array() );
					if ( is_wp_error( $one ) ) {
						return $one;
					}
					$rows[] = $one;
				}

				return $rows;
		}

		return $value;
	}

	// ─── values ───────────────────────────────────────────────────

	private static function rule_value( $type, $data ) {
		switch ( $type ) {
			case 'Search':
				return self::ids( $data );
			case 'key-value':
				return is_array( $data ) && 2 === count( $data ) ? array( 'key' => (string) reset( $data ), 'value' => end( $data ) ) : $data;
			case 'product-qty':
				return array(
					'qty'      => isset( $data['qty'] ) ? (int) $data['qty'] : 0,
					'products' => self::ids( isset( $data['search'] ) ? $data['search'] : array() ),
				);
			case 'Number':
				return is_numeric( $data ) ? 0 + $data : $data;
			case 'Days':
				if ( is_array( $data ) && isset( $data['from'], $data['to'] ) ) {
					return array( 'from' => (int) $data['from'], 'to' => (int) $data['to'] );
				}

				return is_numeric( $data ) ? (int) $data : $data;
		}

		return $data;
	}

	/** [{id|key, name|label}] or scalars → the ids, as strings. */
	private static function ids( $value ) {
		$out = array();

		foreach ( is_array( $value ) ? $value : array( $value ) as $one ) {
			if ( is_array( $one ) ) {
				$id = isset( $one['id'] ) ? $one['id'] : ( isset( $one['key'] ) ? $one['key'] : null );
			} else {
				$id = $one;
			}
			if ( is_scalar( $id ) && '' !== (string) $id ) {
				$out[] = (string) $id;
			}
		}

		return $out;
	}

	/** A webhook capability URL, or a header/key-value row named like a credential with a value, at any depth. */
	private static function holds_secret( $value ) {
		if ( is_string( $value ) ) {
			return (bool) preg_match( self::CAPABILITY_URL_PATTERN, $value );
		}
		if ( ! is_array( $value ) ) {
			return false;
		}
		foreach ( array( 'field', 'key', 'name', 'header' ) as $name_key ) {
			if ( isset( $value[ $name_key ] ) && is_string( $value[ $name_key ] ) && preg_match( self::SECRET_ROW_NAME_PATTERN, $value[ $name_key ] ) ) {
				foreach ( array( 'field_value', 'value' ) as $value_key ) {
					if ( ! empty( $value[ $value_key ] ) ) {
						return true;
					}
				}
			}
		}
		foreach ( $value as $one ) {
			if ( self::holds_secret( $one ) ) {
				return true;
			}
		}

		return false;
	}

	private static function truthy( $value ) {
		return in_array( $value, array( true, 1, '1', 'true', 'yes', 'on' ), true );
	}

	private static function rule_types( array $ctx ) {
		return isset( $ctx['rule_types'] ) ? (array) $ctx['rule_types'] : array();
	}

	private static function decode( $value ) {
		if ( is_string( $value ) ) {
			$value = json_decode( $value, true );
		}

		return is_array( $value ) ? $value : ( is_object( $value ) ? json_decode( (string) wp_json_encode( $value ), true ) : null );
	}

	private static function unsupported( $reason ) {
		return new WP_Error( 'fkmcp_reader_unsupported', $reason );
	}
}
