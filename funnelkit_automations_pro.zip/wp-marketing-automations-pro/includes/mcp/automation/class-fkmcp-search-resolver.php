<?php

defined( 'ABSPATH' ) || exit;

/**
 * Search field values (ids or exact names) → the builder's saved
 * [{id, name}], read from the same data the admin pickers read. Batched per
 * field and memoised per request (spec §0.2.3).
 */
class FKMCP_Search_Resolver {
	const VALUE_MAX = 200;

	/** Values one search field may carry; each is a lookup (spec §0.2.3). */
	const VALUES_MAX = 100;

	/** @var object FKMCP_Pack_Pro (resolve_terms) */
	private $pack;

	/** kind => [ 'id:<id>' | 'name:<lower name>' => {id, name} ] */
	private $memo = array();

	private $created = array();

	/** Set by the definition builder: defers tag/list creation until the whole definition validates. */
	private $pending_mode = false;

	/** type ('tag'|'list') => raw values still needing creation, across every deferred call. */
	private $pending = array();

	/** token => {type, values, unknown}: what a single deferred resolve() call asked for, and the names it would create. */
	private $tokens = array();

	private $next_token = 0;

	/** @var callable|null fn( string $path, string $id ): string - a record's title by id, for ID_TITLES; '' when none. Tests replace it. */
	public static $id_title = null;

	public function __construct( $pack ) {
		$this->pack = $pack;
	}

	public function created() {
		return $this->created;
	}

	/** Turns deferred creation on: resolve() records unresolved names instead of creating them. */
	public function defer_creation( $on = true ) {
		$this->pending_mode = (bool) $on;
	}

	/** Definition_Builder calls this at the start of every build(): no state leaks between calls. */
	public function reset_call() {
		$this->pending     = array();
		$this->tokens      = array();
		$this->next_token  = 0;
		$this->created     = array();
	}

	public function has_pending() {
		return ! empty( $this->pending );
	}

	/**
	 * Creates every pending tag/list, once per type, and returns token => [{id,name}] for the
	 * definition builder to patch into the saved rows it recorded each token against. A WP_Error
	 * here means creation itself failed; the caller passes it straight through.
	 */
	public function create_pending() {
		$results = array();

		foreach ( $this->pending as $type => $values ) {
			$created = array();
			$pairs   = $this->pack->resolve_terms( array_values( array_unique( $values ) ), $type, true, $created );

			if ( is_wp_error( $pairs ) ) {
				return $this->orphaned_error( $pairs );
			}

			foreach ( $created as $pair ) {
				$this->created[] = array( 'type' => $type, 'id' => (int) $pair['id'], 'name' => (string) $pair['value'] );
			}

			$by_key = array();
			foreach ( (array) $pairs as $pair ) {
				$by_key[ 'id:' . $pair['id'] ]                            = $pair;
				$by_key[ strtolower( trim( (string) $pair['value'] ) ) ]  = $pair;
			}

			foreach ( $this->tokens as $token => $info ) {
				if ( $info['type'] !== $type ) {
					continue;
				}

				$out = array();
				foreach ( $info['values'] as $value ) {
					$key = is_numeric( $value ) && isset( $by_key[ 'id:' . (int) $value ] ) ? 'id:' . (int) $value : strtolower( trim( (string) $value ) );
					if ( isset( $by_key[ $key ] ) ) {
						$out[ (string) $by_key[ $key ]['id'] ] = array( 'id' => (string) $by_key[ $key ]['id'], 'name' => self::name( $by_key[ $key ]['value'] ) );
					}
				}
				$results[ $token ] = array_values( $out );
			}
		}

		return $results;
	}

	/**
	 * A later type's creation failed, after an earlier type already created some terms; names them
	 * in the message and in data.created_terms so the caller never silently drops them (spec §0.1.9:
	 * the write already happened, so the result must say so).
	 */
	private function orphaned_error( WP_Error $failure ) {
		return empty( $this->created ) ? $failure : self::with_created_terms( $failure, $this->created );
	}

	/**
	 * $error with "these tags were created and remain: …" sentences appended, and every term in
	 * data.created_terms. The one place this message is built (the pack's rollback path uses it
	 * too). Names are scrubbed and capped one by one, ten per type then "and N more", and never
	 * cut by a total cap: the base message is what gets capped.
	 *
	 * @param array $created [{type: tag|list|category, id, name}]
	 */
	public static function with_created_terms( WP_Error $error, array $created ) {
		$by_type = array();
		foreach ( $created as $term ) {
			$by_type[ $term['type'] ][] = FKMCP_Definition_Errors::clean( $term['name'], 100 );
		}

		$sentences = array( rtrim( FKMCP_Definition_Errors::clean( $error->get_error_message(), FKMCP_Definition_Errors::MESSAGE_LIMIT ), ' .;' ) );

		foreach ( $by_type as $type => $names ) {
			$shown = array_slice( $names, 0, 10 );
			$list  = implode( ', ', $shown );
			if ( count( $names ) > count( $shown ) ) {
				/* translators: %d: further created names not listed */
				$list .= ' ' . sprintf( __( 'and %d more', 'wp-marketing-automations-pro' ), count( $names ) - count( $shown ) );
			}
			/* translators: 1: tags, lists or categories, 2: names already created */
			$sentences[] = sprintf( __( 'these %1$s were created and remain: %2$s', 'wp-marketing-automations-pro' ), self::term_type_plural( $type ), $list );
		}

		$data = array_merge( (array) $error->get_error_data(), array( 'created_terms' => $created ) );

		return new WP_Error( $error->get_error_code(), implode( '. ', $sentences ) . '.', $data );
	}

	/** tag/list/category => its translated plural, for a message like "these tags were created". */
	private static function term_type_plural( $type ) {
		switch ( $type ) {
			case 'tag':
				return __( 'tags', 'wp-marketing-automations-pro' );
			case 'list':
				return __( 'lists', 'wp-marketing-automations-pro' );
			case 'category':
				return __( 'categories', 'wp-marketing-automations-pro' );
			default:
				return (string) $type;
		}
	}

	/** Which lookup a search field needs; null when there is none we trust. */
	public static function kind( array $field ) {
		$type = isset( $field['type'] ) ? $field['type'] : '';

		if ( 'custom_search' === $type ) {
			$path = isset( $field['autocompleterOption']['path'] ) ? sanitize_key( $field['autocompleterOption']['path'] ) : '';

			return '' === $path ? null : 'custom:' . $path;
		}

		$ac = isset( $field['autocompleter'] ) ? (string) $field['autocompleter'] : '';

		return in_array( $ac, array( 'tags', 'lists', 'products', 'categories', 'automations', 'link_trigger', 'coupons' ), true ) ? $ac : null;
	}

	public function resolve( array $field, array $values, $path, FKMCP_Definition_Errors $errors, $create_missing ) {
		$kind = self::kind( $field );

		if ( null === $kind ) {
			$errors->add( $path, __( 'can\'t be looked up by an assistant.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		if ( count( $values ) > self::VALUES_MAX ) {
			/* translators: %d: maximum number of values */
			$errors->add( $path, sprintf( __( 'takes at most %d values.', 'wp-marketing-automations-pro' ), self::VALUES_MAX ) );

			return null;
		}

		$clean = array();
		foreach ( $values as $i => $value ) {
			if ( ! is_scalar( $value ) || '' === trim( (string) $value ) || mb_strlen( (string) $value ) > self::VALUE_MAX ) {
				/* translators: %d: maximum length */
				$errors->add( $path . '[' . $i . ']', sprintf( __( 'must be an id or a name of at most %d characters.', 'wp-marketing-automations-pro' ), self::VALUE_MAX ) );

				return null;
			}
			$clean[] = is_string( $value ) ? trim( $value ) : $value;
		}

		if ( empty( $clean ) ) {
			return array();
		}

		if ( 'tags' === $kind || 'lists' === $kind ) {
			return $this->terms( $kind, $clean, $path, $errors, $create_missing );
		}

		$this->lookup( $kind, $clean );
		$out     = array();
		$bad     = false;

		foreach ( $clean as $i => $value ) {
			$hit = $this->hit( $kind, $value );

			if ( is_array( $hit ) && isset( $hit['ambiguous'] ) ) {
				$errors->add( $path . '[' . $i . ']', __( 'matches more than one record; use the id.', 'wp-marketing-automations-pro' ), $hit['ambiguous'] );
				$bad = true;
				continue;
			}

			if ( null === $hit ) {
				/* translators: %s: the value that matched nothing */
				$errors->add( $path . '[' . $i . ']', sprintf( __( 'matches nothing: "%s".', 'wp-marketing-automations-pro' ), mb_substr( wp_strip_all_tags( (string) $value ), 0, 80 ) ) );
				$bad = true;
				continue;
			}

			$out[ $hit['id'] ] = $hit;
		}

		return $bad ? null : array_values( $out );
	}

	private function terms( $kind, array $values, $path, FKMCP_Definition_Errors $errors, $create_missing ) {
		foreach ( $values as $i => $value ) {
			if ( $create_missing && false !== strpos( (string) $value, '{{' ) ) {
				$errors->add( $path . '[' . $i . ']', __( 'a merge tag can\'t be created as a tag or list name.', 'wp-marketing-automations-pro' ) );

				return null;
			}
		}

		$type = 'tags' === $kind ? 'tag' : 'list';

		if ( $create_missing && $this->pending_mode ) {
			return $this->defer_terms( $type, $values, $path, $errors );
		}

		$created = array();
		$pairs   = $this->pack->resolve_terms( $values, $type, (bool) $create_missing, $created );

		if ( is_wp_error( $pairs ) ) {
			$errors->add( $path, wp_strip_all_tags( $pairs->get_error_message() ) );

			return null;
		}

		foreach ( $created as $pair ) {
			$this->created[] = array( 'type' => $type, 'id' => (int) $pair['id'], 'name' => (string) $pair['value'] );
		}

		return $this->term_pairs( $pairs );
	}

	/**
	 * A read-only probe (never creates): everything already exists, resolve now; otherwise record
	 * the whole request as pending and hand back a placeholder the definition builder recognises,
	 * so nothing is written until every part of the definition has validated (spec §0.1.9, §9).
	 */
	private function defer_terms( $type, array $values, $path, FKMCP_Definition_Errors $errors ) {
		$ignored = array();
		$probe   = $this->pack->resolve_terms( $values, $type, false, $ignored );

		if ( ! is_wp_error( $probe ) ) {
			return $this->term_pairs( $probe );
		}

		$data    = $probe->get_error_data();
		$unknown = isset( $data['unknown'] ) && is_array( $data['unknown'] ) ? $data['unknown'] : array();

		if ( ! empty( array_filter( $unknown, 'is_numeric' ) ) ) {
			// An id is never coined, deferred or not; refuse now, same as the non-deferred path would.
			$errors->add( $path, wp_strip_all_tags( $probe->get_error_message() ) );

			return null;
		}

		$token                  = 'p' . ( ++$this->next_token );
		$this->tokens[ $token ] = array( 'type' => $type, 'values' => $values, 'unknown' => array_values( array_map( 'strval', $unknown ) ) );
		$this->pending[ $type ] = isset( $this->pending[ $type ] ) ? array_merge( $this->pending[ $type ], $values ) : $values;

		return array( '$pending' => $token );
	}

	/** token => {type, values, unknown}: what a dry build would create, for the review sheet and the plan hash. */
	public function pending_tokens() {
		return $this->tokens;
	}

	private function term_pairs( array $pairs ) {
		$out = array();
		foreach ( $pairs as $pair ) {
			$out[ (string) $pair['id'] ] = array( 'id' => (string) $pair['id'], 'name' => self::name( $pair['value'] ) );
		}

		return array_values( $out );
	}

	/** Fills the memo for every value not seen before; one or two queries per kind. */
	private function lookup( $kind, array $values ) { // phpcs:ignore Generic.Metrics.CyclomaticComplexity -- one switch over the kinds; splitting it hides the batching.
		$ids   = array();
		$names = array();

		foreach ( $values as $value ) {
			if ( null !== $this->hit( $kind, $value ) ) {
				continue;
			}
			if ( is_numeric( $value ) && 'coupons' !== $kind && 0 !== strpos( $kind, 'custom:' ) ) {
				$ids[] = (int) $value;
			} else {
				$names[] = (string) $value;
			}
		}

		if ( empty( $ids ) && empty( $names ) ) {
			return array();
		}

		$rows = array();

		switch ( $kind ) {
			case 'products':
				if ( ! empty( $ids ) ) {
					foreach ( (array) wc_get_products( array( 'include' => $ids, 'limit' => count( $ids ) ) ) as $p ) {
						$rows[] = array( 'id' => (string) $p->get_id(), 'name' => $p->get_name() . ' (#' . $p->get_id() . ')', 'raw' => $p->get_name() );
					}
				}
				if ( ! empty( $names ) ) {
					// Titles, batched: wc_get_products( 'name' ) matches the slug, not the title.
					global $wpdb;
					$found = $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_title FROM {$wpdb->posts} WHERE post_type IN ('product','product_variation') AND post_status IN ('publish','private') AND post_title IN (" . implode( ',', array_fill( 0, count( $names ), '%s' ) ) . ') LIMIT 50', $names ), 'ARRAY_A' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- table name is fixed; every value is a placeholder.
					foreach ( (array) $found as $row ) {
						$rows[] = array( 'id' => (string) $row['ID'], 'name' => $row['post_title'] . ' (#' . $row['ID'] . ')', 'raw' => (string) $row['post_title'] );
					}
				}
				break;

			case 'categories':
				$args = array( 'taxonomy' => 'product_cat', 'hide_empty' => false );
				if ( ! empty( $ids ) ) {
					foreach ( (array) get_terms( $args + array( 'include' => $ids ) ) as $t ) {
						$rows[] = array( 'id' => (string) $t->term_id, 'name' => (string) $t->name, 'raw' => (string) $t->name );
					}
				}
				if ( ! empty( $names ) ) {
					foreach ( (array) get_terms( $args + array( 'name' => $names ) ) as $t ) {
						$rows[] = array( 'id' => (string) $t->term_id, 'name' => (string) $t->name, 'raw' => (string) $t->name );
					}
				}
				break;

			case 'automations':
			case 'link_trigger':
				$rows = $this->title_rows( 'automations' === $kind ? 'bwfan_automations' : 'bwfan_link_triggers', $ids, $names, 'automations' === $kind );
				break;

			case 'coupons':
				// Codes, batched like product titles (wc_get_coupon_id_by_code() is one query per code).
				global $wpdb;
				$found = $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_title FROM {$wpdb->posts} WHERE post_type = 'shop_coupon' AND post_status = 'publish' AND post_title IN (" . implode( ',', array_fill( 0, count( $names ), '%s' ) ) . ') LIMIT 200', $names ), 'ARRAY_A' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- table name is fixed; every value is a placeholder.
				foreach ( (array) $found as $row ) {
					$code   = (string) $row['post_title'];
					$rows[] = array( 'id' => $code, 'name' => $code, 'raw' => $code );
				}
				break;

			default: // custom:<path>
				$rows = $this->custom_rows( substr( $kind, 7 ), $names );
		}

		// Index by id and by name; a name seen on two ids is ambiguous.
		foreach ( $rows as $row ) {
			$this->memo[ $kind ][ 'id:' . $row['id'] ] = array( 'id' => (string) $row['id'], 'name' => self::name( $row['name'] ) );
			$key = 'name:' . strtolower( (string) $row['raw'] );

			if ( isset( $this->memo[ $kind ][ $key ]['id'] ) && $this->memo[ $kind ][ $key ]['id'] !== (string) $row['id'] ) {
				$this->memo[ $kind ][ $key ] = array( 'ambiguous' => array( $this->memo[ $kind ][ $key ]['id'], (string) $row['id'] ) );
			} elseif ( isset( $this->memo[ $kind ][ $key ]['ambiguous'] ) ) {
				$this->memo[ $kind ][ $key ]['ambiguous'][] = (string) $row['id'];
			} else {
				$this->memo[ $kind ][ $key ] = array( 'id' => (string) $row['id'], 'name' => self::name( $row['name'] ) );
			}
		}

		return array();
	}

	private function hit( $kind, $value ) {
		if ( is_numeric( $value ) && 'coupons' !== $kind && isset( $this->memo[ $kind ][ 'id:' . (int) $value ] ) ) {
			return $this->memo[ $kind ][ 'id:' . (int) $value ];
		}
		if ( isset( $this->memo[ $kind ][ 'id:' . $value ] ) ) {
			return $this->memo[ $kind ][ 'id:' . $value ];
		}
		$key = 'name:' . strtolower( (string) $value );

		return isset( $this->memo[ $kind ][ $key ] ) ? $this->memo[ $kind ][ $key ] : null;
	}

	/** Automations (V2 only) or link triggers by id or exact title, in one prepared query. */
	private function title_rows( $table, array $ids, array $names, $v2_only ) {
		global $wpdb;

		$where = array();
		$args  = array();
		if ( ! empty( $ids ) ) {
			$where[] = 'ID IN (' . implode( ',', array_fill( 0, count( $ids ), '%d' ) ) . ')';
			$args    = array_merge( $args, $ids );
		}
		if ( ! empty( $names ) ) {
			$where[] = 'title IN (' . implode( ',', array_fill( 0, count( $names ), '%s' ) ) . ')';
			$args    = array_merge( $args, $names );
		}

		$tbl = $wpdb->prefix . $table;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- table name is fixed; every value is a placeholder.
		$found = $wpdb->get_results( $wpdb->prepare( "SELECT ID, title FROM {$tbl} WHERE " . ( $v2_only ? 'v = 2 AND ' : '' ) . '(' . implode( ' OR ', $where ) . ') LIMIT 50', $args ), 'ARRAY_A' );

		$rows = array();
		foreach ( (array) $found as $row ) {
			$rows[] = array( 'id' => (string) $row['ID'], 'name' => (string) $row['title'], 'raw' => (string) $row['title'] );
		}

		return $rows;
	}

	/**
	 * Custom searches whose own search reads titles only, so an id never comes back from it:
	 * the id's title is searched instead, and the row whose id matches is taken. The field's
	 * own search still decides what is allowed (post type, status, the events it lists).
	 */
	const ID_TITLES = array(
		'elementor_search_page' => 'post',
		'fk_fetch_bumps'        => 'post',
		'fk_fetch_offers'       => 'post',
		'allowed_automations'   => 'automation',
	);

	/** Connectors and other custom searches: the class's own get_options(), once per value. */
	private function custom_rows( $path, array $values ) {
		static $loaded = false;

		if ( ! $loaded ) {
			do_action( 'bwfan_load_custom_search_classes' );
			$loaded = true;
		}

		$search = isset( BWFAN_Core()->custom_search ) ? BWFAN_Core()->custom_search->get_custom_search( $path ) : null;
		if ( ! is_object( $search ) || ! method_exists( $search, 'get_options' ) ) {
			return array();
		}

		$rows = array();
		foreach ( $values as $value ) {
			$value = (string) $value;
			$found = self::custom_matches( $search, $value, $value, false );
			$id    = ctype_digit( $value ) ? $value : '';

			// A full stored label "Title(#id)" is that id: found by the label's title, or by the id's own title after a rename.
			if ( array() === $found && preg_match( '/^(.*?)\s*\(#(\d+)\)\s*$/', $value, $label ) ) {
				$id    = $label[2];
				$found = '' !== $label[1] ? self::custom_matches( $search, $label[1], $id, true, $value ) : array();
			}

			if ( array() === $found && '' !== $id && isset( self::ID_TITLES[ $path ] ) ) {
				$title = self::id_title( $path, $id );
				$found = '' !== $title ? self::custom_matches( $search, $title, $id, true, $value ) : array();
			}

			$rows = array_merge( $rows, $found );
		}

		return $rows;
	}

	/**
	 * Rows of $search->get_options( $query ) that are $value: by id, or (unless $id_only) by
	 * name, also with a trailing "(#id)" left off, as bump, offer and automation labels carry it.
	 * $given is what the caller sent, which hit() looks the row up by.
	 */
	private static function custom_matches( $search, $query, $value, $id_only, $given = null ) {
		try {
			$options = (array) $search->get_options( $query, array() );
		} catch ( Throwable $e ) {
			$options = array();
		}

		$rows = array();
		foreach ( $options as $key => $option ) {
			// get_options() returns {id: name} or rows of {id|key|value, name|label|title}.
			if ( is_array( $option ) ) {
				$id   = isset( $option['id'] ) ? $option['id'] : ( isset( $option['key'] ) ? $option['key'] : ( isset( $option['value'] ) ? $option['value'] : $key ) );
				$name = isset( $option['name'] ) ? $option['name'] : ( isset( $option['label'] ) ? $option['label'] : ( isset( $option['title'] ) ? $option['title'] : $id ) );
			} else {
				$id   = $key;
				$name = $option;
			}

			$name  = (string) $name;
			$plain = (string) preg_replace( '/\s*\(#\d+\)\s*$/', '', $name );

			if ( (string) $id === $value ) {
				$rows[] = array( 'id' => (string) $id, 'name' => $name, 'raw' => null === $given ? $plain : (string) $given );
			} elseif ( ! $id_only && ( 0 === strcasecmp( $name, $value ) || 0 === strcasecmp( $plain, $value ) ) ) {
				$rows[] = array( 'id' => (string) $id, 'name' => $name, 'raw' => $value );
			}
		}

		return $rows;
	}

	/** The title of a record by id, for a search in ID_TITLES; '' when there is none. */
	private static function id_title( $path, $id ) {
		if ( is_callable( self::$id_title ) ) {
			return (string) call_user_func( self::$id_title, $path, $id );
		}

		if ( 'post' === self::ID_TITLES[ $path ] ) {
			$post = get_post( (int) $id );

			return $post instanceof WP_Post ? (string) $post->post_title : '';
		}

		global $wpdb;

		return (string) $wpdb->get_var( $wpdb->prepare( "SELECT title FROM {$wpdb->prefix}bwfan_automations WHERE ID = %d", (int) $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one title by id, at definition time.
	}

	private static function name( $name ) {
		return mb_substr( wp_strip_all_tags( (string) $name ), 0, self::VALUE_MAX );
	}
}
