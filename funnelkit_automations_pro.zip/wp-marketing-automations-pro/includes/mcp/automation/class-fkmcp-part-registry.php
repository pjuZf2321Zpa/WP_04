<?php

defined( 'ABSPATH' ) || exit;

/**
 * The admin builder's own view of what can be built, read through the same
 * functions the builder's GET /automation/{id} uses, so every plugin's
 * filters are already applied. Memoised per request: get_available_actions()
 * loads every action class, and a 50-step definition asks about the same
 * parts over and over.
 */
class FKMCP_Part_Registry {
	/**
	 * Actions an agent may add but a human should look at before activating.
	 * They change WordPress users or roles, run code, send contact data to any
	 * URL, or delete data. Filterable: fkmcp_definition_sensitive_actions.
	 */
	const SENSITIVE = array(
		'wp_update_user_role'       => 'changes a WordPress user\'s role',
		'wp_createuser'             => 'creates a WordPress user',
		'wp_remove_user'            => 'deletes a WordPress user',
		'wp_update_user_meta'       => 'writes WordPress user meta (can grant roles through wp_capabilities)',
		'wp_custom_callback'        => 'runs a PHP callback',
		'wp_http_post'              => 'sends contact data to any URL',
		'wp_debug'                  => 'writes automation data to the debug log',
		'za_send_data'              => 'sends contact data to Zapier',
		'integrately_send_data'     => 'sends contact data to Integrately',
		'integromat_send_data'      => 'sends contact data to Make',
		'pabbly_send_data'          => 'sends contact data to Pabbly',
		'crm_delete_contact'        => 'deletes the Contact',
		'wc_remove_coupon'          => 'deletes a WooCommerce coupon',
		'gs_delete_data'            => 'clears Google Sheets rows',
		'zoom_delete_meeting'       => 'deletes a Zoom meeting',
		'bulkgate_add_to_blacklist' => 'blacklists a phone number in BulkGate',
	);

	/**
	 * Trigger settings where leaving the default in place silently widens who
	 * enters ("any tag", "any course") or means the automation never fires
	 * (spec §2 fact 10). The agent must state them explicitly; see
	 * FKMCP_Field_Translator::guard(). Every event whose get_default_values()
	 * sets a selector to "any" (or "wc-any"/"affwp-any"/"aff-any") has a row.
	 */
	const GUARDED = array(
		// Lite: CRM and WooCommerce.
		'crm_assigned_tag'                                   => array( 'tag-contains' ),
		'crm_unassigned_tag'                                 => array( 'tag-contains' ),
		'crm_assigned_list'                                  => array( 'list-contains' ),
		'crm_unassigned_list'                                => array( 'list-contains' ),
		'crm_link_trigger'                                   => array( 'link-contains' ),
		'crm_contact_subscribed'                             => array( 'run_for' ),
		'wc_new_order'                                       => array( 'order_status', 'order-contains' ),
		'wc_order_status_change'                             => array( 'from', 'to', 'order-contains' ),
		'wc_product_purchased'                               => array( 'order_status', 'order-contains' ),
		'cf7_form_submit'                                    => array( 'bwfan-cf7_form_submit_form_id' ),
		// Pro modules (modules/*/events, get_default_values()).
		'wp_user_role_changed'                               => array( 'from_user_roles', 'to_user_roles' ),
		'ld_user_added_to_group'                             => array( 'groups' ),
		'ld_user_remove_from_group'                          => array( 'groups' ),
		'ld_user_completes_course'                           => array( 'courses' ),
		'ld_user_course_access_expired'                      => array( 'courses' ),
		'ld_user_course_started'                             => array( 'courses' ),
		'ld_user_enrolled_into_course'                       => array( 'courses' ),
		'ld_user_removed_from_course'                        => array( 'courses' ),
		'ld_user_completes_lesson'                           => array( 'lessons' ),
		'ld_user_completes_topic'                            => array( 'topics' ),
		'ld_user_completes_quiz'                             => array( 'quizzes' ),
		'ms_user_completes_course'                           => array( 'courses' ),
		'ms_user_enrolled_into_course'                       => array( 'courses' ),
		'ms_user_removed_from_course'                        => array( 'courses' ),
		'ms_user_completes_lesson'                           => array( 'lessons' ),
		'ms_user_attempts_quiz'                              => array( 'quizzes' ),
		'mepr_user_membership_cancelled'                     => array( 'products' ),
		'mepr_user_membership_expired'                       => array( 'products' ),
		'mepr_user_membership_paused'                        => array( 'products' ),
		'mepr_user_purchases_one_time_subscription_product'  => array( 'products' ),
		'mepr_user_purchases_recurring_subscription_product' => array( 'products' ),
		'wcm_membership_created'                             => array( 'membership-contains' ),
		'wcm_status_changed'                                 => array( 'from', 'to' ),
		'wcs_created'                                        => array( 'subscription-contains' ),
		'wcs_status_changed'                                 => array( 'from', 'to', 'subscription-contains' ),
		'sublium_created'                                    => array( 'subscription-contains' ),
		'sublium_installments_completed'                     => array( 'subscription-contains' ),
		'sublium_renewal_payment_complete'                   => array( 'subscription-contains' ),
		'sublium_renewal_payment_failed'                     => array( 'subscription-contains' ),
		'sublium_status_changed'                             => array( 'from', 'to', 'subscription-contains' ),
		'sublium_trial_end'                                  => array( 'subscription-contains' ),
		'sublium_upgraded'                                   => array( 'subscription-contains' ),
		'affwp_status_change'                                => array( 'from', 'to' ),
		'affwp_referral_status_change'                       => array( 'from', 'to' ),
		'yith_affiliates_status_changed'                     => array( 'from', 'to' ),
		'yith_affiliates_ban_status_changed'                 => array( 'ban_filter' ),
		'stripe_offer_rejected'                              => array( 'offer-contains', 'bump-contains' ),
	);

	/** Goal settings the runtime never meets when left empty (research C §7): required. */
	const GOAL_REQUIRED = array(
		'wc_new_order'     => array( 'order_status' ),
		'crm_link_trigger' => array( 'link_trigger' ),
	);

	/** Goal settings the schema requires but the runtime ignores: defaulted, so the agent needn't send them. */
	const GOAL_DEFAULTS = array(
		'crm_contact_subscribed' => array( 'run_for' => 'any' ),
	);

	private static $memo = array();

	public static function reset() {
		self::$memo = array();
	}

	public static function event_obj( $slug ) {
		$event = BWFAN_Core()->sources->get_event( (string) $slug );

		return is_object( $event ) ? $event : null;
	}

	public static function event_slugs() {
		if ( ! isset( self::$memo['event_slugs'] ) ) {
			self::$memo['event_slugs'] = array_keys( (array) BWFAN_Core()->sources->get_events() );
		}

		return self::$memo['event_slugs'];
	}

	public static function event( $slug ) {
		$key = 'event:' . $slug;

		if ( array_key_exists( $key, self::$memo ) ) {
			return self::$memo[ $key ];
		}

		$descriptor = null;
		$event      = self::event_obj( $slug );

		if ( null !== $event ) {
			try {
				$data = $event->get_event_data_for_api( $slug );
			} catch ( Throwable $e ) {
				$data = array();
			}

			if ( ! empty( $data ) && is_array( $data ) ) {
				$fields = isset( $data['fields'] ) && is_array( $data['fields'] ) ? $data['fields'] : array();

				$descriptor = array(
					'kind'            => 'event',
					'slug'            => (string) $slug,
					'name'            => isset( $data['event_name'] ) ? (string) $data['event_name'] : (string) $slug,
					'source'          => isset( $data['source_type'] ) ? (string) $data['source_type'] : '',
					'fields'          => $fields,
					'defaults'        => isset( $data['default_values'] ) && is_array( $data['default_values'] ) ? $data['default_values'] : array(),
					'need_unique_key' => ! empty( $data['need_unique_key'] ),
					'has_common_run'  => in_array( 'bwfan_automation_run', array_column( $fields, 'id' ), true ),
				);
			}
		}

		self::$memo[ $key ] = $descriptor;

		return $descriptor;
	}

	/**
	 * Usable actions for a trigger, exactly as the builder lists them, less
	 * the lock placeholders (catalogue entries that can't be used here).
	 */
	public static function actions( $event ) {
		$key = 'actions:' . $event;

		if ( isset( self::$memo[ $key ] ) ) {
			return self::$memo[ $key ];
		}

		$usable = array();
		$locked = array();

		try {
			$all = BWFAN_Load_Integrations::get_available_actions( (string) $event );
		} catch ( Throwable $e ) {
			$all = array();
		}

		foreach ( (array) $all as $slug => $data ) {
			if ( ! is_array( $data ) ) {
				continue;
			}

			if ( ! empty( $data['lock'] ) || ! isset( $data['fields'] ) ) {
				$locked[ (string) $slug ] = true;
				continue;
			}

			$usable[ (string) $slug ] = array(
				'kind'        => 'action',
				'slug'        => (string) $slug,
				'name'        => isset( $data['action_name'] ) ? (string) $data['action_name'] : (string) $slug,
				'integration' => isset( $data['integration_slug'] ) ? (string) $data['integration_slug'] : '',
				'nicename'    => isset( $data['integration_nicename'] ) && is_scalar( $data['integration_nicename'] ) ? (string) $data['integration_nicename'] : null,
				'fields'      => is_array( $data['fields'] ) ? $data['fields'] : array(),
				'defaults'    => isset( $data['default_values'] ) && is_array( $data['default_values'] ) ? $data['default_values'] : array(),
			);
		}

		self::$memo[ $key ]            = $usable;
		self::$memo[ 'locked:' . $event ] = $locked;

		return $usable;
	}

	public static function action( $slug, $event ) {
		$actions = self::actions( $event );

		return isset( $actions[ $slug ] ) ? $actions[ $slug ] : null;
	}

	/**
	 * Every goal the builder offers, keyed by slug: the list the automation GET
	 * hands the goal picker (L/includes/class-bwfan-automation-v2.php:117 →
	 * BWFAN_Load_Sources::get_api_event_list_data( true )). Any goal works under
	 * any trigger. Fields and defaults are the goal's own (get_goal_data_for_api()),
	 * not the trigger's. Read once per request.
	 */
	public static function goals() {
		if ( isset( self::$memo['goals'] ) ) {
			return self::$memo['goals'];
		}

		try {
			$list = class_exists( 'BWFAN_Load_Sources' ) ? BWFAN_Load_Sources::get_api_event_list_data( true ) : array();
		} catch ( Throwable $e ) {
			$list = array();
		}

		$out = array();
		foreach ( (array) $list as $slug => $data ) {
			// A non-v2 goal comes back as a junk {source_label:''} entry with no fields.
			if ( ! is_array( $data ) || empty( $data['fields'] ) || ! is_array( $data['fields'] ) ) {
				continue;
			}

			$slug     = (string) $slug;
			$defaults = isset( $data['default_values'] ) && is_array( $data['default_values'] ) ? $data['default_values'] : array();

			$out[ $slug ] = array(
				'kind'         => 'goal',
				'slug'         => $slug,
				'name'         => isset( $data['event_name'] ) ? (string) $data['event_name'] : $slug,
				'source'       => isset( $data['source_type'] ) ? (string) $data['source_type'] : '',
				'source_label' => isset( $data['source_label'] ) && is_scalar( $data['source_label'] ) ? (string) $data['source_label'] : null,
				'fields'       => $data['fields'],
				'defaults'     => array_merge( isset( self::GOAL_DEFAULTS[ $slug ] ) ? self::GOAL_DEFAULTS[ $slug ] : array(), $defaults ),
			);
		}

		self::$memo['goals'] = $out;

		return $out;
	}

	public static function goal( $slug ) {
		$goals = self::goals();

		return isset( $goals[ $slug ] ) ? $goals[ $slug ] : null;
	}

	/** Why a catalogue action can't be used here, or null when it can (or doesn't exist). */
	public static function locked_reason( $slug, $event ) {
		self::actions( $event );

		if ( empty( self::$memo[ 'locked:' . $event ][ $slug ] ) ) {
			return null;
		}

		return __( 'This action is not available here: it does not work with this trigger, or the plugin or connector it needs is not active on this site.', 'wp-marketing-automations-pro' );
	}

	/** "connect <name>" when the action's connector isn't connected, else null. */
	public static function connector_need( $integration ) {
		$int = BWFAN_Core()->integration->get_integration( (string) $integration );

		if ( ! is_object( $int ) || ! method_exists( $int, 'need_connector' ) || ! $int->need_connector() ) {
			return null;
		}

		if ( BWFAN_Core()->connectors->is_connected( $int->get_connector_slug() ) ) {
			return null;
		}

		/* translators: %s: connector name, e.g. Keap */
		return sprintf( __( 'connect %s', 'wp-marketing-automations-pro' ), $int->get_name() );
	}

	public static function is_denied( $action ) {
		return in_array( (string) $action, (array) apply_filters( 'fkmcp_definition_denied_actions', array() ), true );
	}

	public static function sensitive_reason( $action ) {
		$list = (array) apply_filters( 'fkmcp_definition_sensitive_actions', self::SENSITIVE );

		return isset( $list[ $action ] ) ? (string) $list[ $action ] : null;
	}

	public static function guarded_fields( $event ) {
		return isset( self::GUARDED[ $event ] ) ? self::GUARDED[ $event ] : array();
	}

	/**
	 * Merge tag names valid in this trigger's texts: its groups plus
	 * bwfan_default, V2 tags only. $delay_only narrows to the tags a date
	 * wait may use.
	 *
	 * @return array<string, true>
	 */
	public static function merge_tags( $event, $delay_only = false ) {
		$key = 'tags:' . $event . ':' . ( $delay_only ? 'delay' : 'all' );

		if ( isset( self::$memo[ $key ] ) ) {
			return self::$memo[ $key ];
		}

		$obj  = self::event_obj( $event );
		$tags = array();

		if ( null !== $obj ) {
			// get_merge_tag_groups() appends bwfan_default on every call; dedupe.
			$groups = array_unique( array_merge( (array) $obj->get_merge_tag_groups(), array( 'bwfan_default' ) ) );
			$all    = (array) BWFAN_Core()->merge_tags->get_all_merge_tags();

			foreach ( $groups as $group ) {
				if ( empty( $all[ $group ] ) || ! is_array( $all[ $group ] ) ) {
					continue;
				}

				foreach ( $all[ $group ] as $tag ) {
					if ( ! is_object( $tag ) || ! $tag->is_support_v2() || ( $delay_only && ! $tag->is_delay_variable() ) ) {
						continue;
					}

					$tags[ (string) $tag->get_name() ] = true;
				}
			}

			// Custom contact fields render through one tag with a key attribute.
			if ( ! $delay_only && isset( $all['bwf_contact']['bwfan_contact_field'] ) ) {
				$tags['contact_field'] = true;
			}
		}

		self::$memo[ $key ] = $tags;

		return $tags;
	}
}
