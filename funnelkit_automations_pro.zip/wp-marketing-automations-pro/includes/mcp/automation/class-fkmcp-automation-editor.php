<?php

defined( 'ABSPATH' ) || exit;

/**
 * update-automation's planning and its safety net (spec §16). The pure methods
 * decide which old rows to keep, what to write and what to refuse. snapshot() and
 * restore() put an automation back exactly as it was when anything after the
 * snapshot fails. Restore points can't be used for that: nothing restores from them.
 */
class FKMCP_Automation_Editor {

	/** Row statuses an update may reuse: new, active, incomplete, disabled. Never deleted (3) or archived (4). */
	const REUSABLE = array( 0, 1, 2, 5 );

	/** A split's runtime data, kept on a reused split (mail_steps is recomputed after the graph save). */
	const SPLIT_RUNTIME = array( 'last_run', 'winner', 'split_stats', 'complete_time', 'mail_steps' );

	/** Main-table columns restore() writes back (ID is the key, never written). */
	const MAIN_COLUMNS = array( 'source', 'event', 'status', 'priority', 'start', 'v', 'benchmark', 'title', 'category' );

	/** temp id => old row id, for each new step with an old step of the same type at the same path. */
	public static function match( array $paths, array $types, array $positions, array $rows ) {
		$reuse = array();
		$used  = array();

		foreach ( $paths as $i => $path ) {
			if ( ! isset( $positions[ $path ] ) ) {
				continue;
			}
			$old = $positions[ $path ];
			$id  = (int) $old['id'];
			if ( ! isset( $types[ $i ] ) || $old['type'] !== $types[ $i ] || isset( $used[ $id ] ) || ! isset( $rows[ $id ] ) || ! in_array( (int) $rows[ $id ]['status'], self::REUSABLE, true ) ) {
				continue;
			}
			$reuse[ $i + 1 ] = $id;
			$used[ $id ]     = true;
		}

		return $reuse;
	}

	/** One write per reused row that differs from its old self (a split's runtime keys merged back first). */
	public static function row_writes( array $old_rows, array $new_rows, array $reused_ids ) {
		$writes = array();

		foreach ( $reused_ids as $id ) {
			$id = (int) $id;
			if ( ! isset( $old_rows[ $id ], $new_rows[ $id ] ) ) {
				continue;
			}
			$old = $old_rows[ $id ];
			$new = $new_rows[ $id ];

			if ( 7 === (int) $new['type'] ) {
				$new['data'] = self::merge_split_runtime( $old['data'], $new['data'] );
			}

			$set = array(
				'type'   => (int) $new['type'],
				'action' => self::nullable( $new['action'] ),
				'data'   => self::nullable( $new['data'] ),
				'status' => (int) $new['status'],
			);
			if ( (int) $old['type'] === $set['type'] && self::nullable( $old['action'] ) === $set['action'] && self::nullable( $old['data'] ) === $set['data'] && (int) $old['status'] === $set['status'] ) {
				continue;
			}
			$writes[] = array(
				'id'  => $id,
				'set' => $set,
			);
		}

		return $writes;
	}

	/**
	 * What an update would change, for the review sheet (spec §4.1): per path new,
	 * changed or unchanged (by the same byte compare row_writes() writes by), and the
	 * rows it would remove with their old path (was_path) and title. Pure.
	 *
	 * @return array {changes: path => new|changed|unchanged, removed: [{path: "removed:<id>", was_path, id, title}], old: path => old sidebar}
	 */
	public static function review_changes( array $plan, array $reuse, array $snap_rows, array $positions, array $steps_meta ) {
		$map = $reuse;
		foreach ( $plan['paths'] as $i => $path ) {
			if ( ! isset( $map[ $i + 1 ] ) ) {
				$map[ $i + 1 ] = PHP_INT_MAX - ( $i + 1 ); // placeholder: positive, never a live id.
			}
		}
		$real    = FKMCP_Definition_Builder::remap( $plan, $map );
		$written = array();
		foreach ( self::row_writes( $snap_rows, $real['rows'], array_values( $reuse ) ) as $write ) {
			$written[ (int) $write['id'] ] = true;
		}

		$changes = array();
		$old     = array();
		foreach ( $plan['paths'] as $i => $path ) {
			if ( ! isset( $reuse[ $i + 1 ] ) ) {
				$changes[ $path ] = 'new';
				continue;
			}
			$id = (int) $reuse[ $i + 1 ];
			if ( isset( $written[ $id ] ) ) {
				$changes[ $path ] = 'changed';
				$data             = isset( $snap_rows[ $id ]['data'] ) ? json_decode( (string) $snap_rows[ $id ]['data'], true ) : null;
				$old[ $path ]     = isset( $data['sidebarData'] ) && is_array( $data['sidebarData'] ) ? $data['sidebarData'] : array();
			} else {
				$changes[ $path ] = 'unchanged';
			}
		}

		$path_of = array();
		foreach ( $positions as $path => $position ) {
			$path_of[ (int) $position['id'] ] = $path;
		}
		$node_of = array();
		foreach ( $steps_meta as $node ) {
			if ( is_array( $node ) && isset( $node['stepId'] ) && is_numeric( $node['stepId'] ) ) {
				$node_of[ (int) $node['stepId'] ] = $node;
			}
		}
		$removed = array();
		foreach ( array_unique( array_diff( self::graph_ids( $steps_meta ), array_map( 'intval', array_values( $reuse ) ) ) ) as $id ) {
			$node      = isset( $node_of[ $id ] ) ? $node_of[ $id ] : array();
			$title     = isset( $node['data']['label'] ) && is_string( $node['data']['label'] ) && '' !== trim( $node['data']['label'] ) ? $node['data']['label'] : 'Step ' . ( isset( $node['id'] ) && is_scalar( $node['id'] ) ? $node['id'] : $id );
			$removed[] = array(
				'path'     => 'removed:' . $id, // never the old path: a new step can take it (a type change), and the two required ids must differ
				'was_path' => isset( $path_of[ $id ] ) ? $path_of[ $id ] : null, // for display; past a legacy fork there is no position
				'id'       => $id,
				'title'    => FKMCP_Definition_Errors::untrust( FKMCP_Definition_Errors::clean( $title, 150 ) ), // the builder's label: site text, data only
			);
		}

		return array(
			'changes' => $changes,
			'removed' => $removed,
			'old'     => $old,
		);
	}

	/**
	 * On a live Automation (active, or contacts in it) only email content is saved
	 * (spec §3.5). The tree must be the same (paths, types, row ids). An email row
	 * may not change its action, status, recipients or transactional flag (a
	 * transactional email reaches unsubscribed contacts). A non-email row that
	 * differs is not written and not refused: builder-saved rows use keys the
	 * definition can't reproduce, so it is reported in ignored_paths instead.
	 * "Differs" is exactly row_writes()' comparison, so the two never disagree.
	 *
	 * @return array|string {writes: [{id, set:{data}}], paths, ignored_paths, warnings}, or why it is refused.
	 */
	public static function live_email_changes( array $positions, array $plan, array $reuse, array $old_rows, array $new_rows ) {
		$structure  = 'a step is added, removed, moved or changed type';
		$old_paths  = array();
		$path_of_id = array();
		foreach ( $positions as $path => $position ) {
			$old_paths[ $path ]                   = $position['type'];
			$path_of_id[ (int) $position['id'] ] = $path;
		}
		$new_paths = count( $plan['paths'] ) === count( $plan['types'] ) ? array_combine( $plan['paths'], $plan['types'] ) : array();
		ksort( $old_paths );
		ksort( $new_paths );
		if ( $old_paths !== $new_paths || count( $reuse ) !== count( $plan['export']['step_data'] ) ) {
			return $structure;
		}
		foreach ( $reuse as $id ) {
			if ( ! isset( $old_rows[ $id ], $new_rows[ $id ], $path_of_id[ (int) $id ] ) ) {
				return $structure; // row_writes() would skip it silently.
			}
		}

		$email = function ( $row ) {
			$d = json_decode( (string) $row['data'], true );
			$e = isset( $d['sidebarData']['bwfan_email_data']['data'] ) && is_array( $d['sidebarData']['bwfan_email_data']['data'] ) ? $d['sidebarData']['bwfan_email_data']['data'] : array();

			return array(
				'guard'  => array( isset( $d['sidebarData']['bwfan_email_to'] ) ? (string) $d['sidebarData']['bwfan_email_to'] : '', ! empty( $e['isTransactional'] ) ),
				'custom' => ! empty( $e['overrideSenderInfo'] ) || ! empty( $e['utmEnabled'] ), // the keys wp_sendemail reads
			);
		};

		$out = array(
			'writes'        => array(),
			'paths'         => array(),
			'ignored_paths' => array(),
			'warnings'      => array(),
		);
		foreach ( self::row_writes( $old_rows, $new_rows, array_values( $reuse ) ) as $write ) {
			$old  = $old_rows[ $write['id'] ];
			$path = $path_of_id[ $write['id'] ];
			if ( 'email' !== FKMCP_Saved_Tree::type_of( $old ) ) {
				$out['ignored_paths'][] = $path;
				continue;
			}
			if ( (int) $old['type'] !== $write['set']['type'] ) {
				return $structure;
			}
			$was = $email( $old );
			$now = $email( $new_rows[ $write['id'] ] );
			if ( self::nullable( $old['action'] ) !== $write['set']['action'] || (int) $old['status'] !== $write['set']['status'] || $was['guard'] !== $now['guard'] ) {
				return 'an email\'s recipients, action or status changed';
			}
			$out['writes'][] = array(
				'id'  => $write['id'],
				'set' => array( 'data' => (string) $write['set']['data'] ),
			);
			$out['paths'][]  = $path;
			if ( $was['custom'] && ! $now['custom'] ) {
				/* translators: %s: the step's path, e.g. steps[0] */
				$out['warnings'][] = sprintf( __( '%s: the builder\'s custom sender / UTM settings on this email were reset to defaults.', 'wp-marketing-automations-pro' ), $path );
			}
		}

		return $out;
	}

	/**
	 * On a live Automation the trigger may not change: the same event, and every
	 * setting the agent sent (run / enter_on_active_contact included) equal to the
	 * stored one, strictly, key order aside. Settings not sent are not compared:
	 * the builder stores keys a definition can't reproduce. '' when unchanged.
	 */
	public static function live_trigger_change( array $trigger, array $plan, array $old_meta, $old_event ) {
		if ( $plan['event'] !== (string) $old_event ) {
			return 'the trigger changed';
		}
		$sent = isset( $trigger['settings'] ) && is_array( $trigger['settings'] ) ? array_keys( $trigger['settings'] ) : array();
		foreach ( array_keys( FKMCP_Definition_Builder::TRIGGER_ALIASES ) as $key ) {
			if ( array_key_exists( $key, $trigger ) ) {
				$sent[] = $key;
			}
		}
		$sorted = function ( $value ) use ( &$sorted ) {
			if ( is_array( $value ) ) {
				ksort( $value );
				$value = array_map( $sorted, $value );
			}

			return $value;
		};
		foreach ( $sent as $key ) {
			$id = isset( FKMCP_Definition_Builder::TRIGGER_ALIASES[ $key ] ) ? FKMCP_Definition_Builder::TRIGGER_ALIASES[ $key ] : (string) $key;
			$in = array_key_exists( $id, $plan['event_meta'] );
			if ( $in !== array_key_exists( $id, $old_meta ) || ( $in && $sorted( $plan['event_meta'][ $id ] ) !== $sorted( $old_meta[ $id ] ) ) ) {
				return 'the trigger changed';
			}
		}

		return '';
	}

	/** Problems for {{wc_dynamic_coupon id="N"}} naming anything but a Create Coupon row this update keeps. */
	public static function coupon_problems( array $step_data, array $paths, array $reuse ) {
		$coupons = array();
		foreach ( $reuse as $temp => $id ) {
			$action = isset( $step_data[ $temp ]['action'] ) && is_string( $step_data[ $temp ]['action'] ) ? json_decode( $step_data[ $temp ]['action'], true ) : null;
			if ( isset( $action['action'] ) && in_array( $action['action'], FKMCP_Definition_Builder::COUPON_CREATORS, true ) ) {
				$coupons[ (int) $id ] = true;
			}
		}

		$problems = array();
		foreach ( $step_data as $temp => $row ) {
			foreach ( self::coupon_ids( isset( $row['data'] ) ? $row['data'] : null ) as $id ) {
				if ( ! isset( $coupons[ $id ] ) ) {
					$problems[] = array(
						'path' => isset( $paths[ $temp - 1 ] ) ? $paths[ $temp - 1 ] : 'steps',
						'id'   => $id,
					);
				}
			}
		}

		return $problems;
	}

	/** The trigger's new event_meta: the plan's, keeping the key and the stored sample when the event is unchanged. */
	public static function event_meta( array $plan, array $old_event_meta, $old_event ) {
		$meta = $plan['event_meta'];
		unset( $meta['bwfan_unique_key'] ); // build() marks it 'pending'; import() would have made one, update decides here.

		if ( $plan['event'] === $old_event ) {
			foreach ( array( 'bwfan_unique_key', 'webhook_data', 'received_at', 'referer' ) as $key ) {
				if ( array_key_exists( $key, $old_event_meta ) ) {
					$meta[ $key ] = $old_event_meta[ $key ];
				}
			}
		}

		if ( ! empty( $plan['need_unique_key'] ) && empty( $meta['bwfan_unique_key'] ) ) {
			$meta['bwfan_unique_key'] = wp_generate_password( 32, false );
		}

		return $meta;
	}

	/** The row ids a saved graph points at (chips and pseudo-nodes have none). */
	public static function graph_ids( array $nodes ) {
		$ids = array();
		foreach ( $nodes as $node ) {
			if ( is_array( $node ) && isset( $node['stepId'] ) && is_numeric( $node['stepId'] ) && (int) $node['stepId'] > 0 ) {
				$ids[] = (int) $node['stepId'];
			}
		}

		return $ids;
	}

	/** One meta value from a snapshot, unserialized; null when absent. */
	public static function meta_value( array $snap, $key ) {
		foreach ( $snap['meta'] as $meta ) {
			if ( $key === $meta['meta_key'] ) {
				return maybe_unserialize( $meta['meta_value'] );
			}
		}

		return null;
	}

	// ─── I/O ──────────────────────────────────────────────────────

	/** The main row, straight from the table (the V2 and WooFunnels caches go stale within a request). */
	public static function main_row( $aid ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}bwfan_automations WHERE `ID` = %d", absint( $aid ) ), ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery

		return empty( $row ) ? null : $row;
	}

	/** Contacts in the automation, any status: paused, failed and waiting ones resume at a step id (spec §16). */
	public static function contact_count( $aid ) {
		global $wpdb;

		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}bwfan_automation_contact WHERE `aid` = %d", absint( $aid ) ) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery
	}

	/** Everything an update can change, raw: 3 queries. */
	public static function snapshot( $aid ) {
		global $wpdb;
		$aid  = absint( $aid );
		$meta = array();
		foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT `ID`, `meta_key`, `meta_value` FROM {$wpdb->prefix}bwfan_automationmeta WHERE `bwfan_automation_id` = %d ORDER BY `ID` ASC", $aid ), ARRAY_A ) as $r ) { //phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$meta[ (int) $r['ID'] ] = array(
				'meta_key'   => (string) $r['meta_key'],
				'meta_value' => $r['meta_value'],
			);
		}
		$rows = array();
		foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}bwfan_automation_step WHERE `aid` = %d ORDER BY `ID` ASC", $aid ), ARRAY_A ) as $r ) { //phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$rows[ (int) $r['ID'] ] = $r;
		}

		return array(
			'row'  => self::main_row( $aid ),
			'meta' => $meta,
			'rows' => $rows,
		);
	}

	/** What restore() must do to turn $now back into $snap. Pure. */
	public static function restore_ops( array $snap, array $now ) {
		$ops  = array();
		$main = array();
		foreach ( $snap['row'] as $col => $value ) {
			if ( 'ID' !== $col && ( ! array_key_exists( $col, $now['row'] ) || $now['row'][ $col ] !== $value ) ) {
				$main[ $col ] = $value;
			}
		}
		if ( ! empty( $main ) ) {
			$ops[] = array(
				'op'  => 'main',
				'set' => $main,
			);
		}

		foreach ( array_diff_key( $now['meta'], $snap['meta'] ) as $id => $unused ) {
			$ops[] = array(
				'op' => 'meta_delete',
				'id' => (int) $id,
			);
		}
		foreach ( $snap['meta'] as $id => $meta ) {
			if ( ! isset( $now['meta'][ $id ] ) || $now['meta'][ $id ] !== $meta ) {
				$ops[] = array(
					'op'         => 'meta_put',
					'id'         => (int) $id,
					'meta_key'   => $meta['meta_key'],
					'meta_value' => $meta['meta_value'],
					'insert'     => ! isset( $now['meta'][ $id ] ),
				);
			}
		}

		foreach ( array_diff_key( $now['rows'], $snap['rows'] ) as $id => $unused ) {
			$ops[] = array(
				'op' => 'step_delete',
				'id' => (int) $id,
			);
		}
		foreach ( $snap['rows'] as $id => $row ) {
			if ( ! isset( $now['rows'][ $id ] ) || $now['rows'][ $id ] !== $row ) {
				$set = $row;
				unset( $set['ID'] );
				$ops[] = array(
					'op'     => 'step_put',
					'id'     => (int) $id,
					'row'    => $set,
					'insert' => ! isset( $now['rows'][ $id ] ),
				);
			}
		}

		return $ops;
	}

	/**
	 * Puts the automation back as $snap had it. Every statement is scoped to this
	 * automation. Throws on the first failed write, so the caller reports it.
	 */
	public static function restore( $aid, array $snap ) {
		global $wpdb;
		$aid = absint( $aid );

		foreach ( self::restore_ops( $snap, self::snapshot( $aid ) ) as $op ) {
			switch ( $op['op'] ) {
				case 'main':
					$ok = false !== $wpdb->update( $wpdb->prefix . 'bwfan_automations', array_intersect_key( $op['set'], array_flip( self::MAIN_COLUMNS ) ), array( 'ID' => $aid ) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery
					break;
				case 'meta_delete':
					$ok = false !== $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}bwfan_automationmeta WHERE `ID` = %d AND `bwfan_automation_id` = %d", $op['id'], $aid ) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery
					break;
				case 'meta_put':
					$ok = $op['insert']
						? false !== $wpdb->insert( $wpdb->prefix . 'bwfan_automationmeta', array( 'ID' => $op['id'], 'bwfan_automation_id' => $aid, 'meta_key' => $op['meta_key'], 'meta_value' => $op['meta_value'] ) ) //phpcs:ignore WordPress.DB.DirectDatabaseQuery
						: false !== $wpdb->update( $wpdb->prefix . 'bwfan_automationmeta', array( 'meta_key' => $op['meta_key'], 'meta_value' => $op['meta_value'] ), array( 'ID' => $op['id'], 'bwfan_automation_id' => $aid ) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery
					break;
				case 'step_delete':
					$ok = false !== $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}bwfan_automation_step WHERE `ID` = %d AND `aid` = %d", $op['id'], $aid ) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery
					break;
				default: // step_put
					$op['row']['aid'] = $aid; // Never let a restored row re-point at another automation.
					$ok               = $op['insert']
						? false !== $wpdb->insert( $wpdb->prefix . 'bwfan_automation_step', array( 'ID' => $op['id'] ) + $op['row'] ) //phpcs:ignore WordPress.DB.DirectDatabaseQuery
						: false !== $wpdb->update( $wpdb->prefix . 'bwfan_automation_step', $op['row'], array( 'ID' => $op['id'], 'aid' => $aid ) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery
			}
			if ( ! $ok ) {
				throw new RuntimeException( 'restore failed at ' . $op['op'] );
			}
		}

		BWFAN_Automation_V2::unset_instance( $aid );
	}

	// ─── helpers ──────────────────────────────────────────────────

	private static function merge_split_runtime( $old_data, $new_data ) {
		$old = is_string( $old_data ) ? json_decode( $old_data, true ) : null;
		$new = is_string( $new_data ) ? json_decode( $new_data, true ) : null;
		if ( ! isset( $old['sidebarData'], $new['sidebarData'] ) || ! is_array( $old['sidebarData'] ) || ! is_array( $new['sidebarData'] ) ) {
			return $new_data;
		}

		// A path-count change can leave a stale winner pointing at a path that no
		// longer exists (Lite's split-test controller returns winner_path
		// unconditionally), so nothing runtime carries over.
		if ( isset( $old['sidebarData']['split_path'], $new['sidebarData']['split_path'] ) && (int) $old['sidebarData']['split_path'] !== (int) $new['sidebarData']['split_path'] ) {
			return $new_data;
		}

		$kept = array_intersect_key( $old['sidebarData'], array_flip( self::SPLIT_RUNTIME ) );
		if ( empty( $kept ) ) {
			return $new_data;
		}
		$new['sidebarData'] = $new['sidebarData'] + $kept;

		// The old row's key order, so an unchanged split compares equal byte for byte.
		$ordered = array();
		foreach ( array_keys( $old['sidebarData'] ) as $key ) {
			if ( array_key_exists( $key, $new['sidebarData'] ) ) {
				$ordered[ $key ] = $new['sidebarData'][ $key ];
			}
		}
		$new['sidebarData'] = $ordered + $new['sidebarData'];

		return wp_json_encode( $new );
	}

	private static function coupon_ids( $data_json ) {
		if ( ! is_string( $data_json ) || false === stripos( $data_json, 'wc_dynamic_coupon' ) ) {
			return array();
		}
		$ids  = array();
		$walk = function ( $value ) use ( &$walk, &$ids ) {
			if ( is_array( $value ) ) {
				foreach ( $value as $v ) {
					$walk( $v );
				}

				return;
			}
			if ( is_string( $value ) ) {
				$value = FKMCP_Definition_Builder::block_attr_quotes( $value );
			}
			// {{ becomes a WP shortcode at runtime: attribute names are case-insensitive and can come in any order.
			if ( is_string( $value ) && preg_match_all( '/\{\{\s*wc_dynamic_coupon\b[^}]*?\bid\s*=\s*(?:"|\'|&quot;|&#039;)?(\d+)/i', $value, $m ) ) {
				foreach ( $m[1] as $id ) {
					$ids[] = (int) $id;
				}
			}
		};
		$walk( json_decode( $data_json, true ) );

		return array_values( array_unique( $ids ) );
	}

	private static function nullable( $value ) {
		return null === $value || '' === $value ? null : (string) $value;
	}
}
