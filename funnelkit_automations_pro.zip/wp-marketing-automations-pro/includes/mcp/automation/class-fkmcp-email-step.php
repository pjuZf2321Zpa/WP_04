<?php

defined( 'ABSPATH' ) || exit;

/**
 * An automation email step built from a saved email template (spec §3.2): the
 * template is copied by value, exactly as the builder's Import does. Mode 5
 * (block editor) is re-checked by the email-design validator for this
 * automation and copied with its stored HTML and block; modes 1-3 are handed
 * back as a body for the ordinary kses path. No hooks; design classes load only
 * through the checker, only for a mode-5 template.
 */
class FKMCP_Email_Step {

	/** @var callable ( array $row, array $input ): array|WP_Error - FKMCP_Pack_Email_Design::automation_copy */
	public static $checker = array( 'FKMCP_Pack_Email_Design', 'automation_copy' );

	/** @var callable ( array $row ): string - FKMCP_Pack_Email_Design::template_revision */
	public static $reviser = array( 'FKMCP_Pack_Email_Design', 'template_revision' );

	/** @var callable ( string $html, string $title ): array{url, expires} - FKMCP_Pack_Email_Design::automation_preview */
	public static $previewer = array( 'FKMCP_Pack_Email_Design', 'automation_preview' );

	/** @var callable ( array $design, array $settings, array $input ): array|WP_Error - FKMCP_Pack_Email_Design::automation_design */
	public static $designer = array( 'FKMCP_Pack_Email_Design', 'automation_design' );

	/** Inline block designs one definition may carry (each loads and runs the renderer). */
	const MAX_DESIGNS = 10;

	/**
	 * Sample-data (context none) preview links, 1 h, for the designed emails a
	 * successful save just wrote (spec §0; M5a Task 7). Never runs for a mode
	 * 1-3 email, a kept one, or one whose path was not written this call - the
	 * caller signals that by leaving its path out of $path_to_id. A preview
	 * failure (any Throwable, or the previewer itself returning no url) never
	 * fails the save: preview_url is left null and preview_error is set, so the
	 * caller can add a warning naming the path.
	 *
	 * @return array $emails, each designed non-kept written entry with preview_url/expires (or preview_error).
	 */
	public static function previews( array $emails, array $rows_by_id, array $path_to_id ) {
		foreach ( $emails as &$email ) {
			if ( empty( $email['designed'] ) || ! empty( $email['kept'] ) || ! isset( $path_to_id[ $email['path'] ] ) ) {
				continue;
			}
			$row  = isset( $rows_by_id[ $path_to_id[ $email['path'] ] ] ) ? $rows_by_id[ $path_to_id[ $email['path'] ] ] : null;
			$data = null === $row ? null : json_decode( (string) $row['data'], true );
			$html = isset( $data['sidebarData']['bwfan_email_data']['template'] ) ? (string) $data['sidebarData']['bwfan_email_data']['template'] : '';
			try {
				$page = '' === $html ? array( 'url' => null, 'expires' => null ) : call_user_func( self::$previewer, $html, isset( $data['sidebarData']['bwfan_email_data']['subject'] ) ? (string) $data['sidebarData']['bwfan_email_data']['subject'] : '' );
			} catch ( Throwable $e ) {
				$page = array( 'url' => null, 'expires' => null );
			}
			$email['preview_url'] = isset( $page['url'] ) ? $page['url'] : null;
			$email['expires']     = isset( $page['expires'] ) ? $page['expires'] : null;
			if ( null === $email['preview_url'] ) {
				$email['preview_error'] = true;
			}
		}
		unset( $email );

		return $emails;
	}

	/** Saved templates (type 1, canned 1) by id, one query; ids that are not saved are simply absent. */
	public static function load_templates( array $ids ) {
		$ids = array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
		if ( empty( $ids ) ) {
			return array();
		}

		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT `ID`, `subject`, `template`, `title`, `mode`, `data` FROM {$wpdb->prefix}bwfan_templates WHERE `type` = 1 AND `canned` = 1 AND `ID` IN (" . implode( ',', array_fill( 0, count( $ids ), '%d' ) ) . ')', $ids ), ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare

		$out = array();
		foreach ( (array) $rows as $row ) {
			$out[ (int) $row['ID'] ] = $row;
		}

		return $out;
	}

	/**
	 * @return array|null {mode, template, block, subject_default, preheader_default, warnings, ref}; null after errors.
	 */
	public static function template_body( array $step, array $tpl, $path, FKMCP_Definition_Errors $errors, array $ctx ) {
		// The email-design pack may be filtered off (spec §0.2.1 lazy loading); refuse cleanly rather than
		// fatal. Checked first: the reviser runs unconditionally below (every mode gets a template_ref).
		if ( ! is_callable( self::$checker ) || ! is_callable( self::$reviser ) ) {
			$errors->add( $path . '.template_id', __( 'this site cannot re-check designed email templates right now; try again later.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$mode = (int) $tpl['mode'];
		$data = is_string( $tpl['data'] ) ? json_decode( $tpl['data'], true ) : ( is_array( $tpl['data'] ) ? $tpl['data'] : array() );
		$data = is_array( $data ) ? $data : array();
		$ref  = array(
			'id'       => (int) $tpl['ID'],
			'revision' => (string) call_user_func( self::$reviser, $tpl ),
		);
		$base = array(
			'mode'              => $mode,
			'block'             => null,
			'subject_default'   => (string) $tpl['subject'],
			'preheader_default' => isset( $data['preheader'] ) && is_string( $data['preheader'] ) ? $data['preheader'] : '',
			'warnings'          => array(),
			'ref'               => $ref,
		);

		if ( in_array( $mode, array( 1, 2, 3 ), true ) ) {
			return $base + array( 'template' => (string) $tpl['template'] );
		}

		if ( 5 !== $mode ) {
			$errors->add( $path . '.template_id', __( 'is a legacy drag-and-drop template; open it in the builder and save it in the block editor first.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$copy = call_user_func(
			self::$checker,
			$tpl,
			array(
				'event'         => isset( $ctx['event'] ) ? (string) $ctx['event'] : '',
				'automation_id' => isset( $ctx['automation_id'] ) ? absint( $ctx['automation_id'] ) : 0,
				'transactional' => ! empty( $step['transactional'] ),
			)
		);
		if ( is_wp_error( $copy ) ) {
			$errors->add( $path . '.template_id', FKMCP_Definition_Errors::clean( $copy->get_error_message(), 300 ) );

			return null;
		}
		if ( ! empty( $copy['blocking'] ) ) {
			foreach ( $copy['blocking'] as $finding ) {
				/* translators: 1: finding code, 2: where in the design, 3: message */
				$errors->add( $path . '.template_id', sprintf( __( '%1$s at %2$s: %3$s', 'wp-marketing-automations-pro' ), FKMCP_Definition_Errors::clean( esc_html( $finding['code'] ), 100 ), FKMCP_Definition_Errors::clean( esc_html( $finding['path'] ), 100 ), FKMCP_Definition_Errors::clean( esc_html( $finding['message'] ), 300 ) ) );
			}

			return null;
		}

		$base['block'] = $copy['block'];
		foreach ( $copy['warnings'] as $warning ) {
			// No path prefix here: the definition builder's row-warning loop already prefixes every
			// step's warnings with its own path, so prefixing here too would read "steps[0]: steps[0]: …".
			$base['warnings'][] = FKMCP_Definition_Errors::clean( esc_html( $warning ), 300 );
		}

		return $base + array( 'template' => (string) $copy['html'] );
	}

	/**
	 * An inline block design, validated and rendered for this automation.
	 *
	 * @return array|null the template_body() shape; null after errors.
	 */
	public static function design_body( array $step, $path, FKMCP_Definition_Errors $errors, array $ctx ) {
		if ( ! is_callable( self::$designer ) ) {
			$errors->add( $path . '.design', __( 'this site cannot build designed emails right now; try again later.', 'wp-marketing-automations-pro' ) );

			return null;
		}
		$settings = isset( $step['design_settings'] ) ? $step['design_settings'] : array();
		$built    = call_user_func(
			self::$designer,
			$step['design'],
			$settings,
			array(
				'event'          => isset( $ctx['event'] ) ? (string) $ctx['event'] : '',
				'automation_id'  => isset( $ctx['automation_id'] ) ? absint( $ctx['automation_id'] ) : 0,
				'transactional'  => ! empty( $step['transactional'] ),
				'measure_budget' => isset( $ctx['measure_budget'] ) ? (string) $ctx['measure_budget'] : null,
			)
		);
		if ( is_wp_error( $built ) ) {
			$errors->add( $path . '.design', FKMCP_Definition_Errors::clean( esc_html( $built->get_error_message() ), 300 ) );

			return null;
		}
		if ( ! empty( $built['blocking'] ) ) {
			foreach ( $built['blocking'] as $finding ) {
				/* translators: 1: finding code, 2: where in the design, 3: message */
				$errors->add( $path . '.design', sprintf( __( '%1$s at %2$s: %3$s', 'wp-marketing-automations-pro' ), FKMCP_Definition_Errors::clean( esc_html( $finding['code'] ), 100 ), FKMCP_Definition_Errors::clean( esc_html( $finding['path'] ), 100 ), FKMCP_Definition_Errors::clean( esc_html( $finding['message'] ), 300 ) ) );
			}

			return null;
		}
		$warnings = array();
		foreach ( $built['warnings'] as $warning ) {
			$warnings[] = FKMCP_Definition_Errors::clean( esc_html( $warning ), 300 );
		}

		return array(
			'mode'              => 5,
			'template'          => (string) $built['html'],
			'block'             => $built['block'],
			'subject_default'   => '',
			'preheader_default' => '',
			'warnings'          => $warnings,
			'ref'               => null,
		);
	}
}
