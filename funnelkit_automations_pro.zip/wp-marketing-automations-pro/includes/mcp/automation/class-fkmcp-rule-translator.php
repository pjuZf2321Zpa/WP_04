<?php

defined( 'ABSPATH' ) || exit;

/** Thrown by the wp_die() handler installed around a rule's own get_options() call. */
class FKMCP_Rule_Halt extends RuntimeException {
}

/**
 * Condition and branch rules: an agent's [[{rule, operator, value}]] (outer
 * list OR, inner AND) → the [[{filter, rule, data}]] the builder saves. Only
 * rules the admin itself lists for the trigger are accepted, only with their
 * own operators, and only values the runtime reads the way the agent means:
 * every value shape that would make a rule match everyone is refused (spec
 * §15.4). Nothing here writes; search values never create tags or lists.
 */
class FKMCP_Rule_Translator {
	const GROUPS_MAX = 10;

	const RULES_MAX = 20;

	const TEXT_MAX = 500;

	const DAYS_MAX = 36500;

	/** contact_dob_days: the runtime clamps to 0..365 (bwf-contact.php:2647-2653). */
	const DOB_DAYS_MAX = 365;

	const QTY_MAX = 100000;

	/** Options read from one rule, at most. */
	const OPTIONS_MAX = 500;

	/** Rule types an assistant can set: the §15.4 table. */
	const TYPES = array( 'Text', 'Number', 'time', 'datetime', 'Date', 'Days', 'Select', 'Search', 'key-value', 'product-qty' );

	const NUM_OPS = array( '==', '!=', '>', '<', '>=', '<=' );

	const NUM_WORD_OPS = array( 'lessthan', 'morethan' );

	const BLANK_OPS = array( 'is_blank', 'is_not_blank' );

	const RANGE_OPS = array( 'between', 'not_between' );

	/** Search rules whose values are one of the M1 resolver's kinds, or a bounded direct lookup. */
	const SEARCH_KINDS = array(
		'contact_tags'                     => 'tags',
		'contact_lists'                    => 'lists',
		'product_item'                     => 'products',
		'customer_past_purchased_products' => 'products',
		'customer_purchased_products'      => 'products',
		'customer_reviewed_product'        => 'products',
		'product_category'                 => 'categories',
		'order_category'                   => 'categories',
		'customer_purchased_cat'           => 'categories',
		'cart_category'                    => 'categories',
		'comment_products_cats'            => 'categories',
		'product_tags'                     => 'product_tags',
		'order_tags'                       => 'product_tags',
		'cart_items_tag'                   => 'product_tags',
		'customer_purchased_tags'          => 'product_tags',
		'ever_entered_automation'          => 'automations',
		'currently_active_automation'      => 'automations',
		'completed_automation'             => 'automations',
		'link_trigger_clicked'             => 'link_trigger',
		'order_coupons'                    => 'coupon_ids',
		'cart_coupons'                     => 'coupon_ids',
		'subscription_coupons'             => 'coupon_ids',
		'customer_used_coupons'            => 'coupon_ids',
		'users_user'                       => 'users',
	);

	/** Search rules whose own get_options('') returns the whole, small list, safely in-process (research C §3.3). */
	const OPTION_RULES = array( 'product_item_type', 'order_payment_gateway', 'order_shipping_method', 'order_shipping_method_zone', 'order_billing_country', 'order_shipping_country', 'contact_country', 'order_status', 'order_status_change', 'users_role', 'customer_role' );

	const OPTION_PREFIXES = array( 'bwf_contact_field_f' );

	/** wp_die() picks one of these by request type; all of them are replaced during a get_options() call. */
	const DIE_FILTERS = array( 'wp_die_handler', 'wp_die_ajax_handler', 'wp_die_json_handler', 'wp_die_jsonp_handler', 'wp_die_xmlrpc_handler', 'wp_die_xml_handler' );

	/** @var array Per-request memo: 'rules:<event>' registries, 'eval:<slug>' verdicts, 'opts:<slug>' option maps. */
	private static $memo = array();

	private $event;

	private $resolver;

	private $rules;

	/**
	 * kind => normalised value => rows it matched ([] for none): users, coupons and
	 * product tags already looked up by an earlier rule of this translator.
	 * ponytail: unbounded per instance; a build is capped at 200 rules × 100 values.
	 */
	private $found = array();

	public function __construct( $event, $resolver = null ) {
		$this->event    = (string) $event;
		$this->resolver = $resolver;
		$this->rules    = self::registry( $this->event );
	}

	public static function reset() {
		self::$memo = array();
	}

	/**
	 * slug => {slug, name, group, type, operators, options} for the trigger,
	 * exactly as the admin's GET /automation/event-rules/{event} lists them
	 * (class-bwfan-rules-loader.php:362-479). Built once per trigger per request.
	 */
	public static function registry( $event ) {
		$key = 'rules:' . $event;
		if ( isset( self::$memo[ $key ] ) ) {
			return self::$memo[ $key ];
		}

		$out = array();
		try {
			$loader = BWFAN_Core()->rules;
			$loader->load_rules_classes();
			$groups = $loader->get_rules( $event, 0 );
		} catch ( Throwable $e ) {
			$groups = array();
		}

		foreach ( (array) $groups as $group_slug => $group ) {
			if ( ! is_array( $group ) || empty( $group['rules'] ) || ! is_array( $group['rules'] ) ) {
				continue;
			}
			$title = isset( $group['title'] ) && is_scalar( $group['title'] ) ? (string) $group['title'] : (string) $group_slug;

			foreach ( $group['rules'] as $rule ) {
				if ( ! is_array( $rule ) || empty( $rule['slug'] ) || ! is_string( $rule['slug'] ) ) {
					continue;
				}
				$ops = isset( $rule['operators'] ) && is_array( $rule['operators'] ) ? $rule['operators'] : array();

				$out[ $rule['slug'] ] = array(
					'slug'      => $rule['slug'],
					'name'      => isset( $rule['name'] ) && is_scalar( $rule['name'] ) ? (string) $rule['name'] : $rule['slug'],
					'group'     => $title,
					'type'      => isset( $rule['type'] ) && is_string( $rule['type'] ) ? $rule['type'] : '',
					'operators' => array_map( 'strval', array_filter( $ops, 'is_scalar' ) ),
					'options'   => self::option_map( isset( $rule['options'] ) ? $rule['options'] : array() ),
				);
			}
		}

		self::$memo[ $key ] = $out;

		return $out;
	}

	/**
	 * The cheap pass: shape, rule slugs, operators and caps, with no value
	 * lookups. Returns how many rules it saw, so the caller can total them.
	 */
	public function check( $rules, $path, FKMCP_Definition_Errors $errors ) {
		if ( ! FKMCP_Step_Tree::is_list( $rules ) || empty( $rules ) ) {
			$errors->add( $path, __( 'must be a non-empty list of rule groups: [[{rule, operator, value}, …], …]. Groups are OR-ed; rules in a group are AND-ed.', 'wp-marketing-automations-pro' ) );

			return 0;
		}

		if ( count( $rules ) > self::GROUPS_MAX ) {
			/* translators: %d: maximum number of groups */
			$errors->add( $path, sprintf( __( 'has more than %d groups.', 'wp-marketing-automations-pro' ), self::GROUPS_MAX ) );

			return 0;
		}

		$seen = 0;
		foreach ( $rules as $g => $group ) {
			$gpath = $path . '[' . $g . ']';

			if ( ! FKMCP_Step_Tree::is_list( $group ) || empty( $group ) ) {
				$errors->add( $gpath, __( 'must be a non-empty list of rules.', 'wp-marketing-automations-pro' ) );
				continue;
			}

			if ( count( $group ) > self::RULES_MAX ) {
				/* translators: %d: maximum number of rules in a group */
				$errors->add( $gpath, sprintf( __( 'has more than %d rules.', 'wp-marketing-automations-pro' ), self::RULES_MAX ) );
				continue;
			}

			foreach ( $group as $r => $rule ) {
				++$seen;
				$this->check_rule( $rule, $gpath . '[' . $r . ']', $errors );
			}
		}

		return $seen;
	}

	/**
	 * The full translation. Call it only after check() passed for the whole
	 * definition. Returns [[{filter, rule, data}]], or null after adding errors.
	 */
	public function translate( $rules, $path, FKMCP_Definition_Errors $errors ) {
		$before = $errors->count();
		$out    = array();

		foreach ( $rules as $g => $group ) {
			$saved = array();

			foreach ( $group as $r => $rule ) {
				if ( $errors->full() ) {
					break 2;
				}

				$rpath = $path . '[' . $g . '][' . $r . ']';
				$pair  = $this->check_rule( $rule, $rpath, $errors );
				if ( null === $pair ) {
					continue;
				}

				list( $entry, $op ) = $pair;
				$mark               = $errors->count();
				$data               = $this->value( $entry, $op, array_key_exists( 'value', $rule ) ? $rule['value'] : null, $rpath . '.value', $errors );

				if ( $errors->count() > $mark ) {
					continue;
				}

				$saved[] = array(
					'filter' => $entry['slug'],
					'rule'   => $op,
					'data'   => $data,
				);
			}

			$out[] = $saved;
		}

		return $errors->count() > $before ? null : $out;
	}

	/**
	 * Rows for describe-automation-part kind=rules: every rule an assistant
	 * can set under this trigger, with the site's own text passed through $scrub.
	 */
	public function describe( $scrub ) {
		$out = array();

		foreach ( $this->rules as $slug => $e ) {
			$hint = $this->hint( $e );
			if ( null === $hint ) {
				continue;
			}

			$ops = $e['operators'];
			if ( 'Search' === $e['type'] ) {
				unset( $ops['contains'], $ops['not_contains'] );
			}

			$row = array(
				'slug'      => $slug,
				'name'      => (string) call_user_func( $scrub, $e['name'] ),
				'group'     => (string) call_user_func( $scrub, $e['group'] ),
				'type'      => $e['type'],
				'operators' => self::scrub_map( $ops, $scrub ),
				'value'     => $hint,
			);

			if ( in_array( $e['type'], array( 'Select', 'key-value' ), true ) && ! empty( $e['options'] ) ) {
				$row['options'] = self::scrub_map( array_slice( $e['options'], 0, 200, true ), $scrub );
			}

			$out[] = $row;
		}

		return $out;
	}

	/** Returns array( $entry, $operator ), or null after adding an error. */
	private function check_rule( $rule, $path, FKMCP_Definition_Errors $errors ) {
		if ( ! is_array( $rule ) || ( ! empty( $rule ) && FKMCP_Step_Tree::is_list( $rule ) ) ) {
			$errors->add( $path, __( 'must be {rule, operator, value}.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$unknown = array_diff( array_keys( $rule ), array( 'rule', 'operator', 'value' ) );
		foreach ( $unknown as $key ) {
			$errors->add( $path . '.' . $key, __( 'is not part of a rule.', 'wp-marketing-automations-pro' ), array( 'rule', 'operator', 'value' ) );
		}
		if ( ! empty( $unknown ) ) {
			return null;
		}

		$slug = isset( $rule['rule'] ) && is_string( $rule['rule'] ) ? $rule['rule'] : '';
		if ( '' === $slug || strlen( $slug ) > FKMCP_Field_Translator::KEY_MAX || ! isset( $this->rules[ $slug ] ) ) {
			$errors->add( $path . '.rule', __( 'is not a condition rule for this trigger.', 'wp-marketing-automations-pro' ), $errors->full() ? null : FKMCP_Field_Translator::closest( $slug, array_keys( $this->rules ), 25 ) );

			return null;
		}

		$entry = $this->rules[ $slug ];

		if ( ! in_array( $entry['type'], self::TYPES, true ) ) {
			/* translators: %s: the rule's type */
			$errors->add( $path . '.rule', sprintf( __( 'is a %s rule, which an assistant can\'t set; add it in the builder.', 'wp-marketing-automations-pro' ), $entry['type'] ) );

			return null;
		}

		if ( ! self::evaluates( $slug ) ) {
			$errors->add( $path . '.rule', __( 'can\'t be evaluated on this site, so it would always match; add conditions in the builder.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$ops = $entry['operators'];
		$op  = array_key_exists( 'operator', $rule ) ? $rule['operator'] : null;

		if ( empty( $ops ) ) {
			if ( null !== $op && '' !== $op ) {
				$errors->add( $path . '.operator', __( 'this rule has no operator; leave it out.', 'wp-marketing-automations-pro' ) );

				return null;
			}
			$op = '';
		} elseif ( ! is_string( $op ) || ! array_key_exists( $op, $ops ) ) {
			// Its label works too ("is less than" for <). The refusal lists labels: the error filter strips tags,
			// and that takes keys like < and <= with it.
			$label_op = null;
			foreach ( is_string( $op ) ? $ops : array() as $key => $label ) {
				if ( 0 === strcasecmp( trim( (string) $label ), trim( $op ) ) ) {
					$label_op = (string) $key;
					break;
				}
			}
			if ( null === $label_op ) {
				$errors->add( $path . '.operator', __( 'is not an operator of this rule. Send one of these labels, or its key from describe-automation-part.', 'wp-marketing-automations-pro' ), array_map( 'strval', array_values( $ops ) ) );

				return null;
			}
			$op = $label_op;
		}

		if ( 'Search' === $entry['type'] && in_array( $op, array( 'contains', 'not_contains' ), true ) ) {
			$errors->add( $path . '.operator', __( 'takes free text an assistant can\'t set here; use another operator, or set it in the builder.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		// A key the payload lacks reads as '' at runtime, so a negated operator or is_blank on an unchecked (maybe typo'd) key matches everyone.
		if ( 'key-value' === $entry['type'] && empty( $entry['options'] ) && in_array( $op, array( 'is_not', 'not_contains', '!=', 'isnot', 'is_blank' ), true ) ) {
			$errors->add( $path . '.operator', __( 'can\'t be used when the key can\'t be checked on this site: a missing key would match every contact. Use a positive operator or is_not_blank, or set this rule in the builder.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$blank     = in_array( $op, self::BLANK_OPS, true );
		$has_value = array_key_exists( 'value', $rule ) && null !== $rule['value'] && '' !== $rule['value'];

		if ( $blank && 'key-value' !== $entry['type'] && $has_value ) {
			$errors->add( $path . '.value', __( 'must be left out: this operator takes no value.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		if ( ( ! $blank || 'key-value' === $entry['type'] ) && ! array_key_exists( 'value', $rule ) ) {
			$errors->add( $path . '.value', __( 'is required.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		return array( $entry, $op );
	}

	private function value( array $entry, $op, $v, $path, FKMCP_Definition_Errors $errors ) {
		$type = $entry['type'];

		if ( in_array( $op, self::BLANK_OPS, true ) ) {
			if ( 'key-value' !== $type ) {
				return '';
			}
			$keys = is_array( $v ) ? array_keys( $v ) : array();
			sort( $keys );
			$valid = ( array( 'key' ) === $keys ) || ( array( 'key', 'value' ) === $keys && array_key_exists( 'value', $v ) && ( null === $v['value'] || '' === $v['value'] ) );
			if ( ! $valid ) {
				$errors->add( $path, __( 'must be {key} only with this operator.', 'wp-marketing-automations-pro' ) );

				return null;
			}
			$key = $this->kv_key( $entry, $v['key'], $path . '.key', $errors );

			return null === $key ? null : array( $key, '' );
		}

		switch ( $type ) {
			case 'Number':
				return $this->number( $v, $path, $errors, true );
			case 'Text':
				$use_number = in_array( $op, self::NUM_OPS, true ) || in_array( $op, self::NUM_WORD_OPS, true );
				return $use_number ? $this->number( $v, $path, $errors ) : $this->text( $v, $path, $errors );
			case 'time':
				if ( ! is_string( $v ) || ! preg_match( '/^([01]\d|2[0-3]):[0-5]\d\z/', $v ) ) {
					$errors->add( $path, __( 'must be a time as HH:MM (24-hour).', 'wp-marketing-automations-pro' ) );

					return null;
				}

				return $v;
			case 'datetime':
				return $this->datetime( $v, $path, $errors );
			case 'Date':
				return 'between' === $op ? $this->range( $v, 'date', $entry['slug'], $path, $errors ) : $this->date( $v, $path, $errors );
			case 'Days':
				return in_array( $op, self::RANGE_OPS, true ) ? $this->range( $v, 'days', $entry['slug'], $path, $errors ) : $this->days( $v, $entry['slug'], $path, $errors );
			case 'Select':
				return $this->option( $entry, $v, $path, $errors );
			case 'key-value':
				return $this->key_value( $entry, $op, $v, $path, $errors );
			case 'product-qty':
				return $this->product_qty( $entry, $v, $path, $errors );
			case 'Search':
				return $this->search( $entry, $v, $path, $errors );
		}

		$errors->add( $path, __( 'can\'t be set by an assistant.', 'wp-marketing-automations-pro' ) );

		return null;
	}

	private function text( $v, $path, FKMCP_Definition_Errors $errors ) {
		if ( ! is_string( $v ) && ! is_int( $v ) && ! is_float( $v ) ) {
			$errors->add( $path, __( 'must be text.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$text = trim( wp_strip_all_tags( (string) $v ) );

		if ( '' === $text ) {
			$errors->add( $path, __( 'can\'t be empty: an empty value matches every contact.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		if ( mb_strlen( $text ) > self::TEXT_MAX ) {
			/* translators: %d: maximum length */
			$errors->add( $path, sprintf( __( 'is longer than %d characters.', 'wp-marketing-automations-pro' ), self::TEXT_MAX ) );

			return null;
		}

		return $text;
	}

	/** $non_negative for 'Number' rules: the runtime absint()s many of them, so "> -1" would silently become "> 1". */
	private function number( $v, $path, FKMCP_Definition_Errors $errors, $non_negative = false ) {
		$s = is_string( $v ) ? trim( $v ) : ( is_int( $v ) || is_float( $v ) ? (string) $v : '' );

		if ( '' === $s || strlen( $s ) > 30 || ! is_numeric( $s ) || ! is_finite( (float) $s ) ) {
			$errors->add( $path, __( 'must be a number.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		if ( $non_negative && (float) $s < 0 ) {
			$errors->add( $path, __( 'must not be negative.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		return $s;
	}

	private function datetime( $v, $path, FKMCP_Definition_Errors $errors ) {
		$s = is_string( $v ) ? trim( $v ) : '';
		if ( 16 === strlen( $s ) ) {
			$s .= ':00';
		}
		$d = DateTime::createFromFormat( '!Y-m-d H:i:s', $s );

		if ( ! $d || $d->format( 'Y-m-d H:i:s' ) !== $s ) {
			$errors->add( $path, __( 'must be a real date and time as YYYY-MM-DD HH:MM[:SS].', 'wp-marketing-automations-pro' ) );

			return null;
		}

		return $s;
	}

	private function date( $v, $path, FKMCP_Definition_Errors $errors ) {
		$s = is_string( $v ) ? trim( $v ) : '';
		$d = DateTime::createFromFormat( '!Y-m-d', $s );

		if ( ! $d || $d->format( 'Y-m-d' ) !== $s ) {
			$errors->add( $path, __( 'must be a real date as YYYY-MM-DD.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		return $s;
	}

	private function days( $v, $slug, $path, FKMCP_Definition_Errors $errors ) {
		$max = 'contact_dob_days' === $slug ? self::DOB_DAYS_MAX : self::DAYS_MAX;
		$ok  = ( is_int( $v ) || ( is_string( $v ) && preg_match( '/^\d{1,6}\z/', $v ) ) ) && (int) $v >= 0 && (int) $v <= $max;

		if ( ! $ok ) {
			/* translators: %d: the largest number of days */
			$errors->add( $path, sprintf( __( 'must be a whole number of days from 0 to %d.', 'wp-marketing-automations-pro' ), $max ) );

			return null;
		}

		return (string) (int) $v;
	}

	private function range( $v, $kind, $slug, $path, FKMCP_Definition_Errors $errors ) {
		$keys = is_array( $v ) ? array_keys( $v ) : array();
		sort( $keys );

		if ( array( 'from', 'to' ) !== $keys ) {
			$errors->add( $path, __( 'must be {from, to} for this operator.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$from = 'date' === $kind ? $this->date( $v['from'], $path . '.from', $errors ) : $this->days( $v['from'], $slug, $path . '.from', $errors );
		$to   = 'date' === $kind ? $this->date( $v['to'], $path . '.to', $errors ) : $this->days( $v['to'], $slug, $path . '.to', $errors );

		if ( null === $from || null === $to ) {
			return null;
		}

		if ( 'date' === $kind ? strcmp( $from, $to ) > 0 : (int) $from > (int) $to ) {
			$errors->add( $path, __( 'needs from ≤ to: the other way round it never matches, and "not between" would match every contact.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		return array(
			'from' => $from,
			'to'   => $to,
		);
	}

	private function option( array $entry, $v, $path, FKMCP_Definition_Errors $errors ) {
		if ( empty( $entry['options'] ) ) {
			$errors->add( $path, __( 'has no options on this site yet; set this rule in the builder.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$key = self::match_option( $entry['options'], $v );

		if ( null === $key ) {
			$errors->add( $path, __( 'is not one of this rule\'s options (use its key or exact label).', 'wp-marketing-automations-pro' ), array_map( 'strval', array_keys( $entry['options'] ) ) );

			return null;
		}

		return $key;
	}

	private function key_value( array $entry, $op, $v, $path, FKMCP_Definition_Errors $errors ) {
		if ( ! is_array( $v ) || ! array_key_exists( 'key', $v ) || ! array_key_exists( 'value', $v ) || 2 !== count( $v ) ) {
			$errors->add( $path, __( 'must be {key, value}.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$key = $this->kv_key( $entry, $v['key'], $path . '.key', $errors );
		if ( null === $key ) {
			return null;
		}

		$val = in_array( $op, self::NUM_OPS, true ) ? $this->number( $v['value'], $path . '.value', $errors ) : $this->text( $v['value'], $path . '.value', $errors );

		return null === $val ? null : array( $key, $val );
	}

	private function kv_key( array $entry, $key, $path, FKMCP_Definition_Errors $errors ) {
		if ( ! empty( $entry['options'] ) ) {
			$k = self::match_option( $entry['options'], $key );
			if ( null === $k ) {
				$errors->add( $path, __( 'is not one of this rule\'s keys.', 'wp-marketing-automations-pro' ), array_map( 'strval', array_keys( $entry['options'] ) ) );
			}

			return $k;
		}

		$k = is_string( $key ) ? trim( wp_strip_all_tags( $key ) ) : '';

		if ( '' === $k || mb_strlen( $k ) > 255 ) {
			$errors->add( $path, __( 'is required, at most 255 characters: a missing key matches every contact.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		return $k;
	}

	private function product_qty( array $entry, $v, $path, FKMCP_Definition_Errors $errors ) {
		if ( ! is_array( $v ) || ! array_key_exists( 'qty', $v ) || ! array_key_exists( 'products', $v ) || 2 !== count( $v ) ) {
			$errors->add( $path, __( 'must be {qty, products}.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$qty = $v['qty'];
		if ( ! ( is_int( $qty ) || ( is_string( $qty ) && ctype_digit( $qty ) ) ) || (int) $qty < 1 || (int) $qty > self::QTY_MAX ) {
			/* translators: %d: the largest quantity */
			$errors->add( $path . '.qty', sprintf( __( 'must be a whole number from 1 to %d.', 'wp-marketing-automations-pro' ), self::QTY_MAX ) );

			return null;
		}

		$search = $this->resolve_search( 'products', $entry, $v['products'], $path . '.products', $errors );

		return null === $search ? null : array(
			'qty'    => (string) (int) $qty,
			'search' => $search,
		);
	}

	private function search( array $entry, $v, $path, FKMCP_Definition_Errors $errors ) {
		$kind = self::search_kind( $entry['slug'] );

		if ( null === $kind ) {
			$errors->add( $path, __( 'can\'t be looked up by an assistant; set this rule in the builder.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		return $this->resolve_search( $kind, $entry, $v, $path, $errors );
	}

	/** [{key, label}] for a Search value list, or null after adding errors. Never creates anything. */
	private function resolve_search( $kind, array $entry, $v, $path, FKMCP_Definition_Errors $errors ) {
		if ( ! FKMCP_Step_Tree::is_list( $v ) || empty( $v ) ) {
			$errors->add( $path, __( 'must be a non-empty list of ids or exact names: an empty list would match every contact.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		if ( count( $v ) > FKMCP_Search_Resolver::VALUES_MAX ) {
			/* translators: %d: maximum number of values */
			$errors->add( $path, sprintf( __( 'takes at most %d values.', 'wp-marketing-automations-pro' ), FKMCP_Search_Resolver::VALUES_MAX ) );

			return null;
		}

		foreach ( $v as $k => $item ) {
			$ok = ( is_int( $item ) && $item > 0 ) || ( is_string( $item ) && '' !== trim( $item ) && '0' !== trim( $item ) && mb_strlen( $item ) <= FKMCP_Search_Resolver::VALUE_MAX );
			if ( ! $ok ) {
				$errors->add( $path . '[' . $k . ']', __( 'must be an id or an exact name.', 'wp-marketing-automations-pro' ) );

				return null;
			}
		}

		switch ( $kind ) {
			case 'users':
				return $this->users( $v, $path, $errors );
			case 'coupon_ids':
				return $this->coupons( $v, $path, $errors );
			case 'product_tags':
				return $this->product_tags( $v, $path, $errors );
			case 'options':
				return $this->from_options( $entry['slug'], $v, $path, $errors );
		}

		return $this->from_resolver( $kind, $v, $path, $errors );
	}

	/** How a Search rule's values are looked up here, or null when an assistant can't (spec §15.4). */
	private static function search_kind( $slug ) {
		if ( isset( self::SEARCH_KINDS[ $slug ] ) ) {
			return self::SEARCH_KINDS[ $slug ];
		}

		if ( in_array( $slug, self::OPTION_RULES, true ) ) {
			return 'options';
		}

		foreach ( self::OPTION_PREFIXES as $prefix ) {
			if ( 0 === strpos( $slug, $prefix ) ) {
				return 'options';
			}
		}

		return null;
	}

	private function from_resolver( $kind, array $v, $path, FKMCP_Definition_Errors $errors ) {
		if ( ! $this->resolver instanceof FKMCP_Search_Resolver ) {
			$errors->add( $path, __( 'can\'t be looked up here.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$pairs = $this->resolver->resolve(
			array(
				'id'            => 'rule',
				'type'          => 'search',
				'autocompleter' => $kind,
			),
			$v,
			$path,
			$errors,
			false // never create a tag or list for a rule.
		);

		if ( null === $pairs ) {
			return null;
		}

		$out = array();
		foreach ( $pairs as $pair ) {
			$out[] = array(
				'key'   => (string) $pair['id'],
				'label' => (string) $pair['name'],
			);
		}

		return $out;
	}

	/** product_tags: by id or exact name (abstracts.php:378 label format). */
	private function product_tags( array $v, $path, FKMCP_Definition_Errors $errors ) {
		$ids   = array();
		$names = array();
		foreach ( $v as $item ) {
			$s = trim( (string) $item );
			if ( ctype_digit( $s ) ) {
				$ids[] = (int) $s;
			} else {
				$names[] = $s;
			}
		}

		$fetch = function ( $field ) {
			return function ( array $values ) use ( $field ) {
				$result = get_terms( array(
					'taxonomy'   => 'product_tag',
					$field       => $values,
					'hide_empty' => false,
					'number'     => 100,
				) );

				return is_wp_error( $result ) ? null : (array) $result;
			};
		};
		$terms = $this->cached( 'tag_id', $ids, $fetch( 'include' ), function ( $t ) {
			return (int) $t->term_id;
		} );
		$named = null === $terms ? null : $this->cached( 'tag_name', $names, $fetch( 'name' ), function ( $t ) {
			return strtolower( $t->name );
		} );
		if ( null === $named ) {
			$errors->add( $path, __( 'can\'t be looked up on this site; set this rule in the builder.', 'wp-marketing-automations-pro' ) );
			return null;
		}
		$terms = array_merge( $terms, $named );

		$by_id    = array();
		$by_label = array();
		foreach ( $terms as $term ) {
			$label = $term->name . ' (#' . $term->term_id . ')';
			$by_id[ (int) $term->term_id ]     = array( 'id' => $term->term_id, 'name' => $term->name, 'label' => $label );
			$by_label[ $label ]                = array( 'id' => $term->term_id, 'name' => $term->name, 'label' => $label );
			$by_label[ strtolower( $term->name ) ] = array( 'id' => $term->term_id, 'name' => $term->name, 'label' => $label );
		}

		$out = array();
		foreach ( $v as $k => $item ) {
			$s    = trim( (string) $item );
			$term = null;
			if ( ctype_digit( $s ) ) {
				$term = isset( $by_id[ (int) $s ] ) ? $by_id[ (int) $s ] : null;
			} else {
				$term = isset( $by_label[ $s ] ) ? $by_label[ $s ] : ( isset( $by_label[ strtolower( $s ) ] ) ? $by_label[ strtolower( $s ) ] : null );
			}

			if ( null === $term ) {
				$errors->add( $path . '[' . $k . ']', sprintf( __( 'matches no product tag: "%s".', 'wp-marketing-automations-pro' ), mb_substr( wp_strip_all_tags( (string) $item ), 0, 80 ) ) );
				return null;
			}

			$out[ (int) $term['id'] ] = array(
				'key'   => (string) $term['id'],
				'label' => (string) $term['label'],
			);
		}

		return array_values( $out );
	}

	/** users_user: by id or exact email, two prepared queries at most (the rule's own search is unbounded). */
	private function users( array $v, $path, FKMCP_Definition_Errors $errors ) {
		global $wpdb;

		$ids    = array();
		$emails = array();
		foreach ( $v as $k => $item ) {
			$s = strtolower( trim( (string) $item ) );
			if ( ctype_digit( $s ) ) {
				$ids[] = (int) $s;
			} elseif ( is_email( $s ) ) {
				$emails[] = $s;
			} else {
				$errors->add( $path . '[' . $k . ']', __( 'must be a user id or an exact email address.', 'wp-marketing-automations-pro' ) );

				return null;
			}
		}

		$rows = array_merge(
			$this->cached( 'user_id', $ids, function ( array $ids ) use ( $wpdb ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- placeholders built for the IN list; table name is core's.
				return (array) $wpdb->get_results( $wpdb->prepare( "SELECT ID, user_email, display_name FROM {$wpdb->users} WHERE ID IN (" . implode( ',', array_fill( 0, count( $ids ), '%d' ) ) . ') LIMIT 100', $ids ), 'ARRAY_A' );
			}, function ( $row ) {
				return (int) $row['ID'];
			} ),
			$this->cached( 'user_email', $emails, function ( array $emails ) use ( $wpdb ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- placeholders built for the IN list; table name is core's.
				return (array) $wpdb->get_results( $wpdb->prepare( "SELECT ID, user_email, display_name FROM {$wpdb->users} WHERE user_email IN (" . implode( ',', array_fill( 0, count( $emails ), '%s' ) ) . ') LIMIT 100', $emails ), 'ARRAY_A' );
			}, function ( $row ) {
				return strtolower( (string) $row['user_email'] );
			} )
		);

		$by_id    = array();
		$by_email = array();
		foreach ( $rows as $row ) {
			$by_id[ (int) $row['ID'] ]                        = $row;
			$by_email[ strtolower( (string) $row['user_email'] ) ] = $row;
		}

		$out = array();
		foreach ( $v as $k => $item ) {
			$s   = strtolower( trim( (string) $item ) );
			$row = ctype_digit( $s ) ? ( isset( $by_id[ (int) $s ] ) ? $by_id[ (int) $s ] : null ) : ( isset( $by_email[ $s ] ) ? $by_email[ $s ] : null );

			if ( null === $row ) {
				/* translators: %s: the value that matched no user */
				$errors->add( $path . '[' . $k . ']', sprintf( __( 'matches no user: "%s".', 'wp-marketing-automations-pro' ), mb_substr( wp_strip_all_tags( (string) $item ), 0, 80 ) ) );

				return null;
			}

			$out[ (int) $row['ID'] ] = array(
				'key'   => (string) $row['ID'],
				'label' => (string) $row['display_name'],
			);
		}

		return array_values( $out );
	}

	/**
	 * Rows matching $values, querying (one batch through $fetch) only the values not seen
	 * yet. $key_of maps a row back to the normalised value it matched: an id as int, text
	 * lowercased. Null when $fetch fails; a failed batch is not remembered.
	 */
	private function cached( $kind, array $values, callable $fetch, callable $key_of ) {
		$want = array();
		foreach ( $values as $value ) {
			$want[ is_int( $value ) ? $value : strtolower( (string) $value ) ] = $value;
		}

		$miss = array_diff_key( $want, isset( $this->found[ $kind ] ) ? $this->found[ $kind ] : array() );
		if ( ! empty( $miss ) ) {
			$rows = call_user_func( $fetch, array_values( $miss ) );
			if ( null === $rows ) {
				return null;
			}
			foreach ( $miss as $key => $value ) {
				$this->found[ $kind ][ $key ] = array();
			}
			foreach ( $rows as $row ) {
				$key = call_user_func( $key_of, $row );
				if ( isset( $miss[ $key ] ) ) {
					$this->found[ $kind ][ $key ][] = $row;
				}
			}
		}

		$out = array();
		foreach ( $want as $key => $value ) {
			$out = array_merge( $out, $this->found[ $kind ][ $key ] );
		}

		return $out;
	}

	/** Coupon rules: key = the coupon's post ID, label = its code, as the rules save them. Two prepared queries at most. */
	private function coupons( array $v, $path, FKMCP_Definition_Errors $errors ) {
		global $wpdb;

		$ids   = array();
		$codes = array();
		foreach ( $v as $item ) {
			$s = trim( (string) $item );
			if ( ctype_digit( $s ) ) {
				$ids[] = (int) $s;
			} else {
				$codes[] = $s;
			}
		}

		$rows = array_merge(
			$this->cached( 'coupon_id', $ids, function ( array $ids ) use ( $wpdb ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- placeholders built for the IN list; table name is core's.
				return (array) $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_title FROM {$wpdb->posts} WHERE post_type = 'shop_coupon' AND post_status = 'publish' AND ID IN (" . implode( ',', array_fill( 0, count( $ids ), '%d' ) ) . ') LIMIT 100', $ids ), 'ARRAY_A' );
			}, function ( $row ) {
				return (int) $row['ID'];
			} ),
			$this->cached( 'coupon_code', $codes, function ( array $codes ) use ( $wpdb ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- placeholders built for the IN list; table name is core's.
				return (array) $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_title FROM {$wpdb->posts} WHERE post_type = 'shop_coupon' AND post_status = 'publish' AND post_title IN (" . implode( ',', array_fill( 0, count( $codes ), '%s' ) ) . ') LIMIT 200', $codes ), 'ARRAY_A' );
			}, function ( $row ) {
				return strtolower( (string) $row['post_title'] );
			} )
		);

		$by_id   = array();
		$by_code = array();
		foreach ( $rows as $row ) {
			$by_id[ (int) $row['ID'] ]                             = $row;
			$by_code[ strtolower( (string) $row['post_title'] ) ][] = $row;
		}

		$out = array();
		foreach ( $v as $k => $item ) {
			$s    = trim( (string) $item );
			$hits = ctype_digit( $s ) ? ( isset( $by_id[ (int) $s ] ) ? array( $by_id[ (int) $s ] ) : array() ) : ( isset( $by_code[ strtolower( $s ) ] ) ? $by_code[ strtolower( $s ) ] : array() );

			if ( count( $hits ) > 1 ) {
				$errors->add( $path . '[' . $k . ']', __( 'matches more than one coupon; use its id.', 'wp-marketing-automations-pro' ), array_map( 'strval', array_column( $hits, 'ID' ) ) );

				return null;
			}
			if ( empty( $hits ) ) {
				/* translators: %s: the value that matched no coupon */
				$errors->add( $path . '[' . $k . ']', sprintf( __( 'matches no published coupon: "%s".', 'wp-marketing-automations-pro' ), mb_substr( wp_strip_all_tags( $s ), 0, 80 ) ) );

				return null;
			}

			$out[ (int) $hits[0]['ID'] ] = array(
				'key'   => (string) $hits[0]['ID'],
				'label' => (string) $hits[0]['post_title'],
			);
		}

		return array_values( $out );
	}

	private function from_options( $slug, array $v, $path, FKMCP_Definition_Errors $errors ) {
		$map = $this->search_options( $slug );

		if ( null === $map ) {
			$errors->add( $path, __( 'its options could not be read on this site; set this rule in the builder.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$out = array();
		foreach ( $v as $k => $item ) {
			$key = self::match_option( $map, $item );

			if ( null === $key ) {
				$errors->add( $path . '[' . $k . ']', __( 'is not one of this rule\'s options (use its key or exact label).', 'wp-marketing-automations-pro' ), $errors->full() ? null : array_slice( array_values( $map ), 0, 25 ) );

				return null;
			}

			$out[ $key ] = array(
				'key'   => $key,
				'label' => $map[ $key ], // the rule's own label: order_status_change compares it.
			);
		}

		return array_values( $out );
	}

	/**
	 * A full-list rule's own options, read once per request. Any wp_die()
	 * inside (a nonce check, a wp_send_json()) becomes a refusal instead of
	 * ending the MCP request; every filter and buffer is restored in finally.
	 */
	private function search_options( $slug ) {
		$key = 'opts:' . $slug;
		if ( array_key_exists( $key, self::$memo ) ) {
			return self::$memo[ $key ];
		}

		$map    = null;
		$handle = array( __CLASS__, 'die_handler' );
		$level  = ob_get_level();
		$had_ajax_filter = has_filter( 'wp_doing_ajax', '__return_true' );

		foreach ( self::DIE_FILTERS as $filter ) {
			add_filter( $filter, $handle, PHP_INT_MAX );
		}
		if ( ! $had_ajax_filter ) {
			add_filter( 'wp_doing_ajax', '__return_true', PHP_INT_MAX ); // so wp_send_json() goes through wp_die(), not a bare die.
		}
		ob_start();

		try {
			$obj = BWFAN_Core()->rules->get_rule( $slug );
			if ( is_object( $obj ) && method_exists( $obj, 'get_options' ) ) {
				$raw = $obj->get_options( '' );
				$map = is_array( $raw ) ? self::option_map( $raw ) : null;
			}
		} catch ( Throwable $e ) {
			$map = null;
		} finally {
			while ( ob_get_level() > $level ) {
				$status = ob_get_status();
				if ( empty( $status['flags'] ) || ! ( $status['flags'] & PHP_OUTPUT_HANDLER_REMOVABLE ) || ! ob_end_clean() ) {
					break;
				}
			}
			if ( ! $had_ajax_filter ) {
				remove_filter( 'wp_doing_ajax', '__return_true', PHP_INT_MAX );
			}
			foreach ( self::DIE_FILTERS as $filter ) {
				remove_filter( $filter, $handle, PHP_INT_MAX );
			}
		}

		self::$memo[ $key ] = $map;

		return $map;
	}

	/** The handler wp_die() asks its filter for: one that throws. */
	public static function die_handler() {
		return array( __CLASS__, 'halt' );
	}

	public static function halt() {
		throw new FKMCP_Rule_Halt( 'wp_die inside a rule\'s options' );
	}

	/** What a rule's value looks like, for describe; null when an assistant can't set the rule. */
	private function hint( array $e ) {
		if ( ! in_array( $e['type'], self::TYPES, true ) || ! self::evaluates( $e['slug'] ) ) {
			return null;
		}

		switch ( $e['type'] ) {
			case 'Text':
				$has_numeric = ! empty( array_intersect( array_keys( $e['operators'] ), array_merge( self::NUM_OPS, self::NUM_WORD_OPS ) ) );
				$has_text    = ! empty( array_diff( array_keys( $e['operators'] ), array_merge( self::NUM_OPS, self::NUM_WORD_OPS ) ) );
				if ( $has_numeric && $has_text ) {
					return __( 'a number for comparison operators, otherwise text (at most 500 characters)', 'wp-marketing-automations-pro' );
				}
				return $has_numeric ? __( 'a number', 'wp-marketing-automations-pro' ) : __( 'text, at most 500 characters', 'wp-marketing-automations-pro' );
			case 'Number':
				return __( 'a number', 'wp-marketing-automations-pro' );
			case 'time':
				return __( 'a time, HH:MM (24-hour)', 'wp-marketing-automations-pro' );
			case 'datetime':
				return __( 'a date and time, YYYY-MM-DD HH:MM[:SS]', 'wp-marketing-automations-pro' );
			case 'Date':
				return __( 'a date, YYYY-MM-DD; with between, {from, to} where from is not after to', 'wp-marketing-automations-pro' );
			case 'Days':
				return __( 'a whole number of days; with between or not_between, {from, to} where from ≤ to', 'wp-marketing-automations-pro' );
			case 'Select':
				return empty( $e['operators'] ) ? __( 'one option key or its exact label; leave operator out', 'wp-marketing-automations-pro' ) : __( 'one option key or its exact label', 'wp-marketing-automations-pro' );
			case 'key-value':
				return __( '{key, value}; with is_blank or is_not_blank, {key} only', 'wp-marketing-automations-pro' );
			case 'product-qty':
				return __( '{qty: a whole number from 1, products: product ids or exact names}', 'wp-marketing-automations-pro' );
			case 'Search':
				$kind  = self::search_kind( $e['slug'] );
				$names = array(
					'tags'          => __( 'tags by ids or exact names', 'wp-marketing-automations-pro' ),
					'lists'         => __( 'lists by ids or exact names', 'wp-marketing-automations-pro' ),
					'products'      => __( 'products by ids or exact names', 'wp-marketing-automations-pro' ),
					'categories'    => __( 'categories by ids or exact names', 'wp-marketing-automations-pro' ),
					'product_tags'  => __( 'product tags by ids or exact names', 'wp-marketing-automations-pro' ),
					'automations'   => __( 'automations by ids or exact titles', 'wp-marketing-automations-pro' ),
					'link_trigger'  => __( 'link triggers by ids or exact titles', 'wp-marketing-automations-pro' ),
					'coupon_ids'    => __( 'coupons by ids or exact codes', 'wp-marketing-automations-pro' ),
					'users'         => __( 'users by ids or exact email addresses', 'wp-marketing-automations-pro' ),
					'options'       => __( 'option keys or exact labels, as the builder lists them', 'wp-marketing-automations-pro' ),
				);

				return null === $kind ? null : sprintf( /* translators: %s: what the list holds */ __( 'a list (1-100) of %s', 'wp-marketing-automations-pro' ), $names[ $kind ] );
		}

		return null;
	}

	/** An option key, from its key or its exact label (any case); null when neither or when the label is ambiguous. */
	private static function match_option( array $options, $v ) {
		if ( ! is_scalar( $v ) || is_bool( $v ) ) {
			return null;
		}

		$s = trim( (string) $v );
		if ( array_key_exists( $s, $options ) ) {
			return $s;
		}

		$hits = array();
		foreach ( $options as $key => $label ) {
			if ( 0 === strcasecmp( (string) $label, $s ) ) {
				$hits[] = (string) $key;
			}
		}

		return 1 === count( $hits ) ? $hits[0] : null;
	}

	/**
	 * A rule's options as key => label, from a {key: label} map, a list of
	 * scalars, or a list of {id|key|value, name|label|title}. A key that
	 * doesn't survive tag stripping unchanged is dropped (fail-closed, as
	 * M1's FKMCP_Field_Translator::options() does).
	 */
	private static function option_map( $options ) {
		$out = array();
		if ( ! is_array( $options ) ) {
			return $out;
		}

		$list = FKMCP_Step_Tree::is_list( $options );

		foreach ( $options as $k => $v ) {
			if ( count( $out ) >= self::OPTIONS_MAX ) {
				break;
			}

			if ( is_array( $v ) ) {
				$key   = isset( $v['id'] ) ? $v['id'] : ( isset( $v['key'] ) ? $v['key'] : ( isset( $v['value'] ) ? $v['value'] : null ) );
				$label = isset( $v['name'] ) ? $v['name'] : ( isset( $v['label'] ) ? $v['label'] : ( isset( $v['title'] ) ? $v['title'] : $key ) );
			} else {
				$key   = $list ? $v : $k;
				$label = $v;
			}

			if ( ! is_scalar( $key ) || ! is_scalar( $label ) ) {
				continue;
			}

			$key = (string) $key;
			if ( '' === $key || $key !== mb_substr( wp_strip_all_tags( $key, true ), 0, 500 ) ) {
				continue;
			}

			$out[ $key ] = (string) $label;
		}

		return $out;
	}

	private static function scrub_map( array $map, $scrub ) {
		$out = array();
		foreach ( $map as $k => $v ) {
			$out[ (string) $k ] = (string) call_user_func( $scrub, $v );
		}

		return (object) $out; // an object, so numeric keys survive JSON as keys.
	}

	/**
	 * False when the rule's class doesn't override is_match_v2(): the base
	 * returns true, so the rule would always match (L/rules/rules/base.php:293).
	 */
	private static function evaluates( $slug ) {
		$key = 'eval:' . $slug;
		if ( isset( self::$memo[ $key ] ) ) {
			return self::$memo[ $key ];
		}

		$ok = false;
		try {
			$obj = BWFAN_Core()->rules->get_rule( $slug );
			if ( is_object( $obj ) && method_exists( $obj, 'is_match_v2' ) ) {
				$method = new ReflectionMethod( $obj, 'is_match_v2' );
				$ok     = 'BWFAN_Rule_Base' !== $method->getDeclaringClass()->getName();
			}
		} catch ( Throwable $e ) {
			$ok = false;
		}

		self::$memo[ $key ] = $ok;

		return $ok;
	}
}
