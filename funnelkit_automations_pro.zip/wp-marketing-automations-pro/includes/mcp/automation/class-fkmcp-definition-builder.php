<?php

defined( 'ABSPATH' ) || exit;

/**
 * A whole agent definition (a tree of steps, flattened by FKMCP_Step_Tree) → an import() plan. A cheap pass checks shape,
 * refs, descriptors and step/marker references first; only once that pass
 * is clean does anything expensive run (field translation, search lookups,
 * ajax/live-API calls). The only write before import() itself is a
 * create_missing tag or list, and even that waits until everything —
 * cheap and expensive both — has validated (spec §0.1.9, §7, §9).
 */
class FKMCP_Definition_Builder {
	const STEPS_MAX = 50;

	const TYPES = array( 'email', 'wait', 'action', 'exit', 'condition', 'branches', 'split', 'jump', 'goal' );

	const GOAL_KEYS = array( 'type', 'ref', 'event', 'settings', 'if_not_met' );

	/** The builder's "If the contact doesn't meet the specified goal" (BWFAN_Goal_Controller). */
	const GOAL_RUN = array( 'wait', 'continue', 'end' );

	const EXIT_KEYS = array( 'type', 'ref' );

	const ACTION_KEYS = array( 'type', 'ref', 'action', 'settings' );

	/** Trigger shorthands and the event_meta ids they set. */
	const TRIGGER_ALIASES = array(
		'run'                     => 'bwfan_automation_run',
		'enter_on_active_contact' => 'enter_automation_on_active_contact',
	);

	const COUPON_CREATORS = array( 'pro_wc_create_coupon', 'wc_create_coupon' );

	const CONDITION_KEYS = array( 'type', 'ref', 'rules', 'yes', 'no' );

	const BRANCHES_KEYS = array( 'type', 'ref', 'branches', 'else' );

	/** A branch never takes an id: branch ids are server-owned (spec §0.1.2, §15.2). */
	const BRANCH_KEYS = array( 'name', 'rules', 'steps' );

	const BRANCH_NAME_MAX = 100;

	const RULES_TOTAL_MAX = 200;

	const SPLIT_KEYS = array( 'type', 'ref', 'title', 'desc', 'paths' );

	const JUMP_KEYS = array( 'type', 'ref', 'to' );

	const SPLIT_TITLE_MAX = 255;

	const SPLIT_DESC_MAX = 1000;

	/** Refused anywhere inside a split path, at any depth (the builder's type-selector.js:261-511). */
	const NOT_IN_SPLIT = array( 'goal', 'jump', 'exit', 'split' );

	/** Never a jump or skip target (jump.js:111-124). */
	const NOT_TARGETS = array( 'exit', 'jump', 'split' );

	private $resolver;

	private $special;

	/** @var FKMCP_Rule_Translator|null Built lazily, only for a definition with a fork. */
	private $rule_tr;

	/** @var callable Makes a branch id; tests inject a deterministic one. */
	private $branch_id;

	/** @var string|null Seed for this build's branch ids (spec §4.3); null = the constructor's callable. */
	private $seed = null;

	/** @var int Counter within one build's seeded ids. */
	private $seed_k = 0;

	public function __construct( $pack, $branch_id = null ) {
		$this->resolver = new FKMCP_Search_Resolver( $pack );
		$this->resolver->defer_creation( true );
		$this->special   = new FKMCP_Special_Fields( $this->resolver );
		$this->branch_id = is_callable( $branch_id ) ? $branch_id : array( __CLASS__, 'new_branch_id' );
	}

	/**
	 * A definition → an import() plan. With opts['dry'] the plan is returned before the one
	 * write (create_missing tags/lists stay {"$pending": token} sentinels); otherwise finish()
	 * runs on it. opts['branch_seed'] makes branch ids repeatable when no id callable was injected.
	 */
	public function build( $definition, array $opts ) {
		$plan = $this->plan( $definition, $opts );

		return is_wp_error( $plan ) || ! empty( $opts['dry'] ) ? $plan : $this->finish( $plan );
	}

	/**
	 * The one write a build makes: create_missing tags/lists, patched into the plan's
	 * rows and event meta, then the rows re-encoded. Call it on the builder that made
	 * the dry plan (its resolver holds the pending tokens). Spec §4.3: review and commit
	 * hash the same dry plan; only this step differs.
	 */
	public function finish( array $plan ) {
		if ( empty( $plan['dry'] ) ) {
			return $plan; // already finished: its terms exist; a second pass would create them again.
		}

		if ( $this->resolver->has_pending() ) {
			$patch = $this->resolver->create_pending();
			if ( is_wp_error( $patch ) ) {
				return $patch;
			}
			self::apply_pending( $plan['event_meta'], $patch );
			$plan['export']['meta']['event_meta'] = $plan['event_meta'];
			foreach ( $plan['rows'] as $i => &$row ) {
				if ( isset( $row['raw_data'] ) ) {
					continue; // a kept row is stored bytes; it never holds a sentinel.
				}
				self::apply_pending( $row['sidebar'], $patch );
				$plan['export']['step_data'][ $i + 1 ]['data'] = null === $row['sidebar'] ? null : wp_json_encode( array( 'sidebarData' => $row['sidebar'] ) );
			}
			unset( $row );
			$plan['created_terms'] = $this->resolver->created();
		}

		unset( $plan['dry'], $plan['rows'], $plan['pending'], $plan['descriptors'], $plan['sent'] );

		return $plan;
	}

	/** Terms this builder's last finish() created so far - also after it threw partway. */
	public function created_terms() {
		return $this->resolver->created();
	}

	/** build() up to, not including, its one write: the dry plan (see build()). */
	private function plan( $definition, array $opts ) {
		$this->resolver->reset_call(); // no pending/created state leaks in from an earlier build() on this instance.
		$this->seed   = ( array( __CLASS__, 'new_branch_id' ) === $this->branch_id && isset( $opts['branch_seed'] ) && is_string( $opts['branch_seed'] ) && '' !== $opts['branch_seed'] ) ? $opts['branch_seed'] : null;
		$this->seed_k = 0;
		$this->rule_tr = null; // the registry is per trigger; a new build may use another one.

		// The caller's collector when it has problems of its own to report in the same round
		// trip (create-automation's categories); those never stop the passes below early.
		$errors = isset( $opts['errors'] ) && $opts['errors'] instanceof FKMCP_Definition_Errors ? $opts['errors'] : new FKMCP_Definition_Errors();
		$base   = $errors->count();

		if ( ! is_array( $definition ) || ! isset( $definition['trigger'] ) || ! is_array( $definition['trigger'] ) || ! isset( $definition['steps'] ) || ! FKMCP_Step_Tree::is_list( $definition['steps'] ) ) {
			$errors->add( 'definition', __( 'must be {trigger: {...}, steps: [...]}, with steps a JSON list.', 'wp-marketing-automations-pro' ) );

			return $errors->to_wp_error();
		}

		foreach ( array_diff( array_keys( $definition ), array( 'trigger', 'steps' ) ) as $key ) {
			$errors->add( 'definition.' . $key, __( 'is not part of a definition.', 'wp-marketing-automations-pro' ) );
		}

		$tree = FKMCP_Step_Tree::flatten( $definition['steps'], self::STEPS_MAX, $errors );
		if ( null === $tree ) {
			return $errors->to_wp_error();
		}
		$items = $tree->items;

		$refs = $this->refs( $items, $errors );

		// ── trigger: existence and shape only (cheap) ──
		$trigger    = $definition['trigger'];
		$event_slug = isset( $trigger['event'] ) && is_string( $trigger['event'] ) ? $trigger['event'] : '';
		$event      = '' !== $event_slug && strlen( $event_slug ) <= FKMCP_Field_Translator::KEY_MAX ? FKMCP_Part_Registry::event( $event_slug ) : null;

		if ( null === $event ) {
			$errors->add( 'trigger.event', __( 'is not a trigger on this site.', 'wp-marketing-automations-pro' ), $errors->full() ? null : FKMCP_Field_Translator::closest( $event_slug, FKMCP_Part_Registry::event_slugs(), 25 ) );

			return $errors->to_wp_error();
		}

		$reason = FKMCP_Field_Translator::unbuildable_reason( $event['fields'], $this->special );
		if ( null !== $reason ) {
			$errors->add( 'trigger.event', $reason );

			return $errors->to_wp_error();
		}

		foreach ( array_diff( array_keys( $trigger ), array( 'event', 'run', 'enter_on_active_contact', 'settings' ) ) as $key ) {
			$errors->add( 'trigger.' . $key, __( 'is not part of a trigger.', 'wp-marketing-automations-pro' ) );
		}

		if ( array_key_exists( 'settings', $trigger ) && ! is_array( $trigger['settings'] ) ) {
			$errors->add( 'trigger.settings', __( 'must be an object of settings.', 'wp-marketing-automations-pro' ) );
		}

		foreach ( array( 'run', 'enter_on_active_contact' ) as $key ) {
			if ( array_key_exists( $key, $trigger ) && ! $event['has_common_run'] ) {
				$errors->add( 'trigger.' . $key, __( 'is not a setting of this trigger.', 'wp-marketing-automations-pro' ) );
			}
		}

		// ── cheap pass over every step: type, keys, descriptors, ref targets ──
		$types       = array();
		$descriptors = array();
		$sent        = array(); // i => setting keys the agent sent ('trigger' => the trigger's), for the review sheet
		$markers     = array(); // i => [field id, ...] dynamic-coupon-marker fields on this action
		$skip_refs   = array(); // i => ref string, for a wait with a well-formed {"$step": ref} skip_to
		$jump_refs   = array(); // i => ref string or 'end'
		$marker_refs = array(); // list of {index, key, ref, path}
		$rules_total = 0;

		$design_count = 0; // inline designs seen so far (cheap: counted before anything renders).

		foreach ( $items as $i => $item ) {
			$step = $item['step'];
			$path = $item['path'];
			$type = $item['type'];

			if ( ! in_array( $type, self::TYPES, true ) ) {
				$errors->add( $path . '.type', __( 'is not a step type.', 'wp-marketing-automations-pro' ), self::TYPES );
				continue;
			}
			$types[ $i ] = $type;

			if ( $item['in_split'] && in_array( $type, self::NOT_IN_SPLIT, true ) ) {
				/* translators: %s: the step type */
				$errors->add( $path . '.type', sprintf( __( 'a %s step can\'t be inside a split path.', 'wp-marketing-automations-pro' ), $type ) );
				continue;
			}

			if ( 'split' === $type && ! $item['top'] ) {
				$errors->add( $path . '.type', __( 'a split can only be on the main line, not inside a condition, branches or split path.', 'wp-marketing-automations-pro' ) );
				continue;
			}

			switch ( $type ) {
				case 'email':
					FKMCP_Step_Builder::unknown_keys( $step, FKMCP_Step_Builder::EMAIL_KEYS, $path, $errors );
					// Counted here, in the cheap pass, so an over-cap definition is refused before any
					// design renders (and before its images are measured) - not after the fact.
					if ( array_key_exists( 'design', $step ) ) {
						++$design_count;
						if ( $design_count > FKMCP_Email_Step::MAX_DESIGNS ) {
							/* translators: %d: max */
							$errors->add( $path . '.design', sprintf( __( 'at most %d emails per Automation can carry an inline design; save the rest as templates and use template_id.', 'wp-marketing-automations-pro' ), FKMCP_Email_Step::MAX_DESIGNS ) );
						}
					}
					break;

				case 'wait':
					FKMCP_Step_Builder::unknown_keys( $step, FKMCP_Step_Builder::WAIT_KEYS, $path, $errors );
					if ( is_array( $step ) && array_key_exists( 'skip_to', $step ) ) {
						$st = $step['skip_to'];
						if ( is_array( $st ) && isset( $st['$step'] ) && is_string( $st['$step'] ) && preg_match( FKMCP_Step_Builder::REF_PATTERN, $st['$step'] ) ) {
							$skip_refs[ $i ] = $st['$step'];
						}
						// 'end', or malformed: left to FKMCP_Step_Builder::wait() to report during translate.
					}
					break;

				case 'exit':
					FKMCP_Step_Builder::unknown_keys( $step, self::EXIT_KEYS, $path, $errors );
					break;

				case 'action':
					FKMCP_Step_Builder::unknown_keys( $step, self::ACTION_KEYS, $path, $errors );
					$descriptor = $this->cheap_action_check( $step, $path, $event_slug, $errors );
					if ( null !== $descriptor ) {
						$descriptors[ $i ] = $descriptor;
						$sent[ $i ]        = isset( $step['settings'] ) && is_array( $step['settings'] ) ? array_map( 'strval', array_keys( $step['settings'] ) ) : array();
						$marker_fields     = self::marker_fields( $descriptor );
						if ( ! empty( $marker_fields ) && isset( $step['settings'] ) && is_array( $step['settings'] ) ) {
							foreach ( $marker_fields as $fid ) {
								if ( ! array_key_exists( $fid, $step['settings'] ) ) {
									continue;
								}
								$value = $step['settings'][ $fid ];
								if ( is_array( $value ) && isset( $value['$step'] ) && is_string( $value['$step'] ) && preg_match( FKMCP_Step_Builder::REF_PATTERN, $value['$step'] ) ) {
									$marker_refs[] = array( 'index' => $i, 'key' => $fid, 'ref' => $value['$step'], 'path' => $path . '.settings.' . $fid );
								}
							}
						}
						$markers[ $i ] = $marker_fields;
					}
					break;

				case 'condition':
					FKMCP_Step_Builder::unknown_keys( $step, self::CONDITION_KEYS, $path, $errors );
					if ( $rules_total <= self::RULES_TOTAL_MAX ) { // past the cap, later rule sets aren't checked: one total error says it all.
						$rules_total += $this->rules_for( $event_slug )->check( isset( $step['rules'] ) ? $step['rules'] : null, $path . '.rules', $errors );
					}
					break;

				case 'branches':
					FKMCP_Step_Builder::unknown_keys( $step, self::BRANCHES_KEYS, $path, $errors );
					$list = isset( $step['branches'] ) ? $step['branches'] : null;

					if ( ! FKMCP_Step_Tree::is_list( $list ) || empty( $list ) ) {
						/* translators: %d: maximum number of branches */
						$errors->add( $path . '.branches', sprintf( __( 'must be a list of 1 to %d branches, each {name, rules, steps}.', 'wp-marketing-automations-pro' ), FKMCP_Step_Tree::BRANCHES_MAX ) );
						break;
					}

					foreach ( $list as $b => $branch ) {
						$bpath = $path . '.branches[' . $b . ']';

						if ( ! is_array( $branch ) || ( ! empty( $branch ) && FKMCP_Step_Tree::is_list( $branch ) ) ) {
							$errors->add( $bpath, __( 'must be {name, rules, steps}.', 'wp-marketing-automations-pro' ) );
							continue;
						}

						FKMCP_Step_Builder::unknown_keys( $branch, self::BRANCH_KEYS, $bpath, $errors );

						if ( '' === self::branch_name( $branch ) ) {
							/* translators: %d: maximum name length */
							$errors->add( $bpath . '.name', sprintf( __( 'is required, at most %d characters.', 'wp-marketing-automations-pro' ), self::BRANCH_NAME_MAX ) );
						}

						if ( $rules_total <= self::RULES_TOTAL_MAX ) {
							$rules_total += $this->rules_for( $event_slug )->check( isset( $branch['rules'] ) ? $branch['rules'] : null, $bpath . '.rules', $errors );
						}
					}
					break;

				case 'split':
					FKMCP_Step_Builder::unknown_keys( $step, self::SPLIT_KEYS, $path, $errors );
					$paths = isset( $step['paths'] ) ? $step['paths'] : null;

					if ( ! FKMCP_Step_Tree::is_list( $paths ) || count( $paths ) < 2 || count( $paths ) > FKMCP_Step_Tree::SPLIT_PATHS_MAX ) {
						/* translators: %d: maximum number of paths */
						$errors->add( $path . '.paths', sprintf( __( 'must be a list of 2 to %d paths, each a list of steps.', 'wp-marketing-automations-pro' ), FKMCP_Step_Tree::SPLIT_PATHS_MAX ) );
					}
					if ( '' === self::split_title( $step ) ) {
						/* translators: %d: maximum title length */
						$errors->add( $path . '.title', sprintf( __( 'is required, at most %d characters.', 'wp-marketing-automations-pro' ), self::SPLIT_TITLE_MAX ) );
					}
					if ( null === self::split_desc( $step ) ) {
						/* translators: %d: maximum description length */
						$errors->add( $path . '.desc', sprintf( __( 'must be text of at most %d characters.', 'wp-marketing-automations-pro' ), self::SPLIT_DESC_MAX ) );
					}
					break;

				case 'jump':
					FKMCP_Step_Builder::unknown_keys( $step, self::JUMP_KEYS, $path, $errors );
					$to = isset( $step['to'] ) ? $step['to'] : null;

					if ( 'end' === $to ) {
						$jump_refs[ $i ] = 'end';
					} elseif ( is_array( $to ) && isset( $to['$step'] ) && is_string( $to['$step'] ) && preg_match( FKMCP_Step_Builder::REF_PATTERN, $to['$step'] ) ) {
						$jump_refs[ $i ] = $to['$step'];
					} else {
						$errors->add( $path . '.to', __( 'must be "end" or {"$step": "<ref>"}.', 'wp-marketing-automations-pro' ) );
					}

					$lane = $tree->lists[ $item['list'] ]['items'];
					if ( end( $lane ) !== $i ) {
						$errors->add( $path, __( 'must be the last step of its lane: a step after a jump never runs.', 'wp-marketing-automations-pro' ) );
					}
					break;

				case 'goal':
					FKMCP_Step_Builder::unknown_keys( $step, self::GOAL_KEYS, $path, $errors );
					$slug = isset( $step['event'] ) && is_string( $step['event'] ) && strlen( $step['event'] ) <= FKMCP_Field_Translator::KEY_MAX ? $step['event'] : '';
					$goal = '' !== $slug ? FKMCP_Part_Registry::goal( $slug ) : null;

					if ( null === $goal ) {
						$errors->add( $path . '.event', __( 'is not a goal on this site.', 'wp-marketing-automations-pro' ), $errors->full() ? null : FKMCP_Field_Translator::closest( $slug, array_keys( FKMCP_Part_Registry::goals() ), 25 ) );
						break;
					}

					$why = FKMCP_Field_Translator::unbuildable_reason( $goal['fields'], $this->special );
					if ( null !== $why ) {
						$errors->add( $path . '.event', $why );
						break;
					}

					if ( array_key_exists( 'if_not_met', $step ) && ! in_array( $step['if_not_met'], self::GOAL_RUN, true ) ) {
						$errors->add( $path . '.if_not_met', __( 'must be wait, continue or end.', 'wp-marketing-automations-pro' ), self::GOAL_RUN );
					}

					if ( array_key_exists( 'settings', $step ) && ! is_array( $step['settings'] ) ) {
						$errors->add( $path . '.settings', __( 'must be an object of settings.', 'wp-marketing-automations-pro' ) );
					} elseif ( isset( $step['settings'] ) && array_key_exists( 'bwfan_goal_run', $step['settings'] ) ) {
						$errors->add( $path . '.settings.bwfan_goal_run', __( 'is set with if_not_met.', 'wp-marketing-automations-pro' ) );
					}

					$descriptors[ $i ] = $goal;
					$sent[ $i ]        = isset( $step['settings'] ) && is_array( $step['settings'] ) ? array_map( 'strval', array_keys( $step['settings'] ) ) : array();
					break;
			}
		}

		if ( $rules_total > self::RULES_TOTAL_MAX ) {
			/* translators: %d: maximum number of rules */
			$errors->add( 'steps', sprintf( __( 'uses more than %d rules in total.', 'wp-marketing-automations-pro' ), self::RULES_TOTAL_MAX ) );
		}

		// Jump and skip targets (spec §15.3). Every target is set on the tree first, so each
		// loop check follows every other jump and skip too.
		$edges = array();
		foreach ( $skip_refs as $i => $ref ) {
			$edges[ $i ] = array( 'ref' => $ref, 'kind' => 'skip' );
		}
		foreach ( $jump_refs as $i => $ref ) {
			$edges[ $i ] = array( 'ref' => $ref, 'kind' => 'jump' );
		}

		$looped = array();
		foreach ( $edges as $i => $edge ) {
			$path = $items[ $i ]['path'] . ( 'jump' === $edge['kind'] ? '.to' : '.skip_to' );

			if ( 'end' === $edge['ref'] ) {
				$tree->set_target( $i, 'end' );
				continue;
			}

			$target = isset( $refs[ $edge['ref'] ] ) ? $refs[ $edge['ref'] ] : null;
			$m1_bad = null === $target || $target === $i || ( isset( $types[ $target ] ) && 'exit' === $types[ $target ] );
			$m3_bad = null !== $target && ( ( isset( $types[ $target ] ) && in_array( $types[ $target ], self::NOT_TARGETS, true ) ) || $items[ $target ]['in_split'] );

			if ( $m1_bad || $m3_bad ) {
				// A flat definition keeps its original message (spec §14).
				$message = 'skip' === $edge['kind'] && ! $m3_bad
					? __( 'must name another step that is not an exit.', 'wp-marketing-automations-pro' )
					: __( 'must name another step that is not a jump, exit or split, and not inside a split path.', 'wp-marketing-automations-pro' );
				$errors->add( $path, $message, self::skip_allowed( $refs, $types, $items, $i ) );
				continue;
			}

			$tree->set_target( $i, $target );
			$looped[ $i ] = array( 'target' => $target, 'ref' => $edge['ref'], 'kind' => $edge['kind'], 'path' => $path );
		}

		foreach ( $looped as $i => $edge ) {
			if ( $tree->reaches_without_wait( $edge['target'], $i ) ) {
				$errors->add(
					$edge['path'],
					'skip' === $edge['kind']
						/* translators: %s: the ref that would be skipped back to */
						? sprintf( __( 'can\'t skip back to %s without a wait in between: it would repeat those steps immediately', 'wp-marketing-automations-pro' ), $edge['ref'] )
						/* translators: %s: the ref that would be jumped back to */
						: sprintf( __( 'can\'t jump back to %s without a wait on every path in between: it would repeat those steps immediately', 'wp-marketing-automations-pro' ), $edge['ref'] )
				);
			}
		}

		// Dynamic-coupon markers: must name a Create Coupon step that always runs before them
		// (in a flat definition, simply an earlier one: the original text is kept there, spec §14).
		$post_refs = array();
		foreach ( $marker_refs as $m ) {
			$target = isset( $refs[ $m['ref'] ] ) ? $refs[ $m['ref'] ] : null;
			$ok     = null !== $target && $tree->always_before( $target, $m['index'] ) && isset( $types[ $target ] ) && 'action' === $types[ $target ] && isset( $items[ $target ]['step']['action'] ) && in_array( $items[ $target ]['step']['action'], self::COUPON_CREATORS, true );

			if ( ! $ok ) {
				$errors->add( $m['path'], empty( $tree->lanes ) ? __( 'must name an earlier Create Coupon step.', 'wp-marketing-automations-pro' ) : __( 'must name a Create Coupon step that always runs before this one.', 'wp-marketing-automations-pro' ) );
				continue;
			}
			$post_refs[] = array( 'temp' => $m['index'] + 1, 'key_path' => array( $m['key'] ), 'target_temp' => $target + 1 );
		}

		if ( $errors->count() > $base ) {
			return $errors->to_wp_error(); // nothing has been translated, looked up, or written yet.
		}

		// ── translate: the only phase that can hit a search, an ajax handler, or a live API ──
		$merge_tags = FKMCP_Part_Registry::merge_tags( $event_slug );
		$settings   = isset( $trigger['settings'] ) && is_array( $trigger['settings'] ) ? $trigger['settings'] : array();
		foreach ( array_keys( self::TRIGGER_ALIASES ) as $key ) {
			if ( array_key_exists( $key, $trigger ) ) {
				$settings[ $key ] = $trigger[ $key ];
			}
		}
		$sent['trigger'] = array_keys( $settings );

		$translator = new FKMCP_Field_Translator( $event['fields'], $event['defaults'], array(
			'merge_tags'     => $merge_tags,
			'guarded'        => FKMCP_Part_Registry::guarded_fields( $event_slug ),
			'aliases'        => self::TRIGGER_ALIASES,
			'create_missing' => ! empty( $opts['create_missing'] ),
			'resolver'       => $this->resolver,
			'special'        => $this->special,
			'webhook_sample' => isset( $opts['webhook_sample'] ) && is_array( $opts['webhook_sample'] ) ? $opts['webhook_sample'] : null,
			'webhook_paths'  => isset( $opts['webhook_paths'] ) && is_array( $opts['webhook_paths'] ) ? array_values( $opts['webhook_paths'] ) : null,
		) );
		$event_meta = $translator->normalise( $settings, 'trigger.settings', $errors );

		if ( $event['need_unique_key'] ) {
			$event_meta['bwfan_unique_key'] = 'pending'; // import() replaces any present key with a fresh one.
		}

		$awaiting = self::awaiting_sample( $event_slug, $event_meta );

		$template_ids = array();
		foreach ( $items as $item ) {
			if ( 'email' === $item['type'] && is_array( $item['step'] ) && isset( $item['step']['template_id'] ) && is_int( $item['step']['template_id'] ) ) {
				$template_ids[] = $item['step']['template_id'];
			}
		}
		$templates = isset( $opts['templates'] ) && is_array( $opts['templates'] ) ? $opts['templates'] : ( empty( $template_ids ) ? array() : FKMCP_Email_Step::load_templates( $template_ids ) );

		$cf_cache = null;
		$step_ctx = array(
			'merge_tags'     => $merge_tags,
			'delay_tags'     => FKMCP_Part_Registry::merge_tags( $event_slug, true ),
			'woocommerce'    => function_exists( 'WC' ),
			'event'          => $event_slug,
			'automation_id'  => isset( $opts['automation_id'] ) ? absint( $opts['automation_id'] ) : 0,
			'templates'      => $templates,
			// One image-download budget for every inline design this build renders, not one each.
			'measure_budget' => uniqid( 'fkmcp-def-', true ),
			'contact_fields' => function () use ( &$cf_cache ) {
				if ( null === $cf_cache ) {
					$cf_cache = call_user_func( array( 'BWFCRM_Fields', 'get_custom_fields' ) );
				}

				return $cf_cache;
			},
		);

		$limit     = FKMCP_Definition_Errors::LIMIT;
		$rows      = array();
		$sensitive = array();
		$emails    = array();
		$warnings  = array();
		$used_ids  = array();
		$goals     = array();

		$kept_used = array(); // step ids an email keep: <id> already took
		foreach ( $items as $i => $item ) {
			$step = $item['step'];
			if ( $errors->count() >= $limit ) {
				break;
			}
			if ( ! isset( $types[ $i ] ) ) {
				continue; // an invalid type would already have failed the cheap pass above.
			}

			$path = $item['path'];
			$row  = null;

			switch ( $types[ $i ] ) {
				case 'email':
					if ( array_key_exists( 'keep', $step ) ) {
						// keep: <step id> keeps that email wherever it now sits; keep: true keeps the email at this path.
						$by_id = is_int( $step['keep'] ) && $step['keep'] > 0;
						if ( $by_id ) {
							$kept = isset( $opts['kept_ids'][ $step['keep'] ] ) && is_array( $opts['kept_ids'][ $step['keep'] ] ) ? $opts['kept_ids'][ $step['keep'] ] : null;
						} else {
							$kept = isset( $opts['kept'][ $path ] ) && is_array( $opts['kept'][ $path ] ) ? $opts['kept'][ $path ] : null;
						}
						if ( true !== $step['keep'] && ! $by_id ) {
							$errors->add( $path . '.keep', __( 'keep must be the email\'s step id (get-automation) or true; leave it out otherwise.', 'wp-marketing-automations-pro' ) );
						} elseif ( array() !== array_diff( array_keys( $step ), array( 'type', 'ref', 'keep' ) ) ) {
							$errors->add( $path, __( 'keep takes no other settings.', 'wp-marketing-automations-pro' ) );
						} elseif ( $by_id && isset( $kept_used[ $step['keep'] ] ) ) {
							$errors->add( $path . '.keep', __( 'keeps an email another step already keeps; each email can be kept once.', 'wp-marketing-automations-pro' ) );
						} elseif ( null === $kept ) {
							$errors->add( $path . '.keep', $by_id ? __( 'is not an email step of this Automation (get-automation gives each email\'s id).', 'wp-marketing-automations-pro' ) : __( 'only works in update-automation, on a step that is an email now (get-automation gives each step\'s path).', 'wp-marketing-automations-pro' ) );
						} else {
							if ( $by_id ) {
								$kept_used[ $step['keep'] ] = true;
							}
							$old     = json_decode( $kept['data'], true );
							$sidebar = isset( $old['sidebarData'] ) && is_array( $old['sidebarData'] ) ? $old['sidebarData'] : array();
							$mode    = isset( $sidebar['bwfan_email_data']['mode'] ) ? (int) $sidebar['bwfan_email_data']['mode'] : 0;
							$row     = array(
								'type'          => 2,
								'action'        => json_decode( $kept['action'], true ),
								'sidebar'       => $sidebar,
								'status'        => (int) $kept['status'],
								'node'          => 'action',
								'refs'          => array(),
								'warnings'      => array(),
								'transactional' => ! empty( $kept['transactional'] ),
								'raw_action'    => $kept['action'],
								'raw_data'      => $kept['data'],
							);
							$emails[] = array(
								'step'          => $i + 1,
								'path'          => $path,
								'transactional' => $row['transactional'],
								'template_id'   => isset( $sidebar['bwfan_email_data']['data']['template_ref']['id'] ) ? (int) $sidebar['bwfan_email_data']['data']['template_ref']['id'] : null,
								'mode'          => $mode,
								'designed'      => 5 === $mode,
								'kept'          => true,
							);
						}
						break;
					}
					$row = FKMCP_Step_Builder::email( $step, $path, $errors, $step_ctx );
					if ( null !== $row ) {
						$emails[] = array(
							'step'          => $i + 1,
							'path'          => $path,
							'transactional' => $row['transactional'],
							'template_id'   => $row['template_id'],
							'mode'          => $row['sidebar']['bwfan_email_data']['mode'],
							'designed'      => $row['designed'],
						);
					}
					break;
				case 'wait':
					$row = FKMCP_Step_Builder::wait( $step, $path, $errors, $step_ctx );
					break;
				case 'exit':
					$row = FKMCP_Step_Builder::exit_step();
					break;
				case 'action':
					$row = $this->action_row( $step, $path, $descriptors[ $i ], isset( $markers[ $i ] ) ? $markers[ $i ] : array(), $merge_tags, $opts, $errors );
					if ( null !== $row && null !== ( $why = FKMCP_Part_Registry::sensitive_reason( $step['action'] ) ) ) {
						$sensitive[] = array( 'step' => $i + 1, 'path' => $path, 'action' => $step['action'], 'reason' => $why );
						/* translators: 1: the step's path, e.g. steps[3], 2: what the action does */
						$warnings[] = sprintf( __( '%1$s %2$s; review it before activating.', 'wp-marketing-automations-pro' ), $path, $why );
					}
					break;

				case 'condition':
					$saved = $this->rules_for( $event_slug )->translate( $step['rules'], $path . '.rules', $errors );
					$row   = null === $saved ? null : self::fork_row( 4, 'conditional', $saved );
					break;

				case 'branches':
					$saved = array();
					foreach ( $step['branches'] as $b => $branch ) {
						$saved[ $b ] = $this->rules_for( $event_slug )->translate( $branch['rules'], $path . '.branches[' . $b . '].rules', $errors );
					}

					if ( in_array( null, $saved, true ) ) {
						break; // errors already added; no ids are made for a refused step.
					}

					$keep = isset( $opts['branch_ids'][ $path ] ) && is_array( $opts['branch_ids'][ $path ] ) ? array_values( $opts['branch_ids'][ $path ] ) : array();

					$entries = array();
					$defs    = array();
					foreach ( $step['branches'] as $b => $branch ) {
						$id        = $this->branch_id_for( $keep, $b, $used_ids );
						$name      = self::branch_name( $branch );
						$entries[] = array(
							'id'    => $id,
							'name'  => $name,
							'rules' => $saved[ $b ],
						);
						$defs[]    = array(
							'id'   => $id,
							'name' => $name,
						);
					}

					$row             = self::fork_row( 8, 'branches', array( 'branches' => $entries ) );
					$row['branches'] = $defs;
					break;

				case 'split':
					$row = self::fork_row(
						7,
						'split',
						array(
							'split_path' => (string) count( $step['paths'] ),
							'title'      => self::split_title( $step ),
							'desc'       => (string) self::split_desc( $step ),
						)
					);
					break;

				case 'jump':
					$end = 'end' === $jump_refs[ $i ];
					$row = array(
						'type'     => 6,
						'action'   => null,
						'sidebar'  => array( 'jump_to' => $end ? array( 'step' => 'end', 'name' => 'End Automation' ) : array( 'step' => 0, 'name' => '' ) ),
						'status'   => 1,
						'node'     => 'jump',
						'refs'     => $end ? array() : array( array( 'key_path' => array( 'jump_to' ), 'ref' => $jump_refs[ $i ] ) ),
						'warnings' => array(),
					);
					break;

				case 'goal':
					$row = $this->goal_row( $step, $path, $descriptors[ $i ], $errors );
					if ( null !== $row ) {
						$goals[ $i + 1 ] = $descriptors[ $i ]['slug'];
					}
					break;
			}

			if ( null !== $row ) {
				$rows[ $i ] = $row;
				foreach ( $row['warnings'] as $warning ) {
					/* translators: 1: the step's path, e.g. steps[3], 2: the warning */
					$warnings[] = sprintf( __( '%1$s: %2$s', 'wp-marketing-automations-pro' ), $path, $warning );
				}
			}
		}

		// update-automation on a webhook trigger that has a stored sample: every
		// {{wp_webhook_data field="…"}} must name one of its paths, or it renders blank.
		if ( 'autonami_webhook_received' === $event_slug && isset( $opts['webhook_paths'] ) && is_array( $opts['webhook_paths'] ) ) {
			foreach ( $rows as $i => $row ) {
				if ( isset( $row['raw_data'] ) ) {
					continue; // a kept row is trusted, unchanged stored content; not re-checked.
				}
				foreach ( self::webhook_fields( wp_json_encode( array( 'sidebarData' => $row['sidebar'] ) ) ) as $field ) {
					if ( ! in_array( $field, $opts['webhook_paths'], true ) ) {
						/* translators: 1: a webhook field path, 2: close paths from the last test request */
						$errors->add( $items[ $i ]['path'], sprintf( __( 'uses wp_webhook_data field "%1$s", which is not in the last test request. Close paths: %2$s.', 'wp-marketing-automations-pro' ), $field, implode( ', ', FKMCP_Field_Translator::closest( $field, $opts['webhook_paths'], 5 ) ) ) );
					}
				}
			}
		}

		if ( $errors->has() ) {
			return $errors->to_wp_error();
		}

		// ── graph first: tree() can throw (LogicException), and nothing has been written yet ──
		$nodes = array();
		foreach ( $rows as $i => $row ) {
			$nodes[ $i ] = array(
				'node' => $row['node'],
				'temp' => $i + 1,
			);
			if ( isset( $row['branches'] ) ) {
				$nodes[ $i ]['branches'] = $row['branches'];
			}
		}
		$graph = ( new FKMCP_Graph_Builder() )->tree( $tree, $nodes );

		// The only write (create_missing tags/lists) is finish()'s, after everything here, the graph included, succeeded.
		// Until then a sidebar holds {"$pending": token}; the jump/skip labels below never read a term.

		// ── fill in each jump/skip target's temp id and the builder's own label (targets already validated) ──
		foreach ( $rows as $i => &$row ) {
			foreach ( $row['refs'] as $ref ) {
				$target       = $refs[ $ref['ref'] ];
				$slot         = &self::dig( $row['sidebar'], $ref['key_path'] );
				$slot['step'] = $target + 1;
				$slot['name'] = self::builder_label( $graph['node_ids'][ $target ], $rows[ $target ], $items[ $target ]['step'], $this->label_part( $target, $rows[ $target ], $items[ $target ]['step'], $descriptors, $event_slug ) );
				unset( $slot );
			}
		}
		unset( $row );

		$labels = array();
		foreach ( $rows as $i => $row ) {
			$labels[ $i ] = self::builder_label( $graph['node_ids'][ $i ], $row, $items[ $i ]['step'], $this->label_part( $i, $row, $items[ $i ]['step'], $descriptors, $event_slug ) );
		}

		$desc_out = array();
		foreach ( $descriptors as $i => $d ) {
			$desc_out[ $i ] = array( 'kind' => $d['kind'], 'slug' => $d['slug'] );
		}

		$template_titles = array();
		foreach ( $templates as $tid => $trow ) {
			$template_titles[ (int) $tid ] = FKMCP_Definition_Errors::clean( (string) $trow['title'], 100 );
		}

		$step_data = array();
		foreach ( $rows as $i => $row ) {
			$step_data[ $i + 1 ] = array(
				'type'   => $row['type'],
				'action' => isset( $row['raw_action'] ) ? $row['raw_action'] : ( null === $row['action'] ? null : wp_json_encode( $row['action'] ) ),
				'data'   => isset( $row['raw_data'] ) ? $row['raw_data'] : ( null === $row['sidebar'] ? null : wp_json_encode( array( 'sidebarData' => $row['sidebar'] ) ) ),
				'status' => $row['status'],
			);
		}

		return array(
			'event'           => $event_slug,
			'source'          => $event['source'],
			'event_meta'      => $event_meta,
			'export'          => array(
				'data'      => array( 'source' => $event['source'], 'event' => $event_slug, 'start' => $graph['start_temp'], 'v' => 2 ),
				'meta'      => array( 'event_meta' => $event_meta, 'steps' => $graph['steps'], 'links' => $graph['links'], 'count' => $graph['count'] ),
				'step_data' => $step_data,
			),
			'post_refs'       => $post_refs,
			'warnings'        => $warnings,
			'sensitive'       => $sensitive,
			'emails'          => $emails,
			'created_terms'   => $this->resolver->created(),
			'need_unique_key' => $event['need_unique_key'],
			'awaiting_sample' => $awaiting,
			'node_ids'        => $graph['node_ids'],
			'joins'           => $graph['joins'],
			'goals'           => $goals,
			'step_count'      => count( $rows ),
			'paths'           => array_column( $items, 'path' ),
			'types'           => array_column( $items, 'type' ),
			'dry'             => true,
			'rows'            => $rows,
			'labels'          => $labels,
			'pending'         => $this->resolver->pending_tokens(),
			'descriptors'     => $desc_out,
			'sent'            => $sent,
			'template_titles' => $template_titles,
		);
	}

	/** The single entry BWFAN_Automations::import() iterates; meta.title is required or it skips it. */
	public static function export_entry( $title, array $plan ) {
		$entry                  = $plan['export'];
		$entry['meta']['title'] = (string) $title;

		return $entry;
	}

	/**
	 * The plan's temp ids (1..n) swapped for real row ids, in memory and before
	 * anything is written (update-automation, spec §16): graph node stepIds, the
	 * start, jump and date-wait skip targets, and dynamic-coupon references. Chips
	 * keep their string ids. A row the remap doesn't touch keeps its data byte for
	 * byte, so an unchanged step is never rewritten.
	 *
	 * @param array $plan build() output.
	 * @param array $map  temp id => real row id, one per step.
	 *
	 * @return array {steps, start, rows: real id => {type, action, data, status}}
	 * @throws RuntimeException When a temp id has no real id.
	 */
	public static function remap( array $plan, array $map ) {
		$real = function ( $temp ) use ( $map ) {
			$temp = (int) $temp;
			if ( ! isset( $map[ $temp ] ) || (int) $map[ $temp ] <= 0 ) {
				throw new RuntimeException( 'no row id for step ' . $temp );
			}

			return (int) $map[ $temp ];
		};

		$steps = $plan['export']['meta']['steps'];
		foreach ( $steps as &$node ) {
			if ( isset( $node['stepId'] ) && is_int( $node['stepId'] ) ) {
				$node['stepId'] = $real( $node['stepId'] );
			}
		}
		unset( $node );

		$rows = array();
		foreach ( $plan['export']['step_data'] as $temp => $row ) {
			if ( is_string( $row['data'] ) && ( false !== strpos( $row['data'], '"jump_to"' ) || false !== strpos( $row['data'], '"skip_to_step"' ) ) ) {
				$data    = json_decode( $row['data'], true );
				$changed = false;
				if ( isset( $data['sidebarData']['jump_to']['step'] ) && is_int( $data['sidebarData']['jump_to']['step'] ) && $data['sidebarData']['jump_to']['step'] > 0 ) {
					$data['sidebarData']['jump_to']['step'] = $real( $data['sidebarData']['jump_to']['step'] );
					$changed                                = true;
				}
				if ( isset( $data['sidebarData']['data']['skip_to_step']['step'] ) && is_int( $data['sidebarData']['data']['skip_to_step']['step'] ) && $data['sidebarData']['data']['skip_to_step']['step'] > 0 ) {
					$data['sidebarData']['data']['skip_to_step']['step'] = $real( $data['sidebarData']['data']['skip_to_step']['step'] );
					$changed                                             = true;
				}
				if ( $changed ) {
					$row['data'] = wp_json_encode( $data );
				}
			}
			$rows[ $real( $temp ) ] = $row;
		}

		foreach ( isset( $plan['post_refs'] ) ? $plan['post_refs'] : array() as $ref ) {
			$from = $real( $ref['temp'] );
			$data = json_decode( (string) $rows[ $from ]['data'], true );
			if ( ! is_array( $data ) || ! isset( $data['sidebarData'] ) || ! is_array( $data['sidebarData'] ) ) {
				throw new RuntimeException( 'a step reference has no data to fill' );
			}
			$slot = &$data['sidebarData'];
			foreach ( $ref['key_path'] as $key ) {
				if ( ! is_array( $slot ) || ! array_key_exists( $key, $slot ) ) {
					throw new RuntimeException( 'a step reference has no slot to fill' );
				}
				$slot = &$slot[ $key ];
			}
			$slot = $real( $ref['target_temp'] );
			unset( $slot );
			$rows[ $from ]['data'] = wp_json_encode( $data );
		}

		$start = isset( $plan['export']['data']['start'] ) ? (int) $plan['export']['data']['start'] : 0;

		return array(
			'steps' => $steps,
			'start' => $start > 0 ? $real( $start ) : 0,
			'rows'  => $rows,
		);
	}

	/** The field="…" of every {{wp_webhook_data …}} in a row's data JSON, in order, unique. */
	public static function webhook_fields( $data_json ) {
		$fields = array();
		$walk   = function ( $value ) use ( &$walk, &$fields ) {
			if ( is_array( $value ) ) {
				foreach ( $value as $v ) {
					$walk( $v );
				}

				return;
			}
			if ( is_string( $value ) ) {
				$value = self::block_attr_quotes( $value );
			}
			// Any attribute order, any case; a quoted value (group 1) may hold spaces, an unquoted one (group 2) may not.
			if ( is_string( $value ) && false !== stripos( $value, 'wp_webhook_data' ) && preg_match_all( '/\{\{\s*wp_webhook_data\b[^}]*?\bfield\s*=\s*(?:(?:"|\'|&quot;|&#039;)([^"\'&}]*)|([^"\'&}\s]*))/i', $value, $m ) ) {
				foreach ( $m[1] as $k => $field ) {
					$fields[] = trim( '' !== $field ? $field : $m[2][ $k ] );
				}
			}
		};
		$walk( json_decode( (string) $data_json, true ) );

		return array_values( array_unique( $fields ) );
	}

	/**
	 * A designed email also keeps its block markup, where serialize_block_attributes()
	 * writes quotes as \u0022 / \u0027 (and & as \u0026): read a merge tag there as it
	 * renders, or field="x" comes out as \u0022x\u0022.
	 */
	public static function block_attr_quotes( $value ) {
		return false === strpos( $value, '\u00' ) ? $value : str_replace( array( '\u0022', '\u0027', '\u0026' ), array( '"', "'", '&' ), $value );
	}

	private function refs( array $items, FKMCP_Definition_Errors $errors ) {
		$refs = array();
		foreach ( $items as $i => $item ) {
			$step = $item['step'];
			if ( ! is_array( $step ) || ! array_key_exists( 'ref', $step ) ) {
				continue;
			}
			if ( ! is_string( $step['ref'] ) || ! preg_match( FKMCP_Step_Builder::REF_PATTERN, $step['ref'] ) ) {
				$errors->add( $item['path'] . '.ref', __( 'must be 1-64 characters of a-z, 0-9, _ and -.', 'wp-marketing-automations-pro' ) );
			} elseif ( isset( $refs[ $step['ref'] ] ) ) {
				$errors->add( $item['path'] . '.ref', __( 'is already used by another step.', 'wp-marketing-automations-pro' ) );
			} else {
				$refs[ $step['ref'] ] = $i;
			}
		}

		return $refs;
	}

	/** Descriptor-level checks only: nothing here calls a translator, a resolver, or a live API. */
	private function cheap_action_check( array $step, $path, $event, FKMCP_Definition_Errors $errors ) {
		$slug = isset( $step['action'] ) && is_string( $step['action'] ) ? $step['action'] : '';

		if ( strlen( $slug ) > FKMCP_Field_Translator::KEY_MAX ) {
			$errors->add( $path . '.action', __( 'is not an action on this site.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		if ( FKMCP_Part_Registry::is_denied( $slug ) ) {
			$errors->add( $path . '.action', __( 'can\'t be added by an assistant on this site; add it in the builder.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$descriptor = FKMCP_Part_Registry::action( $slug, $event );
		if ( null === $descriptor ) {
			$why = FKMCP_Part_Registry::locked_reason( $slug, $event );
			$errors->add( $path . '.action', null !== $why ? $why : __( 'is not an action on this site.', 'wp-marketing-automations-pro' ), $errors->full() ? null : FKMCP_Field_Translator::closest( $slug, array_keys( FKMCP_Part_Registry::actions( $event ) ), 25 ) );

			return null;
		}

		$need = FKMCP_Part_Registry::connector_need( $descriptor['integration'] );
		if ( null !== $need ) {
			/* translators: %s: e.g. "connect Keap" */
			$errors->add( $path . '.action', sprintf( __( 'needs you to %s first.', 'wp-marketing-automations-pro' ), $need ) );

			return null;
		}

		$reason = FKMCP_Field_Translator::unbuildable_reason( $descriptor['fields'], $this->special );
		if ( null !== $reason ) {
			$errors->add( $path . '.action', 'wp_sendemail' === $slug ? FKMCP_Step_Builder::email_action_reason() : $reason );

			return null;
		}

		return $descriptor;
	}

	/** Field ids on this descriptor that are the dynamic-coupon ajax marker. */
	private static function marker_fields( array $descriptor ) {
		$out = array();
		foreach ( $descriptor['fields'] as $field ) {
			if ( isset( $field['id'], $field['type'] ) && 'ajax' === $field['type'] && isset( $field['ajax_cb'] ) && FKMCP_Special_Fields::DYNAMIC_COUPON_CB === sanitize_key( $field['ajax_cb'] ) ) {
				$out[] = (string) $field['id'];
			}
		}

		return $out;
	}

	/** Ref names a bad jump or skip may suggest: real targets only (spec §15.3). */
	private static function skip_allowed( array $refs, array $types, array $items, $self_index ) {
		$out = array();
		foreach ( $refs as $ref => $idx ) {
			if ( $idx === $self_index || ( isset( $types[ $idx ] ) && in_array( $types[ $idx ], self::NOT_TARGETS, true ) ) || ! empty( $items[ $idx ]['in_split'] ) ) {
				continue;
			}
			$out[] = $ref;
		}

		return $out;
	}

	private function action_row( array $step, $path, array $descriptor, array $marker_fields, array $merge_tags, array $opts, FKMCP_Definition_Errors $errors ) {
		$int  = BWFAN_Core()->integration->get_integration( $descriptor['integration'] );
		$sync = is_object( $int ) && method_exists( $int, 'need_connector' ) && $int->need_connector() ? sprintf( /* translators: %s: connector name */ __( 'sync %s', 'wp-marketing-automations-pro' ), $int->get_name() ) : null;

		$translator = new FKMCP_Field_Translator( $descriptor['fields'], $descriptor['defaults'], array(
			'merge_tags'     => $merge_tags,
			'create_missing' => ! empty( $opts['create_missing'] ),
			'resolver'       => $this->resolver,
			'special'        => $this->special,
			'needs'          => $sync,
		) );
		$before = $errors->count();
		$saved  = $translator->normalise( isset( $step['settings'] ) ? $step['settings'] : array(), $path . '.settings', $errors );

		if ( $errors->count() > $before ) {
			return null;
		}

		// The dynamic-coupon marker(s) were already validated in the cheap pass; zero them here
		// (import() fixes them up from post_refs). Anything else shaped like a "$step" marker,
		// nested anywhere but the top level, is not a spot our fixup code looks at — refuse it.
		foreach ( $saved as $key => $value ) {
			if ( in_array( $key, $marker_fields, true ) ) {
				$saved[ $key ] = 0;
				continue;
			}
			if ( self::has_step_marker( $value ) ) {
				$errors->add( $path . '.settings.' . $key, __( 'can\'t contain a "$step" reference here; only a dynamic coupon setting may.', 'wp-marketing-automations-pro' ) );
			}
		}

		if ( $errors->count() > $before ) {
			return null;
		}

		return FKMCP_Step_Builder::action( $descriptor, $saved );
	}

	/** True if $value, or anything nested inside it, is an array carrying a "$step" key. */
	private static function has_step_marker( $value ) {
		if ( ! is_array( $value ) ) {
			return false;
		}
		if ( array_key_exists( '$step', $value ) ) {
			return true;
		}
		foreach ( $value as $v ) {
			if ( self::has_step_marker( $v ) ) {
				return true;
			}
		}

		return false;
	}

	/** Replaces every {"$pending": token} sentinel found anywhere in $value with $results[token]. */
	private static function apply_pending( &$value, array $results ) {
		if ( ! is_array( $value ) ) {
			return;
		}
		if ( isset( $value['$pending'] ) && is_string( $value['$pending'] ) && array_key_exists( $value['$pending'], $results ) ) {
			$value = $results[ $value['$pending'] ];

			return;
		}
		foreach ( $value as &$v ) {
			self::apply_pending( $v, $results );
		}
		unset( $v );
	}

	private static function &dig( array &$array, array $path ) {
		$node = &$array;
		foreach ( $path as $key ) {
			$node = &$node[ $key ];
		}

		return $node;
	}

	/**
	 * The builder's own step label (jump.js:125-187, delay.js:905-962):
	 * ['Step', <node id>, ' : '+Type, …].join(' '), double spaces and all —
	 * an action adds ' - '+integration_nicename+' : ' (or ' - ') then its name,
	 * a goal adds source_label+' : ' then its name.
	 */
	private static function builder_label( $node_id, array $row, array $step, $part ) {
		$types = array( 'action' => 'Action', 'wait' => 'Delay', 'conditional' => 'Conditional', 'benchmark' => 'Goal', 'branches' => 'Branches' );
		$parts = array( 'Step', (string) $node_id );

		if ( isset( $types[ $row['node'] ] ) ) {
			$parts[] = ' : ' . $types[ $row['node'] ];
		}

		if ( is_array( $part ) && 'action' === $row['node'] ) {
			$parts[] = null !== $part['nicename'] ? ' - ' . $part['nicename'] . ' : ' : ' - ';
			$parts[] = $part['name'];
		} elseif ( is_array( $part ) && 'benchmark' === $row['node'] ) {
			if ( null !== $part['source_label'] ) {
				$parts[] = $part['source_label'] . ' : ';
			}
			$parts[] = $part['name'];
		}

		return implode( ' ', $parts );
	}

	/** What builder_label() adds for a target: an action's nicename and name, a goal's source label and name. Site text is cleaned. */
	private function label_part( $target, array $row, array $step, array $descriptors, $event_slug ) {
		$descriptor = null;
		if ( 'action' === $row['node'] ) {
			$descriptor = 'email' === $step['type'] ? FKMCP_Part_Registry::action( 'wp_sendemail', $event_slug ) : ( isset( $descriptors[ $target ] ) ? $descriptors[ $target ] : null );
		} elseif ( 'benchmark' === $row['node'] ) {
			$descriptor = isset( $descriptors[ $target ] ) ? $descriptors[ $target ] : null;
		}

		if ( null === $descriptor ) {
			return null;
		}

		return array(
			'name'         => FKMCP_Definition_Errors::clean( $descriptor['name'], 100 ),
			'nicename'     => isset( $descriptor['nicename'] ) && null !== $descriptor['nicename'] ? FKMCP_Definition_Errors::clean( $descriptor['nicename'], 100 ) : null,
			'source_label' => isset( $descriptor['source_label'] ) && null !== $descriptor['source_label'] ? FKMCP_Definition_Errors::clean( $descriptor['source_label'], 100 ) : null,
		);
	}

	/** A split title as saved (sanitized, trimmed), or '' when missing, blank or too long. */
	private static function split_title( array $step ) {
		$title = isset( $step['title'] ) && is_string( $step['title'] ) ? trim( sanitize_text_field( $step['title'] ) ) : '';

		return mb_strlen( $title ) > self::SPLIT_TITLE_MAX ? '' : $title;
	}

	/** A split description as saved: '' when absent; null when not a string or too long. */
	private static function split_desc( array $step ) {
		if ( ! array_key_exists( 'desc', $step ) ) {
			return '';
		}
		if ( ! is_string( $step['desc'] ) ) {
			return null;
		}
		$desc = trim( sanitize_textarea_field( $step['desc'] ) );

		return mb_strlen( $desc ) > self::SPLIT_DESC_MAX ? null : $desc;
	}

	/**
	 * A goal's row: its own fields and defaults (never the trigger's), the
	 * agent's settings, and bwfan_goal_run from if_not_met — always written, as
	 * the runtime needs it. Goal terms are never created (the builder doesn't),
	 * and a goal the runtime could never meet is refused.
	 */
	private function goal_row( array $step, $path, array $goal, FKMCP_Definition_Errors $errors ) {
		$settings                   = isset( $step['settings'] ) && is_array( $step['settings'] ) ? $step['settings'] : array();
		$settings['bwfan_goal_run'] = isset( $step['if_not_met'] ) ? $step['if_not_met'] : 'wait';

		$translator = new FKMCP_Field_Translator( $goal['fields'], $goal['defaults'], array(
			'merge_tags'     => array(),
			'create_missing' => false,
			'resolver'       => $this->resolver,
			'special'        => $this->special,
		) );
		$before = $errors->count();
		$saved  = $translator->normalise( $settings, $path . '.settings', $errors );

		if ( $errors->count() > $before ) {
			return null;
		}

		$slug = $goal['slug'];
		foreach ( isset( FKMCP_Part_Registry::GOAL_REQUIRED[ $slug ] ) ? FKMCP_Part_Registry::GOAL_REQUIRED[ $slug ] : array() as $fid ) {
			if ( empty( $saved[ $fid ] ) ) {
				$errors->add( $path . '.settings.' . $fid, __( 'must be set: this goal is never met without it.', 'wp-marketing-automations-pro' ) );
			}
		}

		if ( $errors->count() > $before ) {
			return null;
		}

		return array(
			'type'     => 3,
			'action'   => array(
				'benchmark' => $slug,
				'source'    => $goal['source'],
			),
			'sidebar'  => $saved,
			'status'   => 1,
			'node'     => 'benchmark',
			'refs'     => array(),
			'warnings' => array(),
		);
	}

	/** The rules translator for this trigger, made on first use: a definition with no fork never reads the rule registry. */
	private function rules_for( $event ) {
		if ( null === $this->rule_tr ) {
			$this->rule_tr = new FKMCP_Rule_Translator( $event, $this->resolver );
		}

		return $this->rule_tr;
	}

	private static function fork_row( $type, $node, $sidebar ) {
		return array(
			'type'     => $type,
			'action'   => null,
			'sidebar'  => $sidebar,
			'status'   => 1,
			'node'     => $node,
			'refs'     => array(),
			'warnings' => array(),
		);
	}

	/** A branch's name as it is saved, or '' when missing, blank or too long. */
	private static function branch_name( array $branch ) {
		$name = isset( $branch['name'] ) && is_string( $branch['name'] ) ? trim( sanitize_text_field( $branch['name'] ) ) : '';

		return mb_strlen( $name ) > self::BRANCH_NAME_MAX ? '' : $name;
	}

	/** A branch id in the builder's shape, "b_" + base36 (branches.js:47-49). Server-made; never the agent's. */
	public static function new_branch_id() {
		return 'b_' . base_convert( bin2hex( random_bytes( 5 ) ), 16, 36 );
	}

	/** update-automation keeps a branches step's ids by index (spec §15.2: they must stay stable); anything unusable gets a new one. */
	private function branch_id_for( array $keep, $b, array &$used ) {
		if ( isset( $keep[ $b ] ) && is_string( $keep[ $b ] ) && preg_match( '/^b_[a-z0-9]{1,20}$/', $keep[ $b ] ) && ! isset( $used[ $keep[ $b ] ] ) ) {
			$used[ $keep[ $b ] ] = true;

			return $keep[ $b ];
		}

		return $this->next_branch_id( $used );
	}

	private function next_branch_id( array &$used ) {
		for ( $k = 0; $k < 10; $k++ ) {
			$id = null === $this->seed
				? (string) call_user_func( $this->branch_id )
				: 'b_' . substr( base_convert( substr( hash( 'sha256', $this->seed . '|' . ( $this->seed_k++ ) ), 0, 12 ), 16, 36 ), 0, 20 ); // 12 hex chars stay inside base_convert's float precision.
			if ( preg_match( '/^b_[a-z0-9]{1,20}$/', $id ) && ! isset( $used[ $id ] ) ) {
				$used[ $id ] = true;

				return $id;
			}
		}

		throw new RuntimeException( 'could not make a unique branch id' );
	}

	/**
	 * Whether the trigger's webhook field still waits for its first test request:
	 * a webhook field the builder maps (showmap not false) with nothing stored yet.
	 * Shared by build() and set-automation-status.
	 *
	 * @param string $event      Trigger slug.
	 * @param array  $event_meta The trigger's settings as stored.
	 *
	 * @return bool
	 */
	public static function awaiting_sample( $event, array $event_meta ) {
		$descriptor = FKMCP_Part_Registry::event( (string) $event );

		foreach ( null === $descriptor ? array() : $descriptor['fields'] as $field ) {
			if ( 'webhook' === ( isset( $field['type'] ) ? $field['type'] : '' ) && ( ! isset( $field['showmap'] ) || false !== $field['showmap'] ) && empty( $event_meta[ $field['id'] ] ) ) {
				return true;
			}
		}

		return false;
	}
}
