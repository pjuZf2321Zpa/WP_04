<?php

defined( 'ABSPATH' ) || exit;

/**
 * One part's settings: form schema → JSON Schema for the agent, and agent
 * values → exactly what the builder saves. The admin save path validates
 * nothing server-side, so this is the only check between an agent and the
 * stored step (spec §2 fact 6).
 */
class FKMCP_Field_Translator {
	const TEXT_MAX = 5000;

	const ROWS_MAX = 50;

	const DEPTH_MAX = 3;

	/** An option list beyond this many entries is truncated (x-options-truncated); matches list-contact-filters' precedent. */
	const OPTIONS_MAX = 200;

	/** An option key/label carrying markup, or longer than this once stripped, is dropped rather than trusted. */
	const OPTION_TEXT_MAX = 500;

	/** An agent string used as a key (a slug, an event, a merge-tag name) is never longer than this. */
	const KEY_MAX = 100;

	/** Types handled here. Anything else goes to the special handlers or isn't offered. */
	const PLAIN = array( 'text', 'textarea', 'text_with_button', 'number', 'radio', 'wp_select', 'select', 'checkbox', 'toggle', 'checkbox_grid', 'search', 'custom_search', 'expression', 'repeater' );

	/** Shown in the builder, never stored. */
	const DISPLAY = array( 'notice', 'para', 'send_data' );

	/** A form trigger's field map (bwf_form_submit): what an agent names, saved as bwfan_{role}_field_map. */
	const FORM_MAP_ROLES = array( 'email', 'first_name', 'last_name', 'phone' );

	/** The values that mean "match everyone" for a guarded field. */
	const ANY = array( 'any', 'wc-any', 'affwp-any', 'aff-any' );

	private $fields;
	private $defaults;
	private $ctx;
	private $depth;

	public function __construct( array $fields, array $defaults, array $ctx, $depth = 0 ) {
		$this->fields   = array_values( array_filter( $fields, 'is_array' ) );
		$this->defaults = $defaults;
		$this->ctx      = $ctx + array(
			'merge_tags'     => array(),
			'guarded'        => array(),
			'create_missing' => false,
			'resolver'       => null,
			'special'        => null,
			'aliases'        => array(),
			'needs'          => null,
			// Callable( string $text ): string for site-sourced label/option text
			// (schema descriptions, enum labels). Defaults to this class's own
			// strip+cap when the caller has no scrub of its own to hand in.
			'scrub'          => null,
		);
		$this->depth    = (int) $depth;
	}

	// ─── schema ───────────────────────────────────────────────────

	public function schema() {
		$props    = array();
		$required = array();
		$alias_of = array_flip( $this->ctx['aliases'] );

		foreach ( $this->fields as $field ) {
			$id   = isset( $field['id'] ) ? (string) $field['id'] : '';
			$type = isset( $field['type'] ) ? (string) $field['type'] : '';

			if ( '' === $id || in_array( $type, self::DISPLAY, true ) || ! $this->supports( $type ) ) {
				continue;
			}

			$name = isset( $alias_of[ $id ] ) ? $alias_of[ $id ] : $id;
			$prop = $this->type_schema( $field );

			$label = self::label( $field );
			if ( '' !== $label ) {
				$prop['description'] = $label;
			}

			if ( ! empty( $field['toggler']['fields'] ) ) {
				$prop['x-applies-when'] = self::toggler_text( $field['toggler'] );
			}

			$props[ $name ] = $prop;

			if ( empty( $field['toggler']['fields'] ) && ( ( ! empty( $field['required'] ) && ! array_key_exists( $id, $this->defaults ) ) || in_array( $id, $this->ctx['guarded'], true ) ) ) {
				$required[] = $name;
			}
		}

		$schema = array(
			'type'                 => 'object',
			'additionalProperties' => false,
			'properties'           => $props,
		);

		if ( ! empty( $required ) ) {
			$schema['required'] = $required;
		}

		return $schema;
	}

	private function type_schema( array $field ) {
		$type = (string) $field['type'];

		if ( null !== $this->ctx['special'] && $this->ctx['special']->handles( $type ) ) {
			return $this->ctx['special']->schema( $field );
		}

		switch ( $type ) {
			case 'number':
				$s = array( 'type' => 'number' );
				if ( isset( $field['min'] ) && is_numeric( $field['min'] ) ) {
					$s['minimum'] = (float) $field['min'];
				}
				if ( isset( $field['max'] ) && is_numeric( $field['max'] ) ) {
					$s['maximum'] = (float) $field['max'];
				}

				return $s;
			case 'checkbox':
			case 'toggle':
				return array( 'type' => 'boolean' );
			case 'radio':
			case 'wp_select':
			case 'select':
				$one = $this->enum_schema( $field );

				return ! empty( $field['multiple'] ) ? array( 'type' => 'array', 'items' => $one ) : $one;
			case 'checkbox_grid':
				return array( 'type' => 'array', 'items' => $this->enum_schema( $field ) );
			case 'search':
			case 'custom_search':
				$item = array( 'type' => array( 'string', 'integer' ) );

				return ( isset( $field['multiple'] ) && false === $field['multiple'] ) ? $item : array( 'type' => 'array', 'items' => $item, 'description' => 'Ids or exact names.' );
			case 'expression':
				return ( new self( (array) $field['fields'], array(), $this->ctx, $this->depth + 1 ) )->schema();
			case 'repeater':
				return array( 'type' => 'array', 'maxItems' => self::ROWS_MAX, 'items' => ( new self( (array) $field['fields'], array(), $this->ctx, $this->depth + 1 ) )->schema() );
			default:
				return array( 'type' => 'string', 'maxLength' => self::TEXT_MAX );
		}
	}

	private function supports( $type ) {
		return in_array( $type, self::PLAIN, true ) || ( null !== $this->ctx['special'] && $this->ctx['special']->handles( $type ) );
	}

	/**
	 * {type: string, enum: [...]} for a select/radio/checkbox_grid field:
	 * options() has already scrubbed and capped the keys (§0.1.3 - some come
	 * from cached third-party data, e.g. a Brevo attribute name); this adds
	 * x-options-truncated when the cap bit, and x-enum-labels so an opaque
	 * key (a custom field id, "7") still reads with its label.
	 */
	private function enum_schema( array $field ) {
		$truncated = false;
		$options   = self::options( $field, $truncated );
		$enum      = array_map( 'strval', array_keys( $options ) );

		if ( empty( $enum ) ) {
			return array( 'type' => 'string' );
		}

		$schema = array( 'type' => 'string', 'enum' => $enum );

		if ( $truncated ) {
			$schema['x-options-truncated'] = true;
		}

		$labels = $this->enum_labels( $options );
		if ( ! empty( $labels ) ) {
			$schema['x-enum-labels'] = $labels;
		}

		return $schema;
	}

	/** value => scrubbed label, only where the label differs from the value, capped like the enum itself. */
	private function enum_labels( array $options ) {
		$labels = array();

		foreach ( $options as $key => $label ) {
			if ( (string) $label === (string) $key ) {
				continue;
			}

			$clean = $this->scrub( $label );
			if ( '' !== $clean ) {
				$labels[ (string) $key ] = $clean;
			}

			if ( count( $labels ) >= self::OPTIONS_MAX ) {
				break;
			}
		}

		return $labels;
	}

	/** Site text on its way into a schema: the caller's scrub (the pack's untrust()), or the same strip+cap on its own. */
	private function scrub( $value ) {
		if ( is_callable( $this->ctx['scrub'] ) ) {
			return (string) call_user_func( $this->ctx['scrub'], (string) $value );
		}

		return FKMCP_Definition_Errors::clean( $value, self::OPTION_TEXT_MAX );
	}

	// ─── normalise ────────────────────────────────────────────────

	public function normalise( $values, $path, FKMCP_Definition_Errors $errors ) {
		if ( ! is_array( $values ) ) {
			$errors->add( $path, __( 'must be an object of settings.', 'wp-marketing-automations-pro' ) );

			return array();
		}

		if ( $this->depth > self::DEPTH_MAX ) {
			$errors->add( $path, __( 'is nested too deeply.', 'wp-marketing-automations-pro' ) );

			return array();
		}

		// Aliases (run → bwfan_automation_run) and the path each id is reported under.
		$sent  = array();
		$shown = array();
		$by_id = array();
		foreach ( $this->fields as $field ) {
			if ( isset( $field['id'] ) && '' !== (string) $field['id'] ) {
				$by_id[ (string) $field['id'] ] = $field;
			}
		}
		$ids   = array_keys( $by_id );
		$alias = $this->ctx['aliases'];
		foreach ( $values as $key => $value ) {
			$key = (string) $key;
			$id  = isset( $alias[ $key ] ) ? $alias[ $key ] : $key;

			if ( ! isset( $by_id[ $id ] ) ) {
				$errors->add( $path . '.' . $key, __( 'is not a setting of this part.', 'wp-marketing-automations-pro' ), array_values( array_diff( array_map( array( $this, 'shown_name' ), $ids ), array( '' ) ) ) );
				continue;
			}

			$sent[ $id ]  = $value;
			$shown[ $id ] = $key;
		}

		// Togglers read the form as the builder holds it: defaults under sent values.
		$current = array_merge( $this->defaults, $sent );

		// Togglers compare option *values*, so a label the agent sent
		// ("Specific Tag") must count as its value ("selected_tag").
		foreach ( $sent as $id => $value ) {
			$type = isset( $by_id[ $id ]['type'] ) ? $by_id[ $id ]['type'] : '';

			if ( ! in_array( $type, array( 'radio', 'wp_select', 'select' ), true ) || ! empty( $by_id[ $id ]['multiple'] ) || ! is_scalar( $value ) ) {
				continue;
			}

			foreach ( self::options( $by_id[ $id ] ) as $key => $label ) {
				if ( (string) $key === (string) $value || 0 === strcasecmp( (string) $label, trim( (string) $value ) ) ) {
					$current[ $id ] = (string) $key;
					break;
				}
			}
		}

		$out    = array();
		$failed = array();

		// Two passes: ajax fields (and form field maps, which load the same way) last, so the dependency an ajax field posts is its sibling's
		// normalised value (a search's id, not the name sent) and a sibling that already failed
		// is never posted at all (the ajax resolver then asks for it first).
		foreach ( array( false, true ) as $ajax_pass ) {
			foreach ( $this->fields as $field ) {
				$id    = isset( $field['id'] ) ? (string) $field['id'] : '';
				$type  = isset( $field['type'] ) ? (string) $field['type'] : '';
				$fpath = $path . '.' . ( isset( $shown[ $id ] ) ? $shown[ $id ] : $this->shown_name( $id ) );

				if ( '' === $id || in_array( $type, array( 'ajax', 'bwf_form_submit' ), true ) !== $ajax_pass ) {
					continue;
				}

				$was_sent = array_key_exists( $id, $sent );

				if ( in_array( $type, self::DISPLAY, true ) || ! $this->supports( $type ) ) {
					if ( $was_sent ) {
						$errors->add( $fpath, __( 'can\'t be set by an assistant.', 'wp-marketing-automations-pro' ) );
					}
					continue;
				}

				if ( ! self::applies( $field, $current ) ) {
					if ( $was_sent ) {
						/* translators: %s: the condition, e.g. "tag-contains is selected_tag" */
						$errors->add( $fpath, sprintf( __( 'does not apply unless %s.', 'wp-marketing-automations-pro' ), self::toggler_text( $field['toggler'] ) ) );
					}
					if ( array_key_exists( $id, $this->defaults ) ) {
						$out[ $id ] = $this->defaults[ $id ];
					}
					continue;
				}

				if ( $was_sent ) {
					$siblings = $ajax_pass ? array_diff_key( array_merge( $current, $out ), $failed ) : $current;
					$value    = $this->value( $field, $sent[ $id ], $siblings, $fpath, $errors );
					if ( null !== $value ) {
						$out[ $id ] = $value;
					} else {
						$failed[ $id ] = true;
					}
					continue;
				}

				if ( array_key_exists( $id, $this->defaults ) ) {
					$out[ $id ] = $this->defaults[ $id ];
					continue;
				}

				if ( ! empty( $field['required'] ) ) {
					$errors->add( $fpath, __( 'is required.', 'wp-marketing-automations-pro' ) );
				}
			}
		}

		// Back to schema order, the order the builder saves in.
		$out = array_replace( array_intersect_key( $by_id, $out ), $out ); // array_replace: a numeric field id keeps its key.

		$this->guard( $out, $sent, $path, $errors );

		// The builder saves {...default_values, ...values}: keep defaults with no field too.
		return array_merge( array_diff_key( $this->defaults, $by_id ), $out );
	}

	/**
	 * Guarded fields must be stated, and when one isn't "any", the fields that
	 * depend on it must not be empty: "specific tag" with no tag silently
	 * matches every tag at runtime (crm_assigned_tag.php:420-436).
	 */
	private function guard( array $out, array $sent, $path, FKMCP_Definition_Errors $errors ) {
		$index = $this->index();
		foreach ( $this->ctx['guarded'] as $gid ) {
			// Not on this site's schema, or hidden by its own toggler (a Stripe offer's bump-contains when type is "offer").
			if ( ! isset( $index[ $gid ] ) || ! self::applies( $index[ $gid ], $out ) ) {
				continue;
			}

			if ( ! array_key_exists( $gid, $sent ) ) {
				if ( ! empty( $index[ $gid ]['required'] ) && ! array_key_exists( $gid, $this->defaults ) ) {
					continue; // already reported as "is required."
				}
				$options = self::options( $index[ $gid ] );
				if ( array() !== array_intersect( self::ANY, array_keys( $options ) ) ) {
					$errors->add( $path . '.' . $this->shown_name( $gid ), __( 'must be set explicitly; send "any" to match everyone.', 'wp-marketing-automations-pro' ) );
				} elseif ( array() !== $options ) {
					/* translators: %s: the allowed values, comma separated */
					$errors->add( $path . '.' . $this->shown_name( $gid ), sprintf( __( 'must be set explicitly. Allowed: %s.', 'wp-marketing-automations-pro' ), implode( ', ', array_keys( $options ) ) ) );
				} else {
					$errors->add( $path . '.' . $this->shown_name( $gid ), __( 'must be set explicitly.', 'wp-marketing-automations-pro' ) );
				}
				continue;
			}

			$value = isset( $out[ $gid ] ) ? $out[ $gid ] : null;
			if ( is_string( $value ) && in_array( $value, self::ANY, true ) ) {
				continue;
			}

			foreach ( $this->fields as $field ) {
				if ( empty( $field['toggler']['fields'] ) || ! in_array( $gid, array_column( $field['toggler']['fields'], 'id' ), true ) ) {
					continue;
				}

				if ( self::applies( $field, $out ) && self::is_empty( isset( $out[ $field['id'] ] ) ? $out[ $field['id'] ] : null ) ) {
					/* translators: %s: the guarding setting, e.g. tag-contains */
					$errors->add( $path . '.' . $this->shown_name( $field['id'] ), sprintf( __( 'is required when %s is not "any"; left empty it would match everyone.', 'wp-marketing-automations-pro' ), $this->shown_name( $gid ) ) );
				}
			}
		}
	}

	private function value( array $field, $value, array $current, $path, FKMCP_Definition_Errors $errors ) {
		$type = (string) $field['type'];

		if ( null !== $this->ctx['special'] && $this->ctx['special']->handles( $type ) ) {
			return $this->ctx['special']->normalise( $field, $value, $current, $path, $errors, $this->ctx );
		}

		switch ( $type ) {
			case 'text':
			case 'text_with_button':
			case 'textarea':
				if ( ! is_string( $value ) && ! is_int( $value ) && ! is_float( $value ) ) {
					$errors->add( $path, __( 'must be text.', 'wp-marketing-automations-pro' ) );

					return null;
				}
				$value = (string) $value;
				if ( mb_strlen( $value ) > self::TEXT_MAX ) {
					/* translators: %d: maximum length */
					$errors->add( $path, sprintf( __( 'is longer than %d characters.', 'wp-marketing-automations-pro' ), self::TEXT_MAX ) );

					return null;
				}
				self::check_merge_tags( $value, $this->ctx['merge_tags'], $path, $errors );

				return 'textarea' === $type ? sanitize_textarea_field( $value ) : sanitize_text_field( $value );

			case 'number':
				if ( ! is_int( $value ) && ! is_float( $value ) && ! ( is_string( $value ) && is_numeric( $value ) ) ) {
					$errors->add( $path, __( 'must be a number.', 'wp-marketing-automations-pro' ) );

					return null;
				}
				$n   = 0 + $value;
				$min = isset( $field['min'] ) && is_numeric( $field['min'] ) ? (float) $field['min'] : null;
				if ( null !== $min && $min >= 0 ) {
					$n = abs( $n );
				}
				if ( ( null !== $min && $n < $min ) || ( isset( $field['max'] ) && is_numeric( $field['max'] ) && $n > (float) $field['max'] ) ) {
					/* translators: 1: minimum, 2: maximum */
					$errors->add( $path, sprintf( __( 'must be between %1$s and %2$s.', 'wp-marketing-automations-pro' ), null === $min ? '-∞' : $min, isset( $field['max'] ) ? $field['max'] : '∞' ) );

					return null;
				}

				return (string) $n;

			case 'checkbox':
			case 'toggle':
				if ( ! is_bool( $value ) ) {
					$errors->add( $path, __( 'must be true or false.', 'wp-marketing-automations-pro' ) );

					return null;
				}

				return $value;

			case 'radio':
			case 'wp_select':
			case 'select':
				if ( ! empty( $field['multiple'] ) ) {
					return $this->multi_select( $field, $value, $path, $errors );
				}

				return $this->option( $field, $value, $path, $errors );

			case 'checkbox_grid':
				if ( ! is_array( $value ) ) {
					$errors->add( $path, __( 'must be a list.', 'wp-marketing-automations-pro' ) );

					return null;
				}
				$keys = array();
				foreach ( $value as $i => $one ) {
					$key = $this->option( $field, $one, $path . '[' . $i . ']', $errors );
					if ( null !== $key ) {
						$keys[ $key ] = true;
					}
				}

				return array_map( 'strval', array_keys( $keys ) );

			case 'search':
			case 'custom_search':
				$single = isset( $field['multiple'] ) && false === $field['multiple'];
				$list   = is_array( $value ) ? array_values( $value ) : array( $value );
				if ( $single && count( $list ) > 1 ) {
					$errors->add( $path, __( 'takes one value.', 'wp-marketing-automations-pro' ) );

					return null;
				}
				if ( null === $this->ctx['resolver'] ) {
					$errors->add( $path, __( 'can\'t be looked up here.', 'wp-marketing-automations-pro' ) );

					return null;
				}
				$free = ! empty( $field['allowFreeTextSearch'] ) && ! empty( $this->ctx['create_missing'] );

				return $this->ctx['resolver']->resolve( $field, $list, $path, $errors, $free );

			case 'expression':
				$sub = new self( (array) $field['fields'], isset( $this->defaults[ $field['id'] ] ) && is_array( $this->defaults[ $field['id'] ] ) ? $this->defaults[ $field['id'] ] : array(), $this->sub_ctx(), $this->depth + 1 );

				return $sub->normalise( $value, $path, $errors );

			case 'repeater':
				if ( ! is_array( $value ) || count( $value ) > self::ROWS_MAX ) {
					/* translators: %d: maximum rows */
					$errors->add( $path, sprintf( __( 'must be a list of at most %d rows.', 'wp-marketing-automations-pro' ), self::ROWS_MAX ) );

					return null;
				}
				$row_defaults = array();
				foreach ( (array) $field['fields'] as $sub_field ) {
					if ( isset( $sub_field['id'], $sub_field['default'] ) ) {
						$row_defaults[ $sub_field['id'] ] = $sub_field['default'];
					}
				}
				$rows = array();
				foreach ( array_values( $value ) as $i => $row ) {
					$rows[] = ( new self( (array) $field['fields'], $row_defaults, $this->sub_ctx(), $this->depth + 1 ) )->normalise( $row, $path . '[' . $i . ']', $errors );
				}

				return $rows;
		}

		return null;
	}

	/** Nested fields don't inherit trigger-level guards or aliases. */
	private function sub_ctx() {
		return array_merge( $this->ctx, array( 'guarded' => array(), 'aliases' => array() ) );
	}

	private function option( array $field, $value, $path, FKMCP_Definition_Errors $errors ) {
		$options = self::options( $field );

		if ( empty( $options ) ) {
			$errors->add( $path, null !== $this->ctx['needs'] ? sprintf( /* translators: %s: e.g. "sync Keap" */ __( 'has no options yet; %s first.', 'wp-marketing-automations-pro' ), $this->ctx['needs'] ) : __( 'has no options available on this site.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		if ( is_scalar( $value ) ) {
			foreach ( $options as $key => $label ) {
				if ( (string) $key === (string) $value ) {
					return (string) $key;
				}
			}
			foreach ( $options as $key => $label ) {
				if ( 0 === strcasecmp( (string) $label, trim( (string) $value ) ) ) {
					return (string) $key;
				}
			}
		}

		$errors->add( $path, __( 'is not one of the options.', 'wp-marketing-automations-pro' ), array_map( 'strval', array_keys( $options ) ) );

		return null;
	}

	private function multi_select( array $field, $value, $path, FKMCP_Definition_Errors $errors ) {
		if ( ! is_array( $value ) ) {
			$errors->add( $path, __( 'must be a list.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$options = self::options( $field );
		$out     = array();
		foreach ( array_values( $value ) as $i => $one ) {
			$key = $this->option( $field, $one, $path . '[' . $i . ']', $errors );
			if ( null !== $key && ! isset( $out[ $key ] ) ) {
				// The builder's saved shape for a multiple select (map-input-fields.js:277-311).
				$out[ $key ] = array( 'key' => $key, 'label' => (string) $options[ $key ], 'value' => array( 'id' => $key ) );
			}
		}

		return array_values( $out );
	}

	// ─── helpers ──────────────────────────────────────────────────

	/**
	 * The builder's hasToggler (panel-type/action.js:110-167): OR by default,
	 * AND supported, anything else hides the field; a missing value means
	 * truthy, an array means "includes", '' means "not empty"; loose ==.
	 */
	public static function applies( array $field, array $values ) {
		if ( empty( $field['toggler']['fields'] ) || ! is_array( $field['toggler']['fields'] ) ) {
			return true;
		}

		$relation = isset( $field['toggler']['relation'] ) ? strtoupper( (string) $field['toggler']['relation'] ) : 'OR';
		if ( ! in_array( $relation, array( 'OR', 'AND' ), true ) ) {
			return false;
		}

		$results = array();
		foreach ( $field['toggler']['fields'] as $cond ) {
			$actual = isset( $cond['id'], $values[ $cond['id'] ] ) ? $values[ $cond['id'] ] : null;

			if ( ! array_key_exists( 'value', $cond ) ) {
				$results[] = true == $actual; // phpcs:ignore Universal.Operators.StrictComparisons -- the builder compares loosely.
			} elseif ( is_array( $cond['value'] ) ) {
				$results[] = in_array( $actual, $cond['value'] ); // phpcs:ignore WordPress.PHP.StrictInArray -- loose, like the builder.
			} elseif ( '' === $cond['value'] ) {
				// JS: value != '' — the number 0 equals '' there; the string '0' does not.
				$results[] = ! self::is_empty( $actual ) && 0 !== $actual && 0.0 !== $actual;
			} else {
				$results[] = $actual == $cond['value']; // phpcs:ignore Universal.Operators.StrictComparisons -- loose, like the builder.
			}
		}

		return 'AND' === $relation ? ! in_array( false, $results, true ) : in_array( true, $results, true );
	}

	/** Why a part can't be built: a required field of a type nothing here can fill. */
	public static function unbuildable_reason( array $fields, $special ) {
		foreach ( $fields as $field ) {
			$type = isset( $field['type'] ) ? (string) $field['type'] : '';
			$ok   = in_array( $type, self::PLAIN, true ) || in_array( $type, self::DISPLAY, true ) || ( null !== $special && $special->handles( $type ) );

			if ( ! $ok && ! empty( $field['required'] ) ) {
				/* translators: 1: field id, 2: field type */
				return sprintf( __( 'Setting "%1$s" uses a field type (%2$s) an assistant can\'t fill yet.', 'wp-marketing-automations-pro' ), isset( $field['id'] ) ? $field['id'] : '?', $type );
			}
		}

		return null;
	}

	/** Every {{tag …}} must be a tag valid for the trigger; the first token is the tag. */
	public static function check_merge_tags( $text, array $allowed, $path, FKMCP_Definition_Errors $errors ) {
		if ( false === strpos( (string) $text, '{{' ) || ! preg_match_all( '/\{\{(.*?)\}\}/s', (string) $text, $m ) ) {
			return;
		}

		foreach ( array_unique( $m[1] ) as $inner ) {
			$tag = strtok( trim( $inner ), " \t\n" );

			if ( false === $tag || '' === $tag || isset( $allowed[ $tag ] ) ) {
				continue;
			}

			/* translators: %s: merge tag name */
			$message = sprintf( __( 'uses the merge tag {{%s}}, which this trigger does not provide.', 'wp-marketing-automations-pro' ), mb_substr( sanitize_key( substr( $tag, 0, self::KEY_MAX ) ), 0, 80 ) );
			$errors->add( $path, $message, strlen( $tag ) > self::KEY_MAX || $errors->full() ? null : self::closest( $tag, array_keys( $allowed ) ) );
		}
	}

	/** Needle and candidates cut to KEY_MAX: levenshtein() is O(n·m), and no real slug is longer. */
	public static function closest( $needle, array $haystack, $n = 5 ) {
		$needle = strtolower( substr( (string) $needle, 0, self::KEY_MAX ) );
		$scored = array();

		foreach ( $haystack as $candidate ) {
			$scored[ (string) $candidate ] = levenshtein( $needle, strtolower( substr( (string) $candidate, 0, self::KEY_MAX ) ) );
		}

		asort( $scored );

		return array_slice( array_keys( $scored ), 0, $n );
	}

	/**
	 * Options as key => label, whether the schema gives [{label,value}] or
	 * {key: label}. Option KEYS become settings_schema enum values and the
	 * values an agent may send back - for connector fields (a HubSpot
	 * pipeline/stage id, a Brevo attribute name) they are cached third-party
	 * data, not developer-authored text, so a key carrying markup (or one
	 * that only fits after stripping it) is dropped rather than trusted
	 * (§0.1.3). Capped at OPTIONS_MAX so one runaway list can't blow up the
	 * schema; $truncated reports whether that cap bit, same list either way
	 * that normalise() validates against, so the schema never advertises an
	 * option normalise() would then refuse, or accepts one it doesn't.
	 *
	 * @param array     $field
	 * @param bool|null $truncated
	 *
	 * @return array<string, string>
	 */
	public static function options( array $field, &$truncated = null ) {
		$truncated = false;
		$raw       = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$out       = array();

		foreach ( $raw as $key => $option ) {
			if ( is_array( $option ) && array_key_exists( 'value', $option ) ) {
				if ( '' === (string) $option['value'] ) {
					continue; // "Select" placeholders.
				}
				$k     = (string) $option['value'];
				$label = isset( $option['label'] ) ? wp_strip_all_tags( (string) $option['label'] ) : $k;
			} elseif ( is_scalar( $option ) && '' !== (string) $key ) {
				$k     = (string) $key;
				$label = wp_strip_all_tags( (string) $option );
			} else {
				continue;
			}

			if ( $k !== mb_substr( wp_strip_all_tags( $k, true ), 0, self::OPTION_TEXT_MAX ) ) {
				continue; // fail closed: markup, a fake boundary or an over-long key - drop it rather than trust it.
			}

			if ( count( $out ) >= self::OPTIONS_MAX ) {
				$truncated = true;
				continue;
			}

			$out[ $k ] = $label;
		}

		return $out;
	}

	/** @return array<string, array> fields by id */
	private function index() {
		$by_id = array();
		foreach ( $this->fields as $field ) {
			if ( isset( $field['id'] ) && '' !== (string) $field['id'] ) {
				$by_id[ (string) $field['id'] ] = $field;
			}
		}

		return $by_id;
	}

	private function shown_name( $id ) {
		$alias_of = array_flip( $this->ctx['aliases'] );

		return isset( $alias_of[ $id ] ) ? $alias_of[ $id ] : (string) $id;
	}

	public static function label( array $field ) {
		$parts = array();
		foreach ( array( 'label', 'tip', 'hint' ) as $key ) {
			if ( ! empty( $field[ $key ] ) && is_string( $field[ $key ] ) ) {
				$parts[] = wp_strip_all_tags( $field[ $key ] );
			}
		}

		return mb_substr( implode( ' — ', $parts ), 0, 300 );
	}

	private static function toggler_text( array $toggler ) {
		$bits = array();
		foreach ( (array) $toggler['fields'] as $cond ) {
			$id     = isset( $cond['id'] ) ? (string) $cond['id'] : '?';
			$bits[] = ! array_key_exists( 'value', $cond ) ? $id . ' is on' : ( is_array( $cond['value'] ) ? $id . ' is one of ' . implode( '/', $cond['value'] ) : ( '' === $cond['value'] ? $id . ' is set' : $id . ' is ' . $cond['value'] ) );
		}

		return implode( isset( $toggler['relation'] ) && 'AND' === strtoupper( $toggler['relation'] ) ? ' and ' : ' or ', $bits );
	}

	private static function is_empty( $value ) {
		return null === $value || '' === $value || array() === $value || false === $value;
	}
}
