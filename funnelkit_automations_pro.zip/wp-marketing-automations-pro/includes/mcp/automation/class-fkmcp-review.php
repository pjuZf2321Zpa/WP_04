<?php

defined( 'ABSPATH' ) || exit;

/**
 * Review before save (spec §4): a signed, single-use, 15-minute token bound to the
 * user, the plan hash and (update) the automation id and revision. No hooks; the pack
 * calls it. The token carries no secret data; the server keeps the required-step list.
 */
class FKMCP_Review {

	const TTL    = 900;
	const PREFIX = 'fkmcp_rv_';

	/** Max characters of missing paths listed in a review_required message (the adapter shows only the message). */
	const LIST_MAX = 1500;

	public static function now() {
		return (int) apply_filters( 'fkmcp_review_now', time() );
	}

	/** Review is always required; the filter is for automated tests and CI only, never an admin setting. */
	public static function required_setting() {
		return (bool) apply_filters( 'fkmcp_require_review', true );
	}

	/** Kept false until the adapter can push a server-to-client request over a streaming transport (mcp-adapter 0.6.1's HTTP transport has none — GET returns 405); the filter exists for that switch-on. */
	public static function elicitation_supported() {
		return false && (bool) apply_filters( 'fkmcp_review_elicitation', false );
	}

	/** The normalised plan, not its prose: export, refs, pending terms, templates and the caller's extras (title, categories, aid, reuse…). */
	public static function plan_hash( array $plan, array $extra ) {
		$pending = array();
		foreach ( isset( $plan['pending'] ) ? (array) $plan['pending'] : array() as $token => $info ) {
			$pending[ $token ] = array( $info['type'], $info['values'] );
		}
		$templates = array();
		foreach ( isset( $plan['emails'] ) ? (array) $plan['emails'] : array() as $email ) {
			$templates[] = array( isset( $email['path'] ) ? $email['path'] : '', isset( $email['template_id'] ) ? $email['template_id'] : null, isset( $email['mode'] ) ? $email['mode'] : null );
		}

		$json = wp_json_encode( array(
			'export'    => isset( $plan['export'] ) ? $plan['export'] : null,
			'post_refs' => isset( $plan['post_refs'] ) ? $plan['post_refs'] : null,
			'pending'   => $pending,
			'templates' => $templates,
			'extra'     => $extra,
		) );

		// fail closed: an unencodable plan never matches (INF/NaN, nesting past 512 — json_encode() returns false)
		return hash( 'sha256', false === $json ? random_bytes( 32 ) : $json );
	}

	/**
	 * The nonce is derived from what is reviewed, so reviewing the same plan again
	 * rewrites one row (and retires the earlier token) instead of adding a row per call.
	 */
	public static function issue( $hash, array $required, $aid = 0, $revision = '' ) {
		$nonce = substr( hash_hmac( 'sha256', implode( '|', array( 'nonce', (string) get_current_user_id(), (string) (int) $aid, (string) $revision, (string) $hash ) ), wp_salt( 'auth' ) ), 0, 20 );
		$exp   = self::now() + self::TTL;
		set_transient( self::PREFIX . $nonce, array( 'required' => array_values( array_map( 'strval', $required ) ), 'exp' => $exp ), self::TTL );

		return array(
			'token'   => 'v1.' . $nonce . '.' . $exp . '.' . self::sign( $nonce, $exp, (int) $aid, (string) $revision, $hash ),
			'expires' => gmdate( 'Y-m-d\TH:i:s\Z', $exp ),
		);
	}

	/**
	 * Everything but the consume, cheapest first, so a failure never burns a valid token.
	 *
	 * @return true|WP_Error
	 */
	public static function check( $token, $hash, $confirmed, $aid = 0, $revision = '' ) {
		$parts = self::parse( $token );
		if ( null === $parts || $parts['exp'] < self::now() ) {
			return self::stale();
		}

		$stored = get_transient( self::PREFIX . $parts['nonce'] );
		if ( ! is_array( $stored ) || ! isset( $stored['required'] ) || (int) $stored['exp'] !== $parts['exp'] ) {
			return self::stale();
		}

		if ( ! hash_equals( self::sign( $parts['nonce'], $parts['exp'], (int) $aid, (string) $revision, (string) $hash ), $parts['sig'] ) ) {
			return self::stale();
		}

		$confirmed = is_array( $confirmed ) ? array_map( 'strval', array_filter( $confirmed, 'is_scalar' ) ) : array();
		$missing   = array_values( array_diff( $stored['required'], $confirmed ) );
		if ( ! empty( $missing ) ) {
			return self::required( $missing );
		}

		return true;
	}

	/** Atomic enough: delete_transient() is true only for the call that removed the row — a persistent object-cache drop-in must return an accurate wp_cache_delete() result. */
	public static function consume( $token ) {
		$parts = self::parse( $token );

		return null !== $parts && true === delete_transient( self::PREFIX . $parts['nonce'] );
	}

	/** fkmcp_review_required with the paths to confirm, in the message (error data never reaches the agent). */
	public static function required( array $missing ) {
		$list = implode( ', ', $missing );
		if ( strlen( $list ) > self::LIST_MAX ) {
			$cut   = substr( $list, 0, self::LIST_MAX );
			$pos   = strrpos( $cut, ', ' );
			$shown = false !== $pos ? substr( $cut, 0, $pos ) : '';
			$count = '' === $shown ? 0 : substr_count( $shown, ', ' ) + 1;
			$list  = $shown . sprintf( ' (+%d more)', count( $missing ) - $count );
		}

		/* translators: %s: step paths, comma separated */
		return new WP_Error( 'fkmcp_review_required', sprintf( __( 'Review first: call again with mode "review", show the user each step, then send review_token and confirmed_steps. Still to confirm: %s.', 'wp-marketing-automations-pro' ), $list ) );
	}

	public static function stale() {
		return new WP_Error( 'fkmcp_review_stale', __( 'The review no longer matches (changed definition, automation or user; site data the plan uses, such as templates, tags, lists or categories, changed; or the token expired or was used). Run mode "review" again and confirm the new sheet.', 'wp-marketing-automations-pro' ) );
	}

	private static function sign( $nonce, $exp, $aid, $revision, $hash ) {
		return hash_hmac( 'sha256', implode( '|', array( 'v1', $nonce, (string) $exp, (string) get_current_user_id(), (string) $aid, $revision, $hash ) ), wp_salt( 'auth' ) );
	}

	private static function parse( $token ) {
		if ( ! is_string( $token ) || 1 !== preg_match( '/^v1\.([A-Za-z0-9]{20})\.(\d{10})\.([a-f0-9]{64})$/D', $token, $m ) ) {
			return null;
		}

		return array( 'nonce' => $m[1], 'exp' => (int) $m[2], 'sig' => $m[3] );
	}
}
