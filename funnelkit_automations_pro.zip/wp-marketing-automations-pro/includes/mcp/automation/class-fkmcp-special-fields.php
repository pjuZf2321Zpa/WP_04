<?php

defined( 'ABSPATH' ) || exit;

/** Thrown by our wp_die_ajax_handler to take control back from an ajax handler. */
class FKMCP_Ajax_Halt extends Exception {
}

/**
 * Field types that aren't a plain value: each one has its own saved shape,
 * and some need a lookup or a live API call to validate (spec §5.1).
 */
class FKMCP_Special_Fields {
	const HTTP_TIMEOUT = 8;

	/** Seconds all Google Sheets calls of one build may take together; later sheets are refused, never left unchecked. */
	const SHEETS_TIME_BUDGET = 20;

	const TYPES = array( 'create_coupon', 'group_select', 'google_sheet', 'image_upload', 'webhook', 'ajax', 'bwf_form_submit' );

	/**
	 * Callbacks that once ended the request with a bare exit, as {cb: the
	 * owning plugin's version}: not called again until that plugin updates.
	 */
	const AJAX_SKIP_OPTION = 'fkmcp_ajax_unresolvable';

	/** Lists the saved Create Coupon steps of the automation, which doesn't exist yet at create time. */
	const DYNAMIC_COUPON_CB = 'bwfan_get_automation_wc_dynamic_coupon';

	/** The callback running right now, for the shutdown guard. */
	private static $in_ajax = null;

	private static $guard = false;

	/** The pending superglobal/filter restore for the call in flight; run once, from whichever path notices first. */
	private static $restore = null;

	private $ajax_memo = array();

	/** Google Sheets answers for this build, by spreadsheet (and worksheet): steps on one sheet share a lookup. */
	private $sheet_memo = array();

	private $sheets_started = null;

	const COUPON_KEYS = array( 'type', 'existing_code', 'title', 'description', 'discount_type', 'amount', 'prefix', 'expiry', 'allow_shipping', 'min_spend', 'max_spend', 'individual_use', 'exclude_sale_items', 'restrict_to_contact_email', 'products', 'exclude_products', 'categories', 'exclude_categories', 'usage_limit_per_coupon', 'usage_limit_per_user', 'usage_limit_x_items' );

	const EXPIRY_UNITS = array( 'min', 'hours', 'days', 'weeks', 'months' );

	const IMAGE_MIME = array( 'image/jpeg', 'image/png', 'image/gif' );

	private $resolver;

	/** Callable( string $text ): string for site/connector-sourced label text in a schema; null falls back to strip+cap. */
	private $scrub;

	public function __construct( $resolver = null, $scrub = null ) {
		$this->resolver = $resolver;
		$this->scrub    = is_callable( $scrub ) ? $scrub : null;
	}

	public function handles( $type ) {
		return in_array( (string) $type, self::TYPES, true );
	}

	public function schema( array $field ) {
		switch ( $field['type'] ) {
			case 'create_coupon':
				return array(
					'type'        => 'object',
					'description' => 'type "new" (amount, expiry required; discount_type defaults to percent) or "existing" (existing_code). expiry: {type:"after", value, unit:min|hours|days|weeks|months} | {type:"on", date:"YYYY-MM-DD"} | {type:"never"}. To send the code in a later email, create the Automation first, then list-coupons with its automation_id gives this step\'s {{wc_dynamic_coupon id="N"}} tag; add it with update-automation.',
					'properties'  => array_fill_keys( self::COUPON_KEYS, new stdClass() ),
				);
			case 'group_select':
				return $this->group_select_schema( $field );
			case 'google_sheet':
				return array( 'type' => 'object', 'description' => 'spreadsheet (id or URL), worksheet (title), columns [{column: header or letter, value}]' . ( in_array( $this->operation( $field ), array( 'update', 'delete' ), true ) ? ', lookup {column, value} (required)' : '' ) . '.' );
			case 'image_upload':
				return array( 'type' => array( 'integer', 'string' ), 'description' => 'A media-library image id, or a public https URL to a JPG, PNG or GIF.' );
			case 'ajax':
				if ( self::DYNAMIC_COUPON_CB === ( isset( $field['ajax_cb'] ) ? $field['ajax_cb'] : '' ) ) {
					return array( 'type' => 'object', 'properties' => array( '$step' => array( 'type' => 'string' ) ), 'required' => array( '$step' ), 'description' => '{"$step": "<ref of an earlier Create Coupon step>"}' );
				}
				$deps = isset( $field['ajax_field'] ) && is_array( $field['ajax_field'] ) ? array_values( $field['ajax_field'] ) : array();

				return array( 'type' => 'string', 'description' => 'One of the options this setting offers, loaded the way the builder loads them' . ( $deps ? ' after setting ' . implode( ', ', $deps ) : '' ) . '. describe-automation-part cannot list them in advance; a wrong value is answered with the valid labels.' );
			case 'bwf_form_submit':
				$deps = isset( $field['ajax_field'] ) && is_array( $field['ajax_field'] ) ? array_values( $field['ajax_field'] ) : array();

				return array(
					'type'        => 'object',
					'properties'  => array_fill_keys( FKMCP_Field_Translator::FORM_MAP_ROLES, array( 'type' => 'string' ) ),
					'description' => 'Which field of the chosen form holds the Contact\'s email, first name, last name and phone: each a field key or label' . ( $deps ? ', after setting ' . implode( ', ', $deps ) : '' ) . '. email may be left out when the form has exactly one email field. describe-automation-part cannot list the form\'s fields; a wrong one is answered with them.',
				);
			default: // webhook
				return array( 'type' => 'string', 'description' => 'Dotted path to the email in the webhook payload, e.g. contact.email. Use get-webhook-sample after a test request to see the paths.' );
		}
	}

	public function normalise( array $field, $value, array $current, $path, FKMCP_Definition_Errors $errors, array $ctx ) {
		switch ( $field['type'] ) {
			case 'create_coupon':
				return $this->coupon( $value, $path, $errors, $ctx );
			case 'group_select':
				return $this->group_select( $field, $value, $path, $errors, $ctx );
			case 'google_sheet':
				return $this->google_sheet( $field, $value, $path, $errors, $ctx );
			case 'image_upload':
				return $this->image( $value, $path, $errors );
			case 'webhook':
				return $this->webhook( $field, $value, $path, $errors, $ctx );
			case 'ajax':
				return $this->ajax( $field, $value, $current, $path, $errors, $ctx );
			case 'bwf_form_submit':
				return $this->form_map( $field, $value, $current, $path, $errors, $ctx );
		}

		return null;
	}

	// ─── create_coupon ────────────────────────────────────────────

	private function coupon( $in, $path, FKMCP_Definition_Errors $errors, array $ctx ) {
		if ( ! is_array( $in ) ) {
			$errors->add( $path, __( 'must be an object.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$before = $errors->count();
		foreach ( array_diff( array_keys( $in ), self::COUPON_KEYS ) as $key ) {
			$errors->add( $path . '.' . $key, __( 'is not a coupon setting.', 'wp-marketing-automations-pro' ), self::COUPON_KEYS );
		}

		$type = isset( $in['type'] ) ? $in['type'] : 'new';
		if ( ! in_array( $type, array( 'new', 'existing' ), true ) ) {
			$errors->add( $path . '.type', __( 'must be "new" or "existing".', 'wp-marketing-automations-pro' ) );

			return null;
		}

		// The action itself defaults coupon_type to "new" when absent
		// (class-bwfan-wc-create-coupon.php:44), and the builder's own saved
		// data leaves the key out for a new coupon - only "existing" is ever
		// written explicitly.
		$out     = array();
		$general = array();

		if ( 'existing' === $type ) {
			$out['type'] = $type;
			$code        = isset( $in['existing_code'] ) && is_string( $in['existing_code'] ) ? trim( $in['existing_code'] ) : '';
			$id          = '' !== $code ? (int) wc_get_coupon_id_by_code( $code ) : 0;
			if ( $id <= 0 || 'shop_coupon' !== get_post_type( $id ) ) {
				$errors->add( $path . '.existing_code', __( 'must be the code of an existing coupon.', 'wp-marketing-automations-pro' ) );
			} else {
				$out['coupon_id'] = array( 'key' => $id, 'label' => (string) get_the_title( $id ) );
			}
		}

		foreach ( array( 'title' => 'title', 'description' => 'description', 'prefix' => 'coupon_prefix' ) as $key => $saved ) {
			if ( isset( $in[ $key ] ) ) {
				if ( ! is_string( $in[ $key ] ) || mb_strlen( $in[ $key ] ) > 200 ) {
					$errors->add( $path . '.' . $key, __( 'must be text of at most 200 characters.', 'wp-marketing-automations-pro' ) );
					continue;
				}
				FKMCP_Field_Translator::check_merge_tags( $in[ $key ], $ctx['merge_tags'], $path . '.' . $key, $errors );
				$general[ $saved ] = sanitize_text_field( $in[ $key ] );
			}
		}

		if ( 'new' === $type ) {
			$types = wc_get_coupon_types();
			// The builder's own "Create Coupon" action defaults to percent when
			// general.discount_type is absent (class-bwfan-wc-create-coupon.php:54),
			// and its own admin UI can leave the field unset - so an omitted value
			// here is not an error, only an explicit unknown one is.
			$dtype = isset( $in['discount_type'] ) ? (string) $in['discount_type'] : 'percent';
			if ( ! isset( $types[ $dtype ] ) ) {
				$errors->add( $path . '.discount_type', __( 'is not a WooCommerce discount type.', 'wp-marketing-automations-pro' ), array_keys( $types ) );
			} elseif ( isset( $in['discount_type'] ) ) {
				// Left out when the agent didn't send it either, matching the
				// builder: it saves general.discount_type only once the field
				// has been touched, and the action defaults it to percent.
				$general['discount_type'] = $dtype;
			}

			$amount = isset( $in['amount'] ) ? $in['amount'] : null;
			if ( ! is_int( $amount ) && ! is_float( $amount ) || $amount < 0 || ( 'percent' === $dtype && $amount > 100 ) ) {
				$errors->add( $path . '.amount', 'percent' === $dtype ? __( 'must be a number from 0 to 100.', 'wp-marketing-automations-pro' ) : __( 'must be a number of 0 or more.', 'wp-marketing-automations-pro' ) );
			} else {
				$general['amount'] = $amount;
			}
		}

		$expiry = isset( $in['expiry'] ) && is_array( $in['expiry'] ) ? $in['expiry'] : array( 'type' => 'new' === $type ? '' : 'never' );
		switch ( isset( $expiry['type'] ) ? $expiry['type'] : '' ) {
			case 'after':
				$value = isset( $expiry['value'] ) ? $expiry['value'] : null;
				if ( ! is_int( $value ) || $value < 1 ) {
					$errors->add( $path . '.expiry.value', __( 'must be a whole number of 1 or more.', 'wp-marketing-automations-pro' ) );
				}
				if ( ! isset( $expiry['unit'] ) || ! in_array( $expiry['unit'], self::EXPIRY_UNITS, true ) ) {
					$errors->add( $path . '.expiry.unit', __( 'is not a unit.', 'wp-marketing-automations-pro' ), self::EXPIRY_UNITS );
				}
				$general['specific_expiry_type'] = '1';
				$general['expiry']               = array( 'unit' => isset( $expiry['unit'] ) ? (string) $expiry['unit'] : '', 'text' => (string) (int) $value );
				break;
			case 'on':
				$date = isset( $expiry['date'] ) ? (string) $expiry['date'] : '';
				$ts   = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ? strtotime( $date . ' 23:59:59' ) : false;
				if ( false === $ts || $ts < time() ) {
					$errors->add( $path . '.expiry.date', __( 'must be a future date, YYYY-MM-DD.', 'wp-marketing-automations-pro' ) );
				}
				$general['specific_expiry_type'] = '2';
				$general['expiry']               = $date;
				break;
			case 'never':
				$general['specific_expiry_type'] = '3';
				break;
			default:
				$errors->add( $path . '.expiry', __( 'is required: {type:"after"|"on"|"never"}.', 'wp-marketing-automations-pro' ) );
		}

		if ( isset( $in['allow_shipping'] ) ) {
			$general['allow_shipping'] = $this->bool( $in['allow_shipping'], $path . '.allow_shipping', $errors );
		}

		$restrictions = array();
		foreach ( array( 'min_spend' => 'min_spend', 'max_spend' => 'max_spend' ) as $key => $saved ) {
			if ( isset( $in[ $key ] ) ) {
				if ( ! is_int( $in[ $key ] ) && ! is_float( $in[ $key ] ) || $in[ $key ] < 0 ) {
					$errors->add( $path . '.' . $key, __( 'must be a number of 0 or more.', 'wp-marketing-automations-pro' ) );
				} else {
					$restrictions[ $saved ] = $in[ $key ];
				}
			}
		}
		foreach ( array( 'individual_use' => 'individual_use', 'exclude_sale_items' => 'exclude_sale_item', 'restrict_to_contact_email' => 'restrict_customer_email' ) as $key => $saved ) {
			if ( isset( $in[ $key ] ) ) {
				$restrictions[ $saved ] = $this->bool( $in[ $key ], $path . '.' . $key, $errors );
			}
		}
		foreach ( array( 'products' => 'products', 'exclude_products' => 'products', 'categories' => 'categories', 'exclude_categories' => 'categories' ) as $key => $kind ) {
			if ( isset( $in[ $key ] ) ) {
				$list = null !== $this->resolver ? $this->resolver->resolve( array( 'type' => 'search', 'autocompleter' => $kind ), (array) $in[ $key ], $path . '.' . $key, $errors, false ) : null;
				if ( null !== $list ) {
					$restrictions[ $key ] = $list;
				}
			}
		}

		$limits = array();
		foreach ( array( 'usage_limit_per_coupon' => 'usage_limit_per_coupon', 'usage_limit_per_user' => 'usage_limit_per_user', 'usage_limit_x_items' => 'usage_limit_x_item' ) as $key => $saved ) {
			if ( isset( $in[ $key ] ) ) {
				if ( ! is_int( $in[ $key ] ) || $in[ $key ] < 1 ) {
					$errors->add( $path . '.' . $key, __( 'must be a whole number of 1 or more.', 'wp-marketing-automations-pro' ) );
				} else {
					$limits[ $saved ] = $in[ $key ];
				}
			}
		}

		if ( $errors->count() > $before ) {
			return null;
		}

		$out['general'] = $general;
		if ( ! empty( $restrictions ) ) {
			$out['restrictions'] = $restrictions;
		}
		if ( ! empty( $limits ) ) {
			$out['limits'] = $limits;
		}

		return $out;
	}

	private function bool( $value, $path, FKMCP_Definition_Errors $errors ) {
		if ( ! is_bool( $value ) ) {
			$errors->add( $path, __( 'must be true or false.', 'wp-marketing-automations-pro' ) );

			return false;
		}

		return $value;
	}

	// ─── group_select ─────────────────────────────────────────────

	/**
	 * {group: {value: label}} → [value => "Group / Label"]; non-array options
	 * (a 403 string) → []. Values are connector-sourced (a HubSpot
	 * pipeline/stage id) - one carrying markup, or one that only fits after
	 * stripping it, is dropped rather than trusted (§0.1.3); capped at
	 * OPTIONS_MAX, the same list either way that group_select() validates
	 * against, so the schema never advertises an option group_select() would
	 * then refuse, or accepts one it doesn't.
	 *
	 * @param array     $field
	 * @param bool|null $truncated
	 */
	private function flat_groups( array $field, &$truncated = null ) {
		$truncated = false;
		$flat      = array();
		if ( ! isset( $field['options'] ) || ! is_array( $field['options'] ) ) {
			return $flat;
		}
		foreach ( $field['options'] as $group => $options ) {
			foreach ( (array) $options as $value => $label ) {
				$key = (string) $value;

				if ( $key !== mb_substr( wp_strip_all_tags( $key, true ), 0, FKMCP_Field_Translator::OPTION_TEXT_MAX ) ) {
					continue; // fail closed: markup, a fake boundary or an over-long key - drop it rather than trust it.
				}

				if ( count( $flat ) >= FKMCP_Field_Translator::OPTIONS_MAX ) {
					$truncated = true;
					continue;
				}

				$flat[ $key ] = wp_strip_all_tags( $group . ' / ' . $label );
			}
		}

		return $flat;
	}

	/** The group_select schema: enum of scrubbed values, x-options-truncated when capped, x-enum-labels ("Pipeline / Stage") since group_select() accepts that text too. */
	private function group_select_schema( array $field ) {
		$truncated = false;
		$flat      = $this->flat_groups( $field, $truncated );
		$schema    = array( 'type' => 'string', 'enum' => array_keys( $flat ), 'description' => 'The value, or "Pipeline / Stage".' );

		if ( $truncated ) {
			$schema['x-options-truncated'] = true;
		}

		$labels = array();
		foreach ( $flat as $key => $label ) {
			if ( $label === $key ) {
				continue;
			}
			$clean = $this->scrub_label( $label );
			if ( '' !== $clean ) {
				$labels[ $key ] = $clean;
			}
			if ( count( $labels ) >= FKMCP_Field_Translator::OPTIONS_MAX ) {
				break;
			}
		}
		if ( ! empty( $labels ) ) {
			$schema['x-enum-labels'] = $labels;
		}

		return $schema;
	}

	/** Site text on its way into a schema: the caller's scrub (the pack's untrust()), or the same strip+cap on its own. */
	private function scrub_label( $value ) {
		if ( null !== $this->scrub ) {
			return (string) call_user_func( $this->scrub, (string) $value );
		}

		return FKMCP_Definition_Errors::clean( $value, FKMCP_Field_Translator::OPTION_TEXT_MAX );
	}

	private function group_select( array $field, $value, $path, FKMCP_Definition_Errors $errors, array $ctx ) {
		$flat = $this->flat_groups( $field );

		if ( empty( $flat ) ) {
			$errors->add( $path, ! empty( $ctx['needs'] ) ? sprintf( /* translators: %s: e.g. sync HubSpot */ __( 'has no options yet; %s first.', 'wp-marketing-automations-pro' ), $ctx['needs'] ) : __( 'has no options available on this site.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		if ( ! is_scalar( $value ) ) {
			$errors->add( $path, __( 'must be text.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$value = trim( (string) $value );
		if ( isset( $flat[ $value ] ) ) {
			return $value;
		}

		$by_full  = array();
		$by_label = array();
		foreach ( $flat as $key => $full ) {
			$by_full[ strtolower( $full ) ] = $key;
			$label = strtolower( trim( substr( $full, strrpos( $full, ' / ' ) + 3 ) ) );
			$by_label[ $label ][] = $key;
		}

		$needle = strtolower( preg_replace( '/\s*\/\s*/', ' / ', $value ) );
		if ( isset( $by_full[ $needle ] ) ) {
			return (string) $by_full[ $needle ];
		}
		if ( isset( $by_label[ $needle ] ) && 1 === count( $by_label[ $needle ] ) ) {
			return (string) $by_label[ $needle ][0];
		}

		$errors->add( $path, isset( $by_label[ $needle ] ) ? __( 'is in more than one pipeline; use "Pipeline / Stage" or the value.', 'wp-marketing-automations-pro' ) : __( 'is not one of the options.', 'wp-marketing-automations-pro' ), array_values( $flat ) );

		return null;
	}

	// ─── google_sheet ─────────────────────────────────────────────

	private function operation( array $field ) {
		return isset( $field['operation'] ) ? (string) $field['operation'] : 'insert';
	}

	private function google_sheet( array $field, $in, $path, FKMCP_Definition_Errors $errors, array $ctx ) {
		if ( ! is_array( $in ) ) {
			$errors->add( $path, __( 'must be an object.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$op     = $this->operation( $field );
		$before = $errors->count();
		$raw    = isset( $in['spreadsheet'] ) && is_string( $in['spreadsheet'] ) ? trim( $in['spreadsheet'] ) : '';
		$id     = preg_match( '#/d/([A-Za-z0-9_-]{20,})#', $raw, $m ) ? $m[1] : $raw;

		if ( ! preg_match( '/^[A-Za-z0-9_-]{20,}$/', $id ) ) {
			$errors->add( $path . '.spreadsheet', __( 'must be a Google Sheets id or URL.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		if ( ! class_exists( 'BWFCO_Google_Sheets' ) ) {
			$errors->add( $path, __( 'needs the Google Sheets connector; connect Google Sheets first.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$sheet = $this->sheet_call( 'w:' . $id, function () use ( $id ) {
			return BWFCO_Google_Sheets::get_google_worksheets( $id );
		} );

		if ( false === $sheet ) {
			$errors->add( $path . '.spreadsheet', __( 'could not be checked: the Google Sheets lookups for this definition ran out of time. Send fewer Google Sheets steps per call.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		if ( ! is_array( $sheet ) || empty( $sheet['worksheets'] ) ) {
			$message = is_array( $sheet ) && ! empty( $sheet['message'] ) ? wp_strip_all_tags( (string) $sheet['message'] ) : __( 'no worksheets found', 'wp-marketing-automations-pro' );
			/* translators: %s: the Google API's message */
			$errors->add( $path . '.spreadsheet', sprintf( __( 'could not be read from Google Sheets: %s', 'wp-marketing-automations-pro' ), mb_substr( $message, 0, 200 ) ) );

			return null;
		}

		$title = null;
		$want  = isset( $in['worksheet'] ) ? strtolower( trim( (string) $in['worksheet'] ) ) : '';
		foreach ( (array) $sheet['worksheets'] as $name ) {
			if ( strtolower( (string) $name ) === $want ) {
				$title = (string) $name;
			}
		}
		if ( null === $title ) {
			$errors->add( $path . '.worksheet', __( 'is not a worksheet of that spreadsheet.', 'wp-marketing-automations-pro' ), array_values( (array) $sheet['worksheets'] ) );

			return null;
		}

		$letters = isset( $sheet['sheets_column'][ $title ] ) ? array_keys( (array) $sheet['sheets_column'][ $title ] ) : array();
		$headers = $this->headers( $id, $title, $letters );

		$columns = array();
		foreach ( isset( $in['columns'] ) && is_array( $in['columns'] ) ? array_values( $in['columns'] ) : array() as $i => $col ) {
			$letter = $this->column( isset( $col['column'] ) ? $col['column'] : '', $letters, $headers );
			if ( null === $letter ) {
				$errors->add( $path . '.columns[' . $i . '].column', __( 'is not a column of that worksheet.', 'wp-marketing-automations-pro' ), array_merge( array_values( $headers ), $letters ) );
				continue;
			}
			$text = isset( $col['value'] ) && is_scalar( $col['value'] ) ? (string) $col['value'] : '';
			FKMCP_Field_Translator::check_merge_tags( $text, $ctx['merge_tags'], $path . '.columns[' . $i . '].value', $errors );
			$columns[] = array( 'column' => $letter, 'value' => sanitize_text_field( $text ) );
		}

		if ( in_array( $op, array( 'insert', 'update' ), true ) && empty( $columns ) && $errors->count() === $before ) {
			$errors->add( $path . '.columns', __( 'needs at least one column.', 'wp-marketing-automations-pro' ) );
		}

		$search = array();
		if ( in_array( $op, array( 'update', 'delete' ), true ) ) {
			$lookup = isset( $in['lookup'] ) && is_array( $in['lookup'] ) ? $in['lookup'] : null;
			$letter = null !== $lookup ? $this->column( isset( $lookup['column'] ) ? $lookup['column'] : '', $letters, $headers ) : null;
			if ( null === $letter ) {
				$errors->add( $path . '.lookup', __( 'is required: {column, value} to find the row.', 'wp-marketing-automations-pro' ) );
			} else {
				$text = isset( $lookup['value'] ) && is_scalar( $lookup['value'] ) ? (string) $lookup['value'] : '';
				FKMCP_Field_Translator::check_merge_tags( $text, $ctx['merge_tags'], $path . '.lookup.value', $errors );
				$search = array( 'col' => $letter, 'value' => sanitize_text_field( $text ) );
			}
		}

		if ( $errors->count() > $before ) {
			return null;
		}

		return array(
			'spreadsheet_id'        => $id,
			'worksheet_title'       => $title,
			'worksheet_column'      => $columns,
			'worksheet_search_data' => $search,
		);
	}

	/** Header row → [letter => header]; empty when the call fails (letters still work). */
	private function headers( $id, $title, array $letters ) {
		if ( empty( $letters ) || ! class_exists( 'WFCO_Load_Connectors' ) ) {
			return array();
		}

		$row = $this->sheet_call( 'h:' . $id . '|' . $title, function () use ( $id, $title ) {
			$call = WFCO_Load_Connectors::get_instance()->get_call( 'wfco_gs_get_sheet_range_value' );

			return is_object( $call ) ? $call->set_data( array( 'spreadsheet_id' => $id, 'worksheet_title' => $title, 'range' => $title . '!1:1' ) )->process() : null;
		} );

		$cells = isset( $row['values'][0] ) && is_array( $row['values'][0] ) ? $row['values'][0] : array();
		$out   = array();
		foreach ( $letters as $i => $letter ) {
			if ( isset( $cells[ $i ] ) && '' !== trim( (string) $cells[ $i ] ) ) {
				$out[ $letter ] = wp_strip_all_tags( (string) $cells[ $i ] );
			}
		}

		return $out;
	}

	private function column( $name, array $letters, array $headers ) {
		$name = trim( (string) $name );
		if ( in_array( strtoupper( $name ), $letters, true ) ) {
			return strtoupper( $name );
		}
		foreach ( $headers as $letter => $header ) {
			if ( 0 === strcasecmp( $header, $name ) ) {
				return $letter;
			}
		}

		return null;
	}

	/**
	 * One Google Sheets call, memoised for the build and inside its time budget.
	 *
	 * @return mixed The call's answer, or false once the budget is spent.
	 */
	private function sheet_call( $key, callable $call ) {
		if ( array_key_exists( $key, $this->sheet_memo ) ) {
			return $this->sheet_memo[ $key ];
		}

		if ( null === $this->sheets_started ) {
			$this->sheets_started = microtime( true );
		} elseif ( microtime( true ) - $this->sheets_started > self::SHEETS_TIME_BUDGET ) {
			return false;
		}

		$this->sheet_memo[ $key ] = $this->with_timeout( $call );

		return $this->sheet_memo[ $key ];
	}

	/** Runs a live API call with the §0.1.6 timeout; the filter never outlives the call. */
	private function with_timeout( callable $call ) {
		$timeout = static function () {
			return self::HTTP_TIMEOUT;
		};

		add_filter( 'http_request_timeout', $timeout, 999 );

		try {
			return $call();
		} catch ( Throwable $e ) {
			return array( 'message' => $e->getMessage() );
		} finally {
			remove_filter( 'http_request_timeout', $timeout, 999 );
		}
	}

	// ─── image_upload ─────────────────────────────────────────────

	private function image( $value, $path, FKMCP_Definition_Errors $errors ) {
		if ( is_int( $value ) ) {
			if ( ! wp_attachment_is_image( $value ) || ! in_array( get_post_mime_type( $value ), self::IMAGE_MIME, true ) ) {
				$errors->add( $path, __( 'must be a JPG, PNG or GIF image in the media library.', 'wp-marketing-automations-pro' ) );

				return null;
			}

			return (string) wp_get_attachment_url( $value );
		}

		$url  = is_string( $value ) ? trim( $value ) : '';
		$path_part = strtolower( (string) parse_url( $url, PHP_URL_PATH ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.parse_url_parse_url -- only the path component, no scheme-relative input reaches here.

		if ( 0 !== strpos( $url, 'https://' ) || false === wp_http_validate_url( $url ) || ! preg_match( '/\.(jpe?g|png|gif)$/', $path_part ) ) {
			$errors->add( $path, __( 'must be a public https URL to a JPG, PNG or GIF image.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		return $url;
	}

	// ─── webhook ──────────────────────────────────────────────────

	private function webhook( array $field, $value, $path, FKMCP_Definition_Errors $errors, array $ctx = array() ) {
		if ( isset( $field['showmap'] ) && false === $field['showmap'] ) {
			$errors->add( $path, __( 'is not needed: this webhook reads the email from its own payload.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		if ( ! is_string( $value ) || strlen( $value ) > 200 || false !== strpos( $value, '{' ) || ! preg_match( '/^[A-Za-z0-9_-]+(\.[A-Za-z0-9_-]+)*$/', $value ) ) {
			$errors->add( $path, __( 'must be a dotted path such as contact.email.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		// update-automation with a stored sample (spec §5.2): the path must resolve
		// the way the runtime reads it, and point at an email address.
		if ( isset( $ctx['webhook_sample'] ) && is_array( $ctx['webhook_sample'] ) ) {
			$paths = isset( $ctx['webhook_paths'] ) && is_array( $ctx['webhook_paths'] ) ? $ctx['webhook_paths'] : array();
			$found = self::sample_value( $ctx['webhook_sample'], $value );

			if ( null === $found ) {
				/* translators: %s: close paths from the last test request */
				$errors->add( $path, sprintf( __( 'is not a field of the last test request. Close paths: %s.', 'wp-marketing-automations-pro' ), implode( ', ', FKMCP_Field_Translator::closest( $value, $paths, 5 ) ) ) );

				return null;
			}
			if ( ! is_string( $found ) || ! is_email( $found ) ) {
				$errors->add( $path, __( 'must point at an email address in the last test request.', 'wp-marketing-automations-pro' ) );

				return null;
			}
		}

		return $value;
	}

	// ─── ajax ─────────────────────────────────────────────────────

	private function ajax( array $field, $value, array $current, $path, FKMCP_Definition_Errors $errors, array $ctx ) {
		$cb = isset( $field['ajax_cb'] ) ? sanitize_key( $field['ajax_cb'] ) : '';

		if ( self::DYNAMIC_COUPON_CB === $cb ) {
			if ( is_array( $value ) && isset( $value['$step'] ) && is_string( $value['$step'] ) && preg_match( FKMCP_Step_Builder::REF_PATTERN, $value['$step'] ) ) {
				return array( '$step' => $value['$step'] );
			}
			$errors->add( $path, __( 'must be {"$step": "<ref>"} naming an earlier Create Coupon step.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$options = $this->ajax_options( $field, $current, $path, $errors, $ctx );
		if ( null === $options ) {
			return null;
		}

		$key = self::match_option( $options, $value );
		if ( null !== $key ) {
			return $key;
		}

		$errors->add( $path, __( 'is not one of the options.', 'wp-marketing-automations-pro' ), array_values( $options ) );

		return null;
	}

	/**
	 * A form trigger's field map: {email, first_name?, last_name?, phone?}, each a field
	 * of the chosen form by key or label, loaded through the trigger's ajax_cb the way
	 * the builder loads them. Saved as the builder saves it: bwfan_{role}_field_map => key.
	 */
	private function form_map( array $field, $value, array $current, $path, FKMCP_Definition_Errors $errors, array $ctx ) {
		$roles = FKMCP_Field_Translator::FORM_MAP_ROLES;

		if ( ! is_array( $value ) || ( array() !== $value && array_values( $value ) === $value ) ) {
			$errors->add( $path, __( 'must be an object: {email, first_name, last_name, phone}, each a field of the chosen form.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$extra = array_diff( array_keys( $value ), $roles );
		foreach ( $extra as $role ) {
			$errors->add( $path . '.' . sanitize_key( $role ), __( 'is not part of a form field map: use email, first_name, last_name or phone.', 'wp-marketing-automations-pro' ) );
		}
		if ( $extra ) {
			return null;
		}

		$options = $this->ajax_options( $field, $current, $path, $errors, $ctx );
		if ( null === $options ) {
			return null;
		}

		$map    = array();
		$failed = false;
		foreach ( $roles as $role ) {
			if ( ! isset( $value[ $role ] ) || '' === $value[ $role ] ) {
				continue;
			}
			$key = self::match_option( $options, $value[ $role ] );
			if ( null === $key ) {
				$errors->add( $path . '.' . $role, __( 'is not a field of this form.', 'wp-marketing-automations-pro' ), array_values( $options ) );
				$failed = true;
				continue;
			}
			$map[ 'bwfan_' . $role . '_field_map' ] = $key;
		}

		if ( ! isset( $map['bwfan_email_field_map'] ) && ! $failed ) {
			// The builder refuses a map without email. Left out: the form's one email field, when it has exactly one.
			$emails = array();
			foreach ( $options as $key => $label ) {
				if ( preg_match( '/e-?mail/i', $key . ' ' . $label ) ) {
					$emails[] = (string) $key;
				}
			}
			if ( 1 !== count( $emails ) ) {
				$errors->add( $path . '.email', __( 'is required: name the form field that holds the Contact\'s email.', 'wp-marketing-automations-pro' ), array_values( $options ) );

				return null;
			}
			$map = array( 'bwfan_email_field_map' => $emails[0] ) + $map;
		}

		return $failed ? null : $map;
	}

	/** The option a value names, by key or by label (case-insensitive), or null. */
	private static function match_option( array $options, $value ) {
		if ( ! is_scalar( $value ) ) {
			return null;
		}
		foreach ( $options as $key => $label ) {
			if ( (string) $key === (string) $value || 0 === strcasecmp( $label, trim( (string) $value ) ) ) {
				return (string) $key;
			}
		}

		return null;
	}

	/**
	 * The options an ajax-loaded setting offers, key => label, read by running the
	 * handler the builder calls; null with the reason added to $errors.
	 */
	private function ajax_options( array $field, array $current, $path, FKMCP_Definition_Errors $errors, array $ctx ) {
		$cb = isset( $field['ajax_cb'] ) ? sanitize_key( $field['ajax_cb'] ) : '';

		$skip = (array) get_option( self::AJAX_SKIP_OPTION, array() );
		if ( '' === $cb || ( isset( $skip[ $cb ] ) && (string) $skip[ $cb ] === self::owner_version( $cb ) ) ) {
			$errors->add( $path, __( 'can\'t be read by an assistant; set it in the builder.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		if ( ! has_action( 'wp_ajax_' . $cb ) ) {
			$errors->add( $path, __( 'is not available on this site.', 'wp-marketing-automations-pro' ) );

			return null;
		}

		$post = array();
		foreach ( isset( $field['ajax_field'] ) && is_array( $field['ajax_field'] ) ? $field['ajax_field'] : array() as $post_key => $sibling ) {
			$dep = isset( $current[ $sibling ] ) ? $current[ $sibling ] : '';

			// Admin parity (bwf-ajax-select/index.js:75-80): an array dependency (a picker value,
			// [{id|key, ...}, ...]) sends its first element's key or id; empty, or neither present,
			// still counts as unset.
			if ( is_array( $dep ) ) {
				$first = isset( $dep[0] ) && is_array( $dep[0] ) ? $dep[0] : array();
				$dep   = isset( $first['key'] ) && is_scalar( $first['key'] ) ? $first['key'] : ( isset( $first['id'] ) && is_scalar( $first['id'] ) ? $first['id'] : '' );
			}

			if ( ! is_scalar( $dep ) || '' === (string) $dep ) {
				/* translators: %s: the setting this one depends on */
				$errors->add( $path, sprintf( __( 'needs %s to be set first.', 'wp-marketing-automations-pro' ), sanitize_key( $sibling ) ) );

				return null;
			}
			$post[ sanitize_key( $post_key ) ] = (string) $dep;
		}

		$automation_id = isset( $ctx['automation_id'] ) ? (int) $ctx['automation_id'] : 0;
		$memo_key      = $cb . '|' . $automation_id . '|' . md5( (string) wp_json_encode( $post ) );
		if ( ! isset( $this->ajax_memo[ $memo_key ] ) ) {
			$this->ajax_memo[ $memo_key ] = $this->call_ajax( $cb, $post, $automation_id );
		}
		$options = $this->ajax_memo[ $memo_key ];

		if ( is_wp_error( $options ) ) {
			$errors->add( $path, $options->get_error_message() );

			return null;
		}

		return $options;
	}

	/**
	 * Runs the ajax handler the builder would call, in this request, and
	 * reads what it would have sent. The handler's own nonce and capability
	 * checks run unchanged: the nonce is a real one for the current user.
	 *
	 * @return array<string, string>|WP_Error key => label
	 */
	private function call_ajax( $cb, array $post, $automation_id ) {
		self::arm_guard();

		// phpcs:disable WordPress.Security.NonceVerification, FunnelBuilder.CodeAnalysis.FunnelBuilderSpecific.MissingCapabilityCheck -- we build, then restore, the request an admin-ajax call would carry; the handler named by do_action() below runs its own nonce and capability checks unchanged.
		$backup = array( $_POST, $_REQUEST );
		$nonce  = wp_create_nonce( 'bwfan-action-admin' );
		$_POST  = array_merge( $post, array( 'action' => $cb, 'fromApp' => '1', 'automationId' => (string) absint( $automation_id ), '_wpnonce' => $nonce, 'nonce' => $nonce ) );
		$_REQUEST = $_POST;
		// phpcs:enable

		$die     = static function () {
			return array( __CLASS__, 'halt' );
		};
		$timeout = static function () {
			return self::HTTP_TIMEOUT;
		};
		// A handler's own wp_send_json() shouldn't trip a "doing it wrong" notice just because we
		// are calling it in-process rather than through a real admin-ajax request.
		$quiet_json = static function ( $trigger, $function ) {
			return 'wp_send_json' === $function ? false : $trigger;
		};

		add_filter( 'wp_doing_ajax', '__return_true', 999 );
		add_filter( 'wp_die_ajax_handler', $die, PHP_INT_MAX );
		add_filter( 'http_request_timeout', $timeout, 999 );
		add_filter( 'doing_it_wrong_trigger_error', $quiet_json, 999, 2 );

		// If the handler ends the request with a bare exit, this finally block never runs; on_shutdown()
		// runs the same restore in that case, so either path is enough. run_restore() makes it idempotent.
		self::$restore = static function () use ( $backup, $die, $timeout, $quiet_json ) {
			list( $_POST, $_REQUEST ) = $backup; // phpcs:ignore WordPress.Security.NonceVerification, FunnelBuilder.CodeAnalysis.FunnelBuilderSpecific.MissingCapabilityCheck -- restoring the caller's own request, not processing form input.
			remove_filter( 'wp_doing_ajax', '__return_true', 999 );
			remove_filter( 'wp_die_ajax_handler', $die, PHP_INT_MAX );
			remove_filter( 'http_request_timeout', $timeout, 999 );
			remove_filter( 'doing_it_wrong_trigger_error', $quiet_json, 999 );
		};

		$level         = ob_get_level();
		$raw           = '';
		$failed        = null;
		self::$in_ajax = $cb;
		ob_start();

		try {
			do_action( 'wp_ajax_' . $cb );
		} catch ( FKMCP_Ajax_Halt $halt ) {
			// Normal: wp_send_json() → wp_die() → our handler.
			unset( $halt );
		} catch ( Throwable $e ) {
			$failed = new WP_Error( 'fkmcp_ajax_failed', __( 'The options could not be loaded; try again, or set it in the builder.', 'wp-marketing-automations-pro' ) );
		} finally {
			$raw = ob_get_level() > $level ? (string) ob_get_contents() : '';
			self::discard_buffers( $level );
			self::$in_ajax = null;
			self::run_restore();
		}

		if ( null !== $failed ) {
			return $failed;
		}

		$json = json_decode( $raw, true );

		// {success:false, data:{message}} (wp_send_json_error()) or {msg, status:false}
		// (BWFAN_Common::check_nonce()'s shape) both mean the handler refused.
		if ( is_array( $json ) && ( ( isset( $json['success'] ) && false === $json['success'] ) || ( isset( $json['status'] ) && false === $json['status'] && isset( $json['msg'] ) ) ) ) {
			$message = isset( $json['data']['message'] ) ? (string) $json['data']['message'] : ( isset( $json['msg'] ) ? (string) $json['msg'] : '' );
			$message = '' !== $message ? wp_strip_all_tags( $message ) : __( 'The options could not be loaded.', 'wp-marketing-automations-pro' );

			return new WP_Error( 'fkmcp_ajax_refused', mb_substr( $message, 0, 200 ) );
		}

		if ( ! is_array( $json ) || ! isset( $json['results'] ) || ! is_array( $json['results'] ) ) {
			return new WP_Error( 'fkmcp_ajax_unsupported', __( 'can\'t be read by an assistant here; set this field in the builder.', 'wp-marketing-automations-pro' ) );
		}

		$options = array();
		foreach ( $json['results'] as $row ) {
			if ( is_array( $row ) && isset( $row['key'] ) && is_scalar( $row['key'] ) ) {
				$options[ (string) $row['key'] ] = mb_substr( wp_strip_all_tags( isset( $row['value'] ) ? (string) $row['value'] : (string) $row['key'] ), 0, 200 );
			}
		}

		if ( empty( $options ) ) {
			return new WP_Error( 'fkmcp_ajax_empty', __( 'There are no options for this setting.', 'wp-marketing-automations-pro' ) );
		}

		return $options;
	}

	/** Our wp_die_ajax_handler: hand control back to call_ajax(). */
	public static function halt() {
		throw new FKMCP_Ajax_Halt();
	}

	/**
	 * Discards buffers down to $floor. Stops instead of spinning forever if one refuses removal
	 * (started without PHP_OUTPUT_HANDLER_REMOVABLE, e.g. by a caching or compression plugin).
	 * Checked via ob_get_status() first: ob_end_clean() itself would also refuse such a buffer,
	 * but raises a notice doing it.
	 */
	private static function discard_buffers( $floor ) {
		while ( ob_get_level() > $floor ) {
			$status = ob_get_status();
			if ( empty( $status['flags'] ) || 0 === ( $status['flags'] & PHP_OUTPUT_HANDLER_REMOVABLE ) ) {
				break;
			}
			if ( ! ob_end_clean() ) {
				break;
			}
		}
	}

	/** Runs, then clears, the pending restore set by call_ajax(); a no-op once it has already run. */
	private static function run_restore() {
		if ( null === self::$restore ) {
			return;
		}

		$restore       = self::$restore;
		self::$restore = null;
		$restore();
	}

	private static function arm_guard() {
		if ( ! self::$guard ) {
			// WordPress' own wp_ob_end_flush_all() is on 'shutdown' at priority 1 (default-filters.php)
			// and would flush our buffered output before a bare register_shutdown_function() runs, since
			// shutdown_action_hook() is registered before we ever are. PHP_INT_MIN runs first, ahead of
			// that and of any other plugin's shutdown hook; register_shutdown_function() is kept as a
			// fallback for a context with no 'shutdown' action. on_shutdown() only acts once either way.
			add_action( 'shutdown', array( __CLASS__, 'on_shutdown' ), PHP_INT_MIN );
			register_shutdown_function( array( __CLASS__, 'on_shutdown' ) );
			self::$guard = true;
		}
	}

	/**
	 * The version of the plugin whose file registered wp_ajax_{$cb}, or '' when
	 * that can't be told (a closure in a theme, no plugin metadata). A skip entry
	 * only holds while this matches, so updating the add-on retries the callback.
	 */
	private static function owner_version( $cb ) {
		global $wp_filter;

		$hook = isset( $wp_filter[ 'wp_ajax_' . $cb ] ) ? $wp_filter[ 'wp_ajax_' . $cb ] : null;
		$file = '';

		foreach ( is_object( $hook ) && isset( $hook->callbacks ) ? (array) $hook->callbacks : array() as $entries ) {
			$entry = reset( $entries );
			try {
				$fn   = isset( $entry['function'] ) ? $entry['function'] : null;
				$ref  = is_array( $fn ) ? new ReflectionMethod( $fn[0], $fn[1] ) : ( is_object( $fn ) && ! $fn instanceof Closure ? new ReflectionMethod( $fn, '__invoke' ) : new ReflectionFunction( $fn ) );
				$file = (string) $ref->getFileName();
			} catch ( Throwable $e ) {
				$file = '';
			}
			break;
		}

		if ( '' === $file || ! function_exists( 'plugin_basename' ) ) {
			return '';
		}

		if ( ! function_exists( 'get_plugins' ) && file_exists( ABSPATH . 'wp-admin/includes/plugin.php' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$dir = strtok( plugin_basename( $file ), '/' );
		if ( false === $dir || ! function_exists( 'get_plugins' ) ) {
			return '';
		}

		foreach ( (array) get_plugins( '/' . $dir ) as $data ) {
			if ( ! empty( $data['Version'] ) ) {
				return (string) $data['Version'];
			}
		}

		return '';
	}

	/** True when the request is ending on a genuine PHP fatal, not a handler's own bare exit. */
	private static function is_fatal_shutdown() {
		$last = error_get_last();

		return is_array( $last ) && isset( $last['type'] ) && in_array( $last['type'], array( E_ERROR, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR ), true );
	}

	/**
	 * A handler ended the request with a bare exit, or the request ended on a genuine PHP fatal.
	 * Replace whatever was printed with a clean JSON-RPC error, restore every superglobal and
	 * filter call_ajax() set, remember the callback so it is never called in-process again
	 * (skipped on a fatal: nothing ran there worth blaming on the callback itself), and log it.
	 */
	public static function on_shutdown() {
		static $handled = false;

		if ( $handled || null === self::$in_ajax ) {
			return;
		}
		$handled = true;

		$cb = self::$in_ajax;
		self::discard_buffers( 0 );
		self::run_restore();

		if ( ! self::is_fatal_shutdown() ) {
			// String keys only: a legacy unversioned list entry (int key) is dropped here.
			$skip        = array_filter( (array) get_option( self::AJAX_SKIP_OPTION, array() ), 'is_string', ARRAY_FILTER_USE_KEY );
			$skip[ $cb ] = self::owner_version( $cb );
			update_option( self::AJAX_SKIP_OPTION, $skip, false );
		}

		if ( class_exists( 'BWFAN_MCP_Log' ) ) {
			BWFAN_MCP_Log::event( 'AJAX_RESOLVER_EXIT ' . $cb );
		}

		if ( ! headers_sent() ) {
			header( 'Content-Type: application/json; charset=utf-8' );
		}

		echo wp_json_encode( // phpcs:ignore WordPress.Security.EscapeOutput -- JSON body, built from literals.
			array(
				'jsonrpc' => '2.0',
				'id'      => null,
				'error'   => array(
					'code'    => -32603,
					'message' => __( 'A setting\'s options could not be loaded by an assistant; set that setting in the builder.', 'wp-marketing-automations-pro' ),
				),
			)
		);
	}

	/**
	 * The sample value at a path, as BWFAN_Autonami_Webhook_Received::capture_v2_data()
	 * reads it: the literal key first, then a dotted walk. Unlike the runtime, which
	 * silently skips a missing segment, this fails on the first one. null when absent.
	 */
	private static function sample_value( array $sample, $path ) {
		if ( array_key_exists( $path, $sample ) ) {
			return $sample[ $path ];
		}

		$value = $sample;
		foreach ( explode( '.', $path ) as $segment ) {
			if ( ! is_array( $value ) || ! array_key_exists( $segment, $value ) ) {
				return null;
			}
			$value = $value[ $segment ];
		}

		return $value;
	}
}
