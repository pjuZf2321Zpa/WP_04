<?php

defined( 'ABSPATH' ) || exit;

/**
 * The review sheet (spec §4.1): per step, what will be saved, in the user's words -
 * labels and names, never raw ids. Pure: reads the dry plan and the (memoised) part
 * registry; no queries of its own beyond those memos, no writes, no hooks.
 */
class FKMCP_Review_Sheet {

	const MAX_SETTINGS = 40;
	const MAX_DISPLAY  = 200;

	const FORMATS = array( 1 => 'rich text', 2 => 'WooCommerce', 3 => 'HTML', 5 => 'designed' );

	public static function steps( array $plan, $changes = null, array $old = array() ) {
		$emails = array();
		foreach ( (array) $plan['emails'] as $email ) {
			$emails[ $email['path'] ] = $email;
		}
		$sensitive = array();
		foreach ( (array) $plan['sensitive'] as $s ) {
			$sensitive[ $s['path'] ] = (string) $s['reason'];
		}

		$out = array();
		foreach ( $plan['paths'] as $i => $path ) {
			$change = null === $changes ? 'new' : ( isset( $changes[ $path ] ) ? $changes[ $path ] : 'unchanged' );
			if ( 'unchanged' === $change && null !== $changes ) {
				continue;
			}
			$row   = $plan['rows'][ $i ];
			$type  = $plan['types'][ $i ];
			$entry = array(
				'path'      => $path,
				'title'     => self::text( isset( $plan['labels'][ $i ] ) ? $plan['labels'][ $i ] : $path ),
				'type'      => $type,
				'change'    => $change,
				'settings'  => array(),
				'creates'   => self::creates( $row['sidebar'], $plan['pending'] ),
				'sensitive' => isset( $sensitive[ $path ] ) ? self::text( $sensitive[ $path ] ) : null,
				'warnings'  => self::warnings_for( $path, $plan['warnings'] ),
			);

			if ( 'email' === $type ) {
				$email             = isset( $emails[ $path ] ) ? $emails[ $path ] : array();
				$entry['settings'] = self::email_settings( $row, $email, $plan, $entry['warnings'], isset( $old[ $path ] ) ? (array) $old[ $path ] : null );
				$entry['email']    = array(
					'template_id' => isset( $email['template_id'] ) ? $email['template_id'] : null,
					'mode'        => isset( $email['mode'] ) ? (int) $email['mode'] : null,
					'designed'    => ! empty( $email['designed'] ),
					'kept'        => ! empty( $email['kept'] ),
				);
			} elseif ( isset( $plan['descriptors'][ $i ] ) ) {
				$d                 = $plan['descriptors'][ $i ];
				$desc              = 'goal' === $d['kind'] ? FKMCP_Part_Registry::goal( $d['slug'] ) : FKMCP_Part_Registry::action( $d['slug'], $plan['event'] );
				$entry['settings'] = self::field_settings( is_array( $desc ) ? $desc : array(), (array) $row['sidebar'], isset( $plan['sent'][ $i ] ) ? $plan['sent'][ $i ] : array(), $plan['pending'], isset( $old[ $path ] ) ? (array) $old[ $path ] : null );
			} elseif ( null !== $row['sidebar'] && array() !== $row['sidebar'] ) {
				$entry['settings'] = array( array( 'id' => 'settings', 'label' => 'Settings', 'value_display' => self::cap( (string) wp_json_encode( $row['sidebar'] ) ), 'source' => 'agent', 'required' => false, 'missing' => false ) );
			}

			$out[] = $entry;
		}

		return $out;
	}

	/**
	 * The trigger's shape is {event, name, settings}. `change` is not this class's business:
	 * FKMCP_Pack_Pro::review_gate() adds it (FKMCP_Review_Sheet::trigger( … ) + array( 'change' => … )),
	 * the same way it classifies steps.
	 */
	public static function trigger( array $plan, $old_meta = null ) {
		$event = FKMCP_Part_Registry::event( $plan['event'] );

		return array(
			'event'    => $plan['event'],
			'name'     => self::text( is_array( $event ) && isset( $event['name'] ) ? $event['name'] : $plan['event'] ),
			'settings' => self::field_settings( is_array( $event ) ? $event : array(), (array) $plan['event_meta'], isset( $plan['sent']['trigger'] ) ? $plan['sent']['trigger'] : array(), $plan['pending'], is_array( $old_meta ) ? $old_meta : null ),
		);
	}

	public static function display( array $field, $value, array $pending ) {
		if ( is_array( $value ) && isset( $value['$pending'] ) && isset( $pending[ $value['$pending'] ] ) ) {
			$info  = $pending[ $value['$pending'] ];
			$names = array();
			foreach ( $info['values'] as $v ) {
				$names[] = in_array( (string) $v, $info['unknown'], true ) ? $v . ' (will be created)' : (string) $v;
			}

			return self::cap( implode( ', ', $names ) );
		}
		if ( is_bool( $value ) ) {
			return $value ? 'yes' : 'no';
		}
		if ( is_array( $value ) ) {
			$names = array();
			foreach ( $value as $item ) {
				if ( is_array( $item ) && isset( $item['name'] ) && is_scalar( $item['name'] ) ) {
					$names[] = (string) $item['name'];
				} elseif ( is_array( $item ) && isset( $item['label'] ) && is_scalar( $item['label'] ) ) {
					$names[] = (string) $item['label'];
				} else {
					return self::cap( (string) wp_json_encode( $value ) );
				}
			}

			return self::cap( implode( ', ', $names ) );
		}
		if ( null === $value ) {
			return '';
		}
		$options = FKMCP_Field_Translator::options( $field );

		return self::cap( isset( $options[ (string) $value ] ) ? (string) $options[ (string) $value ] : (string) $value );
	}

	private static function field_settings( array $desc, array $values, array $sent, array $pending, $old ) {
		$fields = isset( $desc['fields'] ) && is_array( $desc['fields'] ) ? $desc['fields'] : array();
		$sent   = array_map( 'strval', $sent ); // $sent['trigger'] keys can be ints; compare as strings.
		$out    = array();
		foreach ( $fields as $field ) {
			if ( ! isset( $field['id'] ) || in_array( isset( $field['type'] ) ? $field['type'] : '', FKMCP_Field_Translator::DISPLAY, true ) || ! FKMCP_Field_Translator::applies( $field, $values ) ) {
				continue;
			}
			$id      = (string) $field['id']; // raw, for the values()/sent()/old() lookups below - the untrusted copy goes only into the entry.
			$display = self::display( $field, isset( $values[ $id ] ) ? $values[ $id ] : null, $pending );
			$entry   = array(
				'id'            => self::text( $id ),
				'label'         => self::text( FKMCP_Field_Translator::label( $field ) ),
				'value_display' => $display,
				'source'        => in_array( $id, $sent, true ) ? 'agent' : 'default',
				'required'      => ! empty( $field['required'] ),
				'missing'       => ! empty( $field['required'] ) && '' === $display,
			);
			if ( is_array( $old ) ) {
				$before = self::display( $field, isset( $old[ $id ] ) ? $old[ $id ] : null, array() );
				if ( $before !== $display ) {
					$entry['before_display'] = $before;
				}
			}
			$out[] = $entry;
			if ( count( $out ) >= self::MAX_SETTINGS ) {
				break;
			}
		}

		return $out;
	}

	private static function email_settings( array $row, array $email, array $plan, array $warnings, $old = null ) {
		$basics = self::email_basics( (array) $row['sidebar'] );
		$mode   = isset( $email['mode'] ) ? (int) $email['mode'] : $basics['mode'];
		$trans  = 'yes' === $basics['transactional'];
		$tid    = isset( $email['template_id'] ) ? $email['template_id'] : null;
		$kept   = ! empty( $email['kept'] );
		$src    = $kept ? 'kept' : 'agent';

		if ( $trans ) {
			$unsub = 'not needed (transactional)';
		} elseif ( 5 === $mode ) {
			$unsub = 'checked in the design';
		} else {
			$unsub = false !== strpos( implode( ' ', $warnings ), '{{mail_footer}}' ) ? 'footer added' : 'in the body';
		}

		$rows   = array(
			'to'            => $basics['to'],
			'subject'       => $basics['subject'],
			'preheader'     => $basics['preheader'],
			'transactional' => $basics['transactional'],
			'format'        => isset( self::FORMATS[ $mode ] ) ? self::FORMATS[ $mode ] : (string) $mode,
			'template'      => null === $tid ? '—' : ( isset( $plan['template_titles'][ (int) $tid ] ) ? $plan['template_titles'][ (int) $tid ] . ' (#' . (int) $tid . ')' : '#' . (int) $tid ),
			'unsubscribe'   => $unsub,
			'preview'       => ! empty( $email['designed'] ) && ! $kept ? 'yes' : 'no',
		);
		$before = array();
		if ( is_array( $old ) ) { // update: what the saved email says, for the entries it can answer itself
			$before           = self::email_basics( $old );
			$before['format'] = isset( self::FORMATS[ $before['mode'] ] ) ? self::FORMATS[ $before['mode'] ] : (string) $before['mode'];
			unset( $before['mode'] );
		}
		$out = array();
		foreach ( $rows as $id => $value ) {
			$entry = array( 'id' => $id, 'label' => ucfirst( $id ), 'value_display' => self::cap( (string) $value ), 'source' => $src, 'required' => in_array( $id, array( 'to', 'subject' ), true ), 'missing' => in_array( $id, array( 'to', 'subject' ), true ) && '' === (string) $value );
			if ( isset( $before[ $id ] ) && self::cap( (string) $before[ $id ] ) !== $entry['value_display'] ) {
				$entry['before_display'] = self::cap( (string) $before[ $id ] );
			}
			$out[] = $entry;
		}

		return $out;
	}

	/** An email sidebar's own entries (template, unsubscribe and preview come from the plan). */
	private static function email_basics( array $sb ) {
		$data  = isset( $sb['bwfan_email_data'] ) && is_array( $sb['bwfan_email_data'] ) ? $sb['bwfan_email_data'] : array();
		$inner = isset( $data['data'] ) && is_array( $data['data'] ) ? $data['data'] : array();

		return array(
			'to'            => isset( $sb['bwfan_email_to'] ) && is_scalar( $sb['bwfan_email_to'] ) ? (string) $sb['bwfan_email_to'] : '',
			'subject'       => isset( $data['subject'] ) && is_scalar( $data['subject'] ) ? (string) $data['subject'] : '',
			'preheader'     => isset( $inner['preheader'] ) && is_scalar( $inner['preheader'] ) ? (string) $inner['preheader'] : '',
			'transactional' => ! empty( $inner['isTransactional'] ) ? 'yes' : 'no',
			'mode'          => isset( $data['mode'] ) ? (int) $data['mode'] : 1,
		);
	}

	private static function creates( $sidebar, array $pending ) {
		$out  = array();
		$seen = array();
		$walk = function ( $v ) use ( &$walk, &$out, &$seen, $pending ) {
			if ( ! is_array( $v ) ) {
				return;
			}
			if ( isset( $v['$pending'] ) && is_string( $v['$pending'] ) && isset( $pending[ $v['$pending'] ] ) && ! isset( $seen[ $v['$pending'] ] ) ) {
				$seen[ $v['$pending'] ] = true;
				foreach ( $pending[ $v['$pending'] ]['unknown'] as $name ) {
					$out[] = array( 'type' => $pending[ $v['$pending'] ]['type'], 'name' => self::text( $name ) );
				}

				return;
			}
			foreach ( $v as $child ) {
				$walk( $child );
			}
		};
		$walk( $sidebar );

		return $out;
	}

	private static function warnings_for( $path, array $warnings ) {
		$out = array();
		foreach ( $warnings as $w ) {
			if ( 0 === strpos( (string) $w, $path . ': ' ) ) {
				$out[] = self::text( substr( (string) $w, strlen( $path ) + 2 ) );
			}
		}

		return $out;
	}

	private static function cap( $s ) {
		$s = self::text( $s );

		return mb_strlen( $s ) > self::MAX_DISPLAY ? mb_substr( $s, 0, self::MAX_DISPLAY ) . '…' : $s;
	}

	/** Routes through FKMCP_Definition_Errors::untrust(), the single implementation FKMCP_Pack_Pro::untrust() also delegates to - this class must stay usable where the pack itself isn't loaded (its own unit harness). */
	private static function text( $s ) {
		return (string) FKMCP_Definition_Errors::untrust( (string) $s );
	}
}
