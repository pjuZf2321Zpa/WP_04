<?php

defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/class-fkmcp-pack-email-design-abilities.php';

/**
 * Email design tools: read the block editor's grammar, read saved templates
 * and layouts as block trees, check a design, and save it as a template - its
 * block markup for the editor and its email HTML, generated here, together.
 *
 * A design is a tree of blocks - { name, attrs, innerBlocks } - in the shape
 * the email editor stores: email-block/row > email-block/section >
 * email-block/column > content blocks. The design classes that do the work
 * are loaded only when one of these tools runs.
 */
class FKMCP_Pack_Email_Design extends FKMCP_Pack_Email_Design_Abilities {

	/** @var callable|null fn( int $id ): string - 'layout', 'email' or '' for a bwfan_templates id that is not a saved template. Tests replace it. */
	public static $template_kind = null;

	const MODE_BLOCK = 5;

	const TEMPLATE_KEYS = array( 'ID', 'title', 'subject', 'mode', 'created_at', 'updated_at' );

	/** Largest block tree or HTML body a read tool returns, in bytes of JSON. */
	const MAX_RESULT_BYTES = 150000;

	/** The block groups the editor offers a saved template, which has no trigger yet. */
	const TEMPLATE_GROUPS = array( 'cart', 'order' );

	/**
	 * Loads the design classes. Only these tools need them, so they are not
	 * part of the MCP runtime every request loads - and most calls need only
	 * a slice of them.
	 *
	 * - 'manifest': the schema and list/get tools - reads a stored design,
	 *   lists starter designs, products, coupons, block conditions.
	 * - 'validate': the above, plus the design checker (Tree::validate, its
	 *   Blocks/Review dependents) and Quality::review.
	 * - 'render' or no argument (the safe default): every design class,
	 *   including the ones that build and render email HTML.
	 *
	 * Each slice is a superset of the one before it, so a call site that asks
	 * for too little only risks a slower load, never a missing class.
	 * Tree::validate() needs at least 'validate': without BWFCRM_Email_Design_Review
	 * it silently skips the readability review.
	 *
	 * @param string|null $slice 'manifest', 'validate', 'render', or null for everything.
	 */
	private static function load_design( $slice = null ) {
		$dir = BWFAN_PRO_PLUGIN_DIR . '/crm/includes/block-editor/email-design';

		// Every slice needs these: value helpers, and the editor's manifest and guide text.
		require_once $dir . '/render/class-bwfcrm-email-render-js.php';
		require_once $dir . '/class-bwfcrm-email-design-manifest.php';
		require_once $dir . '/class-bwfcrm-email-design-guide.php';

		if ( 'manifest' === $slice ) {
			require_once $dir . '/class-bwfcrm-email-design-tree.php';
			require_once $dir . '/class-bwfcrm-email-design-edit.php';
			require_once $dir . '/class-bwfcrm-email-design-library.php';
			require_once $dir . '/class-bwfcrm-email-design-store.php';
			require_once $dir . '/class-bwfcrm-email-design-conditions.php';
			return;
		}

		require_once $dir . '/class-bwfcrm-email-design-tree.php';
		require_once $dir . '/class-bwfcrm-email-design-edit.php';
		require_once $dir . '/class-bwfcrm-email-design-library.php';
		require_once $dir . '/class-bwfcrm-email-design-store.php';
		require_once $dir . '/class-bwfcrm-email-design-conditions.php';
		require_once $dir . '/class-bwfcrm-email-design-blocks.php';
		// The review reads colours through the renderer's JavaScript-semantics helpers.
		require_once $dir . '/class-bwfcrm-email-design-review.php';
		require_once $dir . '/class-bwfcrm-email-design-quality.php';

		if ( 'validate' === $slice ) {
			return;
		}

		require_once $dir . '/class-bwfcrm-email-design-preview.php';
		require_once $dir . '/class-bwfcrm-email-design-preview-page.php';
		require_once $dir . '/class-bwfcrm-email-design-audit.php';
		require_once $dir . '/class-bwfcrm-email-design-measure.php';
		require_once $dir . '/render/class-bwfcrm-email-renderer.php';
	}

	// ─── get-email-design-schema ────────────────────────────────────

	public function get_email_design_schema( $input = array() ) {
		self::load_design( 'manifest' );

		$input  = (array) $input;
		$groups = self::event_groups( $input );

		if ( is_wp_error( $groups ) ) {
			return $groups;
		}

		$manifest = BWFCRM_Email_Design_Manifest::get();
		$blocks   = BWFCRM_Email_Design_Manifest::blocks( $groups );

		if ( is_wp_error( $manifest ) ) {
			return $manifest;
		}

		if ( is_wp_error( $blocks ) ) {
			return $blocks;
		}

		$detail  = isset( $input['blocks'] ) && is_array( $input['blocks'] ) ? array_flip( array_filter( $input['blocks'], 'is_string' ) ) : array();
		$recipes = isset( $input['recipes'] ) && is_array( $input['recipes'] ) ? array_flip( array_filter( $input['recipes'], 'is_string' ) ) : array();
		$list   = array();

		foreach ( $blocks as $name => $block ) {
			$row = array(
				'name'               => $name,
				'title'              => isset( $block['title'] ) ? (string) $block['title'] : $name,
				'kind'               => isset( $block['kind'] ) ? $block['kind'] : 'content',
				'available'          => ! empty( $block['available'] ),
				'unavailable_reason' => $block['unavailable_reason'],
				'parent'             => isset( $block['parent'] ) ? array_values( (array) $block['parent'] ) : array(),
				'attribute_names'    => array_keys( isset( $block['attributes'] ) ? (array) $block['attributes'] : array() ),
			);

			// What the block is for, when to use it, and what it needs to fill in.
			$row = array_merge( $row, BWFCRM_Email_Design_Guide::block( $name ) );

			if ( isset( $detail[ $name ] ) ) {
				$row['attributes'] = BWFCRM_Email_Design_Guide::describe_attributes( $name, isset( $block['attributes'] ) ? (array) $block['attributes'] : array() );
				$row['hands_off']  = BWFCRM_Email_Design_Guide::hands_off( $name );
			}

			$list[] = $row;
		}

		$menu = BWFCRM_Email_Design_Guide::recipe_summaries();

		foreach ( BWFCRM_Email_Design_Guide::recipes() as $i => $recipe ) {
			if ( isset( $recipe['name'], $recipes[ $recipe['name'] ] ) ) {
				$menu[ $i ] = $recipe;
			}
		}

		$schema = array(
			'editor_version' => (string) $manifest['editor_version'],
			'rules'          => self::design_rules(),
			'layout'         => isset( $manifest['layout'] ) ? $manifest['layout'] : array(),
			'column_presets' => isset( $manifest['column_presets'] ) ? $manifest['column_presets'] : array(),
			'email_settings' => isset( $manifest['email_settings'] ) ? $manifest['email_settings'] : array(),
			'inline_tags'    => isset( $manifest['inline_tags'] ) ? $manifest['inline_tags'] : array(),
			'site_style'     => self::site_style(),
			'design_guide'   => self::design_guide(),
			'style_pattern'  => BWFCRM_Email_Design_Guide::style_pattern(),
			'recipes'        => $menu,
			'blocks'         => $list,
		);

		// The brief is read once, when planning; the calls for block details leave it out.
		if ( empty( $detail ) ) {
			// Line by line: the result guardrail flattens newlines and caps each string.
			$schema['art_direction'] = array_values( array_filter( array_map( 'trim', explode( "\n", BWFCRM_Email_Design_Guide::art_direction() ) ), 'strlen' ) );
		}

		return $schema;
	}

	/** The rules a design must follow, in the words the agent reads. */
	private static function design_rules() {
		return array(
			'The email is a list of email-block/row blocks. A row holds email-block/section blocks, a section holds email-block/column blocks, and every other block sits in a column.',
			'A section\'s columnsWidth lists one percentage per column and should be one of column_presets; omit it for equal columns.',
			'All content lives in attrs. Content blocks never have innerBlocks, and no block contains HTML of its own.',
			'Text, button and list content is HTML using only inline_tags. A heading is email-block/text with content like <span style="font-weight:600;" data-heading-level="2">Title</span>.',
			'Values that can differ by screen are objects keyed desktop (and optionally mobile), e.g. {"desktop": {"top": "16", "right": "0", "bottom": "16", "left": "0", "unit": "px"}}.',
			'Colours are written in the shape the attribute\'s example shows. A button\'s color and bgColor, and a coupon\'s colours, are plain strings per screen: {"desktop": "#c2410c"}. Backgrounds (a section\'s contentBackground, a column\'s background) are objects: {"desktop": {"color": "#ffffff"}}. A colour in the wrong shape is ignored by the editor.',
			'Three backgrounds, three layers: settings.background is the page around the email; a section\'s contentBackground is the email column itself; a row\'s bgColor paints a band across the whole inbox width behind its section. For one tidy column keep settings.background light and leave row bgColor unset. Set a row bgColor only for a band meant to run edge to edge - and then for every band.',
			'Text, list and footer blocks have no colour attribute: their text shows in the site\'s text colour (site_style.color) unless the content sets one inline, as <span style="color: #ffffff;">…</span> around the text.',
			'Leave uniqueID out of new blocks - one is assigned. Keep the uniqueID of every block read from an existing design.',
			'Merge tags are {{slug}} from list-merge-tags. A marketing email needs the email-block/footer block, or a link to {{unsubscribe_link}}: <a href="{{unsubscribe_link}}">Unsubscribe</a>.',
			'Blocks with available=false cannot be used in this email. Dynamic blocks (kind dynamic) are filled in at send time from the store, the order or the cart: set their options, never their content. Read a block\'s summary, use_when and needs before choosing it, and ask for its attributes (blocks) before setting them.',
			'Each attribute\'s values lists what it accepts and means, depends_on names the option it needs, site_data says which lookup gives its ids or codes (list-products, list-product-categories, list-coupons), and hands_off lists what is worked out on save or has no effect - leave those out.',
			'For common requests copy a recipe (best_sellers_grid, new_arrivals, category_grid, hand_picked_products, related_to_order, store_coupon, automation_coupon, cart_reminder, order_receipt, social_row, nav_menu, spacer…) - ask for it in `recipes` to get its attrs - and change only what the user asked for. A product block always needs productFeedType: its editor default, specific, shows nothing until products are picked.',
			'Never guess an id or a code: look products, categories, coupons and an automation\'s coupon steps up first. Never leave an editor placeholder in (TAKE10OFF, "Button Text", "Hello, world!", "Menu 1").',
			'Order, cart and subscription blocks fill in only when an automation with that trigger sends the email. For such an email pass event (and automation_id) to validate and save; a template without them is checked for use anywhere.',
			'Display conditions (a block\'s conditional) come from list-block-conditions for the trigger; they are only checked when an automation sends the email.',
			'Images take a public image URL. In percent width their pixel size is worked out when the email is saved; leave imageWidth out unless widthUnit is px.',
			'The email-block/footer block inserts the site\'s global email footer (which carries the unsubscribe link). With isGlobal false its content is already a paragraph: inline HTML only, no <p>.',
			'When the site has a Global Style, an email\'s settings may override only email_settings.global_style_overridable (backgrounds, width, align); text, link and button styling is set on the blocks.',
			'Check every design with validate-email-design before saving it. It also reads the design as a recipient sees it: text that cannot be read on its background is an error, and `report` lists each text\'s colour, background and contrast.',
		);
	}

	/** How to plan an email that reads well, in the words the agent reads. */
	private static function design_guide() {
		return array(
			'Plan before you build: the email\'s one goal, the one action the reader should take, and the sections top to bottom. Read art_direction and make its five decisions - the action, the idea, the palette, the type scale, the rhythm - so the email looks like this brand and not like every email. Say the plan to the user before saving.',
			'Start from a professional design where one fits: list-email-starter-designs, then get-email-starter-design, and change its words, images and links - every sample image (its logo, its banners) is another brand\'s and must be replaced; validation warns sample_image for each one left. Build from nothing only when no starter fits.',
			'A clear order: a short header (logo or brand line), a hero (one headline, one sentence, an image), the body, one main button, then the footer. One idea per section.',
			'Keep the site\'s style (site_style): its fonts, text and button colours. Add at most one accent colour, used for the button and small highlights.',
			'Light content backgrounds read best in every inbox: keep the body light and use colour for the hero and a band or two. On a dark section, every text in it needs a light inline colour and the button a colour that stands out from the dark.',
			'Text must be readable: at least 4.5:1 contrast for body text, 3:1 for headings and buttons. validate-email-design checks this; do not save with a readability error or warning left.',
			'One headline per email (heading level 1 or 2), short paragraphs of one to three sentences, body text 14-18px, buttons with a two-to-four-word action ("Shop the sale").',
			'Space sections apart with section padding (24-40px top and bottom) rather than empty text blocks; keep 16-24px side padding so text never touches the edge on mobile.',
			'Images: use the site\'s own (list-email-images; site_style.logo for the logo). One strong hero at full column width, with an alt text; never put the only copy of important words inside an image. With no suitable image, leave images out rather than use one from elsewhere.',
			'Write the finished email, not instructions: no "add your text here" or copy describing what should go in a section. Where the user must supply something (a product, a date), ask, or say plainly which part to fill in.',
			'Never type the store\'s name or address: use {{business_name}} and {{business_address}}, so the email stays right if they change. Link every button to a real page on the site or a merge tag (list-merge-tags), never "#".',
			'Give a marketing email the email-block/footer block (the site\'s footer with the unsubscribe link), and a preheader that adds to the subject rather than repeating it.',
			'Work in rounds until the email is right: build the design, run preview-email-design, open its preview_url in your browser and look at the desktop and phone views as the recipient would, read quality.findings, improve, and preview again. Save only when quality is good (90+), nothing looks off - cramped, cluttered, hard to read, broken on the phone - and every block shows what the user asked for.',
			'In each round also ask art_direction\'s last questions of the preview: is it clear in two seconds what the email is about and where to click, does it feel like this brand rather than any brand, and is anything uniform that should vary.',
			'Before saving an email with product, coupon, order or cart blocks, run preview-email-design and check each block shows what the user asked for - products, a code, a layout - and nothing renders empty (the preview uses sample values, never a real customer, order or cart).',
			'Before telling the user the email is done, run audit-email-design - the editor\'s Audit Email: missing, broken and shortened links, the unsubscribe link, the size - and fix what fails. Saves and previews already give its other checks in `audit`.',
			'After saving, share the link and say what you made and why, so the user can open it in the editor.',
		);
	}

	/**
	 * The site's Global Style as a brief: what every email on the site looks
	 * like before a block sets anything of its own.
	 */
	private static function site_style() {
		$settings = class_exists( 'BWFAN_Common' ) && method_exists( 'BWFAN_Common', 'get_block_editor_settings' ) ? BWFAN_Common::get_block_editor_settings() : array();
		$style    = is_array( $settings ) && isset( $settings['setting'] ) && is_array( $settings['setting'] ) ? $settings['setting'] : array();
		$brief    = array( 'global_style' => ! empty( $style ) );
		$keys     = array( 'background', 'contentBackground', 'width', 'color', 'linkColor', 'linkLineType', 'font', 'fontH1', 'fontH2', 'fontH3', 'fontH4', 'fontH5', 'fontH6', 'buttonColor', 'buttonBackground', 'buttonBorder', 'buttonPadding', 'buttonFont', 'buttonAuto', 'buttonSize', 'logoSize', 'logoAuto', 'social', 'socialType' );

		foreach ( $keys as $key ) {
			if ( isset( $style[ $key ] ) && array() !== $style[ $key ] ) {
				$brief[ $key ] = $style[ $key ];
			}
		}

		$logo = isset( $settings['site']['logo'] ) && is_string( $settings['site']['logo'] ) ? $settings['site']['logo'] : '';

		$brief['logo'] = '' !== $logo ? $logo : null;

		return $brief;
	}

	/**
	 * @param array $input
	 *
	 * @return string[]|WP_Error The WooCommerce block groups of the event named in the input.
	 */
	private static function event_groups( array $input ) {
		$event = isset( $input['event'] ) && is_string( $input['event'] ) ? trim( $input['event'] ) : '';

		if ( '' === $event ) {
			// A template, like the editor's, may hold order and cart blocks; the checks say where they fill in.
			return self::TEMPLATE_GROUPS;
		}

		if ( ! function_exists( 'BWFAN_Core' ) || ! isset( BWFAN_Core()->sources ) || ! is_object( BWFAN_Core()->sources->get_event( sanitize_key( $event ) ) ) ) {
			return new WP_Error( 'fkmcp_invalid_input', sprintf( 'There is no trigger event "%s". Give the trigger event slug of the Automation the email is sent from (get-automation gives it, e.g. wc_new_order or ab_cart_abandoned), not an integration slug such as wc or autonami.', $event ) );
		}

		return BWFCRM_Email_Design_Manifest::event_groups( $event );
	}

	// ─── list-email-templates ───────────────────────────────────────

	public function list_email_templates( $input = array() ) {
		$input  = (array) $input;
		$page   = BWFAN_MCP_Format::paginate( $input );
		$params = array(
			'limit'  => $page['limit'],
			'offset' => $page['offset'],
		);

		if ( ! empty( $input['search'] ) && is_string( $input['search'] ) ) {
			$params['search'] = sanitize_text_field( $input['search'] );
		}

		if ( ! empty( $input['mode'] ) ) {
			$code = array_search( $input['mode'], self::MODES, true );

			if ( false === $code ) {
				return new WP_Error( 'fkmcp_invalid_input', 'mode must be one of: ' . implode( ', ', self::MODES ) . '.' );
			}

			$params['mode'] = $code;
		}

		$response = BWFAN_MCP_Dispatch::call( 'list-email-templates', $params );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$rows  = isset( $response['result'] ) && is_array( $response['result'] ) ? $response['result'] : array();
		$items = array();

		foreach ( $rows as $row ) {
			if ( is_array( $row ) ) {
				$items[] = self::template_summary( $row );
			}
		}

		return array(
			'items' => $items,
			// The controller omits total_count when it is zero.
			'total' => isset( $response['total_count'] ) ? (int) $response['total_count'] : ( empty( $items ) ? 0 : null ),
		);
	}

	/** A template row as the list reports it. */
	private static function template_summary( array $row ) {
		$data = self::decode( isset( $row['data'] ) ? $row['data'] : array() );
		$mode = isset( $row['mode'] ) && is_numeric( $row['mode'] ) ? (int) $row['mode'] : null;

		return array(
			'id'         => isset( $row['ID'] ) ? (int) $row['ID'] : 0,
			'title'      => isset( $row['title'] ) ? (string) $row['title'] : '',
			'subject'    => isset( $row['subject'] ) ? (string) $row['subject'] : null,
			'mode'       => $mode,
			'mode_label' => null !== $mode && isset( self::MODES[ $mode ] ) ? self::MODES[ $mode ] : null,
			'has_design' => self::MODE_BLOCK === $mode && '' !== self::block_body( $data ),
			'updated_at' => isset( $row['updated_at'] ) ? (string) $row['updated_at'] : null,
		);
	}

	/**
	 * A short fingerprint of what a template holds, so an update can tell it
	 * is replacing the version the client read and not one saved since.
	 *
	 * @param array $row Template row: title, subject, template, data.
	 *
	 * @return string
	 */
	private static function revision( array $row ) {
		return substr(
			md5(
				(string) wp_json_encode(
					array(
						isset( $row['title'] ) ? (string) $row['title'] : '',
						isset( $row['subject'] ) ? (string) $row['subject'] : '',
						isset( $row['template'] ) ? (string) $row['template'] : '',
						// Through JSON both ways, so data read back from storage and data about to be stored agree.
						self::decode( wp_json_encode( self::decode( isset( $row['data'] ) ? $row['data'] : array() ) ) ),
					)
				)
			),
			0,
			16
		);
	}

	// ─── get-email-template ─────────────────────────────────────────

	public function get_email_template( $input = array() ) {
		$id  = isset( $input['template_id'] ) ? absint( $input['template_id'] ) : 0;
		$row = self::saved_row( $id );

		if ( is_wp_error( $row ) ) {
			return $row;
		}

		$data = self::decode( isset( $row['data'] ) ? $row['data'] : array() );
		$mode = isset( $row['mode'] ) && is_numeric( $row['mode'] ) ? (int) $row['mode'] : null;
		$html = isset( $row['template'] ) && is_string( $row['template'] ) ? $row['template'] : '';

		$out = array(
			'id'         => $id,
			'title'      => isset( $row['title'] ) ? (string) $row['title'] : '',
			'subject'    => isset( $row['subject'] ) ? (string) $row['subject'] : null,
			'preheader'  => isset( $data['preheader'] ) && is_scalar( $data['preheader'] ) ? (string) $data['preheader'] : null,
			'mode'       => $mode,
			'mode_label' => null !== $mode && isset( self::MODES[ $mode ] ) ? self::MODES[ $mode ] : null,
			'has_html'   => '' !== trim( $html ),
			'revision'   => self::revision( $row ),
		);

		if ( self::MODE_BLOCK === $mode ) {
			self::load_design( 'manifest' );

			$block           = isset( $data['block'] ) && is_array( $data['block'] ) ? $data['block'] : array();
			$design          = self::read_design( self::block_body( $data ) );
			$out['settings'] = isset( $block['settings'] ) && is_array( $block['settings'] ) ? $block['settings'] : array();

			if ( ! empty( $input['outline'] ) ) {
				$out['outline'] = BWFCRM_Email_Design_Edit::outline( $design );
				unset( $out['settings'] );
			} else {
				$out['design'] = $design;
			}

			if ( empty( $design ) ) {
				$out['notice'] = 'This block-editor template has no design saved beside its HTML; it can only be rebuilt, not edited.';
			}
		} elseif ( in_array( $mode, array( 1, 2, 3 ), true ) ) {
			$out['html'] = $html;
		} else {
			$out['notice'] = 'This template was made with the legacy visual builder; its design cannot be read or edited with these tools.';
		}

		return self::within_limit( $out, isset( $out['design'] ) ? 'Read it with outline: true, which lists the blocks by uniqueID without the whole design, and change it with edit-email-design.' : 'This template is too large to read here; open it in the editor.' );
	}

	// ─── list-email-layouts ─────────────────────────────────────────

	public function list_email_layouts( $input = array() ) {
		$input  = (array) $input;
		$page   = BWFAN_MCP_Format::paginate( $input, 10, 20 );
		$params = array(
			'limit'  => $page['limit'],
			'offset' => $page['offset'],
		);

		if ( ! empty( $input['search'] ) && is_string( $input['search'] ) ) {
			$params['search'] = sanitize_text_field( $input['search'] );
		}

		$response = BWFAN_MCP_Dispatch::call( 'list-email-layouts', $params );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		self::load_design( 'manifest' );

		$with_design = ! empty( $input['with_design'] );
		$rows        = isset( $response['result'] ) && is_array( $response['result'] ) ? $response['result'] : array();
		$items       = array();

		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) || ! isset( $row['ID'] ) ) {
				continue;
			}

			$design = self::read_design( isset( $row['content'] ) ? $row['content'] : '' );
			$item   = array(
				'id'          => (int) $row['ID'],
				'title'       => isset( $row['title'] ) ? (string) $row['title'] : '',
				'description' => isset( $row['description'] ) && is_scalar( $row['description'] ) ? (string) $row['description'] : null,
				'blocks'      => self::count_blocks( $design ),
			);

			if ( $with_design ) {
				$item['design'] = $design;
			}

			$items[] = $item;
		}

		return self::within_limit(
			array(
				'items' => $items,
				'total' => isset( $response['total_count'] ) ? (int) $response['total_count'] : ( empty( $items ) ? 0 : null ),
			)
		);
	}

	/**
	 * Stored markup as the tree these tools hand out: complete(), so empty
	 * objects read as {} rather than [] and an agent editing the tree sends
	 * back the shapes the editor expects.
	 *
	 * @param string $markup
	 *
	 * @return array[]
	 */
	private static function read_design( $markup ) {
		$tree = BWFCRM_Email_Design_Tree::from_markup( $markup );

		return empty( $tree ) ? array() : BWFCRM_Email_Design_Tree::complete( $tree );
	}

	private static function count_blocks( array $tree ) {
		$count = 0;

		foreach ( $tree as $node ) {
			++$count;

			if ( ! empty( $node['innerBlocks'] ) && is_array( $node['innerBlocks'] ) ) {
				$count += self::count_blocks( $node['innerBlocks'] );
			}
		}

		return $count;
	}

	// ─── starter designs ────────────────────────────────────────────

	public function list_email_starter_designs( $input = array() ) {
		self::load_design( 'manifest' );

		$input = (array) $input;
		$index = BWFCRM_Email_Design_Library::index();

		if ( is_wp_error( $index ) ) {
			return new WP_Error( 'fkmcp_unavailable', $index->get_error_message() . ' Design from get-email-design-schema instead.' );
		}

		$category = isset( $input['category'] ) && is_string( $input['category'] ) ? strtolower( trim( $input['category'] ) ) : '';
		$search   = isset( $input['search'] ) && is_string( $input['search'] ) ? strtolower( trim( $input['search'] ) ) : '';
		$items    = array();

		foreach ( $index['templates'] as $template ) {
			if ( '' !== $category && ! in_array( $category, array_map( 'strtolower', $template['categories'] ), true ) ) {
				continue;
			}

			if ( '' !== $search && false === strpos( strtolower( $template['title'] ), $search ) ) {
				continue;
			}

			$items[] = self::starter_item( $template, $index );
		}

		return array(
			'categories' => $index['categories'],
			'items'      => $items,
		);
	}

	public function get_email_starter_design( $input = array() ) {
		self::load_design( 'manifest' );

		$input = (array) $input;
		$id    = isset( $input['id'] ) && is_string( $input['id'] ) ? trim( $input['id'] ) : '';
		$found = self::find_starter( $id );

		if ( is_wp_error( $found ) ) {
			return $found;
		}

		$design = BWFCRM_Email_Design_Library::design( $id );

		if ( is_wp_error( $design ) ) {
			return new WP_Error( 'bwfcrm_library_unknown' === $design->get_error_code() ? 'fkmcp_not_found' : 'fkmcp_unavailable', $design->get_error_message() );
		}

		$tree = self::read_design( $design['markup'] );

		if ( empty( $tree ) ) {
			return new WP_Error( 'fkmcp_unavailable', sprintf( 'The starter design "%s" could not be read as blocks.', $id ) );
		}

		$item = null === $found ? array() : $found;

		return self::within_limit(
			array(
				'id'          => $id,
				'title'       => isset( $item['title'] ) ? $item['title'] : null,
				'design'      => $tree,
				'settings'    => (object) BWFCRM_Email_Render_Js::plain( $design['settings'] ),
				'preview_url' => isset( $item['preview_url'] ) ? $item['preview_url'] : null,
				'blocks'      => self::count_blocks( $tree ),
			)
		);
	}

	/**
	 * The library entry of a starter id: null when the index cannot be read
	 * (the design may still be), an error when the index has no such id.
	 */
	private static function find_starter( $id ) {
		$index = BWFCRM_Email_Design_Library::index();

		if ( is_wp_error( $index ) ) {
			return null;
		}

		foreach ( $index['templates'] as $template ) {
			if ( $id === $template['id'] ) {
				return self::starter_item( $template, $index );
			}
		}

		return new WP_Error( 'fkmcp_not_found', sprintf( 'There is no starter design "%s". list-email-starter-designs gives the ids.', $id ) );
	}

	private static function starter_item( array $template, array $index ) {
		$woocommerce = isset( $template['dependency']['wc'] ) && is_array( $template['dependency']['wc'] ) ? array_values( array_filter( $template['dependency']['wc'], 'is_string' ) ) : null;

		return array(
			'id'          => $template['id'],
			'title'       => $template['title'],
			'categories'  => $template['categories'],
			'woocommerce' => $woocommerce,
			'preview_url' => '' !== $template['preview'] && '' !== $index['preview_prefix'] ? sanitize_url( $index['preview_prefix'] . $template['preview'] ) : null,
			'image_url'   => '' !== $template['image'] && '' !== $index['image_prefix'] ? sanitize_url( $index['image_prefix'] . $template['image'] ) : null,
		);
	}

	// ─── list-email-images ──────────────────────────────────────────

	public function list_email_images( $input = array() ) {
		$input = (array) $input;
		$page  = BWFAN_MCP_Format::paginate( $input, 20, 50 );
		$args  = array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'post_mime_type' => 'image',
			'orderby'        => 'date',
			'order'          => 'DESC',
			'posts_per_page' => $page['limit'],
			'offset'         => $page['offset'],
		);

		if ( ! empty( $input['search'] ) && is_string( $input['search'] ) ) {
			$args['s'] = sanitize_text_field( $input['search'] );
		}

		$query = new WP_Query( $args );
		$items = array();

		foreach ( $query->posts as $post ) {
			$url = wp_get_attachment_url( $post->ID );

			if ( ! is_string( $url ) || '' === $url ) {
				continue;
			}

			$meta    = wp_get_attachment_metadata( $post->ID );
			$items[] = array(
				'id'     => (int) $post->ID,
				'url'    => $url,
				'alt'    => (string) get_post_meta( $post->ID, '_wp_attachment_image_alt', true ),
				'title'  => (string) $post->post_title,
				'width'  => is_array( $meta ) && ! empty( $meta['width'] ) ? (int) $meta['width'] : null,
				'height' => is_array( $meta ) && ! empty( $meta['height'] ) ? (int) $meta['height'] : null,
			);
		}

		return array(
			'items' => $items,
			'total' => (int) $query->found_posts,
		);
	}

	// ─── store data ─────────────────────────────────────────────────

	public function list_products( $input = array() ) {
		self::load_design( 'manifest' );

		if ( ! BWFCRM_Email_Design_Store::has_woocommerce() ) {
			return new WP_Error( 'fkmcp_unavailable', 'WooCommerce is not active, so there are no products.' );
		}

		$input = (array) $input;
		$page  = BWFAN_MCP_Format::paginate( $input, 20, 50 );

		return BWFCRM_Email_Design_Store::products(
			array(
				'search'   => isset( $input['search'] ) && is_string( $input['search'] ) ? sanitize_text_field( $input['search'] ) : '',
				'ids'      => isset( $input['ids'] ) ? array_map( 'absint', (array) $input['ids'] ) : array(),
				'category' => isset( $input['category'] ) ? absint( $input['category'] ) : 0,
				'order'    => isset( $input['order'] ) && is_string( $input['order'] ) ? $input['order'] : 'best_selling',
				'in_stock' => ! empty( $input['in_stock'] ),
				'limit'    => $page['limit'],
				'offset'   => $page['offset'],
			)
		);
	}

	public function list_product_categories( $input = array() ) {
		self::load_design( 'manifest' );

		if ( ! BWFCRM_Email_Design_Store::has_woocommerce() ) {
			return new WP_Error( 'fkmcp_unavailable', 'WooCommerce is not active, so there are no product categories.' );
		}

		$input = (array) $input;
		$page  = BWFAN_MCP_Format::paginate( $input, 50, 50 );

		return BWFCRM_Email_Design_Store::categories(
			array(
				'search' => isset( $input['search'] ) && is_string( $input['search'] ) ? sanitize_text_field( $input['search'] ) : '',
				'limit'  => $page['limit'],
				'offset' => $page['offset'],
			)
		);
	}

	public function list_coupons( $input = array() ) {
		self::load_design( 'manifest' );

		if ( ! BWFCRM_Email_Design_Store::has_woocommerce() ) {
			return new WP_Error( 'fkmcp_unavailable', 'WooCommerce is not active, so there are no coupons.' );
		}

		$input  = (array) $input;
		$page   = BWFAN_MCP_Format::paginate( $input, 20, 50 );
		$result = BWFCRM_Email_Design_Store::coupons(
			array(
				'search' => isset( $input['search'] ) && is_string( $input['search'] ) ? sanitize_text_field( $input['search'] ) : '',
				'limit'  => $page['limit'],
				'offset' => $page['offset'],
			)
		);

		if ( ! empty( $input['automation_id'] ) ) {
			$result['automation'] = BWFCRM_Email_Design_Store::automation_coupons( absint( $input['automation_id'] ) );
		}

		return $result;
	}

	public function list_block_conditions( $input = array() ) {
		self::load_design( 'manifest' );

		$input = (array) $input;
		$event = isset( $input['event'] ) && is_string( $input['event'] ) ? sanitize_key( $input['event'] ) : '';

		if ( '' === $event || ! function_exists( 'BWFAN_Core' ) || ! isset( BWFAN_Core()->sources ) || ! is_object( BWFAN_Core()->sources->get_event( $event ) ) ) {
			return new WP_Error( 'fkmcp_invalid_input', sprintf( 'There is no trigger event "%s". Give the trigger event slug of the Automation the email is sent from (get-automation gives it, e.g. wc_new_order or ab_cart_abandoned), not an integration slug such as wc or autonami.', $event ) );
		}

		$items  = BWFCRM_Email_Design_Conditions::for_event( $event, isset( $input['automation_id'] ) ? absint( $input['automation_id'] ) : 0 );
		$search = isset( $input['search'] ) && is_string( $input['search'] ) ? strtolower( trim( $input['search'] ) ) : '';

		if ( '' !== $search ) {
			$items = array_values(
				array_filter(
					$items,
					static function ( $rule ) use ( $search ) {
						return false !== strpos( strtolower( $rule['name'] . ' ' . $rule['filter'] . ' ' . $rule['group'] ), $search );
					}
				)
			);
		}

		return array( 'items' => $items );
	}

	// ─── preview-email-design ───────────────────────────────────────

	public function preview_email_design( $input = array() ) {
		self::load_design( 'render' );

		$input  = (array) $input;
		$groups = self::event_groups( $input );

		if ( is_wp_error( $groups ) ) {
			return $groups;
		}

		$design   = isset( $input['design'] ) && is_array( $input['design'] ) ? $input['design'] : array();
		$settings = isset( $input['settings'] ) && is_array( $input['settings'] ) ? $input['settings'] : array();

		if ( empty( $design ) && ! empty( $input['template_id'] ) ) {
			$row = self::saved_row( absint( $input['template_id'] ) );

			if ( is_wp_error( $row ) ) {
				return $row;
			}

			$data = self::decode( isset( $row['data'] ) ? $row['data'] : array() );

			if ( self::MODE_BLOCK !== ( isset( $row['mode'] ) ? (int) $row['mode'] : 0 ) ) {
				return new WP_Error( 'fkmcp_invalid_input', 'Only block-editor templates (mode 5) can be previewed.' );
			}

			$design    = BWFCRM_Email_Design_Tree::from_markup( self::block_body( $data ) );
			$settings  = isset( $data['block']['settings'] ) && is_array( $data['block']['settings'] ) ? $data['block']['settings'] : $settings;
			$title     = isset( $row['title'] ) ? (string) $row['title'] : '';
			$preheader = isset( $data['preheader'] ) ? (string) $data['preheader'] : '';
		}

		if ( empty( $design ) ) {
			return new WP_Error( 'fkmcp_invalid_input', 'Give a design, or the template_id of a block-editor template.' );
		}

		$prepared = BWFCRM_Email_Design_Blocks::normalize( $design );

		// The preview is a public page on this site: no design with script in it becomes one, draft or not.
		$markup = self::forbidden_markup( $prepared['tree'], $settings, $groups );

		if ( is_wp_error( $markup ) ) {
			return $markup;
		}

		$built = self::build( $prepared['tree'], $settings );

		if ( is_wp_error( $built ) ) {
			return $built;
		}

		$tree   = BWFCRM_Email_Design_Tree::from_markup( $built['block']['body'] );
		$result = BWFCRM_Email_Design_Preview::run( $built['html'], $tree );
		$page   = self::preview_page( $built['html'], isset( $input['title'] ) && is_string( $input['title'] ) ? sanitize_text_field( $input['title'] ) : ( isset( $title ) ? $title : '' ) );
		$extra  = array( 'transactional' => ! empty( $input['transactional'] ), 'brand_available' => self::brand_available() );

		if ( isset( $input['preheader'] ) || isset( $preheader ) ) {
			$extra['preheader'] = isset( $input['preheader'] ) ? (string) $input['preheader'] : (string) $preheader;
		}

		// A value in a shape the renderer cannot print comes out as [object Object], whatever attribute it was.
		$broken = substr_count( $built['html'], '[object Object]' );

		return array(
			'problems'    => $broken ? array( sprintf( '%d value(s) in the email print as "[object Object]" - an attribute holds an object where the block expects a plain string (often a colour: {"desktop":"#hex"}). Compare the attributes with get-email-design-schema and fix their shape.', $broken ) ) : array(),
			'empty_tags'  => BWFCRM_Email_Design_Preview::empty_merge_tags( $built['html'] ),
			'preview_url' => $page['url'],
			'expires'     => $page['expires'],
			'audit'       => BWFCRM_Email_Design_Audit::run( $built['html'], array( 'transactional' => ! empty( $input['transactional'] ) ) ),
			'quality'     => BWFCRM_Email_Design_Quality::review( $tree, $settings, $extra ),
			'blocks'      => $result['blocks'],
			'conditions'  => $result['conditions'],
		);
	}

	/**
	 * Refuses a design carrying script - tags, handlers or javascript: links -
	 * which the other checks of a draft let through to the preview.
	 *
	 * @return true|WP_Error
	 */
	private static function forbidden_markup( array $design, array $settings, array $groups ) {
		$report = BWFCRM_Email_Design_Tree::validate( $design, $settings, array( 'event_groups' => $groups ) );

		if ( is_wp_error( $report ) ) {
			return $report;
		}

		$found = array();

		foreach ( $report['errors'] as $issue ) {
			if ( 'forbidden_markup' === $issue['code'] ) {
				$found[] = $issue['path'] . ' ' . $issue['message'];
			}
		}

		return empty( $found ) ? true : new WP_Error( 'fkmcp_invalid_input', 'Nothing was previewed: ' . implode( '; ', $found ) );
	}

	/** Whether the site has a brand an email can open with: a logo, or a business name. */
	private static function brand_available() {
		if ( '' !== BWFCRM_Email_Design_Store::site_logo() ) {
			return true;
		}

		$settings = class_exists( 'BWFAN_Common' ) && method_exists( 'BWFAN_Common', 'get_global_settings' ) ? BWFAN_Common::get_global_settings() : array();

		return ! empty( $settings['bwfan_setting_business_name'] );
	}

	/**
	 * A preview page of the email as received. A preview is a help, never a
	 * condition: when it cannot be made the save or check goes on without it.
	 *
	 * @return array { url: string|null, expires: string|null }
	 */
	private static function preview_page( $html, $title ) {
		try {
			return BWFCRM_Email_Design_Preview_Page::create( BWFCRM_Email_Design_Preview::render_email( $html ), $title );
		} catch ( Throwable $e ) {
			return array(
				'url'     => null,
				'expires' => null,
			);
		}
	}

	// ─── validate-email-design ──────────────────────────────────────

	public function validate_email_design( $input = array() ) {
		self::load_design( 'validate' );

		$input  = (array) $input;
		$groups = self::event_groups( $input );

		if ( is_wp_error( $groups ) ) {
			return $groups;
		}

		$prepared = BWFCRM_Email_Design_Blocks::normalize( isset( $input['design'] ) && is_array( $input['design'] ) ? $input['design'] : array() );
		$report   = BWFCRM_Email_Design_Tree::validate(
			$prepared['tree'],
			isset( $input['settings'] ) && is_array( $input['settings'] ) ? $input['settings'] : array(),
			self::check_options( $input, $groups )
		);

		if ( is_wp_error( $report ) ) {
			return $report;
		}

		// What was filled in is said first: a save fills it in the same way.
		$report['warnings'] = array_merge( $prepared['warnings'], $report['warnings'] );
		$report['quality']  = BWFCRM_Email_Design_Quality::review( $prepared['tree'], isset( $input['settings'] ) && is_array( $input['settings'] ) ? $input['settings'] : array(), array( 'transactional' => ! empty( $input['transactional'] ), 'brand_available' => self::brand_available() ) );

		return $report;
	}

	/**
	 * How a design is checked for this email: its trigger's block groups, the
	 * trigger and automation it belongs to, and whether it is transactional.
	 */
	private static function check_options( array $input, array $groups ) {
		return array(
			'event_groups'  => $groups,
			'transactional' => ! empty( $input['transactional'] ),
			'merge_tags'    => self::merge_tag_slugs(),
			'event'         => isset( $input['event'] ) && is_string( $input['event'] ) ? sanitize_key( $input['event'] ) : '',
			'automation_id' => isset( $input['automation_id'] ) ? absint( $input['automation_id'] ) : 0,
		);
	}

	// ─── create / update / clone ────────────────────────────────────

	public function audit_email_design( $input = array() ) {
		self::load_design( 'render' );

		$input = (array) $input;

		if ( ! empty( $input['template_id'] ) && empty( $input['design'] ) ) {
			$row = self::saved_row( absint( $input['template_id'] ) );

			if ( is_wp_error( $row ) ) {
				return $row;
			}

			$html = isset( $row['template'] ) && is_string( $row['template'] ) ? $row['template'] : '';

			if ( '' === trim( $html ) ) {
				return new WP_Error( 'fkmcp_invalid_input', 'This template has no email HTML to audit.' );
			}

			return self::audit_html( $html, $input );
		}

		if ( empty( $input['design'] ) || ! is_array( $input['design'] ) ) {
			return new WP_Error( 'fkmcp_invalid_input', 'Give a design, or the template_id of a saved template.' );
		}

		$groups = self::event_groups( $input );

		if ( is_wp_error( $groups ) ) {
			return $groups;
		}

		$prepared = BWFCRM_Email_Design_Blocks::normalize( $input['design'] );
		$built    = self::build( $prepared['tree'], isset( $input['settings'] ) && is_array( $input['settings'] ) ? $input['settings'] : array() );

		return is_wp_error( $built ) ? $built : self::audit_html( $built['html'], $input );
	}

	/**
	 * The audit on rendered email HTML, plus what an agent needs when it
	 * skipped the slow part: check_links=false asks no address, says so in
	 * links_checked and the broken_urls message, and next hands the outside
	 * links to check-email-links, 10 per call.
	 */
	public static function audit_html( $html, array $input ) {
		self::load_design( 'render' );

		$check  = ! isset( $input['check_links'] ) || ! empty( $input['check_links'] );
		$report = BWFCRM_Email_Design_Audit::run(
			$html,
			array(
				'transactional' => ! empty( $input['transactional'] ),
				'check_links'   => $check,
				'list_links'    => true,
			)
		);

		$report['links_checked'] = $check;
		$report['next']          = array();

		if ( $check ) {
			return $report;
		}

		foreach ( $report['checks'] as $i => $row ) {
			if ( 'broken_urls' !== $row['key'] ) {
				continue;
			}

			// No outside address means nothing to ask: the same answer a full check gives.
			if ( empty( $report['links'] ) ) {
				$report['checks'][ $i ]['passed']  = true;
				$report['checks'][ $i ]['message'] = '';
			} else {
				$report['checks'][ $i ]['message'] = __( 'Not checked: check_links was false. Call check-email-links with next (10 links per call) before telling the user the links work.', 'wp-marketing-automations-pro' );
			}
		}

		if ( wp_has_ability( 'funnelkit/check-email-links' ) ) {
			foreach ( array_chunk( $report['links'], 10 ) as $urls ) {
				$report['next'][] = array(
					'tool' => 'funnelkit-check-email-links',
					'why'  => __( 'Checks these links for broken and shortened addresses.', 'wp-marketing-automations-pro' ),
					'args' => array( 'urls' => $urls ),
				);
			}
		}

		return $report;
	}

	public function check_email_links( $input = array() ) {
		self::load_design( 'render' );

		$urls = array();

		foreach ( isset( $input['urls'] ) && is_array( $input['urls'] ) ? $input['urls'] : array() as $url ) {
			// The schema allows only http(s); requests go through wp_safe_remote_*, which never asks a local address.
			if ( is_string( $url ) && 1 === preg_match( '#^https?://#i', $url ) && ! in_array( $url, $urls, true ) ) {
				$urls[] = $url;
			}
		}

		return BWFCRM_Email_Design_Audit::check_urls( array_slice( $urls, 0, 10 ) );
	}

	public function create_email_template( $input = array() ) {
		self::load_design( 'render' );

		$input  = (array) $input;
		$groups = self::event_groups( $input );

		if ( is_wp_error( $groups ) ) {
			return $groups;
		}

		$prepared = BWFCRM_Email_Design_Blocks::normalize( isset( $input['design'] ) && is_array( $input['design'] ) ? $input['design'] : array() );
		$design   = $prepared['tree'];
		$settings = isset( $input['settings'] ) && is_array( $input['settings'] ) ? $input['settings'] : array();
		$report   = self::check( $design, $settings, self::check_options( $input, $groups ) );

		if ( is_wp_error( $report ) ) {
			return $report;
		}

		$built = self::build( $design, $settings );

		if ( is_wp_error( $built ) ) {
			return $built;
		}

		$data = array( 'block' => $built['block'] );

		if ( isset( $input['preheader'] ) && is_string( $input['preheader'] ) ) {
			$data['preheader'] = sanitize_text_field( $input['preheader'] );
		}

		$response = BWFAN_MCP_Dispatch::write(
			'create-email-template',
			array(
				'title'    => sanitize_text_field( $input['title'] ),
				'subject'  => sanitize_text_field( $input['subject'] ),
				'template' => $built['html'],
				'type'     => 1,
				'mode'     => self::MODE_BLOCK,
				'data'     => wp_json_encode( $data ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$id = isset( $response['result']['id'] ) ? absint( $response['result']['id'] ) : 0;

		if ( ! $id ) {
			return new WP_Error( 'fkmcp_write_failed', 'The template could not be saved.' );
		}

		$page = self::preview_page( $built['html'], sanitize_text_field( $input['subject'] ) );

		return array(
			'id'          => $id,
			'title'       => sanitize_text_field( $input['title'] ),
			'link'        => self::template_link( $id ),
			'preview_url' => $page['url'],
			'quality'     => BWFCRM_Email_Design_Quality::review( $design, $settings, array( 'preheader' => isset( $input['preheader'] ) ? (string) $input['preheader'] : '', 'transactional' => ! empty( $input['transactional'] ), 'brand_available' => self::brand_available() ) ),
			'bytes'       => strlen( $built['html'] ),
			'audit'       => BWFCRM_Email_Design_Audit::run( $built['html'], array( 'transactional' => ! empty( $input['transactional'] ) ) ),
			'warnings'    => array_merge( $prepared['warnings'], $report['warnings'], $built['warnings'] ),
		);
	}

	public function update_email_template( $input = array() ) {
		self::load_design( 'render' );

		$input  = (array) $input;
		$id     = isset( $input['template_id'] ) ? absint( $input['template_id'] ) : 0;
		$groups = self::event_groups( $input );

		if ( is_wp_error( $groups ) ) {
			return $groups;
		}

		$row = self::saved_row( $id );

		if ( is_wp_error( $row ) ) {
			return $row;
		}

		$mode = isset( $row['mode'] ) ? (int) $row['mode'] : 0;

		if ( self::MODE_BLOCK !== $mode ) {
			return new WP_Error( 'fkmcp_invalid_input', 'Only block-editor templates (mode 5) can be updated with this tool; this one is ' . ( isset( self::MODES[ $mode ] ) ? self::MODES[ $mode ] : 'another editor' ) . '. Create a new block-editor template instead.' );
		}

		$data     = self::decode( isset( $row['data'] ) ? $row['data'] : array() );
		$block    = isset( $data['block'] ) && is_array( $data['block'] ) ? $data['block'] : array();
		$html     = isset( $row['template'] ) && is_string( $row['template'] ) ? $row['template'] : '';
		$updated  = array();
		$warnings = array();
		$rendered = false;

		$preexisting = array();

		$has_design   = isset( $input['design'] ) && is_array( $input['design'] );
		$has_settings = isset( $input['settings'] ) && is_array( $input['settings'] );

		if ( $has_design || $has_settings ) {
			$sent = isset( $input['revision'] ) && is_string( $input['revision'] ) ? $input['revision'] : '';

			if ( '' === $sent ) {
				return new WP_Error( 'fkmcp_invalid_input', 'Send the revision get-email-template returned with a new design or settings, so an edit made since is not overwritten.' );
			}

			if ( ! hash_equals( self::revision( $row ), $sent ) ) {
				return new WP_Error( 'fkmcp_stale_template', 'This template was saved since you read it - in the editor or by another edit. Read it again with get-email-template, make the change on that version and send its revision.' );
			}

			$prepared = BWFCRM_Email_Design_Blocks::normalize( $has_design ? $input['design'] : BWFCRM_Email_Design_Tree::from_markup( self::block_body( $data ) ) );
			$design   = $prepared['tree'];
			$kept     = isset( $block['settings'] ) && is_array( $block['settings'] ) ? $block['settings'] : array();
			$settings = $has_settings ? self::merge_settings( $kept, $input['settings'] ) : $kept;

			if ( empty( $design ) ) {
				return new WP_Error( 'fkmcp_invalid_input', $has_design ? 'The design is empty; send at least one row.' : 'This template has no block design to apply settings to; send a design.' );
			}

			$stored   = BWFCRM_Email_Design_Blocks::normalize( BWFCRM_Email_Design_Tree::from_markup( self::block_body( $data ) ) );
			$options  = self::check_options( $input, $groups );
			$baseline = empty( $stored['tree'] ) ? array() : self::known_errors( $stored['tree'], $kept, $options );
			$report   = self::check( $design, $settings, $options, $baseline, $has_design );

			if ( is_wp_error( $report ) ) {
				return $report;
			}

			$built = self::build( $design, $settings );

			if ( is_wp_error( $built ) ) {
				return $built;
			}

			$data['block'] = $built['block'];
			$html          = $built['html'];
			$rendered      = true;
			$warnings      = array_merge( $has_design ? $prepared['warnings'] : array(), $report['warnings'], $built['warnings'] );
			$preexisting   = $report['preexisting'];
			$updated       = array_merge( $updated, $has_design ? array( 'design' ) : array(), $has_settings ? array( 'settings' ) : array() );
		}

		if ( isset( $input['preheader'] ) && is_string( $input['preheader'] ) ) {
			$data['preheader'] = sanitize_text_field( $input['preheader'] );
			$updated[]         = 'preheader';
		}

		$title   = isset( $input['title'] ) ? sanitize_text_field( $input['title'] ) : ( isset( $row['title'] ) ? (string) $row['title'] : '' );
		$subject = isset( $input['subject'] ) ? sanitize_text_field( $input['subject'] ) : ( isset( $row['subject'] ) ? (string) $row['subject'] : '' );

		if ( isset( $input['title'] ) ) {
			$updated[] = 'title';
		}

		if ( isset( $input['subject'] ) ) {
			$updated[] = 'subject';
		}

		if ( empty( $updated ) ) {
			return new WP_Error( 'fkmcp_invalid_input', 'Nothing to update: pass at least one of title, subject, preheader, design or settings.' );
		}

		if ( '' === trim( $html ) ) {
			return new WP_Error( 'fkmcp_invalid_input', 'This template has no email HTML yet; send its design so it can be generated.' );
		}

		$revision = self::revision(
			array(
				'title'    => $title,
				'subject'  => $subject,
				'template' => $html,
				'data'     => $data,
			)
		);

		// Read again right before the write: the checks and the render above take a while, and a save made meanwhile would be lost.
		$fresh = self::stored_revision( $id );

		if ( is_wp_error( $fresh ) ) {
			return $fresh;
		}

		if ( ! hash_equals( self::revision( $row ), $fresh ) ) {
			return new WP_Error( 'fkmcp_stale_template', 'This template was saved since you read it - in the editor or by another edit. Read it again with get-email-template, make the change on that version and send its revision.' );
		}

		// The controller writes every column it is given - and turns a missing mode into rich text - so send them all.
		$response = BWFAN_MCP_Dispatch::write(
			'update-email-template',
			array(
				'template_id' => $id,
				'title'       => $title,
				'subject'     => $subject,
				'template'    => $html,
				'type'        => 1,
				'mode'        => self::MODE_BLOCK,
				'data'        => wp_json_encode( $data ),
			),
			array( 'template_id' => $id )
		);

		// The model reports a write that changed no row as a failure: a retry of the same update. It is done if the row now reads as written.
		if ( is_wp_error( $response ) && self::stored_revision( $id ) !== $revision ) {
			return $response;
		}

		$page = $rendered ? self::preview_page( $html, $subject ) : null;

		return array(
			'id'          => $id,
			'revision'    => $revision,
			'updated'     => array_values( array_unique( $updated ) ),
			'rendered'    => $rendered,
			'preview_url' => null !== $page ? $page['url'] : null,
			'quality'     => $rendered ? BWFCRM_Email_Design_Quality::review( $design, $settings, array( 'preheader' => isset( $data['preheader'] ) ? (string) $data['preheader'] : '', 'transactional' => ! empty( $input['transactional'] ), 'brand_available' => self::brand_available() ) ) : null,
			'preexisting' => $preexisting,
			'audit'       => $rendered ? BWFCRM_Email_Design_Audit::run( $html, array( 'transactional' => ! empty( $input['transactional'] ) ) ) : null,
			'notice'      => self::preexisting_notice( $preexisting ),
			'link'        => self::template_link( $id ),
			'warnings'    => $warnings,
		);
	}

	public function edit_email_design( $input = array() ) {
		self::load_design( 'render' );

		$input   = (array) $input;
		$id      = isset( $input['template_id'] ) ? absint( $input['template_id'] ) : 0;
		$row = self::saved_row( $id );

		if ( is_wp_error( $row ) ) {
			return $row;
		}

		if ( self::MODE_BLOCK !== ( isset( $row['mode'] ) ? (int) $row['mode'] : 0 ) ) {
			return new WP_Error( 'fkmcp_invalid_input', 'Only block-editor templates (mode 5) can be edited with this tool.' );
		}

		$sent = isset( $input['revision'] ) && is_string( $input['revision'] ) ? $input['revision'] : '';

		// Checked here too, before anything is worked out on a version that is gone.
		if ( ! hash_equals( self::revision( $row ), $sent ) ) {
			return new WP_Error( 'fkmcp_stale_template', 'This template was saved since you read it - in the editor or by another edit. Read it again with get-email-template, and address the edit to that version with its revision.' );
		}

		$tree = BWFCRM_Email_Design_Tree::from_markup( self::block_body( self::decode( isset( $row['data'] ) ? $row['data'] : array() ) ) );

		if ( empty( $tree ) ) {
			return new WP_Error( 'fkmcp_invalid_input', 'This template has no block design to edit; send a whole design with update-email-template.' );
		}

		$edit = BWFCRM_Email_Design_Edit::apply( $tree, isset( $input['operations'] ) && is_array( $input['operations'] ) ? $input['operations'] : array() );

		if ( is_wp_error( $edit ) ) {
			return $edit;
		}

		$result = $this->update_email_template(
			array_merge(
				array_intersect_key( $input, array_flip( array( 'template_id', 'revision', 'event', 'automation_id', 'transactional' ) ) ),
				array( 'design' => $edit['tree'] )
			)
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		unset( $result['updated'], $result['rendered'] );

		return array_merge( array( 'applied' => $edit['applied'] ), $result );
	}

	public function clone_email_template( $input = array() ) {
		$id = isset( $input['template_id'] ) ? absint( $input['template_id'] ) : 0;

		// The model copies any row by id - a deleted template, an automation's or a broadcast's email - so only a saved template is let through.
		$source = self::saved_row( $id );

		if ( is_wp_error( $source ) ) {
			return $source;
		}

		$response = BWFAN_MCP_Dispatch::call( 'clone-email-template', array(), array( 'template_id' => $id ) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$copy = isset( $response['result']['id'] ) ? absint( $response['result']['id'] ) : 0;

		return array(
			'source_id' => $id,
			'id'        => $copy ? $copy : null,
			'link'      => $copy ? self::template_link( $copy ) : null,
		);
	}

	/** What a problem code means to someone reading the email, for the preexisting notice. */
	const PROBLEM_LABELS = array(
		'unreadable'      => 'text that cannot be read on its background',
		'low_contrast'    => 'text that is hard to read',
		'wrong_shape'     => 'colours or values in a form the editor ignores',
		'setting_ignored' => 'email settings the site style overrides',
		'no_unsubscribe'  => 'no unsubscribe link',
	);

	/**
	 * One sentence for the user about the problems an edit left as they were,
	 * or null when there are none.
	 *
	 * @param array[] $preexisting
	 *
	 * @return string|null
	 */
	private static function preexisting_notice( array $preexisting ) {
		if ( empty( $preexisting ) ) {
			return null;
		}

		$labels = array();

		foreach ( array_count_values( array_column( $preexisting, 'code' ) ) as $code => $count ) {
			$labels[] = ( isset( self::PROBLEM_LABELS[ $code ] ) ? self::PROBLEM_LABELS[ $code ] : str_replace( '_', ' ', $code ) ) . ' (' . $count . ')';
		}

		return sprintf( 'Only the requested change was made. This template already had problems, left as they were: %s. Tell the user and offer to fix them.', implode( '; ', $labels ) );
	}

	/**
	 * The errors a saved design already has, as keys an edit's errors are
	 * matched against: the same problem on the same block, found by its
	 * uniqueID so a block that moved still matches (error_key()).
	 *
	 * @return bool[] key => true
	 */
	private static function known_errors( array $design, array $settings, array $options ) {
		$report = BWFCRM_Email_Design_Tree::validate( $design, $settings, $options );
		$keys   = array();

		foreach ( is_wp_error( $report ) ? array() : $report['errors'] as $error ) {
			$keys[ self::error_key( $design, $error ) ] = true;
		}

		return $keys;
	}

	/**
	 * Where an error is, as the uniqueID of the block its path points into and
	 * the rest of the path; the path itself for a block without one, or for
	 * the settings. Positions change when blocks are inserted or moved; ids do not.
	 *
	 * @param array[] $design
	 * @param array   $error { code, path }
	 *
	 * @return string
	 */
	private static function error_key( array $design, array $error ) {
		$parts = explode( '/', ltrim( (string) $error['path'], '/' ) );
		$nodes = $design;
		$id    = '';
		$rest  = $parts;

		for ( $i = 0; $i < count( $parts ); $i++ ) {
			if ( ! ctype_digit( $parts[ $i ] ) || ! isset( $nodes[ (int) $parts[ $i ] ] ) || ! is_array( $nodes[ (int) $parts[ $i ] ] ) ) {
				break;
			}

			$node = $nodes[ (int) $parts[ $i ] ];
			$id   = isset( $node['attrs']['uniqueID'] ) && is_string( $node['attrs']['uniqueID'] ) ? $node['attrs']['uniqueID'] : '';
			$rest = array_slice( $parts, $i + 1 );

			if ( ! isset( $parts[ $i + 1 ] ) || 'innerBlocks' !== $parts[ $i + 1 ] || empty( $node['innerBlocks'] ) || ! is_array( $node['innerBlocks'] ) ) {
				break;
			}

			$nodes = $node['innerBlocks'];
			$i++;
		}

		return '' === $id ? $error['code'] . '|' . $error['path'] : $error['code'] . '|#' . $id . '/' . implode( '/', $rest );
	}

	/**
	 * Validates a design before a save, the way validate-email-design does.
	 *
	 * @param array[] $design
	 * @param array   $settings
	 * @param array   $options  check_options(): the email's trigger, automation and kind.
	 * @param bool[]  $baseline Errors the design had before this edit (known_errors()):
	 *                          reported in `preexisting`, never blocking. A settings change
	 *                          that makes a block unreadable is new, so it blocks.
	 * @param bool    $design_sent Whether the design itself came with the request. Stored
	 *                          markup the editor accepted (a <style> in an HTML block) does
	 *                          not block a settings-only change; markup sent always does.
	 *
	 * @return array|WP_Error The report, or the refusal listing every error.
	 */
	private static function check( array $design, array $settings, array $options, array $baseline = array(), $design_sent = true ) {
		$report = BWFCRM_Email_Design_Tree::validate( $design, $settings, $options );

		if ( is_wp_error( $report ) ) {
			return $report;
		}

		$errors                = array();
		$report['preexisting'] = array();

		foreach ( $report['errors'] as $error ) {
			// An edit is judged on what it changes: problems the template already had do not block it.
			// Markup that is not allowed always does when the design was sent.
			if ( ( ! $design_sent || 'forbidden_markup' !== $error['code'] ) && isset( $baseline[ self::error_key( $design, $error ) ] ) ) {
				$report['preexisting'][] = $error;
			} else {
				$errors[] = $error;
			}
		}

		if ( empty( $errors ) ) {
			return $report;
		}

		$lines = array();

		foreach ( array_slice( $errors, 0, 15 ) as $error ) {
			$lines[] = $error['path'] . ' ' . $error['code'] . ': ' . $error['message'];
		}

		return new WP_Error(
			'fkmcp_invalid_design',
			sprintf( 'The design has %d error(s); nothing was saved. Fix them and send it again:', count( $errors ) ) . "\n" . implode( "\n", $lines ) . ( count( $errors ) > 15 ? "\n…" : '' )
		);
	}

	/**
	 * The design as the template stores it: block markup for the editor and,
	 * rendered from the very same completed tree, the email HTML to send.
	 *
	 * @param array[]     $design
	 * @param array       $settings
	 * @param string|null $budget   image-measure budget name shared across designs (see Measure::apply()); null = its own.
	 *
	 * @return array|WP_Error { block: data.block, html, warnings }
	 */
	private static function build( array $design, array $settings, $budget = null ) {
		BWFCRM_Email_Renderer::load();

		// Completed, measured as the editor would measure it on screen, and completed again to put
		// every attribute back in its shape; the ids in the markup and the classes in the HTML are the same.
		$measured = BWFCRM_Email_Design_Measure::apply( BWFCRM_Email_Design_Tree::complete( $design, $settings ), $settings, $budget );
		$tree     = BWFCRM_Email_Design_Tree::complete( $measured['tree'], $settings );
		$html     = BWFCRM_Email_Renderer::render( $tree, $settings );

		if ( is_wp_error( $html ) ) {
			return $html;
		}

		return array(
			'block' => array(
				'body'           => BWFCRM_Email_Design_Tree::to_markup( $tree ),
				'settings'       => (object) BWFCRM_Email_Design_Tree::runtime_settings( $settings ),
				'rendered_by'    => 'php',
				'editor_version' => BWFCRM_Email_Design_Manifest::EDITOR_VERSION,
			),
			'html'     => $html,
			'warnings' => $measured['warnings'],
		);
	}

	private static function template_link( $id ) {
		return BWFAN_MCP_Links::app( 'autonami', '/template/' . absint( $id ) . '/' );
	}

	/**
	 * Every merge tag on the site as it is written in an email - {{contact_first_name}} -
	 * for the unknown-merge-tag check; empty when they cannot be read. The loader keys
	 * its tags by class slug; the name inside the braces is the tag's own name.
	 */
	public static function merge_tag_slugs() {
		if ( ! class_exists( 'BWFAN_Merge_Tag_Loader' ) || ! method_exists( 'BWFAN_Merge_Tag_Loader', 'get_all_merge_tags' ) ) {
			return array();
		}

		$names = array();

		foreach ( (array) BWFAN_Merge_Tag_Loader::get_all_merge_tags() as $group ) {
			if ( ! is_array( $group ) ) {
				continue;
			}

			foreach ( $group as $slug => $tag ) {
				$name = is_object( $tag ) && method_exists( $tag, 'get_name' ) && is_scalar( $tag->get_name() ) ? (string) $tag->get_name() : (string) $slug;

				if ( '' !== $name ) {
					$names[] = $name;
				}
			}
		}

		return array_values( array_unique( $names ) );
	}

	/**
	 * Validator findings that refuse a template copied into an automation step (spec §3.2),
	 * combined with UNSCANNED below. Every other finding is a warning. automation_design()
	 * does not use this list: a freshly-sent design blocks on any validator error at all,
	 * since nothing about it has been seen or trusted before.
	 */
	const AUTOMATION_BLOCKING = array( 'forbidden_markup', 'bad_key', 'disallowed_tag', 'unavailable_block', 'no_unsubscribe', 'unknown_merge_tag' );

	/**
	 * Two kinds of finding, both blocking for automation_copy(). not_a_block,
	 * stray_content, unknown_block, too_deep, bad_attrs, bad_children and inner_html mean
	 * part of the tree was never actually read: the validator's check_node() (tree.php)
	 * returns early on each of them, so content under that point - a <script>, in particular
	 * - never gets its own forbidden_markup/merge-tag check. wrong_parent and leaf_children
	 * are not about unread content; they stay blocking because they are structural problems
	 * the block editor would never have saved in the first place - a stored template holding
	 * one was never actually valid. too_large is deliberately not here: the validator only
	 * computes it once the whole tree scanned clean (tree.php :217-223), so it is a size
	 * limit on a fully-read design, not a sign that something went unscanned.
	 */
	const UNSCANNED = array( 'not_a_block', 'stray_content', 'unknown_block', 'too_deep', 'bad_attrs', 'bad_children', 'inner_html', 'wrong_parent', 'leaf_children' );

	/**
	 * A saved mode-5 template, re-checked for the automation it is copied into:
	 * its trigger's block groups, merge tags and transactional setting. The stored
	 * HTML and block are returned as they are - never re-rendered - so the copy is
	 * byte-identical every time. Blocks on AUTOMATION_BLOCKING and UNSCANNED findings;
	 * every other finding is a warning. Public seam for FKMCP_Email_Step (M5a).
	 *
	 * @param array $row   templates row: template, data, subject, title, mode.
	 * @param array $input {event, automation_id, transactional}.
	 *
	 * @return array|WP_Error {html, block (as stored: an object from the row's JSON), blocking[], warnings[]}
	 */
	public static function automation_copy( array $row, array $input ) {
		return self::copy_check( $row, $input, false );
	}

	/**
	 * A saved mode-5 template, re-checked for a broadcast: no trigger, so no cart or order block,
	 * and only the broadcast's merge tags. Same result and same blocking rules as automation_copy().
	 * The caller applies footer_ok() to the returned html.
	 *
	 * @param array $row   templates row: template, data, subject, title, mode.
	 * @param array $input {transactional}.
	 *
	 * @return array|WP_Error {html, block (as stored: an object from the row's JSON), blocking[], warnings[]}
	 */
	public static function broadcast_copy( array $row, array $input ) {
		return self::copy_check( $row, $input, true );
	}

	/** The one re-check behind automation_copy() and broadcast_copy(). */
	private static function copy_check( array $row, array $input, $broadcast ) {
		self::load_design( 'validate' );

		// Arrays are for validation only. The block handed back comes from an object decode, so an
		// empty {} (settings, or nested) stays {} when the step stores it - an array decode makes it [].
		$data   = self::decode( isset( $row['data'] ) ? $row['data'] : array() );
		$stored = isset( $row['data'] ) && is_string( $row['data'] ) ? json_decode( $row['data'] ) : null;
		$block  = isset( $stored->block ) && is_object( $stored->block ) ? $stored->block : ( isset( $data['block'] ) && is_array( $data['block'] ) ? $data['block'] : array() );
		$body   = self::block_body( $data );

		if ( '' === trim( $body ) ) {
			return new WP_Error( 'fkmcp_invalid_input', 'The template has no design.' );
		}

		if ( $broadcast ) {
			$options = self::broadcast_options( $input );
		} else {
			$groups = self::event_groups( $input );
			if ( is_wp_error( $groups ) ) {
				return $groups;
			}
			$options = self::check_options( $input, $groups );
		}

		$settings = isset( $data['block']['settings'] ) ? self::decode( $data['block']['settings'] ) : array();
		$report   = BWFCRM_Email_Design_Tree::validate( BWFCRM_Email_Design_Tree::from_markup( $body ), $settings, $options );
		if ( is_wp_error( $report ) ) {
			return $report;
		}

		list( $blocking, $warnings ) = self::split_report( $report, array_merge( self::AUTOMATION_BLOCKING, self::UNSCANNED ) );

		return array(
			'html'     => isset( $row['template'] ) ? (string) $row['template'] : '',
			'block'    => $block,
			'blocking' => $blocking,
			'warnings' => $warnings,
		);
	}

	/**
	 * An inline block design for an automation email step (spec §7.1): normalised,
	 * validated for the automation's trigger and transactional setting, then rendered
	 * by the template builder's own build(). Only this renderer's output is stored;
	 * the agent never sends HTML. Any validator error refuses it outright -
	 * a design sent fresh has nothing already trusted about it, so a finding that means
	 * part of the tree was never read (too_deep, unknown_block, …) must block exactly
	 * like a finding that means content was. Only the validator's warnings pass through.
	 *
	 * @param array $design   the block tree, as create-email-template takes it.
	 * @param array $settings design settings; empty = the site's defaults.
	 * @param array $input    {event, automation_id, transactional, measure_budget?}. measure_budget names
	 *                        one image-download budget that every design of one definition build
	 *                        shares; without it this design gets its own.
	 *
	 * @return array|WP_Error {html, block, blocking[], warnings[]}
	 */
	public static function automation_design( array $design, array $settings, array $input ) {
		self::load_design( 'render' );

		$groups = self::event_groups( $input );
		if ( is_wp_error( $groups ) ) {
			return $groups;
		}

		return self::design_pipeline( $design, $settings, $input, self::check_options( $input, $groups ) );
	}

	/**
	 * An inline block design for a broadcast email: the same pipeline as automation_design(),
	 * checked for a broadcast. A broadcast has no trigger, so no cart or order block is
	 * available and only the broadcast's own merge tags are known. Whatever the design,
	 * the email also needs the footer the broadcast wizard asks for, or it is refused.
	 *
	 * @param array $design   the block tree, as create-email-template takes it.
	 * @param array $settings design settings; empty = the site's defaults.
	 * @param array $input    {transactional, budget?}. budget names one image-download budget
	 *                        shared by every design of one create call.
	 *
	 * @return array|WP_Error {html, block, blocking[], warnings[]}
	 */
	public static function broadcast_design( array $design, array $settings, array $input ) {
		self::load_design( 'render' );

		$options = self::broadcast_options( $input );

		if ( isset( $input['budget'] ) && is_string( $input['budget'] ) ) {
			$input['measure_budget'] = $input['budget'];
		}

		$result = self::design_pipeline( $design, $settings, $input, $options );

		if ( is_wp_error( $result ) || ! empty( $result['blocking'] ) || self::footer_ok( $result['html'] ) ) {
			return $result;
		}

		return array(
			'html'     => '',
			'block'    => null,
			'blocking' => array(
				array(
					'path'    => '',
					'code'    => 'no_footer',
					'message' => 'A broadcast email needs {{mail_footer}} (the email-block/footer block with its global footer), or {{unsubscribe_link}}, {{business_name}} and {{business_address}} in the email.',
				),
			),
			'warnings' => $result['warnings'],
		);
	}

	/** The validator's options for a broadcast: no trigger groups, the broadcast's own merge tags. */
	private static function broadcast_options( array $input ) {
		return array(
			'event_groups'  => array(),
			'transactional' => ! empty( $input['transactional'] ),
			'merge_tags'    => self::broadcast_merge_tags(),
			'event'         => '',
			'automation_id' => 0,
		);
	}

	/**
	 * What the broadcast wizard's step 3 asks of an email body: the global footer's merge
	 * tag, or the unsubscribe link and the business name and address spelled out.
	 *
	 * @param string $html
	 *
	 * @return bool
	 */
	public static function footer_ok( $html ) {
		$html = (string) $html;

		return false !== strpos( $html, '{{mail_footer}}' )
			|| ( false !== strpos( $html, '{{unsubscribe_link}}' ) && false !== strpos( $html, '{{business_name}}' ) && false !== strpos( $html, '{{business_address}}' ) );
	}

	/**
	 * Test seam: a callable returning the broadcast's merge tag names, used in place of the
	 * merge tag loader.
	 *
	 * @var callable|null
	 */
	public static $broadcast_tags = null;

	/**
	 * The merge tags a broadcast knows, as written inside the braces: the same groups the
	 * broadcast editor lists (bwfan_default and the broadcast-safe tags). The contact-field
	 * tag is one name whatever the field, so it covers every {{contact_field key="…"}}.
	 * Empty when they cannot be read, which skips the unknown-tag check.
	 *
	 * @return string[]
	 */
	public static function broadcast_merge_tags() {
		if ( is_callable( self::$broadcast_tags ) ) {
			return array_values( array_unique( array_map( 'strval', (array) call_user_func( self::$broadcast_tags ) ) ) );
		}

		if ( ! function_exists( 'BWFAN_Core' ) || ! isset( BWFAN_Core()->merge_tags ) || ! method_exists( BWFAN_Core()->merge_tags, 'get_localize_tags_with_group' ) ) {
			return array();
		}

		$names = array();

		try {
			foreach ( (array) BWFAN_Core()->merge_tags->get_localize_tags_with_group( false, array( 'bwfan_default' ) ) as $group ) {
				foreach ( is_array( $group ) ? $group : array() as $tag ) {
					if ( is_object( $tag ) && method_exists( $tag, 'get_name' ) && is_scalar( $tag->get_name() ) && '' !== (string) $tag->get_name() ) {
						$names[] = (string) $tag->get_name();
					}
				}
			}
		} catch ( Throwable $e ) {
			return array();
		}

		return array_values( array_unique( $names ) );
	}

	/**
	 * The steps both inline designs share: seed, normalise, assign ids, validate (any
	 * error blocks), build.
	 *
	 * @param array $design
	 * @param array $settings
	 * @param array $input    reads measure_budget.
	 * @param array $options  the validator's options.
	 *
	 * @return array|WP_Error {html, block, blocking[], warnings[]}
	 */
	private static function design_pipeline( array $design, array $settings, array $input, array $options ) {
		// The seed is the design exactly as the agent sent it - normalize() below only ever
		// fills in defaults, so the same input always derives the same ids regardless.
		$seed = hash( 'sha256', (string) wp_json_encode( $design ) );

		$prepared = BWFCRM_Email_Design_Blocks::normalize( $design );
		if ( empty( $prepared['tree'] ) ) {
			return new WP_Error( 'fkmcp_invalid_input', 'The design is empty. Send at least one email-block/row > section > column > content block.' );
		}

		// Ids after normalize(), not before: normalize()'s own defaults (a product block's
		// card style, in particular) only apply to a block it still sees as new - one with
		// no uniqueID yet. Build() never hands Tree::complete() a block it has to
		// invent a random id for either way - two calls on the same design render the same.
		$tree = self::assign_ids( $prepared['tree'], $seed );

		$report = BWFCRM_Email_Design_Tree::validate( $tree, $settings, $options );
		if ( is_wp_error( $report ) ) {
			return $report;
		}

		// No code list here: every error blocks, so the design is either fully
		// trusted or not rendered at all.
		list( $blocking, $warnings ) = self::split_report( $report );

		if ( ! empty( $blocking ) ) {
			// Nothing rendered for a refused design - the agent never sees HTML built from blocked markup.
			return array(
				'html'     => '',
				'block'    => null,
				'blocking' => $blocking,
				'warnings' => $warnings,
			);
		}

		$built = self::build( $tree, $settings, isset( $input['measure_budget'] ) && is_string( $input['measure_budget'] ) ? $input['measure_budget'] : null );
		if ( is_wp_error( $built ) ) {
			return $built;
		}

		foreach ( array_merge( $prepared['warnings'], $built['warnings'] ) as $warning ) {
			$warnings[] = self::format_warning( $warning );
		}

		return array(
			'html'     => $built['html'],
			'block'    => $built['block'],
			'blocking' => array(),
			'warnings' => $warnings,
		);
	}

	/**
	 * Every id-less block in a design tree gets a stable, deterministic uniqueID -
	 * derived from the given seed and the block's position, never from time or
	 * randomness - so the same design assigns the same ids on every call. An id the
	 * agent already sent is left exactly as sent; a bad or duplicate one still goes
	 * to the validator and is refused there, same as today. Stops at the validator's
	 * own nesting limit: a block past it is never read by validate() either, so
	 * it is left untouched here and is refused there as too_deep.
	 *
	 * @param array  $tree the block tree to stamp ids into (normalize()'s output).
	 * @param string $seed hash of the design exactly as the agent sent it.
	 *
	 * @return array the same tree, with a uniqueID on every reachable block that arrived without one.
	 */
	private static function assign_ids( array $tree, $seed ) {
		$used = array();
		self::collect_assigned_ids( $tree, $used );

		return self::assign_ids_at( $tree, $seed, '', $used, 0 );
	}

	/** Every uniqueID already in the tree (agent-sent or assigned on an earlier pass), as complete() collects them. */
	private static function collect_assigned_ids( array $blocks, array &$used ) {
		foreach ( $blocks as $block ) {
			if ( is_array( $block ) && isset( $block['attrs']['uniqueID'] ) && is_string( $block['attrs']['uniqueID'] ) && '' !== $block['attrs']['uniqueID'] ) {
				$used[ $block['attrs']['uniqueID'] ] = true;
			}

			if ( is_array( $block ) && ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				self::collect_assigned_ids( $block['innerBlocks'], $used );
			}
		}
	}

	/**
	 * @param array  $blocks
	 * @param string $seed  hash of the whole design, so the same design always derives the same ids.
	 * @param string $path  the block's index path so far, e.g. "0/1".
	 * @param array  $used  ids already spoken for; updated as new ones are assigned.
	 * @param int    $depth how deep $blocks sits (0 = top level), mirroring Tree::validate()'s own depth count.
	 */
	private static function assign_ids_at( array $blocks, $seed, $path, array &$used, $depth ) {
		foreach ( $blocks as $i => $block ) {
			// A scalar (or otherwise non-block) entry is left exactly as sent; the
			// validator reports not_a_block for it and the design is refused there.
			if ( ! is_array( $block ) ) {
				continue;
			}

			$block_path = '' === $path ? (string) $i : $path . '/' . $i;
			$attrs      = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();

			if ( empty( $attrs['uniqueID'] ) || ! is_string( $attrs['uniqueID'] ) ) {
				$attempt = 0;

				do {
					// 7 lowercase hex characters, the validator's own rule (bad_unique_id).
					$id = substr( hash( 'sha256', $seed . '|' . $block_path . '|' . $attempt ), 0, 7 );
					++$attempt;
				} while ( isset( $used[ $id ] ) );

				$used[ $id ]       = true;
				$attrs['uniqueID'] = $id;
				$block['attrs']    = $attrs;
			}

			// Past this depth, validate() never looks at the node at all (it reports
			// too_deep on the parent and stops) - leave it untouched rather than assign an id
			// to a subtree the validator is about to refuse wholesale.
			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) && $depth + 1 < BWFCRM_Email_Design_Tree::MAX_DEPTH ) {
				$block['innerBlocks'] = self::assign_ids_at( $block['innerBlocks'], $seed, $block_path, $used, $depth + 1 );
			}

			$blocks[ $i ] = $block;
		}

		return $blocks;
	}

	/** A sample-data preview page (1 h) of HTML already saved into an automation step. */
	public static function automation_preview( $html, $title ) {
		self::load_design( 'render' );

		return self::preview_page( (string) $html, (string) $title );
	}

	/**
	 * Splits a validator report (errors + optional warnings) into blocking findings and
	 * every other finding, flattened to "<path>: <message>". Shared by automation_copy()
	 * and automation_design() so both read the same findings the same way.
	 *
	 * @param array      $report         {errors, warnings?} - each one {path, code, message}.
	 * @param array|null $blocking_codes null blocks every error (automation_design -
	 *                                   a fresh design is never partially trusted); an array
	 *                                   blocks only errors whose code is in it (automation_copy).
	 *
	 * @return array{0: array[], 1: string[]} [$blocking, $warnings]
	 */
	private static function split_report( array $report, $blocking_codes = null ) {
		$blocking = array();
		$warnings = array();

		foreach ( $report['errors'] as $error ) {
			if ( null === $blocking_codes || in_array( $error['code'], $blocking_codes, true ) ) {
				$blocking[] = $error;
			} else {
				$warnings[] = self::format_warning( $error );
			}
		}

		foreach ( isset( $report['warnings'] ) ? $report['warnings'] : array() as $warning ) {
			$warnings[] = self::format_warning( $warning );
		}

		return array( $blocking, $warnings );
	}

	/**
	 * A finding as a single line: "<path>: <message>", or just the message when the
	 * path is empty. A bare string (never produced today, but tolerated) passes through.
	 *
	 * @param array|string $item {path, message}, or a plain string.
	 *
	 * @return string
	 */
	private static function format_warning( $item ) {
		if ( ! is_array( $item ) ) {
			return (string) $item;
		}

		$path    = isset( $item['path'] ) ? $item['path'] : '';
		$message = isset( $item['message'] ) ? $item['message'] : '';

		return '' === $path ? $message : $path . ': ' . $message;
	}

	/** The template's revision as get-email-template reports it, for the step's template_ref. */
	public static function template_revision( array $row ) {
		return self::revision( $row );
	}

	// ─── helpers ────────────────────────────────────────────────────

	/**
	 * A template's data column as an array. The controllers hand it over
	 * decoded to objects, or as the JSON string it is stored as.
	 *
	 * @param mixed $data
	 *
	 * @return array
	 */
	private static function decode( $data ) {
		if ( is_string( $data ) ) {
			$data = json_decode( $data, true );
		} elseif ( is_object( $data ) ) {
			$data = json_decode( wp_json_encode( $data ), true );
		}

		return is_array( $data ) ? $data : array();
	}

	private static function block_body( array $data ) {
		return isset( $data['block']['body'] ) && is_string( $data['block']['body'] ) ? $data['block']['body'] : '';
	}

	/**
	 * A saved template's row, read as get-email-template reads it: only a
	 * saved template (not deleted, not an automation's or a broadcast's email).
	 *
	 * @param int $id
	 *
	 * @return array|WP_Error
	 */
	private static function saved_row( $id ) {
		$response = BWFAN_MCP_Dispatch::call( 'get-email-template', array(), array( 'template_id' => absint( $id ) ) );

		if ( is_wp_error( $response ) ) {
			return 'fkmcp_not_found' === $response->get_error_code() ? self::not_a_template( absint( $id ) ) : $response;
		}

		$row = isset( $response['result'] ) && is_array( $response['result'] ) ? $response['result'] : array();

		return empty( $row ) ? self::not_a_template( absint( $id ) ) : $row;
	}

	/**
	 * Why an id is not a saved template, and where its content is read instead: the same
	 * table also holds saved layouts and the email of each automation step and broadcast.
	 */
	private static function not_a_template( $id ) {
		$kind = self::template_kind( $id );

		if ( 'layout' === $kind ) {
			return new WP_Error(
				'fkmcp_not_found',
				sprintf( 'Id %d is a saved layout, not an email template: list-email-layouts with with_design true returns its design.', $id ),
				array( 'next' => array( array( 'tool' => 'funnelkit-list-email-layouts', 'why' => 'Saved layouts with their designs.', 'args' => array( 'with_design' => true ) ) ) )
			);
		}

		if ( 'email' === $kind ) {
			return new WP_Error( 'fkmcp_not_found', sprintf( 'Id %d is the email inside an automation step or a broadcast, not a saved template: get-automation shows an automation\'s emails, get-broadcast a broadcast\'s. Saved template ids come from list-email-templates.', $id ) );
		}

		return new WP_Error(
			'fkmcp_not_found',
			sprintf( 'No saved email template has id %d (it may have been deleted). Saved template ids come from list-email-templates.', $id ),
			array( 'next' => array( array( 'tool' => 'funnelkit-list-email-templates', 'why' => 'The saved email templates and their ids.', 'args' => (object) array() ) ) )
		);
	}

	/** 'layout', 'email' (an automation step's or a broadcast's own copy) or '' for an id with no row. */
	private static function template_kind( $id ) {
		if ( is_callable( self::$template_kind ) ) {
			return (string) call_user_func( self::$template_kind, $id );
		}

		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT canned, mode FROM {$wpdb->prefix}bwfan_templates WHERE ID = %d", $id ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one row by id, only on a refusal.

		if ( ! is_array( $row ) ) {
			return '';
		}

		return 6 === (int) $row['mode'] ? 'layout' : 'email';
	}

	/**
	 * @param int $id
	 *
	 * @return string|WP_Error The revision the template reads as now.
	 */
	private static function stored_revision( $id ) {
		$row = self::saved_row( $id );

		return is_wp_error( $row ) ? $row : self::revision( $row );
	}

	/**
	 * Settings sent with an update, over the stored ones: each key merges
	 * down to the values it names (desktop kept when only mobile is sent);
	 * a list - a font stack, say - replaces the stored one whole.
	 *
	 * @param array $stored
	 * @param array $input
	 *
	 * @return array
	 */
	private static function merge_settings( array $stored, array $input ) {
		foreach ( $input as $key => $value ) {
			$merge = is_array( $value ) && ! self::is_list( $value ) && isset( $stored[ $key ] ) && is_array( $stored[ $key ] ) && ! self::is_list( $stored[ $key ] );

			$stored[ $key ] = $merge ? self::merge_settings( $stored[ $key ], $value ) : $value;
		}

		return $stored;
	}

	/** array_is_list() for PHP 7.4; an empty array counts as one, so it replaces. */
	private static function is_list( array $value ) {
		return array() === $value || array_keys( $value ) === range( 0, count( $value ) - 1 );
	}

	/**
	 * These results skip the per-string cut every other tool gets (a design is
	 * long by nature), so the size bound is applied here instead.
	 *
	 * @param array  $result
	 * @param string $hint What to ask for instead; fewer items by default.
	 *
	 * @return array|WP_Error
	 */
	private static function within_limit( array $result, $hint = '' ) {
		$bytes = strlen( (string) wp_json_encode( $result ) );

		if ( $bytes > self::MAX_RESULT_BYTES ) {
			return new WP_Error( 'fkmcp_result_too_large', sprintf( 'The result is %d KB, over the %d KB a tool may return. %s', (int) ceil( $bytes / 1024 ), (int) ( self::MAX_RESULT_BYTES / 1024 ), '' !== $hint ? $hint : 'Ask for fewer items.' ) );
		}

		return $result;
	}
}
