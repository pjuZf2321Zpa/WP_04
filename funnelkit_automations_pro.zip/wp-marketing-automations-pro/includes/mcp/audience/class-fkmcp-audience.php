<?php

defined( 'ABSPATH' ) || exit;

/**
 * Saved audiences made and changed over MCP (create-audience / update-audience).
 *
 * The conditions go through the broadcast audience check: the contact query drops a
 * condition it cannot read, and an audience with nothing left matches everyone, so a
 * condition is stored exactly as the admin stores it or the whole call is refused.
 *
 * A status condition is refused. The broadcast engine searches its own WHERE clause for
 * "c.status" to decide whether to add its unsubscribe rules, so an audience carrying one,
 * used in a broadcast built in the admin, can reach unsubscribed contacts.
 *
 * The name is set once. The automation rule "Contact Audience" stores an audience by its
 * name, so a rename would silently break every automation that uses it.
 */
class FKMCP_Audience {
	const NAME_MAX = 100;

	const DESCRIPTION_MAX = 1000;

	const CREATE_KEYS = array( 'name', 'description', 'filters' );

	const UPDATE_KEYS = array( 'audience_id', 'description', 'filters' );

	/**
	 * The audience store, as a map so a self-check can replace it.
	 *
	 * get( int $id ): {name: string, data: array|null}|null - audiences only (type 3), data null when unreadable;
	 * by_name( string $name ): int - the id of an audience with that name, 0 for none;
	 * insert( string $name, array $data ): int - the new id, 0 on failure;
	 * update( int $id, string $name, array $data ): bool;
	 * count( array $filters ): int - contacts matching now.
	 *
	 * @var array<string, callable>
	 */
	public static $store = array(
		'get'     => array( __CLASS__, 'store_get' ),
		'by_name' => array( __CLASS__, 'store_by_name' ),
		'insert'  => array( __CLASS__, 'store_insert' ),
		'update'  => array( __CLASS__, 'store_update' ),
		'count'   => array( __CLASS__, 'store_count' ),
	);

	/**
	 * @param array $input name, filters, description?.
	 *
	 * @return array|WP_Error
	 */
	public static function create( array $input ) {
		$errors = new FKMCP_Definition_Errors();

		foreach ( array_diff( array_keys( $input ), self::CREATE_KEYS ) as $key ) {
			$errors->add( (string) $key, __( 'is not an input of this tool. Remove this key.', 'wp-marketing-automations-pro' ) );
		}

		$name        = self::checked_name( isset( $input['name'] ) ? $input['name'] : null, $errors );
		$description = array_key_exists( 'description', $input ) ? self::checked_description( $input['description'], $errors ) : '';
		$checked     = self::checked_filters( $input, $errors, true );

		if ( '' !== $name ) {
			$existing = (int) call_user_func( self::$store['by_name'], $name );
			if ( $existing > 0 ) {
				/* translators: %d: id of the audience that has this name */
				$errors->add( 'name', sprintf( __( 'An audience with this name already exists (audience_id %d). Use that one (update-audience changes its conditions), or choose another name.', 'wp-marketing-automations-pro' ), $existing ) );
			}
		}

		if ( $errors->has() || null === $checked ) {
			return self::invalid( $errors );
		}

		try {
			$count = (int) call_user_func( self::$store['count'], $checked['filters'] );
		} catch ( Throwable $e ) {
			self::log( 'AUDIENCE_COUNT_FAILED class=' . get_class( $e ) );

			return new WP_Error( 'fkmcp_create_failed', __( 'The audience could not be counted, so nothing was saved. Try again; if it fails again, create it in the admin.', 'wp-marketing-automations-pro' ) );
		}

		try {
			$id = (int) call_user_func( self::$store['insert'], $name, array( 'desc' => $description, 'filters' => $checked['filters'] ) );
		} catch ( Throwable $e ) {
			self::log( 'AUDIENCE_CREATE_FAILED class=' . get_class( $e ) );
			$id = 0;
		}

		if ( $id < 1 ) {
			return new WP_Error( 'fkmcp_create_failed', __( 'The audience could not be saved. Try again; if it fails again, create it in the admin.', 'wp-marketing-automations-pro' ) );
		}

		self::log( sprintf( 'AUDIENCE_CREATED id=%d count=%d', $id, $count ) );

		return self::result( $id, $name, $description, $checked['summary'], $count, 0 === $count ? array( self::empty_warning() ) : array() );
	}

	/**
	 * Changes the description, the conditions, or both. The name never changes.
	 *
	 * @param array $input audience_id and description and/or filters.
	 *
	 * @return array|WP_Error
	 */
	public static function update( array $input ) {
		$errors = new FKMCP_Definition_Errors();

		foreach ( array_diff( array_keys( $input ), self::UPDATE_KEYS ) as $key ) {
			$errors->add(
				(string) $key,
				'name' === $key
					? __( 'cannot be changed: the automation rule "Contact Audience" finds an audience by its name, so a rename would break every automation that uses it. Remove this key.', 'wp-marketing-automations-pro' )
					: __( 'is not an input of this tool. Remove this key.', 'wp-marketing-automations-pro' )
			);
		}

		$id = isset( $input['audience_id'] ) ? $input['audience_id'] : null;
		if ( ! ( is_int( $id ) || ( is_string( $id ) && ctype_digit( $id ) ) ) || (int) $id < 1 ) {
			$errors->add( 'audience_id', __( 'must be a positive integer. Call list-audiences for valid ids.', 'wp-marketing-automations-pro' ) );
			$id = 0;
		}
		$id = (int) $id;

		$changed = array_values( array_intersect( array( 'description', 'filters' ), array_keys( $input ) ) );
		if ( array() === $changed ) {
			$errors->add( 'audience_id', __( 'Nothing to change: send description, filters, or both.', 'wp-marketing-automations-pro' ) );
		}

		$description = in_array( 'description', $changed, true ) ? self::checked_description( $input['description'], $errors ) : null;
		$checked     = in_array( 'filters', $changed, true ) ? self::checked_filters( $input, $errors, false ) : null;

		$row = null;
		if ( $id > 0 ) {
			$row = call_user_func( self::$store['get'], $id );
			if ( ! is_array( $row ) ) {
				$errors->add( 'audience_id', __( 'No saved audience with that id. Call list-audiences for valid ids.', 'wp-marketing-automations-pro' ) );
			} elseif ( ! is_array( $row['data'] ) ) {
				$errors->add( 'audience_id', __( 'This audience is stored in a format that cannot be read here. Change it in the admin.', 'wp-marketing-automations-pro' ) );
			}
		}

		if ( $errors->has() ) {
			return self::invalid( $errors );
		}

		$data = $row['data'];
		if ( null !== $description ) {
			$data['desc'] = $description;
		}

		$count    = null;
		$warnings = array();
		if ( null !== $checked ) {
			$data['filters'] = $checked['filters'];

			try {
				$count = (int) call_user_func( self::$store['count'], $checked['filters'] );
			} catch ( Throwable $e ) {
				self::log( 'AUDIENCE_COUNT_FAILED class=' . get_class( $e ) );

				return new WP_Error( 'fkmcp_update_failed', __( 'The new conditions could not be counted, so nothing was saved. Try again; if it fails again, change the audience in the admin.', 'wp-marketing-automations-pro' ) );
			}

			$warnings[] = __( 'Automations that use this audience in a "Contact Audience" rule follow the new conditions from now on.', 'wp-marketing-automations-pro' );
			if ( 0 === $count ) {
				$warnings[] = self::empty_warning();
			}
		}

		try {
			$saved = (bool) call_user_func( self::$store['update'], $id, (string) $row['name'], $data );
		} catch ( Throwable $e ) {
			self::log( 'AUDIENCE_UPDATE_FAILED class=' . get_class( $e ) );
			$saved = false;
		}

		if ( ! $saved ) {
			return new WP_Error( 'fkmcp_update_failed', __( 'The audience could not be saved. Nothing was changed. Try again; if it fails again, change it in the admin.', 'wp-marketing-automations-pro' ) );
		}

		self::log( sprintf( 'AUDIENCE_UPDATED id=%d changed=%s', $id, implode( ',', $changed ) ) );

		$result            = self::result( $id, (string) $row['name'], isset( $data['desc'] ) && is_string( $data['desc'] ) ? $data['desc'] : '', null === $checked ? null : $checked['summary'], $count, $warnings );
		$result['changed'] = $changed;

		return $result;
	}

	/** @return string The name, or '' after an error. */
	private static function checked_name( $value, FKMCP_Definition_Errors $errors ) {
		$name = is_string( $value ) ? trim( $value ) : '';

		if ( '' === $name || '0' === $name || mb_strlen( $name ) > self::NAME_MAX || sanitize_text_field( $name ) !== $name ) {
			$errors->add( 'name', __( 'is required, at most 100 characters, and not just "0". Use plain text: single spaces, no HTML, no % codes.', 'wp-marketing-automations-pro' ) );

			return '';
		}

		return $name;
	}

	/** @return string The description, or '' after an error. */
	private static function checked_description( $value, FKMCP_Definition_Errors $errors ) {
		$description = is_string( $value ) ? trim( $value ) : null;

		if ( null === $description || mb_strlen( $description ) > self::DESCRIPTION_MAX || sanitize_textarea_field( $description ) !== $description ) {
			$errors->add( 'description', __( 'must be at most 1000 characters. Use plain text: no HTML, no % codes. Send "" to clear it.', 'wp-marketing-automations-pro' ) );

			return '';
		}

		return $description;
	}

	/** @return array{filters: array, summary: string[]}|null */
	private static function checked_filters( array $input, FKMCP_Definition_Errors $errors, $required ) {
		if ( ! array_key_exists( 'filters', $input ) || array() === $input['filters'] ) {
			if ( $required || array_key_exists( 'filters', $input ) ) {
				$errors->add( 'filters', __( 'is required: at least one group with one condition. An audience without conditions would match every contact.', 'wp-marketing-automations-pro' ) );
			}

			return null;
		}

		return FKMCP_Broadcast_Audience::validate_for_audience(
			$input['filters'],
			'filters',
			$errors,
			__( 'status cannot be set in an audience made here: a status condition switches off the unsubscribe rules of a broadcast that uses the audience. Build status-based audiences in the admin.', 'wp-marketing-automations-pro' )
		);
	}

	private static function empty_warning() {
		return __( 'No contact matches these conditions yet. The audience is saved and includes contacts as soon as they match.', 'wp-marketing-automations-pro' );
	}

	private static function result( $id, $name, $description, $summary, $count, array $warnings ) {
		return array(
			'audience_id' => $id,
			'name'        => FKMCP_Definition_Errors::untrust( $name ),
			'description' => FKMCP_Definition_Errors::untrust( $description ),
			'summary'     => $summary,
			'count'       => $count,
			'warnings'    => $warnings,
			'edit_url'    => BWFAN_MCP_Links::app( 'autonami', '/contacts' ) . '&audience_id=' . $id,
			'next_step'   => 'Tell the user the audience is saved, with its summary and count. It can be used in a broadcast (create-broadcast audience_id) and listed with filter-contacts audience_id.',
		);
	}

	private static function invalid( FKMCP_Definition_Errors $errors ) {
		$error = $errors->to_wp_error();
		$data  = $error->get_error_data();
		$total = count( $data['errors'] ) + (int) $data['more'];
		$lines = explode( "\n", $error->get_error_message(), 2 );

		return new WP_Error(
			'fkmcp_invalid_input',
			/* translators: %d: number of problems found in the input */
			sprintf( _n( 'The audience has %d problem. Nothing was saved.', 'The audience has %d problems. Nothing was saved.', $total, 'wp-marketing-automations-pro' ), $total ) . ( isset( $lines[1] ) ? "\n" . $lines[1] : '' ),
			$data
		);
	}

	private static function log( $line ) {
		if ( class_exists( 'BWFAN_MCP_Log' ) ) {
			BWFAN_MCP_Log::event( $line );
		}
	}

	/** By type as well as id: tags and lists live in the same table, and BWFCRM_Audience does not check the type. */
	public static function store_get( $id ) {
		$rows = BWFAN_Model_Terms::get_terms( 3, 0, 1, '', array( (int) $id ) );
		$row  = is_array( $rows ) && $rows ? reset( $rows ) : null;
		if ( ! is_array( $row ) || ! isset( $row['ID'] ) || (int) $row['ID'] !== (int) $id ) {
			return null;
		}

		$data = BWFAN_PRO_Common::decode_stored_data_column( isset( $row['data'] ) ? $row['data'] : null );

		return array(
			'name' => isset( $row['name'] ) ? (string) $row['name'] : '',
			'data' => is_array( $data ) ? $data : null,
		);
	}

	/** The rule lookup is the same LIKE, so a name it would confuse with this one counts as taken. */
	public static function store_by_name( $name ) {
		$row = BWFAN_Model_Terms::get_term_by_name( $name, 3 );

		return is_array( $row ) && isset( $row['ID'] ) ? (int) $row['ID'] : 0;
	}

	public static function store_insert( $name, array $data ) {
		$now      = current_time( 'mysql', 1 );
		$audience = new BWFCRM_Audience();
		$audience->set_audience( 0, $name, $data, $now, $now );

		return (int) $audience->save();
	}

	public static function store_update( $id, $name, array $data ) {
		$audience = new BWFCRM_Audience( $id );
		$audience->set_audience( $id, $name, $data, '', current_time( 'mysql', 1 ) );

		return $audience->save() === (int) $id;
	}

	/** The count the admin's audience list shows. */
	public static function store_count( array $filters ) {
		BWFCRM_Load_Filters::maybe_load_filters();

		$res = BWFCRM_Model_Contact::get_contacts_from_filters( '', '', '', $filters, array( 'grab_totals' => true, 'only_count' => true, 'customer_data' => false ) );

		return is_array( $res ) && isset( $res['total'] ) ? (int) $res['total'] : 0;
	}
}
