<?php
#[AllowDynamicProperties]
class BWFAN_Pro_WooFunnels_Support {

	public static $_instance = null;
	public $full_name = '';
	public $is_license_needed = true;
	/**
	 * @var WooFunnels_License_check
	 */
	public $license_instance;
	/**
	 * Whether init_licensing() has already run this request, successfully or not.
	 *
	 * @var bool
	 */
	protected $licensing_initialised = false;
	protected $slug = 'autonami-automations-pro';
	protected $encoded_basename = '';

	private function __construct() {
		$this->full_name        = BWFAN_PRO_FULL_NAME;
		$this->encoded_basename = sha1( BWFAN_PRO_PLUGIN_BASENAME );

		add_filter( 'woofunnels_plugins_license_needed', array( $this, 'add_license_support' ), 10 );
		/**
		 * init_licensing wires the plugin updater (pre_set_site_transient_update_plugins /
		 * plugins_api) and sets license_instance for the admin license form. Those run in admin,
		 * cron (daily update + license check) and WP-CLI only — never a frontend page view.
		 *
		 * What the gate saves is the WORK, not a file load: constructing
		 * WooFunnels_License_check, WooFunnels_License_check::get_plugins() (an option read
		 * plus unserialize), setup_data() and start_updater() on every frontend request.
		 * The class itself ships with this plugin (includes/license/, lazy-autoloaded; the
		 * free core and Funnel Builder Pro carry class_exists()-guarded copies of the same
		 * files), so it is always resolvable — the class_exists() guard inside
		 * init_licensing() only matters on a build where that folder is missing. Do not
		 * "fix" this by checking whether the class is loaded on the frontend; it will be,
		 * and that is not what this gate is for.
		 *
		 * Contexts outside this gate (the REST license route, most notably) must go through
		 * get_license_instance(), which initialises on demand.
		 */
		if ( is_admin() || wp_doing_cron() || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
			add_action( 'init', array( $this, 'init_licensing' ), 12 );
		}
		add_action( 'woofunnels_licenses_submitted', array( $this, 'process_licensing_form' ) );
		add_action( 'woofunnels_deactivate_request', array( $this, 'maybe_process_deactivation' ) );

		if ( ! wp_next_scheduled( 'woofunnels_bwfan_license_check' ) ) {
			wp_schedule_event( time(), 'daily', 'woofunnels_bwfan_license_check' );
		}

		add_action( 'woofunnels_bwfan_license_check', array( $this, 'license_check' ) );
		add_filter( 'woofunnels_default_reason_' . BWFAN_PRO_PLUGIN_BASENAME, function () {
			return 1;
		} );

		add_filter( 'woofunnels_default_reason_default', function () {
			return 1;
		} );
		add_filter( 'woofunnels_register_usage_collectors', array( $this, 'maybe_add_registery' ), 55, 1 );

	}

	/**
	 * @return BWFAN_Pro_WooFunnels_Support
	 */
	public static function get_instance() {
		if ( null === self::$_instance ) {
			self::$_instance = new self;
		}

		return self::$_instance;
	}

	public function woofunnels_page() {
		if ( ! isset( $_GET['tab'] ) ) { // WordPress.CSRF.NonceVerification.NoNonceVerification
			WooFunnels_dashboard::$selected = 'licenses';
		}
		WooFunnels_dashboard::load_page();
	}

	/**
	 * Adding WooCommerce sub-menu for global options
	 */
	public function add_menus() {
		if ( true === WooFunnels_dashboard::$is_core_menu ) {
			return;
		}

		add_menu_page( __( 'WooFunnels', 'woofunnels' ), __( 'WooFunnels', 'woofunnels' ), 'manage_options', 'woofunnels', array( $this, 'woofunnels_page' ), '', 59 );
		add_submenu_page( 'woofunnels', __( 'Licenses', 'woofunnels' ), __( 'License', 'woofunnels' ), 'manage_options', 'woofunnels' );
		WooFunnels_dashboard::$is_core_menu = true;
	}

	/**
	 * License management helper function to create a slug that is friendly with edd
	 *
	 * @param  $name
	 *
	 * @return String
	 */
	public function slugify_module_name( $name ) {
		return preg_replace( '/[^a-zA-Z0-9_\s]/', '', str_replace( ' ', '_', strtolower( $name ) ) );
	}

	public function add_license_support( $plugins ) {
		$status  = 'invalid';
		$renew   = 'Please Activate';
		$license = array(
			'key'     => '',
			'email'   => '',
			'expires' => '',
		);

		$plugins_in_database = WooFunnels_License_check::get_plugins();

		if ( is_array( $plugins_in_database ) && isset( $plugins_in_database[ $this->encoded_basename ] ) && count( $plugins_in_database[ $this->encoded_basename ] ) > 0 ) {
			$status  = 'active';
			$renew   = '';
			$license = array(
				'key'     => $plugins_in_database[ $this->encoded_basename ]['data_extra']['api_key'] ?? '',
				'email'   => $plugins_in_database[ $this->encoded_basename ]['data_extra']['license_email'] ?? '',
				'expires' => $plugins_in_database[ $this->encoded_basename ]['data_extra']['expires'] ?? '',
			);
		}

		$plugins[ $this->encoded_basename ] = array(
			'plugin'            => $this->full_name,
			'product_version'   => BWFAN_PRO_VERSION,
			'product_status'    => $status,
			'license_expiry'    => $renew,
			'product_file_path' => $this->encoded_basename,
			'existing_key'      => $license,
		);

		return $plugins;
	}

	public function woofunnels_slugify_module_name( $name ) {
		return preg_replace( '/[^a-zA-Z0-9_\s]/', '', str_replace( ' ', '_', strtolower( $name ) ) );
	}

	public function init_licensing() {
		$this->licensing_initialised = true;

		if ( class_exists( 'WooFunnels_License_check' ) && $this->is_license_needed ) {
			$this->license_instance = new WooFunnels_License_check( $this->encoded_basename );

			$plugins = WooFunnels_License_check::get_plugins();
			if ( isset( $plugins[ $this->encoded_basename ] ) && count( $plugins[ $this->encoded_basename ] ) > 0 ) {
				$data = array(
					'plugin_slug' => BWFAN_PRO_PLUGIN_BASENAME,
					'plugin_name' => BWFAN_PRO_FULL_NAME,
					'license_key' => $plugins[ $this->encoded_basename ]['data_extra']['api_key'] ?? '',
					'product_id'  => $this->full_name,
					'version'     => BWFAN_PRO_VERSION,
				);
				$this->license_instance->setup_data( $data );
				$this->license_instance->start_updater();
			}
		}
	}

	/**
	 * Resolve the license instance, initialising it on demand.
	 *
	 * init_licensing() is only hooked in admin, cron and WP-CLI. Every other context — the REST
	 * license route being the one that matters — reaches these methods with a null instance, so
	 * resolve lazily here instead of dereferencing null.
	 *
	 * @return WooFunnels_License_check|null
	 */
	public function get_license_instance() {
		/**
		 * Initialise at most once. Where licensing is genuinely unavailable —
		 * WooFunnels_License_check missing, or is_license_needed false — retrying
		 * would re-enter the whole setup on every caller for no gain.
		 */
		if ( ! $this->licensing_initialised && ! $this->license_instance instanceof WooFunnels_License_check ) {
			$this->init_licensing();
		}

		return $this->license_instance instanceof WooFunnels_License_check ? $this->license_instance : null;
	}

	/**
	 * Error payload for callers that expect the WooFunnels license response shape.
	 *
	 * @return array
	 */
	protected function license_unavailable_response() {
		return array(
			'error' => __( 'Licensing is unavailable on this site. Please reload the page and try again.', 'wp-marketing-automations-pro' ),
		);
	}

	public function process_licensing_form( $posted_data ) {
		$license = $this->get_license_instance();
		if ( null === $license ) {
			return;
		}

		if ( isset( $posted_data['license_keys'][ $this->encoded_basename ] ) ) {
			$key  = $posted_data['license_keys'][ $this->encoded_basename ]['key'];
			$data = array(
				'plugin_slug' => BWFAN_PRO_PLUGIN_BASENAME,
				'plugin_name' => BWFAN_PRO_FULL_NAME,
				'license_key' => $key,
				'product_id'  => $this->full_name,
				'version'     => BWFAN_PRO_VERSION,
			);
			$license->setup_data( $data );
			$license->activate_license();
		}
	}

	/**
	 * Validate is it is for email product deactivation
	 *
	 * @param  $posted_data
	 */
	public function maybe_process_deactivation( $posted_data ) {
		$license = $this->get_license_instance();
		if ( null === $license ) {
			return;
		}

		if ( isset( $posted_data['filepath'] ) && $posted_data['filepath'] === $this->encoded_basename ) {
			$plugins = WooFunnels_License_check::get_plugins();

			if ( isset( $plugins[ $this->encoded_basename ] ) && count( $plugins[ $this->encoded_basename ] ) > 0 ) {
				$data = array(
					'plugin_slug' => BWFAN_PRO_PLUGIN_BASENAME,
					'plugin_name' => BWFAN_PRO_FULL_NAME,
					'license_key' => $plugins[ $this->encoded_basename ]['data_extra']['api_key'] ?? '',
					'product_id'  => $this->full_name,
					'version'     => BWFAN_PRO_VERSION,
				);
				$license->setup_data( $data );
				$license->deactivate_license();
				wp_safe_redirect( 'admin.php?page=' . $posted_data['page'] . '&tab=' . $posted_data['tab'] );
			}
		}
	}

	public function process_activation_api( $key ) {
		$license = $this->get_license_instance();
		if ( null === $license ) {
			return $this->license_unavailable_response();
		}

		$data = array(
			'plugin_slug' => BWFAN_PRO_PLUGIN_BASENAME,
			'plugin_name' => BWFAN_PRO_FULL_NAME,
			'license_key' => $key,
			'product_id'  => $this->full_name,
			'version'     => BWFAN_PRO_VERSION,
		);
		BWFAN_Common::log_test_data( $data, 'bwfan-license' );
		$license->setup_data( $data );

		$resp = $license->activate_license();
		BWFAN_Common::log_test_data( $resp, 'bwfan-license' );

		return $resp;
	}

	public function process_deactivation_api() {
		$license = $this->get_license_instance();
		if ( null === $license ) {
			return $this->license_unavailable_response();
		}

		$plugins = WooFunnels_License_check::get_plugins();
		$data    = array(
			'plugin_slug' => BWFAN_PRO_PLUGIN_BASENAME,
			'plugin_name' => BWFAN_PRO_FULL_NAME,
			'license_key' => $plugins[ $this->encoded_basename ]['data_extra']['api_key'] ?? '',
			'product_id'  => $this->full_name,
			'version'     => BWFAN_PRO_VERSION,
		);
		BWFAN_Common::log_test_data( $data, 'bwfan-license' );
		$license->setup_data( $data );

		$resp = $license->deactivate_license();
		BWFAN_Common::log_test_data( $resp, 'bwfan-license' );

		return $resp;
	}

	public function license_check() {
		$license = $this->get_license_instance();
		if ( null === $license ) {
			return;
		}

		$plugins = WooFunnels_License_check::get_plugins();
		if ( isset( $plugins[ $this->encoded_basename ] ) && count( $plugins[ $this->encoded_basename ] ) > 0 ) {
			$data = array(
				'plugin_slug' => BWFAN_PRO_PLUGIN_BASENAME,
				'license_key' => $plugins[ $this->encoded_basename ]['data_extra']['api_key'] ?? '',
				'product_id'  => $this->full_name,
				'version'     => BWFAN_PRO_VERSION,
			);
			$license->setup_data( $data );
			$license->license_status();
		}
	}

	public function is_license_present() {
		$plugins = WooFunnels_License_check::get_plugins();

		if ( ! isset( $plugins[ $this->encoded_basename ] ) ) {
			return false;
		}

		return true;

	}

	public function maybe_add_registery( $collectors ) {
		/**
		 * Load usage collector (lazy registration via filter hook)
		 */
		// Load the usage collector class if it doesn't exist yet
		if ( ! class_exists( 'BWFANCRM_Usage_Collector' ) && file_exists( BWFAN_PRO_PLUGIN_DIR . '/includes/usage/class-bwfancrm-usage-collector.php' ) ) {
			require_once BWFAN_PRO_PLUGIN_DIR . '/includes/usage/class-bwfancrm-usage-collector.php';
		}

		// Register with registry if class exists
		if ( class_exists( 'BWFANCRM_Usage_Collector' ) ) {
			return BWFANCRM_Usage_Collector::add_to_registry( $collectors );
		}

		// Backward compatibility: Also check for old tracking collector class
		// Load the tracking collector class if it doesn't exist yet
		if ( ! class_exists( 'BWFANCRM_Usage_Collector' ) && ! class_exists( 'BWFANCRM_Tracking_Collector' ) && file_exists( BWFAN_PRO_PLUGIN_DIR . '/includes/tracking/class-bwfancrm-tracking-collector.php' ) ) {
			require_once BWFAN_PRO_PLUGIN_DIR . '/includes/tracking/class-bwfancrm-tracking-collector.php';
		}

		// Register tracking collector with registry if class exists
		if ( ! class_exists( 'BWFANCRM_Usage_Collector' ) && class_exists( 'BWFANCRM_Tracking_Collector' ) ) {
			return BWFANCRM_Tracking_Collector::add_to_registry( $collectors );
		}

		return $collectors;
	}

}

BWFAN_Pro_WooFunnels_Support::get_instance();
