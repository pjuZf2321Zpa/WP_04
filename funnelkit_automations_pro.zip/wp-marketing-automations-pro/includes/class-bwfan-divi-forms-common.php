<?php
/**
 * Divi Contact Form discovery (Divi 4 shortcodes + Divi 5 blocks).
 *
 * @package Autonami
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

#[\AllowDynamicProperties]
class BWFAN_Divi_Forms_Common {

	/** @var array|null */
	private static $extract_cache = null;

	/**
	 * @return array Form composite id => [ 'title' => string, 'fields' => array ].
	 */
	public static function extract_forms_and_fields() {
		if ( null !== self::$extract_cache ) {
			return self::$extract_cache;
		}

		global $wpdb;

		$d4  = '%' . $wpdb->esc_like( 'et_pb_contact_form' ) . '%';
		$d5  = '%' . $wpdb->esc_like( 'divi/contact-form' ) . '%';
		$d5e = '%' . $wpdb->esc_like( 'divi\/contact-form' ) . '%';

		$query = $wpdb->prepare( "SELECT ID, post_content, post_title, post_type FROM {$wpdb->posts}
			WHERE post_status NOT IN ('trash','inherit','auto-draft')
			AND post_type IS NOT NULL AND post_type NOT LIKE %s
			AND ( post_content LIKE %s OR post_content LIKE %s OR post_content LIKE %s )", 'revision', $d4, $d5, $d5e );

		$rows = $wpdb->get_results( $query ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$data = array();

		if ( ! empty( $rows ) ) {
			foreach ( $rows as $row ) {
				$data = array_replace( $data, self::extract_classic_forms_from_post( $row ) );
				$data = array_replace( $data, self::extract_divi5_forms_from_post( $row ) );
			}
		}

		self::$extract_cache = $data;

		return $data;
	}

	/**
	 * @param object $p wp_posts row.
	 *
	 * @return array
	 */
	private static function extract_classic_forms_from_post( $p ) {
		$out = array();
		if ( false === strpos( $p->post_content, 'et_pb_contact_form' ) ) {
			return $out;
		}

		if ( ! preg_match_all( '/\[et_pb_contact_form(.*?)](.+?)\[\/et_pb_contact_form]/', $p->post_content, $forms, PREG_SET_ORDER ) ) {
			return $out;
		}

		$rx = get_shortcode_regex( array( 'et_pb_contact_form' ) );
		foreach ( $forms as $form_number => $form ) {
			if ( ! preg_match_all( "/$rx/", $form[0], $extracted, PREG_SET_ORDER ) ) {
				continue;
			}
			foreach ( $extracted as $ex ) {
				$atts = shortcode_parse_atts( $ex[3] );
				if ( empty( $atts['_unique_id'] ) ) {
					continue;
				}
				$fid   = sprintf( '%d-%s-%s', $p->ID, $atts['_unique_id'], $form_number );
				$title = isset( $atts['title'] ) ? $atts['title'] : __( 'No form title', 'wp-marketing-automations-pro' );

				$out[ $fid ] = array(
					'title'  => sprintf( '%s - %s', $p->post_title, $title ),
					'fields' => self::extract_form_fields( $form[0] ),
				);
			}
		}

		return $out;
	}

	/**
	 * @param object $p wp_posts row.
	 *
	 * @return array
	 */
	private static function extract_divi5_forms_from_post( $p ) {
		$c = $p->post_content;
		if ( false === strpos( $c, 'divi/contact-form' ) && false === strpos( $c, 'divi\/contact-form' ) ) {
			return array();
		}
		if ( ! function_exists( 'parse_blocks' ) ) {
			return array();
		}

		$layout = ( function_exists( 'et_theme_builder_is_layout_post_type' ) && et_theme_builder_is_layout_post_type( $p->post_type ) ) ? $p->post_type : 'default';

		if ( class_exists( 'ET_Builder_Module_Order' ) ) {
			ET_Builder_Module_Order::reset_indexes( $layout );
		}

		$blocks = parse_blocks( $c );
		if ( empty( $blocks ) ) {
			return array();
		}

		$out          = array();
		$order_manual = array();
		self::walk_divi5_blocks( $blocks, $p, $layout, $out, $order_manual );

		return $out;
	}

	/**
	 * @param array $blocks Parsed blocks.
	 * @param object $p Post row.
	 * @param string $layout Layout type for ET_Builder_Module_Order.
	 * @param array $out Output map by ref.
	 * @param array $order_manual Per-post order when ET_Builder_Module_Order is missing (by ref).
	 */
	private static function walk_divi5_blocks( array $blocks, $p, $layout, array &$out, array &$order_manual ) {
		foreach ( $blocks as $block ) {
			$name = isset( $block['blockName'] ) ? $block['blockName'] : '';
			if ( 'divi/contact-form' === $name ) {
				$attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();

				if ( class_exists( 'ET_Builder_Module_Order' ) ) {
					$order = ET_Builder_Module_Order::increment_index( ET_Builder_Module_Order::INDEX_MODULE_ORDER, 'et_pb_contact_form', $layout );
				} else {
					$key = $layout . ':' . $p->ID;
					if ( ! isset( $order_manual[ $key ] ) ) {
						$order_manual[ $key ] = - 1;
					}
					$order = (int) ++ $order_manual[ $key ];
				}

				$synth = array(
					'orderIndex'  => $order,
					'id'          => 'divi/contact-form-' . $order,
					'layout_type' => $layout,
				);

				if ( class_exists( '\ET\Builder\Packages\ModuleLibrary\ContactForm\ContactFormUtils' ) ) {
					$uid = \ET\Builder\Packages\ModuleLibrary\ContactForm\ContactFormUtils::get_unique_id( $attrs, $synth );
				} else {
					$uid = self::array_get( $attrs, 'module.advanced.uniqueId.desktop.value', '' );
					if ( '' === $uid ) {
						$uid = md5( $layout . '--' . $synth['id'] . '--' . $order );
					}
				}

				$fid = $p->ID . '-' . $uid . '-' . $order;

				$t = self::array_get( $attrs, 'title.innerContent.desktop.value', '' );
				$t = self::d5_attr_to_string( $t );
				$t = '' !== $t ? wp_strip_all_tags( $t ) : __( 'No form title', 'wp-marketing-automations-pro' );

				$out[ $fid ] = array(
					'title'  => sprintf( '%s - %s', $p->post_title, $t ),
					'fields' => self::collect_divi5_fields_deep( $block ),
				);
			}

			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				self::walk_divi5_blocks( $block['innerBlocks'], $p, $layout, $out, $order_manual );
			}
		}
	}

	/**
	 * All divi/contact-field modules under a contact form (any nesting depth).
	 *
	 * @param array $form_block divi/contact-form parsed block.
	 *
	 * @return array
	 */
	private static function collect_divi5_fields_deep( array $form_block ) {
		$list = array();
		if ( empty( $form_block['innerBlocks'] ) || ! is_array( $form_block['innerBlocks'] ) ) {
			return $list;
		}
		self::collect_divi5_fields_walker( $form_block['innerBlocks'], $list );

		return $list;
	}

	/**
	 * @param array $blocks Inner blocks subtree.
	 * @param array $list Accumulated fields (by ref).
	 */
	private static function collect_divi5_fields_walker( array $blocks, array &$list ) {
		foreach ( $blocks as $b ) {
			$name = isset( $b['blockName'] ) ? $b['blockName'] : '';
			if ( 'divi/contact-field' === $name ) {
				$fa = isset( $b['attrs'] ) && is_array( $b['attrs'] ) ? $b['attrs'] : array();

				$type = self::array_get( $fa, 'fieldItem.advanced.type.desktop.value', 'input' );
				if ( 'hidden' === $type ) {
					continue;
				}

				$fid = strtolower( (string) self::d5_field_id_from_attrs( $fa ) );
				if ( '' === $fid ) {
					continue;
				}

				$label = self::array_get( $fa, 'fieldItem.innerContent.desktop.value', '' );
				$label = self::d5_attr_to_string( $label );
				if ( '' === trim( (string) $label ) ) {
					$label = __( 'New Field', 'wp-marketing-automations-pro' );
				}

				$list[] = array(
					'field_title' => $label,
					'field_id'    => $fid,
					'field_type'  => $type,
				);
			}
			if ( ! empty( $b['innerBlocks'] ) && is_array( $b['innerBlocks'] ) ) {
				self::collect_divi5_fields_walker( $b['innerBlocks'], $list );
			}
		}
	}

	/**
	 * Field id from attrs (handles minor attribute shape differences).
	 *
	 * @param array $fa Block attrs.
	 *
	 * @return string
	 */
	private static function d5_field_id_from_attrs( array $fa ) {
		$id = self::array_get( $fa, 'fieldItem.advanced.id.desktop.value', '' );
		if ( '' !== $id ) {
			return (string) $id;
		}
		$item = isset( $fa['fieldItem']['advanced']['id'] ) && is_array( $fa['fieldItem']['advanced']['id'] ) ? $fa['fieldItem']['advanced']['id'] : array();
		foreach ( array( 'desktop', 'tablet', 'phone' ) as $bp ) {
			if ( ! empty( $item[ $bp ]['value'] ) ) {
				return (string) $item[ $bp ]['value'];
			}
		}

		return '';
	}

	/**
	 * @param mixed $v Divi innerContent value (string or nested array).
	 *
	 * @return string
	 */
	private static function d5_attr_to_string( $v ) {
		if ( is_string( $v ) ) {
			return $v;
		}
		if ( ! is_array( $v ) ) {
			return '';
		}
		if ( isset( $v['text'] ) && is_string( $v['text'] ) ) {
			return $v['text'];
		}
		foreach ( $v as $x ) {
			if ( is_string( $x ) && '' !== trim( $x ) ) {
				return $x;
			}
			if ( is_array( $x ) ) {
				$s = self::d5_attr_to_string( $x );
				if ( '' !== trim( $s ) ) {
					return $s;
				}
			}
		}

		return '';
	}

	/**
	 * @param string $content_shortcode Form shortcode fragment (Divi 4).
	 *
	 * @return array
	 */
	public static function extract_form_fields( $content_shortcode ) {
		$fields  = array();
		$pattern = get_shortcode_regex( array( 'et_pb_contact_field' ) );
		if ( ! preg_match_all( "/$pattern/", $content_shortcode, $found, PREG_SET_ORDER ) ) {
			return $fields;
		}
		foreach ( $found as $row ) {
			$a        = shortcode_parse_atts( $row[3] );
			$fields[] = array(
				'field_title' => self::array_get( $a, 'field_title', __( 'No title', 'wp-marketing-automations-pro' ) ),
				'field_id'    => strtolower( self::array_get( $a, 'field_id' ) ),
				'field_type'  => self::array_get( $a, 'field_type', 'text' ),
			);
		}

		return $fields;
	}

	/**
	 * @param array $array Source.
	 * @param string|array $address Dot path.
	 * @param mixed $default Default.
	 *
	 * @return mixed
	 */
	public static function array_get( $array, $address, $default = '' ) {
		$keys  = is_array( $address ) ? $address : explode( '.', $address );
		$value = $array;
		foreach ( $keys as $key ) {
			if ( ! empty( $key ) && isset( $key[0] ) && '[' === $key[0] ) {
				$index = substr( $key, 1, - 1 );
				$key   = is_numeric( $index ) ? (int) $index : $index;
			}
			if ( ! is_array( $value ) || ! isset( $value[ $key ] ) ) {
				return $default;
			}
			$value = $value[ $key ];
		}

		return $value;
	}

	/**
	 * @param string $form_id Composite id.
	 *
	 * @return string Unique portion for global-form matching.
	 */
	public static function extract_unique_form_id( $form_id ) {
		if ( false === strpos( $form_id, '-' ) ) {
			return $form_id;
		}
		$form_unique_id = explode( '-', $form_id );
		/** Remove form number */
		array_pop( $form_unique_id );
		/** Remove post id */
		array_shift( $form_unique_id );

		return implode( '-', $form_unique_id );
	}

}
