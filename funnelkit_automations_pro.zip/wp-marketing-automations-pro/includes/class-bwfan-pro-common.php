<?php

#[AllowDynamicProperties]
class BWFAN_PRO_Common {

	public static $crm_default_fields = [
		'address-1' => [
			'name'  => 'Address 1',
			'type'  => 1,
			'mode'  => 2,
			'vmode' => 1,
			'view'  => 2,
			'meta'  => [],
		],
		'address-2' => [
			'name'  => 'Address 2',
			'type'  => 1,
			'mode'  => 2,
			'vmode' => 1,
			'view'  => 2,
			'meta'  => []
		],
		'city'      => [
			'name'  => 'City',
			'type'  => 1,
			'mode'  => 2,
			'vmode' => 1,
			'view'  => 2,
			'meta'  => []
		],
		'postcode'  => [
			'name'  => 'Pincode',
			'type'  => 1,
			'mode'  => 2,
			'vmode' => 1,
			'view'  => 2,
			'meta'  => []
		],
		'company'   => [
			'name'  => 'Company',
			'type'  => 1,
			'mode'  => 2,
			'vmode' => 1,
			'view'  => 2,
			'meta'  => []
		],
		'gender'    => [
			'name'  => 'Gender',
			'type'  => 4,
			'mode'  => 2,
			'vmode' => 1,
			'view'  => 2,
			'meta'  => [ 'options' => [ 'Male', 'Female', 'Other' ] ]
		],
		'dob'       => [
			'name'  => 'Date of Birth',
			'type'  => 7,
			'mode'  => 2,
			'vmode' => 1,
			'view'  => 2,
			'meta'  => []
		]
	];

	public static $upstroke_funnels = null;
	public static $upstroke_offers = null;

	public static $show_tags_list_by_name = null;

	public static $unsubscribe_page_link = '';

	public static function init() {
		register_deactivation_hook( BWFAN_PRO_PLUGIN_FILE, array( __CLASS__, 'deactivation' ) );

		add_action( 'admin_init', array( __CLASS__, 'schedule_cron' ) );

		add_action( 'bwfan_run_midnight_cron', array( __CLASS__, 'run_midnight_cron' ) );
		add_action( 'bwfan_delete_engagement_meta_records', array( __CLASS__, 'delete_engagement_tracking_meta' ) );
		add_action( 'bwfan_automation_saved', array( __CLASS__, 'schedule_time_async_events' ) );
		add_action( 'bwfan_run_independent_automation', array( __CLASS__, 'make_independent_events_tasks' ) );
		add_action( 'bwfan_delete_unscheduled_broadcast_data', array( __CLASS__, 'delete_engagements' ), 10, 1 );

		add_filter( 'bwfan_select2_ajax_callable', array( __CLASS__, 'get_callable_object' ), 1, 2 );

		add_filter( 'bwfan_send_async_call_data', array( __CLASS__, 'passing_event_language' ), 10, 1 );

		/** Send test data to zapier zap */
		add_action( 'wp_ajax_bwf_test_zap', array( __CLASS__, 'test_zap' ) );
		/** send test data to pabbly */
		add_action( 'wp_ajax_bwf_test_pabbly', array( __CLASS__, 'test_pabbly' ) );

		/** Send test data to zapier zap */
		add_action( 'wp_ajax_bwf_send_test_http_post', array( __CLASS__, 'send_test_http_post' ) );

		/** Delete automation tasks after paid order */
		add_action( 'bwf_normalize_contact_meta_before_save', array( __CLASS__, 'delete_automation_tasks_by_automation_ids' ), PHP_INT_MAX, 2 );

		/** 5 min action callback */
		add_action( 'bwfan_5_minute_worker', array( __CLASS__, 'five_minute_worker_cb' ) );

		/** populate cart from order **/
		add_action( 'wp_loaded', array( __CLASS__, 'bwfan_populate_cart_from_order' ), 30 );

		add_filter( 'bwfan_get_form_submit_events', array( __CLASS__, 'get_form_submit_events' ), 10, 1 );

		add_filter( 'bwfan_automation_tables', array( __CLASS__, 'bwfan_added_pro_tables' ), 10, 1 );

		add_action( 'bwfan_check_conversion_validity', [ __CLASS__, 'bwfan_delete_invalid_conversions' ], 10 );

		/** Ajax call to save email template */
		add_action( 'wp_ajax_bwf_save_email_template', array( __CLASS__, 'bwf_save_email_template' ) );

		/** Display email content in browser */
		add_action( 'wp', [ __CLASS__, 'load_view_in_browser_link_content' ] );

		/** Admin bar "Search Contact" toggle on Settings → Tools */
		add_filter( 'bwfan_global_tools_settings', array( __CLASS__, 'add_admin_bar_search_tool' ) );
		add_filter( 'bwfan_run_global_tool_toggle_admin_bar_search', array( __CLASS__, 'save_admin_bar_search_tool' ), 10, 2 );

		/** Register the MCP pack and dispatch map for Pro */
		add_filter( 'fkmcp_ability_packs', array( __CLASS__, 'register_mcp_pack' ) );
		add_filter(
			'fkmcp_automations_context_pro',
			function () {
				$pro = array(
					'active'  => true,
					'version' => defined( 'BWFAN_PRO_VERSION' ) ? BWFAN_PRO_VERSION : null,
				);

				// Pro is active but the two creation tools are left out: say why,
				// so the agent does not tell the user they need Pro.
				if ( class_exists( 'FKMCP_Pack_Pro_Abilities', false ) && ! FKMCP_Pack_Pro_Abilities::lite_supports_creation() ) {
					$pro['note'] = sprintf( 'Update FunnelKit Automations to use automation creation: create-automation and list-recipes need FunnelKit Automations %s or later.', FKMCP_Pack_Pro_Abilities::MIN_LITE_FOR_CREATION );
				}

				return $pro;
			}
		);
		add_filter( 'fkmcp_dispatch_map', array( __CLASS__, 'register_mcp_dispatch_map' ) );
		add_filter( 'fkmcp_get_automation_result', array( __CLASS__, 'decorate_get_automation' ), 10, 3 );

		// Email previews made by the MCP email-design tools: a private link that expires.
		add_action( 'template_redirect', array( __CLASS__, 'maybe_serve_email_preview' ), 1 );
		add_filter( 'fkmcp_context_family_packs', array( __CLASS__, 'register_mcp_context_packs' ) );
	}

	/**
	 * Register the MCP pack for Pro.
	 *
	 * @param array $packs
	 *
	 * @return array
	 */
	public static function register_mcp_pack( $packs ) {
		if ( ! class_exists( 'FKMCP_Pack' ) || ! defined( 'BWFAN_PLUGIN_DIR' ) ) {
			return $packs;
		}

		// Pro packs use the lite plugin's MCP runtime (format, links, dispatch, permissions).
		$loader = BWFAN_PLUGIN_DIR . '/includes/mcp/class-bwfan-mcp-loader.php';

		// An Automations older than the MCP runtime: no pack rather than a fatal.
		if ( ! is_readable( $loader ) ) {
			return $packs;
		}

		require_once $loader;
		BWFAN_MCP_Loader::load();

		require_once BWFAN_PRO_PLUGIN_DIR . '/includes/mcp/class-fkmcp-pack-pro-abilities.php';

		$packs[] = new FKMCP_Pack_Pro_Abilities();

		require_once BWFAN_PRO_PLUGIN_DIR . '/includes/mcp/class-fkmcp-pack-email-design-abilities.php';

		$packs[] = new FKMCP_Pack_Email_Design_Abilities();

		// Designs are returned whole; the pack bounds their size itself.
		add_filter( 'fkmcp_scrub_result', array( 'FKMCP_Pack_Email_Design_Abilities', 'scrub_result' ), 10, 2 );

		return $packs;
	}

	/**
	 * fkmcp_get_automation_result: adds each step's definition path. Guarded
	 * because this filter can fire when no pack was registered, such as a
	 * direct, in-process call to FKMCP_Pack_Lite::get_automation() (the update
	 * sandbox does this). When a pack was registered, the light pack's
	 * autoloader loads the handler pack on class_exists(); otherwise the
	 * guard returns early.
	 *
	 * @param array|mixed $automation
	 * @param int         $aid
	 * @param array|mixed $result
	 *
	 * @return array|mixed
	 */
	public static function decorate_get_automation( $automation, $aid, $result ) {
		if ( ! class_exists( 'FKMCP_Pack_Pro' ) ) {
			return $automation;
		}

		return FKMCP_Pack_Pro::decorate_get_automation( $automation, $aid, $result );
	}

	/**
	 * Shows an email preview when the request asks for one; the page's class
	 * loads only then.
	 */
	public static function maybe_serve_email_preview() {
		if ( empty( $_GET['fk-email-preview'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- only checks whether a preview is asked for.
			return;
		}

		require_once BWFAN_PRO_PLUGIN_DIR . '/crm/includes/block-editor/email-design/class-bwfcrm-email-design-preview-page.php';

		BWFCRM_Email_Design_Preview_Page::maybe_serve();
	}

	/**
	 * Lists the Pro and email-design tools in the Automations context tool. The context
	 * tool matches pack class names, so the light registry names are listed beside the
	 * heavy ones: any Lite and Pro version pairing advertises both families.
	 *
	 * @param string[] $packs
	 *
	 * @return string[]
	 */
	public static function register_mcp_context_packs( $packs ) {
		$packs   = (array) $packs;
		$packs[] = 'FKMCP_Pack_Pro_Abilities';
		$packs[] = 'FKMCP_Pack_Email_Design_Abilities';
		$packs[] = 'FKMCP_Pack_Email_Design';

		return $packs;
	}

	/**
	 * Register the MCP dispatch map for Pro.
	 *
	 * @param array $map
	 *
	 * @return array
	 */
	public static function register_mcp_dispatch_map( $map ) {
		$campaigns = BWFAN_PRO_PLUGIN_DIR . '/crm/includes/api/campaigns/class-bwfcrm-api-campaigns-controller.php';
		$audience  = BWFAN_PRO_PLUGIN_DIR . '/crm/includes/api/audience/class-bwfcrm-api-audience-controller.php';
		$templates = BWFAN_PRO_PLUGIN_DIR . '/crm/includes/api/templates/class-bwfcrm-api-templates-controller.php';
		$autonami  = BWFAN_PLUGIN_DIR . '/includes/api/autonami/class-bwfan-api-autonami-controller.php';
		$recipe    = BWFAN_PLUGIN_DIR . '/includes/api/recipe/class-bwfan-api-recipe-controller.php';

		return array_merge( $map, array(
			'list-broadcasts'     => array( 'file' => $campaigns, 'class' => 'BWFCRM_API_Campaigns_Controller', 'handler' => 'get_campaigns' ),
			// The get-broadcast-stats ability reads its numbers from get-broadcast:
			// the controller's get_campaign_stats() returns a 4-day interval time
			// series for the admin chart, not the aggregate the ability reports.
			'get-broadcast'       => array( 'file' => $campaigns, 'class' => 'BWFCRM_API_Campaigns_Controller', 'handler' => 'get_campaign' ),
			'list-audiences'      => array( 'file' => $audience, 'class' => 'BWFCRM_API_Audience_Controller', 'handler' => 'get_audiences' ),
			'get-audience'        => array( 'file' => $audience, 'class' => 'BWFCRM_API_Audience_Controller', 'handler' => 'get_audience_by_id' ),
			'list-link-triggers'  => array( 'file' => BWFAN_PRO_PLUGIN_DIR . '/crm/includes/api/link-triggers/class-bwfcrm-api-link-triggers-controller.php', 'class' => 'BWFCRM_API_Link_Triggers_Controller', 'handler' => 'get_link_triggers' ),
			'get-contact-trail'   => array( 'file' => BWFAN_PLUGIN_DIR . '/includes/api/automation/class-bwfan-api-automation-controller.php', 'class' => 'BWFAN_API_Automation_Controller', 'handler' => 'get_automation_contact_trail' ),

			// Write targets — all behind BWFAN_MCP_Permissions::can_write in the pack.
			'create-contact'        => array( 'file' => BWFAN_PLUGIN_DIR . '/includes/api/contacts/class-bwfan-api-contacts-controller.php', 'class' => 'BWFAN_API_Contacts_Controller', 'handler' => 'create_contact' ),
			'apply-contact-fields'  => array( 'file' => BWFAN_PLUGIN_DIR . '/includes/api/contacts/class-bwfan-api-contacts-controller.php', 'class' => 'BWFAN_API_Contacts_Controller', 'handler' => 'apply_field' ),
			'assign-contact-tags'   => array( 'file' => BWFAN_PLUGIN_DIR . '/includes/api/contacts/class-bwfan-api-contacts-controller.php', 'class' => 'BWFAN_API_Contacts_Controller', 'handler' => 'update_contact_tags' ),
			'assign-contact-lists'  => array( 'file' => BWFAN_PLUGIN_DIR . '/includes/api/contacts/class-bwfan-api-contacts-controller.php', 'class' => 'BWFAN_API_Contacts_Controller', 'handler' => 'update_contact_lists' ),
			'remove-contact-tags'   => array( 'file' => BWFAN_PLUGIN_DIR . '/includes/api/contacts/class-bwfan-api-contacts-controller.php', 'class' => 'BWFAN_API_Contacts_Controller', 'handler' => 'delete_contact_tags' ),
			'remove-contact-lists'  => array( 'file' => BWFAN_PLUGIN_DIR . '/includes/api/contacts/class-bwfan-api-contacts-controller.php', 'class' => 'BWFAN_API_Contacts_Controller', 'handler' => 'delete_contact_lists' ),
			'create-contact-note'   => array( 'file' => BWFAN_PLUGIN_DIR . '/includes/api/contacts/class-bwfan-api-contacts-controller.php', 'class' => 'BWFAN_API_Contacts_Controller', 'handler' => 'create_contact_note' ),
			'get-contact-notes'     => array( 'file' => BWFAN_PLUGIN_DIR . '/includes/api/contacts/class-bwfan-api-contacts-controller.php', 'class' => 'BWFAN_API_Contacts_Controller', 'handler' => 'get_contact_notes' ),
			'update-contact-note'   => array( 'file' => BWFAN_PLUGIN_DIR . '/includes/api/contacts/class-bwfan-api-contacts-controller.php', 'class' => 'BWFAN_API_Contacts_Controller', 'handler' => 'update_contact_note' ),
			'create-tags'           => array( 'file' => BWFAN_PLUGIN_DIR . '/includes/api/tags/class-bwfan-api-tags-controller.php', 'class' => 'BWFAN_API_Tags_Controller', 'handler' => 'create_tag' ),
			'update-tag'            => array( 'file' => BWFAN_PLUGIN_DIR . '/includes/api/tags/class-bwfan-api-tags-controller.php', 'class' => 'BWFAN_API_Tags_Controller', 'handler' => 'update_tag' ),
			'create-list'           => array( 'file' => BWFAN_PLUGIN_DIR . '/includes/api/lists/class-bwfan-api-lists-controller.php', 'class' => 'BWFAN_API_Lists_Controller', 'handler' => 'create_single_list' ),
			'update-list'           => array( 'file' => BWFAN_PLUGIN_DIR . '/includes/api/lists/class-bwfan-api-lists-controller.php', 'class' => 'BWFAN_API_Lists_Controller', 'handler' => 'update_list' ),
			'create-custom-field'   => array( 'file' => BWFAN_PLUGIN_DIR . '/includes/api/fields/class-bwfan-api-fields-controller.php', 'class' => 'BWFAN_API_Fields_Controller', 'handler' => 'create_field' ),
			'update-custom-field'   => array( 'file' => BWFAN_PLUGIN_DIR . '/includes/api/fields/class-bwfan-api-fields-controller.php', 'class' => 'BWFAN_API_Fields_Controller', 'handler' => 'update_field' ),
			'create-field-group'    => array( 'file' => BWFAN_PLUGIN_DIR . '/includes/api/groupfields/class-bwfan-api-groupfields-controller.php', 'class' => 'BWFAN_API_Groupfields_Controller', 'handler' => 'create_group' ),
			'update-field-group'    => array( 'file' => BWFAN_PLUGIN_DIR . '/includes/api/groupfields/class-bwfan-api-groupfields-controller.php', 'class' => 'BWFAN_API_Groupfields_Controller', 'handler' => 'update_group' ),
			'contact-status-action' => array( 'file' => BWFAN_PLUGIN_DIR . '/includes/api/contacts/class-bwfan-api-contacts-controller.php', 'class' => 'BWFAN_API_Contacts_Controller', 'handler' => 'execute_status_action' ),
			'send-contact-message'  => array( 'file' => BWFAN_PLUGIN_DIR . '/includes/api/contacts/class-bwfan-api-contacts-controller.php', 'class' => 'BWFAN_API_Contacts_Controller', 'handler' => 'send_message' ),
			'delete-contact-row'    => array( 'file' => BWFAN_PLUGIN_DIR . '/includes/api/contacts/class-bwfan-api-contacts-controller.php', 'class' => 'BWFAN_API_Contacts_Controller', 'handler' => 'delete_contact' ),
			'get-email-analytics' => array( 'file' => BWFAN_PRO_PLUGIN_DIR . '/crm/includes/api/reports/class-bwfcrm-api-reports-controller.php', 'class' => 'BWFCRM_API_Reports_Controller', 'handler' => 'get_emails_tabular' ),

			// Email design.
			'list-email-templates' => array( 'file' => $templates, 'class' => 'BWFCRM_API_Templates_Controller', 'handler' => 'get_templates' ),
			'get-email-template'   => array( 'file' => $templates, 'class' => 'BWFCRM_API_Templates_Controller', 'handler' => 'get_template' ),
			'list-email-layouts'   => array( 'file' => BWFAN_PRO_PLUGIN_DIR . '/crm/includes/api/layout/class-bwfcrm-api-layout-controller.php', 'class' => 'BWFCRM_API_Layout_Controller', 'handler' => 'get_layouts' ),
			'create-email-template' => array( 'file' => $templates, 'class' => 'BWFCRM_API_Templates_Controller', 'handler' => 'create_template' ),
			'update-email-template' => array( 'file' => $templates, 'class' => 'BWFCRM_API_Templates_Controller', 'handler' => 'update_template' ),
			'clone-email-template'  => array( 'file' => $templates, 'class' => 'BWFCRM_API_Templates_Controller', 'handler' => 'clone_template' ),

			// create-automation / list-recipes: Lite's own controllers. Never map
			// import_recipe (V1, takes input as a class name) or import_automation
			// (file upload). delete-automations is the rollback only.
			'list-recipes'             => array( 'file' => $recipe, 'class' => 'BWFAN_API_Recipe_Controller', 'handler' => 'get_recipes' ),
			'create-automation-recipe' => array( 'file' => $recipe, 'class' => 'BWFAN_API_Recipe_Controller', 'handler' => 'import_automation_recipe' ),
			'create-automation-blank'  => array( 'file' => $autonami, 'class' => 'BWFAN_API_Autonami_Controller', 'handler' => 'create_automation' ),
			'duplicate-automation'     => array( 'file' => $autonami, 'class' => 'BWFAN_API_Autonami_Controller', 'handler' => 'duplicate_automation' ),
			'delete-automations'       => array( 'file' => $autonami, 'class' => 'BWFAN_API_Autonami_Controller', 'handler' => 'delete_automations' ),
		) );
	}

	/**
	 * Register the admin bar "Search Contact" toggle on the Settings → Tools screen.
	 *
	 * @param array $tool_settings
	 *
	 * @return array
	 */
	public static function add_admin_bar_search_tool( $tool_settings ) {
		$tool_settings[] = array(
			'title'          => __( 'Admin Bar "Search Contact"', 'wp-marketing-automations-pro' ),
			'type'           => 'toggle',
			'description'    => __( 'Show the "Search Contact" shortcut in the WordPress admin bar.', 'wp-marketing-automations-pro' ),
			'task'           => 'toggle_admin_bar_search',
			'status'         => 'no' !== bwf_options_get( 'bwfan_admin_bar_search_enabled', 'value', 'yes' ),
			'processingText' => __( 'Updating admin bar setting', 'wp-marketing-automations-pro' ),
			'reload'         => true,
		);

		return $tool_settings;
	}

	/**
	 * Save the admin bar "Search Contact" toggle state.
	 *
	 * @param array $result
	 * @param array $data
	 *
	 * @return array
	 */
	public static function save_admin_bar_search_tool( $result, $data ) {
		$enabled = ! empty( $data['value'] );
		bwf_options_update( 'bwfan_admin_bar_search_enabled', $enabled ? 'yes' : 'no' );

		$result['msg']    = $enabled ? __( 'Admin bar shortcut enabled', 'wp-marketing-automations-pro' ) : __( 'Admin bar shortcut disabled', 'wp-marketing-automations-pro' );
		$result['status'] = true;

		return $result;
	}

	/**
	 * Build a Reply-To email header for Pro send paths.
	 *
	 * Delegates to the lite BWFAN_Common::build_reply_to_header() so the
	 * bwfan_reply_to_header filter governs Pro mail too. When running against an older
	 * lite build that does not yet expose the helper, mirrors the same logic (including
	 * the bwfan_reply_to_header filter) so behaviour is identical and a partial update
	 * can never fatal on the send path.
	 *
	 * @param string $reply_to_email Reply-To email address.
	 * @param string $reply_to_name  Reply-To display name (optional).
	 * @param string $fallback_name  Fallback name, typically the From name.
	 *
	 * @return string Reply-To header line, or empty string when no email is provided.
	 */
	public static function build_reply_to_header( $reply_to_email, $reply_to_name = '', $fallback_name = '' ) {
		if ( method_exists( 'BWFAN_Common', 'build_reply_to_header' ) ) {
			return BWFAN_Common::build_reply_to_header( $reply_to_email, $reply_to_name, $fallback_name );
		}

		$reply_to_email = trim( (string) $reply_to_email );
		if ( empty( $reply_to_email ) ) {
			return '';
		}

		/**
		 * Filter the Reply-To header line before it is added to the email headers.
		 *
		 * Default is the standard bare `Reply-To: <email>`. Return a custom value such as
		 * `Reply-To: Name <email>` for SMTP plugins that require a display name on Reply-To
		 * (e.g. Authority Mailer, Code 29). When attaching a name that may contain specials
		 * (comma, <, @, ...), wrap it in double quotes in the callback to keep the header valid.
		 *
		 * @param string $header         The Reply-To header line. Default 'Reply-To: <email>'.
		 * @param string $reply_to_email Reply-To email address.
		 * @param string $reply_to_name  Reply-To display name, if any (may be empty).
		 * @param string $fallback_name  Fallback name, typically the From name.
		 */
		return apply_filters( 'bwfan_reply_to_header', 'Reply-To: ' . $reply_to_email, $reply_to_email, $reply_to_name, $fallback_name );
	}

	/** Include Form Submit Events available in Pro
	 *
	 * @param $events
	 *
	 * @return string[]
	 */
	public static function get_form_submit_events( $events ) {
		$pro_form_events = array(
			'BWFAN_Elementor_Form_Submit',
			'BWFAN_Elementor_PopUp_Form_Submit',
			'BWFAN_Caldera_Form_Submit',
			'BWFAN_Fluent_Form_Submit',
			'BWFAN_SureForms_Form_Submit',
			'BWFAN_GF_Form_Submit',
			'BWFAN_Ninja_Form_Submit',
			'BWFAN_Funnel_Optin_Form_Submit',
			'BWFAN_TVE_Lead_Form_Submit',
			'BWFAN_WPFORMS_Form_Submit'
		);

		return is_array( $events ) && ! empty( $events ) ? array_merge( $events, $pro_form_events ) : $pro_form_events;
	}

	public static function send_test_http_post() {
		BWFAN_PRO_Common::nocache_headers();
		BWFAN_Common::check_nonce(); // phpcs:disable WordPress.Security.NonceVerification

		$response = [];
		try {
			$post = $_POST;
			BWFAN_Merge_Tag_Loader::set_data( array(
				'is_preview' => true,
			) );
			$custom_fields = array();
			if ( isset( $post['v'] ) && 2 === absint( $post['v'] ) ) {
				$url = $post['url'];
				if ( isset( $post['custom_fields'] ) && is_array( $post['custom_fields'] ) ) {
					foreach ( $post['custom_fields'] as $field ) {
						$field_value                 = stripslashes( $field['field_value'] );
						$field_key                   = stripslashes( $field['field'] );
						$custom_fields[ $field_key ] = BWFAN_Common::decode_merge_tags( $field_value );
					}
				}

				$headers = array();
				if ( isset( $post['headers'] ) && is_array( $post['headers'] ) ) {
					foreach ( $post['headers'] as $field ) {
						$field_value           = stripslashes( $field['field_value'] );
						$field_key             = stripslashes( $field['field'] );
						$headers[ $field_key ] = BWFAN_Common::decode_merge_tags( $field_value );
					}
				}

				$method = isset( $post['http_method'] ) ? $post['http_method'] : 2;
			} else {

				$url          = $post['data']['url'];
				$fields       = array_map( 'stripslashes', $post['data']['custom_fields']['field'] );
				$fields_value = array_map( 'stripslashes', $post['data']['custom_fields']['field_value'] );
				foreach ( $fields as $key1 => $field_id ) {
					$custom_fields[ $field_id ] = BWFAN_Common::decode_merge_tags( $fields_value[ $key1 ] );
				}

				$fields       = array_map( 'stripslashes', $post['data']['headers']['field'] );
				$fields_value = array_map( 'stripslashes', $post['data']['headers']['field_value'] );
				$headers      = array();
				foreach ( $fields as $key1 => $field_id ) {
					$headers[ $field_id ] = BWFAN_Common::decode_merge_tags( $fields_value[ $key1 ] );
				}

				$method = isset( $post['data']['http_method'] ) ? $post['data']['http_method'] : 2;
			}


			$action_object             = BWFAN_Core()->integration->get_action( 'wp_http_post' );
			$action_object->is_preview = true;
			$action_object->set_data( array(
				'headers'       => $headers,
				'custom_fields' => $custom_fields,
				'url'           => $url,
				'method'        => $method,
			) );
			$response = $action_object->process();
		} catch ( Exception $e ) {
			wp_send_json( array(
				'status' => false,
				'msg'    => $e->getMessage(),
			) );
		}

		if ( empty( $response ) || 200 !== $response['response'] ) {
			$message = isset( $response['body'] ) && is_array( $response['body'] ) ? $response['body'][0] : __( 'Unable to send data', 'wp-marketing-automations-pro' );
			wp_send_json( array(
				'status' => false,
				'msg'    => $message,
			) );
		}

		wp_send_json( array(
			'status' => true,
			'msg'    => __( 'Test Data posted', 'wp-marketing-automations-pro' ),
		) );
	}

	/**
	 * Capture all the action ids of an automation and delete all its tasks except for completed tasks.
	 *
	 * @param $contact
	 * @param $order_id
	 *
	 * @return void
	 */
	public static function delete_automation_tasks_by_automation_ids( $contact, $order_id ) {
		/** Check if v1 automations active */
		if ( false === BWFAN_Common::is_automation_v1_active() ) {
			return;
		}

		if ( $contact instanceof WooFunnels_Contact && absint( $contact->get_id() ) > 0 ) {
			do_action( 'bwfan_sync_call_delete_tasks', $contact->get_email(), $contact->get_contact_no(), $order_id );

			return;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order instanceof WC_Order ) {
			return;
		}

		do_action( 'bwfan_sync_call_delete_tasks', $order->get_billing_email(), $order->get_billing_phone(), $order_id );
	}

	/**
	 * Schedule a wp event which will run once a day.
	 * @throws Exception
	 */
	public static function schedule_cron() {
		if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
			return;
		}

		$run_midnight_cron_scheduled            = '';
		$five_minute_worker_scheduled           = '';
		$run_midnight_connectors_sync_scheduled = '';

		if ( method_exists( 'BWFAN_Common', 'bwf_has_action_scheduled' ) ) {
			$run_midnight_cron_scheduled            = BWFAN_Common::bwf_has_action_scheduled( 'bwfan_run_midnight_cron' );
			$five_minute_worker_scheduled           = BWFAN_Common::bwf_has_action_scheduled( 'bwfan_5_minute_worker' );
			$run_midnight_connectors_sync_scheduled = BWFAN_Common::bwf_has_action_scheduled( 'bwfan_run_midnight_connectors_sync' );
		} else {
			$run_midnight_cron_scheduled            = bwf_has_action_scheduled( 'bwfan_run_midnight_cron' );
			$five_minute_worker_scheduled           = bwf_has_action_scheduled( 'bwfan_5_minute_worker' );
			$run_midnight_connectors_sync_scheduled = bwf_has_action_scheduled( 'bwfan_run_midnight_connectors_sync' );
		}

		$midnight_time = self::get_midnight_store_time();
		if ( ! $run_midnight_cron_scheduled ) {
			bwf_schedule_recurring_action( $midnight_time, DAY_IN_SECONDS, 'bwfan_run_midnight_cron' );
		}

		/** Schedule connectors sync call */
		if ( ! $run_midnight_connectors_sync_scheduled ) {
			bwf_schedule_recurring_action( $midnight_time, DAY_IN_SECONDS, 'bwfan_run_midnight_connectors_sync' );
		}

		/** Scheduling a 5 min worker */
		if ( ! $five_minute_worker_scheduled ) {
			bwf_schedule_recurring_action( time(), MINUTE_IN_SECONDS * 5, 'bwfan_5_minute_worker' );
		}
	}

	/**
	 * Remove autonami events on plugin deactivation.
	 */
	public static function deactivation() {
		bwf_unschedule_actions( 'bwfan_run_midnight_cron' );
	}

	/**
	 * Run once in a day and check all the active automations for events which are time independent.
	 *
	 * @return void
	 * @throws Exception
	 */
	public static function run_midnight_cron() {
		$global_settings = BWFAN_Common::get_global_settings();

		$delete_time_in_days = intval( $global_settings['bwfan_delete_engagement_tracking_meta'] );
		if ( ( ! isset( $global_settings['bwfan_delete_engagement_tracking_meta_enable'] ) || $global_settings['bwfan_delete_engagement_tracking_meta_enable'] ) && ! empty( $delete_time_in_days ) && ! bwf_has_action_scheduled( 'bwfan_delete_engagement_meta_records' ) ) {
			bwf_schedule_recurring_action( time(), MINUTE_IN_SECONDS * 5, 'bwfan_delete_engagement_meta_records' );
		}

		$automations = self::get_active_async_automations();
		if ( empty( $automations ) ) {
			return;
		}

		$automations = array_column( $automations, 'ID' );

		do_action( 'bwfan_midnight_cron', $automations );
		foreach ( $automations as $aid ) {
			self::schedule_time_async_events( $aid );
		}
	}

	/**
	 * Delete engagement tracking meta record from DB. This function run once in a day.
	 *
	 * @return void
	 */
	public static function delete_engagement_tracking_meta() {
		global $wpdb;

		$global_settings     = BWFAN_Common::get_global_settings();
		$delete_time_in_days = intval( $global_settings['bwfan_delete_engagement_tracking_meta'] );
		$delete_time_in_days = $delete_time_in_days > 0 ? $delete_time_in_days : 30;

		$current_datetime = new DateTime( 'now' );
		$current_datetime->modify( "-{$delete_time_in_days} days" );

		$cutoff_date = $current_datetime->format( 'Y-m-d' );
		$start_time  = time();

		$last_id_query = $wpdb->prepare( "SELECT MAX(ID)
        FROM {$wpdb->prefix}bwfan_engagement_tracking
        WHERE created_at IS NOT NULL
        AND created_at < %s", $cutoff_date );


		$last_id = $wpdb->get_var( $last_id_query );// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL

		if ( empty( $last_id ) ) {
			bwf_unschedule_actions( 'bwfan_delete_engagement_meta_records' );

			return;
		}

		do {
			$delete_query = $wpdb->prepare( "DELETE FROM {$wpdb->prefix}bwfan_engagement_trackingmeta
	         WHERE eid <= %d
	         AND meta_key IN ( %s, %s)
	         LIMIT 500", $last_id, 'merge_tags', 'conditional_set' );

			$rows_affected = $wpdb->query( $delete_query ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL

			if ( empty( $rows_affected ) ) {
				bwf_unschedule_actions( 'bwfan_delete_engagement_meta_records' );
				break;
			}
		} while ( ( time() - $start_time ) < 20 );
	}

	/**
	 * Get all active async automation ids
	 *
	 * @return array|null
	 */
	public static function get_active_async_automations() {
		$ins        = BWFAN_Load_Sources::get_instance();
		$all_events = $ins->get_events();

		/** Fetch time independent only */
		$all_events = array_filter( $all_events, function ( $events ) {
			return $events->is_time_independent();
		} );
		if ( empty( $all_events ) ) {
			return [];
		}

		$all_events = array_map( function ( $events ) {
			return $events->get_slug();
		}, $all_events );
		$all_events = array_keys( $all_events );

		global $wpdb;

		$placeholder = array_fill( 0, count( $all_events ), '%s' );
		$placeholder = implode( ", ", $placeholder );
		$query       = $wpdb->prepare( "SELECT `ID` FROM `{$wpdb->prefix}bwfan_automations` WHERE `event` IN ($placeholder) AND `status` = 1;", $all_events );

		return BWFAN_Model_Automations::get_results( $query );
	}

	/**
	 * Schedule action if the automation is time independent.
	 *
	 * @param $automation_id
	 *
	 * @throws Exception
	 */
	public static function schedule_time_async_events( $automation_id ) {
		if ( class_exists( 'WooFunnels_Cache' ) ) {
			$WooFunnels_Cache_obj = WooFunnels_Cache::get_instance();
			$WooFunnels_Cache_obj->set_cache( 'bwfan_automations_meta_' . $automation_id, false, 'autonami' );
		}

		$automation = BWFAN_Model_Automations::get_automation_with_data( $automation_id );
		/** Check if automation deactivated */
		if ( 1 !== intval( $automation['status'] ) ) {
			if ( bwf_has_action_scheduled( 'bwfan_run_independent_automation', array( $automation_id ) ) ) {
				bwf_unschedule_actions( 'bwfan_run_independent_automation', array( $automation_id ) );
			}

			if ( $automation_id !== intval( $automation_id ) ) {
				if ( bwf_has_action_scheduled( 'bwfan_run_independent_automation', array( intval( $automation_id ) ) ) ) {
					bwf_unschedule_actions( 'bwfan_run_independent_automation', array( intval( $automation_id ) ) );
				}
			}

			return;
		}

		if ( ! isset( $automation['event'] ) || empty( $automation['event'] ) ) {
			return;
		}

		$event_instance = BWFAN_Core()->sources->get_event( $automation['event'] );
		if ( ! $event_instance instanceof BWFAN_Event ) {
			return;
		}
		$event_instance->load_hooks();

		/** v1 */
		$hours   = isset( $automation['meta']['event_meta']['hours'] ) ? $automation['meta']['event_meta']['hours'] : '';
		$minutes = isset( $automation['meta']['event_meta']['minutes'] ) ? $automation['meta']['event_meta']['minutes'] : '';

		if ( 2 === absint( $automation['v'] ) ) {
			$hours   = isset( $automation['meta']['event_meta']['scheduled-everyday-at']['hours'] ) ? $automation['meta']['event_meta']['scheduled-everyday-at']['hours'] : '';
			$minutes = isset( $automation['meta']['event_meta']['scheduled-everyday-at']['minutes'] ) ? $automation['meta']['event_meta']['scheduled-everyday-at']['minutes'] : '';
		}

		$hours   = empty( $hours ) ? 00 : $hours;
		$minutes = empty( $minutes ) ? 00 : $minutes;

		if ( bwf_has_action_scheduled( 'bwfan_run_independent_automation', array( $automation_id ) ) ) {
			bwf_unschedule_actions( 'bwfan_run_independent_automation', array( $automation_id ) );
		}

		if ( $automation_id !== intval( $automation_id ) ) {
			if ( bwf_has_action_scheduled( 'bwfan_run_independent_automation', array( intval( $automation_id ) ) ) ) {
				bwf_unschedule_actions( 'bwfan_run_independent_automation', array( intval( $automation_id ) ) );
			}
		}

		$automation_id = intval( $automation_id );

		bwf_schedule_single_action( BWFAN_Core()->automations->get_automation_execution_time( $hours, $minutes ), 'bwfan_run_independent_automation', array( $automation_id ) );
	}

	/**
	 * Make tasks for those events which are time independent.
	 * Like WC subscription before end or before renewal
	 *
	 * @param $automation_id
	 */
	public static function make_independent_events_tasks( $automation_id ) {
		$automation_details = BWFAN_Model_Automations::get_automation_with_data( $automation_id );

		/** Check if automation is active */
		if ( 1 !== intval( $automation_details['status'] ) ) {
			return;
		}

		$event_instance = BWFAN_Core()->sources->get_event( $automation_details['event'] );

		/** Validate if event exist */
		if ( ! $event_instance instanceof BWFAN_Event ) {
			return;
		}

		/** Halt if not time independent event */
		if ( false === $event_instance->is_time_independent() ) {
			return;
		}

		$event_instance->load_hooks();
		$last_run = BWFAN_Model_Automationmeta::get_meta( $automation_id, 'last_run' );
		if ( empty( $last_run ) ) {
			$event_instance->make_task_data( $automation_id, $automation_details );

			return;
		}

		$date_time   = new DateTime();
		$current_day = $date_time->format( 'Y-m-d' );

		BWFAN_Common::log_test_data( 'async - last run: ' . $last_run . ' | current: ' . $current_day, 'async-checking', true );
		if ( $current_day !== $last_run ) {
			$event_instance->make_task_data( $automation_id, $automation_details );
		}
	}

	/**
	 * Get FunnelKit Upsell funnels
	 *
	 * @param $term
	 *
	 * @return array|null
	 */
	public static function get_upstroke_funnels( $term = '' ) {
		/** Return if already set */
		if ( ! is_null( self::$upstroke_funnels ) ) {
			return self::$upstroke_funnels;
		}

		$args = array(
			'post_type'      => WFOCU_Common::get_funnel_post_type_slug(),
			'post_status'    => array( 'publish' ),
			'posts_per_page' => - 1,
		);
		if ( ! empty( $term ) ) {
			$args['s'] = $term;
		}
		if ( ! empty( $term ) && is_numeric( $term ) ) {
			unset( $args['s'] );
			$args['post__in'] = array( $term );
		}

		$q     = new WP_Query( $args );
		$items = array();
		if ( $q->have_posts() ) {
			foreach ( $q->posts as $post ) {
				$items[] = array(
					'id'         => $post->ID,
					'post_title' => $post->post_title,
				);
			}
		}

		self::$upstroke_funnels = $items;

		return $items;
	}

	/**
	 * Return Funnelkit Upsell offers
	 *
	 * @param $term
	 *
	 * @return array|null
	 */
	public static function get_upstroke_offers( $term = '' ) {
		/** Return if already set */
		if ( ! is_null( self::$upstroke_offers ) ) {
			return self::$upstroke_offers;
		}

		$args = array(
			'post_type'      => WFOCU_Common::get_offer_post_type_slug(),
			'post_status'    => array( 'publish' ),
			'posts_per_page' => - 1,
		);
		if ( ! empty( $term ) ) {
			$args['s'] = $term;
		}
		if ( ! empty( $term ) && is_numeric( $term ) ) {
			unset( $args['s'] );
			$args['post__in'] = array( $term );
		}

		$q     = new WP_Query( $args );
		$items = array();
		if ( $q->have_posts() ) {
			foreach ( $q->posts as $post ) {
				$items[] = array(
					'id'         => $post->ID,
					'post_title' => $post->post_title,
				);
			}
		}

		self::$upstroke_offers = $items;

		return $items;
	}

	public static function get_upstroke_funnel_nice_name( $funnel_ids ) {
		$result = [];
		$args   = array(
			'post_type'   => WFOCU_Common::get_funnel_post_type_slug(),
			'numberposts' => - 1,
			'post__in'    => $funnel_ids,
		);

		$funnels = get_posts( $args );
		if ( false === is_array( $funnels ) || 0 === count( $funnels ) ) {
			return $result;
		}

		foreach ( $funnels as $single_funnel ) {
			$result[ $single_funnel->ID ] = $single_funnel->post_title . ' (#' . $single_funnel->ID . ')';
		}

		return $result;
	}

	public static function get_upstroke_offer_nice_name( $offer_ids ) {
		$result = [];
		$args   = array(
			'post_type'   => WFOCU_Common::get_offer_post_type_slug(),
			'numberposts' => - 1,
			'post__in'    => $offer_ids,
		);

		$offers = get_posts( $args );
		if ( false === is_array( $offers ) || 0 === count( $offers ) ) {
			return $result;
		}

		foreach ( $offers as $single_offer ) {
			$result[ $single_offer->ID ] = $single_offer->post_title;
		}

		return $result;
	}

	public static function get_all_active_affiliates() {
		global $wpdb;

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$affiliates = $wpdb->get_results( $wpdb->prepare( "
										SELECT affiliate_id
										FROM {$wpdb->prefix}affiliate_wp_affiliates
										WHERE status = %s
										", 'active' ), ARRAY_A );

		if ( count( $affiliates ) > 0 ) {
			return array_column( $affiliates, 'affiliate_id' );
		}

		return $affiliates;
	}


	public static function get_referrals_count_from_period( $affiliate_id, $from, $to ) {
		global $wpdb;

		$start_date = $from . ' 00:00:00';
		$end_date   = $to . ' 23:59:59';

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$referrals = $wpdb->get_var( $wpdb->prepare( "
			                                        SELECT COUNT(referral_id)
			                                        FROM {$wpdb->prefix}affiliate_wp_referrals
			                                        WHERE affiliate_id = %d
			                                        AND status = %s
			                                        AND date >= %s
			                                        AND date <= %s
			                                        ", $affiliate_id, 'unpaid', $start_date, $end_date ) );

		return ! empty( $referrals ) ? $referrals : 0;
	}

	public static function get_visits_from_period( $affiliate_id, $from, $to ) {
		global $wpdb;

		$start_date = $from . ' 00:00:00';
		$end_date   = $to . ' 23:59:59';

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$visits = $wpdb->get_var( $wpdb->prepare( "
			                                        SELECT COUNT(visit_id)
			                                        FROM {$wpdb->prefix}affiliate_wp_visits
			                                        WHERE affiliate_id = %d
			                                        AND date >= %s
			                                        AND date <= %s
			                                        ", $affiliate_id, $start_date, $end_date ) );

		return ! empty( $visits ) ? $visits : 0;
	}

	public static function get_commissions_from_period( $affiliate_id, $from, $to ) {
		global $wpdb;

		$start_date = $from . ' 00:00:00';
		$end_date   = $to . ' 23:59:59';

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$earnings = $wpdb->get_var( $wpdb->prepare( "
			                                        SELECT SUM(amount)
			                                        FROM {$wpdb->prefix}affiliate_wp_referrals
			                                        WHERE affiliate_id = %d
			                                        AND status = %s
			                                        AND date >= %s
			                                        AND date <= %s
			                                        ", $affiliate_id, 'unpaid', $start_date, $end_date ) );

		$total_earnings = 0;
		if ( ! empty( $earnings ) ) {
			$decimal        = apply_filters( 'bwfan_get_decimal_values', 2 );
			$total_earnings = round( $earnings, $decimal );
		}

		return $total_earnings;
	}

	public static function get_callable_object( $is_empty, $data ) {
		if ( 'sfwd-courses' === $data['type'] ) {
			return [ __CLASS__, 'get_learndash_courses' ];
		} elseif ( 'tag' === $data['type'] ) {
			return [ __CLASS__, 'get_tags' ];
		} elseif ( 'list' === $data['type'] ) {
			return [ __CLASS__, 'get_lists' ];
		} elseif ( 'link_trigger' === $data['type'] ) {
			return [ __CLASS__, 'get_link_triggers' ];
		} elseif ( 'quiz' === $data['type'] ) {
			return [ __CLASS__, 'get_quizzes' ];
		}

		return $is_empty;
	}

	public static function get_learndash_courses( $searched_term ) {
		$courses      = array();
		$results      = array();
		$query_params = array(
			'post_type'      => 'sfwd-courses',
			'posts_per_page' => - 1,
			'post_status'    => 'publish',
		);

		if ( '' !== $searched_term ) {
			$query_params['s'] = $searched_term;
		}

		$query = new WP_Query( $query_params );

		if ( $query->found_posts > 0 ) {
			foreach ( $query->posts as $post ) {
				$results[] = array(
					'id'   => $post->ID,
					'text' => $post->post_title,
				);
			}
		}

		$courses['results'] = $results;

		return $courses;
	}

	public static function get_wc_membership_active_statuses() {
		if ( ! function_exists( 'wc_memberships' ) ) {
			return [];
		}

		$statuses = wc_memberships()->get_user_memberships_instance()->get_active_access_membership_statuses();

		return BWFAN_PRO_Common::get_wc_membership_statuses_with_prefix( $statuses );
	}

	public static function get_wc_membership_statuses_with_prefix( $statuses ) {
		if ( ! function_exists( 'wc_memberships' ) ) {
			return [];
		}

		$statuses_to_return = [];
		foreach ( (array) $statuses as $index => $status ) {

			if ( 'any' !== $status ) {
				$statuses_to_return[ $index ] = 'wcm-' . $status;
			}
		}

		return $statuses_to_return;
	}


	public static function test_zap() {
		BWFAN_PRO_Common::nocache_headers();
		BWFAN_Common::check_nonce();
		// phpcs:disable WordPress.Security.NonceVerification
		$result = array(
			'status' => false,
			'msg'    => __( 'Error', 'wp-marketing-automations-pro' ),
		);

		$post        = $_POST;
		$webhook_url = isset( $post['data'] ) || isset( $post['data']['url'] ) ? $post['data']['url'] : '';
		$url         = filter_input( INPUT_POST, 'url' );
		$webhook_url = empty( $url ) ? $webhook_url : $url;
		if ( empty( $webhook_url ) ) {
			$result['msg'] = __( 'Webhook URL cannot be blank', 'wp-marketing-automations-pro' );
			wp_send_json( $result );
		}

		update_option( 'bwfan_show_preview', $post );
		BWFAN_Merge_Tag_Loader::set_data( array(
			'is_preview' => true,
		) );

		$post['event_data']['event_slug'] = $post['event'];
		$custom_fields                    = array();
		/** only checking with v1 automations */
		if ( ! isset( $post['v'] ) || 2 !== absint( $post['v'] ) ) {
			if ( isset( $post['data']['custom_fields'] ) && isset( $post['data']['custom_fields']['field'] ) && isset( $post['data']['custom_fields']['field_value'] ) ) {
				reset( $post['data']['custom_fields']['field'] );
				$first_key = key( $post['data']['custom_fields']['field'] );
				if ( empty( $post['data']['custom_fields']['field'][ $first_key ] ) || empty( $post['data']['custom_fields']['field'][ $first_key ] ) ) {
					$result['msg'] = __( 'Atleast one key / value pair required', 'wp-marketing-automations-pro' );
					wp_send_json( $result );
				}
			} else {
				$result['msg'] = __( 'Atleast one key / value pair required', 'wp-marketing-automations-pro' );
				wp_send_json( $result );
			}
			$fields       = array_map( 'stripslashes', $post['data']['custom_fields']['field'] );
			$fields_value = array_map( 'stripslashes', $post['data']['custom_fields']['field_value'] );

			foreach ( $fields as $key1 => $field_id ) {
				$custom_fields[ $field_id ] = BWFAN_Common::decode_merge_tags( $fields_value[ $key1 ] );
			}
		} else {
			$fields = $post['custom_fields'];
			foreach ( $fields as $field ) {
				$custom_fields[ $field['field'] ] = BWFAN_Common::decode_merge_tags( $field['field_value'] );
			}
		}
		$data_to_set                  = array();
		$data_to_set['custom_fields'] = $custom_fields;
		$data_to_set['url']           = BWFAN_Common::decode_merge_tags( $webhook_url );
		$data_to_set['test']          = true;
		$action_object                = BWFAN_Core()->integration->get_action( 'za_send_data' );
		$action_object->is_preview    = true;
		$action_object->set_data( $data_to_set );
		$response = $action_object->process();

		/** adding handling for error responses in test zap */
		if ( empty( $response ) || 200 !== $response['response'] ) {
			$message = isset( $response['body'] ) && is_array( $response['body'] ) ? $response['body'][0] : __( 'Unable to send data', 'wp-marketing-automations-pro' );
			wp_send_json( array(
				'status' => false,
				'msg'    => $message,
			) );
		}

		if ( false !== $response ) {
			$result['msg']    = __( 'Test Data sent to Zap.', 'wp-marketing-automations-pro' );
			$result['status'] = true;
		}


		//phpcs:enable WordPress.Security.NonceVerification
		wp_send_json( $result );
	}

	public static function test_pabbly() {
		BWFAN_PRO_Common::nocache_headers();
		BWFAN_Common::check_nonce();
		// phpcs:disable WordPress.Security.NonceVerification
		$result = array(
			'status' => false,
			'msg'    => __( 'Error', 'wp-marketing-automations-pro' ),
		);

		$post = $_POST;
		if ( empty( $post['data']['url'] ) ) {
			$result['msg'] = __( 'Webhook URL cannot be blank', 'wp-marketing-automations-pro' );
			wp_send_json( $result );

		}

		if ( isset( $post['data']['custom_fields'] ) && isset( $post['data']['custom_fields']['field'] ) && isset( $post['data']['custom_fields']['field_value'] ) ) {
			reset( $post['data']['custom_fields']['field'] );
			$first_key = key( $post['data']['custom_fields']['field'] );
			if ( empty( $post['data']['custom_fields']['field'][ $first_key ] ) || empty( $post['data']['custom_fields']['field'][ $first_key ] ) ) {
				$result['msg'] = __( 'Atleast one key / value pair required', 'wp-marketing-automations-pro' );
				wp_send_json( $result );
			}
		} else {
			$result['msg'] = __( 'Atleast one key / value pair required', 'wp-marketing-automations-pro' );
			wp_send_json( $result );
		}

		update_option( 'bwfan_show_preview', $post );
		BWFAN_Merge_Tag_Loader::set_data( array(
			'is_preview' => true,
		) );

		$post['event_data']['event_slug'] = $post['event'];
		$action_object                    = BWFAN_Core()->integration->get_action( 'pabbly_send_data' );
		$action_object->is_preview        = true;
		$data_to_set                      = array();

		$fields       = array_map( 'stripslashes', $post['data']['custom_fields']['field'] );
		$fields_value = array_map( 'stripslashes', $post['data']['custom_fields']['field_value'] );

		$custom_fields = array();

		foreach ( $fields as $key1 => $field_id ) {
			$custom_fields[ $field_id ] = BWFAN_Common::decode_merge_tags( $fields_value[ $key1 ] );
		}
		$data_to_set['custom_fields'] = $custom_fields;
		$data_to_set['url']           = BWFAN_Common::decode_merge_tags( $post['data']['url'] );
		$data_to_set['test']          = true;

		$action_object->set_data( $data_to_set );
		$response = $action_object->process();

		if ( false !== $response ) {
			$result['msg']    = __( 'Test Data sent to Pabbly.', 'wp-marketing-automations-pro' );
			$result['status'] = true;
		}
		//phpcs:enable WordPress.Security.NonceVerification
		wp_send_json( $result );
	}

	public static function five_minute_worker_cb() {
		/** v1 automations */
		$active_automations = BWFAN_Core()->automations->get_active_automations( 1 );
		if ( is_array( $active_automations ) && 0 < count( $active_automations ) ) {
			do_action( 'bwfan_5_min_action', $active_automations );
		}

		/** v2 automations */
		$active_automations = BWFAN_Core()->automations->get_active_automations( 2 );
		if ( is_array( $active_automations ) && 0 < count( $active_automations ) ) {
			do_action( 'bwfan_5_min_action', $active_automations );
		}
	}

	/**
	 * Passing language as a param in sync call for every event
	 * Used in order status pending event - get_event_data() as well
	 *
	 * @param $data
	 *
	 * @return mixed
	 * @throws Exception
	 */
	public static function passing_event_language( $data ) {
		/** checking for wpml plugin **/
		if ( defined( 'ICL_SITEPRESS_VERSION' ) && defined( 'ICL_LANGUAGE_CODE' ) ) {

			$lang = ICL_LANGUAGE_CODE;

			/** get order language in case order id set in the data */
			if ( ! empty( $data['order_id'] ) ) {
				$order          = wc_get_order( $data['order_id'] );
				$order_language = $order instanceof WC_Order ? $order->get_meta( 'wpml_language' ) : '';
				if ( ! empty( $order_language ) ) {
					$lang = $order_language;
				}
			}

			$data['language'] = $lang;

			return $data;
		}

		/** checking for polylang plugin **/
		if ( function_exists( 'pll_current_language' ) && function_exists( 'pll_get_post_language' ) ) {
			$lang = pll_current_language();

			/** get order language in case order id set in the data */
			if ( ! empty( $data['order_id'] ) ) {
				$order_language = pll_get_post_language( $data['order_id'] );
				if ( ! empty( $order_language ) ) {
					$lang = $order_language;
				}
			}

			$data['language'] = $lang;

			return $data;
		}

		/** checking for translate press **/
		if ( bwfan_is_translatepress_active() ) {
			$data['language'] = get_locale();

			return $data;
		}

		/** checking for weglot plugin */
		if ( defined( 'BWFAN_VERSION' ) && version_compare( BWFAN_VERSION, '2.0.2', '>' ) && bwfan_is_weglot_active() ) {
			$data['language'] = weglot_get_current_language();
			if ( ! isset( $data['order_id'] ) || empty( $data['order_id'] ) ) {
				return $data;
			}
			$order                  = wc_get_order( $data['order_id'] );
			$order_language         = $order instanceof WC_Order ? $order->get_meta( 'weglot_language' ) : '';
			$weglot_language_option = self::get_weglot_language_option();
			if ( ! array_key_exists( $order_language, $weglot_language_option ) ) {
				return $data;
			}

			$data['language'] = $order_language;

			return $data;
		}

		/** checking for gtranslate plugin */
		if ( function_exists( 'bwfan_is_gtranslate_active' ) && bwfan_is_gtranslate_active() ) {
			$data['language'] = BWFAN_Compatibility_With_GTRANSLATE::get_gtranslate_language();

			return $data;
		}

		/** checking for linguise plugin */
		if ( function_exists( 'bwfan_is_linguise_active' ) && bwfan_is_linguise_active() ) {
			$lang = '';
			if ( class_exists( '\Linguise\WordPress\Helper' ) ) {
				$lang = \Linguise\WordPress\Helper::getLanguage();
			}

			/** get order language in case order id set in the data */
			if ( ! empty( $data['order_id'] ) ) {
				$order          = wc_get_order( $data['order_id'] );
				$order_language = $order instanceof WC_Order ? $order->get_meta( 'linguise_language' ) : '';
				if ( ! empty( $order_language ) ) {
					$lang = $order_language;
				}
			}

			if ( ! empty( $lang ) ) {
				$data['language'] = $lang;
			}

			return $data;
		}

		return $data;
	}

	/**
	 * Weglot language options
	 *
	 * @return array
	 * @throws Exception
	 */
	public static function get_weglot_language_option() {
		$data            = Context_Weglot::weglot_get_context()->get_service( 'Language_Service_Weglot' )->get_original_and_destination_languages();
		$weglot_language = array();
		foreach ( $data as $lang_key => $lang ) {
			if ( ! $lang instanceof Weglot\Client\Api\LanguageEntry ) {
				continue;
			}
			$weglot_language[ $lang->getInternalCode() ] = $lang->getLocalName();
		}

		return $weglot_language;
	}

	/**
	 * Populate cart from order key
	 *
	 * @throws Exception
	 */
	public static function bwfan_populate_cart_from_order() {
		if ( ! bwfan_is_woocommerce_active() ) {
			return;
		}

		if ( ! isset( $_GET['bwfan-order-again'] ) || empty( $_GET['bwfan-order-again'] ) ) {
			return;
		}

		/** wp_loaded also fires on admin, REST and cron requests, where WC creates no cart or session */
		if ( ! WC()->cart instanceof WC_Cart || ! WC()->session instanceof WC_Session ) {
			return;
		}

		/** Order key only. A bare order id would let anyone load any order's items into their cart */
		$order_id = wc_get_order_id_by_order_key( sanitize_text_field( wp_unslash( $_GET['bwfan-order-again'] ) ) );

		$order = wc_get_order( $order_id );
		if ( ! $order instanceof WC_Order || ! $order->has_status( apply_filters( 'woocommerce_valid_order_statuses_for_order_again', array( 'completed', 'processing' ) ) ) ) {
			return;
		}
		/** empty cart **/
		WC()->cart->empty_cart();
		/** Make sure a brand-new guest gets a session cookie */
		WC()->session->set_customer_session_cookie( true );
		$order_items = $order->get_items();

		if ( ! is_array( $order_items ) || 0 === count( $order_items ) ) {
			return;
		}

		foreach ( $order_items as $item ) {

			if ( ! $item instanceof WC_Order_Item_Product ) {
				continue;
			}

			$product_id     = (int) apply_filters( 'woocommerce_add_to_cart_product_id', $item->get_product_id() );
			$quantity       = $item->get_quantity();
			$variation_id   = (int) $item->get_variation_id();
			$variations     = array();
			$cart_item_data = apply_filters( 'woocommerce_order_again_cart_item_data', array(), $item, $order );
			$product        = $item->get_product();

			if ( ! $product instanceof WC_Product ) {
				continue;
			}

			/** Prevent reordering variable products if no selected variation */
			if ( ! $variation_id && $product->is_type( 'variable' ) ) {
				continue;
			}

			/** Stock left for this item, counting what earlier lines of the same order already put in the cart */
			$available = PHP_INT_MAX;
			if ( $product->managing_stock() && ! $product->backorders_allowed() ) {
				$in_cart   = WC()->cart->get_cart_item_quantities();
				$available = (int) $product->get_stock_quantity() - (int) ( $in_cart[ $product->get_stock_managed_by_id() ] ?? 0 );
			}

			/** Prevent reordering items specifically out of stock */
			if ( ! $product->is_in_stock() || $available < 1 ) {
				/* translators: %s: product name */
				wc_add_notice( sprintf( __( '"%s" is out of stock and could not be added to your cart.', 'wp-marketing-automations-pro' ), $product->get_name() ), 'error' );
				continue;
			}

			/** Reduce the quantity to what is in stock, instead of skipping the item */
			if ( $available < $quantity ) {
				/* translators: 1: quantity added 2: product name */
				wc_add_notice( sprintf( __( 'Only %1$d of "%2$s" was available, so we added %1$d to your cart.', 'wp-marketing-automations-pro' ), $available, $product->get_name() ), 'notice' );
				$quantity = $available;
			}

			foreach ( $item->get_meta_data() as $meta ) {
				if ( taxonomy_is_product_attribute( $meta->key ) ) {
					$term                     = get_term_by( 'slug', $meta->value, $meta->key );
					$variations[ $meta->key ] = $term ? $term->name : $meta->value;
				} elseif ( meta_is_product_attribute( $meta->key, $meta->value, $product_id ) ) {
					$variations[ $meta->key ] = $meta->value;
				}
			}

			if ( ! apply_filters( 'woocommerce_add_to_cart_validation', true, $product_id, $quantity, $variation_id, $variations, $cart_item_data ) ) {
				continue;
			}

			/** Add to cart directly */
			WC()->cart->add_to_cart( $product_id, $quantity, $variation_id, $variations, $cart_item_data );
		}

		/** Clear show notices for added coupons or products */
		if ( ! is_null( WC()->session ) ) {
			$notices = wc_get_notices();
			unset( $notices['success'] );
			WC()->session->set( 'wc_notices', $notices );
		}
		/** Redirect so the cookie is sent and the query arg is removed */
		wc_nocache_headers();
		wp_safe_redirect( wc_get_cart_url() );
		exit;
	}

	public static function get_bwf_customer_by_email( $email ) {
		$bwf_contact = self::get_bwf_contact_by_email( $email );
		if ( ! $bwf_contact instanceof WooFunnels_Contact ) {
			return false;
		}

		$customer = new WooFunnels_Customer( $bwf_contact );

		if ( ! isset( $customer->id ) || ! $customer->id > 0 ) {
			return false;
		}

		return $customer;
	}

	public static function get_bwf_contact_by_email( $email ) {
		$contact = self::get_contact_by_email( $email );
		if ( ! isset( $contact->wpid ) ) {
			return false;
		}

		$bwf_contact = bwf_get_contact( $contact->wpid, $email );
		if ( $bwf_contact instanceof WooFunnels_Customer ) {
			return $bwf_contact->contact;
		}

		if ( $bwf_contact instanceof WooFunnels_Contact ) {
			return $bwf_contact;
		}

		return false;
	}

	public static function get_contact_by_email( $email ) {
		if ( ! is_email( $email ) || ! class_exists( 'WooFunnels_DB_Operations' ) ) {
			return false;
		}

		$contact_db  = WooFunnels_DB_Operations::get_instance();
		$contact_obj = $contact_db->get_contact_by_email( $email );

		if ( ! isset( $contact_obj->id ) || ! $contact_obj->id > 0 ) {
			return false;
		}

		return $contact_obj;
	}

	public static function get_contact_meta( $contact_id, $key = '' ) {
		$contact_id = absint( $contact_id );
		if ( ! $contact_id > 0 ) {
			return false;
		}

		$contact_db   = WooFunnels_DB_Operations::get_instance();
		$contact_meta = $contact_db->get_contact_metadata( $contact_id );
		if ( ! is_array( $contact_meta ) || empty( $contact_meta ) ) {
			return false;
		}

		$contact_meta_array = array();
		foreach ( $contact_meta as $meta ) {
			$contact_meta_array[ $meta->meta_key ] = maybe_unserialize( $meta->meta_value );
		}

		if ( empty( $key ) ) {
			return $contact_meta_array;
		}

		if ( ! isset( $contact_meta_array[ $key ] ) ) {
			return false;
		}

		return $contact_meta_array[ $key ];
	}

	public static function insert_default_crm_fields() {
		global $wpdb;
		$crm_fields_table = $wpdb->prefix . 'bwfan_fields';
		$default_fields   = self::$crm_default_fields;
		$db_errors        = [];
		foreach ( $default_fields as $field => $field_data ) {
			$already_exist = self::check_field_exist( $field );
			if ( $already_exist ) {
				continue;
			}
			$data = [
				'name'       => $field_data['name'],
				'slug'       => $field,
				'type'       => $field_data['type'],
				'gid'        => 0,
				'meta'       => wp_json_encode( $field_data['meta'] ),
				'mode'       => $field_data['mode'],
				'vmode'      => $field_data['vmode'],
				'view'       => $field_data['view'],
				'search'     => 1,
				'created_at' => current_time( 'mysql', 1 ),
			];
			$wpdb->insert( $crm_fields_table, $data ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$field_id = $wpdb->insert_id;
			if ( ! empty( $wpdb->last_error ) ) {
				$db_errors[] = 'Error in default field creation: ' . $field_data['name'] . ' ' . $wpdb->last_error;
			}
			/** Check field column exist in contact_fields table **/
			$exists = BWF_Model_Contact_Fields::column_already_exists( $field_id );
			if ( empty( $exists ) ) {
				$column_added = BWF_Model_Contact_Fields::add_column_field( $field_id, 1 );
				/** If column not added */
				if ( true !== $column_added ) {
					BWFAN_Model_Fields::delete( $field_id );
					$db_errors[] = 'Error in contact field column creation: ' . $column_added;
				}
			}
		}
		/** Log if any mysql errors */
		if ( ! empty( $db_errors ) ) {
			BWFAN_PRO_Common::log_test_data( array_merge( [ __FUNCTION__ ], $db_errors ), 'field-creation-error' );
		}
	}

	/**
	 * Checking if field with slug exists or not
	 *
	 * @param $slug
	 *
	 * @return bool
	 */
	public static function check_field_exist( $slug ) {
		global $wpdb;
		$query  = $wpdb->prepare( "SELECT `ID` FROM `{$wpdb->prefix}bwfan_fields` WHERE `slug` = %s LIMIT 0, 1", $slug );
		$result = $wpdb->get_var( $query ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return ! empty( $result );
	}

	/**
	 *
	 */
	public static function bwfan_added_pro_tables( $tables ) {
		global $wpdb;

		$tables[] = $wpdb->prefix . 'bwfan_engagement_tracking';
		$tables[] = $wpdb->prefix . 'bwfan_engagement_trackingmeta';
		$tables[] = $wpdb->prefix . 'bwfan_conversions';
		$tables[] = $wpdb->prefix . 'bwfan_templates';
		$tables[] = $wpdb->prefix . 'bwfan_terms';
		$tables[] = $wpdb->prefix . 'bwfan_fields';
		$tables[] = $wpdb->prefix . 'bwfan_field_groups';
		$tables[] = $wpdb->prefix . 'bwfan_contact_note';
		$tables[] = $wpdb->prefix . 'bwfan_import_export';
		$tables[] = $wpdb->prefix . 'bwfan_broadcast';
		$tables[] = $wpdb->prefix . 'bwf_contact_fields';
		$tables[] = $wpdb->prefix . 'bwfan_form_feeds';
		$tables[] = $wpdb->prefix . 'bwfan_message';

		return $tables;
	}

	/**
	 * Getting contact id from phone number
	 *
	 * @param $phone
	 *
	 * @return int
	 */
	public static function get_contact_id_by_phone( $phone ) {
		global $wpdb;
		$query = $wpdb->prepare( "SELECT `id` FROM `{$wpdb->prefix}bwf_contact` WHERE RIGHT(contact_no,10) = %s ORDER BY `id` DESC LIMIT 0,1", $phone );
		$cid   = $wpdb->get_var( $query ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return empty( $cid ) ? 0 : intval( $cid );
	}

	/**
	 * Get paid orders count
	 *
	 * @param $renewal_orders
	 *
	 * @return int
	 */
	public static function get_paid_orders_count( $renewal_orders ) {
		if ( method_exists( 'BWFAN_Common', 'get_paid_orders_count' ) ) {
			return BWFAN_Common::get_paid_orders_count( $renewal_orders );
		}

		if ( empty( $renewal_orders ) ) {
			return 0;
		}
		$paid_statuses = wc_get_is_paid_statuses();
		if ( empty( $paid_statuses ) ) {
			return 0;
		}
		$orders = array_filter( $renewal_orders, function ( $order_id ) use ( $paid_statuses ) {
			$order = wc_get_order( $order_id );

			return ( $order instanceof WC_ORDER && $order->has_status( $paid_statuses ) );
		} );

		return count( $orders );
	}

	public static function bwfan_delete_invalid_conversions() {
		if ( ! function_exists( 'wc_get_order' ) ) {
			delete_option( 'bwfan_db_1_3_3_options' );
			bwf_unschedule_actions( 'bwfan_check_conversion_validity' );

			return;
		}

		$last_conversion_id = get_option( 'bwfan_db_1_3_3_options' );
		if ( ! is_array( $last_conversion_id ) || empty( $last_conversion_id ) ) {
			delete_option( 'bwfan_db_1_3_3_options' );
			bwf_unschedule_actions( 'bwfan_check_conversion_validity' );

			return;
		}

		$last_conversion_id = absint( $last_conversion_id['last_conversion_id'] );
		$conversions        = BWFAN_Model_Conversions::get_conversions_for_check_validity( absint( $last_conversion_id ) );
		if ( empty( $conversions ) ) {
			delete_option( 'bwfan_db_1_3_3_options' );
			bwf_unschedule_actions( 'bwfan_check_conversion_validity' );

			return;
		}

		$start_time = time();
		foreach ( $conversions as $index => $conversion ) {
			$order = wc_get_order( $conversion['wcid'] );
			if ( ! $order instanceof WC_Order || ! in_array( $order->get_status(), wc_get_is_paid_statuses() ) || 'trash' === get_post_status( $order->get_id() ) ) {
				BWFAN_Model_Conversions::delete( $conversion['ID'] );
			}

			if ( ! isset( $conversions[ $index + 1 ] ) ) {
				delete_option( 'bwfan_db_1_3_3_options' );
				bwf_unschedule_actions( 'bwfan_check_conversion_validity' );
				break;
			}

			$next_conversion = $conversions[ $index + 1 ];
			update_option( 'bwfan_db_1_3_3_options', [ 'last_conversion_id' => $next_conversion['ID'] ], false );
			if ( ( time() - $start_time ) >= 30 || BWFCRM_Common::memory_exceeded() ) {
				break;
			}
		}
	}

	public static function remove_actions( $hook, $cls, $function = '' ) {
		global $wp_filter;
		$object = null;
		if ( class_exists( $cls ) && isset( $wp_filter[ $hook ] ) && ( $wp_filter[ $hook ] instanceof WP_Hook ) ) {
			$hooks = $wp_filter[ $hook ]->callbacks;
			foreach ( $hooks as $priority => $reference ) {
				if ( is_array( $reference ) && count( $reference ) > 0 ) {
					foreach ( $reference as $index => $calls ) {
						if ( isset( $calls['function'] ) && is_array( $calls['function'] ) && count( $calls['function'] ) > 0 ) {
							if ( is_object( $calls['function'][0] ) ) {
								$cls_name = get_class( $calls['function'][0] );
								if ( $cls_name == $cls && $calls['function'][1] == $function ) {
									$object = $calls['function'][0];
									unset( $wp_filter[ $hook ]->callbacks[ $priority ][ $index ] );
								}
							} elseif ( $index == $cls . '::' . $function ) {
								// For Static Classess
								$object = $cls;
								unset( $wp_filter[ $hook ]->callbacks[ $priority ][ $cls . '::' . $function ] );
							}
						}
					}
				}
			}
		} elseif ( function_exists( $cls ) && isset( $wp_filter[ $hook ] ) && ( $wp_filter[ $hook ] instanceof WP_Hook ) ) {

			$hooks = $wp_filter[ $hook ]->callbacks;
			foreach ( $hooks as $priority => $reference ) {
				if ( is_array( $reference ) && count( $reference ) > 0 ) {
					foreach ( $reference as $index => $calls ) {
						$remove = false;
						if ( $index == $cls ) {
							$remove = true;
						} elseif ( isset( $calls['function'] ) && $cls == $calls['function'] ) {
							$remove = true;
						}
						if ( true == $remove ) {
							unset( $wp_filter[ $hook ]->callbacks[ $priority ][ $cls ] );
						}
					}
				}
			}
		}

		return $object;

	}

	/**
	 * Get the complete phone number of a contact with a country code
	 *
	 * @param $contact_obj WooFunnels_Contact
	 *
	 * @return mixed|string|void
	 */
	public static function get_contact_full_number( $contact_obj ) {
		if ( ! $contact_obj instanceof WooFunnels_Contact || 0 === absint( $contact_obj->get_id() ) ) {
			return '';
		}
		$phone = $contact_obj->get_contact_no();
		if ( empty( $phone ) ) {
			return '';
		}
		$country = $contact_obj->get_country();
		if ( ! empty( $country ) ) {
			$phone = BWFAN_Phone_Numbers::add_country_code( $phone, $country );
		}

		return $phone;
	}

	public static function get_tags( $searched_term ) {
		if ( ! class_exists( 'BWFCRM_Tag' ) ) {
			return [];
		}

		$tag_data = BWFCRM_Tag::get_tags( [], $searched_term );

		return self::prepare_data( $tag_data, 'tag' );
	}

	public static function prepare_data( $data, $type ) {
		$results   = [];
		$results[] = [ 'id' => 'any', 'text' => 'Any ' . $type ];

		foreach ( $data as $tag ) {
			$results[] = array(
				'id'   => $tag['ID'],
				'text' => $tag['name'],
			);
		}

		return $results;
	}

	public static function get_lists( $searched_term ) {
		if ( ! class_exists( 'BWFCRM_Lists' ) ) {
			return [];
		}

		$tag_data = BWFCRM_Lists::get_lists( [], $searched_term );

		return self::prepare_data( $tag_data, 'list' );
	}

	public static function get_contact_data_counts( $exclude_unsubs = false ) {
		$bulk_actions_count        = BWFAN_Model_Bulk_Action::get_bulk_actions_total_count( false );
		$bulk_actions_all_count    = isset( $bulk_actions_count['all'] ) ? $bulk_actions_count['all'] : 0;
		$bulk_actions_active_count = isset( $bulk_actions_count['1'] ) ? $bulk_actions_count['1'] : 0;

		return [
			'contacts_contacts'            => 0,
			'contacts_manage_audiences'    => 0,
			'contacts_manage_fields'       => 0,
			'contacts_manage_lists'        => 0,
			'contacts_manage_tags'         => 0,
			'contacts_bulk_actions'        => $bulk_actions_all_count,
			'contacts_active_bulk_actions' => $bulk_actions_active_count,
		];
	}

	public static function get_broadcast_data_count( $type = '' ) {
		if ( empty( $type ) ) {
			return [];
		}
		$status_count = BWFAN_Model_Broadcast::get_broadcast_total_count_by_status( $type );

		return [
			'broadcasts_email'    => 0,
			'broadcasts_sms'      => 0,
			'broadcasts_whatsapp' => 0,
			'status_scheduled'    => $status_count['2'],
			'status_ongoing'      => $status_count['3'],
			'status_completed'    => $status_count['4'],
			'status_cancelled'    => $status_count['7'],
			'status_paused'       => intval( $status_count['5'] ) + intval( $status_count['6'] ),
			'status_all'          => isset( $status_count['status_all'] ) ? $status_count['status_all'] : 0,
		];
	}

	/**
	 * Get form count by status
	 *
	 * @return array
	 */
	public static function get_forms_data_count() {
		$count = BWFAN_Model_Form_Feeds::get_forms_total_count();

		return [
			'forms_all'      => $count['all'],
			'forms_draft'    => $count['1'],
			'forms_active'   => $count['2'],
			'forms_inactive' => $count['3'],
		];
	}

	/**
	 * Return link trigger count array with status
	 *
	 * @return array
	 */
	public static function get_link_triggers_data_count() {
		$count = BWFAN_Model_Link_Triggers::get_link_triggers_total_count();

		return [
			'link-triggers_all'      => $count['all'],
			'link-triggers_draft'    => $count['0'],
			'link-triggers_inactive' => $count['1'],
			'link-triggers_active'   => $count['2'],
		];
	}

	/**
	 * Return bulk action count array with status
	 *
	 * @return array
	 */
	public static function get_bulk_actions_data_count() {
		$count = BWFAN_Model_Bulk_Action::get_bulk_actions_total_count();

		return [
			'all'       => $count['all'],
			'draft'     => $count['0'],
			'ongoing'   => $count['1'],
			'completed' => $count['2'],
			'paused'    => $count['3'],
		];
	}

	/**
	 * Returns country iso code
	 *
	 * @param $country
	 *
	 * @return string
	 */
	public static function get_country_iso_code( $country ) {
		$country = strtolower( $country );

		$countries     = self::get_countries_data();
		$countries_iso = array_keys( $countries );
		$countries_iso = array_map( function ( $j ) {
			return strtolower( $j );
		}, $countries_iso );

		if ( in_array( $country, $countries_iso, true ) ) {
			/** Country found */
			return strtoupper( $country );
		}

		/** Country array with 2 digit key and lower names as value */
		$countries_lower = array_map( function ( $j ) {
			return strtolower( $j );
		}, $countries );

		if ( in_array( $country, $countries_lower, true ) ) {
			/** Country found */
			$index = array_search( $country, $countries_lower );

			return strtoupper( $index );
		}

		return '';
	}

	/** countries data
	 * @return mixed|null
	 */
	public static function get_countries_data() {
		$countries_json = file_get_contents( BWFAN_PRO_PLUGIN_DIR . '/includes/countries.json' );
		$countries      = json_decode( $countries_json, true );

		return $countries;
	}

	public static function get_country_name( $country_code ) {
		$country_code = strtoupper( $country_code );
		$countries    = self::get_countries_data();

		if ( isset( $countries[ $country_code ] ) ) {
			return $countries[ $country_code ];
		}

		return $country_code;
	}

	/**
	 * @param $global_data
	 *
	 * @return int
	 */
	public static function maybe_get_user_id_from_task_meta( $task_meta ) {
		/** Get User ID */
		if ( isset( $task_meta['user_id'] ) && ! empty( $task_meta['user_id'] ) ) {
			return $task_meta['user_id'];
		}

		/** Get User ID by Email */
		if ( isset( $task_meta['email'] ) && is_email( $task_meta['email'] ) ) {
			$email = $task_meta['email'];

			/** Check if User exists by this email */
			$user_data = get_user_by( 'email', $email );
			if ( $user_data instanceof WP_User ) {
				return $user_data->ID;
			}

			/** Create user if not exists, and email exists and valid */
			$user_id = wp_create_user( $email, wp_generate_password(), $email );
			if ( ! is_wp_error( $user_id ) ) {
				return $user_id;
			}
		}

		/** get user id from the contact if wpid available */
		if ( isset( $task_meta['contact_id'] ) && ! empty( $task_meta['contact_id'] ) ) {
			$contact = new BWFCRM_Contact( $task_meta['contact_id'] );
			if ( ! $contact->is_contact_exists() ) {
				return false;
			}

			$user_id = $contact->contact->get_wpid();
			if ( ! empty( $user_id ) ) {
				return $user_id;
			}

			/*** if still user id not associate with contact then get using the contact email */
			$contact_email = $contact->contact->get_email();
			$user_data     = get_user_by( 'email', $contact_email );
			if ( $user_data instanceof WP_User && ! empty( $user_data->ID ) ) {
				return $user_data->ID;
			}

			/** if still user not exists with the contact email then create the user and bind with contact */
			$password = wp_generate_password();
			$user_id  = wp_create_user( $contact_email, $password, $contact_email );

			/** if error in user_id then return blank */
			if ( is_wp_error( $user_id ) ) {
				return false;
			}

			/** create display name using first name and appending lastname to it if available*/
			$display_name = trim( $contact->contact->get_f_name() );
			$display_name = empty( $display_name ) ? trim( $contact->contact->get_l_name() ) : $display_name . ' ' . trim( $contact->contact->get_l_name() );;
			if ( ! empty( trim( $display_name ) ) ) {
				wp_update_user( array( 'ID' => $user_id, 'display_name' => trim( $display_name ) ) );
			}

			$user = new WP_User( $user_id );
			$user->set_role( 'subscriber' );

			$user_first_name = trim( $contact->contact->get_f_name() );
			$user_last_name  = trim( $contact->contact->get_l_name() );
			$nickname        = trim( $user_first_name );
			! empty( $user_first_name ) && update_user_meta( $user_id, 'first_name', $user_first_name );
			! empty( $user_last_name ) && update_user_meta( $user_id, 'last_name', $user_last_name );
			! empty( $nickname ) && update_user_meta( $user_id, 'nickname', $nickname );

			$contact->contact->set_wpid( $user_id );
			$contact->contact->save();
			$contact->contact->update_meta( 'bwfan_userpassword', $password );

			return $user_id;
		}

		return false;
	}

	/** return links triggers on searching in automations */
	public static function get_link_triggers( $searched_term ) {
		if ( ! class_exists( 'BWFAN_Model_Link_Triggers' ) ) {
			return [];
		}

		$link_data = BWFAN_Model_Link_Triggers::get_link_triggers( $searched_term, '', 10, 0 );

		if ( ! isset( $link_data['links'] ) || empty( $link_data['links'] ) ) {
			return [];
		}

		$link = array();

		foreach ( $link_data['links'] as $link_index => $links ) {
			$link[ $link_index ]['id']   = $links['ID'];
			$link[ $link_index ]['text'] = $links['title'];
		}

		return $link;
	}

	/**
	 * Add UTM parameters in test email or sms for broadcast
	 *
	 * @param $body
	 * @param $args
	 *
	 * @return array|mixed|string|string[]|null
	 */
	public static function add_test_broadcast_utm_params( $body, $args, $mode = 'email' ) {
		$utm_data = array();

		/** Normalise Data */
		if ( isset( $args['utmContent'] ) ) {
			$utm_data['utm_content'] = $args['utmContent'];
		}

		if ( isset( $args['utmMedium'] ) ) {
			$utm_data['utm_medium'] = $args['utmMedium'];
		}

		if ( isset( $args['utmName'] ) ) {
			$utm_data['utm_name'] = $args['utmName'];
		}

		if ( isset( $args['utmSource'] ) ) {
			$utm_data['utm_source'] = $args['utmSource'];
		}

		if ( isset( $args['utmTerm'] ) ) {
			$utm_data['utm_term'] = $args['utmTerm'];
		}

		if ( empty( $utm_data ) ) {
			return $body;
		}

		/** Add flag to append UTM Params */
		$utm_data['append_utm'] = 1;

		$ins = BWFAN_UTM_Tracking::get_instance();

		return $ins->maybe_add_utm_parameters( $body, $utm_data, $mode );
	}


	/**
	 * Get customer past purchased product by email and time
	 *
	 * @param $current_time
	 * @param $email
	 *
	 * @return array
	 */
	public static function get_customer_past_purchased_product( $current_time, $email ) {
		global $wpdb;

		$email = trim( $email );
		if ( empty( $email ) ) {
			return [];
		}

		$current_time = empty( $current_time ) ? current_time( 'mysql' ) : $current_time;

		$query  = $wpdb->prepare( "SELECT p.product_id FROM `{$wpdb->prefix}wc_order_product_lookup` AS `p` INNER JOIN `{$wpdb->prefix}wc_customer_lookup` AS `c` ON c.customer_id = p.customer_id  WHERE p.`date_created` < %s AND c.email = %s GROUP BY p.product_id", $current_time, $email );
		$result = $wpdb->get_results( $query, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		if ( empty( $result ) ) {
			return [];
		}

		return array_map( function ( $row ) {
			return $row['product_id'];
		}, $result );
	}

	/**
	 * Return regex pattern
	 *
	 * @param int $type
	 *
	 * @return string
	 */
	public static function get_regex_pattern( $type = 1 ) {
		$type = (int) $type;

		switch ( $type ) {
			case 1:
				/**
				 * [0] => href='https://google.com/?abcd=ss&utm_content=source'
				 * [1] => https://google.com/?abcd=ss&utm_content=source
				 */ return '/href=["\']?([^"\'>]+)["\']?/';
			case 2:
				/**
				 * [0] => <a href='https://...' class='any'>
				 */ return '/<a[^>]+href=[^>]+>/i';
			case 3:
				/**
				 * [0] => https://...
				 * A trailing "/?" stays in the match (e.g. {{reorder_last_order_url}} fallback), else params get appended before the "?"
				 */ return '#\bhttps?://[^,\s()<>]+(?:\([\w\d]+\)|/\?|([^,[:punct:]\s]|/))#';
			default:
				return '';
		}
	}

	/**
	 * v2 Method: Prepared options for field schema
	 *
	 * @param $options
	 *
	 * @return array
	 */
	public static function prepared_field_options( $options ) {
		if ( ! is_array( $options ) || empty( $options ) ) {
			return [];
		}
		$prepared_options = array_map( function ( $label, $value ) {
			return array(
				'label' => $label,
				'value' => $value,
			);
		}, $options, array_keys( $options ) );

		return $prepared_options;
	}

	public static function encrypt_32_bit_string( $str ) {
		if ( empty( $str ) ) {
			return '';
		}

		$r = strrev( $str );
		$n = [];
		for ( $i = 0; $i < strlen( $r ); $i ++ ) {
			$n[] = wp_rand( '0', '9' ) . $r[ $i ];
		}

		return implode( '', $n );
	}

	/**
	 * For AffiliateWP
	 *
	 * @param $user_id
	 *
	 * @return string|null
	 */
	public static function get_aff_id_by_user_id( $user_id ) {
		if ( 0 === absint( $user_id ) ) {
			return 0;
		}

		global $wpdb;

		$sql = $wpdb->prepare( "SELECT `affiliate_id` FROM {$wpdb->prefix}affiliate_wp_affiliates WHERE `user_id` = %d", $user_id );

		return $wpdb->get_var( $sql ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * Search string from given array
	 *
	 * @param $data
	 * @param $search
	 *
	 * @return array
	 */
	public static function search_srting_from_data( $data, $search ) {

		if ( empty( $data ) || ! is_array( $data ) ) {
			return [];
		}

		if ( empty( $search ) ) {
			return $data;
		}

		return array_filter( $data, function ( $post ) use ( $search ) {
			return false !== strpos( strtolower( $post ), strtolower( $search ) );
		} );
	}

	/**
	 * Get or create Tag/List if not exists
	 *
	 * @param $terms
	 * @param $type
	 *
	 * @return array
	 */
	public static function get_or_create_terms( $terms, $type ) {
		if ( method_exists( 'BWFAN_Common', 'get_or_create_terms' ) ) {
			return BWFAN_Common::get_or_create_terms( $terms, $type );
		}

		$terms = array_map( function ( $term ) {
			if ( isset( $term['name'] ) ) {
				$term['value'] = $term['name'];
			}

			return $term;
		}, $terms );

		$terms = BWFCRM_Term::get_or_create_terms( $terms, $type, true );

		/**Prepared Data */
		$terms = array_map( function ( $term ) {
			$term_data         = [];
			$term_data['id']   = $term->get_id();
			$term_data['name'] = $term->get_name();

			return $term_data;
		}, $terms );

		return $terms;
	}

	/**
	 * Get broadcasts id and name
	 *
	 * @param $term
	 *
	 * @return array
	 */
	public static function get_broadcasts_by_term( $term ) {
		$broadcasts = BWFAN_Model_Broadcast::get_broadcasts_titles( $term );
		if ( empty( $broadcasts ) ) {
			return [];
		}

		$arr = array();
		foreach ( $broadcasts as $campaigns ) {
			$arr[ $campaigns['id'] ] = $campaigns['title'];
		}

		return $arr;
	}

	public static function get_contacts_from_broadcast( $bid, $column = '' ) {
		global $wpdb;
		$sql   = "SELECT DISTINCT c.id FROM {$wpdb->prefix}bwf_contact as c LEFT JOIN {$wpdb->prefix}bwf_wc_customers as wc ON c.id = wc.cid  LEFT JOIN {$wpdb->prefix}bwfan_engagement_tracking as et ON c.id=et.cid";
		$column = in_array( $column, array( 'open', 'click' ), true ) ? $column : '';
		$where  = " WHERE ( c.email != '' AND c.email IS NOT NULL )";
		if ( empty( $column ) ) {
			$where .= $wpdb->prepare( " AND ( et.c_status=2 AND et.type = 2  AND et.oid = %d)", $bid );
		} else {
			$where .= $wpdb->prepare( " AND ( et.{$column}>0 AND et.c_status=2 AND et.type = 2  AND et.oid = %d)", $bid );
		}
		$sql = $sql . $where;

		return $wpdb->get_results( $sql, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	public static function get_engaged_or_unengaged_data_count( $where_query, $contact_id ) {
		global $wpdb;
		$sql   = "SELECT DISTINCT COUNT(c.id) FROM {$wpdb->prefix}bwf_contact as c LEFT JOIN {$wpdb->prefix}bwf_wc_customers as wc ON c.id = wc.cid LEFT JOIN {$wpdb->prefix}bwf_contact_fields as cm ON c.id=cm.cid";
		$where = " WHERE ( c.email != '' AND c.email IS NOT NULL )";
		$where .= $where_query; // pass-through fragment; callers must pass already-prepared SQL
		$where .= $wpdb->prepare( " AND c.id=%d", $contact_id );
		$sql   = $sql . $where;

		return $wpdb->get_var( $sql ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	public static function get_skip_conversion_automations() {
		global $wpdb;
		$skip_events = apply_filters( 'bwfan_skip_conversion_automations', [ 'wcs_before_renewal' ] );
		/** Create string placeholder */
		$placeholder = array_fill( 0, count( $skip_events ), '%s' );
		$placeholder = implode( ", ", $placeholder );

		$query = $wpdb->prepare( "SELECT `ID` FROM {$wpdb->prefix}bwfan_automations WHERE 1 = 1 AND `event` IN ($placeholder) ", $skip_events );

		$query_res = $wpdb->get_results( $query, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		if ( empty( $query_res ) ) {
			return [];
		}

		return array_column( $query_res, 'ID' );
	}


	/**
	 * Get quiz data on search for learndash event
	 *
	 * @param $searched_term
	 *
	 * @return mixed
	 */
	public static function get_quizzes( $searched_term ) {
		$results      = array();
		$query_params = array(
			'post_type'   => 'sfwd-quiz',
			'post_status' => 'publish',
		);

		if ( '' !== $searched_term ) {
			$query_params['s'] = $searched_term;
		}

		$query = new WP_Query( $query_params );
		if ( $query->found_posts > 0 ) {
			foreach ( $query->posts as $post ) {
				$results[] = array(
					'id'   => $post->ID,
					'text' => $post->post_title,
				);
			}
		}

		return $results;
	}

	/**
	 * Excluding the automation which have failed to match the event settings as we have bulk actions as well.
	 *
	 * @param $event_slug
	 * @param $automation_id
	 * @param $v
	 *
	 * @return void
	 */
	public static function exclude_invalid_automation( $event_slug, $automation_id, $v ) {
		// return if any of following data missing
		if ( empty( $v ) || empty( $event_slug ) || empty( $automation_id ) ) {
			return;
		}

		// unset automation from v1 automations
		if ( 'v1' === $v ) {
			if ( isset( BWFAN_Core()->public->active_automations[ $event_slug ] ) && isset( BWFAN_Core()->public->active_automations[ $event_slug ][ $event_slug ][ $automation_id ] ) ) {
				unset( BWFAN_Core()->public->active_automations[ $event_slug ][ $event_slug ][ $automation_id ] );
			}
		}

		// unset automation from v2 automations
		if ( 'v2' === $v ) {
			if ( isset( BWFAN_Core()->public->active_v2_automations[ $event_slug ][ $event_slug ][ $automation_id ] ) ) {
				unset( BWFAN_Core()->public->active_v2_automations[ $event_slug ][ $event_slug ][ $automation_id ] );
			}
		}
	}

	/**
	 * Create or update contact on form submit event
	 *
	 * @param $automation_data
	 */
	public static function maybe_create_update_contact( $automation_data ) {
		if ( empty( $automation_data ) ) {
			return;
		}

		$email = $automation_data['email'];

		if ( ! is_email( trim( $email ) ) ) {
			return;
		}

		$contact = new WooFunnels_Contact( '', $email, '', '', '' );
		$args    = [];
		if ( isset( $automation_data['first_name'] ) && ! empty( $automation_data['first_name'] ) ) {
			$args['f_name'] = $automation_data['first_name'];
		}

		if ( isset( $automation_data['last_name'] ) && ! empty( $automation_data['last_name'] ) ) {
			$args['l_name'] = $automation_data['last_name'];
		}

		if ( isset( $automation_data['contact_phone'] ) && ! empty( $automation_data['contact_phone'] ) ) {
			$args['contact_no'] = $automation_data['contact_phone'];
		}

		if ( isset( $automation_data['mark_contact_subscribed'] ) && 1 === absint( $automation_data['mark_contact_subscribed'] ) ) {
			$args['status'] = 1;
		}

		/** checking if contact not exists than create otherwise update */
		if ( ! $contact instanceof WooFunnels_Contact || 0 === absint( $contact->get_id() ) ) {
			$bwfcrm_contact = new BWFCRM_Contact( $email, true, $args );
		} else { // update first_name, last_name, phone and status
			$bwfcrm_contact = new BWFCRM_Contact( $contact, false, $args );
			$bwfcrm_contact->update( $args );
			if ( isset( $automation_data['mark_contact_subscribed'] ) && 1 === absint( $automation_data['mark_contact_subscribed'] ) ) {
				$bwfcrm_contact->resubscribe();
			}
		}
	}

	public static function get_emails_by_subject_in_data( $subject, $v ) {
		global $wpdb;
		$sql          = "SELECT `auto_step`.*,`auto_m`.`title` FROM {$wpdb->prefix}bwfan_automation_step AS `auto_step` JOIN {$wpdb->prefix}bwfan_automations as `auto_m` ON `auto_step`.`aid`=`auto_m`.`ID` WHERE `auto_step`.`action` LIKE '%s' && `auto_step`.`data` LIKE '%s' && `auto_step`.`status`=1 && `auto_m`.`v`='%d'";
		$prepared_sql = $wpdb->prepare( $sql, '%wp_sendemail%', '%' . $subject . '%', $v );
		$emails       = $wpdb->get_results( $prepared_sql, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		$final_array = [];
		foreach ( $emails as $email ) {
			$return          = array();
			$data            = json_decode( $email['data'], true );
			$db_subject      = isset( $data['sidebarData']['bwfan_email_data'] ) && isset( $data['sidebarData']['bwfan_email_data']['subject'] ) ? $data['sidebarData']['bwfan_email_data']['subject'] : '';
			$return['id']    = $email['ID'];
			$return['name']  = $db_subject;
			$return['title'] = $email['title'];
			$final_array[]   = $return;
		}

		return $final_array;
	}

	public static function get_contacts_engagement( $cid, $step_ids, $mode, $type, $field = 'open' ) {
		global $wpdb;

		if ( empty( $step_ids ) ) {
			return array();
		}

		$allowed_fields = array( 'open', 'click' );
		if ( ! in_array( $field, $allowed_fields, true ) ) {
			$field = 'open';
		}

		$step_id         = array_fill( 0, count( $step_ids ), '%d' );
		$format_step_ids = implode( ', ', $step_id );
		$sql             = "SELECT * FROM {$wpdb->prefix}bwfan_engagement_tracking WHERE `cid`='%d' && `mode`='%d' && `type`='%d' && `sid` IN ({$format_step_ids}) && `{$field}` >0"; // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		$params = array( $cid, $mode, $type );
		$params = array_merge( $params, $step_ids );

		$prepared_sql = $wpdb->prepare( $sql, ...$params ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

		return $wpdb->get_results( $prepared_sql, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	public static function get_sorted_fields( $fields ) {
		$sort_format = get_option( 'bwf_crm_field_sort', array() );
		if ( empty( $sort_format ) ) {
			return $fields;
		}
		$data = [];
		foreach ( $sort_format as $sort_data ) {
			if ( ! isset( $sort_data['fields'] ) ) {
				continue;
			}

			foreach ( $sort_data['fields'] as $field_id ) {
				if ( ! isset( $fields[ $field_id ] ) ) {
					continue;
				}

				$data[ $field_id ] = $fields[ $field_id ];
			}
		}

		/** Get newly added fields */
		$field_keys = array_keys( $fields );
		$data_keys  = array_keys( $data );
		$new_fields = array_diff( $field_keys, $data_keys );
		if ( 0 === count( $new_fields ) ) {
			return $data;
		}

		foreach ( $new_fields as $field_id ) {
			$data[ $field_id ] = $fields[ $field_id ];
		}

		return $data;
	}

	/**
	 * Get Contact id from contact object
	 *
	 * @param $email
	 * @param $user_id
	 * @param $phone
	 *
	 * @return int
	 */
	public static function get_cid_from_contact( $email = '', $user_id = 0, $phone = '' ) {
		if ( empty( $email ) && empty( $user_id ) && empty( $phone ) ) {
			return 0;
		}
		$contact = new WooFunnels_Contact( $user_id, $email, $phone );

		if ( $contact->get_id() > 0 ) {
			return $contact->get_id();
		}

		return 0;
	}

	/**
	 * Aman testing purpose only
	 *
	 * @param $data
	 * @param $file
	 * @param $force
	 *
	 * @return void
	 */
	public static function log_test_data( $data, $file = 'v2-automations', $force = false ) {
		if ( empty( $data ) ) {
			return;
		}
		if ( true === $force ) {
			add_filter( 'bwfan_before_making_logs', '__return_true' );
		}
		if ( is_array( $data ) ) {
			BWFAN_Core()->logger->log( print_r( $data, true ), $file );

			return;
		}
		BWFAN_Core()->logger->log( $data, $file );
	}

	/** check order contains subscriptions */
	public static function order_contains_subscriptions( $order_id ) {
		if ( empty( $order_id ) ) {
			return false;
		}

		if ( ! bwfan_is_woocommerce_subscriptions_active() || ! function_exists( 'wcs_order_contains_subscription' ) ) {
			return false;
		}
		/** Check if is renewal order */
		if ( function_exists( 'wcs_order_contains_renewal' ) && wcs_order_contains_renewal( $order_id ) && function_exists( 'wcs_get_subscriptions_for_renewal_order' ) ) {
			$subscriptions = wcs_get_subscriptions_for_renewal_order( $order_id );
			if ( ! empty( $subscriptions ) ) {
				return $subscriptions;
			}
		}

		$order_contain_subscription = wcs_order_contains_subscription( $order_id );
		if ( ! $order_contain_subscription ) {
			return false;
		}

		$order_subscriptions = wcs_get_subscriptions_for_order( $order_id );

		if ( empty( $order_subscriptions ) || ! is_array( $order_subscriptions ) ) {
			return false;
		}

		return $order_subscriptions;
	}

	/**
	 * Save email template in v1 automation
	 * @return void
	 */
	public static function bwf_save_email_template() {
		BWFAN_PRO_Common::nocache_headers();
		BWFAN_Common::check_nonce(); // phpcs:disable WordPress.Security.NonceVerification

		$post_data = $_POST;
		$mode_type = [
			'raw_template' => 1,
			'raw'          => 3,
			'editor'       => 4,
		];
		$template  = '';
		$error     = '';

		$title = isset( $post_data['title'] ) ? $post_data['title'] : '';

		/** Check for template name */
		if ( empty( $title ) ) {
			$error = __( 'Name is required', 'wp-marketing-automations-pro' );
		}

		$data    = isset( $post_data['data'] ) ? $post_data['data'] : [];
		$subject = isset( $data['subject'] ) ? $data['subject'] : '';

		/** Check for template subject */
		if ( empty( $subject ) ) {
			$error = __( 'Subject is required', 'wp-marketing-automations-pro' );
		}

		$mode = isset( $data['template'] ) && isset( $mode_type[ $data['template'] ] ) ? intval( $mode_type[ $data['template'] ] ) : 1;

		switch ( $mode ) {
			case 1:
				$template = isset( $data['body'] ) ? $data['body'] : '';
				break;
			case 3:
				$template = isset( $data['body_raw'] ) ? $data['body_raw'] : '';
				break;
			case 4:
				if ( isset( $data['editor'] ) && isset( $data['editor']['body'] ) ) {
					$template = $data['editor']['body'];
				}
				break;
		}

		/** Check for template body */
		if ( empty( $template ) ) {
			$error = __( 'Email body is required', 'wp-marketing-automations-pro' );
		}

		if ( ! empty( $error ) ) {
			wp_send_json( array(
				'status' => false,
				'msg'    => $error,
			) );
		}

		$m_data = [
			'preheader'  => isset( $data['preheading'] ) ? $data['preheading'] : '',
			'utmEnabled' => ( isset( $data['append_utm'] ) && intval( $data['append_utm'] ) === 1 ) ? true : false,
			'utm'        => [
				'source'  => isset( $data['utm_source'] ) ? $data['utm_source'] : '',
				'medium'  => isset( $data['utm_medium'] ) ? $data['utm_medium'] : '',
				'name'    => '',
				'content' => isset( $data['utm_campaign'] ) ? $data['utm_campaign'] : '',
				'term'    => isset( $data['utm_term'] ) ? $data['utm_term'] : '',
			],
		];

		if ( isset( $data['editor'] ) && isset( $data['editor']['design'] ) ) {
			$m_data['design'] = stripslashes( $data['editor']['design'] );
		}

		$create_time = current_time( 'mysql', 1 );

		$template_data = [
			'title'      => $title,
			'template'   => stripslashes( $template ),
			'subject'    => $subject,
			'type'       => 1,
			'mode'       => $mode,
			'canned'     => 1,
			'created_at' => $create_time,
			'updated_at' => $create_time,
			'data'       => wp_json_encode( $m_data ),
		];

		$result = BWFAN_Model_Templates::bwfan_create_new_template( $template_data );

		if ( ! $result ) {
			wp_send_json( array(
				'status' => false,
				'msg'    => __( 'Unable to saved template.', 'wp-marketing-automations-pro' ),
			) );
		}

		wp_send_json( array(
			'status' => true,
			'msg'    => __( 'Template saved successfully.', 'wp-marketing-automations-pro' ),
		) );
	}


	/**
	 * Get languages options if any language plugin is activated
	 *
	 * @param $settings
	 *
	 * @return array|mixed
	 * @throws Exception
	 */
	public static function get_language_settings( $settings = [] ) {
		$language_options = [];

		/** WPML */
		if ( function_exists( 'icl_get_languages' ) ) {
			$languages = icl_get_languages();
			if ( ! empty( $languages ) ) {
				foreach ( $languages as $language ) {
					$language_options[ $language['language_code'] ] = ! empty( $language['translated_name'] ) ? $language['translated_name'] : $language['native_name'];
				}
			}
		}

		/** Polylang */
		if ( function_exists( 'pll_the_languages' ) ) {
			try {
				$languages = pll_the_languages( array( 'raw' => 1, 'hide_if_empty' => 0 ) );
				if ( ! empty( $languages ) ) {
					foreach ( $languages as $language ) {
						$language_options[ $language['slug'] ] = $language['name'];
					}
				}
			} catch ( Error $e ) {
			}
		}

		/** TranslatePress **/
		if ( bwfan_is_translatepress_active() ) {
			$trp                 = TRP_Translate_Press::get_trp_instance();
			$trp_languages       = $trp->get_component( 'languages' );
			$trp_languages_array = $trp_languages->get_languages( 'english_name' );

			$languages = ! empty( get_option( 'trp_settings' ) ) ? get_option( 'trp_settings' ) : array();
			$languages = isset( $languages['translation-languages'] ) ? $languages['translation-languages'] : array();
			if ( ! empty( $languages ) ) {
				foreach ( $languages as $language ) {
					$language_options[ $language ] = $language;
				}
			}

			$language_options = array_intersect_key( $trp_languages_array, $language_options );
		}

		/** Weglot */
		if ( defined( 'BWFAN_VERSION' ) && version_compare( BWFAN_VERSION, '2.0.2', '>' ) && function_exists( 'bwfan_is_weglot_active' ) && bwfan_is_weglot_active() ) {
			$language_options = BWFAN_PRO_Common::get_weglot_language_option();
		}

		/** Linguise */
		if ( function_exists( 'bwfan_is_linguise_active' ) && bwfan_is_linguise_active() ) {
			$linguise_options = get_option( 'linguise_options' );
			if ( ! empty( $linguise_options ) && is_array( $linguise_options ) ) {
				$enabled   = isset( $linguise_options['enabled_languages'] ) ? $linguise_options['enabled_languages'] : [];
				$default   = isset( $linguise_options['default_language'] ) ? $linguise_options['default_language'] : '';
				$all_langs = array_merge( [ $default ], $enabled );
				$all_langs = array_filter( array_unique( $all_langs ) );

				/** Get human-readable names from Linguise's languages data */
				$lang_infos = class_exists( '\Linguise\WordPress\Helper' ) ? \Linguise\WordPress\Helper::getLanguagesInfos() : null;
				foreach ( $all_langs as $code ) {
					if ( $lang_infos && isset( $lang_infos->$code ) ) {
						$language_options[ $code ] = $lang_infos->$code->name;
					} else {
						$language_options[ $code ] = $code;
					}
				}
			}
		}

		if ( count( $language_options ) > 0 ) {
			$settings['enable_lang']  = 1;
			$settings['lang_options'] = $language_options;
		}

		return apply_filters( 'bwfan_enable_language_settings', $settings );
	}

	/**
	 * Get all active automation contact rows by contact id and automation id
	 *
	 * @param $automation_id
	 * @param $contact_id
	 *
	 * @return array|object|stdClass[]|null
	 */
	public static function get_automation_contact_rows( $automation_id, $contact_id ) {
		global $wpdb;

		$table = "{$wpdb->prefix}bwfan_automation_contact";
		$query = $wpdb->prepare( 'SELECT * FROM ' . $table . ' WHERE `aid` = %d AND `cid` = %d ORDER BY `ID` ', $automation_id, $contact_id );

		return $wpdb->get_results( $query, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	public static function get_midnight_store_time() {
		$timezone = new DateTimeZone( wp_timezone_string() );
		$date     = new DateTime();
		$date->modify( '+1 days' );
		$date->setTimezone( $timezone );
		$date->setTime( 0, 0, 0 );

		return $date->getTimestamp();
	}

	/**
	 * Checking if any languages enabled
	 *
	 * @return bool
	 * @throws Exception
	 */
	public static function is_language_enabled() {
		$language_data = self::get_language_settings();
		if ( ! is_array( $language_data ) ) {
			return false;
		}

		if ( isset( $language_data['enable_lang'] ) && 1 === intval( $language_data['enable_lang'] ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Get v2 automations (id and meta) based on the given event slug
	 *
	 * @param $event_slug
	 *
	 * @return array
	 */
	public static function get_all_automations_by_slug( $event_slug = '' ) {
		if ( empty( $event_slug ) ) {
			return [];
		}
		global $wpdb;
		$query = $wpdb->prepare( 'SELECT `ID` FROM {table_name} WHERE `v` = %d AND `event` = %s', 2, $event_slug );

		$all_automations = BWFAN_Model_Automations::get_results( $query );
		if ( 0 === count( $all_automations ) ) {
			return [];
		}

		$final_automation_data = [];
		foreach ( $all_automations as $automation ) {
			$id                           = $automation['ID'];
			$final_automation_data[ $id ] = [
				'id'   => $id,
				'meta' => BWFAN_Model_Automationmeta::get_automation_meta( $id ),
			];
		}

		return $final_automation_data;
	}

	/**
	 * Get Birthday min value
	 *
	 * @return false|string
	 */
	public static function get_birthday_min_value( $type = 'date' ) {
		$min_date = apply_filters( 'bwfan_set_birthday_min', false );
		if ( empty( $min_date ) ) {
			return false;
		}
		$date = DateTime::createFromFormat( 'Y-m-d', $min_date );
		if ( $type === 'year' ) {
			return $date->format( 'Y' );
		}

		return $date && $date->format( 'Y-m-d' ) === $min_date ? "min='$min_date'" : '';
	}

	/**
	 * Get Birthday min value
	 *
	 * @return false|string
	 */
	public static function get_birthday_max_value( $type = 'date' ) {
		$min_date = apply_filters( 'bwfan_set_birthday_max', false );
		if ( empty( $min_date ) ) {
			return false;
		}
		$date = DateTime::createFromFormat( 'Y-m-d', $min_date );
		if ( $type === 'year' ) {
			return $date->format( 'Y' );
		}

		return $date && $date->format( 'Y-m-d' ) === $min_date ? "max='$min_date'" : '';
	}

	/**
	 * Show the email content in browser
	 *
	 * @return void
	 */
	public static function load_view_in_browser_link_content() {
		$action = filter_input( INPUT_GET, 'bwfan-action' );
		if ( empty( $action ) || 'view_in_browser' !== $action ) {
			return;
		}

		$hash_code = filter_input( INPUT_GET, 'bwfan-ehash' );
		if ( empty( $hash_code ) ) {
			return;
		}

		global $wpdb;
		$engagement = $wpdb->get_row( $wpdb->prepare( "SELECT `ID`,`tid`,`oid`,`cid` FROM `{$wpdb->prefix}bwfan_engagement_tracking` WHERE `hash_code` = %s", $hash_code ), ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( empty( $engagement ) ) {
			return;
		}

		$e_id        = isset( $engagement['ID'] ) ? $engagement['ID'] : '';
		$oid         = isset( $engagement['oid'] ) ? $engagement['oid'] : '';
		$template_id = isset( $engagement['tid'] ) ? $engagement['tid'] : '';

		$query    = $wpdb->prepare( "SELECT `template`, `mode`,`type` FROM `{$wpdb->prefix}bwfan_templates` WHERE `ID` = %d LIMIT 0,1", $template_id );
		$response = $wpdb->get_row( $query, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( empty( $response ) || empty( $response['template'] ) ) {
			return;
		}

		$body = $response['template'];
		$mode = intval( $response['mode'] );
		$type = intval( $response['type'] );
		if ( method_exists( 'BWFAN_Common', 'bwfan_before_send_mail' ) && 1 === $type && 5 === $mode ) {
			BWFAN_Common::bwfan_before_send_mail();
			$body = BWFAN_Common::correct_shortcode_string( $body, $type );
		}

		$merge_tags = BWFAN_Model_Engagement_Trackingmeta::get_merge_tags( $e_id );
		foreach ( $merge_tags as $key => $value ) {
			$body = str_replace( $key, wp_kses_post( $value ), $body );
		}

		/** Append tracking code in body urls */
		$conversation_obj = new BWFAN_Email_Conversations();

		$body = $conversation_obj->add_tracking_code( $body, $engagement, $hash_code, $oid, true );
		$body = BWFAN_Common::bwfan_correct_protocol_url( $body );

		if ( 1 === intval( $mode ) ) {
			$body = BWFCRM_Common::emogrify_rich_text( $body );
		} else {
			$body = BWFCRM_Common::emogrify_html( $body );
		}

		if ( 5 === $mode && class_exists( 'BWFCRM_Block_Editor' ) ) {
			$global_val = BWFCRM_Block_Editor::$global_settings_var;
			if ( ! empty( $global_val ) ) {
				$global_val_k = array_keys( $global_val );
				$global_val_v = array_values( $global_val );
				$body         = str_replace( $global_val_k, $global_val_v, $body );
			}
		}

		self::secure_response_headers();
		echo $body; //phpcs:ignore WordPress.Security.EscapeOutput
		die;
	}

	/**
	 * Get template type
	 *
	 * @param $type_name
	 *
	 * @return int
	 */
	public static function get_email_template_type( $type_name ) {
		$type = 1;
		switch ( $type_name ) {
			case 'html':
				$type = 3;
				break;
			case 'editor':
				if ( bwfan_is_autonami_pro_active() ) {
					$type = 4;
				}
			case 'block':
				if ( bwfan_is_autonami_pro_active() ) {
					$type = 5;
				}
				break;
		}

		return $type;
	}

	/**
	 * Checks if HPOS enabled
	 *
	 * @return bool
	 */
	public static function is_hpos_enabled() {
		return ( class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' ) && method_exists( '\Automattic\WooCommerce\Utilities\OrderUtil', 'custom_orders_table_usage_is_enabled' ) && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled() );
	}

	public static function meta_array_flatten( $array ) {
		if ( ! is_array( $array ) ) {
			return [];
		}
		$data = [];
		foreach ( $array as $row ) {
			if ( empty( $row['meta_value'] ) ) {
				continue;
			}
			$modified = maybe_unserialize( $row['meta_value'] );
			$modified = bwf_is_json( $modified ) ? json_decode( $modified, true ) : $modified;

			$data[ $row['meta_key'] ] = $modified;
		}

		return $data;
	}

	/**
	 * Set headers to prevent caching
	 *
	 * @return void
	 */
	public static function nocache_headers() {
		do_action( 'litespeed_control_set_nocache', 'fkautomations' );
		if ( headers_sent() ) {
			return;
		}

		header( 'Cache-Control: no-cache, no-store, must-revalidate, max-age=0' );
		header( 'Pragma: no-cache' );
		header( 'Expires: Wed, 11 Jan 1984 05:00:00 GMT' );
		header( 'Last-Modified: false' );
	}

	/**
	 * Emit a baseline set of security headers on plugin-owned HTML responses.
	 * Skips CSP (needs Report-Only rollout + monitoring) — only emits the
	 * universally-safe non-CSP defenses (MIME sniffing, clickjacking, referrer leak).
	 *
	 * @return void
	 */
	public static function secure_response_headers() {
		if ( headers_sent() ) {
			return;
		}

		header( 'X-Content-Type-Options: nosniff' );
		header( 'X-Frame-Options: SAMEORIGIN' );
		header( 'Referrer-Policy: no-referrer' );
	}

	/**
	 * Get v2 automation contact run count
	 *
	 * @param $contact_id
	 * @param $automation_id
	 *
	 * @return int
	 */
	public static function get_v2_automation_contact_run_count( $contact_id, $automation_id ) {
		global $wpdb;

		/** Get run count from automation contact table */
		$query = "SELECT COUNT(`ID`) FROM {$wpdb->prefix}bwfan_automation_contact WHERE `cid` = %d AND `aid` = %d";;
		$active_run_count = $wpdb->get_var( $wpdb->prepare( $query, $contact_id, $automation_id ) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		/** Get run count from automation complete contact table */
		$query = "SELECT COUNT(`ID`) FROM {$wpdb->prefix}bwfan_automation_complete_contact WHERE `cid` = %d AND `aid` = %d";

		return intval( $active_run_count ) + intval( $wpdb->get_var( $wpdb->prepare( $query, $contact_id, $automation_id ) ) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * If url exists in excluded urls
	 *
	 * @param $url
	 *
	 * @return bool
	 */
	public static function is_exclude_url( $url ) {
		if ( empty( $url ) ) {
			return false;
		}

		$excluded_urls = [
			'fonts.googleapis.com',
			'mailto:',
			'tel:',
			'whatsapp:',
			'wa.me:',
			'//wa.me',
			't.me',
			'm.me',
			'x.com',
			'twitter.com',
			'linkedin.com',
			'instagram.com',
			'pinterest.com',
			'youtube.com',
			'youtu.be',
			'snapchat.com',
			'reddit.com',
			'tripadvisor.com',
			'meetup.com',
			'producthunt.com',
			'tinder.com',
			'tumblr.com',
			'music.apple.com',
			'open.spotify.com',
			'soundcloud.com',
			'yelp.com',
			'medium.com',
			'skype.com',
			'flickr.com',
			'github.com',
			'discord.gg',
			'tiktok.com',
			'zoom.us'
		];
		$excluded_urls = apply_filters( 'bwfan_exclude_click_track_urls', $excluded_urls );

		foreach ( $excluded_urls as $excluded_url ) {
			if ( $url === $excluded_url || false !== strpos( $url, $excluded_url ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * @param $link
	 *
	 * @return void
	 */
	public static function wp_redirect( $link ) {
		remove_all_filters( 'wp_redirect' );

		add_filter( 'allowed_redirect_hosts', function ( $allowed_hosts, $host ) use ( $link ) {
			/** Add link host in allowed hosts, because already checked link is valid or not */
			if ( $host === wp_parse_url( $link, PHP_URL_HOST ) ) {
				$allowed_hosts[] = $host;
			}

			return $allowed_hosts;
		}, 10, 2 );

		if ( ! headers_sent() ) {
			header( 'X-Robots-Tag: noindex, nofollow', true );
		}

		wp_safe_redirect( $link );
		exit;
	}

	/**
	 * Get unsubscribe link
	 *
	 * @param $data
	 *
	 * @return string
	 */
	public static function get_unsubscribe_link( $data ) {
		if ( method_exists( 'BWFAN_Common', 'get_unsubscribe_link' ) ) {
			return BWFAN_Common::get_unsubscribe_link( $data );
		}

		if ( empty( self::$unsubscribe_page_link ) ) {
			$global_settings = BWFAN_Common::get_global_settings();
			if ( ! isset( $global_settings['bwfan_unsubscribe_page'] ) || empty( $global_settings['bwfan_unsubscribe_page'] ) ) {
				return '';
			}
			$page                        = absint( $global_settings['bwfan_unsubscribe_page'] );
			self::$unsubscribe_page_link = get_permalink( $page );
		}

		if ( empty( $data ) || ! is_array( $data ) ) {
			return self::$unsubscribe_page_link;
		}

		if ( empty( $data['uid'] ) && isset( $data['contact_id'] ) ) {
			$contact = new WooFunnels_Contact( '', '', '', $data['contact_id'] );
			$uid     = ( $contact->get_id() > 0 ) ? $contact->get_uid() : '';

			if ( ! empty( $uid ) ) {
				$data['uid'] = $uid;
			}
			unset( $data['contact_id'] );
		}

		$data['bwfan-action'] = 'unsubscribe';

		return add_query_arg( $data, self::$unsubscribe_page_link );
	}

	/**
	 * Disable run v2 automation immediately
	 *
	 * @return void
	 */
	public static function disable_run_v2_automation_immediately() {
		$disable = apply_filters( 'bwfan_disable_run_v2_automation_immediately', true );
		add_filter( 'bwfan_run_v2_automation_immediately', function ( $run ) use ( $disable ) {
			return ! ( true === $disable );
		} );
	}

	/**
	 * Set automation ended reason in data
	 *
	 * @param $reason
	 * @param $data
	 *
	 * @return mixed
	 */
	public static function set_automation_ended_reason( $reason, $data ) {
		if ( method_exists( 'BWFAN_Common', 'set_automation_ended_reason' ) ) {
			BWFAN_Common::set_automation_ended_reason( $reason, $data );
		}
		$decoded_data               = ! empty( $data['data'] ) ? json_decode( $data['data'], true ) : [];
		$decoded_data['end_reason'] = $reason;
		$data['data']               = wp_json_encode( $decoded_data );

		return $data;
	}

	/**
	 * Get generic rules
	 *
	 * @return array
	 */
	public static function get_generic_rules() {
		if ( ! class_exists( 'BWFAN_Core' ) ) {
			return [];
		}
		$generic_rule_groups = [
			'bwf_contact_segments',
			'bwf_contact',
			'bwf_contact_fields',
			'bwf_contact_field',
			'bwf_contact_user',
			'bwf_contact_wc',
			'bwf_contact_geo',
			'bwf_engagement',
			'bwf_broadcast',
			'bwf_automation'
		];
		$rules_groups        = BWFAN_Core()->rules->get_all_groups();
		$rules               = apply_filters( 'bwfan_rule_get_rule_types', array() );

		$final_rules = array();
		foreach ( $generic_rule_groups as $group ) {
			if ( ! isset( $rules_groups[ $group ] ) || ! isset( $rules[ $group ] ) ) {
				continue;
			}

			$final_rules[ $group ] = $rules_groups[ $group ];

			$group_rules = $rules[ $group ];
			$rule_keys   = array_keys( $rules[ $group ] );

			$final_rules[ $group ]['rules'] = array_map( function ( $rule ) use ( $group_rules ) {
				$rules_loader = BWFAN_Rules_Loader::get_instance();
				$rule_array   = $rules_loader->get_rule_schema( $rule, [] );
				if ( empty( $rule_array ) ) {
					return false;
				}
				$rule_array['name'] = $group_rules[ $rule ];

				return $rule_array;
			}, $rule_keys );

			$final_rules[ $group ]['rules'] = array_filter( $final_rules[ $group ]['rules'] );
			if ( empty( $final_rules[ $group ]['rules'] ) ) {
				unset( $final_rules[ $group ] );
			}
		}

		return $final_rules;
	}

	/**
	 * Check lite plugin version is 3.0 or greater
	 *
	 * @return bool
	 */
	public static function is_lite_3_0() {
		return defined( 'BWFAN_VERSION' ) && version_compare( BWFAN_VERSION, '3.0.0', '>=' );
	}

	/**
	 * Optimize phone number by removing spaces, brackets, hyphens and retains the country code and numbers
	 *
	 * @param $phone
	 *
	 * @return array|mixed|string|string[]|null
	 */
	public static function modify_phone( $phone = '' ) {
		if ( empty( $phone ) ) {
			return $phone;
		}
		if ( method_exists( 'BWFAN_Common', 'modify_phone' ) ) {
			return BWFAN_Common::modify_phone( $phone );
		}

		return preg_replace( '/[\s\-()]+/', '', $phone );
	}

	/**
	 * Get wishlist data including product IDs, variation IDs, user ID, and title for a specific wishlist ID.
	 *
	 * @param int $wishlist_id The ID of the wishlist.
	 *
	 * @return array|bool An array of wishlist data with keys 'wishlist_id', 'user_id', 'title', 'product_ids', and 'variation_ids', or false if not found.
	 */
	public static function get_ti_wc_wishlist_data_by_id( $wishlist_id ) {
		if ( empty( $wishlist_id ) || ! is_numeric( $wishlist_id ) ) {
			return false;
		}
		global $wpdb;
		$query  = $wpdb->prepare( "SELECT lists.ID AS wishlist_id, lists.author AS user_id, lists.title,
                GROUP_CONCAT(items.product_id) AS product_ids,
                GROUP_CONCAT(items.variation_id) AS variation_ids
         FROM {$wpdb->prefix}tinvwl_lists AS lists
         JOIN {$wpdb->prefix}tinvwl_items AS items ON lists.ID = items.wishlist_id
         WHERE lists.ID = %d
         GROUP BY lists.ID", $wishlist_id );
		$result = $wpdb->get_row( $query, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		if ( empty( $result ) || ! is_array( $result ) ) {
			return false;
		}

		return [
			'wishlist_id' => $result['wishlist_id'],
			'user_id'     => $result['user_id'],
			'title'       => $result['title'],
			'product_ids' => explode( ',', $result['product_ids'] )
		];
	}

	/**
	 * @return void
	 */
	public static function validate_scheduled_recurring_actions() {
		if ( method_exists( 'BWFAN_Common', 'validate_scheduled_recurring_actions' ) ) {
			BWFAN_Common::validate_scheduled_recurring_actions();

			return;
		}
		$hooks = [
			[
				'name'       => 'bwfan_run_event_queue',
				'time'       => MINUTE_IN_SECONDS,
				'args'       => [],
				'group_slug' => ''
			],
			[
				'name'       => 'bwfan_run_queue_v2',
				'time'       => MINUTE_IN_SECONDS,
				'args'       => [],
				'group_slug' => ''
			],
			[
				'name'       => 'bwfcrm_broadcast_run_queue',
				'time'       => MINUTE_IN_SECONDS,
				'args'       => [],
				'group_slug' => 'bwfcrm'
			]
		];

		foreach ( $hooks as $hook ) {
			if ( bwf_has_action_scheduled( $hook['name'] ) ) {
				continue;
			}

			bwf_schedule_recurring_action( time(), $hook['time'], $hook['name'], $hook['args'], $hook['group_slug'] );
		}
	}

	public static function forms_fields_rules( $type, $condition_value, $value ) {
		$value = is_array( $value ) ? array_map( 'stripslashes', $value ) : stripslashes( $value );
		switch ( $type ) {
			case 'is':
				if ( is_array( $condition_value ) && is_array( $value ) ) {
					$result = count( array_intersect( $condition_value, $value ) ) > 0;
				} else {
					$result = in_array( $condition_value, $value );
				}
				break;
			case 'is_not':
				if ( is_array( $condition_value ) && is_array( $value ) ) {
					$result = count( array_intersect( $condition_value, $value ) ) === 0;
				} else {
					$result = ! in_array( $condition_value, $value );
				}
				break;
			case 'contains':
				if ( is_array( $value ) ) {
					$result = ! empty( array_filter( $value, function ( $element ) use ( $condition_value ) {
						return strpos( $element, $condition_value ) !== false;
					} ) );
					break;
				}

				$result = strpos( $value, $condition_value ) !== false;
				break;
			case 'not_contains':
				if ( is_array( $value ) ) {
					$result = ! empty( array_filter( $value, function ( $element ) use ( $condition_value ) {
						return strpos( $element, $condition_value ) === false;
					} ) );
					break;
				}

				$result = strpos( $value, $condition_value ) === false;
				break;
			case 'starts_with':
				$value  = isset( $value[0] ) && ! empty( $value[0] ) ? $value[0] : '';
				$length = strlen( $condition_value );
				$result = substr( $value, 0, $length ) === $condition_value;
				break;
			case 'ends_with':
				$value  = is_array( $value ) ? end( $value ) : $value;
				$length = strlen( $condition_value );
				if ( 0 === $length || ( $length > strlen( $value ) ) ) {
					$result = false;
					break;
				}
				$result = substr( $value, - $length ) === $condition_value;
				break;
			case 'is_blank':
				$result = empty( $value[0] );
				break;
			case 'is_not_blank':
				$result = ! empty( $value[0] );
				break;
			default:
				$result = false;
				break;
		}

		return $result;
	}

	/**
	 * Delete the unsent Engagements of a Broadcast
	 *
	 * Sent and bounced engagements are left alone - see the query below.
	 *
	 * @param $broadcast_id
	 * @param int $time time for which action should run
	 *
	 * @return bool
	 */
	public static function delete_engagements( $broadcast_id, $time = 20 ) {
		global $wpdb;
		/** Fetch engagement ids */

		/** absint to match how the action was scheduled - these args are compared as json */
		$broadcast_id = absint( $broadcast_id );
		$args         = array(
			'broadcast_id' => $broadcast_id,
		);
		$start_time   = time();

		/**
		 * Which rows count as "never went out" depends on the flow.
		 *
		 * v2 builds every engagement ahead of the send and marks a failed send as error, so both
		 * draft and error rows are ones a re-run has to rebuild. v1 creates and sends in the same
		 * breath: its error rows are sent attempts the provider rejected - the failed count on the
		 * report and the only record of why - and deleting them on cancel or unschedule erased
		 * that history for no gain. Only a v1 draft row, left by a run that died between insert
		 * and send, is a row that never went out.
		 *
		 * A cancelled v2 broadcast keeps its error rows as well. Cancel lands on a broadcast that
		 * is running or paused, and there a v2 error row is a send the provider rejected or a
		 * contact skipped at send time with the reason on record - the failed count on the report.
		 * The broadcast is over, nothing will rebuild those rows, so deleting them only erased the
		 * history. Unschedule and a reset still clear them: those throw the run away to build it again.
		 */
		$broadcast = BWFAN_Model_Broadcast::get( $broadcast_id );
		$statuses  = array( BWFAN_Email_Conversations::$STATUS_DRAFT );
		if ( is_array( $broadcast ) && BWFCRM_Broadcast_Helper::is_v2_broadcast( $broadcast ) && BWFCRM_Campaigns::$CAMPAIGN_CANCELLED !== absint( $broadcast['status'] ?? 0 ) ) {
			$statuses[] = BWFAN_Email_Conversations::$STATUS_ERROR;
		}
		$status_placeholders = implode( ', ', array_fill( 0, count( $statuses ), '%d' ) );

		do {
			/**
			 * Only the engagements that never went out.
			 *
			 * A broadcast is unscheduled with engagements already created but not yet sent - those
			 * are the rows that have to go, so a later run creates them fresh instead of skipping
			 * the contact as already engaged. Anything actually delivered (sent, and bounced, which
			 * only happens after a send) is history: it carries the opens, clicks and revenue the
			 * broadcast reports on, and those contacts must not be mailed a second time on a re-run.
			 */
			$e_ids = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->prefix}bwfan_engagement_tracking WHERE `oid` = %d AND `type` = %d AND `c_status` IN ( $status_placeholders ) ORDER BY ID LIMIT 1000", array_merge( array( $broadcast_id, BWFAN_Email_Conversations::$TYPE_CAMPAIGN ), $statuses ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL

			/**
			 * A failed read also comes back as an empty array. Treating it as "nothing left"
			 * would unschedule the cleanup with the rows still there; leave the loop instead so
			 * the recurring action below stays scheduled and the next minute retries.
			 */
			if ( ! empty( $wpdb->last_error ) ) {
				break;
			}

			if ( empty( $e_ids ) ) {
				/**
				 * Nothing left - but a creation worker may still be inserting.
				 *
				 * The reset that queued this cleanup leaves the broadcast scheduled, and a worker
				 * already inside its creation loop notices only at its next batch boundary. A pass
				 * that finds the table empty while that worker is mid-batch would unschedule
				 * itself, and the rows the worker inserts after this read would survive - old
				 * template, old merge tags - for the re-preparation to skip as already engaged.
				 * The worker stamps last_modified every couple of seconds while it creates, so a
				 * fresh stamp means "come back next minute"; a stale one means nobody is writing.
				 * Read now, not off the row fetched above: the delete passes before this point
				 * can have run for the whole time budget, and a copy that old would clear a
				 * worker that is still stamping.
				 */
				$last_modified = $wpdb->get_var( $wpdb->prepare( "SELECT `last_modified` FROM {$wpdb->prefix}bwfan_broadcast WHERE `id` = %d", $broadcast_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$last_modified = ! empty( $last_modified ) ? strtotime( $last_modified ) : 0;
				if ( $last_modified > 0 && ( time() - $last_modified ) < 10 ) {
					break;
				}

				/**
				 * Only when there is something to drop.
				 *
				 * bwf_unschedule_actions() runs _doing_it_wrong() whenever find_actions() matches
				 * nothing, so asking it to remove an action that was never scheduled writes a PHP
				 * notice per call rather than doing nothing quietly. That happens on any direct
				 * caller - the test suite is full of them - and in production to a cleanup whose
				 * own row the stale sweep in has_engagement_cleanup_queued() removed while it was
				 * still running. The work is already done either way; only the notice is wrong.
				 */
				if ( bwf_has_action_scheduled( 'bwfan_delete_unscheduled_broadcast_data', $args ) ) {
					bwf_unschedule_actions( 'bwfan_delete_unscheduled_broadcast_data', $args );
				}

				return true;
			}

			/** Delete engagements */
			$placeholders = implode( ',', array_fill( 0, count( $e_ids ), '%d' ) );
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}bwfan_engagement_tracking WHERE ID IN($placeholders)", $e_ids ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL

			/** A DELETE that failed leaves the same ids for the next SELECT; looping on them burns the budget for nothing - let the recurring action retry */
			if ( ! empty( $wpdb->last_error ) ) {
				break;
			}

			/** Delete engagement tracking meta */
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}bwfan_engagement_trackingmeta WHERE eid IN($placeholders)", $e_ids ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL
			if ( ! empty( $wpdb->last_error ) ) {
				break;
			}

			/** Keep deleting in batches until the time budget for this run is spent */
		} while ( ( time() - $start_time ) < $time );

		/**
		 * The time budget for this run is spent with rows still left over, so make sure the
		 * recurring cleanup stays scheduled to pick up the remainder. Without this a caller
		 * that invokes this directly would leave the leftover engagements orphaned.
		 */
		if ( ! BWFAN_Model_Broadcast::has_engagement_cleanup_queued( $broadcast_id ) ) {
			bwf_schedule_recurring_action( time(), MINUTE_IN_SECONDS, 'bwfan_delete_unscheduled_broadcast_data', $args );
		}

		return false;
	}

	public static function get_referral_data( $customer_id ) {
		global $wpdb;

		$referral_data = [];
		$customer_data = $wpdb->get_row( $wpdb->prepare( "SELECT email, first_name, last_name FROM {$wpdb->prefix}affiliate_wp_customers WHERE customer_id = %d ", $customer_id ) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( empty( $customer_data ) ) {
			return $referral_data;
		}
		$referral_data['email']      = isset( $customer_data->email ) ? $customer_data->email : '';
		$referral_data['first_name'] = isset( $customer_data->first_name ) ? $customer_data->first_name : '';
		$referral_data['last_name']  = isset( $customer_data->last_name ) ? $customer_data->last_name : '';

		return $referral_data;
	}

	/**
	 * Get Offers
	 *
	 * @param $search
	 *
	 * @return array
	 */
	public static function get_offers( $search = '' ) {
		$args = [
			"post_type"   => "wfocu_offer",
			"s"           => $search,
			"numberposts" => 20,
		];

		return self::get_formatted_offer_data( $args, $search );
	}

	/**
	 * Get Bump
	 *
	 * @param $search
	 *
	 * @return array
	 */
	public static function get_bumps( $search = '' ) {
		$args = [
			"post_type"   => "wfob_bump",
			"s"           => $search,
			"numberposts" => 20,
		];

		return self::get_formatted_offer_data( $args, $search );
	}

	/**
	 * Get formatted offer/bump
	 *
	 * @param $args
	 * @param $search
	 *
	 * @return array
	 */
	public static function get_formatted_offer_data( $args, $search ) {
		$posts  = get_posts( $args );
		$offers = [];
		foreach ( $posts as $post ) {
			$offers[ $post->ID ] = $post->post_title . '(#' . $post->ID . ')';
		}

		return array_filter( $offers, function ( $offer ) use ( $search ) {
			return false !== strpos( strtolower( $offer ), strtolower( $search ) );
		} );
	}

	/**
	 * Check advance log enabled
	 *
	 * @param $log
	 *
	 * @return bool
	 */
	public static function is_log_enabled( $log ) {
		if ( method_exists( 'BWFAN_Common', 'is_log_enabled' ) ) {
			return BWFAN_Common::is_log_enabled( $log );
		}
		$global_settings = BWFAN_Common::get_global_settings();

		return isset( $global_settings['bwfan_advance_logs'] ) && ! empty( $global_settings['bwfan_advance_logs'] ) && isset( $global_settings[ $log ] ) && ! empty( $global_settings[ $log ] );
	}

	/**
	 * Get formatted tag & list data if comma exists in value
	 *
	 * @param $data
	 *
	 * @return array|string[]
	 */
	public static function check_for_comma_seperated( $data ) {
		if ( method_exists( 'BWFAN_Common', 'check_for_comma_seperated' ) ) {
			return BWFAN_Common::check_for_comma_seperated( $data );
		}

		if ( empty( $data ) || ! is_array( $data ) ) {
			return [];
		}
		$formatted_data = [];
		foreach ( $data as $value ) {
			if ( ! empty( ( $value['id'] ) ) || false === strpos( $value['value'], ',' ) ) {
				$formatted_data[] = $value;
				continue;
			}
			$comma_separated_values = explode( ',', $value['value'] );
			$comma_separated_values = array_map( function ( $single_value ) {
				return [
					'id'    => 0,
					'value' => trim( $single_value )
				];
			}, $comma_separated_values );
			$formatted_data         = array_merge( $formatted_data, $comma_separated_values );
		}

		return $formatted_data;
	}

	/**
	 * Get date format
	 *
	 * @return array[]
	 */
	public static function get_date_formats() {
		if ( method_exists( 'BWFAN_Common', 'get_date_formats' ) ) {
			return BWFAN_Common::get_date_formats();
		}

		return array(
			array(
				'format' => 'j M Y',
			),
			array(
				'format' => 'jS M Y',
			),
			array(
				'format' => 'M j Y',
			),
			array(
				'format' => 'M jS Y',
			),
			array(
				'format' => 'd/m/Y',
			),
			array(
				'format' => 'd-m-Y',
			),
			array(
				'format' => 'Y/m/d',
			),
			array(
				'format' => 'Y-m-d',
			),
			array(
				'format' => 'd/m/Y H:i:s',
			),
			array(
				'format' => 'd-m-Y H:i:s',
			),
			array(
				'format' => 'Y/m/d H:i:s',
			),
			array(
				'format' => 'Y-m-d H:i:s',
			),
			array(
				'format' => 'd.m.Y',
			),
		);
	}

	/** Breakdance  */
	public static function get_breakdance_form_fields( $form_post_id ) {
		global $wpdb;

		// Query all Breakdance form metadata
		$query   = "SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_breakdance_data'";
		$results = $wpdb->get_results( $query ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		if ( ! $results ) {
			return [];
		}

		foreach ( $results as $row ) {
			$meta_data = json_decode( $row->meta_value, true );
			if ( ! isset( $meta_data['tree_json_string'] ) ) {
				continue;
			}

			$tree_data = json_decode( $meta_data['tree_json_string'], true );
			if ( ! isset( $tree_data['root'] ) ) {
				continue;
			}
			$fields = [];

			self::extract_form_fields( $tree_data['root'], $form_post_id, $fields );

			if ( ! empty( $fields ) ) {
				return $fields;
			}
		}

		return [];
	}


	/**
	 * Extract Form Fields from the Breakdance Form Builder
	 */
	private static function extract_form_fields( $node, $form_post_id, &$fields ) {
		if ( isset( $node['data']['type'] ) && $node['data']['type'] === 'EssentialElements\\FormBuilder' ) {
			if ( isset( $node['id'] ) && $node['id'] == $form_post_id ) {
				if ( isset( $node['data']['properties']['content']['form']['fields'] ) ) {
					foreach ( $node['data']['properties']['content']['form']['fields'] as $field ) {
						if ( ! empty( $field['advanced']['id'] ) && ! empty( $field['label'] ) ) {
							$fields[ $field['advanced']['id'] ] = sanitize_text_field( $field['label'] );
						}
					}
				}
			}
		}

		if ( isset( $node['children'] ) && is_array( $node['children'] ) ) {
			foreach ( $node['children'] as $child ) {
				self::extract_form_fields( $child, $form_post_id, $fields );
			}
		}
	}

	public static function get_all_breakdance_forms() {
		global $wpdb;

		$post_types   = [ 'page', 'breakdance_popup', 'breakdance_template', 'breakdance_global_block' ];
		$placeholders = implode( ',', array_fill( 0, count( $post_types ), '%s' ) );

		$query = $wpdb->prepare( "
        SELECT post_id, meta_value
        FROM {$wpdb->postmeta}
        WHERE meta_key = '_breakdance_data'
        AND post_id IN (
            SELECT ID FROM {$wpdb->posts} WHERE post_type IN ($placeholders)
        )
    ", ...$post_types );

		$results = $wpdb->get_results( $query ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( ! $results ) {
			return [];
		}

		$unique_forms = [];

		foreach ( $results as $row ) {
			$meta_data = json_decode( $row->meta_value, true );
			if ( ! $meta_data || ! isset( $meta_data['tree_json_string'] ) ) {
				continue;
			}

			$tree_data = json_decode( $meta_data['tree_json_string'], true );
			if ( ! $tree_data || ! isset( $tree_data['root'] ) ) {
				continue;
			}
			self::extract_breakdance_forms( $tree_data['root'], $row->post_id, $unique_forms );
		}

		return array_values( $unique_forms );
	}

	public static function extract_breakdance_forms( $node, $post_id, &$unique_forms ) {
		if ( isset( $node['data']['type'] ) && $node['data']['type'] === 'EssentialElements\\FormBuilder' ) {
			$form_id    = $node['id'];
			$form_title = $node['data']['properties']['content']['form']['form_name'] ?? 'Untitled Form';

			// Unique key for preventing duplicate forms
			$unique_key = $form_id . '_' . $post_id;

			if ( ! isset( $unique_forms[ $unique_key ] ) ) {
				$unique_forms[ $unique_key ] = [
					'id'      => $form_id,
					'title'   => $form_title,
					'post_id' => $post_id
				];
			}
		}

		if ( isset( $node['children'] ) && is_array( $node['children'] ) ) {
			foreach ( $node['children'] as $child ) {
				self::extract_breakdance_forms( $child, $post_id, $unique_forms );
			}
		}
	}

	/**
	 * @param $link
	 * Validate links domains
	 *
	 * @return mixed|string|null
	 */
	public static function validate_target_link( $link ) {
		if ( method_exists( 'BWFAN_Common', 'validate_target_link' ) ) {
			return BWFAN_Common::validate_target_link( $link );
		}

		$link_host     = parse_url( urldecode( $link ), PHP_URL_HOST );
		$site_url      = home_url();
		$site_url_host = parse_url( $site_url, PHP_URL_HOST );

		/** If site url and redirect url host are same */
		if ( $link_host === $site_url_host ) {
			return $link;
		}

		$allowed_domains = apply_filters( 'bwfan_allowed_redirect_domains', array() );
		if ( empty( $allowed_domains ) ) {
			return $link;
		}

		/** Filter valid domains */
		$allowed_domains = array_filter( array_map( function ( $domain ) {
			return ! empty( $domain ) && is_string( $domain ) ? wp_parse_url( $domain, PHP_URL_HOST ) : false;
		}, $allowed_domains ) );

		return in_array( $link_host, $allowed_domains, true ) ? $link : $site_url;
	}

	/**
	 * Validate that a link is a well-formed http(s) URL.
	 *
	 * Use this for links that are stored for tracking or used as redirect targets
	 * (not fetched server-side). Unlike wp_http_validate_url() — which is an SSRF
	 * guard for outbound wp_remote_*() requests — this does NOT resolve DNS or
	 * reject private/loopback IPs. That matters because an admin's own-domain link
	 * legitimately resolves to 127.0.0.1 on hosts that loop their domain back to
	 * themselves, which makes wp_http_validate_url() wrongly reject valid links.
	 *
	 * It keeps the only protection relevant here: a strict http/https protocol
	 * whitelist (via esc_url_raw / wp_kses_bad_protocol) that blocks javascript:,
	 * data:, etc., plus a required host.
	 *
	 * @param string $url
	 *
	 * @return bool
	 */
	public static function bwfan_is_valid_link( $url ) {
		if ( method_exists( 'BWFAN_Common', 'bwfan_is_valid_link' ) ) {
			return BWFAN_Common::bwfan_is_valid_link( $url );
		}

		if ( ! is_string( $url ) || '' === trim( $url ) ) {
			return false;
		}

		/** Reject disallowed protocols (javascript:, data:, …) without DNS/SSRF checks. */
		if ( '' === esc_url_raw( $url ) ) {
			return false;
		}

		$parsed = wp_parse_url( $url );
		if ( empty( $parsed['scheme'] ) || empty( $parsed['host'] ) ) {
			return false;
		}

		return in_array( strtolower( $parsed['scheme'] ), array( 'http', 'https' ), true );
	}

	/**
	 * If constant define then get contact email by user id
	 *
	 * @param $user_id
	 * @param $contact_id
	 *
	 * @return string
	 */
	public static function get_contact_email( $user_id = 0, $contact_id = 0 ) {
		if ( method_exists( 'BWFAN_Common', 'get_contact_email' ) ) {
			return BWFAN_Common::get_contact_email( $user_id, $contact_id );
		}

		if ( ! defined( 'BWFAN_GET_CONTACT_EMAIL' ) || true !== BWFAN_GET_CONTACT_EMAIL || ( empty( $user_id ) && empty( $contact_id ) ) ) {
			return '';
		}

		$contact = new WooFunnels_Contact( $user_id, '', '', $contact_id );

		return $contact->get_id() > 0 ? $contact->get_email() : '';
	}

	/**
	 * Get coupons
	 *
	 * @param string $searched_term
	 * @param array $type
	 *
	 * @return array
	 */
	public static function get_coupon( $searched_term, $type = [] ) {
		$coupons      = array();
		$results      = array();
		$query_params = array(
			'post_type'      => 'shop_coupon',
			'posts_per_page' => 10,
			'post_status'    => 'publish',
			'meta_query'     => array(
				array(
					'key'     => '_is_bwfan_coupon',
					'compare' => 'NOT EXISTS',
				),
			),
		);
		if ( ! empty( $type ) ) {
			$query_params['meta_query'][] = array(
				'key'     => 'discount_type',
				'value'   => $type,
				'compare' => 'IN',
			);
		}
		if ( '' !== $searched_term ) {
			$query_params['s'] = $searched_term;
		}

		$query = new WP_Query( $query_params );

		if ( $query->found_posts > 0 ) {
			foreach ( $query->posts as $post ) {
				$results[] = array(
					'id'   => $post->ID,
					'text' => $post->post_title,
				);
			}
		}

		$coupons['results'] = $results;

		return $coupons;
	}

	/**
	 * Get Sublium subscriber by user ID
	 *
	 * @param int $user_id
	 *
	 * @return array
	 */
	public static function get_sublium_subscriber( $user_id ) {
		if ( ! class_exists( 'Sublium_WCS\Includes\database\Subscribers' ) ) {
			return [];
		}
		$subscribers       = new Sublium_WCS\Includes\database\Subscribers();
		$filter['user_id'] = [
			'operator' => '=',
			'value'    => $user_id,
		];


		$results = $subscribers->read( $filter, 1 );

		return ! empty( $results ) ? $results[0] ?? [] : [];
	}

	/**
	 * Get WooCommerce orders
	 *
	 * Fetches WooCommerce order IDs using direct SQL queries for better performance.
	 * Supports both HPOS (High-Performance Order Storage) and legacy post-based storage.
	 *
	 * @param array $args {
	 *     Optional. Arguments for querying orders.
	 *
	 * @type string $after_date_created Optional. MySQL datetime string. Fetches orders created before this date.
	 *                                      Format: 'Y-m-d H:i:s' (e.g., '2024-01-01 00:00:00').
	 * @type int $limit Optional. Number of orders to fetch. Default: no limit.
	 * @type int $offset Optional. Number of orders to skip. Default: 0.
	 * @type bool $only_count Optional. If true, returns count instead of order IDs. Default: false.
	 * }
	 *
	 * @return array|int Array of order IDs, or integer count if $only_count is true.
	 *                   Returns empty array if no paid statuses configured or no orders found.
	 */
	public static function get_wc_orders( $args = [] ) {

		global $wpdb;
		$paid_status = wc_get_is_paid_statuses();
		$paid_status = is_array( $paid_status ) ? array_map( function ( $status ) {
			return 'wc-' . $status;
		}, $paid_status ) : [];
		if ( empty( $paid_status ) ) {
			return [];
		}

		$placeholder        = array_fill( 0, count( $paid_status ), '%s' );
		$placeholder        = implode( ", ", $placeholder );
		$order_by           = '';
		$after_date_created = '';
		$limit_query        = '';
		$prepare_args       = $paid_status;
		if ( BWF_WC_Compatibility::is_hpos_enabled() ) {
			$query       = "SELECT `id` FROM {$wpdb->prefix}wc_orders  WHERE `status` IN ($placeholder) AND `type` = 'shop_order' AND ( `parent_order_id` = 0 OR `parent_order_id` IS NULL ) ";
			$count_query = "SELECT COUNT(`id`) FROM {$wpdb->prefix}wc_orders  WHERE `status` IN ($placeholder) AND `type` = 'shop_order' AND (`parent_order_id` = 0 OR `parent_order_id` IS NULL )";

			if ( ! empty( $args['after_date_created'] ) ) {
				/**
				 * Use '<' operator to fetch orders created BEFORE the specified date.
				 * This is correct for importing historical orders and matches the
				 * behavior of wc_get_orders() with 'date_created' => '<' parameter.
				 */
				$after_date_created = " AND `date_created_gmt` < %s ";
				$order_by           = " ORDER BY date_created_gmt DESC";
				$prepare_args[]     = $args['after_date_created'];
			}

		} else {
			$query       = "SELECT `ID` AS id FROM {$wpdb->posts} WHERE `post_parent` = 0 AND `post_type` = 'shop_order' AND post_status IN($placeholder)";
			$count_query = "SELECT COUNT(`ID`) FROM {$wpdb->posts} WHERE `post_parent` = 0  AND `post_type` = 'shop_order' AND post_status IN($placeholder)";

			if ( ! empty( $args['after_date_created'] ) ) {
				/**
				 * Use '<' operator to fetch orders created BEFORE the specified date.
				 * This is correct for importing historical orders and matches the
				 * behavior of wc_get_orders() with 'date_created' => '<' parameter.
				 */
				$after_date_created = " AND `post_date_gmt` < %s ";
				$order_by           = " ORDER BY post_date_gmt DESC";
				$prepare_args[]     = $args['after_date_created'];
			}

		}
		if ( ! empty( $args['only_count'] ) ) {
			$query = $wpdb->prepare( "$count_query $after_date_created", ...$prepare_args );
			$count = $wpdb->get_var( $query ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

			return ! empty( $count ) ? intval( $count ) : 0;
		}
		$query = $wpdb->prepare( "$query $after_date_created $order_by", ...$prepare_args );
		if ( ! empty( $args['limit'] ) ) {
			$limit_query = " LIMIT %d OFFSET %d";
			$limit_query = $wpdb->prepare( $limit_query, $args['limit'], isset( $args['offset'] ) ? $args['offset'] : 0 );
		}
		$orders = $wpdb->get_col( "$query $limit_query " ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return ! empty( $orders ) ? $orders : [];
	}

	/**
	 * Use left join for contact query
	 *
	 * @param $filter
	 * @param $additional_info
	 *
	 * @return bool
	 */
	public static function use_left_join( $filter, $additional_info ) {
		return apply_filters( 'bwfan_contact_use_left_join', false, $filter, $additional_info );
	}

	/**
	 * Check if the site's default language is RTL (right-to-left)
	 * Unlike WordPress's is_rtl() function which checks current user's language in backend,
	 * this function checks the site's default language setting
	 *
	 * @return bool True if site's default language is RTL, false otherwise
	 */
	public static function is_site_rtl() {
		if ( method_exists( 'BWFAN_Common', 'is_site_rtl' ) ) {
			return BWFAN_Common::is_site_rtl();
		}
		static $is_rtl = null;
		static $site_locale = null;

		// Return cached result if already determined
		if ( null !== $is_rtl ) {
			// Allow filtering of the final RTL result for flexibility
			return apply_filters( 'bwfan_is_site_rtl', $is_rtl, $site_locale );
		}

		// Get the site's default locale (bypassing user preferences)
		$site_locale = self::get_site_default_locale();

		// Switch to site's default locale temporarily
		$switched = switch_to_locale( $site_locale );

		if ( $switched ) {
			// Use WordPress's native is_rtl() function which checks $wp_locale
			// Now $wp_locale reflects the SITE's language, not user's preference
			$is_rtl = is_rtl();

			// Restore the original locale (user's preference if in admin)
			restore_previous_locale();
		} else {
			// If switching failed, check current state (fallback)
			// This shouldn't happen in normal WordPress installations
			$is_rtl = is_rtl();
		}

		// Allow filtering of the final RTL result for complete flexibility
		return apply_filters( 'bwfan_is_site_rtl', $is_rtl, $site_locale );
	}

	/**
	 * Get the site's default locale (not affected by user language preference)
	 * Replicates WordPress's get_locale() logic but without user preference override
	 *
	 * @return string Site's default locale
	 */
	private static function get_site_default_locale() {
		// Check if WPLANG is defined in wp-config (highest priority)
		if ( defined( 'WPLANG' ) ) {
			return WPLANG;
		}

		$locale = '';

		// Get from database options (site-wide setting)
		if ( is_multisite() ) {
			$locale = get_option( 'WPLANG' );
			if ( false === $locale ) {
				$locale = get_site_option( 'WPLANG' );
			}
		} else {
			$locale = get_option( 'WPLANG' );
		}

		// Empty or false means en_US (WordPress default)
		if ( empty( $locale ) ) {
			$locale = 'en_US';
		}

		return $locale;
	}

	/**
	 * fetching transaction status for creating the membership
	 *
	 * @return array[]
	 */
	public static function get_mepr_transaction_status() {
		return array(
			MeprTransaction::$complete_str => __( 'Complete', 'wp-marketing-automations-pro' ),
			MeprTransaction::$pending_str  => __( 'Pending', 'wp-marketing-automations-pro' ),
			MeprTransaction::$failed_str   => __( 'Failed', 'wp-marketing-automations-pro' ),
			MeprTransaction::$refunded_str => __( 'Refunded', 'wp-marketing-automations-pro' ),
		);
	}

	/**
	 * Fetch MemberPress subscription statuses for recurring memberships.
	 *
	 * @return array<string, string>
	 */
	public static function get_mepr_subscription_status() {
		return array(
			MeprSubscription::$pending_str   => __( 'Pending', 'wp-marketing-automations-pro' ),
			MeprSubscription::$active_str    => __( 'Active', 'wp-marketing-automations-pro' ),
			MeprSubscription::$suspended_str => __( 'Suspended', 'wp-marketing-automations-pro' ),
			MeprSubscription::$cancelled_str => __( 'Cancelled', 'wp-marketing-automations-pro' ),
		);
	}

	/**
	 * Sanitize a MemberPress subscription status value.
	 *
	 * @param string $status Raw status from automation step data.
	 * @param string $default Fallback status when empty or invalid.
	 *
	 * @return string
	 */
	public static function sanitize_mepr_subscription_status( $status, $default = '' ) {
		$status  = strtolower( sanitize_text_field( $status ) );
		$valid   = array_keys( self::get_mepr_subscription_status() );
		$default = ! empty( $default ) ? $default : MeprSubscription::$pending_str;

		if ( empty( $status ) ) {
			return $default;
		}

		return in_array( $status, $valid, true ) ? $status : $default;
	}

	/**
	 * fetching payment gateways for creating the membership
	 *
	 * @return array
	 */
	public static function get_mepr_payment_gateways() {
		$mepr_options = MeprOptions::fetch();

		$pms     = array_keys( $mepr_options->integrations );
		$results = array( MeprTransaction::$manual_gateway_str => __( 'Manual', 'wp-marketing-automations-pro' ) );

		foreach ( $pms as $pm_id ) {
			$obj = $mepr_options->payment_method( $pm_id );
			if ( $obj instanceof MeprBaseRealGateway ) {
				$results[ $obj->id ] = sprintf( '%1$s (%2$s)', $obj->label, $obj->name );
			}
		}

		return $results;
	}

	/**
	 * @param $searched_term
	 *
	 * @return array
	 */
	public static function get_mepr_one_time_subscription_products( $searched_term = '' ) {
		$query_params      = array(
			'post_type'      => 'memberpressproduct',
			'posts_per_page' => - 1,
			'post_status'    => 'publish',
			'meta_query'     => [
				[
					'key'   => '_mepr_product_period_type',
					'value' => 'lifetime',
				],
			],
		);
		$query_params['s'] = $searched_term;
		$query             = new WP_Query( $query_params );
		$results           = array();
		if ( $query->found_posts > 0 ) {
			foreach ( $query->posts as $post ) {
				$results[] = array(
					'id'   => $post->ID,
					'text' => $post->post_title,
				);
			}
		}

		return $results;
	}

	/**
	 * Get recurring subscription product
	 *
	 * @param $searched_term
	 */
	public static function get_mepr_recurring_subscription_products( $searched_term = '' ) {
		$query_params      = array(
			'post_type'      => 'memberpressproduct',
			'posts_per_page' => - 1,
			'post_status'    => 'publish',
			'meta_query'     => [
				[
					'key'     => '_mepr_product_period_type',
					'value'   => 'lifetime',
					'compare' => '!=',
				],
			],
		);
		$query_params['s'] = $searched_term;
		$query             = new WP_Query( $query_params );
		$results           = array();
		if ( $query->found_posts > 0 ) {
			foreach ( $query->posts as $post ) {
				$results[] = array(
					'id'   => $post->ID,
					'text' => $post->post_title,
				);
			}
		}

		return $results;
	}

	/**
	 * Request-level cache of term ID => latest name, so each term is fetched only once per request.
	 *
	 * @var array
	 */
	private static $term_name_cache = array();

	/**
	 * Decode stored JSON data column (lite compatibility when method is unavailable).
	 *
	 * @param mixed $data Raw or decoded data.
	 *
	 * @return array|null
	 */
	public static function decode_stored_data_column( $data ) {
		if ( empty( $data ) ) {
			return null;
		}

		if ( is_array( $data ) ) {
			return $data;
		}

		if ( is_string( $data ) && method_exists( 'BWFAN_Common', 'is_json' ) && BWFAN_Common::is_json( $data ) ) {
			$decoded = json_decode( $data, true );

			return is_array( $decoded ) ? $decoded : null;
		}

		return null;
	}

	/**
	 * Refresh tag/list labels inside stored filter rules (lite compatibility).
	 *
	 * @param mixed $filters Stored filter rules.
	 *
	 * @return mixed
	 */
	public static function get_updated_filters( $filters ) {
		if ( empty( $filters ) || ! is_array( $filters ) ) {
			return $filters;
		}

		/** Honor the same admin opt-out used by automation events/actions (see BWFAN_Common::modify_step_admin_data). */
		if ( defined( 'BWFAN_Disable_Automation_Fetch_Latest_Names' ) && 1 === intval( BWFAN_Disable_Automation_Fetch_Latest_Names ) ) {
			return $filters;
		}

		static $tag_list_filters = array( 'tags', 'lists' );

		foreach ( $filters as $or_key => $or_rule ) {
			if ( ! is_array( $or_rule ) ) {
				continue;
			}

			foreach ( $or_rule as $and_key => $rule ) {
				$filter_slug = is_object( $rule ) ? ( $rule->filter ?? '' ) : ( $rule['filter'] ?? '' );
				if ( ! in_array( $filter_slug, $tag_list_filters, true ) ) {
					continue;
				}

				$data = is_object( $rule ) ? ( $rule->data ?? array() ) : ( $rule['data'] ?? array() );
				if ( empty( $data ) || ! is_array( $data ) ) {
					continue;
				}

				$updated_data = self::refresh_term_labels( $data );
				if ( is_object( $rule ) ) {
					$filters[ $or_key ][ $and_key ]->data = $updated_data;
				} else {
					$filters[ $or_key ][ $and_key ]['data'] = $updated_data;
				}
			}
		}

		return $filters;
	}

	/**
	 * Refresh the `label` of each tag/list entry with its latest stored name.
	 *
	 * Uses a request-level cache so each term ID is fetched from the DB only once per request,
	 * even when the same tag/list is referenced across many broadcasts/audiences/filters.
	 *
	 * @param array $terms Term entries, each having a `key` (term ID) and `label` (name).
	 *
	 * @return array
	 */
	private static function refresh_term_labels( $terms ) {
		if ( ! is_array( $terms ) ) {
			return $terms;
		}

		foreach ( $terms as $index => $term ) {
			$is_object = is_object( $term );
			$entry     = $is_object ? (array) $term : $term;
			if ( ! is_array( $entry ) || ! isset( $entry['key'] ) ) {
				continue;
			}

			$name = self::get_latest_term_name( $entry['key'] );
			if ( null !== $name ) {
				$entry['label'] = $name;
			}

			$terms[ $index ] = $is_object ? (object) $entry : $entry;
		}

		return $terms;
	}

	/**
	 * Resolve a term's latest stored name, caching the lookup for the rest of the request.
	 *
	 * @param int|string $term_id Term ID.
	 *
	 * @return string|null Latest name, or null when the term no longer exists.
	 */
	public static function get_latest_term_name( $term_id ) {
		$term_id = (string) $term_id;
		if ( '' === $term_id ) {
			return null;
		}

		if ( ! array_key_exists( $term_id, self::$term_name_cache ) ) {
			$term = method_exists( 'BWFAN_Model_Terms', 'get' ) ? BWFAN_Model_Terms::get( $term_id ) : null;

			self::$term_name_cache[ $term_id ] = ( is_array( $term ) && ! empty( $term['name'] ) ) ? $term['name'] : null;
		}

		return self::$term_name_cache[ $term_id ];
	}

	/**
	 * Normalize stored filters and refresh tag/list labels for admin display (lite compatibility).
	 *
	 * This is a read/display-only helper, mirroring how automation events/actions resolve the latest
	 * tag/list names (see BWFAN_Common::fetch_updated_data / modify_step_admin_data). It never writes
	 * to the DB: legacy filters are only normalized in-memory so the admin UI renders correctly.
	 * Permanent legacy->new migration is owned by the scheduled `bwfan_convert_filters_to_new_filters`
	 * action, and execution converts on the fly via BWFCRM_Filters::_normalize_for_new_filters().
	 *
	 * @param mixed $filters Stored filter rules.
	 *
	 * @return mixed
	 */
	public static function prepare_stored_filters_for_admin( $filters ) {
		if ( empty( $filters ) || ! is_array( $filters ) ) {
			return $filters;
		}

		if ( class_exists( 'BWFCRM_Filters' ) && ! BWFCRM_Filters::is_new_filter( $filters ) && method_exists( 'BWFCRM_Model_Contact', 'get_contacts_from_filters' ) ) {
			$filters = BWFCRM_Filters::convert_filters_to_new_filters( $filters );
		}

		return self::get_updated_filters( $filters );
	}
}
