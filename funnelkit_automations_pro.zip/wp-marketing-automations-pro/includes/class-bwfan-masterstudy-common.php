<?php
/**
 * MasterStudy LMS helpers for Automations (curriculum linkage, labels).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

#[\AllowDynamicProperties]
class BWFAN_Masterstudy_Common {

	public static function init() {
	}

	/**
	 * Course IDs a lesson (or curriculum material post) belongs to.
	 *
	 * @param int $post_id Lesson or quiz post ID.
	 *
	 * @return int[]
	 */
	public static function get_material_course_ids( $post_id ) {
		$post_id = absint( $post_id );
		if ( ! $post_id ) {
			return array();
		}
		if ( class_exists( '\MasterStudy\Lms\Repositories\CurriculumRepository' ) ) {
			return ( new \MasterStudy\Lms\Repositories\CurriculumRepository() )->get_lesson_course_ids( $post_id );
		}

		return array();
	}

	/**
	 * First associated course for a lesson/material.
	 *
	 * @param int $lesson_id
	 *
	 * @return int
	 */
	public static function get_primary_course_id_for_lesson( $lesson_id ) {
		$ids = self::get_material_course_ids( $lesson_id );

		return ! empty( $ids ) ? absint( reset( $ids ) ) : 0;
	}

	/**
	 * Admin/search label: lesson title + course name + ID.
	 *
	 * @param int $lesson_id
	 *
	 * @return string
	 */
	public static function get_lesson_search_label( $lesson_id ) {
		$post = get_post( absint( $lesson_id ) );
		if ( ! $post instanceof WP_Post || 'stm-lessons' !== $post->post_type ) {
			return '';
		}
		$course_id = self::get_primary_course_id_for_lesson( $lesson_id );
		$course_title = $course_id ? get_the_title( $course_id ) : __( '—', 'wp-marketing-automations-pro' );

		return sprintf(
			/* translators: 1: lesson title, 2: course name, 3: lesson post ID */
			__( '%1$s (Course: %2$s) [#%3$d]', 'wp-marketing-automations-pro' ),
			$post->post_title,
			$course_title,
			$post->ID
		);
	}

	/**
	 * Resolve course ID from automation context (explicit ID, or from lesson/quiz curriculum).
	 *
	 * @param int $course_id
	 * @param int $lesson_id
	 * @param int $quiz_id
	 *
	 * @return int
	 */
	public static function resolve_event_course_id( $course_id = 0, $lesson_id = 0, $quiz_id = 0 ) {
		$course_id = absint( $course_id );
		if ( $course_id ) {
			return $course_id;
		}
		$lesson_id = absint( $lesson_id );
		if ( $lesson_id ) {
			return self::get_primary_course_id_for_lesson( $lesson_id );
		}
		$quiz_id = absint( $quiz_id );
		if ( $quiz_id ) {
			$ids = self::get_material_course_ids( $quiz_id );

			return ! empty( $ids ) ? absint( reset( $ids ) ) : 0;
		}

		return 0;
	}

	/**
	 * Latest enrollment row progress for a user/course (0–100).
	 *
	 * @param int $user_id
	 * @param int $course_id
	 *
	 * @return float|null
	 */
	public static function get_user_course_progress_percent( $user_id, $course_id ) {
		global $wpdb;

		$user_id   = absint( $user_id );
		$course_id = absint( $course_id );
		if ( ! $user_id || ! $course_id ) {
			return null;
		}

		static $table_exists = null;
		$table = $wpdb->prefix . 'stm_lms_user_courses';
		if ( null === $table_exists ) {
			$table_exists = ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table );
		}
		if ( ! $table_exists ) {
			return null;
		}

		$val = $wpdb->get_var(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- dynamic $wpdb->prefix table name.
				"SELECT progress_percent FROM {$table} WHERE user_id = %d AND course_id = %d ORDER BY user_course_id DESC LIMIT 1",
				$user_id,
				$course_id
			)
		);

		return null !== $val ? floatval( $val ) : null;
	}
}
