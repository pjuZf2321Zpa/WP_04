<?php
/**
 * Automations Pro Usage Collector Class
 *
 * Collects usage data for FunnelKit Automations Pro
 *
 * @package FunnelKit Automations Pro
 * @since 3.6.5
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'BWFANCRM_Usage_Collector' ) && class_exists( 'WooFunnels_Usage_Collector_Abstract' ) ) {

	/**
	 * Class BWFANCRM_Usage_Collector
	 */
	#[\AllowDynamicProperties]
	class BWFANCRM_Usage_Collector extends WooFunnels_Usage_Collector_Abstract {

		/**
		 * Plugin identifier
		 *
		 * @var string
		 */
		protected $plugin_id = 'automations';

		/**
		 * Module type
		 *
		 * @var string
		 */
		protected $module = 'pro';

		/**
		 * Usage version
		 *
		 * @var string
		 */
		protected $usage_version = '1.0.0';

		/**
		 * @var null
		 */
		private static $ins = null;

		/**
		 * BWFANCRM_Usage_Collector constructor.
		 */
		public function __construct() {
			// Call parent constructor to register with registry (overrides Lite)
			parent::__construct();
		}

		/**
		 * Override: Pro always collects (no opt-in check)
		 *
		 * @return bool
		 */
		public function should_collect() {
			return true; // Pro always collects usage data
		}

		/**
		 * Add this collector to the registry filter
		 *
		 * @param array $collectors Existing collectors
		 * @return array
		 */
	public static function add_to_registry( $collectors ) {
		$collectors['automations'] = array(
			'class'  => __CLASS__,
			'module' => 'pro',
		);
		return $collectors;
	}

		/**
		 * Get instance
		 *
		 * @return BWFANCRM_Usage_Collector|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		/**
		 * Collect usage data
		 *
		 * @return array Usage data
		 */
		public function collect() {
			try {
				// Try to use Lite usage collector if available (reuse logic)
				// Manually load Lite class if not already loaded
				if ( ! class_exists( 'BWFAN_Usage_Collector' ) ) {
					$lite_usage_file = defined( 'BWFAN_PLUGIN_DIR' ) ? BWFAN_PLUGIN_DIR . '/includes/usage/class-bwfan-usage-collector.php' : '';
					if ( ! empty( $lite_usage_file ) && file_exists( $lite_usage_file ) ) {
						require_once $lite_usage_file;
					}
				}

				// Use Lite collector if available to get Lite data
				$lite_data = array();
				if ( class_exists( 'BWFAN_Usage_Collector' ) ) {
					$lite_collector = new BWFAN_Usage_Collector();
					$lite_collected = $lite_collector->collect();
					// Extract Lite data from collected structure
					if ( ! empty( $lite_collected ) && is_array( $lite_collected ) ) {
						if ( isset( $lite_collected['installation_config'] ) ) {
							if ( isset( $lite_collected['installation_config']['lite'] ) ) {
								$lite_data['lite'] = $lite_collected['installation_config']['lite'];
							}
							if ( isset( $lite_collected['installation_config']['install_date'] ) ) {
								$lite_data['install_date'] = $lite_collected['installation_config']['install_date'];
							}
						}
						if ( isset( $lite_collected['feature'] ) ) {
							$lite_data['features'] = $lite_collected['feature'];
						}
						if ( isset( $lite_collected['feature_performance'] ) ) {
							$lite_data['feature_performance'] = $lite_collected['feature_performance'];
						}
						if ( isset( $lite_collected['settings'] ) ) {
							$lite_data['settings'] = $lite_collected['settings'];
						}
					}
				}

				// Fallback: Collect Lite data using internal methods if Lite collector not available
				if ( empty( $lite_data ) ) {
					$lite_data = $this->collect_lite_data();
				}

				// Collect Pro data using internal methods
				$pro_data = $this->collect_pro_data();

				// Merge Lite and Pro data
				$data = $this->merge_lite_and_pro_data( $lite_data, $pro_data );

				// Build usage data structure
				$installation_config = array();
				if ( isset( $data['lite'] ) ) {
					$installation_config['lite'] = $data['lite'];
				}
				if ( isset( $data['install_date'] ) ) {
					$installation_config['install_date'] = $data['install_date'];
				}
				if ( isset( $data['pro'] ) ) {
					$installation_config['pro'] = $data['pro'];
				}

				$feature = array();
				if ( isset( $data['features'] ) && is_array( $data['features'] ) ) {
					$feature = $data['features'];
				}

			$feature_performance = array();
			if ( isset( $data['feature_performance'] ) && is_array( $data['feature_performance'] ) ) {
				$feature_performance = $data['feature_performance'];
			}

			$settings = array();
			if ( isset( $data['settings'] ) && is_array( $data['settings'] ) ) {
				$settings = $data['settings'];
			}

			$result = array(
				'version'             => $this->usage_version,
				'module'              => $this->module,
				'plugin'              => $this->plugin_id,
				'installation_config' => $installation_config,
				'feature'             => $feature,
				'feature_performance' => $feature_performance,
				'settings'            => $settings,
			);

				// Add connector version if available
				if ( isset( $data['connector'] ) ) {
					$result['connector'] = $data['connector'];
				}

				return $result;

			} catch ( Throwable $e ) {
				// Return empty array if collection fails
				return array();
			}
		}

		/**
		 * Collect Pro-specific data
		 *
		 * @return array
		 */
		private function collect_pro_data() {
			$pro_data = array();

			// Get link trigger data
			$link_trigger_data = $this->get_link_trigger_data();
			$pro_data['link_trigger'] = $link_trigger_data;

			// Get form data
			$form_data = $this->get_form_data();
			$pro_data['form_feed'] = $form_data;

			// Get broadcast data
			$broadcast_data = $this->get_broadcast_data();
			$pro_data['broadcast'] = $broadcast_data;

			// Get active Pro features
			$pro_features = $this->get_active_pro_features();
			$pro_data['pro_features'] = $pro_features;

			// Get SMS sent count
			$sms_sent_data = $this->get_total_sms_sent();
			$pro_data['sms_sent'] = $sms_sent_data;

			// Get active transactional slugs
			$transactional_slugs = $this->get_active_transactional_slugs();
			$pro_data['transactional_email'] = $transactional_slugs;

		// Get connectors data
		if ( function_exists( 'bwfan_is_autonami_connector_active' ) && bwfan_is_autonami_connector_active() ) {
			$connectors_data = $this->get_active_connectors_data();
			$pro_data['connectors'] = $connectors_data;
			if ( defined( 'WFCO_AUTONAMI_CONNECTORS_VERSION' ) ) {
				$pro_data['connector_version'] = WFCO_AUTONAMI_CONNECTORS_VERSION;
			}
		}

		// Get audiences data
		$audiences_data = $this->get_pro_audiences_data();
		$pro_data['audiences'] = $audiences_data;

		// Get bulk actions data
		$bulk_actions_data = $this->get_pro_bulk_actions_data();
		$pro_data['bulk_actions'] = $bulk_actions_data;

		// Get broadcast detailed data
		$broadcasts_detailed_data = $this->get_pro_broadcast_detailed_data();
		$pro_data['broadcasts_detailed'] = $broadcasts_detailed_data;

		// Get templates data
		$templates_data = $this->get_pro_templates_data();
		$pro_data['templates'] = $templates_data;

		// Get transactional emails data
		$transactional_emails_data = $this->get_pro_transactional_emails_data();
		$pro_data['transactional_emails'] = $transactional_emails_data;

		// Get REST API keys data
		$rest_api_keys_data = $this->get_pro_rest_api_keys_data();
		$pro_data['rest_api_keys'] = $rest_api_keys_data;

		return $pro_data;
	}

		/**
		 * Gets link trigger/form data
		 *
		 * @return array Link trigger/form data
		 */
		private function get_link_trigger_data() {
			global $wpdb;
			$table_name = $wpdb->prefix . 'bwfan_link_triggers';

			/** Get active count and titles of link triggers/forms where status is 2 (Active) */
			$query = "SELECT COUNT(DISTINCT ID) as total_count, SUM(CASE WHEN `status` = 2 THEN 1 ELSE 0 END) as active_count FROM {$table_name}";

			$result = $wpdb->get_row( $query, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

			if( ! is_array( $result ) || empty( $result ) ) {
				return [
					'total_count' => 0,
					'active_count' => 0,
					'actions' => [],
				];
			}

			$total_count = intval( $result['total_count'] ?? 0 );
			$active_count = intval( $result['active_count'] ?? 0 );
			$actions = [];
			if( $active_count > 0 ) {
				$action_query = "SELECT data FROM {$table_name} WHERE status = 2";
				$action_result = $wpdb->get_results( $action_query, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				if( ! empty( $action_result ) && is_array( $action_result ) ) {
					$actions_data = array_column( $action_result, 'data' );
					$actions_slugs = [];
					foreach( $actions_data as $item ) {
						if( empty( $item ) ) {
							continue;
						}
						$item = ! empty( $item ) && is_string( $item ) ? json_decode( $item, true ) : [];

						if( empty( $item ) || ! is_array( $item ) || empty( $item['actions'] ) ) {
							continue;
						}
						$actions_slugs = array_merge( $actions_slugs, array_keys($item['actions']) );
					}
					$actions_slugs = array_filter( array_unique( $actions_slugs ) );
					$actions = $actions_slugs;
				}

			} else {
				$actions = [];
			}

			return [
				'total_count' => $total_count,
				'active_count' => $active_count,
				'actions' => array_values($actions),
			];
		}

		/**
		 * Gets link trigger/form data
		 *
		 * @return array Link trigger/form data
		 */
		private function get_form_data() {
			global $wpdb;
			$table_name = $wpdb->prefix . 'bwfan_form_feeds';

			/** Get active count and titles of link triggers/forms where status is 2 (Active) */
			$query = "SELECT COUNT(DISTINCT ID) as total,
            SUM(CASE WHEN `status` = 2 THEN 1 ELSE 0 END) as active_count,
            GROUP_CONCAT(CASE WHEN `status` = 2 THEN source ELSE NULL END SEPARATOR '<>' ) as sources
	        FROM {$table_name}";

			$result = $wpdb->get_row( $query, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

			$sources = ! empty( $result['sources'] ) ? explode( '<>', $result['sources'] ) : [];

			$sources = array_filter( array_unique( $sources ) );

			return [
				'total' => ! empty( $result ) ? intval( $result['total'] ?? 0 ) : 0,
				'active' => ! empty( $result ) ? intval( $result['active_count'] ?? 0 ) : 0,
				'sources' => array_values($sources),
			];
		}

		/**
		 * Gets broadcast statistics including total count and last execution time
		 *
		 * @return array Array with total_count and last_sent data
		 */
		private function get_broadcast_data() {
			global $wpdb;

			$broadcast_table = $wpdb->prefix . 'bwfan_broadcast';

			$query = "SELECT COUNT(id) as total_count, COUNT(CASE WHEN status = 4 THEN 1 ELSE NULL END) as completed_count, COUNT(CASE WHEN status = 2 THEN 1 ELSE NULL END) as scheduled_count, MAX(CASE WHEN status = 4 THEN execution_time ELSE NULL END) as last_sent FROM {$broadcast_table}";
			$result = $wpdb->get_row( $query, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			if ( ! is_array( $result ) || empty( $result ) ) {
				return [
					'total_count' => 0,
					'completed_count' => 0,
					'scheduled_count' => 0,
					'last_sent' => '',
				];
			}

			$data = $this->get_broadcast_conversion_data();
			$data = empty( $data ) ? [] : $data;
			$data['total_count'] = intval( $result['total_count'] ?? 0 );
			$data['completed_count'] = intval( $result['completed_count'] ?? 0 );
			$data['scheduled_count'] = intval( $result['scheduled_count'] ?? 0 );
			$data['conversion_count'] = intval( $data['order_count'] ?? 0 );
			$data['last_30_days_order_count'] = intval( $data['last_30_days_order_count'] ?? 0 );
			$data['last_sent'] = $result['last_sent'] ?? '';

			return $data;
		}

		/**
		 * Gets broadcast conversion data (orders and revenue from broadcasts)
		 *
		 * @return array Conversion data with order_count, last_30_days_order_count, revenue, last_30_days_revenue
		 */
		private function get_broadcast_conversion_data() {
			global $wpdb;

			$conversions_table = $wpdb->prefix . 'bwfan_conversions';

			// Total order count and revenue from all automation conversions where otype (object type) is 2 (broadcast) and wcid (order ID) is not 0
			$total_query = "SELECT COUNT(DISTINCT wcid) as order_count, COALESCE(SUM(wctotal), 0) as revenue
			FROM {$conversions_table}
			WHERE otype = 2 AND wcid != 0";

			$total_result = $wpdb->get_row( $total_query, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			if ( empty( $total_result ) ) {
				return [
					'order_count'              => 0,
					'last_30_days_order_count' => 0,
				];
			}

			// Last 30 days order count and revenue from automation conversions where otype (object type) is 2 (broadcast) and wcid (order ID) is not 0 and date is in last 30 days
			$last_30_days_query = "SELECT COUNT(DISTINCT wcid) as order_count FROM {$conversions_table} WHERE otype = 2 AND wcid != 0 AND date >= DATE_SUB(NOW(), INTERVAL 30 DAY)";

			$last_30_days_result = $wpdb->get_row( $last_30_days_query, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

			return [
				'order_count'              => intval( $total_result['order_count'] ?? 0 ),
				'last_30_days_order_count' => ! empty( $last_30_days_result ) ? intval( $last_30_days_result['order_count'] ?? 0 ) : 0,
			];
		}

		/**
		 * Gets count of active connectors
		 *
		 * @return array Count of active connectors
		 */
		private function get_active_connectors_data() {
			if ( ! bwfan_is_autonami_connector_active() ) {
				return [
					'count' => 0,
					'slugs' => []
				];
			}

			global $wpdb;

			$connectors_table = $wpdb->prefix . 'wfco_connectors';

			$query = "SELECT COUNT(ID) AS count,GROUP_CONCAT(DISTINCT slug) AS slugs FROM {$connectors_table} WHERE status = 1";

			$result = $wpdb->get_row( $query, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

			return [
				'count' => intval( $result['count'] ?? 0 ),
				'slugs' => ! empty( $result['slugs'] ) ? explode( ',', $result['slugs'] ) : []
			];
		}

		/**
		 * Gets total count of SMS sent
		 *
		 * @return int Total count of SMS sent
		 */
		private function get_total_sms_sent() {
			global $wpdb;

			$engagement_table = $wpdb->prefix . 'bwfan_engagement_tracking';

			// Total count of SMS sent where mode is 2 (SMS) and c_status is 2 (Sent)
			$query = "SELECT COUNT(ID) FROM {$engagement_table} WHERE mode = 2 AND c_status = 2";

			//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			return intval( $wpdb->get_var( $query ) );
		}

		/**
		 * Gets array of active transactional email slugs
		 *
		 * @return array List of active transactional mail slugs
		 */
		private function get_active_transactional_slugs() {
			if ( ! isset( BWFCRM_Core()->transactional_mails ) ) {
				return [];
			}

			$mail_obj      = BWFCRM_Core()->transactional_mails;
			$enabled_mails = $mail_obj->get_enabled_transactional_mails();

			if ( empty( $enabled_mails ) ) {
				return [];
			}

			$active_slugs = [];
			foreach ( $enabled_mails as $slug => $data ) {
				if ( isset( $data['status'] ) && $data['status'] === 'enabled' ) {
					$active_slugs[] = $slug;
				}
			}

			return $active_slugs;
		}

		/**
		 * Gets array of active Pro features based on settings
		 *
		 * @return array List of active features
		 */
		private function get_active_pro_features() {
			$settings        = get_option( 'bwfan_global_settings', [] );
			$active_features = [];

			$feature_keys = [
				'bwfan_enable_bounce_handling' => 'bounce_handling',
				'bwfan_disable_sms_tracking'   => 'disable_sms_tracking',
			];

			if ( bwfan_is_autonami_connector_active() && class_exists( 'BWFAN_Twilio_Webhook_Setup' ) && method_exists( 'BWFAN_Twilio_Webhook_Setup', 'get_webhooks' ) ) {
				$feature_keys['bwfan_twilio_shorten_url'] = 'twilio_url_shortener';
			}

			foreach ( $feature_keys as $setting_key => $feature_name ) {
				if ( isset( $settings[ $setting_key ] ) && filter_var( $settings[ $setting_key ], FILTER_VALIDATE_BOOLEAN ) ) {
					$active_features[] = $feature_name;
				}
			}

		return array_unique( $active_features );
	}

	/**
	 * Gets Pro audiences data
	 *
	 * @return array Audiences data with count
	 */
	private function get_pro_audiences_data() {
		global $wpdb;

		$terms_table = $wpdb->prefix . 'bwfan_terms';

		// Check if table exists
		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $terms_table ) ) !== $terms_table ) {
			return [
				'count' => 0,
			];
		}

		// Count audiences (type = 3)
		$query = $wpdb->prepare( "SELECT COUNT(ID) as count FROM {$terms_table} WHERE type = %d", 3 );

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->get_var( $query );

		return [
			'count' => intval( $result ?? 0 ),
		];
	}

	/**
	 * Gets Pro bulk actions data
	 *
	 * @return array Bulk actions data with run_count and action_slugs
	 */
	private function get_pro_bulk_actions_data() {
		global $wpdb;

		$bulk_action_table = $wpdb->prefix . 'bwfan_bulk_action';

		// Check if table exists
		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $bulk_action_table ) ) !== $bulk_action_table ) {
			return [
				'run_count'   => 0,
				'action_slugs' => [],
			];
		}

		// Count bulk actions run (status = 1 ongoing OR status = 2 completed)
		$query = "SELECT COUNT(ID) as run_count FROM {$bulk_action_table} WHERE status IN (1, 2)";

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$run_count = intval( $wpdb->get_var( $query ) ?? 0 );

		// Get action slugs from actions column (JSON)
		$actions_query = "SELECT actions FROM {$bulk_action_table} WHERE status IN (1, 2) AND actions != '' AND actions IS NOT NULL";

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$actions_results = $wpdb->get_results( $actions_query, ARRAY_A );

		$action_slugs = [];
		if ( ! empty( $actions_results ) && is_array( $actions_results ) ) {
			foreach ( $actions_results as $row ) {
				$actions_json = $row['actions'] ?? '';
				if ( empty( $actions_json ) || ! is_string( $actions_json ) ) {
					continue;
				}

				$actions_data = json_decode( $actions_json, true );
				if ( empty( $actions_data ) || ! is_array( $actions_data ) ) {
					continue;
				}

				// Extract action slugs from the actions array
				foreach ( $actions_data as $action ) {
					if ( isset( $action['action'] ) && ! empty( $action['action'] ) ) {
						$action_slugs[] = $action['action'];
					}
				}
			}
		}

		$action_slugs = array_filter( array_unique( $action_slugs ) );

		return [
			'run_count'    => $run_count,
			'action_slugs' => array_values( $action_slugs ),
		];
	}

	/**
	 * Gets Pro broadcast detailed data
	 *
	 * @return array Broadcast detailed data with counts and engagement rates
	 */
	private function get_pro_broadcast_detailed_data() {
		global $wpdb;

		$broadcast_table = $wpdb->prefix . 'bwfan_broadcast';
		$engagement_table = $wpdb->prefix . 'bwfan_engagement_tracking';

		// Check if broadcast table exists
		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $broadcast_table ) ) !== $broadcast_table ) {
			return [
				'email_count'         => 0,
				'sms_count'           => 0,
				'whatsapp_count'      => 0,
				'ab_test_count'       => 0,
				'smart_sending_count' => 0,
				'send_to_unopen_count' => 0,
				'avg_open_rate'       => 0.0,
				'avg_click_rate'      => 0.0,
			];
		}

		// Count broadcasts by type (type = 1 email, type = 2 SMS, type = 3 WhatsApp)
		$type_query = "SELECT
			SUM(CASE WHEN type = 1 THEN 1 ELSE 0 END) as email_count,
			SUM(CASE WHEN type = 2 THEN 1 ELSE 0 END) as sms_count,
			SUM(CASE WHEN type = 3 THEN 1 ELSE 0 END) as whatsapp_count
			FROM {$broadcast_table} WHERE parent = 0";

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$type_result = $wpdb->get_row( $type_query, ARRAY_A );

		$email_count = intval( $type_result['email_count'] ?? 0 );
		$sms_count = intval( $type_result['sms_count'] ?? 0 );
		$whatsapp_count = intval( $type_result['whatsapp_count'] ?? 0 );

		// Count A/B test broadcasts (count distinct parent IDs where parent > 0, which gives us number of A/B tests)
		$ab_test_query = "SELECT COUNT(DISTINCT parent) as ab_test_count
			FROM {$broadcast_table} WHERE parent > 0";

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$ab_test_count = intval( $wpdb->get_var( $ab_test_query ) ?? 0 );

		// Get broadcasts with data column to parse JSON for smart sending and send to unopen
		$data_query = "SELECT id, data FROM {$broadcast_table} WHERE data != '' AND data IS NOT NULL AND parent = 0";

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$data_results = $wpdb->get_results( $data_query, ARRAY_A );

		$smart_sending_count = 0;
		$send_to_unopen_count = 0;

		if ( ! empty( $data_results ) && is_array( $data_results ) ) {
			foreach ( $data_results as $row ) {
				$data_json = $row['data'] ?? '';
				if ( empty( $data_json ) || ! is_string( $data_json ) ) {
					continue;
				}

				$data = json_decode( $data_json, true );
				if ( empty( $data ) || ! is_array( $data ) ) {
					continue;
				}

				// Check for smart sending
				if ( isset( $data['smart_send'] ) && is_array( $data['smart_send'] ) && isset( $data['smart_send']['enable'] ) && true === $data['smart_send']['enable'] ) {
					$smart_sending_count++;
				}

				// Check for send to unopen (parent field in data indicates unopen broadcast)
				if ( isset( $data['parent'] ) && ! empty( $data['parent'] ) ) {
					$send_to_unopen_count++;
				}
			}
		}

		// Calculate average open and click rates from engagement tracking
		$avg_open_rate = 0.0;
		$avg_click_rate = 0.0;

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $engagement_table ) ) === $engagement_table ) {
			// Get open and click rates per broadcast, then calculate average
			$rates_query = "SELECT
				oid,
				(SUM(IF(open > 0, 1, 0)) / COUNT(ID)) * 100 as open_rate,
				(SUM(IF(click > 0, 1, 0)) / COUNT(ID)) * 100 as click_rate
				FROM {$engagement_table}
				WHERE type = 2 AND c_status = 2
				GROUP BY oid";

			//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$rates_results = $wpdb->get_results( $rates_query, ARRAY_A );

			if ( ! empty( $rates_results ) && is_array( $rates_results ) ) {
				$total_open_rate = 0.0;
				$total_click_rate = 0.0;
				$broadcast_count = count( $rates_results );

				foreach ( $rates_results as $rate_row ) {
					$total_open_rate += floatval( $rate_row['open_rate'] ?? 0 );
					$total_click_rate += floatval( $rate_row['click_rate'] ?? 0 );
				}

				if ( $broadcast_count > 0 ) {
					$avg_open_rate = $total_open_rate / $broadcast_count;
					$avg_click_rate = $total_click_rate / $broadcast_count;
				}
			}
		}

		return [
			'email_count'         => $email_count,
			'sms_count'           => $sms_count,
			'whatsapp_count'      => $whatsapp_count,
			'ab_test_count'       => $ab_test_count,
			'smart_sending_count' => $smart_sending_count,
			'send_to_unopen_count' => $send_to_unopen_count,
			'avg_open_rate'       => round( $avg_open_rate, 2 ),
			'avg_click_rate'      => round( $avg_click_rate, 2 ),
		];
	}

	/**
	 * Gets Pro templates data
	 *
	 * @return array Templates data with user_created_count
	 */
	private function get_pro_templates_data() {
		global $wpdb;

		$templates_table = $wpdb->prefix . 'bwfan_templates';

		// Check if table exists
		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $templates_table ) ) !== $templates_table ) {
			return [
				'user_created_count' => 0,
			];
		}

		// Count user-created templates (canned = 1)
		$query = "SELECT COUNT(ID) as user_created_count FROM {$templates_table} WHERE canned = 1";

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->get_var( $query );

		return [
			'user_created_count' => intval( $result ?? 0 ),
		];
	}

	/**
	 * Gets Pro transactional emails data
	 *
	 * @return array Transactional emails data with sent_count
	 */
	private function get_pro_transactional_emails_data() {
		global $wpdb;

		$engagement_table = $wpdb->prefix . 'bwfan_engagement_tracking';

		// Check if table exists
		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $engagement_table ) ) !== $engagement_table ) {
			return [
				'sent_count' => 0,
			];
		}

		// Count transactional emails sent (type = 9, mode = 1 email, c_status = 2 sent)
		$query = "SELECT COUNT(ID) as sent_count FROM {$engagement_table} WHERE type = 9 AND mode = 1 AND c_status = 2";

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->get_var( $query );

		return [
			'sent_count' => intval( $result ?? 0 ),
		];
	}

	/**
	 * Gets Pro REST API keys data
	 *
	 * @return array REST API keys data with active_count, permissions, and dates
	 */
	private function get_pro_rest_api_keys_data() {
		global $wpdb;

		$api_keys_table = $wpdb->prefix . 'bwfan_api_keys';

		// Check if table exists
		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $api_keys_table ) ) !== $api_keys_table ) {
			return [
				'active_count'      => 0,
				'permissions'       => [
					'read_count'  => 0,
					'write_count' => 0,
					'both_count'  => 0,
				],
				'first_created_date' => '',
				'last_used_date'     => '',
			];
		}

		// Get active API keys data (status = 1)
		$query = "SELECT
			COUNT(id) as active_count,
			SUM(CASE WHEN permission = 1 THEN 1 ELSE 0 END) as read_count,
			SUM(CASE WHEN permission = 2 THEN 1 ELSE 0 END) as write_count,
			SUM(CASE WHEN permission = 3 THEN 1 ELSE 0 END) as both_count,
			MIN(created_at) as first_created_date,
			MAX(CASE WHEN last_access != '0000-00-00 00:00:00' AND last_access IS NOT NULL THEN last_access ELSE NULL END) as last_used_date
			FROM {$api_keys_table} WHERE status = 1";

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->get_row( $query, ARRAY_A );

		if ( empty( $result ) ) {
			return [
				'active_count'        => 0,
				'permissions'         => [
					'read_count'  => 0,
					'write_count' => 0,
					'both_count'  => 0,
				],
				'first_created_date' => '',
				'last_used_date'     => '',
			];
		}

		return [
			'active_count'        => intval( $result['active_count'] ?? 0 ),
			'permissions'         => [
				'read_count'  => intval( $result['read_count'] ?? 0 ),
				'write_count' => intval( $result['write_count'] ?? 0 ),
				'both_count'  => intval( $result['both_count'] ?? 0 ),
			],
			'first_created_date' => $result['first_created_date'] ?? '',
			'last_used_date'     => $result['last_used_date'] ?? '',
		];
	}

	/**
	 * Gets Lite duplicate contacts data
	 *
	 * @return array Duplicate contacts data with duplicate_emails_count and duplicate_phones_count
	 */
	private function get_lite_duplicate_contacts_data() {
		global $wpdb;

		$contacts_table = $wpdb->prefix . 'bwf_contact';

		// Count duplicate emails (contacts with same email address)
		$duplicate_emails_query = "SELECT COUNT(*) as duplicate_count
			FROM (
				SELECT email, COUNT(*) as cnt
				FROM {$contacts_table}
				WHERE email != '' AND email IS NOT NULL
				GROUP BY email
				HAVING cnt > 1
			) as duplicates";

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$duplicate_emails_count = intval( $wpdb->get_var( $duplicate_emails_query ) );

		// Count duplicate phone numbers (contacts with same contact_no)
		$duplicate_phones_query = "SELECT COUNT(*) as duplicate_count
			FROM (
				SELECT contact_no, COUNT(*) as cnt
				FROM {$contacts_table}
				WHERE contact_no != '' AND contact_no IS NOT NULL
				GROUP BY contact_no
				HAVING cnt > 1
			) as duplicates";

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$duplicate_phones_count = intval( $wpdb->get_var( $duplicate_phones_query ) );

		return [
			'duplicate_emails_count' => $duplicate_emails_count,
			'duplicate_phones_count' => $duplicate_phones_count,
		];
	}

	/**
	 * Gets Lite lists and tags data
	 *
	 * @return array Lists and tags data with lists_count and tags_count
	 */
	private function get_lite_lists_tags_data() {
		global $wpdb;

		$terms_table = $wpdb->prefix . 'bwfan_terms';

		// Check if table exists
		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $terms_table ) ) !== $terms_table ) {
			return [
				'lists_count' => 0,
				'tags_count'  => 0,
			];
		}

		// Count lists (type = 2) and tags (type = 1)
		$query = "SELECT
			SUM(CASE WHEN type = 2 THEN 1 ELSE 0 END) as lists_count,
			SUM(CASE WHEN type = 1 THEN 1 ELSE 0 END) as tags_count
			FROM {$terms_table}";

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->get_row( $query, ARRAY_A );

		if ( empty( $result ) ) {
			return [
				'lists_count' => 0,
				'tags_count'  => 0,
			];
		}

		return [
			'lists_count' => intval( $result['lists_count'] ?? 0 ),
			'tags_count'  => intval( $result['tags_count'] ?? 0 ),
		];
	}

	/**
	 * Gets Lite custom fields data
	 *
	 * @return array Custom fields data with total_count and types array
	 */
	private function get_lite_custom_fields_data() {
		global $wpdb;

		$fields_table = $wpdb->prefix . 'bwfan_fields';

		// Check if table exists
		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $fields_table ) ) !== $fields_table ) {
			return [
				'total_count' => 0,
				'types'       => [],
			];
		}

		// Get total count and group by type with text labels
		$query = "SELECT
			CASE
				WHEN type = 1 THEN 'text'
				WHEN type = 2 THEN 'number'
				WHEN type = 3 THEN 'textarea'
				WHEN type = 4 THEN 'select'
				WHEN type = 5 THEN 'radio'
				WHEN type = 6 THEN 'checkbox'
				WHEN type = 7 THEN 'date'
				WHEN type = 8 THEN 'datetime'
				WHEN type = 9 THEN 'time'
				ELSE CONCAT('type_', type)
			END as type_text,
			COUNT(*) as count
			FROM {$fields_table}
			GROUP BY type";

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$results = $wpdb->get_results( $query, ARRAY_A );

		$total_count = 0;
		$types       = [];

		if ( ! empty( $results ) && is_array( $results ) ) {
			foreach ( $results as $row ) {
				$type_text = $row['type_text'] ?? '';
				$count     = intval( $row['count'] ?? 0 );
				$total_count += $count;
				if ( ! empty( $type_text ) ) {
					$types[ $type_text ] = $count;
				}
			}
		}

		return [
			'total_count' => $total_count,
			'types'       => $types,
		];
	}

	/**
	 * Gets Lite automation v1 data
	 *
	 * @return array Automation v1 data with active (1 or 0), total_count, and active_slugs
	 */
	private function get_lite_automation_v1_data() {
		global $wpdb;

		$automations_table = $wpdb->prefix . 'bwfan_automations';

		// Get v1 automations data (v = 1)
		$query = "SELECT
			COUNT(DISTINCT ID) as total_count,
			SUM(CASE WHEN status = 1 AND v = 1 THEN 1 ELSE 0 END) as active_count,
			GROUP_CONCAT(DISTINCT CASE WHEN status = 1 AND v = 1 AND event != '' THEN event ELSE NULL END) as active_events
			FROM {$automations_table}
			WHERE v = 1";

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->get_row( $query, ARRAY_A );

		if ( empty( $result ) ) {
			return [
				'active'      => 0,
				'total_count' => 0,
				'active_slugs' => [],
			];
		}

		$total_count = intval( $result['total_count'] ?? 0 );
		$active_count = intval( $result['active_count'] ?? 0 );
		$active = $active_count > 0 ? 1 : 0;

		// Parse active event slugs
		$active_slugs = [];
		if ( ! empty( $result['active_events'] ) ) {
			$events = explode( ',', $result['active_events'] );
			$active_slugs = array_filter( array_values( array_unique( $events ) ) );
		}

		return [
			'active'       => $active,
			'total_count'  => $total_count,
			'active_slugs' => array_values( $active_slugs ),
		];
	}

	/**
	 * Gets Lite settings data
	 *
	 * @return array Settings data with all requested settings
	 */
	private function get_lite_settings_data() {
		$settings = get_option( 'bwfan_global_settings', [] );

		return [
			'wait_period'                          => intval( $settings['bwfan_ab_init_wait_time'] ?? 0 ),
			'cool_off_period'                      => intval( $settings['bwfan_disable_abandonment_days'] ?? 0 ),
			'lost_cart_days'                       => intval( $settings['bwfan_ab_mark_lost_cart'] ?? 0 ),
			'gdpr_consent'                         => intval( $settings['bwfan_ab_email_consent'] ?? 0 ),
			'email_marketing_consent'              => intval( $settings['bwfan_user_consent'] ?? 0 ),
			'subscribe_page_manage_list_active'    => intval( $settings['bwfan_subscribe_page_manage_list_active'] ?? 0 ),
			'delete_expired_coupon'                => intval( $settings['bwfan_delete_expired_coupon'] ?? 0 ),
			'delete_engagement_tracking_meta_days' => intval( $settings['bwfan_delete_engagement_tracking_meta_days'] ?? 0 ),
		];
	}

	/**
	 * Collect Lite data (fallback method for backward compatibility)
	 * Used when Lite collector is not available
	 *
	 * @return array Lite data
	 */
	private function collect_lite_data() {
		$contacts_data = $this->get_lite_contacts_data();
		$orders_data    = $this->get_lite_orders_data();
		$carts_data     = $this->get_lite_carts_data();
		$automations_data = $this->get_lite_automations_data();
		$active_features = $this->get_lite_active_features();
		$duplicate_contacts_data = $this->get_lite_duplicate_contacts_data();
		$lists_tags_data = $this->get_lite_lists_tags_data();
		$custom_fields_data = $this->get_lite_custom_fields_data();
		$automation_v1_data = $this->get_lite_automation_v1_data();
		$settings_data = $this->get_lite_settings_data();

		return [
			'lite'           => defined( 'BWFAN_VERSION' ) ? BWFAN_VERSION : '',
			'install_date'   => bwf_options_get( 'fka_psd' ),
			'features'       => [
				'active'     => $active_features,
				'automation/total' => $automations_data['total_count'],
				'automation/active' => $automations_data['active_count'],
				'automation/events' => $automations_data['event_slugs'],
				'automation/goals' => $automations_data['goals_slugs'],
				'automation/steps/actions' => $automations_data['steps_actions'],
				'automation/steps/active' => $automations_data['steps_active_count'],
				'automation/conversion' => $automations_data['order_count'],
				"contact/total" => $contacts_data['total_count'],
				"contact/subscribed" => $contacts_data['subscribed_count'],
				"contact/duplicate_emails" => $duplicate_contacts_data['duplicate_emails_count'],
				"contact/duplicate_phones" => $duplicate_contacts_data['duplicate_phones_count'],
				"customer/orders" => $orders_data['total_orders'],
				"cart/total" => $carts_data['total_count'],
				"engagement/email" => $this->get_lite_total_email_sent(),
				"lists/total" => $lists_tags_data['lists_count'],
				"tags/total" => $lists_tags_data['tags_count'],
				"custom_fields/total" => $custom_fields_data['total_count'],
				"custom_fields/types" => $custom_fields_data['types'],
				"automation/v1/active" => $automation_v1_data['active'],
				"automation/v1/total" => $automation_v1_data['total_count'],
				"automation/v1/active_slugs" => $automation_v1_data['active_slugs'],
			],
			'settings' => $settings_data,
			'feature_performance' => [
				'automation/last_30_days_order_count' => $automations_data['last_30_days_order_count'],
				"cart/last_30_days_count" => $carts_data['last_30_days_count'],
			]
		];
	}

	/**
	 * Gets Lite Automations data
	 *
	 * @return array automations data
	 */
	private function get_lite_automations_data() {
		$count_data     = $this->get_lite_automation_count();
		$conversion_data = $this->get_lite_automation_conversion_data();

		return [
			'total_count'              => $count_data['total_count'],
			'active_count'             => $count_data['active_count'],
			'event_slugs'              => $count_data['event_slugs'],
			'goals_slugs'              => $count_data['goals_slugs'],
			'steps_actions'            => $count_data['steps_actions'],
			'steps_active_count'       => $count_data['steps_active_count'],
			'order_count'              => $conversion_data['order_count'],
			'last_30_days_order_count' => $conversion_data['last_30_days_order_count'],
		];
	}

	/**
	 * Gets Lite automation count data
	 *
	 * @return array automation count data
	 */
	private function get_lite_automation_count() {
		global $wpdb;

		$automations_table = $wpdb->prefix . 'bwfan_automations';

		$query = "SELECT COUNT(DISTINCT ID) as total_count,
            SUM(CASE WHEN status = 1 THEN 1 ELSE 0 END) as active_count,
            GROUP_CONCAT(CASE WHEN status = 1 AND event != '' THEN event ELSE NULL END) as events,
            GROUP_CONCAT(CASE WHEN status = 1 AND  benchmark != '' THEN benchmark ELSE NULL END SEPARATOR '<>' ) as benchmark
	        FROM {$automations_table}";

		$result = $wpdb->get_row( $query, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		if ( ! is_array( $result ) || empty( $result ) ) {
			return [
				'total_count'  => 0,
				'active_count' => 0,
				'event_slugs'  => [],
			];
		}
		$events = ! empty( $result['events'] ) ? array_filter( array_values( array_unique( explode( ',', $result['events'] ) ) ) ) : [];
		$benchmark = ! empty( $result['benchmark'] ) ? explode( '<>', $result['benchmark'] ) : [];
		$benchmark_slugs = [];
		foreach( $benchmark as $item ) {
			$item = ! empty( $item ) && is_string( $item ) ? json_decode( $item, true ) : [];
			if( empty( $item ) || ! is_array( $item ) ) {
				continue;
			}
			$benchmark_slugs = array_merge( $benchmark_slugs, array_values( $item ) );
		}
		$steps_actions = $this->get_lite_steps_data();
		$benchmark_slugs = array_filter( array_unique( $benchmark_slugs ) );
		return [
			'total_count'  => (int) ( $result['total_count'] ?? 0 ),
			'active_count' => (int) ( $result['active_count'] ?? 0 ),
			'event_slugs'  => array_values($events),
			'goals_slugs'  => array_values($benchmark_slugs),
			'steps_actions' => array_values($steps_actions['actions']),
			'steps_active_count' => $steps_actions['active_count'],
		];
	}

	/**
	 * Gets Lite steps data
	 *
	 * @return array steps data
	 */
	private function get_lite_steps_data() {
		global $wpdb;
		$automations_table = $wpdb->prefix . 'bwfan_automations';
		$steps_table = $wpdb->prefix . 'bwfan_automation_step';

		$query = "SELECT COUNT(DISTINCT s.ID) as total_count,
			SUM(CASE WHEN s.status = 1 THEN 1 ELSE 0 END) as active_count,
			GROUP_CONCAT(CASE WHEN s.action != '' THEN s.action ELSE NULL END SEPARATOR '<>' ) as actions
			FROM {$steps_table} as s JOIN {$automations_table} as a ON s.aid = a.ID WHERE a.status = 1 AND s.type = 2 AND s.status = 1";
		$result = $wpdb->get_row( $query, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		if( ! is_array( $result ) || empty( $result ) ) {
			return [
				'total_count' => 0,
				'active_count' => 0,
				'actions' => [],
			];
		}

		$actions = ! empty( $result['actions'] ) ? explode( '<>', $result['actions'] ) : [];
		$actions_slugs = [];
		if ( ! empty( $actions ) ) {
			foreach( $actions as $item ) {
				if( empty( $item ) ) {
					continue;
				}
				$item = ! empty( $item ) && is_string( $item ) ? json_decode( $item, true ) : [];
				if( empty( $item ) || ! is_array( $item ) || empty( $item['action'] ) ) {
					continue;
				}
				$actions_slugs[] = $item['action'];
			}
			$actions_slugs = array_filter( array_unique( $actions_slugs ) );
		}

		return [
			'total_count' => (int) ( $result['total_count'] ?? 0 ),
			'active_count' => (int) ( $result['active_count'] ?? 0 ),
			'actions' => array_values($actions_slugs),
		];
	}

	/**
	 * Gets Lite automation conversion data
	 *
	 * @return array Conversion data
	 */
	private function get_lite_automation_conversion_data() {
		global $wpdb;

		$conversions_table = $wpdb->prefix . 'bwfan_conversions';

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $conversions_table ) ) !== $conversions_table ) {
			return [
				'order_count'              => 0,
				'last_30_days_order_count' => 0,
			];
		}

		$total_query = "SELECT COUNT(DISTINCT wcid) as order_count FROM {$conversions_table}
			WHERE otype = 1 AND wcid != 0";

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$total_result = $wpdb->get_row( $total_query, ARRAY_A );

		$last_30_days_query = "SELECT COUNT(DISTINCT wcid) as order_count FROM {$conversions_table} WHERE otype = 1 AND wcid != 0 AND date >= DATE_SUB(NOW(), INTERVAL 30 DAY)";

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$last_30_days_result = $wpdb->get_row( $last_30_days_query, ARRAY_A );

		return [
			'order_count'              => (int) ( $total_result['order_count'] ?? 0 ),
			'last_30_days_order_count' => (int) ( $last_30_days_result['order_count'] ?? 0 ),
		];
	}

	/**
	 * Gets Lite contacts count
	 *
	 * @param bool $active_count Whether to get only subscribed/active contacts
	 * @return int Count of contacts
	 */
	private function get_lite_contacts_count($active_count = false) {
		global $wpdb;

		$contacts_table = $wpdb->prefix . 'bwf_contact';

		$query = "SELECT COUNT(c.id) FROM {$contacts_table} AS c WHERE c.email != '' AND c.email IS NOT NULL";
		if ( true === $active_count ) {
			$query .= " AND c.status = 1 AND NOT EXISTS (SELECT 1 FROM {$wpdb->prefix}bwfan_message_unsubscribe AS unsub WHERE unsub.recipient = c.email )";
			$query .= " AND NOT EXISTS (SELECT 1 FROM {$wpdb->prefix}bwfan_message_unsubscribe AS unsub1 WHERE unsub1.recipient = c.contact_no )";
		}

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return intval( $wpdb->get_var( $query ) );
	}

	/**
	 * Gets Lite contacts data
	 *
	 * @return array contacts data
	 */
	private function get_lite_contacts_data() {
		$data = [
			'total_count' => $this->get_lite_contacts_count(),
			'subscribed_count' => $this->get_lite_contacts_count(true),
		];
		return $data;
	}

	/**
	 * Gets Lite active features
	 *
	 * @return array List of active features
	 */
	private function get_lite_active_features() {
		$settings        = get_option( 'bwfan_global_settings', [] );
		$active_features = [];

		$feature_keys = [
			'bwfan_enable_notification'  => 'notifications',
			'bwfan_ab_enable'            => 'cart_abandonment',
			'bwfan_user_consent'         => 'user_consent',
			'bwfan_dob_field'            => 'dob_field',
			'bwfan_dob_field_my_account' => 'dob_field_my_account',
			'bwfan_sandbox_mode'         => 'sandbox_mode',
			'bwfan_make_logs'            => 'basic_logging',
			'bwfan_advance_logs'         => 'advance_logging',
		];

		foreach ( $feature_keys as $setting_key => $feature_name ) {
			if ( isset( $settings[ $setting_key ] ) && filter_var( $settings[ $setting_key ], FILTER_VALIDATE_BOOLEAN ) ) {
				$active_features[] = $feature_name;
			}
		}

		return array_unique( $active_features );
	}

	/**
	 * Gets Lite total email sent
	 *
	 * @return int Total count of emails sent
	 */
	private function get_lite_total_email_sent() {
		global $wpdb;

		$engagement_table = $wpdb->prefix . 'bwfan_engagement_tracking';

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $engagement_table ) ) !== $engagement_table ) {
			return 0;
		}

		$query = "SELECT COUNT(ID) FROM {$engagement_table} WHERE mode = 1 AND c_status = 2";

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return intval( $wpdb->get_var( $query ) );
	}

	/**
	 * Gets Lite orders data
	 *
	 * @return array Orders data
	 */
	private function get_lite_orders_data() {
		global $wpdb;

		$customers_table = $wpdb->prefix . 'bwf_wc_customers';

		$query = "SELECT COALESCE(SUM(total_order_count), 0) as total_orders, COALESCE(SUM(total_order_value), 0) as revenue FROM {$customers_table}";

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->get_row( $query, ARRAY_A );

		if ( ! is_array( $result ) ) {
			return [
				'total_orders' => 0,
			];
		}

		return [
			'total_orders' => (int) ( $result['total_orders'] ?? 0 ),
		];
	}

	/**
	 * Gets Lite carts data
	 *
	 * @return array Carts data
	 */
	private function get_lite_carts_data() {
		global $wpdb;

		$carts_table = $wpdb->prefix . 'bwfan_abandonedcarts';

		$total_query = "SELECT COUNT(ID) FROM {$carts_table}";

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$total_count = intval( $wpdb->get_var( $total_query ) );

		$last_30_days_query = "SELECT COUNT(ID) FROM {$carts_table}
			WHERE created_time >= DATE_SUB(NOW(), INTERVAL 30 DAY)";

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$last_30_days_count = intval( $wpdb->get_var( $last_30_days_query ) );

		return [
			'total_count'        => $total_count,
			'last_30_days_count' => $last_30_days_count,
		];
	}

	/**
	 * Merge Lite and Pro data into final structure
	 *
	 * @param array $lite_data Lite usage data
	 * @param array $pro_data Pro usage data
	 * @return array Merged data
	 */
	private function merge_lite_and_pro_data( $lite_data, $pro_data ) {
			$data = $lite_data;

			if ( ! is_array( $data ) ) {
				$data = array();
			}

			// Add Pro version
			if ( defined( 'BWFAN_PRO_VERSION' ) ) {
				$data['pro'] = BWFAN_PRO_VERSION;
			}

			// Merge Pro features into Lite features
			if ( ! empty( $pro_data['pro_features'] ) && is_array( $pro_data['pro_features'] ) ) {
				if ( ! isset( $data['features'] ) ) {
					$data['features'] = array();
				}
				if ( ! isset( $data['features']['active'] ) ) {
					$data['features']['active'] = array();
				}
				if ( is_array( $data['features']['active'] ) ) {
					$data['features']['active'] = array_merge( $data['features']['active'], $pro_data['pro_features'] );
				} else {
					$data['features']['active'] = $pro_data['pro_features'];
				}
			}

			// Add Pro feature data
			$pro_data_features = array();
			if ( isset( $pro_data['sms_sent'] ) ) {
				$pro_data_features['engagement/sms'] = $pro_data['sms_sent'];
			}
			if ( ! empty( $pro_data['broadcast'] ) && is_array( $pro_data['broadcast'] ) ) {
				$pro_data_features['broadcast/total'] = isset( $pro_data['broadcast']['total_count'] ) ? intval( $pro_data['broadcast']['total_count'] ) : 0;
				$pro_data_features['broadcast/completed'] = isset( $pro_data['broadcast']['completed_count'] ) ? intval( $pro_data['broadcast']['completed_count'] ) : 0;
				$pro_data_features['broadcast/scheduled'] = isset( $pro_data['broadcast']['scheduled_count'] ) ? intval( $pro_data['broadcast']['scheduled_count'] ) : 0;
				$pro_data_features['broadcast/conversion'] = isset( $pro_data['broadcast']['conversion_count'] ) ? intval( $pro_data['broadcast']['conversion_count'] ) : 0;
			}
			if ( ! empty( $pro_data['transactional_email'] ) && is_array( $pro_data['transactional_email'] ) ) {
				$pro_data_features['transactional/email'] = $pro_data['transactional_email'];
			}
			if ( ! empty( $pro_data['link_trigger'] ) && is_array( $pro_data['link_trigger'] ) ) {
				$pro_data_features['link_trigger/total'] = isset( $pro_data['link_trigger']['total_count'] ) ? intval( $pro_data['link_trigger']['total_count'] ) : 0;
				$pro_data_features['link_trigger/active'] = isset( $pro_data['link_trigger']['active_count'] ) ? intval( $pro_data['link_trigger']['active_count'] ) : 0;
				$pro_data_features['link_trigger/actions'] = isset( $pro_data['link_trigger']['actions'] ) && is_array( $pro_data['link_trigger']['actions'] ) ? $pro_data['link_trigger']['actions'] : array();
			}
			if ( ! empty( $pro_data['form_feed'] ) && is_array( $pro_data['form_feed'] ) ) {
				$pro_data_features['form_feed/total'] = isset( $pro_data['form_feed']['total'] ) ? intval( $pro_data['form_feed']['total'] ) : 0;
				$pro_data_features['form_feed/active'] = isset( $pro_data['form_feed']['active'] ) ? intval( $pro_data['form_feed']['active'] ) : 0;
				$pro_data_features['form_feed/sources'] = isset( $pro_data['form_feed']['sources'] ) && is_array( $pro_data['form_feed']['sources'] ) ? $pro_data['form_feed']['sources'] : array();
			}
			if ( ! empty( $pro_data['connectors'] ) && is_array( $pro_data['connectors'] ) ) {
				$pro_data_features['connector/total'] = isset( $pro_data['connectors']['count'] ) ? intval( $pro_data['connectors']['count'] ) : 0;
				$pro_data_features['connector/slugs'] = isset( $pro_data['connectors']['slugs'] ) && is_array( $pro_data['connectors']['slugs'] ) ? $pro_data['connectors']['slugs'] : array();
			}

			// Add new Pro data features
			if ( ! empty( $pro_data['audiences'] ) && is_array( $pro_data['audiences'] ) ) {
				$pro_data_features['audiences/count'] = isset( $pro_data['audiences']['count'] ) ? intval( $pro_data['audiences']['count'] ) : 0;
			}

			if ( ! empty( $pro_data['bulk_actions'] ) && is_array( $pro_data['bulk_actions'] ) ) {
				$pro_data_features['bulk_actions/run_count'] = isset( $pro_data['bulk_actions']['run_count'] ) ? intval( $pro_data['bulk_actions']['run_count'] ) : 0;
				$pro_data_features['bulk_actions/action_slugs'] = isset( $pro_data['bulk_actions']['action_slugs'] ) && is_array( $pro_data['bulk_actions']['action_slugs'] ) ? $pro_data['bulk_actions']['action_slugs'] : array();
			}

			if ( ! empty( $pro_data['broadcasts_detailed'] ) && is_array( $pro_data['broadcasts_detailed'] ) ) {
				$pro_data_features['broadcasts_detailed/email_count'] = isset( $pro_data['broadcasts_detailed']['email_count'] ) ? intval( $pro_data['broadcasts_detailed']['email_count'] ) : 0;
				$pro_data_features['broadcasts_detailed/sms_count'] = isset( $pro_data['broadcasts_detailed']['sms_count'] ) ? intval( $pro_data['broadcasts_detailed']['sms_count'] ) : 0;
				$pro_data_features['broadcasts_detailed/whatsapp_count'] = isset( $pro_data['broadcasts_detailed']['whatsapp_count'] ) ? intval( $pro_data['broadcasts_detailed']['whatsapp_count'] ) : 0;
				$pro_data_features['broadcasts_detailed/ab_test_count'] = isset( $pro_data['broadcasts_detailed']['ab_test_count'] ) ? intval( $pro_data['broadcasts_detailed']['ab_test_count'] ) : 0;
				$pro_data_features['broadcasts_detailed/smart_sending_count'] = isset( $pro_data['broadcasts_detailed']['smart_sending_count'] ) ? intval( $pro_data['broadcasts_detailed']['smart_sending_count'] ) : 0;
				$pro_data_features['broadcasts_detailed/send_to_unopen_count'] = isset( $pro_data['broadcasts_detailed']['send_to_unopen_count'] ) ? intval( $pro_data['broadcasts_detailed']['send_to_unopen_count'] ) : 0;
				$pro_data_features['broadcasts_detailed/avg_open_rate'] = isset( $pro_data['broadcasts_detailed']['avg_open_rate'] ) ? floatval( $pro_data['broadcasts_detailed']['avg_open_rate'] ) : 0.0;
				$pro_data_features['broadcasts_detailed/avg_click_rate'] = isset( $pro_data['broadcasts_detailed']['avg_click_rate'] ) ? floatval( $pro_data['broadcasts_detailed']['avg_click_rate'] ) : 0.0;
			}

			if ( ! empty( $pro_data['templates'] ) && is_array( $pro_data['templates'] ) ) {
				$pro_data_features['templates/user_created_count'] = isset( $pro_data['templates']['user_created_count'] ) ? intval( $pro_data['templates']['user_created_count'] ) : 0;
			}

			if ( ! empty( $pro_data['transactional_emails'] ) && is_array( $pro_data['transactional_emails'] ) ) {
				$pro_data_features['transactional_emails/sent_count'] = isset( $pro_data['transactional_emails']['sent_count'] ) ? intval( $pro_data['transactional_emails']['sent_count'] ) : 0;
			}

			if ( ! empty( $pro_data['rest_api_keys'] ) && is_array( $pro_data['rest_api_keys'] ) ) {
				$pro_data_features['rest_api_keys/active_count'] = isset( $pro_data['rest_api_keys']['active_count'] ) ? intval( $pro_data['rest_api_keys']['active_count'] ) : 0;
				if ( ! empty( $pro_data['rest_api_keys']['permissions'] ) && is_array( $pro_data['rest_api_keys']['permissions'] ) ) {
					$pro_data_features['rest_api_keys/permissions/read_count'] = isset( $pro_data['rest_api_keys']['permissions']['read_count'] ) ? intval( $pro_data['rest_api_keys']['permissions']['read_count'] ) : 0;
					$pro_data_features['rest_api_keys/permissions/write_count'] = isset( $pro_data['rest_api_keys']['permissions']['write_count'] ) ? intval( $pro_data['rest_api_keys']['permissions']['write_count'] ) : 0;
					$pro_data_features['rest_api_keys/permissions/both_count'] = isset( $pro_data['rest_api_keys']['permissions']['both_count'] ) ? intval( $pro_data['rest_api_keys']['permissions']['both_count'] ) : 0;
				}
				$pro_data_features['rest_api_keys/first_created_date'] = isset( $pro_data['rest_api_keys']['first_created_date'] ) ? $pro_data['rest_api_keys']['first_created_date'] : '';
				$pro_data_features['rest_api_keys/last_used_date'] = isset( $pro_data['rest_api_keys']['last_used_date'] ) ? $pro_data['rest_api_keys']['last_used_date'] : '';
			}

			if ( ! empty( $pro_data_features ) ) {
				if ( ! isset( $data['features'] ) ) {
					$data['features'] = array();
				}
				$data['features'] = array_merge( $data['features'], $pro_data_features );
			}

			// Add Pro feature performance
			$pro_feature_performance = array();
			if ( ! empty( $pro_data['broadcast'] ) && is_array( $pro_data['broadcast'] ) ) {
				if ( ! empty( $pro_data['broadcast']['last_sent'] ) ) {
					$pro_feature_performance['broadcast/last_sent'] = $pro_data['broadcast']['last_sent'];
				}
				if ( isset( $pro_data['broadcast']['last_30_days_order_count'] ) ) {
					$pro_feature_performance['broadcast/last_30_days_order_count'] = intval( $pro_data['broadcast']['last_30_days_order_count'] );
				}
			}

			if ( ! empty( $pro_feature_performance ) ) {
				if ( ! isset( $data['feature_performance'] ) ) {
					$data['feature_performance'] = array();
				}
				$data['feature_performance'] = array_merge( $data['feature_performance'], $pro_feature_performance );
			}

			// Add connector version
			if ( ! empty( $pro_data['connector_version'] ) ) {
				$data['connector'] = $pro_data['connector_version'];
			}

		return $data;
	}

	/**
	 * Setup data - Collects data and saves to options table
	 * Called by individual tracker schedule
	 *
	 * @return bool True on success, false on failure
	 */
	public function setup_data() {
		// Check if we should collect data
		if ( ! $this->should_collect() ) {
			return false;
		}

		$data = $this->collect();
		if ( ! empty( $data ) ) {
			$option_key = $this->get_option_key();
			update_option( $option_key, array(
				'timestamp' => time(),
				'data'      => $data,
			), false );
			return true;
		}
		return false;
	}

	/**
	 * Return data - Returns saved data from options table
	 * Called by final collector to retrieve saved data
	 *
	 * @return array Saved data or empty array if not found
	 */
	public function return_data() {
		$option_key = $this->get_option_key();
		$saved_data = get_option( $option_key, array() );
		if ( isset( $saved_data['data'] ) && is_array( $saved_data['data'] ) ) {
			return $saved_data['data'];
		}
		return array();
	}

	/**
	 * Get option key - Returns the option key name for this tracker's data
	 *
	 * @return string Option key name
	 */
	public function get_option_key() {
		return 'fk_usage_data_' . $this->plugin_id;
	}
}

// Register collector via filter hook (lazy registration - only when class is loaded)
}

