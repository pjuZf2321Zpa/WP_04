<?php

if ( ! class_exists( 'BWFAN_Contact_Email_Encoded' ) ) {
	#[\AllowDynamicProperties]
	class BWFAN_Contact_Email_Encoded extends BWFAN_Merge_Tag {

		private static $instance = null;

		public function __construct() {
			$this->tag_name        = 'contact_email_encoded';
			$this->tag_description = __( 'Contact Email Encoded', 'wp-marketing-automations' );
			add_shortcode( 'bwfan_contact_email_encoded', array( $this, 'parse_shortcode' ) );
			$this->is_crm_broadcast = true;
		}

		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Parse the merge tag and return its value.
		 *
		 * @param $attr
		 *
		 * @return mixed|string|void
		 */
		public function parse_shortcode( $attr ) {
			$get_data = BWFAN_Merge_Tag_Loader::get_data();
			if ( true === $get_data['is_preview'] ) {
				return $this->parse_shortcode_output( $this->get_dummy_preview(), $attr );
			}
			$email = $this->get_target_email( $get_data );

			return $this->parse_shortcode_output( $this->encode_email( $email ), $attr );
		}

		/**
		 * Extract target email from available data sources
		 *
		 * Validates email format before returning to ensure only valid emails are encoded.
		 *
		 * @param array $get_data Merge tag data array.
		 * @return string Valid email address or empty string.
		 */
		protected function get_target_email( $get_data ) {
			// 1. Check for direct email
			if ( ! empty( $get_data['email'] ) && is_email( $get_data['email'] ) ) {
				return $get_data['email'];
			}

			// 2. Check contact-specific email
			/*
			 * The constant BWFAN_GET_CONTACT_EMAIL is used to control whether the contact-specific email
			 * should be retrieved for the given contact_id. Define BWFAN_GET_CONTACT_EMAIL as true
			 * in contexts where you want to prioritize fetching the contact's email address.
			 * This check ensures that contact email retrieval only occurs when explicitly enabled.
			 */
			if ( isset( $get_data['contact_id'] ) && defined( 'BWFAN_GET_CONTACT_EMAIL' ) && true === BWFAN_GET_CONTACT_EMAIL ) {
				$email = $this->get_email( $get_data['contact_id'] );
				if ( ! empty( $email ) && is_email( $email ) ) {
					return $email;
				}
			}

			// 3. Check cart data
			if ( ! empty( $get_data['cart_details'] ) ) {
				if (
					isset( $get_data['cart_details']['checkout_data'] ) &&
					is_string( $get_data['cart_details']['checkout_data'] ) &&
					trim( $get_data['cart_details']['checkout_data'] ) !== ''
				) {
					$data = json_decode( $get_data['cart_details']['checkout_data'], true );
					if ( json_last_error() === JSON_ERROR_NONE && is_array( $data ) && isset( $data['fields']['billing_email'] ) ) {
						$email = $data['fields']['billing_email'];
						if ( ! empty( $email ) && is_email( $email ) ) {
							return $email;
						}
					}
				}
			}

			// 4. Check order
			$order = $this->get_order_object( $get_data );
			if ( ! empty( $order ) ) {
				$email = BWFAN_Woocommerce_Compatibility::get_order_data( $order, '_billing_email' );
				if ( ! empty( $email ) && is_email( $email ) ) {
					return $email;
				}
			}
			// 5. Check user ID
			if ( ! empty( $get_data['user_id'] ) ) {
				$user = get_user_by( 'ID', absint( $get_data['user_id'] ) );

				if ( $user instanceof WP_User && ! empty( $user->user_email ) && is_email( $user->user_email ) ) {
					return $user->user_email;
				}
			}

			return '';
		}

		/**
		 * Get email from contact ID
		 *
		 * @param int|string $cid Contact ID.
		 * @return string Valid email address or empty string.
		 */
		public function get_email( $cid ) {
			$cid = absint( $cid );
			if ( 0 === $cid ) {
				return '';
			}
			$contact = new WooFunnels_Contact( '', '', '', $cid );
			if ( $contact->get_id() > 0 ) {
				$email = $contact->get_email();
				/** Validate email format before returning */
				return ( ! empty( $email ) && is_email( $email ) ) ? $email : '';
			}

			return '';
		}

		/**
		 * Encode/process email with filterable method
		 *
		 * Validates email format before encoding to prevent encoding invalid data.
		 * Normalizes email to lowercase and trims whitespace before encoding.
		 *
		 * @param string $email Email address to encode.
		 * @return string Encoded email or empty string if invalid.
		 */
		protected function encode_email( $email ) {
			if ( empty( $email ) || ! is_email( $email ) ) {
				return '';
			}
			$normalized = strtolower( trim( $email ) );
			$encoded    = apply_filters( 'bwfan_email_encoded_value', $normalized, $email );

			/** Validate filter return value is a string */
			if ( ! is_string( $encoded ) ) {
				$encoded = $normalized;
			}

			/** If filter changed the value, use it */
			if ( $encoded !== $normalized ) {
				return $encoded;
			}

			/** Default fallback (base64) */
			return base64_encode( $normalized );
		}

		/**
		 * Show dummy value of the current merge tag.
		 *
		 * @return string
		 */
		public function get_dummy_preview() {
			$contact = $this->get_contact_data();
			$email   = get_bloginfo( 'admin_email' );

			/** check for contact instance and id */
			if ( $contact instanceof WooFunnels_Contact && 0 !== absint( $contact->get_id() ) ) {
				$email = $contact->get_email() ?? $email;
			}

			return $this->encode_email( $email );
		}

		/**
		 * @return array[]
		 */
		public function get_setting_schema() {
			return [
				[
					'id'       => 'cu_notice',
					'type'     => 'notice',
					'class'    => '',
					'status'   => 'info',
					'message'  => __( 'The contact email will be encoded using base64 for privacy by default. The encoding method can be customized via the "bwfan_email_encoded_value" filter.', 'wp-marketing-automations' ),
					'dismiss'  => false,
					'required' => false,
					'toggler'  => array(),
				],
			];
		}
	}

	/**
	 * Register this merge tag to a group.
	 */
	BWFAN_Merge_Tag_Loader::register( 'bwf_contact', 'BWFAN_Contact_Email_Encoded', null, __( 'Contact', 'wp-marketing-automations' ) );
}
