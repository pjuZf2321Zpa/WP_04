<?php

#[\AllowDynamicProperties]
class BWFAN_SureForms_Form_Field extends BWFAN_Merge_Tag {

	private static $instance = null;
	protected $support_v2 = true;
	protected $support_v1 = false;

	public function __construct() {
		$this->tag_name        = 'sureforms_form_field';
		$this->tag_description = __( 'Form Field', 'wp-marketing-automations-pro' );
		add_shortcode( 'bwfan_sureforms_form_field', array( $this, 'parse_shortcode' ) );
		add_action( 'wp_ajax_bwfan_get_automation_sureforms_form_fields', array( $this, 'bwfan_get_automation_sureforms_form_fields' ) );
	}

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Parse the merge tag and return its value.
	 *
	 * @param $attr
	 *
	 * @return mixed|string|void
	 */
	public function parse_shortcode( $attr ) {
		if ( true === BWFAN_Merge_Tag_Loader::get_data( 'is_preview' ) ) {
			return $this->get_dummy_preview();
		}

		$entry = BWFAN_Merge_Tag_Loader::get_data( 'fields' );

		$field_value = '';
		if ( isset( $attr['field'] ) && isset( $entry[ $attr['field'] ] ) ) {
			$field_value = $entry[ $attr['field'] ];
		}

		if ( is_array( $field_value ) ) {
			$field_value = implode( ', ', $field_value );
		}

		return $this->parse_shortcode_output( $field_value, $attr );
	}

	/**
	 * Show dummy value of the current merge tag.
	 *
	 * @return string
	 */
	public function get_dummy_preview() {
		return 'Test';
	}

	public function bwfan_get_automation_sureforms_form_fields() {
		BWFAN_PRO_Common::nocache_headers();
		BWFAN_Common::check_nonce();
		$finalarr     = array();
		$automationId = isset( $_POST['automationId'] ) ? absint( $_POST['automationId'] ) : 0; // phpcs:ignore FunnelBuilder.CodeAnalysis.FunnelBuilderSpecific.MissingCapabilityCheck -- BWFAN_Common::check_nonce() enforces access_capabilities().

		/** Check Automation */
		$automation_obj = BWFAN_Automation_V2::get_instance( $automationId );

		/** Check for automation exists */
		if ( empty( $automation_obj->error ) ) {
			$automation_meta = $automation_obj->get_automation_meta_data();

			if ( isset( $automation_meta['event_meta'] ) && isset( $automation_meta['event_meta']['bwfan-sureforms_form_submit_form_id'] ) ) {
				$form_id = sanitize_text_field( $automation_meta['event_meta']['bwfan-sureforms_form_submit_form_id'] );
				$fields  = array();
				if ( ! empty( $form_id ) ) {
					$obj    = BWFAN_SureForms_Form_Submit::get_instance();
					$fields = $obj->get_form_fields( $form_id );
				}

				/** Handling form fields for the v2 automations */
				foreach ( $fields as $key => $value ) {
					$finalarr[] = array(
						'key'   => $key,
						'value' => $value
					);
				}
			}
		}

		wp_send_json( array(
			'results' => $finalarr
		) );
		exit;
	}

	/**
	 * Returns merge tag schema
	 *
	 * @return array[]
	 */
	public function get_setting_schema() {
		return array(
			array(
				'id'          => 'field',
				'type'        => 'ajax',
				'label'       => __( 'Select Field', 'wp-marketing-automations-pro' ),
				"class"       => 'bwfan-input-wrapper',
				"required"    => true,
				'placeholder' => __( 'Select', 'wp-marketing-automations-pro' ),
				"description" => "",
				"ajax_cb"     => 'bwfan_get_automation_sureforms_form_fields',
			)
		);
	}

}

/**
 * Register this merge tag to a group.
 */
if ( bwfan_is_sureforms_active() ) {
	BWFAN_Merge_Tag_Loader::register( 'sureforms', 'BWFAN_SureForms_Form_Field' );
}
