<?php
if ( ! class_exists( 'BWFAN_MEPR_Subscription_ID' ) ) {
	#[\AllowDynamicProperties]
	class BWFAN_MEPR_Subscription_ID extends BWFAN_Merge_Tag {

		private static $instance = null;
		protected $support_v2 = true;
		protected $support_v1 = false;

		public function __construct() {
			$this->tag_name        = 'mepr_subscription_id';
			$this->tag_description = __( 'Subscription ID', 'wp-marketing-automations-pro' );
			add_shortcode( 'bwfan_mepr_subscription_id', array( $this, 'parse_shortcode' ) );
		}

		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Parse the merge tag and return its value.
		 *
		 * @param $attr
		 *
		 * @return mixed|string|void
		 */
		public function parse_shortcode( $attr ) {
			$get_data = BWFAN_Merge_Tag_Loader::get_data();

			if ( true === $get_data['is_preview'] ) {
				return $this->parse_shortcode_output( $this->get_dummy_preview(), $attr );
			}

			// Get subscription_id from event data (optimized - no database queries)
			$subscription_id = isset( $get_data['subscription_id'] ) ? absint( $get_data['subscription_id'] ) : 0;

			return $this->parse_shortcode_output( $subscription_id, $attr );
		}

		/**
		 * Show dummy value of the current merge tag.
		 *
		 * @return string
		 *
		 */
		public function get_dummy_preview() {
			return '123';
		}


	}

	/**
	 * Register this merge tag to a group.
	 */
	if ( function_exists( 'bwfan_is_mepr_active' ) && bwfan_is_mepr_active() ) {
		BWFAN_Merge_Tag_Loader::register( 'bwfan_mepr_subscription_product', 'BWFAN_MEPR_Subscription_ID', '', 'MemberPress' );
	}
}

