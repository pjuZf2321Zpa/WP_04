<?php

#[\AllowDynamicProperties]
class BWFAN_SureForms_Entry_ID extends BWFAN_Merge_Tag {

	private static $instance = null;
	protected $support_v2 = true;
	protected $support_v1 = false;

	public function __construct() {
		$this->tag_name        = 'sureforms_entry_id';
		$this->tag_description = __( 'Entry ID', 'wp-marketing-automations-pro' );
		add_shortcode( 'bwfan_sureforms_entry_id', array( $this, 'parse_shortcode' ) );
	}

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Parse the merge tag and return its value.
	 *
	 * @param $attr
	 *
	 * @return mixed|string|void
	 */
	public function parse_shortcode( $attr ) {
		if ( true === BWFAN_Merge_Tag_Loader::get_data( 'is_preview' ) ) {
			return $this->get_dummy_preview();
		}

		$entry_id = BWFAN_Merge_Tag_Loader::get_data( 'entry_id' );
		if ( empty( $entry_id ) ) {
			return $this->parse_shortcode_output( '', $attr );
		}

		return $this->parse_shortcode_output( $entry_id, $attr );
	}

	/**
	 * Show dummy value of the current merge tag.
	 *
	 * @return string
	 */
	public function get_dummy_preview() {
		return '11';
	}
}

/**
 * Register this merge tag to a group.
 */
if ( bwfan_is_sureforms_active() ) {
	BWFAN_Merge_Tag_Loader::register( 'sureforms', 'BWFAN_SureForms_Entry_ID', null, __( 'SureForms', 'wp-marketing-automations-pro' ) );
}
