<?php
if ( ! class_exists( 'BWFAN_MEPR_Member_Name' ) ) {
	#[\AllowDynamicProperties]
	class BWFAN_MEPR_Member_Name extends BWFAN_Merge_Tag {

		private static $instance = null;
		protected $support_v2 = true;
		protected $support_v1 = false;

		public function __construct() {
			$this->tag_name        = 'mepr_member_name';
			$this->tag_description = __( 'Member Name', 'wp-marketing-automations-pro' );
			add_shortcode( 'bwfan_mepr_member_name', array( $this, 'parse_shortcode' ) );
		}

		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Parse the merge tag and return its value.
		 *
		 * @param $attr
		 *
		 * @return mixed|string|void
		 */
		public function parse_shortcode( $attr ) {
			$get_data = BWFAN_Merge_Tag_Loader::get_data();

			if ( true === $get_data['is_preview'] ) {
				return $this->parse_shortcode_output( $this->get_dummy_preview(), $attr );
			}

			$email   = $get_data['email'];
			$user_id = $get_data['user_id'];

			$user = ( ! empty( $email ) && is_email( $email ) ) ? get_user_by( 'email', $email ) : get_user_by( 'ID', $user_id );
			if ( ! $user instanceof WP_User ) {
				return '';
			}
			$member_name = ( ! empty( $user->first_name ) || ! empty( $user->last_name ) ) ? "$user->first_name $user->last_name" : $user->display_name;

			return $this->parse_shortcode_output( $member_name, $attr );
		}

		/**
		 * Show dummy value of the current merge tag.
		 *
		 * @return string
		 *
		 */
		public function get_dummy_preview() {
			return 'Dummy: Member Name';
		}


	}

	/**
	 * Register this merge tag to a group.
	 */
	if ( function_exists( 'bwfan_is_mepr_active' ) && bwfan_is_mepr_active() ) {
		BWFAN_Merge_Tag_Loader::register( 'mepr_user', 'BWFAN_MEPR_Member_Name', '', 'MemberPress' );
	}
}