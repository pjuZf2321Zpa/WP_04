<?php

#[\AllowDynamicProperties]
class BWFAN_SureForms_Entry_URL extends BWFAN_Merge_Tag {

	private static $instance = null;
	protected $support_v2 = true;
	protected $support_v1 = false;

	public function __construct() {
		$this->tag_name        = 'sureforms_entry_url';
		$this->tag_description = __( 'Entry URL', 'wp-marketing-automations-pro' );
		add_shortcode( 'bwfan_sureforms_entry_url', array( $this, 'parse_shortcode' ) );
	}

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Parse the merge tag and return its value.
	 *
	 * @param $attr
	 *
	 * @return mixed|string|void
	 */
	public function parse_shortcode( $attr ) {
		if ( true === BWFAN_Merge_Tag_Loader::get_data( 'is_preview' ) ) {
			return $this->get_dummy_preview();
		}

		$entry_url = BWFAN_Merge_Tag_Loader::get_data( 'entry_url' );
		if ( empty( $entry_url ) ) {
			return $this->parse_shortcode_output( '', $attr );
		}

		return $this->parse_shortcode_output( $entry_url, $attr );
	}

	/**
	 * Show dummy value of the current merge tag.
	 *
	 * @return string
	 */
	public function get_dummy_preview() {
		return admin_url( 'admin.php?page=sureforms_entries' );
	}
}

/**
 * Register this merge tag to a group.
 */
if ( bwfan_is_sureforms_active() ) {
	BWFAN_Merge_Tag_Loader::register( 'sureforms', 'BWFAN_SureForms_Entry_URL', null, __( 'SureForms', 'wp-marketing-automations-pro' ) );
}
