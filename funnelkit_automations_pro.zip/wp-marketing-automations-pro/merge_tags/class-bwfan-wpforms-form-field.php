<?php

#[\AllowDynamicProperties]
class BWFAN_WPFORMS_Form_Field extends BWFAN_Merge_Tag {

	private static $instance = null;

	public function __construct() {
		$this->tag_name        = 'wpforms_form_field';
		$this->tag_description = __( 'Form Field', 'wp-marketing-automations-pro' );
		add_shortcode( 'bwfan_wpforms_form_field', array( $this, 'parse_shortcode' ) );
		add_action( 'wp_ajax_bwfan_get_automation_wpform_form_fields', array( $this, 'bwfan_get_automation_wpform_form_fields' ) );
	}

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Show the html in popup for the merge tag.
	 */
	public function get_view() {
		$this->get_back_button();
		?>
        <label for="" class="bwfan-label-title"><?php echo esc_html__( 'Select Field', 'wp-marketing-automations-pro' ); ?></label>
        <select id="" class="bwfan-input-wrapper bwfan-mb-15 bwfan_tag_select bwfan_wpforms_form_fields" style="padding-left:10px;" name="field"></select>
		<?php
		if ( $this->support_fallback ) {
			$this->get_fallback();
		}

		$this->get_preview();
		$this->get_copy_button();
	}

	/**
	 * Parse the merge tag and return its value.
	 *
	 * @param $attr
	 *
	 * @return mixed|string|void
	 */
	public function parse_shortcode( $attr ) {
		if ( true === BWFAN_Merge_Tag_Loader::get_data( 'is_preview' ) ) {
			return $this->get_dummy_preview();
		}
		$entry = BWFAN_Merge_Tag_Loader::get_data( 'entry' );
		if ( ! isset( $attr['field'] ) || ! isset( $entry['fields'][ $attr['field'] ] ) ) {
			return $this->parse_shortcode_output( '', $attr );
		}
        $format_type = isset( $attr['type'] ) ? $attr['type'] : 'text';
        $field_value     = $entry['fields'][ $attr['field'] ];
        if ( is_array( $field_value ) && 'date' !== $format_type ) {
            $field_value = isset( $field_value['first'] ) ? implode( ' ', $field_value ) : ( isset( $field_value['primary'] ) ? $field_value['primary'] : implode( ', ', $field_value ) );
        }
        if ( is_array( $field_value ) && 'date' === $format_type ) {
            $field_value = $this->process_field_value( $field_value, $attr );
        }


        return $this->parse_shortcode_output( $field_value, $attr );
	}

    /**
     * Process field value based on field type and attributes
     *
     * @param mixed $field_value
     * @param array $attr
     *
     * @return mixed|string
     */
    public function process_field_value( $field_value, $attr ) {
        /** Handle date fields */
        if ( isset( $attr['type'] ) && 'date' === $attr['type'] ) {
            return $this->get_date_value( $field_value, $attr );
        }
        return $field_value;
    }

    public function get_date_value( $value, $attr ) {
        if ( ! is_array( $attr ) || ! isset( $attr['type'] ) || 'date' !== $attr['type'] || ! isset( $attr['format'] ) || empty( $attr['format'] ) ) {
            return $value;
        }

        if ( ! is_array( $value ) || ! isset( $value['date'] ) ) {
            return $value;
        }

        /** Handle dropdown date format (m, d, y in array) */
        if ( is_array( $value['date'] ) ) {
            $date_data = $value['date'];
            // Default to 1 for month and day if missing (i.e., January 1st), and current year if year is missing.
            // This ensures a valid date is constructed even if some components are not provided.
            $month = isset( $date_data['m'] ) ? absint( $date_data['m'] ) : 1;
            $day   = isset( $date_data['d'] ) ? absint( $date_data['d'] ) : 1;
            $year  = isset( $date_data['y'] ) ? absint( $date_data['y'] ) : absint( wp_date( 'Y' ) );

            /** Validate date components */
            $month = max( 1, min( 12, $month ) );
            $day   = max( 1, min( 31, $day ) );
            $year  = max( 1970, min( 9999, $year ) );

            /** Validate day is valid for the month */
            $days_in_month = cal_days_in_month( CAL_GREGORIAN, $month, $year );
            $day           = min( $day, $days_in_month );

            $date_string = sprintf( '%04d-%02d-%02d', $year, $month, $day );
            $date_parameters = $attr;
            $date_parameters['input_format'] = 'Y-m-d';

            return $this->format_datetime( $date_string, $date_parameters );
        }
        if ( is_string( $value['date'] ) ) {
            $date_string = $value['date'];

            return $this->format_datetime( $date_string, $attr );
        }

        return $value;
    }

	public function bwfan_get_automation_wpform_form_fields() {
		BWFAN_PRO_Common::nocache_headers();
		BWFAN_Common::check_nonce();

		/** Check user capabilities */
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json( array(
				'results' => [],
				'error'   => __( 'Insufficient permissions.', 'wp-marketing-automations-pro' ),
			) );
			exit;
		}

		$final_arr    = [];
		$automationId = isset( $_POST['automationId'] ) ? absint( sanitize_text_field( wp_unslash( $_POST['automationId'] ) ) ) : 0;

		/** Check Automation */
		$automation_obj = BWFAN_Automation_V2::get_instance( $automationId );

		/** Check for automation exists */
		if ( empty( $automation_obj->error ) ) {
			$automation_meta = $automation_obj->get_automation_meta_data();

			if ( isset( $automation_meta['event_meta'] ) && isset( $automation_meta['event_meta']['bwfan-wpforms_form_submit_form_id'] ) ) {
				$form_id = sanitize_text_field( $automation_meta['event_meta']['bwfan-wpforms_form_submit_form_id'] );
				$fields  = [];
				if ( ! empty( $form_id ) ) {
					$obj    = BWFAN_WPFORMS_Form_Submit::get_instance();
					$fields = $obj->get_form_fields( $form_id );
				}

				/** Handling form fields for the v2 automations */
				foreach ( $fields as $key => $value ) {
					$final_arr[] = [
						'key'   => $key,
						'value' => $value
					];
				}
			}
		}

		wp_send_json( array(
			'results' => $final_arr
		) );
		exit;
	}

	/**
	 * Returns merge tag schema
	 *
	 * @return array[]
	 */
	public function get_setting_schema() {
        $formats      = $this->date_formats;
        $date_formats = [];
        foreach ( $formats as $data ) {
            if ( isset( $data['format'] ) ) {
                $date_time = wp_date( $data['format'] );
                $date_formats[] = [
                    'value' => $data['format'],
                    'label' => $date_time,
                ];
            }
        }
		return [
			[
				'id'          => 'field',
				'type'        => 'ajax',
				'label'       => __( 'Select Field', 'wp-marketing-automations-pro' ),
				"class"       => 'bwfan-input-wrapper',
				"required"    => true,
				'placeholder' => __( 'Select', 'wp-marketing-automations-pro' ),
				"description" => "",
				"ajax_cb"     => 'bwfan_get_automation_wpform_form_fields',
            ],
            [
                'id'          => 'type',
                'type'        => 'select',
                'options'     => [
                    [
                        'value' => '',
                        'label' => __( 'Text', 'wp-marketing-automations' ),
                    ],
                    [
                        'value' => 'date',
                        'label' => __( 'Date', 'wp-marketing-automations' ),
                    ]
                ],
                'label'       => __( 'Meta Field Type', 'wp-marketing-automations' ),
                "class"       => 'bwfan-input-wrapper',
                "required"    => false,
                'placeholder' => 'Select',
            ],
            [
                'id'          => 'format',
                'type'        => 'select',
                'options'     => $date_formats,
                'label'       => __( 'Output Format', 'wp-marketing-automations' ),
                "class"       => 'bwfan-input-wrapper',
                "placeholder" => 'Select',
                "required"    => false,
                'hint'        => __( 'Desired date output format', 'wp-marketing-automations' ),
                'toggler'     => array(
                    'fields'   => array(
                        array(
                            'id'    => 'type',
                            'value' => 'date',
                        ),
                    ),
                    'relation' => 'AND',
                )
            ]
		];
	}

	/**
	 * Show dummy value of the current merge tag.
	 *
	 * @return string
	 */
	public function get_dummy_preview() {
		return 'Test';
	}
}

/**
 * Register this merge tag to a group.
 */
if ( bwfan_is_wpforms_active() ) {
	BWFAN_Merge_Tag_Loader::register( 'wpforms', 'BWFAN_WPFORMS_Form_Field' );
}
