<?php

class BWFCRM_Broadcast_Helper {

	public static $CONTACT_BATCH_COUNT = 75;

	public static $CAMPAIGN_DRAFT = 1;
	public static $CAMPAIGN_SCHEDULED = 2;
	public static $CAMPAIGN_RUNNING = 3;
	public static $CAMPAIGN_COMPLETED = 4;
	public static $CAMPAIGN_HALT = 5;
	public static $CAMPAIGN_PAUSED = 6;

	public static $CAMPAIGN_EMAIL = 1;
	public static $CAMPAIGN_SMS = 2;
	public static $CAMPAIGN_WHATSAPP = 3;

	public static $logs = [];
	public static $engagement_creating = false;

	/**
	 * Whether the last audience fetch looks like a query that failed rather than a walk that ended
	 *
	 * An exhausted walk and a failed page query both come back as an empty contact list, and the
	 * caller acts on that emptiness irreversibly - it writes engagements_created, after which the
	 * dispatcher never routes back into creation.
	 *
	 * This does NOT read $wpdb->last_error. get_contacts() ends by running its own COUNT, and
	 * wpdb::flush() clears last_error at the start of every query, so by the time the caller looks
	 * the error belongs to the count, not to the page query that actually failed. What survives is
	 * the disagreement between the two: a total above zero with no rows to show for it.
	 */
	public static $last_contact_query_failed = false;

	/** Resolved once per request, null until then */
	private static $logging_enabled = null;

	/**
	 * Check if the broadcast is a v2 broadcast
	 *
	 * @param array $broadcast Broadcast data.
	 *
	 * @return bool True if it is a v2 broadcast, false otherwise.
	 */
	public static function is_v2_broadcast( $broadcast = [] ) {
		if ( ! is_array( $broadcast ) || empty( $broadcast ) ) {
			return false;
		}

		/** The v2 flow only sends email, so SMS and WhatsApp always fall back to v1 */
		if ( isset( $broadcast['type'] ) && self::$CAMPAIGN_EMAIL !== absint( $broadcast['type'] ) ) {
			return false;
		}

		$data = ! empty( $broadcast['data'] ) ? $broadcast['data'] : false;
		if ( ! is_array( $data ) && ! empty( $data ) ) {
			$data = json_decode( $data, true );
		}

		if ( ! empty( $data['v2'] ) ) {
			/** If v2 is set, then it is a v2 broadcast */
			return true;
		}

		return false;
	}

	public static function fetch_contacts_for_broadcast( $broadcast, $object ) {
		/**
		 * Totals left on - the parameter defaults to true - because the failure check below is
		 * built on them. The explicit `false` that used to sit here made that check dead: without
		 * the flag get_contacts() does not return `total_count` at all, so the check read a key
		 * that was never there and could never fire.
		 *
		 * Turning it on costs no query. BWFCRM_Contact::get_contacts() resolves to
		 * BWFAN_Model_Contact::get_contacts_from_filters(), which runs its count unconditionally
		 * in the return statement; all `grab_totals` decides is whether that figure is passed
		 * back out.
		 */
		$args = self::get_broadcast_query_args( $broadcast );

		self::$last_contact_query_failed = false;

		if ( ! empty( $object->offset ) ) {
			$args['props']['end_id']         = absint( $object->offset );
			$args['props']['exclude_end_id'] = true;
		}

		/** Get Contacts */
		$parentBroadcast = isset( $broadcast['parent'] ) ? absint( $broadcast['parent'] ) : false;
		if ( ! empty( $parentBroadcast ) ) {
			$args['props']['limit']       = self::$CONTACT_BATCH_COUNT;
			$args['props']['offset']      = 0;
			$args['props']['grab_totals'] = true;
			/** exclude_unsubs and the two include_* flags already ride in props - see get_broadcast_query_args() */
			$contacts_array = BWFCRM_Core()->campaigns->get_unopen_broadcast_contacts( absint( $parentBroadcast ), $args['props'], OBJECT );
		} else {
			if ( ! isset( $args['props']['exclude_unsubs'] ) || false === $args['props']['exclude_unsubs'] ) {
				$args['props']['exclude_unsubs'] = apply_filters( 'bwfan_force_exclude_unsubscribe_contact', false );
			}
			$contacts_array = BWFCRM_Contact::get_contacts( '', 0, self::$CONTACT_BATCH_COUNT, $args['filters'], $args['props'], OBJECT );
		}

		/**
		 * The count and the page disagreeing is the signal.
		 *
		 * get_contacts() returns both, built from the same WHERE clause and therefore the same id
		 * bound - see get_prepared_query(), where `base` and `total` share $final_where_query - so
		 * on a healthy call an empty page means a zero total. A page query rolled back by a
		 * deadlock or a lock wait returns no rows while the count that follows it still reports
		 * the audience, and that is the case the caller must not read as "the walk is finished".
		 *
		 * The key is `total_count`, not `total`: `total` is what the model hands to
		 * BWFCRM_Contact::get_contacts(), which republishes it under the other name.
		 */
		$reported_total = is_array( $contacts_array ) && isset( $contacts_array['total_count'] ) ? absint( $contacts_array['total_count'] ) : 0;
		$returned_rows  = is_array( $contacts_array ) && isset( $contacts_array['contacts'] ) && is_array( $contacts_array['contacts'] ) ? count( $contacts_array['contacts'] ) : 0;

		self::$last_contact_query_failed = ( 0 === $returned_rows && $reported_total > 0 );

		if ( ! is_array( $contacts_array ) || ! isset( $contacts_array['contacts'] ) || ! is_array( $contacts_array['contacts'] ) ) {
			$contact_ids = BWFCRM_Common::crm_error( __( 'Invalid broadcast contact query results', 'wp-marketing-automations-pro' ) );
			self::set_log( 'broadcast_id' . $broadcast['id'] . '_no_query_result' );

			return $contact_ids;
		}

		/** Get IDs From Contacts */
		$contact_ids = array_map( function ( $contact ) {
			return $contact->get_id();
		}, $contacts_array['contacts'] );

		/** Adding failsafe to avoid multiple broadcast processing on the same contact */
		/** getting contacts ids in desc order */
		arsort( $contact_ids );
		/** First id to process is */
		$first_id = current( $contact_ids );

		if ( ! empty( $object->offset ) && $first_id >= $object->offset ) {
			/** If first contact already processed, empty the contact array */
			self::set_log( 'broadcast_id' . $broadcast['id'] . ' has data but contact already processed' );

			$object->stop_broadcast_required = true;

			return $contact_ids;
		}

		self::set_log( 'broadcast_id' . $broadcast['id'] . ' - IDs: ' . implode( ',', $contact_ids ) );

		return $contact_ids;
	}

	public static function get_broadcast_query_args( $broadcast, $grab_total = true ) {
		if ( ! is_array( $broadcast ) || empty( $broadcast ) ) {
			return false;
		}

		$data = isset( $broadcast['data'] ) && ! empty( $broadcast['data'] ) ? $broadcast['data'] : false;
		if ( ! is_array( $data ) && ! empty( $data ) ) {
			$data = json_decode( $data, true );
		}

		$exclude = ! empty( $data ) && isset( $data['exclude'] ) && is_array( $data['exclude'] ) ? $data['exclude'] : array();
		$exclude = array_map( 'absint', $exclude );

		$parentBroadcast = isset( $broadcast['parent'] ) ? absint( $broadcast['parent'] ) : false;
		if ( ! empty( $parentBroadcast ) ) {
			return array(
				'filters' => array(),
				'data'    => $data,
				'props'   => array(
					'order'       => 'DESC',
					'exclude_ids' => $exclude,
					'fetch_base'  => 1,
					/**
					 * The resend's own audience settings, not the parent's.
					 *
					 * get_unopen_broadcast_contacts() is handed the parent id, so without these
					 * it answers from the parent's blob while get_unsendable_reason() answers
					 * from this one - the query and the send gate then disagree about the same
					 * contact. These three are the whole of that disagreement.
					 */
					'exclude_unsubs'      => ! empty( $data['is_promotional'] ),
					'include_soft_bounce' => ! empty( $data['includeSoftBounce'] ),
					'include_unverified'  => ! empty( $data['includeUnverified'] ),
				),
			);
		}

		$filters = ! empty( $data ) && isset( $data['filters'] ) ? $data['filters'] : array();

		/** BC: for lite < 3.8.0, we need to set status_is to 1 to filter unsubscribed contacts in broadcast queries. */
		if ( defined( 'BWFAN_VERSION' ) && version_compare( BWFAN_VERSION, '3.8.0', '<' ) ) {
			$filters['status_is'] = 1;
		}

		$mode = isset( $broadcast['type'] ) ? absint( $broadcast['type'] ) : 1;

		/** Fetch Base must SMS (Phone Number), if mode is WhatsApp */
		$mode = self::$CAMPAIGN_WHATSAPP === $mode ? self::$CAMPAIGN_SMS : $mode;

		return array(
			'filters' => $filters,
			'data'    => $data,
			'props'   => array(
				'fetch_base'           => $mode,
				'order_by'             => 'id',
				'order'                => 'DESC',
				'grab_totals'          => $grab_total,
				'exclude_unsubs_lists' => isset( $filters['lists_any'] ),
				'exclude_ids'          => $exclude,
				/**
				 * Honours includeSoftBounce, and every other place that decides on a soft bounce
				 * has to honour it too or the setting means something different at each of them:
				 * get_unsendable_reason() below, the on-screen figure in
				 * BWFCRM_Campaigns::get_broadcast_updated_contact_count(), the resend walk in
				 * BWFCRM_Campaigns::get_unopen_broadcast_contacts(), and the audience_keys list
				 * in BWFAN_Model_Broadcast::update_campaign() that decides whether toggling it
				 * invalidates a prepared run. Hardcode any one of them and the count reports an
				 * audience creation will not build, or the send gate refuses a contact the query
				 * put there.
				 */
				'include_soft_bounce'  => ! empty( $data['includeSoftBounce'] ),
				'include_unverified'   => ! empty( $data['includeUnverified'] ),
				'include_unsubscribe'  => empty( $data['is_promotional'] ),
				'is_broadcast'         => true,
			),
		);
	}


	public static function error_while_fetching_contacts( $contact_ids, $broadcast_id, $broadcast_data ) {
		if ( ! $contact_ids instanceof WP_Error ) {
			return false;
		}

		/** Written onto the data that is actually persisted, otherwise the halt has no reason against it */
		$data                = is_array( $broadcast_data ) ? $broadcast_data : array();
		$data['halt_reason'] = $contact_ids->get_error_message();

		BWFAN_Model_Broadcast::update_status_to_halt( $broadcast_id, $data );
		BWFCRM_Broadcast_Processing::action_schedule_save_last_sent( $broadcast_id );

		return true;
	}

	/**
	 * Check if Smart Sending is enabled for the broadcast
	 *
	 * @param array $broadcast_data Broadcast data.
	 *
	 * @return bool True if smart sending is enabled, false otherwise.
	 */
	public static function check_if_smart_send_enabled( $broadcast_data ) {
		if ( empty( $broadcast_data ) || ! is_array( $broadcast_data ) ) {
			return false;
		}

		/** Return false if smart sending is not enabled */
		$smart_send_settings = $broadcast_data['smart_send'] ?? false;
		if ( is_array( $smart_send_settings ) && isset( $smart_send_settings['enable'] ) && true == $smart_send_settings['enable'] ) {
			return true;
		}

		return false;
	}

	public static function maybe_process_smart_send_v2( $broadcast, $processed, $count, $mode = 1 ) {
		$broadcast_data = $broadcast['data'];

		/** Return false if smart sending is not enabled */
		if ( ! self::check_if_smart_send_enabled( $broadcast_data ) ) {
			return false;
		}

		/** Return winner if already declared */
		$winner = isset( $broadcast_data['winner'] ) && ! empty( $broadcast_data['winner'] ) ? intval( $broadcast_data['winner'] ) : false;
		if ( ! empty( $winner ) ) {
			BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $broadcast['id'] . ' maybe_process_smart_send_v2 winner found: ' . $winner );

			return $winner;
		}

		/**
		 * Smart sending already ran and closed without a winner, so the rest of the broadcast
		 * goes out as it is. Without this the percentage below is still satisfied and the
		 * broadcast holds again on the very next contact, over and over, never sending.
		 */
		if ( ! empty( $broadcast_data['smart_sending_done'] ) ) {
			return false;
		}

		/** Smart send settings */
		$smart_send_settings = $broadcast_data['smart_send'];

		/** Return false if percent is not achieved yet */
		$processed = ! empty( $processed ) ? intval( $processed ) : 0;
		$percent   = ! empty( $smart_send_settings['percent'] ) ? intval( $smart_send_settings['percent'] ) : 0;
		$count     = intval( $count );
		if ( empty( $percent ) || empty( $count ) ) {
			return false;
		}

		$percent_achieved = ( $processed / $count ) * 100;
		if ( $percent_achieved < $percent ) {
			return false;
		}

		$broadcast_id = $broadcast['id'];

		/** Return 'hold' if percent is achieved and need to wait for the most opens or clicked template */
		if ( ! isset( $broadcast_data['hold_broadcast'] ) ) {
			/**
			 * Creating engagements only decides the test batch is now big enough - it holds
			 * nothing, because those engagements still have to be sent. The flag is set once
			 * they have been, by maybe_start_smart_send_window(), so hold_broadcast means one
			 * thing throughout: the partial send is done and its window is running.
			 */
			if ( true === self::$engagement_creating ) {
				return 'hold';
			}

			$hours = isset( $smart_send_settings['hours'] ) ? intval( $smart_send_settings['hours'] ) : 0;
			BWFAN_Model_Broadcast::hold_broadcast_for_smart_send( $broadcast_id, $hours );

			return 'hold';
		}

		/** Return false, if unable to get the Winner */
		$db_winner = BWFAN_Model_Broadcast::get_broadcast_tids_stats( intval( $broadcast_id ), intval( $mode ) );
		if ( ! is_array( $db_winner ) || empty( $db_winner['winner'] ) ) {
			/**
			 * Closed without a winner, so mark smart sending done along with dropping the hold.
			 * The percentage is still satisfied on the next contact, and only this flag stops the
			 * check above from holding the broadcast again on it - see the guard at the top.
			 */
			BWFAN_Model_Broadcast::remove_hold_flag_smart_sending( absint( $broadcast_id ) );
			BWFAN_Model_Broadcast::update_broadcast_data( absint( $broadcast_id ), [ 'smart_sending_done' => 1 ] );

			return false;
		}

		/** Return & declare winner */
		BWFAN_Model_Broadcast::declare_the_winner_email( intval( $broadcast_id ), $db_winner );

		return intval( $db_winner['winner'] );
	}


	/**
	 * Park a broadcast for the length of its smart send window
	 *
	 * execution_time *is* the window: the dispatcher will not enter the send loop until it has
	 * passed, and the hold flag travels in the same statement, so the two cannot disagree. A
	 * second deadline was previously stamped into the data blob as well - see the note in
	 * BWFCRM_Broadcast_V2_Email_Controller::resolve_smart_send_hold() for why one is enough.
	 *
	 * set_delay() only ever moves execution_time later, so a broadcast already parked further out
	 * - by the daily send cap, say - keeps the later time and simply waits a little longer.
	 *
	 * @param int $broadcast_id
	 * @param array $data Broadcast data, read only for its smart_send settings
	 *
	 * @return bool
	 */
	public static function update_broadcast_e_time( $broadcast_id, $data ) {
		$smart_send_settings = $data['smart_send'] ?? false;
		if ( empty( $smart_send_settings ) ) {
			return false;
		}
		$hours = isset( $smart_send_settings['hours'] ) ? intval( $smart_send_settings['hours'] ) : 0;

		/**
		 * Only the window length comes from the caller. The blob written alongside it is read
		 * fresh inside hold_broadcast_for_smart_send() - see the note there - so counters the run
		 * wrote after it took its copy of $data survive being parked.
		 */
		return BWFAN_Model_Broadcast::hold_broadcast_for_smart_send( $broadcast_id, $hours );
	}

	/**
	 * Whether broadcast logging is turned on for this site
	 *
	 * Same gate the v1 buffer uses in BWFCRM_Broadcast_Processing::log(), read here as well so
	 * a site that never asked for these logs neither writes them nor pays to collect them - this
	 * buffer takes several entries per contact, so on a large broadcast the array itself is the
	 * cost, not just the file.
	 *
	 * @return bool
	 */
	public static function is_logging_enabled() {
		if ( null === self::$logging_enabled ) {
			self::$logging_enabled = ( false !== apply_filters( 'bwfan_allow_broadcast_logging', BWFAN_PRO_Common::is_log_enabled( 'bwfan_broadcast_logging' ) ) );
		}

		return self::$logging_enabled;
	}

	public static function set_log( $log ) {
		if ( empty( $log ) || ! self::is_logging_enabled() ) {
			return;
		}
		self::$logs[] = array(
			't' => microtime( true ),
			'm' => $log,
		);
	}

	public static function log() {
		if ( ! is_array( self::$logs ) || 0 === count( self::$logs ) ) {
			return;
		}

		if ( ! self::is_logging_enabled() ) {
			self::$logs = [];

			return;
		}

		add_filter( 'bwfan_before_making_logs', '__return_true' );
		BWFAN_Core()->logger->log( wp_json_encode( self::$logs, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR ), 'fka-broadcast-v2' );
		self::$logs = [];
	}

	/**
	 * What the contacts of a claimed batch look like right now
	 *
	 * v2 creates the engagements well before it sends them - an hour ahead for a scheduled
	 * broadcast, and longer than that for one whose creation phase spans several runs - so the
	 * audience query that picked these contacts is long out of date by the time the mail goes
	 * out. A contact can unsubscribe, hard bounce or be deleted in between, and the claim query
	 * knows nothing about any of that. This reads the state the send has to check against, in
	 * one query per batch alongside the uid the mail already needed.
	 *
	 * The unsubscribe record lives in its own table keyed on the recipient address rather than
	 * on the contact, which is why it is looked up by email and phone the way the contact query
	 * does it. The phone side is guarded against the empty string, or every contact without a
	 * number would match an unsubscribe row that has none either.
	 *
	 * @param array $engagements Engagement rows of the current batch
	 *
	 * @return array|false Map of contact id => [ uid, status, email, unsubscribed ], missing
	 *                     contacts absent; false when the query itself failed
	 */
	public static function get_contact_send_states( $engagements = [] ) {
		if ( ! is_array( $engagements ) || empty( $engagements ) ) {
			return [];
		}

		// filter out cids column form the engagement array
		$cids = array_map( function ( $engagement ) {
			return $engagement['cid'] ?? false;
		}, $engagements );
		$cids = array_filter( array_map( 'intval', $cids ) );

		if ( empty( $cids ) ) {
			return [];
		}

		global $wpdb;

		$unsubscribe_table = $wpdb->prefix . 'bwfan_message_unsubscribe';
		$placeholders      = implode( ',', array_fill( 0, count( $cids ), '%d' ) );
		$query             = $wpdb->prepare(
			"SELECT c.id, c.uid, c.status, c.email,
				( EXISTS ( SELECT 1 FROM {$unsubscribe_table} AS unsub WHERE unsub.recipient = c.email )
				  OR EXISTS ( SELECT 1 FROM {$unsubscribe_table} AS unsub_p WHERE c.contact_no <> '' AND unsub_p.recipient = c.contact_no ) ) AS unsubscribed
			FROM {$wpdb->prefix}bwf_contact AS c WHERE c.id IN ( $placeholders )",
			$cids
		);

		$results = $wpdb->get_results( $query, ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL

		/**
		 * A failed query is not an empty result, and the caller cannot treat it as one.
		 *
		 * This joins bwf_contact to two correlated EXISTS over the unsubscribe table, once per
		 * claimed batch, so a deadlock or a lock wait timeout on it is an ordinary event under
		 * load. An empty map reads to get_unsendable_reason() as "contact no longer exists", and
		 * every engagement of the batch is then written c_status = ERROR - a status the send loop
		 * never re-claims. That silently and permanently drops a whole batch of recipients.
		 */
		if ( ! empty( $wpdb->last_error ) ) {
			self::set_log( 'contact send state query failed: ' . $wpdb->last_error );

			return false;
		}

		if ( empty( $results ) || ! is_array( $results ) ) {
			return [];
		}

		$mapped_data = [];
		foreach ( $results as $result ) {
			$mapped_data[ absint( $result['id'] ) ] = array(
				'uid'          => $result['uid'],
				'status'       => absint( $result['status'] ),
				'email'        => $result['email'],
				'unsubscribed' => ! empty( $result['unsubscribed'] ),
			);
		}

		return $mapped_data;
	}

	/**
	 * Why this contact must not be mailed, if it must not
	 *
	 * Mirrors what the audience query would do with the contact today, using the same broadcast
	 * settings it was built from: a promotional broadcast excludes unsubscribers, soft bounced
	 * and unverified contacts are in only when the broadcast opted into them, and hard bounces
	 * and complaints are never mailed.
	 *
	 * What this cannot re-check is the audience itself - the broadcast's tag, list and segment
	 * filters, its exclude list and exclude_unsubs_lists are not re-run per recipient. A contact
	 * that has since left the segment is still mailed.
	 *
	 * @param array $state Contact state from get_contact_send_states(), empty when the contact is gone
	 * @param array $data Broadcast data blob
	 *
	 * @return string Reason to record against the engagement, empty string when the contact is still fine to mail
	 */
	public static function get_unsendable_reason( $state, $data = [] ) {
		if ( ! is_array( $state ) || empty( $state ) ) {
			return __( 'Contact no longer exists', 'wp-marketing-automations-pro' );
		}

		$data   = is_array( $data ) ? $data : array();
		$status = absint( $state['status'] );

		/** The audience is built on addresses, so a contact whose email has since gone has nowhere to be written to */
		if ( empty( $state['email'] ) ) {
			return __( 'Contact no longer has an email address', 'wp-marketing-automations-pro' );
		}

		/**
		 * Mirrors the shape of the audience query rather than re-deriving it.
		 *
		 * That query reads `( c.status = 1 [ OR c.status = 4 ] [ OR c.status = 0 ] [ OR unsubscribed ] )`
		 * with each branch added by the matching broadcast setting, and separately drops every
		 * unsubscriber when the broadcast is promotional. The unsubscribe branch is an OR, not a
		 * veto: a transactional broadcast reaches an unsubscribed contact whatever its status,
		 * which is the whole point of sending one. Treating it as an exclusion instead - as the
		 * first cut of this method did - would silently drop those contacts from a broadcast that
		 * was addressed to them.
		 */
		$includes_unsubscribers = empty( $data['is_promotional'] );

		if ( ! empty( $state['unsubscribed'] ) && ! $includes_unsubscribers ) {
			return __( 'Contact unsubscribed after this broadcast was prepared', 'wp-marketing-automations-pro' );
		}

		/**
		 * Soft bounces follow includeSoftBounce, the same key the audience queries read - the
		 * `OR c.status=4` branch on the resend path and include_soft_bounce on the main one.
		 * Gating the send on a different answer than the query gives builds the engagement and
		 * then refuses to mail it, writing c_status = ERROR against a contact the audience
		 * deliberately included.
		 */
		$qualifies = ( BWFCRM_Contact::$STATUS_OPTED_IN === $status )
					 || ( ! empty( $data['includeSoftBounce'] ) && BWFCRM_Contact::$STATUS_SOFT_BOUNCED === $status )
					 || ( ! empty( $data['includeUnverified'] ) && BWFCRM_Contact::$STATUS_NOT_OPTED_IN === $status )
					 || ( $includes_unsubscribers && ! empty( $state['unsubscribed'] ) );

		if ( $qualifies ) {
			return '';
		}

		switch ( $status ) {
			case BWFCRM_Contact::$STATUS_BOUNCED:
				return __( 'Contact bounced after this broadcast was prepared', 'wp-marketing-automations-pro' );

			case BWFCRM_Contact::$STATUS_COMPLAINT:
				return __( 'Contact marked this sender as spam after this broadcast was prepared', 'wp-marketing-automations-pro' );

			case BWFCRM_Contact::$STATUS_NOT_OPTED_IN:
				return __( 'Contact became unverified after this broadcast was prepared', 'wp-marketing-automations-pro' );

			/** Only reachable when the broadcast excludes soft bounces, so the bounce is newer than the preparation */
			case BWFCRM_Contact::$STATUS_SOFT_BOUNCED:
				return __( 'Contact soft bounced after this broadcast was prepared', 'wp-marketing-automations-pro' );

			default:
				return __( 'Contact is no longer part of this broadcast\'s audience', 'wp-marketing-automations-pro' );
		}
	}

	/**
	 * Highest contact id this broadcast already holds an engagement for
	 *
	 * Where the top up cursor starts. Engagement creation walks contact ids downwards -
	 * fetch_contacts_for_broadcast() feeds e_offset to the query as end_id - so every contact
	 * above this mark is one that entered the segment after creation had already passed it.
	 *
	 * @param int $broadcast_id Broadcast to read the mark of
	 *
	 * @return int Highest engaged contact id, 0 when the broadcast has no engagements yet
	 */
	public static function get_max_engaged_contact_id( $broadcast_id ) {
		global $wpdb;

		$engagement_table = $wpdb->prefix . 'bwfan_engagement_tracking';

		$max_cid = $wpdb->get_var( $wpdb->prepare( "SELECT MAX(cid) FROM {$engagement_table}
			WHERE oid = %d AND type = %d",
			absint( $broadcast_id ),
			BWFAN_Email_Conversations::$TYPE_CAMPAIGN
		) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return absint( $max_cid );
	}
}
