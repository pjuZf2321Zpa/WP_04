<?php

use BWFCRM\Actions\Base;

/**
 * BWFCRM_Actions_Handler
 */
#[AllowDynamicProperties]
class BWFCRM_Actions_Handler {
	/**
	 * Class instance
	 */
	private static $ins = null;
	/**
	 * Registered actions list
	 *
	 * @var array
	 */
	private $_actions = [];
	/**
	 * Registered action list slug mapped with nice name
	 *
	 * @var array
	 */
	private $_nice_names = [];

	/**
	 * Registered Actions group list
	 *
	 * @var array
	 */
	private $_groups = [];

	/**
	 * Bulk action handler instance
	 *
	 * @var BWFCRM_Bulk_Action_Handler|null
	 */
	private $bulk_action_handler_ins = null;

	/**
	 * Class constructor
	 */
	public function __construct() {
		add_action( 'init', [ $this, 'load_actions' ], 8 );
	}

	/**
	 * Returns class instance
	 *
	 * @return BWFCRM_Actions_Handler|null
	 */
	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self;
		}

		return self::$ins;
	}

	/**
	 * Set bulk action handler instance
	 * 
	 * @param BWFCRM_Bulk_Action_Handler|null $bulk_action_handler_ins
	 * @return void
	 */
	public function set_bulk_action_handler_ins( $bulk_action_handler_ins ) {
		$this->bulk_action_handler_ins = $bulk_action_handler_ins;
	}

	/**
	 * Get bulk action handler instance
	 * 
	 * @return BWFCRM_Bulk_Action_Handler|null
	 */
	public function get_bulk_action_handler_ins() {
		return $this->bulk_action_handler_ins;
	}

	/**
	 * Load all actions.
	 *
	 * Registrations used to sit at file scope in each action file, which
	 * blocked those classes from Pro's lazy classmap autoloader (rule 1: no
	 * file-scope register()). Declared here instead, the action files are
	 * pure class definitions resolved on first reference — no action file
	 * loads at this point.
	 *
	 * Adding a CRM action: a row here (glob/filename order) + the class in
	 * includes/class-bwfan-pro-autoload-map.php.
	 */
	public function load_actions() {
		$map = [
			[ 'add_to_lists', 'BWFCRM\Actions\Autonami\Add_To_Lists', __( 'Add Lists', 'wp-marketing-automations-pro' ), 'autonami', __( 'FunnelKit Automations', 'wp-marketing-automations-pro' ) ],
			[ 'add_tags', 'BWFCRM\Actions\Autonami\Add_Tags', __( 'Add Tags', 'wp-marketing-automations-pro' ), 'autonami', __( 'FunnelKit Automations', 'wp-marketing-automations-pro' ) ],
			[ 'add_to_automation', 'BWFCRM\Actions\Autonami\Add_To_Automation', __( 'Add To Automation', 'wp-marketing-automations-pro' ), 'autonami', __( 'FunnelKit Automations', 'wp-marketing-automations-pro' ) ],
			[ 'delete_contacts', 'BWFCRM\Actions\Autonami\Delete_Contacts', __( 'Delete Contacts', 'wp-marketing-automations-pro' ), 'autonami', __( 'FunnelKit Automations', 'wp-marketing-automations-pro' ) ],
			[ 'end_automation', 'BWFCRM\Actions\Autonami\End_Automation', __( 'End Automation', 'wp-marketing-automations-pro' ), 'autonami', __( 'FunnelKit Automations', 'wp-marketing-automations-pro' ) ],
			[ 'remove_lists', 'BWFCRM\Actions\Autonami\Remove_Lists', __( 'Remove Lists', 'wp-marketing-automations-pro' ), 'autonami', __( 'FunnelKit Automations', 'wp-marketing-automations-pro' ) ],
			[ 'remove_tags', 'BWFCRM\Actions\Autonami\Remove_Tags', __( 'Remove Tags', 'wp-marketing-automations-pro' ), 'autonami', __( 'FunnelKit Automations', 'wp-marketing-automations-pro' ) ],
			[ 'subscribe_contacts', 'BWFCRM\Actions\Autonami\Subscribe_Contacts', __( 'Subscribe Contacts', 'wp-marketing-automations-pro' ), 'autonami', __( 'FunnelKit Automations', 'wp-marketing-automations-pro' ) ],
			[ 'unsubscribe_contacts', 'BWFCRM\Actions\Autonami\Unsubscribe_Contacts', __( 'Unsubscribe Contacts', 'wp-marketing-automations-pro' ), 'autonami', __( 'FunnelKit Automations', 'wp-marketing-automations-pro' ) ],
			[ 'update_fields', 'BWFCRM\Actions\Autonami\Update_Fields', __( 'Update Fields', 'wp-marketing-automations-pro' ), 'autonami', __( 'FunnelKit Automations', 'wp-marketing-automations-pro' ) ],
		];

		foreach ( $map as $args ) {
			call_user_func_array( [ $this, 'register_action' ], $args );
		}

		do_action( 'bwfcrm_actions_loaded' );
	}

	/**
	 * Function registers actions
	 *
	 * @param $slug
	 * @param $class
	 * @param $nice_name
	 */
	public function register_action( $slug, $class, $nice_name, $group = '', $group_label = '' ) {
		if ( empty( $slug ) ) {
			return;
		}

		$this->_actions[ $slug ]    = $class;
		$this->_nice_names[ $slug ] = ! empty( $nice_name ) ? $nice_name : $slug;
		if ( ! empty( $group ) && ! empty( $group_label ) ) {
			if ( isset( $this->_groups[ $group ] ) && isset( $this->_groups[ $group ]['actions'] ) && is_array( $this->_groups[ $group ]['actions'] ) ) {
				$actions = $this->_groups[ $group ]['actions'];
				/**
				 * _actions and _nice_names are slug-keyed, so re-registering a slug
				 * is a no-op there; this list is positional and would gain a second
				 * entry, which get_group_list() renders as a duplicate action. The
				 * require_once in the glob this map replaced made a second pass
				 * impossible — keep the registry itself idempotent instead.
				 */
				if ( ! in_array( $slug, $actions, true ) ) {
					array_push( $actions, $slug );
				}
			} else {
				$actions = [ $slug ];
			}

			$this->_groups[ $group ] = [
				'label'   => $group_label,
				'actions' => $actions
			];
		}
	}

	/**
	 * Returns action schema data map with action slug
	 *
	 * @return array
	 */
	public function get_all_actions_schema_data() {
		$data = [];
		foreach ( $this->_actions as $slug => $action ) {
			$action_obj = $this->get_action_by_slug( $slug );
			/**
			 * A slug is registered from the declared map, but its class resolves
			 * through the Pro classmap autoloader, which bails silently on an
			 * unreadable map or class file (update file-swap / partial deploy).
			 * The glob this map replaced skipped such a file via is_readable(),
			 * so $_actions could never hold an unresolvable slug — keep that
			 * guarantee here: drop the action, never fatal the whole response.
			 */
			if ( ! $action_obj instanceof Base ) {
				continue;
			}
			$data[ $slug ] = $action_obj->get_action_schema();
		}

		return $data;
	}

	/**
	 * Return action object by slug
	 *
	 * @param $slug
	 *
	 * @return |Base|null
	 */
	public function get_action_by_slug( $slug ) {
		if ( empty( $slug ) ) {
			return null;
		}

		$action_class = $this->_actions[ $slug ] ?? '';
		$action_obj   = class_exists( $action_class ) ? ( new $action_class ) : null;

		return $action_obj instanceof Base ? $action_obj : null;
	}

	/**
	 * Returns action array slug mapped with nice name
	 *
	 * @return array
	 */
	public function get_all_action_list( $support = 0 ) {
		if ( intval( $support ) === 0 ) {
			return $this->_nice_names;
		}

		$actions = [];
		foreach ( $this->_nice_names as $slug => $label ) {
			$actionObj = $this->get_action_by_slug( $slug );
			/** Unresolvable class — same guard as get_all_actions_schema_data(). */
			if ( ! $actionObj instanceof Base ) {
				continue;
			}
			$supported = $actionObj->get_action_support();
			if ( in_array( $support, $supported ) ) {
				$actions[ $slug ] = $label;
			}
		}

		return $actions;
	}

	/**
	 * Return action group list
	 *
	 * @return array
	 */
	public function get_group_list() {
		return $this->_groups;
	}

	public function process_all_actions( $actions, $contact ) {
		$response = [];
		if ( empty( $actions ) ) {
			return $response;
		}

		$bulk_action_id = isset( $actions['id'] ) ? $actions['id'] : 0;
		if ( isset( $actions['id'] ) ) {
			unset( $actions['id'] );
		}

		foreach ( $actions as $action => $data ) {
			if ( ! is_null( $this->bulk_action_handler_ins ) ) {
				$this->bulk_action_handler_ins->set_log( 'action started: ' . $action );
			}
			$action_obj = $this->get_action_by_slug( $action );

			if ( is_null( $action_obj ) ) {
				continue;
			}

			/** Set the from flag for end automation and unsubscribe contacts actions to know the source of the action */
			$allowed_actions = [ 'end_automation', 'unsubscribe_contacts', 'update_field' ];
			if ( in_array( $action, $allowed_actions, true ) ) {
				$data['from']           = 'Bulk Action';
				$data['bulk_action_id'] = $bulk_action_id;
			}

			$response[ $action ] = $action_obj->handle_action( $contact, $data );
			if ( ! is_null( $this->bulk_action_handler_ins ) ) {
				$this->bulk_action_handler_ins->set_log( 'action processed: ' . $action );
			}
		}

		return $response;
	}
}

/**
 * Register action handler to BWFCRM_Core
 */
if ( class_exists( 'BWFCRM_Actions_Handler' ) ) {
	BWFCRM_Core::register( 'actions', 'BWFCRM_Actions_Handler' );
}
