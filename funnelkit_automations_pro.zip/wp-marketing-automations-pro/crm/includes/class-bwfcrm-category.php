<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

#[\AllowDynamicProperties]
class BWFCRM_Category extends BWFCRM_Term {
	public static $AUTOMATION = 4;
	public static $BROADCAST = 5;
	public static $TEMPLATE = 6;
	public static $FORM = 7;
	public static $LINK_TRIGGER = 8;

	/**
	 * Valid category types
	 */
	private const VALID_TYPES = [
		4, // AUTOMATION
		5, // BROADCAST
		6, // TEMPLATE
		7, // FORM
		8, // LINK_TRIGGER
	];

	public function __construct( $data = false ) {
		parent::__construct( $data );
	}

	/**
	 * Fetch the terms of the category
	 *
	 * @param mixed $type Category type (accepts int, string, or numeric)
	 * @param array $ids Category IDs
	 * @param string $search Search term
	 * @param string $exact Exact search nature
	 * @param mixed $limit Limit results (accepts int, string, or numeric)
	 * @return array|false Array of categories or false on failure
	 */
	public static function get_categories( $type = 0, $ids = [], $search = '', $exact = '', $limit = 10 ) {
		$type = is_numeric( $type ) ? (int) $type : 0;
		$limit = is_numeric( $limit ) ? (int) $limit : 10;
		$ids = is_array( $ids ) ? $ids : [];

		if ( ! self::is_valid_type( $type ) ) {
			return false;
		}

		return parent::get_terms( $type, $ids, $search, 0, $limit, ARRAY_A, $exact );
	}

	/**
	 * Fetch the category by id
	 *
	 * @param mixed $type Category type (accepts int, string, or numeric)
	 * @param array $ids Category IDs
	 * @return array Array of category details
	 */
	public static function get_category_by_id( $type, $ids = [] ) {
		$type = is_numeric( $type ) ? (int) $type : 0;
		$ids = is_array( $ids ) ? $ids : [];

		if ( empty( $ids ) || ! self::is_valid_type( $type ) ) {
			return [];
		}

		$ids = array_map( 'absint', $ids );
		$category_details = BWFAN_Model_Terms::get_terms( $type, 0, 0, '', $ids, 'exact', true );

		if ( empty( $category_details ) ) {
			return [];
		}

		return array_map( function ( $category ) {
			return [
				'id'   => absint( $category['ID'] ?? 0 ),
				'name' => $category['name'] ?? '',
			];
		}, $category_details );
	}

	/**
	 * Use to update the name of the category
	 *
	 * @param string $terms Term name
	 * @param mixed $type Category type (accepts int, string, or numeric)
	 * @return array|false|object|stdClass|null
	 */
	public static function save_category( $terms = '', $type = 0 ) {
		$type = is_numeric( $type ) ? (int) $type : 0;

		if ( ! self::is_valid_type( $type ) ) {
			return false;
		}

		return parent::add_term_to_db( $terms, $type );
	}

	/**
	 * Validate the type of category before proceeding to next move
	 *
	 * @param mixed $type Category type (accepts int, string, or numeric)
	 * @return bool True if valid, false otherwise
	 */
	public static function is_valid_type( $type = 0 ) {
		// Cast to int for validation (maintains backward compatibility)
		$type = is_numeric( $type ) ? (int) $type : 0;
		return in_array( $type, self::VALID_TYPES, true );
	}

	/**
	 * Insert the category to the terms table with their types
	 *
	 * @param array $categories Categories array
	 * @param mixed $type Category type (accepts int, string, or numeric)
	 * @return array|false Array of created categories or false on failure
	 */
	public static function add_categories( $categories, $type ) {
		$type = is_numeric( $type ) ? (int) $type : 0;
		$categories = is_array( $categories ) ? $categories : [];

		if ( empty( $categories ) || ! self::is_valid_type( $type ) ) {
			return false;
		}

		$created_categories = BWFCRM_Term::get_or_create_terms( $categories, $type, true, true );

		if ( empty( $created_categories ) ) {
			return false;
		}

		return $created_categories;
	}

	/**
	 * Get the model class based on type
	 *
	 * @param mixed $type Category type (accepts int, string, or numeric)
	 * @return string Model class name
	 */
	public static function get_model_classes( $type ) {
		$type = is_numeric( $type ) ? (int) $type : 0;
		switch ( $type ) {
			case self::$AUTOMATION:
				return 'BWFAN_Model_Automations';
			case self::$BROADCAST:
				return 'BWFAN_Model_Broadcast';
			case self::$TEMPLATE:
				return 'BWFAN_Model_Templates';
			case self::$FORM:
				return 'BWFAN_Model_Form_Feeds';
			case self::$LINK_TRIGGER:
				return 'BWFAN_Model_Link_Triggers';
			default:
				return '';
		}
	}

	/**
	 * Call assign method of different category based on it's types
	 *
	 * @param array $items_ids Item IDs
	 * @param array $categories Categories array
	 * @param mixed $type Category type (accepts int, string, or numeric)
	 * @return bool True on success, false on failure
	 */
	public static function assign_categories( $items_ids = [], $categories = [], $type = 0 ) {
		$type = is_numeric( $type ) ? (int) $type : 0;
		$items_ids = is_array( $items_ids ) ? $items_ids : [$items_ids];
		$categories = is_array( $categories ) ? $categories : [];

		// Allow empty categories array to unassign all categories
		if ( empty( $items_ids ) || ! self::is_valid_type( $type ) ) {
			return false;
		}

		return self::process_data( $items_ids, $categories, $type );
	}

	/**
	 * Process category assignment data
	 *
	 * @param array|int $items_ids Item IDs (can be single ID or array)
	 * @param array $categories Categories array
	 * @param mixed $type Category type (accepts int, string, or numeric)
	 * @return bool True on success, false on failure
	 */
	public static function process_data( $items_ids, $categories, $type ) {
		$type = is_numeric( $type ) ? (int) $type : 0;
		$items_ids = ! is_array( $items_ids ) ? [ $items_ids ] : $items_ids;
		$items_ids = array_map( 'absint', $items_ids );
		$categories = is_array( $categories ) ? $categories : [];

		// Allow empty categories array to remove all categories
		if ( empty( $items_ids ) || ! self::is_valid_type( $type ) ) {
			return false;
		}

		$category_ids = self::validate_and_prepare_data( $items_ids, $categories );
		// Allow false/empty to proceed (for removing all categories)
		if ( false === $category_ids ) {
			return false; // Invalid items_ids
		}
		// Empty array is allowed (for removing all categories)

		$get_model_class = self::get_model_classes( $type );
		if ( ! class_exists( $get_model_class ) || ! method_exists( $get_model_class, 'get_data_by_id' ) ) {
			return false;
		}

		$item_data = $get_model_class::get_data_by_id( $items_ids );
		if ( empty( $item_data ) ) {
			return false;
		}

		$categories_to_update = [];
		$items_count = count( $items_ids );
		$is_bulk_operation = $items_count > 1;

		foreach ( $item_data as $id => $value ) {
			$existing_categories = self::parse_categories_json( $value['category'] ?? '' );

			// For bulk operations (multiple items): merge/add categories
			// For single item: replace categories (or remove all if empty)
			if ( $is_bulk_operation ) {
				// Merge existing with new categories (add operation)
				$final_category_ids = array_unique( array_merge( $existing_categories, $category_ids ) );
			} else {
				// Replace existing categories with new ones (replace operation)
				$final_category_ids = array_unique( $category_ids );
			}

			$assigned = array_diff( $final_category_ids, $existing_categories );
			$removed  = array_diff( $existing_categories, $final_category_ids );

			$update_data = [
				'category' => ! empty( $final_category_ids )
					? wp_json_encode( array_map( 'strval', array_values( $final_category_ids ) ) )
					: '',
			];
			$update_where = [ 'ID' => absint( $id ) ];
			if ( false === $get_model_class::update( $update_data, $update_where ) ) {
				return false;
			}

			// Track count changes
			foreach ( $assigned as $cat_id ) {
				$categories_to_update[ $cat_id ] = ( $categories_to_update[ $cat_id ] ?? 0 ) + 1;
			}

			foreach ( $removed as $cat_id ) {
				$categories_to_update[ $cat_id ] = ( $categories_to_update[ $cat_id ] ?? 0 ) - 1;
			}
		}

		// Update term counts
		if ( ! empty( $categories_to_update ) ) {
			return self::update_term_counts( $categories_to_update, array_keys( $categories_to_update ), $type );
		}

		return true;
	}

	/**
	 * Call delete reference method based on condition & types
	 *
	 * @param mixed $type Category type (accepts int, string, or numeric)
	 * @param array $categories_ids Category IDs to delete
	 * @return bool True if all deletions successful, false otherwise
	 */
	public static function delete_terms_with_reference( $type = 0, $categories_ids = [] ) {
		$type = is_numeric( $type ) ? (int) $type : 0;
		$categories_ids = is_array( $categories_ids ) ? $categories_ids : [];

		if ( empty( $type ) || ! self::is_valid_type( $type ) ) {
			return false;
		}

		if ( empty( $categories_ids ) ) {
			return false;
		}

		$deletable_category = self::process_delete_categories( $categories_ids, $type );
		$failed_deletions   = [];

		if ( ! empty( $deletable_category ) ) {
			foreach ( $categories_ids as $category_id ) {
				if ( ! BWFAN_Model_Terms::delete_term( $category_id ) ) {
					$failed_deletions[] = $category_id;
				}
			}
		}

		return empty( $failed_deletions );
	}

	/**
	 * Process category deletions and return deletable category IDs
	 *
	 * @param array $category_ids Category IDs to delete
	 * @param mixed $type Category type (accepts int, string, or numeric)
	 * @return array Deletable category IDs (empty array if none can be deleted)
	 */
	public static function process_delete_categories( $category_ids = [], $type = 0 ) {
		$type = is_numeric( $type ) ? (int) $type : 0;
		$category_ids = is_array( $category_ids ) ? $category_ids : [];

		if ( empty( $category_ids ) || ! self::is_valid_type( $type ) ) {
			return [];
		}

		$get_model_class = self::get_model_classes( $type );
		if ( ! class_exists( $get_model_class ) || ! method_exists( $get_model_class, 'get_data_with_categories' ) ) {
			return [];
		}

		$item_data = $get_model_class::get_data_with_categories( $category_ids );
		if ( empty( $item_data ) ) {
			// No items reference these categories, all are deletable
			return $category_ids;
		}

		$matched_categories = [];
		$successfully_updated = [];

		foreach ( $item_data as $data ) {
			$categories = self::parse_categories_json( $data['category'] ?? '' );
			if ( empty( $categories ) ) {
				continue;
			}

			$item_matched_categories = array_intersect( $categories, $category_ids );
			if ( empty( $item_matched_categories ) ) {
				continue;
			}

			$matched_categories = array_merge( $matched_categories, $item_matched_categories );
			$updated_categories = array_diff( $categories, $category_ids );

			// Only update if categories were actually removed
			if ( count( $categories ) !== count( $updated_categories ) ) {
				$update_data = [
					'category' => ! empty( $updated_categories )
						? wp_json_encode( array_map( 'strval', array_values( $updated_categories ) ) )
						: '',
				];

				if ( $get_model_class::update( $update_data, [ 'ID' => absint( $data['ID'] ) ] ) ) {
					$successfully_updated = array_merge( $successfully_updated, $item_matched_categories );
				}
			}
		}

		$matched_categories = array_unique( $matched_categories );
		$successfully_updated = array_unique( $successfully_updated );

		// Return categories that were successfully removed from items + categories not referenced at all
		return array_unique( array_merge(
			$successfully_updated,
			array_diff( $category_ids, $matched_categories )
		) );
	}

	/**
	 * Update term counts for categories
	 *
	 * @param array $categories_to_update Array of category_id => count_change
	 * @param array $category_ids Category IDs to update
	 * @param mixed $type Category type (accepts int, string, or numeric)
	 * @return bool True if all updates successful, false otherwise
	 */
	public static function update_term_counts( $categories_to_update = [], $category_ids = [], $type = 0 ) {
		$type = is_numeric( $type ) ? (int) $type : 0;
		$categories_to_update = is_array( $categories_to_update ) ? $categories_to_update : [];
		$category_ids = is_array( $category_ids ) ? $category_ids : [];

		if ( empty( $categories_to_update ) || empty( $category_ids ) || ! self::is_valid_type( $type ) ) {
			return false;
		}

		$all_terms = BWFAN_Model_Terms::get_terms( $type, 0, 0, '', $category_ids );
		if ( empty( $all_terms ) ) {
			return false;
		}

		$terms_map = array_column( $all_terms, null, 'ID' );
		$all_success = true;

		foreach ( $categories_to_update as $cat_id => $count ) {
			if ( ! isset( $terms_map[ $cat_id ] ) ) {
				continue;
			}

			$term = $terms_map[ $cat_id ];
			$data = self::parse_term_data( $term['data'] ?? '' );
			$data['count'] = max( 0, ( $data['count'] ?? 0 ) + $count );

			$update_result = BWFAN_Model_Terms::update(
				[ 'data' => wp_json_encode( $data ) ],
				[ 'ID' => $cat_id ]
			);

			if ( false === $update_result ) {
				$all_success = false;
			}
		}

		return $all_success;
	}

	/**
	 * Decrease the count of the category based on the type
	 *
	 * @param array|int $items_ids Item IDs (can be single ID or array)
	 * @param mixed $type Category type (accepts int, string, or numeric)
	 * @return bool True on success, false on failure
	 */
	public static function handle_category_count_decrease( $items_ids, $type = 0 ) {
		$type = is_numeric( $type ) ? (int) $type : 0;
		if ( ! is_array( $items_ids ) ) {
			$items_ids = [ $items_ids ];
		}

		$items_ids = array_map( 'absint', $items_ids );

		if ( empty( $items_ids ) || ! self::is_valid_type( $type ) ) {
			return false;
		}

		$get_model_class = self::get_model_classes( $type );
		if ( ! class_exists( $get_model_class ) || ! method_exists( $get_model_class, 'get_data_by_id' ) ) {
			return false;
		}

		$item_data = $get_model_class::get_data_by_id( $items_ids );
		if ( empty( $item_data ) ) {
			return false;
		}

		$all_categories_to_decrease = [];

		foreach ( $item_data as $item ) {
			$categories = self::parse_categories_json( $item['category'] ?? '' );

			if ( ! empty( $categories ) ) {
				foreach ( $categories as $cat_id ) {
					$all_categories_to_decrease[] = absint( $cat_id );
				}
			}
		}

		if ( empty( $all_categories_to_decrease ) ) {
			return true;
		}

		$unique_categories = array_unique( $all_categories_to_decrease );
		$all_terms = BWFAN_Model_Terms::get_terms( $type, 0, 0, '', $unique_categories );

		if ( empty( $all_terms ) ) {
			return false;
		}

		$terms_map = array_column( $all_terms, null, 'ID' );
		$category_decrease_counts = array_count_values( $all_categories_to_decrease );

		$updates = [];
		foreach ( $category_decrease_counts as $cat_id => $count ) {
			if ( isset( $terms_map[ $cat_id ] ) ) {
				$term = $terms_map[ $cat_id ];
				$term_data = self::parse_term_data( $term['data'] ?? '' );
				$old_count = $term_data['count'] ?? 0;
				$new_count = max( 0, $old_count - $count );

				$term_data['count'] = $new_count;
				$updates[] = [
					'ID'   => absint( $cat_id ),
					'data' => wp_json_encode( $term_data ),
				];
			}
		}

		foreach ( $updates as $update ) {
			if ( ! BWFAN_Model_Terms::update( [ 'data' => $update['data'] ], [ 'ID' => $update['ID'] ] ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Validate the params and prepare the data to save them in terms table
	 *
	 * @param array $items_ids Item IDs
	 * @param array $categories Categories array with 'created' and 'existing' keys
	 * @return array|false Array of category IDs or false on failure
	 */
	private static function validate_and_prepare_data( $items_ids = [], $categories = [] ) {
		$items_ids = is_array( $items_ids ) ? $items_ids : [];
		$categories = is_array( $categories ) ? $categories : [];

		if ( empty( $items_ids ) ) {
			return false;
		}

		// Allow empty categories array to unassign all categories
		if ( empty( $categories ) ) {
			return [];
		}

		$category_ids = [];

		if ( ! empty( $categories['created'] ) && is_array( $categories['created'] ) ) {
			foreach ( $categories['created'] as $category ) {
				if ( is_object( $category ) && method_exists( $category, 'get_id' ) ) {
					$category_ids[] = absint( $category->get_id() );
				}
			}
		}

		if ( ! empty( $categories['existing'] ) && is_array( $categories['existing'] ) ) {
			foreach ( $categories['existing'] as $category ) {
				if ( is_object( $category ) && method_exists( $category, 'get_id' ) ) {
					$category_ids[] = absint( $category->get_id() );
				}
			}
		}

		return empty( $category_ids ) ? [] : array_unique( $category_ids );
	}

	/**
	 * Safely parse categories JSON string
	 *
	 * @param string $json JSON string
	 * @return array Parsed categories array
	 */
	private static function parse_categories_json( $json ) {
		if ( ! is_string( $json ) || empty( trim( $json ) ) ) {
			return [];
		}

		$decoded = json_decode( $json, true );

		if ( json_last_error() !== JSON_ERROR_NONE ) {
			return [];
		}

		return is_array( $decoded ) ? array_map( 'absint', $decoded ) : [];
	}

	/**
	 * Safely parse term data JSON string
	 *
	 * @param string $json JSON string
	 * @return array Parsed term data array
	 */
	private static function parse_term_data( $json ) {
		if ( ! is_string( $json ) || empty( trim( $json ) ) ) {
			return [];
		}

		$decoded = json_decode( $json, true );

		if ( json_last_error() !== JSON_ERROR_NONE ) {
			return [];
		}

		return is_array( $decoded ) ? $decoded : [];
	}
}
