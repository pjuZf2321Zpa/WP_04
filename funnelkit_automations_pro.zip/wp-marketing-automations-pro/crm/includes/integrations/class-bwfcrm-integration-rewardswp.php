<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

#[\AllowDynamicProperties]
class BWFCRM_Integration_RewardsWP {

	private static $ins = null;

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	public function __construct() {
		if ( ! function_exists( 'bwfan_is_rewardswp_active' ) || ! bwfan_is_rewardswp_active() ) {
			return;
		}

		/** Single Contact API Response */
		add_filter( 'bwfan_single_contact_get_array', array( $this, 'get_rewardswp_array' ), 10, 3 );
	}

	/**
	 * Get RewardsWP member details for a contact.
	 *
	 * @param int|WooFunnels_Contact $contact Contact ID or object.
	 *
	 * @return array
	 */
	public function get_contact_member_details( $contact ) {
		if ( is_numeric( $contact ) ) {
			$contact = new WooFunnels_Contact( '', '', '', absint( $contact ) );
		}

		if ( ! $contact instanceof WooFunnels_Contact || 0 === absint( $contact->get_wpid() ) ) {
			return array();
		}

		return $this->get_member_details( $contact->get_wpid() );
	}

	/**
	 * Fetch member summary data from RewardsWP.
	 *
	 * @param int $user_id WordPress user ID.
	 *
	 * @return array
	 */
	public function get_member_details( $user_id ) {
		if ( ! function_exists( 'Awesomemotive\Rewardswp\Helpers\get_member_by' ) ) {
			return array();
		}

		$member = \Awesomemotive\Rewardswp\Helpers\get_member_by( 'user_id', $user_id );

		if ( ! $member ) {
			return array(
				'member_id'           => '-',
				'status'              => '-',
				'referral_code'       => '-',
				'referral_url'        => '-',
				'points_balance'      => '0',
				'points_earned'       => '0',
				'points_spent'        => '0',
				'total_referrals'     => '0',
				'completed_referrals' => '0',
				'conversion_rate'     => '-',
				'total_revenue'       => '-',
				'member_since'        => '-',
				'edit_link'           => '-',
			);
		}

		$points_earned = 0;
		$points_spent  = 0;
		if ( function_exists( 'Awesomemotive\Rewardswp\Helpers\get_member_points_earned' ) ) {
			$points_earned = intval( \Awesomemotive\Rewardswp\Helpers\get_member_points_earned( $member->id ) );
		}
		if ( function_exists( 'Awesomemotive\Rewardswp\Helpers\get_member_points_spent' ) ) {
			$points_spent = intval( \Awesomemotive\Rewardswp\Helpers\get_member_points_spent( $member->id ) );
		}

		return array(
			'member_id'           => $member->id,
			'status'              => $member->get_status(),
			'referral_code'       => $member->referral_code ? $member->referral_code : '-',
			'referral_url'        => $member->get_referral_url() ? $member->get_referral_url() : '-',
			'points_balance'      => intval( $member->points_balance ),
			'points_earned'       => $points_earned,
			'points_spent'        => $points_spent,
			'total_referrals'     => intval( $member->total_referrals ),
			'completed_referrals' => intval( $member->completed_referrals ),
			'conversion_rate'     => $member->get_referral_conversion_rate(),
			'total_revenue'       => $member->get_total_referral_revenue(),
			'member_since'        => $member->created_at ? $member->created_at : '-',
			'edit_link'           => $this->get_edit_link( $member->id ),
		);
	}

	/**
	 * Hook callback: inject RewardsWP data into the single contact response.
	 */
	public function get_rewardswp_array( $contact_array, $contact, $slim_data = true ) {
		if ( ! is_array( $contact_array ) || ! $contact instanceof BWFCRM_Contact || ! $contact->is_contact_exists() || true === $slim_data ) {
			return $contact_array;
		}

		$user_id = $contact->contact->get_wpid();
		if ( empty( $user_id ) ) {
			return $contact_array;
		}

		$contact_array['rewardswp'] = $this->get_member_details( absint( $user_id ) );

		return $contact_array;
	}

	/**
	 * Build admin edit link for a RewardsWP member.
	 *
	 * @param int $member_id RewardsWP member ID.
	 *
	 * @return string
	 */
	public function get_edit_link( $member_id ) {
		return admin_url( 'admin.php?page=rewardswp#/members/' . intval( $member_id ) );
	}
}

if ( class_exists( 'BWFCRM_Integration_RewardsWP' ) ) {
	BWFCRM_Core()->integrations->register( 'BWFCRM_Integration_RewardsWP' );
}
