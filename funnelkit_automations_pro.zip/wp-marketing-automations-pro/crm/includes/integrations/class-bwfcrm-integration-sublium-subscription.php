<?php

/**
 * Sublium Subscription Integration Class
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

#[\AllowDynamicProperties]
class BWFCRM_Integration_Sublium_Subscription {
	private static $instance = null;

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public function __construct() {
		if ( ! function_exists( 'bwfan_is_sublium_active' ) || ! bwfan_is_sublium_active() ) {
			return;
		}

		/** Adding sublium subscriptions details to single contact API response */
		add_filter( 'bwfan_single_contact_get_array', array( $this, 'get_sublium_array' ), 10, 3 );
	}

	/**
	 * Get sublium subscriptions details
	 *
	 * @param array $contact_array
	 * @param object $contact
	 * @param bool $slim_data
	 * @return array
	 */
	public function get_sublium_array( $contact_array, $contact, $slim_data = true ) {
		if ( true === $slim_data ) {
			return $contact_array;
		}

		$contact_wpid = $contact->contact->get_wpid();

		if ( 0 === absint( $contact_wpid ) ) {
			return $contact_array;
		}

		$user_total_renewal          = 0;
		$user_total_renewal_amount   = 0;
		$user_renewal_dates          = array();
		$user_next_renewal_date      = '';
		$user_next_renewal_amount    = 0;
		$user_active_subscriptions   = 0;
		$user_inactive_subscriptions = 0;

		$subscriptions_db = new \Sublium_WCS\Includes\database\subscriptions();
		$subscriptions = $subscriptions_db->read( array( 'user_id' => absint( $contact_wpid ) ), 0, 0, 'id', 'DESC' );

		if ( empty( $subscriptions ) ) {
			return $contact_array;
		}

		// Sublium active statuses: ACTIVE (3), TRIALING (2), COMPLETED (8)
		$active_statuses = array(
			\Sublium_WCS\Includes\Controller\Subscriptions\Subscription::STATUSES['ACTIVE'],
			\Sublium_WCS\Includes\Controller\Subscriptions\Subscription::STATUSES['TRIALING'],
			\Sublium_WCS\Includes\Controller\Subscriptions\Subscription::STATUSES['COMPLETED'],
		);

		foreach ( $subscriptions as $subscription_record ) {
			if ( ! isset( $subscription_record['id'] ) || empty( $subscription_record['id'] ) ) {
				continue;
			}

			$subscription = new \Sublium_WCS\Includes\Controller\Subscriptions\Subscription( $subscription_record['id'] );
			if ( ! $subscription->exists ) {
				continue;
			}

			$subscription_status = $subscription->get_status();

			if ( in_array( $subscription_status, $active_statuses, true ) ) {
				$user_active_subscriptions ++;
				$next_payment_date = $subscription->get_next_payment_date();
				if ( ! empty( $next_payment_date ) ) {
					$user_renewal_dates[ $subscription->get_id() ] = $next_payment_date;
				}

				// Get renewal orders for this subscription
				if ( function_exists( 'sublium_get_subscription_renewal_orders' ) ) {
					$renewal_order_ids = sublium_get_subscription_renewal_orders( $subscription->get_id() );
					if ( ! empty( $renewal_order_ids ) && is_array( $renewal_order_ids ) ) {
						$paid_statuses = wc_get_is_paid_statuses();
						foreach ( $renewal_order_ids as $order_id ) {
							$order = wc_get_order( $order_id );
							if ( ! $order instanceof WC_Order || ! $order->has_status( $paid_statuses ) ) {
								continue;
							}
							$user_total_renewal ++;
							$order_total = BWF_Plugin_Compatibilities::get_fixed_currency_price_reverse( $order->get_total(), BWF_WC_Compatibility::get_order_currency( $order ) );
							$user_total_renewal_amount += $order_total;
						}
					}
				} else {
					// Fallback: use renewal count if function doesn't exist
					$renewal_count = $subscription->get_renewal_count();
					if ( empty( $renewal_count ) ) {
						$renewal_count = $subscription->get_successful_payment_count();
					}
					$user_total_renewal += absint( $renewal_count );

					$subscription_total = $subscription->get_totals();
					$subscription_currency = $subscription->get_currency();
					$renewal_amount = BWF_Plugin_Compatibilities::get_fixed_currency_price_reverse( $subscription_total, $subscription_currency );
					$user_total_renewal_amount += ( $renewal_amount * absint( $renewal_count ) );
				}
			} else {
				$user_inactive_subscriptions ++;
			}
		}

		/** getting contact next renewal date and next renewal amount */
		if ( ! empty( $user_renewal_dates ) ) {
			uasort( $user_renewal_dates, function ( $date1, $date2 ) {
				return ( strtotime( $date1 ) <=> strtotime( $date2 ) );
			} );

			foreach ( $user_renewal_dates as $subscription_id => $subscription_dates ) {
				$subscription = new \Sublium_WCS\Includes\Controller\Subscriptions\Subscription( $subscription_id );

				if ( ! $subscription->exists ) {
					break;
				}

				$subscription_total = $subscription->get_totals();
				$subscription_currency = $subscription->get_currency();
				$user_next_renewal_amount = BWF_Plugin_Compatibilities::get_fixed_currency_price_reverse( $subscription_total, $subscription_currency );
				$user_next_renewal_date   = $subscription_dates;
				break;
			}
		}

		$data = [
			'active_subscriptions'   => $user_active_subscriptions,
			'inactive_subscriptions' => $user_inactive_subscriptions,
			'next_renewal_date'      => $user_next_renewal_date,
			'next_renewal_amount'    => $user_next_renewal_amount,
			'total_renewal_count'    => $user_total_renewal,
			'total_renewal_amount'   => number_format( $user_total_renewal_amount, 2 ),
		];

		$contact_array['sublium'] = $data;

		return $contact_array;
	}
}

if ( class_exists( 'BWFCRM_Integration_Sublium_Subscription' ) ) {
	BWFCRM_Core()->integrations->register( 'BWFCRM_Integration_Sublium_Subscription' );
}
