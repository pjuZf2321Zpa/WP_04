<?php

#[\AllowDynamicProperties]
class BWFCRM_Filter_Broadcast_Sent extends BWFCRM_Custom_Filter_Base {
	private static $ins = null;
	private $is_join = false;

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	public function __construct() {
		$this->name = 'broadcast_sent';
		add_filter( 'bwfan_contact_sql_join_query', array( $this, 'join_query' ), 10, 2 );
		add_filter( 'bwfan_contact_sql_where_query', array( $this, 'where_query' ), 10, 4 );
	}

	/**
	 * Add join of custom filter
	 *
	 * @param $join_query
	 * @param $custom_filters
	 *
	 * @return string
	 */
	public function join_query( $join_query, $custom_filters ) {

		if ( true !== $this->is_join || ! $this->is_current_filter_exists( $custom_filters ) ) {
			return $join_query;
		}

		$filter       = $this->maybe_get_current_filter( $custom_filters );
		$filter_value = intval( $filter['value'] );

		global $wpdb;
		if ( strpos( $join_query, "LEFT JOIN {$wpdb->prefix}bwfan_engagement_tracking as et1" ) === false ) {
			$join_query .= " LEFT JOIN {$wpdb->prefix}bwfan_engagement_tracking as et1 ON c.id=et1.cid AND et1.c_status = '2' AND et1.type = '2' AND et1.oid = $filter_value";
		}

		return $join_query;
	}

	public function where_query( $filter_where, $filter_key, $filter_rule, $filter_value ) {
		$this->is_join = BWFAN_Pro_Common::use_left_join( [ 'key' => $filter_key, 'value' => $filter_value ], [] );
		if ( $this->name !== $filter_key || empty( $filter_value ) ) {
			return $filter_where;
		}

		$filter_value   = intval( $filter_value );
		$status_send    = BWFAN_Email_Conversations::$STATUS_SEND;
		$type_broadcast = BWFAN_Email_Conversations::$TYPE_CAMPAIGN;
		$query          = '';
		switch ( $filter_rule ) {
			case 'yes':
				$query = $this->is_join ? "et1.id IS NOT NULL" : " EXISTS";
				break;
			case 'no':
				$query = $this->is_join ? "et1.id IS NULL" : " NOT EXISTS";
				break;
		}
		if ( empty( $this->is_join ) && ! empty( $query ) ) {
			global $wpdb;
			$query = " $query ( SELECT 1 FROM {$wpdb->prefix}bwfan_engagement_tracking AS egt WHERE c.id = egt.cid AND egt.oid = $filter_value AND egt.type = $type_broadcast AND egt.c_status = $status_send ) ";
		}

		return $query;
	}
}

$ins = BWFCRM_Filter_Broadcast_Sent::get_instance();
BWFCRM_Filters::register_custom_filter( $ins->name );
