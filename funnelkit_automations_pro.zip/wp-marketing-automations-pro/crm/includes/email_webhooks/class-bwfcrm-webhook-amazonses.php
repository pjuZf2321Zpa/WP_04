<?php

#[\AllowDynamicProperties]
class BWFCRM_Webhook_AmazonSES extends BWFCRM_Email_Webhook_Base {
	private static $ins = null;

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self;
		}

		return self::$ins;
	}

	public function __construct() {
		$this->_name = "Amazon SES";
	}

	public function handle_webhook() {
		if ( ! is_array( $this->_data ) || empty( $this->_data ) ) {
			return;
		}

		$this->maybe_bounce_contact_email();
	}

	private function maybe_bounce_contact_email() {
		$notificationType = isset( $this->_data['notificationType'] ) && ! empty( $this->_data['notificationType'] ) ? $this->_data['notificationType'] : '';

		if ( empty( $notificationType ) ) {
			$notificationType = isset( $this->_data['Type'] ) && ! empty( $this->_data['Type'] ) ? $this->_data['Type'] : '';
		}

		if ( empty( $notificationType ) ) {
			BWFAN_Core()->logger->log( "Amazon SES no notification type found", 'crm_email_webhooks' );

			return;
		}

		$mail       = isset( $this->_data['mail'] ) && is_array( $this->_data['mail'] ) ? $this->_data['mail'] : [];
		$subject    = isset( $mail['commonHeaders']['subject'] ) ? $mail['commonHeaders']['subject'] : '';
		$message_id = isset( $mail['messageId'] ) ? $mail['messageId'] : '';

		if ( $notificationType === 'SubscriptionConfirmation' ) {
			// Validate SubscribeURL is a legitimate AWS SNS URL to prevent SSRF
			$subscribe_url = isset( $this->_data['SubscribeURL'] ) ? $this->_data['SubscribeURL'] : '';
			if ( ! empty( $subscribe_url ) && $this->is_valid_aws_sns_url( $subscribe_url ) ) {
				wp_remote_get( esc_url_raw( $subscribe_url ) );
			}
			wp_send_json( [
				'status'  => 200,
				'message' => 'success'
			], 200 );
		}

		if ( $notificationType === 'Complaint' ) {
			$complaint = isset( $this->_data['complaint'] ) && is_array( $this->_data['complaint'] ) ? $this->_data['complaint'] : [];
			if ( empty( $complaint ) || ! isset( $complaint['complainedRecipients'] ) || ! is_array( $complaint['complainedRecipients'] ) ) {
				return;
			}

			$feedback_type = isset( $complaint['complaintFeedbackType'] ) ? $complaint['complaintFeedbackType'] : '';

			/** In case of complaint marking contact bounced */
			foreach ( $complaint['complainedRecipients'] as $complainedRecipient ) {
				$email = $this->extractEmail( $complainedRecipient['emailAddress'] );
				$this->mark_contact_complaint( $email, [
					'notification_type' => 'Complaint',
					'feedback_type'     => $feedback_type,
					'subject'           => $subject,
					'message_id'        => $message_id,
				] );
			}

			return;
		}

		if ( $notificationType === 'Bounce' ) {
			$bounce = isset( $this->_data['bounce'] ) && is_array( $this->_data['bounce'] ) ? $this->_data['bounce'] : [];
			if ( ! isset( $bounce['bounceType'] ) ) {
				return;
			}

			$bounce_subtype = isset( $bounce['bounceSubType'] ) ? $bounce['bounceSubType'] : '';
			$bounce_type    = [ 'Undetermined', 'Permanent' ];
			if ( in_array( $bounce['bounceType'], apply_filters( 'bwfan_amazonses_bounce_type', $bounce_type ), true ) ) {
				foreach ( $bounce['bouncedRecipients'] as $bouncedRecipient ) {
					$email = $this->extractEmail( $bouncedRecipient['emailAddress'] );
					$this->mark_contact_bounce( $email, [
						'notification_type' => 'Bounce',
						'bounce_type'       => $bounce['bounceType'],
						'bounce_subtype'    => $bounce_subtype,
						'diagnostic'        => isset( $bouncedRecipient['diagnosticCode'] ) ? $bouncedRecipient['diagnosticCode'] : '',
						'subject'           => $subject,
						'message_id'        => $message_id,
					] );
				}

				return;
			}

			/**
			 * Sender-fault Transient subtypes describe a problem with the message
			 * (content blocked, attachment rejected, size limit), not the recipient's
			 * mailbox — the address is deliverable, so the contact's status must not
			 * change. Log the event on the contact and stop.
			 */
			$sender_fault_subtypes = apply_filters( 'bwfan_amazonses_sender_fault_subtypes', [ 'ContentRejected', 'AttachmentRejected', 'MessageTooLarge' ] );
			if ( is_array( $sender_fault_subtypes ) && in_array( $bounce_subtype, $sender_fault_subtypes, true ) ) {
				foreach ( $bounce['bouncedRecipients'] as $bouncedRecipient ) {
					$email   = $this->extractEmail( $bouncedRecipient['emailAddress'] );
					$contact = new BWFCRM_Contact( $email );
					$this->add_webhook_log_note( $contact, __( 'Bounce Ignored (Sender Fault)', 'wp-marketing-automations-pro' ), [
						'notification_type' => 'Bounce',
						'bounce_type'       => $bounce['bounceType'],
						'bounce_subtype'    => $bounce_subtype,
						'diagnostic'        => isset( $bouncedRecipient['diagnosticCode'] ) ? $bouncedRecipient['diagnosticCode'] : '',
						'subject'           => $subject,
						'message_id'        => $message_id,
					] );
				}

				return;
			}

			/** Soft bounce case */
			foreach ( $bounce['bouncedRecipients'] as $bouncedRecipient ) {
				$email = $this->extractEmail( $bouncedRecipient['emailAddress'] );
				$this->mark_contact_soft_bounce( $email, [
					'notification_type' => 'Bounce',
					'bounce_type'       => $bounce['bounceType'],
					'bounce_subtype'    => $bounce_subtype,
					'diagnostic'        => isset( $bouncedRecipient['diagnosticCode'] ) ? $bouncedRecipient['diagnosticCode'] : '',
					'subject'           => $subject,
					'message_id'        => $message_id,
				] );
			}
		}
	}

	private function extractEmail( $from_email ) {
		$bracket_pos = strpos( $from_email, '<' );
		if ( false !== $bracket_pos ) {
			$from_email = substr( $from_email, $bracket_pos + 1 );
			$from_email = str_replace( '>', '', $from_email );
			$from_email = trim( $from_email );
		}

		if ( is_email( $from_email ) ) {
			return $from_email;
		}

		return false;
	}

	/**
	 * Validate that a URL is a legitimate AWS SNS URL to prevent SSRF attacks
	 *
	 * @param string $url The URL to validate
	 * @return bool True if valid AWS SNS URL, false otherwise
	 */
	private function is_valid_aws_sns_url( $url ) {
		if ( empty( $url ) || ! is_string( $url ) ) {
			return false;
		}

		$parsed = wp_parse_url( $url );

		// wp_parse_url() returns false on malformed URLs
		if ( false === $parsed || ! is_array( $parsed ) ) {
			return false;
		}

		// Must be HTTPS
		if ( ! isset( $parsed['scheme'] ) || 'https' !== strtolower( $parsed['scheme'] ) ) {
			return false;
		}

		// Must be an AWS SNS domain
		if ( ! isset( $parsed['host'] ) || empty( $parsed['host'] ) ) {
			return false;
		}

		$host = strtolower( $parsed['host'] );

		// Valid AWS SNS domains: sns.{region}.amazonaws.com or sns.{region}.amazonaws.com.cn (China)
		// Region format: alphanumeric parts separated by hyphens (e.g., us-east-1, ap-southeast-2)
		if ( ! preg_match( '/^sns\.[a-z0-9]+(-[a-z0-9]+)*\.amazonaws\.com(\.cn)?$/', $host ) ) {
			return false;
		}

		return true;
	}
}

BWFCRM_Core()->email_webhooks->register( 'BWFCRM_Webhook_AmazonSES' );
