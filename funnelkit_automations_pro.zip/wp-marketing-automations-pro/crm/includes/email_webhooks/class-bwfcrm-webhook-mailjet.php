<?php

#[\AllowDynamicProperties]
class BWFCRM_Webhook_MailJet extends BWFCRM_Email_Webhook_Base {
	private static $ins = null;

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self;
		}

		return self::$ins;
	}

	public function __construct() {
		$this->_name = "Mailjet";
	}

	public function handle_webhook() {
		if ( ! is_array( $this->_data ) || empty( $this->_data ) ) {
			return;
		}

		$this->maybe_bounce_contact_email();
	}

	private function maybe_bounce_contact_email() {
		// Loop through the data if it's an array
		foreach ( $this->_data as $datum ) {
			// Ensure the necessary data is set and it's a valid email event
			if ( ! is_array( $datum ) || ! isset( $datum[0] ) || ! isset( $datum[0]['event'] ) || ! isset( $datum[0]['email'] ) || ! is_email( $datum[0]['email'] ) ) {
				continue;
			}

			$event = $datum[0]['event'];
			$email = $datum[0]['email'];

			/**
			 * Mailjet event names: `bounce` (carries a `hard_bounce` boolean), `blocked`, `spam`.
			 * There is no `soft_bounce`/`complaint` event - soft bounces are `bounce` with hard_bounce = false
			 * and complaints arrive as `spam`.
			 */
			$bounce_status = apply_filters( 'bwfan_mailjet_bounce_status', array( 'bounce', 'blocked', 'spam' ) );
			if ( ! in_array( $event, $bounce_status, true ) ) {
				continue;
			}
			$context = [
				'notification_type' => $event,
				'reason'            => isset( $datum[0]['error'] ) ? $datum[0]['error'] : ( isset( $datum[0]['comment'] ) ? $datum[0]['comment'] : '' ),
				'message_id'        => isset( $datum[0]['MessageID'] ) ? $datum[0]['MessageID'] : '',
				'custom_id'         => isset( $datum[0]['CustomID'] ) ? $datum[0]['CustomID'] : '',
			];

			switch ( strtolower( $event ) ) {
				case 'bounce':
					$is_hard_bounce = isset( $datum[0]['hard_bounce'] ) ? filter_var( $datum[0]['hard_bounce'], FILTER_VALIDATE_BOOLEAN ) : true;
					if ( $is_hard_bounce ) {
						$this->mark_contact_bounce( $email, $context );
					} else {
						$this->mark_contact_soft_bounce( $email, $context );
					}
					break;

				case 'blocked':
					$this->mark_contact_bounce( $email, $context );
					break;

				case 'spam':
					$this->mark_contact_complaint( $email, $context );
					break;
			}
		}
	}
}

BWFCRM_Core()->email_webhooks->register( 'BWFCRM_Webhook_MailJet' );
