<?php

/**
 * Elastic Email Bounce Handling Controller
 */
#[\AllowDynamicProperties]
class BWFCRM_Webhook_ElasticEmail extends BWFCRM_Email_Webhook_Base {
	private static $ins = null;

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self;
		}

		return self::$ins;
	}

	public function __construct() {
		$this->_name = "Elastic Email";
	}

	/**
	 * Email Bounce Service Handler
	 *
	 * @return void
	 */
	public function handle_webhook() {
		if ( ! is_array( $this->_data ) || empty( $this->_data ) ) {
			return;
		}

		$this->maybe_bounce_contact_email();
	}

	/**
	 * Mark contact bounced
	 *
	 * @return void
	 */
	private function maybe_bounce_contact_email() {
		if ( ! is_array( $this->_data ) || ! isset( $this->_data['status'] ) || ! is_email( $this->_data['to'] ) ) {
			return;
		}
		/**
		 * Elastic Email notification `status` values: `Error` (bounce) and `AbuseReport` (complaint).
		 * There is no `bounce_type` field - hard vs soft is derived from the `category` value below.
		 */
		$valid_statuses = apply_filters( 'bwfan_elasticemail_bounce_statuses', array( 'error', 'abusereport', 'complaint' ) );

		$status = strtolower( $this->_data['status'] );

		if ( ! in_array( $status, $valid_statuses, true ) ) {
			return;
		}
		$category   = isset( $this->_data['category'] ) ? $this->_data['category'] : '';
		$reason     = isset( $this->_data['message'] ) ? $this->_data['message'] : $category;
		$subject    = isset( $this->_data['subject'] ) ? $this->_data['subject'] : '';
		$message_id = isset( $this->_data['messageid'] ) ? $this->_data['messageid'] : ( isset( $this->_data['transaction'] ) ? $this->_data['transaction'] : '' );

		if ( 'abusereport' === $status || 'complaint' === $status ) {
			$this->mark_contact_complaint( $this->_data['to'], [
				'notification_type' => $this->_data['status'],
				'reason'            => $reason,
				'category'          => $category,
				'subject'           => $subject,
				'message_id'        => $message_id,
			] );

			return;
		}

		/** status === 'error' -> bounce. Classify hard vs soft from the permanent-failure categories. */
		$hard_categories = apply_filters( 'bwfan_elasticemail_hard_bounce_categories', array( 'NoMailbox', 'BlackListed', 'DNSProblem', 'SPFProblem', 'NotDelivered' ) );
		$is_hard_bounce  = in_array( strtolower( $category ), array_map( 'strtolower', $hard_categories ), true );

		$context = [
			'notification_type' => $this->_data['status'],
			'bounce_type'       => $is_hard_bounce ? 'hard' : 'soft',
			'category'          => $category,
			'reason'            => $reason,
			'subject'           => $subject,
			'message_id'        => $message_id,
		];

		if ( $is_hard_bounce ) {
			$this->mark_contact_bounce( $this->_data['to'], $context );
		} else {
			$this->mark_contact_soft_bounce( $this->_data['to'], $context );
		}
	}
}

BWFCRM_Core()->email_webhooks->register( 'BWFCRM_Webhook_ElasticEmail' );
