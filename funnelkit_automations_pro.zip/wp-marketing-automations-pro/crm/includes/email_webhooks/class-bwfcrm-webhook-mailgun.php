<?php

#[\AllowDynamicProperties]
class BWFCRM_Webhook_Mailgun extends BWFCRM_Email_Webhook_Base {
	private static $ins = null;

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self;
		}

		return self::$ins;
	}

	public function __construct() {
		$this->_name = "Mailgun";
	}

	public function handle_webhook() {
		if ( ! is_array( $this->_data ) || empty( $this->_data ) ) {
			return;
		}

		$this->maybe_bounce_contact_email();
	}

	private function maybe_bounce_contact_email() {
		foreach ( $this->_data as $key => $datum ) {
			if ( 'event-data' !== $key ) {
				continue;
			}
			$valid_bounce_statuses = apply_filters( 'bwfan_mailgun_bounce_status', array( 'bounced', 'failed', 'complained', 'unsubscribed' ) );
			if ( ! is_array( $datum ) || ! isset( $datum['event'] ) || ! in_array( $datum['event'], $valid_bounce_statuses, true ) || ! isset( $datum['recipient'] ) || ! is_email( $datum['recipient'] ) ) {
				continue;
			}

			$event_type = strtolower( $datum['event'] );
			$reason     = isset( $datum['reason'] ) ? $datum['reason'] : ( isset( $datum['delivery-status']['message'] ) ? $datum['delivery-status']['message'] : '' );
			$headers    = isset( $datum['message']['headers'] ) && is_array( $datum['message']['headers'] ) ? $datum['message']['headers'] : [];
			$context    = [
				'notification_type' => $datum['event'],
				'severity'          => isset( $datum['severity'] ) ? $datum['severity'] : '',
				'reason'            => $reason,
				'subject'           => isset( $headers['subject'] ) ? $headers['subject'] : '',
				'message_id'        => isset( $headers['message-id'] ) ? $headers['message-id'] : '',
			];

			switch ( $event_type ) {
				case 'bounced':
				case 'failed':
					/**
					 * Mailgun sends severity `temporary` for soft/transient failures and `permanent`
					 * for hard bounces. Treat a temporary `failed` event as a soft bounce so a transient
					 * delivery issue does not permanently mark the contact as bounced.
					 */
					if ( 'failed' === $event_type && 'temporary' === strtolower( (string) $context['severity'] ) ) {
						$this->mark_contact_soft_bounce( $datum['recipient'], $context );
					} else {
						$this->mark_contact_bounce( $datum['recipient'], $context );
					}
					break;

				case 'complained':
					$this->mark_contact_complaint( $datum['recipient'], $context );
					break;
			}
		}
	}
}

BWFCRM_Core()->email_webhooks->register( 'BWFCRM_Webhook_Mailgun' );
