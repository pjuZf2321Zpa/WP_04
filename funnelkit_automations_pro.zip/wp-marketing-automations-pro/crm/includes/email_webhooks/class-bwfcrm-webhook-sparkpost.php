<?php

#[\AllowDynamicProperties]
class BWFCRM_Webhook_Sparkpost extends BWFCRM_Email_Webhook_Base {
	private static $ins = null;

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self;
		}

		return self::$ins;
	}

	public function __construct() {
		$this->_name = "Sparkpost";
	}

	public function handle_webhook() {
		if ( ! is_array( $this->_data ) || empty( $this->_data ) ) {
			return;
		}

		$this->maybe_bounce_contact_email();
	}

	private function maybe_bounce_contact_email() {
		foreach ( $this->_data as $datum ) {
			if ( ! is_array( $datum ) || ! isset( $datum['msys']['message_event']['type'] ) || 'bounce' !== $datum['msys']['message_event']['type'] || ! isset( $datum['msys']['message_event']['rcpt_to'] ) || ! is_email( $datum['msys']['message_event']['rcpt_to'] ) ) {
				continue;
			}

			$message_event = $datum['msys']['message_event'];
			$context       = [
				'notification_type' => isset( $message_event['type'] ) ? $message_event['type'] : '',
				'bounce_class'      => isset( $message_event['bounce_class'] ) ? $message_event['bounce_class'] : '',
				'reason'            => isset( $message_event['reason'] ) ? $message_event['reason'] : '',
				'subject'           => isset( $message_event['subject'] ) ? $message_event['subject'] : '',
				'message_id'        => isset( $message_event['message_id'] ) ? $message_event['message_id'] : '',
				'transmission_id'   => isset( $message_event['transmission_id'] ) ? $message_event['transmission_id'] : '',
				'campaign_id'       => isset( $message_event['campaign_id'] ) ? $message_event['campaign_id'] : '',
			];

			/**
			 * Only definitive (hard) bounce classes mark the contact bounced. Every other class is a
			 * soft/transient failure and is recorded as a soft bounce so it does not permanently remove
			 * the contact. Hard classes: 10 Invalid Recipient, 25 Admin Failure, 30 Generic (No RCPT), 90 Unsubscribe.
			 */
			$hard_bounce_classes = apply_filters( 'bwfan_sparkpost_hard_bounce_classes', array( 10, 25, 30, 90 ) );
			$bounce_class        = (int) ( isset( $message_event['bounce_class'] ) ? $message_event['bounce_class'] : 0 );

			if ( in_array( $bounce_class, $hard_bounce_classes, true ) ) {
				$this->mark_contact_bounce( $message_event['rcpt_to'], $context );
			} else {
				$this->mark_contact_soft_bounce( $message_event['rcpt_to'], $context );
			}
			break;
		}
	}
}

BWFCRM_Core()->email_webhooks->register( 'BWFCRM_Webhook_Sparkpost' );
