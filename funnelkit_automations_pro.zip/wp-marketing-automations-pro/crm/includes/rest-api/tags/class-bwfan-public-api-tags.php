<?php

namespace BWFAN\Rest_API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Get_All_Tags
 */
class Get_All_Tags extends \BWFAN_Rest_API_Base {
	public static $ins;

	public function __construct() {
		parent::__construct();
		$this->method = \WP_REST_Server::READABLE;
		$this->route  = '/tags';
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	public function process_api_call() {
		$limit  = ! empty( $this->args['limit'] ) ? absint( $this->args['limit'] ) : 30;
		$offset = ! empty( $this->args['offset'] ) ? absint( $this->args['offset'] ) : 0;

		$tags = \BWFCRM_Tag::get_tags( array(), '', $offset, $limit );

		if ( is_wp_error( $tags ) ) {
			$this->error_response( null, 422, 'unknown_error' );
		}

		if ( empty( $tags ) ) {
			$this->error_response( null, 404, 'data_not_found' );
		}

		if ( is_array( $tags ) ) {
			$tags = array_map( function ( $tag ) {
				return array( 'ID' => $tag['ID'], 'name' => $tag['name'] );
			}, $tags );
		}

		return $this->success_response( [ 'tags' => $tags ], __( 'Tag(s) Listed successfully', 'wp-marketing-automations-pro' ) );
	}
}

\BWFAN_Rest_API_Loader::register( 'BWFAN\Rest_API\Get_All_Tags' );

/**
 * Class Add_Tags
 */
class Add_Tags extends \BWFAN_Rest_API_Base {
	public static $ins;

	public function __construct() {
		parent::__construct();
		$this->method   = \WP_REST_Server::CREATABLE;
		$this->route    = '/tag/add';
		$this->required = [ 'tags' ];
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	public function process_api_call() {
		$tags = isset( $this->args['tags'] ) ? $this->args['tags'] : array();

		$tag_data = array();
		if ( is_array( $tags ) ) {
			$tag_data = array_map( function ( $tag ) {
				return array( 'id' => 0, 'value' => $tag );
			}, $tags );
		} else {
			$tag_data['id']    = 0;
			$tag_data['value'] = $tags;
			$tag_data          = array( $tag_data );
		}

		$tags = \BWFCRM_Term::get_or_create_terms( $tag_data, \BWFCRM_Term_Type::$TAG, true, true );

		if ( is_wp_error( $tags ) ) {
			$this->error_response( null, 422, 'unknown_error' );
		}

		if ( ! isset( $tags['existing'] ) || ! isset( $tags['created'] ) ) {
			$this->error_response( null, 422, 'unknown_error' );
		}

		$created_tags = \BWFCRM_Term::get_collection_array( $tags['created'] );

		if ( empty( $created_tags ) ) {
			$this->error_response( null, 422, 'already_exists' );
		}

		return $this->success_response( [ 'tags' => $created_tags ], __( 'Tag(s) created successfully', 'wp-marketing-automations-pro' ) );
	}
}

\BWFAN_Rest_API_Loader::register( 'BWFAN\Rest_API\Add_Tags' );

/**
 * Class Update_Tags
 */
class Update_Tags extends \BWFAN_Rest_API_Base {
	public static $ins;

	public function __construct() {
		parent::__construct();
		$this->method   = \WP_REST_Server::EDITABLE;
		$this->route    = '/tag/update/(?P<id>[\\d]+)';
		$this->required = [ 'id', 'tag' ];
		$this->validate = [ 'tag_not_exists' ];
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	/**
	 * @param \BWFCRM_Tag $tag
	 */
	public function process_api_call( $tag = '' ) {
		$tag_id   = $this->get_sanitized_arg( 'id', 'text_field' );
		$tag_name = $this->get_sanitized_arg( 'tag', 'text_field' );

		$current_name = $tag->get_name();
		if ( $tag_name === $current_name ) {
			$updated_tag = [ 'ID' => $tag_id, 'name' => $tag_name ];

			return $this->success_response( [ 'tags' => $updated_tag ], __( 'Tag updated successfully', 'wp-marketing-automations-pro' ) );
		}

		$already_exists = \BWFCRM_Tag::get_terms( \BWFCRM_Term_Type::$TAG, [], $tag_name, 0, 0, ARRAY_A, 'exact' );
		if ( ! empty( $already_exists ) ) {
			$this->error_response( __( 'Tag already exists with name: ' . $tag_name, 'wp-marketing-automations-pro' ), 422, 'unknown_error' );
		}

		$tag->set_name( $tag_name );
		$update_tag = $tag->save();

		if ( empty( $update_tag ) ) {
			$this->error_response( null, 422, 'unknown_error' );
		}

		$updated_tag = [ 'ID' => $tag_id, 'name' => $tag->get_name() ];

		return $this->success_response( [ 'tags' => $updated_tag ], __( 'Tag updated successfully', 'wp-marketing-automations-pro' ) );
	}
}

\BWFAN_Rest_API_Loader::register( 'BWFAN\Rest_API\Update_Tags' );

/**
 * Class Delete_Tags
 */
class Delete_Tags extends \BWFAN_Rest_API_Base {
	public static $ins;

	public function __construct() {
		parent::__construct();
		$this->method   = \WP_REST_Server::DELETABLE;
		$this->route    = '/tag/(?P<id>[\\d]+)';
		$this->required = [ 'id' ];
		$this->validate = [ 'tag_not_exists' ];
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	/**
	 * @param \BWFCRM_Tag $tag
	 */
	public function process_api_call( $tag = '' ) {
		$tag_id = $this->get_sanitized_arg( 'id', 'text_field' );

		$deleted_tag = [ 'ID' => $tag_id, 'name' => $tag->get_name() ];

		$delete_tag = \BWFCRM_Tag::delete_tag( absint( $tag_id ) );

		if ( false === $delete_tag ) {
			$this->error_response( null, 422, 'unknown_error' );
		}

		return $this->success_response( [ 'tags' => $deleted_tag ], __( 'Tag deleted successfully', 'wp-marketing-automations-pro' ) );
	}
}

\BWFAN_Rest_API_Loader::register( 'BWFAN\Rest_API\Delete_Tags' );
