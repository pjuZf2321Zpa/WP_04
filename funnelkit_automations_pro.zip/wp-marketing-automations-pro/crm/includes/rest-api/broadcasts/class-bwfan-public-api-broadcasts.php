<?php

namespace BWFAN\Rest_API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BWFAN_Rest_API_Get_Broadcasts
 *
 * Lists broadcasts with pagination and optional filtering by status and type.
 */

class Get_Broadcasts extends \BWFAN_Rest_API_Base {
	public static $ins;

	public function __construct() {
		parent::__construct();
		$this->method = \WP_REST_Server::READABLE;
		$this->route  = '/broadcasts';
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	public function process_api_call() {
		$limit  = ! empty( $this->args['limit'] ) ? absint( $this->args['limit'] ) : 25;
		$offset = ! empty( $this->args['offset'] ) ? absint( $this->args['offset'] ) : 0;
		$search = isset( $this->args['search'] ) ? sanitize_text_field( $this->args['search'] ) : '';
		$status = isset( $this->args['status'] ) ? sanitize_text_field( $this->args['status'] ) : 'all';
		$type   = isset( $this->args['type'] ) ? sanitize_text_field( $this->args['type'] ) : '';
		$order  = isset( $this->args['order'] ) ? strtoupper( sanitize_text_field( $this->args['order'] ) ) : 'DESC';

		if ( ! in_array( $order, array( 'ASC', 'DESC' ), true ) ) {
			$order = 'DESC';
		}

		$allowed_statuses = array( 'all', 'scheduled', 'ongoing', 'completed', 'paused', 'cancelled' );
		if ( ! in_array( $status, $allowed_statuses, true ) ) {
			$status = 'all';
		}

		$result = \BWFAN_Model_Broadcast::get_campaigns( $search, $limit, $offset, $order, $type, $status );

		if ( empty( $result ) || ! isset( $result['data']['campaigns'] ) ) {
			return $this->success_response( array( 'broadcasts' => array(), 'total' => 0 ), __( 'No broadcasts found', 'wp-marketing-automations-pro' ) );
		}

		$campaigns  = $result['data']['campaigns'];
		$total      = isset( $result['total'] ) ? absint( $result['total'] ) : 0;
		$broadcasts = array();

		foreach ( $campaigns as $campaign ) {
			$broadcast = array(
				'id'             => isset( $campaign['id'] ) ? absint( $campaign['id'] ) : 0,
				'title'          => isset( $campaign['title'] ) ? $campaign['title'] : '',
				'type'           => isset( $campaign['type'] ) ? absint( $campaign['type'] ) : 0,
				'status'         => isset( $campaign['status'] ) ? absint( $campaign['status'] ) : 0,
				'count'          => isset( $campaign['count'] ) ? absint( $campaign['count'] ) : 0,
				'execution_time' => isset( $campaign['execution_time'] ) ? $campaign['execution_time'] : '',
				'created_at'     => isset( $campaign['created_at'] ) ? $campaign['created_at'] : '',
				'category'       => isset( $campaign['category'] ) ? $campaign['category'] : array(),
			);

			if ( isset( $campaign['children'] ) && is_array( $campaign['children'] ) ) {
				$broadcast['children'] = array_map( function ( $child ) {
					return array(
						'id'             => isset( $child['id'] ) ? absint( $child['id'] ) : 0,
						'title'          => isset( $child['title'] ) ? $child['title'] : '',
						'type'           => isset( $child['type'] ) ? absint( $child['type'] ) : 0,
						'status'         => isset( $child['status'] ) ? absint( $child['status'] ) : 0,
						'count'          => isset( $child['count'] ) ? absint( $child['count'] ) : 0,
						'execution_time' => isset( $child['execution_time'] ) ? $child['execution_time'] : '',
						'created_at'     => isset( $child['created_at'] ) ? $child['created_at'] : '',
					);
				}, $campaign['children'] );
			}

			$broadcasts[] = $broadcast;
		}

		return $this->success_response( array( 'broadcasts' => $broadcasts, 'total' => $total ), __( 'Broadcast(s) listed successfully', 'wp-marketing-automations-pro' ) );
	}

	public function get_result_total_count() {
		return 0;
	}
}

\BWFAN_Rest_API_Loader::register( 'BWFAN\Rest_API\Get_Broadcasts' );

/**
 * Class BWFAN_Rest_API_Get_Broadcast
 *
 * Retrieves a single broadcast by ID with full metadata.
 */

class Get_Broadcast extends \BWFAN_Rest_API_Base {
	public static $ins;

	public function __construct() {
		parent::__construct();
		$this->method       = \WP_REST_Server::READABLE;
		$this->route        = '/broadcasts/(?P<id>[\d]+)';
		$this->request_args = array(
			'id' => array(
				'description' => __( 'Broadcast ID to retrieve', 'wp-marketing-automations-pro' ),
				'type'        => 'integer',
			),
		);
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	public function default_args_values() {
		return array(
			'id' => 0,
		);
	}

	public function process_api_call() {
		$broadcast_id = absint( $this->get_sanitized_arg( 'id', 'key' ) );
		if ( empty( $broadcast_id ) ) {
			return $this->error_response( __( 'Broadcast ID is required', 'wp-marketing-automations-pro' ), 400, 'missing_broadcast_id' );
		}

		$result = \BWFAN_Model_Broadcast::get_campaign( $broadcast_id );

		if ( empty( $result ) || ! isset( $result['status'] ) || 200 !== absint( $result['status'] ) ) {
			return $this->error_response( __( 'Broadcast not found', 'wp-marketing-automations-pro' ), 404, 'data_not_found' );
		}

		$campaign = $result['data'];

		$broadcast = array(
			'id'             => isset( $campaign['id'] ) ? absint( $campaign['id'] ) : 0,
			'title'          => isset( $campaign['title'] ) ? $campaign['title'] : '',
			'description'    => isset( $campaign['description'] ) ? $campaign['description'] : '',
			'type'           => isset( $campaign['type'] ) ? absint( $campaign['type'] ) : 0,
			'status'         => isset( $campaign['status'] ) ? absint( $campaign['status'] ) : 0,
			'count'          => isset( $campaign['count'] ) ? absint( $campaign['count'] ) : 0,
			'processed'      => isset( $campaign['processed'] ) ? absint( $campaign['processed'] ) : 0,
			'execution_time' => isset( $campaign['execution_time'] ) ? $campaign['execution_time'] : '',
			'created_at'     => isset( $campaign['created_at'] ) ? $campaign['created_at'] : '',
			'open_count'     => isset( $campaign['open_count'] ) ? absint( $campaign['open_count'] ) : 0,
			'open_rate'      => isset( $campaign['open_rate'] ) ? floatval( $campaign['open_rate'] ) : 0,
			'click_count'    => isset( $campaign['click_count'] ) ? absint( $campaign['click_count'] ) : 0,
			'click_rate'     => isset( $campaign['click_rate'] ) ? floatval( $campaign['click_rate'] ) : 0,
			'sent'           => isset( $campaign['sent'] ) ? absint( $campaign['sent'] ) : 0,
			'revenue'        => isset( $campaign['revenue'] ) ? floatval( $campaign['revenue'] ) : 0,
			'conversions'    => isset( $campaign['conversions'] ) ? absint( $campaign['conversions'] ) : 0,
			'unsubs'         => isset( $campaign['unsubs'] ) ? absint( $campaign['unsubs'] ) : 0,
			'subject'        => isset( $campaign['subject'] ) ? $campaign['subject'] : '',
			'parent'         => isset( $campaign['parent'] ) ? absint( $campaign['parent'] ) : 0,
			'category'       => isset( $campaign['category'] ) ? $campaign['category'] : array(),
		);

		$child_ids = \BWFAN_Model_Broadcast::get_broadcast_child( $broadcast_id, true );
		if ( ! empty( $child_ids ) ) {
			$children              = \BWFAN_Model_Broadcast::get_broadcast_child( $broadcast_id );
			$broadcast['children'] = array();
			if ( ! empty( $children ) && is_array( $children ) ) {
				foreach ( $children as $child ) {
					$broadcast['children'][] = array(
						'id'             => isset( $child['id'] ) ? absint( $child['id'] ) : 0,
						'title'          => isset( $child['title'] ) ? $child['title'] : '',
						'type'           => isset( $child['type'] ) ? absint( $child['type'] ) : 0,
						'status'         => isset( $child['status'] ) ? absint( $child['status'] ) : 0,
						'count'          => isset( $child['count'] ) ? absint( $child['count'] ) : 0,
						'execution_time' => isset( $child['execution_time'] ) ? $child['execution_time'] : '',
						'created_at'     => isset( $child['created_at'] ) ? $child['created_at'] : '',
						'open_rate'      => isset( $child['open_rate'] ) ? floatval( $child['open_rate'] ) : 0,
						'click_rate'     => isset( $child['click_rate'] ) ? floatval( $child['click_rate'] ) : 0,
						'sent'           => isset( $child['sent'] ) ? absint( $child['sent'] ) : 0,
						'revenue'        => isset( $child['revenue'] ) ? floatval( $child['revenue'] ) : 0,
						'conversions'    => isset( $child['conversions'] ) ? absint( $child['conversions'] ) : 0,
					);
				}
			}
		}

		return $this->success_response( array( 'broadcast' => $broadcast ), __( 'Broadcast retrieved successfully', 'wp-marketing-automations-pro' ) );
	}
}

\BWFAN_Rest_API_Loader::register( 'BWFAN\Rest_API\Get_Broadcast' );

/**
 * Class BWFAN_Rest_API_Get_Broadcast_Stats
 *
 * Retrieves stats for a single broadcast: sent, opened, clicked, unsubscribed, revenue, rates.
 */

class Get_Broadcast_Stats extends \BWFAN_Rest_API_Base {
	public static $ins;

	public function __construct() {
		parent::__construct();
		$this->method       = \WP_REST_Server::READABLE;
		$this->route        = '/broadcasts/(?P<id>[\d]+)/stats';
		$this->request_args = array(
			'id' => array(
				'description' => __( 'Broadcast ID to retrieve stats for', 'wp-marketing-automations-pro' ),
				'type'        => 'integer',
			),
		);
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	public function default_args_values() {
		return array(
			'id' => 0,
		);
	}

	public function process_api_call() {
		$broadcast_id = absint( $this->get_sanitized_arg( 'id', 'key' ) );
		if ( empty( $broadcast_id ) ) {
			return $this->error_response( __( 'Broadcast ID is required', 'wp-marketing-automations-pro' ), 400, 'missing_broadcast_id' );
		}

		$broadcast = \BWFAN_Model_Broadcast::get( $broadcast_id );
		if ( empty( $broadcast ) || ! is_array( $broadcast ) || ! isset( $broadcast['id'] ) ) {
			return $this->error_response( __( 'Broadcast not found', 'wp-marketing-automations-pro' ), 404, 'data_not_found' );
		}

		$stats         = \BWFAN_Model_Broadcast::get_broadcast_basic_stats( $broadcast_id );
		$formatted_ids = array( array( 'id' => $broadcast_id ) );
		$conversions   = \BWFAN_Model_Broadcast::include_conversion_into_campaigns( $formatted_ids, true );

		$conversion_count = 0;
		$revenue          = 0;
		if ( ! empty( $conversions ) && is_array( $conversions ) ) {
			foreach ( $conversions as $conversion ) {
				if ( isset( $conversion['oid'] ) && absint( $conversion['oid'] ) === $broadcast_id ) {
					$conversion_count = isset( $conversion['conversions'] ) ? absint( $conversion['conversions'] ) : 0;
					$revenue          = isset( $conversion['revenue'] ) ? floatval( $conversion['revenue'] ) : 0;
					break;
				}
			}
		}

		$unsubscribed = \BWFAN_Model_Broadcast::get_campaign_unsubscribers( $broadcast_id );

		$response = array(
			'id'           => $broadcast_id,
			'status'       => isset( $stats['status'] ) ? absint( $stats['status'] ) : 0,
			'count'        => isset( $stats['count'] ) ? absint( $stats['count'] ) : 0,
			'sent'         => isset( $stats['sent'] ) ? absint( $stats['sent'] ) : 0,
			'open_count'   => isset( $stats['open_count'] ) ? absint( $stats['open_count'] ) : 0,
			'open_rate'    => isset( $stats['open_rate'] ) ? floatval( number_format( floatval( $stats['open_rate'] ), 2 ) ) : 0,
			'click_count'  => isset( $stats['click_count'] ) ? absint( $stats['click_count'] ) : 0,
			'click_rate'   => isset( $stats['click_rate'] ) ? floatval( number_format( floatval( $stats['click_rate'] ), 2 ) ) : 0,
			'unsubscribed' => absint( $unsubscribed ),
			'conversions'  => $conversion_count,
			'revenue'      => $revenue,
		);

		return $this->success_response( array( 'stats' => $response ), __( 'Broadcast stats retrieved successfully', 'wp-marketing-automations-pro' ) );
	}
}

\BWFAN_Rest_API_Loader::register( 'BWFAN\Rest_API\Get_Broadcast_Stats' );
