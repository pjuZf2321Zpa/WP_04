<?php

namespace BWFAN\Rest_API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Get_All_Fields
 */
class Get_All_Fields extends \BWFAN_Rest_API_Base {
	public static $ins;

	public function __construct() {
		parent::__construct();
		$this->method = \WP_REST_Server::READABLE;
		$this->route  = '/fields';
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	public function process_api_call() {
		$type = ! empty( $this->args['type'] ) ? $this->args['type'] : null;

		$fields = \BWFCRM_Fields::get_custom_fields( '', 1, null, false, null, $type );

		if ( empty( $fields ) ) {
			$this->error_response( null, 404, 'data_not_found' );
		}

		return $this->success_response( array( 'fields' => $fields ), __( 'Fields listed successfully', 'wp-marketing-automations-pro' ) );
	}
}

\BWFAN_Rest_API_Loader::register( 'BWFAN\Rest_API\Get_All_Fields' );

/**
 * Class Add_Field
 */
class Add_Field extends \BWFAN_Rest_API_Base {
	public static $ins;

	public function __construct() {
		parent::__construct();
		$this->method   = \WP_REST_Server::CREATABLE;
		$this->route    = '/field/add';
		$this->required = [ 'field_name', 'type' ];
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	public function process_api_call() {
		$field_name = $this->get_sanitized_arg( 'field_name', 'text_field' );
		$type       = $this->get_sanitized_arg( 'type', 'text_field' );
		$group_id   = $this->get_sanitized_arg( 'group_id', 'text_field' );
		$mode       = isset( $this->args['mode'] ) ? absint( $this->args['mode'] ) : 1;
		$vmode      = isset( $this->args['vmode'] ) ? absint( $this->args['vmode'] ) : 1;
		$search     = isset( $this->args['search'] ) ? absint( $this->args['search'] ) : 1;

		$group_id = ! empty( $group_id ) && is_numeric( $group_id ) ? $group_id : 0;
		$group    = \BWFCRM_Group::get_groupby_id( $group_id );
		if ( $group_id > 0 && empty( $group ) ) {
			$this->error_response( null, 422, 'unprocessable_entity' );
		}

		$options     = isset( $this->args['options'] ) && ! empty( $this->args['options'] ) && is_array( $this->args['options'] ) ? $this->args['options'] : [];
		$placeholder = isset( $this->args['placeholder'] ) ? $this->args['placeholder'] : '';

		$field = \BWFCRM_Fields::add_field( $field_name, $type, $options, $placeholder, $mode, $vmode, $search, $group_id );

		if ( is_wp_error( $field ) ) {
			$this->error_response( '', 422, 'already_exists' );
		}

		if ( empty( $field ) ) {
			$this->error_response( '', 422, 'unknown_error' );
		}

		return $this->success_response( array( 'fields' => $field ), __( 'Field created successfully', 'wp-marketing-automations-pro' ) );
	}
}

\BWFAN_Rest_API_Loader::register( 'BWFAN\Rest_API\Add_Field' );

/**
 * Class Update_Field
 */
class Update_Field extends \BWFAN_Rest_API_Base {
	public static $ins;

	public function __construct() {
		parent::__construct();
		$this->method   = \WP_REST_Server::EDITABLE;
		$this->route    = '/field/update/(?P<id>[\\d]+)';
		$this->required = [ 'id', 'slug' ];
		$this->validate = [ 'field_not_exists' ];
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	public function process_api_call() {
		$field_id    = $this->get_sanitized_arg( 'id', 'text_field' );
		$field_name  = $this->get_sanitized_arg( 'field_name', 'text_field' );
		$type        = $this->get_sanitized_arg( 'type', 'text_field' );
		$slug        = $this->get_sanitized_arg( 'slug', 'text_field' );
		$options     = isset( $this->args['options'] ) ? $this->args['options'] : array();
		$placeholder = $this->get_sanitized_arg( 'placeholder', 'text_field' );
		$mode        = $this->get_sanitized_arg( 'mode', 'text_field' );
		$vmode       = $this->get_sanitized_arg( 'vmode', 'text_field' );
		$search      = $this->get_sanitized_arg( 'search', 'text_field' );
		$group_id    = $this->get_sanitized_arg( 'group_id', 'text_field' );
		$group_id    = ! empty( $group_id ) && is_numeric( $group_id ) ? $group_id : false;

		$group = \BWFCRM_Group::get_groupby_id( $group_id );
		if ( false !== $group_id && $group_id > 0 && empty( $group ) ) {
			$this->error_response( null, 422, 'unprocessable_entity' );
		}

		$update_field = \BWFCRM_Fields::update_field( $field_id, $group_id, $field_name, $type, $options, $placeholder, $slug, $mode, $vmode, $search );

		if ( $update_field['status'] === 404 ) {
			$this->error_response( null, 422, 'already_exists' );
		}

		$updated_field = \BWFAN_Model_Fields::get_field_by_id( $field_id );
		if ( empty( $updated_field ) || ! isset( $updated_field['name'] ) ) {
			$this->error_response( null, 422, 'unknown_error' );
		}

		$field = [
			'ID'   => $field_id,
			'name' => $updated_field['name'],
		];

		return $this->success_response( [ 'fields' => $field ], __( 'Field updated successfully', 'wp-marketing-automations-pro' ) );
	}
}

\BWFAN_Rest_API_Loader::register( 'BWFAN\Rest_API\Update_Field' );

/**
 * Class Delete_Field
 */
class Delete_Field extends \BWFAN_Rest_API_Base {
	public static $ins;

	public function __construct() {
		parent::__construct();
		$this->method   = \WP_REST_Server::DELETABLE;
		$this->route    = '/field/(?P<id>[\\d]+)';
		$this->required = [ 'id' ];
		$this->validate = [ 'field_not_exists' ];
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	public function process_api_call() {
		$field_id = $this->get_sanitized_arg( 'id', 'text_field' );

		$deleting_field = \BWFAN_Model_Fields::get_field_by_id( $field_id );

		$delete_field = \BWFCRM_Fields::delete_field( absint( $field_id ) );

		if ( false === $delete_field ) {
			$this->error_response( '', 422, 'unknown_error' );
		}

		$field = [
			'ID'   => $field_id,
			'name' => $deleting_field['name'],
		];

		return $this->success_response( [ 'fields' => $field ], __( 'Field deleted successfully', 'wp-marketing-automations-pro' ) );
	}
}

\BWFAN_Rest_API_Loader::register( 'BWFAN\Rest_API\Delete_Field' );
