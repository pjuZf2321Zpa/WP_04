<?php

namespace BWFAN\Rest_API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Get_Contacts
 */
class Get_Contacts extends \BWFAN_Rest_API_Base {
	public static $ins;

	public function __construct() {
		parent::__construct();
		$this->method = \WP_REST_Server::READABLE;
		$this->route  = '/contacts';

		add_filter( 'bwfan_contact_sql_final_where_query', [ $this, 'bwfan_public_api_contact_where_sql' ], 10, 1 );
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	public function process_api_call() {
		$email      = $this->get_sanitized_arg( 'email', 'email' );
		$limit      = isset( $this->args['limit'] ) ? absint( $this->args['limit'] ) : 30;
		$offset     = isset( $this->args['offset'] ) ? absint( $this->args['offset'] ) : 0;
		$sort_order = isset( $this->args['sort_order'] ) ? $this->args['sort_order'] : 'DESC';
		$sort_field = isset( $this->args['sort_field'] ) ? $this->args['sort_field'] : 'creation_date';
		$status     = isset( $this->args['status'] ) ? $this->args['status'] : '';

		$filters = array();
		if ( ! empty( $status ) || '0' === (string) $status ) {
			$statuses  = $this->get_contact_statuses();
			$status    = is_string( $status ) ? strtolower( $status ) : $status;
			$status_id = null;

			if ( isset( $statuses[ $status ] ) ) {
				// Label provided (e.g. "subscribed").
				$status_id = $statuses[ $status ];
			} elseif ( is_numeric( $status ) && in_array( (int) $status, $statuses, true ) ) {
				// Numeric id provided (0–5), kept for back-compat.
				$status_id = (int) $status;
			}

			if ( is_null( $status_id ) ) {
				$this->error_response( sprintf( __( 'Invalid status. Allowed values are: %s', 'wp-marketing-automations-pro' ), implode( ', ', array_keys( $statuses ) ) ), 422, 'invalid_status' );
			}

			$filters['c'][] = array(
				'key'   => 'status',
				'rule'  => 'is',
				'type'  => \BWFCRM_Filters::$TYPE_NUMBER_EXACT,
				'value' => $status_id,
			);
		}

		$additional_info = array( 'order_by' => $sort_field, 'order' => $sort_order, 'grab_totals' => true );
		$contact_data    = \BWFCRM_Model_Contact::get_contacts( $email, $limit, $offset, $filters, $additional_info );

		if ( empty( $contact_data ) ) {
			$this->error_response( '', 422, 'data_not_found' );
		}

		$unsubscribed = self::get_unsubscribed_contacts( $contact_data );

		if ( ! empty( $unsubscribed ) ) {
			$processed_contacts = array_map( function ( $contact ) use ( $unsubscribed ) {
				$email      = $contact['email'] ?? '';
				$contact_no = $contact['contact_no'] ?? '';

				if ( in_array( $email, $unsubscribed, true ) || in_array( $contact_no, $unsubscribed, true ) ) {
					/** String, like every other row: get_contacts() reads with ARRAY_A, so the column arrives as one. */
					$contact['status'] = '3';
				}

				return $contact;
			}, $contact_data['contacts'] );

			$contact_data['contacts'] = $processed_contacts;
		}

		return $this->success_response( [ 'contact' => $contact_data ], __( 'Contact(s) listed successfully', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * @param string $filter_where
	 * @return string
	 */
	public function bwfan_public_api_contact_where_sql( $filter_where ) {
		global $wpdb;
		$from         = ( ! empty( $this->args['from'] ) && false !== strtotime( $this->args['from'] ) ) ? date( 'Y-m-d', strtotime( $this->args['from'] ) ) : '';
		$to           = ( ! empty( $this->args['to'] ) && false !== strtotime( $this->args['to'] ) ) ? date( 'Y-m-d', strtotime( $this->args['to'] ) ) : '';
		$updated_from = ( ! empty( $this->args['updated_from'] ) && false !== strtotime( $this->args['updated_from'] ) ) ? date( 'Y-m-d', strtotime( $this->args['updated_from'] ) ) : '';
		$updated_to   = ( ! empty( $this->args['updated_to'] ) && false !== strtotime( $this->args['updated_to'] ) ) ? date( 'Y-m-d', strtotime( $this->args['updated_to'] ) ) : '';
		$tags         = isset( $this->args['tag'] ) ? $this->args['tag'] : array();
		$lists        = isset( $this->args['list'] ) ? $this->args['list'] : array();

		if ( ! empty( $from ) ) {
			$filter_where .= $wpdb->prepare( "AND (c.creation_date >= %s)", $from );
		}
		if ( ! empty( $to ) ) {
			$filter_where .= $wpdb->prepare( "AND (c.creation_date <= %s)", $to );
		}
		if ( ! empty( $updated_from ) ) {
			$filter_where .= $wpdb->prepare( "AND (c.last_modified > %s)", $updated_from );
		}
		if ( ! empty( $updated_to ) ) {
			$filter_where .= $wpdb->prepare( "AND (c.last_modified < %s)", $updated_to );
		}

		if ( ! empty( $tags ) ) {
			$tag_clauses = array();
			foreach ( (array) $tags as $tag ) {
				$like          = '%"' . $wpdb->esc_like( (string) $tag ) . '"%';
				$tag_clauses[] = $wpdb->prepare( 'c.tags LIKE %s', $like );
			}
			if ( ! empty( $tag_clauses ) ) {
				$filter_where .= 'AND (' . implode( ' OR ', $tag_clauses ) . ')';
			}
		}

		if ( ! empty( $lists ) ) {
			$list_clauses = array();
			foreach ( (array) $lists as $list ) {
				$like           = '%"' . $wpdb->esc_like( (string) $list ) . '"%';
				$list_clauses[] = $wpdb->prepare( 'c.lists LIKE %s', $like );
			}
			if ( ! empty( $list_clauses ) ) {
				$filter_where .= 'AND (' . implode( ' OR ', $list_clauses ) . ')';
			}
		}

		return $filter_where;
	}

	public static function get_unsubscribed_contacts( $contact_data ) {
		if ( ! isset( $contact_data['contacts'] ) || empty( $contact_data['contacts'] ) ) {
			return [];
		}
		$emails      = array_column( $contact_data['contacts'], 'email' );
		$contact_nos = array_column( $contact_data['contacts'], 'contact_no' );
		$recipients  = array_filter( array_unique( array_merge( $emails, $contact_nos ) ) );
		if ( empty( $recipients ) ) {
			return [];
		}
		global $wpdb;
		$placeholders = implode( ',', array_fill( 0, count( $recipients ), '%s' ) );
		$query        = " SELECT recipient FROM {$wpdb->prefix}bwfan_message_unsubscribe WHERE recipient IN ($placeholders)";

		return $wpdb->get_col( $wpdb->prepare( $query, $recipients ) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL
	}
}

\BWFAN_Rest_API_Loader::register( 'BWFAN\Rest_API\Get_Contacts' );

/**
 * Class Get_Contact_By_Id_Or_Email
 */
class Get_Contact_By_Id_Or_Email extends \BWFAN_Rest_API_Base {
	public static $ins;

	public function __construct() {
		parent::__construct();
		$this->method   = \WP_REST_Server::READABLE;
		$this->route    = '/contact';
		$this->validate = [ 'contact_not_exists' ];
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	/**
	 * @param \BWFCRM_Contact $contact
	 */
	public function process_api_call( $contact = '' ) {
		$id    = $this->get_sanitized_arg( 'id', 'text_field' );
		$email = $this->get_sanitized_arg( 'email', 'email' );

		$search_by = empty( $id ) ? $email : $id;
		if ( empty( $search_by ) ) {
			$this->error_response( null, 400, 'required_fields_missing' );
		}

		return $this->success_response( [ 'contact' => \BWFAN_Rest_API_Common::get_formatted_contact_data( $contact ) ], __( 'Contact fetched successfully', 'wp-marketing-automations-pro' ) );
	}
}

\BWFAN_Rest_API_Loader::register( 'BWFAN\Rest_API\Get_Contact_By_Id_Or_Email' );

/**
 * Class Add_Contact
 */
class Add_Contact extends \BWFAN_Rest_API_Base {
	public static $ins;

	public function __construct() {
		parent::__construct();
		$this->method   = \WP_REST_Server::CREATABLE;
		$this->route    = '/contact/add';
		$this->required = [ 'email' ];
		$this->validate = [ 'contact_already_exists' ];
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	/**
	 * @param \BWFCRM_Contact $contact
	 */
	public function process_api_call( $contact = '' ) {
		$result          = array();
		$email           = $this->get_sanitized_arg( 'email', 'email' );
		$stop_automation = isset( $this->args['stop_automation'] ) ? $this->args['stop_automation'] : false;

		if ( ! is_email( $email ) ) {
			$this->error_response( null, 422, 'email_invalid' );
		}

		$fields = isset( $this->args['fields'] ) && ! empty( $this->args['fields'] ) ? $this->args['fields'] : array();

		$params = array(
			'f_name'     => isset( $this->args['f_name'] ) ? $this->get_sanitized_arg( 'f_name', 'text_field', $this->args['f_name'] ) : '',
			'l_name'     => isset( $this->args['l_name'] ) ? $this->get_sanitized_arg( 'l_name', 'text_field', $this->args['l_name'] ) : '',
			'country'    => isset( $this->args['country'] ) ? $this->get_sanitized_arg( 'country', 'text_field', $this->args['country'] ) : '',
			'state'      => isset( $this->args['state'] ) ? $this->get_sanitized_arg( 'state', 'text_field', $this->args['state'] ) : '',
			'source'     => isset( $this->args['source'] ) ? $this->get_sanitized_arg( 'source', 'text_field', $this->args['source'] ) : 'public_api',
			'contact_no' => isset( $this->args['contact_no'] ) ? $this->get_sanitized_arg( 'contact_no', 'text_field', $this->args['contact_no'] ) : '',
		);

		if ( ! empty( $fields ) ) {
			$field_data = \BWFAN_Rest_API_Common::remove_invalid_fields( $fields );
			if ( ! empty( $field_data['field_not_exists'] ) ) {
				$result['field_not_exists'] = $field_data['field_not_exists'];
			}
			$params = array_replace( $params, $field_data['fields'] );
		}

		$contact = \BWFAN_Rest_API_Common::create_contact( $email, $params, true );

		if ( isset( $this->args['tags'] ) ) {
			$tag_ids = is_array( $this->args['tags'] ) ? $this->args['tags'] : array( $this->args['tags'] );
			$contact->set_tags_v2( $tag_ids, $stop_automation );
		}

		if ( isset( $this->args['lists'] ) ) {
			$list_ids = is_array( $this->args['lists'] ) ? $this->args['lists'] : array( $this->args['lists'] );
			$contact->set_lists_v2( $list_ids, $stop_automation );
		}

		$contact->save();

		if ( ! $contact->is_contact_exists() ) {
			$this->error_response( '', 422, 'unknown_error' );
		}

		if ( isset( $this->args['status'] ) ) {
			\BWFAN_Rest_API_Common::change_contact_status( $contact, $this->args['status'] );
		}

		return $this->success_response( [ 'contact' => \BWFAN_Rest_API_Common::set_contact_status( $contact ) ], 'Contact created successfully' );
	}
}

\BWFAN_Rest_API_Loader::register( 'BWFAN\Rest_API\Add_Contact' );

/**
 * Class Update_Contact
 */
class Update_Contact extends \BWFAN_Rest_API_Base {
	public static $ins;

	public function __construct() {
		parent::__construct();
		$this->method   = \WP_REST_Server::EDITABLE;
		$this->route    = '/contact/update/(?P<id>[\\d]+)';
		$this->required = [ 'id' ];
		$this->validate = [ 'contact_not_exists' ];
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	/**
	 * @param \BWFCRM_Contact $contact
	 */
	public function process_api_call( $contact = '' ) {
		$id = $this->get_sanitized_arg( 'id', 'text_field' );

		$params = array(
			'id'         => $id,
			'f_name'     => isset( $this->args['f_name'] ) ? $this->get_sanitized_arg( 'f_name', 'text_field', $this->args['f_name'] ) : '',
			'l_name'     => isset( $this->args['l_name'] ) ? $this->get_sanitized_arg( 'l_name', 'text_field', $this->args['l_name'] ) : '',
			'country'    => isset( $this->args['country'] ) ? $this->get_sanitized_arg( 'country', 'text_field', $this->args['country'] ) : '',
			'state'      => isset( $this->args['state'] ) ? $this->get_sanitized_arg( 'state', 'text_field', $this->args['state'] ) : '',
			'source'     => isset( $this->args['source'] ) ? $this->get_sanitized_arg( 'source', 'text_field', $this->args['source'] ) : '',
			'contact_no' => isset( $this->args['contact_no'] ) ? $this->get_sanitized_arg( 'contact_no', 'text_field', $this->args['contact_no'] ) : '',
		);

		if ( isset( $this->args['email'] ) ) {
			$email = $this->get_sanitized_arg( 'email', 'email' );
			if ( ! is_email( $email ) ) {
				$this->error_response( null, 422, 'email_invalid' );
			}
			if ( ! empty( \BWFAN_Rest_API_Common::is_contact_exists( $email ) ) ) {
				$this->error_response( null, 422, 'already_exists' );
			}
			$params['email'] = $email;
		}

		$result = array();
		$fields = isset( $this->args['fields'] ) && ! empty( $this->args['fields'] ) ? $this->args['fields'] : array();
		if ( ! empty( $fields ) ) {
			$field_data = \BWFAN_Rest_API_Common::remove_invalid_fields( $fields );
			if ( ! empty( $field_data['field_not_exists'] ) ) {
				$result['field_not_exists'] = $field_data['field_not_exists'];
			}
			if ( ! empty( $field_data['fields'] ) ) {
				$contact->set_fields( $field_data['fields'] );
			}
		}

		$params = array_filter( $params );

		if ( isset( $this->args['tags'] ) && ! empty( $this->args['tags'] ) ) {
			$tags     = is_array( $this->args['tags'] ) ? $this->args['tags'] : array( $this->args['tags'] );
			$tag_data = \BWFCRM_Tag::get_tags( $tags );
			$tag_ids  = array_column( $tag_data, 'ID' );
			$contact->set_tags_v2( $tag_ids );
		}

		if ( isset( $this->args['lists'] ) && ! empty( $this->args['lists'] ) ) {
			$lists      = is_array( $this->args['lists'] ) ? $this->args['lists'] : array( $this->args['lists'] );
			$lists_data = \BWFCRM_Lists::get_lists( $lists );
			$list_ids   = array_column( $lists_data, 'ID' );
			$contact->set_lists_v2( $list_ids );
		}

		$update_contact = $contact->update( $params );
		if ( is_wp_error( $update_contact ) || ! $update_contact ) {
			$this->error_response( '', 422, 'unknown_error' );
		}

		if ( isset( $this->args['status'] ) ) {
			\BWFAN_Rest_API_Common::change_contact_status( $contact, $this->args['status'] );
		}

		$contact = new \BWFCRM_Contact( $contact->get_id() );

		return $this->success_response( [ 'contact' => \BWFAN_Rest_API_Common::get_formatted_contact_data( $contact ) ], __( 'Contact updated successfully', 'wp-marketing-automations-pro' ) );
	}
}

\BWFAN_Rest_API_Loader::register( 'BWFAN\Rest_API\Update_Contact' );

/**
 * Class Delete_Contact
 */
class Delete_Contact extends \BWFAN_Rest_API_Base {
	public static $ins;

	public function __construct() {
		parent::__construct();
		$this->method   = \WP_REST_Server::DELETABLE;
		$this->route    = '/contact/(?P<id>[\\d]+)';
		$this->required = [ 'id' ];
		$this->validate = [ 'contact_not_exists' ];
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	public function process_api_call() {
		$id             = $this->get_sanitized_arg( 'id', 'text_field' );
		$delete_contact = \BWFCRM_Model_Contact::delete_contact( $id );

		if ( ! $delete_contact ) {
			$this->error_response( '', 422, 'unknown_error' );
		}

		return $this->success_response( [], __( 'Contact deleted successfully', 'wp-marketing-automations-pro' ) );
	}
}

\BWFAN_Rest_API_Loader::register( 'BWFAN\Rest_API\Delete_Contact' );

/**
 * Class Update_Email
 */
class Update_Email extends \BWFAN_Rest_API_Base {
	public static $ins;

	public function __construct() {
		parent::__construct();
		$this->method   = \WP_REST_Server::EDITABLE;
		$this->route    = '/contact/update-email/(?P<id>[\\d]+)';
		$this->required = [ 'id', 'email' ];
		$this->validate = [ 'contact_not_exists' ];
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	/**
	 * @param \BWFCRM_Contact $contact
	 */
	public function process_api_call( $contact = '' ) {
		$email = $this->get_sanitized_arg( 'email', 'email' );

		if ( ! is_email( $email ) ) {
			$this->error_response( null, 422, 'email_invalid' );
		}

		if ( ! empty( \BWFAN_Rest_API_Common::is_contact_exists( $email ) ) ) {
			$this->error_response( null, 422, 'already_exists' );
		}

		$update_contact = $contact->set_data( array( 'email' => $email ) );
		if ( is_wp_error( $update_contact ) ) {
			$this->error_response( $update_contact->get_error_messages(), 422, 'unknown_error' );
		}

		$contact->save();
		$contact = new \BWFCRM_Contact( $contact->get_id() );

		return $this->success_response( [ 'contact' => \BWFAN_Rest_API_Common::get_formatted_contact_data( $contact ) ], __( 'Email updated successfully', 'wp-marketing-automations-pro' ) );
	}
}

\BWFAN_Rest_API_Loader::register( 'BWFAN\Rest_API\Update_Email' );

/**
 * Class Change_Status
 */
class Change_Status extends \BWFAN_Rest_API_Base {
	public static $ins;

	public function __construct() {
		parent::__construct();
		$this->method   = \WP_REST_Server::EDITABLE;
		$this->route    = '/contact/change-status/(?P<id>[\\d]+)';
		$this->required = [ 'id', 'status' ];
		$this->validate = [ 'contact_not_exists' ];
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	/**
	 * @param \BWFCRM_Contact $contact
	 */
	public function process_api_call( $contact = '' ) {
		$status           = $this->get_sanitized_arg( 'status', 'text_field' );
		$status           = ! empty( $status ) ? strtolower( $status ) : $status;
		$allowed_statuses = array_keys( $this->get_contact_statuses() );

		if ( ! in_array( $status, $allowed_statuses, true ) ) {
			$this->error_response( sprintf( __( 'Invalid status. Allowed values are: %s', 'wp-marketing-automations-pro' ), implode( ', ', $allowed_statuses ) ), 422, 'invalid_status' );
		}

		$result = \BWFAN_Rest_API_Common::change_contact_status( $contact, $status );
		if ( ! $result ) {
			$this->error_response( '', 422, 'unknown_error' );
		}

		return $this->success_response( [ 'contact' => \BWFAN_Rest_API_Common::get_formatted_contact_data( $contact ) ], __( 'Status changed successfully', 'wp-marketing-automations-pro' ) );
	}
}

\BWFAN_Rest_API_Loader::register( 'BWFAN\Rest_API\Change_Status' );

/**
 * Class Assign_Tag
 */
class Assign_Tag extends \BWFAN_Rest_API_Base {
	public static $ins;

	public function __construct() {
		parent::__construct();
		$this->method   = \WP_REST_Server::EDITABLE;
		$this->route    = '/contact/tag-assign/(?P<id>[\\d]+)';
		$this->required = [ 'id', 'tags' ];
		$this->validate = [ 'contact_not_exists' ];
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	/**
	 * @param \BWFCRM_Contact $contact
	 */
	public function process_api_call( $contact = '' ) {
		$tags            = isset( $this->args['tags'] ) ? $this->args['tags'] : array();
		$stop_automation = isset( $this->args['stop_automation'] ) ? $this->args['stop_automation'] : false;

		if ( ! is_array( $tags ) ) {
			$this->error_response( null, 422, 'unprocessable_entity' );
		}

		$tag_data = \BWFCRM_Tag::get_tags( $tags );
		if ( empty( $tag_data ) ) {
			$this->error_response( 'Tag(s) not found', 422, 'unprocessable_entity' );
		}

		$tag_ids     = array_column( $tag_data, 'ID' );
		$old_tags    = $contact->get_tags();
		$assign_tags = $contact->set_tags_v2( $tag_ids, $stop_automation );
		$contact->save();

		if ( ! is_array( $assign_tags ) ) {
			$this->error_response( 'No tag(s) to update', 422, 'unprocessable_entity' );
		}
		if ( is_wp_error( $assign_tags ) ) {
			$this->error_response( $assign_tags->get_error_messages(), 422, 'unknown_error' );
		}

		$newly_assigned_tags = array_diff( $assign_tags, $old_tags );
		$tag_results         = \BWFCRM_Tag::get_tags( $newly_assigned_tags );

		return $this->success_response( [ 'tags' => $tag_results ], __( 'Tag(s) assigned successfully', 'wp-marketing-automations-pro' ) );
	}
}

\BWFAN_Rest_API_Loader::register( 'BWFAN\Rest_API\Assign_Tag' );

/**
 * Class Unassign_Tag
 */
class Unassign_Tag extends \BWFAN_Rest_API_Base {
	public static $ins;

	public function __construct() {
		parent::__construct();
		$this->method   = \WP_REST_Server::EDITABLE;
		$this->route    = '/contact/tag-unassign/(?P<id>[\\d]+)';
		$this->required = [ 'id', 'tagId' ];
		$this->validate = [ 'contact_not_exists' ];
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	/**
	 * @param \BWFCRM_Contact $contact
	 */
	public function process_api_call( $contact = '' ) {
		$tags = isset( $this->args['tagId'] ) ? $this->args['tagId'] : array();

		if ( ! is_array( $tags ) ) {
			$this->error_response( '', 422, 'unprocessable_entity' );
		}

		$tags_data = $contact->remove_tags( $tags );
		$contact->save();

		if ( empty( $tags_data ) ) {
			$this->error_response( 'No tag to unassign', 422, 'unprocessable_entity' );
		}
		if ( is_wp_error( $tags_data ) ) {
			$this->error_response( $tags_data->get_error_messages(), 422, 'unknown_error' );
		}

		$unassign_tags = \BWFCRM_Tag::get_tags( $tags_data );

		return $this->success_response( [ 'tags' => $unassign_tags ], __( 'Tag(s) unassigned successfully', 'wp-marketing-automations-pro' ) );
	}
}

\BWFAN_Rest_API_Loader::register( 'BWFAN\Rest_API\Unassign_Tag' );

/**
 * Class Assign_List
 */
class Assign_List extends \BWFAN_Rest_API_Base {
	public static $ins;

	public function __construct() {
		parent::__construct();
		$this->method   = \WP_REST_Server::EDITABLE;
		$this->route    = '/contact/list-assign/(?P<id>[\\d]+)';
		$this->required = [ 'id', 'lists' ];
		$this->validate = [ 'contact_not_exists' ];
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	/**
	 * @param \BWFCRM_Contact $contact
	 */
	public function process_api_call( $contact = '' ) {
		$lists           = isset( $this->args['lists'] ) ? $this->args['lists'] : array();
		$stop_automation = isset( $this->args['stop_automation'] ) ? (bool) $this->args['stop_automation'] : false;

		if ( ! is_array( $lists ) ) {
			$this->error_response( null, 422, 'unprocessable_entity' );
		}

		$list_data = \BWFCRM_Lists::get_lists( $lists );
		if ( empty( $list_data ) ) {
			$this->error_response( 'List(s) not found', 422, 'unprocessable_entity' );
		}

		$old_lists    = $contact->get_lists();
		$list_ids     = array_column( $list_data, 'ID' );
		$assign_lists = $contact->set_lists_v2( $list_ids, $stop_automation );
		$contact->save();

		if ( ! is_array( $assign_lists ) ) {
			$this->error_response( 'No list(s) to update', 422, 'unprocessable_entity' );
		}
		if ( is_wp_error( $assign_lists ) ) {
			$this->error_response( $assign_lists->get_error_messages(), 422, 'unknown_error' );
		}

		$newly_assigned_lists = array_diff( $assign_lists, $old_lists );
		$list_results         = \BWFCRM_Lists::get_lists( $newly_assigned_lists );

		return $this->success_response( [ 'lists' => $list_results ], __( 'List(s) assigned successfully', 'wp-marketing-automations-pro' ) );
	}
}

\BWFAN_Rest_API_Loader::register( 'BWFAN\Rest_API\Assign_List' );

/**
 * Class Unassign_List
 */
class Unassign_List extends \BWFAN_Rest_API_Base {
	public static $ins;

	public function __construct() {
		parent::__construct();
		$this->method   = \WP_REST_Server::EDITABLE;
		$this->route    = '/contact/list-unassign/(?P<id>[\\d]+)';
		$this->required = [ 'id', 'listId' ];
		$this->validate = [ 'contact_not_exists' ];
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	/**
	 * @param \BWFCRM_Contact $contact
	 */
	public function process_api_call( $contact = '' ) {
		$lists = isset( $this->args['listId'] ) ? $this->args['listId'] : array();

		if ( ! is_array( $lists ) ) {
			$this->error_response( '', 422, 'unprocessable_entity' );
		}

		$unassign_lists = $contact->remove_lists( $lists );
		$contact->save();

		if ( empty( $unassign_lists ) ) {
			$this->error_response( 'No list to unassign', 422, 'unprocessable_entity' );
		}
		if ( is_wp_error( $unassign_lists ) ) {
			$this->error_response( $unassign_lists->get_error_messages(), 422, 'unknown_error' );
		}

		$unassign_lists = \BWFCRM_Lists::get_lists( $unassign_lists );

		return $this->success_response( [ 'lists' => $unassign_lists ], __( 'List(s) unassigned successfully', 'wp-marketing-automations-pro' ) );
	}
}

\BWFAN_Rest_API_Loader::register( 'BWFAN\Rest_API\Unassign_List' );
