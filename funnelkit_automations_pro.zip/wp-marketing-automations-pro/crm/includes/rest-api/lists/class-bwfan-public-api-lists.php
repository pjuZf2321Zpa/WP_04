<?php

namespace BWFAN\Rest_API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Get_All_Lists
 */
class Get_All_Lists extends \BWFAN_Rest_API_Base {
	public static $ins;

	public function __construct() {
		parent::__construct();
		$this->method = \WP_REST_Server::READABLE;
		$this->route  = '/lists';
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	public function process_api_call() {
		$limit  = ! empty( $this->args['limit'] ) ? absint( $this->args['limit'] ) : 30;
		$offset = ! empty( $this->args['offset'] ) ? absint( $this->args['offset'] ) : 0;

		$lists = \BWFCRM_Lists::get_lists( array(), '', $offset, $limit );

		if ( empty( $lists ) ) {
			$this->error_response( null, 404, 'data_not_found' );
		}

		if ( is_array( $lists ) && ! empty( $lists ) ) {
			$lists = array_map( function ( $list ) {
				return array( 'ID' => $list['ID'], 'name' => $list['name'] );
			}, $lists );
		}

		return $this->success_response( [ 'lists' => $lists ], 'Lists fetched successfully' );
	}
}

\BWFAN_Rest_API_Loader::register( 'BWFAN\Rest_API\Get_All_Lists' );

/**
 * Class Add_List
 */
class Add_List extends \BWFAN_Rest_API_Base {
	public static $ins;

	public function __construct() {
		parent::__construct();
		$this->method   = \WP_REST_Server::CREATABLE;
		$this->route    = '/list/add';
		$this->required = [ 'lists' ];
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	public function process_api_call() {
		$lists = isset( $this->args['lists'] ) ? $this->args['lists'] : array();

		$list_data = array();
		if ( is_array( $lists ) ) {
			$list_data = array_map( function ( $list ) {
				return array( 'id' => 0, 'value' => $list );
			}, $lists );
		} else {
			$list_data['id']    = 0;
			$list_data['value'] = $lists;
			$list_data          = array( $list_data );
		}

		$lists = \BWFCRM_Term::get_or_create_terms( $list_data, \BWFCRM_Term_Type::$LIST, true, true );
		if ( is_wp_error( $lists ) ) {
			$this->error_response( null, 422, 'unknown_error' );
		}

		if ( ! isset( $lists['existing'] ) || ! isset( $lists['created'] ) ) {
			$this->error_response( null, 422, 'unknown_error' );
		}

		$created_lists = \BWFCRM_Term::get_collection_array( $lists['created'] );

		if ( empty( $created_lists ) ) {
			$this->error_response( null, 422, 'already_exists' );
		}

		return $this->success_response( [ 'lists' => $created_lists ], __( 'New list created successfully.', 'wp-marketing-automations-pro' ) );
	}
}

\BWFAN_Rest_API_Loader::register( 'BWFAN\Rest_API\Add_List' );

/**
 * Class Update_List
 */
class Update_List extends \BWFAN_Rest_API_Base {
	public static $ins;

	public function __construct() {
		parent::__construct();
		$this->method   = \WP_REST_Server::EDITABLE;
		$this->route    = '/list/update/(?P<id>[\\d]+)';
		$this->required = [ 'id', 'list' ];
		$this->validate = [ 'list_not_exists' ];
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	/**
	 * @param \BWFCRM_Lists $list
	 */
	public function process_api_call( $list = '' ) {
		$list_id   = $this->get_sanitized_arg( 'id', 'key' );
		$list_name = $this->get_sanitized_arg( 'list', 'text_field' );

		$current_name = $list->get_name();
		if ( $list_name === $current_name ) {
			$updated_list = [ 'ID' => $list_id, 'name' => $list_name ];

			return $this->success_response( [ 'lists' => $updated_list ], __( 'List updated successfully', 'wp-marketing-automations-pro' ) );
		}

		$already_exists = \BWFCRM_Lists::get_terms( \BWFCRM_Term_Type::$LIST, [], $list_name, 0, 0, ARRAY_A, 'exact' );
		if ( ! empty( $already_exists ) ) {
			$this->error_response( __( 'List already exists with name: ' . $list_name, 'wp-marketing-automations-pro' ), 422, 'unknown_error' );
		}

		$list->set_name( $list_name );
		$updated = $list->save();

		if ( empty( $updated ) || is_wp_error( $updated ) ) {
			$this->error_response( null, 422, 'unknown_error' );
		}

		$updated_list = [ 'ID' => $list_id, 'name' => $list->get_name() ];

		return $this->success_response( [ 'lists' => $updated_list ], __( 'List updated successfully', 'wp-marketing-automations-pro' ) );
	}
}

\BWFAN_Rest_API_Loader::register( 'BWFAN\Rest_API\Update_List' );

/**
 * Class Delete_List
 */
class Delete_List extends \BWFAN_Rest_API_Base {
	public static $ins;

	public function __construct() {
		parent::__construct();
		$this->method   = \WP_REST_Server::DELETABLE;
		$this->route    = '/list/(?P<id>[\\d]+)';
		$this->required = [ 'id' ];
		$this->validate = [ 'list_not_exists' ];
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	/**
	 * @param \BWFCRM_Lists $list
	 */
	public function process_api_call( $list = '' ) {
		$list_id = $this->get_sanitized_arg( 'id', 'text_field' );

		$deleted_list = [ 'ID' => $list_id, 'name' => $list->get_name() ];

		$delete_list = \BWFCRM_Lists::delete_list( absint( $list_id ) );

		if ( false === $delete_list ) {
			$this->error_response( null, 422, 'unknown_error' );
		}

		return $this->success_response( [ 'lists' => $deleted_list ], __( 'List deleted successfully', 'wp-marketing-automations-pro' ) );
	}
}

\BWFAN_Rest_API_Loader::register( 'BWFAN\Rest_API\Delete_List' );
