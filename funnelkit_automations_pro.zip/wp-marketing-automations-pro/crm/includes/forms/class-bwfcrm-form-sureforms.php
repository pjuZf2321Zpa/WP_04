<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

#[AllowDynamicProperties]
class BWFCRM_Form_SureForms extends BWFCRM_Form_Base {
	private $total_selections = 1;
	private $source = 'sureforms';

	/** Form Submission Captured Data */
	private $form_id = '';
	private $form_title = '';
	private $fields = [];
	private $email = '';
	private $autonami_event = '';

	public function get_source() {
		return $this->source;
	}

	public function get_form_link( $feed ) {
		$url     = '';
		$form_id = $feed->get_data( 'form_id' );
		if ( absint( $form_id ) > 0 ) {
			/** 'raw' context: the default 'display' context returns &amp;, which breaks the link once it reaches React as JSON. */
			$url = get_edit_post_link( absint( $form_id ), 'raw' );
		}

		return ! empty( $url ) ? $url : '';
	}

	public function capture_async_submission() {
		$this->form_id        = isset( BWFAN_Common::$events_async_data['form_id'] ) ? BWFAN_Common::$events_async_data['form_id'] : '';
		$this->form_title     = isset( BWFAN_Common::$events_async_data['form_title'] ) ? BWFAN_Common::$events_async_data['form_title'] : '';
		$this->fields         = isset( BWFAN_Common::$events_async_data['fields'] ) && is_array( BWFAN_Common::$events_async_data['fields'] ) ? BWFAN_Common::$events_async_data['fields'] : [];
		$this->email          = isset( BWFAN_Common::$events_async_data['email'] ) ? BWFAN_Common::$events_async_data['email'] : '';
		$this->autonami_event = isset( BWFAN_Common::$events_async_data['event'] ) ? BWFAN_Common::$events_async_data['event'] : '';

		$this->find_feeds_and_create_contacts();
	}

	public function filter_feeds_for_current_entry() {
		return array_filter( array_map( function ( $feed ) {
			$feed_form_id = $feed->get_data( 'form_id' );
			if ( absint( $this->form_id ) !== absint( $feed_form_id ) ) {
				return false;
			}

			return $feed;
		}, $this->feeds ) );
	}

	public function prepare_contact_data_from_feed_entry( $mapped_fields ) {
		$contact_data = [];
		if ( ! is_array( $mapped_fields ) || empty( $mapped_fields ) ) {
			return $contact_data;
		}

		foreach ( $this->fields as $block_id => $value ) {
			if ( ! isset( $mapped_fields[ $block_id ] ) ) {
				continue;
			}

			$contact_field = is_numeric( $mapped_fields[ $block_id ] ) ? absint( $mapped_fields[ $block_id ] ) : $mapped_fields[ $block_id ];

			if ( is_array( $value ) ) {
				$value = array_filter( $value );
				$value = implode( ', ', $value );
			}

			$contact_data[ $contact_field ] = $value;
		}

		return $contact_data;
	}

	public function get_form_fields( $feed ) {
		if ( ! $feed instanceof BWFCRM_Form_Feed ) {
			return BWFCRM_Common::crm_error( __( 'Feed not Exists: ', 'wp-marketing-automations-pro' ) );
		}
		$feed_id = $feed->get_id();
		if ( ! $feed->is_feed_exists() ) {
			/* translators: %d: form feed ID */
			return BWFCRM_Common::crm_error( sprintf( __( 'No Feed Exists: %d', 'wp-marketing-automations-pro' ), $feed_id ) );
		}

		$form_id = $feed->get_data( 'form_id' );
		if ( empty( $form_id ) ) {
			/* translators: %d: form feed ID */
			return BWFCRM_Common::crm_error( sprintf( __( "Form Feed doesn't have sufficient data to get fields: %d", 'wp-marketing-automations-pro' ), $feed_id ) );
		}

		/** @var BWFAN_SureForms_Form_Submit $event */
		$event = BWFAN_Core()->sources->get_event( 'sureforms_form_submit' );
		if ( ! $event instanceof BWFAN_SureForms_Form_Submit ) {
			/* translators: %d: form feed ID */
			return BWFCRM_Common::crm_error( sprintf( __( "Form FunnelKit Automations Event doesn't found for Feed: %d", 'wp-marketing-automations-pro' ), $feed_id ) );
		}

		return $event->get_form_fields( $form_id );
	}

	public function get_form_selection( $args, $return_all_available = false ) {
		/** Reuse the event's form list so titles are decoded and untitled forms get the same fallback label. */
		$event        = BWFAN_Core()->sources->get_event( 'sureforms_form_submit' );
		$form_options = $event instanceof BWFAN_SureForms_Form_Submit ? $event->get_view_data() : [];

		$form_options = array( 'default' => $form_options );
		$form_options = $this->get_step_selection_array( 'Form', 'form_id', 1, $form_options );

		return $form_options;
	}

	public function get_total_selection_steps() {
		return $this->total_selections;
	}

	public function get_meta() {
		return array(
			'form_selection_fields' => array(
				'form_id' => 'Form ID'
			)
		);
	}

	public function update_form_selection( $args, $feed_id ) {
		if ( empty( $feed_id ) ) {
			return BWFCRM_Common::crm_error( __( 'Empty Feed ID provided', 'wp-marketing-automations-pro' ) );
		}

		$form_id = isset( $args['form_id'] ) && ! empty( $args['form_id'] ) ? $args['form_id'] : false;
		$feed    = new BWFCRM_Form_Feed( $feed_id );
		if ( ! $feed->is_feed_exists() ) {
			/* translators: %d: form feed ID */
			return BWFCRM_Common::crm_error( sprintf( __( 'Feed with ID not exists: %d', 'wp-marketing-automations-pro' ), $feed_id ) );
		}

		if ( empty( $form_id ) && $this->source === $feed->get_source() ) {
			return false;
		}

		$feed->unset_data( 'form_id' );
		$feed->get_source() !== $this->source && $feed->set_source( $this->source );
		! empty( $form_id ) && $feed->set_data( 'form_id', $form_id );

		return ! ! $feed->save( true );
	}
}

if ( function_exists( 'bwfan_is_sureforms_active' ) && bwfan_is_sureforms_active() ) {
	BWFCRM_Core()->forms->register( 'sureforms', 'BWFCRM_Form_SureForms', 'SureForms', array(
		'sureforms_form_submit'
	) );
}
