<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

#[AllowDynamicProperties]
class BWFCRM_Form_CF7 extends BWFCRM_Form_Base {
	private $total_selections = 1;
	private $source = 'cf7';

	/** Form Submission Captured Data */
	private $form_id = '';
	private $form_title = '';
	private $fields = [];
	private $autonami_event = '';

	public function get_source() {
		return $this->source;
	}

	/**
	 * @param BWFCRM_Form_Feed $feed
	 *
	 * @return string|void
	 */
	public function get_form_link( $feed ) {
		$url     = '';
		$form_id = $feed->get_data( 'form_id' );
		if ( absint( $form_id ) > 0 ) {
			$url = admin_url( 'admin.php?page=wpcf7&post=' . absint( $form_id ) . '&action=edit' );
		}

		return $url;
	}

	public function capture_async_submission() {
		/** CF7 async payload carries flat, tag-name-keyed values under 'fields' (no 'entry' key) */
		$this->form_id    = BWFAN_Common::$events_async_data['form_id'];
		$this->form_title = BWFAN_Common::$events_async_data['form_title'];
		$this->fields     = isset( BWFAN_Common::$events_async_data['fields'] ) && is_array( BWFAN_Common::$events_async_data['fields'] ) ? BWFAN_Common::$events_async_data['fields'] : [];

		$this->autonami_event = BWFAN_Common::$events_async_data['event'];

		$this->find_feeds_and_create_contacts();
	}

	public function filter_feeds_for_current_entry() {
		return array_filter( array_map( function ( $feed ) {
			$feed_form_id = $feed->get_data( 'form_id' );
			if ( absint( $this->form_id ) !== absint( $feed_form_id ) ) {
				return false;
			}

			return $feed;
		}, $this->feeds ) );
	}

	public function prepare_contact_data_from_feed_entry( $mapped_fields ) {
		$contact_data = [];
		if ( ! is_array( $mapped_fields ) || empty( $mapped_fields ) ) {
			return $contact_data;
		}

		foreach ( $this->fields as $tag => $value ) {
			if ( ! isset( $mapped_fields[ $tag ] ) ) {
				continue;
			}

			$contact_field = is_numeric( $mapped_fields[ $tag ] ) ? absint( $mapped_fields[ $tag ] ) : $mapped_fields[ $tag ];

			if ( is_array( $value ) ) {
				$value = array_filter( $value );
				$value = implode( ', ', $value );
			}

			$contact_data[ $contact_field ] = $value;
		}

		return $contact_data;
	}

	public function get_form_fields( $feed ) {
		if ( ! $feed instanceof BWFCRM_Form_Feed ) {
			return BWFCRM_Common::crm_error( __( 'Feed  not Exists: ', 'wp-marketing-automations-pro' ) );
		}
		$feed_id = $feed->get_id();
		if ( ! $feed->is_feed_exists() ) {
			return BWFCRM_Common::crm_error( __( 'No Feed Exists: ' . $feed_id, 'wp-marketing-automations-pro' ) );
		}

		$form_id = $feed->get_data( 'form_id' );
		if ( empty( $form_id ) ) {
			return BWFCRM_Common::crm_error( __( 'Form Feed doesn\'t have sufficient data to get fields: ' . $feed_id, 'wp-marketing-automations-pro' ) );
		}

		return $this->get_cf7_form_fields( $form_id );
	}

	public function get_cf7_form_fields( $form_id ) {
		$fields = array();
		if ( empty( $form_id ) || ! class_exists( 'WPCF7_ContactForm' ) ) {
			return $fields;
		}

		$form = \WPCF7_ContactForm::get_instance( $form_id );
		if ( ! $form instanceof \WPCF7_ContactForm ) {
			return $fields;
		}

		$form_fields = $form->scan_form_tags();
		if ( empty( $form_fields ) ) {
			return $fields;
		}

		foreach ( $form_fields as $field ) {
			if ( $field->type === 'submit' || false !== strpos( $field->type, 'file' ) || empty( $field->name ) ) {
				continue;
			}
			$fields[ $field->name ] = $field->name;
		}

		return $fields;
	}

	public function get_form_selection( $args, $return_all_available = false ) {
		/** Form ID Handling - enumerate CF7 forms (mirrors lite CF7 event get_view_data) */
		$query_args = array(
			'post_type'      => 'wpcf7_contact_form',
			'posts_per_page' => -1,
			'orderby'        => 'title',
			'order'          => 'ASC',
			'post_status'    => 'publish',
		);
		$forms      = ( new WP_Query( $query_args ) )->posts;

		$form_options = [];
		if ( ! empty( $forms ) ) {
			foreach ( $forms as $form ) {
				$form_options[ $form->ID ] = $form->post_title;
			}
		}

		$form_options = array( 'default' => $form_options );
		$form_options = $this->get_step_selection_array( 'Form', 'form_id', 1, $form_options );

		return $form_options;
	}

	public function get_total_selection_steps() {
		return $this->total_selections;
	}

	public function get_meta() {
		return array(
			'form_selection_fields' => array(
				'form_id' => 'Form ID'
			)
		);
	}

	/**
	 * @param $args
	 * @param $feed_id
	 *
	 * @return bool|WP_Error
	 */
	public function update_form_selection( $args, $feed_id ) {
		if ( empty( $feed_id ) ) {
			return BWFCRM_Common::crm_error( __( 'Empty Feed ID provided', 'wp-marketing-automations-pro' ) );
		}

		$form_id = isset( $args['form_id'] ) && ! empty( $args['form_id'] ) ? $args['form_id'] : false;
		$feed    = new BWFCRM_Form_Feed( $feed_id );
		if ( ! $feed->is_feed_exists() ) {
			return BWFCRM_Common::crm_error( __( 'Feed with ID not exists: ' . $feed_id, 'wp-marketing-automations-pro' ) );
		}

		if ( empty( $form_id ) && $this->source === $feed->get_source() ) {
			return false;
		}

		$feed->unset_data( 'form_id' );
		$feed->get_source() !== $this->source && $feed->set_source( $this->source );
		! empty( $form_id ) && $feed->set_data( 'form_id', $form_id );

		return ! ! $feed->save( true );
	}
}

if ( function_exists( 'bwfan_is_cf7_active' ) && bwfan_is_cf7_active() ) {
	BWFCRM_Core()->forms->register( 'cf7', 'BWFCRM_Form_CF7', 'Contact Form 7', array(
		'cf7_form_submit'
	) );
}
