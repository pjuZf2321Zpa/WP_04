<?php

if ( ! class_exists( 'BWFCRM_WCS_Column_Preferences' ) ) {
	#[\AllowDynamicProperties]
	class BWFCRM_WCS_Column_Preferences {
		private static $ins = null;

		/** @return BWFCRM_WCS_Column_Preferences */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function __construct() {
			add_filter( 'bwfcrm_contact_columns_group', array( $this, 'add_column_group' ), 10, 2 );
			add_filter( 'bwfcrm_contact_columns_preferences', array( $this, 'add_columns' ), 10, 3 );

			/** Add woocommerce subscription contact data for export columns */
			add_filter( 'bwfan_get_contact_field_by_slug', array( $this, 'wcs_contact_data' ), 10, 3 );
		}

		public function add_column_group( $slug, $fields ) {
			if ( ! bwfan_is_woocommerce_subscriptions_active() || ! isset( $fields['groupKey'] ) || ! in_array( $fields['groupKey'], ['wc_subscription'], true ) ) {
				return $slug;
			}

			$column = "wcs." . $slug;
			switch ( $slug ) {
				case 'l_subscription_days' :
					$column = " DATEDIFF(now(), wcs.l_order_date) as `l_subscription_days` ";
					break;
				case 'next_renewal_days' :
					$column = " DATEDIFF(wcs.next_renewal_date, now()) as `next_renewal_days` ";
					break;
				case 'l_subscription_date' :
					$column = " wcs.l_order_date AS `l_subscription_date` ";
					break;
			}

			return $column;
		}

		public function add_columns( $data, $group_columns, $join_cf_query ) {
			if ( ! bwfan_is_woocommerce_subscriptions_active() ) {
				return $data;
			}

			/** Get woocommerce subscription columns */
			$wcs = isset( $group_columns['wc_subscription'] ) && is_array( $group_columns['wc_subscription'] ) ? $group_columns['wc_subscription'] : [];
			if ( empty( $wcs ) ) {
				return $data;
			}
			$total_columns = isset( $data['total_columns'] ) && is_array( $data['total_columns'] ) ? array_merge( $data['total_columns'], $wcs ) : $wcs;

			$join = '';
			/** Checking if Join is already in custom filter */
			if ( false === strpos( $join_cf_query, 'bwfan_wcs_subscriber' ) ) {
				global $wpdb;
				$join = " LEFT JOIN {$wpdb->prefix}bwfan_wcs_subscriber as wcs ON c.id=wcs.cid ";
			}

			return [
				'total_columns' => $total_columns,
				'join_query'    => isset( $data['join_query'] ) ? $data['join_query'] . $join : $join
			];
		}

		/**
		 * Fetch WCS contact data for export columns.
		 * @param mixed $val
		 * @param mixed $field
		 * @param mixed $contact
		 */
		public function wcs_contact_data( $val, $field, $contact ) {
			if ( ! bwfan_is_woocommerce_subscriptions_active() ) {
				return $val;
			}

			$contact_id = $contact->get_id();

			static $subscriber_data = [];
			if ( ! isset( $subscriber_data[ $contact_id ] ) ) {
				$subscriber_data[ $contact_id ] = BWFAN_Model_WCS_Subscriber::get_subscriber( $contact_id );
			}

			$wcs = $subscriber_data[ $contact_id ];
			if ( empty( $wcs ) ) {
				return $val;
			}
			
			$l_order_date = $wcs['l_order_date'] ?? '';
			$next_renewal_date = $wcs['next_renewal_date'] ?? '';
			$active_subs_count = $wcs['active_subs_count'] ?? 0;
			$active_subs_product = $wcs['active_subs_product'] ?? [];
			switch ( $field ) {
				case 'l_subscription_days':
					$val = !empty($l_order_date) ? date_diff(new DateTime($l_order_date), new DateTime('now'))->days : 0;
					break;
				case 'l_subscription_date':
					$val = $l_order_date;
					break;
				case 'active_subs_count':
					$val = $wcs['active_subs_count'] ?? 0;
					break;
				case 'next_renewal_days':
					$val = !empty($next_renewal_date) ? date_diff(new DateTime($next_renewal_date), new DateTime('now'))->days : 0;
					break;
				case 'next_renewal_date':
					$val = $next_renewal_date;
					break;
				case 'renewal_count':
					$val = $wcs['renewal_count'] ?? 0;
					break;
				case 'active_subs_product':
					$val = implode( ', ', $active_subs_product );
					break;
				case 'has_active_subscription':
					$val = $active_subs_count > 0 ? 'Yes' : 'No';
					break;
			}
			return $val;
		}
	}

$ins = BWFCRM_WCS_Column_Preferences::get_instance();

}
