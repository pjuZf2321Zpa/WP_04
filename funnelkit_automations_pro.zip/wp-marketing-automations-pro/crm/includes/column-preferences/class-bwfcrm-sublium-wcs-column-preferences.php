<?php

if ( ! class_exists( 'BWFCRM_Sublium_WCS_Column_Preferences' ) ) {
	#[\AllowDynamicProperties]
	class BWFCRM_Sublium_WCS_Column_Preferences {
		private static $ins = null;

		/** @return BWFCRM_Sublium_WCS_Column_Preferences */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function __construct() {
			add_filter( 'bwfcrm_contact_columns_group', array( $this, 'add_column_group' ), 10, 2 );
			add_filter( 'bwfcrm_contact_columns_preferences', array( $this, 'add_columns' ), 10, 3 );
			add_filter( 'bwfcrm_modify_contact_columns_preferences_data', [ $this, 'modify_columns_data' ] );

			/** Add sublium subscription contact data for export columns */
			add_filter( 'bwfan_get_contact_field_by_slug', array( $this, 'insert_sublium_export_data' ), 10, 3 );
		}

		public function add_column_group( $slug, $fields ) {
			if ( ! bwfan_is_sublium_active() || ! isset( $fields['groupKey'] ) || ! in_array( $fields['groupKey'], ['sublium_subscription'], true ) ) {
				return $slug;
			}
			
			$column = "ss." . $slug;
			switch ( $slug ) {
				case 'sublium_next_renewal_days' :
					$column = " IF(DATEDIFF(ss.next_renewal_date, now()) < 0, 0, DATEDIFF(ss.next_renewal_date, now())) as `sublium_next_renewal_days` ";
					break;
				case 'sublium_next_renewal_date' :
					$column = " ss.next_renewal_date AS `sublium_next_renewal_date` ";
					break;
				case 'sublium_l_subscription_days' :
					$column = " DATEDIFF(now(), ss.last_order_date) as `sublium_l_subscription_days` ";
					break;
				case 'sublium_l_subscription_date' :
					$column = " ss.last_order_date AS `sublium_l_subscription_date` ";
					break;
				case 'sublium_active_subs_count' :
					$column = " ss.active_count AS `sublium_active_subs_count` ";
					break;
				case 'sublium_renewal_count' :
					$column = " ss.renewals_count AS `sublium_renewal_count` ";
					break;
				case 'sublium_active_subs_product' :
					$column = " ss.active_subscription_products AS `sublium_active_subs_product` ";
					break;
				case 'sublium_has_active_subs' :
					$column = " IF(ss.active_count > 0, 'Yes', 'No') AS `sublium_has_active_subs` ";
					break;
			}

			return $column;
		}

		public function add_columns( $data, $group_columns, $join_cf_query ) {
			if ( ! bwfan_is_sublium_active() ) {
				return $data;
			}

			/** Get sublium subscription columns */
			$wcs = isset( $group_columns['sublium_subscription'] ) && is_array( $group_columns['sublium_subscription'] ) ? $group_columns['sublium_subscription'] : [];
			if ( empty( $wcs ) ) {
				return $data;
			}
			$total_columns = isset( $data['total_columns'] ) && is_array( $data['total_columns'] ) ? array_merge( $data['total_columns'], $wcs ) : $wcs;
			$needs_to_added = isset( $group_columns['needs_to_added'] ) && is_array( $group_columns['needs_to_added'] ) ? $group_columns['needs_to_added'] : [];

			$join = '';

			/** Checking if Join is already in custom filter */
			if ( false === strpos( $join_cf_query, 'sublium_wcs_subscribers' ) ) {
				global $wpdb;
				$join = " LEFT JOIN {$wpdb->prefix}sublium_wcs_subscribers as ss ON c.wpid=ss.user_id";
			}

			return [
				'total_columns' => $total_columns,
				'join_query'    => isset( $data['join_query'] ) ? $data['join_query'] . $join : $join,
				'needs_to_added' => array_merge( $needs_to_added, ['sublium_active_subs_product'] ),
			];
		}

		public function modify_columns_data( $contact_data ) {
			if ( ! bwfan_is_sublium_active() ) {
				return $contact_data;
			}

			if ( isset( $contact_data['sublium_active_subs_product'] ) ) {
				$active_subs_products = json_decode( $contact_data['sublium_active_subs_product'], true );

				$active_subs_products = array_filter( array_map( function ( $product_id ) {
					$product = wc_get_product( $product_id );
					if ( ! $product instanceof WC_Product ) {
						return false;
					}
					$pid = $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id();

					return ! $product->is_type( 'variable' ) ? array(
						'id'   => $pid,
						'name' => wp_strip_all_tags( $product->get_name( 'edit' ) ),
						'link' => get_edit_post_link( $pid ),
					) : false;
				}, $active_subs_products ) );

				sort( $active_subs_products );
				$contact_data['sublium_active_subs_product'] = $active_subs_products;
			}

			return $contact_data;
		}

		public function insert_sublium_export_data( $val, $field, $contact ) {
			if ( ! bwfan_is_sublium_active() || ! $contact instanceof BWFCRM_Contact || ! $contact->is_contact_exists() ) {
				return $val;
			}

			$user_id = $contact->contact->get_wpid();
			if ( empty( $user_id ) ) {
				return $val;
			}

			static $subscriber_data = [];
			if ( ! isset( $subscriber_data[ $user_id ] ) ) {
				global $wpdb;
				$table_name = $wpdb->prefix . 'sublium_wcs_subscribers';
				$subscriber = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table_name WHERE user_id = %d", $user_id ), ARRAY_A );
				if ( empty( $subscriber ) ) {
					$subscriber_data[ $user_id ] = false;
					return $val;
				}
				$subscriber_data[ $user_id ] = $subscriber;
			}

			if ( empty( $subscriber_data[ $user_id ] ) ) {
				return $val;
			}

			$data = $subscriber_data[ $user_id ];
			$last_order_date = $data['last_order_date'] ?? '';
			$next_renewal_date = $data['next_renewal_date'] ?? '';
			$active_subscription_products = $data['active_subscription_products'] ?? '';
			$active_subscription_products = ! empty( $active_subscription_products ) ? json_decode( $active_subscription_products, true ) : [];
			switch ( $field ) {
				case 'sublium_has_active_subs':
					$val = isset( $data['active_count'] ) && $data['active_count'] > 0 ? 'Yes' : 'No';
					break;
				case 'sublium_l_subscription_days':
					$val = ! empty( $last_order_date ) ? date_diff( new DateTime( $last_order_date ), new DateTime( 'now' ) )->days : 0;
					break;
				case 'sublium_next_renewal_days':
					$val = ! empty( $next_renewal_date ) ? date_diff( new DateTime( $next_renewal_date ), new DateTime( 'now' ) )->days : 0;
					break;
				case 'sublium_l_subscription_date':
					$val = $last_order_date;
					break;
				case 'sublium_next_renewal_date':
					$val = $next_renewal_date;
					break;
				case 'sublium_renewal_count':
					$val = intval( $data['renewals_count'] );
					break;
				case 'sublium_active_subs_product':
					$val = implode( ', ', $active_subscription_products );
					break;
				case 'sublium_active_subs_count':
					$val = intval( $data['active_count'] );
					break;
			}
			
			return $val;
		}
	}

$ins = BWFCRM_Sublium_WCS_Column_Preferences::get_instance();

}