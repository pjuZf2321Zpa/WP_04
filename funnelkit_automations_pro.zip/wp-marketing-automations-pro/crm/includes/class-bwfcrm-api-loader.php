<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Class BWFCRM_Api_Loader
 *
 * @package Autonami
 */
#[AllowDynamicProperties]
class BWFCRM_API_Loader {
	private static $ins = null;

	/**
	 * @var array $registered_apis
	 */
	private static $registered_apis = array();

	/**
	 * Supported HTTP Method Constants
	 */
	const POST = 'POST';
	const GET = 'GET';
	const PUT = 'PUT';
	const PATCH = 'PATCH';
	const DELETE = 'DELETE';

	/**
	 * Route prefix → API subdirectory mapping.
	 * Two-level keys checked first (longest match wins).
	 *
	 * Strict matching: unmapped prefix or wrong namespace → load nothing.
	 * Every Pro-owned prefix MUST be listed here. Lite-only prefixes can be
	 * mapped to an empty array to make the "Pro has nothing here" intent explicit.
	 */
	private static $route_map = array(
		// Two-level prefixes (overlaps)
		'contact/export'            => array( 'exporter' ),
		'contact/filters'           => array( 'filters' ),
		'import/csv'                => array( 'csv-importer' ),
		'import/csv-upload'         => array( 'csv-importer' ),
		'import/processes'          => array( 'importer' ),
		'templates/export'          => array( 'templates' ),
		'templates/import'          => array( 'templates' ),

		// Single-level prefixes
		'contacts'                  => array( 'contacts' ),
		// Legacy backward-compat: old Lite (< fix/4604) calls un-versioned /fields and /all/fields.
		// TODO: remove together with class-bwfcrm-api-fields-controller.php once min Lite ships the /v3 repoint.
		'fields'                    => array( 'fields' ),
		'all'                       => array( 'fields' ),
		'analytics'                 => array( 'reports' ),
		'audience'                  => array( 'audience' ),
		'audiences'                 => array( 'audience' ),
		'automation'                => array( 'automations' ),
		'broadcast'                 => array( 'campaigns' ),
		'broadcasts'                => array( 'campaigns' ),
		'broadcasts-lookup'         => array( 'campaigns' ),
		'broadcasts-stats'          => array( 'campaigns' ),
		'bulk-action'               => array( 'bulk-actions' ),
		'bulk-actions'              => array( 'bulk-actions' ),
		'category'                  => array( 'categories' ),
		'db-update'                 => array( 'db-update' ),
		'filters'                   => array( 'filters' ),
		'form-feeds'                => array( 'forms' ),
		'funnelkit'                 => array( 'funnelkit' ),
		'generic-rules'             => array( 'block-editor' ),
		'layout'                    => array( 'layout' ),
		'layouts'                   => array( 'layout' ),
		'link-trigger'              => array( 'link-triggers' ),
		'link-triggers'             => array( 'link-triggers' ),
		'messages'                  => array( 'conversations' ),
		'products'                  => array( 'wc' ),
		'send-test-email'           => array( 'conversations' ),
		'send-test-sms'             => array( 'conversations' ),
		'send-test-whatsapp-message' => array( 'conversations' ),
		'template'                  => array( 'templates' ),
		'templates'                 => array( 'templates', 'conversations' ),
		'transactional-activity'    => array( 'transactional-mails' ),
		'transactional-mail'        => array( 'transactional-mails' ),
		'transactional-mails'       => array( 'transactional-mails' ),
		'upload-image'              => array( 'conversations' ),
		'wlm'                       => array( 'wlm' ),
		'wc'                        => array( 'wc' ),
		'get-api-keys'              => array( 'rest-api-keys' ),
		'create-api-key'            => array( 'rest-api-keys' ),
		'update-api-key'            => array( 'rest-api-keys' ),
		'delete-api-key'            => array( 'rest-api-keys' ),
	);

	/**
	 * BWFCRM_Api_Loader constructor.
	 */
	public function __construct() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * Return the object of current class
	 *
	 * @return null|BWFCRM_Api_Loader
	 */
	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	/**
	 * Load API class files only from specified subdirectories.
	 *
	 * @param array $dirs Directory names under /crm/includes/api/.
	 */
	private static function load_api_classes_for_dirs( $dirs ) {
		$api_dir = __DIR__ . '/api';

		foreach ( $dirs as $dir_name ) {
			$dir_path = $api_dir . '/' . $dir_name;
			if ( ! is_dir( $dir_path ) ) {
				continue;
			}
			foreach ( glob( $dir_path . '/class-*.php' ) as $_field_filename ) {
				if ( ! is_readable( $_field_filename ) ) { // survive update file-swap / partial deploy
					continue;
				}
				require_once $_field_filename;
			}
		}

		do_action( 'bwfcrm_api_classes_loaded' );
	}

	/**
	 * Determine which API subdirectories match the current REST request URL.
	 *
	 * Strict matching:
	 *   - Wrong namespace (request not for autonami-app) → null (skip loading)
	 *   - Right namespace but unmapped prefix            → null (skip loading)
	 *   - Mapped to empty array (Lite-owned prefix)      → []   (skip loading)
	 *   - Mapped prefix                                  → array of directory names
	 *
	 * @return array|null Array of directory names; null means no match.
	 */
	private static function get_matching_directories() {
		$rest_route = isset( $_GET['rest_route'] ) ? sanitize_text_field( wp_unslash( $_GET['rest_route'] ) ) : ''; // phpcs:ignore
		if ( empty( $rest_route ) && isset( $_SERVER['REQUEST_URI'] ) ) {
			$rest_route = esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) );
		}

		if ( empty( $rest_route ) || ! defined( 'BWFAN_API_NAMESPACE' ) ) {
			return null;
		}

		// Strip the query string first so a namespace-like value in a query parameter
		// (e.g. /wp-json/wc/v3/x?ref=autonami-app/y) cannot match the namespace.
		$qmark = strpos( $rest_route, '?' );
		if ( false !== $qmark ) {
			$rest_route = substr( $rest_route, 0, $qmark );
		}

		$ns  = BWFAN_API_NAMESPACE;
		$pos = strpos( $rest_route, $ns );
		if ( false === $pos ) {
			return null;
		}

		$api_path = substr( $rest_route, $pos + strlen( $ns ) );
		$api_path = ltrim( $api_path, '/' );

		$qpos = strpos( $api_path, '?' );
		if ( false !== $qpos ) {
			$api_path = substr( $api_path, 0, $qpos );
		}

		if ( empty( $api_path ) ) {
			return null;
		}

		$parts = explode( '/', $api_path );

		// Two-level match first
		if ( count( $parts ) >= 2 ) {
			$two_level = $parts[0] . '/' . $parts[1];
			if ( isset( self::$route_map[ $two_level ] ) ) {
				/**
				 * csv-importer controllers need the legacy importer stack, which
				 * does not load when Lite >= 3.7.0 (see BWFCRM_Importer) — resolving
				 * them would fatal on the missing classes, so the routes cleanly
				 * disappear instead. Their only caller is an unrouted legacy screen.
				 */
				if ( in_array( 'csv-importer', self::$route_map[ $two_level ], true ) && ! BWFCRM_Core::legacy_importer_needed() ) {
					return null;
				}

				return self::$route_map[ $two_level ];
			}

			// Handle contact/{id}/export
			if ( is_numeric( $parts[1] ) && count( $parts ) >= 3 ) {
				if ( 'contact' === $parts[0] && 'export' === $parts[2] ) {
					return array( 'exporter' );
				}
			}
		}

		// Single-level match
		if ( is_numeric( $parts[0] ) ) {
			return null;
		}

		if ( isset( self::$route_map[ $parts[0] ] ) ) {
			return self::$route_map[ $parts[0] ];
		}

		return null;
	}

	public static function register( $api_class ) {
		if ( ! class_exists( $api_class ) || ! method_exists( $api_class, 'get_instance' ) ) {
			return;
		}

		if ( empty( $api_class ) ) {
			return;
		}

		$api_slug = strtolower( $api_class );
		if ( false === strpos( $api_slug, 'bwfcrm_api_' ) && false === strpos( $api_slug, 'bwfan\rest_api' ) ) {
			return;
		}

		if ( false !== strpos( $api_slug, 'bwfcrm_api_' ) ) {
			$api_slug = explode( 'bwfcrm_api_', $api_slug )[1];
		}

		/** @var BWFCRM_API_Base $api_obj */
		$api_obj = $api_class::get_instance();

		if ( empty( $api_obj->route ) ) {
			return;
		}

		self::$registered_apis[ $api_obj->route ][ $api_slug ] = $api_obj;
	}

	public static function register_routes() {
		if ( ! defined( 'BWFAN_API_NAMESPACE' ) ) {
			return;
		}

		// Route-level loading: resolve the target subdirectory(ies) from the request
		// URL and load only those. When the request is not for the autonami-app
		// namespace, or its prefix is not mapped, load nothing.
		$dirs = self::get_matching_directories();
		if ( ! empty( $dirs ) ) {
			self::load_api_classes_for_dirs( $dirs );
		}

		foreach ( self::$registered_apis as $route => $registered_api ) {
			if ( empty( $registered_api ) ) {
				continue;
			}

			$api_group = array_map( function ( $api ) {
				/** Added support for WC_REST_Controllers */
				if ( class_exists( 'WC_REST_Controller' ) && $api instanceof WC_REST_Controller ) {
					$api->register_routes();

					return false;
				}

				/** @var BWFCRM_API_Base $api */
				if ( empty( $api->method ) ) {
					return false;
				}

				$route_args = array(
					'methods'             => $api->method,
					'callback'            => array( $api, 'api_call' ),
					'permission_callback' => '__return_true',
					'show_in_index'       => false,
				);

				if ( false === $api->public_api ) {
					$route_args['permission_callback'] = [ $api, 'rest_permission_callback' ];
				}

				if ( is_array( $api->request_args ) && ! empty( $api->request_args ) ) {
					$route_args['args'] = $api->request_args;
				}

				return $route_args;
			}, $registered_api );

			$api_group = array_filter( $api_group );
			$api_group = array_values( $api_group );

			register_rest_route( BWFAN_API_NAMESPACE, $route, $api_group );
		}

		do_action( 'bwfcrm_api_routes_registered', self::$registered_apis );
	}

}

if ( class_exists( 'BWFCRM_Core' ) ) {
	BWFCRM_Core::register( 'ap', 'BWFCRM_API_Loader' );
}
