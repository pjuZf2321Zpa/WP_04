<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Skip if the parent abstract is not loaded yet (e.g. old loader still in memory during a plugin-update file-swap); prevents a fatal that would abort the update.
if ( ! class_exists( 'BWFCRM_API_Controller' ) ) {
	return;
}

class BWFCRM_API_Templates_Controller extends BWFCRM_API_Controller {

	public static $ins;

	public $templates = array();
	public $total_count = 0;

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	protected function register_routes() {

		/** GET /templates */
		$this->add_route( '/templates', [
			[ 'GET', 'get_templates', array(
				'search'   => array(
					'description' => __( 'Search from name', 'wp-marketing-automations-pro' ),
					'type'        => 'string',
				),
				'ids'      => array(
					'description' => __( 'Search from template ids', 'wp-marketing-automations-pro' ),
					'type'        => 'string'
				),
				'category' => array(
					'description' => __( 'Template category filter', 'wp-marketing-automations-pro' ),
					'type'        => 'string',
				),
			) ],
		] );

		/** GET /templates/export/ */
		$this->add_route( '/templates/export/', [
			[ 'GET', 'export_templates' ],
		] );

		/** POST /templates/import/ */
		$this->add_route( '/templates/import/', [
			[ 'POST', 'import_templates' ],
		] );

		/** GET /templates/{id}/export/ */
		$this->add_route( '/templates/(?P<template_id>[\d]+)/export/', [
			[ 'GET', 'export_single_template' ],
		] );

		/** POST + GET + DELETE /template/{id} */
		$this->add_route( '/template', [
			[ 'POST', 'create_template' ],
		] );

		/** POST + DELETE /template/{id} */
		$this->add_route( '/template/(?P<template_id>[\d]+)', [
			[ 'GET', 'get_template', array(
				'template_id' => array(
					'description' => __( 'Template ID to retrieve', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ],
			[ 'POST', 'update_template', array(
				'template_id' => array(
					'description' => __( 'Template ID to update', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ],
			[ 'DELETE', 'delete_template' ],
		] );

		/** GET /template/{id}/clone */
		$this->add_route( '/template/(?P<template_id>[\d]+)/clone', [
			[ 'GET', 'clone_template', array(
				'template_id' => array(
					'description' => __( 'Template ID whose data to be cloned.', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ],
		] );

		/** POST /template/{id}/save-email-content */
		$this->add_route( '/template/(?P<template_id>[\d]+)/save-email-content', [
			[ 'POST', 'save_template_email_content', array(
				'template_id' => array(
					'description' => __( 'Template ID to update', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ],
		] );
	}

	/**
	 * GET /templates
	 */
	public function get_templates() {
		/** if isset search param then get the tag by name **/
		$search       = ! empty( $this->get_sanitized_arg( 'search', 'text_field' ) ) ? $this->get_sanitized_arg( 'search', 'text_field' ) : '';
		$mode         = ! empty( $this->get_sanitized_arg( 'mode', 'text_field' ) ) ? $this->get_sanitized_arg( 'mode', 'text_field' ) : '';
		$template_ids = ! empty( $this->args['ids'] ) ? explode( ',', $this->args['ids'] ) : array();
		$limit        = ! empty( $this->get_sanitized_arg( 'limit', 'text_field' ) ) ? $this->get_sanitized_arg( 'limit', 'text_field' ) : 0;
		$offset       = ! empty( $this->get_sanitized_arg( 'offset', 'text_field' ) ) ? $this->get_sanitized_arg( 'offset', 'text_field' ) : 0;
		$get_template = isset( $this->args['get_template'] ) ? $this->get_sanitized_arg( 'get_template', 'bool' ) : true;
		$category     = ! empty( $this->get_sanitized_arg( 'category', 'key' ) ) ? $this->get_sanitized_arg( 'category', 'text_field' ) : '';

		$templates = BWFAN_Model_Templates::bwfan_get_templates( $offset, $limit, $search, $template_ids, $get_template, $mode, $category );
		if ( ! is_array( $templates ) ) {
			$templates = array();
		}

		$templates = array_map( function ( $template ) {
			if ( ! empty( $template['data'] ) ) {
				$template['data'] = json_decode( $template['data'] );
			}
			if ( isset( $template['template'] ) ) {
				unset( $template['template'] );
			}

			return $template;
		}, $templates );

		$this->total_count = BWFAN_Model_Templates::bwfan_get_templates_count( $search, $template_ids, $mode, $category );

		$this->response_code = 200;

		return $this->success_response( $templates );
	}

	/**
	 * GET /templates/export/
	 */
	public function export_templates() {
		$ids = isset( $this->args['ids'] ) ? explode(',', $this->args['ids'] ) : [];
		$data = BWFCRM_Templates::get_json( $ids );

		$this->response_code = 200;

		return $this->success_response( $data, __( 'Templates exported', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * POST /templates/import/
	 */
	public function import_templates() {
		$this->response_code = 200;

		$files = $this->args['files'];

		$this->response_code = 404;
		if ( empty( $files ) ) {
			return $this->error_response( [], __( 'Import File missing.', 'wp-marketing-automations-pro' ) );
		}

		$file_data = file_get_contents( $files['files']['tmp_name'] );

		$import_file_data = json_decode( $file_data, true );
		if ( empty( $import_file_data ) && ! is_array( $import_file_data ) ) {

			return $this->error_response( [], __( 'Import file data missing', 'wp-marketing-automations-pro' ) );
		}

		$template_id = BWFCRM_Templates::import( $import_file_data );
		if ( empty( $template_id ) ) {

			return $this->error_response( __( 'Invalid json file', 'wp-marketing-automations-pro' ) );
		}

		$this->response_code = 200;

		return $this->success_response( [ 'template_id' => $template_id ], __( 'Templates imported', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * GET /templates/{id}/export/
	 */
	public function export_single_template() {
		$this->response_code = 200;

		$template_id = ( isset( $this->args['template_id'] ) && '' !== $this->args['template_id'] ) ? $this->args['template_id'] : 0;
		$data = BWFCRM_Templates::get_json( $template_id );

		$this->response_code = 200;

		return $this->success_response( $data, __( 'Template exported', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * POST /template
	 */
	public function create_template() {
		$this->response_code = 200;

		if ( isset( $this->args['content'] ) ) {
			$content    = BWFAN_Common::is_json( $this->args['content'] ) ? json_decode( $this->args['content'], true ) : [];
			$this->args = wp_parse_args( $content, $this->args );
		}
		$title       = $this->get_sanitized_arg( 'title', 'text_field' );
		$subject     = $this->get_sanitized_arg( 'subject', 'text_field' );
		$template    = $this->args['template'] ?? null;
		$type        = $this->get_sanitized_arg( 'type', 'text_field' );
		$mode        = $this->get_sanitized_arg( 'mode', 'text_field' );
		$escape_body = $this->get_sanitized_arg( 'escape_body', 'text_field' );
		$data        = $this->args['data'] ?? null;

		if ( empty( $title ) ) {
			$this->response_code = 400;
			$response            = __( 'Name is required', 'wp-marketing-automations-pro' );

			return $this->error_response( $response );
		}

		if ( empty( $subject ) && ! $escape_body ) {
			$this->response_code = 400;
			$response            = __( 'Subject is required', 'wp-marketing-automations-pro' );

			return $this->error_response( $response );
		}

		if ( empty( $template ) && ! $escape_body ) {
			$this->response_code = 400;
			$response            = __( 'Email body is required', 'wp-marketing-automations-pro' );

			return $this->error_response( $response );
		}

		$already_exists = BWFAN_Model_Templates::bwfan_check_template_exists( 'title', $title );
		if ( absint( $already_exists ) > 0 ) {
			$title = "$title - $already_exists";
		}

		$create_time = current_time( 'mysql', 1 );

		$template_data = [
			'title'      => $title,
			'template'   => $template,
			'subject'    => $subject,
			'type'       => intval( $type ) > 0 ? intval( $type ) : 1,
			'mode'       => intval( $mode ) > 0 ? intval( $mode ) : 5,
			'canned'     => 1,
			'created_at' => $create_time,
			'updated_at' => $create_time,
			'data'       => BWFAN_Common::is_json( $data ) ? $data : wp_json_encode( $data ),
		];

		$result = BWFAN_Model_Templates::bwfan_create_new_template( $template_data );
		if ( empty( $result ) ) {
			$this->response_code = 500;

			return $this->error_response( __( 'Unable to create template', 'wp-marketing-automations-pro' ) );
		}

		return $this->success_response( [ 'id' => $result ], __( 'Template Saved Successfully', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * GET /template/{id}
	 */
	public function get_template() {
		$template_id = $this->get_sanitized_arg( 'template_id' );
		if ( empty( $template_id ) ) {
			return $this->error_response( __( 'Invalid / Empty template ID provided', 'wp-marketing-automations-pro' ), null, 400 );
		}

		$template = BWFAN_Model_Templates::bwfan_get_template( $template_id );

		if ( empty( $template ) ) {
			return $this->error_response( __( 'Template not found with provided ID', 'wp-marketing-automations-pro' ), null, 400 );
		}

		if ( ! empty( $template['data'] ) ) {
			$template['data'] = json_decode( $template['data'] );
		}

		$this->response_code = 200;

		return $this->success_response( $template );
	}

	/**
	 * POST /template/{id}
	 */
	public function update_template() {
		if ( isset( $this->args['content'] ) ) {
			$content    = BWFAN_Common::is_json( $this->args['content'] ) ? json_decode( $this->args['content'], true ) : [];
			$this->args = wp_parse_args( $content, $this->args );
		}
		$template_id = $this->get_sanitized_arg( 'template_id' );
		if ( empty( $template_id ) ) {
			return $this->error_response( __( 'Invalid / Empty template ID provided', 'wp-marketing-automations-pro' ), null, 400 );
		}

		$title   = $this->get_sanitized_arg( 'title', 'text_field' );
		$subject = $this->get_sanitized_arg( 'subject', 'text_field' );
		$onlytitle = $this->get_sanitized_arg( 'onlytitle', 'text_field' );

		$template = $this->args['template'] ?? null;

		$type = $this->get_sanitized_arg( 'type', 'text_field' );
		$mode = $this->get_sanitized_arg( 'mode', 'text_field' );
		$data = $this->args['data'] ?? null;

		if ( empty( $title ) ) {
			$this->response_code = 400;
			$response            = __( 'Oops Title not entered, enter title to save template', 'wp-marketing-automations-pro' );

			return $this->error_response( $response );
		}

		if ( empty( $subject ) && ! $onlytitle ) {
			$this->response_code = 400;
			$response            = __( 'Oops Subject not entered, enter subject to save template', 'wp-marketing-automations-pro' );

			return $this->error_response( $response );
		}

		if ( empty( $template ) && ! $onlytitle ) {
			$this->response_code = 400;
			$response            = __( 'Oops Template is empty, enter content to save template', 'wp-marketing-automations-pro' );

			return $this->error_response( $response );
		}

		$exists = BWFAN_Model_Templates::bwfan_check_template_exists( 'ID', $template_id );
		if ( ! $exists ) {
			$this->response_code = 400;
			$response            = __( 'Template does not exists with id : ', 'wp-marketing-automations-pro' ) . $template_id;

			return $this->error_response( $response );
		}

		$create_time = current_time( 'mysql', 1 );

		if( $onlytitle ) {
			$template_data = [
				'title'      => $title,
				'updated_at' => $create_time,
			];
		} else {
			$template_data = [
				'title'      => $title,
				'template'   => $template,
				'subject'    => $subject,
				'type'       => intval( $type ) > 0 ? intval( $type ) : 1,
				'mode'       => intval( $mode ) > 0 ? intval( $mode ) : 1,
				'canned'     => 1,
				'updated_at' => $create_time,
				'data'       => BWFAN_Common::is_json( $data ) ? $data : wp_json_encode( $data ),
			];
		}


		$result = BWFAN_Model_Templates::bwfan_update_template( $template_id, $template_data );
		if ( ! $result ) {
			$this->response_code = 500;

			return $this->error_response( __( 'Unable to update template', 'wp-marketing-automations-pro' ) );
		}

		return $this->success_response( [], __( 'Template Updated', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * DELETE /template/{id}
	 */
	public function delete_template() {
		$template_id = $this->get_sanitized_arg( 'template_id', 'key' );

		if ( empty( $template_id ) ) {
			$this->response_code = 404;
			$response            = __( 'Template ID is mandatory', 'wp-marketing-automations-pro' );

			return $this->error_response( $response );
		}
		/** if the provided id doesn't exists */
		$already_exists = BWFAN_Model_Templates::bwfan_check_template_exists( 'ID', $template_id );
		if ( ! $already_exists ) {
			$this->response_code = 400;
			$response            = __( "Template doesn't exists with ID : ", 'wp-marketing-automations-pro' ) . $template_id;

			return $this->error_response( $response );
		}
		if ( is_string( $template_id ) ) {
			$template_id = array( $template_id );
		}
		$delete_template = BWFAN_Model_Templates::bwf_delete_template( $template_id );

		if ( false === $delete_template ) {
			$this->response_code = 404;

			$response = __( 'Unable to delete the Template', 'wp-marketing-automations-pro' );

			return $this->error_response( $response );
		}

		$this->response_code = 200;
		$success_message     = __( 'Template deleted', 'wp-marketing-automations-pro' );

		return $this->success_response( [], $success_message );
	}

	/**
	 * GET /template/{id}/clone
	 */
	public function clone_template() {
		$template_id = $this->get_sanitized_arg( 'template_id', 'key' );
		if ( intval( $template_id ) > 0 ) {

			$template_data       = BWFAN_Model_Templates::clone_template( $template_id );
			$this->response_code = $template_data['status'];
			if ( $template_data['status'] === 200 ) {
				// The copy's id, when the model reports it.
				$result = ! empty( $template_data['template_id'] ) ? [ 'id' => absint( $template_data['template_id'] ) ] : [];

				return $this->success_response( $result, $template_data['message'] );
			} else {
				return $this->error_response( $template_data['message'] );
			}
		} else {
			$this->response_code = 404;

			return $this->error_response( __( 'Please provide a valid template id.', 'wp-marketing-automations-pro' ) );
		}
	}

	/**
	 * POST /template/{id}/save-email-content
	 */
	public function save_template_email_content() {
		if ( isset( $this->args['content'] ) ) {
			$content    = BWFAN_Common::is_json( $this->args['content'] ) ? json_decode( $this->args['content'], true ) : [];
			$this->args = wp_parse_args( $content, $this->args );
		}
		$template_id = $this->get_sanitized_arg( 'template_id' );
		if ( empty( $template_id ) ) {
			return $this->error_response( __( 'Invalid / Empty template ID provided', 'wp-marketing-automations-pro' ), null, 400 );
		}

		$template = $this->args['template'] ?? null;
		$data     = $this->args['data'] ?? null;
		$subject  = isset( $this->args['subject'] ) ? $this->args['subject'] : '';
		$mode     = $this->args['mode'] ?? null;

		$exists = BWFAN_Model_Templates::bwfan_check_template_exists( 'ID', $template_id );
		if ( ! $exists ) {
			$this->response_code = 400;
			$response            = __( 'Template does not exists with id : ', 'wp-marketing-automations-pro' ) . $template_id;

			return $this->error_response( $response );
		}

		$create_time = current_time( 'mysql', 1 );

		$template_data = [
			'template'   => $template,
			'data'       => BWFAN_Common::is_json( $data ) ? $data : wp_json_encode( $data ),
			'mode'       => ! empty( $mode ) ? intval($mode):  4,
			'updated_at' => $create_time,
		];
		if ( ! empty( $subject ) ) {
			$template_data[ 'subject' ] = $subject;
		}

		$result = BWFAN_Model_Templates::bwfan_update_template( $template_id, $template_data );
		if ( ! $result ) {
			$this->response_code = 500;

			return $this->error_response( __( 'Unable to update template', 'wp-marketing-automations-pro' ) );
		}

		$response_data = BWFAN_Model_Templates::bwfan_get_template( $template_id );

		if ( ! empty( $response_data['data'] ) ) {
			$response_data['data'] = json_decode( $response_data['data'] );
		}

		return $this->success_response( $response_data, __( 'Template Updated Successfully', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * Return template total count
	 *
	 * @return int
	 */
	public function get_result_total_count() {
		return $this->total_count;
	}
}

BWFCRM_API_Templates_Controller::get_instance();
