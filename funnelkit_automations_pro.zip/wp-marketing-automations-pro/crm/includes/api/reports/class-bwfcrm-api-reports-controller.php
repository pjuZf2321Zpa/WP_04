<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Skip if the parent abstract is not loaded yet (e.g. old loader still in memory during a plugin-update file-swap); prevents a fatal that would abort the update.
if ( ! class_exists( 'BWFCRM_API_Controller' ) ) {
	return;
}

class BWFCRM_API_Reports_Controller extends BWFCRM_API_Controller {

	public static $ins;
	public $total_count = 0;
	public $contact;
	private $aid = 0;

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	public function __construct() {
		$this->pagination         = new stdClass();
		$this->pagination->offset = 0;
		$this->pagination->limit  = 10;
		parent::__construct();
	}

	public function default_args_values() {
		return array(
			'after'    => '',
			'before'   => '',
			'interval' => '',
			'type'     => '',
			'oid'      => 0,
			'mode'     => 1,
			'contact'  => 0,
			'search'   => '',
			'version'  => 2,
			'offset'   => 0,
			'limit'    => 0,
		);
	}

	protected function register_routes() {
		// GET /analytics/contacts
		$this->add_route( '/analytics/contacts', array(
			array( 'GET', 'get_contacts_report' ),
		) );

		// GET /analytics/direct-emails/tabular
		$this->add_route( '/analytics/direct-emails/tabular', array(
			array( 'GET', 'get_direct_emails_tabular' ),
		) );

		// GET /analytics/emails/chart
		$this->add_route( '/analytics/emails/chart', array(
			array( 'GET', 'get_email_report' ),
		) );

		// GET /analytics/emails/tabular
		$this->add_route( '/analytics/emails/tabular', array(
			array( 'GET', 'get_emails_tabular' ),
		) );

		// GET /analytics/engagement
		$this->add_route( '/analytics/engagement', array(
			array( 'GET', 'get_engagement_report' ),
		) );

		// GET /analytics/engagements/search
		$this->add_route( '/analytics/engagements/search', array(
			array( 'GET', 'get_engagements_search', array(
				'offset' => array(
					'description' => __( 'Templates list Offset', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
				'limit'  => array(
					'description' => __( 'Per page limit', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ),
		) );

		// GET /analytics/entity/data
		$this->add_route( '/analytics/entity/data', array(
			array( 'GET', 'get_entity_data' ),
		) );
	}

	/**
	 * GET /analytics/contacts
	 */
	public function get_contacts_report() {

		$response['totals'] = $this->prepare_contacts_report_item();

		$response['intervals'] = $this->prepare_contacts_report_item( 'interval' );

		$this->response_code = 200;

		return $this->success_response( $response );
	}

	/**
	 * @param string $is_interval
	 *
	 * @return array
	 */
	public function prepare_contacts_report_item( $is_interval = '' ) {

		$start_date        = ( isset( $this->args['after'] ) && '' !== $this->args['after'] ) ? $this->args['after'] : BWFCRM_Dashboards::default_date( WEEK_IN_SECONDS )->format( BWFCRM_Dashboards::$sql_datetime_format );
		$end_date          = ( isset( $this->args['before'] ) && '' !== $this->args['before'] ) ? $this->args['before'] : BWFCRM_Dashboards::default_date()->format( BWFCRM_Dashboards::$sql_datetime_format );
		$intervals_request = ( isset( $this->args['interval'] ) && '' !== $this->args['interval'] ) ? $this->args['interval'] : 'week';

		$new_contacts       = BWFCRM_Reports::get_total_contacts( $start_date, $end_date, $is_interval, $intervals_request );
		$new_contacts_count = isset( $new_contacts[0]['contact_counts'] ) ? $new_contacts[0]['contact_counts'] : 0;

		$total_contacts       = BWFCRM_Reports::get_contacts_before_date( $end_date );
		$total_contacts_count = isset( $total_contacts[0]['contact_counts'] ) ? $total_contacts[0]['contact_counts'] : 0;

		$total_customers       = BWFCRM_Reports::get_customers_before_date( $end_date );
		$total_customers_count = isset( $total_customers[0]['contact_counts'] ) ? $total_customers[0]['contact_counts'] : 0;

		$total_unsubs       = BWFCRM_Reports::get_unsubscribers_total( $start_date, $end_date, $is_interval, $intervals_request );
		$total_unsubs_count = isset( $total_unsubs[0]['unsubs_count'] ) ? $total_unsubs[0]['unsubs_count'] : 0;


		$result    = [];
		$intervals = [];
		/** when interval present */
		if ( ! empty( $is_interval ) ) {
			$intervals_all = BWFCRM_Dashboards::intervals_between( $start_date, $end_date, $intervals_request );

			$total_contacts_start       = BWFCRM_Reports::get_contacts_before_date( $start_date );
			$total_contacts_start_count = isset( $total_contacts_start[0]['contact_counts'] ) ? $total_contacts_start[0]['contact_counts'] : 0;

			foreach ( $intervals_all as $all_interval ) {
				$interval   = $all_interval['time_interval'];
				$start_date = $all_interval['start_date'];
				$end_date   = $all_interval['end_date'];

				$new_contact       = BWFCRM_Dashboards::maybe_interval_exists( $new_contacts, 'time_interval', $interval );
				$new_contact_count = isset( $new_contact[0]['contact_counts'] ) ? $new_contact[0]['contact_counts'] : 0;

				$total_contacts_start_count = $total_contacts_start_count + $new_contact_count;

				$total_customers       = BWFCRM_Reports::get_customers_before_date( $end_date );
				$total_customers_count = isset( $total_customers[0]['contact_counts'] ) ? $total_customers[0]['contact_counts'] : 0;

				$total_unsub       = BWFCRM_Dashboards::maybe_interval_exists( $total_unsubs, 'time_interval', $interval );
				$total_unsub_count = isset( $total_unsub[0]['unsubs_count'] ) ? $total_unsub[0]['unsubs_count'] : 0;

				$intervals['interval']       = $interval;
				$intervals['start_date']     = $start_date;
				$intervals['date_start_gmt'] = BWFCRM_Dashboards::convert_local_datetime_to_gmt( $start_date )->format( BWFCRM_Dashboards::$sql_datetime_format );
				$intervals['end_date']       = $end_date;
				$intervals['date_end_gmt']   = BWFCRM_Dashboards::convert_local_datetime_to_gmt( $end_date )->format( BWFCRM_Dashboards::$sql_datetime_format );

				$intervals['subtotals'] = array(
					'total_contacts'  => absint( $total_contacts_start_count ),
					'total_customers' => absint( $total_customers_count ),
					'new_contacts'    => absint( $new_contact_count ),
					'unsubscribers'   => absint( $total_unsub_count )
				);
				$result[]               = $intervals;
			}
		} else {
			$result = [
				'total_contacts'  => absint( $total_contacts_count ),
				'total_customers' => absint( $total_customers_count ),
				'new_contacts'    => absint( $new_contacts_count ),
				'unsubscribers'   => absint( $total_unsubs_count )
			];

		}

		return $result;
	}

	/**
	 * GET /analytics/direct-emails/tabular
	 */
	public function get_direct_emails_tabular() {

		$start_date    = ( isset( $this->args['after'] ) && '' !== $this->args['after'] ) ? $this->args['after'] : BWFCRM_Dashboards::default_date( WEEK_IN_SECONDS )->format( BWFCRM_Dashboards::$sql_datetime_format );
		$end_date      = ( isset( $this->args['before'] ) && '' !== $this->args['before'] ) ? $this->args['before'] : BWFCRM_Dashboards::default_date()->format( BWFCRM_Dashboards::$sql_datetime_format );
		$type          = ( isset( $this->args['type'] ) && '' !== $this->args['type'] ) ? $this->args['type'] : '';
		$offset        = ! empty( $this->args['limit'] ) ? absint( $this->args['limit'] ) : 0;
		$limit         = ! empty( $this->args['offset'] ) ? absint( $this->args['offset'] ) : 0;
		$mode          = ! empty( $this->args['mode'] ) ? absint( $this->args['mode'] ) : 1;

		$conversations = BWFCRM_Reports::get_direct_conversations_with_template( $start_date, $end_date, $type, $limit, $offset, $mode );

		if ( ! empty( $conversations ) ) {
			$conversations[ 'data' ] = array_map( function( $con ) {
				if ( isset( $con['author_id'] ) && absint( $con['author_id'] ) > 0 ) {
					$user = get_user_by( 'id', absint( $con['author_id'] ) );
					if ( $user instanceof WP_User ) {
						$con['author'] = array(
							'email' => $user->user_email,
							'name'  => $user->display_name,
							'id'    => $user->ID,
							'link'  => add_query_arg( 'user_id', $user->ID, admin_url( 'user-edit.php' ) ),
						);
						$crmProfile      = bwf_get_contact( $user->ID, $user->user_email );
						if ( $crmProfile && $crmProfile instanceof WooFunnels_Contact && $crmProfile->get_id() > 0 ) {
							$con['author']['contact'] = $crmProfile->id;
						}
					}
					return $con;
				}
			}, $conversations[ 'data' ]);
		}

		if ( isset( $conversations['total_count'] ) ) {
			$this->total_count = $conversations['total_count'];
			unset( $conversations['total_count'] );
		}

		$this->response_code = 200;

		return $this->success_response( $conversations );
	}

	/**
	 * GET /analytics/emails/chart
	 */
	public function get_email_report() {
		$response = [];

		$response['totals']          = $this->prepare_email_report_item();
		$response['automation_data'] = $this->get_automation_data();

		$response['intervals'] = $this->prepare_email_report_item( 'interval' );

		$this->response_code = 200;

		return $this->success_response( $response );
	}

	/**
	 * @param $is_interval
	 *
	 * @return array
	 * @throws Exception
	 */
	public function prepare_email_report_item( $is_interval = '' ) {
		$start_date        = ( isset( $this->args['after'] ) && '' !== $this->args['after'] ) ? $this->args['after'] : BWFCRM_Dashboards::default_date( WEEK_IN_SECONDS )->format( BWFCRM_Dashboards::$sql_datetime_format );
		$end_date          = ( isset( $this->args['before'] ) && '' !== $this->args['before'] ) ? $this->args['before'] : BWFCRM_Dashboards::default_date()->format( BWFCRM_Dashboards::$sql_datetime_format );
		$intervals_request = ( isset( $this->args['interval'] ) && '' !== $this->args['interval'] ) ? $this->args['interval'] : 'day';
		$oid               = ( isset( $this->args['oid'] ) && absint( $this->args['oid'] ) > 0 ) ? absint( $this->args['oid'] ) : 0;
		$type              = ( isset( $this->args['type'] ) && absint( $this->args['type'] ) ) ? $this->args['type'] : 0;
		$mode              = ( isset( $this->args['mode'] ) && absint( $this->args['mode'] ) ) ? $this->args['mode'] : 1;
		$is_contact        = isset( $this->args['contact'] ) ? $this->args['contact'] : 0;

		$automation_obj = BWFAN_Automation_V2::get_instance( $oid );
		if ( empty( $automation_obj->error ) ) {
			$this->aid = $oid;
		}

		if ( $is_contact ) {
			return $this->get_automation_contacts_data( $start_date, $end_date, $is_interval, $intervals_request );
		}

		$email_stats   = BWFCRM_Reports::get_email_stats( $start_date, $end_date, $is_interval, $intervals_request, $oid, $type, $mode );
		$intervals_all = BWFCRM_Dashboards::intervals_between( $start_date, $end_date, $intervals_request );

		$open_click_interactions = BWFCRM_Reports::get_interaction_stats_by_date_range( [ $start_date, $end_date ], $type, $oid, $mode );

		$open_click_interactions['open']  = array_column( $open_click_interactions['open'], 'f_open_count', 'f_open' );
		$open_click_interactions['click'] = array_column( $open_click_interactions['click'], 'f_click_count', 'f_click' );

		$interactions_count = $this->total_open_clicks_count( $open_click_interactions );

		$result    = [];
		$intervals = [];

		if ( empty( $is_interval ) ) {
			/** No interval */
			$result = $this->get_email_analytics_subtotals( $email_stats );

			$result['email_open']  = $interactions_count['email_open'];
			$result['email_click'] = $interactions_count['email_click'];

			return $result;
		}

		foreach ( $intervals_all as $all_interval ) {
			$interval   = $all_interval['time_interval'];
			$start_date = $all_interval['start_date'];
			$end_date   = $all_interval['end_date'];

			$o_interaction        = isset( $open_click_interactions['open'][ $interval ] ) ? $open_click_interactions['open'][ $interval ] : 0;
			$c_interaction        = isset( $open_click_interactions['click'][ $interval ] ) ? $open_click_interactions['click'][ $interval ] : 0;
			$email_stats_interval = BWFCRM_Dashboards::maybe_interval_exists( $email_stats, 'time_interval', $interval );
			$conversions          = BWFCRM_Reports::get_conversions( $start_date, $end_date, $oid, $type, $mode );

			if ( isset( $email_stats_interval[0]['conversions'] ) ) {
				$email_stats_interval[0]['conversions'] = $conversions['conversions'];
			}
			if ( isset( $email_stats_interval[0]['revenue'] ) ) {
				$email_stats_interval[0]['revenue'] = $conversions['revenue'];
			}
			$intervals['interval']                   = $interval;
			$intervals['start_date']                 = $start_date;
			$intervals['date_start_gmt']             = BWFCRM_Dashboards::convert_local_datetime_to_gmt( $start_date )->format( BWFCRM_Dashboards::$sql_datetime_format );
			$intervals['end_date']                   = $end_date;
			$intervals['date_end_gmt']               = BWFCRM_Dashboards::convert_local_datetime_to_gmt( $end_date )->format( BWFCRM_Dashboards::$sql_datetime_format );
			$intervals['subtotals']                  = $this->get_email_analytics_subtotals( $email_stats_interval );
			$intervals['subtotals']['email_open']    = absint( $o_interaction );
			$intervals['subtotals']['email_click']   = absint( $c_interaction );
			$intervals['subtotals']['total_orders']  = isset( $conversions['conversions'] ) ? $conversions['conversions'] : 0;
			$intervals['subtotals']['total_revenue'] = isset( $conversions['revenue'] ) ? $conversions['revenue'] : 0;
			$result[]                                = $intervals;
		}

		return $result;
	}

	public function get_email_analytics_subtotals( $email_stats ) {
		$open_count  = ! isset( $email_stats[0]['open_count'] ) ? 0 : $email_stats[0]['open_count'];
		$click_count = ! isset( $email_stats[0]['click_count'] ) ? 0 : $email_stats[0]['click_count'];
		$sent        = ! isset( $email_stats[0]['sent'] ) ? 0 : $email_stats[0]['sent'];
		$open_rate   = $open_count > 0 ? ( $open_count / $sent ) * 100 : 0;
		$click_rate  = $click_count > 0 ? ( $click_count / $sent ) * 100 : 0;

		return [
			'email_sents'   => absint( $sent ),
			'email_open'    => absint( $open_count ),
			'open_rate'     => number_format( $open_rate, 2 ),
			'email_click'   => absint( $click_count ),
			'click_rate'    => number_format( $click_rate, 2 ),
			'total_orders'  => ! isset( $email_stats[0]['conversions'] ) ? 0 : $email_stats[0]['conversions'],
			'total_revenue' => ! isset( $email_stats[0]['revenue'] ) ? 0 : $email_stats[0]['revenue']
		];
	}

	public function get_automation_data() {
		$type = ( isset( $this->args['type'] ) ) ? absint( $this->args['type'] ) : 1;
		$oid  = ( isset( $this->args['oid'] ) && absint( $this->args['oid'] ) > 0 ) ? absint( $this->args['oid'] ) : 0;
		if ( 1 !== $type || empty( $oid ) ) {
			return '';
		}

		return BWFAN_Model_Automations_V2::get_automation( $oid );
	}

	public function total_open_clicks_count( $open_click_interactions ) {
		$opens  = isset( $open_click_interactions['open'] ) ? $open_click_interactions['open'] : [];
		$clicks = isset( $open_click_interactions['click'] ) ? $open_click_interactions['click'] : [];

		return [
			'email_open'  => count( $opens ) > 0 ? array_sum( $opens ) : 0,
			'email_click' => count( $clicks ) > 0 ? array_sum( $clicks ) : 0
		];
	}

	public function get_automation_contacts_data( $start_date, $end_date, $is_interval, $intervals_request ) {
		$aid = ( isset( $this->args['oid'] ) && absint( $this->args['oid'] ) > 0 ) ? absint( $this->args['oid'] ) : 0;

		$active_contacts       = BWFAN_Model_Automation_Contact::get_total_contacts( $aid, $start_date, $end_date, $is_interval, $intervals_request );
		$active_contacts_count = isset( $active_contacts[0]['contact_counts'] ) ? $active_contacts[0]['contact_counts'] : 0;


		$complete_contacts       = BWFAN_Model_Automation_Complete_Contact::get_total_contacts( $aid, $start_date, $end_date, $is_interval, $intervals_request );
		$complete_contacts_count = isset( $complete_contacts[0]['contact_counts'] ) ? $complete_contacts[0]['contact_counts'] : 0;

		$total_unsubs       = BWFCRM_Reports::get_unsubscribers_total( $start_date, $end_date, $is_interval, $intervals_request, $aid );
		$total_unsubs_count = isset( $total_unsubs[0]['unsubs_count'] ) ? $total_unsubs[0]['unsubs_count'] : 0;

		$conversions   = BWFAN_Model_Conversions::get_automation_revenue( $aid, $start_date, $end_date, $is_interval, $intervals_request );
		$total_revenue = isset( $conversions[0]['revenue'] ) ? (float) $conversions[0]['revenue'] : 0;
		/** AOV */
		$orders = isset( $conversions[0]['conversions'] ) ? absint( $conversions[0]['conversions'] ) : 0;
		$aov    = ! empty( $total_revenue ) && absint( $orders ) > 0 ? $total_revenue / $orders : 0;

		if ( empty( $is_interval ) ) {
			return [
				'active_contacts'   => absint( $active_contacts_count ),
				'complete_contacts' => absint( $complete_contacts_count ),
				'unsubscribers'     => absint( $total_unsubs_count ),
				'revenue'           => $total_revenue,
				'conversions'       => $orders,
				'aov'               => $aov,
			];
		}

		/** when interval present */

		$result        = [];
		$intervals     = [];
		$intervals_all = BWFCRM_Dashboards::intervals_between( $start_date, $end_date, $intervals_request );

		foreach ( $intervals_all as $all_interval ) {
			$interval   = $all_interval['time_interval'];
			$start_date = $all_interval['start_date'];
			$end_date   = $all_interval['end_date'];

			$active_contact       = BWFCRM_Dashboards::maybe_interval_exists( $active_contacts, 'time_interval', $interval );
			$active_contact_count = isset( $active_contact[0]['contact_counts'] ) ? $active_contact[0]['contact_counts'] : 0;

			$complete_contact       = BWFCRM_Dashboards::maybe_interval_exists( $complete_contacts, 'time_interval', $interval );
			$complete_contact_count = isset( $complete_contact[0]['contact_counts'] ) ? $complete_contact[0]['contact_counts'] : 0;

			$total_unsub       = BWFCRM_Dashboards::maybe_interval_exists( $total_unsubs, 'time_interval', $interval );
			$total_unsub_count = isset( $total_unsub[0]['unsubs_count'] ) ? $total_unsub[0]['unsubs_count'] : 0;

			$conversion = BWFCRM_Dashboards::maybe_interval_exists( $conversions, 'time_interval', $interval );
			$revenue    = isset( $conversion[0]['revenue'] ) ? $conversion[0]['revenue'] : 0;
			/** AOV */
			$orders = isset( $conversion[0]['conversions'] ) ? $conversion[0]['conversions'] : 0;
			$aov    = ! empty( $revenue ) && absint( $orders ) > 1 ? $revenue / $orders : 0;

			$intervals['interval']       = $interval;
			$intervals['start_date']     = $start_date;
			$intervals['date_start_gmt'] = BWFCRM_Dashboards::convert_local_datetime_to_gmt( $start_date )->format( BWFCRM_Dashboards::$sql_datetime_format );
			$intervals['end_date']       = $end_date;
			$intervals['date_end_gmt']   = BWFCRM_Dashboards::convert_local_datetime_to_gmt( $end_date )->format( BWFCRM_Dashboards::$sql_datetime_format );

			$intervals['subtotals'] = array(
				'active_contacts'   => absint( $active_contact_count ),
				'complete_contacts' => absint( $complete_contact_count ),
				'unsubscribers'     => absint( $total_unsub_count ),
				'revenue'           => $revenue,
				'conversions'       => $orders,
				'aov'               => $aov,
			);
			$result[]               = $intervals;
		}


		return $result;
	}

	/**
	 * @return array
	 */
	public function get_result_count_data() {
		if ( empty( $this->aid ) ) {
			return [];
		}

		return [
			'failed' => BWFAN_Model_Automation_Contact::get_active_count( $this->aid, 2 )
		];
	}

	/**
	 * GET /analytics/emails/tabular
	 */
	public function get_emails_tabular() {

		$start_date    = ( isset( $this->args['after'] ) && '' !== $this->args['after'] ) ? $this->args['after'] : BWFCRM_Dashboards::default_date( WEEK_IN_SECONDS )->format( BWFCRM_Dashboards::$sql_datetime_format );
		$end_date      = ( isset( $this->args['before'] ) && '' !== $this->args['before'] ) ? $this->args['before'] : BWFCRM_Dashboards::default_date()->format( BWFCRM_Dashboards::$sql_datetime_format );
		$type          = ( isset( $this->args['type'] ) && '' !== $this->args['type'] ) ? $this->args['type'] : '';
		$oid           = ( isset( $this->args['oid'] ) && absint( $this->args['oid'] ) > 0 ) ? [ absint( $this->args['oid'] ) ] : [];

		/**
		 * These two are named backwards AND passed in backwards, and the two
		 * mistakes cancel out: get_conversations_with_template( …, $offset,
		 * $limit ) is handed ( $limit, $offset ) below, so the query still ends
		 * up with the correct LIMIT offset,count.
		 *
		 * Renaming these without also swapping the call arguments silently
		 * breaks paging — the MCP get-performance ability walks this endpoint
		 * by offset and would re-read page one on every pass. Fix both halves
		 * together or neither. get_direct_emails_tabular() above carries the
		 * same pairing.
		 */
		$offset        = ! empty( $this->args['limit'] ) ? absint( $this->args['limit'] ) : 0;
		$limit         = ! empty( $this->args['offset'] ) ? absint( $this->args['offset'] ) : 0;
		$mode          = ! empty( $this->args['mode'] ) ? absint( $this->args['mode'] ) : 1;
		$conversations = BWFCRM_Reports::get_conversations_with_template( $start_date, $end_date, $type, $limit, $offset, $oid, $mode );
		if ( isset( $conversations['total_count'] ) ) {
			$this->total_count = $conversations['total_count'];
			unset( $conversations['total_count'] );
		}

		$this->response_code = 200;

		return $this->success_response( $conversations );
	}

	/**
	 * GET /analytics/engagement
	 */
	public function get_engagement_report() {
		$response = $this->prepare_engagement_item();

		$this->response_code = 200;

		return $this->success_response( $response );
	}

	/**
	 * @return array
	 */
	public function prepare_engagement_item() {

		$start_date               = ( isset( $this->args['after'] ) && '' !== $this->args['after'] ) ? $this->args['after'] : BWFCRM_Dashboards::default_date( WEEK_IN_SECONDS )->format( BWFCRM_Dashboards::$sql_datetime_format );
		$end_date                 = ( isset( $this->args['before'] ) && '' !== $this->args['before'] ) ? $this->args['before'] : BWFCRM_Dashboards::default_date()->format( BWFCRM_Dashboards::$sql_datetime_format );
		$result                   = [];
		$days                     = array( "1", "2", "3", "4", "5", "6", "7" );
		$hours                    = array( "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23" );
		$get_email_trends_by_day  = BWFCRM_Dashboards::get_email_trends( $start_date, $end_date );
		$get_email_trends_by_hour = BWFCRM_Dashboards::get_email_trends( $start_date, $end_date, 'hour' );
		foreach ( $days as $day ) {
			$day_column = empty( $get_email_trends_by_day ) ? [] : array_column( $get_email_trends_by_day, 'day' );
			if ( ! in_array( $day, $day_column ) ) {
				$get_email_trends_by_day[] = array( 'day' => $day, 'mean' => number_format( 0, 4 ), 'open' => 0, 'total' => 0 );
			}
		}
		foreach ( $hours as $hour ) {
			$hour_column = empty( $get_email_trends_by_hour ) ? [] : array_column( $get_email_trends_by_hour, 'hour' );
			if ( ! in_array( $hour, $hour_column ) ) {
				$get_email_trends_by_hour[] = array( 'hour' => $hour, 'mean' => number_format( 0, 4 ), 'open' => 0, 'total' => 0 );
			}
		}

		usort( $get_email_trends_by_day, function ( $item1, $item2 ) {
			return $item1['day'] < $item2['day'] ? - 1 : 1;
		} );

		usort( $get_email_trends_by_hour, function ( $item1, $item2 ) {
			return $item1['hour'] < $item2['hour'] ? - 1 : 1;
		} );

		$result['day']  = $get_email_trends_by_day;
		$result['hour'] = $get_email_trends_by_hour;

		return $result;
	}

	/**
	 * GET /analytics/engagements/search
	 */
	public function get_engagements_search() {
		$search  = ( isset( $this->args['search'] ) && '' !== $this->args['search'] ) ? $this->args['search'] : '';
		$type    = ( isset( $this->args['type'] ) && '' !== $this->args['type'] ) ? $this->args['type'] : 1;
		$mode    = ( isset( $this->args['mode'] ) && '' !== $this->args['mode'] ) ? $this->args['mode'] : 1;
		$version = ( isset( $this->args['version'] ) && '' !== $this->args['version'] ) ? $this->args['version'] : 2;

		$engagements = BWFCRM_Reports::get_engagements( $search, intval( $type ), $mode, $version );
		if ( empty( $engagements ) ) {
			return $this->success_response( [], __( 'Record not found', 'wp-marketing-automations-pro' ) );
		}

		if ( count( $engagements ) > 0 ) {
			$this->total_count = count( $engagements );
		}

		return $this->success_response( $engagements, __( 'Got all engagements', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * GET /analytics/entity/data
	 */
	public function get_entity_data() {
		$type    = ( isset( $this->args['type'] ) && '' !== $this->args['type'] ) ? $this->args['type'] : '';
		$oid     = ( isset( $this->args['oid'] ) && '' !== $this->args['oid'] ) ? $this->args['oid'] : 0;
		$object_title = BWFCRM_Reports::get_object_title( $oid, $type );

		$data = [
			'id'    => $oid,
			'title' => $object_title,
			'type'  => $type
		];

		return $this->success_response( $data );
	}

	public function get_result_total_count() {
		return $this->total_count;
	}
}

BWFCRM_API_Reports_Controller::get_instance();
