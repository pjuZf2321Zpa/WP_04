<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Skip if the parent abstract is not loaded yet (e.g. old loader still in memory during a plugin-update file-swap); prevents a fatal that would abort the update.
if ( ! class_exists( 'BWFCRM_API_Controller' ) ) {
	return;
}

class BWFCRM_API_Bulk_Actions_Controller extends BWFCRM_API_Controller {

	public static $ins;

	public $total_count = 0;
	public $count_data = [];
	public $extra_data = [];

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	protected function register_routes() {

		/** GET /bulk-actions */
		$this->add_route( '/bulk-actions', [
			[ 'GET', 'get_bulk_actions' ],
		] );

		/** DELETE /bulk-actions/delete */
		$this->add_route( '/bulk-actions/delete', [
			[ 'DELETE', 'delete_bulk_action' ],
		] );

		/** POST /bulk-action */
		$this->add_route( '/bulk-action', [
			[ 'POST', 'create_bulk_action' ],
		] );

		/** GET + PUT /bulk-action/{id} */
		$this->add_route( '/bulk-action/(?P<bulk_action_id>[\d]+)', [
			[ 'GET', 'get_bulk_action', array(
				'bulk_action_id' => array(
					'description' => __( 'Bulk Action ID to retrieve', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ],
			[ 'PUT', 'update_bulk_action' ],
		] );

		/** GET /bulk-action/{id}/clone */
		$this->add_route( '/bulk-action/(?P<id>[\d]+)/clone', [
			[ 'GET', 'clone_bulk_action', array(
				'id' => array(
					'description' => __( 'Bulk action ID whose data to be cloned.', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ],
		] );

		/** GET /bulk-action/status/{id} */
		$this->add_route( '/bulk-action/status/(?P<bulk_action_id>[\d]+)', [
			[ 'GET', 'get_bulk_action_status', array(
				'bulk_action_id' => array(
					'description' => __( 'Bulk Action ID to retrieve', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ],
		] );

		/** POST /bulk-action/{id}/update-status */
		$this->add_route( '/bulk-action/(?P<bulk_action_id>[\d]+)/update-status', [
			[ 'POST', 'update_bulk_action_status', array(
				'bulk_action_id' => array(
					'description' => __( 'Bulk Action ID to update', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ],
		] );

		/** GET /bulk-action/download/{id} — nonce-based auth (no cookie) scoped to this route only. */
		$this->add_route( 'bulk-action/download/(?P<bulk_action_id>[\d]+)', [
			[ 'GET', 'download_log_file' ],
		], 'download_permission_callback' );
	}

	/**
	 * GET /bulk-actions
	 */
	public function get_bulk_actions() {
		$search = (string) $this->get_sanitized_arg( 'search', 'text_field' );
		$offset = ! empty( $this->get_sanitized_arg( 'offset', 'key' ) ) ? $this->get_sanitized_arg( 'offset', 'text_field' ) : 0;
		$limit  = ! empty( $this->get_sanitized_arg( 'limit', 'key' ) ) ? $this->get_sanitized_arg( 'limit', 'text_field' ) : 0;
		$status = ! empty( $this->get_sanitized_arg( 'status', 'key' ) ) ? $this->get_sanitized_arg( 'status', 'text_field' ) : '';
		$ids    = empty( $this->args['ids'] ) ? array() : explode( ',', $this->args['ids'] );
		/**
		 * Get bulk action data
		 */
		$bulk_action_data  = BWFAN_Model_Bulk_Action::get_bulk_actions( $search, $status, $limit, $offset, true, $ids );
		$bulk_actions      = isset( $bulk_action_data['list'] ) ? $bulk_action_data['list'] : [];
		$this->total_count = isset( $bulk_action_data['total'] ) ? intval( $bulk_action_data['total'] ) : 0;

		$this->extra_data['total']   = BWFAN_PRO_Common::get_bulk_actions_data_count();
		$this->extra_data['actions'] = ( array ) BWFCRM_Core()->actions->get_all_action_list( 2 );
		$this->count_data            = BWFAN_PRO_Common::get_contact_data_counts();
		$this->response_code         = 200;

		return $this->success_response( $bulk_actions );
	}

	/**
	 * DELETE /bulk-actions/delete
	 */
	public function delete_bulk_action() {
		$ids = $this->args['ids'];

		if ( empty( $ids ) || ! is_array( $ids ) ) {
			return $this->error_response( __( 'Bulk actions ids are missing.', 'wp-marketing-automations-pro' ), null, 500 );
		}

		/** delete actions */
		$deleted = BWFAN_Model_Bulk_Action::delete_multiple_bulk_actions( $ids );

		if ( false === $deleted ) {
			$this->response_code = 404;

			$response = __( 'Unable to delete the bulk actions', 'wp-marketing-automations-pro' );

			return $this->error_response( $response );
		}

		$this->response_code = 200;
		$success_message     = __( 'Bulk action deleted', 'wp-marketing-automations-pro' );

		return $this->success_response( [], $success_message );
	}

	/**
	 * POST /bulk-action
	 */
	public function create_bulk_action() {
		$this->response_code = 200;

		$title       = $this->get_sanitized_arg( 'title', 'text_field', $this->args['title'] );
		$only_action = isset( $this->args['only_action'] ) && boolval( $this->args['only_action'] );
		$include_ids = isset( $this->args['include_ids'] ) && ! empty( $this->args['include_ids'] ) ? $this->args['include_ids'] : [];
		$actions     = isset( $this->args['actions'] ) && ! empty( $this->args['actions'] ) ? $this->args['actions'] : [];

		if ( empty( $title ) && ! $only_action ) {
			$this->response_code = 400;
			$response            = __( 'Oops Title not entered, enter title to create bulk action', 'wp-marketing-automations-pro' );

			return $this->error_response( $response );
		}

		$already_exists = ! $only_action ? BWFAN_Model_Bulk_Action::check_bulk_action_exists_with( 'title', $title ) : false;

		if ( $already_exists ) {
			$this->response_code = 400;
			$response            = __( 'Bulk Action already exists with title : ', 'wp-marketing-automations-pro' ) . $title;

			return $this->error_response( $response );
		}

		$utc_time   = current_time( 'mysql', 1 );
		$store_time = current_time( 'mysql' );

		$data = [
			'title'      => $only_action ? __( 'Contacts Bulk Action ', 'wp-marketing-automation-pro' ) . '(' . $store_time . ')' : $title,
			'status'     => 0,
			'created_by' => get_current_user_id(),
			'created_at' => $utc_time,
			'updated_at' => $utc_time,
		];

		if ( $only_action ) {
			if ( empty( $actions ) ) {
				$this->response_code = 400;
				$response            = __( 'Oops Actions not entered, enter actions to create bulk action', 'wp-marketing-automations-pro' );

				return $this->error_response( $response );
			}

			/** Check for directory exists */
			if ( ! file_exists( BWFCRM_BULK_ACTION_LOG_DIR . '/' ) ) {
				wp_mkdir_p( BWFCRM_BULK_ACTION_LOG_DIR );
			}
			/** Create log file */
			$file_name = 'FKA-Bulk-Action-' . time() . '-' . wp_generate_password( 5, false ) . '-log.csv';

			/** Open log file */
			$file = fopen( BWFCRM_BULK_ACTION_LOG_DIR . '/' . $file_name, "wb" );
			if ( ! empty( $file ) ) {
				/** Updating headers in log file */
				fputcsv( $file, array_merge( [ 'Contact ID' ], array_keys( $actions ) ), ',', '"', '\\' );

				/** Close log file */
				fclose( $file );
			}
			$enable_automation = isset( $this->args['enable_automation'] ) && boolval( $this->args['enable_automation'] );

			$data['actions'] = json_encode( $this->add_new_list_and_tags( $actions ) );
			$data['status']  = 1;
			$data['count']   = count( $include_ids );
			// Set meta data
			$data['meta']['include_ids']           = $include_ids;
			$data['meta']['log_file']              = $file_name;
			$data['meta']['enable_automation_run'] = $enable_automation;
			$data['meta']                          = json_encode( $data['meta'] );

		}

		$result = BWFAN_Model_Bulk_Action::bwfan_create_new_bulk_action( $data );
		if ( empty( $result ) ) {
			$this->response_code = 500;

			return $this->error_response( __( 'Unable to create bulk action', 'wp-marketing-automations-pro' ) );
		}

		if ( $only_action ) {
			BWFCRM_Core()->bulk_action->schedule_bulk_action( $result );
		}

		return $this->success_response( [ 'id' => $result ], __( 'Bulk action created', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * Create tags and list
	 *
	 * @param $actions
	 *
	 * @return array
	 */
	public function add_new_list_and_tags( $actions ) {
		foreach ( $actions as $action_key => $action_val ) {
			$terms     = [];
			$term_type = 0;
			if ( $action_key === 'add_tags' ) {
				$term_type = BWFCRM_Term_Type::$TAG;
				$terms     = $action_val;
			} else if ( $action_key === 'add_to_lists' ) {
				$term_type = BWFCRM_Term_Type::$LIST;
				$terms     = $action_val;
			}

			if ( is_array( $terms ) && ! empty( $terms ) && method_exists( 'BWFAN_PRO_Common', 'get_or_create_terms' ) ) {
				$terms                  = BWFAN_PRO_Common::get_or_create_terms( $terms, $term_type );
				$actions[ $action_key ] = $terms;
			}
		}

		return $actions;
	}

	/**
	 * GET /bulk-action/{id}
	 */
	public function get_bulk_action() {
		$bulk_action_id = $this->get_sanitized_arg( 'bulk_action_id' );
		if ( empty( $bulk_action_id ) ) {
			return $this->error_response( __( 'Invalid / Empty bulk action ID provided', 'wp-marketing-automations-pro' ), null, 400 );
		}

		$data = BWFAN_Model_Bulk_Action::bwfan_get_bulk_action( $bulk_action_id );

		if ( empty( $data ) ) {
			return $this->error_response( __( 'Bulk Action not found with provided ID', 'wp-marketing-automations-pro' ), null, 400 );
		}

		/** Fetch updated list */
		if ( isset( $data['actions']['add_to_lists'] ) ) {
			$data['actions']['add_to_lists'] = BWFAN_Common::get_updated_tags_and_list( $data['actions']['add_to_lists'] );
		}

		/** Fetch updated Tags */
		if ( isset( $data['actions']['add_tags'] ) ) {
			$data['actions']['add_tags'] = BWFAN_Common::get_updated_tags_and_list( $data['actions']['add_tags'] );
		}


		$response = [
			'data'          => $data,
			'actions'       => $this->format_action_array( BWFCRM_Core()->actions->get_all_action_list( 2 ) ),
			'action_schema' => BWFCRM_Core()->actions->get_all_actions_schema_data(),
			'group_data'    => BWFCRM_Core()->actions->get_group_list(),
		];

		$this->response_code = 200;

		return $this->success_response( $response );
	}

	/**
	 * Format the action data
	 *
	 * @param $actions
	 *
	 * @return array|array[]
	 */
	public function format_action_array( $actions ) {
		if ( empty( $actions ) ) {
			return [];
		}

		return array_map( function ( $slug, $nice_name ) {
			return [
				'value' => $slug,
				'label' => $nice_name,
			];
		}, array_keys( $actions ), $actions );
	}

	/**
	 * PUT /bulk-action/{id}
	 */
	public function update_bulk_action() {
		$this->response_code = 200;

		$bulk_action_id = $this->get_sanitized_arg( 'bulk_action_id', 'key' );
		$title          = $this->get_sanitized_arg( 'title', 'text_field', $this->args['title'] );
		$created_at     = isset( $this->args['created_at'] ) ? $this->args['created_at'] : '';

		if ( empty( $created_at ) ) {
			/** Title update call */
			BWFAN_Model_Bulk_Action::update_bulk_action_data( $bulk_action_id, [ 'title' => $title ] );

			$data = BWFAN_Model_Bulk_Action::bwfan_get_bulk_action( $bulk_action_id );

			return $this->success_response( $data, __( 'Bulk action updated', 'wp-marketing-automations-pro' ) );
		}

		$count = $this->get_sanitized_arg( 'count', 'text_field', $this->args['count'] );

		$actions               = isset( $this->args['actions'] ) && ! empty( $this->args['actions'] ) ? $this->args['actions'] : [];
		$contact_filters       = isset( $this->args['contactFilters'] ) && ! empty( $this->args['contactFilters'] ) ? $this->args['contactFilters'] : [];
		$exclude_ids           = isset( $this->args['exclude_ids'] ) && ! empty( $this->args['exclude_ids'] ) ? $this->args['exclude_ids'] : [];
		$include_ids           = isset( $this->args['include_ids'] ) && ! empty( $this->args['include_ids'] ) ? $this->args['include_ids'] : [];
		$start_bulk_action     = isset( $this->args['start_bulk_action'] ) && boolval( $this->args['start_bulk_action'] );
		$stop_bulk_action      = isset( $this->args['stop_bulk_action'] ) && boolval( $this->args['stop_bulk_action'] );
		$file_name             = isset( $this->args['log_file'] ) && boolval( $this->args['log_file'] );
		$enable_automation_run = isset( $this->args['enable_automation_run'] ) && boolval( $this->args['enable_automation_run'] );
		$meta                  = [];

		if ( empty( $title ) ) {
			$this->response_code = 400;
			$response            = __( 'Oops Title not entered, enter title to save bulk action', 'wp-marketing-automations-pro' );

			return $this->error_response( $response );
		}

		$already_exists = BWFAN_Model_Bulk_Action::check_bulk_action_exists_with( 'ID', $bulk_action_id );

		if ( ! $already_exists ) {
			$this->response_code = 400;
			$response            = __( "Bulk Action doesn't exists with id : ", 'wp-marketing-automations-pro' ) . $bulk_action_id;

			return $this->error_response( $response );
		}

		$update_time = current_time( 'mysql', 1 );

		$meta['contactFilters']        = $contact_filters;
		$meta['exclude_ids']           = $exclude_ids;
		$meta['include_ids']           = $include_ids;
		$meta['enable_automation_run'] = $enable_automation_run;
		$actions                       = $this->add_new_list_and_tags( $actions );

		$link_data = [
			'title'      => $title,
			'count'      => intval( $count ) > 0 ? $count : 0,
			'actions'    => json_encode( $actions ),
			'updated_at' => $update_time,
		];

		if ( $start_bulk_action ) {
			$link_data['status'] = 1;
			/** Check if file already exists */
			if ( empty( $file_name ) ) {
				/** Check for directory exists */
				if ( ! file_exists( BWFCRM_BULK_ACTION_LOG_DIR . '/' ) ) {
					wp_mkdir_p( BWFCRM_BULK_ACTION_LOG_DIR );
				}

				/** Create log file */
				$file_name = 'FKA-Bulk-Action-' . time() . '-' . wp_generate_password( 5, false ) . '-log.csv';

				/** Open log file */
				$file = fopen( BWFCRM_BULK_ACTION_LOG_DIR . '/' . $file_name, "wb" );
				if ( ! empty( $file ) ) {
					/** Updating headers in log file */
					fputcsv( $file, array_merge( [ 'Contact ID' ], array_keys( $actions ) ), ',', '"', '\\' );

					/** Close log file */
					fclose( $file );
				}
			}

			$meta['log_file'] = $file_name;
		}

		if ( $stop_bulk_action ) {
			$link_data['status'] = 3;
			if ( bwf_has_action_scheduled( 'bwfcrm_bulk_action_process', array( 'bulk_action_id' => absint( $bulk_action_id ) ), 'bwfcrm' ) ) {
				bwf_unschedule_actions( 'bwfcrm_bulk_action_process', array( 'bulk_action_id' => absint( $bulk_action_id ) ), 'bwfcrm' );
			}
		}

		$link_data['meta'] = json_encode( $meta );

		/** Updating db entry for bulk action */
		$result = BWFAN_Model_Bulk_Action::update_bulk_action_data( $bulk_action_id, $link_data );

		/** Error handle */
		if ( empty( $result ) ) {
			$this->response_code = 500;

			return $this->error_response( __( 'Unable to update bulk action', 'wp-marketing-automations-pro' ) );
		}

		/** Schedule action */
		if ( $start_bulk_action ) {
			BWFCRM_Core()->bulk_action->schedule_bulk_action( $bulk_action_id );
		}

		/** Get bulk action data to return */
		$data = BWFAN_Model_Bulk_Action::bwfan_get_bulk_action( $bulk_action_id );

		if ( empty( $data ) ) {
			return $this->error_response( __( 'Bulk Action not found with provided ID', 'wp-marketing-automations-pro' ), null, 400 );
		}

		/** Set success response */
		return $this->success_response( $data, __( 'Bulk action updated', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * GET /bulk-action/{id}/clone
	 */
	public function clone_bulk_action() {
		$id = $this->get_sanitized_arg( 'id', 'key' );
		if ( intval( $id ) > 0 ) {
			$data                = BWFAN_Model_Bulk_Action::clone_bulk_action( $id );
			$this->response_code = $data['status'];
			if ( $data['status'] === 200 ) {
				return $this->success_response( [], $data['message'] );
			}

			return $this->error_response( $data['message'] );
		}

		$this->response_code = 404;

		return $this->error_response( __( 'Please provide a valid bulk action id.', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * GET /bulk-action/status/{id}
	 */
	public function get_bulk_action_status() {
		$id = $this->get_sanitized_arg( 'bulk_action_id' );
		if ( empty( $id ) ) {
			return $this->error_response( __( 'Invalid / Empty bulk action ID provided', 'wp-marketing-automations-pro' ), null, 400 );
		}

		/** Check for bulk action entry */
		$data = BWFAN_Model_Bulk_Action::bwfan_get_bulk_action( $id, false );
		if ( empty( $data ) ) {
			return $this->error_response( __( 'Bulk Action not found with provided ID', 'wp-marketing-automations-pro' ), null, 400 );
		}
		$meta = ! empty( $data['meta'] ) ? json_decode( $data['meta'], true ) : [];
		$meta = is_array( $meta ) ? $meta : [];

		/** Get bulk action status */
		$action_status = BWFCRM_Core()->bulk_action->get_bulk_action_status( $id );

		if ( 1 === absint( $data['status'] ) && empty( $meta['is_running'] ) ) {
			bwf_unschedule_actions( 'bwfcrm_bulk_action_process', array( 'bulk_action_id' => absint( $id ) ), 'bwfcrm' );
			bwf_schedule_recurring_action( time() + 60, 60, 'bwfcrm_bulk_action_process', array( 'bulk_action_id' => absint( $id ) ), 'bwfcrm' );
			BWFCRM_Core()->bulk_action->process_bulk_action( $id, 5 ); // 5 seconds per call timeout
			$action_status = BWFCRM_Core()->bulk_action->get_bulk_action_status( $id );
		}

		if ( empty( $action_status ) ) {
			return $this->error_response( __( 'Bulk Action data not found with provided ID.', 'wp-marketing-automations-pro' ), null, 400 );
		}

		$this->response_code = 200;

		return $this->success_response( $action_status );
	}

	/**
	 * POST /bulk-action/{id}/update-status
	 */
	public function update_bulk_action_status() {
		$this->response_code = 200;

		$bulk_action_id = $this->get_sanitized_arg( 'bulk_action_id' );
		$status         = $this->get_sanitized_arg( 'status', 'text_field', $this->args['status'] );
		if ( empty( $bulk_action_id ) ) {
			return $this->error_response( __( 'Invalid / Empty bulk action ID provided', 'wp-marketing-automations-pro' ), null, 400 );
		}

		$data = BWFAN_Model_Bulk_Action::bwfan_get_bulk_action( $bulk_action_id, false );

		if ( empty( $data ) ) {
			return $this->error_response( __( 'Bulk Action not found with provided ID', 'wp-marketing-automations-pro' ), null, 400 );
		}

		$data['updated_at'] = current_time( 'mysql', 1 );

		if ( isset( $data['status'] ) ) {
			$data['status'] = intval( $status );
		}

		$result = BWFAN_Model_Bulk_Action::update_bulk_action_data( $bulk_action_id, $data );

		if ( intval( $status ) === 3 && ! empty( $result ) ) {
			if ( bwf_has_action_scheduled( 'bwfcrm_bulk_action_process', array( 'bulk_action_id' => absint( $bulk_action_id ) ), 'bwfcrm' ) ) {
				bwf_unschedule_actions( 'bwfcrm_bulk_action_process', array( 'bulk_action_id' => absint( $bulk_action_id ) ), 'bwfcrm' );
			}
		}

		if ( intval( $status ) === 1 && ! empty( $result ) ) {
			BWFCRM_Core()->bulk_action->schedule_bulk_action( $bulk_action_id );
		}

		if ( empty( $result ) ) {
			$this->response_code = 500;

			return $this->error_response( __( 'Unable to update bulk action status', 'wp-marketing-automations-pro' ) );
		}

		return $this->success_response( [ 'id' => $result ], __( 'Successfully updated bulk action status', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * GET /bulk-action/download/{id}
	 */
	public function download_log_file() {
		$bulk_action_id = absint( $this->get_sanitized_arg( 'bulk_action_id' ) );
		if ( empty( $bulk_action_id ) ) {
			$this->response_code = 404;

			return $this->error_response( __( 'Invalid Bulk Action ID', 'wp-marketing-automations-pro' ) );
		}

		$action_data = BWFAN_Model_Bulk_Action::bwfan_get_bulk_action( $bulk_action_id );

		if ( ! isset( $action_data['log_file'] ) ) {
			$this->response_code = 404;

			return $this->error_response( __( 'Log file url is missing', 'wp-marketing-automations-pro' ) );
		}

		/** basename() strips any path segments from the DB-stored value so a tampered
		 * log_file entry cannot traverse outside the log directories. */
		$log_file = basename( $action_data['log_file'] );
		$filename = BWFCRM_BULK_ACTION_LOG_DIR . '/' . $log_file;
		if ( ! file_exists( $filename ) ) {
			$filename = BWFCRM_BULK_ACTION_LOG_DIR_BACKUP . '/' . $log_file;
		}
		if ( ! file_exists( $filename ) ) {
			wp_die();
		}

		$this->serve_file_download( $filename );
	}


	/**
	 * Returns total count
	 *
	 * @return int
	 */
	public function get_result_total_count() {
		return $this->total_count;
	}

	/**
	 * Returns extra data
	 *
	 * @return array|int
	 */
	public function get_result_extra_data() {
		return $this->extra_data;
	}

	/**
	 * Returns bulk action count based on status
	 *
	 * @return array|int
	 */
	public function get_result_count_data() {
		return $this->count_data;
	}
}

BWFCRM_API_Bulk_Actions_Controller::get_instance();
