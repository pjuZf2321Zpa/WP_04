<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Skip if the parent abstract is not loaded yet (e.g. old loader still in memory during a plugin-update file-swap); prevents a fatal that would abort the update.
if ( ! class_exists( 'BWFCRM_API_Controller' ) ) {
	return;
}

class BWFCRM_API_Transactional_Mails_Controller extends BWFCRM_API_Controller {

	public static $ins;
	public $total_count = 0;

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	public function __construct() {
		$this->pagination         = new stdClass();
		$this->pagination->offset = 0;
		$this->pagination->limit  = 25;
		parent::__construct();
	}

	public function default_args_values() {
		return array(
			'search'   => '',
			'offset'   => 0,
			'limit'    => 25,
			'type'     => '',
			'lang'     => '',
			'subject'  => '',
			'template' => '',
			'data'     => [],
			'status'   => '',
			'content'  => '',
			'eid'      => 0,
		);
	}

	protected function register_routes() {
		// GET /transactional-activity
		$this->add_route( '/transactional-activity', array(
			array( 'GET', 'get_transactional_activity' ),
		) );

		// GET /transactional-mail/{type}
		$this->add_route( '/transactional-mail/(?P<type>[a-zA-Z0-9_-]+)', array(
			array( 'GET', 'get_transactional_mail' ),
			array( 'POST', 'update_transactional_mail' ),
		) );

		// GET /transactional-mails
		$this->add_route( '/transactional-mails', array(
			array( 'GET', 'get_transactional_mails' ),
		) );

		// GET /transactional-mail/{type}/preview
		$this->add_route( '/transactional-mail/(?P<type>[a-zA-Z0-9_-]+)/preview', array(
			array( 'GET', 'get_transactional_preview' ),
		) );

		// POST /transactional-mail/{eid}/resend
		$this->add_route( '/transactional-mail/(?P<eid>[\d]+)/resend', array(
			array( 'POST', 'resend_transactional_mail' ),
		) );

		// POST /transactional-mail/{type}/save-email-content
		$this->add_route( '/transactional-mail/(?P<type>[a-zA-Z0-9_-]+)/save-email-content', array(
			array( 'POST', 'save_email_content' ),
		) );

		// POST /transactional-mail/{type}/status
		$this->add_route( '/transactional-mail/(?P<type>[a-zA-Z0-9_-]+)/status', array(
			array( 'POST', 'update_transactional_mail_status' ),
		) );
	}

	/**
	 * GET /transactional-activity
	 */
	public function get_transactional_activity() {
		$search  = $this->get_sanitized_arg( 'search', 'text_field' ) ?? '';
		$limit    = ! empty( $this->get_sanitized_arg( 'limit', 'text_field' ) ) ? $this->get_sanitized_arg( 'limit', 'text_field' ) : 25;
		$offset   = ! empty( $this->get_sanitized_arg( 'offset', 'text_field' ) ) ? $this->get_sanitized_arg( 'offset', 'text_field' ) : 0;

		$activity_data = $this->get_transactional_activity_data( $search, $offset, $limit );
		$this->response_code = 200;
		$this->total_count   = 0;
		if ( empty( $activity_data[ 'activities' ] ) ) {
			return $this->success_response( [],__( 'No transactional activity found', 'wp-marketing-automations-pro' ) );
		}
		$this->total_count = $activity_data[ 'total_count' ];

		return $this->success_response( $activity_data[ 'activities' ], __( 'Transactional activity fetched successfully', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * Get transactional activity
	 *
	 * @param string $search
	 * @param int $offset
	 * @param int $limit
	 *
	 * @return array
	 */
	public function get_transactional_activity_data( $search = '', $offset = 0, $limit = 25 ) {
		$activity_data = [];
		// Load all transactional mails
		BWFCRM_Core()->transactional_mails->load_all_files();
		// Get transactional activity list
		$activity_data[ 'activities' ] = BWFCRM_Core()->transactional_mails->get_transactional_activity( $search, $offset, $limit );
		// Get total count of transactional activity
		$activity_data[ 'total_count' ] = BWFCRM_Core()->transactional_mails->get_transactional_activity( $search, $offset, $limit, [], [], true );

		return $activity_data;
	}

	public function get_result_total_count() {
		return $this->total_count;
	}

	/**
	 * GET /transactional-mail/{type}
	 */
	public function get_transactional_mail() {
		$type      = $this->get_sanitized_arg( 'type' );
		if ( empty( $type ) ) {
			return $this->error_response( __( 'Empty transactional mail type', 'wp-marketing-automations-pro' ), null, 400 );
		}
		$lang = $this->args['lang'] ?? '';
		$this->response_code = 200;
		// @todo add lite data if pro not found || pro version is old
		if ( ! isset( BWFCRM_Core()->transactional_mails ) ) {
			return $this->success_response( [] );
		}
		$mail_class = BWFCRM_Core()->transactional_mails;
		$template_data =  $mail_class->get_transactional_mail_by_slug( $type, $lang );
		if( ! $template_data ) {
			return $this->error_response( __( 'Invalid transactional mail type', 'wp-marketing-automations-pro' ), null, 404 );
		}
		return $this->success_response( $template_data );
	}

	/**
	 * GET /transactional-mails
	 */
	public function get_transactional_mails() {
		$this->response_code = 200;
		if ( ! isset( BWFCRM_Core()->transactional_mails ) ) {
			return $this->success_response( [] );
		}
		$mail_obj = BWFCRM_Core()->transactional_mails;
		$mail_obj->load_all_files();
		$mail_data = $mail_obj->get_registered_transactional_mails();

		if ( empty( $mail_data ) ) {
			return $this->success_response( [], __( 'No transactional mails found', 'wp-marketing-automations-pro' ) );
		}

		$final_data = [];

		foreach ( $mail_data as $mail ) {
			if ( empty( $mail['template_data'] ) ) {
				$final_data[] = $mail;
				continue;
			}

			$template_id = 0;
			if ( empty( $lang ) && ! empty( $mail['template_data']['template_id'] ) ) {
				$template_id = $mail['template_data']['template_id'];
			} else if ( ! empty( $lang ) && ! empty( $mail['template_data']['lang'][ $lang ] ) ) {
				$template_id = $mail['template_data']['lang'][ $lang ];
			}

			if ( empty( $template_id ) ) {
				$final_data[] = $mail;
				continue;
			}

			$template_data = BWFAN_Model_Templates::bwfan_get_template( $template_id, 0 );
			if ( isset( $template_data['data'] ) ) {
				$template_data_data = json_decode( $template_data['data'], true );
				$other_recipient    = ! empty( $template_data_data['other_recipients'] ) ? $template_data_data['other_recipients'] : '';
				if ( ! empty( $other_recipient ) ) {
					$mail['other_recipient'] = $other_recipient;
				}
			}
			$final_data[] = $mail;
		}

		return $this->success_response( $final_data, __( 'Transactional mails fetched successfully', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * GET /transactional-mail/{type}/preview
	 */
	public function get_transactional_preview() {
		$type      = $this->get_sanitized_arg( 'type' );
		if ( empty( $type ) ) {
			return $this->error_response( __( 'Empty transactional mail type', 'wp-marketing-automations-pro' ), null, 400 );
		}
		$lang = $this->args['lang'] ?? '';
		$this->response_code = 200;

		// Check if transactional mails are loaded
		if ( ! isset( BWFCRM_Core()->transactional_mails ) ) {
			return $this->success_response( [] );
		}
		// Initialize transactional mails class
		$mail_class = BWFCRM_Core()->transactional_mails;

		// Get transactional mail data by slug
		$template_data =  $mail_class->get_transactional_mail_by_slug( $type, $lang );

		// Check if transactional mail not found
		if ( empty( $template_data ) ) {
			return $this->error_response( __( 'Transactional mail not found', 'wp-marketing-automations-pro' ), null, 404 );
		}

		// Get template content
		$content = $template_data['template'];

		if( method_exists( 'BWFAN_Common', 'bwfan_before_send_mail' ) ){
			BWFAN_Common::bwfan_before_send_mail( 'block' );
		}

		// Set data for merge tags
		BWFAN_Merge_Tag_Loader::set_data( [ 'is_preview' => true ] );

		// Correct shortcode string for email body
		$body = method_exists( 'BWFAN_Common', 'correct_shortcode_string' ) ? BWFAN_Common::correct_shortcode_string( $content, 'block' ) : $content;

		// Decode merge tags
		$body = BWFAN_Common::decode_merge_tags( $body );

		// Update links in email body
		$body = BWFAN_Common::bwfan_correct_protocol_url( $body );

		// Get final email body
		$body = BWFCRM_Core()->conversation->apply_template_by_type( $body, 'block', '' );

		$this->response_code = 200;

		// Return success response
		return $this->success_response( [
			'body' => $body,
			'data' => [
				'subject'   => ! empty( $template_data['subject'] ) ? $template_data['subject'] : __( 'Test Subject', 'wp-marketing-automations-pro' ),
				'preheader' => ! empty( $template_data['data']['preheader'] ) ? $template_data['data']['preheader']: '',
				'utmEnabled' => ! empty( $template_data['data']['utmEnabled'] ) && boolval( $template_data['data']['utmEnabled'] ),
				'utmDetails' => ! empty( $template_data['data']['utm'] ) ? $template_data['data']['utm'] : [],
				'overRideSenderInfo' => true,
				'overRideInfo' => [
					'from_name' => ! empty( $template_data['data']['from_name'] ) ? $template_data['data']['from_name'] : '',
					'from_email' => ! empty( $template_data['data']['from_email'] ) ? $template_data['data']['from_email'] : '',
					'reply_to' => ! empty( $template_data['data']['reply_to_email'] ) ? $template_data['data']['reply_to_email'] : '',
				]
			],

		] );
	}

	/**
	 * POST /transactional-mail/{eid}/resend
	 */
	public function resend_transactional_mail() {
		$eid = $this->get_sanitized_arg( 'eid' );
		if ( empty( $eid ) ) {
			return $this->error_response( __( 'Invalid or empty engagement id.', 'wp-marketing-automations-pro' ), null, 400 );
		}
		$response = BWFCRM_Core()->transactional_mails->resend_conversation_to_contact( $eid );
		if ( ! $response || ( is_array( $response ) && empty( $response['status'] ) ) ) {
			$this->response_code = 500;

			return $this->error_response( ! empty( $response['message'] ) ? $response['message'] : __( 'Unable to send transactional mail', 'wp-marketing-automations-pro' ) );
		}

		return $this->success_response( [], __( 'Transactional mail sent successfully', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * POST /transactional-mail/{type}/save-email-content
	 */
	public function save_email_content() {
		$type      = $this->get_sanitized_arg( 'type' );
		if ( empty( $type ) ) {
			return $this->error_response( __( 'Invalid or empty transactional mail type', 'wp-marketing-automations-pro' ), null, 400 );
		}
		if ( isset( $this->args['content'] ) ) {
			$content    = BWFAN_Common::is_json( $this->args['content'] ) ? json_decode( $this->args['content'], true ) : [];
			$this->args = wp_parse_args( $content, $this->args );
		}
		$lang = $this->args['lang'] ?? '';
		$subject = $this->get_sanitized_arg( 'subject', 'text_field', $this->args['subject'] );
		$template = isset( $this->args['template'] ) ? $this->args['template'] : '';
		$data = isset($this->args['data']) ? $this->args['data'] : [];

		if ( ! empty( $lang ) ) {
			$data['lang'] = $lang;
		}

		$this->response_code = 200;
		if ( ! isset( BWFCRM_Core()->transactional_mails ) ) {
			return $this->success_response( [] );
		}
		$mail_class = BWFCRM_Core()->transactional_mails;
		$template_data =  $mail_class->get_transactional_mail_by_slug( $type, $lang );
		if ( empty( $template_data ) ) {
			$this->response_code = 404;

			return $this->error_response( __( 'Transactional mail not found', 'wp-marketing-automations-pro' ) );
		}
		$template_id = $template_data['ID'];
		//check if the template_id exists in other engagement
		//if exists create a new transactional mail template with the updated content
		//else update the existing transactional mail template with the updated content
		$engagement_exists = BWFAN_Model_Engagement_Tracking::get_engagements_by_tid( $template_id, true );

		// Update the template
		$create_time = current_time( 'mysql', 1 );

		if ( intval( $engagement_exists ) > 0 ) {
			// new template data
			$template_data = [
				'title'      => $type,
				'template'   => $template,
				'subject'    => $subject,
				'type'       => 1,
				'mode'       => 7,
				'canned'     => 0,
				'updated_at' => $create_time,
				'created_at' => $create_time,
				'data'       => BWFAN_Common::is_json( $data ) ? $data : wp_json_encode( $data ),
			];
			$template_id = BWFAN_Model_Templates::bwfan_create_new_template( $template_data );
			$result = BWFCRM_Core()->transactional_mails->update_option_template_id( $type, $template_id, $lang );
		} else {
			$template_data = [
				'template'   => $template,
				'data'       => BWFAN_Common::is_json( $data ) ? $data : wp_json_encode( $data ),
				'updated_at' => $create_time,
			];
			if ( ! empty( $subject ) ) {
				$template_data[ 'subject' ] = $subject;
			}
			$result = BWFAN_Model_Templates::bwfan_update_template( $template_id, $template_data );
		}

		if ( ! $result ) {
			$this->response_code = 500;

			return $this->error_response( __( 'Unable to update transactional mail', 'wp-marketing-automations-pro' ) );
		}

		return $this->success_response( [], __( 'Transactional mail updated successfully', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * POST /transactional-mail/{type}/status
	 */
	public function update_transactional_mail_status() {
		$type      = $this->get_sanitized_arg( 'type' ); // Transactional mail type or 'all' for all transactional mails
		if ( empty( $type ) ) {
			return $this->error_response( __( 'Invalid or empty transactional mail type', 'wp-marketing-automations-pro' ), null, 400 );
		}

		$status         = $this->get_sanitized_arg( 'status', 'bool' );
		$this->response_code = 200;
		if ( ! isset( BWFCRM_Core()->transactional_mails ) ) {
			return $this->error_response( __( 'Unable to find transactional mail', 'wp-marketing-automations-pro' ), null, 400 );
		}
		/** @var  $mail_class BWFCRM_Transactional_Mail_Loader */
		$mail_class = BWFCRM_Core()->transactional_mails;

		$result =  $mail_class->update_transactional_mail_status( $type, $status );

		if ( ! $result ) {
			return $this->error_response( __( 'Unable to update transactional mail status', 'wp-marketing-automations-pro' ), null, 400 );
		}

		return $this->success_response( [], __( 'Transactional mail status updated', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * POST /transactional-mail/{type} (update)
	 */
	public function update_transactional_mail() {
		$type      = $this->get_sanitized_arg( 'type' );
		if ( empty( $type ) ) {
			return $this->error_response( __( 'Invalid or empty transactional mail type', 'wp-marketing-automations-pro' ), null, 400 );
		}
		if ( isset( $this->args['content'] ) ) {
			$content    = BWFAN_Common::is_json( $this->args['content'] ) ? json_decode( $this->args['content'], true ) : [];
			$this->args = wp_parse_args( $content, $this->args );
		}

		$lang = $this->args['lang'] ?? '';
		$subject = $this->get_sanitized_arg( 'subject', 'text_field', $this->args['subject'] );
		$template = isset( $this->args['template'] ) ? $this->args['template'] : '';
		$data = isset($this->args['data']) ? $this->args['data'] : [];

		$this->response_code = 200;
		if ( ! isset( BWFCRM_Core()->transactional_mails ) ) {
			return $this->success_response( [] );
		}
		$template_data = BWFCRM_Core()->transactional_mails->get_transactional_mail_by_slug( $type, $lang );

		$template_id = $template_data['ID'];

		// Implementing the logic to update the transactional mail content

		//check if the template_id exists in other engagement
		//if exists create a new transactional mail template with the updated content
		//else update the existing transactional mail template with the updated content
		$engagement_exists = BWFAN_Model_Engagement_Tracking::get_engagements_by_tid( $template_id, true );

		// Update the template
		$create_time = current_time( 'mysql', 1 );

		if ( ! empty( $lang ) ) {
			$data['lang'] = $lang;
		}

		// new template data
		$template_data = [
			'title'      => $type,
			'template'   => $template,
			'subject'    => $subject,
			'type'       => 1,
			'mode'       => 7,
			'canned'     => 0,
			'updated_at' => $create_time,
			'data'       => BWFAN_Common::is_json( $data ) ? $data : wp_json_encode( $data ),
		];
		if ( intval( $engagement_exists ) > 0 ) {
			$template_data[ 'created_at' ] = $create_time;
			$template_id = BWFAN_Model_Templates::bwfan_create_new_template( $template_data );
			$result = BWFCRM_Core()->transactional_mails->update_option_template_id( $type, $template_id, $lang );
		} else {
			$result = BWFAN_Model_Templates::bwfan_update_template( $template_id, $template_data );
			if ( ! $result ) {
				return $this->error_response( __( 'Unable to update transactional mail template', 'wp-marketing-automations-pro' ) );
			}
			$result = BWFCRM_Core()->transactional_mails->update_option_template_id( $type, $template_id, $lang );
		}

		if ( ! $result ) {
			$this->response_code = 500;

			return $this->error_response( __( 'Unable to update transactional mail', 'wp-marketing-automations-pro' ) );
		}

		return $this->success_response( [], __( 'Transactional mail updated', 'wp-marketing-automations-pro' ) );
	}
}

BWFCRM_API_Transactional_Mails_Controller::get_instance();
