<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Skip if the parent abstract is not loaded yet (e.g. old loader still in memory during a plugin-update file-swap); prevents a fatal that would abort the update.
if ( ! class_exists( 'BWFCRM_API_Controller' ) ) {
	return;
}

class BWFCRM_API_WLM_Controller extends BWFCRM_API_Controller {

	public static $ins;

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	protected function register_routes() {
		$this->add_route( '/wlm/contact/(?P<contact_id>[\\d]+)', [
			[ 'GET', 'get_contact_member' ],
		] );

		$this->add_route( '/wlm/levels', [
			[ 'GET', 'get_levels' ],
		] );
	}

	/**
	 * GET /wlm/contact/(?P<contact_id>[\d]+)
	 */
	public function get_contact_member() {
		$contact_id = $this->get_sanitized_arg( 'contact_id', 'text_field' );
		if ( empty( $contact_id ) ) {
			return $this->error_response_200( __( 'No Contact ID provided', 'wp-marketing-automations-pro' ), null, 400 );
		}

		/** @var BWFCRM_Integration_Wishlist_Member $ins */
		$ins     = BWFCRM_Core()->integrations->get_integration( 'wishlist_member' );
		$details = $ins->get_contact_member_details( absint( $contact_id ) );

		return $this->success_response( $details );
	}

	/**
	 * GET /wlm/levels
	 */
	public function get_levels() {
		/** @var BWFCRM_Integration_Wishlist_Member $ins */
		$ins    = BWFCRM_Core()->integrations->get_integration( 'wishlist_member' );
		$levels = $ins->get_levels();

		return $this->success_response( $levels );
	}
}

BWFCRM_API_WLM_Controller::get_instance();
