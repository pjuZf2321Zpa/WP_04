<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Skip if the parent abstract is not loaded yet (e.g. old loader still in memory during a plugin-update file-swap); prevents a fatal that would abort the update.
if ( ! class_exists( 'BWFCRM_API_Controller' ) ) {
	return;
}

class BWFCRM_API_Forms_Controller extends BWFCRM_API_Controller {

	public static $ins;

	public $total = 0;
	public $count_data = [];

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	protected function register_routes() {

		/** GET + POST /form-feeds */
		$this->add_route( '/form-feeds', [
			[ 'GET', 'get_form_feeds' ],
			[ 'POST', 'create_form_feed' ],
		] );

		/** GET + PUT + DELETE /form-feeds/{id} */
		$this->add_route( '/form-feeds/(?P<feed_id>[\d]+)', [
			[ 'GET', 'get_single_form_feed', array(
				'feed_id' => array(
					'description' => __( 'Form Feed ID to retrieve', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ],
			[ 'PUT', 'update_form_feed' ],
			[ 'DELETE', 'delete_form_feed' ],
		] );

		/** PUT /form-feeds/{id}/status */
		$this->add_route( '/form-feeds/(?P<feed_id>[\d]+)/status', [
			[ 'PUT', 'change_form_status' ],
		] );

		/** GET /form-feeds/{id}/mapping-data */
		$this->add_route( '/form-feeds/(?P<feed_id>[\d]+)/mapping-data', [
			[ 'GET', 'get_feed_mapping_data' ],
		] );

		/** POST /form-feeds/{id}/sync-selection */
		$this->add_route( '/form-feeds/(?P<feed_id>[\d]+)/sync-selection', [
			[ 'POST', 'sync_feed_selection' ],
		] );

		/** PUT /form-feeds/{id}/save-email-data */
		$this->add_route( '/form-feeds/(?P<feed_id>[\d]+)/save-email-data', [
			[ 'PUT', 'save_email_data' ],
		] );

		/** PUT /form-feeds/{id}/save-email-content */
		$this->add_route( '/form-feeds/(?P<feed_id>[\d]+)/save-email-content', [
			[ 'PUT', 'update_incentive_email' ],
		] );

		/** GET /form-feeds/{id}/get-email-content */
		$this->add_route( '/form-feeds/(?P<feed_id>[\d]+)/get-email-content', [
			[ 'GET', 'get_form_email_content', array(
				'feed_id' => array(
					'description' => __( 'Form Feed ID to retrieve', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ],
		] );
	}

	/**
	 * GET /form-feeds
	 */
	public function get_form_feeds() {
		$args = array(
			'offset'      => $this->pagination->offset,
			'limit'       => $this->pagination->limit,
			'grab_totals' => $this->get_sanitized_arg( 'grab_totals', 'bool' ),
            'status'      => $this->get_sanitized_arg( 'status', 'text_field' ),
            'search'      => $this->get_sanitized_arg( 'search', 'text_field' ),
			'category'    => $this->get_sanitized_arg( 'category', 'text_field' ),
		);

		$feeds            = BWFCRM_Core()->forms->get_feeds( $args );
		$this->total      = absint( $feeds['total'] );
		$this->count_data = BWFAN_PRO_Common::get_forms_data_count();

		return $this->success_response( $feeds['feeds'] );
	}

	/**
	 * POST /form-feeds
	 */
	public function create_form_feed() {
		$this->response_code = 200;

		$name = $this->get_sanitized_arg( 'name', 'text_field' );
		$form = $this->get_sanitized_arg( 'form', 'text_field' );
		if ( empty( $name ) ) {
			return $this->error_response( __( 'Invalid data / Required fields missing', 'wp-marketing-automations-pro' ), null, 400 );
		}

		$nice_names = BWFCRM_Core()->forms->get_forms_nice_names();
		if ( ! empty( $form ) && ! isset( $nice_names[ $form ] ) ) {
			return $this->error_response( __( 'Form type is invalid', 'wp-marketing-automations-pro' ), null, 500 );
		}

		$feed = new BWFCRM_Form_Feed();
		$feed->set_title( $name );
		! empty( $form ) && $feed->set_source( $form );
		$feed_id = $feed->save();
		if ( ! absint( $feed_id ) > 0 ) {
			return $this->error_response( __( 'Unable to create form', 'wp-marketing-automations-pro' ), null, 500 );
		}

		return $this->success_response( $feed->get_array(), __( 'Form created', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * GET /form-feeds/{id}
	 */
	public function get_single_form_feed() {
		$feed_id = $this->get_sanitized_arg( 'feed_id' );
		if ( empty( $feed_id ) ) {
			return $this->error_response( __( 'Invalid / Empty Feed ID provided', 'wp-marketing-automations-pro' ), null, 400 );
		}

		$feed = new BWFCRM_Form_Feed( $feed_id );
		if ( ! $feed->is_feed_exists() ) {
			return $this->error_response( __( 'No Feed Exists / Invalid feed in DB', 'wp-marketing-automations-pro' ), null, 500 );
		}

		return $this->success_response( $feed->get_array() );
	}

	/**
	 * PUT /form-feeds/{id}
	 */
	public function update_form_feed() {
		$this->response_code = 200;

		$feed_id = $this->get_sanitized_arg( 'feed_id' );
		if ( empty( $feed_id ) ) {
			return $this->error_response( __( 'Invalid / Empty Feed ID provided', 'wp-marketing-automations-pro' ), null, 400 );
		}

		$feed = new BWFCRM_Form_Feed( $feed_id );
		if ( ! $feed->is_feed_exists() ) {
			return $this->error_response( __( 'No Feed Exists / Invalid feed in DB', 'wp-marketing-automations-pro' ), null, 500 );
		}

		$mapped_fields = isset( $this->args['map'] ) && is_array( $this->args['map'] ) ? $this->args['map'] : [];
		if ( count( $mapped_fields ) > 0 && ! in_array( 'email', $mapped_fields, true ) ) {
			return $this->error_response( __( 'Email mapping is required', 'wp-marketing-automations-pro' ), null, 400 );
		}

		$title = isset( $this->args['title'] ) && ! empty( $this->args['title'] ) ? $this->get_sanitized_arg( 'title', 'text_field' ) : '';

		$tags = isset( $this->args['tags'] ) && is_array( $this->args['tags'] ) ? $this->args['tags'] : [];
		$tags = ( empty( $tags ) && isset( $this->args['data'] ) && isset( $this->args['data']['tags'] ) ) ? $this->args['data']['tags'] : $tags;

		$lists = isset( $this->args['lists'] ) && is_array( $this->args['lists'] ) ? $this->args['lists'] : [];
		$lists = ( empty( $lists ) && isset( $this->args['data'] ) && isset( $this->args['data']['lists'] ) ) ? $this->args['data']['lists'] : $lists;

		$update_existing          = $this->get_sanitized_arg( 'update_existing', 'bool' );
		$trigger_events           = $this->get_sanitized_arg( 'trigger_events', 'bool' );
		$dont_update_blank_values = $this->get_sanitized_arg( 'dont_update_blank', 'bool' );

		$update_existing = ( isset( $this->args['data'] ) && isset( $this->args['data']['update_existing'] ) ) ? $this->args['data']['update_existing'] : $update_existing;
		$trigger_events  = ( isset( $this->args['data'] ) && isset( $this->args['data']['trigger_events'] ) ) ? $this->args['data']['trigger_events'] : $trigger_events;

		$dont_update_blank_values = ( isset( $this->args['data'] ) && isset( $this->args['data']['dont_update_blank'] ) ) ? $this->args['data']['dont_update_blank'] : $dont_update_blank_values;

		/** Create Tags if not exists */
		if ( is_array( $tags ) && ! empty( $tags ) && method_exists( 'BWFAN_PRO_Common', 'get_or_create_terms' ) ) {
			$tags = BWFAN_PRO_Common::get_or_create_terms( $tags, BWFCRM_Term_Type::$TAG );
			/** Prepared Tags */
			$tags = array_map( function ( $tag ) {
				$tag['value'] = isset( $tag['name'] ) ? $tag['name'] : '';
				unset( $tag['name'] );

				return $tag;
			}, $tags );
		}

		/** Create Lists if not exists */
		if ( is_array( $lists ) && ! empty( $lists ) && method_exists( 'BWFAN_PRO_Common', 'get_or_create_terms' ) ) {
			$lists = BWFAN_PRO_Common::get_or_create_terms( $lists, BWFCRM_Term_Type::$LIST );
			/** Prepared List */
			$lists = array_map( function ( $list ) {
				$list['value'] = isset( $list['name'] ) ? $list['name'] : '';
				unset( $list['name'] );

				return $list;
			}, $lists );
		}

		$status = $this->get_sanitized_arg( 'status' );
		if ( BWFCRM_Core()->forms->is_valid_status( $status ) ) {
			$feed->set_status( $status );
		}
		! empty( $title ) && $feed->set_title( $title );
		! empty( $mapped_fields ) && $feed->set_data( 'mapped_fields', $mapped_fields );
		$feed->set_data( 'tags', ! empty( $tags ) ? $tags : [] );
		$feed->set_data( 'lists', ! empty( $lists ) ? $lists : [] );
		$feed->set_data( 'update_existing', $update_existing );
		$feed->set_data( 'trigger_events', $trigger_events );
		$feed->set_data( 'update_blank', $dont_update_blank_values );

		$feed->save();

		return $this->success_response( $feed->get_array(), __( 'Form updated', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * DELETE /form-feeds/{id}
	 */
	public function delete_form_feed() {
		$this->response_code = 200;

		$feed_id = $this->get_sanitized_arg( 'feed_id' );
		if ( empty( $feed_id ) ) {
			return $this->error_response( __( 'Invalid / Empty form ID provided', 'wp-marketing-automations-pro' ), null, 400 );
		}

		$feed = new BWFCRM_Form_Feed( $feed_id );
		if ( ! $feed->is_feed_exists() ) {
			return $this->error_response( __( 'No form exists', 'wp-marketing-automations-pro' ), null, 500 );
		}

		$feed->delete();

		return $this->success_response( '', __( 'Form created', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * PUT /form-feeds/{id}/status
	 */
	public function change_form_status() {
		$this->response_code = 200;

		$feed_id = $this->get_sanitized_arg( 'feed_id' );
		if ( empty( $feed_id ) ) {
			return $this->error_response( __( 'Invalid / Empty Feed ID provided', 'wp-marketing-automations-pro' ), null, 400 );
		}

		$feed = new BWFCRM_Form_Feed( $feed_id );
		if ( ! $feed->is_feed_exists() ) {
			return $this->error_response( __( 'No Feed Exists / Invalid feed in DB', 'wp-marketing-automations-pro' ), null, 500 );
		}

		$status = $this->get_sanitized_arg( 'status' );
		if ( ! BWFCRM_Core()->forms->is_valid_status( $status ) ) {
			return $this->error_response( __( 'Invalid status', 'wp-marketing-automations-pro' ), null, 400 );
		}

		$feed->set_status( $status );
		$feed->save();

		return $this->success_response( $feed->get_array(), __( 'Form Status Changed', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * GET /form-feeds/{id}/mapping-data
	 */
	public function get_feed_mapping_data() {
		$feed_id = $this->get_sanitized_arg( 'feed_id' );
		$feed    = new BWFCRM_Form_Feed( $feed_id );
		$form    = BWFCRM_Core()->forms->get_form( $feed->get_source() );
		if ( ! $feed->is_feed_exists() || empty( $feed->get_source() ) || empty( $form ) ) {
			return $this->error_response( __( 'No Feed / Form Source Found for Feed ID: ' . $feed_id, 'wp-marketing-automations-pro' ) );
		}

		$fields = $form->get_form_fields( $feed );
		if ( is_wp_error( $fields ) ) {
			return $this->error_response( '', $fields );
		}

		$contact_fields = BWFCRM_Fields::get_groups_with_fields( true, true, true, true );
		if ( empty( $contact_fields ) ) {
			return $this->error_response( __( 'Unable to get contact fields for Feed ID: ' . $feed_id, 'wp-marketing-automations-pro' ) );
		}

		$mapping_data = array(
			'headers' => $form->format_form_fields_for_mapping( $fields ),
			'fields'  => $contact_fields
		);

		return $this->success_response( $mapping_data );
	}

	/**
	 * POST /form-feeds/{id}/sync-selection
	 */
	public function sync_feed_selection() {
		$feed_id            = $this->get_sanitized_arg( 'feed_id' );
		$form               = $this->get_sanitized_arg( 'form' );
		$return_all_options = $this->get_sanitized_arg( 'return_all_options', 'bool' );
		$selection          = $this->args['selection'];
		if ( ! is_array( $selection ) ) {
			$selection = [];
		}

		$selection = BWFCRM_Core()->forms->sync_feed_selection( $feed_id, $form, $selection, $return_all_options );
		if ( is_wp_error( $selection ) ) {
			return $this->error_response( '', $selection );
		}

		return $this->success_response( $selection );
	}

	/**
	 * PUT /form-feeds/{id}/save-email-data
	 */
	public function save_email_data() {
		$this->response_code = 200;

		if ( isset( $this->args['content'] ) ) {
			$content    = BWFAN_Common::is_json( $this->args['content'] ) ? json_decode( $this->args['content'], true ) : [];
			$this->args = wp_parse_args( $content, $this->args );
		}

		$feed_id = $this->get_sanitized_arg( 'feed_id' );
		if ( empty( $feed_id ) ) {
			return $this->error_response( __( 'Invalid / Empty Feed ID provided', 'wp-marketing-automations-pro' ), null, 400 );
		}

		$feed = new BWFCRM_Form_Feed( $feed_id );
		if ( ! $feed->is_feed_exists() ) {
			return $this->error_response( __( 'No Feed Exists / Invalid feed in DB', 'wp-marketing-automations-pro' ), null, 500 );
		}

		$incentivize_email = $this->get_sanitized_arg( 'incentivize_email', 'bool' );

		$incentive_email = isset( $this->args['incentive_email'] ) ? $this->args['incentive_email'] : [];
		$incentive_email = is_array( $incentive_email ) ? $incentive_email : [];
		if ( true === $incentivize_email && 0 === count( $incentive_email ) ) {
			return $this->error_response( __( 'Incentive Email Required', 'wp-marketing-automations-pro' ), null, 400 );
		}

		$marketing_status = $this->get_sanitized_arg( 'marketing_status', 'bool' );
		$redirect_url     = $this->get_sanitized_arg( 'redirect_url', 'text_field' );
		if ( empty( $redirect_url ) ) {
			$redirect_url = esc_url_raw( home_url( '/' ) );
		}
		$redirect_mode = $this->get_sanitized_arg( 'redirect_mode', 'key' );
		if ( empty( $redirect_mode ) ) {
			$redirect_mode = 'url';
		}

		$add_tag_enable = $this->get_sanitized_arg( 'add_tag_enable', 'bool' );

		$tag_to_add = isset( $this->args['tag_to_add'] ) ? $this->args['tag_to_add'] : [];
		$tag_to_add = is_array( $tag_to_add ) ? $tag_to_add : [];

		if ( is_array( $tag_to_add ) && ! empty( $tag_to_add ) ) {

			$tag_to_add = BWFCRM_Term::get_or_create_terms( $tag_to_add, BWFCRM_Term_Type::$TAG, true );

			/**Preparing tags */
			$tag_to_add = array_map( function ( $tag ) {
				$tag_data          = [];
				$tag_data['id']    = $tag->get_id();
				$tag_data['value'] = $tag->get_name();

				return $tag_data;
			}, $tag_to_add );
		}

		$status = $this->get_sanitized_arg( 'status' );
		if ( BWFCRM_Core()->forms->is_valid_status( $status ) ) {
			$feed->set_status( $status );
		}

		$not_send_to_subscribed = $this->get_sanitized_arg( 'not_send_to_subscribed', 'bool' );

		$feed->set_data( 'marketing_status', $marketing_status );
		$feed->set_data( 'incentivize_email', $incentivize_email );
		$feed->set_data( 'redirect_url', $redirect_url );
		$feed->set_data( 'redirect_mode', $redirect_mode );
		$feed->set_data( 'add_tag_enable', $add_tag_enable );
		$feed->set_data( 'tag_to_add', $tag_to_add );
		$feed->set_data( 'not_send_to_subscribed', $not_send_to_subscribed );

		if ( true === $incentivize_email ) {
			$feed->set_data( 'incentive_email', $incentive_email );
		}

		$feed->save();

		return $this->success_response( $feed->get_array(), __( 'Form updated', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * PUT /form-feeds/{id}/save-email-content
	 */
	public function update_incentive_email() {
		$this->response_code = 200;

		$feed_id = $this->get_sanitized_arg( 'feed_id' );
		if ( empty( $feed_id ) ) {
			return $this->error_response( __( 'Invalid / Empty Feed ID provided', 'wp-marketing-automations-pro' ), null, 400 );
		}

		$feed = new BWFCRM_Form_Feed( $feed_id );
		if ( ! $feed->is_feed_exists() ) {
			return $this->error_response( __( 'No Feed Exists / Invalid feed in DB', 'wp-marketing-automations-pro' ), null, 500 );
		}
		$content = isset( $this->args['content'] ) ? $this->args['content'] : [];
		$content = BWFAN_Common::is_json( $content ) ? json_decode( $content, true ) : $content;

		$content = is_array( $content ) ? $content : [];
		if ( 0 === count( $content ) ) {
			return $this->error_response( __( 'Incentive Email Required', 'wp-marketing-automations-pro' ), null, 400 );
		}

		$saved_email = $feed->get_data( 'incentive_email' );
		if ( ! is_array( $saved_email ) ) {
			$saved_email = [];
		}

		$saved_email['content'] = ! empty( $content ) ? $content : array();
		$feed->set_data( 'incentive_email', $saved_email );

		$feed->save();

		return $this->success_response( $feed->get_array(), __( 'Form updated', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * GET /form-feeds/{id}/get-email-content
	 */
	public function get_form_email_content() {
		$feed_id = $this->get_sanitized_arg( 'feed_id' );
		if ( empty( $feed_id ) ) {
			return $this->error_response( __( 'Invalid / Empty Feed ID provided', 'wp-marketing-automations-pro' ), null, 400 );
		}

		$feed = new BWFCRM_Form_Feed( $feed_id );
		if ( ! $feed->is_feed_exists() ) {
			return $this->error_response( __( 'No Feed Exists / Invalid feed in DB', 'wp-marketing-automations-pro' ), null, 500 );
		}

		$email = $feed->get_data( 'incentive_email' );
		if ( ! is_array( $email ) || ! isset( $email['content'] ) || empty( $email['content'] ) ) {
			return $this->error_response( __( 'No Incentive Email found', 'wp-marketing-automations-pro' ), null, 500 );
		}

		$content        = is_array( $email['content'] ) && ! empty( $email['content'][0] ) ? $email['content'][0] : [];
		$editor_content = ! is_array( $content ) || empty( $content['editor'] ) || ! is_array( $content['editor'] ) ? [] : $content['editor'];

		return $this->success_response( $editor_content );
	}

	public function get_result_total_count() {
		return $this->total;
	}

	public function get_result_count_data() {
		return $this->count_data;
	}
}

BWFCRM_API_Forms_Controller::get_instance();
