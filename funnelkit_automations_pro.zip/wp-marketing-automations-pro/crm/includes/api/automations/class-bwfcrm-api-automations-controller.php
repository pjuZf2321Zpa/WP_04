<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Skip if the parent abstract is not loaded yet (e.g. old loader still in memory during a plugin-update file-swap); prevents a fatal that would abort the update.
if ( ! class_exists( 'BWFCRM_API_Controller' ) ) {
	return;
}

class BWFCRM_API_Automations_Controller extends BWFCRM_API_Controller {

	public static $ins;
	public $total_count = 0;
	public $automation_id = 0;
	private $aid = 0;
	public $recipients_timeline = [];

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	public function __construct() {
		$this->pagination         = new stdClass();
		$this->pagination->offset = 0;
		$this->pagination->limit  = 10;
		parent::__construct();
	}

	public function default_args_values() {
		return array(
			'automation_id' => 0,
			'step_id'       => 0,
			'node_id'       => 0,
			'path_num'      => 0,
			'contact_id'    => 0,
			'split_id'      => 0,
			'offset'        => 0,
			'limit'         => 10,
			'mode'          => 1,
		);
	}

	protected function register_routes() {
		// POST /automation/{id}/step/{id}/declare-winner
		$this->add_route( '/automation/(?P<automation_id>[\d]+)/step/(?P<step_id>[\d]+)/declare-winner', array(
			array( 'POST', 'declare_path_winner', array(
				'automation_id' => array(
					'description' => __( 'Automation id to get split step', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
				'step_id'       => array(
					'description' => __( 'Step Id of split test', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
				'node_id'       => array(
					'description' => __( 'Step node to get all steps of split step', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
				'path_num'      => array(
					'description' => __( 'Path number to declare winner', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ),
		) );

		// GET /automation/{id}/conversions
		$this->add_route( '/automation/(?P<automation_id>[\d]+)/conversions/', array(
			array( 'GET', 'get_automation_conversions', array(
				'automation_id' => array(
					'description' => __( 'Automation ID to retrieve', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
				'offset'        => array(
					'description' => __( 'Contacts list Offset', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
				'limit'         => array(
					'description' => __( 'Per page limit', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ),
		) );

		// GET /automation/{id}/step/{id}/path/{id}
		$this->add_route( '/automation/(?P<automation_id>[\d]+)/step/(?P<step_id>[\d]+)/path/(?P<path_id>[\d]+)', array(
			array( 'GET', 'get_split_path_stats_by_step', array(
				'automation_id' => array(
					'description' => __( 'Automation id to get path stats', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
				'step_id'       => array(
					'description' => __( 'Step id to get path stats', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
				'path_id'       => array(
					'description' => __( 'Path id to get stats', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ),
		) );

		// GET /automation/{id}/step/{id}/path-stats
		$this->add_route( '/automation/(?P<automation_id>[\d]+)/step/(?P<step_id>[\d]+)/path-stats/', array(
			array( 'GET', 'get_automation_path_stats', array(
				'automation_id' => array(
					'description' => __( 'Automation id to get path stats', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
				'step_id'       => array(
					'description' => __( 'Step id to get path stats', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ),
		) );

		// GET /automation/{id}/recipients/{contact_id}/timeline
		$this->add_route( '/automation/(?P<automation_id>[\d]+)/recipients/(?P<contact_id>[\d]+)/timeline', array(
			array( 'GET', 'get_automation_recipient_timeline', array(
				'automation_id' => array(
					'description' => __( 'Automation ID to retrieve engagements', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
				'contact_id'    => array(
					'description' => __( 'Contact ID to retrieve recipient timeline', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ),
		) );

		// GET /automation/{id}/recipients
		$this->add_route( '/automation/(?P<automation_id>[\d]+)/recipients/', array(
			array( 'GET', 'get_automation_recipients', array(
				'automation_id' => array(
					'description' => __( 'Automation ID to retrieve', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
				'offset'        => array(
					'description' => __( 'Contacts list Offset', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
				'limit'         => array(
					'description' => __( 'Per page limit', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ),
		) );

		// GET /automation/{id}/split/{id}/preview
		$this->add_route( '/automation/(?P<automation_id>[\d]+)/split/(?P<split_id>[\d]+)/preview', array(
			array( 'GET', 'get_automation_split_preview', array(
				'automation_id' => array(
					'description' => __( 'Automation id to get path stats', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
				'split_id'      => array(
					'description' => __( 'split id to get preview', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ),
		) );

		// GET /automation/{id}/split-stats
		$this->add_route( '/automation/(?P<automation_id>[\d]+)/split-stats/', array(
			array( 'GET', 'get_automation_split_stats', array(
				'automation_id' => array(
					'description' => __( 'Automation id to get path stats', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ),
		) );
	}

	/**
	 * POST /automation/{id}/step/{id}/declare-winner
	 */
	public function declare_path_winner() {
		$this->automation_id = $this->get_sanitized_arg( 'automation_id' );
		$node_id             = $this->get_sanitized_arg( 'node_id' );
		$path_num            = $this->get_sanitized_arg( 'path_num' );
		$step_id             = $this->get_sanitized_arg( 'step_id' );

		if ( empty( $this->automation_id ) || empty( $node_id ) || empty( $path_num ) ) {
			return $this->error_response( __( 'Invalid / Empty automation ID provided', 'wp-marketing-automations-pro' ), null, 400 );
		}
		$current_path = 'p-' . $path_num;

		/** Initiate automation object */
		$automation_obj = BWFAN_Automation_V2::get_instance( $this->automation_id );

		/** Check for automation exists */
		if ( ! empty( $automation_obj->error ) ) {
			return $this->error_response( [], $automation_obj->error );
		}

		/** Archives rows and returns a revision, so it checks the one sent first, under the edit lock (spec §17). */
		if ( method_exists( 'BWFAN_Automation_V2', 'check_revision' ) && ! BWFAN_Automation_V2::check_revision( $this->automation_id, isset( $this->args['revision'] ) ? $this->args['revision'] : '' ) ) {
			return $this->error_response( __( 'This Automation changed since you opened it. Reload to see the latest version.', 'wp-marketing-automations-pro' ), null, 409 );
		}

		/** Get all nodes of split step */
		$split_steps = BWFAN_Model_Automationmeta::get_meta( $this->automation_id, 'split_steps' );
		if ( isset( $split_steps[ $step_id ] ) ) {
			$all_steps = $split_steps[ $step_id ];
		}

		/** Get steps to mark archive  */
		$steps_for_archive = [];
		foreach ( $all_steps as $path => $nodes ) {
			if ( $current_path === $path ) {
				continue;
			}
			$steps_for_archive = array_merge( $steps_for_archive, $nodes );
		}
		$steps_for_archive = array_filter( $steps_for_archive );

		/** Mark steps to split archive */
		BWFAN_Model_Automation_Step::update_steps_status( $steps_for_archive );

		$data = $this->set_winner_path( $step_id, $path_num );
		/** Save completed split steps */
		$this->save_completed_split( $step_id, $all_steps, $automation_obj );

		if ( is_array( $data ) && method_exists( 'BWFAN_Automation_V2', 'get_revision' ) ) {
			$data['revision'] = BWFAN_Automation_V2::get_revision( $this->automation_id ); // the builder's next save needs it (spec §17).
		}

		$this->response_code = 200;

		return $this->success_response( $data, __( 'Winner path set', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * @param $step_data
	 *
	 * @return array|array[]
	 */
	public function get_path_stats( $step_data ) {
		$create_time = $step_data['created_at'];
		$data        = isset( $step_data['data'] ) ? $step_data['data'] : [];
		/** Email and SMS steps in all paths */
		$mail_steps = isset( $data['sidebarData']['mail_steps'] ) ? $data['sidebarData']['mail_steps'] : [];

		if ( empty( $mail_steps ) ) {
			return [];
		}

		$paths_stats = [];
		$step_stats  = [];
		foreach ( $mail_steps as $path => $steps ) {

			$sent           = 0;
			$open_count     = 0;
			$click_count    = 0;
			$revenue        = 0;
			$unsubscribes   = 0;
			$conversions    = 0;
			$contacts_count = 0;

			/** Get analytics of each single step */
			foreach ( $steps as $step ) {
				$stats                        = BWFCRM_Automations::get_path_stats( $this->automation_id, [ $step ], $create_time, false );
				$path_num                     = str_replace( 'p-', '', $path );
				$contact_count                = BWFAN_Model_Automation_Contact_Trail::get_path_contact_count( $step_data['ID'], $path_num );
				$stats['tiles'][0]            = [
					'l' => 'Contacts',
					'v' => ! empty( $contact_count ) ? intval( $contact_count ) : '-',
				];
				$sent                         += intval( $stats['stats']['sent'] );
				$open_count                   += intval( $stats['stats']['open_count'] );
				$click_count                  += intval( $stats['stats']['click_count'] );
				$contacts_count               += intval( $stats['stats']['contacts_count'] );
				$revenue                      += floatval( $stats['stats']['revenue'] );
				$unsubscribes                 += intval( $stats['stats']['unsubscribes'] );
				$conversions                  += intval( $stats['stats']['conversions'] );
				$step_stats[ $step ]['tiles'] = $stats['tiles'];
			}

			$open_rate        = $open_count > 0 ? number_format( ( $open_count / $sent ) * 100, 1 ) : 0;
			$click_rate       = $click_count > 0 ? number_format( ( $click_count / $sent ) * 100, 1 ) : 0;
			$rev_per_person   = empty( $contacts_count ) || empty( $revenue ) ? 0 : number_format( $revenue / $contacts_count, 1 );
			$unsubscribe_rate = empty( $contacts_count ) || empty( $unsubscribes ) ? 0 : ( $unsubscribes / $contacts_count ) * 100;
			/** Get click rate from total opens */
			$click_to_open_rate = ( empty( $click_count ) || empty( $open_count ) ) ? 0 : number_format( ( $click_count / $open_count ) * 100, 1 );


			$paths_stats[ $path ] = [
				[
					'l' => __( 'Contact', 'wp-marketing-automations-pro' ),
					'v' => empty( $contacts_count ) ? '-' : $contacts_count,
				],
				[
					'l' => __( 'Sent', 'wp-marketing-automations-pro' ),
					'v' => empty( $sent ) ? '-' : $sent,
				],
				[
					'l' => __( 'Opened', 'wp-marketing-automations-pro' ),
					'v' => empty( $open_count ) ? '-' : $open_count . ' (' . $open_rate . '%)',
				],
				[
					'l' => __( 'Clicked', 'wp-marketing-automations-pro' ),
					'v' => empty( $click_count ) ? '-' : $click_count . ' (' . $click_rate . '%)',
				],
				[
					'l' => __( 'Click to Open.', 'wp-marketing-automations-pro' ),
					'v' => empty( $click_to_open_rate ) ? '-' : $click_to_open_rate . '%',
				],
			];
			if ( bwfan_is_woocommerce_active() ) {

				$currency_symbol = get_woocommerce_currency_symbol();
				$revenue         = empty( $revenue ) ? '' : html_entity_decode( $currency_symbol . $revenue, ENT_QUOTES | ENT_HTML401 );
				$rev_per_person  = empty( $rev_per_person ) ? '-' : html_entity_decode( $currency_symbol . $rev_per_person, ENT_QUOTES | ENT_HTML401 );

				$revenue_tiles = [
					[
						'l' => __( 'Rev.', 'wp-marketing-automations-pro' ),
						'v' => empty( $revenue ) ? '-' : $revenue . ' (' . $conversions . ')',
					],
					[
						'l' => __( 'Rev Per Contact', 'wp-marketing-automations-pro' ),
						'v' => empty( $rev_per_person ) ? '-' : $rev_per_person,
					]
				];

				$paths_stats[ $path ] = array_merge( $paths_stats[ $path ], $revenue_tiles );
			}
			$paths_stats[ $path ][] = [
				'l' => __( 'Unsubscribed', 'wp-marketing-automations-pro' ),
				'v' => empty( $unsubscribes ) ? '-' : $unsubscribes . ' (' . number_format( $unsubscribe_rate, 1 ) . '%)',
			];
		}

		return [
			'paths_stats' => $paths_stats,
			'step_steps'  => $step_stats
		];
	}

	/**
	 * Set winner path in split step data
	 *
	 * @param $step_id
	 * @param $winner_path
	 *
	 * @return array[]|void
	 */
	public function set_winner_path( $step_id, $winner_path ) {
		/** Step data */
		$data                         = BWFAN_Model_Automation_Step::get_step_data( $step_id );
		$sidebarData                  = isset( $data['data']['sidebarData'] ) ? $data['data']['sidebarData'] : [];
		$sidebarData['winner']        = $winner_path;
		$sidebarData['complete_time'] = current_time( 'mysql', 1 );
		/** Set split stats */
		$sidebarData['split_stats'] = $this->get_path_stats( $data );
		/** Set split preview data */
		$sidebarData['preview_data'] = BWFCRM_Automations::get_split_preview_data( $this->automation_id, $step_id );
		$this->save_step_data( $step_id, $sidebarData );
		$updated_data = [
			'sidebarData' => $sidebarData
		];

		return $updated_data;
	}

	/**
	 * @param $step_id
	 * @param $sidebarData
	 *
	 * @return void
	 */
	public function save_step_data( $step_id, $sidebarData ) {
		$updated_data = [
			'sidebarData' => $sidebarData
		];

		BWFAN_Model_Automation_Step::update( array(
			'data'   => wp_json_encode( $updated_data ),
			'status' => 4,
		), array(
			'ID' => $step_id,
		) );

	}

	/**
	 * @param $step_id
	 * @param $all_steps
	 * @param $automation_obj
	 *
	 * @return bool|void
	 */
	public function save_completed_split( $step_id, $all_steps, $automation_obj ) {
		$meta_data = $automation_obj->get_automation_meta_data();
		if ( ! isset( $meta_data['completed_split_steps'] ) ) {
			$split_steps = [
				$step_id => $all_steps
			];

			$data = [
				'completed_split_steps' => maybe_serialize( $split_steps )
			];

			return BWFAN_Model_Automationmeta::insert_automation_meta_data( $automation_obj->automation_id, $data );;
		}

		$split_steps             = $meta_data['completed_split_steps'];
		$split_steps[ $step_id ] = $all_steps;
		$meta_data_arr           = [
			'completed_split_steps' => maybe_serialize( $split_steps )
		];


		return BWFAN_Model_Automationmeta::update_automation_meta_values( $automation_obj->automation_id, $meta_data_arr );
	}

	/**
	 * GET /automation/{id}/conversions
	 */
	public function get_automation_conversions() {
		$automation_id  = $this->get_sanitized_arg( 'automation_id', 'text_field' );
		$automation_obj = BWFAN_Automation_V2::get_instance( $automation_id );

		/** Check for automation exists */
		if ( ! empty( $automation_obj->error ) ) {
			return $this->error_response( [], $automation_obj->error );
		}
		$this->aid = $automation_id;

		$conversions                    = BWFCRM_Automations::get_conversions( $automation_id, $this->pagination->offset, $this->pagination->limit );
		$conversions['automation_data'] = $automation_obj->automation_data;

		if ( isset( $conversions['automation_data']['v'] ) && 1 === absint( $conversions['automation_data']['v'] ) ) {
			$meta                                    = BWFAN_Model_Automationmeta::get_automation_meta( $automation_id );
			$conversions['automation_data']['title'] = isset( $meta['title'] ) ? $meta['title'] : '';
		}

		if ( empty( $conversions['total'] ) ) {
			$this->response_code = 404;
			$response            = __( "No orders found", "autonami-automations-pro" );

			return $this->success_response( $conversions, $response );
		}
		$this->total_count = $conversions['total'];

		return $this->success_response( $conversions, __( 'Got All Orders', 'wp-marketing-automations-pro' ) );
	}

	public function get_result_total_count() {
		return $this->total_count;
	}

	/**
	 * @return array
	 */
	public function get_result_count_data() {
		return [
			'failed' => BWFAN_Model_Automation_Contact::get_active_count( $this->aid, 2 )
		];
	}

	/**
	 * GET /automation/{id}/step/{id}/path/{id}
	 */
	public function get_split_path_stats_by_step() {
		$automation_id = $this->get_sanitized_arg( 'automation_id' );
		$step_id       = $this->get_sanitized_arg( 'step_id' );
		$path_id       = $this->get_sanitized_arg( 'path_id' );

		if ( empty( $automation_id ) || empty( $step_id ) ) {
			return $this->error_response( __( 'Invalid / Empty automation ID provided', 'wp-marketing-automations-pro' ), null, 400 );
		}
		$path_name = 'p-' . $path_id;

		/** Initiate automation object */
		$automation_obj = BWFAN_Automation_V2::get_instance( $automation_id );

		/** Check for automation exists */
		if ( ! empty( $automation_obj->error ) ) {
			return $this->error_response( [], $automation_obj->error );
		}

		$step_data = BWFAN_Model_Automation_Step::get_step_data_by_id( $step_id );
		$data      = isset( $step_data['data'] ) ? json_decode( $step_data['data'], true ) : [];
		if ( empty( $data ) || ! is_array( $data ) || ! isset( $data['sidebarData'] ) ) {
			return $this->success_response( [], __( 'Path stats not found', 'wp-marketing-automations-pro' ) );
		}
		/** Email and SMS steps in all paths */
		$mail_steps  = isset( $data['sidebarData']['mail_steps'] ) ? $data['sidebarData']['mail_steps'] : [];
		$split_stats = isset( $data['sidebarData']['split_stats'] ) ? $data['sidebarData']['split_stats'] : [];
		$step_stats  = isset( $split_stats['step_stats'] ) ? $split_stats['step_stats'] : [];


		if ( ! isset( $mail_steps[ $path_name ] ) ) {
			return $this->success_response( [], __( 'Path stats not found', 'wp-marketing-automations-pro' ) );
		}
		$path_steps = $mail_steps[ $path_name ];
		$final_data = [];
		foreach ( $path_steps as $step_id ) {
			if ( ! isset( $step_stats[ $step_id ] ) ) {
				$tid_data  = BWFAN_Model_Engagement_Tracking::get_engagements_tid( $automation_id, [ $step_id ] );
				$tids      = array_column( $tid_data, 'tid' );
				$templates = BWFAN_Model_Templates::get_templates_by_ids( $tids );
				$subject   = $type = '';
				foreach ( $tid_data as $data ) {
					$template = $templates[ $data['tid'] ];
					$subject  = isset( $template['subject'] ) ? $template['subject'] : '';
					$subject  = 1 === intval( $template['type'] ) ? $subject : $template['template'];
					$type     = $template['type'];
				}
				$tiles        = $this->get_path_stats_for_step( $automation_id, [ $step_id ], $step_data['created_at'] );
				$final_data[] = [
					'step'  => $step_id,
					'title' => $subject,
					'type'  => $type,
					'tile'  => $tiles,
				];
				continue;
			}

			$final_data[] = [
				'step'  => $step_id,
				'title' => isset( $step_stats[ $step_id ]['subject'] ) ? $step_stats[ $step_id ]['subject'] : '',
				'type'  => isset( $step_stats[ $step_id ]['type'] ) ? $step_stats[ $step_id ]['type'] : '',
				'tile'  => $step_stats[ $step_id ]['tiles'],
			];
		}

		$this->response_code = 200;

		return $this->success_response( $final_data, __( 'paths stats found', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * Get path's stats
	 *
	 * @param $automation_id
	 * @param $step_ids
	 * @param $after_date
	 *
	 * @return array|WP_Error
	 */
	public function get_path_stats_for_step( $automation_id, $step_ids, $after_date ) {
		if ( empty( $step_ids ) ) {
			return [];
		}
		$data = BWFAN_Model_Engagement_Tracking::get_automation_step_analytics( $automation_id, $step_ids, $after_date );

		if ( empty( $data ) || ! is_array( $data ) ) {
			return [];
		}

		$open_rate        = isset( $data['open_rate'] ) ? number_format( $data['open_rate'], 2 ) : 0;
		$click_rate       = isset( $data['click_rate'] ) ? number_format( $data['click_rate'], 2 ) : 0;
		$revenue          = isset( $data['revenue'] ) ? floatval( $data['revenue'] ) : 0;
		$unsubscribes     = isset( $data['unsbuscribers'] ) ? absint( $data['unsbuscribers'] ) : 0;
		$conversions      = isset( $data['conversions'] ) ? absint( $data['conversions'] ) : 0;
		$sent             = isset( $data['sent'] ) ? absint( $data['sent'] ) : 0;
		$open_count       = isset( $data['open_count'] ) ? absint( $data['open_count'] ) : 0;
		$click_count      = isset( $data['click_count'] ) ? absint( $data['click_count'] ) : 0;
		$contacts_count   = isset( $data['contacts_count'] ) ? absint( $data['contacts_count'] ) : 1;
		$rev_per_person   = empty( $contacts_count ) || empty( $revenue ) ? 0 : number_format( $revenue / $contacts_count, 2 );
		$unsubscribe_rate = empty( $contacts_count ) || empty( $unsubscribes ) ? 0 : ( $unsubscribes / $contacts_count ) * 100;

		/** Get click rate from total opens */
		$click_to_open_rate = ( empty( $click_count ) || empty( $open_count ) ) ? 0 : number_format( ( $click_count / $open_count ) * 100, 2 );

		$tiles = [
//			[
//				'l' => 'Contacts',
//				'v' => $contacts_count
//			],
			[
				'l' => __( 'Sent', 'wp-marketing-automations-pro' ),
				'v' => $sent,
			],
			[
				'l' => __( 'Opened', 'wp-marketing-automations-pro' ),
				'v' => empty( $open_count ) ? '-' : $open_count . '( ' . $open_rate . '% )',
			],
			[
				'l' => __( 'Clicked', 'wp-marketing-automations-pro' ),
				'v' => empty( $click_count ) ? '-' : $click_count . ' ( ' . $click_rate . '% )',
			],
			[
				'l' => __( 'Click to Open.', 'wp-marketing-automations-pro' ),
				'v' => $click_to_open_rate . '%',
			]
		];

		if ( bwfan_is_woocommerce_active() ) {

			$currency_symbol = get_woocommerce_currency_symbol();
			$revenue         = html_entity_decode( $currency_symbol . $revenue, ENT_QUOTES | ENT_HTML401 );
			$rev_per_person  = html_entity_decode( $currency_symbol . $rev_per_person, ENT_QUOTES | ENT_HTML401 );

			$revenue_tiles = [
				[
					'l' => __( 'Rev.', 'wp-marketing-automations-pro' ),
					'v' => empty( $revenue ) ? '-' : $revenue . ' ( ' . $conversions . ' )',
				],
				[
					'l' => __( 'Rev Per Contact', 'wp-marketing-automations-pro' ),
					'v' => $rev_per_person,
				]
			];

			$tiles = array_merge( $tiles, $revenue_tiles );
		}

		$tiles[] = [
			'l' => __( 'Unsubscribed', 'wp-marketing-automations-pro' ),
			'v' => empty( $unsubscribes ) ? '-' : $unsubscribes . '( ' . number_format( $unsubscribe_rate, 2 ) . '% )',
		];

		return $tiles;
	}

	/**
	 * GET /automation/{id}/step/{id}/path-stats
	 */
	public function get_automation_path_stats() {
		$automation_id = $this->get_sanitized_arg( 'automation_id' );
		$step_id       = $this->get_sanitized_arg( 'step_id' );

		if ( empty( $automation_id ) || empty( $step_id ) ) {
			return $this->error_response( __( 'Invalid / Empty automation ID provided', 'wp-marketing-automations-pro' ), null, 400 );
		}

		/** Initiate automation object */
		$automation_obj = BWFAN_Automation_V2::get_instance( $automation_id );

		/** Check for automation exists */
		if ( ! empty( $automation_obj->error ) ) {
			return $this->error_response( [], $automation_obj->error );
		}

		$step_data = BWFAN_Model_Automation_Step::get_step_data_by_id( $step_id );
		$data      = isset( $step_data['data'] ) ? json_decode( $step_data['data'], true ) : [];
		if ( empty( $data ) || ! is_array( $data ) || ! isset( $data['sidebarData'] ) ) {
			return $this->error_response( [], $automation_obj->error );
		}

		$default_stat = [
			[
				'l' => 'Sent',
				'v' => '-',
			],
			[
				'l' => 'Open Rate',
				'v' => '-',
			],
			[
				'l' => 'Click Rate',
				'v' => '-',
			],
			[
				'l' => 'Click to Open Rate',
				'v' => '-',
			],
			[
				'l' => 'Revenue',
				'v' => '-',
			],
			[
				'l' => 'Revenue/Contact',
				'v' => '-',
			],
			[
				'l' => 'Unsubscribe Rate',
				'v' => '-',
			]
		];

		/** Email and SMS steps in all paths */
		$mail_steps = isset( $data['sidebarData']['mail_steps'] ) ? $data['sidebarData']['mail_steps'] : [];
		if ( empty( $mail_steps ) ) {
			$split_path_count = isset( $data['sidebarData']['split_path'] ) ? intval( $data['sidebarData']['split_path'] ) : 3;
			$stats            = [];
			for ( $i = 1; $i <= $split_path_count; $i ++ ) {
				$stats[] = [
					'path' => $i,
					'tile' => $default_stat,
				];
			}

			return $this->success_response( $stats, __( 'No data found', 'wp-marketing-automations-pro' ) );
		}

		foreach ( $mail_steps as $path => $step_ids ) {
			$path    = str_replace( 'p-', '', $path );
			$tiles   = BWFCRM_Automations::get_path_stats( $automation_id, $step_ids, $step_data['created_at'] );
			$stats[] = [
				'path' => $path,
				'tile' => empty( $tiles ) ? $default_stat : $tiles,
			];
		}

		$this->response_code = 200;

		return $this->success_response( $stats, __( 'paths stats found', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * GET /automation/{id}/recipients/{contact_id}/timeline
	 */
	public function get_automation_recipient_timeline() {
		$automation_id       = $this->get_sanitized_arg( 'automation_id', 'text_field' );
		$contact_id          = $this->get_sanitized_arg( 'contact_id', 'text_field' );
		$mode                = ! empty( absint( $this->get_sanitized_arg( 'mode', 'text_field' ) ) ) ? $this->get_sanitized_arg( 'mode', 'text_field' ) : 1;
		$recipients_timeline = BWFAN_Model_Engagement_Tracking::get_automation_recipient_timeline( $automation_id, $contact_id, $mode );
		if ( empty( $recipients_timeline ) ) {
			return $this->success_response( [], __( 'No engagement found', 'wp-marketing-automations-pro' ) );
		}
		$this->recipients_timeline = $recipients_timeline;

		return $this->success_response( $recipients_timeline, __( 'Got All timeline', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * GET /automation/{id}/recipients
	 */
	public function get_automation_recipients() {
		$automation_id  = $this->get_sanitized_arg( 'automation_id', 'text_field' );
		$automation_obj = BWFAN_Automation_V2::get_instance( $automation_id );

		/** Check for automation exists */
		if ( ! empty( $automation_obj->error ) ) {
			return $this->error_response( [], $automation_obj->error );
		}
		$this->aid = $automation_id;

		$recipients               = BWFAN_Model_Engagement_Tracking::get_automation_recipents( $automation_id, $this->pagination->offset, $this->pagination->limit );
		$recipients['recipients'] = $recipients['conversations'];
		unset( $recipients['conversations'] );
		$recipients['automation_data'] = $automation_obj->automation_data;

		if ( isset( $recipients['automation_data']['v'] ) && 1 === absint( $recipients['automation_data']['v'] ) ) {
			$meta                                   = BWFAN_Model_Automationmeta::get_automation_meta( $automation_id );
			$recipients['automation_data']['title'] = isset( $meta['title'] ) ? $meta['title'] : '';
		}

		if ( empty( $recipients['total'] ) ) {
			$this->response_code = 404;
			$response            = __( "No recipients found", "autonami-automations-pro" );

			return $this->success_response( $recipients, $response );
		}

		$this->total_count = $recipients['total'];

		return $this->success_response( $recipients, __( 'Got All Recipients', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * GET /automation/{id}/split/{id}/preview
	 */
	public function get_automation_split_preview() {
		$automation_id = $this->get_sanitized_arg( 'automation_id' );
		$split_id      = $this->get_sanitized_arg( 'split_id' );

		if ( empty( $automation_id ) ) {
			return $this->error_response( __( 'Invalid / Empty automation ID provided', 'wp-marketing-automations-pro' ), null, 400 );
		}

		/** Initiate automation object */
		$automation_obj = BWFAN_Automation_V2::get_instance( $automation_id );

		/** Check for automation exists */
		if ( ! empty( $automation_obj->error ) ) {
			return $this->error_response( [], $automation_obj->error );
		}
		$split_data          = BWFAN_Model_Automation_Step::get_step_data( $split_id );
		$split_status        = isset( $split_data['status'] ) ? intval( $split_data['status'] ) : '';
		$this->response_code = 200;
		/** Split step is archive */
		if ( 4 === $split_status ) {
			$data = isset( $split_data['data']['sidebarData']['preview_data'] ) ? $split_data['data']['sidebarData']['preview_data'] : [];

			return $this->success_response( $data, __( 'Split step preview', 'wp-marketing-automations-pro' ) );
		}

		$data = BWFCRM_Automations::get_split_preview_data( $automation_id, $split_id, $automation_obj );

		return $this->success_response( $data, __( 'Split step preview', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * GET /automation/{id}/split-stats
	 */
	public function get_automation_split_stats() {
		$automation_id = $this->get_sanitized_arg( 'automation_id' );

		if ( empty( $automation_id ) ) {
			return $this->error_response( __( 'Invalid / Empty automation ID provided', 'wp-marketing-automations-pro' ), null, 400 );
		}

		/** Initiate automation object */
		$automation_obj = BWFAN_Automation_V2::get_instance( $automation_id );

		/** Check for automation exists */
		if ( ! empty( $automation_obj->error ) ) {
			return $this->error_response( [], $automation_obj->error );
		}

		$meta_data             = $automation_obj->get_automation_meta_data();
		$split_steps           = isset( $meta_data['split_steps'] ) ? $meta_data['split_steps'] : [];
		$completed_split_steps = isset( $meta_data['completed_split_steps'] ) ? $meta_data['completed_split_steps'] : [];
		$split_steps           = array_replace( $split_steps, $completed_split_steps );
		$prepared_data         = [];
		$empty_tiles           = [
			[
				'l' => __( 'Contacts', 'wp-marketing-automations-pro' ),
				'v' => '-',
			],
			[
				'l' => __( 'Sent', 'wp-marketing-automations-pro' ),
				'v' => '-',
			],
			[
				'l' => __( 'Opened', 'wp-marketing-automations-pro' ),
				'v' => '-',
			],
			[
				'l' => __( 'Clicked', 'wp-marketing-automations-pro' ),
				'v' => '-',
			],
			[
				'l' => __( 'Click to Open', 'wp-marketing-automations-pro' ),
				'v' => '-',
			],
			[
				'l' => __( 'Rev.', 'wp-marketing-automations-pro' ),
				'v' => '-',
			],
			[
				'l' => __( 'Rev. Per Contact', 'wp-marketing-automations-pro' ),
				'v' => '-',
			],
			[
				'l' => __( 'Unsubscribed', 'wp-marketing-automations-pro' ),
				'v' => '-',
			]
		];
		foreach ( $split_steps as $step_id => $step ) {
			$data = BWFAN_Model_Automation_Step::get_step_data( $step_id );

			$sidebarData = isset( $data['data']['sidebarData'] ) ? $data['data']['sidebarData'] : [];
			$paths       = isset( $sidebarData['mail_steps'] ) ? $sidebarData['mail_steps'] : [];
			$split_stats = isset( $sidebarData['split_stats'] ) ? $sidebarData['split_stats'] : [];
			$paths_stats = isset( $split_stats['paths_stats'] ) ? $split_stats['paths_stats'] : [];
			$title       = isset( $sidebarData['title'] ) ? $sidebarData['title'] : '';
			$completed   = isset( $sidebarData['complete_time'] ) ? $sidebarData['complete_time'] : '';
			$winner      = isset( $sidebarData['winner'] ) ? $sidebarData['winner'] : '';
			$desc        = isset( $sidebarData['desc'] ) ? $sidebarData['desc'] : '';
			$prep_data   = [
				'title'     => $title,
				'status'    => isset( $data['status'] ) && intval( $data['status'] ) !== 4 ? 'ongoing' : 'completed',
				'started'   => isset( $data['created_at'] ) ? $data['created_at'] : '',
				'completed' => $completed,
				'desc'      => $desc,
				'step_id'   => $step_id,
			];
			/** If no steps found in paths */
			if ( empty( $paths ) ) {
				$split_path_count = isset( $sidebarData['split_path'] ) ? intval( $sidebarData['split_path'] ) : 3;
				for ( $i = 1; $i <= $split_path_count; $i ++ ) {
					$prep_data['path'][] = [
						'path' => $i,
						'tile' => $empty_tiles
					];
				}
			}
			/** For ongoing split step */
			if ( empty( $split_stats ) ) {
				foreach ( $paths as $path_name => $mail_steps ) {
					$path = str_replace( 'p-', '', $path_name );
					if ( empty( $mail_steps ) ) {
						$prep_data['path'][] = [
							'path' => $path,
							'tile' => $empty_tiles
						];
						continue;
					}
					$tiles               = BWFCRM_Automations::get_path_stats( $automation_id, $mail_steps, $data['created_at'] );
					$contact_count       = BWFAN_Model_Automation_Contact_Trail::get_path_contact_count( $step_id, $path );
					$tiles[0]            = [
						'l' => __( 'Contacts', 'wp-marketing-automations-pro' ),
						'v' => ! empty( $contact_count ) ? intval( $contact_count ) : '-',
					];
					$prep_data['path'][] = [
						'path'   => $path,
						'tile'   => $tiles,
						'winner' => false,
					];
				}
				$prepared_data[] = $prep_data;
				continue;
			}

			/** For completed split step */
			foreach ( $paths as $path_name => $mail_steps ) {
				$path_stats = isset( $paths_stats[ $path_name ] ) ? $paths_stats[ $path_name ] : [];
				$p_name     = str_replace( 'p-', '', $path_name );
				if ( empty( $path_stats ) ) {
					$prep_data['path'][] = [
						'path' => $p_name,
						'tile' => $empty_tiles
					];
					continue;
				}

				$prep_data['path'][] = [
					'path'   => $p_name,
					'tile'   => $path_stats,
					'winner' => ( intval( $winner ) === intval( $p_name ) ),
				];
			}
			$prepared_data[] = $prep_data;
		}

		$key_values = array_column( $prepared_data, 'started' );
		array_multisort( $key_values, SORT_DESC, $prepared_data );

		$this->response_code = 200;

		return $this->success_response( [
			'automation_data' => $automation_obj->get_automation_data(),
			'data'            => $prepared_data,
		], __( 'paths stats found', 'wp-marketing-automations-pro' ) );
	}
}

BWFCRM_API_Automations_Controller::get_instance();
