<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Skip if the parent abstract is not loaded yet (e.g. old loader still in memory during a plugin-update file-swap); prevents a fatal that would abort the update.
if ( ! class_exists( 'BWFCRM_API_Controller' ) ) {
	return;
}

class BWFCRM_API_Funnelkit_Controller extends BWFCRM_API_Controller {

	public static $ins;

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	protected function register_routes() {
		$this->add_route( '/funnelkit/checkouts', [
			[ 'GET', 'get_checkouts' ],
		] );

		$this->add_route( '/funnelkit/optins', [
			[ 'GET', 'get_optins' ],
		] );
	}

	/**
	 * GET /funnelkit/checkouts
	 */
	public function get_checkouts() {
		$ids    = ! empty( $this->get_sanitized_arg( 'ids', 'text_field' ) ) ? $this->get_sanitized_arg( 'ids', 'text_field' ) : '';
		$ids    = ! empty( $ids ) ? explode( ',', $ids ) : array();
		$offset = ! empty( $this->get_sanitized_arg( 'offset' ) ) ? $this->get_sanitized_arg( 'offset', 'text_field' ) : 0;
		$limit  = ! empty( $this->get_sanitized_arg( 'limit' ) ) ? $this->get_sanitized_arg( 'limit', 'text_field' ) : 10;
		$search = $this->get_sanitized_arg( 'search', 'text_field' );

		if ( ! class_exists( 'WFACP_Common' ) ) {
			return $this->success_response( [] );
		}

		$data = $this->get_fk_checkout_pages( $search, $limit, $offset );

		if ( ! is_array( $data ) || 0 === count( $data ) ) {
			return array();
		}

		$result = array();

		foreach ( $data as $v ) {
			$id           = get_post_meta( $v['ID'], '_bwf_in_funnel', true );
			$funnel_title = '';
			if ( ! empty( $id ) ) {
				$get_funnel   = new WFFN_Funnel( $id );
				$funnel_title = $get_funnel instanceof WFFN_Funnel && 0 !== $get_funnel->get_id() ? $get_funnel->get_title() : '';
			}

			$funnel_title       = ! empty( $funnel_title ) ? " ($funnel_title - #{$v['ID']})" : " (#{$v['ID']})";
			$result[ $v['ID'] ] = $v['post_title'] . $funnel_title;
		}

		if ( ! empty( $ids ) ) {
			// trimming and converting ids to int value
			$ids = array_map( 'trim', $ids );
			$ids = array_map( 'intval', $ids );

			$result = array_filter( $result, function ( $checkout ) use ( $ids ) {
				return in_array( intval( $checkout ), $ids, true );
			}, ARRAY_FILTER_USE_KEY );
		}

		return $this->success_response( $result );
	}

	/**
	 * Get funnelKit checkout pages
	 *
	 * @param $search
	 * @param $limit
	 * @param $offset
	 *
	 * @return array|object|stdClass[]|null
	 */
	public function get_fk_checkout_pages( $search = '', $limit = 10, $offset = 0 ) {

		global $wpdb;
		$query = $wpdb->prepare( "SELECT * FROM `{$wpdb->posts}` WHERE `post_type` = %s AND `post_title` != '' AND `post_status` = %s ", WFACP_Common::get_post_type_slug(), 'publish' );
		if ( ! empty( $search ) ) {
			$query .= $wpdb->prepare( " AND `post_title` LIKE %s ", "%$search%" );
		}
		$query .= " ORDER BY `ID` DESC";
		if ( ! empty( $limit ) ) {
			$query .= $wpdb->prepare( " LIMIT %d, %d", $offset, $limit );
		}

		return $wpdb->get_results( $query, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
	}

	/**
	 * GET /funnelkit/optins
	 */
	public function get_optins() {
		$ids    = ! empty( $this->get_sanitized_arg( 'ids', 'text_field' ) ) ? $this->get_sanitized_arg( 'ids', 'text_field' ) : '';
		$ids    = ! empty( $ids ) ? explode( ',', $ids ) : array();
		$offset = ! empty( $this->get_sanitized_arg( 'offset' ) ) ? $this->get_sanitized_arg( 'offset', 'text_field' ) : 0;
		$limit  = ! empty( $this->get_sanitized_arg( 'limit' ) ) ? $this->get_sanitized_arg( 'limit', 'text_field' ) : 10;
		$search = $this->get_sanitized_arg( 'search', 'text_field' );

		if ( ! function_exists( 'WFOPP_Core' ) ) {
			return $this->success_response( [] );
		}

		$data = $this->get_optin_forms( $search, $limit, $offset );

		if ( ! is_array( $data ) || 0 === count( $data ) ) {
			return array();
		}

		$result = array();

		foreach ( $data as $v ) {
			$id                 = get_post_meta( $v['ID'], '_bwf_in_funnel', true );
			$get_funnel         = new WFFN_Funnel( $id );
			$funnel_title       = $get_funnel instanceof WFFN_Funnel && 0 !== $get_funnel->get_id() ? $get_funnel->get_title() : '';
			$funnel_title       = ! empty( $funnel_title ) ? " ($funnel_title - #{$v['ID']})" : " (#{$v['ID']})";
			$result[ $v['ID'] ] = $v['post_title'] . $funnel_title;
		}

		if ( ! empty( $ids ) ) {
			// trimming and converting ids to int value
			$ids = array_map( 'trim', $ids );
			$ids = array_map( 'intval', $ids );

			$result = array_filter( $result, function ( $optin ) use ( $ids ) {
				return in_array( intval( $optin ), $ids, true );
			}, ARRAY_FILTER_USE_KEY );
		}

		return $this->success_response( $result );
	}

	/**
	 * Get optin forms
	 *
	 * @param $search string
	 * @param $limit int
	 * @param $offset int
	 *
	 * @return array|object|stdClass[]|null
	 */
	public function get_optin_forms( $search = '', $limit = 10, $offset = 0 ) {
		global $wpdb;
		$query = $wpdb->prepare( "SELECT `ID`, `post_title` FROM `{$wpdb->posts}` WHERE `post_type` = %s AND `post_status` = %s", WFOPP_Core()->optin_pages->get_post_type_slug(), 'publish' );
		if ( ! empty( $search ) ) {
			$query .= $wpdb->prepare( " AND `post_title` LIKE %s", "%$search%" );
		}
		if ( ! empty( $limit ) ) {
			$query .= $wpdb->prepare( " LIMIT %d, %d", $offset, $limit );
		}

		return $wpdb->get_results( $query, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
	}
}

BWFCRM_API_Funnelkit_Controller::get_instance();
