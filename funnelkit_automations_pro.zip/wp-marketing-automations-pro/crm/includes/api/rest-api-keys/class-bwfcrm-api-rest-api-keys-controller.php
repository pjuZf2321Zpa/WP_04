<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * REST API Keys admin endpoints.
 *
 * GET    /get-api-keys
 * GET    /get-api-keys-by-userid/{user_id}
 * POST   /create-api-key/{user_id}
 * POST   /update-api-key/{api_key_id}
 * DELETE /delete-api-key/{api_key_id}
 */
// Skip if the parent abstract is not loaded yet (e.g. old loader still in memory during a plugin-update file-swap); prevents a fatal that would abort the update.
if ( ! class_exists( 'BWFCRM_API_Controller' ) ) {
	return;
}

class BWFCRM_API_Rest_API_Keys_Controller extends BWFCRM_API_Controller {

	public static $ins    = null;
	public $total_count   = 0;

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	protected function register_routes() {
		$this->add_route( '/get-api-keys', [
			[ 'GET', 'get_api_keys' ],
		] );


		$this->add_route( '/create-api-key/(?P<user_id>[\d]+)', [
			[ 'POST', 'create_api_key' ],
		] );

		$this->add_route( '/update-api-key/(?P<api_key_id>[\d]+)', [
			[ 'POST', 'update_api_key' ],
		] );

		$this->add_route( '/delete-api-key/(?P<api_key_id>[\d]+)', [
			[ 'DELETE', 'delete_api_key' ],
		] );
	}

	public function get_api_keys() {
		$limit  = ! empty( $this->args['limit'] ) ? absint( $this->args['limit'] ) : 30;
		$offset = ! empty( $this->args['offset'] ) ? absint( $this->args['offset'] ) : 0;
		$search = ! empty( $this->args['search'] ) ? $this->args['search'] : '';

		$fetch = BWFAN_Rest_API_DB_Model::fetch( array(), array(), $limit, $offset, $search, true );

		if ( is_wp_error( $fetch ) ) {
			return $this->error_response( __( 'API key could not be listed', 'wp-marketing-automations-pro' ), $fetch, 500 );
		}

		$this->total_count = isset( $fetch['total'] ) ? intval( $fetch['total'] ) : 0;
		$data              = isset( $fetch['data'] ) ? $fetch['data'] : [];

		$data = array_map( function ( $item ) {
			if ( isset( $item['api_key'] ) ) {
				$item['api_key'] = 'xxxx' . substr( $item['api_key'], - 6 );
			}

			return $item;
		}, $data );

		return $this->success_response( $data, __( 'API key listed successful', 'wp-marketing-automations-pro' ) );
	}


	public function create_api_key() {
		$user_id     = $this->get_sanitized_arg( 'user_id', 'text_field' );
		$permission  = $this->get_sanitized_arg( 'permission', 'text_field' );
		$description = $this->get_sanitized_arg( 'description', 'text_field' );
		$status      = $this->get_sanitized_arg( 'status', 'text_field' );
		$user_data   = get_user_by( 'ID', $user_id );

		if ( empty( $user_id ) || empty( $user_data ) ) {
			return $this->error_response( __( 'Required Parameter Missing : User ID not provided or user with this id does not exist', 'wp-marketing-automations-pro' ), null, 400 );
		}

		if ( empty( $permission ) ) {
			return $this->error_response( __( 'Required Parameter Missing : No permission provided', 'wp-marketing-automations-pro' ), null, 400 );
		}

		if ( strlen( $description ) > 200 ) {
			return $this->error_response( __( 'Description must be no longer than 200 characters', 'wp-marketing-automations-pro' ), null, 400 );
		}

		$data = [
			'uid'        => $user_id,
			'api_key'    => wp_generate_password( 40, false, false ),
			'created_by' => get_current_user_id() ? get_current_user_id() : 0,
			'created_at' => current_time( 'mysql', 1 ),
			'permission' => $permission,
		];

		if ( ! empty( $description ) ) {
			$data['description'] = $description;
		}

		if ( ! empty( $status ) ) {
			$data['status'] = $status;
		}

		$insert = BWFAN_Rest_API_DB_Model::insert( $data );

		if ( is_wp_error( $insert ) ) {
			return $this->error_response( __( 'API key not created', 'wp-marketing-automations-pro' ), $insert, 500 );
		}

		return $this->success_response( $data, __( 'API key created successfully', 'wp-marketing-automations-pro' ) );
	}

	public function update_api_key() {
		$api_key_id     = $this->get_sanitized_arg( 'api_key_id', 'text_field' );
		$permission     = $this->get_sanitized_arg( 'permission', 'text_field' );
		$description    = $this->get_sanitized_arg( 'description', 'text_field' );
		$status         = $this->get_sanitized_arg( 'status', 'text_field' );
		$update_api_key = $this->get_sanitized_arg( 'update_api_key', 'bool' );

		if ( empty( $api_key_id ) ) {
			return $this->error_response( __( 'Required parameter missing : No api key ID provided', 'wp-marketing-automations-pro' ), null, 400 );
		}

		if ( strlen( $description ) > 200 ) {
			return $this->error_response( __( 'Description must be no longer than 200 characters', 'wp-marketing-automations-pro' ), null, 400 );
		}

		$api_key_exists = BWFAN_Rest_API_DB_Model::fetch( array(), array( 'id' => $api_key_id ) );
		if ( empty( $api_key_exists ) ) {
			return $this->error_response( __( 'API key does not exist with ID #' . $api_key_id, 'wp-marketing-automations-pro' ), null, 400 );
		}

		$where = array( 'id' => $api_key_id );
		$data  = [
			'created_at' => current_time( 'mysql', 1 ),
		];

		if ( ! empty( $update_api_key ) && true === $update_api_key ) {
			$data['api_key'] = wp_generate_password( 40, false, false );
		}

		if ( ! empty( $permission ) ) {
			$data['permission'] = $permission;
		}

		if ( ! empty( $description ) ) {
			$data['description'] = $description;
		}

		if ( ! empty( $status ) ) {
			$data['status'] = $status;
		}

		$update = BWFAN_Rest_API_DB_Model::update( $data, $where );

		if ( is_wp_error( $update ) ) {
			return $this->error_response( __( 'API key update failed', 'wp-marketing-automations-pro' ), $update, 500 );
		}

		return $this->success_response( $data, __( 'API key updated successfully', 'wp-marketing-automations-pro' ) );
	}

	public function delete_api_key() {
		$api_key_id = $this->get_sanitized_arg( 'api_key_id', 'text_field' );

		if ( empty( $api_key_id ) ) {
			return $this->error_response( __( 'Required parameter missing : No API key ID provided', 'wp-marketing-automations-pro' ), null, 400 );
		}

		$api_key_exists = BWFAN_Rest_API_DB_Model::fetch( array(), array( 'id' => $api_key_id ) );

		if ( empty( $api_key_exists ) ) {
			return $this->error_response( __( 'API key does not exist with ID #' . $api_key_id, 'wp-marketing-automations-pro' ), null, 400 );
		}

		$data   = [ 'id' => $api_key_id ];
		$delete = BWFAN_Rest_API_DB_Model::delete( $data );

		if ( is_wp_error( $delete ) ) {
			return $this->error_response( __( 'API key could not be deleted', 'wp-marketing-automations-pro' ), $delete, 500 );
		}

		return $this->success_response( $data, __( 'API key deleted successfully', 'wp-marketing-automations-pro' ) );
	}

	public function get_result_total_count() {
		return $this->total_count;
	}
}

BWFCRM_API_Rest_API_Keys_Controller::get_instance();
