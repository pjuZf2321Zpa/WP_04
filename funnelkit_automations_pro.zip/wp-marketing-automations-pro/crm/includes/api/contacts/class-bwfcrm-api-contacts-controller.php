<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Skip if the parent abstract is not loaded yet (e.g. old loader still in memory during a plugin-update file-swap); prevents a fatal that would abort the update.
if ( ! class_exists( 'BWFCRM_API_Controller' ) ) {
	return;
}

class BWFCRM_API_Contacts_Controller extends BWFCRM_API_Controller {

	public static $ins;

	public $total_count = 0;
	public $count_data = [];
	public $contact;
	public $mode = null;

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	protected function register_routes() {

		/**
		 * GET /contacts — LEGACY backward-compat (broadcast/export/bulk contact listing).
		 * Old Lite (< fix/4604) calls un-versioned autonami-app/contacts; newer Lite calls the
		 * Lite-served /v3/contacts superset. fix/3225 removed this as a /v3 duplicate, which 404s
		 * old Lite + new Pro (independent update channels). Restored for that compat window only.
		 * TODO: remove get_contacts()/get_unopened_broadcast_contacts() once min Lite ships fix/4604.
		 */
		$this->add_route( '/contacts', [
			[ 'GET', 'get_contacts', array(
				'search'      => array( 'description' => __( 'Search from email, first_name or last_name', 'wp-marketing-automations-pro' ), 'type' => 'string' ),
				'offset'      => array( 'description' => __( 'Contacts list Offset', 'wp-marketing-automations-pro' ), 'type' => 'integer' ),
				'limit'       => array( 'description' => __( 'Per page limit', 'wp-marketing-automations-pro' ), 'type' => 'integer' ),
				'get_wc'      => array( 'description' => __( 'Get WC Data as well', 'wp-marketing-automations-pro' ), 'type' => 'boolean' ),
				'grab_totals' => array( 'description' => __( 'Grab total contact count as well', 'wp-marketing-automations-pro' ), 'type' => 'boolean' ),
			) ],
		] );

		/** GET /contacts/{id}/subscriptions */
		if ( class_exists( 'WC_Subscriptions' ) || ( function_exists( 'bwfan_is_sublium_active' ) && bwfan_is_sublium_active() ) ) {
			$this->add_route( '/contacts/(?P<contact_id>[\d]+)/subscriptions', [
				[ 'GET', 'get_contact_subscriptions' ],
			] );
		}

		/** GET /contacts/{id}/engagements */
		$this->add_route( '/contacts/(?P<contact_id>[\d]+)/engagements', [
			[ 'GET', 'get_contact_conversations', array(
				'contact_id' => array(
					'description' => __( 'Contact ID for which engagements to retrieve', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ],
		] );

	}

	/**
	 * GET /contacts (LEGACY compat — see register_routes note).
	 * Broadcast/export/bulk-aware listing. Delegates to BWFCRM_Contact::get_contacts().
	 */
	public function get_contacts() {
		// Honor the limit/offset already parsed from the request by handle_request;
		// fall back to a default page size only when the caller did not supply one.
		if ( empty( $this->pagination->limit ) ) {
			$this->pagination->limit = 10;
		}

		$additional_info = array(
			'grab_totals'          => $this->get_sanitized_arg( 'grab_totals', 'bool' ),
			'only_count'           => $this->get_sanitized_arg( 'only_count', 'bool' ),
			'fetch_base'           => $this->get_sanitized_arg( 'fetch_base', 'text_field' ),
			'exclude_unsubs'       => $this->get_sanitized_arg( 'exclude_unsubs', 'bool' ),
			'exclude_unsubs_lists' => $this->get_sanitized_arg( 'exclude_unsubs_lists', 'bool' ),
			'grab_custom_fields'   => $this->get_sanitized_arg( 'grab_custom_fields', 'bool' ),
			'include_soft_bounce'  => $this->get_sanitized_arg( 'includeSoftBounce', 'bool' ),
			'include_unverified'   => $this->get_sanitized_arg( 'includeUnverified', 'bool' ),
			'include_unsubscribe'  => $this->get_sanitized_arg( 'include_unsubs', 'bool' ),
			'include_ids'          => isset( $this->args['include_ids'] ) ? $this->args['include_ids'] : [],
			'is_broadcast'         => $this->get_sanitized_arg( 'is_broadcast', 'bool' ),
		);

		/** Un-Open contacts case */
		$un_open_broadcast = $this->get_sanitized_arg( 'unopen_broadcast', 'key' );
		if ( ! empty( $un_open_broadcast ) ) {
			return $this->get_unopened_broadcast_contacts( $un_open_broadcast, $additional_info );
		}

		$order    = $this->get_sanitized_arg( 'order', 'text_field' );
		$order_by = $this->get_sanitized_arg( 'order_by', 'text_field' );
		if ( ! empty( $order ) && ! empty( $order_by ) ) {
			$additional_info['order']    = $order;
			$additional_info['order_by'] = $order_by;
		}

		if ( class_exists( 'WooCommerce' ) ) {
			$additional_info['customer_data'] = $this->get_sanitized_arg( 'get_wc', 'bool' );
		}

		/** checking if search present in params */
		$search             = $this->get_sanitized_arg( 'search', 'text_field' );
		$filters_collection = empty( $this->args['filters'] ) ? array() : $this->args['filters'];

		if ( false === $additional_info['exclude_unsubs'] ) {
			$additional_info['exclude_unsubs'] = apply_filters( 'bwfan_force_exclude_unsubscribe_contact', false );
		}

		$contacts = BWFCRM_Contact::get_contacts( $search, $this->pagination->offset, $this->pagination->limit, $filters_collection, $additional_info );
		if ( ! is_array( $contacts ) ) {
			$this->response_code = 500;

			return $this->error_response( is_string( $contacts ) ? $contacts : __( 'Unknown error occurred', 'wp-marketing-automations-pro' ) );
		}

		if ( isset( $contacts['total_count'] ) ) {
			$this->total_count = absint( $contacts['total_count'] );
		}

		if ( ! isset( $contacts['contacts'] ) || empty( $contacts['contacts'] ) ) {
			return $this->success_response( array() );
		}

		$this->response_code = 200;

		return $this->success_response( $contacts['contacts'] );
	}

	public function get_unopened_broadcast_contacts( $broadcast_id, $additional_info ) {
		$additional_info['offset'] = $this->pagination->offset;
		$additional_info['limit']  = $this->pagination->limit;

		$contacts = BWFCRM_Core()->campaigns->get_unopen_broadcast_contacts( absint( $broadcast_id ), $additional_info );

		if ( ! is_array( $contacts ) ) {
			$this->response_code = 500;

			return $this->error_response( is_string( $contacts ) ? $contacts : __( 'Unknown error occurred', 'wp-marketing-automations-pro' ) );
		}

		if ( isset( $contacts['total_count'] ) ) {
			$this->total_count = absint( $contacts['total_count'] );
		}

		if ( ! isset( $contacts['contacts'] ) || empty( $contacts['contacts'] ) ) {
			return $this->success_response( array() );
		}

		$this->response_code = 200;

		return $this->success_response( $contacts['contacts'] );
	}

	/**
	 * GET /contacts/{id}/subscriptions
	 */
	public function get_contact_subscriptions() {
		if ( empty( $this->pagination->limit ) ) {
			$this->pagination->limit = 10;
		}

		/** checking if id or email present in params **/
		$contact_id = $this->get_sanitized_arg( 'contact_id', 'key' );
		$type       = $this->get_sanitized_arg( 'type', 'key' );

		/** contact id missing than return  */
		if ( empty( $contact_id ) ) {
			$this->response_code = 404;

			return $this->error_response( __( 'Contact id is mandatory', 'wp-marketing-automations-pro' ) );
		}

		$contact = new BWFCRM_Contact( $contact_id );

		if ( ! $contact->is_contact_exists() ) {
			$this->response_code = 404;

			return $this->error_response( __( 'No contact found related with contact id :' . $contact_id, 'wp-marketing-automations-pro' ) );
		}

		$limit  = $this->pagination->limit;
		$offset = $this->pagination->offset;

		$total_contact_subscriptions = 0;
		if ( 'sublium' === $type ) {
			$contact_orders = method_exists( $contact, 'get_sublium_subscriptions_array' ) ? $contact->get_sublium_subscriptions_array( $offset, $limit ) : [];
			$total_contact_subscriptions = method_exists( $contact, 'get_total_sublium_subscriptions' ) && ! empty( $contact_orders['subscriptions'] )  ? $contact->get_total_sublium_subscriptions() : 0;
		} else {
			$contact_orders = $contact->get_subscriptions_array( $offset, $limit );
			$total_contact_subscriptions = ! empty( $contact_orders['subscriptions'] ) ? $contact->get_total_subscriptions() : 0;
		}
		if ( empty( $contact_orders['subscriptions'] ) ) {
			$this->response_code = 200;

			return $this->success_response( [], __( 'No contact subscriptions found related with contact id :' . $contact_id, 'wp-marketing-automations-pro' ) );
		}
		$this->total_count           = $total_contact_subscriptions;
		$this->response_code         = 200;
		$success_message             = __( 'Got all contact subscriptions', 'wp-marketing-automations-pro' );

		return $this->success_response( $contact_orders, $success_message );
	}


	/**
	 * GET /contacts/{id}/engagements
	 */
	public function get_contact_conversations() {
		/** checking if id or email present in params **/
		$id         = $this->get_sanitized_arg( 'contact_id', 'key' );
		$this->mode = $this->get_sanitized_arg( 'mode', 'key' );
		$limit      = ! empty( $this->get_sanitized_arg( 'limit', 'text_field' ) ) ? $this->get_sanitized_arg( 'limit', 'text_field' ) : 25;
		$offset     = ! empty( $this->get_sanitized_arg( 'offset', 'text_field' ) ) ? $this->get_sanitized_arg( 'offset', 'text_field' ) : 0;

		if ( ! class_exists( 'BWFAN_Email_Conversations' ) || ! isset( BWFAN_Core()->conversations ) || ! BWFAN_Core()->conversations instanceof BWFAN_Email_Conversations ) {
			return $this->error_response( __( 'Unable to find conversations module', 'wp-marketing-automations-pro' ), null, 500 );
		}

		$this->contact = new BWFCRM_Contact( absint( $id ) );
		if ( ! $this->contact instanceof BWFCRM_Contact || ! $this->contact->is_contact_exists() ) {
			return $this->error_response( __( 'Contact doesn\'t exists', 'wp-marketing-automations-pro' ), null, 500 );
		}

		$conversation = $this->contact->get_conversations( $this->mode, $offset, $limit );
		if ( $conversation instanceof WP_Error ) {
			return $this->error_response( '', $conversation, 500 );
		}

		return $this->success_response( $conversation );
	}


	public function get_result_total_count() {
		if ( $this->contact instanceof BWFCRM_Contact && $this->contact->is_contact_exists() && null !== $this->mode ) {
			return $this->contact->get_conversations_total( $this->mode );
		}

		return $this->total_count;
	}

	public function get_result_count_data() {
		return $this->count_data;
	}
}

BWFCRM_API_Contacts_Controller::get_instance();
