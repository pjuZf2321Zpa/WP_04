<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Skip if the parent abstract is not loaded yet (e.g. old loader still in memory during a plugin-update file-swap); prevents a fatal that would abort the update.
if ( ! class_exists( 'BWFCRM_API_Controller' ) ) {
	return;
}

class BWFCRM_API_Layout_Controller extends BWFCRM_API_Controller {

	public static $ins;
	public $templates = array();
	public $total_count = 0;

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	protected function register_routes() {
		$this->add_route( '/layouts', [
			[ 'GET', 'get_layouts' ],
		] );

		$this->add_route( '/layout', [
			[ 'POST', 'create_layout' ],
		] );

		$this->add_route( '/layout/(?P<layout_id>[\\d]+)', [
			[ 'PUT', 'delete_layout' ],
		] );
	}

	public function default_args_values() {
		return array(
			'layout_id' => '',
			'title'     => '',
			'content'   => '',
		);
	}

	/**
	 * GET /layouts
	 */
	public function get_layouts() {
		$search  = ! empty( $this->get_sanitized_arg( 'search', 'text_field' ) ) ? $this->get_sanitized_arg( 'search', 'text_field' ) : '';
		$ids     = ! empty( $this->args['ids'] ) ? explode( ',', $this->args['ids'] ) : array();
		$limit   = ! empty( $this->get_sanitized_arg( 'limit', 'text_field' ) ) ? $this->get_sanitized_arg( 'limit', 'text_field' ) : 0;
		$offset  = ! empty( $this->get_sanitized_arg( 'offset', 'text_field' ) ) ? $this->get_sanitized_arg( 'offset', 'text_field' ) : 0;
		$layouts = BWFAN_Model_Templates::bwfan_get_layouts( $offset, $limit, $search, $ids );
		if ( ! is_array( $layouts ) ) {
			$layouts = array();
		}

		$layouts = array_map( function ( $layout ) {
			$data = [];
			if ( ! isset( $layout['ID'] ) ) {
				return;
			}
			if ( ! empty( $layout['data'] ) ) {
				$layout['data'] = json_decode( $layout['data'], true );
			}
			$data['ID']          = $layout['ID'];
			$data['title']       = isset( $layout['title'] ) ? $layout['title'] : '';
			$data['content']     = isset( $layout['template'] ) ? $layout['template'] : '';
			$data['categories']  = isset( $layout['data']['categories'] ) ? $layout['data']['categories'] : [];
			$data['description'] = isset( $layout['data']['desc'] ) ? $layout['data']['desc'] : '';

			return $data;
		}, $layouts );

		$this->total_count = BWFAN_Model_Templates::bwfan_get_layouts_count( $search, $ids );

		$this->response_code = 200;

		return $this->success_response( $layouts );
	}

	/**
	 * POST /layout
	 */
	public function create_layout() {
		$title      = isset( $this->args['title'] ) ? $this->get_sanitized_arg( 'title', 'text_field', $this->args['title'] ) : '';
		$desc       = isset( $this->args['desc'] ) ? $this->get_sanitized_arg( 'desc', 'text_field', $this->args['desc'] ) : '';
		$content    = isset( $this->args['content'] ) ? $this->args['content'] : '';
		$categories = isset( $this->args['categories'] ) ? $this->args['categories'] : [];

		if ( empty( $title ) ) {
			$this->response_code = 400;
			$response            = __( 'Name is required', 'wp-marketing-automations-pro' );

			return $this->error_response( $response );
		}

		if ( empty( $content ) ) {
			$this->response_code = 400;
			$response            = __( 'Layout body is required', 'wp-marketing-automations-pro' );

			return $this->error_response( $response );
		}

		$create_time = current_time( 'mysql', 1 );

		$data = [
			'desc'       => $desc,
			'categories' => $categories
		];

		$template_data = [
			'title'      => $title,
			'template'   => $content,
			'type'       => 1,
			'mode'       => 6,
			'canned'     => 0,
			'created_at' => $create_time,
			'updated_at' => $create_time,
			'data'       => json_encode( $data ),
		];

		$result = BWFAN_Model_Templates::bwfan_create_new_template( $template_data );
		if ( empty( $result ) ) {
			$this->response_code = 500;

			return $this->error_response( __( 'Unable to create layout', 'wp-marketing-automations-pro' ) );
		}

		return $this->success_response( [ 'id' => $result ], __( 'Layout Created Successfully', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * PUT /layout/(?P<layout_id>[\d]+)
	 */
	public function delete_layout() {

		$layout_id = (int) $this->get_sanitized_arg( 'layout_id', 'key' );

		if ( empty( $layout_id ) ) {
			$this->response_code = 404;
			$response            = __( 'Layout ID is mandatory', 'wp-marketing-automations-pro' );

			return $this->error_response( $response );
		}

		/** if the provided id doesn't exist */
		$already_exists = BWFAN_Model_Templates::bwfan_check_layout_exists( 'ID', $layout_id );
		if ( ! $already_exists ) {
			$this->response_code = 400;
			$response            = __( "Layout doesn't exists with ID : ", 'wp-marketing-automations-pro' ) . $layout_id;

			return $this->error_response( $response );
		}

		$delete_layout = BWFAN_Model_Templates::bwf_delete_layout( $layout_id );
		if ( false === $delete_layout ) {
			$this->response_code = 404;

			$response = __( 'Unable to delete the Layout', 'wp-marketing-automations-pro' );

			return $this->error_response( $response );
		}

		$this->response_code = 200;
		$success_message     = __( 'Layout deleted', 'wp-marketing-automations-pro' );

		return $this->success_response( [], $success_message );

	}

	/**
	 * Return template total count
	 *
	 * @return int
	 */
	public function get_result_total_count() {
		return $this->total_count;
	}
}

BWFCRM_API_Layout_Controller::get_instance();
