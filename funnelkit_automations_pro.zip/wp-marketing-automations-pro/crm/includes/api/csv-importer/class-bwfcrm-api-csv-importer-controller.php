<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Skip if the parent abstract is not loaded yet (e.g. old loader still in memory during a plugin-update file-swap); prevents a fatal that would abort the update.
if ( ! class_exists( 'BWFCRM_API_Controller' ) ) {
	return;
}

class BWFCRM_API_CSV_Importer_Controller extends BWFCRM_API_Controller {

	public static $ins;

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	protected function register_routes() {
		$route = version_compare( BWFAN_VERSION, '3.4.0', '>' ) ? '/import/csv-upload' : '/import/csv/upload';
		$this->add_route( $route, [
			[ 'POST', 'upload_csv' ],
		] );

	}

	/**
	 * POST /import/csv-upload (or /import/csv/upload for older versions)
	 */
	public function upload_csv() {
		$files = $this->args['files'];
		if ( empty( $files ) || ! is_array( $files['csv'] ) || ! is_uploaded_file( $files['csv']['tmp_name'] ) ) {
			$this->response_code = 400;

			return $this->error_response( __( 'Not any file found for import', 'wp-marketing-automations-pro' ) );
		}

		$delimiter = isset( $this->args['$delimiter'] ) && ! empty( $this->args['$delimiter'] ) ? $this->args['$delimiter'] : ',';

		$import_res = BWFCRM_CSV_Importer::create_import_from_csv( $files['csv'], $delimiter );
		if ( ! is_array( $import_res ) ) {
			return $this->error_response( is_string( $import_res ) ? $import_res : __( 'Unknown error occurred', 'wp-marketing-automations-pro' ), null, 500 );
		}

		$options = BWFCRM_CSV_Importer::get_mapping_options_from_csv( $import_res['file'], $delimiter );
		if ( ! is_array( $options ) ) {
			return $this->error_response( is_string( $options ) ? $options : __( 'Unknown error occurred', 'wp-marketing-automations-pro' ), null, 500 );
		}

		$result = array(
			'import_id' => $import_res['import_id'],
			'headers'   => $options['headers'],
			'fields'    => $options['fields'],
		);

		return $this->success_response( $result, __( 'Headers Data', 'wp-marketing-automations-pro' ) );
	}

}

BWFCRM_API_CSV_Importer_Controller::get_instance();
