<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Legacy backward-compat controller (GET only).
 *
 * Old FunnelKit Automations (Lite) versions call the un-versioned admin routes
 * `autonami-app/fields` and `autonami-app/all/fields` (GET). Newer Lite (with the
 * /v3 JS repoint) calls Lite-served `/v3/fields` and `/v3/all/fields` instead.
 *
 * fix/3225 removed the full Pro fields controller as a `/v3` duplicate, which 404s
 * those two GETs for anyone running new Pro + old Lite (the two plugins update on
 * independent channels — wordpress.org vs funnelkit.com). These two GET routes are
 * restored purely to cover that compat window. Field create/update/delete are NOT
 * restored — old Lite never called them un-versioned.
 *
 * TODO: remove this file (and the `fields`/`all` entries in class-bwfcrm-api-loader.php)
 * once the minimum supported Lite version ships the /v3 repoint (fix/4604).
 */
// Skip if the parent abstract is not loaded yet (e.g. old loader still in memory during a plugin-update file-swap); prevents a fatal that would abort the update.
if ( ! class_exists( 'BWFCRM_API_Controller' ) ) {
	return;
}

class BWFCRM_API_Fields_Controller extends BWFCRM_API_Controller {

	public static $ins;
	public $total_count = 0;

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	protected function register_routes() {
		$this->add_route( '/fields', [
			[ 'GET', 'get_fields' ],
		] );

		$this->add_route( '/all/fields', [
			[ 'GET', 'get_all_fields' ],
		] );
	}

	/**
	 * GET /fields
	 */
	public function get_fields() {
		$type       = isset( $this->args['type'] ) ? $this->get_sanitized_arg( 'type', 'text_field', $this->args['type'] ) : null;
		$all_fields = isset( $this->args['all'] ) ? $this->get_sanitized_arg( 'all', 'text_field', $this->args['all'] ) : false;
		$fields     = BWFCRM_Fields::get_custom_fields( null, $all_fields ? 1 : null, null, $all_fields ? false : true, $all_fields ? null : 1, $type );
		$fields     = BWFAN_PRO_Common::get_sorted_fields( $fields );
		$this->total_count = count( $fields );

		return $this->success_response( $fields, __( empty( $fields ) ? 'No Fields found.' : 'Got all fields', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * GET /all/fields
	 */
	public function get_all_fields() {
		$all_fields = BWFCRM_Fields::get_fields( '', 1 );
		if ( isset( $all_fields['creation_date'] ) ) {
			unset( $all_fields['creation_date'] );
		}
		$fields        = $all_fields;
		$select_fields = [ 'timezone', 'status', 'country' ];

		$statuses = [];
		if ( method_exists( 'BWFAN_Common', 'get_contact_status_array_list' ) ) {
			$status = BWFAN_Common::get_contact_status_array_list();
			foreach ( $status as $key => $value ) {
				$statuses[ $key ] = $value['name'];
			}
		} else {
			$statuses = array(
				'0' => 'Unverified',
				'1' => 'Subscribed',
				'3' => 'Unsubscribed',
				'2' => 'Bounced',
			);
		}

		$all_fields = array_map( function ( $field ) use ( $fields, $select_fields, $statuses ) {
			if ( ! is_array( $field ) ) {
				$field_id = array_search( $field, $fields );
				$field    = [
					'group_id' => 0,
					'ID'       => $field_id,
					'type'     => in_array( $field_id, $select_fields ) ? 4 : 1,
					'name'     => $field,
					'meta'     => [],
				];

				if ( 'status' === $field_id ) {
					$field['meta']['options'] = $statuses;
				}
			}

			return $field;
		}, $all_fields );

		$this->total_count = count( $all_fields );

		return $this->success_response( $all_fields, __( empty( $all_fields ) ? 'No Fields found.' : 'Got all fields', 'wp-marketing-automations-pro' ) );
	}

	public function get_result_total_count() {
		return $this->total_count;
	}
}

BWFCRM_API_Fields_Controller::get_instance();
