<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Skip if the parent abstract is not loaded yet (e.g. old loader still in memory during a plugin-update file-swap); prevents a fatal that would abort the update.
if ( ! class_exists( 'BWFCRM_API_Controller' ) ) {
	return;
}

class BWFCRM_API_Link_Triggers_Controller extends BWFCRM_API_Controller {

	public static $ins;
	public $total_count = 0;
	public $count_data = [];
	public $extra_data = [];

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	public function __construct() {
		$this->pagination         = new stdClass();
		$this->pagination->offset = 0;
		$this->pagination->limit  = 25;
		parent::__construct();
	}

	public function default_args_values() {
		return array(
			'link_id'            => 0,
			'title'              => '',
			'desc'               => '',
			'redirect_url'       => '',
			'redirect_url_title' => '',
			'add_contact_note'   => false,
			'actions'            => [],
			'enable_auto_login'  => false,
			'auto_login'         => array(
				'unit' => 'days',
				'text' => '7',
			),
			'action_run'         => '',
			'status'             => '',
			'only_title'         => false,
			'search'             => '',
			'offset'             => 0,
			'limit'              => 0,
			'ids'                => '',
			'category'           => '',
		);
	}

	protected function register_routes() {
		// GET /link-trigger/{id}/clone
		$this->add_route( '/link-trigger/(?P<link_id>[\d]+)/clone', array(
			array( 'GET', 'clone_link_trigger', array(
				'link_id' => array(
					'description' => __( 'Link ID whose data to be cloned.', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ),
		) );

		// POST /link-trigger + GET /link-trigger/{id} + POST /link-trigger/{id}
		$this->add_route( '/link-trigger', array(
			array( 'POST', 'create_link_trigger' ),
		) );

		$this->add_route( '/link-trigger/(?P<link_id>[\d]+)', array(
			array( 'GET', 'get_link_trigger', array(
				'link_id' => array(
					'description' => __( 'Link ID to retrieve', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ),
			array( 'POST', 'update_link_trigger' ),
		) );

		// DELETE /link-triggers/delete
		$this->add_route( '/link-triggers/delete', array(
			array( 'DELETE', 'delete_link_trigger' ),
		) );

		// GET /link-triggers/actions
		$this->add_route( '/link-triggers/actions', array(
			array( 'GET', 'get_actions' ),
		) );

		// GET /link-triggers
		$this->add_route( '/link-triggers', array(
			array( 'GET', 'get_link_triggers' ),
		) );
	}

	/**
	 * GET /link-trigger/{id}/clone
	 */
	public function clone_link_trigger() {
		$link_id = $this->get_sanitized_arg( 'link_id', 'key' );

		if ( intval( $link_id ) > 0 ) {
			$link_data           = BWFAN_Model_Link_Triggers::clone_link_trigger( $link_id );
			$this->response_code = $link_data['status'];
			if ( $link_data['status'] === 200 ) {
				return $this->success_response( [], $link_data['message'] );
			} else {
				return $this->error_response( $link_data['message'] );
			}
		} else {
			$this->response_code = 404;

			return $this->error_response( __( 'Please provide a valid link trigger id.', 'wp-marketing-automations-pro' ) );
		}
	}

	/**
	 * POST /link-trigger
	 */
	public function create_link_trigger() {
		$title              = $this->get_sanitized_arg( 'title', 'text_field', $this->args['title'] );
		$desc               = $this->get_sanitized_arg( 'desc', 'text_field', $this->args['desc'] );
		$redirect_url       = $this->get_sanitized_arg( 'redirect_url', 'text_field', $this->args['redirect_url'] );
		$redirect_url_title = $this->get_sanitized_arg( 'redirect_url_title', 'text_field', $this->args['redirect_url_title'] );
		$add_contact_note   = isset( $this->args['add_contact_note'] ) ? $this->get_sanitized_arg( 'add_contact_note', 'text_field', $this->args['add_contact_note'] ) : false;
		$actions            = $this->args['actions'];
		$only_title         = isset( $this->args['only_title'] ) ? $this->get_sanitized_arg( 'only_title', 'text_field', $this->args['only_title'] ) : false;
		$status             = 2;
		$enable_auto_login  = isset( $this->args['enable_auto_login'] ) ? $this->get_sanitized_arg( 'enable_auto_login', 'bool' ) : false;
		$auto_login         = isset( $this->args['auto_login'] ) ? $this->args['auto_login'] : array();
		if ( $only_title ) {
			$status = 0;
		}

		if ( empty( $title ) ) {
			$this->response_code = 400;
			$response            = __( 'Oops Title not entered, enter title to create smart link', 'wp-marketing-automations-pro' );

			return $this->error_response( $response );
		}

		$already_exists = BWFAN_Model_Link_Triggers::check_link_exists_with( 'title', $title );

		if ( $already_exists ) {
			$this->response_code = 400;
			$response            = __( 'Links trigger already exists with title : ', 'wp-marketing-automations-pro' ) . $title;

			return $this->error_response( $response );
		}
		$create_time = current_time( 'mysql', 1 );

		if ( isset( $actions['add_tags'] ) ) {
			/** Create Tags if not exists */
			$actions['add_tags'] = $this->process_terms( $actions['add_tags'] ?? [], BWFCRM_Term_Type::$TAG );
			if ( empty( $actions['add_tags'] ) ) {
				unset( $actions['add_tags'] );
			}
		}

		if ( isset( $actions['add_to_lists'] ) ) {
			/** Create Lists if not exists */
			$actions['add_to_lists'] = $this->process_terms( $actions['add_to_lists'] ?? [], BWFCRM_Term_Type::$LIST );
			if ( empty( $actions['add_to_lists'] ) ) {
				unset( $actions['add_to_lists'] );
			}
		}

		$data      = [
			'redirect_url'       => ! empty( $redirect_url ) ? $redirect_url : '',
			'actions'            => ! empty( $actions ) ? $actions : [],
			'desc'               => ! empty( $desc ) ? $desc : '',
			'redirect_url_title' => $redirect_url_title,
			'add_contact_note'   => $add_contact_note,
			'enable_auto_login'  => $enable_auto_login,
			'auto_login'         => $auto_login,
		];
		$link_data = [
			'title'      => $title,
			'status'     => $status,
			'created_at' => $create_time,
			'updated_at' => $create_time,
			'data'       => wp_json_encode( $data ),
			'created_by' => get_current_user_id()
		];

		$result = BWFAN_Model_Link_Triggers::bwfan_create_new_link_trigger( $link_data );
		if ( empty( $result ) ) {
			$this->response_code = 500;

			return $this->error_response( __( 'Unable to create link trigger', 'wp-marketing-automations-pro' ) );
		}

		return $this->success_response( [ 'id' => $result ], __( 'Link trigger Created', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * Process term and return term ids
	 *
	 * @param array $item Term data.
	 * @param string $type Term type.
	 *
	 * @return array
	 */
	public function process_terms( $item = [], $type = '' ) {
		if ( is_array( $item ) && ! empty( $item ) ) {
			return BWFAN_PRO_Common::get_or_create_terms( $item, $type );
		}

		return [];
	}

	/**
	 * DELETE /link-triggers/delete
	 */
	public function delete_link_trigger() {
		$link_ids = $this->args['ids'];

		if ( empty( $link_ids ) || ! is_array( $link_ids ) ) {
			return $this->error_response( __( 'Links ids are missing.', 'wp-marketing-automations-pro' ), null, 500 );
		}

		/** delete links */
		$delete_link = BWFAN_Model_Link_Triggers::delete_multiple_links( $link_ids );

		if ( false === $delete_link ) {
			$this->response_code = 404;

			$response = __( 'Unable to delete the link triggers', 'wp-marketing-automations-pro' );

			return $this->error_response( $response );
		}

		$this->response_code = 200;
		$success_message     = __( 'Link triggers deleted.', 'wp-marketing-automations-pro' );

		return $this->success_response( [], $success_message );

	}

	/**
	 * GET /link-triggers/actions
	 */
	public function get_actions() {
		$response = [
			'actions'        => $this->format_action_array( BWFCRM_Core()->actions->get_all_action_list( 1 ) ),
			'actions_schema' => BWFCRM_Core()->actions->get_all_actions_schema_data(),
		];

		$this->response_code = 200;

		return $this->success_response( $response );
	}

	/**
	 * Format the action data
	 *
	 * @param $actions
	 *
	 * @return array|array[]
	 */
	public function format_action_array( $actions ) {

		if ( empty( $actions ) ) {
			return [];
		}

		return array_map( function ( $slug, $nice_name ) {
			return [
				'value' => $slug,
				'label' => $nice_name,
			];
		}, array_keys( $actions ), $actions );
	}

	/**
	 * GET /link-trigger/{id}
	 */
	public function get_link_trigger() {
		$link_id = $this->get_sanitized_arg( 'link_id' );
		if ( empty( $link_id ) ) {
			return $this->error_response( __( 'Invalid / Empty link ID provided', 'wp-marketing-automations-pro' ), null, 400 );
		}

		$linkdata = BWFAN_Model_Link_Triggers::bwfan_get_link_trigger( $link_id );

		if ( empty( $linkdata ) ) {
			return $this->error_response( __( 'Links trigger not found with provided ID', 'wp-marketing-automations-pro' ), null, 400 );
		} else {
			$temp = ! empty( $linkdata['data'] ) ? (array) $linkdata['data'] : [];
			unset( $linkdata['data'] );
			$linkdata = array_merge( $linkdata, $temp );
		}

		/** Fetch updated list */
		if ( isset( $linkdata['actions']['add_to_lists'] ) ) {
			$linkdata['actions']['add_to_lists'] = BWFAN_Common::get_updated_tags_and_list( $linkdata['actions']['add_to_lists'] );
		}

		/** Fetch updated Tags */
		if ( isset( $linkdata['actions']['add_tags'] ) ) {
			$linkdata['actions']['add_tags'] = BWFAN_Common::get_updated_tags_and_list( $linkdata['actions']['add_tags'] );
		}

		$response = [
			'link_data'     => $linkdata,
			'actions'       => $this->format_action_array( BWFCRM_Core()->actions->get_all_action_list( 1 ) ),
			'action_schema' => BWFCRM_Core()->actions->get_all_actions_schema_data(),
		];

		$this->response_code = 200;

		return $this->success_response( $response );
	}

	/**
	 * POST /link-trigger/{id}
	 */
	public function update_link_trigger() {
		$title              = $this->get_sanitized_arg( 'title', 'text_field', $this->args['title'] );
		$desc               = $this->get_sanitized_arg( 'desc', 'text_field', $this->args['desc'] );
		$redirect_url       = $this->get_sanitized_arg( 'redirect_url', 'text_field', $this->args['redirect_url'] );
		$redirect_url_title = $this->get_sanitized_arg( 'redirect_url_title', 'text_field', $this->args['redirect_url_title'] );
		$action_run         = isset( $this->args['action_run'] ) ? $this->get_sanitized_arg( 'action_run', 'text_field', $this->args['action_run'] ) : 'once';
		$status             = isset( $this->args['status'] ) ? $this->get_sanitized_arg( 'status', 'text_field', $this->args['status'] ) : false;
		$add_contact_note   = isset( $this->args['add_contact_note'] ) ? $this->get_sanitized_arg( 'add_contact_note', 'bool', $this->args['add_contact_note'] ) : false;
		$enable_auto_login  = isset( $this->args['enable_auto_login'] ) ? $this->get_sanitized_arg( 'enable_auto_login', 'bool' ) : false;
		$auto_login         = isset( $this->args['auto_login'] ) ? $this->args['auto_login'] : array();
		$actions            = $this->args['actions'];
		$link_id            = $this->get_sanitized_arg( 'link_id', 'key' );
		if ( empty( $title ) ) {
			$this->response_code = 400;
			$response            = __( 'Oops Title not entered, enter title to save template', 'wp-marketing-automations-pro' );

			return $this->error_response( $response );
		}

		$already_exists = BWFAN_Model_Link_Triggers::check_link_exists_with( 'ID', $link_id );

		if ( ! $already_exists ) {
			$this->response_code = 400;
			$response            = __( "Links trigger doesn't exists with id : ", 'wp-marketing-automations-pro' ) . $link_id;

			return $this->error_response( $response );
		}

		$create_time = current_time( 'mysql', 1 );
		/** Create Tags if not exists */
		$add_tags = isset( $actions['add_tags'] ) ? $actions['add_tags'] : [];
		if ( is_array( $add_tags ) && ! empty( $add_tags ) && method_exists( 'BWFAN_PRO_Common', 'get_or_create_terms' ) ) {
			$tags                = BWFAN_PRO_Common::get_or_create_terms( $add_tags, BWFCRM_Term_Type::$TAG );
			$actions['add_tags'] = $tags;
		}

		/** Create Lists if not exists */
		$add_to_lists = isset( $actions['add_to_lists'] ) ? $actions['add_to_lists'] : [];
		if ( is_array( $add_to_lists ) && ! empty( $add_to_lists ) && method_exists( 'BWFAN_PRO_Common', 'get_or_create_terms' ) ) {
			$lists                   = BWFAN_PRO_Common::get_or_create_terms( $add_to_lists, BWFCRM_Term_Type::$LIST );
			$actions['add_to_lists'] = $lists;
		}

		$data = array(
			'redirect_url'       => ! empty( $redirect_url ) && filter_var( $redirect_url, FILTER_VALIDATE_URL ) !== false ? $redirect_url : '',
			'actions'            => $actions,
			'redirect_url_title' => $redirect_url_title,
			'action_run'         => $action_run === 'once' ? $action_run : 'multiple',
			'desc'               => ! empty( $desc ) ? $desc : '',
			'add_contact_note'   => $add_contact_note,
			'enable_auto_login'  => $enable_auto_login,
			'auto_login'         => $auto_login,
		);

		$link_data = array(
			'title'      => $title,
			'status'     => $status,
			'updated_at' => $create_time,
			'data'       => wp_json_encode( $data ),
		);

		$result = BWFAN_Model_Link_Triggers::update_link_trigger_data( $link_id, $link_data );

		if ( empty( $result ) ) {
			$this->response_code = 500;

			return $this->error_response( __( 'Unable to create link trigger', 'wp-marketing-automations-pro' ) );
		}

		$link_data = BWFAN_Model_Link_Triggers::bwfan_get_link_trigger( $link_id );

		if ( empty( $link_data ) ) {
			return $this->error_response( __( 'Link trigger not found with provided ID', 'wp-marketing-automations-pro' ), null, 400 );
		} else {
			$temp = ! empty( $link_data['data'] ) ? (array) $link_data['data'] : array();
			unset( $link_data['data'] );
			$link_data = array_merge( $link_data, $temp );
		}

		return $this->success_response( $link_data, __( 'Link trigger saved', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * GET /link-triggers
	 */
	public function get_link_triggers() {

		$search   = (string) $this->get_sanitized_arg( 'search', 'text_field' );
		$offset   = ! empty( $this->get_sanitized_arg( 'offset', 'key' ) ) ? $this->get_sanitized_arg( 'offset', 'text_field' ) : 0;
		$limit    = ! empty( $this->get_sanitized_arg( 'limit', 'key' ) ) ? $this->get_sanitized_arg( 'limit', 'text_field' ) : 0;
		$status   = ! empty( $this->get_sanitized_arg( 'status', 'key' ) ) ? $this->get_sanitized_arg( 'status', 'text_field' ) : '';
		$link_ids = empty( $this->args['ids'] ) ? array() : explode( ',', $this->args['ids'] );
		$category = ! empty( $this->get_sanitized_arg( 'category', 'key' ) ) ? $this->get_sanitized_arg( 'category', 'text_field' ) : '';

		/**
		 * Get links data
		 */
		$link_data                   = BWFAN_Model_Link_Triggers::get_link_triggers( $search, $status, $limit, $offset, true, $link_ids, $category );
		$links                       = isset( $link_data['links'] ) ? $link_data['links'] : [];
		$this->total_count           = isset( $link_data['total'] ) ? intval( $link_data['total'] ) : 0;
		$this->count_data            = BWFAN_PRO_Common::get_link_triggers_data_count();
		$this->extra_data['actions'] = ( array ) BWFCRM_Core()->actions->get_all_action_list( 1 );
		$this->response_code         = 200;

		return $this->success_response( $links );
	}

	/**
	 * Returns total count
	 *
	 * @return int
	 */
	public function get_result_total_count() {
		return $this->total_count;
	}

	/**
	 * Returns links count based on status
	 *
	 * @return array|int
	 */
	public function get_result_count_data() {
		return $this->count_data;
	}

	/**
	 * Returns extra data
	 *
	 * @return array|int
	 */
	public function get_result_extra_data() {
		return $this->extra_data;
	}
}

BWFCRM_API_Link_Triggers_Controller::get_instance();
