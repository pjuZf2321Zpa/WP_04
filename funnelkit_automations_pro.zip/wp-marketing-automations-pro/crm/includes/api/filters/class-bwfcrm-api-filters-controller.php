<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Skip if the parent abstract is not loaded yet (e.g. old loader still in memory during a plugin-update file-swap); prevents a fatal that would abort the update.
if ( ! class_exists( 'BWFCRM_API_Controller' ) ) {
	return;
}

class BWFCRM_API_Filters_Controller extends BWFCRM_API_Controller {

	public static $ins;
	public $total_count = 0;

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	protected function register_routes() {
		$this->add_route( '/filters', [
			[ 'GET', 'get_filters' ],
		] );

		$this->add_route( '/contact/filters/(?P<filter>[a-zA-Z0-9_-]+)/suggestions', [
			[ 'GET', 'get_filter_suggestions' ],
		] );
	}

	/**
	 * GET /filters
	 */
	public function get_filters() {

		$load_instance     = BWFCRM_Load_Filters::get_instance();
		$filters           = $load_instance->get_filters();
		$this->total_count = count( $filters );

		return $this->success_response( $filters, empty( $filters ) ? __( 'No Filters found.', 'wp-marketing-automations-pro' ) : __( 'Successfully fetched filters', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * GET /contact/filters/(?P<filter>[a-zA-Z0-9_-]+)/suggestions
	 */
	public function get_filter_suggestions() {
		$rule = $this->get_sanitized_arg( 'filter' );
		if ( empty( $rule ) ) {
			return $this->error_response_200( __( 'Invalid or empty filter', 'wp-marketing-automations-crm' ), null, 400 );
		}

		// removed get_sanitized_arg function because that was merging two or more substrings and making one
		// for example : cart abandonment. with get_sanitized_arg, it is becoming cartabandonment, which making issue in search
		$search = $this->args['search'] ?? '';

		$result = BWFCRM_Core()->filters->get_filter_search_suggestions( $search, $rule );

		return $this->success_response( $result );
	}

	public function get_result_total_count() {
		return $this->total_count;
	}
}

BWFCRM_API_Filters_Controller::get_instance();
