<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Skip if the parent abstract is not loaded yet (e.g. old loader still in memory during a plugin-update file-swap); prevents a fatal that would abort the update.
if ( ! class_exists( 'BWFCRM_API_Controller' ) ) {
	return;
}

class BWFCRM_API_Importer_Controller extends BWFCRM_API_Controller {

	public static $ins;

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	protected function register_routes() {
		$this->add_route( '/import/processes', [
			[ 'GET', 'get_processes' ],
		] );

	}

	/**
	 * GET /import/processes
	 */
	public function get_processes() {
		/**
		 * Legacy importer stack absent on Lite >= 3.7.0. Nothing can have started a
		 * legacy import in the first place — no route creates one and no app calls
		 * this endpoint — so an empty list is accurate rather than a silent omission.
		 * See docs/IMPORTER-VERSION-GATE.md.
		 */
		if ( ! is_object( BWFCRM_Core()->importer ) ) {
			return $this->success_response( array( 'imports' => array() ), '' );
		}

		/** Outputs **/
		$processes = BWFCRM_Core()->importer->get_existing_processes();
		if ( is_string( $processes ) ) {
			return $this->error_response( $processes, null, 500 );
		}

		if ( is_wp_error( $processes ) ) {
			return $this->error_response( '', $processes, 500 );
		}

		return $this->success_response( array( 'imports' => $processes ), '' );
	}

}

BWFCRM_API_Importer_Controller::get_instance();
