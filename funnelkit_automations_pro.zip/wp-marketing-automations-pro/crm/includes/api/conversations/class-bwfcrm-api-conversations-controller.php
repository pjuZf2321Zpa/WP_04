<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Skip if the parent abstract is not loaded yet (e.g. old loader still in memory during a plugin-update file-swap); prevents a fatal that would abort the update.
if ( ! class_exists( 'BWFCRM_API_Controller' ) ) {
	return;
}

class BWFCRM_API_Conversations_Controller extends BWFCRM_API_Controller {

	public static $ins;
	public $contact;

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	public function __construct() {
		$this->pagination         = new stdClass();
		$this->pagination->offset = 0;
		$this->pagination->limit  = 25;
		parent::__construct();
	}

	public function default_args_values() {
		return array(
			'template_id' => 0,
			'email'       => '',
			'content'     => 0,
			'phone'       => '',
			'sms_body'    => '',
			'sms_data'    => [],
		);
	}

	protected function register_routes() {
		// GET /messages/daily-limit
		$this->add_route( '/messages/daily-limit', array(
			array( 'GET', 'get_message_daily_limit' ),
		) );


		// POST /send-test-email
		$this->add_route( '/send-test-email', array(
			array( 'POST', 'send_test_mail' ),
		) );

		// POST /send-test-sms
		$this->add_route( '/send-test-sms', array(
			array( 'POST', 'send_test_sms' ),
		) );

		// POST /send-test-whatsapp-message
		$this->add_route( '/send-test-whatsapp-message', array(
			array( 'POST', 'send_test_whatsapp_message' ),
		) );

		// POST /upload-image
		$this->add_route( '/upload-image', array(
			array( 'POST', 'upload_image' ),
		) );
	}

	/**
	 * GET /messages/daily-limit
	 */
	public function get_message_daily_limit() {
		$daily_limit = BWFCRM_Core()->campaigns->get_daily_limit_status_array();

		return $this->success_response( $daily_limit );
	}


	/**
	 * POST /send-test-email
	 */
	public function send_test_mail() {
		$content = isset( $this->args['content'] ) ? $this->args['content'] : [];
		$content = BWFAN_Common::is_json( $content ) ? json_decode( $content, true ) : $content;
		if ( empty( $content ) ) {
			return $this->error_response( __( 'No content data found', 'wp-marketing-automations-pro' ) );
		}

		if ( isset( $content['mail_data'] ) && is_array( $content['mail_data'] ) ) {
			$mail_data = $content['mail_data'];
			unset( $content['mail_data'] );
			$content = array_replace( $content, $mail_data );
		}

		$content['email'] = $this->get_sanitized_arg( 'email', 'text_field' );

		if ( BWFAN_Common::send_test_email( $content ) ) {
			return $this->success_response( '', 'Test Email Sent' );
		}

		return $this->error_response( 'Unable to send test email', null, 500 );
	}

	/**
	 * POST /send-test-sms
	 */
	public function send_test_sms() {
		if ( ! isset( $this->args ) || empty( $this->args ) || ! is_array( $this->args ) ) {
			return $this->error_response( __( 'No data found', 'wp-marketing-automations-pro' ) );
		}

		$phone = $this->args['phone'];
		if ( empty( $phone ) ) {
			return $this->error_response( __( 'Phone no is required.', 'wp-marketing-automations-pro' ), null, 400 );
		}

		$sms_body = $this->args['sms_body'];
		if ( empty( $sms_body ) ) {
			return $this->error_response( __( 'SMS body is required.', 'wp-marketing-automations-pro' ), null, 400 );
		}

		BWFAN_Merge_Tag_Loader::set_data( array(
			'is_preview' => true,
		) );
		$sms_body = BWFAN_Common::decode_merge_tags( $sms_body );
		/** Append UTM parameters */
		$sms_body = BWFAN_PRO_Common::add_test_broadcast_utm_params( $sms_body, $this->args['sms_data'], 'sms' );

		$send_sms_result = BWFCRM_Common::send_sms( array(
			'to'      => $phone,
			'body'    => $sms_body,
			'is_test' => true
		) );

		if ( $send_sms_result instanceof WP_Error ) {
			return $this->error_response( 'Unable to send test sms. Error: ' . $send_sms_result->get_error_message(), null, 500 );
		}

		return $this->success_response( '', 'Test SMS Sent' );
	}

	/**
	 * POST /send-test-whatsapp-message
	 */
	public function send_test_whatsapp_message() {
		if ( ! isset( $this->args ) || empty( $this->args ) || ! is_array( $this->args ) ) {
			return $this->error_response( __( 'No data found', 'wp-marketing-automations-pro' ) );
		}

		$phone = $this->args['phone'];
		if ( empty( $phone ) ) {
			return $this->error_response( __( 'Phone no is required.', 'wp-marketing-automations-pro' ), null, 400 );
		}

		$sms_body = $this->args['sms_body'];
		if ( empty( $sms_body ) ) {
			return $this->error_response( __( 'SMS body is required.', 'wp-marketing-automations-pro' ), null, 400 );
		}
		$data      = [];
		$imagedata = [];
		$first     = false;
		if ( ! empty( $sms_body ) ) {
			if ( isset( $sms_body['body'] ) && ! empty( $sms_body ) ) {

				/** Decode Merge Tags for Preview */
				BWFAN_Merge_Tag_Loader::set_data( array(
					'is_preview' => true,
				) );
				$sms_body['body'] = BWFAN_Common::decode_merge_tags( $sms_body['body'] );

				$data = array(
					'type' => 'text',
					'data' => $sms_body['body'],
				);
			}
			if ( isset( $sms_body['whatsAppImage'] ) && $sms_body['whatsAppImage'] && isset( $sms_body['whatsAppImageSetting'] ) && isset( $sms_body['whatsAppImageSetting']['imageURL'] ) && ! empty( $sms_body['whatsAppImageSetting']['imageURL'] ) ) {
				$imagedata = array(
					'type' => 'image',
					'data' => $sms_body['whatsAppImageSetting']['imageURL'],
				);
				if ( isset( $sms_body['whatsAppImageSetting']['position'] ) && ! empty( $sms_body['whatsAppImageSetting']['position'] ) && $sms_body['whatsAppImageSetting']['position'] != 'after' ) {
					$first = true;
				}
			}
		}
		$finalData = [];
		if ( ! empty( $imagedata ) ) {
			if ( $first ) {
				$finalData = [ $imagedata, $data ];
			} else {
				$finalData = [ $data, $imagedata ];
			}
		} else {
			$finalData[] = $data;
		}

		$response = BWFCRM_Core()->conversation->send_whatsapp_message( $phone, $finalData );

		if ( $response['status'] == true ) {
			return $this->success_response( '', 'Test Message Sent' );
		}

		return $this->error_response( isset( $response['msg'] ) && ! empty( $response['msg'] ) ? $response['msg'] : 'Unable to send test message', null, 500 );
	}

	/**
	 * POST /upload-image
	 */
	public function upload_image() {
		$files = $this->args['files'];
		if ( empty( $files ) || ! is_array( $files['image'] ) || ! is_uploaded_file( $files['image']['tmp_name'] ) ) {
			$this->response_code = 400;

			return $this->error_response( __( 'Not any image file found for import', 'wp-marketing-automations-pro' ), null, 400 );
		}

		$url = BWFCRM_Core()->email_editor->upload_media( $files['image'] );
		if ( empty( $url ) || is_wp_error( $url ) ) {
			return $this->error_response( __( 'Unable to upload image file', 'wp-marketing-automations-pro' ), null, 500 );
		}

		return $this->success_response( $url, __( 'Headers Data', 'wp-marketing-automations-pro' ) );
	}
}

BWFCRM_API_Conversations_Controller::get_instance();
