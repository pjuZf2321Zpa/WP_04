<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Skip if the parent abstract is not loaded yet (e.g. old loader still in memory during a plugin-update file-swap); prevents a fatal that would abort the update.
if ( ! class_exists( 'BWFCRM_API_Controller' ) ) {
	return;
}

class BWFCRM_API_Campaigns_Controller extends BWFCRM_API_Controller {

	public static $ins;

	public $total_count = 0;
	public $count_data = [];
	public $recipients_timeline = [];
	public $merge_tags = [];

	private $_form_merge_tags = [ 'bwfan_contact_confirmation_link' ];

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	protected function register_routes() {

		/** GET /broadcasts */
		$this->add_route( '/broadcasts', [
			[ 'GET', 'get_campaigns', array(
				'search'   => array(
					'description' => __( 'Search from campaign name', 'wp-marketing-automations-pro' ),
					'type'        => 'string',
				),
				'offset'   => array(
					'description' => __( 'Broadcast list Offset', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
				'limit'    => array(
					'description' => __( 'Per page limit', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
				'order'    => array(
					'description' => __( 'Order of the campaign list', 'wp-marketing-automations-pro' ),
					'type'        => 'string',
				),
				'order_by' => array(
					'description' => __( 'Order campaign list according to fields', 'wp-marketing-automations-pro' ),
					'type'        => 'string',
				),
				'fields'   => array(
					'description' => __( 'Comma separated fields to get', 'wp-marketing-automations-pro' ),
					'type'        => 'string',
				),
				'type'     => array(
					'description' => __( 'Broadcast type filter', 'wp-marketing-automations-pro' ),
					'type'        => 'string',
				),
				'status'   => array(
					'description' => __( 'Broadcast status filter', 'wp-marketing-automations-pro' ),
					'type'        => 'string',
				),
				'category' => array(
					'description' => __( 'Broadcast category filter', 'wp-marketing-automations-pro' ),
					'type'        => 'string',
				),
			) ],
		] );

		/** GET /broadcasts-lookup */
		$this->add_route( '/broadcasts-lookup', [
			[ 'GET', 'get_broadcast_lookup', array(
				'search' => array(
					'description' => __( 'Search from Broadcast name', 'wp-marketing-automations-pro' ),
					'type'        => 'string',
				),
				'offset' => array(
					'description' => __( 'Broadcast Offset', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
				'limit'  => array(
					'description' => __( 'Per page limit', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
				'ids'    => array(
					'description' => __( 'Broadcast IDs', 'wp-marketing-automations-pro' ),
					'type'        => 'string',
				),
				'type'   => array(
					'description' => __( 'Broadcast type filter', 'wp-marketing-automations-pro' ),
					'type'        => 'string',
				),
			) ],
		] );

		/** GET /broadcasts-stats */
		$this->add_route( '/broadcasts-stats', [
			[ 'GET', 'get_broadcasts_stats' ],
		] );

		/** POST /broadcast */
		$this->add_route( '/broadcast', [
			[ 'POST', 'create_campaign' ],
		] );

		/** POST /broadcast/email-preview */
		$this->add_route( '/broadcast/email-preview', [
			[ 'POST', 'campaign_email_preview' ],
		] );

		/** GET /broadcast/merge-tags */
		$this->add_route( 'broadcast/merge-tags', [
			[ 'GET', 'get_merge_tags' ],
		] );

		/** GET + PUT + DELETE /broadcast/{id} */
		$this->add_route( '/broadcast/(?P<campaign_id>[\d]+)', [
			[ 'GET', 'get_campaign', array(
				'campaign_id' => array(
					'description' => __( 'Broadcast ID to retrieve', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ],
			[ 'PUT', 'update_campaign' ],
			[ 'DELETE', 'delete_campaign', array(
				'campaign_id' => array(
					'description' => __( 'Broadcast ID to retrieve', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ],
		] );

		/** POST /broadcast/{id}/clone */
		$this->add_route( '/broadcast/(?P<campaign_id>[\d]+)/clone', [
			[ 'POST', 'clone_campaign', array(
				'campaign_id' => array(
					'description' => __( 'Broadcast ID whose data to be cloned.', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
				'created_by'  => array(
					'description' => __( 'User ID who is cloning contact.', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ],
		] );

		/** GET /broadcast/{id}/stats */
		$this->add_route( '/broadcast/(?P<campaign_id>[\d]+)/stats', [
			[ 'GET', 'get_campaign_stats', array(
				'campaign_id' => array(
					'description' => __( 'Broadcast ID to retrieve', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ],
		] );

		/** GET /broadcast/{id}/overview-stats */
		$this->add_route( '/broadcast/(?P<broadcast_id>[\d]+)/overview-stats', [
			[ 'GET', 'get_broadcast_overview_stats', array(
				'broadcast_id' => array(
					'description' => __( 'Broadcast ID to retrieve', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ],
		] );

		/** POST /broadcast/{id}/pause-unpause */
		$this->add_route( '/broadcast/(?P<campaign_id>[\d]+)/pause-unpause', [
			[ 'POST', 'pause_unpause_broadcast', array(
				'campaign_id' => array(
					'description' => __( 'Broadcast ID whose state has to be changes.', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ],
		] );

		/** PUT /broadcast/{id}/save-content */
		$this->add_route( '/broadcast/(?P<broadcast_id>[\d]+)/save-content', [
			[ 'PUT', 'save_content' ],
		] );

		/** GET /broadcast/{id}/content/{content_id} */
		$this->add_route( '/broadcast/(?P<broadcast_id>[\d]+)/content/(?P<content_id>[\d]+)', [
			[ 'GET', 'get_editor_content', array(
				'broadcast_id' => array(
					'description' => __( 'Broadcast ID to retrieve', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
				'content_id'   => array(
					'description' => __( 'A/B Content index\'s data to retreive', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ],
		] );

		/** GET /broadcasts/{id}/recipients/ */
		$this->add_route( '/broadcasts/(?P<campaign_id>[\d]+)/recipients/', [
			[ 'GET', 'get_recipients', array(
				'campaign_id' => array(
					'description' => __( 'Campaign ID to retrieve', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
				'offset'      => array(
					'description' => __( 'Contacts list Offset', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
				'limit'       => array(
					'description' => __( 'Per page limit', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ],
		] );

		/** GET /broadcasts/{id}/conversions/ */
		$this->add_route( '/broadcasts/(?P<campaign_id>[\d]+)/conversions/', [
			[ 'GET', 'get_campaign_conversions', array(
				'campaign_id' => array(
					'description' => __( 'Broadcast ID to retrieve', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
				'offset'      => array(
					'description' => __( 'Contacts list Offset', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
				'limit'       => array(
					'description' => __( 'Per page limit', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ],
		] );

		/** GET /broadcasts/{id}/recipients/{conversation_id}/timeline */
		$this->add_route( '/broadcasts/(?P<campaign_id>[\d]+)/recipients/(?P<conversation_id>[\d]+)/timeline', [
			[ 'GET', 'get_recipient_timeline', array(
				'campaign_id'     => array(
					'description' => __( 'Broadcast ID to retrieve campaign', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
				'conversation_id' => array(
					'description' => __( 'Conversation ID to retrieve recipient timeline', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ],
		] );
	}

	/**
	 * GET /broadcasts
	 */
	public function get_campaigns() {
		// offset/limit are parsed from the request by handle_request; default the page
		// size when the caller did not supply one, and use pagination->* directly so the
		// response envelope reports the same offset/limit the query actually used.
		if ( empty( $this->pagination->limit ) ) {
			$this->pagination->limit = 25;
		}

		$offset   = $this->pagination->offset;
		$limit    = $this->pagination->limit;
		$search   = (string) $this->get_sanitized_arg( 'search', 'text_field' );
		$order    = ! empty( $this->get_sanitized_arg( 'order', 'key' ) ) ? $this->get_sanitized_arg( 'order', 'text_field' ) : 'DESC';
		$type     = ! empty( $this->get_sanitized_arg( 'type', 'key' ) ) ? $this->get_sanitized_arg( 'type', 'text_field' ) : '';
		$status   = ! empty( $this->get_sanitized_arg( 'status', 'key' ) ) ? $this->get_sanitized_arg( 'status', 'text_field' ) : '';
		$category = ! empty( $this->get_sanitized_arg( 'category', 'key' ) ) ? $this->get_sanitized_arg( 'category', 'text_field' ) : '';
		try {
			$campaign_data       = BWFAN_Model_Broadcast::get_campaigns( $search, $limit, $offset, $order, $type, $status, $category );
			$this->count_data    = BWFAN_PRO_Common::get_broadcast_data_count( $type );
			$this->response_code = 200;
			$this->total_count   = intval( $campaign_data['total'] );

			/** Check if worker call is late */
			$last_run       = bwf_options_get( 'fk_core_worker_let' );
			$threshold_time = method_exists( 'BWFAN_Common', 'get_worker_delay_timestamp' ) ? BWFAN_Common::get_worker_delay_timestamp() : 300;
			if ( '' !== $last_run && ( ( time() - $last_run ) > $threshold_time ) ) {
				/** Worker is running late */
				$campaign_data['data']['worker_delayed'] = time() - $last_run;
			}

			/** Check basic worker last run time and status code check */
			$resp = method_exists( 'BWFAN_Common', 'validate_core_worker' ) ? BWFAN_Common::validate_core_worker() : [];
			if ( isset( $resp['response_code'] ) ) {
				$campaign_data['data']['response_code'] = $resp['response_code'];
			}

			return $this->success_response( $campaign_data['data'], $campaign_data['message'] );
		} catch ( Error $e ) {
			$this->response_code = 404;

			return $this->error_response( $e->getMessage() );
		}
	}

	/**
	 * GET /broadcasts-lookup
	 */
	public function get_broadcast_lookup() {
		// offset/limit are parsed from the request by handle_request; default the page
		// size when the caller did not supply one, and use pagination->* directly so the
		// response envelope reports the same offset/limit the query actually used.
		if ( empty( $this->pagination->limit ) ) {
			$this->pagination->limit = 25;
		}

		$offset = $this->pagination->offset;
		$limit  = $this->pagination->limit;
		$search = (string) $this->get_sanitized_arg( 'search', 'text_field' );
		$ids    = ! empty( $this->get_sanitized_arg( 'ids', 'text_field' ) ) ? $this->get_sanitized_arg( 'ids', 'text_field' ) : '';
		$type   = ! empty( $this->get_sanitized_arg( 'type', 'key' ) ) ? $this->get_sanitized_arg( 'type', 'text_field' ) : '';

		$ids = ! empty( $ids ) ? explode( ',', $ids ) : array();

		$broadcasts = BWFCRM_Core()->campaigns->get_broadcast_lookup(
			array(
				'search' => $search,
				'offset' => $offset,
				'limit'  => $limit,
				'ids'    => $ids,
				'type'   => $type,
			)
		);

		$this->total_count = count( $broadcasts );

		return $this->success_response( $broadcasts );
	}

	/**
	 * GET /broadcasts-stats
	 */
	public function get_broadcasts_stats() {
		$broadcasts_ids      = isset( $this->args['broadcast_ids'] ) ? $this->args['broadcast_ids'] : [];
		$child_broadcast_ids = BWFAN_Model_Broadcast::get_broadcast_child( $broadcasts_ids, true );

		/** Fetch second level child */
		$child2_broadcast_ids = ! empty( $child_broadcast_ids ) ? BWFAN_Model_Broadcast::get_broadcast_child( $child_broadcast_ids, true ) : [];

		$broadcasts_ids = array_merge( $broadcasts_ids, $child_broadcast_ids, $child2_broadcast_ids );

		$final_data = [];
		$cached_key = 'bwfan_broadcast_stats';
		$force      = filter_input( INPUT_GET, 'force' );
		$exp        = BWFAN_Common::get_admin_analytics_cache_lifespan();

		try {
			if ( 'false' === $force ) {
				$stats = get_transient( $cached_key );
				if ( ! empty( $stats ) ) {
					$broadcasts_ids = array_filter( $broadcasts_ids, function ( $id ) use ( $stats ) {
						return ! array_key_exists( $id, $stats );
					} );
					if ( count( $broadcasts_ids ) > 0 ) {
						sort( $broadcasts_ids );
					}
					$final_data = $stats;
				}
			}

			if ( is_array( $broadcasts_ids ) && count( $broadcasts_ids ) > 0 ) {
				$ids         = $broadcasts_ids;
				$batch_size  = 10;
				$data        = [];
				$conversions = [];
				while ( count( $ids ) > 0 ) {
					/** Get ids in batches */
					$selected_ids = ( count( $ids ) > $batch_size ) ? array_slice( $ids, 0, $batch_size ) : $ids;

					/** update broadcast ids for next run */
					$ids = array_diff( $ids, $selected_ids );
					sort( $ids );

					$batch_data = BWFAN_Model_Broadcast::include_open_click_rate( $selected_ids, [], true );

					$data = array_merge( $data, $batch_data );
					/** Get formatted ids for conversions */
					$formatted_ids = [];
					foreach ( $selected_ids as $id ) {
						$formatted_ids[] = [ 'id' => $id ];
					}
					/** Get conversions */
					$batch_conversions = BWFAN_Model_Broadcast::include_conversion_into_campaigns( $formatted_ids, true );
					$conversions       = array_merge( $conversions, $batch_conversions );
				}

				$broadcast_ids  = empty( $data ) ? [] : array_column( $data, 'oid' );
				$conversion_ids = empty( $conversions ) ? [] : array_column( $conversions, 'oid' );

				foreach ( $broadcasts_ids as $id ) {
					$index      = array_search( $id, $broadcast_ids );
					$open_rate  = 0;
					$sent       = 0;
					$click_rate = 0;
					if ( false !== $index ) {
						$open_rate  = isset( $data[ $index ]['open_rate'] ) ? $data[ $index ]['open_rate'] : 0;
						$sent       = isset( $data[ $index ]['sent'] ) ? $data[ $index ]['sent'] : 0;
						$click_rate = isset( $data[ $index ]['click_rate'] ) ? $data[ $index ]['click_rate'] : 0;
					}

					$index            = array_search( $id, $conversion_ids );
					$conversion_count = 0;
					$revenue          = 0;
					if ( false !== $index ) {
						$conversion_count = isset( $conversions[ $index ]['conversions'] ) ? $conversions[ $index ]['conversions'] : 0;
						$revenue          = isset( $conversions[ $index ]['revenue'] ) ? $conversions[ $index ]['revenue'] : 0;
					}

					$final_data[ $id ] = [
						'open_rate'   => $open_rate,
						'sent'        => $sent,
						'click_rate'  => $click_rate,
						'conversions' => $conversion_count,
						'revenue'     => $revenue,
					];
				}

				set_transient( $cached_key, $final_data, $exp );
				BWFAN_Common::validate_scheduled_recurring_actions();
			}

			$this->response_code = 200;

			return $this->success_response( $final_data, '' );
		} catch ( Error $e ) {
			$this->response_code = 404;

			return $this->error_response( $e->getMessage() );
		}
	}

	/**
	 * POST /broadcast
	 */
	public function create_campaign() {
		$title      = ! empty( $this->get_sanitized_arg( 'title', 'text_field' ) ) ? $this->get_sanitized_arg( 'title', 'text_field' ) : '';
		$type       = ! empty( $this->get_sanitized_arg( 'type', 'key' ) ) ? $this->get_sanitized_arg( 'type', 'key' ) : 0;

		/** Create send to unopen broadcast */
		$createUnopen = $this->get_sanitized_arg( 'createUnopen', 'key' );
		if ( 1 !== absint( $type ) ) {
			$createUnopen = false;
		}

		if ( empty( $title ) ) {
			$this->response_code = 400;

			return $this->error_response( __( 'Title is a mandatory field', 'wp-marketing-automations-pro' ) );
		}

		if ( intval( $type ) <= 0 || ! in_array( intval( $type ), array( 1, 2, 3 ), true ) ) {
			$this->response_code = 400;

			return $this->error_response( __( 'Please select a type', 'wp-marketing-automations-pro' ) );
		}

		$created_by = get_current_user_id();

		if ( 0 === $created_by ) {
			$this->response_code = 404;

			return $this->error_response( __( 'User is not logged in.', 'wp-marketing-automations-pro' ) );
		}

		$description = ! empty( $this->get_sanitized_arg( 'description', 'text_field' ) ) ? $this->get_sanitized_arg( 'description', 'text_field' ) : '';

		$campaign_data = BWFAN_Model_Broadcast::create_campaign( $title, $description, $type, $created_by, $createUnopen );

		$this->response_code = $campaign_data['status'];

		if ( $campaign_data['status'] === 200 ) {
			return $this->success_response( $campaign_data['data'], __( 'Broadcast created', 'wp-marketing-automations-pro' ) );
		} else {
			return $this->error_response( __( 'Error occurred in creating a broadcast', 'wp-marketing-automations-pro' ), null, 500 );
		}
	}

	/**
	 * POST /broadcast/email-preview
	 */
	public function campaign_email_preview() {
		$content = '';
		$type    = ! empty( $this->args['type'] ) ? $this->args['type'] : 'rich';
		if ( ! empty( $this->args['content'] ) ) {
			$content = $this->args['content'];
		}
		if ( method_exists( 'BWFAN_Common', 'bwfan_before_send_mail' ) ) {
			BWFAN_Common::bwfan_before_send_mail( $type );
		}
		/** Email Subject */
		BWFAN_Merge_Tag_Loader::set_data( [ 'is_preview' => true ] );
		$body = method_exists( 'BWFAN_Common', 'correct_shortcode_string' ) ? BWFAN_Common::correct_shortcode_string( $content, $type ) : $content;
		$body = BWFAN_Common::decode_merge_tags( $body );
		$body = BWFAN_Common::bwfan_correct_protocol_url( $body );

		$body = BWFCRM_Core()->conversation->apply_template_by_type( $body, $type, '' );

		$this->response_code = 200;

		return $this->success_response( [ 'body' => $body ] );
	}

	/**
	 * GET broadcast/merge-tags
	 */
	public function get_merge_tags() {
		$this->response_code = 200;
		$context         = $this->get_sanitized_arg( 'context', 'text_field' );
		$fetch_for_forms = 'forms' === $context;

		$custom_context = [];
		if ( 'forms' !== $context ) {
			$custom_context = explode( ',', $context );
		}
		$custom_context[] = 'bwfan_default';

		try {
			if ( BWFAN_PRO_Common::is_lite_3_0() ) {
				$merge_tags = BWFAN_Core()->merge_tags->get_localize_tags_with_group( $fetch_for_forms, $custom_context );
				$merge_tags = $this->get_all_data_for_merge_tags( $merge_tags, $fetch_for_forms );
			} else {
				$merge_tags = BWFCRM_Core()->merge_tags->get_registered_grouped_tags( true, $fetch_for_forms );
			}
		} catch ( Error $e ) {
			$this->response_code = 404;
			$response            = $e->getMessage();

			return $this->error_response( $response );
		}

		if ( empty( $merge_tags ) ) {
			$this->response_code = 404;
			$response            = __( "No merge tags found", "wp-marketing-automations-pro" );

			return $this->error_response( $response );
		}
		$this->merge_tags = $merge_tags;

		return $this->success_response( $merge_tags, __( 'Got All Merge Tags', 'wp-marketing-automations-pro' ) );
	}

	public function get_all_data_for_merge_tags( $merge_tags, $fetch_for_forms ) {
		$merge_tags_data = [];

		$broadcast_merge_tag_groups = array_keys( $merge_tags );
		$form_merge_tags            = $this->_form_merge_tags;

		foreach ( $broadcast_merge_tag_groups as $merge_tag_group ) {
			if ( ! isset( $merge_tags[ $merge_tag_group ] ) ) {
				continue;
			}

			$custom_tag_data = [];
			/** creating custom contact field merge tag if present - ONLY for Contact group */
			if ( isset( $merge_tags[ $merge_tag_group ]['bwfan_contact_field'] ) && $merge_tag_group === 'Contact' ) {
				$field_merge_tags = $merge_tags[ $merge_tag_group ]['bwfan_contact_field'];
				$custom_tag_data  = $this->get_contact_fields_tags( $field_merge_tags->get_priority() );
				unset( $merge_tags[ $merge_tag_group ]['bwfan_contact_field'] );
			}

			$tag_data = array_map( function ( $tags ) use ( $fetch_for_forms, $form_merge_tags ) {
				if ( false === $fetch_for_forms && in_array( $tags->get_name(), $form_merge_tags ) ) {
					return false;
				}

				$data = [
					'tag_name'        => $tags->get_name(),
					'tag_description' => $tags->get_description(),
					'priority'        => $tags->get_priority(),
				];

				/** Return the data for the contact_subscribe_link merge tag when it is called from the form, as the merge tag schema and default values are not needed in the form context. */
				if ( true === $fetch_for_forms && 'contact_subscribe_link' === $tags->get_name() ) {
					$data['tag_description'] = __( 'Confirmation Link', 'wp-marketing-automations-pro' );

					return $data;
				}

				if ( method_exists( $tags, 'get_setting_schema' ) ) {
					$data['schema'] = $tags->get_setting_schema();
				}
				if ( method_exists( $tags, 'get_default_values' ) ) {
					$data['default_val'] = $tags->get_default_values();
				}

				return $data;
			}, $merge_tags[ $merge_tag_group ] );

			if ( ! empty( $custom_tag_data ) ) {
				$tag_data = array_merge( $tag_data, $custom_tag_data );
			}

			$tag_data = array_filter( $tag_data );
			uasort( $tag_data, function ( $a, $b ) {
				return $a['priority'] <= $b['priority'] ? - 1 : 1;
			} );

			if ( ! empty( $merge_tags[ $merge_tag_group ] ) ) {
				$merge_tags_data[ $merge_tag_group ] = array_merge( $merge_tags[ $merge_tag_group ], $tag_data );
			} else {
				$merge_tags_data[ $merge_tag_group ] = $tag_data;
			}
		}

		foreach ( $merge_tags_data as $group => $merge_tag_det ) {
			foreach ( $merge_tag_det as $key => $v ) {
				if ( false === $fetch_for_forms && in_array( $key, $this->_form_merge_tags ) ) {
					unset( $merge_tags_data[ $group ][ $key ] );
				}
			}
		}

		return $merge_tags_data;
	}

	/**
	 * Fetching all the contact custom fields for creating merge tag
	 *
	 * @param $priority
	 *
	 * @return array
	 */
	public function get_contact_fields_tags( $priority ) {
		$fields = BWFCRM_Fields::get_custom_fields( 1, 1, null );

		$return = [];
		foreach ( $fields as $field ) {
			if ( ! is_array( $field ) || ! isset( $field['slug'] ) ) {
				continue;
			}

			$field_group = 'contact_field key="' . $field['slug'] . '"';

			$return[ $field_group ]['tag_name']        = $field_group;
			$return[ $field_group ]['tag_description'] = $field['name'];
			$return[ $field_group ]['priority']        = $priority;
		}

		return $return;
	}

	/**
	 * GET /broadcast/{id}
	 */
	public function get_campaign() {
		$campaign_id = $this->get_sanitized_arg( 'campaign_id', 'key' );
		$ab_mode     = $this->get_sanitized_arg( 'ab_mode', 'bool' );
		$ping_worker = $this->get_sanitized_arg( 'ping_worker', 'bool' );
		if ( true === $ping_worker ) {
			BWFCRM_Common::ping_woofunnels_worker();
		}

		if ( 0 === intval( $campaign_id ) ) {
			$this->response_code = 404;

			return $this->error_response( __( 'Invalid broadcast ID given', 'wp-marketing-automations-pro' ) );
		}

		$campaign_data = BWFAN_Model_Broadcast::get_campaign( $campaign_id, ! $ab_mode, $ab_mode );

		/** Check for template stats */
		if ( ! empty( $campaign_data['data']['data']['smart_send_stat'] ) ) {
			$campaign_data['data']['data']['smart_send_stat'] = BWFAN_Model_Broadcast::get_formatted_smart_stat( $campaign_data['data']['data']['smart_send_stat'], true );
		}
		$this->response_code = $campaign_data['status'];

		if ( ! $ab_mode ) {
			$campaign_data['data']['count'] = BWFCRM_Campaigns::get_broadcast_updated_contact_count( $campaign_data['data'] );
		}


		if ( 200 === intval( $campaign_data['status'] ) ) {
			return $this->success_response( $campaign_data['data'], $campaign_data['message'] );
		}

		return $this->error_response( $campaign_data['message'] );
	}

	/**
	 * PUT /broadcast/{id}
	 */
	public function update_campaign() {
		$campaign_id = $this->get_sanitized_arg( 'campaign_id', 'key' );
		$step        = $this->get_sanitized_arg( 'step', 'key' );

		/** Check fo data */
		$data = isset( $this->args['content'] ) ? $this->args['content'] : [];
		$data = BWFAN_Common::is_json( $data ) ? json_decode( $data, true ) : $data;

		/** For old version */
		if ( empty( $data ) && isset( $this->args['data'] ) && ! empty( $this->args['data'] ) ) {
			$data = BWFAN_Common::is_json( $this->args['data'] ) ? json_decode( $this->args['data'], true ) : $this->args['data'];
		}

		if ( empty( $campaign_id ) || ! $step || intval( $step ) < 1 ) {
			$this->response_code = 404;

			return $this->error_response( __( 'Unable to save broadcast, ID is missing', 'wp-marketing-automations-pro' ) );
		}

		if ( empty( $data ) ) {
			$this->response_code = 404;

			return $this->error_response( __( 'Unable to save broadcast, data is missing', 'wp-marketing-automations-pro' ) );
		}

		$campaign = BWFAN_Model_Broadcast::update_campaign( $campaign_id, $step, $data );
		/** validating the content */
		if ( isset( $data['content'] ) && is_array( $data['content'] ) ) {
			foreach ( $data['content'] as $key => $content ) {
				try {
					BWFCRM_Core()->conversation->emogrify_email( $content['body'] );
					$campaign['data'][ 'validated_email_body_' . $key ] = true;
				} catch ( Error $e ) {
					$campaign['data'][ 'validated_email_body_' . $key ] = false;
				}
			}
		}

		$this->response_code = $campaign['status'];

		if ( 200 === $campaign['status'] ) {
			return $this->success_response( $campaign['data'], $campaign['message'] );
		}

		return $this->error_response( $campaign['message'] );
	}

	/**
	 * DELETE /broadcast/{id}
	 */
	public function delete_campaign() {
		$campaign_id = $this->get_sanitized_arg( 'campaign_id', 'key' );
		if ( intval( $campaign_id ) > 0 ) {
			$campaign_data       = BWFAN_Model_Broadcast::delete_campaign( $campaign_id );
			$this->response_code = $campaign_data['status'];
			if ( $campaign_data['status'] === 200 ) {
				return $this->success_response( $campaign_data['data'], $campaign_data['message'] );
			} else {
				return $this->error_response( $campaign_data['message'] );
			}
		} else {
			$this->response_code = 404;

			return $this->error_response( __( 'Unable to delete a broadcast, invalid ID', 'wp-marketing-automations-pro' ) );

		}
	}

	/**
	 * POST /broadcast/{id}/clone
	 */
	public function clone_campaign() {
		$campaign_id    = $this->get_sanitized_arg( 'campaign_id', 'key' );
		$send_to_unopen = $this->get_sanitized_arg( 'send_to_unopen', 'bool' );
		$created_by     = $this->get_sanitized_arg( 'created_by', 'key' );
		$created_by     = ! empty( $created_by ) ? $created_by : '';
		$user_exists    = (bool) get_users( array(
			'include' => $created_by,
			'fields'  => 'ID',
		) );

		if ( ! $user_exists ) {
			$this->response_code = 404;

			return $this->error_response( __( 'User does not exists with provided ID', 'wp-marketing-automations-pro' ) );
		}

		if ( intval( $campaign_id ) > 0 ) {
			$campaign_data       = BWFAN_Model_Broadcast::clone_campaign( $campaign_id, $created_by, $send_to_unopen );
			$this->response_code = $campaign_data['status'];
			if ( $campaign_data['status'] === 200 ) {
				return $this->success_response( $campaign_data['data'], $campaign_data['message'] );
			} else {
				return $this->error_response( $campaign_data['message'] );
			}
		} else {
			$this->response_code = 404;

			return $this->error_response( __( 'Please provide a valid broadcast id.', 'wp-marketing-automations-pro' ) );
		}
	}

	/**
	 * GET /broadcast/{id}/stats
	 */
	public function get_campaign_stats() {
		$campaign_id = $this->get_sanitized_arg( 'campaign_id', 'key' );

		if ( absint( $campaign_id ) > 0 ) {
			$campaign_data       = BWFCRM_Core()->campaigns->get_campaign_open_click_analytics($campaign_id);
			return $this->success_response( $campaign_data );
		} else {
			return $this->error_response( __( 'Invalid broadcast ID given', 'wp-marketing-automations-pro' ), null, 400 );

		}
	}

	/**
	 * GET /broadcast/{id}/overview-stats
	 */
	public function get_broadcast_overview_stats() {
		$broadcast_id = $this->get_sanitized_arg( 'broadcast_id', 'key' );
		if ( empty( $broadcast_id ) ) {
			return $this->error_response( __( 'Broadcast not found', 'wp-marketing-automations-pro' ), null, 404 );
		}

		$broadcast     = BWFAN_Model_Broadcast::get_broadcast_basic_stats( $broadcast_id );

		return $this->success_response( $broadcast );
	}

	/**
	 * POST /broadcast/{id}/pause-unpause
	 */
	public function pause_unpause_broadcast() {
		$campaign_id   = $this->get_sanitized_arg( 'campaign_id', 'key' );
		$status        = 0;
		$campaign_data = false;
		if ( ! empty( $this->args['status'] ) ) {
			$status = intval( $this->args['status'] );
		}

		$this->response_code = 404;
		if ( intval( $campaign_id ) > 0 ) {
			switch ( $status ) {
				case 1:
					/** Engagements are cleared by the background action scheduled in update_status_to_draft() */
					$campaign_data = BWFAN_Model_Broadcast::update_status_to_draft( $campaign_id );
					break;
				case 3:
					$campaign_data = BWFAN_Model_Broadcast::update_status_to_ongoing( $campaign_id );
					break;
				case 6:
					$campaign_data = BWFAN_Model_Broadcast::update_status_to_pause( $campaign_id );
					BWFCRM_Broadcast_Processing::action_schedule_save_last_sent( $campaign_id, false );
					break;
				case 7:
					$campaign_data = BWFAN_Model_Broadcast::update_status_to_cancel( $campaign_id );
					break;
				default:
					return $this->error_response( __( 'Invalid status provided', 'wp-marketing-automations-pro' ) );
			}

			if ( $campaign_data ) {
				$this->response_code = 200;

				return $this->success_response( '', __( 'Successfully updated broadcast status', 'wp-marketing-automations-pro' ) );
			}

			return $this->error_response( __( 'Unable to set broadcast status.', 'wp-marketing-automations-pro' ) );
		}

		return $this->error_response( __( 'Invalid broadcast ID provided', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * PUT /broadcast/{id}/save-content
	 */
	public function save_content() {
		$broadcast_id = $this->get_sanitized_arg( 'broadcast_id', 'key' );
		if ( empty( $broadcast_id ) ) {
			return $this->error_response( __( 'Unable to save broadcast, Broadcast ID missing', 'wp-marketing-automations-pro' ), null, 400 );
		}

		/** Filter data */
		$data = isset( $this->args['content'] ) ? $this->args['content'] : [];
		$data = BWFAN_Common::is_json( $data ) ? json_decode( $data, true ) : $data;

		$result = BWFCRM_Core()->campaigns->save_broadcast_content( $broadcast_id, $data );
		if ( is_wp_error( $result ) ) {
			return $this->error_response( '', $result, $result->get_error_code() );
		}

		return $this->success_response( [], 'Broadcast Content Saved!' );
	}

	/**
	 * GET /broadcast/{id}/content/{content_id}
	 */
	public function get_editor_content() {
		$broadcast_id = $this->get_sanitized_arg( 'broadcast_id', 'key' );
		$content_id   = $this->get_sanitized_arg( 'content_id', 'key' );
		if ( empty( $broadcast_id ) || ( empty( $content_id ) && 0 !== absint( $content_id ) ) ) {
			return $this->error_response( __( 'Invalid Broadcast ID / Content Index given', 'wp-marketing-automations-pro' ) );
		}

		$content = BWFCRM_Core()->campaigns->get_editor_content( $broadcast_id, $content_id );
		if ( ! is_array( $content ) || empty( $content ) ) {
			$content = [];
		}

		return $this->success_response( $content );
	}

	/**
	 * GET /broadcasts/{id}/recipients/
	 */
	public function get_recipients() {
		// Honor the offset/limit parsed from the request by handle_request; default
		// the page size only when the caller did not supply one.
		if ( empty( $this->pagination->limit ) ) {
			$this->pagination->limit = 10;
		}

		$campaign_id = $this->get_sanitized_arg( 'campaign_id', 'text_field' );
		$recipients  = BWFAN_Model_Engagement_Tracking::get_recipents_by_type( $campaign_id, BWFAN_Email_Conversations::$TYPE_CAMPAIGN, $this->pagination->offset, $this->pagination->limit );
		if ( empty( $recipients['conversations'] ) ) {
			$this->response_code = 404;
			$response            = __( "No recipients found", "autonami-automations-pro" );

			return $this->success_response( [], $response );
		}
		$this->total_count = $recipients['total'];

		return $this->success_response( $recipients['conversations'], __( 'Got All Recipients', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * GET /broadcasts/{id}/conversions/
	 */
	public function get_campaign_conversions() {
		// Honor the offset/limit parsed from the request by handle_request; default
		// the page size only when the caller did not supply one.
		if ( empty( $this->pagination->limit ) ) {
			$this->pagination->limit = 10;
		}

		$campaign_id = $this->get_sanitized_arg( 'campaign_id', 'text_field' );
		$recipients  = BWFCRM_Core()->campaigns->get_conversions( $campaign_id, $this->pagination->offset, $this->pagination->limit );
		if ( empty( $recipients['conversions'] ) ) {
			$this->response_code = 404;
			$response            = __( "No orders found", "autonami-automations-pro" );

			return $this->success_response([], $response );
		}
		$this->total_count = $recipients['total'];

		return $this->success_response( $recipients['conversions'], __( 'Got All Orders', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * GET /broadcasts/{id}/recipients/{conversation_id}/timeline
	 */
	public function get_recipient_timeline() {
		$campaign_id         = $this->get_sanitized_arg( 'campaign_id', 'text_field' );
		$conversation_id     = $this->get_sanitized_arg( 'conversation_id', 'text_field' );
		$recipients_timeline = BWFAN_Model_Engagement_Tracking::get_engagement_recipient_timeline( $conversation_id );
		if ( empty( $recipients_timeline ) ) {
			return $this->success_response( [], __( 'No engagement found', 'wp-marketing-automations-pro' ) );
		}
		$this->recipients_timeline = $recipients_timeline;

		return $this->success_response( $recipients_timeline, __( 'Got All timeline', 'wp-marketing-automations-pro' ) );
	}

	public function get_result_total_count() {
		if ( ! empty( $this->recipients_timeline ) ) {
			return count( $this->recipients_timeline );
		}

		return $this->total_count;
	}

	public function get_result_count_data() {
		return $this->count_data;
	}
}

BWFCRM_API_Campaigns_Controller::get_instance();
