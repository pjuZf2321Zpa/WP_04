<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Skip if the parent abstract is not loaded yet (e.g. old loader still in memory during a plugin-update file-swap); prevents a fatal that would abort the update.
if ( ! class_exists( 'BWFCRM_API_Controller' ) ) {
	return;
}

class BWFCRM_API_Categories_Controller extends BWFCRM_API_Controller {

	public static $ins;

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	protected function register_routes() {
		$this->add_route( '/category/(?P<type>[\d]+)', [
			[ 'GET', 'get_category' ],
			[ 'POST', 'create_category' ],
			[ 'DELETE', 'delete_category' ],
		] );

		$this->add_route( '/category/assign/(?P<type>\d+)', [
			[ 'POST', 'assign_category' ],
		] );

		$this->add_route( '/category/(?P<category_id>[\d]+)/rename', [
			[ 'PUT', 'update_category' ],
		] );
	}

	public function default_args_values() {
		return array(
			'type'         => '',
			'name'         => '',
			'category_id'  => '',
			'category_ids' => [],
			'items_ids'    => [],
			'categories'   => [],
			'limit'        => 10,
			'offset'       => 0,
		);
	}

	/**
	 * GET /category/(?P<type>[\d]+)
	 */
	public function get_category() {
		$type   = $this->get_sanitized_arg( 'type', 'text_field' );
		$search = $this->get_sanitized_arg( 'search', 'text_field' );
		$limit  = $this->get_sanitized_arg( 'limit', 'text_field' ) ?: 10;
		$offset = $this->get_sanitized_arg( 'offset', 'text_field' ) ?: 0;

		if ( empty( $type ) ) {
			return $this->error_response( __( 'Type is required.', 'wp-marketing-automations-pro' ), null, 404 );
		}

		if ( ! BWFCRM_Category::is_valid_type( $type ) ) {
			return $this->error_response( __( 'Invalid type', 'wp-marketing-automations-pro' ), null, 404 );
		}

		$categories = BWFAN_Model_Terms::get_terms( $type, $offset, $limit, $search );

		$processed_categories = array_map( function ( $category ) {
			$data = ! empty( $category['data'] ) ? json_decode( $category['data'], true ) : [];

			return [
				'id'    => $category['ID'],
				'name'  => $category['name'],
				'count' => isset( $data['count'] ) ? (int) $data['count'] : 0
			];
		}, $categories );


		return $this->success_response( [
			'categories' => $processed_categories,
		], __( 'Categories fetched successfully.', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * POST /category/(?P<type>[\d]+)
	 */
	public function create_category() {
		$category_name = isset( $this->args['name'] ) ? $this->args['name'] : '';
		$type          = $this->get_sanitized_arg( 'type', 'key' );

		if ( empty( $category_name ) || empty( $type ) ) {
			return $this->error_response( __( 'Category name and type are required', 'wp-marketing-automations-pro' ), null, 404 );
		}

		if ( false === BWFCRM_Category::is_valid_type( $type ) ) {
			return $this->error_response( __( 'Invalid type', 'wp-marketing-automations-pro' ), null, 404 );
		}

		/** check if category is already exists  */
		$already_exists = BWFCRM_Category::get_categories( $type, [], $category_name, 'exact' );

		if ( ! empty( $already_exists ) ) {
			return $this->error_response( __( "Category already exists with name: " . $category_name, 'wp-marketing-automations-pro' ), null, 404 );
		}

		$result = BWFCRM_Category::save_category( $category_name, (int) $type );
		if ( false === $result ) {
			return $this->error_response( __( 'Unable to create new category', 'wp-marketing-automations-pro' ), null, 400 );
		}

		return $this->success_response( [], __( 'Category Created', 'wp-marketing-automations-pro' ) );

	}

	/**
	 * DELETE /category/(?P<type>[\d]+)
	 */
	public function delete_category() {
		$type       = (int) $this->get_sanitized_arg( 'type', 'key' );
		$categories = ! empty( $this->args['category_ids'] ) ? $this->args['category_ids'] : [];

		if ( false === BWFCRM_Category::is_valid_type( $type ) ) {
			return $this->error_response( __( 'Invalid type', 'wp-marketing-automations-pro' ), null, 404 );
		}

		if ( empty( $categories ) ) {
			return $this->error_response( __( 'Category and type are required', 'wp-marketing-automations-pro' ), null, 404 );
		}

		$del_category = BWFCRM_Category::delete_terms_with_reference( $type, $categories );
		if ( false === $del_category ) {
			return $this->error_response( __( "Failed to delete the category", 'wp-marketing-automations-pro' ), null, 400 );
		}

		return $this->success_response( [], __( 'Category deleted successfully.', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * POST /category/assign/(?P<type>\d+)
	 */
	public function assign_category() {
		$type       = (int) $this->get_sanitized_arg( 'type', 'key' );
		$items_ids  = ! empty( $this->args['items_ids'] ) ? $this->args['items_ids'] : [];
		$categories = $this->args['categories'];

		if ( empty( $items_ids ) ) {
			return $this->error_response( __( 'Items ID required', 'wp-marketing-automations-pro' ), null, 404 );
		}

		if ( ! BWFCRM_Category::is_valid_type( $type ) ) {
			return $this->error_response( __( "Invalid Type", 'wp-marketing-automations-pro' ), null, 404 );
		}

		// Allow empty categories array to unassign all categories
		$all_categories = [];
		if ( ! empty( $categories ) ) {
			$all_categories = BWFCRM_Category::add_categories( $categories, $type );
			if ( false === $all_categories ) {
				return $this->error_response( __( 'Unable to create category', 'wp-marketing-automations-pro' ), null, 400 );
			}
		}

		$result = BWFCRM_Category::assign_categories( $items_ids, $all_categories, $type );
		if ( ! $result ) {
			return $this->error_response( __( 'Failed to assign categories', 'wp-marketing-automations-pro' ), null, 400 );
		}

		return $this->success_response( [], __( "Category successfully assigned", 'wp-marketing-automations-pro' ) );
	}

	/**
	 * PUT /category/(?P<category_id>[\d]+)/rename
	 */
	public function update_category() {
		$category_id   = $this->get_sanitized_arg( 'category_id', 'key' );
		$category_name = isset( $this->args['name'] ) ? $this->args['name'] : '';

		if ( empty( $category_id ) || empty( $category_name ) ) {
			return $this->error_response( __( 'Category ID and Name is required', 'wp-marketing-automations-pro' ), null, 404 );
		}

		$category = new BWFCRM_Category( $category_id );

		if ( ! $category->is_exists() ) {
			return $this->error_response( __( "Category doesn't exists", 'wp-marketing-automations-pro' ), null, 404 );
		}

		$already_exists = BWFCRM_Category::get_categories( $category->get_type(), [], $category_name, 'exact' );

		if ( ! empty( $already_exists ) && $already_exists[0]['ID'] !== $category->get_id() ) {
			return $this->error_response( __( 'Category already exists with name', 'wp-marketing-automations-pro' ), null, 404 );
		}

		$category->set_name( $category_name );

		if ( empty( $category->save() ) ) {
			return $this->error_response( __( 'Unable to Rename the Category', 'wp-marketing-automations-pro' ), null, 400 );
		}

		return $this->success_response( [], __( 'Category Rename Successful', 'wp-marketing-automations-pro' ) );

	}
}

BWFCRM_API_Categories_Controller::get_instance();
