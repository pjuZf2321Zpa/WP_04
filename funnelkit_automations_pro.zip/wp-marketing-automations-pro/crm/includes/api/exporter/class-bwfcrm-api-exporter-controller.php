<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Skip if the parent abstract is not loaded yet (e.g. old loader still in memory during a plugin-update file-swap); prevents a fatal that would abort the update.
if ( ! class_exists( 'BWFCRM_API_Controller' ) ) {
	return;
}

class BWFCRM_API_Exporter_Controller extends BWFCRM_API_Controller {

	public static $ins;
	public $total_count = 0;
	private $export_id = null;

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	public function __construct() {
		$this->pagination         = new stdClass();
		$this->pagination->offset = 0;
		$this->pagination->limit  = 25;
		parent::__construct();
	}

	public function default_args_values() {
		return array(
			'title'     => '',
			'fields'    => [],
			'filters'   => [],
			'count'     => 0,
			'export_id' => '',
			'offset'    => 0,
			'limit'     => 0,
		);
	}

	protected function register_routes() {
		// POST /contact/export/add
		$this->add_route( '/contact/export/add', array(
			array( 'POST', 'add_export' ),
		) );

		// DELETE /contact/export/cancel/{id}
		$this->add_route( '/contact/export/cancel/(?P<export_id>[\d]+)', array(
			array( 'DELETE', 'cancel_export' ),
		) );

		// DELETE /contact/export/delete/{id}
		$this->add_route( '/contact/export/delete/(?P<export_id>[\d]+)', array(
			array( 'DELETE', 'delete_export' ),
		) );

		// GET /contact/export/download/{id} — uses nonce-based auth (no cookie)
		$this->add_route( '/contact/export/download/(?P<export_id>[\d]+)', array(
			array( 'GET', 'download_export_file' ),
		), 'download_permission_callback' );

		// GET /contact/export/{id}
		$this->add_route( '/contact/export/(?P<export_id>[\d]+)', array(
			array( 'GET', 'get_export_data', array(
				'export_id' => array(
					'description' => __( 'Export ID to retrieve', 'wp-marketing-automations-pro' ),
					'type'        => 'integer',
				),
			) ),
		) );

		// GET /contact/export
		$this->add_route( '/contact/export', array(
			array( 'GET', 'get_export_list' ),
		) );

	}

	/**
	 * POST /contact/export/add
	 */
	public function add_export() {
		$title   = isset( $this->args['title'] ) ? $this->get_sanitized_arg( 'title', 'text_field', $this->args['title'] ) : '';
		$fields  = isset( $this->args['fields'] ) ? $this->args['fields'] : [];
		$filters = isset( $this->args['filters'] ) ? $this->args['filters'] : [];
		$count   = isset( $this->args['count'] ) ? intval( $this->args['count'] ) : 0;

		if ( empty( $fields ) ) {
			$this->response_code = 404;

			return $this->error_response( __( 'Export fields are missing', 'wp-marketing-automations-pro' ) );
		}

		$response = BWFCRM_Core()->exporter->bwfcrm_add_export_action( $title, $fields, $filters, $count );
		if ( ! $response['status'] ) {
			$this->response_code = 404;

			return $this->error_response( __( 'Error in exporting contacts.', 'wp-marketing-automations-pro' ) );
		}
		if ( 404 === $response['status'] ) {
			$this->response_code = 404;

			return $this->error_response( __( 'Unable to create a file, permission issues, contact host.', 'wp-marketing-automations-pro' ) );
		}

		return $this->success_response( $response, __( 'Export Added to Queue', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * DELETE /contact/export/cancel/{id}
	 */
	public function cancel_export() {

		$export_id = $this->get_sanitized_arg( 'export_id', 'text_field' );

		$cancel_export = BWFCRM_Core()->exporter->cancel_export_entry( $export_id );

		if ( ! $cancel_export ) {

			$this->response_code = 400;

			return $this->error_response( __( 'Unable to cancel export with id', 'wp-marketing-automations-pro' ). ' #' . $export_id );
		}

		return $this->success_response( [], __( 'Export Cancelled Successfully', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * DELETE /contact/export/delete/{id}
	 */
	public function delete_export() {

		$export_id = $this->get_sanitized_arg( 'export_id', 'text_field' );

		$delete_export = BWFCRM_Core()->exporter->delete_export_entry( $export_id );

		if ( ! $delete_export ) {

			$this->response_code = 400;

			return $this->error_response( __( 'Unable to delete export with id', 'wp-marketing-automations-pro' ) .' #'. $export_id );
		}

		return $this->success_response( [], __( 'Deleted Successfully', 'wp-marketing-automations-pro' ) );
	}

	/**
	 * GET /contact/export/download/{id}
	 */
	public function download_export_file() {
		$export_id = absint( $this->get_sanitized_arg( 'export_id' ) );
		if ( empty( $export_id ) ) {
			$this->response_code = 404;
			return $this->error_response( __( 'Invalid Export ID', 'wp-marketing-automations-pro' ) );
		}

		$export = BWFAN_Model_Import_Export::get( $export_id );
		if ( empty( $export['meta'] ) ) {
			$this->response_code = 404;
			return $this->error_response( __( 'Export file is not ready yet', 'wp-marketing-automations-pro' ) );
		}

		$export_meta = json_decode( $export['meta'], true );
		if ( ! is_array( $export_meta ) || ! isset( $export_meta['file'] ) ) {
			$this->response_code = 404;
			return $this->error_response( __( 'Export file url is missing', 'wp-marketing-automations-pro' ) );
		}

		/** basename() strips any path segments from the DB-stored value so a tampered
		 * meta entry cannot traverse outside the export directories. */
		$export_file = basename( $export_meta['file'] );
		$filename    = BWFCRM_EXPORT_DIR . '/' . $export_file;
		if ( ! file_exists( $filename ) ) {
			$filename = BWFCRM_EXPORT_DIR_BACKUP . '/' . $export_file;
		}
		if ( file_exists( $filename ) ) {
			$this->serve_file_download( $filename );
		}
		wp_die();
	}

	/**
	 * GET /contact/export/{id}
	 */
	public function get_export_data() {
		$this->export_id = $this->get_sanitized_arg( 'export_id', 'text_field' );
		if ( empty( $this->export_id ) ) {
			$this->response_code = 400;

			return $this->error_response( __( 'Unable to get export data with id', 'wp-marketing-automations-pro' ) . ' #' . $this->export_id );
		}

		$export_ins = new BWFCRM_Exporter();
		$export_ins->maybe_get_export( $this->export_id );
		$export = $this->get_export_data_row( $export_ins->db_export_row );

		/** Check if export is already running */
		if ( ! empty( $export_ins->is_running ) ) {
			return $this->success_response( $export, __( 'Export is already running.', 'wp-marketing-automations-pro' ) );
		}

		/** If export is completed */
		if ( BWFCRM_Exporter::$EXPORT_SUCCESS === intval( $export['status'] ) ) {
			return $this->success_response( $export, __( 'Export finished.', 'wp-marketing-automations-pro' ) );
		}

		/** Unscheduled the action if it is scheduled */
		if ( bwf_has_action_scheduled( BWFCRM_Exporter::$ACTION_HOOK, array( 'export_id' => $this->export_id ), 'bwfcrm' ) ) {
			bwf_unschedule_actions( BWFCRM_Exporter::$ACTION_HOOK, array( 'export_id' => $this->export_id ), 'bwfcrm' );
		}

		/** Schedule next occurrence */
		bwf_schedule_single_action( time() + 60, BWFCRM_Exporter::$ACTION_HOOK, array( 'export_id' => $this->export_id ), 'bwfcrm' );

		/** Run the export action directly */
		$export_ins->bwfcrm_export( $this->export_id );

		/** Fetch updated export data */
		$export = $this->get_export_data_row( [] );
		if ( empty( $export ) ) {
			$this->response_code = 400;

			return $this->error_response( __( 'Unable to get export data', 'wp-marketing-automations-pro' ) . ' #' . $this->export_id );
		}

		if ( BWFCRM_Exporter::$EXPORT_SUCCESS === intval( $export['status'] ) ) {
			bwf_unschedule_actions( BWFCRM_Exporter::$ACTION_HOOK, array( 'export_id' => $this->export_id ), 'bwfcrm' );
		}

		return $this->success_response( $export, __( 'Successfully fetched export data with id ', 'wp-marketing-automations-pro' ) . '#' . $this->export_id );
	}

	public function get_export_data_row( $export ) {
		$export = empty( $export ) ? BWFAN_Model_Import_Export::get( $this->export_id ) : $export;
		if ( empty( $export ) ) {
			return false;
		}

		$temp = ! empty( $export['meta'] ) ? json_decode( $export['meta'], true ) : [];
		unset( $export['meta'] );
		if ( isset( $temp['file'] ) ) {
			$temp['filename'] = $temp['file'];
			if ( file_exists( BWFCRM_EXPORT_DIR . '/' . $temp['file'] ) ) {
				$temp['file'] = BWFCRM_EXPORT_URL . $temp['file'];
			} else if( file_exists( BWFCRM_EXPORT_DIR_BACKUP . '/' . $temp['file'] ) ) {
				$temp['file'] = BWFCRM_EXPORT_URL_BACKUP . $temp['file'];
			} else {
				$temp['file'] = false;
			}
		} else {
			$temp['file'] = false;
		}

		return array_merge( $export, $temp );
	}

	/**
	 * GET /contact/export
	 */
	public function get_export_list() {
		$limit  = ! empty( $this->get_sanitized_arg( 'limit', 'text_field' ) ) ? $this->get_sanitized_arg( 'limit', 'text_field' ) : 0;
		$offset = ! empty( $this->get_sanitized_arg( 'offset', 'text_field' ) ) ? $this->get_sanitized_arg( 'offset', 'text_field' ) : 0;
		$data   = BWFAN_Model_Import_Export::get_export_import( 2, $limit, $offset );

		$exports           = isset( $data['exports'] ) && is_array( $data['exports'] ) ? $data['exports'] : [];
		$this->total_count = isset( $data['total_count'] ) && ! empty( $data['total_count'] ) ? $data['total_count'] : 0;
		$exports           = array_map( function ( $export ) {
			$meta = ! empty( $export['meta'] ) ? json_decode( $export['meta'], true ) : [];
			unset( $export['meta'] );

			if ( ! empty( $meta['filters'] ) && ! BWFCRM_Filters::is_new_filter( $meta['filters'] ) && method_exists( 'BWFCRM_Model_Contact', 'get_contacts_from_filters' ) ) {
				$meta['filters'] = BWFCRM_Filters::convert_filters_to_new_filters( $meta['filters'] );
				BWFAN_Model_Import_Export::update( [ 'meta' => wp_json_encode( $meta ) ], [ 'id' => $export['id'] ] );
			}

			if ( isset( $meta['file'] ) ) {
				if ( file_exists( BWFCRM_EXPORT_DIR . '/' . $meta['file'] ) || file_exists( BWFCRM_EXPORT_DIR_BACKUP . '/' . $meta['file'] ) ) {
					$meta['file'] = true;
				} else {
					$meta['file'] = false;
				}
			}

			return array_merge( $export, $meta );
		}, $exports );

		return $this->success_response( $exports, __( 'Got Export data', 'wp-marketing-automations-pro' ) );
	}

	public function get_result_total_count() {
		return $this->total_count;
	}

}

BWFCRM_API_Exporter_Controller::get_instance();
