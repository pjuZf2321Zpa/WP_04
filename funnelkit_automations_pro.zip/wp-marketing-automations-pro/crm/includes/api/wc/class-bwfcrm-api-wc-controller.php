<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Skip if the parent abstract is not loaded yet (e.g. old loader still in memory during a plugin-update file-swap); prevents a fatal that would abort the update.
if ( ! class_exists( 'BWFCRM_API_Controller' ) ) {
	return;
}

class BWFCRM_API_WC_Controller extends BWFCRM_API_Controller {

	public static $ins;
	public $products = array();

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	protected function register_routes() {
		$this->add_route( '/products/', [
			[ 'GET', 'get_wc_products', array(
				'search' => array(
					'description' => __( 'Search from name', 'wp-marketing-automations-pro' ),
					'type'        => 'string',
				),
			) ],
		] );

		/**
		 * Note: /products/tags is registered separately by BWFCRM_API_Get_Product_Tags
		 * which extends WC_REST_Product_Tags_Controller and does not fit the controller pattern.
		 */
	}

	/**
	 * GET /products/
	 */
	public function get_wc_products() {
		$search = ! empty( $this->get_sanitized_arg( 'search', 'text_field' ) ) ? $this->get_sanitized_arg( 'search', 'text_field' ) : '';
		$ids    = BWFAN_Common::search_products( $search, true );

		if ( empty( $ids ) ) {
			return $this->success_response( [] );
		}

		/**
		 * Products types that are allowed in the offers
		 */
		$product_objects = array_filter( array_map( 'wc_get_product', $ids ), 'wc_products_array_filter_editable' );
		$products        = array();
		foreach ( $product_objects as $product_object ) {
			if ( ! $product_object instanceof WC_Product ) {
				continue;
			}

			if ( 'pending' === $product_object->get_status() ) {
				continue;
			}

			$image_url       = wp_get_attachment_image_src( get_post_thumbnail_id( $product_object->get_id() ), 'thumbnail', true );
			$image_url       = isset( $image_url[0] ) ? $image_url[0] : wc_placeholder_img_src();
			$image_file_name = basename( $image_url );
			$products[]      = array(
				'id'    => $product_object->get_id(),
				'name'  => strip_tags( rawurldecode( BWFAN_Common::get_formatted_product_name( $product_object ) ) ),
				"image" => array( "src" => $image_url, "name" => $image_file_name ),
			);
		}

		$this->response_code = 200;

		return $this->success_response( $products );
	}
}

BWFCRM_API_WC_Controller::get_instance();
