<?php
/**
 * REST API Product Tags controller
 *
 * Handles requests to the products/tags endpoint.
 *
 * @package WooCommerce\RestApi
 * @since   2.6.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * REST API Product Tags controller class.
 *
 * @package WooCommerce\RestApi
 * @extends WC_REST_Product_Tags_V2_Controller
 */

if ( ! class_exists( 'WC_REST_Product_Tags_Controller' ) ) {
	return;
}

#[\AllowDynamicProperties]
class BWFCRM_API_Get_Product_Tags extends WC_REST_Product_Tags_Controller {
	public static $ins;
	public $route = '/products/tags';

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	/**
	 * Endpoint namespace.
	 *
	 * @var string
	 */
	protected $namespace = BWFAN_API_NAMESPACE;

	/**
	 * WooCommerce builds these route args itself, so the routes are flagged after registration
	 */
	public function register_routes() {
		parent::register_routes();
		add_filter( 'rest_endpoints', array( $this, 'hide_routes_from_index' ) );
	}

	/**
	 * Keep this controller's routes out of the public REST index
	 *
	 * @param array $endpoints
	 *
	 * @return array
	 */
	public function hide_routes_from_index( $endpoints ) {
		$base = '/' . $this->namespace . '/' . $this->rest_base;
		foreach ( array( $base, $base . '/(?P<id>[\d]+)', $base . '/batch' ) as $route ) {
			if ( empty( $endpoints[ $route ] ) || ! is_array( $endpoints[ $route ] ) ) {
				continue;
			}
			foreach ( $endpoints[ $route ] as $key => $handler ) {
				if ( is_int( $key ) && is_array( $handler ) ) {
					$endpoints[ $route ][ $key ]['show_in_index'] = false;
				}
			}
		}

		return $endpoints;
	}
}

BWFCRM_API_Loader::register( 'BWFCRM_API_Get_Product_Tags' );
