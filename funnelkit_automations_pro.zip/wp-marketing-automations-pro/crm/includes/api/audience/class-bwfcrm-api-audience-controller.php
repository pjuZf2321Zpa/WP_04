<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Skip if the parent abstract is not loaded yet (e.g. old loader still in memory during a plugin-update file-swap); prevents a fatal that would abort the update.
if ( ! class_exists( 'BWFCRM_API_Controller' ) ) {
	return;
}

class BWFCRM_API_Audience_Controller extends BWFCRM_API_Controller {

	public static $ins;
	public $audiences = array();
	public $total_count = 0;
	public $count_data = [];

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	public function __construct() {
		$this->pagination         = new stdClass();
		$this->pagination->offset = 0;
		$this->pagination->limit  = 25;
		parent::__construct();
	}

	public function default_args_values() {
		return array(
			'audience_id'  => '',
			'name'         => '',
			'data'         => [],
			'audience_ids' => [],
			'ids'          => '',
			'search'       => '',
			'offset'       => 0,
			'limit'        => 0,
		);
	}

	protected function register_routes() {
		// GET /audiences + POST /audience
		$this->add_route( '/audiences', array(
			array( 'GET', 'get_audiences', array(
				'search' => array(
					'description' => __( 'Search from name', 'wp-marketing-automations-pro' ),
					'type'        => 'string',
				),
				'ids'    => array(
					'description' => __( 'Search from audience ids', 'wp-marketing-automations-pro' ),
					'type'        => 'string'
				),
			) ),
		) );

		$this->add_route( '/audience', array(
			array( 'POST', 'create_audience' ),
		) );

		// GET + PUT + DELETE /audience/{id}
		$this->add_route( '/audience/(?P<audience_id>[\d]+)', array(
			array( 'GET', 'get_audience_by_id' ),
			array( 'PUT', 'update_audience' ),
			array( 'DELETE', 'delete_audience' ),
		) );

		// GET /audiences/contacts
		$this->add_route( '/audiences/contacts', array(
			array( 'GET', 'get_audience_contacts_count' ),
		) );
	}

	/**
	 * GET /audiences
	 */
	public function get_audiences() {
		/** if isset search param then get the tag by name **/
		$search       = $this->get_sanitized_arg( 'search', 'text_field' );
		$audience_ids = empty( $this->args['ids'] ) ? array() : explode( ',', $this->args['ids'] );
		$limit        = $this->get_sanitized_arg( 'limit', 'text_field' );
		$offset       = $this->get_sanitized_arg( 'offset', 'text_field' );

		$audiences = BWFAN_Model_Terms::get_terms( 3, $offset, $limit, $search, $audience_ids );
		if ( ! is_array( $audiences ) ) {
			$audiences = array();
		}

		/** Ensure filter classes are registered so each stored filter can be validated below. */
		BWFCRM_Load_Filters::maybe_load_filters();

		$audiences = array_map( function ( $audience ) {
			$audience['data'] = BWFAN_PRO_Common::decode_stored_data_column( $audience['data'] ?? null ) ?? array();
			if ( ! empty( $audience['data']['filters'] ) ) {
				$audience['data']['filters'] = BWFAN_PRO_Common::prepare_stored_filters_for_admin( $audience['data']['filters'] );
				$audience['data']['filters'] = $this->remove_invalid_filters( $audience['data']['filters'] );
			}

			return $audience;
		}, $audiences );
		$count     = BWFAN_Model_Terms::get_terms_count( 3, $search, $audience_ids );

		$this->total_count   = $count;
		$this->count_data    = BWFAN_PRO_Common::get_contact_data_counts();
		$this->response_code = 200;

		return $this->success_response( $audiences );
	}

	/**
	 * Drop stored filter groups whose filter class is unavailable.
	 *
	 * A filter's class may be missing when the plugin that registered it is deactivated, or,
	 * for a custom-field filter, when the underlying field has been deleted. Mirrors the validation
	 * used in the audience contacts-count API so the admin never receives a dead filter to render.
	 *
	 * @param mixed $filters Nested filter groups (OR groups of AND rows) already normalized for admin.
	 *
	 * @return mixed Filtered groups, or the input unchanged when it is not an array.
	 */
	private function remove_invalid_filters( $filters ) {
		if ( empty( $filters ) || ! is_array( $filters ) ) {
			return $filters;
		}

		$valid_filters = array();
		foreach ( $filters as $filter_group ) {
			if ( ! is_array( $filter_group ) || ! isset( $filter_group[0] ) ) {
				continue;
			}

			$first_row   = $filter_group[0];
			$filter_slug = is_object( $first_row ) ? ( $first_row->filter ?? '' ) : ( is_array( $first_row ) ? ( $first_row['filter'] ?? '' ) : '' );

			if ( false !== strpos( $filter_slug, 'bwf_cf' ) ) {
				/** Custom-field filter: valid only if the underlying field still exists. */
				$field_id   = str_replace( 'bwf_cf', '', $filter_slug );
				$filter_obj = new BWFAN_Filter_BWF_CF( array(), $field_id );
				if ( ! $filter_obj->is_field_valid ) {
					continue;
				}
			} else {
				/** Standard filter: valid only if its registered class is loaded. */
				$filter_class = isset( BWFCRM_Load_Filters::$filter_classes[ $filter_slug ] ) ? BWFCRM_Load_Filters::$filter_classes[ $filter_slug ] : '';
				if ( ! class_exists( $filter_class ) ) {
					continue;
				}
			}

			$valid_filters[] = $filter_group;
		}

		return $valid_filters;
	}

	/**
	 * POST /audience
	 */
	public function create_audience() {
		$name = $this->get_sanitized_arg( 'name', 'text_field', $this->args['name'] );

		if ( empty( $name ) ) {
			$this->response_code = 400;
			$response            = __( 'Name is mandatory', 'wp-marketing-automations-pro' );

			return $this->error_response( $response );
		}

		if ( empty( $this->args['data'] ) || ( is_array( $this->args['data'] ) && empty( $this->args['data']['filters'] ) ) ) {
			$this->response_code = 400;
			$response            = __( 'Filters are mandatory.', 'wp-marketing-automations-pro' );

			return $this->error_response( $response );
		}

		$audience       = new BWFCRM_Audience();
		$already_exists = $audience->check_audience_is_exists( $name );
		if ( absint( $already_exists ) > 0 ) {
			$name = "$name - $already_exists";
		}

		$create_time = current_time( 'mysql', 1 );
		$audience->set_audience( 0, $name, $this->args['data'], $create_time, $create_time );
		$audience->save();
		if ( empty( $audience->get_id() ) ) {
			$this->response_code = 500;

			return $this->error_response( '', $audience );
		}
		$audience_data = $audience->get_array();


		return $this->success_response( $audience_data, __( 'Audience created', 'wp-marketing-automations-pro' ) );

	}

	/**
	 * GET /audience/{id}
	 */
	public function get_audience_by_id() {

		$audience_id = $this->get_sanitized_arg( 'audience_id', 'key' );

		if ( empty( $audience_id ) ) {
			$this->response_code = 404;
			$response            = __( 'Audience ID is mandatory ', 'wp-marketing-automations-pro' );

			return $this->error_response( $response );
		}

		$audience = new BWFCRM_Audience( absint( $audience_id ) );
		if ( ! $audience->is_audience_exists() ) {
			$this->response_code = 404;
			$response            = __( "Audience not exist with given ID #" . $audience_id, 'wp-marketing-automations-pro' );

			return $this->error_response( $response );
		}

		$audience_data = $audience->get_array();

		if ( empty( $audience_data ) ) {
			$this->response_code = 404;

			$response = __( 'No audience data found related with audience id:' . $audience_id, 'wp-marketing-automations-pro' );

			return $this->error_response( $response );
		}
		$audience_data['data'] = json_decode( $audience_data['data'] );
		$this->response_code   = 200;
		$success_message       = __( 'Audience data found with audience id:' . $audience_id, 'wp-marketing-automations-pro' );

		return $this->success_response( $audience_data, $success_message );

	}

	/**
	 * PUT /audience/{id}
	 */
	public function update_audience() {

		$audience_id = $this->get_sanitized_arg( 'audience_id', 'text_field' );

		if ( empty( $audience_id ) ) {
			$this->response_code = 404;
			$response            = __( "Audience Id is mandatory", 'wp-marketing-automations-pro' );

			return $this->error_response( $response );
		}

		$name = $this->get_sanitized_arg( 'name', 'text_field' );

		if ( empty( $name ) ) {
			$this->response_code = 404;
			$response            = __( "Audience name is Mandatory", 'wp-marketing-automations-pro' );

			return $this->error_response( $response );
		}

		/** if the provided id is audience id or not $data */
		$audience = new BWFCRM_Audience( absint( $audience_id ) );
		if ( ! $audience->is_audience_exists() ) {
			$this->response_code = 404;
			$response            = __( "Audience not exist with given ID #" . $audience_id, 'wp-marketing-automations-pro' );

			return $this->error_response( $response );
		}
		$updated_time = current_time( 'mysql', 1 );
		$audience->set_audience( $audience_id, $name, $this->args['data'], '', $updated_time );
		$saved = $audience->save();


		if ( 0 === $saved ) {
			$response            = __( 'Unable to update audience with id ' . $audience_id, 'wp-marketing-automations-pro' );
			$this->response_code = 400;

			return $this->error_response( $response );
		}

		$response = __( 'Audience updated', 'wp-marketing-automations-pro' );

		return $this->success_response( [], $response );

	}

	/**
	 * DELETE /audience/{id}
	 */
	public function delete_audience() {

		$audience_id = $this->get_sanitized_arg( 'audience_id', 'key' );

		if ( empty( $audience_id ) ) {
			$this->response_code = 404;
			$response            = __( 'Audience ID is mandatory', 'wp-marketing-automations-pro' );

			return $this->error_response( $response );
		}

		/** if the provided id is tag id or not $data */

		$audience = new BWFCRM_Audience( $audience_id );
		$audience->is_audience_exists();

		if ( ! $audience->is_audience_exists() ) {
			$this->response_code = 404;
			$response            = __( "Audience not exist with given ID #" . $audience_id, 'wp-marketing-automations-pro' );

			return $this->error_response( $response );
		}

		$delete_audince = BWFAN_Model_Terms::delete_term( $audience_id );
		if ( false === $delete_audince ) {
			$this->response_code = 404;

			$response = __( 'Unable to delete the Audience', 'wp-marketing-automations-pro' );

			return $this->error_response( $response );
		}

		$this->response_code = 200;
		$success_message     = __( 'Audience deleted', 'wp-marketing-automations-pro' );

		return $this->success_response( [], $success_message );

	}

	/**
	 * GET /audiences/contacts
	 */
	public function get_audience_contacts_count() {

		$audience_ids = $this->get_sanitized_arg( '', 'text_field', $this->args['audience_ids'] );
		$data         = [];
		if ( $audience_ids ) {
			foreach ( $audience_ids as $audience_id ) {
				$audience      = new BWFCRM_Audience( $audience_id );
				$audience_data = $audience->get_data();
				$audience_data = json_decode( $audience_data, true );
				$filters       = $audience_data['filters'];
				if ( ( method_exists( 'BWFCRM_Model_Contact', 'get_contacts_from_filters' ) ) ) {
					$contacts_count    = $this->get_audience_contacts_count_data( $filters, false, true );
					$subscribers_count = $this->get_audience_contacts_count_data( $filters, true );
				} else {
					$contacts_count    = $this->get_audience_contacts_count_old_filter( $filters );
					$subscribers_count = $this->get_audience_contacts_count_old_filter( $filters, true );
				}

				if ( ! isset( $data[ $audience_id ] ) ) {
					$data[ $audience_id ] = [];
				}

				if ( method_exists( 'BWFCRM_Model_Contact', 'get_contacts_from_filters' ) ) {
					$data[ $audience_id ]['contact_count']     = is_array( $contacts_count ) && isset( $contacts_count['total'] ) ? absint( $contacts_count['total'] ) : 0;
					$data[ $audience_id ]['customer_count']     = is_array( $contacts_count ) && isset( $contacts_count['customer_count'] ) ? absint( $contacts_count['customer_count'] ) : 0;
					$data[ $audience_id ]['total_revenue']     = is_array( $contacts_count ) && isset( $contacts_count['total_revenue'] ) ? absint( $contacts_count['total_revenue'] ) : 0;
					$data[ $audience_id ]['subscribers_count'] = is_array( $subscribers_count ) && isset( $subscribers_count['total'] ) ? absint( $subscribers_count['total'] ) : 0;
				} else {
					$data[ $audience_id ]['contact_count']     = is_array( $contacts_count ) && isset( $contacts_count['total'] ) ? intval( $contacts_count['total'] ) : 0;
					$data[ $audience_id ]['subscribers_count'] = is_array( $subscribers_count ) && isset( $subscribers_count['total'] ) ? absint( $subscribers_count['total'] ) : 0;
				}
			}
		}
		$this->response_code = 200;

		return $this->success_response( $data );
	}

	public function get_audience_contacts_count_data( $filters, $exclude_unsubscribers = false, $customer_count = false ) {
		$new_filters = [];
		if ( true === $exclude_unsubscribers ) {
			$unsubscribed_status = [ 0, 2, 3, 4, 5 ];

			/** Load filters if not already loaded */
			BWFCRM_Load_Filters::maybe_load_filters();

			foreach ( $filters as $filter_data ) {
				if ( ! is_array( $filter_data ) ) {
					continue; // Skip if not an array
				}

				$filter_key	  = isset( $filter_data[0]['filter'] ) ? $filter_data[0]['filter'] : '';
				if ( false !== strpos( $filter_key, 'bwf_cf' ) ) {

					/** Check if it's a valid custom field filter */
					$field_id = str_replace( 'bwf_cf', '', $filter_key );
					$filter_obj = new BWFAN_Filter_BWF_CF( $filter_data[0], $field_id );
					if ( ! $filter_obj->is_field_valid ) {
						continue;
					}
				} else {

					/** Check filter class exists */
					$filter_class = isset( BWFCRM_Load_Filters::$filter_classes[ $filter_key ] ) ? BWFCRM_Load_Filters::$filter_classes[ $filter_key ] : '';
					if ( ! class_exists( $filter_class ) ) {
						continue;
					}
				}

				$status_is_already = false;
				foreach ( $filter_data as $filter ) {
					/**
					 * if unverified(0), bounced(2), unsubscribed(3), soft bounced(4) and complaint(5) status available in filter then
					 * no need to get subscribers count
					 * Returns false immediately if any unsubscribed status is found
					 */
					if ( 'status' === $filter['filter'] && 'is' === $filter['rule'] && isset( $filter['data'] ) && in_array( absint( $filter['data'] ), $unsubscribed_status, true ) ) {
						return false;
					}

					if ( 'status' === $filter['filter'] && 'is' === $filter['rule'] && isset( $filter['data'] ) && intval( $filter['data'] ) === 1 ) {
						$status_is_already = true;
						break;
					}
				}
				/** Add status filter for get subscribers count */
				if ( false === $status_is_already ) {
					$filter_data[] = [
						'rule'   => 'is',
						'filter' => 'status',
						'data'   => 1,
					];
				}
				$new_filters[] = $filter_data;
			}
		}

		$additional_info = [
			'grab_totals'   => true,
			'only_count'    => true,
			'customer_data' => false,
			'customer_count' => $customer_count,
		];

		$filters = ! empty( $new_filters ) ? $new_filters : $filters;

		return BWFCRM_Model_Contact::get_contacts_from_filters( '', '', '', $filters, $additional_info );
	}

	public function get_audience_contacts_count_old_filter( $filters, $exclude_unsubscribers = false, $customer_count = false ) {

		$unsubscribed_status = [ 0, 2, 3, 4, 5 ];

		/**
		 * if unverified(0), bounced(2), unsubscribed(3), soft bounced(4) and complaint(5) status available in filter then
		 * no need to get subscribers count
		 */
		if ( $exclude_unsubscribers && isset( $filters['status_is'] ) && in_array( absint( $filters['status_is'] ), $unsubscribed_status, true ) ) {
			return false;
		}

		$additional_info = [
			'grab_totals'   => true,
			'only_count'    => true,
			'customer_data' => false,
			'customer_count' => $customer_count,
		];

		if ( $exclude_unsubscribers ) {
			$filters['status_is'] = 1;
		} else {
			$additional_info['customer_count'] = true;
		}
		$contact_data = BWFCRM_Contact::get_contacts( '', 0, 5, $filters, $additional_info );

		return [
			'total' => $contact_data['total_count'],
		];
	}

	public function get_result_total_count() {
		return $this->total_count;
	}

	public function get_result_count_data() {
		return $this->count_data;
	}
}

BWFCRM_API_Audience_Controller::get_instance();
