<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

#[AllowDynamicProperties]
class BWFCRM_Transactional_Mail_Loader {

	/**
	 * Cached default site language for the current request.
	 *
	 * @var string|null
	 */
	private static $cached_default_lang = null;

	private static $ins = null;

	/**
	 * Available mails
	 *
	 * @var array
	 */
	private static $available_mails = [];

	/**
	 * Enabled mails option data
	 *
	 * @var array
	 */
	private static $enabled_mails_option = [];

	/**
	 * Email class directory
	 *
	 * @var string
	 */
	private static $email_dir = BWFAN_PRO_PLUGIN_DIR . '/crm/includes/transactional-emails';

	/**
	 * Additional email directories registered via hook
	 *
	 * @var array
	 */
	private static $extra_email_dirs = [];

	/**
	 * Get instance
	 *
	 * @return BWFCRM_Transactional_Mail_Loader|null
	 */
	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	/**
	 * BWFCRM_Transactional_Mail_Loader constructor.
	 */
	public function __construct() {
		add_action( 'init', [ $this, 'load_enabled_files' ] );
		add_action( 'woocommerce_before_resend_order_emails', array( $this, 'handle_woocommerce_resend_mail' ), 10, 2 );
	}

	/**
	 * Get extra email directories registered via filter.
	 *
	 * @return array Array of absolute directory paths.
	 */
	public static function get_extra_email_dirs() {
		if ( empty( self::$extra_email_dirs ) ) {
			/**
			 * Filter to register additional transactional email directories.
			 *
			 * Each entry should be an absolute directory path containing
			 * class-bwfcrm-transactional-mail-*.php files.
			 *
			 * @param array $dirs Additional email directories.
			 */
			self::$extra_email_dirs = apply_filters( 'bwfcrm_transactional_mail_directories', [] );
			self::$extra_email_dirs = is_array( self::$extra_email_dirs ) ? self::$extra_email_dirs : [];
		}

		return self::$extra_email_dirs;
	}

	/**
	 * Handle woocommerce resend mail
	 *
	 * @param WC_Order $order Order object.
	 * @param string $type Type of mail.
	 *
	 * @return void
	 */
	public function handle_woocommerce_resend_mail( $order, $type ) {
		do_action( "bwfcrm_before_resend_order_email_" . $type, $order );
	}

	/**
	 * Get class name
	 *
	 * @param string $class_name
	 * @param string $slug
	 *
	 * @return string
	 */
	public function get_class_name( $class_name = '', $slug = '' ) {
		if ( empty( $class_name ) && empty( $slug ) ) {
			return '';
		}
		if ( $class_name !== '' ) {
			$search  = [ 'class-bwfcrm-', '.php', '-' ];
			$replace = [ '', '', '_' ];

			return 'BWFCRM_' . implode( '_', array_map( 'ucfirst', explode( '_', str_replace( $search, $replace, $class_name ) ) ) );
		}
		if ( $slug !== '' ) {
			return 'BWFCRM_Transactional_Mail_' . implode( '_', array_map( 'ucfirst', explode( '_', $slug ) ) );
		}
	}

	/**
	 * Get path info
	 *
	 * @param string $slug
	 *
	 * @return string
	 */
	public function get_path_info( $slug = '' ) {
		if ( empty( $slug ) ) {
			return '';
		}

		$filename = '/class-bwfcrm-transactional-mail-' . strtolower( str_replace( '_', '-', $slug ) ) . '.php';
		$path     = self::$email_dir . $filename;

		if ( file_exists( $path ) ) {
			return $path;
		}

		// Check extra email directories
		foreach ( self::get_extra_email_dirs() as $dir ) {
			$extra_path = rtrim( $dir, '/' ) . $filename;
			if ( file_exists( $extra_path ) ) {
				return $extra_path;
			}
		}

		return $path;
	}

	/**
	 * Get slug by class
	 *
	 * @param string $class
	 *
	 * @return string
	 */
	public static function get_slug_by_class( $class = '' ) {
		return strtolower( str_replace( 'BWFCRM_Transactional_Mail_', '', $class ) );
	}

	/**
	 * Get custom order statuses (excludes built-in WooCommerce statuses)
	 *
	 * @return array Key-value pairs of status_key (without wc- prefix) => label
	 */
	public function get_custom_order_statuses() {
		if ( ! function_exists( 'wc_get_order_statuses' ) ) {
			return [];
		}

		$all_statuses = wc_get_order_statuses();

		// Built-in statuses that already have dedicated classes
		$builtin = [
			'wc-pending', 'wc-processing', 'wc-on-hold',
			'wc-completed', 'wc-cancelled', 'wc-refunded',
			'wc-failed', 'wc-checkout-draft', 'wc-wfocu-pri-order',
		];

		$custom = [];
		foreach ( $all_statuses as $status_key => $status_label ) {
			if ( ! in_array( $status_key, $builtin, true ) ) {
				// Strip 'wc-' prefix
				$key            = str_replace( 'wc-', '', $status_key );
				$custom[ $key ] = $status_label;
			}
		}

		return apply_filters( 'bwfcrm_custom_order_statuses_for_transactional_mail', $custom );
	}

	/**
	 * Load enabled files only
	 */
	public function load_enabled_files() {
		if ( ! BWFAN_Common::check_for_lks() ) {
			return;
		}
		$enabled_mails              = $this->get_enabled_transactional_mails_setting();
		self::$enabled_mails_option = $enabled_mails;
		if ( empty( $enabled_mails ) ) {
			return;
		}
		foreach ( $enabled_mails as $class_slug => $data ) {

			if ( empty( $data['status'] ) || $data['status'] !== 'enabled' ) {
				continue;
			}

			$class_name = $this->get_class_name( '', $class_slug );
			$path       = $this->get_path_info( $class_slug );
			if ( ! file_exists( $path ) || empty( $class_name ) || class_exists( $class_name ) ) {
				continue;
			}
			require_once( $path );

			if ( ! in_array( $class_name, self::$available_mails ) ) {
				self::register( $class_name, true );
			}
		}

		// Register custom order status transactional mails (enabled only)
		$this->register_custom_status_mails( true );
	}

	/**
	 * Load all files
	 */
	public function load_all_files() {
		$dirs = array_merge( [ self::$email_dir ], self::get_extra_email_dirs() );

		foreach ( $dirs as $dir ) {
			foreach ( glob( rtrim( $dir, '/' ) . '/class-*.php' ) as $_field_filename ) {
				if ( ! is_readable( $_field_filename ) ) { // survive update file-swap / partial deploy
					continue;
				}
				$file_data  = pathinfo( $_field_filename );
				$class_name = $this->get_class_name( $file_data['filename'] );
				if ( ( isset( $file_data['basename'] ) && 'index.php' === $file_data['basename'] ) || in_array( $class_name, self::$available_mails ) ) {
					continue;
				}
				require_once( $_field_filename );

				if ( class_exists( $class_name ) ) {
					self::register( $class_name, false );
				}
			}
		}

		// Register custom order status transactional mails (all)
		$this->register_custom_status_mails( false );
	}

	/**
	 * Register custom status transactional mails
	 *
	 * @param bool $only_enabled Whether to only load enabled custom status mails.
	 *
	 * @return void
	 */
	public function register_custom_status_mails( $only_enabled = true ) {
		$custom_statuses = $this->get_custom_order_statuses();
		if ( empty( $custom_statuses ) ) {
			return;
		}

		if ( ! class_exists( 'BWFCRM_Transactional_Mail_Custom_Order_Status' ) ) {
			require_once self::$email_dir . '/class-bwfcrm-transactional-mail-custom-order-status.php';
		}

		$enabled_mails = $this->get_enabled_transactional_mails_setting();

		foreach ( $custom_statuses as $status_key => $status_label ) {
			$slug = 'custom_' . $status_key;

			// Skip if already registered
			if ( isset( self::$available_mails[ $slug ] ) ) {
				continue;
			}

			$data = $enabled_mails[ $slug ] ?? [];

			// If only loading enabled, skip anything not explicitly enabled.
			// A missing status (e.g. an entry created via the per-language
			// branch with only lang data, or one never configured) must
			// default to disabled so the mail's hooks are not registered
			// without the user enabling it.
			if ( $only_enabled && ( empty( $data['status'] ) || $data['status'] !== 'enabled' ) ) {
				continue;
			}

			$load_hooks = $only_enabled; // Only load hooks for enabled mails

			$class = new BWFCRM_Transactional_Mail_Custom_Order_Status(
				$load_hooks,
				$data,
				$status_key,
				$status_label
			);

			if ( $class instanceof BWFCRM_Transactional_Mail_Base ) {
				self::$available_mails[ $class->get_data( 'slug' ) ] = $class->get_api_data();
			}
		}
	}

	/**
	 * Register mail
	 *
	 * @param string $className
	 * @param bool $load_hooks
	 */
	public static function register( $className, $load_hooks = true ) {
		$slug  = self::get_slug_by_class( $className );
		$data  = self::$enabled_mails_option[ $slug ] ?? [];
		$class = new $className( $load_hooks, $data );
		if ( ! $class instanceof BWFCRM_Transactional_Mail_Base || ( ! $load_hooks && ! $class->is_valid() ) ) {
			return;
		}
		self::$available_mails[ $class->get_data( 'slug' ) ] = $class->get_api_data();
	}

	/**
	 * Get registered transactional mails
	 *
	 * @return array
	 */
	public function get_registered_transactional_mails() {
		$mails = self::$available_mails;

		if ( empty( $mails ) ) {
			return [];
		}

		uasort( $mails, function ( $a, $b ) {
			return $a['priority'] <=> $b['priority'];
		} );

		return array_values( $mails );
	}

	/**
	 * Returns API data for the transactional mail by slug and language
	 *
	 * @param $slug
	 * @param $lang
	 * @param bool $return_template
	 *
	 * @return array|false|mixed
	 */
	public function get_transactional_mail_by_slug( $slug, $lang = '', $return_template = true ) {
		// Collapse default-language code to '' so per-language overrides aren't
		// orphaned by the editor sending lang=<defaultCode> on monolingual paths.
		$lang = $this->normalize_lang_for_storage( $lang );
		// Get transactional mail saved data
		$enabled_mails = $this->get_enabled_transactional_mails_setting();
		// Mail data for slug
		$data = $enabled_mails[ $slug ] ?? [];

		// Get dynamic class
		$className = $this->get_class_name( '', $slug );

		// Get Loaded file
		$path = $this->get_path_info( $slug );

		if ( ! file_exists( $path ) || empty( $className ) ) {
			// Check if this is a custom status slug
			if ( strpos( $slug, 'custom_' ) === 0 ) {
				return $this->get_custom_status_mail_by_slug( $slug, $lang, $return_template );
			}
			return false;
		}

		if ( ! class_exists( $className ) ) {
			require_once( $path );
		}

		$class = new $className( false, $data );
		if ( ! $class instanceof BWFCRM_Transactional_Mail_Base ) {
			return false;
		}

		$apidata        = $class->get_api_data();
		$template_data  = [];
		$template_id    = 0;
		$template_title = isset( $apidata['name'] ) ? $apidata['name'] : $slug;
		$status         = isset( $apidata['enabled'] ) ? $apidata['enabled'] : false;
		$recipient      = isset( $apidata['recipient'] ) ? $apidata['recipient'] : '';

		if ( ! empty( $apidata['template_data'] ) ) {
			if ( empty( $lang ) && ! empty( $apidata['template_data']['template_id'] ) ) {
				$template_id = $apidata['template_data']['template_id'];
			} else if ( ! empty( $lang ) && ! empty( $apidata['template_data']['lang'][ $lang ] ) ) {
				$template_id = $apidata['template_data']['lang'][ $lang ];
			}

			// Legacy fallback: default-language template lives only under
			// lang[<defaultCode>] with no top-level template_id (pre-migration
			// state). Without this, the create branch below would overwrite that
			// existing entry with a fresh template if a save fires before
			// db_update_3_4_0 runs (e.g., first request is a REST call).
			if ( empty( $template_id ) && empty( $lang ) ) {
				$default_code = $this->get_default_site_language();
				if ( '' !== $default_code && ! empty( $apidata['template_data']['lang'][ $default_code ] ) ) {
					$template_id = $apidata['template_data']['lang'][ $default_code ];
				}
			}

			if ( ! empty( $template_id ) ) {
				$template_data = BWFAN_Model_Templates::bwfan_get_template( $template_id, 0 );
			}
		}

		// If template not found have to create a new template for the mail and save its data to the db
		if ( empty( $template_data ) ) { // Create a new template with mode=7 and save its data to the db
			$create_time = current_time( 'mysql', 1 );

			// Get default template data
			$template_data = $class->get_default_template_data();

			// Set current time
			$template_data['created_at'] = $template_data['updated_at'] = $create_time;

			// Create new template
			$template_id = BWFAN_Model_Templates::bwfan_create_new_template( $template_data );

			// Save template id to transactional mail data
			if ( empty( $lang ) ) {
				$enabled_mails[ $slug ]['template_id'] = $template_id;
				$enabled_mails[ $slug ]['status']      = 'disabled';
				$default_code                          = $this->get_default_site_language();
				if ( '' !== $default_code ) {
					$enabled_mails[ $slug ]['lang'][ $default_code ] = $template_id;
				}
			} else {
				$enabled_mails[ $slug ]['lang'][ $lang ] = $template_id;
			}
			update_option( 'bwfan_enabled_transactional_mails', $enabled_mails, true );

		}

		if ( ! $return_template ) {
			return $enabled_mails;
		}
		// check for json encoded value & decode
		if ( BWFAN_Common::is_json( $template_data['data'] ) ) {
			$template_data['data'] = json_decode( $template_data['data'], true );
		}
		$template_data['mode']              = 5;
		$template_data['title']             = $template_title;
		$template_data['slug']              = $slug;
		$template_data['status']            = $status;
		$template_data['recipient']         = $recipient;
		$template_data['merge_tag']         = ! empty( $apidata['merge_tag_group'] ) ? $apidata['merge_tag_group'] : [];
		$template_data['supported_block']   = ! empty( $apidata['supported_block'] ) ? $apidata['supported_block'] : [];
		$template_data['conditional_event'] = ! empty( $apidata['conditional_event'] ) ? $apidata['conditional_event'] : '';
		$template_data['custom_tag']        = ! empty( $apidata['custom_tag'] ) ? $apidata['custom_tag'] : [];

		return $template_data;
	}

	/**
	 * Get custom status transactional mail by slug
	 *
	 * @param string $slug     Custom status slug (e.g., 'custom_shipped').
	 * @param string $lang     Language code.
	 * @param bool   $return_template Whether to return template data or raw enabled_mails.
	 *
	 * @return array|false
	 */
	private function get_custom_status_mail_by_slug( $slug, $lang = '', $return_template = true ) {
		$lang            = $this->normalize_lang_for_storage( $lang );
		$status_key      = str_replace( 'custom_', '', $slug );
		$custom_statuses = $this->get_custom_order_statuses();

		if ( ! isset( $custom_statuses[ $status_key ] ) ) {
			return false;
		}

		if ( ! class_exists( 'BWFCRM_Transactional_Mail_Custom_Order_Status' ) ) {
			require_once self::$email_dir . '/class-bwfcrm-transactional-mail-custom-order-status.php';
		}

		$enabled_mails = $this->get_enabled_transactional_mails_setting();
		$data          = $enabled_mails[ $slug ] ?? [];

		$class = new BWFCRM_Transactional_Mail_Custom_Order_Status(
			false,
			$data,
			$status_key,
			$custom_statuses[ $status_key ]
		);

		if ( ! $class instanceof BWFCRM_Transactional_Mail_Base ) {
			return false;
		}

		$apidata        = $class->get_api_data();
		$template_id    = 0;
		$template_data  = [];
		$template_title = isset( $apidata['name'] ) ? $apidata['name'] : $slug;
		$status         = isset( $apidata['enabled'] ) ? $apidata['enabled'] : false;
		$recipient      = isset( $apidata['recipient'] ) ? $apidata['recipient'] : '';

		if ( ! empty( $apidata['template_data'] ) ) {
			if ( empty( $lang ) && ! empty( $apidata['template_data']['template_id'] ) ) {
				$template_id = $apidata['template_data']['template_id'];
			} else if ( ! empty( $lang ) && ! empty( $apidata['template_data']['lang'][ $lang ] ) ) {
				$template_id = $apidata['template_data']['lang'][ $lang ];
			}

			// Legacy fallback: default-language template lives only under
			// lang[<defaultCode>] with no top-level template_id (pre-migration
			// state). Prevents the create branch from overwriting that entry
			// when a save fires before db_update_3_4_0 has run.
			if ( empty( $template_id ) && empty( $lang ) ) {
				$default_code = $this->get_default_site_language();
				if ( '' !== $default_code && ! empty( $apidata['template_data']['lang'][ $default_code ] ) ) {
					$template_id = $apidata['template_data']['lang'][ $default_code ];
				}
			}

			if ( ! empty( $template_id ) ) {
				$template_data = BWFAN_Model_Templates::bwfan_get_template( $template_id, 0 );
			}
		}

		// If no template exists, create default
		if ( empty( $template_data ) ) {
			$create_time   = current_time( 'mysql', 1 );
			$template_data = $class->get_default_template_data( $lang );

			$template_data['created_at'] = $template_data['updated_at'] = $create_time;

			$template_id = BWFAN_Model_Templates::bwfan_create_new_template( $template_data );

			if ( empty( $lang ) ) {
				$enabled_mails[ $slug ]['template_id'] = $template_id;
				$enabled_mails[ $slug ]['status']      = 'disabled';
				$default_code                          = $this->get_default_site_language();
				if ( '' !== $default_code ) {
					$enabled_mails[ $slug ]['lang'][ $default_code ] = $template_id;
				}
			} else {
				$enabled_mails[ $slug ]['lang'][ $lang ] = $template_id;
			}
			update_option( 'bwfan_enabled_transactional_mails', $enabled_mails, true );
		}

		if ( ! $return_template ) {
			return $enabled_mails;
		}

		// Format response (same as existing method)
		if ( BWFAN_Common::is_json( $template_data['data'] ) ) {
			$template_data['data'] = json_decode( $template_data['data'], true );
		}
		$template_data['mode']              = 5;
		$template_data['title']             = $template_title;
		$template_data['slug']              = $slug;
		$template_data['status']            = $status;
		$template_data['recipient']         = $recipient;
		$template_data['merge_tag']         = ! empty( $apidata['merge_tag_group'] ) ? $apidata['merge_tag_group'] : [];
		$template_data['supported_block']   = ! empty( $apidata['supported_block'] ) ? $apidata['supported_block'] : [];
		$template_data['conditional_event'] = ! empty( $apidata['conditional_event'] ) ? $apidata['conditional_event'] : '';

		return $template_data;
	}

	/**
	 * Update all transactional mail status single or all
	 *
	 * @param $type
	 * @param $state
	 *
	 * @return bool
	 */
	public function update_transactional_mail_status( $type = '', $state = false ) {
		if ( empty( $type ) ) {
			return false;
		}

		$data = [];
		if ( $type === 'all' ) {
			self::load_all_files();
			foreach ( self::$available_mails as $slug => $data ) {
				$data = self::get_transactional_mail_by_slug( $slug, '', false );
			}

			$data = array_map( function ( $item ) use ( $state ) {
				$item['status'] = $state ? 'enabled' : 'disabled';

				return $item;
			}, $data );
		} else {
			$enabled_mails = $this->get_enabled_transactional_mails_setting();

			if ( isset( $enabled_mails[ $type ] ) ) {
				$enabled_mails[ $type ]['status'] = $state ? 'enabled' : 'disabled';
				$data                             = $enabled_mails;
			} else {
				$data = self::get_transactional_mail_by_slug( $type, '', false );
				if ( empty( $data ) ) {
					return false;
				}
				$data[ $type ]['status'] = $state ? 'enabled' : 'disabled';
			}
		}

		return update_option( 'bwfan_enabled_transactional_mails', $data, true );
	}

	public function get_enabled_transactional_mails() {
		return self::$enabled_mails_option;
	}

	public function get_transactional_activity( $search = '', $offset = 0, $limit = 25, $ids = [], $cids = [], $total = false ) {
		global $wpdb;

		// Get engagement tracking data with mode = 1, type = 9
		$query = "SELECT " . ( $total ? 'COUNT(ID) as count' : '*' ) . " FROM {table_name} WHERE type = 9 AND mode = 1";

		if ( ! empty( $ids ) ) {
			$query .= $wpdb->prepare( " AND ID in ( " . implode( ',', $ids ) . " )" );
		}

		if ( ! empty( $cids ) ) {
			$query .= $wpdb->prepare( " AND cid in ( " . implode( ',', $cids ) . " )" );
		}


		if ( ! empty( $search ) ) {
			$like = '%' . $wpdb->esc_like( $search ) . '%';
			$query .= $wpdb->prepare( ' AND send_to LIKE %s', $like );
		}
		$query .= ' ORDER BY updated_at DESC';
		if ( ! $total && intval( $limit ) > 0 ) {
			$offset = ! empty( $offset ) ? intval( $offset ) : 0;
			$query  .= $wpdb->prepare( " LIMIT %d, %d", $offset, $limit );
		}

		$result = BWFAN_Model_Engagement_Tracking::get_results( $query );
		if ( $total ) {
			return ! empty( $result ) ? $result[0]['count'] : 0;
		}
		$result = is_array( $result ) && ! empty( $result ) ? $this->get_formatted_transactional_data( $result ) : array();

		return $result;
	}

	public function get_formatted_transactional_data( $mails ) {
		$tids = [];
		$cids = [];
		foreach ( $mails as $mail ) {
			if ( ! empty( $mail['tid'] ) ) {
				$tids[] = $mail['tid'];
			}
			if ( ! empty( $mail['cid'] ) ) {
				$cids[] = $mail['cid'];
			}
		}
		$templates    = BWFAN_Model_Templates::get_templates_by_ids( array_unique( $tids ), [ 'ID', 'title' ] );
		$final_data   = [];
		$contact_list = BWFCRM_Model_Contact::get_contacts( '', '', 0, [], [ 'include_ids' => array_unique( $cids ) ] );
		$contact_list = is_array( $contact_list ) && isset( $contact_list['contacts'] ) ? $contact_list['contacts'] : [];
		$contacts     = [];
		foreach ( $contact_list as $item ) {
			$contacts[ $item['id'] ] = [
				'id'     => $item['id'],
				'f_name' => $item['f_name'],
				'l_name' => $item['l_name'],
				'email'  => $item['email'],
			];
		}
		foreach ( $mails as $mail ) {
			if ( ! empty( $mail['tid'] ) && isset( $templates[ $mail['tid'] ] ) ) {
				if ( isset( self::$available_mails[ $templates[ $mail['tid'] ]['title'] ] ) ) {
					$mail['transactional_type'] = self::$available_mails[ $templates[ $mail['tid'] ]['title'] ]['name'];
				}
				if ( isset( self::$available_mails[ $templates[ $mail['tid'] ]['title'] ]['merge_tag_group'] ) ) {
					$mail['is_order'] = in_array( 'order', self::$available_mails[ $templates[ $mail['tid'] ]['title'] ]['supported_block'] );
				}
				if ( isset( $contacts[ $mail['cid'] ] ) ) {
					$mail['contact'] = $contacts[ $mail['cid'] ];
				}
			}

			$final_data[] = $mail;
		}

		return $final_data;

	}

	/**
	 * Update transactional mail template id
	 *
	 * @param string $slug
	 * @param string $template_id
	 * @param string $lang
	 */
	public function update_transactional_mail_template_id( $slug = '', $template_id = '', $lang = '' ) {
		if ( empty( $slug ) || empty( $template_id ) ) {
			return false;
		}
		$lang          = $this->normalize_lang_for_storage( $lang );
		$enabled_mails = $this->get_enabled_transactional_mails_setting();

		if ( empty( $lang ) ) {
			$enabled_mails[ $slug ]['template_id'] = $template_id;
			$default_code                          = $this->get_default_site_language();
			if ( '' !== $default_code ) {
				$enabled_mails[ $slug ]['lang'][ $default_code ] = $template_id;
			}
		} else {
			$enabled_mails[ $slug ]['lang'][ $lang ] = $template_id;
		}

		return update_option( 'bwfan_enabled_transactional_mails', $enabled_mails, true );
	}

	/**
	 * Resend conversation
	 *
	 * @param int $eid
	 *
	 * @return bool
	 */
	public function resend_same_conversation( $eid ) {
		$conversation = new BWFAN_Engagement_Tracking( $eid );
		if ( ! $conversation instanceof BWFAN_Engagement_Tracking ) {
			return false;
		}

		$contact = $conversation->get_contact();
		if ( ! $contact instanceof BWFCRM_Contact ) {
			return false;
		}
		$merge_tags    = $conversation->get_merge_tags();
		$template_id   = $conversation->get_template_id();
		$template_data = BWFCRM_Templates::get_transactional_mail_by_template_id( $template_id );
		if ( empty( $template_data ) ) {
			return false;
		}
		$email_content = isset( $template_data['data'] ) && BWFAN_Common::is_json( $template_data['data'] ) ? json_decode( $template_data['data'], true ) : [];
		$email_body    = ! empty( $template_data['template'] ) ? $template_data['template'] : '';
		$email_subject = ! empty( $template_data['subject'] ) ? $template_data['subject'] : '';
		$pre_header    = isset( $email_content['preheader'] ) && ! empty( $email_content['preheader'] ) ? $email_content['preheader'] : '';
		if ( empty( $email_body ) || empty( $email_subject ) ) {
			return false;
		}
		/** @var  $global_email_settings BWFAN_Common settings */
		$global_email_settings = BWFAN_Common::get_global_settings();
		/** Email Subject And body */
		if ( is_array( $merge_tags ) && 0 < count( $merge_tags ) ) {
			$email_subject = BWFAN_Core()->conversations->parse_email_merge_tags( $email_subject, $merge_tags );
			$email_body    = BWFAN_Core()->conversations->parse_email_merge_tags( $email_body, $merge_tags );
			$pre_header    = BWFAN_Core()->conversations->parse_email_merge_tags( $pre_header, $merge_tags );
		}

		/** Email Body */
		$body = BWFAN_Common::bwfan_correct_protocol_url( $email_body );
		$body = BWFCRM_Core()->conversation->apply_template_by_type( $body, 'block', $email_subject );
		/** Apply Click tracking and UTM Params */
		$utm_enabled = isset( $email_content['utmEnabled'] ) && 1 === absint( $email_content['utmEnabled'] );
		$utm_data    = $utm_enabled && isset( $email_content['utm'] ) && is_array( $email_content['utm'] ) ? $email_content['utm'] : array();
		$uid         = $contact->contact->get_uid();
		/** Set contact object */
		BWFCRM_Core()->conversation->contact = $contact;
		$body                                = BWFCRM_Core()->conversation->append_to_email_body_links( $body, $utm_data, $conversation->get_hash(), $uid );
		/** Apply Pre-Header and Hash ID (open pixel id) */

		$body = BWFCRM_Core()->conversation->append_to_email_body( $body, $pre_header, $conversation->get_hash() );
		/** Email Headers */
		$reply_to_email = isset( $email_content['reply_to_email'] ) ? $email_content['reply_to_email'] : $global_email_settings['bwfan_email_reply_to'];
		$from_email     = isset( $email_content['from_email'] ) ? $email_content['from_email'] : $global_email_settings['bwfan_email_from'];
		$from_name      = isset( $email_content['from_name'] ) ? $email_content['from_name'] : $global_email_settings['bwfan_email_from_name'];
		/** Setup Headers */
		$header   = array();
		$header[] = 'MIME-Version: 1.0';
		if ( ! empty( $from_email ) && ! empty( $from_name ) ) {
			$header[] = 'From: ' . $from_name . ' <' . $from_email . '>';
		}
		if ( ! empty( $reply_to_email ) ) {
			$header[] = BWFAN_PRO_Common::build_reply_to_header( $reply_to_email, '', $from_name );
		}
		$header[] = 'Content-type:text/html;charset=UTF-8';
		/** Removed wp mail filters */
		BWFCRM_Common::bwf_remove_filter_before_wp_mail();
		$header = apply_filters( 'bwfan_email_headers', $header );

		BWFCRM_Common::$captured_email_failed_message = null;

		/** Send the Email */
		return wp_mail( $conversation->get_send_to(), $email_subject, $body, $header );
	}

	/**
	 * Resend conversation to contact
	 *
	 * @param int $eid
	 *
	 * @return bool|array
	 */
	public function resend_conversation_to_contact( $eid ) {
		$old_conversation = new BWFAN_Engagement_Tracking( $eid );
		if ( ! $old_conversation->is_valid() ) {
			return [
				'status'  => false,
				'message' => __( 'Conversation not found.', 'wp-marketing-automations-pro' ),
			];
		}
		$contact = $old_conversation->get_contact();
		if ( ! $contact instanceof BWFCRM_Contact ) {
			return [
				'status'  => false,
				'message' => __( "Contact doesn't exist", 'wp-marketing-automations-pro' ),
			];
		}

		// Get the metadata for the conversation
		$meta_data = BWFAN_Model_Engagement_Trackingmeta::get_meta( $eid );
		$con_meta  = [];
		foreach ( $meta_data as $item ) {
			if ( isset( $item['meta_key'] ) && isset( $item['meta_value'] ) ) {
				$con_meta[ $item['meta_key'] ] = json_decode( $item['meta_value'], true );
			}
		}

		$template_id   = $old_conversation->get_template_id();
		$template_data = BWFCRM_Templates::get_transactional_mail_by_template_id( $template_id );
		if ( empty( $template_data ) ) {
			return [
				'status'  => false,
				'message' => __( 'Template not found.', 'wp-marketing-automations-pro' ),
			];
		}
		$email_body    = ! empty( $template_data['template'] ) ? $template_data['template'] : '';
		$email_content = isset( $template_data['data'] ) && BWFAN_Common::is_json( $template_data['data'] ) ? json_decode( $template_data['data'], true ) : [];

		$email_subject = ! empty( $template_data['subject'] ) ? $template_data['subject'] : '';
		$pre_header    = isset( $email_content['preheader'] ) && ! empty( $email_content['preheader'] ) ? $email_content['preheader'] : '';
		if ( empty( $email_body ) || empty( $email_subject ) ) {
			return [
				'status'  => false,
				'message' => __( 'Email body or subject not found.', 'wp-marketing-automations-pro' ),
			];
		}
		/** @var  $global_email_settings BWFAN_Common settings */
		$global_email_settings = BWFAN_Common::get_global_settings();

		// Set merge tag data
		$merge_tags = $con_meta['merge_tags'] ?? '';

		if ( ! empty( $con_meta['conditional_set'] ) ) {
			BWFAN_Merge_Tag_Loader::set_data( [ 'conditional_set' => $con_meta['conditional_set'] ] );
		}

		$merge_tags_data = [];
		BWFAN_Common::bwfan_before_send_mail( 'block' );

		$merge_tags_list = BWFAN_Common::fetch_merge_tags( $email_body );

		// If merge tags are not available but exists in the content return false
		if ( ( empty( $merge_tags ) && ! empty( $merge_tags_list ) ) || ( false !== strpos( $email_body, 'bwfan_email_block_visibility' ) && empty( $con_meta['conditional_set'] ) ) ) {
			return [
				'status'  => false,
				'message' => __( "Unable to resend this email because the dynamic personalized data needed to generate it is no longer available.", 'wp-marketing-automations-pro' ),
			];
		}

		$new_conversation = new BWFAN_Engagement_Tracking();
		$new_conversation->set_template_id( $template_id );
		$new_conversation->set_oid( $old_conversation->get_oid() );
		$new_conversation->set_mode( BWFAN_Email_Conversations::$MODE_EMAIL );
		$new_conversation->set_contact( $contact );
		$new_conversation->set_send_to( $contact->contact->get_email() );
		$new_conversation->enable_tracking();
		$new_conversation->set_type( BWFAN_Email_Conversations::$TYPE_TRANSACTIONAL );
		$new_conversation->set_status( BWFAN_Email_Conversations::$STATUS_DRAFT );

		$email_body = method_exists( 'BWFAN_Common', 'correct_shortcode_string' ) ? BWFAN_Common::correct_shortcode_string( $email_body, 5 ) : $email_body;

		if ( ! empty( $merge_tags ) ) {
			// Set the merge tags if not empty
			$new_conversation->set_merge_tags( $merge_tags );
			/** Email Subject, Preheader And Body */
			$email_subject = BWFAN_Core()->conversations->parse_email_merge_tags( $email_subject, $merge_tags );
			$email_body    = BWFAN_Core()->conversations->parse_email_merge_tags( $email_body, $merge_tags );
			$pre_header    = BWFAN_Core()->conversations->parse_email_merge_tags( $pre_header, $merge_tags );
		} else {
			// Set the merge tags if empty by decoding current content
			$new_conversation->add_merge_tags_from_string( $email_body, $merge_tags_data );
			$new_conversation->add_merge_tags_from_string( $email_subject, $merge_tags_data );
			/** Email Subject, Preheader And Body */
			$email_subject = BWFAN_Common::decode_merge_tags( $email_subject );
			$merge_tags    = $new_conversation->get_merge_tags();
			$email_body    = BWFAN_Common::replace_merge_tags( $email_body, $merge_tags, $contact->get_id() );
			$pre_header    = BWFAN_Common::decode_merge_tags( $pre_header );
		}
		/** Email Body */
		$body = BWFAN_Common::bwfan_correct_protocol_url( $email_body );
		$body = BWFCRM_Core()->conversation->apply_template_by_type( $body, 'block', $email_subject );
		/** Apply Click tracking and UTM Params */
		$utm_enabled = isset( $email_content['utmEnabled'] ) && 1 === absint( $email_content['utmEnabled'] );
		$utm_data    = $utm_enabled && isset( $email_content['utm'] ) && is_array( $email_content['utm'] ) ? $email_content['utm'] : array();
		$uid         = $contact->contact->get_uid();
		/** Set contact object */
		BWFCRM_Core()->conversation->contact = $contact;
		$body                                = BWFCRM_Core()->conversation->append_to_email_body_links( $body, $utm_data, $new_conversation->get_hash(), $uid );
		/** Apply Pre-Header and Hash ID (open pixel id) */
		$body = BWFCRM_Core()->conversation->append_to_email_body( $body, $pre_header, $new_conversation->get_hash() );
		/** Email Headers */
		$reply_to_email = isset( $email_content['reply_to_email'] ) ? $email_content['reply_to_email'] : $global_email_settings['bwfan_email_reply_to'];
		$from_email     = isset( $email_content['from_email'] ) ? $email_content['from_email'] : $global_email_settings['bwfan_email_from'];
		$from_name      = isset( $email_content['from_name'] ) ? $email_content['from_name'] : $global_email_settings['bwfan_email_from_name'];
		/** Setup Headers */
		$header   = array();
		$header[] = 'MIME-Version: 1.0';
		if ( ! empty( $from_email ) && ! empty( $from_name ) ) {
			$header[] = 'From: ' . $from_name . ' <' . $from_email . '>';
		}
		if ( ! empty( $reply_to_email ) ) {
			$header[] = BWFAN_PRO_Common::build_reply_to_header( $reply_to_email, '', $from_name );
		}
		$header[] = 'Content-type:text/html;charset=UTF-8';
		/** Removed wp mail filters */
		BWFCRM_Common::bwf_remove_filter_before_wp_mail();

		$header = apply_filters( 'bwfan_email_headers', $header );

		BWFCRM_Common::$captured_email_failed_message = null;

		/** Send the Email */
		$email_status = wp_mail( $new_conversation->get_send_to(), $email_subject, $body, $header );
		/** Set the status of Email */
		if ( true === $email_status ) {
			$new_conversation->set_status( BWFAN_Email_Conversations::$STATUS_SEND );
		} else {
			$new_conversation->set_status( BWFAN_Email_Conversations::$STATUS_ERROR );
		}
		$new_conversation->save();

		return $email_status;
	}

	/**
	 * Update option template id by slug and lang parameter
	 *
	 * @param string $slug
	 * @param string $lang
	 *
	 * @return bool
	 */
	public function update_option_template_id( $slug = '', $template_id = 0, $lang = '' ) {
		if ( empty( $slug ) || empty( $template_id ) ) {
			return false;
		}
		$lang          = $this->normalize_lang_for_storage( $lang );
		$enabled_mails = $this->get_enabled_transactional_mails_setting();
		$before        = $enabled_mails;
		if ( empty( $lang ) ) {
			$enabled_mails[ $slug ]['template_id'] = $template_id;
			// Mirror to lang[<defaultCode>] so a future default-language change
			// can still resolve this content under the (now non-default) code.
			$default_code = $this->get_default_site_language();
			if ( '' !== $default_code ) {
				$enabled_mails[ $slug ]['lang'][ $default_code ] = $template_id;
			}
		} else {
			$enabled_mails[ $slug ]['lang'][ $lang ] = $template_id;
		}

		// When the pointer already targets this template the array is unchanged, and
		// update_option() would return false for that no-op. Treat "nothing to change"
		// as success so callers do not mistake an idempotent re-save for a failure.
		if ( $enabled_mails === $before ) {
			return true;
		}

		return update_option( 'bwfan_enabled_transactional_mails', $enabled_mails, true );
	}

	public function get_enabled_transactional_mails_setting() {
		$enabled_mails = get_option( 'bwfan_enabled_transactional_mails', [] );

		return ! is_array( $enabled_mails ) ? [] : $enabled_mails;
	}

	/**
	 * Resolve the SITE-DEFAULT language code (independent of current request locale).
	 *
	 * Storage decisions for transactional mail templates must key off the site
	 * default — not whatever language the admin happens to be browsing in —
	 * otherwise saves under non-default sessions overwrite the default-language
	 * pointer (`template_id`) with non-default content. Delegates to
	 * BWFCRM_Common::get_site_default_language() which returns the matching
	 * code format per active multilingual plugin.
	 *
	 * @return string
	 */
	private function get_default_site_language() {
		if ( null !== self::$cached_default_lang ) {
			return self::$cached_default_lang;
		}

		$lang = '';
		if ( class_exists( 'BWFCRM_Common' ) && method_exists( 'BWFCRM_Common', 'get_site_default_language' ) ) {
			$lang = (string) BWFCRM_Common::get_site_default_language();
		}

		self::$cached_default_lang = $lang;

		return self::$cached_default_lang;
	}

	/**
	 * Collapse a default-language code to '' so the per-language override branch
	 * is reserved for genuine non-default languages. Without this, fix/4562's JS
	 * change (which always sends lang=<defaultCode> on monolingual paths) would
	 * orphan the base template under `lang[<defaultCode>]`.
	 *
	 * @param string $lang
	 *
	 * @return string
	 */
	private function normalize_lang_for_storage( $lang = '' ) {
		if ( ! is_string( $lang ) || '' === $lang ) {
			return '';
		}

		$default = $this->get_default_site_language();
		if ( '' !== $default && strcasecmp( $lang, $default ) === 0 ) {
			return '';
		}

		return $lang;
	}

}

if ( class_exists( 'BWFCRM_Transactional_Mail_Loader' ) ) {
	BWFCRM_Core::register( 'transactional_mails', 'BWFCRM_Transactional_Mail_Loader' );
}
