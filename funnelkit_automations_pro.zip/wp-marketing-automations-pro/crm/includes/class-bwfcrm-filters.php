<?php

#[AllowDynamicProperties]
class BWFCRM_Filters {
	/** Filter Natures */
	public static $TYPE_JSON_ARRAY = 1;
	public static $TYPE_STRING = 2;
	public static $TYPE_STRING_EXACT = 3;
	public static $TYPE_DATE = 4;
	public static $TYPE_BOOL = 5;
	public static $TYPE_NUMBER = 6;
	public static $TYPE_CURRENCY = 7;
	public static $TYPE_DATE_RELATIVE = 8;
	public static $TYPE_NUMBER_EXACT = 9;
	public static $TYPE_DATETIME = 10;
	public static $TYPE_TIME = 11;

	public static $TYPE_CUSTOM_FILTER = 'custom';

	/** Date Timezones */
	public static $TIMEZONE_UTC = 1;
	public static $TIMEZONE_STORE = 2;

	/** Customer Filters */
	public static $wc_filters = array(
		'total_order_value',
		'total_order_count',
		'l_order_date',
		'l_order_days',
		'f_order_date',
		'f_order_days',
		'aov',
		'purchased_products_cats',
		'purchased_products_tags',
		'purchased_products',
		'used_coupons',
		'has_purchased',
		'has_used_any_coupons',
	);

	/** WC subscription Filters */
	public static $wcs_filters = array(
		'wcs_l_order_date',
		'wcs_l_order_days',
		'wcs_next_renewal_date',
		'wcs_next_renewal_days',
		'wcs_active_subs_count',
		'wcs_active_subs_product',
		'wcs_has_active_subscription',
		'wcs_total_renewal_count',
		'wcs_has_bought_subscription',
	);

	/** Contacts Filters */
	public static $wp_filters = array(
		'country',
		'creation_date',
		'f_name',
		'l_name',
		'contact_no',
		'state',
		'status',
		'tags',
		'lists',
		'email',
	);

	/** Contacts Meta Filters */
	public static $field_filters = array(
		'company',
		'dob',
		'gender',
		'postcode',
		'address-1',
		'address-2',
		'last-login',
		'last-open',
		'last-click',
		'last-sent',
	);

	public static $custom_filters = array();

	public static function register_custom_filter( $field ) {
		self::$custom_filters[] = $field;
	}

	/**
	 * Get filter type by contact field type
	 *
	 * @param $type
	 *
	 * @return int
	 */
	public static function get_type_by_field_type( $type ) {
		/** Datetime & time field type value */
		$type_datetime = property_exists( 'BWFCRM_Fields', 'TYPE_DATETIME' ) && BWFCRM_Fields::$TYPE_DATETIME ? BWFCRM_Fields::$TYPE_DATETIME : 8;
		$type_time     = property_exists( 'BWFCRM_Fields', 'TYPE_TIME' ) && BWFCRM_Fields::$TYPE_TIME ? BWFCRM_Fields::$TYPE_TIME : 9;

		switch ( intval( $type ) ) {
			case BWFCRM_Fields::$TYPE_CHECKBOX:
				return self::$TYPE_JSON_ARRAY;

			case BWFCRM_Fields::$TYPE_DATE:
				return self::$TYPE_DATE;

			case $type_datetime:
				return self::$TYPE_DATETIME;

			case $type_time:
				return self::$TYPE_TIME;

			case BWFCRM_Fields::$TYPE_NUMBER:
				return self::$TYPE_NUMBER;

			case BWFCRM_Fields::$TYPE_SELECT:
			case BWFCRM_Fields::$TYPE_RADIO:
				return self::$TYPE_STRING_EXACT;

			case BWFCRM_Fields::$TYPE_TEXT:
			case BWFCRM_Fields::$TYPE_TEXTAREA:
			default:
				return self::$TYPE_STRING;
		}
	}

	/**
	 * Get default rule by filter's nature
	 *
	 * @param $filter_type
	 *
	 * @return string
	 */
	public static function get_default_rule_by_filter_type( $filter_type ) {
		switch ( absint( $filter_type ) ) {
			case self::$TYPE_JSON_ARRAY:
				return 'any';
			case self::$TYPE_STRING:
				return 'contains';
			case self::$TYPE_STRING_EXACT:
				return 'is';
			case self::$TYPE_DATE:
				return 'is';
			case self::$TYPE_BOOL:
				return 'yes';
			case self::$TYPE_NUMBER:
			case self::$TYPE_NUMBER_EXACT:
				return 'is';
			case self::$TYPE_CURRENCY:
				return 'more_than';
			default:
				return 'is';
		}
	}

	/**
	 * Get default rule by contact field type
	 *
	 * @param $type
	 *
	 * @return string
	 */
	public static function get_default_rule_by_field_type( $type ) {
		switch ( absint( $type ) ) {
			case BWFCRM_Fields::$TYPE_CHECKBOX:
				return self::get_default_rule_by_filter_type( self::$TYPE_JSON_ARRAY );

			case BWFCRM_Fields::$TYPE_DATE:
				return self::get_default_rule_by_filter_type( self::$TYPE_DATE );

			case BWFCRM_Fields::$TYPE_NUMBER:
				return self::get_default_rule_by_filter_type( self::$TYPE_NUMBER );

			case BWFCRM_Fields::$TYPE_SELECT:
			case BWFCRM_Fields::$TYPE_RADIO:
				return self::get_default_rule_by_filter_type( self::$TYPE_STRING_EXACT );

			case BWFCRM_Fields::$TYPE_TEXT:
			case BWFCRM_Fields::$TYPE_TEXTAREA:
			default:
				return self::get_default_rule_by_filter_type( self::$TYPE_STRING );
		}
	}

	public static function get_type_by_wc_filters( $filter_key ) {
		switch ( $filter_key ) {
			case 'aov':
			case 'total_order_value':
				return self::$TYPE_CURRENCY;
			case 'total_order_count':
			case 'wcs_active_subs_count':
			case 'wcs_total_renewal_count':
				return self::$TYPE_NUMBER;
			case 'l_order_date':
			case 'f_order_date':
			case 'wcs_l_order_date':
			case 'wcs_next_renewal_date':
				return self::$TYPE_DATE;
			case 'l_order_days':
			case 'f_order_days':
			case 'wcs_l_order_days':
			case 'wcs_next_renewal_days':
				return self::$TYPE_DATE_RELATIVE;
			case 'purchased_products_tags':
			case 'purchased_products':
			case 'used_coupons':
			case 'purchased_products_cats':
			case 'wcs_active_subscriptions':
			case 'wcs_active_subs_product':
				return self::$TYPE_JSON_ARRAY;
			case 'has_used_any_coupons':
			case 'has_purchased':
			case 'wcs_has_active_subscription':
			case 'wcs_has_bought_subscription':
				return self::$TYPE_BOOL;
			default:
				return 0;
		}
	}

	public static function get_type_by_wp_filters( $filter_key ) {
		switch ( $filter_key ) {
			case 'country':
				return self::$TYPE_STRING_EXACT;
			case 'creation_date':
				return self::$TYPE_DATE;
			case 'f_name':
				return self::$TYPE_STRING;
			case 'l_name':
				return self::$TYPE_STRING;
			case 'contact_no':
				return self::$TYPE_STRING;
			case 'state':
				return self::$TYPE_STRING;
			case 'status':
				return self::$TYPE_NUMBER_EXACT;
			case 'tags':
				return self::$TYPE_JSON_ARRAY;
			case 'lists':
				return self::$TYPE_JSON_ARRAY;
			case 'email':
				return self::$TYPE_STRING;
			default:
				return 0;
		}
	}

	public static function get_type_by_field_filters( $filter_key ) {
		switch ( $filter_key ) {
			case 'company':
				return self::$TYPE_STRING;
			case 'dob':
				return self::$TYPE_DATE;
			case 'gender':
				return self::$TYPE_STRING_EXACT;
			case 'postcode':
				return self::$TYPE_STRING;
			case 'address-1':
				return self::$TYPE_STRING;
			case 'address-2':
				return self::$TYPE_STRING;
			case 'last-login':
				return self::$TYPE_DATE_RELATIVE;
			case 'last-open':
				return self::$TYPE_DATE_RELATIVE;
			case 'last-sent':
				return self::$TYPE_DATE_RELATIVE;
			case 'last-click':
				return self::$TYPE_DATE_RELATIVE;
			default:
				return 0;
		}
	}

	public static function get_filter_timezone( $filter_key ) {
		return self::$TIMEZONE_STORE;
	}

	public static function get_alternate_filter_key( $filter_key, $new_filter = false ) {
		if ( true === $new_filter ) {
			return $filter_key;
		}

		switch ( $filter_key ) {
			case 'l_order_days':
			case 'wcs_l_order_date':
			case 'wcs_l_order_days':
				return 'l_order_date';
			case 'f_order_days':
				return 'f_order_date';
			case 'wcs_next_renewal_date':
			case 'wcs_next_renewal_days':
				return 'next_renewal_date';
			case 'wcs_active_subs_count':
				return 'active_subs_count';
			case 'wcs_active_subs_product':
				return 'active_subs_product';
			case 'wcs_has_bought_subscription':
				return 'has_bought_subscription';
			case 'wcs_total_renewal_count':
				return 'renewal_count';
			default:
				return $filter_key;
		}
	}

	private static function _normalize_single_filter( $filter, $new_filter = false ) {
		/** Contact Filters */
		foreach ( self::$wp_filters as $filter_key ) {
			if ( substr( $filter, 0, strlen( $filter_key ) ) === $filter_key ) {
				$filter = explode( $filter_key . '_', $filter );
				if ( true === $new_filter ) {
					return [
						'key'   => $filter_key,
						'rule'  => count( $filter ) > 1 ? $filter[1] : '',
						'value' => '',
						'type'  => self::get_type_by_wp_filters( $filter_key ),
					];
				}

				return array(
					'key'      => self::get_alternate_filter_key( $filter_key ),
					'category' => 'c',
					'rule'     => count( $filter ) > 1 ? $filter[1] : '',
					'type'     => self::get_type_by_wp_filters( $filter_key ),
				);
			}
		}

		/** Customer Filters */
		foreach ( self::$wc_filters as $filter_key ) {
			if ( substr( $filter, 0, strlen( $filter_key ) ) === $filter_key ) {
				$filter = explode( $filter_key . '_', $filter );
				if ( true === $new_filter ) {
					return [
						'key'   => self::get_alternate_filter_key( $filter_key, true ),
						'rule'  => count( $filter ) > 1 ? $filter[1] : '',
						'value' => '',
						'type'  => self::get_type_by_wp_filters( $filter_key ),
					];
				}

				return array(
					'key'      => self::get_alternate_filter_key( $filter_key ),
					'category' => 'wc',
					'rule'     => count( $filter ) > 1 ? $filter[1] : '',
					'type'     => self::get_type_by_wc_filters( $filter_key ),
				);
			}
		}

		/** Customer Filters */
		foreach ( self::$wcs_filters as $filter_key ) {
			if ( substr( $filter, 0, strlen( $filter_key ) ) === $filter_key ) {
				$filter = explode( $filter_key . '_', $filter );

				return array(
					'key'      => self::get_alternate_filter_key( $filter_key ),
					'category' => 'wcs',
					'rule'     => count( $filter ) > 1 ? $filter[1] : '',
					'type'     => self::get_type_by_wc_filters( $filter_key ),
				);
			}
		}

		/** Contact Field Filters */
		foreach ( self::$field_filters as $filter_key ) {
			if ( substr( $filter, 0, strlen( $filter_key ) ) === $filter_key ) {
				$filter      = explode( $filter_key . '_', $filter );
				$filter_type = self::get_type_by_field_filters( $filter_key );
				if ( true === $new_filter ) {
					return [
						'key'   => $filter_key,
						'rule'  => count( $filter ) > 1 ? $filter[1] : '',
						'value' => '',
						'type'  => $filter_type,
					];
				}

				$filter_key = BWFCRM_Fields::get_field_id_by_slug( self::get_alternate_filter_key( $filter_key ) );
				if ( empty( $filter_key ) ) {
					return false;
				}

				return array(
					'key'      => 'f' . absint( $filter_key ),
					'category' => 'cm',
					'rule'     => count( $filter ) > 1 ? $filter[1] : '',
					'type'     => $filter_type,
				);
			}
		}

		/** Custom Filters */
		foreach ( self::$custom_filters as $filter_key ) {
			if ( substr( $filter, 0, strlen( $filter_key ) ) === $filter_key ) {
				$filter = explode( $filter_key . '_', $filter );
				if ( true === $new_filter ) {
					return [
						'key'   => $filter_key,
						'rule'  => count( $filter ) > 1 ? $filter[1] : '',
						'value' => '',
						'type'  => 'custom',
					];
				}

				return array(
					'key'      => $filter_key,
					'category' => 'custom',
					'rule'     => count( $filter ) > 1 ? $filter[1] : '',
					'type'     => 'custom',
				);
			}
		}

		return false;
	}

	public static function _convert_to_appropriate_timezone( $key, $value ) {
		if ( self::$TIMEZONE_UTC === self::get_filter_timezone( $key ) ) {
			return get_gmt_from_date( $value, 'Y-m-d' );
		}

		return $value;
	}

	public static function _handle_date_filter_value( $filter, $filter_value ) {
		if ( is_array( $filter_value ) ) {
			return array_map( function ( $date_val ) use ( $filter ) {
				return self::_convert_to_appropriate_timezone( $filter['key'], $date_val );
			}, $filter_value );
		}

		return self::_convert_to_appropriate_timezone( $filter['key'], $filter_value );
	}

	public static function _normalize_custom_fields_filters( $filters, $new_filter = false ) {
		BWFCRM_Load_Filters::maybe_load_filters();

		if ( ! is_array( $filters ) || empty( $filters ) ) {
			return array();
		}

		/** Fetch Custom Field filters from filters */
		$field_filters = array();
		foreach ( $filters as $filter_key => $filter ) {
			if ( false !== strpos( $filter_key, 'bwf_cf' ) ) {
				$field_filters[ $filter_key ] = $filter;
			}
		}

		if ( ! is_array( $field_filters ) || empty( $field_filters ) ) {
			return array();
		}

		$normalized_filters = array();

		foreach ( $field_filters as $filter_key => $filter ) {
			$filter_key = explode( 'bwf_cf', $filter_key )[1];
			$filter_key = explode( '_', $filter_key, 2 );

			$field_id     = intval( $filter_key[0] );
			$filter_rule  = $filter_key[1];
			$filter_value = $filter;
			if ( empty( $filter_value ) ) {
				continue;
			}

			$filter_db  = BWFAN_Model_Fields::get_field_by_id( $field_id );
			$field_type = 1;

			if ( ! empty( $filter_db ) && isset( $filter_db['type'] ) ) {
				$field_type = intval( $filter_db['type'] );
			}

			$filter_nature = self::get_type_by_field_type( $field_type );
			if ( self::$TYPE_JSON_ARRAY === $filter_nature ) {
				$filter_value = explode( ',', $filter_value );
			}

			/** If method call from normalize for new filter */
			if ( true === $new_filter ) {
				// Create filter object to get operators
				$filter_obj = new BWFAN_Filter_BWF_CF( [], $field_id );

				// Get possible operators based on field type
				$operators = $filter_obj->get_possible_operators();

				// Check if operator needs mapping using old_operators method
				if ( ! isset( $operators[ $filter_rule ] ) ) {
					$old_to_new_mapping = $filter_obj->old_operators();
					$filter_rule        = isset( $old_to_new_mapping[ $filter_rule ] ) ? $old_to_new_mapping[ $filter_rule ] : $filter_rule;
				}
				$filter_value         = is_array( $filter_value ) ? array_map( function ( $value ) {
					return [
						'key'   => $value,
						'label' => $value,
					];
				}, $filter_value ) : trim( $filter_value );
				$normalized_filters[] = [
					'key'   => 'bwf_cf' . $field_id,
					'rule'  => $filter_rule,
					'value' => $filter_value,
					'type'  => $filter_nature,
				];
				continue;
			}

			$normalized_filters['cm'][] = array(
				'key'   => 'f' . $field_id,
				'value' => is_array( $filter_value ) ? array_map( 'trim', $filter_value ) : trim( $filter_value ),
				'type'  => $filter_nature,
				'rule'  => $filter_rule,
			);
		}

		return $normalized_filters;
	}

	public static function _normalize_input_filters( $filters ) {

		/** Add Custom Field Filters */
		$normalized_filters = self::_normalize_custom_fields_filters( $filters );

		/** Add Rest of the Filters */
		foreach ( $filters as $filter => $filter_value ) {
			$filter = self::_normalize_single_filter( $filter );
			if ( empty( $filter ) || ! is_array( $filter ) ) {
				continue;
			}

			if ( self::$TYPE_DATE === $filter['type'] || self::$TYPE_DATE_RELATIVE === $filter['type'] ) {
				$filter_value = self::_handle_date_filter_value( $filter, $filter_value );
			}

			if ( 'total_order_count' === $filter['key'] || 'total_order_value' === $filter['key'] ) {
				$filter['value'] = $filter_value;
			} else {
				$filter['value'] = is_array( $filter_value ) ? array_map( 'trim', $filter_value ) : trim( $filter_value );
			}
			$filter_category = $filter['category'];
			unset( $filter['category'] );

			$normalized_filters[ $filter_category ][] = $filter;
		}

		return $normalized_filters;
	}

	public static function maybe_add_unsubscribe_lists_filter( $filters ) {
		if ( ! is_array( $filters ) || ! isset( $filters['lists_any'] ) ) {
			return $filters;
		}

		$settings = BWFAN_Common::get_global_settings();
		$enabled  = isset( $settings['bwfan_unsubscribe_lists_enable'] ) ? $settings['bwfan_unsubscribe_lists_enable'] : 0;
		if ( 0 === absint( $enabled ) ) {
			return $filters;
		}

		$public_lists = $settings['bwfan_unsubscribe_public_lists'];
		if ( empty( $public_lists ) || ! is_array( $public_lists ) ) {
			return $filters;
		}
		$lists = is_array( $filters['lists_any'] ) ? array_reduce( $filters['lists_any'], function ( $carry, $item ) {
			$items = explode( ',', $item );

			return array_replace( $carry, $items );
		}, array() ) : explode( ',', $filters['lists_any'] );
		$lists = array_values( array_intersect( $lists, $public_lists ) );
		$lists = implode( ',', $lists );

		$unsub_lists_field = BWFAN_Model_Fields::get_field_by_slug( 'unsubscribed-lists' );
		if ( is_array( $unsub_lists_field ) && isset( $unsub_lists_field['ID'] ) ) {
			$field_id                          = $unsub_lists_field['ID'];
			$filters["bwf_cf{$field_id}_none"] = $lists;
		}

		return $filters;
	}

	/**
	 * normalize filters data for new filter
	 *
	 * @param $filters
	 *
	 * @return array
	 */
	public static function _normalize_for_new_filters( $filters ) {
		BWFCRM_Load_Filters::maybe_load_filters();

		/** Check if filters are already in new format */
		if ( self::is_new_filter( $filters ) ) {
			return $filters;
		}

		/** Add Custom Field Filters */
		$normalized_filters = self::_normalize_custom_fields_filters( $filters, true );
		/** Add Rest of the Filters */
		foreach ( $filters as $filter => $filter_value ) {
			$filter = self::_normalize_single_filter( $filter, true );
			if ( empty( $filter ) || ! is_array( $filter ) ) {
				continue;
			}

			if ( self::$TYPE_DATE === $filter['type'] || self::$TYPE_DATE_RELATIVE === $filter['type'] ) {
				$filter_value = self::_handle_date_filter_value( $filter, $filter_value );
			}

			if ( 'total_order_count' === $filter['key'] || 'total_order_value' === $filter['key'] ) {
				$filter['value'] = $filter_value;
			} else {
				$filter['value'] = is_array( $filter_value ) ? array_map( 'trim', $filter_value ) : trim( $filter_value );
			}
			unset( $filter['category'] );

			$normalized_filters[] = $filter;
		}

		$normalized_filters = array_map( function ( $filter ) {
			$filter['filter'] = $filter['key'];
			$filter['data']   = $filter['value'];
			unset( $filter['key'] );
			unset( $filter['value'] );
			unset( $filter['type'] );

			/** Make slug compatible (remove hyphen) */
			$slug  = str_replace( '-', '_', $filter['filter'] );
			$class = isset( BWFCRM_Load_Filters::$filter_classes[ $slug ] ) ? BWFCRM_Load_Filters::$filter_classes[ $slug ] : '';
			if ( false !== strpos( $class, 'bwf_cf' ) ) {
				$field_id   = str_replace( 'bwf_cf', '', $class );
				$filter_obj = new BWFAN_Filter_BWF_CF( [], $field_id );
			} else {
				$filter_obj = class_exists( $class ) ? new $class() : $class;
			}
			if ( ! $filter_obj instanceof BWFAN_Filter_Base ) {
				return $filter;
			}
			$values = [];
			if ( 'search' === strtolower( $filter_obj->get_type() ) ) {
				$data   = ! is_array( $filter['data'] ) && false !== strpos( $filter['data'], ',' ) ? explode( ',', $filter['data'] ) : $filter['data'];
				$data   = ! is_array( $data ) ? [ $data ] : $data;
				$values = $filter_obj->get_value_as_key_label( $data );
				sort( $values );
			}

			/** If rule in not exists in operators */
			$operators = $filter_obj->get_possible_operators();
			$rule      = $filter['rule'];
			if ( ! isset( $operators[ $rule ] ) ) {
				$old_to_new_mapping = $filter_obj->old_operators();
				$filter['rule']     = isset( $old_to_new_mapping[ $rule ] ) ? $old_to_new_mapping[ $rule ] : $rule;
			}
			if ( 'between' === $filter['rule'] && is_array( $filter['data'] ) ) {
				$filter['data'] = [
					'from' => $filter['data'][0],
					'to'   => $filter['data'][1],
				];
			}
			$filter['data'] = ! empty( $values ) ? $values : $filter['data'];

			return $filter;
		}, $normalized_filters );

		return count( $normalized_filters ) > 0 ? [ $normalized_filters ] : [];
	}

	/**
	 * Normalize old filter data to new filter data
	 *
	 * @param $filters
	 *
	 * @return array|mixed
	 */
	public static function convert_filters_to_new_filters( $filters ) {
		$old_filters = BWFCRM_Filters::_normalize_for_new_filters( $filters );

		return ! empty( $old_filters ) ? $old_filters : $filters;
	}

	/**
	 * Get modified status query
	 *
	 * @param $filter_query
	 * @param $additional_info
	 * @param $unsubs_query
	 *
	 * @return array|mixed|string|string[]
	 */
	public static function get_modified_status_query( $filter_query, $additional_info, $unsubs_query ) {
		if ( empty( $filter_query ) ) {
			return '';
		}

		if ( is_array( $unsubs_query ) ) {
			$unsubs_query = '';
		}

		/** Include soft bounce status in query */
		$filter_query = ! empty( $additional_info['include_soft_bounce'] ) ? str_replace( [
			'c.status = 1 )',
			'c.status = 0 )'
		], [
			'c.status = 1 OR c.status = ' . BWFCRM_Contact::$STATUS_SOFT_BOUNCED . ' )',
			'c.status = 0 OR c.status = ' . BWFCRM_Contact::$STATUS_SOFT_BOUNCED . ' )'
		], $filter_query ) : $filter_query;

		/** Include unverified status in query */
		$filter_query = ! empty( $additional_info['include_unverified'] ) ? str_replace( [
			'c.status = 1 )',
			'c.status = 4 )'
		], [
			'c.status = 1 OR c.status = ' . BWFCRM_Contact::$STATUS_NOT_OPTED_IN . ' )',
			'c.status = 4 OR c.status = ' . BWFCRM_Contact::$STATUS_NOT_OPTED_IN . ' )'
		], $filter_query ) : $filter_query;

		/** Include unsubscribed status in query */
		return ! empty( $additional_info['include_unsubscribe'] ) ? str_replace( [ 'c.status = 1 )', 'c.status = 4 )', 'c.status = 0 )' ], [
			'c.status = 1 ' . $unsubs_query . ' )',
			'c.status = 4 ' . $unsubs_query . ' )',
			'c.status = 0 ' . $unsubs_query . ' )'
		], $filter_query ) : $filter_query;
	}

	/**
	 * Check if filters are in the new format.
	 *
	 * @param array $filters The filters array to check
	 *
	 * @return bool True if filters are in new format, false otherwise
	 */
	public static function is_new_filter( $filters ) {
		return isset( $filters[0] ) && isset( $filters[0][0] ) && isset( $filters[0][0]['filter'] );
	}
}
