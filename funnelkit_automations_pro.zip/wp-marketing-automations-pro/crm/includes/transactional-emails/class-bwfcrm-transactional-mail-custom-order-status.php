<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Dynamic transactional email class for custom WooCommerce order statuses.
 *
 * Unlike the 12 built-in transactional email classes that each handle a specific status,
 * this single class is instantiated per custom status at runtime by the Loader's
 * register_custom_status_mails() method.
 *
 * When loaded by glob() via load_all_files() without proper params, the constructor
 * returns early and is_valid() returns false, causing register() to discard the instance.
 */
#[AllowDynamicProperties]
class BWFCRM_Transactional_Mail_Custom_Order_Status extends BWFCRM_Transactional_Mail_Base {

	/**
	 * Track which order IDs have been scheduled for email processing
	 *
	 * @var array
	 */
	private $scheduled_ids = [];

	/**
	 * Custom status key without 'wc-' prefix (e.g., 'shipped')
	 *
	 * @var string
	 */
	private $custom_status = '';

	/**
	 * Custom status human-readable label (e.g., 'Shipped')
	 *
	 * @var string
	 */
	private $custom_label = '';

	/**
	 * Constructor
	 *
	 * @param bool   $load_hooks   Whether to register WooCommerce hooks.
	 * @param array  $data         Saved template/settings data from bwfan_enabled_transactional_mails option.
	 * @param string $status_key   Custom status key without 'wc-' prefix (e.g., 'shipped').
	 * @param string $status_label Human-readable status label (e.g., 'Shipped').
	 */
	public function __construct( $load_hooks = false, $data = [], $status_key = '', $status_label = '' ) {
		// Guard: if no status_key provided, this class was loaded by glob() via load_all_files()
		// without proper params. Return early — register_custom_status_mails() handles proper instantiation.
		if ( empty( $status_key ) ) {
			return;
		}

		$this->custom_status     = $status_key;
		$this->custom_label      = $status_label;
		$this->slug              = 'custom_' . $status_key;
		$this->name              = sprintf( __( '%s Order', 'wp-marketing-automations-pro' ), $status_label );
		$this->description       = sprintf(
			__( 'Notification sent to customers when order status changes to %s.', 'wp-marketing-automations-pro' ),
			$status_label
		);
		$this->priority          = apply_filters( 'bwfcrm_custom_status_mail_priority', 50, $status_key );
		// Apply recipient filter BEFORE hook registration — determines admin vs customer behavior
		$this->recipient         = apply_filters( 'bwfcrm_custom_status_mail_recipient', 'customer', $status_key );
		$this->subject           = apply_filters( 'bwfcrm_custom_status_mail_subject', sprintf(
			'%s: %s #%s',
			'{{store_name}}',
			__( 'Order status update', 'wp-marketing-automations-pro' ),
			'{{order_id}}'
		), $status_key, $status_label );
		$this->merge_tag_group   = [ 'wc_order' ];
		$this->conditional_event = 'wc_new_order';
		$this->supported_block   = [ 'order' ];
		$this->template_data     = $data;
		$this->wc_mail_id        = 'custom_' . $status_key;
		$this->is_custom         = true;
		$this->set_data_by_template_data();

		if ( $load_hooks && $this->is_valid() ) {
			// Hook into: woocommerce_order_status_{custom_status}
			// Fires when order transitions TO this status from ANY previous status
			add_action(
				'woocommerce_order_status_' . $this->custom_status,
				[ $this, 'run_custom_status_mail' ],
				30,
				2
			);

			// Hook for WooCommerce admin "Resend" dropdown support
			add_action(
				'bwfcrm_before_resend_order_email_custom_' . $this->custom_status,
				[ $this, 'resend_order_emails' ]
			);
		}
	}

	/**
	 * Resend order emails (triggered by WooCommerce admin resend dropdown)
	 *
	 * @param WC_Order $order Order object.
	 *
	 * @return void
	 */
	public function resend_order_emails( $order ) {
		if ( ! $order instanceof WC_Order ) {
			return;
		}
		$this->run_custom_status_mail( $order->get_id(), $order );
	}

	/**
	 * Schedule custom status mail on shutdown hook (prevents duplicate sends)
	 *
	 * @param int      $order_id Order ID.
	 * @param WC_Order $order    Order object.
	 *
	 * @return void
	 */
	public function run_custom_status_mail( $order_id, $order = null ) {
		$order_id = (int) $order_id;
		if ( isset( $this->scheduled_ids[ $order_id ] ) ) {
			return; // Prevent multiple scheduling
		}
		add_action( 'shutdown', function () use ( $order_id ) {
			$this->bwf_custom_status_order_mail( $order_id );
		} );
		$this->scheduled_ids[ $order_id ] = true; // Mark as scheduled
	}

	/**
	 * Check if mail is valid with dependency.
	 * Returns false if status_key is empty (glob-loaded without proper params by register()).
	 * This ensures register() discards the instance via its (!$load_hooks && !$class->is_valid()) check.
	 *
	 * @return bool
	 */
	public function is_valid() {
		if ( empty( $this->custom_status ) ) {
			return false;
		}

		return bwfan_is_woocommerce_active();
	}

	/**
	 * Execute the custom status mail send (runs on shutdown)
	 *
	 * @param int $order_id Order ID.
	 *
	 * @return void
	 */
	public function bwf_custom_status_order_mail( $order_id ) {
		/** Return if template id or order id is empty */
		if ( empty( $this->template_data['template_id'] ) || empty( $order_id ) ) {
			return;
		}

		/** Get order object */
		$order = wc_get_order( $order_id );

		if ( ! $order instanceof WC_Order ) {
			return;
		}

		/** Get template id */
		$template_id = intval( $this->template_data['template_id'] );

		/** Resolve language-specific template */
		$order_language = BWFAN_Common::get_order_language( $order );
		if ( ! empty( $order_language ) && isset( $this->template_data['lang'][ $order_language ] ) ) {
			$template_id = $this->template_data['lang'][ $order_language ];
		}

		/** Set data for merge tags — branch based on recipient type */
		if ( $this->recipient === 'admin' ) {
			$set_data = array(
				'order_id'   => $order_id,
				'oid'        => $order_id,
				'email'      => BWFAN_Common::$admin_email,
				'wc_order'   => $order,
				'contact_id' => 0,
			);
		} else {
			// Customer recipient — use billing email and contact ID
			$set_data = array(
				'order_id'   => $order_id,
				'oid'        => $order_id,
				'email'      => BWFAN_Woocommerce_Compatibility::get_order_data( $order, '_billing_email' ),
				'wc_order'   => $order,
				'contact_id' => BWFAN_Woocommerce_Compatibility::get_order_data( $order, '_woofunnel_cid' ),
			);
		}

		/** Create engagement tracking — base class handles full send pipeline */
		$this->create_engagement_tracking( $template_id, $this->get_api_data(), $set_data );
	}

	/**
	 * Get custom tag
	 *
	 * @return array
	 */
	public function get_custom_tag() {
		return [
			__('Custom Order Status', 'wp-marketing-automations-pro'),
		];
	}
}
