<?php

defined( 'ABSPATH' ) || exit;

/**
 * What each block and option of the email editor means: the knowledge the
 * editor's settings panels hold and the manifest cannot - allowed values and
 * what each does, units and ranges, which options depend on others, which are
 * worked out on save or have no effect, which need store data or a trigger's
 * context, and recipes for common requests.
 *
 * Read through BWFCRM_Email_Design_Versions: manifest/2.1-guide.json, and a
 * <version>-guide.diff.json for each later editor version that changed it -
 * written by hand from the editor's settings panels and the send-time code. Every name it uses is
 * checked against the manifest by the self-checks, so it cannot drift from
 * the editor it describes.
 */
class BWFCRM_Email_Design_Guide {

	/** Keys of an attribute entry passed on to the agent, in this order. */
	const ATTRIBUTE_KEYS = array( 'label', 'description', 'values', 'unit', 'range', 'depends_on', 'site_data', 'computed', 'ignored', 'placeholder' );

	/** Keys of a block entry passed on to the agent. */
	const BLOCK_KEYS = array( 'summary', 'use_when', 'needs', 'without_context' );

	/** @var array|null */
	private static $data = null;

	/**
	 * @return array The guide; empty when it is missing or unreadable (the tools then work without it).
	 */
	public static function get() {
		if ( null !== self::$data ) {
			return self::$data;
		}

		require_once __DIR__ . '/class-bwfcrm-email-design-versions.php';

		// The 2.1 guide, with each later editor version's guide diff applied.
		$data = BWFCRM_Email_Design_Versions::resolve( 'guide', BWFCRM_Email_Design_Manifest::EDITOR_VERSION );
		$data = is_wp_error( $data ) ? null : $data;

		/**
		 * The email design guide the MCP tools give to AI clients.
		 *
		 * @param array $data
		 */
		self::$data = (array) apply_filters( 'bwfcrm_email_design_guide', is_array( $data ) ? $data : array() );

		return self::$data;
	}

	/** For the self-checks: load a guide from an array instead of the shipped file. */
	public static function set( $data ) {
		self::$data = is_array( $data ) ? $data : null;
	}

	/**
	 * A block's guidance: summary, use_when, needs, without_context.
	 *
	 * @param string $name
	 *
	 * @return array
	 */
	public static function block( $name ) {
		$guide = self::get();
		$entry = isset( $guide['blocks'][ $name ] ) && is_array( $guide['blocks'][ $name ] ) ? $guide['blocks'][ $name ] : array();

		return array_intersect_key( $entry, array_flip( self::BLOCK_KEYS ) );
	}

	/**
	 * An attribute's guidance, from the block's own entry or the shared ones.
	 *
	 * @param string $block
	 * @param string $attribute
	 *
	 * @return array
	 */
	public static function attribute( $block, $attribute ) {
		$guide = self::get();

		if ( isset( $guide['blocks'][ $block ]['attributes'][ $attribute ] ) ) {
			$entry = $guide['blocks'][ $block ]['attributes'][ $attribute ];
		} elseif ( isset( $guide['shared'][ $attribute ] ) ) {
			$entry = $guide['shared'][ $attribute ];
		} else {
			return array();
		}

		$out = array();

		foreach ( self::ATTRIBUTE_KEYS as $key ) {
			if ( isset( $entry[ $key ] ) && '' !== $entry[ $key ] ) {
				$out[ $key ] = $entry[ $key ];
			}
		}

		return $out;
	}

	/**
	 * A block's attribute definitions from the manifest, each with its guidance
	 * added: what the agent reads when it asks for a block's details.
	 *
	 * @param string $block
	 * @param array  $attributes name => manifest definition.
	 *
	 * @return array
	 */
	public static function describe_attributes( $block, array $attributes ) {
		foreach ( $attributes as $name => $definition ) {
			$attributes[ $name ] = array_merge( (array) $definition, self::attribute( $block, $name ) );
		}

		return $attributes;
	}

	/**
	 * The attributes an agent must not set: worked out on save, or with no effect.
	 *
	 * @param string $block
	 *
	 * @return string[]
	 */
	public static function hands_off( $block ) {
		$guide = self::get();
		$out   = array();

		foreach ( isset( $guide['blocks'][ $block ]['attributes'] ) ? (array) $guide['blocks'][ $block ]['attributes'] : array() as $name => $entry ) {
			if ( ! empty( $entry['computed'] ) || ! empty( $entry['ignored'] ) ) {
				$out[] = $name;
			}
		}

		return $out;
	}

	/** @return array[] The recipes for common requests. */
	public static function recipes() {
		$guide = self::get();

		return isset( $guide['recipes'] ) && is_array( $guide['recipes'] ) ? array_values( $guide['recipes'] ) : array();
	}

	/**
	 * A recipe by name.
	 *
	 * @param string $name
	 *
	 * @return array|null
	 */
	public static function recipe( $name ) {
		foreach ( self::recipes() as $recipe ) {
			if ( isset( $recipe['name'] ) && $name === $recipe['name'] ) {
				return $recipe;
			}
		}

		return null;
	}

	/**
	 * The recipes as a menu: name, description, block and needs, without the
	 * attributes - those come with recipe() or recipes().
	 *
	 * @return array[]
	 */
	public static function recipe_summaries() {
		$summaries = array();

		foreach ( self::recipes() as $recipe ) {
			unset( $recipe['attrs'] );
			$summaries[] = $recipe;
		}

		return $summaries;
	}

	/**
	 * Art direction for AI clients: how to make an email distinctive rather
	 * than the most common one, as a markdown brief. Plain text beside this
	 * file so a designer can edit it; empty when it is missing.
	 *
	 * @return string
	 */
	public static function art_direction() {
		$file = __DIR__ . '/art-direction.txt';
		$text = is_readable( $file ) ? (string) file_get_contents( $file ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- a file shipped inside this plugin, not a URL.

		/**
		 * The art direction the MCP tools give to AI clients designing an email.
		 *
		 * @param string $text Markdown.
		 */
		return (string) apply_filters( 'bwfcrm_email_design_art_direction', $text );
	}

	/** @return string How styling attributes are named, said once rather than per attribute. */
	public static function style_pattern() {
		$guide = self::get();

		return isset( $guide['style_pattern'] ) ? (string) $guide['style_pattern'] : '';
	}

	/**
	 * A placeholder default still in an attribute: the text the editor ships as
	 * a stand-in, which would go out as written.
	 *
	 * @param string $block
	 * @param string $attribute
	 *
	 * @return string|null
	 */
	public static function placeholder( $block, $attribute ) {
		$entry = self::attribute( $block, $attribute );

		return isset( $entry['placeholder'] ) ? (string) $entry['placeholder'] : null;
	}
}
