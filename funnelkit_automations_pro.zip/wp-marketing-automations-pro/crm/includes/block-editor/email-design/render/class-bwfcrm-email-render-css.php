<?php

defined( 'ABSPATH' ) || exit;

/**
 * The email editor's CSS helpers: padding, borders, backgrounds and type,
 * written the way the editor writes them, so a block's CSS here is the CSS the
 * editor would produce for the same attributes. Kept deliberately literal -
 * quirks included - because the editor's output is the reference.
 */
final class BWFCRM_Email_Render_Css {

	private static function t( $value ) {
		return BWFCRM_Email_Render_Js::truthy( $value );
	}

	private static function s( $value ) {
		return BWFCRM_Email_Render_Js::str( $value );
	}

	private static function g( $value, $key ) {
		return BWFCRM_Email_Render_Js::get( $value, array( (string) $key ) );
	}

	/** Truthy, or exactly the number 0. */
	private static function set_or_zero( $value ) {
		return self::t( $value ) || BWFCRM_Email_Render_Js::is_zero( $value );
	}

	public static function box_shadow( $shadow ) {
		$h      = self::g( $shadow, 'h_offset' );
		$v      = self::g( $shadow, 'v_offset' );
		$blur   = self::g( $shadow, 'blur' );
		$spread = self::g( $shadow, 'spread' );

		if ( '' === $h && '' === $v && '' === $blur && '' === $spread ) {
			return '';
		}

		$color = self::g( $shadow, 'color' );

		return self::s( $h ) . 'px ' . self::s( $v ) . 'px ' . self::s( $blur ) . 'px ' . self::s( $spread ) . 'px ' . ( self::t( $color ) ? self::s( $color ) : 'transparent' ) . ' ' . ( self::t( self::g( $shadow, 'inset' ) ) ? 'inset' : '' );
	}

	public static function unit_value( $data, $style = 'width', $default_unit = 'px', $default_key = 'value', $default_unit_key = 'unit' ) {
		if ( ! self::t( $data ) || ! BWFCRM_Email_Render_Js::has( $data, $default_key ) ) {
			return '';
		}

		$value = self::g( $data, $default_key );

		if ( '' === $value ) {
			return '';
		}

		$unit = self::t( self::g( $data, $default_unit_key ) ) ? self::g( $data, $default_unit_key ) : $default_unit;

		return self::t( $style ) ? $style . ':' . self::s( $value ) . self::s( $unit ) . ';' : self::s( $value ) . self::s( $unit );
	}

	public static function width( $width, $style = 'width' ) {
		return self::dimension( $width, $style, 'width' );
	}

	public static function height( $height, $style = 'height' ) {
		return self::dimension( $height, $style, 'height' );
	}

	private static function dimension( $value, $style, $key ) {
		$direct = self::g( $value, $key );

		if ( self::t( $value ) && ( self::t( $direct ) || BWFCRM_Email_Render_Js::is_zero( $direct ) ) ) {
			return ( self::t( $direct ) || BWFCRM_Email_Render_Js::is_zero( $direct ) || '0' === $direct )
				? $style . ':' . self::s( $direct ) . ( self::t( self::g( $value, 'unit' ) ) ? self::s( self::g( $value, 'unit' ) ) : 'px' ) . ';'
				: '';
		}

		$desktop = self::g( $value, 'desktop' );
		$inner   = self::g( $desktop, $key );

		return self::t( $value ) && self::t( $desktop ) && ( self::t( $inner ) || BWFCRM_Email_Render_Js::is_zero( $inner ) || '0' === $inner )
			? $style . ':' . self::s( $inner ) . ( self::t( self::g( $desktop, 'unit' ) ) ? self::s( self::g( $desktop, 'unit' ) ) : 'px' ) . ';'
			: '';
	}

	/**
	 * @return string|null Null where the editor's function returns undefined (all four sides empty).
	 */
	public static function shorthand( $top, $right, $bottom, $left, $unit ) {
		if ( '' === $top && '' === $right && '' === $bottom && '' === $left ) {
			return null;
		}

		$side = static function ( $value ) use ( $unit ) {
			$number = BWFCRM_Email_Render_Js::parse_float( $value );

			// parseFloat( v ) != 0 && '' !== v - NaN is "not 0".
			return ( ( is_nan( $number ) || 0.0 !== (float) $number ) && '' !== $value )
				? BWFCRM_Email_Render_Js::number_to_string( $number ) . BWFCRM_Email_Render_Js::str( $unit ) . ' '
				: '0 ';
		};

		$top    = $side( $top );
		$right  = $side( $right );
		$bottom = $side( $bottom );
		$left   = $side( $left );

		if ( $right === $left ) {
			$left = '';

			if ( $top === $bottom ) {
				$bottom = '';

				if ( $top === $right ) {
					$right = '';
				}
			}
		}

		return trim( $top . $right . $bottom . $left );
	}

	public static function background( $background, $important = false ) {
		$is_important = $important ? '! important' : '';

		if ( BWFCRM_Email_Render_Js::is_empty( $background ) ) {
			return '';
		}

		$css       = '';
		$gradient  = '';
		$image     = '';
		$color     = '';
		$color_css = '';
		$position  = 'center top';
		$size      = 'cover';
		$repeat    = 'no-repeat';

		foreach ( BWFCRM_Email_Render_Js::plain( $background ) as $key => $value ) {
			if ( ! self::t( $value ) ) {
				continue;
			}

			$key = (string) $key;

			if ( 'gradient' === $key ) {
				$gradient = $value;
			} elseif ( 'image' === $key ) {
				$image = $value;
			} elseif ( 'position' === $key ) {
				$x        = self::g( $value, 0 );
				$y        = self::g( $value, 1 );
				$position = ( self::t( $x ) ? BWFCRM_Email_Render_Js::str( BWFCRM_Email_Render_Js::number( $x ) * 100 ) : '0' ) . '% ' . ( self::t( $y ) ? BWFCRM_Email_Render_Js::str( BWFCRM_Email_Render_Js::number( $y ) * 100 ) : '0' ) . '%';
				$css     .= 'background-' . $key . ':' . $position . '% ;';
			} elseif ( 'color' === $key ) {
				$color     = $value;
				$color_css = 'background-' . $key . ':' . self::s( $value ) . ' ' . $is_important . ';';
			} elseif ( 'size' === $key ) {
				$size = $value;
			} elseif ( 'repeat' === $key ) {
				$repeat = $value;
			} else {
				$css .= 'background-' . $key . ':' . self::s( $value ) . ' ' . $is_important . ';';
			}
		}

		if ( ! BWFCRM_Email_Render_Js::is_empty( $image ) || ! BWFCRM_Email_Render_Js::is_empty( $gradient ) ) {
			$url  = self::t( $image ) ? "url('" . self::s( self::g( $image, 'url' ) ) . "')" . ( self::t( $gradient ) ? ',' : '' ) : '';
			$css .= 'background:' . self::s( $color ) . ' ' . $url . ' ' . self::s( $gradient ) . ' ' . self::s( $position ) . ' / ' . self::s( $size ) . ' ' . self::s( $repeat ) . ';';

			if ( ! BWFCRM_Email_Render_Js::is_empty( $image ) ) {
				$css .= 'background-position:' . self::s( $position ) . ' ;';
				$css .= 'background-repeat:' . self::s( $repeat ) . ' ;';
				$css .= 'background-size:' . self::s( $size ) . ' ;';
			}
		} else {
			$css .= $color_css;
		}

		return $css;
	}

	public static function space( $space, $type = 'padding', $ie_support = false, $important = false ) {
		$is_important = $important ? '! important' : '';
		$prefix       = $ie_support ? 'mso-' : '';
		$suffix       = $ie_support ? '-alt' : '';

		$top    = self::g( $space, 'top' );
		$right  = self::g( $space, 'right' );
		$bottom = self::g( $space, 'bottom' );
		$left   = self::g( $space, 'left' );
		$unit   = self::g( $space, 'unit' );

		if ( ! ( self::set_or_zero( $top ) || self::set_or_zero( $right ) || self::set_or_zero( $bottom ) || self::set_or_zero( $left ) ) ) {
			return '';
		}

		if ( self::set_or_zero( $top ) && self::set_or_zero( $right ) && self::set_or_zero( $bottom ) && self::set_or_zero( $left ) ) {
			return $prefix . $type . $suffix . ':' . self::s( self::shorthand( $top, $right, $bottom, $left, $unit ) ) . $is_important . ';';
		}

		$css = '';

		foreach ( array( 'top' => $top, 'bottom' => $bottom, 'left' => $left, 'right' => $right ) as $side => $value ) {
			if ( '' !== $value ) {
				$css .= $prefix . $type . '-' . $side . $suffix . ': ' . self::s( $value ) . self::s( $unit ) . $is_important . ';';
			}
		}

		return $css;
	}

	public static function padding( $padding = array(), $important = false, $ie_support = false ) {
		$is_important = $important ? '! important' : '';
		$prefix       = $ie_support ? 'mso-' : '';
		$suffix       = $ie_support ? '-alt' : '';

		$top    = self::g( $padding, 'top' );
		$right  = self::g( $padding, 'right' );
		$bottom = self::g( $padding, 'bottom' );
		$left   = self::g( $padding, 'left' );
		$unit   = self::s( self::g( $padding, 'unit' ) );

		if ( ( ! self::t( $top ) || '' === $top ) && ( ! self::t( $bottom ) || '' === $bottom ) && ( ! self::t( $left ) || '' === $left ) && ( ! self::t( $right ) || '' === $right ) ) {
			return '';
		}

		$side = static function ( $value ) use ( $unit ) {
			return self::t( $value ) && '' !== $value && '0' !== $value ? self::s( $value ) . $unit : '0' . $unit;
		};

		// Every side is followed by a space except a zero left one - the editor's exact spacing.
		$left_css = self::t( $left ) && '' !== $left && '0' !== $left ? $side( $left ) . ' ' : $side( $left );

		return $prefix . 'padding' . $suffix . ': ' . $side( $top ) . ' ' . $side( $right ) . ' ' . $side( $bottom ) . ' ' . $left_css . $is_important . ';';
	}

	public static function border_radius( $border, $important = false, $global = null, $force = null ) {
		$is_important = $important ? ' !important' : '';
		$unit         = self::t( self::g( $border, 'radius_unit' ) ) ? self::s( self::g( $border, 'radius_unit' ) ) : 'px';
		$corners      = array( 'top-left', 'top-right', 'bottom-right', 'bottom-left' );

		$missing = true;

		foreach ( $corners as $corner ) {
			if ( BWFCRM_Email_Render_Js::has( $border, $corner ) ) {
				$missing = false;
			}
		}

		if ( self::t( $force ) && $missing ) {
			return 'border-radius: ' . self::s( $force ) . $is_important . ';';
		}

		$values = array();

		foreach ( $corners as $corner ) {
			$values[] = BWFCRM_Email_Render_Js::has( $border, $corner ) ? self::g( $border, $corner ) : ( self::t( $global ) ? self::g( $global, $corner ) : BWFCRM_Email_Render_Js::UNDEFINED );
		}

		if ( ! ( self::t( $values[0] ) || self::t( $values[1] ) || self::t( $values[2] ) || self::t( $values[3] ) ) ) {
			return '';
		}

		$parts = array_map(
			static function ( $value ) use ( $unit ) {
				return self::t( $value ) ? self::s( $value ) . $unit : '0';
			},
			$values
		);

		return 'border-radius: ' . implode( ' ', $parts ) . ' ' . $is_important . ';';
	}

	public static function border( $border, $important = false, $global = null, $radius_force = null ) {
		$unit         = self::t( self::g( $border, 'unit' ) ) ? self::s( self::g( $border, 'unit' ) ) : 'px';
		$radius       = self::border_radius( $border, $important, $global, $radius_force );
		$is_important = $important ? '! important' : '';
		$style_value  = self::t( self::g( $border, 'style' ) ) ? self::s( self::g( $border, 'style' ) ) : '';

		// The editor's own isEmpty() here means "has a width": neither '' nor '0'.
		$has_width = static function ( $value ) {
			return ! ( '' === $value || '0' === $value );
		};

		$top    = self::g( $border, 'top' );
		$right  = self::g( $border, 'right' );
		$bottom = self::g( $border, 'bottom' );
		$left   = self::g( $border, 'left' );

		$side_set = static function ( $value ) {
			return self::t( $value ) || 0.0 === (float) BWFCRM_Email_Render_Js::parse_float( $value ) && ! is_nan( BWFCRM_Email_Render_Js::parse_float( $value ) );
		};

		$any_width = $has_width( $bottom ) || $has_width( $top ) || $has_width( $right ) || $has_width( $left );

		$width_css = '';
		$style_css = '';

		if ( $side_set( $top ) && $side_set( $right ) && $side_set( $bottom ) && $side_set( $left ) ) {
			$width_css = 'border-width:' . self::s( self::shorthand( $top, $right, $bottom, $left, $unit ) ) . ' ' . $is_important . ';';
			$style_css = self::t( self::g( $border, 'style' ) ) && $any_width ? 'border-style:' . $style_value . ' ' . $is_important . ';' : '';
		} else {
			foreach ( array( 'top' => $top, 'right' => $right, 'bottom' => $bottom, 'left' => $left ) as $side => $value ) {
				if ( $side_set( $value ) ) {
					$width_css .= 'border-' . $side . '-width:' . self::s( $value ) . $unit . ' ' . $is_important . ';';
					$style_css .= '' !== $style_value ? 'border-' . $side . '-style:' . $style_value . ' ' . $is_important . ';' : '';
				}
			}
		}

		$style_css .= '' !== $style_value && '' === $style_css && $any_width ? 'border-style:' . $style_value . ' ' . $is_important . ';' : '';

		$ct = self::g( $border, 'color_top' );
		$cr = self::g( $border, 'color_right' );
		$cb = self::g( $border, 'color_bottom' );
		$cl = self::g( $border, 'color_left' );

		$color_css = '';

		if ( self::t( $ct ) && self::t( $cr ) && self::t( $cb ) && self::t( $cl ) ) {
			// The editor compares with ==, which for these strings is ===.
			if ( $ct === $cb && $ct === $cr && $ct === $cl ) {
				$color_css = 'border-color: ' . self::s( $ct ) . ' ' . $is_important . ';';
			} else {
				$color_css = 'border-color: ' . self::s( $ct ) . ' ' . self::s( $cr ) . ' ' . self::s( $cb ) . ' ' . self::s( $cl ) . ' ' . $is_important . ';';
			}
		}

		if ( '' === $color_css ) {
			foreach ( array( 'top' => $ct, 'right' => $cr, 'bottom' => $cb, 'left' => $cl ) as $side => $color ) {
				$color_css .= self::t( $color ) ? 'border-' . $side . '-color: ' . self::s( $color ) . ' ' . $is_important . ';' : '';
			}
		}

		return $width_css . $color_css . $style_css . $radius;
	}

	public static function typo( $typo = array(), $type = 'font', $skip = array() ) {
		if ( BWFCRM_Email_Render_Js::is_empty( $typo ) ) {
			return '';
		}

		$css  = '';
		$unit = self::g( $typo, 'sizeUnit' );

		foreach ( BWFCRM_Email_Render_Js::plain( $typo ) as $key => $value ) {
			$key = (string) $key;

			if ( 'sizeUnit' === $key || ( is_array( $skip ) && in_array( $key, $skip, true ) ) ) {
				continue;
			}

			if ( 'size' === $key ) {
				$css .= is_nan( (float) BWFCRM_Email_Render_Js::number( $value ) )
					? $type . '-' . $key . ': ' . self::s( $value ) . ';'
					: $type . '-' . $key . ': ' . self::s( $value ) . ( self::t( $unit ) ? self::s( $unit ) : 'px' ) . ';';
			} elseif ( 'shadow' === $key ) {
				$css .= $type . '-' . $key . ': ' . self::s( self::g( $value, 'x' ) ) . 'px ' . self::s( self::g( $value, 'y' ) ) . 'px ' . self::s( self::g( $value, 'blur' ) ) . 'px ' . self::s( self::g( $value, 'color' ) ) . ';';
			} else {
				$css .= $type . '-' . $key . ': ' . self::s( $value ) . ';';
			}
		}

		return $css;
	}

	public static function letter_spacing( $data, $selector = 'letter-spacing' ) {
		$value = self::g( $data, 'value' );

		return "\n\t" . ( self::t( $data ) && BWFCRM_Email_Render_Js::number( $value ) >= 0 && BWFCRM_Email_Render_Js::UNDEFINED !== $value
			? $selector . ':' . self::s( $value ) . ( self::t( self::g( $data, 'unit' ) ) ? self::s( self::g( $data, 'unit' ) ) : 'px' ) . ';'
			: '' );
	}

	public static function line_height( $line_height, $screen, $important = false ) {
		$value = BWFCRM_Email_Render_Js::get( $line_height, array( $screen, 'value' ) );

		if ( self::t( $line_height ) && self::t( self::g( $line_height, $screen ) ) && self::t( $value ) && '' !== $value ) {
			return 'line-height: ' . self::s( $value ) . ' ' . ( $important ? '!important' : '' ) . ';';
		}

		return 'desktop' === $screen ? 'line-height:1.5;' : '';
	}

	/**
	 * @param array  $attrs
	 * @param array  $keys { bold, italic, LH }
	 * @param string $screen
	 */
	public static function text( $attrs, $keys, $screen ) {
		$bold   = isset( $keys['bold'] ) ? $keys['bold'] : null;
		$italic = isset( $keys['italic'] ) ? $keys['italic'] : null;
		$lh     = array_key_exists( 'LH', $keys ) ? $keys['LH'] : 'lineHeight';
		$css    = '';

		if ( 'desktop' === $screen ) {
			if ( self::t( $bold ) ) {
				$css .= self::t( BWFCRM_Email_Render_Js::get( $attrs, array( $bold, $screen ) ) ) ? 'font-weight:600;' : '';
			}

			if ( self::t( $italic ) ) {
				$css .= self::t( BWFCRM_Email_Render_Js::get( $attrs, array( $italic, $screen ) ) ) ? 'font-style: italic;' : '';
			}
		}

		if ( self::t( $lh ) ) {
			$css .= self::line_height( self::g( $attrs, $lh ), $screen, 'mobile' === $screen );
		}

		return $css;
	}

	/** getCSSStyle({ attrs, key, property, screen }) */
	public static function style_of( $attrs, $key, $property, $screen = false ) {
		if ( ! self::t( $attrs ) || ! self::t( self::g( $attrs, $key ) ) ) {
			return '';
		}

		if ( false !== $screen && ! self::t( BWFCRM_Email_Render_Js::get( $attrs, array( $key, $screen ) ) ) ) {
			return '';
		}

		$value = false !== $screen ? BWFCRM_Email_Render_Js::get( $attrs, array( $key, $screen ) ) : self::g( $attrs, $key );

		return $property . ': ' . self::s( $value ) . ';';
	}

	/** getCSSStyleByVal({ css, screen, defaultVal, property }) */
	public static function style_by_value( $css, $screen, $default, $property ) {
		if ( ! self::t( $css ) ) {
			return '';
		}

		if ( false !== $screen && ! self::t( self::g( $css, $screen ) ) ) {
			return self::t( $default ) ? $property . ':' . self::s( $default ) : '';
		}

		if ( false === $screen ) {
			return $property . ':' . self::s( $css );
		}

		return $property . ': ' . self::s( self::g( $css, $screen ) ) . ';';
	}
}
