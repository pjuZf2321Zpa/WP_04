<?php

defined( 'ABSPATH' ) || exit;

/**
 * The handful of JavaScript and lodash behaviours the email renderer relies
 * on, reproduced in PHP.
 *
 * The block editor builds its email HTML with template strings, JavaScript
 * truthiness and lodash helpers. For the HTML rendered here to be the email
 * the editor would render, those have to behave the same way - including
 * where they are surprising: an empty object is truthy, a missing value prints
 * as "undefined", lodash's isEmpty(5) is true.
 */
final class BWFCRM_Email_Render_Js {

	/** JavaScript's undefined: what reading a missing key gives, as distinct from a stored null. */
	const UNDEFINED = "\0undefined\0";

	/** `if ( value )` */
	public static function truthy( $value ) {
		if ( self::UNDEFINED === $value || null === $value || false === $value ) {
			return false;
		}

		if ( is_int( $value ) ) {
			return 0 !== $value;
		}

		if ( is_float( $value ) ) {
			return 0.0 !== $value && ! is_nan( $value );
		}

		if ( is_string( $value ) ) {
			return '' !== $value;
		}

		// Arrays and objects, empty ones included.
		return true;
	}

	/** `value === 0` */
	public static function is_zero( $value ) {
		return 0 === $value || 0.0 === $value;
	}

	/**
	 * lodash get(): the value at a dotted path, or $default when the path does
	 * not resolve. A stored null is a value, as it is for lodash.
	 *
	 * @param mixed           $value
	 * @param string|string[] $path
	 * @param mixed           $default
	 *
	 * @return mixed
	 */
	public static function get( $value, $path, $default = self::UNDEFINED ) {
		$keys = is_array( $path ) ? $path : explode( '.', (string) $path );

		foreach ( $keys as $key ) {
			if ( is_object( $value ) ) {
				$value = get_object_vars( $value );
			}

			if ( ! is_array( $value ) || ! array_key_exists( $key, $value ) ) {
				return $default;
			}

			$value = $value[ $key ];
		}

		return $value;
	}

	/** `Object.prototype.hasOwnProperty.call( value, key )` */
	public static function has( $value, $key ) {
		if ( is_object( $value ) ) {
			$value = get_object_vars( $value );
		}

		return is_array( $value ) && array_key_exists( $key, $value );
	}

	/** lodash isEmpty(): true for null, '', [] and {} - and for every number and boolean. */
	public static function is_empty( $value ) {
		if ( self::UNDEFINED === $value || null === $value ) {
			return true;
		}

		if ( is_string( $value ) ) {
			return '' === $value;
		}

		if ( is_array( $value ) ) {
			return 0 === count( $value );
		}

		if ( is_object( $value ) ) {
			return 0 === count( get_object_vars( $value ) );
		}

		return true;
	}

	/** A value as a template string prints it: `${ value }`. */
	public static function str( $value ) {
		if ( self::UNDEFINED === $value ) {
			return 'undefined';
		}

		if ( null === $value ) {
			return 'null';
		}

		if ( true === $value ) {
			return 'true';
		}

		if ( false === $value ) {
			return 'false';
		}

		if ( is_int( $value ) ) {
			return (string) $value;
		}

		if ( is_float( $value ) ) {
			return self::number_to_string( $value );
		}

		if ( is_string( $value ) ) {
			return $value;
		}

		if ( is_object( $value ) ) {
			return '[object Object]';
		}

		if ( is_array( $value ) ) {
			if ( array() !== $value && array_keys( $value ) !== range( 0, count( $value ) - 1 ) ) {
				return '[object Object]';
			}

			// Array#join: null and undefined print as nothing.
			return implode(
				',',
				array_map(
					static function ( $item ) {
						return null === $item || self::UNDEFINED === $item ? '' : self::str( $item );
					},
					$value
				)
			);
		}

		return (string) $value;
	}

	/** Number#toString. */
	public static function number_to_string( $value ) {
		$value = (float) $value;

		if ( is_nan( $value ) ) {
			return 'NaN';
		}

		if ( is_infinite( $value ) ) {
			return $value > 0 ? 'Infinity' : '-Infinity';
		}

		if ( floor( $value ) === $value && abs( $value ) < 1e21 ) {
			return 0.0 === $value ? '0' : sprintf( '%.0f', $value );
		}

		// The shortest digits that read back as the same number - what JavaScript prints.
		for ( $precision = 1; $precision <= 17; $precision++ ) {
			// %g follows LC_NUMERIC (a comma under de_DE); JavaScript always prints a point.
			$candidate = str_replace( ',', '.', sprintf( '%.' . $precision . 'g', $value ) );

			if ( (float) $candidate === $value ) {
				if ( false === stripos( $candidate, 'e' ) ) {
					return $candidate;
				}

				break;
			}
		}

		return rtrim( rtrim( sprintf( '%.17F', $value ), '0' ), '.' );
	}

	/** parseFloat( String( value ) ) */
	public static function parse_float( $value ) {
		$string = ltrim( self::str( $value ) );

		if ( preg_match( '/^[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?/', $string, $match ) ) {
			return (float) $match[0];
		}

		if ( preg_match( '/^([+-]?)Infinity/', $string, $match ) ) {
			return '-' === $match[1] ? -INF : INF;
		}

		return NAN;
	}

	/** parseInt( String( value ), 10 ), NaN included. */
	public static function parse_int( $value ) {
		$string = ltrim( self::str( $value ) );

		if ( preg_match( '/^[+-]?\d+/', $string, $match ) ) {
			return (int) $match[0];
		}

		return NAN;
	}

	/** Number( value ) */
	public static function number( $value ) {
		if ( self::UNDEFINED === $value ) {
			return NAN;
		}

		if ( null === $value || false === $value ) {
			return 0;
		}

		if ( true === $value ) {
			return 1;
		}

		if ( is_int( $value ) || is_float( $value ) ) {
			return $value;
		}

		if ( is_string( $value ) ) {
			$trimmed = trim( $value );

			if ( '' === $trimmed ) {
				return 0;
			}

			if ( is_numeric( $trimmed ) ) {
				return $trimmed + 0;
			}

			return NAN;
		}

		if ( is_array( $value ) && 0 === count( $value ) ) {
			return 0;
		}

		if ( is_array( $value ) && 1 === count( $value ) && array_keys( $value ) === array( 0 ) ) {
			return self::number( $value[0] );
		}

		return NAN;
	}

	/** `a + b`: concatenation when either side is a string, addition otherwise. */
	public static function plus( $a, $b ) {
		if ( is_string( $a ) || is_string( $b ) || is_array( $a ) || is_array( $b ) || is_object( $a ) || is_object( $b ) || self::UNDEFINED === $a || self::UNDEFINED === $b ) {
			// undefined + number is NaN, not a string - but no renderer path adds those.
			return self::str( $a ) . self::str( $b );
		}

		return self::number( $a ) + self::number( $b );
	}

	/**
	 * The browser's global escape() - percent-encoding, not an HTML escape:
	 * letters, digits and @*_+-./ stay; any other UTF-16 code unit below 256
	 * becomes %XX, the rest %uXXXX. The editor encodes dynamic blocks' settings
	 * and conditional content with it, and send time decodes exactly this form.
	 *
	 * @param string $value UTF-8.
	 *
	 * @return string
	 */
	public static function url_escape( $value ) {
		$units = unpack( 'n*', (string) mb_convert_encoding( self::str( $value ), 'UTF-16BE', 'UTF-8' ) );
		$out   = '';

		foreach ( $units ? $units : array() as $unit ) {
			if ( $unit < 128 && 1 === preg_match( '/^[A-Za-z0-9@*_+\-.\/]$/', chr( $unit ) ) ) {
				$out .= chr( $unit );
			} elseif ( $unit < 256 ) {
				$out .= sprintf( '%%%02X', $unit );
			} else {
				$out .= sprintf( '%%u%04X', $unit );
			}
		}

		return $out;
	}

	/** lodash escape(). */
	public static function escape( $value ) {
		return strtr(
			self::str( $value ),
			array(
				'&'  => '&amp;',
				'<'  => '&lt;',
				'>'  => '&gt;',
				'"'  => '&quot;',
				"'"  => '&#39;',
			)
		);
	}

	/**
	 * JSON.stringify(): slashes and non-ASCII left as they are, and a whole
	 * number written without a fraction (1, not 1.0).
	 *
	 * @param mixed $value Arrays for lists and maps, stdClass for objects that may be empty.
	 *
	 * @return string
	 */
	public static function json( $value ) {
		return (string) wp_json_encode( self::json_numbers( $value ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_LINE_TERMINATORS );
	}

	private static function json_numbers( $value ) {
		if ( is_float( $value ) && is_finite( $value ) && floor( $value ) === $value && abs( $value ) < 9007199254740992 ) {
			return (int) $value;
		}

		if ( is_array( $value ) ) {
			foreach ( $value as $key => $item ) {
				$value[ $key ] = self::json_numbers( $item );
			}

			return $value;
		}

		if ( is_object( $value ) ) {
			$copy = new stdClass();

			foreach ( get_object_vars( $value ) as $key => $item ) {
				$copy->$key = self::json_numbers( $item );
			}

			return $copy;
		}

		return $value;
	}

	/** A decoded attribute value with its objects as arrays, for reading. */
	public static function plain( $value ) {
		if ( is_object( $value ) ) {
			$value = get_object_vars( $value );
		}

		if ( is_array( $value ) ) {
			foreach ( $value as $key => $item ) {
				$value[ $key ] = self::plain( $item );
			}
		}

		return $value;
	}
}
