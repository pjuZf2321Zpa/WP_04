<?php

defined( 'ABSPATH' ) || exit;

/**
 * Renders a block-editor email design to the HTML the email editor saves for
 * it - the document stored as a template's body and sent, after send time has
 * swapped in Global Style values, dynamic blocks and merge tags.
 *
 * It follows the editor's own pipeline step for step: each block renders its
 * HTML and its CSS; the CSS is inlined into that block's HTML (the block's
 * children already carry theirs); the @media rules are kept aside by block;
 * then everything is wrapped in the email document with the collected media
 * rules in its stylesheet. Parity with the editor is checked against HTML the
 * editor itself rendered (tests/email-design).
 */
final class BWFCRM_Email_Renderer {

	/** Blocks with a renderer of their own; everything else renders nothing, as in the editor. */
	const BLOCKS = array(
		'email-block/row'           => 'BWFCRM_Email_Block_Row',
		'email-block/section'       => 'BWFCRM_Email_Block_Section',
		'email-block/column'        => 'BWFCRM_Email_Block_Column',
		'email-block/text'          => 'BWFCRM_Email_Block_Text',
		'email-block/button'        => 'BWFCRM_Email_Block_Button',
		'email-block/image'         => 'BWFCRM_Email_Block_Image',
		'email-block/list'          => 'BWFCRM_Email_Block_List',
		'email-block/menu'          => 'BWFCRM_Email_Block_Menu',
		'email-block/social'        => 'BWFCRM_Email_Block_Social',
		'email-block/space-divider' => 'BWFCRM_Email_Block_Space_Divider',
		'email-block/html'          => 'BWFCRM_Email_Block_Html',
		'email-block/site-logo'     => 'BWFCRM_Email_Block_Site_Logo',
		'email-block/footer'        => 'BWFCRM_Email_Block_Footer',

		// Dynamic blocks: filled in at send time from the order, cart or store; saved as shortcodes.
		'email-block/cart-items'               => 'BWFCRM_Email_Block_Cart_Items',
		'email-block/cart-link'                => 'BWFCRM_Email_Block_Cart_Link',
		'email-block/coupon'                   => 'BWFCRM_Email_Block_Coupon',
		'email-block/best-selling-product'     => 'BWFCRM_Email_Block_Best_Selling_Product',
		'email-block/orders-summary'           => 'BWFCRM_Email_Block_Orders_Summary',
		'email-block/billing-shipping-address' => 'BWFCRM_Email_Block_Billing_Shipping_Address',
		'email-block/customer-note'            => 'BWFCRM_Email_Block_Customer_Note',
		'email-block/downloads'                => 'BWFCRM_Email_Block_Downloads',
		'email-block/subscription-items'       => 'BWFCRM_Email_Block_Subscription_Items',
		'email-block/subscription-info'        => 'BWFCRM_Email_Block_Subscription_Info',
		'email-block/payment-schedule'         => 'BWFCRM_Email_Block_Payment_Schedule',
	);

	/**
	 * @param array[] $tree     The design, as BWFCRM_Email_Design_Tree reads and completes it.
	 * @param array   $settings The email's settings (block.settings).
	 * @param array   $options  { site: array block editor site settings, rtl: bool, google_fonts: string[] }
	 *
	 * @return string|WP_Error The email document.
	 */
	public static function render( array $tree, array $settings = array(), array $options = array() ) {
		self::load();

		if ( ! BWFCRM_Email_Render_Inliner::available() ) {
			return new WP_Error( 'fkmcp_renderer_unavailable', 'The email renderer needs the CSS selector library bundled with FunnelKit Automations.' );
		}

		$context = BWFCRM_Email_Render_Context::create( $settings, isset( $options['site'] ) ? $options['site'] : null, $options );
		$tree    = self::mark_background_images( BWFCRM_Email_Render_Js::plain( BWFCRM_Email_Design_Tree::complete( $tree, $settings ) ) );

		$family = BWFCRM_Email_Render_Js::get( $context->global, 'font.desktop.family' );

		if ( BWFCRM_Email_Render_Js::truthy( $family ) ) {
			$context->fonts[] = $family;
		}

		$styles = array();
		$html   = '';

		foreach ( $tree as $block ) {
			$html .= self::render_block( $block, $styles, $context, false );
		}

		$style = self::email_global_style( implode( '', self::object_values( $styles ) ) );

		return self::document( $html, $style, self::font_links( $context ), $context );
	}

	/**
	 * getEditorData(): in a section with a background image, every column and
	 * content block learns it (rowHasBgImage), added after its attributes.
	 */
	private static function mark_background_images( array $tree ) {
		foreach ( $tree as $r => $row ) {
			foreach ( isset( $row['innerBlocks'] ) ? (array) $row['innerBlocks'] : array() as $s => $section ) {
				$url = BWFCRM_Email_Render_Js::get( isset( $section['attrs'] ) ? $section['attrs'] : array(), 'contentBackground.desktop.image.url' );

				if ( BWFCRM_Email_Render_Js::is_empty( $url ) ) {
					continue;
				}

				foreach ( isset( $section['innerBlocks'] ) ? (array) $section['innerBlocks'] : array() as $c => $column ) {
					$tree[ $r ]['innerBlocks'][ $s ]['innerBlocks'][ $c ]['attrs']['rowHasBgImage'] = true;

					foreach ( isset( $column['innerBlocks'] ) ? (array) $column['innerBlocks'] : array() as $b => $content ) {
						$tree[ $r ]['innerBlocks'][ $s ]['innerBlocks'][ $c ]['innerBlocks'][ $b ]['attrs']['rowHasBgImage'] = true;
					}
				}
			}
		}

		return $tree;
	}

	/**
	 * A dynamic block's shortcode, as the editor writes it while saving: the
	 * block's attributes and the email's global settings as JSON, percent-encoded
	 * (the browser's escape()), between the tags. Send time decodes and renders it.
	 *
	 * The attributes are the block's as the editor holds them: every default, the
	 * block's own order, then keys the block's edit sets when it mounts
	 * ($runtime, e.g. hasWCChildSelected), then rowHasBgImage where the section
	 * has a background image, then `global`.
	 *
	 * @param string                      $tag             Shortcode tag, e.g. bwfbe_cart_items.
	 * @param array                       $block
	 * @param BWFCRM_Email_Render_Context $context
	 * @param string                      $open_attributes Extra text after the tag name, e.g. ' type="best_selling_products"'.
	 * @param array                       $runtime         Keys the edit adds on mount, in the order it adds them.
	 *
	 * @return string
	 */
	public static function dynamic_shortcode( $tag, array $block, BWFCRM_Email_Render_Context $context, $open_attributes = '', array $runtime = array() ) {
		$given = $block['attrs'];
		$bg    = array_key_exists( 'rowHasBgImage', $given ) ? array( 'rowHasBgImage' => $given['rowHasBgImage'] ) : array();

		unset( $given['rowHasBgImage'] );

		$attrs           = BWFCRM_Email_Design_Tree::runtime_attributes( $block['name'], $given );
		$attrs           = array_merge( $attrs, array_diff_key( $runtime, $attrs ), $bg );
		$attrs['global'] = (object) self::runtime_global( $context );

		return '[' . $tag . $open_attributes . ']' . BWFCRM_Email_Render_Js::url_escape( BWFCRM_Email_Render_Js::json( (object) $attrs ) ) . '[/' . $tag . ']';
	}

	/**
	 * The global settings as the editor holds them: objects, except that a
	 * setting the site stores as an empty list arrives - and stays - [].
	 */
	public static function runtime_global( BWFCRM_Email_Render_Context $context ) {
		$global = BWFCRM_Email_Design_Tree::runtime_settings( $context->global );
		$site   = isset( $context->site['setting'] ) && is_array( $context->site['setting'] ) ? $context->site['setting'] : array();

		foreach ( $global as $key => $value ) {
			// An email's own settings replace only the settings it may override.
			$overridden = in_array( $key, BWFCRM_Email_Render_Context::OVERRIDABLE, true ) && $context->template_has( $key );

			if ( $value instanceof stdClass && array() === get_object_vars( $value ) && array_key_exists( $key, $site ) && array() === $site[ $key ] && ! $overridden ) {
				$global[ $key ] = array();
			}
		}

		return $global;
	}

	/** Loads the renderer's classes; only rendering needs them. */
	public static function load() {
		$dir = __DIR__;

		require_once $dir . '/class-bwfcrm-email-render-js.php';
		require_once $dir . '/class-bwfcrm-email-render-css.php';
		require_once $dir . '/class-bwfcrm-email-render-context.php';
		require_once $dir . '/class-bwfcrm-email-render-inliner.php';
		require_once $dir . '/blocks/class-bwfcrm-email-block.php';

		foreach ( self::BLOCKS as $name => $class ) {
			$file = $dir . '/blocks/class-' . strtolower( str_replace( '_', '-', $class ) ) . '.php';

			if ( is_readable( $file ) ) {
				require_once $file;
			}
		}
	}

	/**
	 * One block, its children first - renderBlock().
	 *
	 * @param array                        $block      { name, attrs, innerBlocks }
	 * @param array                        $styles     uniqueID => the block's @media CSS, gathered for the stylesheet.
	 * @param BWFCRM_Email_Render_Context  $context
	 * @param bool                         $responsive Whether the parent section stacks its columns on mobile.
	 *
	 * @return string
	 */
	public static function render_block( array $block, array &$styles, BWFCRM_Email_Render_Context $context, $responsive ) {
		$name  = isset( $block['name'] ) ? $block['name'] : '';
		$class = isset( self::BLOCKS[ $name ] ) ? self::BLOCKS[ $name ] : null;

		if ( null === $class || ! class_exists( $class ) ) {
			return '';
		}

		// The editor renders from the block as parsed, every default filled in.
		$block['attrs']       = BWFCRM_Email_Design_Tree::with_defaults( $name, isset( $block['attrs'] ) ? (array) $block['attrs'] : array() );
		$block['innerBlocks'] = isset( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ? array_values( $block['innerBlocks'] ) : array();

		$attrs     = $block['attrs'];
		$unique_id = BWFCRM_Email_Render_Js::get( $attrs, 'uniqueID' );
		$is_hidden = BWFCRM_Email_Render_Js::get( $attrs, 'isHidden' );
		$col_gap   = BWFCRM_Email_Render_Js::get( $attrs, 'colGap' );
		$rules     = BWFCRM_Email_Render_Js::get( $attrs, 'conditional.rules', array() );
		$children  = $block['innerBlocks'];
		$sectioned = 'email-block/section' === $name && count( $children ) > 1;
		$stacks    = 'email-block/section' === $name && BWFCRM_Email_Render_Js::truthy( BWFCRM_Email_Render_Js::get( $attrs, 'responsive' ) );

		self::collect_fonts( $block, $context );

		$css = '';

		if ( BWFCRM_Email_Render_Js::truthy( $unique_id ) ) {
			$css = call_user_func( array( $class, 'style' ), $block, $context );

			if ( $sectioned && BWFCRM_Email_Render_Js::truthy( BWFCRM_Email_Render_Js::get( $col_gap, 'desktop.value' ) ) ) {
				$css .= self::gap_css( $col_gap, $unique_id, $stacks );
			}
		}

		$inner = '';

		foreach ( $children as $index => $child ) {
			$gap_value = BWFCRM_Email_Render_Js::get( $col_gap, 'desktop.value' );

			if ( BWFCRM_Email_Render_Js::UNDEFINED === $gap_value || null === $gap_value ) {
				$gap_value = BWFCRM_Email_Render_Js::get( $col_gap, 'mobile.value' );
			}

			if ( $sectioned && 0 !== $index && BWFCRM_Email_Render_Js::truthy( $gap_value ) ) {
				$inner .= self::gap_html(
					BWFCRM_Email_Render_Js::truthy( BWFCRM_Email_Render_Js::get( $col_gap, 'desktop.value' ) ) ? BWFCRM_Email_Render_Js::get( $col_gap, 'desktop.value' ) : 0,
					$unique_id,
					$stacks
				);
			}

			$inner .= self::render_block( $child, $styles, $context, $stacks );
		}

		$hidden = BWFCRM_Email_Render_Js::truthy( $is_hidden ) && BWFCRM_Email_Render_Js::truthy( BWFCRM_Email_Render_Js::get( $is_hidden, 'desktop' ) );
		$html   = ( $hidden ? '<!--[if !mso]><!-->' : '' )
			. call_user_func( array( $class, 'html' ), $block, $inner, $context, $responsive )
			. ( $hidden ? '<!--<![endif]-->' : '' );

		$inlined = BWFCRM_Email_Render_Inliner::inline( $html, self::email_global_style( $css ) );

		if ( BWFCRM_Email_Render_Js::truthy( $unique_id ) ) {
			$styles[ BWFCRM_Email_Render_Js::str( $unique_id ) ] = '' !== $inlined['preserved'] ? "\n\n" . $inlined['preserved'] : '';
		}

		$out = $inlined['html'];

		if ( is_array( $rules ) && ! empty( $rules ) ) {
			$out = self::visibility_wrap( $rules, $out );
		}

		return $out;
	}

	/**
	 * Conditional content: the block travels as data inside a wrapper send time
	 * turns into the visibility shortcode (rules evaluated per recipient). Both
	 * the rules and the block are JSON, percent-encoded as the editor encodes them.
	 */
	private static function visibility_wrap( array $rules, $html ) {
		return '<bwfan_email_block_visibility rules="' . BWFCRM_Email_Render_Js::url_escape( BWFCRM_Email_Render_Js::json( $rules ) ) . '" data-bwf-visibility="true">'
			. BWFCRM_Email_Render_Js::url_escape( BWFCRM_Email_Render_Js::json( self::escape_html( $html ) ) )
			. '</bwfan_email_block_visibility>';
	}

	/** @wordpress/escape-html escapeHTML(): & (unless already an entity) and <. */
	public static function escape_html( $value ) {
		$value = preg_replace( '/&(?!([a-z0-9]+|#[0-9]+|#x[a-f0-9]+);)/i', '&amp;', (string) $value );

		return str_replace( '<', '&lt;', $value );
	}

	/**
	 * A value for a double-quoted attribute in markup built by hand, as the editor's template
	 * strings build it: only what could end the attribute or an Outlook comment is escaped,
	 * so an editor-made value (a colour, a width, url('…') with a query string) prints as it is.
	 */
	public static function attr( $value ) {
		return str_replace( array( '"', '<', '>' ), array( '&quot;', '&lt;', '&gt;' ), (string) $value );
	}

	/** Object.values() on the editor's style map: integer-like keys first, ascending, then the rest in insertion order. */
	private static function object_values( array $map ) {
		$numeric = array();
		$other   = array();

		foreach ( $map as $key => $value ) {
			$key = (string) $key;

			if ( preg_match( '/^(0|[1-9]\d{0,9})$/', $key ) && (float) $key < 4294967295 ) {
				$numeric[ (int) $key ] = $value;
			} else {
				$other[] = $value;
			}
		}

		ksort( $numeric );

		return array_merge( array_values( $numeric ), $other );
	}

	// ─── the pieces around the blocks ───────────────────────────────

	/** emailGlobalStyle(): the rules every block's CSS is inlined with. */
	public static function email_global_style( $misc = '' ) {
		return "p { margin: 0; } img {line-height: 100%;} td > img { pointer-events:none !important; } .screen-reader-text { display: none; }\n\t" . $misc;
	}

	/** GapHTML: the spacer cell between two columns. */
	public static function gap_html( $col_gap, $unique_id, $responsive ) {
		$gap   = self::attr( BWFCRM_Email_Render_Js::str( $col_gap ) );
		$id    = self::attr( BWFCRM_Email_Render_Js::str( $unique_id ) );
		$table = self::element(
			'table',
			self::table_props( array( 'width' => $col_gap ), true ),
			'<tbody><tr><td></td></tr></tbody>'
		);

		if ( ! $responsive ) {
			return '<td class="bwfbe-section-gap-' . $id . '">' . $table . '</td>';
		}

		// valign="top> lacks its closing quote in the editor's own markup too; kept for parity.
		return '<!--[if mso | IE]><td style="width: ' . $gap . 'px;vertical-align:top;" valign="top><![endif]-->'
			. "<div\n\t\t\t\t\tstyle=\"font-size:0;vertical-align:top;display:table-cell;width:" . $gap . "px;\"\n\t\t\t\t\tclass=\"bwfbe-section-gap-" . $id . '"' . "\n\t\t\t\t>"
			. $table
			. '</div><!--[if mso | IE]></td><![endif]-->';
	}

	/** GapCSS: the spacer on mobile. */
	public static function gap_css( $col_gap, $unique_id, $responsive ) {
		$mobile  = BWFCRM_Email_Render_Js::get( $col_gap, 'mobile.value' );
		$desktop = BWFCRM_Email_Render_Js::get( $col_gap, 'desktop.value' );
		$prop    = $responsive ? 'height' : 'width';
		$id      = BWFCRM_Email_Render_Js::str( $unique_id );

		if ( BWFCRM_Email_Render_Js::truthy( $col_gap ) && BWFCRM_Email_Render_Js::truthy( BWFCRM_Email_Render_Js::get( $col_gap, 'mobile' ) ) && BWFCRM_Email_Render_Js::truthy( $mobile ) ) {
			$size = $prop . ': ' . BWFCRM_Email_Render_Js::str( $mobile ) . 'px !important;';
		} elseif ( BWFCRM_Email_Render_Js::truthy( $col_gap ) && BWFCRM_Email_Render_Js::truthy( BWFCRM_Email_Render_Js::get( $col_gap, 'desktop' ) ) && BWFCRM_Email_Render_Js::truthy( $desktop ) ) {
			$size = $prop . ': ' . BWFCRM_Email_Render_Js::str( $desktop ) . 'px !important;;';
		} else {
			$size = '';
		}

		return '@media only screen and (max-width: 768px) {
				.bwfbe-section-gap-' . $id . ', .bwfbe-section-gap-' . $id . ' > table {
					' . $size . '
					' . ( $responsive ? 'width: 100% !important;' : '' ) . '
				}
			}
			';
	}

	/** The email document around the rendered blocks - rawDOM(). */
	private static function document( $body, $style, $fonts, BWFCRM_Email_Render_Context $context ) {
		$background = $context->uses_variable( 'background' )
			? array( 'background' => 'var(--bwfbe-background-desktop-color)' )
			: self::css_string_to_obj( BWFCRM_Email_Render_Css::background( BWFCRM_Email_Render_Js::get( $context->global, 'background.desktop' ) ) );

		$body_style = array_merge(
			array(
				'padding'                  => 0,
				'margin'                   => 0,
				'-webkit-text-size-adjust' => '100%',
			),
			$background,
			array( 'direction' => $context->rtl ? 'rtl' : 'ltr' )
		);

		$stylesheet = self::minify_media_query(
			self::minify_css(
				'
							table {
								clear: both;
							}
							table, tr, td {
								border-collapse: collapse;
								mso-table-lspace: 0pt;
								mso-table-rspace: 0pt;
								border-spacing: 0px;
							}
							a.bwf-menu-item {
								text-decoration: none;
							}
							@media only screen and (max-width: 768px) {
								.bwfbe-block-section,
								.bwfbe-block-section .bwfbe-block-section-outer-container {
									width: 100% !important;
								}
								.bwf-email-inner-column-wrapper.is-responsive {
									width: 100% !important;
									display:inline-block !important;
									box-sizing: border-box;
								}
							}
							' . $style . '
						 '
			)
		);

		return '<html xmlns="http://www.w3.org/1999/xhtml"' . ( $context->rtl ? ' dir="rtl"' : '' ) . '><head>'
			. '<!--[if gte mso 9]><xml><o:officeDocumentSettings><o:allowPNG></o:allowPNG><o:pixelsPerInch>96</o:pixelsPerInch></o:officeDocumentSettings></xml><![endif]-->'
			. '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>'
			. '<meta name="viewport" content="width=device-width, initial-scale=1.0"/>'
			. '<meta name="x-apple-disable-message-reformatting"/>'
			. '<!--[if !mso]><meta http-equiv="X-UA-Compatible" content="IE=edge"/><![endif]-->'
			. $fonts
			. '<title></title>'
			. '<!--[if (gte mso 9)|(IE)]><style>ul li { mso-special-format: bullet; }</style><![endif]-->'
			// No CSS needs "<"; escaped as CSS, a value can never close the tag (</style>).
			. '<style id="email-stylesheet" type="text/css">' . str_replace( '<', '\\3c ', $stylesheet ) . '</style>'
			. '</head>'
			. '<body style="' . esc_attr( self::style_attr( $body_style ) ) . '">'
			. '<div style="' . esc_attr( self::style_attr( $background ) ) . '">' . $body . '</div>'
			. '</body></html>';
	}

	/** Font links for the Google and custom fonts the email uses - createFontLinks(). */
	private static function font_links( BWFCRM_Email_Render_Context $context ) {
		$links = '';

		foreach ( array_unique( $context->fonts ) as $font ) {
			if ( in_array( $font, $context->google_fonts, true ) ) {
				$links .= '<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=' . str_replace( ' ', '+', $font ) . '" id="bwfblock-google-fonts"  />';
			}
		}

		return $links;
	}

	/** includeFontsInHTML(): every font family a block's attributes name. */
	private static function collect_fonts( array $block, BWFCRM_Email_Render_Context $context ) {
		foreach ( (array) $block['attrs'] as $key => $value ) {
			if ( ! preg_match( '/font/i', (string) $key ) ) {
				continue;
			}

			$family = BWFCRM_Email_Render_Js::get( $value, 'desktop.family' );

			if ( is_string( $family ) && '' !== $family && ! in_array( $family, $context->fonts, true ) ) {
				$context->fonts[] = $family;
			}
		}
	}

	// ─── CSS utilities ──────────────────────────────────────────────

	/** minifyCSS() */
	public static function minify_css( $css, $important = false ) {
		$css = preg_replace( '#/\*.*?\*/#', '', (string) $css );
		$css = preg_replace( '/\n\s*\n/', '', $css );
		$css = preg_replace( '/[\n\r \t]/', ' ', $css );
		$css = preg_replace( '/ +/', ' ', $css );
		$css = preg_replace( '/ ?([,:;{}]) ?/', '$1', $css );
		$css = preg_replace( '/[^\}\{]+\{\}/', '', $css );
		$css = preg_replace( '/[^\}\{]+\{\}/', '', $css );
		$css = str_replace( ';}', '}', $css );
		$css = str_replace( '{{', '{ {', $css );
		$css = str_replace( '}}', '} }', $css );
		$css = trim( $css );

		if ( ! $important ) {
			return $css;
		}

		$css = preg_replace( '/\s?\!important/', '', $css );
		$css = preg_replace( '/([;\}])/', ' !important$1', $css );
		$css = str_replace( '} !important}', '}}', $css );

		return trim( $css );
	}

	/** minifyMediaQuery(): one block per media query, merged in the order first seen. */
	public static function minify_media_query( $css ) {
		$pattern = '/@media[^{]+\{([\s\S]+?\})\s*\}/';

		if ( ! preg_match_all( $pattern, $css, $matches ) ) {
			return $css;
		}

		$default = trim( preg_replace( $pattern, '', $css ) );
		$merged  = array();

		foreach ( $matches[0] as $media ) {
			if ( ! preg_match( '/@media[^{]+\{/', $media, $query ) || ! preg_match( '/\{([\s\S]+)\}$/', $media, $rules ) ) {
				continue;
			}

			$query = trim( $query[0] );
			$rules = trim( $rules[1] );

			$merged[ $query ] = isset( $merged[ $query ] ) ? $merged[ $query ] . ' ' . $rules : $rules;
		}

		$parts = array();

		foreach ( $merged as $query => $rules ) {
			$parts[] = $query . ' ' . $rules . ' }';
		}

		return trim( $default . ' ' . implode( ' ', $parts ) );
	}

	/** GlobalCssPreview(): a Global Style value, as its CSS variable while saving. */
	public static function global_css( $globals, $attr, $screen, $sub = '', $important = false, $context = null ) {
		$apply_var = null === $context || $context->saving;
		$value_of  = static function ( $value ) use ( $apply_var, $attr, $screen, $sub ) {
			return $apply_var ? 'var(--bwfbe-' . $attr . '-' . $screen . ( ! BWFCRM_Email_Render_Js::is_empty( $sub ) ? '-' . BWFCRM_Email_Render_Js::str( $sub ) : '' ) . ')' : BWFCRM_Email_Render_Js::str( $value );
		};

		$is_important = $important ? ' ! important' : '';
		$setting      = BWFCRM_Email_Render_Js::get( $globals, array( $attr, $screen ) );

		$exists = BWFCRM_Email_Render_Js::truthy( BWFCRM_Email_Render_Js::get( $globals, array( (string) $attr ) ) )
			&& BWFCRM_Email_Render_Js::truthy( $setting )
			&& ( '' !== $sub ? BWFCRM_Email_Render_Js::has( $setting, BWFCRM_Email_Render_Js::str( $sub ) ) && '' !== BWFCRM_Email_Render_Js::get( $setting, array( BWFCRM_Email_Render_Js::str( $sub ) ) ) : true );

		if ( ! $exists ) {
			return '';
		}

		$inner = '' !== $sub ? BWFCRM_Email_Render_Js::get( $setting, array( BWFCRM_Email_Render_Js::str( $sub ) ) ) : $setting;

		switch ( $attr ) {
			case 'buttonColor':
			case 'color':
			case 'linkColor':
			case 'colorH1':
			case 'colorH2':
			case 'colorH3':
			case 'colorH4':
			case 'colorH5':
			case 'colorH6':
				return 'desktop' === $screen ? 'color: ' . $value_of( $setting ) . $is_important . ';' : '';

			case 'buttonFont':
			case 'font':
			case 'fontH1':
			case 'fontH2':
			case 'fontH3':
			case 'fontH4':
			case 'fontH5':
			case 'fontH6':
				if ( 'size' === $sub ) {
					return 'font-' . $sub . ': ' . $value_of( BWFCRM_Email_Render_Js::str( $inner ) . 'px' ) . $is_important . ';';
				}

				if ( 'desktop' === $screen ) {
					if ( 'family' === $sub ) {
						$family = null === $inner || BWFCRM_Email_Render_Js::UNDEFINED === $inner ? 'Arial, helvetica, sans-serif' : BWFCRM_Email_Render_Js::str( $inner );

						return 'font-' . $sub . ': ' . $value_of( $family . self::backup_font( $globals, $inner, $context ) ) . ' ' . $is_important . ';';
					}

					return 'font-' . BWFCRM_Email_Render_Js::str( $sub ) . ': ' . $value_of( $inner ) . $is_important . ';';
				}

				return '';

			case 'linkLineType':
				return 'desktop' === $screen ? 'text-decoration-line: ' . $value_of( $setting ) . $is_important . ';' : '';

			case 'linkLineColor':
				return 'desktop' === $screen ? 'text-decoration-color: ' . $value_of( $setting ) . $is_important . ';' : '';

			case 'buttonBackground':
				return 'desktop' === $screen ? 'background-color: ' . $value_of( BWFCRM_Email_Render_Js::get( $setting, 'color' ) ) . $is_important . ';' : '';
		}

		return '';
	}

	/** getBackupFont(): the Global Style's backup font, after a web font. */
	public static function backup_font( $globals, $family, $context = null ) {
		$backup = BWFCRM_Email_Render_Js::get( $globals, 'backupFont.desktop.family' );

		if ( ! BWFCRM_Email_Render_Js::truthy( $backup ) || ! is_string( $family ) ) {
			return '';
		}

		$without = str_replace( $backup, '', $family );
		$name    = '' !== $without ? $without : $family;
		$fonts   = null !== $context ? $context->google_fonts : array();

		return in_array( $name, $fonts, true ) ? ',' . $backup : '';
	}

	/** getVisibilityCss(): hiding a block on desktop or mobile. */
	public static function visibility_css( $selector, array $block, $screen ) {
		$hidden = BWFCRM_Email_Render_Js::get( $block['attrs'], 'isHidden' );
		$name   = $block['name'];
		$css    = '';

		if ( 'desktop' === $screen ) {
			if ( BWFCRM_Email_Render_Js::truthy( BWFCRM_Email_Render_Js::get( $hidden, array( $screen ) ) ) ) {
				$css .= '
			display: none;
			mso-hide: all;
			max-height: 0px;
			overflow: hidden;
		';
			}
		} elseif ( BWFCRM_Email_Render_Js::truthy( BWFCRM_Email_Render_Js::get( $hidden, array( $screen ) ) ) ) {
			$css .= '
				display: none !important;
				mso-hide: all !important;
				max-height: 0px !important;
				overflow: hidden !important;
			';
		} elseif ( BWFCRM_Email_Render_Js::truthy( BWFCRM_Email_Render_Js::get( $hidden, 'desktop' ) ) ) {
			if ( 'email-block/row' === $name || 'email-block/section' === $name ) {
				$css .= 'display: table !important;';
			} elseif ( 'email-block/column' !== $name ) {
				$css .= 'display: table-cell !important;';
			}

			$css .= 'mso-hide: unset !important;';
			$css .= '
					max-height: unset !important;
					overflow: unset !important;
				';
		}

		return '
		' . $selector . ' {
			' . $css . '
		}
	';
	}

	/** cssStringToObj() */
	public static function css_string_to_obj( $css ) {
		$out = array();

		if ( ! BWFCRM_Email_Render_Js::truthy( $css ) ) {
			return $out;
		}

		foreach ( explode( ';', $css ) as $style ) {
			$parts = explode( ':', $style );

			if ( 2 === count( $parts ) ) {
				$out[ $parts[0] ] = $parts[1];
			}
		}

		return $out;
	}

	// ─── HTML the way @wordpress/element writes it ──────────────────

	const UNITLESS = array( 'animation', 'animationIterationCount', 'baselineShift', 'borderImageOutset', 'borderImageSlice', 'borderImageWidth', 'columnCount', 'cx', 'cy', 'fillOpacity', 'flexGrow', 'flexShrink', 'floodOpacity', 'fontWeight', 'gridColumnEnd', 'gridColumnStart', 'gridRowEnd', 'gridRowStart', 'lineHeight', 'opacity', 'order', 'orphans', 'r', 'rx', 'ry', 'shapeImageThreshold', 'stopOpacity', 'strokeDasharray', 'strokeDashoffset', 'strokeMiterlimit', 'strokeOpacity', 'strokeWidth', 'tabSize', 'widows', 'x', 'y', 'zIndex', 'zoom' );

	/** renderStyle(): a style object as a style attribute. */
	public static function style_attr( array $style ) {
		$parts = array();

		foreach ( $style as $property => $value ) {
			if ( null === $value || BWFCRM_Email_Render_Js::UNDEFINED === $value ) {
				continue;
			}

			$property = (string) $property;

			if ( 0 === strpos( $property, '--' ) ) {
				$name = $property;
			} elseif ( preg_match( '/^(ms|O|Moz|Webkit)/', $property ) ) {
				$name = '-' . self::kebab( $property );
			} else {
				$name = self::kebab( $property );
			}

			if ( ( is_int( $value ) || is_float( $value ) ) && 0 != $value && ! in_array( $property, self::UNITLESS, true ) ) { // phpcs:ignore Universal.Operators.StrictComparisons.LooseNotEqual -- 0 and 0.0 alike, as JavaScript's 0 !== value.
				$value = BWFCRM_Email_Render_Js::str( $value ) . 'px';
			}

			$parts[] = $name . ':' . BWFCRM_Email_Render_Js::str( $value );
		}

		return implode( ';', $parts );
	}

	/** lodash kebabCase() for style property names: words split at case changes and punctuation. */
	private static function kebab( $name ) {
		$name = preg_replace( '/([a-z0-9])([A-Z])/', '$1 $2', $name );
		$name = preg_replace( '/([A-Z]+)([A-Z][a-z])/', '$1 $2', $name );
		$words = preg_split( '/[^A-Za-z0-9]+/', $name, -1, PREG_SPLIT_NO_EMPTY );

		return strtolower( implode( '-', $words ) );
	}

	/**
	 * An element, as renderElement() writes it: attributes in the order given,
	 * null ones left out, booleans only where they mean something.
	 */
	public static function element( $tag, array $props, $children = '' ) {
		$attributes = '';

		foreach ( $props as $key => $value ) {
			if ( null === $value || BWFCRM_Email_Render_Js::UNDEFINED === $value || is_array( $value ) && 'style' !== $key ) {
				continue;
			}

			$name = 'className' === $key ? 'class' : ( 'htmlFor' === $key ? 'for' : strtolower( $key ) );

			if ( 'style' === $key ) {
				$value = is_array( $value ) ? self::style_attr( $value ) : $value;

				if ( null === $value || '' === $value && is_array( $props['style'] ) ) {
					// renderStyle() of an empty object is undefined: the attribute is left out.
					continue;
				}
			}

			if ( is_bool( $value ) ) {
				if ( 0 !== strpos( $key, 'data-' ) && 0 !== strpos( $key, 'aria-' ) ) {
					continue;
				}

				$value = $value ? 'true' : 'false';
			}

			$attributes .= ' ' . $name . '="' . esc_attr( BWFCRM_Email_Render_Js::str( $value ) ) . '"';
		}

		if ( in_array( $tag, array( 'area', 'base', 'br', 'col', 'command', 'embed', 'hr', 'img', 'input', 'keygen', 'link', 'meta', 'param', 'source', 'track', 'wbr' ), true ) ) {
			return '<' . $tag . $attributes . '/>';
		}

		return '<' . $tag . $attributes . '>' . $children . '</' . $tag . '>';
	}

	/**
	 * The editor's Table component's props: cellpadding/cellspacing/border 0,
	 * role presentation, and width:100% unless the table sets its own.
	 */
	public static function table_props( array $props, $custom_width = false ) {
		$style = isset( $props['style'] ) && is_array( $props['style'] ) ? $props['style'] : array();

		unset( $props['style'] );

		$base = array(
			'cellPadding' => isset( $props['cellspacing'] ) ? $props['cellspacing'] : '0',
			'cellSpacing' => isset( $props['cellpadding'] ) ? $props['cellpadding'] : '0',
			'border'      => isset( $props['border'] ) ? $props['border'] : '0',
			'bgcolor'     => isset( $props['bgcolor'] ) ? $props['bgcolor'] : null,
			'align'       => isset( $props['align'] ) ? $props['align'] : null,
			'style'       => array_merge( $custom_width ? array() : array( 'width' => '100%' ), $style ),
			'role'        => 'presentation',
		);

		unset( $props['cellspacing'], $props['cellpadding'], $props['border'], $props['bgcolor'], $props['align'] );

		return array_merge( $base, $props );
	}
}
