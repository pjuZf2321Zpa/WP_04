<?php

defined( 'ABSPATH' ) || exit;

/**
 * What the email editor knows while it saves an email, which is everything a
 * block's HTML may depend on besides its own attributes:
 *
 *  - global:   the settings the email renders with - the editor's defaults,
 *              overlaid with the site's Global Style, overlaid with the four
 *              settings an email may override (background, width,
 *              contentBackground, align);
 *  - template: the email's own saved settings (block.settings);
 *  - saving:   always true here. The editor writes CSS variables for Global
 *              Style values only while it saves, and send time replaces them.
 */
final class BWFCRM_Email_Render_Context {

	/** Settings an email may override on top of a site's Global Style. */
	const OVERRIDABLE = array( 'background', 'width', 'contentBackground', 'align' );

	/** @var array */
	public $global = array();

	/** @var array */
	public $template = array();

	/** @var array */
	public $site = array();

	/** @var bool */
	public $saving = true;

	/** @var bool */
	public $rtl = false;

	/** @var string[] */
	public $google_fonts = array();

	/** Fonts the blocks use, collected while rendering, for the font links in the head. */
	public $fonts = array();

	/**
	 * @param array      $settings The email's settings (block.settings).
	 * @param array|null $site     The block editor site settings; null reads the site's.
	 * @param array      $options  { rtl: bool, google_fonts: string[] }
	 *
	 * @return self
	 */
	public static function create( array $settings = array(), $site = null, array $options = array() ) {
		$context           = new self();
		$context->template = BWFCRM_Email_Render_Js::plain( $settings );
		$context->site     = is_array( $site ) ? BWFCRM_Email_Render_Js::plain( $site ) : self::site_settings();
		$context->rtl      = isset( $options['rtl'] ) ? (bool) $options['rtl'] : ( function_exists( 'is_rtl' ) && is_rtl() );
		$context->google_fonts = isset( $options['google_fonts'] ) ? (array) $options['google_fonts'] : self::google_fonts();

		// The editor store's initial globalSettings.
		$global = array(
			'background'       => array(),
			'width'            => array( 'desktop' => array( 'value' => 640, 'unit' => 'px' ) ),
			'align'            => array(),
			'color'            => array(),
			'font'             => array(),
			'linkLineType'     => array( 'desktop' => 'underline' ),
			'linkColor'        => array(),
			'linkLineColor'    => array(),
			'buttonColor'      => array(),
			'buttonBackground' => array(),
			'buttonSize'       => array(),
			'buttonAuto'       => array( 'desktop' => true ),
			'buttonFont'       => array(),
		);

		$site_setting = isset( $context->site['setting'] ) && is_array( $context->site['setting'] ) ? $context->site['setting'] : array();

		if ( ! empty( $site_setting ) ) {
			$global = array_merge( $global, $site_setting, array_intersect_key( $context->template, array_flip( self::OVERRIDABLE ) ) );
		} elseif ( ! empty( $context->template ) ) {
			$global = array_merge( $global, $context->template );
		}

		$context->global = $global;

		return $context;
	}

	/** `templateSettings.hasOwnProperty( key )` */
	public function template_has( $key ) {
		return array_key_exists( $key, $this->template );
	}

	/** A setting the email left to the Global Style renders as its CSS variable while saving. */
	public function uses_variable( $key ) {
		return $this->saving && ! $this->template_has( $key );
	}

	private static function site_settings() {
		if ( class_exists( 'BWFAN_Common' ) && method_exists( 'BWFAN_Common', 'get_block_editor_settings' ) ) {
			$settings = BWFAN_Common::get_block_editor_settings();

			return is_array( $settings ) ? BWFCRM_Email_Render_Js::plain( $settings ) : array();
		}

		return array();
	}

	/** The web fonts the editor offers, as the plugin hands them to it. */
	private static function google_fonts() {
		if ( class_exists( 'BWFAN_Rest_API_Loader' ) && method_exists( 'BWFAN_Rest_API_Loader', 'get_instance' ) ) {
			$loader = BWFAN_Rest_API_Loader::get_instance();

			if ( is_object( $loader ) && method_exists( $loader, 'get_google_fonts_array' ) ) {
				return (array) $loader->get_google_fonts_array();
			}
		}

		return array();
	}
}
