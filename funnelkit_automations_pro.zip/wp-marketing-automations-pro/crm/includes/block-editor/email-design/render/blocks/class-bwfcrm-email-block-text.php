<?php

defined( 'ABSPATH' ) || exit;

/** email-block/text: a paragraph or heading of rich text. */
class BWFCRM_Email_Block_Text extends BWFCRM_Email_Block {

	public static function html( array $block, $inner, BWFCRM_Email_Render_Context $context, $responsive ) {
		$content = self::a( $block, 'content', '' );
		$content = is_string( $content ) ? $content : '';
		$html    = $context->saving ? self::heading_font_size( $content ) : $content;

		return '<tr><td class="bwf-email-text bwf-email-text-' . self::s( self::a( $block, 'uniqueID' ) ) . '">'
			. '<div class="bwf-block-text-container"><p class="bwf-block-text-inner-container">'
			. $html
			. ( false !== strpos( $content, '<br>' ) ? '<br/>' : '' )
			. '</p></div></td></tr>';
	}

	/**
	 * updateHeadingFontSize(): a heading span with no font size of its own
	 * gets its level's Global Style size, as a CSS variable.
	 */
	public static function heading_font_size( $content ) {
		if ( false === strpos( $content, 'data-heading-level' ) ) {
			return $content;
		}

		// Merge tags in links would come back URL-encoded ({{unsubscribe_link}} as %7B%7B…) and never be replaced.
		$tags     = array();
		$html     = BWFCRM_Email_Render_Inliner::protect( $content, $tags );
		$dom      = new DOMDocument();
		$previous = libxml_use_internal_errors( true );
		$dom->loadHTML( '<?xml encoding="utf-8"?><div id="bwfcrm-text-root">' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
		libxml_clear_errors();
		libxml_use_internal_errors( $previous );

		$xpath = new DOMXPath( $dom );
		$root  = $xpath->query( '//*[@id="bwfcrm-text-root"]' )->item( 0 );

		if ( ! $root ) {
			return $content;
		}

		foreach ( $xpath->query( './/span[@data-heading-level]', $root ) as $span ) {
			$level = $span->getAttribute( 'data-heading-level' );
			$style = $span->getAttribute( 'style' );

			if ( '' !== $level && ! preg_match( '/(^|;)\s*font-size\s*:/i', $style ) ) {
				$style = trim( $style );
				$span->setAttribute( 'style', ( '' !== $style ? rtrim( $style, ';' ) . '; ' : '' ) . 'font-size: var(--bwfbe-fontH' . $level . '-desktop-size);' );
			}
		}

		$out = '';

		foreach ( iterator_to_array( $root->childNodes ) as $child ) {
			$out .= $dom->saveHTML( $child );
		}

		return BWFCRM_Email_Render_Inliner::restore( $out, $tags );
	}

	public static function style( array $block, BWFCRM_Email_Render_Context $context ) {
		return self::media( self::desktop_css( $block, $context, 'desktop' ), self::mobile_css( $block, $context, 'mobile' ) );
	}

	private static function size_or_global( array $block, BWFCRM_Email_Render_Context $context, $screen, $important ) {
		$size = BWFCRM_Email_Render_Js::get( self::a( $block, 'font' ), array( $screen, 'size' ) );

		if ( null !== self::at( self::a( $block, 'font' ), $screen ) && self::t( $size ) && '' !== $size ) {
			return 'font-size: ' . self::s( $size ) . 'px' . ( $important ? ' !important' : '' ) . ';';
		}

		return BWFCRM_Email_Renderer::global_css( $context->global, 'font', $screen, 'size', $important, $context );
	}

	private static function font_family_css( array $block, BWFCRM_Email_Render_Context $context, $screen ) {
		$family = BWFCRM_Email_Render_Js::get( self::a( $block, 'font' ), array( $screen, 'family' ) );

		if ( null !== self::at( self::a( $block, 'font' ), $screen ) && self::t( $family ) && '' !== $family ) {
			return 'font-family: ' . self::s( $family ) . BWFCRM_Email_Renderer::backup_font( $context->global, $family, $context ) . ';';
		}

		return BWFCRM_Email_Renderer::global_css( $context->global, 'font', $screen, 'family', false, $context );
	}

	private static function line_height( array $block, $screen, $fallback, $important = false ) {
		$value = BWFCRM_Email_Render_Js::get( self::a( $block, 'lineHeight' ), array( $screen, 'value' ) );

		if ( null !== self::at( self::a( $block, 'lineHeight' ), $screen ) && self::t( $value ) && '' !== $value ) {
			return 'line-height: ' . self::s( $value ) . ( $important ? ' !important' : '' ) . ';';
		}

		return $fallback;
	}

	private static function desktop_css( array $block, BWFCRM_Email_Render_Context $context, $screen ) {
		$selector = '.bwf-email-text.bwf-email-text-' . self::s( self::a( $block, 'uniqueID' ) );
		$padding  = self::at( self::a( $block, 'padding' ), $screen );
		$col_pad  = null !== $padding ? BWFCRM_Email_Render_Css::padding( $padding ) : '';
		$align    = BWFCRM_Email_Render_Js::get( self::a( $block, 'text' ), array( $screen, 'align' ) );
		$text_at  = BWFCRM_Email_Render_Js::get( self::a( $block, 'text' ), array( $screen ) );
		$color    = self::at( self::a( $block, 'color' ), $screen );
		$lh_value = BWFCRM_Email_Render_Js::get( self::a( $block, 'lineHeight' ), array( $screen, 'value' ) );
		$has_lh   = null !== self::at( self::a( $block, 'lineHeight' ), $screen ) && self::t( $lh_value ) && '' !== $lh_value;

		// Heading sizes are written only outside a save; a save leaves them to the CSS variable on the span.
		$headings = '';

		if ( ! $context->saving ) {
			foreach ( array( 1, 2, 3, 4, 5, 6 ) as $level ) {
				$headings .= $selector . ' span[data-heading-level="' . $level . '"]{
					font-size:' . self::s( BWFCRM_Email_Render_Js::get( $context->global, 'fontH' . $level . '.desktop.size' ) ) . 'px;
				}';
			}
		}

		return '
        ' . $selector . ' {
            ' . $col_pad . '
            word-break:break-word;
        }
        ' . $selector . ' .bwf-block-text-container {
            font-family:arial,helvetica,sans-serif;
            line-height:1.5;
            font-size: 16px;
            ' . ( $context->rtl ? 'text-align:right;' : '' ) . '
            ' . ( self::t( $text_at ) && self::t( $align ) ? 'text-align: ' . self::s( $align ) . ';' : '' ) . '
            ' . self::size_or_global( $block, $context, $screen, false ) . '
            ' . self::font_family_css( $block, $context, $screen ) . '
            ' . self::line_height( $block, $screen, 'line-height:1.5;' ) . '
            ' . ( null !== $color ? 'color: ' . self::s( $color ) . ';' : BWFCRM_Email_Renderer::global_css( $context->global, 'color', $screen, '', false, $context ) ) . '
        }
        ' . $selector . ' .bwf-block-text-inner-container {
            word-break:break-word;
            ' . self::size_or_global( $block, $context, $screen, false ) . '
            ' . self::font_family_css( $block, $context, $screen ) . '
            ' . self::line_height( $block, $screen, 'line-height:1.5;' ) . '
        }
        ' . $selector . ' p, ' . $selector . ' span {
            ' . ( $has_lh ? 'mso-line-height-alt: ' . self::s( BWFCRM_Email_Render_Js::number( $lh_value ) * 100 ) . '%;' : 'mso-line-height-alt:150%;' ) . '
        }
        ' . $headings . '
        ' . $selector . ' a {
            ' . BWFCRM_Email_Renderer::global_css( $context->global, 'linkLineType', $screen, '', false, $context ) . '
            ' . BWFCRM_Email_Renderer::global_css( $context->global, 'linkColor', $screen, '', false, $context ) . '
        }
		' . BWFCRM_Email_Renderer::visibility_css( $selector, $block, $screen ) . '
    ';
	}

	private static function mobile_css( array $block, BWFCRM_Email_Render_Context $context, $screen ) {
		$selector = '.bwf-email-text.bwf-email-text-' . self::s( self::a( $block, 'uniqueID' ) );
		$padding  = self::at( self::a( $block, 'padding' ), $screen );
		$col_pad  = null !== $padding ? BWFCRM_Email_Render_Css::padding( $padding, true ) : '';
		$align    = BWFCRM_Email_Render_Js::get( self::a( $block, 'text' ), array( $screen, 'align' ) );
		$text_at  = BWFCRM_Email_Render_Js::get( self::a( $block, 'text' ), array( $screen ) );
		$color    = self::at( self::a( $block, 'color' ), $screen );
		$size     = BWFCRM_Email_Render_Js::get( self::a( $block, 'font' ), array( $screen, 'size' ) );
		$has_size = null !== self::at( self::a( $block, 'font' ), $screen ) && self::t( $size ) && '' !== $size;

		return '
		' . $selector . ' {
			' . $col_pad . '
		}
        ' . $selector . ' .bwf-block-text-container {
            ' . ( self::t( $text_at ) && self::t( $align ) ? 'text-align: ' . self::s( $align ) . ' !important;' : '' ) . '
            ' . self::size_or_global( $block, $context, $screen, true ) . '
            ' . ( null !== $color ? 'color: ' . self::s( $color ) . ';' : BWFCRM_Email_Renderer::global_css( $context->global, 'color', $screen, true, false, $context ) ) . '
            ' . self::line_height( $block, $screen, '', true ) . '
        }
        ' . $selector . ' .bwf-block-text-inner-container,
        ' . $selector . ' .bwf-block-text-inner-container span {
            ' . ( $has_size ? 'font-size: ' . self::s( $size ) . 'px !important;' : '' ) . '
            ' . self::line_height( $block, $screen, '', true ) . '
        }
		' . BWFCRM_Email_Renderer::visibility_css( $selector, $block, $screen ) . '
    ';
	}
}
