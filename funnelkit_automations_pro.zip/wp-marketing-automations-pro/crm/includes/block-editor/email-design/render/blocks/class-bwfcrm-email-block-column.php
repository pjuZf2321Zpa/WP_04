<?php

defined( 'ABSPATH' ) || exit;

/** email-block/column: one column of a section, sized in pixels. */
class BWFCRM_Email_Block_Column extends BWFCRM_Email_Block {

	public static function html( array $block, $inner, BWFCRM_Email_Render_Context $context, $responsive ) {
		$unique_id  = self::s( self::a( $block, 'uniqueID' ) );
		$padding    = self::a( $block, 'padding' );
		$v_align    = self::a( $block, 'vAlign' );
		$border     = self::a( $block, 'border' );
		$background = self::a( $block, 'background' );
		$width      = self::a( $block, 'width.desktop.width' );
		$unit       = self::a( $block, 'width.desktop.unit', 'px' );
		$parsed     = BWFCRM_Email_Render_Js::parse_int( $width );

		// renderTemplate (a template preview) rescales; saving never does.
		$col_width = ( ! is_nan( (float) $parsed ) && 0 !== $parsed ) ? self::s( $width ) . self::s( $unit ) : '100%';

		$pad_desktop = self::at( $padding, 'desktop' );
		$col_padding = null !== $pad_desktop ? BWFCRM_Email_Render_Css::padding( $pad_desktop ) : '';
		$valign      = null !== self::at( $v_align, 'desktop' ) ? self::s( self::at( $v_align, 'desktop' ) ) : 'top';
		$b_desktop   = self::at( $border, 'desktop' );
		$bg_desktop  = self::at( $background, 'desktop' );
		$has_bg_img  = self::t( self::a( $block, 'rowHasBgImage' ) );

		$child_table = static function () use ( $inner ) {
			return BWFCRM_Email_Renderer::element( 'table', BWFCRM_Email_Renderer::table_props( array() ), '<tbody>' . $inner . '</tbody>' );
		};

		if ( '' !== $col_padding ) {
			$content = $has_bg_img
				? '<!--[if mso | IE]>' . BWFCRM_Email_Renderer::element( 'span', array( 'style' => array( 'marginLeft' => self::s( BWFCRM_Email_Render_Js::get( $padding, 'desktop.left' ) ) . 'px' ) ), '<![endif]-->' . $child_table() . '<!--[if mso | IE]>' ) . '<![endif]-->'
				: $child_table();
			$rows    = '<tr><td class="bwf-email-inner-column-container">' . $content . '</td></tr>';
		} else {
			$rows = $inner;
		}

		$structure = BWFCRM_Email_Renderer::element(
			'table',
			BWFCRM_Email_Renderer::table_props(
				array(
					'className' => 'bwf-email-inner-column bwf-email-inner-column-' . $unique_id,
					'role'      => 'presentation',
					'width'     => 100,
				)
			),
			'<tbody>' . $rows . '</tbody>'
		);

		$border_css = null !== $b_desktop ? BWFCRM_Email_Renderer::attr( BWFCRM_Email_Render_Css::border( $b_desktop ) ) : '';
		$bg_css     = null !== $bg_desktop ? BWFCRM_Email_Renderer::attr( BWFCRM_Email_Render_Css::background( $bg_desktop ) ) : '';
		// Written into the <td> below by hand, not through element(): escaped here.
		$td_width   = BWFCRM_Email_Renderer::attr( $col_width );
		$td_valign  = BWFCRM_Email_Renderer::attr( $valign );

		if ( ! $responsive ) {
			$bg_color = self::a( $block, 'background.desktop.color' );

			return '<td style="width: ' . $td_width . ';vertical-align: ' . $td_valign . ';' . $border_css . '
					' . ( ! BWFCRM_Email_Render_Js::is_empty( $bg_color ) ? 'background-color: ' . BWFCRM_Email_Renderer::attr( self::s( $bg_color ) ) . ';' : '' ) . '
					' . $bg_css . '" valign="' . $td_valign . '">'
				. $structure
				. '</td>';
		}

		return '<!--[if mso | IE]><td style="width: ' . $td_width . ';vertical-align: ' . $td_valign . ';' . $border_css . $bg_css . '" valign="' . $td_valign . '"><![endif]-->'
			. BWFCRM_Email_Renderer::element(
				'div',
				array(
					'className' => 'bwf-email-inner-column-wrapper bwf-email-inner-column-wrapper-' . $unique_id . ( $responsive ? ' is-responsive' : '' ),
					'style'     => array( 'width' => $col_width ),
				),
				$structure
			)
			. '<!--[if mso | IE]></td><![endif]-->';
	}

	public static function style( array $block, BWFCRM_Email_Render_Context $context ) {
		return self::media( self::desktop_css( $block, 'desktop' ), self::mobile_css( $block, 'mobile' ) );
	}

	private static function desktop_css( array $block, $screen ) {
		$id         = self::s( self::a( $block, 'uniqueID' ) );
		$selector   = '.bwf-email-inner-column-wrapper.bwf-email-inner-column-wrapper-' . $id;
		$padding    = self::at( self::a( $block, 'padding' ), $screen );
		$border     = self::at( self::a( $block, 'border' ), $screen );
		$background = self::at( self::a( $block, 'background' ), $screen );
		$v_align    = self::at( self::a( $block, 'vAlign' ), $screen );
		$col_pad    = null !== $padding ? BWFCRM_Email_Render_Css::padding( $padding ) : '';

		return '
        ' . $selector . ' {
            display:table-cell;
			' . ( null !== $v_align ? 'vertical-align:' . self::s( $v_align ) . ';' : 'vertical-align:top;' ) . '
        }
        .bwf-email-inner-column.bwf-email-inner-column-' . $id . ' {
            border-collapse:separate;
        }
		' . ( '' === $col_pad
			? '.bwf-email-inner-column.bwf-email-inner-column-' . $id . ' {
			' . $col_pad . '
		}'
			: '.bwf-email-inner-column.bwf-email-inner-column-' . $id . ' .bwf-email-inner-column-container {
			' . $col_pad . '
		}' ) . '
		.bwf-email-inner-column-wrapper.bwf-email-inner-column-wrapper-' . $id . ' {
			' . ( null !== $border ? BWFCRM_Email_Render_Css::border( $border ) : '' ) . '
			' . ( null !== $background ? BWFCRM_Email_Render_Css::background( $background ) : '' ) . '
			mso-border-alt:none;
		}
		.bwf-email-inner-column-wrapper.bwf-email-inner-column-wrapper-' . $id . ' > table {
			' . ( null !== $background ? BWFCRM_Email_Render_Css::background( $background ) : '' ) . '
			' . ( null !== $border ? BWFCRM_Email_Render_Css::border_radius( $border ) : '' ) . '
		}
    ';
	}

	private static function mobile_css( array $block, $screen ) {
		$id         = self::s( self::a( $block, 'uniqueID' ) );
		$padding    = self::a( $block, 'padding' );
		$pad_screen = self::at( $padding, $screen );
		$border     = self::at( self::a( $block, 'border' ), $screen );
		$background = self::at( self::a( $block, 'background' ), $screen );
		$col_pad    = null !== $pad_screen ? BWFCRM_Email_Render_Css::padding( $pad_screen, true ) : '';

		return '
		' . ( null === self::at( $padding, 'desktop' )
			? '.bwf-email-inner-column.bwf-email-inner-column-' . $id . ' {
			' . $col_pad . '
		}'
			: '.bwf-email-inner-column.bwf-email-inner-column-' . $id . ' .bwf-email-inner-column-container {
			' . $col_pad . '
		}' ) . '
		.bwf-email-inner-column-wrapper.bwf-email-inner-column-wrapper-' . $id . ' {
			' . ( null !== $border ? BWFCRM_Email_Render_Css::border( $border, true ) : '' ) . '
			' . ( null !== $background ? BWFCRM_Email_Render_Css::background( $background, true ) : '' ) . '
		}
    ';
	}
}
