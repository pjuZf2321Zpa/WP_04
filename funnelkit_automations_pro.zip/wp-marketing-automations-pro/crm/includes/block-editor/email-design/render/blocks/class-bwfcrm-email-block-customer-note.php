<?php

defined( 'ABSPATH' ) || exit;

/**
 * email-block/customer-note: the note the customer left with the order.
 *
 * While saving, the editor writes only the shortcode, the block's attributes
 * and the email's global settings inside it, and no CSS; send time renders it.
 * The shortcode is written the way cart-items writes it; hasWCChildSelected is
 * set by the edit on mount and saved with the attributes.
 */
class BWFCRM_Email_Block_Customer_Note extends BWFCRM_Email_Block {

	public static function html( array $block, $inner, BWFCRM_Email_Render_Context $context, $responsive ) {
		return BWFCRM_Email_Renderer::dynamic_shortcode( 'bwfbe_order_note', $block, $context, '', array( 'hasWCChildSelected' => false ) );
	}
}
