<?php

defined( 'ABSPATH' ) || exit;

/**
 * email-block/cart-link: the button back to the abandoned cart. Dynamic - while saving, the
 * editor writes only its shortcode and no CSS; send time renders it.
 */
class BWFCRM_Email_Block_Cart_Link extends BWFCRM_Email_Block {

	public static function html( array $block, $inner, BWFCRM_Email_Render_Context $context, $responsive ) {
		return BWFCRM_Email_Renderer::dynamic_shortcode( 'bwfbe_cart_link', $block, $context );
	}
}
