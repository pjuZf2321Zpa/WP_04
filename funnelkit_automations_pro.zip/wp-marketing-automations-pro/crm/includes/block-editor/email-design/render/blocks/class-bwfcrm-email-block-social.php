<?php

defined( 'ABSPATH' ) || exit;

/** email-block/social: a row of social profile icons. */
class BWFCRM_Email_Block_Social extends BWFCRM_Email_Block {

	/** The editor's assetsURL, where the social icon images live. */
	const ASSETS_URL = 'https://d241ue3yrqqwem.cloudfront.net/';

	public static function html( array $block, $inner, BWFCRM_Email_Render_Context $context, $responsive ) {
		$screen     = 'desktop';
		$padding    = self::a( $block, 'padding' );
		$left       = BWFCRM_Email_Render_Js::get( $padding, array( $screen, 'left' ) );
		$space_left = null !== self::at( $padding, $screen ) && self::t( $left ) ? self::s( $left ) . 'px' : '';
		$icons      = self::a( $block, 'icons', array() );
		$icons      = BWFCRM_Email_Render_Js::UNDEFINED === $icons ? array() : $icons;
		$size       = self::a( $block, 'size' );
		$setting    = BWFCRM_Email_Render_Js::get( $context->site, 'setting', array() );
		$social     = BWFCRM_Email_Render_Js::get( $setting, 'social', array() );
		$social     = BWFCRM_Email_Render_Js::UNDEFINED === $social ? array() : $social;

		// Saving is never a preview and never a template render: no icons means the dynamic shortcode.
		if ( BWFCRM_Email_Render_Js::is_empty( $icons ) ) {
			$cells = self::shortcode( $block, $context );
		} else {
			$cells = '';

			foreach ( is_array( $icons ) ? array_values( $icons ) : array() as $icon ) {
				$cells .= '<!--[if mso | IE]>'
					. BWFCRM_Email_Renderer::element(
						'td',
						array(
							'style' => array(
								'width'        => $size,
								'height'       => $size,
								'paddingRight' => '0 !important',
							),
						),
						'<![endif]-->'
						. BWFCRM_Email_Renderer::element(
							'table',
							BWFCRM_Email_Renderer::table_props(
								array(
									'style' => array(
										'display'        => 'inline-block',
										'borderCollapse' => 'collapse',
									),
								),
								true
							),
							'<tbody><tr><td class="bwfbe-social-icon-wrap">' . self::icon_html( $block, $icon, $icons, $social, $setting ) . '</td></tr></tbody>'
						)
						. '<!--[if mso | IE]>'
					)
					. '<![endif]-->';
			}
		}

		$table = BWFCRM_Email_Renderer::element(
			'table',
			BWFCRM_Email_Renderer::table_props( array( 'rolw' => 'presentation' ) ),
			'<tbody><tr><td class="bwf-email-social-container">'
			. '<!--[if mso | IE]>'
			. BWFCRM_Email_Renderer::element( 'table', BWFCRM_Email_Renderer::table_props( array(), true ), '<tr><![endif]-->' . $cells . '<!--[if mso | IE]></tr>' )
			. '<![endif]-->'
			. '</td></tr></tbody>'
		);

		// SpanTag is '' unless the section has a background image: its children render without a wrapper.
		$span_inner = '<![endif]-->' . $table . '<!--[if mso | IE]>';
		$span       = self::t( self::a( $block, 'rowHasBgImage' ) ) && '' !== $space_left
			? BWFCRM_Email_Renderer::element( 'span', array( 'style' => array( 'marginLeft' => $space_left ) ), $span_inner )
			: $span_inner;

		return '<tr><td class="bwf-email-social bwf-email-social-' . self::s( self::a( $block, 'uniqueID' ) ) . '">'
			. '<!--[if mso | IE]>' . $span . '<![endif]-->'
			. '</td></tr>';
	}

	/** getIconHtml(): the icon image, linked to the icon's own or the site's profile URL. */
	private static function icon_html( array $block, $icon, $icons, $social, $setting ) {
		$type        = self::a( $block, 'type' );
		$social_type = BWFCRM_Email_Render_Js::get( $setting, 'socialType', 'circle' );
		$social_type = BWFCRM_Email_Render_Js::UNDEFINED === $social_type ? 'circle' : $social_type;
		$icon_type   = BWFCRM_Email_Render_Js::is_empty( $icons ) && BWFCRM_Email_Render_Js::is_empty( $type ) ? $social_type : $type;
		$icon_type   = self::t( $icon_type ) ? $icon_type : 'circle';
		$name        = BWFCRM_Email_Render_Js::get( $icon, 'iconName' );
		$size        = self::a( $block, 'size' );

		$html = BWFCRM_Email_Renderer::element(
			'img',
			array(
				'src'    => self::ASSETS_URL . 'social-icons/' . self::s( $icon_type ) . '/' . self::s( $name ) . '.png',
				'width'  => $size,
				'height' => $size,
				'alt'    => $name,
			)
		);

		$global = BWFCRM_Email_Render_Js::UNDEFINED;

		if ( ! BWFCRM_Email_Render_Js::is_empty( $social ) && is_array( $social ) ) {
			foreach ( $social as $candidate ) {
				if ( BWFCRM_Email_Render_Js::get( $candidate, 'iconName' ) === $name ) {
					$global = $candidate;
					break;
				}
			}
		}

		$link        = BWFCRM_Email_Render_Js::get( $icon, 'link' );
		$global_link = BWFCRM_Email_Render_Js::get( $global, 'link' );

		if ( self::t( $link ) || self::t( $global_link ) ) {
			$html = BWFCRM_Email_Renderer::element(
				'a',
				array(
					'href'   => ! BWFCRM_Email_Render_Js::is_empty( $link ) ? $link : $global_link,
					'target' => '_blank',
				),
				$html
			);
		}

		return $html;
	}

	/**
	 * The [bwfbe_social_icons] shortcode, for a block with no icons. Its editor
	 * sets hasWCChildSelected once it mounts, as the WooCommerce blocks do.
	 */
	private static function shortcode( array $block, BWFCRM_Email_Render_Context $context ) {
		return BWFCRM_Email_Renderer::dynamic_shortcode( 'bwfbe_social_icons', $block, $context, '', array( 'hasWCChildSelected' => false ) );
	}

	public static function style( array $block, BWFCRM_Email_Render_Context $context ) {
		return self::media( self::desktop_css( $block, 'desktop' ), self::mobile_css( $block, 'mobile' ) );
	}

	/** getSpacing(): the gap between icons, on the side away from the alignment. */
	private static function spacing( array $block, $screen ) {
		$spacing = self::at( self::a( $block, 'spacing' ), $screen );

		if ( null === $spacing ) {
			return '';
		}

		$alignment = self::at( self::a( $block, 'alignment' ), $screen );
		$align     = null !== $alignment ? $alignment : 'center';

		switch ( $align ) {
			case 'left':
				return 'padding-right: ' . self::s( $spacing ) . 'px;mso-padding-right: ' . self::s( $spacing ) . 'px;';
			case 'right':
				return 'padding-left: ' . self::s( $spacing ) . 'px;mso-padding-left: ' . self::s( $spacing ) . 'px;';
			default:
				$half = self::s( BWFCRM_Email_Render_Js::number( $spacing ) / 2 );

				return 'padding-left: ' . $half . 'px;mso-padding-left: ' . $half . 'px;padding-right: ' . $half . 'px;mso-padding-right: ' . $half . 'px;';
		}
	}

	private static function alignment( array $block, $screen ) {
		$alignment = self::at( self::a( $block, 'alignment' ), $screen );

		if ( null !== $alignment && in_array( $alignment, array( 'right', 'center', 'left' ), true ) ) {
			return 'text-align:' . $alignment . ';';
		}

		return 'text-align:center;';
	}

	private static function desktop_css( array $block, $screen ) {
		$selector = '.bwf-email-social.bwf-email-social-' . self::s( self::a( $block, 'uniqueID' ) );
		$padding  = self::at( self::a( $block, 'padding' ), $screen );
		$size     = self::s( self::a( $block, 'size' ) );

		return '
        ' . $selector . ' {
            ' . ( null !== $padding ? BWFCRM_Email_Render_Css::padding( $padding ) : '' ) . '
            ' . ( null !== $padding ? BWFCRM_Email_Render_Css::padding( $padding, false, true ) : '' ) . '
        }
        ' . $selector . ' .bwfbe-social-icon-wrap {
            ' . self::spacing( $block, $screen ) . '
            width:' . $size . 'px;
            height:' . $size . 'px;
        }
        ' . $selector . ' .bwf-email-social-container {
            ' . self::alignment( $block, $screen ) . '
        }
		' . BWFCRM_Email_Renderer::visibility_css( $selector, $block, $screen ) . '
    ';
	}

	private static function mobile_css( array $block, $screen ) {
		$selector = '.bwf-email-social.bwf-email-social-' . self::s( self::a( $block, 'uniqueID' ) );
		$padding  = self::at( self::a( $block, 'padding' ), $screen );

		return '
		' . $selector . ' {
			' . ( null !== $padding ? BWFCRM_Email_Render_Css::padding( $padding, true ) : '' ) . '
		}
		' . BWFCRM_Email_Renderer::visibility_css( $selector, $block, $screen ) . '
    ';
	}
}
