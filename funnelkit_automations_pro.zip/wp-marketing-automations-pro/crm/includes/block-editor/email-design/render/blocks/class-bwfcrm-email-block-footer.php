<?php

defined( 'ABSPATH' ) || exit;

/** email-block/footer: the email's footer, usually the global one. */
class BWFCRM_Email_Block_Footer extends BWFCRM_Email_Block {

	public static function html( array $block, $inner, BWFCRM_Email_Render_Context $context, $responsive ) {
		if ( self::t( self::a( $block, 'isGlobal' ) ) ) {
			// Saved as a merge tag; send time puts the global footer in its place.
			$footer = $context->saving ? '{{mail_footer}}' : self::global_footer();
		} else {
			$footer = self::a( $block, 'content', '' );
			$footer = is_string( $footer ) ? html_entity_decode( $footer, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) : '';
		}

		return '<tr><td class="bwf-email-footer bwf-email-footer-' . self::s( self::a( $block, 'uniqueID' ) ) . '">'
			. '<div class="bwf-block-text-container"><p class="bwf-block-text-inner-container">'
			. $footer
			. '</p></div></td></tr>';
	}

	/** The global email footer, as the editor is given it. */
	private static function global_footer() {
		if ( ! class_exists( 'BWFAN_Common' ) || ! method_exists( 'BWFAN_Common', 'get_global_settings' ) ) {
			return '';
		}

		$settings = BWFAN_Common::get_global_settings();

		return isset( $settings['bwfan_email_footer_setting'] ) && is_string( $settings['bwfan_email_footer_setting'] ) ? $settings['bwfan_email_footer_setting'] : '';
	}

	public static function style( array $block, BWFCRM_Email_Render_Context $context ) {
		return self::media( self::desktop_css( $block, $context, 'desktop' ), self::mobile_css( $block, $context, 'mobile' ) );
	}

	private static function size( array $block, $screen ) {
		$font = self::at( self::a( $block, 'font' ), $screen );
		$size = BWFCRM_Email_Render_Js::get( $font, 'size' );

		return null !== $font && self::t( $size ) && '' !== $size ? $size : null;
	}

	private static function font_family_css( array $block, $screen ) {
		$font   = self::at( self::a( $block, 'font' ), $screen );
		$family = BWFCRM_Email_Render_Js::get( $font, 'family' );

		return null !== $font && self::t( $family ) && '' !== $family ? $family : null;
	}

	private static function line_height( array $block, $screen ) {
		$line_height = self::at( self::a( $block, 'lineHeight' ), $screen );
		$value       = BWFCRM_Email_Render_Js::get( $line_height, 'value' );

		return null !== $line_height && self::t( $value ) && '' !== $value ? $value : null;
	}

	private static function align( array $block, $screen ) {
		$text  = BWFCRM_Email_Render_Js::get( self::a( $block, 'text' ), array( $screen ) );
		$align = BWFCRM_Email_Render_Js::get( $text, 'align' );

		return self::t( $text ) && self::t( $align ) ? $align : null;
	}

	private static function desktop_css( array $block, BWFCRM_Email_Render_Context $context, $screen ) {
		$selector = '.bwf-email-footer.bwf-email-footer-' . self::s( self::a( $block, 'uniqueID' ) );
		$padding  = self::at( self::a( $block, 'padding' ), $screen );
		$align    = self::align( $block, $screen );
		$size     = self::size( $block, $screen );
		$family   = self::font_family_css( $block, $screen );
		$lh       = self::line_height( $block, $screen );
		$color    = self::at( self::a( $block, 'color' ), $screen );

		$size_css   = null !== $size ? 'font-size: ' . self::s( $size ) . 'px;' : BWFCRM_Email_Renderer::global_css( $context->global, 'font', $screen, 'size', false, $context );
		$family_css = null !== $family ? 'font-family: ' . self::s( $family ) . BWFCRM_Email_Renderer::backup_font( $context->global, $family, $context ) . ';' : BWFCRM_Email_Renderer::global_css( $context->global, 'font', $screen, 'family', false, $context );
		$lh_css     = null !== $lh ? 'line-height: ' . self::s( $lh ) . ';' : 'line-height:1.5;';

		return '
        ' . $selector . ' {
            ' . ( null !== $padding ? BWFCRM_Email_Render_Css::padding( $padding ) : '' ) . '
            word-break:break-word;
        }
        ' . $selector . ' .bwf-block-text-container {
            font-family:arial,helvetica,sans-serif;
            line-height:1.5;
            font-size: 16px;
            ' . ( $context->rtl ? 'text-align:right;' : '' ) . '
            ' . ( null !== $align ? 'text-align: ' . self::s( $align ) . ';' : '' ) . '
            ' . $size_css . '
            ' . $family_css . '
            ' . $lh_css . '
            ' . ( null !== $color ? 'color: ' . self::s( $color ) . ';' : BWFCRM_Email_Renderer::global_css( $context->global, 'color', $screen, '', false, $context ) ) . '
        }
        ' . $selector . ' .bwf-block-text-inner-container {
            word-break:break-word;
            ' . $size_css . '
            ' . $family_css . '
            ' . $lh_css . '
        }
        ' . $selector . ' p, ' . $selector . ' span {
            ' . ( null !== $lh ? 'mso-line-height-alt: ' . self::s( BWFCRM_Email_Render_Js::number( $lh ) * 100 ) . '%;' : 'mso-line-height-alt:150%;' ) . '
        }
        ' . $selector . ' a {
            ' . BWFCRM_Email_Renderer::global_css( $context->global, 'linkLineType', $screen, '', false, $context ) . '
            ' . BWFCRM_Email_Renderer::global_css( $context->global, 'linkColor', $screen, '', false, $context ) . '
        }
		' . BWFCRM_Email_Renderer::visibility_css( $selector, $block, $screen ) . '
    ';
	}

	private static function mobile_css( array $block, BWFCRM_Email_Render_Context $context, $screen ) {
		$selector = '.bwf-email-footer.bwf-email-footer-' . self::s( self::a( $block, 'uniqueID' ) );
		$padding  = self::at( self::a( $block, 'padding' ), $screen );
		$align    = self::align( $block, $screen );
		$size     = self::size( $block, $screen );
		$lh       = self::line_height( $block, $screen );
		$color    = self::at( self::a( $block, 'color' ), $screen );

		return '
		' . $selector . ' {
			' . ( null !== $padding ? BWFCRM_Email_Render_Css::padding( $padding, true ) : '' ) . '
		}
        ' . $selector . ' .bwf-block-text-container {
            ' . ( null !== $align ? 'text-align: ' . self::s( $align ) . ' !important;' : '' ) . '
            ' . ( null !== $size ? 'font-size: ' . self::s( $size ) . 'px !important;' : BWFCRM_Email_Renderer::global_css( $context->global, 'font', $screen, 'size', true, $context ) ) . '
            ' . ( null !== $color ? 'color: ' . self::s( $color ) . ';' : BWFCRM_Email_Renderer::global_css( $context->global, 'color', $screen, true, false, $context ) ) . '
            ' . ( null !== $lh ? 'line-height: ' . self::s( $lh ) . ' !important;' : '' ) . '
        }
        ' . $selector . ' .bwf-block-text-inner-container,  ' . $selector . ' .bwf-block-text-inner-container span.has-font-size {
            ' . ( null !== $size ? 'font-size: ' . self::s( $size ) . 'px !important;' : '' ) . '
            ' . ( null !== $lh ? 'line-height: ' . self::s( $lh ) . ' !important;' : '' ) . '
        }
		' . BWFCRM_Email_Renderer::visibility_css( $selector, $block, $screen ) . '
    ';
	}
}
