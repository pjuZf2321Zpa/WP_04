<?php

defined( 'ABSPATH' ) || exit;

/** email-block/space-divider: a horizontal rule with space around it. */
class BWFCRM_Email_Block_Space_Divider extends BWFCRM_Email_Block {

	public static function html( array $block, $inner, BWFCRM_Email_Render_Context $context, $responsive ) {
		$screen    = 'desktop';
		$alignment = self::at( self::a( $block, 'alignment' ), $screen );
		$value     = BWFCRM_Email_Render_Js::get( self::a( $block, 'dividerWidth' ), array( $screen, 'value' ) );

		// lodash isEmpty(): a numeric width counts as empty, so only a string width is kept.
		$width = ! BWFCRM_Email_Render_Js::is_empty( $value ) ? self::s( $value ) . '%' : '100%';

		switch ( null !== $alignment ? $alignment : '' ) {
			case 'right':
				$align_style = array( 'marginLeft' => 'auto' );
				break;
			case 'left':
				$align_style = array( 'marginRight' => 'auto' );
				break;
			default:
				$align_style = array( 'margin' => 'auto' );
		}

		$table = BWFCRM_Email_Renderer::element(
			'table',
			BWFCRM_Email_Renderer::table_props(
				array(
					'width' => $width,
					'style' => array( 'width' => $width ),
				)
			),
			BWFCRM_Email_Renderer::element(
				'tr',
				array(),
				BWFCRM_Email_Renderer::element(
					'td',
					array(
						'style' => array_merge(
							array(
								'height'      => '0',
								'line-height' => 0,
							),
							$align_style,
							self::divider_style( $block, $screen )
						),
					)
				)
			)
		);

		return '<tr>' . BWFCRM_Email_Renderer::element(
			'td',
			array(
				'className' => 'bwf-email-space-divider bwf-email-space-divider-' . self::s( self::a( $block, 'uniqueID' ) ),
				'align'     => null !== $alignment ? self::s( $alignment ) : 'center',
			),
			'<p class="bwf-email-space-divider-container"></p><!--[if mso | IE]>' . $table . '<![endif]-->'
		) . '</tr>';
	}

	/** The rule's border as a style object; the width keeps the editor's stray semicolon. */
	private static function divider_style( array $block, $screen ) {
		$height = self::at( self::a( $block, 'dividerHeight' ), $screen );
		$style  = array();

		if ( null === $height || '' === BWFCRM_Email_Render_Js::get( $height, 'value' ) ) {
			return $style;
		}

		$style['border-top-width'] = self::s( BWFCRM_Email_Render_Js::get( $height, 'value' ) ) . 'px;';

		$divider = self::at( self::a( $block, 'dividerStyle' ), $screen );
		$color   = self::at( self::a( $block, 'color' ), $screen );

		if ( null !== $divider ) {
			$style['border-top-style'] = $divider;
		}

		if ( null !== $color ) {
			$style['border-top-color'] = $color;
		}

		return $style;
	}

	public static function style( array $block, BWFCRM_Email_Render_Context $context ) {
		return self::media( self::desktop_css( $block, 'desktop' ), self::mobile_cell_css( $block, 'mobile' ) . self::mobile_container_css( $block, 'mobile' ) );
	}

	private static function alignment_css( array $block, $screen ) {
		$important = 'mobile' === $screen ? ' !important;' : '';
		$alignment = self::at( self::a( $block, 'alignment' ), $screen );

		if ( null === $alignment ) {
			return 'desktop' === $screen ? 'margin-left: auto' . $important . ';margin-right: auto' . $important . ';' : '';
		}

		switch ( $alignment ) {
			case 'right':
				return 'margin-left:auto' . $important . ';';
			case 'left':
				return 'margin-right:auto' . $important . ';';
			default:
				return 'margin-left: auto' . $important . ';margin-right: auto' . $important . ';';
		}
	}

	private static function divider_css( array $block, $screen ) {
		$height = self::at( self::a( $block, 'dividerHeight' ), $screen );

		if ( null === $height || '' === BWFCRM_Email_Render_Js::get( $height, 'value' ) ) {
			return '';
		}

		$divider = self::at( self::a( $block, 'dividerStyle' ), $screen );
		$color   = self::at( self::a( $block, 'color' ), $screen );

		return 'border-top-width: ' . self::s( BWFCRM_Email_Render_Js::get( $height, 'value' ) ) . 'px;'
			. ( null !== $divider ? 'border-top-style: ' . self::s( $divider ) . ';' : '' )
			. ( null !== $color ? 'border-top-color: ' . self::s( $color ) . ';' : '' );
	}

	private static function max_width( array $block, $screen ) {
		$width = self::at( self::a( $block, 'dividerWidth' ), $screen );

		return null !== $width ? BWFCRM_Email_Render_Css::unit_value( $width, 'max-width', '%' ) : '';
	}

	private static function desktop_css( array $block, $screen ) {
		$selector = '.bwf-email-space-divider.bwf-email-space-divider-' . self::s( self::a( $block, 'uniqueID' ) );
		$padding  = self::at( self::a( $block, 'padding' ), $screen );

		return '
        ' . $selector . ' {
            ' . ( null !== $padding ? BWFCRM_Email_Render_Css::padding( $padding ) : '' ) . '
            ' . ( null !== $padding ? BWFCRM_Email_Render_Css::padding( $padding, false, true ) : '' ) . '
            font-size:0px;
            word-break:break-word;
            word-break:break-word;
        }
        ' . $selector . ' .bwf-email-space-divider-container {
            width: 100%;
            margin-top: auto;
            margin-bottom:auto;
            ' . self::max_width( $block, $screen ) . '
            ' . self::divider_css( $block, $screen ) . '
            ' . self::alignment_css( $block, $screen ) . '
        }

		' . BWFCRM_Email_Renderer::visibility_css( $selector, $block, $screen ) . '
    ';
	}

	private static function mobile_cell_css( array $block, $screen ) {
		$selector = '.bwf-email-space-divider.bwf-email-space-divider-' . self::s( self::a( $block, 'uniqueID' ) );
		$padding  = self::at( self::a( $block, 'padding' ), $screen );

		return '
		' . $selector . ' {
			' . ( null !== $padding ? BWFCRM_Email_Render_Css::padding( $padding, true ) : '' ) . '
            ' . self::alignment_css( $block, $screen ) . '
		}';
	}

	private static function mobile_container_css( array $block, $screen ) {
		$selector = '.bwf-email-space-divider.bwf-email-space-divider-' . self::s( self::a( $block, 'uniqueID' ) );

		return '
        ' . $selector . ' .bwf-email-space-divider-container {
            ' . self::max_width( $block, $screen ) . '
            ' . self::alignment_css( $block, $screen ) . '
        }

		' . BWFCRM_Email_Renderer::visibility_css( $selector, $block, $screen ) . '
    ';
	}
}
