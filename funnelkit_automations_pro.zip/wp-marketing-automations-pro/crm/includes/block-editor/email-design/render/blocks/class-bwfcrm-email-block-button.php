<?php

defined( 'ABSPATH' ) || exit;

/** email-block/button: a link styled as a button, Global Style by default. */
class BWFCRM_Email_Block_Button extends BWFCRM_Email_Block {

	public static function html( array $block, $inner, BWFCRM_Email_Render_Context $context, $responsive ) {
		$screen    = 'desktop';
		$alignment = self::a( $block, 'alignment' );
		$content   = self::a( $block, 'content', '' );
		$url       = self::a( $block, 'url', '' );
		$target    = self::a( $block, 'target' );
		$padding   = self::a( $block, 'containerPadding', array() );
		$left      = BWFCRM_Email_Render_Js::get( $padding, array( $screen, 'left' ) );
		$span_tag  = self::t( $padding ) && self::t( BWFCRM_Email_Render_Js::get( $padding, array( $screen ) ) ) && self::t( $left ) ? 'span' : '';
		$align     = self::t( $alignment ) && self::t( BWFCRM_Email_Render_Js::get( $alignment, array( $screen ) ) ) ? BWFCRM_Email_Render_Js::get( $alignment, array( $screen ) ) : 'center';
		$content   = BWFCRM_Email_Render_Js::UNDEFINED === $content ? '' : self::s( $content );

		if ( '' !== $url ) {
			$link = BWFCRM_Email_Renderer::element(
				'a',
				array(
					'href'      => $url,
					'target'    => self::t( $target ) ? $target : '_blank',
					'className' => 'bwfbe-block-btn-content',
				),
				$content
			);
		} else {
			$link = BWFCRM_Email_Renderer::element( 'p', array( 'className' => 'bwfbe-block-btn-content' ), $content );
		}

		$table = BWFCRM_Email_Renderer::element(
			'table',
			BWFCRM_Email_Renderer::table_props(
				array(
					'role'      => 'presentation',
					'style'     => array( 'borderCollapse' => 'separate' ),
					'className' => 'bwfbe-block-btn-container',
				),
				true
			),
			'<tbody><tr>' . BWFCRM_Email_Renderer::element( 'td', array( 'className' => 'bwfbe-btn-text-wrap' ), $link ) . '</tr></tbody>'
		);

		$children = '<![endif]-->' . $table . '<!--[if mso | IE]>';

		// With no left container padding the editor's tag name is empty, which renders the children alone.
		$span = '' !== $span_tag
			? BWFCRM_Email_Renderer::element( $span_tag, array( 'style' => array( 'marginLeft' => self::s( $left ) . 'px' ) ), $children )
			: $children;

		return '<tr>' . BWFCRM_Email_Renderer::element(
			'td',
			array(
				'className' => 'bwfbe-block-btn bwfbe-block-btn-' . self::s( self::a( $block, 'uniqueID' ) ),
				'align'     => $align,
			),
			'<!--[if mso | IE]>' . $span . '<![endif]-->'
		) . '</tr>';
	}

	public static function style( array $block, BWFCRM_Email_Render_Context $context ) {
		return self::media( self::desktop_css( $block, $context, 'desktop' ), self::mobile_css( $block, $context, 'mobile' ) );
	}

	/** `{ ...value }` for a settings object; anything else spreads to nothing. */
	private static function spread( $value ) {
		if ( is_object( $value ) ) {
			$value = get_object_vars( $value );
		}

		return is_array( $value ) ? $value : array();
	}

	/** `obj && obj[ screen ] && obj[ screen ][ key ]` */
	private static function deep( $value, $screen, $key ) {
		$inner = self::at( $value, $screen );

		if ( null === $inner ) {
			return null;
		}

		$leaf = BWFCRM_Email_Render_Js::get( $inner, array( $key ) );

		return self::t( $leaf ) ? $leaf : null;
	}

	/** buttonAuto / buttonWidthMerge: the Global Style's button width, overlaid with the block's own. */
	private static function width_rule( array $block, BWFCRM_Email_Render_Context $context, $screen, $important ) {
		$auto  = array_merge( self::spread( BWFCRM_Email_Render_Js::get( $context->global, 'buttonAuto', null ) ), self::spread( self::a( $block, 'autoWidth' ) ) );
		$merge = array_merge( self::spread( BWFCRM_Email_Render_Js::get( $context->global, 'buttonSize', null ) ), self::spread( self::a( $block, 'widthPercent' ) ) );
		$imp   = $important ? ' !important' : '';

		if ( self::t( BWFCRM_Email_Render_Js::get( $auto, array( $screen ) ) ) ) {
			return 'width:auto' . $imp . ';';
		}

		$size = BWFCRM_Email_Render_Js::get( $merge, array( $screen ) );

		if ( ! self::t( $size ) ) {
			return '';
		}

		$value = BWFCRM_Email_Render_Js::get( $size, array( 'value' ) );

		return 'width:' . self::s( self::t( $value ) ? $value : $size ) . '%' . $imp . ';';
	}

	private static function desktop_css( array $block, BWFCRM_Email_Render_Context $context, $screen ) {
		$global     = $context->global;
		$selector   = '.bwfbe-block-btn.bwfbe-block-btn-' . self::s( self::a( $block, 'uniqueID' ) );
		$padding    = self::at( self::a( $block, 'padding' ), $screen );
		$container  = self::at( self::a( $block, 'containerPadding' ), $screen );
		$bg_color   = self::at( self::a( $block, 'bgColor' ), $screen );
		$color      = self::at( self::a( $block, 'color' ), $screen );
		$text_align = self::at( self::a( $block, 'textAlignment' ), $screen );
		$size       = self::deep( self::a( $block, 'font' ), $screen, 'size' );
		$family     = self::deep( self::a( $block, 'font' ), $screen, 'family' );
		$border     = BWFCRM_Email_Render_Js::get( self::a( $block, 'border' ), array( $screen ), array() );
		$radius_var = $context->saving ? 'var(--bwfbe-buttonBorder-desktop-radius)' : false;
		$g_border   = BWFCRM_Email_Render_Js::get( $global, 'buttonBorder.' . $screen );
		$g_padding  = BWFCRM_Email_Render_Js::get( $global, 'buttonPadding.' . $screen );

		if ( $context->saving && ! self::t( self::a( $block, 'widthPercent' ) ) ) {
			$width = 'width: var(--bwfbe-buttonWidth-desktop-value);';
		} else {
			$width = self::width_rule( $block, $context, $screen, false );
		}

		$background = null !== $bg_color ? 'background-color: ' . self::s( $bg_color ) . ';' : BWFCRM_Email_Renderer::global_css( $global, 'buttonBackground', $screen, '', false, $context );
		$font_size  = null !== $size ? 'font-size: ' . self::s( $size ) . 'px;' : BWFCRM_Email_Renderer::global_css( $global, 'buttonFont', $screen, 'size', false, $context );

		if ( null !== $padding ) {
			$wrap_padding    = BWFCRM_Email_Render_Css::padding( $padding, false, true );
			$content_padding = BWFCRM_Email_Render_Css::padding( $padding, false, false );
		} elseif ( $context->saving ) {
			$wrap_padding    = 'mso-padding-alt:var(--bwfbe-buttonPadding-desktop);';
			$content_padding = 'padding:var(--bwfbe-buttonPadding-desktop);';
		} else {
			$wrap_padding    = BWFCRM_Email_Render_Css::padding( $g_padding, false, true );
			$content_padding = BWFCRM_Email_Render_Css::padding( $g_padding, false, false );
		}

		return '

        ' . $selector . ' {
			' . ( null !== $container ? BWFCRM_Email_Render_Css::padding( $container, false ) : '' ) . '
			' . ( null !== $container ? BWFCRM_Email_Render_Css::padding( $container, false, true ) : '' ) . '


        }
		' . $selector . ' .bwfbe-block-btn-container {
			' . $width . '
		}
		' . $selector . ' .bwfbe-block-btn-container .bwfbe-btn-text-wrap {
			font-size:16px;
			cursor:auto;
			border-style:none;
			' . $background . '
			' . $font_size . '
            ' . BWFCRM_Email_Render_Css::border( $border, false, $g_border, $radius_var ) . '
			mso-padding-alt: 10px 20px;
			' . $wrap_padding . '
			' . ( null !== $text_align ? 'text-align: ' . self::s( $text_align ) . ';' : '' ) . '
			line-height: 1.5;

		}
		' . $selector . ' .bwfbe-block-btn-container .bwfbe-block-btn-content {
			line-height: 1.5;
			text-decoration: none;
			padding: 10px 20px;
			' . $content_padding . '
			mso-padding-alt:0;
			' . $background . '
			' . $font_size . '
			' . ( null !== $family && '' !== $family ? 'font-family: ' . self::s( $family ) . BWFCRM_Email_Renderer::backup_font( $global, $family, $context ) . ';' : BWFCRM_Email_Renderer::global_css( $global, 'font', $screen, 'family', false, $context ) ) . '
			display: inline-block;
			text-decoration: none;
			text-transform:none;
			' . ( null !== $color ? 'color: ' . self::s( $color ) . ';' : BWFCRM_Email_Renderer::global_css( $global, 'buttonColor', $screen, '', false, $context ) ) . '
			' . BWFCRM_Email_Render_Css::border_radius( $border, false, $g_border, $radius_var ) . '
		}

		' . BWFCRM_Email_Renderer::visibility_css( $selector, $block, $screen ) . '
    ';
	}

	private static function mobile_css( array $block, BWFCRM_Email_Render_Context $context, $screen ) {
		$global     = $context->global;
		$selector   = '.bwfbe-block-btn.bwfbe-block-btn-' . self::s( self::a( $block, 'uniqueID' ) );
		$padding    = self::at( self::a( $block, 'padding' ), $screen );
		$container  = self::at( self::a( $block, 'containerPadding' ), $screen );
		$alignment  = self::at( self::a( $block, 'alignment' ), $screen );
		$bg_color   = self::at( self::a( $block, 'bgColor' ), $screen );
		$color      = self::at( self::a( $block, 'color' ), $screen );
		$text_align = self::at( self::a( $block, 'textAlignment' ), $screen );
		$border     = self::at( self::a( $block, 'border' ), $screen );
		$size       = self::deep( self::a( $block, 'font' ), $screen, 'size' );
		$family     = self::deep( self::a( $block, 'font' ), $screen, 'family' );
		$radius     = self::a( $block, 'borderRadius' );

		// The editor passes `true` where the sub-setting name goes; kept as it is.
		$background = null !== $bg_color ? 'background-color: ' . self::s( $bg_color ) . ' !important;' : BWFCRM_Email_Renderer::global_css( $global, 'buttonBackground', $screen, true, false, $context );

		return '

        ' . $selector . ' {
			' . ( null !== $container ? BWFCRM_Email_Render_Css::padding( $container, true ) : '' ) . '
			text-align: ' . ( null !== $alignment ? '-webkit-' . self::s( $alignment ) . ' !important' : '' ) . '; 
        }
		' . $selector . ' .bwfbe-block-btn-container {
			' . self::width_rule( $block, $context, $screen, true ) . '
			' . ( null !== $alignment ? self::alignment_css( $alignment, true ) : '' ) . '
		}
		' . $selector . ' .bwfbe-block-btn-container .bwfbe-btn-text-wrap {
			' . $background . '
			' . ( null !== $size ? 'font-size: ' . self::s( $size ) . 'px  !important;' : BWFCRM_Email_Renderer::global_css( $global, 'buttonFont', $screen, 'size', true, $context ) ) . '
			' . ( null !== $family && '' !== $family ? 'font-family: ' . self::s( $family ) . ' !important;' : BWFCRM_Email_Renderer::global_css( $global, 'font', $screen, 'family', false, $context ) ) . '
            ' . ( null !== $border ? BWFCRM_Email_Render_Css::border( $border, true ) : '' ) . '
			' . ( null !== $text_align ? 'text-align: ' . self::s( $text_align ) . ' !important;' : '' ) . '

		}
		' . $selector . ' .bwfbe-block-btn-container .bwfbe-block-btn-content {
			' . ( null !== $padding ? BWFCRM_Email_Render_Css::padding( $padding, true, false ) : '' ) . '
			mso-padding-alt:0;
			' . $background . '
			' . ( null !== $size ? 'font-size: ' . self::s( $size ) . 'px !important;' : BWFCRM_Email_Renderer::global_css( $global, 'buttonFont', $screen, 'size', true, $context ) ) . '
			' . ( null !== $color ? 'color: ' . self::s( $color ) . ' !important;' : BWFCRM_Email_Renderer::global_css( $global, 'buttonColor', $screen, true, false, $context ) ) . '
			' . ( self::t( $radius ) ? 'border-radius: ' . self::s( $radius ) . ' !important;' : '' ) . '
			' . ( null !== $family ? 'font-family: ' . self::s( $family ) . ' !important;' : BWFCRM_Email_Renderer::global_css( $global, 'font', $screen, 'family', true, $context ) ) . '
		}

		' . BWFCRM_Email_Renderer::visibility_css( $selector, $block, $screen ) . '
    ';
	}

	/** alignmentCss() */
	public static function alignment_css( $alignment, $important = false ) {
		$imp = $important ? ' !important' : '';

		switch ( $alignment ) {
			case 'center':
				return 'margin-right: auto' . $imp . ';margin-left:auto' . $imp . ';';
			case 'left':
				return 'margin-right: auto' . $imp . ';margin-left:0' . $imp . ';';
			case 'right':
				return 'margin-left: auto' . $imp . ';margin-right:0' . $imp . ';';
		}

		return '';
	}
}
