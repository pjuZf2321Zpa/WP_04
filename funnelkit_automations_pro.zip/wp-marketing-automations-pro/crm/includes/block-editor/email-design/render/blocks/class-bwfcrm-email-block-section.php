<?php

defined( 'ABSPATH' ) || exit;

/** email-block/section: the centred content box holding a row's columns. */
class BWFCRM_Email_Block_Section extends BWFCRM_Email_Block {

	public static function html( array $block, $inner, BWFCRM_Email_Render_Context $context, $responsive ) {
		$global      = $context->global;
		$stacks      = self::t( self::a( $block, 'responsive' ) );
		$padding     = self::a( $block, 'padding' );
		$image_url   = self::a( $block, 'contentBackground.desktop.image.url' );
		$row_bg      = self::a( $block, 'contentBackground.desktop.color' );
		$row_bg_img  = self::t( $image_url ) ? self::s( $image_url ) : '';
		$row_bg      = self::t( $row_bg ) ? self::s( $row_bg ) : '';
		// The editor reads the width off the selector function, not its result, so it is always 640.
		$row_width   = '640px';
		$align       = $context->uses_variable( 'align' )
			? 'var(--bwfbe-align-desktop)'
			: ( self::t( BWFCRM_Email_Render_Js::get( $global, 'align.desktop' ) ) ? BWFCRM_Email_Render_Js::get( $global, 'align.desktop' ) : 'center' );
		$left_margin = self::s( BWFCRM_Email_Render_Js::get( $padding, 'desktop.left' ) ) . 'px';

		$columns_table = static function () use ( $inner, $stacks ) {
			return ( $stacks ? '<!--[if mso | IE]>' : '' )
				. BWFCRM_Email_Renderer::element(
					'table',
					BWFCRM_Email_Renderer::table_props(
						array(
							'role'        => 'presentation',
							'border'      => '0',
							'cellpadding' => '0',
							'cellspacing' => '0',
							'style'       => array( 'borderCollapse' => 'separate' ),
						)
					),
					'<tbody><tr>' . ( $stacks ? '<![endif]-->' : '' ) . $inner . ( $stacks ? '<!--[if mso | IE]>' : '' ) . '</tr></tbody>'
				)
				. ( $stacks ? '<![endif]-->' : '' );
		};

		$cell = '' !== $row_bg_img
			? '<!--[if mso | IE]>' . BWFCRM_Email_Renderer::element( 'span', array( 'style' => array( 'marginLeft' => $left_margin ) ), '<![endif]-->' . $columns_table() . '<!--[if mso | IE]>' ) . '<![endif]-->'
			: $columns_table();

		$inner_props = array(
			'align'     => 'center',
			'width'     => str_replace( 'px', '', $row_width ),
			'className' => 'bwfbe-block-section-inner-container',
		);

		if ( '' !== $row_bg_img ) {
			$inner_props['background'] = $row_bg_img;
		}

		if ( $context->rtl ) {
			$inner_props['dir'] = 'rtl';
		}

		$inner_props['style'] = array( 'borderCollapse' => 'separate' );

		$container = BWFCRM_Email_Renderer::element(
			'div',
			array( 'className' => 'bwfbe-block-section-outer-container' ),
			BWFCRM_Email_Renderer::element(
				'table',
				BWFCRM_Email_Renderer::table_props( $inner_props ),
				'<tbody><tr><td>' . $cell . '</td></tr></tbody>'
			)
		);

		$mso = '' !== $row_bg_img
			? '<v:rect style="width:' . $row_width . ';" xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false"><v:fill origin="0, -0.5" position="0, -0.5" src="' . BWFCRM_Email_Renderer::attr( $row_bg_img ) . '" color="' . BWFCRM_Email_Renderer::attr( $row_bg ) . '" type="frame" size="1,1" aspect="atleast" /><v:textbox style="mso-fit-shape-to-text:true" inset="0,0,0,0"><![endif]-->' . $container . '<!--[if mso | IE]></v:textbox></v:rect><![endif]-->'
			: '<![endif]-->' . $container;

		$outer_cell = '<!--[if mso | IE]>'
			. BWFCRM_Email_Renderer::element(
				'table',
				BWFCRM_Email_Renderer::table_props( array( 'align' => 'center', 'width' => str_replace( 'px', '', $row_width ) ) ),
				'<tr>' . BWFCRM_Email_Renderer::element(
					'td',
					array(
						'style' => array(
							'lineHeight'           => 0,
							'fontSize'             => 0,
							'mso-line-height-rule' => 'exactly',
						),
					),
					$mso . '<!--[if mso | IE]>'
				) . '</tr>'
			)
			. '<![endif]-->';

		return BWFCRM_Email_Renderer::element(
			'table',
			BWFCRM_Email_Renderer::table_props(
				array(
					'align'     => $align,
					'className' => 'bwfbe-block-section-container bwfbe-block-section bwfbe-block-' . self::s( self::a( $block, 'uniqueID' ) ),
				),
				true
			),
			'<tbody><tr><td>' . $outer_cell . '</td></tr></tbody>'
		);
	}

	/**
	 * The section's background: its own colour, else the email's content
	 * background (its CSS variable while saving).
	 */
	private static function background( $content_background, $screen, $global, $default, BWFCRM_Email_Render_Context $context, $saving = true ) {
		$background = BWFCRM_Email_Render_Js::plain( $content_background );
		$background = is_array( $background ) ? $background : array();

		if ( ! self::t( BWFCRM_Email_Render_Js::get( $background, array( $screen, 'color' ) ) ) ) {
			if ( ! isset( $background[ $screen ] ) || ! is_array( $background[ $screen ] ) ) {
				$background[ $screen ] = array();
			}

			$background[ $screen ]['color'] = $saving && $context->uses_variable( 'background' )
				? 'var(--bwfbe-contentBackground-desktop-color)'
				: BWFCRM_Email_Render_Js::get( $global, array( 'contentBackground', $screen, 'color' ) );
		}

		if ( self::t( $background ) && self::t( BWFCRM_Email_Render_Js::get( $background, array( $screen ) ) ) ) {
			return BWFCRM_Email_Render_Css::background( $background[ $screen ] );
		}

		return self::t( $default ) ? 'background-color: ' . self::s( $default ) : '';
	}

	public static function style( array $block, BWFCRM_Email_Render_Context $context ) {
		return self::media( self::desktop_css( $block, $context, 'desktop' ), self::mobile_css( $block, $context, 'mobile' ) );
	}

	private static function desktop_css( array $block, BWFCRM_Email_Render_Context $context, $screen ) {
		$global    = $context->global;
		$border    = self::a( $block, 'border' );
		$padding   = self::a( $block, 'padding' );
		$selector  = '.bwfbe-block-section.bwfbe-block-' . self::s( self::a( $block, 'uniqueID' ) ) . '.bwfbe-block-section-container';
		$container = self::s( BWFCRM_Email_Render_Js::get( $global, 'width.desktop.value', '640' ) ) . 'px';
		$bg        = self::background( self::a( $block, 'contentBackground' ), $screen, $global, false, $context );
		$b         = self::at( $border, $screen );
		$radius    = null !== $b ? BWFCRM_Email_Render_Css::border_radius( $b ) : '';
		$p         = self::at( $padding, $screen );

		return '
        ' . $selector . ' {
            width: ' . $container . ';
        }
        ' . $selector . ' > tbody > tr > td {
            ' . $bg . '
            ' . $radius . '
        }
        ' . $selector . ' .bwfbe-block-section-outer-container {
            margin: 0 auto;
            width: ' . $container . ';
            ' . $bg . '
            ' . $radius . '
        }
        ' . $selector . ' .bwfbe-block-section-outer-container > div {
            line-height:0;
            font-size:0;
        }
        ' . $selector . ' .bwfbe-block-section-outer-container .bwfbe-block-section-inner-container {
            width: 100%;
            line-height:normal;
            ' . $bg . '
            ' . $radius . '
        }
        ' . $selector . ' .bwfbe-block-section-outer-container .bwfbe-block-section-inner-container > tbody > tr > td {
            font-size:0px;
            border-collapse: separate;
            ' . ( null !== $p ? BWFCRM_Email_Render_Css::space( $p ) : '' ) . '
            ' . ( null !== $p ? BWFCRM_Email_Render_Css::space( $p, 'padding', true ) : '' ) . '
            ' . ( null !== $b ? BWFCRM_Email_Render_Css::border( $b ) : '' ) . '
        }
        ' . $selector . ' .bwfbe-block-section-inner-container > tbody > tr > td > div {
            font-size:0px;
            border-collapse: separate;
        }
        ' . BWFCRM_Email_Renderer::visibility_css( $selector, $block, $screen ) . '
    ';
	}

	private static function mobile_css( array $block, BWFCRM_Email_Render_Context $context, $screen ) {
		$global   = $context->global;
		$border   = self::at( self::a( $block, 'border' ), $screen );
		$padding  = self::at( self::a( $block, 'padding' ), $screen );
		$selector = '.bwfbe-block-section.bwfbe-block-' . self::s( self::a( $block, 'uniqueID' ) );
		// The mobile rules call the helper without the save state: no CSS variable here.
		$bg       = self::background( self::a( $block, 'contentBackground' ), $screen, $global, BWFCRM_Email_Render_Js::UNDEFINED, $context, false );
		$radius   = null !== $border ? BWFCRM_Email_Render_Css::border_radius( $border, true ) : '';

		return '
        ' . $selector . ' .bwfbe-block-section-inner-container > tbody > tr > td {
            ' . ( null !== $padding ? BWFCRM_Email_Render_Css::space( $padding, 'padding', false, true ) : '' ) . '
            ' . ( null !== $border ? BWFCRM_Email_Render_Css::border( $border, true ) : '' ) . '
        }
        ' . $selector . ' > tbody > tr > td {
            ' . $bg . '
            ' . $radius . '
        }
        ' . $selector . ' .bwfbe-block-section-outer-container {
            ' . $bg . '
            ' . $radius . '
        }
        ' . $selector . ' .bwfbe-block-section-outer-container .bwfbe-block-section-inner-container {
            ' . $bg . '
            ' . $radius . '
        }
        ' . BWFCRM_Email_Renderer::visibility_css( $selector, $block, $screen ) . '
    ';
	}
}
