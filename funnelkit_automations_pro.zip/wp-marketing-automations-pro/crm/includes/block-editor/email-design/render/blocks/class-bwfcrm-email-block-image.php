<?php

defined( 'ABSPATH' ) || exit;

/** email-block/image: an image, optionally linked. */
class BWFCRM_Email_Block_Image extends BWFCRM_Email_Block {

	/** Class prefix of the block's cell and of its image wrap. */
	const SLUG = 'image';

	/** The width attribute's key for the percentage (image: width, site logo: value). */
	const WIDTH_KEY = 'width';

	public static function html( array $block, $inner, BWFCRM_Email_Render_Context $context, $responsive ) {
		$url   = self::a( $block, 'url', '' );
		$image = self::a( $block, 'image', array() );
		$alt   = BWFCRM_Email_Render_Js::get( $image, 'alt' );

		// PreviewImage keeps the original URL while saving.
		$img = BWFCRM_Email_Renderer::element(
			'img',
			array(
				'src'   => BWFCRM_Email_Render_Js::get( $image, 'url' ),
				'alt'   => self::t( $alt ) ? $alt : ' ',
				'title' => $alt,
			)
		);

		if ( self::t( $url ) ) {
			$target = self::a( $block, 'target' );
			$img    = BWFCRM_Email_Renderer::element(
				'a',
				array(
					'href'   => $url,
					'target' => self::t( $target ) ? $target : '_blank',
				),
				$img
			);
		}

		return static::cell( $block, $img );
	}

	/** The block's cell around the (linked) image. */
	protected static function cell( array $block, $content ) {
		$alignment = self::a( $block, 'alignment' );
		$align     = self::at( $alignment, 'desktop' );

		return '<tr>' . BWFCRM_Email_Renderer::element(
			'td',
			array( 'className' => 'bwfbe-block-' . static::SLUG . ' bwfbe-block-' . static::SLUG . '-' . self::s( self::a( $block, 'uniqueID' ) ) ),
			BWFCRM_Email_Renderer::element(
				'table',
				BWFCRM_Email_Renderer::table_props( array( 'align' => null !== $align ? $align : 'center' ), true ),
				'<tbody><tr>' . BWFCRM_Email_Renderer::element( 'td', array( 'className' => 'bwf-email-' . static::SLUG . '_wrap' ), $content ) . '</tr></tbody>'
			)
		) . '</tr>';
	}

	public static function style( array $block, BWFCRM_Email_Render_Context $context ) {
		return self::media( static::screen_css( $block, 'desktop' ), static::screen_css( $block, 'mobile' ) );
	}

	/** getWidthUnit() */
	protected static function width_unit( array $block, $screen ) {
		$unit = self::a( $block, 'widthUnit' );

		if ( self::t( BWFCRM_Email_Render_Js::get( $unit, array( $screen ) ) ) ) {
			return BWFCRM_Email_Render_Js::get( $unit, array( $screen ) );
		}

		return self::t( BWFCRM_Email_Render_Js::get( $unit, array( 'desktop' ) ) ) ? BWFCRM_Email_Render_Js::get( $unit, array( 'desktop' ) ) : '%';
	}

	/** getMobileWidth() / getWidth(): the image width on mobile. */
	protected static function mobile_width( array $block, $screen ) {
		if ( 'mobile' !== $screen ) {
			return '';
		}

		$auto  = self::a( $block, 'autoWidth' );
		$width = self::a( $block, 'width' );

		if ( 'px' === static::width_unit( $block, $screen ) ) {
			if ( self::t( BWFCRM_Email_Render_Js::get( $auto, array( $screen ) ) ) ) {
				return 'width:auto !important;';
			}

			$image_width = self::a( $block, 'imageWidth' );
			$val         = BWFCRM_Email_Render_Js::get( $image_width, array( $screen ) );
			$val         = self::t( $val ) ? $val : BWFCRM_Email_Render_Js::get( $image_width, array( 'desktop' ) );
			$val         = self::t( $val ) ? $val : '';

			return self::t( $val ) ? 'width:' . self::s( $val ) . 'px !important;' : 'width:auto !important;';
		}

		$percent = BWFCRM_Email_Render_Js::get( $width, array( $screen, static::WIDTH_KEY ) );
		$val     = self::t( $width ) && self::t( BWFCRM_Email_Render_Js::get( $width, array( $screen ) ) ) && self::t( $percent ) ? $percent : '100';

		if ( self::t( $width ) && self::t( BWFCRM_Email_Render_Js::get( $width, array( $screen ) ) ) && ! self::t( BWFCRM_Email_Render_Js::get( $auto, array( $screen ) ) ) ) {
			return 'width:' . self::s( $val ) . '% !important;';
		}

		if ( self::t( BWFCRM_Email_Render_Js::get( $auto, array( $screen ) ) ) ) {
			return 'width:auto !important;';
		}

		$desktop = BWFCRM_Email_Render_Js::get( $width, array( 'desktop', static::WIDTH_KEY ) );

		return self::t( $width ) && self::t( BWFCRM_Email_Render_Js::get( $width, array( 'desktop' ) ) ) && ! self::t( BWFCRM_Email_Render_Js::get( $auto, array( 'desktop' ) ) ) && self::t( $desktop )
			? 'width:' . self::s( $desktop ) . '% !important;'
			: '';
	}

	/** The image's own width rule: an image that failed to load has none (image block only). */
	protected static function image_width_css( array $block, $screen ) {
		if ( self::t( self::a( $block, 'error' ) ) ) {
			return 'width: 0;';
		}

		$image_width = self::at( self::a( $block, 'imageWidth' ), $screen );

		return 'desktop' === $screen && null !== $image_width ? 'width:' . self::s( $image_width ) . 'px;' : '';
	}

	/** alignmentCss() */
	protected static function alignment_css( $alignment, $important = false ) {
		$imp = $important ? ' !important' : '';

		switch ( $alignment ) {
			case 'center':
				return 'margin-right: auto' . $imp . ';margin-left:auto' . $imp . ';';
			case 'left':
				return 'margin-right: auto' . $imp . ';margin-left:0' . $imp . ';';
			case 'right':
				return 'margin-left: auto' . $imp . ';margin-right:0' . $imp . ';';
		}

		return '';
	}

	protected static function screen_css( array $block, $screen ) {
		$mobile    = 'mobile' === $screen;
		$selector  = '.bwfbe-block-' . static::SLUG . '.bwfbe-block-' . static::SLUG . '-' . self::s( self::a( $block, 'uniqueID' ) );
		$padding   = self::at( self::a( $block, 'padding' ), $screen );
		$border    = self::at( self::a( $block, 'border' ), $screen );
		$alignment = self::a( $block, 'alignment' );
		$align     = self::at( $alignment, $screen );
		$table     = '';

		if ( $mobile && self::t( $alignment ) ) {
			$align_mobile = BWFCRM_Email_Render_Js::get( $alignment, array( 'mobile' ) );

			if ( self::t( $align_mobile ) ) {
				$table = 'center' === $align_mobile ? 'margin-left: auto !important; margin-right: auto !important; float:none !important;' : 'float: ' . self::s( $align_mobile ) . ' !important;';
			}
		}

		if ( null !== $align ) {
			$wrap_align = 'text-align: ' . self::s( $align ) . ' ' . ( $mobile ? '!important' : '' ) . ';';
			$img_align  = self::alignment_css( $align, $mobile );
		} else {
			$wrap_align = 'desktop' === $screen ? 'text-align:center;' : '';
			$img_align  = 'desktop' === $screen ? 'margin-right: auto;margin-left:auto;' : '';
		}

		return $selector . '{
        ' . ( null !== $padding ? '
		' . BWFCRM_Email_Render_Css::padding( $padding, $mobile ) . '
		' . BWFCRM_Email_Render_Css::padding( $padding, $mobile, true ) . '
		' : '' ) . '
    }
	' . $selector . ' > table {
		' . $table . '
	}
    ' . $selector . ' img{
        ' . ( 'desktop' === $screen ? '
			height: auto;
			display: block;
			text-decoration:none;
			max-width: 100%;
			font-size:13px;
			border:0;
			outline:none;
			box-sizing:border-box;
		' : '' ) . '
    }
	' . $selector . ' .bwf-email-' . static::SLUG . '_wrap {
		width: 100% ' . ( $mobile ? '!important' : '' ) . ';
		' . $wrap_align . '
	}
	' . $selector . ' img {
		' . static::image_width_css( $block, $screen ) . '
		' . $img_align . '
		' . static::mobile_width( $block, $screen ) . '
		' . ( null !== $border ? BWFCRM_Email_Render_Css::border( $border ) : '' ) . '
	}

	' . BWFCRM_Email_Renderer::visibility_css( $selector, $block, $screen ) . '
    ';
	}
}
