<?php

defined( 'ABSPATH' ) || exit;

/**
 * email-block/best-selling-product: a grid or list of products. Dynamic -
 * while saving, the editor writes only the multi-product shortcode and no CSS;
 * send time picks and renders the products. Switched off (onBoarding false),
 * it writes nothing.
 */
class BWFCRM_Email_Block_Best_Selling_Product extends BWFCRM_Email_Block {

	public static function html( array $block, $inner, BWFCRM_Email_Render_Context $context, $responsive ) {
		if ( ! self::t( self::a( $block, 'onBoarding' ) ) ) {
			return '';
		}

		return BWFCRM_Email_Renderer::dynamic_shortcode( 'bwfbe_multi_product', $block, $context, ' type="best_selling_products"', array( 'hasWCChildSelected' => false ) );
	}
}
