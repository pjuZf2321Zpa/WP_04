<?php

defined( 'ABSPATH' ) || exit;

/** email-block/menu: a row or column of text links. */
class BWFCRM_Email_Block_Menu extends BWFCRM_Email_Block {

	public static function html( array $block, $inner, BWFCRM_Email_Render_Context $context, $responsive ) {
		$screen     = 'desktop';
		$container  = self::a( $block, 'containerPadding' );
		$left       = BWFCRM_Email_Render_Js::get( $container, array( $screen, 'left' ) );
		$space_left = null !== self::at( $container, $screen ) && self::t( $left ) ? self::s( $left ) . 'px' : '';
		$layout     = self::a( $block, 'layout' );
		$horizontal = 'horizontal' === BWFCRM_Email_Render_Js::get( $layout, array( $screen ) );
		$alignment  = self::at( self::a( $block, 'alignment' ), $screen );
		$align      = null !== $alignment ? $alignment : 'center';
		$items      = self::a( $block, 'menuItems', array() );
		$items      = is_array( $items ) ? array_values( $items ) : array();
		$separator  = self::a( $block, 'separator' );
		$show_sep   = self::t( self::a( $block, 'showSeparator' ) );

		// `layout.hasOwnProperty( screen ) ? layout[ screen ] : layout.desktop` - desktop either way.
		$sep_layout = $horizontal;

		$menu = '';

		foreach ( $items as $index => $item ) {
			$children = self::item_html( $item, $index );

			if ( '' !== $separator && $show_sep && $sep_layout && count( $items ) - 1 !== $index ) {
				$children .= '<!--[if mso | IE]><td><![endif]--><span id="separator">' . self::child( $separator ) . '</span><!--[if mso | IE]></td><![endif]-->';
			}

			$menu .= self::layout_tags( $block, $children );
		}

		// LayoutTag is '' outside a horizontal menu: its children render without a wrapper.
		$layout_inner = '<![endif]-->' . $menu . '<!--[if mso | IE]>';
		$layout_tag   = $horizontal ? '<tr>' . $layout_inner . '</tr>' : $layout_inner;

		$table_props = array(
			'rolw'  => 'presentation',
			'style' => array( 'verticalAlign' => 'top' ),
		);

		if ( $context->rtl ) {
			$table_props['dir'] = 'rtl';
		}

		$table = BWFCRM_Email_Renderer::element(
			'table',
			BWFCRM_Email_Renderer::table_props( $table_props ),
			'<tbody><tr>'
			. BWFCRM_Email_Renderer::element(
				'td',
				array(
					'className' => 'bwf-email-menu-container',
					'style'     => array( 'text-align' => $align ),
				),
				'<!--[if mso | IE]>'
				. BWFCRM_Email_Renderer::element(
					'table',
					BWFCRM_Email_Renderer::table_props(
						array(
							'style' => array( 'text-align' => $align ),
							'align' => $align,
						),
						true
					),
					$layout_tag
				)
				. '<![endif]-->'
			)
			. '</tr></tbody>'
		);

		// SpanTag is '' unless the section has a background image: its children render without a wrapper.
		$span_inner = '<![endif]-->' . $table . '<!--[if mso | IE]>';
		$span       = self::t( self::a( $block, 'rowHasBgImage' ) ) && '' !== $space_left
			? BWFCRM_Email_Renderer::element( 'span', array( 'style' => array( 'marginLeft' => $space_left ) ), $span_inner )
			: $span_inner;

		return '<tr><td class="bwf-email-menu bwf-email-menu-' . self::s( self::a( $block, 'uniqueID' ) ) . '">'
			. '<!--[if mso | IE]>' . $span . '<![endif]-->'
			. '</td></tr>';
	}

	/** A React text child: strings and numbers print, anything else renders nothing. */
	private static function child( $value ) {
		if ( is_string( $value ) || is_int( $value ) || is_float( $value ) ) {
			return self::s( $value );
		}

		return '';
	}

	/** getMenuHtml(): a link when the item has a URL, else a span. */
	private static function item_html( $item, $index ) {
		$text = BWFCRM_Email_Render_Js::get( $item, 'text' );
		$url  = BWFCRM_Email_Render_Js::get( $item, 'url' );

		if ( self::t( $url ) ) {
			$target = BWFCRM_Email_Render_Js::get( $item, 'target' );

			return BWFCRM_Email_Renderer::element(
				'a',
				array(
					'href'      => $url,
					'target'    => self::t( $target ) ? $target : '_blank',
					'className' => 'bwf-menu-item',
				),
				self::child( $text )
			);
		}

		return BWFCRM_Email_Renderer::element( 'span', array( 'className' => 'bwf-menu-item bwf-menu-item-' . ( $index + 1 ) ), self::child( $text ) );
	}

	/** ConditionalLayoutTags: each item in its own Outlook cell (horizontal) or row (vertical). */
	private static function layout_tags( array $block, $children ) {
		$padding = self::at( self::a( $block, 'padding' ), 'desktop' );
		$css     = null !== $padding ? BWFCRM_Email_Render_Css::padding( $padding ) . BWFCRM_Email_Render_Css::padding( $padding, false, true ) : '';
		$style   = BWFCRM_Email_Renderer::css_string_to_obj( $css );
		$props   = array(
			'className' => 'bwf-menu-row',
			'style'     => $style,
		);

		if ( 'horizontal' === self::a( $block, 'layout.desktop' ) ) {
			return '<!--[if mso | IE]>' . BWFCRM_Email_Renderer::element( 'td', $props, '<![endif]-->' . $children . '<!--[if mso | IE]>' ) . '<![endif]-->';
		}

		return '<!--[if mso | IE]>' . BWFCRM_Email_Renderer::element( 'tr', $props, '<td><![endif]-->' . $children . '<!--[if mso | IE]></td>' ) . '<![endif]-->';
	}

	public static function style( array $block, BWFCRM_Email_Render_Context $context ) {
		return self::media( self::desktop_css( $block, $context, 'desktop' ), self::mobile_css( $block, $context, 'mobile' ) );
	}

	/** alignmentStyle(): nothing at all (printed "undefined") on mobile without an alignment. */
	private static function alignment( array $block, $screen ) {
		$important = 'mobile' === $screen ? ' !important' : '';
		$alignment = self::at( self::a( $block, 'alignment' ), $screen );

		if ( null !== $alignment ) {
			$value = in_array( $alignment, array( 'right', 'center', 'left' ), true ) ? $alignment : 'center';

			return 'text-align:' . $value . $important . ';';
		}

		return 'desktop' === $screen ? 'text-align:center' . $important . ';' : 'undefined';
	}

	private static function color( array $block, BWFCRM_Email_Render_Context $context, $screen ) {
		$color = self::at( self::a( $block, 'color' ), $screen );

		return null !== $color ? 'color: ' . self::s( $color ) . ';' : BWFCRM_Email_Renderer::global_css( $context->global, 'color', $screen, '', false, $context );
	}

	private static function font_size( array $block, BWFCRM_Email_Render_Context $context, $screen, $important ) {
		$size = BWFCRM_Email_Render_Js::get( self::a( $block, 'font' ), array( $screen, 'size' ) );

		if ( null !== self::at( self::a( $block, 'font' ), $screen ) && self::t( $size ) && '' !== $size ) {
			return 'font-size: ' . self::s( $size ) . 'px' . ( $important ? ' !important' : '' ) . ';';
		}

		return BWFCRM_Email_Renderer::global_css( $context->global, 'font', $screen, 'size', $important, $context );
	}

	private static function flag( array $block, $key, $screen ) {
		return null !== self::at( self::a( $block, $key ), $screen );
	}

	private static function desktop_css( array $block, BWFCRM_Email_Render_Context $context, $screen ) {
		$selector  = '.bwf-email-menu.bwf-email-menu-' . self::s( self::a( $block, 'uniqueID' ) );
		$container = self::at( self::a( $block, 'containerPadding' ), $screen );
		$padding   = self::at( self::a( $block, 'padding' ), $screen );
		$layout    = BWFCRM_Email_Render_Js::get( self::a( $block, 'layout' ), array( $screen ) );
		$family    = BWFCRM_Email_Render_Js::get( self::a( $block, 'font' ), array( $screen, 'family' ) );
		$sep_color = self::at( self::a( $block, 'separatorColor' ), $screen );
		$items     = self::a( $block, 'menuItems', array() );

		$family_css = null !== self::at( self::a( $block, 'font' ), $screen ) && self::t( $family ) && '' !== $family
			? 'font-family: ' . self::s( $family ) . BWFCRM_Email_Renderer::backup_font( $context->global, $family, $context ) . ';'
			: BWFCRM_Email_Renderer::global_css( $context->global, 'font', $screen, 'family', false, $context );

		$item_colors = '';

		foreach ( is_array( $items ) ? array_values( $items ) : array() as $i => $item ) {
			$item_color = BWFCRM_Email_Render_Js::get( $item, 'color' );

			if ( self::t( $item_color ) ) {
				$item_colors .= $selector . ' .bwf-menu-item.bwf-menu-item-' . ( $i + 1 ) . ' { color: ' . self::s( $item_color ) . ' }';
			}
		}

		return '
        ' . $selector . ' {
            ' . ( null !== $container ? BWFCRM_Email_Render_Css::padding( $container ) : '' ) . '
            ' . ( null !== $container ? BWFCRM_Email_Render_Css::padding( $container, false, true ) : '' ) . '
        }

        ' . $selector . ' .bwf-email-menu-container {
            ' . self::alignment( $block, $screen ) . '
        }
		' . $selector . ' .bwf-menu-item,
		' . $selector . ' a.bwf-menu-item {
			word-break: break-word;
			text-decoration: none;
			' . ( null !== $padding ? BWFCRM_Email_Render_Css::padding( $padding ) : '' ) . '
            ' . ( null !== $padding ? BWFCRM_Email_Render_Css::padding( $padding, false, true ) : '' ) . '
			display: ' . ( 'horizontal' === $layout ? 'inline-block' : 'block' ) . ';

		}
		' . $selector . ' .bwf-menu-item, ' . $selector . ' #separator {
			font-size:16px;
			' . self::font_size( $block, $context, $screen, false ) . '
            ' . $family_css . '
			' . self::color( $block, $context, $screen ) . ';
			' . BWFCRM_Email_Render_Css::line_height( self::a( $block, 'lineHeight' ), $screen ) . '
		}
		' . $selector . ' .bwf-menu-item {
			' . self::color( $block, $context, $screen ) . ';
			' . ( self::flag( $block, 'bold', $screen ) ? 'font-weight:600;' : '' ) . '
			' . ( self::flag( $block, 'underline', $screen ) ? 'text-decoration: underline;' : '' ) . '
			' . ( self::flag( $block, 'italic', $screen ) ? 'font-style: italic;' : '' ) . '
		}
		' . $selector . ' #separator {
			' . ( null !== $sep_color ? 'color: ' . self::s( $sep_color ) . ';' : '' ) . '
		}
		' . $item_colors . '
		' . BWFCRM_Email_Renderer::visibility_css( $selector, $block, $screen ) . '
    ';
	}

	private static function mobile_css( array $block, BWFCRM_Email_Render_Context $context, $screen ) {
		$selector  = '.bwf-email-menu.bwf-email-menu-' . self::s( self::a( $block, 'uniqueID' ) );
		$container = self::at( self::a( $block, 'containerPadding' ), $screen );
		$padding   = self::at( self::a( $block, 'padding' ), $screen );
		$layout_at = self::a( $block, 'layout' );
		$layout    = BWFCRM_Email_Render_Js::get( $layout_at, array( $screen ) );

		if ( self::t( $layout_at ) && 'horizontal' === $layout ) {
			$display = 'display:inline-block !important;';
		} elseif ( 'vertical' === $layout ) {
			$display = 'display:block !important;';
		} else {
			$display = '';
		}

		return '
		' . $selector . ' {
			' . ( null !== $container ? BWFCRM_Email_Render_Css::padding( $container, true ) : '' ) . '
			' . ( null !== $container ? BWFCRM_Email_Render_Css::padding( $container, true, true ) : '' ) . '
		}
		' . $selector . ' .bwf-menu-row {
			' . ( null !== $padding ? BWFCRM_Email_Render_Css::padding( $padding, true ) : '' ) . '
			' . ( null !== $padding ? BWFCRM_Email_Render_Css::padding( $padding, true, true ) : '' ) . '
		}
		' . $selector . ' .bwf-menu-item,
		' . $selector . ' a.bwf-menu-item {
			' . ( null !== $padding ? BWFCRM_Email_Render_Css::padding( $padding, true ) : '' ) . '
            ' . ( null !== $padding ? BWFCRM_Email_Render_Css::padding( $padding, true, true ) : '' ) . '
			' . $display . '
			' . BWFCRM_Email_Render_Css::line_height( self::a( $block, 'lineHeight' ), $screen ) . '
		}
		' . $selector . ' .bwf-menu-item {
			' . self::color( $block, $context, $screen ) . ';
			' . self::font_size( $block, $context, $screen, true ) . '
		}
        ' . $selector . ' .bwf-email-menu-container {
            ' . self::alignment( $block, $screen ) . '
        }
		' . $selector . ' #separator {
			' . ( 'vertical' === $layout && self::t( $layout ) ? 'display:none;' : '' ) . '
		}
		' . BWFCRM_Email_Renderer::visibility_css( $selector, $block, $screen ) . '
    ';
	}
}
