<?php

defined( 'ABSPATH' ) || exit;

/** email-block/row: the full-width band a set of sections sits in. */
class BWFCRM_Email_Block_Row extends BWFCRM_Email_Block {

	public static function html( array $block, $inner, BWFCRM_Email_Render_Context $context, $responsive ) {
		$global = $context->global;
		$align  = $context->uses_variable( 'align' )
			? 'var(--bwfbe-align-desktop)'
			: ( self::t( BWFCRM_Email_Render_Js::get( $global, 'align.desktop' ) ) ? BWFCRM_Email_Render_Js::get( $global, 'align.desktop' ) : 'center' );
		$bg     = $context->uses_variable( 'background' ) ? 'var(--bwfbe-background-desktop-color)' : BWFCRM_Email_Render_Js::get( $global, 'background.desktop.color', null );

		return BWFCRM_Email_Renderer::element(
			'table',
			BWFCRM_Email_Renderer::table_props(
				array(
					'align'     => $align,
					'className' => 'bwfbe-block-row bwfbe-block-' . self::s( self::a( $block, 'uniqueID' ) ),
					'bgcolor'   => $bg,
				)
			),
			'<tbody><tr><td>' . $inner . '</td></tr></tbody>'
		);
	}

	public static function style( array $block, BWFCRM_Email_Render_Context $context ) {
		return self::media( self::screen_css( $block, 'desktop' ), self::mobile_css( $block, 'mobile' ) );
	}

	private static function screen_css( array $block, $screen ) {
		$selector   = '.bwfbe-block-row.bwfbe-block-' . self::s( self::a( $block, 'uniqueID' ) );
		$padding    = self::a( $block, 'padding' );
		$bg_color   = self::a( $block, 'bgColor' );
		$background = self::a( $block, 'background' );
		$bg_screen  = BWFCRM_Email_Render_Js::get( $background, array( $screen ) );

		return '
		' . $selector . '{
			' . ( ! BWFCRM_Email_Render_Js::is_empty( $background ) ? BWFCRM_Email_Render_Css::background( $bg_screen ) : '' ) . '
		}
        ' . $selector . ' > tbody > tr > td {
            ' . ( null !== self::at( $bg_color, $screen ) ? 'background-color: ' . self::s( self::at( $bg_color, $screen ) ) . ';' : '' ) . '
			' . ( ! BWFCRM_Email_Render_Js::is_empty( $background ) && BWFCRM_Email_Render_Js::is_empty( $background ) ? BWFCRM_Email_Render_Css::background( $bg_screen ) : '' ) . '
            ' . ( null !== self::at( $padding, $screen ) ? BWFCRM_Email_Render_Css::space( self::at( $padding, $screen ) ) : '' ) . '
            ' . ( null !== self::at( $padding, $screen ) ? BWFCRM_Email_Render_Css::space( self::at( $padding, $screen ), 'padding', true ) : '' ) . '
        }
        ' . BWFCRM_Email_Renderer::visibility_css( $selector, $block, $screen ) . '
    ';
	}

	private static function mobile_css( array $block, $screen ) {
		$selector = '.bwfbe-block-row.bwfbe-block-' . self::s( self::a( $block, 'uniqueID' ) );
		$padding  = self::at( self::a( $block, 'padding' ), $screen );

		return '
        ' . $selector . ' > tbody > tr > td {
            ' . ( null !== $padding ? BWFCRM_Email_Render_Css::space( $padding, 'padding', false, true ) : '' ) . '
            ' . ( null !== $padding ? BWFCRM_Email_Render_Css::space( $padding, 'padding', true, true ) : '' ) . '
        }
        ' . BWFCRM_Email_Renderer::visibility_css( $selector, $block, $screen ) . '
    ';
	}
}
