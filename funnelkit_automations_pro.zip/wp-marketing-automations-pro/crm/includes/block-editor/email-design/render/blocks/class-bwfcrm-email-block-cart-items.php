<?php

defined( 'ABSPATH' ) || exit;

/**
 * email-block/cart-items: the products left in the cart. Dynamic - while
 * saving, the editor writes only its shortcode, the block's attributes and the
 * email's global settings inside, and no CSS; send time renders the items.
 */
class BWFCRM_Email_Block_Cart_Items extends BWFCRM_Email_Block {

	public static function html( array $block, $inner, BWFCRM_Email_Render_Context $context, $responsive ) {
		return BWFCRM_Email_Renderer::dynamic_shortcode( 'bwfbe_cart_items', $block, $context, '', array( 'hasWCChildSelected' => false ) );
	}
}
