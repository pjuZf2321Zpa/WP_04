<?php

defined( 'ABSPATH' ) || exit;

/** email-block/list: an ordered or unordered list of rich-text items. */
class BWFCRM_Email_Block_List extends BWFCRM_Email_Block {

	/** Characters a CSS colour may contain, as the editor re-checks a hoisted colour. */
	const SAFE_COLOR = '/^[#a-z0-9.,%()\s-]+$/i';

	/** CSS named colours a browser keeps as written (lower case). */
	const NAMED = '/^(transparent|currentcolor|[a-z]+)$/i';

	public static function html( array $block, $inner, BWFCRM_Email_Render_Context $context, $responsive ) {
		$content = self::a( $block, 'content' );
		$ordered = self::a( $block, 'ordered', false );
		$ordered = BWFCRM_Email_Render_Js::UNDEFINED === $ordered ? false : $ordered;
		$items   = self::hoist_li_colors( $content, self::t( $ordered ) );
		$tag     = self::t( $ordered ) ? 'ol' : 'ul';

		return '<tr><td class="bwfbe-block-list bwfbe-block-list-' . self::s( self::a( $block, 'uniqueID' ) ) . '">'
			. '<div class="bwfbe-block-list-content"><' . $tag . '>' . ( is_string( $items ) ? $items : '' ) . '</' . $tag . '></div>'
			. '</td></tr>';
	}

	/**
	 * hoistLiColors(): each item with no colour of its own on the <li> takes the
	 * colour of the first styled element in its own text (nested lists aside),
	 * so the marker is coloured too. Unchanged content when nothing is hoisted.
	 */
	public static function hoist_li_colors( $content, $ordered ) {
		if ( ! is_string( $content ) || '' === $content ) {
			return $content;
		}

		// Merge tags in links would come back URL-encoded ({{unsubscribe_link}} as %7B%7B…) and never be replaced.
		$tags     = array();
		$html     = BWFCRM_Email_Render_Inliner::protect( $content, $tags );
		$dom      = new DOMDocument();
		$previous = libxml_use_internal_errors( true );
		$tag      = $ordered ? 'ol' : 'ul';
		$loaded   = $dom->loadHTML( '<?xml encoding="utf-8"?><' . $tag . ' id="__bwf_root">' . $html . '</' . $tag . '>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
		libxml_clear_errors();
		libxml_use_internal_errors( $previous );

		if ( ! $loaded ) {
			return $content;
		}

		$xpath = new DOMXPath( $dom );
		$root  = $xpath->query( '//*[@id="__bwf_root"]' )->item( 0 );

		if ( ! $root ) {
			return $content;
		}

		$changed = false;

		foreach ( iterator_to_array( $xpath->query( './/li', $root ) ) as $li ) {
			if ( '' !== self::style_color( $li->getAttribute( 'style' ) ) ) {
				continue;
			}

			$color = self::own_color( $li, $xpath );

			if ( '' === $color ) {
				continue;
			}

			$li->setAttribute( 'style', self::set_color( $li->getAttribute( 'style' ), $color ) );
			$changed = true;
		}

		if ( ! $changed ) {
			return $content;
		}

		$out = '';

		foreach ( iterator_to_array( $root->childNodes ) as $child ) {
			$out .= $dom->saveHTML( $child );
		}

		return BWFCRM_Email_Render_Inliner::restore( $out, $tags );
	}

	/** ownColor(): the item's text colour, ignoring any list nested inside it. */
	private static function own_color( DOMElement $li, DOMXPath $xpath ) {
		$clone = $li->cloneNode( true );

		foreach ( iterator_to_array( $xpath->query( './/ol|.//ul', $clone ) ) as $nested ) {
			$nested->parentNode->removeChild( $nested );
		}

		foreach ( $xpath->query( './/*[@style]', $clone ) as $styled ) {
			$color = self::style_color( $styled->getAttribute( 'style' ) );

			if ( '' !== $color && preg_match( self::SAFE_COLOR, $color ) ) {
				return $color;
			}
		}

		return '';
	}

	/** el.style.color: the last valid colour declaration, as the browser normalises it. */
	private static function style_color( $style ) {
		$color = '';

		foreach ( explode( ';', (string) $style ) as $declaration ) {
			$parts = explode( ':', $declaration, 2 );

			if ( 2 !== count( $parts ) || 'color' !== strtolower( trim( $parts[0] ) ) ) {
				continue;
			}

			$value = self::normalise_color( trim( preg_replace( '/\s*!important\s*$/i', '', trim( $parts[1] ) ) ) );

			if ( '' !== $value ) {
				$color = $value;
			}
		}

		return $color;
	}

	/** Hex and rgb() colours as a browser reads them back: rgb(r, g, b) or rgba(r, g, b, a). */
	private static function normalise_color( $value ) {
		if ( preg_match( '/^#([0-9a-f]{3,4}|[0-9a-f]{6}|[0-9a-f]{8})$/i', $value, $match ) ) {
			$hex = $match[1];

			if ( strlen( $hex ) <= 4 ) {
				$hex = preg_replace( '/(.)/', '$1$1', $hex );
			}

			$rgb = array( hexdec( substr( $hex, 0, 2 ) ), hexdec( substr( $hex, 2, 2 ) ), hexdec( substr( $hex, 4, 2 ) ) );

			if ( 8 === strlen( $hex ) ) {
				$alpha = hexdec( substr( $hex, 6, 2 ) ) / 255;

				if ( 1.0 !== (float) $alpha ) {
					return 'rgba(' . implode( ', ', $rgb ) . ', ' . BWFCRM_Email_Render_Js::number_to_string( round( $alpha, 3 ) ) . ')';
				}
			}

			return 'rgb(' . implode( ', ', $rgb ) . ')';
		}

		if ( preg_match( '/^rgba?\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*(?:,\s*([\d.]+%?)\s*)?\)$/i', $value, $match ) ) {
			$rgb = array( (int) round( min( 255, (float) $match[1] ) ), (int) round( min( 255, (float) $match[2] ) ), (int) round( min( 255, (float) $match[3] ) ) );

			if ( isset( $match[4] ) && '' !== $match[4] ) {
				$alpha = '%' === substr( $match[4], -1 ) ? (float) $match[4] / 100 : (float) $match[4];

				if ( $alpha < 1 ) {
					return 'rgba(' . implode( ', ', $rgb ) . ', ' . BWFCRM_Email_Render_Js::number_to_string( $alpha ) . ')';
				}
			}

			return 'rgb(' . implode( ', ', $rgb ) . ')';
		}

		if ( preg_match( self::NAMED, $value ) ) {
			return strtolower( $value );
		}

		return '';
	}

	/** li.style.color = color: the item's declarations, re-serialised, with the colour last. */
	private static function set_color( $style, $color ) {
		$out = '';

		foreach ( explode( ';', (string) $style ) as $declaration ) {
			$parts = explode( ':', $declaration, 2 );

			if ( 2 !== count( $parts ) || '' === trim( $parts[0] ) ) {
				continue;
			}

			$out .= strtolower( trim( $parts[0] ) ) . ': ' . trim( $parts[1] ) . '; ';
		}

		return $out . 'color: ' . $color . ';';
	}

	public static function style( array $block, BWFCRM_Email_Render_Context $context ) {
		return self::media( self::desktop_css( $block, $context, 'desktop' ), self::mobile_css( $block, $context, 'mobile' ) );
	}

	private static function font_size( array $block, BWFCRM_Email_Render_Context $context, $screen, $important ) {
		$size = BWFCRM_Email_Render_Js::get( self::a( $block, 'font' ), array( $screen, 'size' ) );

		if ( null !== self::at( self::a( $block, 'font' ), $screen ) && self::t( $size ) && '' !== $size ) {
			return 'font-size: ' . self::s( $size ) . 'px' . ( $important ? ' !important' : '' ) . ';';
		}

		return BWFCRM_Email_Renderer::global_css( $context->global, 'font', $screen, 'size', $important, $context );
	}

	private static function has_line_height( array $block, $screen ) {
		$value = BWFCRM_Email_Render_Js::get( self::a( $block, 'lineHeight' ), array( $screen, 'value' ) );

		return null !== self::at( self::a( $block, 'lineHeight' ), $screen ) && self::t( $value ) && '' !== $value;
	}

	private static function text_align( array $block, $screen, $important ) {
		$text  = BWFCRM_Email_Render_Js::get( self::a( $block, 'text' ), array( $screen ) );
		$align = BWFCRM_Email_Render_Js::get( $text, 'align' );

		return self::t( $text ) && self::t( $align ) ? 'text-align: ' . self::s( $align ) . ( $important ? ' !important' : '' ) . ';' : '';
	}

	private static function desktop_css( array $block, BWFCRM_Email_Render_Context $context, $screen ) {
		$id       = self::s( self::a( $block, 'uniqueID' ) );
		$block_s  = '.bwfbe-block-list.bwfbe-block-list-' . $id;
		$selector = $block_s . ' ol,' . $block_s . ' ul';
		$padding  = self::at( self::a( $block, 'padding' ), $screen );
		$lists    = null !== $padding ? BWFCRM_Email_Render_Css::padding( $padding, 'mobile' === $screen, 'mobile' !== $screen ) : '';
		$pad_at   = BWFCRM_Email_Render_Js::get( self::a( $block, 'padding' ), array( $screen ) );
		$color    = self::at( self::a( $block, 'color' ), $screen );
		$family   = BWFCRM_Email_Render_Js::get( self::a( $block, 'font' ), array( $screen, 'family' ) );
		$lh       = self::at( self::a( $block, 'lineHeight' ), $screen );
		$lh_value = BWFCRM_Email_Render_Js::get( self::a( $block, 'lineHeight' ), array( $screen, 'value' ) );
		$link     = self::at( self::a( $block, 'linkColor' ), $screen );

		$family_css = null !== self::at( self::a( $block, 'font' ), $screen ) && self::t( $family ) && '' !== $family
			? 'font-family: ' . self::s( $family ) . BWFCRM_Email_Renderer::backup_font( $context->global, $family, $context ) . ';'
			: BWFCRM_Email_Renderer::global_css( $context->global, 'font', $screen, 'family', false, $context );

		// The second padding reads padding[ screen ] unguarded; paddingCss() of nothing is empty.
		return '
	' . $block_s . ' li {
        ' . ( null !== $color ? 'color: ' . self::s( $color ) . ';' : BWFCRM_Email_Renderer::global_css( $context->global, 'color', $screen, '', false, $context ) ) . '
        ' . self::font_size( $block, $context, $screen, false ) . '
		' . $family_css . '
        ' . ( null !== $lh ? 'line-height: ' . self::s( $lh_value ) . ';' : 'line-height:revert;' ) . '
		' . ( self::has_line_height( $block, $screen ) ? 'mso-line-height-alt: ' . self::s( BWFCRM_Email_Render_Js::number( $lh_value ) * 100 ) . '%;' : 'mso-line-height-alt:150%;' ) . '
		margin:0;
	}
    ' . $selector . '{
        ' . self::text_align( $block, $screen, false ) . '
        word-break:break-word;
		margin:0px;
    }
	' . $block_s . ' {
        ' . $lists . '
		' . ( 'desktop' === $screen ? BWFCRM_Email_Render_Css::padding( is_array( $pad_at ) ? $pad_at : array(), true ) : '' ) . '
	}
    ' . $block_s . ' li a{
		' . ( 'desktop' === $screen ? 'color: inherit;' : '' ) . '
        ' . ( null !== $link ? 'color: ' . self::s( $link ) . ';' : BWFCRM_Email_Renderer::global_css( $context->global, 'linkColor', $screen, '', false, $context ) ) . '
		' . BWFCRM_Email_Renderer::global_css( $context->global, 'linkLineType', $screen, '', false, $context ) . '
		' . BWFCRM_Email_Renderer::global_css( $context->global, 'linkColor', $screen, '', false, $context ) . '
    }

	' . BWFCRM_Email_Renderer::visibility_css( $block_s, $block, $screen ) . '
   ';
	}

	private static function mobile_css( array $block, BWFCRM_Email_Render_Context $context, $screen ) {
		$id       = self::s( self::a( $block, 'uniqueID' ) );
		$block_s  = '.bwfbe-block-list.bwfbe-block-list-' . $id;
		$selector = $block_s . ' ol,' . $block_s . ' ul';
		$padding  = self::at( self::a( $block, 'padding' ), $screen );
		$lh_value = BWFCRM_Email_Render_Js::get( self::a( $block, 'lineHeight' ), array( $screen, 'value' ) );

		return '
		' . $block_s . ' {
			' . ( null !== $padding ? BWFCRM_Email_Render_Css::padding( $padding, true ) : '' ) . '
		}
		' . $block_s . ' li {
			' . self::font_size( $block, $context, $screen, true ) . '
			' . ( self::has_line_height( $block, $screen ) ? 'line-height: ' . self::s( $lh_value ) . ' !important;' : '' ) . '
		}
		' . $selector . ' {
			' . self::text_align( $block, $screen, true ) . '
		}
		' . BWFCRM_Email_Renderer::visibility_css( $block_s, $block, $screen ) . '
	';
	}
}
