<?php

defined( 'ABSPATH' ) || exit;

/**
 * email-block/site-logo: the site's logo, linked to the site. Saved with
 * merge tags for both; nothing at all when the site has no logo.
 */
class BWFCRM_Email_Block_Site_Logo extends BWFCRM_Email_Block_Image {

	const SLUG = 'site-logo';

	const WIDTH_KEY = 'value';

	public static function html( array $block, $inner, BWFCRM_Email_Render_Context $context, $responsive ) {
		$site = BWFCRM_Email_Render_Js::get( $context->site, 'site' );
		$logo = BWFCRM_Email_Render_Js::get( $site, 'logo' );

		if ( ! self::t( $logo ) ) {
			return '';
		}

		$alt    = BWFCRM_Email_Render_Js::get( self::a( $block, 'image', array() ), 'alt' );
		$alt    = self::t( $alt ) ? $alt : 'site logo';
		$target = self::a( $block, 'target' );

		$img = BWFCRM_Email_Renderer::element(
			'img',
			array(
				'src'   => $context->saving ? '{{site_logo}}' : $logo,
				'alt'   => $alt,
				'title' => $alt,
			)
		);

		$site_url = BWFCRM_Email_Render_Js::get( $site, 'url' );

		return static::cell(
			$block,
			BWFCRM_Email_Renderer::element(
				'a',
				array(
					'href'   => $context->saving ? '{{site_link}}' : ( self::t( $site_url ) ? $site_url : '' ),
					'target' => self::t( $target ) ? $target : '_blank',
				),
				$img
			)
		);
	}

	/** The site logo has no load-error state. */
	protected static function image_width_css( array $block, $screen ) {
		$image_width = self::at( self::a( $block, 'imageWidth' ), $screen );

		return 'desktop' === $screen && null !== $image_width ? 'width:' . self::s( $image_width ) . 'px;' : '';
	}
}
