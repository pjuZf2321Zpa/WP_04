<?php

defined( 'ABSPATH' ) || exit;

/**
 * email-block/coupon: a coupon code with its heading and button. Dynamic - while saving, the
 * editor writes only its shortcode and no CSS; send time renders it.
 */
class BWFCRM_Email_Block_Coupon extends BWFCRM_Email_Block {

	public static function html( array $block, $inner, BWFCRM_Email_Render_Context $context, $responsive ) {
		return BWFCRM_Email_Renderer::dynamic_shortcode( 'bwfbe_coupon', $block, $context, '', array( 'hasWCChildSelected' => false ) );
	}
}
