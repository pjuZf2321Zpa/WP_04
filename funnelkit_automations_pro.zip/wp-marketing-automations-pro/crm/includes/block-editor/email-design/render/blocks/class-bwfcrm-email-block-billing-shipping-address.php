<?php

defined( 'ABSPATH' ) || exit;

/**
 * email-block/billing-shipping-address: the order's billing and shipping addresses.
 *
 * While saving, the editor writes only the shortcode, the block's attributes
 * and the email's global settings inside it, and no CSS; send time renders it.
 * The shortcode is written the way cart-items writes it; hasWCChildSelected is
 * set by the edit on mount and saved with the attributes.
 */
class BWFCRM_Email_Block_Billing_Shipping_Address extends BWFCRM_Email_Block {

	public static function html( array $block, $inner, BWFCRM_Email_Render_Context $context, $responsive ) {
		return BWFCRM_Email_Renderer::dynamic_shortcode( 'bwfbe_customer_addresses', $block, $context, '', array( 'hasWCChildSelected' => false ) );
	}
}
