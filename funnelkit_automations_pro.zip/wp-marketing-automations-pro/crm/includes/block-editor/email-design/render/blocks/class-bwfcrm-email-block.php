<?php

defined( 'ABSPATH' ) || exit;

/**
 * One email block's rendering: its HTML and its CSS, each a port of the
 * block's own html.js / style.js in the email editor. A block gets its
 * attributes with every default filled in, as the editor renders from them.
 *
 * html()  - the block's markup; $inner is its children, already rendered.
 * style() - the CSS inlined into that markup: desktop rules, then the mobile
 *           rules in a media query (kept for the email's stylesheet).
 */
abstract class BWFCRM_Email_Block {

	/**
	 * @param array                       $block      { name, attrs, innerBlocks }
	 * @param string                      $inner      The rendered children.
	 * @param BWFCRM_Email_Render_Context $context
	 * @param bool                        $responsive Whether the parent section stacks its columns on mobile.
	 *
	 * @return string
	 */
	public static function html( array $block, $inner, BWFCRM_Email_Render_Context $context, $responsive ) {
		return '';
	}

	/**
	 * @param array                       $block
	 * @param BWFCRM_Email_Render_Context $context
	 *
	 * @return string
	 */
	public static function style( array $block, BWFCRM_Email_Render_Context $context ) {
		return '';
	}

	/** The usual HTMLStyle shape: desktop CSS, then mobile CSS inside the 768px media query. */
	protected static function media( $desktop, $mobile ) {
		return BWFCRM_Email_Renderer::minify_css( $desktop ) . '@media only screen and (max-width: 768px) {
                    ' . BWFCRM_Email_Renderer::minify_css( $mobile ) . '
                }';
	}

	protected static function a( array $block, $path, $default = BWFCRM_Email_Render_Js::UNDEFINED ) {
		return BWFCRM_Email_Render_Js::get( $block['attrs'], $path, $default );
	}

	protected static function t( $value ) {
		return BWFCRM_Email_Render_Js::truthy( $value );
	}

	protected static function s( $value ) {
		return BWFCRM_Email_Render_Js::str( $value );
	}

	/** `obj && obj[ screen ]` - the value when both are truthy, else null. */
	protected static function at( $value, $screen ) {
		if ( ! self::t( $value ) ) {
			return null;
		}

		$inner = BWFCRM_Email_Render_Js::get( $value, array( $screen ) );

		return self::t( $inner ) ? $inner : null;
	}
}
