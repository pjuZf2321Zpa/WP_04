<?php

defined( 'ABSPATH' ) || exit;

/** email-block/html: custom HTML, inserted as written. */
class BWFCRM_Email_Block_Html extends BWFCRM_Email_Block {

	public static function html( array $block, $inner, BWFCRM_Email_Render_Context $context, $responsive ) {
		$content = self::a( $block, 'content', '' );
		$content = is_string( $content ) ? $content : '';

		/*
		 * The editor renders the content as text (tags and existing entities
		 * kept) and then decodes the block's entities once, so the markup
		 * comes out raw and every entity in it decoded.
		 */
		$content = html_entity_decode( $content, ENT_QUOTES | ENT_HTML5, 'UTF-8' );

		$table = BWFCRM_Email_Renderer::element(
			'table',
			BWFCRM_Email_Renderer::table_props( array( 'align' => 'left' ) ),
			'<tbody><tr><td>' . $content . '</td></tr></tbody>'
		);

		return '<tr><td class="bwfbe-block-html bwfbe-block-html-' . self::s( self::a( $block, 'uniqueID' ) ) . '">' . $table . '</td></tr>';
	}

	public static function style( array $block, BWFCRM_Email_Render_Context $context ) {
		// The mobile rules are the desktop ones again, for the mobile screen.
		return self::media( self::screen_css( $block, $context, 'desktop' ), self::screen_css( $block, $context, 'mobile' ) );
	}

	private static function screen_css( array $block, BWFCRM_Email_Render_Context $context, $screen ) {
		$selector = '.bwfbe-block-html.bwfbe-block-html-' . self::s( self::a( $block, 'uniqueID' ) );
		$padding  = self::at( self::a( $block, 'padding' ), $screen );
		$family   = BWFCRM_Email_Render_Js::get( self::a( $block, 'font' ), array( $screen, 'family' ) );

		return $selector . '{
        ' . ( null !== $padding ? BWFCRM_Email_Render_Css::padding( $padding ) : '' ) . '
		font-size: 16px;
		' . ( ! BWFCRM_Email_Render_Js::is_empty( $family ) ? 'font-family: ' . self::s( $family ) . ';' : BWFCRM_Email_Renderer::global_css( $context->global, 'font', $screen, 'family', false, $context ) ) . '
    }
	' . $selector . ' td {
		line-height: 1.5;
	}

	' . BWFCRM_Email_Renderer::visibility_css( $selector, $block, $screen ) . '
	';
	}
}
