<?php

defined( 'ABSPATH' ) || exit;

/**
 * Moves a block's CSS into its elements' style attributes, the way the email
 * editor does it (juice 8, with the editor's options), so the inline styles
 * here are the ones the editor would write.
 *
 * What that means in practice, and why a general-purpose inliner will not do:
 *  - a property declared twice in one rule keeps both declarations, in order -
 *    that is how the editor ships a fallback before a CSS variable
 *    (`font-size: 16px; font-size: var(--bwfbe-font-desktop-size)`);
 *  - an existing style attribute outranks every rule except an !important one,
 *    and !important itself is dropped;
 *  - only elements some rule matched get their style attribute rewritten;
 *  - on table cells and images a px width or height is copied to the width /
 *    height attribute, and on table elements background-color, text-align and
 *    vertical-align become bgcolor, align and valign;
 *  - @media rules are not inlined: they are handed back for the email's
 *    stylesheet;
 *  - merge tags ({{...}}) pass through untouched.
 */
final class BWFCRM_Email_Render_Inliner {

	const IGNORED_PSEUDOS = array( 'hover', 'active', 'focus', 'visited', 'link' );
	const WIDTH_ELEMENTS = array( 'TABLE', 'TD', 'TH', 'IMG' );
	const TABLE_ELEMENTS = array( 'TABLE', 'TH', 'TR', 'TD', 'CAPTION', 'COLGROUP', 'COL', 'THEAD', 'TBODY', 'TFOOT' );
	const NON_VISUAL = array( 'HEAD', 'TITLE', 'BASE', 'LINK', 'STYLE', 'META', 'SCRIPT', 'NOSCRIPT' );
	const STYLE_TO_ATTRIBUTE = array(
		'background-color' => 'bgcolor',
		'background-image' => 'background',
		'text-align'       => 'align',
		'vertical-align'   => 'valign',
	);

	const ROOT_ID = 'bwfcrm-email-render-root';

	/** @var object|null CssSelectorConverter */
	private static $converter = null;

	/** Whether the selector engine the inliner needs can be loaded here. */
	public static function available() {
		return null !== self::converter();
	}

	private static function converter() {
		if ( null !== self::$converter ) {
			return self::$converter;
		}

		$class = 'BWFAN\\Symfony\\Component\\CssSelector\\CssSelectorConverter';

		// The bundled library is PHP 8 code (a parse error before it), so it is loaded only where FunnelKit Automations loads it.
		if ( ! class_exists( $class ) && version_compare( PHP_VERSION, '8.0.3', '>=' ) && defined( 'BWFAN_PLUGIN_DIR' ) && is_readable( BWFAN_PLUGIN_DIR . '/libraries/Emogrifier/autoload.php' ) ) {
			require_once BWFAN_PLUGIN_DIR . '/libraries/Emogrifier/autoload.php';
		}

		if ( class_exists( $class ) ) {
			self::$converter = new $class( true );
		} elseif ( defined( 'BWFAN_PLUGIN_DIR' ) && is_readable( BWFAN_PLUGIN_DIR . '/libraries/class-emogrifier-v1.php' ) ) {
			// Before PHP 8.0.3: the selector translator of the older inliner FunnelKit Automations loads there.
			self::$converter = BWFCRM_Email_Render_Legacy_Selectors::create();
		}

		return self::$converter;
	}

	/**
	 * @param string $html A fragment: the block's HTML.
	 * @param string $css  The CSS to apply.
	 *
	 * @return array { html: string, preserved: string } preserved holds the @media rules, for the stylesheet.
	 */
	public static function inline( $html, $css ) {
		$parsed = self::parse_css( (string) $css );

		if ( empty( $parsed['rules'] ) ) {
			return array( 'html' => $html, 'preserved' => $parsed['preserved'] );
		}

		$blocks = array();
		$html   = self::protect( (string) $html, $blocks );

		$dom = new DOMDocument();

		$previous = libxml_use_internal_errors( true );
		$dom->loadHTML( '<?xml encoding="utf-8"?><div id="' . self::ROOT_ID . '">' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
		libxml_clear_errors();
		libxml_use_internal_errors( $previous );

		$xpath = new DOMXPath( $dom );
		$root  = $xpath->query( '//*[@id="' . self::ROOT_ID . '"]' )->item( 0 );

		if ( ! $root ) {
			return array( 'html' => self::restore( $html, $blocks ), 'preserved' => $parsed['preserved'] );
		}

		$state = array();
		$order = 0;

		foreach ( $parsed['rules'] as $index => $rule ) {
			// Every rule is its own origin, as juice gives each its own selector object.
			$rule['origin'] = 'rule-' . $index;

			self::apply_rule( $xpath, $root, $rule, $state, $order );
		}

		foreach ( $state as $entry ) {
			self::write_style( $entry );
		}

		foreach ( $state as $entry ) {
			self::dimension( $entry, 'width' );
			self::dimension( $entry, 'height' );
			self::table_attributes( $entry );
		}

		$out = '';

		foreach ( iterator_to_array( $root->childNodes ) as $child ) {
			$out .= $dom->saveHTML( $child );
		}

		return array( 'html' => self::restore( $out, $blocks ), 'preserved' => $parsed['preserved'] );
	}

	/** juice's code-block protection: merge tags ({{ }}) and <% %> never reach the parser. */
	/**
	 * Swaps merge tags and <% %> blocks for placeholders, so a DOM pass does
	 * not URL-encode them in href/src; restore() puts them back.
	 */
	public static function protect( $html, array &$blocks ) {
		foreach ( array( '/<%[\s\S]*?%>/', '/\{\{[\s\S]*?\}\}/' ) as $pattern ) {
			$html = preg_replace_callback(
				$pattern,
				static function ( $m ) use ( &$blocks ) {
					$blocks[] = $m[0];

					return 'JUICE_CODE_BLOCK_' . ( count( $blocks ) - 1 ) . '_';
				},
				$html
			);
		}

		return $html;
	}

	public static function restore( $html, array $blocks ) {
		foreach ( $blocks as $i => $block ) {
			$html = preg_replace_callback(
				'/JUICE_CODE_BLOCK_' . $i . '_(="")?/i',
				static function () use ( $block ) {
					return $block;
				},
				$html
			);
		}

		return $html;
	}

	/**
	 * Splits CSS into rules to inline and at-rules to keep.
	 *
	 * @return array { rules: [ { selector, declarations: [ [name, value] ] } ], preserved: string }
	 */
	public static function parse_css( $css ) {
		$rules     = array();
		$preserved = array();
		$length    = strlen( $css );
		$i         = 0;

		while ( $i < $length ) {
			// Skip whitespace and comments.
			if ( ctype_space( $css[ $i ] ) ) {
				++$i;
				continue;
			}

			if ( '/' === $css[ $i ] && isset( $css[ $i + 1 ] ) && '*' === $css[ $i + 1 ] ) {
				$end = strpos( $css, '*/', $i + 2 );
				$i   = false === $end ? $length : $end + 2;
				continue;
			}

			$open = self::find( $css, '{', $i );

			if ( false === $open ) {
				break;
			}

			$prelude = trim( substr( $css, $i, $open - $i ) );
			$close   = self::matching_brace( $css, $open );
			$body    = substr( $css, $open + 1, $close - $open - 1 );
			$i       = $close + 1;

			if ( '' === $prelude ) {
				continue;
			}

			if ( '@' === $prelude[0] ) {
				$keyword = strtolower( strtok( substr( $prelude, 1 ), " \t\n(" ) );

				if ( 'media' === $keyword ) {
					$preserved[] = self::stringify_media( $prelude, $body );
				} elseif ( in_array( $keyword, array( 'font-face', 'keyframes', '-webkit-keyframes' ), true ) ) {
					$preserved[] = $prelude . '{' . $body . '}';
				}

				continue;
			}

			$declarations = self::parse_declarations( $body );
			$group        = count( $rules ) . ':' . $open;

			foreach ( self::split_selectors( $prelude ) as $selector ) {
				$rules[] = array( 'selector' => $selector, 'declarations' => $declarations, 'group' => $group );
			}
		}

		return array(
			'rules'     => $rules,
			'preserved' => implode( ' ', $preserved ),
		);
	}

	/**
	 * A kept @media rule written back out the way juice's CSS parser writes it:
	 * rule by rule, declarations without a value dropped.
	 */
	private static function stringify_media( $prelude, $body ) {
		$inner = self::parse_css( $body );
		$rules = array();
		$last  = null;

		foreach ( $inner['rules'] as $rule ) {
			$declarations = array();

			foreach ( $rule['declarations'] as $declaration ) {
				if ( '' !== $declaration[1] ) {
					$declarations[] = $declaration[0] . ': ' . $declaration[1] . ';';
				}
			}

			// The selectors of one source rule were split apart; put them back together - and only those.
			if ( null !== $last && $rules[ $last ]['group'] === $rule['group'] ) {
				$rules[ $last ]['selectors'][] = $rule['selector'];
				continue;
			}

			$rules[] = array( 'selectors' => array( $rule['selector'] ), 'text' => implode( ' ', $declarations ), 'group' => $rule['group'] );
			$last    = count( $rules ) - 1;
		}

		$out = array();

		foreach ( $rules as $rule ) {
			$out[] = implode( ', ', $rule['selectors'] ) . ' { ' . $rule['text'] . ' }';
		}

		return $prelude . ' { ' . implode( ' ', $out ) . ' }';
	}

	private static function find( $css, $char, $from ) {
		$quote = null;

		for ( $i = $from, $l = strlen( $css ); $i < $l; $i++ ) {
			$c = $css[ $i ];

			if ( null !== $quote ) {
				if ( $c === $quote ) {
					$quote = null;
				}

				continue;
			}

			if ( '"' === $c || "'" === $c ) {
				$quote = $c;
			} elseif ( $c === $char ) {
				return $i;
			}
		}

		return false;
	}

	private static function matching_brace( $css, $open ) {
		$depth = 0;
		$quote = null;

		for ( $i = $open, $l = strlen( $css ); $i < $l; $i++ ) {
			$c = $css[ $i ];

			if ( null !== $quote ) {
				if ( $c === $quote ) {
					$quote = null;
				}

				continue;
			}

			if ( '"' === $c || "'" === $c ) {
				$quote = $c;
			} elseif ( '{' === $c ) {
				++$depth;
			} elseif ( '}' === $c ) {
				--$depth;

				if ( 0 === $depth ) {
					return $i;
				}
			}
		}

		return $l - 1;
	}

	/** juice utils.extract(): commas split selectors except inside [ ] and ( ). */
	private static function split_selectors( $text ) {
		$depth = 0;
		$out   = array();
		$sel   = '';

		for ( $i = 0, $l = strlen( $text ); $i < $l; $i++ ) {
			$c = $text[ $i ];

			if ( $depth ) {
				if ( ']' === $c || ')' === $c ) {
					--$depth;
				}

				$sel .= $c;
				continue;
			}

			if ( ',' === $c ) {
				$out[] = trim( $sel );
				$sel   = '';
				continue;
			}

			if ( '[' === $c || '(' === $c ) {
				++$depth;
			}

			if ( '' !== $sel || ( ',' !== $c && "\n" !== $c && ' ' !== $c ) ) {
				$sel .= $c;
			}
		}

		if ( '' !== trim( $sel ) ) {
			$out[] = trim( $sel );
		}

		return array_values( array_filter( $out, 'strlen' ) );
	}

	/** Declarations in order, repeats kept: [ [name, value], ... ]. */
	private static function parse_declarations( $body ) {
		$out   = array();
		$depth = 0;
		$quote = null;
		$item  = '';

		for ( $i = 0, $l = strlen( $body ); $i <= $l; $i++ ) {
			$c = $i < $l ? $body[ $i ] : ';';

			if ( null !== $quote ) {
				$item .= $c;

				if ( $c === $quote ) {
					$quote = null;
				}

				continue;
			}

			if ( '"' === $c || "'" === $c ) {
				$quote = $c;
			} elseif ( '(' === $c ) {
				++$depth;
			} elseif ( ')' === $c ) {
				--$depth;
			} elseif ( ';' === $c && $depth <= 0 ) {
				$colon = strpos( $item, ':' );

				if ( false !== $colon ) {
					$name  = trim( substr( $item, 0, $colon ) );
					$value = trim( substr( $item, $colon + 1 ) );

					if ( '' !== $name ) {
						$out[] = array( $name, $value );
					}
				}

				$item = '';
				continue;
			}

			$item .= $c;
		}

		return $out;
	}

	/** juice/slick specificity: [ style attribute, ids, classes + attributes, tags + pseudos - :not ]. */
	public static function specificity( $selector, $style_attribute = false ) {
		$spec = array( $style_attribute ? 1 : 0, 0, 0, 0 );

		if ( $style_attribute ) {
			return $spec;
		}

		// Attribute values could hold anything; count the brackets, then drop them.
		$spec[2] += preg_match_all( '/\[[^\]]*\]/', $selector );
		$plain    = preg_replace( '/\[[^\]]*\]/', '', $selector );
		$plain    = preg_replace( '/:not\(([^)]*)\)/', ' $1', $plain, -1, $nots );

		$spec[1] += preg_match_all( '/#[\w-]+/', $plain );
		$spec[2] += preg_match_all( '/\.[\w-]+/', $plain );
		// Pseudos score in the last column; :not() itself does not, its argument does (counted above).
		$spec[3] += preg_match_all( '/::?[\w-]+/', $plain );

		foreach ( preg_split( '/[\s>+~]+/', trim( $plain ) ) as $compound ) {
			if ( preg_match( '/^[a-zA-Z][\w-]*/', $compound ) ) {
				++$spec[3];
			}
		}

		return $spec;
	}

	private static function pseudo_names( $selector ) {
		preg_match_all( '/::?([\w-]+)/', preg_replace( '/\[[^\]]*\]/', '', $selector ), $m );

		return $m[1];
	}

	private static function apply_rule( DOMXPath $xpath, DOMElement $root, array $rule, array &$state, &$order ) {
		$selector = $rule['selector'];
		$pseudos  = self::pseudo_names( $selector );

		if ( array_intersect( $pseudos, self::IGNORED_PSEUDOS ) || array_intersect( $pseudos, array( 'before', 'after' ) ) ) {
			return;
		}

		try {
			$path = self::converter()->toXPath( $selector, 'descendant-or-self::' );
		} catch ( \Throwable $e ) {
			return;
		}

		$nodes = @$xpath->query( $path, $root ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- an unmatchable selector is skipped, as juice skips it.

		if ( ! $nodes ) {
			return;
		}

		$spec = self::specificity( $selector );

		foreach ( $nodes as $node ) {
			if ( ! $node instanceof DOMElement || $node->isSameNode( $root ) || in_array( strtoupper( $node->nodeName ), self::NON_VISUAL, true ) ) {
				continue;
			}

			$key = spl_object_id( $node );

			if ( ! isset( $state[ $key ] ) ) {
				$state[ $key ] = array( 'node' => $node, 'props' => array() );

				// An existing style attribute takes part as the most specific selector there is.
				if ( $node->hasAttribute( 'style' ) && '' !== $node->getAttribute( 'style' ) ) {
					foreach ( self::parse_declarations( $node->getAttribute( 'style' ) ) as $declaration ) {
						self::add_prop( $state[ $key ], $declaration, 'style-attribute', self::specificity( '', true ), $order );
					}
				}
			}

			foreach ( $rule['declarations'] as $declaration ) {
				self::add_prop( $state[ $key ], $declaration, $rule['origin'], $spec, $order );
			}
		}
	}

	/**
	 * juice's addProps for one declaration.
	 *
	 * @param array $entry       The element's state.
	 * @param array $declaration [ name, value ]
	 * @param string $origin     What it came from; declarations of one rule share it.
	 * @param int[] $spec
	 * @param int   $order       Running source position, the tie-breaker juice takes from line/column.
	 */
	private static function add_prop( array &$entry, array $declaration, $origin, array $spec, &$order ) {
		list( $name, $value ) = $declaration;

		$important = (bool) preg_match( '/!important$/', $value );

		if ( $important ) {
			$value = preg_replace( '/\s*!important$/', '', $value );
		}

		$vector    = $spec;
		$vector[0] += $important ? 2 : 0;
		$vector[]  = ++$order;

		$prop = array(
			'name'   => $name,
			'value'  => $value,
			'origin' => $origin,
			'vector' => $vector,
			'next'   => null,
		);

		$existing = isset( $entry['props'][ $name ] ) ? $entry['props'][ $name ] : null;

		if ( null !== $existing && 1 === self::compare( $existing['vector'], $prop['vector'] ) ) {
			return;
		}

		if ( null !== $existing && $existing['origin'] !== $prop['origin'] ) {
			// A different rule wins: the property moves to the end of the order.
			unset( $entry['props'][ $name ] );
		} elseif ( null !== $existing ) {
			// Declared again in the same rule: both are kept.
			$prop['next'] = $existing;
		}

		$entry['props'][ $name ] = $prop;
	}

	private static function compare( array $a, array $b ) {
		$min = min( count( $a ), count( $b ) );

		for ( $i = 0; $i < $min; $i++ ) {
			if ( $a[ $i ] === $b[ $i ] ) {
				continue;
			}

			return $a[ $i ] > $b[ $i ] ? 1 : -1;
		}

		return count( $a ) - count( $b );
	}

	private static function write_style( array $entry ) {
		$props = array();

		foreach ( $entry['props'] as $prop ) {
			while ( null !== $prop ) {
				$props[] = $prop;
				$prop    = $prop['next'];
			}
		}

		usort(
			$props,
			static function ( $a, $b ) {
				return self::compare( $a['vector'], $b['vector'] );
			}
		);

		$parts = array();

		foreach ( $props as $prop ) {
			if ( 'content' !== $prop['name'] ) {
				$parts[] = $prop['name'] . ': ' . str_replace( '"', "'", $prop['value'] ) . ';';
			}
		}

		if ( ! empty( $parts ) ) {
			$entry['node']->setAttribute( 'style', implode( ' ', $parts ) );
		}
	}

	private static function dimension( array $entry, $dimension ) {
		$tag = strtoupper( $entry['node']->nodeName );

		if ( ! in_array( $tag, self::WIDTH_ELEMENTS, true ) || ! isset( $entry['props'][ $dimension ] ) ) {
			return;
		}

		$value = $entry['props'][ $dimension ]['value'];

		if ( false !== strpos( $value, 'px' ) ) {
			$entry['node']->setAttribute( $dimension, preg_replace( '/px/', '', $value, 1 ) );

			return;
		}

		if ( in_array( $tag, self::TABLE_ELEMENTS, true ) && false !== strpos( $value, '%' ) ) {
			$entry['node']->setAttribute( $dimension, $value );
		}
	}

	private static function table_attributes( array $entry ) {
		if ( ! in_array( strtoupper( $entry['node']->nodeName ), self::TABLE_ELEMENTS, true ) ) {
			return;
		}

		foreach ( $entry['props'] as $name => $prop ) {
			if ( ! isset( self::STYLE_TO_ATTRIBUTE[ $name ] ) ) {
				continue;
			}

			$attribute = self::STYLE_TO_ATTRIBUTE[ $name ];
			$value     = $prop['value'];

			if ( 'background' === $attribute && 0 === strpos( $value, 'url(' ) ) {
				$value = preg_replace( '/^url\(([\'"])?([^\'"]+)\1\)$/', '$2', $value );
			}

			if ( preg_match( '/(linear|radial)-gradient\(/i', $value ) ) {
				continue;
			}

			$entry['node']->setAttribute( $attribute, $value );
		}
	}
}

/**
 * CSS selectors to XPath with the translator of FunnelKit Automations' older
 * inliner (BWF_Pelago\Emogrifier_V1), for PHP before 8.0.3, where the bundled
 * Symfony one cannot load. It reads the class, descendant and child selectors
 * the editor's CSS is made of, and matches the same elements Symfony does on
 * every design checked (tests/test-email-render-parity.php renders the fixtures
 * through both). A selector with anything more - attribute, pseudo-class,
 * sibling or universal - is refused, and the inliner skips that rule as juice
 * skips one it cannot read: a style missing, never one put on the wrong element.
 */
class BWFCRM_Email_Render_Legacy_Selectors {

	/** Characters of the selectors the older translator is not trusted with. */
	const UNSUPPORTED = '/[\[:+~*]/';

	/** @var object Emogrifier_V1 */
	private $inliner;

	/** @var ReflectionMethod Its translator, which it keeps private. */
	private $translate;

	/**
	 * @return self|null Null when FunnelKit Automations' older inliner, or its translator, is not there.
	 */
	public static function create() {
		if ( ! class_exists( 'BWF_Pelago\Emogrifier_V1' ) ) {
			require_once BWFAN_PLUGIN_DIR . '/libraries/class-emogrifier-v1.php';
		}

		if ( ! class_exists( 'BWF_Pelago\Emogrifier_V1' ) || ! method_exists( 'BWF_Pelago\Emogrifier_V1', 'translateCssToXpath' ) ) {
			return null;
		}

		$self            = new self();
		$self->inliner   = new \BWF_Pelago\Emogrifier_V1();
		$self->translate = new ReflectionMethod( $self->inliner, 'translateCssToXpath' );
		if ( PHP_VERSION_ID < 80100 ) {
			$self->translate->setAccessible( true ); // From PHP 8.1 private methods are callable through Reflection as they are.
		}

		return $self;
	}

	/**
	 * @param string $selector
	 *
	 * @return string An XPath from the document root.
	 *
	 * @throws InvalidArgumentException For a selector the older translator is not trusted with.
	 */
	public function toXPath( $selector ) {
		if ( preg_match( self::UNSUPPORTED, $selector ) ) {
			throw new InvalidArgumentException( 'Selector not supported before PHP 8.0.3: ' . $selector ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- caught by the inliner, never shown.
		}

		return $this->translate->invoke( $this->inliner, $selector );
	}
}
