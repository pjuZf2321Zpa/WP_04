<?php

defined( 'ABSPATH' ) || exit;

/**
 * The email editor's template library: the professionally designed emails the
 * editor offers under "Templates" when a new email is started, read from the
 * same service the editor reads them from.
 *
 * Each library design comes in two forms; this returns the one that follows
 * the site's Global Style (its colours, fonts and buttons), so a design
 * started from the library looks like the rest of the site's email.
 *
 * Both the index and each design are cached: the library changes with editor
 * releases, not from one request to the next. A failed request is cached
 * briefly too, so an unreachable library costs one timeout, not one per call.
 */
class BWFCRM_Email_Design_Library {

	const URL = 'https://app.getautonami.com/block-templates';

	const INDEX_TTL = 12 * HOUR_IN_SECONDS;

	const DESIGN_TTL = DAY_IN_SECONDS;

	/** How long a failed request is answered from its failure, not retried: 5 minutes. */
	const FAILURE_TTL = 300;

	/** Largest response read: a library design is well under this. */
	const MAX_BYTES = 1048576;

	/**
	 * @return array|WP_Error { categories: string[], preview_prefix: string, image_prefix: string, templates: array[] }
	 */
	public static function index() {
		$cached = get_transient( 'bwfcrm_email_design_library' );

		if ( is_array( $cached ) ) {
			return $cached;
		}

		$data = self::fetch( self::url() );

		if ( is_wp_error( $data ) ) {
			return $data;
		}

		if ( ! isset( $data['templates'] ) || ! is_array( $data['templates'] ) ) {
			return new WP_Error( 'bwfcrm_library_unreadable', 'The email template library answered, but not with a list of templates.' );
		}

		$templates = array();

		foreach ( $data['templates'] as $template ) {
			if ( ! is_array( $template ) || empty( $template['id'] ) || ! self::valid_id( $template['id'] ) ) {
				continue;
			}

			$templates[] = array(
				'id'         => (string) $template['id'],
				'title'      => isset( $template['title'] ) && is_string( $template['title'] ) ? sanitize_text_field( $template['title'] ) : (string) $template['id'],
				'categories' => isset( $template['categories'] ) && is_array( $template['categories'] ) ? array_values( array_map( 'sanitize_text_field', array_filter( $template['categories'], 'is_string' ) ) ) : array(),
				'image'      => isset( $template['image'] ) && is_string( $template['image'] ) ? $template['image'] : '',
				'preview'    => isset( $template['prev'] ) && is_string( $template['prev'] ) ? $template['prev'] : '',
				'dependency' => isset( $template['dependency'] ) && is_array( $template['dependency'] ) ? $template['dependency'] : array(),
			);
		}

		$index = array(
			'categories'     => isset( $data['category-list'] ) && is_array( $data['category-list'] ) ? array_values( array_map( 'sanitize_text_field', array_filter( $data['category-list'], 'is_string' ) ) ) : array(),
			'image_prefix'   => isset( $data['image-prefix'] ) && is_string( $data['image-prefix'] ) ? sanitize_url( $data['image-prefix'] ) : '',
			'preview_prefix' => isset( $data['preview-prefix'] ) && is_string( $data['preview-prefix'] ) ? sanitize_url( $data['preview-prefix'] ) : '',
			'templates'      => $templates,
		);

		set_transient( 'bwfcrm_email_design_library', $index, self::INDEX_TTL );

		return $index;
	}

	/**
	 * One library design, in the form that follows the site's Global Style.
	 *
	 * @param string $id
	 *
	 * @return array|WP_Error { markup: string, settings: array }
	 */
	public static function design( $id ) {
		if ( ! self::valid_id( $id ) ) {
			return new WP_Error( 'bwfcrm_library_unknown', 'Library template ids are lowercase letters, digits and dashes, as list-email-starter-designs gives them.' );
		}

		$key    = 'bwfcrm_email_design_library_' . md5( $id );
		$cached = get_transient( $key );

		if ( is_array( $cached ) ) {
			return $cached;
		}

		// An id the (already read) index does not list is not asked for.
		$index = get_transient( 'bwfcrm_email_design_library' );

		if ( is_array( $index ) && isset( $index['templates'] ) && ! in_array( $id, array_column( $index['templates'], 'id' ), true ) ) {
			return new WP_Error( 'bwfcrm_library_unknown', sprintf( 'The library has no design "%s". list-email-starter-designs gives the ids.', $id ) );
		}

		$data = self::fetch( self::url() . '/' . rawurlencode( $id ) );

		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$markup = '';

		foreach ( array( 'body-dynamic', 'body' ) as $field ) {
			if ( isset( $data[ $field ] ) && is_string( $data[ $field ] ) && '' !== trim( $data[ $field ] ) ) {
				$markup = $data[ $field ];
				break;
			}
		}

		if ( '' === $markup ) {
			return new WP_Error( 'bwfcrm_library_unknown', sprintf( 'The library has no design "%s". list-email-starter-designs gives the ids.', $id ) );
		}

		$design = array(
			'markup'   => $markup,
			'settings' => isset( $data['settings'] ) && is_array( $data['settings'] ) ? $data['settings'] : array(),
		);

		set_transient( $key, $design, self::DESIGN_TTL );

		return $design;
	}

	private static function valid_id( $id ) {
		return is_string( $id ) && 1 === preg_match( '/^[a-z0-9][a-z0-9-]{0,99}$/', $id );
	}

	private static function url() {
		/**
		 * Where the email template library is read from.
		 *
		 * @param string $url
		 */
		return (string) apply_filters( 'bwfcrm_email_design_library_url', self::URL );
	}

	private static function fetch( $url ) {
		$failed_key = 'bwfcrm_email_design_library_failed_' . md5( $url );
		$failed     = get_transient( $failed_key );

		if ( is_array( $failed ) && isset( $failed['code'], $failed['message'] ) ) {
			return new WP_Error( $failed['code'], $failed['message'] );
		}

		$data = self::request( $url );

		if ( is_wp_error( $data ) ) {
			set_transient( $failed_key, array( 'code' => $data->get_error_code(), 'message' => $data->get_error_message() ), self::FAILURE_TTL );
		}

		return $data;
	}

	private static function request( $url ) {
		$response = wp_safe_remote_get(
			$url,
			array(
				'timeout'             => 10,
				'redirection'         => 2,
				'limit_response_size' => self::MAX_BYTES,
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'bwfcrm_library_unreachable', 'The email template library could not be reached: ' . $response->get_error_message() );
		}

		if ( 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			return new WP_Error( 'bwfcrm_library_unreachable', sprintf( 'The email template library answered %d.', (int) wp_remote_retrieve_response_code( $response ) ) );
		}

		$data = json_decode( wp_remote_retrieve_body( $response ), true );

		return is_array( $data ) ? $data : new WP_Error( 'bwfcrm_library_unreadable', 'The email template library did not answer in JSON.' );
	}
}
