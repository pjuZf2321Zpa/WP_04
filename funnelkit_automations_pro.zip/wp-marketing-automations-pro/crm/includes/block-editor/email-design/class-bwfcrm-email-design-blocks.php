<?php

defined( 'ABSPATH' ) || exit;

/**
 * What each block of a design will actually do when the email is sent - the
 * checks a person makes by looking at the editor's preview:
 *
 *  - a product block must have a feed that finds products, and the products,
 *    categories and coupons it names must exist in the store;
 *  - order, cart and subscription blocks fill in only when the right trigger
 *    sends the email;
 *  - placeholders the editor ships as defaults (TAKE10OFF, "Button Text",
 *    "Hello, world!", unlinked menu items) would go out as written;
 *  - options that have no effect, or only work together, are named.
 *
 * normalize() first repairs what the editor itself would never save - a
 * product block with no feed, social icons with no style, a heading without
 * its bold - and says what it filled in.
 */
class BWFCRM_Email_Design_Blocks {

	const PRODUCT = 'email-block/best-selling-product';

	/**
	 * A hand-picked product entry as the editor writes it when a product is
	 * picked. The editor shows a card's text from these fields (title with
	 * {{product_title}} replaced by the product's name), so an entry with only
	 * an id shows an empty card there; send time reads the same placeholders.
	 */
	const PICKED_PRODUCT = array(
		'title'             => '{{product_title}}',
		'description'       => '{{product_description}}',
		'regularPrice'      => '{{product_price}}',
		'salePrice'         => '{{product_sale_price}}',
		'image'             => '',
		'permalink'         => '{{product_url}}',
		'newTab'            => '_blank',
		'buttonText'        => 'Buy Now',
		'regularPriceLabel' => 'Regular Price',
		'salePriceLabel'    => 'Sale Price',
	);

	/** Block groups that only fill in when a trigger of that kind sends the email. */
	const TRIGGER_GROUPS = array( 'order', 'cart', 'sublium-subscription-info', 'sublium-subscription-items', 'sublium-installment' );

	/**
	 * Fills in what the editor always writes but a design may leave out.
	 *
	 * @param array[] $tree
	 *
	 * @return array { tree: array[], warnings: array[] }
	 */
	public static function normalize( array $tree ) {
		$warnings = array();

		self::walk(
			$tree,
			function ( array &$block, $path ) use ( &$warnings ) {
				$name  = isset( $block['name'] ) ? (string) $block['name'] : '';
				$attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();

				switch ( $name ) {
					case self::PRODUCT:
						// The editor leaves its default feed, specific, out of the saved markup: a block with
						// products picked but no feed is a hand-picked grid, and stays one.
						if ( ! array_key_exists( 'productFeedType', $attrs ) && empty( $attrs['specificProductData'] ) ) {
							$attrs['productFeedType'] = 'best_selling_store';
							$attrs['sortBy']          = isset( $attrs['sortBy'] ) ? $attrs['sortBy'] : 'sales';
							$warnings[]               = self::issue( $path . '/attrs/productFeedType', 'feed_defaulted', 'No productFeedType was given, so the block shows the best sellers (best_selling_store). The editor\'s own default, specific, shows nothing until products are picked. Set productFeedType to say which products you mean.' );
						}

						if ( ! empty( $attrs['specificProductData'] ) && is_array( $attrs['specificProductData'] ) ) {
							foreach ( $attrs['specificProductData'] as $cell => $entry ) {
								if ( is_array( $entry ) && ! empty( $entry['id'] ) ) {
									$picked = self::PICKED_PRODUCT;

									if ( isset( $attrs['buttonText'] ) && is_string( $attrs['buttonText'] ) ) {
										$picked['buttonText'] = $attrs['buttonText'];
									}

									// What the entry says wins; the rest is what picking the product writes.
									$attrs['specificProductData'][ $cell ] = array_merge( array( 'id' => $entry['id'] ), $picked, $entry );
								}
							}
						}

						// A new block only: an edit never restyles products already in a design.
						if ( empty( $attrs['uniqueID'] ) ) {
							$filled = self::card_style( $attrs );

							if ( ! empty( $filled ) ) {
								$warnings[] = self::issue( $path . '/attrs', 'card_style', 'Unset, the cards copied the site\'s main button and a half-width image, so the buttons outweighed the products. Filled in ' . implode( ', ', $filled ) . ' - set them to choose otherwise.' );
							}
						}
						break;

					case 'email-block/row':
						// The row's bgColor is a plain colour per screen; the object form a background takes renders as [object Object].
						if ( isset( $attrs['bgColor'] ) && is_array( $attrs['bgColor'] ) ) {
							foreach ( $attrs['bgColor'] as $screen => $value ) {
								if ( is_array( $value ) && isset( $value['color'] ) && is_string( $value['color'] ) ) {
									$attrs['bgColor'][ $screen ] = $value['color'];
								}
							}
						}
						break;

					case 'email-block/social':
						if ( ! empty( $attrs['icons'] ) && empty( $attrs['type'] ) ) {
							// The editor copies the site's icon style in as soon as icons are chosen.
							$site          = BWFCRM_Email_Design_Store::social_type();
							$attrs['type'] = '' !== $site ? $site : 'circle';
						}
						break;

					case 'email-block/text':
						if ( isset( $attrs['content'] ) && is_string( $attrs['content'] ) ) {
							$attrs['content'] = self::bold_headings( $attrs['content'] );
						}
						break;

					case 'email-block/space-divider':
						if ( isset( $attrs['dividerWidth'] ) && is_array( $attrs['dividerWidth'] ) ) {
							foreach ( $attrs['dividerWidth'] as $screen => $value ) {
								// The editor stores the width as a string; a number reads as empty and Outlook draws the line full width.
								if ( is_array( $value ) && isset( $value['value'] ) && ( is_int( $value['value'] ) || is_float( $value['value'] ) ) ) {
									$attrs['dividerWidth'][ $screen ]['value'] = (string) $value['value'];
								}
							}
						}
						break;
				}

				// A display condition in the shape the rule builder saves and the send-time code reads,
				// with the summary the editor's condition panel shows: without it the panel is empty.
				if ( ! empty( $attrs['conditional']['rules'] ) && is_array( $attrs['conditional'] ) && is_array( $attrs['conditional']['rules'] ) && class_exists( 'BWFCRM_Email_Design_Conditions' ) ) {
					$attrs['conditional']['rules'] = BWFCRM_Email_Design_Conditions::normalize_values( $attrs['conditional']['rules'] );
					$summary                       = BWFCRM_Email_Design_Conditions::summary( $attrs['conditional']['rules'] );

					if ( '' !== $summary ) {
						$attrs['conditional']['data'] = $summary;
					}
				}

				$block['attrs'] = $attrs;
			}
		);

		return array(
			'tree'     => $tree,
			'warnings' => $warnings,
		);
	}

	/**
	 * A heading span without a font weight gets the editor's 600: its heading
	 * control always writes it, and without it the heading is not bold.
	 */
	private static function bold_headings( $html ) {
		if ( false === strpos( $html, 'data-heading-level' ) ) {
			return $html;
		}

		return (string) preg_replace_callback(
			'/<span\b[^>]*\bdata-heading-level=["\']?[1-6]["\']?[^>]*>/i',
			static function ( $m ) {
				$tag = $m[0];

				if ( preg_match( '/font-weight\s*:/i', $tag ) ) {
					return $tag;
				}

				if ( preg_match( '/\sstyle=(["\'])(.*?)\1/is', $tag, $style ) ) {
					$css = rtrim( trim( $style[2] ), ';' );

					return str_replace( $style[0], ' style=' . $style[1] . ( '' !== $css ? $css . ';' : '' ) . 'font-weight:600;' . $style[1], $tag );
				}

				return preg_replace( '/^<span\b/i', '<span style="font-weight:600;"', $tag );
			},
			$html
		);
	}

	/**
	 * @param array[] $tree
	 * @param array   $settings
	 * @param array   $options {
	 *     @type string[] $event_groups  Block groups the email's trigger provides.
	 *     @type string   $event         The trigger event slug; empty for a template.
	 *     @type int      $automation_id The automation the email belongs to, if known.
	 * }
	 *
	 * @return array { errors: array[], warnings: array[] }
	 */
	public static function check( array $tree, array $settings = array(), array $options = array() ) {
		$out     = array( 'errors' => array(), 'warnings' => array() );
		$context = array(
			'groups'        => isset( $options['event_groups'] ) ? array_values( (array) $options['event_groups'] ) : array(),
			'event'         => isset( $options['event'] ) ? (string) $options['event'] : '',
			'automation_id' => isset( $options['automation_id'] ) ? absint( $options['automation_id'] ) : 0,
		);

		self::walk(
			$tree,
			function ( array &$block, $path ) use ( &$out, $context ) {
				$name  = isset( $block['name'] ) ? (string) $block['name'] : '';
				$attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? BWFCRM_Email_Render_Js::plain( $block['attrs'] ) : array();

				self::check_hands_off( $out, $name, $attrs, $path );
				self::check_image_hosts( $out, $attrs, $path );
				self::check_placeholders( $out, $name, $attrs, $path );
				self::check_trigger( $out, $name, $path, $context );
				self::check_condition( $out, $attrs, $path, $context );

				switch ( $name ) {
					case self::PRODUCT:
						self::check_products( $out, $attrs, $path, $context );
						break;

					case 'email-block/coupon':
						self::check_coupon( $out, $attrs, $path, $context, 'code', isset( $attrs['couponType'] ) ? $attrs['couponType'] : 'wc' );

						if ( ! empty( $attrs['enableCartLink'] ) && ! in_array( 'cart', $context['groups'], true ) && '' !== $context['event'] ) {
							$out['warnings'][] = self::issue( $path . '/attrs/enableCartLink', 'needs_cart', 'The cart recovery link only exists when a cart trigger sends the email; here the button would link nowhere. Turn enableCartLink off and set btnURL.' );
						}
						break;

					case 'email-block/cart-link':
						self::check_button_padding( $out, $attrs, $path );

						if ( ! empty( $attrs['coupon'] ) ) {
							if ( empty( $attrs['enableCoupon'] ) ) {
								$out['warnings'][] = self::issue( $path . '/attrs/coupon', 'coupon_applied_anyway', 'coupon is applied whenever it is set, even with enableCoupon off. Clear coupon too, or set enableCoupon to true.' );
							}

							self::check_coupon( $out, $attrs, $path, $context, 'coupon', isset( $attrs['couponType'] ) ? $attrs['couponType'] : 'wc' );
						}
						break;

					case 'email-block/site-logo':
						if ( '' === BWFCRM_Email_Design_Store::site_logo() ) {
							$out['errors'][] = self::issue( $path, 'no_site_logo', 'The site has no logo, so this block would show nothing. Use an image block (list-email-images) or a text block with {{business_name}}, or add a logo in the email editor\'s Global Styles.' );
						}
						break;

					case 'email-block/social':
						self::check_social( $out, $attrs, $path );
						break;

					case 'email-block/menu':
						if ( ! empty( $attrs['showSeparator'] ) && 'vertical' === BWFCRM_Email_Render_Js::get( $attrs, 'layout.desktop', 'horizontal' ) ) {
							$out['warnings'][] = self::issue( $path . '/attrs/showSeparator', 'no_effect', 'Separators only show in the horizontal layout.' );
						}
						break;

					case 'email-block/button':
						if ( isset( $attrs['widthPercent'] ) && false !== BWFCRM_Email_Render_Js::get( $attrs, 'autoWidth.desktop' ) ) {
							$out['warnings'][] = self::issue( $path . '/attrs/widthPercent', 'width_ignored', 'widthPercent only applies with autoWidth {"desktop":false}; the Global Style\'s auto width wins otherwise.' );
						}

						self::check_button_padding( $out, $attrs, $path );
						break;

					case 'email-block/text':
						if ( null !== BWFCRM_Email_Render_Js::get( $attrs, 'font.mobile.size', null ) && self::mixes_heading_and_text( (string) BWFCRM_Email_Render_Js::get( $attrs, 'content', '' ) ) ) {
							$out['warnings'][] = self::issue( $path . '/attrs/font', 'mobile_size_flattens_headings', 'font.mobile.size sets every text in this block to one size on mobile, so its heading and its body text look the same there. Put the heading in its own text block.' );
						}
						break;

					case 'email-block/footer':
						if ( false === BWFCRM_Email_Render_Js::get( $attrs, 'isGlobal', true ) && preg_match( '/<p[\s>]/i', (string) BWFCRM_Email_Render_Js::get( $attrs, 'content', '' ) ) ) {
							$out['warnings'][] = self::issue( $path . '/attrs/content', 'nested_paragraph', 'The footer content is already inside a paragraph; drop the <p> tags and use <br> for line breaks.' );
						}
						break;

					case 'email-block/section':
						self::check_background( $out, $attrs, $path );
						break;

					case 'email-block/row':
						foreach ( isset( $attrs['bgColor'] ) && is_array( $attrs['bgColor'] ) ? $attrs['bgColor'] : array() as $screen => $value ) {
							if ( null !== $value && ! is_string( $value ) ) {
								$out['errors'][] = self::issue( $path . '/attrs/bgColor/' . $screen, 'wrong_shape', 'A row\'s bgColor is a plain colour per screen: {"desktop":"#f1f5f9"}. Anything else renders as [object Object], which inboxes show as a random colour.' );
							}
						}
						break;
				}
			}
		);

		return $out;
	}

	private static function check_products( array &$out, array $attrs, $path, array $context ) {
		$feed = isset( $attrs['productFeedType'] ) ? (string) $attrs['productFeedType'] : 'specific';
		$at   = $path . '/attrs/';

		if ( isset( $attrs['onBoarding'] ) && false === $attrs['onBoarding'] ) {
			$out['errors'][] = self::issue( $at . 'onBoarding', 'block_hidden', 'onBoarding false hides the product block. Leave it out.' );
		}

		switch ( $feed ) {
			case 'specific':
				$cells = isset( $attrs['specificProductData'] ) && is_array( $attrs['specificProductData'] ) ? $attrs['specificProductData'] : array();
				$ids   = array();

				foreach ( $cells as $key => $cell ) {
					$id = is_array( $cell ) && isset( $cell['id'] ) ? absint( $cell['id'] ) : 0;

					if ( ! $id ) {
						$out['errors'][] = self::issue( $at . 'specificProductData/' . $key, 'no_product', 'Each entry needs the id of a product (list-products).' );
						continue;
					}

					$ids[] = $id;
					self::check_cell( $out, $attrs, (string) $key, $at . 'specificProductData/' . $key );
				}

				if ( empty( $cells ) ) {
					$out['errors'][] = self::issue( $at . 'specificProductData', 'no_products', 'The specific feed shows only the products in specificProductData, and it is empty, so the block would show nothing. Add products by id ({"00":{"id":142},"01":{"id":156}} - list-products), or choose another feed: best_selling_store, latest or category.' );
				}

				foreach ( BWFCRM_Email_Design_Store::missing_products( $ids ) as $id ) {
					$out['errors'][] = self::issue( $at . 'specificProductData', 'unknown_product', sprintf( 'There is no published product with id %d. list-products gives the ids.', $id ) );
				}
				break;

			case 'category':
				$include = isset( $attrs['productIncludeCategory'] ) ? array_filter( array_map( 'absint', (array) $attrs['productIncludeCategory'] ) ) : array();

				if ( empty( $include ) ) {
					$out['errors'][] = self::issue( $at . 'productIncludeCategory', 'no_category', 'The category feed needs a category term id in productIncludeCategory, e.g. [23] (list-product-categories).' );
				} elseif ( count( $include ) > 1 ) {
					$out['warnings'][] = self::issue( $at . 'productIncludeCategory', 'first_category_only', 'When the email is sent only the first category is used. Use one category per product block.' );
				}

				$exclude = isset( $attrs['productExcludeCategory'] ) ? array_filter( array_map( 'absint', (array) $attrs['productExcludeCategory'] ) ) : array();

				foreach ( BWFCRM_Email_Design_Store::missing_categories( array_merge( $include, $exclude ) ) as $id ) {
					$out['errors'][] = self::issue( $at . 'productIncludeCategory', 'unknown_category', sprintf( 'There is no product category with id %d. list-product-categories gives the ids.', $id ) );
				}
				break;

			case 'related':
				if ( empty( $attrs['productRelatable'] ) ) {
					$out['warnings'][] = self::issue( $at . 'productRelatable', 'related_without_link', 'Without productRelatable (upsells, cross_sells or both) the related feed is just the best sellers.' );
				}

				if ( ! array_intersect( array( 'order', 'cart' ), $context['groups'] ) || '' === $context['event'] ) {
					$out['warnings'][] = self::issue( $at . 'productFeedType', 'related_needs_order', 'The related feed shows products linked to the order or cart. When no order or cart trigger sends the email it shows the best sellers instead. Use best_selling_store here, or pass the automation\'s event.' );
				}
				break;

			case 'best_selling_store':
			case 'latest':
				break;

			default:
				$out['errors'][] = self::issue( $at . 'productFeedType', 'unknown_feed', sprintf( '"%s" is not a feed. Use best_selling_store, latest, category, related or specific.', $feed ) );
		}

		if ( ! empty( $attrs['productExclude'] ) ) {
			foreach ( BWFCRM_Email_Design_Store::missing_products( array_map( 'absint', (array) $attrs['productExclude'] ) ) as $id ) {
				$out['warnings'][] = self::issue( $at . 'productExclude', 'unknown_product', sprintf( 'There is no published product with id %d.', $id ) );
			}
		}
	}

	/**
	 * What a new product block's cards leave unset and would take from the
	 * site's main button and the editor's 50% image: a button sized for a
	 * card, and an image the card's width in a grid.
	 *
	 * @return string[] The attributes filled in.
	 */
	private static function card_style( array &$attrs ) {
		$filled  = array();
		$content = BWFCRM_Email_Render_Js::get( $attrs, 'productContentEnabled.desktop', null );
		$buttons = ! is_array( $content ) || in_array( 'button', $content, true );

		if ( $buttons && ! isset( $attrs['btnPadding'] ) ) {
			$attrs['btnPadding'] = array( 'desktop' => array( 'top' => '9', 'right' => '18', 'bottom' => '9', 'left' => '18', 'unit' => 'px' ) );
			$filled[]            = 'btnPadding 9/18px';
		}

		if ( $buttons && ! isset( $attrs['btnTextFont'] ) ) {
			$attrs['btnTextFont'] = array( 'desktop' => array( 'size' => 14 ) );
			$filled[]             = 'btnTextFont 14px';
		}

		$list = isset( $attrs['layout'] ) && 'list' === $attrs['layout'];

		if ( ! $list && ! isset( $attrs['imageWidth'] ) && ( ! is_array( $content ) || in_array( 'image', $content, true ) ) ) {
			$attrs['imageWidth'] = array( 'desktop' => array( 'value' => 100, 'unit' => '%' ) );
			$filled[]            = 'imageWidth 100%';
		}

		return $filled;
	}

	/**
	 * A heading and body text in one block: a mobile font size then makes them
	 * the same size. A block that is only a heading is sized on purpose.
	 */
	private static function mixes_heading_and_text( $html ) {
		if ( false === strpos( $html, 'data-heading-level' ) ) {
			return false;
		}

		return '' !== trim( html_entity_decode( wp_strip_all_tags( self::without_headings( $html ) ), ENT_QUOTES, 'UTF-8' ) );
	}

	/**
	 * The HTML with every heading span taken out, spans nested in a heading
	 * (a coloured word, a number) with it.
	 *
	 * @param string $html
	 *
	 * @return string
	 */
	private static function without_headings( $html ) {
		while ( preg_match( '/<span\b[^>]*data-heading-level[^>]*>/i', $html, $open, PREG_OFFSET_CAPTURE ) ) {
			$start = $open[0][1];
			$at    = $start + strlen( $open[0][0] );
			$depth = 1;

			while ( $depth > 0 && preg_match( '/<(\/?)span\b[^>]*>/i', $html, $tag, PREG_OFFSET_CAPTURE, $at ) ) {
				$depth += '' === $tag[1][0] ? 1 : -1;
				$at     = $tag[0][1] + strlen( $tag[0][0] );
			}

			// An unclosed heading runs to the end.
			$html = substr( $html, 0, $start ) . ( $depth > 0 ? '' : substr( $html, $at ) );
		}

		return $html;
	}

	/**
	 * A button's padding is the space inside it, around the label: unequal top
	 * and bottom push the label off-centre, and too little crowds it. Space
	 * around a button is its containerPadding.
	 */
	private static function check_button_padding( array &$out, array $attrs, $path ) {
		$padding = BWFCRM_Email_Render_Js::get( $attrs, 'padding.desktop' );

		if ( ! is_array( $padding ) ) {
			return;
		}

		$side = function ( $key ) use ( $padding ) {
			$value = BWFCRM_Email_Render_Js::parse_float( isset( $padding[ $key ] ) ? $padding[ $key ] : 0 );

			return is_nan( $value ) ? 0 : $value;
		};

		if ( abs( $side( 'top' ) - $side( 'bottom' ) ) > 4 || abs( $side( 'left' ) - $side( 'right' ) ) > 4 || $side( 'top' ) < 8 || $side( 'left' ) < 12 ) {
			$out['warnings'][] = self::issue( $path . '/attrs/padding', 'button_padding', sprintf( 'padding is the space inside the button, around its label (%s/%s/%s/%s px here): the label sits off-centre or crowded. Use equal top/bottom and left/right, e.g. 14/28/14/28. For space around the button, set containerPadding.', $side( 'top' ), $side( 'right' ), $side( 'bottom' ), $side( 'left' ) ) );
		}
	}

	/** A specific-feed entry outside the grid is never shown. */
	private static function check_cell( array &$out, array $attrs, $key, $path ) {
		$layout  = isset( $attrs['layout'] ) ? $attrs['layout'] : 'grid';
		$rows    = isset( $attrs['rows'] ) ? max( 1, (int) $attrs['rows'] ) : 1;
		$columns = 'grid' === $layout ? ( isset( $attrs['columns'] ) ? max( 1, (int) $attrs['columns'] ) : 2 ) : 1;

		if ( ! preg_match( '/^(\d)(\d)$/', $key, $m ) || (int) $m[1] >= $rows || (int) $m[2] >= $columns ) {
			$out['errors'][] = self::issue( $path, 'cell_outside_grid', sprintf( 'Entries are keyed by row then column as a string: "00", "01", "10"… With %d row(s) and %d column(s), "%s" is never shown. Raise rows/columns or use a key inside the grid.', $rows, $columns, $key ) );
		}
	}

	private static function check_coupon( array &$out, array $attrs, $path, array $context, $key, $type ) {
		// Left out, the block keeps the editor's default code.
		$value = array_key_exists( $key, $attrs ) ? $attrs[ $key ] : self::manifest_default( 'code' === $key ? 'email-block/coupon' : 'email-block/cart-link', $key );
		$code  = trim( wp_strip_all_tags( is_scalar( $value ) ? (string) $value : '' ) );
		$at    = $path . '/attrs/' . $key;

		if ( 'dynamic' === $type ) {
			if ( ! preg_match( '/\{\{wc_dynamic_coupon id="(\d+)"\}\}/', $code, $m ) ) {
				$out['errors'][] = self::issue( $at, 'bad_coupon_tag', 'An automation coupon is the Create Coupon step\'s tag, {{wc_dynamic_coupon id="<step id>"}} - list-coupons with the automation_id gives it.' );

				return;
			}

			if ( ! $context['automation_id'] ) {
				$out['warnings'][] = self::issue( $at, 'coupon_needs_automation', 'An automation coupon is made by a Create Coupon step of the automation that sends the email; anywhere else the code comes out empty. Pass automation_id so it can be checked.' );

				return;
			}

			$steps = wp_list_pluck( BWFCRM_Email_Design_Store::automation_coupons( $context['automation_id'] ), 'step_id' );

			if ( ! in_array( (int) $m[1], array_map( 'intval', $steps ), true ) ) {
				$out['errors'][] = self::issue( $at, 'unknown_coupon_step', sprintf( 'Automation %d has no active Create Coupon step %d. list-coupons with its automation_id lists them.', $context['automation_id'], (int) $m[1] ) );
			}

			return;
		}

		if ( '' === $code ) {
			$out['errors'][] = self::issue( $at, 'no_coupon', 'Give the coupon code, from list-coupons.' );

			return;
		}

		if ( ! BWFCRM_Email_Design_Store::has_woocommerce() ) {
			return;
		}

		$coupon      = BWFCRM_Email_Design_Store::coupon( $code );
		$placeholder = BWFCRM_Email_Design_Guide::placeholder( 'email-block/coupon', 'code' );

		if ( null === $coupon ) {
			if ( null !== $placeholder && strtoupper( $code ) === strtoupper( $placeholder ) ) {
				$out['errors'][] = self::issue( $at, 'placeholder', sprintf( '%s is the editor\'s example code and is not a coupon in this store. Use a real code (list-coupons), or ask the user which coupon to offer.', $code ) );
			} else {
				$out['warnings'][] = self::issue( $at, 'unknown_coupon', sprintf( 'There is no coupon "%s" in this store yet. Create it in WooCommerce before the email is sent, or use a code from list-coupons.', $code ) );
			}
		} elseif ( ! empty( $coupon['expired'] ) ) {
			$out['warnings'][] = self::issue( $at, 'expired_coupon', sprintf( 'The coupon "%s" expired on %s.', $coupon['code'], (string) $coupon['expires'] ) );
		}
	}

	private static function check_social( array &$out, array $attrs, $path ) {
		if ( ! empty( $attrs['icons'] ) ) {
			return;
		}

		$linked = array_filter(
			BWFCRM_Email_Design_Store::social(),
			static function ( $icon ) {
				return is_array( $icon ) && ! empty( $icon['link'] );
			}
		);

		if ( empty( $linked ) ) {
			$out['warnings'][] = self::issue( $path . '/attrs/icons', 'social_links_empty', 'With no icons of its own the block shows the site\'s social icons, and none of them has a link. Give icons with links: [{"iconName":"instagram","link":"https://..."}].' );
		}
	}

	private static function check_background( array &$out, array $attrs, $path ) {
		foreach ( isset( $attrs['contentBackground'] ) && is_array( $attrs['contentBackground'] ) ? $attrs['contentBackground'] : array() as $screen => $background ) {
			if ( ! is_array( $background ) ) {
				continue;
			}

			if ( isset( $background['image'] ) && '' !== $background['image'] && ! ( is_array( $background['image'] ) && ! empty( $background['image']['url'] ) ) ) {
				$out['errors'][] = self::issue( $path . '/attrs/contentBackground/' . $screen . '/image', 'wrong_shape', 'A background image is an object: {"url":"https://..."}. A string renders url(undefined).' );
			}

			if ( isset( $background['position'] ) && '' !== $background['position'] && ! ( is_array( $background['position'] ) && 2 === count( $background['position'] ) ) ) {
				$out['errors'][] = self::issue( $path . '/attrs/contentBackground/' . $screen . '/position', 'wrong_shape', 'Background position is [x, y] as fractions from 0 to 1, e.g. [0.5, 0.5] for the centre.' );
			}
		}
	}

	/** Blocks that need an order, cart or subscription: said plainly for templates, which have no trigger yet. */
	private static function check_trigger( array &$out, $name, $path, array $context ) {
		if ( 'email-block/payment-schedule' === $name ) {
			$out['errors'][] = self::issue( $path, 'not_rendered', 'FunnelKit Automations does not render the installment schedule block. Use email-block/subscription-info, which shows the schedule for installment plans.' );

			return;
		}

		if ( '' !== $context['event'] ) {
			return;
		}

		$guide = BWFCRM_Email_Design_Guide::block( $name );
		$needs = isset( $guide['needs']['trigger'] ) ? (string) $guide['needs']['trigger'] : '';

		if ( '' === $needs || ! in_array( $needs, self::TRIGGER_GROUPS, true ) ) {
			return;
		}

		$without = isset( $guide['without_context'] ) ? (string) $guide['without_context'] : 'empty';

		$out['warnings'][] = self::issue( $path, 'needs_trigger', sprintf( 'This block fills in only when an automation with a %s trigger sends the email; in a broadcast or anywhere else it shows %s. Use this template only in such automations, or pass the automation\'s event to check it.', $needs, $without ) );
	}

	private static function check_condition( array &$out, array $attrs, $path, array $context ) {
		$rules = BWFCRM_Email_Render_Js::get( $attrs, 'conditional.rules', array() );

		if ( empty( $rules ) ) {
			return;
		}

		if ( ! is_array( $rules ) || array_filter( $rules, static function ( $group ) { return ! is_array( $group ); } ) ) {
			$out['errors'][] = self::issue( $path . '/attrs/conditional/rules', 'wrong_shape', 'rules is a list of groups, each a list of rules: [[{"filter":"...","rule":"...","data":"..."}]]. Groups are OR, rules in a group are AND.' );

			return;
		}

		if ( '' === $context['event'] ) {
			$out['warnings'][] = self::issue( $path . '/attrs/conditional', 'condition_not_checked', 'Display conditions are only checked when an automation sends the email; in a broadcast or preview the block always shows.' );
		}

		if ( class_exists( 'BWFCRM_Email_Design_Conditions' ) ) {
			foreach ( BWFCRM_Email_Design_Conditions::check_rules( $rules, $context['event'] ) as $issue ) {
				$out[ $issue['bucket'] ][] = self::issue( $path . '/attrs/conditional/rules' . $issue['path'], $issue['code'], $issue['message'] );
			}
		}
	}

	/**
	 * Images on a local or private address: inboxes cannot load them, and
	 * neither can the email editor, which runs on a public site.
	 */
	private static function check_image_hosts( array &$out, array $attrs, $path ) {
		$found = array();

		array_walk_recursive(
			$attrs,
			function ( $value, $key ) use ( &$found ) {
				if ( 'url' === $key && is_string( $value ) && preg_match( '#\.(?:jpe?g|png|gif|webp|svg)(?:[?\#]|$)#i', $value ) && self::is_private_host( (string) wp_parse_url( $value, PHP_URL_HOST ) ) ) {
					$found[] = $value;
				}
			}
		);

		foreach ( array_unique( $found ) as $url ) {
			$out['warnings'][] = self::issue( $path . '/attrs', 'private_image', sprintf( 'The image %s is on a local or private address: recipients\' inboxes cannot load it, and the email editor (on a public site) shows it blank. Use an image on the site\'s public address, or any public image URL.', basename( (string) wp_parse_url( $url, PHP_URL_PATH ) ) ) );
		}
	}

	private static function is_private_host( $host ) {
		$host = strtolower( trim( $host, '[]' ) );

		if ( '' === $host || 'localhost' === $host || preg_match( '/\.(?:local|localhost|test|internal|lan)$/', $host ) ) {
			return '' !== $host;
		}

		if ( filter_var( $host, FILTER_VALIDATE_IP ) ) {
			return false === filter_var( $host, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE );
		}

		return false;
	}

	/** Options with no effect, and the ones the editor works out on save. */
	private static function check_hands_off( array &$out, $name, array $attrs, $path ) {
		foreach ( BWFCRM_Email_Design_Guide::hands_off( $name ) as $key ) {
			// A design read back from a template carries every default; only a value someone chose counts.
			if ( ! array_key_exists( $key, $attrs ) || $attrs[ $key ] === self::manifest_default( $name, $key ) ) {
				continue;
			}

			$entry = BWFCRM_Email_Design_Guide::attribute( $name, $key );

			if ( ! empty( $entry['ignored'] ) ) {
				$out['warnings'][] = self::issue( $path . '/attrs/' . $key, 'no_effect', sprintf( '%s has no effect: %s', $key, isset( $entry['description'] ) ? $entry['description'] : 'it is not used.' ) );
			}
		}
	}

	private static function manifest_default( $block, $key ) {
		$manifest = BWFCRM_Email_Design_Manifest::get();

		return is_array( $manifest ) && isset( $manifest['blocks'][ $block ]['attributes'][ $key ]['default'] ) ? $manifest['blocks'][ $block ]['attributes'][ $key ]['default'] : null;
	}

	/** Editor defaults that are stand-ins, left as they are. */
	private static function check_placeholders( array &$out, $name, array $attrs, $path ) {
		foreach ( array( 'content' ) as $key ) {
			$placeholder = BWFCRM_Email_Design_Guide::placeholder( $name, $key );

			if ( null === $placeholder ) {
				continue;
			}

			$value = array_key_exists( $key, $attrs ) ? $attrs[ $key ] : null;

			if ( null === $value || trim( wp_strip_all_tags( (string) $value ) ) === trim( wp_strip_all_tags( $placeholder ) ) ) {
				$out['warnings'][] = self::issue( $path . '/attrs/' . $key, 'placeholder', sprintf( '"%s" is the editor\'s placeholder and would be sent as written. Write the real text.', trim( wp_strip_all_tags( $placeholder ) ) ) );
			}
		}

		if ( 'email-block/menu' === $name ) {
			foreach ( isset( $attrs['menuItems'] ) && is_array( $attrs['menuItems'] ) ? $attrs['menuItems'] : array() as $i => $item ) {
				if ( is_array( $item ) && isset( $item['text'] ) && preg_match( '/^\s*Menu \d+\s*$/', wp_strip_all_tags( (string) $item['text'] ) ) ) {
					$out['warnings'][] = self::issue( $path . '/attrs/menuItems/' . $i . '/text', 'placeholder', 'This is the editor\'s placeholder menu item. Give it real text and a link.' );
				}
			}
		}
	}

	/**
	 * Calls $visit( &$block, $path ) for every block, depth first, with its JSON-pointer path.
	 *
	 * @param array[]  $tree
	 * @param callable $visit
	 * @param string   $prefix
	 */
	private static function walk( array &$tree, callable $visit, $prefix = '' ) {
		foreach ( $tree as $i => &$block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			$path = $prefix . '/' . $i;

			$visit( $block, $path );

			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				self::walk( $block['innerBlocks'], $visit, $path . '/innerBlocks' );
			}
		}

		unset( $block );
	}

	private static function issue( $path, $code, $message ) {
		return array(
			'path'    => $path,
			'code'    => $code,
			'message' => $message,
		);
	}
}
