<?php

defined( 'ABSPATH' ) || exit;

/**
 * The email editor's Audit Email, on the rendered email HTML: links that go
 * nowhere, links that do not answer, shortened links, the unsubscribe link
 * and the size at which Gmail clips a message - so an email passes the audit
 * a person runs in the editor before it is saved, not after.
 *
 * Every check but the broken-link one reads the HTML only; that one asks
 * each outside address, and runs only when asked for.
 */
class BWFCRM_Email_Design_Audit {

	/** Size above which the editor warns, in KB: Gmail clips a message past about 102 KB. */
	const MAX_KB = 100;

	/** Most distinct addresses one audit asks. */
	const MAX_LINKS = 30;

	/** Seconds to wait for each address. */
	const TIMEOUT = 5;

	/** Seconds all link requests of one audit may take together, well inside PHP's usual 30s limit. */
	const TIME_BUDGET = 20;

	/** Seconds check_urls() may spend: it checks at most 10 addresses, and a rerun answers from the cache. */
	const URLS_BUDGET = 10;

	/** How long an address's answer is remembered. */
	const CACHE_TTL = HOUR_IN_SECONDS;

	/** Link shorteners, as the editor lists them. */
	const SHORTENERS = array( 'bit.ly', 'tinyurl.com', 't.co', 'goo.gl', 'ow.ly', 'is.gd', 'buff.ly', 'short.io', 'rebrand.ly', 'bl.ink', 'shorturl.at', 'cutt.ly', 'youtu.be', 'fb.me', 'fb.watch', 'pin.it', 'lnkd.in', 'vm.tiktok.com', 'redd.it', 'trib.al', 'tiny.cc', 'amzn.to', 'amzn.eu' );

	/** Elements the editor renders as a link only when one is set, by class. */
	const LINKED_PARTS = array(
		'bwfbe-block-btn-content' => 'button',
		'coupon-btn-text'         => 'button',
		'bwf-menu-item'           => 'link',
	);

	/**
	 * @param string $html  The email as rendered, merge tags still in it.
	 * @param array  $args  transactional (bool), check_links (bool).
	 *
	 * @return array { passed, checks: [{ key, label, passed, items[], message }], size_kb }
	 */
	public static function run( $html, array $args = array() ) {
		$html          = (string) $html;
		$transactional = ! empty( $args['transactional'] );
		$links         = self::links( self::with_footer( $html ) );
		$size_kb       = (int) round( strlen( $html ) / 1024 );

		$checks = array(
			self::check( 'missing_urls', 'No Missing URLs', $links['missing'], 'These have no link, or one that is not a full http(s):// address: give each a real page or a merge tag.' ),
			self::broken( $links['reachable'], ! empty( $args['check_links'] ) ),
			self::check( 'shortened_urls', 'No Shortened URLs', self::shortened( $links['all'] ), 'Link shorteners hide where a link goes, and spam filters distrust them: use the full address.' ),
			self::check( 'unsubscribe', 'Unsubscribe Merge Tag', ( $transactional || $links['unsubscribe'] ) ? array() : array( 'no {{unsubscribe_link}}' ), 'A marketing email needs {{unsubscribe_link}} as a link\'s address - in a text link, or through the footer block.' ),
			self::check( 'email_size', 'Email Size', $size_kb > self::MAX_KB ? array( $size_kb . ' KB' ) : array(), sprintf( 'Over %d KB, Gmail clips the email and hides its end - often the footer and unsubscribe link. Remove sections or long HTML.', self::MAX_KB ) ),
		);

		$passed = true;

		foreach ( $checks as $check ) {
			if ( false === $check['passed'] ) {
				$passed = false;
			}
		}

		$report = array(
			'passed'  => $passed,
			'checks'  => $checks,
			'size_kb' => $size_kb,
		);

		if ( ! empty( $args['list_links'] ) ) {
			$report['links'] = self::outside_urls( $links['reachable'] );
		}

		return $report;
	}

	/**
	 * The broken- and shortened-link checks on a list of addresses, without an
	 * email around them: check-email-links asks a few per call, so each call
	 * stays short. Same cache, same safe requests, same answers as the audit.
	 *
	 * @param string[] $urls http(s) addresses.
	 *
	 * @return array { checks: [broken_urls, shortened_urls], checked: int }
	 */
	public static function check_urls( array $urls ) {
		$links = array();

		foreach ( $urls as $url ) {
			$links[] = array( 'label' => '', 'url' => (string) $url );
		}

		return array(
			'checks'  => array(
				self::broken( $links, true, self::URLS_BUDGET ),
				self::check( 'shortened_urls', 'No Shortened URLs', self::shortened( $links ), 'Link shorteners hide where a link goes, and spam filters distrust them: use the full address.' ),
			),
			'checked' => count( $links ),
		);
	}

	/** Outside addresses the broken-link check would ask, once each, in email order. */
	private static function outside_urls( array $reachable ) {
		$home = preg_replace( '/^www\./', '', strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ) );
		$urls = array();

		foreach ( $reachable as $link ) {
			$host = preg_replace( '/^www\./', '', strtolower( (string) wp_parse_url( $link['url'], PHP_URL_HOST ) ) );

			if ( $host !== $home && ! in_array( $link['url'], $urls, true ) && count( $urls ) < self::MAX_LINKS ) {
				$urls[] = $link['url'];
			}
		}

		return $urls;
	}

	private static function check( $key, $label, array $items, $message ) {
		return array(
			'key'     => $key,
			'label'   => $label,
			'passed'  => empty( $items ),
			'items'   => array_values( $items ),
			'message' => empty( $items ) ? '' : $message,
		);
	}

	/** The global footer, where the footer block's unsubscribe link lives, in place of its tag. */
	private static function with_footer( $html ) {
		if ( false === strpos( $html, '{{mail_footer}}' ) || ! class_exists( 'BWFAN_Common' ) || ! method_exists( 'BWFAN_Common', 'get_global_settings' ) ) {
			return $html;
		}

		$settings = BWFAN_Common::get_global_settings();
		$footer   = isset( $settings['bwfan_email_footer_setting'] ) ? (string) $settings['bwfan_email_footer_setting'] : '';

		return str_replace( '{{mail_footer}}', $footer, $html );
	}

	/**
	 * Every link, sorted as the editor sorts them.
	 *
	 * @return array { all: string[], missing: string[], reachable: [{ label, url }], unsubscribe: bool }
	 */
	private static function links( $html ) {
		$out = array( 'all' => array(), 'missing' => array(), 'reachable' => array(), 'unsubscribe' => false );

		if ( '' === trim( $html ) || ! class_exists( 'DOMDocument' ) ) {
			return $out;
		}

		$doc      = new DOMDocument();
		$previous = libxml_use_internal_errors( true );

		$doc->loadHTML( '<?xml encoding="utf-8"?>' . $html );
		libxml_clear_errors();
		libxml_use_internal_errors( $previous );

		foreach ( $doc->getElementsByTagName( 'a' ) as $a ) {
			$url   = trim( (string) $a->getAttribute( 'href' ) );
			$label = self::label( $a );

			$out['all'][] = array( 'label' => $label, 'url' => $url );

			if ( preg_match( '/\{\{[^}]*_?unsubscribe_link[^}]*\}\}/i', $url ) ) {
				$out['unsubscribe'] = true;
			}

			if ( preg_match( '/^(mailto|tel|sms):/i', $url ) ) {
				continue;
			}

			// A merge tag fills the address in at send time.
			if ( preg_match( '/\{\{[^{}]*\}\}/', $url ) && preg_match( '/^(https?:\/\/|\{\{)/i', $url ) ) {
				continue;
			}

			if ( ! self::is_web_url( $url ) ) {
				$out['missing'][] = '' !== $label ? $label : '(a link)';
			} else {
				$out['reachable'][] = array( 'label' => $label, 'url' => $url );
			}
		}

		// Buttons, coupon buttons and menu items without a link are not <a> at all.
		$xpath = new DOMXPath( $doc );

		foreach ( self::LINKED_PARTS as $class => $kind ) {
			foreach ( $xpath->query( '//*[contains(concat(" ", normalize-space(@class), " "), " ' . $class . ' ")]' ) as $node ) {
				if ( 'a' !== strtolower( $node->nodeName ) ) {
					$text             = trim( preg_replace( '/\s+/', ' ', $node->textContent ) );
					$out['missing'][] = ( '' !== $text ? $text : 'a ' . $kind ) . ' (' . $kind . ')';
				}
			}
		}

		foreach ( $xpath->query( '//*[contains(concat(" ", normalize-space(@class), " "), " bwfbe-social-icon-wrap ")]' ) as $node ) {
			if ( 0 === $node->getElementsByTagName( 'a' )->length ) {
				$img              = $node->getElementsByTagName( 'img' )->item( 0 );
				$out['missing'][] = ( $img ? (string) $img->getAttribute( 'alt' ) : 'a social icon' ) . ' (social icon)';
			}
		}

		$out['missing'] = array_values( array_unique( $out['missing'] ) );

		return $out;
	}

	/** A link's words, or its image's alt text. */
	private static function label( DOMElement $a ) {
		$text = trim( preg_replace( '/\s+/', ' ', $a->textContent ) );

		if ( '' === $text ) {
			$img  = $a->getElementsByTagName( 'img' )->item( 0 );
			$text = $img ? trim( (string) $img->getAttribute( 'alt' ) ) : '';
		}

		return mb_strlen( $text ) > 60 ? mb_substr( $text, 0, 59 ) . '…' : $text;
	}

	private static function is_web_url( $url ) {
		$parts = wp_parse_url( $url );

		return is_array( $parts ) && isset( $parts['scheme'], $parts['host'] ) && in_array( strtolower( $parts['scheme'] ), array( 'http', 'https' ), true ) && '' !== $parts['host'];
	}

	private static function shortened( array $links ) {
		$found = array();

		foreach ( $links as $link ) {
			$host = strtolower( (string) wp_parse_url( $link['url'], PHP_URL_HOST ) );
			$host = 0 === strpos( $host, 'www.' ) ? substr( $host, 4 ) : $host;

			if ( '' !== $host && in_array( $host, self::SHORTENERS, true ) ) {
				$found[] = ( '' !== $link['label'] ? $link['label'] . ' ' : '' ) . '(' . $link['url'] . ')';
			}
		}

		return array_values( array_unique( $found ) );
	}

	/**
	 * Asks each outside address whether it answers. Links to this site are
	 * left out: a request to the site from inside one of its own requests can
	 * wait on itself.
	 */
	private static function broken( array $links, $enabled, $budget = self::TIME_BUDGET ) {
		$check = self::check( 'broken_urls', 'No Broken URLs', array(), '' );

		if ( ! $enabled ) {
			$check['passed']  = null;
			$check['message'] = 'Not checked here: run audit-email-design, which asks each address.';

			return $check;
		}

		$home      = preg_replace( '/^www\./', '', strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ) );
		$asked     = array();
		$broken    = array();
		$blocked   = 0;
		$unchecked = 0;
		$deadline  = microtime( true ) + $budget;

		foreach ( $links as $link ) {
			$url  = $link['url'];
			$host = preg_replace( '/^www\./', '', strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) ) );

			if ( $host === $home || isset( $asked[ $url ] ) || count( $asked ) >= self::MAX_LINKS ) {
				continue;
			}

			$asked[ $url ] = true;
			$answer        = self::answers( $url, $deadline );

			if ( 'unchecked' === $answer ) {
				++$unchecked;
			} elseif ( 'blocked' === $answer ) {
				++$blocked;
			} elseif ( 'broken' === $answer ) {
				$broken[] = ( '' !== $link['label'] ? $link['label'] . ' ' : '' ) . '(' . $url . ')';
			}
		}

		$check = self::check( 'broken_urls', 'No Broken URLs', $broken, 'These addresses did not answer, or answered that the page is gone: fix or remove them.' );

		// A site that blocks outside requests cannot tell a broken link from a blocked one.
		if ( $blocked > 0 && empty( $broken ) ) {
			$check['passed']  = null;
			$check['message'] = sprintf( 'Not checked: this site blocks outside requests, so %d address(es) could not be asked. Open the links, or run the editor\'s Audit Email.', $blocked );
		} elseif ( $unchecked > 0 ) {
			$check['message'] = trim( $check['message'] . sprintf( ' %d address(es) were not checked: the others took too long to answer. Run the audit again to check them.', $unchecked ) );

			if ( empty( $broken ) ) {
				$check['passed'] = null;
			}
		}

		return $check;
	}

	/**
	 * Whether an address answers with a page: ok, broken, or blocked when the
	 * site allows no outside requests; unchecked when the audit's time is up.
	 * Remembered for an hour, but not blocked, unchecked or unanswered (DNS,
	 * SSL or a timeout may pass).
	 *
	 * @param string $url
	 * @param float  $deadline microtime() by which every request must be done.
	 */
	private static function answers( $url, $deadline ) {
		$key    = 'bwfcrm_email_audit_' . md5( $url );
		$cached = get_transient( $key );

		if ( false !== $cached ) {
			return $cached;
		}

		$left = $deadline - microtime( true );

		if ( $left < 1 ) {
			return 'unchecked';
		}

		// Each redirect hop waits the full timeout again: the time left is shared by the request and its 3 redirects.
		$args     = array( 'timeout' => min( self::TIMEOUT, $left / 4 ), 'redirection' => 3 );
		$response = wp_safe_remote_head( $url, $args );

		// WP_HTTP_BLOCK_EXTERNAL, or a filter refusing the request: nothing was asked.
		if ( is_wp_error( $response ) && 'http_request_not_executed' === $response->get_error_code() ) {
			return 'blocked';
		}

		$code = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );

		// Some servers refuse HEAD, or anything that looks like a bot, while the page is fine.
		if ( in_array( $code, array( 403, 405, 501 ), true ) || 0 === $code ) {
			$left = $deadline - microtime( true );

			if ( $left < 1 ) {
				return 'unchecked';
			}

			$args['timeout'] = min( self::TIMEOUT, $left / 4 );
			$response        = wp_safe_remote_get( $url, $args + array( 'limit_response_size' => 1024 ) );
			$code            = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );
		}

		// No answer in a wait the audit's time cut short (by more than a second) says nothing about the address.
		if ( 0 === $code && $args['timeout'] < self::TIMEOUT - 1 ) {
			return 'unchecked';
		}

		// Gone, or not there at all; a refusal (401, 403, 429) still says the address is real.
		$answer = 0 !== $code && 404 !== $code && 410 !== $code && $code < 500 ? 'ok' : 'broken';

		if ( 0 !== $code ) {
			set_transient( $key, $answer, self::CACHE_TTL );
		}

		return $answer;
	}
}
