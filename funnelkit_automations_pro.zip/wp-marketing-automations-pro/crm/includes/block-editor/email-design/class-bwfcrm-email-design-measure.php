<?php

defined( 'ABSPATH' ) || exit;

/**
 * The sizes the email editor measures on screen and saves into a design, worked
 * out here for designs that never went through the editor.
 *
 * The editor watches some elements as they render and writes their width back
 * into the block: an image in percent width stores its rendered pixel width
 * (Outlook sizes the image by it), and the product grid stores its container
 * and column widths (send time lays the grid out with them). A design saved
 * through MCP has no screen, so these are computed from the layout the same
 * elements would have had:
 *
 *  - image / site logo, width in %: the smaller of the image's own width and
 *    the column's inner width, times the percentage;
 *  - best-selling products: the column's inner width, and that shared out
 *    between the grid's columns;
 *  - the footer: the global footer copied in as its text, as the editor
 *    fills an empty footer block.
 *
 * Values the editor measured are kept for the product grid; images in percent
 * width are recomputed, as the editor recomputes them whenever it loads the
 * design - unless the image's own size cannot be read and a measured width is
 * already there.
 */
class BWFCRM_Email_Design_Measure {

	/** Largest image download read to learn an image's size; its header is at the start. */
	const MAX_IMAGE_BYTES = 262144;

	/** Most images downloaded in one budget (one apply(), or every apply() sharing a budget name), at up to 5 seconds each; the rest count as unknown. */
	const MAX_REMOTE_FETCHES = 10;

	/** Seconds one budget may spend downloading images, so a slow image host cannot outlast the request. */
	const TIME_BUDGET = 8;

	/** How long an image's width, once read, is remembered across requests: a day. */
	const CACHE_TTL = 86400;

	/** @var array url => width|null, for one request. */
	private static $widths = array();

	/** @var int Downloads made in the current budget. */
	private static $fetches = 0;

	/** @var float microtime() by which the current budget stops downloading. */
	private static $deadline = 0.0;

	/** @var bool Whether the current budget ran out of downloads or time. */
	private static $spent = false;

	/** @var string|null Name of the current budget; null = the last apply() had its own. */
	private static $budget = null;

	/**
	 * @param array[]     $tree     A completed tree (column widths in place).
	 * @param array       $settings The email's settings.
	 * @param string|null $budget   Null: this call gets its own download budget. A name: every
	 *                              call passing that same name, one after another, shares one
	 *                              budget (several designs saved in one request); a new name
	 *                              starts a fresh one.
	 *
	 * @return array { tree: array[], warnings: array[] }
	 */
	public static function apply( array $tree, array $settings = array(), $budget = null ) {
		$warnings = array();
		$budget   = null === $budget ? null : (string) $budget;

		if ( null === $budget || $budget !== self::$budget ) {
			self::$fetches  = 0;
			self::$deadline = microtime( true ) + self::TIME_BUDGET;
			self::$spent    = false;
		}
		self::$budget = $budget;

		foreach ( $tree as $r => $row ) {
			foreach ( isset( $row['innerBlocks'] ) ? (array) $row['innerBlocks'] : array() as $s => $section ) {
				foreach ( isset( $section['innerBlocks'] ) ? (array) $section['innerBlocks'] : array() as $c => $column ) {
					$width = BWFCRM_Email_Render_Js::parse_float( BWFCRM_Email_Render_Js::get( isset( $column['attrs'] ) ? BWFCRM_Email_Render_Js::plain( $column['attrs'] ) : array(), 'width.desktop.width' ) );

					if ( is_nan( $width ) || $width <= 0 ) {
						continue;
					}

					foreach ( isset( $column['innerBlocks'] ) ? (array) $column['innerBlocks'] : array() as $b => $block ) {
						$path  = '/' . $r . '/innerBlocks/' . $s . '/innerBlocks/' . $c . '/innerBlocks/' . $b;
						$attrs = isset( $block['attrs'] ) ? BWFCRM_Email_Render_Js::plain( $block['attrs'] ) : array();
						$new   = null;

						if ( ! isset( $block['name'] ) ) {
							continue;
						}

						if ( 'email-block/image' === $block['name'] || 'email-block/site-logo' === $block['name'] ) {
							$new = self::image( $block['name'], $attrs, $width, $path, $warnings );
						} elseif ( 'email-block/best-selling-product' === $block['name'] ) {
							$new = self::products( $attrs, $width );
						} elseif ( 'email-block/footer' === $block['name'] ) {
							$new = self::footer( $attrs );
						}

						if ( null !== $new ) {
							$tree[ $r ]['innerBlocks'][ $s ]['innerBlocks'][ $c ]['innerBlocks'][ $b ]['attrs'] = $new;
						}
					}
				}
			}
		}

		return array(
			'tree'     => $tree,
			'warnings' => $warnings,
		);
	}

	/** The width inside a block's side padding. */
	private static function inner( array $attrs, $name, $column_width ) {
		$padding = BWFCRM_Email_Render_Js::get( BWFCRM_Email_Design_Tree::with_defaults( $name, $attrs ), 'padding.desktop' );
		$left    = BWFCRM_Email_Render_Js::parse_float( BWFCRM_Email_Render_Js::get( $padding, 'left' ) );
		$right   = BWFCRM_Email_Render_Js::parse_float( BWFCRM_Email_Render_Js::get( $padding, 'right' ) );

		return max( 0, $column_width - ( is_nan( $left ) ? 0 : $left ) - ( is_nan( $right ) ? 0 : $right ) );
	}

	private static function image( $name, array $attrs, $column_width, $path, array &$warnings ) {
		$full = BWFCRM_Email_Design_Tree::with_defaults( $name, $attrs );

		// A pixel width is the user's; the editor measures only percent widths.
		if ( 'px' === BWFCRM_Email_Render_Js::get( $full, 'widthUnit.desktop' ) ) {
			return null;
		}

		$url = 'email-block/site-logo' === $name ? self::site_logo() : BWFCRM_Email_Render_Js::get( $full, 'image.url' );

		if ( ! is_string( $url ) || '' === trim( $url ) ) {
			return null;
		}

		$key     = 'email-block/site-logo' === $name ? 'value' : 'width';
		$percent = BWFCRM_Email_Render_Js::parse_float( BWFCRM_Email_Render_Js::get( $full, 'width.desktop.' . $key ) );
		$auto    = BWFCRM_Email_Render_Js::get( $attrs, 'autoWidth.desktop' );

		// A logo without its own size shows at the site's logo size, as in the editor.
		if ( 'email-block/site-logo' === $name ) {
			$site    = self::editor_setting();
			$auto    = null === $auto ? BWFCRM_Email_Render_Js::get( $site, 'logoAuto.desktop', true ) : $auto;
			$percent = is_nan( $percent ) ? BWFCRM_Email_Render_Js::parse_float( BWFCRM_Email_Render_Js::get( $site, 'logoSize.desktop.value', 100 ) ) : $percent;
		}

		// Auto width shows the image at its own size, capped by the column: no percentage applies.
		$percent = true === $auto || is_nan( $percent ) || $percent <= 0 ? 100 : $percent;
		$inner   = self::inner( $attrs, $name, $column_width );
		$natural = self::natural_width( $url );

		if ( null === $natural ) {
			// A width the editor measured beats a guess.
			if ( BWFCRM_Email_Render_Js::parse_float( BWFCRM_Email_Render_Js::get( $attrs, 'imageWidth.desktop' ) ) > 0 ) {
				return null;
			}

			$natural = $inner;
			$warnings[] = array(
				'path'    => $path . '/attrs/image',
				'code'    => 'image_size_unknown',
				'message' => 'The image\'s own width could not be read, so it is assumed to fill its column. Open the email in the editor once to measure it exactly.',
			);
		}

		$measured = round( min( $natural, $inner ) * $percent / 100, 2 );
		$current  = isset( $attrs['imageWidth'] ) && is_array( $attrs['imageWidth'] ) ? $attrs['imageWidth'] : array();

		$current['desktop'] = floor( $measured ) === $measured ? (int) $measured : $measured;
		$attrs['imageWidth'] = $current;

		return $attrs;
	}

	private static function products( array $attrs, $column_width ) {
		$full    = BWFCRM_Email_Design_Tree::with_defaults( 'email-block/best-selling-product', $attrs );
		$changed = false;

		// A width that is not a number ("wide") is measured as if unset: it cannot be done sums with.
		if ( ! self::is_width( BWFCRM_Email_Render_Js::get( $attrs, 'containerWidth.desktop' ) ) ) {
			$container               = BWFCRM_Email_Render_Js::truthy( BWFCRM_Email_Render_Js::get( $full, 'responsive' ) )
				? self::inner( $attrs, 'email-block/best-selling-product', $column_width )
				: $column_width;
			$attrs['containerWidth'] = array( 'desktop' => $container );
			$changed                 = true;
		}

		if ( ! self::is_width( BWFCRM_Email_Render_Js::get( $attrs, 'colWidth.desktop' ) ) ) {
			$columns = max( 1, (int) BWFCRM_Email_Render_Js::get( $full, 'columns', 2 ) );
			$gap     = BWFCRM_Email_Render_Js::parse_float( BWFCRM_Email_Render_Js::get( $full, 'colGap.desktop.value' ) );
			$gap     = is_nan( $gap ) ? 0 : $gap;
			$width   = ( (float) $attrs['containerWidth']['desktop'] - $gap * ( $columns - 1 ) ) / $columns;

			// The editor stores the measured column plus 2; send time then trims the last column to fit.
			$attrs['colWidth'] = array( 'desktop' => round( $width, 2 ) + 2 );
			$changed           = true;
		}

		if ( ! self::is_width( BWFCRM_Email_Render_Js::get( $attrs, 'imgWidthPx.desktop' ) ) ) {
			$attrs['imgWidthPx'] = array( 'desktop' => self::product_image_width( $full, $attrs ) );
			$changed             = true;
		}

		return $changed ? $attrs : null;
	}

	/** A set, positive, numeric width (a number or a numeric string). */
	private static function is_width( $value ) {
		return ( is_int( $value ) || is_float( $value ) || ( is_string( $value ) && is_numeric( $value ) ) ) && (float) $value > 0;
	}

	/**
	 * The product picture's width as the editor measures it: in a grid, the
	 * card's width times the image width; in a list, 35% of the row times it.
	 * The editor adds 2 for every feed but specific.
	 */
	private static function product_image_width( array $full, array $attrs ) {
		$percent = BWFCRM_Email_Render_Js::parse_float( BWFCRM_Email_Render_Js::get( $full, 'imageWidth.desktop.value', 100 ) );
		$percent = is_nan( $percent ) || $percent <= 0 ? 100 : $percent;

		if ( 'list' === BWFCRM_Email_Render_Js::get( $full, 'layout' ) ) {
			$width = (float) $attrs['containerWidth']['desktop'] * 0.35 * $percent / 100;
		} else {
			$width = ( (float) $attrs['colWidth']['desktop'] - 2 ) * $percent / 100;
		}

		return (int) round( $width ) + ( 'specific' === BWFCRM_Email_Render_Js::get( $full, 'productFeedType' ) ? 0 : 2 );
	}

	/**
	 * The footer block, when it has no text of its own, takes the global email
	 * footer as its content the moment the editor loads it - inline styles
	 * removed, as the editor removes them.
	 */
	private static function footer( array $attrs ) {
		if ( ! BWFCRM_Email_Render_Js::is_empty( BWFCRM_Email_Render_Js::get( $attrs, 'content', '' ) ) ) {
			return null;
		}

		$settings = class_exists( 'BWFAN_Common' ) && method_exists( 'BWFAN_Common', 'get_global_settings' ) ? BWFAN_Common::get_global_settings() : array();
		$footer   = isset( $settings['bwfan_email_footer_setting'] ) && is_string( $settings['bwfan_email_footer_setting'] ) ? $settings['bwfan_email_footer_setting'] : '';

		if ( '' === $footer ) {
			return null;
		}

		$attrs['content'] = preg_replace( '/style\s*=\s*(["\'])(.*?)\1/', '', $footer );

		return $attrs;
	}

	/** The block editor's Global Style settings. */
	private static function editor_setting() {
		$settings = class_exists( 'BWFAN_Common' ) && method_exists( 'BWFAN_Common', 'get_block_editor_settings' ) ? BWFAN_Common::get_block_editor_settings() : array();

		return is_array( $settings ) && isset( $settings['setting'] ) && is_array( $settings['setting'] ) ? BWFCRM_Email_Render_Js::plain( $settings['setting'] ) : array();
	}

	private static function site_logo() {
		$settings = class_exists( 'BWFAN_Common' ) && method_exists( 'BWFAN_Common', 'get_block_editor_settings' ) ? BWFAN_Common::get_block_editor_settings() : array();
		$logo     = BWFCRM_Email_Render_Js::get( is_array( $settings ) ? $settings : array(), 'site.logo', '' );

		return is_string( $logo ) ? $logo : '';
	}

	/**
	 * An image's own width in pixels: a Media Library image from its metadata,
	 * anything else from the first bytes of the file. Null when it cannot be read.
	 *
	 * @param string $url
	 *
	 * @return float|null
	 */
	public static function natural_width( $url ) {
		if ( array_key_exists( $url, self::$widths ) ) {
			return self::$widths[ $url ];
		}

		/**
		 * The width of an image an email design uses, before it is looked up.
		 *
		 * @param float|null $width Null to look it up.
		 * @param string     $url
		 */
		$width = apply_filters( 'bwfcrm_email_design_image_width', null, $url );

		if ( null === $width ) {
			$width = self::attachment_width( $url );
		}

		if ( null === $width ) {
			$width = self::remote_width( $url );
		}

		// Out of downloads or time: unknown for now, not remembered, so a later apply() may still look.
		if ( null === $width && self::$spent ) {
			return null;
		}

		self::$widths[ $url ] = null === $width ? null : (float) $width;

		return self::$widths[ $url ];
	}

	private static function attachment_width( $url ) {
		if ( ! function_exists( 'attachment_url_to_postid' ) || ! function_exists( 'wp_get_attachment_metadata' ) ) {
			return null;
		}

		$id = attachment_url_to_postid( $url );

		if ( ! $id ) {
			return null;
		}

		$meta = wp_get_attachment_metadata( $id );

		return is_array( $meta ) && ! empty( $meta['width'] ) ? (float) $meta['width'] : null;
	}

	private static function remote_width( $url ) {
		if ( ! function_exists( 'wp_safe_remote_get' ) || ! preg_match( '#^https?://#i', $url ) ) {
			return null;
		}

		$key    = 'bwfcrm_email_img_w_' . md5( $url );
		$cached = function_exists( 'get_transient' ) ? get_transient( $key ) : false;

		if ( is_numeric( $cached ) && $cached > 0 ) {
			return (float) $cached;
		}

		$left = self::$deadline - microtime( true );

		if ( self::$spent || ++self::$fetches > self::MAX_REMOTE_FETCHES || $left < 1 ) {
			self::$spent = true;

			return null;
		}

		// The safe variant refuses local and private addresses: the URL came from the AI client.
		$response = wp_safe_remote_get(
			$url,
			array(
				'timeout'             => min( 5, $left ),
				'redirection'         => 2,
				'limit_response_size' => self::MAX_IMAGE_BYTES,
			)
		);

		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			return null;
		}

		$body = wp_remote_retrieve_body( $response );
		$size = '' !== $body && function_exists( 'getimagesizefromstring' ) ? @getimagesizefromstring( $body ) : false; // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- a truncated or non-image body is simply "unknown".

		if ( ! is_array( $size ) || empty( $size[0] ) ) {
			return null;
		}

		// Only a width read is remembered: an address that failed may answer next time.
		if ( function_exists( 'set_transient' ) ) {
			set_transient( $key, (float) $size[0], self::CACHE_TTL );
		}

		return (float) $size[0];
	}
}
