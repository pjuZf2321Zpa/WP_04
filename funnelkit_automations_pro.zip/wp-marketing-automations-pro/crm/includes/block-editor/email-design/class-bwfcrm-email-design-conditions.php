<?php

defined( 'ABSPATH' ) || exit;

/**
 * Display conditions of email blocks: the rules a block's `conditional`
 * may use, and whether a block's rules are ones the email's trigger offers.
 *
 * A block shows only when its rules pass - [[rule, rule], [rule]], groups OR,
 * rules in a group AND - and each rule is {filter, rule, data}: the rule's
 * name, its operator and the value, as the automation rule builder writes
 * them. The rules on offer are the automation's: those of the trigger's rule
 * groups, read from the same registry the rule builder reads.
 *
 * The value's shape goes by the rule's type, as the rule builder saves it and
 * the rule's send-time code reads it: a Select holds the option's key ("no"),
 * a Search a list of {key, label}. A rule with no operators saves "rule":"".
 */
class BWFCRM_Email_Design_Conditions {

	/** Most options listed for one rule; the rest are found with its search. */
	const MAX_OPTIONS = 50;

	/** Operators that take no value. */
	const NO_VALUE = array( 'is_blank', 'is_not_blank' );

	/** @var array[] filter => rule_info(), for one request. */
	private static $info = array();

	/** @var bool[] filter => true once rule_info() has read its options and name. */
	private static $detailed = array();

	/** @var bool Whether the rule classes were loaded. */
	private static $loaded = false;

	/**
	 * Rule values in the shape their send-time code reads: a Select's value
	 * given as a list of one - ["no"] or [{"key":"no","label":"No"}], as the
	 * email editor itself has saved it - becomes its key, "no"; a Search
	 * value given as bare ids becomes [{key, label}]. The email editor's
	 * shape never matched when the email was sent, so this runs at send
	 * time too. A list of several Select values is left for check_rules().
	 *
	 * @param array $rules [[rule, …], …]
	 *
	 * @return array
	 */
	public static function normalize_values( $rules ) {
		if ( ! is_array( $rules ) ) {
			return $rules;
		}

		foreach ( $rules as $g => $group ) {
			if ( ! is_array( $group ) ) {
				continue;
			}

			foreach ( $group as $r => $rule ) {
				if ( ! is_array( $rule ) || empty( $rule['filter'] ) || ! is_string( $rule['filter'] ) || ! array_key_exists( 'data', $rule ) ) {
					continue;
				}

				// Type and operators only: this runs for every conditional block of every email sent.
				$info = self::rule_info( $rule['filter'], false );
				$data = $rule['data'];

				if ( 'select' === $info['type'] && is_array( $data ) && 1 === count( $data ) ) {
					$first = reset( $data );

					if ( is_array( $first ) && isset( $first['key'] ) && is_scalar( $first['key'] ) ) {
						$rules[ $g ][ $r ]['data'] = (string) $first['key'];
					} elseif ( is_scalar( $first ) ) {
						$rules[ $g ][ $r ]['data'] = (string) $first;
					}
				} elseif ( 'select' === $info['type'] && ( is_int( $data ) || is_float( $data ) ) ) {
					$rules[ $g ][ $r ]['data'] = (string) $data;
				} elseif ( 'search' === $info['type'] && is_array( $data ) ) {
					foreach ( $data as $i => $item ) {
						if ( is_scalar( $item ) && '' !== (string) $item ) {
							$rules[ $g ][ $r ]['data'][ $i ] = array( 'key' => (string) $item, 'label' => (string) $item );
						}
					}
				}

				// No operators: the rule builder saves none.
				if ( null !== $info['type'] && empty( $info['operators'] ) ) {
					$rules[ $g ][ $r ]['rule'] = '';
				}
			}
		}

		return $rules;
	}

	/**
	 * The summary the editor's condition panel shows, and saves as the
	 * conditional's `data` - the rule builder's own markup: each rule read
	 * out ("Has Made A Purchase : No"), rules joined by AND, groups by OR.
	 *
	 * @param array $rules [[rule, …], …], values as normalize_values() leaves them.
	 *
	 * @return string '' when there are no rules.
	 */
	public static function summary( $rules ) {
		if ( ! is_array( $rules ) ) {
			return '';
		}

		$html  = '';
		$first = true;

		foreach ( $rules as $group ) {
			$items = '';
			$index = 0;

			foreach ( is_array( $group ) ? $group : array() as $rule ) {
				$text = is_array( $rule ) ? self::readable( $rule ) : '';

				if ( '' === $text ) {
					continue;
				}

				$items .= '<div>' . ( $index > 0 ? '<div class="bwf-step-divider"><span class="bwf-divider">' . esc_html__( 'AND', 'wp-marketing-automations' ) . '</span></div>' : '' )
					. '<div class="bwf-step-content-content bwf-two-line-ellipse-text">' . $text . '</div></div>';
				++$index;
			}

			if ( '' === $items ) {
				continue;
			}

			$html .= ( $first ? '' : '<div class="bwf-step-divider divider-line bwf-or"><span class="bwf-divider">' . esc_html__( 'OR', 'wp-marketing-automations' ) . '</span></div>' ) . $items;
			$first = false;
		}

		return '' === $html ? '' : '<div class="bwf-step-brick">' . $html . '</div>';
	}

	/** One rule read out: the rule's readable text with its name, operator and value (in <strong>). */
	private static function readable( array $rule ) {
		if ( empty( $rule['filter'] ) || ! is_string( $rule['filter'] ) ) {
			return '';
		}

		$info     = self::rule_info( $rule['filter'] );
		$operator = isset( $rule['rule'] ) && is_scalar( $rule['rule'] ) ? (string) $rule['rule'] : '';
		$data     = isset( $rule['data'] ) ? $rule['data'] : '';
		$label    = isset( $info['operators'][ $operator ] ) ? (string) $info['operators'][ $operator ] : $operator;

		// The rule builder: a Select with no operator reads "Name : value".
		if ( 'select' === $info['type'] && '' === $operator ) {
			$label = ':';
		}

		if ( is_array( $data ) ) {
			// Search values, [{key, label}]: their labels, as the rule builder lists them.
			$labels = array();

			foreach ( $data as $item ) {
				if ( is_array( $item ) && isset( $item['label'] ) && is_scalar( $item['label'] ) && '' !== (string) $item['label'] ) {
					$labels[] = (string) $item['label'];
				} elseif ( is_array( $item ) && isset( $item['key'] ) && is_scalar( $item['key'] ) ) {
					$labels[] = isset( $info['options'][ (string) $item['key'] ] ) ? (string) $info['options'][ (string) $item['key'] ] : (string) $item['key'];
				} elseif ( is_scalar( $item ) ) {
					$labels[] = isset( $info['options'][ (string) $item ] ) ? (string) $info['options'][ (string) $item ] : (string) $item;
				}
			}

			$value = implode( ', ', $labels );
		} else {
			// A Select's key reads as its option's label.
			$value = is_scalar( $data ) && isset( $info['options'][ (string) $data ] ) ? (string) $info['options'][ (string) $data ] : ( is_scalar( $data ) ? (string) $data : '' );
		}

		$value = in_array( $operator, self::NO_VALUE, true ) ? '' : '<strong>' . esc_html( wp_strip_all_tags( (string) $value ) ) . '</strong>';

		return strtr(
			$info['readable'],
			array(
				'{{key /}}'   => esc_html( $info['name'] ),
				'{{rule /}}'  => esc_html( wp_strip_all_tags( $label ) ),
				'{{value /}}' => $value,
			)
		);
	}

	/**
	 * What the rule builder knows of a rule: its type (lower case; null when
	 * there is no such rule), name, operators, options and readable text.
	 * The options and name are read only when asked for: options can mean a
	 * query (every tag, every course).
	 *
	 * @param string $filter
	 * @param bool   $details Whether the options and name are needed.
	 *
	 * @return array { type, name, operators, options, readable }
	 */
	private static function rule_info( $filter, $details = true ) {
		if ( ! isset( self::$info[ $filter ] ) ) {
			$info = array( 'type' => null, 'name' => $filter, 'operators' => array(), 'options' => array(), 'readable' => '{{key /}} {{rule /}} {{value /}}' );
			$rule = self::rule( $filter );

			if ( null !== $rule ) {
				$operators         = $rule->get_possible_rule_operators();
				$info['type']      = strtolower( (string) $rule->get_rule_type() );
				$info['operators'] = is_array( $operators ) ? $operators : array();
			}

			self::$info[ $filter ] = $info;
		}

		if ( $details && null !== self::$info[ $filter ]['type'] && ! isset( self::$detailed[ $filter ] ) ) {
			self::$detailed[ $filter ] = true;

			// The readable text is for the MCP summary only; a send never reads it.
			$readable                          = self::rule( $filter )->get_readable_text_schema();
			self::$info[ $filter ]['readable'] = is_string( $readable ) && '' !== $readable ? $readable : self::$info[ $filter ]['readable'];

			if ( ! in_array( self::$info[ $filter ]['type'], array( 'search', 'product-qty' ), true ) ) {
				$options                          = self::rule( $filter )->get_options( '' );
				self::$info[ $filter ]['options'] = is_array( $options ) ? $options : array();
			}

			// The name the rule builder shows, from the same list it reads.
			foreach ( (array) apply_filters( 'bwfan_rule_get_rule_types', array() ) as $group ) {
				if ( is_array( $group ) && isset( $group[ $filter ] ) && is_string( $group[ $filter ] ) ) {
					self::$info[ $filter ]['name'] = wp_strip_all_tags( $group[ $filter ] );
					break;
				}
			}
		}

		return self::$info[ $filter ];
	}

	/** @return BWFAN_Rule_Base|null The rule's class, or null when there is no such rule. */
	private static function rule( $filter ) {
		$rules = function_exists( 'BWFAN_Core' ) && isset( BWFAN_Core()->rules ) ? BWFAN_Core()->rules : null;

		// The rule classes load on demand: every caller of get_rule() loads them first, or it finds none.
		if ( is_object( $rules ) && method_exists( $rules, 'load_rules_classes' ) && ! self::$loaded ) {
			$rules->load_rules_classes();
			self::$loaded = true;
		}

		$rule = is_object( $rules ) && method_exists( $rules, 'get_rule' ) ? $rules->get_rule( $filter ) : null;

		return class_exists( 'BWFAN_Rule_Base' ) && $rule instanceof BWFAN_Rule_Base ? $rule : null;
	}

	/**
	 * The rules a trigger offers.
	 *
	 * @param string $event         Trigger event slug.
	 * @param int    $automation_id Some options depend on the automation's own settings.
	 *
	 * @return array[] { filter, group, name, type, operators: {op: label}, multiple, options: {value: label}|null, value_label }
	 */
	public static function for_event( $event, $automation_id = 0 ) {
		if ( '' === (string) $event || ! function_exists( 'BWFAN_Core' ) || ! isset( BWFAN_Core()->rules ) || ! method_exists( BWFAN_Core()->rules, 'get_rules' ) ) {
			return array();
		}

		$groups = BWFAN_Core()->rules->get_rules( sanitize_key( $event ), absint( $automation_id ) );
		$out    = array();

		foreach ( is_array( $groups ) ? $groups : array() as $group => $entry ) {
			foreach ( isset( $entry['rules'] ) ? (array) $entry['rules'] : array() as $rule ) {
				if ( ! is_array( $rule ) || empty( $rule['slug'] ) ) {
					continue;
				}

				$options = isset( $rule['options'] ) && is_array( $rule['options'] ) ? $rule['options'] : array();

				$out[] = array(
					'filter'      => (string) $rule['slug'],
					'group'       => (string) $group,
					'name'        => isset( $rule['name'] ) ? wp_strip_all_tags( (string) $rule['name'] ) : (string) $rule['slug'],
					'type'        => isset( $rule['type'] ) ? (string) $rule['type'] : 'Text',
					'operators'   => isset( $rule['operators'] ) && is_array( $rule['operators'] ) ? array_map( 'wp_strip_all_tags', $rule['operators'] ) : array(),
					'multiple'    => ! empty( $rule['multiple'] ),
					'options'     => empty( $options ) ? null : array_slice( $options, 0, self::MAX_OPTIONS, true ),
					'value_label' => isset( $rule['value_label'] ) ? wp_strip_all_tags( (string) $rule['value_label'] ) : '',
				);
			}
		}

		return $out;
	}

	/**
	 * Issues with a block's rules.
	 *
	 * @param array  $rules [[rule, …], …]
	 * @param string $event The trigger; empty checks only that each rule exists.
	 *
	 * @return array[] { bucket: errors|warnings, path, code, message } - path relative to the rules.
	 */
	public static function check_rules( array $rules, $event = '' ) {
		$offered = array();

		foreach ( self::for_event( $event ) as $rule ) {
			$offered[ $rule['filter'] ] = $rule;
		}

		$issues = array();

		foreach ( array_values( $rules ) as $g => $group ) {
			foreach ( array_values( (array) $group ) as $r => $rule ) {
				$path = '/' . $g . '/' . $r;

				if ( ! is_array( $rule ) || empty( $rule['filter'] ) || ! isset( $rule['rule'] ) || ! array_key_exists( 'data', $rule ) ) {
					$issues[] = self::issue( 'errors', $path, 'wrong_shape', 'Each rule is {"filter":"<rule name>","rule":"<operator>","data":<value>} - list-block-conditions gives the names and operators.' );
					continue;
				}

				$filter      = (string) $rule['filter'];
				$value_issue = self::check_value( $rule, $path );

				if ( null !== $value_issue ) {
					$issues[] = $value_issue;
				}

				if ( '' !== (string) $event && ! empty( $offered ) ) {
					if ( ! isset( $offered[ $filter ] ) ) {
						$issues[] = self::issue( 'errors', $path . '/filter', 'unknown_condition', sprintf( 'The %s trigger has no rule "%s". list-block-conditions with this event lists the ones it has.', $event, $filter ) );
						continue;
					}

					if ( ! empty( $offered[ $filter ]['operators'] ) && ! isset( $offered[ $filter ]['operators'][ (string) $rule['rule'] ] ) ) {
						$issues[] = self::issue( 'errors', $path . '/rule', 'unknown_operator', sprintf( '"%s" is not an operator of %s. Use one of: %s.', (string) $rule['rule'], $filter, implode( ', ', array_keys( $offered[ $filter ]['operators'] ) ) ) );
					}

					continue;
				}

				if ( function_exists( 'BWFAN_Core' ) && isset( BWFAN_Core()->rules ) && method_exists( BWFAN_Core()->rules, 'get_rule' ) && ! ( BWFAN_Core()->rules->get_rule( $filter ) instanceof BWFAN_Rule_Base ) ) {
					$issues[] = self::issue( 'errors', $path . '/filter', 'unknown_condition', sprintf( 'There is no rule "%s". list-block-conditions lists the rules a trigger offers.', $filter ) );
				}
			}
		}

		return $issues;
	}

	/**
	 * A value that is not the shape its rule reads, or not one of its options.
	 *
	 * @return array|null The issue, or null.
	 */
	private static function check_value( array $rule, $path ) {
		$info     = self::rule_info( (string) $rule['filter'] );
		$data     = $rule['data'];
		$operator = is_scalar( $rule['rule'] ) ? (string) $rule['rule'] : '';

		if ( in_array( $operator, self::NO_VALUE, true ) ) {
			return null;
		}

		if ( 'select' === $info['type'] ) {
			if ( ! is_scalar( $data ) || '' === (string) $data ) {
				return self::issue( 'errors', $path . '/data', 'wrong_shape', sprintf( '%s takes one option\'s key as a string, e.g. "data":"%s". Options: %s.', $rule['filter'], (string) key( $info['options'] ), self::option_list( $info['options'] ) ) );
			}

			// A long list was cut when read; its other options are valid too.
			if ( ! empty( $info['options'] ) && count( $info['options'] ) < self::MAX_OPTIONS && ! isset( $info['options'][ (string) $data ] ) ) {
				return self::issue( 'errors', $path . '/data', 'unknown_option', sprintf( '"%s" is not an option of %s. Use one of: %s.', (string) $data, $rule['filter'], self::option_list( $info['options'] ) ) );
			}
		} elseif ( 'search' === $info['type'] ) {
			$valid = is_array( $data ) && ! empty( $data );

			foreach ( is_array( $data ) ? $data : array() as $item ) {
				$valid = $valid && is_array( $item ) && isset( $item['key'] ) && is_scalar( $item['key'] ) && '' !== (string) $item['key'];
			}

			if ( ! $valid ) {
				return self::issue( 'errors', $path . '/data', 'wrong_shape', sprintf( '%s takes a list of {"key":<id>,"label":"<name>"}.', $rule['filter'] ) );
			}
		}

		return null;
	}

	/** Options as key (label), for a message. */
	private static function option_list( array $options ) {
		$list = array();

		foreach ( array_slice( $options, 0, 10, true ) as $key => $label ) {
			$list[] = $key . ( is_scalar( $label ) && (string) $label !== (string) $key ? ' (' . wp_strip_all_tags( (string) $label ) . ')' : '' );
		}

		return implode( ', ', $list );
	}

	private static function issue( $bucket, $path, $code, $message ) {
		return array(
			'bucket'  => $bucket,
			'path'    => $path,
			'code'    => $code,
			'message' => $message,
		);
	}
}
