<?php

defined( 'ABSPATH' ) || exit;

/**
 * How well a design is made - the craft a designer checks before sending,
 * measured on the design so an AI client can improve it round by round:
 * one headline leading the email, one main call to action with a short
 * label, short paragraphs, readable body sizes, few typefaces and accent
 * colours, room around the content, images with alt text, and a layout that
 * holds up on a phone.
 *
 * A score out of 100 with a finding per shortfall, each saying how to fix it.
 * It judges craft, not correctness: validation says whether a design works.
 */
class BWFCRM_Email_Design_Quality {

	/** Score from which a design is ready. */
	const GOOD = 90;

	/** Findings a reader sees as broken: while one is left, the design is not ready, whatever its score. */
	const DEFECTS = array( 'unbalanced_button', 'text_at_edge', 'columns_on_phone', 'too_many_columns' );

	/** Body text below this size (px) is hard to read on a phone. */
	const MIN_BODY_SIZE = 14;

	/** Words a paragraph block can hold before it reads as a wall of text. */
	const PARAGRAPH_WORDS = 70;

	/** Words in the whole email before it reads as too long for one message. */
	const EMAIL_WORDS = 350;

	/**
	 * @param array[] $tree     The design.
	 * @param array   $settings The email's settings.
	 * @param array   $extra    { preheader: string|null, transactional: bool, brand_available: bool } What the email carries
	 *                          besides the design, and whether the site has a logo or business name to open with.
	 *
	 * @return array { score: int, grade: good|fair|needs_work, findings: array[] }
	 */
	public static function review( array $tree, array $settings = array(), array $extra = array() ) {
		$facts = self::facts( $tree );
		$found = array();

		$add = function ( $code, $cost, $message, $path = '' ) use ( &$found ) {
			$found[] = array(
				'code'    => $code,
				'cost'    => $cost,
				'path'    => $path,
				'message' => $message,
			);
		};

		// A headline leads the email.
		if ( 0 === $facts['headings'] ) {
			$add( 'no_headline', 10, 'There is no headline. Open the email with one clear heading (<span style="font-weight:600;" data-heading-level="1">…</span>) saying the one thing the reader should take away.' );
		} elseif ( null !== $facts['first_heading_index'] && $facts['first_heading_index'] > 3 ) {
			$add( 'headline_buried', 4, 'The first heading comes after several other blocks. Put the headline near the top, right after the logo or brand line.', $facts['first_heading_path'] );
		}

		if ( $facts['h1'] > 1 ) {
			$add( 'several_h1', 5, sprintf( 'There are %d level-1 headings. Keep one H1 for the headline and use level 2-3 for section headings.', $facts['h1'] ) );
		}

		// One main action.
		$actions = $facts['buttons'] + $facts['action_blocks'];

		if ( 0 === $actions ) {
			$add( 'no_action', 10, 'There is no button. Give the reader one clear next step with a button linking to where it happens.' );
		} elseif ( $facts['buttons'] > 3 ) {
			$add( 'too_many_actions', 8, sprintf( 'There are %d buttons. One main button (and at most one quieter one) converts better than many - turn the others into text links or remove them.', $facts['buttons'] ) );
		}

		foreach ( array_slice( $facts['unbalanced_buttons'], 0, 2 ) as $button ) {
			$add( 'unbalanced_button', 6, 'A button\'s label sits off-centre or crowded: its padding (the space inside the button) is uneven or too small. Use equal top/bottom and left/right, e.g. 14/28/14/28px, and set space around the button with containerPadding.', $button );
		}

		$long_labels = 0;

		foreach ( $facts['button_labels'] as $label ) {
			if ( $long_labels < 2 && ( str_word_count( $label['text'] ) > 4 || mb_strlen( $label['text'] ) > 28 ) ) {
				++$long_labels;
				$add( 'long_button_label', 3, sprintf( 'The button label "%s" is long. Use two to four words that say the action, e.g. "Shop the sale".', $label['text'] ), $label['path'] );
			}
		}

		// Short, readable text.
		$walls = 0;

		foreach ( $facts['paragraphs'] as $paragraph ) {
			if ( $walls < 2 && $paragraph['words'] > self::PARAGRAPH_WORDS ) {
				++$walls;
				$add( 'long_paragraph', 5, sprintf( 'A paragraph has %d words. Keep paragraphs to one to three sentences; split it or cut it down.', $paragraph['words'] ), $paragraph['path'] );
			}
		}

		if ( $facts['words'] > self::EMAIL_WORDS ) {
			$add( 'too_long', 5, sprintf( 'The email has about %d words. Aim for under %d: say one thing and link to the rest.', $facts['words'], self::EMAIL_WORDS ) );
		}

		if ( null !== $facts['smallest_body'] && $facts['smallest_body'] < self::MIN_BODY_SIZE ) {
			$add( 'small_text', 5, sprintf( 'Some body text is %dpx. Use at least %dpx so it reads on a phone (legal footers can be 12px).', (int) $facts['smallest_body'], self::MIN_BODY_SIZE ), $facts['smallest_body_path'] );
		}

		// A consistent look.
		if ( count( $facts['families'] ) > 2 ) {
			$add( 'too_many_fonts', 6, sprintf( 'The email uses %d typefaces (%s). Use one, or two at most: one for headings, one for body text.', count( $facts['families'] ), implode( ', ', array_keys( $facts['families'] ) ) ) );
		}

		if ( count( $facts['accents'] ) > 3 ) {
			$add( 'too_many_colours', 6, sprintf( 'The email uses %d accent colours (%s). Keep the site\'s colours and one accent for the button and highlights.', count( $facts['accents'] ), implode( ', ', array_values( $facts['accents'] ) ) ) );
		}

		// Room to breathe.
		$cramped = 0;

		foreach ( $facts['sections'] as $section ) {
			if ( $cramped < 3 && $section['blocks'] > 0 && $section['vertical'] < 24 && ! $section['full_bleed'] && ! $section['strip'] ) {
				++$cramped;
				$add( 'cramped_section', 3, 'A section has little space above and below its content. Give sections 24-40px top and bottom padding.', $section['path'] );
			}

			if ( $section['has_text'] && $section['side'] < 12 ) {
				$add( 'text_at_edge', 4, 'Text in a section sits closer than 12px to the edge, which touches the screen edge on a phone. Give the section or column 16-24px side padding.', $section['path'] );
			}

			if ( $section['columns'] > 3 ) {
				$add( 'too_many_columns', 5, sprintf( 'A section has %d columns, too narrow on most screens. Use at most three.', $section['columns'] ), $section['path'] );
			} elseif ( $section['columns'] >= 3 && false === $section['responsive'] ) {
				$add( 'columns_on_phone', 5, 'Three columns that do not stack on phones get too narrow to read. Leave responsive on.', $section['path'] );
			}
		}

		// Product cards: buttons that copy the main one, over thumbnails, outweigh what they sell.
		foreach ( array_slice( self::heavy_cards( $tree ), 0, 1 ) as $path ) {
			$add( 'heavy_card_buttons', 4, 'The product cards\' buttons copy the email\'s main button (unset btnPadding / btnTextFont) and sit under half-width images, so they outweigh the products. Give the block btnPadding {"desktop":{"top":"9","right":"18","bottom":"9","left":"18","unit":"px"}}, btnTextFont {"desktop":{"size":14}} and, in a grid, imageWidth {"desktop":{"value":100,"unit":"%"}} - or an outlined button (btnBorder) to keep them quiet.', $path );
		}

		// One column: a strong band that dissolves into what is behind it reads full-width beside boxed sections.
		$widths = self::widths( $tree, $settings );

		if ( ! empty( $widths['bleeding'] ) && $widths['boxed'] > 0 ) {
			$band = $widths['bleeding'][0];

			$add(
				'mixed_widths',
				5,
				sprintf( 'This section\'s background (%s) is the colour behind it - its row\'s bgColor, or the email background - so it looks full-width while the other sections sit in the email column. Give the email a light background (settings.background) and leave row bgColor unset, so every section reads as one column; or give each band its own row bgColor to make them all full-width.', $band['colour'] ),
				$band['path']
			);
		}

		if ( $facts['text_run'] > 4 ) {
			$add( 'text_run', 3, sprintf( '%d text blocks in a row. Break long runs with an image, a button, a divider or a new section.', $facts['text_run'] ) );
		}

		// Polish: what separates a designed email from a plain letter.
		if ( empty( $extra['transactional'] ) ) {
			if ( empty( $facts['images'] ) && 0 === $facts['visual_blocks'] && count( $facts['backgrounds'] ) < 2 ) {
				$add( 'no_visual', 10, 'Nothing to look at: no image, no product grid, no coloured band. Add a hero image (list-email-images), a product grid, or at least a tinted band behind the headline or the offer - without one the email reads as a plain letter.' );
			}

			// Only when the site has a brand to show: a logo, or a business name for {{business_name}}.
			if ( ! $facts['brand_header'] && ( ! array_key_exists( 'brand_available', $extra ) || ! empty( $extra['brand_available'] ) ) ) {
				$add( 'no_brand_header', 5, 'The email does not open with the brand. Start with the site logo (site_style.logo) or a short line with {{business_name}}, so the reader knows who it is from.' );
			}

			if ( $facts['sections_with_content'] >= 3 && count( $facts['backgrounds'] ) < 2 ) {
				$add( 'flat_layout', 4, 'Every section has the same background. Give the hero or the offer a tinted band (a light tint of the accent colour) so the email has rhythm and the key part stands out.' );
			}
		}

		if ( null !== $facts['headline_size'] && $facts['headline_size'] < 24 ) {
			$add( 'small_headline', 4, sprintf( 'The headline is %dpx - it does not lead. Make it 28-36px (heading level 1 or 2).', (int) $facts['headline_size'] ), $facts['first_heading_path'] );
		}

		foreach ( array_slice( $facts['centred_paragraphs'], 0, 1 ) as $centred ) {
			$add( 'centred_paragraph', 3, 'A long paragraph is centred, which is hard to read. Centre headlines and short lines; left-align paragraphs longer than two lines.', $centred );
		}

		// Images.
		$no_alt = 0;

		foreach ( $facts['images'] as $image ) {
			if ( $no_alt < 2 && '' === trim( $image['alt'] ) ) {
				++$no_alt;
				$add( 'image_without_alt', 3, 'An image has no alt text. Describe it in image.alt - many inboxes block images at first.', $image['path'] );
			}
		}

		// The email around the design.
		$width = BWFCRM_Email_Render_Js::parse_float( BWFCRM_Email_Render_Js::get( $settings, 'width.desktop.value', null ) );

		if ( ! is_nan( $width ) && ( $width < 560 || $width > 680 ) ) {
			$add( 'unusual_width', 3, sprintf( 'The email is %dpx wide. 600-640px suits every inbox.', (int) $width ) );
		}

		if ( array_key_exists( 'preheader', $extra ) && '' === trim( (string) $extra['preheader'] ) ) {
			$add( 'no_preheader', 4, 'There is no preheader. Add one short line that adds to the subject - inboxes show it right after it.' );
		}

		$score = max( 0, 100 - array_sum( array_column( $found, 'cost' ) ) );

		usort(
			$found,
			static function ( $a, $b ) {
				return $b['cost'] - $a['cost'];
			}
		);

		$defect = (bool) array_intersect( self::DEFECTS, array_column( $found, 'code' ) );

		return array(
			'score'    => $score,
			'grade'    => $score >= self::GOOD && ! $defect ? 'good' : ( $score >= 70 ? 'fair' : 'needs_work' ),
			'findings' => $found,
		);
	}

	/** What the review measures, gathered in one walk over the design. */
	private static function facts( array $tree ) {
		$facts = array(
			'headings'             => 0,
			'h1'                   => 0,
			'first_heading_index'  => null,
			'first_heading_path'   => '',
			'buttons'              => 0,
			'action_blocks'        => 0,
			'button_labels'        => array(),
			'paragraphs'           => array(),
			'words'                => 0,
			'smallest_body'        => null,
			'smallest_body_path'   => '',
			'families'             => array(),
			'accents'              => array(),
			'sections'             => array(),
			'images'               => array(),
			'text_run'             => 0,
			'visual_blocks'        => 0,
			'brand_header'         => false,
			'backgrounds'          => array(),
			'sections_with_content'=> 0,
			'headline_size'        => null,
			'centred_paragraphs'   => array(),
			'unbalanced_buttons'   => array(),
			'secondary_buttons'    => 0,
			'body_sizes'           => array(),
		);

		/** Default sizes of heading levels in the Global Style. */
		$level_sizes = array( 1 => 36, 2 => 32, 3 => 28, 4 => 24, 5 => 20, 6 => 16 );

		$content_index = 0;
		$run           = 0;

		foreach ( array_values( $tree ) as $r => $row ) {
			foreach ( self::children( $row ) as $s => $section ) {
				$section_attrs = self::attrs( $section );
				$section_path  = '/' . $r . '/innerBlocks/' . $s;
				$columns       = self::children( $section );
				$summary       = array(
					'path'       => $section_path,
					'columns'    => count( $columns ),
					'responsive' => BWFCRM_Email_Render_Js::get( $section_attrs, 'responsive', true ),
					'vertical'   => self::padding( $section_attrs, 'top' ) + self::padding( $section_attrs, 'bottom' ),
					'side'       => null,
					'has_text'   => false,
					'blocks'     => 0,
					'full_bleed' => true,
					'strip'      => false,
					'words'      => 0,
				);

				self::accent( $facts, BWFCRM_Email_Render_Js::get( $section_attrs, 'contentBackground.desktop.color' ) );

				$band = self::background_key( BWFCRM_Email_Render_Js::get( $section_attrs, 'contentBackground.desktop' ) );

				foreach ( $columns as $c => $column ) {
					$column_attrs = self::attrs( $column );
					$side         = self::padding( $section_attrs, 'left' ) + self::padding( $column_attrs, 'left' );
					$blocks       = self::children( $column );

					self::accent( $facts, BWFCRM_Email_Render_Js::get( $column_attrs, 'background.desktop.color' ) );

					$column_band = self::background_key( BWFCRM_Email_Render_Js::get( $column_attrs, 'background.desktop' ) );

					if ( 'none' !== $column_band && ! empty( $blocks ) ) {
						$band = $column_band;
					}

					foreach ( $blocks as $b => $block ) {
						$name  = isset( $block['name'] ) ? (string) $block['name'] : '';
						$attrs = self::attrs( $block );
						$path  = $section_path . '/innerBlocks/' . $c . '/innerBlocks/' . $b;

						++$summary['blocks'];

						if ( 'email-block/image' !== $name ) {
							$summary['full_bleed'] = false;
						}

						if ( 'email-block/text' === $name ) {
							$summary['words'] += str_word_count( self::text( (string) BWFCRM_Email_Render_Js::get( $attrs, 'content', '' ) ) );
						}

						// Spacers and dividers are space, not content: they do not push the headline down the email.
						if ( 'email-block/space-divider' !== $name ) {
							++$content_index;
						}

						// A null default: left out, a JavaScript-semantics get answers with its "undefined" marker.
						self::typeface( $facts, BWFCRM_Email_Render_Js::get( $attrs, 'font.desktop.family', null ) );

						if ( in_array( $name, array( 'email-block/text', 'email-block/list', 'email-block/footer' ), true ) ) {
							$html = (string) BWFCRM_Email_Render_Js::get( $attrs, 'content', '' );
							$text = self::text( $html );

							if ( 'email-block/footer' !== $name && '' !== $text ) {
								// How close this text comes to the email's edge: section, column and block padding.
								$edge                = $side + self::padding( $attrs, 'left' );
								$summary['has_text'] = true;
								$summary['side']     = null === $summary['side'] ? $edge : min( $summary['side'], $edge );
							}

							$facts['words'] += str_word_count( $text );

							preg_match_all( '/data-heading-level=["\']?([1-6])/', $html, $levels );

							// The brand opens the email: a logo, or its name in the first lines.
							if ( $content_index <= 2 && false !== stripos( $html, '{{business_name}}' ) ) {
								$facts['brand_header'] = true;
							}

							if ( ! empty( $levels[1] ) ) {
								$facts['headings'] += count( $levels[1] );
								$facts['h1']       += count( array_keys( $levels[1], '1', true ) );

								if ( null === $facts['first_heading_index'] ) {
									$facts['first_heading_index'] = $content_index;
									$facts['first_heading_path']  = $path;
									$facts['headline_size']       = preg_match( '/data-heading-level[^>]*font-size\s*:\s*(\d+)px|font-size\s*:\s*(\d+)px[^>]*data-heading-level/i', $html, $size ) ? (float) max( $size[1] ?? 0, $size[2] ?? 0 ) : (float) $level_sizes[ (int) $levels[1][0] ];
								}
							} elseif ( 'email-block/text' === $name ) {
								$facts['paragraphs'][] = array( 'path' => $path, 'words' => str_word_count( $text ) );

								if ( str_word_count( $text ) > 35 && in_array( BWFCRM_Email_Render_Js::get( $attrs, 'text.desktop.align' ), array( 'center', 'justify' ), true ) ) {
									$facts['centred_paragraphs'][] = $path;
								}
							}

							// A short capitalised label ("PACKED WITH PURPOSE") is small by convention; body text is not.
							$label = str_word_count( $text ) <= 5 && '' !== $text && $text === strtoupper( $text );

							if ( 'email-block/footer' !== $name && empty( $levels[1] ) && ! $label ) {
								self::body_size( $facts, $attrs, $html, $path, count( $facts['sections'] ) );
							}

							preg_match_all( '/(?<![-\w])color\s*:\s*(#[0-9a-fA-F]{3,6})/', $html, $colours );

							foreach ( $colours[1] as $colour ) {
								self::accent( $facts, $colour );
							}

							$run = 'email-block/text' === $name ? $run + 1 : 0;
						} else {
							$run = 0;
						}

						$facts['text_run'] = max( $facts['text_run'], $run );

						switch ( $name ) {
							case 'email-block/button':
								// An outlined button on its section's own colour is a secondary link, not a competing action.
								$fill = BWFCRM_Email_Render_Js::get( $attrs, 'bgColor.desktop', '' );
								$fill = is_string( $fill ) ? strtolower( $fill ) : '';
								$edge = BWFCRM_Email_Render_Js::get( $attrs, 'border.desktop.style', '' );
								$edge = is_string( $edge ) ? $edge : '';

								if ( '' !== $edge && '' !== $fill && ( 'color:' . $fill === $band || 'transparent' === $fill ) ) {
									++$facts['secondary_buttons'];
									break;
								}

								++$facts['buttons'];
								if ( self::unbalanced( $attrs ) ) {
									$facts['unbalanced_buttons'][] = $path;
								}
								$facts['button_labels'][] = array( 'path' => $path, 'text' => self::text( (string) BWFCRM_Email_Render_Js::get( $attrs, 'content', '' ) ) );
								self::accent( $facts, BWFCRM_Email_Render_Js::get( $attrs, 'bgColor.desktop' ) );
								break;

							case 'email-block/best-selling-product':
							case 'email-block/cart-items':
							case 'email-block/orders-summary':
								++$facts['visual_blocks'];
								if ( 'email-block/best-selling-product' === $name ) {
									++$facts['action_blocks'];
								}
								break;

							case 'email-block/cart-link':
								++$facts['action_blocks'];
								if ( self::unbalanced( $attrs ) ) {
									$facts['unbalanced_buttons'][] = $path;
								}
								break;

							case 'email-block/coupon':
								++$facts['action_blocks'];
								break;

							case 'email-block/image':
								$facts['images'][] = array( 'path' => $path, 'alt' => (string) BWFCRM_Email_Render_Js::get( $attrs, 'image.alt', '' ) );
								$facts['brand_header'] = $facts['brand_header'] || $content_index <= 2;
								break;

							case 'email-block/site-logo':
								$facts['brand_header'] = $facts['brand_header'] || $content_index <= 3;
								break;
						}
					}
				}

				// One short line on a band of its own: a label strip, meant to be tight.
				$summary['strip'] = 1 === $summary['blocks'] && $summary['words'] > 0 && $summary['words'] <= 6;

				$facts['sections'][] = $summary;

				if ( $summary['blocks'] > 0 ) {
					++$facts['sections_with_content'];
					$facts['backgrounds'][ $band ] = true;
				}
			}
		}

		// The last section is the footer, whatever blocks make it: its legal lines may be small.
		$last = count( $facts['sections'] ) > 1 ? count( $facts['sections'] ) - 1 : PHP_INT_MAX;

		foreach ( $facts['body_sizes'] as $entry ) {
			if ( $entry['section'] < $last && ( null === $facts['smallest_body'] || $entry['size'] < $facts['smallest_body'] ) ) {
				$facts['smallest_body']      = $entry['size'];
				$facts['smallest_body_path'] = $entry['path'];
			}
		}

		return $facts;
	}

	/** Whether a button's inside padding pushes its label off-centre or crowds it. */
	private static function unbalanced( array $attrs ) {
		$padding = BWFCRM_Email_Render_Js::get( $attrs, 'padding.desktop' );

		if ( ! is_array( $padding ) ) {
			return false;
		}

		$get = function ( $key ) use ( $padding ) {
			$value = BWFCRM_Email_Render_Js::parse_float( isset( $padding[ $key ] ) ? $padding[ $key ] : 0 );

			return is_nan( $value ) ? 0 : $value;
		};

		return abs( $get( 'top' ) - $get( 'bottom' ) ) > 4 || abs( $get( 'left' ) - $get( 'right' ) ) > 4 || $get( 'top' ) < 8 || $get( 'left' ) < 12;
	}

	/**
	 * Product grids whose card buttons are left to the site's main button
	 * style: several full-size buttons in a row of narrow cards.
	 *
	 * @return string[] Paths of those blocks.
	 */
	private static function heavy_cards( array $blocks, $path = '' ) {
		$found = array();

		foreach ( array_values( $blocks ) as $i => $block ) {
			$at = $path . '/' . $i;

			if ( ! is_array( $block ) ) {
				continue;
			}

			if ( isset( $block['name'] ) && 'email-block/best-selling-product' === $block['name'] ) {
				$attrs   = self::attrs( $block );
				$content = BWFCRM_Email_Render_Js::get( $attrs, 'productContentEnabled.desktop', null );
				$buttons = ! is_array( $content ) || in_array( 'button', $content, true );
				$grid    = ! isset( $attrs['layout'] ) || 'list' !== $attrs['layout'];
				$columns = isset( $attrs['columns'] ) ? (int) $attrs['columns'] : 2;

				if ( $buttons && $grid && $columns >= 2 && ! isset( $attrs['btnPadding'] ) && ! isset( $attrs['btnTextFont'] ) ) {
					$found[] = $at;
				}
			}

			$inner = self::children( $block );

			if ( ! empty( $inner ) ) {
				foreach ( self::heavy_cards( $inner, $at . '/innerBlocks' ) as $hit ) {
					$found[] = $hit;
				}
			}
		}

		return $found;
	}

	/**
	 * How the sections sit against what is behind them - the row's colour, or
	 * the email background: boxed (a visible column) or bleeding into it. A
	 * light section bleeding into a light page is the ordinary look; a strong
	 * one bleeding reads as a full-width band.
	 *
	 * @return array { boxed: int, bleeding: [{ path, colour }] }
	 */
	private static function widths( array $tree, array $settings ) {
		$out = array( 'boxed' => 0, 'bleeding' => array() );

		if ( ! class_exists( 'BWFCRM_Email_Design_Review' ) ) {
			return $out;
		}

		$site    = class_exists( 'BWFAN_Common' ) && method_exists( 'BWFAN_Common', 'get_block_editor_settings' ) ? BWFAN_Common::get_block_editor_settings() : array();
		$site    = isset( $site['setting'] ) && is_array( $site['setting'] ) ? $site['setting'] : array();
		$page    = BWFCRM_Email_Design_Review::color_of( BWFCRM_Email_Render_Js::get( $settings, 'background.desktop.color', BWFCRM_Email_Render_Js::get( $site, 'background.desktop.color', null ) ) );
		$content = BWFCRM_Email_Design_Review::color_of( BWFCRM_Email_Render_Js::get( $settings, 'contentBackground.desktop.color', BWFCRM_Email_Render_Js::get( $site, 'contentBackground.desktop.color', '#ffffff' ) ) );

		foreach ( array_values( $tree ) as $r => $row ) {
			$row_attrs = self::attrs( $row );
			$behind    = BWFCRM_Email_Design_Review::color_of( BWFCRM_Email_Render_Js::get( $row_attrs, 'bgColor.desktop', BWFCRM_Email_Render_Js::get( $row_attrs, 'background.desktop.color', null ) ) );
			$behind    = null !== $behind ? $behind : $page;

			if ( null === $behind ) {
				continue;
			}

			foreach ( self::children( $row ) as $s => $section ) {
				$own    = BWFCRM_Email_Design_Review::color_of( BWFCRM_Email_Render_Js::get( self::attrs( $section ), 'contentBackground.desktop.color', null ) );
				$colour = null !== $own ? $own : $content;

				if ( null === $colour || empty( self::children( $section ) ) ) {
					continue;
				}

				if ( strtolower( $colour ) !== strtolower( $behind ) ) {
					++$out['boxed'];
				} elseif ( BWFCRM_Email_Design_Review::contrast( $colour, '#ffffff' ) >= 2 ) {
					$out['bleeding'][] = array( 'path' => '/' . $r . '/innerBlocks/' . $s, 'colour' => $colour );
				}
			}
		}

		return $out;
	}

	/** A band's background as a key: its colour, gradient or image; "none" when it shows the email's own. */
	private static function background_key( $background ) {
		if ( ! is_array( $background ) ) {
			return 'none';
		}

		foreach ( array( 'image', 'gradient', 'color' ) as $key ) {
			if ( ! empty( $background[ $key ] ) ) {
				$value = $background[ $key ];

				return $key . ':' . strtolower( is_array( $value ) ? (string) ( $value['url'] ?? '' ) : (string) $value );
			}
		}

		return 'none';
	}

	/** The smallest body text size a block sets, inline or on the block. */
	private static function body_size( array &$facts, array $attrs, $html, $path, $section ) {
		$sizes = array();
		$block = BWFCRM_Email_Render_Js::parse_float( BWFCRM_Email_Render_Js::get( $attrs, 'font.desktop.size', null ) );

		if ( ! is_nan( $block ) ) {
			$sizes[] = $block;
		}

		if ( preg_match_all( '/font-size\s*:\s*(\d+(?:\.\d+)?)px/i', $html, $m ) ) {
			$sizes = array_merge( $sizes, array_map( 'floatval', $m[1] ) );
		}

		foreach ( $sizes as $size ) {
			// Legal and footnote lines below 12px are their own choice; 12-13px body text is the common slip.
			if ( $size >= 12 ) {
				$facts['body_sizes'][] = array( 'size' => $size, 'path' => $path, 'section' => $section );
			}
		}
	}

	private static function typeface( array &$facts, $family ) {
		if ( is_string( $family ) && '' !== trim( $family ) ) {
			$first = strtolower( trim( explode( ',', $family )[0], " '\"" ) );

			// Values that name no typeface: the block follows the email's font.
			if ( in_array( $first, array( '', 'undefined', 'null', 'inherit', 'initial', 'unset', 'default' ), true ) ) {
				return;
			}

			$facts['families'][ $first ] = true;
		}
	}

	/** A saturated colour: greys, near-white and near-black are neutrals, not accents. */
	private static function accent( array &$facts, $colour ) {
		$hex = class_exists( 'BWFCRM_Email_Design_Review' ) ? BWFCRM_Email_Design_Review::color_of( $colour ) : null;

		if ( null === $hex ) {
			return;
		}

		$rgb = array( hexdec( substr( $hex, 1, 2 ) ), hexdec( substr( $hex, 3, 2 ) ), hexdec( substr( $hex, 5, 2 ) ) );

		if ( max( $rgb ) - min( $rgb ) < 40 ) {
			return;
		}

		// Shades of one hue - a navy and a lighter blue of the same palette - are one accent.
		$max = max( $rgb );
		$min = min( $rgb );
		$d   = $max - $min;

		if ( $max === $rgb[0] ) {
			$hue = fmod( ( $rgb[1] - $rgb[2] ) / $d, 6 );
		} elseif ( $max === $rgb[1] ) {
			$hue = ( $rgb[2] - $rgb[0] ) / $d + 2;
		} else {
			$hue = ( $rgb[0] - $rgb[1] ) / $d + 4;
		}

		$hue = fmod( $hue * 60 + 360, 360 );
		$key = 'hue-' . (int) floor( ( $hue + 15 ) / 30 ) % 12;

		$facts['accents'][ $key ] = $hex;
	}

	private static function padding( array $attrs, $side ) {
		$value = BWFCRM_Email_Render_Js::parse_float( BWFCRM_Email_Render_Js::get( $attrs, 'padding.desktop.' . $side, 0 ) );

		return is_nan( $value ) ? 0 : $value;
	}

	private static function text( $html ) {
		return trim( preg_replace( '/\s+/', ' ', html_entity_decode( wp_strip_all_tags( preg_replace( '/<br\s*\/?>/i', ' ', (string) $html ) ), ENT_QUOTES, 'UTF-8' ) ) );
	}

	private static function children( $node ) {
		return is_array( $node ) && isset( $node['innerBlocks'] ) && is_array( $node['innerBlocks'] ) ? array_values( $node['innerBlocks'] ) : array();
	}

	/** A block's attributes with the editor's defaults filled in: padding left out is the block's default padding. */
	private static function attrs( $node ) {
		$attrs = is_array( $node ) && isset( $node['attrs'] ) ? (array) BWFCRM_Email_Render_Js::plain( $node['attrs'] ) : array();
		$name  = is_array( $node ) && isset( $node['name'] ) ? (string) $node['name'] : '';

		return '' !== $name && class_exists( 'BWFCRM_Email_Design_Tree' ) ? (array) BWFCRM_Email_Render_Js::plain( BWFCRM_Email_Design_Tree::with_defaults( $name, $attrs ) ) : $attrs;
	}
}
