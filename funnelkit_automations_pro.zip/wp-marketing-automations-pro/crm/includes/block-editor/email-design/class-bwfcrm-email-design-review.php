<?php

defined( 'ABSPATH' ) || exit;

/**
 * Reads a design the way a recipient will see it: for every block that shows
 * text, the colour the text will render in and the background under it, and
 * whether one can be read on the other.
 *
 * The colours are resolved the way the email renders them:
 *  - text: the colour set inline on the text itself - the editor keeps a text
 *    colour in the content, as <span style="color: …"> - else the block's
 *    colour, else the site's Global Style colour. An email's own settings
 *    cannot change the text colour when the site has a Global Style - only
 *    background, width, contentBackground and align;
 *  - background: a highlight set on the text itself, else the column's, else
 *    the section's, else the email's content background, else the site's.
 *    A see-through colour is blended over the one beneath it.
 *
 * Contrast follows WCAG: below 3:1 text is hard to read at any size (error);
 * below 4.5:1 normal-size text fails AA (warning; large text is fine at 3:1).
 * Colours this cannot read (a CSS variable, a gradient, a background image)
 * are skipped.
 */
class BWFCRM_Email_Design_Review {

	const MIN_CONTRAST = 3.0;
	const AA_CONTRAST = 4.5;

	/** Where the editor's template library keeps its sample images: a design still using one is unfinished. */
	const SAMPLE_IMAGES = '#^https?://(d241ue3yrqqwem\.cloudfront\.net|email-autonami\.s3\.amazonaws\.com)/email-preview/#i';

	/** Font size (px) from which text counts as large for contrast. */
	const LARGE_TEXT = 24;

	/**
	 * @param array[] $tree     The design, as sent (defaults need not be filled in).
	 * @param array   $settings The email's settings.
	 *
	 * @return array { errors: [], warnings: [], report: [] }
	 */
	public static function review( array $tree, array $settings = array() ) {
		$site     = self::site_setting();
		$settings = BWFCRM_Email_Render_Js::plain( $settings );
		$out      = array( 'errors' => array(), 'warnings' => array(), 'report' => array() );

		$email_bg = self::color_of( BWFCRM_Email_Render_Js::get( $settings, 'contentBackground.desktop.color', null ), '#ffffff' );
		$email_bg = null !== $email_bg ? $email_bg : self::color_of( BWFCRM_Email_Render_Js::get( $site, 'contentBackground.desktop.color', '#ffffff' ), '#ffffff' );
		$email_bg = null !== $email_bg ? $email_bg : '#ffffff';

		foreach ( array_values( $tree ) as $r => $row ) {
			foreach ( self::children( $row ) as $s => $section ) {
				$section_attrs = self::attrs( $section );
				$section_bg    = self::band( BWFCRM_Email_Render_Js::get( $section_attrs, 'contentBackground.desktop', null ), $email_bg );

				self::sample_images( $out, $section_attrs, '/' . $r . '/innerBlocks/' . $s );

				foreach ( self::children( $section ) as $c => $column ) {
					$column_bg = self::band( BWFCRM_Email_Render_Js::get( self::attrs( $column ), 'background.desktop', null ), $section_bg );

					self::sample_images( $out, self::attrs( $column ), '/' . $r . '/innerBlocks/' . $s . '/innerBlocks/' . $c );

					foreach ( self::children( $column ) as $b => $block ) {
						$path = '/' . $r . '/innerBlocks/' . $s . '/innerBlocks/' . $c . '/innerBlocks/' . $b;
						self::block( $out, isset( $block['name'] ) ? (string) $block['name'] : '', self::attrs( $block ), $column_bg, $site, $path );
					}
				}
			}
		}

		return $out;
	}

	/**
	 * The colour a section or column paints under its blocks: its own colour
	 * (blended over the one beneath when see-through), else the one beneath.
	 * Null when it shows an image or a gradient - the text is read on that,
	 * which this cannot judge.
	 *
	 * @param mixed       $background The band's background setting, { color, image, gradient, … }.
	 * @param string|null $under      The colour beneath; null when unknown.
	 *
	 * @return string|null
	 */
	private static function band( $background, $under ) {
		$background = is_array( $background ) ? $background : array();
		$image      = isset( $background['image'] ) ? $background['image'] : '';
		$image      = is_array( $image ) ? ( isset( $image['url'] ) ? $image['url'] : '' ) : $image;
		$gradient   = isset( $background['gradient'] ) ? $background['gradient'] : '';

		if ( ( is_string( $image ) && '' !== trim( $image ) ) || ( is_string( $gradient ) && '' !== trim( $gradient ) ) ) {
			return null;
		}

		$own = self::color_of( isset( $background['color'] ) ? $background['color'] : null, $under );

		return null !== $own ? $own : $under;
	}

	/**
	 * A starter design's sample images (its logo, its banners) left in place:
	 * the email would go out with another brand's pictures.
	 */
	private static function sample_images( array &$out, array $attrs, $path ) {
		$found = array();

		array_walk_recursive(
			$attrs,
			function ( $value ) use ( &$found ) {
				if ( is_string( $value ) && preg_match( self::SAMPLE_IMAGES, $value ) ) {
					$found[] = $value;
				}
			}
		);

		foreach ( array_unique( $found ) as $url ) {
			$out['warnings'][] = array(
				'path'    => $path . '/attrs',
				'code'    => 'sample_image',
				'message' => sprintf( 'This is still the starter design\'s sample image (%s) - its logo and words are not this site\'s. Replace it with the site\'s own image (site_style.logo for the logo), or remove the block.', basename( (string) wp_parse_url( $url, PHP_URL_PATH ) ) ),
			);
		}
	}

	private static function block( array &$out, $name, array $attrs, $background, array $site, $path ) {
		self::sample_images( $out, $attrs, $path );

		$site_text = self::color_of( BWFCRM_Email_Render_Js::get( $site, 'color.desktop', '#353030' ) );
		$size      = BWFCRM_Email_Render_Js::parse_float( BWFCRM_Email_Render_Js::get( $attrs, 'font.desktop.size', null ) );
		$size      = is_nan( $size ) ? null : $size;
		$excerpt   = self::excerpt( BWFCRM_Email_Render_Js::get( $attrs, 'content', '' ) );

		switch ( $name ) {
			case 'email-block/text':
			case 'email-block/list':
			case 'email-block/footer':
			case 'email-block/menu':
				$own     = self::color_of( BWFCRM_Email_Render_Js::get( $attrs, 'color.desktop', null ) );
				$content = (string) BWFCRM_Email_Render_Js::get( $attrs, 'content', '' );

				if ( 'email-block/text' === $name && null === $size && false !== strpos( $content, 'data-heading-level' ) ) {
					$size = self::LARGE_TEXT;
				}

				foreach ( self::text_colors( $content, null !== $own ? $own : $site_text, $background ) as $run ) {
					self::pair( $out, $path, $name, $excerpt, $run['color'], $run['on'], null !== $size ? $size : 16, $run['inline'] ? 'colour set on the text' : ( null !== $own ? 'block\'s colour' : 'site\'s Global Style text colour' ) );
				}
				break;

			case 'email-block/button':
				$bg = self::color_of( BWFCRM_Email_Render_Js::get( $attrs, 'bgColor.desktop', null ), $background );
				$bg = null !== $bg ? $bg : self::color_of( BWFCRM_Email_Render_Js::get( $site, 'buttonBackground.desktop.color', '#353030' ), $background );
				$fg = self::color_of( BWFCRM_Email_Render_Js::get( $attrs, 'color.desktop', null ), $bg );
				$fg = null !== $fg ? $fg : self::color_of( BWFCRM_Email_Render_Js::get( $site, 'buttonColor.desktop', '#ffffff' ), $bg );

				// Button labels are bold: large text from 18.66px (14pt).
				self::pair( $out, $path, $name, $excerpt, $fg, $bg, null !== $size ? max( $size, self::LARGE_TEXT ) : self::LARGE_TEXT, 'button text' );

				// An outlined button shows by its border, not its fill.
				$edge = self::color_of( BWFCRM_Email_Render_Js::get( $attrs, 'border.desktop.color_top', null ) );
				$line = '' !== (string) BWFCRM_Email_Render_Js::get( $attrs, 'border.desktop.style', '' ) && null !== $edge && null !== $background && self::contrast( $edge, $background ) >= self::MIN_CONTRAST;

				self::pair( $out, $path, $name, 'button shape', $line ? $edge : $bg, $background, self::LARGE_TEXT, 'button against the email', true );
				break;

			case 'email-block/coupon':
				foreach ( array( 'headingColor' => 'heading', 'msgColor' => 'message' ) as $key => $label ) {
					$color = self::color_of( BWFCRM_Email_Render_Js::get( $attrs, $key . '.desktop', null ), $background );

					if ( null !== $color ) {
						self::pair( $out, $path, $name, 'coupon ' . $label, $color, $background, 'heading' === $label ? self::LARGE_TEXT : 16, 'coupon ' . $label );
					}
				}

				$code_bg = self::color_of( BWFCRM_Email_Render_Js::get( $attrs, 'codeBgColor.desktop', null ), $background );
				$code_bg = null !== $code_bg ? $code_bg : $background;
				$code    = self::color_of( BWFCRM_Email_Render_Js::get( $attrs, 'codeColor.desktop', null ), $code_bg );

				if ( null !== $code ) {
					self::pair( $out, $path, $name, 'coupon code', $code, $code_bg, 16, 'coupon code' );
				}
				break;
		}
	}

	/**
	 * Records one foreground/background pair in the report, and an issue when
	 * it cannot be read.
	 */
	private static function pair( array &$out, $path, $name, $what, $fg, $bg, $size, $source, $shape_only = false ) {
		if ( null === $fg || null === $bg ) {
			return;
		}

		$ratio = self::contrast( $fg, $bg );

		$out['report'][] = array(
			'path'     => $path,
			'block'    => $name,
			'text'     => $what,
			'color'    => $fg,
			'on'       => $bg,
			'contrast' => round( $ratio, 2 ),
			'size'     => $size,
		);

		if ( $shape_only ) {
			// A button the colour of the email around it is a visible, if weak, problem - never an error.
			if ( $ratio < 1.5 ) {
				$out['warnings'][] = array( 'path' => $path . '/attrs/bgColor', 'code' => 'low_contrast', 'message' => sprintf( 'The button (%s) barely stands out from the email behind it (%s), contrast %.1f:1.', $fg, $bg, $ratio ) );
			}

			return;
		}

		$needed = $size >= self::LARGE_TEXT ? self::MIN_CONTRAST : self::AA_CONTRAST;

		if ( $ratio < self::MIN_CONTRAST ) {
			$out['errors'][] = array(
				'path'    => $path,
				'code'    => 'unreadable',
				'message' => sprintf( '%s "%s": %s text on %s is contrast %.1f:1 - it cannot be read. The colour is the %s. %s', $name, $what, $fg, $bg, $ratio, $source, self::fix_for( $name ) ),
			);
		} elseif ( $ratio < $needed ) {
			$out['warnings'][] = array(
				'path'    => $path,
				'code'    => 'low_contrast',
				'message' => sprintf( '%s "%s": %s on %s is contrast %.1f:1, below the %.1f:1 normal text needs to read comfortably.', $name, $what, $fg, $bg, $ratio, $needed ),
			);
		}
	}

	/** How to change the colour a block's text shows in. */
	private static function fix_for( $name ) {
		switch ( $name ) {
			case 'email-block/button':
				return 'Set the button\'s color and bgColor, e.g. {"desktop":"#ffffff"} and {"desktop":"#c2410c"}.';

			case 'email-block/coupon':
				return 'Set the coupon\'s headingColor, msgColor, codeColor and codeBgColor, e.g. {"desktop":"#ffffff"}.';

			case 'email-block/menu':
				return 'Set the menu\'s color, e.g. {"desktop":"#ffffff"}.';
		}

		return 'The text colour goes in the content itself: wrap the text in <span style="color: #ffffff;">…</span> on a dark background, or give the section or column a light background instead.';
	}

	/**
	 * The colours the visible text in rich-text content shows in, each on the
	 * background under it: a text run takes the inline colour of its nearest
	 * styled ancestor, else the given default, and the highlight
	 * (background-color) of its nearest highlighted ancestor, else the given
	 * background. Links are skipped - they take the link colour.
	 *
	 * @param string      $html
	 * @param string|null $default    The colour of text with none of its own.
	 * @param string|null $background The colour under the block; null when unknown.
	 *
	 * @return array[] { color, on, inline: whether the colour was set on the text }
	 */
	private static function text_colors( $html, $default, $background ) {
		$runs = array();

		if ( '' === trim( $html ) || false === strpos( $html, 'color' ) || ! class_exists( 'DOMDocument' ) ) {
			return null === $default ? array() : array( array( 'color' => $default, 'on' => $background, 'inline' => false ) );
		}

		$dom      = new DOMDocument();
		$previous = libxml_use_internal_errors( true );
		$dom->loadHTML( '<?xml encoding="utf-8"?><div>' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
		libxml_clear_errors();
		libxml_use_internal_errors( $previous );

		foreach ( ( new DOMXPath( $dom ) )->query( '//text()[normalize-space()]' ) as $node ) {
			$color = null;
			$on    = null;

			// The styles that apply, nearest first: the text's colour is blended over its highlight, so both are read before either is resolved.
			$colors = array();
			$fills  = array();

			for ( $el = $node->parentNode; $el instanceof DOMElement; $el = $el->parentNode ) {
				if ( 'a' === strtolower( $el->nodeName ) ) {
					continue 2;
				}

				$style = $el->getAttribute( 'style' );

				if ( empty( $colors ) && preg_match( '/(?:^|;)\s*color\s*:\s*([^;]+)/i', $style, $m ) ) {
					$colors[] = $m[1];
				}

				if ( preg_match( '/(?:^|;)\s*background(?:-color)?\s*:\s*([^;]+)/i', $style, $m ) ) {
					$fills[] = $m[1];
				}
			}

			// Highlights paint from the outermost in.
			$on = $background;

			foreach ( array_reverse( $fills ) as $fill ) {
				$paint = self::color_of( $fill, $on );
				$on    = null !== $paint ? $paint : ( null !== self::alpha( $fill ) ? $on : null );
			}

			if ( ! empty( $colors ) ) {
				$color = self::color_of( $colors[0], $on );
			}

			$inline = null !== $color;
			$color  = $inline ? $color : $default;

			if ( null !== $color ) {
				$runs[ $color . '|' . $on ] = array( 'color' => $color, 'on' => $on, 'inline' => $inline || ( isset( $runs[ $color . '|' . $on ] ) && $runs[ $color . '|' . $on ]['inline'] ) );
			}
		}

		return array_values( $runs );
	}

	/** WCAG contrast ratio between two #rrggbb colours. */
	public static function contrast( $a, $b ) {
		$la = self::luminance( $a );
		$lb = self::luminance( $b );

		return ( max( $la, $lb ) + 0.05 ) / ( min( $la, $lb ) + 0.05 );
	}

	private static function luminance( $hex ) {
		$rgb = array( hexdec( substr( $hex, 1, 2 ) ), hexdec( substr( $hex, 3, 2 ) ), hexdec( substr( $hex, 5, 2 ) ) );

		foreach ( $rgb as $i => $v ) {
			$v         = $v / 255;
			$rgb[ $i ] = $v <= 0.03928 ? $v / 12.92 : pow( ( $v + 0.055 ) / 1.055, 2.4 );
		}

		return 0.2126 * $rgb[0] + 0.7152 * $rgb[1] + 0.0722 * $rgb[2];
	}

	/**
	 * A colour as #rrggbb, or null when it is empty or not a plain colour
	 * (a CSS variable, a gradient). A see-through colour is blended over
	 * $under; a fully transparent one, or a see-through one with nothing known
	 * beneath, is null - the colour beneath shows.
	 *
	 * @param mixed       $value
	 * @param string|null $under #rrggbb beneath the colour.
	 *
	 * @return string|null
	 */
	public static function color_of( $value, $under = null ) {
		$parsed = self::parse_color( $value );

		if ( null === $parsed ) {
			return null;
		}

		list( $rgb, $alpha ) = $parsed;

		if ( $alpha >= 1 ) {
			return vsprintf( '#%02x%02x%02x', $rgb );
		}

		if ( $alpha <= 0 || ! is_string( $under ) || ! preg_match( '/^#[0-9a-f]{6}$/', $under ) ) {
			return null;
		}

		$base = array( hexdec( substr( $under, 1, 2 ) ), hexdec( substr( $under, 3, 2 ) ), hexdec( substr( $under, 5, 2 ) ) );

		foreach ( $rgb as $i => $v ) {
			$rgb[ $i ] = (int) round( $v * $alpha + $base[ $i ] * ( 1 - $alpha ) );
		}

		return vsprintf( '#%02x%02x%02x', $rgb );
	}

	/** A colour's opacity, 0-1; null when it is not a colour this reads. */
	private static function alpha( $value ) {
		$parsed = self::parse_color( $value );

		return null === $parsed ? null : $parsed[1];
	}

	/**
	 * @param mixed $value
	 *
	 * @return array|null [ [r, g, b], alpha ]
	 */
	private static function parse_color( $value ) {
		if ( ! is_string( $value ) ) {
			return null;
		}

		$value = strtolower( trim( preg_replace( '/\s*!important\s*$/i', '', $value ) ) );
		$named = array( 'white' => '#ffffff', 'black' => '#000000', 'red' => '#ff0000', 'green' => '#008000', 'blue' => '#0000ff', 'gray' => '#808080', 'grey' => '#808080', 'transparent' => '#00000000' );
		$value = isset( $named[ $value ] ) ? $named[ $value ] : $value;

		if ( preg_match( '/^#([0-9a-f])([0-9a-f])([0-9a-f])([0-9a-f])?$/', $value, $m ) ) {
			return array( array( hexdec( $m[1] . $m[1] ), hexdec( $m[2] . $m[2] ), hexdec( $m[3] . $m[3] ) ), isset( $m[4] ) && '' !== $m[4] ? hexdec( $m[4] . $m[4] ) / 255 : 1.0 );
		}

		if ( preg_match( '/^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})?$/', $value, $m ) ) {
			return array( array( hexdec( $m[1] ), hexdec( $m[2] ), hexdec( $m[3] ) ), isset( $m[4] ) && '' !== $m[4] ? hexdec( $m[4] ) / 255 : 1.0 );
		}

		if ( preg_match( '/^rgba?\(\s*(\d+)\s*[,\s]\s*(\d+)\s*[,\s]\s*(\d+)\s*(?:[,\/]\s*([\d.]+)(%)?\s*)?\)$/', $value, $m ) ) {
			$alpha = isset( $m[4] ) && '' !== $m[4] ? (float) $m[4] / ( ! empty( $m[5] ) ? 100 : 1 ) : 1.0;

			return array( array( min( 255, (int) $m[1] ), min( 255, (int) $m[2] ), min( 255, (int) $m[3] ) ), max( 0.0, min( 1.0, $alpha ) ) );
		}

		return null;
	}

	private static function excerpt( $html ) {
		$text = is_string( $html ) ? trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( $html ) ) ) : '';

		return mb_strlen( $text ) > 40 ? mb_substr( $text, 0, 39 ) . '…' : $text;
	}

	private static function children( $node ) {
		return is_array( $node ) && isset( $node['innerBlocks'] ) && is_array( $node['innerBlocks'] ) ? array_values( $node['innerBlocks'] ) : array();
	}

	private static function attrs( $node ) {
		return is_array( $node ) && isset( $node['attrs'] ) ? (array) BWFCRM_Email_Render_Js::plain( $node['attrs'] ) : array();
	}

	private static function site_setting() {
		$settings = class_exists( 'BWFAN_Common' ) && method_exists( 'BWFAN_Common', 'get_block_editor_settings' ) ? BWFAN_Common::get_block_editor_settings() : array();

		return is_array( $settings ) && isset( $settings['setting'] ) && is_array( $settings['setting'] ) ? BWFCRM_Email_Render_Js::plain( $settings['setting'] ) : array();
	}
}
