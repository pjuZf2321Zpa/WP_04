<?php

defined( 'ABSPATH' ) || exit;

/**
 * An email design as a tree of blocks - { name, attrs, innerBlocks } - and the
 * three things done to one: check it against the block manifest, complete it
 * (defaults, unique ids), and turn it into the block markup the email editor
 * saves and re-opens (and back).
 *
 * The markup is WordPress block-comment serialization, produced by core's
 * serialize_blocks(), so its escaping is the one the editor's own parser
 * expects. Content blocks carry everything in their attributes and serialize
 * self-closing; row, section and column hold only their children.
 */
class BWFCRM_Email_Design_Tree {

	/** Largest design accepted, as serialized markup (the editor's own audit limit for an email). */
	const MAX_BYTES = 102400;

	/** Deepest nesting read: row > section > column > block, with room to report a mistake. */
	const MAX_DEPTH = 6;

	/**
	 * Attributes the editor edits as rich text, which may hold only its inline
	 * formats. The footer is absent on purpose: it carries the site's global
	 * footer HTML, paragraphs included, and gets only the forbidden-markup check.
	 */
	const RICH_TEXT = array(
		'email-block/text'   => array( 'content' ),
		'email-block/button' => array( 'content' ),
		'email-block/list'   => array( 'content' ),
	);

	/** Never valid anywhere in a design, the HTML block included. */
	/** Placeholders a hand-picked product entry carries; the product block fills them, not the merge tags. */
	const PRODUCT_PLACEHOLDERS = array( 'product_title', 'product_description', 'product_price', 'product_sale_price', 'product_url' );

	/** Link schemes that run or carry a page; inline images (data:image/…) are fine. */
	const UNSAFE_SCHEME = '(?:javascript:|vbscript:|data:(?!image\/(?:png|gif|jpe?g|webp);))';

	// svg and math: their animation elements (<animate values>, <set to>) turn a link into javascript: past the link checks; mail clients do not show inline SVG.
	const FORBIDDEN_TAGS = array( 'script', 'iframe', 'object', 'embed', 'form', 'input', 'button', 'textarea', 'select', 'meta', 'link', 'base', 'style', 'svg', 'math' );

	/**
	 * Block markup → tree. Whitespace between blocks is dropped; anything else
	 * outside a block is kept as a node with a null name, for validate() to
	 * report.
	 *
	 * @param string $markup
	 *
	 * @return array[]
	 */
	public static function from_markup( $markup ) {
		$markup = is_string( $markup ) ? $markup : '';

		if ( '' === trim( $markup ) || ! function_exists( 'parse_blocks' ) ) {
			return array();
		}

		return self::from_parsed( parse_blocks( $markup ) );
	}

	private static function from_parsed( array $parsed, $depth = 0 ) {
		$out = array();

		foreach ( $parsed as $block ) {
			$name  = isset( $block['blockName'] ) ? $block['blockName'] : null;
			$inner = isset( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ? $block['innerBlocks'] : array();
			$html  = isset( $block['innerHTML'] ) && is_string( $block['innerHTML'] ) ? $block['innerHTML'] : '';

			if ( null === $name ) {
				if ( '' !== trim( $html ) ) {
					$out[] = array( 'name' => null, 'html' => $html );
				}

				continue;
			}

			$node = array(
				'name'  => $name,
				'attrs' => isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array(),
			);

			if ( ! empty( $inner ) && $depth < self::MAX_DEPTH ) {
				$node['innerBlocks'] = self::from_parsed( $inner, $depth + 1 );
			}

			// Markup between a block's own comments: invalid for every email block.
			$own_html = self::own_html( $block );

			if ( '' !== $own_html ) {
				$node['html'] = $own_html;
			}

			$out[] = $node;
		}

		return $out;
	}

	/** The string chunks of a parsed block, without its children. */
	private static function own_html( array $block ) {
		$chunks = isset( $block['innerContent'] ) && is_array( $block['innerContent'] ) ? $block['innerContent'] : array();
		$html   = '';

		foreach ( $chunks as $chunk ) {
			if ( is_string( $chunk ) ) {
				$html .= $chunk;
			}
		}

		return trim( $html );
	}

	/**
	 * Tree → block markup.
	 *
	 * @param array[] $tree A completed tree (see complete()).
	 *
	 * @return string
	 */
	public static function to_markup( array $tree ) {
		// Top-level rows a blank line apart, as the editor writes them.
		return implode( "\n\n", array_map( 'serialize_block', self::to_parsed( $tree ) ) );
	}

	private static function to_parsed( array $tree ) {
		$out = array();

		foreach ( $tree as $node ) {
			$children = isset( $node['innerBlocks'] ) && is_array( $node['innerBlocks'] ) ? $node['innerBlocks'] : array();
			$content  = array();

			// Children on their own lines, as the editor writes them.
			foreach ( $children as $i => $child ) {
				$content[] = 0 === $i ? "\n" : "\n\n";
				$content[] = null;
			}

			if ( ! empty( $children ) ) {
				$content[] = "\n";
			}

			$out[] = array(
				'blockName'    => isset( $node['name'] ) ? $node['name'] : null,
				'attrs'        => isset( $node['attrs'] ) ? $node['attrs'] : array(),
				'innerBlocks'  => self::to_parsed( $children ),
				'innerHTML'    => '',
				'innerContent' => $content,
			);
		}

		return $out;
	}

	/**
	 * Checks a design the way the editor would read it, so a design that
	 * passes opens without a block-validation warning.
	 *
	 * @param array[] $tree
	 * @param array   $settings Per-email settings (block.settings).
	 * @param array   $options {
	 *     @type string[] $event_groups WooCommerce block groups of the trigger event, if any.
	 *     @type bool     $transactional Transactional email: no unsubscribe link required.
	 *     @type string[] $merge_tags    Known merge tag slugs; empty skips the check.
	 *     @type string   $event         The trigger event slug, if the email belongs to an Automation.
	 *     @type int      $automation_id The Automation the email belongs to, if known.
	 * }
	 *
	 * @return array|WP_Error { valid: bool, errors: [], warnings: [] }
	 */
	public static function validate( array $tree, array $settings = array(), array $options = array() ) {
		$blocks = BWFCRM_Email_Design_Manifest::blocks( isset( $options['event_groups'] ) ? (array) $options['event_groups'] : array() );

		if ( is_wp_error( $blocks ) ) {
			return $blocks;
		}

		$report = array(
			'errors'   => array(),
			'warnings' => array(),
			'ids'      => array(),
			'strings'  => array(),
			'names'    => array(),
		);

		if ( empty( $tree ) ) {
			self::add( $report, 'errors', '', 'empty_design', 'The design has no blocks. Start with an email-block/row.' );
		}

		foreach ( array_values( $tree ) as $i => $node ) {
			self::check_node( $report, $blocks, $node, '/' . $i, null, 0 );
		}

		self::check_settings( $report, $settings );
		self::check_text( $report, $options );

		// Readability - loaded with the design tools; plain structural checks run without it.
		$reading = array();

		if ( class_exists( 'BWFCRM_Email_Design_Review' ) ) {
			$review  = BWFCRM_Email_Design_Review::review( $tree, $settings );
			$reading = $review['report'];

			foreach ( array( 'errors', 'warnings' ) as $bucket ) {
				foreach ( $review[ $bucket ] as $issue ) {
					self::add( $report, $bucket, $issue['path'], $issue['code'], $issue['message'] );
				}
			}
		}

		// What each block will do when sent: feeds, store data, triggers, placeholders.
		if ( class_exists( 'BWFCRM_Email_Design_Blocks' ) ) {
			$blocks_report = BWFCRM_Email_Design_Blocks::check( $tree, $settings, $options );

			foreach ( array( 'errors', 'warnings' ) as $bucket ) {
				foreach ( $blocks_report[ $bucket ] as $issue ) {
					self::add( $report, $bucket, $issue['path'], $issue['code'], $issue['message'] );
				}
			}
		}

		if ( empty( $report['errors'] ) ) {
			$bytes = strlen( self::to_markup( self::complete( $tree ) ) );

			if ( $bytes > self::MAX_BYTES ) {
				self::add( $report, 'errors', '', 'too_large', sprintf( 'The design is %d KB; the limit is %d KB.', (int) ceil( $bytes / 1024 ), (int) ( self::MAX_BYTES / 1024 ) ) );
			}
		}

		return array(
			'valid'    => empty( $report['errors'] ),
			'errors'   => $report['errors'],
			'warnings' => $report['warnings'],
			'report'   => $reading,
		);
	}

	private static function check_node( array &$report, array $blocks, $node, $path, $parent, $depth ) {
		if ( ! is_array( $node ) ) {
			self::add( $report, 'errors', $path, 'not_a_block', 'Each block must be an object with a name.' );

			return;
		}

		$name = isset( $node['name'] ) && is_string( $node['name'] ) ? $node['name'] : null;

		if ( null === $name ) {
			self::add( $report, 'errors', $path, 'stray_content', 'Content outside any block. Every piece of the email has to be a block.' );

			return;
		}

		if ( ! isset( $blocks[ $name ] ) ) {
			self::add( $report, 'errors', $path . '/name', 'unknown_block', sprintf( '"%s" is not an email block. Call get-email-design-schema for the blocks available.', $name ) );

			return;
		}

		$block = $blocks[ $name ];

		if ( empty( $block['available'] ) ) {
			self::add( $report, 'errors', $path . '/name', 'unavailable_block', sprintf( '%s cannot be used here: %s', $name, $block['unavailable_reason'] ) );
		}

		$report['names'][] = $name;

		$allowed_parents = isset( $block['parent'] ) && is_array( $block['parent'] ) ? $block['parent'] : array();

		if ( null === $parent && ! empty( $allowed_parents ) ) {
			self::add( $report, 'errors', $path, 'wrong_parent', sprintf( '%s cannot be at the top of the email; the top level holds only email-block/row.', $name ) );
		} elseif ( null !== $parent && ! in_array( $parent, $allowed_parents, true ) ) {
			self::add( $report, 'errors', $path, 'wrong_parent', sprintf( '%s cannot sit inside %s; it belongs in %s.', $name, $parent, empty( $allowed_parents ) ? 'the top level' : implode( ' or ', $allowed_parents ) ) );
		}

		if ( isset( $node['html'] ) && '' !== trim( (string) $node['html'] ) ) {
			self::add( $report, 'errors', $path, 'inner_html', sprintf( '%s has markup between its comments. Email blocks keep all content in their attributes.', $name ) );
		}

		$attrs    = isset( $node['attrs'] ) ? $node['attrs'] : array();
		$children = isset( $node['innerBlocks'] ) ? $node['innerBlocks'] : array();

		if ( ! is_array( $attrs ) ) {
			self::add( $report, 'errors', $path . '/attrs', 'bad_attrs', 'attrs must be an object.' );
			$attrs = array();
		}

		self::check_attrs( $report, $block, $name, $attrs, $path );

		$is_layout = isset( $block['kind'] ) && 'layout' === $block['kind'];

		if ( ! is_array( $children ) ) {
			self::add( $report, 'errors', $path . '/innerBlocks', 'bad_children', 'innerBlocks must be a list.' );
			$children = array();
		}

		if ( ! $is_layout && ! empty( $children ) ) {
			self::add( $report, 'errors', $path . '/innerBlocks', 'leaf_children', sprintf( '%s cannot hold other blocks.', $name ) );
		}

		if ( $is_layout && empty( $children ) && BWFCRM_Email_Design_Manifest::COLUMN !== $name ) {
			// The editor removes an empty row or section as soon as the design changes.
			self::add( $report, 'errors', $path . '/innerBlocks', 'empty_layout', sprintf( '%s needs at least one %s.', $name, BWFCRM_Email_Design_Manifest::ROW === $name ? 'email-block/section' : 'email-block/column' ) );
		}

		if ( BWFCRM_Email_Design_Manifest::COLUMN === $name && empty( $children ) ) {
			self::add( $report, 'warnings', $path, 'empty_column', 'This column is empty.' );
		}

		if ( BWFCRM_Email_Design_Manifest::SECTION === $name ) {
			self::check_section( $report, $attrs, $children, $path );
		}

		if ( $depth + 1 >= self::MAX_DEPTH ) {
			if ( ! empty( $children ) ) {
				self::add( $report, 'errors', $path . '/innerBlocks', 'too_deep', 'Blocks are nested deeper than row > section > column > block allows.' );
			}

			return;
		}

		foreach ( array_values( $children ) as $i => $child ) {
			self::check_node( $report, $blocks, $child, $path . '/innerBlocks/' . $i, $name, $depth + 1 );
		}
	}

	private static function check_attrs( array &$report, array $block, $name, array $attrs, $path ) {
		$known = isset( $block['attributes'] ) && is_array( $block['attributes'] ) ? $block['attributes'] : array();

		foreach ( $attrs as $key => $value ) {
			$at = $path . '/attrs/' . $key;

			if ( ! isset( $known[ $key ] ) ) {
				self::add( $report, 'errors', $at, 'unknown_attribute', sprintf( '%s has no attribute "%s".', $name, $key ) );

				continue;
			}

			$type = isset( $known[ $key ]['type'] ) ? $known[ $key ]['type'] : null;

			if ( null !== $type && ! self::is_type( $value, $type ) ) {
				self::add( $report, 'errors', $at, 'wrong_type', sprintf( '%s.%s must be %s.', $name, $key, self::type_label( $type ) ) );

				continue;
			}

			if ( isset( $known[ $key ]['enum'] ) && is_array( $known[ $key ]['enum'] ) && ! in_array( $value, $known[ $key ]['enum'], true ) ) {
				self::add( $report, 'errors', $at, 'not_allowed', sprintf( '%s.%s must be one of: %s.', $name, $key, implode( ', ', $known[ $key ]['enum'] ) ) );
			}

			if ( isset( $known[ $key ]['shape'] ) && is_array( $known[ $key ]['shape'] ) ) {
				self::check_shape( $report, $value, $known[ $key ]['shape'], $at, $name . '.' . $key, isset( $known[ $key ]['example'] ) ? $known[ $key ]['example'] : null, 0 );
			}
		}

		if ( isset( $attrs['uniqueID'] ) && is_string( $attrs['uniqueID'] ) ) {
			$id = $attrs['uniqueID'];

			if ( ! preg_match( '/^[0-9a-f]{7}$/', $id ) ) {
				self::add( $report, 'errors', $path . '/attrs/uniqueID', 'bad_unique_id', 'uniqueID must be 7 lowercase hex characters; leave it out and one is assigned.' );
			} elseif ( isset( $report['ids'][ $id ] ) ) {
				self::add( $report, 'errors', $path . '/attrs/uniqueID', 'duplicate_unique_id', sprintf( 'uniqueID %s is also used at %s; each block needs its own.', $id, $report['ids'][ $id ] ) );
			} else {
				$report['ids'][ $id ] = $path;
			}
		}

		self::collect_strings( $report, $attrs, $path . '/attrs', $name, 0 );

		if ( isset( self::RICH_TEXT[ $name ] ) ) {
			foreach ( self::RICH_TEXT[ $name ] as $key ) {
				if ( isset( $attrs[ $key ] ) && is_string( $attrs[ $key ] ) ) {
					self::check_rich_text( $report, $name, $attrs[ $key ], $path . '/attrs/' . $key );
				}
			}
		}

		// Menu item text is inline markup the renderer writes raw: the same inline allowlist as rich text.
		if ( 'email-block/menu' === $name && isset( $attrs['menuItems'] ) && is_array( $attrs['menuItems'] ) ) {
			foreach ( $attrs['menuItems'] as $i => $item ) {
				if ( is_array( $item ) && isset( $item['text'] ) && is_string( $item['text'] ) ) {
					self::check_rich_text( $report, $name, $item['text'], $path . '/attrs/menuItems/' . $i . '/text' );
				}
			}
		}
	}

	/**
	 * A value against the shape editor-made designs give the attribute (learned
	 * into the manifest). The editor reads these values by path - a colour as
	 * `bgColor.desktop`, a string - so an object where it expects a string is
	 * silently ignored when it renders: an error. A plain value of another type
	 * is a warning; numbers and numeric strings count as the same.
	 *
	 * @param array  $report
	 * @param mixed  $value
	 * @param array  $shape   { t: string[], k?: key => shape, i?: shape }
	 * @param string $path
	 * @param string $label   block.attribute, for the message
	 * @param mixed  $example A real value, shown in the message.
	 * @param int    $depth
	 */
	private static function check_shape( array &$report, $value, array $shape, $path, $label, $example, $depth ) {
		if ( $depth > 6 ) {
			return;
		}

		$allowed = isset( $shape['t'] ) ? (array) $shape['t'] : array();
		$type    = self::json_type( $value );
		$fits    = in_array( $type, $allowed, true )
			|| ( 'number' === $type && in_array( 'string', $allowed, true ) )
			|| ( 'string' === $type && in_array( 'number', $allowed, true ) && is_numeric( $value ) )
			|| ( 'empty' === $type && ( in_array( 'object', $allowed, true ) || in_array( 'array', $allowed, true ) ) );

		if ( ! $fits ) {
			$structural = in_array( $type, array( 'object', 'array' ), true ) !== ( array() !== array_intersect( $allowed, array( 'object', 'array' ) ) );
			$hint       = null !== $example ? ' Editor-made designs write it like: ' . wp_json_encode( $example ) . '.' : '';

			self::add(
				$report,
				$structural ? 'errors' : 'warnings',
				$path,
				'wrong_shape',
				sprintf( '%s should be %s here, not %s - the editor would ignore it.%s', $label, implode( ' or ', $allowed ), 'empty' === $type ? 'empty' : $type, $hint )
			);

			return;
		}

		if ( 'object' === $type && ! empty( $shape['k'] ) && is_array( $shape['k'] ) ) {
			foreach ( (array) $value as $key => $item ) {
				if ( isset( $shape['k'][ $key ] ) ) {
					self::check_shape( $report, $item, $shape['k'][ $key ], $path . '/' . $key, $label, $example, $depth + 1 );
				}
			}
		}

		if ( 'array' === $type && ! empty( $shape['i'] ) && is_array( $shape['i'] ) ) {
			foreach ( array_values( (array) $value ) as $i => $item ) {
				self::check_shape( $report, $item, $shape['i'], $path . '/' . $i, $label, $example, $depth + 1 );
			}
		}
	}

	/** The JSON type a decoded value had; an empty array could have been [] or {}. */
	private static function json_type( $value ) {
		if ( null === $value ) {
			return 'null';
		}

		if ( is_bool( $value ) ) {
			return 'boolean';
		}

		if ( is_int( $value ) || is_float( $value ) ) {
			return 'number';
		}

		if ( is_string( $value ) ) {
			return 'string';
		}

		if ( is_object( $value ) ) {
			$value = get_object_vars( $value );

			return array() === $value ? 'empty' : 'object';
		}

		if ( is_array( $value ) ) {
			if ( array() === $value ) {
				return 'empty';
			}

			return array_keys( $value ) === range( 0, count( $value ) - 1 ) ? 'array' : 'object';
		}

		return 'string';
	}

	/**
	 * Every string in the attributes, with where it came from, for the checks that read text.
	 * Keys are checked here too: some are written into the stylesheet as they are.
	 */
	private static function collect_strings( array &$report, $value, $path, $name, $depth ) {
		if ( is_string( $value ) ) {
			$report['strings'][] = array( 'path' => $path, 'value' => $value, 'block' => $name );

			return;
		}

		// A settings sub-value can arrive as a decoded object (block.settings is stored and re-read
		// that way) rather than an array; read the same regardless, or its strings are never checked.
		if ( is_object( $value ) ) {
			$value = get_object_vars( $value );
		}

		if ( ! is_array( $value ) || array() === $value ) {
			return;
		}

		// Deeper than any attribute the editor writes (display conditions reach 7): unread, so refused.
		if ( $depth > 10 ) {
			self::add( $report, 'errors', $path, 'too_deep', 'This value is nested deeper than any email block attribute.' );

			return;
		}

		foreach ( $value as $key => $item ) {
			if ( ! preg_match( '/^[A-Za-z0-9_-]+$/', (string) $key ) ) {
				self::add( $report, 'errors', $path, 'bad_key', sprintf( 'The key %s is not allowed: keys may use only letters, digits, "_" and "-".', wp_json_encode( (string) $key ) ) );

				continue;
			}

			self::collect_strings( $report, $item, $path . '/' . $key, $name, $depth + 1 );
		}
	}

	private static function check_rich_text( array &$report, $name, $html, $path ) {
		$allowed = self::inline_tags();

		if ( 'email-block/list' === $name ) {
			$allowed[] = 'li';
		}

		if ( ! preg_match_all( '/<\s*([a-zA-Z][a-zA-Z0-9-]*)\b/', $html, $matches ) ) {
			return;
		}

		$bad = array_diff( array_unique( array_map( 'strtolower', $matches[1] ) ), $allowed );

		if ( ! empty( $bad ) ) {
			self::add( $report, 'errors', $path, 'disallowed_tag', sprintf( '%s content may only use %s; found %s. Headings are <span data-heading-level="1-6">…</span>.', $name, implode( ', ', $allowed ), implode( ', ', $bad ) ) );
		}
	}

	private static function inline_tags() {
		$manifest = BWFCRM_Email_Design_Manifest::get();

		return ! is_wp_error( $manifest ) && ! empty( $manifest['inline_tags'] ) ? (array) $manifest['inline_tags'] : array( 'strong', 'em', 'u', 's', 'sub', 'sup', 'a', 'span', 'br' );
	}

	/**
	 * A string with every entity layer decoded, numeric ones without their
	 * semicolon too (browsers accept &#106avascript:), up to 5 layers.
	 *
	 * Decoded with the send path's own table (ENT_HTML401) first, then
	 * ENT_HTML5: ENT_HTML401 decodes &#13;/&#x0D; (CR) into a real carriage
	 * return, which ENT_HTML5 alone does not, and the send path
	 * html_entity_decode()s with the default (HTML401) table.
	 */
	private static function fully_decoded( $value ) {
		for ( $i = 0; $i < 5; $i++ ) {
			$fixed = preg_replace( '/&#([xX][0-9a-fA-F]++|[0-9]++)(?!;)/', '&#$1;', $value );
			$next  = html_entity_decode( html_entity_decode( $fixed, ENT_QUOTES | ENT_HTML401, 'UTF-8' ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
			if ( $next === $value ) {
				break;
			}
			$value = $next;
		}

		return $value;
	}

	/**
	 * Whether a string holds markup an email must never carry, read as the send path will
	 * read it: raw and fully decoded. The validator's own forbidden-markup check (check_text),
	 * public for other email bodies (FKMCP_Step_Builder::email()). Plain escaped text
	 * (I &lt;3 you) passes.
	 *
	 * @param string $value
	 *
	 * @return bool
	 */
	public static function forbidden_markup( $value ) {
		list( $tag, $unsafe ) = self::markup_findings( (string) $value );

		return '' !== $tag || $unsafe;
	}

	/**
	 * The forbidden markup in one string: the first forbidden tag's name ('' for none), and
	 * whether it holds a script handler or a javascript:, vbscript: or data: link.
	 *
	 * @return array{0: string, 1: bool}
	 */
	private static function markup_findings( $value ) {
		// Every string is read fully decoded: the send path html_entity_decode()s the whole email body
		// (Lite class-bwfan-wp-sendemail.php:609,646), so escaped markup anywhere becomes live markup.
		$decoded = self::fully_decoded( $value );

		// $decoded is already fully decoded above; a scheme check also drops control characters
		// and whitespace inside it (java\tscript:, java&#13;script:), so links are read that way too.
		$compact = preg_replace( '/[\x00-\x20]+/', '', $decoded );

		// Closing tags too: a value written into the stylesheet could end it with </style>.
		$tag = preg_match( '/<\s*\/?\s*(' . implode( '|', self::FORBIDDEN_TAGS ) . ')\b/i', $value . "\n" . $decoded, $m ) ? strtolower( $m[1] ) : '';

		$unsafe = preg_match( '/(?:^|[\s\/"\'])on[a-z]+\s*=/i', $value . "\n" . $decoded )
			|| preg_match( '/(?:href|src|action|background|poster)=["\']?' . self::UNSAFE_SCHEME . '/i', $compact )
			|| preg_match( '/^' . self::UNSAFE_SCHEME . '/i', $compact );

		return array( $tag, (bool) $unsafe );
	}

	private static function check_section( array &$report, array $attrs, array $columns, $path ) {
		$count = count( $columns );

		if ( 0 === $count || ! isset( $attrs['columnsWidth'] ) ) {
			return;
		}

		$widths = $attrs['columnsWidth'];

		if ( ! is_array( $widths ) || count( $widths ) !== $count ) {
			self::add( $report, 'errors', $path . '/attrs/columnsWidth', 'column_count', sprintf( 'columnsWidth lists %d widths for %d columns.', is_array( $widths ) ? count( $widths ) : 0, $count ) );

			return;
		}

		$manifest = BWFCRM_Email_Design_Manifest::get();
		$presets  = ! is_wp_error( $manifest ) && isset( $manifest['column_presets'] ) ? (array) $manifest['column_presets'] : array();

		foreach ( $presets as $preset ) {
			if ( isset( $preset['width'] ) && self::same_widths( (array) $preset['width'], $widths ) ) {
				return;
			}
		}

		self::add( $report, 'warnings', $path . '/attrs/columnsWidth', 'custom_widths', 'These column widths are not one of the editor presets (see column_presets); the editor will show them but offers no way to pick them again.' );
	}

	private static function same_widths( array $a, array $b ) {
		if ( count( $a ) !== count( $b ) ) {
			return false;
		}

		foreach ( array_values( $a ) as $i => $width ) {
			$other = array_values( $b )[ $i ];

			if ( ! is_numeric( $other ) || abs( (float) $width - (float) $other ) > 0.5 ) {
				return false;
			}
		}

		return true;
	}

	private static function check_settings( array &$report, array $settings ) {
		$manifest    = BWFCRM_Email_Design_Manifest::get();
		$known       = ! is_wp_error( $manifest ) && isset( $manifest['email_settings']['defaults'] ) ? (array) $manifest['email_settings']['defaults'] : array();
		$overridable = ! is_wp_error( $manifest ) && isset( $manifest['email_settings']['global_style_overridable'] ) ? (array) $manifest['email_settings']['global_style_overridable'] : array( 'background', 'width', 'contentBackground', 'align' );
		$site        = class_exists( 'BWFAN_Common' ) && method_exists( 'BWFAN_Common', 'get_block_editor_settings' ) ? BWFAN_Common::get_block_editor_settings() : array();
		$has_style   = is_array( $site ) && ! empty( $site['setting'] );

		foreach ( $settings as $key => $value ) {
			// Settings are written into the email's stylesheet: their text is checked like the blocks'.
			self::collect_strings( $report, $value, '/settings/' . $key, '', 0 );

			if ( ! array_key_exists( $key, $known ) ) {
				self::add( $report, 'errors', '/settings/' . $key, 'unknown_setting', sprintf( 'There is no email setting "%s".', $key ) );
			} elseif ( ! is_array( $value ) ) {
				self::add( $report, 'errors', '/settings/' . $key, 'wrong_type', sprintf( 'Email setting %s must be an object, e.g. {"desktop": …}.', $key ) );
			} elseif ( $has_style && ! in_array( $key, $overridable, true ) ) {
				// The editor applies only these over the site's Global Style; anything else is dropped without a word.
				self::add( $report, 'errors', '/settings/' . $key, 'setting_ignored', sprintf( 'The email setting "%s" has no effect: this site uses a Global Style, and an email may override only %s. Set it on the blocks instead: text colour inline in the content (<span style="color:#hex">), each button\'s "bgColor" and "color".', $key, implode( ', ', $overridable ) ) );
			}
		}
	}

	/** Checks that read every string: markup that must never appear, merge tags, links, unsubscribe. */
	private static function check_text( array &$report, array $options ) {
		$known_tags = isset( $options['merge_tags'] ) && is_array( $options['merge_tags'] ) ? array_flip( $options['merge_tags'] ) : array();
		$has_unsub  = false;

		foreach ( $report['strings'] as $string ) {
			$value = $string['value'];
			$path  = $string['path'];

			list( $tag, $unsafe ) = self::markup_findings( $value );

			if ( '' !== $tag ) {
				self::add( $report, 'errors', $path, 'forbidden_markup', sprintf( '<%s> is not allowed in an email design.', $tag ) );
			}

			if ( $unsafe ) {
				self::add( $report, 'errors', $path, 'forbidden_markup', 'Script handlers and javascript:, vbscript: or data: links are not allowed in an email design.' );
			}

			if ( false !== strpos( $value, '{{unsubscribe_link' ) ) {
				$has_unsub = true;
			}

			if ( ! empty( $known_tags ) && preg_match_all( '/\{\{\s*([a-zA-Z0-9_]+)/', $value, $tags ) ) {
				foreach ( array_unique( $tags[1] ) as $tag ) {
					// A picked product's own placeholders, filled by the product block itself at send time.
					if ( false !== strpos( $path, '/attrs/specificProductData/' ) && in_array( $tag, self::PRODUCT_PLACEHOLDERS, true ) ) {
						continue;
					}

					if ( ! isset( $known_tags[ $tag ] ) ) {
						self::add( $report, 'errors', $path, 'unknown_merge_tag', sprintf( '{{%s}} is not a merge tag on this site. Call list-merge-tags.', $tag ) );
					}
				}
			}

			if ( self::is_link_path( $path ) ) {
				$link = trim( $value );

				if ( '' === $link || '#' === $link ) {
					self::add( $report, 'warnings', $path, 'empty_link', 'This link goes nowhere.' );
				}
			}
		}

		$transactional = ! empty( $options['transactional'] );
		$has_footer    = in_array( 'email-block/footer', $report['names'], true );

		if ( ! $transactional && ! $has_unsub && ! $has_footer ) {
			self::add( $report, 'errors', '', 'no_unsubscribe', 'A marketing email needs an unsubscribe link: the email-block/footer block, or a link to {{unsubscribe_link}} - <a href="{{unsubscribe_link}}">Unsubscribe</a> in a text block at the bottom. Transactional emails are exempt.' );
		}
	}

	/** Attribute paths that hold a link target. */
	private static function is_link_path( $path ) {
		return (bool) preg_match( '#/attrs/(url|link)$|/attrs/(menuItems|icons)/\d+/(url|link)$#', $path );
	}

	/**
	 * Completes a design the way the editor would have created it: every
	 * block gets a unique id, a section its column widths, attributes their
	 * block's order, and empty objects stay objects.
	 *
	 * Ids already present are kept, so a re-saved design keeps its per-block
	 * styles attached.
	 *
	 * Column widths are worked out as the editor works them out whenever it
	 * loads a design, so the markup written here is the markup it would save.
	 *
	 * @param array[] $tree     A tree that passed validate().
	 * @param array   $settings The email's own settings (block.settings); its width decides the column widths.
	 *
	 * @return array[]
	 */
	public static function complete( array $tree, array $settings = array() ) {
		$blocks = BWFCRM_Email_Design_Manifest::blocks();
		$used   = array();

		self::collect_ids( $tree, $used );

		// Widths first, on the plain tree: complete_nodes() then puts every attribute in its place.
		$tree = self::column_widths( $tree, self::email_width( $settings ) );

		return self::complete_nodes( $tree, is_wp_error( $blocks ) ? array() : $blocks, $used );
	}

	/**
	 * The email's content width in pixels: its own setting, else the site's
	 * Global Style, else the editor's 640.
	 *
	 * @param array $settings
	 *
	 * @return int
	 */
	public static function email_width( array $settings = array() ) {
		if ( isset( $settings['width']['desktop']['value'] ) && is_numeric( $settings['width']['desktop']['value'] ) ) {
			return (int) $settings['width']['desktop']['value'];
		}

		$site = class_exists( 'BWFAN_Common' ) && method_exists( 'BWFAN_Common', 'get_block_editor_settings' ) ? BWFAN_Common::get_block_editor_settings() : array();

		if ( isset( $site['setting']['width']['desktop']['value'] ) && is_numeric( $site['setting']['width']['desktop']['value'] ) ) {
			return (int) $site['setting']['width']['desktop']['value'];
		}

		return 640;
	}

	/**
	 * Every column's pixel width, as the section computes it: the email width
	 * less the section's side padding, side borders and the gaps between its
	 * columns, shared out by columnsWidth.
	 *
	 * @param array[] $tree
	 * @param int     $email_width
	 *
	 * @return array[]
	 */
	private static function column_widths( array $tree, $email_width ) {
		foreach ( $tree as $r => $row ) {
			if ( ! isset( $row['name'] ) || BWFCRM_Email_Design_Manifest::ROW !== $row['name'] || empty( $row['innerBlocks'] ) ) {
				continue;
			}

			foreach ( $row['innerBlocks'] as $s => $section ) {
				if ( ! isset( $section['name'] ) || BWFCRM_Email_Design_Manifest::SECTION !== $section['name'] || empty( $section['innerBlocks'] ) ) {
					continue;
				}

				$attrs   = self::plain( self::with_defaults( $section['name'], isset( $section['attrs'] ) && is_array( $section['attrs'] ) ? self::plain( $section['attrs'] ) : array() ) );
				$columns = count( $section['innerBlocks'] );
				// A section without widths gets the equal split complete_nodes() is about to write.
				$shares  = isset( $attrs['columnsWidth'] ) && is_array( $attrs['columnsWidth'] ) ? array_values( $attrs['columnsWidth'] ) : self::equal_widths( $columns );
				$padding = isset( $attrs['padding']['desktop'] ) ? (array) $attrs['padding']['desktop'] : array();
				$border  = isset( $attrs['border']['desktop'] ) ? (array) $attrs['border']['desktop'] : array();
				$gap     = isset( $attrs['colGap']['desktop']['value'] ) ? self::number( $attrs['colGap']['desktop']['value'] ) : 0;
				$extra   = self::number( self::pick( $padding, 'left' ) ) + self::number( self::pick( $padding, 'right' ) ) + ( $columns - 1 ) * $gap + self::number( self::pick( $border, 'left' ) ) + self::number( self::pick( $border, 'right' ) );
				$usable  = (int) ( $email_width - $extra );

				foreach ( $section['innerBlocks'] as $c => $column ) {
					if ( ! isset( $column['name'] ) || BWFCRM_Email_Design_Manifest::COLUMN !== $column['name'] || ! isset( $shares[ $c ] ) || ! is_numeric( $shares[ $c ] ) ) {
						continue;
					}

					$width            = isset( $column['attrs']['width'] ) ? self::plain( $column['attrs']['width'] ) : array();
					$width            = is_array( $width ) ? $width : array();
					$width['desktop'] = array(
						'width' => self::js_number( ( $shares[ $c ] * $usable ) / 100 ),
						'unit'  => 'px',
					);

					$tree[ $r ]['innerBlocks'][ $s ]['innerBlocks'][ $c ]['attrs']['width'] = $width;
				}
			}
		}

		return $tree;
	}

	/** JavaScript's Number#toString for the values a column width can take. */
	private static function js_number( $value ) {
		$value = (float) $value;

		if ( floor( $value ) === $value && abs( $value ) < 1e15 ) {
			return (string) (int) $value;
		}

		// The shortest digits that read back as the same number - what JavaScript prints.
		for ( $precision = 1; $precision <= 17; $precision++ ) {
			// %g follows LC_NUMERIC (a comma under de_DE); JavaScript always prints a point.
			$candidate = str_replace( ',', '.', sprintf( '%.' . $precision . 'g', $value ) );

			if ( (float) $candidate === $value ) {
				return false !== stripos( $candidate, 'e' ) ? (string) $value : $candidate;
			}
		}

		return (string) $value;
	}

	/** Mirrors JavaScript's Number(): '' and null are 0, numeric strings their value. */
	private static function number( $value ) {
		return is_numeric( $value ) ? (float) $value : 0.0;
	}

	private static function pick( array $values, $key ) {
		return isset( $values[ $key ] ) ? $values[ $key ] : 0;
	}

	/** An attribute value with its objects turned back into arrays, for reading. */
	private static function plain( $value ) {
		if ( is_object( $value ) ) {
			$value = get_object_vars( $value );
		}

		if ( is_array( $value ) ) {
			foreach ( $value as $key => $item ) {
				$value[ $key ] = self::plain( $item );
			}
		}

		return $value;
	}

	private static function collect_ids( array $tree, array &$used ) {
		foreach ( $tree as $node ) {
			if ( isset( $node['attrs']['uniqueID'] ) && is_string( $node['attrs']['uniqueID'] ) ) {
				$used[ $node['attrs']['uniqueID'] ] = true;
			}

			if ( ! empty( $node['innerBlocks'] ) && is_array( $node['innerBlocks'] ) ) {
				self::collect_ids( $node['innerBlocks'], $used );
			}
		}
	}

	private static function complete_nodes( array $tree, array $blocks, array &$used ) {
		$out = array();

		foreach ( array_values( $tree ) as $node ) {
			$name     = isset( $node['name'] ) ? $node['name'] : '';
			$attrs    = isset( $node['attrs'] ) && is_array( $node['attrs'] ) ? $node['attrs'] : array();
			$known    = isset( $blocks[ $name ]['attributes'] ) ? (array) $blocks[ $name ]['attributes'] : array();
			$children = isset( $node['innerBlocks'] ) && is_array( $node['innerBlocks'] ) ? $node['innerBlocks'] : array();

			if ( empty( $attrs['uniqueID'] ) || ! is_string( $attrs['uniqueID'] ) ) {
				$attrs = array( 'uniqueID' => self::new_id( $used ) ) + $attrs;
			}

			$attrs = self::editor_attributes( $attrs, $known );

			if ( BWFCRM_Email_Design_Manifest::SECTION === $name && ! isset( $attrs['columnsWidth'] ) && ! empty( $children ) ) {
				$attrs['columnsWidth'] = self::equal_widths( count( $children ) );
			}

			$complete = array(
				'name'  => $name,
				'attrs' => self::objects( $attrs, $known ),
			);

			if ( ! empty( $children ) ) {
				$complete['innerBlocks'] = self::complete_nodes( $children, $blocks, $used );
			}

			$out[] = $complete;
		}

		return $out;
	}

	/**
	 * The attributes as the editor would save them:
	 *  - in the order the block defines them, the order the editor serializes in;
	 *  - a plain value equal to its default left out, as the editor omits those.
	 *
	 * Defaults are not written in. The editor fills in whatever a design leaves
	 * unset when it loads it, so storing a default changes nothing there, and a
	 * design re-saved from here stays the design that was read. Code that needs
	 * the values a block ends up with asks with_defaults().
	 *
	 * @param array $attrs
	 * @param array $known The block's attribute definitions, in the block's order.
	 *
	 * @return array
	 */
	private static function editor_attributes( array $attrs, array $known ) {
		$out = array();

		foreach ( $known as $key => $def ) {
			if ( ! array_key_exists( $key, $attrs ) ) {
				continue;
			}

			$value = $attrs[ $key ];

			if ( is_array( $def ) && array_key_exists( 'default', $def ) && ! is_array( $value ) && $value === $def['default'] ) {
				continue;
			}

			$out[ $key ] = $value;
		}

		// Anything the manifest does not know stays, after the rest; validate() has already refused it.
		return $out + array_diff_key( $attrs, $known );
	}

	/**
	 * A block's attributes with every default the design left unset filled in -
	 * the values the editor works with once it has loaded the block.
	 *
	 * @param string $name
	 * @param array  $attrs
	 *
	 * @return array
	 */
	public static function with_defaults( $name, array $attrs ) {
		$blocks = BWFCRM_Email_Design_Manifest::blocks();
		$known  = ! is_wp_error( $blocks ) && isset( $blocks[ $name ]['attributes'] ) ? (array) $blocks[ $name ]['attributes'] : array();
		$out    = array();

		// In the block's own order, as the editor builds a parsed block's attributes.
		foreach ( $known as $key => $def ) {
			if ( array_key_exists( $key, $attrs ) ) {
				$out[ $key ] = $attrs[ $key ];
			} elseif ( is_array( $def ) && array_key_exists( 'default', $def ) ) {
				$out[ $key ] = $def['default'];
			}
		}

		return $out + array_diff_key( $attrs, $known );
	}

	/**
	 * A block's attributes exactly as the editor holds them while rendering:
	 * defaults filled in, the block's order, and objects as objects - for
	 * anything the editor serializes to JSON (a dynamic block's shortcode).
	 *
	 * @param string $name
	 * @param array  $attrs
	 *
	 * @return array
	 */
	public static function runtime_attributes( $name, array $attrs ) {
		$blocks = BWFCRM_Email_Design_Manifest::blocks();
		$known  = ! is_wp_error( $blocks ) && isset( $blocks[ $name ]['attributes'] ) ? (array) $blocks[ $name ]['attributes'] : array();

		return self::objects( self::with_defaults( $name, self::plain( $attrs ) ), $known );
	}

	/**
	 * Settings as the editor holds them: every value an object except the few
	 * that are lists or plain values.
	 *
	 * @param array $settings
	 *
	 * @return array
	 */
	public static function runtime_settings( array $settings ) {
		$out = array();

		foreach ( self::plain( $settings ) as $key => $value ) {
			$is_list = is_array( $value ) && array() !== $value && array_keys( $value ) === range( 0, count( $value ) - 1 );

			$out[ $key ] = is_array( $value ) && ! $is_list ? self::as_object( $value, 0 ) : $value;
		}

		return $out;
	}

	/** The editor's preset for n equal columns, or an even split if it has none. */
	private static function equal_widths( $count ) {
		$manifest = BWFCRM_Email_Design_Manifest::get();

		foreach ( ! is_wp_error( $manifest ) && isset( $manifest['column_presets'] ) ? (array) $manifest['column_presets'] : array() as $preset ) {
			if ( isset( $preset['name'], $preset['width'] ) && 0 === strpos( (string) $preset['name'], 'equal-' ) && count( (array) $preset['width'] ) === $count ) {
				return array_values( (array) $preset['width'] );
			}
		}

		return array_fill( 0, $count, round( 100 / $count, 2 ) );
	}

	private static function new_id( array &$used ) {
		do {
			$id = substr( bin2hex( random_bytes( 4 ) ), 0, 7 );
		} while ( isset( $used[ $id ] ) );

		$used[ $id ] = true;

		return $id;
	}

	/**
	 * Decoded JSON cannot tell {} from []: both arrive as an empty array, and
	 * serialized as [] an object attribute is thrown away by the editor. Put the
	 * objects back: an attribute typed object, and inside any value the keys the
	 * editor keeps per screen (desktop, mobile) or under an object default.
	 *
	 * @param array $attrs
	 * @param array $known The block's attribute definitions.
	 *
	 * @return array
	 */
	private static function objects( array $attrs, array $known ) {
		foreach ( $attrs as $key => $value ) {
			$type = isset( $known[ $key ]['type'] ) ? $known[ $key ]['type'] : null;

			if ( 'object' === $type && is_array( $value ) ) {
				$attrs[ $key ] = self::as_object( $value, 0 );
			}
		}

		return $attrs;
	}

	private static function as_object( array $value, $depth ) {
		if ( array() === $value ) {
			return (object) array();
		}

		if ( $depth > 8 ) {
			return $value;
		}

		$is_list = array_keys( $value ) === range( 0, count( $value ) - 1 );

		foreach ( $value as $key => $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			// A list keeps its items as they are; an item that is itself a map is an object.
			if ( $is_list ) {
				$item_is_map    = array() !== $item && array_keys( $item ) !== range( 0, count( $item ) - 1 );
				$value[ $key ] = $item_is_map ? self::as_object( $item, $depth + 1 ) : $item;

				continue;
			}

			if ( array() === $item ) {
				// An empty per-screen value is an object; an empty named list (rules, icons) stays a list.
				$value[ $key ] = in_array( (string) $key, array( 'desktop', 'mobile', 'tablet' ), true ) ? (object) array() : array();

				continue;
			}

			$value[ $key ] = self::as_object( $item, $depth + 1 );
		}

		return $is_list ? $value : (object) $value;
	}

	private static function is_type( $value, $type ) {
		switch ( $type ) {
			case 'string':
			case 'url': // The column block declares its link as "url"; the editor treats it as a string.
				return is_string( $value );
			case 'boolean':
				return is_bool( $value );
			case 'number':
				return is_int( $value ) || is_float( $value );
			case 'integer':
				return is_int( $value );
			case 'array':
				return is_array( $value ) && ( array() === $value || array_keys( $value ) === range( 0, count( $value ) - 1 ) );
			case 'object':
				// {} decodes to an empty array, so an empty array is an acceptable object.
				return is_array( $value ) && ( array() === $value || array_keys( $value ) !== range( 0, count( $value ) - 1 ) );
			case 'null':
				return null === $value;
		}

		return true;
	}

	private static function type_label( $type ) {
		return 'url' === $type ? 'a string' : ( 'object' === $type || 'array' === $type || 'integer' === $type ? 'an ' . $type : 'a ' . $type );
	}

	private static function add( array &$report, $bucket, $path, $code, $message ) {
		$path = '' === $path ? '/' : $path;

		// One message per place and problem: a design repeating a mistake does not repeat the report.
		foreach ( $report[ $bucket ] as $existing ) {
			if ( $existing['path'] === $path && $existing['code'] === $code ) {
				return;
			}
		}

		$report[ $bucket ][] = array(
			'path'    => $path,
			'code'    => $code,
			'message' => $message,
		);
	}
}
