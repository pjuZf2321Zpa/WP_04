<?php

defined( 'ABSPATH' ) || exit;

/**
 * The block editor's grammar as data: which blocks exist, their attributes and
 * defaults, how they nest, the column presets and the email settings.
 *
 * Read through BWFCRM_Email_Design_Versions: manifest/2.1.json in full, and a
 * diff for each later editor version, all generated from the editor's own
 * source by bin/email-design/build-block-manifest.mjs. It is never edited by
 * hand: a hand-kept copy would fall behind the editor it describes.
 *
 * Which of those blocks a given email may use depends on the site and on the
 * email's context, exactly as the editor decides it:
 *  - WooCommerce blocks need WooCommerce. Those in the `all` group are always
 *    offered; the rest only when the trigger event lists their group.
 *  - The site logo needs the block editor's site settings, the footer needs
 *    the global email footer.
 */
class BWFCRM_Email_Design_Manifest {

	/** Editor version the plugin loads and this manifest describes. */
	const EDITOR_VERSION = '2.1';

	const ROW = 'email-block/row';
	const SECTION = 'email-block/section';
	const COLUMN = 'email-block/column';

	/** @var array|null */
	private static $data = null;

	/**
	 * @return array|WP_Error The manifest, or why it could not be read.
	 */
	public static function get() {
		if ( null !== self::$data ) {
			return self::$data;
		}

		require_once __DIR__ . '/class-bwfcrm-email-design-versions.php';

		// The first editor version in full, and each later one as a diff on it.
		$data = BWFCRM_Email_Design_Versions::resolve( 'manifest', self::EDITOR_VERSION );

		if ( is_wp_error( $data ) ) {
			return $data;
		}

		if ( ! is_array( $data ) || empty( $data['blocks'] ) || ! is_array( $data['blocks'] ) ) {
			return new WP_Error( 'fkmcp_design_manifest_invalid', 'The email block manifest could not be read.' );
		}

		self::$data = $data;

		return self::$data;
	}

	/** For the self-checks: load a manifest from an array instead of the shipped file. */
	public static function set( $data ) {
		self::$data = is_array( $data ) ? $data : null;
	}

	/**
	 * Blocks an email may use here.
	 *
	 * @param string[] $event_groups WooCommerce block groups the trigger event supports (its supported_blocks);
	 *                               empty for a saved template, which has no event.
	 *
	 * @return array|WP_Error name => block definition, with `available` and `unavailable_reason` set.
	 */
	public static function blocks( array $event_groups = array() ) {
		$manifest = self::get();

		if ( is_wp_error( $manifest ) ) {
			return $manifest;
		}

		$out = array();

		foreach ( $manifest['blocks'] as $name => $block ) {
			$reason = self::unavailable_reason( $name, $block, $event_groups );

			$block['available']          = null === $reason;
			$block['unavailable_reason'] = $reason;
			$out[ $name ]                = $block;
		}

		return $out;
	}

	/**
	 * @param string   $name
	 * @param array    $block
	 * @param string[] $event_groups
	 *
	 * @return string|null Null when the block may be used.
	 */
	private static function unavailable_reason( $name, array $block, array $event_groups ) {
		if ( 'email-block/site-logo' === $name && empty( self::site_settings() ) ) {
			return 'The site logo block needs the email editor site settings.';
		}

		if ( 'email-block/footer' === $name && '' === self::footer() ) {
			return 'The footer block needs a global email footer (Settings > Email).';
		}

		if ( ! isset( $block['kind'] ) || 'dynamic' !== $block['kind'] ) {
			return null;
		}

		if ( ! function_exists( 'bwfan_is_woocommerce_active' ) || ! bwfan_is_woocommerce_active() ) {
			return 'Needs WooCommerce.';
		}

		$groups = isset( $block['groups'] ) && is_array( $block['groups'] ) ? $block['groups'] : array();

		if ( empty( $groups ) || in_array( 'all', $groups, true ) ) {
			return null;
		}

		if ( array_intersect( $groups, $event_groups ) ) {
			return null;
		}

		return sprintf( 'Only in emails of an Automation whose trigger provides %s data.', implode( ' / ', $groups ) );
	}

	/**
	 * The WooCommerce block groups an Automation trigger supports.
	 *
	 * @param string $event_slug
	 *
	 * @return string[]
	 */
	public static function event_groups( $event_slug ) {
		if ( '' === (string) $event_slug || ! function_exists( 'BWFAN_Core' ) || ! isset( BWFAN_Core()->sources ) ) {
			return array();
		}

		$event = BWFAN_Core()->sources->get_event( sanitize_key( $event_slug ) );

		if ( ! is_object( $event ) || ! method_exists( $event, 'get_supported_blocks' ) ) {
			return array();
		}

		return array_values( array_filter( (array) $event->get_supported_blocks(), 'is_string' ) );
	}

	private static function site_settings() {
		if ( ! class_exists( 'BWFAN_Common' ) || ! method_exists( 'BWFAN_Common', 'get_block_editor_settings' ) ) {
			return array();
		}

		$settings = BWFAN_Common::get_block_editor_settings();

		return is_array( $settings ) && ! empty( $settings['site'] ) ? (array) $settings['site'] : array();
	}

	private static function footer() {
		if ( ! class_exists( 'BWFAN_Common' ) || ! method_exists( 'BWFAN_Common', 'get_global_settings' ) ) {
			return '';
		}

		$settings = BWFAN_Common::get_global_settings();

		return isset( $settings['bwfan_email_footer_setting'] ) && is_string( $settings['bwfan_email_footer_setting'] ) ? trim( $settings['bwfan_email_footer_setting'] ) : '';
	}
}
