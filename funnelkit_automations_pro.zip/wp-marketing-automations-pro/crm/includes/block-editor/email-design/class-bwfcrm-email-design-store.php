<?php

defined( 'ABSPATH' ) || exit;

/**
 * The store data an email design refers to by id or code - products,
 * product categories, coupons, an automation's Create Coupon steps, the site
 * logo and social links - read the way the send-time blocks read them.
 *
 * Used by the design checks (does this product, category or coupon exist?)
 * and by the tools that let an AI client look these up.
 */
class BWFCRM_Email_Design_Store {

	/** Most rows one lookup returns. */
	const MAX_ROWS = 50;

	public static function has_woocommerce() {
		return function_exists( 'wc_get_product' ) && ( ! function_exists( 'bwfan_is_woocommerce_active' ) || bwfan_is_woocommerce_active() );
	}

	/**
	 * Published products, as the product block shows them.
	 *
	 * @param array $args {
	 *     @type string $search   Part of the name or SKU.
	 *     @type int[]  $ids      Only these products.
	 *     @type int    $category Only this product category (term id).
	 *     @type string $order    best_selling (default), latest, price_low, price_high, name.
	 *     @type bool   $in_stock Only products in stock or on backorder.
	 *     @type int    $limit
	 *     @type int    $offset
	 * }
	 *
	 * @return array { items: array[], total: int }
	 */
	public static function products( array $args = array() ) {
		if ( ! self::has_woocommerce() ) {
			return array( 'items' => array(), 'total' => 0 );
		}

		$limit = isset( $args['limit'] ) ? max( 1, min( self::MAX_ROWS, (int) $args['limit'] ) ) : 20;
		$query = array(
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'fields'         => 'ids',
			'posts_per_page' => $limit,
			'offset'         => isset( $args['offset'] ) ? max( 0, (int) $args['offset'] ) : 0,
		);

		switch ( isset( $args['order'] ) ? $args['order'] : 'best_selling' ) {
			case 'latest':
				$query['orderby'] = 'date';
				$query['order']   = 'DESC';
				break;
			case 'price_low':
			case 'price_high':
				$query['meta_key'] = '_price'; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- the product block sorts the same way.
				$query['orderby']  = 'meta_value_num';
				$query['order']    = 'price_low' === $args['order'] ? 'ASC' : 'DESC';
				break;
			case 'name':
				$query['orderby'] = 'title';
				$query['order']   = 'ASC';
				break;
			default:
				$query['meta_key'] = 'total_sales'; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- the product block sorts the same way.
				$query['orderby']  = 'meta_value_num';
				$query['order']    = 'DESC';
		}

		if ( ! empty( $args['search'] ) ) {
			$query['s'] = (string) $args['search'];
		}

		if ( ! empty( $args['ids'] ) ) {
			$query['post__in'] = array_values( array_filter( array_map( 'absint', (array) $args['ids'] ) ) );

			// WP_Query ignores an empty post__in and would list every product.
			if ( empty( $query['post__in'] ) ) {
				return array( 'items' => array(), 'total' => 0 );
			}
		}

		if ( ! empty( $args['category'] ) ) {
			$query['tax_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- a category filter is the point of the lookup.
				array(
					'taxonomy' => 'product_cat',
					'field'    => 'term_id',
					'terms'    => array( absint( $args['category'] ) ),
				),
			);
		}

		if ( ! empty( $args['in_stock'] ) ) {
			$query['meta_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- the product block filters the same way.
				array(
					'key'     => '_stock_status',
					'value'   => array( 'instock', 'onbackorder' ),
					'compare' => 'IN',
				),
			);
		}

		$result = new WP_Query( $query );
		$items  = array();

		// One query each for the posts, their meta and terms, and the images,
		// instead of about 7 per product: fields=ids left every cache cold.
		_prime_post_caches( $result->posts, true, true );
		$thumbs = array_filter( array_map( static function ( $id ) {
			return (int) get_post_meta( $id, '_thumbnail_id', true );
		}, $result->posts ) );
		if ( $thumbs ) {
			_prime_post_caches( $thumbs, false, true );
		}

		foreach ( $result->posts as $id ) {
			$product = wc_get_product( $id );

			if ( $product ) {
				$items[] = self::product_row( $product );
			}
		}

		return array(
			'items' => $items,
			'total' => (int) $result->found_posts,
		);
	}

	private static function product_row( $product ) {
		$image = get_post_thumbnail_id( $product->get_id() );
		$short = wp_strip_all_tags( (string) $product->get_short_description() );

		return array(
			'id'            => (int) $product->get_id(),
			'name'          => wp_strip_all_tags( (string) $product->get_name() ),
			'price'         => self::price_text( $product ),
			'regular_price' => (string) $product->get_regular_price(),
			'sale_price'    => (string) $product->get_sale_price(),
			'on_sale'       => (bool) $product->is_on_sale(),
			'in_stock'      => (bool) $product->is_in_stock(),
			'image'         => $image ? (string) wp_get_attachment_image_url( $image, 'medium' ) : null,
			'url'           => (string) $product->get_permalink(),
			'categories'    => array_map( 'intval', (array) $product->get_category_ids() ),
			'description'   => mb_strlen( $short ) > 160 ? mb_substr( $short, 0, 159 ) . '…' : $short,
		);
	}

	/** The price as a shopper reads it: "$84.00 (was $99.00)" on sale. */
	private static function price_text( $product ) {
		$format = static function ( $amount ) {
			return function_exists( 'wc_price' ) ? html_entity_decode( wp_strip_all_tags( wc_price( $amount ) ), ENT_QUOTES, 'UTF-8' ) : (string) $amount;
		};

		if ( '' === (string) $product->get_price() ) {
			return '';
		}

		if ( $product->is_on_sale() && '' !== (string) $product->get_regular_price() ) {
			return $format( $product->get_price() ) . ' (was ' . $format( $product->get_regular_price() ) . ')';
		}

		return $format( $product->get_price() );
	}

	/**
	 * @param int[] $ids
	 *
	 * @return int[] The ids that are not published products.
	 */
	public static function missing_products( array $ids ) {
		if ( ! self::has_woocommerce() ) {
			return array();
		}

		$missing = array();

		foreach ( array_unique( array_map( 'intval', $ids ) ) as $id ) {
			$product = $id > 0 ? wc_get_product( $id ) : false;

			if ( ! $product || 'publish' !== $product->get_status() ) {
				$missing[] = $id;
			}
		}

		return $missing;
	}

	/**
	 * Product categories.
	 *
	 * @param array $args { search, ids, limit, offset }
	 *
	 * @return array { items: array[], total: int }
	 */
	public static function categories( array $args = array() ) {
		if ( ! function_exists( 'get_terms' ) || ! taxonomy_exists( 'product_cat' ) ) {
			return array( 'items' => array(), 'total' => 0 );
		}

		$query = array(
			'taxonomy'   => 'product_cat',
			'hide_empty' => false,
			'orderby'    => 'count',
			'order'      => 'DESC',
		);

		if ( ! empty( $args['search'] ) ) {
			$query['search'] = (string) $args['search'];
		}

		if ( ! empty( $args['ids'] ) ) {
			$query['include'] = array_values( array_filter( array_map( 'absint', (array) $args['ids'] ) ) );
		}

		$total = get_terms( array_merge( $query, array( 'fields' => 'count' ) ) );
		$terms = get_terms(
			array_merge(
				$query,
				array(
					'number' => isset( $args['limit'] ) ? max( 1, min( self::MAX_ROWS, (int) $args['limit'] ) ) : 50,
					'offset' => isset( $args['offset'] ) ? max( 0, (int) $args['offset'] ) : 0,
				)
			)
		);
		$items = array();

		foreach ( is_array( $terms ) ? $terms : array() as $term ) {
			if ( $term instanceof WP_Term ) {
				$items[] = array(
					'id'       => (int) $term->term_id,
					'name'     => html_entity_decode( wp_strip_all_tags( $term->name ), ENT_QUOTES, 'UTF-8' ),
					'slug'     => $term->slug,
					'parent'   => (int) $term->parent,
					'products' => (int) $term->count,
				);
			}
		}

		return array(
			'items' => $items,
			'total' => is_numeric( $total ) ? (int) $total : count( $items ),
		);
	}

	/**
	 * @param int[] $ids
	 *
	 * @return int[] The ids that are not product categories.
	 */
	public static function missing_categories( array $ids ) {
		if ( ! function_exists( 'get_term' ) || ! taxonomy_exists( 'product_cat' ) ) {
			return array();
		}

		$missing = array();

		foreach ( array_unique( array_map( 'intval', $ids ) ) as $id ) {
			$term = $id > 0 ? get_term( $id, 'product_cat' ) : null;

			if ( ! $term instanceof WP_Term ) {
				$missing[] = $id;
			}
		}

		return $missing;
	}

	/**
	 * A store coupon by its code.
	 *
	 * @param string $code
	 *
	 * @return array|null { code, id, expired, description } or null when there is none.
	 */
	public static function coupon( $code ) {
		if ( ! self::has_woocommerce() || ! function_exists( 'wc_get_coupon_id_by_code' ) || '' === trim( (string) $code ) ) {
			return null;
		}

		$id = wc_get_coupon_id_by_code( trim( (string) $code ) );

		return $id ? self::coupon_row( $id ) : null;
	}

	/**
	 * Store coupons a person made (not the ones automations generate per contact).
	 *
	 * @param array $args { search, limit, offset }
	 *
	 * @return array { items: array[], total: int }
	 */
	public static function coupons( array $args = array() ) {
		if ( ! self::has_woocommerce() ) {
			return array( 'items' => array(), 'total' => 0 );
		}

		$query = array(
			'post_type'      => 'shop_coupon',
			'post_status'    => 'publish',
			'fields'         => 'ids',
			'orderby'        => 'date',
			'order'          => 'DESC',
			'posts_per_page' => isset( $args['limit'] ) ? max( 1, min( self::MAX_ROWS, (int) $args['limit'] ) ) : 20,
			'offset'         => isset( $args['offset'] ) ? max( 0, (int) $args['offset'] ) : 0,
			'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- leaves out the coupons automations generate, as the editor's coupon picker does.
				array(
					'key'     => '_is_bwfan_coupon',
					'compare' => 'NOT EXISTS',
				),
			),
		);

		if ( ! empty( $args['search'] ) ) {
			$query['s'] = (string) $args['search'];
		}

		$result = new WP_Query( $query );
		$items  = array();

		foreach ( $result->posts as $id ) {
			$row = self::coupon_row( $id );

			if ( null !== $row ) {
				$items[] = $row;
			}
		}

		return array(
			'items' => $items,
			'total' => (int) $result->found_posts,
		);
	}

	private static function coupon_row( $id ) {
		if ( ! class_exists( 'WC_Coupon' ) ) {
			return null;
		}

		$coupon  = new WC_Coupon( $id );
		$expires = $coupon->get_date_expires();

		return array(
			'code'        => (string) $coupon->get_code(),
			'id'          => (int) $coupon->get_id(),
			'discount'    => wp_strip_all_tags( self::discount_text( $coupon ) ),
			'expires'     => $expires ? $expires->date( 'Y-m-d' ) : null,
			'expired'     => $expires ? $expires->getTimestamp() < time() : false,
			'description' => wp_strip_all_tags( (string) $coupon->get_description() ),
		);
	}

	private static function discount_text( $coupon ) {
		$amount = (float) $coupon->get_amount();

		switch ( $coupon->get_discount_type() ) {
			case 'percent':
				return rtrim( rtrim( number_format( $amount, 2, '.', '' ), '0' ), '.' ) . '% off';
			case 'fixed_product':
				return ( function_exists( 'wc_price' ) ? html_entity_decode( wp_strip_all_tags( wc_price( $amount ) ), ENT_QUOTES, 'UTF-8' ) : $amount ) . ' off each product';
			default:
				return ( function_exists( 'wc_price' ) ? html_entity_decode( wp_strip_all_tags( wc_price( $amount ) ), ENT_QUOTES, 'UTF-8' ) : $amount ) . ' off the cart';
		}
	}

	/**
	 * The Create Coupon steps of an automation: the codes its emails can show.
	 *
	 * @param int $automation_id
	 *
	 * @return array[] { tag: '{{wc_dynamic_coupon id="N"}}', step_id: int, title: string }
	 */
	public static function automation_coupons( $automation_id ) {
		global $wpdb;

		$automation_id = absint( $automation_id );

		if ( ! $automation_id || ! self::has_woocommerce() || ! isset( $wpdb ) ) {
			return array();
		}

		// The same steps the editor's coupon picker lists: active Create Coupon steps of this automation.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT ID, data FROM {$wpdb->prefix}bwfan_automation_step WHERE aid = %d AND action LIKE %s AND status = 1", $automation_id, '%wc_create_coupon%' ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- a design-time lookup, as the editor's own.
		$out  = array();

		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			$data  = json_decode( (string) $row['data'], true );
			$title = isset( $data['sidebarData']['coupon_data']['general']['title'] ) ? (string) $data['sidebarData']['coupon_data']['general']['title'] : '';

			$out[] = array(
				'tag'     => '{{wc_dynamic_coupon id="' . (int) $row['ID'] . '"}}',
				'step_id' => (int) $row['ID'],
				'title'   => wp_strip_all_tags( $title ),
			);
		}

		return $out;
	}

	/** @return string The site logo the site-logo block shows; empty when there is none. */
	public static function site_logo() {
		$settings = self::editor_settings();
		$logo     = isset( $settings['site']['logo'] ) && is_string( $settings['site']['logo'] ) ? trim( $settings['site']['logo'] ) : '';

		return $logo;
	}

	/** @return array[] The site's social icons: { iconName, link }. */
	public static function social() {
		$settings = self::editor_settings();

		return isset( $settings['setting']['social'] ) && is_array( $settings['setting']['social'] ) ? array_values( $settings['setting']['social'] ) : array();
	}

	/** @return string The site's social icon style. */
	public static function social_type() {
		$settings = self::editor_settings();

		return isset( $settings['setting']['socialType'] ) && is_string( $settings['setting']['socialType'] ) ? $settings['setting']['socialType'] : '';
	}

	private static function editor_settings() {
		if ( ! class_exists( 'BWFAN_Common' ) || ! method_exists( 'BWFAN_Common', 'get_block_editor_settings' ) ) {
			return array();
		}

		$settings = BWFAN_Common::get_block_editor_settings();

		return is_array( $settings ) ? $settings : array();
	}
}
