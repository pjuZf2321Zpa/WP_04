<?php

defined( 'ABSPATH' ) || exit;

/**
 * What the recipient will see in a design's dynamic blocks: each block's
 * own send-time code is run, and what it produced is reported - the product
 * names a product block picked, a coupon code, or that the block renders
 * nothing.
 *
 * Every block and merge tag runs with sample data: the preview flag is on and
 * no real order, cart or contact is read, so nothing about a real customer can
 * reach the result or the public preview page, and no tag can act on a real
 * account. Nothing is sent and nothing is stored. The merge-tag data is set
 * for each run and put back afterwards.
 */
class BWFCRM_Email_Design_Preview {

	/** Longest text summary per block. */
	const SUMMARY_CHARS = 300;

	/**
	 * @param string  $html The email HTML as saved (dynamic blocks as [bwfbe_*] shortcodes).
	 * @param array[] $tree The completed design the HTML was rendered from.
	 *
	 * @return array { blocks: array[], conditions: array[] }
	 */
	public static function run( $html, array $tree ) {
		self::load_blocks();

		$saved = class_exists( 'BWFAN_Merge_Tag_Loader' ) ? BWFAN_Merge_Tag_Loader::get_data() : array();
		$user  = get_current_user_id();

		try {
			self::use_sample_data();

			$blocks     = self::dynamic_blocks( $html, $tree );
			$conditions = self::conditions( $tree );
		} finally {
			self::leave_sample_data( $user );

			if ( class_exists( 'BWFAN_Merge_Tag_Loader' ) ) {
				BWFAN_Merge_Tag_Loader::reset_data();
				BWFAN_Merge_Tag_Loader::set_data( is_array( $saved ) ? $saved : array() );
			}
		}

		return array(
			'blocks'     => $blocks,
			'conditions' => $conditions,
		);
	}

	/**
	 * The whole email as the recipient receives it, rendered by the send path
	 * the admin's "Preview and Test" uses: visibility conditions and dynamic
	 * blocks run, merge tags filled with the send path's sample values, the
	 * email wrapped and styled.
	 *
	 * @param string $html The email HTML as saved.
	 *
	 * @return string
	 */
	public static function render_email( $html ) {
		self::load_blocks();

		$saved = class_exists( 'BWFAN_Merge_Tag_Loader' ) ? BWFAN_Merge_Tag_Loader::get_data() : array();
		$user  = get_current_user_id();

		// The page this HTML is shown on is a public link: no working account link for a real recipient may reach it.
		add_filter( 'pre_do_shortcode_tag', array( __CLASS__, 'dead_account_tag' ), 10, 2 );

		try {
			self::use_sample_data();

			if ( class_exists( 'BWFAN_Common' ) ) {
				BWFAN_Common::bwfan_before_send_mail( 'block' );

				$html = BWFAN_Common::correct_shortcode_string( $html, 5 );
				$html = BWFAN_Common::decode_merge_tags( $html );
				$html = BWFAN_Common::bwfan_correct_protocol_url( $html );
			}

			$action = function_exists( 'BWFAN_Core' ) && isset( BWFAN_Core()->integration ) ? BWFAN_Core()->integration->get_action( 'wp_sendemail' ) : null;

			if ( null === $action && class_exists( 'BWFAN_Wp_Sendemail' ) ) {
				$action = BWFAN_Wp_Sendemail::get_instance();
			}

			if ( is_object( $action ) && method_exists( $action, 'email_content_v2' ) ) {
				$html = (string) $action->email_content_v2( array( 'template' => 5, 'body' => $html ) );
			}

			// Unsubscribe, profile, subscribe, cart and link-trigger links name the contact by uid: the page is kept, the uid dropped.
			$html = preg_replace( '/([?&;](?:bwfan-)?uid=)[^&"\'\s<>#]*/i', '$1', $html );
		} finally {
			remove_filter( 'pre_do_shortcode_tag', array( __CLASS__, 'dead_account_tag' ), 10 );
			self::leave_sample_data( $user );

			if ( class_exists( 'BWFAN_Merge_Tag_Loader' ) ) {
				BWFAN_Merge_Tag_Loader::reset_data();
				BWFAN_Merge_Tag_Loader::set_data( is_array( $saved ) ? $saved : array() );
			}
		}

		return $html;
	}

	/**
	 * Merge tags that come out empty on this site and would leave gaps like
	 * "Thanks for shopping with ."
	 *
	 * @param string $html The email HTML as saved.
	 *
	 * @return string[] The tags, as written: {{business_name}}.
	 */
	public static function empty_merge_tags( $html ) {
		// The global footer is a tag of its own: what it holds is shown too.
		if ( false !== strpos( (string) $html, '{{mail_footer}}' ) && class_exists( 'BWFAN_Common' ) && method_exists( 'BWFAN_Common', 'get_global_settings' ) ) {
			$settings = BWFAN_Common::get_global_settings();
			$html    .= isset( $settings['bwfan_email_footer_setting'] ) ? ' ' . (string) $settings['bwfan_email_footer_setting'] : '';
		}

		// Links carry their own tags (unsubscribe, cart recovery); only visible text matters here.
		preg_match_all( '/\{\{\s*([a-z0-9_]+)[^{}]*\}\}/i', wp_strip_all_tags( preg_replace( '/<a\b[^>]*>/i', '', (string) $html ) ), $found );

		$tags = array_values( array_unique( $found[0] ) );

		if ( empty( $tags ) || ! class_exists( 'BWFAN_Common' ) || ! class_exists( 'BWFAN_Merge_Tag_Loader' ) ) {
			return array();
		}

		$saved = BWFAN_Merge_Tag_Loader::get_data();
		$user  = get_current_user_id();
		$empty = array();

		try {
			self::use_sample_data();

			foreach ( $tags as $tag ) {
				// Sample values for a contact are what a real contact would fill; site-wide tags are read as they are.
				if ( 0 === strpos( trim( $tag, '{ ' ), 'contact_' ) ) {
					continue;
				}

				if ( '' === trim( wp_strip_all_tags( (string) BWFAN_Common::decode_merge_tags( $tag ) ) ) ) {
					$empty[] = $tag;
				}
			}
		} finally {
			self::leave_sample_data( $user );
			BWFAN_Merge_Tag_Loader::reset_data();
			BWFAN_Merge_Tag_Loader::set_data( is_array( $saved ) ? $saved : array() );
		}

		return $empty;
	}

	/** The send-time block code: registered when the block editor controller loads. */
	private static function load_blocks() {
		if ( ! class_exists( 'BWFCRM_Block_Editor' ) && defined( 'BWFAN_PRO_PLUGIN_DIR' ) ) {
			require_once BWFAN_PRO_PLUGIN_DIR . '/crm/includes/class-bwfcrm-block-editor.php';
		}

		if ( class_exists( 'BWFCRM_Block_Editor' ) && method_exists( 'BWFCRM_Block_Editor', 'set_global_css_variables' ) ) {
			BWFCRM_Block_Editor::set_global_css_variables();
		}

		if ( function_exists( 'BWFAN_Core' ) && isset( BWFAN_Core()->rules ) && method_exists( BWFAN_Core()->rules, 'load_rules_classes' ) ) {
			BWFAN_Core()->rules->load_rules_classes();
		}
	}

	/**
	 * Tags that hand out the recipient's account itself answer a dead value
	 * while render_email() runs. A password setup link is a real reset key (and
	 * making one voids the recipient's earlier one); the hash uid is the key the
	 * account links carry. A filter, not a swap of the shortcode, since the
	 * merge tags register their shortcodes during the render itself.
	 *
	 * @param false|string $output What the shortcode would give instead of running.
	 * @param string       $tag
	 *
	 * @return false|string
	 */
	public static function dead_account_tag( $output, $tag ) {
		$dead = array(
			'bwfan_contact_password_setup_link' => '#',
			'bwfan_contact_hash_uid'            => '',
		);

		return isset( $dead[ $tag ] ) ? $dead[ $tag ] : $output;
	}

	/**
	 * Sample values for every merge tag and block: the one data a preview ever
	 * runs with. Two more things would otherwise put real data in the result,
	 * which ends on a public page even in preview mode: the contact tags read the
	 * logged-in user (on an MCP request, the admin who connected the client), so
	 * the run has no current user; and the order table template loads the site's
	 * latest order, so those tags answer a fixed text (sample_order_tag()).
	 * leave_sample_data() undoes both.
	 */
	private static function use_sample_data() {
		if ( ! class_exists( 'BWFAN_Merge_Tag_Loader' ) ) {
			return;
		}

		BWFAN_Merge_Tag_Loader::reset_data();
		BWFAN_Merge_Tag_Loader::set_data( array( 'is_preview' => true ) );

		add_filter( 'pre_do_shortcode_tag', array( __CLASS__, 'sample_order_tag' ), 10, 3 );
		wp_set_current_user( 0 );
	}

	/** Puts back the current user and drops the order-table filter; runs in every `finally` that ends a use_sample_data(). */
	private static function leave_sample_data( $user_id ) {
		remove_filter( 'pre_do_shortcode_tag', array( __CLASS__, 'sample_order_tag' ), 10 );
		wp_set_current_user( $user_id );
	}

	/**
	 * Order summary and every tag laid out as the order table answer a fixed
	 * text. In preview mode that template still includes the site's latest real
	 * order (number, items, totals, note, download links with the customer's
	 * email and order key), and the page this renders for is public. Any tag
	 * asked for template="order-table" is covered, whichever its group: the
	 * template, not the tag, is what loads the order.
	 *
	 * @param false|string $output What the shortcode would give instead of running.
	 * @param string       $tag
	 * @param array|string $attr
	 *
	 * @return false|string
	 */
	public static function sample_order_tag( $output, $tag, $attr = array() ) {
		if ( 'bwfan_order_summary' === $tag || ( is_array( $attr ) && isset( $attr['template'] ) && 'order-table' === $attr['template'] ) ) {
			return 'Order summary - filled from the order when the email is sent';
		}

		return $output;
	}

	/**
	 * Runs every dynamic block's shortcode, in the order the design holds them.
	 */
	private static function dynamic_blocks( $html, array $tree ) {
		$by_id = array();

		self::walk(
			$tree,
			function ( $block, $path ) use ( &$by_id ) {
				if ( ! empty( $block['attrs']['uniqueID'] ) && is_string( $block['attrs']['uniqueID'] ) ) {
					$by_id[ $block['attrs']['uniqueID'] ] = array( 'path' => $path, 'block' => (string) $block['name'] );
				}
			}
		);

		preg_match_all( '/\[(bwfbe_(?!email_block_visibility)[a-z_]+)\b[^\]]*\](.*?)\[\/\1\]/s', $html, $matches, PREG_SET_ORDER );

		$out = array();

		foreach ( $matches as $match ) {
			// The block's attributes travel inside its shortcode, percent-encoded: its uniqueID says which block it is.
			$attrs  = json_decode( self::unescape( $match[2] ), true );
			$id     = is_array( $attrs ) && isset( $attrs['uniqueID'] ) ? (string) $attrs['uniqueID'] : '';
			$where  = isset( $by_id[ $id ] ) ? $by_id[ $id ] : array( 'path' => '', 'block' => $match[1] );
			$output = '';

			try {
				$output = (string) do_shortcode( $match[0] );
			} catch ( Throwable $e ) {
				$out[] = $where + array( 'shows' => 'error', 'summary' => 'The block failed to render: ' . wp_strip_all_tags( $e->getMessage() ) );
				continue;
			}

			$out[] = $where + self::describe( $match[1], $output );
		}

		return $out;
	}

	/** The reverse of JavaScript's escape(), which the editor uses for a block's attributes. */
	private static function unescape( $value ) {
		$value = preg_replace_callback(
			'/%u([0-9a-fA-F]{4})/',
			static function ( $m ) {
				return mb_convert_encoding( pack( 'n', hexdec( $m[1] ) ), 'UTF-8', 'UTF-16BE' );
			},
			(string) $value
		);

		return rawurldecode( $value );
	}

	/** What a block's output shows, in words. */
	private static function describe( $shortcode, $output ) {
		$text = trim( preg_replace( '/\s+/', ' ', html_entity_decode( wp_strip_all_tags( preg_replace( '/<style\b[^>]*>.*?<\/style>/is', '', $output ) ), ENT_QUOTES, 'UTF-8' ) ) );

		if ( '' === $text && false === stripos( $output, '<img' ) ) {
			return array( 'shows' => 'nothing', 'summary' => 'Renders nothing in this context.' );
		}

		$row = array(
			'shows'   => 'content',
			'summary' => mb_strlen( $text ) > self::SUMMARY_CHARS ? mb_substr( $text, 0, self::SUMMARY_CHARS - 1 ) . '…' : $text,
		);

		if ( 'bwfbe_multi_product' === $shortcode ) {
			preg_match_all( '/class="bwf-multi-product-title"[^>]*>.*?<a\b[^>]*>(.*?)<\/a>/is', $output, $titles );

			$row['shows']    = 'products';
			$row['products'] = array_values( array_filter( array_map( 'trim', array_map( 'wp_strip_all_tags', $titles[1] ) ) ) );

			if ( empty( $row['products'] ) ) {
				$row['shows']   = 'nothing';
				$row['summary'] = 'The feed found no products.';
			}
		}

		return $row;
	}

	/** The conditional blocks: no order or cart is read, so none can be judged here. */
	private static function conditions( array $tree ) {
		$out = array();

		self::walk(
			$tree,
			function ( $block, $path ) use ( &$out ) {
				$rules = isset( $block['attrs']['conditional']['rules'] ) ? BWFCRM_Email_Render_Js::plain( $block['attrs']['conditional']['rules'] ) : array();

				if ( empty( $rules ) ) {
					return;
				}

				$out[] = array( 'path' => $path, 'block' => (string) $block['name'] ) + array( 'shown' => null, 'note' => 'Checked only when an automation sends the email; a broadcast always shows it.' );
			}
		);

		return $out;
	}

	private static function walk( array $tree, callable $visit, $prefix = '' ) {
		foreach ( array_values( $tree ) as $i => $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			$path = $prefix . '/' . $i;

			$visit( $block, $path );

			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				self::walk( $block['innerBlocks'], $visit, $path . '/innerBlocks' );
			}
		}
	}
}
