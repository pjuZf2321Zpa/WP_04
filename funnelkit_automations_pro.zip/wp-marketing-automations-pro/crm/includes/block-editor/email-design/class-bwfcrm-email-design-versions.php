<?php

defined( 'ABSPATH' ) || exit;

/**
 * The manifest and the option guide of every editor version, kept as one
 * full description of the first version and a diff per version after it.
 *
 *   manifest/2.1.json               the base: every block, attribute, preset, setting
 *   manifest/2.1-guide.json         the base guide
 *   manifest/<v>.diff.json          what editor version <v> changed in the manifest
 *   manifest/<v>-guide.diff.json    what it changed in the guide (optional)
 *
 * A version is read by starting from the base and applying each later diff
 * in version order. Each diff names the version it builds on ("extends"), so
 * a missing or misplaced one is refused rather than silently skipped.
 *
 * Diffs are JSON Merge Patch (RFC 7386): an object is merged key by key, a
 * null removes the key, anything else replaces the value. One addition: a
 * list of named items (column presets, recipes) may be patched as an object
 * keyed by name - null removes the item, an object merges into it, and a new
 * name adds it at the end - so adding a preset does not restate the rest.
 *
 * What a merge patch cannot say - a value that is null, or an object holding
 * nulls - is written {"$replace": <value>}: the value as it is, not merged.
 */
class BWFCRM_Email_Design_Versions {

	/** The first version described in full; every later one is a diff on it. */
	const BASE = '2.1';

	/** Keys of a diff that describe it, not the version it produces. */
	const META_KEYS = array( 'extends' );

	/** A value set exactly as given, nulls and all, instead of merged. */
	const REPLACE = '$replace';

	/**
	 * The manifest or guide of an editor version.
	 *
	 * @param string      $kind    manifest | guide
	 * @param string      $version e.g. 2.1
	 * @param string|null $dir     The manifest folder; the shipped one by default.
	 *
	 * @return array|WP_Error
	 */
	public static function resolve( $kind, $version, $dir = null ) {
		$dir     = null !== $dir ? rtrim( $dir, '/' ) : __DIR__ . '/manifest';
		$version = (string) $version;
		$data    = self::read( $dir . '/' . self::file( $kind, self::BASE, false ) );

		if ( null === $data ) {
			return new WP_Error( 'fkmcp_design_manifest_missing', sprintf( 'The email design %s for editor version %s, the base every version builds on, is missing or unreadable.', $kind, self::BASE ) );
		}

		$known = self::versions( $dir );

		if ( ! in_array( $version, $known, true ) ) {
			return new WP_Error( 'fkmcp_design_manifest_missing', sprintf( 'There is no email design manifest for editor version %s. Known versions: %s.', $version, implode( ', ', $known ) ) );
		}

		$previous = self::BASE;

		foreach ( $known as $step ) {
			if ( version_compare( $step, self::BASE, '<=' ) || version_compare( $step, $version, '>' ) ) {
				continue;
			}

			$file = $dir . '/' . self::file( $kind, $step, true );

			// A version may leave the guide as it was; the manifest always has its diff.
			if ( 'guide' === $kind && ! is_readable( $file ) ) {
				$previous = $step;
				continue;
			}

			$diff = self::read( $file, false );

			if ( ! $diff instanceof stdClass ) {
				return new WP_Error( 'fkmcp_design_manifest_missing', sprintf( 'The %s diff for editor version %s is missing or unreadable.', $kind, $step ) );
			}

			$extends = isset( $diff->extends ) ? (string) $diff->extends : '';

			if ( $extends !== $previous ) {
				return new WP_Error( 'fkmcp_design_manifest_chain', sprintf( 'The %s diff for editor version %s extends "%s", but the version before it is %s.', $kind, $step, $extends, $previous ) );
			}

			foreach ( self::META_KEYS as $key ) {
				unset( $diff->$key );
			}

			$data     = self::patch( $data, $diff );
			$previous = $step;
		}

		$data['editor_version'] = $version;

		return $data;
	}

	/**
	 * Every editor version there is a manifest for, oldest first.
	 *
	 * @param string|null $dir
	 *
	 * @return string[]
	 */
	public static function versions( $dir = null ) {
		$dir      = null !== $dir ? rtrim( $dir, '/' ) : __DIR__ . '/manifest';
		$versions = array( self::BASE );

		foreach ( (array) glob( $dir . '/*.diff.json' ) as $file ) {
			if ( preg_match( '/^(\d+(?:\.\d+)*)\.diff\.json$/', basename( $file ), $m ) && version_compare( $m[1], self::BASE, '>' ) ) {
				$versions[] = $m[1];
			}
		}

		usort( $versions, 'version_compare' );

		return array_values( array_unique( $versions ) );
	}

	private static function file( $kind, $version, $diff ) {
		return $version . ( 'guide' === $kind ? '-guide' : '' ) . ( $diff ? '.diff' : '' ) . '.json';
	}

	/** A JSON file: as arrays, or with objects kept as objects (for a diff, where {} and [] differ). */
	private static function read( $file, $assoc = true ) {
		if ( ! is_readable( $file ) ) {
			return null;
		}

		$data = json_decode( (string) file_get_contents( $file ), $assoc ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- a file shipped inside this plugin, not a URL.

		return $assoc ? ( is_array( $data ) ? $data : null ) : $data;
	}

	// ─── Applying a diff ──────────────────────────────────────────────

	/**
	 * Applies a merge patch: $patch as decoded with objects kept as objects.
	 *
	 * @param mixed $target
	 * @param mixed $patch
	 *
	 * @return mixed
	 */
	public static function patch( $target, $patch ) {
		if ( ! $patch instanceof stdClass ) {
			return self::plain( $patch );
		}

		$props = get_object_vars( $patch );

		if ( array( self::REPLACE ) === array_keys( $props ) ) {
			return self::plain( $props[ self::REPLACE ] );
		}

		if ( self::is_named_list( $target ) ) {
			return self::patch_named( $target, $patch );
		}

		$target = is_array( $target ) && ! self::is_list( $target ) ? $target : array();

		foreach ( get_object_vars( $patch ) as $key => $value ) {
			if ( null === $value ) {
				unset( $target[ $key ] );
			} else {
				$target[ $key ] = self::patch( isset( $target[ $key ] ) ? $target[ $key ] : null, $value );
			}
		}

		return $target;
	}

	private static function patch_named( array $list, stdClass $patch ) {
		foreach ( get_object_vars( $patch ) as $name => $value ) {
			$at = self::index_of( $list, (string) $name );

			if ( null === $value ) {
				if ( null !== $at ) {
					array_splice( $list, $at, 1 );
				}
			} elseif ( null !== $at ) {
				$list[ $at ] = self::patch( $list[ $at ], $value );
			} else {
				$item   = self::patch( array(), $value );
				$list[] = array( 'name' => isset( $item['name'] ) ? $item['name'] : (string) $name ) + $item;
			}
		}

		return array_values( $list );
	}

	// ─── Making a diff ────────────────────────────────────────────────

	/**
	 * The diff that turns $old into $new: what a new editor version changed.
	 *
	 * @param array    $old     The previous version, resolved.
	 * @param array    $new     The new version in full.
	 * @param stdClass $new_obj The new version decoded with objects kept, for exact values.
	 *
	 * @return stdClass
	 */
	public static function diff( array $old, array $new, stdClass $new_obj ) {
		$out = new stdClass();

		foreach ( $old as $key => $value ) {
			if ( ! array_key_exists( $key, $new ) ) {
				$out->$key = null;
			}
		}

		foreach ( $new as $key => $value ) {
			$exact = $new_obj->$key;

			if ( ! array_key_exists( $key, $old ) ) {
				$out->$key = self::literal( $exact );
			} elseif ( $old[ $key ] === $value ) {
				continue;
			} elseif ( self::same( $old[ $key ], $value ) ) {
				continue;
			} elseif ( self::is_object( $old[ $key ] ) && is_array( $value ) && $exact instanceof stdClass ) {
				// Object to object - to an empty one too: a merge patch cannot say "replace with {}",
				// so the keys that go are named with null.
				$out->$key = self::diff( $old[ $key ], $value, $exact );
			} elseif ( self::is_named_list( $old[ $key ] ) && self::is_named_list( $value ) && self::same_order( $old[ $key ], $value ) ) {
				$out->$key = self::diff_named( $old[ $key ], $value, $exact );
			} else {
				$out->$key = self::literal( $exact );
			}
		}

		return $out;
	}

	private static function diff_named( array $old, array $new, array $new_obj ) {
		$out = new stdClass();

		foreach ( $old as $item ) {
			if ( null === self::index_of( $new, $item['name'] ) ) {
				$out->{$item['name']} = null;
			}
		}

		foreach ( $new as $i => $item ) {
			$at = self::index_of( $old, $item['name'] );

			if ( null === $at ) {
				$out->{$item['name']} = self::literal( $new_obj[ $i ] );
			} elseif ( ! self::same( $old[ $at ], $item ) ) {
				$out->{$item['name']} = self::diff( $old[ $at ], $item, $new_obj[ $i ] );
			}
		}

		return $out;
	}

	/** Whether the items both lists keep are in the same order, which patching by name preserves. */
	private static function same_order( array $old, array $new ) {
		$kept = array();

		foreach ( $new as $item ) {
			if ( null !== self::index_of( $old, $item['name'] ) ) {
				$kept[] = $item['name'];
			}
		}

		$before = array();

		foreach ( $old as $item ) {
			if ( null !== self::index_of( $new, $item['name'] ) ) {
				$before[] = $item['name'];
			}
		}

		// New items are appended, so they must all come after the kept ones.
		$last_kept = -1;
		$first_new = PHP_INT_MAX;

		foreach ( $new as $i => $item ) {
			if ( null !== self::index_of( $old, $item['name'] ) ) {
				$last_kept = $i;
			} else {
				$first_new = min( $first_new, $i );
			}
		}

		return $kept === $before && $last_kept < $first_new;
	}

	// ─── Helpers ──────────────────────────────────────────────────────

	/** Whether two values hold the same data, whatever order their keys are in. */
	public static function same( $a, $b ) {
		return self::canonical( $a ) === self::canonical( $b );
	}

	private static function canonical( $value ) {
		if ( ! is_array( $value ) ) {
			return $value;
		}

		if ( ! self::is_list( $value ) ) {
			ksort( $value );
		}

		foreach ( $value as $key => $item ) {
			$value[ $key ] = self::canonical( $item );
		}

		return $value;
	}

	private static function is_list( $value ) {
		return is_array( $value ) && ( array() === $value || array_keys( $value ) === range( 0, count( $value ) - 1 ) );
	}

	private static function is_object( $value ) {
		return is_array( $value ) && ! self::is_list( $value );
	}

	/** A non-empty list whose items are objects each with a unique string name. */
	private static function is_named_list( $value ) {
		if ( ! self::is_list( $value ) || array() === $value ) {
			return false;
		}

		$names = array();

		foreach ( $value as $item ) {
			if ( ! is_array( $item ) || ! isset( $item['name'] ) || ! is_string( $item['name'] ) || isset( $names[ $item['name'] ] ) ) {
				return false;
			}

			$names[ $item['name'] ] = true;
		}

		return true;
	}

	private static function index_of( array $list, $name ) {
		foreach ( $list as $i => $item ) {
			if ( is_array( $item ) && isset( $item['name'] ) && $name === $item['name'] ) {
				return $i;
			}
		}

		return null;
	}

	/** A value for a diff: as it is, unless a merge patch would misread it (a null, or an object holding one). */
	private static function literal( $value ) {
		return null === $value || ( $value instanceof stdClass && self::holds_null( $value ) ) ? (object) array( self::REPLACE => $value ) : $value;
	}

	private static function holds_null( $value ) {
		foreach ( (array) $value as $item ) {
			if ( null === $item || ( ( is_object( $item ) || is_array( $item ) ) && self::holds_null( $item ) ) ) {
				return true;
			}
		}

		return false;
	}

	/** A patch value as the arrays the rest of the code reads. */
	private static function plain( $value ) {
		return is_object( $value ) || is_array( $value ) ? json_decode( (string) wp_json_encode( $value ), true ) : $value;
	}
}
