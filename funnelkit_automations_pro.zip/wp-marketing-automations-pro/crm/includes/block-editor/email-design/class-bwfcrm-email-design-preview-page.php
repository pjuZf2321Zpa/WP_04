<?php

defined( 'ABSPATH' ) || exit;

/**
 * A private, short-lived page showing a rendered email the way its
 * recipient sees it, at desktop and phone width side by side - so an AI
 * client with a browser, or a person, can look at a design and improve it
 * before it is saved.
 *
 * The rendered email is kept for an hour under a random token. A preview of
 * sample data needs no login, since the one who asked for it may be a browser
 * the AI client drives: anyone holding the link can see it until it expires,
 * so the link is only ever returned to the MCP client that asked for it.
 * A preview showing a real order, cart or contact is kept ten minutes and
 * opens only for the user who made it, or an admin; anyone else gets what an
 * expired link gets, so nothing says the preview exists.
 *
 * Each view is a sandboxed frame the email cannot run script in. It shares
 * the page's origin only so the page can grow the frame to the email's full
 * height, and a full-page screenshot then shows the whole email.
 */
class BWFCRM_Email_Design_Preview_Page {

	/** Query argument the page answers on. */
	const QUERY = 'fk-email-preview';

	/** How long a preview stays viewable. */
	const TTL = HOUR_IN_SECONDS;

	/** How long a preview showing a real customer's order or cart stays viewable. */
	const PRIVATE_TTL = 600;

	/** Desktop view width: wider than the emails' 768px mobile breakpoint, or it shows the phone layout. */
	const DESKTOP_WIDTH = 820;

	/** Phone width the mobile view is shown at. */
	const PHONE_WIDTH = 375;

	/**
	 * The page's one script: grows each view to the email's full height, now
	 * if the page has already loaded, else on load. The Content-Security-Policy
	 * allows it, and only it, by its hash.
	 */
	const SCRIPT = "(function () { function size() { document.querySelectorAll('iframe').forEach(function (f) { f.style.height = '0'; f.style.height = f.contentDocument.documentElement.scrollHeight + 'px'; }); } if (document.readyState === 'complete') { size(); } else { window.addEventListener('load', size); } })();";

	/**
	 * Keeps a rendered email and returns the link that shows it.
	 *
	 * @param string $html    The email as rendered for the recipient.
	 * @param string $title   What the preview is of.
	 * @param bool   $private Whether it shows a real order, cart or contact: then
	 *                        only its creator or an admin may open it, for less time.
	 *
	 * The token is a keyed hash of what is shown (and, for a private one, who
	 * may see it): previewing the same email again rewrites its own row and
	 * hands back the same link, instead of storing the HTML once per call.
	 * Without the site's salt the token can't be derived from the content.
	 *
	 * @return array { url, expires } Both null when the preview could not be stored.
	 */
	public static function create( $html, $title = '', $private = false ) {
		$token = substr( hash_hmac( 'sha256', implode( "\0", array( (string) $html, (string) $title, $private ? 'private:' . get_current_user_id() : 'public' ) ), wp_salt( 'auth' ) ), 0, 32 );
		$ttl   = $private ? self::PRIVATE_TTL : self::TTL;
		$data  = array(
			'html'    => (string) $html,
			'title'   => (string) $title,
			'created' => time(),
			'ttl'     => $ttl,
			'private' => (bool) $private,
		);

		if ( $private ) {
			$data['creator'] = get_current_user_id();
		}

		// false also means "unchanged", so only a row that is not there now is a failure (a cache over its item size, for one).
		if ( ! set_transient( self::key( $token ), $data, $ttl ) && ! is_array( get_transient( self::key( $token ) ) ) ) {
			return array(
				'url'     => null,
				'expires' => null,
			);
		}

		return array(
			'url'     => add_query_arg( self::QUERY, $token, home_url( '/' ) ),
			'expires' => gmdate( 'c', time() + $ttl ),
		);
	}

	private static function key( $token ) {
		return 'bwfcrm_email_preview_' . $token;
	}

	/**
	 * Answers a request for a preview: the side-by-side page, or with
	 * view=email the bare email. Hooked early on template_redirect.
	 */
	public static function maybe_serve() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- a read-only page keyed by a random token, as a shared-link preview is.
		$token = isset( $_GET[ self::QUERY ] ) ? sanitize_text_field( wp_unslash( $_GET[ self::QUERY ] ) ) : '';

		if ( empty( $token ) ) {
			return;
		}

		// Page caches that ignore no-cache headers still honour this; a cached copy would outlive the link.
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}

		nocache_headers();
		header( 'X-Robots-Tag: noindex, nofollow' );
		header( 'Referrer-Policy: no-referrer' );
		// Nothing on the page is for another site to frame; its views are srcdoc frames, never this URL.
		header( 'X-Frame-Options: DENY' );
		header( 'X-Content-Type-Options: nosniff' );

		$data = 1 === preg_match( '/^[A-Za-z0-9]{32}$/', $token ) ? get_transient( self::key( $token ) ) : false;

		if ( ! is_array( $data ) || empty( $data['html'] ) || ! self::can_view( $data ) ) {
			self::expired();
		}

		status_header( 200 );
		header( 'Content-Type: text/html; charset=utf-8' );

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- see above.
		if ( isset( $_GET['view'] ) && 'email' === sanitize_key( wp_unslash( $_GET['view'] ) ) ) {
			// The email alone, as sandboxed as the frames of the page: no script, and not this site's origin.
			header( "Content-Security-Policy: sandbox allow-popups allow-popups-to-escape-sandbox; script-src 'none'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'" );
			echo $data['html']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the email as rendered by the send path, shown as the recipient sees it.
			exit;
		}

		self::page( $data );
		exit;
	}

	/** The one answer for a link that shows nothing: expired, unknown, or not this viewer's. */
	private static function expired() {
		status_header( 404 );
		header( 'Content-Type: text/plain; charset=utf-8' );
		echo esc_html__( 'This email preview has expired. Ask for a new one.', 'wp-marketing-automations-pro' );
		exit;
	}

	private static function is_private( array $data ) {
		// Stored before the flag existed: the shorter lifetime meant real data.
		return isset( $data['private'] ) ? (bool) $data['private'] : isset( $data['ttl'] ) && (int) $data['ttl'] < self::TTL;
	}

	/** A real-data preview opens only for the user who made it, or an admin. */
	private static function can_view( array $data ) {
		if ( ! self::is_private( $data ) ) {
			return true;
		}

		if ( ! is_user_logged_in() ) {
			return false;
		}

		return ( isset( $data['creator'] ) && get_current_user_id() === (int) $data['creator'] ) || current_user_can( 'manage_options' );
	}

	private static function page( array $data ) {
		$email = add_query_arg( 'view', 'email' );

		// The page's own styles and script; images from anywhere, as the email shows them. The views are
		// srcdoc frames and inherit this policy, so it also allows the Google Fonts the renderer links, and
		// https pages for a link clicked inside a view (the views run no script).
		header( "Content-Security-Policy: default-src 'none'; script-src 'sha256-" . base64_encode( hash( 'sha256', self::SCRIPT, true ) ) . "'; style-src 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src * data:; frame-src 'self' https:; base-uri 'none'; form-action 'none'; frame-ancestors 'none'" );
		$title = '' !== $data['title'] ? $data['title'] : __( 'Email preview', 'wp-marketing-automations-pro' );
		?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?php echo esc_html( $title ); ?></title>
<style>
	body { margin: 0; background: #eef0f3; color: #1f2430; font: 14px/1.5 -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
	header { padding: 14px 24px; background: #fff; border-bottom: 1px solid #dcdfe5; display: flex; flex-wrap: wrap; gap: 8px 24px; align-items: baseline; }
	header h1 { font-size: 16px; margin: 0; }
	header p { margin: 0; color: #5b6272; font-size: 13px; }
	main { display: flex; flex-wrap: wrap; gap: 32px; padding: 24px; align-items: flex-start; justify-content: center; }
	figure { margin: 0; }
	figcaption { font-size: 12px; font-weight: 600; letter-spacing: .06em; text-transform: uppercase; color: #5b6272; margin-bottom: 8px; }
	iframe { display: block; border: 1px solid #dcdfe5; background: #fff; height: 2400px; }
	.desktop iframe { width: <?php echo (int) self::DESKTOP_WIDTH; ?>px; max-width: calc(100vw - 48px); }
	.phone iframe { width: <?php echo (int) self::PHONE_WIDTH; ?>px; }
</style>
</head>
<body>
<header>
	<h1><?php echo esc_html( $title ); ?></h1>
	<p><?php echo esc_html( self::is_private( $data ) ? __( 'Private preview - only its creator and site admins can see it, for ten minutes.', 'wp-marketing-automations-pro' ) : __( 'Private preview - anyone with this link can see it for an hour.', 'wp-marketing-automations-pro' ) ); ?></p>
	<p><a href="<?php echo esc_url( $email ); ?>"><?php esc_html_e( 'Email only', 'wp-marketing-automations-pro' ); ?></a></p>
</header>
<main>
	<figure class="desktop"><figcaption><?php esc_html_e( 'Desktop', 'wp-marketing-automations-pro' ); ?></figcaption><iframe title="<?php esc_attr_e( 'Desktop', 'wp-marketing-automations-pro' ); ?>" sandbox="allow-same-origin allow-popups allow-popups-to-escape-sandbox" srcdoc="<?php echo esc_attr( $data['html'] ); ?>"></iframe></figure>
	<figure class="phone"><figcaption><?php esc_html_e( 'Phone', 'wp-marketing-automations-pro' ); ?></figcaption><iframe title="<?php esc_attr_e( 'Phone', 'wp-marketing-automations-pro' ); ?>" sandbox="allow-same-origin allow-popups allow-popups-to-escape-sandbox" srcdoc="<?php echo esc_attr( $data['html'] ); ?>"></iframe></figure>
</main>
<script><?php echo self::SCRIPT; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- a constant of this class. ?></script>
</body>
</html>
		<?php
	}
}
