<?php

defined( 'ABSPATH' ) || exit;

/**
 * Small edits to a design, addressed by the blocks' uniqueIDs: change a
 * block's attributes, delete, move, duplicate or insert a block - so a
 * client changing one button does not have to send the whole design back.
 * And the outline of a design, which names those ids.
 *
 * Operations apply in order to the tree as the previous one left it, and
 * all or none do: one that cannot apply refuses the lot. Nesting is not
 * judged here; the design is validated as a whole afterwards.
 */
class BWFCRM_Email_Design_Edit {

	const ACTIONS = array( 'update', 'delete', 'move', 'duplicate', 'insert' );

	/** Most operations one call may make. */
	const MAX_OPERATIONS = 50;

	/** Characters of text an outline shows per block. */
	const LABEL_LENGTH = 60;

	/** Attributes an outline reads a block's label from, first found wins. */
	const LABEL_ATTRIBUTES = array( 'content', 'text', 'buttonText', 'title', 'alt', 'heading' );

	/**
	 * @param array[] $tree       The design, rows first.
	 * @param array[] $operations Each { action, uniqueID?, attrs?, block?, parent?, index? }.
	 *
	 * @return array|WP_Error { tree, applied: [{ action, uniqueID, new_uniqueID? }] }, or every operation that cannot apply.
	 */
	public static function apply( array $tree, array $operations ) {
		if ( empty( $operations ) ) {
			return new WP_Error( 'fkmcp_invalid_input', 'Send at least one operation.' );
		}

		if ( count( $operations ) > self::MAX_OPERATIONS ) {
			return new WP_Error( 'fkmcp_invalid_input', sprintf( 'At most %d operations at once.', self::MAX_OPERATIONS ) );
		}

		$taken   = array_flip( self::ids( $tree ) );
		$applied = array();
		$errors  = array();

		foreach ( array_values( $operations ) as $i => $operation ) {
			$operation = is_array( $operation ) ? $operation : array();
			$action    = isset( $operation['action'] ) && is_string( $operation['action'] ) ? $operation['action'] : '';
			$result    = in_array( $action, self::ACTIONS, true )
				? self::$action( $tree, $operation, $taken )
				: new WP_Error( 'fkmcp_invalid_input', 'action must be one of ' . implode( ', ', self::ACTIONS ) . '.' );

			if ( is_wp_error( $result ) ) {
				$errors[] = sprintf( 'operation %d (%s): %s', $i, '' !== $action ? $action : '?', $result->get_error_message() );

				continue;
			}

			$tree      = $result['tree'];
			$applied[] = $result['applied'];
		}

		if ( ! empty( $errors ) ) {
			return new WP_Error( 'fkmcp_invalid_input', 'Nothing was changed: ' . implode( '; ', $errors ) );
		}

		return array(
			'tree'    => $tree,
			'applied' => $applied,
		);
	}

	/**
	 * The design as its blocks' names, uniqueIDs and a short label, nested as
	 * the design is: enough to address an edit without reading every attribute.
	 *
	 * @param array[] $tree
	 *
	 * @return array[] Each { uniqueID, name, label?, blocks? }.
	 */
	public static function outline( array $tree ) {
		$outline = array();

		foreach ( $tree as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			$attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
			$node  = array(
				'uniqueID' => isset( $attrs['uniqueID'] ) && is_scalar( $attrs['uniqueID'] ) ? (string) $attrs['uniqueID'] : null,
				'name'     => isset( $block['name'] ) ? (string) $block['name'] : '',
			);
			$label = self::label( $attrs );

			if ( '' !== $label ) {
				$node['label'] = $label;
			}

			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				$node['blocks'] = self::outline( $block['innerBlocks'] );
			}

			$outline[] = $node;
		}

		return $outline;
	}

	private static function label( array $attrs ) {
		foreach ( self::LABEL_ATTRIBUTES as $key ) {
			if ( ! isset( $attrs[ $key ] ) || ! is_string( $attrs[ $key ] ) ) {
				continue;
			}

			$text = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( $attrs[ $key ] ) ) );

			if ( '' !== $text ) {
				return mb_strlen( $text ) > self::LABEL_LENGTH ? mb_substr( $text, 0, self::LABEL_LENGTH - 1 ) . '…' : $text;
			}
		}

		return '';
	}

	// ─── Operations: each returns { tree, applied } or a WP_Error ─────

	/** Sets the attributes given, whole; an attribute set to null is removed, back to its default. */
	private static function update( array $tree, array $operation, array &$taken ) {
		$path = self::find( $tree, $operation );

		if ( is_wp_error( $path ) ) {
			return $path;
		}

		if ( empty( $operation['attrs'] ) || ! is_array( $operation['attrs'] ) ) {
			return new WP_Error( 'fkmcp_invalid_input', 'update needs attrs: the attributes to set.' );
		}

		$block = self::get( $tree, $path );
		$attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();

		foreach ( $operation['attrs'] as $key => $value ) {
			if ( 'uniqueID' === $key ) {
				continue;
			}

			if ( null === $value ) {
				unset( $attrs[ $key ] );
			} else {
				$attrs[ $key ] = $value;
			}
		}

		$block['attrs'] = $attrs;

		return array(
			'tree'    => self::put( $tree, $path, $block ),
			'applied' => array(
				'action'   => 'update',
				'uniqueID' => $operation['uniqueID'],
			),
		);
	}

	private static function delete( array $tree, array $operation, array &$taken ) {
		$path = self::find( $tree, $operation );

		if ( is_wp_error( $path ) ) {
			return $path;
		}

		return array(
			'tree'    => self::remove( $tree, $path ),
			'applied' => array(
				'action'   => 'delete',
				'uniqueID' => $operation['uniqueID'],
			),
		);
	}

	/** Moves a block into parent (a uniqueID; omitted for the top level) at index (omitted for the end). */
	private static function move( array $tree, array $operation, array &$taken ) {
		$path = self::find( $tree, $operation );

		if ( is_wp_error( $path ) ) {
			return $path;
		}

		$block  = self::get( $tree, $path );
		$parent = isset( $operation['parent'] ) && is_scalar( $operation['parent'] ) ? (string) $operation['parent'] : '';

		if ( '' !== $parent && in_array( $parent, self::ids( array( $block ) ), true ) ) {
			return new WP_Error( 'fkmcp_invalid_input', 'a block cannot move into itself or a block inside it.' );
		}

		$tree = self::remove( $tree, $path );
		$tree = self::place( $tree, $block, $parent, isset( $operation['index'] ) ? $operation['index'] : null );

		if ( is_wp_error( $tree ) ) {
			return $tree;
		}

		return array(
			'tree'    => $tree,
			'applied' => array(
				'action'   => 'move',
				'uniqueID' => $operation['uniqueID'],
			),
		);
	}

	/** Copies a block, with everything in it, right after itself; the copy gets new uniqueIDs. */
	private static function duplicate( array $tree, array $operation, array &$taken ) {
		$path = self::find( $tree, $operation );

		if ( is_wp_error( $path ) ) {
			return $path;
		}

		$copy  = self::renew( self::get( $tree, $path ), $taken );
		$index = array_pop( $path );

		return array(
			'tree'    => self::insert_at( $tree, $path, $index + 1, $copy ),
			'applied' => array(
				'action'       => 'duplicate',
				'uniqueID'     => $operation['uniqueID'],
				'new_uniqueID' => $copy['attrs']['uniqueID'],
			),
		);
	}

	/** Adds block into parent (a uniqueID; omitted for the top level) at index (omitted for the end). */
	private static function insert( array $tree, array $operation, array &$taken ) {
		if ( empty( $operation['block'] ) || ! is_array( $operation['block'] ) || empty( $operation['block']['name'] ) || ! is_string( $operation['block']['name'] ) ) {
			return new WP_Error( 'fkmcp_invalid_input', 'insert needs block: { name, attrs, innerBlocks }.' );
		}

		$block  = self::renew( $operation['block'], $taken );
		$parent = isset( $operation['parent'] ) && is_scalar( $operation['parent'] ) ? (string) $operation['parent'] : '';
		$tree   = self::place( $tree, $block, $parent, isset( $operation['index'] ) ? $operation['index'] : null );

		if ( is_wp_error( $tree ) ) {
			return $tree;
		}

		return array(
			'tree'    => $tree,
			'applied' => array(
				'action'       => 'insert',
				'uniqueID'     => '' !== $parent ? $parent : null,
				'new_uniqueID' => $block['attrs']['uniqueID'],
			),
		);
	}

	// ─── Tree helpers: a path is the list of indexes down to a block ─────

	/** @return int[]|WP_Error The path of the operation's uniqueID. */
	private static function find( array $tree, array $operation ) {
		$id = isset( $operation['uniqueID'] ) && is_scalar( $operation['uniqueID'] ) ? (string) $operation['uniqueID'] : '';

		if ( '' === $id ) {
			return new WP_Error( 'fkmcp_invalid_input', 'uniqueID is required: the block to change, from get-email-template (outline: true lists them).' );
		}

		$path = self::path_of( $tree, $id );

		return null !== $path ? $path : new WP_Error( 'fkmcp_invalid_input', sprintf( 'no block has uniqueID "%s".', $id ) );
	}

	private static function path_of( array $blocks, $id ) {
		foreach ( $blocks as $i => $block ) {
			if ( isset( $block['attrs']['uniqueID'] ) && (string) $block['attrs']['uniqueID'] === $id ) {
				return array( $i );
			}

			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				$inner = self::path_of( $block['innerBlocks'], $id );

				if ( null !== $inner ) {
					return array_merge( array( $i ), $inner );
				}
			}
		}

		return null;
	}

	private static function get( array $tree, array $path ) {
		$index = array_shift( $path );

		return empty( $path ) ? $tree[ $index ] : self::get( $tree[ $index ]['innerBlocks'], $path );
	}

	private static function put( array $tree, array $path, array $block ) {
		$index = array_shift( $path );

		if ( empty( $path ) ) {
			$tree[ $index ] = $block;
		} else {
			$tree[ $index ]['innerBlocks'] = self::put( $tree[ $index ]['innerBlocks'], $path, $block );
		}

		return $tree;
	}

	private static function remove( array $tree, array $path ) {
		$index = array_shift( $path );

		if ( empty( $path ) ) {
			array_splice( $tree, $index, 1 );
		} else {
			$tree[ $index ]['innerBlocks'] = self::remove( $tree[ $index ]['innerBlocks'], $path );
		}

		return $tree;
	}

	/** Inserts block among the children at parent_path (empty for the top level), before position index. */
	private static function insert_at( array $tree, array $parent_path, $index, array $block ) {
		if ( empty( $parent_path ) ) {
			array_splice( $tree, $index, 0, array( $block ) );

			return $tree;
		}

		$head     = array_shift( $parent_path );
		$children = isset( $tree[ $head ]['innerBlocks'] ) && is_array( $tree[ $head ]['innerBlocks'] ) ? $tree[ $head ]['innerBlocks'] : array();

		$tree[ $head ]['innerBlocks'] = self::insert_at( $children, $parent_path, $index, $block );

		return $tree;
	}

	/** Puts block in parent (a uniqueID, '' for the top level) at index: null for the end, clamped to the children there. */
	private static function place( array $tree, array $block, $parent, $index ) {
		$parent_path = array();

		if ( '' !== $parent ) {
			$parent_path = self::path_of( $tree, $parent );

			if ( null === $parent_path ) {
				return new WP_Error( 'fkmcp_invalid_input', sprintf( 'no parent block has uniqueID "%s".', $parent ) );
			}
		}

		$parent_block = empty( $parent_path ) ? null : self::get( $tree, $parent_path );
		$siblings     = null === $parent_block ? $tree : ( isset( $parent_block['innerBlocks'] ) && is_array( $parent_block['innerBlocks'] ) ? $parent_block['innerBlocks'] : array() );
		$count        = count( $siblings );
		$at           = is_numeric( $index ) ? max( 0, min( $count, (int) $index ) ) : $count;

		return self::insert_at( $tree, $parent_path, $at, $block );
	}

	/** A block and everything in it with fresh uniqueIDs, none already in use. */
	private static function renew( array $block, array &$taken ) {
		$attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();

		do {
			$id = substr( md5( wp_generate_password( 12, false, false ) ), 0, 7 );
		} while ( isset( $taken[ $id ] ) );

		$taken[ $id ]      = true;
		$attrs['uniqueID'] = $id;
		$block['attrs']    = $attrs;

		if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
			foreach ( $block['innerBlocks'] as $i => $inner ) {
				$block['innerBlocks'][ $i ] = is_array( $inner ) ? self::renew( $inner, $taken ) : $inner;
			}
		} else {
			$block['innerBlocks'] = array();
		}

		return $block;
	}

	/** Every uniqueID in the blocks, at any depth. */
	private static function ids( array $blocks, array &$ids = array() ) {
		foreach ( $blocks as $block ) {
			if ( isset( $block['attrs']['uniqueID'] ) && is_scalar( $block['attrs']['uniqueID'] ) ) {
				$ids[] = (string) $block['attrs']['uniqueID'];
			}

			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				self::ids( $block['innerBlocks'], $ids );
			}
		}

		return $ids;
	}
}
