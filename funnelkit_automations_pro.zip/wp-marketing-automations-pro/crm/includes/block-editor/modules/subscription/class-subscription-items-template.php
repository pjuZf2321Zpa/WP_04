<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'BWFBE_Subscription_Items_Template' ) ) {
	#[AllowDynamicProperties]
	class BWFBE_Subscription_Items_Template {

		/**
		 * Instance.
		 *
		 * @access private
		 * @var object Instance
		 */
		private static $instance;

		private $responsive_style;

		private $wrapper_selector = '';

		private $tableAttrs = '';

		private $settings = [];

		private $imgSize = null;

		public static $subscription;

		public static $subscription_items;

		public static $is_preview;

		public static $date_format = '';

		public static function get_instance() {
			if ( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			add_shortcode( 'bwfbe_subscription_items', [ $this, 'subscription_items_block' ] );
		}

		/**
		 * Get subscription from merge tag data
		 *
		 * @param array $data Merge tag data.
		 *
		 * @return WC_Subscription|null
		 */
		public function set_subscription_data( $data ) {
			/** Try direct subscription object */
			if ( ! empty( $data['wc_subscription'] ) && $data['wc_subscription'] instanceof WC_Subscription ) {
				return $data['wc_subscription'];
			}

			/** Try subscription ID */
			if ( ! empty( $data['wc_subscription_id'] ) && function_exists( 'wcs_get_subscription' ) ) {
				$subscription = wcs_get_subscription( $data['wc_subscription_id'] );
				if ( $subscription instanceof WC_Subscription ) {
					return $subscription;
				}
			}

			/** Fallback: wc_order might be a WC_Subscription */
			if ( ! empty( $data['wc_order'] ) && $data['wc_order'] instanceof WC_Subscription ) {
				return $data['wc_order'];
			}

			/** Fallback: order_id could be a subscription ID */
			if ( ! empty( $data['order_id'] ) && function_exists( 'wcs_get_subscription' ) ) {
				$subscription = wcs_get_subscription( $data['order_id'] );
				if ( $subscription instanceof WC_Subscription ) {
					return $subscription;
				}
			}

			/** Sublium subscription support */
			$sublium_subscription = $this->get_sublium_subscription( $data );
			if ( null !== $sublium_subscription ) {
				return $sublium_subscription;
			}

			return null;
		}

		/**
		 * Resolve a Sublium subscription object from merge tag data.
		 *
		 * @param array $data Merge tag data.
		 *
		 * @return \Sublium_WCS\Includes\Controller\Subscriptions\Subscription|null
		 */
		public function get_sublium_subscription( $data ) {
			$class = 'Sublium_WCS\Includes\Controller\Subscriptions\Subscription';
			if ( ! class_exists( $class ) ) {
				return null;
			}

			/** Try direct subscription object */
			if ( ! empty( $data['sublium_subscription'] ) && $data['sublium_subscription'] instanceof $class ) {
				return $data['sublium_subscription'];
			}

			/** Try subscription ID */
			$subscription_id = ! empty( $data['sublium_subscription_id'] ) ? $data['sublium_subscription_id'] : '';
			if ( empty( $subscription_id ) ) {
				return null;
			}

			$subscription = new $class( $subscription_id );

			return ( isset( $subscription->exists ) && $subscription->exists ) ? $subscription : null;
		}

		/**
		 * Check whether the resolved subscription is a Sublium subscription object.
		 *
		 * @param mixed $subscription
		 *
		 * @return bool
		 */
		public function is_sublium_subscription( $subscription ) {
			$class = 'Sublium_WCS\Includes\Controller\Subscriptions\Subscription';

			return class_exists( $class ) && $subscription instanceof $class;
		}

		/**
		 * Resolve the payment method display string for a Sublium subscription,
		 * e.g. "visa card ending with 4242". Mirrors Sublium's own
		 * Helpers\Subscription::get_payment_method() output.
		 *
		 * @param \Sublium_WCS\Includes\Controller\Subscriptions\Subscription $subscription
		 *
		 * @return string
		 */
		public function get_sublium_payment_method_title( $subscription ) {
			$helper = 'Sublium_WCS\Includes\Helpers\Subscription';
			if ( class_exists( $helper ) && method_exists( $helper, 'get_payment_method' ) ) {
				$payment_data = $helper::get_payment_method( $subscription );
				if ( ! empty( $payment_data['payment_method_string'] ) ) {
					return $payment_data['payment_method_string'];
				}
			}

			return '-';
		}

		public function subscription_items_block( $atts, $content ) {
			$mergetagdata = BWFAN_Merge_Tag_Loader::get_data();

			if ( ! empty( $mergetagdata['is_engagement'] ) ) {
				return BWFCRM_Block_Editor::get_placeholder( false, __( 'Subscription Items Block', 'wp-marketing-automations-pro' ) );
			}

			self::$is_preview = isset( $mergetagdata['is_preview'] ) && $mergetagdata['is_preview'];

			self::$subscription = ! self::$is_preview ? $this->set_subscription_data( $mergetagdata ) : null;

			if ( ! self::$is_preview && empty( self::$subscription ) ) {
				return '';
			}

			$date_format 	   = get_option( 'date_format' );
			self::$date_format = ! empty( $date_format ) ? $date_format : 'd M, Y';

			if ( ! self::$is_preview && self::$subscription instanceof WC_Subscription ) {
				do_action( 'bwfan_email_setup_locale', BWFAN_Common::get_order_language( self::$subscription ) );
			}

			ob_start();

			$attributes = json_decode( BWFCRM_Block_Editor::decode_content( $content ), true );

			$defaults = [
				'orderInfoAlign'        => [ 'desktop' => 'center' ],
				'padding'               => [
					'desktop' => [
						'top'    => '16',
						'right'  => '16',
						'bottom' => '16',
						'left'   => '16',
						'unit'   => 'px',
					],
					'mobile'  => [
						'top'    => '8',
						'right'  => '8',
						'bottom' => '8',
						'left'   => '8',
						'unit'   => 'px',
					],
				],
				'dividerStyle'          => [ 'desktop' => 'solid' ],
				'uniqueID'              => '',
				'enabledContentOptions' => [
					'desktop' => [ 'orderDate', 'orderId', 'payment', 'image', 'qty' ],
				],
				'orderInfoLabelFont'    => [
					'desktop' => [
						'size' => '12',
					],
				],
				'orderInfoTextFont'     => [
					'desktop' => [
						'size' => '13',
					],
				],
				'commonPriceFont'       => [
					'desktop' => [
						'size' => '14',
					],
					'mobile'  => [
						'size' => '13',
					],
				],
				'productTitleFont'      => [
					'desktop' => [
						'size' => '13',
					],
					'mobile'  => [
						'size' => '12',
					],
				],
				'qtyFont'               => [
					'desktop' => [
						'size' => '14',
					],
					'mobile'  => [
						'size' => '13',
					],
				],
				'pricesMetaFont'        => [
					'desktop' => [
						'size' => '14',
					],
					'mobile'  => [
						'size' => '13',
					],
				],
				'pricesMetaColor'       => [
					'desktop' => '#82838e',
				],
				'discountColor'         => [
					'desktop' => '#09B29C',
				],
				'subTotalPriceFont'     => [
					'desktop' => [
						'size' => '14',
					],
					'mobile'  => [
						'size' => '13',
					],
				],
				'subTotalTextFont'      => [
					'desktop' => [
						'size' => '14',
					],
					'mobile'  => [
						'size' => '13',
					],
				],
				'totalPriceFont'        => [
					'desktop' => [
						'size' => '16',
					],
					'mobile'  => [
						'size' => '13',
					],
				],
				'totalTextFont'         => [
					'desktop' => [
						'size' => '16',
					],
					'mobile'  => [
						'size' => '13',
					],
				],
				'subTotalTextColor'     => [
					'desktop' => '#82838e',
				],
				'productTitleBold'      => [
					'desktop' => true,
				],
				'totalTextBold'         => [
					'desktop' => true,
				],
				'totalPriceBold'        => [
					'desktop' => true,
				],
				'itemImgWidth'          => [
					'desktop' => [
						'value' => '48',
						'unit'  => 'px',
					],
				],
				'qtyLabel'              => __( 'Qty', 'woocommerce' ), // phpcs:ignore WordPress.WP.I18n.TextDomainMismatch
				'subtotalLabel'         => __( 'Subtotal', 'woocommerce' ), // phpcs:ignore WordPress.WP.I18n.TextDomainMismatch
				'shippingLabel'         => __( 'Shipping', 'woocommerce' ), // phpcs:ignore WordPress.WP.I18n.TextDomainMismatch
				'taxesLabel'            => __( 'Taxes', 'woocommerce' ), // phpcs:ignore WordPress.WP.I18n.TextDomainMismatch
				'discountLabel'         => __( 'Discount', 'wp-marketing-automations-pro' ),
				'totalLabel'            => __( 'Total', 'woocommerce' ), // phpcs:ignore WordPress.WP.I18n.TextDomainMismatch
				'imageSize'             => 'thumbnail',
			];

			$this->settings = wp_parse_args( $attributes, $defaults );

			$this->settings['classname'] = [
				'bwfbe-email-order-summary',
				'bwfbe-email-order-summary-' . ( $attributes['uniqueID'] ?? '' ),
			];

			$this->wrapper_selector = '.bwfbe-email-order-summary.bwfbe-email-order-summary-' . $this->settings['uniqueID'];

			$this->tableAttrs = 'cellpadding="0" cellspacing="0" role="presentation" border="0"';

			$this->imgSize = isset( $this->settings['itemImgWidth']['desktop']['value'] ) ? $this->settings['itemImgWidth']['desktop']['value'] : '48';

			if ( ! self::$is_preview ) {
				$this->subscription_summary_html( self::$subscription );
			} else {
				$this->default_subscription_summary_html();
			}

			?>
			<style data-id='woofunnels'>
				.bwfbe-email-order-summary .product-info .product-qty {
					display: none;
					mso-hide: all;
					max-height: 0px;
					overflow: hidden;
				}

				@media only screen and (max-width: 768px) {

					.bwfbe-email-order-summary .order_item td.product-qty-wrap {
						display: none !important;
						mso-hide: all !important;
						max-height: 0px !important;
						overflow: hidden !important;
					}

					.bwfbe-email-order-summary .order_item td.product-price {
						width: 17% !important;
					}

					.bwfbe-email-order-summary .order-meta > table > tbody > tr > td:first-child, .bwfbe-email-order-summary .total > table > tbody > tr > td:first-child {
						width: 60% !important;
					}

					.bwfbe-email-order-summary .order-meta > table > tbody > tr > td:nth-child(2), .bwfbe-email-order-summary .total > table > tbody > tr > td:nth-child(2) {
						width: 40% !important;
					}

				<?php if ( isset( $this->settings['itemImgWidth']['mobile']['value'] ) && ! empty( $this->settings['itemImgWidth']['mobile']['value'] ) ) { ?>
					<?php echo $this->wrapper_selector; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> .product-image,
													<?php echo $this->wrapper_selector; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> .product-image table,
													<?php echo $this->wrapper_selector; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> .product-image img {
														width: <?php echo $this->settings['itemImgWidth']['mobile']['value']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>px !important;
														height: <?php echo $this->settings['itemImgWidth']['mobile']['value']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>px !important;
													}

				<?php } ?>
					.bwfbe-email-order-summary .product-info .product-qty {
						mso-hide: unset !important;
						max-height: unset !important;
						overflow: unset !important;
						display: block !important;
					}

				<?php echo $this->responsive_style; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

				}
			</style>
			<?php
			$this->responsive_style = '';

			return BWFAN_Common::decode_merge_tags( ob_get_clean() );
		}

		/**
		 * Extract subscription data using WC_Subscription methods
		 *
		 * @param WC_Subscription $subscription
		 */
		public function getSubscriptionData( $subscription ) {
			if ( $this->is_sublium_subscription( $subscription ) ) {
				$this->get_sublium_subscription_data( $subscription );

				return;
			}

			$data = [
				'items'    => [],
				'subtotal' => 0,
				'fee'      => [],
				'tax'      => 0,
				'shipping' => 0,
				'coupon'   => 0,
				'currency' => $subscription->get_currency(),
				'total'    => $subscription->get_total(),
			];

			/** Get line items (products) */
			foreach ( $subscription->get_items() as $item_id => $item ) {
				$product = $item->get_product();

				if ( ! $product ) {
					continue;
				}

				/** Get formatted item meta */
				$formatted_meta = [];
				$item_meta      = $item->get_formatted_meta_data( '_', true );
				foreach ( $item_meta as $meta ) {
					$formatted_meta[] = (object) [
						'key'           => $meta->key,
						'value'         => $meta->value,
						'display_key'   => $meta->display_key,
						'display_value' => wpautop( make_clickable( $meta->display_value ) ),
					];
				}

				$data['items'][] = [
					'product_id'     => $product->get_id(),
					'name'           => $item->get_name(),
					'price'          => $item->get_total(),
					'quantity'       => $item->get_quantity(),
					'formatted_meta' => $formatted_meta,
				];

				$data['subtotal'] += $item->get_subtotal();
			}

			/** Get shipping total */
			$data['shipping'] = $subscription->get_shipping_total();

			/** Get tax total */
			$data['tax'] = $subscription->get_total_tax();

			/** Get fees */
			foreach ( $subscription->get_fees() as $fee ) {
				$data['fee'][] = [
					'name'   => $fee->get_name(),
					'amount' => $fee->get_total(),
				];
			}

			/** Get discount total */
			$data['coupon'] = $subscription->get_total_discount();

			self::$subscription_items = $data;
		}

		/**
		 * Extract subscription items data from a Sublium subscription object.
		 *
		 * @param \Sublium_WCS\Includes\Controller\Subscriptions\Subscription $subscription
		 *
		 * @return void
		 */
		public function get_sublium_subscription_data( $subscription ) {
			$currency = $subscription->get_currency();
			$currency = ! empty( $currency ) ? $currency : get_option( 'woocommerce_currency' );

			/**
			 * Use Sublium's own totals breakdown so the tax, shipping, fee and discount
			 * rows match the actual order. Sublium stores these as separate line items
			 * (item_type 2 = shipping, 3 = tax, 4 = fee, 5 = discount) and reconciles
			 * them in calculate_items_totals().
			 */
			$totals = method_exists( $subscription, 'calculate_items_totals' ) ? $subscription->calculate_items_totals() : [];

			/** Sublium stores discount as a negative value; the Discount row uses the abs value */
			$discount = isset( $totals['discount'] ) ? abs( floatval( $totals['discount'] ) ) : 0;

			$data = [
				'items'    => [],
				'subtotal' => isset( $totals['subtotal'] ) ? floatval( $totals['subtotal'] ) : 0,
				'fee'      => [],
				'tax'      => isset( $totals['tax'] ) ? floatval( $totals['tax'] ) : 0,
				'shipping' => isset( $totals['shipping'] ) ? floatval( $totals['shipping'] ) : 0,
				'coupon'   => $discount,
				'currency' => $currency,
				'total'    => isset( $totals['total'] ) ? floatval( $totals['total'] ) : floatval( $subscription->get_totals() ),
			];

			/** Fee line */
			if ( ! empty( $totals['fee'] ) ) {
				$data['fee'][] = [
					'name'   => __( 'Fee', 'wp-marketing-automations-pro' ),
					'amount' => floatval( $totals['fee'] ),
				];
			}

			/** Cancellation discounts as separate named lines (mirrors Sublium's order-total template) */
			if ( ! empty( $totals['cancellation_discounts'] ) && is_array( $totals['cancellation_discounts'] ) ) {
				foreach ( $totals['cancellation_discounts'] as $cancellation_discount ) {
					$data['fee'][] = [
						'name'   => ! empty( $cancellation_discount['name'] ) ? $cancellation_discount['name'] : __( 'Discount', 'wp-marketing-automations-pro' ),
						'amount' => isset( $cancellation_discount['amount'] ) ? floatval( $cancellation_discount['amount'] ) : 0,
					];
				}
			}

			/** Get product line items (item_type 1) */
			$items = $subscription->get_subscription_items( 1 );
			if ( ! empty( $items ) && is_array( $items ) ) {
				foreach ( $items as $item ) {
					$item_data = isset( $item['item_data'] ) ? $item['item_data'] : [];

					/** item_data may be stored as a JSON string */
					if ( is_string( $item_data ) ) {
						$decoded   = json_decode( $item_data, true );
						$item_data = ( JSON_ERROR_NONE === json_last_error() && is_array( $decoded ) ) ? $decoded : [];
					}

					if ( empty( $item_data['product_id'] ) ) {
						continue;
					}

					/** Prefer the variation when present (mirrors Sublium's email block), fall back to the parent */
					$product = ! empty( $item_data['variation_id'] ) ? wc_get_product( $item_data['variation_id'] ) : wc_get_product( $item_data['product_id'] );
					if ( ! $product instanceof WC_Product ) {
						$product = wc_get_product( $item_data['product_id'] );
					}
					if ( ! $product instanceof WC_Product ) {
						continue;
					}

					/** Sublium's email block uses item_data['total'] for the per-line amount */
					$item_total = isset( $item_data['total'] ) ? floatval( $item_data['total'] ) : 0;

					/** Product attribute meta (e.g. Color, Size) — mirrors Sublium's email block */
					$formatted_meta = [];
					$meta_data      = isset( $item_data['meta'] ) && is_array( $item_data['meta'] ) ? $item_data['meta'] : [];
					foreach ( $meta_data as $meta ) {
						if ( ! isset( $meta['key'] ) || ! isset( $meta['value'] ) ) {
							continue;
						}

						$key           = rawurldecode( (string) $meta['key'] );
						$attribute_key = str_replace( 'attribute_', '', $key );
						$display_key   = wc_attribute_label( $attribute_key, $product );
						$display_value = wp_kses_post( $meta['value'] );

						if ( taxonomy_exists( $attribute_key ) ) {
							$term = get_term_by( 'slug', $meta['value'], $attribute_key );
							if ( ! is_wp_error( $term ) && is_object( $term ) && ! empty( $term->name ) ) {
								$display_value = $term->name;
							}
						}

						$formatted_meta[] = (object) [
							'key'           => $meta['key'],
							'value'         => $meta['value'],
							'display_key'   => $display_key,
							'display_value' => wpautop( make_clickable( $display_value ) ),
						];
					}

					/** Plan summary meta, e.g. "5-day free trial, shipped monthly" */
					$plan_summary = isset( $item_data['sublium_wcs_plan_summary'] ) ? (string) $item_data['sublium_wcs_plan_summary'] : '';
					if ( '' !== $plan_summary ) {
						$formatted_meta[] = (object) [
							'key'           => '_sublium_wcs_plan_summary',
							'value'         => $plan_summary,
							'display_key'   => __( 'Plan', 'wp-marketing-automations-pro' ),
							'display_value' => $plan_summary,
						];
					}

					$data['items'][] = [
						'product_id'     => $product->get_id(),
						'name'           => $product->get_name(),
						'price'          => $item_total,
						'quantity'       => isset( $item_data['quantity'] ) ? $item_data['quantity'] : 1,
						'formatted_meta' => $formatted_meta,
					];
				}
			}

			/** Fallback: derive subtotal from line items if Sublium didn't provide one */
			if ( empty( $data['subtotal'] ) && ! empty( $data['items'] ) ) {
				foreach ( $data['items'] as $line ) {
					$data['subtotal'] += floatval( $line['price'] );
				}
			}

			self::$subscription_items = $data;
		}

		public function subscription_summary_html( $subscription ) {
			$this->getSubscriptionData( $subscription );

			$showOrderInfo = $this->is_section_enable( 'orderDate' ) || $this->is_section_enable( 'orderId' ) || $this->is_section_enable( 'payment' );
			$currency      = [ 'currency' => self::$subscription_items['currency'] ];
			remove_all_filters( 'woocommerce_currency_symbol' );
			?>
			<tr>
				<td class="<?php echo implode( ' ', $this->settings['classname'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" style="<?php echo $this->get_block_wrapper_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
					<table <?php echo $this->tableAttrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> style="width:100%">
						<tbody>
						<?php if ( $showOrderInfo && ! empty( $subscription ) ) : ?>
							<tr>
								<td class="order-info" style="<?php echo $this->get_order_info_wrapper_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
									<table class="order-info-container" <?php echo $this->tableAttrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> style="<?php echo $this->get_order_info_container_style( '.order-info > table' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
										<tbody>
										<tr>
											<?php
											$orderInfoItems = [
												[ 'orderDate', 'orderDateLabel', __( 'Subscription Start Date', 'wp-marketing-automations-pro' ), gmdate( 'd F, Y' ) ],
												[ 'orderId', 'orderIdLabel', __( 'Subscription ID', 'wp-marketing-automations-pro' ), '#ABCD1234' ],
												[ 'payment', 'paymentLabel', __( 'Payment', 'woocommerce' ), 'VISA-5902' ], // phpcs:ignore WordPress.WP.I18n.TextDomainMismatch
											];

											$totalInfoItems = array_filter(
												$orderInfoItems,
												function ( $orderInfoItem ) {
													return $this->is_section_enable( $orderInfoItem[0] );
												}
											);
											$width          = count( $totalInfoItems ) === 3 ? '33%' : ( count( $totalInfoItems ) === 2 ? '50%' : '100%' );
											$index          = 0;
											foreach ( $totalInfoItems as $orderInfoItem ) {

												$itemLabel = isset( $this->settings[ $orderInfoItem[1] ] ) && $this->settings[ $orderInfoItem[1] ] !== '' ? $this->settings[ $orderInfoItem[1] ] : $orderInfoItem[2];
												?>
												<td style="vertical-align:top;<?php echo 'width:' . $width . ';' . ( $index !== count( $totalInfoItems ) - 1 ? 'padding: 0 4px 0 0;mso-padding-alt: 0 4px 0 0;' : '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
													<p class="order-info-label" style="<?php echo $this->get_order_info_label_style( '.order-info-label' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
														<?php echo $itemLabel; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
													</p>
													<p class="order-info-text" style="<?php echo $this->get_order_info_text_style( '.order-info-text' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
														<?php
														$is_sublium = $this->is_sublium_subscription( $subscription );
														switch ( $orderInfoItem[1] ) {
															case 'orderDateLabel':
																$start_date = $is_sublium ? $subscription->get_created_at() : $subscription->get_date( 'start' );
																echo ! empty( $start_date ) ? esc_html( date_i18n( 'M d, Y', strtotime( $start_date ) ) ) : '--'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
																break;
															case 'orderIdLabel':
																echo '#' . esc_html( $subscription->get_id() );
																break;
															case 'paymentLabel':
																$payment_title = $is_sublium ? $this->get_sublium_payment_method_title( $subscription ) : ( $subscription->get_payment_method_title() ?: '-' );
																echo esc_html( $payment_title );
																break;
														}
														?>
													</p>

												</td>
												<?php
												++$index;
											}
											?>

										</tr>
										</tbody>
									</table>
								</td>
							</tr>
						<?php endif; ?>
						<?php $this->subscription_summary_items(); ?>

						<tr>
							<td align="<?php echo is_rtl() ? 'right' : 'left'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" class="order-meta" style="padding: 25px 0px; mso-padding-alt: 25px 0px;<?php echo $this->get_block_seperator_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
								<table style="<?php echo $this->get_order_meta_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" <?php echo $this->tableAttrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
									<tbody>
									<tr class="subtotal">
										<td class="subtotal-text" style="width:70%;padding: 0 0 8px; mso-padding-alt: 0 0 8px;">
											<p class="price-text" style="<?php echo $this->get_subtotal_text_style( '.subtotal .price-text' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>"><?php echo $this->settings['subtotalLabel']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
										</td>
										<td align="<?php echo is_rtl() ? 'left' : 'right'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" class="subtotal-price" style="width:30%;padding: 0 0 5px; mso-padding-alt: 0 0 5px;">
											<p class="price" style="<?php echo $this->get_subtotal_price_style( '.subtotal .price' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
												<?php echo wc_price( self::$subscription_items['subtotal'], $currency ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
											</p>
										</td>
									</tr>
									<?php
									$orderPricingInfo = [];
									if ( self::$subscription_items['shipping'] > 0 ) {
										$orderPricingInfo[] = [
											$this->settings['shippingLabel'],
											wc_price( self::$subscription_items['shipping'], $currency ),
										];
									}
									if ( self::$subscription_items['coupon'] > 0 ) {
										$orderPricingInfo[] = [
											$this->settings['discountLabel'],
											'-' . wc_price( self::$subscription_items['coupon'], $currency ),
										];
									}
									if ( self::$subscription_items['fee'] ) {
										foreach ( self::$subscription_items['fee'] as $fee ) {
											$orderPricingInfo[] = [
												$fee['name'],
												wc_price( $fee['amount'], $currency ),
											];
										}
									}
									if ( self::$subscription_items['tax'] > 0 ) {
										$orderPricingInfo[] = [
											$this->settings['taxesLabel'],
											wc_price( self::$subscription_items['tax'], $currency ),
										];
									}
									$index = 0;
									foreach ( $orderPricingInfo as $priceItem ) {
										$padding = count( $orderPricingInfo ) - 1 !== $index ? 'padding: 0px 0px 8px 0px; mso-padding-alt: 0px 0px 8px 0px;' : '';
										?>
										<tr class="prices">
											<td class="price-text-wrap" style="width:70%;<?php echo $padding; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
												<p class="price-text" style="<?php echo $this->get_lineitem_text_style( '.prices .price-text' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
													<?php echo $priceItem[0]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
												</p>
											</td>
											<td class="price-wrap" align="<?php echo is_rtl() ? 'left' : 'right'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" style="width:30%;<?php echo $padding; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
												<p class="price" style="<?php echo $this->get_order_price_style( '.prices .price' ) . ( $this->settings['discountLabel'] === $priceItem[0] ? bwf_css()->getColor( $this->settings, 'discountColor', 'desktop' ) : '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
													<?php echo $priceItem[1]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
												</p>

											</td>
										</tr>
										<?php
										++$index;
									}
									?>
									</tbody>

								</table>

							</td>
						</tr>

						<tr>
							<td class="total" style="padding: 16px 0px 0px; mso-padding-alt: 16px 0px 0px;">
								<table align="<?php echo is_rtl() ? 'right' : 'left'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" <?php echo $this->tableAttrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> style="width:100%;<?php echo $this->get_order_meta_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
									<tbody>
									<tr class="total">
										<td class="total-text-wrap" style="width:60%;">
											<p class="price-text" style="<?php echo $this->get_total_text_style( '.total .price-text' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>"><?php echo $this->settings['totalLabel']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
										</td>
										<td class="total-price-wrap" align="<?php echo is_rtl() ? 'left' : 'right'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" style="width:40%;">
											<p class="price" style="<?php echo $this->get_total_price_style( '.total .price' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
												<?php echo wc_price( self::$subscription_items['total'], $currency ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
											</p>
										</td>
									</tr>
									</tbody>

								</table>

							</td>
						</tr>
						</tbody>
					</table>
				</td>
			</tr>
			<?php
		}

		public function subscription_summary_items() {
			$order_items = self::$subscription_items['items'];
			$show_image  = $this->is_section_enable( 'image' );
			$size        = apply_filters( 'bwfan_wcs_alter_product_image_size', $this->settings['imageSize'] );
			$currency    = [ 'currency' => self::$subscription_items['currency'] ];
			foreach ( $order_items as $item ) :
				$product = $item['product_id'] ? wc_get_product( $item['product_id'] ) : null;

				if ( ! apply_filters( 'bwfan_wcs_order_item_visible', true, $item ) ) {
					continue;
				}

				$image_url = '';
				if ( is_object( $product ) ) {
					$image_url = BWFAN_Common::get_product_image_url( $product, $size );
				}

				if ( empty( $image_url ) ) {
					$image_url = BWFCRM_Block_Editor::get_product_placeholder();
				}
				$image = '<img src="' . esc_url( $image_url ) . '" height="' . $this->imgSize . '" width="' . $this->imgSize . '" style="border-radius:8px;height:' . $this->imgSize . 'px;width:' . $this->imgSize . 'px;' . ( $size !== 'thumbnail' ? 'object-fit:contain;' : '' ) . '" />';
				?>
				<tr>
					<td class="<?php echo esc_attr( apply_filters( 'bwfan_subscription_item_class', 'subscription_item', $item ) ); ?>" style="<?php echo $this->get_item_wrap_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
						<table <?php echo $this->tableAttrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> style="width: 100%">
							<tbody>
							<tr>
								<?php if ( $show_image ) : ?>
									<td class="product-image" align="center" width="<?php echo $this->imgSize; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" style="width:<?php echo $this->imgSize; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>px">
										<table style="width:<?php echo $this->imgSize; ?>px;" <?php echo $this->tableAttrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
											<tr>
												<td align="center" style="border: 0;border-radius:8px;" width="<?php echo $this->imgSize; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" height="<?php echo $this->imgSize; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
													<?php echo wp_kses_post( apply_filters( 'bwfan_order_item_thumbnail', $image, $item ) ); ?>
												</td>
											</tr>
										</table>
									</td>
								<?php endif; ?>

								<?php
								$item_meta_style     = 'padding-right:4px;width:auto;' . ( $show_image ? 'padding-left:10px; mso-padding-alt:0px 4px 0px 10px;' : 'mso-padding-alt:0px 4px 0px 0px;' );
								$item_meta_style_rtl = 'padding-left:4px;width:auto;' . ( $show_image ? 'padding-right:10px; mso-padding-alt:0px 10px 0px 4px;' : 'mso-padding-alt:0px 0px 0px 4px;' );
								?>
								<td align="<?php echo is_rtl() ? 'right' : 'left'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" class="product-info" style="<?php echo is_rtl() ? $item_meta_style_rtl : $item_meta_style; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
									<p class="product-title" style="<?php echo $this->get_item_title_style( '.product-info .product-title' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
										<?php echo wp_kses_post( apply_filters( 'bwfan_order_item_name', $item['name'], $item, false ) ); ?>
									</p>

									<?php
									foreach ( $item['formatted_meta'] as $meta ) {
										$value = wp_kses_post( make_clickable( trim( $meta->display_value ) ) );
										$label = wp_kses_post( $meta->display_key );
										$html  = apply_filters( 'bwfan_display_item_meta', $label . ': ' . wp_strip_all_tags( $value ), $meta );
										?>
										<p class="product-meta" style="<?php echo $this->get_item_meta_style( '.product-info .product-meta ' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
											<?php echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
										</p>
										<?php
									}
									?>

									<?php if ( $this->is_section_enable( 'qty' ) ) : ?>
								<td class="product-qty-wrap" style="width:15%;">
									<p class="product-qty" style="<?php echo $this->get_item_qty_style( '.product-qty' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
										<?php
										echo $this->settings['qtyLabel'] . ' '; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
										$qty         = $item['quantity'];
										$qty_display = esc_html( $qty );
										echo wp_kses_post( apply_filters( 'bwfan_email_subscription_item_quantity', $qty_display, $item ) );
										?>
									</p>
								</td>
							<?php endif; ?>
					</td>
					<td class="product-price" style="width:15%;" align="<?php echo is_rtl() ? 'left' : 'right'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
						<p style="<?php echo $this->get_order_price_style( '.product-price p' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
							<?php echo wc_price( $item['price'], $currency ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</p>
					</td>
				</tr>

				</tbody>
				</table>
				</td>
				</tr>

				<?php
			endforeach;
		}

		public function default_subscription_summary_html() {

			$showOrderInfo    = $this->is_section_enable( 'orderDate' ) || $this->is_section_enable( 'orderId' ) || $this->is_section_enable( 'payment' );
			$showProductImage = $this->is_section_enable( 'image' );
			$dummy_product    = [
				[
					'id'        => 1,
					'title'     => __( 'Here is the product title', 'wp-marketing-automations-pro' ),
					'price'     => wc_price( '50' ),
					'meta_data' => __( 'Black, 32', 'wp-marketing-automations-pro' ),
					'qty'       => 1,
				],
			];
			?>
			<tr>
				<td class="<?php echo implode( ' ', $this->settings['classname'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" style="<?php echo $this->get_block_wrapper_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
					<table <?php echo $this->tableAttrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> style="width:100%">
						<tbody>
						<?php if ( $showOrderInfo ) : ?>
							<tr>
								<td class="order-info" style="<?php echo $this->get_order_info_wrapper_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
									<table class="order-info-container" <?php echo $this->tableAttrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> style="<?php echo $this->get_order_info_container_style( '.order-info > table' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
										<tbody>
										<tr>
											<?php
											$orderInfoItems = [
												[ 'orderDate', 'orderDateLabel', __( 'Subscription Start Date', 'wp-marketing-automations-pro' ), gmdate( 'd F, Y' ) ],
												[ 'orderId', 'orderIdLabel', __( 'Subscription ID', 'wp-marketing-automations-pro' ), '#ABCD1234' ],
												[ 'payment', 'paymentLabel', __( 'Payment', 'woocommerce' ), 'VISA-5902' ], // phpcs:ignore WordPress.WP.I18n.TextDomainMismatch
											];
											$totalInfoItems = array_filter(
												$orderInfoItems,
												function ( $orderInfoItem ) {
													return $this->is_section_enable( $orderInfoItem[0] );
												}
											);
											$width          = count( $totalInfoItems ) === 3 ? '33%' : ( count( $totalInfoItems ) === 2 ? '50%' : '100%' );
											$index          = 0;
											foreach ( $totalInfoItems as $orderInfoItem ) {
												$itemLabel = isset( $this->settings[ $orderInfoItem[1] ] ) && $this->settings[ $orderInfoItem[1] ] !== '' ? $this->settings[ $orderInfoItem[1] ] : $orderInfoItem[2];
												?>

												<td style="vertical-align:top;<?php echo 'width:' . $width . ';' . ( $index !== count( $totalInfoItems ) - 1 ? 'padding: 0 4px 0 0;mso-padding-alt: 0 4px 0 0;' : '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
													<p class="order-info-label" style="<?php echo $this->get_order_info_label_style( '.order-info-label' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
														<?php echo $itemLabel; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
													</p>
													<p class="order-info-text" style="<?php echo $this->get_order_info_text_style( '.order-info-text' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
														<?php echo $orderInfoItem[3]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
													</p>

												</td>
												<?php
												++$index;
											}
											?>

										</tr>
										</tbody>
									</table>
								</td>
							</tr>
							<?php
						endif;

						foreach ( $dummy_product as $product ) {
							?>
							<tr>
								<td class="order_item" style="<?php echo $this->get_item_wrap_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
									<table <?php echo $this->tableAttrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> style="width: 100%">
										<tbody>
										<tr>
											<?php if ( $showProductImage ) : ?>
												<td class="product-image" width="<?php echo $this->imgSize; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" align="center" style="width:<?php echo $this->imgSize; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>px">
													<table style="width:<?php echo $this->imgSize; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>px" <?php echo $this->tableAttrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
														<tr>
															<td align="center" style="border-radius:8px;">
																<img height="<?php echo $this->imgSize; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" width="<?php echo $this->imgSize; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" src="<?php echo BWFCRM_Block_Editor::get_product_placeholder(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" alt="product" style="height: <?php echo $this->imgSize; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>px;width: <?php echo $this->imgSize; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>px;border-radius:8px;"/>
															</td>
														</tr>
													</table>

												</td>
											<?php endif; ?>

											<?php
											$item_meta_style = 'padding-right:4px;width:70%;' . ( $showProductImage ? 'padding-left:10px; mso-padding-alt:0px 4px 0px 10px;' : 'mso-padding-alt:0px 4px 0px 0px;' );

											$item_meta_style_rtl = 'padding-left:4px;width:70%;' . ( $showProductImage ? 'padding-right:10px; mso-padding-alt:0px 10px 0px 4px;' : 'mso-padding-alt:0px 0px 0px 4px;' );
											?>
											<td align="<?php echo is_rtl() ? 'right' : 'left'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" class="product-info" style="<?php echo is_rtl() ? $item_meta_style_rtl : $item_meta_style; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
												<p class="product-title" style="<?php echo $this->get_item_title_style( '.product-info .product-title' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>"><?php echo $product['title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
												<p class="product-meta" style="<?php echo $this->get_item_meta_style( '.product-info .product-meta ' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>"><?php echo $product['meta_data']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
												<?php if ( $this->is_section_enable( 'qty' ) ) : ?>
													<p class="product-qty" style="<?php echo $this->get_item_qty_style( '.product-qty' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
														<?php echo $this->settings['qtyLabel'] . ' ' . $product['qty']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
													</p>
												<?php endif; ?>
											</td>
											<?php if ( $this->is_section_enable( 'qty' ) ) : ?>
												<td class="product-qty-wrap" style="width:15%;">
													<p style="<?php echo $this->get_item_qty_style( '.product-qty' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
														<?php
														echo $this->settings['qtyLabel'] . ' ' . $product['qty']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
														?>
													</p>
												</td>
											<?php endif; ?>

											<td class="product-price" style="width:15%;" align="<?php echo is_rtl() ? 'left' : 'right'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
												<p style="<?php echo $this->get_order_price_style( '.product-price p' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>"><?php echo $product['price']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
											</td>
										</tr>
										</tbody>
									</table>
								</td>
							</tr>
							<?php
						}
						?>
						<tr>
							<td align="<?php echo is_rtl() ? 'right' : 'left'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" class="order-meta" style="padding: 24px 0; mso-padding-alt: 24px 0;<?php echo $this->get_block_seperator_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
								<table style="<?php echo $this->get_order_meta_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" <?php echo $this->tableAttrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
									<tbody>
									<tr class="subtotal">
										<td class="subtotal-text" style="width:70%;padding: 0 0 5px; mso-padding-alt: 0 0 5px;">
											<p class="price-text" style="<?php echo $this->get_subtotal_text_style( '.subtotal .price-text' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>"><?php echo $this->settings['subtotalLabel']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
										</td>
										<td align="<?php echo is_rtl() ? 'left' : 'right'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" class="subtotal-price" style="width:30%;padding: 0 0 5px; mso-padding-alt: 0 0 5px;">
											<p class="price" style="<?php echo $this->get_subtotal_price_style( '.subtotal .price' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>"><?php echo wc_price( 10.00 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
										</td>
									</tr>
									<?php
									$orderPricingInfo = [
										[ $this->settings['shippingLabel'], wc_price( 7.00 ) ],
										[ $this->settings['taxesLabel'], wc_price( 5.00 ) ],
										[ $this->settings['discountLabel'], '-' . wc_price( 10.00 ) ],
									];
									$index            = 0;
									foreach ( $orderPricingInfo as $priceItem ) {
										$padding = count( $orderPricingInfo ) - 1 !== $index ? 'padding: 0px 0px 8px 0px; mso-padding-alt: 0px 0px 8px 0px;' : '';
										?>
										<tr class="prices">
											<td class="price-text-wrap" style="width:70%;<?php echo $padding; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
												<p class="price-text" style="<?php echo $this->get_lineitem_text_style( '.prices .price-text' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
													<?php echo $priceItem[0]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
												</p>
											</td>
											<td align="<?php echo is_rtl() ? 'left' : 'right'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" class="price-wrap" style="width:30%;<?php echo $padding; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
												<p class="price" style="<?php echo $this->get_order_price_style( '.prices .price' ) . ( $this->settings['discountLabel'] === $priceItem[0] ? bwf_css()->getColor( $this->settings, 'discountColor', 'desktop' ) : '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
													<?php echo $priceItem[1]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
												</p>

											</td>
										</tr>
										<?php
										++$index;
									}
									?>
									</tbody>

								</table>

							</td>
						</tr>

						<tr>
							<td class="total" style="padding: 16px 0px 0px; mso-padding-alt: 16px 0px 0px;">
								<table align="<?php echo is_rtl() ? 'right' : 'left'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" <?php echo $this->tableAttrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> style="width:100%;<?php echo $this->get_order_meta_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
									<tbody>
									<tr class="total">
										<td class="total-text-wrap" style="width:70%;">
											<p class="price-text" style="<?php echo $this->get_total_text_style( '.total .price-text' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>"><?php echo $this->settings['totalLabel']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
										</td>
										<td class="total-price-wrap" align="<?php echo is_rtl() ? 'left' : 'right'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" style="width:30%;">
											<p class="price" style="<?php echo $this->get_total_price_style( '.total .price' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>"><?php echo wc_price( 52.00 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
										</td>
									</tr>
									</tbody>

								</table>

							</td>
						</tr>
						</tbody>
					</table>
				</td>
			</tr>
			<?php
		}

		public function is_section_enable( $section = '', $screen = 'desktop' ) {
			$section_enabled = isset( $this->settings['enabledContentOptions'][ $screen ] ) ? $this->settings['enabledContentOptions'][ $screen ] : [];

			return ( in_array( $section, $section_enabled, true ) );
		}

		/**
		 * Get Block Container style
		 */
		private function get_block_wrapper_style() {
			$style  = 'word-break:break-word;';
			$style .= bwf_css()->getPadding( $this->settings, 'padding', 'desktop' );
			$style .= bwf_css()->getMsoPadding( $this->settings, 'padding', 'desktop' );
			$style .= bwf_css()->getVisibilityCss( $this->settings, 'desktop' );

			if ( $this->wrapper_selector ) {
				$mStyle                  = bwf_css()->getPadding( $this->settings, 'padding', 'mobile', true );
				$mStyle                 .= bwf_css()->getVisibilityCss( $this->settings, 'mobile' );
				$this->responsive_style .= sprintf( '%1$s {%2$s}', $this->wrapper_selector, $mStyle );
			}

			return $style;
		}

		/**
		 * Get order info wrapper style
		 */
		private function get_order_info_wrapper_style() {
			$style  = 'padding: 24px 0px 24px;';
			$style .= 'mso-padding-alt: 24px 0px 24px;';
			$style .= $this->get_block_seperator_style( 'top' );
			$style .= $this->get_block_seperator_style( 'bottom' );

			return $style;
		}

		private function get_order_info_container_style( $classname = '' ) {
			$style  = 'width:100%;';
			$style .= bwf_css()->textAlign( $this->settings, 'orderInfoAlign', 'desktop' );

			if ( $this->wrapper_selector && $classname ) {
				$mStyle                  = bwf_css()->textAlign( $this->settings, 'orderInfoAlign', 'mobile', true );
				$this->responsive_style .= sprintf( '%1$s %2$s {%3$s}', $this->wrapper_selector, $classname, $mStyle );
			}

			return $style;
		}

		/**
		 * Get separator style
		 */
		private function get_block_seperator_style( $pos = 'bottom' ) {
			$dividerColor = isset( $this->settings['dividerColor']['desktop'] ) ? $this->settings['dividerColor']['desktop'] : '';
			$dividerStyle = isset( $this->settings['dividerStyle']['desktop'] ) ? $this->settings['dividerStyle']['desktop'] : '';

			if ( 'none' === $dividerStyle ) {
				return '';
			}

			return sprintf( 'border-%1$s: 1px %2$s %3$s;', $pos, $dividerStyle, $dividerColor );
		}

		/**
		 * Get order info label style
		 */
		private function get_order_info_label_style( $classname = '' ) {
			$defaulStyle = $this->get_default_style();
			$style       = 'color: #a5abb6;';
			$style      .= $defaulStyle['text-style'];
			$style      .= bwf_css()->getFontSize( $this->settings, 'orderInfoLabelFont', 'desktop', false, $defaulStyle['font-size'] );
			$style      .= bwf_css()->getColor( $this->settings, 'orderInfoLabelColor', 'desktop' );
			$style      .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'desktop' );

			if ( ! empty( $classname ) ) {
				$mStyle                  = bwf_css()->getFontSize( $this->settings, 'orderInfoLabelFont', 'mobile', true );
				$mStyle                 .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'mobile', true );
				$this->responsive_style .= sprintf( '%1$s %2$s {%3$s}', $this->wrapper_selector, $classname, $mStyle );
			}

			return $style;
		}

		/**
		 * Get order info text style
		 */
		private function get_order_info_text_style( $classname = '' ) {
			$defaulStyle = $this->get_default_style();
			$style       = $defaulStyle['text-style'];
			$style      .= bwf_css()->getFontSize( $this->settings, 'orderInfoTextFont', 'desktop', false, $defaulStyle['font-size'] );
			$style      .= bwf_css()->getColor( $this->settings, 'orderInfoTextColor', 'desktop' );
			$style      .= bwf_css()->getBold( $this->settings, 'orderInfoTextBold', 'desktop' );
			$style      .= bwf_css()->getItalic( $this->settings, 'orderInfoTextItalic', 'desktop' );
			$style      .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'desktop' );

			if ( ! empty( $classname ) ) {
				$mStyle                  = bwf_css()->getFontSize( $this->settings, 'orderInfoTextFont', 'mobile', true );
				$mStyle                 .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'mobile', true );
				$this->responsive_style .= sprintf( '%1$s %2$s {%3$s}', $this->wrapper_selector, $classname, $mStyle );
			}

			return $style;
		}

		/**
		 * Get order item wrapper style
		 */
		private function get_item_wrap_style() {
			$style  = 'padding:20px 0px; mso-padding-alt: 20px 0px;';
			$style .= $this->get_block_seperator_style();

			return $style;
		}

		private function get_item_title_style( $classname ) {
			$defaulStyle = $this->get_default_style();
			$style       = '';
			$style      .= $defaulStyle['text-style'];
			$style      .= bwf_css()->getFontSize( $this->settings, 'productTitleFont', 'desktop', false, $defaulStyle['font-size'] );
			$style      .= bwf_css()->getColor( $this->settings, 'productTitleColor', 'desktop' );
			$style      .= bwf_css()->getBold( $this->settings, 'productTitleBold', 'desktop' );
			$style      .= bwf_css()->getItalic( $this->settings, 'productTitleItalic', 'desktop' );
			$style      .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'desktop' );

			if ( ! empty( $classname ) ) {
				$mStyle                  = bwf_css()->getFontSize( $this->settings, 'productTitleFont', 'mobile', true );
				$mStyle                 .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'mobile', true );
				$this->responsive_style .= sprintf( '%1$s %2$s {%3$s}', $this->wrapper_selector, $classname, $mStyle );
			}

			return $style;
		}

		private function get_item_meta_style( $classname ) {
			$defaulStyle = $this->get_default_style();
			$style       = 'color: #8c8f94;';
			$style      .= $defaulStyle['text-style'];
			$style      .= bwf_css()->getFontSize( $this->settings, 'productMetaFont', 'desktop', false, $defaulStyle['font-size'] );
			$style      .= bwf_css()->getColor( $this->settings, 'productMetaColor', 'desktop' );
			$style      .= bwf_css()->getBold( $this->settings, 'productMetaBold', 'desktop' );
			$style      .= bwf_css()->getItalic( $this->settings, 'productMetaItalic', 'desktop' );
			$style      .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'desktop' );

			if ( ! empty( $classname ) ) {
				$mStyle                  = bwf_css()->getFontSize( $this->settings, 'productMetaFont', 'mobile', true );
				$mStyle                 .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'mobile', true );
				$this->responsive_style .= sprintf( '%1$s %2$s {%3$s}', $this->wrapper_selector, $classname, $mStyle );
			}

			return $style;
		}

		private function get_item_qty_style( $classname = '' ) {
			$defaulStyle = $this->get_default_style();
			$style       = $defaulStyle['text-style'];
			$style      .= bwf_css()->getFontSize( $this->settings, 'qtyFont', 'desktop', false, $defaulStyle['font-size'] );
			$style      .= bwf_css()->getColor( $this->settings, 'qtyColor', 'desktop' );
			$style      .= bwf_css()->getBold( $this->settings, 'qtyBold', 'desktop' );
			$style      .= bwf_css()->getItalic( $this->settings, 'qtyItalic', 'desktop' );
			$style      .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'desktop' );

			if ( ! empty( $classname ) ) {
				$mStyle                  = bwf_css()->getFontSize( $this->settings, 'qtyFont', 'mobile', true );
				$mStyle                 .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'mobile', true );
				$this->responsive_style .= sprintf( '%1$s %2$s {%3$s}', $this->wrapper_selector, $classname, $mStyle );
			}

			return $style;
		}

		private function get_order_price_style( $classname ) {
			$defaulStyle = $this->get_default_style();
			$style       = $defaulStyle['text-style'];
			$style      .= bwf_css()->getFontSize( $this->settings, 'commonPriceFont', 'desktop', false, $defaulStyle['font-size'] );
			$style      .= bwf_css()->getColor( $this->settings, 'commonPriceColor', 'desktop' );
			$style      .= bwf_css()->getBold( $this->settings, 'commonPriceBold', 'desktop' );
			$style      .= bwf_css()->getItalic( $this->settings, 'commonPriceItalic', 'desktop' );
			$style      .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'desktop' );

			if ( ! empty( $classname ) ) {
				$mStyle                  = bwf_css()->getFontSize( $this->settings, 'commonPriceFont', 'mobile', true );
				$mStyle                 .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'mobile', true );
				$this->responsive_style .= sprintf( '%1$s %2$s {%3$s}', $this->wrapper_selector, $classname, $mStyle );
			}

			return $style;
		}

		private function get_subtotal_text_style( $classname ) {
			$defaulStyle = $this->get_default_style();
			$style       = $defaulStyle['text-style'];
			$style      .= bwf_css()->getFontSize( $this->settings, 'subTotalTextFont', 'desktop', false, $defaulStyle['font-size'] );
			$style      .= bwf_css()->getColor( $this->settings, 'subTotalTextColor', 'desktop' );
			$style      .= bwf_css()->getBold( $this->settings, 'subTotalTextBold', 'desktop' );
			$style      .= bwf_css()->getItalic( $this->settings, 'subTotalTextItalic', 'desktop' );
			$style      .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'desktop' );

			if ( ! empty( $classname ) ) {
				$mStyle                  = bwf_css()->getFontSize( $this->settings, 'subTotalTextFont', 'mobile', true );
				$mStyle                 .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'mobile', true );
				$this->responsive_style .= sprintf( '%1$s %2$s {%3$s}', $this->wrapper_selector, $classname, $mStyle );
			}

			return $style;
		}

		private function get_subtotal_price_style( $classname ) {
			$defaulStyle = $this->get_default_style();
			$style       = $defaulStyle['text-style'];
			$style      .= bwf_css()->getFontSize( $this->settings, 'subTotalPriceFont', 'desktop', false, $defaulStyle['font-size'] );
			$style      .= bwf_css()->getColor( $this->settings, 'subTotalPriceColor', 'desktop' );
			$style      .= bwf_css()->getBold( $this->settings, 'subTotalPriceBold', 'desktop' );
			$style      .= bwf_css()->getItalic( $this->settings, 'subTotalPriceItalic', 'desktop' );
			$style      .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'desktop' );

			if ( ! empty( $classname ) ) {
				$mStyle                  = bwf_css()->getFontSize( $this->settings, 'subTotalPriceFont', 'mobile', true );
				$mStyle                 .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'mobile', true );
				$this->responsive_style .= sprintf( '%1$s %2$s {%3$s}', $this->wrapper_selector, $classname, $mStyle );
			}

			return $style;
		}

		private function get_lineitem_text_style( $classname ) {
			$defaulStyle = $this->get_default_style();
			$style       = $defaulStyle['text-style'];
			$style      .= bwf_css()->getFontSize( $this->settings, 'pricesMetaFont', 'desktop', false, $defaulStyle['font-size'] );
			$style      .= bwf_css()->getColor( $this->settings, 'pricesMetaColor', 'desktop' );
			$style      .= bwf_css()->getBold( $this->settings, 'pricesMetaBold', 'desktop' );
			$style      .= bwf_css()->getItalic( $this->settings, 'pricesMetaItalic', 'desktop' );
			$style      .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'desktop' );

			if ( ! empty( $classname ) ) {
				$mStyle                  = bwf_css()->getFontSize( $this->settings, 'pricesMetaFont', 'mobile', true );
				$mStyle                 .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'mobile', true );
				$this->responsive_style .= sprintf( '%1$s %2$s {%3$s}', $this->wrapper_selector, $classname, $mStyle );
			}

			return $style;
		}

		private function get_total_text_style( $classname ) {
			$defaulStyle = $this->get_default_style();
			$style       = $defaulStyle['text-style'];
			$style      .= bwf_css()->getFontSize( $this->settings, 'totalTextFont', 'desktop', false, $defaulStyle['font-size'] );
			$style      .= bwf_css()->getColor( $this->settings, 'totalTextColor', 'desktop' );
			$style      .= bwf_css()->getBold( $this->settings, 'totalTextBold', 'desktop' );
			$style      .= bwf_css()->getItalic( $this->settings, 'totalTextItalic', 'desktop' );
			$style      .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'desktop' );

			if ( ! empty( $classname ) ) {
				$mStyle                  = bwf_css()->getFontSize( $this->settings, 'totalTextFont', 'mobile', true );
				$mStyle                 .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'mobile', true );
				$this->responsive_style .= sprintf( '%1$s %2$s {%3$s}', $this->wrapper_selector, $classname, $mStyle );
			}

			return $style;
		}

		private function get_total_price_style( $classname ) {
			$defaulStyle = $this->get_default_style();
			$style       = $defaulStyle['text-style'];
			$style      .= bwf_css()->getFontSize( $this->settings, 'totalPriceFont', 'desktop', false, $defaulStyle['font-size'] );
			$style      .= bwf_css()->getColor( $this->settings, 'totalPriceColor', 'desktop' );
			$style      .= bwf_css()->getBold( $this->settings, 'totalPriceBold', 'desktop' );
			$style      .= bwf_css()->getItalic( $this->settings, 'totalPriceItalic', 'desktop' );
			$style      .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'desktop' );

			if ( ! empty( $classname ) ) {
				$mStyle                  = bwf_css()->getFontSize( $this->settings, 'totalPriceFont', 'mobile', true );
				$mStyle                 .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'mobile', true );
				$this->responsive_style .= sprintf( '%1$s %2$s {%3$s}', $this->wrapper_selector, $classname, $mStyle );
			}

			return $style;
		}

		private function get_order_meta_style( $classname = '.order-meta' ) {
			$style  = 'width:100%;';
			$style .= bwf_css()->textAlign( $this->settings, 'orderMetaAlign', 'desktop', false, is_rtl() ? 'text-align:right;' : '' );

			if ( ! empty( $classname ) ) {
				$mStyle                  = bwf_css()->textAlign( $this->settings, 'orderMetaAlign', 'mobile', true );
				$this->responsive_style .= sprintf( '%1$s .order-meta > table, %1$s .total > table {%2$s}', $this->wrapper_selector, $mStyle );
			}

			return $style;
		}

		/**
		 * Block default and common style
		 */
		private function get_default_style( $type = '' ) {
			$defaultStyle = [
				'font-size'   => 'font-size:16px;',
				'font-family' => bwf_css()->getFontFamily( $this->settings ),
				'text-style'  => 'margin:0;line-height: 1.5;' . bwf_css()->getFontFamily( $this->settings ),
				'color'       => bwf_css()->getColor( $this->settings, 'color', 'desktop' ),
			];

			if ( ! empty( $type ) && is_string( $type ) ) {
				return $defaultStyle[ $type ];
			}

			return $defaultStyle;
		}
	}

	BWFBE_Subscription_Items_Template::get_instance();
}
