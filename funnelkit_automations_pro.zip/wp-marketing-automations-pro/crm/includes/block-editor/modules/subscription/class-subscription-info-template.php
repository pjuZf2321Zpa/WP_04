<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'BWFBE_Subscription_Info_Template' ) ) {
	#[AllowDynamicProperties]
	class BWFBE_Subscription_Info_Template {

		/**
		 * Instance.
		 *
		 * @access private
		 * @var object Instance
		 */
		private static $instance;

		private $responsive_style;

		private $wrapper_selector = '';

		private $tableAttrs = '';

		private $settings = [];

		public static $subscription;

		public static $is_preview;

		public static function get_instance() {
			if ( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			add_shortcode( 'bwfbe_subscription_info', [ $this, 'subscription_info_block' ] );
		}

		/**
		 * Get subscription from merge tag data
		 *
		 * @param array $data Merge tag data.
		 *
		 * @return WC_Subscription|\Sublium_WCS\Includes\Controller\Subscriptions\Subscription|null
		 */
		public function set_subscription( $data ) {
			/** Try direct subscription object */
			if ( ! empty( $data['wc_subscription'] ) && $data['wc_subscription'] instanceof WC_Subscription ) {
				return $data['wc_subscription'];
			}

			/** Try subscription ID */
			if ( ! empty( $data['wc_subscription_id'] ) && function_exists( 'wcs_get_subscription' ) ) {
				$subscription = wcs_get_subscription( $data['wc_subscription_id'] );
				if ( $subscription instanceof WC_Subscription ) {
					return $subscription;
				}
			}

			/** Fallback: wc_order might be a WC_Subscription (since WC_Subscription extends WC_Order) */
			if ( ! empty( $data['wc_order'] ) && $data['wc_order'] instanceof WC_Subscription ) {
				return $data['wc_order'];
			}

			/** Fallback: order_id could be a subscription ID */
			if ( ! empty( $data['order_id'] ) && function_exists( 'wcs_get_subscription' ) ) {
				$subscription = wcs_get_subscription( $data['order_id'] );
				if ( $subscription instanceof WC_Subscription ) {
					return $subscription;
				}
			}

			/** Sublium subscription support */
			$sublium_subscription = $this->get_sublium_subscription( $data );
			if ( null !== $sublium_subscription ) {
				return $sublium_subscription;
			}

			return null;
		}

		/**
		 * Resolve a Sublium subscription object from merge tag data.
		 *
		 * @param array $data Merge tag data.
		 *
		 * @return \Sublium_WCS\Includes\Controller\Subscriptions\Subscription|null
		 */
		public function get_sublium_subscription( $data ) {
			$class = 'Sublium_WCS\Includes\Controller\Subscriptions\Subscription';
			if ( ! class_exists( $class ) ) {
				return null;
			}

			/** Try direct subscription object */
			if ( ! empty( $data['sublium_subscription'] ) && $data['sublium_subscription'] instanceof $class ) {
				return $data['sublium_subscription'];
			}

			/** Try subscription ID */
			$subscription_id = ! empty( $data['sublium_subscription_id'] ) ? $data['sublium_subscription_id'] : '';
			if ( empty( $subscription_id ) ) {
				return null;
			}

			$subscription = new $class( $subscription_id );

			return ( isset( $subscription->exists ) && $subscription->exists ) ? $subscription : null;
		}

		public function subscription_info_block( $atts, $content ) {
			$mergetagdata = BWFAN_Merge_Tag_Loader::get_data();

			if ( ! empty( $mergetagdata['is_engagement'] ) ) {
				return BWFCRM_Block_Editor::get_placeholder( false, __( 'Subscription Info Block', 'wp-marketing-automations-pro' ) );
			}

			self::$is_preview = isset( $mergetagdata['is_preview'] ) && $mergetagdata['is_preview'];

			self::$subscription = ! self::$is_preview ? $this->set_subscription( $mergetagdata ) : null;

			if ( ! self::$is_preview && empty( self::$subscription ) ) {
				return '';
			}

			if ( ! self::$is_preview && self::$subscription instanceof WC_Subscription ) {
				do_action( 'bwfan_email_setup_locale', BWFAN_Common::get_order_language( self::$subscription ) );
			}

			ob_start();

			$attributes = json_decode( BWFCRM_Block_Editor::decode_content( $content ), true );

			$defaults = [
				'orderInfoAlign'     => [ 'desktop' => 'center' ],
				'padding'            => [
					'desktop' => [
						'top'    => '16',
						'right'  => '16',
						'bottom' => '16',
						'left'   => '16',
						'unit'   => 'px',
					],
					'mobile'  => [
						'top'    => '8',
						'right'  => '8',
						'bottom' => '8',
						'left'   => '8',
						'unit'   => 'px',
					],
				],
				'uniqueID'           => '',
				'orderInfoLabelFont' => [
					'desktop' => [
						'size' => '12',
					],
				],
				'orderInfoTextFont'  => [
					'desktop' => [
						'size' => '13',
					],
				],
				'commonPriceFont'    => [
					'desktop' => [
						'size' => '14',
					],
					'mobile'  => [
						'size' => '13',
					],
				],
				'productTitleFont'   => [
					'desktop' => [
						'size' => '13',
					],
					'mobile'  => [
						'size' => '12',
					],
				],
				'qtyFont'            => [
					'desktop' => [
						'size' => '14',
					],
					'mobile'  => [
						'size' => '13',
					],
				],
				'pricesMetaFont'     => [
					'desktop' => [
						'size' => '14',
					],
					'mobile'  => [
						'size' => '13',
					],
				],
				'pricesMetaColor'    => [
					'desktop' => '#82838e',
				],
				'discountColor'      => [
					'desktop' => '#09B29C',
				],
				'subTotalPriceFont'  => [
					'desktop' => [
						'size' => '14',
					],
					'mobile'  => [
						'size' => '13',
					],
				],
				'subTotalTextFont'   => [
					'desktop' => [
						'size' => '14',
					],
					'mobile'  => [
						'size' => '13',
					],
				],
				'totalPriceFont'     => [
					'desktop' => [
						'size' => '16',
					],
					'mobile'  => [
						'size' => '13',
					],
				],
				'totalTextFont'      => [
					'desktop' => [
						'size' => '16',
					],
					'mobile'  => [
						'size' => '13',
					],
				],
				'subTotalTextColor'  => [
					'desktop' => '#82838e',
				],
				'productTitleBold'   => [
					'desktop' => true,
				],
				'totalTextBold'      => [
					'desktop' => true,
				],
				'totalPriceBold'     => [
					'desktop' => true,
				],
				'itemImgWidth'       => [
					'desktop' => [
						'value' => '48',
						'unit'  => 'px',
					],
				],
				'imageSize'          => 'thumbnail',
				'scTitleFont'        => [
					'desktop' => [
						'size' => '18px',
						'unit' => 'px',
					],
				],
				'scLabelFont'        => [
					'desktop' => [
						'size' => '12',
						'unit' => 'px',
					],
				],
				'scLabelColor'       => [ 'desktop' => '#82838e' ],
				'scTitle'            => '<strong>' . __( 'Subscription Information', 'wp-marketing-automations-pro' ) . '</strong>',
				'scIdLabel'          => '<strong>' . __( 'ID', 'wp-marketing-automations-pro' ) . '</strong>',
				'scStartDateLabel'   => '<strong>' . __( 'Start Date', 'wp-marketing-automations-pro' ) . '</strong>',
				'scEndDateLabel'     => '<strong>' . __( 'End Date', 'wp-marketing-automations-pro' ) . '</strong>',
				'scAmountLabel'      => '<strong>' . __( 'Recurring Total', 'wp-marketing-automations-pro' ) . '</strong>',
				'scNextPaymentLabel' => '<strong>' . __( 'Next Payment', 'wp-marketing-automations-pro' ) . '</strong>',
				'scIdFont'           => [
					'desktop' => [
						'size' => '14',
						'unit' => 'px',
					],
					'mobile'  => [
						'size' => '13',
						'unit' => 'px',
					],
				],
				'scStartDateFont'    => [
					'desktop' => [
						'size' => '14',
						'unit' => 'px',
					],
					'mobile'  => [
						'size' => '13',
						'unit' => 'px',
					],
				],
				'scEndDateFont'      => [
					'desktop' => [
						'size' => '14',
						'unit' => 'px',
					],
					'mobile'  => [
						'size' => '13',
						'unit' => 'px',
					],
				],
				'scAmountFont'       => [
					'desktop' => [
						'size' => '14',
						'unit' => 'px',
					],
					'mobile'  => [
						'size' => '13',
						'unit' => 'px',
					],
				],
				'scNextPaymentFont'  => [
					'desktop' => [
						'size' => '14',
						'unit' => 'px',
					],
					'mobile'  => [
						'size' => '13',
						'unit' => 'px',
					],
				],
				'dividerColor'       => [ 'desktop' => '#f6f6f6' ],
				'dividerStyle'       => [ 'desktop' => 'solid' ],

				/** Installment schedule (shown instead of the info table for Sublium installment plans) */
				'psTitle'             => '<strong>' . __( 'Installment Schedule', 'wp-marketing-automations-pro' ) . '</strong>',
				'psPaymentsLabel'     => '<strong>' . __( 'Installments', 'wp-marketing-automations-pro' ) . '</strong>',
				'psDueDateLabel'      => '<strong>' . __( 'Due Date', 'wp-marketing-automations-pro' ) . '</strong>',
				'psStatusLabel'       => '<strong>' . __( 'Status', 'wp-marketing-automations-pro' ) . '</strong>',
				'psAmountLabel'       => '<strong>' . __( 'Amount', 'wp-marketing-automations-pro' ) . '</strong>',
				'psPaidStatusColor'   => [ 'desktop' => '#10B981' ],
				'psFailedStatusColor' => [ 'desktop' => '#EF4444' ],
				'psStatusColor'       => [ 'desktop' => '#82838e' ],
			];

			$this->settings = wp_parse_args( $attributes, $defaults );

			$this->settings['classname'] = [
				'bwfbe-email-order-summary',
				'bwfbe-email-order-summary-' . ( $attributes['uniqueID'] ?? '' ),
			];

			$this->wrapper_selector = '.bwfbe-email-order-summary.bwfbe-email-order-summary-' . $this->settings['uniqueID'];

			$this->tableAttrs = 'cellpadding="0" cellspacing="0" role="presentation" border="0"';

			?>
			<style data-id='woofunnels'>
				@media only screen and (max-width: 768px) {
				<?php echo $this->responsive_style; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				}
			</style>
			<?php
			$this->responsive_style = '';

			$this->subscription_summary_html();

			return BWFAN_Common::decode_merge_tags( ob_get_clean() );
		}

		public function subscription_summary_html() {
			remove_all_filters( 'woocommerce_currency_symbol' );
			?>
			<tr>
				<td class="<?php echo implode( ' ', $this->settings['classname'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" style="<?php echo $this->get_block_wrapper_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
					<table <?php echo $this->tableAttrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> style="width:100%">
						<tbody>
						<?php $this->subscription_html(); ?>
						</tbody>
					</table>
				</td>
			</tr>
			<?php
		}

		public function get_subscription_data() {
			if ( self::$is_preview ) {
				$date_format = get_option( 'date_format', 'd F, Y' );

				return [
					[
						'id'           => '123',
						'start_date'   => gmdate( $date_format ),
						'end_date'     => __( 'When cancelled', 'wp-marketing-automations-pro' ),
						'amount'       => wc_price( 1300 ) . ' / ' . __( 'month', 'woocommerce' ), // phpcs:ignore WordPress.WP.I18n.TextDomainMismatch
						'next_payment' => gmdate( $date_format, strtotime( '+1 month' ) ),
						'view_link'    => '#',
					],
				];
			}

			if ( empty( self::$subscription ) ) {
				return [];
			}

			$sublium_class = 'Sublium_WCS\Includes\Controller\Subscriptions\Subscription';
			if ( class_exists( $sublium_class ) && self::$subscription instanceof $sublium_class ) {
				return $this->get_sublium_subscription_data();
			}

			if ( ! self::$subscription instanceof WC_Subscription ) {
				return [];
			}

			$subscription = self::$subscription;
			$date_format  = get_option( 'date_format', 'd F, Y' );

			/** Get dates */
			$start_date = $subscription->get_date( 'start' );
			$start_date = ! empty( $start_date ) ? date_i18n( $date_format, strtotime( $start_date ) ) : '--';

			$end_date = $subscription->get_date( 'end' );
			$end_date = ! empty( $end_date ) ? date_i18n( $date_format, strtotime( $end_date ) ) : __( 'When cancelled', 'wp-marketing-automations-pro' );

			$next_payment = $subscription->get_date( 'next_payment' );
			$next_payment = ! empty( $next_payment ) ? date_i18n( $date_format, strtotime( $next_payment ) ) : '--';

			/** Get recurring total with period */
			$recurring_total = $subscription->get_formatted_order_total();

			/** Get subscription view URL */
			$view_link = $subscription->get_view_order_url();

			return [
				[
					'id'           => $subscription->get_id(),
					'start_date'   => $start_date,
					'end_date'     => $end_date,
					'amount'       => $recurring_total,
					'next_payment' => $next_payment,
					'view_link'    => $view_link,
				],
			];
		}

		/**
		 * Build the subscription info rows from a Sublium subscription object.
		 *
		 * @return array
		 */
		public function get_sublium_subscription_data() {
			$subscription = self::$subscription;
			$date_format  = get_option( 'date_format', 'd F, Y' );

			$start_raw = $subscription->get_created_at();
			$end_raw   = $subscription->get_end_date();
			$next_raw  = $subscription->get_next_payment_date_only();

			$start_date   = ! empty( $start_raw ) ? date_i18n( $date_format, strtotime( $start_raw ) ) : '--';
			$end_date     = ! empty( $end_raw ) ? date_i18n( $date_format, strtotime( $end_raw ) ) : __( 'When cancelled', 'wp-marketing-automations-pro' );
			$next_payment = ! empty( $next_raw ) ? date_i18n( $date_format, strtotime( $next_raw ) ) : '--';

			$currency = $subscription->get_currency();
			$currency = ! empty( $currency ) ? $currency : get_option( 'woocommerce_currency' );

			return [
				[
					'id'           => $subscription->get_id(),
					'start_date'   => $start_date,
					'end_date'     => $end_date,
					'amount'       => wc_price( $subscription->get_totals(), [ 'currency' => $currency ] ),
					'next_payment' => $next_payment,
					'view_link'    => '',
				],
			];
		}

		/**
		 * Whether the resolved subscription is a Sublium installment plan (plan_type 3).
		 *
		 * @param mixed $subscription
		 *
		 * @return bool
		 */
		public function is_sublium_installment( $subscription ) {
			$class = 'Sublium_WCS\Includes\Controller\Subscriptions\Subscription';
			if ( ! class_exists( $class ) || ! $subscription instanceof $class ) {
				return false;
			}

			return method_exists( $subscription, 'get_plan_type' ) && 3 === (int) $subscription->get_plan_type();
		}

		public function subscription_html() {
			/** Sublium installment plans render the installment schedule in place of the info table */
			if ( $this->is_sublium_installment( self::$subscription ) ) {
				$this->installment_schedule_html();

				return;
			}

			$subscriptions = $this->get_subscription_data();
			if ( empty( $subscriptions ) ) {
				return;
			}
			?>
			<tr>
				<td class="sc-wrap">
					<p class="sc-title" style="<?php echo $this->get_sc_title_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>"><?php echo $this->settings['scTitle']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
					<table align="<?php echo is_rtl() ? 'right' : 'left'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" <?php echo $this->tableAttrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> style="width:100%;" class="sc-table">
						<tbody>
						<tr>
							<td class="sc-label" style="width:10%;<?php echo $this->get_sc_label_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>"><?php echo $this->settings['scIdLabel']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
							<td class="sc-label" style="width:24%;<?php echo $this->get_sc_label_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>"><?php echo $this->settings['scStartDateLabel']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
							<td class="sc-label" style="width:24%;<?php echo $this->get_sc_label_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>"><?php echo $this->settings['scEndDateLabel']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
							<td class="sc-label" style="width:28%;<?php echo $this->get_sc_label_style( 'sc-label', '0px' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>"><?php echo $this->settings['scAmountLabel']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
						</tr>
						<?php
						foreach ( $subscriptions as $subscription ) {
							?>
							<tr>
								<td style="<?php echo $this->get_sc_td_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>width:10%;">
									<a href="<?php echo esc_url( $subscription['view_link'] ); ?>" target="_blank" class="sc-id" style="<?php echo $this->get_sc_id_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">#<?php echo esc_html( $subscription['id'] ); ?></a>
								</td>
								<td class="sc-start-date" style="width:24%;<?php echo $this->get_sc_start_date_style() . $this->get_sc_td_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
									<?php echo esc_html( $subscription['start_date'] ); ?>
								</td>
								<td class="sc-end-date" style="width:24%;<?php echo $this->get_sc_end_date_style() . $this->get_sc_td_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
									<?php echo esc_html( $subscription['end_date'] ); ?>
								</td>
								<td style="width:28%;<?php echo $this->get_sc_td_style( '0px' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
									<p class="sc-amount" style="<?php echo $this->get_sc_amount_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
										<?php echo $subscription['amount']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
									</p>
									<p class="sc-next-payment" style="<?php echo $this->get_sc_next_payment_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
										<?php echo $this->settings['scNextPaymentLabel'] . ' :' . esc_html( $subscription['next_payment'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
									</p>
								</td>
							</tr>
						<?php } ?>
						</tbody>
					</table>
				</td>
			</tr>
			<?php
		}

		/**
		 * Build the installment schedule rows for a Sublium installment plan.
		 * Mirrors Sublium's payment-schedule block, sourcing data from Sublium's
		 * own get_installment_payment_summary().
		 *
		 * @return array
		 */
		public function get_installment_schedule_data() {
			if ( empty( self::$subscription ) || ! isset( self::$subscription->exists ) || ! self::$subscription->exists ) {
				return [];
			}

			$helper = 'Sublium_WCS\Includes\Helpers\Subscription';
			if ( ! class_exists( $helper ) || ! method_exists( $helper, 'get_installment_payment_summary' ) ) {
				return [];
			}

			$payments = $helper::get_installment_payment_summary( self::$subscription );

			return is_array( $payments ) ? $payments : [];
		}

		public function installment_schedule_html() {
			$payments = $this->get_installment_schedule_data();
			if ( empty( $payments ) ) {
				return;
			}
			?>
			<tr>
				<td class="sc-wrap">
					<p class="ps-title" style="<?php echo $this->get_ps_title_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>"><?php echo $this->settings['psTitle']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
					<table align="<?php echo is_rtl() ? 'right' : 'left'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" <?php echo $this->tableAttrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> style="width:100%;" class="ps-table">
						<tbody>
						<tr class="ps-header">
							<td style="<?php echo $this->get_ps_header_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>width:25%;"><?php echo $this->settings['psPaymentsLabel']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
							<td style="<?php echo $this->get_ps_header_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>width:25%;"><?php echo $this->settings['psDueDateLabel']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
							<td style="<?php echo $this->get_ps_header_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>width:25%;"><?php echo $this->settings['psStatusLabel']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
							<td style="<?php echo $this->get_ps_header_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>width:25%;"><?php echo $this->settings['psAmountLabel']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
						</tr>
						<?php foreach ( $payments as $payment ) : ?>
							<tr class="ps-row">
								<td style="<?php echo $this->get_ps_cell_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
									<?php echo esc_html( $payment['payment'] ?? '' ); ?>
								</td>
								<td style="<?php echo $this->get_ps_cell_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
									<?php echo esc_html( $payment['due_date'] ?? '' ); ?>
								</td>
								<td style="<?php echo $this->get_ps_cell_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
									<span class="ps-status ps-status-<?php echo esc_attr( $payment['status'] ?? '' ); ?>" style="<?php echo $this->get_ps_status_style( $payment['status'] ?? '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
										<?php echo esc_html( $payment['status_label'] ?? '' ); ?>
									</span>
								</td>
								<td style="<?php echo $this->get_ps_cell_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
									<?php echo $payment['amount'] ?? ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								</td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				</td>
			</tr>
			<?php
		}

		private function get_ps_title_style( $classname = '.ps-title' ) {
			$defaulStyle = $this->get_default_style();
			$style       = $defaulStyle['text-style'];
			$style      .= bwf_css()->getFontSize( $this->settings, 'scTitleFont', 'desktop', false, $defaulStyle['font-size'] );
			$style      .= bwf_css()->getColor( $this->settings, 'scTitleColor', 'desktop' );
			$style      .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'desktop' );
			$style      .= 'padding: 0 0 16px 0;';

			if ( ! empty( $classname ) ) {
				$mStyle                  = bwf_css()->getFontSize( $this->settings, 'scTitleFont', 'mobile', true );
				$mStyle                 .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'mobile', true );
				$this->responsive_style .= sprintf( '%1$s %2$s {%3$s}', $this->wrapper_selector, $classname, $mStyle );
			}

			return $style;
		}

		private function get_ps_header_style() {
			$defaulStyle = $this->get_default_style();
			$style       = $defaulStyle['text-style'];
			$style      .= bwf_css()->getFontSize( $this->settings, 'scLabelFont', 'desktop', false, $defaulStyle['font-size'] );
			$style      .= bwf_css()->getColor( $this->settings, 'scLabelColor', 'desktop' );
			$style      .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'desktop' );
			$style      .= $this->get_block_seperator_style();
			$style      .= 'padding:12px 8px;mso-padding-alt:12px 8px;';

			return $style;
		}

		private function get_ps_cell_style() {
			$defaulStyle = $this->get_default_style();
			$style       = $defaulStyle['text-style'];
			$style      .= bwf_css()->getFontSize( $this->settings, 'scIdFont', 'desktop', false, $defaulStyle['font-size'] );
			$style      .= bwf_css()->getColor( $this->settings, 'scIdColor', 'desktop' );
			$style      .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'desktop' );
			$style      .= $this->get_block_seperator_style();
			$style      .= 'padding:10px 8px;mso-padding-alt:10px 8px;';

			return $style;
		}

		private function get_ps_status_style( $status ) {
			$defaulStyle = $this->get_default_style();
			$style       = $defaulStyle['text-style'];
			$style      .= bwf_css()->getFontSize( $this->settings, 'scIdFont', 'desktop', false, '12px' );
			$style      .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'desktop' );

			switch ( $status ) {
				case 'paid':
					$style .= 'color: ' . ( $this->settings['psPaidStatusColor']['desktop'] ?? '#10B981' ) . ';';
					break;
				case 'failed':
					$style .= 'color: ' . ( $this->settings['psFailedStatusColor']['desktop'] ?? '#EF4444' ) . ';';
					break;
				case 'pending':
				case 'upcoming':
				default:
					$style .= 'color: ' . ( $this->settings['psStatusColor']['desktop'] ?? '#82838e' ) . ';';
					break;
			}

			return $style;
		}

		/**
		 * Get Block Container style
		 */
		private function get_block_wrapper_style() {
			$style  = 'word-break:break-word;';
			$style .= bwf_css()->getPadding( $this->settings, 'padding', 'desktop' );
			$style .= bwf_css()->getMsoPadding( $this->settings, 'padding', 'desktop' );
			$style .= bwf_css()->getVisibilityCss( $this->settings, 'desktop' );

			if ( $this->wrapper_selector ) {
				$mStyle                  = bwf_css()->getPadding( $this->settings, 'padding', 'mobile', true );
				$mStyle                 .= bwf_css()->getVisibilityCss( $this->settings, 'mobile' );
				$this->responsive_style .= sprintf( '%1$s {%2$s}', $this->wrapper_selector, $mStyle );
			}

			return $style;
		}

		/**
		 * Get separator style
		 */
		private function get_block_seperator_style( $pos = 'bottom' ) {
			$dividerColor = isset( $this->settings['dividerColor']['desktop'] ) ? $this->settings['dividerColor']['desktop'] : '';
			$dividerStyle = isset( $this->settings['dividerStyle']['desktop'] ) ? $this->settings['dividerStyle']['desktop'] : '';

			if ( 'none' === $dividerStyle ) {
				return '';
			}

			return sprintf( 'border-%1$s: 1px %2$s %3$s;', $pos, $dividerStyle, $dividerColor );
		}

		private function get_sc_title_style( $classname = '.sc-title' ) {
			$defaulStyle = $this->get_default_style();
			$style       = $defaulStyle['text-style'];
			$style      .= bwf_css()->getFontSize( $this->settings, 'scTitleFont', 'desktop', false, $defaulStyle['font-size'] );
			$style      .= bwf_css()->getColor( $this->settings, 'scTitleColor', 'desktop' );
			$style      .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'desktop' );

			if ( ! empty( $classname ) ) {
				$mStyle                  = bwf_css()->getFontSize( $this->settings, 'scTitleFont', 'mobile', true );
				$mStyle                 .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'mobile', true );
				$this->responsive_style .= sprintf( '%1$s %2$s {%3$s}', $this->wrapper_selector, $classname, $mStyle );
			}

			return $style;
		}

		private function get_sc_label_style( $classname = '.sc-label', $right = '4px' ) {
			$defaulStyle = $this->get_default_style();
			$style       = $defaulStyle['text-style'];
			$style      .= bwf_css()->getFontSize( $this->settings, 'scLabelFont', 'desktop', false, $defaulStyle['font-size'] );
			$style      .= bwf_css()->getColor( $this->settings, 'scLabelColor', 'desktop' );
			$style      .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'desktop' );
			$style      .= $this->get_block_seperator_style();
			$style      .= 'padding:24px ' . $right . ' 8px 0;mso-padding-alt:24px ' . $right . ' 8px 0;';

			if ( ! empty( $classname ) ) {
				$mStyle                  = bwf_css()->getFontSize( $this->settings, 'scLabelFont', 'mobile', true );
				$mStyle                 .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'mobile', true );
				$this->responsive_style .= sprintf( '%1$s %2$s {%3$s}', $this->wrapper_selector, $classname, $mStyle );
			}

			return $style;
		}

		private function get_sc_id_style( $classname = '.sc-id' ) {
			$defaulStyle = $this->get_default_style();
			$style       = $defaulStyle['text-style'];
			$style      .= bwf_css()->getFontSize( $this->settings, 'scIdFont', 'desktop', false, $defaulStyle['font-size'] );
			$style      .= bwf_css()->getColor( $this->settings, 'scIdColor', 'desktop', 'linkColor' );
			$style      .= bwf_css()->getBold( $this->settings, 'scIdBold', 'desktop' );
			$style      .= bwf_css()->getItalic( $this->settings, 'scIdItalic', 'desktop' );
			$style      .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'desktop' );

			if ( ! empty( $classname ) ) {
				$mStyle                  = bwf_css()->getFontSize( $this->settings, 'scIdFont', 'mobile', true );
				$mStyle                 .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'mobile', true );
				$this->responsive_style .= sprintf( '%1$s %2$s {%3$s}', $this->wrapper_selector, $classname, $mStyle );
			}

			return $style;
		}

		private function get_sc_start_date_style( $classname = '.sc-start-date' ) {
			$defaulStyle = $this->get_default_style();
			$style       = $defaulStyle['text-style'];
			$style      .= bwf_css()->getFontSize( $this->settings, 'scStartDateFont', 'desktop', false, $defaulStyle['font-size'] );
			$style      .= bwf_css()->getColor( $this->settings, 'scStartDateColor', 'desktop' );
			$style      .= bwf_css()->getBold( $this->settings, 'scStartDateBold', 'desktop' );
			$style      .= bwf_css()->getItalic( $this->settings, 'scStartDateItalic', 'desktop' );
			$style      .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'desktop' );

			if ( ! empty( $classname ) ) {
				$mStyle                  = bwf_css()->getFontSize( $this->settings, 'scStartDateFont', 'mobile', true );
				$mStyle                 .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'mobile', true );
				$this->responsive_style .= sprintf( '%1$s %2$s {%3$s}', $this->wrapper_selector, $classname, $mStyle );
			}

			return $style;
		}

		private function get_sc_end_date_style( $classname = '.sc-end-date' ) {
			$defaulStyle = $this->get_default_style();
			$style       = $defaulStyle['text-style'];
			$style      .= bwf_css()->getFontSize( $this->settings, 'scEndDateFont', 'desktop', false, $defaulStyle['font-size'] );
			$style      .= bwf_css()->getColor( $this->settings, 'scEndDateColor', 'desktop' );
			$style      .= bwf_css()->getBold( $this->settings, 'scEndDateBold', 'desktop' );
			$style      .= bwf_css()->getItalic( $this->settings, 'scEndDateItalic', 'desktop' );
			$style      .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'desktop' );

			if ( ! empty( $classname ) ) {
				$mStyle                  = bwf_css()->getFontSize( $this->settings, 'scEndDateFont', 'mobile', true );
				$mStyle                 .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'mobile', true );
				$this->responsive_style .= sprintf( '%1$s %2$s {%3$s}', $this->wrapper_selector, $classname, $mStyle );
			}

			return $style;
		}

		private function get_sc_amount_style( $classname = '.sc-amount' ) {
			$defaulStyle = $this->get_default_style();
			$style       = $defaulStyle['text-style'];
			$style      .= bwf_css()->getFontSize( $this->settings, 'scAmountFont', 'desktop', false, $defaulStyle['font-size'] );
			$style      .= bwf_css()->getColor( $this->settings, 'scAmountColor', 'desktop' );
			$style      .= bwf_css()->getBold( $this->settings, 'scAmountBold', 'desktop' );
			$style      .= bwf_css()->getItalic( $this->settings, 'scAmountItalic', 'desktop' );
			$style      .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'desktop' );

			if ( ! empty( $classname ) ) {
				$mStyle                  = bwf_css()->getFontSize( $this->settings, 'scAmountFont', 'mobile', true );
				$mStyle                 .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'mobile', true );
				$this->responsive_style .= sprintf( '%1$s %2$s {%3$s}', $this->wrapper_selector, $classname, $mStyle );
			}

			return $style;
		}

		private function get_sc_next_payment_style( $classname = '.sc-next-payment' ) {
			$defaulStyle = $this->get_default_style();
			$style       = $defaulStyle['text-style'];
			$style      .= bwf_css()->getFontSize( $this->settings, 'scNextPaymentFont', 'desktop', false, $defaulStyle['font-size'] );
			$style      .= bwf_css()->getColor( $this->settings, 'scNextPaymentColor', 'desktop' );
			$style      .= bwf_css()->getBold( $this->settings, 'scNextPaymentBold', 'desktop' );
			$style      .= bwf_css()->getItalic( $this->settings, 'scNextPaymentItalic', 'desktop' );
			$style      .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'desktop' );

			if ( ! empty( $classname ) ) {
				$mStyle                  = bwf_css()->getFontSize( $this->settings, 'scNextPaymentFont', 'mobile', true );
				$mStyle                 .= bwf_css()->getLineHeight( $this->settings, 'lineHeight', 'mobile', true );
				$this->responsive_style .= sprintf( '%1$s %2$s {%3$s}', $this->wrapper_selector, $classname, $mStyle );
			}

			return $style;
		}

		private function get_sc_td_style( $right = '4px' ) {
			$style  = $this->get_block_seperator_style();
			$style .= 'padding:20px ' . $right . ' 20px 0;mso-padding-alt:20px ' . $right . ' 20px 0;';

			return $style;
		}

		/**
		 * Block default and common style
		 */
		private function get_default_style( $type = '' ) {
			$defaultStyle = [
				'font-size'   => 'font-size:16px;',
				'font-family' => bwf_css()->getFontFamily( $this->settings ),
				'text-style'  => 'margin:0;line-height: 1.5;' . bwf_css()->getFontFamily( $this->settings ),
				'color'       => bwf_css()->getColor( $this->settings, 'color', 'desktop' ),
			];

			if ( ! empty( $type ) && is_string( $type ) ) {
				return $defaultStyle[ $type ];
			}

			return $defaultStyle;
		}
	}

	BWFBE_Subscription_Info_Template::get_instance();
}
