<?php

/**
 * BWFCRM_Calls_Handler
 */
#[AllowDynamicProperties]
class BWFCRM_Calls_Handler {
	/**
	 * Class instance
	 */
	private static $ins = null;

	/**
	 * Registered calls list
	 *
	 * @var array
	 */
	private $_calls = [];

	/**
	 * Class constructor
	 */
	public function __construct() {
		add_action( 'plugins_loaded', [ $this, 'load_calls' ], 8 );
	}

	/**
	 * Returns class instance
	 *
	 * @return BWFCRM_Calls_Handler|null
	 */
	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self;
		}

		return self::$ins;
	}

	/**
	 * Load all calls.
	 *
	 * Registrations used to sit at file scope in each call file, which
	 * blocked those classes from Pro's lazy classmap autoloader (rule 1: no
	 * file-scope register()). Declared here instead, the call files are pure
	 * class definitions — the crm-actions' class_exists() guards and
	 * `new Calls\X` sites autoload them on first use.
	 *
	 * Adding a CRM call: a row here (glob/filename order) + the class in
	 * includes/class-bwfan-pro-autoload-map.php.
	 */
	public function load_calls() {
		$map = [
			'add_to_lists'         => 'BWFCRM\Calls\Autonami\Add_To_Lists',
			'add_tags'             => 'BWFCRM\Calls\Autonami\Add_Tags',
			'add_to_automation'    => 'BWFCRM\Calls\Autonami\Add_To_Automation',
			'delete_contacts'      => 'BWFCRM\Calls\Autonami\Delete_Contacts',
			'end_automation'       => 'BWFCRM\Calls\Autonami\End_Automation',
			'remove_lists'         => 'BWFCRM\Calls\Autonami\Remove_Lists',
			'remove_tags'          => 'BWFCRM\Calls\Autonami\Remove_Tags',
			'subscribe_contacts'   => 'BWFCRM\Calls\Autonami\Subscribe_Contacts',
			'unsubscribe_contacts' => 'BWFCRM\Calls\Autonami\Unsubscribe_Contacts',
			'update_fields'        => 'BWFCRM\Calls\Autonami\Update_Fields',
		];

		foreach ( $map as $slug => $class ) {
			$this->register_call( $slug, $class );
		}

		do_action( 'bwfcrm_calls_loaded' );
	}

	/**
	 * Function registers call
	 *
	 * @param $slug
	 * @param $class
	 * @param $nice_name
	 *
	 * @return null
	 */
	public function register_call( $slug, $class ) {
		if ( empty( $slug ) ) {
			return;
		}

		$this->_calls[ $slug ] = $class;
	}

	/**
	 * Retrun call obj if call exists
	 *
	 * @param $slug
	 *
	 * @return array|false
	 */
	public function get_call_by_slug( $slug ) {
		if ( ! isset( $this->_calls[ $slug ] ) ) {
			return false;
		}

		/**
		 * A slug is registered from the declared map, but its class resolves
		 * through the Pro classmap autoloader, which bails silently on an
		 * unreadable map or class file (update file-swap / partial deploy).
		 * The glob this map replaced required the file before the slug could
		 * register, so an unloadable class was impossible — keep returning
		 * false rather than throwing "Class not found".
		 */
		if ( ! class_exists( $this->_calls[ $slug ] ) ) {
			return false;
		}

		return new $this->_calls[ $slug ];
	}
}

/**
 * Register calls handler to BWFCRM_Core
 */
if ( class_exists( 'BWFCRM_Calls_Handler' ) ) {
	BWFCRM_Core::register( 'calls', 'BWFCRM_Calls_Handler' );
}