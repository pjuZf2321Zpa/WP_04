<?php
/**
 * Campaigns Controller Class
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BWFCRM_Campaigns
 */
#[AllowDynamicProperties]
class BWFCRM_Campaigns {
	public static $CAMPAIGN_DRAFT = 1;
	public static $CAMPAIGN_SCHEDULED = 2;
	public static $CAMPAIGN_RUNNING = 3;
	public static $CAMPAIGN_COMPLETED = 4;
	public static $CAMPAIGN_HALT = 5;
	public static $CAMPAIGN_PAUSED = 6;
	public static $CAMPAIGN_CANCELLED = 7;

	public static $CAMPAIGN_EMAIL = 1;
	public static $CAMPAIGN_SMS = 2;
	public static $CAMPAIGN_WHATSAPP = 3;

	private static $ins = null;

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	/** @var BWFCRM_Broadcast_Processing */
	private $broadcast_as_ins = null;

	public function __construct() {
		include_once __DIR__ . '/class-bwfcrm-broadcast-processing.php';
		$this->broadcast_as_ins = BWFCRM_Broadcast_Processing::get_instance();
	}

	public function get_campaign_open_click_analytics( $oid ) {
		$start_date = BWFAN_Model_Engagement_Tracking::get_first_conversation_date( absint( $oid ), BWFAN_Email_Conversations::$TYPE_CAMPAIGN );
		if ( empty( $start_date ) ) {
			$start_date = new DateTime();
		} else {
			$start_date = new DateTime( $start_date );
		}

		$start_date->setTimezone( wp_timezone() );
		$end_date = clone $start_date;
		$end_date->add( new DateInterval( 'P4D' ) );

		/* Add current hour interval */
		$current_date = new DateTime( 'now' );
		$current_date->setTimezone( wp_timezone() );
		$current_date->add( new DateInterval( 'PT1H' ) );
		if ( $current_date < $end_date ) {
			$end_date = $current_date;
		}

		$intervals      = $this->intervals_between( $start_date->format( 'Y-m-d H:i:s' ), $end_date->format( 'Y-m-d H:i:s' ) );
		$time_intervals = empty( $intervals ) ? [] : array_column( $intervals, 'time_interval' );
		$data           = BWFAN_Model_Broadcast::get_interaction_stats_by_date_range( $time_intervals, $oid );

		$final_data = array();
		foreach ( $intervals as $interval ) {
			$opens        = empty( $data['open'] ) || ! is_array( $data['open'] ) || ! isset( $data['open'][0][ $interval['time_interval'] ] ) ? 0 : $data['open'][0][ $interval['time_interval'] ];
			$clicks       = empty( $data['click'] ) || ! is_array( $data['click'] ) || ! isset( $data['click'][0][ $interval['time_interval'] ] ) ? 0 : $data['click'][0][ $interval['time_interval'] ];
			$final_data[] = $this->get_interval_array( $interval, $opens, $clicks );
		}

		return $final_data;
	}

	public function get_interval_array( $interval, $opens, $clicks ) {
		$interval_data                   = array();
		$interval_data['interval']       = $interval['time_interval'];
		$interval_data['start_date']     = $interval['start_date'];
		$interval_data['date_start_gmt'] = $this->convert_local_datetime_to_gmt( $interval['start_date'] )->format( 'Y-m-d H:i:s' );
		$interval_data['end_date']       = $interval['end_date'];
		$interval_data['date_end_gmt']   = $this->convert_local_datetime_to_gmt( $interval['end_date'] )->format( 'Y-m-d H:i:s' );

		$interval_data['subtotals'] = array(
			'opens'    => absint( $opens ),
			'clicks'   => absint( $clicks ),
			'segments' => array(),
		);

		return $interval_data;
	}

	public function convert_local_datetime_to_gmt( $datetime_string ) {
		$datetime = new DateTime( $datetime_string, new \DateTimeZone( wp_timezone_string() ) );
		$datetime->setTimezone( new DateTimeZone( 'GMT' ) );

		return $datetime;
	}

	public function intervals_between( $start, $end ) {
		$interval_type = 'PT60M';
		$format        = 'Y-m-d H';
		$result        = array();

		// Variable that store the date interval
		// of period 1 day
		$period  = new DateInterval( $interval_type );
		$realEnd = new DateTime( $end );
		$period  = new DatePeriod( new DateTime( $start ), $period, $realEnd );
		$count   = iterator_count( $period );

		foreach ( $period as $date ) {
			if ( $count >= 1 ) {

				$new_interval                  = array();
				$new_interval['start_date']    = $date->format( 'Y-m-d H:i:s' );
				$new_interval['end_date']      = $date->format( 'Y-m-d 23:59:59' );
				$new_interval['time_interval'] = $date->format( $format );

				$result[] = $new_interval;
			}
			$count --;
		}

		return $result;
	}

	public function get_conversions( $campaign_id, $offset = 0, $limit = 25 ) {
		if ( empty( $campaign_id ) ) {
			return array(
				'conversions' => array(),
				'total'       => 0,
			);
		}

		return BWFAN_Model_Conversions::get_conversions_by_source_type( $campaign_id, BWFAN_Email_Conversations::$TYPE_CAMPAIGN, $limit, $offset );
	}

	/**
	 * @return mixed
	 */
	public static function get_top_broadcast( $type = 1 ) {
		$broadcasts = BWFAN_Model_Broadcast::get_top_broadcast( $type );

		$top_broadcast['top_broadcast'] = $broadcasts;

		return $top_broadcast;
	}

	public function save_editor_content( $broadcast_id, $content_number, $design, $html ) {
		$data = BWFAN_Model_Broadcast::get_broadcast_data( $broadcast_id );

		$editor = array(
			'body'   => $html,
			'design' => $design,
		);

		$content_data = ! empty( $data ) && isset( $data['content'] ) && ! empty( $data['content'] ) ? $data['content'] : array();
		if ( empty( $content_data ) || ! is_array( $content_data ) ) {
			$content_data[]['editor']                = $editor;
			$content_data[ $content_number ]['type'] = 'editor';
		} else {
			$content_number                            = absint( $content_number );
			$content_data[ $content_number ]['editor'] = $editor;
			$content_data[ $content_number ]['type']   = 'editor';
		}

		$data            = ! is_array( $data ) ? array() : $data;
		$data['content'] = $content_data;

		BWFAN_Model_Broadcast::update_broadcast_data( $broadcast_id, $data );

		return true;
	}

	public function get_editor_design( $broadcast_id, $content_number ) {
		$content    = $this->get_editor_content( $broadcast_id, $content_number, true );
		$merge_tags = $this->get_merge_tags_for_editor();
		if ( empty( $content ) ) {
			return array(
				'design'     => '',
				'merge_tags' => $merge_tags,
				'subject'    => '',
			);
		}

		$editor_content = ! isset( $content['content'] ) || ! is_array( $content['content'] ) ? array() : $content['content'];
		$subject        = ! isset( $content['subject'] ) ? '' : $content['subject'];
		if ( ! is_array( $editor_content ) || ! isset( $editor_content['design'] ) || empty( $editor_content['design'] ) ) {
			return array(
				'design'     => '',
				'merge_tags' => $merge_tags,
				'subject'    => $subject,
			);
		}

		return array(
			'design'     => $editor_content['design'],
			'merge_tags' => $merge_tags,
			'subject'    => $subject,
		);
	}

	public function get_editor_content( $broadcast_id, $content_number, $get_subject = false ) {
		if ( empty( $content_number ) && 0 !== absint( $content_number ) ) {
			return false;
		}

		$data = BWFAN_Model_Broadcast::get_broadcast_data( $broadcast_id );
		if ( ! is_array( $data ) || empty( $data['content'] ) || ! is_array( $data['content'] ) || ! isset( $data['content'][ $content_number ] ) ) {
			return false;
		}

		$content = $data['content'][ $content_number ];
		if ( ! is_array( $content ) ) {
			return false;
		}

		$editor_content = empty( $content['editor'] ) || ! is_array( $content['editor'] ) ? array() : $content['editor'];
		if ( false === $get_subject ) {
			return $editor_content;
		}

		$subject = isset( $content['subject'] ) && ! empty( $content['subject'] ) ? $content['subject'] : '';

		return array(
			'subject' => $subject,
			'content' => $editor_content,
		);
	}

	public function get_merge_tags_for_editor() {
		$tags   = BWFCRM_Core()->merge_tags->get_registered_grouped_tags( true );
		$return = array();
		foreach ( $tags as $slug => $m_tags ) {
			$group_tags = array();
			foreach ( $m_tags as $tag_slug => $tag_name ) {
				$group_tags[ sanitize_title( $tag_slug ) ] = array(
					'name'  => $tag_name,
					'value' => '{{' . $tag_slug . '}}',
				);
			}

			$group_name = '';
			switch ( $slug ) {
				case 'contact':
					$group_name = 'Contact';
					break;
				case 'contact_fields':
					$group_name = 'Fields';
					break;
				case 'general':
					$group_name = 'General';
					break;
			}

			$return[ $slug ] = array(
				'name'      => $group_name,
				'mergeTags' => $group_tags,
			);
		}

		return $return;
	}

	public function save_broadcast_content( $broadcast_id, $content ) {
		if ( empty( $broadcast_id ) || empty( $content ) || ! is_array( $content ) ) {
			return BWFCRM_Common::crm_error( __( 'Broadcast ID or Content is not valid / empty', 'wp-marketing-automations-pro' ), null, 400 );
		}

		$data = BWFAN_Model_Broadcast::get_broadcast_data( absint( $broadcast_id ) );
		if ( empty( $data ) || ! is_array( $data ) ) {
			return BWFCRM_Common::crm_error( __( 'Broadcast not found OR Invalid Broadcast Data', 'wp-marketing-automations-pro' ), null, 400 );
		}

		/** Same rule as update_campaign(): a finished broadcast's content is what its report links to */
		$row = BWFAN_Model_Broadcast::get( absint( $broadcast_id ) );
		if ( is_array( $row ) && BWFAN_Model_Broadcast::is_finished_status( $row['status'] ?? 0 ) ) {
			return BWFCRM_Common::crm_error( BWFAN_Model_Broadcast::finished_response()['message'], null, 400 );
		}

		$previous_content = isset( $data['content'] ) ? $data['content'] : array();
		$new_content      = ! empty( $content ) ? self::bwf_validate_anchor_tag( $content ) : array();

		/**
		 * The same normalisation step 3 of update_campaign() applies before it compares and saves:
		 * the editor posts `utm` back whether or not utmEnabled is on, and step 3 strips it when
		 * off. Without the same strip here the two doors disagreed on unchanged content - a no-op
		 * save read as a change, threw a prepared run away, or was refused outright on a broadcast
		 * that had started.
		 */
		if ( is_array( $new_content ) ) {
			$new_content = array_map( static function ( $variant ) {
				if ( is_array( $variant ) && empty( $variant['utmEnabled'] ) ) {
					unset( $variant['utm'] );
				}

				return $variant;
			}, $new_content );
		}

		/**
		 * Compared on a key-sorted copy.
		 *
		 * wp_json_encode() is order sensitive, and the stored blob has been through a JSON round
		 * trip while the incoming content has not - so a save that changed nothing can still read
		 * as different. That now costs twice: it throws away a prepared run, and it refuses the
		 * save outright with the 400 below on any broadcast that has started.
		 */
		$content_changed  = self::content_fingerprint( $previous_content ) !== self::content_fingerprint( $new_content );

		/**
		 * A broadcast that is already sending cannot have its content swapped underneath it.
		 *
		 * Its engagements were created with the old body and subject already resolved into their
		 * merge tags and an old template id against the row. Accepting the save would leave the
		 * ones created before it on the old content and the ones created after on the new - one
		 * broadcast shipping two different emails - and with A/B content the stored template id
		 * then matches nothing, so the send falls back to whichever variant the round robin lands
		 * on and the body no longer matches the merge tags resolved for that recipient.
		 *
		 * reset_prepared_broadcast() cannot rescue it either: it deliberately refuses anything
		 * that is not scheduled, because a run already in flight is past the point where its
		 * audience can be rebuilt. So the save is refused with a reason rather than accepted and
		 * quietly ignored, which is what happened before.
		 */
		if ( $content_changed ) {
			$broadcast = BWFAN_Model_Broadcast::get( absint( $broadcast_id ) );
			$prepared  = ! empty( $data['prepared_for'] );

			/**
			 * Any prepared broadcast that is no longer editable, not just a running one.
			 *
			 * Paused and halted broadcasts have engagements created and part of the audience
			 * already mailed, and reset_prepared_broadcast() refuses them for that reason - so
			 * accepting the save leaves the remainder to go out with the new body while what
			 * already went out carried the old one.
			 *
			 * Draft is editable alongside scheduled. Unscheduling clears what was prepared and
			 * queues the engagement cleanup, so a draft has nothing in flight to protect - and
			 * testing only for scheduled refused the save outright on any broadcast whose
			 * `prepared_for` outlived the unschedule, which is every SMS and WhatsApp one:
			 * update_status_to_draft() strips that key behind an `engagements_created` test and
			 * that key is written for email broadcasts only.
			 */
			/**
			 * v2 only, on top of the status test. The refusal protects engagements built ahead of
			 * the send with the content baked in; v1 reads the content from the row on every run,
			 * so an edit to a running or paused SMS or WhatsApp broadcast applies from the next
			 * run, as it always has. `prepared_for` is no longer written for those flows, but an
			 * old row may still carry it, and that key alone must not refuse the save.
			 */
			if ( $prepared && is_array( $broadcast ) && BWFCRM_Broadcast_Helper::is_v2_broadcast( $broadcast ) && ! self::is_content_editable_status( $broadcast['status'] ) ) {
				return BWFCRM_Common::crm_error( __( 'This broadcast is already sending, so its content can no longer be changed. Pause and duplicate it if you need to send different content.', 'wp-marketing-automations-pro' ), null, 400 );
			}
		}

		/**
		 * The content key alone, not the blob this request started with.
		 *
		 * $data was read at the top of the call and now carries the v2 run state - engagements_created,
		 * topup_offset, topup_done, consecutive_failures, failed_cids, winner, hold_broadcast. Handing
		 * the whole thing to update_broadcast_data() array_replace()s every one of those back to the
		 * value it held when the request began, so a worker that finished creating engagements, or
		 * declared a smart send winner, in the meantime has it silently reverted - and
		 * engagements_created going back to 0 sends the dispatcher into creation on a broadcast that
		 * is already sending.
		 */
		BWFAN_Model_Broadcast::update_broadcast_data( absint( $broadcast_id ), array( 'content' => $new_content ) );

		/**
		 * A scheduled broadcast may already have been prepared - templates written and engagements
		 * created with this content's merge tags resolved - so the preparation is dropped and done
		 * again against what was just saved. Guarded on the content actually differing, since a
		 * save that changes nothing should not throw a prepared run away.
		 */
		if ( $content_changed ) {
			BWFAN_Model_Broadcast::reset_prepared_broadcast( absint( $broadcast_id ) );
		}

		return true;
	}

	/**
	 * Whether a broadcast in this status may still have its content changed
	 *
	 * Scheduled, because reset_prepared_broadcast() can still throw the prepared run away and
	 * rebuild it. Draft, because there is nothing prepared left to protect.
	 *
	 * Halted, because a halt is terminal: the dispatcher does not fetch status 5, so nothing more
	 * goes out from it, and the only route back onto the calendar is step 4 of update_campaign(),
	 * which sets the status to scheduled and calls reset_prepared_broadcast() on the next line -
	 * deleting every unsent engagement before the broadcast can run again. So the split this guard
	 * exists to prevent cannot happen here, while the halts most in need of an edit are exactly
	 * the ones about content: "Broadcast content not found" and "Error in email body".
	 *
	 * Running and paused are what is left, and both mean a send in flight over engagements this
	 * save cannot reach. Cancelled and completed never reach the test at all - both strip
	 * `prepared_for` on the way out, and the caller only asks when that marker is present.
	 *
	 * @param int|string $status
	 *
	 * @return bool
	 */
	public static function is_content_editable_status( $status ) {
		return in_array( absint( $status ), array(
			self::$CAMPAIGN_SCHEDULED,
			self::$CAMPAIGN_DRAFT,
			self::$CAMPAIGN_HALT,
		), true );
	}

	/**
	 * Order-independent fingerprint of a broadcast's content
	 *
	 * Public because BWFAN_Model_Broadcast::save_campaign() guards the same content against the
	 * same statuses at step 3 and has to reach the same verdict - comparing the two blobs any
	 * other way reintroduces the key-order false positive this exists to remove.
	 *
	 * @param mixed $content
	 *
	 * @return string
	 */
	public static function content_fingerprint( $content ) {
		return wp_json_encode( self::sort_keys_recursive( $content ) );
	}

	/**
	 * Sort an array's keys, and those of every array inside it
	 *
	 * @param mixed $value
	 *
	 * @return mixed
	 */
	private static function sort_keys_recursive( $value ) {
		if ( ! is_array( $value ) ) {
			return $value;
		}

		$value = array_map( array( __CLASS__, 'sort_keys_recursive' ), $value );
		ksort( $value );

		return $value;
	}

	/**
	 * Remove undefined anchor tags
	 *
	 * @param $content
	 *
	 * @return array
	 */
	public static function bwf_validate_anchor_tag( $content ) {
		$content_arr = [];
		foreach ( $content as $data ) {
			if ( isset( $data['editor'] ) && isset( $data['editor']['body'] ) ) {
				$data['editor']['body'] = preg_replace_callback( '%(<a href="undefined".*?>)+?\s*(?P<link>\S+)\s*+(<\/a.*?>)%is', function ( $matches ) {
					$string = $matches[0];
					if ( isset( $matches['link'] ) && BWFAN_Pro_Common::bwfan_is_valid_link( $matches['link'] ) ) {
						$string = preg_replace( '/href="undefined"/i', 'href="' . $matches['link'] . '"', $string );
					} else {
						$string = preg_replace( '/href="undefined"/i', 'href="#"', $string );
					}

					return $string;
				}, $data['editor']['body'] );
			}
			$content_arr[] = $data;
		}

		return $content_arr;
	}

	public function maybe_daily_limit_reached( $type = 1 ) {
		return $this->broadcast_as_ins->maybe_daily_limit_reached( $type );
	}

	public function get_daily_limit_status_array() {
		return $this->broadcast_as_ins->get_daily_limit_status_array();
	}

	public function process_single_scheduled_broadcasts( $campaign_data ) {
		$this->broadcast_as_ins->process_single_scheduled_broadcasts( $campaign_data );
	}

	public function get_unopen_broadcast_contacts( $broadcast_id, $args = array(), $return_type = ARRAY_N ) {
		global $wpdb;

		/** Pagination Query */
		$limit            = isset( $args['limit'] ) ? absint( $args['limit'] ) : 0;
		$offset           = isset( $args['offset'] ) ? absint( $args['offset'] ) : 0;
		$pagination_query = '';
		if ( ! empty( $limit ) ) {
			$pagination_query = "LIMIT $offset, $limit";
		}

		/** Order By Query */
		$order          = isset( $args['order'] ) && ! empty( $args['order'] ) ? $args['order'] : 'ASC';
		$order          = ( 'DESC' === strtoupper( $order ) ) ? 'DESC' : 'ASC';
		$order_by_query = "ORDER BY cid $order";

		/** END ID Query */
		$end_id       = isset( $args['end_id'] ) ? absint( $args['end_id'] ) : 0;
		$end_id_query = '';
		if ( ! empty( $end_id ) ) {
			$end_id_query = $wpdb->prepare( 'AND et.cid < %d', $end_id );
		}

		/** Exclude Contact IDs */
		$exclude_ids   = isset( $args['exclude_ids'] ) && is_array( $args['exclude_ids'] ) ? array_map( 'absint', $args['exclude_ids'] ) : array();
		$exclude_query = '';
		if ( ! empty( $exclude_ids ) ) {
			$exclude_placeholder = implode( ',', array_fill( 0, count( $exclude_ids ), '%d' ) );
			$exclude_query       = $wpdb->prepare( "AND et.cid NOT IN ($exclude_placeholder)", $exclude_ids );
		}
		/**
		 * Audience rules come from the broadcast being sent, not the one being resent.
		 *
		 * $broadcast_id is the parent, but the resend is its own broadcast with its own settings,
		 * and the send gate reads those - BWFCRM_Broadcast_V2_Email_Controller passes
		 * $this->broadcast['data'] to get_unsendable_reason(). A query answering from the parent
		 * builds engagements the gate then refuses, one ERROR row per contact.
		 *
		 * They arrive in $args from get_broadcast_query_args(), and the audience preview passes
		 * them explicitly because that screen renders an unsaved form. The parent's stored
		 * settings are only the fallback for a caller that supplies none.
		 */
		$broadcast_data      = BWFAN_Model_Broadcast::get_broadcast_data( $broadcast_id );
		$exclude_unsubs      = array_key_exists( 'exclude_unsubs', $args ) ? ! empty( $args['exclude_unsubs'] ) : ! empty( $broadcast_data['is_promotional'] );
		$include_soft_bounce = array_key_exists( 'include_soft_bounce', $args ) ? ! empty( $args['include_soft_bounce'] ) : ! empty( $broadcast_data['includeSoftBounce'] );
		$include_unverified  = array_key_exists( 'include_unverified', $args ) ? ! empty( $args['include_unverified'] ) : ! empty( $broadcast_data['includeUnverified'] );

		$unsubscribe_query = $exclude_unsubs ? BWFCRM_Model_Contact::_get_unsubscribers_query( [], true ) : '';

		/** Status 1 (active), plus 4 (soft bounce) and 0 (unverified) when the broadcast opted into them */
		$status = 'c.status=1';
		$status .= $include_soft_bounce ? ' OR c.status=4' : '';
		$status .= $include_unverified ? ' OR c.status=0' : '';

		/** Final Status Query */
		$status_query = " AND ($status) ";

		/** Engagement Query for Contact IDs */
		$sql  = $wpdb->prepare( "SELECT et.cid from {$wpdb->prefix}bwfan_engagement_tracking AS et JOIN {$wpdb->prefix}bwf_contact AS c ON et.cid=c.id  WHERE et.type=2 AND et.oid=%d AND (et.cid!='' OR et.cid IS NOT NULL) AND et.open=0 $status_query $end_id_query $exclude_query $unsubscribe_query $order_by_query $pagination_query", $broadcast_id );
		$cids = $wpdb->get_results( $sql, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		/** Same WHERE as the page above minus its pagination, so the two can be compared */
		$count_sql = $wpdb->prepare( "SELECT count(et.cid) from {$wpdb->prefix}bwfan_engagement_tracking AS et JOIN {$wpdb->prefix}bwf_contact AS c ON et.cid=c.id WHERE et.type=2 AND et.oid=%d AND (et.cid!='' OR et.cid IS NOT NULL) AND et.open=0 $status_query $end_id_query $unsubscribe_query $exclude_query", $broadcast_id );

		/**
		 * The count still runs on an empty page, and is reported as it comes back.
		 *
		 * Returning a hardcoded zero here made an exhausted walk and a page query that failed
		 * indistinguishable to the caller, which is the one thing
		 * BWFCRM_Broadcast_Helper::$last_contact_query_failed exists to tell apart - a resend
		 * broadcast whose page was rolled back by a deadlock would have been recorded as fully
		 * prepared having built engagements for a fraction of the non openers.
		 *
		 * It costs one COUNT on the last page of each walk. Callers that pair the total with the
		 * rows already test the rows first, so a non zero total beside an empty page reaches only
		 * the code meant to act on it.
		 */
		if ( empty( $cids ) ) {
			$total_counts = $wpdb->get_var( $count_sql ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL

			return array(
				'contacts'    => array(),
				'total_count' => absint( $total_counts ),
			);
		}

		/** Total Contacts */
		$total_counts = $wpdb->get_var( $count_sql ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL

		/** Contact Query */
		$cids               = array_column( $cids, 'cid' );
		$contact_query_args = array(
			'customer_data'       => true,
			'include_ids'         => $cids,
			'grab_totals'         => isset( $args['grab_totals'] ) && $args['grab_totals'],
			'only_count'          => isset( $args['only_count'] ) && $args['only_count'],
			'exclude_unsubs'      => $exclude_unsubs,
			'include_soft_bounce' => $include_soft_bounce,
			'include_unverified'  => $include_unverified,
		);

		$filters              = isset( $args['filters'] ) ? $args['filters'] : array();
		$filters['status_is'] = 1; // only active contacts
		$contacts             = BWFCRM_Contact::get_contacts( '', 0, $limit, $filters, $contact_query_args, $return_type );
		$contacts             = is_array( $contacts ) && ! empty( $contacts['contacts'] ) ? $contacts['contacts'] : [];

		/**
		 * Left zeroed when the page came back empty, unlike the empty-$cids return above.
		 *
		 * The two are not the same case. Up there an empty page and a non zero count can only
		 * mean the engagement query failed. Down here $cids was non empty and it is the contact
		 * query that returned nothing, which the contact filters can legitimately do - they are
		 * not the ones the count was taken over - so a non zero total beside no rows is not
		 * evidence of a failure and must not be reported as one.
		 */
		return array(
			'contacts'    => $contacts,
			'total_count' => empty( $contacts ) ? 0 : absint( $total_counts ),
		);
	}

	public function get_broadcast_lookup( $args ) {
		global $wpdb;

		$args = wp_parse_args( $args, array(
			'ids'    => array(),
			'type'   => 0,
			'limit'  => 25,
			'offset' => 0,
			'search' => '',
		) );

		$pagination_query = '';
		if ( ! empty( $args['offset'] ) || ! empty( $args['limit'] ) ) {
			$pagination_query = 'LIMIT ' . absint( $args['offset'] ) . ', ' . absint( $args['limit'] );
		}

		$ids         = $args['ids'];
		$where_query = 'WHERE 1 = 1 ';
		if ( is_array( $ids ) && ! empty( $ids ) ) {
			$ids             = array_map( 'absint', $ids );
			$ids_placeholder = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
			$where_query    .= $wpdb->prepare( "AND id IN ($ids_placeholder)", $ids );
		}

		$type = absint( $args['type'] );
		if ( ! empty( $type ) ) {
			$where_query .= $wpdb->prepare( 'AND type = %d', $type );
		}

		$db_broadcasts = $wpdb->get_results( "SELECT id, title from {$wpdb->prefix}bwfan_broadcast $where_query $pagination_query", ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$broadcasts    = array();
		foreach ( $db_broadcasts as $broadcast ) {
			$broadcasts[ absint( $broadcast['id'] ) ] = array(
				'id'    => absint( $broadcast['id'] ),
				'title' => $broadcast['title'],
			);
		}

		return $broadcasts;
	}

	/**
	 * If broadcast is in scheduled and paused status then get updated contact's count
	 *
	 * @param $broadcast
	 *
	 * @return array|mixed
	 */
	public static function get_broadcast_updated_contact_count( $broadcast ) {
		/** If broadcast status is not scheduled and paused */
		$allowed_status = [ BWFCRM_Broadcast_Processing::$CAMPAIGN_SCHEDULED, BWFCRM_Broadcast_Processing::$CAMPAIGN_PAUSED ];
		if ( ! in_array( intval( $broadcast['status'] ), $allowed_status, true ) ) {
			return $broadcast['count'];
		}

		$data            = isset( $broadcast['data'] ) && isset( $broadcast['data']['filters'] ) ? $broadcast['data'] : BWFAN_Model_Broadcast::get_broadcast_data( $broadcast['id'] );
		$filters         = isset( $data['filters'] ) ? $data['filters'] : [];
		$additional_info = [
			'grab_totals'   => true,
			'only_count'    => true,
			'customer_data' => false,
		];
		/**
		 * Same key the audience query reads, because this figure is meant to be the size of what
		 * that query builds. Hardcoding it either way makes the screen report an audience the
		 * broadcast will not mail.
		 */
		$additional_info['include_soft_bounce'] = ! empty( $data['includeSoftBounce'] );

		if ( isset( $data['includeUnverified'] ) ) {
			$additional_info['include_unverified'] = $data['includeUnverified'];
		}
		if ( empty( $data['is_promotional'] ) ) {
			$additional_info['include_unsubscribe'] = true;
		}
		$additional_info['is_broadcast'] = true;

		/** BC: for lite < 3.8.0, we need to set status_is to 1 to filter unsubscribed contacts in broadcast queries. */
		if ( defined( 'BWFAN_VERSION' ) && version_compare( BWFAN_VERSION, '3.8.0', '<' ) ) {
			$filters['status_is'] = 1;
		}

		$count = BWFCRM_Contact::get_contacts( '', 0, 0, $filters, $additional_info );

		return isset( $count['total_count'] ) ? $count['total_count'] : $broadcast['count'];
	}

	/**
	 * Get sent engagements of broadcast
	 *
	 * @param int $broadcast_id
	 * @param int $limit
	 * @param string $date last sent date processed
	 *
	 * @return array|object|stdClass[]|null
	 */
	public static function get_broadcast_engagements( $broadcast_id, $limit = 100, $date = 0 ) {
		global $wpdb;

		$placeholder = empty( $date ) ? '%d' : '%s';

		$query = $wpdb->prepare( "SELECT `created_at`, GROUP_CONCAT(`cid` SEPARATOR ',') AS cids FROM {$wpdb->prefix}bwfan_engagement_tracking WHERE `created_at` > $placeholder AND `oid` = %d AND `type` = %d AND `c_status` = %d GROUP BY `created_at` ORDER BY `created_at` ASC LIMIT %d", $date, intval( $broadcast_id ), 2, 2, $limit );

		return $wpdb->get_results( $query, ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL
	}
}

if ( class_exists( 'BWFCRM_Campaigns' ) ) {
	BWFCRM_Core::register( 'campaigns', 'BWFCRM_Campaigns' );
}
