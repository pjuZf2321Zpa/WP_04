<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Base class for controller-style API routes in Pro.
 *
 * One class registers ALL routes for a directory via add_route().
 * Each route maps to a named handler method on the class.
 * Extends BWFCRM_API_Base for utility methods.
 *
 * Mirrors Lite's BWFAN_API_Controller but uses Pro's base class
 * and nocache_headers method.
 *
 * Usage:
 *   class BWFCRM_API_Tags_Controller extends BWFCRM_API_Controller {
 *       protected function register_routes() {
 *           $this->add_route( '/tags', [
 *               [ 'GET', 'get_tags', [ 'search' => [...] ] ],
 *               [ 'POST', 'create_tag' ],
 *           ]);
 *       }
 *       public function get_tags() { ... }
 *       public function create_tag() { ... }
 *   }
 *   BWFCRM_API_Tags_Controller::get_instance();
 */
abstract class BWFCRM_API_Controller extends BWFCRM_API_Base {

	public $public_api = false;

	public function __construct() {
		parent::__construct();
		$this->register_routes();
	}

	/**
	 * Child classes override this to register all their routes.
	 */
	abstract protected function register_routes();

	/**
	 * Not used in controllers — dispatch happens via named handlers.
	 */
	public function process_api_call() {
		return $this->error_response( __( 'Not supported', 'wp-marketing-automations-pro' ), null, 500 );
	}

	/**
	 * Permission callback for direct file-download routes (CSV exports, log files).
	 *
	 * Wire this as the per-route callback on download endpoints only — never as the
	 * controller-wide callback — so the nonce bypass cannot reach other routes.
	 *
	 * Identity is the primary gate: a logged-in user is authorised by the standard
	 * capability check. The shared bwf-nonce secret (the site's bwfan_unique_secret)
	 * is only a fallback for cookieless download links — e.g. a link opened directly
	 * in the browser with no auth cookie — because it travels in the URL and leaks
	 * into access logs, history and Referer headers. It is therefore consulted ONLY
	 * when there is no logged-in user, and compared with hash_equals() only when the
	 * secret is non-empty, so an unset/empty option can never satisfy the check.
	 *
	 * @param WP_REST_Request $request
	 *
	 * @return bool
	 */
	public function download_permission_callback( WP_REST_Request $request ) {
		// Prefer the authenticated user's capability over the URL-borne secret.
		if ( is_user_logged_in() ) {
			return $this->rest_permission_callback( $request );
		}

		$query_params = $request->get_query_params();
		$expected     = (string) get_option( 'bwfan_unique_secret', '' );
		$provided     = isset( $query_params['bwf-nonce'] ) ? (string) $query_params['bwf-nonce'] : '';

		return ( '' !== $expected && hash_equals( $expected, $provided ) );
	}

	/**
	 * Stream an existing file to the browser as an attachment download, then exit.
	 *
	 * The caller must resolve $filename to a validated path and confirm the file
	 * exists before calling this.
	 *
	 * @param string $filename Absolute path to the file to stream.
	 *
	 * @return void
	 */
	protected function serve_file_download( $filename ) {
		header( 'Content-Description: File Transfer' );
		header( 'Content-Type: application/octet-stream' );
		header( 'Cache-Control: no-cache, must-revalidate' );
		header( 'Expires: 0' );
		header( 'Content-Disposition: attachment; filename="' . basename( $filename ) . '"' );
		header( 'Content-Length: ' . filesize( $filename ) );
		header( 'Pragma: public' );

		// Clear system output buffer
		flush();
		readfile( $filename );
		exit;
	}

	/**
	 * Register a route with one or more HTTP method handlers.
	 *
	 * @param string      $route               Route path.
	 * @param array       $endpoints            Array of [ HTTP_METHOD, handler_method_name, ?args ].
	 * @param string|null $permission_callback  Optional method name for a custom permission callback.
	 */
	protected function add_route( $route, $endpoints, $permission_callback = null ) {
		$wp_methods = array(
			'GET'    => WP_REST_Server::READABLE,
			'POST'   => WP_REST_Server::CREATABLE,
			'PUT'    => WP_REST_Server::EDITABLE,
			'PATCH'  => WP_REST_Server::EDITABLE,
			'DELETE' => WP_REST_Server::DELETABLE,
		);

		$route_args = array();
		foreach ( $endpoints as $endpoint ) {
			$http_method  = $endpoint[0];
			$handler_name = $endpoint[1];
			$args         = isset( $endpoint[2] ) ? $endpoint[2] : array();

			if ( ! isset( $wp_methods[ $http_method ] ) ) {
				continue;
			}

			$wp_method  = $wp_methods[ $http_method ];
			$controller = $this;

			$route_args[] = array(
				'methods'             => $wp_method,
				'callback'            => function ( WP_REST_Request $request ) use ( $controller, $handler_name, $wp_method ) {
					return $controller->handle_request( $request, $handler_name, $wp_method );
				},
				'permission_callback' => $this->public_api
					? '__return_true'
					: ( $permission_callback ? array( $this, $permission_callback ) : array( $this, 'rest_permission_callback' ) ),
				'args'                => $args,
				'show_in_index'       => false,
			);
		}

		if ( ! empty( $route_args ) ) {
			register_rest_route( BWFAN_API_NAMESPACE, $route, $route_args );
		}
	}

	/**
	 * Standard request handling: parse params, set pagination, fire hooks, call handler.
	 *
	 * Shares request preparation with BWFCRM_API_Base::api_call() via prepare_request();
	 * the only controller-specific steps are setting $this->method from the matched
	 * route, resetting the response code, and dispatching to a named handler.
	 *
	 * @param WP_REST_Request $request      The REST request.
	 * @param string          $handler_name Method name to call.
	 * @param string          $wp_method    WP_REST_Server method constant.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_request( WP_REST_Request $request, $handler_name, $wp_method ) {
		$this->method = $wp_method;
		$this->prepare_request( $request );

		// Reset response code for each request
		$this->response_code = 200;

		try {
			do_action( 'bwfan_rest_call' );

			return $this->$handler_name();
		} catch ( Exception $e ) {
			$this->response_code = 500;

			return $this->error_response( $e->getMessage() );
		}
	}
}
