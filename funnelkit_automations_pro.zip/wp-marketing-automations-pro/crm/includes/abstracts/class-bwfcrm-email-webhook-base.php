<?php
/**
 * BWFCRM_Email_Webhook_Base Abstract Class
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BWFCRM_Email_Webhook_Base
 *
 */
#[\AllowDynamicProperties]
abstract class BWFCRM_Email_Webhook_Base {
	protected $_data = [];
	protected $_name = "";

	public function set_data( $data = [] ) {
		$this->_data = $data;
	}

	public function get_name() {
		return $this->_name;
	}

	abstract public function handle_webhook();

	protected function mark_contact_bounce( $contact_email, $context = [] ) {
		$contact = new BWFCRM_Contact( $contact_email );
		$before  = $this->contact_status_snapshot( $contact );
		if ( ! $contact->mark_as_bounced() ) {
			BWFAN_Core()->logger->log( "Unable to change contact status to bounce. Contact not found of email: $contact_email", 'crm_email_webhooks' );

			return;
		}

		$this->maybe_add_webhook_log_note( $contact, __( 'Bounced', 'wp-marketing-automations-pro' ), $context, $before );
	}

	protected function mark_contact_soft_bounce( $contact_email, $context = [] ) {
		$contact = new BWFCRM_Contact( $contact_email );

		/** Older FKA lite version do nothing */
		if ( ! method_exists( $contact, 'mark_as_soft_bounced' ) ) {
			return;
		}

		$before = $this->contact_status_snapshot( $contact );
		$result = $contact->mark_as_soft_bounced();
		if ( ! $result ) {
			BWFAN_Core()->logger->log( "Unable to change contact status to soft bounce. Contact not found of email: $contact_email", 'crm_email_webhooks' );

			return;
		}

		$this->maybe_add_webhook_log_note( $contact, __( 'Soft Bounced', 'wp-marketing-automations-pro' ), $context, $before );
	}

	protected function mark_contact_complaint( $contact_email, $context = [] ) {
		$contact = new BWFCRM_Contact( $contact_email );
		if ( method_exists( $contact, 'mark_as_complaint' ) ) {
			$before = $this->contact_status_snapshot( $contact );
			if ( ! $contact->mark_as_complaint() ) {
				BWFAN_Core()->logger->log( "Unable to change contact status to complaint. Contact not found of email: $contact_email", 'crm_email_webhooks' );

				return;
			}

			$this->maybe_add_webhook_log_note( $contact, __( 'Complaint', 'wp-marketing-automations-pro' ), $context, $before );

			return;
		}

		/** Older FKA lite version */
		$before = $this->contact_status_snapshot( $contact );
		if ( ! $contact->mark_as_bounced() ) {
			BWFAN_Core()->logger->log( "Unable to change contact status to complaint first then bounce. Contact not found of email: $contact_email", 'crm_email_webhooks' );

			return;
		}

		$this->maybe_add_webhook_log_note( $contact, __( 'Complaint', 'wp-marketing-automations-pro' ), $context, $before );
	}

	/**
	 * Snapshot the contact's current display status before a mark_* call so the log note can be gated
	 * on an actual status transition. Returns null when the status can't be read (older FKA lite or an
	 * invalid contact), in which case the note is always added — preserving prior behavior.
	 *
	 * @param BWFCRM_Contact $contact
	 *
	 * @return int|null Display status, or null when unknown.
	 */
	private function contact_status_snapshot( $contact ) {
		if ( ! $contact instanceof BWFCRM_Contact || ! method_exists( $contact, 'get_display_status' ) || ! $contact->is_contact_exists() ) {
			return null;
		}

		$status = $contact->get_display_status();

		return is_numeric( $status ) ? intval( $status ) : null;
	}

	/**
	 * Add the webhook log note only when the mark actually changed the contact's status. A retried or
	 * duplicate webhook re-marks a contact that is already in the target state (mark_as_* still returns
	 * truthy), which must not append a second note. Mirrors the transition guard the mark_as_* hooks use.
	 *
	 * @param BWFCRM_Contact $contact
	 * @param string         $status_label
	 * @param array          $context
	 * @param int|null       $before_status Display status captured before the mark (null => unknown).
	 */
	private function maybe_add_webhook_log_note( $contact, $status_label, $context, $before_status ) {
		if ( null !== $before_status ) {
			$after_status = $this->contact_status_snapshot( $contact );
			if ( null !== $after_status && $after_status === $before_status ) {
				/** No transition: contact was already in this state (webhook retry / duplicate delivery). */
				return;
			}
		}

		$this->add_webhook_log_note( $contact, $status_label, $context );
	}

	/**
	 * Add a 'log' type note to the contact recording the ESP webhook event
	 * (bounce / soft bounce / complaint) along with the relevant webhook data.
	 *
	 * @param BWFCRM_Contact $contact      Contact that was marked.
	 * @param string         $status_label Human readable status (Bounced / Soft Bounced / Complaint).
	 * @param array          $context      Per-contact webhook data to log (e.g. notification_type, reason).
	 */
	protected function add_webhook_log_note( $contact, $status_label, $context = [] ) {
		if ( ! $contact instanceof BWFCRM_Contact || ! $contact->is_contact_exists() || ! method_exists( $contact, 'add_note_to_contact' ) ) {
			return;
		}

		/** Allow disabling the auto-generated note per event */
		if ( false === apply_filters( 'bwfcrm_email_webhook_add_note', true, $this->_name, $status_label, $context, $contact ) ) {
			return;
		}

		$esp = ! empty( $this->_name ) ? $this->_name : __( 'Email service', 'wp-marketing-automations-pro' );

		/* translators: 1: status (Bounced/Soft Bounced/Complaint), 2: ESP name */
		$title = sprintf( __( 'Email %1$s reported by %2$s', 'wp-marketing-automations-pro' ), $status_label, $esp );

		$lines   = [];
		$lines[] = $this->format_webhook_log_line( __( 'Provider:', 'wp-marketing-automations-pro' ), $esp );
		$lines[] = $this->format_webhook_log_line( __( 'Status:', 'wp-marketing-automations-pro' ), $status_label );

		if ( is_array( $context ) ) {
			foreach ( $context as $key => $value ) {
				if ( null === $value || '' === $value || [] === $value ) {
					continue;
				}
				if ( is_array( $value ) || is_object( $value ) ) {
					$value = wp_json_encode( $value );
				}
				$label   = ucwords( str_replace( [ '_', '-' ], ' ', $key ) ) . ':';
				$lines[] = $this->format_webhook_log_line( $label, $value );
			}
		}

		$contact->add_note_to_contact( [
			'title' => $title,
			'body'  => implode( '<br>', $lines ),
			'type'  => 'log',
		] );
	}

	/**
	 * Format a single webhook log note line with a bold label for rich-text display.
	 *
	 * @param string $label Field label (include trailing colon).
	 * @param string $value Field value.
	 *
	 * @return string
	 */
	private function format_webhook_log_line( $label, $value ) {
		return sprintf(
			'<strong>%s</strong> %s',
			esc_html( $label ),
			esc_html( (string) $value )
		);
	}
}
