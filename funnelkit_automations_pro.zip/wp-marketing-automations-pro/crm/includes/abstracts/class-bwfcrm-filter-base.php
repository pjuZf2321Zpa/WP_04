<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


if ( ! class_exists( 'BWFAN_Filter_Base' ) ) {

	#[AllowDynamicProperties]
	abstract class BWFAN_Filter_Base {

		public $slug = '';

		public $name = '';

		protected $group_name = '';
		protected $group_priority = '';
		public $priority = 0;

		protected $filter = null;

		protected $table = '';
		protected $base_table = '';

		/** Table alias  */
		protected $alias = '';
		protected $base_alias = 'c';

		protected $columns = [];

		public $multiple = true;
		public $is_preference = false;
		public $type = 'search';

		/** @var bool|null */
		public $is_field_valid = null;

		/**
		 * @param $slug
		 *
		 * @return void
		 */
		public function set_slug( $slug ) {
			$this->slug = $slug;
		}

		/**
		 * @return mixed|string
		 */
		public function get_filter_slug() {
			return $this->slug;
		}

		/**
		 * @return mixed|string
		 */
		public function get_filter_name() {
			return $this->name;
		}

		/**
		 * @return mixed|string
		 */
		public function get_group_name() {
			return $this->group_name;
		}

		public function get_group_priority() {
			return $this->group_priority;
		}

		/**
		 * @param $query
		 *
		 * @return bool
		 */
		public function is_join_exist( $query ) {

			if ( false !== strpos( $query, $this->table ) ) {
				return true;
			}

			return false;
		}

		/**
		 * Sanitize column/key for safe use in SQL identifiers (no user input).
		 *
		 * @param string $key
		 * @return string
		 */
		protected function sanitize_column_key( $key ) {
			return preg_replace( '/[^a-zA-Z0-9_\-\.]/', '', (string) $key );
		}

		/**
		 * @param bool $comma_parse
		 * @return string
		 */
		public function prepare_query( $comma_parse = true ) {
			global $wpdb;

			$filter_value = $this->filter['value'];
			$filter_rule  = $this->filter['rule'];
			$filter_key   = $this->sanitize_column_key( $this->filter['key'] );
			if ( '' === $filter_key ) {
				return '';
			}

			if ( $comma_parse && is_string( $filter_value ) && strpos( $filter_value, ',' ) ) {
				$filter_value = explode( ',', $filter_value );
			}

			switch ( $filter_rule ) {
				case 'is':
					$filter_rule = is_array( $filter_value ) ? 'IN' : '=';
					break;
				case 'is_not':
					$filter_rule = is_array( $filter_value ) ? 'NOT IN' : '!=';
					break;
				case 'contains':
					$filter_rule  = 'LIKE';
					$filter_value = is_array( $filter_value ) ? array_map( function ( $fil_val ) use ( $wpdb, $filter_key ) {
						$like = '%' . $wpdb->esc_like( trim( $fil_val ) ) . '%';

						return $wpdb->prepare( "{$this->alias}.{$filter_key} LIKE %s", $like );
					}, $filter_value ) : '%' . $wpdb->esc_like( trim( $filter_value ) ) . '%';
					break;
				case 'not_contains':
					$filter_rule  = 'NOT LIKE';
					$filter_value = is_array( $filter_value ) ? array_map( function ( $fil_val ) use ( $wpdb, $filter_key ) {
						$like = '%' . $wpdb->esc_like( trim( $fil_val ) ) . '%';

						return $wpdb->prepare( "{$this->alias}.{$filter_key} NOT LIKE %s", $like );
					}, $filter_value ) : '%' . $wpdb->esc_like( trim( $filter_value ) ) . '%';
					break;
				case 'starts_with':
					$filter_rule  = 'LIKE';
					$filter_value = is_array( $filter_value ) ? array_map( function ( $fil_val ) use ( $wpdb, $filter_key ) {
						$like = $wpdb->esc_like( trim( $fil_val ) ) . '%';

						return $wpdb->prepare( "{$this->alias}.{$filter_key} LIKE %s", $like );
					}, $filter_value ) : $wpdb->esc_like( trim( $filter_value ) ) . '%';
					break;
				case 'ends_with':
					$filter_rule  = 'LIKE';
					$filter_value = is_array( $filter_value ) ? array_map( function ( $fil_val ) use ( $wpdb, $filter_key ) {
						$like = '%' . $wpdb->esc_like( trim( $fil_val ) );

						return $wpdb->prepare( "{$this->alias}.{$filter_key} LIKE %s", $like );
					}, $filter_value ) : '%' . $wpdb->esc_like( trim( $filter_value ) );
					break;
				case 'is_blank':
					$filter_rule  = '=';
					$filter_value = '';
					break;
				case 'is_not_blank':
					$filter_rule  = '!=';
					$filter_value = '';
					break;
				default:
					return '';
			}

			$if_column_exists = '';
			if ( in_array( $this->filter['rule'], array( 'not_contains', 'is_not', 'is_blank' ), true ) ) {
				$if_column_exists = "{$this->alias}.{$filter_key} IS NULL OR";
			}

			if ( 'is_not_blank' === $this->filter['rule'] ) {
				$if_column_exists = "{$this->alias}.{$filter_key} IS NOT NULL AND";
			}

			if ( is_array( $filter_value ) && in_array( $this->filter['rule'], array( 'contains', 'not_contains', 'starts_with', 'ends_with' ), true ) ) {
				$filter_value = array_filter( $filter_value );
				$sub_rule     = ( 'LIKE' === $filter_rule ) ? 'OR' : 'AND';
				$filter_value = implode( " {$sub_rule} ", $filter_value );

				return "($if_column_exists $filter_value)";
			}

			if ( is_array( $filter_value ) ) {
				$placeholders = implode( ', ', array_fill( 0, count( $filter_value ), '%s' ) );
				$filter_value = $wpdb->prepare( '(' . $placeholders . ')', array_map( 'trim', $filter_value ) );
			} else {
				$filter_value = $wpdb->prepare( '%s', $filter_value );
			}

			return "($if_column_exists {$this->alias}.{$filter_key} {$filter_rule} {$filter_value})";
		}

		public function prepare_query_for_json_array() {
			global $wpdb;

			$filter_value = $this->filter['value'];
			$key          = $this->sanitize_column_key( $this->filter['key'] );
			if ( '' === $key ) {
				return '';
			}

			if ( ! is_array( $filter_value ) ) {
				$filter_value = array( $filter_value );
			}
			$rule     = in_array( $this->filter['rule'], array( 'contains', 'is', 'any', 'all' ), true ) ? 'LIKE' : 'NOT LIKE';
			$sub_rule = ( 'LIKE' === $rule ) && ( 'all' !== $this->filter['rule'] ) ? 'OR' : 'AND';
			$query    = [];
			foreach ( $filter_value as $val_item ) {
				$val_item = ! is_array( $val_item ) ? explode( ',', $val_item ) : $val_item;
				$val_item = array_map( 'trim', $val_item );

				$val_item = array_map( function ( $val ) use ( $wpdb, $rule, $key ) {
					$like = '%"' . $wpdb->esc_like( $val ) . '"%';

					return $wpdb->prepare( "{$this->alias}.{$key} {$rule} %s", $like );
				}, $val_item );

				$val_item = array_filter( $val_item );
				$val_item = implode( " {$sub_rule} ", $val_item );

				$if_column_exists = ( 'NOT LIKE' === $rule ) ? "{$this->alias}.{$key} IS NULL OR" : '';
				$query[]          = ! empty( $if_column_exists ) ? "($if_column_exists ($val_item))" : "($val_item)";

			}

			return ! empty( $query ) ? '(' . implode( " {$sub_rule} ", $query ) . ')' : '';
		}

		public function get_oprator_name( $rule ) {
			$operators = [
				'==' => 'is',
				'!=' => 'is_not',
				'>'  => 'more_than',
				'<'  => 'less_than',
				'>=' => 'more_than_equal',
				'<=' => 'less_than_equal',
			];

			return isset( $operators[ $rule ] ) ? $operators[ $rule ] : $rule;
		}

		public function prepare_query_for_number() {
			global $wpdb;

			$filter_value         = $this->filter['value'];
			$this->filter['rule'] = $this->get_oprator_name( $this->filter['rule'] );
			$filter_rule          = $this->filter['rule'];
			$filter_key           = $this->sanitize_column_key( $this->filter['key'] );
			if ( '' === $filter_key ) {
				return '';
			}

			if ( is_string( $filter_value ) && strpos( $filter_value, ',' ) ) {
				$filter_value = explode( ',', $filter_value );
			}

			/** Only for Status filter */
			$include_unsub_query_or = '';
			if ( 'status' === $filter_key && 'is_not' === $filter_rule && in_array( $filter_value, array( 0, 1, 2, 4, 5 ), true ) ) {
				/** Using OR query because contact maybe not fall within status (0,1,2), but is present in unsubscribed table */
				$include_unsub_query_or = "OR EXISTS (SELECT 1 FROM {$wpdb->prefix}bwfan_message_unsubscribe AS unsub WHERE c.email = unsub.recipient )";
			}

			switch ( $filter_rule ) {
				case 'is':
					$filter_rule = is_array( $filter_value ) ? 'IN' : '=';
					break;
				case 'is_not':
					$filter_rule = is_array( $filter_value ) ? 'NOT IN' : '!=';
					break;
				case 'more_than':
					$filter_rule = '>';
					break;
				case 'more_than_equal':
					$filter_rule = '>=';
					break;
				case 'less_than':
					$filter_rule = '<';
					break;
				case 'less_than_equal':
				case 'less_then_equal':
					$filter_rule = '<=';
					break;
				case 'is_blank':
					$filter_rule  = '=';
					$filter_value = 0;
					break;
				case 'is_not_blank':
					$filter_rule  = '!=';
					$filter_value = 0;
					break;
				default:
					return '';
			}

			$if_column_exists = '';
			if ( in_array( $this->filter['rule'], array( 'less_than', 'is_not', 'is_blank', 'less_than_equal' ) ) ) {
				$if_column_exists = "{$this->alias}.{$filter_key} IS NULL OR";
			}

			if ( 'is_not_blank' === $this->filter['rule'] ) {
				$if_column_exists = "{$this->alias}.{$filter_key} IS NOT NULL AND";
			}

			/** check for property in case value 0 and rule is equal */
			if ( in_array( $this->filter['rule'], array( 'less_than', 'is' ) ) && 0 === absint( $filter_value ) ) {
				$if_column_exists = "{$this->alias}.{$filter_key} IS NULL OR";
			}

			/** check for property in case value 0 and rule is not equal */
			if ( 'is_not' === $this->filter['rule'] && 0 === absint( $filter_value ) ) {
				$if_column_exists = '';
			}

			if ( is_array( $filter_value ) ) {
				$placeholders  = implode( ', ', array_fill( 0, count( $filter_value ), '%d' ) );
				$filter_value  = $wpdb->prepare( '(' . $placeholders . ')', array_map( 'absint', $filter_value ) );
			} else {
				$filter_value  = $wpdb->prepare( '%d', absint( $filter_value ) );
			}

			return "($if_column_exists {$this->alias}.{$filter_key} {$filter_rule} {$filter_value} {$include_unsub_query_or})";
		}

		public static function _get_unsubscribers_query( $filter, $exclude_unsubs = false, $additional_info = [] ) {
			$exclude_unsub_query = "  NOT EXISTS ";
			$include_unsub_query = " EXISTS ";
			global $wpdb;
			$email_query      = "(SELECT 1 FROM {$wpdb->prefix}bwfan_message_unsubscribe AS unsub WHERE c.email = unsub.recipient )";
			$contact_no_query = "(SELECT 1 FROM {$wpdb->prefix}bwfan_message_unsubscribe AS unsub1 WHERE c.contact_no = unsub1.recipient )";
			if ( true === $exclude_unsubs ) {
				return "( $exclude_unsub_query  $email_query AND $exclude_unsub_query $contact_no_query )";
			}

			if ( ! empty( $additional_info['include_unsubscribe'] ) ) {
				return "( $include_unsub_query  $email_query AND $exclude_unsub_query $contact_no_query )";
			}

			/** Has to be valid filter */
			if ( ! is_array( $filter ) || ! isset( $filter['rule'] ) ) {
				return '';
			}

			$filter_value = isset( $filter['value'] ) ? absint( $filter['value'] ) : '';
			/** when "status is not unsubscribed" */
			if ( 'is_not' === $filter['rule'] && 3 === $filter_value ) {
				return "( $exclude_unsub_query  $email_query AND $exclude_unsub_query $contact_no_query )";
			}

			/** Include Un-subscribers when "status is unsubscribed" */
			if ( 'is' === $filter['rule'] && 3 === $filter_value ) {
				return "( $include_unsub_query  $email_query OR $include_unsub_query $contact_no_query )";
			}

			/** Exclude Un-subscribers if any status other than 3 (unsubscribed) and rule = 'is' 0(unverified), 1(subscribed), 2(bounced), 4(soft bounced), 5(complained)*/
			if ( 'is' === $filter['rule'] && in_array( $filter_value, array( 0, 1, 2, 4, 5 ), true ) ) {
				return "( $exclude_unsub_query  $email_query AND $exclude_unsub_query $contact_no_query )";
			}

			return '';
		}

		/**
		 * Whether the dual-input range-negation operator ('not_between') may be exposed.
		 *
		 * Its two-input "period" control is rendered by the Lite plugin's filter-type JS, shipped in
		 * Lite 3.8.4. Gate the operator on the Lite version so older Lite installs don't render a broken control.
		 *
		 * @return bool
		 */
		public static function supports_range_negation() {
			return defined( 'BWFAN_VERSION' ) && version_compare( BWFAN_VERSION, '3.8.4', '>=' );
		}

		public function prepare_date_query() {
			global $wpdb;

			$filter_key = $this->sanitize_column_key( $this->filter['key'] );
			if ( '' === $filter_key ) {
				return '';
			}
			if ( empty( $this->filter['value'] ) && 'is_blank' !== $this->filter['rule'] ) {
				return '';
			}

			/** to check if filter is for next days */
			$is_next = false !== strpos( $filter_key, 'next' );

			$symbol       = $is_next ? "+" : "-";
			$date         = new DateTime( 'now', wp_timezone() );
			$filter_value = '';
			if ( ! is_array( $this->filter['value'] ) ) {
				$filter_value = absint( $this->filter['value'] );
				$date->modify( "$symbol $filter_value days" );

				$filter_value = $date->format( 'Y-m-d' );
			} else {
				if ( 'next' !== $this->filter['rule'] ) {
					$filter_value = array();
					$from         = intval( $this->filter['value']['to'] ) ?? intval( $this->filter['value'][0] );
					$date->modify( "$symbol $from days" );
					$filter_value[] = $date->format( 'Y-m-d' );

					$to   = intval( $this->filter['value']['from'] ) ?? intval( $this->filter['value'][1] );
					$date = new DateTime( 'now', wp_timezone() );
					$date->modify( "$symbol $to days" );
					$filter_value[] = $date->format( 'Y-m-d' );
				}
			}

			$filter_rule = '';
			switch ( true ) {
				case 'over' === $this->filter['rule'] || 'before' === $this->filter['rule']:
					$filter_rule = '<';
					break;
				case 'after' === $this->filter['rule']:
					$filter_rule = '>';
					break;
				case 'past' === $this->filter['rule']:
					$filter_rule = '>=';
					break;
				case 'not_past' === $this->filter['rule']:
					/** Inclusive negation: before the cutoff OR never matched (NULL) — e.g. "not purchased in the last X days", including never-purchased contacts. */
					$filter_rule = '<';
					break;
				case 'between' === $this->filter['rule']:
				case 'not_between' === $this->filter['rule']:
					$filter_rule = 'between';
					if ( $is_next ) {
						$filter_value = array_reverse( $filter_value );
					}
					break;
				case 'next' === $this->filter['rule']:
					$date         = new DateTime( 'now', wp_timezone() );
					$before_date  = $date->format( 'Y-m-d' );
					$filter_value = [
						"$before_date 00:00:00",
						"$filter_value 23:59:59",
					];

					$filter_rule = 'between';
					break;
			}

			if ( 'is_blank' === $this->filter['rule'] ) {
				return "({$this->alias}.{$filter_key} IS NULL)";
			}

			if ( ! is_array( $filter_value ) ) {
				if ( 'not_past' === $this->filter['rule'] ) {
					return $wpdb->prepare( "({$this->alias}.{$filter_key} {$filter_rule} %s OR {$this->alias}.{$filter_key} IS NULL)", $filter_value );
				}

				return $wpdb->prepare( "({$this->alias}.{$filter_key} {$filter_rule} %s)", $filter_value );
			} else {
				/**
				 * Expand date-only range bounds to full days so DateTime columns are not clipped at midnight.
				 * Without this, a "0 to X days" range drops same-day records, e.g. col '2026-06-29 14:00:00'
				 * fails "<= '2026-06-29'" (widened to '2026-06-29 00:00:00'). This also aligns the SQL filter
				 * (System A) with the rule engine (System B), which already compares at day granularity.
				 * The 'next' rule already builds bounds with explicit times, so it is left untouched.
				 */
				$lower_bound = $filter_value[0];
				$upper_bound = $filter_value[1];
				if ( 'next' !== $this->filter['rule'] ) {
					$lower_bound = $filter_value[0] . ' 00:00:00';
					$upper_bound = $filter_value[1] . ' 23:59:59';
				}

				if ( 'not_between' === $this->filter['rule'] ) {
					/** Inclusive negation: outside the period OR never matched (NULL) — "not in the period", including never-matched contacts. */
					return $wpdb->prepare( "({$this->alias}.{$filter_key} < %s OR {$this->alias}.{$filter_key} > %s OR {$this->alias}.{$filter_key} IS NULL)", $lower_bound, $upper_bound );
				}

				return $wpdb->prepare( "({$this->alias}.{$filter_key} <= %s AND {$this->alias}.{$filter_key} >= %s)", $upper_bound, $lower_bound );
			}
		}

		public function get_date_filter_sql( $filter = [] ) {
			global $wpdb;

			$this->filter = is_array( $filter ) && count( $filter ) > 0 ? $filter : $this->filter;
			$filter_key   = $this->sanitize_column_key( $this->filter['key'] );
			if ( '' === $filter_key ) {
				return '';
			}
			if ( empty( $this->filter['value'] ) ) {
				if ( 'is_not_blank' === $this->filter['rule'] ) {
					return "({$this->alias}.{$filter_key} IS NOT NULL)";
				}

				return 'is_blank' === $this->filter['rule'] ? "({$this->alias}.{$filter_key} IS NULL)" : '';
			}

			if ( is_array( $this->filter['value'] ) && 1 === count( $this->filter['value'] ) ) {
				$this->filter['value'] = $this->filter['value'][0];
			}

			$format  = 'Y-m-d';
			$is_null = $filter_rule = '';

			if ( isset( $this->filter['type'] ) && intval( $this->filter['type'] ) === BWFCRM_Fields::$TYPE_DATETIME ) {
				$format = 'Y-m-d H:i:s';
			}
			if ( isset( $this->filter['type'] ) && intval( $this->filter['type'] ) === BWFCRM_Fields::$TYPE_TIME ) {
				$format = 'H:i';
			}

			if ( is_array( $this->filter['value'] ) ) {
				/** For 'between' rule */
				$from               = isset( $this->filter['value']['from'] ) ? $this->filter['value']['from'] : $this->filter['value'][0];
				$to                 = isset( $this->filter['value']['to'] ) ? $this->filter['value']['to'] : $this->filter['value'][1];
				$filter_before_date = bwfcrm_maybe_get_datetime( $from );
				$filter_after_date  = bwfcrm_maybe_get_datetime( $to );

				$filter_before_date = date( $format, $filter_before_date->getTimestamp() );
				$filter_after_date  = date( $format, $filter_after_date->getTimestamp() );
				if ( 'Y-m-d' === $format ) {
					$filter_before_date = "$filter_before_date 00:00:00";
					$filter_after_date  = "$filter_after_date 23:59:59";
				}

				$filter_rule = '=';
			} else {

				$filter_value = bwfcrm_maybe_get_datetime( $this->filter['value'], $format );
				$filter_date  = date( $format, $filter_value->getTimestamp() );
				if ( 'Y-m-d' === $format ) {
					$filter_before_date = "$filter_date 00:00:00";
					$filter_after_date  = "$filter_date 23:59:59";
				} else {
					$filter_after_date = $filter_before_date = $filter_date;
				}
				switch ( $this->filter['rule'] ) {
					case 'is':
					case 'on':
						$filter_rule = '=';
						break;
					case 'is_not':
						$filter_rule = '!=';
						$is_null     = "{$this->alias}.{$filter_key} IS NULL OR";
						break;
					case 'before':
					case 'is_before':
						$filter_rule = '<';
						break;
					case 'after':
					case 'is_after':
						$filter_rule = '>';
						break;
					case 'on_after':
						$filter_rule = '>=';
						break;
					case 'on_before':
						$filter_rule = '<=';
						break;
				}
			}

			if ( ! empty( $filter_rule ) && ( '=' !== $filter_rule || 'Y-m-d' !== $format ) ) {
				/** For 'more_than' and 'less_than' rules */
				$date_value = ( ( '>' === $filter_rule || '>=' === $filter_rule ) ? $filter_after_date : $filter_before_date );
				$where      = $wpdb->prepare( "({$is_null} {$this->alias}.{$filter_key} {$filter_rule} %s)", $date_value );
			} else {
				/** For 'is' and 'between' rules */
				$where = $wpdb->prepare( "({$this->alias}.{$filter_key} >= %s AND {$this->alias}.{$filter_key} <= %s)", $filter_before_date, $filter_after_date );
			}

			return $where;
		}


		public function prepare_query_for_bool() {
			$filter_value = $this->filter['value'];
			$filter_key   = $this->sanitize_column_key( $this->filter['key'] );
			if ( '' === $filter_key ) {
				return '';
			}
			$query        = '';
			switch ( $filter_key ) {
				case 'status':
					$filter_value = ( ( 'yes' === $filter_value ) ? 1 : 0 );
					$query        = "$this->alias.$filter_key = $filter_value";

					break;
				case 'has_purchased':
					if ( 'yes' === $filter_value ) {
						$query = "$this->alias.total_order_count > 0";
					} else {
						$query = "($this->alias.total_order_count = 0 OR $this->alias.total_order_count IS NULL )";
					}

					break;
				case 'user':
					if ( 'yes' === $filter_value ) {
						$query = "$this->alias.wpid > 0";
					} else {
						$query = "$this->alias.wpid = 0";
					}

					break;
				case 'has_used_any_coupons':
					if ( 'yes' === $filter_value ) {
						$query = "($this->alias.used_coupons IS NOT NULL AND $this->alias.used_coupons != '' AND $this->alias.used_coupons != '[]')";
					} else {
						$query = "($this->alias.used_coupons IS NULL OR $this->alias.used_coupons = '' OR $this->alias.used_coupons = '[]')";
					}

					break;
				case 'has_active_subscription':
					if ( 'yes' === $filter_value ) {
						$query = "$this->alias.active_subs_count > 0";
					} else {
						$query = "($this->alias.active_subs_count = 0 OR $this->alias.active_subs_count IS NULL )";
					}

					break;
				case 'has_bought_subscription':
					if ( 'yes' === $filter_value ) {
						$query = "$this->alias.cid IS NOT NULL";
					} else {
						$query = "$this->alias.cid IS NULL";
					}

					break;
				default:
					$query = "($this->alias.$filter_key = 0 OR $this->alias.$filter_key IS NULL )";
					if ( 'yes' === $filter_value ) {
						$query = "$this->alias.$filter_key > 0";
					}
			}

			return $query;
		}

		/**
		 * Build EXISTS query for any/all/none filters where each row has a single column value (e.g. oid, obj_id).
		 * "all" requires separate EXISTS per value; "any"/"none" use OR conditions.
		 *
		 * @param array  $filter_value   Values to match.
		 * @param string $filter_rule    any, all, none (or is, is_not, no).
		 * @param string $column         Column name (e.g. oid, obj_id, wfacp_id).
		 * @param string $extra_where    Extra SQL to append to each subquery (e.g. " AND egt.type = 1").
		 * @param string $subquery_alias Alias for subquery table (e.g. egt, pv).
		 * @param array  $none_rules     Rule values that mean "none" (e.g. ['none','no'] or ['none','is_not']).
		 * @return string
		 */
		protected function build_exists_query_single_value_column( $filter_value, $filter_rule, $column, $extra_where = '', $subquery_alias = null, $none_rules = [ 'none', 'no' ] ) {
			global $wpdb;

			if ( empty( $filter_value ) || ! is_array( $filter_value ) ) {
				return '';
			}

			$column         = $this->sanitize_column_key( $column );
			$subquery_alias = $subquery_alias ? $subquery_alias : $this->alias;
			$subquery_alias = $this->sanitize_column_key( $subquery_alias );
			if ( '' === $column || '' === $subquery_alias ) {
				return '';
			}

			$group_by   = " GROUP BY {$subquery_alias}.cid";
			$query_type = 'EXISTS';

			if ( 'is' === $filter_rule ) {
				$filter_rule = 'any';
			}
			if ( in_array( $filter_rule, [ 'is_not' ], true ) ) {
				$filter_rule = 'none';
			}

			if ( 'all' === $filter_rule ) {
				$exists_parts = [];
				foreach ( $filter_value as $val ) {
					$prepared_val  = $wpdb->prepare( '%s', $val );
					$exists_parts[] = " EXISTS (SELECT 1 FROM {$this->table} AS {$subquery_alias} WHERE {$this->base_alias}.id = {$subquery_alias}.cid AND {$subquery_alias}.{$column} = {$prepared_val}{$extra_where})";
				}

				return empty( $exists_parts ) ? '' : ' (' . implode( ' AND ', $exists_parts ) . ') ';
			}

			if ( in_array( $filter_rule, $none_rules, true ) ) {
				$query_type = 'NOT EXISTS';
				$group_by   = '';
			}

			$conditions = array_map( function ( $val ) use ( $wpdb, $column, $subquery_alias ) {
				return "{$subquery_alias}.{$column} = " . $wpdb->prepare( '%s', $val );
			}, $filter_value );
			$filter_conditions = implode( ' OR ', $conditions );

			return " $query_type (SELECT 1 FROM {$this->table} AS {$subquery_alias} WHERE {$this->base_alias}.id = {$subquery_alias}.cid AND ($filter_conditions){$extra_where}{$group_by})";
		}

		/**
		 * @return string
		 */
		public function get_where_query() {
			return '';
		}

		/**
		 * @param $query
		 *
		 * @return mixed|string
		 */
		public function get_join_query( $query = '' ) {
			return '';
		}

		public function get_columns() {
			return $this->columns;
		}

		/**
		 * @param $search
		 *
		 * @return array
		 */
		public function get_options( $search = '' ) {
			return [];
		}

		public function get_type() {
			return 'Text';
		}

		public function get_possible_operators() {
			return [];
		}

		public function get_value_label() {
			return '';
		}

		public function get_prefix() {
			return '';
		}

		public function get_default_value() {
			return '';
		}

		public function get_readable_text() {
			return '{{key /}} {{rule /}} {{value /}}';
		}

		/**
		 * Extra input props for the React filter UI, e.g. [ 'min' => 0, 'max' => 365 ] for a number/day input.
		 * Emitted as `extra_props`; Lite ignores keys it does not use.
		 *
		 * @return array
		 */
		public function get_extra_props() {
			return [];
		}

		public function is_select_multiple() {
			return $this->multiple;
		}

		public function get_value_as_key_label( $data ) {
			return array();
		}

		public function old_operators() {
			return [];
		}
	}

}