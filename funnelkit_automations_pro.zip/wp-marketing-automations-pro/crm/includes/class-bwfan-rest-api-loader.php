<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Public Api load class
 */
#[\AllowDynamicProperties]
class BWFAN_Rest_API_Loader {
	private static $ins = null;
	private static $registered_apis = array();

	public function __construct() {
		// add new menu on setting
		add_action( 'bwfan_filter_app_header_data', [ $this, 'bwfan_add_new_menu' ] );

		// Defer API class loading + route registration to rest_api_init with namespace gate
		add_action( 'rest_api_init', array( __CLASS__, 'maybe_load_and_register' ) );

		// adding localized data
		add_action( 'bwfan_admin_view_localize_data', array( $this, 'add_admin_view_localize_data' ), 10, 1 );

		add_action( 'bwfan_admin_settings_schema', array( $this, 'add_bwfan_admin_settings_schema' ), 10, 1 );

		/** If rest api addon is activated then remove the action */
		if ( class_exists( 'BWFAN_Addon_Public_API' ) ) {
			$rest_api_addon_ins = BWFAN_Addon_Public_API::get_instance();
			remove_action( 'plugins_loaded', [ $rest_api_addon_ins, 'bwfan_after_plugin_loaded' ] );
			remove_action( 'bwfcrm_api_classes_loaded', [ $rest_api_addon_ins, 'bwfan_load_admin_apis' ] );
		}
	}

	/**
	 * Route prefix → subdirectory mapping for selective file loading.
	 * Keyed by the first path segment after the namespace.
	 */
	private static $route_map = array(
		'broadcasts' => 'broadcasts',
		'contact'    => 'contacts',
		'contacts'   => 'contacts',
		'field'      => 'fields',
		'fields'     => 'fields',
		'list'       => 'lists',
		'lists'      => 'lists',
		'tag'        => 'tags',
		'tags'       => 'tags',
	);

	/**
	 * Load public API classes only when the request targets the public API namespace.
	 * Previously loaded on 'init' for every request — now deferred to rest_api_init
	 * and scoped to the matching route directory.
	 */
	public static function maybe_load_and_register() {
		$rest_route = isset( $_GET['rest_route'] ) ? sanitize_text_field( wp_unslash( $_GET['rest_route'] ) ) : ''; // phpcs:ignore
		if ( empty( $rest_route ) && isset( $_SERVER['REQUEST_URI'] ) ) {
			$rest_route = esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) );
		}

		// Route-level loading: resolve the target subdirectory from the request URL
		// and load only that directory. When the request is not for the public API
		// namespace, or its prefix is not mapped, load nothing.
		if ( defined( 'BWFAN_REST_API_NAMESPACE' ) ) {
			$dir = self::get_matching_directory( $rest_route );
			if ( null !== $dir ) {
				self::load_api_classes_for_dir( $dir );
			}
		}

		self::register_routes();
	}

	/**
	 * Resolve which subdirectory matches the current REST request URL.
	 *
	 * @param string $rest_route
	 *
	 * @return string|null Directory name, or null for full fallback.
	 */
	private static function get_matching_directory( $rest_route ) {
		// Strip the query string first so a namespace-like value in a query parameter
		// (e.g. /wp-json/wc/v3/x?ref=funnelkit-automations/y) cannot match the namespace.
		$qmark = strpos( $rest_route, '?' );
		if ( false !== $qmark ) {
			$rest_route = substr( $rest_route, 0, $qmark );
		}

		$ns  = BWFAN_REST_API_NAMESPACE;
		$pos = strpos( $rest_route, $ns );
		if ( false === $pos ) {
			return null;
		}

		$api_path = ltrim( substr( $rest_route, $pos + strlen( $ns ) ), '/' );
		$qpos     = strpos( $api_path, '?' );
		if ( false !== $qpos ) {
			$api_path = substr( $api_path, 0, $qpos );
		}

		if ( empty( $api_path ) ) {
			return null;
		}

		$first_segment = explode( '/', $api_path )[0];

		return isset( self::$route_map[ $first_segment ] ) ? self::$route_map[ $first_segment ] : null;
	}

	/**
	 * Load API class files only from one subdirectory.
	 *
	 * @param string $dir Directory name under /crm/includes/rest-api/.
	 */
	private static function load_api_classes_for_dir( $dir ) {
		$dir_path = __DIR__ . '/rest-api/' . $dir;
		if ( ! is_dir( $dir_path ) ) {
			return;
		}

		foreach ( glob( $dir_path . '/class-*.php' ) as $_field_filename ) {
			if ( ! is_readable( $_field_filename ) ) { // survive update file-swap / partial deploy
				continue;
			}
			require_once $_field_filename;
		}

		do_action( 'bwfan_public_api_classes_loaded' );
	}

	/**
	 * @return BWFAN_Rest_API_Loader
	 */
	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	public function bwfan_add_new_menu( $menu ) {
		if ( isset( $menu['settings_nav'] ) ) {
			$menu['settings_nav']['rest-api'] = [
				'name' => __( 'REST API', 'wp-marketing-automations-pro' ),
				'link' => admin_url( 'admin.php?page=autonami&path=/settings/rest-api' )
			];
		}

		return $menu;
	}

	/**
	 * registering public apis
	 *
	 * @param $api_class
	 */
	public static function register( $api_class ) {
		if ( empty( $api_class ) || ! class_exists( $api_class ) || ! method_exists( $api_class, 'get_instance' ) ) {
			return;
		}

		$api_slug = strtolower( $api_class );
		if ( false === strpos( $api_slug, 'bwfan\rest_api' ) ) {
			return;
		}

		/** @var BWFCRM_API_Base $api_obj */
		$api_obj = $api_class::get_instance();

		if ( empty( $api_obj->route ) ) {
			return;
		}

		self::$registered_apis[ $api_obj->route ][ $api_slug ] = $api_obj;
	}

	/**
	 * registering the routes dynamically
	 */
	public static function register_routes() {
		foreach ( self::$registered_apis as $route => $registered_api ) {
			if ( empty( $registered_api ) ) {
				continue;
			}

			$api_group = array_map( function ( $api ) {
				/** @var BWFAN_API_Base $api */
				if ( empty( $api->method ) ) {
					return false;
				}

				$route_args = array(
					'methods'             => $api->method,
					'callback'            => array( $api, 'api_call' ),
					'permission_callback' => array( __CLASS__, 'authenticate' ),
				);

				if ( is_array( $api->request_args ) && ! empty( $api->request_args ) ) {
					$route_args['args'] = $api->request_args;
				}

				return $route_args;
			}, $registered_api );

			$api_group = array_filter( $api_group );
			$api_group = array_values( $api_group );

			register_rest_route( BWFAN_REST_API_NAMESPACE, $route, $api_group );
		}

		do_action( 'bwfan_public_api_routes_registered', self::$registered_apis );
	}

	/**
	 * @param WP_REST_Request $request
	 * authenticating the request by api key
	 *
	 * @return bool
	 */
	public static function authenticate( WP_REST_Request $request ) {
		$query_params = $request->get_query_params();
		$method       = $request->get_method();

		if ( empty( $method ) ) {
			BWFCRM_Core()->response_handler->error_response( null, 405, '', 'method_not_allowed' );
		}

		/**
		 * Read the API key from a request header (Authorization: Bearer <key> or X-API-Key)
		 * so the secret need not travel in the URL, where it leaks into server access logs,
		 * browser history and Referer headers. Only consulted when the request carries no
		 * ?api_key= query parameter, so existing integrations stay fully backward compatible
		 * even on sites that send unrelated Authorization headers (HTTP Basic, JWT, etc.).
		 */
		if ( empty( $query_params['api_key'] ) ) {
			$header_key = self::get_api_key_from_headers( $request );
			if ( ! empty( $header_key ) ) {
				$query_params['api_key'] = $header_key;
			}
		}

		return self::authenticate_by_api_key( $query_params, $method );

	}

	/**
	 * Extract the API key from request headers.
	 *
	 * Supports `Authorization: Bearer <key>` and `X-API-Key: <key>`.
	 *
	 * @param WP_REST_Request $request
	 *
	 * @return string Sanitized API key, or an empty string when no key header is present.
	 */
	public static function get_api_key_from_headers( WP_REST_Request $request ) {
		$key  = '';
		$auth = $request->get_header( 'authorization' );

		/** Only a Bearer token is treated as the key; bare / Basic / Digest Authorization headers are ignored. */
		if ( ! empty( $auth ) && 0 === stripos( $auth, 'bearer ' ) ) {
			$key = trim( substr( $auth, 7 ) );
		}

		if ( empty( $key ) ) {
			$key = $request->get_header( 'x-api-key' );
		}

		return is_string( $key ) ? sanitize_text_field( $key ) : '';
	}

	/**
	 * @param $query_params
	 * @param $method
	 * authenticating api request coming from third party by api key
	 *
	 * @return bool
	 */
	public static function authenticate_by_api_key( $query_params, $method ) {
		if ( ! isset( $query_params['api_key'] ) || empty( $query_params['api_key'] ) ) {
			BWFCRM_Core()->response_handler->error_response( null, 401, '', 'api_key_missing' );
		}

		$api_key = $query_params['api_key'];
		// checking if the api key is correct or not
		$user = BWFAN_Rest_API_DB_Model::get_user_details_by_api( $api_key );
		if ( empty( $user ) ) {
			BWFCRM_Core()->response_handler->error_response( null, 401, '', 'api_key_invalid' );
		}

		// checking if the api key is activated for use. 1 - activated | 2 - revoked
		if ( 2 === absint( $user['status'] ) ) {
			BWFCRM_Core()->response_handler->error_response( null, 401, '', 'api_key_inactive' );
		}

		// checking if the api key has the appropriate permission
		if ( ! in_array( $method, self::get_api_request_methods( $user['permission'] ) ) ) {
			BWFCRM_Core()->response_handler->error_response( null, 401, '', 'permission_denied' );
		}

		// updating the last_access of the api key
		BWFAN_Rest_API_DB_Model::update_api_key_last_access( $user['id'] );

		return true;
	}

	/**
	 * adding public api active status
	 *
	 * @param BWFCRM_Base_React_Page $bwfcrm_brp_obj
	 *
	 * @return void
	 */
	public function add_admin_view_localize_data( $bwfcrm_brp_obj ) {
		$bwfcrm_brp_obj->page_data['is_public_api_active'] = true;
		$bwfcrm_brp_obj->page_data['googleFonts']          = $this->get_google_fonts_array();
		$bwfcrm_brp_obj->page_data['customFonts']          = apply_filters( 'bwfan_block_editor_custom_fonts', [] );
		$bwfcrm_brp_obj->page_data['imageSizes']           = $this->get_all_image_sizes();
		$bwfcrm_brp_obj->page_data['blockEditorVersion']   = defined( 'BWFAN_VERSION' ) && version_compare( BWFAN_VERSION, '3.7.2', '>' ) ? '2.1' : '1.0.6';
	}

	/**
	 * Returns available google fonts for block editor
	 *
	 * @return array
	 */
	public function get_google_fonts_array() {
		return apply_filters( 'bwfan_block_editor_google_fonts', [
			'Arvo',
			'Lato',
			'Lora',
			'Merriweather',
			'Merriweather Sans',
			'Noticia Text',
			'Open Sans',
			'Playfair Display',
			'Roboto',
			'Rubik',
			'Source Sans Pro',
		] );
	}

	/**
	 * Get all image sizes
	 *
	 * @return array
	 */
	public function get_all_image_sizes() {
		global $_wp_additional_image_sizes;

		$default_image_sizes = array( 'thumbnail', 'medium', 'medium_large', 'large' );

		foreach ( $default_image_sizes as $size ) {
			$image_sizes[ $size ]['width']  = get_option( $size . '_size_w' );
			$image_sizes[ $size ]['height'] = get_option( $size . '_size_h' );
			$image_sizes[ $size ]['crop']   = (bool) get_option( $size . '_crop' );
		}

		if ( isset( $_wp_additional_image_sizes ) && count( $_wp_additional_image_sizes ) ) {
			$image_sizes = array_merge( $image_sizes, $_wp_additional_image_sizes );
		}

		return $image_sizes;
	}

	/**
	 * 1 - only read permission (GET)
	 * 2 - only write permission (POST)
	 * 3 - both read and write permission (GET,POST,DELETE)
	 *
	 * @param $method
	 *
	 * @return string|string[]
	 */
	public static function get_api_request_methods( $method ) {
		if ( empty( $method ) ) {
			return array();
		}

		$request_methods = array(
			1 => array( 'GET' ),
			2 => array( 'POST' ),
			3 => array( 'GET', 'POST', 'DELETE' )
		);

		return isset( $request_methods[ $method ] ) ? $request_methods[ $method ] : '';
	}

	/**
	 * Add public API tab on settings
	 *
	 * @param $settings
	 *
	 * @return array
	 */
	public function add_bwfan_admin_settings_schema( $settings ) {
		$settings[0]['tabs'][] = array(
			'key'    => 'rest-api',
			'label'  => 'REST API',
			'fields' => [
				array(
					'id'   => 'bwfan_rest_api',
					'type' => 'bwfan_rest_api',
				),
			],
		);

		return $settings;
	}
}

new BWFAN_Rest_API_Loader();
