<?php
/**
 * Email Webhook Handler Controller Class
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BWFCRM_Email_Webhook_Handler
 *
 */
#[\AllowDynamicProperties]
class BWFCRM_Email_Webhook_Handler {
	private $_webhooks = [];

	private $_loaded = false;

	private static $ins = null;

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self;
		}

		return self::$ins;
	}

	/**
	 * Slug → webhook file map.
	 *
	 * Value may be a bare filename (loaded from the bundled email_webhooks/
	 * folder) or an absolute path — the latter lets add-ons register a provider
	 * whose class file lives outside this plugin. Extend via the filter.
	 *
	 * @return array
	 */
	public function get_webhook_files() {
		$files = array(
			'amazonses'    => 'class-bwfcrm-webhook-amazonses.php',
			'elasticemail' => 'class-bwfcrm-webhook-elastic-email.php',
			'mailgun'      => 'class-bwfcrm-webhook-mailgun.php',
			'mailjet'      => 'class-bwfcrm-webhook-mailjet.php',
			'pepipost'     => 'class-bwfcrm-webhook-pepipost.php',
			'postmark'     => 'class-bwfcrm-webhook-postmark.php',
			'sendgrid'     => 'class-bwfcrm-webhook-sendgrid.php',
			'sendinblue'   => 'class-bwfcrm-webhook-sendinblue.php',
			'sparkpost'    => 'class-bwfcrm-webhook-sparkpost.php',
		);

		return apply_filters( 'bwfcrm_email_webhook_files', $files );
	}

	/**
	 * Load a single webhook provider file by slug.
	 *
	 * @param string $slug Provider slug from the request (e.g. 'sendgrid').
	 *
	 * @return void
	 */
	public function load_webhook_file( $slug ) {
		if ( isset( $this->_webhooks[ $slug ] ) ) {
			return;
		}

		$files = $this->get_webhook_files();
		if ( ! isset( $files[ $slug ] ) ) {
			return;
		}

		/** Bare filename → resolve against the bundled folder; absolute path → use as-is. */
		$file = $files[ $slug ];
		if ( ! is_file( $file ) ) {
			$file = __DIR__ . '/email_webhooks/' . $file;
		}

		if ( is_file( $file ) ) {
			require_once( $file );
		}
	}

	/**
	 * Load every registered webhook class.
	 *
	 * Runs once. Deferred off `plugins_loaded` so the require_once + instantiation
	 * only happens when the bounce settings schema is built — not on every
	 * frontend/cron/ajax/admin request. Webhook delivery loads a single file
	 * instead (see load_webhook_file()).
	 */
	public function load_webhooks() {
		if ( true === $this->_loaded ) {
			return;
		}
		$this->_loaded = true;

		foreach ( array_keys( $this->get_webhook_files() ) as $slug ) {
			$this->load_webhook_file( $slug );
		}

		do_action( 'bwfcrm_api_email_webhooks_loaded' );
	}

	public function register( $webhook_class ) {
		if ( ! class_exists( $webhook_class ) || ! method_exists( $webhook_class, 'get_instance' ) ) {
			return;
		}

		$slug = strtolower( $webhook_class );
		if ( false === strpos( $slug, 'bwfcrm_webhook_' ) ) {
			return;
		}

		$slug = explode( 'bwfcrm_webhook_', $slug )[1];
		/** @var BWFCRM_Email_Webhook_Base $api_obj */
		$webhook = $webhook_class::get_instance();

		$this->_webhooks[ $slug ] = $webhook;
	}

	public function register_routes() {
		register_rest_route( BWFCRM_WEBHOOK_NAMESPACE, '/emails/(?P<slug>[a-zA-Z0-9-]+)/(?P<key>[a-zA-Z0-9-]+)', [
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_webhook' ),
				'permission_callback' => '__return_true',
				'show_in_index'       => false,
			),
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'handle_webhook' ),
				'permission_callback' => '__return_true',
				'show_in_index'       => false,
			)
		] );
	}

	public function handle_webhook( WP_REST_Request $request ) {
		BWFAN_PRO_Common::nocache_headers();
		$query_params   = $request->get_query_params();
		$query_params   = is_array( $query_params ) ? $query_params : array();
		$request_params = $request->get_params();
		$request_params = is_array( $request_params ) ? $request_params : array();
		$json_params    = $request->get_json_params();
		$json_params    = is_array( $json_params ) ? $json_params : array();
		$params         = array_replace( $query_params, $request_params );
		$params         = array_replace( $params, $json_params );
		$slug           = isset( $params['slug'] ) && ! empty( $params['slug'] ) ? $params['slug'] : '';

		$unique_key = get_option( 'bwfan_u_key', 0 );
		if ( ! isset( $params['key'] ) || empty( $unique_key ) || ! hash_equals( (string) $unique_key, (string) $params['key'] ) ) {
			BWFAN_Core()->logger->log( 'Email Webhook prevented: Invalid unique key', 'crm_email_webhooks' );

			wp_send_json_error( [
				'message' => 'Invalid Key.'
			] );
		}

		/**
		 * Skip only when bounce handling is *explicitly* disabled. An unset flag means the legacy
		 * default (webhooks were always processed before this setting gated them), so existing sites
		 * that wired bounce webhooks without a detected mailer plugin keep working after upgrade.
		 */
		$global_settings = BWFAN_Common::get_global_settings();
		if ( isset( $global_settings['bwfan_enable_bounce_handling'] ) && empty( $global_settings['bwfan_enable_bounce_handling'] ) ) {
			BWFAN_Core()->logger->log( 'Email Webhook prevented: Bounce handling disabled', 'crm_email_webhooks' );

			wp_send_json_error( [
				'message' => 'Bounce handling is disabled'
			] );
		}

		/** Load only the requested provider's file (settings page loads all via load_webhooks()). */
		$this->load_webhook_file( $slug );

		if ( ! isset( $this->_webhooks[ $slug ] ) ) {
			BWFAN_Core()->logger->log( "Email Webhook prevented: Webhook with slug doesn't exists. $slug", 'crm_email_webhooks' );

			wp_send_json_error( [
				'message' => 'No Such Email Provider exists: ' . $slug
			] );
		}

		$webhook = $this->_webhooks[ $slug ];
		if ( ! $webhook instanceof BWFCRM_Email_Webhook_Base ) {
			$class = get_class( $webhook );
			BWFAN_Core()->logger->log( "Email Webhook prevented: Invalid Webhook Class. $class", 'crm_email_webhooks' );
			wp_send_json_error( [
				'message' => 'Internal Email Webhook Error'
			] );

			return;
		}

		/**
		 * Only process the provider the site actually selected. Every provider endpoint shares the same
		 * unique key, so without this an Elastic Email payload POSTed to its URL would still mark contacts
		 * while Mailgun is the configured ESP. bwfan_bounce_select stores the lowercased provider name.
		 */
		$selected_provider = isset( $global_settings['bwfan_bounce_select'] ) ? strtolower( trim( $global_settings['bwfan_bounce_select'] ) ) : '';
		/** Match on the display name (how it is stored) or the slug — the latter rescues values saved before a provider rename (e.g. Sendinblue → Brevo). */
		if ( '' !== $selected_provider && strtolower( $webhook->get_name() ) !== $selected_provider && $slug !== $selected_provider ) {
			BWFAN_Core()->logger->log( "Email Webhook prevented: '$slug' is not the selected bounce provider ('$selected_provider')", 'crm_email_webhooks' );

			wp_send_json_error( [
				'message' => 'This email provider is not configured for bounce handling'
			] );
		}

		if ( 'amazonses' === $slug ) {
			$posted_data = file_get_contents( 'php://input' );

			if ( empty( $posted_data ) ) {
				BWFAN_Core()->logger->log( "No posted data for amazonses", 'crm_email_webhooks' );
				wp_send_json_error( [
					'message' => 'No data found'
				] );

				return;
			}
			$params       = json_decode( $posted_data, true );
			$message_data = is_array( $params ) && ! empty( $params['Message'] ) ? json_decode( $params['Message'], true ) : array();
			if ( ! empty( $message_data ) && is_array( $message_data ) ) {
				unset( $params['Message'] );
				$params = array_merge( $params, $message_data );
			}
		}

		/** Log webhook Request - Dev only */
		if ( ( defined( 'BWFAN_Email_Bounce_Log_Data' ) && true === BWFAN_Email_Bounce_Log_Data ) || true === apply_filters( 'bwfan_email_bounce_log_data', BWFAN_PRO_Common::is_log_enabled( 'bwfan_email_bounce_logging' ), $params ) ) {
			BWFAN_Common::log_test_data( 'Email bounce webhook data for service: ' . $slug, 'fka-email-webhook-request', true );
			BWFAN_Common::log_test_data( $params, 'fka-email-webhook-request', true );
		}

		$webhook->set_data( $params );
		$webhook->handle_webhook();

		wp_send_json( [
			'message' => 'Email webhook request submitted'
		], 200 );
	}

	public function get_webhooks() {
		$this->load_webhooks();

		$webhooks   = [];
		$unique_key = get_option( 'bwfan_u_key', 0 );
		$namespace  = BWFCRM_WEBHOOK_NAMESPACE;
		/**
		 * @var string $webhook
		 * @var BWFCRM_Email_Webhook_Base $webhook_obj
		 */
		foreach ( $this->_webhooks as $webhook => $webhook_obj ) {
			$webhooks[ $webhook ] = [
				'name' => $webhook_obj->get_name(),
				'link' => add_query_arg( array(), rest_url( "$namespace/emails/$webhook/$unique_key" ) )
			];
		}

		return $webhooks;
	}
}