<?php

if ( ! class_exists( 'BWFCRM_Load_Filters' ) ) {
	#[\AllowDynamicProperties]
	class BWFCRM_Load_Filters {

		public static $filters = [];
		public static $filter_classes = [];
		public static $ins = null;
		public static $filters_loaded = false;

		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function __construct() {
			add_action( 'bwfan_convert_filters_to_new_filters', array( $this, 'convert_to_new_filters' ) );
		}


		/**
		 * Include all the Filters class files
		 *
		 * @return void
		 */
		public static function load_filters() {
			do_action( 'bwfan_before_filters_load' );
			$filters_dir = BWFAN_PRO_PLUGIN_DIR . '/crm/includes/filters';
			require_once BWFAN_PRO_PLUGIN_DIR . '/crm/includes/abstracts/class-bwfcrm-filter-base.php';
			foreach ( glob( $filters_dir . '/*/class-*.php' ) as $filename ) {
				if ( ! is_readable( $filename ) ) { // survive update file-swap / partial deploy
					continue;
				}
				require_once( $filename );
			}
			do_action( 'bwfan_filters_loaded' );
		}

		/**
		 * Register the filter classes when the file is included
		 *
		 * @param $group
		 * @param $class
		 * @param $slug
		 *
		 * @return void
		 */
		public static function register( $group, $class, $slug = '' ) {
			if ( ! class_exists( $class ) || ! method_exists( $class, 'get_instance' ) ) {
				return;
			}
			$filter_obj = $class::get_instance();

			/** If filter's class object is from contact custom field filter then return */
			if ( $filter_obj instanceof BWFAN_Filter_BWF_CF ) {
				return;
			}

			if ( ! $filter_obj instanceof BWFAN_Filter_Base ) {
				return;
			}
			if ( ! empty( $slug ) ) {
				$filter_obj->set_slug( $slug );
			}

			if ( ! isset( self::$filters[ $group ]['title'] ) ) {
				self::$filters[ $group ]['title'] = $filter_obj->get_group_name();
			}
			if ( $filter_obj->get_group_priority() > 0 && ! isset( self::$filters[ $group ]['priority'] ) ) {
				self::$filters[ $group ]['priority'] = $filter_obj->get_group_priority();
			}
			$options = [];
			if ( ! in_array( strtolower( $filter_obj->get_type() ), array( 'search', 'product-qty' ) ) ) {
				$options = $filter_obj->get_options( '' );
			}
			self::$filters[ $group ]['rules'][] = [
				'slug'          => $filter_obj->slug,
				'type'          => $filter_obj->get_type(),
				'options'       => $options,
				'name'          => $filter_obj->get_filter_name(),
				'multiple'      => $filter_obj->is_select_multiple(),
				'operators'     => $filter_obj->get_possible_operators(),
				'readable_text' => $filter_obj->get_readable_text(),
				'value_label'   => $filter_obj->get_value_label(),
				'default'       => $filter_obj->get_default_value(),
				'priority'      => $filter_obj->priority,
				'preference'    => $filter_obj->is_preference,
				'extra_props'   => $filter_obj->get_extra_props(),
			];
			self::$filter_classes[ $slug ]      = $class;

		}

		/**
		 * @return array
		 */
		public function get_filters() {
			self::maybe_load_filters();

			/** Add contact custom field filters */
			$fields = BWFCRM_Fields::get_custom_fields( null, null, 1, 1, 1 );
			if ( ! empty( $fields ) ) {
				self::$filters['contact_custom_fields']['title'] = 'Custom Field';
				foreach ( $fields as $field ) {
					$field_filter_obj = new BWFAN_Filter_BWF_CF( [], $field['ID'] );
					if ( ! $field_filter_obj->is_field_valid ) {
						continue;
					}
					if ( $field_filter_obj->get_group_priority() > 0 && ! isset( self::$filters['bwf_contact_fields']['priority'] ) ) {
						self::$filters['contact_custom_fields']['priority'] = $field_filter_obj->get_group_priority();
					}
					self::$filters['contact_custom_fields']['rules'][] = [
						'slug'          => $field_filter_obj->slug,
						'type'          => $field_filter_obj->get_type(),
						'options'       => $field_filter_obj->get_options(),
						'name'          => $field_filter_obj->get_filter_name(),
						'multiple'      => $field_filter_obj->is_select_multiple(),
						'operators'     => $field_filter_obj->get_possible_operators(),
						'readable_text' => $field_filter_obj->get_readable_text(),
						'value_label'   => $field_filter_obj->get_value_label(),
						'default'       => $field_filter_obj->get_default_value(),
						'extra_props'   => $field_filter_obj->get_extra_props(),
						'priority'      => $field_filter_obj->priority,
						'preference'    => $field_filter_obj->is_preference,
					];
				}
			}

			/** Arrange filters according priority */
			self::$filters = array_map( function ( $filter ) {
				if ( isset( $filter['rules'] ) ) {
					$filter['rules'] = $this->set_priority( $filter['rules'] );
				}

				return $filter;
			}, self::$filters );

			return $this->set_priority( self::$filters );
		}

		/**
		 *
		 * @param $filters
		 *
		 * @return array|mixed
		 */
		public function set_priority( $filters ) {
			if ( empty( $filters ) ) {
				return [];
			}

			usort( $filters, function ( $a, $b ) {
				return $a['priority'] < $b['priority'] ? - 1 : 1;
			} );

			return $filters;
		}

		/**
		 * Prepare query according filters
		 *
		 * @param $rules
		 * @param $preferences
		 * @param $additional_info
		 * @param $search
		 *
		 * @return array
		 */
		public function get_prepared_query( $rules, $preferences = true, $additional_info = [], $search = '' ) {
			self::maybe_load_filters();

			$normalized_rules  = BWFCRM_Filters::_normalize_for_new_filters( $rules );
			$rules             = empty( $normalized_rules ) ? $rules : $normalized_rules;
			$final_join_query  = '';
			$final_where_query = [];
			foreach ( $rules as $data ) {
				if ( ! is_array( $data ) ) {
					continue; // Skip if not an array
				}
				/** OR */
				$where_query = [];
				foreach ( $data as $rule ) {
					/** AND */
					$rule = self::get_formatted_rule( $rule );
					$key  = $rule['key'];
					try {
						/** @var BWFAN_Filter_Base $filter_obj */
						if ( false !== strpos( $key, 'bwf_cf' ) ) {
							$field_id   = str_replace( 'bwf_cf', '', $key );
							$filter_obj = new BWFAN_Filter_BWF_CF( $rule, $field_id );
							if ( ! $filter_obj->is_field_valid ) {
								continue;
							}
						} else {
							$filter_class = isset( self::$filter_classes[ $key ] ) ? self::$filter_classes[ $key ] : '';
							if ( ! class_exists( $filter_class ) ) {
								continue;
							}
							$filter_class = str_replace( '-', '_', $filter_class );
							$filter_obj   = new $filter_class( $rule );
						}

						$join_query       = $filter_obj->get_join_query( $final_join_query );
						$final_join_query .= $join_query;
						$query            = $filter_obj->get_where_query();
						if ( ! empty( $query ) ) {
							$where_query[] = $query;
						}
					} catch ( Error $e ) {
						BWFAN_Common::log_test_data( $e->getMessage(), 'err-when-preparing-query', true );
					}
				}

				if ( ! empty( $where_query ) ) {
					$final_where_query[] = '(' . implode( ' AND ', $where_query ) . ')';
				}
			}

			/** Get columns & join query if saved column preferences */
			$columns_joins    = ( true === $preferences ) ? BWFCRM_Model_Contact::get_preference_columns_and_joins( $final_join_query, $additional_info ) : [];
			$columns          = isset( $columns_joins['columns'] ) ? $columns_joins['columns'] : "c.*";
			$final_join_query = isset( $columns_joins['join_query'] ) ? $columns_joins['join_query'] : $final_join_query;

			$final_where_query = implode( ' OR ', $final_where_query );
			$final_where_query = ! empty( $final_where_query ) ? " AND ( $final_where_query ) " : '';

			/** If wc column is set in order by */
			$order_by           = is_array( $additional_info ) && isset( $additional_info['order_by'] ) && ! empty( $additional_info['order_by'] ) ? $additional_info['order_by'] : 'last_modified';
			$order_column_alias = in_array( $order_by, BWFCRM_Filters::$wc_filters ) ? 'wc' : 'c';
			$order_by_column    = " {$order_column_alias}.{$order_by}";

			$customer_count = is_array( $additional_info ) && !empty( $additional_info['customer_count'] );

			/** if wc customer (bwf_wc_customers) table's columns is in $columns and wc customer table not in join query then join the table */
			global $wpdb;
			if ( ( false !== strpos( $order_by_column, 'wc.' ) && false === strpos( $final_join_query, 'bwf_wc_customer' ) ) || ( false === $preferences && $customer_count && false !== strpos( $columns, 'wc.' ) && false === strpos( $final_join_query, 'bwf_wc_customer' ) ) ) {
				$final_join_query .= " LEFT JOIN {$wpdb->prefix}bwf_wc_customers as wc ON c.id = wc.cid ";
			}

			/** If method called from broadcast */
			$is_broadcast = isset( $additional_info['is_broadcast'] ) && ! empty( $additional_info['is_broadcast'] );
			if ( $is_broadcast && false === strpos( $final_where_query, 'c.status = 1' ) ) {
				$final_where_query .= " AND ( c.status = 1 ) ";
			}

			/**
			 * Broadcasts exclude unsubscribed by default. The NOT EXISTS path has an is_broadcast
			 * short-circuit in lite; _get_unsubscribers_query_with_join() lacks it, so force
			 * exclude_unsubs here unless the caller explicitly opts in via include_unsubscribe.
			 */
			$exclude_unsubs = ! empty( $additional_info['exclude_unsubs'] )
				|| ( $is_broadcast && empty( $additional_info['include_unsubscribe'] ) );

			$unsub_for_status_modify = '';
			$unsub_query_append      = '';
			if ( $is_broadcast && false === strpos( $final_where_query, 'bwfan_message_unsubscribe' ) ) {
				$unsub_raw = BWFCRM_Model_Contact::_get_unsubscribers_query( [], $exclude_unsubs, $additional_info );

				if ( is_array( $unsub_raw ) ) {
					/**
					 * LEFT JOIN mode: 'join' lands in FROM; 'where' is routed by include_unsubscribe.
					 * NOT EXISTS returns "OR (…)" for include_unsubscribe so get_modified_status_query
					 * can splice it inside each c.status = N ) — reshape the "AND (…)" fragment to
					 * "OR (…)" so the left-join version inlines with the same OR semantics (status N
					 * OR present in unsub table). Without this it tail-ANDs and narrows to zero rows.
					 */
					if ( ! empty( $unsub_raw['join'] ) ) {
						$final_join_query .= $unsub_raw['join'];
					}
					$where_fragment = isset( $unsub_raw['where'] ) ? $unsub_raw['where'] : '';
					if ( ! empty( $additional_info['include_unsubscribe'] ) ) {
						$unsub_for_status_modify = ( 0 === strpos( $where_fragment, 'AND ' ) )
							? 'OR ' . substr( $where_fragment, 4 )
							: $where_fragment;
					} else {
						$unsub_query_append = $where_fragment;
					}
				} else {
					$unsub_for_status_modify = $unsub_raw;
					$unsub_query_append      = $unsub_raw;
				}
			}

			/** Start ID and End ID queries */
			$end_id         = is_array( $additional_info ) && isset( $additional_info['end_id'] ) && ! empty( $additional_info['end_id'] ) ? intval( $additional_info['end_id'] ) : 0;
			$exclude_end_id = is_array( $additional_info ) && isset( $additional_info['exclude_end_id'] ) && true === $additional_info['exclude_end_id'];
			$start_id       = is_array( $additional_info ) && isset( $additional_info['start_id'] ) && ! empty( $additional_info['start_id'] ) ? intval( $additional_info['start_id'] ) : 0;
			$include_ids    = is_array( $additional_info ) && isset( $additional_info['include_ids'] ) && is_array( $additional_info['include_ids'] ) ? $additional_info['include_ids'] : array();
			$exclude_ids    = is_array( $additional_info ) && isset( $additional_info['exclude_ids'] ) && is_array( $additional_info['exclude_ids'] ) ? $additional_info['exclude_ids'] : array();

			$final_where_query .= ! empty( $start_id ) ? " AND c.id > $start_id " : '';
			$end_id_operator   = ( true === $exclude_end_id ) ? '<' : '<=';
			$final_where_query .= ! empty( $end_id ) ? " AND c.id $end_id_operator $end_id " : '';

			/** Include Contacts into this query */
			$include_ids       = array_map( 'intval', $include_ids );
			$include_ids       = implode( ',', $include_ids );
			$final_where_query .= ! empty( $include_ids ) ? " AND c.id IN ({$include_ids}) " : '';

			/** Exclude Contacts from this query */
			$exclude_ids       = array_map( 'intval', $exclude_ids );
			$exclude_ids       = implode( ',', $exclude_ids );
			$final_where_query .= ! empty( $exclude_ids ) ? " AND c.id NOT IN ({$exclude_ids}) " : '';

			/** Include soft bounce, unverified and unsubscribe status. */
			if ( ! empty( $additional_info['include_soft_bounce'] ) || ! empty( $additional_info['include_unverified'] ) || ! empty( $additional_info['include_unsubscribe'] ) ) {
				$final_where_query = BWFCRM_Filters::get_modified_status_query( $final_where_query, $additional_info, $unsub_for_status_modify );
				if ( ! empty( $additional_info['include_unsubscribe'] ) ) {
					/** Splice happened inside status rewrite; don't tail-append. */
					$unsub_query_append = '';
				}
			}
			$final_where_query .= $unsub_query_append;

			/** Check if one of Email or Phone must not empty */
			$contact_mode      = is_array( $additional_info ) && isset( $additional_info['fetch_base'] ) ? intval( $additional_info['fetch_base'] ) : 1;
			$empty_email_check = ( 2 === $contact_mode ) ? " ( c.contact_no != '' AND c.contact_no IS NOT NULL )" : " ( c.email != '' AND c.email IS NOT NULL )";

			$base_query = "SELECT $columns FROM {$wpdb->prefix}bwf_contact AS c $final_join_query WHERE $empty_email_check AND ( 1=1 $final_where_query)  ";

			$count_columns = $customer_count ? "COUNT(DISTINCT c.id) AS contact_count, COUNT(DISTINCT wc.id) AS customer_count, sum(wc.`total_order_value`) AS total_revenue" : "COUNT(DISTINCT c.id) AS contact_count";

			if ( $customer_count && false !== strpos( $count_columns, 'wc.' ) && false === strpos( $final_join_query, 'bwf_wc_customer' ) ) {
				$final_join_query .= " LEFT JOIN {$wpdb->prefix}bwf_wc_customers as wc ON c.id = wc.cid ";
			}

			$count_query  = "SELECT $count_columns FROM {$wpdb->prefix}bwf_contact AS c $final_join_query WHERE $empty_email_check AND (1=1 $final_where_query) ";
			$search_query = $this->get_search_query( $search );
			if ( ! empty( $search_query ) ) {
				$base_query  .= " AND ( $search_query ) ";
				$count_query .= " AND ( $search_query ) ";
			}

			return [
				'base'           => $base_query,
				'total'          => $count_query,
				'needs_to_added' => isset( $columns_joins['needs_to_added'] ) ? $columns_joins['needs_to_added'] : []
			];
		}

		public static function get_formatted_rule( $rule ) {
			if ( ! isset( $rule['filter'] ) ) {
				return $rule;
			}
			$value = isset( $rule['data'] ) && is_array( $rule['data'] ) && isset( $rule['data'][0]['key'] ) ? array_column( $rule['data'], 'key' ) : $rule['data'];
			$value = empty( $value ) && isset( $rule['value'] ) ? $rule['value'] : $value;
			$value = is_array( $value ) ? $value : trim( $value );

			return [
				'key'   => $rule['filter'],
				'rule'  => isset( $rule['rule'] ) ? $rule['rule'] : '',
				'value' => $value
			];
		}

		/**
		 * @param $term
		 * @param $filter
		 *
		 * @return array
		 */
		public function get_filter_search_suggestions( $term = '', $filter = '' ) {
			self::maybe_load_filters();

			if ( empty( $filter ) ) {
				return [];
			}

			$filter_class = isset( self::$filter_classes[ $filter ] ) ? self::$filter_classes[ $filter ] : '';
			$field_id     = 0;
			if ( false !== strpos( $filter, 'bwf_cf' ) ) {
				$field_id     = str_replace( 'bwf_cf', '', $filter );
				$filter_class = 'BWFAN_Filter_BWF_CF';
			}

			if ( ! class_exists( $filter_class ) ) {
				return [];
			}
			if ( intval( $field_id ) > 0 ) {
				$filter_obj = new $filter_class( [], $field_id );
			} else {
				$filter_obj = new $filter_class();
			}

			if ( ! $filter_obj instanceof BWFAN_Filter_Base ) {
				return [];
			}

			return $filter_obj->get_options( $term );
		}

		/**
		 * Get search query
		 *
		 * @param $search
		 *
		 * @return string
		 */
		public function get_search_query( $search ) {
			global $wpdb;

			if ( empty( $search ) ) {
				return '';
			}

			/** Search Contact by f_name, l_name, contact_no (phone), email */
			$like = '%' . $wpdb->esc_like( $search ) . '%';
			$search_query = $wpdb->prepare(
				" ( c.email LIKE %s OR c.f_name LIKE %s OR c.l_name LIKE %s OR c.contact_no LIKE %s )",
				$like,
				$like,
				$like,
				$like
			);

			/** Get f_name and l_name from search string and append in query */
			if ( false !== strpos( $search, ' ' ) ) {
				$search_arr = explode( ' ', $search );
				$first_name = isset( $search_arr[0] ) ? $search_arr[0] : '';
				$last_name  = ! empty( end( $search_arr ) ) ? end( $search_arr ) : '';
				if ( ! empty( $first_name ) && ! empty( $last_name ) ) {
					$like_fn = '%' . $wpdb->esc_like( $first_name ) . '%';
					$like_ln = '%' . $wpdb->esc_like( $last_name ) . '%';
					$search_query .= $wpdb->prepare( " OR ( c.f_name LIKE %s AND c.l_name LIKE %s )", $like_fn, $like_ln );
				}
			}

			return $search_query;
		}

		/**
		 * Common method to load filters based on property value
		 *
		 * @return void
		 */
		public static function maybe_load_filters() {
			if ( ! self::$filters_loaded ) {
				self::$filters_loaded = true;
				self::load_filters();
			}
		}

		/**
		 * Convert old filters to new filters format across multiple tables
		 *
		 * @return void
		 */
		public function convert_to_new_filters() {
			global $wpdb;
			$start_time = time();

			$data_table        = get_option( 'convert_filters_data_table', 'bwfan_terms' );
			$last_processed_id = get_option( 'convert_filters_last_id', 0 );

			// Check if conversion is already completed
			if ( get_option( 'convert_filters_completed', false ) ) {
				bwf_unschedule_actions( 'bwfan_convert_filters_to_new_filters' );

				return;
			}

			do {
				/** Update audience filter data */
				if ( 'bwfan_terms' === $data_table ) {
					$last_id = intval( $last_processed_id ) > 0 ? intval( $last_processed_id ) : 0;
					$query   = $wpdb->prepare( "SELECT `ID`, `data` FROM `{$wpdb->prefix}bwfan_terms` WHERE `type` = %d AND `ID` > %d ORDER BY `ID` ASC LIMIT 0,30", 3, $last_id );
					$result  = $wpdb->get_results( $query, ARRAY_A );

					if ( is_array( $result ) && count( $result ) > 0 ) {
						foreach ( $result as $row ) {
							$id   = $row['ID'];
							$data = ! empty( $row['data'] ) ? json_decode( $row['data'], true ) : [];
							if ( ! empty( $data['filters'] ) && ! BWFCRM_Filters::is_new_filter( $data['filters'] ) ) {
								$data['filters'] = BWFCRM_Filters::convert_filters_to_new_filters( $data['filters'] );
								BWFAN_Model_Terms::update( [ 'data' => wp_json_encode( $data ) ], [ 'ID' => $id ] );
							}
							$last_processed_id = $id;
						}
						continue;
					} else {
						$data_table        = 'bwfan_import_export';
						$last_processed_id = 0;
					}
				}

				/** Update export filter data */
				if ( 'bwfan_import_export' === $data_table ) {
					$last_id = intval( $last_processed_id ) > 0 ? intval( $last_processed_id ) : 0;
					$query   = $wpdb->prepare( "SELECT `id`, `meta` FROM `{$wpdb->prefix}bwfan_import_export` WHERE `type` = %d AND `id` > %d ORDER BY `id` ASC LIMIT 0,30", 2, $last_id );
					$result  = $wpdb->get_results( $query, ARRAY_A );

					if ( is_array( $result ) && count( $result ) > 0 ) {
						foreach ( $result as $row ) {
							$id   = $row['id'];
							$meta = ! empty( $row['meta'] ) ? json_decode( $row['meta'], true ) : [];
							if ( ! empty( $meta['filters'] ) && ! BWFCRM_Filters::is_new_filter( $meta['filters'] ) ) {
								$meta['filters'] = BWFCRM_Filters::convert_filters_to_new_filters( $meta['filters'] );
								BWFAN_Model_Import_Export::update( [ 'meta' => wp_json_encode( $meta ) ], [ 'id' => $id ] );
							}
							$last_processed_id = $id;
						}
						continue;
					} else {
						$data_table        = 'bwfan_bulk_action';
						$last_processed_id = 0;
					}
				}

				/** Update bulk action filter data */
				if ( 'bwfan_bulk_action' === $data_table ) {
					$last_id = intval( $last_processed_id ) > 0 ? intval( $last_processed_id ) : 0;
					$query   = $wpdb->prepare( "SELECT `ID`, `meta` FROM `{$wpdb->prefix}bwfan_bulk_action` WHERE `ID` > %d ORDER BY `ID` ASC LIMIT 0,30", $last_id );
					$result  = $wpdb->get_results( $query, ARRAY_A );
					if ( is_array( $result ) && count( $result ) > 0 ) {
						foreach ( $result as $row ) {
							$id   = $row['ID'];
							$meta = ! empty( $row['meta'] ) ? json_decode( $row['meta'], true ) : [];
							if ( ! empty( $meta['contactFilters'] ) && ! BWFCRM_Filters::is_new_filter( $meta['contactFilters'] ) ) {
								$meta['contactFilters'] = BWFCRM_Filters::convert_filters_to_new_filters( $meta['contactFilters'] );
								BWFAN_Model_Bulk_Action::update( [ 'meta' => wp_json_encode( $meta ) ], [ 'ID' => $id ] );
							}
							$last_processed_id = $id;
						}
						continue;
					} else {
						$data_table        = 'bwfan_broadcast';
						$last_processed_id = 0;
					}
				}

				/** Update broadcast filter data */
				if ( 'bwfan_broadcast' === $data_table ) {
					$last_id = intval( $last_processed_id ) > 0 ? intval( $last_processed_id ) : 0;
					$query   = $wpdb->prepare( "SELECT `id`, `data` FROM `{$wpdb->prefix}bwfan_broadcast` WHERE `parent` = %d AND `id` > %d ORDER BY `id` ASC LIMIT 0,30", 0, $last_id );
					$result  = $wpdb->get_results( $query, ARRAY_A );
					if ( is_array( $result ) && count( $result ) > 0 ) {
						foreach ( $result as $row ) {
							$id   = $row['id'];
							$data = ! empty( $row['data'] ) ? json_decode( $row['data'], true ) : [];
							if ( ! empty( $data['filters'] ) && ! BWFCRM_Filters::is_new_filter( $data['filters'] ) ) {
								$data['filters'] = BWFCRM_Filters::convert_filters_to_new_filters( $data['filters'] );
								BWFAN_Model_Broadcast::update( [ 'data' => wp_json_encode( $data ) ], [ 'id' => $id ] );
							}
							$last_processed_id = $id;
						}
						continue;
					}
				}

				/** All tables processed - mark as completed */
				delete_option( 'convert_filters_data_table' );
				delete_option( 'convert_filters_last_id' );
				update_option( 'convert_filters_completed', true, false );

				bwf_unschedule_actions( 'bwfan_convert_filters_to_new_filters' );
				break;

			} while ( ( time() - $start_time ) < 20 );

			// Save progress to database (only if not completed)
			if ( ! get_option( 'convert_filters_completed', false ) ) {
				update_option( 'convert_filters_data_table', $data_table, false );
				update_option( 'convert_filters_last_id', $last_processed_id, false );
			}
		}
	}

	BWFCRM_Core::register( 'filters', 'BWFCRM_Load_Filters' );
}