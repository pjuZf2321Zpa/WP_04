<?php

/**
 * Mail Handler Controller for handling email sending operations
 * Can be overridden to implement custom mail sending functionality
 */
class BWFAN_Mail_Handler_Controller {
	/**
	 * @var int Batch limit for emails per second
	 */
	protected $batch_limit_per_second = 50;

	/**
	 * Constructor
	 */
	public function __construct() {
		// Initialize the controller
	}

	/**
	 * Set the batch limit for emails per second
	 *
	 * @param int $limit The limit to set
	 *
	 * @return void
	 */
	public function set_batch_limit_per_second( $limit ) {
		$this->batch_limit_per_second = absint( $limit );
	}

	/**
	 * Get the batch limit for emails per second
	 *
	 * @return int The batch limit
	 */
	public function get_batch_limit_per_second() {
		return $this->batch_limit_per_second;
	}

	/**
	 * Send a single email
	 *
	 * @param array|false $mail_data Formatted mail data, or false when formatting failed
	 *
	 * @return bool Whether the email was sent successfully
	 */
	public function send_mail( $mail_data ) {
		if ( false === $mail_data ) {
			return false;
		}

		$headers = array(
			'MIME-Version: 1.0',
			'From: ' . $mail_data['senders_name'] . ' <' . $mail_data['senders_email'] . '>',
			'Content-type: text/html;charset=UTF-8',
		);

		/**
		 * Built the same way as the v1 sender, so SMTP plugins that need a display name on
		 * Reply-To (and the bwfan_reply_to_header filter they hook) keep working on broadcasts.
		 */
		if ( ! empty( $mail_data['replyto'] ) ) {
			$reply_to_header = BWFAN_PRO_Common::build_reply_to_header( $mail_data['replyto'], '', $mail_data['senders_name'] ?? '' );
			if ( ! empty( $reply_to_header ) ) {
				$headers[] = $reply_to_header;
			}
		}

		/** Set unsubscribe link in header */
		if ( ! empty( $mail_data['unsubscribe_link'] ) ) {
			$headers[] = "List-Unsubscribe: <{$mail_data['unsubscribe_link']}>";
			$headers[] = "List-Unsubscribe-Post: List-Unsubscribe=One-Click";
		}

		BWFCRM_Broadcast_Helper::set_log( 'contact#' . $mail_data['contact_id'] . '_before_wp_mail' );

		/**
		 * Fired with the arguments the v1 sender passed: the broadcast's own data blob first,
		 * then the body.
		 *
		 * Handing the per-mail array as the first argument instead would have been a silent break.
		 * v1 passed the blob - listeners read `content`, `filters`, `is_promotional` and the rest
		 * off it - and because the arity is unchanged, such a listener would not error, it would
		 * simply find every key missing and do nothing. The per-mail array is appended as a third
		 * argument, which existing two-parameter listeners ignore.
		 */
		$broadcast_data = isset( $mail_data['broadcast_data'] ) && is_array( $mail_data['broadcast_data'] ) ? $mail_data['broadcast_data'] : array();

		do_action( 'bwfan_before_send_email', $broadcast_data, $mail_data['body'], $mail_data );

		/** Same filter the v1 sender applies, so header overrides are not lost on this path */
		$headers = apply_filters( 'bwfan_email_headers', $headers );

		/**
		 * A mailer that throws must not take the whole run with it. The caller records this
		 * send's outcome right after this returns; letting the throw escape would kill the
		 * request first, leaving the engagement unsent but still claimed - freed again by the
		 * orphan sweep, re-claimed first on the next run, and thrown on again forever.
		 */
		try {
			/** Process the email */
			$result = wp_mail( $mail_data['to'], $mail_data['subject'], $mail_data['body'], $headers );
		} catch ( Error|Exception $e ) {
			$result = false;
			/** Read back by the caller as this send's error message */
			if ( empty( BWFCRM_Common::$captured_email_failed_message ) ) {
				BWFCRM_Common::$captured_email_failed_message = $e->getMessage();
			}
		}

		BWFCRM_Broadcast_Helper::set_log( 'contact#' . $mail_data['contact_id'] . '_after_wp_mail' );

		/**
		 * Cast, because every consumer tests this with `true === $result`.
		 *
		 * wp_mail() returns a bool, but this method is the documented override point - a handler
		 * talking to a provider API naturally returns the message id it got back, and a truthy
		 * non-true value would then record every successful send as an error, fill failed_cids,
		 * and pause the broadcast on a send that worked perfectly.
		 */
		return (bool) $result;
	}

	/**
	 * Verify if the mail handler is properly configured and can connect to the mail service
	 *
	 * @return bool Whether the connection is successful
	 */
	public function verify_connection() {
		// Default implementation always returns true since wp_mail doesn't require external connection
		return true;
	}
}
