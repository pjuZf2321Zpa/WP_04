<?php

class BWFCRM_Broadcast_V2_Email_Controller {
	public $processing = null;
	public $engagements = array();
	public $engagement_contact_uids = [];

	/** Contact state of the current batch, read once per batch by the send loop */
	public $engagement_contact_states = [];

	/** Merge tags of the current batch, keyed on engagement id, read once per batch */
	public $engagement_merge_tags = [];
	public $offset = 0;
	public $processed = 0;
	public $count = 0;
	public $contact_ids = [];
	public $broadcast_id = 0;
	public $broadcast_data = [];
	public $broadcast = [];
	public $stop_broadcast_required = false;
	public $mail_handler = null;

	public $failed_cids = [];

	/** Failures since the last success, which is what pauses the broadcast */
	public $consecutive_failures = 0;

	/** Consecutive failures tolerated before the broadcast is paused */
	public static $CONSECUTIVE_FAILURE_LIMIT = 10;

	/** Mail bodies that failed to build since the last one that did - persisted like consecutive_failures */
	public $render_failures = 0;

	/**
	 * Consecutive build failures tolerated before the broadcast is halted
	 *
	 * One body that throws is that recipient's problem; ten in a row is the template's, and a
	 * template fault needs the broadcast halted so its content can be edited - paused refuses
	 * content edits, halted accepts them.
	 */
	public static $RENDER_FAILURE_LIMIT = 10;

	/**
	 * Per-run render cache, one entry per content variant - see maybe_prepare_render_cache()
	 *
	 * An entry is either a validated pre-rendered template (state 'validated') or a decision to
	 * keep building that variant per recipient (state 'fallback', with the reason). Never
	 * persisted: a run lasts seconds and content cannot change under a sending broadcast.
	 */
	private $render_cache = [];

	/** Template types the render cache understands; anything else builds per recipient */
	public static $RENDER_CACHE_TYPES = array( 'rich', 'html', 'editor', 'wc' );

	/**
	 * Stand-in for the per-recipient unsubscribe URL during a template render.
	 *
	 * A URL, not a bare token, and one that carries `bwfan-action=unsubscribe`: the link
	 * rewriter excludes unsubscribe URLs from click tracking by that substring, and a
	 * placeholder without it was click-wrapped at template level while the real URL is not -
	 * the one difference gate one can never accept. No `&` on purpose, so the string has a
	 * single serialised form in every context.
	 */
	public static $UNSUB_URL_PLACEHOLDER = 'https://bwfanunsub.invalid/__BWFANUNSUB__?bwfan-action=unsubscribe';

	/** Engagements claimed per batch when the per second limit gives no usable number */
	public static $CLAIM_BATCH_SIZE = 50;

	/** Seconds between the lock refreshes that keep a second worker out of engagement creation */
	public static $LOCK_REFRESH_SECONDS = 2;

	/** When the broadcast lock was last stamped by this run, 0 until the first stamp */
	private $lock_stamped_at = 0;

	/** Lite's own conversation object while this run works on a clone - see start_conversation_session() */
	private $original_conversation = null;

	public function __construct( BWFCRM_Broadcast_Processing $broadcast_processing ) {
		$this->processing   = $broadcast_processing;
		$this->contact_ids  = $broadcast_processing->contact_ids;
		$this->broadcast_id = $broadcast_processing->current_broadcast['id'];
		$this->broadcast    = $this->processing->current_broadcast;
	}

	/**
	 * Get the appropriate mail handler controller based on available handlers and their configurations
	 *
	 * @return BWFAN_Mail_Handler_Controller The mail handler controller instance
	 */
	public function get_mail_handler_controller() {
		/**
		 * No include here: the class is in the Pro autoload map, so it resolves on first
		 * reference. Loading it inside this method meant it did not exist until a broadcast was
		 * already sending, and `class X extends BWFAN_Mail_Handler_Controller` - the shape the
		 * bwfcrm_override_broadcast_mail_handler filter documents - fataled at plugin load.
		 */
		$mail_handler = new BWFAN_Mail_Handler_Controller();

		// Allow external plugins to override the mail handler controller
		$handler = apply_filters( 'bwfcrm_override_broadcast_mail_handler', $mail_handler );

		if ( $handler instanceof BWFAN_Mail_Handler_Controller ) {
			return $handler;
		}

		/**
		 * Say so rather than fall back in silence.
		 *
		 * A developer whose subclass failed to load, or who returned the wrong thing, otherwise
		 * sees no notice at all and every mail keeps going out through plain wp_mail() while they
		 * believe the override took effect.
		 */
		BWFCRM_Broadcast_Helper::set_log( 'bwfcrm_override_broadcast_mail_handler returned ' . ( is_object( $handler ) ? get_class( $handler ) : gettype( $handler ) ) . ', which does not extend BWFAN_Mail_Handler_Controller - falling back to the default handler' );

		// If the handler is not an instance of BWFAN_Mail_Handler_Controller, return the default
		return $mail_handler;
	}

	/**
	 * Fetch all the contacts of v2 broadcast and create engagement
	 *
	 * @return void
	 */
	public function create_v2_email_engagements() {
		$this->offset    = $this->broadcast['e_offset'] ?? 0;
		$this->processed = $this->broadcast['e_processed'] ?? 0;
		$this->count     = intval( $this->broadcast['count'] );
		BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' email engagements creation starts' );

		do {
			/**
			 * Creation runs for the whole one hour lead time, so an admin can pause, cancel,
			 * unschedule - or edit - the broadcast half way through it. Nothing else in this loop
			 * would notice - it turns only on time and memory, and the dispatcher's own checks are
			 * at the top of a foreach the worker is already past.
			 *
			 * The status alone is not enough to read. An edit to the content or the audience
			 * leaves the broadcast scheduled and only strips the preparation marker
			 * (reset_prepared_broadcast()), so a worker that tested the status kept inserting
			 * engagements with the old template id and the old merge tags for the rest of its call,
			 * racing the cleanup the edit queued. Rows it inserted after the cleanup's last pass
			 * survived, the re-preparation skipped those contacts as already engaged, and they
			 * were mailed the old body with the new variant's merge tags.
			 */
			if ( ! $this->is_preparation_still_valid() ) {
				BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' no longer preparing (status changed or preparation reset), stopping engagement creation' );
				break;
			}

			BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . '_before_fetch_contacts_for_create_engagements' );
			$this->contact_ids = BWFCRM_Broadcast_Helper::fetch_contacts_for_broadcast( $this->broadcast, $this );
			$error             = BWFCRM_Broadcast_Helper::error_while_fetching_contacts( $this->contact_ids, $this->broadcast_id, $this->broadcast['data'] );

			if ( $error ) {
				break;
			}

			if ( true === $this->stop_broadcast_required ) {
				$this->stop_broadcast_required = false;
				BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' stop broadcast required line 44' );

				break;
			}

			/** if no more contacts to process then set engagement created and return */
			if ( empty( $this->contact_ids ) ) {
				/**
				 * An empty page is only proof that the walk is finished if the query that
				 * produced it actually ran.
				 *
				 * error_while_fetching_contacts() catches a WP_Error and a malformed result
				 * shape, but a query rolled back by a deadlock - or a third party filter on the
				 * segment that momentarily matches nothing - returns a perfectly well formed
				 * empty list. engagements_created is written from here and never written back,
				 * so reading one of those as "the audience is covered" ends the broadcast for
				 * good: the dispatcher stops routing into creation, the send drains whatever was
				 * built, and update_status_to_complete() marks it done having mailed a fraction
				 * of the list, with nothing on the row or the report to say so.
				 */
				if ( true === BWFCRM_Broadcast_Helper::$last_contact_query_failed ) {
					BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' contact query returned no rows while still reporting an audience, leaving creation open' );
					$this->yield_run( true );

					break;
				}

				/**
				 * unset() cannot reach the stored blob: update_broadcast_data() re-reads the row
				 * and array_replace()s the keys handed to it, so a key merely missing from the
				 * snapshot survives. remove_hold_flag_smart_sending() is the one thing that
				 * actually deletes it.
				 */
				if ( isset( $this->broadcast['data']['winner'] ) && intval( $this->broadcast['data']['winner'] ) > 0 && isset( $this->broadcast['data']['hold_broadcast'] ) ) {
					BWFAN_Model_Broadcast::remove_hold_flag_smart_sending( absint( $this->broadcast['id'] ) );
					unset( $this->broadcast['data']['hold_broadcast'] );
				}

				/** Only the keys that changed - see the note on update_broadcast_data() */
				$created_keys = array( 'engagements_created' => 1 );

				/**
				 * The whole audience is built and smart sending never reached its test batch - contacts
				 * whose insert failed are not counted, so the percentage can stay out of reach. A winner
				 * would only choose for contacts that no longer exist, so close smart sending here
				 * rather than open a window over the ones already built.
				 */
				$b_data = $this->broadcast['data'];
				if ( BWFCRM_Broadcast_Helper::check_if_smart_send_enabled( $b_data ) && empty( $b_data['winner'] ) && empty( $b_data['smart_sending_done'] ) ) {
					$created_keys['smart_sending_done'] = 1;
					BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' audience exhausted before the smart send test batch, smart sending skipped' );
				}
				$this->update_broadcast_data( $created_keys );

				BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' no engagements left to create, we can begin to sending' );
				break;
			}

			$this->create_v2_broadcast_contact_email();

			/** Continue to next broadcast, in case needed to end the current broadcast process */
			if ( true === $this->stop_broadcast_required ) {
				$this->stop_broadcast_required = false;
				BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' stop broadcast required line 63' );
				break;
			}

			if ( $this->processing->is_time_exceeded() ) {
				$this->yield_run();
			}
		} while ( ! $this->processing->is_time_exceeded() && ! BWFCRM_Common::memory_exceeded() );

		/**
		 * Creation is over for this broadcast, so put the flag back.
		 *
		 * It is static and one request walks several broadcasts, so leaving it set would tell
		 * maybe_process_smart_send_v2() that a later v1 broadcast in the same loop is still
		 * creating engagements - and a v1 smart send would then hold without ever recording
		 * the hold, stalling on every run.
		 */
		BWFCRM_Broadcast_Helper::$engagement_creating = false;
	}

	/**
	 * processing each v2 contact
	 *
	 * @return void
	 */
	public function create_v2_broadcast_contact_email() {
		/**
		 * Contacts of this batch that already hold an engagement for this broadcast.
		 *
		 * e_offset is only persisted once the batch below completes, so a run that dies
		 * part way through leaves it stale and the next run re-fetches those contacts.
		 * Without this check they would each get a second engagement, and a second email.
		 */
		$existing_cids = $this->get_existing_engagement_cids( $this->contact_ids );
		$prep_id       = $this->broadcast['data']['prep_id'] ?? '';

		foreach ( $this->contact_ids as $id ) {
			BWFCRM_Broadcast_Helper::set_log( 'contact#' . $id . '_create_engagement' );
			if ( $this->processing->is_time_exceeded() || BWFCRM_Common::memory_exceeded() ) {
				break;
			}

			/** Hold the lock for as long as this run keeps creating, not just for its first five seconds */
			$this->touch_broadcast_lock();

			/**
			 *  Fallback, in case previously processed ID gets into loop again,
			 *  where offset must be old, and id must be new.
			 */
			if ( ! empty( $this->offset ) && $this->offset <= $id ) {
				continue;
			}

			/** Already created by an earlier run, count it and move the offset past it */
			if ( isset( $existing_cids[ absint( $id ) ] ) ) {
				BWFCRM_Broadcast_Helper::set_log( 'contact#' . $id . '_engagement_already_exists' );
				$this->processed ++;
				$this->offset = $id;

				continue;
			}

			BWFCRM_Broadcast_Helper::$engagement_creating = true;

			/** Check for smart sending before */
			$smart_send_enabled = BWFCRM_Broadcast_Helper::check_if_smart_send_enabled( $this->broadcast['data'] );

			if ( $smart_send_enabled ) {
				/** Check if Smart sending needs to process */
				$smart_send = BWFCRM_Broadcast_Helper::maybe_process_smart_send_v2( $this->broadcast, $this->processed, $this->count, $this->broadcast['type'] );
				BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' smart send value: ' . $smart_send );
				if ( 'hold' === $smart_send ) {
					if ( ! $this->is_same_preparation( $prep_id ) ) {
						$this->stop_broadcast_required = true;
						break;
					}

					/**
					 * The test batch's engagements exist now, so hand the broadcast over to its
					 * sending phase. Leaving engagements_created at 0 kept the dispatcher routing
					 * straight back into creation, so the test batch was never actually sent and
					 * the winner ended up being resolved a minute later from an empty stats table.
					 *
					 * hold_broadcast is deliberately not set here. Nothing is on hold yet - these
					 * engagements still have to go out, and it is their sending that the window
					 * is measured from.
					 */
					$this->update_broadcast_data( array( 'engagements_created' => 1 ) );
					BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' smart send test batch created, moving to send phase' );
					$this->stop_broadcast_required = true;
					break;
				}
				if ( ! isset( $this->broadcast['data']['winner'] ) && intval( $smart_send ) > 0 ) {
					$this->broadcast['data']['winner']             = $smart_send;
					$this->broadcast['data']['smart_sending_done'] = 1;
				}
			}

			/** A failed contact is not retried: the offset moves past it either way, only a created row counts */
			if ( $this->create_contact_engagement( $this->broadcast, $id ) ) {
				$this->processed ++;
			} else {
				BWFCRM_Broadcast_Helper::set_log( 'contact#' . $id . ' engagement insert failed, skipped' );
			}
			$this->offset = $id;
		}

		if ( ! $this->is_same_preparation( $prep_id ) ) {
			$this->stop_broadcast_required = true;
			$this->processing->reset_contact_cache();

			return;
		}

		/** Update engagement processed & offset */
		BWFAN_Model_Broadcast::update( [
			'e_processed' => $this->processed,
			'e_offset'    => $this->offset,
		], [ 'id' => $this->broadcast['id'] ] );

		/** Fetching the next batch happens outside the loop above, so carry the lock over it */
		$this->touch_broadcast_lock( true );

		/** Nothing in the next batch can hit this batch's contacts, and it is never emptied otherwise */
		$this->processing->reset_contact_cache();
	}

	/**
	 * Whether the broadcast is still on the preparation this batch started on
	 *
	 * A content, audience or schedule save during the batch resets the preparation and queues the
	 * cleanup of the rows just inserted, and another runner can prepare it again before this batch
	 * writes anything. The row then reads as a valid fresh preparation - prepared_for holds the
	 * execution time, so it comes back with the same value - and counters written onto it claim
	 * contacts whose rows the cleanup deletes. prep_id is new on every preparation.
	 *
	 * Broadcasts prepared before prep_id existed carry none, and are not checked.
	 *
	 * @param string $prep_id prep_id the batch started with
	 *
	 * @return bool
	 */
	private function is_same_preparation( $prep_id ) {
		if ( empty( $prep_id ) ) {
			return true;
		}

		$row  = BWFAN_Model_Broadcast::get( absint( $this->broadcast['id'] ) );
		$data = ! empty( $row['data'] ) ? json_decode( $row['data'], true ) : array();
		if ( is_array( $data ) && isset( $data['prep_id'] ) && $prep_id === $data['prep_id'] ) {
			return true;
		}

		BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' preparation changed during this batch, counters not written' );

		return false;
	}

	/**
	 * Create engagements for the contacts that entered the segment after creation finished
	 *
	 * Engagements are built up to an hour ahead of the execution time, so the segment can still
	 * gain contacts in between. Creation cannot reach them: it walks contact ids downwards from
	 * the highest one it saw, feeding e_offset to the query as end_id, and a contact added since
	 * has a higher id than anything that walk ever started from. This runs the complementary
	 * cursor - everything above the highest contact the broadcast already has an engagement for,
	 * ascending - so each pass carries on from where the last one stopped.
	 *
	 * One sweep, as the broadcast becomes due, covers the whole window: the cursor starts at the
	 * mark left when creation finished, so a contact added a minute into the hour and one added at
	 * the fifty ninth minute are both above it and both picked up by the same walk. Checking
	 * repeatedly through the wait would find the same contacts earlier without finding any more.
	 *
	 * It never runs once sending has begun. From the first mail the audience is closed: a contact
	 * added at minute forty of the send was never part of what this broadcast was addressed to, and
	 * a list that keeps growing underneath the send leaves it without a finish line.
	 *
	 * A contact that merely started matching the filters - picked up a tag, placed an order - is
	 * out of reach either way, since its id is below the mark and creation has already walked past
	 * it. This covers contacts created since, which is what the window is actually about.
	 *
	 * @return bool False when the sweep ran out of the call's time budget with contacts still to
	 *               cover, in which case sending waits for the next pass rather than close the
	 *               audience over them
	 */
	public function maybe_create_topup_engagements() {
		$data = is_array( $this->broadcast['data'] ) ? $this->broadcast['data'] : array();

		/** Creation has not finished, so it is still reaching these contacts on its own */
		if ( empty( $data['engagements_created'] ) ) {
			return true;
		}

		/** The window is closed, either by a previous pass or by the first mail going out */
		if ( ! empty( $data['topup_done'] ) || intval( $this->broadcast['processed'] ) > 0 ) {
			return true;
		}

		/**
		 * A resend takes its audience from the parent broadcast's non openers rather than from a
		 * live segment, so a contact created since has nothing here to be added to.
		 */
		if ( ! empty( $this->broadcast['parent'] ) ) {
			return true;
		}

		/**
		 * Smart send measures one fixed audience: the test batch is a percentage of count, and the
		 * winner is read off what that slice did. Growing the list underneath it changes what is
		 * being measured, so these broadcasts keep the audience they were scheduled with.
		 */
		if ( BWFCRM_Broadcast_Helper::check_if_smart_send_enabled( $data ) ) {
			return true;
		}

		$args = BWFCRM_Broadcast_Helper::get_broadcast_query_args( $this->broadcast );
		if ( ! is_array( $args ) || ! isset( $args['props'] ) ) {
			return true;
		}

		/**
		 * Same opt-out creation honours. Without it a site using this filter to keep
		 * unsubscribers out of every broadcast would have them let back in through the top up,
		 * which is the one path that adds recipients after the audience was built.
		 */
		if ( ! isset( $args['props']['exclude_unsubs'] ) || false === $args['props']['exclude_unsubs'] ) {
			$args['props']['exclude_unsubs'] = apply_filters( 'bwfan_force_exclude_unsubscribe_contact', false );
		}

		$cursor = isset( $data['topup_offset'] ) ? absint( $data['topup_offset'] ) : 0;
		if ( empty( $cursor ) ) {
			$cursor = BWFCRM_Broadcast_Helper::get_max_engaged_contact_id( $this->broadcast['id'] );

			/** No engagement to sit above, so there is nothing here that a top up would add to */
			if ( empty( $cursor ) ) {
				return true;
			}
		}

		/**
		 * Written before any work rather than only once a batch has produced something: the mark
		 * is read off MAX(cid) over every engagement of the broadcast, and a sweep too large for
		 * one call would pay for that scan again on each pass it takes.
		 */
		$this->update_broadcast_data( array( 'topup_offset' => $cursor ) );

		/** Take the lock for this run exactly as the dispatcher does before creation */
		$this->touch_broadcast_lock( true );

		$this->processed = intval( $this->broadcast['e_processed'] ?? 0 );
		$batch_size      = BWFCRM_Broadcast_Helper::$CONTACT_BATCH_COUNT;
		$halted          = false;

		BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' top up starts above contact#' . $cursor );

		do {
			/**
			 * Ascending from the mark, not descending as creation runs. The cursor moves up to the
			 * last id of each batch, so a descending walk would begin at the newest contact and
			 * leave everything between it and the mark without an engagement.
			 */
			$props                = $args['props'];
			$props['start_id']    = $cursor;
			$props['order_by']    = 'id';
			$props['order']       = 'ASC';
			/** On, so the count comes back out of get_contacts() - see the note below */
			$props['grab_totals'] = true;
			unset( $props['end_id'], $props['exclude_end_id'] );

			$contacts_array = BWFCRM_Contact::get_contacts( '', 0, $batch_size, $args['filters'], $props, OBJECT );

			/**
			 * Same tell as create_v2_email_engagements() uses: a page with no rows while the
			 * count alongside it still reports an audience is a query that failed, not a walk
			 * that finished. Falling through here writes topup_done = 1, which closes the window
			 * for good, so the two must not be confused. $wpdb->last_error cannot be used - the
			 * count runs after the page and clears it.
			 *
			 * The count is run by the model either way; `grab_totals` only decides whether
			 * get_contacts() passes it back, and it arrives as `total_count`.
			 */
			$reported_total = is_array( $contacts_array ) && isset( $contacts_array['total_count'] ) ? absint( $contacts_array['total_count'] ) : 0;

			if ( ! is_array( $contacts_array ) || empty( $contacts_array['contacts'] ) || ! is_array( $contacts_array['contacts'] ) ) {
				if ( $reported_total > 0 ) {
					BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' top up query returned no rows while still reporting an audience, leaving the window open' );

					return false;
				}

				break;
			}

			$contact_ids = array_map( function ( $contact ) {
				return $contact->get_id();
			}, $contacts_array['contacts'] );

			/**
			 * The query already orders ascending, but the cursor's whole meaning is "everything up
			 * to here is covered" - so sort rather than trust it. Out of order, a batch that breaks
			 * on the call budget would leave the mark above ids it never reached.
			 */
			sort( $contact_ids );

			/** Same guard creation uses: a run that died part way through must not create a second engagement */
			$existing_cids = $this->get_existing_engagement_cids( $contact_ids );
			$created       = 0;

			foreach ( $contact_ids as $id ) {
				if ( $this->processing->is_time_exceeded() || BWFCRM_Common::memory_exceeded() ) {
					$halted = true;
					break;
				}

				$this->touch_broadcast_lock();

				/**
				 * The cursor moves whether or not an engagement comes of it. A contact creation
				 * turns down - no address on record, deleted since the query ran - would otherwise
				 * hold the mark where it is and every later pass would start on it again.
				 */
				$cursor = absint( $id );

				if ( isset( $existing_cids[ absint( $id ) ] ) ) {
					continue;
				}

				if ( ! $this->create_contact_engagement( $this->broadcast, $id ) ) {
					BWFCRM_Broadcast_Helper::set_log( 'contact#' . $id . ' engagement insert failed, skipped' );
					continue;
				}
				$this->processed ++;
				$created ++;
			}

			$this->persist_topup_progress( $cursor, $created );

			if ( true === $halted ) {
				break;
			}
		} while ( ! $this->processing->is_time_exceeded() && ! BWFCRM_Common::memory_exceeded() );

		BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' top up stopped at contact#' . $cursor . ( $halted ? ' on the call budget' : ' with no contacts left' ) );

		/** Out of time with contacts still to cover, so the window stays open for the next pass */
		if ( true === $halted ) {
			return false;
		}

		$this->update_broadcast_data( array( 'topup_done' => 1 ) );

		return true;
	}

	/**
	 * Write what a top up batch produced
	 *
	 * @param int $cursor Contact id the batch stopped on
	 * @param int $created Engagements this batch created
	 *
	 * @return void
	 */
	private function persist_topup_progress( $cursor, $created ) {
		$this->update_broadcast_data( array( 'topup_offset' => absint( $cursor ) ) );

		if ( empty( $created ) ) {
			return;
		}

		/**
		 * count is written once when the broadcast is scheduled and is what the campaign screen
		 * reports against, so contacts added since have to be added to it or every total reads
		 * short for the rest of the run.
		 *
		 * Added in SQL rather than written as this run's absolute figure: both columns were read
		 * into a snapshot at the top of the call, and another worker on the same broadcast can
		 * have moved them in the meantime - which is exactly the mistake increment_campaign_offsets()
		 * was rewritten to stop making.
		 */
		BWFAN_Model_Broadcast::increment_topup_counters( $this->broadcast['id'], $created );

		/** Keep the in-memory rows roughly in step; the stored value is the one that counts */
		$this->broadcast['count'] = intval( $this->broadcast['count'] ) + intval( $created );
		if ( is_array( $this->processing->current_broadcast ) ) {
			$this->processing->current_broadcast['count'] = $this->broadcast['count'];
		}
	}

	/**
	 * Merge keys into the stored broadcast data and keep the in memory rows in step
	 *
	 * BWFAN_Model_Broadcast::update_broadcast_data() re-reads the row and merges, so it carries
	 * nothing of this request's copy over anything written meanwhile.
	 *
	 * @param array $keys Keys to write
	 *
	 * @return void
	 */
	private function update_broadcast_data( $keys ) {
		BWFAN_Model_Broadcast::update_broadcast_data( $this->broadcast['id'], $keys );

		$this->broadcast['data'] = array_replace( is_array( $this->broadcast['data'] ) ? $this->broadcast['data'] : array(), $keys );
		if ( is_array( $this->processing->current_broadcast ) ) {
			$this->processing->current_broadcast['data'] = $this->broadcast['data'];
		}
	}

	/**
	 * Keep this broadcast marked as being worked on while engagements are created
	 *
	 * maybe_broadcast_running() reads last_modified and treats a broadcast as taken only for five
	 * seconds after it was written. The dispatcher stamps it once before handing over, but creation
	 * runs until the call time budget is spent - so without refreshing it here the lock lapses
	 * mid-run, a second worker walks into the same contacts, and every contact it reaches before
	 * the batch's existing-engagement snapshot goes stale gets a second engagement and a second
	 * email. Nothing else refreshes it: BWFAN_Model::update() does not touch last_modified and the
	 * e_offset write above sets only its own columns.
	 *
	 * Throttled to one write every couple of seconds, which is nothing next to the queries each
	 * contact already costs.
	 *
	 * @param bool $force Write even if the last stamp is still recent
	 *
	 * @return void
	 */
	private function touch_broadcast_lock( $force = false ) {
		$now = time();
		if ( false === $force && ( $now - $this->lock_stamped_at ) < self::$LOCK_REFRESH_SECONDS ) {
			return;
		}

		$this->lock_stamped_at = $now;
		$last_modified         = current_time( 'mysql', 1 );

		BWFAN_Model_Broadcast::update( array( 'last_modified' => $last_modified ), array( 'id' => absint( $this->broadcast['id'] ) ) );

		/** Kept in step so anything reading the in-memory row sees the same stamp */
		$this->broadcast['last_modified'] = $last_modified;
		if ( is_array( $this->processing->current_broadcast ) ) {
			$this->processing->current_broadcast['last_modified'] = $last_modified;
		}
	}

	/**
	 * Contact ids out of the given list that already have an engagement for this broadcast
	 *
	 * One query per batch rather than a check per contact.
	 *
	 * @param array $contact_ids Contact ids of the current batch
	 *
	 * @return array Map of contact id => true, empty when none exist yet
	 */
	private function get_existing_engagement_cids( $contact_ids = [] ) {
		$contact_ids = array_filter( array_map( 'absint', (array) $contact_ids ) );
		if ( empty( $contact_ids ) ) {
			return [];
		}

		global $wpdb;

		$placeholders = implode( ',', array_fill( 0, count( $contact_ids ), '%d' ) );
		$args         = array_merge( [ $this->broadcast['id'], BWFAN_Email_Conversations::$TYPE_CAMPAIGN ], $contact_ids );

		$cids = $wpdb->get_col( $wpdb->prepare( "SELECT cid FROM {$wpdb->prefix}bwfan_engagement_tracking
			WHERE oid = %d AND type = %d AND cid IN ( $placeholders )", $args ) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL

		return empty( $cids ) ? [] : array_fill_keys( array_map( 'absint', $cids ), true );
	}

	/**
	 * Merge tags of every engagement in the claimed batch, in one query
	 *
	 * BWFAN_Model_Engagement_Trackingmeta::get_merge_tags() is a query per engagement, and this
	 * loop already batches the contact read it sits next to - one round trip per recipient for a
	 * value the batch could fetch together is the difference between one query per batch and
	 * fifty.
	 *
	 * @param array $engagements Engagement rows of the current batch
	 *
	 * @return array Map of engagement id => merge tag array, engagements with none absent
	 */
	private function get_merge_tags_for_batch( $engagements = [] ) {
		if ( ! is_array( $engagements ) || empty( $engagements ) ) {
			return [];
		}

		$ids = array_filter( array_map( function ( $engagement ) {
			return absint( $engagement['ID'] ?? 0 );
		}, $engagements ) );

		if ( empty( $ids ) ) {
			return [];
		}

		global $wpdb;

		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		$rows         = $wpdb->get_results( $wpdb->prepare( "SELECT eid, meta_value FROM {$wpdb->prefix}bwfan_engagement_trackingmeta
			WHERE meta_key = 'merge_tags' AND eid IN ( $placeholders )", $ids ), ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL

		/**
		 * A query that failed is not a batch with no merge tags, and the caller has to be able to
		 * tell them apart - it falls back to the per-engagement read on a miss, which is the very
		 * query per recipient this exists to avoid.
		 */
		if ( ! empty( $wpdb->last_error ) || ! is_array( $rows ) ) {
			return [];
		}

		/**
		 * Every engagement asked for gets an entry, even when it has no merge tags at all.
		 *
		 * Returning only the rows that exist would leave a template with no merge tags - a plain
		 * broadcast, the common case - missing from the map for every recipient, so each one
		 * would fall through to get_merge_tags() and pay for exactly the round trip this method
		 * was added to remove.
		 */
		$tags = array_fill_keys( $ids, [] );

		foreach ( $rows as $row ) {
			$decoded = json_decode( $row['meta_value'], true );
			if ( is_array( $decoded ) ) {
				$tags[ absint( $row['eid'] ) ] = $decoded;
			}
		}

		return $tags;
	}

	/**
	 * Creating the engagement for each v2 contact
	 *
	 * @param $broadcast
	 * @param $contact_id
	 *
	 * @return bool True when an engagement row was created
	 */
	public function create_contact_engagement( $broadcast, $contact_id ) {
		$contact = new WooFunnels_Contact( '', '', '', $contact_id );
		if ( 0 === $contact->get_id() ) {
			return false;
		}

		$data                = $broadcast['data'];
		$broadcast_id        = intval( $broadcast['id'] );
		$broadcast_author_id = intval( $broadcast['created_by'] );
		$broadcast_content   = $data['content'];

		$template_winner = isset( $data['winner'] ) ? intval( $data['winner'] ) : 0;
		$chosen_content  = $this->processing->get_current_email_template( $broadcast_content, $this->processed, $template_winner );
		/**
		 * Get template data on the basic of template id if exists.
		 */
		$content_template = $this->processing->get_template_from_id( $chosen_content['template_id'] ?? 0, $chosen_content );

		/**
		 * Primed before the conversation is created, exactly as the v1 sender does it.
		 *
		 * The {{unsubscribe_link}} tag reads broadcast_id off the loader and only appends `bid`
		 * when it finds one, and v2 resolves every merge tag here - at creation - then stores the
		 * result against the engagement. Without this the link is built with no `bid` and that
		 * value is what the send substitutes, so the unsubscribe never records which broadcast it
		 * came from. The loader merges rather than replaces, so it must also be set per contact:
		 * a stale broadcast_id left by an earlier broadcast in the same request would otherwise
		 * point the link at the wrong one.
		 */
		BWFAN_Merge_Tag_Loader::set_data( array(
			'broadcast_id' => $broadcast_id,
			'contact_id'   => $contact_id,
		) );

		/**
		 * The contact object, not its id. create_campaign_conversation() takes either, but given
		 * an id it builds a second WooFunnels_Contact of its own - so every recipient of a large
		 * broadcast was loaded twice during creation, once for the existence check above and once
		 * to be thrown away here.
		 */
		$email_data = BWFCRM_Core()->conversation->create_campaign_conversation( $contact, $broadcast_id, $chosen_content['template_id'] ?? 0, $broadcast_author_id, BWFCRM_Campaigns::$CAMPAIGN_EMAIL, false, $content_template );
		if ( $this->processing->validate_email_data_error( $email_data ) ) {
			return false;
		}

		/**
		 * The insert is INSERT IGNORE, so a row the table refused - a duplicate hash_code, a
		 * deadlock - comes back as conversation_id 0 with no error at all. Counted as created,
		 * the contact was prepared with nothing to claim and silently never got the broadcast.
		 */
		return is_array( $email_data ) && ! empty( $email_data['conversation_id'] );
	}


	/**
	 * Handle failed mails and update broadcast data accordingly
	 *
	 * @param array $result
	 * @param string $error Error message or reason for failure
	 *
	 * @return bool True if the broadcast should be stopped, false otherwise
	 */
	public function handle_failed_mails( $result = [], $error = '' ) {
		/** A delivered mail ends the current run of failures */
		if ( true === $result ) {
			if ( $this->consecutive_failures > 0 ) {
				$this->consecutive_failures = 0;
				$this->update_broadcast_data( array( 'consecutive_failures' => 0 ) );
			}

			return false;
		}

		/**
		 * Persisted rather than counted in memory.
		 *
		 * A fresh controller is built for every broadcast on every dispatcher pass, so a purely
		 * in-memory counter is thrown away at the end of each Action Scheduler run. Against a
		 * provider that fails slowly - an SMTP endpoint that times out rather than rejecting -
		 * a thirty second run fits only three or four attempts, so the count never reached the
		 * limit, reset on the next tick, and the broadcast burned through its whole audience
		 * failing every single email. That outage is the one this gate exists to stop.
		 *
		 * One write per failure, which costs nothing on a healthy send because there are none.
		 */
		$this->consecutive_failures ++;
		$this->update_broadcast_data( array( 'consecutive_failures' => $this->consecutive_failures ) );

		if ( $this->consecutive_failures < self::$CONSECUTIVE_FAILURE_LIMIT ) {
			return false;
		}

		/**
		 * The same opt-out the v1 sender honours, so a site that told broadcasts not to pause on
		 * failures is not overruled by the flow it happens to be sending on. The counter is reset
		 * rather than left at the limit, or the filter would be consulted again on every single
		 * mail for the rest of the run.
		 */
		$should_pause = apply_filters( 'bwfan_broadcast_should_pause_on_failures', true, $this->broadcast_id );
		if ( ! is_bool( $should_pause ) ) {
			$should_pause = true;
		}

		if ( false === $should_pause ) {
			$this->consecutive_failures = 0;
			$this->update_broadcast_data( array( 'consecutive_failures' => 0 ) );

			return false;
		}

		/**
		 * Persist every failed contact, not just this run of them - update_status_to_ongoing()
		 * reads the list back to re-open those engagements when the broadcast is resumed.
		 *
		 * Merged into the stored blob rather than written over it. The copy this controller holds
		 * was read when the send loop started and can be minutes old, while overlapping workers
		 * on the same broadcast are normal - a smart send winner, smart_sending_done and the
		 * engagements_created reset that sends the broadcast back into creation are all written
		 * by a sibling worker in exactly that window. Writing the snapshot back dropped them, and
		 * the broadcast then completed having mailed only its test batch.
		 */
		$data = ! empty( $this->broadcast['data'] ) ? $this->broadcast['data'] : array();

		/**
		 * Offset and processed are deliberately left alone here. Breaking out of the send loop
		 * falls through to increment_campaign_offsets(), which moves them by this batch's delta;
		 * writing this pipeline's own absolute totals would undo another pipeline's progress.
		 */
		$this->update_broadcast_data( array(
			'failed_cids'   => $this->failed_cids,
			'failed_reason' => array_values( array_unique( array_merge( $data['failed_reason'] ?? [], [ $error ] ) ) ),
		) );

		/**
		 * Guarded on the broadcast still running, rather than the unconditional status write this
		 * replaced - a worker finishing its last batch after an admin cancelled or unscheduled the
		 * broadcast used to flip it back to paused.
		 *
		 * The dispatcher moves a due broadcast to running before the send phase is reached, so the
		 * guard matches in the normal course of events. It can miss in one narrow race: the send
		 * branch gates on execution_time and not on status, so a broadcast whose time falls between
		 * the two phases of a single run can send while still scheduled. That costs one further
		 * failed email and no more - consecutive_failures is persisted, so the next tick finds the
		 * broadcast running and pauses it on its first failure.
		 */
		BWFAN_Model_Broadcast::update_status_to_pause( $this->broadcast_id );

		BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' paused after ' . $this->consecutive_failures . ' consecutive failures' );

		return true; // Stop execution if too many failures
	}

	/**
	 * Process for sending emails using claim-based approach for multi-pipeline processing
	 *
	 * @return void
	 */
	public function send_email_process() {
		global $wpdb;

		$data = ! empty( $this->broadcast['data'] ) ? $this->broadcast['data'] : array();

		/** If broadcast data have failed_cids */
		if ( ! empty( $data['failed_cids'] ) ) {
			$this->failed_cids = array_filter( array_map( 'absint', $data['failed_cids'] ) );
		}

		/** Carried across runs, see the note in handle_failed_mails() */
		$this->consecutive_failures = absint( $data['consecutive_failures'] ?? 0 );
		$this->render_failures      = absint( $data['render_failures'] ?? 0 );

		// Initialize the mail handler controller
		$this->mail_handler = $this->get_mail_handler_controller();

		$this->processed = intval( $this->broadcast['processed'] );
		$this->offset    = intval( $this->broadcast['offset'] );
		$this->count     = intval( $this->broadcast['count'] );

		// Configure the mail handler
		$limit = $this->processing->get_per_second_limit();
		$this->mail_handler->set_batch_limit_per_second( $limit );

		/**
		 * How many engagements to claim at a time, which is not the same thing as the throttle.
		 *
		 * The per second limit is an optional setting with a minimum of 0, and 0 has always meant
		 * "do not throttle" on the v1 path. Handing that straight to the claim query makes it
		 * `LIMIT 0`, so nothing is ever claimed, every pass reads as an empty batch with work
		 * still pending, and the broadcast reschedules itself forever without sending a mail.
		 */
		$batch_size = absint( $limit ) > 0 ? absint( $limit ) : self::$CLAIM_BATCH_SIZE;

		/**
		 * Swept once for the whole call, not per batch.
		 *
		 * This is a broadcast wide UPDATE and it releases claims older than five minutes, so
		 * running it again a batch later - seconds, on a batch the size of the per second limit -
		 * can only ever find the same nothing. The claims it exists to clean up are left by runs
		 * that died, and those are already long expired by the time this one starts.
		 */
		$this->remove_orphaned_claims();

		$this->start_conversation_session();

		/**
		 * The conversation session has to be closed even when a mail blows up mid-loop.
		 *
		 * end_conversation_session() is what puts Lite's own conversation object back. Miss it and
		 * the clone stays on the shared singleton carrying this broadcast's ids - the very leak the
		 * session exists to prevent - and the next thing to mail in this request inherits them. A
		 * shutdown handler is no use for that: it runs once the request is already over, long after
		 * that mail went out. The closer is guarded, so reaching it twice is harmless.
		 */
		try {
			do {
				/**
				 * Has anybody stopped this broadcast since the last batch?
				 *
				 * Pause and Cancel are admin HTTP requests landing while this worker is mid-call, and
				 * nothing else in this loop would notice: the claim UPDATE filters engagement columns
				 * only, and the loop condition is time and memory. A click two seconds into a thirty
				 * second call therefore left the worker claiming fresh batches and mailing for the
				 * remaining twenty eight - at the default fifteen a second, several hundred emails
				 * sent after the screen said the broadcast had stopped.
				 *
				 * One primary-key read per batch, not per email, so the batch already claimed still
				 * finishes - those rows are claimed and their statuses have to be written. That bounds
				 * the overrun at one batch instead of a whole call.
				 */
				if ( ! $this->is_broadcast_still_sending() ) {
					BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' no longer sending, stopping this run' );
					break;
				}

				// Create claim id
				$claim_id = $this->create_claim_id();
				if ( ! $claim_id ) {
					BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' failed to create claim id' );
					break;
				}

				// Update engagements with claim id
				$claimed_count = $this->claim_engagements( $claim_id, $batch_size );

				/** Captured straight away, every later query resets $wpdb->last_error */
				$claim_error = $wpdb->last_error;
				BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' claimed ' . $claimed_count . ' engagements with claim_id ' . $claim_id );

				// Fetch engagements by claim id
				$this->engagements = $this->get_engagements_by_claim_id( $claim_id );

				if ( empty( $this->engagements ) ) {
					/**
					 * Free anything the claim UPDATE stamped before the fetch came back empty.
					 *
					 * The two statements are not atomic with each other: the claim can succeed and
					 * the read that follows it fail, or come back short, on a deadlock or a lock
					 * wait. Deleting only the claim row leaves those engagements carrying a claim_id
					 * with nothing behind it, unreachable until the orphan sweep five minutes later,
					 * and has_active_claims_for_broadcast() counts them - so every pass in between
					 * claims nothing and gives up. Cheap to run when nothing was claimed.
					 */
					if ( absint( $claimed_count ) > 0 ) {
						$this->release_remaining_claim( $claim_id );
					}

					// Check if any other claims exist for this broadcast
					if ( $this->has_active_claims_for_broadcast() ) {
						BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' no engagements claimed, but other active claims exist' );
						$this->delete_claim( $claim_id );
						break;
					}

					/**
					 * Nothing was claimed - but establish that the table agrees before acting on it.
					 *
					 * A failed claim query returns zero rows exactly like an exhausted broadcast
					 * does - a deadlock, a lock wait timeout or a missing column all look the
					 * same here - so completing on an empty batch alone would silently drop every
					 * remaining contact. This runs ahead of the smart send branches too: reading a
					 * transient claim failure as "the test batch is fully sent" would open the
					 * window early and strand the rest of that batch for its whole duration.
					 */
					$pending_count = $this->get_pending_engagements_count();
					if ( $pending_count > 0 ) {
						BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' claimed nothing while ' . $pending_count . ' engagements are still pending, rescheduling instead of completing. Claim query error: ' . $claim_error );
						$this->delete_claim( $claim_id );
						$this->yield_run( true );
						break;
					}

					/** Smart send hold already running: sit out the window, then resolve the winner */
					if ( $this->is_broadcast_on_hold() ) {
						$this->resolve_smart_send_hold( $data );
						$this->delete_claim( $claim_id );
						break;
					}

					/** Test batch just finished sending: this is where its window starts */
					if ( $this->maybe_start_smart_send_window( $data ) ) {
						$this->delete_claim( $claim_id );
						break;
					}

					// Mark broadcast as complete
					BWFAN_Model_Broadcast::update_status_to_complete( $this->broadcast['id'], $data, $this->processed, $this->count );
					$this->processing::action_schedule_save_last_sent( $this->broadcast['id'] );
					$this->delete_claim( $claim_id );

					/** Same reset the v1 completion does, or the broadcast list serves stale totals */
					delete_transient( 'bwfan_broadcast_stats' );

					BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' completed' );
					break;
				}

				/**
				 * The batch read back has to be exactly the batch that was claimed.
				 *
				 * claim_id is a random local number, so two claims live on this broadcast at once
				 * can in principle draw the same one - and get_engagements_by_claim_id() is keyed
				 * on that number, so it would hand this run the other claim's rows as well as its
				 * own. Nothing downstream would catch it: the send loop takes the claim as proof of
				 * exclusivity and deliberately does not re-check c_status per row, so both runs
				 * would mail the union and every contact in it would get the broadcast twice, with
				 * no error anywhere. The claim UPDATE already reports how many rows it stamped, so
				 * the two numbers disagreeing is the collision, for free.
				 *
				 * It also fires on a dead run's rows still carrying this number - harmless in
				 * itself, they are unsent drafts, but not this batch's to send either.
				 *
				 * Nothing is released here on purpose. The claim covers the other run's rows too,
				 * and freeing those while it is still sending them is what would let a third run
				 * claim and re-send the same contacts. Both runs bail instead, the orphan sweep
				 * frees whatever is left, and the next pass claims it again under a fresh number.
				 */
				if ( absint( $claimed_count ) !== count( $this->engagements ) ) {
					BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' claimed ' . absint( $claimed_count ) . ' engagements but read back ' . count( $this->engagements ) . ' for claim_id ' . $claim_id . ', abandoning this batch unsent' );
					$this->delete_claim( $claim_id );
					$this->yield_run( true );
					break;
				}

				/**
				 * One read of the batch's contacts, used for two things: the uid the mail needs, and
				 * whether the contact is still someone this broadcast may write to at all.
				 */
				$contact_states = BWFCRM_Broadcast_Helper::get_contact_send_states( $this->engagements );

				/**
				 * The contact read failed, so nothing is known about this batch - and an unknown
				 * contact is read further down as one that no longer exists, which errors the
				 * engagement permanently. Put the rows back and let the next pass claim them.
				 */
				if ( false === $contact_states ) {
					BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' contact state read failed, releasing the batch unsent' );
					$this->release_remaining_claim( $claim_id );
					$this->delete_claim( $claim_id );
					$this->yield_run( true );
					break;
				}

				$this->engagement_contact_states = $contact_states;
				$this->engagement_contact_uids   = empty( $this->engagement_contact_states ) ? [] : wp_list_pluck( $this->engagement_contact_states, 'uid' );

				$batch_processed = $this->process_broadcast_with_claim( $claim_id );

				// Delete claim after processing
				$this->delete_claim( $claim_id );

				if ( true === $this->stop_broadcast_required ) {
					$this->stop_broadcast_required = false;
					break;
				}

				/**
				 * Backstop: a claimed batch that sent nothing means the loop is not making progress.
				 * Those rows are released and immediately claimable again, so carrying on would just
				 * re-claim the same ones for the rest of the time budget. Hand the run back instead -
				 * the next one starts from a clean claim.
				 */
				if ( 0 === absint( $batch_processed ) ) {
					BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' claimed a batch but processed nothing, ending this run' );
					$this->yield_run();
					break;
				}

				if ( $this->processing->is_time_exceeded() ) {
					$this->yield_run();
					break;
				}
			} while ( ! $this->processing->is_time_exceeded() && ! BWFCRM_Common::memory_exceeded() );
		} finally {
			$this->end_conversation_session();
		}
	}

	/**
	 * 1.2: keep this broadcast's conversation state off Lite's shared object for the length of the run.
	 *
	 * prime_conversation_for_links() stamps broadcast_id, template_id, engagement_type and contact on
	 * BWFAN_Core()->conversation before every mail, and nulls ->template. Nothing puts them back:
	 * prepare_email_body() resets broadcast_id and sets engagement_type only while it is still empty,
	 * and no path anywhere clears template_id - not ours alone, the forms, transactional-mail and
	 * send_message() paths all stamp it on the shared object and walk away too.
	 *
	 * That matters because maybe_insert_link() falls back to exactly those fields when the caller
	 * passes no ids of its own, and callers do: modify_message_body_urls() asks for a link hash with
	 * no $data at all - the SMS, notification and WhatsApp rewrite - and the subscribe-link merge tag
	 * passes type and oid but no template_id. Action Scheduler runs a batch of actions per PHP
	 * process, so one of those following a broadcast in the same request files its link rows under
	 * this broadcast's tid: its clicks land here, and its own link metrics find nothing. Automation
	 * email is immune, insert_automation_conversation() puts template_id into $data itself.
	 *
	 * The rewrite chain runs on the BWFAN_Core()->conversation object - the Pro class only delegates
	 * to it, re-reading the global on each call - so the run gets a clone of that object to scribble
	 * on and the original goes back at the end. A clone restores whatever was there rather than a
	 * list of fields we would have to keep in step with prime_conversation_for_links(), and it
	 * carries Lite's request-lifetime link-hash memo in, so the run starts warm.
	 */
	private function start_conversation_session() {
		/** is_object(), not isset(): a non-object in that slot would fatal on clone rather than be skipped */
		if ( null !== $this->original_conversation || ! is_object( BWFAN_Core()->conversation ) ) {
			return;
		}

		$this->original_conversation = BWFAN_Core()->conversation;
		BWFAN_Core()->conversation   = clone $this->original_conversation;
	}

	/** Put Lite's own conversation object back, discarding everything this run stamped on the clone */
	private function end_conversation_session() {
		if ( null === $this->original_conversation ) {
			return;
		}

		BWFAN_Core()->conversation   = $this->original_conversation;
		$this->original_conversation = null;
	}

	/**
	 * Remove orphaned claims - engagements claimed more than 5 minutes ago
	 *
	 * @return void
	 */
	private function remove_orphaned_claims() {
		global $wpdb;

		$engagement_table = $wpdb->prefix . 'bwfan_engagement_tracking';

		/**
		 * UTC, because that is the clock every writer of this column uses - the claim stamps
		 * below, and create_campaign_conversation() for a row that has not been claimed yet.
		 * MySQL's NOW() follows the database server's timezone instead, so comparing the two
		 * either never expires a claim (server ahead of UTC, broadcast stalls) or expires every
		 * claim on sight (server behind UTC, contacts get mailed twice).
		 */
		$threshold_time = gmdate( 'Y-m-d H:i:s', time() - ( 5 * MINUTE_IN_SECONDS ) );

		/**
		 * Scoped to this broadcast so it cannot steal another pipeline's claims, but deliberately
		 * not to draft rows.
		 *
		 * has_active_claims_for_broadcast() - the gate that decides whether this broadcast is
		 * already being worked on - counts a claim on a row of any status, so this has to be able
		 * to clear every row that gate can see. fail_the_conversation() sets c_status = ERROR
		 * without touching claim_id, and only the record_engagement_result() call after it clears
		 * the claim; any fatal, OOM kill or PHP timeout in that window leaves an errored row
		 * holding a claim forever. A draft-only sweep could never release it, so from that moment
		 * every pass claimed nothing, saw an active claim, and gave up - the broadcast sat at
		 * Running with no error anywhere on the report.
		 *
		 * Clearing claim_id on a row that has already been sent or errored costs nothing: the
		 * column means nothing once the row has left draft.
		 */
		$wpdb->query( $wpdb->prepare( "UPDATE {$engagement_table}
			SET claim_id = 0
			WHERE oid = %d AND type = %d AND claim_id > 0 AND updated_at < %s",
			$this->broadcast['id'],
			BWFAN_Email_Conversations::$TYPE_CAMPAIGN,
			$threshold_time
		) );

		BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' removed orphaned claims older than ' . $threshold_time );
	}

	/**
	 * Create a claim id locally - no table row behind it
	 *
	 * @return int|false The claim ID or false on failure
	 */
	private function create_claim_id() {
		/**
		 * Generated locally instead of inserting into bwf_action_claim.
		 *
		 * The claim table never was the lock - the atomic `claim_id = 0` UPDATE in
		 * claim_engagements() is - so the insert/delete pair per batch only manufactured a
		 * number, on a table whose auto increment Action Scheduler's data store shares. A local
		 * id removes two writes per batch and all churn on that shared table.
		 *
		 * What the number has to deliver is not uniqueness but non-reuse. A run that dies holding
		 * a claim leaves its unsent rows carrying that number until the orphan sweep clears them,
		 * and a later run drawing the same number would read those rows back as part of its own
		 * batch. That is why this is a random draw rather than a process id, a connection id or
		 * any other short handle the system recycles - those are unique among live holders and
		 * are then handed straight back out, which is the one property that breaks here.
		 *
		 * Nine digits keep it readable in the logs and in the engagements table. Two claims live
		 * on one broadcast at the same moment drawing the same number is ~1 in 10^9, and the
		 * count check after the read-back in send_email_process() turns that into a retry instead
		 * of a double send - so the width is margin, not the guard. Every fetch and release is
		 * additionally scoped to this broadcast's oid, so a cross-broadcast repeat touches
		 * nothing.
		 */
		try {
			return random_int( 1, 999999999 );
		} catch ( \Exception $e ) {
			/** No entropy source on this host - the contract stays id-or-false */
			return false;
		}
	}

	/**
	 * Update engagements with claim id atomically
	 *
	 * @param int $claim_id The claim ID
	 * @param int $limit The limit of engagements to claim
	 *
	 * @return int Number of engagements claimed
	 */
	private function claim_engagements( $claim_id, $limit ) {
		global $wpdb;

		$engagement_table = $wpdb->prefix . 'bwfan_engagement_tracking';
		$broadcast_id     = $this->broadcast['id'];

		$result = $wpdb->query( $wpdb->prepare( "UPDATE {$engagement_table}
			SET claim_id = %d, updated_at = %s
			WHERE oid = %d AND type = %d AND c_status = %d AND claim_id = 0
			ORDER BY ID ASC
			LIMIT %d",
			$claim_id,
			current_time( 'mysql', 1 ),
			$broadcast_id,
			BWFAN_Email_Conversations::$TYPE_CAMPAIGN,
			BWFAN_Email_Conversations::$STATUS_DRAFT,
			$limit
		) );

		return $result ? $result : 0;
	}

	/**
	 * Get engagements by claim id
	 *
	 * @param int $claim_id The claim ID
	 *
	 * @return array Array of engagement data
	 */
	private function get_engagements_by_claim_id( $claim_id ) {
		global $wpdb;

		$engagement_table = $wpdb->prefix . 'bwfan_engagement_tracking';

		/**
		 * Scoped to this broadcast, not to the claim id alone.
		 *
		 * Claim ids are random locals (see create_claim_id()), so in principle two broadcasts
		 * could hold the same number at once. The oid predicate is what makes that harmless:
		 * without it, a collision would pick up another broadcast's rows and send them with
		 * this broadcast's template and merge tags. release_remaining_claim() carries the same
		 * scope for the same reason.
		 */
		$engagements = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$engagement_table}
			WHERE claim_id = %d AND oid = %d AND type = %d
			ORDER BY ID ASC", $claim_id, $this->broadcast['id'], BWFAN_Email_Conversations::$TYPE_CAMPAIGN ), ARRAY_A );

		return is_array( $engagements ) ? $engagements : array();
	}

	/**
	 * Whether this broadcast is still in a state that may send
	 *
	 * Read fresh from the row rather than from the copy this run started with, which is the whole
	 * point: the statuses that stop a send - paused, cancelled, halted, back to draft - are
	 * written by an admin request while this worker is running.
	 *
	 * Scheduled counts as sending alongside running, for the same reason update_status_to_complete()
	 * accepts both: a v2 broadcast begins sending on the tick its execution time arrives, which can
	 * be the tick before the dispatcher moves it to running. Treating that as "stopped" would break
	 * the send loop on the very tick it should start.
	 *
	 * A row that cannot be read at all is treated as still sending, so a dropped connection pauses
	 * nothing - the ordinary claim path already handles a database that is not answering.
	 *
	 * @return bool
	 */
	private function is_broadcast_still_sending() {
		global $wpdb;

		$status = $wpdb->get_var( $wpdb->prepare( "SELECT `status` FROM {$wpdb->prefix}bwfan_broadcast WHERE `id` = %d", absint( $this->broadcast['id'] ) ) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		if ( is_null( $status ) ) {
			return true;
		}

		return in_array( absint( $status ), array(
			BWFCRM_Campaigns::$CAMPAIGN_RUNNING,
			BWFCRM_Campaigns::$CAMPAIGN_SCHEDULED,
		), true );
	}

	/**
	 * Whether the preparation this run is building is still the one the broadcast wants
	 *
	 * Read fresh from the row, once per batch, like is_broadcast_still_sending() - but the
	 * status is only one of three things that end a preparation:
	 *
	 * - the status leaving scheduled/running (pause, cancel, unschedule, halt);
	 * - `prepared_for` gone - reset_prepared_broadcast() strips it when the content or the
	 *   audience is edited, or the broadcast is re-scheduled, without touching the status;
	 * - `engagements_created` no longer 0 - written only by a run that finished creating, so
	 *   finding it changed underneath this one means another run completed this preparation.
	 *
	 * A row that cannot be read is treated as unchanged, as in is_broadcast_still_sending();
	 * the per-batch existing-engagement check already guards a database that is not answering.
	 *
	 * @return bool
	 */
	private function is_preparation_still_valid() {
		global $wpdb;

		$row = $wpdb->get_row( $wpdb->prepare( "SELECT `status`, `data` FROM {$wpdb->prefix}bwfan_broadcast WHERE `id` = %d", absint( $this->broadcast['id'] ) ), ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		if ( ! is_array( $row ) || ! isset( $row['status'] ) ) {
			return true;
		}

		if ( ! in_array( absint( $row['status'] ), array(
			BWFCRM_Campaigns::$CAMPAIGN_RUNNING,
			BWFCRM_Campaigns::$CAMPAIGN_SCHEDULED,
		), true ) ) {
			return false;
		}

		$data = ! empty( $row['data'] ) ? json_decode( $row['data'], true ) : array();
		if ( ! is_array( $data ) || empty( $data['prepared_for'] ) ) {
			return false;
		}

		/**
		 * A reset and a second preparation put prepared_for back with the same value, so only
		 * prep_id tells this worker its snapshot - offset, counters, content - belongs to a
		 * preparation that was thrown away. Checked here, before the next batch is inserted:
		 * the re-preparation only runs once the cleanup is gone, so rows inserted now would
		 * survive and the new run would skip those contacts as already engaged.
		 */
		$prep_id = $this->broadcast['data']['prep_id'] ?? '';
		if ( ! empty( $prep_id ) && ( ! isset( $data['prep_id'] ) || $prep_id !== $data['prep_id'] ) ) {
			return false;
		}

		return isset( $data['engagements_created'] ) && 0 === intval( $data['engagements_created'] );
	}

	/**
	 * Hand the broadcast back to the scheduler
	 *
	 * maybe_broadcast_running() treats a row whose last_modified is within five seconds as
	 * taken by another worker, and the reschedule creates an action due now that Action
	 * Scheduler starts within seconds. Whether that immediate run should pick the broadcast up
	 * again depends on why this one stopped:
	 *
	 * - Out of time or memory with work still to do: backdate the stamp so the next run carries
	 *   straight on. Nothing is in flight once this run exits, so that is the truthful state.
	 *
	 * - A query failed (the audience page, the claim, the contact read): leave the stamp fresh.
	 *   The immediate run then skips the broadcast and the regular tick retries it a minute
	 *   later. Backdating here would have the next run hit the same failing statement within
	 *   seconds, and for a fault that does not clear on its own - a column the migration could
	 *   not add, a table locked by a long job - that is a full WordPress bootstrap every few
	 *   seconds for as long as the fault lasts. A minute between attempts is the backoff.
	 *
	 * @param bool $backoff True to hold the broadcast for the lock window before it is retried
	 *
	 * @return void
	 */
	private function yield_run( $backoff = false ) {
		$stamp = $backoff ? time() : time() - 6;

		BWFAN_Model_Broadcast::update( array(
			'last_modified' => date( 'Y-m-d H:i:s', $stamp ),
		), array(
			'id' => absint( $this->broadcast['id'] ),
		) );

		BWFCRM_Common::reschedule_broadcast_action();
	}

	/**
	 * Count the engagements of this broadcast that are still waiting to be sent
	 *
	 * Used to tell an exhausted broadcast apart from a claim query that failed, since both
	 * end up with an empty batch.
	 *
	 * @return int Number of engagements still pending
	 */
	private function get_pending_engagements_count() {
		global $wpdb;

		$engagement_table = $wpdb->prefix . 'bwfan_engagement_tracking';

		$count = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$engagement_table}
			WHERE oid = %d AND type = %d AND c_status = %d",
			$this->broadcast['id'],
			BWFAN_Email_Conversations::$TYPE_CAMPAIGN,
			BWFAN_Email_Conversations::$STATUS_DRAFT
		) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return absint( $count );
	}

	/**
	 * Check if there are active claims for this broadcast
	 *
	 * @return bool True if active claims exist, false otherwise
	 */
	private function has_active_claims_for_broadcast() {
		global $wpdb;

		$engagement_table = $wpdb->prefix . 'bwfan_engagement_tracking';
		$broadcast_id     = $this->broadcast['id'];

		$count = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$engagement_table}
			WHERE oid = %d AND type = %d AND claim_id > 0",
			$broadcast_id,
			BWFAN_Email_Conversations::$TYPE_CAMPAIGN
		) );

		return intval( $count ) > 0;
	}

	/**
	 * Mark this run done with a claim id
	 *
	 * @param int $claim_id The claim ID to delete
	 *
	 * @return void
	 */
	private function delete_claim( $claim_id ) {
		/**
		 * Nothing to delete since claim ids went local - and deleting would be dangerous:
		 * a random id can coincide with a live row id in bwf_action_claim, which belongs to
		 * Action Scheduler's claim store, and removing that row breaks the claim AS is
		 * holding. The engagement-side release stays in release_remaining_claim().
		 */
		BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' finished claim_id ' . $claim_id );
	}

	/**
	 * Process broadcast with claim-based approach
	 *
	 * @param int $claim_id The claim ID for this batch
	 *
	 * @return int How many engagements this batch actually processed
	 */
	private function process_broadcast_with_claim( $claim_id ) {
		// Set the batch limit for the mail handler
		$per_second_limit = $this->processing->get_per_second_limit();
		$this->mail_handler->set_batch_limit_per_second( $per_second_limit );

		$successful_engagement_ids = array();
		$failed_engagement_data    = array();

		/** Counted separately from $this->processed, which is this pipeline's own snapshot */
		$batch_processed = 0;

		$broadcast_data = is_array( $this->broadcast['data'] ) ? $this->broadcast['data'] : array();

		/** One read for the whole batch, next to the one the contact states already do */
		$this->engagement_merge_tags = $this->get_merge_tags_for_batch( $this->engagements );

		// Process one by one (default behavior)
		foreach ( $this->engagements as $engagement ) {
			BWFCRM_Broadcast_Helper::set_log( 'contact#' . $engagement['cid'] . '_start' );
			if ( $this->processing->is_time_exceeded() || BWFCRM_Common::memory_exceeded() ) {
				BWFCRM_Broadcast_Helper::set_log( 'contact#' . $engagement['cid'] . '_time exceeded' );
				break;
			}

			/**
			 * Checked here rather than trusted from creation time.
			 *
			 * The audience query ran when the engagements were created, which on this flow is an
			 * hour before the send at the least, so a contact can have unsubscribed, bounced or
			 * been deleted since. v1 re-ran that query every seventy five contacts and so honoured
			 * those changes as it went; the claim query cannot, it only knows the engagement rows.
			 * Recorded as a failed engagement so the reason is on the record, and skipped without
			 * touching the failure counter - nothing was sent and the provider is not at fault.
			 */
			$contact_state = $this->engagement_contact_states[ absint( $engagement['cid'] ) ] ?? [];
			$unsendable    = BWFCRM_Broadcast_Helper::get_unsendable_reason( $contact_state, $broadcast_data );
			if ( ! empty( $unsendable ) ) {
				BWFCRM_Broadcast_Helper::set_log( 'contact#' . $engagement['cid'] . '_skipped: ' . $unsendable );
				if ( false === $this->record_engagement_result( $engagement['ID'], false, $unsendable ) ) {
					BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' result write failed, stopping this run' );
					$this->stop_broadcast_required = true;
					break;
				}

				$this->offset = $engagement['cid'];
				$this->processed ++;
				$batch_processed ++;

				continue;
			}

			/**
			 * No offset guard here on purpose.
			 *
			 * The v1 loop skipped anything at or above the offset because it walked contacts
			 * itself and the offset was always its own high-water mark. Claiming makes that
			 * false: `offset` is shared by every pipeline and only ever moves down, so a row
			 * another pipeline released unsent sits above it and the guard would skip it on
			 * sight - then release_remaining_claim() frees it, the loop below re-claims the
			 * same row, and the broadcast spins on it until the time budget runs out, never
			 * completing because a pending count keeps rescheduling it.
			 *
			 * The claim plus the c_status = draft predicate already give exclusivity, and a
			 * sent row leaves draft before the claim is released, so nothing is sent twice.
			 */

			/**
			 * if daily limit reached then delay and end the current broadcast
			 */
			$daily_limit_supported = in_array( absint( $this->broadcast['type'] ), $this->processing->supported_daily_limit_broadcast_types );
			if ( $daily_limit_supported && $this->processing->daily_achieved_limit >= $this->processing->daily_message_limit ) {
				BWFAN_Model_Broadcast::set_delay( $this->processing->current_broadcast['id'] );
				$this->stop_broadcast_required = true;
				break;
			}

			/** Hold for one second to complete, if per second limit achieved */
			if ( ! empty( $per_second_limit ) && $per_second_limit <= $this->processing->records_processed_in_one_sec ) {
				BWFCRM_Broadcast_Helper::set_log( 'contact#' . $engagement['cid'] . '_per_second_limit_reached' );
				$this->processing->delay_time();
			}
			BWFCRM_Common::$captured_email_failed_message = null;

			/**
			 * A mail that could not be built is not a provider failure.
			 *
			 * format_contact_mail() returns false when the contact is gone, has no usable address
			 * or the body could not be rendered, and it has already recorded the reason against
			 * the engagement. Feeding that to handle_failed_mails() the way a rejected send is fed
			 * to it would pause the whole broadcast - with a notice blaming the email service -
			 * after ten such contacts in a row.
			 */
			$mail_data = $this->format_contact_mail( $engagement );

			/**
			 * The body threw and the broadcast has been halted. Break out rather than record
			 * anything against this engagement: it never had its chance, and leaving it in draft
			 * is what lets it go out once the template is fixed. Falling through to the end of
			 * this method is what matters - the claim is released and the counters this batch
			 * moved are written, neither of which survived the die() this replaced.
			 */
			if ( true === $this->stop_broadcast_required ) {
				break;
			}

			if ( false === $mail_data ) {
				BWFCRM_Broadcast_Helper::set_log( 'contact#' . $engagement['cid'] . '_mail could not be prepared' );
				if ( false === $this->record_engagement_result( $engagement['ID'], false ) ) {
					BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' result write failed, stopping this run' );
					$this->stop_broadcast_required = true;
					break;
				}

				$this->offset = $engagement['cid'];
				$this->processed ++;
				$batch_processed ++;

				continue;
			}

			// Use the mail handler to send the email
			/**
			 * Normalised here, not only in the base handler.
			 *
			 * bwfcrm_override_broadcast_mail_handler swaps the whole class, so an override's
			 * send_mail() replaces the base method and its cast with it. A handler that returns
			 * the provider's message id - the natural thing to return - is truthy but not `true`,
			 * and every comparison below is strict, so each successful send would be recorded as
			 * a failure, fill failed_cids and eventually pause the broadcast.
			 *
			 * WP_Error is excluded rather than cast: it is an object, so a plain (bool) makes the
			 * one return value that unambiguously means "this did not send" read as success, and
			 * the contact is marked sent having received nothing.
			 */
			$sent   = $this->mail_handler->send_mail( $mail_data );
			$result = ! is_wp_error( $sent ) && ! empty( $sent );
			$error  = '';

			if ( true === $result ) {
				$successful_engagement_ids[] = $engagement['ID'];
			} else {
				/** A handler that said why takes precedence over whatever wp_mail last captured */
				$error                    = is_wp_error( $sent ) ? $sent->get_error_message() : BWFCRM_Common::$captured_email_failed_message;
				$error                    = ! empty( $error ) ? $error : __( 'Email not sent (Error Unknown)', 'wp-marketing-automations-pro' );
				$this->failed_cids[]      = $engagement['cid'];
				$failed_engagement_data[] = [
					'engagement_id' => $engagement['ID'],
					'error_message' => $error
				];
			}

			/** Recorded before moving on, so a fatal here costs at most this one email */
			$recorded = $this->record_engagement_result( $engagement['ID'], true === $result, $error );

			/**
			 * The mail left but its status could not be written. Sending on against a dead
			 * table stacks up mails the ledger does not know about - every one a double-send
			 * on recovery. Stopping here keeps the cost at this one mail: the sweep frees its
			 * row in five minutes and the next run re-sends only it.
			 */
			if ( false === $recorded ) {
				BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' result write failed after send, stopping this run' );
				$this->stop_broadcast_required = true;
				break;
			}

			/** set last engagement time */
			$this->processing->last_engagement_sent = microtime( true );

			$this->processing->records_processed_in_one_sec ++;
			$this->processing->daily_achieved_limit ++;
			$this->offset = $engagement['cid'];
			$this->processed ++;
			$batch_processed ++;

			$stop_execution = $this->handle_failed_mails( $result, $error );
			if ( $stop_execution ) {
				$this->stop_broadcast_required = true;
				BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' stop broadcast required' );
				break;
			}
		}

		BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' batch done - sent ' . count( $successful_engagement_ids ) . ', failed ' . count( $failed_engagement_data ) );

		/** Nothing in the next batch can hit this batch's contacts, and it is never emptied otherwise */
		$this->processing->reset_contact_cache();

		/** Statuses are already written per email, this only frees rows the loop never reached */
		$this->release_remaining_claim( $claim_id );

		// Update broadcast offsets, by how much this batch moved them
		BWFAN_Model_Broadcast::increment_campaign_offsets( $this->broadcast['id'], $this->offset, $batch_processed );

		return $batch_processed;
	}

	/**
	 * Record the outcome of a single send and release that engagement's claim
	 *
	 * Written per email rather than once per batch on purpose. Between wp_mail() returning and
	 * this row being updated the engagement still reads as unsent, so a fatal in that window
	 * would let remove_orphaned_claims() release it and the contact would be mailed a second
	 * time. Writing here narrows that window from a whole batch down to one email.
	 *
	 * updated_at is written in UTC to stay on the same clock as the claim stamp, which is what
	 * the orphan cleanup compares against.
	 *
	 * @param int $engagement_id
	 * @param bool $sent Whether the mail handler reported a successful send
	 * @param string $error Error message to record against a failed send
	 *
	 * @return bool False when the row UPDATE itself errored - the loop must stop sending on it
	 */
	private function record_engagement_result( $engagement_id, $sent, $error = '' ) {
		global $wpdb;

		$engagement_table = $wpdb->prefix . 'bwfan_engagement_tracking';
		$engagement_id    = absint( $engagement_id );
		$status           = $sent ? BWFAN_Email_Conversations::$STATUS_SEND : BWFAN_Email_Conversations::$STATUS_ERROR;
		$now              = current_time( 'mysql', 1 );

		if ( $sent ) {
			/**
			 * created_at is re-stamped with the send, the same way update_conversation_status()
			 * does it on the v1 path.
			 *
			 * v2 creates the engagement well before it goes out - an hour ahead for a scheduled
			 * broadcast, and much earlier than that for one whose creation phase spanned several
			 * runs. The daily sending limit counts `c_status = 2 AND created_at > now - 24 hours`
			 * (get_last_24_hours_conversations_count), so leaving the creation timestamp on a sent
			 * row hides that send from the limit entirely and the site keeps mailing past its cap.
			 * Everything else reporting on when a broadcast went out reads the same column.
			 */
			$written = $wpdb->query( $wpdb->prepare( "UPDATE {$engagement_table}
				SET c_status = %d, claim_id = 0, created_at = %s, updated_at = %s
				WHERE ID = %d", $status, $now, $now, $engagement_id ) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		} else {
			/**
			 * A failed send never went out, so its created_at stays as it was.
			 *
			 * One statement for status, claim release and timestamp together. The
			 * fail_the_conversation() pass that used to follow re-updated the same row a
			 * second time - same status, same timestamp - for no extra information; only its
			 * error meta carried anything, and that write lives just below.
			 */
			$written = $wpdb->query( $wpdb->prepare( "UPDATE {$engagement_table}
				SET c_status = %d, claim_id = 0, updated_at = %s
				WHERE ID = %d", $status, $now, $engagement_id ) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

			if ( ! empty( $error ) ) {
				/** The same meta fail_the_conversation() writes - the report reads it back as the failure reason */
				BWFAN_Model_Engagement_Trackingmeta::insert( array(
					'meta_key'   => 'error_msg',
					'meta_value' => $error,
					'eid'        => $engagement_id,
				) );
			}
		}

		/**
		 * false from $wpdb->query() is a query error; 0 affected rows is not one and stays
		 * true. The loop stops on false: once this write cannot land, every further send is a
		 * mail the ledger does not know about, and each of those double-sends on recovery.
		 */
		return false !== $written;
	}

	/**
	 * Release any engagement still holding this claim
	 *
	 * Everything the loop actually sent is released by record_engagement_result(); this covers
	 * the rows it skipped or never reached, so the claim never outlives the batch.
	 *
	 * @param int $claim_id
	 *
	 * @return void
	 */
	private function release_remaining_claim( $claim_id ) {
		global $wpdb;

		$engagement_table = $wpdb->prefix . 'bwfan_engagement_tracking';

		/** Scoped like the fetch above, so a recycled claim id cannot free another broadcast's rows */
		$wpdb->query( $wpdb->prepare( "UPDATE {$engagement_table}
			SET claim_id = 0, updated_at = %s
			WHERE claim_id = %d AND oid = %d AND type = %d",
			current_time( 'mysql', 1 ),
			$claim_id,
			$this->broadcast['id'],
			BWFAN_Email_Conversations::$TYPE_CAMPAIGN
		) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * Format contact mail data
	 *
	 * @param array $engagement The engagement data
	 * @param array $final_data Whether to return final formatted data or not
	 *
	 * @return array|bool The formatted mail data or false if there was an error
	 */
	public function format_contact_mail( $engagement = [], $final_data = true ) {
		$contact_id = absint( $engagement['cid'] );

		// Check if contact ID is valid and has a corresponding UID
		$c_uid = $this->engagement_contact_uids[ $contact_id ] ?? 0;
		if ( empty( $c_uid ) ) {
			/** Recorded, like every other branch that gives up on this mail, so the report says why */
			BWFCRM_Core()->conversation->fail_the_conversation( $engagement['ID'], sprintf( /* translators: %d: contact id */ __( 'Contact not found while sending: %d', 'wp-marketing-automations-pro' ), $contact_id ) );

			return false;
		}
		$data      = $this->broadcast['data'];
		$hash_code = $engagement['hash_code'] ?? '';

		$senders_data = [
			'senders_name'  => $data['senders_name'] ?? '',
			'senders_email' => $data['senders_email'] ?? '',
			'replyto'       => $data['replyto'] ?? '',
		];

		/**
		 * This pipeline's own live counter, not the row's `processed` as it was fetched.
		 *
		 * That value is read once per dispatcher pass and never moves for the rest of it, so
		 * whenever the round robin is actually reached - which happens when the engagement's
		 * stored tid matches nothing in the content, as it does after an A/B broadcast's content
		 * is edited while it is running - every recipient of the pass got the same variant, and
		 * the split the smart send winner is read from was not a split at all.
		 */
		$chosen_content = $this->processing->get_current_email_template( $this->broadcast['data']['content'], $this->processed, $engagement['tid'] );

		$pre_header  = $chosen_content['preheader'] ?? '';
		$utm_details = isset( $chosen_content['utm'] ) && is_array( $chosen_content['utm'] ) ? $this->processing->get_utm_data_from_campaign_data( $chosen_content['utm'] ) : '';

		/**
		 * Get template data on the basic of template id if exists.
		 */
		$template_data = $this->processing->get_template_from_id( $chosen_content['template_id'] ?? '', $chosen_content );
		$email_subject = $template_data['subject'] ?? '';
		$email_body    = $template_data['template'] ?? '';

		/**
		 * Read off the campaign content, the way the v1 sender does it - not off $template_data.
		 *
		 * When get_template_from_id() finds the stored row it returns that row, whose `type` column
		 * is the conversation type check_already_exists_template() wrote (1 for email), not the
		 * editor type. apply_template_by_type() switches on 'rich'/'wc'/'html'/'editor'/'block', so
		 * the integer matched no case and the body was returned with no emogrify and no wrapper.
		 */
		$template_type = $chosen_content['type'] ?? ( $template_data['type'] ?? '' );

		/** Read for the whole batch in one query; the per-engagement read is the fallback */
		$merge_tags = $this->engagement_merge_tags[ absint( $engagement['ID'] ) ] ?? null;
		if ( ! is_array( $merge_tags ) ) {
			$merge_tags = BWFAN_Model_Engagement_Trackingmeta::get_merge_tags( $engagement['ID'] );
		}

		/**
		 * The address the contact holds now, not the one snapshotted when the engagement was
		 * created.
		 *
		 * v2 creates engagements an hour before the send at the least, and far earlier than that
		 * for an audience whose creation spanned several runs. A contact who corrects a typo'd
		 * address in that window - or whose email is rewritten by an order, an import or an API
		 * call - would otherwise be mailed at the old one, which may well now belong to someone
		 * else. The freshness check a few lines up already reads this exact column, so the two
		 * disagreeing was invisible: the contact passed on the new address and the mail went to
		 * the stale one. v1 could not drift, it read the address at send time.
		 */
		$contact_state = $this->engagement_contact_states[ $contact_id ] ?? [];
		$to            = ! empty( $contact_state['email'] ) ? $contact_state['email'] : ( $engagement['send_to'] ?? '' );
		if ( ! is_email( $to ) ) {
			/* translators: %d: contact id */
			BWFCRM_Core()->conversation->fail_the_conversation( $engagement['ID'], sprintf( __( 'No email found for this contact: %d', 'wp-marketing-automations-pro' ), $contact_id ) );

			return false;
		}

		// Set unsubscribe link in header
		$unsubscribe_link = BWFAN_PRO_Common::get_unsubscribe_link( [ 'uid' => $c_uid, 'broadcast_id' => $this->broadcast['id'] ] );

		if ( ! $final_data ) {
			return array_merge( [
				'to'               => $to,
				'subject'          => $email_subject,
				'body'             => $email_body,
				'merge_tags'       => $merge_tags,
				'preheader'        => $pre_header,
				'utm_details'      => $utm_details,
				'contact_id'       => $contact_id,
				'unsubscribe_link' => $unsubscribe_link,
				'engagement_id'    => $engagement['ID']
			], $senders_data );
		}
		/**
		 * Fast path: this content variant has already been rendered once this run, the render
		 * validated byte-for-byte against a real per-recipient build, and this recipient's
		 * values are plain - so the mail is a string substitution, not a rebuild.
		 */
		$cache_key = md5( $email_subject . '|' . $email_body . '|' . $pre_header . '|' . $template_type . '|' . wp_json_encode( $utm_details ) );
		$entry     = $this->render_cache[ $cache_key ] ?? null;

		if ( is_array( $entry ) && 'validated' === $entry['state'] && ! $this->values_need_per_recipient_build( $entry, $merge_tags ) ) {
			list( $email_subject, $email_body ) = $this->materialize_cached_mail( $entry, $merge_tags, $c_uid, $hash_code, $unsubscribe_link, $contact_id );

			/** A mail materialised from a validated render is a successful build */
			if ( $this->render_failures > 0 ) {
				$this->render_failures = 0;
				$this->update_broadcast_data( array( 'render_failures' => 0 ) );
			}

			return array_merge( [
				'to'               => $to,
				'subject'          => $email_subject,
				'body'             => $email_body,
				'contact_id'       => $contact_id,
				'unsubscribe_link' => $unsubscribe_link,
				'engagement_id'    => $engagement['ID'],
				'broadcast_data'   => $data,
			], $senders_data );
		}

		/** Kept for the cache-preparation pass below, which needs the pre-build inputs */
		$raw_subject   = $email_subject;
		$raw_body      = $email_body;
		$raw_preheader = $pre_header;

		// Prepare email body with merge tags
		try {
			$built = $this->build_mail_content( array(
				'subject'       => $email_subject,
				'body'          => $email_body,
				'preheader'     => $pre_header,
				'template_type' => $template_type,
				'merge_tags'    => $merge_tags,
				'contact_id'    => $contact_id,
				'c_uid'         => $c_uid,
				'hash_code'     => $hash_code,
				'utm_details'   => $utm_details,
				'template_id'   => absint( $chosen_content['template_id'] ?? 0 ),
				'template_mode' => false,
			) );

			/**
			 * apply_template_by_type() returns a WP_Error when Emogrifier or the block renderer
			 * cannot parse the body. That fails this one engagement, it is not a thrown fault.
			 */
			if ( is_wp_error( $built ) ) {
				BWFCRM_Core()->conversation->fail_the_conversation( $engagement['ID'], $built->get_error_message() );

				return false;
			}

			list( $email_subject, $email_body ) = $built;

			/**
			 * First successful per-recipient build of this variant in the run: render the
			 * template once with placeholders and hold it as a candidate. It must reproduce
			 * this recipient's mail byte for byte to become a candidate at all, and it is only
			 * trusted once it also reproduces a DIFFERENT recipient's ordinary build - see
			 * maybe_promote_render_cache(). Any difference at either gate - an HTML-producing
			 * tag, an escaping quirk, a value the render contact baked in - keeps the variant
			 * on the per-recipient path for the whole run.
			 */
			if ( null === $entry ) {
				$this->maybe_prepare_render_cache( $cache_key, array(
					'subject'          => $raw_subject,
					'body'             => $raw_body,
					'preheader'        => $raw_preheader,
					'template_type'    => $template_type,
					'utm_details'      => $utm_details,
					'template_id'      => absint( $chosen_content['template_id'] ?? 0 ),
					'merge_tags'       => $merge_tags,
					'contact_id'       => $contact_id,
					'c_uid'            => $c_uid,
					'hash_code'        => $hash_code,
					'unsubscribe_link' => $unsubscribe_link,
					'reference'        => array( $email_subject, $email_body ),
				) );
			} elseif ( 'candidate' === ( $entry['state'] ?? '' ) ) {
				$this->maybe_promote_render_cache( $cache_key, $contact_id, $merge_tags, $c_uid, $hash_code, $unsubscribe_link, array( $email_subject, $email_body ) );
			}
		} catch ( Error|Exception $e ) {
			/**
			 * Exception as well as Error, and no die().
			 *
			 * What this block guards is do_shortcode() over third-party merge-tag callbacks and
			 * Emogrifier over user HTML, either of which can throw either kind - the sibling
			 * BWFAN_Mail_Handler_Controller::send_mail() catches both for the same reason. An
			 * Exception used to escape and fatal the request outright; an Error hit the die().
			 *
			 * Both took the request down from inside a claimed batch, so release_remaining_claim()
			 * and increment_campaign_offsets() never ran: every mail the batch had already delivered
			 * was lost from `processed` and `offset` for good, the claim row leaked, and five
			 * minutes later the orphan sweep freed the rows, the ordered claim picked the same
			 * batch first, and the same body threw again - an unbounded retry loop with nothing
			 * on the report to explain it.
			 *
			 * The first cut halted the whole broadcast on the spot. That stopped the loop, but a
			 * single contact whose data makes a merge-tag callback throw then stopped a send to
			 * everyone else, and halt is terminal - the only way on is to re-schedule, which throws
			 * the prepared run away and rebuilds it. Failing the one engagement is enough to end
			 * the loop: an errored row is never claimed again. So the recipient is failed with the
			 * reason on the record and the run carries on.
			 *
			 * A template that throws for everyone still has to halt, and halt rather than pause:
			 * a paused broadcast refuses content edits, a halted one accepts them, and a template
			 * fault needs exactly that edit. The counter below tells the two apart - it is
			 * persisted across runs like consecutive_failures, for the same reason, and a body
			 * that builds resets it.
			 */
			$message = __( 'Error in email body: ', 'wp-marketing-automations-pro' ) . $e->getMessage();

			BWFCRM_Core()->conversation->fail_the_conversation( $engagement['ID'], $message );
			BWFCRM_Broadcast_Helper::set_log( 'contact#' . $contact_id . ' mail body could not be built: ' . $e->getMessage() );

			$this->render_failures ++;
			$this->update_broadcast_data( array( 'render_failures' => $this->render_failures ) );

			if ( $this->render_failures < self::$RENDER_FAILURE_LIMIT ) {
				/** The caller records the engagement as failed and releases its claim, as for any mail it could not build */
				return false;
			}

			$data['halt_reason'] = $message;
			BWFAN_Model_Broadcast::update_status_to_halt( $this->broadcast['id'], $data );
			$this->processing::action_schedule_save_last_sent( $this->broadcast['id'] );

			BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' halted after ' . $this->render_failures . ' consecutive mail bodies failed to build: ' . $e->getMessage() );

			$this->stop_broadcast_required = true;

			return false;
		}

		/** A body that built ends the run of build failures - one write, and only when there was a run to end */
		if ( $this->render_failures > 0 ) {
			$this->render_failures = 0;
			$this->update_broadcast_data( array( 'render_failures' => 0 ) );
		}

		return array_merge( [
			'to'               => $to,
			'subject'          => $email_subject,
			'body'             => $email_body,
			'contact_id'       => $contact_id,
			'unsubscribe_link' => $unsubscribe_link,
			'engagement_id'    => $engagement['ID'],

			/** Carried so send_mail() can fire bwfan_before_send_email with the payload v1 gave it */
			'broadcast_data'   => $data,
		], $senders_data );
	}

	/**
	 * The rendering pipeline a single mail goes through, extracted verbatim from
	 * format_contact_mail() so the render cache can run it once per template as well as once
	 * per recipient. Order and semantics are unchanged - the comments travelled with the code.
	 *
	 * Merge tags are resolved before the body is styled, which is the order v1 uses.
	 * apply_template_by_type() runs the body through Emogrifier, and Emogrifier round trips the
	 * HTML through DOMDocument. DOM treats href as a URI attribute and percent encodes what it
	 * holds, so `href="{{unsubscribe_link}}"` comes back out as `href="%7B%7B...%7D%7D"`.
	 * Substituting after that point can no longer match the key - which is also why the render
	 * cache's placeholders are plain letters and underscores: they survive that encoding.
	 *
	 * In template mode (see maybe_prepare_render_cache()) the same pipeline runs over a
	 * placeholdered copy with no recipient: the loader gets contact 0, `{{unsubscribe_link}}`
	 * revealed out of the footer becomes the unsubscribe placeholder, and any merge tag still
	 * unresolved at the end throws - the caller reads that as "this template cannot be cached".
	 *
	 * @param array $args subject, body, preheader, template_type, merge_tags, contact_id,
	 *                    c_uid, hash_code, utm_details, template_id, template_mode
	 *
	 * @return array|WP_Error [ subject, body ] or the WP_Error apply_template_by_type() returned
	 * @throws Exception|Error From merge-tag callbacks, Emogrifier, or the template-mode check
	 */
	private function build_mail_content( $args ) {
		$email_subject = (string) $args['subject'];
		$email_body    = (string) $args['body'];
		$pre_header    = (string) $args['preheader'];
		$template_type = $args['template_type'];
		$merge_tags    = is_array( $args['merge_tags'] ) ? $args['merge_tags'] : array();
		$contact_id    = absint( $args['contact_id'] );
		$utm_details   = $args['utm_details'];
		$template_mode = ! empty( $args['template_mode'] );

		/** The pre-header carries merge tags too, and is injected into the body further down */
		if ( ! empty( $merge_tags ) ) {
			$email_subject = BWFAN_Core()->conversations->parse_email_merge_tags( $email_subject, $merge_tags );
			$email_body    = BWFAN_Core()->conversations->parse_email_merge_tags( $email_body, $merge_tags );
			$pre_header    = BWFAN_Core()->conversations->parse_email_merge_tags( $pre_header, $merge_tags );
		}

		/**
		 * Reveal what the mail footer protects, and resolve whatever the map did not cover.
		 *
		 * Two things are interleaved here, which is why it loops rather than doing each once.
		 *
		 * A campaign whose content carries no template_id renders from the raw body, which -
		 * unlike a saved template - never went through decode_mail_footer() and so still holds
		 * a literal {{mail_footer}}. Expanding it yields the footer with its own tags rewritten
		 * to {_{...}_} by BWFAN_Mail_Footer::parse_shortcode(), which is how they survive being
		 * decoded along with the footer itself. decode_mail_footer() is the only thing that
		 * turns them back and it runs at template save, never here.
		 *
		 * So the escaped form can be sitting in the body already (the map substituted a
		 * {{mail_footer}} entry) or be produced by the decode below (the map did not cover it).
		 * Un-escaping only before the decode misses the second case and the footer's
		 * {{unsubscribe_link}} still ships escaped; two passes settle both, and a body the map
		 * already covered in full breaks out on the first without decoding anything.
		 */
		for ( $pass = 0; $pass < 2; $pass ++ ) {
			$revealed = str_replace( array( '{_{', '}_}' ), array( '{{', '}}' ), $email_body );

			/**
			 * The second pass exists only for tags the decode below revealed. If it revealed
			 * none, whatever `{{` is still in the body is something decode_merge_tags() could
			 * not resolve, and running it over the whole body again would not change that -
			 * it would just cost another do_shortcode() per contact.
			 */
			if ( $pass > 0 && $revealed === $email_body ) {
				break;
			}

			$email_body = $revealed;

			/** The one revealed tag whose value the send loop itself builds per recipient */
			if ( $template_mode ) {
				$email_body = str_replace( '{{unsubscribe_link}}', self::$UNSUB_URL_PLACEHOLDER, $email_body );
			}

			$pending = false !== strpos( $email_body, '{{' ) || false !== strpos( $email_subject, '{{' ) || false !== strpos( $pre_header, '{{' );
			if ( ! $pending ) {
				break;
			}

			BWFAN_Merge_Tag_Loader::set_data( array(
				'broadcast_id' => absint( $this->broadcast['id'] ),
				'contact_id'   => $contact_id,
				'contact_mode' => 1,
			) );

			if ( false !== strpos( $email_subject, '{{' ) ) {
				$email_subject = BWFAN_Common::decode_merge_tags( $email_subject );
			}
			if ( false !== strpos( $pre_header, '{{' ) ) {
				$pre_header = BWFAN_Common::decode_merge_tags( $pre_header );
			}
			if ( false !== strpos( $email_body, '{{' ) ) {
				$email_body = BWFAN_Common::decode_merge_tags( $email_body );
			}
		}

		/**
		 * A tag the template-level decode could resolve is a tag whose value would be baked into
		 * the cached copy for every recipient. Refusing here is what keeps that impossible.
		 */
		if ( $template_mode && ( false !== strpos( $email_body, '{{' ) || false !== strpos( $email_subject, '{{' ) || false !== strpos( $pre_header, '{{' ) ) ) {
			throw new Exception( 'merge tags left unresolved at template level' );
		}

		/**
		 * Applied before the body is styled, as v1's prepare_email_body() does it.
		 *
		 * A merge tag that resolves to a full URL and was written after a literal scheme -
		 * `https://{{some_url_tag}}` - leaves `https://https://example.com` in the href.
		 * get_link_hash() corrects the URL it stores but convert_link_to_track_link() wraps
		 * the uncorrected one, so the pair never matched again and the click landed the
		 * visitor on the site's home page instead of the destination.
		 */
		$email_body = BWFAN_Common::bwfan_correct_protocol_url( $email_body );

		/**
		 * Also applied at template save, in get_or_create_multiple_templates(), so on the
		 * normal path this finds nothing to do. It is here for the campaign whose content
		 * carries no template_id and therefore renders from the raw body, which never went
		 * through that pass - block templates in particular need it, since it is the only
		 * thing that rewrites their custom tags into shortcodes. Converting already-converted
		 * markup is a no-op, so running it twice costs nothing.
		 *
		 * v1's html_entity_decode() is deliberately NOT reproduced here: v2 substitutes from
		 * the merge-tag map built at creation, whose keys are the tags exactly as the template
		 * stores them. Decoding first makes an entity-encoded key stop matching and ships the
		 * tag as literal text - the opposite of what it is supposed to fix.
		 */
		if ( method_exists( 'BWFAN_Common', 'correct_shortcode_string' ) ) {
			$email_body = BWFAN_Common::correct_shortcode_string( $email_body, $template_type );
		}

		$email_body = BWFCRM_Core()->conversation->apply_template_by_type( $email_body, $template_type, $pre_header );

		if ( is_wp_error( $email_body ) ) {
			return $email_body;
		}

		// Append UTM details & email body links
		if ( ! empty( $utm_details ) && ! empty( $merge_tags ) && is_array( $merge_tags ) ) {
			$utm_details = $this->append_merge_tag_to_utm( $utm_details, $merge_tags );
		}

		/** Everything the link rewriter reads off the conversation object - see the method */
		$this->prime_conversation_for_links( $contact_id, absint( $args['template_id'] ), $email_body );

		$email_body = BWFCRM_Core()->conversation->append_to_email_body_links( $email_body, $utm_details, $args['hash_code'], $args['c_uid'] );

		/**
		 * Last, as in v1's prepare_email_body(). The pre-header and the open pixel are added
		 * once every link has been rewritten, so the pixel's own URL is not fed through the
		 * click tracker above.
		 */
		$email_body = BWFCRM_Core()->conversation->append_to_email_body( $email_body, $pre_header, $args['hash_code'] );

		return array( $email_subject, $email_body );
	}

	/**
	 * Decide, once per content variant per run, whether its mails can be materialised from a
	 * pre-rendered template - and prove it before trusting it.
	 *
	 * The expensive per-mail work - footer expansion, Emogrifier, link rewriting - is identical
	 * for every recipient of a variant; only the merge-tag values, the uid, the tracking hash
	 * and the unsubscribe link differ. So the pipeline is run once over a copy whose
	 * per-recipient tags are replaced by DOM-safe placeholder tokens, and each mail becomes a
	 * string substitution.
	 *
	 * Nothing is trusted on classification alone. The recipient this method is called for has
	 * just had their mail built the ordinary way; the candidate template is materialised for
	 * that same recipient and must reproduce that mail byte for byte, or the variant stays on
	 * the per-recipient path. A wrong cache is therefore impossible; the failure mode of every
	 * unknown - an HTML-producing tag, an encoding quirk, a third-party filter - is "no
	 * speed-up", never a wrong mail.
	 *
	 * Substitution contexts differ deliberately: body tokens sit in DOM-serialised HTML, so
	 * their values are entity-escaped the way DOMDocument would have; pre-header and subject
	 * never pass through the DOM, so their values substitute raw.
	 *
	 * @param string $key Cache key of the variant
	 * @param array $args Raw template inputs + the reference recipient's build
	 *
	 * @return void
	 */
	private function maybe_prepare_render_cache( $key, $args ) {
		$fallback = function ( $reason ) use ( $key ) {
			$this->render_cache[ $key ] = array( 'state' => 'fallback', 'reason' => $reason );
			BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' render cache fallback (' . $reason . ') for variant ' . $key );
		};

		if ( false === apply_filters( 'bwfan_broadcast_render_cache', true, absint( $this->broadcast['id'] ) ) ) {
			$fallback( 'disabled by filter' );

			return;
		}

		if ( ! in_array( $args['template_type'], self::$RENDER_CACHE_TYPES, true ) ) {
			$fallback( 'template type ' . ( is_scalar( $args['template_type'] ) ? $args['template_type'] : gettype( $args['template_type'] ) ) );

			return;
		}

		/** UTM values carrying merge tags make every tracked link per-recipient */
		if ( ! empty( $args['utm_details'] ) && false !== strpos( wp_json_encode( $args['utm_details'] ), '{{' ) ) {
			$fallback( 'merge tags in UTM values' );

			return;
		}

		/** Link-trigger URLs need a per-contact auth hash appended at rewrite time */
		if ( false !== strpos( $args['body'], 'bwfan-link-trigger' ) ) {
			$fallback( 'link trigger URL' );

			return;
		}

		$merge_tags = is_array( $args['merge_tags'] ) ? $args['merge_tags'] : array();

		/**
		 * Conservative by name and by value. Tags known to emit HTML keep their variant on the
		 * per-recipient path so their markup still travels through Emogrifier; a scalar tag that
		 * merely matches the pattern (order_id) only costs its variant the speed-up. The value
		 * check catches what the names cannot: this recipient's values are in hand, and one that
		 * carries markup or a nested tag disqualifies the variant outright.
		 */
		$html_tags = (array) apply_filters( 'bwfan_broadcast_html_merge_tags', array( 'cart', 'order', 'product', 'items' ) );

		/** The footer is template-level: identical for every recipient, resolved in the render below */
		$template_safe = array();
		if ( isset( $merge_tags['{{mail_footer}}'] ) ) {
			$template_safe['{{mail_footer}}'] = $merge_tags['{{mail_footer}}'];
			unset( $merge_tags['{{mail_footer}}'] );
		}

		/**
		 * The unsubscribe tag is handled by URL placeholder, not by token: its stored value and
		 * the send loop's own unsubscribe link are the same URL, and as a generic token inside
		 * an href it would be click-wrapped at template level - see $UNSUB_URL_PLACEHOLDER.
		 */
		if ( isset( $merge_tags['{{unsubscribe_link}}'] ) ) {
			unset( $merge_tags['{{unsubscribe_link}}'] );
			$args['subject']   = str_replace( '{{unsubscribe_link}}', self::$UNSUB_URL_PLACEHOLDER, (string) $args['subject'] );
			$args['body']      = str_replace( '{{unsubscribe_link}}', self::$UNSUB_URL_PLACEHOLDER, (string) $args['body'] );
			$args['preheader'] = str_replace( '{{unsubscribe_link}}', self::$UNSUB_URL_PLACEHOLDER, (string) $args['preheader'] );
		}

		foreach ( $merge_tags as $tag => $value ) {
			$lower = strtolower( (string) $tag );

			if ( false !== strpos( $lower, 'bwfan_email_block_visibility' ) || false !== strpos( (string) $tag, 'bwf$__$' ) ) {
				$fallback( 'conditional block' );

				return;
			}

			foreach ( $html_tags as $needle ) {
				if ( '' !== (string) $needle && false !== strpos( $lower, strtolower( (string) $needle ) ) ) {
					$fallback( 'html-producing tag ' . $tag );

					return;
				}
			}

			$value = (string) $value;
			if ( false !== strpos( $value, '<' ) || false !== strpos( $value, '{{' ) || false !== strpos( $value, '{_{' ) ) {
				$fallback( 'dynamic value carries markup: ' . $tag );

				return;
			}
		}

		/** Longest keys first so a key containing another key can never be half-replaced */
		$keys = array_keys( $merge_tags );
		usort( $keys, function ( $a, $b ) {
			return strlen( $b ) - strlen( $a );
		} );

		$protect = function ( $part, $ns ) use ( $keys ) {
			$tokens = array();
			foreach ( $keys as $i => $tag ) {
				if ( false === strpos( $part, $tag ) ) {
					continue;
				}
				$token            = '__BWFANTAG' . $ns . $i . '__';
				$part             = str_replace( $tag, $token, $part );
				$tokens[ $token ] = $tag;
			}

			return array( $part, $tokens );
		};

		list( $ph_subject, $subject_tokens )     = $protect( (string) $args['subject'], 'S' );
		list( $ph_body, $body_tokens )           = $protect( (string) $args['body'], 'B' );
		list( $ph_preheader, $preheader_tokens ) = $protect( (string) $args['preheader'], 'P' );

		try {
			/**
			 * Rendered with the reference recipient's contact, not with contact 0. The footer's
			 * revealed tags resolve through the loader, and several of them are functions of the
			 * contact's uid (a profile link, say): with no contact they render empty or
			 * structurally different, and the whole - perfectly cacheable - variant fell to the
			 * per-recipient path. Whatever recipient-specific material this bakes in is dealt
			 * with below: the uid and the tracking hash are swapped for placeholders, and
			 * anything else contact-shaped cannot survive the second validation gate, because
			 * that gate compares against a different recipient.
			 */
			$built = $this->build_mail_content( array(
				'subject'       => $ph_subject,
				'body'          => $ph_body,
				'preheader'     => $ph_preheader,
				'template_type' => $args['template_type'],
				'merge_tags'    => $template_safe,
				'contact_id'    => absint( $args['contact_id'] ),
				'c_uid'         => '__BWFANUID__',
				'hash_code'     => '__BWFANTRACK__',
				'utm_details'   => $args['utm_details'],
				'template_id'   => absint( $args['template_id'] ),
				'template_mode' => true,
			) );
		} catch ( Error|Exception $e ) {
			$fallback( 'template render failed: ' . $e->getMessage() );

			return;
		}

		if ( is_wp_error( $built ) ) {
			$fallback( 'template render failed: ' . $built->get_error_message() );

			return;
		}

		/**
		 * The render contact's uid and tracking hash become placeholders wherever a loader-driven
		 * tag emitted them (the pipeline's own links and pixel already used the placeholders).
		 * Both are long hex strings, so a legitimate collision with static content is not real.
		 */
		$swap = array();
		if ( '' !== (string) $args['c_uid'] ) {
			$swap[ (string) $args['c_uid'] ] = '__BWFANUID__';
		}
		if ( '' !== (string) $args['hash_code'] ) {
			$swap[ (string) $args['hash_code'] ] = '__BWFANTRACK__';
		}
		$built[0] = strtr( $built[0], $swap );
		$built[1] = strtr( $built[1], $swap );

		$entry = array(
			'state'            => 'candidate',
			'render_cid'       => absint( $args['contact_id'] ),
			'subject'          => $built[0],
			'body'             => $built[1],
			'subject_tokens'   => $subject_tokens,
			'body_tokens'      => $body_tokens,
			'preheader_tokens' => $preheader_tokens,
			'has_unsub'        => false !== strpos( $built[1], self::$UNSUB_URL_PLACEHOLDER ) || false !== strpos( $built[0], self::$UNSUB_URL_PLACEHOLDER ),
		);

		/** Gate one: the render must reproduce the recipient it was rendered with, exactly */
		list( $check_subject, $check_body ) = $this->materialize_cached_mail( $entry, $args['merge_tags'], $args['c_uid'], $args['hash_code'], $args['unsubscribe_link'], absint( $args['contact_id'] ) );

		if ( $check_subject !== $args['reference'][0] || $check_body !== $args['reference'][1] ) {
			$fallback( 'validation mismatch' . self::describe_mismatch( $args['reference'], array( $check_subject, $check_body ) ) );

			return;
		}

		$this->render_cache[ $key ] = $entry;
		BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' render cache candidate for variant ' . $key . ', awaiting cross-recipient validation' );
	}

	/**
	 * Gate two: a candidate render is trusted only once it reproduces a different recipient's
	 * ordinary build byte for byte
	 *
	 * The template was rendered with one recipient's contact on the loader, so a merge tag
	 * resolved at template level could have baked that recipient's value into the copy. Gate
	 * one cannot see that - it compares against the very recipient whose value was baked. This
	 * gate can: materialised for a second recipient, a baked value stands out as a byte
	 * difference and the variant falls back. Until a different recipient comes along the
	 * candidate serves nobody, so a single-recipient broadcast simply never uses the cache.
	 *
	 * @param string $key Cache key of the candidate variant
	 * @param int $contact_id Recipient just built the ordinary way
	 * @param array $merge_tags That recipient's stored merge-tag values
	 * @param string $c_uid
	 * @param string $hash_code
	 * @param string $unsubscribe_link
	 * @param array $reference That recipient's ordinary build [ subject, body ]
	 *
	 * @return void
	 */
	private function maybe_promote_render_cache( $key, $contact_id, $merge_tags, $c_uid, $hash_code, $unsubscribe_link, $reference ) {
		$entry = $this->render_cache[ $key ] ?? null;
		if ( ! is_array( $entry ) || 'candidate' !== ( $entry['state'] ?? '' ) ) {
			return;
		}

		/** The render contact cannot cross-validate itself */
		if ( absint( $entry['render_cid'] ) === absint( $contact_id ) ) {
			return;
		}

		/** A recipient the fast path would refuse anyway proves nothing about the template */
		if ( $this->values_need_per_recipient_build( $entry, $merge_tags ) ) {
			return;
		}

		list( $check_subject, $check_body ) = $this->materialize_cached_mail( $entry, $merge_tags, $c_uid, $hash_code, $unsubscribe_link, $contact_id );

		if ( $check_subject !== $reference[0] || $check_body !== $reference[1] ) {
			$reason                               = 'cross-recipient validation mismatch' . self::describe_mismatch( $reference, array( $check_subject, $check_body ) );
			$this->render_cache[ $key ]['state']  = 'fallback';
			$this->render_cache[ $key ]['reason'] = $reason;
			BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' render cache fallback (' . $reason . ') for variant ' . $key );

			return;
		}

		$this->render_cache[ $key ]['state'] = 'validated';
		unset( $this->render_cache[ $key ]['render_cid'] );
		BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' render cache validated for variant ' . $key );
	}

	/**
	 * Where and how a validation comparison failed, for the fallback reason and the logs
	 *
	 * @param array $reference [ subject, body ] the ordinary build produced
	 * @param array $candidate [ subject, body ] the cached render materialised
	 *
	 * @return string Compact description: which part, first differing byte, short context
	 */
	private static function describe_mismatch( $reference, $candidate ) {
		$part = $reference[0] !== $candidate[0] ? 'subject' : 'body';
		$ref  = (string) ( 'subject' === $part ? $reference[0] : $reference[1] );
		$cand = (string) ( 'subject' === $part ? $candidate[0] : $candidate[1] );

		$max = min( strlen( $ref ), strlen( $cand ) );
		$at  = 0;
		while ( $at < $max && $ref[ $at ] === $cand[ $at ] ) {
			$at ++;
		}

		$context = function ( $s ) use ( $at ) {
			return substr( $s, max( 0, $at - 40 ), 80 );
		};

		return ' in ' . $part . ' at byte ' . $at . '; expected [' . $context( $ref ) . '] got [' . $context( $cand ) . ']';
	}

	/**
	 * Turn a validated template render into one recipient's mail
	 *
	 * Body tokens sit in DOM-serialised HTML, so their values are escaped the way DOMDocument
	 * would have serialised them (& < > - not quotes, which DOM leaves alone in text). The
	 * subject and the pre-header never pass through the DOM and substitute raw. The uid and the
	 * tracking hash are plain hex inside URLs the pipeline built after the DOM stage, so they
	 * substitute raw; the unsubscribe URL was in the document before the DOM stage and is
	 * escaped like any body value.
	 *
	 * @param array $entry Validated cache entry
	 * @param array $merge_tags This recipient's stored merge-tag values
	 * @param string $c_uid
	 * @param string $hash_code
	 * @param string $unsubscribe_link
	 *
	 * @return array [ subject, body ]
	 */
	private function materialize_cached_mail( $entry, $merge_tags, $c_uid, $hash_code, $unsubscribe_link, $contact_id = 0 ) {
		$merge_tags = is_array( $merge_tags ) ? $merge_tags : array();

		/**
		 * The unsubscribe URL that goes into the body is the TAG's output, not the send loop's
		 * header link: the two are built by different code and order their query args
		 * differently, and gate one compares bytes. Resolving the real tag for this recipient
		 * is exact by construction; the header value stays the fallback for a tag that
		 * resolves to nothing.
		 */
		$unsub_value = (string) $unsubscribe_link;
		if ( ! empty( $entry['has_unsub'] ) && $contact_id > 0 ) {
			BWFAN_Merge_Tag_Loader::set_data( array(
				'broadcast_id' => absint( $this->broadcast['id'] ),
				'contact_id'   => absint( $contact_id ),
				'contact_mode' => 1,
			) );
			$decoded = BWFAN_Common::decode_merge_tags( '{{unsubscribe_link}}' );
			if ( is_string( $decoded ) && '' !== $decoded && false === strpos( $decoded, '{{' ) ) {
				$unsub_value = $decoded;
			}
		}

		$body_repl = array(
			self::$UNSUB_URL_PLACEHOLDER => htmlspecialchars( $unsub_value, ENT_NOQUOTES, 'UTF-8', false ),
			'__BWFANUID__'               => (string) $c_uid,
			'__BWFANTRACK__'             => (string) $hash_code,
		);

		foreach ( $entry['body_tokens'] as $token => $tag ) {
			$value               = isset( $merge_tags[ $tag ] ) && is_string( $merge_tags[ $tag ] ) ? $merge_tags[ $tag ] : '';
			$body_repl[ $token ] = htmlspecialchars( $value, ENT_NOQUOTES, 'UTF-8', false );
		}
		foreach ( $entry['preheader_tokens'] as $token => $tag ) {
			$body_repl[ $token ] = isset( $merge_tags[ $tag ] ) && is_string( $merge_tags[ $tag ] ) ? $merge_tags[ $tag ] : '';
		}

		$subject_repl = array();
		foreach ( $entry['subject_tokens'] as $token => $tag ) {
			$subject_repl[ $token ] = isset( $merge_tags[ $tag ] ) && is_string( $merge_tags[ $tag ] ) ? $merge_tags[ $tag ] : '';
		}

		return array(
			empty( $subject_repl ) ? $entry['subject'] : strtr( $entry['subject'], $subject_repl ),
			strtr( $entry['body'], $body_repl ),
		);
	}

	/**
	 * Whether this recipient's values disqualify them from the cached render
	 *
	 * The variant validated against a recipient with plain values, but a later recipient can
	 * still carry markup or a nested tag in a custom-field value - substituted post-DOM that
	 * would ship escaped instead of rendered, and the old path would have treated it as markup.
	 * Such a recipient is built the ordinary way; everyone else keeps the fast path.
	 *
	 * @param array $entry Validated cache entry
	 * @param array $merge_tags This recipient's stored merge-tag values
	 *
	 * @return bool
	 */
	private function values_need_per_recipient_build( $entry, $merge_tags ) {
		if ( ! is_array( $merge_tags ) ) {
			return false;
		}

		foreach ( array( 'subject_tokens', 'body_tokens', 'preheader_tokens' ) as $bucket ) {
			foreach ( $entry[ $bucket ] as $tag ) {
				$value = isset( $merge_tags[ $tag ] ) && is_string( $merge_tags[ $tag ] ) ? $merge_tags[ $tag ] : '';
				/**
				 * Markup, a nested tag, or a quote. The quote matters when the token sits inside
				 * an HTML attribute: the DOM the ordinary path serialises through encodes quotes
				 * there, the cached substitution does not, and the validating recipients may not
				 * have carried one.
				 */
				if ( false !== strpos( $value, '<' ) || false !== strpos( $value, '{{' ) || false !== strpos( $value, '{_{' ) || false !== strpos( $value, '"' ) || false !== strpos( $value, "'" ) ) {
					return true;
				}
			}
		}

		return false;
	}


	/**
	 * Put the conversation objects into the state the link rewriter expects
	 *
	 * v1 reaches the rewriter through prepare_email_body(), which sets all of this on the way in.
	 * This flow builds the body itself and so has to set it too - none of it is optional:
	 *
	 * - broadcast_id and template_id are what maybe_insert_link() records a link against. Left at
	 *   0, BWFAN_Model_Links::check_if_link_exists() guards every clause with !empty() and its
	 *   WHERE collapses to the URL alone, so it hands back the l_hash of whichever broadcast
	 *   happened to use that URL first. Clicks are then attributed to that broadcast, and this
	 *   one's link metrics - looked up by its own oid and tid - find nothing at all.
	 *
	 * - engagement_type is the `type` those rows are keyed on.
	 *
	 * - contact is what convert_link_to_track_link() checks before asking for an auto-login auth
	 *   hash. BWFCRM_Conversation::append_to_email_body_links() assigns its own $contact onto the
	 *   Lite object unconditionally, so leaving it null does not merely skip the assignment, it
	 *   overwrites whatever Lite had - and every link-trigger URL shipped without bwfan-auth,
	 *   silently failing to log the recipient in.
	 *
	 * The contact is only built when the body actually carries a link trigger. It is a full
	 * contact read, and this runs once per recipient in the hot loop, so the mails that cannot
	 * use it should not pay for it.
	 *
	 * @param int $contact_id
	 * @param int $template_id Template this mail was rendered from
	 * @param string $email_body Body about to be rewritten
	 *
	 * @return void
	 */
	private function prime_conversation_for_links( $contact_id, $template_id, $email_body ) {
		$conversation = BWFCRM_Core()->conversation;

		$conversation->broadcast_id    = absint( $this->broadcast['id'] );
		$conversation->engagement_type = BWFAN_Email_Conversations::$TYPE_CAMPAIGN;
		$conversation->contact         = null;

		if ( false !== strpos( $email_body, 'bwfan-link-trigger' ) ) {
			$contact = new BWFCRM_Contact( absint( $contact_id ) );
			if ( $contact->is_contact_exists() ) {
				$conversation->contact = $contact;
			}
		}

		/**
		 * broadcast_id and template_id live on the Lite object only - the bridge in
		 * BWFCRM_Conversation carries contact and engagement_type across, nothing else.
		 */
		if ( isset( BWFAN_Core()->conversation ) ) {
			BWFAN_Core()->conversation->broadcast_id    = absint( $this->broadcast['id'] );
			BWFAN_Core()->conversation->template_id     = absint( $template_id );
			BWFAN_Core()->conversation->engagement_type = BWFAN_Email_Conversations::$TYPE_CAMPAIGN;

			/**
			 * Lite's automation email path stores the automation's template row on this object
			 * (BWFAN_Email_Conversations::prepare_email_conversation) and never clears it. When
			 * an automation mail went out earlier in this request, get_link_hash() would find it
			 * and take the template branch: serve that automation's cached hash for a matching
			 * URL and write this broadcast's links into that automation template's row. The
			 * session clones the conversation object, so the stale row survives that too. Null it so
			 * get_link_hash() falls through to maybe_insert_link(), which keys on this broadcast's ids.
			 */
			BWFAN_Core()->conversation->template = null;
		}
	}

	public function append_merge_tag_to_utm( $utm_details, $merge_tags = [] ) {
		if ( empty( $utm_details ) || ! is_array( $utm_details ) || empty( $merge_tags ) || ! is_array( $merge_tags ) ) {
			return $utm_details;
		}

		foreach ( $utm_details as $key => $value ) {
			$utm_details[ $key ] = BWFAN_Core()->conversations->parse_email_merge_tags( $value, $merge_tags );
		}

		return $utm_details;

	}

	/**
	 * Carry a smart send hold forward once the test batch has finished sending
	 *
	 * Reached only when the claim came back empty while the hold flag is set, which means the test
	 * batch is fully sent and the window it opened has run its course.
	 *
	 * The window is `execution_time`, and nothing else. maybe_start_smart_send_window() parks the
	 * broadcast there in the same statement that raises the hold flag, and the dispatcher will not
	 * enter the send loop - the only route into this method - until that time has passed. So being
	 * here is itself the proof that the window is over; there is nothing left to compare a clock
	 * against.
	 *
	 * A second deadline used to be stamped into the data blob as `hold_until` and checked here.
	 * Two clocks for one window can disagree, and did: a broadcast was found holding with a
	 * `hold_until` five and a half hours - the site's GMT offset - behind its execution_time, and
	 * an already-expired deadline means this method resolves the winner the moment it is reached,
	 * cutting the test short. One value that the dispatcher already enforces cannot drift from
	 * itself.
	 *
	 * @param array $data Broadcast data
	 *
	 * @return void
	 */
	private function resolve_smart_send_hold( $data ) {
		$broadcast_id = absint( $this->broadcast['id'] );

		/** Window is over, whichever template earned the most interaction wins */
		$db_winner = BWFAN_Model_Broadcast::get_broadcast_tids_stats( $broadcast_id, intval( $this->broadcast['type'] ) );
		if ( ! is_array( $db_winner ) || empty( $db_winner['winner'] ) ) {
			/**
			 * Nothing to compare against - drop the hold and let creation resume as it was.
			 *
			 * smart_sending_done is what closes smart sending for good. Without it the percentage
			 * that opened this window is still satisfied on the very next contact, so creation
			 * holds again, the send phase opens another window, and the broadcast waits out the
			 * configured hours over and over while the remaining contacts are never mailed.
			 * declare_the_winner_email() sets the same flag on the branch below.
			 */
			BWFAN_Model_Broadcast::remove_hold_flag_smart_sending( $broadcast_id );
			$updated_data = [
				'smart_sending_done'  => 1,
			];
			if ( isset( $data['v2'] ) && 1 === intval( $data['v2'] ) ) {
				$updated_data['engagements_created'] = 0;
			}
			BWFAN_Model_Broadcast::update_broadcast_data( $broadcast_id, $updated_data );
			BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $broadcast_id . ' smart send window closed with no stats, resuming without a winner' );

			return;
		}

		BWFAN_Model_Broadcast::declare_the_winner_email( $broadcast_id, $db_winner );
		BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $broadcast_id . ' smart send window closed, winner template: ' . $db_winner['winner'] );
	}

	/**
	 * Open the smart send window now that the test batch has been created and sent
	 *
	 * Reached only once the claim came back empty and a count confirmed no engagement of this
	 * broadcast is still waiting - which, while smart sending is undecided, means the partial
	 * send is complete. That is the point hold_broadcast marks, and the only place it is set,
	 * so the flag reads the same wherever it is checked: the test batch is out and the
	 * broadcast is waiting on the opens and clicks it earns.
	 *
	 * Creating the engagements is not enough on its own - they still have to be delivered
	 * before there is anything for the window to measure.
	 *
	 * @param array $data Broadcast data
	 *
	 * @return bool True when the send loop stops here - parked for its window, or handed back to creation
	 */
	private function maybe_start_smart_send_window( $data ) {
		if ( ! BWFCRM_Broadcast_Helper::check_if_smart_send_enabled( $data ) ) {
			return false;
		}

		/** A winner is already in, or smart sending closed without one - nothing left to wait for */
		if ( ! empty( $data['winner'] ) || ! empty( $data['smart_sending_done'] ) ) {
			return false;
		}

		/**
		 * The window measures what the test batch earns, and a test batch with nothing sent earns
		 * nothing - waiting it out only resolved the winner from empty stats an hour later. Close
		 * smart sending now, as resolve_smart_send_hold() does on empty stats, and let creation
		 * carry on with everyone else. True, so the caller stops here rather than completing.
		 */
		if ( ! $this->has_sent_engagement() ) {
			BWFAN_Model_Broadcast::update_broadcast_data( absint( $this->broadcast['id'] ), array(
				'smart_sending_done'  => 1,
				'engagements_created' => 0,
			) );
			BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' test batch sent nothing, smart sending skipped, resuming without a winner' );

			return true;
		}

		/**
		 * The flag and the window it refers to are written in one statement - update_broadcast_e_time()
		 * pushes execution_time out by the configured hours and writes this blob alongside it - so a
		 * broadcast can never be found holding without a window, or parked without the flag.
		 *
		 * $data is taken by value; nothing reads the in-memory copy after this point, and the caller
		 * breaks out of the send loop.
		 */
		$data['hold_broadcast'] = 1;
		BWFCRM_Broadcast_Helper::update_broadcast_e_time( $this->broadcast['id'], $data );

		BWFCRM_Broadcast_Helper::set_log( 'broadcast_id' . $this->broadcast['id'] . ' test batch sent, smart send window started' );

		return true;
	}

	/**
	 * Whether any engagement of this broadcast went out - bounced included, a bounce only follows a send
	 *
	 * @return bool
	 */
	private function has_sent_engagement() {
		global $wpdb;

		$sent = $wpdb->get_var( $wpdb->prepare( "SELECT `ID` FROM {$wpdb->prefix}bwfan_engagement_tracking WHERE `oid` = %d AND `type` = %d AND `c_status` IN ( %d, %d ) LIMIT 1", absint( $this->broadcast['id'] ), BWFAN_Email_Conversations::$TYPE_CAMPAIGN, BWFAN_Email_Conversations::$STATUS_SEND, BWFAN_Email_Conversations::$STATUS_BOUNCED ) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return ! empty( $sent );
	}

	public function is_broadcast_on_hold( $data = [] ) {
		/** Falls back to the broadcast's own data only when the caller passed none */
		if ( empty( $data ) ) {
			$data = ! empty( $this->broadcast['data'] ) ? $this->broadcast['data'] : array();
		}

		return is_array( $data ) && ! empty( $data['hold_broadcast'] );
	}

}
