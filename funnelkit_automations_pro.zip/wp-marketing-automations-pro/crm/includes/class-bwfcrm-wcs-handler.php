<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'BWFCRM_WCS_Handler' ) ) {
	#[\AllowDynamicProperties]
	class BWFCRM_WCS_Handler {
		private static $ins = null;
		public static $indexing = false;
		public static $is_contact_new = null;

		/**
		 * Statuses that keep a subscription in the contact's active subscriptions.
		 * Pending cancellation is paid up until its end date, so it still counts as active.
		 *
		 * @var string[]
		 */
		public static $active_statuses = [ 'active', 'pending-cancel' ];

		/**
		 * Statuses that take a subscription out of the contact's active subscriptions.
		 *
		 * @var string[]
		 */
		public static $inactive_statuses = [ 'cancelled', 'expired', 'on-hold', 'switched' ];

		public $subscription_id;
		public $from_status;
		public $to_status;
		public $email;

		/**
		 * Class instance
		 *
		 * @return BWFCRM_WCS_Handler|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		/**
		 * Class constructor
		 */
		public function __construct() {
			add_action( 'rest_api_init', [ $this, 'rest_init_register_async_request' ] );
			add_action( 'woocommerce_subscription_status_updated', [ $this, 'wcs_status_updated' ], 10, 3 );
			add_filter( 'fk_before_sending_wcs_status_change_async_request', [ __CLASS__, 'wcs_status_change' ], 10, 4 );
			add_filter( 'fk_wcs_status_change_async_capture', [ __CLASS__, 'fk_wcs_status_change_async_capture' ] );
			add_action( 'woocommerce_subscription_renewal_payment_complete', array( $this, 'update_renewal_data' ), 10, 2 );

			/** Trashed, deleted and restored subscriptions never go through a status change */
			add_action( 'woocommerce_subscription_trashed', [ $this, 'sync_trashed_or_deleted_subscription' ] );
			add_action( 'woocommerce_subscription_deleted', [ $this, 'sync_trashed_or_deleted_subscription' ] );
			add_action( 'woocommerce_untrash_subscription', [ $this, 'sync_trashed_or_deleted_subscription' ] );
			add_action( 'untrashed_post', [ $this, 'sync_trashed_or_deleted_subscription' ] );

			/** WCS copies subscription meta to renewal and resubscribe orders, and order meta to new subscriptions */
			add_filter( 'wc_subscriptions_object_data', [ __CLASS__, 'exclude_sync_meta_from_copy' ] );
			add_filter( 'bwfan_single_contact_get_array', [ $this, 'get_wcs_as_array' ], 10, 2 );
			add_filter( 'bwfcrm_transactional_mail_directories', [ $this, 'register_wcs_transactional_email_dir' ] );
		}

		/**
		 * Register WooCommerce Subscriptions transactional email directory
		 * when WooCommerce Subscriptions is active.
		 *
		 * @param array $dirs Existing extra email directories.
		 *
		 * @return array
		 */
		public function register_wcs_transactional_email_dir( $dirs ) {
			if ( bwfan_is_woocommerce_active() && bwfan_is_woocommerce_subscriptions_active() ) {
				$dirs[] = BWFAN_PRO_PLUGIN_DIR . '/modules/wc-subscription/transactional-emails';
			}

			return $dirs;
		}

		/**
		 * Register endpoints
		 *
		 * @return void
		 */
		public function rest_init_register_async_request() {

			/** Posting data to async request for processing subscription status changed to active */
			register_rest_route( 'fka/v1', '/wcs_status_changed', array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'capture_wcs_status_changed' ),
				'permission_callback' => array( __CLASS__, 'validate' ),
			) );
		}

		/**
		 * Method to validate nonce for the public creatable post requests
		 *
		 * @param WP_REST_Request $request
		 *
		 * @return bool
		 */
		public static function validate( $request ) {
			$posted_data = $request->get_body_params();

			/** Arrays pass isset() but make hash_equals() / hash_hmac() throw a TypeError */
			if ( ! isset( $posted_data['_nonce'], $posted_data['nonce_action'] ) || ! is_string( $posted_data['_nonce'] ) || ! is_string( $posted_data['nonce_action'] ) ) {
				return false;
			}

			return self::verify_nonce( $posted_data['_nonce'], $posted_data['nonce_action'] );
		}

		/**
		 * Create nonce for rest request using wp_hash method which is unique for each site
		 * Static nonce (no expiry) - intentional for async REST calls
		 * where standard WP nonces may expire between dispatch and processing.
		 *
		 * @return string
		 */
		public static function create_nonce( $action = '' ) {
			return substr( wp_hash( $action, 'nonce' ), - 12, 10 );
		}

		/**
		 * verify nonce in rest calls
		 *
		 * @param $nonce
		 * @param $action
		 *
		 * @return bool
		 * @see validate()
		 */
		public static function verify_nonce( $nonce, $action ) {
			$expected = self::create_nonce( $action );

			if ( empty( $expected ) || empty( $nonce ) ) {
				return false;
			}

			return ( hash_equals( $expected, $nonce ) );
		}

		/**
		 * @param $subscription WC_Subscription
		 * @param $to
		 * @param $from
		 *
		 * @return void
		 */
		public function wcs_status_updated( $subscription, $to, $from ) {
			if ( ! $subscription instanceof WC_Subscription ) {
				return;
			}

			/**
			 * Sync the subscriber row here, before the async request goes out. The async request can be lost
			 * (blocked REST route, failed non-blocking post) and is never retried, and every renewal goes
			 * on-hold then back to active, so activation cannot depend on it.
			 *
			 * This runs inside WCS's own status change: an exception here would make WCS restore the old
			 * status, so a sync failure must never escape.
			 */
			if ( in_array( $to, self::$active_statuses, true ) || in_array( $to, self::$inactive_statuses, true ) ) {
				try {
					self::create_update_wcs_subscriber( $subscription, $to, $from );
				} catch ( Error|Exception $r ) {
					$ins = WooFunnels_DB_Updater::get_instance();
					$ins->event_advanced_logs( "Error occurred: " . $r->getMessage() );
				}
			}

			$extra_data = apply_filters( 'fk_before_sending_wcs_status_change_async_request', [], $subscription->get_id(), $from, $to );
			/** Send async call */
			$data = array(
				'wcs_id'       => $subscription->get_id(),
				'from'         => $from,
				'to'           => $to,
				'_nonce'       => self::create_nonce( 'bwf_rest_wcs_status_changed' ),
				'nonce_action' => 'bwf_rest_wcs_status_changed'
			);
			if ( ! empty( $extra_data ) && is_array( $extra_data ) ) {
				$data = array_merge( $extra_data, $data );
			}


			$flag_saved_val = get_transient( 'bwfan_stop_async_call' );
			if ( 1 === intval( $flag_saved_val ) ) {
				self::process_events( $data );
			} else {

				$url  = home_url() . '/?rest_route=/fka/v1/wcs_status_changed';
				$args = bwf_get_remote_rest_args( $data );

				BWFAN_Common::event_advanced_logs( "Sending data for order status change JSON endpoint. URL: " . $url );
				BWFAN_Common::event_advanced_logs( $data );

				$start_time = microtime( true );
				$response   = wp_remote_post( $url, $args );
				BWFAN_Common::event_advanced_logs( "Response: " . $url );
				BWFAN_Common::event_advanced_logs( $response );

				$end_time = microtime( true );
				if ( ( $end_time - $start_time ) > 0.2 ) {
					/** Curl took minimum 0.2 secs */
					$flag_saved_val = get_transient( 'bwfan_stop_async_call' );
					if ( empty( $flag_saved_val ) ) {
						set_transient( 'bwfan_stop_async_call', 1, WEEK_IN_SECONDS );
					}
				}
			}


		}

		/**
		 *
		 *
		 * @param $request
		 *
		 * @return void
		 */
		public static function capture_wcs_status_changed( $request ) {
			BWFAN_PRO_Common::nocache_headers();
			$posted_data = $request->get_body_params();
			self::process_events( $posted_data );
		}

		/**
		 * @param $posted_data
		 *
		 * @return void
		 */
		public static function process_events( $posted_data ) {
			if ( empty( $posted_data ) ) {
				return;
			}
			BWFAN_Common::event_advanced_logs( 'WCS status change endpoint callback data received: ' );
			BWFAN_Common::event_advanced_logs( $posted_data );

			$wcs_id      = isset( $posted_data['wcs_id'] ) ? $posted_data['wcs_id'] : 0;
			$status_from = isset( $posted_data['from'] ) ? $posted_data['from'] : '';
			$status_to   = isset( $posted_data['to'] ) ? $posted_data['to'] : '';

			/** If data aren't passed */
			if ( empty( $wcs_id ) || empty( $status_from ) || empty( $status_to ) ) {
				return;
			}

			/** If order is not valid */
			$subscription = wcs_get_subscription( $wcs_id );

			if ( ! $subscription instanceof WC_Subscription ) {
				return;
			}

			try {
				/**
				 * Activation is already synced inline in wcs_status_updated(). This pass is a no-op when that
				 * worked, and repairs the row if it did not.
				 *
				 * Only sync when the subscription is still active. A stale queued async request could otherwise
				 * re-add a subscription that has since been cancelled, expired or put on hold — those
				 * transitions are applied inline and could be overwritten by the out-of-order activation.
				 */
				if ( 'active' === $status_to && $subscription->has_status( 'active' ) ) {
					self::create_update_wcs_subscriber( $subscription, $status_to, $status_from );
				}
				do_action( 'fk_wcs_status_change_async_capture', $posted_data );

			} catch ( Error|Exception $r ) {
				$ins = WooFunnels_DB_Updater::get_instance();
				$ins->event_advanced_logs( "Error occurred: " . $r->getMessage() );
			}
		}

		/**
		 * Append extra data for order status change
		 *
		 * @param $extra_data
		 * @param $wcs_id
		 * @param $from
		 * @param $to
		 *
		 * @return mixed
		 */
		public static function wcs_status_change( $extra_data, $wcs_id, $from, $to ) {
			$data = [
				'wcs_id'        => $wcs_id,
				'from'          => $from,
				'to'            => $to,
				'unique_key'    => get_option( 'bwfan_u_key', false ),
				'function_name' => 'wcs_order_status_changed',
			];

			try {
				$a_e_id = BWFAN_Model_Automation_Events::insert_data( $data );
			} catch ( Error $e ) {
				BWFAN_Common::log_test_data( 'Automation Event Insert Row Error: ' . $e->getMessage(), 'db-creation-errors', true );
				$table_instance = new BWFAN_DB_Table_Automation_Events();
				$table_instance->create_table();

				$a_e_id = BWFAN_Model_Automation_Events::insert_data( $data );
			}

			if ( ! empty( $a_e_id ) && $a_e_id > 0 ) {
				$extra_data['a_e_id'] = $a_e_id;
			}

			return $extra_data;
		}

		/**
		 * Get or create contact
		 *
		 * @param $subscription
		 * @param bool $update_existing Whether an existing contact's profile is updated from the subscription's billing details
		 *
		 * @return int
		 */
		public static function get_or_create_contact( $subscription, $update_existing = true ) {
			if ( ! $subscription instanceof WC_Subscription ) {
				return 0;
			}
			$email   = $subscription->get_billing_email();
			$user_id = $subscription->get_user_id();

			// Try to get existing contact
			$contact              = new \WooFunnels_Contact( $user_id, $email );
			self::$is_contact_new = false;
			if ( 0 === $contact->get_id() ) {
				self::$is_contact_new = true;
				$contact->set_email( $email );
			}

			if ( ! self::$is_contact_new && ! $update_existing ) {
				/** Linking the WordPress user is not a profile update, so a guest contact still gets it */
				if ( $user_id > 0 && empty( $contact->get_wpid() ) ) {
					$contact->set_wpid( $user_id );
					$contact->save();
				}

				return $contact->get_id();
			}

			if ( $user_id > 0 ) {
				$contact->set_wpid( $user_id );
			}

			$contact->set_f_name( $subscription->get_billing_first_name() );
			$contact->set_l_name( $subscription->get_billing_last_name() );

			$country = $subscription->get_billing_country();
			if ( ! empty( $country ) && 2 === strlen( $country ) ) {
				$contact->set_country( $country );
			}

			/** Appending country code in phone number if not added */
			$contact_no = $subscription->get_billing_phone();
			if ( class_exists( 'BWFAN_Phone_Numbers' ) && ! empty( $contact_no ) && ! empty( $contact->get_country() ) ) {
				$contact_no = \BWFAN_Phone_Numbers::add_country_code( $contact_no, $contact->get_country() );
			}
			$contact->set_contact_no( $contact_no );

			$state = $subscription->get_billing_state();
			/** Set state only if both country and order state are not empty */
			if ( ! empty( $country ) && ! empty( $state ) ) {
				$state = bwf_get_states( $country, $state );
				$contact->set_state( $state );
			}

			$contact->save();

			return $contact->get_id();
		}

		/**
		 * Get the contact a subscription was synced under, if that contact still exists
		 *
		 * @param WC_Subscription $subscription
		 *
		 * @return int
		 */
		public static function get_synced_contact_id( $subscription ) {
			$cid = absint( $subscription->get_meta( '_fka_cid' ) );
			if ( empty( $cid ) ) {
				return 0;
			}

			$contact = new \WooFunnels_Contact( '', '', '', $cid );

			return $contact->get_id() > 0 ? $cid : 0;
		}

		/**
		 * Get product and variation ids of a subscription's line items
		 *
		 * @param WC_Subscription $subscription
		 *
		 * @return string[]
		 */
		public static function get_subscription_product_ids( $subscription ) {
			$products = [];
			foreach ( $subscription->get_items() as $item ) {
				$item_data  = $item->get_data();
				$products[] = strval( $item_data['product_id'] );
				if ( ! empty( $item_data['variation_id'] ) ) {
					$products[] = strval( $item_data['variation_id'] );
				}
			}

			return $products;
		}

		/**
		 * Get the total paid renewals across every subscription synced to a contact
		 *
		 * Counted from WooCommerce each time instead of adding to the stored value, so the import and the
		 * live path agree and a subscription is never counted twice or missed.
		 *
		 * @param int $cid
		 * @param WC_Subscription|null $subscription Subscription being synced, counted even if it is not linked to the contact yet
		 *
		 * @return int
		 */
		public static function get_contact_renewal_count( $cid, $subscription = null ) {
			$subscriptions = wcs_get_subscriptions( [
				'subscriptions_per_page' => -1,
				'subscription_status'    => array_keys( wcs_get_subscription_statuses() ),
				'meta_query'             => [ //phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					[
						'key'   => '_fka_cid',
						'value' => absint( $cid ),
					],
				],
			] );
			if ( $subscription instanceof WC_Subscription ) {
				$subscriptions[ $subscription->get_id() ] = $subscription;
			}

			$count = 0;
			foreach ( $subscriptions as $item ) {
				if ( $item instanceof WC_Subscription ) {
					$count += intval( $item->get_payment_count( 'completed', 'renewal' ) );
				}
			}

			return $count;
		}

		/**
		 * Get the valid ids, products and next renewal date of a contact's active subscriptions
		 *
		 * Next renewal date is the earliest upcoming payment, or the earliest overdue one when none is upcoming,
		 * stored in site time like the other date columns.
		 *
		 * @param array $subscription_ids
		 *
		 * @return array
		 */
		public static function get_active_subscriptions_summary( $subscription_ids ) {
			$valid_ids    = [];
			$products     = [];
			$next_payment = 0;
			$overdue      = 0;
			$now          = time();

			foreach ( $subscription_ids as $subscription_id ) {
				$subscription = wcs_get_subscription( $subscription_id );
				/** Deleted, trashed or no longer active subscriptions drop out */
				if ( ! $subscription instanceof WC_Subscription || ! $subscription->has_status( self::$active_statuses ) ) {
					continue;
				}
				$valid_ids[] = strval( $subscription_id );
				$products    = array_merge( $products, self::get_subscription_product_ids( $subscription ) );

				$time = $subscription->get_time( 'next_payment' );
				if ( empty( $time ) ) {
					continue;
				}
				if ( $time >= $now ) {
					$next_payment = empty( $next_payment ) ? $time : min( $next_payment, $time );
				} else {
					$overdue = empty( $overdue ) ? $time : min( $overdue, $time );
				}
			}

			$products = array_values( array_unique( $products ) );
			sort( $products );

			$time = ! empty( $next_payment ) ? $next_payment : $overdue;

			return [
				'ids'               => $valid_ids,
				'products'          => $products,
				'next_renewal_date' => empty( $time ) ? null : get_date_from_gmt( gmdate( 'Y-m-d H:i:s', $time ) ),
			];
		}

		/**
		 * Keep the inactive-count flag on the subscription it belongs to
		 *
		 * A new subscription created from a copied order would otherwise start out counted as inactive, and its
		 * activation would take back another subscription's count.
		 *
		 * @param array $data Meta to copy, keyed by meta key
		 *
		 * @return array
		 */
		public static function exclude_sync_meta_from_copy( $data ) {
			if ( is_array( $data ) ) {
				unset( $data['_fka_inactive_counted'] );
			}

			return $data;
		}

		/**
		 * Get the contact the import indexes a subscription under
		 *
		 * Keeps the contact the subscription was synced under when its billing email changed since, like the live
		 * sync does, so a re-import doesn't move the subscription (and its renewals) to another contact.
		 *
		 * @param WC_Subscription $subscription
		 * @param bool $update_existing Whether an existing contact's profile is updated from the subscription's billing details
		 *
		 * @return int
		 */
		public static function get_import_contact_id( $subscription, $update_existing = true ) {
			if ( ! $subscription instanceof WC_Subscription ) {
				return 0;
			}

			$cid = self::get_synced_contact_id( $subscription );
			if ( ! empty( $cid ) ) {
				$contact = new \WooFunnels_Contact( '', '', '', $cid );
				if ( 0 !== strcasecmp( (string) $contact->get_email(), (string) $subscription->get_billing_email() ) ) {
					/** Billing details belong to the new email, so the synced contact's profile is left alone */
					self::$is_contact_new = false;

					return $cid;
				}
			}

			return self::get_or_create_contact( $subscription, $update_existing );
		}

		/**
		 * @param $subscription WC_Subscription
		 * @param $status_to
		 * @param $status_from
		 * @param $cid
		 * @param $indexing
		 *
		 * @return void
		 */
		public static function create_update_wcs_subscriber( $subscription, $status_to, $status_from, $cid = 0, $indexing = false ) {
			if ( ! $subscription instanceof WC_Subscription ) {
				return;
			}

			/** Import rebuilds the table, so nothing counts as synced during indexing */
			$is_synced = false === $indexing && ! empty( $subscription->get_meta( '_fka_cid' ) );

			$is_active_status = in_array( $status_to, self::$active_statuses, true );

			if ( false === $indexing && ! $is_active_status && ! in_array( $status_to, self::$inactive_statuses, true ) ) {
				return;
			}

			if ( empty( $cid ) ) {
				/** Keep the contact the subscription was synced under, even if billing email changed since */
				$cid = self::get_synced_contact_id( $subscription );

				/** A subscription that is not active only updates the row it was synced into, so it never creates a contact */
				if ( empty( $cid ) && false === $indexing && ! $is_active_status ) {
					return;
				}
				$cid = empty( $cid ) ? self::get_or_create_contact( $subscription ) : $cid;
			}
			if ( empty( $cid ) ) {
				return;
			}

			$wcs_id   = $subscription->get_id();
			$products = self::get_subscription_product_ids( $subscription );

			$data = BWFAN_Model_WCS_Subscriber::get_subscriber( $cid );

			$inactive_subs_count = intval( $data['inactive_subs_count'] ?? 0 );
			$l_order_date        = $data['l_order_date'] ?? null;

			$active_subs           = ! empty( $data['active_subscriptions'] ) && is_array( $data['active_subscriptions'] ) ? array_map( 'strval', $data['active_subscriptions'] ) : [];
			$subscription_products = $data['subscription_products'] ?? [];

			// Track if subscription was previously active to avoid double-counting inactive subscriptions
			$was_previously_active = in_array( strval( $wcs_id ), $active_subs, true );

			/**
			 * Not counted as inactive: a switched subscription was replaced by a new one, not lost, and a
			 * pending one (indexed by the import) has never been active.
			 */
			$counts_as_inactive = ! in_array( $status_to, [ 'switched', 'pending' ], true );

			/**
			 * Whether this subscription is currently included in inactive_subs_count. Stored on the subscription
			 * ('1' / '0') so reactivation only gives back a count that was actually taken. The import rebuilds the
			 * count, so it starts from not counted.
			 */
			$stored_counted_flag  = $subscription->meta_exists( '_fka_inactive_counted' ) ? strval( $subscription->get_meta( '_fka_inactive_counted' ) ) : null;
			$was_counted_inactive = false === $indexing && '1' === $stored_counted_flag;
			if ( false === $indexing && null === $stored_counted_flag ) {
				/** Synced by an older version, which did not store the flag: the status it left tells */
				$was_counted_inactive = $is_synced && in_array( $status_from, self::$inactive_statuses, true ) && 'switched' !== $status_from;
			}
			$is_counted_inactive = $was_counted_inactive;

			if ( ! $is_active_status ) {
				/** Remove subscription from active subscription */
				if ( $was_previously_active ) {
					$subscription_index = array_search( strval( $wcs_id ), $active_subs, true );
					unset( $active_subs[ $subscription_index ] );
					// Only increment inactive count if subscription was previously active
					if ( $counts_as_inactive ) {
						$inactive_subs_count += 1;
						$is_counted_inactive = true;
					}
				} elseif ( true === $indexing ) {
					if ( $counts_as_inactive ) {
						$inactive_subs_count += 1;
						$is_counted_inactive = true;
					}
				} else {
					/** Never tracked as active: leave the subscriber row untouched so no phantom row or contact link is created for a never-synced subscription */
					return;
				}
			} else {
				/** If status is active */
				/** Get the last order date */
				$last_order_time = method_exists( $subscription, 'get_last_order_date_created' ) ? $subscription->get_last_order_date_created() : 0;
				$last_order_time = $last_order_time instanceof WC_DateTime ? $last_order_time->getTimestamp() : absint( $last_order_time );
				if ( ! empty( $last_order_time ) ) {
					$l_order_date = get_date_from_gmt( gmdate( 'Y-m-d H:i:s', $last_order_time ) );
				} else {
					$last_order   = $subscription->get_last_order( 'all' );
					$l_order_date = $last_order instanceof WC_Order && $last_order->get_date_created() ? $last_order->get_date_created()->date( 'Y-m-d H:i:s' ) : null;
				}

				/** Use the most recent order date */
				if ( ! empty( $data['l_order_date'] ) && ! empty( $l_order_date ) ) {
					$l_order_date = max( $l_order_date, $data['l_order_date'] );
				} elseif ( empty( $l_order_date ) && ! empty( $data['l_order_date'] ) ) {
					$l_order_date = $data['l_order_date'];
				}

				/** Check if subscription is already in active list */
				if ( ! $was_previously_active ) {
					$active_subs[] = strval( $wcs_id );

					/** Only a subscription that was counted as inactive gives that count back */
					if ( $was_counted_inactive && $inactive_subs_count > 0 ) {
						$inactive_subs_count -= 1;
					}
				}
				$is_counted_inactive = false;
			}

			$renewal_count = self::get_contact_renewal_count( $cid, $subscription );

			$summary             = self::get_active_subscriptions_summary( $active_subs );
			$active_subs         = $summary['ids'];
			$active_subs_product = $summary['products'];
			$next_renewal_date   = $summary['next_renewal_date'];

			/** All products */
			$subscription_products = array_unique( array_merge( $subscription_products, $products ) );
			$subscription_products = array_values( $subscription_products );

			$active_subs_count = count( $active_subs );

			$row_data = [
				"cid"                   => $cid,
				"user_id"               => $subscription->get_user_id(),
				"l_order_date"          => $l_order_date,
				"next_renewal_date"     => $next_renewal_date,
				"active_subscriptions"  => wp_json_encode( $active_subs ),
				"subscription_products" => wp_json_encode( $subscription_products ),
				"active_subs_product"   => wp_json_encode( $active_subs_product ),
				"active_subs_count"     => $active_subs_count,
				"inactive_subs_count"   => $inactive_subs_count,
				"renewal_count"         => $renewal_count,
			];

			global $wpdb;
			if ( empty( $data ) ) {
				/** If subscriber not found */
				$wpdb->insert( $wpdb->prefix . 'bwfan_wcs_subscriber', $row_data );
			} else {
				$wpdb->update( $wpdb->prefix . 'bwfan_wcs_subscriber', $row_data, array( 'ID' => $data['ID'] ) );
			}

			$save_meta = false;

			/** Link on first sync, or re-link when the import indexed it under another contact or the old contact is gone */
			if ( absint( $subscription->get_meta( '_fka_cid' ) ) !== absint( $cid ) ) {
				$subscription->update_meta_data( '_fka_cid', $cid );
				$save_meta = true;
			}

			$counted_flag = $is_counted_inactive ? '1' : '0';
			if ( $counted_flag !== $stored_counted_flag ) {
				$subscription->update_meta_data( '_fka_inactive_counted', $counted_flag );
				$save_meta = true;
			}

			if ( $save_meta ) {
				$subscription->save_meta_data();
			}
		}


		/**
		 * FK wc subscription status change async captured
		 *
		 * @param $data
		 *
		 * @return void
		 */
		public static function fk_wcs_status_change_async_capture( $data ) {
			/** Delete row from automation events */
			if ( isset( $data['a_e_id'] ) ) {
				BWFAN_Model_Automation_Events::delete( $data['a_e_id'] );
			}

			$subscription = wcs_get_subscription( $data['wcs_id'] );
			if ( ! $subscription instanceof WC_Subscription ) {
				return;
			}

			do_action( 'bwfan_wcs_status_changed', $subscription, $data['to'], $data['from'] );
		}

		/**
		 * Update the subscriber rows of a subscription that was trashed, deleted or restored from trash
		 *
		 * WCS cancels a subscription before trashing or deleting it, and that status change is synced (and counted
		 * as inactive) like any other. This removes anything still listed as active, without counting it again.
		 *
		 * @param int $subscription_id
		 *
		 * @return void
		 */
		public function sync_trashed_or_deleted_subscription( $subscription_id ) {
			$subscription_id = absint( $subscription_id );
			if ( empty( $subscription_id ) ) {
				return;
			}

			/** untrashed_post fires for every post type */
			if ( 'untrashed_post' === current_filter() && 'shop_subscription' !== get_post_type( $subscription_id ) ) {
				return;
			}

			try {
				global $wpdb;
				$like = '%' . $wpdb->esc_like( '"' . $subscription_id . '"' ) . '%';
				$rows = $wpdb->get_results( $wpdb->prepare( "SELECT `ID`, `active_subscriptions` FROM {$wpdb->prefix}bwfan_wcs_subscriber WHERE `active_subscriptions` LIKE %s", $like ), ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

				foreach ( $rows as $row ) {
					$active_subs = json_decode( $row['active_subscriptions'], true );
					if ( ! is_array( $active_subs ) ) {
						continue;
					}

					$summary = self::get_active_subscriptions_summary( $active_subs );
					$wpdb->update( $wpdb->prefix . 'bwfan_wcs_subscriber', [
						'active_subscriptions' => wp_json_encode( $summary['ids'] ),
						'active_subs_product'  => wp_json_encode( $summary['products'] ),
						'active_subs_count'    => count( $summary['ids'] ),
						'next_renewal_date'    => $summary['next_renewal_date'],
					], [ 'ID' => $row['ID'] ] );
				}

				/** Restored from trash with an active status: add it back */
				$subscription = wcs_get_subscription( $subscription_id );
				if ( $subscription instanceof WC_Subscription && $subscription->has_status( self::$active_statuses ) ) {
					self::create_update_wcs_subscriber( $subscription, $subscription->get_status(), 'trash' );
				}
			} catch ( Error|Exception $r ) {
				$ins = WooFunnels_DB_Updater::get_instance();
				$ins->event_advanced_logs( "Error occurred: " . $r->getMessage() );
			}
		}

		/**
		 * Update Renewal data
		 *
		 * @param $subscription
		 * @param $order
		 *
		 * @return void
		 */
		public function update_renewal_data( $subscription, $order ) {
			if ( ! $order instanceof WC_Order || ! $order->has_status( wc_get_is_paid_statuses() ) ) {
				return;
			}

			$cid        = self::get_synced_contact_id( $subscription );
			$cid        = empty( $cid ) ? $order->get_meta( '_woofunnel_cid' ) : $cid;
			$cid        = empty( $cid ) ? self::get_or_create_contact( $subscription ) : $cid;
			$subscriber = BWFAN_Model_WCS_Subscriber::get_subscriber( $cid );
			if ( empty( $subscriber ) ) {
				return;
			}

			$renewal_count = self::get_contact_renewal_count( $cid, $subscription );

			$active_subs = is_array( $subscriber['active_subscriptions'] ) ? $subscriber['active_subscriptions'] : [];
			$summary     = self::get_active_subscriptions_summary( $active_subs );

			$data = [
				'l_order_date'         => $order->get_date_created()->date( 'Y-m-d H:i:s' ),
				'next_renewal_date'    => $summary['next_renewal_date'],
				'renewal_count'        => $renewal_count,
				'active_subscriptions' => wp_json_encode( $summary['ids'] ),
				'active_subs_product'  => wp_json_encode( $summary['products'] ),
				'active_subs_count'    => count( $summary['ids'] ),
			];
			global $wpdb;
			$wpdb->update( $wpdb->prefix . 'bwfan_wcs_subscriber', $data, array( 'ID' => $subscriber['ID'] ) );
		}

		/**
		 * Get WCS data from synced subscriber table for contact get_array response.
		 * Replaces/enhances lite's get_wcs_as_array with deep integration data.
		 *
		 * @param array $contact_array The contact array being built.
		 * @param BWFCRM_Contact $contact The contact object.
		 *
		 * @return array Modified contact array with wcs data.
		 */
		public function get_wcs_as_array( $contact_array, $contact ) {
			if ( ! class_exists( 'WC_Subscriptions' ) ) {
				return $contact_array;
			}
			$cid = is_object( $contact ) && method_exists( $contact, 'get_id' ) ? $contact->get_id() : 0;
			if ( empty( $cid ) ) {
				return $contact_array;
			}

			$subscriber = BWFAN_Model_WCS_Subscriber::get_subscriber( $cid );
			if ( empty( $subscriber ) ) {
				return $contact_array;
			}

			$next_renewal_amount   = 0;
			$total_renewal_amount  = 0;
			$active_subs           = $subscriber['active_subscriptions'] ?? [];
			$stored_next_renewal   = $subscriber['next_renewal_date'] ?? '';
			$user_id               = intval( $subscriber['user_id'] ?? 0 );

			if ( $user_id > 0 && function_exists( 'wcs_get_users_subscriptions' ) ) {
				$user_subscriptions = wcs_get_users_subscriptions( $user_id );
				if ( ! empty( $user_subscriptions ) ) {
					$paid_statuses = wc_get_is_paid_statuses();
					foreach ( $user_subscriptions as $subscription ) {
						if ( ! $subscription instanceof WC_Subscription ) {
							continue;
						}
						$renewal_order_ids = $subscription->get_related_orders( 'ids', array( 'renewal', 'resubscribe' ) );
						foreach ( $renewal_order_ids as $order_id ) {
							$order = wc_get_order( $order_id );
							if ( $order instanceof WC_Order && $order->has_status( $paid_statuses ) ) {
								$total_renewal_amount += BWF_Plugin_Compatibilities::get_fixed_currency_price_reverse( $order->get_total(), BWF_WC_Compatibility::get_order_currency( $order ) );
							}
						}
					}
				}
			}

			if ( ! empty( $active_subs ) && is_array( $active_subs ) ) {
				$subscription_for_amount = null;
				foreach ( $active_subs as $sub_id ) {
					$subscription = wcs_get_subscription( $sub_id );
					if ( ! $subscription instanceof WC_Subscription ) {
						continue;
					}
					$sub_next_payment = $subscription->get_date( 'next_payment', 'site' );
					/** Rows synced before site time was used hold the GMT date */
					$sub_next_payment_gmt = $subscription->get_date( 'next_payment' );
					if ( ! empty( $stored_next_renewal ) && ! empty( $sub_next_payment ) && in_array( $stored_next_renewal, [ $sub_next_payment, $sub_next_payment_gmt ], true ) ) {
						$subscription_for_amount = $subscription;
						break;
					}
				}
				if ( null === $subscription_for_amount ) {
					$earliest_date = null;
					foreach ( $active_subs as $sub_id ) {
						$subscription = wcs_get_subscription( $sub_id );
						if ( ! $subscription instanceof WC_Subscription ) {
							continue;
						}
						$sub_next_payment = $subscription->get_date( 'next_payment' );
						if ( empty( $sub_next_payment ) ) {
							continue;
						}
						if ( null === $earliest_date || $sub_next_payment < $earliest_date ) {
							$earliest_date       = $sub_next_payment;
							$subscription_for_amount = $subscription;
						}
					}
				}
				if ( $subscription_for_amount instanceof WC_Subscription ) {
					$next_renewal_amount = BWFCRM_Contact::get_next_renewal_amount( $subscription_for_amount );
				}
			}

			$contact_array['wcs'] = [
				'active_subscriptions'   => intval( $subscriber['active_subs_count'] ?? 0 ),
				'inactive_subscriptions' => intval( $subscriber['inactive_subs_count'] ?? 0 ),
				'next_renewal_date'      => ! empty( $subscriber['next_renewal_date'] ) && '0000-00-00 00:00:00' !== $subscriber['next_renewal_date'] ? $subscriber['next_renewal_date'] : '',
				'next_renewal_amount'    => $next_renewal_amount,
				'total_renewal_count'    => intval( $subscriber['renewal_count'] ?? 0 ),
				'total_renewal_amount'   => number_format( $total_renewal_amount, 2 ),
				'l_order_date'           => $subscriber['l_order_date'] ?? '',
				'active_subscription_ids' => $active_subs,
				'active_subs_product'    => $subscriber['active_subs_product'] ?? [],
				'subscription_products'  => $subscriber['subscription_products'] ?? [],
			];

			return $contact_array;
		}

	}

	if ( class_exists( 'BWFCRM_WCS_Handler' ) ) {
		BWFCRM_Core::register( 'wcs_handler', 'BWFCRM_WCS_Handler' );
	}
}
