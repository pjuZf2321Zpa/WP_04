<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'BWFAN_Load_Importer' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Load_Importer {
		private static $ins = null;

		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function __construct() {
			add_action( 'bwfan_importer_loaded', array( $this, 'load_importers' ) );
		}

		/**
		 * Load importer classes
		 *
		 * @return void
		 */
		public function load_importers() {
			$integration_dir = __DIR__ . '/importers/v2';
			foreach ( glob( $integration_dir . '/class-*.php' ) as $_field_filename ) {
				if ( ! is_readable( $_field_filename ) ) { // survive update file-swap / partial deploy
					continue;
				}
				require_once( $_field_filename );
			}
		}

	}

	if ( class_exists( 'BWFAN_Load_Importer' ) ) {
		BWFCRM_Core::register( 'load_importer', 'BWFAN_Load_Importer' );
	}
}
