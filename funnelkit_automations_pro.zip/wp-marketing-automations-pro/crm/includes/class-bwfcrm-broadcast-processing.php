<?php
/**
 * Broadcast Processing Controller Class
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

#[AllowDynamicProperties]
final class BWFCRM_Broadcast_Processing {
	/** Constants */
	public static $CAMPAIGN_DRAFT = 1;
	public static $CAMPAIGN_SCHEDULED = 2;
	public static $CAMPAIGN_RUNNING = 3;
	public static $CAMPAIGN_COMPLETED = 4;
	public static $CAMPAIGN_HALT = 5;
	public static $CAMPAIGN_PAUSED = 6;

	public static $CAMPAIGN_EMAIL = 1;
	public static $CAMPAIGN_SMS = 2;
	public static $CAMPAIGN_WHATSAPP = 3;

	public $AS_CALL_TIME;

	public $SMS_PER_SECOND_LIMIT = 1;
	public $EMAIL_PER_SECOND_LIMIT = 10000;

	/** Class Properties */
	/** @var BWFCRM_Broadcast_Processing current_broadcast */
	private static $ins = null;

	public $started_send_mail_at = null;
	public $records_processed_in_one_sec = 0;

	public $last_engagement_sent = null;

	public $start_time = 0;

	/** @var array current_broadcast */
	public $current_broadcast = null;

	public $offset = 0;
	public $processed = 0;
	public $count = 0;
	public $daily_message_limit = 0;
	public $daily_achieved_limit = 0;
	public $contact_ids = array();
	public $stop_broadcast_required = false;
	public $stop_broadcast_for_shorten_url = false;

	public $default_email_settings = array();

	/** Email is supposed to utilise Daily Limit feature for now */
	public $supported_daily_limit_broadcast_types = array( 1 );

	private $logs = array();

	public $failed_cids = array();
	public $err_msg = array();

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	public function __construct() {
		/** Scheduler per Run time in seconds */
		$this->AS_CALL_TIME = $this->get_per_call_time();

		add_action( 'bwfcrm_broadcast_run_queue', array( $this, 'do_scheduler_work' ) );
	}

	public function do_scheduler_work() {
		/** If Sandbox mode active */
		if ( true === BWFAN_Common::is_sandbox_mode_active() ) {
			return;
		}

		if ( true === apply_filters( 'bwfcrm_disable_broadcast_run_queue', false ) ) {
			return;
		}

		$this->default_email_settings = BWFAN_Common::get_global_settings();

		/** SMS & EMail limit per second */
		$this->EMAIL_PER_SECOND_LIMIT = isset( $this->default_email_settings['bwfan_email_per_second_limit'] ) ? absint( $this->default_email_settings['bwfan_email_per_second_limit'] ) : 15;
		$this->EMAIL_PER_SECOND_LIMIT = apply_filters( 'bwfan_broadcast_email_per_second_limit', $this->EMAIL_PER_SECOND_LIMIT );
		$this->SMS_PER_SECOND_LIMIT   = apply_filters( 'bwfan_broadcast_sms_per_second_limit', $this->SMS_PER_SECOND_LIMIT );

		$this->start_time = time();
		BWFCRM_Load_Filters::load_filters();

		$this->set_contact_cache( true );

		/** Process scheduled broadcasts, make them running */
		$this->process_scheduled_broadcasts();
		if ( $this->is_time_exceeded() ) {
			/** Reset here too, the cache must not stay on for the rest of the request */
			$this->set_contact_cache();

			return;
		}

		bwf_clear_queries();

		/** Process running v2 broadcasts */
		$this->process_running_v2_broadcasts();

		$this->set_contact_cache();
	}

	public function process_scheduled_broadcasts() {
		$scheduled = BWFAN_Model_Broadcast::get_scheduled_broadcasts_to_run();

		if ( ! is_array( $scheduled ) || empty( $scheduled ) ) {
			return;
		}

		foreach ( $scheduled as $broadcast ) {
			if ( $this->is_time_exceeded() ) {
				break;
			}

			$this->process_single_scheduled_broadcasts( $broadcast );
		}
	}

	public function process_single_scheduled_broadcasts( $broadcast ) {
		/**
		 * Already set up for this execution time, so there is nothing to work out again.
		 *
		 * Broadcasts are now picked up an hour before they are due and stay scheduled until
		 * their execution time arrives, so this runs on the same row every few minutes for up
		 * to an hour. Without this guard each of those passes repeats the audience count, the
		 * last-contact lookup and the template upsert, and puts `engagements_created` back to 0
		 * after the engagements have already been created - sending the v2 flow back into
		 * creation on every tick. All that is left to do here is start it when it is due.
		 *
		 * The marker records that this broadcast has been set up, not what it was set up for.
		 * Keying it on the execution time looked tighter but tied it to a value the system moves
		 * on its own: every retry delay - the daily send cap, a URL shortener that would not
		 * answer - pushes execution_time out, and the marker then no longer matched a broadcast
		 * that was perfectly well prepared. It was re-counted, re-templated and put back into
		 * creation, on every delay, with its cursors reset underneath a run already in progress.
		 * Only a deliberate change invalidates preparation, and each of those paths - editing the
		 * audience or content, rescheduling, unscheduling - clears the marker itself.
		 */
		if ( $this->is_broadcast_prepared( $broadcast ) ) {
			$this->maybe_start_due_broadcast( $broadcast );

			return;
		}

		$args = BWFCRM_Broadcast_Helper::get_broadcast_query_args( $broadcast );

		$parentBroadcast = isset( $broadcast['parent'] ) ? absint( $broadcast['parent'] ) : false;
		/** Reset broadcast stats */
		delete_transient( 'bwfan_broadcast_stats' );
		/** Fetching last contact ID of a broadcast from the given filters */
		if ( ! empty( $parentBroadcast ) ) {
			$args['props']['limit']       = 1;
			$args['props']['offset']      = 0;
			$args['props']['grab_totals'] = true;
			/** exclude_unsubs and the two include_* flags already ride in props - see get_broadcast_query_args() */
			$contacts_array = BWFCRM_Core()->campaigns->get_unopen_broadcast_contacts( absint( $parentBroadcast ), $args['props'], OBJECT );
		} else {

			if ( ! isset( $args['props']['exclude_unsubs'] ) || false === $args['props']['exclude_unsubs'] ) {
				$args['props']['exclude_unsubs'] = apply_filters( 'bwfan_force_exclude_unsubscribe_contact', false );
			}
			$contacts_array = BWFCRM_Contact::get_contacts( '', 0, 1, $args['filters'], $args['props'], OBJECT );
		}
		$contacts       = $contacts_array['contacts'];
		$total_contacts = ! empty( $contacts ) && isset( $contacts_array['total_count'] ) ? intval( $contacts_array['total_count'] ) : 0;
		$last_contact   = is_array( $contacts ) && count( $contacts ) > 0 && $contacts[0] instanceof BWFCRM_Contact ? $contacts[0]->get_id() : 0;

		if ( $total_contacts > 0 && absint( $last_contact ) > 0 ) {
			/** Increment the last contact ID by 1, to always get the contacts with IDs less than ($last_contact+1)  */
			$last_contact            = absint( $last_contact ) + 1;
			$args['data']['content'] = $this->get_or_create_multiple_templates( $args['data']['content'], $args['props']['fetch_base'], true );

			/**
			 * The v2 flow is email only - SMS and WhatsApp always run on v1.
			 *
			 * Gate on the broadcast type rather than on `fetch_base`, which is hardcoded to
			 * email for any broadcast with a parent (the resend-to-unopened clones keep the
			 * parent's type, so an SMS or WhatsApp clone would otherwise be flagged v2).
			 */
			if ( self::$CAMPAIGN_EMAIL === absint( $broadcast['type'] ) ) {
				$args['data']['v2']                  = 1;
				$args['data']['engagements_created'] = 0;

				/**
				 * What is_broadcast_prepared() reads, so the passes that follow this one do nothing.
				 *
				 * Email only. SMS and WhatsApp are fetched when due, prepared and moved to running
				 * in this same call, so the marker never does any work for them - but the content
				 * edit guards read it as "engagements built with this content", and on a v1
				 * broadcast that is false: the content is read from the row on every run. Writing
				 * it for them refused a text fix on a running or paused SMS broadcast.
				 */
				$args['data']['prepared_for'] = $broadcast['execution_time'];

				/**
				 * Which preparation this is. prepared_for holds the execution time, so a reset and a
				 * second preparation put the same value back - this is what a creating worker compares
				 * to tell that the preparation it started on was thrown away underneath it.
				 */
				$args['data']['prep_id'] = wp_generate_password( 12, false );
			}

			BWFAN_Model_Broadcast::update_status_to_run( $broadcast, $last_contact, $args['data'], $total_contacts );

			return;
		}

		/**
		 * An empty audience only settles the broadcast once it is actually due.
		 *
		 * Email broadcasts are now picked up an hour before their execution time so their
		 * engagements can be prepared ahead of the send, which means this count runs an hour
		 * early too - and halting on it turned "nobody matches yet" into "nobody will ever
		 * match". Halt is terminal: nothing re-fetches status 5, so a broadcast scheduled for
		 * 09:00 whose segment fills between 08:00 and 09:00 - an overnight import finishing, a
		 * "signed up today" filter, a drip applying the tag - was killed at 08:00 and needed a
		 * manual reschedule. Before the lead time existed the count happened at 09:00 and it sent.
		 *
		 * Returning instead leaves it scheduled and unprepared, so every later pass counts again
		 * and it prepares the moment the audience appears. Once the execution time has passed an
		 * empty audience is final, and the halt stands as it always did.
		 */
		if ( ! empty( $broadcast['execution_time'] ) && time() < strtotime( $broadcast['execution_time'] ) ) {
			$this->set_log( 'broadcast_id' . $broadcast['id'] . ' has no contacts yet, still ahead of its execution time - will count again' );

			return;
		}

		$args['data']['halt_reason'] = __( 'No contacts found for this broadcast', 'wp-marketing-automations-pro' );
		BWFAN_Model_Broadcast::update_status_to_halt( $broadcast['id'], $args['data'] );
	}

	/**
	 * Whether this broadcast has already been prepared for the execution time it currently holds
	 *
	 * @param array $broadcast
	 *
	 * @return bool
	 */
	protected function is_broadcast_prepared( $broadcast ) {
		if ( empty( $broadcast['execution_time'] ) || absint( $broadcast['count'] ) < 1 ) {
			return false;
		}

		$data = isset( $broadcast['data'] ) && is_array( $broadcast['data'] ) ? $broadcast['data'] : array();

		/** Presence, not equality - see the note in process_single_scheduled_broadcasts() */
		return ! empty( $data['prepared_for'] );
	}

	/**
	 * Move an already prepared broadcast to running once its execution time has passed
	 *
	 * The counterpart to the status branch in update_status_to_run(), for the passes that skip
	 * the set-up work. last_modified is stamped a few seconds back on purpose, the same way, so
	 * maybe_broadcast_running() does not read this write as another worker holding the broadcast.
	 *
	 * @param array $broadcast
	 *
	 * @return void
	 */
	protected function maybe_start_due_broadcast( $broadcast ) {
		if ( empty( $broadcast['execution_time'] ) || time() < strtotime( $broadcast['execution_time'] ) ) {
			return;
		}

		BWFAN_Model_Broadcast::update( array(
			'status'        => BWFCRM_Campaigns::$CAMPAIGN_RUNNING,
			'last_modified' => date( 'Y-m-d H:i:s', time() - 6 ),
		), array(
			'id'     => absint( $broadcast['id'] ),
			'status' => BWFCRM_Campaigns::$CAMPAIGN_SCHEDULED,
		) );
	}

	public function get_or_create_multiple_templates( $emails, $mode = 1, $return_with_contents = false ) {
		if ( ! is_array( $emails ) ) {
			return array();
		}

		$result = array();
		foreach ( $emails as $email ) {
			/** Set template mode 1 - rich, 3 - html 4 - editor */
			$template_type = BWFAN_PRO_Common::get_email_template_type( $email['type'] );
			$data          = array( 'template' => $template_type );
			if ( isset( $email['whatsAppImage'] ) && $email['whatsAppImage'] ) {
				if ( isset( $email['whatsAppImageSetting'] ) && ! empty( $email['whatsAppImageSetting'] ) ) {
					$data = $email['whatsAppImageSetting'];
				}
			}
			$editor_body   = isset( $email['editor'] ) && is_array( $email['editor'] ) && isset( $email['editor']['body'] ) ? $email['editor']['body'] : '';
			$template_body = isset( $email['type'] ) && 'editor' === $email['type'] ? $editor_body : $email['body'];
			$template_body = method_exists( 'BWFAN_Common', 'correct_shortcode_string' ) ? BWFAN_Common::correct_shortcode_string( $template_body, $email['type'] ) : $template_body;

			/**
			 * If a template is a block or 5, then decode the specific blocks in the mail content.
			 * Decoding the specific blocks before saving the template data for fast execution at the time of sending.
			 * Replacing the global variables with their values as they are contact-specific
			 *
			 * For future versions, if the block is genric, we need to add it in the decode_specific_blocks_before function parameter.
			 *
			 * @since 3.5.3
			 */
			if ( 5 === intval( $template_type ) ) {
				include_once BWFAN_PRO_PLUGIN_DIR . '/crm/includes/class-bwfcrm-block-editor.php';
				if ( method_exists( 'BWFCRM_Block_Editor', 'decode_specific_blocks_before' ) ) {
					$template_body = BWFCRM_Block_Editor::decode_specific_blocks_before( $template_body, [ 'bwfbe_multi_product', 'bwfbe_coupon', 'bwfbe_social_icons' ] );
				}

				$global_val = class_exists( 'BWFCRM_Block_Editor' ) ? BWFCRM_Block_Editor::$global_settings_var : [];
				if ( ! empty( $global_val ) ) {
					$global_val_k  = array_keys( $global_val );
					$global_val_v  = array_values( $global_val );
					$template_body = str_replace( $global_val_k, $global_val_v, $template_body );
				}
			}
			$template_id = BWFCRM_Core()->conversation->get_or_create_template( $mode, 1 === $mode && isset( $email['subject'] ) ? $email['subject'] : '', $template_body, 'id', $data );
			if ( true === $return_with_contents ) {
				$email['template_id'] = $template_id;
				$result[]             = $email;
			} else {
				$result[] = $template_id;
			}
		}

		return $result;
	}

	/**
	 * Run one already-fetched broadcast through the legacy (v1) send loop
	 *
	 * The fetch and the iteration it used to own now live in process_running_v2_broadcasts(),
	 * which dispatches each row here or to the v2 controller, so this takes the single broadcast
	 * to work on rather than looking one up.
	 *
	 * @param array $broadcast The broadcast row to process
	 *
	 * @return void
	 */
	public function process_single_running_broadcast( $broadcast ) {
		$this->set_log( 'processing running broadcast' );
		if ( ! is_array( $broadcast ) || empty( $broadcast ) ) {
			return;
		}

		/** bwfan_before_executing_broadcast is fired by the caller, process_running_v2_broadcasts() */

		$this->started_send_mail_at = microtime( true );

		/**
		 * Update last_modified to inform subsequent requests
		 */
		$last_modified_time = current_time( 'mysql', 1 );
		BWFAN_Model_Broadcast::update( array( 'last_modified' => $last_modified_time ), array( 'id' => absint( $broadcast['id'] ) ) );
		$broadcast['last_modified']               = $last_modified_time;
		$this->current_broadcast['last_modified'] = $last_modified_time;

		$data = ! empty( $broadcast['data'] ) ? $broadcast['data'] : array();

		$this->processed = absint( $broadcast['processed'] );
		$this->offset    = absint( $broadcast['offset'] );
		$this->count     = absint( $broadcast['count'] );

		do {
			$this->set_log( 'broadcast_id' . $broadcast['id'] . '_before_fetch_contacts' );
			$this->contact_ids = BWFCRM_Broadcast_Helper::fetch_contacts_for_broadcast( $broadcast, $this );
			$error             = BWFCRM_Broadcast_Helper::error_while_fetching_contacts( $this->contact_ids, $broadcast['id'], $data );

			if ( $error ) {
				break;
			}

			if ( true === $this->stop_broadcast_required ) {
				$this->stop_broadcast_required = false;

				break;
			}

			if ( empty( $this->contact_ids ) ) {
				BWFAN_Model_Broadcast::update_status_to_complete( $broadcast['id'], $data, $this->processed, $this->count );
				self::action_schedule_save_last_sent( $broadcast['id'] );

				/** Reset broadcast stats */
				delete_transient( 'bwfan_broadcast_stats' );
				break;
			}

			$this->process_single_ongoing_broadcast();
			/** Continue to next broadcast, in case needed to end the current broadcast process */
			if ( true === $this->stop_broadcast_required ) {
				$this->stop_broadcast_required = false;

				break;
			}

			if ( $this->is_time_exceeded() ) {
				BWFAN_Model_Broadcast::update( array(
					'last_modified' => date( 'Y-m-d H:i:s', time() - 6 ),
				), array(
					'id' => absint( $broadcast['id'] ),
				) );
				BWFCRM_Common::reschedule_broadcast_action();
			}
		} while ( ! $this->is_time_exceeded() && ! BWFCRM_Common::memory_exceeded() );
	}

	/**
	 * Get all the broadcasts due for processing and run each on its matching flow
	 *
	 * The fetch returns both the v2 email broadcasts and the non-v2 ones - SMS, WhatsApp,
	 * and anything already running from before the v2 flow shipped - ordered by execution
	 * time, and the loop below dispatches each to the v2 or the legacy sender.
	 *
	 * @return void
	 */
	public function process_running_v2_broadcasts() {
		$this->set_log( 'processing running broadcasts' );
		$broadcasts = BWFAN_Model_Broadcast::get_broadcasts_by_status( '', true, true );
		if ( ! is_array( $broadcasts ) || empty( $broadcasts ) ) {
			return;
		}

		$this->set_log( count( $broadcasts ) . ' broadcasts found to process' );

		$current_time               = current_time( 'timestamp', 1 );
		$this->started_send_mail_at = microtime( true );

		/**
		 * Fired here, not per broadcast, to keep the contract it had before the v2 split: once per
		 * request, with an array of broadcasts, ahead of any per-broadcast work. Firing it from
		 * process_single_running_broadcast() instead would hand listeners a single broadcast row -
		 * so a foreach over the argument would silently walk that row's columns - and would skip
		 * the v2 broadcasts entirely, since that method is only reached on the legacy branch.
		 *
		 * Narrowed to the broadcasts actually due to send. The fetch now reaches an hour ahead so
		 * v2 broadcasts can have their engagements prepared, which means a broadcast sits in this
		 * array for roughly sixty consecutive ticks before a single mail exists. Listeners take
		 * this as "a broadcast run is about to send" and act accordingly - the bundled
		 * TranslatePress compatibility unhooks global wp_mail filters on it - so firing it through
		 * that whole hour tears their state down over and over for nothing.
		 */
		$due_broadcasts = array_values( array_filter( $broadcasts, static function ( $broadcast ) use ( $current_time ) {
			return ! empty( $broadcast['execution_time'] ) && $current_time >= strtotime( $broadcast['execution_time'] );
		} ) );

		if ( ! empty( $due_broadcasts ) ) {
			do_action( 'bwfan_before_executing_broadcast', $due_broadcasts );
		}

		foreach ( $broadcasts as $broadcast ) {
			/** Store current broadcast for class-wide access */
			$this->current_broadcast = $broadcast;

			if ( $this->is_time_exceeded() ) {
				break;
			}

			/**
			 * Check if the broadcast is valid and not delete engagement actions is in process
			 *
			 * Status aware, not bwf_has_action_scheduled(): a cleanup row left at status 1 by a
			 * worker that died read as "pending" forever and parked the broadcast on every tick -
			 * see BWFAN_Model_Broadcast::has_engagement_cleanup_queued().
			 */
			if ( ! $this->is_broadcast_valid() || BWFAN_Model_Broadcast::has_engagement_cleanup_queued( $broadcast['id'] ) ) {
				continue;
			}

			$v2broadcast = BWFCRM_Broadcast_Helper::is_v2_broadcast( $broadcast );
			if ( $v2broadcast ) {
				/**
				 * The daily send cap is deliberately not checked before this branch.
				 *
				 * Creating engagements sends no mail and consumes none of the cap - it is the
				 * work the one hour lead time exists to get done. Gating it on the cap meant a
				 * site already at its limit at 17:00, with a broadcast due at 18:00, hit
				 * `continue` on every tick of that hour, created nothing, and started from zero
				 * at 18:00: precisely the situation the lead time was built for. set_delay() was
				 * a no-op there too, since GREATEST() keeps the later time. The cap is checked
				 * below, immediately before sending, which is the only thing that spends it.
				 *
				 * check whether engagement created for current broadcast
				 */
				if ( isset( $broadcast['data']['engagements_created'] ) && 0 === intval( $broadcast['data']['engagements_created'] ) ) {
					/**
					 * Take the lock maybe_broadcast_running() reads before creating anything.
					 * The v1 loop stamps this in process_single_running_broadcast(), which the v2
					 * branch never calls, so without it two overlapping workers create the same
					 * engagements and the contact is mailed twice. Sending needs no equivalent,
					 * the claim_id batching already keeps two pipelines off the same rows.
					 */
					$last_modified_time                       = current_time( 'mysql', 1 );
					$this->current_broadcast['last_modified'] = $last_modified_time;
					BWFAN_Model_Broadcast::update( array( 'last_modified' => $last_modified_time ), array( 'id' => absint( $broadcast['id'] ) ) );

					$broadcast_email_v2 = new BWFCRM_Broadcast_V2_Email_Controller( $this );
					$broadcast_email_v2->create_v2_email_engagements();

					/**
					 * Creation finished with time still on the clock: carry straight on to sending.
					 *
					 * This used to `continue` unconditionally, which handed the first mail to the next
					 * tick. Nothing brought that tick forward - the completion path in
					 * create_v2_email_engagements() is the one exit that never calls yield_run(), so
					 * no worker ping went out, and the recurring runner row sits a full interval past
					 * the start of this one. A Broadcast Now therefore spent 30-90 seconds at
					 * "Ongoing, 0 sent" after every engagement was already built, and on a small
					 * audience that idle slot was several times the length of the send itself.
					 *
					 * Out of time means creation yielded, and yield_run() has already pinged the
					 * worker; the next tick picks the broadcast up as prepared. Anything else that
					 * stopped creation short - a status change, a reset, a query that failed - leaves
					 * the flag at 0, and the fresh read below turns that back into the `continue` it
					 * always was. Only a finished, running broadcast falls through, and the due check
					 * beneath still keeps a scheduled one from going out early.
					 */
					if ( $this->is_time_exceeded() ) {
						continue;
					}

					$fresh = BWFAN_Model_Broadcast::get_formatted_campaign_data( array( BWFAN_Model_Broadcast::get( absint( $broadcast['id'] ) ) ) );
					$fresh = is_array( $fresh ) && isset( $fresh[0] ) && is_array( $fresh[0] ) ? $fresh[0] : array();

					if ( empty( $fresh['data']['engagements_created'] ) || self::$CAMPAIGN_RUNNING !== absint( $fresh['status'] ?? 0 ) ) {
						continue;
					}

					/** The row as it is now: the controller built below reads current_broadcast */
					$broadcast               = $fresh;
					$this->current_broadcast = $fresh;
				}

				if ( $current_time < strtotime( $broadcast['execution_time'] ) ) {
					continue;
				}

				$broadcast_email_v2 = new BWFCRM_Broadcast_V2_Email_Controller( $this );

				/**
				 * Engagements are created up to an hour early, so the segment can gain contacts
				 * between then and now. One sweep here covers all of them, and after it the
				 * audience is closed for good.
				 *
				 * A false return means the sweep ran out of time with contacts still uncovered,
				 * so sending waits for the next pass rather than leaving them behind.
				 */
				if ( ! $broadcast_email_v2->maybe_create_topup_engagements() ) {
					continue;
				}

				/** Set delay if daily limit reached and set daily limit count */
				if ( $this->maybe_daily_limit_reached( $broadcast['type'] ) ) {
					BWFAN_Model_Broadcast::set_delay( $broadcast['id'] );

					continue;
				}

				/** Process the v2 broadcast */
				$broadcast_email_v2->send_email_process();
			} else {
				/** If not v2 broadcast, execution time is later SKIP */
				if ( $current_time < strtotime( $broadcast['execution_time'] ) ) {
					continue;
				}

				/** Set delay if daily limit reached and set daily limit count */
				if ( $this->maybe_daily_limit_reached( $broadcast['type'] ) ) {
					BWFAN_Model_Broadcast::set_delay( $broadcast['id'] );

					continue;
				}

				$this->set_log( 'broadcast_id' . $broadcast['id'] . ' is v1 broadcast' );
				/** If not v2 broadcast, then process it as normal */
				$this->process_single_running_broadcast( $broadcast );
			}
		}
		$this->set_log( 'broadcasts_loop_end' );

		/** Flush both buffers: $this->set_log() fills $this->logs, the helper keeps its own static one */
		$this->log();
		BWFCRM_Broadcast_Helper::log();
	}

	public function is_broadcast_valid() {
		$broadcast = $this->current_broadcast;
		$data      = $this->get_current_broadcast_data();

		/** SMS Validation */
		if ( self::$CAMPAIGN_SMS === absint( $broadcast['type'] ) ) {
			$provider = BWFCRM_Common::get_sms_provider_integration();
			if ( is_wp_error( $provider ) ) {
				$error_message       = $provider->get_error_message();
				$data['halt_reason'] = ! empty( $error_message ) ? $error_message : __( 'Invalid SMS settings', 'wp-marketing-automations-pro' );
				BWFAN_Model_Broadcast::update_status_to_halt( $broadcast['id'], $data );
				self::action_schedule_save_last_sent( $broadcast['id'] );

				return false;
			}
		}

		/** WhatsApp Validation */
		if ( self::$CAMPAIGN_WHATSAPP === absint( $broadcast['type'] ) && false === $this->maybe_validate_whatsapp_settings() ) {
			return false;
		}

		/** Broadcast Content Validation */
		$broadcast_content = $data['content'];
		if ( empty( $broadcast_content ) || ! is_array( $broadcast_content ) ) {
			$data['halt_reason'] = __( 'Broadcast content not found', 'wp-marketing-automations-pro' );
			BWFAN_Model_Broadcast::update_status_to_halt( $broadcast['id'], $data );
			self::action_schedule_save_last_sent( $broadcast['id'] );

			return false;
		}

		/** Validate broadcast might be running */
		if ( true === $this->maybe_broadcast_running() ) {
			return false;
		}
		$this->failed_cids = $data['failed_cids'] ?? [];
		$this->err_msg     = $data['failed_reason'] ?? [];

		return true;
	}

	public function get_per_second_limit() {
		/** Email */
		if ( self::$CAMPAIGN_EMAIL === absint( $this->current_broadcast['type'] ) ) {
			return absint( $this->EMAIL_PER_SECOND_LIMIT );
		}
		/** SMS */
		if ( self::$CAMPAIGN_SMS === absint( $this->current_broadcast['type'] ) ) {
			return absint( $this->SMS_PER_SECOND_LIMIT );
		}

		/** Not checking WhatsApp here */
		return false;
	}

	public function process_single_ongoing_broadcast() {
		$broadcast = $this->current_broadcast;
		$data      = $this->get_current_broadcast_data();

		$per_second_limit = $this->get_per_second_limit();
		foreach ( $this->contact_ids as $id ) {
			$this->set_log( 'contact#' . $id . '_start' );
			if ( $this->is_time_exceeded() || BWFCRM_Common::memory_exceeded() ) {
				$this->set_log( 'contact#' . $id . '_time exceeded' );
				break;
			}

			/**
			 *  Fallback, in case previously processed ID gets into loop again,
			 *  where offset must be old, and id must be new.
			 */
			if ( $this->offset <= $id ) {
				$this->set_log( 'contact#' . $id . ' moving to next contact ' . $this->offset . ' = ' . $id );
				continue;
			}

			/**
			 * If broadcast support daily limit, check that
			 * currently email type supports daily limit
			 * if daily limit reached then delay and end current broadcast
			 */
			$daily_limit_supported = in_array( absint( $broadcast['type'] ), $this->supported_daily_limit_broadcast_types );
			if ( $daily_limit_supported && $this->daily_achieved_limit >= $this->daily_message_limit ) {
				BWFAN_Model_Broadcast::set_delay( $broadcast['id'] );
				$this->stop_broadcast_required = true;

				return;
			}

			/** Hold for one second to complete, if per second limit achieved */
			if ( ! empty( $per_second_limit ) && $per_second_limit <= $this->records_processed_in_one_sec ) {
				$this->set_log( 'contact#' . $id . '_per_second_limit_reached' );
				$this->delay_time();
			}

			/**
			 * Check if Smart sending is enabled
			 * Maybe need to stop broadcast in case contacts processed
			 * If nothing returned, continue because smart sending is not enabled
			 * If hold returned, stop the broadcast
			 */
			/** Live counters, not the row as it was fetched - those do not move inside this run */
			$smart_send = BWFCRM_Broadcast_Helper::maybe_process_smart_send_v2( $broadcast, $this->processed, $this->count, intval( $broadcast['type'] ) );
			if ( 'hold' === $smart_send ) {
				$this->stop_broadcast_required = true;

				return;
			} elseif ( ! empty( $smart_send ) ) {
				$data['winner'] = absint( $smart_send );

				/**
				 * declare_the_winner_email() has already dropped the hold from the stored blob; this
				 * copy was read before that and still carries it. The failed-mail branch below writes
				 * this whole copy back, which put the hold - and its "waiting for the winner" notice -
				 * back onto a broadcast that was sending the winner.
				 */
				unset( $data['hold_broadcast'] );
				$broadcast['data'] = $data;
			}

			if ( self::$CAMPAIGN_SMS === absint( $broadcast['type'] ) ) {
				$this->process_broadcast_contact_sms( $broadcast, $id );
			} elseif ( self::$CAMPAIGN_WHATSAPP === absint( $broadcast['type'] ) ) {
				$this->whatsapp_delay_time();
				$this->process_broadcast_contact_whatsapp( $broadcast, $id );
			} else {
				$this->process_broadcast_contact_email( $broadcast, $id );
			}

			if ( true === $this->stop_broadcast_for_shorten_url ) {
				return;
			}

			/** set last engagement time */
			$this->last_engagement_sent = microtime( true );

			$this->records_processed_in_one_sec ++;
			$this->processed ++;
			$this->daily_achieved_limit ++;
			$this->offset = $id;

			if ( count( $this->failed_cids ) > 0 ) {
				$data['failed_cids']   = $this->failed_cids;
				$data['failed_reason'] = array_values( array_unique( $this->err_msg ) );
				$status                = count( $this->failed_cids ) >= 20 ? self::$CAMPAIGN_PAUSED : false;
				BWFAN_Model_Broadcast::update_broadcast_data_with_status( $broadcast['id'], $data, $status, $this->offset, $this->processed );

				/** If the last 10 engagements are failed, stop the broadcast */
				if ( count( $this->failed_cids ) >= 20 ) {
					$this->set_log( 'contact #' . $id . ' email failed. 20 consecutive failed contacts are: ' . implode( ', ', $this->failed_cids ) );
					$this->stop_broadcast_required = true;
				}
			} else {
				// No email failure
				if ( isset( $data['failed_cids'] ) ) {
					// case when failed_cids is set
					unset( $data['failed_cids'] );
					if ( isset( $data['failed_reason'] ) ) {
						unset( $data['failed_reason'] );
					}
					BWFAN_Model_Broadcast::update_broadcast_data_with_status( $broadcast['id'], $data, false, $this->offset, $this->processed );
				} else {
					/** One contact per call on this path, so the increment is always 1 */
					BWFAN_Model_Broadcast::increment_campaign_offsets( $broadcast['id'], $this->offset, 1 );
				}
			}

			if ( true === $this->stop_broadcast_required ) {
				return;
			}
		}
	}

	/**
	 * @param $broadcast
	 * @param $contact_id
	 *
	 * @return false|void
	 */
	public function process_broadcast_contact_whatsapp( $broadcast, $contact_id ) {
		$contact = new WooFunnels_Contact( '', '', '', absint( $contact_id ) );
		if ( empty( $contact->get_id() ) ) {
			return;
		}
		$this->set_log( 'contact#' . $contact_id . '_process_whatsapp_message_start' );

		$to = BWFAN_PRO_Common::get_contact_full_number( $contact );
		if ( empty( $to ) ) {
			$this->set_log( 'contact#' . $contact_id . '_no_phone_number_whatsapp' );

			return;
		}

		$data = $broadcast['data'];

		$broadcast_id        = absint( $broadcast['id'] );
		$broadcast_author_id = absint( $broadcast['created_by'] );
		$broadcast_content   = $data['content'];

		$template_winner = isset( $data['winner'] ) ? absint( $data['winner'] ) : 0;
		$chosen_content  = $this->get_current_email_template( $broadcast_content, $this->processed, $template_winner );

		$message_data = BWFCRM_Core()->conversation->create_campaign_conversation( $contact, $broadcast_id, $chosen_content['template_id'] ?? 0, $broadcast_author_id, BWFCRM_Campaigns::$CAMPAIGN_WHATSAPP );
		if ( is_wp_error( $message_data ) ) {
			$e_data = $message_data->get_error_data();
			if ( is_array( $e_data ) && isset( $e_data['conversation_id'] ) ) {
				BWFCRM_Core()->conversation->fail_the_conversation( absint( $e_data['conversation_id'] ), $message_data->get_error_message() );
			}

			return;
		}

		if ( ! isset( $message_data['conversation_id'] ) ) {
			$this->set_log( 'contact#' . $contact_id . '_conversation_id not found' );

			return;
		}
		$conversation_id = absint( $message_data['conversation_id'] );
		$hash_code       = isset( $message_data['hash_code'] ) ? $message_data['hash_code'] : '';
		$template        = isset( $message_data['template'] ) ? $message_data['template'] : '';
		$template_data   = isset( $message_data['template_data'] ) ? $message_data['template_data'] : array();
		$utm_details     = isset( $chosen_content['utm'] ) && is_array( $chosen_content['utm'] ) ? $this->get_utm_data_from_campaign_data( $chosen_content['utm'] ) : '';

		$message_body = BWFCRM_Core()->conversation->prepare_sms_body( $conversation_id, $contact_id, $hash_code, $template, $utm_details, $broadcast_id );
		if ( true === $this->stop_broadcast_for_shorten_url ) {
			return false;
		}
		$textdata = array(
			'type' => 'text',
			'data' => $message_body,
		);
		$message  = array( $textdata );
		if ( ! empty( $template_data ) && isset( $template_data['position'] ) && isset( $template_data['imageURL'] ) && ! empty( $template_data['position'] ) && ! empty( $template_data['imageURL'] ) ) {
			$imagedata = array(
				'type' => 'image',
				'data' => $template_data['imageURL'],
			);

			if ( $template_data['position'] == 'before' ) {
				$message = array( $imagedata, $textdata );
			} else {
				$message = array( $textdata, $imagedata );
			}
		}

		$response = BWFCRM_Core()->conversation->send_whatsapp_message( $to, $message, $utm_details );
		if ( is_array( $response ) && $response['status'] == true ) {
			BWFCRM_Core()->conversation->update_conversation_status( $conversation_id, BWFAN_Email_Conversations::$STATUS_SEND );

			return;
		}

		$error_message = __( 'Message could not be sent. ', 'wp-marketing-automations-pro' );

		if ( isset( $response['msg'] ) && ! empty( $response['msg'] ) ) {
			$error_message = $response['msg'];
		}

		BWFCRM_Core()->conversation->fail_the_conversation( $conversation_id, $error_message );
	}

	public function process_broadcast_contact_sms( $broadcast, $contact_id ) {
		$contact = new WooFunnels_Contact( '', '', '', absint( $contact_id ) );
		if ( empty( $contact->get_id() ) ) {
			return false;
		}

		$data = $broadcast['data'];

		$broadcast_id        = absint( $broadcast['id'] );
		$broadcast_author_id = absint( $broadcast['created_by'] );
		$broadcast_content   = $data['content'];
		if ( empty( $broadcast_content ) || ! is_array( $broadcast_content ) ) {
			return false;
		}

		$template_winner = isset( $data['winner'] ) ? absint( $data['winner'] ) : 0;
		$chosen_content  = $this->get_current_email_template( $broadcast_content, $this->processed, $template_winner );
		$sms_data        = BWFCRM_Core()->conversation->create_campaign_conversation( $contact, $broadcast_id, $chosen_content['template_id'] ?? 0, $broadcast_author_id, BWFCRM_Campaigns::$CAMPAIGN_SMS );
		if ( is_wp_error( $sms_data ) ) {
			$e_data = $sms_data->get_error_data();
			if ( is_array( $e_data ) && isset( $e_data['conversation_id'] ) ) {
				BWFCRM_Core()->conversation->fail_the_conversation( absint( $e_data['conversation_id'] ), $sms_data->get_error_message() );
			}

			return false;
		}

		if ( ! isset( $sms_data['conversation_id'] ) ) {
			return false;
		}

		$conversation_id = absint( $sms_data['conversation_id'] );
		$hash_code       = isset( $sms_data['hash_code'] ) ? $sms_data['hash_code'] : '';
		$template        = isset( $sms_data['template'] ) ? $sms_data['template'] : '';
		$utm_details     = isset( $chosen_content['utm'] ) && is_array( $chosen_content['utm'] ) ? $this->get_utm_data_from_campaign_data( $chosen_content['utm'] ) : '';
		$sms_body        = BWFCRM_Core()->conversation->prepare_sms_body( $conversation_id, $contact_id, $hash_code, $template, $utm_details, $broadcast_id );
		if ( true === $this->stop_broadcast_for_shorten_url ) {
			return false;
		}
		if ( is_wp_error( $sms_body ) ) {
			BWFCRM_Core()->conversation->fail_the_conversation( $conversation_id, $sms_body->get_error_message() );

			return false;
		}

		$to = BWFAN_PRO_Common::get_contact_full_number( $contact );

		if ( empty( $to ) ) {
			BWFCRM_Core()->conversation->fail_the_conversation( $conversation_id, __( 'No phone number found for this contact: ' . $contact_id, 'wp-marketing-automations-pro' ) );

			return false;
		}

		$send_sms_result = BWFCRM_Common::send_sms( array(
			'to'   => $to,
			'body' => $sms_body
		) );

		if ( is_wp_error( $send_sms_result ) ) {
			BWFCRM_Core()->conversation->fail_the_conversation( $conversation_id, $send_sms_result->get_error_message() );

			return false;
		}

		return BWFCRM_Core()->conversation->update_conversation_status( $conversation_id, BWFAN_Email_Conversations::$STATUS_SEND );
	}

	/**
	 * Get template data for passing it to conversation
	 *
	 * @param int $tid
	 * @param array $raw_template_data
	 *
	 * @return array
	 * @since 3.5.3
	 *
	 */
	public function get_template_from_id( $tid = 0, $raw_template_data = [] ) {
		$default_content = [
			'preheader' => isset( $raw_template_data['preheader'] ) ? $raw_template_data['preheader'] : '',
			'utm_data'  => ! empty( $raw_template_data['utmEnabled'] ) && isset( $raw_template_data['utm'] ) && is_array( $raw_template_data['utm'] ) ? $this->get_utm_data_from_campaign_data( $raw_template_data['utm'] ) : [],
		];
		if ( empty( $tid ) ) {
			return array_merge( [
					'template' => 'editor' === $raw_template_data['type'] ? $raw_template_data['editor']['body'] : $raw_template_data['body'],
					'subject'  => $raw_template_data['subject'],
					'type'     => $raw_template_data['type'],
				], $default_content );
		}
		/**
		 * The cache only holds the template row, so the per-call content has to be merged on
		 * the way out here too. Returning the bare cached row dropped `preheader` and
		 * `utm_data` for every contact after the first, which left their merge tags
		 * uncollected and rendering as literal placeholders.
		 */
		if ( ! empty( $this->current_broadcast['template_data_by_id'][ $tid ] ) ) {
			return array_merge( $this->current_broadcast['template_data_by_id'][ $tid ], $default_content );
		}

		$template = BWFAN_Model_Templates::get( $tid );
		if ( ! empty( $template ) ) {
			$this->current_broadcast['template_data_by_id'][ $tid ] = $template;

			return array_merge( $template, $default_content );
		}

		return array_merge( [
			'template' => 'editor' === $raw_template_data['type'] ? $raw_template_data['editor']['body'] : $raw_template_data['body'],
			'subject'  => $raw_template_data['subject'],
			'type'     => $raw_template_data['type'],
		], $default_content );
	}

	public function process_broadcast_contact_email( $broadcast, $contact_id ) {
		$contact = new WooFunnels_Contact( '', '', '', absint( $contact_id ) );
		if ( empty( $contact->get_id() ) ) {
			return;
		}

		$data = $broadcast['data'];

		$broadcast_id        = absint( $broadcast['id'] );
		$broadcast_author_id = absint( $broadcast['created_by'] );
		$broadcast_content   = $data['content'];

		$template_winner = isset( $data['winner'] ) ? absint( $data['winner'] ) : 0;
		$chosen_content  = $this->get_current_email_template( $broadcast_content, $this->processed, $template_winner );

		/**
		 * Get template data on the basic of template id if exists.
		 */
		$content_template = $this->get_template_from_id( $chosen_content['template_id'] ?? 0, $chosen_content );

		BWFAN_Merge_Tag_Loader::set_data( array(
			'broadcast_id' => absint( $broadcast_id ),
			'contact_id'   => $contact_id,
		) );

		$email_data = BWFCRM_Core()->conversation->create_campaign_conversation( $contact, $broadcast_id, $chosen_content['template_id'] ?? 0, $broadcast_author_id, BWFCRM_Campaigns::$CAMPAIGN_EMAIL, false, $content_template );

		if ( true === $this->validate_email_data_error( $email_data ) ) {
			return;
		}

		if ( ! isset( $email_data['conversation_id'] ) ) {
			return;
		}

		$conversation_id = absint( $email_data['conversation_id'] );
		$hash_code       = isset( $email_data['hash_code'] ) ? $email_data['hash_code'] : '';
		$template_type   = isset( $chosen_content['type'] ) ? $chosen_content['type'] : '';
		$email_subject   = isset( $email_data['subject'] ) ? $email_data['subject'] : '';
		$template        = isset( $email_data['template'] ) ? $email_data['template'] : '';
		$pre_header      = isset( $chosen_content['preheader'] ) ? $chosen_content['preheader'] : '';
		$utm_details     = isset( $chosen_content['utm'] ) && is_array( $chosen_content['utm'] ) ? $this->get_utm_data_from_campaign_data( $chosen_content['utm'] ) : '';

		$email_subject = BWFCRM_Core()->conversation->prepare_email_subject( $email_subject, $contact_id );
		try {
			$email_body = BWFCRM_Core()->conversation->prepare_email_body( $conversation_id, $contact_id, $hash_code, $template_type, $template, $pre_header, $utm_details, $broadcast_id );
		} catch ( Error $e ) {
			/** Update broadcast status to halt if any error comes in email body */
			$data['halt_reason'] = __( 'Error in email body: ', 'wp-marketing-automations-pro' ) . $e->getMessage();
			BWFAN_Model_Broadcast::update_status_to_halt( $broadcast['id'], $data );
			self::action_schedule_save_last_sent( $broadcast['id'] );
			die();
		}
		if ( is_wp_error( $email_body ) ) {
			BWFCRM_Core()->conversation->fail_the_conversation( $conversation_id, $email_body->get_error_message() );

			return;
		}

		$to = $contact->get_email();
		if ( ! is_email( $to ) ) {
			BWFCRM_Core()->conversation->fail_the_conversation( $conversation_id, __( 'No email found for this contact: ' . $contact_id, 'wp-marketing-automations-pro' ) );

			return;
		}

		$headers = array(
			'MIME-Version: 1.0',
			'From: ' . $data['senders_name'] . ' <' . $data['senders_email'] . '>',
			'Content-type: text/html;charset=UTF-8',
		);

		if ( isset( $data['replyto'] ) && ! empty( $data['replyto'] ) ) {
			$headers[] = BWFAN_PRO_Common::build_reply_to_header( $data['replyto'], '', $data['senders_name'] );
		}

		/** Set unsubscribe link in header */
		$unsubscribe_link = BWFAN_PRO_Common::get_unsubscribe_link( [ 'uid' => $contact->get_uid(), 'broadcast_id' => $broadcast_id ] );
		if ( ! empty( $unsubscribe_link ) ) {
			$headers[] = "List-Unsubscribe: <$unsubscribe_link>";
			$headers[] = "List-Unsubscribe-Post: List-Unsubscribe=One-Click";
		}

		$this->set_log( 'contact#' . $contact_id . '_before_wp_mail' );

		do_action( 'bwfan_before_send_email', $data, $email_body );
		$headers = apply_filters( 'bwfan_email_headers', $headers );

		$result = $error = false;
		try {
			/** Process the email */
			$result = $this->process_email( $to, $email_subject, $email_body, $headers );
		} catch ( Error|Exception $e ) {
			$error = $e->getMessage();
		}

		$this->set_log( 'contact#' . $contact_id . '_after_wp_mail' );

		if ( true === $result ) {
			BWFCRM_Core()->conversation->update_conversation_status( $conversation_id, BWFAN_Email_Conversations::$STATUS_SEND );
			$this->failed_cids = [];
			$this->err_msg     = [];

			return;
		}

		$error = empty( $error ) ? BWFCRM_Common::$captured_email_failed_message : $error;
		$error = ! empty( $error ) ? $error : __( 'Email not sent (Error Unknown)', 'wp-marketing-automations-pro' );
		BWFCRM_Core()->conversation->fail_the_conversation( $conversation_id, $error );

		$should_pause = apply_filters( 'bwfan_broadcast_should_pause_on_failures', true, $broadcast_id );
		$should_pause = is_bool( $should_pause ) ? $should_pause : true;
		if ( $should_pause ) {
			$this->failed_cids[] = $contact_id;
			$this->err_msg[]     = $error;
		}

		BWFCRM_Common::$captured_email_failed_message = null;
	}

	public function get_current_email_template( $email_content, $processed, $winner_tid ) {
		if ( ! empty( $winner_tid ) ) {
			foreach ( $email_content as $email ) {
				if ( ! is_array( $email ) || ! isset( $email['template_id'] ) || absint( $email['template_id'] ) !== absint( $winner_tid ) ) {
					continue;
				}

				return $email;
			}
		}

		return $email_content[ $processed % count( $email_content ) ];
	}

	public function get_utm_data_from_campaign_data( $utm_data ) {
		$final_data = array();
		$utm_keys   = array(
			'source'  => 'utm_source',
			'medium'  => 'utm_medium',
			'name'    => 'utm_campaign',
			'content' => 'utm_content',
			'term'    => 'utm_term',
		);

		foreach ( $utm_data as $key => $datum ) {
			if ( ! isset( $utm_keys[ $key ] ) ) {
				continue;
			}

			$final_data[ $utm_keys[ $key ] ] = $datum;
		}

		return $final_data;
	}

	/**
	 * Add gap between whatsapp messages
	 */
	public function whatsapp_delay_time() {
		if ( is_null( $this->last_engagement_sent ) ) {
			return;
		}

		$gap             = 1;
		$global_settings = BWFAN_Common::get_global_settings();
		if ( isset( $global_settings['bwfan_whatsapp_gap_btw_message'] ) && ! empty( $global_settings['bwfan_whatsapp_gap_btw_message'] ) ) {
			$gap = floatval( $global_settings['bwfan_whatsapp_gap_btw_message'] );
		}
		$sleep_time = $gap * 1000 * 1000;

		/** Get Remaining sleep time, in Micro-Seconds */
		$sleep_time = $sleep_time - ( ( microtime( true ) - $this->last_engagement_sent ) * 1000000 );

		if ( $sleep_time > 0 && $sleep_time < 1000000 ) {
			usleep( ceil( $sleep_time ) );
		}

		if ( $sleep_time >= 1000000 ) {
			$gap = $sleep_time / 1000000;
			sleep( ceil( $gap ) );
		}
	}

	public function delay_time() {
		$sleep_time = 1000000 - ( microtime( true ) - $this->started_send_mail_at ) * 1000000;
		if ( $sleep_time > 0 ) {
			usleep( ceil( $sleep_time ) );
		}

		$this->records_processed_in_one_sec = 0;
		$this->started_send_mail_at         = microtime( true );
	}

	/**
	 * Check if email daily limit reached
	 *
	 * @param int $type 1 email 2 sms 3 whatsapp
	 *
	 * @return bool
	 */
	public function maybe_daily_limit_reached( $type = 1 ) {
		if ( empty( $this->default_email_settings ) ) {
			$this->default_email_settings = BWFAN_Common::get_global_settings();
		}

		/** If not email campaign, no limit */
		if ( self::$CAMPAIGN_EMAIL !== absint( $type ) ) {
			return false;
		}

		$this->daily_achieved_limit = ( 0 === absint( $this->daily_achieved_limit ) ) ? BWFAN_Model_Engagement_Tracking::get_last_24_hours_conversations_count() : absint( $this->daily_achieved_limit );
		$this->daily_message_limit  = isset( $this->default_email_settings['bwfan_email_daily_limit'] ) ? absint( $this->default_email_settings['bwfan_email_daily_limit'] ) : 10000;

		/** Setting default 10k email daily limit */
		$this->daily_message_limit = empty( $this->daily_message_limit ) ? 10000 : $this->daily_message_limit;

		return ( $this->daily_achieved_limit >= $this->daily_message_limit );
	}

	/**
	 * Set delay in broadcast execution
	 *
	 * @param $campaign
	 * @param string $time
	 * @param string $in
	 */
	public function set_delay( $campaign, $time = '10', $in = 'minutes' ) {
		$execution_time = date( 'Y-m-d H:i:s', strtotime( "+$time $in", strtotime( $campaign['execution_time'] ) ) );
		BWFAN_Model_Broadcast::update( array(
			'execution_time' => $execution_time,
			'last_modified'  => current_time( 'mysql', 1 ),
		), array(
			'id' => $campaign['id'],
		) );
	}

	public function get_daily_limit_status_array() {
		if ( empty( $this->default_email_settings ) ) {
			$this->default_email_settings = BWFAN_Common::get_global_settings();
		}

		return array(
			'reached'     => $this->maybe_daily_limit_reached(),
			'daily_limit' => isset( $this->default_email_settings['bwfan_email_daily_limit'] ) ? absint( $this->default_email_settings['bwfan_email_daily_limit'] ) : 10000,
		);
	}

	public function get_per_call_time() {
		if ( defined( 'BWFCRM_BROADCAST_AS_CALL_SECONDS' ) ) {
			return absint( BWFCRM_BROADCAST_AS_CALL_SECONDS );
		}

		return apply_filters( 'bwfan_as_per_call_time', 30 );
	}

	public function is_time_exceeded() {
		return ( time() - $this->start_time ) >= $this->AS_CALL_TIME;
	}

	public function maybe_validate_twilio_settings() {
		$broadcast = $this->current_broadcast;
		$data      = isset( $broadcast['data'] ) && ! empty( $broadcast['data'] ) ? $broadcast['data'] : array();

		if ( ! BWFCRM_Core()->conversation->is_twilio_connected() ) {
			$data['halt_reason'] = __( 'Twilio Connector is not connected, during the schedule time of this campaign', 'wp-marketing-automations-pro' );
			BWFAN_Model_Broadcast::update_status_to_halt( $broadcast['id'], $data );
			self::action_schedule_save_last_sent( $broadcast['id'] );

			return false;
		}

		$sms_settings = BWFCRM_Core()->conversation->get_twilio_settings();
		if ( ! is_array( $sms_settings ) || empty( $sms_settings ) || ! isset( $sms_settings['twilio_no'] ) || ! isset( $sms_settings['account_sid'] ) || ! isset( $sms_settings['auth_token'] ) ) {
			$data['halt_reason'] = __( 'Twilio Connector\'s required details are not found. Please re-connect to Twilio connector again', 'wp-marketing-automations-pro' );
			BWFAN_Model_Broadcast::update_status_to_halt( $broadcast['id'], $data );
			self::action_schedule_save_last_sent( $broadcast['id'] );

			return false;
		}

		return true;
	}

	public function maybe_validate_whatsapp_settings() {
		$broadcast = $this->current_broadcast;
		$data      = isset( $broadcast['data'] ) && ! empty( $broadcast['data'] ) ? $broadcast['data'] : array();

		if ( ! BWFAN_Common::is_whatsapp_services_enabled() ) {
			$data['halt_reason'] = __( 'No WhatsApp service connected', 'wp-marketing-automations-pro' );
			BWFAN_Model_Broadcast::update_status_to_halt( $broadcast['id'], $data );
			self::action_schedule_save_last_sent( $broadcast['id'] );

			return false;
		}

		return true;
	}

	public function maybe_broadcast_running() {
		$broadcast = $this->current_broadcast;

		$last_modified = ! empty( $broadcast ) && isset( $broadcast['last_modified'] ) ? $broadcast['last_modified'] : false;
		if ( false !== $last_modified ) {
			$last_modified = time() - strtotime( $last_modified );
			if ( $last_modified <= 5 ) {
				return true;
			}
		}

		return false;
	}

	public function get_current_broadcast_data() {
		if ( ! is_array( $this->current_broadcast ) || ! isset( $this->current_broadcast['data'] ) ) {
			return array();
		}

		return $this->current_broadcast['data'];
	}

	public function validate_email_data_error( $email_data ) {
		if ( ! is_wp_error( $email_data ) ) {
			return false;
		}

		$e_data = $email_data->get_error_data();
		if ( is_array( $e_data ) && isset( $e_data['conversation_id'] ) ) {
			BWFCRM_Core()->conversation->fail_the_conversation( absint( $e_data['conversation_id'] ), $email_data->get_error_message() );
		}

		return true;
	}

	public function process_email( $to, $email_subject, $email_body, $headers ) {
		BWFCRM_Common::$captured_email_failed_message = null;

		return wp_mail( $to, $email_subject, $email_body, $headers );
	}

	public function set_log( $log ) {
		if ( empty( $log ) ) {
			return;
		}
		$this->logs[] = array(
			't' => microtime( true ),
			'm' => $log,
		);
	}

	protected function log() {
		if ( ! is_array( $this->logs ) || 0 === count( $this->logs ) ) {
			return;
		}

		if ( false === apply_filters( 'bwfan_allow_broadcast_logging', BWFAN_PRO_Common::is_log_enabled( 'bwfan_broadcast_logging' ) ) ) {
			return;
		}
		add_filter( 'bwfan_before_making_logs', '__return_true' );
		BWFAN_Core()->logger->log( print_r( $this->logs, true ), 'fka-broadcast' );
		$this->logs = [];
	}

	/**
	 * Enable query cache for contact fields and meta
	 *
	 * @param $cache
	 *
	 * @return void
	 */
	protected function set_contact_cache( $cache = false ) {
		$db_ins = WooFunnels_DB_Operations::get_instance();

		$db_ins->cache_field_query = boolval( $cache );
		$db_ins->cache_meta_query  = boolval( $cache );

		/** Emptied on the way in as well as out, see reset_contact_cache() */
		$this->reset_contact_cache();

		/** Plain ternary rather than wc_bool_to_string() - broadcasts run on sites without WooCommerce */
		BWFCRM_Broadcast_Helper::set_log( 'broadcast_id set_contact_cache prop set: ' . ( $cache ? 'yes' : 'no' ) );
	}

	/**
	 * Drop the contact meta rows cached for the batch just finished
	 *
	 * WooFunnels_DB_Operations keeps them in $cache_query['meta'], keyed on contact id, on a
	 * singleton that lives for the whole request - and nothing ever clears it. A broadcast run
	 * walks tens of thousands of contacts in one request, so the cache that exists to save a
	 * query per contact within a batch instead accumulates every contact the run has ever
	 * touched, and the run dies on memory long before it dies on time.
	 *
	 * Called between batches, which is as long as any entry is actually worth keeping.
	 *
	 * @return void
	 */
	public function reset_contact_cache() {
		$db_ins = WooFunnels_DB_Operations::get_instance();

		if ( property_exists( $db_ins, 'cache_query' ) ) {
			$db_ins->cache_query = [];
		}
	}

	/**
	 * Schedule action for save last sent
	 *
	 * @param int $broadcast_id
	 * @param bool $delete_key
	 *
	 * @return void
	 */
	public static function action_schedule_save_last_sent( $broadcast_id, $delete_key = true ) {
		if ( empty( $broadcast_id ) ) {
			return;
		}

		if ( ! bwf_has_action_scheduled( 'bwfan_broadcast_last_sent', array( $broadcast_id, $delete_key ), 'bwfcrm' ) ) {
			bwf_schedule_recurring_action( time(), 60, 'bwfan_broadcast_last_sent', array( $broadcast_id, $delete_key ), 'bwfcrm' );
		}
	}

	/**
	 * The methods below moved to BWFCRM_Broadcast_Helper, or were replaced, during the v2 split.
	 *
	 * They were public on this class before it, so they stay callable here and forward to whatever
	 * now does the work. Each keeps its original signature: the replacements read their inputs from
	 * arguments rather than off $this, and two of them changed arity, so an un-updated caller would
	 * otherwise have fataled.
	 */

	/**
	 * Deprecated. Use process_running_v2_broadcasts() instead.
	 *
	 * @return void
	 */
	public function process_running_broadcasts() {
		$this->process_running_v2_broadcasts();
	}

	/**
	 * Deprecated. Use BWFCRM_Broadcast_Helper::maybe_process_smart_send_v2() instead, which takes
	 * the broadcast row in place of the id and blob passed separately here.
	 *
	 * @param int $broadcast_id
	 * @param array $broadcast_data
	 * @param int $processed
	 * @param int $count
	 * @param int $type
	 *
	 * @return int|false
	 */
	public function maybe_process_smart_send_data( $broadcast_id, $broadcast_data, $processed, $count, $type = 1 ) {
		return BWFCRM_Broadcast_Helper::maybe_process_smart_send_v2( array(
			'id'   => absint( $broadcast_id ),
			'data' => $broadcast_data,
		), $processed, $count, $type );
	}

	/**
	 * Deprecated. Use BWFCRM_Broadcast_Helper::fetch_contacts_for_broadcast() instead.
	 *
	 * @return array|WP_Error
	 */
	public function fetch_contacts_for_broadcast() {
		return BWFCRM_Broadcast_Helper::fetch_contacts_for_broadcast( $this->current_broadcast, $this );
	}

	/**
	 * Deprecated. Use BWFCRM_Broadcast_Helper::error_while_fetching_contacts() instead.
	 *
	 * @return bool
	 */
	public function error_while_fetching_contacts() {
		return BWFCRM_Broadcast_Helper::error_while_fetching_contacts( $this->contact_ids, $this->current_broadcast['id'] ?? 0, $this->get_current_broadcast_data() );
	}
}
