<?php

namespace BWFAN\Importers;

use BWFCRM_Contact;
use Exception;
use WC_Subscription;
use WP_Error;

/**
 * Class WCS_Importer
 *
 * This class represents a WordPress importer for the CRM system.
 */
#[\AllowDynamicProperties]
class WCS_Importer extends Importer {
	protected $import_type = 'wcs';

	public function __construct( $params = array() ) {
		$this->slug        = 'wcs';
		$this->name        = __( 'WooCommerce Subscription', 'wp-marketing-automations' );
		$this->description = __( 'Import contacts from WC Subscription', 'wp-marketing-automations' );
		$this->logo_url    = esc_url( plugin_dir_url( BWFAN_PRO_PLUGIN_FILE ) . '/admin/assets/img/importer/wcs.png' );
		$this->has_fields  = false;
		$this->group       = 0;
		$this->priority    = 8;
		parent::__construct( $params );

	}

	/**
	 * Prepares the import data for creating a new import.
	 *
	 * @param array $import_data The import data.
	 * @param array $fields fields.
	 *
	 * @return array The modified import data.
	 */
	public function prepare_create_import_data( $import_data = array(), $fields = array() ) {
		$import_data['count'] = $this->get_contacts_count();

		return $import_data;
	}

	/**
	 * Subscription statuses indexed by the import
	 *
	 * @return string[]
	 */
	public static function get_import_statuses() {
		return array( 'active', 'on-hold', 'pending-cancel', 'cancelled', 'expired', 'pending', 'switched' );
	}

	/**
	 * Prepare the data for importing orders.
	 *
	 * This method fetches orders to import based on specified criteria and stores them in the raw_data property.
	 */
	public function populate_contact_data() {

		if ( ! function_exists( 'wcs_get_subscriptions' ) ) {
			return array();
		}

		return wcs_get_subscriptions( array(
			'subscriptions_per_page' => self::LIMIT,
			'offset'                 => $this->get_offset(),
			'subscription_status'    => self::get_import_statuses(),
			'orderby'                => 'ID',
			'order'                  => 'ASC',
		) );
	}

	/**
	 * Retrieves the count of subscriptions to import.
	 *
	 * Runs a single SQL COUNT(*) against the orders table (HPOS) or posts table (legacy)
	 * so no subscription IDs or objects are loaded into memory.
	 *
	 * @return int The count of subscriptions.
	 */
	public function get_contacts_count() {

		if ( ! function_exists( 'wcs_get_subscriptions' ) || ! function_exists( 'wcs_sanitize_subscription_status_key' ) ) {
			return 0;
		}

		if ( $this->count > 0 ) {
			return $this->count;
		}

		$statuses = array_map( 'wcs_sanitize_subscription_status_key', self::get_import_statuses() );

		$this->count = $this->count_subscriptions_in_db( $statuses );

		return $this->count;
	}

	/**
	 * COUNT subscriptions by status using a direct query (HPOS vs legacy).
	 *
	 * @param string[] $statuses Sanitized wc-* subscription statuses.
	 *
	 * @return int
	 */
	protected function count_subscriptions_in_db( array $statuses ) {
		global $wpdb;

		if ( empty( $statuses ) ) {
			return 0;
		}

		$placeholders = implode( ', ', array_fill( 0, count( $statuses ), '%s' ) );

		if ( function_exists( 'wcs_is_custom_order_tables_usage_enabled' ) && wcs_is_custom_order_tables_usage_enabled() ) {
			$orders_table = $wpdb->prefix . 'wc_orders';
			$sql          = $wpdb->prepare(
				"SELECT COUNT(*) FROM {$orders_table} WHERE type = 'shop_subscription' AND status IN ({$placeholders})",
				...$statuses
			);
		} else {
			$sql = $wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'shop_subscription' AND post_status IN ({$placeholders})",
				...$statuses
			);
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Built above with $wpdb->prepare().
		return (int) $wpdb->get_var( $sql );
	}

	/**
	 * Process individual subscription item
	 *
	 * @param int|WC_Subscription $subscription_id
	 *
	 * @return array|WP_Error
	 */
	public function process_item( $subscription_id = null ) {

		$subscription = $subscription_id instanceof WC_Subscription ? $subscription_id : wcs_get_subscription( $subscription_id );

		if ( ! $subscription instanceof WC_Subscription ) {
			return new WP_Error( 'invalid_subscription', __( 'Invalid subscription ID.', 'wp-marketing-automations' ), array( 'subscription_id' => $subscription_id ) );
		}

		try {
			// Get or create contact
			$user_id = $subscription->get_user_id();
			$email   = $subscription->get_billing_email();

			if ( empty( $email ) ) {
				throw new Exception( __( 'Subscription has no billing email.', 'wp-marketing-automations' ) );
			}

			/** Create/update contact using existing function */
			$cid = $this->get_or_create_contact( $subscription );

			if ( empty( $cid ) ) {
				throw new Exception( __( 'Failed to create or retrieve contact.', 'wp-marketing-automations' ) );
			}

			$contact = new \WooFunnels_Contact( '', '', '', $cid );


		} catch ( Exception $e ) {
			$error_msg = $e->getMessage();
			BWFAN_Core()->logger->log( 'Subscription ID #' . $subscription_id . ' processing failed: ' . $error_msg, 'import_wcs_contacts' );

			$error_data = array(
				'contact_email' => $email ?? '',
				'id'            => $subscription->get_id(),
				'user_id'       => $user_id ?? 0,
			);

			return new WP_Error( 'invalid_data', $error_msg, $error_data );
		}

		/** Add tag and list */
		$to_be_assigned_tags  = $this->get_new_tags();
		$to_be_assigned_lists = $this->get_new_lists();
		$contact              = $this->set_contact_tags( $contact, $to_be_assigned_tags );
		$contact              = $this->set_contact_lists( $contact, $to_be_assigned_lists );

		$is_tag_list_assigned = false;
		if ( ! empty( $to_be_assigned_tags ) || ! empty( $to_be_assigned_lists ) ) {
			$is_tag_list_assigned = true;
			$contact->save();
		}

		$update_existing = $this->get_import_meta( 'update_existing' );
		if ( ! $contact instanceof BWFCRM_Contact || ( empty( $update_existing ) && empty( \BWFCRM_WCS_Handler::$is_contact_new ) && false === $is_tag_list_assigned ) ) {
			return array(
				'id'      => $contact->get_id(),
				'data'    => $subscription->get_id(),
				'skipped' => true,
			);
		}

		/** update status if setting enabled for update contact  */
		if(!empty($update_existing)){
			$disable_events = $this->get_import_meta( 'disable_events' );
			$import_status  = $this->get_import_meta( 'imported_contact_status' );
			switch ( intval( $import_status ) ) {
				case 0:
					$contact->unverify();
					break;
				case 1:
					$contact->resubscribe( $disable_events );
					break;
				case 2:
					$contact->mark_as_bounced();
					break;
				case 3:
					$contact->contact->is_subscribed = false;
					$contact->unsubscribe( $disable_events );
					break;
				case 4:
					$contact->mark_as_soft_bounced();
					break;
				case 5:
					$contact->mark_as_complaint();
					break;
			}
		}

		return array(
			'id'      => $contact->get_id(),
			'data'    => $subscription->get_id(),
			'updated' => true,
		);
	}

	/**
	 * Get or create contact for subscription
	 *
	 * @param WC_Subscription $subscription
	 *
	 * @return int|null Contact ID
	 */
	private function get_or_create_contact( $subscription ) {
		$cid = \BWFCRM_WCS_Handler::get_import_contact_id( $subscription, ! empty( $this->get_import_meta( 'update_existing' ) ) );

		/** Save subscriber in table */
		\BWFCRM_WCS_Handler::create_update_wcs_subscriber( $subscription, $subscription->get_status(), '', $cid, true );

		return $cid;
	}


	/**
	 * Get the log headers for this importer.
	 *
	 * @return array
	 */
	protected function get_log_headers() {
		return [ 'ID', 'Subscription ID', 'Status' ];
	}

	/**
	 * Prepare log data for a single item.
	 *
	 * @param mixed $data
	 * @param mixed $result
	 *
	 * @return array
	 */
	protected function prepare_log_data( $data, $result ) {
		/** A failed item arrives as the subscription id taken from the error, anything else as the subscription itself */
		if ( is_array( $result ) && ! empty( $result['data'] ) ) {
			$subscription_id = $result['data'];
		} else {
			$subscription_id = $data instanceof WC_Subscription ? $data->get_id() : absint( $data );
		}

		return [
			'cid'             => is_wp_error( $result ) ? 0 : $result['id'] ?? 0,
			'Subscription id' => $subscription_id,
			'Status'          => is_wp_error( $result ) ? __( 'Failed', 'wp-marketing-automations' ) : ( isset( $result['skipped'] ) && $result['skipped'] ? __( 'Skipped', 'wp-marketing-automations' ) : __( 'Success', 'wp-marketing-automations' ) ),
		];
	}

	/**
	 * Get the second step fields for wc importer
	 *
	 * @return array
	 *
	 */
	public function get_second_step_fields() {
		$count       = $this->get_contacts_count();
		$this->count = $count;
		$message     = __( 'There are no subscription to import', 'wp-marketing-automations-pro' );
		$type        = 'error';
		if ( $count > 0 ) {
			/* translators: 1: Subscriptions count */
			$message = sprintf( __( 'There are %d subscriptions to be imported', 'wp-marketing-automations-pro' ), $count ); //translators: number of subscriptions to be imported
			$type    = 'warning';
		}

		return [
			[
				'id'          => 'wc_notice',
				'type'        => 'notice',
				'noticeLabel' => __( 'Subscriptions', 'wp-marketing-automations-pro' ),
				'nType'       => $type,
				'isHtml'      => true,
				'text'        => '<span class="bwf-heading8-new">' . __( 'Information', 'wp-marketing-automations-pro' ) . ':</span> ' . $message,
				'desc'        => '',
			]
		];
	}

	/**
	 * Validate the count of contacts to be imported.
	 *
	 * @return bool
	 */
	public function validate_second_step() {
		return intval( $this->count ) > 0;
	}

	/**
	 * Needed only status and disable event field
	 *
	 * @return array
	 */
	public function contact_profile_fields() {
		return [
			'marketing_status',
			'disable_events',
			'update_existing'
		];
	}

	/**
	 * Full re-index: clear auxiliary subscriber rows before this import run.
	 *
	 * @return void
	 */
	public function before_start_import() {
		$this->reset_wcs_subscribers();
	}

	/**
	 * Empty the WCS subscriber index table so this import rebuilds it from scratch.
	 *
	 * TRUNCATE is intentional: each import is a full re-index of `bwfan_wcs_subscriber`.
	 * If a run stops midway, the next import truncates again and processes from the beginning;
	 * data remains authoritative in WooCommerce Subscriptions.
	 *
	 * @return void
	 */
	public function reset_wcs_subscribers() {
		global $wpdb;

		$table = $wpdb->prefix . 'bwfan_wcs_subscriber';
		$data  = $wpdb->get_row( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ), ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( ! empty( $data ) ) {
			// Full re-index: fast reset of auto-increment; not transactional (acceptable for this cache table).
			$wpdb->query( "TRUNCATE TABLE $table" ); //phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

			return;
		}

		/** Load pro table classes */
		\BWFAN_Pro_DB::load_pro_table_classes();

		/** Create WCS subscriber table */
		$table_instance = new \BWFAN_DB_Table_WCS_Subscriber();
		$table_instance->create_table();
		if ( ! empty( $table_instance->db_errors ) ) {
			/** Log if any mysql errors */
			\BWFAN_Common::log_test_data( array_merge( [ __FUNCTION__ ], [$table_instance->db_errors] ), 'db-creation-errors' );
		}
	}

}

if ( function_exists( 'bwfan_is_woocommerce_subscriptions_active' ) && bwfan_is_woocommerce_subscriptions_active() ) {
	BWFAN_Core()->importer->register( 'wcs', 'BWFAN\Importers\WCS_Importer' );
}