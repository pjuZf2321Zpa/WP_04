<?php

if ( ! class_exists( 'BWFAN_Filter_Customer_Role' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Customer_Role extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->name          = __( 'User Role', 'wp-marketing-automations-pro' );
			$this->group_name    = __( 'User', 'wp-marketing-automations-pro' );
			$this->filter        = $value;
			$this->priority      = 1;
			$this->is_preference = false;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}usermeta";
			$this->columns    = [];
			$this->alias      = 'um';
		}

		/**
		 * @return BWFAN_Filter_Customer_Role|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_options( $term = '' ) {
			return $this->get_possible_rule_values();
		}

		public function get_type() {
			return 'Search';
		}

		public function get_possible_operators() {
			return array(
				'is'     => __( 'is', 'wp-marketing-automations-pro' ),
				'is_not' => __( 'is not', 'wp-marketing-automations-pro' ),
			);
		}

		public function get_value_as_key_label( $data ) {
			if ( empty( $data ) ) {
				return [];
			}
			$roles  = $this->get_possible_rule_values();
			$values = [];
			foreach ( $data as $value ) {
				$values[] = [
					'key'   => $value,
					'label' => isset( $roles[ $value ] ) ? $roles[ $value ] : '-',
				];
			}

			return $values;
		}

		public function get_possible_rule_values() {
			if ( ! function_exists( 'get_editable_roles' ) ) {
				require_once ABSPATH . 'wp-admin/includes/user.php';
			}
			$result         = array();
			$editable_roles = get_editable_roles();

			if ( $editable_roles ) {
				foreach ( $editable_roles as $role => $details ) {
					$name = translate_user_role( $details['name'] );

					$result[ $role ] = $name;
				}
			}

			return $result;
		}

		public function get_where_query() {
			$filter_value = $this->filter['value'];
			if ( empty( $filter_value ) ) {
				return '';
			}

			$filter_rule = $this->filter['rule'];
			$query       = " EXISTS";
			$sub_rule    = " AND ";
			switch ( true ) {
				case 'is' === $filter_rule || 'in' === $filter_rule :
					$sub_rule = " OR ";
					break;
				case ( 'is_not' === $filter_rule || 'notin' === $filter_rule ):
					$query = " NOT EXISTS";
					break;
			}

			$filter_value = ! is_array( $filter_value ) ? explode( ',', $filter_value ) : $filter_value;

			$filter_value = array_map( 'trim', $filter_value );
			global $wpdb;
			$inner_query = [];
			foreach ( $filter_value as $key => $value ) {
				$like_value    = '%"' . $wpdb->esc_like( $value ) . '"%';
				$inner_query[] = $wpdb->prepare( "$query ( SELECT 1 FROM `{$this->table}` AS {$this->alias}_{$key} WHERE {$this->alias}_{$key}.`user_id` = {$this->base_alias}.`wpid` AND {$this->alias}_{$key}.`meta_key` = %s AND {$this->alias}_{$key}.`meta_value` LIKE %s )", $wpdb->prefix . 'capabilities', $like_value );
			}

			$query = implode( " {$sub_rule} ", $inner_query );

			return ' ( ' . $query . ' ) ';
		}

	}

	BWFCRM_Core()->filters->register( 'bwf_contact_user', 'BWFAN_Filter_Customer_Role', 'role' );
}
