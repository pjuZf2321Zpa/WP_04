<?php

if ( ! class_exists( 'BWFAN_Filter_Customer_Is_WP_User' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Customer_Is_WP_User extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->slug           = 'is_user';
			$this->name           = __( 'Is User', 'wp-marketing-automations-pro' );
			$this->group_name     = __( 'User', 'wp-marketing-automations-pro' );
			$this->group_priority = 30;
			$this->filter         = $value;
			$this->priority       = 2;
			$this->is_preference = false;

			global $wpdb;
			$this->table   = "{$wpdb->prefix}bwf_contact";
			$this->columns = [];
			$this->alias   = 'c';
		}

		/**
		 * @return BWFAN_Filter_Customer_Is_WP_User|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_options( $term = '' ) {
			return [
				'yes' => __( 'Yes', 'wp-marketing-automations-pro' ),
				'no'  => __( 'No', 'wp-marketing-automations-pro' ),
			];
		}

		public function get_type() {
			return 'Select';
		}

		public function get_possible_operators() {
			return null;
		}


		public function get_where_query() {
			$this->filter['key'] = 'user';

			return $this->prepare_query_for_bool();
		}

	}

	BWFCRM_Core()->filters->register( 'bwf_contact_user', 'BWFAN_Filter_Customer_Is_WP_User', 'is_user' );
}
