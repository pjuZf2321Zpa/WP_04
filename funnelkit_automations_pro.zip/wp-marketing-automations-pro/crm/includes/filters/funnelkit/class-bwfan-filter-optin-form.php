<?php

if ( ! class_exists( 'BWFAN_Filter_Optin_Form' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Optin_Form extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->name           = __( 'Optin Form', 'wp-marketing-automations-pro' );
			$this->group_name     = __( 'Funnelkit', 'wp-marketing-automations-pro' );
			$this->group_priority = 90.1;
			$this->filter         = $value;
			$this->priority       = 1;
			$this->is_preference  = false;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}bwf_optin_entries";
			$this->columns    = [];
			$this->alias      = 'bwf_opt';

		}

		/**
		 * @return BWFAN_Filter_Optin_Form|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_possible_operators() {
			return [
				'any'  => __( 'matches any of', 'wp-marketing-automations-pro' ),
				'all'  => __( 'matches all of ', 'wp-marketing-automations-pro' ),
				'none' => __( 'matches none of ', 'wp-marketing-automations-pro' ),
			];
		}

		public function get_value_as_key_label( $data ) {
			if ( empty( $data ) ) {
				return [];
			}
			$values = [];
			foreach ( $data as $id ) {
				if ( false !== strpos( $id, ',' ) ) {
					$ids    = explode( ',', $id );
					$values = array_merge( $values, $this->get_value_as_key_label( $ids ) );
					continue;
				}

				$post     = get_post( (int) $id );
				$title    = $post ? $post->post_title . " (#$id)" : '-';
				$values[] = [
					'key'   => (string) $id,
					'label' => $title
				];
			}

			return $values;
		}

		public function get_options( $search = '' ) {
			$options = [];

			$args        = [
				'post_type'      => 'wffn_optin',
				'post_status'    => 'publish',
				'posts_per_page' => 10,
				's'              => $search,

			];
			$optin_forms = new WP_Query( $args );
			if ( ! empty( $optin_forms->posts ) ) {
				foreach ( $optin_forms->posts as $form ) {
					$options[ $form->ID ] = $form->post_title . " (" . $form->ID . ")";
				}
			}

			return $options;
		}


		public function get_type() {
			return 'Search';
		}

		public function get_where_query() {
			$filter_value = $this->filter['value'];
			$filter_rule  = $this->filter['rule'];
			if ( empty( $filter_value ) || empty( $filter_rule ) ) {
				return '';
			}

			if ( ! is_array( $filter_value ) ) {
				$filter_value = array( $filter_value );
			}

			return $this->build_exists_query_single_value_column( $filter_value, $filter_rule, 'step_id' );
		}

	}

	if ( bwfan_is_woocommerce_active() && bwfan_is_funnel_active() ) {
		BWFCRM_Core()->filters->register( 'funnelkit', 'BWFAN_Filter_Optin_Form', 'funnelkit_optin' );
	}
}
