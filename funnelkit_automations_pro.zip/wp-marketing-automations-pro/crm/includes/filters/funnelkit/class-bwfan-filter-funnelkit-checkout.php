<?php

if ( ! class_exists( 'BWFAN_Filter_Funnelkit_Checkout_Page' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Funnelkit_Checkout_Page extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->name           = __( 'Checkout Page', 'wp-marketing-automations-pro' );
			$this->group_name     = __( 'Funnelkit', 'wp-marketing-automations-pro' );
			$this->group_priority = 90.1;
			$this->filter         = $value;
			$this->priority       = 1;
			$this->is_preference  = false;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}wfacp_stats";
			$this->columns    = [];
			$this->alias      = 'wp_st';

		}

		/**
		 * @return BWFAN_Filter_Funnelkit_Checkout_Page|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_possible_operators() {
			return [
				'any'  => __( 'matches any of', 'wp-marketing-automations-pro' ),
				'all'  => __( 'matches all of ', 'wp-marketing-automations-pro' ),
				'none' => __( 'matches none of ', 'wp-marketing-automations-pro' ),
			];
		}

		public function get_value_as_key_label( $data ) {
			if ( empty( $data ) ) {
				return [];
			}

			$saved_pages = WFACP_Common::get_saved_pages();
			if ( empty( $saved_pages ) ) {
				return [];
			}

			$pages_lookup = array_column( $saved_pages, 'post_title', 'ID' );
			$result       = [];

			foreach ( $data as $id ) {
				$ids = is_string( $id ) ? array_map( 'trim', explode( ',', $id ) ) : [ $id ];

				foreach ( $ids as $single_id ) {
					$title    = isset( $pages_lookup[ $single_id ] ) ? $pages_lookup[ $single_id ] . " (#$single_id)" : '-';
					$result[] = [
						'key'   => $single_id,
						'label' => $title
					];
				}
			}

			return $result;
		}

		public function get_options( $search = '' ) {
			$data = WFACP_Common::get_saved_pages();

			if ( ! is_array( $data ) || 0 === count( $data ) ) {
				return array();
			}

			$result = array();

			foreach ( $data as $v ) {
				$result[ $v['ID'] ] = $v['post_title'] . " (#{$v['ID']})";
			}

			return BWFAN_PRO_Common::search_srting_from_data( $result, $search );

		}

		public function get_type() {
			return 'Search';
		}

		public function get_where_query() {
			$filter_value = $this->filter['value'];
			$filter_rule  = $this->filter['rule'];

			if ( empty( $filter_value ) || empty( $filter_rule ) ) {
				return '';
			}

			if ( ! is_array( $filter_value ) ) {
				$filter_value = array( $filter_value );
			}

			return $this->build_exists_query_single_value_column( $filter_value, $filter_rule, 'wfacp_id' );
		}

	}

	if ( bwfan_is_woocommerce_active() && bwfan_is_funnel_active() ) {
		BWFCRM_Core()->filters->register( 'funnelkit', 'BWFAN_Filter_Funnelkit_Checkout_Page', 'funnelkit_checkout' );
	}
}
