<?php

if ( ! class_exists( 'BWFAN_Filter_Affwp_Paid' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Affwp_Paid extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->name           = __( 'Paid Earnings', 'wp-marketing-automations-pro' );
			$this->group_name     = __( 'AffiliateWP', 'wp-marketing-automations-pro' );
			$this->filter         = $value;
			$this->group_priority = 100;
			$this->priority       = 2;
			$this->is_preference  = false;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}affiliate_wp_affiliates";
			$this->columns    = [];
			$this->alias      = 'awp';
		}

		/**
		 * @return BWFAN_Filter_Affwp_Paid|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_type() {
			return 'Number';
		}

		public function get_possible_operators() {
			return [
				'less_than'       => __( 'less than', 'wp-marketing-automations-pro' ),
				'more_than'       => __( 'more than', 'wp-marketing-automations-pro' ),
				'more_than_equal' => __( 'more than equal', 'wp-marketing-automations-pro' ),
				'less_than_equal' => __( 'less than equal', 'wp-marketing-automations-pro' ),
			];
		}

		public function get_join_query( $query = '' ) {

			if ( $this->is_join_exist( $query ) ) {
				return '';
			}

			return " LEFT JOIN {$this->table} AS $this->alias ON $this->base_alias.wpid = $this->alias.user_id";
		}

		public function get_where_query() {
			if ( ! isset( $this->filter['value'] ) || ! isset( $this->filter['rule'] ) ) {
				return '';
			}
			$filter_rule = $this->filter['rule'];
			switch ( $filter_rule ) {
				case 'more_than':
					$filter_rule = '>';
					break;
				case 'more_than_equal':
					$filter_rule = '>=';
					break;
				case 'less_than':
					$filter_rule = '<';
					break;
				case 'less_than_equal':
				case 'less_then_equal':
					$filter_rule = '<=';
					break;
				default :
					return '';
			}

			return "$this->alias.earnings {$filter_rule} {$this->filter['value']}";
		}

	}

	if ( bwfan_is_affiliatewp_active() ) {
		BWFCRM_Core()->filters->register( 'bwf_affiliatewp', 'BWFAN_Filter_Affwp_Paid', 'affwp_paid_earning' );
	}
}
