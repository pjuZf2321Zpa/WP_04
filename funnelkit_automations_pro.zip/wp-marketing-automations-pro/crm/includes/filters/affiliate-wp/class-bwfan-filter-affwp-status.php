<?php
if ( ! class_exists( 'BWFAN_Filter_Affwp_Status' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Affwp_Status extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->name          = __( 'Status', 'wp-marketing-automations-pro' );
			$this->group_name    = __( 'AffiliateWP', 'wp-marketing-automations-pro' );
			$this->filter        = $value;
			$this->priority      = 1;
			$this->is_preference = false;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}affiliate_wp_affiliates";
			$this->columns    = [];
			$this->alias      = 'awp';
		}

		/**
		 * @return BWFAN_Filter_Affwp_Status|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_options( $search = '' ) {
			$prepared_data = [
				'active'   => __( 'Active', 'wp-marketing-automations-pro' ),
				'inactive' => __( 'Inactive', 'wp-marketing-automations-pro' ),
				'pending'  => __( 'Pending ', 'wp-marketing-automations-pro' ),
			];

			return BWFAN_PRO_Common::search_srting_from_data( $prepared_data, $search );

		}

		public function get_value_as_key_label( $data ) {
			if ( empty( $data ) ) {
				return [];
			}

			$value = [];
			foreach ( $data as $key => $label ) {
				$value[] = [
					'key'   => $key,
					'label' => $label ?? '-',
				];
			}

			return $value;
		}

		public function get_type() {
			return 'Search';
		}

		public function get_possible_operators() {
			return [
				'any'  => __( 'matches any of', 'wp-marketing-automations-pro' ),
				'all'  => __( 'matches all of ', 'wp-marketing-automations-pro' ),
				'none' => __( 'matches none of ', 'wp-marketing-automations-pro' ),
			];
		}

		public function get_join_query( $query = '' ) {

			if ( $this->is_join_exist( $query ) ) {
				return '';
			}

			return " LEFT JOIN {$this->table} AS $this->alias ON $this->base_alias.wpid = $this->alias.user_id";
		}

		public function get_where_query() {
			$filter_value = $this->filter['value'];
			$filter_rule  = $this->filter['rule'];
			$key          = 'status';

			if ( empty( $filter_value ) || empty( $filter_rule ) ) {
				return '';
			}

			if ( ! is_array( $filter_value ) ) {
				$filter_value = array( $filter_value );
			}

			$rule     = in_array( $filter_rule, array( 'any', 'all' ) ) ? 'LIKE' : 'NOT LIKE';
			$sub_rule = ( 'LIKE' === $rule ) && ( 'all' !== $filter_rule ) ? 'OR' : 'AND';
			global $wpdb;
			$query    = [];
			foreach ( $filter_value as $val_item ) {
				$val_item = ! is_array( $val_item ) ? explode( ',', $val_item ) : $val_item;
				$val_item = array_map( 'trim', $val_item );

				$val_item = array_map( function ( $val ) use ( $rule, $key, $sub_rule, $wpdb ) {
					return $wpdb->prepare( "$this->alias.$key $rule %s", '%' . $wpdb->esc_like( $val ) . '%' );
				}, $val_item );

				$val_item = array_filter( $val_item );
				$val_item = implode( " {$sub_rule} ", $val_item );

				$if_column_exists = ( 'NOT LIKE' === $rule ) ? "{$this->alias}.{$key} IS NULL OR" : '';
				$query[]          = ! empty( $if_column_exists ) ? "($if_column_exists ($val_item))" : "($val_item)";

			}

			return ! empty( $query ) ? '(' . implode( " $sub_rule ", $query ) . ')' : '';
		}
	}

	if ( bwfan_is_affiliatewp_active() ) {
		BWFCRM_Core()->filters->register( 'bwf_affiliatewp', 'BWFAN_Filter_Affwp_Status', 'affwp_status' );
	}
}
