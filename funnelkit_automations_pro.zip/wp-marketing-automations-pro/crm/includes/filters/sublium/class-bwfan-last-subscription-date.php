<?php

namespace Filters\Sublium;

use BWFAN_Filter_Base;
	#[\AllowDynamicProperties]
	class Last_Subscription_Date extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->is_preference = true;
			$this->name          = __( 'Last Subscription Date', 'wp-marketing-automations-pro' );
			$this->group_name = __( 'Sublium Subscriptions', 'wp-marketing-automations-pro' );
			$this->filter     = $value;
			$this->priority   = 5;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}sublium_wcs_subscribers";
			$this->columns    = [];
			$this->alias      = 'ss';
		}

		/**
		 * @return Last_Subscription_Date|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_type() {
			return 'Date';
		}

		public function get_possible_operators() {
			return array(
				'before'  => __( 'Before', 'wp-marketing-automations-pro' ),
				'after'   => __( 'After', 'wp-marketing-automations-pro' ),
				'is'      => __( 'On', 'wp-marketing-automations-pro' ),
				'between' => __( 'Between', 'wp-marketing-automations-pro' ),
			);
		}

		public function get_join_query( $query = '' ) {

			if ( $this->is_join_exist( $query ) ) {
				return '';
			}

			return " LEFT JOIN {$this->table} AS $this->alias ON $this->base_alias.wpid = $this->alias.user_id";
		}

		public function get_where_query() {
			$this->filter['key'] = 'last_order_date';

			return $this->get_date_filter_sql();
		}

	}

	if ( function_exists( 'bwfan_is_sublium_active' ) && bwfan_is_sublium_active() ) {
		BWFCRM_Core()->filters->register( 'sublium', 'Filters\Sublium\Last_Subscription_Date', 'sublium_l_subscription_date' );
	}

