<?php


namespace Filters\Sublium;

use BWFAN_Filter_Base;

#[\AllowDynamicProperties]
class Has_Active_Subscription extends BWFAN_Filter_Base {
	public static $ins = null;

	public function __construct( $value = [] ) {
		$this->is_preference  = true;
		$this->name           = __( 'Has Active Subscription', 'wp-marketing-automations-pro' );
		$this->group_name     = __( 'Sublium Subscriptions', 'wp-marketing-automations-pro' );
		$this->group_priority = 65;
		$this->filter         = $value;
		$this->priority       = 4;

		global $wpdb;
		$this->base_table = "{$wpdb->prefix}bwf_contact";
		$this->base_alias = "c";
		$this->table      = "{$wpdb->prefix}sublium_wcs_subscribers";
		$this->columns    = [];
		$this->alias      = 'ss';
	}

	/**
	 * @return Has_Active_Subscription|mixed|null
	 */
	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	/** v2 Methods: START */
	public function get_options( $term = '' ) {
		return [
			'yes' => __( 'Yes', 'wp-marketing-automations-pro' ),
			'no'  => __( 'No', 'wp-marketing-automations-pro' ),
		];
	}

	public function get_type() {
		return 'Select';
	}

	public function get_possible_operators() {
		return null;
	}

	public function get_join_query( $query = '' ) {

		if ( $this->is_join_exist( $query ) ) {
			return '';
		}

		return " LEFT JOIN {$this->table} AS $this->alias ON $this->base_alias.wpid = $this->alias.user_id";
	}

	public function get_where_query() {
		$this->filter['key'] = 'active_count';

		return $this->prepare_query_for_bool();
	}

}

if ( function_exists( 'bwfan_is_sublium_active' ) && bwfan_is_sublium_active() ) {
	BWFCRM_Core()->filters->register( 'sublium', 'Filters\Sublium\Has_Active_Subscription', 'sublium_has_active_subs' );
}

