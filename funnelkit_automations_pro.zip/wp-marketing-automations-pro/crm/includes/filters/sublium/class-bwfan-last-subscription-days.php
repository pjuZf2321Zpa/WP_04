<?php

namespace Filters\Sublium;

use BWFAN_Filter_Base;

#[\AllowDynamicProperties]
class Last_Subscription_Days extends BWFAN_Filter_Base {
	public static $ins = null;

	public function __construct( $value = [] ) {
		$this->is_preference = true;
		$this->name          = __( 'Last Subscription Days', 'wp-marketing-automations-pro' );
		$this->group_name = __( 'Sublium Subscriptions', 'wp-marketing-automations-pro' );
		$this->filter     = $value;
		$this->priority   = 5;

		global $wpdb;
		$this->base_table = "{$wpdb->prefix}bwf_contact";
		$this->base_alias = "c";
		$this->table      = "{$wpdb->prefix}sublium_wcs_subscribers";
		$this->columns    = [];
		$this->alias      = 'ss';
	}

	/**
	 * @return Last_Subscription_Days|mixed|null
	 */
	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	public function get_type() {
		return 'Days';
	}

	public function get_possible_operators() {
		$operators = [
			'over'        => __( 'Over', 'wp-marketing-automations-pro' ),
			'past'        => __( 'In the past', 'wp-marketing-automations-pro' ),
			'not_past'    => __( 'Not in the last', 'wp-marketing-automations-pro' ),
			'between'     => __( 'In the period', 'wp-marketing-automations-pro' ),
			'not_between' => __( 'Not in the period', 'wp-marketing-automations-pro' ),
		];

		/** 'not_between' needs the Lite 3.8.4 filter-type JS for its dual-input control. */
		if ( ! self::supports_range_negation() ) {
			unset( $operators['not_between'] );
		}

		return $operators;
	}

	public function get_join_query( $query = '' ) {

		if ( $this->is_join_exist( $query ) ) {
			return '';
		}

		return " LEFT JOIN {$this->table} AS $this->alias ON $this->base_alias.wpid = $this->alias.user_id";
	}

	public function get_where_query() {
		$this->filter['key'] = 'last_order_date';

		return $this->prepare_date_query();
	}

}

if ( function_exists( 'bwfan_is_sublium_active' ) && bwfan_is_sublium_active() ) {
	BWFCRM_Core()->filters->register( 'sublium', 'Filters\Sublium\Last_Subscription_Days', 'sublium_l_subscription_days' );
}

