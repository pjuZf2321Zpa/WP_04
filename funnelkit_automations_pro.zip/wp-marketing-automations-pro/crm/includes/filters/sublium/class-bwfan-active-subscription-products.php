<?php

namespace Filters\Sublium;

use BWFAN_Filter_Base;

#[\AllowDynamicProperties]
class Active_Subscription_Products extends BWFAN_Filter_Base {
	public static $ins = null;

	public function __construct( $value = [] ) {
		$this->is_preference = true;
		$this->name          = __( 'Active Subscription Products', 'wp-marketing-automations-pro' );
		$this->group_name = __( 'Sublium', 'wp-marketing-automations-pro' );
		$this->filter     = $value;
		$this->priority   = 12;

		global $wpdb;
		$this->base_table = "{$wpdb->prefix}bwf_contact";
		$this->base_alias = "c";
		$this->table      = "{$wpdb->prefix}sublium_wcs_subscribers";
		$this->columns    = [];
		$this->alias      = 'ss';
	}

	/**
	 * @return Active_Subscription_Products|mixed|null
	 */
	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	public function get_options( $search = '' ) {

		$subscription_products = get_posts( array(
			'post_type'      => 'product',
			'posts_per_page' => 10,
			's'              => $search,
		) );

		$product_array = array();

		foreach ( $subscription_products as $product_post ) {
			$product                            = wc_get_product( $product_post->ID );
			$product_array[ $product_post->ID ] = strip_tags( $product->get_formatted_name() );
			if ( in_array( $product->get_type(), array( 'variable', 'variable-subscription' ), true ) ) {
				$variations = $product->get_children();
				foreach ( $variations as $variation_id ) {
					$variation = wc_get_product( $variation_id );

					$product_array[ $variation->get_id() ] = strip_tags( $variation->get_formatted_name() );
				}
			}
		}

		return $product_array;
	}

	public function get_type() {
		return 'Search';
	}

	public function get_possible_operators() {
		return [
			'any'  => __( 'matches any of', 'wp-marketing-automations-pro' ),
			'all'  => __( 'matches all of ', 'wp-marketing-automations-pro' ),
			'none' => __( 'matches none of ', 'wp-marketing-automations-pro' ),
		];
	}

	public function get_join_query( $query = '' ) {

		if ( $this->is_join_exist( $query ) ) {
			return '';
		}

		return " LEFT JOIN {$this->table} AS $this->alias ON $this->base_alias.wpid = $this->alias.user_id";
	}

	public function get_where_query() {
		$this->filter['key'] = 'active_subscription_products';
		if ( empty( $this->filter['value'] ) ) {
			return '';
		}

		return $this->prepare_query_for_json_array();
	}

}

if ( function_exists( 'bwfan_is_sublium_active' ) && bwfan_is_sublium_active() ) {
	BWFCRM_Core()->filters->register( 'sublium', 'Filters\Sublium\Active_Subscription_Products', 'sublium_active_subs_product' );
}

