<?php

namespace Filters\Sublium;

use BWFAN_Filter_Base;

#[\AllowDynamicProperties]
class Total_Renewal_Count extends BWFAN_Filter_Base {
	public static $ins = null;

	public function __construct( $value = [] ) {
		$this->is_preference = true;
		$this->name          = __( 'Total Renewal Count', 'wp-marketing-automations-pro' );
		$this->group_name = __( 'Sublium Subscriptions', 'wp-marketing-automations-pro' );
		$this->filter     = $value;
		$this->priority   = 10;

		global $wpdb;
		$this->base_table = "{$wpdb->prefix}bwf_contact";
		$this->base_alias = "c";
		$this->table      = "{$wpdb->prefix}sublium_wcs_subscribers";
		$this->columns    = [];
		$this->alias      = 'ss';
	}

	/**
	 * @return Total_Renewal_Count|mixed|null
	 */
	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	public function get_type() {
		return 'Number';
	}

	public function get_possible_operators() {
		return [
			'is'              => __( 'is', 'wp-marketing-automations-pro' ),
			'is_not'          => __( 'is not', 'wp-marketing-automations-pro' ),
			'less_than'       => __( 'less than', 'wp-marketing-automations-pro' ),
			'more_than'       => __( 'more than', 'wp-marketing-automations-pro' ),
			'more_than_equal' => __( 'more than equal', 'wp-marketing-automations-pro' ),
			'less_than_equal' => __( 'less than equal', 'wp-marketing-automations-pro' ),
		];
	}

	public function get_join_query( $query = '' ) {

		if ( $this->is_join_exist( $query ) ) {
			return '';
		}

		return " LEFT JOIN {$this->table} AS $this->alias ON $this->base_alias.wpid = $this->alias.user_id";
	}

	public function get_where_query() {
		$this->filter['key'] = 'renewals_count';

		return $this->prepare_query_for_number();
	}

}

if ( function_exists( 'bwfan_is_sublium_active' ) && bwfan_is_sublium_active() ) {
	BWFCRM_Core()->filters->register( 'sublium', 'Filters\Sublium\Total_Renewal_Count', 'sublium_renewal_count' );
}

