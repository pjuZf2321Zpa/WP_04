<?php

if ( ! class_exists( 'BWFAN_Filter_WLM_Level' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_WLM_Level extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->name          = __( 'Membership Level', 'wp-marketing-automations-pro' );
			$this->group_name    = __( 'Wishlist Member', 'wp-marketing-automations-pro' );
			$this->filter        = $value;
			$this->priority      = 1;
			$this->is_preference = false;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}bwf_contact_wlm_fields";
			$this->columns    = [];
			$this->alias      = 'wlm';
		}

		/**
		 * @return BWFAN_Filter_WLM_Level|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_options( $term = '' ) {
			return $this->get_possible_rule_values( $term );
		}

		public function get_possible_rule_values( $term ) {
			$levels  = wlmapi_get_levels();
			$options = array();

			// Return empty array if no levels found
			if ( empty( $levels['levels']['level'] ) ) {
				return $options;
			}

			// Format data for levels
			foreach ( $levels['levels']['level'] as $level ) {
				$options[ $level['id'] ] = $level['name'];
			}

			// If no search term, return first 10 items
			if ( empty( $term ) ) {
				return array_slice( $options, 0, 10, true );
			}

			return BWFAN_PRO_Common::search_srting_from_data( $options, $term );
		}

		public function get_value_as_key_label( $data ) {
			if ( empty( $data ) ) {
				return [];
			}

			// Get all levels at once
			$levels = wlmapi_get_levels();
			if ( empty( $levels['levels']['level'] ) ) {
				return [];
			}

			// Create lookup array for quick access
			$level_lookup = [];
			foreach ( $levels['levels']['level'] as $level ) {
				$level_lookup[ $level['id'] ] = $level['name'];
			}

			// Format the requested levels
			$value = [];
			foreach ( $data as $id ) {
				$value[] = [
					'key'   => $id,
					'label' => $level_lookup[ $id ] ?? '-'
				];
			}

			return $value;
		}

		public function get_type() {
			return 'Search';
		}

		public function get_possible_operators() {
			return array(
				'is'     => __( 'is', 'wp-marketing-automations-pro' ),
				'is_not' => __( 'is not', 'wp-marketing-automations-pro' ),
			);
		}

		public function old_operators() {
			return array(
				'yes' => 'is',
				'no'  => 'is_not'
			);
		}

		public function get_join_query( $query = '' ) {

			if ( $this->is_join_exist( $query ) ) {
				return '';
			}

			return " LEFT JOIN {$this->table} as $this->alias ON $this->base_alias.id=$this->alias.cid";
		}

		public function get_where_query() {
			$this->filter['key']   = 'level';
			$this->filter['value'] = is_array( $this->filter['value'] ) ? implode( ',', $this->filter['value'] ) : $this->filter['value'];
			$wlm_member            = BWFCRM_Integration_Wishlist_Member::get_instance();
			BWFCRM_Integration_Wishlist_Member::add_contact_filter( 'level', $this->filter['rule'], $this->filter['value'] );

			return $wlm_member->get_status_level_where_sql( '', $this );
		}

	}

	if ( bwfan_is_wlm_active() ) {
		BWFCRM_Core()->filters->register( 'bwf_wlm', 'BWFAN_Filter_WLM_Level', 'wlm_level' );
	}
}

