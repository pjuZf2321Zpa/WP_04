<?php
if ( ! class_exists( 'BWFAN_Filter_WLM_Status' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_WLM_Status extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->name          = __( 'Membership Status', 'wp-marketing-automations-pro' );
			$this->group_name    = __( 'Wishlist Member', 'wp-marketing-automations-pro' );
			$this->filter        = $value;
			$this->priority      = 2;
			$this->is_preference = false;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}bwf_contact_wlm_fields";
			$this->columns    = [];
			$this->alias      = 'wlm';
		}

		/**
		 * @return BWFAN_Filter_WLM_Status|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_options( $term = '' ) {
			$data = [
				'1' => __( 'Unconfirmed', 'wp-marketing-automations-pro' ),
				'2' => __( 'Active', 'wp-marketing-automations-pro' ),
				'3' => __( 'Pending', 'wp-marketing-automations-pro' ),
				'4' => __( 'Cancelled', 'wp-marketing-automations-pro' ),
				'5' => __( 'Scheduled', 'wp-marketing-automations-pro' ),
				'6' => __( 'Expired', 'wp-marketing-automations-pro' ),
			];

			return BWFAN_PRO_Common::search_srting_from_data( $data, $term );
		}

		public function get_type() {
			return 'Search';
		}

		public function get_possible_operators() {
			return [
				'any'  => __( 'Any', 'wp-marketing-automations-pro' ),
				'all'  => __( 'All', 'wp-marketing-automations-pro' ),
				'none' => __( 'None', 'wp-marketing-automations-pro' ),
			];
		}

		public function get_join_query( $query = '' ) {

			if ( $this->is_join_exist( $query ) ) {
				return '';
			}

			return " LEFT JOIN {$this->table}  AS $this->alias ON $this->base_alias.id=$this->alias.cid";
		}

		public function get_value_as_key_label( $data ) {
			$status = [
				'1' => __( 'Unconfirmed', 'wp-marketing-automations-pro' ),
				'2' => __( 'Active', 'wp-marketing-automations-pro' ),
				'3' => __( 'Pending', 'wp-marketing-automations-pro' ),
				'4' => __( 'Cancelled', 'wp-marketing-automations-pro' ),
				'5' => __( 'Scheduled', 'wp-marketing-automations-pro' ),
				'6' => __( 'Expired', 'wp-marketing-automations-pro' ),
			];

			$value = [];
			foreach ( $status as $key => $label ) {
				if ( in_array( $key, $data ) ) {
					$value[] = [
						'key'   => $key,
						'label' => $label,
					];
				}
			}

			return $value;
		}

		public function get_where_query() {
			$this->filter['key']   = 'status';
			$this->filter['value'] = is_array( $this->filter['value'] ) ? implode( ',', $this->filter['value'] ) : $this->filter['value'];
			$wlm_member            = BWFCRM_Integration_Wishlist_Member::get_instance();
			BWFCRM_Integration_Wishlist_Member::add_contact_filter( 'status', $this->filter['rule'], $this->filter['value'] );

			return $wlm_member->get_status_level_where_sql( '', $this );
		}
	}

	if ( bwfan_is_wlm_active() ) {
		BWFCRM_Core()->filters->register( 'bwf_wlm', 'BWFAN_Filter_WLM_Status', 'wlm_status' );
	}
}

