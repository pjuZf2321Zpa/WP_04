<?php

if ( ! class_exists( 'BWFAN_Filter_WLM_Exp' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_WLM_Exp extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->name           = __( 'Expiration Date', 'wp-marketing-automations-pro' );
			$this->group_name     = __( 'Wishlist Member', 'wp-marketing-automations-pro' );
			$this->group_priority = 120;
			$this->filter         = $value;
			$this->priority       = 4;
			$this->is_preference  = false;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}bwf_contact_wlm_fields";
			$this->columns    = [];
			$this->alias      = 'wlm';
		}

		/**
		 * @return BWFAN_Filter_WLM_Exp|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_type() {
			return 'Date';
		}

		public function get_possible_operators() {
			return array(
				'before'  => __( 'Before', 'wp-marketing-automations-pro' ),
				'after'   => __( 'After', 'wp-marketing-automations-pro' ),
				'is'      => __( 'On', 'wp-marketing-automations-pro' ),
				'between' => __( 'Between', 'wp-marketing-automations-pro' ),
			);
		}

		public function get_join_query( $query = '' ) {

			if ( $this->is_join_exist( $query ) ) {
				return '';
			}

			return " LEFT JOIN {$this->table}  AS $this->alias ON $this->base_alias.id=$this->alias.cid";
		}

		public function get_where_query() {
			$this->filter['key'] = 'exp';
			$wlm_member          = BWFCRM_Integration_Wishlist_Member::get_instance();
			BWFCRM_Integration_Wishlist_Member::add_contact_filter( 'exp', $this->filter['rule'], $this->filter['value'] );

			return $wlm_member->get_exp_level_where_sql( '', $this );
		}

	}

	if ( bwfan_is_wlm_active() ) {
		BWFCRM_Core()->filters->register( 'bwf_wlm', 'BWFAN_Filter_WLM_Exp', 'wlm_exp' );
	}
}
