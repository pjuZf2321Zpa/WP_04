<?php

if ( ! class_exists( 'BWFAN_Filter_BWF_CF' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_BWF_CF extends BWFAN_Filter_Base {
		public static $ins = null;
		private $field_id = 0;
		private $field_type = 0;

		public function __construct( $filter = [], $field_id = 0 ) {
			$this->is_preference   = true;
			$this->group_name      = __( 'Custom Field', 'wp-marketing-automations-pro' );
			$this->group_priority  = 30;
			if ( 0 === intval( $field_id ) ) {
				return;
			}
			$this->field_id         = $field_id;
			$filter['key']          = "f$this->field_id";
			$field                  = BWFAN_Model_Fields::get_field_by_id( $this->field_id );
			$this->is_field_valid   = ! empty( $field );
			if ( ! $this->is_field_valid ) {
				return;
			}
			$this->field_type = isset( $field['type'] ) ? intval( $field['type'] ) : '';
			$this->slug       = 'bwf_cf' . $this->field_id;
			$this->name       = isset( $field['name'] ) ? $field['name'] : '';
			$this->filter     = $filter;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}bwf_contact_fields";
			$this->columns    = [];
			$this->alias      = 'cf';
		}

		/**
		 * @return BWFAN_Filter_BWF_CF|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_options( $term = '' ) {
			$field = BWFAN_Model_Fields::get_field_by_id( $this->field_id );

			/** Ensure the field is not empty or its type is either checkbox, select, or radio */
			if ( empty( $field ) || ! in_array( intval( $field['type'] ), [ BWFCRM_Fields::$TYPE_CHECKBOX, BWFCRM_Fields::$TYPE_SELECT, BWFCRM_Fields::$TYPE_RADIO ], true ) ) {
				return [];
			}

			$options = $field['meta']->options ?? [];
			if ( empty( $options ) ) {
				return [];
			}

			if ( BWFCRM_Fields::$TYPE_CHECKBOX === absint( $this->field_type ) ) {
				$options = BWFAN_PRO_Common::search_srting_from_data( $options, $term );
			}

			return $this->get_formatted_options( $options );
		}

		public function get_formatted_options( $options ) {
			if ( empty( $options ) ) {
				return [];
			}
			$formatted = [];
			foreach ( $options as $option ) {
				$formatted[ $option ] = $option;
			}

			return $formatted;
		}

		public function get_type() {
			switch ( intval( $this->field_type ) ) {
				case BWFCRM_Fields::$TYPE_SELECT:
				case BWFCRM_Fields::$TYPE_RADIO:
					return 'Select';
				case BWFCRM_Fields::$TYPE_CHECKBOX:
					return 'Search';
				case BWFCRM_Fields::$TYPE_NUMBER:
					return 'Number';
				case BWFCRM_Fields::$TYPE_DATE:
					return 'Date';
				case BWFCRM_Fields::$TYPE_DATETIME:
					return 'DateTime';
				case BWFCRM_Fields::$TYPE_TIME:
					return 'Time';
				default:
					return 'Text';
			}
		}


		public function get_possible_operators() {
			$operators = [];

			switch ( true ) {
				case ( BWFCRM_Fields::$TYPE_TEXT === absint( $this->field_type ) || BWFCRM_Fields::$TYPE_TEXTAREA === absint( $this->field_type ) ):
					$operators = $this->get_possible_text_operators();
					break;
				case ( BWFCRM_Fields::$TYPE_SELECT === absint( $this->field_type ) || BWFCRM_Fields::$TYPE_RADIO === absint( $this->field_type ) ):
					$operators = $this->get_possible_radio_operators();
					break;
				case ( BWFCRM_Fields::$TYPE_NUMBER === absint( $this->field_type ) ) :
					$operators = $this->get_possible_number_operators();
					break;
				case ( BWFCRM_Fields::$TYPE_CHECKBOX === absint( $this->field_type ) ) :
					$operators = $this->get_possible_checkbox_operators();
					break;
				case ( BWFCRM_Fields::$TYPE_DATE === absint( $this->field_type ) ) :
					$operators = $this->get_possible_date_operators();
					break;
				case ( BWFCRM_Fields::$TYPE_DATETIME === absint( $this->field_type ) ) :
					$operators = $this->get_possible_datetime_operators();
					break;
				case ( BWFCRM_Fields::$TYPE_TIME === absint( $this->field_type ) ) :
					$operators = $this->get_possible_datetime_operators();
			}

			return $operators;
		}

		public function get_possible_datetime_operators() {
			return [

				'is'           => __( 'is', 'wp-marketing-automations-pro' ),
				'is_not'       => __( 'is not', 'wp-marketing-automations-pro' ),
				'is_after'     => __( 'is after', 'wp-marketing-automations-pro' ),
				'is_before'    => __( 'is before', 'wp-marketing-automations-pro' ),
				'on_before'    => __( 'is on or before', 'wp-marketing-automations-pro' ),
				'on_after'     => __( 'is on or after', 'wp-marketing-automations-pro' ),
				'is_blank'     => __( 'Is blank', 'wp-marketing-automations-pro' ),
				'is_not_blank' => __( 'Is not blank', 'wp-marketing-automations-pro' ),
			];
		}

		public function old_operators() {
			return [
				'before' => 'is_before',
				'after'  => 'is_after',
			];
		}

		public function get_possible_text_operators() {
			return array(
				'is'           => __( 'is', 'wp-marketing-automations-pro' ),
				'is_not'       => __( 'is not', 'wp-marketing-automations-pro' ),
				'contains'     => __( 'contains', 'wp-marketing-automations-pro' ),
				'not_contains' => __( 'does not contains', 'wp-marketing-automations-pro' ),
				'starts_with'  => __( 'start with', 'wp-marketing-automations-pro' ),
				'ends_with'    => __( 'end with', 'wp-marketing-automations-pro' ),
				'is_blank'     => __( 'is blank', 'wp-marketing-automations-pro' ),
				'is_not_blank' => __( 'is not blank', 'wp-marketing-automations-pro' ),
			);
		}


		public function get_possible_radio_operators() {
			return array(
				'is'     => __( 'is', 'wp-marketing-automations-pro' ),
				'is_not' => __( 'is not', 'wp-marketing-automations-pro' )
			);
		}

		public function get_possible_date_operators() {
			return array(
				'before'       => __( 'Before', 'wp-marketing-automations-pro' ),
				'after'        => __( 'After', 'wp-marketing-automations-pro' ),
				'is'           => __( 'On', 'wp-marketing-automations-pro' ),
				'between'      => __( 'Between', 'wp-marketing-automations-pro' ),
				'is_blank'     => __( 'Is blank', 'wp-marketing-automations-pro' ),
				'is_not_blank' => __( 'Is not blank', 'wp-marketing-automations-pro' ),
			);
		}

		public function get_possible_number_operators() {
			return array(
				'is'              => __( 'is', 'wp-marketing-automations-pro' ),
				'is_not'          => __( 'is not', 'wp-marketing-automations-pro' ),
				'less_than'       => __( 'Less Than', 'wp-marketing-automations-pro' ),
				'more_than'       => __( 'More Than', 'wp-marketing-automations-pro' ),
				'is_blank'        => __( 'is blank', 'wp-marketing-automations-pro' ),
				'is_not_blank'    => __( 'is not blank', 'wp-marketing-automations-pro' ),
				'more_than_equal' => __( 'More than Equal', 'wp-marketing-automations-pro' ),
				'less_then_equal' => __( 'Less Than Equal', 'wp-marketing-automations-pro' ),
			);
		}

		public function get_possible_checkbox_operators() {
			return [
				'any'  => __( 'Any', 'wp-marketing-automations-pro' ),
				'all'  => __( 'All', 'wp-marketing-automations-pro' ),
				'none' => __( 'None', 'wp-marketing-automations-pro' ),
			];
		}

		public function get_join_query( $query = '' ) {

			if ( $this->is_join_exist( $query ) ) {
				return '';
			}

			$query = " LEFT JOIN {$this->table} AS $this->alias ON $this->base_alias.id = $this->alias.cid";

			return $query;
		}

		public function get_where_query() {
			$this->filter['type'] = $this->field_type;
			switch ( absint( $this->field_type ) ) {
				case BWFCRM_Fields::$TYPE_CHECKBOX:
					$query = $this->prepare_query_for_json_array();
					break;
				case BWFCRM_Fields::$TYPE_DATE:
				case BWFCRM_Fields::$TYPE_DATETIME:
				case BWFCRM_Fields::$TYPE_TIME:
					$query = $this->get_date_filter_sql();
					break;
				case BWFCRM_Fields::$TYPE_NUMBER:
					$query = $this->prepare_query_for_number();
					break;
				case BWFCRM_Fields::$TYPE_SELECT:
				case BWFCRM_Fields::$TYPE_RADIO:
					/** Single-value fields: don't split stored option labels on commas. */
					$query = $this->prepare_query( false );
					break;
				default:
					$query = $this->prepare_query();
			}

			return $query;
		}

	}

	BWFCRM_Core()->filters->register( 'contact_custom_fields', 'BWFAN_Filter_BWF_CF' );
}
