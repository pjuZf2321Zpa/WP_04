<?php

if ( ! class_exists( 'BWFAN_Filter_Page_Viewed' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Page_Viewed extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->name           = __( 'Page viewed', 'wp-marketing-automations-pro' );
			$this->group_name     = __( 'Page Viewed', 'wp-marketing-automations-pro' );
			$this->group_priority = 60;
			$this->filter         = $value;
			$this->priority       = 6;
			$this->is_preference  = false;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}bwfan_page_viewed";
			$this->columns    = [];
			$this->alias      = 'pv';
		}

		/**
		 * @return BWFAN_Filter_Page_Viewed|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_options( $search = '' ) {
			global $wpdb;
			$query = "SELECT `ID`,`post_title` FROM `{$wpdb->prefix}posts` WHERE `post_type` = 'page' AND  `post_status` = 'publish'";

			if ( ! empty( $search ) ) {
				$query .= $wpdb->prepare( " AND ( `post_title` LIKE %s OR `ID` LIKE %s )", '%' . $search . '%', '%' . $search . '%' );
			}
			$query .= " LIMIT 0, 10";

			$pages           = $wpdb->get_results( $query, ARRAY_A ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL
			$formatted_pages = [];
			foreach ( $pages as $page ) {
				$formatted_pages[ $page['ID'] ] = $page['post_title'] . ' (#' . $page['ID'] . ')';
			}

			return $formatted_pages;

		}

		public function get_type() {
			return 'Search';
		}

		public function get_possible_operators() {
			return [
				'any'  => __( 'matches any of', 'wp-marketing-automations-pro' ),
				'all'  => __( 'matches all of ', 'wp-marketing-automations-pro' ),
				'none' => __( 'matches none of ', 'wp-marketing-automations-pro' ),
			];
		}

		public function get_where_query() {
			$filter_value = $this->filter['value'];
			$filter_rule  = $this->filter['rule'];

			if ( empty( $filter_value ) || empty( $filter_rule ) ) {
				return '';
			}

			if ( ! is_array( $filter_value ) ) {
				$filter_value = array( $filter_value );
			}

			$extra_where = " AND {$this->alias}.type='page'";

			return $this->build_exists_query_single_value_column( $filter_value, $filter_rule, 'obj_id', $extra_where, null, [ 'none', 'no', 'is_not' ] );
		}

	}

	if ( class_exists( 'BWFCRM_PV_Tracker' ) ) {
		BWFCRM_Core()->filters->register( 'page_viewed', 'BWFAN_Filter_Page_Viewed', 'page_viewed' );
	}
}
