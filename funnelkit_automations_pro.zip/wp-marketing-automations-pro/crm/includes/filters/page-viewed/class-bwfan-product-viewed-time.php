<?php

if ( ! class_exists( 'BWFAN_Filter_Product_Viewed_Time' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Product_Viewed_Time extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->is_preference  = false;
			$this->name           = __( 'Product viewed time', 'wp-marketing-automations-pro' );
			$this->group_name     = __( 'Page Viewed', 'wp-marketing-automations-pro' );
			$this->group_priority = 60;
			$this->filter         = $value;
			$this->priority       = 6;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}bwfan_page_viewed";
			$this->columns    = [];
			$this->alias      = 'pv';
		}

		/**
		 * @return BWFAN_Filter_Product_Viewed_Time|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_type() {
			return 'Date';
		}

		public function get_possible_operators() {
			return array(
				'before'  => __( 'Before', 'wp-marketing-automations-pro' ),
				'after'   => __( 'After', 'wp-marketing-automations-pro' ),
				'is'      => __( 'On', 'wp-marketing-automations-pro' ),
				'between' => __( 'Between', 'wp-marketing-automations-pro' ),
			);
		}

		public function get_where_query() {
			$filter_value = $this->filter['value'];
			$filter_rule  = $this->filter['rule'];

			if ( empty( $filter_value ) || empty( $filter_rule ) ) {
				return '';
			}

			$group_by_query      = " GROUP BY {$this->alias}.cid";
			$this->filter['key'] = 'time';
			$where               = $this->get_date_filter_sql();

			return " EXISTS (SELECT 1 FROM {$this->table} as {$this->alias} WHERE {$this->base_alias}.id = {$this->alias}.cid AND {$this->alias}.type='product' AND ($where) $group_by_query)";
		}

	}

	if ( class_exists( 'BWFCRM_PV_Tracker' ) ) {
		BWFCRM_Core()->filters->register( 'page_viewed', 'BWFAN_Filter_Product_Viewed_Time', 'product_viewed_time' );
	}
}
