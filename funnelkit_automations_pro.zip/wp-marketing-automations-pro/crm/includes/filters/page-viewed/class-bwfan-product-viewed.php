<?php

if ( ! class_exists( 'BWFAN_Filter_Product_Viewed' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Product_Viewed extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->is_preference  = false;
			$this->name           = __( 'Product viewed', 'wp-marketing-automations-pro' );
			$this->group_name     = __( 'Page Viewed', 'wp-marketing-automations-pro' );
			$this->group_priority = 60;
			$this->filter         = $value;
			$this->priority       = 6;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}bwfan_page_viewed";
			$this->columns    = [];
			$this->alias      = 'pv';
		}

		/**
		 * @return BWFAN_Filter_Product_Viewed|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_options( $search = '' ) {
			BWFAN_Common::$offer_product_types = [
				'simple',
				'variable',
				'variation',
				'subscription',
				'variable-subscription',
				'subscription_variation'
			];

			$array  = BWFAN_Common::product_search( $search, true, true );
			$return = array();
			foreach ( $array as $product ) {
				$return[ $product['id'] ] = $product['text'];
			}

			return $return;
		}

		public function get_type() {
			return 'Search';
		}

		public function get_possible_operators() {
			return [
				'any'  => __( 'matches any of', 'wp-marketing-automations-pro' ),
				'all'  => __( 'matches all of ', 'wp-marketing-automations-pro' ),
				'none' => __( 'matches none of ', 'wp-marketing-automations-pro' ),
			];
		}

		public function get_where_query() {
			$filter_value = $this->filter['value'];
			$filter_rule  = $this->filter['rule'];

			if ( empty( $filter_value ) || empty( $filter_rule ) ) {
				return '';
			}

			if ( ! is_array( $filter_value ) ) {
				$filter_value = array( $filter_value );
			}

			$extra_where = " AND {$this->alias}.type='product'";

			return $this->build_exists_query_single_value_column( $filter_value, $filter_rule, 'obj_id', $extra_where, null, [ 'none', 'no', 'is_not' ] );
		}

	}

	if ( class_exists( 'BWFCRM_PV_Tracker' ) ) {
		BWFCRM_Core()->filters->register( 'page_viewed', 'BWFAN_Filter_Product_Viewed', 'product_viewed' );
	}
}
