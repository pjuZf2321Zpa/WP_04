<?php

if ( ! class_exists( 'BWFAN_Filter_Contact_Country' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Contact_Country extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->is_preference = true;
			$this->name          = __( 'Country', 'wp-marketing-automations-pro' );
			$this->group_name = __( 'Geography', 'wp-marketing-automations-pro' );
			$this->filter     = $value;
			$this->priority   = 1;

			global $wpdb;
			$this->table   = "{$wpdb->prefix}bwf_contact";
			$this->columns = [ "country" ];
			$this->alias   = 'c';

		}

		/**
		 * @return BWFAN_Filter_Contact_Country|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_possible_rule_values() {
			$countries_data = array();
			/** get countries using get countries data from woofunnels core */
			if ( function_exists( 'bwf_get_countries_data' ) ) {
				$countries_data = bwf_get_countries_data();
			}

			return $countries_data;
		}

		public function get_options( $term = '' ) {
			$countries = $this->get_possible_rule_values();

			if ( empty( $term ) ) {
				return $countries;
			}

			$array = array_filter( $countries, function ( $country ) use ( $term ) {
				return false !== strpos( strtolower( $country ), strtolower( $term ) );
			} );

			return $array;
		}


		public function get_type() {
			return 'Search';
		}

		public function get_possible_operators() {
			return array(
				'is'           => __( 'matches any of', 'wp-marketing-automations-pro' ),
				'is_not'       => __( 'matches none of', 'wp-marketing-automations-pro' ),
				'is_blank'     => __( 'is blank', 'wp-marketing-automations-pro' ),
				'is_not_blank' => __( 'is not blank', 'wp-marketing-automations-pro' ),
			);
		}

		public function get_value_as_key_label( $data ) {
			if ( empty( $data ) ) {
				return [];
			}
			$countries_data = bwf_get_countries_data();
			$values         = [];
			foreach ( $data as $value ) {
				$values[] = [
					'key'   => $value,
					'label' => isset( $countries_data[ $value ] ) ? $countries_data[ $value ] : $value,
				];
			}

			return $values;
		}

		public function get_where_query() {

			return $this->prepare_query();
		}

	}

	BWFCRM_Core()->filters->register( 'geography', 'BWFAN_Filter_Contact_Country', 'country' );
}
