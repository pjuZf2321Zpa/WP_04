<?php

if ( ! class_exists( 'BWFAN_Filter_Contact_Lists' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Contact_Lists extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $filter = [] ) {
			$this->is_preference  = true;
			$this->name           = __( 'Lists', 'wp-marketing-automations-pro' );
			$this->group_name     = __( 'Segments', 'wp-marketing-automations-pro' );
			$this->group_priority = 10;
			$this->filter         = $filter;
			$this->priority       = 3;

			global $wpdb;
			$this->table   = "{$wpdb->prefix}bwf_contact";
			$this->columns = [ "lists" ];
			$this->alias   = 'c';

		}

		/**
		 * @return BWFAN_Filter_Contact_Lists|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_options( $term = '' ) {

			return $this->get_search_results( $term, true );
		}

		public function get_search_results( $term, $v2 = false ) {
			$array     = array();
			$get_lists = BWFCRM_Lists::get_lists( array(), $term, 0, 10 );

			if ( empty( $get_lists ) ) {
				if ( $v2 ) {
					return array();
				}

				wp_send_json( array(
					'results' => $array,
				) );
			}

			if ( $v2 ) {
				foreach ( $get_lists as $list ) {
					$array[ $list['ID'] ] = $list['name'];
				}

				return $array;
			}

			foreach ( $get_lists as $list ) {
				array_push( $array, array(
					'id'   => $list['ID'],
					'text' => $list['name'],
				) );
			}
			wp_send_json( array(
				'results' => $array,
			) );
		}

		public function get_type() {
			return 'Search';
		}

		public function get_possible_operators() {
			return [
				'any'          => __( 'matches any of', 'wp-marketing-automations-pro' ),
				'all'          => __( 'matches all of ', 'wp-marketing-automations-pro' ),
				'none'         => __( 'matches none of ', 'wp-marketing-automations-pro' ),
				'is_blank'     => __( 'is blank', 'wp-marketing-automations-pro' ),
				'is_not_blank' => __( 'is not blank', 'wp-marketing-automations-pro' ),
			];
		}

		public function get_value_as_key_label( $data ) {
			if ( empty( $data ) ) {
				return [];
			}

			$lists   = BWFCRM_Lists::get_lists( $data );
			$all_ids = [];
			foreach ( $data as $item ) {
				if ( strpos( $item, ',' ) !== false ) {
					$ids     = explode( ',', $item );
					$all_ids = array_merge( $all_ids, $ids );
				} else {
					$all_ids[] = $item;
				}
			}
			$values = [];
			foreach ( $all_ids as $key => $id ) {
				$values[] = [
					'key'   => $id,
					'label' => isset( $lists[ $key ] ) ? $lists[ $key ]['name'] : '-'
				];
			}

			return $values;
		}

		/**
		 * @param $query
		 *
		 * @return mixed|string
		 */
		public function get_where_query() {
			$this->filter['key'] = 'lists';
			if ( isset( $this->filter['rule'] ) && $this->filter['rule'] === 'is_blank' ) {
				return "(c.lists IS NULL OR c.lists = '' OR c.lists = '[]')";
			}
			if ( isset( $this->filter['rule'] ) && $this->filter['rule'] === 'is_not_blank' ) {
				return "(c.lists IS NOT NULL AND c.lists != '' AND c.lists != '[]')";
			}

			return $this->prepare_query_for_json_array();
		}

	}

	BWFCRM_Core()->filters->register( 'segments', 'BWFAN_Filter_Contact_Lists', 'lists' );
}
