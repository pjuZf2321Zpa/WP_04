<?php

if ( ! class_exists( 'BWFAN_Filter_Customer_Marketing_Status' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Customer_Marketing_Status extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->is_preference = true;
			$this->name          = __( 'Status', 'wp-marketing-automations-pro' );
			$this->group_name = __( 'Segments', 'wp-marketing-automations-pro' );
			$this->filter     = $value;
			$this->priority   = 1;

			global $wpdb;
			$this->table   = "{$wpdb->prefix}bwf_contact";
			$this->columns = [ "status" ];
			$this->alias   = 'c';
		}

		/**
		 * @return BWFAN_Filter_Customer_Marketing_Status|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_options( $term = '' ) {
			return [
				'0' => __( 'Unverified', 'wp-marketing-automations-pro' ),
				'1' => __( 'Subscribed', 'wp-marketing-automations-pro' ),
				'2' => __( 'Bounced', 'wp-marketing-automations-pro' ),
				'3' => __( 'Unsubscribed', 'wp-marketing-automations-pro' ),
				'4' => __( 'Soft Bounced', 'wp-marketing-automations-pro' ),
				'5' => __( 'Complaint', 'wp-marketing-automations-pro' ),
			];
		}

		public function get_type() {
			return 'Select';
		}

		public function get_possible_operators() {
			return array(
				'is'     => __( 'is', 'wp-marketing-automations-pro' ),
				'is_not' => __( 'is not', 'wp-marketing-automations-pro' ),
			);
		}

		public function get_default_value() {
			return '1';
		}

		public function get_where_query() {
			$this->filter['key']  = 'status';
			$this->filter['rule'] = empty( $this->filter['rule'] ) ? 'is' : $this->filter['rule'];
			if ( 3 === intval( $this->filter['value'] ) ) {
				return '(' . $this->_get_unsubscribers_query( $this->filter ) . ')';
			}
			$unsubscribe_query = $this->_get_unsubscribers_query( $this->filter );

			$status_query = $this->prepare_query_for_number();
			$status_query = ! empty( $status_query ) ? " $status_query " : "";
			$status_query = ! empty( $unsubscribe_query ) ? " $status_query AND" : $status_query;

			return ! empty( $unsubscribe_query ) || ! empty( $status_query ) ? '(' . $status_query . $unsubscribe_query . ')' : '';
		}

	}

	BWFCRM_Core()->filters->register( 'segments', 'BWFAN_Filter_Customer_Marketing_Status', 'status' );
}
