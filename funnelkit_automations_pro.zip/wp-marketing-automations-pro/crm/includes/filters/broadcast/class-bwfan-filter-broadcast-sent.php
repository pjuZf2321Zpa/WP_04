<?php
if ( ! class_exists( 'BWFAN_Filter_Broadcast_Sent' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Broadcast_Sent extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = '' ) {
			$this->name          = __( 'Broadcast Sent', 'wp-marketing-automations-pro' );
			$this->group_name    = __( 'Broadcast', 'wp-marketing-automations-pro' );
			$this->filter        = $value;
			$this->priority      = 1;
			$this->is_preference = false;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}bwfan_engagement_tracking";
			$this->columns    = [];
			$this->alias      = 'et';
		}

		/**
		 * @return BWFAN_Filter_Broadcast_Sent|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_options( $term = '' ) {
			return BWFAN_PRO_Common::get_broadcasts_by_term( $term );
		}

		public function get_type() {
			return 'Search';
		}

		public function get_value_as_key_label( $data ) {
			if ( empty( $data ) ) {
				return [];
			}

			$broad_ins  = BWFCRM_Campaigns::get_instance();
			$broad_data = $broad_ins->get_broadcast_lookup( [ 'ids' => $data ] );
			$values     = [];
			foreach ( $data as $key => $id ) {
				$values[] = [
					'key'   => $id,
					'label' => isset( $broad_data[ $id ] ) ? $broad_data[ $id ]['title'] : '-'
				];
			}

			return $values;
		}

		public function get_possible_operators() {
			return [
				'any'  => __( 'matches any of', 'wp-marketing-automations-pro' ),
				'all'  => __( 'matches all of ', 'wp-marketing-automations-pro' ),
				'none' => __( 'matches none of ', 'wp-marketing-automations-pro' ),
			];
		}

		public function get_where_query() {
			$filter_value = $this->filter['value'];
			$filter_rule  = $this->filter['rule'];

			$status_send    = BWFAN_Email_Conversations::$STATUS_SEND;
			$type_broadcast = BWFAN_Email_Conversations::$TYPE_CAMPAIGN;
			$new_value      = [];
			foreach ( $filter_value as $value ) {
				if ( ! isset( $value['key'] ) ) {
					continue;
				}
				$new_value[] = $value['key'];
			}
			$filter_value = ! empty( $new_value ) ? $new_value : $filter_value;

			if ( ! is_array( $filter_value ) ) {
				$filter_value = array( $filter_value );
			}

			$extra_where = " AND egt.type = $type_broadcast AND egt.c_status = $status_send";

			return $this->build_exists_query_single_value_column( $filter_value, $filter_rule, 'oid', $extra_where, 'egt' );
		}

	}

	BWFCRM_Core()->filters->register( 'bwf_broadcast', 'BWFAN_Filter_Broadcast_Sent', 'broadcast_sent' );
}
