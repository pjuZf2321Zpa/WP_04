<?php

if ( ! class_exists( 'BWFAN_Filter_Contact_Last_Name' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Contact_Last_Name extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->is_preference = true;
			$this->name          = __( 'Last Name', 'wp-marketing-automations-pro' );
			$this->group_name = __( 'Contact Details', 'wp-marketing-automations-pro' );
			$this->filter     = $value;
			$this->priority   = 2;

			global $wpdb;
			$this->table   = "{$wpdb->prefix}bwf_contact";
			$this->columns = [ "l_name" ];
			$this->alias   = 'c';

		}

		/**
		 * @return BWFAN_Filter_Contact_Last_Name|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_type() {
			return 'Text';
		}

		public function get_possible_operators() {
			return array(
				'is'           => __( 'is', 'wp-marketing-automations-pro' ),
				'is_not'       => __( 'is not', 'wp-marketing-automations-pro' ),
				'contains'     => __( 'contains', 'wp-marketing-automations-pro' ),
				'not_contains' => __( 'does not contain', 'wp-marketing-automations-pro' ),
				'starts_with'  => __( 'starts with', 'wp-marketing-automations-pro' ),
				'ends_with'    => __( 'ends with', 'wp-marketing-automations-pro' ),
				'is_blank'     => __( 'is blank', 'wp-marketing-automations-pro' ),
				'is_not_blank' => __( 'is not blank', 'wp-marketing-automations-pro' ),
			);
		}

		public function get_where_query() {
			$this->filter['key'] = 'l_name';

			return $this->prepare_query();
		}

	}

	BWFCRM_Core()->filters->register( 'contact_details', 'BWFAN_Filter_Contact_Last_Name','l_name' );
}
