<?php

if ( ! class_exists( 'BWFAN_Filter_Contact_Creation_Days' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Contact_Creation_Days extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->is_preference = true;
			$this->name          = __( 'Contact Created (Days)', 'wp-marketing-automations-pro' );
			$this->group_name = __( 'Contact Details', 'wp-marketing-automations-pro' );
			$this->filter     = $value;
			$this->priority   = 6;

			global $wpdb;
			$this->table   = "{$wpdb->prefix}bwf_contact";
			$this->columns = [];
			$this->alias   = 'c';
		}

		/**
		 * @return BWFAN_Filter_Contact_Creation_Days|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_type() {
			return 'Days';
		}

		public function get_possible_operators() {
			$operators = array(
				'over'        => __( 'Over', 'wp-marketing-automations-pro' ),
				'past'        => __( 'In the past', 'wp-marketing-automations-pro' ),
				'not_past'    => __( 'Not in the last', 'wp-marketing-automations-pro' ),
				'between'     => __( 'In the period', 'wp-marketing-automations-pro' ),
				'not_between' => __( 'Not in the period', 'wp-marketing-automations-pro' ),
			);

			/** 'not_between' needs the Lite 3.8.4 filter-type JS for its dual-input control. */
			if ( ! self::supports_range_negation() ) {
				unset( $operators['not_between'] );
			}

			return $operators;
		}

		public function get_where_query() {
			$filter_value = $this->filter['value'];
			$filter_rule  = $this->filter['rule'];

			// creating dates from the value
			if ( ! is_array( $filter_value ) ) {
				$filter_value = absint( $filter_value );
				$date         = new DateTime( 'now', wp_timezone() );
				$date->modify( "-$filter_value days" );
				$filter_value = $date->format( 'Y-m-d' );
			} else {
				$from = isset( $filter_value['from'] ) ? intval( $filter_value['from'] ) : intval( $filter_value[0] );
				$to   = isset( $filter_value['to'] ) ? intval( $filter_value['to'] ) : intval( $filter_value[1] );
				$date = new DateTime( 'now', wp_timezone() );
				$date->modify( "-$from days" );
				$from = $date->format( 'Y-m-d' );

				$date = new DateTime( 'now', wp_timezone() );
				$date->modify( "-$to days" );
				$to = $date->format( 'Y-m-d' );

				$filter_value = array( $from, $to );
			}

			switch ( $filter_rule ) {
				case 'over':
					$filter_rule = '<';
					break;
				case 'past':
					$filter_rule = '>=';
					break;
				case 'not_past':
					$filter_rule = '<';
					break;
				case 'between':
					$filter_rule = 'between';
					break;
				case 'not_between':
					$filter_rule = 'between';
					break;
			}

			if ( ! in_array( $filter_rule, array( '<', '>=', 'between' ), true ) ) {
				return '';
			}
			global $wpdb;
			$col = "$this->alias.creation_date";

			/**
			 * Over and Past rule. Compare the raw column (no DATE() wrap) against a full-day cutoff so the
			 * lookup stays index-friendly (creation_date is indexed), matching prepare_date_query().
			 */
			if ( ! is_array( $filter_value ) ) {
				$cutoff = $filter_value . ' 00:00:00';
				if ( 'not_past' === $this->filter['rule'] ) {
					/** Inclusive negation: created before the cutoff OR no creation date — i.e. "not created in the last X days". */
					return $wpdb->prepare( "( $col $filter_rule %s OR $col IS NULL)", $cutoff );
				}

				return $wpdb->prepare( "( $col $filter_rule %s)", $cutoff );
			}

			/** Between Rule. Expand date-only range bounds to full days so DateTime columns are not clipped at midnight. */
			$lower_bound = $filter_value[1] . ' 00:00:00';
			$upper_bound = $filter_value[0] . ' 23:59:59';

			if ( 'not_between' === $this->filter['rule'] ) {
				/** Inclusive negation: outside the period OR no creation date — "not created in the period". */
				return $wpdb->prepare( "( $col < %s OR $col > %s OR $col IS NULL)", $lower_bound, $upper_bound );
			}

			return $wpdb->prepare( "( $col >= %s AND $col <= %s)", $lower_bound, $upper_bound );
		}

	}

	BWFCRM_Core()->filters->register( 'contact_details', 'BWFAN_Filter_Contact_Creation_Days','creation_days' );
}
