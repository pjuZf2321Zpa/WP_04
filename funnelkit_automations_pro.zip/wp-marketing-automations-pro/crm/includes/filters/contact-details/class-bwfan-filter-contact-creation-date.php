<?php
if ( ! class_exists( 'BWFAN_Filter_Contact_Creation_Date' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Contact_Creation_Date extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->name          = __( 'Contact Created', 'wp-marketing-automations-pro' );
			$this->group_name    = __( 'Contact Details', 'wp-marketing-automations-pro' );
			$this->filter        = $value;
			$this->priority      = 5;
			$this->is_preference = true;

			global $wpdb;
			$this->table   = "{$wpdb->prefix}bwf_contact";
			$this->columns = [ "creation_date" ];
			$this->alias   = 'c';

		}

		/**
		 * @return BWFAN_Filter_Contact_Creation_Date|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_type() {
			return 'Date';
		}

		public function get_possible_operators() {
			return array(
				'before'  => __( 'Before', 'wp-marketing-automations-pro' ),
				'after'   => __( 'After', 'wp-marketing-automations-pro' ),
				'is'      => __( 'On', 'wp-marketing-automations-pro' ),
				'between' => __( 'Between', 'wp-marketing-automations-pro' ),
			);
		}

		public function get_where_query() {
			$this->filter['key'] = 'creation_date';

			return $this->get_date_filter_sql();
		}

	}

	BWFCRM_Core()->filters->register( 'contact_details', 'BWFAN_Filter_Contact_Creation_Date', 'creation_date' );
}
