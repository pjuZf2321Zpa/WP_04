<?php

if ( ! class_exists( 'BWFAN_Filter_Contact_DOB' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Contact_DOB extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->is_preference = true;
			$this->name          = __( 'Date of Birth', 'wp-marketing-automations-pro' );
			$this->group_name = __( 'Contact Details', 'wp-marketing-automations-pro' );
			$this->filter     = $value;
			$this->priority   = 9;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}bwf_contact_fields";
			$this->columns    = [];
			$this->alias      = 'cf';
		}

		/**
		 * @return BWFAN_Filter_Contact_DOB|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_type() {
			return 'Date';
		}

		public function get_possible_operators() {
			return array(
				'before'       => __( 'Before', 'wp-marketing-automations-pro' ),
				'after'        => __( 'After', 'wp-marketing-automations-pro' ),
				'on'           => __( 'On', 'wp-marketing-automations-pro' ),
				'between'      => __( 'Between', 'wp-marketing-automations-pro' ),
				'is_blank'     => __( 'Is blank', 'wp-marketing-automations-pro' ),
				'is_not_blank' => __( 'Is not blank', 'wp-marketing-automations-pro' ),
			);
		}

		public function get_join_query( $query = '' ) {

			if ( $this->is_join_exist( $query ) ) {
				return '';
			}

			return " LEFT JOIN {$this->table} AS $this->alias ON $this->base_alias.id = $this->alias.cid";
		}

		public function get_where_query() {
			$field_from_db = BWFAN_Model_Fields::get_field_by_slug( 'dob' );
			if ( empty( $field_from_db ) || ! isset( $field_from_db['ID'] ) ) {
				return '';
			}
			$this->filter['key'] = 'f' . $field_from_db['ID'];

			return $this->get_date_filter_sql();
		}

	}

	BWFCRM_Core()->filters->register( 'contact_details', 'BWFAN_Filter_Contact_DOB', 'dob' );
}
