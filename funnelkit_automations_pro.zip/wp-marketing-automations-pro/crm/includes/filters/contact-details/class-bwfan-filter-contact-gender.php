<?php

if ( ! class_exists( 'BWFAN_Filter_Contact_Gender' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Contact_Gender extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->is_preference = true;
			$this->name          = __( 'Gender', 'wp-marketing-automations-pro' );
			$this->group_name = __( 'Contact Details', 'wp-marketing-automations-pro' );
			$this->filter     = $value;
			$this->priority   = 8;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}bwf_contact_fields";
			$this->columns    = [];
			$this->alias      = 'cf';
		}

		/**
		 * @return BWFAN_Filter_Contact_Gender|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_options( $term = '' ) {
			return [
				'male'   => __( 'Male', 'wp-marketing-automations-pro' ),
				'female' => __( 'Female', 'wp-marketing-automations-pro' ),
				'other'  => __( 'Other', 'wp-marketing-automations-pro' ),
			];
		}

		public function get_type() {
			return 'Select';
		}

		public function get_possible_operators() {
			return array(
				'is'     => __( 'is', 'wp-marketing-automations-pro' ),
				'is_not' => __( 'is not', 'wp-marketing-automations-pro' ),
			);
		}

		public function get_join_query( $query = '' ) {

			if ( $this->is_join_exist( $query ) ) {
				return '';
			}

			return " LEFT JOIN {$this->table} AS $this->alias ON $this->base_alias.id = $this->alias.cid";
		}

		public function get_where_query() {
			$field_from_db = BWFAN_Model_Fields::get_field_by_slug( 'gender' );
			if ( empty( $field_from_db ) || ! isset( $field_from_db['ID'] ) ) {
				return '';
			}
			$this->filter['key'] = 'f' . $field_from_db['ID'];

			return $this->prepare_query();
		}

	}

	BWFCRM_Core()->filters->register( 'contact_details', 'BWFAN_Filter_Contact_Gender','gender' );
}
