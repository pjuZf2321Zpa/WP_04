<?php
if ( ! class_exists( 'BWFAN_Filter_Contact_Company' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Contact_Company extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->is_preference  = true;
			$this->name           = __( 'Company', 'wp-marketing-automations-pro' );
			$this->group_name     = __( 'Contact Details', 'wp-marketing-automations-pro' );
			$this->group_priority = 20;
			$this->priority       = 7;
			$this->filter         = $value;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}bwf_contact_fields";
			$this->columns    = [];
			$this->alias      = 'cf';
		}

		/**
		 * @return BWFAN_Filter_Contact_Company|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}


		public function get_type() {
			return 'Text';
		}

		public function get_possible_operators() {
			return array(
				'is'           => __( 'is', 'wp-marketing-automations-pro' ),
				'is_not'       => __( 'is not', 'wp-marketing-automations-pro' ),
				'contains'     => __( 'contains', 'wp-marketing-automations-pro' ),
				'not_contains' => __( 'does not contain', 'wp-marketing-automations-pro' ),
				'starts_with'  => __( 'starts with', 'wp-marketing-automations-pro' ),
				'ends_with'    => __( 'ends with', 'wp-marketing-automations-pro' ),
				'is_blank'     => __( 'is blank', 'wp-marketing-automations-pro' ),
				'is_not_blank' => __( 'is not blank', 'wp-marketing-automations-pro' ),
			);
		}

		public function get_join_query( $query = '' ) {

			if ( $this->is_join_exist( $query ) ) {
				return '';
			}

			return " LEFT JOIN {$this->table} AS $this->alias ON $this->base_alias.id = $this->alias.cid";
		}

		public function get_where_query() {
			$field_from_db = BWFAN_Model_Fields::get_field_by_slug( 'company' );
			if ( empty( $field_from_db ) || ! isset( $field_from_db['ID'] ) ) {
				return '';
			}
			$this->filter['key'] = 'f' . $field_from_db['ID'];

			return $this->prepare_query();
		}

	}

	BWFCRM_Core()->filters->register( 'contact_details', 'BWFAN_Filter_Contact_Company','company' );
}
