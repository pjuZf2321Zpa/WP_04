<?php

if ( ! class_exists( 'BWFAN_Filter_Contact_DOB_Days' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Contact_DOB_Days extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->is_preference = false;
			$this->name          = __( 'Date of Birth (Days)', 'wp-marketing-automations-pro' );
			$this->group_name = __( 'Contact Details', 'wp-marketing-automations-pro' );
			$this->filter     = $value;
			$this->priority   = 10;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}bwf_contact_fields";
			$this->columns    = [];
			$this->alias      = 'cf';
		}

		/**
		 * @return BWFAN_Filter_Contact_DOB_Days|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_type() {
			return 'Days';
		}

		public function get_possible_operators() {
			return array(
				'after'   => __( 'After', 'wp-marketing-automations-pro' ),
				'next'    => __( 'In the next', 'wp-marketing-automations-pro' ),
				'between' => __( 'In the period', 'wp-marketing-automations-pro' ),
			);
		}

		/**
		 * The day count is only meaningful in 0..365: the next birthday is never more than
		 * 365 days away, and a larger value pushes the SQL date literal past year 9999,
		 * which MySQL treats as invalid (BETWEEN then matches nothing instead of everyone).
		 * Mirrored in BWFAN_Rule_Contact_DOB_Days.
		 */
		private function clamp_days( $days ) {
			return max( 0, min( (int) $days, 365 ) );
		}

		/** Input bounds for the React day field; same 0..365 the server enforces in clamp_days(). */
		public function get_extra_props() {
			return [ 'min' => 0, 'max' => 365 ];
		}

		public function get_join_query( $query = '' ) {

			if ( $this->is_join_exist( $query ) ) {
				return '';
			}

			return " LEFT JOIN {$this->table} AS $this->alias ON $this->base_alias.id = $this->alias.cid";
		}

		/**
		 * Compares the number of days until the contact's NEXT birthday (this year if it
		 * hasn't happened yet, otherwise next year) against the entered day count.
		 * Mirrors the After/In the next/In the period semantics of
		 * BWFAN_Filter_Customer_Next_Subscription_Renewal_Days, applied to a computed
		 * "next birthday" date rather than a stored date column.
		 */
		public function get_where_query() {
			global $wpdb;

			$field_from_db = BWFAN_Model_Fields::get_field_by_slug( 'dob' );
			if ( empty( $field_from_db ) || ! isset( $field_from_db['ID'] ) ) {
				return '';
			}
			$this->filter['key'] = 'f' . $field_from_db['ID'];

			$filter_key = $this->sanitize_column_key( $this->filter['key'] );
			if ( '' === $filter_key ) {
				return '';
			}
			/**
			 * Reject only a genuinely absent value. empty() is deliberately avoided here:
			 * it treats the string "0" as empty, and "In the next 0 days" (i.e. the
			 * birthday is today) is a valid query. Returning '' for it would drop the
			 * WHERE clause entirely and silently match the whole audience instead of
			 * just today's birthdays.
			 */
			$value = isset( $this->filter['value'] ) ? $this->filter['value'] : '';
			if ( is_array( $value ) ? empty( $value ) : '' === trim( (string) $value ) ) {
				return '';
			}
			$column = "{$this->alias}.{$filter_key}";

			/** Anchor "today" to the WordPress site timezone. */
			$today     = new DateTime();
			BWFAN_Common::convert_from_gmt( $today );
			$today_ymd = $today->format( 'Y-m-d' );
			$this_year = (int) $today->format( 'Y' );

			$next_year = $this_year + 1;

			/**
			 * Next occurrence of the birthday: this year if not yet passed, else next year.
			 *
			 * '%' is doubled ('%%m-%%d' etc.) because this fragment is embedded in a larger
			 * string later passed through $wpdb->prepare(), which treats a bare '%' as its
			 * own placeholder and silently returns '' when the count doesn't line up.
			 *
			 * The COALESCE handles Feb 29: projecting it onto a non-leap year makes
			 * STR_TO_DATE return NULL, which would silently drop the contact from every
			 * window. Falling back to Mar 1 keeps this identical to the automation rule
			 * (BWFAN_Rule_Contact_DOB_Days), where PHP's DateTime overflows Feb 29 to
			 * Mar 1 the same way. dob is a real DATE column, so '02-29' is the only
			 * month-day that can fail to project.
			 */
			$this_year_birthday = "COALESCE(
				STR_TO_DATE(CONCAT({$this_year}, '-', DATE_FORMAT({$column}, '%%m-%%d')), '%%Y-%%m-%%d'),
				STR_TO_DATE('{$this_year}-03-01', '%%Y-%%m-%%d')
			)";

			$next_year_birthday = "COALESCE(
				STR_TO_DATE(CONCAT({$next_year}, '-', DATE_FORMAT({$column}, '%%m-%%d')), '%%Y-%%m-%%d'),
				STR_TO_DATE('{$next_year}-03-01', '%%Y-%%m-%%d')
			)";

			/**
			 * The "has it happened yet" test compares the PROJECTED date against today, not the raw
			 * month-day. Feb 29 projects onto Mar 1 in a non-leap year, so testing '02-29' >= '03-01'
			 * called the birthday passed on the very day it is observed and pushed it a year out -
			 * on 1 Mar 2027 a Feb 29 contact came back 365 days away instead of 0, dropping them from
			 * every upcoming-birthday window on their own birthday.
			 */
			$next_birthday = "CASE WHEN {$this_year_birthday} >= '{$today_ymd}'
				THEN {$this_year_birthday}
				ELSE {$next_year_birthday}
			END";

			$rule = isset( $this->filter['rule'] ) ? $this->filter['rule'] : '';

			switch ( $rule ) {
				case 'after':
					/**
					 * "After X days" = the next birthday is more than X days away: the exact
					 * complement of "In the next X days" (contacts without a DOB are excluded by
					 * the IS NOT NULL guard below). No calendar-year bound, so "After 30" run in
					 * December wraps into next year the same way "In the period" does. For
					 * calendar-anchored targeting combine with DOB (Month).
					 */
					$cutoff = clone $today;
					$cutoff->modify( '+' . $this->clamp_days( $value ) . ' days' );
					$where = $wpdb->prepare( "( {$next_birthday} ) > %s", $cutoff->format( 'Y-m-d' ) ); //phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $next_birthday holds integer years and a sanitized column name; user values are bound with %s.
					break;

				case 'next':
					$cutoff = clone $today;
					$cutoff->modify( '+' . $this->clamp_days( $value ) . ' days' );
					$where = $wpdb->prepare( "( {$next_birthday} ) BETWEEN %s AND %s", $today_ymd, $cutoff->format( 'Y-m-d' ) ); //phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $next_birthday holds integer years and a sanitized column name; user values are bound with %s.
					break;

				case 'between':
					$from = $this->clamp_days( isset( $value['from'] ) ? $value['from'] : ( isset( $value[0] ) ? $value[0] : 0 ) );
					$to   = $this->clamp_days( isset( $value['to'] ) ? $value['to'] : ( isset( $value[1] ) ? $value[1] : 0 ) );
					if ( $from > $to ) {
						list( $from, $to ) = array( $to, $from );
					}
					$from_date = clone $today;
					$from_date->modify( "+{$from} days" );
					$to_date = clone $today;
					$to_date->modify( "+{$to} days" );
					$where = $wpdb->prepare( "( {$next_birthday} ) BETWEEN %s AND %s", $from_date->format( 'Y-m-d' ), $to_date->format( 'Y-m-d' ) ); //phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $next_birthday holds integer years and a sanitized column name; user values are bound with %s.
					break;

				default:
					return '';
			}

			/**
			 * Never match contacts with an empty Date of Birth. dob is a real DATE column
			 * (not varchar), so comparing it to '' throws under STRICT_TRANS_TABLES -
			 * IS NOT NULL alone is the correct empty-value guard.
			 */
			return "( {$column} IS NOT NULL AND {$where} )";
		}

		public function get_readable_text(){
			return '{{key /}} {{rule /}} {{value /}} ' . __( 'days', 'wp-marketing-automations-pro' );
		}

	}

	BWFCRM_Core()->filters->register( 'contact_details', 'BWFAN_Filter_Contact_DOB_Days', 'dob_days' );
}
