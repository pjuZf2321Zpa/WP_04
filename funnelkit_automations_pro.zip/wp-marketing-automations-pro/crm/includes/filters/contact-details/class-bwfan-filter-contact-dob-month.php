<?php

if ( ! class_exists( 'BWFAN_Filter_Contact_DOB_Month' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Contact_DOB_Month extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->is_preference = false;
			$this->name          = __( 'Date of Birth (Month)', 'wp-marketing-automations-pro' );
			$this->group_name = __( 'Contact Details', 'wp-marketing-automations-pro' );
			$this->filter     = $value;
			$this->priority   = 11;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}bwf_contact_fields";
			$this->columns    = [];
			$this->alias      = 'cf';
		}

		/**
		 * @return BWFAN_Filter_Contact_DOB_Month|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_type() {
			return 'Select';
		}

		public function get_options( $term = '' ) {
			global $wp_locale;

			$options = array();
			for ( $month = 1; $month <= 12; $month ++ ) {
				$options[ (string) $month ] = $wp_locale->get_month( str_pad( $month, 2, '0', STR_PAD_LEFT ) );
			}

			return $options;
		}

		public function get_default_value() {
			return '1';
		}

		public function get_join_query( $query = '' ) {

			if ( $this->is_join_exist( $query ) ) {
				return '';
			}

			return " LEFT JOIN {$this->table} AS $this->alias ON $this->base_alias.id = $this->alias.cid";
		}

		/**
		 * Matches contacts whose Date of Birth falls in the given month (1-12),
		 * ignoring year and day.
		 */
		public function get_where_query() {
			$field_from_db = BWFAN_Model_Fields::get_field_by_slug( 'dob' );
			if ( empty( $field_from_db ) || ! isset( $field_from_db['ID'] ) ) {
				return '';
			}
			$this->filter['key'] = 'f' . $field_from_db['ID'];

			$filter_key = $this->sanitize_column_key( $this->filter['key'] );
			if ( '' === $filter_key ) {
				return '';
			}
			$column = "{$this->alias}.{$filter_key}";

			$month = isset( $this->filter['value'] ) ? absint( $this->filter['value'] ) : 0;
			if ( $month < 1 || $month > 12 ) {
				return '';
			}

			/**
			 * Never match contacts with an empty Date of Birth. dob is a real DATE column
			 * (not varchar), so comparing it to '' throws under STRICT_TRANS_TABLES -
			 * IS NOT NULL alone is the correct empty-value guard.
			 */
			return "( {$column} IS NOT NULL AND MONTH({$column}) = {$month} )";
		}

	}

	BWFCRM_Core()->filters->register( 'contact_details', 'BWFAN_Filter_Contact_DOB_Month', 'dob_month' );
}
