<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BWFAN_Filter_Automation_Email_Click' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Automation_Email_Click extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->name           = __( 'Automation Email Clicked', 'wp-marketing-automations-pro' );
			$this->group_name     = __( 'Automation', 'wp-marketing-automations-pro' );
			$this->group_priority = 90;
			$this->priority       = 5;
			$this->filter         = $value;
			$this->is_preference  = false;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}bwfan_engagement_tracking";
			$this->columns    = [];
			$this->alias      = 'et';
		}

		/**
		 * @return BWFAN_Filter_Automation_Email_Click|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_options( $search = '' ) {
			$automations   = BWFAN_Common::get_automation_by_title( $search, 2, [], 10 );
			$prepared_data = [];
			foreach ( $automations as $automation ) {
				$prepared_data[ $automation['id'] ] = $automation['title'];
			}

			return $prepared_data;
		}

		public function get_type() {
			return 'Search';
		}

		public function get_possible_operators() {
			return [
				'any'  => __( 'matches any of', 'wp-marketing-automations-pro' ),
				'all'  => __( 'matches all of ', 'wp-marketing-automations-pro' ),
				'none' => __( 'matches none of ', 'wp-marketing-automations-pro' ),
			];
		}

		public function get_value_as_key_label( $data ) {
			if ( empty( $data ) ) {
				return [];
			}

			$automation_data   = BWFCRM_Common::get_automation_title_by_ids( $data );
			$automation_titles = array();
			if ( is_array( $automation_data ) ) {
				foreach ( $automation_data as $automation ) {
					if ( isset( $automation['id'], $automation['title'] ) ) {
						$automation_titles[ $automation['id'] ] = $automation['title'];
					}
				}
			}

			$values = [];
			foreach ( $data as $key => $id ) {
				$values[] = [
					'key'   => $id,
					'label' => isset( $automation_titles[ $id ] ) ? $automation_titles[ $id ] : '-'
				];
			}

			return $values;
		}

		public function get_join_query( $query = '' ) {
			return '';
		}

		public function get_where_query() {
			$filter_value = $this->filter['value'];
			$filter_rule  = $this->filter['rule'];

			$status_send     = BWFAN_Email_Conversations::$STATUS_SEND;
			$type_automation = BWFAN_Email_Conversations::$TYPE_AUTOMATION;
			$new_value       = [];
			foreach ( $filter_value as $value ) {
				if ( ! isset( $value['key'] ) ) {
					continue;
				}
				$new_value[] = $value['key'];
			}
			$filter_value = ! empty( $new_value ) ? $new_value : $filter_value;

			if ( ! is_array( $filter_value ) ) {
				$filter_value = array( $filter_value );
			}

			$extra_where = " AND egt.type = $type_automation AND egt.c_status = $status_send AND egt.click > 0";

			return $this->build_exists_query_single_value_column( $filter_value, $filter_rule, 'oid', $extra_where, 'egt' );
		}

	}

	BWFCRM_Core()->filters->register( 'bwf_automation', 'BWFAN_Filter_Automation_Email_Click', 'automation_email_click' );
}
