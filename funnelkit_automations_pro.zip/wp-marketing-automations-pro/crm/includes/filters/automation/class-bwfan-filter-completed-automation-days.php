<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BWFAN_Filter_Completed_Automation_Days' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Completed_Automation_Days extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->name           = __( 'Automation Completed (Days)', 'wp-marketing-automations-pro' );
			$this->group_name     = __( 'Automation', 'wp-marketing-automations-pro' );
			$this->group_priority = 90;
			$this->priority       = 6;
			$this->filter         = $value;
			$this->is_preference  = false;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = 'c';
			$this->table      = "{$wpdb->prefix}bwfan_automation_complete_contact";
			$this->columns    = [];
			$this->alias      = 'acc';
		}

		/**
		 * @return BWFAN_Filter_Completed_Automation_Days|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_type() {
			return 'Days';
		}

		public function get_possible_operators() {
			$operators = [
				'over'        => __( 'Over', 'wp-marketing-automations-pro' ),
				'past'        => __( 'In the past', 'wp-marketing-automations-pro' ),
				'not_past'    => __( 'Not in the last', 'wp-marketing-automations-pro' ),
				'between'     => __( 'In the period', 'wp-marketing-automations-pro' ),
				'not_between' => __( 'Not in the period', 'wp-marketing-automations-pro' ),
			];

			/** 'not_between' needs the Lite 3.8.4 filter-type JS for its dual-input control. */
			if ( ! self::supports_range_negation() ) {
				unset( $operators['not_between'] );
			}

			return $operators;
		}

		public function get_join_query( $query = '' ) {
			return '';
		}

		public function get_where_query() {
			$filter_value = $this->filter['value'];
			$filter_rule  = $this->filter['rule'];

			if ( ! is_array( $filter_value ) ) {
				$filter_value = absint( $filter_value );
				$date         = new DateTime( 'now', wp_timezone() );
				$date->modify( "-$filter_value days" );
				$filter_value = $date->format( 'Y-m-d' );
			} else {
				$from = isset( $filter_value['from'] ) ? intval( $filter_value['from'] ) : intval( $filter_value[0] );
				$to   = isset( $filter_value['to'] ) ? intval( $filter_value['to'] ) : intval( $filter_value[1] );

				$date = new DateTime( 'now', wp_timezone() );
				$date->modify( "-$from days" );
				$from = $date->format( 'Y-m-d' );

				$date = new DateTime( 'now', wp_timezone() );
				$date->modify( "-$to days" );
				$to = $date->format( 'Y-m-d' );

				$filter_value = array( $from, $to );
			}

			$table    = $this->table;
			$base_col = "{$this->base_alias}.id";
			global $wpdb;

			/**
			 * Expand date-only range bounds to full days so DateTime columns are not clipped at midnight,
			 * mirroring prepare_date_query(). Raw column comparison (no DATE() wrap) keeps the lookup index-friendly.
			 */
			$lower_bound = is_array( $filter_value ) ? $filter_value[1] . ' 00:00:00' : '';
			$upper_bound = is_array( $filter_value ) ? $filter_value[0] . ' 23:59:59' : '';

			switch ( $filter_rule ) {
				case 'over':
					return $wpdb->prepare( "(EXISTS (SELECT 1 FROM {$table} AS acc_sub WHERE acc_sub.cid = {$base_col} AND acc_sub.c_date > '0000-00-00 00:00:00') AND NOT EXISTS (SELECT 1 FROM {$table} AS acc_ov WHERE acc_ov.cid = {$base_col} AND DATE(acc_ov.c_date) >= %s))", $filter_value );
				case 'past':
					return $wpdb->prepare( "(EXISTS (SELECT 1 FROM {$table} AS acc_sub WHERE acc_sub.cid = {$base_col} AND DATE(acc_sub.c_date) >= %s))", $filter_value );
				case 'not_past':
					/** Inclusive negation: no completion within the cutoff, including contacts who never completed this automation (no rows). */
					return $wpdb->prepare( "(NOT EXISTS (SELECT 1 FROM {$table} AS acc_sub WHERE acc_sub.cid = {$base_col} AND DATE(acc_sub.c_date) >= %s))", $filter_value );
				case 'between':
					return $wpdb->prepare( "(EXISTS (SELECT 1 FROM {$table} AS acc_sub WHERE acc_sub.cid = {$base_col} AND acc_sub.c_date >= %s AND acc_sub.c_date <= %s))", $lower_bound, $upper_bound );
				case 'not_between':
					/** Inclusive negation: no completion within the period, including contacts who never completed this automation (no rows). */
					return $wpdb->prepare( "(NOT EXISTS (SELECT 1 FROM {$table} AS acc_sub WHERE acc_sub.cid = {$base_col} AND acc_sub.c_date >= %s AND acc_sub.c_date <= %s))", $lower_bound, $upper_bound );
				default:
					return '';
			}
		}

	}

	BWFCRM_Core()->filters->register( 'bwf_automation', 'BWFAN_Filter_Completed_Automation_Days', 'automation_completed_days' );
}
