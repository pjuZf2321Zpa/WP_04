<?php
if ( ! class_exists( 'BWFAN_Filter_Ever_Entered_Automation' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Ever_Entered_Automation extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->name       = __( 'Has ever entered in Automation', 'wp-marketing-automations-pro' );
			$this->group_name = __( 'Automation', 'wp-marketing-automations-pro' );
			$this->filter     = $value;
			$this->priority   = 1;
			$this->is_preference  = false;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}bwf_contact_fields";
			$this->columns    = [];
			$this->alias      = 'cf';
		}

		/**
		 * @return BWFAN_Filter_Ever_Entered_Automation|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_options( $search = '' ) {
			$automations   = BWFAN_Common::get_automation_by_title( $search, 2, [], 10 );
			$prepared_data = [];
			foreach ( $automations as $automation ) {
				$prepared_data[ $automation['id'] ] = $automation['title'];
			}

			return $prepared_data;
		}

		public function get_type() {
			return 'Search';
		}

		public function get_possible_operators() {
			return [
				'any'  => __( 'matches any of', 'wp-marketing-automations-pro' ),
				'all'  => __( 'matches all of ', 'wp-marketing-automations-pro' ),
				'none' => __( 'matches none of ', 'wp-marketing-automations-pro' ),
			];
		}

		public function get_value_as_key_label( $data ) {
			if ( empty( $data ) ) {
				return [];
			}

			$values          = [];
			$automation_data = BWFCRM_Common::get_automation_title_by_ids( $data );
			if ( empty( $automation_data ) ) {
				$data = implode( ', ', $data );
			}
			foreach ( $data as $key => $id ) {
				$values[] = [
					'key'   => $id,
					'label' => isset( $automation_data[ $key ] ) ? $automation_data[ $key ]['title'] : '-'
				];
			}

			return $values;
		}

		public function get_join_query( $query = '' ) {

			if ( $this->is_join_exist( $query ) ) {
				return '';
			}

			return " LEFT JOIN {$this->table} AS $this->alias ON $this->base_alias.id = $this->alias.cid";
		}

		public function get_where_query() {
			$field_from_db = BWFAN_Model_Fields::get_field_by_slug( 'automation-entered' );
			if ( empty( $field_from_db ) || ! isset( $field_from_db['ID'] ) ) {
				return '';
			}

			$this->filter['key'] = 'f' . $field_from_db['ID'];

			return $this->prepare_query_for_json_array();
		}

	}

	BWFCRM_Core()->filters->register( 'bwf_automation', 'BWFAN_Filter_Ever_Entered_Automation', 'automation_entered' );
}
