<?php

if ( ! class_exists( 'BWFAN_Filter_Customer_Has_Purchased' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Customer_Has_Purchased extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->is_preference = true;
			$this->name          = __( 'Has made a purchase', 'wp-marketing-automations-pro' );
			$this->group_name = __( 'WooCommerce', 'wp-marketing-automations-pro' );
			$this->filter     = $value;
			$this->priority   = 1;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}bwf_wc_customers";
			$this->columns    = [];
			$this->alias      = 'wc';
		}

		/**
		 * @return BWFAN_Filter_Customer_Has_Purchased|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		/** v2 Methods: START */
		public function get_options( $term = '' ) {
			return [
				'yes' => __( 'Yes', 'wp-marketing-automations-pro' ),
				'no'  => __( 'No', 'wp-marketing-automations-pro' ),
			];
		}

		public function get_type() {
			return 'Select';
		}

		public function get_possible_operators() {
			return null;
		}

		public function get_join_query( $query = '' ) {

			if ( $this->is_join_exist( $query ) ) {
				return '';
			}

			return " LEFT JOIN {$this->table} AS $this->alias ON $this->base_alias.id = $this->alias.cid";
		}

		public function get_where_query() {
			$this->filter['key'] = 'has_purchased';

			return $this->prepare_query_for_bool();
		}

	}

	if ( bwfan_is_woocommerce_active() ) {
		BWFCRM_Core()->filters->register( 'woocommerce', 'BWFAN_Filter_Customer_Has_Purchased', 'has_purchased' );
	}
}
