<?php

if ( ! class_exists( 'BWFAN_Filter_Customer_Used_Coupons' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Customer_Used_Coupons extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->is_preference = true;
			$this->name          = __( 'Used Coupons', 'wp-marketing-automations-pro' );
			$this->group_name = __( 'WooCommerce', 'wp-marketing-automations-pro' );
			$this->filter     = $value;
			$this->priority   = 9;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}bwf_wc_customers";
			$this->columns    = [];
			$this->alias      = 'wc';
		}

		/**
		 * @return BWFAN_Filter_Customer_Used_Coupons|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_options( $term = '' ) {
			return $this->get_search_results( $term, true );
		}

		public function get_type() {
			return 'Search';
		}

		public function get_possible_operators() {
			return [
				'any'  => __( 'matches any of', 'wp-marketing-automations-pro' ),
				'all'  => __( 'matches all of ', 'wp-marketing-automations-pro' ),
				'none' => __( 'matches none of ', 'wp-marketing-automations-pro' ),
			];
		}

		public function get_search_results( $term, $v2 = false ) {
			$array = BWFAN_Common::get_coupon( $term, 10 );

			if ( $v2 ) {
				$return = array();
				foreach ( $array['results'] as $coupon ) {
					$return[ $coupon['text'] ] = $coupon['text'];
				}

				return $return;
			}
		}

		public function get_value_as_key_label( $data ) {
			if ( empty( $data ) ) {
				return [];
			}
			$value = [];
			foreach ( $data as $id ) {
				$coupon      = new WC_Coupon( $id );
				$coupon_data = $coupon->get_data();
				$value[]     = [
					'key'   => $id,
					'label' => isset( $coupon_data ) ? $coupon_data['code'] : '-',
				];
			}

			return $value;
		}

		public function get_join_query( $query = '' ) {

			if ( $this->is_join_exist( $query ) ) {
				return '';
			}

			return " LEFT JOIN {$this->table} AS $this->alias ON $this->base_alias.id = $this->alias.cid";
		}

		public function get_where_query() {
			$this->filter['key'] = 'used_coupons';

			return $this->prepare_query_for_json_array();
		}

	}

	if ( bwfan_is_woocommerce_active() ) {
		BWFCRM_Core()->filters->register( 'woocommerce', 'BWFAN_Filter_Customer_Used_Coupons', 'used_coupons' );
	}
}
