<?php

if ( ! class_exists( 'BWFAN_Filter_Customer_Purchased_Products' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Customer_Purchased_Products extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->is_preference = true;
			$this->name          = __( 'Purchased Products', 'wp-marketing-automations-pro' );
			$this->group_name = __( 'WooCommerce', 'wp-marketing-automations-pro' );
			$this->filter     = $value;
			$this->priority   = 12;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}bwf_wc_customers";
			$this->columns    = [];
			$this->alias      = 'wc';
		}

		/**
		 * @return BWFAN_Filter_Customer_Purchased_Products|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_options( $term = '' ) {
			return $this->get_search_results( $term, true );
		}

		public function get_type() {
			return 'Search';
		}

		public function get_possible_operators() {
			return [
				'any'  => __( 'matches any of', 'wp-marketing-automations-pro' ),
				'all'  => __( 'matches all of ', 'wp-marketing-automations-pro' ),
				'none' => __( 'matches none of ', 'wp-marketing-automations-pro' ),
			];
		}

		public function get_value_as_key_label( $data ) {
			if ( empty( $data ) ) {
				return [];
			}
			$value = [];
			foreach ( $data as $id ) {
				if ( false !== strpos( $id, ',' ) ) {
					$ids   = explode( ',', $id );
					$value = $this->get_value_as_key_label( $ids );
					continue;
				}
				/** @var WC_Product $product */
				$product = wc_get_product( $id );
				$title   = '-';
				if ( $product instanceof WC_Product ) {
					$title = $product->get_title();
				}
				$value[] = [
					'key'   => $id,
					'label' => $title,
				];
			}

			return $value;
		}

		public function get_search_results( $term, $v2 = false ) {
			BWFAN_Common::$offer_product_types = [
				'simple',
				'variable',
				'variation',
				'subscription',
				'variable-subscription',
				'subscription_variation'
			];

			$array = BWFAN_Common::product_search( $term, true, true );

			if ( $v2 ) {
				$return = array();
				foreach ( $array as $product ) {
					$return[ $product['id'] ] = $product['text'];
				}

				return $return;
			}

			wp_send_json( array(
				'results' => $array,
			) );
		}

		public function get_join_query( $query = '' ) {

			if ( $this->is_join_exist( $query ) ) {
				return '';
			}

			return " LEFT JOIN {$this->table} AS $this->alias ON $this->base_alias.id = $this->alias.cid";
		}

		public function get_where_query() {
			$this->filter['key']   = 'purchased_products';
			$this->filter['value'] = $this->get_product_ids( $this->filter['value'] );
			if ( empty( $this->filter['value'] ) ) {
				return '';
			}

			return $this->prepare_query_for_json_array();
		}

		/**
		 * for older filter
		 *
		 * @param $filter_value
		 *
		 * @return array|bool|mixed[]|null
		 */
		private function get_product_ids( $filter_value ) {

			if ( ! is_array( $filter_value ) || ! isset( $filter_value[0][0] ) || ! is_array( $filter_value[0][0] ) || ! isset( $filter_value[0][0]['key'] ) ) {

				return $filter_value;
			}

			return array_column( $filter_value[0], 'key' );
		}

	}

	if ( bwfan_is_woocommerce_active() ) {
		BWFCRM_Core()->filters->register( 'woocommerce', 'BWFAN_Filter_Customer_Purchased_Products', 'purchased_products' );
	}
}
