<?php

if ( ! class_exists( 'BWFAN_Filter_Customer_Purchased_Cats' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Customer_Purchased_Cats extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->is_preference = true;
			$this->name          = __( 'Purchased Products Categories', 'wp-marketing-automations-pro' );
			$this->group_name = __( 'WooCommerce', 'wp-marketing-automations-pro' );
			$this->filter     = $value;
			$this->priority   = 7;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}bwf_wc_customers";
			$this->columns    = [];
			$this->alias      = 'wc';
		}

		/**
		 * @return BWFAN_Filter_Customer_Purchased_Cats|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_options( $term = '' ) {
			return $this->get_search_results( $term, true );
		}

		public function get_type() {
			return 'Search';
		}

		public function get_possible_operators() {
			return [
				'any'  => __( 'matches any of', 'wp-marketing-automations-pro' ),
				'all'  => __( 'matches all of ', 'wp-marketing-automations-pro' ),
				'none' => __( 'matches none of ', 'wp-marketing-automations-pro' ),
			];
		}

		public function get_search_results( $term, $v2 = false ) {
			$array = [];
			$args  = array(
				'taxonomy'   => array( 'product_cat' ), // taxonomy name
				'orderby'    => 'id',
				'order'      => 'ASC',
				'number'     => 10,
				'hide_empty' => false,
				'fields'     => 'all',
				'name__like' => htmlspecialchars( wp_specialchars_decode( $term, ENT_QUOTES ), ENT_NOQUOTES ),
			);
			/** Lite helper matches both "&" and the stored "&amp;" form; fall back on older Lite */
			$terms = method_exists( 'BWFAN_Common', 'search_terms_by_name' ) ? BWFAN_Common::search_terms_by_name( $args['taxonomy'][0], $term, 10 ) : get_terms( $args );

			if ( $v2 ) {
				if ( count( $terms ) > 0 ) {
					foreach ( $terms as $term ) {
						$array[ $term->term_id ] = wp_specialchars_decode( $term->name, ENT_QUOTES );
					}
				}

				return $array;
			}

			if ( count( $terms ) > 0 ) {
				foreach ( $terms as $term ) {
					$array[] = array(
						'id'   => $term->term_id,
						'text' => wp_specialchars_decode( $term->name, ENT_QUOTES ),
					);
				}
			}

			wp_send_json( array(
				'results' => $array,
			) );
		}

		public function get_value_as_key_label( $data ) {
			if ( empty( $data ) ) {
				return [];
			}
			$value = [];
			foreach ( $data as $id ) {
				$term    = get_term_by( 'id', $id, 'product_cat' );
				$value[] = [
					'key'   => $id,
					'label' => isset( $term->name ) ? wp_specialchars_decode( $term->name, ENT_QUOTES ) : '-',
				];
			}

			return $value;
		}

		public function get_join_query( $query = '' ) {

			if ( $this->is_join_exist( $query ) ) {
				return '';
			}

			return " LEFT JOIN {$this->table} AS $this->alias ON $this->base_alias.id = $this->alias.cid";
		}

		public function get_where_query() {
			$this->filter['key'] = 'purchased_products_cats';

			return $this->prepare_query_for_json_array();
		}

	}

	if ( bwfan_is_woocommerce_active() ) {
		BWFCRM_Core()->filters->register( 'woocommerce', 'BWFAN_Filter_Customer_Purchased_Cats', 'purchased_products_cats' );
	}
}
