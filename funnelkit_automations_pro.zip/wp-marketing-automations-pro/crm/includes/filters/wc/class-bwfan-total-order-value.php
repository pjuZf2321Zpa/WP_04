<?php

if ( ! class_exists( 'BWFAN_Filter_Customer_Total_Spent' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Customer_Total_Spent extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->is_preference = true;
			$this->name          = __( 'Total Revenue', 'wp-marketing-automations-pro' );
			$this->group_name = __( 'WooCommerce', 'wp-marketing-automations-pro' );
			$this->filter     = $value;
			$this->priority   = 11;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}bwf_wc_customers";
			$this->columns    = [];
			$this->alias      = 'wc';
		}

		/**
		 * @return BWFAN_Filter_Customer_Total_Spent|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_type() {
			return 'Number';
		}

		public function get_value_label() {
			return get_woocommerce_currency_symbol();
		}

		public function get_possible_operators() {
			return [
				'less_than'       => __( 'less than', 'wp-marketing-automations-pro' ),
				'more_than'       => __( 'more than', 'wp-marketing-automations-pro' ),
				'more_than_equal' => __( 'more than equal', 'wp-marketing-automations-pro' ),
				'less_than_equal' => __( 'less than equal', 'wp-marketing-automations-pro' ),
			];
		}

		public function get_join_query( $query = '' ) {

			if ( $this->is_join_exist( $query ) ) {
				return '';
			}

			return " LEFT JOIN {$this->table} AS $this->alias ON $this->base_alias.id = $this->alias.cid";
		}

		public function get_where_query() {
			$this->filter['key'] = 'total_order_value';

			return $this->prepare_query_for_number();
		}

	}

	if ( bwfan_is_woocommerce_active() ) {
		BWFCRM_Core()->filters->register( 'woocommerce', 'BWFAN_Filter_Customer_Total_Spent', 'total_order_value' );
	}
}
