<?php

if ( ! class_exists( 'BWFAN_Filter_Engaged' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Engaged extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->name           = __( 'Engaged', 'wp-marketing-automations-pro' );
			$this->group_name     = __( 'Engagement', 'wp-marketing-automations-pro' );
			$this->group_priority = 75;
			$this->priority       = 1;
			$this->filter         = $value;
			$this->is_preference = false;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}bwf_contact_fields";
			$this->columns    = [];
			$this->alias      = 'cf';
		}

		/**
		 * @return BWFAN_Filter_Engaged|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_type() {
			return 'Days';
		}

		public function get_possible_operators() {
			$operators = array(
				'over'        => __( 'Over', 'wp-marketing-automations-pro' ),
				'past'        => __( 'In the past', 'wp-marketing-automations-pro' ),
				'not_past'    => __( 'Not in the last', 'wp-marketing-automations-pro' ),
				'between'     => __( 'In the period', 'wp-marketing-automations-pro' ),
				'not_between' => __( 'Not in the period', 'wp-marketing-automations-pro' ),
			);

			/** 'not_between' needs the Lite 3.8.4 filter-type JS for its dual-input control. */
			if ( ! self::supports_range_negation() ) {
				unset( $operators['not_between'] );
			}

			return $operators;
		}

		public function get_join_query( $query = '' ) {

			if ( $this->is_join_exist( $query ) ) {
				return '';
			}

			return " LEFT JOIN {$this->table} AS $this->alias ON $this->base_alias.id = $this->alias.cid";
		}

		public function get_where_query() {
			$filter_value = $this->filter['value'];
			$filter_rule  = $this->filter['rule'];

			/** Get Last Sent & Last Open */
			$last_sent  = BWFAN_Model_Fields::get_field_by_slug( 'last-sent' );
			$last_open  = BWFAN_Model_Fields::get_field_by_slug( 'last-open' );
			$last_click = BWFAN_Model_Fields::get_field_by_slug( 'last-click' );
			if ( empty( $last_sent ) || ! isset( $last_sent['ID'] ) || empty( $last_open ) || ! isset( $last_open['ID'] ) || empty( $last_click ) || ! isset( $last_click['ID'] ) ) {
				return '';
			}

			if ( ! is_array( $filter_value ) ) {
				$filter_value = absint( $filter_value );
				$date         = new DateTime( 'now', wp_timezone() );
				$date->modify( "-$filter_value days" );
				$filter_value = $date->format( 'Y-m-d' );
			} else {
				$from = isset( $filter_value['from'] ) ? intval( $filter_value['from'] ) : absint( $filter_value[0] );
				$date = new DateTime( 'now', wp_timezone() );
				$date->modify( "-$from days" );
				$from = $date->format( 'Y-m-d' );

				$to   = isset( $filter_value['to'] ) ? intval( $filter_value['to'] ) : absint( $filter_value[1] );
				$date = new DateTime( 'now', wp_timezone() );
				$date->modify( "-$to days" );
				$to = $date->format( 'Y-m-d' );

				$filter_value = array( $from, $to );
			}

			switch ( $filter_rule ) {
				case 'over':
					$filter_rule = '<';
					break;
				case 'past':
				case 'not_past':
					$filter_rule = '>=';
					break;
				case 'between':
				case 'not_between':
					$filter_rule = 'between';
					break;
			}

			if ( ! in_array( $filter_rule, array( '<', '>=', 'between' ), true ) ) {
				return '';
			}

			$last_sent  = 'f' . $last_sent['ID'];
			$last_open  = 'f' . $last_open['ID'];
			$last_click = 'f' . $last_click['ID'];
			$open_col   = "$this->alias.$last_open";
			$click_col  = "$this->alias.$last_click";
			$sent_set   = "$this->alias.$last_sent IS NOT NULL";
			$sent_null  = "$this->alias.$last_sent IS NULL";
			global $wpdb;

			/** Over and Past rule */
			if ( ! is_array( $filter_value ) ) {
				if ( 'not_past' === $this->filter['rule'] ) {
					/** Not engaged in the last X days: never sent, OR neither opened nor clicked within the cutoff (incl. never opened/clicked) — full complement of "engaged". */
					$open_not  = $wpdb->prepare( "($open_col < %s OR $open_col IS NULL)", $filter_value );
					$click_not = $wpdb->prepare( "($click_col < %s OR $click_col IS NULL)", $filter_value );

					return "($sent_null OR ( $open_not AND $click_not ))";
				}

				return $wpdb->prepare( "($sent_set AND ( $open_col $filter_rule %s OR $click_col $filter_rule %s ))", $filter_value, $filter_value );
			}

			/**
			 * Between Rule.
			 * Expand date-only range bounds to full days so DateTime columns are not clipped at midnight,
			 * mirroring prepare_date_query() — keeps same-day records and aligns with the rule engine (System B).
			 */
			$lower_bound = $filter_value[1] . ' 00:00:00';
			$upper_bound = $filter_value[0] . ' 23:59:59';

			if ( 'not_between' === $this->filter['rule'] ) {
				/** Not engaged in the period: never sent, OR neither opened nor clicked within the period (incl. never opened/clicked) — full complement of "engaged". */
				$open_not  = $wpdb->prepare( "($open_col < %s OR $open_col > %s OR $open_col IS NULL)", $lower_bound, $upper_bound );
				$click_not = $wpdb->prepare( "($click_col < %s OR $click_col > %s OR $click_col IS NULL)", $lower_bound, $upper_bound );

				return "($sent_null OR ( $open_not AND $click_not ))";
			}

			$last_open  = $wpdb->prepare( "( $open_col >= %s AND $open_col <= %s)", $lower_bound, $upper_bound );
			$last_click = $wpdb->prepare( "( $click_col >= %s AND $click_col <= %s)", $lower_bound, $upper_bound );

			return "($sent_set AND ( $last_open OR $last_click ))";
		}

	}

	BWFCRM_Core()->filters->register( 'engagement', 'BWFAN_Filter_Engaged', 'engaged' );
}
