<?php

if ( ! class_exists( 'BWFAN_Filter_Unengaged' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Unengaged extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->name       = __( 'Unengaged', 'wp-marketing-automations-pro' );
			$this->group_name = __( 'Engagement', 'wp-marketing-automations-pro' );
			$this->filter     = $value;
			$this->priority   = 2;
			$this->is_preference  = false;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}bwf_contact_fields";
			$this->columns    = [];
			$this->alias      = 'cf';
		}

		/**
		 * @return BWFAN_Filter_Unengaged|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_type() {
			return 'Days';
		}

		public function get_possible_operators() {
			return array(
				'from' => __( 'from', 'wp-marketing-automations-pro' ),
			);
		}

		public function get_join_query( $query = '' ) {

			if ( $this->is_join_exist( $query ) ) {
				return '';
			}

			return " LEFT JOIN {$this->table} AS $this->alias ON $this->base_alias.id = $this->alias.cid";
		}

		public function get_where_query() {
			$filter_value = $this->filter['value'];

			/** Get Last Sent & Last Open */
			$last_sent = BWFAN_Model_Fields::get_field_by_slug( 'last-sent' );
			$last_open = BWFAN_Model_Fields::get_field_by_slug( 'last-open' );
			if ( empty( $last_sent ) || ! isset( $last_sent['ID'] ) || empty( $last_open ) || ! isset( $last_open['ID'] ) ) {
				return '';
			}

			$last_sent = 'f' . $last_sent['ID'];
			$last_open = 'f' . $last_open['ID'];

			$current_time = current_time( 'timestamp' );
			$past_time    = $current_time - ( DAY_IN_SECONDS * absint( $filter_value ) );
			$past_time    = date( 'Y-m-d', $past_time );
			global $wpdb;

			return $wpdb->prepare( "($this->alias.$last_sent IS NOT NULL AND ($this->alias.$last_open IS NULL OR $this->alias.$last_open < %s))", $past_time );
		}

	}

	BWFCRM_Core()->filters->register( 'engagement', 'BWFAN_Filter_Unengaged', 'unengaged' );
}