<?php

if ( ! class_exists( 'BWFAN_Filter_Link_Trigger_Clicked' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Link_Trigger_Clicked extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->is_preference = true;
			$this->name          = __( 'Link Triggered', 'wp-marketing-automations-pro' );
			$this->group_name = __( 'Engagement', 'wp-marketing-automations-pro' );
			$this->filter     = $value;
			$this->priority   = 3;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}bwf_contact_fields";
			$this->columns    = [];
			$this->alias      = 'cf';
		}

		/**
		 * @return BWFAN_Filter_Link_Trigger_Clicked|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}


		public function get_type() {
			return 'Search';
		}

		public function get_options( $term = '' ) {
			return $this->get_search_results( $term );
		}

		public function get_search_results( $term ) {
			$link_triggers = BWFAN_Model_Link_Triggers::get_link_triggers( $term, '', 10 );

			$return = array();
			foreach ( $link_triggers['links'] as $link ) {
				$return[ $link['ID'] ] = $link['title'];
			}

			return $return;
		}

		public function get_value_as_key_label( $data ) {
			if ( empty( $data ) ) {
				return [];
			}

			$values    = [];
			$link_data = BWFAN_Model_Link_Triggers::get_link_triggers( '', '', 0, 0, false, $data );
			if ( empty( $link_data ) ) {
				$data = implode( ', ', $data );
			}
			$link_data_map = array_column( $link_data['links'], 'title', 'ID' );
			foreach ( $data as $item ) {
				$values[] = [
					'key'   => $item,
					'label' => $link_data_map[ $item ] ?? '-'
				];
			}

			return $values;
		}

		public function get_possible_operators() {
			return [
				'any'  => __( 'matches any of', 'wp-marketing-automations-pro' ),
				'all'  => __( 'matches all of ', 'wp-marketing-automations-pro' ),
				'none' => __( 'matches none of ', 'wp-marketing-automations-pro' ),
			];
		}

		public function get_join_query( $query = '' ) {

			if ( $this->is_join_exist( $query ) ) {
				return '';
			}

			return " LEFT JOIN {$this->table} AS $this->alias ON $this->base_alias.id = $this->alias.cid";
		}

		public function get_where_query() {
			$field_from_db = BWFAN_Model_Fields::get_field_by_slug( 'link-trigger-click' );
			if ( empty( $field_from_db ) || ! isset( $field_from_db['ID'] ) ) {
				return '';
			}
			$this->filter['key'] = 'f' . $field_from_db['ID'];

			return $this->prepare_query_for_json_array();
		}

	}

	BWFCRM_Core()->filters->register( 'engagement', 'BWFAN_Filter_Link_Trigger_Clicked', 'links' );
}
