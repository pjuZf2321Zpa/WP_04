<?php

if ( ! class_exists( 'BWFAN_Filter_Active_Subscription_Count' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Active_Subscription_Count extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->is_preference = true;
			$this->name          = __( 'Active Subscription Count', 'wp-marketing-automations-pro' );
			$this->group_name    = __( 'WC Subscription', 'wp-marketing-automations-pro' );
			$this->filter        = $value;
			$this->priority      = 5;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}bwfan_wcs_subscriber";
			$this->columns    = [];
			$this->alias      = 'wcs';
		}

		/**
		 * @return BWFAN_Filter_Active_Subscription_Count|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_type() {
			return 'Number';
		}

		public function get_possible_operators() {
			return [
				'is'              => __( 'is', 'wp-marketing-automations-pro' ),
				'is_not'          => __( 'is not', 'wp-marketing-automations-pro' ),
				'less_than'       => __( 'less than', 'wp-marketing-automations-pro' ),
				'more_than'       => __( 'more than', 'wp-marketing-automations-pro' ),
				'more_than_equal' => __( 'more than equal', 'wp-marketing-automations-pro' ),
				'less_than_equal' => __( 'less than equal', 'wp-marketing-automations-pro' ),
			];
		}

		public function get_join_query( $query = '' ) {

			if ( $this->is_join_exist( $query ) ) {
				return '';
			}

			return " LEFT JOIN {$this->table} AS $this->alias ON $this->base_alias.id = $this->alias.cid";
		}

		public function get_where_query() {
			$this->filter['key'] = 'active_subs_count';

			return $this->prepare_query_for_number();
		}

	}

	if ( bwfan_is_woocommerce_subscriptions_active() && class_exists( 'BWFCRM_WCS_Handler' ) ) {
		BWFCRM_Core()->filters->register( 'wc_subscription', 'BWFAN_Filter_Active_Subscription_Count', 'active_subs_count' );
	}
}
