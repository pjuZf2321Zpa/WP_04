<?php

if ( ! class_exists( 'BWFAN_Filter_Active_Subscription_Products' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Active_Subscription_Products extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->is_preference = true;
			$this->name          = __( 'Active Subscription Products', 'wp-marketing-automations-pro' );
			$this->group_name = __( 'WC Subscription', 'wp-marketing-automations-pro' );
			$this->filter     = $value;
			$this->priority   = 12;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}bwfan_wcs_subscriber";
			$this->columns    = [];
			$this->alias      = 'wcs';
		}

		/**
		 * @return BWFAN_Filter_Active_Subscription_Products|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_options( $search = '' ) {
			/*** Filter hook to modify product type */
			$product_types         = apply_filters( 'bwfan_subscription_product_types', array( 'subscription', 'variable-subscription' ) );
			$subscription_products = get_posts( array(
				'post_type'      => 'product',
				'posts_per_page' => 10,
				's'              => $search,
				'tax_query'      => array(
					array(
						'taxonomy' => 'product_type',
						'field'    => 'slug',
						'terms'    => $product_types,
					),
				),
			) );

			$product_array = array();

			foreach ( $subscription_products as $product_post ) {
				$product                            = wc_get_product( $product_post->ID );
				$product_array[ $product_post->ID ] = strip_tags( $product->get_formatted_name() );
				if ( in_array( $product->get_type(), array( 'variable', 'variable-subscription' ), true ) ) {
					$variations = $product->get_children();
					foreach ( $variations as $variation_id ) {
						$variation = wc_get_product( $variation_id );

						$product_array[ $variation->get_id() ] = strip_tags( $variation->get_formatted_name() );
					}
				}
			}

			return $product_array;
		}

		public function get_type() {
			return 'Search';
		}

		public function get_possible_operators() {
			return [
				'any'  => __( 'matches any of', 'wp-marketing-automations-pro' ),
				'all'  => __( 'matches all of ', 'wp-marketing-automations-pro' ),
				'none' => __( 'matches none of ', 'wp-marketing-automations-pro' ),
			];
		}

		public function get_join_query( $query = '' ) {

			if ( $this->is_join_exist( $query ) ) {
				return '';
			}

			return " LEFT JOIN {$this->table} AS $this->alias ON $this->base_alias.id = $this->alias.cid";
		}

		public function get_where_query() {
			$this->filter['key'] = 'active_subs_product';
			if ( empty( $this->filter['value'] ) ) {
				return '';
			}

			return $this->prepare_query_for_json_array();
		}

	}

	if ( bwfan_is_woocommerce_subscriptions_active() && class_exists( 'BWFCRM_WCS_Handler' ) ) {
		BWFCRM_Core()->filters->register( 'wc_subscription', 'BWFAN_Filter_Active_Subscription_Products', 'active_subs_product' );
	}
}
