<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BWFAN_Filter_Has_Bought_Subscription' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Has_Bought_Subscription extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->is_preference  = false;
			$this->name           = __( 'Has Bought Subscription', 'wp-marketing-automations-pro' );
			$this->group_name     = __( 'WC Subscription', 'wp-marketing-automations-pro' );
			$this->group_priority = 70;
			$this->filter         = $value;
			$this->priority       = 5;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}bwfan_wcs_subscriber";
			$this->columns    = [];
			$this->alias      = 'wcs';
		}

		/**
		 * @return BWFAN_Filter_Has_Bought_Subscription|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		/** v2 Methods: START */
		public function get_options( $term = '' ) {
			return [
				'yes' => __( 'Yes', 'wp-marketing-automations-pro' ),
				'no'  => __( 'No', 'wp-marketing-automations-pro' ),
			];
		}

		public function get_type() {
			return 'Select';
		}

		public function get_possible_operators() {
			return null;
		}

		public function get_join_query( $query = '' ) {

			if ( $this->is_join_exist( $query ) ) {
				return '';
			}

			return " LEFT JOIN {$this->table} AS $this->alias ON $this->base_alias.id = $this->alias.cid";
		}

		public function get_where_query() {
			$this->filter['key'] = 'has_bought_subscription';

			return $this->prepare_query_for_bool();
		}

	}

	if ( bwfan_is_woocommerce_subscriptions_active() && class_exists( 'BWFCRM_WCS_Handler' ) ) {
		BWFCRM_Core()->filters->register( 'wc_subscription', 'BWFAN_Filter_Has_Bought_Subscription', 'has_bought_subscription' );
	}
}
