<?php
if ( ! class_exists( 'BWFAN_Filter_Customer_Last_Subscription_Days' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Customer_Last_Subscription_Days extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->is_preference = true;
			$this->name          = __( 'Last Subscription Days', 'wp-marketing-automations-pro' );
			$this->group_name = __( 'WC Subscription', 'wp-marketing-automations-pro' );
			$this->filter     = $value;
			$this->priority   = 5;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}bwfan_wcs_subscriber";
			$this->columns    = [];
			$this->alias      = 'wcs';
		}

		/**
		 * @return BWFAN_Filter_Customer_Last_Subscription_Days|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_type() {
			return 'Days';
		}

		public function get_possible_operators() {
			$operators = [
				'over'        => __( 'Over', 'wp-marketing-automations-pro' ),
				'past'        => __( 'In the past', 'wp-marketing-automations-pro' ),
				'not_past'    => __( 'Not in the last', 'wp-marketing-automations-pro' ),
				'between'     => __( 'In the period', 'wp-marketing-automations-pro' ),
				'not_between' => __( 'Not in the period', 'wp-marketing-automations-pro' ),
			];

			/** 'not_between' needs the Lite 3.8.4 filter-type JS for its dual-input control. */
			if ( ! self::supports_range_negation() ) {
				unset( $operators['not_between'] );
			}

			return $operators;
		}

		public function get_join_query( $query = '' ) {

			if ( $this->is_join_exist( $query ) ) {
				return '';
			}

			return " LEFT JOIN {$this->table} AS $this->alias ON $this->base_alias.id = $this->alias.cid";
		}

		public function get_where_query() {
			$this->filter['key'] = 'l_order_date';

			return $this->prepare_date_query();
		}

	}

	if ( bwfan_is_woocommerce_subscriptions_active() && class_exists( 'BWFCRM_WCS_Handler' ) ) {
		BWFCRM_Core()->filters->register( 'wc_subscription', 'BWFAN_Filter_Customer_Last_Subscription_Days', 'l_subscription_days' );
	}
}
