<?php

if ( ! class_exists( 'BWFAN_Filter_Customer_Next_Subscription_Renewal_Date' ) ) {
	#[AllowDynamicProperties]
	class BWFAN_Filter_Customer_Next_Subscription_Renewal_Date extends BWFAN_Filter_Base {
		public static $ins = null;

		public function __construct( $value = [] ) {
			$this->is_preference = true;
			$this->name          = __( 'Next Subscription Renewal Date', 'wp-marketing-automations-pro' );
			$this->group_name = __( 'WC Subscription', 'wp-marketing-automations-pro' );
			$this->filter     = $value;
			$this->priority   = 6;

			global $wpdb;
			$this->base_table = "{$wpdb->prefix}bwf_contact";
			$this->base_alias = "c";
			$this->table      = "{$wpdb->prefix}bwfan_wcs_subscriber";
			$this->columns    = [];
			$this->alias      = 'wcs';
		}

		/**
		 * @return BWFAN_Filter_Customer_Next_Subscription_Renewal_Date|mixed|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_type() {
			return 'Date';
		}

		public function get_possible_operators() {
			return array(
				'before'  => __( 'Before', 'wp-marketing-automations-pro' ),
				'after'   => __( 'After', 'wp-marketing-automations-pro' ),
				'is'      => __( 'On', 'wp-marketing-automations-pro' ),
				'between' => __( 'Between', 'wp-marketing-automations-pro' ),
			);
		}

		public function get_join_query( $query = '' ) {

			if ( $this->is_join_exist( $query ) ) {
				return '';
			}

			return " LEFT JOIN {$this->table} AS $this->alias ON $this->base_alias.id = $this->alias.cid";
		}

		public function get_where_query() {
			$this->filter['key'] = 'next_renewal_date';

			return $this->get_date_filter_sql();
		}

	}

	if ( bwfan_is_woocommerce_subscriptions_active() && class_exists( 'BWFCRM_WCS_Handler' ) ) {
		BWFCRM_Core()->filters->register( 'wc_subscription', 'BWFAN_Filter_Customer_Next_Subscription_Renewal_Date', 'next_renewal_date' );
	}
}
