<?php
namespace DiviBooster;

if ( !class_exists('\DiviBooster\Puc_v4p10_DebugBar_ThemePanel', false) ):

	class Puc_v4p10_DebugBar_ThemePanel extends Puc_v4p10_DebugBar_Panel {
		/**
		 * @var Puc_v4p10_Theme_UpdateChecker
		 */
		protected $updateChecker;

		protected function displayConfigHeader() {
			$this->row('Theme directory', esc_html($this->updateChecker->directoryName));
			parent::displayConfigHeader();
		}

		protected function getUpdateFields() {
			return array_merge(parent::getUpdateFields(), array('details_url'));
		}
	}

endif;
