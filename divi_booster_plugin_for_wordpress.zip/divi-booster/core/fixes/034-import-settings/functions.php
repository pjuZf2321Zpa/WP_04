<?php
if (!defined('ABSPATH')) { exit(); } // No direct access

/* Ensure gzdecode exists */
if (!function_exists("gzdecode")) {
	function gzdecode($data) { return gzinflate(substr($data,10,-8)); } 
}

/**
 * Run the import only after WordPress is fully initialized for admin requests.
 * (This fix file is included very early, before pluggable functions are available.)
 */
function db034_handle_settings_import() {
	// Check for settings file import attempt
	if ( empty($_FILES['uploaded_file']) || ! isset($_FILES['uploaded_file']['error']) || $_FILES['uploaded_file']['error'] != 0 ) {
		return;
	}

	// Permission hardening
	if ( ! function_exists('is_admin') || ! is_admin() ) { wp_die(__("You do not have permission to access this page.")); }
	// pluggable.php functions may not be loaded in some edge cases; fail closed.
	if ( ! function_exists('is_user_logged_in') || ! function_exists('current_user_can') || ! function_exists('auth_redirect') ) {
		wp_die(__("Security check failed. Please try again."));
	}
	if ( ! is_user_logged_in() ) { auth_redirect(); exit; }
	if ( ! current_user_can('manage_options') ) { wp_die(__("You do not have permission to access this page.")); }

	// CSRF protection: require a nonce sent from the settings form
	if ( empty($_POST['wtfdivi034_import_nonce']) || ! function_exists('wp_verify_nonce') || ! wp_verify_nonce( sanitize_text_field( wp_unslash($_POST['wtfdivi034_import_nonce']) ), 'wtfdivi034_import_settings' ) ) {
		wp_die(__("Security check failed. Please try again."));
	}

	$filename = basename($_FILES['uploaded_file']['name']);
	$ext = substr($filename, strrpos($filename, '.') + 1);

	// Validate upload basics
	if ( ! isset($_FILES['uploaded_file']['tmp_name']) || ! is_uploaded_file($_FILES['uploaded_file']['tmp_name']) ) {
		wp_die("A problem occurred during file upload. Please try again.");
	}

	// Check file extension only; don't trust client-provided mime type
	$file_size = isset($_FILES['uploaded_file']['size']) ? (int) $_FILES['uploaded_file']['size'] : 0;
	if ( ($ext === 'conf') && ($file_size > 0) && ($file_size < 1000000) ) {

		$newname = function_exists('wp_tempnam') ? wp_tempnam('wtfdivi-tmp.conf') : (get_temp_dir() . 'wtfdivi-tmp.conf');
		if ( empty($newname) ) {
			wp_die("A problem occurred during file upload. Please try again.");
		}

		// Attempt to move the uploaded file to its new place
		if ( (move_uploaded_file($_FILES['uploaded_file']['tmp_name'], $newname)) ) {

			$raw = file_get_contents($newname);
			@unlink($newname);
			if ( $raw === false || $raw === '' ) {
				wp_die("File is not recognized as a valid settings file");
			}

			$decoded = @gzdecode($raw);
			if ( ! is_string($decoded) || $decoded === '' ) {
				wp_die("File is not recognized as a valid settings file");
			}

			// Only allow arrays; reject objects / other types.
			// Use allowed_classes=false to prevent object injection.
			$newoption = @unserialize($decoded, array('allowed_classes' => false));
			if ( ! is_array($newoption) ) {
				wp_die("File is not recognized as a valid settings file");
			}

			update_option('wtfdivi', $newoption);
			$redirect_url = add_query_arg('settings-updated', 'true', dbdb_settings_page_url());
			if ( function_exists('wp_safe_redirect') ) {
				wp_safe_redirect( esc_url_raw( $redirect_url ) );
			} else {
				header('Location: ' . esc_url_raw( $redirect_url ));
			}
			exit;

		} else {
			wp_die("A problem occurred during file upload. Please try again.");
		}

	} else {
		wp_die("File is not recognized as a valid settings file");
	}
}

if ( function_exists('add_action') ) {
	add_action('admin_init', 'db034_handle_settings_import');
}
?>