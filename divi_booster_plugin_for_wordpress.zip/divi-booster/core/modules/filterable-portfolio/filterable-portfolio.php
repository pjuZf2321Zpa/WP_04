<?php

namespace DiviBooster\DiviBooster\Modules\FilterablePortfolio;

include_once(dirname(__FILE__) . '/features/active-tab/active-tab.php');
include_once(dirname(__FILE__) . '/features/tab-order/tab-order.php');
include_once(dirname(__FILE__) . '/features/all-tab-position/all-tab-position.php');