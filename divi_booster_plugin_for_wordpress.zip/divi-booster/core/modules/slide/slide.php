<?php

namespace DiviBooster\DiviBooster\Modules\Slide;

include_once(dirname(__FILE__) . '/features/second-button/second-button.php');
include_once(dirname(__FILE__) . '/features/link-slide-title/link-slide-title.php');