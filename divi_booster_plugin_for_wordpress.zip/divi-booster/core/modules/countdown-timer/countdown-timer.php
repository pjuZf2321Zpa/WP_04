<?php

namespace DiviBooster\DiviBooster\Modules\CountdownTimer;

include_once(dirname(__FILE__) . '/features/custom-labels/custom-labels.php');