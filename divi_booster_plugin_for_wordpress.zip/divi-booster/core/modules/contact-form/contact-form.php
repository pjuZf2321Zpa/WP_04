<?php

namespace DiviBooster\DiviBooster\Modules\ContactForm;

include_once(dirname(__FILE__) . '/features/confirmation-email/confirmation-email.php');
include_once(dirname(__FILE__) . '/features/email-blacklist/email-blacklist.php');