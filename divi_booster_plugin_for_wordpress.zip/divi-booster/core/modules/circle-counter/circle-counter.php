<?php

namespace DiviBooster\DiviBooster\Modules\CircleCounter;

if (!is_plugin_active('circle-counter-module-text-before-number/circle-counter-module-text-before-number.php')) {
    include_once(dirname(__FILE__) . '/features/text-before-number/text-before-number.php');
}
