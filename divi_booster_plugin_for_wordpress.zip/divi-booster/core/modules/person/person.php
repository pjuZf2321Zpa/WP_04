<?php

namespace DiviBooster\DiviBooster\Modules\Person;

include_once(dirname(__FILE__) . '/features/website-icon/website-icon.php');
include_once(dirname(__FILE__) . '/features/email-address/email-address.php');
include_once(dirname(__FILE__) . '/features/phone-number/phone-number.php');
include_once(dirname(__FILE__) . '/features/instagram-icon/instagram-icon.php');
include_once(dirname(__FILE__) . '/features/link-target/link-target.php');

add_action('wp_enqueue_scripts', __NAMESPACE__ . '\\enqueue_divi5_builder_preview_script');
function enqueue_divi5_builder_preview_script() {
    if ((!function_exists('et_builder_d5_enabled') || !\et_builder_d5_enabled()) ||
        (!function_exists('et_core_is_fb_enabled') || !\et_core_is_fb_enabled())) {
        return;
    }

    if (!function_exists('dbdb_enqueue_inline_script_if_dependencies_available')) {
        return;
    }

    $handle = sanitize_title('divi-booster-divi-team-member-preview');
    \dbdb_enqueue_inline_script_if_dependencies_available(
        $handle,
        get_divi5_builder_preview_js(),
        array(array('divi-vendor-wp-hooks', 'wp-hooks')),
        'after',
        array('divi-module-library')
    );
}

function get_divi5_builder_preview_js() {
    return <<<'JS'
(function(){
    if (typeof window === 'undefined' || typeof document === 'undefined') return;

    var hooks = window.vendor && window.vendor.wp && window.vendor.wp.hooks;
    if (!hooks || typeof hooks.addFilter !== 'function') return;

    var moduleValuesById = window._diviBoosterPersonPreviewValuesById || {};
    window._diviBoosterPersonPreviewValuesById = moduleValuesById;

    var moduleObserversById = window._diviBoosterPersonPreviewObserversById || {};
    window._diviBoosterPersonPreviewObserversById = moduleObserversById;

    var moduleRootsById = window._diviBoosterPersonPreviewRootsById || {};
    window._diviBoosterPersonPreviewRootsById = moduleRootsById;

    var queuedModuleIds = {};
    var rafId = 0;

    function requestNextFrame(callback) {
        return typeof window.requestAnimationFrame === 'function' ? window.requestAnimationFrame(callback) : window.setTimeout(callback, 16);
    }

    function getAttrValue(attrs, slug, fallback) {
        var raw = attrs && attrs[slug];
        if (!raw) return fallback || '';

        if (raw.desktop && typeof raw.desktop.value !== 'undefined') {
            return raw.desktop.value || fallback || '';
        }

        if (raw.innerContent && raw.innerContent.desktop && typeof raw.innerContent.desktop.value !== 'undefined') {
            return raw.innerContent.desktop.value || fallback || '';
        }

        if (typeof raw.value !== 'undefined') {
            return raw.value || fallback || '';
        }

        if (raw.innerContent && typeof raw.innerContent.value !== 'undefined') {
            return raw.innerContent.value || fallback || '';
        }

        return fallback || '';
    }

    function normalizeUrl(url) {
        url = String(url || '').trim();
        if (!url) return '';
        return /^[a-z][a-z0-9+.-]*:/i.test(url) ? url : 'http://' + url;
    }

    function getModuleElement(moduleId) {
        if (!moduleId) return null;

        var id = String(moduleId);
        var selector = '[data-id="' + (window.CSS && window.CSS.escape ? window.CSS.escape(id) : id.replace(/"/g, '\\"')) + '"]';

        try {
            return document.querySelector(selector);
        } catch (e) {
            var elements = document.querySelectorAll('[data-id]');
            for (var i = 0; i < elements.length; i++) {
                if (elements[i].getAttribute('data-id') === id) {
                    return elements[i];
                }
            }
        }

        return null;
    }

    function getTeamMemberElement(moduleElement) {
        if (!moduleElement) return null;
        if (moduleElement.classList && moduleElement.classList.contains('et_pb_team_member')) {
            return moduleElement;
        }
        return moduleElement.querySelector ? moduleElement.querySelector('.et_pb_team_member') : null;
    }

    function ensureSocialList(teamMember) {
        var lists = teamMember.querySelectorAll('.et_pb_member_social_links');

        if (lists.length) {
            var target = null;
            var i;

            for (i = 0; i < lists.length; i++) {
                if (lists[i].querySelector('a:not([data-dbdb-person-preview-link="1"])')) {
                    target = lists[i];
                    break;
                }
            }

            target = target || lists[0];

            for (i = 0; i < lists.length; i++) {
                if (lists[i] === target) {
                    continue;
                }

                moveNativeLinks(lists[i], target);

                if (lists[i].parentNode) {
                    lists[i].parentNode.removeChild(lists[i]);
                }
            }

            return target;
        }

        var list = document.createElement('ul');
        list.className = 'et_pb_member_social_links';

        var description = teamMember.querySelector('.et_pb_team_member_description');
        if (description) {
            description.appendChild(list);
        } else {
            teamMember.appendChild(list);
        }

        return list;
    }

    function moveNativeLinks(source, target) {
        var items = source.querySelectorAll('li');

        for (var i = 0; i < items.length; i++) {
            if (!items[i].querySelector('[data-dbdb-person-preview-link="1"]')) {
                target.appendChild(items[i]);
            }
        }
    }

    function removePreviewLinks(list) {
        var links = list.querySelectorAll('[data-dbdb-person-preview-link="1"]');
        for (var i = 0; i < links.length; i++) {
            var item = links[i].closest ? links[i].closest('li') : links[i].parentNode;
            if (item && item.parentNode) {
                item.parentNode.removeChild(item);
            }
        }
    }

    function prependIcon(list, href, className, label, openInNewTab) {
        if (!href) return;

        var item = document.createElement('li');
        var link = document.createElement('a');
        var text = document.createElement('span');

        link.href = href;
        link.className = 'et_pb_font_icon ' + className;
        link.setAttribute('data-dbdb-person-preview-link', '1');

        if (openInNewTab) {
            link.target = '_blank';
            link.rel = 'noopener';
        }

        text.textContent = label;
        link.appendChild(text);
        item.appendChild(link);
        list.insertBefore(item, list.firstChild);
    }

    function syncTargetAttributes(list, openInNewTab) {
        var links = list.querySelectorAll('a');
        for (var i = 0; i < links.length; i++) {
            if (openInNewTab) {
                if (!links[i].hasAttribute('target')) {
                    links[i].setAttribute('data-dbdb-person-preview-target', '1');
                }
                links[i].target = '_blank';
                if (!links[i].rel) {
                    links[i].rel = 'noopener';
                }
            } else if (links[i].getAttribute('data-dbdb-person-preview-target') === '1') {
                links[i].removeAttribute('target');
                links[i].removeAttribute('data-dbdb-person-preview-target');
                if (links[i].rel === 'noopener') {
                    links[i].removeAttribute('rel');
                }
            }
        }
    }

    function applyPreview(moduleId) {
        var values = moduleValuesById[moduleId];
        var moduleElement = getModuleElement(moduleId);
        var teamMember = getTeamMemberElement(moduleElement);

        if (!values || !teamMember) {
            disconnectModuleObserver(moduleId);
            return;
        }

        var list = ensureSocialList(teamMember);
        var openInNewTab = values.linkTarget === 'on' || values.linkTarget === true;

        removePreviewLinks(list);
        prependIcon(list, normalizeUrl(values.instagram), 'db_pb_team_member_instagram_icon', 'Instagram', openInNewTab);
        prependIcon(list, values.phone ? 'tel:' + values.phone : '', 'db_pb_team_member_phone_icon', 'Phone', openInNewTab);
        prependIcon(list, values.email ? 'mailto:' + values.email : '', 'db_pb_team_member_email_icon', 'Email', openInNewTab);
        prependIcon(list, normalizeUrl(values.website), 'db_pb_team_member_website_icon', 'Website', openInNewTab);
        syncTargetAttributes(list, openInNewTab);
        watchModuleElement(moduleId, moduleElement);
    }

    function scheduleApply(moduleId) {
        if (!moduleId) return;
        queuedModuleIds[moduleId] = true;

        if (rafId) return;

        rafId = requestNextFrame(function(){
            var moduleIds = Object.keys(queuedModuleIds);
            queuedModuleIds = {};
            rafId = 0;

            for (var i = 0; i < moduleIds.length; i++) {
                applyPreview(moduleIds[i]);
            }
        });
    }

    function disconnectModuleObserver(moduleId) {
        if (moduleObserversById[moduleId]) {
            moduleObserversById[moduleId].disconnect();
            delete moduleObserversById[moduleId];
        }
        delete moduleRootsById[moduleId];
    }

    function watchModuleElement(moduleId, moduleElement) {
        if (!moduleId || !moduleElement || typeof window.MutationObserver !== 'function') return;
        if (moduleRootsById[moduleId] === moduleElement) return;

        disconnectModuleObserver(moduleId);

        moduleObserversById[moduleId] = new window.MutationObserver(function(){
            scheduleApply(moduleId);
        });
        moduleObserversById[moduleId].observe(moduleElement, { childList: true, subtree: true });
        moduleRootsById[moduleId] = moduleElement;
    }

    hooks.addFilter('divi.module.wrapper.render', 'divi-booster-person-preview', function(moduleWrapper, param) {
        var moduleName = param && param.name || '';
        if (moduleName !== 'divi/team-member') {
            return moduleWrapper;
        }

        var moduleId = param && param.id || '';
        if (!moduleId) {
            return moduleWrapper;
        }

        var attrs = param && param.attrs || {};
        moduleValuesById[moduleId] = {
            website: getAttrValue(attrs, 'websiteUrl', ''),
            email: getAttrValue(attrs, 'diviboosterEmailAddress', ''),
            phone: getAttrValue(attrs, 'dbPhone', ''),
            instagram: getAttrValue(attrs, 'diviboosterInstagram', ''),
            linkTarget: getAttrValue(attrs, 'diviboosterLinkTarget', 'off')
        };

        scheduleApply(moduleId);
        return moduleWrapper;
    });
})();
JS;
}
