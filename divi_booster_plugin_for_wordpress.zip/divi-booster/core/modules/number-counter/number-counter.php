<?php

namespace DiviBooster\DiviBooster\Modules\NumberCounter;

include_once(dirname(__FILE__) . '/features/initial-value/initial-value.php');
include_once(dirname(__FILE__) . '/features/layout/layout.php');
include_once(dirname(__FILE__) . '/features/counter-duration/counter-duration.php');
include_once(dirname(__FILE__) . '/features/start-when-visible/start-when-visible.php');