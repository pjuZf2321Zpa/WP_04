<?php

namespace DiviBooster\DiviBooster\Modules\PostTitle;

include_once(dirname(__FILE__) . '/features/tags/tags.php');