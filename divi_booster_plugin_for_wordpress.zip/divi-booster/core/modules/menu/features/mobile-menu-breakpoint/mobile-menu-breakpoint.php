<?php

namespace DiviBooster\DiviBooster\Modules\Menu\MobileMenuBreakpoint;

if (!defined('ABSPATH')) {
    exit();
}

const DIVI4_MODULE_SLUG = 'et_pb_menu';
const DIVI5_MODULE_SLUG = 'divi/menu';
const D4_FIELD = 'db_show_mobile_menu';
const D4_FIELD_TABLET = 'db_show_mobile_menu_tablet';
const D4_FIELD_PHONE = 'db_show_mobile_menu_phone';
const D5_ATTR = 'dbShowMobileMenu';

// === Hooks ===
if (function_exists('add_filter')) {
    add_filter('et_pb_all_fields_unprocessed_' . DIVI4_MODULE_SLUG, __NAMESPACE__ . '\\register_divi4_fields');
    add_filter('et_module_shortcode_output', __NAMESPACE__ . '\\filter_divi4_output', 10, 3);
    add_filter('divi.moduleLibrary.conversion.moduleConversionOutline', __NAMESPACE__ . '\\register_divi5_conversion_outline', 10, 2);
    add_filter('divi_module_library_register_module_attrs', __NAMESPACE__ . '\\register_divi5_attrs', 10, 2);
    add_filter('block_type_metadata_settings', __NAMESPACE__ . '\\register_divi5_block_attrs', 10, 2);
    add_filter('render_block_' . DIVI5_MODULE_SLUG, __NAMESPACE__ . '\\add_divi5_styles_from_block', 10, 3);
    add_filter('divi_module_wrapper_render', __NAMESPACE__ . '\\add_divi5_styles', 10, 2);
}
if (function_exists('add_action')) {
    add_action('wp_enqueue_scripts', __NAMESPACE__ . '\\enqueue_divi5_builder_script');
}

// === Shared settings ===

// Return the Divi 4 fields that map to the responsive setting.
function divi4_show_mobile_menu_fields()
{
    return array(
        'desktop' => D4_FIELD,
        'tablet' => D4_FIELD_TABLET,
        'phone' => D4_FIELD_PHONE,
    );
}

// Return default menu modes by responsive device.
function default_show_mobile_menu_values()
{
    return array(
        'desktop' => 'off',
        'tablet' => 'on',
        'phone' => 'on',
    );
}

// === Divi 4 output ===

// Register the Divi 4 responsive setting fields.
function register_divi4_fields($fields)
{
    if (!is_array($fields)) {
        return $fields;
    }

    $default_values = default_show_mobile_menu_values();
    $responsive_fields = divi4_show_mobile_menu_fields();

    $fields[D4_FIELD] = array(
        'label' => esc_html__('Show Mobile Menu', 'divi-booster'),
        'type' => 'yes_no_button',
        'options' => array(
            'on' => esc_html__('Yes', 'et_builder'),
            'off' => esc_html__('No', 'et_builder'),
        ),
        'option_category' => 'layout',
        'description' => esc_html__('Choose whether this Menu module shows the mobile menu button or the full menu at each responsive width.', 'divi-booster'),
        'default' => $default_values['desktop'],
        'default_on_front' => $default_values['desktop'],
        'default_tablet' => $default_values['tablet'],
        'default_phone' => $default_values['phone'],
        'mobile_options' => true,
        'responsive' => true,
        'tab_slug' => 'advanced',
        'toggle_slug' => 'layout',
    );

    foreach (array('tablet', 'phone') as $device) {
        $fields[$responsive_fields[$device]] = array(
            'type' => 'skip',
            'tab_slug' => 'advanced',
            'default' => $default_values[$device],
        );
    }

    return $fields;
}

// Add responsive menu-mode CSS to Divi 4 output.
function filter_divi4_output($output, $render_slug, $module)
{
    if (!is_string($output) || $render_slug !== DIVI4_MODULE_SLUG || !isset($module->props) || !is_array($module->props)) {
        return $output;
    }

    $values = get_divi4_values($module->props);
    $defaults = default_show_mobile_menu_values();
    if (!has_custom_menu_mode_values($values, $defaults)) {
        return $output;
    }

    if (is_callable('\\ET_Builder_Element::set_style')) {
        add_divi4_styles($render_slug, divi4_breakpoint_settings(), $values, $defaults);
        return $output;
    }

    $order_class = extract_order_class($output);
    if ($order_class === '') {
        return $output;
    }

    $css = build_menu_mode_css($order_class, divi4_breakpoint_settings(), $values, $defaults);
    return $css === '' ? $output : $output . '<style>' . $css . '</style>';
}

// === Divi 5 registration ===

// Map converted Divi 4 fields to the Divi 5 attribute.
function register_divi5_conversion_outline($conversion_outline, $module_name)
{
    if ($module_name !== DIVI5_MODULE_SLUG) {
        return $conversion_outline;
    }
    if (!isset($conversion_outline['module']) || !is_array($conversion_outline['module'])) {
        $conversion_outline['module'] = array();
    }

    foreach (divi4_show_mobile_menu_fields() as $field) {
        $conversion_outline['module'][$field] = D5_ATTR . '.*';
    }

    return $conversion_outline;
}

// Register the Divi 5 attribute in the module library.
function register_divi5_attrs($module_attrs, $filter_args)
{
    if (!is_array($module_attrs) || !is_array($filter_args)) {
        return $module_attrs;
    }

    if (($filter_args['name'] ?? '') === DIVI5_MODULE_SLUG) {
        $module_attrs[D5_ATTR] = get_divi5_attr_definition();
    }

    return $module_attrs;
}

// Register the Divi 5 attribute on the block.
function register_divi5_block_attrs($settings, $metadata = null)
{
    if (!is_array($settings)) {
        return $settings;
    }

    if (($settings['name'] ?? '') === DIVI5_MODULE_SLUG && isset($settings['attributes']) && is_array($settings['attributes'])) {
        $settings['attributes'][D5_ATTR] = get_divi5_attr_definition();
    }

    return $settings;
}

// === Divi 5 builder preview ===

// Enqueue builder-only CSS and JS used by the preview.
function enqueue_divi5_builder_script()
{
    if ((!function_exists('et_builder_d5_enabled') || !\et_builder_d5_enabled()) ||
        (!function_exists('et_core_is_fb_enabled') || !\et_core_is_fb_enabled())) {
        return;
    }
    if (!function_exists('sanitize_title') ||
        !function_exists('wp_register_style') ||
        !function_exists('wp_enqueue_style') ||
        !function_exists('wp_add_inline_style') ||
        !function_exists('dbdb_enqueue_inline_script_if_dependencies_available')) {
        return;
    }

    $handle = sanitize_title('divi-booster-' . DIVI5_MODULE_SLUG . '-mobile-menu-breakpoint');
    $style_handle = $handle . '-style';

    wp_register_style($style_handle, false, array(), null);
    wp_enqueue_style($style_handle);
    wp_add_inline_style($style_handle, get_divi5_builder_css());

    \dbdb_enqueue_inline_script_if_dependencies_available($handle, get_divi5_builder_js(), array(array('divi-vendor-wp-hooks', 'wp-hooks')));
}

// Build the builder script that keeps preview classes in sync.
function get_divi5_builder_js()
{
    $module_slug = json_for_inline_script(DIVI5_MODULE_SLUG);
    $divi4_slug = json_for_inline_script(DIVI4_MODULE_SLUG);
    $attr_name = json_for_inline_script(D5_ATTR);
    $divi4_fields = json_for_inline_script(array_values(divi4_show_mobile_menu_fields()));
    $attr_definition = json_for_inline_script(get_divi5_attr_definition());
    $breakpoints = json_for_inline_script(get_divi5_breakpoint_settings());

    return <<<JS
(function() {
    var hooks = window.vendor && window.vendor.wp && window.vendor.wp.hooks;
    if (!hooks) {
        return;
    }

    var moduleSlug = {$module_slug};
    var attrName = {$attr_name};
    var attrDefinition = {$attr_definition};
    var divi4Fields = {$divi4_fields};
    var breakpointSettings = {$breakpoints};

    // Add the setting to the builder's module attribute map.
    hooks.addFilter('divi.moduleLibrary.moduleAttributes.' + 'divi.menu', 'divibooster.menuMobileBreakpoint', function(attributes) {
        attributes[attrName] = attrDefinition;
        return attributes;
    });

    hooks.addFilter('divi.moduleLibrary.conversion.moduleConversionOutline', 'divibooster.menuMobileBreakpoint', function(conversionOutline, name) {
        if (name !== {$divi4_slug}) {
            return conversionOutline;
        }
        conversionOutline.module = conversionOutline.module || {};
        for (var i = 0; i < divi4Fields.length; i++) {
            conversionOutline.module[divi4Fields[i]] = attrName + '.*';
        }
        return conversionOutline;
    });

    // Toggle preview classes during module renders.
    hooks.addFilter('divi.module.classnames.value', 'divibooster.menuMobileBreakpoint', function(classnames, ctx) {
        if (!ctx || ctx.name !== moduleSlug) {
            return classnames;
        }
        var attrs = ctx.attrs || {};
        var showMobile = isEnabled(attrValue(attrs, getBuilderBreakpoint()));
        var onClass  = 'db-menu-mobile-menu-on';
        var offClass = 'db-menu-mobile-menu-off';
        // Preserve the classnames value shape supplied by the builder.
        if (typeof classnames === 'string') {
            return classnames
                .replace(/\bdb-menu-mobile-menu-(?:on|off)\b/g, '')
                .trim() + ' ' + (showMobile ? onClass : offClass);
        }
        if (classnames && typeof classnames === 'object' && !Array.isArray(classnames)) {
            var copy = Object.assign({}, classnames);
            copy[onClass]  = !!showMobile;
            copy[offClass] = !showMobile;
            return copy;
        }
        return classnames;
    });

    function nestedValue(object, path) {
        var value = object;
        for (var i = 0; i < path.length; i++) {
            if (!value || typeof value !== 'object' || !Object.prototype.hasOwnProperty.call(value, path[i])) {
                return null;
            }
            value = value[path[i]];
        }
        return value;
    }

    function isEnabled(value) {
        return value === true || value === 1 || value === '1' || value === 'on' || value === 'yes' || value === 'true';
    }

    function parsePixelValue(value) {
        value = typeof value === 'number' ? String(value) : (typeof value === 'string' ? value.trim() : '');
        if (!value) {
            return null;
        }
        var match = value.match(/^(-?\d+(?:\.\d+)?)px$/i) || value.match(/^(-?\d+(?:\.\d+)?)$/);
        return match ? parseFloat(match[1]) : null;
    }

    function breakpointMatchesWidth(settings, width) {
        if (!settings) {
            return false;
        }
        var min = parsePixelValue(settings.minWidth && settings.minWidth.value);
        var max = parsePixelValue(settings.maxWidth && settings.maxWidth.value);
        if (min !== null && width < min) {
            return false;
        }
        if (max !== null && width > max) {
            return false;
        }
        return true;
    }

    function currentBreakpoint() {
        var names = Object.keys(breakpointSettings || {});
        var width = window.innerWidth || document.documentElement.clientWidth || 0;
        var fallback = breakpointSettings && breakpointSettings.desktop ? 'desktop' : (names[0] || 'desktop');
        names.sort(function(a, b) {
            return ((breakpointSettings[a] && breakpointSettings[a].order) || 0) - ((breakpointSettings[b] && breakpointSettings[b].order) || 0);
        });
        for (var i = 0; i < names.length; i++) {
            if (breakpointMatchesWidth(breakpointSettings[names[i]], width)) {
                fallback = names[i];
            }
        }
        return fallback;
    }

    // Prefer the selected builder breakpoint over viewport-width detection.
    function getBuilderBreakpoint() {
        try {
            var appUi = selectStore('divi/app-ui');
            if (appUi && typeof appUi.getBreakpoint === 'function') {
                var bp = appUi.getBreakpoint();
                if (bp && breakpointSettings[bp]) {
                    return bp;
                }
            }
        } catch (e) {}
        return currentBreakpoint();
    }

    function attrValue(attrs, breakpoint) {
        var attr = attrs && attrs[attrName];
        var value = nestedValue(attr, [breakpoint, 'value']);
        if (value === null || value === undefined || value === '') {
            value = defaultValueForBreakpoint(breakpoint);
        }
        return value;
    }

    function defaultValueForBreakpoint(breakpoint) {
        var settings = breakpointSettings && breakpointSettings[breakpoint];
        if (!settings) {
            return breakpoint === 'phone' || breakpoint === 'tablet' ? 'on' : 'off';
        }
        if (breakpoint === 'desktop' || settings.baseDevice) {
            return 'off';
        }
        var desktopOrder = breakpointSettings && breakpointSettings.desktop ? breakpointSettings.desktop.order : 50;
        return (settings.order || 0) < desktopOrder ? 'on' : 'off';
    }

    // Fallback preview sync for store changes not covered by module renders.
    function applyPreview() {
        subscribePreview();

        var editPost = selectStore('divi/edit-post');
        if (!editPost) {
            return;
        }

        var moduleUtils = window.divi && window.divi.moduleUtils;

        try {
            var content = editPost.getContent && editPost.getContent();
            if (!content || typeof content.forEach !== 'function') {
                return;
            }
            content.forEach(function(module, id) {
                try {
                    if (!module) return;
                    var name = (typeof module.get === 'function') ? module.get('name') : module.name;
                    if (name !== moduleSlug) return;

                    var menuEl = null;
                    if (moduleUtils && typeof moduleUtils.getModuleOrderClassName === 'function') {
                        var orderClass = moduleUtils.getModuleOrderClassName(id);
                        if (orderClass) {
                            menuEl = document.querySelector('.' + orderClass);
                        }
                    }
                    if (!menuEl) return;

                    var rawAttrs = (typeof module.getIn === 'function')
                        ? module.getIn(['props', 'attrs'])
                        : null;
                    if (!rawAttrs) return;
                    var attrs = (typeof rawAttrs.asMutable === 'function')
                        ? rawAttrs.asMutable({ deep: true })
                        : rawAttrs;

                    applyMenuMode(menuEl, isEnabled(attrValue(attrs, getBuilderBreakpoint())));
                } catch (innerErr) { /* ignore per-module errors */ }
            });
        } catch (e) { /* ignore store access errors */ }
    }

    function getStoreData() {
        var candidates = [window];
        try {
            if (window.parent && window.parent !== window) {
                candidates.push(window.parent);
            }
            if (window.top && window.top !== window && candidates.indexOf(window.top) === -1) {
                candidates.push(window.top);
            }
        } catch (e) {}

        for (var i = 0; i < candidates.length; i++) {
            if (candidates[i] && candidates[i].divi && candidates[i].divi.data && typeof candidates[i].divi.data.select === 'function') {
                return candidates[i].divi.data;
            }
            if (candidates[i] && candidates[i].wp && candidates[i].wp.data && typeof candidates[i].wp.data.select === 'function') {
                return candidates[i].wp.data;
            }
        }
        return null;
    }

    function selectStore(storeName) {
        var data = getStoreData();
        if (!data || typeof data.select !== 'function') {
            return null;
        }
        try {
            return data.select(storeName);
        } catch (e) {
            return null;
        }
    }

    function applyMenuMode(menu, showMobile) {
        menu.classList.toggle('db-menu-mobile-menu-on', !!showMobile);
        menu.classList.toggle('db-menu-mobile-menu-off', !showMobile);
    }

    var previewScheduled = false;

    function runScheduledPreview() {
        previewScheduled = false;
        applyPreview();
    }

    function schedulePreview() {
        if (previewScheduled) {
            return;
        }
        previewScheduled = true;
        if (window.requestAnimationFrame) {
            window.requestAnimationFrame(runScheduledPreview);
        } else {
            window.setTimeout(runScheduledPreview, 16);
        }
    }

    var subscribed = false;

    function subscribePreview() {
        if (subscribed) {
            return;
        }
        var data = getStoreData();
        if (!data || typeof data.subscribe !== 'function') {
            return;
        }
        subscribed = true;
        data.subscribe(schedulePreview);
    }

    window.addEventListener('resize', schedulePreview);
    document.addEventListener('DOMContentLoaded', schedulePreview);
    hooks.addAction('divi.editPost.store.content.change', 'divibooster.menuMobileBreakpoint', schedulePreview);
    subscribePreview();
    window.setTimeout(schedulePreview, 250);
})();
JS;
}

// Encode data for interpolation into an inline script block.
function json_for_inline_script($value)
{
    $flags = JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;
    $json = function_exists('wp_json_encode') ? wp_json_encode($value, $flags) : json_encode($value, $flags);

    return is_string($json) ? $json : 'null';
}

// Build the builder CSS for class-based menu mode previews.
function get_divi5_builder_css()
{
    return build_menu_mode_rule_for_selector('.et_pb_menu.db-menu-mobile-menu-on', true)
        . build_menu_mode_rule_for_selector('.et_pb_menu.db-menu-mobile-menu-off', false);
}

// === Divi 5 frontend output ===

// Add responsive menu-mode CSS through Divi's generated style pipeline.
function add_divi5_styles($module_wrapper, $args)
{
    if (!is_array($args) || ($args['name'] ?? '') !== DIVI5_MODULE_SLUG || !is_callable('\\ET\\Builder\\FrontEnd\\Module\\Style::add')) {
        return $module_wrapper;
    }

    $attrs = isset($args['attrs']) && is_array($args['attrs']) ? $args['attrs'] : array();
    $order_class = get_divi5_order_class($module_wrapper, $args);
    add_divi5_menu_mode_styles($order_class, $attrs, $args);

    return $module_wrapper;
}

// Add responsive menu-mode CSS from parsed block attrs without changing block HTML.
function add_divi5_styles_from_block($block_content, $parsed_block, $block)
{
    if (!is_string($block_content) || !is_array($parsed_block)) {
        return $block_content;
    }

    $attrs = isset($parsed_block['attrs']) && is_array($parsed_block['attrs']) ? $parsed_block['attrs'] : array();
    add_divi5_menu_mode_styles(extract_order_class($block_content), $attrs);

    return $block_content;
}

// Add Divi 5 generated styles for one menu module when the setting differs from Divi's defaults.
function add_divi5_menu_mode_styles($order_class, $attrs, $style_args = array())
{
    if (!is_string($order_class) || $order_class === '' || !is_array($attrs) || !is_callable('\\ET\\Builder\\FrontEnd\\Module\\Style::add')) {
        return;
    }

    $breakpoints = get_divi5_breakpoint_settings();
    $values = get_divi5_values_for_breakpoints($attrs, $breakpoints);
    $defaults = default_values_for_breakpoints($breakpoints);

    if (!has_custom_menu_mode_values($values, $defaults)) {
        return;
    }

    $style_items = build_menu_mode_style_items('.' . $order_class, $breakpoints, $values, $defaults);
    if (empty($style_items)) {
        return;
    }

    try {
        \ET\Builder\FrontEnd\Module\Style::add(array(
            'id' => get_scalar_arg($style_args, 'id', ''),
            'name' => DIVI5_MODULE_SLUG,
            'orderIndex' => get_scalar_arg($style_args, 'orderIndex', 0),
            'storeInstance' => get_scalar_arg($style_args, 'storeInstance', 0),
            'styles' => array($style_items),
        ));
    } catch (\Throwable $e) {
        return;
    }
}

// Read Divi's module order class from wrapper args, falling back to rendered markup.
function get_divi5_order_class($module_wrapper, $args)
{
    $module_elements = isset($args['elements']) ? $args['elements'] : null;
    if (is_object($module_elements)) {
        try {
            $order_class = isset($module_elements->order_class) ? $module_elements->order_class : '';
            if (is_string($order_class) && preg_match('/^et_pb_menu_\d+(?:_tb_[a-z]+)?$/', $order_class)) {
                return $order_class;
            }
        } catch (\Throwable $e) {
            return '';
        }
    }

    return extract_order_class($module_wrapper);
}

// Read scalar Divi wrapper args for Style::add payloads.
function get_scalar_arg($args, $key, $fallback)
{
    if (!is_array($args) || !array_key_exists($key, $args) || !is_scalar($args[$key])) {
        return $fallback;
    }

    return $args[$key];
}

// Add Divi 4 dynamic styles without changing the module's sibling structure.
function add_divi4_styles($render_slug, $breakpoints, $values, $defaults)
{
    if (!is_callable('\\ET_Builder_Element::set_style')) {
        return;
    }

    foreach (build_menu_mode_style_items('%%order_class%%', $breakpoints, $values, $defaults) as $item) {
        $style = array(
            'selector' => $item['selector'],
            'declaration' => $item['declaration'],
        );
        if (!empty($item['atRules']) && is_string($item['atRules'])) {
            $style['media_query'] = $item['atRules'];
        }
        \ET_Builder_Element::set_style($render_slug, $style);
    }
}

// === Attribute and value helpers ===

// Describe the Divi 5 setting field.
function get_divi5_attr_definition()
{
    return array(
        'type' => 'object',
        'settings' => array(
            'innerContent' => array(
                'groupType' => 'group-items',
                'items' => array(
                    'dbShowMobileMenuToggle' => array(
                        'groupSlug' => 'designLayout',
                        'attrName' => D5_ATTR,
                        'label' => 'Show Mobile Menu',
                        'description' => 'Choose whether this Menu module shows the mobile menu button or the full menu at each breakpoint.',
                        'category' => 'layout',
                        'features' => array(
                            'hover' => false,
                            'sticky' => false,
                            'responsive' => true,
                            'preset' => 'advanced',
                        ),
                        'render' => true,
                        'priority' => 115,
                        'component' => array(
                            'type' => 'field',
                            'name' => 'divi/toggle',
                        ),
                        'defaultAttr' => get_divi5_default_attr(),
                    ),
                ),
            ),
        ),
    );
}

// Build responsive defaults for the Divi 5 attribute.
function get_divi5_default_attr()
{
    $defaults = array();
    foreach (get_divi5_breakpoint_settings() as $breakpoint => $settings) {
        $defaults[$breakpoint] = array(
            'value' => default_value_for_breakpoint($breakpoint, $settings),
        );
    }

    if (!isset($defaults['desktop'])) {
        $defaults['desktop'] = array('value' => 'off');
    }

    return $defaults;
}

// Determine the default menu mode for a Divi 5 breakpoint.
function default_value_for_breakpoint($breakpoint, $settings)
{
    if (!is_array($settings)) {
        return $breakpoint === 'desktop' ? 'off' : 'on';
    }

    if ($breakpoint === 'desktop' || !empty($settings['baseDevice'])) {
        return 'off';
    }

    $breakpoints = get_divi5_breakpoint_settings();
    $desktop_order = isset($breakpoints['desktop']['order']) ? (int) $breakpoints['desktop']['order'] : 50;
    $order = isset($settings['order']) ? (int) $settings['order'] : 0;

    return $order < $desktop_order ? 'on' : 'off';
}

// Read responsive Divi 5 setting values with defaults.
function get_divi5_values($attrs)
{
    return get_divi5_values_for_breakpoints($attrs, get_divi5_breakpoint_settings());
}

// Read responsive Divi 5 setting values for a breakpoint set.
function get_divi5_values_for_breakpoints($attrs, $breakpoints)
{
    $values = array();
    if (!is_array($breakpoints)) {
        return $values;
    }

    foreach ($breakpoints as $breakpoint => $settings) {
        $values[$breakpoint] = read_divi5_value($attrs, $breakpoint, default_value_for_breakpoint($breakpoint, $settings));
    }

    return $values;
}

// Build the default menu mode values for a breakpoint set.
function default_values_for_breakpoints($breakpoints)
{
    $defaults = array();
    if (!is_array($breakpoints)) {
        return $defaults;
    }

    foreach ($breakpoints as $breakpoint => $settings) {
        $defaults[$breakpoint] = default_value_for_breakpoint($breakpoint, $settings);
    }

    return $defaults;
}

// Check whether the feature needs to override Divi's normal menu mode.
function has_custom_menu_mode_values($values, $defaults)
{
    if (!is_array($values) || !is_array($defaults)) {
        return false;
    }

    foreach ($values as $breakpoint => $value) {
        $default = isset($defaults[$breakpoint]) ? $defaults[$breakpoint] : default_value_for_breakpoint($breakpoint, array());
        if (is_on($value) !== is_on($default)) {
            return true;
        }
    }

    return false;
}

function read_divi5_value($attrs, $breakpoint, $default)
{
    if (!is_array($attrs)) {
        return $default;
    }

    if (isset($attrs[D5_ATTR][$breakpoint]['value']) && is_scalar($attrs[D5_ATTR][$breakpoint]['value'])) {
        return (string) $attrs[D5_ATTR][$breakpoint]['value'];
    }

    return $default;
}

// Read responsive Divi 4 setting values with defaults.
function get_divi4_values($props)
{
    $values = array();
    foreach (default_show_mobile_menu_values() as $device => $default) {
        $values[$device] = responsive_value($props, D4_FIELD, $device, $default);
    }

    return $values;
}

// Read a Divi 4 responsive prop value.
function responsive_value($props, $field, $device, $default)
{
    if (!is_array($props)) {
        return $default;
    }

    $suffix = $device === 'desktop' ? '' : '_' . $device;
    $key = $field . $suffix;
    if (isset($props[$key]) && is_scalar($props[$key]) && (string) $props[$key] !== '') {
        return (string) $props[$key];
    }

    return $default;
}

// === CSS generation ===

// Build responsive CSS for one menu module instance.
function build_menu_mode_css($order_class, $breakpoints, $values, $defaults = null)
{
    $style_items = build_menu_mode_style_items('.' . sanitize_css_class($order_class), $breakpoints, $values, $defaults);
    if (empty($style_items)) {
        return '';
    }

    $css = '';
    foreach ($style_items as $item) {
        $rule = $item['selector'] . '{' . $item['declaration'] . '}';
        $css .= empty($item['atRules']) ? $rule : $item['atRules'] . '{' . $rule . '}';
    }

    return $css;
}

// Build responsive style items for one menu module instance.
function build_menu_mode_style_items($selector, $breakpoints, $values, $defaults = null)
{
    if (!is_string($selector) || $selector === '' || !is_array($breakpoints) || !is_array($values)) {
        return array();
    }

    $items = array();
    foreach ($breakpoints as $breakpoint => $settings) {
        $default = is_array($defaults) && isset($defaults[$breakpoint]) ? $defaults[$breakpoint] : default_value_for_breakpoint($breakpoint, $settings);
        $value = isset($values[$breakpoint]) ? $values[$breakpoint] : $default;
        if (is_array($defaults) && is_on($value) === is_on($default)) {
            continue;
        }

        $media_query = breakpoint_media_query($settings);
        $at_rules = $media_query === '' ? false : '@media only screen and ' . $media_query;
        $items = array_merge($items, build_menu_mode_style_items_for_selector($selector, is_on($value), $at_rules));
    }

    return $items;
}

// Build style items for one selector and menu mode.
function build_menu_mode_style_items_for_selector($selector, $show_mobile, $at_rules = false)
{
    if ($show_mobile) {
        return array(
            menu_mode_style_item($at_rules, "{$selector} .et_pb_menu__menu", 'display:none!important;'),
            menu_mode_style_item($at_rules, "{$selector} .et-menu", 'display:none!important;'),
            menu_mode_style_item($at_rules, "{$selector} .et_mobile_nav_menu", 'float:none!important;margin:0 6px!important;display:flex!important;align-items:center!important;'),
            menu_mode_style_item($at_rules, "{$selector}.et_pb_menu--style-left_aligned .et_pb_menu_inner_container,{$selector}.et_pb_menu--style-left_aligned .et_pb_row", 'align-items:center!important;'),
            menu_mode_style_item($at_rules, "{$selector}.et_pb_menu--style-left_aligned .et_pb_menu__wrap", 'justify-content:flex-end!important;'),
            menu_mode_style_item($at_rules, "{$selector}.et_pb_menu--style-left_aligned.et_pb_text_align_center .et_pb_menu__wrap", 'justify-content:center!important;'),
            menu_mode_style_item($at_rules, "{$selector}.et_pb_menu--style-left_aligned.et_pb_text_align_right .et_pb_menu__wrap", 'justify-content:flex-end!important;'),
            menu_mode_style_item($at_rules, "{$selector}.et_pb_menu--style-left_aligned.et_pb_text_align_justified .et_pb_menu__wrap", 'justify-content:space-between!important;'),
            menu_mode_style_item($at_rules, "{$selector}.et_pb_menu--style-inline_centered_logo .et_pb_menu_inner_container>.et_pb_menu__logo-wrap,{$selector}.et_pb_menu--style-inline_centered_logo .et_pb_row>.et_pb_menu__logo-wrap", 'display:flex!important;flex-direction:column!important;align-items:center!important;'),
            menu_mode_style_item($at_rules, "{$selector}.et_pb_menu--style-inline_centered_logo .et_pb_menu_inner_container>.et_pb_menu__logo,{$selector}.et_pb_menu--style-inline_centered_logo .et_pb_row>.et_pb_menu__logo", 'margin:0 auto!important;'),
            menu_mode_style_item($at_rules, "{$selector}.et_pb_menu--style-inline_centered_logo .et_pb_menu__logo-slot", 'display:none!important;'),
            menu_mode_style_item($at_rules, "{$selector} .et_pb_row", 'min-height:81px!important;'),
            menu_mode_style_item($at_rules, "{$selector} .et_mobile_menu", 'top:100%!important;padding:5%!important;'),
            menu_mode_style_item($at_rules, "{$selector} .et_mobile_menu,{$selector} .et_mobile_menu ul", 'list-style:none!important;text-align:left!important;'),
            menu_mode_style_item($at_rules, "{$selector} .et_mobile_menu ul", 'padding:0!important;'),
            menu_mode_style_item($at_rules, "{$selector} .et_pb_mobile_menu_upwards .et_mobile_menu", 'top:auto!important;bottom:100%!important;'),
        );
    }

    return array(
        menu_mode_style_item($at_rules, "{$selector} .et_pb_menu__menu", 'display:flex!important;'),
        menu_mode_style_item($at_rules, "{$selector} .et-menu", 'display:flex!important;'),
        menu_mode_style_item($at_rules, "{$selector} .et_mobile_nav_menu", 'display:none!important;'),
        menu_mode_style_item($at_rules, "{$selector}.et_pb_menu--style-left_aligned .et_pb_menu_inner_container,{$selector}.et_pb_menu--style-left_aligned .et_pb_row", 'align-items:stretch!important;'),
        menu_mode_style_item($at_rules, "{$selector}.et_pb_menu--style-left_aligned .et_pb_menu__wrap", 'justify-content:flex-start!important;'),
        menu_mode_style_item($at_rules, "{$selector}.et_pb_menu--style-left_aligned.et_pb_text_align_center .et_pb_menu__wrap", 'justify-content:center!important;'),
        menu_mode_style_item($at_rules, "{$selector}.et_pb_menu--style-left_aligned.et_pb_text_align_right .et_pb_menu__wrap", 'justify-content:flex-end!important;'),
        menu_mode_style_item($at_rules, "{$selector}.et_pb_menu--style-left_aligned.et_pb_text_align_justified .et_pb_menu__wrap", 'justify-content:space-between!important;'),
        menu_mode_style_item($at_rules, "{$selector}.et_pb_menu--style-inline_centered_logo .et_pb_menu_inner_container>.et_pb_menu__logo-wrap,{$selector}.et_pb_menu--style-inline_centered_logo .et_pb_row>.et_pb_menu__logo-wrap", 'display:none!important;margin-bottom:30px;'),
        menu_mode_style_item($at_rules, "{$selector}.et_pb_menu--style-inline_centered_logo .et_pb_menu__logo-slot", 'display:flex!important;'),
        menu_mode_style_item($at_rules, "{$selector} .et_pb_row", 'min-height:0!important;'),
    );
}

// Format one raw style item for Divi style APIs.
function menu_mode_style_item($at_rules, $selector, $declaration)
{
    return array(
        'atRules' => $at_rules,
        'selector' => $selector,
        'declaration' => $declaration,
    );
}

// Build menu-mode CSS for an order class.
function build_menu_mode_rule($order_class, $show_mobile)
{
    $selector = '.' . sanitize_css_class($order_class);
    return build_menu_mode_rule_for_selector($selector, $show_mobile);
}

// Build menu-mode CSS for a selector.
function build_menu_mode_rule_for_selector($selector, $show_mobile)
{
    if ($show_mobile) {
        return "{$selector} .et_pb_menu__menu{display:none!important;}"
            . "{$selector} .et-menu{display:none!important;}"
            . "{$selector} .et_mobile_nav_menu{float:none!important;margin:0 6px!important;display:flex!important;align-items:center!important;}"
            . "{$selector}.et_pb_menu--style-left_aligned .et_pb_menu_inner_container,{$selector}.et_pb_menu--style-left_aligned .et_pb_row{align-items:center!important;}"
            . "{$selector}.et_pb_menu--style-left_aligned .et_pb_menu__wrap{justify-content:flex-end!important;}"
            . "{$selector}.et_pb_menu--style-left_aligned.et_pb_text_align_center .et_pb_menu__wrap{justify-content:center!important;}"
            . "{$selector}.et_pb_menu--style-left_aligned.et_pb_text_align_right .et_pb_menu__wrap{justify-content:flex-end!important;}"
            . "{$selector}.et_pb_menu--style-left_aligned.et_pb_text_align_justified .et_pb_menu__wrap{justify-content:space-between!important;}"
            . "{$selector}.et_pb_menu--style-inline_centered_logo .et_pb_menu_inner_container>.et_pb_menu__logo-wrap,{$selector}.et_pb_menu--style-inline_centered_logo .et_pb_row>.et_pb_menu__logo-wrap{display:flex!important;flex-direction:column!important;align-items:center!important;}"
            . "{$selector}.et_pb_menu--style-inline_centered_logo .et_pb_menu_inner_container>.et_pb_menu__logo,{$selector}.et_pb_menu--style-inline_centered_logo .et_pb_row>.et_pb_menu__logo{margin:0 auto!important;}"
            . "{$selector}.et_pb_menu--style-inline_centered_logo .et_pb_menu__logo-slot{display:none!important;}"
            . "{$selector} .et_pb_row{min-height:81px!important;}"
            . "{$selector} .et_mobile_menu{top:100%!important;padding:5%!important;}"
            . "{$selector} .et_mobile_menu,{$selector} .et_mobile_menu ul{list-style:none!important;text-align:left!important;}"
            . "{$selector} .et_mobile_menu ul{padding:0!important;}"
            . "{$selector} .et_pb_mobile_menu_upwards .et_mobile_menu{top:auto!important;bottom:100%!important;}";
    }

    return "{$selector} .et_pb_menu__menu{display:flex!important;}"
        . "{$selector} .et-menu{display:flex!important;}"
        . "{$selector} .et_mobile_nav_menu{display:none!important;}"
        . "{$selector}.et_pb_menu--style-left_aligned .et_pb_menu_inner_container,{$selector}.et_pb_menu--style-left_aligned .et_pb_row{align-items:stretch!important;}"
        . "{$selector}.et_pb_menu--style-left_aligned .et_pb_menu__wrap{justify-content:flex-start!important;}"
        . "{$selector}.et_pb_menu--style-left_aligned.et_pb_text_align_center .et_pb_menu__wrap{justify-content:center!important;}"
        . "{$selector}.et_pb_menu--style-left_aligned.et_pb_text_align_right .et_pb_menu__wrap{justify-content:flex-end!important;}"
        . "{$selector}.et_pb_menu--style-left_aligned.et_pb_text_align_justified .et_pb_menu__wrap{justify-content:space-between!important;}"
        . "{$selector}.et_pb_menu--style-inline_centered_logo .et_pb_menu_inner_container>.et_pb_menu__logo-wrap,{$selector}.et_pb_menu--style-inline_centered_logo .et_pb_row>.et_pb_menu__logo-wrap{display:none!important;margin-bottom:30px;}"
        . "{$selector}.et_pb_menu--style-inline_centered_logo .et_pb_menu__logo-slot{display:flex!important;}"
        . "{$selector} .et_pb_row{min-height:0!important;}";
}

// === Breakpoints and sanitization ===

// Convert breakpoint settings into a media-query condition.
function breakpoint_media_query($settings)
{
    if (!is_array($settings)) {
        return '';
    }

    $parts = array();
    if (isset($settings['minWidth']['value']) && is_string($settings['minWidth']['value']) && $settings['minWidth']['value'] !== '') {
        $parts[] = '(min-width: ' . sanitize_css_length($settings['minWidth']['value']) . ')';
    }
    if (isset($settings['maxWidth']['value']) && is_string($settings['maxWidth']['value']) && $settings['maxWidth']['value'] !== '') {
        $parts[] = '(max-width: ' . sanitize_css_length($settings['maxWidth']['value']) . ')';
    }

    return implode(' and ', array_filter($parts));
}

// Sanitize CSS lengths used in generated media queries.
function sanitize_css_length($value)
{
    $value = trim((string) $value);
    return preg_match('/^-?(?:\d+|\d*\.\d+)(?:px|em|rem|vw|vh|%)$/i', $value) ? $value : '0px';
}

// Sanitize a CSS class without assuming WordPress helpers are loaded.
function sanitize_css_class($value)
{
    if (function_exists('sanitize_html_class')) {
        return sanitize_html_class($value);
    }

    $sanitized = preg_replace('/[^A-Za-z0-9_-]/', '', (string) $value);
    return is_string($sanitized) ? $sanitized : '';
}

// Check whether a stored setting value is enabled.
function is_on($value)
{
    return in_array($value, array(true, 1, '1', 'on', 'yes', 'true'), true);
}

// Extract the module order class from rendered markup.
function extract_order_class($html)
{
    if (!is_string($html) || $html === '') {
        return '';
    }
    if (preg_match('/\bet_pb_menu_(\d+(?:_[a-z0-9_]+)?)\b/i', $html, $matches)) {
        return 'et_pb_menu_' . $matches[1];
    }

    return '';
}

// Return the Divi 4 responsive breakpoint settings.
function divi4_breakpoint_settings()
{
    return array(
        'desktop' => array(
            'order' => 50,
            'baseDevice' => true,
            'minWidth' => array('value' => '981px'),
        ),
        'tablet' => array(
            'order' => 30,
            'minWidth' => array('value' => '768px'),
            'maxWidth' => array('value' => '980px'),
        ),
        'phone' => array(
            'order' => 10,
            'maxWidth' => array('value' => '767px'),
        ),
    );
}

// Return Divi 5 breakpoint settings, falling back to Divi 4 defaults.
function get_divi5_breakpoint_settings()
{
    $class = '\\ET\\Builder\\Framework\\Breakpoint\\Breakpoint';
    if (class_exists($class) && is_callable(array($class, 'get_style_breakpoint_settings'))) {
        try {
            $settings = call_user_func(array($class, 'get_style_breakpoint_settings'));
            if (is_array($settings) && !empty($settings)) {
                return $settings;
            }
        } catch (\Throwable $e) {
            // Fall back to the fixed breakpoint set.
        }
    }

    return divi4_breakpoint_settings();
}
