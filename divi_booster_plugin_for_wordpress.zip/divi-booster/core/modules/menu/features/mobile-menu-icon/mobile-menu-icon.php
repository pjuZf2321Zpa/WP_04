<?php

namespace DiviBooster\DiviBooster\Modules\Menu\MobileMenuIcon;

if (!defined('ABSPATH')) {
    exit();
}

const DIVI4_MODULE_SLUG = 'et_pb_menu';
const DIVI5_MODULE_SLUG = 'divi/menu';
const D4_FIELD = 'db_mobile_menu_icon';
const D5_ATTR = 'dbMobileMenuIcon';
const HAMBURGER_SELECTOR = '.mobile_nav .mobile_menu_bar:before';
const DIVI5_BUILDER_HOOKS_PACKAGE_HANDLE = 'divibooster-menu-mobile-icon-builder-hooks';

// === Hooks ===
if (function_exists('add_filter')) {
    add_filter('et_pb_all_fields_unprocessed_' . DIVI4_MODULE_SLUG, __NAMESPACE__ . '\\register_divi4_fields');
    add_filter('et_module_shortcode_output', __NAMESPACE__ . '\\filter_divi4_output', 10, 3);
    add_filter('divi.moduleLibrary.conversion.moduleConversionOutline', __NAMESPACE__ . '\\register_divi5_conversion_outline', 10, 2);
    add_filter('divi_module_library_register_module_attrs', __NAMESPACE__ . '\\register_divi5_attrs', 10, 2);
    add_filter('block_type_metadata_settings', __NAMESPACE__ . '\\register_divi5_block_attrs', 10, 2);
    add_filter('render_block_' . DIVI5_MODULE_SLUG, __NAMESPACE__ . '\\add_divi5_styles_from_block', 10, 3);
    add_filter('divi_module_wrapper_render', __NAMESPACE__ . '\\add_divi5_styles', 10, 2);
}
if (function_exists('add_action')) {
    add_action('wp_enqueue_scripts', __NAMESPACE__ . '\\enqueue_divi5_builder_script');
}
if (function_exists('add_filter')) {
    add_filter('divi_visual_builder_package_build_params_divi-module-library', __NAMESPACE__ . '\\add_divi5_builder_package_dependency');
}

// === Divi 4 ===

// Register the Divi 4 icon picker field.
function register_divi4_fields($fields)
{
    if (!is_array($fields)) {
        return $fields;
    }

    $fields[D4_FIELD] = array(
        'label' => esc_html__('Mobile Menu Icon', 'divi-booster'),
        'type' => 'select_icon',
        'option_category' => 'layout',
        'class' => array('et-pb-font-icon'),
        'description' => esc_html__('Choose an icon for the mobile menu button. Leave unset to use the default hamburger icon.', 'divi-booster'),
        'default' => '',
        'default_on_front' => '',
        'tab_slug' => 'advanced',
        'toggle_slug' => 'icon_settings',
    );

    return $fields;
}

// Add the selected icon CSS to Divi 4 output.
function filter_divi4_output($output, $render_slug, $module)
{
    if (!is_string($output) || $render_slug !== DIVI4_MODULE_SLUG || !isset($module->props) || !is_array($module->props)) {
        return $output;
    }

    $icon = get_divi4_icon_value($module->props);
    if ($icon === '') {
        return $output;
    }

    $declaration = icon_declaration_from_divi4_value($icon);
    if ($declaration === '') {
        return $output;
    }

    if (is_callable('\\ET_Builder_Element::set_style')) {
        \ET_Builder_Element::set_style($render_slug, array(
            'selector' => '%%order_class%% ' . HAMBURGER_SELECTOR,
            'declaration' => $declaration,
        ));
        return $output;
    }

    $order_class = extract_order_class($output);
    if ($order_class === '') {
        return $output;
    }

    $css = build_icon_css($order_class, $declaration);
    if ($css === '') {
        return $output;
    }

    return $output . '<style>' . $css . '</style>';
}

// === Divi 5 ===

// Map converted Divi 4 icon values to the Divi 5 icon-picker attribute.
function register_divi5_conversion_outline($conversion_outline, $module_name)
{
    if ($module_name !== DIVI5_MODULE_SLUG) {
        return $conversion_outline;
    }
    if (!isset($conversion_outline['module']) || !is_array($conversion_outline['module'])) {
        $conversion_outline['module'] = array();
    }

    $conversion_outline['module'][D4_FIELD] = D5_ATTR . '.*';

    if (!isset($conversion_outline['valueExpansionFunctionMap']) || !is_array($conversion_outline['valueExpansionFunctionMap'])) {
        $conversion_outline['valueExpansionFunctionMap'] = array();
    }
    $conversion_outline['valueExpansionFunctionMap'][D4_FIELD] = 'convertFontIcon';

    return $conversion_outline;
}

// Register the Divi 5 attribute in the module library.
function register_divi5_attrs($module_attrs, $filter_args)
{
    if (!is_array($module_attrs) || !is_array($filter_args)) {
        return $module_attrs;
    }

    if (($filter_args['name'] ?? '') === DIVI5_MODULE_SLUG) {
        $module_attrs[D5_ATTR] = get_divi5_attr_definition();
    }

    return $module_attrs;
}

// Register the Divi 5 attribute on the block.
function register_divi5_block_attrs($settings, $metadata = null)
{
    if (!is_array($settings)) {
        return $settings;
    }

    if (($settings['name'] ?? '') === DIVI5_MODULE_SLUG && isset($settings['attributes']) && is_array($settings['attributes'])) {
        $settings['attributes'][D5_ATTR] = get_divi5_attr_definition();
    }

    return $settings;
}

// Add the selected icon CSS through Divi's generated style pipeline.
function add_divi5_styles($module_wrapper, $args)
{
    if (!is_array($args) || ($args['name'] ?? '') !== DIVI5_MODULE_SLUG || !is_callable('\\ET\\Builder\\FrontEnd\\Module\\Style::add')) {
        return $module_wrapper;
    }

    $attrs = isset($args['attrs']) && is_array($args['attrs']) ? $args['attrs'] : array();
    $icon = get_divi5_icon_value($attrs);
    $order_class = get_divi5_order_class($module_wrapper, $args);
    add_divi5_icon_styles($order_class, $icon, $args);

    return $module_wrapper;
}

// Add frontend styles from the saved block attrs. Divi's wrapper filter can
// expose the registered attribute definition instead of the saved value.
function add_divi5_styles_from_block($block_content, $parsed_block, $block)
{
    if (!is_string($block_content) || !is_array($parsed_block)) {
        return $block_content;
    }

    $attrs = isset($parsed_block['attrs']) && is_array($parsed_block['attrs']) ? $parsed_block['attrs'] : array();
    add_divi5_icon_styles(extract_order_class($block_content), get_divi5_icon_value($attrs));

    return $block_content;
}

// Register one module's mobile-menu icon declaration with Divi's CSS store.
function add_divi5_icon_styles($order_class, $icon, $style_args = array())
{
    if (!is_string($order_class) || $order_class === '' || !is_array($icon) || empty($icon) ||
        !is_callable('\\ET\\Builder\\FrontEnd\\Module\\Style::add')) {
        return;
    }

    $declaration = icon_declaration_from_divi5_value($icon);
    if ($declaration === '') {
        return;
    }

    try {
        \ET\Builder\FrontEnd\Module\Style::add(array(
            'id' => get_scalar_arg($style_args, 'id', ''),
            'name' => DIVI5_MODULE_SLUG,
            'orderIndex' => get_scalar_arg($style_args, 'orderIndex', 0),
            'storeInstance' => get_scalar_arg($style_args, 'storeInstance', 0),
            'styles' => array(array(
                array(
                    'atRules' => false,
                    'selector' => '.' . $order_class . ' ' . HAMBURGER_SELECTOR,
                    'declaration' => $declaration,
                ),
            )),
        ));
    } catch (\Throwable $e) {
        return;
    }
}

// Read Divi's module order class from wrapper args, falling back to rendered markup.
function get_divi5_order_class($module_wrapper, $args)
{
    $module_elements = isset($args['elements']) ? $args['elements'] : null;
    if (is_object($module_elements)) {
        try {
            $order_class = isset($module_elements->order_class) ? $module_elements->order_class : '';
            if (is_string($order_class) && preg_match('/^et_pb_menu_\d+(?:_tb_[a-z]+)?$/', $order_class)) {
                return $order_class;
            }
        } catch (\Throwable $e) {
            return '';
        }
    }

    return extract_order_class($module_wrapper);
}

// Read scalar Divi wrapper args for Style::add payloads.
function get_scalar_arg($args, $key, $fallback)
{
    if (!is_array($args) || !array_key_exists($key, $args) || !is_scalar($args[$key])) {
        return $fallback;
    }

    return $args[$key];
}

// Enqueue builder-only JS that exposes the setting before modules are converted/rendered.
function enqueue_divi5_builder_script()
{
    if (!is_divi5_builder_preview() || !function_exists('dbdb_enqueue_inline_script_if_dependencies_available')) {
        return;
    }

    dbdb_enqueue_inline_script_if_dependencies_available(
        DIVI5_BUILDER_HOOKS_PACKAGE_HANDLE,
        get_divi5_builder_js(),
        array('divi-vendor-wp-hooks')
    );
}

// Ensure wrapper-render filters are loaded with Divi's module-library package.
function add_divi5_builder_package_dependency($params)
{
    if (!is_array($params) || !is_divi5_builder_preview()) {
        return $params;
    }

    if (!isset($params['script']) || !is_array($params['script'])) {
        $params['script'] = array();
    }

    $deps = isset($params['script']['deps']) && is_array($params['script']['deps']) ? $params['script']['deps'] : array();
    if (!in_array(DIVI5_BUILDER_HOOKS_PACKAGE_HANDLE, $deps, true)) {
        array_unshift($deps, DIVI5_BUILDER_HOOKS_PACKAGE_HANDLE);
    }
    $params['script']['deps'] = $deps;

    return $params;
}

// Check whether the current request is a Divi 5 visual builder preview.
function is_divi5_builder_preview()
{
    return function_exists('et_builder_d5_enabled') &&
        \et_builder_d5_enabled() &&
        function_exists('et_core_is_fb_enabled') &&
        \et_core_is_fb_enabled();
}

// Build the builder script that registers the custom attr client-side.
function get_divi5_builder_js()
{
    $module_slug = json_for_inline_script(DIVI5_MODULE_SLUG);
    $divi4_slug = json_for_inline_script(DIVI4_MODULE_SLUG);
    $attr_name = json_for_inline_script(D5_ATTR);
    $d4_field = json_for_inline_script(D4_FIELD);
    $attr_definition = json_for_inline_script(get_divi5_attr_definition());
    $style_id = json_for_inline_script('divibooster-menu-mobile-icon-preview');

    return <<<JS
(function() {
    var hooks = window.vendor && window.vendor.wp && window.vendor.wp.hooks;
    if (!hooks) {
        return;
    }

    var moduleSlug = {$module_slug};
    var attrName = {$attr_name};
    var attrDefinition = {$attr_definition};
    var divi4Field = {$d4_field};
    var styleId = {$style_id};
    var previewClassPrefix = 'divibooster-menu-mobile-icon-preview-';
    var previewScheduled = false;
    var previewSubscribed = false;

    hooks.addFilter('divi.moduleLibrary.moduleAttributes.' + 'divi.menu', 'divibooster.menuMobileIcon', function(attributes) {
        attributes[attrName] = attrDefinition;
        return attributes;
    });

    hooks.addFilter('divi.moduleLibrary.conversion.moduleConversionOutline', 'divibooster.menuMobileIcon', function(conversionOutline, name) {
        if (name !== {$divi4_slug}) {
            return conversionOutline;
        }
        var convertFontIcon = window.divi && window.divi.conversion && window.divi.conversion.convertFontIcon;

        conversionOutline.module = conversionOutline.module || {};
        conversionOutline.module[divi4Field] = attrName + '.*';
        conversionOutline.valueExpansionFunctionMap = conversionOutline.valueExpansionFunctionMap || {};
        conversionOutline.valueExpansionFunctionMap[divi4Field] = convertFontIcon || 'convertFontIcon';
        return conversionOutline;
    });

    hooks.addFilter('divi.module.wrapper.render', 'divibooster.menuMobileIcon', function(moduleWrapper, param) {
        try {
            if (!param || param.name !== moduleSlug) {
                return moduleWrapper;
            }

            var WPElement = getWPElement();
            var React = getReact(WPElement);
            if (!React || !WPElement || typeof React.useEffect !== 'function' || typeof React.useRef !== 'function') {
                return moduleWrapper;
            }

            var previewAttrs = toPlain(param.attrs || {});
            var icon = getIconValue(previewAttrs);
            var declaration = iconDeclaration(icon);
            var orderClass = param.elements && param.elements.orderClass ? param.elements.orderClass : '';

            var injectorEl = WPElement.createElement(MenuIconPreviewInjector, {
                key: 'divibooster-menu-mobile-icon-preview',
                declaration: declaration,
                orderClass: orderClass
            });

            var existingChildren = moduleWrapper.props && moduleWrapper.props.children;
            if (!Array.isArray(existingChildren)) {
                existingChildren = existingChildren ? [existingChildren] : [];
            }

            return WPElement.cloneElement(moduleWrapper, moduleWrapper.props, existingChildren.concat([injectorEl]));
        } catch (e) {
            return moduleWrapper;
        }
    });

    function MenuIconPreviewInjector(props) {
        var WPElement = getWPElement();
        var React = getReact(WPElement);
        var ref = React.useRef(null);

        React.useEffect(function() {
            var marker = ref.current;
            if (!marker) {
                return;
            }

            var doc = marker.ownerDocument || document;
            var orderSelector = normalizeOrderSelector(props.orderClass);
            var orderClassName = normalizeOrderClassName(props.orderClass);
            var styleSuffix = cssIdentifier(orderClassName || props.orderClass || 'module');
            var localStyleId = styleId + '-' + styleSuffix;
            var previewClass = previewClassPrefix + styleSuffix;
            var menuEl = findMenuElementInDocument(doc, props.orderClass) || closest(marker, '.et_pb_menu');
            var style = doc.getElementById(localStyleId);

            if (!props.declaration) {
                if (menuEl && menuEl.classList) {
                    menuEl.classList.remove(previewClass);
                }
                if (style && style.parentNode) {
                    style.parentNode.removeChild(style);
                }
                return;
            }

            if (menuEl && menuEl.classList) {
                menuEl.classList.add(previewClass);
            }

            if (!style && doc.head) {
                style = doc.createElement('style');
                style.id = localStyleId;
                doc.head.appendChild(style);
            }

            if (style) {
                var css = '';
                if (menuEl) {
                    css += '.' + previewClass + ' .mobile_nav .mobile_menu_bar:before{' + props.declaration + '}';
                }
                if (orderSelector) {
                    css += orderSelector + ' .mobile_nav .mobile_menu_bar:before{' + props.declaration + '}';
                }
                style.textContent = css;
            }

            return function() {
                if (menuEl && menuEl.classList) {
                    menuEl.classList.remove(previewClass);
                }
                if (style && style.parentNode) {
                    style.parentNode.removeChild(style);
                }
            };
        }, [props.declaration, props.orderClass]);

        return WPElement.createElement('span', {
            ref: ref,
            style: { display: 'none' },
            'aria-hidden': 'true'
        });
    }

    function getWPElement() {
        return window.vendor && window.vendor.wp && window.vendor.wp.element;
    }

    function getReact(WPElement) {
        return (window.vendor && window.vendor.React) || WPElement;
    }

    function schedulePreview() {
        if (previewScheduled) {
            return;
        }
        previewScheduled = true;
        window.requestAnimationFrame(function() {
            previewScheduled = false;
            applyPreview();
        });
    }

    function applyPreview() {
        subscribePreview();

        var editPost = selectStore('divi/edit-post');
        if (!editPost || typeof editPost.getContent !== 'function') {
            return;
        }

        var css = [];
        var moduleUtils = window.divi && window.divi.moduleUtils;

        try {
            var content = editPost.getContent();
            if (!content || typeof content.forEach !== 'function') {
                cleanupPreviewClasses({});
                updatePreviewStyles('');
                return;
            }

            var activePreviewClasses = {};

            content.forEach(function(module, id) {
                try {
                    if (!module) return;

                    var name = (typeof module.get === 'function') ? module.get('name') : module.name;
                    if (name !== moduleSlug) return;

                    if (!moduleUtils || typeof moduleUtils.getModuleOrderClassName !== 'function') return;

                    var orderClass = moduleUtils.getModuleOrderClassName(id);
                    if (!/^et_pb_menu_\d+(?:_tb_[a-z]+)?$/.test(orderClass || '')) return;

                    var rawAttrs = (typeof module.getIn === 'function')
                        ? module.getIn(['props', 'attrs'])
                        : module.props && module.props.attrs;
                    var attrs = toPlain(rawAttrs);
                    var icon = getIconValue(attrs);
                    var declaration = iconDeclaration(icon);

                    if (declaration) {
                        var menuEl = findMenuElement(orderClass);
                        if (menuEl) {
                            var previewClass = previewClassPrefix + String(id).replace(/[^a-zA-Z0-9_-]/g, '-');
                            menuEl.classList.add(previewClass);
                            activePreviewClasses[previewClass] = true;
                            css.push('.' + previewClass + ' .mobile_nav .mobile_menu_bar:before{' + declaration + '}');
                        }
                        css.push('.' + orderClass + ' .mobile_nav .mobile_menu_bar:before{' + declaration + '}');
                    }
                } catch (innerErr) { /* ignore per-module errors */ }
            });

            cleanupPreviewClasses(activePreviewClasses);
            updatePreviewStyles(css.join(String.fromCharCode(10)));
        } catch (e) { /* ignore store access errors */ }
    }

    function getIconValue(attrs) {
        if (!attrs || !attrs[attrName]) {
            return null;
        }

        var attr = toPlain(attrs[attrName]);
        var candidates = [
            attr && attr.desktop && attr.desktop.value,
            attr && attr.value,
            attr
        ];

        for (var i = 0; i < candidates.length; i++) {
            var icon = normalizeIconValue(candidates[i]);
            if (icon) {
                return icon;
            }
        }

        return null;
    }

    function normalizeIconValue(value) {
        value = toPlain(value);

        if (typeof value === 'string') {
            return value.trim() === '' ? null : { value: value };
        }

        if (!value || typeof value !== 'object') {
            return null;
        }

        var preferredKeys = ['unicode', 'icon', 'char', 'code', 'value', 'settings', 'desktop', 'tablet', 'phone', 'innerContent'];
        for (var i = 0; i < preferredKeys.length; i++) {
            var key = preferredKeys[i];
            if (!Object.prototype.hasOwnProperty.call(value, key)) {
                continue;
            }
            if (key === 'unicode' || key === 'char' || key === 'code') {
                return value;
            }
            var nested = key === 'desktop' || key === 'tablet' || key === 'phone'
                ? normalizeIconValue(value[key] && value[key].value)
                : normalizeIconValue(value[key]);
            if (nested) {
                return copyIconMeta(nested, value);
            }
        }

        if (value.decodedUnicode || value.iconUnicode) {
            return value;
        }

        return null;
    }

    function iconDeclaration(icon) {
        icon = toPlain(icon);

        if (!icon || typeof icon !== 'object') {
            return '';
        }

        var unicode = icon.unicode || icon.decodedUnicode || icon.iconUnicode || icon.value;
        var content = cssContent(unicode);
        if (!content) {
            return '';
        }

        var iconType = icon.type || icon.iconType || icon.font || '';

        var declarations = [
            'content: ' + content + ' !important',
            'font-family: "' + cssString(iconType === 'fa' ? 'FontAwesome' : 'ETmodules') + '" !important'
        ];

        if (icon.weight && /^\d+$/.test(String(icon.weight))) {
            declarations.push('font-weight: ' + parseInt(icon.weight, 10) + ' !important');
        }

        return declarations.join('; ') + ';';
    }

    function copyIconMeta(icon, source) {
        if (!icon || !source || typeof icon !== 'object' || typeof source !== 'object') {
            return icon;
        }

        ['type', 'iconType', 'font', 'weight'].forEach(function(key) {
            if ((icon[key] === undefined || icon[key] === '') && source[key] !== undefined && source[key] !== '') {
                icon[key] = source[key];
            }
        });

        return icon;
    }

    function cssContent(unicode) {
        unicode = String(unicode || '').trim();
        if (!unicode) {
            return '';
        }
        var backslash = String.fromCharCode(92);

        var entityMatch = unicode.match(/^&(?:amp;)?#x([a-fA-F0-9]{1,6});?$/);
        if (entityMatch) {
            return "'" + backslash + entityMatch[1].toLowerCase() + "'";
        }

        if (unicode.charAt(0) === backslash && /^[a-fA-F0-9]{1,6}$/.test(unicode.slice(1))) {
            return "'" + backslash + unicode.slice(1).toLowerCase() + "'";
        }

        var hexMatch = unicode.match(/^[a-fA-F0-9]{1,6}$/);
        if (hexMatch) {
            return "'" + backslash + unicode.toLowerCase() + "'";
        }

        return "'" + cssString(unicode) + "'";
    }

    function updatePreviewStyles(css) {
        var documents = getPreviewDocuments();

        for (var i = 0; i < documents.length; i++) {
            var doc = documents[i];
            if (!doc || !doc.head) {
                continue;
            }

            var style = doc.getElementById(styleId);
            if (!css) {
                if (style && style.parentNode) {
                    style.parentNode.removeChild(style);
                }
                continue;
            }

            if (!style) {
                style = doc.createElement('style');
                style.id = styleId;
                doc.head.appendChild(style);
            }

            if (style.textContent !== css) {
                style.textContent = css;
            }
        }
    }

    function getPreviewDocuments() {
        var documents = [document];
        var frames = document.querySelectorAll('iframe');

        for (var i = 0; i < frames.length; i++) {
            try {
                if (frames[i].contentDocument) {
                    documents.push(frames[i].contentDocument);
                }
            } catch (e) { /* ignore cross-origin frames */ }
        }

        return documents;
    }

    function findMenuElement(orderClass) {
        var documents = getPreviewDocuments();

        for (var i = 0; i < documents.length; i++) {
            try {
                var menuEl = findMenuElementInDocument(documents[i], orderClass);
                if (menuEl) {
                    return menuEl;
                }
            } catch (e) { /* ignore inaccessible documents */ }
        }

        return null;
    }

    function findMenuElementInDocument(doc, orderClass) {
        if (!doc || !orderClass || !doc.querySelector) {
            return null;
        }

        try {
            return doc.querySelector(normalizeOrderSelector(orderClass));
        } catch (e) {
            return null;
        }
    }

    function normalizeOrderSelector(orderClass) {
        if (!orderClass || typeof orderClass !== 'string') {
            return '';
        }

        orderClass = orderClass.trim();
        if (orderClass.charAt(0) === '.') {
            return orderClass;
        }

        return '.' + orderClass;
    }

    function normalizeOrderClassName(orderClass) {
        if (!orderClass || typeof orderClass !== 'string') {
            return '';
        }

        orderClass = orderClass.trim();
        return orderClass.charAt(0) === '.' ? orderClass.slice(1) : orderClass;
    }

    function closest(el, selector) {
        if (!el) {
            return null;
        }
        if (typeof el.closest === 'function') {
            try {
                return el.closest(selector);
            } catch (e) {
                return null;
            }
        }
        while (el && el.nodeType === 1) {
            if (matches(el, selector)) {
                return el;
            }
            el = el.parentElement;
        }
        return null;
    }

    function matches(el, selector) {
        var fn = el && (el.matches || el.msMatchesSelector);
        if (!fn) {
            return false;
        }
        try {
            return fn.call(el, selector);
        } catch (e) {
            return false;
        }
    }

    function cssIdentifier(value) {
        value = String(value || '').replace(/[^a-zA-Z0-9_-]/g, '-');
        return value || 'module';
    }

    function cleanupPreviewClasses(activePreviewClasses) {
        var documents = getPreviewDocuments();

        for (var i = 0; i < documents.length; i++) {
            try {
                var nodes = documents[i].querySelectorAll('[class*="' + previewClassPrefix + '"]');
                for (var j = 0; j < nodes.length; j++) {
                    var classes = Array.prototype.slice.call(nodes[j].classList || []);
                    for (var k = 0; k < classes.length; k++) {
                        if (classes[k].indexOf(previewClassPrefix) === 0 && !activePreviewClasses[classes[k]]) {
                            nodes[j].classList.remove(classes[k]);
                        }
                    }
                }
            } catch (e) { /* ignore inaccessible documents */ }
        }
    }

    function getStoreData() {
        if (window.vendor && window.vendor.wp && window.vendor.wp.data) {
            return window.vendor.wp.data;
        }
        if (window.wp && window.wp.data) {
            return window.wp.data;
        }
        return null;
    }

    function selectStore(storeName) {
        var data = getStoreData();
        if (!data || typeof data.select !== 'function') {
            return null;
        }
        try {
            return data.select(storeName);
        } catch (e) {
            return null;
        }
    }

    function subscribePreview() {
        if (previewSubscribed) {
            return;
        }

        var data = getStoreData();
        if (!data || typeof data.subscribe !== 'function') {
            return;
        }

        previewSubscribed = true;
        try {
            data.subscribe(schedulePreview);
        } catch (e) {
            previewSubscribed = false;
        }
    }

    function toPlain(value) {
        if (!value) {
            return value;
        }
        if (typeof value.asMutable === 'function') {
            try {
                return value.asMutable({ deep: true });
            } catch (e) {
                try {
                    return value.asMutable();
                } catch (ignore) {}
            }
        }
        if (typeof value.toJS === 'function') {
            try {
                return value.toJS();
            } catch (e) {}
        }
        return value;
    }

    function cssString(value) {
        var backslash = String.fromCharCode(92);
        return String(value || '')
            .split(backslash).join(backslash + backslash)
            .split('"').join(backslash + '"')
            .split("'").join(backslash + "'")
            .split(String.fromCharCode(10)).join(backslash + 'a ')
            .split(String.fromCharCode(13)).join(backslash + 'd ')
            .split(String.fromCharCode(12)).join(backslash + 'c ');
    }

    hooks.addAction('divi.editPost.store.content.change', 'divibooster.menuMobileIcon', schedulePreview);
    window.addEventListener('resize', schedulePreview);
    document.addEventListener('DOMContentLoaded', schedulePreview);
    subscribePreview();
    window.setTimeout(schedulePreview, 250);
})();
JS;
}

// === Attribute and value helpers ===

// Describe the Divi 5 icon picker field.
function get_divi5_attr_definition()
{
    return array(
        'type' => 'object',
        'settings' => array(
            'innerContent' => array(
                'groupType' => 'group-items',
                'items' => array(
                    'dbMobileMenuIconPicker' => array(
                        'groupSlug' => 'designIcons',
                        'attrName' => D5_ATTR,
                        'label' => esc_html__('Mobile Menu Icon', 'divi-booster'),
                        'description' => esc_html__('Choose an icon for the mobile menu button. Leave unset to use the default hamburger icon.', 'divi-booster'),
                        'features' => array(
                            'hover' => false,
                            'sticky' => false,
                            'responsive' => false,
                            'preset' => 'content',
                        ),
                        'render' => true,
                        'priority' => 35,
                        'component' => array(
                            'type' => 'field',
                            'name' => 'divi/icon-picker',
                            'props' => array(),
                        ),
                        'defaultAttr' => array(
                            'desktop' => array('value' => array()),
                        ),
                    ),
                ),
            ),
        ),
    );
}

// Return the saved Divi 4 icon value.
function get_divi4_icon_value($props)
{
    if (!is_array($props)) {
        return '';
    }

    $value = $props[D4_FIELD] ?? '';

    return is_string($value) ? trim($value) : '';
}

// Return the saved Divi 5 icon-picker value.
function get_divi5_icon_value($attrs)
{
    if (!is_array($attrs)) {
        return array();
    }

    $value = $attrs[D5_ATTR]['desktop']['value'] ?? array();

    if (isset($value['icon']) && is_array($value['icon'])) {
        return $value['icon'];
    }

    return is_array($value) ? $value : array();
}

// Convert Divi 4 icon-picker values into a CSS declaration.
function icon_declaration_from_divi4_value($icon)
{
    if (!is_string($icon) || trim($icon) === '') {
        return '';
    }

    $font_family = function_exists('et_pb_get_icon_font_family') ? \et_pb_get_icon_font_family($icon) : 'ETmodules';
    $font_weight = function_exists('et_pb_get_icon_font_weight') ? \et_pb_get_icon_font_weight($icon) : '';
    $content = divi4_icon_content($icon);

    if ($content === '') {
        return '';
    }

    return build_icon_declaration($content, $font_family, $font_weight);
}

// Convert Divi 5 icon-picker values into a CSS declaration.
function icon_declaration_from_divi5_value($icon)
{
    if (!is_array($icon) || empty($icon)) {
        return '';
    }

    if (class_exists('\\ET\\Builder\\Packages\\StyleLibrary\\Declarations\\Icon\\Icon')) {
        $declaration = \ET\Builder\Packages\StyleLibrary\Declarations\Icon\Icon::style_declaration(array(
            'attrValue' => $icon,
            'important' => array(
                'content' => true,
                'font-family' => true,
                'font-weight' => true,
            ),
        ));

        return is_string($declaration) ? $declaration : '';
    }

    return '';
}

// Build the CSS content value for a Divi 4 icon.
function divi4_icon_content($icon)
{
    if (function_exists('et_pb_maybe_extended_icon') &&
        function_exists('et_pb_get_extended_icon_value_for_css') &&
        \et_pb_maybe_extended_icon($icon)) {
        return normalize_css_content(\et_pb_get_extended_icon_value_for_css($icon));
    }

    if (function_exists('et_sanitize_font_icon') && function_exists('et_pb_get_font_icon_symbols')) {
        $sanitized = \et_sanitize_font_icon($icon);
        if ($sanitized === '') {
            return '';
        }
        $icon = $sanitized;
    }

    if (!function_exists('et_pb_process_font_icon')) {
        return '';
    }

    $processed = html_entity_decode(\et_pb_process_font_icon($icon), ENT_QUOTES, 'UTF-8');
    if (!is_string($processed) || $processed === '') {
        return '';
    }

    return "'" . css_string($processed) . "'";
}

// Format the icon declaration for the hamburger pseudo-element.
function build_icon_declaration($content, $font_family, $font_weight = '')
{
    if (!is_string($content) || $content === '') {
        return '';
    }

    $declarations = array(
        'content: ' . $content . ' !important',
        'font-family: "' . css_string((string) $font_family) . '" !important',
    );

    if ($font_weight !== '' && is_numeric($font_weight)) {
        $declarations[] = 'font-weight: ' . (int) $font_weight . ' !important';
    }

    return implode('; ', $declarations) . ';';
}

// Scope a declaration to the module's hamburger icon.
function build_icon_css($order_class, $declaration)
{
    if (!is_string($order_class) || !preg_match('/^et_pb_menu_\d+(?:_tb_[a-z]+)?$/', $order_class) || !is_string($declaration) || $declaration === '') {
        return '';
    }

    return '.' . $order_class . ' ' . HAMBURGER_SELECTOR . '{' . $declaration . '}';
}

// Normalize Divi's quoted CSS content helper output.
function normalize_css_content($content)
{
    if (!is_string($content)) {
        return '';
    }

    $content = trim($content);

    return preg_match('/^[\'"]\\\\[a-fA-F0-9]{1,6}\s?[\'"]$/', $content) ? $content : '';
}

// Escape a string for a CSS quoted string.
function css_string($value)
{
    return str_replace(
        array('\\', '"', "'", "\n", "\r", "\f"),
        array('\\\\', '\\"', "\\'", '\\a ', '\\d ', '\\c '),
        (string) $value
    );
}

// Encode data for interpolation into an inline script block.
function json_for_inline_script($value)
{
    $flags = JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;
    $json = function_exists('wp_json_encode') ? wp_json_encode($value, $flags) : json_encode($value, $flags);

    return is_string($json) ? $json : 'null';
}

// Extract the module order class from rendered markup.
function extract_order_class($html)
{
    if (!is_string($html) || $html === '') {
        return '';
    }

    return preg_match('/\bet_pb_menu_\d+(?:_tb_[a-z]+)?\b/', $html, $matches) ? $matches[0] : '';
}
