<?php
namespace DiviBooster\Divi5\Chart\AxisLabelFonts;

const GROUP_SLUG        = 'diviboosterAxisLabels';
const X_AXIS_FONT_ATTR  = 'diviboosterXAxisLabelFont';
const Y_AXIS_FONT_ATTR  = 'diviboosterYAxisLabelFont';
const SCRIPT_HANDLE     = 'divibooster-divi5-chart-axis-label-fonts';
const SCRIPT_NAMESPACE  = 'divibooster/chart-axis-label-fonts';
const RUNTIME_ACTION    = 'divibooster_chart_axis_label_fonts_runtime';

// === Chart axis support ===
// Chart types supported by axis-label styling; an unset type uses Line behavior.
const AXIS_LABEL_CHART_TYPES = array('line', 'area', 'bar', 'scatter', 'bubble');



if (function_exists('add_filter')) {
    add_filter('block_type_metadata_settings', __NAMESPACE__ . '\register_chart_axis_label_font_attrs');

    foreach (get_chart_module_slugs() as $chart_module_slug) {
        add_filter('render_block_' . $chart_module_slug, __NAMESPACE__ . '\add_axis_label_font_data_to_chart_output', 10, 3);
    }
}

if (function_exists('add_action')) {
    add_action('divi_visual_builder_assets_before_enqueue_app_window_scripts', __NAMESPACE__ . '\enqueue_visual_builder_script');
    add_action('wp_ajax_' . RUNTIME_ACTION, __NAMESPACE__ . '\output_runtime_asset');
    add_action('wp_ajax_nopriv_' . RUNTIME_ACTION, __NAMESPACE__ . '\output_runtime_asset');
    add_action('wp_enqueue_scripts', __NAMESPACE__ . '\register_frontend_script');
}

// === Server-side integration ===

function register_chart_axis_label_font_attrs($settings) {
    if (!is_array($settings)) {
        return $settings;
    }

    $module_name       = isset($settings['name']) ? $settings['name'] : '';
    $module_attributes = isset($settings['attributes']) ? $settings['attributes'] : false;

    if (
        !in_array($module_name, get_chart_module_slugs(), true) ||
        !is_array($module_attributes) ||
        empty($module_attributes)
    ) {
        return $settings;
    }

    foreach (array(
        X_AXIS_FONT_ATTR => 'X Axis Label',
        Y_AXIS_FONT_ATTR => 'Y Axis Label',
    ) as $attr_name => $field_label) {
        $settings['attributes'][$attr_name] = get_axis_font_attribute_definition(__($field_label, 'divi-booster'), $attr_name);
    }

    if (!isset($settings['settings']) || !is_array($settings['settings'])) {
        $settings['settings'] = array();
    }

    if (!isset($settings['settings']['groups']) || !is_array($settings['settings']['groups'])) {
        $settings['settings']['groups'] = array();
    }

    $settings['settings']['groups'][GROUP_SLUG] = get_axis_labels_group_definition();

    return $settings;
}

function is_visual_builder() {
    if (!function_exists('et_builder_d5_enabled') || !function_exists('et_core_is_fb_enabled')) {
        return false;
    }

    try {
        return \et_builder_d5_enabled() && \et_core_is_fb_enabled();
    } catch (\Throwable $exception) {
        return false;
    }
}

function get_runtime_asset_url($builder_mode) {
    return add_query_arg(
        array(
            'action'  => RUNTIME_ACTION,
            'builder' => $builder_mode ? '1' : '0',
        ),
        admin_url('admin-ajax.php')
    );
}

function get_runtime_asset_version() {
    $version = filemtime(__FILE__);

    return false === $version ? '1' : (string) $version;
}

function register_frontend_script() {
    if (is_visual_builder() || wp_script_is(SCRIPT_HANDLE, 'registered')) {
        return;
    }

    wp_register_script(
        SCRIPT_HANDLE,
        get_runtime_asset_url(false),
        array(),
        get_runtime_asset_version(),
        true
    );
}

function enqueue_frontend_script() {
    if (is_visual_builder()) {
        return;
    }

    if (!wp_script_is(SCRIPT_HANDLE, 'registered')) {
        register_frontend_script();
    }

    if (wp_script_is(SCRIPT_HANDLE, 'registered')) {
        wp_enqueue_script(SCRIPT_HANDLE);
    }
}

function output_runtime_asset() {
    $builder_mode = !empty($_GET['builder']);

    $charset = get_option('blog_charset');

    if (!is_string($charset) || !preg_match('/^[A-Za-z0-9._-]+$/', $charset)) {
        $charset = 'UTF-8';
    }

    status_header(200);
    header('Content-Type: application/javascript; charset=' . $charset);
    header('Cache-Control: public, max-age=31536000, immutable');
    header('X-Content-Type-Options: nosniff');

    echo get_chart_runtime_js($builder_mode);
    exit;
}

function enqueue_visual_builder_script() {
    if (!is_visual_builder()) {
        return;
    }

    // Load the builder integration only when its hooks bundle is registered.
    if (!wp_script_is('divi-vendor-wp-hooks', 'registered')) {
        return;
    }

    if (!wp_script_is(SCRIPT_HANDLE, 'registered')) {
        wp_register_script(
            SCRIPT_HANDLE,
            get_runtime_asset_url(true),
            array('divi-vendor-wp-hooks'),
            get_runtime_asset_version(),
            false
        );
    }

    wp_enqueue_script(SCRIPT_HANDLE);

    $inline_js = get_visual_builder_inline_js();

    if ('' !== $inline_js && function_exists('wp_add_inline_script')) {
        wp_add_inline_script(SCRIPT_HANDLE, $inline_js);
    }
}

// Add serialized axis styles to chart markup for the runtime.
function add_axis_label_font_data_to_chart_output($block_content, $parsed_block, $block) {
    if (!is_string($block_content) || '' === $block_content) {
        return $block_content;
    }

    $attrs       = is_array($parsed_block) && isset($parsed_block['attrs']) && is_array($parsed_block['attrs']) ? $parsed_block['attrs'] : array();
    $font_styles = get_axis_font_styles_from_attrs($attrs);

    if (empty($font_styles)) {
        return $block_content;
    }

    enqueue_frontend_script();

    if (
        !class_exists('WP_HTML_Tag_Processor') ||
        !method_exists('WP_HTML_Tag_Processor', 'next_tag') ||
        !method_exists('WP_HTML_Tag_Processor', 'set_attribute') ||
        !method_exists('WP_HTML_Tag_Processor', 'get_updated_html') ||
        !function_exists('wp_json_encode')
    ) {
        return $block_content;
    }

    try {
        $json = wp_json_encode($font_styles, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

        if (false === $json || !is_string($json)) {
            return $block_content;
        }

        $processor = new \WP_HTML_Tag_Processor($block_content);

        if (!$processor->next_tag(array('class_name' => 'et_pb_charts'))) {
            return $block_content;
        }

        $processor->set_attribute('data-divibooster-chart-axis-label-fonts', $json);

        return $processor->get_updated_html();
    } catch (\Throwable $exception) {
        return $block_content;
    }
}


// === Visual Builder integration ===

function get_visual_builder_inline_js() {
    if (!function_exists('wp_json_encode')) {
        return '';
    }

    $json_flags   = JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;
    $module_slugs = wp_json_encode(get_chart_module_slugs(), $json_flags);
    $group_slug   = wp_json_encode(GROUP_SLUG, $json_flags);
    $group_def    = wp_json_encode(get_axis_labels_group_definition(), $json_flags);
    $x_attr_slug  = wp_json_encode(X_AXIS_FONT_ATTR, $json_flags);
    $y_attr_slug  = wp_json_encode(Y_AXIS_FONT_ATTR, $json_flags);
    $x_attr_def   = wp_json_encode(get_axis_font_attribute_definition(__('X Axis Label', 'divi-booster'), X_AXIS_FONT_ATTR), $json_flags);
    $y_attr_def   = wp_json_encode(get_axis_font_attribute_definition(__('Y Axis Label', 'divi-booster'), Y_AXIS_FONT_ATTR), $json_flags);
    $namespace    = wp_json_encode(SCRIPT_NAMESPACE, $json_flags);

    if (
        false === $module_slugs ||
        false === $group_slug ||
        false === $group_def ||
        false === $x_attr_slug ||
        false === $y_attr_slug ||
        false === $x_attr_def ||
        false === $y_attr_def ||
        false === $namespace
    ) {
        return '';
    }

    return <<<JS
(function() {
    if (!window.vendor || !window.vendor.wp || !window.vendor.wp.hooks) {
        return;
    }

    var chartModuleSlugs = {$module_slugs};
    var groupSlug = {$group_slug};
    var groupDefinition = {$group_def};
    var xAttrSlug = {$x_attr_slug};
    var yAttrSlug = {$y_attr_slug};
    var xAttrDefinition = {$x_attr_def};
    var yAttrDefinition = {$y_attr_def};
    var hookNamespace = {$namespace};
    var addFilter = window.vendor.wp.hooks.addFilter;

    function hookSuffix(moduleSlug) {
        return String(moduleSlug).replace(/\//g, '.');
    }

    chartModuleSlugs.forEach(function(moduleSlug) {
        var suffix = hookSuffix(moduleSlug);

        addFilter('divi.moduleLibrary.moduleSettings.groups.' + suffix, hookNamespace, function(groups) {
            groups = groups || {};
            groups[groupSlug] = JSON.parse(JSON.stringify(groupDefinition));
            return groups;
        });

        addFilter('divi.moduleLibrary.moduleAttributes.' + suffix, hookNamespace, function(attributes) {
            attributes = attributes || {};
            attributes[xAttrSlug] = xAttrDefinition;
            attributes[yAttrSlug] = yAttrDefinition;
            return attributes;
        });
    });

    addFilter('divi.module.wrapper.render', hookNamespace, function(moduleWrapper, param) {
        param = param || {};

        if (chartModuleSlugs.indexOf(param.name) === -1 || !moduleWrapper || !moduleWrapper.props) {
            return moduleWrapper;
        }

        var styles = window.DiviBoosterChartAxisLabels && window.DiviBoosterChartAxisLabels.getStylesFromBuilderAttrs
            ? window.DiviBoosterChartAxisLabels.getStylesFromBuilderAttrs(param.attrs || {}, xAttrSlug, yAttrSlug)
            : {};

        if (!styles || (!styles.x && !styles.y)) {
            return moduleWrapper;
        }

        var element = window.vendor.wp && window.vendor.wp.element ? window.vendor.wp.element : null;

        if (!element || !element.cloneElement) {
            return moduleWrapper;
        }

        var newProps = Object.assign({}, moduleWrapper.props);
        var htmlAttrs = Object.assign({}, moduleWrapper.props.htmlAttrs || {}, {
            'data-divibooster-chart-axis-label-fonts': JSON.stringify(styles)
        });

        // Pass the data attribute through the wrapper's DOM attribute map.
        newProps.htmlAttrs = htmlAttrs;

        setTimeout(function() {
            if (window.DiviBoosterChartAxisLabels && window.DiviBoosterChartAxisLabels.applyAll) {
                window.DiviBoosterChartAxisLabels.applyAll();
            }
        }, 80);

        return element.cloneElement(moduleWrapper, newProps, moduleWrapper.props.children);
    });
})();
JS;
}

function get_axis_font_attribute_definition($field_label, $attr_name) {
    $hidden_chart_type_condition = get_axis_labels_hidden_chart_type_condition();

    return array(
        'type'     => 'object',
        'selector' => '{{selector}}',
        'show_if_not' => $hidden_chart_type_condition,
        'settings' => array(
            'decoration' => array(
                'font' => array(
                    'groupType' => 'group-item',
                    'item'      => array(
                        'groupSlug' => GROUP_SLUG,
                        'priority'  => 10,
                        'render'    => true,
                        'show_if_not' => $hidden_chart_type_condition,
                        'component' => array(
                            'name'  => 'divi/font-chart-js',
                            'type'  => 'group',
                            'props' => array(
                                'attrName'         => $attr_name,
                                'grouped'          => false,
                                'fieldLabel'       => $field_label,
                                'supportsPresets'  => false,
                                'fields'           => array(
                                    'style' => array('render' => false),
                                    'fontStyle' => array('render' => false),
                                    'lineHeight' => array('render' => false),
                                    'textAlign' => array('render' => false),
                                ),
                            ),
                        ),
                    ),
                ),
            ),
        ),
    );
}

function get_axis_labels_group_definition() {
    return array(
        'groupName'     => GROUP_SLUG,
        'panel'         => 'design',
        'priority'      => 35,
        'multiElements' => true,
        'show_if_not'   => get_axis_labels_hidden_chart_type_condition(),
        'component'     => array(
            'name'  => 'divi/composite',
            'props' => array(
                'groupLabel' => __('Axis Labels', 'divi-booster'),
            ),
        ),
    );
}

// Return a condition that hides controls for non-axis types; unset types remain visible.
function get_axis_labels_hidden_chart_type_condition() {
    return array(
        'chart.advanced.config.type' => array('radar', 'pie', 'doughnut', 'polarArea'),
    );
}

function get_axis_font_styles_from_attrs($attrs) {
    if (!is_array($attrs) || empty($attrs)) {
        return array();
    }

    $styles = array();

    foreach (array(
        'x' => X_AXIS_FONT_ATTR,
        'y' => Y_AXIS_FONT_ATTR,
    ) as $axis => $attr_name) {
        $axis_styles = get_responsive_font_styles(isset($attrs[$attr_name]) ? $attrs[$attr_name] : array());

        if (!empty($axis_styles)) {
            $styles[$axis] = $axis_styles;
        }
    }

    return $styles;
}

function get_responsive_font_styles($attr) {
    if (!is_array($attr) || empty($attr)) {
        return array();
    }

    $styles = array();

    foreach (array('desktop', 'tablet', 'phone') as $device) {
        $font_value = get_font_value_for_device($attr, $device);
        $normalized = normalize_font_value($font_value);

        if (!empty($normalized)) {
            $styles[$device] = $normalized;
        }
    }

    return $styles;
}

function get_font_value_for_device($attr, $device) {
    $paths = array(
        array('decoration', 'font', 'font', $device, 'value'),
        array('decoration', 'font', $device, 'value'),
        array('font', $device, 'value'),
        array($device, 'value'),
    );

    foreach ($paths as $path) {
        $value = get_array_path($attr, $path);

        if (is_array($value) && !empty($value)) {
            return $value;
        }
    }

    return array();
}

function normalize_font_value($value) {
    if (!is_array($value) || empty($value)) {
        return array();
    }

    $style = array();

    $map = array(
        'family'     => array('family', 'fontFamily', 'font_family'),
        'weight'     => array('weight', 'fontWeight', 'font_weight'),
        'style'      => array('style', 'fontStyle', 'font_style'),
        'color'      => array('color', 'textColor', 'text_color'),
        'size'       => array('size', 'fontSize', 'font_size'),
        'lineHeight' => array('lineHeight', 'line_height'),
    );

    foreach ($map as $target_key => $source_keys) {
        foreach ($source_keys as $source_key) {
            if (isset($value[$source_key]) && '' !== $value[$source_key] && null !== $value[$source_key]) {
                $style[$target_key] = sanitize_font_style_value($value[$source_key]);
                break;
            }
        }
    }

    return array_filter($style, function($item) {
        return '' !== $item && null !== $item && array() !== $item;
    });
}

function sanitize_font_style_value($value) {
    if (is_array($value)) {
        $sanitized = array();

        foreach ($value as $key => $item) {
            if (is_scalar($item)) {
                $sanitized[sanitize_key((string) $key)] = sanitize_text_field((string) $item);
            }
        }

        return $sanitized;
    }

    if (is_scalar($value)) {
        return sanitize_text_field((string) $value);
    }

    return '';
}

function get_array_path($array, $path) {
    if (!is_array($array) || !is_array($path)) {
        return null;
    }

    $current = $array;

    foreach ($path as $key) {
        if ((!is_int($key) && !is_string($key)) || !is_array($current) || !array_key_exists($key, $current)) {
            return null;
        }

        $current = $current[$key];
    }

    return $current;
}

// === Front-end runtime ===

function get_chart_runtime_js($builder_mode) {
    $builder_mode_json   = $builder_mode ? 'true' : 'false';
    $x_attr_slug         = wp_json_encode(X_AXIS_FONT_ATTR);
    $y_attr_slug         = wp_json_encode(Y_AXIS_FONT_ATTR);
    $axis_chart_types                  = wp_json_encode(AXIS_LABEL_CHART_TYPES);
    $default_chart_label               = wp_json_encode(__('Chart', 'divi-booster'));
    $default_dataset_label             = wp_json_encode(__('Data set', 'divi-booster'));
    $accessibility_label_format        = wp_json_encode(__('%1$s: %2$s', 'divi-booster'));
    $accessibility_description_format  = wp_json_encode(__('%1$s: %2$s.', 'divi-booster'));
    $x_coordinate_label                = wp_json_encode(__('x', 'divi-booster'));
    $y_coordinate_label                = wp_json_encode(__('y', 'divi-booster'));
    $radius_coordinate_label           = wp_json_encode(__('radius', 'divi-booster'));

    if (
        false === $x_attr_slug ||
        false === $y_attr_slug ||
        false === $axis_chart_types ||
        false === $default_chart_label ||
        false === $default_dataset_label ||
        false === $accessibility_label_format ||
        false === $accessibility_description_format ||
        false === $x_coordinate_label ||
        false === $y_coordinate_label ||
        false === $radius_coordinate_label
    ) {
        return '';
    }

    return <<<JS
(function() {
    if (window.DiviBoosterChartAxisLabels && window.DiviBoosterChartAxisLabels.initialized) {
        return;
    }

    var xAttrSlug = {$x_attr_slug};
    var yAttrSlug = {$y_attr_slug};
    var axisLabelChartTypes = {$axis_chart_types};
    var defaultChartLabel = {$default_chart_label};
    var defaultDatasetLabel = {$default_dataset_label};
    var accessibilityLabelFormat = {$accessibility_label_format};
    var accessibilityDescriptionFormat = {$accessibility_description_format};
    var xCoordinateLabel = {$x_coordinate_label};
    var yCoordinateLabel = {$y_coordinate_label};
    var radiusCoordinateLabel = {$radius_coordinate_label};
    var builderMode = {$builder_mode_json};
    var retryCount = 0;
    var maxRetries = builderMode ? 0 : 50;
    var resizeTimer = null;
    var accessibilityId = 0;

    window.DiviBoosterChartAxisLabels = {
        initialized: true,
        applyAll: applyAll,
        getStylesFromBuilderAttrs: getStylesFromBuilderAttrs
    };

    function applyAll() {
        var modules = document.querySelectorAll('[data-divibooster-chart-axis-label-fonts]');
        var appliedAny = false;

        for (var i = 0; i < modules.length; i++) {
            var styles = parseStyles(modules[i].getAttribute('data-divibooster-chart-axis-label-fonts'));

            if (!styles || (!styles.x && !styles.y)) {
                continue;
            }

            var charts = findChartInstances(modules[i]);

            for (var j = 0; j < charts.length; j++) {
                ensureChartAccessibility(charts[j]);

                if (applyStylesToChart(charts[j], styles)) {
                    appliedAny = true;
                }
            }
        }

        return appliedAny;
    }

    function parseStyles(value) {
        if (!value) {
            return null;
        }

        try {
            return JSON.parse(value);
        } catch (e) {
            return null;
        }
    }

    function formatAccessibilityText(format, values) {
        return String(format || '').replace(/%([0-9]+)\$s/g, function(match, index) {
            var value = values[parseInt(index, 10) - 1];

            return undefined === value ? match : value;
        });
    }

    function getStylesFromBuilderAttrs(attrs, xSlug, ySlug) {
        var styles = {};
        var xStyles = getResponsiveFontStyles(readBuilderAttr(attrs, xSlug || xAttrSlug));
        var yStyles = getResponsiveFontStyles(readBuilderAttr(attrs, ySlug || yAttrSlug));

        if (hasStyle(xStyles)) {
            styles.x = xStyles;
        }

        if (hasStyle(yStyles)) {
            styles.y = yStyles;
        }

        return styles;
    }

    function readBuilderAttr(attrs, slug) {
        if (!attrs || !slug) {
            return null;
        }

        var paths = [
            [slug],
            ['module', slug],
            ['attrs', slug],
            ['attributes', slug],
            ['module', 'attributes', slug]
        ];

        for (var i = 0; i < paths.length; i++) {
            var value = getPath(attrs, paths[i]);

            if (value) {
                return value;
            }
        }

        return null;
    }

    function getResponsiveFontStyles(attr) {
        var styles = {};
        ['desktop', 'tablet', 'phone'].forEach(function(device) {
            var value = getFontValueForDevice(attr, device);
            var normalized = normalizeFontValue(value);

            if (hasStyle(normalized)) {
                styles[device] = normalized;
            }
        });

        return styles;
    }

    function getFontValueForDevice(attr, device) {
        var paths = [
            ['decoration', 'font', 'font', device, 'value'],
            ['decoration', 'font', device, 'value'],
            ['font', device, 'value'],
            [device, 'value']
        ];

        for (var i = 0; i < paths.length; i++) {
            var value = getPath(attr, paths[i]);

            if (value && typeof value === 'object') {
                return value;
            }
        }

        return {};
    }

    function normalizeFontValue(value) {
        if (!value || typeof value !== 'object') {
            return {};
        }

        var style = {};
        var sourceMap = {
            family: ['family', 'fontFamily', 'font_family'],
            weight: ['weight', 'fontWeight', 'font_weight'],
            style: ['style', 'fontStyle', 'font_style'],
            color: ['color', 'textColor', 'text_color'],
            size: ['size', 'fontSize', 'font_size'],
            lineHeight: ['lineHeight', 'line_height']
        };

        Object.keys(sourceMap).forEach(function(targetKey) {
            var sourceKeys = sourceMap[targetKey];

            for (var i = 0; i < sourceKeys.length; i++) {
                if (value[sourceKeys[i]] !== undefined && value[sourceKeys[i]] !== null && value[sourceKeys[i]] !== '') {
                    style[targetKey] = value[sourceKeys[i]];
                    break;
                }
            }
        });

        return style;
    }

    function getPath(obj, path) {
        var current = obj;

        for (var i = 0; i < path.length; i++) {
            if (!current || typeof current !== 'object') {
                return undefined;
            }

            if (typeof current.has === 'function' && current.has(path[i])) {
                current = current.get(path[i]);
            } else if (Object.prototype.hasOwnProperty.call(current, path[i])) {
                current = current[path[i]];
            } else {
                return undefined;
            }
        }

        return current && typeof current.toJS === 'function' ? current.toJS() : current;
    }

    function hasStyle(style) {
        if (!style || typeof style !== 'object') {
            return false;
        }

        return Object.keys(style).some(function(key) {
            var value = style[key];
            return value !== undefined && value !== null && value !== '' && (!(typeof value === 'object') || Object.keys(value).length > 0);
        });
    }

    function ensureChartAccessibility(chart) {
        var canvas = chart && (chart.canvas || (chart.ctx && chart.ctx.canvas));

        if (!canvas || typeof canvas.getAttribute !== 'function' || typeof canvas.setAttribute !== 'function') {
            return;
        }

        if (String(canvas.getAttribute('aria-hidden') || '').toLowerCase() === 'true') {
            return;
        }

        var role = String(canvas.getAttribute('role') || '').toLowerCase();

        if (role && 'img' !== role) {
            return;
        }

        if (typeof canvas.textContent === 'string' && canvas.textContent.trim()) {
            return;
        }

        if (!role) {
            canvas.setAttribute('role', 'img');
        }

        var ariaLabel = canvas.getAttribute('aria-label');
        var labelledBy = canvas.getAttribute('aria-labelledby');
        var title = canvas.getAttribute('title');
        var hasAccessibleName = !!(
            (ariaLabel && ariaLabel.trim()) ||
            (labelledBy && labelledBy.trim()) ||
            (title && title.trim())
        );
        var generatedName = canvas.__diviboosterChartAccessibilityGeneratedName === true;

        // Preserve author-provided semantics; add a fallback only when absent.
        if (hasAccessibleName && !generatedName) {
            return;
        }

        if (!hasAccessibleName) {
            canvas.setAttribute('aria-label', getChartAccessibilityName(chart) || defaultChartLabel || 'Chart');
            canvas.__diviboosterChartAccessibilityGeneratedName = true;
        }

        var descriptionText = getChartAccessibilityDescription(chart);
        var descriptionElement = canvas.__diviboosterChartAccessibilityDescription;
        var describedBy = canvas.getAttribute('aria-describedby');

        if (!descriptionText || (describedBy && (!descriptionElement || describedBy !== descriptionElement.id))) {
            return;
        }

        var ownerDocument = canvas.ownerDocument || document;

        if (!ownerDocument || !canvas.parentNode || typeof canvas.parentNode.appendChild !== 'function') {
            return;
        }

        if (!descriptionElement || typeof descriptionElement.setAttribute !== 'function') {
            descriptionElement = ownerDocument.createElement('span');
            var descriptionId = 'divibooster-chart-accessibility-' + accessibilityId++;

            while (ownerDocument.getElementById && ownerDocument.getElementById(descriptionId)) {
                descriptionId = 'divibooster-chart-accessibility-' + accessibilityId++;
            }

            descriptionElement.id = descriptionId;
            descriptionElement.setAttribute('style', 'position:absolute !important; width:1px !important; height:1px !important; padding:0 !important; margin:-1px !important; overflow:hidden !important; clip:rect(0, 0, 0, 0) !important; clip-path:inset(50%) !important; white-space:nowrap !important; border:0 !important;');
            canvas.__diviboosterChartAccessibilityDescription = descriptionElement;
        }

        if (!descriptionElement.parentNode) {
            canvas.parentNode.appendChild(descriptionElement);
        }

        descriptionElement.textContent = descriptionText;
        canvas.setAttribute('aria-describedby', descriptionElement.id);
    }

    function getChartData(chart) {
        return chart && chart.config && chart.config.data
            ? chart.config.data
            : (chart && chart.data ? chart.data : null);
    }

    function getChartAccessibilityName(chart) {
        var title = getChartTitle(chart);

        if (title) {
            return title;
        }

        var data = getChartData(chart);
        var datasetLabels = [];

        if (data && Array.isArray(data.datasets)) {
            data.datasets.forEach(function(dataset) {
                var label = dataset && typeof dataset === 'object' ? getAccessibleText(dataset.label) : '';

                if (label && datasetLabels.indexOf(label) === -1) {
                    datasetLabels.push(label);
                }
            });
        }

        var chartLabel = defaultChartLabel;

        return datasetLabels.length
            ? formatAccessibilityText(accessibilityLabelFormat, [chartLabel, datasetLabels.join(', ')])
            : chartLabel;
    }

    function getChartTitle(chart) {
        var options = chart && chart.config && chart.config.options
            ? chart.config.options
            : (chart && chart.options ? chart.options : null);
        var titleConfig = options && options.plugins ? options.plugins.title : null;

        if (!titleConfig && options) {
            titleConfig = options.title;
        }

        if (typeof titleConfig === 'string' || Array.isArray(titleConfig)) {
            return getAccessibleText(titleConfig);
        }

        if (!titleConfig || typeof titleConfig !== 'object' || titleConfig.display === false) {
            return '';
        }

        return getAccessibleText(titleConfig.text);
    }

    function getChartAccessibilityDescription(chart) {
        var data = getChartData(chart);

        if (!data || !Array.isArray(data.datasets)) {
            return '';
        }

        var labels = Array.isArray(data.labels) ? data.labels : [];
        var descriptions = [];

        data.datasets.forEach(function(dataset) {
            if (!dataset || typeof dataset !== 'object' || !Array.isArray(dataset.data)) {
                return;
            }

            var points = [];

            dataset.data.forEach(function(value, index) {
                var pointText = getChartPointText(value);
                var labelText = getAccessibleText(labels[index]);

                if (pointText) {
                    points.push(labelText ? labelText + ': ' + pointText : pointText);
                }
            });

            if (points.length) {
                var datasetLabel = getAccessibleText(dataset.label) || defaultDatasetLabel;
                descriptions.push(formatAccessibilityText(accessibilityDescriptionFormat, [datasetLabel, points.join(', ')]));
            }
        });

        return descriptions.join(' ');
    }

    function getChartPointText(value) {
        if (!value || typeof value !== 'object' || Array.isArray(value)) {
            return getAccessibleText(value);
        }

        var x = getAccessibleText(value.x);
        var y = getAccessibleText(value.y);
        var radius = getAccessibleText(value.r);

        if (x || y) {
            var coordinates = [];

            if (x) {
                coordinates.push('x: ' + x);
            }

            if (y) {
                coordinates.push('y: ' + y);
            }

            if (radius) {
                coordinates.push('radius: ' + radius);
            }

            return coordinates.join(', ');
        }

        if (undefined !== value.value) {
            return getAccessibleText(value.value);
        }

        if (undefined !== value.r) {
            return getAccessibleText(value.r);
        }

        return '';
    }

    function getAccessibleText(value) {
        if (undefined === value || null === value || 'function' === typeof value) {
            return '';
        }

        if (Array.isArray(value)) {
            var values = [];

            value.forEach(function(item) {
                var text = getAccessibleText(item);

                if (text) {
                    values.push(text);
                }
            });

            return values.join(', ');
        }

        if ('object' === typeof value) {
            return '';
        }

        return String(value).trim();
    }

    function findChartInstances(moduleElement) {
        var instances = [];
        var seen = [];
        var instanceProperties = ['__chartsInstance', '__chartInstance', '__chart'];
        var canvasProperties = ['chart', '__chart', '__chartist'];

        addChartCandidatesFromProperties(instances, seen, moduleElement, instanceProperties);

        var descendants = moduleElement.querySelectorAll('*');

        for (var i = 0; i < descendants.length; i++) {
            addChartCandidatesFromProperties(instances, seen, descendants[i], instanceProperties);
        }

        var canvases = moduleElement.querySelectorAll('canvas');

        for (var j = 0; j < canvases.length; j++) {
            if (window.Chart && typeof window.Chart.getChart === 'function') {
                addChartCandidate(instances, seen, window.Chart.getChart(canvases[j]));
            }

            addChartCandidatesFromProperties(instances, seen, canvases[j], canvasProperties);
        }

        addChartCandidate(instances, seen, findChartInDiviModuleCharts(moduleElement));

        return instances;
    }

    function addChartCandidatesFromProperties(instances, seen, object, properties) {
        properties.forEach(function(property) {
            addChartCandidate(instances, seen, object[property]);
        });
    }

    function findChartInDiviModuleCharts(moduleElement) {
        if (!window.diviModuleCharts || typeof window.diviModuleCharts !== 'object') {
            return null;
        }

        var canvases = moduleElement.querySelectorAll('canvas');
        var canvasIds = [];

        for (var i = 0; i < canvases.length; i++) {
            if (canvases[i].id) {
                canvasIds.push(canvases[i].id);
            }
        }

        return searchObjectForCharts(window.diviModuleCharts, canvases, canvasIds, 0);
    }

    function searchObjectForCharts(obj, canvases, canvasIds, depth) {
        if (!obj || typeof obj !== 'object' || depth > 3) {
            return null;
        }

        if (isChartInstance(obj) && chartBelongsToCanvases(obj, canvases, canvasIds)) {
            return obj;
        }

        var matches = [];

        Object.keys(obj).forEach(function(key) {
            var value = obj[key];

            if (isChartInstance(value) && chartBelongsToCanvases(value, canvases, canvasIds)) {
                matches.push(value);
            } else {
                var nested = searchObjectForCharts(value, canvases, canvasIds, depth + 1);

                if (nested) {
                    matches.push(nested);
                }
            }
        });

        return matches.length ? matches : null;
    }

    function chartBelongsToCanvases(chart, canvases, canvasIds) {
        var canvas = chart.canvas || (chart.ctx && chart.ctx.canvas) || null;

        if (!canvas) {
            return false;
        }

        for (var i = 0; i < canvases.length; i++) {
            if (canvas === canvases[i]) {
                return true;
            }
        }

        return canvas.id && canvasIds.indexOf(canvas.id) !== -1;
    }

    function addChartCandidate(instances, seen, candidate) {
        if (!candidate) {
            return;
        }

        if (Array.isArray(candidate)) {
            candidate.forEach(function(item) {
                addChartCandidate(instances, seen, item);
            });
            return;
        }

        if (isChartInstance(candidate)) {
            if (seen.indexOf(candidate) === -1) {
                instances.push(candidate);
                seen.push(candidate);
            }
            return;
        }

        if (candidate.chart) {
            addChartCandidate(instances, seen, candidate.chart);
        }

        if (candidate.instance) {
            addChartCandidate(instances, seen, candidate.instance);
        }

        if (candidate.chartInstance) {
            addChartCandidate(instances, seen, candidate.chartInstance);
        }
    }

    function isChartInstance(candidate) {
        return !!(candidate && typeof candidate === 'object' && candidate.config && candidate.options && typeof candidate.update === 'function');
    }

    function supportsAxisLabelStyles(chart) {
        var chartType = chart && chart.config ? chart.config.type : '';

        // Treat an unset type as the line default.
        if (!chartType) {
            return true;
        }

        return axisLabelChartTypes.indexOf(String(chartType).toLowerCase()) !== -1;
    }

    function applyStylesToChart(chart, styles) {
        if (!chart || !styles) {
            return false;
        }

        // Skip axis setup for chart types without X/Y axes.
        if (!supportsAxisLabelStyles(chart)) {
            delete chart.__diviboosterAxisLabelFontsHash;
            return false;
        }

        var activeStyles = getActiveStyles(styles);
        var hash = stableStringify(activeStyles);

        if (chart.__diviboosterAxisLabelFontsHash === hash) {
            return true;
        }

        // Chart.js redraws from config.options. chart.options is the resolved
        // options object, so changing it can make diagnostics look correct
        // while leaving the already-rendered canvas unchanged.
        var options = (chart.config && chart.config.options) || chart.options || {};

        if (!options.scales) {
            options.scales = {};
        }

        if (activeStyles.x) {
            applyAxisStyle(options, chart, 'x', activeStyles.x);
        }

        if (activeStyles.y) {
            applyAxisStyle(options, chart, 'y', activeStyles.y);
        }

        chart.__diviboosterAxisLabelFontsHash = hash;

        try {
            chart.update('none');
        } catch (e) {
            try {
                chart.update();
            } catch (ignore) {}
        }

        return true;
    }

    function getActiveStyles(styles) {
        return {
            x: getActiveStyle(styles.x),
            y: getActiveStyle(styles.y)
        };
    }

    function getActiveStyle(axisStyles) {
        if (!axisStyles || typeof axisStyles !== 'object') {
            return null;
        }

        var device = getCurrentDevice();

        return axisStyles[device] || axisStyles.desktop || axisStyles.tablet || axisStyles.phone || null;
    }

    function getCurrentDevice() {
        var width = window.innerWidth || document.documentElement.clientWidth || 0;

        if (width <= 767) {
            return 'phone';
        }

        if (width <= 980) {
            return 'tablet';
        }

        return 'desktop';
    }

    function applyAxisStyle(options, chart, axis, style) {
        if (!style || typeof style !== 'object') {
            return;
        }

        if (options.scales && Array.isArray(options.scales[axis + 'Axes'])) {
            options.scales[axis + 'Axes'].forEach(function(scaleOptions) {
                applyStyleToScaleOptions(scaleOptions, style);
            });
            return;
        }

        var scaleKeys = getAxisScaleKeys(options, chart, axis);

        if (!scaleKeys.length) {
            scaleKeys = [axis];
        }

        scaleKeys.forEach(function(scaleKey) {
            if (!options.scales[scaleKey] || typeof options.scales[scaleKey] !== 'object') {
                options.scales[scaleKey] = {};
            }

            applyStyleToScaleOptions(options.scales[scaleKey], style);
        });
    }

    function getAxisScaleKeys(options, chart, axis) {
        var keys = [];

        if (chart.scales && typeof chart.scales === 'object') {
            keys = getScaleKeys(chart.scales, axis);
        }

        if (!keys.length && options.scales && typeof options.scales === 'object') {
            keys = getScaleKeys(options.scales, axis);
        }

        return keys;
    }

    function getScaleKeys(scales, axis) {
        var keys = [];

        Object.keys(scales).forEach(function(key) {
            var scale = scales[key];

            if ((scale && scale.axis === axis) || key === axis || key.indexOf(axis) === 0) {
                keys.push(key);
            }
        });

        return keys;
    }

    function applyStyleToScaleOptions(scaleOptions, style) {
        if (!scaleOptions.ticks || typeof scaleOptions.ticks !== 'object') {
            scaleOptions.ticks = {};
        }

        var font = buildChartFont(style);

        if (Object.keys(font).length) {
            scaleOptions.ticks.font = Object.assign({}, scaleOptions.ticks.font || {}, font);
        }

        if (style.color) {
            scaleOptions.ticks.color = String(style.color);
            scaleOptions.ticks.fontColor = String(style.color);
        }
    }

    function buildChartFont(style) {
        var font = {};
        var family = normalizeFontFamily(style.family);
        var weight = normalizeFontWeight(style.weight);
        var fontStyle = normalizeFontStyle(style.style);
        var size = cssLengthToPixels(style.size);
        var lineHeight = normalizeLineHeight(style.lineHeight);

        if (family) {
            font.family = family;
        }

        if (weight) {
            font.weight = weight;
        }

        if (fontStyle) {
            font.style = fontStyle;
        }

        if (size) {
            font.size = size;
        }

        if (lineHeight) {
            font.lineHeight = lineHeight;
        }

        return font;
    }

    function normalizeFontFamily(family) {
        if (!family) {
            return '';
        }

        if (typeof family === 'object') {
            family = family.value || family.name || family.family || '';
        }

        family = String(family);

        if (family.indexOf('|') !== -1) {
            family = family.split('|')[0];
        }

        return family.replace(/^['\"]+|['\"]+$/g, '').trim();
    }

    function normalizeFontWeight(weight) {
        if (!weight) {
            return '';
        }

        if (typeof weight === 'object') {
            weight = weight.value || weight.weight || '';
        }

        weight = String(weight).toLowerCase();

        var map = {
            thin: '100',
            ultralight: '200',
            'extra-light': '200',
            extralight: '200',
            light: '300',
            regular: '400',
            normal: '400',
            medium: '500',
            semibold: '600',
            'semi-bold': '600',
            bold: '700',
            extrabold: '800',
            'extra-bold': '800',
            heavy: '900',
            black: '900'
        };

        return map[weight] || weight.replace(/[^0-9a-z-]/g, '');
    }

    function normalizeFontStyle(style) {
        if (!style) {
            return '';
        }

        if (typeof style === 'object') {
            if (style.italic === 'on' || style.italic === true || style.fontStyle === 'italic' || style.value === 'italic') {
                return 'italic';
            }

            return '';
        }

        style = String(style).toLowerCase();

        return style.indexOf('italic') !== -1 ? 'italic' : '';
    }

    function normalizeLineHeight(lineHeight) {
        if (!lineHeight) {
            return '';
        }

        if (typeof lineHeight === 'object') {
            lineHeight = lineHeight.value || '';
        }

        lineHeight = String(lineHeight).trim();

        if (!lineHeight) {
            return '';
        }

        if (/^[0-9.]+$/.test(lineHeight)) {
            return parseFloat(lineHeight);
        }

        return lineHeight;
    }

    function cssLengthToPixels(value) {
        if (!value) {
            return null;
        }

        if (typeof value === 'object') {
            value = value.value || '';
        }

        if (typeof value === 'number') {
            return value;
        }

        value = String(value).trim();

        if (!value) {
            return null;
        }

        if (/^[0-9.]+px$/.test(value)) {
            return parseFloat(value);
        }

        if (/^[0-9.]+$/.test(value)) {
            return parseFloat(value);
        }

        var element = document.createElement('div');
        element.style.position = 'absolute';
        element.style.visibility = 'hidden';
        element.style.width = value;
        document.body.appendChild(element);
        var pixels = parseFloat(window.getComputedStyle(element).width);
        document.body.removeChild(element);

        return isNaN(pixels) ? null : pixels;
    }

    function stableStringify(value) {
        try {
            return JSON.stringify(value || {});
        } catch (e) {
            return String(Date.now());
        }
    }

    function scheduleRetry() {
        if (builderMode) {
            window.setInterval(applyAll, 500);
            return;
        }

        var interval = window.setInterval(function() {
            retryCount++;

            if (applyAll() || retryCount >= maxRetries) {
                window.clearInterval(interval);
            }
        }, 100);
    }

    function bindResizeHandler() {
        window.addEventListener('resize', function() {
            window.clearTimeout(resizeTimer);
            resizeTimer = window.setTimeout(applyAll, 150);
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            applyAll();
            scheduleRetry();
            bindResizeHandler();
        });
    } else {
        applyAll();
        scheduleRetry();
        bindResizeHandler();
    }
})();
JS;
}

function get_chart_module_slugs() {
    return array('divi/charts', 'divi/chart');
}


