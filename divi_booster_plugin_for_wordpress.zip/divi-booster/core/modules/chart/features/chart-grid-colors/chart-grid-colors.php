<?php
namespace DiviBooster\Divi5\Chart\GridLinesColor;

if (!defined('ABSPATH')) {
    exit;
}

const GROUP_SLUG           = 'diviboosterGridLines';
const HORIZONTAL_COLOR_ATTR = 'diviboosterHorizontalGridLineColor';
const VERTICAL_COLOR_ATTR   = 'diviboosterVerticalGridLineColor';
const RADIAL_COLOR_ATTR     = 'diviboosterRadialGridLineColor';
const HORIZONTAL_WIDTH_ATTR = 'diviboosterHorizontalGridLineWidth';
const VERTICAL_WIDTH_ATTR   = 'diviboosterVerticalGridLineWidth';
const RADIAL_WIDTH_ATTR     = 'diviboosterRadialGridLineWidth';
const HORIZONTAL_AXIS_COLOR_ATTR = 'diviboosterHorizontalAxisLineColor';
const VERTICAL_AXIS_COLOR_ATTR   = 'diviboosterVerticalAxisLineColor';
const HORIZONTAL_AXIS_WIDTH_ATTR = 'diviboosterHorizontalAxisLineWidth';
const VERTICAL_AXIS_WIDTH_ATTR   = 'diviboosterVerticalAxisLineWidth';
const DATA_ATTR             = 'data-divibooster-chart-grid-lines';
const SCRIPT_HANDLE         = 'divibooster-divi5-chart-grid-lines-color';
const SCRIPT_NAMESPACE      = 'divibooster/chart-grid-lines-color';
const RUNTIME_ACTION        = 'divibooster_chart_grid_lines_color_runtime';

// === WordPress hooks ===
if (function_exists('add_filter')) {
    add_filter('block_type_metadata_settings', __NAMESPACE__ . '\\register_chart_grid_line_color_attrs');

    foreach (get_chart_module_slugs() as $chart_module_slug) {
        add_filter('render_block_' . $chart_module_slug, __NAMESPACE__ . '\\add_grid_line_color_data_to_chart_output', 10, 3);
    }
}

if (function_exists('add_action')) {
    add_action('wp_enqueue_scripts', __NAMESPACE__ . '\\register_frontend_script');
    add_action('divi_visual_builder_assets_before_enqueue_app_window_scripts', __NAMESPACE__ . '\\enqueue_visual_builder_script');
    add_action('wp_ajax_' . RUNTIME_ACTION, __NAMESPACE__ . '\\output_runtime_asset');
    add_action('wp_ajax_nopriv_' . RUNTIME_ACTION, __NAMESPACE__ . '\\output_runtime_asset');
}

// === Module settings and output ===

function merge_chart_grid_line_definition($existing, $definition) {
    if (!is_array($existing) || !is_array($definition)) {
        return $definition;
    }

    return array_replace_recursive($existing, $definition);
}

function get_grid_line_attribute_definitions() {
    if (!function_exists('__')) {
        return array();
    }

    return array(
        HORIZONTAL_COLOR_ATTR => get_grid_line_color_attribute_definition(
            HORIZONTAL_COLOR_ATTR,
            __('Horizontal Grid Lines Color', 'divi-booster'),
            10
        ),
        VERTICAL_COLOR_ATTR => get_grid_line_color_attribute_definition(
            VERTICAL_COLOR_ATTR,
            __('Vertical Grid Lines Color', 'divi-booster'),
            30
        ),
        RADIAL_COLOR_ATTR => get_grid_line_color_attribute_definition(
            RADIAL_COLOR_ATTR,
            __('Grid Lines Color', 'divi-booster'),
            10
        ),
        HORIZONTAL_WIDTH_ATTR => get_grid_line_width_attribute_definition(
            HORIZONTAL_WIDTH_ATTR,
            __('Horizontal Grid Lines Width', 'divi-booster'),
            20
        ),
        VERTICAL_WIDTH_ATTR => get_grid_line_width_attribute_definition(
            VERTICAL_WIDTH_ATTR,
            __('Vertical Grid Lines Width', 'divi-booster'),
            40
        ),
        RADIAL_WIDTH_ATTR => get_grid_line_width_attribute_definition(
            RADIAL_WIDTH_ATTR,
            __('Grid Lines Width', 'divi-booster'),
            20
        ),
        HORIZONTAL_AXIS_COLOR_ATTR => get_grid_line_color_attribute_definition(
            HORIZONTAL_AXIS_COLOR_ATTR,
            __('Horizontal Axis Line Color', 'divi-booster'),
            50,
            __('Choose a custom color for the horizontal chart axis line. For accessibility, ensure it has sufficient contrast against the chart background and do not rely on color alone to convey information.', 'divi-booster')
        ),
        HORIZONTAL_AXIS_WIDTH_ATTR => get_grid_line_width_attribute_definition(
            HORIZONTAL_AXIS_WIDTH_ATTR,
            __('Horizontal Axis Line Width', 'divi-booster'),
            60,
            __('Choose a custom width for the horizontal chart axis line.', 'divi-booster')
        ),
        VERTICAL_AXIS_COLOR_ATTR => get_grid_line_color_attribute_definition(
            VERTICAL_AXIS_COLOR_ATTR,
            __('Vertical Axis Line Color', 'divi-booster'),
            70,
            __('Choose a custom color for the vertical chart axis line. For accessibility, ensure it has sufficient contrast against the chart background and do not rely on color alone to convey information.', 'divi-booster')
        ),
        VERTICAL_AXIS_WIDTH_ATTR => get_grid_line_width_attribute_definition(
            VERTICAL_AXIS_WIDTH_ATTR,
            __('Vertical Axis Line Width', 'divi-booster'),
            80,
            __('Choose a custom width for the vertical chart axis line.', 'divi-booster')
        ),
    );
}

// Register grid-line settings for supported chart modules.
function register_chart_grid_line_color_attrs($settings) {
    if (!is_array($settings)) {
        return $settings;
    }

    $module_name       = isset($settings['name']) ? $settings['name'] : '';
    $module_attributes = isset($settings['attributes']) ? $settings['attributes'] : false;

    if (!in_array($module_name, get_chart_module_slugs(), true) || !is_array($module_attributes)) {
        return $settings;
    }

    $attribute_definitions = get_grid_line_attribute_definitions();

    if (!is_array($attribute_definitions) || empty($attribute_definitions)) {
        return $settings;
    }

    foreach ($attribute_definitions as $attribute_name => $definition) {
        $existing_definition = isset($settings['attributes'][$attribute_name]) ? $settings['attributes'][$attribute_name] : array();
        $settings['attributes'][$attribute_name] = merge_chart_grid_line_definition($existing_definition, $definition);
    }

    if (!isset($settings['settings']) || !is_array($settings['settings'])) {
        $settings['settings'] = array();
    }

    if (!isset($settings['settings']['groups']) || !is_array($settings['settings']['groups'])) {
        $settings['settings']['groups'] = array();
    }

    $settings['settings']['groups'][GROUP_SLUG] = merge_chart_grid_line_definition(
        isset($settings['settings']['groups'][GROUP_SLUG]) ? $settings['settings']['groups'][GROUP_SLUG] : array(),
        get_grid_lines_group_definition()
    );

    return $settings;
}

// Attach non-empty grid-line data to rendered chart markup.
function add_grid_line_color_data_to_chart_output($block_content, $parsed_block, $block) {
    if (!is_string($block_content) || '' === $block_content) {
        return $block_content;
    }

    $attrs = is_array($parsed_block) && isset($parsed_block['attrs']) && is_array($parsed_block['attrs']) ? $parsed_block['attrs'] : array();
    $data  = get_grid_line_data_from_attrs($attrs, false);

    if (empty($data) || !grid_line_data_has_values($data)) {
        return $block_content;
    }

    enqueue_frontend_script();

    return inject_chart_data_attribute($block_content, DATA_ATTR, $data);
}

// === Frontend assets ===

function register_frontend_script() {
    if (!function_exists('wp_script_is') || !function_exists('wp_register_script')) {
        return;
    }

    if (is_visual_builder() || wp_script_is(SCRIPT_HANDLE, 'registered')) {
        return;
    }

    $runtime_asset_url = get_runtime_asset_url(false);

    if (!is_string($runtime_asset_url) || '' === $runtime_asset_url) {
        return;
    }

    wp_register_script(
        SCRIPT_HANDLE,
        $runtime_asset_url,
        array(),
        get_runtime_asset_version(),
        true
    );
}

function enqueue_frontend_script() {
    if (!function_exists('wp_script_is') || !function_exists('wp_enqueue_script')) {
        return;
    }

    if (is_visual_builder()) {
        return;
    }

    if (!wp_script_is(SCRIPT_HANDLE, 'registered')) {
        register_frontend_script();
    }

    if (wp_script_is(SCRIPT_HANDLE, 'registered')) {
        wp_enqueue_script(SCRIPT_HANDLE);
    }
}

function enqueue_visual_builder_script() {
    if (!is_visual_builder()) {
        return;
    }

    if (
        !function_exists('wp_script_is') ||
        !function_exists('wp_register_script') ||
        !function_exists('wp_enqueue_script')
    ) {
        return;
    }

    if (
        !wp_script_is('divi-vendor-wp-hooks', 'registered') ||
        !wp_script_is('divi-vendor-wp-element', 'registered')
    ) {
        return;
    }

    if (!wp_script_is(SCRIPT_HANDLE, 'registered')) {
        $runtime_asset_url = get_runtime_asset_url(true);

        if (!is_string($runtime_asset_url) || '' === $runtime_asset_url) {
            return;
        }

        wp_register_script(
            SCRIPT_HANDLE,
            $runtime_asset_url,
            array('divi-vendor-wp-hooks', 'divi-vendor-wp-element'),
            get_runtime_asset_version(),
            false
        );
    }

    wp_enqueue_script(SCRIPT_HANDLE);

    $inline_js = get_visual_builder_inline_js();

    if ('' !== $inline_js && function_exists('wp_add_inline_script')) {
        wp_add_inline_script(SCRIPT_HANDLE, $inline_js, 'after');
    }
}

// === Runtime asset generation ===

function output_runtime_asset() {
    $builder_mode = !empty($_GET['builder']);
    $charset      = function_exists('get_option') ? get_option('blog_charset') : 'UTF-8';

    if (!is_string($charset) || !preg_match('/^[A-Za-z0-9._-]+$/', $charset)) {
        $charset = 'UTF-8';
    }

    if (function_exists('status_header')) {
        status_header(200);
    }
    header('Content-Type: application/javascript; charset=' . $charset);
    header('Cache-Control: public, max-age=31536000, immutable');
    header('X-Content-Type-Options: nosniff');

    echo get_chart_runtime_js($builder_mode);
    exit;
}

// Build the builder-side integration script from shared definitions.
function get_visual_builder_inline_js() {
    if (!function_exists('wp_json_encode')) {
        return '';
    }

    $json_flags      = JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;
    $module_slugs    = wp_json_encode(get_chart_module_slugs(), $json_flags);
    $group_slug      = wp_json_encode(GROUP_SLUG, $json_flags);
    $group_definition = get_grid_lines_group_definition();
    $group_def       = wp_json_encode($group_definition, $json_flags);
    $horizontal_attr = wp_json_encode(HORIZONTAL_COLOR_ATTR, $json_flags);
    $vertical_attr   = wp_json_encode(VERTICAL_COLOR_ATTR, $json_flags);
    $radial_attr     = wp_json_encode(RADIAL_COLOR_ATTR, $json_flags);
    $horizontal_width_attr = wp_json_encode(HORIZONTAL_WIDTH_ATTR, $json_flags);
    $vertical_width_attr   = wp_json_encode(VERTICAL_WIDTH_ATTR, $json_flags);
    $radial_width_attr     = wp_json_encode(RADIAL_WIDTH_ATTR, $json_flags);
    $horizontal_axis_color_attr = wp_json_encode(HORIZONTAL_AXIS_COLOR_ATTR, $json_flags);
    $vertical_axis_color_attr   = wp_json_encode(VERTICAL_AXIS_COLOR_ATTR, $json_flags);
    $horizontal_axis_width_attr = wp_json_encode(HORIZONTAL_AXIS_WIDTH_ATTR, $json_flags);
    $vertical_axis_width_attr   = wp_json_encode(VERTICAL_AXIS_WIDTH_ATTR, $json_flags);
    $attribute_definitions = get_grid_line_attribute_definitions();
    $horizontal_def = wp_json_encode($attribute_definitions[HORIZONTAL_COLOR_ATTR], $json_flags);
    $vertical_def = wp_json_encode($attribute_definitions[VERTICAL_COLOR_ATTR], $json_flags);
    $radial_def = wp_json_encode($attribute_definitions[RADIAL_COLOR_ATTR], $json_flags);
    $horizontal_width_def = wp_json_encode($attribute_definitions[HORIZONTAL_WIDTH_ATTR], $json_flags);
    $vertical_width_def = wp_json_encode($attribute_definitions[VERTICAL_WIDTH_ATTR], $json_flags);
    $radial_width_def = wp_json_encode($attribute_definitions[RADIAL_WIDTH_ATTR], $json_flags);
    $horizontal_axis_color_def = wp_json_encode($attribute_definitions[HORIZONTAL_AXIS_COLOR_ATTR], $json_flags);
    $horizontal_axis_width_def = wp_json_encode($attribute_definitions[HORIZONTAL_AXIS_WIDTH_ATTR], $json_flags);
    $vertical_axis_color_def = wp_json_encode($attribute_definitions[VERTICAL_AXIS_COLOR_ATTR], $json_flags);
    $vertical_axis_width_def = wp_json_encode($attribute_definitions[VERTICAL_AXIS_WIDTH_ATTR], $json_flags);
    $namespace       = wp_json_encode(SCRIPT_NAMESPACE, $json_flags);
    $data_attr       = wp_json_encode(DATA_ATTR, $json_flags);
    $cartesian_types = wp_json_encode(get_cartesian_grid_chart_types(), $json_flags);
    $radial_types    = wp_json_encode(get_radial_grid_chart_types(), $json_flags);

    if (
        false === $module_slugs || false === $group_slug || false === $group_def ||
        false === $horizontal_attr || false === $vertical_attr || false === $radial_attr ||
        false === $horizontal_width_attr || false === $vertical_width_attr || false === $radial_width_attr ||
        false === $horizontal_axis_color_attr || false === $vertical_axis_color_attr ||
        false === $horizontal_axis_width_attr || false === $vertical_axis_width_attr ||
        false === $horizontal_def || false === $vertical_def || false === $radial_def ||
        false === $horizontal_width_def || false === $vertical_width_def || false === $radial_width_def ||
        false === $horizontal_axis_color_def || false === $vertical_axis_color_def ||
        false === $horizontal_axis_width_def || false === $vertical_axis_width_def ||
        false === $namespace || false === $data_attr || false === $cartesian_types ||
        false === $radial_types
    ) {
        return '';
    }

    return <<<JS
(function() {
    if (
        !window.vendor ||
        !window.vendor.wp ||
        !window.vendor.wp.hooks ||
        typeof window.vendor.wp.hooks.addFilter !== 'function'
    ) {
        return;
    }

    var chartModuleSlugs = {$module_slugs};
    var groupSlug = {$group_slug};
    var groupDefinition = {$group_def};
    var horizontalAttrSlug = {$horizontal_attr};
    var verticalAttrSlug = {$vertical_attr};
    var radialAttrSlug = {$radial_attr};
    var horizontalWidthAttrSlug = {$horizontal_width_attr};
    var verticalWidthAttrSlug = {$vertical_width_attr};
    var radialWidthAttrSlug = {$radial_width_attr};
    var horizontalAxisColorAttrSlug = {$horizontal_axis_color_attr};
    var verticalAxisColorAttrSlug = {$vertical_axis_color_attr};
    var horizontalAxisWidthAttrSlug = {$horizontal_axis_width_attr};
    var verticalAxisWidthAttrSlug = {$vertical_axis_width_attr};
    var horizontalAttrDefinition = {$horizontal_def};
    var verticalAttrDefinition = {$vertical_def};
    var radialAttrDefinition = {$radial_def};
    var horizontalWidthAttrDefinition = {$horizontal_width_def};
    var verticalWidthAttrDefinition = {$vertical_width_def};
    var radialWidthAttrDefinition = {$radial_width_def};
    var horizontalAxisColorAttrDefinition = {$horizontal_axis_color_def};
    var verticalAxisColorAttrDefinition = {$vertical_axis_color_def};
    var horizontalAxisWidthAttrDefinition = {$horizontal_axis_width_def};
    var verticalAxisWidthAttrDefinition = {$vertical_axis_width_def};
    var hookNamespace = {$namespace};
    var dataAttr = {$data_attr};
    var cartesianTypes = {$cartesian_types};
    var radialTypes = {$radial_types};
    var addFilter = window.vendor.wp.hooks.addFilter;

    if (!Array.isArray(chartModuleSlugs) || !Array.isArray(cartesianTypes) || !Array.isArray(radialTypes)) {
        return;
    }

    function hookSuffix(moduleSlug) {
        return String(moduleSlug).replace(/\//g, '.');
    }

    function clone(value) {
        try {
            return JSON.parse(JSON.stringify(value));
        } catch (e) {
            return value;
        }
    }

    function isPlainObject(value) {
        if (!value || Object.prototype.toString.call(value) !== '[object Object]') {
            return false;
        }

        var prototype = Object.getPrototypeOf(value);

        return prototype === Object.prototype || prototype === null;
    }

    function mergeDefinition(existing, definition) {
        if (!isPlainObject(existing) || !isPlainObject(definition)) {
            return definition;
        }

        var merged = Object.assign({}, existing);

        Object.keys(definition).forEach(function(key) {
            if (isPlainObject(merged[key]) && isPlainObject(definition[key])) {
                merged[key] = mergeDefinition(merged[key], definition[key]);
            } else {
                merged[key] = definition[key];
            }
        });

        return merged;
    }

    function normalizeType(type) {
        return String(type || 'line').replace(/[_\s-]+/g, '').toLowerCase();
    }

    function getPath(obj, path) {
        var current = obj;

        for (var i = 0; i < path.length; i++) {
            if (!current || typeof current !== 'object') {
                return undefined;
            }

            if (typeof current.has === 'function' && current.has(path[i])) {
                current = current.get(path[i]);
            } else if (Object.prototype.hasOwnProperty.call(current, path[i])) {
                current = current[path[i]];
            } else {
                return undefined;
            }
        }

        return current && typeof current.toJS === 'function' ? current.toJS() : current;
    }

    function getResponsiveDevice(responsiveMode) {
        var mode = String(responsiveMode || 'desktop').toLowerCase();

        if (mode.indexOf('phone') !== -1) {
            return 'phone';
        }

        if (mode.indexOf('tablet') !== -1) {
            return 'tablet';
        }

        return 'desktop';
    }

    function readChartType(attrs, responsiveMode) {
        var device = getResponsiveDevice(responsiveMode);
        var paths = [
            ['chart', 'advanced', 'config', device, 'value', 'type'],
            ['chart', 'advanced', 'config', 'desktop', 'value', 'type'],
            ['chart', 'advanced', 'config', 'tablet', 'value', 'type'],
            ['chart', 'advanced', 'config', 'phone', 'value', 'type'],
            ['chart', 'advanced', 'config', 'type'],
            ['chart', 'innerContent', 'desktop', 'value', 'type'],
            ['chart', 'innerContent', 'type'],
            ['module', 'chart', 'advanced', 'config', 'type'],
            ['type'],
            ['chartType']
        ];

        for (var i = 0; i < paths.length; i++) {
            var value = getPath(attrs, paths[i]);

            if (value && typeof value === 'object') {
                value = value.value || value.desktop && value.desktop.value || '';
            }

            if (value !== undefined && value !== null && value !== '') {
                return String(value);
            }
        }

        return 'line';
    }

    function getVisibleChartType(context) {
        var attrs = context && context.attrs ? context.attrs : {};
        var responsiveMode = context && context.responsiveMode ? context.responsiveMode : 'desktop';

        return normalizeType(readChartType(attrs, responsiveMode));
    }

    function gridLinesGroupVisibleCallback(context) {
        var chartType = getVisibleChartType(context);

        return cartesianTypes.indexOf(chartType) !== -1 || radialTypes.indexOf(chartType) !== -1;
    }

    function cartesianGridColorVisibleCallback(context) {
        return cartesianTypes.indexOf(getVisibleChartType(context)) !== -1;
    }

    function radialGridColorVisibleCallback(context) {
        return radialTypes.indexOf(getVisibleChartType(context)) !== -1;
    }

    function setFieldVisibleCallback(attributeDefinition, visibleCallback) {
        var items = attributeDefinition && attributeDefinition.settings &&
            attributeDefinition.settings.innerContent &&
            attributeDefinition.settings.innerContent.items;

        if (!items) {
            return;
        }

        Object.keys(items).forEach(function(key) {
            if (items[key] && typeof items[key] === 'object') {
                items[key].visible = visibleCallback;
            }
        });
    }

    function prepareDefinitions() {
        var group = clone(groupDefinition);
        var horizontal = clone(horizontalAttrDefinition);
        var vertical = clone(verticalAttrDefinition);
        var radial = clone(radialAttrDefinition);
        var horizontalWidth = clone(horizontalWidthAttrDefinition);
        var verticalWidth = clone(verticalWidthAttrDefinition);
        var radialWidth = clone(radialWidthAttrDefinition);
        var horizontalAxisColor = clone(horizontalAxisColorAttrDefinition);
        var verticalAxisColor = clone(verticalAxisColorAttrDefinition);
        var horizontalAxisWidth = clone(horizontalAxisWidthAttrDefinition);
        var verticalAxisWidth = clone(verticalAxisWidthAttrDefinition);

        setFieldVisibleCallback(horizontal, cartesianGridColorVisibleCallback);
        setFieldVisibleCallback(vertical, cartesianGridColorVisibleCallback);
        setFieldVisibleCallback(radial, radialGridColorVisibleCallback);
        setFieldVisibleCallback(horizontalWidth, cartesianGridColorVisibleCallback);
        setFieldVisibleCallback(verticalWidth, cartesianGridColorVisibleCallback);
        setFieldVisibleCallback(radialWidth, radialGridColorVisibleCallback);
        setFieldVisibleCallback(horizontalAxisColor, cartesianGridColorVisibleCallback);
        setFieldVisibleCallback(verticalAxisColor, cartesianGridColorVisibleCallback);
        setFieldVisibleCallback(horizontalAxisWidth, cartesianGridColorVisibleCallback);
        setFieldVisibleCallback(verticalAxisWidth, cartesianGridColorVisibleCallback);

        if (group && group.component && group.component.props) {
            group.component.props.visible = gridLinesGroupVisibleCallback;
        }

        return {
            group: group,
            horizontal: horizontal,
            vertical: vertical,
            radial: radial,
            horizontalWidth: horizontalWidth,
            verticalWidth: verticalWidth,
            radialWidth: radialWidth,
            horizontalAxisColor: horizontalAxisColor,
            verticalAxisColor: verticalAxisColor,
            horizontalAxisWidth: horizontalAxisWidth,
            verticalAxisWidth: verticalAxisWidth
        };
    }

    chartModuleSlugs.forEach(function(moduleSlug) {
        var suffix = hookSuffix(moduleSlug);

        addFilter('divi.moduleLibrary.moduleSettings.groups.' + suffix, hookNamespace, function(groups) {
            if (!isPlainObject(groups)) {
                return groups;
            }

            var definitions = prepareDefinitions();
            groups[groupSlug] = mergeDefinition(groups[groupSlug], definitions.group);
            return groups;
        });

        addFilter('divi.moduleLibrary.moduleAttributes.' + suffix, hookNamespace, function(attributes) {
            if (!isPlainObject(attributes)) {
                return attributes;
            }

            var definitions = prepareDefinitions();
            attributes[horizontalAttrSlug] = mergeDefinition(attributes[horizontalAttrSlug], definitions.horizontal);
            attributes[verticalAttrSlug] = mergeDefinition(attributes[verticalAttrSlug], definitions.vertical);
            attributes[radialAttrSlug] = mergeDefinition(attributes[radialAttrSlug], definitions.radial);
            attributes[horizontalWidthAttrSlug] = mergeDefinition(attributes[horizontalWidthAttrSlug], definitions.horizontalWidth);
            attributes[verticalWidthAttrSlug] = mergeDefinition(attributes[verticalWidthAttrSlug], definitions.verticalWidth);
            attributes[radialWidthAttrSlug] = mergeDefinition(attributes[radialWidthAttrSlug], definitions.radialWidth);
            attributes[horizontalAxisColorAttrSlug] = mergeDefinition(attributes[horizontalAxisColorAttrSlug], definitions.horizontalAxisColor);
            attributes[verticalAxisColorAttrSlug] = mergeDefinition(attributes[verticalAxisColorAttrSlug], definitions.verticalAxisColor);
            attributes[horizontalAxisWidthAttrSlug] = mergeDefinition(attributes[horizontalAxisWidthAttrSlug], definitions.horizontalAxisWidth);
            attributes[verticalAxisWidthAttrSlug] = mergeDefinition(attributes[verticalAxisWidthAttrSlug], definitions.verticalAxisWidth);
            return attributes;
        });
    });

    addFilter('divi.module.wrapper.render', hookNamespace, function(moduleWrapper, param) {
        param = param || {};

        if (chartModuleSlugs.indexOf(param.name) === -1 || !moduleWrapper || !moduleWrapper.props) {
            return moduleWrapper;
        }

        var element = window.vendor.wp && window.vendor.wp.element ? window.vendor.wp.element : null;

        if (!element || !element.cloneElement) {
            return moduleWrapper;
        }

        var data = window.DiviBoosterChartGridLines && window.DiviBoosterChartGridLines.getDataFromBuilderAttrs
            ? window.DiviBoosterChartGridLines.getDataFromBuilderAttrs(
                param.attrs || {},
                horizontalAttrSlug,
                verticalAttrSlug,
                radialAttrSlug,
                horizontalWidthAttrSlug,
                verticalWidthAttrSlug,
                radialWidthAttrSlug,
                horizontalAxisColorAttrSlug,
                verticalAxisColorAttrSlug,
                horizontalAxisWidthAttrSlug,
                verticalAxisWidthAttrSlug
            )
            : { type: readChartType(param.attrs || {}) };

        var newProps = Object.assign({}, moduleWrapper.props);
        var htmlAttrs = Object.assign({}, moduleWrapper.props.htmlAttrs || {});
        var dataJson = '{}';

        try {
            var serializedData = JSON.stringify(data || {});

            if (typeof serializedData === 'string') {
                dataJson = serializedData;
            }
        } catch (e) {}

        htmlAttrs[dataAttr] = dataJson;
        newProps.htmlAttrs = htmlAttrs;

        setTimeout(function() {
            if (window.DiviBoosterChartGridLines && window.DiviBoosterChartGridLines.applyAll) {
                window.DiviBoosterChartGridLines.applyAll();
            }
        }, 80);

        return element.cloneElement(moduleWrapper, newProps, moduleWrapper.props.children);
    });
})();
JS;
}

// === Attribute definitions ===

function get_grid_lines_group_definition() {
    if (!function_exists('__')) {
        return array();
    }

    return array(
        'groupName'     => GROUP_SLUG,
        'panel'         => 'design',
        'priority'      => 36,
        'multiElements' => true,
        'component'     => array(
            'name'  => 'divi/composite',
            'props' => array(
                'groupLabel' => __('Grid Lines', 'divi-booster'),
            ),
        ),
    );
}

function get_grid_line_color_attribute_definition($attr_name, $label, $priority, $description = '') {
    if (!function_exists('__')) {
        return array();
    }

    if ('' === $description) {
        $description = __('Choose a custom color for the chart grid lines. For accessibility, ensure it has sufficient contrast against the chart background and do not rely on color alone to convey information.', 'divi-booster');
    }

    return array(
        'type'     => 'object',
        'selector' => '{{selector}}',
        'settings' => array(
            'innerContent' => array(
                'groupType' => 'group-items',
                'items'     => array(
                    $attr_name . 'Field' => array(
                        'groupSlug'   => GROUP_SLUG,
                        'attrName'    => $attr_name,
                        'label'       => $label,
                        'description' => $description,
                        'render'      => true,
                        'priority'    => $priority,
                        'features'    => array(
                            'dynamicContent' => array(
                                'type' => 'color',
                            ),
                            'hover'      => false,
                            'sticky'     => false,
                            'responsive' => true,
                        ),
                        'component'   => array(
                            'type' => 'field',
                            'name' => 'divi/color-picker',
                        ),
                        'defaultAttr' => array(
                            'desktop' => array(
                                'value' => '',
                            ),
                        ),
                    ),
                ),
            ),
        ),
    );
}

function get_grid_line_width_attribute_definition($attr_name, $label, $priority, $description = '') {
    if (!function_exists('__')) {
        return array();
    }

    if ('' === $description) {
        $description = __('Choose a custom width for the chart grid lines.', 'divi-booster');
    }

    return array(
        'type'     => 'object',
        'selector' => '{{selector}}',
        'settings' => array(
            'innerContent' => array(
                'groupType' => 'group-items',
                'items'     => array(
                    $attr_name . 'Field' => array(
                        'groupSlug'   => GROUP_SLUG,
                        'attrName'    => $attr_name,
                        'label'       => $label,
                        'description' => $description,
                        'render'      => true,
                        'priority'    => $priority,
                        'features'    => array(
                            'hover'      => false,
                            'sticky'     => false,
                            'responsive' => true,
                        ),
                        'component'   => array(
                            'type'  => 'field',
                            'name'  => 'divi/range',
                            'props' => array(
                                'allowedUnits' => array('px'),
                                'defaultUnit'  => 'px',
                                'min'          => 0,
                                'minLimit'     => 0,
                                'max'          => 20,
                                'step'         => 1,
                            ),
                        ),
                        'defaultAttr' => array(
                            'desktop' => array(
                                'value' => '1px',
                            ),
                        ),
                    ),
                ),
            ),
        ),
    );
}

// === Runtime data ===

// Convert chart attributes into the runtime data shape.
function get_grid_line_data_from_attrs($attrs, $include_empty) {
    if (!is_array($attrs)) {
        return array();
    }

    $chart_type = get_chart_type_from_attrs($attrs);
    $data       = array(
        'type' => $chart_type,
    );

    if (!chart_type_has_grid_lines($chart_type)) {
        $data['disabled'] = true;
        return $include_empty ? $data : array();
    }

    if (is_cartesian_grid_chart_type($chart_type)) {
        $horizontal = get_responsive_color_values(isset($attrs[HORIZONTAL_COLOR_ATTR]) ? $attrs[HORIZONTAL_COLOR_ATTR] : array());
        $vertical   = get_responsive_color_values(isset($attrs[VERTICAL_COLOR_ATTR]) ? $attrs[VERTICAL_COLOR_ATTR] : array());
        $horizontal_width = get_responsive_line_width_values(isset($attrs[HORIZONTAL_WIDTH_ATTR]) ? $attrs[HORIZONTAL_WIDTH_ATTR] : array());
        $vertical_width   = get_responsive_line_width_values(isset($attrs[VERTICAL_WIDTH_ATTR]) ? $attrs[VERTICAL_WIDTH_ATTR] : array());
        $horizontal_axis_color = get_responsive_color_values(isset($attrs[HORIZONTAL_AXIS_COLOR_ATTR]) ? $attrs[HORIZONTAL_AXIS_COLOR_ATTR] : array());
        $vertical_axis_color   = get_responsive_color_values(isset($attrs[VERTICAL_AXIS_COLOR_ATTR]) ? $attrs[VERTICAL_AXIS_COLOR_ATTR] : array());
        $horizontal_axis_width = get_responsive_line_width_values(isset($attrs[HORIZONTAL_AXIS_WIDTH_ATTR]) ? $attrs[HORIZONTAL_AXIS_WIDTH_ATTR] : array());
        $vertical_axis_width   = get_responsive_line_width_values(isset($attrs[VERTICAL_AXIS_WIDTH_ATTR]) ? $attrs[VERTICAL_AXIS_WIDTH_ATTR] : array());

        if (!empty($horizontal) || $include_empty) {
            $data['horizontal'] = $horizontal;
        }

        if (!empty($vertical) || $include_empty) {
            $data['vertical'] = $vertical;
        }

        if (!empty($horizontal_width) || $include_empty) {
            $data['horizontalWidth'] = $horizontal_width;
        }

        if (!empty($vertical_width) || $include_empty) {
            $data['verticalWidth'] = $vertical_width;
        }

        if (!empty($horizontal_axis_color) || $include_empty) {
            $data['horizontalAxisColor'] = $horizontal_axis_color;
        }

        if (!empty($vertical_axis_color) || $include_empty) {
            $data['verticalAxisColor'] = $vertical_axis_color;
        }

        if (!empty($horizontal_axis_width) || $include_empty) {
            $data['horizontalAxisWidth'] = $horizontal_axis_width;
        }

        if (!empty($vertical_axis_width) || $include_empty) {
            $data['verticalAxisWidth'] = $vertical_axis_width;
        }
    }

    if (is_radial_grid_chart_type($chart_type)) {
        $radial = get_responsive_color_values(isset($attrs[RADIAL_COLOR_ATTR]) ? $attrs[RADIAL_COLOR_ATTR] : array());
        $radial_width = get_responsive_line_width_values(isset($attrs[RADIAL_WIDTH_ATTR]) ? $attrs[RADIAL_WIDTH_ATTR] : array());

        if (!empty($radial) || $include_empty) {
            $data['radial'] = $radial;
        }

        if (!empty($radial_width) || $include_empty) {
            $data['radialWidth'] = $radial_width;
        }
    }

    return grid_line_data_has_values($data) || $include_empty ? $data : array();
}

function grid_line_data_has_values($data) {
    if (!is_array($data)) {
        return false;
    }

    foreach (array('horizontal', 'vertical', 'radial', 'horizontalAxisColor', 'verticalAxisColor') as $key) {
        if (!empty($data[$key]) && is_array($data[$key])) {
            foreach ($data[$key] as $color) {
                if (is_string($color) && '' !== $color) {
                    return true;
                }
            }
        }
    }

    foreach (array('horizontalWidth', 'verticalWidth', 'radialWidth', 'horizontalAxisWidth', 'verticalAxisWidth') as $key) {
        if (!empty($data[$key]) && is_array($data[$key])) {
            foreach ($data[$key] as $width) {
                if (is_int($width) || is_float($width)) {
                    return true;
                }
            }
        }
    }

    return false;
}

function get_chart_type_from_attrs($attrs) {
    if (!function_exists('sanitize_key')) {
        return '';
    }

    $paths = array(
        array('chart', 'advanced', 'config', 'desktop', 'value', 'type'),
        array('chart', 'advanced', 'config', 'tablet', 'value', 'type'),
        array('chart', 'advanced', 'config', 'phone', 'value', 'type'),
        array('chart', 'advanced', 'config', 'type'),
        array('chart', 'innerContent', 'desktop', 'value', 'type'),
        array('chart', 'innerContent', 'type'),
        array('type'),
        array('chartType'),
    );

    foreach ($paths as $path) {
        $value = get_array_path($attrs, $path);

        if (is_array($value)) {
            if (isset($value['value'])) {
                $value = $value['value'];
            } elseif (isset($value['desktop']['value'])) {
                $value = $value['desktop']['value'];
            }
        }

        if (is_scalar($value) && '' !== (string) $value) {
            return sanitize_key((string) $value);
        }
    }

    return 'line';
}

function get_responsive_color_values($attr) {
    if (!is_array($attr) && !is_scalar($attr)) {
        return array();
    }

    $colors = array();

    foreach (array('desktop', 'tablet', 'phone') as $device) {
        $color = get_color_value_for_device($attr, $device);

        if ('' !== $color) {
            $colors[$device] = $color;
        }
    }

    return $colors;
}

function get_responsive_line_width_values($attr) {
    if (!is_array($attr) && !is_scalar($attr)) {
        return array();
    }

    $widths = array();

    foreach (array('desktop', 'tablet', 'phone') as $device) {
        $width = get_line_width_value_for_device($attr, $device);

        if (null !== $width) {
            $widths[$device] = $width;
        }
    }

    return $widths;
}

function get_line_width_value_for_device($attr, $device) {
    if (is_scalar($attr)) {
        return normalize_line_width_value($attr);
    }

    $paths = array(
        array('innerContent', $device, 'value'),
        array($device, 'value'),
        array('value'),
    );

    foreach ($paths as $path) {
        $width = normalize_line_width_value(get_array_path($attr, $path));

        if (null !== $width) {
            return $width;
        }
    }

    return normalize_line_width_value($attr);
}

function normalize_line_width_value($value) {
    if (!function_exists('sanitize_text_field')) {
        return null;
    }

    if (is_array($value)) {
        foreach (array('width', 'lineWidth', 'value') as $key) {
            if (array_key_exists($key, $value)) {
                $width = normalize_line_width_value($value[$key]);

                if (null !== $width) {
                    return $width;
                }
            }
        }

        return null;
    }

    if (!is_scalar($value)) {
        return null;
    }

    $value = trim(sanitize_text_field((string) $value));

    if ('' === $value || !preg_match('/^(?:\d+(?:\.\d*)?|\.\d+)(?:px)?$/i', $value)) {
        return null;
    }

    $width = (float) preg_replace('/px$/i', '', $value);

    if (!is_finite($width) || $width < 0 || $width > 1000) {
        return null;
    }

    return $width;
}

function get_color_value_for_device($attr, $device) {
    $paths = array(
        array('innerContent', $device, 'value'),
        array($device, 'value'),
        array('decoration', 'color', $device, 'value'),
        array('color', $device, 'value'),
        array('value'),
    );

    if (is_scalar($attr)) {
        return sanitize_css_color_value((string) $attr);
    }

    foreach ($paths as $path) {
        $value = get_array_path($attr, $path);
        $color = normalize_color_value($value);

        if ('' !== $color) {
            return $color;
        }
    }

    return normalize_color_value($attr);
}

function normalize_color_value($value) {
    if (is_array($value)) {
        foreach (array('color', 'rgba', 'rgb', 'hex', 'value') as $key) {
            if (isset($value[$key])) {
                $color = normalize_color_value($value[$key]);

                if ('' !== $color) {
                    return $color;
                }
            }
        }

        return '';
    }

    if (!is_scalar($value)) {
        return '';
    }

    return sanitize_css_color_value((string) $value);
}

function sanitize_css_color_value($value) {
    if (!function_exists('sanitize_text_field')) {
        return '';
    }

    $value = trim(sanitize_text_field($value));

    if ('' === $value) {
        return '';
    }

    if (preg_match('/^#[0-9a-f]{3,8}$/i', $value)) {
        return $value;
    }

    if (preg_match('/^(rgba?|hsla?)\([0-9.,%\s]+\)$/i', $value)) {
        return $value;
    }

    if (preg_match('/^[a-z][a-z0-9_-]*$/i', $value)) {
        return $value;
    }

    return '';
}

// === Markup helpers ===

// Add serialized settings to the chart markup.
function inject_chart_data_attribute($html, $attribute_name, $data) {
    if (!function_exists('wp_json_encode')) {
        return $html;
    }

    $json = wp_json_encode($data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

    if (false === $json || !is_string($json)) {
        return $html;
    }

    if (
        class_exists('WP_HTML_Tag_Processor') &&
        method_exists('WP_HTML_Tag_Processor', 'next_tag') &&
        method_exists('WP_HTML_Tag_Processor', 'set_attribute') &&
        method_exists('WP_HTML_Tag_Processor', 'get_updated_html')
    ) {
        try {
            $processor = new \WP_HTML_Tag_Processor($html);

            if (!$processor->next_tag(array('class_name' => 'et_pb_charts'))) {
                $processor = new \WP_HTML_Tag_Processor($html);

                if (!$processor->next_tag()) {
                    return $html;
                }
            }

            $processor->set_attribute($attribute_name, $json);

            return $processor->get_updated_html();
        } catch (\Throwable $exception) {
            return $html;
        }
    }

    if (!function_exists('esc_attr')) {
        return $html;
    }

    return preg_replace_callback(
        '/<([a-z][a-z0-9:-]*)(\s[^>]*)?>/i',
        function($matches) use ($attribute_name, $json) {
            $tag = $matches[0];

            if (preg_match('/\s' . preg_quote($attribute_name, '/') . '=("|\').*?\1/i', $tag)) {
                return $tag;
            }

            return rtrim($tag, '>') . ' ' . $attribute_name . '="' . esc_attr($json) . '">';
        },
        $html,
        1
    );
}

// === Runtime JavaScript ===

// Build the runtime script that applies chart settings.
function get_chart_runtime_js($builder_mode) {
    if (!function_exists('wp_json_encode')) {
        return '';
    }

    $json_flags      = JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;
    $builder_json    = $builder_mode ? 'true' : 'false';
    $data_attr       = wp_json_encode(DATA_ATTR, $json_flags);
    $horizontal_attr = wp_json_encode(HORIZONTAL_COLOR_ATTR, $json_flags);
    $vertical_attr   = wp_json_encode(VERTICAL_COLOR_ATTR, $json_flags);
    $radial_attr     = wp_json_encode(RADIAL_COLOR_ATTR, $json_flags);
    $horizontal_width_attr = wp_json_encode(HORIZONTAL_WIDTH_ATTR, $json_flags);
    $vertical_width_attr   = wp_json_encode(VERTICAL_WIDTH_ATTR, $json_flags);
    $radial_width_attr     = wp_json_encode(RADIAL_WIDTH_ATTR, $json_flags);
    $horizontal_axis_color_attr = wp_json_encode(HORIZONTAL_AXIS_COLOR_ATTR, $json_flags);
    $vertical_axis_color_attr   = wp_json_encode(VERTICAL_AXIS_COLOR_ATTR, $json_flags);
    $horizontal_axis_width_attr = wp_json_encode(HORIZONTAL_AXIS_WIDTH_ATTR, $json_flags);
    $vertical_axis_width_attr   = wp_json_encode(VERTICAL_AXIS_WIDTH_ATTR, $json_flags);
    $cartesian_types = wp_json_encode(get_cartesian_grid_chart_types(), $json_flags);
    $radial_types    = wp_json_encode(get_radial_grid_chart_types(), $json_flags);
    $no_grid_types   = wp_json_encode(get_no_grid_chart_types(), $json_flags);

    if (
        false === $data_attr || false === $horizontal_attr || false === $vertical_attr ||
        false === $radial_attr || false === $horizontal_width_attr || false === $vertical_width_attr ||
        false === $radial_width_attr || false === $horizontal_axis_color_attr || false === $vertical_axis_color_attr ||
        false === $horizontal_axis_width_attr || false === $vertical_axis_width_attr ||
        false === $cartesian_types || false === $radial_types ||
        false === $no_grid_types
    ) {
        return '';
    }

    return <<<JS
(function() {
    if (window.DiviBoosterChartGridLines && window.DiviBoosterChartGridLines.initialized) {
        return;
    }

    var dataAttr = {$data_attr};
    var horizontalAttrSlug = {$horizontal_attr};
    var verticalAttrSlug = {$vertical_attr};
    var radialAttrSlug = {$radial_attr};
    var horizontalWidthAttrSlug = {$horizontal_width_attr};
    var verticalWidthAttrSlug = {$vertical_width_attr};
    var radialWidthAttrSlug = {$radial_width_attr};
    var horizontalAxisColorAttrSlug = {$horizontal_axis_color_attr};
    var verticalAxisColorAttrSlug = {$vertical_axis_color_attr};
    var horizontalAxisWidthAttrSlug = {$horizontal_axis_width_attr};
    var verticalAxisWidthAttrSlug = {$vertical_axis_width_attr};
    var cartesianTypes = {$cartesian_types};
    var radialTypes = {$radial_types};
    var noGridTypes = {$no_grid_types};
    var builderMode = {$builder_json};
    var retryCount = 0;
    var maxRetries = builderMode ? 0 : 50;
    var resizeTimer = null;
    var resizeFollowupTimer = null;

    window.DiviBoosterChartGridLines = {
        initialized: true,
        applyAll: applyAll,
        getDataFromBuilderAttrs: getDataFromBuilderAttrs
    };

    function applyAll(force) {
        var selector = '[' + dataAttr + ']';
        var modules = document.querySelectorAll(selector);
        var appliedAny = false;

        bindChartContainerResizeHandlers(selector);

        for (var i = 0; i < modules.length; i++) {
            try {
                var data = parseData(modules[i].getAttribute(dataAttr));

                if (!data) {
                    continue;
                }

                applyGridLineColorsToDiviChartConfig(modules[i], data);

                var charts = findChartInstances(modules[i]);

                for (var j = 0; j < charts.length; j++) {
                    if (applyGridLineColorsToChart(charts[j], data, force)) {
                        appliedAny = true;
                    }
                }
            } catch (e) {}
        }

        return appliedAny;
    }

    function bindChartContainerResizeHandlers(selector) {
        if (!window.jQuery || !window.jQuery.fn) {
            return;
        }

        var documentQuery;

        try {
            documentQuery = window.jQuery(document);
        } catch (e) {
            return;
        }

        if (!documentQuery || typeof documentQuery.off !== 'function' || typeof documentQuery.on !== 'function') {
            return;
        }

        documentQuery
            .off('containerWidthChanged.diviboosterChartGridLines', selector)
            .on('containerWidthChanged.diviboosterChartGridLines', selector, function() {
                // Reapply after the event so replacement chart instances receive the styles.
                applyAll(true);
                window.setTimeout(function() {
                    applyAll(true);
                }, 0);
            });
    }

    function applyGridLineColorsToDiviChartConfig(moduleElement, data) {
        if (!moduleElement || !data || !window.diviModuleChartsData || !Array.isArray(window.diviModuleChartsData)) {
            return;
        }

        var moduleId = moduleElement.getAttribute('data-module-id');
        var nestedModule = moduleElement.querySelector('[data-module-id]');

        if (!moduleId && nestedModule) {
            moduleId = nestedModule.getAttribute('data-module-id');
        }

        if (!moduleId) {
            return;
        }

        for (var i = 0; i < window.diviModuleChartsData.length; i++) {
            var chartData = window.diviModuleChartsData[i];

            if (!chartData || String(chartData.moduleId) !== String(moduleId) || !chartData.config) {
                continue;
            }

            var chartType = chartData.config.type || getChartType(null, data);
            var options = chartData.config.options || chartData.config;

            if (data.disabled || !hasGridLines(chartType)) {
                restoreAllGridColorsFromOptions(options);
                return;
            }

            if (isCartesianType(chartType)) {
                applyGridColorToAxis(options, {scales: {}}, 'y', getActiveColor(data.horizontal));
                applyGridLineWidthToAxis(options, {scales: {}}, 'y', getActiveLineWidth(data.horizontalWidth));
                applyGridColorToAxis(options, {scales: {}}, 'x', getActiveColor(data.vertical));
                applyGridLineWidthToAxis(options, {scales: {}}, 'x', getActiveLineWidth(data.verticalWidth));
                applyAxisLineColorToAxis(options, {scales: {}}, 'x', getActiveColor(data.horizontalAxisColor));
                applyAxisLineWidthToAxis(options, {scales: {}}, 'x', getActiveLineWidth(data.horizontalAxisWidth));
                applyAxisLineColorToAxis(options, {scales: {}}, 'y', getActiveColor(data.verticalAxisColor));
                applyAxisLineWidthToAxis(options, {scales: {}}, 'y', getActiveLineWidth(data.verticalAxisWidth));
                restoreRadialGridColors(options);
            } else if (isRadialType(chartType)) {
                applyGridColorToRadialScale(options, {scales: {}}, getActiveColor(data.radial));
                applyGridLineWidthToRadialScale(options, {scales: {}}, getActiveLineWidth(data.radialWidth));
                restoreAxisGridColors(options, {scales: {}}, 'x');
                restoreAxisGridColors(options, {scales: {}}, 'y');
            }

            return;
        }
    }

    function parseData(value) {
        if (!value) {
            return null;
        }

        try {
            return JSON.parse(value);
        } catch (e) {
            return null;
        }
    }

    function getDataFromBuilderAttrs(attrs, horizontalSlug, verticalSlug, radialSlug, horizontalWidthSlug, verticalWidthSlug, radialWidthSlug, horizontalAxisColorSlug, verticalAxisColorSlug, horizontalAxisWidthSlug, verticalAxisWidthSlug) {
        var chartType = readChartType(attrs || {}, getCurrentDevice());
        var data = { type: chartType };

        if (!hasGridLines(chartType)) {
            data.disabled = true;
            return data;
        }

        if (isCartesianType(chartType)) {
            data.horizontal = getResponsiveColorValues(readBuilderAttr(attrs, horizontalSlug || horizontalAttrSlug));
            data.vertical = getResponsiveColorValues(readBuilderAttr(attrs, verticalSlug || verticalAttrSlug));
            data.horizontalWidth = getResponsiveLineWidthValues(readBuilderAttr(attrs, horizontalWidthSlug || horizontalWidthAttrSlug));
            data.verticalWidth = getResponsiveLineWidthValues(readBuilderAttr(attrs, verticalWidthSlug || verticalWidthAttrSlug));
            data.horizontalAxisColor = getResponsiveColorValues(readBuilderAttr(attrs, horizontalAxisColorSlug || horizontalAxisColorAttrSlug));
            data.verticalAxisColor = getResponsiveColorValues(readBuilderAttr(attrs, verticalAxisColorSlug || verticalAxisColorAttrSlug));
            data.horizontalAxisWidth = getResponsiveLineWidthValues(readBuilderAttr(attrs, horizontalAxisWidthSlug || horizontalAxisWidthAttrSlug));
            data.verticalAxisWidth = getResponsiveLineWidthValues(readBuilderAttr(attrs, verticalAxisWidthSlug || verticalAxisWidthAttrSlug));
        }

        if (isRadialType(chartType)) {
            data.radial = getResponsiveColorValues(readBuilderAttr(attrs, radialSlug || radialAttrSlug));
            data.radialWidth = getResponsiveLineWidthValues(readBuilderAttr(attrs, radialWidthSlug || radialWidthAttrSlug));
        }

        return data;
    }

    function readBuilderAttr(attrs, slug) {
        if (!attrs || !slug) {
            return null;
        }

        var paths = [
            [slug],
            ['module', slug],
            ['attrs', slug],
            ['attributes', slug],
            ['module', 'attributes', slug]
        ];

        for (var i = 0; i < paths.length; i++) {
            var value = getPath(attrs, paths[i]);

            if (value !== undefined && value !== null) {
                return value;
            }
        }

        return null;
    }

    function readChartType(attrs, responsiveMode) {
        var device = responsiveMode || 'desktop';
        var paths = [
            ['chart', 'advanced', 'config', device, 'value', 'type'],
            ['chart', 'advanced', 'config', 'desktop', 'value', 'type'],
            ['chart', 'advanced', 'config', 'tablet', 'value', 'type'],
            ['chart', 'advanced', 'config', 'phone', 'value', 'type'],
            ['chart', 'advanced', 'config', 'type'],
            ['chart', 'innerContent', 'desktop', 'value', 'type'],
            ['chart', 'innerContent', 'type'],
            ['module', 'chart', 'advanced', 'config', 'type'],
            ['type'],
            ['chartType']
        ];

        for (var i = 0; i < paths.length; i++) {
            var value = getPath(attrs, paths[i]);

            if (value && typeof value === 'object') {
                value = value.value || (value.desktop && value.desktop.value) || '';
            }

            if (value !== undefined && value !== null && value !== '') {
                return String(value);
            }
        }

        return 'line';
    }

    function getResponsiveColorValues(attr) {
        var colors = {};

        ['desktop', 'tablet', 'phone'].forEach(function(device) {
            var color = getColorValueForDevice(attr, device);

            if (color) {
                colors[device] = color;
            }
        });

        return colors;
    }

    function getResponsiveLineWidthValues(attr) {
        var widths = {};

        ['desktop', 'tablet', 'phone'].forEach(function(device) {
            var width = getLineWidthValueForDevice(attr, device);

            if (width !== null) {
                widths[device] = width;
            }
        });

        return widths;
    }

    function getLineWidthValueForDevice(attr, device) {
        if (typeof attr === 'string' || typeof attr === 'number') {
            return normalizeLineWidth(attr);
        }

        var paths = [
            ['innerContent', device, 'value'],
            [device, 'value'],
            ['value']
        ];

        for (var i = 0; i < paths.length; i++) {
            var width = normalizeLineWidth(getPath(attr, paths[i]));

            if (width !== null) {
                return width;
            }
        }

        return normalizeLineWidth(attr);
    }

    function normalizeLineWidth(value) {
        if (value && typeof value === 'object') {
            var keys = ['width', 'lineWidth', 'value'];

            for (var i = 0; i < keys.length; i++) {
                if (Object.prototype.hasOwnProperty.call(value, keys[i])) {
                    var nestedWidth = normalizeLineWidth(value[keys[i]]);

                    if (nestedWidth !== null) {
                        return nestedWidth;
                    }
                }
            }

            return null;
        }

        if (typeof value !== 'string' && typeof value !== 'number') {
            return null;
        }

        var stringValue = String(value).trim();

        if (!/^(?:\d+(?:\.\d*)?|\.\d+)(?:px)?$/i.test(stringValue)) {
            return null;
        }

        var width = Number(stringValue.replace(/px$/i, ''));

        return isFinite(width) && width >= 0 && width <= 1000 ? width : null;
    }

    function getColorValueForDevice(attr, device) {
        if (typeof attr === 'string') {
            return sanitizeColor(attr);
        }

        var paths = [
            ['innerContent', device, 'value'],
            [device, 'value'],
            ['decoration', 'color', device, 'value'],
            ['color', device, 'value'],
            ['value']
        ];

        for (var i = 0; i < paths.length; i++) {
            var color = normalizeColor(getPath(attr, paths[i]));

            if (color) {
                return color;
            }
        }

        return normalizeColor(attr);
    }

    function normalizeColor(value) {
        if (!value) {
            return '';
        }

        if (typeof value === 'object') {
            var keys = ['color', 'rgba', 'rgb', 'hex', 'value'];

            for (var i = 0; i < keys.length; i++) {
                if (value[keys[i]] !== undefined) {
                    var color = normalizeColor(value[keys[i]]);

                    if (color) {
                        return color;
                    }
                }
            }

            return '';
        }

        return sanitizeColor(String(value));
    }

    function sanitizeColor(value) {
        value = String(value || '').trim();

        if (!value) {
            return '';
        }

        if (/^#[0-9a-f]{3,8}$/i.test(value) || /^(rgba?|hsla?)\([0-9.,%\s]+\)$/i.test(value) || /^[a-z][a-z0-9_-]*$/i.test(value)) {
            return value;
        }

        return '';
    }

    function getPath(obj, path) {
        var current = obj;

        for (var i = 0; i < path.length; i++) {
            if (!current || typeof current !== 'object') {
                return undefined;
            }

            if (typeof current.has === 'function' && current.has(path[i])) {
                current = current.get(path[i]);
            } else if (Object.prototype.hasOwnProperty.call(current, path[i])) {
                current = current[path[i]];
            } else {
                return undefined;
            }
        }

        return current && typeof current.toJS === 'function' ? current.toJS() : current;
    }

    function getActiveColor(colors) {
        if (!colors || typeof colors !== 'object') {
            return '';
        }

        var device = getCurrentDevice();

        return sanitizeColor(colors[device] || colors.desktop || colors.tablet || colors.phone || '');
    }

    function getActiveLineWidth(widths) {
        if (!widths || typeof widths !== 'object') {
            return null;
        }

        var device = getCurrentDevice();
        var devices = [device, 'desktop', 'tablet', 'phone'];

        for (var i = 0; i < devices.length; i++) {
            if (Object.prototype.hasOwnProperty.call(widths, devices[i])) {
                var width = normalizeLineWidth(widths[devices[i]]);

                if (width !== null) {
                    return width;
                }
            }
        }

        return null;
    }

    function getCurrentDevice() {
        var width = window.innerWidth || (document.documentElement && document.documentElement.clientWidth) || 0;

        if (width <= 767) {
            return 'phone';
        }

        if (width <= 980) {
            return 'tablet';
        }

        return 'desktop';
    }

    function normalizeType(type) {
        return String(type || 'line').replace(/[_\s-]+/g, '').toLowerCase();
    }

    function isCartesianType(type) {
        return cartesianTypes.indexOf(normalizeType(type)) !== -1;
    }

    function isRadialType(type) {
        return radialTypes.indexOf(normalizeType(type)) !== -1;
    }

    function hasGridLines(type) {
        type = normalizeType(type);

        if (noGridTypes.indexOf(type) !== -1) {
            return false;
        }

        return isCartesianType(type) || isRadialType(type);
    }

    function getChartType(chart, data) {
        // Prefer the live config when attributes lag during a type change.
        if (chart && chart.config && chart.config.type) {
            return chart.config.type;
        }

        return data && data.type ? data.type : 'line';
    }

    function applyGridLineColorsToChart(chart, data, force) {
        if (!chart || !data) {
            return false;
        }

        var chartType = getChartType(chart, data);

        if (data.disabled || !hasGridLines(chartType)) {
            restoreAllGridColors(chart);
            chart.__diviboosterGridLineColorsHash = '';
            updateChart(chart);
            return true;
        }

        var horizontal = getActiveColor(data.horizontal);
        var vertical = getActiveColor(data.vertical);
        var radial = getActiveColor(data.radial);
        var horizontalWidth = getActiveLineWidth(data.horizontalWidth);
        var verticalWidth = getActiveLineWidth(data.verticalWidth);
        var radialWidth = getActiveLineWidth(data.radialWidth);
        var horizontalAxisColor = getActiveColor(data.horizontalAxisColor);
        var verticalAxisColor = getActiveColor(data.verticalAxisColor);
        var horizontalAxisWidth = getActiveLineWidth(data.horizontalAxisWidth);
        var verticalAxisWidth = getActiveLineWidth(data.verticalAxisWidth);
        var active = {
            type: normalizeType(chartType),
            horizontal: horizontal,
            vertical: vertical,
            radial: radial,
            horizontalWidth: horizontalWidth,
            verticalWidth: verticalWidth,
            radialWidth: radialWidth,
            horizontalAxisColor: horizontalAxisColor,
            verticalAxisColor: verticalAxisColor,
            horizontalAxisWidth: horizontalAxisWidth,
            verticalAxisWidth: verticalAxisWidth
        };
        var hash = stableStringify(active);

        if (
            !force &&
            chart.__diviboosterGridLineColorsHash === hash &&
            gridLineStylesAreApplied(chart, chartType, horizontal, vertical, radial, horizontalWidth, verticalWidth, radialWidth, horizontalAxisColor, verticalAxisColor, horizontalAxisWidth, verticalAxisWidth)
        ) {
            return true;
        }

        var options = (chart.config && chart.config.options) || chart.options || {};

        if (isCartesianType(chartType)) {
            applyGridColorToAxis(options, chart, 'y', horizontal);
            applyGridLineWidthToAxis(options, chart, 'y', horizontalWidth);
            applyGridColorToAxis(options, chart, 'x', vertical);
            applyGridLineWidthToAxis(options, chart, 'x', verticalWidth);
            applyAxisLineColorToAxis(options, chart, 'x', horizontalAxisColor);
            applyAxisLineWidthToAxis(options, chart, 'x', horizontalAxisWidth);
            applyAxisLineColorToAxis(options, chart, 'y', verticalAxisColor);
            applyAxisLineWidthToAxis(options, chart, 'y', verticalAxisWidth);
            restoreRadialGridColors(options);
        } else if (isRadialType(chartType)) {
            applyGridColorToRadialScale(options, chart, radial);
            applyGridLineWidthToRadialScale(options, chart, radialWidth);
            restoreAxisGridColors(options, chart, 'x');
            restoreAxisGridColors(options, chart, 'y');
        }

        chart.__diviboosterGridLineColorsHash = hash;
        updateChart(chart);

        return true;
    }

    function gridLineStylesAreApplied(chart, chartType, horizontal, vertical, radial, horizontalWidth, verticalWidth, radialWidth, horizontalAxisColor, verticalAxisColor, horizontalAxisWidth, verticalAxisWidth) {
        var options = (chart.config && chart.config.options) || chart.options || {};

        if (isCartesianType(chartType)) {
            return gridColorIsAppliedToAxis(options, chart, 'y', horizontal) &&
                gridLineWidthIsAppliedToAxis(options, chart, 'y', horizontalWidth) &&
                gridColorIsAppliedToAxis(options, chart, 'x', vertical) &&
                gridLineWidthIsAppliedToAxis(options, chart, 'x', verticalWidth) &&
                axisLineColorIsAppliedToAxis(options, chart, 'x', horizontalAxisColor) &&
                axisLineWidthIsAppliedToAxis(options, chart, 'x', horizontalAxisWidth) &&
                axisLineColorIsAppliedToAxis(options, chart, 'y', verticalAxisColor) &&
                axisLineWidthIsAppliedToAxis(options, chart, 'y', verticalAxisWidth);
        }

        if (isRadialType(chartType)) {
            return gridColorIsAppliedToRadialScale(options, chart, radial) &&
                gridLineWidthIsAppliedToRadialScale(options, chart, radialWidth);
        }

        return true;
    }

    // === Chart configuration compatibility ===
    // Choose update paths from the available scale shape and version.
    function getChartJsMajorVersion() {
        var version = window.Chart && window.Chart.version ? String(window.Chart.version) : '';
        var major = parseInt(version, 10);

        return isFinite(major) ? major : 0;
    }

    function scaleCollectionHasProperty(scales, property) {
        if (!scales || typeof scales !== 'object') {
            return false;
        }

        return Object.keys(scales).some(function(key) {
            var entries = Array.isArray(scales[key]) ? scales[key] : [scales[key]];

            return entries.some(function(scaleOptions) {
                return !!(
                    scaleOptions &&
                    typeof scaleOptions === 'object' &&
                    Object.prototype.hasOwnProperty.call(scaleOptions, property)
                );
            });
        });
    }

    function scaleOptionHasNestedProperty(scaleOptions, container, property) {
        return !!(
            scaleOptions &&
            typeof scaleOptions === 'object' &&
            scaleOptions[container] &&
            typeof scaleOptions[container] === 'object' &&
            Object.prototype.hasOwnProperty.call(scaleOptions[container], property)
        );
    }

    function scaleCollectionHasNestedProperty(scales, container, property) {
        if (!scales || typeof scales !== 'object') {
            return false;
        }

        return Object.keys(scales).some(function(key) {
            var entries = Array.isArray(scales[key]) ? scales[key] : [scales[key]];

            return entries.some(function(scaleOptions) {
                return scaleOptionHasNestedProperty(scaleOptions, container, property);
            });
        });
    }

    function getChartConfigAdapter(options, chart) {
        if ((!options || typeof options !== 'object') && chart && chart.config && chart.config.options) {
            options = chart.config.options;
        }

        if (!options || typeof options !== 'object') {
            options = {};
        }

        var scales = options.scales && typeof options.scales === 'object' ? options.scales : null;
        var chartMajor = getChartJsMajorVersion();
        var usesAxisArrays = !!(
            scales &&
            (Array.isArray(scales.xAxes) || Array.isArray(scales.yAxes))
        );
        var usesLegacyScale = !!(options.scale && typeof options.scale === 'object');
        var usesLegacyGridLines = !!(
            chartMajor === 2 ||
            usesAxisArrays ||
            usesLegacyScale ||
            scaleCollectionHasProperty(scales, 'gridLines') ||
            (options.scale && typeof options.scale === 'object' &&
                Object.prototype.hasOwnProperty.call(options.scale, 'gridLines'))
        );
        var usesLegacyAxisBorder = !!(
            chartMajor === 3 ||
            usesAxisArrays ||
            usesLegacyScale ||
            scaleCollectionHasNestedProperty(scales, 'grid', 'borderColor') ||
            scaleCollectionHasNestedProperty(scales, 'grid', 'borderWidth') ||
            scaleOptionHasNestedProperty(options.scale, 'grid', 'borderColor') ||
            scaleOptionHasNestedProperty(options.scale, 'grid', 'borderWidth')
        );
        return {
            usesAxisArrays: usesAxisArrays,
            usesLegacyScale: usesLegacyScale,
            usesLegacyGridLines: usesLegacyGridLines,
            usesLegacyAxisBorder: usesLegacyAxisBorder,
            usesModernGrid: true,
            usesModernAxisBorder: true
        };
    }

    function getScaleConfigAdapter(scaleOptions) {
        var hasLegacyGridLines = !!(
            scaleOptions &&
            typeof scaleOptions === 'object' &&
            scaleOptions.gridLines &&
            typeof scaleOptions.gridLines === 'object'
        );
        var hasLegacyAxisBorder =
            scaleOptionHasNestedProperty(scaleOptions, 'grid', 'borderColor') ||
            scaleOptionHasNestedProperty(scaleOptions, 'grid', 'borderWidth');
        var chartMajor = getChartJsMajorVersion();

        return {
            usesAxisArrays: false,
            usesLegacyScale: false,
            usesLegacyGridLines: hasLegacyGridLines || chartMajor === 2,
            usesLegacyAxisBorder: hasLegacyAxisBorder || chartMajor === 3,
            usesModernGrid: true,
            usesModernAxisBorder: true
        };
    }

    function gridColorIsAppliedToAxis(options, chart, axis, color) {
        if (!color) {
            return true;
        }

        if (
            (!options.scales || typeof options.scales !== 'object') &&
            (!options.scale || typeof options.scale !== 'object')
        ) {
            return false;
        }

        var adapter = getChartConfigAdapter(options, chart);

        if (adapter.usesAxisArrays && options.scales && Array.isArray(options.scales[axis + 'Axes'])) {
            return options.scales[axis + 'Axes'].every(function(scaleOptions) {
                return gridColorMatches(scaleOptions, color, adapter);
            });
        }

        var scaleKeys = getAxisScaleKeys(options, chart, axis);

        if (!scaleKeys.length) {
            return false;
        }

        return scaleKeys.every(function(scaleKey) {
            var configuredScale = options.scales[scaleKey];
            var liveScale = chart.scales && chart.scales[scaleKey];

            return gridColorMatches(configuredScale, color, adapter) &&
                (!liveScale || !liveScale.options || gridColorMatches(liveScale.options, color, adapter));
        });
    }

    function gridLineWidthIsAppliedToAxis(options, chart, axis, width) {
        if (width === null) {
            return true;
        }

        if (
            (!options.scales || typeof options.scales !== 'object') &&
            (!options.scale || typeof options.scale !== 'object')
        ) {
            return false;
        }

        var adapter = getChartConfigAdapter(options, chart);

        if (adapter.usesAxisArrays && options.scales && Array.isArray(options.scales[axis + 'Axes'])) {
            return options.scales[axis + 'Axes'].every(function(scaleOptions) {
                return gridLineWidthMatches(scaleOptions, width, adapter);
            });
        }

        var scaleKeys = getAxisScaleKeys(options, chart, axis);

        if (!scaleKeys.length) {
            return false;
        }

        return scaleKeys.every(function(scaleKey) {
            var configuredScale = options.scales[scaleKey];
            var liveScale = chart.scales && chart.scales[scaleKey];

            return gridLineWidthMatches(configuredScale, width, adapter) &&
                (!liveScale || !liveScale.options || gridLineWidthMatches(liveScale.options, width, adapter));
        });
    }

    function axisLineColorIsAppliedToAxis(options, chart, axis, color) {
        if (!color) {
            return true;
        }

        return axisLineValueIsAppliedToAxis(options, chart, axis, color, axisLineColorMatches);
    }

    function axisLineWidthIsAppliedToAxis(options, chart, axis, width) {
        if (width === null) {
            return true;
        }

        return axisLineValueIsAppliedToAxis(options, chart, axis, width, axisLineWidthMatches);
    }

    function axisLineValueIsAppliedToAxis(options, chart, axis, value, matcher) {
        if (!options.scales || typeof options.scales !== 'object') {
            return false;
        }

        var adapter = getChartConfigAdapter(options, chart);

        if (adapter.usesAxisArrays && Array.isArray(options.scales[axis + 'Axes'])) {
            return options.scales[axis + 'Axes'].every(function(scaleOptions) {
                return matcher(scaleOptions, value, adapter);
            });
        }

        var scaleKeys = getAxisScaleKeys(options, chart, axis);

        if (!scaleKeys.length) {
            return false;
        }

        return scaleKeys.every(function(scaleKey) {
            var configuredScale = options.scales[scaleKey];
            var liveScale = chart.scales && chart.scales[scaleKey];

            return matcher(configuredScale, value, adapter) &&
                (!liveScale || !liveScale.options || matcher(liveScale.options, value, adapter));
        });
    }

    function gridColorIsAppliedToRadialScale(options, chart, color) {
        if (!color) {
            return true;
        }

        if (
            (!options.scales || typeof options.scales !== 'object') &&
            (!options.scale || typeof options.scale !== 'object')
        ) {
            return false;
        }

        var adapter = getChartConfigAdapter(options, chart);
        var scaleKeys = getRadialScaleKeys(options, chart);

        if (!scaleKeys.length) {
            return !!options.scale && gridColorMatches(options.scale, color, adapter);
        }

        var scalesMatch = scaleKeys.every(function(scaleKey) {
            var configuredScale = options.scales[scaleKey];
            var liveScale = chart.scales && chart.scales[scaleKey];

            return gridColorMatches(configuredScale, color, adapter) &&
                (!liveScale || !liveScale.options || gridColorMatches(liveScale.options, color, adapter));
        });

        if (!scalesMatch) {
            return false;
        }

        return !options.scale || gridColorMatches(options.scale, color, adapter);
    }

    function gridLineWidthIsAppliedToRadialScale(options, chart, width) {
        if (width === null) {
            return true;
        }

        if (
            (!options.scales || typeof options.scales !== 'object') &&
            (!options.scale || typeof options.scale !== 'object')
        ) {
            return false;
        }

        var adapter = getChartConfigAdapter(options, chart);
        var scaleKeys = getRadialScaleKeys(options, chart);

        if (!scaleKeys.length) {
            return !!options.scale && gridLineWidthMatches(options.scale, width, adapter);
        }

        var scalesMatch = scaleKeys.every(function(scaleKey) {
            var configuredScale = options.scales[scaleKey];
            var liveScale = chart.scales && chart.scales[scaleKey];

            return gridLineWidthMatches(configuredScale, width, adapter) &&
                (!liveScale || !liveScale.options || gridLineWidthMatches(liveScale.options, width, adapter));
        });

        if (!scalesMatch) {
            return false;
        }

        return !options.scale || gridLineWidthMatches(options.scale, width, adapter);
    }

    function gridColorMatches(scaleOptions, color, adapter) {
        if (!scaleOptions || typeof scaleOptions !== 'object') {
            return false;
        }

        adapter = adapter || getScaleConfigAdapter(scaleOptions);

        return !!(
            (adapter.usesModernGrid && scaleOptions.grid && scaleOptions.grid.color === color) ||
            (adapter.usesLegacyGridLines && scaleOptions.gridLines && scaleOptions.gridLines.color === color)
        );
    }

    function gridLineWidthMatches(scaleOptions, width, adapter) {
        if (!scaleOptions || typeof scaleOptions !== 'object') {
            return false;
        }

        adapter = adapter || getScaleConfigAdapter(scaleOptions);

        return !!(
            (adapter.usesModernGrid && scaleOptions.grid && Number(scaleOptions.grid.lineWidth) === width) ||
            (adapter.usesLegacyGridLines && scaleOptions.gridLines && Number(scaleOptions.gridLines.lineWidth) === width)
        );
    }

    function axisLineColorMatches(scaleOptions, color, adapter) {
        if (!scaleOptions || typeof scaleOptions !== 'object') {
            return false;
        }

        adapter = adapter || getScaleConfigAdapter(scaleOptions);

        return !!(
            (adapter.usesModernAxisBorder && scaleOptions.border && scaleOptions.border.color === color) ||
            (adapter.usesLegacyAxisBorder && scaleOptions.grid && scaleOptions.grid.borderColor === color)
        );
    }

    function axisLineWidthMatches(scaleOptions, width, adapter) {
        if (!scaleOptions || typeof scaleOptions !== 'object') {
            return false;
        }

        adapter = adapter || getScaleConfigAdapter(scaleOptions);

        return !!(
            (adapter.usesModernAxisBorder && scaleOptions.border && Number(scaleOptions.border.width) === width) ||
            (adapter.usesLegacyAxisBorder && scaleOptions.grid && Number(scaleOptions.grid.borderWidth) === width)
        );
    }

    function updateChart(chart) {
        try {
            chart.update('none');
        } catch (e) {
            try {
                chart.update();
            } catch (ignore) {}
        }
    }

    function applyGridColorToAxis(options, chart, axis, color) {
        applyScaleValueToAxis(options, chart, axis, color, !!color, setGridColor);
    }

    function applyGridLineWidthToAxis(options, chart, axis, width) {
        applyScaleValueToAxis(options, chart, axis, width, width !== null, setGridLineWidth);
    }

    function applyAxisLineColorToAxis(options, chart, axis, color) {
        applyScaleValueToAxis(options, chart, axis, color, !!color, setAxisLineColor);
    }

    function applyAxisLineWidthToAxis(options, chart, axis, width) {
        applyScaleValueToAxis(options, chart, axis, width, width !== null, setAxisLineWidth);
    }

    function applyScaleValueToAxis(options, chart, axis, value, hasValue, setter) {
        if (!options || typeof options !== 'object') {
            return;
        }

        var adapter = getChartConfigAdapter(options, chart);

        if (!options.scales || typeof options.scales !== 'object') {
            options.scales = {};
        }

        if (adapter.usesAxisArrays && Array.isArray(options.scales[axis + 'Axes'])) {
            options.scales[axis + 'Axes'].forEach(function(scaleOptions) {
                setter(scaleOptions, value, adapter);
            });
            return;
        }

        var scaleKeys = getAxisScaleKeys(options, chart, axis);

        if (!scaleKeys.length) {
            scaleKeys = [axis];
        }

        scaleKeys.forEach(function(scaleKey) {
            if (!options.scales[scaleKey] || typeof options.scales[scaleKey] !== 'object') {
                if (!hasValue) {
                    return;
                }

                options.scales[scaleKey] = {};
                markCreatedGridScale(options.scales[scaleKey]);
            }

            setter(options.scales[scaleKey], value, adapter);
        });
    }

    function restoreAxisGridColors(options, chart, axis) {
        if (!options || !options.scales || typeof options.scales !== 'object') {
            return;
        }

        var adapter = getChartConfigAdapter(options, chart);

        if (adapter.usesAxisArrays && Array.isArray(options.scales[axis + 'Axes'])) {
            options.scales[axis + 'Axes'].forEach(function(scaleOptions) {
                restoreGridColor(scaleOptions, adapter);
                restoreGridLineWidth(scaleOptions, adapter);
                restoreAxisLineColor(scaleOptions, adapter);
                restoreAxisLineWidth(scaleOptions, adapter);
            });
            return;
        }

        getAxisScaleKeys(options, chart, axis).forEach(function(scaleKey) {
            var scaleOptions = options.scales[scaleKey];

            restoreGridColor(scaleOptions, adapter);
            restoreGridLineWidth(scaleOptions, adapter);
            restoreAxisLineColor(scaleOptions, adapter);
            restoreAxisLineWidth(scaleOptions, adapter);

            if (scaleOptions && scaleOptions.__diviboosterCreatedGridScale) {
                delete options.scales[scaleKey];
            }
        });
    }

    function getAxisScaleKeys(options, chart, axis) {
        var keys = [];

        if (!options || typeof options !== 'object') {
            return keys;
        }

        if (chart && chart.scales && typeof chart.scales === 'object') {
            keys = getScaleKeys(chart.scales, axis);
        }

        if (!keys.length && options.scales && typeof options.scales === 'object') {
            keys = getScaleKeys(options.scales, axis);
        }

        return keys;
    }

    function getScaleKeys(scales, axis) {
        var keys = [];

        Object.keys(scales).forEach(function(key) {
            var scale = scales[key];

            if ((scale && scale.axis === axis) || key === axis || normalizeType(key).indexOf(axis) === 0) {
                keys.push(key);
            }
        });

        return keys;
    }

    function applyGridColorToRadialScale(options, chart, color) {
        applyGridValueToRadialScale(options, chart, color, !!color, setGridColor);
    }

    function applyGridLineWidthToRadialScale(options, chart, width) {
        applyGridValueToRadialScale(options, chart, width, width !== null, setGridLineWidth);
    }

    function applyGridValueToRadialScale(options, chart, value, hasValue, setter) {
        if (!options || typeof options !== 'object') {
            return;
        }

        var adapter = getChartConfigAdapter(options, chart);
        var keys = getRadialScaleKeys(options, chart);

        if (!keys.length) {
            if (options.scale && typeof options.scale === 'object') {
                setter(options.scale, value, adapter);
                return;
            }

            // Target the standard `r` key when the radial scale is absent.
            if (hasValue) {
                if (!options.scales || typeof options.scales !== 'object') {
                    options.scales = {};
                }

                if (!options.scales.r || typeof options.scales.r !== 'object') {
                    options.scales.r = {};
                    markCreatedGridScale(options.scales.r);
                }

                setter(options.scales.r, value, adapter);
            }

            return;
        }

        if (!options.scales || typeof options.scales !== 'object') {
            options.scales = {};
        }

        keys.forEach(function(key) {
            if (!options.scales[key] || typeof options.scales[key] !== 'object') {
                if (!hasValue) {
                    return;
                }

                options.scales[key] = {};
                markCreatedGridScale(options.scales[key]);
            }

            setter(options.scales[key], value, adapter);
        });

        if (options.scale && typeof options.scale === 'object') {
            setter(options.scale, value, adapter);
        }
    }

    function restoreRadialGridColors(options) {
        if (!options || typeof options !== 'object') {
            return;
        }

        var adapter = getChartConfigAdapter(options);

        if (options.scales && typeof options.scales === 'object') {
            Object.keys(options.scales).forEach(function(key) {
                if (isRadialScaleKey(key, options.scales[key])) {
                    var scaleOptions = options.scales[key];

                    restoreGridColor(scaleOptions, adapter);
                    restoreGridLineWidth(scaleOptions, adapter);

                    if (scaleOptions && scaleOptions.__diviboosterCreatedGridScale) {
                        delete options.scales[key];
                    }
                }
            });
        }

        if (options.scale && typeof options.scale === 'object') {
            restoreGridColor(options.scale, adapter);
            restoreGridLineWidth(options.scale, adapter);
        }
    }

    function getRadialScaleKeys(options, chart) {
        var keys = [];
        var sources = [];

        if (!options || typeof options !== 'object') {
            return keys;
        }

        if (chart && chart.scales && typeof chart.scales === 'object') {
            sources.push(chart.scales);
        }

        if (options.scales && typeof options.scales === 'object') {
            sources.push(options.scales);
        }

        sources.forEach(function(scales) {
            Object.keys(scales).forEach(function(key) {
                if (keys.indexOf(key) === -1 && isRadialScaleKey(key, scales[key])) {
                    keys.push(key);
                }
            });
        });

        return keys;
    }

    function isRadialScaleKey(key, scale) {
        var normalizedKey = normalizeType(key);
        var type = scale && scale.type ? normalizeType(scale.type) : '';
        var axis = scale && scale.axis ? String(scale.axis).toLowerCase() : '';

        return normalizedKey === 'r' || normalizedKey.indexOf('radial') !== -1 || type.indexOf('radial') !== -1 || axis === 'r';
    }

    function markCreatedGridScale(scaleOptions) {
        if (!scaleOptions || typeof scaleOptions !== 'object' || scaleOptions.__diviboosterCreatedGridScale) {
            return;
        }

        try {
            Object.defineProperty(scaleOptions, '__diviboosterCreatedGridScale', {
                value: true,
                enumerable: false,
                configurable: true
            });
        } catch (e) {
            scaleOptions.__diviboosterCreatedGridScale = true;
        }
    }

    function setGridColor(scaleOptions, color, adapter) {
        if (!scaleOptions || typeof scaleOptions !== 'object') {
            return;
        }

        adapter = adapter || getScaleConfigAdapter(scaleOptions);
        rememberOriginalGridColor(scaleOptions);

        if (!color) {
            restoreGridColor(scaleOptions, adapter);
            return;
        }

        if (adapter.usesModernGrid) {
            if (!scaleOptions.grid || typeof scaleOptions.grid !== 'object') {
                scaleOptions.grid = {};
            }

            scaleOptions.grid.color = color;
        }

        if (adapter.usesLegacyGridLines) {
            if (!scaleOptions.gridLines || typeof scaleOptions.gridLines !== 'object') {
                scaleOptions.gridLines = {};
            }

            scaleOptions.gridLines.color = color;
        }
    }

    function setGridLineWidth(scaleOptions, width, adapter) {
        if (!scaleOptions || typeof scaleOptions !== 'object') {
            return;
        }

        adapter = adapter || getScaleConfigAdapter(scaleOptions);
        rememberOriginalGridLineWidth(scaleOptions);

        if (width === null) {
            restoreGridLineWidth(scaleOptions, adapter);
            return;
        }

        if (adapter.usesModernGrid) {
            if (!scaleOptions.grid || typeof scaleOptions.grid !== 'object') {
                scaleOptions.grid = {};
            }

            scaleOptions.grid.lineWidth = width;
        }

        if (adapter.usesLegacyGridLines) {
            if (!scaleOptions.gridLines || typeof scaleOptions.gridLines !== 'object') {
                scaleOptions.gridLines = {};
            }

            scaleOptions.gridLines.lineWidth = width;
        }
    }

    function setAxisLineColor(scaleOptions, color, adapter) {
        setAxisLineProperty(
            scaleOptions,
            'color',
            'borderColor',
            '__diviboosterOriginalAxisLineColor',
            color,
            !!color,
            adapter
        );
    }

    function setAxisLineWidth(scaleOptions, width, adapter) {
        setAxisLineProperty(
            scaleOptions,
            'width',
            'borderWidth',
            '__diviboosterOriginalAxisLineWidth',
            width,
            width !== null,
            adapter
        );
    }

    function setAxisLineProperty(scaleOptions, borderProperty, gridProperty, marker, value, hasValue, adapter) {
        if (!scaleOptions || typeof scaleOptions !== 'object') {
            return;
        }

        adapter = adapter || getScaleConfigAdapter(scaleOptions);
        rememberOriginalAxisLineProperty(scaleOptions, borderProperty, gridProperty, marker);

        if (!hasValue) {
            restoreAxisLineProperty(scaleOptions, borderProperty, gridProperty, marker, adapter);
            return;
        }

        if (adapter.usesModernAxisBorder) {
            if (!scaleOptions.border || typeof scaleOptions.border !== 'object') {
                scaleOptions.border = {};
            }

            scaleOptions.border[borderProperty] = value;
        }

        // Support legacy axis-border keys alongside the modern border path.
        if (adapter.usesLegacyAxisBorder) {
            if (!scaleOptions.grid || typeof scaleOptions.grid !== 'object') {
                scaleOptions.grid = {};
            }

            scaleOptions.grid[gridProperty] = value;
        }
    }

    function rememberOriginalAxisLineProperty(scaleOptions, borderProperty, gridProperty, marker) {
        if (!scaleOptions || typeof scaleOptions !== 'object' || scaleOptions[marker]) {
            return;
        }

        var original = {
            borderExists: !!scaleOptions.border,
            borderValueExists: !!(scaleOptions.border && Object.prototype.hasOwnProperty.call(scaleOptions.border, borderProperty)),
            borderValue: scaleOptions.border && Object.prototype.hasOwnProperty.call(scaleOptions.border, borderProperty) ? scaleOptions.border[borderProperty] : undefined,
            gridExists: !!scaleOptions.grid,
            gridValueExists: !!(scaleOptions.grid && Object.prototype.hasOwnProperty.call(scaleOptions.grid, gridProperty)),
            gridValue: scaleOptions.grid && Object.prototype.hasOwnProperty.call(scaleOptions.grid, gridProperty) ? scaleOptions.grid[gridProperty] : undefined
        };

        try {
            Object.defineProperty(scaleOptions, marker, {
                value: original,
                enumerable: false,
                configurable: true
            });
        } catch (e) {
            scaleOptions[marker] = original;
        }
    }

    function restoreAxisLineColor(scaleOptions, adapter) {
        restoreAxisLineProperty(scaleOptions, 'color', 'borderColor', '__diviboosterOriginalAxisLineColor', adapter);
    }

    function restoreAxisLineWidth(scaleOptions, adapter) {
        restoreAxisLineProperty(scaleOptions, 'width', 'borderWidth', '__diviboosterOriginalAxisLineWidth', adapter);
    }

    function restoreAxisLineProperty(scaleOptions, borderProperty, gridProperty, marker, adapter) {
        if (!scaleOptions || typeof scaleOptions !== 'object' || !scaleOptions[marker]) {
            return;
        }

        adapter = adapter || getScaleConfigAdapter(scaleOptions);

        var original = scaleOptions[marker];

        if (adapter.usesModernAxisBorder) {
            if (original.borderExists) {
                if (!scaleOptions.border || typeof scaleOptions.border !== 'object') {
                    scaleOptions.border = {};
                }

                if (original.borderValueExists) {
                    scaleOptions.border[borderProperty] = original.borderValue;
                } else {
                    delete scaleOptions.border[borderProperty];
                }
            } else if (scaleOptions.border) {
                delete scaleOptions.border[borderProperty];

                if (!Object.keys(scaleOptions.border).length) {
                    delete scaleOptions.border;
                }
            }
        }

        if (adapter.usesLegacyAxisBorder) {
            if (original.gridExists) {
                if (!scaleOptions.grid || typeof scaleOptions.grid !== 'object') {
                    scaleOptions.grid = {};
                }

                if (original.gridValueExists) {
                    scaleOptions.grid[gridProperty] = original.gridValue;
                } else {
                    delete scaleOptions.grid[gridProperty];
                }
            } else if (scaleOptions.grid) {
                delete scaleOptions.grid[gridProperty];

                if (!Object.keys(scaleOptions.grid).length) {
                    delete scaleOptions.grid;
                }
            }
        }
    }

    function rememberOriginalGridLineWidth(scaleOptions) {
        if (!scaleOptions || typeof scaleOptions !== 'object' || scaleOptions.__diviboosterOriginalGridLineWidth) {
            return;
        }

        var original = {
            gridExists: !!scaleOptions.grid,
            gridLineWidthExists: !!(scaleOptions.grid && Object.prototype.hasOwnProperty.call(scaleOptions.grid, 'lineWidth')),
            gridLineWidth: scaleOptions.grid && Object.prototype.hasOwnProperty.call(scaleOptions.grid, 'lineWidth') ? scaleOptions.grid.lineWidth : undefined,
            gridLinesExists: !!scaleOptions.gridLines,
            gridLinesLineWidthExists: !!(scaleOptions.gridLines && Object.prototype.hasOwnProperty.call(scaleOptions.gridLines, 'lineWidth')),
            gridLinesLineWidth: scaleOptions.gridLines && Object.prototype.hasOwnProperty.call(scaleOptions.gridLines, 'lineWidth') ? scaleOptions.gridLines.lineWidth : undefined
        };

        try {
            Object.defineProperty(scaleOptions, '__diviboosterOriginalGridLineWidth', {
                value: original,
                enumerable: false,
                configurable: true
            });
        } catch (e) {
            scaleOptions.__diviboosterOriginalGridLineWidth = original;
        }
    }

    function restoreGridLineWidth(scaleOptions, adapter) {
        if (!scaleOptions || typeof scaleOptions !== 'object' || !scaleOptions.__diviboosterOriginalGridLineWidth) {
            return;
        }

        adapter = adapter || getScaleConfigAdapter(scaleOptions);

        var original = scaleOptions.__diviboosterOriginalGridLineWidth;

        if (adapter.usesModernGrid) {
            if (original.gridExists) {
                if (!scaleOptions.grid || typeof scaleOptions.grid !== 'object') {
                    scaleOptions.grid = {};
                }

                if (original.gridLineWidthExists) {
                    scaleOptions.grid.lineWidth = original.gridLineWidth;
                } else {
                    delete scaleOptions.grid.lineWidth;
                }
            } else if (scaleOptions.grid) {
                delete scaleOptions.grid.lineWidth;

                if (!Object.keys(scaleOptions.grid).length) {
                    delete scaleOptions.grid;
                }
            }
        }

        if (adapter.usesLegacyGridLines) {
            if (original.gridLinesExists) {
                if (!scaleOptions.gridLines || typeof scaleOptions.gridLines !== 'object') {
                    scaleOptions.gridLines = {};
                }

                if (original.gridLinesLineWidthExists) {
                    scaleOptions.gridLines.lineWidth = original.gridLinesLineWidth;
                } else {
                    delete scaleOptions.gridLines.lineWidth;
                }
            } else if (scaleOptions.gridLines) {
                delete scaleOptions.gridLines.lineWidth;

                if (!Object.keys(scaleOptions.gridLines).length) {
                    delete scaleOptions.gridLines;
                }
            }
        }
    }

    function rememberOriginalGridColor(scaleOptions) {
        if (!scaleOptions || typeof scaleOptions !== 'object' || scaleOptions.__diviboosterOriginalGridColor) {
            return;
        }

        var original = {
            gridExists: !!scaleOptions.grid,
            gridColorExists: !!(scaleOptions.grid && Object.prototype.hasOwnProperty.call(scaleOptions.grid, 'color')),
            gridColor: scaleOptions.grid && Object.prototype.hasOwnProperty.call(scaleOptions.grid, 'color') ? scaleOptions.grid.color : undefined,
            gridLinesExists: !!scaleOptions.gridLines,
            gridLinesColorExists: !!(scaleOptions.gridLines && Object.prototype.hasOwnProperty.call(scaleOptions.gridLines, 'color')),
            gridLinesColor: scaleOptions.gridLines && Object.prototype.hasOwnProperty.call(scaleOptions.gridLines, 'color') ? scaleOptions.gridLines.color : undefined
        };

        try {
            Object.defineProperty(scaleOptions, '__diviboosterOriginalGridColor', {
                value: original,
                enumerable: false,
                configurable: true
            });
        } catch (e) {
            scaleOptions.__diviboosterOriginalGridColor = original;
        }
    }

    function restoreGridColor(scaleOptions, adapter) {
        if (!scaleOptions || typeof scaleOptions !== 'object' || !scaleOptions.__diviboosterOriginalGridColor) {
            return;
        }

        adapter = adapter || getScaleConfigAdapter(scaleOptions);

        var original = scaleOptions.__diviboosterOriginalGridColor;

        if (adapter.usesModernGrid) {
            if (original.gridExists) {
                if (!scaleOptions.grid || typeof scaleOptions.grid !== 'object') {
                    scaleOptions.grid = {};
                }

                if (original.gridColorExists) {
                    scaleOptions.grid.color = original.gridColor;
                } else if (scaleOptions.grid) {
                    delete scaleOptions.grid.color;
                }
            } else {
                delete scaleOptions.grid;
            }
        }

        if (adapter.usesLegacyGridLines) {
            if (original.gridLinesExists) {
                if (!scaleOptions.gridLines || typeof scaleOptions.gridLines !== 'object') {
                    scaleOptions.gridLines = {};
                }

                if (original.gridLinesColorExists) {
                    scaleOptions.gridLines.color = original.gridLinesColor;
                } else if (scaleOptions.gridLines) {
                    delete scaleOptions.gridLines.color;
                }
            } else {
                delete scaleOptions.gridLines;
            }
        }
    }

    function restoreAllGridColors(chart) {
        if (!chart) {
            return;
        }

        var options = (chart.config && chart.config.options) || chart.options || {};

        restoreAllGridColorsFromOptions(options);
    }

    function restoreAllGridColorsFromOptions(options) {
        if (!options || typeof options !== 'object') {
            return;
        }

        var adapter = getChartConfigAdapter(options);

        if (options.scales && typeof options.scales === 'object') {
            Object.keys(options.scales).forEach(function(key) {
                var value = options.scales[key];

                if (Array.isArray(value)) {
                    value.forEach(function(scaleOptions) {
                        restoreGridColor(scaleOptions, adapter);
                        restoreGridLineWidth(scaleOptions, adapter);
                        restoreAxisLineColor(scaleOptions, adapter);
                        restoreAxisLineWidth(scaleOptions, adapter);
                    });
                } else {
                    restoreGridColor(value, adapter);
                    restoreGridLineWidth(value, adapter);
                    restoreAxisLineColor(value, adapter);
                    restoreAxisLineWidth(value, adapter);

                    if (value && value.__diviboosterCreatedGridScale) {
                        delete options.scales[key];
                    }
                }
            });
        }

        if (options.scale && typeof options.scale === 'object') {
            restoreGridColor(options.scale, adapter);
            restoreGridLineWidth(options.scale, adapter);
            restoreAxisLineColor(options.scale, adapter);
            restoreAxisLineWidth(options.scale, adapter);
        }
    }

    function findChartInstances(moduleElement) {
        var instances = [];
        var seen = [];
        var instanceProperties = ['__chartsInstance', '__chartInstance', '__chart'];
        var canvasProperties = ['chart', '__chart', '__chartist'];

        addChartCandidatesFromProperties(instances, seen, moduleElement, instanceProperties);

        var descendants = moduleElement.querySelectorAll('*');

        for (var i = 0; i < descendants.length; i++) {
            addChartCandidatesFromProperties(instances, seen, descendants[i], instanceProperties);
        }

        var canvases = moduleElement.querySelectorAll('canvas');

        for (var j = 0; j < canvases.length; j++) {
            if (window.Chart && typeof window.Chart.getChart === 'function') {
                addChartCandidate(instances, seen, window.Chart.getChart(canvases[j]));
            }

            addChartCandidatesFromProperties(instances, seen, canvases[j], canvasProperties);
        }

        addChartCandidate(instances, seen, findChartInDiviModuleCharts(moduleElement));

        return instances;
    }

    function addChartCandidatesFromProperties(instances, seen, object, properties) {
        if (!object) {
            return;
        }

        properties.forEach(function(property) {
            addChartCandidate(instances, seen, object[property]);
        });
    }

    function findChartInDiviModuleCharts(moduleElement) {
        if (!window.diviModuleCharts || typeof window.diviModuleCharts !== 'object') {
            return null;
        }

        var canvases = moduleElement.querySelectorAll('canvas');
        var canvasIds = [];

        for (var i = 0; i < canvases.length; i++) {
            if (canvases[i].id) {
                canvasIds.push(canvases[i].id);
            }
        }

        return searchObjectForCharts(window.diviModuleCharts, canvases, canvasIds, 0);
    }

    function searchObjectForCharts(obj, canvases, canvasIds, depth) {
        if (!obj || typeof obj !== 'object' || depth > 4) {
            return null;
        }

        if (isChartInstance(obj) && chartBelongsToCanvases(obj, canvases, canvasIds)) {
            return obj;
        }

        var matches = [];

        Object.keys(obj).forEach(function(key) {
            var value = obj[key];

            if (isChartInstance(value) && chartBelongsToCanvases(value, canvases, canvasIds)) {
                matches.push(value);
            } else if (value && typeof value === 'object') {
                addChartCandidate(matches, [], searchObjectForCharts(value, canvases, canvasIds, depth + 1));
            }
        });

        return matches.length ? matches : null;
    }

    function chartBelongsToCanvases(chart, canvases, canvasIds) {
        var canvas = chart.canvas || (chart.ctx && chart.ctx.canvas) || null;

        if (!canvas) {
            return false;
        }

        for (var i = 0; i < canvases.length; i++) {
            if (canvas === canvases[i]) {
                return true;
            }
        }

        return canvas.id && canvasIds.indexOf(canvas.id) !== -1;
    }

    function addChartCandidate(instances, seen, candidate) {
        if (!candidate) {
            return;
        }

        if (Array.isArray(candidate)) {
            candidate.forEach(function(item) {
                addChartCandidate(instances, seen, item);
            });
            return;
        }

        if (isChartInstance(candidate)) {
            if (seen.indexOf(candidate) === -1) {
                instances.push(candidate);
                seen.push(candidate);
            }
            return;
        }

        if (candidate.chart) {
            addChartCandidate(instances, seen, candidate.chart);
        }

        if (candidate.instance) {
            addChartCandidate(instances, seen, candidate.instance);
        }

        if (candidate.chartInstance) {
            addChartCandidate(instances, seen, candidate.chartInstance);
        }
    }

    function isChartInstance(candidate) {
        return !!(candidate && typeof candidate === 'object' && candidate.config && candidate.options && typeof candidate.update === 'function');
    }

    function stableStringify(value) {
        try {
            return JSON.stringify(value || {});
        } catch (e) {
            return String(Date.now());
        }
    }

    function scheduleRetry() {
        if (builderMode) {
            window.setInterval(applyAll, 500);
            return;
        }

        var interval = window.setInterval(function() {
            retryCount++;

            if (applyAll() || retryCount >= maxRetries) {
                window.clearInterval(interval);
            }
        }, 100);
    }

    function bindResizeHandler() {
        window.addEventListener('resize', function() {
            window.clearTimeout(resizeTimer);
            window.clearTimeout(resizeFollowupTimer);
            resizeTimer = window.setTimeout(function() {
                // Divi can replace the chart during its responsive redraw.
                applyAll(true);
                scheduleResizeReapply();
            }, 150);
        });
    }

    function scheduleResizeReapply() {
        var attempts = 0;
        var maxAttempts = 15;

        function reapply() {
            attempts++;
            applyAll();

            if (attempts < maxAttempts) {
                resizeFollowupTimer = window.setTimeout(reapply, 100);
            } else {
                resizeFollowupTimer = null;
            }
        }

        reapply();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            applyAll();
            scheduleRetry();
            bindResizeHandler();
        });
    } else {
        applyAll();
        scheduleRetry();
        bindResizeHandler();
    }
})();
JS;
}

// === Shared runtime helpers ===

function is_visual_builder() {
    if (!function_exists('et_builder_d5_enabled') || !function_exists('et_core_is_fb_enabled')) {
        return false;
    }

    try {
        return \et_builder_d5_enabled() && \et_core_is_fb_enabled();
    } catch (\Throwable $exception) {
        return false;
    }
}

function get_runtime_asset_url($builder_mode) {
    if (!function_exists('add_query_arg') || !function_exists('admin_url')) {
        return '';
    }

    $admin_ajax_url = admin_url('admin-ajax.php');

    if (!is_string($admin_ajax_url) || '' === $admin_ajax_url) {
        return '';
    }

    $runtime_asset_url = add_query_arg(
        array(
            'action'  => RUNTIME_ACTION,
            'builder' => $builder_mode ? '1' : '0',
        ),
        $admin_ajax_url
    );

    return is_string($runtime_asset_url) ? $runtime_asset_url : '';
}

function get_runtime_asset_version() {
    $version = filemtime(__FILE__);

    return false === $version ? '1' : (string) $version;
}

function chart_type_has_grid_lines($type) {
    return is_cartesian_grid_chart_type($type) || is_radial_grid_chart_type($type);
}

function is_cartesian_grid_chart_type($type) {
    return in_array(normalize_chart_type($type), get_cartesian_grid_chart_types(), true);
}

function is_radial_grid_chart_type($type) {
    return in_array(normalize_chart_type($type), get_radial_grid_chart_types(), true);
}

function normalize_chart_type($type) {
    $type = is_scalar($type) ? (string) $type : 'line';
    $type = strtolower($type);

    return preg_replace('/[_\s-]+/', '', $type);
}

function get_cartesian_grid_chart_types() {
    return array('line', 'area', 'bar', 'scatter', 'bubble');
}

function get_radial_grid_chart_types() {
    return array('radar', 'polararea');
}

function get_no_grid_chart_types() {
    return array('pie', 'doughnut', 'donut');
}

function get_array_path($array, $path) {
    if (!is_array($array) || !is_array($path)) {
        return null;
    }

    $current = $array;

    foreach ($path as $key) {
        if ((!is_int($key) && !is_string($key)) || !is_array($current) || !array_key_exists($key, $current)) {
            return null;
        }

        $current = $current[$key];
    }

    return $current;
}

function get_chart_module_slugs() {
    return array('divi/charts', 'divi/chart', 'et_pb_charts');
}

