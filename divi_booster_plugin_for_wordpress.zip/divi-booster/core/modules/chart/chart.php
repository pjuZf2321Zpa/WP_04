<?php

namespace DiviBooster\DiviBooster\Modules\Chart;

if (!is_plugin_active('chart-module-axis-label-font-styles/chart-module-axis-label-font-styles.php')) {
    include_once(dirname(__FILE__) . '/features/chart-axis-label-font-styles/chart-axis-label-font-styles.php');
}

if (!is_plugin_active('chart-module-grid-colors/chart-module-grid-colors.php')) {
    include_once(dirname(__FILE__) . '/features/chart-grid-colors/chart-grid-colors.php');
}