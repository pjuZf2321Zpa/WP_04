<?php

namespace DiviBooster\DiviBooster\Modules\Blog;

include_once(dirname(__FILE__) . '/features/author-filter/author-filter.php');
include_once(dirname(__FILE__) . '/features/pagination-link-text/pagination-link-text.php');
include_once(dirname(__FILE__) . '/features/tags/tags.php');
