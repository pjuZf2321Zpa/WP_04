<?php

namespace DiviBooster\DiviBooster\Modules\AccordionItem;

include_once(dirname(__FILE__) . '/features/css-id/css-id.php');