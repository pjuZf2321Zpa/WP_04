<?php 

namespace DiviBooster\DiviBooster\Modules;

if (!function_exists(__NAMESPACE__ . '\\load_wordpress_plugin_helpers')) {
    function load_wordpress_plugin_helpers() {
        if (function_exists('is_plugin_active')) {
            return;
        }

        if (defined('ABSPATH')) {
            $plugin_php = ABSPATH . 'wp-admin/includes/plugin.php';

            if (is_readable($plugin_php)) {
                include_once $plugin_php;
            }
        }
    }
}

load_wordpress_plugin_helpers();

if (version_compare(PHP_VERSION, '7.0.0', '>=')) {
    include_once(dirname(__FILE__) . '/all/all.php');
    include_once(dirname(__FILE__) . '/accordion/accordion.php');
    include_once(dirname(__FILE__) . '/accordion-item/accordion-item.php');
    include_once(dirname(__FILE__) . '/blog/blog.php');
    include_once(dirname(__FILE__) . '/chart/chart.php');
    include_once(dirname(__FILE__) . '/circle-counter/circle-counter.php');
    include_once(dirname(__FILE__) . '/contact-form/contact-form.php');
    include_once(dirname(__FILE__) . '/countdown-timer/countdown-timer.php');
    include_once(dirname(__FILE__) . '/login/login.php');
    include_once(dirname(__FILE__) . '/menu/menu.php');
    include_once(dirname(__FILE__) . '/email-optin/email-optin.php');
    include_once(dirname(__FILE__) . '/filterable-portfolio/filterable-portfolio.php');
    include_once(dirname(__FILE__) . '/map-pin/map-pin.php');
    include_once(dirname(__FILE__) . '/number-counter/number-counter.php');
    include_once(dirname(__FILE__) . '/person/person.php');
    include_once(dirname(__FILE__) . '/portfolio/portfolio.php');
    include_once(dirname(__FILE__) . '/post-title/post-title.php');
    include_once(dirname(__FILE__) . '/slider/slider.php');
    include_once(dirname(__FILE__) . '/slide/slide.php');
    include_once(dirname(__FILE__) . '/social-media/social-media.php');
    include_once(dirname(__FILE__) . '/timeline/timeline.php');
    include_once(dirname(__FILE__) . '/video/video.php');
    include_once(dirname(__FILE__) . '/tabs/tabs.php');

}
