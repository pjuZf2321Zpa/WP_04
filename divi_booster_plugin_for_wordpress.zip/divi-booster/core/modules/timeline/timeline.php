<?php

namespace DiviBooster\DiviBooster\Modules\Timeline;

include_once(dirname(__FILE__) . '/features/scroll-state-colors/scroll-state-colors.php');
include_once(dirname(__FILE__) . '/features/horizontal-carousel/horizontal-carousel.php');
include_once(dirname(__FILE__) . '/features/marker-numbers/marker-numbers.php');
include_once(dirname(__FILE__) . '/features/marker-text/marker-text.php');
