<?php

namespace DiviBooster\DiviBooster\Modules\Timeline\MarkerText;

if (!defined('ABSPATH')) {
    exit();
}

// === Bootstrap ===

const TIMELINE_SLUG = 'divi/timeline';
const TIMELINE_ITEM_SLUG = 'divi/timeline-item';
const TEXT_ATTR_NAME = 'dbTimelineMarkerText';
const PARENT_FONT_ATTR_NAME = 'dbTimelineMarkerTextFont';
const ITEM_FONT_ATTR_NAME = 'dbTimelineItemMarkerTextFont';
const MARKER_TEXT_CLASS = 'dbtl-marker-text';
const MARKER_TEXT_ITEM_CLASS = 'dbtl-marker-text-item';
const MARKER_HAS_CUSTOM_CONTENT_CLASS = 'dbtl-marker-has-custom-content';
const TIMELINE_ITEM_CLASS = 'et_pb_timeline_item';
const TIMELINE_MARKER_CLASS = 'et_pb_timeline_marker';
const MARKER_LAYOUT_DECLARATION = 'align-items:center;display:flex;gap:0.25em;justify-content:center;';
const MARKER_TEXT_DEFAULT_DECLARATION = 'color:#fff;display:inline-block;font-size:14px;font-weight:700;line-height:1;pointer-events:none;';
const HIDE_MARKER_NUMBER_DECLARATION = 'content:none!important;';

if (function_exists('add_action')) {
    add_action('divi_visual_builder_assets_before_enqueue_scripts', __NAMESPACE__ . '\\enqueue_builder_fields');
}

if (function_exists('add_filter')) {
    add_filter('block_type_metadata_settings', __NAMESPACE__ . '\\register_block_attrs');
    add_filter('render_block_' . TIMELINE_ITEM_SLUG, __NAMESPACE__ . '\\filter_timeline_item_output', 18, 3);
    add_filter('divi_module_wrapper_render', __NAMESPACE__ . '\\add_marker_text_styles', 10, 2);
}

// Detect whether Divi 5 code paths are available.
function is_divi5_active()
{
    if (!function_exists('et_builder_d5_enabled')) {
        return false;
    }

    try {
        return (bool) \et_builder_d5_enabled();
    } catch (\Throwable $e) {
        return false;
    }
}

// Detect whether the current request is for the Visual Builder.
function is_divi5_visual_builder()
{
    if (!is_divi5_active() || !function_exists('et_core_is_fb_enabled')) {
        return false;
    }

    try {
        return (bool) \et_core_is_fb_enabled();
    } catch (\Throwable $e) {
        return false;
    }
}

// === Builder settings and preview integration ===

// Enqueue the builder-only field registration and preview script.
function enqueue_builder_fields()
{
    if (!is_divi5_visual_builder() || !function_exists('sanitize_title') || !function_exists('dbdb_enqueue_inline_script_if_dependencies_available')) {
        return;
    }

    try {
        $handle = sanitize_title('divi-booster-' . TIMELINE_ITEM_SLUG . '-marker-text');
        $inline_js = get_builder_inline_js();
        if ($inline_js === '') {
            return;
        }

        \dbdb_enqueue_inline_script_if_dependencies_available($handle, $inline_js, array('lodash', array('divi-vendor-wp-hooks', 'wp-hooks')));
    } catch (\Throwable $e) {
        return;
    }
}

// Build the script that registers marker text controls and keeps builder previews in sync.
function get_builder_inline_js()
{
    if (!function_exists('wp_json_encode')) {
        return '';
    }

    $timeline_attrs = wp_json_encode(get_timeline_attribute_definitions());
    $item_attrs = wp_json_encode(get_timeline_item_attribute_definitions());
    $marker_group_label = wp_json_encode(translate_ui_text('Marker'));

    if (!is_string($timeline_attrs) || !is_string($item_attrs) || !is_string($marker_group_label)) {
        return '';
    }

    return <<<JS
(function() {
    if (!window.vendor || !window.vendor.wp || !window.vendor.wp.hooks || typeof window.vendor.wp.hooks.addFilter !== 'function' || typeof Object.assign !== 'function') {
        return;
    }

    var hooks = window.vendor.wp.hooks;
    var WPElement = window.vendor.wp.element;
    var React = (window.vendor && window.vendor.React) || WPElement;
    var timelineAttrs = {$timeline_attrs};
    var itemAttrs = {$item_attrs};
    var markerGroupLabel = {$marker_group_label};
    var markerTextGroupSlug = 'designMarker';

    function addMarkerTextGroup(groups, metadata) {
        var moduleName = metadata && metadata.name;

        if (moduleName && moduleName !== 'divi/timeline' && moduleName !== 'divi/timeline-item') {
            return groups;
        }

        groups = groups || {};
        groups[markerTextGroupSlug] = Object.assign({}, groups[markerTextGroupSlug] || {}, {
            groupName: markerTextGroupSlug,
            panel: 'design',
            priority: 63,
            component: Object.assign({}, (groups[markerTextGroupSlug] && groups[markerTextGroupSlug].component) || {}, {
                name: 'divi/composite',
                props: Object.assign({}, (groups[markerTextGroupSlug] && groups[markerTextGroupSlug].component && groups[markerTextGroupSlug].component.props) || {}, {
                    groupLabel: markerGroupLabel
                })
            })
        });

        return groups;
    }

    hooks.addFilter('divi.moduleLibrary.moduleAttributes.divi.timeline', 'divibooster.timelineMarkerText', function(attributes) {
        attributes = attributes || {};
        Object.keys(timelineAttrs).forEach(function(name) {
            attributes[name] = timelineAttrs[name];
        });
        return attributes;
    });

    hooks.addFilter('divi.moduleLibrary.moduleAttributes.divi.timeline-item', 'divibooster.timelineMarkerText', function(attributes) {
        attributes = attributes || {};
        Object.keys(itemAttrs).forEach(function(name) {
            attributes[name] = itemAttrs[name];
        });
        applyChildMarkerTextFontVisibilityCallback(attributes);
        return attributes;
    });

    function applyChildMarkerTextFontVisibilityCallback(attributes) {
        var fontItem = getPath(attributes, ['dbTimelineItemMarkerTextFont', 'settings', 'decoration', 'font', 'item']);
        var visible = function(ctx) {
            return getMarkerText(contextAttrs(ctx)) !== '';
        };

        if (!fontItem) {
            return;
        }

        fontItem.visible = visible;
        fontItem.component = fontItem.component || {};
        fontItem.component.props = fontItem.component.props || {};
        fontItem.component.props.visible = visible;
    }

    function contextAttrs(ctx) {
        return (ctx && ctx.attrs) || ctx || {};
    }

    hooks.addFilter('divi.moduleLibrary.moduleSettings.groups', 'divibooster.timelineMarkerText', addMarkerTextGroup);
    hooks.addFilter('divi.moduleLibrary.moduleSettings.groups.divi.timeline', 'divibooster.timelineMarkerText', function(groups, metadata) {
        return addMarkerTextGroup(groups, Object.assign({}, metadata || {}, { name: 'divi/timeline' }));
    });
    hooks.addFilter('divi.moduleLibrary.moduleSettings.groups.divi.timeline-item', 'divibooster.timelineMarkerText', function(groups, metadata) {
        return addMarkerTextGroup(groups, Object.assign({}, metadata || {}, { name: 'divi/timeline-item' }));
    });

    hooks.addFilter('divi.module.wrapper.render', 'divibooster.timelineMarkerText', function(moduleWrapper, param) {
        try {
            if (!param || (param.name !== 'divi/timeline' && param.name !== 'divi/timeline-item')) {
                return moduleWrapper;
            }

            if (!React || !WPElement || typeof React.useEffect !== 'function' || typeof React.useRef !== 'function' || typeof WPElement.createElement !== 'function' || typeof WPElement.cloneElement !== 'function') {
                return moduleWrapper;
            }

            if (param.name === 'divi/timeline') {
                var timelineOrderClass = getPreviewTimelineOrderClass(param);

                return appendPreviewChild(moduleWrapper, WPElement.createElement(TimelineMarkerTextStyleInjector, {
                    key: 'divibooster-timeline-marker-text-parent-preview',
                    styleId: 'divibooster-timeline-marker-text-parent-preview-' + safeId(timelineOrderClass || 'timeline'),
                    css: buildTimelinePreviewCss(param.attrs || {}, timelineOrderClass)
                }), WPElement);
            }

            var previewAttrs = toPlainObject(param.attrs || {});
            var hasTextAttr = hasOwnAttr(previewAttrs, 'dbTimelineMarkerText');
            var hasFontAttr = hasOwnAttr(previewAttrs, 'dbTimelineItemMarkerTextFont');
            var text = hasTextAttr ? getMarkerText(previewAttrs) : '';
            var orderClass = getPreviewOrderClass(param);
            var css = (hasTextAttr || hasFontAttr) ? buildPreviewCss(previewAttrs, orderClass) : '';
            var injectorEl = WPElement.createElement(TimelineMarkerTextPreviewInjector, {
                key: 'divibooster-timeline-marker-text-preview',
                orderClass: orderClass,
                css: css,
                text: text,
                hasTextAttr: hasTextAttr,
                hasFontAttr: hasFontAttr
            });

            return appendPreviewChild(moduleWrapper, injectorEl, WPElement);
        } catch (e) {
            return moduleWrapper;
        }
    });

    function TimelineMarkerTextStyleInjector(props) {
        var ref = React.useRef(null);

        React.useEffect(function() {
            var doc = ref.current && ref.current.ownerDocument ? ref.current.ownerDocument : document;

            syncPreviewStyleElement(doc, props.styleId || '', props.css || '');

            return function() {
                syncPreviewStyleElement(doc, props.styleId || '', '');
            };
        }, [props.styleId, props.css]);

        return WPElement.createElement('span', {
            ref: ref,
            'aria-hidden': true,
            style: { display: 'none' }
        });
    }

    function TimelineMarkerTextPreviewInjector(props) {
        var ref = React.useRef(null);

        React.useEffect(function() {
            var marker = findTimelineMarker(ref.current);
            if (!marker) {
                return;
            }

            if (props.hasTextAttr) {
                syncPreviewMarkerText(marker, props.text || '');
            }
            if (props.hasTextAttr || props.hasFontAttr) {
                syncPreviewStyles(marker, props.orderClass || '', props.css || '');
            }
        }, [props.orderClass, props.css, props.text, props.hasTextAttr, props.hasFontAttr]);

        return WPElement.createElement('span', {
            ref: ref,
            'aria-hidden': true,
            style: { display: 'none' }
        });
    }

    function syncPreviewMarkerText(marker, text) {
        var item = marker.closest ? marker.closest('.et_pb_timeline_item') : null;
        var textEl = marker.querySelector('.dbtl-marker-text');

        if (!text) {
            if (textEl && textEl.parentNode) {
                textEl.parentNode.removeChild(textEl);
            }
            if (item && item.classList) {
                item.classList.remove('dbtl-marker-has-custom-content');
                item.classList.remove('dbtl-marker-text-item');
            }
            return;
        }

        if (!textEl) {
            textEl = marker.ownerDocument.createElement('span');
            textEl.className = 'dbtl-marker-text';
            marker.appendChild(textEl);
        }

        textEl.textContent = text;
        if (item && item.classList) {
            item.classList.add('dbtl-marker-has-custom-content');
            item.classList.add('dbtl-marker-text-item');
        }
    }

    function syncPreviewStyles(marker, orderClass, css) {
        var doc = marker && marker.ownerDocument ? marker.ownerDocument : document;
        var styleId = orderClass ? 'divibooster-timeline-marker-text-preview-' + safeId(orderClass) : '';

        syncPreviewStyleElement(doc, styleId, css);
    }

    function syncPreviewStyleElement(doc, styleId, css) {
        if (!doc || !styleId) {
            return;
        }

        var styleEl = doc.getElementById(styleId);

        if (!css) {
            if (styleEl && styleEl.parentNode) {
                styleEl.parentNode.removeChild(styleEl);
            }
            return;
        }

        if (!styleEl) {
            styleEl = doc.createElement('style');
            styleEl.id = styleId;
            (doc.head || doc.body || doc.documentElement).appendChild(styleEl);
        }

        styleEl.textContent = css;
    }

    function findTimelineMarker(anchor) {
        var node = anchor && anchor.parentElement;

        while (node && node !== document.documentElement) {
            if (node.classList && node.classList.contains('et_pb_timeline_item')) {
                return node.querySelector('.et_pb_timeline_marker');
            }
            node = node.parentElement;
        }

        return null;
    }

    function buildPreviewCss(attrs, orderClass) {
        var selector = normalizeOrderSelector(orderClass);
        var fontCss;

        if (!selector) {
            return '';
        }

        attrs = toPlainObject(attrs);
        fontCss = getFontCssFromAttrs(attrs, 'desktop', 'dbTimelineItemMarkerTextFont');

        return ':where(.et_pb_timeline ' + selector + ' .et_pb_timeline_marker){align-items:center;display:flex;gap:0.25em;justify-content:center;}' +
            ':where(.et_pb_timeline ' + selector + ' .dbtl-marker-text){color:#fff;display:inline-block;font-size:14px;font-weight:700;line-height:1;pointer-events:none;}' +
            (fontCss ? '.et_pb_timeline ' + selector + selector + ' .dbtl-marker-text{' + fontCss + '}' : '') +
            '.et_pb_timeline.dbtl-marker-numbers ' + selector + '.dbtl-marker-text-item .et_pb_timeline_marker::before{content:none!important;}';
    }

    function buildTimelinePreviewCss(attrs, orderClass) {
        var selector = normalizeOrderSelector(orderClass);
        var fontCss;

        if (!selector) {
            return '';
        }

        attrs = toPlainObject(attrs);
        fontCss = getFontCssFromAttrs(attrs, 'desktop', 'dbTimelineMarkerTextFont');

        return fontCss ? '.et_pb_timeline' + selector + ' .dbtl-marker-text{' + fontCss + '}' : '';
    }

    function getFontCssFromAttrs(attrs, breakpoint, fontAttrName) {
        var fontValue = getFontValue(attrs, breakpoint, fontAttrName);
        var css = '';
        var color = sanitizeCssColor(getFirstFontScalar(fontValue, ['color']));
        var size = sanitizeCssLength(getFirstFontScalar(fontValue, ['size', 'fontSize']), '');
        var weight = getFirstFontScalar(fontValue, ['weight', 'fontWeight']);
        var family = getFirstFontScalar(fontValue, ['family', 'fontFamily']);
        var style = getFirstFontScalar(fontValue, ['style', 'fontStyle']);
        var textDecorationLine = getTextDecorationLineFromFontStyle(style);
        var letterSpacing = sanitizeCssLength(getFirstFontScalar(fontValue, ['letterSpacing']), '');
        var textShadow = sanitizeCssTextShadow(getTextShadowValue(attrs, breakpoint, fontAttrName));

        if (color) {
            css += 'color:' + color + ';';
        }
        if (size) {
            css += 'font-size:' + size + ';';
        }
        if (/^(normal|bold|[1-9]00)$/.test(String(weight).trim())) {
            css += 'font-weight:' + String(weight).trim() + ';';
        }
        if (typeof family === 'string' && family.trim() && family.indexOf('|') === -1 && family.indexOf('\$variable(') !== 0) {
            css += 'font-family:"' + cssString(family.trim()) + '";';
        }
        if (typeof style === 'string' && /\bitalic\b/i.test(style)) {
            css += 'font-style:italic;';
        }
        if (textDecorationLine) {
            css += 'text-decoration-line:' + textDecorationLine + ';';
        }
        if (letterSpacing) {
            css += 'letter-spacing:' + letterSpacing + ';';
        }
        if (textShadow) {
            css += 'text-shadow:' + textShadow + ';';
        }

        return css;
    }

    function getFontValue(attrs, breakpoint, fontAttrName) {
        var paths = [
            [fontAttrName, 'decoration', 'font', 'font', breakpoint, 'value'],
            [fontAttrName, 'decoration', 'font', 'font', 'desktop', 'value'],
            [fontAttrName, 'decoration', 'font', breakpoint, 'value'],
            [fontAttrName, 'decoration', 'font', 'desktop', 'value'],
            [fontAttrName, 'font', breakpoint, 'value'],
            [fontAttrName, 'font', 'desktop', 'value']
        ];
        var value;
        var i;

        for (i = 0; i < paths.length; i++) {
            value = getPath(attrs, paths[i]);
            if (value && typeof value === 'object') {
                return value;
            }
        }

        value = getPath(attrs, [fontAttrName, 'decoration', 'font']);
        return value && typeof value === 'object' ? value : {};
    }

    function getTextShadowValue(attrs, breakpoint, fontAttrName) {
        var paths = [
            [fontAttrName, 'decoration', 'font', 'textShadow', breakpoint, 'value'],
            [fontAttrName, 'decoration', 'font', 'textShadow', breakpoint],
            [fontAttrName, 'decoration', 'font', 'textShadow', 'desktop', 'value'],
            [fontAttrName, 'decoration', 'font', 'textShadow', 'desktop'],
            [fontAttrName, 'decoration', 'font', 'textShadow', 'value'],
            [fontAttrName, 'decoration', 'font', 'textShadow'],
            [fontAttrName, 'textShadow', breakpoint, 'value'],
            [fontAttrName, 'textShadow', breakpoint],
            [fontAttrName, 'textShadow', 'desktop', 'value']
        ];
        var value;
        var i;

        for (i = 0; i < paths.length; i++) {
            value = getPath(attrs, paths[i]);
            if (value && typeof value === 'object') {
                return buildTextShadow(value);
            }
            if (typeof value === 'string' && value.trim()) {
                return value.trim();
            }
        }

        return '';
    }

    function buildTextShadow(value) {
        var shadowStyle = value && typeof value.style === 'string' ? value.style : '';
        var horizontalRaw = getFirstFontScalar(value, ['horizontal', 'horizontalLength', 'x']);
        var verticalRaw = getFirstFontScalar(value, ['vertical', 'verticalLength', 'y']);
        var blurRaw = getFirstFontScalar(value, ['blur', 'blurStrength']);
        var color = sanitizeCssColor(getFirstFontScalar(value, ['color']));
        var hasShadowValue = !!(shadowStyle || horizontalRaw || verticalRaw || blurRaw || color);
        var horizontal = sanitizeCssLength(horizontalRaw, '0px');
        var vertical = sanitizeCssLength(verticalRaw, '0px');
        var blur = sanitizeCssLength(blurRaw, '0px');

        if (shadowStyle && shadowStyle.toLowerCase() === 'none') {
            return '';
        }
        if (!hasShadowValue) {
            return '';
        }

        return horizontal + ' ' + vertical + ' ' + blur + ' ' + (color || 'rgba(0,0,0,0.4)');
    }

    function getFirstFontScalar(value, keys) {
        var nestedValueResult;
        var i;
        var key;

        if (!value || typeof value !== 'object') {
            return '';
        }

        for (i = 0; i < keys.length; i++) {
            if (Object.prototype.hasOwnProperty.call(value, keys[i]) && value[keys[i]] !== null && value[keys[i]] !== undefined && String(value[keys[i]]).trim() !== '') {
                return String(value[keys[i]]).trim();
            }
        }

        for (key in value) {
            if (!Object.prototype.hasOwnProperty.call(value, key) || !value[key] || typeof value[key] !== 'object') {
                continue;
            }
            nestedValueResult = getFirstFontScalar(value[key], keys);
            if (nestedValueResult) {
                return nestedValueResult;
            }
        }

        return '';
    }

    function getTextDecorationLineFromFontStyle(style) {
        var lines = [];

        style = typeof style === 'string' ? style : '';
        if (/\bunderline\b/i.test(style)) {
            lines.push('underline');
        }
        if (/\b(?:strike|strikethrough|line-through)\b/i.test(style)) {
            lines.push('line-through');
        }

        return lines.join(' ');
    }

    function getPreviewOrderClass(param) {
        var candidates = [
            getPath(param, ['elements', 'orderClass']),
            getPath(param, ['elements', 'order_class']),
            param.orderClass,
            param.order_class
        ];
        var i;
        var match;
        var normalized;

        for (i = 0; i < candidates.length; i++) {
            if (typeof candidates[i] !== 'string') {
                continue;
            }

            match = candidates[i].match(/\bet_pb_timeline_item_\d+(?:_tb_[a-z]+)?\b/i);
            if (match) {
                return match[0];
            }

            normalized = candidates[i].replace(/^\./, '').trim();
            if (/^[a-z0-9_-]+$/i.test(normalized)) {
                return normalized;
            }
        }

        return '';
    }

    function getPreviewTimelineOrderClass(param) {
        var candidates = [
            getPath(param, ['elements', 'orderClass']),
            getPath(param, ['elements', 'order_class']),
            param.orderClass,
            param.order_class
        ];
        var i;
        var match;
        var normalized;

        for (i = 0; i < candidates.length; i++) {
            if (typeof candidates[i] !== 'string') {
                continue;
            }

            match = candidates[i].match(/\bet_pb_timeline_\d+(?:_tb_[a-z]+)?\b/i);
            if (match) {
                return match[0];
            }

            normalized = candidates[i].replace(/^\./, '').trim();
            if (/^[a-z0-9_-]+$/i.test(normalized)) {
                return normalized;
            }
        }

        return '';
    }

    function normalizeOrderSelector(orderClass) {
        if (typeof orderClass !== 'string') {
            return '';
        }

        orderClass = orderClass.replace(/^\./, '').trim();
        return /^[a-z0-9_-]+$/i.test(orderClass) ? '.' + orderClass : '';
    }

    function safeId(value) {
        return String(value || 'marker-text').replace(/[^a-z0-9_-]/gi, '-');
    }

    function sanitizeCssLength(value, fallback) {
        value = typeof value === 'string' || typeof value === 'number' ? String(value).trim() : '';
        if (!value || value.indexOf('\$variable(') === 0) {
            return fallback;
        }
        if (/^-?\d+(?:\.\d+)?(?:px|em|rem|%|vh|vw|vmin|vmax)?$/i.test(value)) {
            return value;
        }
        return fallback;
    }

    function sanitizeCssColor(value) {
        value = typeof value === 'string' ? value.trim() : '';
        if (!value || value.indexOf('\$variable(') === 0 || /[{};]/.test(value)) {
            return '';
        }
        if (/^(#[0-9a-f]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|[a-z]+)$/i.test(value)) {
            return value;
        }
        return '';
    }

    function sanitizeCssTextShadow(value) {
        value = typeof value === 'string' ? value.trim() : '';
        if (!value || value.indexOf('\$variable(') === 0 || /[{};]/.test(value)) {
            return '';
        }
        return value;
    }

    function cssString(value) {
        return String(value).replace(/[\\\\"'\\n\\r\\f]/g, function(match) {
            return {
                '\\\\': '\\\\\\\\',
                '"': '\\\\"',
                "'": "\\\\'",
                '\\n': '\\\\a ',
                '\\r': '\\\\d ',
                '\\f': '\\\\c '
            }[match] || '';
        });
    }

    function appendPreviewChild(moduleWrapper, child, WPElement) {
        if (!moduleWrapper || !moduleWrapper.props) {
            return moduleWrapper;
        }

        var children = moduleWrapper.props.children;
        var nextChildren = Array.isArray(children) ? children.concat([child]) : [children, child].filter(Boolean);

        return WPElement.cloneElement(moduleWrapper, {}, nextChildren);
    }

    function getMarkerText(attrs) {
        attrs = toPlainObject(attrs);

        var attr = attrs && attrs.dbTimelineMarkerText;
        var paths = [
            ['desktop', 'value'],
            ['value']
        ];
        var value;
        var i;

        for (i = 0; i < paths.length; i++) {
            value = getPath(attr, paths[i]);
            if (typeof value === 'string' || typeof value === 'number') {
                value = String(value).trim();
                if (value && value.indexOf('\$variable(') !== 0) {
                    return value;
                }
            }
        }

        return '';
    }

    function hasOwnAttr(attrs, attrName) {
        attrs = toPlainObject(attrs);
        return !!(attrs && typeof attrs === 'object' && Object.prototype.hasOwnProperty.call(attrs, attrName));
    }

    function toPlainObject(value) {
        if (!value || typeof value !== 'object') {
            return {};
        }

        try {
            return JSON.parse(JSON.stringify(value));
        } catch (e) {
            return value;
        }
    }

    function getPath(value, path) {
        var i;

        for (i = 0; i < path.length; i++) {
            if (!value || typeof value !== 'object' || !Object.prototype.hasOwnProperty.call(value, path[i])) {
                return null;
            }
            value = value[path[i]];
        }

        return value;
    }
})();
JS;
}

// === Attribute definitions ===

// Add marker text attributes to the Timeline modules that use them.
function register_block_attrs($settings)
{
    if (!is_array($settings) || !isset($settings['name'])) {
        return $settings;
    }

    $definitions = get_attribute_definitions_for_module($settings['name']);
    if (!empty($definitions)) {
        if (!isset($settings['attributes']) || !is_array($settings['attributes'])) {
            $settings['attributes'] = array();
        }
        $settings['attributes'] = array_replace($settings['attributes'], $definitions);
    }

    return $settings;
}

// Return the attribute set owned by a supported module.
function get_attribute_definitions_for_module($module_name)
{
    if ($module_name === TIMELINE_SLUG) {
        return get_timeline_attribute_definitions();
    }

    if ($module_name === TIMELINE_ITEM_SLUG) {
        return get_timeline_item_attribute_definitions();
    }

    return array();
}

// Define parent Timeline attributes.
function get_timeline_attribute_definitions()
{
    return array(
        PARENT_FONT_ATTR_NAME => get_design_marker_text_font_attribute_definition(),
    );
}

// Define child Timeline Item attributes.
function get_timeline_item_attribute_definitions()
{
    return array(
        TEXT_ATTR_NAME => get_marker_text_attribute_definition(),
        ITEM_FONT_ATTR_NAME => get_design_marker_text_font_attribute_definition(),
    );
}

// Define the content field used to enter marker text on child items.
function get_marker_text_attribute_definition()
{
    return array(
        'type' => 'object',
        'settings' => array(
            'innerContent' => array(
                'groupType' => 'group-item',
                'item' => array(
                    'groupSlug' => 'contentItemContent',
                    'priority' => 41,
                    'render' => true,
                    'attrName' => TEXT_ATTR_NAME,
                    'label' => translate_ui_text('Marker Text'),
                    'description' => translate_ui_text('Enter custom text to display inside the timeline marker.'),
                    'category' => 'basic_option',
                    'features' => array(
                        'responsive' => true,
                        'hover' => false,
                        'sticky' => false,
                        'dynamicContent' => array(
                            'type' => 'text',
                        ),
                        'preset' => 'content',
                    ),
                    'component' => array(
                        'type' => 'field',
                        'name' => 'divi/text',
                    ),
                ),
            ),
        ),
    );
}

// Define the shared Marker Text font control.
function get_design_marker_text_font_attribute_definition()
{
    return get_marker_text_font_attribute_definition(
        'designMarker',
        10,
        translate_ui_text('Marker Text'),
        translate_ui_text('Text')
    );
}

// Build a font attribute definition for the Marker settings group.
function get_marker_text_font_attribute_definition($group_slug, $priority, $group_label, $field_label)
{
    return array(
        'type' => 'object',
        'settings' => array(
            'decoration' => array(
                'font' => array(
                    'groupType' => 'group-item',
                    'item' => array(
                        'groupSlug' => $group_slug,
                        'priority' => $priority,
                        'render' => true,
                        'component' => array(
                            'name' => 'divi/font',
                            'type' => 'group',
                            'props' => array(
                                'grouped' => true,
                                'groupLabel' => $group_label,
                                'fieldLabel' => $field_label,
                                'dynamicSubgroupHost' => true,
                                'fields' => array(
                                    'textAlign' => array(
                                        'render' => false,
                                    ),
                                    'lineHeight' => array(
                                        'render' => false,
                                    ),
                                    'textEffectsGroup' => array(
                                        'render' => false,
                                    ),
                                ),
                                'defaultGroupAttr' => array(
                                    'font' => array(
                                        'desktop' => array(
                                            'value' => array(
                                                'size' => '14px',
                                                'weight' => '700',
                                                'lineHeight' => '1',
                                                'color' => '#ffffff',
                                            ),
                                        ),
                                    ),
                                ),
                            ),
                        ),
                    ),
                ),
            ),
        ),
    );
}

// === Frontend marker text output ===

// Insert marker text into rendered Timeline Item markup when text is set.
function filter_timeline_item_output($block_content, $parsed_block, $block)
{
    unset($block);

    if (!is_divi5_active() || !is_string($block_content) || $block_content === '' || !is_array($parsed_block)) {
        return $block_content;
    }

    $attrs = isset($parsed_block['attrs']) && is_array($parsed_block['attrs']) ? $parsed_block['attrs'] : array();
    $text = get_marker_text($attrs);
    if ($text === '') {
        return $block_content;
    }

    $marker_text = '<span class="' . MARKER_TEXT_CLASS . '">' . escape_html($text) . '</span>';
    $block_content = add_classes_to_first_tag_with_class(
        $block_content,
        TIMELINE_ITEM_CLASS,
        array(MARKER_HAS_CUSTOM_CONTENT_CLASS, MARKER_TEXT_ITEM_CLASS)
    );

    return append_html_to_first_tag_with_class($block_content, TIMELINE_MARKER_CLASS, $marker_text);
}

// === Generated marker text styles ===

// Register marker text styles through the module style pipeline.
function add_marker_text_styles($module_wrapper, $args)
{
    if (!is_array($args) || !is_divi5_active() || !is_callable('\\ET\\Builder\\FrontEnd\\Module\\Style::add')) {
        return maybe_et_core_esc_previously($module_wrapper);
    }

    $name = isset($args['name']) && is_string($args['name']) ? $args['name'] : '';
    if ($name !== TIMELINE_SLUG && $name !== TIMELINE_ITEM_SLUG) {
        return maybe_et_core_esc_previously($module_wrapper);
    }

    $module_elements = isset($args['elements']) ? $args['elements'] : null;
    if (!is_object($module_elements) || !is_callable(array($module_elements, 'style'))) {
        return maybe_et_core_esc_previously($module_wrapper);
    }

    $module_attrs = isset($args['attrs']) && is_array($args['attrs']) ? $args['attrs'] : array();
    $order_class = get_module_elements_order_class($module_elements);
    $order_selector = normalize_order_selector($order_class);
    if ($order_selector === '') {
        return maybe_et_core_esc_previously($module_wrapper);
    }

    $font_attr_name = $name === TIMELINE_SLUG ? PARENT_FONT_ATTR_NAME : ITEM_FONT_ATTR_NAME;
    $selector = $name === TIMELINE_SLUG ? $order_selector . ' .' . MARKER_TEXT_CLASS : '.et_pb_timeline ' . $order_selector . ' .' . MARKER_TEXT_CLASS;
    $styles = build_marker_text_styles($module_elements, $module_attrs, $font_attr_name, $selector);

    if ($name === TIMELINE_SLUG) {
        $styles[] = get_default_marker_text_style_items(
            ':where(' . $order_selector . ' .' . TIMELINE_ITEM_CLASS . '.' . MARKER_TEXT_ITEM_CLASS . ' .' . TIMELINE_MARKER_CLASS . ')',
            ':where(' . $order_selector . ' .' . TIMELINE_ITEM_CLASS . '.' . MARKER_TEXT_ITEM_CLASS . ' .' . MARKER_TEXT_CLASS . ')',
            $order_selector . '.dbtl-marker-numbers .' . TIMELINE_ITEM_CLASS . '.' . MARKER_TEXT_ITEM_CLASS . ' .' . TIMELINE_MARKER_CLASS . '::before'
        );
    }

    if ($name === TIMELINE_ITEM_SLUG && get_marker_text($module_attrs) !== '') {
        $styles[] = get_default_marker_text_style_items(
            ':where(.et_pb_timeline ' . $order_selector . ' .' . TIMELINE_MARKER_CLASS . ')',
            ':where(.et_pb_timeline ' . $order_selector . ' .' . MARKER_TEXT_CLASS . ')',
            '.et_pb_timeline.dbtl-marker-numbers ' . $order_selector . '.' . MARKER_TEXT_ITEM_CLASS . ' .' . TIMELINE_MARKER_CLASS . '::before'
        );
    }

    if (empty($styles)) {
        return maybe_et_core_esc_previously($module_wrapper);
    }

    try {
        \ET\Builder\FrontEnd\Module\Style::add(array(
            'id' => get_scalar_arg($args, 'id', ''),
            'name' => $name,
            'orderIndex' => get_scalar_arg($args, 'orderIndex', 0),
            'storeInstance' => get_scalar_arg($args, 'storeInstance', 0),
            'styles' => $styles,
        ));
    } catch (\Throwable $e) {
        return maybe_et_core_esc_previously($module_wrapper);
    }

    return maybe_et_core_esc_previously($module_wrapper);
}

// Return the baseline marker text style items for a generated selector set.
function get_default_marker_text_style_items($marker_selector, $text_selector, $hide_number_selector)
{
    return array(
        style_item(false, $marker_selector, MARKER_LAYOUT_DECLARATION),
        style_item(false, $text_selector, MARKER_TEXT_DEFAULT_DECLARATION),
        style_item(false, $hide_number_selector, HIDE_MARKER_NUMBER_DECLARATION),
    );
}

// Convert Divi font and text-shadow attributes into style manager entries.
function build_marker_text_styles($module_elements, $module_attrs, $font_attr_name, $selector)
{
    $styles = array();
    $font_attr = get_nested_array_value($module_attrs, array($font_attr_name, 'decoration', 'font'));
    if (!is_array($font_attr)) {
        return $styles;
    }

    $text_shadow_attr = get_nested_array_value($module_attrs, array($font_attr_name, 'decoration', 'font', 'textShadow'));
    if (!is_array($text_shadow_attr)) {
        $text_shadow_attr = array();
    }

    $font_style = get_module_elements_style(
        $module_elements,
        array(
            'attrName' => 'module',
            'styleProps' => array(
                'advancedStyles' => array(
                    array(
                        'componentName' => 'divi/font',
                        'props' => array(
                            'selector' => $selector,
                            'attr' => $font_attr,
                        ),
                    ),
                    array(
                        'componentName' => 'divi/text-shadow',
                        'props' => array(
                            'selector' => $selector,
                            'attr' => $text_shadow_attr,
                        ),
                    ),
                ),
            ),
        )
    );

    if (!empty($font_style)) {
        $styles[] = $font_style;
    }

    return $styles;
}

// === Attribute value helpers ===

// Extract plain marker text from the responsive attribute shape.
function get_marker_text($attrs)
{
    if (!is_array($attrs)) {
        return '';
    }

    $value = get_responsive_attr_value(isset($attrs[TEXT_ATTR_NAME]) ? $attrs[TEXT_ATTR_NAME] : null);
    if (!is_scalar($value)) {
        return '';
    }

    $value = trim((string) $value);
    if ($value === '' || strpos($value, '$variable(') === 0) {
        return '';
    }

    return $value;
}

// Resolve the first non-empty responsive attribute value.
function get_responsive_attr_value($attr, $breakpoint = 'desktop')
{
    if (!is_array($attr)) {
        return null;
    }

    $paths = array(
        array($breakpoint, 'value'),
        array('desktop', 'value'),
        array('value'),
    );

    foreach ($paths as $path) {
        $value = get_nested_array_value($attr, $path);
        if (is_scalar($value) && trim((string) $value) !== '') {
            return $value;
        }
    }

    return null;
}

// === HTML update helpers ===

// Append HTML inside the first element with the requested class.
function append_html_to_first_tag_with_class($html, $required_class, $html_to_append)
{
    if (!is_string($html) || $html === '' || !is_string($required_class) || $required_class === '' || !is_string($html_to_append) || $html_to_append === '') {
        return $html;
    }

    $pattern = '~(<([a-z0-9]+)\b[^>]*\bclass=([\"\'])(?=[^\"\']*\b' . preg_quote($required_class, '~') . '\b)[^\"\']*\3[^>]*>)(.*?)(</\2>)~is';
    $updated_html = preg_replace($pattern, '$1$4' . $html_to_append . '$5', $html, 1);

    return is_string($updated_html) ? $updated_html : $html;
}

// Add one class to the first element with the requested class.
function add_class_to_first_tag_with_class($html, $required_class, $class_to_add)
{
    return add_classes_to_first_tag_with_class($html, $required_class, array($class_to_add));
}

// Add classes to the first element with the requested class in a single pass.
function add_classes_to_first_tag_with_class($html, $required_class, $classes_to_add)
{
    if (!is_string($html) || $html === '' || !is_string($required_class) || $required_class === '') {
        return $html;
    }

    if (!is_array($classes_to_add)) {
        $classes_to_add = is_string($classes_to_add) ? array($classes_to_add) : array();
    }

    $classes_to_add = array_values(
        array_filter(
            $classes_to_add,
            function ($class_to_add) {
                return is_string($class_to_add) && $class_to_add !== '';
            }
        )
    );
    if (empty($classes_to_add)) {
        return $html;
    }

    if (class_exists('\\WP_HTML_Tag_Processor')) {
        try {
            $processor = new \WP_HTML_Tag_Processor($html);
            if ($processor->next_tag(array('class_name' => $required_class))) {
                foreach ($classes_to_add as $class_to_add) {
                    $processor->add_class($class_to_add);
                }
                $updated_html = $processor->get_updated_html();
                return is_string($updated_html) ? $updated_html : $html;
            }
        } catch (\Throwable $e) {
            return $html;
        }
    }

    $tag_pattern = '~<([a-z0-9]+)\b([^>]*\bclass=([\"\'])(?=[^\"\']*\b' . preg_quote($required_class, '~') . '\b)([^\"\']*)\3[^>]*)>~i';
    $updated_html = preg_replace_callback(
        $tag_pattern,
        function ($matches) use ($classes_to_add) {
            $new_classes = array();

            foreach ($classes_to_add as $class_to_add) {
                if (!preg_match('/\b' . preg_quote($class_to_add, '/') . '\b/', $matches[4])) {
                    $new_classes[] = escape_html_attr($class_to_add);
                }
            }

            if (empty($new_classes)) {
                return $matches[0];
            }

            return preg_replace('~\bclass=([\"\'])([^\"\']*)\1~i', 'class=$1$2 ' . implode(' ', $new_classes) . '$1', $matches[0], 1);
        },
        $html,
        1
    );

    return is_string($updated_html) ? $updated_html : $html;
}

// === Style manager helpers ===

// Shape a declaration for the style manager.
function style_item($at_rules, $selector, $declaration)
{
    return array(
        'atRules' => $at_rules,
        'selector' => $selector,
        'declaration' => $declaration,
    );
}

// Read a module's order class from its elements object.
function get_module_elements_order_class($module_elements)
{
    if (!is_object($module_elements)) {
        return '';
    }

    try {
        $order_class = isset($module_elements->order_class) ? $module_elements->order_class : '';
    } catch (\Throwable $e) {
        return '';
    }

    return is_scalar($order_class) ? (string) $order_class : '';
}

// Ask the module elements object to generate style data.
function get_module_elements_style($module_elements, $style_args)
{
    if (!is_object($module_elements) || !is_callable(array($module_elements, 'style'))) {
        return array();
    }

    try {
        $style = $module_elements->style($style_args);
    } catch (\Throwable $e) {
        return array();
    }

    return is_array($style) ? $style : array();
}

// Read a scalar render argument with a fallback.
function get_scalar_arg($args, $key, $fallback)
{
    if (!is_array($args) || !array_key_exists($key, $args) || !is_scalar($args[$key])) {
        return $fallback;
    }

    return $args[$key];
}

// Read a nested array value without notices.
function get_nested_array_value($array, $path)
{
    if (!is_array($path)) {
        return null;
    }

    $value = $array;

    foreach ($path as $key) {
        if (!is_array($value) || !array_key_exists($key, $value)) {
            return null;
        }
        $value = $value[$key];
    }

    return $value;
}

// Convert a module order class into a safe class selector.
function normalize_order_selector($order_class)
{
    if (!is_string($order_class)) {
        return '';
    }

    $order_class = trim($order_class);
    if ($order_class === '') {
        return '';
    }

    $order_class = $order_class[0] === '.' ? substr($order_class, 1) : $order_class;

    return preg_match('/^[a-z0-9_-]+$/i', $order_class) ? '.' . $order_class : '';
}

// === Escaping and compatibility helpers ===

// Escape text for HTML content.
function escape_html($value)
{
    if (function_exists('esc_html')) {
        return \esc_html($value);
    }

    return htmlspecialchars((string) $value, ENT_NOQUOTES, 'UTF-8');
}

// Escape text for an HTML attribute.
function escape_html_attr($value)
{
    if (function_exists('esc_attr')) {
        return \esc_attr($value);
    }

    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function translate_ui_text($text)
{
    if (!is_string($text)) {
        return is_scalar($text) ? (string) $text : '';
    }

    if (!function_exists('__')) {
        return $text;
    }

    switch ($text) {
        case 'Enter custom text to display inside the timeline marker.':
            return \__('Enter custom text to display inside the timeline marker.', 'divi-booster');
        case 'Marker':
            return \__('Marker', 'divi-booster');
        case 'Marker Text':
            return \__('Marker Text', 'divi-booster');
        case 'Text':
            return \__('Text', 'divi-booster');
    }

    return $text;
}

// Apply the wrapper escaping helper when available.
function maybe_et_core_esc_previously($html)
{
    if (function_exists('et_core_esc_previously')) {
        try {
            return \et_core_esc_previously($html);
        } catch (\Throwable $e) {
            return $html;
        }
    }

    return $html;
}
