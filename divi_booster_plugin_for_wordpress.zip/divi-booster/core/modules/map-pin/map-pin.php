<?php
namespace DiviBooster\DiviBooster\Modules\MapPin;

include_once(dirname(__FILE__) . '/features/show-details/show-details.php');