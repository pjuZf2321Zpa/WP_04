<?php

namespace DiviBooster\DiviBooster\Modules\Tabs;

if (!is_plugin_active('divi-tabs-module-tab-icons/divi-tabs-module-tab-icons.php')) {
    include_once(dirname(__FILE__) . '/features/tab-icons/tab-icons.php');
}