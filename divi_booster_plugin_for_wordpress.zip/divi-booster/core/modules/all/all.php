<?php

namespace DiviBooster\DiviBooster\Modules\Slide;

include_once(dirname(__FILE__) . '/features/background-blur/background-blur.php');
include_once(dirname(__FILE__) . '/features/custom-icons/custom-icons.php');
