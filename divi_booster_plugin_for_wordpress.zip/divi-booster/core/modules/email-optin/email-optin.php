<?php

namespace DiviBooster\DiviBooster\Modules\EmailOptin;

include_once(dirname(__FILE__) . '/features/inline-form/inline-form.php');
include_once(dirname(__FILE__) . '/features/button-animation/button-animation.php');