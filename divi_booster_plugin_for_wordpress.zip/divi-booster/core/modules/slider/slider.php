<?php

namespace DiviBooster\DiviBooster\Modules\Slider;

include_once(dirname(__FILE__) . '/features/run-once/run-once.php');
include_once(dirname(__FILE__) . '/features/order-random/order-random.php');