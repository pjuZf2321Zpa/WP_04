(function () {
    'use strict';

    var wp = window.vendor && window.vendor.wp;
    if (!wp || !wp.hooks) return;

    // Upload attributes can be URLs or upload objects, including converted
    // Divi 4 values. The settings field currently stores desktop.value.src.
    function imageUrl(value) {
        if (typeof value === 'string') return value;
        if (value && typeof value === 'object') return value.src || value.url || '';
        return '';
    }

    function getImage(attribute, hover) {
        if (!attribute) return '';
        if (!hover && typeof attribute === 'string') return attribute;
        var content = attribute.innerContent || attribute;
        var desktop = content.desktop || {};
        var values = hover ? [
            desktop.hover,
            desktop.hover && desktop.hover.value,
            content.hover && content.hover.desktop && content.hover.desktop.value,
            content.hover && content.hover.value,
            attribute.hover && attribute.hover.innerContent &&
                attribute.hover.innerContent.desktop && attribute.hover.innerContent.desktop.value
        ] : [desktop.value, content.value];
        for (var i = 0; i < values.length; i++) {
            var url = imageUrl(values[i]);
            if (url) return url;
        }
        return '';
    }

    function cssUrl(url) {
        return 'url("' + url.replace(/\\/g, '\\\\').replace(/"/g, '\\"')
            .replace(/\r/g, '\\d ').replace(/\n/g, '\\a ').replace(/\f/g, '\\c ') + '")';
    }

    wp.hooks.addFilter('divi.module.wrapper.render', 'divibooster.customImage.preview', function (wrapper, module) {
        if (!module || module.name !== 'divi/social-media-follow-network') return wrapper;

        var attrs = module.attrs || {};
        var network = attrs.socialNetwork && attrs.socialNetwork.innerContent;
        var value = network && network.desktop && network.desktop.value;
        if (!value || value.title !== 'dbdb-custom-image') return wrapper;

        var image = getImage(attrs.diviboosterImageIcon, false);
        if (!image) return wrapper;

        var element = wp.element;
        var StyleContainer = window.divi && window.divi.module && window.divi.module.StyleContainer;
        var selector = module.elements && module.elements.orderClass;
        if (!element || !StyleContainer || !selector || !element.isValidElement(wrapper)) return wrapper;

        // The child module renders its anchor inside ModuleContainer. Styling
        // that anchor avoids relying on the shape of Divi's nested React tree.
        var anchor = selector + '.et-social-dbdb-custom-image a.icon';
        var hoverImage = getImage(attrs.diviboosterImageIcon, true);
        var previewImage = module.isEdited && module.state === 'hover' && hoverImage ? hoverImage : image;
        var css = anchor + '{background-image:' + cssUrl(previewImage) + ';background-size:contain;'
            + 'background-repeat:no-repeat;background-position:center;}'
            + anchor + ':before{content:"a";visibility:hidden;}';
        if (hoverImage) css += anchor + ':hover{background-image:' + cssUrl(hoverImage) + ';}';

        var styles = element.createElement(StyleContainer, {
            key: 'divibooster-custom-image-preview',
            mode: 'builder',
            state: module.isEdited ? module.state : '',
            noStyleTag: false
        }, element.createElement(element.Fragment, null, css));

        // This filter runs on the child itself, with its current attributes.
        // Returning the unmodified wrapper above also removes styles when the
        // image is cleared or the network changes.
        return element.cloneElement(wrapper, {}, wrapper.props.children, styles);
    });
})();
