<?php
namespace DiviBooster\DiviBooster\Modules\Accordion\MultiOpen;

const DIVI5_MODULE_SLUG = 'divi/accordion';
const DIVI5_SETTING_SLUG = 'diviboosterMultiOpen';
const FEATURE_CLASS = 'divibooster-accordion-multi-open';
// Optional marker added by the independent closeable feature when it is active.
const CLOSEABLE_FEATURE_CLASS = 'divibooster-accordion-closeable';

// === Hook registration ===

if (function_exists('add_filter')) {
    add_filter('block_type_metadata_settings', __NAMESPACE__ . '\\register_divi5_attribute', 10, 1);
    add_filter('render_block_' . DIVI5_MODULE_SLUG, __NAMESPACE__ . '\\filter_divi5_accordion_output', 10, 3);
}

if (function_exists('add_action')) {
    add_action('divi_visual_builder_assets_before_enqueue_scripts', __NAMESPACE__ . '\\enqueue_divi5_builder_scripts');
    add_action('divi_visual_builder_assets_before_enqueue_app_window_scripts', __NAMESPACE__ . '\\enqueue_divi5_builder_scripts');
    add_action('divi_visual_builder_assets_after_enqueue_scripts', __NAMESPACE__ . '\\enqueue_divi5_builder_scripts');
    add_action('divi_visual_builder_assets_after_enqueue_app_window_scripts', __NAMESPACE__ . '\\enqueue_divi5_builder_scripts');
    add_action('wp_enqueue_scripts', __NAMESPACE__ . '\\enqueue_divi5_builder_scripts');
}

// === Module metadata and output ===

// Register the setting in accordion block metadata.
function register_divi5_attribute($settings) {
    if (!is_array($settings)) {
        return $settings;
    }

    $module_slug = isset($settings['name']) ? $settings['name'] : '';

    if ($module_slug !== DIVI5_MODULE_SLUG) {
        return $settings;
    }

    if (!isset($settings['attributes']) || !is_array($settings['attributes'])) {
        $settings['attributes'] = array();
    }

    $settings['attributes'][DIVI5_SETTING_SLUG] = get_storage_attribute_definition();

    return $settings;
}

// === Builder and front-end assets ===

// Attach the metadata mapper and enqueue feature behavior.
function enqueue_divi5_builder_scripts() {
    static $mapping_attached_to_module_library = false;

    if (!function_exists('wp_script_is') || !function_exists('wp_add_inline_script')) {
        return;
    }

    if ((!function_exists('et_builder_d5_enabled') || !\et_builder_d5_enabled()) ||
        (!function_exists('et_core_is_fb_enabled') || !\et_core_is_fb_enabled())) {
        return;
    }

    if (function_exists('current_filter') &&
        current_filter() === 'wp_enqueue_scripts' &&
        function_exists('has_block') &&
        !has_block(DIVI5_MODULE_SLUG)) {
        return;
    }

    // Add the metadata mapper before the module-library handle.
    if (!$mapping_attached_to_module_library && wp_script_is('divi-module-library', 'registered')) {
        $mapping_script = get_builder_module_mapping_js();
        if (is_string($mapping_script) && '' !== $mapping_script &&
            wp_add_inline_script('divi-module-library', $mapping_script, 'before')) {
            $mapping_attached_to_module_library = true;
        }
    }

    enqueue_behavior_script();
}

function filter_divi5_accordion_output($block_content, $parsed_block) {
    if (!is_string($block_content)) {
        return $block_content;
    }

    $attrs = is_array($parsed_block) && isset($parsed_block['attrs']) && is_array($parsed_block['attrs']) ? $parsed_block['attrs'] : array();
    $multi_open = get_divi5_attr_value($attrs, DIVI5_SETTING_SLUG, 'off');

    if ($multi_open !== 'on') {
        return $block_content;
    }

    $updated_content = add_feature_class_to_accordion_wrapper($block_content);

    if (false === $updated_content) {
        return $updated_content;
    }

    enqueue_behavior_script();

    return $updated_content;
}

// === Setting metadata ===

// Define the stored setting and its builder control.
function get_storage_attribute_definition() {
    return array(
        'type'                     => 'object',
        'label'                    => 'Multi Open',
        'selector'                 => '{{selector}}',
        'supportsCustomAttributes' => true,
        'settings' => array(
            'innerContent' => array(
                'groupType' => 'group-items',
                'items'     => array(
                    DIVI5_SETTING_SLUG => get_setting_item_definition(DIVI5_SETTING_SLUG . '.innerContent'),
                ),
            ),
        ),
    );
}

// Define the builder field for the multi-open setting.
function get_setting_item_definition($attr_name) {
    $description = function_exists('__') ? __('Allow multiple accordion items to remain open at the same time.', 'divi-booster') : '';

    return array(
        'groupSlug'   => 'designToggle',
        'attrName'    => $attr_name,
        'label'       => 'Multi Open',
        'description' => $description,
        'features'    => array(
            'hover'      => false,
            'sticky'     => false,
            'responsive' => false,
        ),
        'render'      => true,
        'priority'    => 20,
        'component'   => array(
            'type' => 'field',
            'name' => 'divi/toggle',
        ),
        'defaultAttr' => array(
            'desktop' => array(
                'value' => 'off',
            ),
        ),
    );
}

// === Builder mapping ===

// Build filters that expose the setting in builder metadata.
function get_builder_module_mapping_js() {
    if (!function_exists('wp_json_encode')) {
        return '';
    }

    $json_flags         = \JSON_HEX_TAG | \JSON_HEX_AMP | \JSON_HEX_APOS | \JSON_HEX_QUOT;
    $attribute_json     = wp_json_encode(get_storage_attribute_definition(), $json_flags);
    $divi5_slug         = wp_json_encode(DIVI5_MODULE_SLUG, $json_flags);
    $divi5_setting_slug = wp_json_encode(DIVI5_SETTING_SLUG, $json_flags);
    $toggle_group_text  = function_exists('__') ? __('Toggle', 'divi-booster') : 'Toggle';
    $toggle_group_label = wp_json_encode($toggle_group_text, $json_flags);

    if (!is_string($attribute_json) || !is_string($divi5_slug) ||
        !is_string($divi5_setting_slug) || !is_string($toggle_group_label)) {
        return '';
    }

    return <<<END
(function() {
    var hooks = window.vendor && window.vendor.wp && window.vendor.wp.hooks ? window.vendor.wp.hooks : (window.wp && window.wp.hooks ? window.wp.hooks : null);
    if (!hooks) {
        return;
    }
    if (window.diviboosterAccordionMultiOpenMetadataRegistered) {
        return;
    }
    window.diviboosterAccordionMultiOpenMetadataRegistered = true;

    // Add the setting definition without replacing other attributes.
    function addMultiOpenAttribute(attributes) {
        if (!attributes || typeof attributes !== 'object') {
            return attributes;
        }

        attributes[{$divi5_setting_slug}] = {$attribute_json};

        return attributes;
    }

    // === Attribute registration ===

    hooks.addFilter('divi.moduleLibrary.moduleAttributes', 'divibooster/accordion-multi-open', function(attributes, metadata) {
        if (!metadata || metadata.name !== {$divi5_slug}) {
            return attributes;
        }

        return addMultiOpenAttribute(attributes);
    });

    hooks.addFilter('divi.moduleLibrary.moduleAttributes.divi.accordion', 'divibooster/accordion-multi-open', function(attributes) {
        return addMultiOpenAttribute(attributes);
    });

    // === Settings panel ===

    hooks.addFilter('divi.moduleLibrary.moduleSettings.groups.divi.accordion', 'divibooster/accordion-multi-open', function(groups) {
        groups = groups || {};
        if (!groups.designToggle) {
            groups.designToggle = {
                panel: 'design',
                priority: 10,
                groupName: 'designToggle',
                component: {
                    name: 'divi/composite',
                    props: {
                        groupLabel: {$toggle_group_label}
                    }
                }
            };
        }
        return groups;
    });

    // === Module mapping ===

    hooks.addFilter('divi.moduleLibrary.moduleMapping', 'divibooster/accordion-multi-open', function(modules) {
        var attributesPath = [{$divi5_slug}, 'metadata', 'attributes'];
        var target = modules;

        for (var i = 0; i < attributesPath.length; i++) {
            if (!target || !target[attributesPath[i]]) {
                return modules;
            }
            target = target[attributesPath[i]];
        }

        addMultiOpenAttribute(target);

        return modules;
    });
})();
END;
}

// === Accordion behavior ===

// Build the script that applies multi-open behavior and accessibility updates.
function get_behavior_js() {
    if (!function_exists('wp_json_encode')) {
        return '';
    }

    $feature_class = wp_json_encode(FEATURE_CLASS);
    $setting_slug  = wp_json_encode(DIVI5_SETTING_SLUG);
    $closeable_feature_class = wp_json_encode(CLOSEABLE_FEATURE_CLASS);

    if (!is_string($feature_class) || !is_string($setting_slug) || !is_string($closeable_feature_class)) {
        return '';
    }

    return <<<END
(function() {
    if (window.diviboosterAccordionMultiOpenInitialized) {
        return;
    }
    window.diviboosterAccordionMultiOpenInitialized = true;

    var featureClass = {$feature_class};
    var settingSlug = {$setting_slug};
    var closeableFeatureClass = {$closeable_feature_class};
    // Match Divi 5's native accordion animation duration.
    var toggleDuration = 700;
    var builderFallbackEnabled = false;
    var generatedContentId = 0;

    // === Builder setting synchronization ===
    var builderParentDocument = getBuilderParentDocument();
    bindDocument(document, !!builderParentDocument);

    if (builderParentDocument) {
        bindSettingDocument(builderParentDocument);
    } else if (document.querySelector('#et-vb-app-frame')) {
        bindSettingDocument(document);
        bindBuilderFrame();
    }

    // Mirror the setting locally so preview interactions do not depend on store timing.
    // Check a mutation node and its descendants for a match.
    function nodeMatchesOrContains(node, selector) {
        if (!node || typeof node.querySelector !== 'function') {
            return false;
        }

        return (node.nodeType === 1 && matches(node, selector)) ||
            !!node.querySelector(selector);
    }

    // Track setting changes in the document that owns the controls.
    function bindSettingDocument(targetDocument) {
        if (!targetDocument || typeof targetDocument.addEventListener !== 'function' ||
            targetDocument.diviboosterAccordionMultiOpenSettingBound) {
            return;
        }

        targetDocument.diviboosterAccordionMultiOpenSettingBound = true;
        syncBuilderSetting(targetDocument);
        targetDocument.addEventListener('click', function(event) {
            var onLabel = closest(event.target, '.et-vb-field-divi-composite-diviboosterMultiOpen .et-core-control-toggle__label--on');
            var offLabel = closest(event.target, '.et-vb-field-divi-composite-diviboosterMultiOpen .et-core-control-toggle__label--off');

            if (onLabel) {
                builderFallbackEnabled = true;
            } else if (offLabel) {
                builderFallbackEnabled = false;
            }

            scheduleBuilderSettingSync(targetDocument);
        }, true);

        if (typeof window.MutationObserver === 'function' && targetDocument.documentElement) {
            var settingFieldSelector = '.et-vb-field-divi-composite-diviboosterMultiOpen';
            var observer = new MutationObserver(function(records) {
                for (var i = 0; i < records.length; i++) {
                    var record = records[i];
                    if (!record) {
                        continue;
                    }

                    if (closest(record.target, settingFieldSelector)) {
                        scheduleBuilderSettingSync(targetDocument);
                        return;
                    }

                    if (record.type !== 'childList') {
                        continue;
                    }

                    var nodes = record.addedNodes;
                    for (var j = 0; j < nodes.length; j++) {
                        if (nodeMatchesOrContains(nodes[j], settingFieldSelector)) {
                            scheduleBuilderSettingSync(targetDocument);
                            return;
                        }
                    }

                    nodes = record.removedNodes;
                    for (var k = 0; k < nodes.length; k++) {
                        if (nodeMatchesOrContains(nodes[k], settingFieldSelector)) {
                            scheduleBuilderSettingSync(targetDocument);
                            return;
                        }
                    }
                }
            });

            observer.observe(targetDocument.documentElement, {
                attributes: true,
                attributeFilter: ['class', 'value'],
                childList: true,
                subtree: true
            });
        }
    }

    // Coalesce setting updates before syncing the preview.
    function scheduleBuilderSettingSync(targetDocument) {
        if (!targetDocument || targetDocument.diviboosterAccordionMultiOpenSettingSyncScheduled) {
            return;
        }

        targetDocument.diviboosterAccordionMultiOpenSettingSyncScheduled = true;
        var targetWindow = targetDocument.defaultView || window;
        var schedule = null;

        if (targetWindow && typeof targetWindow.requestAnimationFrame === 'function') {
            schedule = function(callback) {
                return targetWindow.requestAnimationFrame(callback);
            };
        } else if (targetWindow && typeof targetWindow.setTimeout === 'function') {
            schedule = function(callback) {
                return targetWindow.setTimeout(callback, 0);
            };
        }

        if (!schedule) {
            targetDocument.diviboosterAccordionMultiOpenSettingSyncScheduled = false;
            return;
        }

        schedule(function() {
            targetDocument.diviboosterAccordionMultiOpenSettingSyncScheduled = false;
            syncBuilderSetting(targetDocument);
        });
    }

    // Mirror the current builder control value for preview interactions.
    function syncBuilderSetting(targetDocument) {
        if (!targetDocument || !targetDocument.querySelector) {
            return;
        }

        var field = targetDocument.querySelector('.et-vb-field-divi-composite-diviboosterMultiOpen');
        var input = field && field.querySelector ?
            field.querySelector('#et-vb-field-input-toggle-diviboosterMultiOpen-innerContent') :
            null;

        if (!input) {
            input = targetDocument.querySelector('#et-vb-field-input-toggle-diviboosterMultiOpen-innerContent');
        }

        if (input) {
            builderFallbackEnabled = input.value === 'on';
        } else if (field) {
            builderFallbackEnabled = !!field.querySelector('.et-core-control-toggle--on');
        }

        if (targetDocument !== document) {
            scheduleAccordionTitleEnhancement(document, true);
        }
    }

    function getBuilderParentDocument() {
        try {
            if (window.parent && window.parent !== window && window.parent.document) {
                return window.parent.document;
            }
        } catch (error) {
            // Ignore failures when the parent window is inaccessible.
        }

        return null;
    }

    // === Document binding ===

    // Bind interaction handlers and, when needed, watch builder DOM updates.
    function bindDocument(targetDocument, isBuilderFrame) {
        if (!targetDocument || typeof targetDocument.addEventListener !== 'function' ||
            targetDocument.diviboosterAccordionMultiOpenBound) {
            return;
        }

        targetDocument.diviboosterAccordionMultiOpenBound = true;
        enhanceAccordionTitles(targetDocument, isBuilderFrame);

        if (isBuilderFrame) {
            scheduleInitialBuilderStateSync(targetDocument);
        }

        var clickHandler = function(event) {
            handleToggleInteraction(event, targetDocument, isBuilderFrame);
        };
        var keydownHandler = function(event) {
            handleKeydown(event, targetDocument, isBuilderFrame);
        };

        targetDocument.addEventListener('click', clickHandler, true);
        targetDocument.addEventListener('keydown', keydownHandler, true);

        if (isBuilderFrame && targetDocument.defaultView &&
            typeof targetDocument.defaultView.addEventListener === 'function') {
            targetDocument.defaultView.addEventListener('click', clickHandler, true);
        }

        if (isBuilderFrame && window.MutationObserver && targetDocument.documentElement) {
            var accordionSelector = '.et_pb_accordion';
            var observer = new MutationObserver(function(records) {
                for (var i = 0; i < records.length; i++) {
                    var record = records[i];
                    if (!record) {
                        continue;
                    }

                    if (closest(record.target, accordionSelector)) {
                        scheduleAccordionTitleEnhancement(targetDocument, isBuilderFrame);
                        return;
                    }

                    if (record.type !== 'childList') {
                        continue;
                    }

                    var nodes = record.addedNodes;
                    for (var j = 0; j < nodes.length; j++) {
                        if (nodeMatchesOrContains(nodes[j], accordionSelector)) {
                            scheduleAccordionTitleEnhancement(targetDocument, isBuilderFrame);
                            return;
                        }
                    }

                    nodes = record.removedNodes;
                    for (var k = 0; k < nodes.length; k++) {
                        if (nodeMatchesOrContains(nodes[k], accordionSelector)) {
                            scheduleAccordionTitleEnhancement(targetDocument, isBuilderFrame);
                            return;
                        }
                    }
                }
            });

            observer.observe(targetDocument.documentElement, {
                attributes: true,
                attributeFilter: ['class'],
                childList: true,
                subtree: true
            });
        }
    }

    // Wait for the builder frame before binding its document.
    function bindBuilderFrame() {
        var frame = document.querySelector('#et-vb-app-frame');

        if (frame) {
            bindFrame(frame);
            return;
        }

        if (typeof window.MutationObserver !== 'function' || !document.documentElement) {
            return;
        }

        var observer = new MutationObserver(function() {
            var currentFrame = document.querySelector('#et-vb-app-frame');
            if (!currentFrame) {
                return;
            }

            bindFrame(currentFrame);
            observer.disconnect();
        });

        observer.observe(document.documentElement, {childList: true, subtree: true});
    }

    // Bind the frame document and handle future reloads.
    function bindFrame(frame) {
        if (!frame || typeof frame.addEventListener !== 'function' ||
            frame.diviboosterAccordionMultiOpenFrameBound) {
            return;
        }

        frame.diviboosterAccordionMultiOpenFrameBound = true;
        var bindFrameDocument = function() {
            try {
                bindDocument(frame.contentDocument, true);
            } catch (error) {
                // Ignore inaccessible or unavailable builder frame documents.
            }
        };

        try {
            frame.addEventListener('load', bindFrameDocument);
        } catch (error) {
            return;
        }

        bindFrameDocument();
    }

    // Coalesce accessibility updates after DOM changes.
    function scheduleAccordionTitleEnhancement(targetDocument, isBuilderFrame) {
        if (!targetDocument || targetDocument.diviboosterAccordionMultiOpenEnhancementScheduled) {
            return;
        }

        targetDocument.diviboosterAccordionMultiOpenEnhancementScheduled = true;
        var targetWindow = targetDocument.defaultView || window;
        var schedule = null;

        if (targetWindow && typeof targetWindow.requestAnimationFrame === 'function') {
            schedule = function(callback) {
                return targetWindow.requestAnimationFrame(callback);
            };
        } else if (targetWindow && typeof targetWindow.setTimeout === 'function') {
            schedule = function(callback) {
                return targetWindow.setTimeout(callback, 0);
            };
        }

        if (!schedule) {
            targetDocument.diviboosterAccordionMultiOpenEnhancementScheduled = false;
            return;
        }

        schedule(function() {
            targetDocument.diviboosterAccordionMultiOpenEnhancementScheduled = false;
            enhanceAccordionTitles(targetDocument, isBuilderFrame);
        });
    }

    // The builder can paint the preview before its edit-post store is hydrated.
    // Retry briefly so saved module settings work on the first render as well as
    // after the settings modal has been opened.
    function scheduleInitialBuilderStateSync(targetDocument) {
        if (!targetDocument || targetDocument.diviboosterAccordionMultiOpenInitialSyncScheduled) {
            return;
        }

        targetDocument.diviboosterAccordionMultiOpenInitialSyncScheduled = true;
        var attempts = 0;
        var maxAttempts = 30;
        var targetWindow = targetDocument.defaultView || window;
        var retry = function() {
            attempts++;
            enhanceAccordionTitles(targetDocument, true);

            var accordions = targetDocument.querySelectorAll ?
                targetDocument.querySelectorAll('.et_pb_accordion') : [];
            var settingResolved = false;

            for (var i = 0; i < accordions.length; i++) {
                var accordion = accordions[i];
                var moduleId = accordion && typeof accordion.getAttribute === 'function' ?
                    accordion.getAttribute('data-id') : '';

                if (hasClass(accordion, featureClass) ||
                    isBuilderModuleSettingEnabled(moduleId, targetDocument)) {
                    settingResolved = true;
                    break;
                }
            }

            if (settingResolved || attempts >= maxAttempts ||
                !targetWindow || typeof targetWindow.setTimeout !== 'function') {
                targetDocument.diviboosterAccordionMultiOpenInitialSyncScheduled = false;
                return;
            }

            targetWindow.setTimeout(retry, 100);
        };

        retry();
    }

    // === Accessibility ===

    // Add ARIA support to titles when multi-open is active.
    function enhanceAccordionTitles(targetDocument, isBuilderFrame) {
        if (!targetDocument || !targetDocument.querySelectorAll) {
            return;
        }

        var titles = targetDocument.querySelectorAll('.et_pb_accordion .et_pb_toggle_title');
        var lastAccordion = null;
        var lastAccordionEnabled = false;

        for (var i = 0; i < titles.length; i++) {
            var title = titles[i];
            var accordion = closest(title, '.et_pb_accordion');
            var toggle = closest(title, '.et_pb_toggle');

            if (!accordion || !toggle || typeof accordion.contains !== 'function' ||
                !accordion.contains(toggle)) {
                continue;
            }

            if (accordion !== lastAccordion) {
                lastAccordion = accordion;
                lastAccordionEnabled = isMultiOpenEnabled(accordion, isBuilderFrame);
            }

            if (!lastAccordionEnabled) {
                continue;
            }

            updateTitleAccessibility(title, toggle);
        }

        if (isBuilderFrame) {
            var accordions = targetDocument.querySelectorAll('.et_pb_accordion');
            for (var accordionIndex = 0; accordionIndex < accordions.length; accordionIndex++) {
                reconcileAccordionState(accordions[accordionIndex], true);
            }
        }
    }

    // Keep the builder visual state aligned after Divi re-renders child modules.
    function reconcileAccordionState(accordion, isBuilderFrame) {
        if (!accordion || !isMultiOpenEnabled(accordion, isBuilderFrame)) {
            return;
        }

        var state = getAccordionState(accordion);
        if (!state || state.reconciling) {
            return;
        }

        var items = getAccordionItems(accordion);
        if (!items.length) {
            return;
        }

        for (var itemIndex = 0; itemIndex < items.length; itemIndex++) {
            if (hasClass(items[itemIndex], 'et_pb_toggle_open')) {
                state.openItems[getAccordionItemKey(items[itemIndex], itemIndex)] = true;
            }
        }

        state.reconciling = true;
        for (var applyIndex = 0; applyIndex < items.length; applyIndex++) {
            var item = items[applyIndex];
            var itemKey = getAccordionItemKey(item, applyIndex);
            setToggleState(item, !!state.openItems[itemKey]);
        }
        state.reconciling = false;
    }

    function getAccordionState(accordion) {
        var targetDocument = accordion && accordion.ownerDocument;
        if (!targetDocument) {
            return null;
        }

        if (!targetDocument.diviboosterAccordionMultiOpenStates) {
            targetDocument.diviboosterAccordionMultiOpenStates = {};
        }

        var accordionKey = accordion.getAttribute && accordion.getAttribute('data-id');
        if (!accordionKey) {
            accordionKey = 'accordion-' + Array.prototype.indexOf.call(
                targetDocument.querySelectorAll('.et_pb_accordion'),
                accordion
            );
        }

        if (!targetDocument.diviboosterAccordionMultiOpenStates[accordionKey]) {
            var state = {
                openItems: {},
                reconciling: false
            };
            var initialItems = getAccordionItems(accordion);

            for (var itemIndex = 0; itemIndex < initialItems.length; itemIndex++) {
                if (hasClass(initialItems[itemIndex], 'et_pb_toggle_open')) {
                    state.openItems[getAccordionItemKey(initialItems[itemIndex], itemIndex)] = true;
                }
            }

            targetDocument.diviboosterAccordionMultiOpenStates[accordionKey] = state;
        }

        return targetDocument.diviboosterAccordionMultiOpenStates[accordionKey];
    }

    function getAccordionItems(accordion) {
        if (!accordion || typeof accordion.querySelectorAll !== 'function') {
            return [];
        }

        var candidates = accordion.querySelectorAll('.et_pb_accordion_item');
        var items = [];

        for (var i = 0; i < candidates.length; i++) {
            if (closest(candidates[i], '.et_pb_accordion') === accordion) {
                items.push(candidates[i]);
            }
        }

        return items;
    }

    function getAccordionItemKey(item, fallbackIndex) {
        if (item && typeof item.getAttribute === 'function') {
            var itemId = item.getAttribute('data-id');
            if (itemId) {
                return itemId;
            }
        }

        return 'item-' + fallbackIndex;
    }

    function setToggleState(toggle, shouldOpen) {
        if (!toggle) {
            return;
        }

        var title = typeof toggle.querySelector === 'function' ? toggle.querySelector('.et_pb_toggle_title') : null;
        var content = findChildByClass(toggle, 'et_pb_toggle_content');

        if (shouldOpen) {
            removeClass(toggle, 'et_pb_toggle_close');
            addClass(toggle, 'et_pb_toggle_open');
            if (content && content.style && content.style.display === 'none') {
                content.style.display = 'block';
            }
        } else {
            removeClass(toggle, 'et_pb_toggle_open');
            addClass(toggle, 'et_pb_toggle_close');
            if (content && content.style) {
                content.style.display = 'none';
            }
        }

        if (title) {
            updateTitleAccessibility(title, toggle);
        }
    }

    // Synchronize title semantics with its toggle.
    function updateTitleAccessibility(title, toggle) {
        if (!title || !toggle || !title.setAttribute) {
            return;
        }

        var tagName = title.tagName ? title.tagName.toLowerCase() : '';
        if (tagName !== 'button') {
            if (typeof title.hasAttribute !== 'function' || !title.hasAttribute('role')) {
                title.setAttribute('role', 'button');
            }
            if (typeof title.hasAttribute !== 'function' || !title.hasAttribute('tabindex')) {
                title.setAttribute('tabindex', '0');
            }
        }

        title.setAttribute('aria-expanded', hasClass(toggle, 'et_pb_toggle_open') ? 'true' : 'false');

        var content = findChildByClass(toggle, 'et_pb_toggle_content');
        if (!content) {
            return;
        }

        if (!content.id) {
            var contentId;
            do {
                contentId = featureClass + '-content-' + generatedContentId++;
            } while (content.ownerDocument && typeof content.ownerDocument.getElementById === 'function' &&
                content.ownerDocument.getElementById(contentId));
            content.id = contentId;
        }

        if (typeof title.getAttribute !== 'function' || !title.getAttribute('aria-controls')) {
            title.setAttribute('aria-controls', content.id);
        }
    }

    // === Toggle interaction ===

    // Route keyboard activation through the same toggle path.
    function handleKeydown(event, targetDocument, isBuilderFrame) {
        if (!event || (event.key !== 'Enter' && event.key !== ' ' && event.key !== 'Spacebar' &&
            event.keyCode !== 13 && event.keyCode !== 32)) {
            return;
        }

        handleToggleInteraction(event, targetDocument, isBuilderFrame);
    }

    // Open enabled items without closing other accordion items.
    function handleToggleInteraction(event, targetDocument, isBuilderFrame) {
        var title = closest(event.target, '.et_pb_toggle_title');
        if (!title) {
            return;
        }

        var accordion = closest(title, '.et_pb_accordion');
        if (!accordion || !isMultiOpenEnabled(accordion, isBuilderFrame)) {
            return;
        }

        var toggle = closest(title, '.et_pb_toggle');
        if (!toggle || typeof accordion.contains !== 'function' || !accordion.contains(toggle)) {
            return;
        }

        // Do not allow another accordion handler to interrupt an animation.
        if (hasClass(accordion, 'et_pb_accordion_toggling')) {
            if (typeof event.preventDefault === 'function') {
                event.preventDefault();
            }
            if (typeof event.stopPropagation === 'function') {
                event.stopPropagation();
            }
            if (typeof event.stopImmediatePropagation === 'function') {
                event.stopImmediatePropagation();
            }
            return;
        }

        if (hasClass(toggle, 'et_pb_toggle_open')) {
            // An open toggle is a no-op for multi-open. If closeable is active,
            // leave this click alone so that its independent handler can close
            // just the clicked toggle.
            if (hasClass(accordion, closeableFeatureClass)) {
                return;
            }

            if (typeof event.preventDefault === 'function') {
                event.preventDefault();
            }
            if (typeof event.stopPropagation === 'function') {
                event.stopPropagation();
            }
            if (typeof event.stopImmediatePropagation === 'function') {
                event.stopImmediatePropagation();
            }
            return;
        }

        updateTitleAccessibility(title, toggle);
        if (typeof event.preventDefault === 'function') {
            event.preventDefault();
        }
        if (typeof event.stopPropagation === 'function') {
            event.stopPropagation();
        }
        if (typeof event.stopImmediatePropagation === 'function') {
            event.stopImmediatePropagation();
        }

        var state = getAccordionState(accordion);
        if (state) {
            var items = getAccordionItems(accordion);
            var itemIndex = Array.prototype.indexOf.call(items, toggle);
            state.openItems[getAccordionItemKey(toggle, itemIndex)] = true;
        }

        openToggle(accordion, toggle, title, targetDocument.defaultView || window);
        scheduleAccordionTitleEnhancement(targetDocument, isBuilderFrame);
    }

    // === Setting detection ===

    // Determine whether multi-open applies to an accordion.
    function isMultiOpenEnabled(accordion, isBuilderFrame) {
        if (hasClass(accordion, featureClass)) {
            return true;
        }

        if (!isBuilderFrame) {
            return false;
        }

        if (builderFallbackEnabled) {
            return true;
        }

        var moduleId = accordion && typeof accordion.getAttribute === 'function' ? accordion.getAttribute('data-id') : '';
        return isBuilderModuleSettingEnabled(moduleId, accordion && accordion.ownerDocument);
    }

    // Read the module setting from the builder data store.
    function isBuilderModuleSettingEnabled(moduleId, targetDocument) {
        if (!moduleId) {
            return false;
        }

        var ownerWindows = [];
        var addOwnerWindow = function(candidate) {
            if (!candidate) {
                return;
            }

            for (var i = 0; i < ownerWindows.length; i++) {
                if (ownerWindows[i] === candidate) {
                    return;
                }
            }

            ownerWindows.push(candidate);
        };

        try {
            addOwnerWindow(targetDocument && targetDocument.defaultView);
        } catch (error) {
            // Continue with the other builder windows.
        }

        addOwnerWindow(window);

        try {
            addOwnerWindow(window.parent);
        } catch (error) {
            // Ignore inaccessible parent windows.
        }

        var paths = [
            settingSlug + '.innerContent',
            settingSlug,
            'module.decoration.' + settingSlug
        ];

        for (var windowIndex = 0; windowIndex < ownerWindows.length; windowIndex++) {
            var ownerWindow = ownerWindows[windowIndex];
            var data = null;

            try {
                data = ownerWindow && ownerWindow.vendor && ownerWindow.vendor.wp && ownerWindow.vendor.wp.data ?
                    ownerWindow.vendor.wp.data :
                    ownerWindow && ownerWindow.wp && ownerWindow.wp.data ? ownerWindow.wp.data : null;
            } catch (error) {
                continue;
            }

            var select = null;
            try {
                select = data && typeof data.select === 'function' ? data.select('divi/edit-post') : null;
            } catch (error) {
                continue;
            }

            if (!select || typeof select.getModuleAttr !== 'function') {
                continue;
            }

            for (var pathIndex = 0; pathIndex < paths.length; pathIndex++) {
                try {
                    if (isOnValue(select.getModuleAttr(moduleId, paths[pathIndex]))) {
                        return true;
                    }
                } catch (error) {
                    // Continue when this path cannot be read.
                }
            }
        }

        return false;
    }

    // Normalize the setting's supported value shapes.
    function isOnValue(value, seen) {
        try {
            if (value && typeof value.toJS === 'function') {
                value = value.toJS();
            }
        } catch (error) {
            return false;
        }

        if (typeof value === 'string') {
            return value.toLowerCase() === 'on';
        }

        if (!value || typeof value !== 'object') {
            return false;
        }

        seen = seen || [];
        for (var seenIndex = 0; seenIndex < seen.length; seenIndex++) {
            if (seen[seenIndex] === value) {
                return false;
            }
        }
        seen.push(value);

        var getIn = null;
        try {
            getIn = typeof value.getIn === 'function' ? value.getIn : null;
        } catch (error) {
            getIn = null;
        }

        if (getIn) {
            var immutablePaths = [
                ['desktop', 'value'],
                ['innerContent', 'desktop', 'value'],
                ['value']
            ];

            for (var i = 0; i < immutablePaths.length; i++) {
                try {
                    if (isOnValue(getIn.call(value, immutablePaths[i]), seen)) {
                        return true;
                    }
                } catch (error) {
                    // Continue when this immutable path cannot be read.
                }
            }
        }

        try {
            if (isOnValue(value.desktop, seen)) {
                return true;
            }
        } catch (error) {
            // Continue with other supported value shapes.
        }

        try {
            if (isOnValue(value.innerContent, seen)) {
                return true;
            }
        } catch (error) {
            // Continue with the direct value shape.
        }

        try {
            return isOnValue(value.value, seen);
        } catch (error) {
            return false;
        }
    }

    // === Toggle animation ===

    // Open a toggle while preserving the configured animation.
    function openToggle(accordion, toggle, title, ownerWindow) {
        var content = findChildByClass(toggle, 'et_pb_toggle_content');

        addClass(accordion, 'et_pb_accordion_toggling');

        var finishToggle = function() {
            removeClass(accordion, 'et_pb_accordion_toggling');
        };

        var jq = null;
        try {
            if (ownerWindow && typeof ownerWindow.jQuery === 'function') {
                jq = ownerWindow.jQuery;
            } else if (typeof window.jQuery === 'function') {
                jq = window.jQuery;
            }
        } catch (error) {
            jq = null;
        }

        if (jq && content) {
            try {
                var jqContent = jq(content);
                if (jqContent && typeof jqContent.css === 'function' &&
                    typeof jqContent.hide === 'function' &&
                    typeof jqContent.is === 'function' &&
                    typeof jqContent.slideToggle === 'function') {
                    jqContent.css('display', getAccordionContentDisplayType(content));
                    jqContent.hide();

                    if (jqContent.is(':visible')) {
                        switchToOpen(toggle, title);
                        finishToggle();
                    } else {
                        jqContent.slideToggle(toggleDuration, function() {
                            switchToOpen(toggle, title);
                            finishToggle();
                        });
                    }

                    return;
                }
            } catch (error) {
                // Fall back to the native animation when the jQuery effect
                // cannot be started.
            }
        }

        animateToggleOpen(content, toggle, title, ownerWindow, finishToggle);
    }

    // Animate the opening with explicit height frames when jQuery is not
    // available.
    function animateToggleOpen(content, toggle, title, ownerWindow, onComplete) {
        if (!content || !content.style) {
            switchToOpen(toggle, title);
            onComplete();
            return;
        }

        content.style.display = getAccordionContentDisplayType(content);

        if (toggleDuration <= 0) {
            switchToOpen(toggle, title);
            onComplete();
            return;
        }

        var previousHeight = content.style.height;
        var previousOverflow = content.style.overflow;
        var previousTransition = content.style.transition;
        var targetHeight = content.scrollHeight;
        var completed = false;
        var targetWindow = ownerWindow || window;
        var schedule = targetWindow && typeof targetWindow.requestAnimationFrame === 'function' ?
            function(callback) {
                return targetWindow.requestAnimationFrame(callback);
            } : targetWindow && typeof targetWindow.setTimeout === 'function' ?
            function(callback) {
                return targetWindow.setTimeout(callback, 16);
            } : null;
        var getTime = targetWindow && targetWindow.performance &&
            typeof targetWindow.performance.now === 'function' ?
            function() {
                return targetWindow.performance.now();
            } : function() {
                return new Date().getTime();
            };

        var restore = function() {
            if (completed) {
                return;
            }

            completed = true;
            switchToOpen(toggle, title);
            content.style.height = previousHeight;
            content.style.overflow = previousOverflow;
            content.style.transition = previousTransition;
            onComplete();
        };

        if (!targetHeight || !schedule) {
            restore();
            return;
        }

        content.style.height = '0px';
        content.style.overflow = 'hidden';
        content.offsetHeight;

        var startTime = null;
        var animate = function(timestamp) {
            var currentTime = typeof timestamp === 'number' ? timestamp : getTime();
            if (null === startTime) {
                startTime = currentTime;
            }

            var progress = Math.min(1, (currentTime - startTime) / toggleDuration);
            var easedProgress = 0.5 - (Math.cos(progress * Math.PI) / 2);
            content.style.height = Math.round(targetHeight * easedProgress) + 'px';

            if (progress >= 1) {
                restore();
                return;
            }

            schedule(animate);
        };

        schedule(animate);
    }

    // Match Divi 5's display type before hiding content for slideToggle().
    function getAccordionContentDisplayType(content) {
        if (hasClass(content, 'et_flex_module')) {
            return 'flex';
        }

        if (hasClass(content, 'et_grid_module')) {
            return 'grid';
        }

        return 'block';
    }

    // Apply the open state and update its accessible title.
    function switchToOpen(toggle, title) {
        removeClass(toggle, 'et_pb_toggle_close');
        addClass(toggle, 'et_pb_toggle_open');

        if (title && title.setAttribute) {
            title.setAttribute('aria-expanded', 'true');
        }
    }

    // === DOM helpers ===

    function closest(element, selector) {
        if (!element) {
            return null;
        }

        if (typeof element.closest === 'function') {
            try {
                return element.closest(selector);
            } catch (error) {
                // Fall back to parent traversal when native closest fails.
            }
        }

        while (element && element.nodeType === 1) {
            if (matches(element, selector)) {
                return element;
            }
            element = element.parentElement;
        }

        return null;
    }

    function matches(element, selector) {
        if (element && typeof element.matches === 'function') {
            try {
                return !!element.matches(selector);
            } catch (error) {
                return false;
            }
        }

        var elementWindow = element && element.ownerDocument && element.ownerDocument.defaultView;
        var fallbackElement = typeof Element !== 'undefined' ? Element : null;
        var proto = elementWindow && elementWindow.Element ? elementWindow.Element.prototype :
            fallbackElement ? fallbackElement.prototype : null;
        if (!proto) {
            return false;
        }

        var fn = proto.matches || proto.matchesSelector || proto.msMatchesSelector || proto.webkitMatchesSelector;
        if (typeof fn !== 'function') {
            return false;
        }

        try {
            return !!fn.call(element, selector);
        } catch (error) {
            return false;
        }
    }

    function hasClass(element, className) {
        return !!(element && element.classList && typeof element.classList.contains === 'function' &&
            element.classList.contains(className));
    }

    function addClass(element, className) {
        if (element && element.classList && typeof element.classList.add === 'function') {
            element.classList.add(className);
        }
    }

    function removeClass(element, className) {
        if (element && element.classList && typeof element.classList.remove === 'function') {
            element.classList.remove(className);
        }
    }

    function findChildByClass(element, className) {
        if (!element || !element.children) {
            return null;
        }

        for (var i = 0; i < element.children.length; i++) {
            if (hasClass(element.children[i], className)) {
                return element.children[i];
            }
        }

        return typeof element.querySelector === 'function' ? element.querySelector('.' + className) : null;
    }
})();
END;
}

// === Attribute and script helpers ===

// Read the setting from the supported attribute shapes.
function get_divi5_attr_value($attrs, $attr_slug, $default) {
    if (!is_array($attrs) || !is_string($attr_slug)) {
        return $default;
    }

    $attribute_values = array();

    if (isset($attrs[$attr_slug])) {
        $attribute_values[] = $attrs[$attr_slug];
    }

    if (isset($attrs['module']) && is_array($attrs['module']) &&
        isset($attrs['module']['decoration']) && is_array($attrs['module']['decoration']) &&
        isset($attrs['module']['decoration'][$attr_slug])) {
        $attribute_values[] = $attrs['module']['decoration'][$attr_slug];
    }

    foreach ($attribute_values as $attribute_value) {
        if (!is_array($attribute_value)) {
            continue;
        }

        if (isset($attribute_value['innerContent']) && is_array($attribute_value['innerContent'])) {
            $attribute_value = $attribute_value['innerContent'];
        }

        if (isset($attribute_value['desktop']) && is_array($attribute_value['desktop']) &&
            isset($attribute_value['desktop']['value'])) {
            return $attribute_value['desktop']['value'];
        }

        if (isset($attribute_value['value'])) {
            return $attribute_value['value'];
        }
    }

    return $default;
}

// Register the behavior script once, then enqueue it.
function enqueue_behavior_script() {
    static $behavior_registered = false;

    if (!function_exists('sanitize_title') || !function_exists('wp_register_script') ||
        !function_exists('wp_add_inline_script') || !function_exists('wp_enqueue_script')) {
        return;
    }

    $behavior_handle = sanitize_title('divi-booster-' . DIVI5_MODULE_SLUG . '-' . DIVI5_SETTING_SLUG . '-behavior');
    if (!is_string($behavior_handle) || '' === $behavior_handle) {
        return;
    }

    if (!$behavior_registered) {
        if (!wp_register_script($behavior_handle, false, array(), null, true)) {
            return;
        }

        $behavior_script = get_behavior_js();
        if (!is_string($behavior_script) || '' === $behavior_script ||
            !wp_add_inline_script($behavior_handle, $behavior_script, 'after')) {
            return;
        }

        $behavior_registered = true;
    }

    wp_enqueue_script($behavior_handle);
}

// === Markup helper ===

// Mark the rendered accordion wrapper for client-side behavior.
function add_feature_class_to_accordion_wrapper($content) {
    if (!is_string($content) || !function_exists('esc_attr')) {
        return false;
    }

    $feature_applied = false;

    $updated_content = preg_replace_callback('/<div\b([^>]*\sclass=(?:"[^"]*"|\'[^\']*\')[^>]*)>/i', function($matches) use (&$feature_applied) {
        if ($feature_applied) {
            return $matches[0];
        }

        if (!isset($matches[0], $matches[1]) || !is_string($matches[0]) || !is_string($matches[1])) {
            return '';
        }

        $tag_attrs = $matches[1];

        if (!preg_match('/\sclass=(["\'])(.*?)\1/i', $tag_attrs, $class_match)) {
            return $matches[0];
        }

        $classes = preg_split('/\s+/', trim($class_match[2]));
        if (!is_array($classes)) {
            return $matches[0];
        }

        if (!in_array('et_pb_accordion', $classes, true)) {
            return $matches[0];
        }

        if (!in_array(FEATURE_CLASS, $classes, true)) {
            $classes[] = FEATURE_CLASS;
        }

        $new_class_attr = ' class=' . $class_match[1] . esc_attr(implode(' ', array_filter($classes))) . $class_match[1];
        $new_tag_attrs = preg_replace_callback('/\sclass=(["\']).*?\1/i', function() use ($new_class_attr) {
            return $new_class_attr;
        }, $tag_attrs, 1);
        $feature_applied = true;

        return '<div' . $new_tag_attrs . '>';
    }, $content, 1);

    return $feature_applied && is_string($updated_content) ? $updated_content : false;
}
