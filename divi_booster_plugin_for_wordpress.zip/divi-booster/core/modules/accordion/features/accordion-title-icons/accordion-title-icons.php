<?php
namespace DiviBooster\Divi5\Accordion\TitleIcon;

const DIVI5_ACCORDION_SLUG      = 'divi/accordion';
const DIVI5_ACCORDION_ITEM_SLUG = 'divi/accordion-item';
const ATTR_TITLE_ICON           = 'diviboosterTitleIcon';
const ATTR_OPEN_ICON_STYLE      = 'diviboosterOpenTitleIcon';
const ATTR_CLOSED_ICON_STYLE    = 'diviboosterClosedTitleIcon';
const CONTENT_GROUP_SLUG        = 'diviboosterContentTitleIcon';
const DESIGN_OPEN_GROUP_SLUG    = 'diviboosterDesignTitleIcon';
const DESIGN_CLOSED_GROUP_SLUG  = 'diviboosterDesignClosedTitleIcon';
const ICON_CLASS                = 'divibooster-accordion-title-icon';
const TITLE_ACTIVE_CLASS        = 'divibooster-accordion-title-icon-active';
const STYLE_VAR_SIZE            = '--divibooster-accordion-title-icon-size';
const BUILDER_HOOKS_HANDLE      = 'divibooster-accordion-title-icons-builder-hooks';
const FRONTEND_STYLES_HANDLE             = 'divibooster-accordion-title-icons-frontend';
const FRONTEND_BASE_STYLES_HANDLE        = 'divibooster-accordion-title-icons-base';
const NESTED_ACCORDION_ITEM_MARKER       = '_diviboosterAccordionItemInAccordion';
const TITLE_HTML_PATTERN                 = '#<h([1-6])\b([^>]*)\bclass=(["\'])([^"\']*\bet_pb_toggle_title\b[^"\']*)\3([^>]*)>(.*?)</h\1>#is';

// === Feature hooks ===
add_filter('block_type_metadata_settings', __NAMESPACE__ . '\\register_divi5_attributes');
add_action('divi_visual_builder_assets_before_enqueue_scripts', __NAMESPACE__ . '\\register_visual_builder_dependency_script', 0);
add_filter('divi_visual_builder_package_build_params_divi-module-library', __NAMESPACE__ . '\\add_visual_builder_package_dependency');
add_filter('divi_frontend_assets_dynamic_assets_global_assets_list', __NAMESPACE__ . '\\ensure_divi5_icon_assets', 20, 3);
add_action('wp_enqueue_scripts', __NAMESPACE__ . '\\enqueue_frontend_base_styles', 1);
add_filter('render_block_data', __NAMESPACE__ . '\\mark_nested_accordion_item_block', 10, 3);
add_filter('render_block_' . DIVI5_ACCORDION_ITEM_SLUG, __NAMESPACE__ . '\\render_accordion_item_block', 10, 3);
add_filter('render_block_' . DIVI5_ACCORDION_SLUG, __NAMESPACE__ . '\\render_accordion_block', 10, 3);

// Register feature attributes and settings groups for the accordion blocks.
function register_divi5_attributes($settings) {
    if (!is_array($settings)) {
        return $settings;
    }

    $module_name = isset($settings['name']) && is_string($settings['name']) ? $settings['name'] : '';

    if ($module_name !== DIVI5_ACCORDION_SLUG && $module_name !== DIVI5_ACCORDION_ITEM_SLUG) {
        return $settings;
    }

    if (!isset($settings['attributes']) || !is_array($settings['attributes'])) {
        $settings['attributes'] = array();
    }

    $settings['attributes'][ATTR_TITLE_ICON]        = get_title_icon_attribute_definition();
    $settings['attributes'][ATTR_OPEN_ICON_STYLE]   = get_title_icon_style_attribute_definition(
        ATTR_OPEN_ICON_STYLE,
        'diviboosterTitleIconStyles',
        DESIGN_OPEN_GROUP_SLUG,
        __('Title Icon', 'divi-booster'),
        false,
        get_open_title_icon_selector()
    );
    $settings['attributes'][ATTR_CLOSED_ICON_STYLE] = get_title_icon_style_attribute_definition(
        ATTR_CLOSED_ICON_STYLE,
        'diviboosterClosedTitleIconStyles',
        DESIGN_CLOSED_GROUP_SLUG,
        __('Closed Title Icon', 'divi-booster'),
        false,
        get_closed_title_icon_selector()
    );
    $settings = add_title_icon_settings_groups($settings);

    return $settings;
}

// === Visual builder integration ===
// Load the hook bridge used by the live preview.
function register_visual_builder_dependency_script() {
    static $inline_added = false;

    if (!function_exists('wp_register_script') || !function_exists('wp_script_is')) {
        return;
    }

    if (!wp_script_is(BUILDER_HOOKS_HANDLE, 'registered')) {
        wp_register_script(BUILDER_HOOKS_HANDLE, '', array('lodash', 'divi-vendor-wp-hooks'), null, true);
    }

    if ($inline_added || !is_divi5_builder_preview() || !function_exists('wp_add_inline_script')) {
        return;
    }

    wp_add_inline_script(BUILDER_HOOKS_HANDLE, get_visual_builder_script(), 'after');

    $inline_added = true;
}

// Add the hook bridge to the module library bundle.
function add_visual_builder_package_dependency($params) {
    if (!is_array($params)) {
        return $params;
    }

    if (!isset($params['script']) || !is_array($params['script'])) {
        $params['script'] = array();
    }

    $deps = isset($params['script']['deps']) && is_array($params['script']['deps']) ? $params['script']['deps'] : array();

    if (!in_array(BUILDER_HOOKS_HANDLE, $deps, true)) {
        array_unshift($deps, BUILDER_HOOKS_HANDLE);
    }

    $params['script']['deps'] = $deps;

    return $params;
}

// Detect the editor preview without assuming builder APIs are available.
function is_divi5_builder_preview() {
    static $is_preview = null;

    if ($is_preview !== null) {
        return $is_preview;
    }

    if (!function_exists('et_builder_d5_enabled') || !function_exists('et_core_is_fb_enabled')) {
        $is_preview = false;
        return $is_preview;
    }

    try {
        $is_preview = (bool) \et_builder_d5_enabled() && (bool) \et_core_is_fb_enabled();
    } catch (\Throwable $e) {
        $is_preview = false;
    }

    return $is_preview;
}

// === Asset loading ===
// Add icon styles to the shared asset manifest.
function ensure_divi5_icon_assets($global_asset_list, $assets_args = array()) {
    if (!is_array($global_asset_list)) {
        return $global_asset_list;
    }

    if (!is_array($assets_args)) {
        $assets_args = array();
    }

    $assets_prefix = isset($assets_args['assets_prefix']) && is_string($assets_args['assets_prefix']) ? $assets_args['assets_prefix'] : '';

    if ($assets_prefix === '' && class_exists('\\ET\\Builder\\FrontEnd\\Assets\\DynamicAssetsUtils') && method_exists('\\ET\\Builder\\FrontEnd\\Assets\\DynamicAssetsUtils', 'get_dynamic_assets_path')) {
        try {
            $dynamic_assets_prefix = \ET\Builder\FrontEnd\Assets\DynamicAssetsUtils::get_dynamic_assets_path();

            if (is_string($dynamic_assets_prefix)) {
                $assets_prefix = $dynamic_assets_prefix;
            }
        } catch (\Throwable $e) {
            $assets_prefix = '';
        }
    }

    if ($assets_prefix === '') {
        return $global_asset_list;
    }

    $icon_asset_definitions = array(
        'et_icons_all' => array(
            'css' => "{$assets_prefix}/css/icons_all.css",
        ),
        'et_icons_fa' => array(
            'css' => "{$assets_prefix}/css/icons_fa_all.css",
        ),
    );

    foreach ($icon_asset_definitions as $asset_name => $definition) {
        $existing_definition = isset($global_asset_list[$asset_name]) && is_array($global_asset_list[$asset_name])
            ? $global_asset_list[$asset_name]
            : array();

        $global_asset_list[$asset_name] = array_replace($definition, $existing_definition);
    }

    return $global_asset_list;
}

// === Block rendering ===
// Mark nested items so the parent accordion can render their titles.
function mark_nested_accordion_item_block($parsed_block, $parent_block) {
    if (!is_array($parsed_block) || !is_object($parent_block) || !isset($parsed_block['blockName']) || $parsed_block['blockName'] !== DIVI5_ACCORDION_ITEM_SLUG) {
        return $parsed_block;
    }

    if (!isset($parent_block->parsed_block) || !is_array($parent_block->parsed_block) || !isset($parent_block->parsed_block['blockName']) || $parent_block->parsed_block['blockName'] !== DIVI5_ACCORDION_SLUG) {
        return $parsed_block;
    }

    $parsed_block[NESTED_ACCORDION_ITEM_MARKER] = true;

    return $parsed_block;
}

function is_nested_accordion_item_block($parsed_block) {
    return is_array($parsed_block) && !empty($parsed_block[NESTED_ACCORDION_ITEM_MARKER]);
}

// Render an item icon unless the parent accordion will render its title.
function render_accordion_item_block($block_content, $parsed_block) {
    if (!is_string($block_content) || !is_array($parsed_block)) {
        return $block_content;
    }

    if (is_nested_accordion_item_block($parsed_block)) {
        return $block_content;
    }

    if (strpos($block_content, 'et_pb_toggle_title') === false) {
        return $block_content;
    }

    $block_content = add_builder_icon_data_to_item_block($block_content, $parsed_block);

    if (strpos($block_content, ICON_CLASS) !== false) {
        return $block_content;
    }

    $icon = normalize_icon(get_attr($parsed_block, ATTR_TITLE_ICON));

    if (empty($icon)) {
        return $block_content;
    }

    $style_data = get_icon_style_data_for_block($parsed_block);
    $result     = inject_icon_into_first_title($block_content, $icon, $style_data);

    if (!is_array($result) || empty($result['changed']) || !isset($result['content']) || !is_string($result['content'])) {
        return $block_content;
    }

    $order_class = get_order_class_from_content($result['content'], 'et_pb_accordion_item');

    if (!$order_class) {
        $order_class = get_order_class_from_content($result['content'], 'et_pb_toggle');
    }

    if ($order_class) {
        $selector = '.' . sanitize_html_class($order_class);
        enqueue_frontend_styles(get_icon_state_css($selector, $style_data));
    }

    return $result['content'];
}

// Bridge server-rendered icon data to the live builder preview.
function add_builder_icon_data_to_item_block($block_content, $parsed_block, $force = false) {
    if ((!$force && !is_divi5_builder_preview()) || !is_string($block_content) || $block_content === '' || !is_array($parsed_block)) {
        return $block_content;
    }

    if (strpos($block_content, 'data-divibooster-accordion-title-icon-record=') !== false) {
        return $block_content;
    }

    $icon = normalize_icon(get_attr($parsed_block, ATTR_TITLE_ICON));

    if (empty($icon)) {
        return $block_content;
    }

    $style_data = get_icon_style_data_for_block($parsed_block);

    if (!function_exists('wp_json_encode')) {
        return $block_content;
    }

    $record     = array(
        'icon'   => get_builder_icon_record_data($icon),
        'open'   => isset($style_data['open']) ? $style_data['open'] : array(),
        'closed' => isset($style_data['closed']) ? $style_data['closed'] : array(),
    );
    $json = wp_json_encode($record);

    if (!is_string($json) || $json === '') {
        return $block_content;
    }

    $attr = ' data-divibooster-accordion-title-icon-record="' . esc_attr(rawurlencode($json)) . '"';
    $patterns = array(
        '/(<div\b[^>]*\bclass=(["\'])(?=[^"\']*\bet_pb_toggle\b)(?=[^"\']*\bet_pb_accordion_item\b)[^"\']*\2[^>]*)(>)/i',
        '/(<div\b[^>]*\bclass=(["\'])(?=[^"\']*\bet_pb_toggle\b)[^"\']*\2[^>]*)(>)/i',
        '/(<div\b[^>]*\bclass=(["\'])(?=[^"\']*\bet_pb_accordion_item\b)[^"\']*\2[^>]*)(>)/i',
    );

    foreach ($patterns as $pattern) {
        if (!preg_match($pattern, $block_content)) {
            continue;
        }

        $updated = preg_replace_callback(
            $pattern,
            function($matches) use ($attr) {
                return $matches[1] . $attr . $matches[3];
            },
            $block_content,
            1
        );

        return is_string($updated) ? $updated : $block_content;
    }

    return $block_content;
}

function get_builder_icon_record_data($icon) {
    if (!is_array($icon) || !isset($icon['character']) || !is_scalar($icon['character'])) {
        return array();
    }

    $character = (string) $icon['character'];
    $type      = isset($icon['type']) && is_scalar($icon['type']) ? (string) $icon['type'] : '';

    if (trim($character) === '' || ($type !== 'fa' && $type !== 'divi')) {
        return array();
    }

    if ($type === 'fa') {
        $font_family = isset($icon['font_family']) && is_scalar($icon['font_family']) ? (string) $icon['font_family'] : 'FontAwesome';
        $font_weight = isset($icon['font_weight']) && is_scalar($icon['font_weight']) ? (string) $icon['font_weight'] : '900';

        return array(
            'type'       => 'fa',
            'character'  => $character,
            'fontFamily' => $font_family !== '' ? $font_family : 'FontAwesome',
            'fontWeight' => $font_weight !== '' ? $font_weight : '900',
        );
    }

    return array(
        'type'       => 'divi',
        'character'  => $character,
        'fontFamily' => 'ETmodules',
        'fontWeight' => '',
    );
}

// Render icons for accordion titles, inheriting parent styles where needed.
function render_accordion_block($block_content, $parsed_block) {
    if (!is_string($block_content) || !is_array($parsed_block) || strpos($block_content, 'et_pb_toggle_title') === false) {
        return $block_content;
    }

    $parent_icon  = normalize_icon(get_attr($parsed_block, ATTR_TITLE_ICON));
    $child_blocks = get_accordion_item_blocks($parsed_block);

    if (empty($parent_icon)) {
        $has_child_icon = false;

        foreach ($child_blocks as $child_block) {
            if (!empty(get_attr($child_block, ATTR_TITLE_ICON))) {
                $has_child_icon = true;
                break;
            }
        }

        if (!$has_child_icon) {
            return $block_content;
        }
    }

    $parent_style_data = get_icon_style_data_for_block($parsed_block);
    $title_index       = 0;
    $changed           = false;
    $item_styles       = array();

    $pattern = TITLE_HTML_PATTERN;

    $new_content = preg_replace_callback($pattern, function($matches) use (&$title_index, &$changed, &$item_styles, $child_blocks, $parent_icon, $parent_style_data) {
        $item_index       = $title_index++;
        $child_block      = isset($child_blocks[$item_index]) ? $child_blocks[$item_index] : array();
        $child_attr       = get_attr($child_block, ATTR_TITLE_ICON);
        $child_icon       = normalize_icon($child_attr);
        $child_style_data = get_icon_style_data_for_block($child_block);
        $icon             = !empty($child_icon) ? $child_icon : $parent_icon;
        $style_data       = merge_style_data($parent_style_data, $child_style_data);
        $item_styles[$item_index] = $style_data;

        if (empty($icon)) {
            return $matches[0];
        }

        $changed = true;

        return build_title_html_with_icon($matches, $icon, $style_data);
    }, $block_content);

    if (!is_string($new_content) || !$changed) {
        return $block_content;
    }

    $item_order_classes = get_accordion_item_order_classes($new_content);
    $item_style_records = array();

    foreach ($item_styles as $index => $style_data) {
        if (empty($item_order_classes[$index])) {
            continue;
        }

        $item_style_records[] = array(
            'order_class' => $item_order_classes[$index],
            'style_data'  => $style_data,
        );
    }

    if (empty($item_style_records)) {
        return $new_content;
    }

    $order_class = get_order_class_from_content($new_content, 'et_pb_accordion');

    if (!$order_class) {
        return $new_content;
    }

    enqueue_frontend_styles(get_accordion_items_state_css($order_class, $item_style_records));

    return $new_content;
}

// === Visual builder preview ===
// Build the JavaScript bridge for live preview icons.
function get_visual_builder_script() {
    if (!function_exists('wp_json_encode')) {
        return '';
    }

    $accordion_slug      = wp_json_encode(DIVI5_ACCORDION_SLUG);
    $accordion_item_slug = wp_json_encode(DIVI5_ACCORDION_ITEM_SLUG);
    $attr_slug           = wp_json_encode(ATTR_TITLE_ICON);
    $open_style_slug     = wp_json_encode(ATTR_OPEN_ICON_STYLE);
    $closed_style_slug   = wp_json_encode(ATTR_CLOSED_ICON_STYLE);
    $attribute           = wp_json_encode(get_visual_builder_title_icon_attribute_definition());
    $open_style_attr     = wp_json_encode(get_visual_builder_title_icon_style_attribute_definition(
        ATTR_OPEN_ICON_STYLE,
        'diviboosterTitleIconStyles',
        DESIGN_OPEN_GROUP_SLUG,
        __('Title Icon', 'divi-booster'),
        get_visual_builder_open_icon_selector(),
        false
    ));
    $closed_style_attr   = wp_json_encode(get_visual_builder_title_icon_style_attribute_definition(
        ATTR_CLOSED_ICON_STYLE,
        'diviboosterClosedTitleIconStyles',
        DESIGN_CLOSED_GROUP_SLUG,
        __('Closed Title Icon', 'divi-booster'),
        get_visual_builder_closed_icon_selector(),
        false
    ));
    $content_group_slug  = wp_json_encode(CONTENT_GROUP_SLUG);
    $open_group_slug     = wp_json_encode(DESIGN_OPEN_GROUP_SLUG);
    $closed_group_slug   = wp_json_encode(DESIGN_CLOSED_GROUP_SLUG);
    $content_group       = wp_json_encode(get_content_group_definition());
    $open_group          = wp_json_encode(get_design_group_definition(DESIGN_OPEN_GROUP_SLUG, __('Title Icon', 'divi-booster'), 21));
    $closed_group        = wp_json_encode(get_design_group_definition(DESIGN_CLOSED_GROUP_SLUG, __('Closed Title Icon', 'divi-booster'), 31));
    $preview_css         = wp_json_encode(get_visual_builder_preview_css());

    return <<<JS
(function(){
    // === Preview setup ===
    var css = {$preview_css};
    var styleId = 'divibooster-accordion-title-icon-preview-css';

    function addPreviewCss(doc) {
        if (!doc || !doc.head || doc.getElementById(styleId)) {
            return;
        }

        var style = doc.createElement('style');
        style.id = styleId;
        style.textContent = css;
        doc.head.appendChild(style);
    }

    function watchPreviewIframe(iframe) {
        if (!iframe || iframe.__diviboosterAccordionTitleIconWatched) {
            return;
        }

        iframe.__diviboosterAccordionTitleIconWatched = true;
        iframe.addEventListener('load', function() {
            try {
                addPreviewCss(iframe.contentDocument);
                renderPreviewIconsInDoc(iframe.contentDocument);
            } catch (e) {}
        });
    }

    function addPreviewCssEverywhere() {
        addPreviewCss(document);

        Array.prototype.forEach.call(document.querySelectorAll('iframe'), function(iframe) {
            watchPreviewIframe(iframe);

            try {
                addPreviewCss(iframe.contentDocument);
            } catch (e) {}
        });
    }

    addPreviewCssEverywhere();

    var attrTitleIcon = {$attr_slug};
    var attrOpenStyle = {$open_style_slug};
    var attrClosedStyle = {$closed_style_slug};
    var iconClass = 'divibooster-accordion-title-icon';
    var activeTitleClass = 'divibooster-accordion-title-icon-active';
    var styleVarSize = '--divibooster-accordion-title-icon-size';

    // === Preview data ===
    // Read an attribute from the builder's supported data shapes.
    function getAttrValue(source, key) {
        if (!source || typeof source !== 'object') {
            return null;
        }

        if (Object.prototype.hasOwnProperty.call(source, key)) {
            return source[key];
        }

        if (source.attrs && typeof source.attrs === 'object' && Object.prototype.hasOwnProperty.call(source.attrs, key)) {
            return source.attrs[key];
        }

        if (source.attributes && typeof source.attributes === 'object' && Object.prototype.hasOwnProperty.call(source.attributes, key)) {
            return source.attributes[key];
        }

        if (source.module && typeof source.module === 'object' && Object.prototype.hasOwnProperty.call(source.module, key)) {
            return source.module[key];
        }

        return null;
    }

    function getDesktopValue(attr) {
        if (attr && typeof attr === 'object' && attr.desktop && typeof attr.desktop === 'object' && Object.prototype.hasOwnProperty.call(attr.desktop, 'value')) {
            return attr.desktop.value;
        }

        return attr;
    }

    function extractIconMetaProp(value, propName) {
        var preferredKeys;
        var keys;
        var i;
        var key;
        var nested;

        if (!value || typeof value !== 'object' || !propName) {
            return '';
        }

        if (Object.prototype.hasOwnProperty.call(value, propName) && value[propName] !== null && value[propName] !== undefined) {
            if (String(value[propName]).trim() !== '') {
                return String(value[propName]).trim();
            }
        }

        preferredKeys = ['value', 'desktop', 'tablet', 'phone', 'innerContent', 'iconPicker'];

        for (i = 0; i < preferredKeys.length; i++) {
            key = preferredKeys[i];

            if (Object.prototype.hasOwnProperty.call(value, key)) {
                nested = extractIconMetaProp(value[key], propName);

                if (nested !== '') {
                    return nested;
                }
            }
        }

        keys = Object.keys(value);

        for (i = 0; i < keys.length; i++) {
            nested = extractIconMetaProp(value[keys[i]], propName);

            if (nested !== '') {
                return nested;
            }
        }

        return '';
    }

    function decodeIconValue(iconValue, alreadyProcessed) {
        iconValue = String(iconValue || '').trim();

        if (!alreadyProcessed && /^\\u[0-9a-f]{4,6}$/i.test(iconValue)) {
            iconValue = iconValue.substring(2);
        }

        if (!alreadyProcessed && /^(?:U\+|0x)[0-9a-f]{3,6}$/i.test(iconValue)) {
            iconValue = iconValue.substring(2);
        }

        if (!alreadyProcessed && /^[a-f0-9]{3,6}$/i.test(iconValue)) {
            var codePoint = parseInt(iconValue, 16);
            if (isFinite(codePoint) && typeof String.fromCodePoint === 'function') {
                return String.fromCodePoint(codePoint);
            }
        }

        var textarea = document.createElement('textarea');
        textarea.innerHTML = iconValue;
        return textarea.value || iconValue;
    }

    function normalizeFontAwesomeWeight(weight, type) {
        var raw = String(weight || '').trim().toLowerCase();
        var normalizedType = String(type || '').trim().toLowerCase();
        var numeric;

        if (raw === 'regular' || raw === 'normal' || raw === 'book' || raw === 'medium') {
            return '400';
        }

        if (raw === 'bold' || raw === 'solid' || raw === 'semibold' || raw === 'black' || raw === 'heavy') {
            return '900';
        }

        numeric = raw.replace(/[^0-9]/g, '');

        if (/^(100|200|300|400|500|600|700|800|900)$/.test(numeric)) {
            return parseInt(numeric, 10) >= 600 ? '900' : '400';
        }

        return ['fab', 'fa-brands', 'brands', 'far', 'fa-regular', 'regular'].indexOf(normalizedType) !== -1 ? '400' : '900';
    }

    // Convert builder icon data into a renderable font record.
    function normalizeIcon(attr) {
        var value = getDesktopValue(attr);
        var iconValue = '';
        var type = 'divi';
        var fontWeight = '900';
        var fontFamily = 'FontAwesome';
        var extracted;
        var metadataType = extractIconMetaProp(attr, 'type').toLowerCase() || extractIconMetaProp(attr, 'iconType').toLowerCase();
        var metadataWeight = extractIconMetaProp(attr, 'weight');
        var metadataFamily = extractIconMetaProp(attr, 'fontFamily').toLowerCase();

        if (!metadataType && metadataFamily === 'fontawesome') {
            metadataType = 'fa';
        }

        if (metadataType) {
            type = metadataType;
        }

        if (metadataWeight) {
            fontWeight = metadataWeight;
        }

        if (!value) {
            return null;
        }

        if (typeof value === 'object') {
            extracted = extractIconValue(value);

            if (extracted && extracted.value) {
                iconValue = extracted.value;
                value = extracted.source || value;
            }

            if (value.icon && typeof value.icon === 'object') {
                value = value.icon;
            }

            if (!iconValue && typeof value.icon === 'string') {
                iconValue = value.icon;
            } else if (!iconValue && typeof value.unicode === 'string') {
                iconValue = value.unicode;
            } else if (!iconValue && typeof value.value === 'string') {
                iconValue = value.value;
            }

            if (typeof value.type === 'string') {
                type = value.type.toLowerCase();
            } else if (typeof value.iconType === 'string') {
                type = value.iconType.toLowerCase();
            }

            if (value.weight !== undefined) {
                fontWeight = String(value.weight).replace(/[^0-9]/g, '') || fontWeight;
            } else if (value.fontWeight !== undefined) {
                fontWeight = String(value.fontWeight).replace(/[^0-9]/g, '') || fontWeight;
            }

            if (value.style === 'brands') {
                type = 'fa-brands';
                fontFamily = 'FontAwesome';
                fontWeight = '400';
            }
        } else if (typeof value === 'string') {
            iconValue = value;

            if (value.indexOf('||') !== -1) {
                var parts = value.split('||');
                iconValue = parts[0] || value;

                parts.forEach(function(part) {
                    part = String(part).toLowerCase();

                    if (part.indexOf('fa') !== -1) {
                        type = 'fa';
                    }

                    if (part === 'brands' || part === 'fa-brands') {
                        fontFamily = 'FontAwesome';
                        fontWeight = '400';
                    }

                    if (part === 'regular' || part === 'fa-regular') {
                        fontWeight = '400';
                    }
                });
            }
        }

        iconValue = String(iconValue || '').trim();

        if (!iconValue || iconValue === 'none' || iconValue === 'false') {
            return null;
        }

        if (type.indexOf('fa') !== -1 || ['brands', 'regular', 'solid', 'fontawesome'].indexOf(type) !== -1) {
            fontWeight = normalizeFontAwesomeWeight(fontWeight, type);

            return {
                type: 'fa',
                character: decodeIconValue(iconValue, false),
                fontFamily: fontFamily,
                fontWeight: fontWeight || '900'
            };
        }

        return {
            type: 'divi',
            character: decodeIconValue(iconValue, true),
            fontFamily: 'ETmodules',
            fontWeight: ''
        };
    }

    function extractIconValue(value) {
        var preferredKeys;
        var directKeys;
        var keys;
        var i;
        var key;
        var nested;

        value = getDesktopValue(value);

        if (typeof value === 'string') {
            return { value: value, source: null };
        }

        if (!value || typeof value !== 'object') {
            return null;
        }

        directKeys = ['icon', 'unicode', 'char', 'code', 'value'];

        for (i = 0; i < directKeys.length; i++) {
            key = directKeys[i];

            if (typeof value[key] === 'string' && value[key].trim() !== '') {
                return { value: value[key], source: value };
            }
        }

        preferredKeys = ['innerContent', 'iconPicker', 'desktop', 'tablet', 'phone'];

        for (i = 0; i < preferredKeys.length; i++) {
            key = preferredKeys[i];

            if (Object.prototype.hasOwnProperty.call(value, key)) {
                nested = extractIconValue(value[key]);

                if (nested && nested.value) {
                    if (!nested.source) {
                        nested.source = value;
                    }
                    return nested;
                }
            }
        }

        keys = Object.keys(value);

        for (i = 0; i < keys.length; i++) {
            nested = extractIconValue(value[keys[i]]);

            if (nested && nested.value) {
                if (!nested.source) {
                    nested.source = value;
                }
                return nested;
            }
        }

        return null;
    }

    function sanitizeCssValue(value, property) {
        if (typeof value !== 'string' && typeof value !== 'number') {
            return '';
        }

        value = String(value).trim();

        if (property === 'color' && /^(#[0-9a-f]{3,8}|rgba?\([0-9\s.,%]+\)|hsla?\([0-9\s.,%]+\)|var\(--[a-z0-9_-]+\)|[a-z]+)$/i.test(value)) {
            return value;
        }

        if (property === 'size' && /^(?:-?\d+(?:\.\d+)?(?:px|em|rem|%|vw|vh|vmin|vmax)|calc\([a-z0-9\s+\-*\/.%,()]+\)|var\(--[a-z0-9_-]+\))$/i.test(value)) {
            return value;
        }

        return '';
    }

    function sanitizeIconStyleValue(value, property) {
        var sanitized;

        if (typeof value === 'string' || typeof value === 'number') {
            return property === 'color' || property === 'size'
                ? sanitizeCssValue(value, property)
                : value;
        }

        if (!value || typeof value !== 'object') {
            return value;
        }

        if (Array.isArray(value)) {
            return value.map(function(item) {
                return sanitizeIconStyleValue(item, property);
            });
        }

        sanitized = {};

        Object.keys(value).forEach(function(key) {
            var childProperty;

            if (key === '__proto__' || key === 'constructor' || key === 'prototype') {
                return;
            }

            childProperty = key === 'color' || key === 'size' ? key : property;
            sanitized[key] = sanitizeIconStyleValue(value[key], childProperty);
        });

        return sanitized;
    }

    function sanitizeIconStyleAttribute(attr) {
        return attr && typeof attr === 'object' ? sanitizeIconStyleValue(attr, '') : null;
    }

    function sanitizePreviewOrderClass(value) {
        if (typeof value !== 'string') {
            return '';
        }

        value = value.trim();

        if (value.charAt(0) === '.') {
            return /^[.][a-z_][a-z0-9_-]*$/i.test(value) ? value : '';
        }

        return /^[a-z_][a-z0-9_-]*$/i.test(value) ? '.' + value : '';
    }

    function getStyleProperty(attr, property) {
        var preferredKeys;
        var keys;
        var i;
        var key;
        var nested;

        if (!attr || typeof attr !== 'object' || !property) {
            return '';
        }

        if (Object.prototype.hasOwnProperty.call(attr, property) && (typeof attr[property] === 'string' || typeof attr[property] === 'number')) {
            return attr[property];
        }

        preferredKeys = ['desktop', 'value', 'decoration', 'icon', 'tablet', 'phone', 'innerContent', 'iconPicker'];

        for (i = 0; i < preferredKeys.length; i++) {
            key = preferredKeys[i];

            if (Object.prototype.hasOwnProperty.call(attr, key)) {
                nested = getStyleProperty(attr[key], property);

                if (nested !== '') {
                    return nested;
                }
            }
        }

        keys = Object.keys(attr);

        for (i = 0; i < keys.length; i++) {
            if (preferredKeys.indexOf(keys[i]) !== -1) {
                continue;
            }

            nested = getStyleProperty(attr[keys[i]], property);

            if (nested !== '') {
                return nested;
            }
        }

        return '';
    }

    function getIconStyle(attr) {
        var data = { color: '', size: '' };

        if (!attr || typeof attr !== 'object') {
            return data;
        }

        data.color = sanitizeCssValue(getStyleProperty(attr, 'color'), 'color');
        data.size = sanitizeCssValue(getStyleProperty(attr, 'size'), 'size');

        return data;
    }

    function mergeStyle(parent, child) {
        parent = parent || {};
        child = child || {};

        return {
            color: child.color || parent.color || '',
            size: child.size || parent.size || ''
        };
    }

    function buildRecord(source) {
        var iconAttr = getAttrValue(source, attrTitleIcon);
        var icon = normalizeIcon(iconAttr);

        if (!icon) {
            return null;
        }

        var openStyle = getIconStyle(getAttrValue(source, attrOpenStyle));
        var closedStyle = getIconStyle(getAttrValue(source, attrClosedStyle));
        var legacyStyle = getIconStyle(iconAttr);

        if (!openStyle.color && !openStyle.size) {
            openStyle = legacyStyle;
        }

        closedStyle = mergeStyle(openStyle, closedStyle);

        return {
            icon: icon,
            open: openStyle,
            closed: closedStyle
        };
    }

    function mergeRecord(parent, child) {
        if (!parent) {
            return child;
        }

        if (!child) {
            return parent;
        }

        return {
            icon: child.icon || parent.icon,
            open: mergeStyle(parent.open, child.open),
            closed: mergeStyle(parent.closed, child.closed)
        };
    }

    // === Preview rendering ===
    // Remove a preview icon without disturbing a child override.
    function clearRecordFromTitle(title, source) {
        var span;
        var spanSource;

        if (!title) {
            return;
        }

        span = title.querySelector(':scope > .' + iconClass);

        if (!span) {
            return;
        }

        spanSource = span.getAttribute('data-divibooster-accordion-title-icon-source') || '';

        if (source === 'parent' && spanSource === 'child') {
            return;
        }

        if (source === 'child' && spanSource !== 'child') {
            return;
        }

        span.remove();
        title.classList.remove(activeTitleClass);
        title.style.removeProperty(styleVarSize);
    }

    // Apply one icon record to a title and its current state.
    function applyRecordToTitle(title, record, source) {
        var span = title.querySelector(':scope > .' + iconClass);
        if (!record) {
            clearRecordFromTitle(title, source);
            return;
        }

        if (source === 'parent' && span && span.getAttribute('data-divibooster-accordion-title-icon-source') === 'child') {
            return;
        }

        if (!span) {
            span = title.ownerDocument.createElement('span');
            span.className = iconClass;
            title.insertBefore(span, title.firstChild);
        }

        span.setAttribute('aria-hidden', 'true');
        span.setAttribute('data-divibooster-accordion-title-icon-source', source || 'preview');
        title.classList.add(activeTitleClass);

        var stateStyle = title.closest && title.closest('.et_pb_toggle_close') ? (record.closed || {}) : (record.open || {});

        span.textContent = record.icon.character;
        span.classList.toggle('et-pb-icon', record.icon.type === 'divi');
        span.classList.toggle('divibooster-accordion-title-icon-fa', record.icon.type !== 'divi');
        span.style.fontFamily = record.icon.fontFamily || (record.icon.type === 'divi' ? 'ETmodules' : 'FontAwesome');
        span.style.fontWeight = record.icon.fontWeight || '';
        span.style.removeProperty('color');
        span.style.removeProperty('font-size');
        span.style.removeProperty('width');
        title.style.removeProperty(styleVarSize);

        if (stateStyle.color) {
            span.style.setProperty('color', stateStyle.color, 'important');
        }

        if (stateStyle.size) {
            span.style.setProperty('font-size', stateStyle.size, 'important');
            span.style.setProperty('width', stateStyle.size, 'important');
        }
    }

    // Read the server-provided record used during preview hydration.
    function getBridgeRecordFromTitle(title) {
        var source;
        var encoded;
        var decoded;
        var record;

        if (!title || !title.closest) {
            return null;
        }

        source = title.closest('[data-divibooster-accordion-title-icon-record]');

        if (!source) {
            return null;
        }

        encoded = source.getAttribute('data-divibooster-accordion-title-icon-record') || '';

        if (!encoded) {
            return null;
        }

        try {
            decoded = decodeURIComponent(encoded);
            record = JSON.parse(decoded);
        } catch (e) {
            return null;
        }

        if (!record || !record.icon || !record.icon.character) {
            return null;
        }

        record.open = getIconStyle(record.open);
        record.closed = getIconStyle(record.closed || record.open);

        return record;
    }

    function renderPreviewIconsInDoc(doc) {
        var titles;

        if (!doc) {
            return;
        }

        titles = Array.prototype.slice.call(doc.querySelectorAll('.et_pb_accordion .et_pb_toggle_title, .et_pb_accordion_item .et_pb_toggle_title'));

        // Apply server-provided records before live preview updates.
        titles.forEach(function(title) {
            var bridgeRecord = getBridgeRecordFromTitle(title);

            if (bridgeRecord) {
                applyRecordToTitle(title, bridgeRecord, 'bridge');
            }
        });
    }

    // Refresh preview icons in the page and its iframe documents.
    function renderPreviewIcons() {
        renderPreviewIconsInDoc(document);

        Array.prototype.forEach.call(document.querySelectorAll('iframe'), function(iframe) {
            watchPreviewIframe(iframe);

            try {
                addPreviewCss(iframe.contentDocument);
                renderPreviewIconsInDoc(iframe.contentDocument);
            } catch (e) {}
        });
    }

    function toPlainPreviewValue(value) {
        if (!value || typeof value !== 'object') {
            return value;
        }

        try {
            if (typeof value.toJS === 'function') {
                return value.toJS();
            }

            if (typeof value.asMutable === 'function') {
                return value.asMutable({deep: true});
            }
        } catch (e) {}

        return value;
    }

    function hasPreviewAttr(source, key) {
        source = toPlainPreviewValue(source);

        if (!source || typeof source !== 'object') {
            return false;
        }

        if (Object.prototype.hasOwnProperty.call(source, key)) {
            return true;
        }

        if (source.attrs && typeof source.attrs === 'object' && Object.prototype.hasOwnProperty.call(source.attrs, key)) {
            return true;
        }

        if (source.attributes && typeof source.attributes === 'object' && Object.prototype.hasOwnProperty.call(source.attributes, key)) {
            return true;
        }

        if (source.module && typeof source.module === 'object' && Object.prototype.hasOwnProperty.call(source.module, key)) {
            return true;
        }

        return false;
    }

    // Normalize the module attributes supplied by the editor.
    function getPreviewRecordFromParam(param) {
        var attrs = toPlainPreviewValue(param && param.attrs ? param.attrs : {});

        return {
            attrs: attrs,
            record: buildRecord(attrs),
            hasIcon: hasPreviewAttr(attrs, attrTitleIcon)
        };
    }

    function getPreviewChildRecords(param, parentRecord) {
        var children = param && param.childrenAttrs ? toPlainPreviewValue(param.childrenAttrs) : null;
        var childRecords = [];
        var childValues = [];

        if (Array.isArray(children)) {
            childValues = children.slice(0, 200);
        } else if (children && typeof children === 'object') {
            Object.keys(children).slice(0, 200).forEach(function(key) {
                childValues.push(children[key]);
            });
        }

        childValues.forEach(function(child) {
            var attrs = toPlainPreviewValue(child && child.attrs ? child.attrs : child);
            var record = buildRecord(attrs);

            if (!record && hasPreviewAttr(attrs, attrClosedStyle)) {
                record = {
                    icon: null,
                    open: {},
                    closed: getIconStyle(getAttrValue(attrs, attrClosedStyle))
                };
            }

            if (record) {
                childRecords.push({
                    record: mergeRecord(parentRecord, record),
                    source: record.icon ? 'child' : 'parent'
                });
            } else {
                childRecords.push({
                    record: parentRecord,
                    source: 'parent'
                });
            }
        });

        return childRecords;
    }

    function createAccordionPreviewStyleElement(param, moduleName, attrs, moduleWrapper) {
        var WPElement = window.vendor && window.vendor.wp && window.vendor.wp.element;
        var StyleContainer = window.divi && window.divi.module && window.divi.module.StyleContainer;
        var moduleElements = param && param.elements ? param.elements : null;
        var orderClass = sanitizePreviewOrderClass(moduleElements && moduleElements.orderClass ? moduleElements.orderClass : '');
        var advancedStyles = [];
        var openAttr;
        var closedAttr;
        var isEdited;
        var moduleState;

        if (!WPElement || typeof WPElement.createElement !== 'function' || !StyleContainer || !moduleElements || typeof moduleElements.style !== 'function' || !orderClass) {
            return null;
        }

        openAttr = sanitizeIconStyleAttribute(getAttrValue(attrs, attrOpenStyle));
        closedAttr = sanitizeIconStyleAttribute(getAttrValue(attrs, attrClosedStyle));

        if (openAttr) {
            advancedStyles.push({
                componentName: 'divi/icon',
                props: {
                    selector: orderClass + ' .et_pb_toggle_open .et_pb_toggle_title > .' + iconClass + ', ' +
                        orderClass + '.et_pb_toggle_open .et_pb_toggle_title > .' + iconClass + ', ' +
                        orderClass + '.et_pb_accordion_item.et_pb_toggle_open .et_pb_toggle_title > .' + iconClass,
                    attr: openAttr
                }
            });
        }

        if (closedAttr) {
            advancedStyles.push({
                componentName: 'divi/icon',
                props: {
                    selector: orderClass + ' .et_pb_toggle_close .et_pb_toggle_title > .' + iconClass + ', ' +
                        orderClass + '.et_pb_toggle_close .et_pb_toggle_title > .' + iconClass + ', ' +
                        orderClass + '.et_pb_accordion_item.et_pb_toggle_close .et_pb_toggle_title > .' + iconClass,
                    attr: closedAttr
                }
            });
        }

        if (!advancedStyles.length) {
            return null;
        }

        isEdited = moduleWrapper && moduleWrapper.props ? moduleWrapper.props.isEdited : false;
        moduleState = param && param.state ? param.state : '';

        return WPElement.createElement(
            StyleContainer,
            {
                key: 'divibooster-accordion-title-icon-preview-styles-' + moduleName,
                mode: 'builder',
                state: isEdited ? moduleState : '',
                noStyleTag: false
            },
            moduleElements.style({
                attrName: 'module',
                styleProps: {
                    advancedStyles: advancedStyles
                }
            })
        );
    }

    function AccordionPreviewIconInjector(props) {
        var WPElement = window.vendor && window.vendor.wp && window.vendor.wp.element;
        var React = (window.vendor && window.vendor.React) || WPElement;
        var ref = React.useRef(null);

        React.useEffect(function() {
            var marker = ref.current;
            var root;
            var refreshTimers = {};
            var observers = [];

            if (!marker || !marker.closest) {
                return;
            }

            if (props.moduleName === {$accordion_item_slug}) {
                root = marker.closest('.et_pb_accordion_item, .et_pb_toggle');
            } else {
                root = marker.closest('.et_pb_accordion');
            }

            if (!root) {
                return;
            }

            function applyTitles() {
                var titles = Array.prototype.slice.call(root.querySelectorAll('.et_pb_toggle_title'));

                if (props.moduleName === {$accordion_item_slug}) {
                    titles = titles.slice(0, 1);
                }

                titles.forEach(function(title, index) {
                    var childEntry = props.moduleName === {$accordion_slug} && props.childRecords
                        ? props.childRecords[index]
                        : null;
                    var childRecord = childEntry && childEntry.record
                        ? childEntry.record
                        : childEntry;
                    var titleRecord = childRecord || props.record;
                    var titleSource = childRecord
                        ? (childEntry && childEntry.source ? childEntry.source : 'child')
                        : (props.moduleName === {$accordion_item_slug} ? 'child' : 'parent');

                    if (!props.hasIcon && props.moduleName === {$accordion_item_slug}) {
                        clearRecordFromTitle(title, titleSource);
                        return;
                    }

                    applyRecordToTitle(title, titleRecord, titleSource);
                });
            }

            applyTitles();

            function scheduleApplyTitles() {
                [0, 100, 750, 1500].forEach(function(delay) {
                    if (refreshTimers[delay]) {
                        return;
                    }

                    refreshTimers[delay] = window.setTimeout(function() {
                        refreshTimers[delay] = null;
                        applyTitles();
                    }, delay);
                });
            }

            function maybeScheduleApplyTitles(event) {
                var title = event.target && event.target.closest ? event.target.closest('.et_pb_toggle_title') : null;

                if (title && root.contains(title)) {
                    scheduleApplyTitles();
                }
            }

            root.addEventListener('click', maybeScheduleApplyTitles);
            root.addEventListener('keyup', maybeScheduleApplyTitles);

            if (typeof window.MutationObserver === 'function') {
                Array.prototype.slice.call(
                    root.matches && root.matches('.et_pb_accordion_item, .et_pb_toggle')
                        ? [root]
                        : root.querySelectorAll('.et_pb_accordion_item, .et_pb_toggle')
                ).forEach(function(item) {
                    var observer = new window.MutationObserver(scheduleApplyTitles);

                    observer.observe(item, {
                        attributes: true,
                        attributeFilter: ['class']
                    });

                    observers.push(observer);
                });
            }

            return function() {
                root.removeEventListener('click', maybeScheduleApplyTitles);
                root.removeEventListener('keyup', maybeScheduleApplyTitles);
                Object.keys(refreshTimers).forEach(function(delay) {
                    if (refreshTimers[delay]) {
                        window.clearTimeout(refreshTimers[delay]);
                    }
                });
                observers.forEach(function(observer) {
                    observer.disconnect();
                });
            };
        }, [JSON.stringify(props.record || {}), JSON.stringify(props.childRecords || []), props.hasIcon, props.moduleName]);

        return WPElement.createElement('span', {
            ref: ref,
            'aria-hidden': true,
            style: {display: 'none'}
        });
    }

    if (window.vendor && window.vendor.wp && window.vendor.wp.hooks &&
        typeof window.vendor.wp.hooks.addFilter === 'function' &&
        window.vendor.wp.element &&
        typeof window.vendor.wp.element.createElement === 'function' &&
        typeof window.vendor.wp.element.cloneElement === 'function') {
        window.vendor.wp.hooks.addFilter('divi.module.wrapper.render', 'divibooster/accordion-title-icon-render', function(moduleWrapper, param) {
            var moduleName = param && param.name ? param.name : '';
            var WPElement = window.vendor.wp.element;
            var React = (window.vendor && window.vendor.React) || WPElement;
            var previewData;
            var childRecords;
            var injector;
            var styleElement;
            var children;

            if (moduleName !== {$accordion_slug} && moduleName !== {$accordion_item_slug}) {
                return moduleWrapper;
            }

            if (!moduleWrapper || typeof moduleWrapper !== 'object' || !moduleWrapper.props || typeof moduleWrapper.props !== 'object') {
                return moduleWrapper;
            }

            if (!React || typeof React.useEffect !== 'function' || typeof React.useRef !== 'function') {
                return moduleWrapper;
            }

            previewData = getPreviewRecordFromParam(param);
            childRecords = moduleName === {$accordion_slug}
                ? getPreviewChildRecords(param, previewData.record)
                : [];
            injector = WPElement.createElement(AccordionPreviewIconInjector, {
                key: 'divibooster-accordion-title-icon-preview-injector',
                moduleName: moduleName,
                record: previewData.record,
                childRecords: childRecords,
                hasIcon: previewData.hasIcon
            });
            styleElement = createAccordionPreviewStyleElement(param, moduleName, previewData.attrs, moduleWrapper);
            children = moduleWrapper.props && moduleWrapper.props.children ? moduleWrapper.props.children : [];

            if (!Array.isArray(children)) {
                children = [children];
            }

            children = children.concat([injector]);

            if (styleElement) {
                children.push(styleElement);
            }

            return WPElement.cloneElement(moduleWrapper, {}, children);
        });
    }

    renderPreviewIcons();

    if (!window.vendor || !window.vendor.wp || !window.vendor.wp.hooks ||
        typeof window.vendor.wp.hooks.addFilter !== 'function' ||
        !window.lodash || typeof window.lodash.get !== 'function' || typeof window.lodash.set !== 'function') {
        return;
    }

    window.vendor.wp.hooks.addFilter('divi.moduleLibrary.moduleMapping', 'divibooster/accordion-title-icon', function(modules) {
        if (!modules || (typeof modules !== 'object' && typeof modules !== 'function')) {
            return modules;
        }

        var slugs = [{$accordion_slug}, {$accordion_item_slug}];
        var _ = window.lodash;

        slugs.forEach(function(slug) {
            var attrsPath  = [slug, 'metadata', 'attributes'];
            var groupsPath = [slug, 'metadata', 'settings', 'groups'];
            var attrs      = _.get(modules, attrsPath);
            var groups     = _.get(modules, groupsPath);

            if (!attrs || (typeof attrs !== 'object' && typeof attrs !== 'function')) {
                _.set(modules, attrsPath, {});
                attrs = _.get(modules, attrsPath);
            }

            attrs[{$attr_slug}]         = {$attribute};
            attrs[{$open_style_slug}]   = {$open_style_attr};
            attrs[{$closed_style_slug}] = {$closed_style_attr};

            if (!groups || (typeof groups !== 'object' && typeof groups !== 'function')) {
                _.set(modules, groupsPath, {});
                groups = _.get(modules, groupsPath);
            }

            groups[{$content_group_slug}] = {$content_group};
            groups[{$open_group_slug}]    = {$open_group};
            groups[{$closed_group_slug}]  = {$closed_group};
        });

        return modules;
    });
})();
JS;
}

function get_title_icon_attribute_definition() {
    $selector = get_title_icon_selector();

    return array(
        'type'      => 'object',
        'selector'  => $selector,
        'styleProps' => array(
            'icon' => array(
                'selector' => $selector,
                'important' => array(
                    'desktop' => array(
                        'value' => array(
                            'font-family' => true,
                            'font-size'   => true,
                            'content'     => true,
                            'font-weight' => true,
                        ),
                    ),
                ),
            ),
        ),
        'settings' => array(
            'innerContent' => array(
                'groupType' => 'group-items',
                'items'     => array(
                    'diviboosterTitleIcon' => array(
                        'groupSlug'   => CONTENT_GROUP_SLUG,
                        'attrName'    => ATTR_TITLE_ICON,
                        'label'       => __('Title Icon', 'divi-booster'),
                        'description' => __('Choose an icon to display to the left of the accordion title.', 'divi-booster'),
                        'priority'    => 10,
                        'render'      => true,
                        'features'    => array(
                            'hover'      => false,
                            'sticky'     => false,
                            'responsive' => false,
                            'preset'     => array('content', 'html'),
                        ),
                        'component' => array(
                            'type' => 'field',
                            'name' => 'divi/icon-picker',
                        ),
                    ),
                ),
            ),
        ),
    );
}

function get_visual_builder_title_icon_attribute_definition() {
    return apply_visual_builder_icon_selector(
        get_title_icon_attribute_definition(),
        get_visual_builder_icon_selector()
    );
}

function get_visual_builder_title_icon_style_attribute_definition($attr_name, $item_slug, $group_slug, $label, $selector, $has_default = true) {
    return apply_visual_builder_icon_selector(
        get_title_icon_style_attribute_definition($attr_name, $item_slug, $group_slug, $label, $has_default),
        $selector
    );
}

function apply_visual_builder_icon_selector($definition, $selector) {
    if (!is_array($definition) || !is_string($selector) || $selector === '') {
        return $definition;
    }

    $definition['selector'] = $selector;

    if (isset($definition['styleProps']) && is_array($definition['styleProps']) && isset($definition['styleProps']['icon']) && is_array($definition['styleProps']['icon'])) {
        $definition['styleProps']['icon']['selector'] = $selector;
    }

    return $definition;
}

function get_title_icon_selector() {
    return get_title_icon_selector_for_state();
}

function get_open_title_icon_selector() {
    return get_title_icon_selector_for_state('open');
}

function get_closed_title_icon_selector() {
    return get_title_icon_selector_for_state('close');
}

function get_title_icon_selector_for_state($state = '') {
    $state_class = $state === '' ? '' : '.et_pb_toggle_' . $state;

    return implode(', ', array(
        '{{selector}}' . ($state_class === '' ? '' : ' ' . $state_class) . ' .et_pb_toggle_title > .' . ICON_CLASS,
        '{{selector}}' . ($state_class === '' ? '.et_pb_toggle' : $state_class) . ' .et_pb_toggle_title > .' . ICON_CLASS,
        '{{selector}}.et_pb_accordion_item' . $state_class . ' .et_pb_toggle_title > .' . ICON_CLASS,
    ));
}

function get_visual_builder_icon_selector() {
    return get_title_icon_selector();
}

function get_visual_builder_open_icon_selector() {
    return get_open_title_icon_selector();
}

function get_visual_builder_closed_icon_selector() {
    return get_closed_title_icon_selector();
}

function get_visual_builder_preview_css() {
    return
        '.et_pb_toggle_title.' . TITLE_ACTIVE_CLASS . ':after{content:none!important;}' .
        '.et_pb_toggle_title.' . TITLE_ACTIVE_CLASS . '{display:flex;align-items:center;}' .
        '.et_pb_toggle_title:after{float:left;margin-right:.65em;display:inline-block;width:var(' . STYLE_VAR_SIZE . ',1em);font-size:var(' . STYLE_VAR_SIZE . ',1em);line-height:1;text-align:center;color:inherit;pointer-events:none;speak:never;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;}' .
        '.et_pb_toggle_title:after{font-family:ETmodules;}' .
        '.et_pb_toggle_title > .' . ICON_CLASS . '{display:inline-block;margin-right:.65em;width:var(' . STYLE_VAR_SIZE . ',1em);font-size:var(' . STYLE_VAR_SIZE . ',1em);line-height:1;text-align:center;color:inherit;pointer-events:none;speak:never;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;}';
}

function get_title_icon_style_attribute_definition($attr_name, $item_slug, $group_slug, $label, $has_default = true, $selector = '') {
    $selector = is_string($selector) && $selector !== '' ? $selector : get_title_icon_selector();

    $definition = array(
        'type'      => 'object',
        'selector'  => $selector,
        'styleProps' => array(
            'icon' => array(
                'selector' => $selector,
            ),
        ),
        'settings' => array(
            'decoration' => array(
                'icon' => array(
                    'groupType' => 'group-items',
                    'items'     => get_title_icon_style_items($attr_name, $item_slug, $group_slug, $label),
                ),
            ),
        ),
    );

    if ($has_default) {
        $definition['defaultAttr'] = array(
            'desktop' => array(
                'value' => array(
                    'useSize' => 'on',
                    'size'    => '1em',
                ),
            ),
        );
    }

    return $definition;
}

// Limit the style control to fields used by this feature.
function get_title_icon_style_component($label) {
    return array(
        'type'  => 'group',
        'name'  => 'divi/icon',
        'props' => array(
            'grouped'    => false,
            'groupLabel' => $label,
            'fieldLabel' => $label,
            'fields'     => array(
                'icon'      => array('render' => false),
                'color'     => array('render' => true),
                'useSize'   => array('render' => false),
                'size'      => array('render' => false),
                'placement' => array('render' => false),
                'alignment' => array('render' => false),
            ),
        ),
    );
}

// Build the color and size controls for an icon state.
function get_title_icon_style_items($attr_name, $item_slug, $group_slug, $label) {
    return array(
        $item_slug => array(
            'groupSlug' => $group_slug,
            'attrName'  => $attr_name,
            'priority'  => 10,
            'render'    => true,
            'component' => get_title_icon_style_component($label),
        ),
        $item_slug . 'Size' => array(
            'groupSlug' => $group_slug,
            'attrName'  => $attr_name,
            'subName'   => 'size',
            'label'     => sprintf(__('%s Size', 'divi-booster'), $label),
            'priority'  => 20,
            'render'    => true,
            'features'  => array(
                'hover'      => true,
                'sticky'     => true,
                'responsive' => true,
                'preset'     => array('style'),
            ),
            'component' => array(
                'type'  => 'field',
                'name'  => 'divi/range',
                'props' => array(
                    'cssProperty' => 'icon-font-size',
                    'defaultUnit' => 'px',
                    'min'         => 1,
                    'minLimit'    => 1,
                    'max'         => 120,
                ),
            ),
        ),
    );
}

// Add feature groups to the block metadata.
function add_title_icon_settings_groups($settings) {
    if (!is_array($settings)) {
        return $settings;
    }

    if (!isset($settings['settings']) || !is_array($settings['settings'])) {
        $settings['settings'] = array();
    }

    if (!isset($settings['settings']['groups']) || !is_array($settings['settings']['groups'])) {
        $settings['settings']['groups'] = array();
    }

    $settings['settings']['groups'][CONTENT_GROUP_SLUG] = get_content_group_definition();
    $settings['settings']['groups'][DESIGN_OPEN_GROUP_SLUG]   = get_design_group_definition(DESIGN_OPEN_GROUP_SLUG, __('Title Icon', 'divi-booster'), 21);
    $settings['settings']['groups'][DESIGN_CLOSED_GROUP_SLUG] = get_design_group_definition(DESIGN_CLOSED_GROUP_SLUG, __('Closed Title Icon', 'divi-booster'), 31);

    return $settings;
}

function get_content_group_definition() {
    return array(
        'panel'     => 'content',
        'priority'  => 11,
        'groupName' => CONTENT_GROUP_SLUG,
        'component' => array(
            'name'  => 'divi/composite',
            'props' => array(
                'groupLabel' => __('Title Icon', 'divi-booster'),
            ),
        ),
    );
}

function get_design_group_definition($group_slug, $label, $priority) {
    return array(
        'panel'     => 'design',
        'priority'  => $priority,
        'groupName' => $group_slug,
        'component' => array(
            'name'  => 'divi/composite',
            'props' => array(
                'groupLabel'  => $label,
                'presetGroup' => 'divi/icon',
            ),
        ),
    );
}

// === Block structure and markup ===
// Collect direct accordion item blocks for title-level inheritance.
function get_accordion_item_blocks($parsed_block) {
    $items = array();

    if (!is_array($parsed_block) || empty($parsed_block['innerBlocks']) || !is_array($parsed_block['innerBlocks'])) {
        return $items;
    }

    foreach ($parsed_block['innerBlocks'] as $inner_block) {
        if (isset($inner_block['blockName']) && $inner_block['blockName'] === DIVI5_ACCORDION_ITEM_SLUG) {
            $items[] = $inner_block;
        }
    }

    return $items;
}

// Add the first available icon when item rendering did not do so.
function inject_icon_into_first_title($content, $icon, $style_data) {
    $changed = false;
    $pattern = TITLE_HTML_PATTERN;

    $content = preg_replace_callback($pattern, function($matches) use ($icon, $style_data, &$changed) {
        if (!is_array($matches) || !isset($matches[0]) || !is_string($matches[0]) || !isset($matches[6]) || !is_string($matches[6])) {
            return is_array($matches) && isset($matches[0]) && is_string($matches[0]) ? $matches[0] : '';
        }

        if ($changed || strpos($matches[6], ICON_CLASS) !== false) {
            return $matches[0];
        }

        $changed = true;
        return build_title_html_with_icon($matches, $icon, $style_data);
    }, $content, 1);

    return array(
        'content' => is_string($content) ? $content : '',
        'changed' => $changed,
    );
}

// Rebuild the title element while preserving its existing attributes.
function build_title_html_with_icon($matches, $icon, $style_data) {
    if (!is_array($matches) ||
        !isset($matches[0], $matches[1], $matches[2], $matches[3], $matches[4], $matches[5], $matches[6]) ||
        !is_string($matches[0]) || !is_string($matches[1]) || !is_string($matches[2]) ||
        !is_string($matches[3]) || !is_string($matches[4]) || !is_string($matches[5]) ||
        !is_string($matches[6])) {
        return is_array($matches) && isset($matches[0]) && is_string($matches[0]) ? $matches[0] : '';
    }

    $level      = $matches[1];
    $before     = $matches[2];
    $quote      = $matches[3];
    $classes    = $matches[4];
    $after      = $matches[5];
    $inner_html = $matches[6];

    // The item render filter may already have added an icon before the parent
    // accordion render supplies the inherited icon and merged styles.
    $inner_html = remove_existing_title_icons($inner_html);

    $class_list = preg_split('/\s+/', trim($classes));

    if (!is_array($class_list)) {
        return $matches[0];
    }

    if (!in_array(TITLE_ACTIVE_CLASS, $class_list, true)) {
        $class_list[] = TITLE_ACTIVE_CLASS;
    }

    $icon_html = render_icon_html($icon, $style_data);

    if ($icon_html === '') {
        return $matches[0];
    }

    $opening = '<h' . $level . $before . 'class=' . $quote . esc_attr(trim(implode(' ', array_filter($class_list)))) . $quote . $after . '>';

    return $opening . $icon_html . $inner_html . '</h' . $level . '>';
}

// Remove previously injected feature icons before rebuilding a title.
function remove_existing_title_icons($inner_html) {
    if (!is_string($inner_html) || $inner_html === '') {
        return $inner_html;
    }

    $class = preg_quote(ICON_CLASS, '#');
    $pattern = '#<span\\b[^>]*\\bclass=("|\\\')[^"\\\']*\\b' . $class . '\\b[^"\\\']*\\1[^>]*>.*?</span>\\s*#is';
    $updated = preg_replace($pattern, '', $inner_html);

    return is_string($updated) ? $updated : $inner_html;
}

// Render a sanitized icon element for the title.
function render_icon_html($icon, $style_data) {
    if (!is_array($icon) || !isset($icon['type'], $icon['character']) || !is_scalar($icon['type']) || !is_scalar($icon['character'])) {
        return '';
    }

    $type      = (string) $icon['type'];
    $character = (string) $icon['character'];

    if (($type !== 'divi' && $type !== 'fa') || trim($character) === '') {
        return '';
    }

    $classes = array(ICON_CLASS);
    $styles  = array();

    if ($type === 'divi') {
        $classes[] = 'et-pb-icon';
        $styles[]  = 'font-family:ETmodules;';
    } else {
        $font_family = isset($icon['font_family']) && is_scalar($icon['font_family']) ? trim((string) $icon['font_family']) : 'FontAwesome';
        $font_weight = isset($icon['font_weight']) && is_scalar($icon['font_weight']) ? trim((string) $icon['font_weight']) : '900';

        if (!preg_match('/^[a-z0-9 _-]+$/i', $font_family)) {
            $font_family = 'FontAwesome';
        }

        if (!preg_match('/^(100|200|300|400|500|600|700|800|900)$/', $font_weight)) {
            $font_weight = '900';
        }

        $classes[] = 'divibooster-accordion-title-icon-fa';
        $styles[]  = 'font-family:' . ($font_family !== '' ? $font_family : 'FontAwesome') . ';';
        $styles[]  = 'font-weight:' . ($font_weight !== '' ? $font_weight : '900') . ';';
    }

    return sprintf(
        '<span class="%1$s" aria-hidden="true" style="%2$s">%3$s</span>',
        esc_attr(implode(' ', $classes)),
        esc_attr(implode('', $styles)),
        esc_html($character)
    );
}

// === Icon normalization ===
// Normalize stored icon settings for server-side rendering.
function normalize_icon($attr) {
    $metadata_type   = strtolower(extract_icon_meta_prop_from_attr($attr, 'type'));
    $metadata_type   = $metadata_type !== '' ? $metadata_type : strtolower(extract_icon_meta_prop_from_attr($attr, 'iconType'));
    $metadata_weight = extract_icon_meta_prop_from_attr($attr, 'weight');
    $metadata_family = strtolower(extract_icon_meta_prop_from_attr($attr, 'fontFamily'));

    if ($metadata_type === '' && $metadata_family === 'fontawesome') {
        $metadata_type = 'fa';
    }

    $value = get_desktop_value($attr);

    if (empty($value)) {
        return array();
    }

    $icon_value = '';
    $type       = 'divi';
    $font_weight = '900';
    $font_family = 'FontAwesome';

    if ($metadata_type !== '') {
        $type = $metadata_type;
    }

    if ($metadata_weight !== '') {
        $font_weight = $metadata_weight;
    }

    if (is_array($value)) {
        $extracted = extract_icon_value_from_attr($value);

        if (!empty($extracted['value'])) {
            $icon_value = $extracted['value'];

            if (!empty($extracted['source']) && is_array($extracted['source'])) {
                $value = $extracted['source'];
            }
        }

        if (isset($value['icon']) && is_array($value['icon'])) {
            $value = $value['icon'];
        }

        if ($icon_value === '' && isset($value['icon']) && is_string($value['icon'])) {
            $icon_value = $value['icon'];
        } elseif ($icon_value === '' && isset($value['unicode']) && is_string($value['unicode'])) {
            $icon_value = $value['unicode'];
        } elseif ($icon_value === '' && isset($value['value']) && is_string($value['value'])) {
            $icon_value = $value['value'];
        }

        if (isset($value['type']) && is_string($value['type'])) {
            $type = strtolower($value['type']);
        } elseif (isset($value['iconType']) && is_string($value['iconType'])) {
            $type = strtolower($value['iconType']);
        }

        if (isset($value['weight']) && is_scalar($value['weight'])) {
            $font_weight = preg_replace('/[^0-9]/', '', (string) $value['weight']);
        } elseif (isset($value['fontWeight']) && is_scalar($value['fontWeight'])) {
            $font_weight = preg_replace('/[^0-9]/', '', (string) $value['fontWeight']);
        }

        if (isset($value['style']) && $value['style'] === 'brands') {
            $type = 'fa-brands';
            $font_family = 'FontAwesome';
            $font_weight = '400';
        }
    } elseif (is_string($value)) {
        $icon_value = $value;

        if (strpos($value, '||') !== false) {
            $parts      = explode('||', $value);
            $icon_value = isset($parts[0]) ? $parts[0] : $value;

            foreach ($parts as $part) {
                $part = strtolower($part);
                if (strpos($part, 'fa') !== false) {
                    $type = 'fa';
                }
                if ($part === 'brands' || $part === 'fa-brands') {
                    $font_family = 'FontAwesome';
                    $font_weight = '400';
                }
                if ($part === 'regular' || $part === 'fa-regular') {
                    $font_weight = '400';
                }
            }
        }
    }

    $icon_value = trim((string) $icon_value);

    if ($icon_value === '' || $icon_value === 'none' || $icon_value === 'false') {
        return array();
    }

    if (strpos($type, 'fa') !== false || in_array($type, array('brands', 'regular', 'solid', 'fontawesome'), true)) {
        $character = decode_icon_character($icon_value, false);

        if ($font_weight === '' || !preg_match('/^(100|200|300|400|500|600|700|800|900)$/', (string) $font_weight)) {
            $font_weight = in_array($type, array('fab', 'fa-brands', 'brands', 'far', 'fa-regular', 'regular'), true) ? '400' : '900';
        }

        return array(
            'type'        => 'fa',
            'character'   => $character,
            'font_family' => $font_family,
            'font_weight' => $font_weight !== '' ? $font_weight : '900',
        );
    }

    $processed_icon = $icon_value;

    if (function_exists('et_pb_process_font_icon')) {
        try {
            $processed = \et_pb_process_font_icon($icon_value);

            if (is_string($processed) && $processed !== '') {
                $processed_icon = $processed;
            }
        } catch (\Throwable $e) {
            // Keep the unprocessed value if the Divi helper fails.
        }
    }

    return array(
        'type'      => 'divi',
        'character' => decode_icon_character($processed_icon, true),
    );
}

function extract_icon_meta_prop_from_attr($attr, $prop_name) {
    if (!is_array($attr) || !is_string($prop_name) || $prop_name === '') {
        return '';
    }

    if (array_key_exists($prop_name, $attr) && is_scalar($attr[$prop_name])) {
        $value = trim((string) $attr[$prop_name]);

        if ($value !== '') {
            return $value;
        }
    }

    foreach (array('value', 'desktop', 'tablet', 'phone', 'innerContent', 'iconPicker') as $key) {
        if (array_key_exists($key, $attr)) {
            $value = extract_icon_meta_prop_from_attr($attr[$key], $prop_name);

            if ($value !== '') {
                return $value;
            }
        }
    }

    foreach ($attr as $value) {
        $nested = extract_icon_meta_prop_from_attr($value, $prop_name);

        if ($nested !== '') {
            return $nested;
        }
    }

    return '';
}

function extract_icon_value_from_attr($attr) {
    $value = get_desktop_value($attr);

    if (is_string($value)) {
        return array(
            'value'  => $value,
            'source' => array(),
        );
    }

    if (!is_array($value)) {
        return array();
    }

    foreach (array('icon', 'unicode', 'char', 'code', 'value') as $key) {
        if (isset($value[$key]) && is_string($value[$key]) && trim($value[$key]) !== '') {
            return array(
                'value'  => $value[$key],
                'source' => $value,
            );
        }
    }

    foreach (array('innerContent', 'iconPicker', 'desktop', 'tablet', 'phone') as $key) {
        if (array_key_exists($key, $value)) {
            $nested = extract_icon_value_from_attr($value[$key]);

            if (!empty($nested['value'])) {
                if (empty($nested['source'])) {
                    $nested['source'] = $value;
                }

                return $nested;
            }
        }
    }

    foreach ($value as $nested_value) {
        $nested = extract_icon_value_from_attr($nested_value);

        if (!empty($nested['value'])) {
            if (empty($nested['source'])) {
                $nested['source'] = $value;
            }

            return $nested;
        }
    }

    return array();
}

function decode_icon_character($icon_value, $already_processed) {
    $icon_value = trim((string) $icon_value);

    if (!$already_processed && preg_match('/^\\\\u([0-9a-f]{4,6})$/i', $icon_value, $matches)) {
        $icon_value = $matches[1];
    }

    if (!$already_processed && preg_match('/^(?:U\+|0x)([0-9a-f]{3,6})$/i', $icon_value, $matches)) {
        $icon_value = $matches[1];
    }

    if (!$already_processed && preg_match('/^[a-f0-9]{3,6}$/i', $icon_value)) {
        $icon_value = '&#x' . $icon_value . ';';
    }

    return html_entity_decode($icon_value, ENT_QUOTES, 'UTF-8');
}

// === Icon styles ===
// Resolve open and closed styles, including the legacy icon fallback.
function get_icon_style_data_for_block($block) {
    $open_style   = get_icon_style_data(get_attr($block, ATTR_OPEN_ICON_STYLE));
    $closed_style = get_icon_style_data(get_attr($block, ATTR_CLOSED_ICON_STYLE));

    if (empty($open_style['color']) && empty($open_style['size'])) {
        $open_style = get_icon_style_data(get_attr($block, ATTR_TITLE_ICON));
    }

    $closed_style = merge_single_style_data($open_style, $closed_style);

    return array(
        'open'   => $open_style,
        'closed' => $closed_style,
    );
}

function get_icon_style_data($attr) {
    $data  = array(
        'color' => '',
        'size'  => '',
    );

    if (!is_array($attr)) {
        return $data;
    }

    $color = get_style_property($attr, 'color');
    $size  = get_style_property($attr, 'size');

    if ($color !== '') {
        $data['color'] = sanitize_css_color($color);
    }

    if ($size !== '') {
        $data['size'] = sanitize_css_length($size);
    }

    return $data;
}

function get_style_property($value, $property) {
    $preferred_keys = array('desktop', 'value', 'decoration', 'icon', 'tablet', 'phone', 'innerContent', 'iconPicker');

    if (!is_array($value) || !is_string($property) || $property === '') {
        return '';
    }

    if (array_key_exists($property, $value) && is_scalar($value[$property])) {
        return trim((string) $value[$property]);
    }

    foreach ($preferred_keys as $key) {
        if (array_key_exists($key, $value)) {
            $nested = get_style_property($value[$key], $property);

            if ($nested !== '') {
                return $nested;
            }
        }
    }

    foreach ($value as $key => $nested_value) {
        if (in_array($key, $preferred_keys, true)) {
            continue;
        }

        $nested = get_style_property($nested_value, $property);

        if ($nested !== '') {
            return $nested;
        }
    }

    return '';
}

function merge_style_data($parent, $child) {
    $parent = is_array($parent) ? $parent : array();
    $child  = is_array($child) ? $child : array();

    return array(
        'open'   => merge_single_style_data(
            isset($parent['open']) ? $parent['open'] : array(),
            isset($child['open']) ? $child['open'] : array()
        ),
        'closed' => merge_single_style_data(
            isset($parent['closed']) ? $parent['closed'] : array(),
            isset($child['closed']) ? $child['closed'] : array()
        ),
    );
}

function merge_single_style_data($parent, $child) {
    $parent = is_array($parent) ? $parent : array();
    $child  = is_array($child) ? $child : array();

    $merged = array_merge(
        array(
            'color' => '',
            'size'  => '',
        ),
        is_array($parent) ? $parent : array()
    );

    if (!empty($child['color'])) {
        $merged['color'] = $child['color'];
    }

    if (!empty($child['size'])) {
        $merged['size'] = $child['size'];
    }

    return $merged;
}

// === Block attribute helpers ===
// Read a feature attribute from the block's supported containers.
function get_attr($block, $slug) {
    if (!is_array($block) || !is_string($slug) || $slug === '') {
        return null;
    }

    $attrs = isset($block['attrs']) && is_array($block['attrs']) ? $block['attrs'] : array();

    if (array_key_exists($slug, $attrs)) {
        return $attrs[$slug];
    }

    if (isset($attrs['module']) && is_array($attrs['module']) && array_key_exists($slug, $attrs['module'])) {
        return $attrs['module'][$slug];
    }

    if (array_key_exists($slug, $block)) {
        return $block[$slug];
    }

    if (isset($block['module']) && is_array($block['module']) && array_key_exists($slug, $block['module'])) {
        return $block['module'][$slug];
    }

    return null;
}

// Prefer the desktop value when responsive data is present.
function get_desktop_value($attr) {
    if (is_array($attr) && isset($attr['desktop']) && is_array($attr['desktop']) && array_key_exists('value', $attr['desktop'])) {
        return $attr['desktop']['value'];
    }

    return $attr;
}

// === Frontend styles ===
// Load shared icon layout rules once.
function enqueue_frontend_base_styles() {
    static $base_added = false;

    if ($base_added || !function_exists('wp_register_style') || !function_exists('wp_enqueue_style') || !function_exists('wp_style_is')) {
        return;
    }

    if (!wp_style_is(FRONTEND_BASE_STYLES_HANDLE, 'registered')) {
        wp_register_style(FRONTEND_BASE_STYLES_HANDLE, false, array(), null);
    }

    wp_enqueue_style(FRONTEND_BASE_STYLES_HANDLE);

    if (!function_exists('wp_add_inline_style')) {
        return;
    }

    wp_add_inline_style(FRONTEND_BASE_STYLES_HANDLE, get_frontend_base_css());
    $base_added = true;
}

// Load generated styles and skip duplicate CSS.
function enqueue_frontend_styles($css = '') {
    static $css_added = array();

    if (!function_exists('wp_register_style') || !function_exists('wp_enqueue_style') || !function_exists('wp_style_is')) {
        return;
    }

    enqueue_frontend_base_styles();

    if (!wp_style_is(FRONTEND_STYLES_HANDLE, 'registered')) {
        wp_register_style(FRONTEND_STYLES_HANDLE, false, array(), null);
    }

    wp_enqueue_style(FRONTEND_STYLES_HANDLE);

    if (!function_exists('wp_add_inline_style')) {
        return;
    }

    if (!is_string($css) || $css === '') {
        return;
    }

    $css_key = md5($css);

    if (isset($css_added[$css_key])) {
        return;
    }

    wp_add_inline_style(FRONTEND_STYLES_HANDLE, $css);
    $css_added[$css_key] = true;
}

function get_frontend_base_css() {
    return
        '.et_pb_toggle_title.' . TITLE_ACTIVE_CLASS . '{position:relative;display:flex;align-items:center;padding-left:0!important;}' .
        '.et_pb_toggle_title > .' . ICON_CLASS . '{position:static;flex:0 0 var(' . STYLE_VAR_SIZE . ',1em);display:inline-block;width:var(' . STYLE_VAR_SIZE . ',1em);margin-left:0;margin-right:.65em;font-size:var(' . STYLE_VAR_SIZE . ',1em);line-height:1;text-align:center;color:inherit;pointer-events:none;speak:never;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;}';
}

// === Generated CSS ===
// Map rendered accordion items to their module order classes.
function get_accordion_item_order_classes($content) {
    $order_classes = array();

    if (!is_string($content) || $content === '') {
        return $order_classes;
    }

    if (!preg_match_all('/<div\b[^>]*\bclass=(["\'])(.*?)\1[^>]*>/is', $content, $matches)) {
        return $order_classes;
    }

    foreach ($matches[2] as $class_attr) {
        $classes = preg_split('/\s+/', trim($class_attr));

        if (!in_array('et_pb_accordion_item', $classes, true)) {
            continue;
        }

        $order_class = '';

        foreach ($classes as $class) {
            if (preg_match('/^et_pb_accordion_item_\d+(?:_tb_header|_tb_footer)?$/', $class)) {
                $order_class = $class;
                break;
            }
        }

        if ($order_class === '') {
            foreach ($classes as $class) {
                if (preg_match('/^et_pb_toggle_\d+(?:_tb_header|_tb_footer)?$/', $class)) {
                    $order_class = $class;
                    break;
                }
            }
        }

        $order_classes[] = $order_class !== '' ? sanitize_html_class($order_class) : '';
    }

    return $order_classes;
}

// Build state rules for each rendered accordion item.
function get_accordion_items_state_css($order_class, $item_style_records) {
    if (!is_string($order_class) || $order_class === '' || !is_array($item_style_records) || empty($item_style_records)) {
        return '';
    }

    $accordion_class = sanitize_html_class($order_class);

    if ($accordion_class === '') {
        return '';
    }

    $accordion_selector = '.' . $accordion_class;
    $css                = '';

    foreach ($item_style_records as $record) {
        if (!is_array($record) || !isset($record['order_class']) || !is_string($record['order_class'])) {
            continue;
        }

        $item_class = sanitize_html_class($record['order_class']);

        if ($item_class === '') {
            continue;
        }

        $style_data = isset($record['style_data']) && is_array($record['style_data'])
            ? $record['style_data']
            : array();
        $css .= get_icon_state_css($accordion_selector . ' .' . $item_class, $style_data);
    }

    if ($css === '') {
        return '';
    }

    return $css;
}

function get_icon_state_css($item_selector, $style_data) {
    return get_icon_state_rule($item_selector, 'et_pb_toggle_open', isset($style_data['open']) ? $style_data['open'] : array()) .
        get_icon_state_rule($item_selector, 'et_pb_toggle_close', isset($style_data['closed']) ? $style_data['closed'] : array());
}

function get_icon_state_rule($item_selector, $state_class, $style) {
    if (!is_string($item_selector) || $item_selector === '' || !is_string($state_class) || $state_class === '') {
        return '';
    }

    $state_class = sanitize_html_class($state_class);

    if (!is_string($state_class) || $state_class === '') {
        return '';
    }

    $declarations = get_icon_state_declarations($style);

    if ($declarations === '') {
        return '';
    }

    return $item_selector . '.' . $state_class . ' .et_pb_toggle_title > .' . ICON_CLASS . '{' . $declarations . '}';
}

function get_icon_state_declarations($style) {
    $declarations = '';

    if (!is_array($style)) {
        return '';
    }

    if (!empty($style['color'])) {
        $color = sanitize_css_color($style['color']);

        if ($color !== '') {
            $declarations .= 'color:' . $color . '!important;';
        }
    }

    if (!empty($style['size'])) {
        $size = sanitize_css_length($style['size']);

        if ($size !== '') {
            $declarations .= 'font-size:' . $size . '!important;width:' . $size . '!important;flex-basis:' . $size . '!important;';
        }
    }

    return $declarations;
}

// Find the module order class used to scope generated CSS.
function get_order_class_from_content($content, $module_class_prefix) {
    if (!preg_match_all('/class=(["\'])(.*?)\1/is', $content, $matches)) {
        return '';
    }

    foreach ($matches[2] as $class_attr) {
        $classes = preg_split('/\s+/', trim($class_attr));
        foreach ($classes as $class) {
            if (preg_match('/^' . preg_quote($module_class_prefix, '/') . '_\d+(?:_tb_header|_tb_footer)?$/', $class)) {
                return $class;
            }
        }
    }

    foreach ($matches[2] as $class_attr) {
        $classes = preg_split('/\s+/', trim($class_attr));
        foreach ($classes as $class) {
            if (strpos($class, $module_class_prefix . '_') === 0) {
                return sanitize_html_class($class);
            }
        }
    }

    return '';
}

// Accept only CSS value formats used by the icon controls.
function sanitize_css_color($value) {
    if (!is_scalar($value)) {
        return '';
    }

    $value = trim((string) $value);

    if ($value === '') {
        return '';
    }

    if (preg_match('/^(#[0-9a-f]{3,8}|rgba?\([0-9\s.,%]+\)|hsla?\([0-9\s.,%]+\)|var\(--[a-z0-9_-]+\)|[a-z]+)$/i', $value)) {
        return $value;
    }

    return '';
}

function sanitize_css_length($value) {
    if (!is_scalar($value)) {
        return '';
    }

    $value = trim((string) $value);

    if ($value === '') {
        return '';
    }

    if (preg_match('/^(?:-?\d+(?:\.\d+)?(?:px|em|rem|%|vw|vh|vmin|vmax)|calc\([a-z0-9\s+\-*\/.%,()]+\)|var\(--[a-z0-9_-]+\))$/i', $value)) {
        return $value;
    }

    return '';
}
