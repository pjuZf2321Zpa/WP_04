<?php
namespace DiviBooster\DiviBooster\Modules\Accordion\FaqSchema;

const DIVI5_MODULE_SLUG        = 'divi/accordion';
const DIVI5_CHILD_MODULE_SLUG  = 'divi/accordion-item';
const DIVI5_SETTING_SLUG       = 'diviboosterFaqSchema';
const DIVI5_GROUP_SLUG         = 'advancedSchema';
const DIVI5_EDITOR_SCRIPT      = 'divi-module-library';
const TEXT_DOMAIN              = 'divi-booster';

// === Module settings metadata ===

if (function_exists('add_filter')) {
    add_filter('block_type_metadata_settings', __NAMESPACE__ . '\\filter_divi5_block_settings', 10, 2);
}

// Add the FAQ schema setting to Accordion module metadata.
function filter_divi5_block_settings($settings, $metadata) {
    if (!is_array($settings) || !is_array($metadata)) {
        return $settings;
    }

    if (($metadata['name'] ?? '') !== DIVI5_MODULE_SLUG) {
        return $settings;
    }

    return array_replace_recursive($settings, [
        'attributes' => [
            DIVI5_SETTING_SLUG => get_d5_attribute_definition(),
            'module' => [
                'settings' => [
                    'advanced' => [
                        'schema' => get_d5_settings_item_definition(),
                    ],
                ],
            ],
        ],
        'settings' => [
            'groups' => [
                DIVI5_GROUP_SLUG => get_d5_settings_group_definition(),
            ],
        ],
    ]);
}

// Build the settings group shown under the Advanced panel.
function get_d5_settings_group_definition() {
    return [
        'panel'     => 'advanced',
        'priority'  => 25,
        'groupName' => DIVI5_GROUP_SLUG,
        'component' => [
            'name'  => 'divi/composite',
            'props' => [
                'groupLabel' => translate_text('Schema'),
            ],
        ],
    ];
}

// Define the saved on/off attribute for the module.
function get_d5_attribute_definition() {
    return [
        'type'    => 'object',
        'default' => [
            'desktop' => [
                'value' => 'off',
            ],
        ],
    ];
}

// Build the toggle field metadata for the settings UI.
function get_d5_settings_item_definition() {
    return [
        'groupType' => 'group-items',
        'items'     => [
            'diviboosterFaqSchemaToggle' => [
                'groupSlug'   => DIVI5_GROUP_SLUG,
                'attrName'    => DIVI5_SETTING_SLUG,
                'label'       => translate_text('Enable FAQ Schema'),
                'description' => translate_text('Output FAQPage JSON-LD schema for this accordion.'),
                'category'    => 'basic_option',
                'features'    => [
                    'hover'      => false,
                    'sticky'     => false,
                    'responsive' => false,
                    'preset'     => 'content',
                ],
                'render'      => true,
                'priority'    => 10,
                'defaultAttr' => [
                    'desktop' => [
                        'value' => 'off',
                    ],
                ],
                'component'   => [
                    'type' => 'field',
                    'name' => 'divi/toggle',
                ],
            ],
        ],
    ];
}

// === Visual Builder settings filters ===

if (function_exists('add_action')) {
    add_action('divi_visual_builder_assets_after_enqueue_app_window_scripts', __NAMESPACE__ . '\\enqueue_divi5_script');
}

// Attach editor metadata filters to the module library script.
function enqueue_divi5_script() {
    if (!function_exists('wp_script_is') || !function_exists('wp_add_inline_script')) {
        return;
    }

    if (!wp_script_is(DIVI5_EDITOR_SCRIPT, 'registered') && !wp_script_is(DIVI5_EDITOR_SCRIPT, 'enqueued')) {
        return;
    }

    $script = get_inline_js();
    if ($script === '') {
        return;
    }

    wp_add_inline_script(DIVI5_EDITOR_SCRIPT, $script, 'before');
}

// Generate the hook registrations used by the editor.
function get_inline_js() {
    static $inline_js = null;

    if ($inline_js !== null) {
        return $inline_js;
    }

    $attribute_json      = encode_for_js(get_d5_attribute_definition());
    $settings_item_json  = encode_for_js(get_d5_settings_item_definition());
    $settings_group_json = encode_for_js(get_d5_settings_group_definition());
    $divi5_slug          = encode_for_js(DIVI5_MODULE_SLUG);
    $divi5_group_slug    = encode_for_js(DIVI5_GROUP_SLUG);
    $divi5_setting_slug  = encode_for_js(DIVI5_SETTING_SLUG);
    $hook_slug           = encode_for_js(str_replace('/', '.', DIVI5_MODULE_SLUG));

    if (in_array('', [$attribute_json, $settings_item_json, $settings_group_json, $divi5_slug, $divi5_group_slug, $divi5_setting_slug, $hook_slug], true)) {
        return '';
    }

    $inline_js = <<<END
(function() {
    const addFilter = window.vendor?.wp?.hooks?.addFilter;
    if (!addFilter) {
        return;
    }

    const namespace = 'divibooster/accordion-faq-schema';
    const moduleName = {$divi5_slug};

    const addSchemaGroup = groups => ({
        ...(groups || {}),
        [{$divi5_group_slug}]: {$settings_group_json},
    });

    const addSchemaAttribute = attributes => ({
        ...(attributes || {}),
        [{$divi5_setting_slug}]: {$attribute_json},
        module: {
            ...(attributes?.module || {}),
            settings: {
                ...(attributes?.module?.settings || {}),
                advanced: {
                    ...(attributes?.module?.settings?.advanced || {}),
                    schema: {$settings_item_json},
                },
            },
        },
    });

    addFilter('divi.moduleLibrary.moduleSettings.groups', namespace, (groups, metadata) => (
        metadata?.name === moduleName ? addSchemaGroup(groups) : groups
    ));

    addFilter('divi.moduleLibrary.moduleAttributes', namespace, (attributes, metadata) => (
        metadata?.name === moduleName ? addSchemaAttribute(attributes) : attributes
    ));

    addFilter('divi.moduleLibrary.moduleSettings.groups.' + {$hook_slug}, namespace, addSchemaGroup);

    addFilter('divi.moduleLibrary.moduleAttributes.' + {$hook_slug}, namespace, addSchemaAttribute);
})();
END;

    return $inline_js;
}

// === Frontend schema output ===

if (function_exists('add_filter')) {
    add_filter('render_block_' . DIVI5_MODULE_SLUG, __NAMESPACE__ . '\\render_block_faq_schema', 10, 2);
}

// Append JSON-LD when schema output is enabled for this Accordion.
function render_block_faq_schema($block_content, $parsed_block) {
    if (!is_array($parsed_block)) {
        return $block_content;
    }

    $attrs   = isset($parsed_block['attrs']) && is_array($parsed_block['attrs']) ? $parsed_block['attrs'] : [];
    $setting = get_nested_value($attrs, [DIVI5_SETTING_SLUG, 'desktop', 'value'], 'off');

    if (!is_string($block_content) || $setting !== 'on') {
        return $block_content;
    }

    if (is_in_divi_builder()) {
        return $block_content;
    }

    $qa_pairs = extract_accordion_items_qa($parsed_block);

    if (empty($qa_pairs)) {
        return $block_content;
    }

    $json = build_faq_schema_json($qa_pairs);
    if ($json === '') {
        return $block_content;
    }

    return append_faq_script_tag($block_content, $json);
}

// === Rendering context ===

// Detect editor preview requests where schema markup should not be rendered.
function is_in_divi_builder() {
    return function_exists('et_core_is_fb_enabled') && \et_core_is_fb_enabled();
}

// === Accordion content extraction ===

// Pull FAQ question/answer pairs from Accordion Item blocks.
function extract_accordion_items_qa($parsed_block) {
    $qa_pairs = [];

    if (!is_array($parsed_block) || empty($parsed_block['innerBlocks']) || !is_array($parsed_block['innerBlocks'])) {
        return $qa_pairs;
    }

    foreach ($parsed_block['innerBlocks'] as $inner_block) {
        if (!is_array($inner_block)) {
            continue;
        }

        if (($inner_block['blockName'] ?? '') !== DIVI5_CHILD_MODULE_SLUG) {
            continue;
        }

        $attrs = $inner_block['attrs'] ?? [];
        if (!is_array($attrs)) {
            continue;
        }

        $qa = extract_question_answer_from_attrs($attrs);
        if ($qa !== null) {
            $qa_pairs[] = $qa;
        }
    }

    return $qa_pairs;
}

// Convert a single Accordion Item's attributes into a schema-ready pair.
function extract_question_answer_from_attrs(array $attrs) {
    $question = (string) get_nested_value($attrs, ['title', 'innerContent', 'desktop', 'value'], '');
    $answer   = (string) get_nested_value($attrs, ['content', 'innerContent', 'desktop', 'value'], '');

    $question = trim(strip_all_tags($question));
    $answer   = trim(allow_safe_html($answer));

    if ($question === '' || $answer === '') {
        return null;
    }

    return [
        'question' => $question,
        'answer'   => $answer,
    ];
}

// === Schema JSON ===

// Build FAQPage JSON-LD from question/answer pairs.
function build_faq_schema_json(array $qa_pairs) {
    if (empty($qa_pairs)) {
        return '';
    }

    $main_entity = [];

    foreach ($qa_pairs as $qa) {
        if (!is_array($qa)) {
            continue;
        }

        if (!isset($qa['question'], $qa['answer'])) {
            continue;
        }
        $q = trim(strip_all_tags((string) $qa['question']));
        $a = trim(allow_safe_html((string) $qa['answer']));
        if ($q === '' || $a === '') {
            continue;
        }

        $main_entity[] = [
            '@type' => 'Question',
            'name'  => $q,
            'acceptedAnswer' => [
                '@type' => 'Answer',
                'text'  => $a,
            ],
        ];
    }

    if (empty($main_entity)) {
        return '';
    }

    $schema = [
        '@context'   => 'https://schema.org',
        '@type'      => 'FAQPage',
        'mainEntity' => $main_entity,
    ];

    $json = encode_json($schema);

    return is_string($json) ? $json : '';
}

// === Schema script injection ===

// Append schema as inert JSON-LD after the module markup.
function append_faq_script_tag($content, $json) {
    if (!is_string($content) || !is_string($json) || $json === '') {
        return $content;
    }

    if (!function_exists('wp_get_inline_script_tag')) {
        return $content;
    }

    return $content . "\n" . wp_get_inline_script_tag($json, ['type' => 'application/ld+json']);
}

function translate_text($text) {
    return function_exists('__') ? __($text, TEXT_DOMAIN) : $text;
}

function strip_all_tags($html) {
    return function_exists('wp_strip_all_tags') ? wp_strip_all_tags($html) : strip_tags($html);
}

function allow_safe_html($html) {
    return function_exists('wp_kses_post') ? wp_kses_post($html) : strip_tags($html);
}

function encode_for_js($value) {
    $json = encode_json($value);

    return is_string($json) ? $json : '';
}

function encode_json($value) {
    $options = JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;

    if (function_exists('wp_json_encode')) {
        return wp_json_encode($value, $options);
    }

    return function_exists('json_encode') ? json_encode($value, $options) : false;
}

function get_nested_value(array $array, array $path, $default = null) {
    $value = $array;

    foreach ($path as $key) {
        if (!is_array($value) || !array_key_exists($key, $value)) {
            return $default;
        }

        $value = $value[$key];
    }

    return $value;
}
