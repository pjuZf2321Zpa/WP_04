<?php

namespace DiviBooster\DiviBooster\Modules\Accordion;

include_once(dirname(__FILE__) . '/features/closeable/closeable.php');

include_once(dirname(__FILE__) . '/features/initial-state/initial-state.php');

if (!is_plugin_active('accordion-module-faq-schema/accordion-module-faq-schema.php')) {
    include_once(dirname(__FILE__) . '/features/faq-schema/faq-schema.php');
}

if (!is_plugin_active('accordion-module-subtitles/accordion-module-subtitles.php')) {
    include_once(dirname(__FILE__) . '/features/accordion-item-subtitles/accordion-item-subtitles.php');
}

if (!is_plugin_active('accordion-module-title-icons/accordion-module-title-icons.php')) {
    include_once(dirname(__FILE__) . '/features/accordion-title-icons/accordion-title-icons.php');
}

if (!is_plugin_active('accordion-module-multi-open/accordion-module-multi-open.php')) {
    include_once(dirname(__FILE__) . '/features/accordion-module-multi-open/accordion-module-multi-open.php');
}