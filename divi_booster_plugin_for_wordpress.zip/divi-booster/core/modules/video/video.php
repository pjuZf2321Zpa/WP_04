<?php

namespace DiviBooster\DiviBooster\Modules\Video;

include_once(dirname(__FILE__) . '/features/youtube-limit-to-same-channel/youtube-limit-to-same-channel.php');
include_once(dirname(__FILE__) . '/features/youtube-autoplay/youtube-autoplay.php');
include_once(dirname(__FILE__) . '/features/youtube-mute/youtube-mute.php');
include_once(dirname(__FILE__) . '/features/youtube-toggle-controls/youtube-toggle-controls.php');
include_once(dirname(__FILE__) . '/features/youtube-loop/youtube-loop.php');