<?php

namespace DiviBooster\DiviBooster;


// === Add a filter to allow custom classes to be added to modules ===

if (function_exists('add_filter')) {
    \add_filter('et_module_shortcode_output', __NAMESPACE__ . '\\add_module_class_filter', 10, 3);
}

function add_module_class_filter($output, $render_slug, $module) {
    if (!is_string($output)) {
        return $output;
    }
    if (!isset($module->props) || !is_array($module->props)) {
        return $output;
    }
    $props = $module->props;

    // Add a filter for the classes
    $output = preg_replace_callback(
        '/class="([^"]*?et_pb_module ' . $render_slug . '(_\d+)?[^"]*?)"/',
        function ($matches) use ($props, $render_slug) {
            $classes = explode(' ', $matches[1]);
            $classes = \apply_filters("divi_booster/{$render_slug}/classes", $classes, $props);
            $classes = array_unique($classes);
            return 'class="' . implode(' ', $classes) . '"';
        },
        $output
    );

    return $output;
}
