<?php
namespace DiviBooster\DiviBooster\Settings;

if (!defined('ABSPATH')) { exit(); } // No direct access

add_action('db-settings-settings-box-before', 'submit_button');

add_action('db-settings-title-after', __NAMESPACE__.'\output_settings_nav_tabs'); // Applies to all plugins

function is_current_plugin_settings_page($plugin_slug) {
    $split_path = explode('/', plugin_basename(__FILE__));
    $current_plugin = array_shift($split_path);

    return $current_plugin === $plugin_slug;
}

function get_settings_tab_mode($plugin_slug) {
    return \apply_filters("db-settings-{$plugin_slug}-tab-mode", 'page');
}

function get_settings_tabs($plugin_slug) {
    return \apply_filters("db-settings-{$plugin_slug}-tabs", array());
}

function get_active_settings_tab($plugin_slug, $tabs = array()) {
    $active = \apply_filters("db-settings-{$plugin_slug}-active-tab", '');

    if (empty($tabs)) {
        $tabs = get_settings_tabs($plugin_slug);
    }

    if (empty($tabs)) {
        return '';
    }

    if (empty($active) || !isset($tabs[$active])) {
        $tab_keys = array_keys($tabs);
        $active = reset($tab_keys);
    }

    return $active;
}

function output_settings_nav_tabs($plugin_slug) {

    if (!is_current_plugin_settings_page($plugin_slug)) {
        return;
    }

    $tabs = get_settings_tabs($plugin_slug);
    if (empty($tabs)) {
        return;
    }

    $active = get_active_settings_tab($plugin_slug, $tabs);
    $tab_mode = get_settings_tab_mode($plugin_slug);

    ?>
    <ul
        id="db-settings-box-tabs"
        data-db-settings-plugin="<?php echo esc_attr($plugin_slug); ?>"
        data-db-settings-tab-mode="<?php echo esc_attr($tab_mode); ?>"
    >
    <?php
    foreach($tabs as $k=>$tab) {
        $panel_id = 'db-settings-tab-panel-' . sanitize_html_class($k);
        $href = !empty($tab['url']) ? $tab['url'] : '#' . $panel_id;
        printf(
            '<li class="db-settings-box-tab %s"><a href="%s" data-db-settings-tab="%s" data-db-settings-panel="%s">%s</a></li>',
            (($k===$active)?'db-settings-box-tab-active':''),
            esc_attr($href),
            esc_attr($k),
            esc_attr($panel_id),
            esc_html($tab['title'])
        );
    }
    ?>
    </ul>
<?php
}


add_action('admin_head', __NAMESPACE__.'\output_settings_css');


function output_settings_css() { ?>
    <style>
    #db-settings-box-title {
        background-color: white !important;
        padding: 14px 16px 13px 48px !important;
        position: relative;
        border-radius: 3px 3px 0 0;
        border-bottom: 1px solid var(--light-gray);
        font-size: 12px !important;
        margin: 0;
        font-weight: 600;
        font-size: 12px;
        color: var(--dark-gray);
        line-height: 18px;
    }
    .db-settings-wrap {
        --app-color: #326bff;
        --app-color-dark: #1959ff;
        --app-background: #fff;
        --gray: #586892;
        --medium-gray: #a2acc7;
        --light-gray: #d2d7e4;
        --feather-gray: #f2f3f7;
        --dark-gray: #222c39;
        --semidark-gray: #354559;
        --black: #222c39;
        --shadow-color: rgba(34, 44, 57, 0.08);
        --window-background: #f2f3f7;

        font-family: 'Inter', system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", "Noto Sans", "Liberation Sans", Arial, sans-serif;
        -webkit-font-smoothing: antialiased;
        border: none !important;
        border-radius: 3px;
        color: var(--dark-gray) !important;
        border: 1px solid var(--light-gray);
        margin: 20px 30px 30px 20px;
    }
    .db-settings-box-tab-content {
        background-color: white;
        border-collapse: initial;
        margin-top: 0;
        padding: 24px;
        font-size: 12px;
    }
    .db-settings-wrap[data-db-settings-tab-mode="panel"] .db-settings-tab-panel {
        display: none;
    }
    .db-settings-wrap[data-db-settings-tab-mode="panel"] .db-settings-tab-panel.db-settings-tab-panel-active {
        display: block;
    }
    .db-settings-box-tab-content-table {
        margin: 0px;
        font-size: 12px !important;
    }
    .db-settings-box-tab-content-table th {
        width: 22%;
        padding-top: 12px;
        padding-right: 20px;
        vertical-align: top;
        color: var(--dark-gray);
        font-weight: 500;
    }
    .db-settings-box-tab-content-table td {
        padding-top: 10px;
    }
    .db-settings-box-tab-content-table, .db-settings-box-tab-content-table td, .db-settings-box-tab-content-table td p, .db-settings-box-tab-content-table th {
        font-size: 12px !important;
    }
    #db-settings-box-tabs {
        background-color: white;
        padding: 0 7px !important;
        margin: 0;
        border-bottom: 1px solid var(--light-gray);
    }
    #db-settings-box-tabs .db-settings-box-tab {
        display: inline-block;
        margin-bottom:0;
    }
    #db-settings-box-tabs .db-settings-box-tab a {
        box-sizing: border-box;
        color: var(--gray);
        padding: 12px 16px;
        display: inline-block;
        outline: 0;
        font-size: 12px;
        line-height: 14px;
        border-bottom: 3px solid transparent;
        font-weight: 600;
        user-select: none;
        margin-bottom: -1px;
        z-index: 2;
        position: relative;
        transition: none;
        text-decoration: none;
    }
    #db-settings-box-tabs .db-settings-box-tab a:active,
    #db-settings-box-tabs .db-settings-box-tab a:focus,
    #db-settings-box-tabs .db-settings-box-tab-active a {
        color: var(--app-color-dark);
        border-color: var(--app-color-dark);
        box-shadow: none !important;
    }
    #db-settings-box-tabs .db-settings-box-tab:not(.db-settings-box-tab-active) a:hover {
        color: var(--app-color-dark);
    }
    .db-settings-wrap #submit {
        color: #FFF !important;
        cursor: pointer;
        background-color: var(--app-color) !important;
        -webkit-box-shadow: none;
        -moz-box-shadow: none;
        box-shadow: none;
        border: 1px solid var(--app-color);
        padding: 6px 12px;
        font-size: 12px;
        font-weight: 600;
        height: 32px;
        line-height: 12px;
        display: inline-block;
        text-decoration: none;
        -moz-border-radius: 3px;
        -webkit-border-radius: 3px;
        border-radius: 3px;
        position: relative;
        user-select: none;
    }
    .db-settings-wrap #db-settings-box {
        border: 1px solid var(--light-gray);
        box-shadow: 0 8px 24px 0px var(--shadow-color) !important;
    }
    #db-settings-box-title:before {
        content: ' ';
        width: 24px;
        background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAw3pUWHRSYXcgcHJvZmlsZSB0eXBlIGV4aWYAAHjabVBbDoMwDPvvKXaEJu4jPU4ZTNoNdvylTUCAsFTXiZFJE7bf9xNeA0wppFyltFKiIrXUuKuQaOiTKabJVuweXfvhMFhb0BtWSvHv9z4dAXZ1VfkUJG83lqvRkufLLch/hDERq1g9qHkQ2AzygG7PiqVJPT9h2eIVYicMQp3ZR8i9TlW3t2ZtgnkDISoDYgNgnBLQVdDkwkMNDWRlBvskupCnPe0If/IOWSIjSOiuAAABhWlDQ1BJQ0MgcHJvZmlsZQAAeJx9kbtLw1AUxr+makUqDnYQcQhSneyiRRxLFYtgobQVWnUwuekLmjQkKS6OgmvBwcdi1cHFWVcHV0EQfID4B4iToouUeG5SaBHjgcP98d3zHc49FxCaVaaaPTFA1SwjnYiLufyqGHiFD32U44hKzNSTmcUsPOPrniop7iK8l3fdnzGoFEwG+ETiGNMNi3iDeHbT0jnvE4dYWVKIz4mnDBqQ+JHrsstvnEsOC7xnyMim54lDxGKpi+UuZmVDJY4ShxVVo/5CzmWF8xZntVpn7Tn5C4MFbSXDdcoxJLCEJFIQIaOOCqqwEKFTI8VEmu7jHv5Rx58il0yuChg5FlCDCsnxg//B792axZlpt1MwDvS+2PbHBBDYBVoN2/4+tu3WCeB/Bq60jr/WBOY+SW90tPARMLQNXFx3NHkPuNwBRp50yZAcyU8pFIvA+xl9Ux4YvgUG1ty9te9x+gBkaVfLN8DBITBZot7rHu/u797bvzXt/f0ArSRyvm0Twn0AAA12aVRYdFhNTDpjb20uYWRvYmUueG1wAAAAAAA8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/Pgo8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJYTVAgQ29yZSA0LjQuMC1FeGl2MiI+CiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiCiAgICB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIKICAgIHhtbG5zOnN0RXZ0PSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VFdmVudCMiCiAgICB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iCiAgICB4bWxuczpHSU1QPSJodHRwOi8vd3d3LmdpbXAub3JnL3htcC8iCiAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyIKICAgIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIKICAgeG1wTU06RG9jdW1lbnRJRD0iZ2ltcDpkb2NpZDpnaW1wOjQ2MGE5ZWRhLTcwNmEtNGU4My1hZWViLTljZTk3ODhkOGFhYSIKICAgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpmOGQ0NjIwYy1jODI4LTQyNjYtYTcwOC05YTA2Yzg0YzdiZTciCiAgIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo4MTYxNzliYi1lNTU3LTRiZGMtYWM4ZC03MTU4OGU5YWZhMmQiCiAgIGRjOkZvcm1hdD0iaW1hZ2UvcG5nIgogICBHSU1QOkFQST0iMi4wIgogICBHSU1QOlBsYXRmb3JtPSJXaW5kb3dzIgogICBHSU1QOlRpbWVTdGFtcD0iMTc2NzY2MzMyMjk5NDI2MCIKICAgR0lNUDpWZXJzaW9uPSIyLjEwLjM4IgogICB0aWZmOk9yaWVudGF0aW9uPSIxIgogICB4bXA6Q3JlYXRvclRvb2w9IkdJTVAgMi4xMCIKICAgeG1wOk1ldGFkYXRhRGF0ZT0iMjAyNjowMTowNlQxMTozNToyMisxMDowMCIKICAgeG1wOk1vZGlmeURhdGU9IjIwMjY6MDE6MDZUMTE6MzU6MjIrMTA6MDAiPgogICA8eG1wTU06SGlzdG9yeT4KICAgIDxyZGY6U2VxPgogICAgIDxyZGY6bGkKICAgICAgc3RFdnQ6YWN0aW9uPSJzYXZlZCIKICAgICAgc3RFdnQ6Y2hhbmdlZD0iLyIKICAgICAgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDpjZDM0NmFhYS1kYjQ0LTQzNmItYmIxMS1kZGVmMTlkZjk4MzIiCiAgICAgIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkdpbXAgMi4xMCAoV2luZG93cykiCiAgICAgIHN0RXZ0OndoZW49IjIwMjYtMDEtMDZUMTE6MzU6MjIiLz4KICAgIDwvcmRmOlNlcT4KICAgPC94bXBNTTpIaXN0b3J5PgogIDwvcmRmOkRlc2NyaXB0aW9uPgogPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgIAo8P3hwYWNrZXQgZW5kPSJ3Ij8+X2T/QQAAAAZiS0dEAIsAkQDMUXZmoAAAAAlwSFlzAAALEwAACxMBAJqcGAAAAAd0SU1FB+oBBgEjFii/TC8AAAIiSURBVEjHndZdaI5hGAfw39bLZlq+iTFTxHYwapkDaahFOWHJAZIDhhONFDk1ihORk6XUcqg5Ekkp+TiQj5JysFoppFEjepePzMm1ejy99/vO/vXUc9/P9fW/ruu+7qdKZazDFjTEegVeYBAD+GyS2It+HMGy3Le6cHoRd7D+fwwvwVVsnaD8XFzBpXBcFktxHdMnwXgXbuedVOVo9+EQiolId2MKxvA99j4FY9iEk9iB0byBXsxJRHcU3ZiZYH04sz4Ttv7BhiiqEsU8G3WB5kQAe4LNuM69vOyxhGJPLqf7ytSuK7PuxgWojmc4oTiUqUcrHiXkhjMM4AZ2jjtowsuE4kjmvTUclkILPuT0htBSiI4YTChWR4qK+I3O2CvieYbdSjzO6b7G4mqsxa+EgwdhpB2b8Q538TDXyqvwNqc7DSMF3K9wgHqwBicSc2d2mRrWFyoMq3Mxaz6WkTuAa4n0zqouY7wLTyIdXxIyTfiacL4cz1IOCmjDrVj/KSFTEye4r8S3NrzJ1qUqJ7A909dz0VjCyGksTAR4HvvzFc+io8J4PhWntxSag3n9eCrE5JsXkxFqM/2fnUsHg+3lxMStw3HcxLdSqWnA+xDsxY8QbIxC90duU1iNjXH5lEQdFuRarWaCF05HFD154WSxKCIuVjBaG0Fsi4toIFhXdDCOGZGiqaE4lmvlTszH01TqqiZIvyYiHY3R0I6feFXpt+Uv2B1sdHK3ebYAAAAASUVORK5CYII=);
        height: 24px;
        display: block;
        background-size: contain;
        position: absolute;
        left: 15px;
        top: 11px;
    }

    </style>
<?php
}


add_action('admin_footer', __NAMESPACE__.'\output_settings_js');


function output_settings_js() { ?>
    <script>
    (function() {
        function shouldRememberTab(root) {
            return root.getAttribute('data-db-settings-remember-tab') !== 'false';
        }

        function getStorageKey(root) {
            return 'db-settings-active-tab-' + (root.getAttribute('data-db-settings-plugin') || '');
        }

        function getInitialTab(root, tabs) {
            var activeTab = root.getAttribute('data-db-settings-active-tab') || '';
            var hash = window.location.hash.replace(/^#/, '');
            var i;

            if (hash) {
                for (i = 0; i < tabs.length; i++) {
                    if (tabs[i].getAttribute('data-db-settings-panel') === hash) {
                        return tabs[i].getAttribute('data-db-settings-tab');
                    }
                }
            }

            if (shouldRememberTab(root)) {
                try {
                    activeTab = window.sessionStorage.getItem(getStorageKey(root)) || activeTab;
                } catch (e) {
                }
            }

            if (activeTab) {
                for (i = 0; i < tabs.length; i++) {
                    if (tabs[i].getAttribute('data-db-settings-tab') === activeTab) {
                        return activeTab;
                    }
                }
            }

            return tabs[0].getAttribute('data-db-settings-tab');
        }

        function setActiveTab(root, tabs, panels, activeTab, updateHash) {
            var hiddenField = root.querySelector('input[name="db_settings_active_tab"]');
            var i;

            for (i = 0; i < tabs.length; i++) {
                var tab = tabs[i];
                var isActive = tab.getAttribute('data-db-settings-tab') === activeTab;
                var tabItem = tab.parentNode;

                if (tabItem) {
                    tabItem.classList.toggle('db-settings-box-tab-active', isActive);
                }
            }

            for (i = 0; i < panels.length; i++) {
                var panel = panels[i];
                var isPanelActive = panel.getAttribute('data-db-settings-panel') === activeTab;
                panel.classList.toggle('db-settings-tab-panel-active', isPanelActive);
            }

            if (hiddenField) {
                hiddenField.value = activeTab;
            }

            root.setAttribute('data-db-settings-active-tab', activeTab);

            if (shouldRememberTab(root)) {
                try {
                    window.sessionStorage.setItem(getStorageKey(root), activeTab);
                } catch (e) {
                }
            } else {
                try {
                    window.sessionStorage.removeItem(getStorageKey(root));
                } catch (e) {
                }
            }

            if (updateHash) {
                var activePanelId = 'db-settings-tab-panel-' + activeTab;
                if (window.history && window.history.replaceState) {
                    window.history.replaceState(null, '', '#' + activePanelId);
                } else {
                    window.location.hash = activePanelId;
                }
            }
        }

        function initSettingsTabs(root) {
            if (!root || root.getAttribute('data-db-settings-tab-mode') !== 'panel') {
                return;
            }

            var tabs = root.querySelectorAll('#db-settings-box-tabs a[data-db-settings-tab]');
            var panels = root.querySelectorAll('.db-settings-tab-panel[data-db-settings-panel]');
            var initialTab;
            var i;

            if (!tabs.length || !panels.length) {
                return;
            }

            root.classList.add('db-settings-js-ready');
            initialTab = getInitialTab(root, tabs);
            setActiveTab(root, tabs, panels, initialTab, false);

            for (i = 0; i < tabs.length; i++) {
                tabs[i].addEventListener('click', function(event) {
                    event.preventDefault();
                    setActiveTab(
                        root,
                        tabs,
                        panels,
                        this.getAttribute('data-db-settings-tab'),
                        true
                    );
                });
            }
        }

        document.addEventListener('DOMContentLoaded', function() {
            var roots = document.querySelectorAll('.db-settings-wrap[data-db-settings-tab-mode="panel"]');
            var i;

            for (i = 0; i < roots.length; i++) {
                initSettingsTabs(roots[i]);
            }
        });
    })();
    </script>
<?php
}
