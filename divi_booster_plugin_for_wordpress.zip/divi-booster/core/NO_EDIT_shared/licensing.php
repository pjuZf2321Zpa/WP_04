<?php

namespace DiviBooster\DiviBooster\Licensing;

$licensing = new Licensing(
    $config['plugin_file'],
    $config['plugin_slug'],
    $config['plugin_name'],
    $config['plugin_url'],
    $config['edd_store_url'],
    $config['edd_item_id']
);
$licensing->init();

function license_allows_updates($plugin_slug) {
    if (get_option($plugin_slug . '-license_status') !== 'valid') {
        return false;
    }

    $details = get_option($plugin_slug . '-license_details', array());
    if (!is_array($details) || empty($details)) {
        return true;
    }

    if (!empty($details['error'])) {
        return false;
    }

    return license_expiry_is_valid($details);
}

function license_expiry_is_valid($details) {
    if (!is_array($details)) {
        return true;
    }

    if (empty($details['expires'])) {
        return true;
    }

    $expires = strtolower(trim((string) $details['expires']));
    if (in_array($expires, array('lifetime', 'never', 'none', 'unlimited'), true)) {
        return true;
    }

    $timestamp = !empty($details['expires_timestamp']) ? (int) $details['expires_timestamp'] : strtotime($details['expires']);
    return ($timestamp === false || $timestamp >= current_time('timestamp'));
}

class Licensing {

    private $plugin_name;
    private $settings_page;
    private $license_key_option;
    private $license_status_option;
    private $license_details_option;
    private $settings_fields;
    private $plugin_file;
    private $settings_nonce;
    private $plugin_url;
    private $store_url; // URL of site with EDD store
    private $store_item_id; // id of the plugin in EDD
    private $plugin_slug;

    public function __construct($plugin_file, $plugin_slug, $plugin_name, $plugin_url, $store_url, $store_item_id) {
        $this->plugin_file = $plugin_file;
        $this->plugin_slug = $plugin_slug;
        $this->plugin_name = $plugin_name;
        $this->plugin_url = $plugin_url;
        $this->store_url = $store_url;
        $this->store_item_id = $store_item_id;

        $this->settings_page = $this->plugin_slug . '-settings';
        $this->settings_fields = $this->plugin_slug . '-license';
        $this->license_key_option = $this->plugin_slug . '-license_key';
        $this->license_status_option = $this->plugin_slug . '-license_status';
        $this->license_details_option = $this->plugin_slug . '-license_details';
        $this->settings_nonce = $this->plugin_slug . '-nonce';
    }

    private function get_license_tracking_url($url, $area, $link_type) {
        $args = array(
            'utm_medium'   => 'product',
            'utm_source'   => str_replace('-', '_', strtolower($this->plugin_slug)),
            'utm_campaign' => 'licensing',
            'utm_content'  => $area . '_' . $link_type,
        );

        return add_query_arg($args, $url);
    }

    private function get_account_url($area) {
        return $this->get_license_tracking_url('https://divibooster.com/your-account/', $area, 'account_link');
    }

    private function get_product_url($area) {
        return $this->get_license_tracking_url($this->plugin_url, $area, 'product_link');
    }

    public function init() {
        add_action('admin_menu', array($this, 'dbal_license_menu'));
        add_filter("db-settings-{$this->plugin_slug}-tabs", array($this, 'register_settings_tab'), 11);
        add_action("db-{$this->plugin_slug}-updated", array($this, 'dbal_check_license'));
        add_action('admin_init', array($this, 'dbal_register_option'));
        add_action('admin_init', array($this, 'dbal_handle_settings_submission'), 11);
        add_action('admin_init', array($this, 'dbal_maybe_revalidate_license'), 20);
        add_action('admin_notices', array($this, 'dbal_admin_notices'), 0); // Register early
        add_action('admin_notices', array($this, 'hide_unrelated_admin_notices'), 1); // Hide all registered later
        add_action('after_plugin_row_' . plugin_basename($this->plugin_file), array($this, 'dbal_after_plugin_row'), 20, 3);
        add_action('admin_enqueue_scripts', array($this, 'dbal_enqueue_admin_styles'));
    }

    private function is_current_settings_page() {
        $page = isset($_GET['page']) && !is_array($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        return $page === $this->settings_page && $this->current_user_can_manage_settings();
    }

    private function current_user_can_manage_settings() {
        return function_exists('current_user_can') && current_user_can('manage_options');
    }

    private function is_plugins_screen() {
        global $pagenow;
        return $pagenow === 'plugins.php';
    }

    private function get_stored_effective_license_status() {
        $license = trim((string) get_option($this->license_key_option, ''));
        if ($license === '') {
            return false;
        }

        return $this->get_effective_license_status_from_details(
            get_option($this->license_status_option, false),
            $this->get_license_details()
        );
    }

    private function has_valid_license() {
        return $this->get_stored_effective_license_status() === 'valid';
    }

    function dbal_check_license() {
        $license = trim(get_option($this->license_key_option));
        if (empty($license)) {
            delete_option($this->license_status_option);
            delete_option($this->license_details_option);
        } else {
            $response = $this->dbal_submit_license('check', $license);
            if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
                $this->update_license_check_attempt_details($response);
                return;
            }
            $license_data = $this->decode_license_response($response);
            $status = $this->get_effective_license_status_from_data($license_data, get_option($this->license_status_option, false));

            if (!empty($status)) {
                update_option($this->license_status_option, $status);
                $this->update_license_details($license_data, $status);
            }
        }
    }

    private function update_license_check_attempt_details($response) {
        $details = $this->get_license_details();
        $details['checked_at'] = current_time('mysql');
        $details['checked_at_timestamp'] = current_time('timestamp');

        if (is_wp_error($response)) {
            $details['last_check_error'] = sanitize_text_field($response->get_error_message());
        } else {
            $details['last_check_error'] = sprintf(
                'HTTP %d',
                (int) wp_remote_retrieve_response_code($response)
            );
        }

        update_option($this->license_details_option, $details);
    }

    function dbal_maybe_revalidate_license() {
        $submitted_plugin = isset($_POST['db_settings_plugin']) && !is_array($_POST['db_settings_plugin']) ? sanitize_key(wp_unslash($_POST['db_settings_plugin'])) : '';
        if ($submitted_plugin === $this->plugin_slug) {
            return;
        }

        $license = trim((string) get_option($this->license_key_option, ''));
        if ($license === '') {
            return;
        }

        if (!$this->is_license_revalidation_context()) {
            return;
        }

        $details = $this->get_license_details();
        if (!$this->license_revalidation_due($details)) {
            return;
        }

        $this->dbal_check_license();
    }

    private function is_license_revalidation_context() {
        if (defined('DOING_CRON') && constant('DOING_CRON')) {
            return true;
        }

        if (!is_admin()) {
            return false;
        }

        if ($this->is_current_settings_page()) {
            return true;
        }

        global $pagenow;
        return in_array($pagenow, array('plugins.php', 'update-core.php', 'update.php'), true);
    }

    private function license_revalidation_due($details) {
        $last_checked = $this->get_license_last_checked_timestamp($details);

        if ($last_checked <= 0) {
            return true;
        }

        $interval = $this->get_license_revalidation_interval($details);
        return (current_time('timestamp') - $last_checked) >= $interval;
    }

    private function get_license_last_checked_timestamp($details) {
        if (!is_array($details)) {
            return 0;
        }

        if (!empty($details['checked_at_timestamp'])) {
            return (int) $details['checked_at_timestamp'];
        }

        if (!empty($details['checked_at'])) {
            $timestamp = strtotime($details['checked_at']);
            return ($timestamp !== false) ? $timestamp : 0;
        }

        return 0;
    }

    private function get_license_revalidation_interval($details) {
        $interval = DAY_IN_SECONDS;

        if ($this->is_current_settings_page()) {
            $interval = HOUR_IN_SECONDS;
        }

        if ($this->license_is_in_expiry_revalidation_window($details)) {
            $interval = min($interval, HOUR_IN_SECONDS);
        }

        return (int) apply_filters("db-settings-{$this->plugin_slug}-license-revalidation-interval", $interval, $details, $this);
    }

    private function license_is_in_expiry_revalidation_window($details) {
        if (!is_array($details) || empty($details['expires']) || $this->is_lifetime_expiry($details['expires'])) {
            return false;
        }

        $expires = !empty($details['expires_timestamp']) ? (int) $details['expires_timestamp'] : $this->get_license_expiry_timestamp($details['expires']);
        if ($expires === false || $expires <= 0) {
            return false;
        }

        return $expires <= (current_time('timestamp') + DAY_IN_SECONDS);
    }

    function hide_unrelated_admin_notices() {
        if ($this->is_current_settings_page()) {
            remove_all_actions('admin_notices');
        }
    }

    function dbal_license_menu() {
        add_options_page($this->plugin_name, $this->plugin_name, 'manage_options', $this->settings_page, array($this, 'dbal_license_page'));
    }

    function register_settings_tab($tabs) {
        if (!is_array($tabs)) {
            return $tabs;
        }
        $tabs['updates'] = array(
            'title' => 'Updates',
            'url' => $this->get_settings_page_url('updates'),
            'callback' => array($this, 'output_updates_settings_tab'),
        );
        return $tabs;
    }

    private function get_tab_mode() {
        return apply_filters("db-settings-{$this->plugin_slug}-tab-mode", 'page');
    }

    private function get_settings_tabs() {
        return apply_filters("db-settings-{$this->plugin_slug}-tabs", array());
    }

    private function get_active_tab($tabs = array()) {
        $active_tab = '';

        if (empty($tabs)) {
            $tabs = $this->get_settings_tabs();
        }

        if (empty($tabs)) {
            return '';
        }

        if (!empty($_GET['db_settings_tab'])) {
            $active_tab = sanitize_key(wp_unslash($_GET['db_settings_tab']));
        }

        if (empty($active_tab)) {
            $active_tab = apply_filters("db-settings-{$this->plugin_slug}-active-tab", 'updates');
        }

        if (empty($active_tab) || !isset($tabs[$active_tab])) {
            $tab_keys = array_keys($tabs);
            $active_tab = reset($tab_keys);
        }

        return $active_tab;
    }

    private function get_settings_page_url($tab = '') {
        $url = add_query_arg('page', $this->settings_page, admin_url('options-general.php'));

        if (!empty($tab)) {
            $url = add_query_arg('db_settings_tab', sanitize_key($tab), $url);
            $url .= '#db-settings-tab-panel-' . sanitize_html_class($tab);
        }

        return $url;
    }


    function dbal_license_page() {
        if (!$this->current_user_can_manage_settings()) {
            return;
        }

        $tabs = $this->get_settings_tabs();
        $active_tab = $this->get_active_tab($tabs);
        $tab_mode = $this->get_tab_mode();
?>
        <div
            class="db-settings-wrap"
            data-db-settings-plugin="<?php echo esc_attr($this->plugin_slug); ?>"
            data-db-settings-tab-mode="<?php echo esc_attr($tab_mode); ?>"
            data-db-settings-active-tab="<?php echo esc_attr($active_tab); ?>"
            data-db-settings-remember-tab="<?php echo apply_filters("db-settings-{$this->plugin_slug}-remember-active-tab", true) ? 'true' : 'false'; ?>"
        >
            <form method="post" action="<?php echo esc_url($this->get_settings_page_url()); ?>">

                <?php settings_fields($this->settings_fields); ?>
                <?php wp_nonce_field($this->settings_nonce, $this->settings_nonce); ?>
                <input type="hidden" name="db_settings_plugin" value="<?php echo esc_attr($this->plugin_slug); ?>" />
                <input type="hidden" name="db_settings_active_tab" value="<?php echo esc_attr($active_tab); ?>" />

                <?php do_action('db-settings-settings-box-before'); ?>
                <div id="db-settings-box">
                    <h1 id="db-settings-box-title"><?php echo esc_html($this->plugin_name); ?> Settings</h1>
                    <?php do_action('db-settings-title-after', $this->plugin_slug); ?>
                    <?php $this->output_settings_tabs($tabs, $active_tab, $tab_mode); ?>
                </div>
                <?php submit_button(); ?>

            </form>
            <?php
        }

        private function output_settings_tabs($tabs, $active_tab, $tab_mode) {
            if (empty($tabs)) {
                return;
            }

            if ('panel' === $tab_mode) {
                foreach ($tabs as $tab_slug => $tab) {
                    $this->output_settings_tab($tab_slug, $tab, $active_tab);
                }

                return;
            }

            if (!isset($tabs[$active_tab])) {
                $active_tab = 'updates';
            }

            $this->output_settings_tab($active_tab, $tabs[$active_tab], $active_tab);
        }

        private function output_settings_tab($tab_slug, $tab, $active_tab) {
            $classes = 'db-settings-box-tab-content db-settings-tab-panel';

            if ($tab_slug === $active_tab) {
                $classes .= ' db-settings-tab-panel-active';
            }
            ?>
            <div
                id="<?php echo esc_attr('db-settings-tab-panel-' . sanitize_html_class($tab_slug)); ?>"
                class="<?php echo esc_attr($classes); ?>"
                data-db-settings-panel="<?php echo esc_attr($tab_slug); ?>"
            >
                <?php
                if (!empty($tab['callback']) && is_callable($tab['callback'])) {
                    call_user_func($tab['callback'], $tab_slug, $tab, $this);
                } else {
                    do_action("db-settings-{$this->plugin_slug}-tab-content-{$tab_slug}", $tab_slug, $tab, $this);
                }
                ?>
            </div>
            <?php
        }

        private function decode_license_response($response) {
            if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
                return null;
            }

            $license_data = json_decode(wp_remote_retrieve_body($response));
            return is_object($license_data) ? $license_data : null;
        }

        private function get_license_status_from_data($license_data, $fallback = false) {
            if (is_object($license_data) && !empty($license_data->license)) {
                return sanitize_key($license_data->license);
            }

            if (is_object($license_data) && !empty($license_data->error)) {
                return sanitize_key($license_data->error);
            }

            return $fallback;
        }

        private function get_effective_license_status_from_data($license_data, $fallback = false) {
            $status = $this->get_license_status_from_data($license_data, $fallback);

            if ($status === 'valid') {
                if ($this->is_license_data_expired($license_data, $status)) {
                    return 'expired';
                }
            }

            return $status;
        }

        private function get_effective_license_status_from_details($status, $details) {
            if (!is_array($details)) {
                $details = array();
            }

            if (!empty($details['error'])) {
                return sanitize_key($details['error']);
            }

            if (!empty($details['status'])) {
                $status = sanitize_key($details['status']);
            }

            if ($status === 'valid') {
                if ($this->is_license_details_expired($details, $status)) {
                    return 'expired';
                }
            }

            return $status;
        }

        private function is_lifetime_expiry($expires) {
            $expires = strtolower(trim((string) $expires));

            return in_array($expires, array('lifetime', 'never', 'none', 'unlimited'), true);
        }

        private function get_license_expiry_timestamp($expires) {
            $expires = trim((string) $expires);

            if ($expires === '' || $this->is_lifetime_expiry($expires)) {
                return false;
            }

            $timestamp = strtotime($expires);
            return ($timestamp !== false) ? $timestamp : false;
        }

        private function format_license_expiry($expires) {
            $timestamp = $this->get_license_expiry_timestamp($expires);

            if ($timestamp === false) {
                return '';
            }

            return date_i18n(get_option('date_format'), $timestamp);
        }

        private function is_license_data_expired($license_data, $status = '') {
            if ($status === 'expired') {
                return true;
            }

            if (!is_object($license_data) || empty($license_data->expires) || $this->is_lifetime_expiry($license_data->expires)) {
                return false;
            }

            $timestamp = $this->get_license_expiry_timestamp($license_data->expires);
            return ($timestamp !== false && $timestamp < current_time('timestamp'));
        }

        private function is_license_details_expired($details, $status = '') {
            if ($status === 'expired') {
                return true;
            }

            if (!is_array($details)) {
                return false;
            }

            if (empty($details['expires']) || $this->is_lifetime_expiry($details['expires'])) {
                return false;
            }

            $timestamp = !empty($details['expires_timestamp']) ? (int) $details['expires_timestamp'] : $this->get_license_expiry_timestamp($details['expires']);
            return ($timestamp !== false && $timestamp < current_time('timestamp'));
        }

        private function get_license_details() {
            $details = get_option($this->license_details_option, array());

            return is_array($details) ? $details : array();
        }

        private function update_license_details($license_data, $status) {
            $details = array(
                'status' => sanitize_key($status),
                'checked_at' => current_time('mysql'),
                'checked_at_timestamp' => current_time('timestamp'),
            );

            if (is_object($license_data)) {
                if (isset($license_data->success)) {
                    $details['success'] = (bool) $license_data->success;
                }

                $fields = array(
                    'license',
                    'error',
                    'expires',
                    'item_id',
                    'item_name',
                    'payment_id',
                    'customer_name',
                    'customer_email',
                    'license_limit',
                    'site_count',
                    'activations_left',
                    'price_id',
                    'subscription_id',
                    'subscription_status',
                    'subscription_period',
                    'subscription_renewal_date',
                    'renewal_date',
                    'cancelled_at',
                    'canceled_at',
                );

                foreach ($fields as $field) {
                    if (isset($license_data->{$field}) && is_scalar($license_data->{$field})) {
                        $details[$field] = sanitize_text_field((string) $license_data->{$field});
                    }
                }

                if (!empty($license_data->expires) && $this->is_lifetime_expiry($license_data->expires)) {
                    $details['is_lifetime'] = true;
                } elseif (!empty($license_data->expires)) {
                    $details['expires_formatted'] = $this->format_license_expiry($license_data->expires);
                    $expires_timestamp = $this->get_license_expiry_timestamp($license_data->expires);
                    if ($expires_timestamp !== false) {
                        $details['expires_timestamp'] = $expires_timestamp;
                    }
                }
            }

            update_option($this->license_details_option, $details);
        }

        private function get_license_period_message($details, $status) {
            if (!$this->should_display_license_period($status, $details)) {
                return '';
            }

            if (!empty($details['is_lifetime']) || (!empty($details['expires']) && $this->is_lifetime_expiry($details['expires']))) {
                return __('License period: lifetime.');
            }

            $expires = !empty($details['expires']) ? $details['expires'] : '';
            $expires_formatted = !empty($details['expires_formatted']) ? $details['expires_formatted'] : $this->format_license_expiry($expires);

            if ($expires_formatted === '') {
                return '';
            }

            if ($status === 'expired') {
                return sprintf(__('License period ended on %s.'), $expires_formatted);
            }

            return sprintf(__('License period: valid through %s.'), $expires_formatted);
        }

        private function should_display_license_period($status, $details) {
            if (!is_array($details)) {
                $details = array();
            }

            $error = !empty($details['error']) ? sanitize_key($details['error']) : '';
            if ($error !== '') {
                $status = $error;
            }

            return in_array($status, array('valid', 'expired'), true);
        }

        private function get_license_status_label($status, $error = '') {
            if ($error !== '') {
                $status = $error;
            }

            switch ($status) {
                case 'valid':
                    return __('Active');
                case 'pending':
                    return __('Pending');
                case 'expired':
                    return __('Expired');
                case 'completed':
                    return __('Completed');
                case 'failed':
                    return __('Payment failed');
                case 'canceled':
                case 'cancelled':
                    return __('Canceled');
                case 'deactivated':
                case 'inactive':
                case 'site_inactive':
                    return __('Inactive');
                case 'revoked':
                case 'disabled':
                    return __('Disabled');
                case 'no_activations_left':
                    return __('Activation limit reached');
                case 'invalid_item_id':
                case 'item_name_mismatch':
                    return __('Wrong plugin');
                case 'missing':
                case 'invalid':
                    return __('Invalid');
                default:
                    return __('Inactive');
            }
        }

        private function get_license_status_class($status, $error = '') {
            $classes = array('db-license-status');

            if ($status === 'valid' && $error === '') {
                $classes[] = 'db-license-status-active';
            } else {
                $classes[] = 'db-license-status-error';
            }

            return implode(' ', $classes);
        }

        private function get_license_help_messages($status, $details, $has_license) {
            if (!is_array($details)) {
                $details = array();
            }

            $messages = array();
            $error = !empty($details['error']) ? sanitize_key($details['error']) : '';
            $has_checked_license = !empty($details['checked_at']) || !empty($details['license']) || !empty($details['status']);

            if (!$has_license) {
                $messages[] = '<strong>' . esc_html__('Updates are currently disabled.') . '</strong> ' . esc_html__('Enter your license key to receive plugin updates.');
                return $messages;
            }

            if ($error !== '') {
                $status = $error;
            }

            switch ($status) {
                case 'valid':
                    $messages[] = '<strong>' . esc_html__('Updates are enabled.') . '</strong>';
                    break;
                case 'pending':
                    $messages[] = '<strong>' . esc_html__('Updates are currently disabled.') . '</strong> ' . esc_html__('This license is pending payment verification.');
                    break;
                case 'expired':
                    $messages[] = '<strong>' . esc_html__('Updates are currently disabled.') . '</strong> ' . esc_html__('This license period has ended.');
                    break;
                case 'completed':
                    $messages[] = '<strong>' . esc_html__('Updates are currently disabled.') . '</strong> ' . esc_html__('This license period has completed.');
                    break;
                case 'failed':
                    $messages[] = '<strong>' . esc_html__('Updates are currently disabled.') . '</strong> ' . esc_html__('This license payment could not be verified.');
                    break;
                case 'canceled':
                case 'cancelled':
                    $messages[] = '<strong>' . esc_html__('Updates are currently disabled.') . '</strong> ' . esc_html__('This license has been canceled.');
                    break;
                case 'deactivated':
                    $messages[] = '<strong>' . esc_html__('Updates are currently disabled.') . '</strong> ' . esc_html__('This license was deactivated on this site. Save changes to activate it again.');
                    break;
                case 'inactive':
                case 'site_inactive':
                    if ($has_checked_license) {
                        $messages[] = '<strong>' . esc_html__('Updates are currently disabled.') . '</strong> ' . esc_html__('This license is valid, but has not been activated for this site yet. Save changes to activate it.');
                    } else {
                        $messages[] = '<strong>' . esc_html__('Updates are currently disabled.') . '</strong> ' . esc_html__('Save changes to activate this license key and enable updates.');
                    }
                    break;
                case 'revoked':
                case 'disabled':
                    $messages[] = '<strong>' . esc_html__('Updates are currently disabled.') . '</strong> ' . esc_html__('This license key has been disabled.');
                    break;
                case 'no_activations_left':
                    $messages[] = '<strong>' . esc_html__('Updates are currently disabled.') . '</strong> ' . esc_html__('This license key has reached its activation limit for active sites.');
                    break;
                case 'invalid_item_id':
                    $messages[] = '<strong>' . esc_html__('Updates are currently disabled.') . '</strong> ' . esc_html(sprintf(__('This license key is for a different Divi Booster plugin. Please use a license key for %s.'), $this->plugin_name));
                    break;
                case 'item_name_mismatch':
                    $messages[] = '<strong>' . esc_html__('Updates are currently disabled.') . '</strong> ' . esc_html(sprintf(__('This appears to be an invalid license key for %s.'), $this->plugin_name));
                    break;
                case 'missing':
                case 'invalid':
                default:
                    $messages[] = '<strong>' . esc_html__('Updates are currently disabled.') . '</strong> ' . esc_html__('The entered license key could not be validated.');
                    break;
            }

            $period_message = $this->get_license_period_message($details, $status);
            if ($period_message !== '') {
                $messages[] = esc_html($period_message);
            }

            return $messages;
        }

        private function get_new_tab_screen_reader_text() {
            return '<span class="screen-reader-text"> ' . esc_html__('opens in a new tab') . '</span>';
        }

        private function get_external_link($url, $text) {
            return sprintf(
                '<a href="%s" target="_blank" rel="noopener noreferrer">%s%s</a>',
                esc_url($url),
                esc_html($text),
                $this->get_new_tab_screen_reader_text()
            );
        }

        private function get_id_attribute($id) {
            return $id !== '' ? ' id="' . esc_attr($id) . '"' : '';
        }

        private function output_license_cta_paragraph($message, $paragraph_id = '') {
            ?>
            <p<?php echo $this->get_id_attribute($paragraph_id); ?>><?php echo $message; ?></p>
            <?php
        }

        private function output_license_cta($status, $has_license, $paragraph_id = '') {
            $account_url = $this->get_account_url('settings');
            $product_url = $this->get_product_url('settings');
            $account_link = $this->get_external_link($account_url, 'Divi Booster account');

            if (!$has_license) {
                $this->output_license_cta_paragraph(sprintf(
                    'You can find your license key in your %s, or %s.',
                    $account_link,
                    $this->get_external_link($product_url, 'get a license here')
                ), $paragraph_id);
                return;
            }

            if ($status === 'valid') {
                $this->output_license_cta_paragraph(sprintf(
                    'You can manage this license in your %s.',
                    $account_link
                ), $paragraph_id);
                return;
            }

            if ($status === 'no_activations_left') {
                $this->output_license_cta_paragraph(sprintf(
                    'You can free up an activation by deactivating this license on another site in your %s, or %s.',
                    $account_link,
                    $this->get_external_link($product_url, 'get an additional license here')
                ), $paragraph_id);
                return;
            }

            if (in_array($status, array('inactive', 'site_inactive'), true)) {
                $this->output_license_cta_paragraph(sprintf(
                    'If activation still fails, manage this license in your %s, or %s.',
                    $account_link,
                    $this->get_external_link($product_url, 'get a new license here')
                ), $paragraph_id);
                return;
            }

            $this->output_license_cta_paragraph(sprintf(
                'You can renew or manage this license in your %s, or %s.',
                $account_link,
                $this->get_external_link($product_url, 'get a new license here')
            ), $paragraph_id);
        }

        private function get_license_field_ids($message_count) {
            $field_id = $this->license_key_option;
            $ids = array(
                'field' => $field_id,
                'status' => $field_id . '-status',
                'cta' => $field_id . '-cta',
                'messages' => array(),
            );

            for ($index = 0; $index < $message_count; $index++) {
                $ids['messages'][] = $field_id . '-message-' . $index;
            }

            $ids['described_by'] = array_merge(array($ids['status']), $ids['messages'], array($ids['cta']));

            return $ids;
        }

        public function output_updates_settings_tab() {
            $license = get_option($this->license_key_option);
            $status  = get_option($this->license_status_option, false);
            $details = $this->get_license_details();
            $has_license = trim((string) $license) !== '';
            if (!$has_license) {
                $status = false;
                $details = array();
            } else {
                $status = $this->get_effective_license_status_from_details($status, $details);
            }
            $error = !empty($details['error']) ? sanitize_key($details['error']) : '';
            if ($status !== 'valid') {
                $error = '';
            }
            $status_label = $this->get_license_status_label($status, $error);
            $status_class = $this->get_license_status_class($status, $error);
            $messages = $this->get_license_help_messages($status, $details, $has_license);
            $field_ids = $this->get_license_field_ids(count($messages));
            ?>
            <table class="db-settings-box-tab-content-table form-table">
                <tbody>
                    <tr valign="top">
                        <th scope="row" valign="top">
                            <label for="<?php echo esc_attr($field_ids['field']); ?>"><?php esc_html_e('License Key'); ?></label>
                        </th>
                        <td>
                            <input id="<?php echo esc_attr($field_ids['field']); ?>" name="<?php echo esc_attr($this->license_key_option); ?>" type="password" class="regular-text" value="<?php echo esc_attr($license); ?>" aria-describedby="<?php echo esc_attr(implode(' ', $field_ids['described_by'])); ?>" />
                            <?php if ($status !== false && $status == 'valid') { ?>
                                <input type="submit" class="button-secondary" name="edd_license_deactivate" value="<?php esc_attr_e('Deactivate'); ?>" aria-label="<?php echo esc_attr(sprintf(__('Deactivate license for %s'), $this->plugin_name)); ?>" />
                            <?php } ?>
                            <span id="<?php echo esc_attr($field_ids['status']); ?>" class="<?php echo esc_attr($status_class); ?>" role="status" aria-live="polite"><?php echo esc_html($status_label); ?></span>
                            <?php foreach ($messages as $index => $message) { ?>
                                <p id="<?php echo esc_attr($field_ids['messages'][$index]); ?>"><?php echo $message; ?></p>
                            <?php } ?>
                            <?php $this->output_license_cta($status, $has_license, $field_ids['cta']); ?>
                        </td>
                    </tr>
                </tbody>
            </table>
            <?php
        }

        // === Register the license key option ===

        function dbal_register_option() {
            // creates our settings in the options table
            register_setting($this->settings_fields, $this->license_key_option, array($this, 'dbal_sanitize_license'));
            do_action("db-settings-{$this->plugin_slug}-register-settings", $this->settings_fields, $this);
        }

        function dbal_sanitize_license($new) {
            $old = get_option($this->license_key_option);
            if ($old && $old != $new) {
                delete_option($this->license_status_option); // new license has been entered, so must reactivate
                delete_option($this->license_details_option);
            }
            return $new;
        }

        function dbal_handle_settings_submission() {
            $submitted_plugin = isset($_POST['db_settings_plugin']) && !is_array($_POST['db_settings_plugin']) ? sanitize_key(wp_unslash($_POST['db_settings_plugin'])) : '';
            if ($submitted_plugin !== $this->plugin_slug) {
                return;
            }

            if (!$this->current_user_can_manage_settings()) {
                return;
            }

            if (!check_admin_referer($this->settings_nonce, $this->settings_nonce)) {
                return;
            }

            $license = isset($_POST[$this->license_key_option]) && !is_array($_POST[$this->license_key_option]) ? sanitize_text_field(wp_unslash($_POST[$this->license_key_option])) : '';
            $license = strtolower(trim($license));
            $submitted_active_tab = isset($_POST['db_settings_active_tab']) && !is_array($_POST['db_settings_active_tab']) ? sanitize_key(wp_unslash($_POST['db_settings_active_tab'])) : '';

            update_option($this->license_key_option, $this->dbal_sanitize_license($license));
            do_action("db-settings-{$this->plugin_slug}-save-settings", wp_unslash($_POST), $this->settings_fields, $this);

            if (isset($_POST['edd_license_deactivate'])) {
                $this->handle_license_deactivation($license);
                return;
            }

            if ($submitted_active_tab !== 'updates') {
                wp_safe_redirect($this->get_settings_page_url());
                exit();
            }

            if ($license === '') {
                delete_option($this->license_status_option);
                delete_option($this->license_details_option);
                wp_safe_redirect($this->get_settings_page_url());
                exit();
            }

            $this->handle_license_activation($license);
        }

        private function handle_license_activation($license) {
            $response = $this->dbal_submit_license('activate', $license);
            $message = $this->activation_error($response);
            $license_data = $this->decode_license_response($response);

            if (!empty($message)) {
                $status = $this->get_effective_license_status_from_data($license_data, 'invalid');
                update_option($this->license_status_option, $status);
                $this->update_license_details($license_data, $status);

                $redirect = add_query_arg(array('sl_activation' => 'false', 'plugin' => $this->plugin_slug, 'message' => urlencode($message)), $this->get_settings_page_url('updates'));
                wp_safe_redirect($redirect);
                exit();
            }

            if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) !== 200) {
                $validity = 'valid';
            } else {
                $validity = $this->get_effective_license_status_from_data($license_data, 'valid');
            }

            update_option($this->license_status_option, $validity);
            $this->update_license_details($license_data, $validity);

            wp_safe_redirect($this->get_settings_page_url('updates'));
            exit();
        }

        private function handle_license_deactivation($license) {
            if ($license !== '' && !$this->dbal_license_deactivated_in_edd($license)) {
                $this->dbal_submit_license('deactivate', $license);
            }

            update_option($this->license_status_option, 'deactivated');
            $this->update_license_details(null, 'deactivated');
            wp_safe_redirect($this->get_settings_page_url('updates'));
            exit();
        }

        // Return the activation error, if any, from the given response / WP_Error object
        public function activation_error($response) {
            $message = '';
            if (is_wp_error($response)) {
                $message =  ($response->get_error_message() !== '') ? $response->get_error_message() : __('An error occurred while connecting to the license server, please try again.');
                $message .= ($response->get_error_code() !== '') ? ' (Error code ' . $response->get_error_code() . ')' : '';
            } elseif (wp_remote_retrieve_response_code($response) !== 200) {
                $message = ''; // If license server not responding correctly, allow license to validate locally instead of throwing an error
            } else {
                $license_data = $this->decode_license_response($response);
                if (is_object($license_data) && isset($license_data->success) && false === $license_data->success) {
                    $error = !empty($license_data->error) ? $license_data->error : 'invalid';
                    if (!$this->license_error_is_displayed_inline($error)) {
                        $message = __('An error occurred, please try again. (error code: ' . esc_html($error) . ')');
                    }
                }
            }
            return $message;
        }

        private function license_error_is_displayed_inline($error) {
            return in_array($error, array(
                'expired',
                'revoked',
                'disabled',
                'missing',
                'invalid_item_id',
                'invalid',
                'site_inactive',
                'item_name_mismatch',
                'no_activations_left',
                'pending',
                'completed',
                'failed',
                'canceled',
                'cancelled',
            ), true);
        }

        function dbal_license_deactivated_in_edd($license) {
            $deactivated = false;
            $response = $this->dbal_submit_license('check', $license);
            if (!is_wp_error($response)) {
                $license_data = $this->decode_license_response($response);
                $status = $this->get_effective_license_status_from_data($license_data, '');
                if ($status !== '') {
                    $this->update_license_details($license_data, $status);
                }
                if ($status === 'inactive') {
                    $deactivated = true;
                }
            }
            return $deactivated;
        }

        function dbal_submit_license($action, $license) {
            $request_args = array(
                'timeout' => apply_filters("db-settings-{$this->plugin_slug}-license-timeout", 60, $action, $license, $this),
                'body' => array(
                    'edd_action' => $action . '_license',
                    'license'    => $license,
                    'item_id'    => $this->store_item_id,
                    'url'        => home_url()
                )
            );

            $request_args = apply_filters("db-settings-{$this->plugin_slug}-license-request-args", $request_args, $action, $license, $this);

            $result = wp_remote_post(
                $this->store_url,
                $request_args
            );
            return $result;
        }

        // === Display license activation / deactivation errors to user ===


        function dbal_admin_notices() {
            if (!$this->is_current_settings_page()) {
                return;
            }
            $plugin = isset($_GET['plugin']) && !is_array($_GET['plugin']) ? sanitize_key(wp_unslash($_GET['plugin'])) : '';
            if ($plugin !== $this->plugin_slug) {
                return;
            }
            $this->output_error_notice_from_request('sl_activation');
            $this->output_error_notice_from_request('sl_deactivation', 'Error: ');
        }

        private function output_error_notice_from_request($result_key, $prefix = '') {
            $result = isset($_GET[$result_key]) && !is_array($_GET[$result_key]) ? sanitize_key(wp_unslash($_GET[$result_key])) : '';
            if ($result !== 'false' || empty($_GET['message']) || is_array($_GET['message'])) {
                return;
            }

            $this->output_error_notice(sanitize_text_field(wp_unslash($_GET['message'])), $prefix);
        }

        private function output_error_notice($message, $prefix = '') {
            ?>
            <div class="notice notice-error" role="alert">
                <p><?php echo esc_html($prefix . $message); ?></p>
            </div>
            <?php
        }

        // === Notify admin via plugins.php that license required to activate plugin ===


        function dbal_after_plugin_row($plugin_file, $plugin_data, $status) {

            // Don't display message if the plugin is correctly licensed
            if ($this->has_valid_license()) {
                return;
            }

            // Display license message
            $settings_url = $this->get_settings_page_url('updates');
            $account_link = $this->get_external_link($this->get_account_url('plugins'), 'Divi Booster account');
            $product_link = $this->get_external_link($this->get_product_url('plugins'), 'get a license here');
            ?>
            <tr class="plugin-update-tr active db-license-required-tr">
                <td colspan="4" class="plugin-update colspanchange">
                    <div class="update-message notice inline notice-warning notice-alt" role="status">
                        <p><strong>Updates are currently disabled.</strong> Enter your license key on the <a href="<?php echo esc_url($settings_url); ?>">settings page</a> to receive plugin updates. You can find your license in your <?php echo $account_link; ?>, or <?php echo $product_link; ?>.</p>
                    </div>
                </td>
            </tr>
        <?php
        }


        function dbal_enqueue_admin_styles() {
            $styles = array();

            if ($this->is_current_settings_page()) {
                $styles[] = $this->get_license_settings_styles();
            }

            if ($this->is_plugins_screen() && !$this->has_valid_license()) {
                $styles[] = $this->get_plugins_screen_license_styles();
            }

            $styles = array_filter($styles);
            if (empty($styles)) {
                return;
            }

            $handle = 'db-license-admin-' . sanitize_key($this->plugin_slug);
            wp_register_style($handle, false, array(), false);
            wp_enqueue_style($handle);
            wp_add_inline_style($handle, implode("\n", $styles));
        }

        private function get_license_settings_styles() {
            return '
                .db-license-status {
                    line-height: 28px;
                    margin-right: 1em;
                    margin-left: 1em;
                    font-weight: 600;
                }
                .db-license-status-active {
                    color: green;
                }
                .db-license-status-error {
                    color: #b32d2e;
                }
            ';
        }

        private function get_plugins_screen_license_styles() {
            $plugin_basename = addcslashes(plugin_basename($this->plugin_file), "\\\"");
            $plugin_selector = '.plugins tr[data-plugin="' . $plugin_basename . '"]';

            return "
                {$plugin_selector} td,
                {$plugin_selector} th {
                    box-shadow: none !important;
                    border-bottom: 0 !important;
                }
                {$plugin_selector} + .db-license-required-tr td {
                    box-shadow: none !important;
                    border-top: 0 !important;
                }
                {$plugin_selector} + .db-license-required-tr .plugin-update {
                    box-shadow: inset 0 -1px 0 rgba(0, 0, 0, .1) !important;
                    border-top: 0 !important;
                }
            ";
        }
    }
