<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="oceanwp-mb-desc">
	<# if ( data.label ) { #>
		<span class="butterbean-label">{{ data.label }}</span>
	<# } #>

	<# if ( data.description ) { #>
		<span class="butterbean-description">{{{ data.description }}}</span>
	<# } #>
</div>

<div class="oceanwp-mb-field">
	<input type="hidden" class="butterbean-attachment-id" name="{{ data.field_name }}" value="{{ data.value }}" />

	<# if ( data.src ) { #>
		<img class="butterbean-img" src="{{ data.src }}" alt="{{ data.alt }}" />
	<# } else { #>
		<div class="butterbean-placeholder">{{ data.l10n.placeholder }}</div>
	<# } #>

	<p>
		<# if ( data.src ) { #>
			<button type="button" class="button button-secondary butterbean-change-media">{{ data.l10n.change }}</button>
			<button type="button" class="button button-secondary butterbean-remove-media">{{ data.l10n.remove }}</button>
		<# } else { #>
			<button type="button" class="button button-secondary butterbean-add-media">{{ data.l10n.upload }}</button>
		<# } #>
	</p>
</div>