<?php
/**
 * Masteriyo bricks integration addon setup.
 *
 * @package Masteriyo\Addons\BricksIntegration
 *
 * @since 1.9.0
 */

namespace Masteriyo\Addons\BricksIntegration;

use Bricks\Templates;

defined( 'ABSPATH' ) || exit;

/**
 * Main Masteriyo bricks integration class.
 *
 * @class Masteriyo\Addons\BricksIntegration\BricksIntegrationAddon
 */
class BricksIntegrationAddon {
	/**
	 * Initialize module.
	 *
	 * @since 1.9.0
	 */
	public function init() {
		$this->init_hooks();
	}

	/**
	 * Initialize hooks.
	 *
	 * @since 1.9.0
	 */
	public function init_hooks() {
		add_action(
			'init',
			array( $this, 'register_bricks_elements' ),
			11
		);
		add_filter( 'bricks/builder/first_element_category', array( $this, 'set_masteriyo_as_first_element_category' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'restrict_panel_elements_by_template_type' ), 9 );
		add_filter(
			'bricks/builder/i18n',
			function( $i18n ) {
				$i18n['masteriyo'] = esc_html( masteriyo_get_plugin_name() );

				return $i18n;
			}
		);
		add_filter(
			'bricks/setup/control_options',
			array( $this, 'add_masteriyo_course_template_type' )
		);
		add_filter( 'masteriyo_localized_admin_scripts', array( $this, 'add_backend_script_data' ) );
		add_action( 'masteriyo_single_course_page_custom_template_render', array( $this, 'render_single_course_page_template' ), 10, 2 );
		add_action( 'init', array( $this, 'create_template_on_bricks_page' ) );
		add_action( 'masteriyo_course_archive_page_custom_template_render', array( $this, 'render_course_archive_page_template' ), 10, 2 );
		add_action( 'masteriyo_single_course_after_template_content_bricks', 'masteriyo_single_course_modals', 10 );
		add_action( 'masteriyo_course_archive_after_template_content_bricks', 'masteriyo_single_course_modals', 10 );
		add_filter( 'masteriyo_enqueue_public_styles', array( $this, 'enqueue_public_styles_on_bricks_preview' ) );
	}

	/**
	 * Ensure Masteriyo public styles load while Bricks renders a template preview.
	 *
	 * The core detector (masteriyo_is_masteriyo_public_page) only recognises the
	 * Bricks builder (?bricks=run), not the frontend preview (?bricks_preview=)
	 * or a rendered Bricks template. Masteriyo Bricks elements are saved by name
	 * (e.g. "courses"), so the content scan can't detect them either, leaving the
	 * course cards unstyled in preview. This hooks the extensibility filter to
	 * enqueue public.css in those Bricks preview contexts.
	 *
	 * @param bool $enqueue Whether to enqueue Masteriyo public styles.
	 *
	 * @return bool
	 */
	public function enqueue_public_styles_on_bricks_preview( $enqueue ) {
		if ( $enqueue ) {
			return $enqueue;
		}

		if ( isset( $_GET['bricks_preview'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return true;
		}

		if ( class_exists( '\Bricks\Helpers' ) && \Bricks\Helpers::is_bricks_preview() ) {
			return true;
		}

		return $enqueue;
	}


	/**
	 * Render custom template for the Course Archive page.
	 *
	 * @since 2.12.0
	 *
	 * @param string $template_source
	 * @param integer $template_id
	 */
	public function render_course_archive_page_template( $template_source, $template_id ) {
		if ( 'bricks' !== $template_source ) {
			return;
		}

		masteriyo_display_all_notices();
		echo ( new Templates() )->render_shortcode( array( 'id' => $template_id ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		do_action( 'masteriyo_course_archive_after_template_content_bricks' );
	}

	/**
	 * create a template on bricks page
	 *
	 * @since 2.12.0
	 */
	public function create_template_on_bricks_page() {
		// Check if the current page is one of the Bricks Builder pages
		if ( isset( $_SERVER['REQUEST_URI'] ) && ( masteriyo_is_current_user_admin() || masteriyo_is_current_user_manager() ) ) {
			$url             = $_SERVER['REQUEST_URI'];
			$bricks_keywords = array(
				'?page=bricks',
				'edit.php?post_type=bricks_template',
				'?page=bricks-settings',
				'bricks-custom-fonts',
				'?post_type=bricks_fonts',
				'?page=bricks-sidebars',
				'?page=bricks-system-information',
				'?page=bricks-license',
			);

			foreach ( $bricks_keywords as $keyword ) {
				if ( strpos( $url, $keyword ) !== false ) {
					// Create the template
					Helper::create_single_course_bricks_template_if_not_exists();
					Helper::create_course_archive_bricks_template_if_not_exists();
					break;
				}
			}
		}
	}

	/**
	 * Render custom template for the Single Course page.
	 *
	 * @since 2.12.0
	 *
	 * @param string $template_source
	 * @param integer $template_id
	 */
	public function render_single_course_page_template( $template_source, $template_id ) {
		if ( 'bricks' !== $template_source ) {
			return;
		}
		masteriyo_display_all_notices();
		echo ( new Templates() )->render_shortcode( array( 'id' => $template_id ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		do_action( 'masteriyo_single_course_after_template_content_bricks' );
	}

	/**
	 * Add custom template for the Course page Type.
	 *
	 * @since 2.12.0
	 *
	 * @param string $template_source
	 * @param integer $template_id
	 */
	public function add_masteriyo_course_template_type( $control_options ) {
		Helper::masteriyo_single_course_listing_template();
		$control_options['templateTypes']['masteriyo-single-course'] = esc_html(
			sprintf(
				/* translators: %s: the product's name */
				__( '%s Single Course', 'learning-management-system' ),
				masteriyo_get_plugin_name()
			)
		);
		$control_options['templateTypes']['masteriyo-course-archive'] = esc_html(
			sprintf(
				/* translators: %s: the product's name */
				__( '%s Course Archive', 'learning-management-system' ),
				masteriyo_get_plugin_name()
			)
		);
		return $control_options;

	}


	/**
	 * Localize more data to the backend script.
	 *
	 * @since 2.12.0
	 *
	 * @param array $script_data
	 *
	 * @return array
	 */
	public function add_backend_script_data( $script_data ) {
		$script_data['backend']['data']['singleCourseTemplates']['bricks']  = Helper::masteriyo_single_course_listing_template();
		$script_data['backend']['data']['courseArchiveTemplates']['bricks'] = Helper::masteriyo_course_archive_template();
		return $script_data;
	}

	public function register_bricks_elements() {
		$element_files = array(
			__DIR__ . '/Elements/CourseCategoriesElement.php',
			__DIR__ . '/Elements/CoursesElement.php',
			__DIR__ . '/Elements/CourseFeaturedImageElement.php',
			__DIR__ . '/Elements/CourseTitleElement.php',
			__DIR__ . '/Elements/CategoriesOfCourseElement.php',
			__DIR__ . '/Elements/CourseButtonElement.php',
			__DIR__ . '/Elements/CourseHighlightsElement.php',
			__DIR__ . '/Elements/CourseRatingElement.php',
			__DIR__ . '/Elements/CourseContentElement.php',
			__DIR__ . '/Elements/CourseOverviewElement.php',
			__DIR__ . '/Elements/CourseCurriculumElement.php',
			__DIR__ . '/Elements/CourseReviewsElement.php',
			__DIR__ . '/Elements/CoursesSearchElement.php',
			__DIR__ . '/Elements/CourseAvatarElement.php',
			__DIR__ . '/Elements/CourseStatsElement.php',
			__DIR__ . '/Elements/CoursePriceElement.php',
			__DIR__ . '/Elements/CourseArchiveViewModeElement.php',
			__DIR__ . '/Elements/CourseRetakeElement.php',
			__DIR__ . '/Elements/CourseGoogleClassroomCodeNButton.php',
		);
		foreach ( $element_files as $file ) {
			\Bricks\Elements::register_element( $file );
		}

	}

	/**
	 * Show the Masteriyo category expanded at the top of the builder's elements panel.
	 *
	 * @param string|false $category Category slug to show first, or false to use Bricks' own default.
	 * @return string
	 */
	public function set_masteriyo_as_first_element_category( $category ) {
		return 'masteriyo';
	}

	/**
	 * Restrict the Masteriyo elements offered in the builder panel to the ones
	 * relevant to the template type currently being edited: a Single Course
	 * template only offers single-course elements, a Course Archive template
	 * only offers listing/archive elements. Any other template or page is left
	 * untouched so it can freely mix both.
	 *
	 * Runs before Bricks' own `enqueue_scripts` (priority 10) so the trimmed
	 * registry is what gets sent to the panel. Elements already placed on a
	 * page are loaded separately (on the earlier `wp` hook) and are unaffected.
	 */
	public function restrict_panel_elements_by_template_type() {
		if ( ! bricks_is_builder() || ! class_exists( '\Bricks\Elements' ) ) {
			return;
		}

		$post_id       = get_queried_object_id();
		$template_type = $post_id ? get_post_meta( $post_id, '_bricks_template_type', true ) : '';

		$archive_element_names = array(
			'course-categories',
			'courses',
			'single_search_courses',
			'course_archive_view_mode',
		);

		$single_course_element_names = array(
			'single_course_featured_image',
			'single_course_title',
			'masteriyo-course--content__category',
			'single_course_button',
			'single_course_highlights',
			'single_course_ratings',
			'single_course_contents',
			'single_course_overview',
			'single_course_curriculum',
			'single_course_reviews',
			'single_course_author',
			'single_course_stats',
			'single_course_price',
			'single_course_retake',
			'single_course_google_classroom_code',
		);

		if ( 'masteriyo-single-course' === $template_type ) {
			$names_to_hide = $archive_element_names;
		} elseif ( 'masteriyo-course-archive' === $template_type ) {
			$names_to_hide = $single_course_element_names;
		} else {
			return;
		}

		foreach ( $names_to_hide as $name ) {
			unset( \Bricks\Elements::$elements[ $name ] );
		}
	}
}
