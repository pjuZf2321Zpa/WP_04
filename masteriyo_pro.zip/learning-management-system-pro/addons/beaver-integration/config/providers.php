<?php

defined( 'ABSPATH' ) || exit;

/**
 * Masteriyo beaver integration service providers.
 *
 * @since 1.10.0 [Free]
 */

use Masteriyo\Addons\BeaverIntegration\Providers\BeaverIntegrationServiceProvider;

return array_unique(
	array(
		BeaverIntegrationServiceProvider::class,
	)
);
