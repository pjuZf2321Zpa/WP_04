<?php

defined( 'ABSPATH' ) || exit;

/**
 * The Template for displaying brevo consent checkbox in sing-up page.
 *
 * @since 2.14.4 [Free]
 */

if ( is_user_logged_in() ) {
	return;
}

?>
<div class="masteriyo-signup-brevo-consent-checkbox">
	<div class="masteriyo-signup-brevo-consent-checkbox--wrapper">
		<input type="checkbox" id="masteriyo_brevo_consent_checkbox" name="masteriyo_brevo_consent_checkbox">
		<label for="masteriyo_brevo_consent_checkbox" class="masteriyo-label"><?php echo esc_html( $consent_message ); ?></label>
	</div>
</div>
<?php
