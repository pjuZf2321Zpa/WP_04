<?php
/**
 * Pro's part of the certificate addon.
 *
 * The certificate addon ships in both products; the pro-only half of it — the QR
 * code and verification blocks, the block builders behind them, and certificate
 * verification itself — lives under this directory and joins the shared half
 * through the hooks below.
 *
 * Required by `pro/bootstrap.php`, which runs before `Addons::load_all()`, so
 * every hook here is in place by the time the addon's `main.php` is read. The
 * addon's own bail-if-inactive check therefore still governs all of it: the
 * actions these callbacks listen for are only ever fired from the active path.
 *
 * @package Masteriyo\Addons\Certificate\Pro
 */

use Masteriyo\Addons\Certificate\Pro\Blocks;
use Masteriyo\Addons\Certificate\Pro\CertificationVerification;
use Masteriyo\Addons\Certificate\Pro\RestApi\CertificateCustomFontsController;

defined( 'ABSPATH' ) || exit;

/**
 * Where this half of the addon keeps its templates.
 *
 * The shared half has MASTERIYO_CERTIFICATE_TEMPLATES; the verification page is
 * pro-only and so is its template.
 */
define( 'MASTERIYO_CERTIFICATE_PRO_TEMPLATES', __DIR__ . '/templates' );

add_action(
	'masteriyo_certificate_addon_initialized',
	function() {
		CertificationVerification::init();
	}
);

add_action(
	'masteriyo_certificate_register_blocks',
	function() {
		( new Blocks() )->register_blocks();
	}
);

add_filter(
	'masteriyo_certificate_block_builder_namespaces',
	function( $namespaces ) {
		$namespaces[] = 'Masteriyo\\Addons\\Certificate\\Pro\\PDF\\BlockBuilders\\';

		return $namespaces;
	}
);

/**
 * Offer the whole starter-template gallery rather than only the first.
 *
 * The shared half caps the gallery at one template because that cap is what
 * makes `clone_template()` refuse a paid template — it resolves a requested id
 * by scanning the returned array, so an uncapped array is a clonable one
 * whatever the editor renders. Pro removes the cap; which of the templates a
 * given install may actually use is then the editor's licence check.
 */
add_filter( 'masteriyo_certificate_template_samples_limit', '__return_zero' );

/**
 * Register the custom-font upload route.
 *
 * Installing the *predefined* font list is free's and stays on the shared
 * controller. Uploading a font of your own is pro's — free 2.3.2 has no such
 * route, no handler and no client for one — so it is registered from here.
 *
 * Bound inside the addon's own initialisation rather than at file scope,
 * because `masteriyo_rest_api_get_rest_namespaces` is core's and fires whether
 * or not the certificate addon is active. `init()` runs during
 * `Addons::load_all()`, long before `rest_api_init`, so the filter is always in
 * place in time.
 *
 * The map key is this controller's own; `RestApi::register_rest_routes()` only
 * ever uses it as an array key, so sharing `masteriyo/pro/v1` and the
 * `certificates` base with the addon's own controller is what keeps the public
 * URL unchanged.
 */
add_action(
	'masteriyo_certificate_addon_initialized',
	function() {
		add_filter(
			'masteriyo_rest_api_get_rest_namespaces',
			function( $namespaces ) {
				$namespaces['masteriyo/pro/v1']['certificate-custom-fonts'] = CertificateCustomFontsController::class;

				return $namespaces;
			}
		);
	}
);

// The verification page is pro-only, so only pro hands the player a public share URL.
add_filter(
	'masteriyo_rest_response_course_progress_data',
	function( $data ) {
		if ( ! empty( $data['certificate_code'] ) ) {
			$data['certificate_verify_url'] = add_query_arg( 'certificate-verification-id', $data['certificate_code'], home_url( '/' ) );
		}
		return $data;
	}
);
