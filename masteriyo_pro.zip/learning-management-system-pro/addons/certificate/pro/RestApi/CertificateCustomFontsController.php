<?php
/**
 * Custom certificate font upload — pro's half of the certificate addon's fonts.
 *
 * The certificate addon ships in both products, and so does the *predefined*
 * font installer (`certificates/import-certificate-fonts`, which downloads a
 * fixed list from masteriyo.com). Uploading a font of your own is pro's, and
 * free 2.3.2 has none of it — no route, no handler, no helper, no client. It
 * shipped to the free product nonetheless, separated only by a licence check in
 * React while the endpoint itself had no product gate at all.
 *
 * A licence check is not a product split, so the whole feature lives here.
 *
 * The public path does NOT move. This controller keeps
 * `masteriyo/pro/v1/certificates`, so `certificates/import-custom-fonts` answers
 * on exactly the URL it always has — which product ships a controller and which
 * URL it answers on are two different questions. The namespace map's keys are
 * only ever used as array keys by `RestApi::register_rest_routes()`, so a second
 * controller may carry the same `rest_base` under a different key.
 *
 * Registered from `addons/certificate/pro/bootstrap.php` on
 * `masteriyo_rest_api_get_rest_namespaces`, which is only reached once the
 * shared addon has passed its own bail-if-inactive check.
 *
 * @package Masteriyo\Addons\Certificate\Pro\RestApi
 */

namespace Masteriyo\Addons\Certificate\Pro\RestApi;

defined( 'ABSPATH' ) || exit;

/**
 * CertificateCustomFontsController class.
 */
class CertificateCustomFontsController {

	/**
	 * Endpoint namespace.
	 *
	 * @var string
	 */
	protected $namespace = 'masteriyo/pro/v1';

	/**
	 * Route base.
	 *
	 * Deliberately the same base the shared `CertificatesController` uses: the
	 * route this class adds is a sibling of that controller's own font route and
	 * its URL is unchanged by the move.
	 *
	 * @var string
	 */
	protected $rest_base = 'certificates';

	/**
	 * Register the custom-font upload route.
	 */
	public function register_routes() {
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/import-custom-fonts',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'import_custom_fonts' ),
					'permission_callback' => array( $this, 'import_custom_fonts_permission_check' ),
				),
			)
		);
	}

	/**
	 * Check whether the request may install fonts.
	 *
	 * Same capability the shared controller applies to every other certificate
	 * setting write, restated here rather than inherited, because this class
	 * deliberately extends nothing the free product ships.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 *
	 * @return true|\WP_Error
	 */
	public function import_custom_fonts_permission_check( $request ) {
		if ( ! current_user_can( 'manage_masteriyo_settings' ) ) {
			return new \WP_Error(
				'masteriyo_rest_cannot_install_fonts',
				__( 'Sorry, you are not allowed to install certificate fonts.', 'learning-management-system' ),
				array( 'status' => rest_authorization_required_code() )
			);
		}

		return true;
	}

	/**
	 * Imports custom fonts for certificates.
	 *
	 * This method handles the import of custom fonts by processing uploaded files.
	 * It supports both individual font files and ZIP archives containing multiple fonts.
	 * The method performs validation, extraction, and storage of the fonts in the appropriate directory.
	 * It also updates relevant options and transients for caching purposes.
	 *
	 * @param \WP_REST_Request $request The REST API request object.
	 *
	 * @return \WP_REST_Response|\WP_Error The response object on success, or a WP_Error object on failure.
	 *
	 * @throws \Exception If there is an error during the import process.
	 */
	public function import_custom_fonts( $request ) {
		try {
			if ( ! $request ) {
				return $this->create_error( __( 'Request not found.', 'learning-management-system' ), 500 );
			}

			$files = $_FILES['files'] ?? null; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- REST endpoint authenticated via permission_callback.
			if ( empty( $files['name'] ) ) {
				return $this->create_error( __( 'No files uploaded.', 'learning-management-system' ), 400 );
			}

			$file_system = masteriyo_get_filesystem();
			if ( ! $file_system || ! class_exists( \ZipArchive::class ) ) {
				throw new \Exception( __( 'Filesystem or ZipArchive class not available.', 'learning-management-system' ) );
			}

			$upload_dir    = wp_upload_dir();
			$output_folder = $upload_dir['basedir'] . '/masteriyo/certificate-fonts';
			if ( ! $file_system->is_dir( $output_folder ) ) {
				$file_system->mkdir( $output_folder );
			}

			$font_exts         = array( 'ttf', 'otf' );
			$is_zip            = count( $files['name'] ) === 1 && in_array( $files['type'][0], array( 'application/zip', 'application/x-zip-compressed' ), true );
			$conflicting_files = array();
			$invalid_files     = array();

			if ( $is_zip ) {
				$zip       = new \ZipArchive();
				$temp_file = $files['tmp_name'][0];

				if ( $zip->open( $temp_file ) !== true ) {
					return $this->create_error( __( 'Failed to open the ZIP file.', 'learning-management-system' ), 400 );
				}

				// Validate files inside the ZIP archive. Returns two lists, like its
				// sibling below — destructure both, or the conflicts are extracted too.
				list( $conflicting_files, $valid_files ) = $this->validate_zip_contents( $zip, $output_folder, $font_exts );

				if ( $conflicting_files ) {
					$zip->close();
					/* translators: %s is replaced with the names of the fonts that already exist */
					return $this->create_error( sprintf( __( 'These fonts already exist: %s', 'learning-management-system' ), implode( ', ', $conflicting_files ) ), 400 );
				}

				// Extract files from the ZIP archive
				$extract_zip_files = $this->extract_zip_files( $zip, $valid_files, $output_folder, $temp_file );
				if ( is_wp_error( $extract_zip_files ) ) {
					$error_message = $extract_zip_files->get_error_message();
					return $this->create_error( $error_message, 400 );
				}

				$zip->close();
			} else {
				list( $conflicting_files, $invalid_files ) = $this->validate_uploaded_files( $files, $output_folder, $font_exts );

				if ( $invalid_files ) {
					/* translators: %s is replaced with invalid_files */
					return $this->create_error( sprintf( __( 'Invalid file types: %s', 'learning-management-system' ), implode( ', ', $invalid_files ) ), 400 );
				}

				if ( $conflicting_files ) {
					/* translators: %s is replaced with invalid_files */
					return $this->create_error( sprintf( __( 'These fonts already exist: %s', 'learning-management-system' ), implode( ', ', $conflicting_files ) ), 400 );
				}

				// Move the uploaded files to the destination folder
				$this->move_uploaded_files( $files, $output_folder, $file_system );
			}

			// Cleanup and cache update
			array_map( 'wp_delete_file', $files['tmp_name'] );
			update_option( '_masteriyo_additional_certificate_fonts_downloaded', true );
			delete_transient( 'masteriyo_certificate_font_urls' );
			delete_transient( 'masteriyo_font_configurations' );

			return new \WP_REST_Response(
				array( 'message' => __( 'Certificate fonts installed successfully.', 'learning-management-system' ) )
			);

		} catch ( \Exception $e ) {
			return $this->create_error( $e->getMessage(), 500 );
		}
	}

	/**
	 * Creates a WP_Error object with a specified message and status.
	 *
	 * @param string $message The error message.
	 * @param int    $status  The HTTP status code.
	 *
	 * @return \WP_Error The WP_Error object containing the error message and status.
	 */
	private function create_error( $message, $status ) {
		return new \WP_Error(
			'import_fonts_error',
			$message,
			array( 'status' => $status )
		);
	}

	/**
	 * Validate contents inside the ZIP.
	 *
	 * This method checks the contents of a ZIP file to ensure that they are valid font files
	 * and do not conflict with existing files in the specified output folder.
	 *
	 * @param ZipArchive $zip The ZIP archive object containing the files to be validated.
	 * @param string $output_folder The path to the folder where the files will be extracted.
	 * @param array $font_exts An array of valid font file extensions to check against.
	 *
	 * @return array An array containing two elements:
	 *               - An array of conflicting files that already exist in the output folder.
	 *               - An array of valid files that can be safely extracted.
	 */
	private function validate_zip_contents( $zip, $output_folder, $font_exts ) {
		$conflicting_files = array();
		$valid_files       = array();

		for ( $i = 0; $i < $zip->numFiles; $i++ ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			$filename  = $zip->getNameIndex( $i );
			$file_info = pathinfo( $filename );

			if ( empty( $file_info['extension'] ) || ! in_array( strtolower( $file_info['extension'] ), $font_exts, true ) ) {
				continue;
			}

			$target_file = $file_info['basename'];
			if ( file_exists( $output_folder . '/' . $target_file ) ) {
				$conflicting_files[] = $target_file;
			} else {
				$valid_files[] = $filename;
			}
		}

		return array( $conflicting_files, $valid_files );
	}

	/**
	 * Extract valid files from a ZIP archive.
	 *
	 * This method extracts specified valid files from a given ZIP archive and
	 * copies them to the specified output folder.
	 *
	 * @param string $zip The ZIP archive object.
	 * @param array $valid_files An array of valid file paths to be extracted from the ZIP archive.
	 * @param string $output_folder The destination folder where the extracted files will be copied.
	 * @param string $temp_file The temporary file path of the ZIP archive.
	 */
	private function extract_zip_files( $zip, $valid_files, $output_folder, $temp_file ) {
		$flattened_files = array();
		array_walk_recursive(
			$valid_files,
			function( $file ) use ( &$flattened_files ) {
				if ( is_string( $file ) && ! empty( $file ) ) {
					$flattened_files[] = $file;
				}
			}
		);

		if ( ! is_dir( $output_folder ) && ! mkdir( $output_folder, 0777, true ) ) {
			return new \WP_Error(
				'message',
				__( 'Failed to create output folder.', 'learning-management-system' )
			);
		}

		$conflicting_files = array();
		$copied_files      = array();

		foreach ( $flattened_files as $filename ) {
			$file_info = pathinfo( $filename );
			$font_path = $output_folder . '/' . $file_info['basename'];
			$source    = "zip://{$temp_file}#{$filename}";
			if ( ! @copy( $source, $font_path ) ) { //phpcs:ignore

				return new \WP_Error(
					'message',
					/* translators: %s is replaced with invalid_files */
					sprintf( __( 'These fonts already exist: %s', 'learning-management-system' ), $filename )
				);
			}
		}
	}

	/**
	 * Validates the uploaded files by checking their extensions and conflicts.
	 *
	 * @param array  $files         Array of uploaded files.
	 * @param string $output_folder The folder where the files will be saved.
	 * @param array  $font_exts     Array of allowed font file extensions.
	 *
	 * @return array An array containing two arrays:
	 *               - Conflicting files that already exist in the output folder.
	 *               - Invalid files that do not have the allowed extensions.
	 */
	private function validate_uploaded_files( $files, $output_folder, $font_exts ) {
		$conflicting_files = array();
		$invalid_files     = array();

		foreach ( $files['name'] as $index => $name ) {
			$file_type = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );

			if ( ! in_array( $file_type, $font_exts, true ) ) {
				$invalid_files[] = $name;
			} elseif ( file_exists( $output_folder . '/' . basename( $name ) ) ) {
				$conflicting_files[] = basename( $name );
			}
		}

		return array( $conflicting_files, $invalid_files );
	}

	/**
	 * Moves uploaded files to the specified output folder.
	 *
	 * @param array  $files        An array containing the uploaded files information.
	 * @param string $output_folder The destination folder where the files will be moved.
	 * @param object $file_system   An instance of the file system handler to perform the move operation.
	 */
	private function move_uploaded_files( $files, $output_folder, $file_system ) {
		foreach ( $files['name'] as $index => $name ) {
			$temp_file = $files['tmp_name'][ $index ];
			$font_path = $output_folder . '/' . basename( $name );
			$file_system->move( $temp_file, $font_path );
		}
	}
}
