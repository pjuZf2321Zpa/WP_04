<?php
/**
 * Pro's part of the course announcement addon.
 *
 * The addon ships in both products; the webhook listener that fires when a new
 * announcement is published is pro, and lives under this directory.
 *
 * It joins on `masteriyo_course_announcement_addon_initialized`, which the addon
 * fires from `init_hooks()` — past its bail-if-inactive check — so the listener
 * is registered at exactly the point it always was, and only when the addon is
 * active. Registering it unconditionally would put a class the free product does
 * not ship into `masteriyo_get_webhook_listeners()`.
 *
 * @package Masteriyo\Addons\CourseAnnouncement\Pro
 */

use Masteriyo\Addons\CourseAnnouncement\Pro\Listener\NewCourseAnnouncementListener;

defined( 'ABSPATH' ) || exit;

add_action(
	'masteriyo_course_announcement_addon_initialized',
	function() {
		add_filter(
			'masteriyo_webhook_listeners',
			function( $listeners ) {
				$listeners[] = NewCourseAnnouncementListener::class;

				return $listeners;
			}
		);
	}
);
