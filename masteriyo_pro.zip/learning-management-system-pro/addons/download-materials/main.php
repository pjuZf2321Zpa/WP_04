<?php

defined( 'ABSPATH' ) || exit;

/**
 * Addon Name: Download Materials
 * Addon URI: https://masteriyo.com/
 * Description: Attach unlimited lesson materials such as PDF, Doc, etc. Provide students with quick and easy access to download materials, and preview without download.
 * Author: Masteriyo
 * Author URI: https://masteriyo.com
 * Addon Type: enhancement
 * Plan: Free
 * Category: Course Features
 */

define( 'MASTERIYO_DOWNLOAD_MATERIALS_ADDON_FILE', __FILE__ );
define( 'MASTERIYO_DOWNLOAD_MATERIALS_ADDON_BASENAME', plugin_basename( __FILE__ ) );
define( 'MASTERIYO_DOWNLOAD_MATERIALS_ADDON_DIR', __DIR__ );
define( 'MASTERIYO_DOWNLOAD_MATERIALS_ASSETS', __DIR__ . '/assets' );
define( 'MASTERIYO_DOWNLOAD_MATERIALS_TEMPLATES', __DIR__ . '/templates' );
