<?php
/**
 * Keep a group's manual-enrollment orders in sync with the group's own trash/restore state.
 *
 * @package Masteriyo\Addons\GroupCourses\Pro
 * @since 2.31.0
 */

namespace Masteriyo\Addons\GroupCourses\Pro;

defined( 'ABSPATH' ) || exit;

/**
 * ManualGroupEnrollmentOrders class.
 *
 * @since 2.31.0
 */
class ManualGroupEnrollmentOrders {

	/**
	 * Initialize hooks.
	 *
	 * @since 2.31.0
	 */
	public function init_hooks() {
		add_action( 'masteriyo_after_trash_group', array( $this, 'cleanup_group_orders' ), 10, 2 );
		add_action( 'masteriyo_after_restore_group', array( $this, 'restore_group_orders' ), 10, 2 );
	}

	/**
	 * IDs of the group's manual-enrollment orders, matched on all three markers.
	 *
	 * WP_Query, not OrderQuery: AbstractRepository::get_wp_query_args() silently DISCARDS a
	 * caller-supplied meta_query, so an OrderQuery built this way returns every order on the
	 * site — which is how a single group restore used to relabel the whole order table.
	 *
	 * @since 2.31.0
	 *
	 * @param int    $group_id    Group ID.
	 * @param string $created_via Expected _created_via value to match.
	 * @return int[]
	 */
	private function get_group_order_ids( $group_id, $created_via ) {
		$query = new \WP_Query(
			array(
				'post_type'      => 'mto-order',
				'post_status'    => 'any',
				'fields'         => 'ids',
				'posts_per_page' => -1,
				'no_found_rows'  => true,
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					'relation' => 'AND',
					array(
						'key'   => '_created_group_id',
						'value' => $group_id,
					),
					array(
						'key'   => '_created_via',
						'value' => $created_via,
					),
					array(
						'key'   => '_enrollment_type',
						'value' => 'group',
					),
				),
			)
		);

		return array_map( 'absint', $query->posts );
	}

	/**
	 * Mark orders as trashed when their associated group is deleted.
	 *
	 * @since 2.31.0
	 *
	 * @param int $group_id Group ID.
	 * @param object $group Group object.
	 */
	public function cleanup_group_orders( $group_id, $group ) {
		$this->relabel_group_orders( $group_id, 'manual-enrollment', 'manual-enrollment__trashed' );
	}

	/**
	 * Restore orders when their associated group is restored.
	 *
	 * @since 2.31.0
	 *
	 * @param int $group_id Group ID.
	 * @param object $group Group object.
	 */
	public function restore_group_orders( $group_id, $group ) {
		$this->relabel_group_orders( $group_id, 'manual-enrollment__trashed', 'manual-enrollment' );
	}

	/**
	 * Flip created_via on the group's orders, re-verifying every order before writing.
	 *
	 * The re-check runs even though the query already filtered: created_via is order-origin
	 * data on real revenue records, so a write must never depend on a single query being right.
	 *
	 * @since 2.31.0
	 *
	 * @param int    $group_id Group ID.
	 * @param string $from     Expected current _created_via value.
	 * @param string $to       Value to set.
	 */
	private function relabel_group_orders( $group_id, $from, $to ) {
		if ( ! $group_id ) {
			return;
		}

		foreach ( $this->get_group_order_ids( $group_id, $from ) as $order_id ) {
			$order = masteriyo_get_order( $order_id );

			if ( ! $order || is_wp_error( $order ) ) {
				continue;
			}

			if ( absint( $order->get_meta( '_created_group_id', true ) ) !== absint( $group_id )
				|| 'group' !== $order->get_meta( '_enrollment_type', true )
				|| $from !== $order->get_created_via() ) {
				continue;
			}

			$order->set_created_via( $to );
			$order->save();
		}
	}
}
