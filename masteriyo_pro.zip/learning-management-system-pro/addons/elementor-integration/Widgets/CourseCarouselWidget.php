<?php

/**
 * Masteriyo course carousel elementor widget class.
 *
 * @package Masteriyo\Addons\ElementorIntegration\Widgets
 *
 * @since 1.13.0 [Free]
 */

namespace Masteriyo\Addons\ElementorIntegration\Widgets;

use Elementor\Controls_Manager;
use Masteriyo\Addons\ElementorIntegration\Helper;
use Masteriyo\Enums\PostStatus;
use Masteriyo\PostType\PostType;
use Masteriyo\Taxonomy\Taxonomy;

defined( 'ABSPATH' ) || exit;

/**
 * Masteriyo course carousel elementor widget class.
 *
 * @package Masteriyo\Addons\ElementorIntegration\Widgets
 *
 * @since 1.13.0 [Free]
 */
class CourseCarouselWidget extends CourseListWidget {

	/**
	 * Get widget script dependencies.
	 *
	 * @since 1.13.0 [Free]
	 *
	 * @return array
	 */
	public function get_script_depends() {
		return array( 'masteriyo-widget-carousel' );
	}

	/**
	 * Get widget style dependencies.
	 *
	 * @since 1.13.0 [Free]
	 *
	 * @return array
	 */
	public function get_style_depends() {
		// 'e-swiper' keeps the frontend arrow/dot styling consistent with the editor preview.
		return array( 'masteriyo-widget-swiper', 'e-swiper' );
	}

	/**
	 * Get widget name.
	 *
	 * @since 1.13.0 [Free]
	 *
	 * @return string
	 */
	public function get_name() {
		return 'masteriyo-course-carousel';
	}

	/**
	 * Get widget title.
	 *
	 * @since 1.13.0 [Free]
	 *
	 * @return string
	 */
	public function get_title() {
		return __( 'Course Carousel', 'learning-management-system' );
	}

	/**
	 * Get icon class for the widget.
	 *
	 * @since 1.13.0 [Free]
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'masteriyo-course-carousel-widget-icon';
	}

	/**
	 * Register controls for configuring widget content.
	 *
	 * @since 1.13.0 [Free]
	 */
	protected function register_content_controls() {
		$this->register_general_content_controls_section();
		$this->register_filter_controls_section();
		$this->register_sorting_controls_section();
		$this->register_carousel_settings_controls_section();
	}

	/**
	 * Register general content controls section.
	 *
	 * @since 1.13.0 [Free]
	 */
	protected function register_general_content_controls_section() {
		$this->start_controls_section(
			'general',
			array(
				'label' => __( 'General', 'learning-management-system' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'source',
			array(
				'label'    => __( 'Source', 'learning-management-system' ),
				'type'     => Controls_Manager::SELECT,
				'multiple' => true,
				'options'  => array(
					''        => 'All Courses',
					'related' => 'Related Courses',
				),
			)
		);

		$this->add_control(
			'layout',
			array(
				'label'   => __( 'Layout', 'learning-management-system' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'default',
				'options' => array(
					'default' => __( 'Default', 'learning-management-system' ),
					'layout1' => __( 'Modern', 'learning-management-system' ),
					'layout2' => __( 'Overlay', 'learning-management-system' ),
				),
			)
		);

		$this->add_control(
			'limit',
			array(
				'label'   => __( 'Limit', 'learning-management-system' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => -1,
				'max'     => 100,
				'step'    => 1,
				'default' => 12,
			)
		);

		$this->add_control(
			'divider_1',
			array(
				'type' => Controls_Manager::DIVIDER,
			)
		);

		$this->add_control(
			'components_heading',
			array(
				'label' => __( 'Components', 'learning-management-system' ),
				'type'  => Controls_Manager::HEADING,
			)
		);

		$this->add_on_off_switch_control(
			'show_thumbnail',
			__( 'Thumbnail', 'learning-management-system' ),
			array(),
			array(
				'{{WRAPPER}} .masteriyo-course--img-wrap' => 'display: none !important;',
				'{{WRAPPER}} .masteriyo-archive-card__image' => 'display: none !important;',
				'{{WRAPPER}} .masteriyo-course-card__thumbnail-image' => 'display: none !important;',
			)
		);

		$this->add_on_off_switch_control(
			'show_difficulty_badge',
			__( 'Difficulty Badge', 'learning-management-system' ),
			array(
				'condition' => array(
					'show_thumbnail' => 'yes',
					'layout'         => 'default',
				),
			),
			array(
				'{{WRAPPER}} .difficulty-badge' => 'display: none !important;',
			)
		);

		$this->add_on_off_switch_control(
			'show_featured_ribbon',
			__( 'Featured Ribbon', 'learning-management-system' ),
			array(
				'condition' => array(
					'show_thumbnail' => 'yes',
					'layout'         => 'default',
				),
			),
			array(
				'{{WRAPPER}} .course-featured' => 'display: none !important;',
			)
		);

		$this->add_on_off_switch_control(
			'show_categories',
			__( 'Categories', 'learning-management-system' ),
			array(
				'conditions' => array(
					'relation' => 'or',
					'terms'    => array(
						array(
							'name'     => 'layout',
							'operator' => '==',
							'value'    => 'default',
						),
						array(
							'name'     => 'layout',
							'operator' => '==',
							'value'    => 'layout1',
						),
					),
				),
			),
			array(
				'{{WRAPPER}} .masteriyo-course--content__category' => 'display: none !important;',
			)
		);

		$this->add_on_off_switch_control(
			'show_course_title',
			__( 'Course Title', 'learning-management-system' ),
			array(),
			array(
				'{{WRAPPER}} .masteriyo-course--content__title a' => 'display: none !important;',
				'{{WRAPPER}} .masteriyo-course-title-wrapper'     => 'display: none !important;',
			)
		);

		$this->add_on_off_switch_control(
			'show_author',
			__( 'Author', 'learning-management-system' ),
			array(
				'conditions' => array(
					'relation' => 'or',
					'terms'    => array(
						array(
							'name'     => 'layout',
							'operator' => '==',
							'value'    => 'default',
						),
						array(
							'name'     => 'layout',
							'operator' => '==',
							'value'    => 'layout1',
						),
					),
				),
			),
			array(
				'{{WRAPPER}} .masteriyo-course-author' => 'display: none !important;',
				'{{WRAPPER}} .masteriyo-author-image'  => 'display: none !important;',
			)
		);

		$this->add_on_off_switch_control(
			'show_author_avatar',
			__( 'Avatar of Author', 'learning-management-system' ),
			array(
				'conditions' => array(
					'relation' => 'and',
					'terms'    => array(
						array(
							'name'     => 'show_author',
							'operator' => '==',
							'value'    => 'yes',
						),
						array(
							'relation' => 'or',
							'terms'    => array(
								array(
									'name'     => 'layout',
									'operator' => '==',
									'value'    => 'default',
								),
								array(
									'name'     => 'layout',
									'operator' => '==',
									'value'    => 'layout1',
								),
							),
						),
					),
				),
			),
			array(
				'{{WRAPPER}} .masteriyo-course-author img' => 'display: none !important;',
				'{{WRAPPER}} .masteriyo-author-image'      => 'display: none !important;',
			)
		);

		$this->add_on_off_switch_control(
			'show_author_name',
			__( 'Name of Author', 'learning-management-system' ),
			array(
				'conditions' => array(
					'relation' => 'and',
					'terms'    => array(
						array(
							'name'     => 'show_author',
							'operator' => '==',
							'value'    => 'yes',
						),
						array(
							'name'     => 'layout',
							'operator' => '==',
							'value'    => 'default',
						),
					),
				),
			),
			array(
				'{{WRAPPER}} .masteriyo-course-author .masteriyo-course-author--name'             => 'display: none !important;',
				'{{WRAPPER}} .masteriyo-archive-card__body-author .masteriyo-course-author--name' => 'display: none !important;',
			)
		);

		$this->add_on_off_switch_control(
			'show_rating',
			__( 'Rating', 'learning-management-system' ),
			array(),
			array(
				'{{WRAPPER}} .masteriyo-rating' => 'display: none !important;',
				'{{WRAPPER}} .masteriyo-course-card__content--rating' => 'display: none !important;',
			)
		);

		$this->add_on_off_switch_control(
			'show_course_description',
			__( 'Highlights / Description', 'learning-management-system' ),
			array(
				'condition' => array(
					'layout' => 'default',
				),
			),
			array(
				'{{WRAPPER}} .masteriyo-course--content__description'   => 'display: none !important;',
				'{{WRAPPER}} .masteriyo-archive-card__body-description' => 'display: none !important;',
			)
		);

		$this->add_on_off_switch_control(
			'show_metadata',
			__( 'Meta Data', 'learning-management-system' ),
			array(
				'description' => __( 'Show/hide the section containing information on number of students, course hours etc.', 'learning-management-system' ),
				'condition'   => array(
					'layout' => 'default',
				),
			),
			array(
				'{{WRAPPER}} .masteriyo-course--content__stats'   => 'display: none !important;',
				'{{WRAPPER}} .masteriyo-archive-card__body-stats' => 'display: none !important;',
			)
		);

		$this->add_on_off_switch_control(
			'show_course_duration',
			__( 'Course Duration', 'learning-management-system' ),
			array(
				'conditions' => array(
					'relation' => 'and',
					'terms'    => array(
						array(
							'name'     => 'show_metadata',
							'operator' => '==',
							'value'    => 'yes',
						),
						array(
							'name'     => 'layout',
							'operator' => '==',
							'value'    => 'default',
						),
					),
				),
			),
			array(
				'{{WRAPPER}} .masteriyo-course-stats-duration' => 'display: none !important;',
			)
		);

		$this->add_on_off_switch_control(
			'show_students_count',
			__( 'Students Count', 'learning-management-system' ),
			array(
				'conditions' => array(
					'relation' => 'and',
					'terms'    => array(
						array(
							'name'     => 'show_metadata',
							'operator' => '==',
							'value'    => 'yes',
						),
						array(
							'name'     => 'layout',
							'operator' => '==',
							'value'    => 'default',
						),
					),
				),
			),
			array(
				'{{WRAPPER}} .masteriyo-course-stats-students' => 'display: none !important;',
			)
		);

		$this->add_on_off_switch_control(
			'show_lessons_count',
			__( 'Lessons Count', 'learning-management-system' ),
			array(
				'conditions' => array(
					'relation' => 'and',
					'terms'    => array(
						array(
							'name'     => 'show_metadata',
							'operator' => '==',
							'value'    => 'yes',
						),
						array(
							'name'     => 'layout',
							'operator' => '==',
							'value'    => 'default',
						),
					),
				),
			),
			array(
				'{{WRAPPER}} .masteriyo-course-stats-curriculum' => 'display: none !important;',
			)
		);

		$this->add_on_off_switch_control(
			'show_card_footer',
			__( 'Footer', 'learning-management-system' ),
			array(
				'conditions' => array(
					'relation' => 'or',
					'terms'    => array(
						array(
							'name'     => 'layout',
							'operator' => '==',
							'value'    => 'default',
						),
						array(
							'name'     => 'layout',
							'operator' => '==',
							'value'    => 'layout1',
						),
					),
				),
			),
			array(
				'{{WRAPPER}} .masteriyo-course-card-footer'    => 'display: none !important;',
				'{{WRAPPER}} .masteriyo-course-archive--aside' => 'display: none !important;',
			)
		);

		$this->add_on_off_switch_control(
			'show_price',
			__( 'Price', 'learning-management-system' ),
			array(
				'conditions' => array(
					'relation' => 'and',
					'terms'    => array(
						array(
							'name'     => 'show_card_footer',
							'operator' => '==',
							'value'    => 'yes',
						),
						array(
							'relation' => 'or',
							'terms'    => array(
								array(
									'name'     => 'layout',
									'operator' => '==',
									'value'    => 'default',
								),
								array(
									'name'     => 'layout',
									'operator' => '==',
									'value'    => 'layout1',
								),
							),
						),
					),
				),
			),
			array(
				'{{WRAPPER}} .masteriyo-course-price' => 'display: none !important;',
				'{{WRAPPER}} .masteriyo-archive-card__content--rating-amount' => 'display: none !important;',
				'{{WRAPPER}} .masteriyo-course-card__content--amount' => 'display: none !important;',
			)
		);

		$this->add_on_off_switch_control(
			'show_price_layout2',
			__( 'Price', 'learning-management-system' ),
			array(
				'condition' => array(
					'layout' => 'layout2',
				),
			),
			array(
				'{{WRAPPER}} .masteriyo-course-card__content--amount' => 'display: none !important;',
			)
		);

		$this->add_on_off_switch_control(
			'show_enroll_button',
			__( 'Enroll Button', 'learning-management-system' ),
			array(
				'conditions' => array(
					'relation' => 'and',
					'terms'    => array(
						array(
							'name'     => 'show_card_footer',
							'operator' => '==',
							'value'    => 'yes',
						),
						array(
							'relation' => 'or',
							'terms'    => array(
								array(
									'name'     => 'layout',
									'operator' => '==',
									'value'    => 'default',
								),
								array(
									'name'     => 'layout',
									'operator' => '==',
									'value'    => 'layout1',
								),
							),
						),
					),
				),
			),
			array(
				'{{WRAPPER}} .masteriyo-enroll-btn'        => 'display: none !important;',
				'{{WRAPPER}} .masteriyo-btn-enroll-course' => 'display: none !important;',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Registers the carousel settings controls section for the Course Carousel widget.
	 *
	 * This method adds various controls for configuring the carousel behavior, such as
	 * enabling/disabling arrows and dots, setting the transition duration, enabling
	 * centered slides, smooth scrolling, reverse direction, autoplay, and more.
	 *
	 * @since 1.13.0 [Free]
	 *
	 * The controls are added to the 'Course Carousel' section in the Elementor widget
	 * settings panel.
	 */
	protected function register_carousel_settings_controls_section() {
		$this->start_controls_section(
			'course_carousel_section',
			array(
				'label' => __( 'Carousel Settings', 'learning-management-system' ),
				'type'  => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'course_carousel_arrows',
			array(
				'label'        => __( 'Arrows', 'learning-management-system' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'learning-management-system' ),
				'label_off'    => __( 'Hide', 'learning-management-system' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'course_carousel_dots',
			array(
				'label'        => __( 'Dots', 'learning-management-system' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'learning-management-system' ),
				'label_off'    => __( 'Hide', 'learning-management-system' ),
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$this->add_control(
			'course_carousel_transition',
			array(
				'label'   => __( 'Transition Duration', 'learning-management-system' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => '600',
			)
		);

		$this->add_control(
			'course_carousel_center_slides',
			array(
				'label'        => __( 'Centered Slides', 'learning-management-system' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'learning-management-system' ),
				'label_off'    => __( 'No', 'learning-management-system' ),
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$this->add_control(
			'course_carousel_scroll',
			array(
				'label'        => __( 'Smooth Scrolling', 'learning-management-system' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'learning-management-system' ),
				'label_off'    => __( 'No', 'learning-management-system' ),
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$this->add_control(
			'course_carousel_autoplay',
			array(
				'label'        => __( 'Auto Play', 'learning-management-system' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'learning-management-system' ),
				'label_off'    => __( 'No', 'learning-management-system' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'course_carousel_autoplay_speed',
			array(
				'label'     => __( 'Auto Play Speed', 'learning-management-system' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 2500,
				'condition' => array(
					'course_carousel_autoplay' => 'yes',
				),
			)
		);

		$this->add_control(
			'course_carousel_reverse_direction',
			array(
				'label'        => __( 'Reverse Direction', 'learning-management-system' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'learning-management-system' ),
				'label_off'    => __( 'No', 'learning-management-system' ),
				'return_value' => 'yes',
				'default'      => '',
				'condition'    => array(
					'course_carousel_autoplay' => 'yes',
				),
			)
		);

		$this->add_control(
			'course_carousel_infinite_loop',
			array(
				'label'        => __( 'Infinite Loop', 'learning-management-system' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'learning-management-system' ),
				'label_off'    => __( 'No', 'learning-management-system' ),
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$this->add_control(
			'course_carousel_pause_onhover',
			array(
				'label'        => __( 'Pause on Hover', 'learning-management-system' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'learning-management-system' ),
				'label_off'    => __( 'No', 'learning-management-system' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'course_carousel_rewind',
			array(
				'label'        => __( 'Rewind', 'learning-management-system' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'learning-management-system' ),
				'label_off'    => __( 'No', 'learning-management-system' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_responsive_control(
			'slides_per_view',
			array(
				'label'          => __( 'Slides Per View', 'learning-management-system' ),
				'type'           => Controls_Manager::SELECT,
				'options'        => array(
					'1' => '1',
					'2' => '2',
					'3' => '3',
				),
				'min'            => 1,
				'max'            => 3,
				'step'           => 1,
				'default'        => '3',
				'tablet_default' => '2',
				'mobile_default' => '1',
			)
		);

		$this->add_responsive_control(
			'space_between',
			array(
				'label'          => __( 'Space Between Slides', 'learning-management-system' ),
				'type'           => Controls_Manager::NUMBER,
				'default'        => 30,
				'tablet_default' => 20,
				'mobile_default' => 10,
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render HTML for frontend.
	 *
	 * @since 1.13.0 [Free]
	 */
	protected function render() {
		$settings = $this->get_settings();

		$limit   = max( absint( $settings['limit'] ), 1 );
		$columns = max( absint( $settings['slides_per_view'] ), 1 );

		$tax_query = array(
			'relation' => 'AND',
		);

		if ( ! empty( $settings['include_categories'] ) ) {
			$tax_query[] = array(
				'taxonomy' => Taxonomy::COURSE_CATEGORY,
				'terms'    => $settings['include_categories'],
				'field'    => 'term_id',
				'operator' => 'IN',
			);
		}

		if ( ! empty( $settings['exclude_categories'] ) ) {
			$tax_query[] = array(
				'taxonomy' => Taxonomy::COURSE_CATEGORY,
				'terms'    => $settings['exclude_categories'],
				'field'    => 'term_id',
				'operator' => 'NOT IN',
			);
		}

		$args = array(
			'post_type'      => PostType::COURSE,
			'status'         => array( PostStatus::PUBLISH ),
			'posts_per_page' => $limit,
			'order'          => 'DESC',
			'orderby'        => 'date',
			'tax_query'      => $tax_query,
		);

		if ( ! empty( $settings['include_instructors'] ) ) {
			$args['author__in'] = $settings['include_instructors'];
		}

		if ( ! empty( $settings['exclude_instructors'] ) ) {
			$args['author__not_in'] = $settings['exclude_instructors'];
		}

		$order = strtoupper( isset( $settings['sorting_order'] ) ? $settings['sorting_order'] : 'DESC' );

		switch ( isset( $settings['order_by'] ) ? $settings['order_by'] : 'date' ) {
			case 'date':
				$args['orderby'] = 'date';
				$args['order']   = ( 'ASC' === $order ) ? 'ASC' : 'DESC';
				break;

			case 'price':
				$args['orderby']  = 'meta_value_num';
				$args['meta_key'] = '_price';
				$args['order']    = ( 'DESC' === $order ) ? 'DESC' : 'ASC';
				break;

			case 'title':
				$args['orderby'] = 'title';
				$args['order']   = ( 'DESC' === $order ) ? 'DESC' : 'ASC';
				break;

			case 'rating':
				$args['orderby']  = 'meta_value_num';
				$args['meta_key'] = '_average_rating';
				$args['order']    = ( 'ASC' === $order ) ? 'ASC' : 'DESC';
				break;

			default:
				$args['orderby'] = 'date';
				$args['order']   = ( 'ASC' === $order ) ? 'ASC' : 'DESC';
				break;
		}

		$courses_query = new \WP_Query( $args );
		$courses       = array_filter( array_map( 'masteriyo_get_course', $courses_query->posts ) );

		$layout              = isset( $settings['layout'] ) ? $settings['layout'] : 'default';
		$layout_template_map = array(
			'layout1' => 'content-course-1.php',
			'layout2' => 'content-course-2.php',
		);
		$card_template       = isset( $layout_template_map[ $layout ] ) ? $layout_template_map[ $layout ] : 'content-course.php';

		// Expose this widget's component toggles to the card templates (overrides
		// globals, scoped to this render). Layout 2 has its own Price toggle.
		$show = function ( $control_name ) use ( $settings ) {
			return masteriyo_string_to_bool( $settings[ $control_name ] ?? 'yes' );
		};

		$GLOBALS['masteriyo_elementor_display_options'] = array( // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
			'showThumbnail'         => $show( 'show_thumbnail' ),
			'showDifficultyBadge'   => $show( 'show_difficulty_badge' ),
			'showCategories'        => $show( 'show_categories' ),
			'showCourseTitle'       => $show( 'show_course_title' ),
			'showAuthor'            => $show( 'show_author' ),
			'showAuthorAvatar'      => $show( 'show_author_avatar' ),
			'showAuthorName'        => $show( 'show_author_name' ),
			'showRating'            => $show( 'show_rating' ),
			'showCourseDescription' => $show( 'show_course_description' ),
			'showMetadata'          => $show( 'show_metadata' ),
			'showCourseDuration'    => $show( 'show_course_duration' ),
			'showStudentsCount'     => $show( 'show_students_count' ),
			'showLessonsCount'      => $show( 'show_lessons_count' ),
			'showCardFooter'        => $show( 'show_card_footer' ),
			'showPrice'             => 'layout2' === $layout ? $show( 'show_price_layout2' ) : $show( 'show_price' ),
			'showEnrollButton'      => $show( 'show_enroll_button' ),
		);

		$original_block_template = isset( $GLOBALS['masteriyo_block_template'] ) ? $GLOBALS['masteriyo_block_template'] : null;
		// Keep masteriyo_block_template null during loop-start so loop-start.php doesn't add
		// layout-specific grid classes (masteriyo-archive-cards col-X) to the Swiper container.
		// We set it to the actual layout only for individual card rendering below.
		$GLOBALS['masteriyo_block_template'] = null; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited

		$layout_attr_map = array(
			'layout1' => 'layout_1',
			'layout2' => 'layout_2',
		);
		$data_layout     = isset( $layout_attr_map[ $layout ] ) ? $layout_attr_map[ $layout ] : '';
		$layout_class    = $data_layout ? ' ' . $data_layout : '';
		$data_attr       = $data_layout ? ' data-layout="' . esc_attr( $data_layout ) . '"' : '';

		$show_carousel_arrows    = 'yes' === $settings['course_carousel_arrows'] ? true : false;
		$show_carousel_dots      = 'yes' === $settings['course_carousel_dots'] ? true : false;
		$show_carousel_scrollbar = 'yes' === $settings['course_carousel_scroll'] ? true : false;

		// Numeric fallbacks mirror the control defaults shown in the editor panel.
		$slider_data = array(
			'columns'           => $columns,
			'space_between'     => $this->get_numeric_setting( $settings, 'space_between', 30 ),
			'reverse_direction' => 'yes' === ( isset( $settings['course_carousel_reverse_direction'] ) ? $settings['course_carousel_reverse_direction'] : '' ),
			'delay'             => $this->get_numeric_setting( $settings, 'course_carousel_autoplay_speed', 2500 ),
			'infinite_loop'     => 'yes' === $settings['course_carousel_infinite_loop'],
			'autoplay'          => 'yes' === $settings['course_carousel_autoplay'],
			'speed'             => $this->get_numeric_setting( $settings, 'course_carousel_transition', 600 ),
			'navigation'        => 'yes' === $settings['course_carousel_arrows'],
			'pagination'        => 'yes' === $settings['course_carousel_dots'],
			'centeredSlides'    => 'yes' === $settings['course_carousel_center_slides'],
			'pauseOnHover'      => 'yes' === $settings['course_carousel_pause_onhover'],
			'scrollbar'         => 'yes' === $settings['course_carousel_scroll'],
			'rewind'            => 'yes' === $settings['course_carousel_rewind'],
			'breakpoints'       => array(
				320  => array(
					'slidesPerView' => $this->get_numeric_setting( $settings, 'slides_per_view_mobile', 1 ),
					'spaceBetween'  => $this->get_numeric_setting( $settings, 'space_between_mobile', 10 ),
				),
				768  => array(
					'slidesPerView' => $this->get_numeric_setting( $settings, 'slides_per_view_tablet', 2 ),
					'spaceBetween'  => $this->get_numeric_setting( $settings, 'space_between_tablet', 20 ),
				),
				1024 => array(
					'slidesPerView' => $this->get_numeric_setting( $settings, 'slides_per_view', 3 ),
					'spaceBetween'  => $this->get_numeric_setting( $settings, 'space_between', 30 ),
				),
			),
		);

		add_filter( 'masteriyo_is_course_carousel_enabled', '__return_true' );

		// `masteriyo-course-list-display-section` is the ancestor every layout-specific card
		// rule requires — the layout_1 rules are scoped to
		// `.masteriyo-course-list-display-section[data-layout=layout_1]` and the layout_2 ones to
		// `.masteriyo-course-list-display-section.layout_2`. Without it the carousel emits the
		// layout's card markup and matches none of its styling, which is the whole of issue 33.
		// The Course List widget (CourseListWidget::render_course_list()) emits the identical
		// container class plus the identical `$layout_attr_map` value, so the two widgets now
		// agree; `masteriyo-container` and `masteriyo-course-carousel` stay because the swiper
		// JS and the carousel's own rules key on them.
		printf(
			'<div class="masteriyo masteriyo-container masteriyo-course-list-display-section masteriyo-course-carousel%s" data-settings="%s"%s>',
			esc_attr( $layout_class ),
			esc_attr( wp_json_encode( $slider_data ) ),
			$data_attr // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		);
		masteriyo_set_loop_prop( 'columns', $columns );

		if ( count( $courses ) > 0 ) {
			$original_course = isset( $GLOBALS['course'] ) ? $GLOBALS['course'] : null;

			// Map layout → extra CSS class on the Swiper container so layout-specific
			// card appearance rules (scoped to .masteriyo-archive-cards / .masteriyo-course-cards) apply.
			$wrapper_class_map   = array(
				'layout1' => 'masteriyo-archive-cards',
				'layout2' => 'masteriyo-course-cards',
			);
			$wrapper_extra_class = isset( $wrapper_class_map[ $layout ] ) ? ' ' . $wrapper_class_map[ $layout ] : '';

			// Always output Swiper structure manually so we are never at the mercy of
			// loop-start template selection (which reads the backend setting and may use
			// loop-start-1.php / loop-start-2.php that have no Swiper support).
			$GLOBALS['masteriyo_block_template'] = ( 'default' !== $layout ) ? $layout : null; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
			masteriyo_set_loop_prop( 'loop', 0 );

			printf( '<div class="masteriyo-courses-wrapper%s swiper">', esc_attr( $wrapper_extra_class ) );
			echo '<div class="swiper-wrapper">';

			foreach ( $courses as $course ) {
				$GLOBALS['course'] = $course;
				$card_class        = empty( $settings['card_hover_animation'] ) ? '' : sprintf( 'elementor-animation-%s', $settings['card_hover_animation'] );

				if ( 'default' !== $layout ) {
					// Modern / Overlay: wrap each card in swiper-slide (card templates don't add it).
					echo '<div class="swiper-slide">';
					masteriyo_get_template( $card_template, array( 'card_class' => $card_class ) );
					echo '</div>';
				} else {
					// Default: content-course.php adds swiper-slide class to the card element itself.
					masteriyo_get_template( $card_template, array( 'card_class' => $card_class ) );
				}
			}

			echo '</div>'; // closes swiper-wrapper
			echo '</div>'; // closes masteriyo-courses-wrapper
			$GLOBALS['masteriyo_block_template'] = null; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited

			$GLOBALS['course'] = $original_course;
			masteriyo_reset_loop();

			if ( $show_carousel_scrollbar ) :
				?>
			<div class="swiper-scrollbar"></div>
				<?php
			endif;

			if ( $show_carousel_arrows ) :
				?>
				<div class="swiper-button-next"></div>
				<div class="swiper-button-prev"></div>
				<?php
			endif;

			if ( $show_carousel_dots ) :
				?>
				<div class="swiper-pagination"></div>
				<?php
			endif;
		}
		echo '</div>';

		$GLOBALS['masteriyo_block_template'] = $original_block_template; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		unset( $GLOBALS['masteriyo_elementor_display_options'] );

		remove_filter( 'masteriyo_is_course_carousel_enabled', '__return_true' );
	}
}
