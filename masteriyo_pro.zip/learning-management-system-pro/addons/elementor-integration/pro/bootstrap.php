<?php
/**
 * Pro's part of the Elementor integration addon.
 *
 * The addon ships in both products; two of its widgets — course cohort and
 * enrollment expiration — are pro, and live under this directory.
 *
 * They join through `elementor_course_widgets`, the addon's own filter, which is
 * applied from `ElementorIntegrationAddon::register_widgets()`. That callback is
 * only registered past the addon's bail-if-inactive check, so the pro widgets
 * inherit that condition rather than restating it.
 *
 * @package Masteriyo\Addons\ElementorIntegration\Pro
 */

use Masteriyo\Addons\ElementorIntegration\Pro\Widgets\CourseCohortWidget;
use Masteriyo\Addons\ElementorIntegration\Pro\Widgets\CourseEnrollmentExpirationWidget;

defined( 'ABSPATH' ) || exit;

add_filter(
	'elementor_course_widgets',
	function( $widgets ) {
		// Appended in the order the shared list had them, after course progress.
		$widgets[] = new CourseCohortWidget();
		$widgets[] = new CourseEnrollmentExpirationWidget();

		return $widgets;
	}
);

add_filter(
	'masteriyo_elementor_single_course_enrollment_area_elements',
	function( $elements ) {
		// The three single-course starter templates place this immediately after the
		// enroll button, which is where the shared file used to name the widget type
		// directly. The widget itself is registered by the filter above.
		$elements[] = array(
			'elType'     => 'widget',
			'isInner'    => false,
			'isLocked'   => false,
			'settings'   => array(),
			'elements'   => array(),
			'widgetType' => 'masteriyo-course-cohort',
		);

		return $elements;
	}
);
