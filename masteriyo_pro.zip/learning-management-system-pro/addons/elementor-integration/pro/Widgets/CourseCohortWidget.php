<?php
/**
 * Masteriyo course cohort elementor widget class.
 *
 * @package Masteriyo\Addons\ElementorIntegration\Widgets
 */

namespace Masteriyo\Addons\ElementorIntegration\Pro\Widgets;

use Elementor\Controls_Manager;
use Masteriyo\Addons\ElementorIntegration\Helper;
use Masteriyo\Addons\ElementorIntegration\SingleCourseWidgetBase;

defined( 'ABSPATH' ) || exit;

/**
 * Masteriyo course cohort elementor widget class.
 *
 * @package Masteriyo\Addons\ElementorIntegration\Widgets
 */
class CourseCohortWidget extends SingleCourseWidgetBase {

	/**
	 * Get widget name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'masteriyo-course-cohort';
	}

	/**
	 * Get widget title.
	 *
	 * @return string
	 */
	public function get_title() {
		return __( 'Course Cohort', 'learning-management-system' );
	}

	/**
	 * Get widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'masteriyo-course-cohort-widget-icon';
	}

	/**
	 * Get widget keywords.
	 *
	 * @return string[]
	 */
	public function get_keywords() {
		return array( 'cohort', 'enrollment', 'dates', 'schedule', 'start', 'end' );
	}

	/**
	 * Register controls configuring widget content.
	 */
	protected function register_content_controls() {}

	/**
	 * Register controls for customizing widget styles.
	 */
	protected function register_style_controls() {
		$this->start_controls_section(
			'cohort_styles_section',
			array(
				'label' => esc_html__( 'Cohort', 'learning-management-system' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_text_region_style_controls(
			'cohort_',
			'.masteriyo-single-course--cohort',
			array(
				'disable_align'       => true,
				'disable_typography'  => true,
				'disable_text_color'  => true,
				'disable_text_shadow' => true,
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'cohort_label_styles_section',
			array(
				'label' => esc_html__( 'Label', 'learning-management-system' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_text_region_style_controls(
			'cohort_label_',
			'.masteriyo-single-course--cohort .cohort-label',
			array(
				'disable_align' => true,
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'cohort_date_styles_section',
			array(
				'label' => esc_html__( 'Date / Time', 'learning-management-system' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_text_region_style_controls(
			'cohort_date_',
			'.masteriyo-single-course--cohort .cohort-date-time',
			array(
				'disable_align' => true,
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output in the editor.
	 */
	protected function content_template() {
		$course = Helper::get_elementor_preview_course();

		if ( ! $course ) {
			return;
		}

		$this->render_feature_disabled_notice( __( 'Cohort dates will display here when cohort mode or course end date is enabled for the course.', 'learning-management-system' ) );
	}

	/**
	 * Render the widget output on the frontend.
	 */
	protected function render() {
		$course = $this->get_course_to_render();

		if ( ! $course ) {
			$this->render_no_course_notice();
			return;
		}

		$this->render_cohort( $course );
	}

	/**
	 * Render cohort output with fallback for empty content.
	 *
	 * @param \Masteriyo\Models\Course $course
	 */
	private function render_cohort( $course ) {
		$this->render_buffered_or_notice(
			function() use ( $course ) {
				masteriyo_single_course_cohort( $course ); },
			__( 'Cohort dates will display here when cohort mode or course end date is enabled for the course.', 'learning-management-system' )
		);
	}
}
