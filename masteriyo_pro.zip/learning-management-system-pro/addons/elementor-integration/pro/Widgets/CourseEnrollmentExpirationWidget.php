<?php
/**
 * Masteriyo course enrollment expiration elementor widget class.
 *
 * @package Masteriyo\Addons\ElementorIntegration\Widgets
 */

namespace Masteriyo\Addons\ElementorIntegration\Pro\Widgets;

use Elementor\Controls_Manager;
use Masteriyo\Addons\ElementorIntegration\Helper;
use Masteriyo\Addons\ElementorIntegration\SingleCourseWidgetBase;

defined( 'ABSPATH' ) || exit;

/**
 * Masteriyo course enrollment expiration elementor widget class.
 *
 * @package Masteriyo\Addons\ElementorIntegration\Widgets
 */
class CourseEnrollmentExpirationWidget extends SingleCourseWidgetBase {

	/**
	 * Get widget name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'masteriyo-course-enrollment-expiration';
	}

	/**
	 * Get widget title.
	 *
	 * @return string
	 */
	public function get_title() {
		return __( 'Course Enrollment Expiration', 'learning-management-system' );
	}

	/**
	 * Get widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'masteriyo-course-enrollment-expiration-widget-icon';
	}

	/**
	 * Get widget keywords.
	 *
	 * @return string[]
	 */
	public function get_keywords() {
		return array( 'expiration', 'expiry', 'access', 'countdown', 'validity', 'enrollment' );
	}

	/**
	 * Register controls configuring widget content.
	 */
	protected function register_content_controls() {}

	/**
	 * Register controls for customizing widget styles.
	 */
	protected function register_style_controls() {
		$this->start_controls_section(
			'expiration_styles_section',
			array(
				'label' => esc_html__( 'Expiration', 'learning-management-system' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_text_region_style_controls(
			'expiration_',
			'.masteriyo-course-expiry-countdown',
			array(
				'disable_align'       => true,
				'disable_typography'  => true,
				'disable_text_color'  => true,
				'disable_text_shadow' => true,
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output in the editor.
	 */
	protected function content_template() {
		$course = Helper::get_elementor_preview_course();

		if ( ! $course ) {
			return;
		}

		// Always show a placeholder in the editor: the countdown requires an enrolled user
		// with a limited-access order, which is never satisfied in the editor context.
		$this->render_feature_disabled_notice( __( 'Enrollment expiration countdown will display here for enrolled users with a limited access period.', 'learning-management-system' ) );
	}

	/**
	 * Render the widget output on the frontend.
	 */
	protected function render() {
		$course = $this->get_course_to_render();

		if ( ! $course ) {
			$this->render_no_course_notice();
			return;
		}

		$this->render_buffered_or_notice(
			function() use ( $course ) {
				masteriyo_single_course_access_expiry_countdown( $course ); },
			__( 'Enrollment expiration countdown will display here for enrolled users with a limited access period.', 'learning-management-system' )
		);
	}
}
