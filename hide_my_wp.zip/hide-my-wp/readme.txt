﻿    === WP Ghost ===
Contributors: johndarrel
Requires at least: 5.8
Tested up to: 7.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Proactive WordPress Hack Prevention: Secure WP paths & login, firewall protection, brute force defense, 2FA, GEO security & bot blocking.

1. Install the Plugin

- Log In as an Administrator on your WordPress dashboard.
- In the WordPress menu, go to Plugins > Add New Plugin tab.
- Click on the Upload Plugin button from the top of the page.
- Click to browse and upload the hide-my-wp.zip file.
- After the upload, click the Activate Plugin button to activate the plugin.

2. Activate the plugin

- From the plugins list, click on the Settings link to go to plugin’s settings.
- Now enter the Activation Token from your account into the activation field.
- Click to activate and start the plugin setup.

3. Select Safe Mode or Ghost Mode

- Go to WP Ghost > Change Paths > Level of Security
- Choose between 2 levels of security: Safe Mode and Ghost Mode.
- Customize the paths as you like and click the Save button to apply changes.
- Follow the WP Ghost instructions based on your server configuration.

Enjoy WP Ghost!
John

== Changelog ==
= 9.0.13 (27 July 2026) =
* New - Vulnerability scan: flags installed plugins and themes with published security issues
* New - Ghost Doctor: finds what is breaking your paths and repairs it in one click
* New - Ghost Doctor can switch to protection that needs no server rules when your server will not serve them
* New - Security Check now opens with one prioritized list of what to fix first
* New - AI explanations written for your own website, server and configuration
* New - Undo restores your settings if a repair does not help
* Fix - Security Check no longer reports wp-content, the login path or the admin path as visible on sites that are hiding them correctly
* Fix - Ghost Doctor no longer reports a failure when Disable REST API Access is on
* Fix - Open on a failing path check no longer leads to a 404 while the new paths are not working yet
* Fix - Fix it now works for Security Keys, Table Prefix, wp-config constants and plugin updates
* Fix - Security Check runs on its own the first time you open it
* Fix - Last check now shows how long ago the scan ran, not a clock time
* Fix - Change Paths shows one card after a path change instead of two
* Fix - Security Tasks no longer shows an empty table when every task passed

= 9.0.12 (20 July 2026) =
* Security - Two-Factor Authentication settings are now bound to the account they belong to, so the 2FA method, authenticator, email codes, backup codes and passkeys can only be managed by the account owner or by an administrator allowed to edit that user
* Security - Passkey enrollment is now always self-service, matching the device the passkey is created on
* Security - Temporary Login updates and deletions now apply only to temporary accounts, so regular accounts are never affected from this screen
* Security - The role assigned to a temporary login is now validated and can never grant more capabilities than the user creating it already has
* Security - Magic Login links now require the same permissions as the screen they are offered from

= 9.0.11 (16 July 2026) =
* Fix - Editing a custom post type that uses the built-in Categories/Tags taxonomy no longer crashes the Block Editor with "Cannot read properties of undefined"
* Fix - Block Editor no longer crashes with "Cannot read properties of undefined" when Hide User Enumeration is on; the users REST endpoint is now hidden from anonymous visitors only, so logged-in Editors and Authors can still edit posts and custom post types

= 9.0.10 (13 July 2026) =
* Fix - Cloud Activity Log entries are now sent in the background, so a slow logging server can no longer delay backend requests, including the Block Editor and other REST calls
* Fix - Force 2FA Setup no longer redirects custom user roles that can't access their profile to a setup screen they are unable to open
* Fix - Settings page navigation menu no longer loses its layout on sites where another plugin or theme restricts the allowed HTML tags; the menu now keeps its own classes and attributes regardless of the site's wp_kses filters

= 9.0.09 (08 July 2026) =
* New - Force 2FA Setup: require selected user roles to set up Two-Factor Authentication before they can access the dashboard, with a guided setup screen shown right after login
* Fix - WP-CLI commands no longer emit a PHP 8.5 Undefined array key hostname warning

= 9.0.08 (01 July 2026) =
* Fix - Temporary Login page no longer triggers a fatal error when opened for a user that was deleted or expired
* Fix - Two-Factor email setup and Magic Login no longer emit PHP warnings when the requested user no longer exists

= 9.0.07 (29 June 2026) =
* New - Frontend Check now also verifies the theme's CSS and JS files load, catching a broken layout on pages that still return 200
* New - Detects when CSS/JS/font files load through WordPress instead of the server config, falls back to safe paths and warns you on the settings page
* Improvement - Redesigned the Frontend Check results into clear, uniform rows that stay readable with long URLs

= 9.0.06 (02 June 2026) =
* Fix - Some sites could show a blank page when source code optimization was enabled; the header/tag find & replace is now fail-safe and never blanks the output on a regex error
* Fix - Prefetch/speculation rules cleanup now removes the wp-admin and wp-*.php entries without leaving the rules JSON invalid
* Security - Fixed unauthenticated Open Redirect via the `redirect_to` parameter on the custom logout URL.

= 9.0.05 (18 May 2026) =
* Fix - WPML/Polylang with a custom or renamed REST API path: WPML Advanced Translation Editor and other REST API calls no longer fail with a network error in the admin
* Fix - REST API requests made through the ?rest_route= form are no longer mistakenly treated as normal page requests and blocked
* Fix - Renamed REST API path: legacy, cached and external clients still calling the default wp-json path are now recognized correctly instead of being 404'd
* Fix - Compatibility module for WPML: the Advanced Translation Editor sync routes and WPML/ICL admin-ajax requests are no longer rewritten with the active language prefix
* Security - Hardened REST API detection: the firewall can no longer be bypassed by appending /wp-json/ (or ?rest_route=) to the query string of another request
* Security - Brute force protection also covers REST API Application Password authentication

= 9.0.04 (11 May 2026) =
* Fix - Compatibility with WPML and Polylang: static asset URLs (wp-content, wp-includes) no longer get the language prefix prepended (e.g. /en/wp-content/...) when "Change Relative URLs to Absolute URLs" is enabled
* Fix - Password-protected pages (built-in WordPress post password) now submit correctly on Nginx and other servers without server-level rewrites when the login URL is customized
* Fix - Refreshed knowledge base links across admin notices to point to the new documentation
* Fix - Minor bugs and typos

= 9.0.03 (06 April 2026) =
* Fix - Dark Mode popup remained white, and some settings fields were too dark
* Fix - Login Page Design now works in Disable mode
* Fix - Firewall whitelist IPs and paths now work in disabled mode when the Firewall is activated
* Fix - Minor bugs and typos

= 9.0.02 (01 April 2026) =
* New - Translation in Indonesian (id_ID) language
* New - Translation in Turkish (tr_TR) language
* Update - Translations updated in all 16 supported languages: Arabic, Brazilian Portuguese, Chinese (Simplified), Dutch, Finnish, French, German, Italian, Japanese, Portuguese, Romanian, Russian, Spanish, and English (default).
* Fix - Friendly time display (e.g. "3 hours ago") now renders correctly in all translated languages
* Fix - Dropdown and Help icon in the RTL languages

= 9.0.01 (30 March 2026) =
* New - Country filter in Security Threats Log and User Events Log
* New - Click on a country circle in the GeoMap to open Security Threats Log filtered by that country for the last 7 days
* Update - Compatibility with WordPress 7.0 and PHP 8.5
* Update - Moved Export CSV button to below the table in Security Threats Log and User Events Log to avoid accidental clicks
* Update - Added proper color handling for dark mode (browser-based)
* Update - Enhanced security progress indicator and introduced Security Optimization Score
* Update - Add a loading process on login submit
* Fix - GeoMap country circle counts now match Security Threats Log counts for the same 7-day window
* Fix - Security Threats counting for the last 7 days on widget now matches the log totals (timezone-aligned day buckets)
* Fix - Passkey login spinner not showing due to missing classList calls
* Fix - Country codes missing from threats log rows now resolved on-the-fly from GeoIP when cron is not running
* Fix - Resolved robots.txt warning when user agents are blocked

= 9.0.00 (26 March 2026) =
* New - Customize the login page with custom logo (with live preview), logo link URL, and color scheme (page, form, button, text, link colors) with one-click presets
* New - Block AI Crawler Bots at firewall level with automatic robots.txt Disallow rules (GPTBot, ClaudeBot, PerplexityBot, Bytespider, and 30+ others)
* New - GEO Map with top 5 threat countries visualization on the Overview dashboard
* New - Export Security Threats Log and User Events Log to CSV
* New - Security Check task to verify IP block automation is configured correctly
* New - Threats count in the Overview widget now shows the full 7-day period totals
* New - Notification in the Overview widget to activate 7G/8G Firewall when unblocked threats are detected
* Update - Store country code in the threats log table for faster country stats
* Update - Missing country codes resolved in background via cron without slowing down threat logging

= 8.3.07 (16 March 2026) =
* Fix - Sorting and filtering in the Events Log & Security Threats Log
* Fix - Rules and Threats filters to work with WP Multisite subpaths structure
* Fix - Temporary login user edit link on WP Multisite
* Fix - Compatibility with Woocommerce 10.6
* Fix - Compatiibility with the Blocksy theme
* Fix - Optimize the plugin speed

= 8.3.06 (09 March 2026) =
* Fix - Security Log and Events Log not recording properly
* Fix - Optimize user logged in verification
* Fix - Don't show the 2FA and Magic Login form when the Safe URL parameter is set
* Fix - Prevent logging out when the paths are changed
* Fix - Sending the code too often on 2FA Email verification. The code can be resent only every 30 seconds.
* Fix - Remove unused JS, CSS and fonts
* Fix - Compatiibility with the new WP 6.9.4

= 8.3.04 (02 March 2026) =
* Update - Remove the option to send the new paths by email as the are already on WP Ghost dDashboard
* Update - Send the Brute Force, 2FA and Magic Login texts to the multilingual plugins like WPML and Polylang
* Update - Add the Magic Login options to Change Paths > Login Security section
* Update - Compatibility with PHP 8.5
* Fix - Small bugs and typos

= 8.3.03 (25 Feb 2026) =
* New - Added Automation on IP address blocking in the Firewall
* Update - Added compatibility with Photo Gallery from 10Web
* Update - Translations in all 14 languages
* Update - Moved 2FA and Magic Login feature in WP Ghost core
* Update - UI for Security Threats Log and Events Log
* Update - Plugin core security acording to the latest WordPress security recommendations
* Fix - Firewall rules to work with the new WordPress 6.9.2 update

= 8.3.01 (10 Feb 2026) =
* Update - Add the option to hide AI Bots in the Firewall > Block User Agents
* Fix - Fatal error on log table creation when the plugin is activated
* Fix - Safe URL parameter on login form to prevent 2FA from showing when is activated

= 8.3.00 (07 Feb 2026) =
* New – Security Threats Log added to track blocked attacks and malicious requests
* Change – Events Log renamed to Logs, now split into User Events and Security Threats
* Update – Expanded 7G / 8G Firewall rules to block advanced brute-force attempts, SQL injection, XSS payloads, file inclusion, directory traversal, and automated vulnerability scans before reaching WordPress
* Update – Improved threat detection to stop malicious requests before WordPress core execution
* Update – Added advanced request pattern analysis to identify and block malicious payloads
* Update – Enhanced threat classification to clearly separate blocked attacks from allowed traffic in security logs
* Update – Optimized firewall execution path to reduce overhead and improve performance under high attack traffic

= 8.2.19 (08 Jan 2026) =
* Update - Added the option to track all threats

= 8.2.18 (02 Jan 2026) =
* Update - Added the option to Hide Source Map References
* Update - Added the option to Hide Users Enumeration
* Fix - Brute Force compatibility with Elementor Pro on form submit
* Fix - Update Google reCaptcha JavaScript to work with Woocommerce Ajax

= 8.2.17 (09 Dec 2025) =
* Fix - Remove the wp-*.php and admin path from prefetch paths in WP 6.9
* Fix - Small bugs and warnings

= 8.2.16 (01 Dec 2025) =
* Update - Compatibility with WP 6.9
* Update - 2FA to allow each user to select the 2FA method in the profile
* Update - 2FA to connect through passkey and fingerprint
* Update - 2FA to trust the current browser

= 8.2.15 (29 Sept 2025) =
* Update - Compatibility with the plugin WP Social & WP Social PRO
* Update - Compatibility with LiteSpeed Quic Cloud on IPV6
* Update - Make REST API test work when permalinks are set to the default PHP parameter
* Update - Minimum PHP version required is 8.0 in the Security Check section

= 8.2.14 (22 Aug 2025) =
* Update - Firewall rules for more compatibility
* Update - Safe URL verification process
* Update - Compatibility with the plugin Debloat
* Update - Compatibility with WP Social login customization

= 8.2.13 (08 July 2025) =
* Update - Compatibility with Riode theme on Brute Force
* Fix - Update check error

= 8.2.12 (19 June 2025) =
* Update - 7G & 8G Firewall for more compatibility with WP Plugin
* Update - Compatibility with Kadence Blocks

= 8.2.11 (21 Mar 2025) =
* Update - Compatibility with the WP 6.8
* Update - Firewall compatibility with WooCommerce
* Fix - Function _load_textdomain_just_in_time was called incorrectly

= 8.2.10 (10 Mar 2025) =
* Update - Compatibility with the new WP Engine rewrite rules
* Fix - File security when the rewrite rules are not loaded correctly
* Fix - Prevent Brute Force from updating the warning text without space when switched off
* Fix - Prevent PHP warning when IP address unknown in Brute Force IP check
* Fix - Load i18n on login page for password-strength-meter messages when the Clean Login option is activated
* Fix - Detect if parent theme has caps when child theme is activated
* Fix - Dynamic file mapping to load through index.php for better compatibility with all server types

= 8.2.04 (07 Mar 2025) =
* Update - Add the option to customize all active and inactive themes
* Update - The plugin update library from PucFactory
* Fix - Brute Force error in comments when no recaptcha option is selected
* Fix - WP Multisite root directory for custom WP directory installation

= 8.2.03 (04 Mar 2025) =
* Update - Security update on wp-activate.php path call
* Fix - Headers check on Brute Force to get the real IP behind Proxy
* Fix - Admin layout issue when other plugins notification is loading in Wp Ghost settings
* Fix - Remove newlines from the rewrite rules

= 8.2.01 (26 Feb 2025) =
* Update - Translations in all languages for the last changes
* Fix - Brute Force compatibility and bugs
* Fix - Include parent theme in the custom theme name list if the child theme is loaded

= 8.2.00 (25 Feb 2025) =
* Update - Add Google reCaptcha Enterprise
* Update - Increase security on Brute Force feature
* Update - Compatibility with Sucuri plugin on Events Log and Brute Force
* Update - Add the _HMWP_CONFIG_DIR_ constant to define the config root path
* Fix - Get the real IP address behind proxy

= 8.1.04 (06 Feb 2025) =
* Update - New WP Ghost Dashboard design
* Update - Login Attempt and Blocked IPs chart in WP Ghost Dashboard
* Update - Email Alerts log report in WP Ghost Dashboard
* Fix - Paths changed in dynamically loaded CSS and JS files
* Fix - Prevent redirecting URLs to hidden paths on config rules issue
* Fix - Prevent hiding the wp-admin on config rules issue
* Fix - Prevent changing the wp-admin on config rules issue

= 8.1.03 (22 Jan 2025) =
* Update - Knowledge Base links and responsive layout
* Update - GeoIP Country database for Geo-Blocking
* Fix - Config update issue when saving the whitelist from Level Of Security

= 8.1.02 (14 Jan 2025) =
* Update - Added the AI support in the plugin settings page
* Update - Remove the help icons for the plugin whitelabel option with custom domain
* Fix - Prevent changing the login path in posts slug
* Fix - Advanced Pack install domain not found error

= 8.1.01 (04 Jan 2025) =
* Update - Changed Hide My WP Ghost plugin name with short WP Ghost
* Update - WP Ghost comes with a new plugin logo in 2025
* Update - More security on REST API for user listing when User Security is activated
* Update - Plugin Security and Firewall rules

= 8.0.21 (21 Dec 2024) =
* Update - Added gif and tiff to media redirect in Hide WP Common Paths
* Update - Allow activating hmwp_manage_settings capability only for a user using Roles & Capabilities plugin
* Fix - Layout and improved functionality

= 8.0.20 (04 Nov 2024) =
* Update - Compatibility with WP 6.7
* Update - Compatibility with LiteSpeed Quic Cloud IP addresses automatically
* Fix - Litespeed cache plugin compatibility and set /cache/ls directory by default
* Fix - Whitelist website IP address on REST API disable to be able to be accessed by the installed plugins

= 8.0.19 (20 Oct 2024) =
* Fix - Compatibility with LiteSpeed when CDN is not set
* Fix - Change paths when www. prefix exists on the domain

= 8.0.17 (12 Oct 2024) =
* Update - Compatibility with WP Rocket Background CSS loader
* Update - Compatibility with LiteSpeed Cache CDN
* Update - Map Litespeed cache directory in URL Mapping
* Fix - Remove dynamic CSS and JS when Text Mapping is switched off
* Fix - Prevent changing wp-content and wp-includes paths in deep URL location and avoid 404 errors

= 8.0.16 (10 Oct 2024) =
* Update - Layouts, colors
* Update - Added Drupal 11 in CMS simulation
* Update - Set 404 Not Found error as default option for hidden paths
* Fix - Compatibility with Wordfence Scan
* Fix - Changed deprecated PHP functions
* Fix - Warnings when domain schema is not identified for the current website
* Fix - Redirect to homepage the newadmin when user is not logged in

= 8.0.15 (03 Oct 2024) =
* Fix - Compatibility with WP 6.6.2
* Fix - Compatibility with Squirrly SEO buffer when other cache plugins are active
* Fix - Compatibility with Autoptimize minify

= 8.0.14 (07 Sept 2024) =
* Update - Added the option to select all Countries in Geo Blocking
* Update - Brute Force compatibility with UsersWP plugin
* Update - Whitelist path to not check Brute force reCaptcha in case of login whitelist paths

= 8.0.13 (23 Aug 2024) =
* Update - Added the option to disable Copy & Paste separately
* Fix - PHP Error on HMWP_Models_Files due to the not found class
* Fix - Small Bugs

= 8.0.12 (15 Aug 2024) =
* Update - Compatibility with Wordfence

= 8.0.11 (14 Aug 2024) =
* Update - Plugin security and compatibility with WP 6.6.1 and PHP 8.3
* Update - Adding wp-admin path extensions into firewall when user is not logged in

= 8.0.10 (11 Aug 2024) =
* Fix - Google reCaptcha on frontend popup to load google header if not already loaded
* Fix - Hide New Login Path to allow redirects from custom paths: lost password, signup and disconnect
* Fix - WP Multisite active plugins check to ignore inactive plugins
* Fix - Small bugs

= 8.0.09 (10 Aug 2024) =
* Update - Add security preset loading options in Hide My WP > Restore
* Fix - Library integrity on the update process
* Fix - Cookie domain on WP multisite to redirect to new login path when changing sites from the network
* Fix - Brute Force shortcode to work with different login forms

= 8.0.07 (01 Aug 2024) =
* Fix - Compatibility with WP 6.6
* Fix - Security update on wp-login.php and login.php

= 8.0.06 (29 July 2024) =
* Update - Compatibility with WordPress 6.5.5
* Update - Added the option to immediately block a wrong username in Brute Force
* Update - Sub-option layouts
* Fix - File Permission check to receive the correct permissions when is set stronger than required
* Fix - Hide login.php path together with wp-login.php path from being redirect to the new login
* Fix - Small bugs

= 8.0.05 (18 July 2024) =
* Update - Added more path in Frontend Test to make sure the settings are okay before confirmation
* Fix - Compatibility with Wordfence to not remove the rules from htaccess
* Fix - Filter words in 8G Firewall that might be used in article slugs
* Fix - Trim error in cookie when main domain cookie is set
* Fix - Login header hooks to not remove custom login themes

= 8.0.03 (03 July 2024) =
* Fix - isPluginActive check error when is_plugin_active is not yet declared
* Fix - Disable clicks and keys to work without jQuery
* Fix - Compatibility with Wordfence scan process

= 8.0.02 (22 June 2024) =
* Fix - Show error messages in Temporary login when a user already exists
* Fix - Temporary users to work on WP Multisite > Subsites

= 8.0.01 (20 June 2024) =
* Fix - Login security when Elementor login form is created and Brute Force is active
* Fix - Login access when member plugins are used for login process
* Fix - Firewall warning on preg_match bot check in firewall.php

= 8.0.00 (15 June 2024) =
* Update - Added Country Blocking & Geo Security feature
* Update - Added Firewall blacklist by User Agent
* Update - Added Firewall blacklist by Referrer
* Update - Added Firewall blacklist by Hostname
* Update - Added 'Send magic link login' option in All Users user row actions on Hide My WP Advanced Pack plugin
* Update - Added the option to select the level of access for an IP address in whitelist
* Removed - Mysql database permission check as WordPress 6.5 handles DB permissions more secure
* Moved - Firewall section was moved to the main menu as includes more subsections
* Fix - 8G Firewall compatibility with all page builder plugins
