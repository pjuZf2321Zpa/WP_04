<?php defined( 'ABSPATH' ) || die( 'Cheating uh?' ); ?>
<?php if ( ! isset( $view ) ) {
	return;
} ?>
<?php
$report    = isset( $view->report ) ? $view->report : array();
$items     = isset( $report['items'] ) ? $report['items'] : array();
$lastcheck = isset( $view->lastcheck ) ? (int) $view->lastcheck : 0;
$affected  = isset( $report['affected'] ) ? (int) $report['affected'] : 0;
?>


		<?php if ( empty( $items ) ) { ?>

            <div class="card col-sm-12 p-4 shadow-none border-0">
                <div class="card-body text-center p-0">
                    <div class="card-text text-muted">
						<?php echo esc_html__( 'Your plugins and themes have not been checked against the public vulnerability database yet.', 'hide-my-wp' ); ?>
                    </div>
                    <div class="text-center my-4">
                        <form method="POST">
							<?php wp_nonce_field( 'hmwp_vulnerabilitycheck', 'hmwp_nonce' ); ?>
                            <input type="hidden" name="action" value="hmwp_vulnerabilitycheck"/>
                            <button type="submit" class="btn rounded-0 btn-default px-4"><?php echo esc_html__( 'Check Vulnerabilities', 'hide-my-wp' ); ?></button>
                        </form>
                    </div>
                </div>
            </div>

		<?php } else { ?>

			<?php
			// Say what was checked and what came back. Opening a panel to an empty
			// table reads as broken, and it also hides the most reassuring fact
			// this panel has: that everything installed was actually looked at.
			?>
            <div class="col-sm-12 px-4 pt-3 pb-2">
				<?php if ( $affected ) { ?>
                    <span class="text-danger" style="font-weight: 600;">
						<?php
						echo esc_html(
							sprintf(
							/* translators: 1: Number with a known vulnerability. 2: Number checked. */
								_n( '%1$s of %2$s has a known vulnerability', '%1$s of %2$s have known vulnerabilities', $affected, 'hide-my-wp' ),
								$affected,
								count( $items )
							)
						);
						?>
                    </span>
				<?php } else { ?>
                    <span class="text-success" style="font-weight: 600;">
                        <i class="dashicons dashicons-yes mr-1" style="font-size: 1.4rem !important;"></i>
						<?php
						echo esc_html(
							sprintf(
							/* translators: 1: Number of plugins and themes checked. */
								_n( '%1$s plugin and theme checked, none with a known vulnerability', '%1$s plugins and themes checked, none with a known vulnerability', count( $items ), 'hide-my-wp' ),
								count( $items )
							)
						);
						?>
                    </span>
				<?php } ?>
            </div>

            <div class="col-sm-12 p-0 input-group">
                <table class="table table_securitycheck border" style="width: 100%">
                    <thead>
                    <tr>
                        <th scope="col"><?php echo esc_html__( 'Name', 'hide-my-wp' ); ?></th>
                        <th scope="col"><?php echo esc_html__( 'Value', 'hide-my-wp' ); ?></th>
                        <th scope="col"><?php echo esc_html__( 'Valid', 'hide-my-wp' ); ?></th>
                        <th scope="col"><?php echo esc_html__( 'Action', 'hide-my-wp' ); ?></th>
                    </tr>
                    </thead>
                    <tbody>
					<?php foreach ( $items as $index => $row ) {

						$is_problem = ( $row['affected'] || $row['closed'] );
						?>
						<?php
						// No task_passed or task_failed here on purpose. Those classes are
						// driven by the Show completed tasks button, which lives in the
						// Security Tasks panel, so a clean row in this panel could only be
						// revealed from a different panel that may itself be collapsed.
						// This panel is already collapsed by default, so once it is open
						// everything it checked is shown. Problems sort to the top.
						?>
                        <tr>

                            <td style="width: 30%; word-break: break-word;">
								<?php echo esc_html( $row['name'] ); ?>
                                <div class="text-muted small"><?php echo esc_html( 'plugin' === $row['type'] ? __( 'Plugin', 'hide-my-wp' ) : __( 'Theme', 'hide-my-wp' ) ); ?></div>
                            </td>

                            <td style="width: 20%; font-weight: bold; word-break: break-word;">
								<?php echo esc_html( $row['version'] ); ?>
                            </td>

                            <td style="width: 30%; word-break: break-word;" class="<?php echo ( $is_problem ? 'text-danger' : 'text-success' ); ?>">
								<?php if ( $row['affected'] ) { ?>
                                    <i class="dashicons dashicons-no mr-2" style="font-size: 1.6rem !important;"></i>
									<?php
									echo esc_html(
										sprintf(
										/* translators: 1: Number of known vulnerabilities. */
											_n( '%1$s known vulnerability', '%1$s known vulnerabilities', count( $row['vulnerabilities'] ), 'hide-my-wp' ),
											count( $row['vulnerabilities'] )
										)
									);
									?>
									<?php if ( $row['fixed_in'] <> '' ) { ?>
                                        <div class="text-muted small">
											<?php
											/* translators: 1: The first version that is not affected. */
											echo esc_html( sprintf( __( 'Fixed in version %1$s', 'hide-my-wp' ), $row['fixed_in'] ) );
											?>
                                        </div>
									<?php } ?>
								<?php } elseif ( $row['closed'] ) { ?>
                                    <i class="dashicons dashicons-no mr-2" style="font-size: 1.6rem !important;"></i>
									<?php echo esc_html__( 'No longer available on wordpress.org', 'hide-my-wp' ); ?>
								<?php } else { ?>
                                    <i class="dashicons dashicons-yes mr-2" style="font-size: 1.6rem !important;"></i>
									<?php if ( ! $row['known'] ) { ?>
                                        <span class="text-muted small"><?php echo esc_html__( 'Not listed in the database', 'hide-my-wp' ); ?></span>
									<?php } ?>
								<?php } ?>
                            </td>

                            <td style="width: 20%; min-width: 100px; padding-right: 0!important; position: relative">

								<?php if ( $is_problem ) { ?>
                                    <div class="modal" id="hmwp_vulndetail<?php echo esc_attr( $index ); ?>" tabindex="-1" role="dialog" aria-hidden="true">
                                        <div class="modal-dialog modal-lg" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title"><?php echo esc_html( $row['name'] ); ?> <?php echo esc_html( $row['version'] ); ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">

													<?php if ( $row['closed'] ) { ?>
                                                        <p><?php echo esc_html__( 'This plugin or theme was removed from wordpress.org and no longer receives updates. Replace it with a maintained alternative.', 'hide-my-wp' ); ?></p>
													<?php } ?>

													<?php foreach ( $row['vulnerabilities'] as $vulnerability ) { ?>
                                                        <div class="border-top mt-2 pt-2"></div>

                                                        <div style="font-weight: 600;"><?php echo esc_html( $vulnerability['name'] ); ?></div>

														<?php if ( $vulnerability['description'] <> '' ) { ?>
                                                            <div class="my-1"><?php echo esc_html( $vulnerability['description'] ); ?></div>
														<?php } ?>

                                                        <div class="text-muted small my-1">
															<?php if ( $vulnerability['severity'] <> '' ) { ?>
																<?php
																/* translators: 1: Severity word. 2: CVSS score. */
																echo esc_html( sprintf( __( 'Severity: %1$s (%2$s)', 'hide-my-wp' ), ucfirst( $vulnerability['severity'] ), $vulnerability['score'] ) );
																?>
															<?php } ?>
															<?php if ( ! empty( $vulnerability['cwe'] ) ) { ?>
                                                                <div><?php echo esc_html( join( ', ', $vulnerability['cwe'] ) ); ?></div>
															<?php } ?>
															<?php if ( $vulnerability['vector'] <> '' ) { ?>
                                                                <div style="font-family: Menlo, Consolas, monospace;"><?php echo esc_html( $vulnerability['vector'] ); ?></div>
															<?php } ?>
                                                        </div>

														<?php if ( $vulnerability['fixed_in'] <> '' ) { ?>
                                                            <div class="my-1">
																<?php
																/* translators: 1: The first version that is not affected. */
																echo esc_html( sprintf( __( 'Update to version %1$s or later to fix this.', 'hide-my-wp' ), $vulnerability['fixed_in'] ) );
																?>
                                                            </div>
														<?php } ?>

														<?php if ( ! empty( $vulnerability['sources'] ) ) { ?>
                                                            <div class="my-1">
																<?php foreach ( $vulnerability['sources'] as $source ) { ?>
                                                                    <a href="<?php echo esc_url( $source['link'] ); ?>" target="_blank" rel="noopener" class="mr-2"><?php echo esc_html( $source['label'] ); ?></a>
																<?php } ?>
                                                            </div>
														<?php } ?>
													<?php } ?>

                                                    <div class="border-top mt-3 pt-2 text-muted small">
														<?php echo esc_html__( 'Vulnerability data provided by wpvulnerability.net, which aggregates CVE, WPScan, Wordfence and Patchstack records. Records that originate from MITRE remain subject to the MITRE copyright.', 'hide-my-wp' ); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <button class="btn btn-default rounded-0 px-3 float-right m-1" type="button" onclick="jQuery('#hmwp_vulndetail<?php echo esc_attr( $index ); ?>').modal('show');"><?php echo esc_html__( 'Info', 'hide-my-wp' ); ?></button>
								<?php } ?>

								<?php if ( $is_problem && $row['update_available'] && 'plugin' === $row['type'] ) { ?>
                                    <a href="<?php echo esc_url( wp_nonce_url( self_admin_url( 'update.php?action=upgrade-plugin&plugin=' . rawurlencode( $row['path'] ) ), 'upgrade-plugin_' . $row['path'] ) ); ?>" class="btn btn-success mx-0 my-1 rounded-0 float-right m-1"><?php echo esc_html__( 'Update', 'hide-my-wp' ); ?></a>
								<?php } ?>

                            </td>
                        </tr>
					<?php } ?>
                    </tbody>
                </table>
            </div>

			<?php if ( ! empty( $report['skipped'] ) ) { ?>
                <div class="col-sm-12 px-3 pt-2">
                    <div class="text-danger small">
						<?php
						echo esc_html(
							sprintf(
							/* translators: 1: Number of plugins or themes that were not checked. */
								_n( '%1$s plugin or theme was not checked because this site is above the limit for one scan.', '%1$s plugins or themes were not checked because this site is above the limit for one scan.', (int) $report['skipped'], 'hide-my-wp' ),
								(int) $report['skipped']
							)
						);
						?>
                    </div>
                </div>
			<?php } ?>

            <div class="col-sm-12 py-2 d-flex flex-row justify-content-between align-items-center">
                <div class="text-muted small">
					<?php if ( $lastcheck > 0 ) { ?>
                        <strong><?php echo esc_html__( 'Last check:', 'hide-my-wp' ); ?></strong>
						<?php echo esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $lastcheck ) ); ?>
					<?php } ?>
                </div>
                <form method="POST">
					<?php wp_nonce_field( 'hmwp_vulnerabilitycheck', 'hmwp_nonce' ); ?>
                    <input type="hidden" name="action" value="hmwp_vulnerabilitycheck"/>
                    <button type="submit" class="btn btn-light"><?php echo esc_html__( 'Check again', 'hide-my-wp' ); ?></button>
                </form>
            </div>

		<?php } ?>
