<?php
/**
 * Plugin and Theme Vulnerabilities
 * Checks the installed plugins and themes against a public vulnerability database
 *
 * @file The Vulnerabilities model file
 * @package HMWP/Vulnerabilities
 * @since 9.2.0
 */

defined( 'ABSPATH' ) || die( 'Cheating uh?' );

class HMWP_Models_Vulnerabilities {

	/**
	 * Default vulnerability database.
	 *
	 * wpvulnerability.net is a free, open API that aggregates CVE, WPScan,
	 * Wordfence and Patchstack records. It needs no account and answers per
	 * slug, so a site only asks about the plugins it actually has installed.
	 */
	const API_URL = 'https://www.wpvulnerability.net';

	/**
	 * How long a single plugin or theme record is kept before asking again.
	 */
	const CACHE_TIME = 43200; // 12 hours

	/**
	 * How long a failed lookup is remembered.
	 *
	 * Kept short so a database outage does not hide a plugin for half a day,
	 * but long enough that a slug the service cannot answer for is not retried
	 * on every single scan.
	 */
	const FAIL_CACHE_TIME = 3600; // 1 hour

	/**
	 * Safety cap on how many items one scan will look up.
	 */
	const MAX_ITEMS = 100;

	/**
	 * Maps the database comparison words to the PHP version_compare operators.
	 *
	 * @var array
	 */
	private $operators = array(
		'lt' => '<',
		'le' => '<=',
		'gt' => '>',
		'ge' => '>=',
		'eq' => '==',
		'ne' => '!=',
	);

	/**
	 * Get the vulnerability database address.
	 *
	 * Filterable so the request can later be routed through the WP Ghost
	 * account API without changing this model.
	 *
	 * @return string
	 */
	public function getApiUrl() {
		return apply_filters( 'hmwp_vulnerability_api', self::API_URL );
	}

	/**
	 * List the plugins and themes that are active on this site.
	 *
	 * @return array Each entry: type, slug, name, version, path.
	 */
	public function getInstalled() {
		$items = array();

		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$all_plugins = get_plugins();
		$active      = (array) get_option( 'active_plugins', array() );

		// On a network install the network activated plugins are stored separately
		if ( is_multisite() ) {
			$network_active = (array) get_site_option( 'active_sitewide_plugins', array() );
			$active         = array_merge( $active, array_keys( $network_active ) );
		}

		foreach ( array_unique( $active ) as $path ) {

			if ( ! isset( $all_plugins[ $path ] ) ) {
				continue;
			}

			// A plugin in its own directory uses the directory as slug on wordpress.org.
			// A single file plugin uses the file name without the extension.
			if ( strpos( $path, '/' ) !== false ) {
				$slug = dirname( $path );
			} else {
				$slug = basename( $path, '.php' );
			}

			if ( $slug === '' || $slug === '.' ) {
				continue;
			}

			$items[] = array(
				'type'    => 'plugin',
				'slug'    => $slug,
				'name'    => $all_plugins[ $path ]['Name'],
				'version' => $all_plugins[ $path ]['Version'],
				'path'    => $path,
			);
		}

		// The active theme, and its parent when a child theme is in use
		$theme = wp_get_theme();
		if ( $theme->exists() ) {

			$items[] = array(
				'type'    => 'theme',
				'slug'    => $theme->get_stylesheet(),
				'name'    => $theme->get( 'Name' ),
				'version' => $theme->get( 'Version' ),
				'path'    => $theme->get_stylesheet(),
			);

			$parent = $theme->parent();
			if ( $parent && $parent->get_stylesheet() <> $theme->get_stylesheet() ) {
				$items[] = array(
					'type'    => 'theme',
					'slug'    => $parent->get_stylesheet(),
					'name'    => $parent->get( 'Name' ),
					'version' => $parent->get( 'Version' ),
					'path'    => $parent->get_stylesheet(),
				);
			}
		}

		return $items;
	}

	/**
	 * Read one plugin or theme record from the vulnerability database.
	 *
	 * The answer is cached per slug so a daily check does not repeat the same
	 * request. A slug the database does not know about is cached as well, which
	 * is the normal answer for premium and custom built plugins.
	 *
	 * @param string $type plugin or theme.
	 * @param string $slug The wordpress.org slug.
	 *
	 * @return array|false The record, or false when the database has no entry.
	 */
	public function fetchRecord( $type, $slug ) {

		$key    = 'hmwp_vuln_' . $type . '_' . md5( $slug );
		$cached = get_transient( $key );

		if ( $cached !== false ) {
			return ( $cached === 'none' ) ? false : $cached;
		}

		$url = $this->getApiUrl() . '/' . $type . '/' . rawurlencode( $slug );

		// A plain request on purpose. The license headers the plugin adds to its own
		// API calls must not be sent to a third party service, and the user agent
		// carries no site address, so the lookup only reveals the slug being asked
		// about. WordPress would otherwise put the site URL in the default agent.
		$response = wp_remote_get( $url, array(
			'timeout'    => 5,
			'sslverify'  => true,
			'user-agent' => 'WP Ghost/' . HMWP_VERSION,
		) );

		if ( is_wp_error( $response ) ) {
			// A timeout or a refused connection. Remembered briefly so one slow
			// slug does not delay every scan, and retried within the hour.
			set_transient( $key, 'none', self::FAIL_CACHE_TIME );

			return false;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );

		// 404 means the database has no entry for this slug, which is a valid
		// answer and worth caching so we stop asking.
		if ( $code === 404 ) {
			set_transient( $key, 'none', self::CACHE_TIME );

			return false;
		}

		if ( $code <> 200 ) {
			// The service answered with an error of its own. Same short memory as
			// a connection failure, so a broken slug is not retried every scan.
			set_transient( $key, 'none', self::FAIL_CACHE_TIME );

			return false;
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( ! is_array( $body ) || ! isset( $body['data'] ) || ! is_array( $body['data'] ) ) {
			set_transient( $key, 'none', self::CACHE_TIME );

			return false;
		}

		// A slug the database has never seen still answers with 200 and a record
		// where every field is null. That is not an entry, it is a miss, and it
		// must not be reported as "checked and clean". Premium and custom built
		// plugins land here, which is normal.
		if ( empty( $body['data']['name'] ) && empty( $body['data']['vulnerability'] ) ) {
			set_transient( $key, 'none', self::CACHE_TIME );

			return false;
		}

		$record = $this->trimRecord( $body['data'] );

		set_transient( $key, $record, self::CACHE_TIME );

		return $record;
	}

	/**
	 * Keep only the fields the report actually reads.
	 *
	 * A popular plugin answers with a large record. For Elementor it is around
	 * 167KB, and roughly 60 percent of that is per source description text that
	 * is never shown. Storing the whole answer would put megabytes of unused
	 * text in the options table, so the record is reduced before it is cached.
	 *
	 * @param array $data The record as it arrived.
	 *
	 * @return array
	 */
	public function trimRecord( $data ) {

		$record = array(
			'name'          => isset( $data['name'] ) ? $data['name'] : '',
			'closed'        => ! empty( $data['closed'] ),
			'vulnerability' => array(),
		);

		if ( empty( $data['vulnerability'] ) || ! is_array( $data['vulnerability'] ) ) {
			return $record;
		}

		foreach ( $data['vulnerability'] as $vulnerability ) {

			if ( ! isset( $vulnerability['operator'] ) ) {
				continue;
			}

			$entry = array(
				'name'        => isset( $vulnerability['name'] ) ? $vulnerability['name'] : '',
				'description' => isset( $vulnerability['description'] ) ? $vulnerability['description'] : '',
				'operator'    => $vulnerability['operator'],
				'impact'      => array(),
				'source'      => array(),
			);

			// Only the score, the wording and the vector are displayed
			foreach ( array( 'cvss3', 'cvss' ) as $level ) {
				if ( isset( $vulnerability['impact'][ $level ] ) && is_array( $vulnerability['impact'][ $level ] ) ) {
					$entry['impact'][ $level ] = array_intersect_key(
						$vulnerability['impact'][ $level ],
						array( 'score' => 1, 'severity' => 1, 'vector' => 1, 'version' => 1 )
					);
				}
			}

			if ( ! empty( $vulnerability['impact']['cwe'] ) && is_array( $vulnerability['impact']['cwe'] ) ) {
				$entry['impact']['cwe'] = array();
				foreach ( $vulnerability['impact']['cwe'] as $cwe ) {
					$entry['impact']['cwe'][] = array(
						'cwe'  => isset( $cwe['cwe'] ) ? $cwe['cwe'] : '',
						'name' => isset( $cwe['name'] ) ? $cwe['name'] : '',
					);
				}
			}

			// The advisory link and its identifier, never the long description
			if ( ! empty( $vulnerability['source'] ) && is_array( $vulnerability['source'] ) ) {
				foreach ( $vulnerability['source'] as $source ) {
					$entry['source'][] = array(
						'id'   => isset( $source['id'] ) ? $source['id'] : '',
						'name' => isset( $source['name'] ) ? $source['name'] : '',
						'link' => isset( $source['link'] ) ? $source['link'] : '',
					);
				}
			}

			$record['vulnerability'][] = $entry;
		}

		return $record;
	}

	/**
	 * Decide whether an installed version falls inside the affected range.
	 *
	 * The database gives a lower bound, an upper bound, or both, each with its
	 * own comparison word. Both bounds must match when both are present. A
	 * record with no bound at all cannot be evaluated and is not reported, so
	 * the check never invents a result it cannot prove.
	 *
	 * @param string $version  The installed version.
	 * @param array  $operator The operator block from the database record.
	 *
	 * @return bool
	 */
	public function isAffected( $version, $operator ) {

		if ( $version === '' || ! is_array( $operator ) ) {
			return false;
		}

		$has_min = ( ! empty( $operator['min_version'] ) && ! empty( $operator['min_operator'] ) );
		$has_max = ( ! empty( $operator['max_version'] ) && ! empty( $operator['max_operator'] ) );

		if ( ! $has_min && ! $has_max ) {
			return false;
		}

		if ( $has_max ) {
			if ( ! isset( $this->operators[ $operator['max_operator'] ] ) ) {
				return false;
			}
			if ( ! version_compare( $version, $operator['max_version'], $this->operators[ $operator['max_operator'] ] ) ) {
				return false;
			}
		}

		if ( $has_min ) {
			if ( ! isset( $this->operators[ $operator['min_operator'] ] ) ) {
				return false;
			}
			if ( ! version_compare( $version, $operator['min_version'], $this->operators[ $operator['min_operator'] ] ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Work out the first safe version from the affected range.
	 *
	 * Only a "less than" upper bound names an exact safe version. Anything else
	 * is reported as unknown rather than guessed.
	 *
	 * @param array $operator The operator block from the database record.
	 *
	 * @return string Empty when the safe version cannot be determined.
	 */
	public function getFixedVersion( $operator ) {

		if ( isset( $operator['max_operator'] ) && $operator['max_operator'] === 'lt' && ! empty( $operator['max_version'] ) ) {
			return $operator['max_version'];
		}

		return '';
	}

	/**
	 * Read the severity of a single vulnerability record.
	 *
	 * @param array $vulnerability One entry of the record vulnerability list.
	 *
	 * @return array severity and score.
	 */
	public function getSeverity( $vulnerability ) {

		$severity = '';
		$score    = 0;

		if ( isset( $vulnerability['impact']['cvss3'] ) && is_array( $vulnerability['impact']['cvss3'] ) ) {
			$cvss = $vulnerability['impact']['cvss3'];
		} elseif ( isset( $vulnerability['impact']['cvss'] ) && is_array( $vulnerability['impact']['cvss'] ) ) {
			$cvss = $vulnerability['impact']['cvss'];
		} else {
			$cvss = array();
		}

		if ( isset( $cvss['score'] ) ) {
			$score = (float) $cvss['score'];
		}

		if ( isset( $cvss['severity'] ) && strlen( $cvss['severity'] ) > 1 ) {
			// cvss3 spells the severity out, cvss uses a single letter
			$severity = strtolower( $cvss['severity'] );
		} elseif ( $score > 0 ) {
			if ( $score >= 9 ) {
				$severity = 'critical';
			} elseif ( $score >= 7 ) {
				$severity = 'high';
			} elseif ( $score >= 4 ) {
				$severity = 'medium';
			} else {
				$severity = 'low';
			}
		}

		return array( 'severity' => $severity, 'score' => $score );
	}

	/**
	 * Give an advisory link a label a person can read.
	 *
	 * Only the CVE identifier means anything on its own. The other databases use
	 * internal identifiers, so a raw "7391118e-eef5-4ff8-a8ea-f6b65f442c63" tells
	 * the reader nothing. Those are named after the database they came from.
	 *
	 * @param array $source One entry of the source list.
	 *
	 * @return string
	 */
	public function getSourceLabel( $source ) {

		$id   = isset( $source['id'] ) ? $source['id'] : '';
		$link = isset( $source['link'] ) ? $source['link'] : '';

		// A CVE number is meaningful on its own and people search for it
		if ( stripos( $id, 'CVE-' ) === 0 ) {
			return $id;
		}

		$host = strtolower( (string) wp_parse_url( $link, PHP_URL_HOST ) );

		$known = array(
			'wpscan.com'    => 'WPScan',
			'wordfence.com' => 'Wordfence',
			'patchstack.com' => 'Patchstack',
			'cve.org'       => 'CVE',
			'nvd.nist.gov'  => 'NVD',
		);

		foreach ( $known as $domain => $label ) {
			if ( $host <> '' && strpos( $host, $domain ) !== false ) {
				return $label;
			}
		}

		return esc_html__( 'Advisory', 'hide-my-wp' );
	}

	/**
	 * Turn the HTML entities the database returns back into plain text.
	 *
	 * Titles arrive encoded, for example "Elementor &#8211; more than a builder".
	 * The view escapes on output, so the stored value has to be plain text or the
	 * entity would be printed literally.
	 *
	 * @param string $text The text from the database.
	 *
	 * @return string
	 */
	public function decode( $text ) {

		if ( ! is_string( $text ) || $text === '' ) {
			return '';
		}

		return html_entity_decode( $text, ENT_QUOTES, 'UTF-8' );
	}

	/**
	 * Check every installed plugin and theme and store the result.
	 *
	 * @return array The report.
	 * @throws Exception
	 */
	public function scan() {

		$items    = $this->getInstalled();
		$report   = array();
		$affected = $critical = 0;
		$checked  = 0;

		// Plugin updates WordPress already knows about, so no extra request is needed
		$updates = get_site_transient( 'update_plugins' );
		$updates = ( isset( $updates->response ) && is_array( $updates->response ) ) ? $updates->response : array();

		foreach ( $items as $item ) {

			if ( $checked >= self::MAX_ITEMS ) {
				break;
			}
			$checked ++;

			$row = array(
				'type'             => $item['type'],
				'slug'             => $item['slug'],
				'name'             => $item['name'],
				'version'          => $item['version'],
				'path'             => $item['path'],
				'known'            => false,
				'closed'           => false,
				'affected'         => false,
				'severity'         => '',
				'score'            => 0,
				'fixed_in'         => '',
				'vulnerabilities'  => array(),
				'update_available' => isset( $updates[ $item['path'] ] ),
			);

			$record = $this->fetchRecord( $item['type'], $item['slug'] );

			if ( ! empty( $record ) ) {

				$row['known']  = true;
				$row['closed'] = ! empty( $record['closed'] );

				if ( ! empty( $record['vulnerability'] ) && is_array( $record['vulnerability'] ) ) {

					foreach ( $record['vulnerability'] as $vulnerability ) {

						if ( ! isset( $vulnerability['operator'] ) ) {
							continue;
						}

						if ( ! $this->isAffected( $item['version'], $vulnerability['operator'] ) ) {
							continue;
						}

						$impact = $this->getSeverity( $vulnerability );
						$fixed  = $this->getFixedVersion( $vulnerability['operator'] );

						$sources = array();
						if ( ! empty( $vulnerability['source'] ) && is_array( $vulnerability['source'] ) ) {
							foreach ( $vulnerability['source'] as $source ) {
								if ( empty( $source['link'] ) ) {
									continue;
								}

								$sources[] = array(
									'label' => $this->getSourceLabel( $source ),
									'link'  => $source['link'],
								);
							}
						}

						$cwe = array();
						if ( ! empty( $vulnerability['impact']['cwe'] ) && is_array( $vulnerability['impact']['cwe'] ) ) {
							foreach ( $vulnerability['impact']['cwe'] as $entry ) {
								if ( isset( $entry['name'] ) ) {
									$cwe[] = $entry['name'];
								}
							}
						}

						$row['vulnerabilities'][] = array(
							'name'        => isset( $vulnerability['name'] ) ? $this->decode( $vulnerability['name'] ) : '',
							'description' => isset( $vulnerability['description'] ) ? $this->decode( $vulnerability['description'] ) : '',
							'severity'    => $impact['severity'],
							'score'       => $impact['score'],
							'vector'      => isset( $vulnerability['impact']['cvss3']['vector'] ) ? $vulnerability['impact']['cvss3']['vector'] : '',
							'cwe'         => $cwe,
							'fixed_in'    => $fixed,
							'sources'     => $sources,
						);

						// The row carries the highest score found
						if ( $impact['score'] > $row['score'] ) {
							$row['score']    = $impact['score'];
							$row['severity'] = $impact['severity'];
						}

						// Keep the highest known safe version so the advice is not too low
						if ( $fixed <> '' && ( $row['fixed_in'] === '' || version_compare( $fixed, $row['fixed_in'], '>' ) ) ) {
							$row['fixed_in'] = $fixed;
						}
					}
				}

				$row['affected'] = ! empty( $row['vulnerabilities'] );
			}

			if ( $row['affected'] ) {
				$affected ++;
				if ( $row['severity'] === 'critical' ) {
					$critical ++;
				}
			}

			$report[] = $row;
		}

		// Show the problems first, worst score at the top, then the clean rows by name
		usort( $report, array( $this, 'sortReport' ) );

		$result = array(
			'items'    => $report,
			'total'    => count( $report ),
			'affected' => $affected,
			'critical' => $critical,
			// How many were installed but not looked at, so the screen can say so
			// instead of presenting a partial list as if it were complete.
			'skipped'  => max( 0, count( $items ) - $checked ),
		);

		update_option( HMWP_VULNERABILITIES, $result, false );
		update_option( HMWP_VULNERABILITIES_TIME, time(), false );

		return $result;
	}

	/**
	 * Order the report: affected first, highest score first, then by name.
	 *
	 * @param array $a First row.
	 * @param array $b Second row.
	 *
	 * @return int
	 */
	public function sortReport( $a, $b ) {

		if ( $a['affected'] <> $b['affected'] ) {
			return $a['affected'] ? - 1 : 1;
		}

		if ( $a['score'] <> $b['score'] ) {
			return ( $a['score'] > $b['score'] ) ? - 1 : 1;
		}

		return strcasecmp( $a['name'], $b['name'] );
	}

	/**
	 * Read the stored report.
	 *
	 * @return array
	 */
	public function getReport() {

		$report = get_option( HMWP_VULNERABILITIES );

		if ( ! is_array( $report ) || ! isset( $report['items'] ) ) {
			return array( 'items' => array(), 'total' => 0, 'affected' => 0, 'critical' => 0, 'skipped' => 0 );
		}

		// A report stored by an older version has no skipped counter
		if ( ! isset( $report['skipped'] ) ) {
			$report['skipped'] = 0;
		}

		return $report;
	}

	/**
	 * The time of the last check.
	 *
	 * @return int Zero when the check never ran.
	 */
	public function getLastCheck() {
		return (int) get_option( HMWP_VULNERABILITIES_TIME, 0 );
	}

	/**
	 * Forget every cached record so the next scan asks the database again.
	 *
	 * @return void
	 */
	public function purgeCache() {

		foreach ( $this->getInstalled() as $item ) {
			delete_transient( 'hmwp_vuln_' . $item['type'] . '_' . md5( $item['slug'] ) );
		}
	}

}
