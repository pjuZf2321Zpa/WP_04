<?php
/**
 * Vulnerabilities Class
 * Shows the known vulnerabilities for the installed plugins and themes
 *
 * @file The Vulnerabilities controller file
 * @package HMWP/Vulnerabilities
 * @since 9.2.0
 */

defined( 'ABSPATH' ) || die( 'Cheating uh?' );

class HMWP_Controllers_Vulnerabilities extends HMWP_Classes_FrontController {

	/**
	 * The report shown in the view.
	 *
	 * @var array
	 */
	public $report = array();

	/**
	 * The time of the last check.
	 *
	 * @var int
	 */
	public $lastcheck = 0;

	/**
	 * Print the panel under the security tasks.
	 *
	 * Hooked on hmwp_security_check_end from the Security Check page so the
	 * findings read as one list instead of two separate features.
	 *
	 * @return void
	 * @throws Exception
	 */
	public function showPanel() {

		/** @var HMWP_Models_Vulnerabilities $model */
		$model = $this->model;

		$this->report    = $model->getReport();
		$this->lastcheck = $model->getLastCheck();

		$this->show( 'blocks/Vulnerabilities' );
	}

	/**
	 * Run the check and store the result.
	 *
	 * Used by the button on the Security Check page and by the daily cron.
	 *
	 * @return array
	 * @throws Exception
	 */
	public function doVulnerabilityCheck() {

		/** @var HMWP_Models_Vulnerabilities $model */
		$model = $this->model;

		return $model->scan();
	}

	/**
	 * Run the actions on submit
	 *
	 * @throws Exception
	 */
	public function action() {
		parent::action();

		// Check if the current user has the 'hmwp_manage_settings' capability
		if ( ! HMWP_Classes_Tools::userCan( HMWP_CAPABILITY ) ) {
			return;
		}

		switch ( HMWP_Classes_Tools::getValue( 'action' ) ) {

			case 'hmwp_vulnerabilitycheck':

				// Records already read from the database are reused, so pressing the
				// button stays fast. The daily cron is what refreshes them.
				$report = $this->doVulnerabilityCheck();

				if ( (int) $report['affected'] === 0 ) {
					HMWP_Classes_Error::setNotification( esc_html__( 'No known vulnerabilities were found in your plugins and themes.', 'hide-my-wp' ), 'success' );
				} else {
					HMWP_Classes_Error::setNotification(
						sprintf(
						/* translators: 1: Number of affected plugins or themes. */
							esc_html( _n( '%1$s plugin or theme has a known vulnerability.', '%1$s plugins or themes have known vulnerabilities.', (int) $report['affected'], 'hide-my-wp' ) ),
							esc_html( $report['affected'] )
						)
					);
				}

				break;
		}
	}

}
