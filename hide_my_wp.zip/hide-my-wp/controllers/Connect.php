<?php
/**
 * Cloud Connect
 * Called for the Token Activation
 *
 * @package HMWP/Connect
 * @file The Cloud Connect file
 */

defined( 'ABSPATH' ) || die( 'Cheating uh?' );

class HMWP_Controllers_Connect extends HMWP_Classes_FrontController {

	/**
	 * Check the Account with the Server
	 *
	 * @param  null  $token
	 * @param  string  $redirect_to
	 *
	 * @throws Exception
	 */
	public function checkAccountApi( $token = null, $redirect_to = '' ) {

		/**
		 * LEGAL WARNING
		 *
		 * This code is part of WP Ghost’s proprietary license validation system.
		 *
		 * Tampering, removing, altering, or redistributing this functionality
		 * (including publishing nulled versions) is strictly prohibited.
		 *
		 * Violators are subject to DMCA takedown, account termination,
		 * financial claims, and legal prosecution.
		 *
		 * Monitoring mechanisms are in place.
		 */

		$domain  = ( HMWP_Classes_Tools::isMultisites() && defined( 'BLOG_ID_CURRENT_SITE' ) ) ? get_home_url( BLOG_ID_CURRENT_SITE ) : site_url();
		$options = array( 'timeout' => 30, 'headers' => array( 'USER-URL' => $domain ) );
		$url     = _HMWP_API_SITE_ . '/api/wp/token';

		if ( isset( $token ) ) {
			$response = HMWP_Classes_Tools::hmwp_remote_post( $url, array(
				'token'      => $token,
				'activation' => true,
				'url'        => $domain
			), $options );
		} else {
			$response = HMWP_Classes_Tools::hmwp_remote_get( $url, array(), $options );
		}

		//Check API response if valid
		if ( $response && $response = json_decode( $response, true ) ) {

			//On error, show error message
			if ( isset( $response['error'] ) ) {

				if ( isset( $response['message'] ) && $response['message'] <> '' ) {
					//Show error message if set
					HMWP_Classes_Error::setNotification( $response['message'], 'notice', false );
				}

			} else {

				//Update the plugin details
				$response      = array_intersect_key( $response, HMWP_Classes_Tools::$options );
				HMWP_Classes_Tools::$options = array_replace( HMWP_Classes_Tools::$options, $response );
				HMWP_Classes_Tools::saveOptions();

				//redirect to plugin settings if all good
				if ( $redirect_to <> '' ) {
					if ( wp_safe_redirect( esc_url_raw( $redirect_to ) ) ) {
						exit;
					}
				}

			}

		} else {
			HMWP_Classes_Error::setNotification(
				sprintf(
				/* translators: %s: Account URL link. */
					esc_html__( 'CONNECTION ERROR! Make sure your website can access: %s', 'hide-my-wp' ),
					'<a href="' . esc_url( _HMWP_ACCOUNT_SITE_ ) . '" target="_blank">' . esc_html( _HMWP_ACCOUNT_SITE_ ) . '</a>'
				)
				. '<br />'
				. sprintf(
				/* translators: 1: Opening strong tag, 2: Closing strong tag, 3: Opening link tag, 4: Closing link tag. */
					esc_html__( 'Ask your host to check outbound blocks and whitelist IP %1$s 116.203.193.175 %2$s for remote access! %3$s Read More %4$s', 'hide-my-wp' ),
					'<strong>',
					'</strong>',
					'<a href="' . esc_url( HMWP_Classes_Tools::getOption( 'hmwp_plugin_website' ) . '/kb/connection-error-make-sure-your-website-can-access-https-account-wpghost-com/' ) . '" target="_blank">',
					'</a>'
				),
				'notice',
				false
			);
		}

	}

    /**
     * Called when an action is triggered
     *
     * @throws Exception
     */
	public function action() {
        // Call the parent class's action method
        parent::action();

        // Check if the current user has the 'hmwp_manage_settings' capability
        if ( ! HMWP_Classes_Tools::userCan( HMWP_CAPABILITY ) ) {
			return;
		}

        // Check if the action is 'hmwp_connect'
		if ( HMWP_Classes_Tools::getValue( 'action' ) == 'hmwp_connect' ) {

            // If 'hmwp_debug' is set, add a debug request action
            if ( HMWP_Classes_Tools::getValue( 'hmwp_debug' ) ) {
				add_action( 'hmwp_debug_request', function( $url, $options, $response ) {
                    // Display the options and response for debugging purposes
                    HMWP_Classes_Error::showError( '<pre>' . print_r( json_decode( wp_json_encode( $options ), true ), true ) . '</pre>' ); //phpcs:ignore
					HMWP_Classes_Error::showError( '<pre>' . print_r( json_decode( wp_json_encode( $response ), true ), true ) . '</pre>' ); //phpcs:ignore
                    // If the response is a WP_Error, terminate the script
                    if ( is_wp_error( $response ) ) {
						die();
					}
				}, 11, 3 );

			}

            // Retrieve the token and the redirect URL from the settings
            $token = HMWP_Classes_Tools::getValue( 'hmwp_token', '' );

			$redirect_to = HMWP_Classes_Tools::getSettingsUrl();
            // Check if the token is not empty
            if ( $token <> '' ) {
                // Validate the token format using a regular expression
                if ( preg_match( '/^[a-z0-9\-]{32}$/i', $token ) ) {
                    // Call the checkAccountApi function with the token and redirect URL
	                HMWP_Classes_ObjController::getClass( 'HMWP_Controllers_Connect' )->checkAccountApi( $token, $redirect_to );
				} else {
                    // Display an error notification if the token format is invalid
                    HMWP_Classes_Error::setNotification( esc_html__( 'ERROR! Please make sure you use a valid token to activate the plugin', 'hide-my-wp' ) );
				}
			} else {
                // Display an error notification if the token is empty
                HMWP_Classes_Error::setNotification( esc_html__( 'ERROR! Please make sure you use the right token to activate the plugin', 'hide-my-wp' ) );
			}
		}
	}

}
