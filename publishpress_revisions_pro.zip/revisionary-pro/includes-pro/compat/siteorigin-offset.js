(function () {
    'use strict';
    function start() {
        const bar = document.querySelector('#pp_revisions_top_bar[data-rvy-editor-shell="siteorigin"]');
        if (!bar) return;
        function updateEditor() {
            const open = Array.from(document.querySelectorAll('body > .so-panels-live-editor')).some(editor =>
                window.getComputedStyle(editor).display !== 'none' && editor.getClientRects().length > 0
            );
            const changed = document.body.classList.contains('rvy-siteorigin-live-editor') !== open;
            document.body.classList.toggle('rvy-siteorigin-live-editor', open);
            bar.hidden = !open;
            if (open) {
                const height = Math.ceil(bar.getBoundingClientRect().height);
                const value = height + 'px';
                if (document.body.style.getPropertyValue('--rvy-siteorigin-bar-height') !== value) {
                    document.body.style.setProperty('--rvy-siteorigin-bar-height', value);
                }
            }
            if (changed) window.dispatchEvent(new Event('resize'));
        }
        updateEditor();
        const observer = new MutationObserver(updateEditor);
        observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['style', 'class'] });
        if (typeof ResizeObserver !== 'undefined') new ResizeObserver(updateEditor).observe(bar);
        window.addEventListener('resize', updateEditor);
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true }); else start();
})();
