<?php
/** SiteGround Speed Optimizer exclusions for private revision/editor state. */
defined('ABSPATH') || exit;

final class RevisionarySiteGround {
    public static function init() {
        // These lists also feed the file-cache configuration. Register them
        // on every request, rather than only while a revision is being edited.
        add_filter('sgo_bypass_query_params', [__CLASS__, 'queryParams']);
        add_filter('sgo_html_minify_exclude_params', [__CLASS__, 'queryParams']);
        foreach (['sgo_js_minify_exclude', 'sgo_javascript_combine_exclude', 'sgo_js_async_exclude'] as $hook) {
            add_filter($hook, [__CLASS__, 'scripts']);
        }
        add_filter('sgo_rqs_exclude', [__CLASS__, 'versionedScripts']);
        add_filter('sgo_javascript_combine_excluded_inline_content', [__CLASS__, 'inlineScripts']);
    }
    public static function queryParams($values) {
        return array_values(array_unique(array_merge((array) $values, [
            'rv_preview', 'rvy_preview', 'rvy_embed', 'elementor-preview',
            '_rvy_builder_revision', 'rvy_builder_frame',
        ])));
    }
    public static function scripts($values) {
        return array_values(array_unique(array_merge((array) $values, ['rvy-elementor-revision-workflow', 'revisionary-builder-notice', 'rvy-divi-workflow', 'revisionary-siteorigin-workflow'])));
    }
    public static function versionedScripts($values) {
        return array_values(array_unique(array_merge((array) $values, ['elementor-workflow.js', 'builder-notice.js', 'builder-workflow.js', 'divi-workflow.js', 'siteorigin-workflow.js'])));
    }
    public static function inlineScripts($values) {
        return array_values(array_unique(array_merge((array) $values, ['window.RevisionaryElementorWorkflow'])));
    }
}
