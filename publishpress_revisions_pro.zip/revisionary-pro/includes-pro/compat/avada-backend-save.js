/** Wait for Avada's asynchronous back-end shortcode serializer, before native save. */
(function (window, $) {
    'use strict';
    if (!window.RevisionaryEditorSave) return;
    window.RevisionaryEditorSave.addPreparation(function () {
        var app = window.FusionPageBuilderApp;
        if (!app || !$('#fusion_toggle_builder').hasClass('fusion_builder_is_active')) return;
        if (typeof app.builderToShortcodes !== 'function' || app.pauseBuilder) throw new Error(window.rvyObjEdit.saveError);
        return new Promise(function (resolve, reject) {
            var timer, quiet;
            function finish() { window.clearTimeout(timer); $(document).off('fusion-builder-content-updated.rvyFullSave', done); resolve(); }
            function done() {
                // Avada may already have an older 500ms serialization queued.
                // Let all content-updated events settle before saving the form.
                window.clearTimeout(quiet); quiet = window.setTimeout(finish, 550);
            }
            $(document).on('fusion-builder-content-updated.rvyFullSave', done);
            timer = window.setTimeout(function () { window.clearTimeout(quiet); $(document).off('fusion-builder-content-updated.rvyFullSave', done); reject(new Error(window.rvyObjEdit.saveError)); }, 10000);
            try { app.builderToShortcodes(); }
            catch (error) { window.clearTimeout(timer); window.clearTimeout(quiet); $(document).off('fusion-builder-content-updated.rvyFullSave', done); reject(error); }
        });
    });
})(window, window.jQuery);
