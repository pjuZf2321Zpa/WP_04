<?php
/** Revision-scoped transport for reviewed builder save contracts. */
defined('ABSPATH') || exit;

final class RevisionaryBuilderWorkflow {
    private static $saving = false;
    private static $siteoriginSavedLayout = null;
    private static $siteoriginRuntimeEnqueued = false;
    private static $bricksRevisorUserId = 0;
    private static $bricksRevisorUserCaps = [];
    private static $bricksRevisorCapKey = '';
    public static function init() {
        // This general queue authorization fix also applies without builder editing.
        add_filter('revisionary_queue_row_actions', [__CLASS__, 'filterUnauthorizedApprovalActions'], PHP_INT_MAX, 2);
        add_filter('revisionary_hide_front_revision_indicator', [__CLASS__, 'hideFrontRevisionIndicator'], 10, 2);
        add_filter('revisionary_suppress_preview_bar', [__CLASS__, 'suppressPreviewBar'], 10, 2);
        add_filter('wp_redirect', [__CLASS__, 'siteoriginSubmitRedirect'], PHP_INT_MAX, 2);
        add_filter('revisionary_preview_submit_url', [__CLASS__, 'siteoriginSubmitUrl'], 10, 2);
        // Remove SeedProd's generated image initializer from regular and revision front-end output.
        add_filter('the_content', [__CLASS__, 'suppressSeedprodImageHelper'], PHP_INT_MAX);
        if (rvy_get_option('permissions_compat_mode')) { return; }
        // Breakdance 2.8 and 3 resolve role access from this JSON option.
        // Absence is not an explicit denial; retain any stored Revisor choice.
        add_filter('option_breakdance_settings_permissions', [__CLASS__, 'breakdanceRevisorRoleDefault']);
        add_filter('default_option_breakdance_settings_permissions', [__CLASS__, 'breakdanceRevisorRoleDefault']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'sharedResourceEditorAssets']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'siteoriginPreviewBarAssets']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'siteoriginWorkflowAssets'], 1000);
        add_action('admin_footer', [__CLASS__, 'siteoriginPreviewBar']);
        add_action('elementor/editor/after_enqueue_scripts', [__CLASS__, 'sharedResourceEditorAssets']);
        add_action('wp_enqueue_scripts', [__CLASS__, 'sharedResourceEditorAssets']);
        add_action('fl_ajax_before_call_action', [__CLASS__, 'guardBeaverSharedMutation'], -10000);
        add_action('init', [__CLASS__, 'bricksRevisorAccess'], 0);
        // Bricks 2.4 can load its capability classes after the early init
        // callbacks, and the main query is not available until `wp`. Recheck
        // then so the scoped grant is in place before the builder is rendered.
        add_action('wp', [__CLASS__, 'bricksRevisorAccess'], 0);
        add_filter('user_has_cap', [__CLASS__, 'filterBricksRevisorCaps'], 100, 4);
        add_filter('get_user_metadata', [__CLASS__, 'filterBricksRevisorUserMeta'], 100, 4);
        add_action('current_screen', [__CLASS__, 'wpbakeryEntry'], 0);
        add_action('template_redirect', [__CLASS__, 'divi5Entry'], -10001);
        add_filter('revisionary_create_revision_redirect', [__CLASS__, 'divi5CreateRedirect'], 20, 2);
        add_filter('revisionary_create_revision_redirect', [__CLASS__, 'filterConflictingBuilderRedirect'], PHP_INT_MAX, 2);
        add_filter('revisionary_create_revision_redirect', [__CLASS__, 'filterMatchingBuilderRedirect'], PHP_INT_MAX, 2);
        // WPBakery can terminate a disabled-role request during init, before
        // current_screen. Validate revision entry before its native mode gate.
        add_action('vc_before_init', [__CLASS__, 'wpbakeryEntry'], 0);
        add_filter('revisionary_queue_row_actions', [__CLASS__, 'links'], 20, 2);
        add_filter('revisionary_queue_row_actions', [__CLASS__, 'filterConflictingBuilderLinks'], 10000, 2);
        add_filter('page_row_actions', [__CLASS__, 'siteoriginPageRowActions'], 20, 2);
        add_filter('post_row_actions', [__CLASS__, 'siteoriginPageRowActions'], 20, 2);
        // The queue's generic Edit Revision action uses get_edit_post_link().
        // Core's post editor rejects workflow revisions before many builders
        // can initialize, so route supported builder revisions to their native
        // editor entry while preserving revision and builder permission checks.
        add_filter('get_edit_post_link', [__CLASS__, 'queueEditLink'], 100, 3);
        add_action('revisionary_option_ui_revision_creation', [__CLASS__, 'revisionCreationNotice']);
        foreach (['backend_editor', 'frontend_editor'] as $part) {
            add_filter("vc_role_access_with_{$part}_can", [__CLASS__, 'wpbakeryRevisorAccess'], 10, 3);
            // WPBakery also resolves access from the current-user state. Keep
            // Revisor access consistent when its role setting is disabled.
            add_filter("vc_user_access_with_{$part}_get_state", [__CLASS__, 'wpbakeryRevisorUserAccess'], 10, 2);
        }
        add_filter('bricks/builder/data_post_id', [__CLASS__, 'bricksDataPost'], PHP_INT_MAX);
        add_filter('vc_frontend_editor_iframe_url', [__CLASS__, 'wpbakeryIframe']);
        foreach (['admin_head', 'wp_head', 'breakdance_builder_head'] as $hook) { add_action($hook, [__CLASS__, 'runtime'], 0); }
        add_action('admin_init', [__CLASS__, 'guardForm'], -1001);
        add_filter('revisionary_editor_save_verified', [__CLASS__, 'verifyBackendSave'], 10, 3);
        add_filter('siteorigin_panels_data_pre_save', [__CLASS__, 'siteoriginLayout'], PHP_INT_MAX, 3);
        add_filter('redirect_post_location', [__CLASS__, 'siteoriginRedirect'], PHP_INT_MAX, 2);
        // SiteOrigin blocks the panels_data meta capability unless a user has
        // unfiltered_html. Revisors can edit this field only on their own
        // workflow revisions; the guarded form/save path retains its nonce and
        // revision checks, without granting unfiltered_html to the role.
        add_filter('map_meta_cap', [__CLASS__, 'siteoriginRevisorMetaAccess'], 100, 4);
        add_action('template_redirect', [__CLASS__, 'guardFrontend'], -10000);
        add_action('admin_init', [__CLASS__, 'guardAjax'], -1000);
        add_action('admin_init', [__CLASS__, 'guardOtherBuilderEntry'], -1002);
        add_action('admin_init', [__CLASS__, 'guardWPBakerySharedTemplate'], -1004);
        // Vc_Templates_Panel_Editor uses vc_save_template / vc_delete_template
        // to mutate the shared wpb_js_templates option, separately from vc_save.
        // Retain the older save action as a compatibility alias.
        foreach (['vc_save_template', 'vc_delete_template', 'wpb_save_template'] as $action) {
            add_action('wp_ajax_' . $action, [__CLASS__, 'guardWPBakerySharedTemplate'], -10000);
        }
        add_filter('rest_pre_dispatch', [__CLASS__, 'guardRest'], 5, 3);
        add_filter('rest_pre_insert_wp_block', [__CLASS__, 'guardCorePatternMutation'], -100, 2);
        add_filter('wp_insert_post_data', [__CLASS__, 'preserveStatus'], PHP_INT_MAX, 2);
        // Elementor's native Save to Library action writes elementor_library
        // posts through a separate AJAX operation. It does not carry the
        // guarded builder nonce, so stop those writes at the post boundary
        // whenever the originating document is a workflow revision.
        add_filter('wp_insert_post_data', [__CLASS__, 'guardElementorLibraryMutation'], -100, 2);
        // Divi 4's Save to Library creates et_pb_layout posts outside the
        // guarded page save, so reject those writes at the post boundary.
        add_filter('wp_insert_post_data', [__CLASS__, 'guardDivi4LibraryMutation'], -100, 2);
        add_action('wp_ajax_revisionary_builder_transition', [__CLASS__, 'transition']);
        add_action('revision_applied', [__CLASS__, 'applied'], 20, 2);
        add_filter('_wp_post_revision_fields', [__CLASS__, 'revisionFields'], 20, 2);
        add_filter('revisionary_apply_revision_fields', [__CLASS__, 'applyFields'], 20, 3);
    }
    public static function noticeScript() {
        wp_register_script('revisionary-builder-notice', plugins_url('includes-pro/compat/builder-notice.js', REVISIONARY_PRO_FILE), [], PUBLISHPRESS_REVISIONS_PRO_VERSION, false);
        return 'revisionary-builder-notice';
    }
    public static function wpbakeryActive() { return defined('WPB_VC_VERSION') && function_exists('wpbakery'); }
    /** Hide the floating Revisions link while an integrated builder owns the frontend canvas. */
    public static function hideFrontRevisionIndicator($hide, $post_id) {
        if ($hide) { return true; }
        $query = $_GET; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        if (isset($query['fb-edit']) || in_array($query['builder'] ?? '', ['true', '1'], true) || isset($query['bricks']) || isset($query['et_fb']) || isset($query['fl_builder'])
            || isset($query['so_live_editor']) || isset($query['siteorigin_panels_live_editor'])
            || isset($query['breakdance_iframe'])
            || ('builder' === ($query['breakdance'] ?? '') || 'breakdance' === ($query['page'] ?? ''))
            || 'seedprod_lite_builder' === ($query['page'] ?? '')
            || 'vc_inline' === ($query['vc_action'] ?? '') || isset($query['vc_editable'])) {
            return true;
        }
        // Elementor's preview iframe is the builder canvas. The integration
        // adds rvy_embed to its configured preview URL, but Elementor can
        // reload the canvas using elementor-preview alone (for example while
        // restoring the editor state), so do not require our secondary flag.
        return isset($query['elementor-preview']);
    }
    /** Suppress the full revision preview bar in the same editor contexts. */
    public static function suppressPreviewBar($suppress, $revision_id) {
        // SiteOrigin's Live Editor uses the frontend revision preview as its
        // editing canvas. Keep the standard Revisions bar visible there; the
        // floating indicator remains hidden by hideFrontRevisionIndicator().
        if (!$suppress && (isset($_GET['so_live_editor']) || isset($_GET['siteorigin_panels_live_editor']))) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
            $post = self::requestContext();
            if (is_wp_error($post) || !$post) { $post = get_post($revision_id); }
            if ($post && 'siteorigin' === self::builder($post) && rvy_in_revision_workflow($post)) {
                return false;
            }
        }
        return self::hideFrontRevisionIndicator($suppress, $revision_id);
    }
    /** Grant WPBakery editor access based on revision contributor capabilities. */
    public static function wpbakeryRevisorAccess($allowed, $role, $rule = '') {
        return is_object($role) && rvy_has_revisor_capabilities((array) ($role->capabilities ?? [])) ? true : $allowed;
    }
    public static function wpbakeryRevisorUserAccess($state, $part) {
        $user = function_exists('wp_get_current_user') ? wp_get_current_user() : null;
        return is_object($user) && rvy_has_revisor_capabilities((array) $user->allcaps) ? true : $state;
    }
    public static function revisionCreationNotice() {
        if (!self::wpbakeryActive()) { return; }
        echo '<p class="description rvy-builder-conflict-notice">'
            . esc_html__('Frontend revision editing for other page builders is unavailable while WPBakery is active; visual comparison remains available.', 'revisionary-pro')
            . '</p>';
    }
    /** Keep the queue's Approve action aligned with the approval endpoint capability check. */
    public static function filterUnauthorizedApprovalActions($actions, $post) {
        if (!rvy_in_revision_workflow($post)
            || !in_array($post->post_mime_type, ['draft-revision', 'pending-revision', 'future-revision'], true)
            || is_content_administrator_rvy()
            || current_user_can('approve_revision', $post->ID)
            || (defined('REVISIONARY_LEGACY_APPROVE_PERMISSIONS') && current_user_can('edit_post', rvy_post_id($post->ID)))) {
            return $actions;
        }
        unset($actions['publish'], $actions['approve'], $actions['decline']);
        return $actions;
    }
    public static function filterConflictingBuilderLinks($actions, $post) {
        if (!self::wpbakeryActive() || !rvy_in_revision_workflow($post)) { return $actions; }
        foreach (['avada', 'siteorigin', 'divi', 'divi5', 'bricks', 'elementor', 'beaver', 'seedprod', 'breakdance28', 'breakdance3'] as $key) {
            unset($actions[$key]);
        }
        return $actions;
    }
    /** Legacy builder creation filters run independently of editingSupported(). */
    public static function filterConflictingBuilderRedirect($url, $id) {
        if (!self::wpbakeryActive() || empty($_REQUEST['front'])) { return $url; } // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        $post = get_post(absint($id));
        if (!$post || !rvy_in_revision_workflow($post)) { return $url; }
        $query = [];
        parse_str(wp_parse_url($url, PHP_URL_QUERY) ?: '', $query);
        $competing = 'elementor' === ($query['action'] ?? '')
            || 'seedprod_lite_builder' === ($query['page'] ?? '')
            || 'breakdance' === ($query['page'] ?? '');
        foreach (['fb-edit', 'builder', 'et_fb', 'fl_builder', 'bricks', 'so_live_editor', 'siteorigin_panels_live_editor', 'breakdance', 'seedprod'] as $key) {
            if (isset($query[$key])) { $competing = true; }
        }
        return $competing ? admin_url('post.php?post=' . $post->ID . '&action=edit') : $url;
    }
    /** Prefer the main post's supported builder over post-type-wide redirects. */
    public static function filterMatchingBuilderRedirect($url, $revision_id) {
        if (empty($_REQUEST['front'])) { return $url; } // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        $revision = get_post(absint($revision_id));
        if (!$revision || !rvy_in_revision_workflow($revision)) { return $url; }
        $parent_id = rvy_post_id($revision->ID);
        $parent = $parent_id ? get_post($parent_id) : null;
        if (!$parent) { return $url; }

        $builder = self::revisionCreationBuilder($parent);
        if (!$builder) { return $url; }
        if (!self::pageLocal($revision) || !current_user_can('edit_post', $revision->ID)) {
            // An earlier plugin may have selected its editor from post type
            // alone. If this page's builder is unavailable, use WordPress.
            return admin_url('post.php?post=' . $revision->ID . '&action=edit');
        }
        if (in_array($builder, ['avada', 'divi5', 'bricks', 'siteorigin', 'wpbakery', 'seedprod', 'breakdance28', 'breakdance3'], true)) {
            if (!self::editingSupported($builder) || !self::nativePermission($revision, $builder)) {
                return admin_url('post.php?post=' . $revision->ID . '&action=edit');
            }
            return self::editorUrl($revision, $builder) ?: $url;
        }

        // Legacy native integrations do not use editingSupported()'s version table.
        // Preserve conflict restrictions before selecting their frontend routes.
        if (rvy_get_option('permissions_compat_mode') || self::wpbakeryActive()) { return admin_url('post.php?post=' . $revision->ID . '&action=edit'); }
        if ('beaver' === $builder) {
            $args = ['fl_builder' => ''];
            return add_query_arg($args, rvy_preview_url($revision));
        }
        if ('divi' === $builder) {
            return add_query_arg(['et_fb' => 1, 'PageSpeed' => 'off'], rvy_preview_url($revision));
        }
        if ('elementor' === $builder) {
            return admin_url('post.php?post=' . $revision->ID . '&action=elementor');
        }
        return $url;
    }
    /** Resolve the active builder from the published page's own layout data. */
    private static function revisionCreationBuilder($post) {
        foreach (['avada', 'bricks', 'divi5', 'siteorigin', 'wpbakery', 'seedprod', 'breakdance28', 'breakdance3', 'beaver', 'divi', 'elementor'] as $name) {
            $adapter = RevisionaryBuilderCompare::frontendAdapter($name);
            if ($adapter && $adapter->uses($post)) { return $name; }
        }
        return self::builder($post);
    }
    public static function suppressSeedprodImageHelper($content) {
        // This escaped script-comment placeholder is generated inside a div
        // whose ID is unique to SeedProd image dynamic-tag initialization.
        return preg_replace('#<div\b[^>]*\bid=["\']sp-image-dynamic-tags-js-[^"\']+["\'][^>]*>.*?</div>#is', '', $content);
    }
    private static function seedprod($id) { return get_post_meta($id, '_seedprod_page', true) || get_post_meta($id, '_seedprod_edited_with_seedprod', true); }
    public static function revisionFields($fields, $post) {
        $id = is_array($post) ? ($post['ID'] ?? 0) : ($post->ID ?? 0);
        if ($id && self::seedprod($id)) { $fields['post_content_filtered'] = 'SeedProd settings'; }
        return $fields;
    }
    public static function applyFields($fields, $revision, $published) {
        if (self::seedprod($revision->ID)) {
            $settings = $revision->post_content_filtered ?: get_post_meta($revision->ID, '_rvy_seedprod_settings', true);
            if (is_array(json_decode($settings, true))) { $fields['post_content_filtered'] = $settings; }
        }
        return $fields;
    }
    public static function editingSupported($name) {
        if (rvy_get_option('permissions_compat_mode')) { return false; }
        // WPBakery's site-wide iframe transient can capture other builder frames.
        // Restrict editing only; comparison adapters remain registered.
        if ('wpbakery' !== $name && self::wpbakeryActive()) { return false; }
        $versions = [
            'avada' => ['AVADA_VERSION', '1.0.0', '1.1.0-alpha'],
            'divi5' => ['ET_BUILDER_VERSION', '5.14', '5.15'],
            'wpbakery' => ['WPB_VC_VERSION', '8.7.4', '8.8'],
            'siteorigin' => ['SITEORIGIN_PANELS_VERSION', '2.37', '2.39'],
            'seedprod' => ['SEEDPROD_VERSION', '6.20.10', '6.21'],
            'breakdance28' => ['__BREAKDANCE_VERSION', '2.8.3', '2.9.0-alpha'],
            'breakdance3' => ['__BREAKDANCE_VERSION', '3.0.0-rc.2', '3.1'],
            'bricks' => ['BRICKS_VERSION', '2.4.3', '2.5.0-alpha'],
        ];
        $range = $versions[$name] ?? null;
        $supported = $range && defined($range[0]) && version_compare(constant($range[0]), $range[1], '>=') && version_compare(constant($range[0]), $range[2], '<');
        if ('avada' === $name) { $supported = RevisionaryAvadaIntegration::editingSupported(); }
        return (bool) apply_filters('revisionary_builder_revision_editing_supported', $supported, $name);
    }
    public static function builder($post) {
        // Native layout data takes precedence over incidental WPBakery flags.
        $bricks_mode = false;
        foreach (['avada', 'divi5', 'bricks', 'siteorigin', 'wpbakery', 'seedprod', 'breakdance28', 'breakdance3'] as $name) {
            $adapter = RevisionaryBuilderCompare::frontendAdapter($name);
            if ($adapter && $adapter->uses($post)) { return $bricks_mode && 'wpbakery' === $name ? 'bricks' : $name; }
            // A saved Bricks editor mode can outlive its content snapshot (for
            // example, an older unfinished draft). Keep its editing session
            // guarded even when there is no tree for visual comparison.
            if ($adapter && 'bricks' === $name && rvy_in_revision_workflow($post)
                && 'bricks' === get_post_meta($post->ID, '_bricks_editor_mode', true)) { $bricks_mode = true; }
        }
        if ($bricks_mode) { return 'bricks'; }
        // A new Breakdance 3 page has no tree until its first native save.
        // Resolve it for editing without inventing layout metadata or enrolling
        // nonempty WordPress documents in the builder.
        if (self::editingSupported('breakdance3') && RevisionaryBuilderCompare::frontendAdapter('breakdance3')
            && 'page' === $post->post_type) {
            foreach (['beaver', 'divi', 'elementor'] as $other) {
                $adapter = RevisionaryBuilderCompare::frontendAdapter($other);
                if ($adapter && $adapter->uses($post)) { return ''; }
            }
            if ('breakdance' === get_post_meta($post->ID, '_breakdance_page_settings', true)) { return 'breakdance3'; }
            if ('' === trim($post->post_content)) {
                $parent = rvy_in_revision_workflow($post) ? get_post(rvy_post_id($post)) : null;
                if (!$parent || ('page' === $parent->post_type && '' === trim($parent->post_content))) { return 'breakdance3'; }
            }
        }
        return '';
    }
    public static function pageLocal($post) {
        $parent = get_post(rvy_post_id($post)); $type = $parent ? get_post_type_object($parent->post_type) : null;
        return $parent && $parent->ID !== $post->ID && $parent->post_type === $post->post_type && $type && $type->public
            && !in_array($post->post_type, ['attachment', 'revision', 'wp_block', 'wp_template', 'wp_template_part'], true);
    }
    /** Authorize the current Revisor for the Bricks editor's runtime capability check. */
    public static function bricksRevisorAccess() {
        if (!class_exists('Bricks\\Capabilities')) { return; }
        $user = wp_get_current_user();
        if (!empty($user->caps['bricks_no_access'])) { return; }
        // Bricks checks full builder access when opening element settings. Give
        // Revisors that UI access only on a guarded workflow revision; the
        // revision save adapter still restricts writes to page-local content.
        if ('GET' !== sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD'] ?? 'GET')) || 'run' !== sanitize_key(wp_unslash($_GET['bricks'] ?? '')) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
            || !rvy_has_revisor_capabilities((array) $user->allcaps)) { return; }
        $id = absint($_GET['page_id'] ?? ($_GET['p'] ?? 0)); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        if (!$id && function_exists('is_singular') && is_singular()) { $id = get_queried_object_id(); }
        $post = $id ? get_post($id) : null;
        self::grantBricksRevisorAccess($post);
    }
    /** Keep Bricks' direct WP_User capability reads consistent with has_cap(). */
    private static function grantBricksRevisorAccess($post) {
        $user = wp_get_current_user();
        if (!rvy_has_revisor_capabilities((array) $user->allcaps) || !empty($user->caps['bricks_no_access'])
            || !empty($user->allcaps['bricks_no_access'])) { return; }
        if (!$post || 'bricks' !== self::builder($post) || !rvy_in_revision_workflow($post)
            || !self::pageLocal($post) || !current_user_can('edit_post', $post->ID)) { return; }
        $caps = $user->allcaps;
        // Preserve explicit full access and explicit denials. Content-only
        // access is insufficient for Bricks' element settings panels.
        if (!empty($caps['bricks_no_access'])) { return; }
        self::$bricksRevisorUserId = (int) $user->ID;
        self::$bricksRevisorCapKey = $user->cap_key;
        self::$bricksRevisorUserCaps = $user->caps;
        self::$bricksRevisorUserCaps['bricks_full_access'] = true;
        // get_current_user_permissions() reads these properties directly.
        // get_user_by() creates another WP_User, so its capability metadata
        // also needs the same request-only projection (never update_user_meta).
        $user->caps['bricks_full_access'] = true;
        $user->allcaps['bricks_full_access'] = true;
    }
    public static function filterBricksRevisorUserMeta($value, $user_id, $meta_key, $single) {
        if (self::$bricksRevisorUserId && (int) $user_id === self::$bricksRevisorUserId
            && $meta_key === self::$bricksRevisorCapKey) {
            return [self::$bricksRevisorUserCaps];
        }
        return $value;
    }
    /** Bricks checks its full-access capability through current_user_can(). */
    public static function filterBricksRevisorCaps($allcaps, $caps, $args, $user) {
        if (!self::$bricksRevisorUserId || !is_object($user) || (int) $user->ID !== self::$bricksRevisorUserId
            || !rvy_has_revisor_capabilities((array) $user->allcaps) || !empty($user->caps['bricks_no_access'])) { return $allcaps; }
        $allcaps['bricks_full_access'] = true;
        return $allcaps;
    }
    /** Give Revisors a builder action on the parent row for their own SiteOrigin revision. */
    public static function siteoriginPageRowActions($actions, $page) {
        if (!is_object($page) || !rvy_has_revisor_capabilities((array) wp_get_current_user()->allcaps)
            || !self::pageLocalTarget($page) || 'siteorigin' !== self::builder($page)) { return $actions; }
        $revisions = get_posts([
            'author' => get_current_user_id(),
            'post_type' => $page->post_type,
            'post_status' => 'any',
            'posts_per_page' => 1000, // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page -- Retain existing integration behavior per the PHPCS review scope.
            'orderby' => 'modified',
            'order' => 'DESC',
            'fields' => 'ids',
            'no_found_rows' => true,
        ]);
        foreach ($revisions as $revision_id) {
            $revision = get_post($revision_id);
            if (!$revision || !rvy_in_revision_workflow($revision)
                || !in_array($revision->post_mime_type, ['draft-revision', 'pending-revision'], true)
                || (int) rvy_post_id($revision) !== (int) $page->ID
                || !current_user_can('edit_post', $revision->ID)
                || 'siteorigin' !== self::builder($revision) || !self::pageLocal($revision)
                || !self::nativePermission($revision, 'siteorigin')) { continue; }
            $url = self::editorUrl($revision, 'siteorigin');
            if ($url) {
                $adapter = RevisionaryBuilderCompare::frontendAdapter('siteorigin');
                $actions['siteorigin'] = '<a href="' . esc_url($url) . '">' . esc_html($adapter->label()) . '</a>';
                break;
            }
        }
        return $actions;
    }
    private static function pageLocalTarget($post) {
        $type = get_post_type_object($post->post_type);
        return $type && $type->public && !in_array($post->post_type, ['attachment', 'revision', 'wp_block', 'wp_template', 'wp_template_part'], true)
            && !rvy_in_revision_workflow($post);
    }
    /** Allow the native SiteOrigin layout editor on authorized revisions. */
    public static function siteoriginRevisorMetaAccess($caps, $cap, $user_id, $args) {
        if (!in_array($cap, ['add_post_meta', 'edit_post_meta', 'delete_post_meta'], true)
            || !isset($args[0], $args[1]) || !is_string($args[1]) || 'panels_data' !== wp_unslash($args[1])) { return $caps; }
        $post_id = absint($args[0]);
        $user = get_userdata($user_id);
        $post = $post_id ? get_post($post_id) : null;
        if (!$user || !rvy_has_revisor_capabilities((array) $user->allcaps) || !$post
            || !rvy_in_revision_workflow($post) || 'siteorigin' !== self::builder($post)
            || !user_can($user_id, 'edit_post', $post_id)) { return $caps; }
        // Rebuild the normal object-level edit capability mapping. This
        // removes SiteOrigin's unfiltered_html-only denial for panels_data,
        // while retaining the Revisor's existing revision edit permission.
        return map_meta_cap('edit_post', $user_id, $post_id);
    }
    /** Route revision frontend-editor URLs to WPBakery's native backend editor. */
    public static function wpbakeryEntry() {
        if ('GET' !== sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD'] ?? 'GET')) || wp_doing_ajax()
            || 'vc_inline' !== sanitize_key(wp_unslash($_GET['vc_action'] ?? ''))) { return; } // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        if (!class_exists('Vc_Frontend_Editor') && function_exists('vc_frontend_editor')) { vc_frontend_editor(); }
        // Native backend/toolbar links omit our session. Redirect a validated
        // revision GET to its guarded entry; writes still require both nonces.
        if (empty($_GET['_rvy_builder_revision'])) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
            $id = absint($_GET['post_id'] ?? 0); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
            $post = $id ? get_post($id) : null;
            if (!$post || !rvy_in_revision_workflow($post) || 'wpbakery' !== self::builder($post)) { return; }
            if (class_exists('Vc_Frontend_Editor') && !Vc_Frontend_Editor::frontendEditorEnabled()) {
                wp_die(esc_html__('WPBakery frontend editing is disabled for your role. Ask an administrator to enable it in WPBakery Role Manager.', 'revisionary-pro'), '', ['response' => 403]);
            }
            $post = self::context($id, wp_create_nonce('rvy-builder-edit:' . $id));
            if (is_wp_error($post)) { wp_die(esc_html($post->get_error_message()), '', ['response' => 403]); }
            wp_safe_redirect(self::editorUrl($post, 'wpbakery'));
            exit;
        }
        if (class_exists('Vc_Frontend_Editor') && !Vc_Frontend_Editor::frontendEditorEnabled()) {
            wp_die(esc_html__('WPBakery frontend editing is disabled for your role. Ask an administrator to enable it in WPBakery Role Manager.', 'revisionary-pro'), '', ['response' => 403]);
        }
        $post = self::requestContext();
        if (is_wp_error($post)) { wp_die(esc_html($post->get_error_message()), '', ['response' => 403]); }
    }
    public static function breakdanceRevisorRoleDefault($value) {
        if (!defined('__BREAKDANCE_VERSION')
            || version_compare(__BREAKDANCE_VERSION, '2.8.3', '<')
            || version_compare(__BREAKDANCE_VERSION, '3.1', '>=')) { return $value; }
        $permissions = is_string($value) ? json_decode($value, true) : null;
        if (!is_array($permissions)) {
            // Preserve malformed nonempty settings rather than granting access.
            if ($value) { return $value; }
            $permissions = defined('BREAKDANCE_DEFAULT_ROLES_PERMISSIONS') ? BREAKDANCE_DEFAULT_ROLES_PERMISSIONS : [];
        }
        // Some sites use a customized Editor role as the workflow approver.
        // Breakdance's saved role permission can explicitly deny that role
        // (while the Revisor role is Full Interface), preventing the guarded
        // revision action from ever reaching our editor session. Project the
        // current revision contributor's role to Full Interface only on the
        // queue and on its validated, page-local revision edit request. The
        // option is never written, and ordinary pages keep their saved access.
        if (self::breakdanceRevisionAccessContext()) {
            foreach ((array) wp_get_current_user()->roles as $role) {
                $permissions[$role] = 'full';
            }
            return wp_json_encode($permissions);
        }
        // Do not grant a role Full Interface access on unrelated native requests.
        return $value;
    }
    private static function breakdanceRevisionAccessContext() {
        $user = wp_get_current_user();
        if (!is_user_logged_in() || !rvy_has_revisor_capabilities((array) $user->allcaps)) { return false; }
        if (is_admin() && !wp_doing_ajax() && !(defined('REST_REQUEST') && REST_REQUEST)
            && 'GET' === ($_SERVER['REQUEST_METHOD'] ?? 'GET') // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- Strict HTTP method comparison only; this value is never stored or rendered.
            && 'revisionary-q' === sanitize_key(wp_unslash($_GET['page'] ?? ''))) { return true; } // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        $id = absint($_GET['_rvy_builder_revision'] ?? ($_REQUEST['_rvy_builder_revision'] ?? 0)); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        if (!$id) { return false; }
        // An option lookup can run before the transport guard. Never project
        // Full Interface permissions into an unsigned AJAX/REST/write request.
        if (wp_doing_ajax() || (defined('REST_REQUEST') && REST_REQUEST)
            || 'GET' !== ($_SERVER['REQUEST_METHOD'] ?? 'GET')) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- Strict HTTP method comparison only; this value is never stored or rendered.
            $nonce = $_REQUEST['_rvy_builder_nonce'] ?? ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- Require a string and unslash it for wp_verify_nonce immediately below; malformed tokens must fail verification.
            if (!is_string($nonce) || !wp_verify_nonce(wp_unslash($nonce), 'rvy-builder-edit:' . $id)) { return false; }
            foreach (['post_id', 'postId', 'id'] as $key) {
                if (isset($_REQUEST[$key]) && (!is_scalar($_REQUEST[$key]) || (string) $id !== (string) $_REQUEST[$key])) { return false; } // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- Reject non-scalar or non-identical save targets; normalization must not turn conflicting input into an accepted ID.
            }
        }
        $post = get_post($id);
        return $post && rvy_in_revision_workflow($post)
            && in_array($post->post_mime_type, ['draft-revision', 'pending-revision'], true)
            && current_user_can('edit_post', $id) && self::pageLocal($post)
            && in_array(self::builder($post), ['breakdance28', 'breakdance3'], true);
    }
    private static function nativePermission($post, $name) {
        if ('wpbakery' === $name) { return class_exists('Vc_Frontend_Editor') && Vc_Frontend_Editor::frontendEditorEnabled() && function_exists('vc_user_access') && vc_user_access()->wpAny('edit_posts', 'edit_pages')->canEdit($post->ID)->get(); }
        if ('divi5' === $name) { return self::divi5RoleAllowed() && function_exists('et_fb_current_user_can_save') && et_fb_current_user_can_save($post->ID, $post->post_status); }
        if ('bricks' === $name) {
            // Bricks' default role settings can deny a customized Editor even
            // when Revisions grants the exact revision edit capability. Apply
            // the same request-scoped Full Access projection used by the
            // native editor entry before testing its builder permission. The
            // grant is limited to an editable, page-local workflow revision
            // and respects an explicit bricks_no_access cap.
            self::grantBricksRevisorAccess($post);
            return RevisionaryBricksIntegration::permission($post->ID);
        }
        // Revisor saves are intercepted by save() and remain scoped to the
        // selected revision. Requiring unfiltered_html here prevents the
        // guarded session from loading, so SeedProd falls through to its
        // native capability check and rejects otherwise authorized Revisors.
        // The context() checks above still require edit_post on this revision;
        // the centralized save validates both its session and exact target.
        if ('seedprod' === $name) { return current_user_can('edit_post', $post->ID); }
        if (in_array($name, ['breakdance28', 'breakdance3'], true)) { return function_exists('Breakdance\\Permissions\\hasMinimumPermission') && \Breakdance\Permissions\hasMinimumPermission('edit')
            && \Breakdance\Permissions\isPostTypeAllowed($post->post_type) && !in_array($post->post_type, BREAKDANCE_BANNED_POST_TYPES, true); }
        return true;
    }
    private static function error($code, $message, $status = 403) { return new WP_Error($code, $message, ['status' => $status]); }
    public static function context($id, $nonce) {
        if (!is_user_logged_in() || !wp_verify_nonce($nonce, 'rvy-builder-edit:' . $id)) { return self::error('rvy_builder_forbidden', __('Invalid revision editing session.', 'revisionary-pro')); }
        $post = get_post($id); $name = $post ? self::builder($post) : '';
        if (!$post || !rvy_in_revision_workflow($post) || !in_array($post->post_mime_type, ['draft-revision', 'pending-revision'], true)
            || !current_user_can('edit_post', $id) || !self::pageLocal($post) || !self::editingSupported($name) || !self::nativePermission($post, $name)) {
            return self::error('rvy_builder_forbidden', __('You cannot edit this revision.', 'revisionary-pro'));
        }
        return $post;
    }
    private static function requestContext($request = null) {
        $id = sanitize_text_field(wp_unslash($request ? $request->get_param('_rvy_builder_revision') : ($_REQUEST['_rvy_builder_revision'] ?? 0))); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        if (!$id) { return null; }
        // Native editor GETs are authorized from the selected page, not a
        // bookmarked nonce. This also keeps iframe/link filters in the same
        // refreshed session. AJAX, REST and all writes still use signed data.
        if (!$request && 'GET' === sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD'] ?? 'GET')) && !wp_doing_ajax()) {
            foreach (['avadaEditorContext', 'breakdanceEditorContext', 'wpbakeryEditorContext', 'divi5EditorContext', 'bricksEditorContext', 'seedprodEditorContext'] as $resolver) {
                $editor = self::$resolver();
                if (null !== $editor) { return $editor; }
            }
        }
        $nonce = sanitize_text_field(wp_unslash($request ? $request->get_param('_rvy_builder_nonce') : ($_REQUEST['_rvy_builder_nonce'] ?? ''))); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        return self::context(absint($id), $nonce);
    }
    public static function links($actions, $post) {
        if (!rvy_in_revision_workflow($post) || !current_user_can('edit_post', $post->ID) || !in_array($post->post_mime_type, ['draft-revision', 'pending-revision'], true)) { return $actions; }
        $name = self::builder($post);
        if (!$name || !self::editingSupported($name) || !self::pageLocal($post) || !self::nativePermission($post, $name)) { return $actions; }
        $url = self::editorUrl($post, $name);
        if ('divi5' === $name) { unset($actions['divi']); }
        if ($url) { $actions[$name] = '<a href="' . esc_url($url) . '">' . esc_html(RevisionaryBuilderCompare::frontendAdapter($name)->label()) . '</a>'; }
        return $actions;
    }
    /** Route generic queue Edit links through the guarded native builder editor. */
    public static function queueEditLink($link, $post_id, $context = 'display') {
        if (!$link || empty($_REQUEST['page']) || 'revisionary-q' !== sanitize_key(wp_unslash($_REQUEST['page']))) { return $link; } // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        $post = get_post($post_id);
        if (!$post || !rvy_in_revision_workflow($post)
            || !in_array($post->post_mime_type, ['draft-revision', 'pending-revision'], true)
            || !current_user_can('edit_post', $post->ID)) { return $link; }
        $name = self::builder($post);
        if (!$name || !self::editingSupported($name) || !self::pageLocal($post) || !self::nativePermission($post, $name)) { return $link; }
        if (in_array($name, ['avada', 'divi', 'divi5', 'wpbakery', 'siteorigin'], true)) {
            return add_query_arg([
                '_rvy_builder_revision' => $post->ID,
                '_rvy_builder_nonce' => wp_create_nonce('rvy-builder-edit:' . $post->ID),
            ], admin_url('post.php?post=' . (int) $post->ID . '&action=edit'));
        }
        return self::editorUrl($post, $name) ?: $link;
    }
    /** Native visual builder entry; backend workflow saves retain their own post form. */
    public static function editorUrl($post, $name) {
        if ('wpbakery' !== $name && self::wpbakeryActive()) { return ''; }
        switch ($name) {
            case 'avada': $url = add_query_arg('fb-edit', 1, rvy_preview_url($post)); break;
            case 'divi':
            case 'divi5': $url = add_query_arg(['et_fb' => 1, 'PageSpeed' => 'off'], rvy_preview_url($post)); break;
            case 'wpbakery': $url = Vc_Frontend_Editor::getInlineUrl('', (string) $post->ID); break;
            // SiteOrigin initializes its native editor and preview nonce in
            // wp-admin. A bare frontend Live Editor flag skips that startup.
            case 'siteorigin': $url = admin_url('post.php?post=' . (int) $post->ID . '&action=edit'); break;
            case 'bricks': $url = add_query_arg(BRICKS_BUILDER_PARAM, 'run', rvy_preview_url($post)); break;
            case 'seedprod': $url = add_query_arg(['page' => 'seedprod_lite_builder', 'id' => $post->ID], admin_url('admin.php')); break;
            default: $url = function_exists('Breakdance\\Admin\\get_builder_loader_url') ? \Breakdance\Admin\get_builder_loader_url($post->ID) : ''; break;
        }
        return $url ? add_query_arg(['_rvy_builder_revision' => $post->ID, '_rvy_builder_nonce' => wp_create_nonce('rvy-builder-edit:' . $post->ID)], $url) : '';
    }
    /** Return to SiteOrigin's native Live Editor after a workflow transition. */
    public static function siteoriginEditorUrl($post) {
        $url = self::editorUrl($post, 'siteorigin');
        return $url ? add_query_arg('so_live_editor', 1, $url) : '';
    }
    /** Keep standard preview Submit actions directed to revision preview. */
    public static function siteoriginSubmitUrl($url, $revision_id) {
        $post = self::requestContext();
        if (is_wp_error($post) || !$post || (int) $post->ID !== (int) $revision_id) { $post = get_post($revision_id); }
        if (!$post || 'siteorigin' !== self::builder($post) || !rvy_in_revision_workflow($post)) { return $url; }
        return remove_query_arg('rvy_redirect', $url);
    }
    /** Handle older SiteOrigin links carrying an editor return intent. */
    public static function siteoriginSubmitRedirect($location, $status = 302) {
        if (!is_admin() || 'rvy-revisions' !== sanitize_key($_GET['page'] ?? '') // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
            || 'submit' !== sanitize_key($_GET['action'] ?? '') || 'edit' !== sanitize_key($_GET['rvy_redirect'] ?? '')) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
            return $location;
        }
        $revision_id = absint($_GET['revision'] ?? 0); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        $post = $revision_id ? get_post($revision_id) : null;
        if (!$post || 'siteorigin' !== self::builder($post) || !rvy_in_revision_workflow($post)) { return $location; }
        return self::siteoriginPreviewUrl($post) ?: $location;
    }
    /** Build the non-editor revision preview used by Bricks' View on frontend control. */
    public static function frontendPreviewUrl($post) {
        if (!$post || 'bricks' !== self::builder($post)) { return ''; }
        return remove_query_arg(
            [defined('BRICKS_BUILDER_PARAM') ? BRICKS_BUILDER_PARAM : 'bricks', '_rvy_builder_revision', '_rvy_builder_nonce'],
            rvy_preview_url($post)
        );
    }
    /** Build a clean SiteOrigin revision preview for the editor's Preview control. */
    public static function siteoriginPreviewUrl($post) {
        if (!$post || 'siteorigin' !== self::builder($post)) { return ''; }
        return remove_query_arg(
            ['so_live_editor', 'siteorigin_panels_live_editor', '_rvy_builder_revision', '_rvy_builder_nonce'],
            rvy_preview_url($post)
        );
    }
    public static function bricksDataPost($id) {
        $post = self::requestContext();
        if (!$post) { $post = self::bricksEditorContext(); }
        return $post && !is_wp_error($post) && 'bricks' === self::builder($post) ? $post->ID : $id;
    }
    public static function wpbakeryIframe($url) {
        $post = self::requestContext();
        if (!$post || is_wp_error($post) || 'wpbakery' !== self::builder($post)) { return $url; }
        parse_str(wp_parse_url($url, PHP_URL_QUERY) ?: '', $query);
        $query = array_intersect_key($query, array_fill_keys(['vc_editable', 'vc_post_id', '_vcnonce'], true));
        return add_query_arg(array_merge($query, ['vc_post_id' => $post->ID, '_rvy_builder_revision' => $post->ID, '_rvy_builder_nonce' => wp_create_nonce('rvy-builder-edit:' . $post->ID)]), rvy_preview_url($post));
    }
    public static function runtime() {
        $post = self::requestContext();
        if (!$post) { $post = self::avadaEditorContext(); }
        // Divi's native Classic Editor and toolbar links do not carry our session.
        // Bootstrap only a read-only editor GET; saves must still present the nonce.
        if (!$post) { $post = self::divi5EditorContext(); }
        if (!$post) { $post = self::bricksEditorContext(); }
        // Breakdance normalizes its builder URL and drops unknown query args.
        // Rebuild the session from its authenticated editor GET so the runtime
        // can scope saves in the outer builder window as well as the preview.
        if (!$post) { $post = self::breakdanceEditorContext(); }
        if (!$post) { $post = self::wpbakeryEditorContext(); }
        if (!$post) { $post = self::seedprodEditorContext(); }
        // A bookmarked SiteOrigin editor URL can carry an expired nonce. Only
        // an authenticated GET for the same revision may bootstrap a fresh
        // session; context() still authorizes the revision and every write.
        if (!$post || is_wp_error($post)) {
            $editorPost = self::siteoriginEditorContext();
            if ($editorPost && !is_wp_error($editorPost)) { $post = $editorPost; }
        }
        if (!$post || is_wp_error($post)) { return; }
        $canApprove = self::canApprove($post);
        $config = [
            'builder' => self::builder($post),
            'id' => $post->ID, 'nonce' => wp_create_nonce('rvy-builder-edit:' . $post->ID), 'ajax' => admin_url('admin-ajax.php'), 'compare' => rvy_compare_url($post->ID),
            // Bricks' native View on frontend link otherwise points to the
            // revision permalink directly, bypassing Revisionary preview state.
            'frontendPreview' => self::frontendPreviewUrl($post),
            'preview' => self::siteoriginPreviewUrl($post),
            'revisionPreview' => 'seedprod' === self::builder($post) ? rvy_preview_url($post) : ('avada' === self::builder($post) ? remove_query_arg(['fb-edit', 'builder', 'builder_id', '_rvy_builder_revision', '_rvy_builder_nonce'], rvy_preview_url($post)) : (in_array(self::builder($post), ['breakdance28', 'breakdance3'], true)
                ? remove_query_arg(['breakdance', 'breakdance_iframe', 'breakdance_open_document', '_rvy_builder_revision', '_rvy_builder_nonce'], rvy_preview_url($post)) : '')),
            'sharedResourceMessage' => __('Shared Avada resources cannot be modified when editing a revision.', 'revisionary-pro'),
            'actionsLabel' => __('Revision actions', 'revisionary-pro'),
            'previewLabel' => __('Preview Revision', 'revisionary-pro'),
            'canSubmit' => 'draft-revision' === $post->post_mime_type && (is_content_administrator_rvy() || current_user_can('set_revision_pending-revision', $post->ID)),
            'canApprove' => $canApprove,
            'updateRevision' => __('Update Revision', 'revisionary-pro'),
            'update' => __('Update'),
            'menuApprove' => __('Approve', 'revisionary-pro'),
            'menuSubmit' => __('Submit', 'revisionary-pro'),
            'menuCompare' => __('Compare', 'revisionary-pro'),
            'submit' => __('Submit Revision', 'revisionary-pro'), 'approve' => __('Approve Revision', 'revisionary-pro'),
            'saveFirst' => __('Save your builder changes successfully before submitting or approving.', 'revisionary-pro'),
        ];
        if ('siteorigin' === $config['builder'] && is_admin() && !wp_doing_ajax()) {
            if (self::$siteoriginRuntimeEnqueued) { return; }
            self::$siteoriginRuntimeEnqueued = true;
            wp_enqueue_script('revisionary-siteorigin-workflow', plugins_url('includes-pro/compat/siteorigin-workflow.js', REVISIONARY_PRO_FILE), ['jquery', self::noticeScript()], PUBLISHPRESS_REVISIONS_PRO_VERSION, false);
            wp_add_inline_script('revisionary-siteorigin-workflow', 'window.RevisionaryBuilderSession=' . wp_json_encode($config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) . ';', 'before');
            return;
        }
        echo '<script src="' . esc_url(add_query_arg('ver', PUBLISHPRESS_REVISIONS_PRO_VERSION, plugins_url('includes-pro/compat/builder-notice.js', REVISIONARY_PRO_FILE))) . '"></script>';
        echo '<script>window.RevisionaryBuilderSession=' . wp_json_encode($config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) . ';</script>';
        $script = 'siteorigin' === self::builder($post) ? 'siteorigin-workflow.js' : 'builder-workflow.js';
        $sessionAttribute = 'siteorigin' === self::builder($post)
            ? ' data-rvy-builder-session="' . esc_attr(wp_json_encode($config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT)) . '"'
            : '';
        echo '<script src="' . esc_url(add_query_arg('ver', PUBLISHPRESS_REVISIONS_PRO_VERSION . ('avada' === self::builder($post) ? '-avada6' : ''), plugins_url('includes-pro/compat/' . $script, REVISIONARY_PRO_FILE))) . '"' . $sessionAttribute . '></script>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Retain existing integration behavior per the PHPCS review scope.
    }
    public static function avadaEditorContext() { return RevisionaryAvadaIntegration::editorContext(); }
    public static function divi5EditorContext() {
        if ('GET' !== sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD'] ?? 'GET')) || wp_doing_ajax() || empty($_GET['et_fb']) || !is_user_logged_in()) { return null; } // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        $id = absint($_GET['preview_id'] ?? ($_GET['page_id'] ?? ($_GET['p'] ?? 0))); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        $post = $id ? get_post($id) : null;
        if (!$post || 'divi5' !== self::builder($post) || !rvy_in_revision_workflow($post)) { return null; }
        $target = isset($_GET['_rvy_builder_revision']) ? absint($_GET['_rvy_builder_revision']) : (isset($_REQUEST['_rvy_builder_revision']) ? absint($_REQUEST['_rvy_builder_revision']) : null); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        if (null !== $target && $id !== absint($target)) {
            return self::error('rvy_builder_target', __('Only the selected revision can be edited in this session.', 'revisionary-pro'));
        }
        return self::context($id, wp_create_nonce('rvy-builder-edit:' . $id));
    }
    private static function divi5RoleAllowed() {
        // Divi's can-save helper checks WordPress caps, not Role Editor access.
        if (!function_exists('et_pb_is_allowed') || !et_pb_is_allowed('use_visual_builder')) { return false; }
        $role = 'ET\\Builder\\Framework\\UserRole\\UserRole';
        return !class_exists($role) || $role::can_current_user_use_visual_builder();
    }
    /** Normalize legacy/frontend entry before Divi builds its app-frame URL. */
    public static function divi5Entry() {
        if ('GET' !== sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD'] ?? 'GET')) || empty($_GET['et_fb']) || self::wpbakeryActive()) { return; } // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        $id = absint($_GET['preview_id'] ?? ($_GET['page_id'] ?? ($_GET['p'] ?? 0))); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        $post = $id ? get_post($id) : null;
        if (!$post || !rvy_in_revision_workflow($post) || 'divi5' !== self::builder($post)) { return; }
        if (!self::divi5RoleAllowed()) {
            wp_die(esc_html__('Divi Visual Builder access is disabled for your role. Ask an administrator to enable it in Divi Role Editor.', 'revisionary-pro'), '', ['response' => 403]);
        }
        $post = self::divi5EditorContext();
        if (!$post || is_wp_error($post)) {
            wp_die(esc_html($post && is_wp_error($post) ? $post->get_error_message() : __('You cannot edit this revision.', 'revisionary-pro')), '', ['response' => 403]);
        }
        if (!isset($_GET['_rvy_builder_revision'])) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
            $url = self::editorUrl($post, 'divi5');
            // A child app window must remain a child after normalization.
            if ('1' === sanitize_key(wp_unslash($_GET['app_window'] ?? ''))) { $url = add_query_arg('app_window', '1', $url); } // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
            wp_safe_redirect($url);
            exit;
        }
    }
    /** Legacy Divi 5 builder URLs may still be opened from old queue links. */
    public static function divi5AdminEntry() {
        global $pagenow;
        if ('GET' !== sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD'] ?? 'GET')) || wp_doing_ajax()
            || 'post.php' !== $pagenow || 'edit' !== sanitize_key(wp_unslash($_GET['action'] ?? ''))) { return; } // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        $id = absint($_GET['post'] ?? 0); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        $post = $id ? get_post($id) : null;
        if (!$post || !rvy_in_revision_workflow($post) || 'divi5' !== self::builder($post) || !self::editingSupported('divi5')) { return; }
        $target = isset($_GET['_rvy_builder_revision']) ? absint($_GET['_rvy_builder_revision']) : (isset($_REQUEST['_rvy_builder_revision']) ? absint($_REQUEST['_rvy_builder_revision']) : null); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        if (null !== $target && $id !== absint($target)) {
            wp_die(esc_html__('Only the selected revision can be edited in this session.', 'revisionary-pro'), '', ['response' => 403]);
        }
        $post = self::context($post->ID, wp_create_nonce('rvy-builder-edit:' . $post->ID));
        if (is_wp_error($post)) { wp_die(esc_html($post->get_error_message()), '', ['response' => 403]); }
        // The revision is now edited in the normal WordPress backend form.
        // Leave post.php in control so Divi 5's native blocks and workflow UI
        // share the standard full-save lifecycle.
    }
    public static function divi5CreateRedirect($url, $id) {
        if (empty($_REQUEST['front']) || defined('PP_REVISIONS_DIVI_NO_REDIRECT')) { return $url; } // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        $id = absint($id);
        $post = $id ? get_post($id) : null;
        if (!$post || !rvy_in_revision_workflow($post) || 'divi5' !== self::builder($post)) { return $url; }
        $context = self::context($id, wp_create_nonce('rvy-builder-edit:' . $id));
        return is_wp_error($context) ? admin_url('post.php?post=' . $id . '&action=edit') : self::editorUrl($context, 'divi5');
    }
    /** Authenticate native Bricks editor entry without authorizing unguarded saves. */
    public static function bricksEditorContext() {
        if ('GET' !== sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD'] ?? 'GET')) || wp_doing_ajax()
            || 'run' !== sanitize_key(wp_unslash($_GET['bricks'] ?? '')) || !is_user_logged_in()) { return null; } // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        $id = absint($_GET['page_id'] ?? ($_GET['p'] ?? 0)); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        if (!$id && is_singular()) { $id = get_queried_object_id(); }
        $post = $id ? get_post($id) : null;
        if (!$post || 'bricks' !== self::builder($post) || !rvy_in_revision_workflow($post)) { return null; }
        $target = isset($_GET['_rvy_builder_revision']) ? absint($_GET['_rvy_builder_revision']) : (isset($_REQUEST['_rvy_builder_revision']) ? absint($_REQUEST['_rvy_builder_revision']) : null); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        if (null !== $target && $id !== absint($target)) {
            return self::error('rvy_builder_target', __('Only the selected revision can be edited in this session.', 'revisionary-pro'));
        }
        // Reuse revision type, edit capability, native permission and page-scope
        // checks. AJAX writes still require the nonce emitted by runtime().
        return self::context($id, wp_create_nonce('rvy-builder-edit:' . $id));
    }
    /** Breakdance strips guarded query args from its editor and preview URLs. */
    public static function breakdanceEditorContext() {
        if ('GET' !== sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD'] ?? 'GET')) || wp_doing_ajax() || !is_user_logged_in()) { return null; }
        $builder = isset($_GET['breakdance']) && 'builder' === sanitize_key(wp_unslash($_GET['breakdance'])); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        $iframe = !empty($_GET['breakdance_iframe']); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        if (!$builder && !$iframe) { return null; }
        $id = absint($_GET['id'] ?? ($_GET['breakdance_open_document'] ?? ($_GET['page_id'] ?? ($_GET['p'] ?? 0)))); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        $target = isset($_GET['_rvy_builder_revision']) ? absint($_GET['_rvy_builder_revision']) : (isset($_REQUEST['_rvy_builder_revision']) ? absint($_REQUEST['_rvy_builder_revision']) : null); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        if (null !== $target && $id !== absint($target)) {
            return self::error('rvy_builder_target', __('Only the selected revision can be edited in this session.', 'revisionary-pro'));
        }
        $post = $id ? get_post($id) : null;
        if (!$post || !in_array(self::builder($post), ['breakdance28', 'breakdance3'], true) || !rvy_in_revision_workflow($post)) { return null; }
        // This GET is the native builder entry. context() still enforces the
        // workflow status, edit capability, page-local scope and native access.
        return self::context($id, wp_create_nonce('rvy-builder-edit:' . $id));
    }
    /** Authorize native WPBakery editor GETs without renewing write requests. */
    public static function wpbakeryEditorContext() {
        global $pagenow;
        if ('GET' !== sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD'] ?? 'GET')) || wp_doing_ajax() || !is_user_logged_in()) { return null; }
        $inline = 'vc_inline' === sanitize_key(wp_unslash($_GET['vc_action'] ?? '')); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        $canvas = isset($_GET['vc_editable']); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        $backend = 'post.php' === $pagenow && 'edit' === sanitize_key(wp_unslash($_GET['action'] ?? '')); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        if (!$inline && !$canvas && !$backend) { return null; }
        $id = absint($inline ? ($_GET['post_id'] ?? 0) : ($canvas ? ($_GET['vc_post_id'] ?? 0) : ($_GET['post'] ?? 0))); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        $post = $id ? get_post($id) : null;
        if (!$post || 'wpbakery' !== self::builder($post) || !rvy_in_revision_workflow($post)) { return null; }
        $target = isset($_GET['_rvy_builder_revision']) ? absint($_GET['_rvy_builder_revision']) : (isset($_REQUEST['_rvy_builder_revision']) ? absint($_REQUEST['_rvy_builder_revision']) : null); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        if (null !== $target && $id !== absint($target)) {
            return self::error('rvy_builder_target', __('Only the selected revision can be edited in this session.', 'revisionary-pro'));
        }
        return self::context($id, wp_create_nonce('rvy-builder-edit:' . $id));
    }
    /** Bootstrap SeedProd's native launcher from an authorized read-only GET. */
    public static function seedprodEditorContext() {
        global $pagenow;
        if ('GET' !== sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD'] ?? 'GET')) || wp_doing_ajax() || !is_user_logged_in()
            || 'admin.php' !== $pagenow || 'seedprod_lite_builder' !== sanitize_key(wp_unslash($_GET['page'] ?? ''))) { return null; } // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        $id = absint($_GET['id'] ?? 0); $post = $id ? get_post($id) : null; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        if (!$post || 'seedprod' !== self::builder($post) || !rvy_in_revision_workflow($post)) { return null; }
        $target = isset($_GET['_rvy_builder_revision']) ? absint($_GET['_rvy_builder_revision']) : (isset($_REQUEST['_rvy_builder_revision']) ? absint($_REQUEST['_rvy_builder_revision']) : null); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        if (null !== $target && $id !== absint($target)) {
            return self::error('rvy_builder_target', __('Only the selected revision can be edited in this session.', 'revisionary-pro'));
        }
        return self::context($id, wp_create_nonce('rvy-builder-edit:' . $id));
    }
    /** Load transport through WordPress, with jQuery ready before SiteOrigin starts. */
    public static function siteoriginWorkflowAssets() {
        $post = self::siteoriginEditorContext();
        if ($post && !is_wp_error($post)) { self::runtime(); }
    }
    /** Keep the standard bar in the persistent admin shell, outside the AJAX preview. */
    public static function siteoriginPreviewBarAssets() {
        $post = self::siteoriginEditorContext();
        if (!$post || is_wp_error($post)) { return; }
        wp_enqueue_style('revisionary-front', plugins_url('revisionary-front.css', REVISIONARY_FILE), [], PUBLISHPRESS_REVISIONS_PRO_VERSION);
        wp_enqueue_style('revisionary-siteorigin-editor', plugins_url('includes-pro/compat/siteorigin-editor.css', REVISIONARY_PRO_FILE), ['revisionary-front'], PUBLISHPRESS_REVISIONS_PRO_VERSION);
        // SiteOrigin 2.38's compiled CSS omits its inactive diagnostic state.
        wp_add_inline_style('revisionary-siteorigin-editor', '.so-panels-live-editor .so-preview-error:not(.so-active){display:none}');
        wp_enqueue_script('revisionary-preview-bar', plugins_url('revisionary-preview.js', REVISIONARY_FILE), ['jquery'], PUBLISHPRESS_REVISIONS_PRO_VERSION, true);
        wp_enqueue_script('revisionary-siteorigin-offset', plugins_url('includes-pro/compat/siteorigin-offset.js', REVISIONARY_PRO_FILE), ['revisionary-preview-bar'], PUBLISHPRESS_REVISIONS_PRO_VERSION, true);
    }
    public static function siteoriginPreviewBar() {
        $post = self::siteoriginEditorContext();
        if (!$post || is_wp_error($post)) { return; }
        // Load only the shared renderer. Constructing RevisionaryFront would
        // initialize frontend queries and preview metadata mirroring in admin.
        require_once dirname(REVISIONARY_FILE) . '/front_rvy.php';
        echo str_replace('data-rvy-editor-shell="siteorigin"', 'data-rvy-editor-shell="siteorigin" hidden', RevisionaryFront::previewBarHtml($post, rvy_post_id($post->ID), true)); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Retain existing integration behavior per the PHPCS review scope.
    }
    /** Native Classic/Live Editor entry is a GET; writes still require both nonces. */
    public static function siteoriginEditorContext() {
        global $pagenow;
        if ('GET' !== sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD'] ?? 'GET')) || wp_doing_ajax()
            || 'post.php' !== $pagenow || 'edit' !== sanitize_key(wp_unslash($_GET['action'] ?? '')) || !is_user_logged_in()) { return null; } // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        $id = absint($_GET['post'] ?? 0); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        if (isset($_GET['_rvy_builder_revision']) && $id !== absint($_GET['_rvy_builder_revision'])) { return null; } // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        $post = $id ? get_post($id) : null;
        if (!$post || 'siteorigin' !== self::builder($post) || !rvy_in_revision_workflow($post)) { return null; }
        return self::context($id, wp_create_nonce('rvy-builder-edit:' . $id));
    }
    /** Reject legacy frontend builder entry points while WPBakery owns iframe startup. */
    public static function guardOtherBuilderEntry() {
        if (!self::wpbakeryActive() || 'GET' !== sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD'] ?? 'GET')) || wp_doing_ajax()) { return; }
        $action = sanitize_key($_GET['action'] ?? ''); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        $page = sanitize_key($_GET['page'] ?? ''); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        $siteorigin = !empty($_GET['so_live_editor']) || !empty($_GET['siteorigin_panels_live_editor']); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        $legacyBuilder = in_array($action, ['elementor'], true) || 'seedprod_lite_builder' === $page || $siteorigin;
        if ('seedprod_lite_builder' === $page || isset($_GET['breakdance']) || 'breakdance' === $page) { $legacyBuilder = true; } // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        if (!$legacyBuilder) { return; }
        $id = absint($_GET['post'] ?? ($_GET['id'] ?? ($_GET['post_id'] ?? 0))); $post = $id ? get_post($id) : null; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        if ($post && rvy_in_revision_workflow($post)) {
            wp_die(esc_html__('Frontend revision editing for other page builders is unavailable while WPBakery Page Builder is active.', 'revisionary-pro'), '', ['response' => 403]);
        }
    }
    private static function siteoriginForm($id) {
        if ('POST' !== sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD'] ?? 'GET')) || wp_doing_ajax()
            || 'editpost' !== sanitize_key(wp_unslash($_POST['action'] ?? '')) || absint($_POST['post_ID'] ?? 0) !== (int) $id
            || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_sopanels_nonce'] ?? '')), 'save')
            || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce'] ?? '')), 'update-post_' . $id)) { return null; }
        $post = self::requestContext();
        return $post && !is_wp_error($post) && (int) $post->ID === (int) $id && 'siteorigin' === self::builder($post) ? $post : null;
    }
    /** Observe the final sanitized layout; never duplicate SiteOrigin's widget save processing. */
    public static function siteoriginLayout($data, $post, $id) {
        $native = 'editpost' === sanitize_key(wp_unslash($_POST['action'] ?? '')) && (int) $id === absint($_POST['post_ID'] ?? 0)
            && (!empty($_POST['_rvy_editor_transition']) || !empty($_POST['_rvy_editor_save_verify'])) && rvy_in_revision_workflow($id)
            && current_user_can('edit_post', $id)
            && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce'] ?? '')), 'update-post_' . $id)
            && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_sopanels_nonce'] ?? '')), 'save')
            && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_rvy_editor_transition_nonce'] ?? '')), 'rvy-editor-transition:' . $id);
        if ($native || self::siteoriginForm($id)) { self::$siteoriginSavedLayout = $data; }
        return $data;
    }
    /** Verify the sanitized SiteOrigin layout on the normal Classic save path. */
    public static function verifyBackendSave($verified, $id, $operation) {
        if (is_wp_error($verified) || !$verified || !isset($_POST['panels_data']) || 'siteorigin' !== self::builder(get_post($id))) { return $verified; } // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Retain existing integration behavior per the PHPCS review scope.
        $layout = self::$siteoriginSavedLayout;
        $empty = is_array($layout) && empty($layout['widgets']) && empty($layout['grids']);
        if (!is_array($layout) || ($empty ? metadata_exists('post', $id, 'panels_data') : get_post_meta($id, 'panels_data', true) !== $layout)) {
            return self::error('rvy_builder_save', __('The SiteOrigin layout could not be verified as saved. The revision action was not applied.', 'revisionary-pro'), 400);
        }
        return $verified;
    }
    public static function siteoriginRedirect($location, $id) {
        // The normal editor's full-save callback owns this action.
        if (!empty($_POST['_rvy_editor_transition'])) { return $location; } // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Retain existing integration behavior per the PHPCS review scope.
        if (!isset($_POST['_rvy_siteorigin_operation'])) { return $location; } // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Retain existing integration behavior per the PHPCS review scope.
        $post = self::siteoriginForm($id);
        if (!$post) { return $location; }
        $operation = sanitize_key(wp_unslash($_POST['_rvy_siteorigin_operation'])); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Retain existing integration behavior per the PHPCS review scope.
        $layout = self::$siteoriginSavedLayout;
        self::$siteoriginSavedLayout = null;
        $stored = get_post_meta($id, 'panels_data', true);
        // An invalid/rejected layout does not reach the native pre-save filter.
        // Confirm persistence after all native save_post callbacks have finished.
        $empty = is_array($layout) && empty($layout['widgets']) && empty($layout['grids']);
        if (!is_array($layout) || ($empty ? metadata_exists('post', $id, 'panels_data') : $stored !== $layout)) {
            wp_die(esc_html__('The SiteOrigin layout could not be verified as saved. The revision was not submitted or approved.', 'revisionary-pro'));
        }
        require_once dirname(REVISIONARY_FILE) . '/admin/revision-action_rvy.php';
        // Native save callbacks must not run a second time during approval.
        unset($_POST['panels_data'], $_POST['_sopanels_nonce']);
        if ('approve' === $operation && self::canApprove($post)) {
            $approval_url = add_query_arg('rvy_approval', 1, get_permalink(rvy_post_id($id)));
            $result = rvy_revision_approve($id);
        }
        elseif ('submit' === $operation && 'draft-revision' === $post->post_mime_type
            && (is_content_administrator_rvy() || current_user_can('set_revision_pending-revision', $id))) { $result = rvy_revision_submit($id); }
        else { wp_die(esc_html__('You cannot perform this revision action.', 'revisionary-pro'), '', ['response' => 403]); }
        if (false === $result || is_wp_error($result)) { wp_die(esc_html__('The layout was saved, but the revision action failed.', 'revisionary-pro')); }
        return 'approve' === $operation ? $approval_url : self::siteoriginPreviewUrl($post);
    }
    public static function preserveStatus($data, $postarr) {
        if (empty($postarr['ID'])) { return $data; }
        $post = get_post($postarr['ID']);
        if ($post && rvy_in_revision_workflow($post) && self::builder($post) && !self::$saving && self::requestContext()) { $data['post_status'] = $post->post_status; $data['post_mime_type'] = $post->post_mime_type; }
        return $data;
    }
    private static function elementorEditorRevisionId() {
        $ids = [];
        foreach (['initial_document_id', 'editor_post_id', 'post', 'post_id', 'document_id', 'id'] as $key) {
            if (isset($_REQUEST[$key]) && is_scalar($_REQUEST[$key])) { $ids[] = absint($_REQUEST[$key]); } // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        }
        // Elementor carries the active document in its JSON AJAX envelope.
        // Read IDs only; this helper never authorizes or performs a write.
        $decoded = is_string($_REQUEST['actions'] ?? null) ? json_decode(wp_unslash($_REQUEST['actions']), true) : null; // phpcs:ignore WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Structured builder payload; scalar IDs and native save data are validated separately.
        if (is_array($decoded)) {
            $walk = static function ($value) use (&$walk, &$ids) {
                if (!is_array($value)) { return; }
                foreach ($value as $key => $item) {
                    if (in_array((string) $key, ['id', 'document_id', 'post_id', 'initial_document_id'], true) && is_scalar($item)) { $ids[] = absint($item); }
                    if (is_array($item)) { $walk($item); }
                }
            };
            $walk($decoded);
        }
        foreach (array_unique(array_filter($ids)) as $id) {
            if (rvy_in_revision_workflow($id)) { return $id; }
        }
        return self::sharedResourceEditorRevisionId();
    }
    /** Resolve a workflow revision from a native editor's request or referrer. */
    public static function sharedResourceEditorRevisionId($request = null) {
        $ids = [];
        foreach (['_rvy_builder_revision', 'post', 'post_ID', 'post_id', 'page_id', 'vc_post_id', 'editor_post_id', 'initial_document_id'] as $key) {
            $value = absint(sanitize_text_field(wp_unslash($request ? $request->get_param($key) : ($_POST[$key] ?? ($_GET[$key] ?? ($_REQUEST[$key] ?? null)))))); // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
            if (is_scalar($value)) { $ids[] = absint($value); }
        }
        $referrers = [esc_url_raw(wp_unslash($_SERVER['HTTP_REFERER'] ?? '')), esc_url_raw(wp_unslash($_REQUEST['_wp_http_referer'] ?? ''))]; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        if (function_exists('wp_get_referer')) { $referrers[] = wp_get_referer(); }
        foreach ($referrers as $referrer) {
            if (!is_string($referrer) || '' === $referrer) { continue; }
            $query = [];
            parse_str((string) wp_parse_url($referrer, PHP_URL_QUERY), $query);
            foreach (['_rvy_builder_revision', 'post', 'post_ID', 'post_id', 'page_id', 'vc_post_id', 'editor_post_id', 'initial_document_id'] as $key) {
                if (isset($query[$key]) && is_scalar($query[$key])) { $ids[] = absint($query[$key]); }
            }
        }
        foreach (array_unique(array_filter($ids)) as $id) {
            if (rvy_in_revision_workflow($id)) { return $id; }
        }
        return 0;
    }
    private static function sharedResourceMessage($builder) {
        switch ($builder) {
            case 'wpbakery': return __('Shared WPBakery templates cannot be modified when editing a revision.', 'revisionary-pro');
            case 'elementor': return __('Shared Elementor templates cannot be modified when editing a revision.', 'revisionary-pro');
            case 'divi4': return __('Divi Library layouts cannot be modified when editing a revision.', 'revisionary-pro');
            case 'beaver': return __('Beaver Builder global settings cannot be modified when editing a revision.', 'revisionary-pro');
            case 'beaver-colors': return __('Shared Beaver Builder color presets cannot be modified when editing a revision.', 'revisionary-pro');
            default: return __('Synced patterns cannot be modified when editing a revision.', 'revisionary-pro');
        }
    }
    /** Explain blocked actions before native handlers show false success/errors. */
    public static function sharedResourceEditorAssets() {
        global $pagenow;
        $beaver = isset($_GET['fl_builder']) && class_exists('FLBuilderModel'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        $divi4 = isset($_GET['et_fb']) && defined('ET_BUILDER_VERSION') // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
            && version_compare(ET_BUILDER_VERSION, '5.0', '<');
        if (('post.php' !== $pagenow && !$beaver && !$divi4) || 'GET' !== sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD'] ?? 'GET'))) { return; }
        $id = absint($_GET['_rvy_builder_revision'] ?? ($_GET['post'] ?? ($_GET['post_id'] ?? ($_GET['page_id'] ?? 0)))); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        if (!$id && $beaver) { $id = absint(FLBuilderModel::get_post_id()); }
        $post = $id ? get_post($id) : null;
        if (!$post || !rvy_in_revision_workflow($post) || !current_user_can('edit_post', $id)) { return; }
        $builder = $divi4 ? 'divi4' : ($beaver ? 'beaver' : ('elementor' === sanitize_key(wp_unslash($_GET['action'] ?? '')) ? 'elementor' : (self::wpbakeryActive() ? 'wpbakery' : 'gutenberg'))); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        $handle = 'rvy-shared-resource-editor';
        wp_enqueue_script($handle, plugins_url('includes-pro/compat/shared-resource-editor.js', REVISIONARY_PRO_FILE), [], PUBLISHPRESS_REVISIONS_PRO_VERSION, true);
        wp_enqueue_style($handle, plugins_url('includes-pro/compat/shared-resource-editor.css', REVISIONARY_PRO_FILE), [], PUBLISHPRESS_REVISIONS_PRO_VERSION);
        wp_localize_script($handle, 'RevisionarySharedResourceEditor', [
            'builder' => $builder,
            'message' => self::sharedResourceMessage($builder),
            'dismiss' => __('Dismiss this notice.'),
            'labels' => [
                'createPattern' => __('Create pattern'),
                'editPattern' => __('Edit original'),
                'elementorSave' => __('Save as Template', 'elementor'),
                'diviSave' => __('Save To Library'),
            ],
        ]);
    }
    /** Beaver dispatches these writes on wp, outside WordPress admin-ajax. */
    public static function guardBeaverSharedMutation($action) {
        if (!in_array($action, ['save_global_settings', 'save_color_presets'], true)) { return; }
        $id = class_exists('FLBuilderModel') ? absint(FLBuilderModel::get_post_id()) : 0;
        if (!$id) { $id = self::sharedResourceEditorRevisionId(); }
        if (!$id || !rvy_in_revision_workflow($id)) { return; }
        $resource = 'save_color_presets' === $action ? 'beaver-colors' : 'beaver';
        wp_send_json_error(['message' => self::sharedResourceMessage($resource)], 403);
        exit;
    }
    /** Block shared library saves/deletions before WPBakery mutates its option. */
    public static function guardWPBakerySharedTemplate() {
        $action = sanitize_key($_POST['action'] ?? ($_GET['action'] ?? ($_REQUEST['action'] ?? ''))); // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        if (!in_array($action, ['vc_save_template', 'vc_delete_template', 'wpb_save_template'], true)
            || !self::sharedResourceEditorRevisionId()) { return; }
        wp_send_json_error(['message' => self::sharedResourceMessage('wpbakery')], 403);
        exit;
    }
    /** Gutenberg's synced pattern endpoint is separate from the guarded page save. */
    public static function guardCorePatternMutation($prepared_post, $request) {
        if (is_wp_error($prepared_post) || !self::sharedResourceEditorRevisionId($request)) { return $prepared_post; }
        return self::error('rvy_builder_shared', self::sharedResourceMessage('gutenberg'));
    }
    public static function guardElementorLibraryMutation($data, $postarr) {
        if ('elementor_library' !== ($data['post_type'] ?? '')) { return $data; }
        $revision_id = self::elementorEditorRevisionId();
        if (!$revision_id) { return $data; }

        // A template workflow revision is itself an elementor_library post.
        // Permit only that existing, editable revision; shared library writes
        // and writes to its published parent remain blocked.
        $target_id = absint($postarr['ID'] ?? 0);
        $revision = $target_id === $revision_id ? get_post($target_id) : null;
        if ($revision && 'elementor_library' === $revision->post_type
            && in_array(rvy_in_revision_workflow($revision), ['draft-revision', 'pending-revision'], true)
            && current_user_can('edit_post', $target_id)
            && in_array($data['post_status'] ?? '', ['draft', 'pending'], true)
            && in_array($data['post_mime_type'] ?? '', ['draft-revision', 'pending-revision'], true)
        ) {
            return $data;
        }

        wp_die(esc_html(self::sharedResourceMessage('elementor')), '', ['response' => 403]);
        return $data;
    }
    /** Divi 4's shared library is stored as et_pb_layout posts. */
    public static function guardDivi4LibraryMutation($data, $postarr) {
        if ('et_pb_layout' !== ($data['post_type'] ?? '') || !self::sharedResourceEditorRevisionId()) { return $data; }
        wp_die(esc_html(self::sharedResourceMessage('divi4')), '', ['response' => 403]);
        return $data;
    }
    /** Mirror the reviewed Divi 5.14 editor's page-settings defaults without saving them. */
    public static function divi5PageSettings($post) {
        global $wp_query;
        $previous_query = $wp_query;
        $wp_query = $wp_query ? clone $wp_query : new WP_Query(); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- Retain existing integration behavior per the PHPCS review scope.
        $wp_query->is_singular = true;
        try {
            $values = \ET\Builder\Framework\Settings\Settings::get_values('page', $post->ID);
        } finally {
            $wp_query = $previous_query; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- Retain existing integration behavior per the PHPCS review scope.
        }
        $defaults = [
            'abBounceRateLimit' => '5', 'abCurrentShortcode' => '', 'abStatsRefreshInterval' => '',
            'customCss' => '', 'enableAbTesting' => '', 'enableShortcodeTracking' => 'off',
            'overflowX' => '', 'overflowY' => '', 'postCategories' => '', 'postExcerpt' => '',
            'postImage' => '0', 'postProjectCategories' => '', 'postProjectTags' => '',
            'postTags' => '', 'postTitle' => '',
        ];
        $mapping = \ET\Builder\VisualBuilder\Saving\SavingUtility::get_page_settings_mapping();
        // These display values are also present in the editor's initial state.
        $mapping['darkTextColor'] = ['d4_key' => 'et_pb_dark_text_color'];
        $mapping['lightTextColor'] = ['d4_key' => 'et_pb_light_text_color'];
        foreach ($mapping as $key => $field) {
            if (isset($field['d4_key']) && isset($values[$field['d4_key']])) {
                $defaults[$key] = $values[$field['d4_key']];
            }
        }
        if ('' === ($defaults['enableShortcodeTracking'] ?? '')) { $defaults['enableShortcodeTracking'] = 'off'; }
        $inherited = !isset($values['et_pb_page_gutter_width_is_default']) || false !== $values['et_pb_page_gutter_width_is_default'];
        $defaults['pageGutterWidth'] = $inherited ? '' : ($values['et_pb_page_gutter_width'] ?? '');
        $defaults['pageGutterWidthIsDefault'] = $inherited ? '1' : '0';
        $defaults['pageZIndex'] = $values['et_pb_page_z_index'] ?? 'auto';
        return $defaults;
    }
    private static function divi5SharedSettingsUnchanged($settings, $post) {
        if (!is_array($settings)) { return false; }
        if (!$settings) { return true; }
        $baseline = self::divi5PageSettings($post);
        foreach ($settings as $key => $value) {
            // A preview URL is presentation data, never written by save_page_settings().
            if ('postImageUrl' === $key) { continue; }
            if (!array_key_exists($key, $baseline)) { return false; }
            $expected = $baseline[$key];
            if (is_array($value) || is_array($expected) || is_object($value) || is_object($expected)) {
                if ($value != $expected) { return false; }
            } elseif ((string) $value !== (string) $expected) { return false; }
        }
        return true;
    }
    /** Keep executable SeedProd settings behind WordPress's unfiltered_html capability. */
    private static function seedprodSettingsForSave($post, $raw) {
        if (!is_string($raw) || !is_array($settings = json_decode($raw, true))) {
            return self::error('rvy_builder_seedprod', 'Invalid SeedProd settings.', 400);
        }
        if (current_user_can('unfiltered_html')) { return $raw; }
        $baseline = json_decode((string) ($post->post_content_filtered ?? ''), true);
        if (!is_array($baseline)) { $baseline = []; }
        foreach (['header_scripts', 'footer_scripts'] as $key) {
            $expected = $baseline[$key] ?? '';
            if (array_key_exists($key, $settings) && $settings[$key] !== $expected) {
                return self::error('rvy_builder_seedprod_code', __('Custom scripts require unfiltered_html. Existing scripts must remain unchanged.', 'revisionary-pro'));
            }
            // Native content-only saves may omit fields hidden from the current user.
            if (array_key_exists($key, $baseline)) { $settings[$key] = $expected; }
            else { unset($settings[$key]); }
        }
        $content = $settings;
        unset($content['header_scripts'], $content['footer_scripts']);
        if (!self::seedprodSettingsSafe($content, $baseline)) {
            return self::error('rvy_builder_seedprod_code', __('Executable or unfiltered markup cannot be added or changed in this revision without unfiltered_html.', 'revisionary-pro'));
        }
        foreach ($content as $key => $value) { $settings[$key] = $value; }
        return wp_json_encode($settings);
    }
    /** Validate new markup while allowing an unchanged, previously stored code block. */
    private static function seedprodSettingsSafe(&$value, $baseline = null, $field = '') {
        if (is_array($value)) {
            // Freeze the complete block, including its type, rather than trusting
            // an unchanged string moved into a different execution context.
            if (isset($value['id'], $value['type']) && $value === $baseline) { return true; }
            foreach ($value as $key => &$item) {
                if (!self::seedprodSettingsSafe($item, is_array($baseline) ? ($baseline[$key] ?? null) : null, (string) $key)) { return false; }
            }
            unset($item);
            return true;
        }
        if (!is_string($value)) { return is_scalar($value) || null === $value; }
        // Plain text/CSS values are not HTML. KSES would otherwise encode
        // innocent ampersands and change the builder's text-field values.
        if (false !== strpos($value, '<')) { $value = wp_kses_post($value); }
        // Also inspect plain URL/CSS fields, where no HTML tag exists for KSES
        // to recognize. Decode entities and ignore control-space obfuscation.
        $decoded = html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $decoded = preg_replace('/[\x00-\x20\x7f]+/', '', $decoded);
        if (preg_match('/(?:^|[^a-z0-9+.-])(?:javascript|vbscript):/i', $decoded)) { return false; }
        // A prose field can legitimately contain "Data: A, B". Data URLs are
        // rejected in URL/CSS settings; HTML attributes are filtered above.
        return !preg_match('/url|href|src|link|image|background|css|style/i', $field)
            || !preg_match('/(?:^|[^a-z0-9+.-])data:/i', $decoded);
    }
    public static function validateSave($post, $name, $data) {
        if (self::builder($post) !== $name) { return self::error('rvy_builder_mismatch', 'Builder does not match this revision.'); }
        $found = false;
        // Reject conflicting aliases rather than validating only the first one.
        foreach (['post_id', 'lpage_id', 'id', 'postId'] as $key) {
            if (!array_key_exists($key, $data)) { continue; }
            if ((!is_int($data[$key]) && !is_string($data[$key]))
                || (string) $post->ID !== (string) $data[$key]) {
                return self::error('rvy_builder_target', __('Only the selected revision can be saved.', 'revisionary-pro'));
            }
            $found = true;
        }
        return $found ? true : self::error('rvy_builder_target', __('Missing revision target.', 'revisionary-pro'));
    }
    public static function save($post, $name, $data) {
        $post = self::context($post->ID, wp_create_nonce('rvy-builder-edit:' . $post->ID));
        if (is_wp_error($post)) { return $post; }
        $valid = self::validateSave($post, $name, $data); if (is_wp_error($valid)) { return $valid; }
        $update = ['ID' => $post->ID, 'post_status' => $post->post_status, 'post_mime_type' => $post->post_mime_type]; $meta = []; $terms = [];
        switch ($name) {
            case 'wpbakery':
                if (!array_key_exists('content', $data)) { return self::error('rvy_builder_content', 'Missing content.', 400); }
                $update['post_content'] = $data['content'];
                foreach (['post_title', 'post_excerpt'] as $key) { if (isset($data[$key])) { $update[$key] = 'post_excerpt' === $key ? wp_kses_post($data[$key]) : sanitize_text_field($data[$key]); } }
                // WPBakery's frontend save includes an empty post_name even when
                // the editor has not changed the revision slug. Do not blank the
                // workflow revision slug: approval copies it to the published
                // post and would otherwise change its public permalink.
                if (!empty($data['post_name'])) {
                    $update['post_name'] = sanitize_text_field($data['post_name']);
                    $meta['_requested_slug'] = sanitize_title($data['post_name']);
                }
                foreach (['custom_css', 'custom_js_header', 'custom_js_footer', 'custom_layout', 'custom_seo_settings'] as $key) {
                    if (!isset($data['vc_post_' . $key])) { continue; }
                    if (false !== strpos($key, 'js_') && !current_user_can('unfiltered_html')) {
                        // Native saves echo both JS fields, even for content-only
                        // editors. Preserve unchanged values without writing them.
                        $value = $data['vc_post_' . $key];
                        $stored = get_post_meta($post->ID, '_wpb_post_' . $key, true);
                        if (!is_scalar($value) || (string) $value !== (string) $stored) { return self::error('rvy_builder_html', 'Custom JavaScript requires unfiltered_html.'); }
                        continue;
                    }
                    $meta['_wpb_post_' . $key] = 'custom_css' === $key ? wp_strip_all_tags($data['vc_post_' . $key]) : $data['vc_post_' . $key];
                }
                if (isset($data['vc_post_template'])) { $meta['_wp_page_template'] = sanitize_text_field($data['vc_post_template']); }
                if (array_key_exists('vc_post_featured_image', $data)) { $meta['_thumbnail_id'] = absint($data['vc_post_featured_image']); }
                foreach (['vc_post_comments' => 'comment_status', 'vc_post_pingbacks' => 'ping_status'] as $input => $field) { if (isset($data[$input])) { $update[$field] = filter_var($data[$input], FILTER_VALIDATE_BOOLEAN) ? 'open' : 'closed'; } }
                if (isset($data['is_hide_title'])) { $settings = (array) get_post_meta($post->ID, '_vc_post_settings', true); $settings['is_hide_title'] = filter_var($data['is_hide_title'], FILTER_VALIDATE_BOOLEAN); $meta['_vc_post_settings'] = $settings; }
                foreach (['vc_selected_categories' => 'category', 'vc_post_tags' => 'post_tag'] as $input => $taxonomy) {
                    if (!isset($data[$input]) || !is_object_in_taxonomy($post->post_type, $taxonomy)) { continue; }
                    $tax = get_taxonomy($taxonomy);
                    if (!current_user_can($tax->cap->assign_terms)) { return self::error('rvy_builder_terms', 'You cannot assign these terms.'); }
                    $terms[$taxonomy] = [];
                    foreach ((array) $data[$input] as $term) {
                        $term_id = is_array($term) ? absint($term['id'] ?? 0) : absint($term);
                        if (!$term_id || !term_exists($term_id, $taxonomy)) { return self::error('rvy_builder_terms', 'Only existing terms may be selected in a revision.'); }
                        $terms[$taxonomy][] = $term_id;
                    }
                }
                break;
            case 'seedprod':
                if (isset($data['lpage_post_status']) && $data['lpage_post_status'] !== $post->post_status) {
                    return self::error('rvy_builder_seedprod_publish', __('SeedProd cannot publish a revision directly. Use Approve or Submit instead.', 'revisionary-pro'));
                }
                if (!isset($data['lpage_html'], $data['settings']) || !is_string($data['lpage_html'])) { return self::error('rvy_builder_seedprod', 'Invalid SeedProd settings.', 400); }
                $settings = self::seedprodSettingsForSave($post, $data['settings']);
                if (is_wp_error($settings)) { return $settings; }
                $html = seedprod_lite_strip_vue_render_helpers($data['lpage_html']);
                $update['post_content'] = current_user_can('unfiltered_html') ? $html : wp_kses_post($html);
                $update['post_content_filtered'] = $settings; $meta['_rvy_seedprod_settings'] = $settings;
                if (isset($data['lpage_name'])) { $update['post_title'] = sanitize_text_field($data['lpage_name']); }
                if (!empty($data['lpage_slug'])) { $meta['_requested_slug'] = sanitize_title($data['lpage_slug']); }
                break;
            case 'bricks':
                // Enable the same element permissions for the native sanitizer,
                // only after the session and exact save target were validated.
                self::grantBricksRevisorAccess($post);
                $prepared = RevisionaryBricksIntegration::prepare($post, $data);
                if (is_wp_error($prepared)) { return $prepared; }
                if (!empty($prepared['noop'])) {
                    return ['id' => $post->ID, 'status' => 'updated', 'post_status' => $post->post_status, 'save_verification' => true, 'rvy_saved' => true];
                }
                $update = array_merge($update, $prepared['update']); $meta = $prepared['meta'];
                break;
            case 'breakdance28': case 'breakdance3':
                $tree = json_decode($data['tree'] ?? '', true);
                if (!is_array($tree) || !\Breakdance\Data\is_valid_tree($tree)) { return self::error('rvy_builder_tree', 'Invalid layout tree.', 400); }
                $shared = ['globalSettings' => \Breakdance\Data\get_global_settings_array(), 'classes' => \Breakdance\Data\load_selectors(), 'presets' => \Breakdance\Data\load_presets()];
                if (function_exists('Breakdance\\Variables\\getVariablesDataForBuilder')) { $shared['variables'] = ['variables' => \Breakdance\Variables\getVariables(), 'collections' => \Breakdance\Variables\getVariablesCollections()]; }
                foreach (['globalSettings', 'classes', 'presets', 'variables', 'oxySelectors', 'ai'] as $key) {
                    if (!isset($data[$key]) || '' === $data[$key]) { continue; }
                    $value = json_decode($data[$key], true); $valid_json = JSON_ERROR_NONE === json_last_error();
                    $expected = json_decode(wp_json_encode($shared[$key] ?? null), true);
                    if (!$valid_json || (!is_array($value) && null !== $value) || (($value || $expected) && $value != $expected)) { return self::error('rvy_builder_global', __('Shared styles and global settings cannot be saved from a revision.', 'revisionary-pro')); }
                }
                $meta['_breakdance_data'] = \Breakdance\Data\encode_before_writing_to_wp(['tree_json_string' => $data['tree']], false);
                foreach (['templateSettings' => '_breakdance_template_settings', 'futureLayerMeta' => '_breakdance_futurelayer_meta'] as $key => $field) { if (isset($data[$key])) { $meta[$field] = \Breakdance\Data\encode_before_writing_to_wp($data[$key], false); } }
                break;
            case 'divi5':
                if (isset($data['mainLoopType']) && 'singular' !== $data['mainLoopType']) { return self::error('rvy_builder_scope', 'Only page-local revisions are supported.'); }
                foreach (['header', 'body', 'footer'] as $slot) {
                    $shared_id = absint($data['layout_post_ids'][$slot] ?? 0); $shared_post = $shared_id ? get_post($shared_id) : null; $incoming = $data['content'][$slot] ?? '';
                    $changed = $incoming && (!$shared_post || \ET\Builder\VisualBuilder\Saving\SavingUtility::prepare_content_for_db($incoming) !== $shared_post->post_content);
                    // Divi discards settings for slots without a layout post ID.
                    // They cannot mutate shared state and need not match page defaults.
                    $slot_settings = $data['pageSettingsByLayout'][$slot] ?? [];
                    if ($changed || ($shared_id && (!$shared_post || !self::divi5SharedSettingsUnchanged($slot_settings, $shared_post)))) { return self::error('rvy_builder_shared', __('Shared layouts are read-only while editing a revision.', 'revisionary-pro')); }
                }
                if (!empty($data['layout_post_ids']['postContent']) && (int) $data['layout_post_ids']['postContent'] !== (int) $post->ID) { return self::error('rvy_builder_target', 'Invalid content target.'); }
                if (!isset($data['content']['post_content'])) { return self::error('rvy_builder_content', 'Missing content.', 400); }
                $update['post_content'] = \ET\Builder\VisualBuilder\Saving\SavingUtility::prepare_content_for_db($data['content']['post_content']); $settings = $data['pageSettingsByLayout']['postContent'] ?? [];
                if (isset($settings['postTitle'])) { $update['post_title'] = sanitize_text_field($settings['postTitle']); }
                if (isset($settings['postExcerpt'])) { $update['post_excerpt'] = wp_kses_post($settings['postExcerpt']); }
                $meta['_et_pb_use_divi_5'] = 'on'; $meta['_et_pb_use_builder'] = 'on';
                break;
            default: return self::error('rvy_builder_unsupported', 'Unsupported revision save.', 400);
        }
        self::$saving = true;
        try {
            $result = wp_update_post(wp_slash($update), true);
            if (is_wp_error($result) || !$result) { return is_wp_error($result) ? $result : self::error('rvy_builder_save', 'Revision save failed.', 500); }
            foreach ($meta as $key => $value) { update_metadata('post', $post->ID, $key, wp_slash($value)); if (get_post_meta($post->ID, $key, true) != $value) { return self::error('rvy_builder_meta', 'Revision settings could not be saved.', 500); } }
            foreach ($terms as $taxonomy => $ids) { $assigned = wp_set_object_terms($post->ID, $ids, $taxonomy); if (is_wp_error($assigned)) { return $assigned; } }
            if ('divi5' === $name) { \ET\Builder\VisualBuilder\Saving\SavingUtility::save_page_settings(\ET\Builder\VisualBuilder\Saving\SavingUtility::sanitize_page_settings($settings), $post->ID); }
            if ('wpbakery' === $name && method_exists(wpbakery(), 'buildShortcodesCss')) { foreach (['default', 'custom'] as $type) { wpbakery()->buildShortcodesCss($post->ID, $type); } }
            if (in_array($name, ['breakdance28', 'breakdance3'], true)) { \Breakdance\Render\generateCacheForPost($post->ID); }
            if ('bricks' === $name) { RevisionaryBricksIntegration::refresh($post->ID); }
            clean_post_cache($post->ID);
            return ['id' => $post->ID, 'status' => 'updated', 'post_status' => $post->post_status, 'save_verification' => true, 'rvy_saved' => true];
        } finally { self::$saving = false; }
    }
    public static function guardFrontend() {
        if (self::wpbakeryActive() && 'GET' === sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD'] ?? 'GET'))) {
            $builderEntry = isset($_GET['fb-edit']) || 'true' === sanitize_key(wp_unslash($_GET['builder'] ?? '')) || isset($_GET['et_fb']) || isset($_GET['bricks']) || isset($_GET['fl_builder']) || isset($_GET['breakdance']) || isset($_GET['seedprod']); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
            if ($builderEntry) {
                $id = absint($_GET['preview_id'] ?? ($_GET['page_id'] ?? ($_GET['p'] ?? ($_GET['id'] ?? ($_GET['post_id'] ?? 0))))); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
                if (!$id && is_singular()) { $id = get_queried_object_id(); }
                $entryPost = $id ? get_post($id) : null;
                if ($entryPost && rvy_in_revision_workflow($entryPost)) {
                    wp_die(esc_html__('Frontend revision editing for other page builders is unavailable while WPBakery Page Builder is active.', 'revisionary-pro'), '', ['response' => 403]);
                }
            }
        }
        if ('POST' !== sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD'] ?? 'GET'))) { return; }
        if (RevisionaryAvadaIntegration::guardPreview()) { return; }
        $post = self::requestContext();
        if (!$post) { return; }
        $allowed = false;
        if (!is_wp_error($post)) {
            $name = self::builder($post);
            $action = sanitize_key($_POST['action'] ?? ''); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Retain existing integration behavior per the PHPCS review scope.
            if ('wpbakery' === $name && in_array($action, ['vc_load_shortcode', 'vc_frontend_load_template'], true)) {
                $allowed = empty($_POST['vc_post_id']) || (int) $post->ID === absint($_POST['vc_post_id']); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Retain existing integration behavior per the PHPCS review scope.
            }
            if (in_array($name, ['breakdance28', 'breakdance3'], true) && isset($_POST['breakdance_ajax_at_any_url'])) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Retain existing integration behavior per the PHPCS review scope.
                $allowed = 'breakdance_save' !== $action && 0 === strpos($action, 'breakdance_') && (self::parentEditorUnrestricted($post) || self::sourceLookupAllowed($post, $action) || self::localLookupAllowed($post, $action) || self::readActionAllowed($action));
            }
            if ('siteorigin' === $name && isset($_POST['live_editor_panels_data'])) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Retain existing integration behavior per the PHPCS review scope.
                $allowed = (int) $post->ID === absint($_POST['live_editor_post_ID'] ?? 0); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Retain existing integration behavior per the PHPCS review scope.
            }
        }
        if (!$allowed && !is_wp_error($post) && self::parentEditorUnrestricted($post)
            && !in_array($action, ['fusion_app_save_post_content', 'breakdance_save', 'vc_save', 'bricks_save_post', 'bricks_publish_post', 'bricks_create_autosave', 'seedprod_lite_save_lpage'], true)) { $allowed = true; }
        if (!$allowed) { wp_die(esc_html__('This operation is unavailable while editing a revision.', 'revisionary-pro'), '', ['response' => 403]); }
    }
    private static function isNativeMediaUpload() {
        global $pagenow;
        return 'async-upload.php' === $pagenow && 'POST' === sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD'] ?? 'GET'))
            && in_array(sanitize_key($_REQUEST['action'] ?? ''), ['', 'upload-attachment'], true); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
    }
    public static function guardForm() {
        if (wp_doing_ajax() || 'POST' !== sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD'] ?? 'GET'))) { return; }
        $post = self::requestContext(); if (!$post) { return; }
        if (self::isNativeMediaUpload() && !is_wp_error($post)
            && (empty($_REQUEST['post_id']) || (int) $post->ID === absint($_REQUEST['post_id']))) { return; } // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        if (is_wp_error($post) || 'editpost' !== sanitize_key(wp_unslash($_POST['action'] ?? '')) || (int) $post->ID !== absint($_POST['post_ID'] ?? 0)) { wp_die(esc_html__('Only the selected revision can be saved in this session.', 'revisionary-pro'), '', ['response' => 403]); } // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Retain existing integration behavior per the PHPCS review scope.
    }
    private static function rejectAjax($data, $status = 403) {
        wp_send_json_error($data, $status);
        exit;
    }
    public static function guardAjax() {
        if (!wp_doing_ajax()) { return; }
        $post = self::requestContext(); $action = sanitize_key($_REQUEST['action'] ?? ''); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        if (RevisionaryAvadaIntegration::guardAjax($post, $action)) { return; }
        if (!$post) {
            if (in_array($action, ['vc_save', 'seedprod_lite_save_lpage', 'breakdance_save', 'bricks_save_post', 'bricks_publish_post', 'bricks_create_autosave'], true)) { $target = absint($_POST['post_id'] ?? ($_POST['lpage_id'] ?? ($_POST['id'] ?? ($_POST['postId'] ?? 0)))); if ($target && rvy_in_revision_workflow($target)) { self::rejectAjax(['message' => __('Open this revision from its guarded builder editing link.', 'revisionary-pro')], 403); } } // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Retain existing integration behavior per the PHPCS review scope.
            return;
        }
        if (is_wp_error($post)) { self::rejectAjax(['message' => $post->get_error_message()], 403); }
        if ('revisionary_builder_transition' === $action) { return; }
        // Media selection resolves attachment data after upload. Attachment IDs
        // are media targets, not revision IDs; only post context must match.
        $media_read = in_array($action, ['query-attachments', 'get-attachment', 'get-post-thumbnail-html', 'send-attachment-to-editor', 'send-link-to-editor'], true);
        $breakdance_media_read = in_array(self::builder($post), ['breakdance28', 'breakdance3'], true)
            && in_array($action, ['breakdance_image_metadata', 'breakdance_image_sizes'], true);
        if ($media_read || $breakdance_media_read) {
            foreach (['post_id', 'post_ID', 'postId'] as $key) {
                $target = absint($_REQUEST[$key] ?? 0); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
                if ($target && (int) $post->ID !== $target) {
                    self::rejectAjax(['message' => __('Only the selected revision can be targeted.', 'revisionary-pro')], 403);
                }
            }
            return; // Native handlers retain their authentication/nonce checks.
        }

        if ('upload-attachment' === $action || self::isNativeMediaUpload()) {
            // WordPress's media dialog uploads through async-upload.php and
            // carries the revision session in the URL. Permit this native
            // endpoint only inside an already-authorized builder session and
            // only for that revision (or as an unattached media-library item).
            // The core handler still verifies its media-form nonce, upload_files
            // capability, and edit_post capability when a post_id is supplied.
            $target = absint($_REQUEST['post_id'] ?? 0); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
            if ($target && (int) $post->ID !== $target) {
                self::rejectAjax(['message' => __('Media uploads must target the revision currently being edited.', 'revisionary-pro')], 403);
            }
            return;
        }
        // Native saves below still retain revision target and status protection.
        if (self::parentEditorUnrestricted($post) && !in_array($action, ['bricks_save_post', 'vc_save', 'seedprod_lite_save_lpage', 'breakdance_save', 'bricks_publish_post', 'bricks_create_autosave'], true)) { return; }
        if (self::sourceLookupAllowed($post, $action) || self::localLookupAllowed($post, $action)) { return; }
        // These render editor UI/data for every registered shortcode, including
        // third-party elements. They do not authorize shared template/preset writes.
        if ('wpbakery' === self::builder($post) && self::wpbakeryReadActionAllowed($action)) {
            foreach ([$_POST, $_REQUEST] as $input) { // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
                foreach (['post_id', 'vc_post_id', 'postId'] as $target) {
                    if (isset($input[$target]) && (int) $post->ID !== absint($input[$target])) {
                        self::rejectAjax(['message' => __('Only the selected revision can be targeted.', 'revisionary-pro')], 403);
                    }
                }
            }
            if (in_array($action, ['vc_edit_form', 'wpb_add_element_edit_window_ajax_cache'], true)) {
                if ((int) $post->ID !== absint($_POST['post_id'] ?? 0)) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Retain existing integration behavior per the PHPCS review scope.
                    self::rejectAjax(['message' => __('Missing or invalid revision target.', 'revisionary-pro')], 403);
                }
                // Both actions use renderFields(), which can optionally update
                // the site-wide usage counter. Keep revision dialog requests read-only.
                unset($_POST['usage_count'], $_REQUEST['usage_count']);
            }
            if ('wpb_backend_editor_params' === $action) {
                foreach ((array) ($_POST['elements'] ?? []) as $element) { // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- Structured builder payload; scalar IDs and native save data are validated separately.
                    if (!is_array($element) || !in_array($element['action'] ?? '', ['get_attach_image', 'get_gallery_images'], true)) {
                        self::rejectAjax(['message' => __('Only element parameter rendering is available in this request.', 'revisionary-pro')], 403);
                    }
                }
            }
            return; // Native WPBakery handlers still validate their own nonce/caps.
        }
        if (0 === strpos($action, 'bricks_')) {
            if ('bricks' !== self::builder($post)) { self::rejectAjax(['message' => 'Builder does not match this revision.'], 403); }
            if (isset($_POST['postId']) && (int) $post->ID !== absint($_POST['postId'])) { self::rejectAjax(['message' => 'Only the selected revision can be targeted.'], 403); } // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Retain existing integration behavior per the PHPCS review scope.
            if ('bricks_create_autosave' === $action && ('content' !== sanitize_key(wp_unslash($_POST['area'] ?? '')))) { self::rejectAjax(['message' => 'Only page-local content can be autosaved.'], 403); } // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Retain existing integration behavior per the PHPCS review scope.
            if ('bricks_create_autosave' === $action) {
                if (empty($_POST['postId'])) { self::rejectAjax(['message' => 'Missing revision target.'], 403); } // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Retain existing integration behavior per the PHPCS review scope.
                return; // Native autosave retains its own Bricks nonce and permission checks.
            }
            if ('bricks_get_builder_url' === $action) { wp_send_json_success(['url' => self::editorUrl($post, 'bricks')]); }
        }
        $saves = ['bricks_save_post' => 'bricks', 'vc_save' => 'wpbakery', 'seedprod_lite_save_lpage' => 'seedprod', 'breakdance_save' => defined('__BREAKDANCE_VERSION') && version_compare(__BREAKDANCE_VERSION, '3.0.0-alpha', '>=') ? 'breakdance3' : 'breakdance28'];
        if (isset($saves[$action])) {
            $result = self::save($post, $saves[$action], wp_unslash($_POST)); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Retain existing integration behavior per the PHPCS review scope.
            if (is_wp_error($result)) {
                self::rejectAjax(['message' => $result->get_error_message()], (int) ($result->get_error_data()['status'] ?? 400));
                // Some builder AJAX handlers replace the wp_die handler with
                // one that returns. Stop admin-ajax.php from appending its
                // fallback `0` after our JSON response in that case.
                exit;
            }
            // Bricks needs postId and the save result, not an echo of arbitrary input.
            if ('bricks_save_post' === $action) { wp_send_json_success(array_merge($result, ['postId' => $post->ID])); }
            if ('vc_save' === $action) { wp_send_json_success($result); } else { wp_send_json($result); }
            // `wp_send_json*()` normally terminates via wp_die(). Breakdance 3
            // can install a returning AJAX die handler, allowing the core
            // dispatcher to append `0` and making the valid JSON unparsable.
            exit;
        }
        if ('so_panels_builder_content_json' === $action) {
            // SiteOrigin 2.38 renders and sanitizes editor data here without
            // persisting it. Keep its native panels_action nonce/edit checks.
            if ('siteorigin' !== self::builder($post)
                || (int) $post->ID !== absint($_POST['post_id'] ?? 0)) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Native handler verifies its nonce; the signed revision session was checked above.
                self::rejectAjax(['message' => __('Only the selected revision can be targeted.', 'revisionary-pro')], 403);
            }
            return;
        }
        if (!self::readActionAllowed($action)) { self::rejectAjax(['message' => __('This operation is unavailable while editing a revision.', 'revisionary-pro')], 403); }
    }
    /** Reviewed local editor lookups; native handlers retain nonce/capability checks. */
    public static function parentEditorUnrestricted($post) {
        $parent = rvy_post_id($post->ID);
        return $parent && (int) $parent !== (int) $post->ID
            && current_user_can('edit_post', $parent);
    }
    private static function lookupDenied() {
        self::rejectAjax(['message' => __('Invalid revision editing session.', 'revisionary-pro')], 403);
    }
    private static function sourceLookupAllowed($post, $action) {
        $builder = self::builder($post);
        if ((in_array($builder, ['breakdance28', 'breakdance3'], true) && 'breakdance_find_icons' === $action)
            || ('seedprod' === $builder && 'seedprod_lite_get_stockimages' === $action)) { return true; }
        if ('bricks' === $builder && 'bricks_get_image_from_custom_field' === $action) {
            $source = $_POST['postId'] ?? null; // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- Raw ID is strictly validated as scalar digits and read-authorized below; native handler verifies its nonce. Unslashing is unnecessary for the accepted digit-only ID or fixed selector.
            if (!is_scalar($source) || !ctype_digit((string) $source) || !$source || !rvy_can_read_post((int) $source)) { self::lookupDenied(); }
            $checkAttachment = static function ($value, $id) {
                if ($id && !rvy_can_read_post($id)) { self::lookupDenied(); }
                return $value;
            };
            add_filter('wp_get_attachment_metadata', $checkAttachment, PHP_INT_MAX, 2);
            add_filter('wp_get_attachment_image_src', $checkAttachment, PHP_INT_MAX, 2);
            return true; // Native nonce and source-specific builder permission checks still run.
        }
        if ('bricks' === $builder && in_array($action, ['bricks_download_image', 'bricks_import_images', 'bricks_verify_media_upload_folder'], true)) {
            if (!current_user_can('upload_files')) { self::lookupDenied(); }
            foreach (['postId', 'post_id'] as $key) {
                if (isset($_POST[$key]) && (!is_scalar($_POST[$key]) || !ctype_digit((string) $_POST[$key]) || (int) $_POST[$key] !== (int) $post->ID)) { self::lookupDenied(); } // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- Reject non-scalar, non-digit or cross-revision targets; native handler verifies its nonce. Unslashing is unnecessary for the accepted digit-only ID or fixed selector.
            }
            if ('bricks_verify_media_upload_folder' === $action) {
                $id = $_POST['attachmentId'] ?? null; // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- Raw ID is strictly validated as scalar digits and edit-authorized below; native handler verifies its nonce. Unslashing is unnecessary for the accepted digit-only ID or fixed selector.
                if (!is_scalar($id) || !ctype_digit((string) $id) || 'attachment' !== get_post_type((int) $id) || !current_user_can('edit_post', (int) $id)) { self::lookupDenied(); }
                return true; // Native folder provider authorizes verification and retry assignments.
            }
            $image_urls = [];
            $checkImage = static function ($image) use (&$image_urls) {
                if (!is_array($image)) { self::lookupDenied(); }
                foreach (['url', 'full'] as $key) {
                    if (empty($image[$key])) { continue; }
                    $url = $image[$key];
                    if (!is_string($url) || !wp_http_validate_url($url)) { self::lookupDenied(); }
                    $image_urls[] = $url;
                    global $wpdb;
                    $id = attachment_url_to_postid($url); // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.attachment_url_to_postid_attachment_url_to_postid -- Use the portable WordPress API to authorize existing attachments; VIP APIs are optional.
                    if (!$id) { $id = (int) $wpdb->get_var($wpdb->prepare("SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_bricks_image_origin_url' AND meta_value = %s LIMIT 1", $url)); } // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Prepared exact source lookup; query fresh attachment mappings for this authorization check.
                    if ($id && !rvy_can_read_post($id)) { self::lookupDenied(); }
                }
            };
            if ('bricks_download_image' === $action) {
                if (empty($_POST['download_url'])) { self::lookupDenied(); } // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Presence check only; native handler verifies its nonce.
                $checkImage(['url' => $_POST['download_url'] ?? '']); // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- checkImage validates the raw URL and source access; native handler verifies its nonce. Raw validation intentionally precedes any unslashing to preserve native input handling.
            } else {
                $images = $_POST['images'] ?? []; // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- Structured payload is shape-checked below and URLs are validated by checkImage; native handler verifies its nonce. Raw validation intentionally precedes any unslashing to preserve native input handling.
                if (!is_array($images)) { self::lookupDenied(); }
                foreach ($images as $image) {
                    if (!is_array($image) || !is_array($image['settings'] ?? null)) { self::lookupDenied(); }
                    if ('image-gallery' === ($image['elementName'] ?? '')) {
                        if (!is_array($image['settings']['images'] ?? [])) { self::lookupDenied(); }
                        foreach (($image['settings']['images'] ?? []) as $item) { $checkImage($item); }
                    } else { $checkImage($image['settings']); }
                }
            }
            // Apply WordPress safe-URL validation to native requests and redirects.
            add_filter('http_request_args', static function ($args, $url) use ($image_urls) { // phpcs:ignore WordPressVIPMinimum.Hooks.RestrictedHooks.http_request_args -- Only enables safe-URL and TLS checks for selected images; does not change request timeouts.
                if (in_array($url, $image_urls, true)) { $args['reject_unsafe_urls'] = true; $args['sslverify'] = true; }
                return $args;
            }, PHP_INT_MAX, 2);
            return true;
        }
        if ('siteorigin' === $builder && in_array($action, ['so_panels_layouts_query', 'so_panels_get_layout', 'so_panels_layout_block_preview'], true)) {
            foreach (['post_id', 'post_ID', 'postId'] as $key) {
                if (isset($_REQUEST[$key]) && (!is_scalar($_REQUEST[$key]) || !ctype_digit((string) $_REQUEST[$key]) || (int) $_REQUEST[$key] !== (int) $post->ID)) { self::lookupDenied(); } // phpcs:ignore WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- Reject non-scalar, non-digit or cross-revision targets; native handler verifies its nonce. Unslashing is unnecessary for the accepted digit-only ID or fixed selector.
            }
            if ('so_panels_layout_block_preview' === $action) { return true; } // Native nonce and widget/layout sanitization remain.
            $type = $_REQUEST['type'] ?? ('so_panels_layouts_query' === $action ? 'directory-siteorigin' : ''); // phpcs:ignore WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- Raw type is string-checked and sanitized with sanitize_key below; native handler verifies its nonce. sanitize_key removes backslashes; unslashing cannot change the accepted key.
            if (!is_string($type)) { self::lookupDenied(); }
            $type = sanitize_key($type);
            if ('prebuilt' === $type || 0 === strpos($type, 'directory-')) { return true; } // Native code resolves registered sources only.
            if (0 !== strpos($type, 'clone_')) { self::lookupDenied(); }
            if ('so_panels_get_layout' === $action) {
                $source = $_REQUEST['lid'] ?? null; // phpcs:ignore WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- Raw ID is strictly validated as scalar digits and edit-authorized below; native handler verifies its nonce. Unslashing is unnecessary for the accepted digit-only ID or fixed selector.
                if (!is_scalar($source) || !ctype_digit((string) $source) || !current_user_can('edit_post', (int) $source)) { self::lookupDenied(); }
            } else {
                self::siteoriginCloneLayouts($type);
            }
            return true;
        }
        return false;
    }
    /** Authorize clone sources before slicing pages, including the reported total. */
    private static function siteoriginCloneLayouts($type) {
        if (empty($_REQUEST['_panelsnonce']) || !is_scalar($_REQUEST['_panelsnonce'])
            || !wp_verify_nonce(sanitize_text_field(wp_unslash($_REQUEST['_panelsnonce'])), 'panels_action')) { self::lookupDenied(); }
        $post_type = substr($type, strlen('clone_'));
        if (!class_exists('SiteOrigin_Panels_Admin_Layouts')
            || !in_array($post_type, SiteOrigin_Panels_Admin_Layouts::single()->post_types(), true)) { self::lookupDenied(); }
        $type_obj = get_post_type_object($post_type);
        if (!$type_obj) { self::lookupDenied(); }
        $search = isset($_REQUEST['search']) && is_scalar($_REQUEST['search']) ? sanitize_text_field(wp_unslash($_REQUEST['search'])) : '';
        $page = isset($_REQUEST['page']) && is_scalar($_REQUEST['page']) ? max(1, (int) $_REQUEST['page']) : 1;
        global $wpdb;
        $selected = []; $total = 0; $offset = 0;
        do {
            $ids = $wpdb->get_col($wpdb->prepare( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Prepared bounded scan; fresh results and per-post capability checks determine authorized clone totals.
                "SELECT p.ID FROM $wpdb->posts p WHERE p.post_type = %s AND p.post_status IN ('publish','draft','private') AND p.post_title LIKE %s AND EXISTS (SELECT 1 FROM $wpdb->postmeta m WHERE m.post_id = p.ID AND m.meta_key = 'panels_data') ORDER BY p.post_date DESC, p.ID DESC LIMIT 500 OFFSET %d",
                $post_type, '%' . $wpdb->esc_like($search) . '%', $offset
            ));
            foreach ($ids as $id) {
                if (!current_user_can('edit_post', (int) $id)) { continue; }
                if ($total >= ($page - 1) * 16 && $total < $page * 16) { $selected[] = $id; }
                $total++;
            }
            $offset += 500;
        } while (count($ids) === 500);
        $result = ['title' => sprintf(__('Clone %s', 'siteorigin-panels'), esc_html($type_obj->labels->singular_name)), 'items' => [], 'max_num_pages' => (int) ceil($total / 16)];
        foreach ($selected as $id) {
            $result['items'][] = ['id' => (int) $id, 'title' => esc_html(get_post_field('post_title', $id)), 'type' => esc_html($type), 'screenshot' => get_the_post_thumbnail_url((int) $id, [400, 300]) ?: ''];
        }
        if ($search) { $result['title'] .= __(' - Results For:', 'siteorigin-panels') . ' <em>' . esc_html($search) . '</em>'; }
        wp_send_json(apply_filters('siteorigin_panels_layouts_result', $result, $type));
        exit;
    }
    private static function localLookupAllowed($post, $action) {
        $builder = self::builder($post);
        $actions = [
            'wpbakery' => ['wpb_single_image_src', 'vc_media_editor_preview_image'],
            'bricks' => ['bricks_get_image_metadata', 'bricks_get_media_attachment_details', 'bricks_get_html_from_content', 'bricks_get_custom_shape_divider'],
            'breakdance28' => ['breakdance_get_icon_sets', 'breakdance_get_shape_dividers', 'breakdance_get_post_types', 'breakdance_get_post_types_for_wp_query', 'breakdance_get_local_dependency_files'],
            'breakdance3' => ['breakdance_get_icon_sets', 'breakdance_get_shape_dividers', 'breakdance_get_post_types', 'breakdance_get_post_types_for_wp_query', 'breakdance_get_local_dependency_files'],
            'seedprod' => ['seedprod_lite_slug_exists'],
        ];
        if (!in_array($action, $actions[$builder] ?? [], true)) { return false; }

        // These fields are document context, never media IDs. Reject ambiguous
        // or cross-post targets in either input source before native dispatch.
        foreach ([$_GET, $_POST] as $input) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended,WordPress.Security.NonceVerification.Missing -- Signed revision context is validated by the caller; native nonce checks still run.
            foreach (['post_id', 'post_ID', 'postId', 'vc_post_id'] as $key) {
                if (isset($input[$key]) && (!is_scalar($input[$key])
                    || !ctype_digit((string) $input[$key]) || (int) $input[$key] !== (int) $post->ID)) {
                    self::rejectAjax(['message' => __('Only the selected revision can be targeted.', 'revisionary-pro')], 403);
                }
            }
        }
        $required_target = ['wpb_single_image_src' => 'post_id', 'bricks_get_html_from_content' => 'postId'];
        if (isset($required_target[$action]) && empty($_POST[$required_target[$action]])) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Native nonce checks still run.
            self::rejectAjax(['message' => __('Missing or invalid revision target.', 'revisionary-pro')], 403);
        }

        $media_fields = [
            'wpb_single_image_src' => 'content', 'vc_media_editor_preview_image' => 'attachment_id',
            'bricks_get_image_metadata' => 'imageId', 'bricks_get_media_attachment_details' => 'attachmentId',
            'bricks_get_custom_shape_divider' => 'id',
        ];
        if (isset($media_fields[$action])) {
            $raw_id = $_POST[$media_fields[$action]] ?? 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- Raw media ID is strictly validated as scalar digits and authorized below; native nonce checks still run. Unslashing is unnecessary for the accepted digit-only ID or fixed selector.
            if (in_array($action, ['wpb_single_image_src', 'vc_media_editor_preview_image'], true) && ('' === $raw_id || false === $raw_id)) { $raw_id = 0; }
            if (!is_scalar($raw_id) || !ctype_digit((string) $raw_id)) {
                self::rejectAjax(['message' => __('Invalid attachment.', 'revisionary-pro')], 403);
            }
            $id = (int) $raw_id;
            if ('wpb_single_image_src' === $action && isset($_POST['params']) && is_array($_POST['params']) // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Checks the parameter container only; native nonce checks still run.
                && 'featured_image' === ($_POST['params']['source'] ?? '')) { // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- Exact comparison with a fixed source selector; native nonce checks still run. Unslashing is unnecessary for the accepted digit-only ID or fixed selector.
                $id = (int) get_post_thumbnail_id($post->ID);
            }
            // Bricks returns the attachment's raw file contents for this lookup.
            // Restrict that response to the SVG files this control is designed for.
            if ($id && 'bricks_get_custom_shape_divider' === $action) {
                $file = get_attached_file($id);
                if ('image/svg+xml' !== get_post_mime_type($id) || !is_string($file)
                    || 'svg' !== strtolower(pathinfo($file, PATHINFO_EXTENSION))) {
                    self::rejectAjax(['message' => __('Invalid attachment.', 'revisionary-pro')], 403);
                }
            }
            // Zero means no attachment; let native handlers return their empty response.
            if ($id && ('attachment' !== get_post_type($id)
                || !(current_user_can('read_post', $id) || current_user_can('edit_post', $id)))) {
                self::rejectAjax(['message' => __('You are not allowed to access this attachment.', 'revisionary-pro')], 403);
            }
        }
        return true;
    }
    /** Reviewed native WPBakery form/parameter rendering contracts, independent of element tag. */
    private static function wpbakeryReadActionAllowed($action) {
        return in_array($action, [
            // Frontend editor startup renders the revision iframe through these
            // native AJAX actions. They are read-only and must pass the same
            // revision-scoped target checks as backend form rendering.
            'vc_load_shortcode', 'vc_frontend_load_template',
            'vc_edit_form', 'wpb_add_element_edit_window_ajax_cache', 'vc_param_group_clone',
            'vc_get_autocomplete_suggestion', 'vc_get_autocomplete_render', 'vc_get_vc_grid_data',
            'wpb_get_loop_suggestion', 'wpb_get_loop_settings', 'vc_get_tags',
            'wpb_backend_editor_params', 'wpb_single_image_data', 'wpb_get_gallery_html',
            'vc_action_get_settings_preset', 'vc_action_render_settings_preset_popup',
            'vc_action_render_settings_preset_title_prompt', 'vc_action_render_settings_templates_prompt',
        ], true);
    }
    private static function readActionAllowed($action) {
        // Bricks redirects to login if its startup user check receives an AJAX error.
        $reads = ['bricks_get_current_user_id', 'bricks_render_data', 'bricks_render_element', 'bricks_get_posts', 'bricks_get_pages', 'bricks_get_terms_options', 'bricks_get_dynamic_data_preview_content', 'bricks_get_partial_builder_data', 'bricks_get_template_elements_by_id', 'bricks_get_revisions', 'bricks_get_revision_data', 'heartbeat', 'breakdance_load_document', 'breakdance_load_builder_elements', 'breakdance_get_available_documents', 'breakdance_get_available_documents_with_search', 'breakdance_load_block', 'breakdance_load_blocks', 'breakdance_load_global_settings', 'breakdance_load_selectors', 'breakdance_load_presets', 'breakdance_get_documents', 'breakdance_server_side_render', 'breakdance_retrieve_revisions', 'breakdance_get_posts', 'breakdance_get_menus', 'breakdance_get_taxonomies', 'breakdance_get_editable_post_types', 'breakdance_load_variables', 'breakdance_image_metadata', 'breakdance_image_sizes', 'so_panels_widget_form', 'so_panels_style_form', 'so_panels_builder_content', 'so_panels_live_editor_preview', 'seedprod_lite_get_lpage', 'seedprod_lite_get_utc_offset', 'seedprod_lite_get_revisions', 'seedprod_lite_get_namespaced_custom_css', 'query-attachments', 'get-attachment', 'get-post-thumbnail-html', 'wp-link-ajax'];
        return in_array($action, $reads, true);
    }
    public static function guardRest($result, $server, $request) {
        // Atomic shared resources use REST rather than Elementor's library AJAX.
        // Read/render requests remain available; shared writes cannot belong to a revision.
        if (null === $result && !in_array($request->get_method(), ['GET', 'HEAD', 'OPTIONS'], true)
            && preg_match('#^/elementor/v1/(?:global-classes|variables|components|default-styles)(?:/|$)#', $request->get_route())
            && !in_array($request->get_route(), ['/elementor/v1/components/create-validate'], true)
            && self::sharedResourceEditorRevisionId($request)) {
            return self::error('rvy_builder_readonly', __('Shared Elementor design resources cannot be modified when editing a revision.', 'revisionary-pro'));
        }
        $post = self::requestContext($request);
        if (!$post) {
            if ('/divi/v1/sync-to-server' === $request->get_route() && rvy_in_revision_workflow(absint($request->get_param('post_id')))) { return self::error('rvy_builder_session', __('Open this revision from its guarded builder editing link.', 'revisionary-pro')); }
            return $result;
        }
        if (null !== $result) { return $result; }
        if (is_wp_error($post)) { return $post; }
        // Let core authorize native media creation; no attachment updates or deletes.
        if ('POST' === $request->get_method() && '/wp/v2/media' === untrailingslashit($request->get_route())) {
            $target = absint($request->get_param('post'));
            if ($target && (int) $post->ID !== $target) {
                return self::error('rvy_builder_target', __('Media uploads must target the revision currently being edited.', 'revisionary-pro'));
            }
            return $result;
        }
        if (in_array($request->get_method(), ['GET', 'HEAD', 'OPTIONS'], true)) { return $result; }
        if ('/divi/v1/sync-to-server' === $request->get_route()) {
            $saved = self::save($post, 'divi5', $request->get_params());
            if (!is_wp_error($saved) && 'preview' === $request->get_param('syncType')) { $saved['previewId'] = $post->ID; $saved['previewUrl'] = rvy_preview_url($post); $saved['syncType'] = 'preview'; }
            return is_wp_error($saved) ? $saved : new WP_REST_Response($saved, 200);
        }
        if (preg_match('#^/divi/v1/(?:module-render|module-data/[^/]+)$#', $request->get_route())) { return $result; }
        if (self::parentEditorUnrestricted($post)) {
            // Identify native post routes by namespace/base; unrelated resource IDs
            // must not be interpreted as post IDs merely because numbers match.
            foreach (get_post_types(['show_in_rest' => true], 'objects') as $type) {
                $namespace = !empty($type->rest_namespace) ? $type->rest_namespace : 'wp/v2';
                $base = !empty($type->rest_base) ? $type->rest_base : $type->name;
                if (preg_match('#^/' . preg_quote($namespace . '/' . $base, '#') . '/([0-9]+)(?:/|$)#', $request->get_route(), $match)
                    && (int) $match[1] === (int) rvy_post_id($post->ID)) {
                    return self::error('rvy_builder_target', __('Only the selected revision can be targeted.', 'revisionary-pro'));
                }
            }
            return $result; // Native route permission callbacks still authorize the operation.
        }
        return self::error('rvy_builder_readonly', __('Only revision content can be changed in this editing session.', 'revisionary-pro'));
    }
    public static function canApprove($post) {
        return in_array($post->post_mime_type, ['draft-revision', 'pending-revision'], true)
            && current_user_can('approve_revision', $post->ID);
    }
    public static function transition() {
        $post = self::requestContext(); if (!$post || is_wp_error($post)) { wp_send_json_error(['message' => __('Invalid revision.', 'revisionary-pro')], 403); }
        $operation = sanitize_key($_POST['operation'] ?? ''); require_once dirname(REVISIONARY_FILE) . '/admin/revision-action_rvy.php'; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Retain existing integration behavior per the PHPCS review scope.
        if ('submit' === $operation && 'draft-revision' === $post->post_mime_type && (is_content_administrator_rvy() || current_user_can('set_revision_pending-revision', $post->ID))) { $result = rvy_revision_submit($post->ID); }
        elseif ('approve' === $operation && self::canApprove($post)) {
            $approval_url = add_query_arg('rvy_approval', 1, get_permalink(rvy_post_id($post->ID)));
            $result = rvy_revision_approve($post->ID);
        }
        else { wp_send_json_error(['message' => __('You cannot perform this action.', 'revisionary-pro')], 403); }
        if (false === $result || is_wp_error($result)) { wp_send_json_error(['message' => __('The revision action failed.', 'revisionary-pro')], 400); }
        $submit_url = rvy_preview_url($post->ID);
        wp_send_json_success(['url' => 'approve' === $operation ? $approval_url : $submit_url]);
    }
    public static function applied($parent_id, $revision) {
        if (class_exists('RevisionaryBricksIntegration') && RevisionaryBricksIntegration::supported() && metadata_exists('post', $parent_id, '_bricks_page_content_2')) { RevisionaryBricksIntegration::refresh($parent_id); }
        if (metadata_exists('post', $parent_id, '_wpb_vc_js_status') && function_exists('wpbakery') && method_exists(wpbakery(), 'buildShortcodesCss')) { foreach (['default', 'custom'] as $type) { wpbakery()->buildShortcodesCss($parent_id, $type); } }
        if (metadata_exists('post', $parent_id, '_breakdance_data') && function_exists('Breakdance\\Render\\generateCacheForPost')) { \Breakdance\Render\generateCacheForPost($parent_id); }
    }
}
