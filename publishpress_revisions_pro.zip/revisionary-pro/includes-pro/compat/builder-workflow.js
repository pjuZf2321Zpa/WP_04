(function () {
    'use strict';
    if (window.__rvyBuilderTransport || !window.RevisionaryBuilderSession) return;
    window.__rvyBuilderTransport = true;
    const config = window.RevisionaryBuilderSession;
    let owner = window;
    try { if (window.top.location.origin === window.location.origin) owner = window.top; } catch (error) { /* Local scope. */ }
    if (config.builder === 'seedprod') {
        // SeedProd offers to publish an unpublished page when leaving its
        // builder. A workflow revision must never publish through that path.
        // Answer "No" only to this exact prompt so the normal exit can proceed.
        const installRevisionExitPromptGuard = (target) => {
            if (!target || target.__rvySeedprodExitPromptGuard) return;
            const nativeConfirm = target.confirm;
            target.confirm = function (message) {
                const normalized = String(message || '').replace(/\s+/g, ' ').trim();
                if (/^This page is not published\. Would you like to publish it now\?$/i.test(normalized)) return false;
                return nativeConfirm.call(target, message);
            };
            target.__rvySeedprodExitPromptGuard = true;
        };
        installRevisionExitPromptGuard(window);
        if (owner !== window) installRevisionExitPromptGuard(owner);
    }
    const key = '__rvyBuilderState' + config.id;
    const state = owner[key] || (owner[key] = { dirty: true, generation: 0, inFlight: 0 });
    const saves = new Set(['fusion_app_save_post_content', 'vc_save', 'seedprod_lite_save_lpage', 'breakdance_save', 'bricks_save_post']);
    function changed() { state.dirty = true; state.generation++; }
    function feedback(message) {
        window.RevisionaryBuilderNotice(message, config.builder);
    }
    async function runTransition(operation) {
        const body = new URLSearchParams({ action: 'revisionary_builder_transition', operation, _rvy_builder_revision: String(config.id), _rvy_builder_nonce: config.nonce });
        const response = await originalFetch(scoped(config.ajax), { method: 'POST', credentials: 'same-origin', body });
        const result = await response.json();
        if (!response.ok || !result.success) throw new Error(result.data?.message || config.saveFirst);
        // A builder can invoke transitions from its canvas iframe. Exit the editor shell.
        owner.location.assign(result.data.url);
    }
    function saveError(response, status) {
        const data = response && (response.data || response);
        const failure = data?.failure;
        const message = typeof data === 'string' ? data : (data?.message || (typeof failure === 'object' ? Object.values(failure).flat().join(' ') : failure));
        const text = message || ('Revision save failed (HTTP ' + status + ').');
        state.error = text;
        state.nativeOperation = '';
        // Use textContent: builder/server error messages must never become HTML.
        feedback(text);
    }
    function scoped(value) {
        const url = new URL(value, window.location.href);
        if (url.origin !== window.location.origin) return value;
        url.searchParams.set('_rvy_builder_revision', String(config.id));
        url.searchParams.set('_rvy_builder_nonce', config.nonce);
        return url.href;
    }
    function saved(response, generation, requestNumber) {
        const data = response && (response.data || response);
        if (data && data.rvy_saved === true && Number(data.id) === Number(config.id)) {
            if (generation === state.generation && requestNumber === state.saveRequest) { state.dirty = false; state.saveSerial = (state.saveSerial || 0) + 1; }
            state.error = '';
            if (['bricks', 'divi5', 'wpbakery'].includes(config.builder) && state.nativeOperation && generation === state.generation && requestNumber === state.saveRequest) {
                const operation = state.nativeOperation;
                // Divi clears its native dirty state after processing the save response.
                // Wait for that confirmation, cancelling if another edit starts.
                let attempts = 0;
                const transition = () => {
                    if (generation !== state.generation || state.dirty || state.error) { state.nativeOperation = ''; return; }
                    if (state.inFlight || nativeDirty()) {
                        if (++attempts < 1200) window.setTimeout(transition, 50);
                        else { state.nativeOperation = ''; feedback(config.saveFirst); }
                        return;
                    }
                    state.nativeOperation = '';
                    runTransition(operation).catch((error) => feedback(error.message));
                };
                window.setTimeout(transition, 0);
            }
            window.RevisionaryBuilderNotice('', config.builder);
        }
    }
    // Never transition on the strength of an earlier save. The native Update
    // must acknowledge this generation, and all save requests must finish.
    async function updateAndTransition(operation, control) {
        if (state.workflowBusy) return;
        if (!control || control.disabled) { feedback(config.saveFirst); return; }
        state.workflowBusy = true;
        state.error = '';
        const generation = state.generation;
        const serial = state.saveSerial || 0;
        const requestNumber = state.saveRequest || 0;
        try {
            control.click();
            await new Promise((resolve, reject) => {
                const deadline = Date.now() + 60000;
                const check = () => {
                    if (state.error || generation !== state.generation) return reject(new Error(state.error || config.saveFirst));
                    if ((state.saveRequest || 0) > requestNumber && (state.saveSerial || 0) > serial && !state.dirty && !state.inFlight && !nativeDirty()) return resolve();
                    if (Date.now() >= deadline) return reject(new Error(config.saveFirst));
                    window.setTimeout(check, 50);
                };
                check();
            });
            await runTransition(operation);
        } catch (error) { feedback(error.message); }
        finally { state.workflowBusy = false; }
    }
    function saveRequest(url, body) {
        if (/\/divi\/v1\/sync-to-server(?:[/?]|$)/.test(url) || /rest_route=.*sync-to-server/.test(url)) return true;
        try {
            if (saves.has(new URL(url, window.location.href).searchParams.get('action'))) return true;
            const params = body instanceof FormData || body instanceof URLSearchParams ? body : new URLSearchParams(typeof body === 'string' ? body : '');
            return saves.has(params.get('action'));
        } catch (error) { return false; }
    }
    const originalFetch = window.fetch;
    if (originalFetch) window.fetch = function (input, options) {
        const raw = typeof input === 'string' || input instanceof URL ? String(input) : input.url;
        const isSave = saveRequest(raw, options?.body); const generation = state.generation;
        const requestNumber = isSave ? (state.saveRequest = (state.saveRequest || 0) + 1) : 0;
        if (isSave) { state.inFlight++; state.dirty = true; }
        let request;
        try { request = typeof input === 'string' || input instanceof URL ? scoped(raw) : new Request(scoped(raw), input); }
        catch (error) { if (isSave) state.inFlight--; throw error; }
        return originalFetch.call(this, request, options).then(async (response) => {
            if (isSave) {
                try {
                    const data = await response.clone().json();
                    if (response.ok && data?.success !== false && !(config.builder === 'avada' && data?.data?.failure)) saved(data, generation, requestNumber);
                    else saveError(data, response.status);
                } catch (error) { if (!response.ok) saveError(null, response.status); }
            }
            return response;
        }).catch((error) => { if (isSave) saveError({message: error.message}, 0); throw error; }).finally(() => { if (isSave) state.inFlight--; });
    };
    const open = XMLHttpRequest.prototype.open; const send = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function (method, url) {
        this.__rvyUrl = String(url); const args = Array.from(arguments); args[1] = scoped(url); return open.apply(this, args);
    };
    XMLHttpRequest.prototype.send = function (body) {
        if (saveRequest(this.__rvyUrl || '', body)) {
            const generation = state.generation;
            const requestNumber = state.saveRequest = (state.saveRequest || 0) + 1;
            state.inFlight++; state.dirty = true;
            this.addEventListener('loadend', () => {
                state.inFlight--;
                try {
                    const data = this.responseType === 'json' ? this.response : JSON.parse(this.responseText);
                    if (this.status >= 200 && this.status < 300 && data?.success !== false && !(config.builder === 'avada' && data?.data?.failure)) saved(data, generation, requestNumber);
                    else saveError(data, this.status);
                } catch (error) { if (this.status < 200 || this.status >= 300) saveError(null, this.status); }
            }, { once: true });
        }
        return send.call(this, body);
    };
    function frame(node) {
        if (node.tagName !== 'IFRAME' || !node.getAttribute('src')) return;
        let source = node.getAttribute('src');
        // Breakdance opens its canvas with a direct page_id request. A workflow
        // revision is intentionally not publicly queryable, so WordPress returns
        // a 404 before Breakdance can render the canvas. Use the authenticated
        // Revisionary preview URL for that iframe while preserving Breakdance's
        // iframe/document flags and the revision-scoped save nonce.
        if (['breakdance28', 'breakdance3'].includes(config.builder) && config.revisionPreview) {
            try {
                const frameUrl = new URL(source, window.location.href);
                if (frameUrl.origin === window.location.origin && frameUrl.searchParams.has('breakdance_iframe')) {
                    const previewUrl = new URL(config.revisionPreview, window.location.href);
                    if (previewUrl.origin === window.location.origin) {
                        previewUrl.searchParams.set('breakdance_iframe', 'true');
                        previewUrl.searchParams.set('breakdance_open_document', String(config.id));
                        source = previewUrl.href;
                    }
                }
            } catch (error) { /* Keep the native frame URL if it cannot be safely resolved. */ }
        }
        const next = scoped(source); if (next !== node.src) node.src = next;
    }
    function nativeDirty() {
        if (config.builder === 'avada') return typeof owner.FusionApp?.hasContentChanged === 'function' ? owner.FusionApp.hasContentChanged() : true;
        if (config.builder !== 'divi5') return false;
        // Divi 5.14 exports its content/settings comparison, including drag,
        // delete, undo and other edits which do not emit DOM input events.
        const contexts = [owner, window];
        try { owner.document.querySelectorAll('iframe').forEach((frame) => contexts.push(frame.contentWindow)); } catch (error) { return true; }
        for (const context of contexts) {
            try {
                const api = context?.divi?.appUi;
                if (typeof api?.hasUnsavedChanges === 'function') return api.hasUnsavedChanges() !== false;
            } catch (error) { return true; }
        }
        return true; // No native proof: require another save rather than lose edits.
    }
    function start() {
        document.querySelectorAll('iframe').forEach(frame);
        new MutationObserver((records) => records.forEach((record) => {
            if (record.type === 'attributes') frame(record.target);
            record.addedNodes.forEach((node) => { if (node.nodeType === 1) { frame(node); node.querySelectorAll('iframe').forEach(frame); } });
        })).observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['src'] });
        document.addEventListener('submit', (event) => {
            if (!(event.target instanceof HTMLFormElement)) return;
            for (const [name, value] of Object.entries({ _rvy_builder_revision: config.id, _rvy_builder_nonce: config.nonce })) {
                const field = document.createElement('input'); field.type = 'hidden'; field.name = name; field.value = value; event.target.appendChild(field);
            }
        }, true);
        for (const type of ['input', 'change', 'pointerdown', 'keydown']) {
            document.addEventListener(type, (event) => {
                if (event.target.closest?.('#rvy-avada-tools, #rvy-avada-menu, .fusion-builder-save-page, #rvy-seedprod-workflow-items, #rvy-breakdance-workflow')) return;
                if (config.builder === 'seedprod' && ['pointerdown', 'keydown'].includes(type)
                    && event.target.closest?.('#seedprod-builder-save-dropdown')) return;
                // Gestures may edit layouts, so invalidate an in-flight save, but
                // navigation alone must not discard an already verified save.
                if (config.builder === 'divi5' && (type === 'pointerdown' || type === 'keydown')) { state.generation++; return; }
                changed();
            }, true);
        }
        if (window.parent !== window) return;
        if (config.builder === 'avada') {
            const blockedSelector = '.fusion-builder-layout-button-save, .fusion-builder-layout-button-delete, .fusion-builder-layout-button-edit, .fusion-page-layout a[href*="/fusion_template/"], .fusion-builder-element-button-save, .awb-sites-import-js, .awb-import-studio, [href="#fusion-builder-sections-go"], .fusion-builder-global-save, .fusion-builder-global-edit';
            const message = config.sharedResourceMessage;
            const markBlocked = () => {
                document.querySelectorAll(blockedSelector).forEach(control => {
                    control.setAttribute('aria-disabled', 'true');
                    control.setAttribute('data-rvy-avada-disabled', '1');
                    control.setAttribute('title', message);
                    control.style.setProperty('opacity', '0.45', 'important');
                    control.style.setProperty('filter', 'grayscale(1)', 'important');
                    control.style.setProperty('cursor', 'not-allowed', 'important');
                });
            };
            const hideTooltip = () => document.getElementById('rvy-avada-disabled-tooltip')?.remove();
            const tooltip = control => {
                hideTooltip();
                const tip = document.createElement('div'); tip.id = 'rvy-avada-disabled-tooltip'; tip.setAttribute('role', 'tooltip');
                tip.textContent = message;
                tip.style.cssText = 'position:fixed;z-index:2147483647;max-width:320px;padding:10px 12px;background:#222;color:#fff;border-radius:4px;font:13px/1.5 sans-serif;pointer-events:none';
                document.body.appendChild(tip);
                const box = control.getBoundingClientRect();
                tip.style.left = Math.max(8, Math.min(box.left, window.innerWidth - tip.offsetWidth - 8)) + 'px';
                tip.style.top = Math.max(8, box.bottom + tip.offsetHeight + 8 < window.innerHeight ? box.bottom + 6 : box.top - tip.offsetHeight - 6) + 'px';
                control.setAttribute('aria-describedby', tip.id);
            };
            document.addEventListener('click', event => {
                const control = event.target.closest?.('[data-rvy-avada-disabled]');
                if (!control) { hideTooltip(); return; }
                event.preventDefault(); event.stopImmediatePropagation(); tooltip(control);
            }, true);
            document.addEventListener('mouseover', event => {
                const control = event.target.closest?.('[data-rvy-avada-disabled]');
                if (control && !control.contains(event.relatedTarget)) tooltip(control);
            }, true);
            document.addEventListener('mouseout', event => {
                const control = event.target.closest?.('[data-rvy-avada-disabled]');
                if (control && !control.contains(event.relatedTarget)) hideTooltip();
            }, true);
            document.addEventListener('focusin', event => { if (event.target.matches?.('[data-rvy-avada-disabled]')) tooltip(event.target); }, true);
            document.addEventListener('keydown', event => {
                if (event.key === 'Escape') hideTooltip();
                const control = event.target.closest?.('[data-rvy-avada-disabled]');
                if (control && ['Enter', ' '].includes(event.key)) { event.preventDefault(); event.stopImmediatePropagation(); tooltip(control); }
            }, true);
            markBlocked();
            new MutationObserver(markBlocked).observe(document.body, {childList:true,subtree:true});
            const style = document.createElement('style');
            style.textContent = '.fusion-builder-save-page{min-width:70px!important;width:70px!important;padding-inline:10px!important}.rvy-avada-transition{display:inline-flex;align-items:center;justify-content:center;min-width:84px;height:54px;padding:0 14px;background:#198fd9;color:#fff;border:0;cursor:pointer;font:inherit}.rvy-avada-transition:disabled{opacity:.6}.post-status{display:none!important}#rvy-avada-tools{display:flex;align-items:center;gap:0;padding:0}.rvy-avada-menu-toggle{height:54px;width:34px;border:0;background:transparent;color:inherit;font-size:24px;cursor:pointer}#rvy-avada-menu{position:fixed;z-index:999999;background:#2a3035;color:#fff;padding:8px;box-shadow:0 4px 12px #0005}#rvy-avada-menu a{display:block;padding:10px;color:inherit;text-decoration:none}#rvy-avada-menu[hidden]{display:none}';
            document.head.appendChild(style);
            const updateControls = () => {
                const save = document.querySelector('.fusion-builder-save-page');
                document.querySelectorAll('li.post-status').forEach(node => node.style.setProperty('display', 'none', 'important'));
                if (!save || document.getElementById('rvy-avada-tools')) return;
                const tools = document.createElement('li'); tools.id = 'rvy-avada-tools';
                const fontSize = window.getComputedStyle(save.querySelector('.save-label') || save).fontSize;
                const bindTransition = (button, operation) => {
                    button.style.setProperty('font-size', fontSize, 'important');
                button.addEventListener('click', async (event) => {
                    event.preventDefault(); event.stopPropagation();
                    if (state.avadaTransitionBusy) return;
                    state.avadaTransitionBusy = true; button.disabled = true;
                    const generation = state.generation;
                    try {
                        // Avada debounces inline changes/history at 300ms.
                        // Let the final blur/input settle, then require a new
                        // native save acknowledgement even on a clean page.
                        await new Promise(resolve => window.setTimeout(resolve, 400));
                        if (generation !== state.generation || typeof owner.FusionApp?.savePostContent !== 'function') throw new Error(config.saveFirst);
                        await updateAndTransition(operation, {disabled:false, click:() => owner.FusionApp.savePostContent()});
                    } catch (error) { feedback(error.message); }
                    finally { state.avadaTransitionBusy = false; button.disabled = false; }
                });
                };
                const operation = config.canApprove ? 'approve' : (config.canSubmit ? 'submit' : '');
                if (operation) {
                    const button = document.createElement('button');
                    button.type = 'button'; button.className = 'rvy-avada-transition';
                    button.textContent = config[operation === 'approve' ? 'menuApprove' : 'menuSubmit'];
                    bindTransition(button, operation);
                    tools.appendChild(button);
                }
                document.getElementById('rvy-avada-menu')?.remove();
                const menu = document.createElement('div'); menu.id = 'rvy-avada-menu'; menu.hidden = true;
                const toggle = document.createElement('button'); toggle.type = 'button'; toggle.className = 'rvy-avada-menu-toggle';
                toggle.innerHTML = '<svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg>'; toggle.style.cssText = 'display:inline-flex;align-items:center;justify-content:center;color:#fff'; toggle.setAttribute('aria-label', config.actionsLabel); toggle.setAttribute('aria-expanded', 'false');
                toggle.addEventListener('click', (event) => {
                    event.preventDefault(); event.stopPropagation(); menu.hidden = !menu.hidden;
                    toggle.setAttribute('aria-expanded', String(!menu.hidden));
                    const rect = toggle.getBoundingClientRect(); menu.style.top = rect.bottom + 'px'; menu.style.right = Math.max(8, window.innerWidth - rect.right) + 'px';
                });
                tools.appendChild(toggle);
                // Submit belongs in the menu only when Approve occupies the bar.
                if (config.canSubmit && operation === 'approve') {
                    const submit = document.createElement('button'); submit.type = 'button';
                    submit.textContent = config.submit; submit.className = 'rvy-avada-menu-submit';
                    submit.style.cssText = 'display:block;width:100%;padding:10px;border:0;background:transparent;color:inherit;text-align:left;cursor:pointer;font-family:inherit';
                    bindTransition(submit, 'submit'); menu.appendChild(submit);
                }
                for (const [label, href] of [[config.menuCompare, config.compare], [config.previewLabel, config.revisionPreview]]) {
                    if (!href) continue;
                    const link = document.createElement('a'); link.textContent = label; link.href = href; link.target = '_blank'; link.rel = 'noopener'; link.style.setProperty('font-size', fontSize, 'important'); menu.appendChild(link);
                }

                save.closest('li').after(tools); document.body.appendChild(menu);
            };
            updateControls();
            new MutationObserver(updateControls).observe(document.body, {childList:true,subtree:true});
            return;
        }
        if (config.builder === 'seedprod') {
            // SeedProd's native Preview button uses the page permalink, which
            // does not resolve a workflow revision. Open its Revisionary preview.
            document.addEventListener('click', (event) => {
                const preview = event.target.closest?.('#seedprod-builder-preview');
                if (!preview || !config.revisionPreview) return;
                event.preventDefault(); event.stopImmediatePropagation();
                window.open(config.revisionPreview, '_blank', 'noopener');
            }, true);
            // Vue recreates the menu. Keep revision actions first and neutralize
            // its native publication control without removing Vue-owned nodes.
            const updateMenu = () => {
                const menu = document.getElementById('seedprod-builder-save-dropdown-menu');
                if (!menu) return;
                const publish = menu.querySelector('.sp-btn-publish');
                if (publish) {
                    publish.hidden = true; publish.disabled = true;
                    publish.style.setProperty('display', 'none', 'important');
                    publish.setAttribute('aria-hidden', 'true'); publish.tabIndex = -1;
                }
                const existing = menu.querySelector('#rvy-seedprod-workflow-items');
                if (existing) {
                    const approve = existing.querySelector('#rvy-builder-approve');
                    const icon = publish?.querySelector('svg');
                    if (approve && icon && !approve.querySelector('svg')) approve.insertBefore(icon.cloneNode(true), approve.firstChild);
                    if (menu.firstChild !== existing) menu.insertBefore(existing, menu.firstChild);
                    return;
                }
                const items = document.createElement('div');
                items.id = 'rvy-seedprod-workflow-items';
                for (const operation of ['approve', 'submit']) {
                    if (!config[operation === 'approve' ? 'canApprove' : 'canSubmit']) continue;
                    const button = document.createElement('button');
                    button.type = 'button'; button.id = 'rvy-builder-' + operation;
                    button.className = 'sp-btn sp-font-semibold';
                    button.style.cssText = 'display:block;width:100%;text-align:left';
                    button.textContent = config[operation === 'approve' ? 'menuApprove' : 'menuSubmit'] || config[operation];
                    if (operation === 'approve') {
                        const icon = publish?.querySelector('svg');
                        if (icon) button.insertBefore(icon.cloneNode(true), button.firstChild);
                    }
                    button.addEventListener('click', async (event) => {
                        event.preventDefault(); event.stopPropagation();
                        await updateAndTransition(operation, document.getElementById('seedprod-builder-save'));
                    });
                    items.appendChild(button);
                }
                const compare = document.createElement('a');
                compare.href = config.compare; compare.target = '_blank'; compare.rel = 'noopener';
                compare.className = 'sp-btn sp-font-semibold';
                compare.style.cssText = 'display:block;width:100%;text-align:left;box-sizing:border-box';
                compare.textContent = config.menuCompare;
                items.appendChild(compare);
                menu.insertBefore(items, menu.firstChild);
            };
            // Capture runs before Vue's publication handler, even if a caller
            // forces a click while the hidden control is still in the DOM.
            document.addEventListener('click', (event) => {
                if (!event.target.closest?.('#seedprod-builder-save-dropdown-menu .sp-btn-publish')) return;
                event.preventDefault(); event.stopImmediatePropagation();
            }, true);
            updateMenu();
            new MutationObserver(updateMenu).observe(document.body, {childList: true, subtree: true});
        }
        if (config.builder === 'divi5') {
            const operation = () => config.canApprove ? 'approve' : (config.canSubmit ? 'submit' : '');
            const statusAction = (control) => {
                return [control.textContent, control.getAttribute('aria-label'), control.getAttribute('title')]
                    .filter(Boolean).some((label) => /^save\s*&\s*(?:publish|set\s+(?:pending|private))$/i.test(label.replace(/\s+/g, ' ').trim()));
            };
            const hideStatusAction = (control) => {
                control.hidden = true;
                control.setAttribute('aria-hidden', 'true');
                control.setAttribute('tabindex', '-1');
                control.style?.setProperty('display', 'none', 'important');
            };
            const updateSave = () => {
                document.querySelectorAll('a, button, [role="button"], [role="menuitem"], [data-test-id*="save"], [data-test-id*="publish"], [data-testid*="save"], [data-testid*="publish"]')
                    .forEach((control) => { if (statusAction(control)) hideStatusAction(control); });
                const candidates = document.querySelectorAll('.et-vb-page-bar button, button.et-vb-page-bar-action-button, button[data-test-id*="save"], button[data-test-id*="publish"], button[aria-label="Save"], button[title="Save"], button[aria-label="Publish"], button[title="Publish"]');
                candidates.forEach((button) => {
                    const caption = button.textContent.trim();
                    if (button.dataset.rvyNativeSave || ['Save', 'Publish', config.approve, config.submit].includes(caption)) {
                        button.dataset.rvyNativeSave = '1';
                        const allowedOperation = operation();
                        const label = allowedOperation ? config[allowedOperation] : (config.update || 'Update');
                        // Preserve React's child elements and text-node identities. Replacing
                        // button.textContent removes children React later tries to unmount.
                        const walker = document.createTreeWalker(button, 4);
                        let text;
                        while ((text = walker.nextNode())) {
                            if (['Save', 'Publish', config.approve, config.submit].includes(text.nodeValue.trim())) {
                                if (text.nodeValue !== label) text.nodeValue = label;
                            }
                        }
                        button.setAttribute('aria-label', label);
                        button.setAttribute('title', label);
                    }
                });
            };
            updateSave();
            new MutationObserver(updateSave).observe(document.body, { childList: true, subtree: true });
            if (operation()) {
                const captureIntent = (event) => {
                    if (event.type === 'mousedown' && event.button !== 0) return;
                    if (event.type === 'keydown' && !['Enter', ' '].includes(event.key)) return;
                    if (event.target.closest?.('button[data-rvy-native-save]')) state.nativeOperation = operation();
                };
                // Divi saves on mousedown and can replace the button before click.
                for (const type of ['mousedown', 'keydown', 'click']) document.addEventListener(type, captureIntent, true);
            }
        }
        if (config.builder === 'wpbakery') {
            const operations = [];
            if (config.canApprove) operations.push('approve');
            else if (config.canSubmit) operations.push('submit');
            const primaryOperation = operations[0] || '';
            const secondaryOperation = operations[1] || '';
            const caption = (control, label) => {
                if (!control) return;
                if (control.getAttribute('title') !== label) control.setAttribute('title', label);
                if (control.getAttribute('aria-label') !== label) control.setAttribute('aria-label', label);
                const text = control.querySelector('p') || control.querySelector('.vc_btn-content') || control.querySelector('span');
                if (text && text.textContent !== label) text.textContent = label;
                else if (!text && document.createTreeWalker) {
                    const walker = document.createTreeWalker(control, 4);
                    let node;
                    while ((node = walker.nextNode())) {
                        if (node.nodeValue.trim()) { node.nodeValue = label; break; }
                    }
                }
            };
            const controlsIn = (group) => Array.from(group.querySelectorAll('a, button, [role="button"]'));
            const isPendingAction = (control) => {
                if (control.classList.contains('rvy-wpb-transition')) return false;
                // Native editor workflow links must reach the full-form save handler.
                // Their Submit caption also matches the frontend toolbar heuristic.
                // The native Update control must remain a plain save even after
                // workflow captions are applied; otherwise "Submit Revision" on
                // that control is mistaken for a transition and its click is
                // intercepted before WPBakery persists the builder content.
                if (isUpdateControl(control)) return false;
                if (control.matches('.revision-approve, .rvy-direct-approve, .revision-schedule')
                    || control.closest('.rvy-creation-ui, #submitdiv')) return false;
                const id = (control.id || '').toLowerCase();
                const status = [control.getAttribute('data-status'), control.getAttribute('data-change-status')].filter(Boolean).map(value => value.toLowerCase());
                const action = String(control.getAttribute('data-action') || '').toLowerCase();
                const attrs = [control.getAttribute('aria-label'), control.getAttribute('title'), control.textContent, control.className].filter(Boolean).join(' ').toLowerCase();
                return ['vc_button-save-as-pending', 'vc_button-save-draft'].includes(id)
                    || status.some(value => ['pending', 'pending-revision', 'draft', 'draft-revision'].includes(value))
                    || ['submit', 'save_as_pending', 'save-as-pending'].includes(action)
                    || /save[-_ ]?(?:as[-_ ]?)?pending|submit(?:[-_ ]revision| for review)?|save[-_ ]draft/.test(attrs)
                    || /(?:^|\s)(?:vc[-_])?(?:save[-_ ]as[-_ ]pending|submit)(?:\s|$)/.test(attrs);
            };
            const isUpdateControl = (control) => {
                if (control.classList.contains('rvy-wpb-transition')) return false;
                const id = (control.id || '').toLowerCase();
                const labels = [control.getAttribute('data-change-status'), control.getAttribute('data-action'), control.getAttribute('aria-label'), control.getAttribute('title'), control.textContent]
                    .filter(Boolean).map(value => value.trim().toLowerCase());
                const classes = String(control.className || '').toLowerCase().split(/\s+/);
                return id === 'vc_button-update' || id === 'vc_button-save-draft'
                    || labels.some(value => /^(?:publish|update|save draft)$/.test(value))
                    || classes.some(value => /(?:^|[-_])update(?:$|[-_])/.test(value));
            };
            const setHidden = (control, hidden) => {
                control.hidden = hidden;
                control.setAttribute('aria-hidden', hidden ? 'true' : 'false');
                if (hidden) control.setAttribute('tabindex', '-1');
                else control.removeAttribute('tabindex');
                if (control.style?.setProperty) control.style.setProperty('display', hidden ? 'none' : '', hidden ? 'important' : '');
                else if (control.style) control.style.display = hidden ? 'none' : '';
            };
            const saveGroups = () => {
                // Prefer WPBakery's save-button wrappers. The outer navbar also
                // matches the generic selectors, but can contain more than one
                // responsive save group; processing it as well duplicates the
                // workflow action beside its nested Update buttons.
                const saveButtons = Array.from(document.querySelectorAll('.vc_save-buttons, [class*="save-buttons"], [data-vc-control*="save"]'));
                const candidates = saveButtons.length ? saveButtons : Array.from(document.querySelectorAll('#vc_navbar, .vc_navbar, .vc_ui-navbar, [class*="vc_save"]'));
                const actionable = candidates.filter(group => controlsIn(group).some(control => isUpdateControl(control) || isPendingAction(control)));
                const groups = actionable.filter(group => !actionable.some(child => child !== group && group.contains(child)));
                const hasVisibleSave = group => controlsIn(group).some(control =>
                    (isUpdateControl(control) || isPendingAction(control)) && control.getClientRects().length > 0);
                return groups.sort((a, b) => Number(hasVisibleSave(b)) - Number(hasVisibleSave(a)));
            };
            const updateControls = () => {
                const groups = saveGroups();
                const workflowGroup = groups.find(group => controlsIn(group).some(control =>
                    (isUpdateControl(control) || isPendingAction(control)) && control.getClientRects().length > 0)) || groups[0];
                // WPBakery has responsive copies of its save controls. Keep one
                // Revisions action in the currently visible toolbar group, and
                // discard any duplicate clones left by another toolbar wrapper.
                document.querySelectorAll('.rvy-wpb-transition').forEach(control => {
                    if (!workflowGroup || !workflowGroup.contains(control)) control.remove();
                });
                const allControls = new Set(document.querySelectorAll('[id^="vc_button-"], [data-change-status], [data-action]'));
                groups.forEach(group => controlsIn(group).forEach(control => allControls.add(control)));
                // Revisor/WPBakery combinations can alter the generated IDs and
                // button classes. Include semantically named controls from the
                // builder toolbar roots, then classify them by status/caption.
                document.querySelectorAll('#vc_navbar a, #vc_navbar button, .vc_navbar a, .vc_navbar button, .vc_ui-navbar a, .vc_ui-navbar button, [class*="vc_save"] a, [class*="vc_save"] button').forEach(control => allControls.add(control));
                for (const control of allControls) {
                    if (isPendingAction(control)) {
                        if (primaryOperation) {
                            setHidden(control, false);
                            control.setAttribute('data-rvy-operation', primaryOperation);
                            caption(control, config[primaryOperation]);
                        } else {
                            // A pending revision with no allowed transition must not expose
                            // WPBakery's Save as Pending/Submit action.
                            control.removeAttribute('data-rvy-operation');
                            setHidden(control, true);
                        }
                    } else if (isUpdateControl(control)) {
                        caption(control, config.update || 'Update');
                    }
                }
                for (const group of groups) {
                    // Both Save Draft and Update can be rendered in the same
                    // responsive wrapper. Keep the native Update when present.
                    const nativeSaves = controlsIn(group).filter(isUpdateControl);
                    const retainedSave = nativeSaves.find(control => control.id === 'vc_button-update') || nativeSaves[0];
                    nativeSaves.forEach(control => setHidden(control, control !== retainedSave));
                    // Generated actions retain their operation and never enter
                    // native button classification on subsequent observer passes.
                    group.querySelectorAll('.rvy-wpb-transition').forEach(control => {
                        if (control.getAttribute('data-rvy-operation') !== primaryOperation) control.remove();
                    });
                    // WPBakery renders Save Draft for draft revisions and Save as Pending
                    // for pending revisions. Both controls submit the native vc_save;
                    // use whichever variant this post status produced for transitions.
                    const nativeAction = controlsIn(group).find(isPendingAction);
                    if (group !== workflowGroup) {
                        if (nativeAction) {
                            nativeAction.removeAttribute('data-rvy-operation');
                            setHidden(nativeAction, true);
                        }
                        group.querySelectorAll('.rvy-wpb-transition').forEach(control => control.remove());
                        continue;
                    }
                    if (!nativeAction) {
                        // Submitted WPBakery revisions can render only the native
                        // Update control. Keep that control as a plain save, and add
                        // a separate Revisions action which saves first, then calls
                        // the nonce-checked workflow transition endpoint.
                        const nativeSave = retainedSave;
                        if (!primaryOperation || !nativeSave || group.querySelector('.rvy-wpb-transition[data-rvy-operation="' + primaryOperation + '"]')) continue;
                        const addTransition = (operation) => {
                            if (!operation || document.querySelector('.rvy-wpb-transition[data-rvy-operation="' + operation + '"]')) return;
                            const transition = nativeSave.cloneNode(true);
                            transition.id = 'rvy-wpb-transition-' + operation;
                            transition.setAttribute('href', 'javascript:;');
                            transition.removeAttribute('data-change-status');
                            transition.removeAttribute('data-action');
                            transition.classList.add('rvy-wpb-transition');
                            transition.setAttribute('data-rvy-operation', operation);
                            caption(transition, config[operation]);
                            nativeSave.parentNode.insertBefore(transition, nativeSave);
                        };
                        addTransition(primaryOperation);
                        addTransition(secondaryOperation);
                        continue;
                    }
                    if (primaryOperation) {
                        setHidden(nativeAction, false);
                        nativeAction.setAttribute('data-rvy-operation', primaryOperation);
                        if (!nativeAction.classList.contains('rvy-wpb-transition')) {
                            nativeAction.setAttribute('data-rvy-native-action', '1');
                        }
                        caption(nativeAction, config[primaryOperation]);
                        if (secondaryOperation && !group.querySelector('.rvy-wpb-transition')) {
                            const secondary = document.createElement('a');
                            secondary.href = 'javascript:;';
                            secondary.className = ((nativeAction.className || '') + ' rvy-wpb-transition').trim();
                            secondary.setAttribute('data-rvy-operation', secondaryOperation);
                            secondary.setAttribute('title', config[secondaryOperation]);
                            secondary.setAttribute('aria-label', config[secondaryOperation]);
                            const icon = document.createElement('i');
                            icon.className = nativeAction.querySelector('i')?.className || '';
                            icon.setAttribute('aria-hidden', 'true');
                            const text = document.createElement('p');
                            text.textContent = config[secondaryOperation];
                            secondary.appendChild(icon);
                            secondary.appendChild(text);
                            nativeAction.parentNode.insertBefore(secondary, nativeAction.nextSibling);
                        }
                    } else {
                        setHidden(nativeAction, true);
                    }
                }
            };
            updateControls();
            window.addEventListener('resize', updateControls);
            new MutationObserver(updateControls).observe(document.body, { childList: true, subtree: true });
            // The first toolbar pass can add a temporary action beside Update
            // before WPBakery finishes rendering its native Save Draft button.
            // Once the native control has been wired for this operation, drop
            // only the matching fallback clone. This observer does not rerun
            // toolbar setup, so its cleanup cannot restart the editor's load.
            const removeDuplicateFallbacks = () => {
                if (!primaryOperation) return;
                document.querySelectorAll('.rvy-wpb-transition[data-rvy-operation="' + primaryOperation + '"]').forEach(transition => {
                    const group = transition.closest('.vc_save-buttons, [class*="save-buttons"], [data-vc-control*="save"], #vc_navbar, .vc_navbar, .vc_ui-navbar, [class*="vc_save"]');
                    if (!group) return;
                    const nativeAction = group.querySelector('[data-rvy-native-action="1"][data-rvy-operation="' + primaryOperation + '"]');
                    if (nativeAction && !nativeAction.classList.contains('rvy-wpb-transition')) transition.remove();
                });
            };
            new MutationObserver(removeDuplicateFallbacks).observe(document.body, { childList: true, subtree: true });
            document.addEventListener('click', (event) => {
                const action = event.target.closest?.('#vc_button-save-as-pending, #vc_button-save-draft, .rvy-wpb-transition, [data-change-status="pending"], [data-action="submit"]')
                    || event.target.closest?.('a, button, [role="button"]');
                if (!action) return;
                if (!action.className?.includes?.('rvy-wpb-transition') && !isPendingAction(action)) return;
                event.preventDefault(); event.stopImmediatePropagation();
                // Use the native Update paired with the clicked responsive toolbar;
                // never let WPBakery's status-changing button publish a revision.
                const group = action.closest('.vc_save-buttons, [class*="save-buttons"], [data-vc-control*="save"], #vc_navbar, .vc_navbar, .vc_ui-navbar, [class*="vc_save"]');
                const save = group?.querySelector('[id="vc_button-update"]')
                    || controlsIn(group || document.body).find(control => isUpdateControl(control));
                const operation = action.getAttribute('data-rvy-operation');
                if (operation) updateAndTransition(operation, save);
            }, true);
        }
        if (['breakdance28', 'breakdance3'].includes(config.builder)) {
            // Breakdance 2.8 and 3 have shipped different save button
            // attributes. Prefer their stable hooks, then fall back to the
            // top bar's accessible Save/Update button label.
            const nativeSave = () => {
                const direct = document.getElementById('main-save-button') || document.querySelector('[data-test-id="main-save-button"]');
                const isSaveSectionControl = control => {
                    const section = control?.closest?.('.topbar-section');
                    return !section || (section.className.includes('topbar-section-bl') && !section.querySelector('[aria-label="Exit"]'));
                };
                if (direct && isSaveSectionControl(direct)) return direct;
                const buttons = Array.from(document.querySelectorAll('button, [role="button"], input[type="submit"]'));
                return buttons.find(button => isSaveSectionControl(button) && /^(save|update)$/i.test((button.getAttribute('aria-label') || button.getAttribute('title') || button.textContent || button.value || '').trim())) || null;
            };
            const positionMenu = (wrapper, save, host) => {
                const toggle = wrapper.firstChild;
                const menu = wrapper.querySelector('#rvy-breakdance-menu');
                const toggleRect = toggle?.getBoundingClientRect?.();
                if (!toggleRect || !menu) return;
                const width = window.innerWidth || document.documentElement.clientWidth || 1024;
                const height = window.innerHeight || document.documentElement.clientHeight || 768;
                menu.style.left = Math.max(4, Math.min(toggleRect.right - 210, width - 214)) + 'px';
                menu.style.top = Math.max(4, Math.min(toggleRect.bottom + 4, height - 60)) + 'px';
            };
            const mountMenu = () => {
                const save = nativeSave();
                if (!save) return;
                // Both versions wrap the native Save button in a div. Mount
                // beside that button inside its wrapper, reserving toolbar width.
                const host = save.parentElement?.closest('div');
                if (!host) return;
                let wrapper = document.getElementById('rvy-breakdance-workflow');
                if (!wrapper) {
                    wrapper = document.createElement('div'); wrapper.id = 'rvy-breakdance-workflow';
                    wrapper.style.cssText = 'display:inline-flex;flex:0 0 24px;align-items:center;width:24px;height:36px;pointer-events:none';
                    const toggle = document.createElement('button'); toggle.type = 'button';
                    toggle.textContent = '\u22ee'; toggle.setAttribute('aria-label', config.actionsLabel);
                    toggle.setAttribute('aria-haspopup', 'menu'); toggle.setAttribute('aria-expanded', 'false');
                    toggle.style.cssText = 'box-sizing:border-box;width:24px;height:36px;font-size:22px;line-height:1;padding:4px;cursor:pointer;pointer-events:auto';
                    const menu = document.createElement('div'); menu.id = 'rvy-breakdance-menu'; menu.hidden = true;
                    toggle.setAttribute('aria-controls', menu.id); menu.setAttribute('role', 'menu');
                    menu.style.cssText = 'box-sizing:border-box;position:fixed;left:0;top:0;min-width:210px;max-height:calc(100vh - 56px);overflow-y:auto;z-index:2147483647;background:#fff;color:#1d2327;padding:6px;border:1px solid #8c8f94;box-shadow:0 2px 8px #0003;pointer-events:auto';
                    const close = () => { menu.hidden = true; toggle.setAttribute('aria-expanded', 'false'); };
                    for (const operation of ['approve', 'submit']) {
                        if (!config[operation === 'approve' ? 'canApprove' : 'canSubmit']) continue;
                        const item = document.createElement('button'); item.type = 'button'; item.textContent = config[operation];
                        item.id = 'rvy-builder-' + operation; item.setAttribute('role', 'menuitem');
                        item.style.cssText = 'display:block;width:100%;padding:8px;text-align:left;color:inherit;background:white;border:0;cursor:pointer';
                        item.addEventListener('click', () => updateAndTransition(operation, nativeSave()));
                        menu.appendChild(item);
                    }
                    for (const [url, label] of [[config.compare, config.menuCompare], [config.revisionPreview, config.previewLabel]]) {
                        const item = document.createElement('a'); item.href = url; item.textContent = label;
                        item.target = '_blank'; item.rel = 'noopener'; item.setAttribute('role', 'menuitem');
                        item.style.cssText = 'display:block;padding:8px;color:inherit;text-decoration:none!important'; menu.appendChild(item);
                    }

                    toggle.addEventListener('click', () => { menu.hidden = !menu.hidden; toggle.setAttribute('aria-expanded', String(!menu.hidden)); if (!menu.hidden) { const save = nativeSave(); positionMenu(wrapper, save, save?.closest?.('.topbar-section.topbar-section-bl')); menu.querySelector('[role="menuitem"]')?.focus(); } });
                    wrapper.appendChild(toggle); wrapper.appendChild(menu);
                    document.addEventListener('click', (event) => { if (!wrapper.contains(event.target)) close(); });
                    wrapper.addEventListener('keydown', (event) => {
                        if (event.key === 'Escape') { close(); toggle.focus(); }
                        if (['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) {
                            event.preventDefault(); const items = Array.from(menu.querySelectorAll('[role="menuitem"]'));
                            const index = items.indexOf(document.activeElement);
                            const next = event.key === 'Home' ? 0 : event.key === 'End' ? items.length - 1 : (index + (event.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length;
                            items[next]?.focus();
                        }
                    });
                }
                host.style.display = 'inline-flex'; host.style.alignItems = 'center';
                if (wrapper.parentNode !== host) host.appendChild(wrapper);
                positionMenu(wrapper, save, host);
            };
            mountMenu(); new MutationObserver(mountMenu).observe(document.body, { childList: true, subtree: true });
            window.addEventListener('resize', () => { const wrapper = document.getElementById('rvy-breakdance-workflow'); const save = nativeSave(); if (wrapper && save) positionMenu(wrapper, save, save.closest?.('.topbar-section.topbar-section-bl')); });
            window.addEventListener('scroll', () => { const wrapper = document.getElementById('rvy-breakdance-workflow'); const save = nativeSave(); if (wrapper && save) positionMenu(wrapper, save, save.closest?.('.topbar-section.topbar-section-bl')); }, true);
        }
        if (config.builder === 'bricks') {
            // Bricks' View on frontend button normally opens the revision's
            // permalink. Route it through Revisionary so revision content and
            // the preview bar are rendered outside the editor canvas.
            if (config.frontendPreview) {
                const selector = '#bricks-toolbar .new-tab a, #bricks-toolbar-top .new-tab a';
                const updateFrontendLink = () => {
                    document.querySelectorAll(selector).forEach((link) => {
                        if (link.getAttribute('href') !== config.frontendPreview) link.setAttribute('href', config.frontendPreview);
                    });
                };
                updateFrontendLink();
                new MutationObserver(updateFrontendLink).observe(document.body, { childList: true, subtree: true });
            }
            const operation = () => config.canApprove ? 'approve' : (config.canSubmit ? 'submit' : '');
            const toolbarElement = () => document.querySelector('#bricks-toolbar-top') || document.querySelector('#bricks-toolbar');
            const findNativeSave = () => {
                const toolbar = toolbarElement();
                if (!toolbar) return null;
                return toolbar.querySelector('li.save, [data-name="save"], [data-action="save"], [data-status="save"]')
                    || Array.from(toolbar.querySelectorAll('li, button, [role="button"]')).find(control => /^(?:save|update|publish)$/i.test((control.getAttribute('aria-label') || control.getAttribute('title') || control.getAttribute('data-balloon') || control.textContent || '').trim()));
            };
            const updateControls = () => {
                const toolbar = toolbarElement();
                const controls = toolbar ? Array.from(toolbar.querySelectorAll('li, button, [role="button"]')) : [];
                const save = findNativeSave();
                const publishControl = Array.from(toolbar?.querySelectorAll('[data-name="publish"], [data-action="publish"], [data-status="publish"], [aria-label="Publish"], [title="Publish"]') || [])
                    .find(control => !control.closest('[data-rvy-bricks-transition]'))
                    || controls.find(control => !control.hasAttribute('data-rvy-bricks-transition') && /^(?:publish|submit(?: for review)?)$/i.test((control.getAttribute('aria-label') || control.getAttribute('title') || control.getAttribute('data-balloon') || control.textContent || '').trim()));
                let publish = publishControl?.closest('li, button, [role="button"]') || publishControl;
                let fallback = toolbar?.querySelector('[data-rvy-bricks-transition]');
                if (publish || !operation()) {
                    fallback?.remove();
                } else if (save) {
                    // Bricks omits Publish entirely when the user cannot publish
                    // pages. A Revisor can still submit their workflow revision.
                    // Match the native control and its order (between Redo and
                    // Edit in WordPress), without granting publish_pages.
                    if (!fallback) {
                        fallback = document.createElement('li');
                        fallback.setAttribute('data-rvy-bricks-transition', '1');
                        fallback.setAttribute('tabindex', '0');
                        fallback.setAttribute('draggable', 'false');
                        fallback.setAttribute('data-balloon-pos', 'bottom-right');
                        fallback.style.order = '200';
                        fallback.innerHTML = '<span class="bricks-svg-wrapper" data-name="publish"><svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="bricks-svg"><path d="M12 1.498v9.75" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path><path d="M9 5.011a9 9 0 1 0 6 0" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path></svg></span>';
                        const group = toolbar.querySelector('.group-wrapper.end') || save.parentElement;
                        group.insertBefore(fallback, group.querySelector('.wordpress') || save);
                    }
                    publish = fallback;
                }
                if (save) {
                    if (save.getAttribute('data-balloon') !== config.updateRevision) save.setAttribute('data-balloon', config.updateRevision);
                    if (save.getAttribute('aria-label') !== config.updateRevision) save.setAttribute('aria-label', config.updateRevision);
                    if (save.getAttribute('title') !== config.updateRevision) save.setAttribute('title', config.updateRevision);
                    save.setAttribute('role', 'button');
                }
                if (publish) {
                    const allowedOperation = operation();
                    if (allowedOperation) {
                        if (publish.getAttribute('data-balloon') !== config[allowedOperation]) publish.setAttribute('data-balloon', config[allowedOperation]);
                        if (publish.getAttribute('aria-label') !== config[allowedOperation]) publish.setAttribute('aria-label', config[allowedOperation]);
                        if (publish.getAttribute('title') !== config[allowedOperation]) publish.setAttribute('title', config[allowedOperation]);
                        publish.setAttribute('role', 'button');
                    } else {
                        // A pending revision with no transition permission can only Update.
                        // Hide Bricks' native Publish action and block it in the capture handler.
                        publish.hidden = true;
                        publish.setAttribute('aria-hidden', 'true');
                        publish.setAttribute('tabindex', '-1');
                        if (publish.style?.setProperty) publish.style.setProperty('display', 'none', 'important');
                        else if (publish.style) publish.style.display = 'none';
                    }
                }
            };
            updateControls();
            new MutationObserver(updateControls).observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['data-balloon'] });
            document.addEventListener('keydown', (event) => {
                const fallback = event.target.closest?.('[data-rvy-bricks-transition]');
                if (!fallback || !['Enter', ' '].includes(event.key)) return;
                event.preventDefault(); event.stopImmediatePropagation();
                fallback.click();
            }, true);
            document.addEventListener('click', (event) => {
                const control = event.target.closest?.('#bricks-toolbar-top li, #bricks-toolbar-top button, #bricks-toolbar-top [role="button"], #bricks-toolbar li, #bricks-toolbar button, #bricks-toolbar [role="button"]');
                if (!control) return;
                const publish = control.matches?.('[data-name="publish"], [data-action="publish"], [data-status="publish"], [aria-label="Publish"], [title="Publish"]')
                    || control.querySelector('[data-name="publish"], [data-action="publish"], [data-status="publish"], [aria-label="Publish"], [title="Publish"]');
                if (publish) {
                    event.preventDefault(); event.stopImmediatePropagation();
                    const allowedOperation = operation();
                    if (allowedOperation) {
                        state.nativeOperation = allowedOperation;
                        findNativeSave()?.click();
                    }
                    else feedback(config.saveFirst);
                }
            }, true);
        }
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true }); else start();
})();
