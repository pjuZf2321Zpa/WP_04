<?php
defined('ABSPATH') || exit;

/**
 * @package     PublishPress\Revisions\RevisionaryElementor
 * @author      PublishPress <help@publishpress.com>
 * @copyright   Copyright (c) 2026 PublishPress. All rights reserved.
 * @license     GPLv2 or later
 * @since       1.0.0
 */
class RevisionaryElementor
{	
    private $revision_id = 0;
    private $orig_post_id = 0;
    private $save_in_progress = false;
	private $disable_filtering = false;
    private $buffered_content = [];
    private $revision_saves = [];

    function __construct() {
        if (rvy_get_option('permissions_compat_mode')) { return; }
        global $revisionary;

        if ( ! defined('RVY_CONTENT_ROLES') || !$revisionary->content_roles->is_direct_file_access() ) {
			add_action('template_redirect', [$this, 'act_template_redirect'], 5 ); // Execute after RevisionaryFront::act_template_redirect() in case there is an upstream redirect
		}
		
        add_filter('default_options_rvy', [$this, 'fltDefaultOptions']);
        add_filter('options_sitewide_rvy', [$this, 'fltDefaultOptionScope']);
        add_filter('revisionary_option_captions', [$this, 'fltOptionCaptions']);
        add_filter('revisionary_option_sections', [$this, 'fltOptionSections']);
        add_action('revisionary_option_ui_revision_options', [$this, 'actRevisionOptionsUI']);
        add_action('revisionary_auto_submit_setting_ui', [$this, 'actAutoSubmitSettingUI'], 10, 3);

        add_filter('revisionary_detect_id', [$this, 'elementorDetectID'], 10, 2);

        // Editor JS setup, scripts
        add_filter('elementor/document/config', [$this, 'fltPanelConfig']);
        add_filter('elementor/document/urls/wp_preview', [$this, 'fltWPpreview']);
        add_filter('revisionary_queue_row_actions', [$this, 'fltRevisionQueueRowActions'], 10, 2);
        add_filter('revisionary_create_revision_redirect', [$this, 'fltCreateRevisionRedirect'], 10, 2);

        add_action('wp_print_scripts', [$this, 'frontScripts']);
        add_action('elementor/editor/after_enqueue_scripts', [$this, 'enqueueWorkflowEditorScript']);
        add_action('wp_ajax_revisionary_elementor_transition', [$this, 'ajaxWorkflowTransition']);
        add_action('wp_ajax_elementor_ajax', [$this, 'prepareRevisionSave'], -100);
        add_action('elementor/document/after_save', [$this, 'finishRevisionSave'], 1000, 2);
        add_filter('elementor/document/save/data', [$this, 'normalizeRevisionDocument'], 1000, 2);

        // Server-side database update hooks
        add_action('elementor/widgets/widgets_registered', [$this, 'elementorMonitorQueries']);
        add_filter('revisionary_do_submission_redirect', [$this, 'elementorDisableSubmissionRedirect']);

        add_filter('posts_request', [$this, 'fltPostsRequestPastRevisions'], 10, 2);

        if (defined('WPSEO_VERSION')) { // Yoast SEO: prevent revision changes from being applied to published post without approval
            add_action('init', [$this, 'wpseoCompatWorkaround'], 11);
        }

        add_filter( "get_post_metadata", [$this, 'fltPostCSSrules'], 10, 5);

        add_action("wp_enqueue_scripts", [$this, 'actEnqueueElementorPostCSS'], 11);

        add_filter('pre_option_elementor_css_print_method', [$this, 'fltCSSprintMethod']);
        add_filter('pre_option_elementor_element_cache_ttl', [$this, 'fltPreviewElementCacheTTL']);

        add_filter('option_rank_math_modules', [$this, 'fltRankMathModules']);


        add_action('elementor/document/before_save', [$this, 'actFlagBuilderSave'], 10, 2);
        add_action('elementor/document/after_save', [$this, 'actUnflagBuilderSave'], 99, 2);

        if (defined('REVISIONARY_ELEMENTOR_FORCE_LIBRARY_FILTERING') && REVISIONARY_ELEMENTOR_FORCE_LIBRARY_FILTERING) {
            add_filter('revisionary_enabled_post_types', [$this, 'fltEnabledPostTypes']);
        }

        add_filter('presspermit_unfiltered_post_types', [$this, 'fltPressPermitUnfilteredPostTypes']);

        //phpcs:ignore Squiz.PHP.CommentedOutCode.Found
        /*
        // Elementor Revision edit: action=elementor_ajax, actions={"document-29418":{"action":"get_document_config","data":{"id":29418}}}
        */

		add_action('admin_print_footer_scripts', function() {
            if (!empty($_REQUEST['page']) && ('revisionary-q' == $_REQUEST['page'])) {              //phpcs:ignore WordPress.Security.NonceVerification.Recommended
                ?>
                <style>
                .edit_with_elementor, .elementor {display:inline !important;}
                </style>
                <?php
            }
        });
		
        add_filter('elementor/editor/localize_settings', [$this, 'fltElementorEditorSettings']);
		
        if (defined('REVISIONARY_ELEMENTOR_BYPASS_SAVE_FILTER')) {
            add_filter( 'elementor/document/save/data', [ $this, 'fltBufferContent' ], 9, 2 );
            add_filter( 'elementor/document/save/data', [ $this, 'fltRestoreContent' ], 11, 2 );
        }

        $preview_arg = (defined('RVY_PREVIEW_ARG')) ? sanitize_key(constant('RVY_PREVIEW_ARG')) : 'rv_preview';
			
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
        if (((!empty($_GET[$preview_arg]) || !empty($_GET['_ppp'])) && empty($_REQUEST['preview_id'])) || !empty($_GET['mark_current_revision'])) {
            add_filter(
                'option_elementor_experiment-e_element_cache', 
                function($option_val) {
                    return 'inactive';
                }
            );
        }

        add_filter(
            'revisionary_unrevisioned_postmeta',
            function ($meta) {
                $meta['_elementor_element_cache'] = true;

                return $meta;
            }
        );

        add_action(
            'revision_applied', 
            function ($published_id) {
                delete_metadata('post', $published_id, '_elementor_element_cache');
                $this->clearPostCSS($published_id);

                if (rvy_get_option('elementor_full_cache_clear')) {
                    $this->elementorClearCache();
                }
            }
        );

        add_action(
            'revision_approved', 
            function ($post_id, $revision_id) {
                delete_metadata('post', $post_id, '_elementor_element_cache');
            },
            10, 2
        );

        add_action(
            'revision_restored', 
            function ($post_id, $revision_id) {
                delete_metadata('post', $post_id, '_elementor_element_cache');
                $this->clearPostCSS($post_id);

                if (rvy_get_option('elementor_full_cache_clear')) {
                    $this->elementorClearCache();
                }
            },
            10, 2
        );

        add_action(
            'revisionary_front_init',
            function() {
                if ($post_id = rvy_detect_post_id()) {
                   $_post = get_post($post_id);

                   if (!$_post || !is_a($_post, 'WP_Post')) {
                      wp_redirect(site_url());
                      exit;
                   }
                }
            }
        );

        // Useful hooks used in past version of Revisions:
        // 'elementor/documents/ajax_save/return_data'
        // 'elementor/editor/wp_head'
    }

    /**
     * The published post keeps its own _elementor_css meta and post-{ID}.css file when a revision is applied,
     * so Elementor would keep serving the pre-revision stylesheet (no rules for elements added in the revision).
     * Drop it so Elementor regenerates it from the new _elementor_data on the next page load.
     */
    function clearPostCSS($post_id) {
        $post_id = (int) $post_id;

        if (!$post_id) {
            return;
        }

        if (class_exists('\Elementor\Core\Files\CSS\Post')) {
            try {
                \Elementor\Core\Files\CSS\Post::create($post_id)->delete();
            } catch (\Throwable $e) {
            }
        }

        delete_metadata('post', $post_id, '_elementor_css');
    }

    function elementorClearCache() {
        $dirs = wp_upload_dir( null, false );
        $path =  $dirs['basedir'] . '/elementor/' . '*';

        foreach ( glob( $path ) as $file_path ) {
            wp_delete_file( $file_path );
        }

        delete_post_meta_by_key('_elementor_css');
        delete_post_meta_by_key('_elementor_element_cache');
        delete_post_meta_by_key('_elementor_page_assets');

        delete_option('elementor-custom-breakpoints-files');

        delete_option('_elementor_assets_data');
    }

    // Bypass Elementor's Content Sanitizer module on Revision Edit due to erroneous handling
    function fltBufferContent($data, $document) {
        if (!empty($document) && !empty($document->post) && rvy_in_revision_workflow($document->post->ID)) {
            $this->buffered_content[$document->post->ID] = $data;
        }

        return $data;
    }

    function fltRestoreContent($data, $document) {
        if (!empty($document) && !empty($document->post) && !empty($this->buffered_content[$document->post->ID])) {
            $data = $this->buffered_content[$document->post->ID];
        }

        return $data;
    }

    function fltElementorEditorSettings($settings) {
        $settings['autosave_interval'] = 99999999;
        return $settings;
    }

    function actFlagBuilderSave($elem_doc, $data) {
        if (!$id = $elem_doc->get_main_id()) {
            $id = true;
        }

        $this->save_in_progress = $id;

        return $data;
    }

    function actUnflagBuilderSave($elem_doc, $data) {
        global $revisionary;
		
        $this->save_in_progress = false;
		
        $post_id = $elem_doc->get_main_id();

        if ($post_status = get_post_field('post_status', $post_id)) {
            if (in_array($post_status, ['draft', 'auto-draft'])
            && !rvy_in_revision_workflow($post_id)
            ) {
                return;
            }
        }

		$revisionary->skip_filtering = true;
		
        if (!rvy_in_revision_workflow($post_id) 
		&& ('elementor_library' != get_post_field('post_type', $post_id)) 
		&& current_user_can('edit_post', $post_id)) {
			$revisionary->skip_filtering = false;
            return;
        }
		
		$revisionary->skip_filtering = false;

        $this->get_last_user_revision($post_id);
        
        if ($this->revision_id) {
            $this->restore_revision($this->revision_id);
        }
    }

    function fltEnabledPostTypes($types) {
        $types['elementor_library'] = true;

        return $types;
    }

    function fltPressPermitUnfilteredPostTypes($types) {
		$types[] = 'elementor_library';

        return $types;
	}

    function get_last_user_revision($post_id) {
        global $current_user, $wpdb;
    
        if (rvy_in_revision_workflow($post_id)) {
            return get_post($post_id);
        }

		static $busy;
		
		if (!empty($busy)) {
			return;
		}
		
		$busy = true;
		
        remove_filter('query', [$this, 'actAdjustElementorUpdateQuery']);
		
        $target_id = ('revision' == get_post_field('post_type', $post_id)) ? get_post_field('post_parent', $post_id) : $post_id;
		
		if (rvy_in_revision_workflow($target_id)) {
			$target_id = rvy_post_id($target_id);
		}
		
        $revision_status_csv = implode("','", array_map('sanitize_key', rvy_revision_statuses()));

        $revision = $wpdb->get_row(                                                                                                     // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $wpdb->prepare(
                "SELECT * FROM $wpdb->posts WHERE (post_author = %d OR post_author = 1) AND post_status IN ('draft', 'pending')"
				. " AND post_type != 'revision'"
                . " AND post_mime_type IN ('$revision_status_csv')"                                                                     // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                . " AND comment_count = %d ORDER BY ID DESC LIMIT 1",

                $current_user->ID,
                $target_id
            )
        );

		if ($revision) {
			if ('revision' != get_post_field('post_type', $revision->comment_count)) {
				$this->restore_revision($revision->ID);
				
                clean_post_cache($revision->ID);

			}
		} elseif ('elementor_library' == get_post_field('post_type', $target_id)) {
                if (!empty($_REQUEST['initial_document_id']) && ((int) $_REQUEST['initial_document_id'] != $target_id)) {               //phpcs:ignore WordPress.Security.NonceVerification.Recommended
                    $post_status = get_post_field('post_status', $target_id);

                    if (!$post_status || (in_array($post_status, ['draft', 'auto-draft']) && !rvy_in_revision_workflow($target_id))) {
                        return;
                    }

                    require_once( dirname(REVISIONARY_FILE).'/admin/revision-action_rvy.php');

                    if ($this->revision_id = rvy_revision_create($target_id, ['force' => true, 'suppress_redirect' => true])) {
                        $revision = get_post($this->revision_id);
                        
                        $wpdb->update(                                                                                                  // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                            $wpdb->posts, 
                            ['post_status' => 'draft', 'post_mime_type' => 'draft-revision', 'post_author' => $current_user->ID], 
                            ['ID' => $this->revision_id]
                        );
                    }
                }
            }

        add_filter('query', [$this, 'actAdjustElementorUpdateQuery']);

		$busy = false;
		
        return $revision;
    }
	
	function restore_revision($revision_id) {
        global $current_user, $wpdb;

        if ($revision = $wpdb->get_row(                                                                 // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $wpdb->prepare(
                "SELECT * FROM $wpdb->posts WHERE post_status IN ('draft', 'pending', 'inherit')"
                . " AND (post_author = %d OR post_author = 1)"
				. " AND ID = %d ORDER BY ID DESC LIMIT 1",

                $current_user->ID,
                $revision_id
            )
        )) {
			if ('revision' == get_post_field('post_type', $revision->comment_count)) {
				$wpdb->update(                                                                          // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                    $wpdb->posts, 
                    ['comment_count' => get_post_field('post_parent', $revision->comment_count)], 
                    ['ID' => $revision_id]
                );
			}
			
			if (!in_array($revision->post_mime_type, ['draft-revision', 'pending-revision'])) {
				if ('draft' == $revision->post_status) {
					$wpdb->update(                                                                      // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                        $wpdb->posts, 
                        ['post_mime_type' => 'draft-revision', 'post_author' => $current_user->ID], 
                        ['ID' => $revision_id]
                    );

				} elseif ('pending' == $revision->post_status) {
					$wpdb->update(                                                                      // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                        $wpdb->posts, 
                        ['post_mime_type' => 'pending-revision', 'post_author' => $current_user->ID], 
                        ['ID' => $revision_id]
                    );

				} elseif ('inherit' == $revision->post_status) {
					if ($revision_status = get_post_meta($revision_id, '_rvy_revision_status', true)) {
						if ($main_post_id = rvy_post_id($revision->post_parent)) {
							if ($main_post_id != $revision->ID) {
                                if ('revision' == get_post_field('post_type', $main_post_id)) {
									$main_post_id = get_post_field('post_parent', $main_post_id);
								}
								
								$post_status = str_replace('-revision', '', $revision_status);
                                
                                $wpdb->update(                                                          // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                                    $wpdb->posts, 
                                    ['post_type' => get_post_field('post_type', $main_post_id), 'post_status' => $post_status, 'post_mime_type' => $revision_status, 'comment_count' => $main_post_id], 
                                    ['ID' => $revision_id]
                                );
                                
                                $this->revision_id = $revision_id;
                                
                                add_action('shutdown', function() {
                                    global $wpdb;
                                    $wpdb->update(                                                      // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                                        $wpdb->posts, 
                                        ['post_mime_type' => 'pending-revision', 'post_author' => $current_user->ID], 
                                        ['ID' => $this->revision_id, 'post_status' => 'pending']
                                    );
                                    
                                    $wpdb->update(                                                      // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                                        $wpdb->posts, 
                                        ['post_mime_type' => 'draft-revision', 'post_author' => $current_user->ID], 
                                        ['ID' => $this->revision_id, 'post_status' => 'draft']
                                    );
                                });
                            }
						}
					}
				}
			}
			
            clean_post_cache($revision_id);
			
			return true;
        }
		
		return false;
    }

    function getSaveParams() {
        if (empty($_REQUEST['actions']) || !is_string($_REQUEST['actions'])) { //phpcs:ignore WordPress.Security.NonceVerification.Recommended
            return [];
        }

        $requests = json_decode(wp_unslash($_REQUEST['actions']), true); //phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        if (!is_array($requests)) {
            return [];
        }

        if (!empty($requests['save_builder']) && is_array($requests['save_builder'])) {
            return ['save_builder' => $requests['save_builder']];
        }

        foreach ($requests as $request) {
            if (is_array($request) && !empty($request['action']) && ('save_builder' == $request['action'])) {
                return ['save_builder' => $request];
            }
        }

        return [];
    }

    /** Save the editable revision without asking Elementor to publish the parent. */
    function prepareRevisionSave() {
        $editor_id = absint($_POST['editor_post_id'] ?? $_REQUEST['editor_post_id'] ?? 0); // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        if (!$editor_id || !is_string($_POST['actions'] ?? $_REQUEST['actions'] ?? null)) { return; } // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        $revision = get_post($editor_id);
        if (!$revision || !in_array(rvy_in_revision_workflow($editor_id), ['draft-revision', 'pending-revision'], true)
            || !current_user_can('edit_post', $editor_id)) { return; }
        $actions = json_decode(wp_unslash($_POST['actions'] ?? $_REQUEST['actions']), true); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Structured builder payload; native save handlers validate the decoded array.
        if (!is_array($actions)) { return; }
        $changed = false;
        foreach ($actions as $key => &$action) {
            if (!is_array($action) || empty($action['data']) || !is_array($action['data'])) { continue; }
            $kind = $action['action'] ?? $key;
            if (!in_array($kind, ['save_builder', 'save_page_settings'], true)
                || $editor_id !== absint($action['data']['id'] ?? $editor_id)) { continue; }
            if ('save_page_settings' === $kind) {
                if (!isset($action['data']['data']) || !is_array($action['data']['data'])) { continue; }
                $action['data']['data'] = $this->revisionSettings($action['data']['data'], $editor_id);
            } else {
                if ('autosave' !== ($action['data']['status'] ?? '')) {
                    $action['data']['status'] = 'pending' === $revision->post_status ? 'pending' : 'draft';
                }
                if (isset($action['data']['settings']) && is_array($action['data']['settings'])) {
                    $action['data']['settings'] = $this->revisionSettings($action['data']['settings'], $editor_id);
                }
                $this->revision_saves[$editor_id] = true;
            }
            $changed = true;
        }
        unset($action);
        if ($changed) {
            // Native Elementor nonce and document checks still run afterward.
            $_POST['actions'] = $_REQUEST['actions'] = wp_slash(wp_json_encode($actions));
        }
    }

    /** Normalize only an authorized workflow document; never grant publish_posts. */
    function revisionSettings($settings, $id) {
        $revision = get_post($id);
        if (!$revision || !in_array(rvy_in_revision_workflow($id), ['draft-revision', 'pending-revision'], true)
            || !current_user_can('edit_post', $id)) { return $settings; }
        if (isset($settings['post_status']) && 'autosave' !== $settings['post_status']) {
            $settings['post_status'] = 'pending' === $revision->post_status ? 'pending' : 'draft';
        }
        if (!array_key_exists('post_featured_image', $settings) || current_user_can('publish_posts')) { return $settings; }
        $image = $settings['post_featured_image'];
        // Empty values can be serialized as an empty string as well as an array.
        if (!is_array($image) && '' !== $image && null !== $image) { return $settings; }
        $thumbnail = is_array($image) ? absint($image['id'] ?? 0) : 0;
        if ($thumbnail !== (int) get_post_thumbnail_id($id)) { return $settings; }
        unset($settings['post_featured_image']);
        return $settings;
    }

    function normalizeRevisionDocument($data, $document) {
        $id = (int) $document->get_main_id();
        if (isset($data['settings']) && is_array($data['settings'])) {
            $data['settings'] = $this->revisionSettings($data['settings'], $id);
        }
        return $data;
    }

    /** Transition only after Elementor has persisted the layout and settings. */
    function finishRevisionSave($document, $data) {
        $id = (int) $document->get_main_id();
        if (empty($this->revision_saves[$id])) { return; }
        unset($this->revision_saves[$id]);
        $this->revision_id = $id;
        $this->actMirrorElementorDataToPostContent($document, $data);
        delete_metadata('post', $id, '_elementor_element_cache');
        $operation = sanitize_key(wp_unslash($_POST['_rvy_elementor_operation'] ?? $_REQUEST['_rvy_elementor_operation'] ?? '')); // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        if (!$operation) {
            if ('pending-revision' === rvy_in_revision_workflow($id)) { $this->actUpdatePendingRevision($document, $data); }
            return;
        }
        require_once dirname(REVISIONARY_FILE) . '/admin/revision-action_rvy.php';
        if ('submit' === $operation && 'draft-revision' === rvy_in_revision_workflow($id)
            && (is_content_administrator_rvy() || current_user_can('set_revision_pending-revision', $id))) {
            $result = rvy_revision_submit($id);
        } elseif ('approve' === $operation && current_user_can('approve_revision', $id)) {
            $result = rvy_revision_approve($id);
            if (false !== $result && !is_wp_error($result)) { delete_post_meta($id, '_rvy_revision_status'); }
        } else {
            throw new \Exception(__('Your Elementor changes were saved, but you cannot perform this revision action.', 'revisionary-pro'));
        }
        if (false === $result || is_wp_error($result)) {
            throw new \Exception(__('Your Elementor changes were saved, but the revision action failed. Retry the revision action.', 'revisionary-pro'));
        }
    }

    function fltDefaultOptions($options) {
        $options['elementor_revision_ensure_css_file'] = 1;
        $options['elementor_published_ensure_css_file'] = 0;
        $options['elementor_auto_submit_templates'] = 1;
        $options['elementor_auto_submit_template_notify'] = 0;
        $options['elementor_update_template_revision_notify'] = 0;
        $options['elementor_submission_redirect'] = 1;
        $options['elementor_generate_template_css'] = 0;
        $options['elementor_full_cache_clear'] = 0;

        return $options;
    }

    function fltDefaultOptionScope($options) {
        $options['elementor_revision_ensure_css_file'] = true;
        $options['elementor_published_ensure_css_file'] = true;
        $options['elementor_auto_submit_templates'] = true;
        $options['elementor_auto_submit_template_notify'] = true;
        $options['elementor_update_template_revision_notify'] = true;
        $options['elementor_submission_redirect'] = true;
        $options['elementor_generate_template_css'] = true;
        $options['elementor_full_cache_clear'] = true;
        
        return $options;
    }

    function fltOptionCaptions($captions) {
        $captions['elementor_revision_ensure_css_file'] = __('Generate CSS file for revision if needed', 'revisionary-pro');
        $captions['elementor_published_ensure_css_file'] = __('Also generate CSS for published pages', 'revisionary-pro');
        $captions['elementor_auto_submit_templates'] = __('Auto-submit Template Revisions', 'revisionary-pro');
        $captions['elementor_auto_submit_template_notify'] = __('Send notifications for auto-submitted Template Revisions', 'revisionary-pro');
        $captions['elementor_update_template_revision_notify'] = __('Send notifications when a Template Revision is updated', 'revisionary-pro');
        $captions['elementor_submission_redirect'] = __('Redirect to preview after editing a revision', 'revisionary-pro');
        $captions['elementor_generate_template_css'] = __('Generate CSS file for revision templates', 'revisionary-pro');
        $captions['elementor_full_cache_clear'] = __('Fully clear Elementor cache at revision publication', 'revisionary-pro');

        return $captions;
    }

    function fltOptionSections($sections) {
        $sections['features']['options'][] = 'elementor_revision_ensure_css_file';
        $sections['features']['options'][] = 'elementor_generate_template_css';
        $sections['features']['options'][] = 'elementor_published_ensure_css_file';
        $sections['features']['options'][] = 'elementor_full_cache_clear';
        $sections['features']['working_copy'][] = 'elementor_auto_submit_templates';
        $sections['features']['working_copy'][] = 'elementor_auto_submit_template_notify';
        $sections['features']['working_copy'][] = 'elementor_update_template_revision_notify';
        $sections['features']['working_copy'][] = 'elementor_submission_redirect';

        return $sections;
    }

    function actRevisionOptionsUI($settings_ui) {
        echo '<h4 style="margin-top: 30px; margin-bottom:0">' . esc_html__('Elementor:', 'revisionary-pro') . '</h4>';

        $ensure_css = rvy_get_option('elementor_revision_ensure_css_file');

		$settings_ui->option_checkbox('elementor_revision_ensure_css_file', 'features', 'options', '', '');

        if ($ensure_css) {
            $settings_ui->option_checkbox('elementor_generate_template_css', 'features', 'options', '', '');

            if ('external' !== get_option('elementor_css_print_method')) {
                $hint = esc_html__('NOTE: You will also need to enable Elementor > Settings > Advanced > CSS Print Method > External.', 'revisionary-pro');
            } else {
                $hint = esc_html__('Disable this setting if there is any problem with front end styling.', 'revisionary-pro');
            }

            $settings_ui->option_checkbox('elementor_published_ensure_css_file', 'features', 'options', $hint, '');
        }

        $hint = esc_html__('Leave this disabled for better performance if possible.', 'revisionary-pro');
        $settings_ui->option_checkbox('elementor_full_cache_clear', 'features', 'options', $hint, '');
    }

    function actAutoSubmitSettingUI($settings_ui, $tab, $section) {
        echo '<h4 style="margin-top: 30px; margin-bottom:0">' . esc_html__('Elementor:', 'revisionary-pro') . '</h4>';
        $hint = '';
        $settings_ui->option_checkbox('elementor_auto_submit_templates', $tab, $section, $hint, '');

        $hint = '';
        $settings_ui->option_checkbox('elementor_auto_submit_template_notify', $tab, $section, $hint, '');
        
        $hint = '';
		$settings_ui->option_checkbox('elementor_update_template_revision_notify', $tab, $section, $hint, '');

        $hint = __('Redirect to the revision preview after submission or a revision status change in Elementor. Disable this option to remain in the editor.', 'revisionary-pro');
        $settings_ui->option_checkbox('elementor_submission_redirect', $tab, $section, $hint, '');
    }

    function fltRankMathModules($option_val) {
        // Rank Math SEO's Link Counter module interferes with revision submission in Elementor
        if (!empty($_REQUEST['action']) && ('elementor_ajax' == $_REQUEST['action'])                    //phpcs:ignore WordPress.Security.NonceVerification.Recommended            
        && (!empty($_REQUEST['editor_post_id'])                                                         //phpcs:ignore WordPress.Security.NonceVerification.Recommended
        && rvy_in_revision_workflow((int) $_REQUEST['editor_post_id']))                                 //phpcs:ignore WordPress.Security.NonceVerification.Recommended
        ) {
            $option_val = array_diff((array) $option_val, ['link-counter']);
        }

        return $option_val;
    }

    function act_template_redirect() {
        global $post;

        if ( is_admin() ) {
            return;
        }

        if (defined('FL_BUILDER_VERSION') && isset($_REQUEST['fl_builder'])) {                          //phpcs:ignore WordPress.Security.NonceVerification.Recommended
            return;
        }

        if (!class_exists('Elementor\Core\Files\CSS\Post') || !rvy_get_option('elementor_revision_ensure_css_file')) {
            return;
        }

        if (!empty($_REQUEST['page_id'])) {                                                             //phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $post_id = (int) $_REQUEST['page_id'];                                                      //phpcs:ignore WordPress.Security.NonceVerification.Recommended
        } elseif (!empty($_REQUEST['p'])) {                                                             //phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $post_id = (int) $_REQUEST['p'];                                                            //phpcs:ignore WordPress.Security.NonceVerification.Recommended
        } else {
            if (!empty($post)) {
                $post_id = $post->ID;
            } else {
                $post_id = 0;
            }
        }

        if (!$post_id) {
            $post_id = rvy_detect_post_id();
        }

        if (!$post_id) {
            return;
        }

        if (rvy_in_revision_workflow($post_id)) {
            $source_post_id = rvy_post_id($post_id);

        } elseif ('revision' == get_post_field('post_type', $post_id)) {
            $source_post_id = get_post_field('post_parent', $post_id);

        } elseif (
		!defined('REVISIONARY_EXTERNAL_CSS_REVISION_ONLY')
		&& (rvy_get_option('elementor_generate_template_css') || ('elementor_library' != get_post_field('post_type', $post_id)))
		) {
            $source_post_id = $post_id;
        } else {
            return;
        }

        try {
            $uploads = wp_upload_dir();

            $uploads_path = (!empty($uploads['basedir'])) ? $uploads['basedir'] : WP_CONTENT_URL . "/uploads";

            if (!empty($uploads['basedir'])) {
                $filepath = trailingslashit($uploads_path) . "elementor/css/post-{$source_post_id}.css";
                if (!file_exists($filepath)) {
                    if (class_exists('\Elementor\Plugin') && !empty(\Elementor\Plugin::$instance)
                    && !empty(\Elementor\Plugin::$instance->documents)
                    && method_exists(\Elementor\Plugin::$instance->documents, 'get')
                    && \Elementor\Plugin::$instance->documents->get($source_post_id)
                    ) {
                        $elem_post = new \Elementor\Core\Files\CSS\Post($source_post_id);

                        if (defined('REVISIONARY_ELEMENTOR_DELETE_OBSOLETE_REVISION_CSS') || !empty($elem_post->get_content())) {
                            $elem_post->update();
                            $elem_post->enqueue();
                        }
                    }
                }

                // If CSS file exists for published post but not revision, copy contents from published post CSS, replacing post ID
                if ($source_post_id != $post_id) {
                    $revision_filepath = trailingslashit($uploads_path) . "elementor/css/post-{$post_id}.css";
                    if (!file_exists($revision_filepath) && file_exists($filepath)) {
                        $css_content = file_get_contents($filepath);                            //phpcs:ignore WordPressVIPMinimum.Performance.FetchingRemoteData.FileGetContentsUnknown

                        $revision_css_content = str_replace("elementor-{$source_post_id}", "elementor-{$post_id}", $css_content);

                        file_put_contents($revision_filepath, $revision_css_content);           //phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.file_ops_file_put_contents
                    }
                }

                $preview_arg = (defined('RVY_PREVIEW_ARG')) ? sanitize_key(constant('RVY_PREVIEW_ARG')) : 'rv_preview';
			
			    // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
			    if (defined('REVISIONARY_ELEMENTOR_ENQUEUE_KIT') && !empty($_GET[$preview_arg]) && empty($_REQUEST['preview_id']) && rvy_get_option('elementor_revision_ensure_css_file')) {
                    if ($kit = get_page_by_path('default-kit', OBJECT, 'elementor_library')) {
                        if (!empty($kit->ID) && !empty($kit->post_status) && ('publish' == $kit->post_status)) {
                            $filepath = trailingslashit($uploads_path) . "elementor/css/post-{$kit->ID}.css";
                            if (!file_exists($filepath)) {
                                if (class_exists('\Elementor\Plugin') && !empty(\Elementor\Plugin::$instance)
                                && !empty(\Elementor\Plugin::$instance->documents)
                                && method_exists(\Elementor\Plugin::$instance->documents, 'get')
                                && \Elementor\Plugin::$instance->documents->get($kit->ID)
                                ) {
                                    $elem_post = new \Elementor\Core\Files\CSS\Post($kit->ID);
            
                                    if (defined('REVISIONARY_ELEMENTOR_DELETE_OBSOLETE_REVISION_CSS') || !empty($elem_post->get_content())) {
                                        $elem_post->update();
                                        $elem_post->enqueue();
                                    }
                                }
                            }
    
                            add_action('wp_enqueue_scripts', function() use ($kit) {
                                $filepath = WP_CONTENT_URL . "/uploads/elementor/css/post-{$kit->ID}.css";
                                $elem_ver = (defined('ELEMENTOR_VERSION')) ? ELEMENTOR_VERSION : PUBLISHPRESS_REVISIONS_VERSION;
            
                                wp_enqueue_style("revisionary-elementor-kit-{$kit->ID}", $filepath, [], $elem_ver);
                            });
                        }
                    }
                }
        
                if (defined('REVISIONARY_DEBUG') && !empty($_REQUEST['css_file_check'])) {      //phpcs:ignore WordPress.Security.NonceVerification.Recommended
                    if (file_exists($filepath)) {
                        echo esc_html($filepath) . ': <br /><br />';
                        $test = file_get_contents($filepath);                                   //phpcs:ignore WordPressVIPMinimum.Performance.FetchingRemoteData.FileGetContentsUnknown
                        echo esc_html($test);
                        die('test');
                    } else {
                        echo esc_html($filepath) . ' does not exist.';
                    }
                }
            }
        } catch (Exception $ex) {
            return;
        }
    }

    private function isRevisionPreview() {
        $preview_arg = (defined('RVY_PREVIEW_ARG')) ? sanitize_key(constant('RVY_PREVIEW_ARG')) : 'rv_preview';

        if (!is_admin() 
        && (!defined('REST_REQUEST') || ! REST_REQUEST) 
        && ((
                (!empty($_GET[$preview_arg]) || !empty($_GET['preview']) || !empty($_GET['_ppp']))      //phpcs:ignore WordPress.Security.NonceVerification.Recommended
                && empty($_REQUEST['preview_id'])                                                       //phpcs:ignore WordPress.Security.NonceVerification.Recommended
            ) 
            || !empty($_GET['rvy_approval'])                                                            //phpcs:ignore WordPress.Security.NonceVerification.Recommended
            || !empty($_GET['mark_current_revision'])                                                   //phpcs:ignore WordPress.Security.NonceVerification.Recommended
            )
        ) { // preview_id indicates a regular preview via WP core, based on autosave revision
            if (!empty($_REQUEST['page_id'])) {                                                         //phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $revision_id = (int) $_REQUEST['page_id'];                                              //phpcs:ignore WordPress.Security.NonceVerification.Recommended
            } elseif (!empty($_REQUEST['p'])) {                                                         //phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $revision_id = (int) $_REQUEST['p'];                                                    //phpcs:ignore WordPress.Security.NonceVerification.Recommended
            } else {
                global $post;

                if (!empty($post)) {
                    $revision_id = $post->ID;
                } else {
                    $revision_id = 0;
                }
            }

            if ((rvy_in_revision_workflow($revision_id) || wp_is_post_revision($revision_id))
                && (rvy_can_read_post($revision_id) || current_user_can('edit_post', rvy_post_id($revision_id)))) {
                return $revision_id;
            }
        }

        return false;
    }

    function fltCSSprintMethod($option_val) {
        if ($this->isRevisionPreview()) {
            if (rvy_get_option('elementor_revision_ensure_css_file') || defined('REVISIONARY_PREVIEW_FORCE_EXTERNAL_CSS')) {
                return 'external';
            }
        }

        return $option_val;
    }

    function fltPreviewElementCacheTTL($option_val) {
        return $this->isRevisionPreview() ? 'disable' : $option_val;
    }

    function actEnqueueElementorPostCSS() { 
        if ($revision_id = $this->isRevisionPreview()) {
            if ($this->enqueueRevisionPreviewStyles($revision_id)) { return; }
            if ($parent_id = wp_is_post_revision($revision_id)) {
                // Historical wrappers use the main document ID. Generate styles
                // from the requested snapshot, not the current page CSS file.
                if (class_exists('\\Elementor\\Core\\Files\\CSS\\Post')) {
                    $css = (new \Elementor\Core\Files\CSS\Post($revision_id))->get_content();
                    $css = str_replace('elementor-' . $revision_id, 'elementor-' . $parent_id, $css);
                    wp_enqueue_style('elementor-frontend');
                    wp_register_style('revisionary-elementor-past-preview', false);
                    wp_add_inline_style('revisionary-elementor-past-preview', $css);
                    // Print after Elementor's current-document styles so they
                    // cannot override the requested historical snapshot.
                    add_action('wp_head', static function () {
                        wp_print_styles('revisionary-elementor-past-preview');
                    }, 100);
                }
                return;
            }
            $uploads = wp_upload_dir();

            $uploads_path = (!empty($uploads['baseurl'])) ? $uploads['baseurl'] : WP_CONTENT_URL . "/uploads";

            // This may be required for the file creation to be triggered
            if (!defined('REVISIONARY_ELEMENTOR_REVISION_CSS_NO_EXTRA_ENQUEUE')) {
                wp_enqueue_style('revisionary-elementor-post-css-extra', trailingslashit($uploads_path) . "elementor/css/post-{$revision_id}.css", []);
            }

            // This is required for correct CSS file loading
            wp_enqueue_style('revisionary-elementor-post-css', trailingslashit($uploads_path) . "elementor/css/post-{$revision_id}.css", [], null);
        }
    }

    /** Render snapshot CSS even when uploads are read-only or a cached file is absent. */
    private function enqueueRevisionPreviewStyles($revision_id) {
        if (!class_exists('Elementor\\Core\\Files\\CSS\\Post')) { return false; }
        try {
            $css = (new \Elementor\Core\Files\CSS\Post($revision_id))->get_content();
            $parent_id = wp_is_post_revision($revision_id);
            if ($parent_id) { $css = str_replace('elementor-' . $revision_id, 'elementor-' . $parent_id, $css); }
            if (class_exists('Elementor\\Plugin') && !empty(\Elementor\Plugin::$instance)) {
                $plugin = \Elementor\Plugin::$instance;
                if (!empty($plugin->frontend)) {
                    $plugin->frontend->enqueue_styles();
                    $plugin->frontend->enqueue_scripts();
                }
                if (!empty($plugin->kits_manager)) {
                    $kit = $plugin->kits_manager->get_active_kit();
                    if ($kit && $kit->get_id()) {
                        $css = (new \Elementor\Core\Files\CSS\Post($kit->get_id()))->get_content() . $css;
                    }
                }
            }
            if (!is_string($css) || '' === trim($css)) { return false; }
            $handle = 'revisionary-elementor-snapshot-preview';
            wp_enqueue_style('elementor-frontend');
            wp_register_style($handle, false, ['elementor-frontend']);
            wp_add_inline_style($handle, $css);
            wp_enqueue_style($handle);
            add_action('wp_head', static function () use ($handle) { wp_print_styles($handle); }, 100);
            return true;
        } catch (\Throwable $error) {
            // Retain the existing external-file fallback for older Elementor APIs.
            return false;
        }
    }

    function fltPostCSSrules($rules, $object_id, $meta_key, $single, $meta_type) {
        if (('_elementor_css' == $meta_key) && rvy_in_revision_workflow($object_id)) {
            $parent_post_id = rvy_post_id($object_id);
            
            if (!$parent_post_id || ($parent_post_id == $object_id)) {
                return $rules;
            }

            global $wpdb;

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $_rules = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT meta_value FROM $wpdb->postmeta WHERE meta_key = '_elementor_css' && post_id = %d",
                    $object_id
                )
            );

            if ($_rules) {
                if (
                defined('REVISIONARY_FILTER_LIBRARY_CSS')
                || ('elementor_library' != get_post_field('post_type', $object_id))
                || (defined('REVISIONARY_FILTER_LIBRARY_CHILD_CSS') && ('elementor_library' == get_post_field('post_type', $parent_post_id)))
                ) {
                    $rules = str_replace("elementor-$parent_post_id", "elementor-$object_id", $_rules);
                }
            }
        }

        return $rules;
    }
    
    function wpseoCompatWorkaround() {
        global $wp_filter;

        if (!empty($_REQUEST['editor_post_id']) && !empty($_REQUEST['action']) && ('elementor_ajax' == $_REQUEST['action'])     //phpcs:ignore WordPress.Security.NonceVerification.Recommended
        ) {
            // Ordinary Elementor saves must still refresh Yoast's published-post indexable.
            $post_id = (int) $_REQUEST['editor_post_id']; //phpcs:ignore WordPress.Security.NonceVerification.Recommended
            if (!rvy_in_revision_workflow($post_id)) {
                return;
            }

            foreach(['wp_insert_post', 'delete_post'] as $action) {
                if (empty($wp_filter[$action]->callbacks)) {
                    continue;
                }

                foreach(array_keys($wp_filter[$action]->callbacks) as $priority) {
                    foreach(array_keys($wp_filter[$action]->callbacks[$priority]) as $wpseo_filter_key) {
                        if (false !== strpos($wpseo_filter_key, 'build_indexable')) {
                            unset($wp_filter[$action]->callbacks[$priority][$wpseo_filter_key]);
                        }
                    }
                }
            }
        }
    }


    function fltCreateRevisionRedirect($url, $post_id) {
        if (!empty($_REQUEST['front']) && !defined('PP_REVISIONS_ELEMENTOR_NO_REDIRECT')) {         //phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $post_type = get_post_field('post_type', $post_id);
            
            if (!$this->isElementorPostType($post_type)) {
                return $url;
            }

            if (apply_filters(
                'revisionary_elementor_create_revision_redirect',
                !defined('LEARNDASH_VERSION') || !in_array($post_type, ['sfwd-courses', 'sfwd-lessons', 'sfwd-topic', 'sfwd-quiz', 'sfwd-question', 'sfwd-certificates', 'sfwd-assignment', 'ld-exam', 'ld-achievement', 'ld-notification']),
                $post_id
            )) {
            	$url = admin_url("post.php?post=$post_id&action=elementor");
            }
        }

        return $url;
    }

    function elementorDetectID($id, $args) {
        $args = (array) $args;

        if (!empty($args['is_ajax']) 
        && !empty($_REQUEST['action'])                                                              //phpcs:ignore WordPress.Security.NonceVerification.Recommended
        && ('elementor_ajax' == $_REQUEST['action'])                                                //phpcs:ignore WordPress.Security.NonceVerification.Recommended
        && !empty($_REQUEST['editor_post_id']) && did_action('elementor/db/before_save')            //phpcs:ignore WordPress.Security.NonceVerification.Recommended
        ) {
            if (!empty($_REQUEST['actions'])) {                                                     //phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $requests = json_decode( 
                    stripslashes(sanitize_text_field($_REQUEST['actions']))                         //phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.MissingUnslash
                    , true 
                );

                if (!empty($requests['save_builder'])) {                                            
                    $id = (int) $_REQUEST['editor_post_id'];                                        //phpcs:ignore WordPress.Security.NonceVerification.Recommended
                }
            }
        }

        return $id;
    }

    function fltPanelConfig($config) {
        $post_id = rvy_detect_post_id();
        
        if (!$revision_status = rvy_in_revision_workflow($post_id)) {
            if (!empty($_REQUEST['initial_document_id'])) {                                         //phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $post_id = (int) $_REQUEST['initial_document_id'];                                 	//phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $revision_status = rvy_in_revision_workflow($post_id);
            }
        }

        if ($revision_status = rvy_in_revision_workflow($post_id)) {
            // A native Elementor save updates content; workflow actions have
            // their own explicit Submit / Approve controls.
            $config['panel']['messages']['publish_notification'] = esc_html__('Revision updated.', 'revisionary-pro');

            // @todo: generic revisions top bar ?
            $config['urls']['preview'] = add_query_arg('rvy_embed', 1, add_query_arg('elementor-preview', $post_id, rvy_preview_url($post_id)));

            $config['urls']['wp_preview'] = rvy_preview_url($post_id);
            $config['urls']['permalink'] = rvy_preview_url($post_id);
            $config['urls']['have_a_look'] = rvy_preview_url($post_id);
        }

        return $config;
    }

    function fltWPpreview($url) {
        if ($post_id = rvy_detect_post_id()) {
            if (rvy_in_revision_workflow($post_id)) {
                $url = rvy_preview_url($post_id);
            }
        }

        return $url;
    }

    function fltRevisionQueueRowActions($actions, $post) {
        if ($this->isElementorPostType($post->post_type)) {
            $actions['elementor'] = sprintf(
                    '<a href="%1$s" class="" title="%2$s" aria-label="%2$s">%3$s</a>',
                    rvy_admin_url("post.php?post=$post->ID&action=elementor"),
                    esc_html__('Elementor', 'revisionary-pro'),
                    esc_html__('Elementor', 'revisionary-pro')
            );
        }

        return $actions;
    }

    /** Load workflow controls in Elementor's editor shell, after its own scripts. */
    function enqueueWorkflowEditorScript() {
        if (!$post_id = rvy_detect_post_id()) {
            return;
        }

        $post = get_post($post_id);
        if (!$post || !rvy_in_revision_workflow($post)) {
            return;
        }

        $can_approve = in_array($post->post_mime_type, ['draft-revision', 'pending-revision'], true)
            && current_user_can('approve_revision', $post_id);
        $can_submit = 'draft-revision' === $post->post_mime_type
            && (is_content_administrator_rvy() || current_user_can('set_revision_pending-revision', $post_id));
        $buttons = [];
        if ($can_submit) {
            $buttons[] = ['operation' => 'submit', 'label' => __('Submit Revision', 'revisionary-pro')];
        }
        if ($can_approve) {
            $buttons[] = ['operation' => 'approve', 'label' => __('Approve Revision', 'revisionary-pro')];
        }

        $handle = 'rvy-elementor-revision-workflow';
        wp_enqueue_script(
            $handle,
            plugins_url('includes-pro/compat/elementor-workflow.js', REVISIONARY_PRO_FILE),
            ['jquery', 'wp-i18n', RevisionaryBuilderWorkflow::noticeScript()],
            PUBLISHPRESS_REVISIONS_PRO_VERSION,
            true
        );
        wp_set_script_translations($handle, 'revisionary-pro', REVISIONARY_PRO_ABSPATH . '/languages');
        wp_add_inline_script(
            $handle,
            'window.RevisionaryElementorWorkflow = ' . wp_json_encode([
                'id' => $post_id,
                'buttons' => $buttons,
                'updateLabel' => __('Update', 'revisionary-pro'),
                'nativeSaveLabels' => array_values(array_unique([__('Publish', 'elementor'), __('Submit', 'elementor'), __('Publish'), __('Submit'), __('Update', 'elementor'), __('Publish Changes', 'elementor')])),
                'transitionUrl' => admin_url('admin-ajax.php'),
                'transitionNonce' => wp_create_nonce('rvy-elementor-transition:' . $post_id),
            ]) . ';',
            'before'
        );
    }

    /** Run a workflow action when Elementor has no unsaved changes to save. */
    function ajaxWorkflowTransition() {
        $revision_id = absint($_POST['revision_id'] ?? 0);
        $nonce = sanitize_text_field(wp_unslash($_POST['nonce'] ?? ''));
        if (!$revision_id || !wp_verify_nonce($nonce, 'rvy-elementor-transition:' . $revision_id)) {
            wp_send_json_error(['message' => __('Invalid revision editing session.', 'revisionary-pro')], 403);
        }

        $revision = get_post($revision_id);
        if (!$revision || !rvy_in_revision_workflow($revision_id)
            || !in_array($revision->post_mime_type, ['draft-revision', 'pending-revision'], true)
            || !current_user_can('edit_post', $revision_id)) {
            wp_send_json_error(['message' => __('You cannot edit this revision.', 'revisionary-pro')], 403);
        }

        $operation = sanitize_key(wp_unslash($_POST['operation'] ?? ''));
        require_once dirname(REVISIONARY_FILE) . '/admin/revision-action_rvy.php';
        if ('submit' === $operation && 'draft-revision' === $revision->post_mime_type
            && (is_content_administrator_rvy() || current_user_can('set_revision_pending-revision', $revision_id))) {
            $result = rvy_revision_submit($revision_id);
        } elseif ('approve' === $operation && current_user_can('approve_revision', $revision_id)) {
            // Approval may convert the revision to a Past Revision. Resolve
            // its published parent while the workflow relationship is intact.
            $approval_url = add_query_arg('rvy_approval', 1, get_permalink(rvy_post_id($revision_id)));
            $result = rvy_revision_approve($revision_id);
        } else {
            wp_send_json_error(['message' => __('You cannot perform this action.', 'revisionary-pro')], 403);
        }

        if (false === $result || is_wp_error($result)) {
            wp_send_json_error(['message' => __('The revision action failed.', 'revisionary-pro')], 400);
        }

        wp_send_json_success(['url' => 'approve' === $operation ? $approval_url : rvy_preview_url($revision_id)]);
    }

    // @todo: migrate to .js file with localize_script()
    function frontScripts() {
        if ($post_id = rvy_detect_post_id()) {
            if ($revision_status = rvy_in_revision_workflow($post_id)) {
                $post = get_post($post_id);
                $can_approve = $post && in_array($post->post_mime_type, ['draft-revision', 'pending-revision'], true)
                    && current_user_can('approve_revision', $post_id);
                $can_publish = $can_approve;
                ?>

                <script type="text/javascript">
                /* <![CDATA[ */
                window.__rvyElementorWorkflowIntent = '';

                <?php /* Redirect to Revisions preview screen after revision status change */
                
                if (get_option('rvy_elementor_submission_redirect', true)):
                    $redirect_delay_msec = (defined('REVISIONARY_ELEMENTOR_REDIRECT_DELAY_MSEC')) ? REVISIONARY_ELEMENTOR_REDIRECT_DELAY_MSEC : 15000;
                    if ('draft-revision' == $revision_status) {
                        $redirect_toast_caption = pp_revisions_status_label('pending-revision', 'submitted');
                    } elseif ($can_publish && ('future-revision' != $revision_status)) {
                        $redirect_toast_caption = __('Approval done.', 'revisionary-pro');
                    } else {
                        $redirect_toast_caption = __('Revision updated.', 'revisionary-pro');
                    }
                ?>

                var rvyRedirectMonitoring = false;
                var rvyRedirectToastCaption = <?php echo wp_json_encode($redirect_toast_caption);?>;
                var rvyRedirectScheduled = false;
                var rvyRedirectSaveStatus = null;
                var rvyRedirectOperation = null;
                var rvyRedirectElementor;
                var rvyRedirectSaver;
                var rvyRedirectChannel;
                var rvyElementorReadySelector = '#elementor-editor-wrapper-v2, #elementor-panel, #elementor-preview, #elementor-panel-footer-settings, #elementor-panel-saver-button-publish';
                var rvyRedirectLoadObserver;
                var rvyRedirectStatusObserver;

                var rvyRedirectAfterStatusChange = function() {
                    if (window.__rvyElementorWorkflowControls || !rvyRedirectOperation || rvyRedirectScheduled || window.__rvyElementorWorkflowSaveFailed) {
                        return;
                    }
                    rvyRedirectScheduled = true;
                    if (rvyRedirectLoadObserver) {
                        rvyRedirectLoadObserver.disconnect();
                    }
                    if (rvyRedirectStatusObserver) {
                        rvyRedirectStatusObserver.disconnect();
                    }
                    var redirectUrl = rvyRedirectOperation === 'approve'
                        ? <?php echo wp_json_encode(add_query_arg('rvy_approval', 1, get_permalink(rvy_post_id($post_id))));?>
                        : <?php echo wp_json_encode(add_query_arg('base_post', rvy_post_id($post_id), rvy_preview_url($post_id)));?>;
                    setTimeout(function() {
                        window.location = redirectUrl;
                    }, 500);
                };

                var rvyRedirectOnSaveSuccess = function() {
                    // The generic saved/after:save events also fire for autosaves.
                    if (['publish', 'pending', 'future', 'pending-revision', 'future-revision'].indexOf(rvyRedirectSaveStatus) !== -1) {
                        rvyRedirectAfterStatusChange();
                    }
                };

                var rvyBindRedirectEvents = function() {
                    var editor = window.elementor;
                    if (!editor) {
                        return;
                    }
                    if (rvyRedirectElementor !== editor && typeof editor.on === 'function') {
                        rvyRedirectElementor = editor;
                        editor.on('preview:loaded', function() { rvyStartRedirectMonitoring(true); });
                    }
                    if (editor.saver && rvyRedirectSaver !== editor.saver && typeof editor.saver.on === 'function') {
                        rvyRedirectSaver = editor.saver;
                        editor.saver.on('before:save', function(args) {
                            // The explicit workflow owns save -> transition -> redirect.
                            if (window.__rvyElementorWorkflowControls) {
                                rvyRedirectOperation = null; rvyRedirectSaveStatus = null;
                                return;
                            }
                            // Do not redirect for a secondary document (such as a site kit).
                            var saveDocument = args && args.document;
                            var operation = window.__rvyElementorWorkflowIntent;
                            rvyRedirectOperation = saveDocument && Number(saveDocument.id) !== <?php echo (int) $post_id;?>
                                || (args && args.status === 'autosave')
                                || ['submit', 'approve'].indexOf(operation) === -1 ? null : operation;
                            rvyRedirectSaveStatus = rvyRedirectOperation ? (args && args.status) || 'publish' : null;
                        });
                        editor.saver.on('after:save', rvyRedirectOnSaveSuccess);
                        editor.saver.on('after:save', function() { window.setTimeout(function() { window.__rvyElementorWorkflowIntent = ''; }, 0); });
                        editor.saver.on('after:saveError', function() { rvyRedirectSaveStatus = null; rvyRedirectOperation = null; window.__rvyElementorWorkflowIntent = ''; });
                        editor.saver.on('page:status:change', function(status, oldStatus) {
                            if (status !== oldStatus && status !== 'autosave' && rvyRedirectSaveStatus !== null) {
                                rvyRedirectAfterStatusChange();
                            }
                        });
                    }
                    var channel = editor.channels && editor.channels.editor;
                    if (channel && rvyRedirectChannel !== channel && typeof channel.on === 'function') {
                        rvyRedirectChannel = channel;
                        channel.on('saved', rvyRedirectOnSaveSuccess);
                    }
                };

                if (window.jQuery && !window.__rvyElementorWorkflowAjaxHook) {
                    window.__rvyElementorWorkflowAjaxHook = true;
                    window.jQuery.ajaxPrefilter(function(options) {
                        var operation = window.__rvyElementorWorkflowIntent;
                        if (window.__rvyElementorWorkflowControls || !operation || String(options.url || '').indexOf('admin-ajax.php') === -1) return;
                        var data = options.data;
                        var actionData = data && (typeof data === 'string' ? decodeURIComponent(data.replace(/\+/g, ' ')) : data.actions || '');
                        if (String(actionData).indexOf('save_builder') === -1) return;
                        // Older savers use this AJAX path instead of before:save.
                        if (!rvyRedirectSaver) {
                            rvyRedirectOperation = ['submit', 'approve'].indexOf(operation) !== -1 ? operation : null;
                        }
                        if (typeof data === 'string') options.data += '&_rvy_elementor_operation=' + encodeURIComponent(operation);
                        else if (data && typeof data.append === 'function') data.append('_rvy_elementor_operation', operation);
                        else if (data && typeof data === 'object') data._rvy_elementor_operation = operation;
                    });
                }

                var rvyStartRedirectMonitoring = function(previewLoaded) {
                    rvyBindRedirectEvents();
                    if (!rvyRedirectMonitoring && (previewLoaded === true || document.querySelector(rvyElementorReadySelector))) {
                        rvyRedirectMonitoring = true;
                        // The delay applies only to the legacy toast fallback, not explicit saves.
                        setTimeout(function() {
                            if (rvyRedirectScheduled) {
                                return;
                            }
                            var rvyCheckRedirectToast = function() {
                                var toast = document.getElementById('elementor-toast');
                                if (!toast || toast.hidden) {
                                    return;
                                }
                                var style = window.getComputedStyle(toast);
                                if (style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0'
                                    && toast.textContent.indexOf(rvyRedirectToastCaption) !== -1) {
                                    rvyRedirectAfterStatusChange();
                                }
                            };
                            rvyRedirectStatusObserver = new MutationObserver(rvyCheckRedirectToast);
                            rvyRedirectStatusObserver.observe(document.documentElement, {
                                childList: true,
                                subtree: true,
                                characterData: true,
                                attributes: true,
                                attributeFilter: ['class', 'style', 'hidden', 'aria-hidden']
                            });
                            rvyCheckRedirectToast();
                        }, <?php echo esc_attr($redirect_delay_msec);?>);
                    }
                    if (rvyRedirectMonitoring && rvyRedirectSaver && rvyRedirectLoadObserver) {
                        rvyRedirectLoadObserver.disconnect();
                    }
                };

                // These native events are emitted by Elementor 4.3 alongside its event bus.
                window.addEventListener('elementor:loaded', rvyStartRedirectMonitoring);
                window.addEventListener('elementor:init', rvyStartRedirectMonitoring);
                rvyRedirectLoadObserver = new MutationObserver(rvyStartRedirectMonitoring);
                rvyRedirectLoadObserver.observe(document.documentElement, { childList: true, subtree: true });
                rvyStartRedirectMonitoring();

                <?php endif;?>

                /* ]]> */
                </script>
                <?php

                // Elementor disables the iframe links, so hide them
                if (!empty($_REQUEST['rvy_embed'])):                                               //phpcs:ignore WordPress.Security.NonceVerification.Recommended 
                ?>
                    <style>
                    div.rvy_view_revision a.rvy_preview_linkspan, #pp_revisions_top_bar div.rvy_preview_msgspan a, #pp_revisions_top_bar div.rvy_preview_msgspan span.rvy-preview-link {display: none;}
                    </style>
                <?php endif;
            }
        }
    }

    function elementorMonitorQueries() {
        add_filter('query', [$this, 'actAdjustElementorUpdateQuery']);
    }

    /**
     * Replace a single target ID in an Elementor-generated UPDATE query.
     * Return false when the expected WHERE target is absent so a caller can
     * fail closed instead of accidentally saving to the published post.
     */
    private function replaceUpdateTargetId($query, $column, $old_id, $new_id) {
        $old_id = (int) $old_id;
        $new_id = (int) $new_id;

        if (!$old_id || !$new_id) {
            return false;
        }

        $pattern = '/(\bWHERE\s+`?' . preg_quote($column, '/') . '`?\s*=\s*)' . $old_id . '(?![0-9])/i';
        $replacements = 0;
        $updated_query = preg_replace($pattern, '${1}' . $new_id, $query, 1, $replacements);

        if (1 !== $replacements || !is_string($updated_query)) {
            return false;
        }

        return $updated_query;
    }

    private function safeNoopPostsUpdateQuery() {
        global $wpdb;

        return "UPDATE `{$wpdb->posts}` SET ID = ID WHERE 1 = 0";
    }

    function actAdjustElementorUpdateQuery($qry) {
        global $revisionary, $wpdb, $current_user;

        if ($this->save_in_progress && !empty($_REQUEST['action']) && ('elementor_ajax' == $_REQUEST['action'])) { //phpcs:ignore WordPress.Security.NonceVerification.Recommended
			if (0 === strpos($qry, 'UPDATE')) {
                
                //phpcs:ignore Squiz.PHP.CommentedOutCode.Found
                /*
                // WHERE `ID` = 32507
                */

                $matches = [];

                if (preg_match('/\bWHERE\s+`?ID`?\s*=\s*([0-9]+)/i', $qry, $matches)) {
                    if ($matches[1]) {
						if (rvy_in_revision_workflow($matches[1])) {
							$revision = get_post($matches[1]);
						} else {
							$revisionary->skip_filtering = true;
							
                            if (current_user_can('edit_post', $matches[1])

                            //phpcs:ignore Squiz.PHP.CommentedOutCode.Found
                            /* Previous conditional
                            //&& (empty($_REQUEST['post']) || !rvy_in_revision_workflow($_REQUEST['post']))
                            */

                            && (empty($_REQUEST['initial_document_id']) || empty($_REQUEST['editor_post_id'])           //phpcs:ignore WordPress.Security.NonceVerification.Recommended
                            || ($_REQUEST['initial_document_id'] == $matches[1])                                        //phpcs:ignore WordPress.Security.NonceVerification.Recommended
                            || !rvy_in_revision_workflow((int) $_REQUEST['initial_document_id'])                        //phpcs:ignore WordPress.Security.NonceVerification.Recommended
                            || ('elementor_library' != get_post_field('post_type', $matches[1]))
                            )
                            ) {
                                return $qry;
                            }
							
                            if (!empty($_REQUEST['initial_document_id'])) {                                             //phpcs:ignore WordPress.Security.NonceVerification.Recommended
                                $post_status = get_post_field('post_status', (int) $_REQUEST['initial_document_id']);   //phpcs:ignore WordPress.Security.NonceVerification.Recommended

                                if (in_array($post_status, ['draft', 'auto-draft'])
                                && !rvy_in_revision_workflow((int) $_REQUEST['initial_document_id'])                    //phpcs:ignore WordPress.Security.NonceVerification.Recommended
                                ) {
                                    return $qry;
                                }
                            }

							$revisionary->skip_filtering = false;

                            $revision = $this->get_last_user_revision($matches[1]);
						}
						
						if ($revision) {
                            $revision_id = $revision->ID;
                            $this->revision_id = $revision->ID;
							
							$updated_query = $this->replaceUpdateTargetId($qry, 'ID', $matches[1], $revision->ID);
							if (false === $updated_query) {
								return $this->safeNoopPostsUpdateQuery();
							}
							$qry = $updated_query;
							
							$qry = str_replace(", `post_mime_type` = ''", '', $qry);
							$qry = str_replace(", `post_status` = 'publish'", '', $qry);
										
                            $save_params = $this->getSaveParams();

                            if (
                                !empty($save_params) && !empty($save_params['save_builder']) && !empty($save_params['save_builder']['data']) 
                                && !empty($save_params['save_builder']['data']['status']) && ('publish' == $save_params['save_builder']['data']['status'])
                            ) {
                                $operation = sanitize_key(wp_unslash($_REQUEST['_rvy_elementor_operation'] ?? '')); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
                                $can_approve = in_array($revision->post_mime_type, ['draft-revision', 'pending-revision'], true)
                                    && current_user_can('approve_revision', $revision->ID);
                                $can_submit = 'draft-revision' === $revision->post_mime_type
                                    && (is_content_administrator_rvy() || current_user_can('set_revision_pending-revision', $revision->ID));
                                $template_workflow_enabled = ('elementor_library' != $revision->post_type) || rvy_get_option('elementor_auto_submit_templates');

                                if ('submit' === $operation && $can_submit && $template_workflow_enabled) {
                                        $update_prefix = '/^(UPDATE\\s+`?' . preg_quote($wpdb->posts, '/') . '`?\\s+SET\\s+)/i';
                                        $replacements = 0;
                                        $updated_query = preg_replace(
                                            $update_prefix,
                                            '${1}`post_status` = \'pending\', `post_mime_type` = \'pending-revision\', ',
                                            $qry,
                                            1,
                                            $replacements
                                        );

                                        if (1 !== $replacements || !is_string($updated_query)) {
                                            return $this->safeNoopPostsUpdateQuery();
                                        }

                                        $qry = $updated_query;
                                        update_post_meta($revision->ID, '_rvy_revision_status', 'pending-revision');
                                        $this->revision_id = $revision->ID;
                                        add_action('elementor/document/after_save', [$this, 'actSubmitPendingRevision'], 10, 2);
                                } elseif ('approve' === $operation && $can_approve && $template_workflow_enabled) {
                                    if ('draft-revision' === $revision->post_mime_type) {
                                        $update_prefix = '/^(UPDATE\\s+`?' . preg_quote($wpdb->posts, '/') . '`?\\s+SET\\s+)/i';
                                        $replacements = 0;
                                        $updated_query = preg_replace(
                                            $update_prefix,
                                            '${1}`post_status` = \'pending\', `post_mime_type` = \'pending-revision\', ',
                                            $qry,
                                            1,
                                            $replacements
                                        );
                                        if (1 !== $replacements || !is_string($updated_query)) {
                                            return $this->safeNoopPostsUpdateQuery();
                                        }
                                        $qry = $updated_query;
                                        update_post_meta($revision->ID, '_rvy_revision_status', 'pending-revision');
                                    }
                                    $this->revision_id = $revision->ID;
                                    add_action('elementor/document/after_save', [$this, 'actApprovePendingRevision'], 10, 2);
                                } elseif ('pending-revision' === $revision->post_mime_type && !$operation && $template_workflow_enabled) {
                                    $this->revision_id = $revision->ID;
                                    add_action('elementor/document/after_save', [$this, 'actUpdatePendingRevision'], 10, 2);
                                }

                                $this->revision_id = $revision->ID;
                                add_action('elementor/document/after_save', [$this, 'actMirrorElementorDataToPostContent'], 5, 2);
                            }
                        }
                    }
                }
				
                //phpcs:ignore Squiz.PHP.CommentedOutCode.Found
                /*
                // WHERE `post_id` = 32507 AND `meta_key` = '_elementor_data'
                */

                $matches = [];
                if (preg_match("/\bWHERE\s+`?post_id`?\s*=\s*([0-9]+)\s+AND\s+`?meta_key`?\s*=\s*'_elementor_data'/i", $qry, $matches)) {
				if ($matches[1]) {
                    $revisionary->skip_filtering = true;
					
					if (!rvy_in_revision_workflow($matches[1]) 

                    //phpcs:ignore Squiz.PHP.CommentedOutCode.Found
                    /* previous conditional
					//&& ('elementor_library' != get_post_field('post_type', $matches[1])) 
                    */
                    
                    && current_user_can('edit_post', $matches[1])
                    && (empty($_REQUEST['initial_document_id']) || empty($_REQUEST['editor_post_id'])           //phpcs:ignore WordPress.Security.NonceVerification.Recommended
	                || ($_REQUEST['initial_document_id'] == $matches[1])                                        //phpcs:ignore WordPress.Security.NonceVerification.Recommended
	                || !rvy_in_revision_workflow((int) $_REQUEST['initial_document_id'])                        //phpcs:ignore WordPress.Security.NonceVerification.Recommended
	                || ('elementor_library' != get_post_field('post_type', $matches[1]))
	                )
                    ) {
                        $revisionary->skip_filtering = false;
						
						return $qry;
                    }
					
					$revisionary->skip_filtering = false;

                    if (!empty($_REQUEST['initial_document_id'])) {                                             //phpcs:ignore WordPress.Security.NonceVerification.Recommended
                        $post_status = get_post_field('post_status', (int) $_REQUEST['initial_document_id']);   //phpcs:ignore WordPress.Security.NonceVerification.Recommended

                        if (in_array($post_status, ['draft', 'auto-draft'])
                        && !rvy_in_revision_workflow((int) $_REQUEST['initial_document_id'])                    //phpcs:ignore WordPress.Security.NonceVerification.Recommended
                        ) {
                            return $qry;
                        }
                    }

                    if ($revision = $this->get_last_user_revision($matches[1])) {
							$updated_query = $this->replaceUpdateTargetId($qry, 'post_id', $matches[1], $revision->ID);
							if (false === $updated_query) {
								return $this->safeNoopPostsUpdateQuery();
							}
							$qry = $updated_query;

                            $revision_id = $revision->ID;
							$this->revision_id = $revision->ID;
                        }
                    }
                }
			}
        } 

        if (0 === strpos($qry, 'UPDATE ') && strpos($qry, "`post_status` = '")) {
            $save_params = $this->getSaveParams();
            $save_status = $save_params['save_builder']['data']['status'] ?? '';

                                if (in_array($save_status, ['publish', 'future'], true)) {
                    if (empty($revision_id)) {
                        $post_id = (isset($_REQUEST['editor_post_id'])) ? (int) $_REQUEST['editor_post_id'] : 0;    //phpcs:ignore WordPress.Security.NonceVerification.Recommended
                    } else {
                        $post_id = $revision_id;
                    }
					
					$this->revision_id = $post_id;

                    if ($revision_status = rvy_in_revision_workflow($post_id)) {
                        $operation = sanitize_key(wp_unslash($_REQUEST['_rvy_elementor_operation'] ?? '')); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
                        $can_approve = in_array($revision_status, ['draft-revision', 'pending-revision'], true)
                            && current_user_can('approve_revision', $post_id);
                        $can_submit = 'draft-revision' === $revision_status
                            && (is_content_administrator_rvy() || current_user_can('set_revision_pending-revision', $post_id));

                        // The native Publish button is an Update in revision editing.
                        // Only explicit extension buttons carry a workflow operation.
                        if ('submit' === $operation && $can_submit) {
                            $qry = str_replace("`post_mime_type` = 'draft-revision'", "`post_mime_type` = 'pending-revision'", $qry);
                            $qry = str_replace("`post_status` = 'draft'", "`post_mime_type` = 'pending-revision'", $qry);
                            $qry = str_replace("`post_status` = 'publish'", "`post_mime_type` = 'pending-revision'", $qry);
                            $qry = str_replace("`post_author` = 1'", "`post_author` = " . intval($current_user->ID), $qry);
                            update_post_meta($post_id, '_rvy_revision_status', 'pending-revision');
                            $this->revision_id = $post_id;
                            add_action('elementor/document/after_save', [$this, 'actSubmitPendingRevision'], 10, 2);
                            clean_post_cache($this->revision_id);
                        } elseif ('approve' === $operation && $can_approve) {
                            if ('draft-revision' === $revision_status) {
                                $qry = str_replace("`post_mime_type` = 'draft-revision'", "`post_mime_type` = 'pending-revision'", $qry);
                                $qry = str_replace("`post_status` = 'draft'", "`post_mime_type` = 'pending-revision'", $qry);
                                $qry = str_replace("`post_status` = 'publish'", "`post_mime_type` = 'pending-revision'", $qry);
                                update_post_meta($post_id, '_rvy_revision_status', 'pending-revision');
                                clean_post_cache($post_id);
                            } else {
                                $qry = str_replace("`post_status` = 'publish'", "`post_mime_type` = 'pending-revision'", $qry);
                            }
                            $qry = str_replace("`post_author` = 1'", "`post_author` = " . intval($current_user->ID), $qry);
                            $this->revision_id = $post_id;
                            add_action('elementor/document/after_save', [$this, 'actApprovePendingRevision'], 10, 2);
                        } elseif ('pending-revision' === $revision_status && !$operation) {
                            // Preserve the existing update notification behavior without approving.
                            $this->revision_id = $post_id;
                            add_action('elementor/document/after_save', [$this, 'actUpdatePendingRevision'], 10, 2);
                        }

                        if (in_array($revision_status, ['draft-revision', 'pending-revision', 'future-revision'], true)) {
                            $this->revision_id = $post_id;
                            add_action('elementor/document/after_save', [$this, 'actMirrorElementorDataToPostContent'], 5, 2);
                        }
                    }
            }
        } 

        return $qry;
    }

	function actMirrorElementorDataToPostContent($elem_doc, $data) {
		global $wpdb;

		if (class_exists('\Elementor\Plugin') && rvy_in_revision_workflow($this->revision_id)) {
			if ($elem = \Elementor\Plugin::instance()) {
				if ($post_content = $elem->db->get_plain_text($this->revision_id)) {
					$wpdb->update(                                                      // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                        $wpdb->posts, 
                        ['post_content' => $post_content], 
                        ['ID' => $this->revision_id]
                    );
				}
			}
		}
	}
	
    function actApprovePendingRevision($elem_doc, $data) {
		global $revisionary;
		
		$revisionary->skip_filtering = true;
		
        if (current_user_can('approve_revision', $this->revision_id)) {
            require_once(dirname(REVISIONARY_FILE) . '/admin/revision-action_rvy.php');	
            rvy_revision_approve($this->revision_id, ['force_notify' => true]);
			delete_post_meta($this->revision_id, '_rvy_revision_status');
        }
		
		$revisionary->skip_filtering = false;

        delete_metadata('post', $this->revision_id, '_elementor_element_cache');
    }

    function actSubmitPendingRevision($elem_doc, $data) {
        require_once(dirname(REVISIONARY_FILE).'/revision-workflow_rvy.php');
        $rvy_workflow_ui = new Rvy_Revision_Workflow_UI();
        $_post = get_post(rvy_post_id($this->revision_id));

        //phpcs:ignore Squiz.PHP.CommentedOutCode.Found
		/* previous workaround
        if ('inherit' == $_post->post_status) {
            $_post->post_status = 'pending';
        }
    	*/

        $args = ['revision_id' => $this->revision_id, 'published_post' => $_post, 'object_type' => $_post->post_type];
        $rvy_workflow_ui->do_notifications('pending-revision', 'pending-revision', (array) $_post, $args);
		
		clean_post_cache($this->revision_id);

        delete_metadata('post', $this->revision_id, '_elementor_element_cache');
    }

    function actUpdatePendingRevision($elem_doc, $data) {
		require_once(dirname(REVISIONARY_FILE).'/revision-workflow_rvy.php');
        $rvy_workflow_ui = new Rvy_Revision_Workflow_UI();
        $_post = get_post(rvy_post_id($this->revision_id));

        //phpcs:ignore Squiz.PHP.CommentedOutCode.Found
		/* previous workaround
        if ('inherit' == $_post->post_status) {
            $_post->post_status = 'pending';
        }
    	*/

		if (rvy_get_option('revision_update_notifications') && !defined('REVISIONARY_ELEMENTOR_NO_UPDATE_NOTIFICATIONS')) {
        	$args = ['update' => true, 'revision_id' => $this->revision_id, 'published_post' => $_post, 'object_type' => $_post->post_type];
        	$rvy_workflow_ui->do_notifications('pending-revision', 'pending-revision', (array) $_post, $args);
    	}

        delete_metadata('post', $this->revision_id, '_elementor_element_cache');
    }

    function actPublishScheduledRevision($elem_doc, $data) {
        require_once( dirname(REVISIONARY_FILE).'/admin/revision-action_rvy.php');	
        rvy_revision_publish($this->revision_id);
    }

    // Stop Elementor from blocking front end display (even outside Elementor ) of past revisions to capable users
    function fltPostsRequestPastRevisions($request, $query_obj) {
        global $wpdb;
        static $busy;

        if (!empty($busy)) {
            return $request;
        }

        $busy = true;

        if (!is_admin() && (!defined('REST_REQUEST') || ! REST_REQUEST)) {
            $is_revision_query = strpos($request, "post_type = 'revision'");

            if (!$this->orig_post_id  && !empty($query_obj->query_vars['p'])) {
                if (('revision' == get_post_field('post_type', $query_obj->query_vars['p'])) && current_user_can('edit_post', $query_obj->query_vars['p'])) {
                    $this->orig_post_id = (int) $query_obj->query_vars['p'];
                }
            }

            if ($this->orig_post_id) {
                $this->orig_post_id = (int) $this->orig_post_id;
                $request = str_replace("ID = {$this->orig_post_id} AND $wpdb->posts.post_type IN ('post', 'page'", "ID = {$this->orig_post_id} AND $wpdb->posts.post_type IN ('post', 'page', 'revision'", $request);
            }
        }

        $busy = false;
        return $request;
    }

    // @todo: Is this hook still needed for scheduled revision submission?
    function elementorDisableSubmissionRedirect($redirect) {
        if (defined('DOING_AJAX') && DOING_AJAX 
        && !empty($_REQUEST['action']) && ('elementor_ajax' == $_REQUEST['action'])             //phpcs:ignore WordPress.Security.NonceVerification.Recommended
        && !empty($_REQUEST['editor_post_id'])                                                  //phpcs:ignore WordPress.Security.NonceVerification.Recommended
        && did_action('elementor/db/before_save')
        ) {
            $redirect = false;
        }

        return $redirect;
    }

    private function isElementorPostType($post_type) {
        return in_array($post_type, get_post_types_by_support('elementor'));
    }
}
