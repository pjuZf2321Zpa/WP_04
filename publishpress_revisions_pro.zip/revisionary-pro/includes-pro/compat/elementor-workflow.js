(function ($, window, document) {
    'use strict';

    const config = window.RevisionaryElementorWorkflow;
    if (!config || !Array.isArray(config.buttons) || window.__rvyElementorWorkflowControls) return;
    window.__rvyElementorWorkflowControls = true;
    window.__rvyElementorWorkflowIntent = '';
    window.__rvyElementorWorkflowSaveFailed = false;
    let lastSaveError = '';
    let workflowBusy = false;
    const { __, sprintf } = wp.i18n;

    function textOf(element) {
        return (element.getAttribute('aria-label') || element.textContent || '').replace(/\s+/g, ' ').trim();
    }

    function visible(element) {
        if (!element || !element.isConnected || !element.getClientRects().length) return false;
        const style = window.getComputedStyle(element);
        return style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0';
    }

    function nativeSaveCaption(label) {
        return /^(update|submit|publish|update page|publish changes)$/i.test(label)
            || (config.nativeSaveLabels || []).includes(label);
    }

    function findSaveButton() {
        const legacy = document.getElementById('elementor-panel-saver-button-publish');
        if (visible(legacy)) return legacy;

        const currentTopbar = document.querySelector('.MuiButtonGroup-firstButton');
        if (visible(currentTopbar)) {
            const button = currentTopbar.matches('button,[role="button"]') ? currentTopbar : currentTopbar.querySelector('button,[role="button"]');
            if (button && visible(button)) return button;
        }

        const root = document.getElementById('elementor-editor-wrapper-v2') || document.getElementById('elementor-panel') || document;
        const candidates = root.querySelectorAll('button,[role="button"]');
        for (const candidate of candidates) {
            if (!candidate.closest('[id^="rvy-elementor-workflow-"]') && nativeSaveCaption(textOf(candidate)) && visible(candidate)) return candidate;
        }
        return null;
    }

    function setText(element, value) {
        const label = element.querySelector('#elementor-panel-saver-button-publish-label');
        if (label) {
            label.textContent = value;
            return;
        }
        // Retain Elementor's React-owned elements and replace only a text node.
        const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT);
        let node;
        while ((node = walker.nextNode())) {
            if (node.nodeValue.trim()) {
                node.nodeValue = value;
                return;
            }
        }
    }

    function disabled(element) {
        return !!(element.disabled || element.getAttribute('aria-disabled') === 'true'
            || element.classList.contains('elementor-disabled') || element.classList.contains('Mui-disabled'));
    }

    function editorLoading() {
        const indicators = document.querySelectorAll('.elementor-loading, .elementor-loader, .MuiCircularProgress-root, [aria-label="Loading"]');
        return Array.from(indicators).some(visible);
    }

    function showStatus(button, message) {
        window.RevisionaryBuilderNotice(message, 'elementor');
    }

    async function transition(operation, button) {
        workflowBusy = true;
        button.disabled = true;
        try {
            const body = new URLSearchParams({
                action: 'revisionary_elementor_transition',
                operation: operation,
                revision_id: String(config.id),
                nonce: config.transitionNonce
            });
            const response = await window.fetch(config.transitionUrl, {
                method: 'POST', credentials: 'same-origin', body: body
            });
            let result;
            try { result = await response.json(); } catch (error) {
                throw new Error(sprintf(
                    /* translators: %s: HTTP status code. */
                    __('The revision action returned HTTP %s. Keep this editor open; check your session or hosting firewall before retrying.', 'revisionary-pro'), response.status));
            }
            if (!response.ok || !result.success) {
                throw new Error(result.data && result.data.message ? result.data.message : __('The revision action failed.', 'revisionary-pro'));
            }
            workflowBusy = false;
            window.location.assign(result.data.url);
        } catch (error) {
            workflowBusy = false;
            button.disabled = false;
            showStatus(button, error.message || __('The revision action failed.', 'revisionary-pro'));
        }
    }

    function attachControls() {
        const saveButton = findSaveButton();
        if (!saveButton) return;

        const label = textOf(saveButton);
        if (nativeSaveCaption(label)) {
            const updateLabel = config.updateLabel || __('Update', 'revisionary-pro');
            if (label !== updateLabel) setText(saveButton, updateLabel);
            for (const attribute of ['aria-label', 'title']) {
                if (saveButton.getAttribute(attribute) !== updateLabel) saveButton.setAttribute(attribute, updateLabel);
            }
        }
        for (const item of config.buttons) {
            const id = 'rvy-elementor-workflow-' + item.operation;
            if (document.getElementById(id) || !saveButton.parentNode) continue;

            const action = document.createElement('button');
            action.type = 'button';
            action.id = id;
            action.className = saveButton.className;
            action.classList.remove('elementor-disabled', 'Mui-disabled', 'MuiButtonGroup-firstButton');
            action.removeAttribute('disabled');
            action.style.marginInlineStart = '8px';
            action.textContent = item.label;
            action.setAttribute('aria-label', item.label);
            action.addEventListener('click', function (event) {
                event.preventDefault();
                if (workflowBusy) return;
                // Elementor can replace the native button while retaining our
                // controls. Never save through a detached React-owned button.
                const currentSave = findSaveButton();
                if (!currentSave) {
                    showStatus(action, __('Wait for Elementor to finish loading before saving this revision.', 'revisionary-pro'));
                    return;
                }
                const saver = window.elementor && window.elementor.saver;
                const dirty = saver && typeof saver.isEditorChanged === 'function' && saver.isEditorChanged();
                if (disabled(currentSave)) {
                    if (editorLoading()) {
                        showStatus(action, __('Wait for Elementor to finish loading before submitting or approving this revision.', 'revisionary-pro'));
                        return;
                    }
                    if (lastSaveError || dirty) {
                        showStatus(action, lastSaveError || __('Your latest changes have not been saved. Retry Update before submitting or approving.', 'revisionary-pro'));
                        return;
                    }
                    // A disabled Elementor saver means there are no builder
                    // changes waiting to persist. Transition the already-saved
                    // revision directly instead of clicking a no-op control.
                    transition(item.operation, action);
                    return;
                }
                workflowBusy = true;
                lastSaveError = '';
                window.__rvyElementorWorkflowSaveFailed = false;
                window.__rvyElementorWorkflowIntent = item.operation;
                window.setTimeout(function () {
                    if (window.__rvyElementorWorkflowIntent === item.operation) {
                        window.__rvyElementorWorkflowIntent = '';
                        workflowBusy = false;
                    }
                }, 15000);
                currentSave.click();
            });
            saveButton.parentNode.insertBefore(action, saveButton.nextSibling);
        }
        if (lastSaveError && config.buttons.length) {
            const action = document.getElementById('rvy-elementor-workflow-' + config.buttons[0].operation);
            if (action) action.disabled = false;
        }
    }

    function isBuilderSave(data) {
        if (typeof data === 'string') return data.indexOf('save_builder') !== -1;
        if (data && typeof data.get === 'function') return String(data.get('actions') || '').indexOf('save_builder') !== -1;
        return !!(data && String(data.actions || '').indexOf('save_builder') !== -1);
    }

    $.ajaxPrefilter(function (options, originalOptions, request) {
        const operation = window.__rvyElementorWorkflowIntent;
        if (String(options.url || '').indexOf('admin-ajax.php') === -1 || !isBuilderSave(options.data)) return;

        let saveFailed = false;
        const failed = function (status, result) {
            saveFailed = true;
            workflowBusy = false;
            window.__rvyElementorWorkflowIntent = '';
            window.__rvyElementorWorkflowSaveFailed = true;
            const workflowAction = operation === 'submit' || operation === 'approve';
            if (status) {
                lastSaveError = sprintf(
                    /* translators: %s: HTTP status code. */
                    workflowAction
                        ? __('Elementor could not save your changes (HTTP %s). Retry Update before submitting or approving.', 'revisionary-pro')
                        : __('Elementor could not save your changes (HTTP %s).', 'revisionary-pro'),
                    status
                );
            } else {
                lastSaveError = workflowAction
                    ? __('Elementor could not save your changes. Retry Update before submitting or approving.', 'revisionary-pro')
                    : __('Elementor could not save your changes.', 'revisionary-pro');
            }
            if (status === 401 || status === 403) {
                // Renew the authenticated nonce without replaying the save or
                // reloading away unsaved edits.
                window.wp?.heartbeat?.connectNow();
            }
            attachControls();
            showStatus(null, lastSaveError);
        };
        if (request && typeof request.fail === 'function') request.fail(function (response) { failed(response.status, response.responseJSON); });
        if (request && typeof request.done === 'function') request.done(function (result) {
            const responses = result && result.data && result.data.responses;
            const errors = responses && Object.values(responses).some(function (response) { return !response || response.success !== true; });
            if (!result || result.success !== true || !responses || !Object.keys(responses).length || errors) { failed(undefined, result); return; }
            lastSaveError = '';
            window.__rvyElementorWorkflowSaveFailed = false;
            window.RevisionaryBuilderNotice('', 'elementor');
            if (operation && !saveFailed) {
                const button = document.getElementById('rvy-elementor-workflow-' + operation);
                if (button) transition(operation, button);
                else workflowBusy = false;
            }
        });
        if (!operation) return;

        // Keep workflow status changes out of Elementor's native save batch.
        // Transition only after a successful response confirms it completed.
        window.__rvyElementorWorkflowIntent = '';

    });

    function observeEditor() {
        attachControls();
        const observer = new MutationObserver(attachControls);
        observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'aria-label', 'disabled'] });
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', observeEditor, { once: true });
    else observeEditor();
})(window.jQuery, window, document);
