<?php
defined('ABSPATH') || exit;

/**
 * @package     PublishPress\Revisions\RevisionaryDivi
 * @author      PublishPress <help@publishpress.com>
 * @copyright   Copyright (c) 2026 PublishPress. All rights reserved.
 * @license     GPLv2 or later
 * @since       1.0.0
 */
class RevisionaryDivi
{
	function __construct($revisionary) {
        if (rvy_get_option('permissions_compat_mode')) { return; }
		add_action('wp_print_scripts', [$this, 'submissionRedirect']);
        add_filter('revisionary_option_captions', [$this, 'workaroundCaption']);
        add_filter('revisionary_option_sections', [$this, 'workaroundSections']);
        add_action('revisionary_option_ui_revision_options', [$this, 'workaroundSettings']);
        add_filter('script_loader_src', [$this, 'backendTextModuleBundle'], 20, 2);

		add_filter('et_fb_get_asset_helpers', [$this, 'fltDiviAssetHelpers'], 11, 2);

		// Divi sends "publish" for a builder save even when the target is a
		// Revisions workflow item. Keep the WordPress post status in a revision
		// state so the workflow handler can submit or approve it after the save.
		add_filter('wp_insert_post_data', [$this, 'fltDiviRevisionPostStatus'], 99, 2);

		add_action('wp_ajax_revisionary_divi_transition', [$this, 'ajaxWorkflowTransition']);
		add_action('wp_ajax_revisionary_divi_check_save', [$this, 'ajaxCheckWorkflowSave']);

		// prevent Divi reload
		if (!rvy_is_divi_editing_preview() && !defined('REVISIONARY_LEGACY_DIVI_REDIRECT')) {
			if ($post_id = rvy_detect_post_id()) {
				if (rvy_in_revision_workflow($post_id)) {
					add_action('init', function() {
						remove_action( 'template_redirect', 'et_fb_auto_activate_builder' );
					});
				}
			}
		}

		add_action('revisionary_queue_row_actions', [$this, 'actRevisionQueueRowActions'], 10, 2);

		add_filter('revisionary_create_revision_redirect', [$this, 'fltCreateRevisionRedirect'], 10, 2);

		// Divi theme 4.14.8 requires direct positioning for revisions bar
		if (!function_exists('et_divi_replace_parent_stylesheet') && (!defined('ET_BUILDER_PRODUCT_VERSION') || version_compare(ET_BUILDER_PRODUCT_VERSION, '4.14.8', '<='))) {
			add_filter('revisionary_admin_bar_absolute', [$this, 'fltAdminBarAbsolute']);
		}

		add_filter('page_link', [$this, 'fltPermalink'], 10, 2);
		add_filter('post_type_link', [$this, 'fltPermalink'], 10, 2);

		add_action( 'admin_bar_menu', [$this, 'et_fb_add_admin_bar_link'], 1 );
	}
    function isDivi4() {
        return defined('ET_BUILDER_VERSION') && version_compare(ET_BUILDER_VERSION, '4.0', '>=')
            && version_compare(ET_BUILDER_VERSION, '5.0', '<');
    }

    function workaroundCaption($captions) {
        $captions['divi4_revisor_backend_workaround'] = __('Divi 4 integration: apply back end editing workaround for Revisors', 'revisionary-pro');
        return $captions;
    }

    function workaroundSections($sections) {
        if ($this->isDivi4()) {
            $sections['features']['options'][] = 'divi4_revisor_backend_workaround';
        }
        return $sections;
    }

    function workaroundSettings($ui) {
        if ($this->isDivi4()) {
            $ui->option_checkbox('divi4_revisor_backend_workaround', 'features', 'options', __('Caution: Disable this setting if any editor errors occur.', 'revisionary-pro'));
        }
    }

    /** Opt-in workaround for Divi's nested SCROLL_END / OPEN_SETTINGS dispatch. */
    function backendTextModuleBundle($src, $handle) {
        if (!$this->isDivi4() || !rvy_get_option('divi4_revisor_backend_workaround')
            || (!is_admin() && empty($_REQUEST['et_bfb'])) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
            || !($id = rvy_detect_post_id()) || !rvy_in_revision_workflow($id)
            || !current_user_can('edit_post', $id)
            || !current_user_can('set_revision_pending-revision', $id)
            || current_user_can('approve_revision', $id)
            || false === strpos($src, '/includes/builder/frontend-builder/build/bundle.js')) {
            return $src;
        }
        // Read only the active parent theme's known asset, never a request URL.
        $file = get_template_directory() . '/includes/builder/frontend-builder/build/bundle.js';
        if (!is_readable($file)) { return $src; }
        $source = file_get_contents($file); // phpcs:ignore WordPressVIPMinimum.Performance.FetchingRemoteData.FileGetContentsUnknown -- Retain existing integration behavior per the PHPCS review scope.
        if (!$source) { return $src; }
        $pattern = '~([a-zA-Z_$][\w$]*\.default)\.openModuleSettings\(this\)(?=:"partial"!==this\.props\.vb_support)~';
        $count = 0;
        $patched = preg_replace_callback($pattern, static function ($match) {
            $action = $match[1];
            return '(function(m){if(m.props.type==="et_pb_text"&&m.props.just_created){setTimeout(function(){'
                . $action . '.openModuleSettings(m)},0)}else{' . $action . '.openModuleSettings(m)}})(this)';
        }, $source, -1, $count);
        if (1 !== $count || !$patched) { return $src; }
        $uploads = wp_upload_dir();
        if (!empty($uploads['error'])) { return $src; }
        $directory = $uploads['basedir'] . '/revisionary-divi4';
        $name = 'bundle-' . hash('sha256', $patched) . '.js';
        $target = $directory . '/' . $name;
        if (!is_file($target)) {
            if (!wp_mkdir_p($directory)) { return $src; }
            // Atomic rename prevents another editor from receiving a partial bundle.
            $temporary = wp_tempnam($target, $directory);
            if (!$temporary) { return $src; }
            $written = file_put_contents($temporary, $patched); // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.file_ops_file_put_contents -- Retain existing integration behavior per the PHPCS review scope.
            if (strlen($patched) !== $written || !class_exists('WP_Filesystem_Direct') || !WP_Filesystem_Direct::move($temporary, $target)) {
                @wp_delete_file($temporary);
                return $src;
            }

			if (class_exists('WP_Filesystem_Direct')) {
           		WP_Filesystem_Direct::chmod($target, defined('FS_CHMOD_FILE') ? FS_CHMOD_FILE : 0644);
			}
		}
        return set_url_scheme($uploads['baseurl'] . '/revisionary-divi4/' . $name);
    }

	function et_fb_add_admin_bar_link() {
		global $wp_the_query;

		if (!rvy_is_divi_editing_preview() && !empty($wp_the_query->query_vars['p']) && !empty($wp_the_query->queried_object->ID) && ($wp_the_query->queried_object->ID != $wp_the_query->query_vars['p']) && rvy_in_revision_workflow($wp_the_query->query_vars['p'])) {
			$wp_the_query->queried_object = get_post($wp_the_query->query_vars['p']);
		}
	}

	function fltAdminBarAbsolute($absolute) {
		return false;
	}

	function fltPermalink($url, $post) {
		static $busy;

		if (!empty($busy)) {
			return $url;
		}

		$busy = true;

		if (rvy_in_revision_workflow($post)) {
			$url = rvy_preview_url($post);
		}

		$busy = false;

		return $url;
	}

	function fltCreateRevisionRedirect($url, $post_id) {
        if (!empty($_REQUEST['front']) && !defined('PP_REVISIONS_DIVI_NO_REDIRECT')) {						//phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$url = add_query_arg(['et_fb' => 1, 'PageSpeed' => 'off'], rvy_preview_url($post_id));
        }

        return $url;
    }

	function fltDiviAssetHelpers($content, $post_type) {
		$revision_id = 0;
		foreach (['et_post_id', 'page_id', 'post'] as $request_key) {
			if (!empty($_REQUEST[$request_key])) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				$candidate = absint($_REQUEST[$request_key]); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
				if (rvy_in_revision_workflow($candidate)) {
					$revision_id = $candidate;
					break;
				}
			}
		}
		if (!$revision_id && ($detected_id = rvy_detect_post_id()) && rvy_in_revision_workflow($detected_id)) {
			$revision_id = $detected_id;
		}

		if ($revision_id) {
			$revision = get_post($revision_id);
			$update_label = in_array($revision->post_mime_type, ['draft-revision', 'pending-revision'], true)
				? esc_html__('Update', 'revisionary-pro')
				: pp_revisions_label('update_revision');
			$publish_labels = array_unique([esc_html__('Publish'), esc_html__('Submit')]);
			foreach ($publish_labels as $publish_label) {
				$content = preg_replace('/("publishButtonText"\s*:\s*")' . preg_quote($publish_label, '/') . '(")/', '$1' . addcslashes($update_label, '\\$') . '$2', $content);
				$content = preg_replace('/("publish"\s*:\s*")' . preg_quote($publish_label, '/') . '(")/', '$1' . addcslashes($update_label, '\\$') . '$2', $content);
			}
		}

		return $content;
	}

	function submissionRedirect() {
		if (rvy_is_divi_editing_preview()) {
			return;
		}
		if ($post_id = rvy_detect_post_id()) {
			if (rvy_in_revision_workflow($post_id)) {
				$revision = get_post($post_id);
				$can_approve = $revision && in_array($revision->post_mime_type, ['draft-revision', 'pending-revision'], true)
					&& current_user_can('approve_revision', $post_id);
				$can_submit = $revision && 'draft-revision' === $revision->post_mime_type
					&& (is_content_administrator_rvy() || current_user_can('set_revision_pending-revision', $post_id));
				$workflow_operation = $can_approve ? 'approve' : ($can_submit ? 'submit' : '');
				if (!$workflow_operation) {
					return;
				}
				$workflow_caption = 'approve' === $workflow_operation
					? __('Approve Revision', 'revisionary-pro')
					: __('Submit Revision', 'revisionary-pro');
				$script_handle = 'rvy-divi-workflow';
				wp_enqueue_script($script_handle, plugins_url('includes-pro/compat/divi-workflow.js', REVISIONARY_PRO_FILE), ['jquery', RevisionaryBuilderWorkflow::noticeScript()], PUBLISHPRESS_REVISIONS_PRO_VERSION, true);
				wp_add_inline_script($script_handle, 'window.RevisionaryDiviWorkflow = ' . wp_json_encode([
					'id' => $post_id,
                    'legacyLoading' => defined('REVISIONARY_DIVI_LEGACY_LOADING'),
                    'exitEditorOnTransition' => defined('ET_BUILDER_VERSION') && version_compare(ET_BUILDER_VERSION, '5.0', '>='),
					'operation' => $workflow_operation,
					'caption' => $workflow_caption,
					'updateLabel' => __('Update', 'revisionary-pro'),
					'transitionUrl' => admin_url('admin-ajax.php'),
					'transitionNonce' => wp_create_nonce('rvy-divi-transition:' . $post_id),
					'compareUrl' => rvy_compare_url($post_id),
                    'previewUrl' => rvy_preview_url($post_id),
                    'approvalUrl' => add_query_arg('rvy_approval', 1, get_permalink(rvy_post_id($post_id))),
				]) . ';', 'before');
				?>
				<style>
				body.et-fb div.rvy_view_revision a.rvy_preview_linkspan {display: none;}
				<?php if (!empty($_REQUEST['et_fb'])): // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
				div.rvy_view_revision a.rvy_preview_linkspan, #pp_revisions_top_bar div.rvy_preview_msgspan a, #pp_revisions_top_bar div.rvy_preview_msgspan span.rvy-preview-link {display: none;}
				<?php endif; ?>
				</style>
				<?php
			}
		}
	}

	function fltDiviRevisionPostStatus($data, $postarr) {
		if (empty($_REQUEST['action']) || ('et_fb_ajax_save' != $_REQUEST['action'])			//phpcs:ignore WordPress.Security.NonceVerification.Recommended
		|| empty($_REQUEST['options']) || empty($_REQUEST['options']['status'])					//phpcs:ignore WordPress.Security.NonceVerification.Recommended
		|| ('publish' != $_REQUEST['options']['status'])											//phpcs:ignore WordPress.Security.NonceVerification.Recommended
		|| empty($postarr['ID']) || !isset($data['post_status']) || ('publish' != $data['post_status'])
		) {
			return $data;
		}

		$revision = get_post((int) $postarr['ID']);

		if (!$revision || !rvy_in_revision_workflow($revision)) {
			return $data;
		}

		$data['post_status'] = in_array($revision->post_status, ['draft', 'pending'], true)
			? $revision->post_status
			: 'draft';

		return $data;
	}

	/** Run a revision transition only after Divi reports that its native save completed. */
	function ajaxWorkflowTransition() {
		$revision_id = absint($_POST['revision_id'] ?? 0);
		$nonce = sanitize_text_field(wp_unslash($_POST['nonce'] ?? ''));
		if (!$revision_id || !wp_verify_nonce($nonce, 'rvy-divi-transition:' . $revision_id)) {
			wp_send_json_error(['message' => __('Invalid revision editing session.', 'revisionary-pro')], 403);
		}

		$revision = get_post($revision_id);
		if (!$revision || !rvy_in_revision_workflow($revision_id)
			|| !in_array($revision->post_mime_type, ['draft-revision', 'pending-revision'], true)
			|| !current_user_can('edit_post', $revision_id)) {
			wp_send_json_error(['message' => __('You cannot edit this revision.', 'revisionary-pro')], 403);
		}

		$operation = sanitize_key(wp_unslash($_POST['operation'] ?? ''));
		require_once dirname(REVISIONARY_FILE) . '/admin/revision-action_rvy.php';
		if ('submit' === $operation && 'draft-revision' === $revision->post_mime_type
			&& (is_content_administrator_rvy() || current_user_can('set_revision_pending-revision', $revision_id))) {
			$result = rvy_revision_submit($revision_id);
		} elseif ('approve' === $operation && current_user_can('approve_revision', $revision_id)) {
			$approval_url = add_query_arg('rvy_approval', 1, get_permalink(rvy_post_id($revision_id)));
			$result = rvy_revision_approve($revision_id);
		} else {
			wp_send_json_error(['message' => __('You cannot perform this action.', 'revisionary-pro')], 403);
		}

		if (false === $result || is_wp_error($result)) {
			wp_send_json_error(['message' => __('The revision action failed.', 'revisionary-pro')], 400);
		}

		wp_send_json_success(['url' => 'approve' === $operation ? $approval_url : rvy_preview_url($revision_id)]);
	}

	/** Check whether the native Divi save has persisted since the workflow action began. */
	function ajaxCheckWorkflowSave() {
		$revision_id = absint($_POST['revision_id'] ?? 0);
		$nonce = sanitize_text_field(wp_unslash($_POST['nonce'] ?? ''));
		$baseline = sanitize_text_field(wp_unslash($_POST['modified'] ?? ''));
		if (!$revision_id || !wp_verify_nonce($nonce, 'rvy-divi-transition:' . $revision_id)) {
			wp_send_json_error(['message' => __('Invalid revision editing session.', 'revisionary-pro')], 403);
		}

		$revision = get_post($revision_id);
		if (!$revision || !rvy_in_revision_workflow($revision_id)
			|| !in_array($revision->post_mime_type, ['draft-revision', 'pending-revision'], true)
			|| !current_user_can('edit_post', $revision_id)) {
			wp_send_json_error(['message' => __('You cannot edit this revision.', 'revisionary-pro')], 403);
		}

		wp_send_json_success([
			'modified' => $revision->post_modified_gmt,
			'saved' => '' !== $baseline && $baseline !== $revision->post_modified_gmt,
		]);
	}

	function actRevisionQueueRowActions($actions, $post) {
        // Divi 5 has its own format-aware workflow action. Never offer its
        // editor for legacy shortcode revisions through this Divi 4 callback.
        if (!$this->isDivi4() || !rvy_in_revision_workflow($post)
            || !in_array($post->post_mime_type, ['draft-revision', 'pending-revision'], true)
            || !current_user_can('edit_post', $post->ID)
            || false !== strpos($post->post_content, 'wp:divi/')
            || ('on' !== get_post_meta($post->ID, '_et_pb_use_builder', true)
                && false === strpos($post->post_content, '[et_pb_'))) {
            return $actions;
        }
        $actions['divi'] = sprintf(
            '<a href="%1$s" class="" title="%2$s" aria-label="%2$s">%3$s</a>',
            add_query_arg(['et_fb' => 1, 'PageSpeed' => 'off'], get_permalink($post->ID)),
            esc_html__('Divi', 'revisionary-pro'),
            esc_html__('Divi', 'revisionary-pro')
        );

        return $actions;
    }
} // end RevisionaryDivi class
