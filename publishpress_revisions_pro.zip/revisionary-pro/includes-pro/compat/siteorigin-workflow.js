(function () {
    'use strict';
    let config = window.RevisionaryBuilderSession;
    // Some admin setups leave the inline session bootstrap inert when the
    // SiteOrigin editor adds its preview frame. Keep the configuration on
    // this external script as well so the transport can still scope the
    // initial AJAX preview request before SiteOrigin writes it into about:blank.
    if (!config && document.currentScript && document.currentScript.dataset.rvyBuilderSession) {
        try { config = JSON.parse(document.currentScript.dataset.rvyBuilderSession); } catch (error) {}
    }
    if (!config || config.builder !== 'siteorigin' || window.__rvySiteOriginWorkflow) return;
    window.__rvySiteOriginWorkflow = true;
    function scoped(value) {
        try {
            const url = new URL(value || window.location.href, window.location.href);
            if (url.origin !== window.location.origin) return value;
            url.searchParams.set('_rvy_builder_revision', String(config.id));
            url.searchParams.set('_rvy_builder_nonce', config.nonce);
            return url.href;
        } catch (error) {
            return value;
        }
    }
    function previewUrl(value) {
        try {
            const native = new URL(value, window.location.href);
            if (native.origin !== window.location.origin || !native.searchParams.has('siteorigin_panels_live_editor')) return value;
            const target = new URL(config.preview || native.href, window.location.href);
            // Preserve native nonce, mode, isolation policy and any future preview flags.
            native.searchParams.forEach((value, key) => {
                if (key === '_panelsnonce' || key.startsWith('siteorigin_panels_live_editor')) target.searchParams.set(key, value);
            });
            if (window.crossOriginIsolated === true) target.searchParams.set('siteorigin_panels_live_editor_isolated', '1');
            return scoped(target.href);
        } catch (error) { return value; }
    }
    function fields(form) {
        if (!form || new URL(form.action || window.location.href, window.location.href).origin !== window.location.origin) return;
        if (form.querySelector('[name="live_editor_panels_data"]')) form.action = previewUrl(form.action);
        for (const [name, value] of Object.entries({ _rvy_builder_revision: config.id, _rvy_builder_nonce: config.nonce })) {
            let input = form.querySelector('input[name="' + name + '"]');
            if (!input) { input = document.createElement('input'); input.type = 'hidden'; input.name = name; form.appendChild(input); }
            input.value = value;
        }
    }
    function updateSaveCaption() {
        document.querySelectorAll('.so-panels-live-editor .live-editor-save').forEach(button => {
            const caption = config.update || 'Update';
            if (button.textContent !== caption) button.textContent = caption;
        });
    }
    function start() {
        updateSaveCaption();
        const form = document.getElementById('post');
        // SiteOrigin uses jQuery.trigger('submit'), then native form.submit().
        // Prepopulate the editor form; a native submit-event listener alone misses it.
        fields(form);
        // Submit the native editor form first. The redirect hook verifies the
        // persisted sanitized panels_data before performing the requested action.
        document.addEventListener('click', (event) => {
            const action = event.target.closest?.('#pp_revisions_top_bar a.rvy-submit-revision, #pp_revisions_top_bar a.rvy-approve-revision');
            if (!action) return;
            event.preventDefault(); event.stopImmediatePropagation();
            const operation = action.classList.contains('rvy-approve-revision') ? 'approve' : 'submit';
            const save = document.querySelector('.so-panels-live-editor .live-editor-save') || document.getElementById('save-post') || document.getElementById('publish');
            if (!form || !save || save.disabled) { window.RevisionaryBuilderNotice(config.saveFirst, 'siteorigin'); return; }
            let input = form.querySelector('[name="_rvy_siteorigin_operation"]');
            if (!input) { input = document.createElement('input'); input.type = 'hidden'; input.name = '_rvy_siteorigin_operation'; form.appendChild(input); }
            input.value = operation;
            fields(form);
            save.click();
        }, true);
        // This data attribute is consumed by SiteOrigin when its builder starts.
        // Its canvas uses a form POST with no iframe src, not an AJAX-filled frame.
        const metabox = document.getElementById('siteorigin-panels-metabox');
        if (metabox) {
            const native = metabox.getAttribute('data-preview-url');
            if (native) metabox.setAttribute('data-preview-url', previewUrl(native));
        }
        if (window.jQuery) {
            window.jQuery(document).on('submit.rvySiteOrigin', 'form', function () { fields(this); });
            window.jQuery.ajaxPrefilter(function (options) { options.url = scoped(previewUrl(options.url)); });
        }
        document.addEventListener('submit', (event) => fields(event.target), true);

        // SiteOrigin can reload the preview in an iframe while entering or
        // leaving Live Editor. Its iframe may be inserted before SiteOrigin
        // assigns a URL, so watch both new nodes and later src changes. Use the
        // standard revision preview URL for the SiteOrigin canvas, preserving
        // SiteOrigin's own live-editor arguments and nonce.
        function scopePreviewFrame(frame) {
            if (!frame || /^siteorigin-panels-live-preview-/.test(frame.id || '')) return;
            try {
                const source = frame.getAttribute('src') || frame.src;
                if (!source) return;
                const target = new URL(source, window.location.href);
                const current = new URL(window.location.href);
                const siteOriginEditor = target.searchParams.has('siteorigin_panels_live_editor')
                    || target.searchParams.has('so_live_editor');
                const isPreview = target.pathname === current.pathname
                    || target.searchParams.has('rv_preview')
                    || target.searchParams.has('preview_id')
                    || target.searchParams.has('page_id')
                    || siteOriginEditor;
                if (target.origin === window.location.origin && isPreview) {
                    let scopedTarget = target;
                    if (siteOriginEditor && config.preview) {
                        scopedTarget = new URL(config.preview, window.location.href);
                        for (const name of ['siteorigin_panels_live_editor', 'so_live_editor', '_panelsnonce', 'siteorigin_panels_live_editor_isolated']) {
                            if (target.searchParams.has(name)) {
                                scopedTarget.searchParams.set(name, target.searchParams.get(name));
                            }
                        }
                    }
                    const next = scoped(scopedTarget.href);
                    if (next !== target.href) frame.src = next;
                }
            } catch (error) {}
        }

        document.querySelectorAll('iframe').forEach(scopePreviewFrame);
        const frameObserver = new MutationObserver((records) => {
            // Native Live Editor controls are created again on open/re-render.
            updateSaveCaption();
            records.forEach((record) => {
                if ('attributes' === record.type) {
                    if (record.target && record.target.matches && record.target.matches('iframe')) {
                        scopePreviewFrame(record.target);
                    }
                    return;
                }
                record.addedNodes.forEach((node) => {
                    if (node.nodeType !== 1) return;
                    if (node.matches && node.matches('iframe')) scopePreviewFrame(node);
                    if (node.querySelectorAll) node.querySelectorAll('iframe').forEach(scopePreviewFrame);
                });
            });
        });
        frameObserver.observe(document.documentElement, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: ['src']
        });

        // The persistent standard bar belongs to the outer editor shell.
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true }); else start();
})();
