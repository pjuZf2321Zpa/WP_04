(function ($, window, document) {
    'use strict';

    var config = window.RevisionaryDiviWorkflow;
    if (!$ || !config || !config.operation || window.__rvyDiviWorkflowInitialized) return;
    window.__rvyDiviWorkflowInitialized = true;

    var intent = '';
    var transitionStarted = false;
    var timeoutId = 0;
    var saveCheckTimer = 0;
    var preparing = false;
    var saveBaseline = '';

    function actionInValue(value) {
        if (!value) return false;
        if (typeof value === 'string') {
            var decoded = value;
            try { decoded = decodeURIComponent(value.replace(/\+/g, ' ')); } catch (error) { /* Keep the original payload. */ }
            return /(?:^|[?&])action=et_fb_ajax_save(?:&|$)/.test(decoded)
                || /["']action["']\s*:\s*["']et_fb_ajax_save["']/.test(decoded);
        }
        if (typeof value === 'object') {
            if (typeof value.get === 'function' && value.get('action') === 'et_fb_ajax_save') return true;
            if (value.action === 'et_fb_ajax_save') return true;
            return Object.keys(value).some(function (key) { return actionInValue(value[key]); });
        }
        return false;
    }

    function isDiviSave(url, body) {
        return actionInValue(url) || actionInValue(body);
    }

    function resetIntent(message) {
        intent = '';
        preparing = false;
        transitionStarted = false;
        window.__rvyDiviWorkflowIntent = '';
        if (timeoutId) window.clearTimeout(timeoutId);
        if (saveCheckTimer) window.clearTimeout(saveCheckTimer);
        timeoutId = 0;
        saveCheckTimer = 0;
        var button = document.getElementById('rvy-divi-workflow-action');
        if (button) button.disabled = false;
        if (message) window.RevisionaryBuilderNotice(message, 'divi');
    }

    function transition() {
        if (!intent || transitionStarted) return;
        transitionStarted = true;
        if (timeoutId) window.clearTimeout(timeoutId);
        if (saveCheckTimer) window.clearTimeout(saveCheckTimer);
        timeoutId = 0;
        saveCheckTimer = 0;
        $.ajax({
            url: config.transitionUrl,
            method: 'POST',
            dataType: 'json',
            timeout: 30000,
            data: {
                action: 'revisionary_divi_transition',
                revision_id: config.id,
                operation: intent,
                nonce: config.transitionNonce
            }
        }).done(function (response) {
            if (!response || !response.success) {
                resetIntent(response && response.data && response.data.message ? response.data.message : 'The revision action failed.');
                return;
            }
            intent = '';
            window.__rvyDiviWorkflowIntent = '';
            var destination = response.data && response.data.url ? response.data.url : (config.operation === 'approve' ? config.approvalUrl : config.previewUrl);
            var targetWindow = window;
            if (config.exitEditorOnTransition) {
                try { if (window.top.location.origin === window.location.origin) targetWindow = window.top; } catch (error) { /* Retain local navigation across origins. */ }
            }
            targetWindow.location.assign(destination);
        }).fail(function (xhr) {
            var message = xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message;
            resetIntent(message || 'The revision action failed. Please try again.');
        });
    }

    function saveResponse(response, status) {
        if (!intent || transitionStarted) return;
        // Native XHR normally exposes JSON as a response string. A 2xx status
        // alone is not proof of a successful save; unknown response formats
        // must wait for the guarded persistence check instead.
        if (status >= 200 && status < 300 && (!response || typeof response !== 'object')) return;
        var data = response && (response.data || response);
        if (status >= 200 && status < 300 && (!response || response.success !== false) && (!data || data.success !== false)) {
            transition();
            return;
        }
        var message = data && data.message;
        resetIntent(message || 'Divi could not save this revision. The workflow action was not applied.');
    }

    // Divi moves editor UI into its own iframe on some versions. In that case
    // the transport hooks above may not see the save even though WordPress has
    // persisted it. Poll the workflow revision timestamp as a same-origin,
    // server-confirmed fallback before giving up.
    function checkSavedRevision() {
        if (!intent || transitionStarted) return;
        $.ajax({
            url: config.transitionUrl,
            method: 'POST',
            dataType: 'json',
            timeout: 10000,
            data: {
                action: 'revisionary_divi_check_save',
                revision_id: config.id,
                modified: saveBaseline,
                nonce: config.transitionNonce
            }
        }).done(function (response) {
            if (response && response.success && response.data && response.data.saved) {
                transition();
            } else if (intent && !transitionStarted) {
                saveCheckTimer = window.setTimeout(checkSavedRevision, 500);
            }
        }).fail(function (xhr) {
            if (xhr && (xhr.status === 401 || xhr.status === 403)) {
                var message = xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message;
                resetIntent(message || 'Divi could not verify that the revision was saved. The workflow action was not applied.');
            } else if (intent && !transitionStarted) {
                saveCheckTimer = window.setTimeout(checkSavedRevision, 1000);
            }
        });
    }

    // Divi 4 can send builder saves through XHR/fetch instead of jQuery's
    // global AJAX events. Observe the transport so the workflow action only
    // follows the actual successful et_fb_ajax_save response.
    var originalFetch = window.fetch;
    if (originalFetch) {
        window.fetch = function (input, options) {
            // Startup requests retain their native timing until a workflow action begins.
            if (!config.legacyLoading && !intent) return originalFetch.apply(this, arguments);
            var url = typeof input === 'string' || input instanceof URL ? String(input) : input.url;
            var body = options && options.body;
            var context = this;
            var request = Promise.resolve();
            if (!isDiviSave(url, body) && typeof Request !== 'undefined' && input instanceof Request && !body) {
                request = input.clone().text().catch(function () { return ''; }).then(function (text) { body = text; });
            }
            return request.then(function () {
                var save = !!intent && isDiviSave(url, body);
                return originalFetch.call(context, input, options).then(function (response) {
                    if (save) {
                        return response.clone().json().then(function (data) {
                            saveResponse(data, response.status);
                            return response;
                        }, function () {
                            if (!response.ok) saveResponse(null, response.status);
                            return response;
                        });
                    }
                    return response;
                }, function (error) {
                    if (save) resetIntent('Divi could not save this revision. The workflow action was not applied.');
                    throw error;
                });
            });
        };
    }

    if (window.XMLHttpRequest) {
        var xhrOpen = XMLHttpRequest.prototype.open;
        var xhrSend = XMLHttpRequest.prototype.send;
        XMLHttpRequest.prototype.open = function (method, url) {
            this.__rvyDiviUrl = String(url);
            return xhrOpen.apply(this, arguments);
        };
        XMLHttpRequest.prototype.send = function (body) {
            var save = !!intent && isDiviSave(this.__rvyDiviUrl, body);
            if (save) {
                this.addEventListener('loadend', function () {
                    var data = this.responseJSON || this.response;
                    if (typeof data === 'string' || !data) {
                        try { data = JSON.parse(typeof data === 'string' ? data : this.responseText); } catch (error) { data = null; }
                    }
                    saveResponse(data, this.status);
                }, { once: true });
            }
            return xhrSend.apply(this, arguments);
        };
    }

    function setToolbarAttribute(button, name, value) {
        if (config.legacyLoading || button.getAttribute(name) !== value) {
            button.setAttribute(name, value);
        }
    }

    function setNativeCaption(button) {
        if (!button) return;
        setToolbarAttribute(button, 'aria-label', config.updateLabel);
        setToolbarAttribute(button, 'title', config.updateLabel);
        var walker = document.createTreeWalker(button, NodeFilter.SHOW_TEXT);
        var node;
        while ((node = walker.nextNode())) {
            if (/^(?:Publish|Submit)\s*$/.test(node.nodeValue.trim())
                && (config.legacyLoading || node.nodeValue !== config.updateLabel)) node.nodeValue = config.updateLabel;
        }
    }

    function update() {
        var nativeButton = document.querySelector('button.et-fb-button--publish:not(#rvy-divi-workflow-action)');
        if (!nativeButton || !nativeButton.parentNode) return;
        setNativeCaption(nativeButton);

        var button = document.getElementById('rvy-divi-workflow-action');
        if (!button) {
            button = document.createElement('button');
            button.className = nativeButton.className;
            button.id = 'rvy-divi-workflow-action';
            button.type = 'button';
            button.style.marginLeft = '8px';
        }
        if (button.textContent !== config.caption) button.textContent = config.caption;
        setToolbarAttribute(button, 'aria-label', config.caption);
        if (!button.__rvyWorkflowClickBound) {
            button.addEventListener('click', handleWorkflowClick);
            button.__rvyWorkflowClickBound = true;
        }
        if (button.parentNode !== nativeButton.parentNode) nativeButton.parentNode.insertBefore(button, nativeButton.nextSibling);
    }

    function handleWorkflowClick(event) {
        var button = event.currentTarget && event.currentTarget.id === 'rvy-divi-workflow-action'
            ? event.currentTarget
            : event.target;
        while (button && button !== document && button.id !== 'rvy-divi-workflow-action') button = button.parentNode;
        if (!button || button === document) return;
        if (event.__rvyDiviWorkflowHandled) return;
        event.__rvyDiviWorkflowHandled = true;
        event.preventDefault();
        if (button.disabled || preparing || intent || !config.operation) return;
        var nativeButton = document.querySelector('button.et-fb-button--publish:not(#rvy-divi-workflow-action)');
        if (!nativeButton) return;

        preparing = true;
        transitionStarted = false;
        button.disabled = true;
        timeoutId = window.setTimeout(function () {
            if ((preparing || intent) && !transitionStarted) resetIntent('Divi did not confirm that the revision was saved. The workflow action was not applied.');
        }, 60000);
        // An earlier Update can change the timestamp after page load. Capture
        // the current server value before this save so it cannot approve on
        // the strength of an unrelated, earlier save.
        $.ajax({
            url: config.transitionUrl,
            method: 'POST', dataType: 'json', timeout: 10000,
            data: { action: 'revisionary_divi_check_save', revision_id: config.id, nonce: config.transitionNonce }
        }).done(function (response) {
            if (!preparing) return;
            if (!response || !response.success || !response.data || !response.data.modified) {
                resetIntent('Divi could not verify this revision editing session. The workflow action was not applied.');
                return;
            }
            saveBaseline = response.data.modified;
            preparing = false;
            intent = config.operation;
            window.__rvyDiviWorkflowIntent = intent;
            nativeButton.click();
            checkSavedRevision();
        }).fail(function () {
            if (preparing) resetIntent('Divi could not verify this revision editing session. The workflow action was not applied.');
        });
    }

    // Divi can rebuild or clone its toolbar while moving the Visual Builder
    // into an iframe. A delegated listener survives replacement of the
    // workflow button node, unlike a listener attached to one rendered node.
    document.addEventListener('click', function (event) {
        var button = event.target;
        while (button && button !== document && button.id !== 'rvy-divi-workflow-action') button = button.parentNode;
        if (button && button !== document) handleWorkflowClick(event);
    });

    function initializeToolbar() {
        // Divi can evaluate this script before the editor document has a body.
        // Wait for DOM readiness before observing or modifying its toolbar.
        if (!document.body) return;
        update();
        if (window.MutationObserver) {
            new window.MutationObserver(update).observe(document.body, { childList: true, subtree: true });
        }
        if (window.setInterval) {
            var toolbarRefreshCount = 0;
            var toolbarRefreshTimer = window.setInterval(function () {
                update();
                if (++toolbarRefreshCount >= 30) window.clearInterval(toolbarRefreshTimer);
            }, 500);
        }
    }

    if (document.body) {
        initializeToolbar();
    } else {
        document.addEventListener('DOMContentLoaded', initializeToolbar, { once: true });
    }
})(window.jQuery, window, document);
