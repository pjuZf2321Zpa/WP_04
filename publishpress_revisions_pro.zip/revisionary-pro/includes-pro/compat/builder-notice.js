/** Revision editor notices, outside builder toolbar layout. */
(function (window) {
    'use strict';
    if (window.RevisionaryBuilderNotice) return;
    window.RevisionaryBuilderNotice = function (message, key) {
        let doc = window.document;
        try { if (window.top.location.origin === window.location.origin) doc = window.top.document; } catch (error) {}
        const id = 'rvy-builder-notice-' + (key || 'workflow');
        const previous = doc.getElementById(id);
        if (!message) { previous?.remove(); return; }
        if (previous && previous.querySelector('[data-rvy-message]').textContent === message) return;
        previous?.remove();
        if (!doc.body) { doc.addEventListener('DOMContentLoaded', () => window.RevisionaryBuilderNotice(message, key), {once:true}); return; }
        const notice = doc.createElement('div');
        notice.id = id; notice.setAttribute('role', 'alert');
        notice.style.cssText = 'position:fixed;top:64px;right:20px;z-index:2147483647;box-sizing:border-box;width:480px;max-width:calc(100vw - 40px);max-height:calc(100vh - 100px);overflow:auto;padding:16px 44px 16px 18px;border-left:4px solid #d63638;background:#fff;color:#1e1e1e;box-shadow:0 3px 18px #0004;font:14px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;text-align:left;white-space:normal;overflow-wrap:anywhere';
        const text = doc.createElement('div'); text.setAttribute('data-rvy-message', ''); text.textContent = message;
        const dismiss = doc.createElement('button'); dismiss.type = 'button'; dismiss.textContent = '×';
        dismiss.setAttribute('aria-label', 'Dismiss notice');
        dismiss.style.cssText = 'position:absolute;top:6px;right:8px;border:0;background:transparent;color:#50575e;font:24px/1.5 sans-serif;cursor:pointer';
        dismiss.addEventListener('click', () => notice.remove());
        notice.append(text, dismiss); doc.body.appendChild(notice);
    };
})(window);
