<?php
/** Avada One and Avada Classic: native Fusion saves in a signed revision session. */
defined('ABSPATH') || exit;

final class RevisionaryAvadaIntegration {
    private static $saving = 0;
    public static function classic() {
        return defined('AVADA_VERSION') && version_compare(AVADA_VERSION, '7.16.4', '>=')
            && version_compare(AVADA_VERSION, '7.17', '<');
    }
    public static function editingSupported() {
        // Keep Avada One's existing supported range separate from Classic's
        // separately packaged builder. Do not enable unknown major versions.
        $one = defined('AVADA_VERSION') && version_compare(AVADA_VERSION, '1.0.0', '>=')
            && version_compare(AVADA_VERSION, '1.1.0-alpha', '<');
        return $one || (self::classic() && defined('FUSION_BUILDER_VERSION')
            && version_compare(FUSION_BUILDER_VERSION, '3.16.4', '>=')
            && version_compare(FUSION_BUILDER_VERSION, '3.17', '<')
            && function_exists('Fusion_App') && shortcode_exists('fusion_builder_container'));
    }
    public static function init() {
        add_action('admin_head', [__CLASS__, 'backendAssets'], 20);
        add_filter('revisionary_compare_skip_meta_fields', [__CLASS__, 'skipViewCounters']);
        add_filter('fusion_load_live_editor', [__CLASS__, 'loadEditor']);
        add_filter('awb_role_manager_access_capability', [__CLASS__, 'capability'], 100, 4);
        add_filter('fusion_save_data', [__CLASS__, 'saveData'], PHP_INT_MAX);
        add_filter('wp_insert_post_data', [__CLASS__, 'guardPost'], -200, 2);
        add_action('wp_enqueue_scripts', [__CLASS__, 'runtime'], 0);
        add_action('fusion_app_before', [__CLASS__, 'runtime'], 1);
    }
    /** Runtime analytics are not editorial changes, even with Avada inactive. */
    public static function skipViewCounters($fields) {
        return array_values(array_unique(array_merge((array) $fields, [
            'avada_post_views_count',
            'avada_today_post_views_count',
            'avada_post_views_count_today_date',
        ])));
    }
    public static function backendAssets() {
        if (!defined('AVADA_VERSION') || !wp_script_is('rvy_editor_save', 'enqueued')) { return; }
        wp_enqueue_script('rvy-avada-backend-save', plugins_url('includes-pro/compat/avada-backend-save.js', REVISIONARY_PRO_FILE), ['rvy_editor_save', 'jquery'], PUBLISHPRESS_REVISIONS_PRO_VERSION, true);
    }
    private static function target() {
        $id = sanitize_text_field(wp_unslash($_REQUEST['_rvy_builder_revision'] ?? ($_GET['preview_id'] ?? ($_GET['page_id'] ?? ($_GET['p'] ?? ($_REQUEST['post_id'] ?? 0)))))); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        // Supported Avada backend capability filters run in post.php, before the
        // frontend query exists. This is only an access check: native form
        // saves continue to require WordPress's post-specific nonce.
        if (!$id && self::editingSupported() && is_admin() && !wp_doing_ajax()) {
            $id = sanitize_text_field(wp_unslash($_GET['post'] ?? ($_POST['post_ID'] ?? 0))); // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        }
        return absint($id);
    }
    private static function revision() {
        $id = self::target(); $post = $id ? get_post($id) : null;
        return $post && rvy_in_revision_workflow($post) && current_user_can('edit_post', $id)
            && in_array($post->post_mime_type, ['draft-revision', 'pending-revision'], true) ? $post : null;
    }
    public static function loadEditor($allowed) {
        if ($allowed || rvy_get_option('permissions_compat_mode')) { return $allowed; }
        return self::revision() ? true : $allowed;
    }
    public static function capability($cap, $type = null, $context = '', $id = null) {
        $contexts = ['live_builder_edit', 'page_options'];
        if (self::editingSupported()) { $contexts[] = 'backend_builder_edit'; }
        if (!in_array($context, $contexts, true) || rvy_get_option('permissions_compat_mode')) { return $cap; }
        $post = self::revision();
        if (!$post || ($id && (int) $id !== (int) $post->ID) || ($type && $type !== $post->post_type)) { return $cap; }
        return $id ? 'edit_post' : 'read';
    }
    public static function editorContext() {
        if ('GET' !== sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD'] ?? 'GET')) || wp_doing_ajax() || !is_user_logged_in()) { return null; }
        $backend = self::editingSupported() && is_admin() && 'post.php' === ($GLOBALS['pagenow'] ?? '')
            && 'edit' === sanitize_key(wp_unslash($_GET['action'] ?? '')); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        if (!$backend && !isset($_GET['fb-edit']) && !in_array($_GET['builder'] ?? '', ['true', '1'], true)) { return null; } // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        $id = $backend ? absint($_GET['post'] ?? 0) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
            : absint($_GET['preview_id'] ?? ($_GET['page_id'] ?? ($_GET['p'] ?? ($_GET['post_id'] ?? 0)))); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        if (!$id && is_singular()) { $id = get_queried_object_id(); }
        $post = $id ? get_post($id) : null;
        if (!$post || !rvy_in_revision_workflow($post) || 'avada' !== RevisionaryBuilderWorkflow::builder($post)) { return null; }
        if (isset($_GET['_rvy_builder_revision']) && $id !== absint($_GET['_rvy_builder_revision'])) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
            return new WP_Error('rvy_builder_target', __('Only the selected revision can be edited in this session.', 'revisionary-pro'));
        }
        return RevisionaryBuilderWorkflow::context($id, wp_create_nonce('rvy-builder-edit:' . $id));
    }
    public static function runtime() {
        static $printed = false;
        if ($printed) { return; }
        $post = self::editorContext();
        if (!$post || is_wp_error($post)) { return; }
        $printed = true;
        RevisionaryBuilderWorkflow::runtime();
    }
    private static function reject($message) {
        wp_send_json_error(['message' => $message, 'failure' => ['revision' => $message]], 403);
        exit;
    }
    public static function guardAjax($post, $action) {
        $avada = in_array($action, ['get_shortcode_render', 'update_page_template_post_meta'], true)
            || 0 === strpos($action, 'fusion_') || 0 === strpos($action, 'awb_');
        if (!$avada) { return false; }
        if (!$post) {
            $target = absint($_POST['post_id'] ?? 0);
            if ('fusion_app_save_post_content' === $action && $target && rvy_in_revision_workflow($target)) {
                self::reject(__('Open this revision from its guarded builder editing link.', 'revisionary-pro'));
            }
            return false;
        }
        if (is_wp_error($post)) { self::reject($post->get_error_message()); }
        if ('avada' !== RevisionaryBuilderWorkflow::builder($post)) { return false; }
        if (!in_array($action, ['fusion_app_save_post_content', 'update_page_template_post_meta'], true)
            && RevisionaryBuilderWorkflow::parentEditorUnrestricted($post)) { return true; }
        foreach (['post_id', 'target_post'] as $key) {
            if (isset($_POST[$key]) && (string) $post->ID !== sanitize_text_field(wp_unslash($_POST[$key]))) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Retain existing integration behavior per the PHPCS review scope.
                self::reject(__('Only the selected revision can be targeted.', 'revisionary-pro'));
            }
        }
        // Avada waits for this startup request before navigating from the
        // backend editor to Live Builder. It has no fusion_/awb_ prefix.
        // Keep it scoped to this revision and retain the native nonce check.
        if ('update_page_template_post_meta' === $action) {
            if ((int) $post->ID !== absint($_POST['post_id'] ?? 0)
                || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['fusion_load_nonce'] ?? '')), 'fusion_load_nonce')) {
                self::reject(__('Invalid Avada revision save session. Reload the editor and try again.', 'revisionary-pro'));
            }
            return true; // Native handler still checks its nonce and edit_post.
        }
        if ('fusion_app_save_post_content' === $action) {
            if ((int) $post->ID !== absint($_POST['post_id'] ?? 0)
                || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['fusion_load_nonce'] ?? '')), 'fusion_load_nonce')) {
                self::reject(__('Invalid Avada revision save session. Reload the editor and try again.', 'revisionary-pro'));
            }
            foreach (['fusion_options', 'custom', 'global_elements', 'layout_id'] as $key) {
                if (!empty($_POST[$key])) { self::reject(__('Shared Avada layouts, library elements and global options cannot be modified when editing a revision.', 'revisionary-pro')); }
            }
            // Native Avada sanitizes page options and content. Status, author,
            // hierarchy and taxonomy publication settings cannot escape this session.
            if (isset($_POST['post_details'])) {
                parse_str(wp_unslash($_POST['post_details']), $details); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Structured builder payload; scalar IDs and native save data are validated separately.
                $details = array_intersect_key($details, array_flip(['post_title', 'post_excerpt', 'post_name']));
                // Avada reads this unconditionally when saving page settings.
                // Derive it from the authorized revision, never the request.
                $details['post_type'] = $post->post_type;
                if (empty($details['post_name'])) { unset($details['post_name']); }
                $_POST['post_details'] = wp_slash(http_build_query($details));
            }
            self::$saving = $post->ID;
            return true;
        }
        // Reviewed render/data endpoints. All library, preset, global option,
        // import and shared layout writes are rejected before native dispatch.
        return in_array($action, ['fusion_get_widget_form', 'fusion_builder_load_studio_elements', 'awb_load_websites', 'fusion_app_save_builder_preferences', 'get_shortcode_render', 'fusion_release_post_lock', 'fusion_get_post_lock_data', 'awb_get_library_items', 'awb_resolve_media_ids', 'fusion_load_custom_elements', 'fusion_builder_load_layout', 'fusion_builder_get_image_url', 'fusion_app_partial_refresh', 'fusion_app_full_refresh', 'fusion_app_preview_only', 'fusion_get_webfonts_ajax', 'fusion_builder_get_library_data', 'fusion_builder_get_library_elements', 'fusion_builder_get_element_data', 'fusion_builder_get_shortcode', 'fusion_builder_get_dynamic_data'], true)
            ? true : self::reject(__('Shared Avada resources cannot be modified when editing a revision.', 'revisionary-pro'));
    }
    public static function guardPreview() {
        $action = sanitize_key($_POST['action'] ?? ''); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Retain existing integration behavior per the PHPCS review scope.
        if (!in_array($action, ['fusion_app_full_refresh', 'fusion_app_preview_only'], true) || empty($_REQUEST['_rvy_builder_revision'])) { return false; } // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        $post = RevisionaryBuilderWorkflow::context(absint($_REQUEST['_rvy_builder_revision']), sanitize_text_field(wp_unslash($_REQUEST['_rvy_builder_nonce'] ?? ''))); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Retain existing integration behavior per the PHPCS review scope.
        if (is_wp_error($post)) { wp_die(esc_html($post->get_error_message()), '', ['response' => 403]); }
        return self::guardAjax($post, $action);
    }
    public static function guardPost($data, $input) {
        if (!self::$saving) { return $data; }
        if (self::$saving !== absint($input['ID'] ?? 0) && 'revision' !== ($data['post_type'] ?? '')) {
            self::reject(__('Shared Avada layouts and library elements cannot be modified when editing a revision.', 'revisionary-pro'));
        }
        return $data;
    }
    public static function saveData($data) {
        if (self::$saving && empty($data['failure'])) {
            $data['rvy_saved'] = true; $data['id'] = self::$saving;
        }
        return $data;
    }
}
