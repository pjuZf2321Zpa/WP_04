/* Explain shared-resource restrictions before native mutation handlers run. */
(function () {
    'use strict';
    const config = window.RevisionarySharedResourceEditor;
    if (!config || !config.message) return;

    function explain(event, noticeDocument) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        noticeDocument = noticeDocument || document;
        let notice = noticeDocument.getElementById('rvy-shared-resource-notice');
        if (!notice) {
            notice = noticeDocument.createElement('div');
            notice.id = 'rvy-shared-resource-notice';
            notice.className = 'rvy-shared-resource-notice';
            notice.setAttribute('role', 'alert');
            const message = noticeDocument.createElement('span');
            message.textContent = config.message;
            const dismiss = noticeDocument.createElement('button');
            dismiss.type = 'button';
            dismiss.setAttribute('aria-label', config.dismiss);
            dismiss.textContent = '\u00d7';
            dismiss.addEventListener('click', () => notice.remove());
            notice.appendChild(message);
            notice.appendChild(dismiss);
            if (noticeDocument !== document && !noticeDocument.getElementById('rvy-shared-resource-editor-style')) {
                const style = noticeDocument.createElement('style');
                style.id = 'rvy-shared-resource-editor-style';
                style.textContent = '.rvy-shared-resource-notice{position:fixed;top:58px;left:50%;transform:translateX(-50%);z-index:2147483000;box-sizing:border-box;width:min(680px,calc(100% - 32px));padding:16px 44px 16px 20px;border-left:4px solid #dba617;background:#fff;color:#1e1e1e;box-shadow:0 2px 14px rgba(0,0,0,.25);font:14px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;text-align:left}.rvy-shared-resource-notice button{position:absolute;top:8px;right:8px;padding:4px 8px;border:0;background:transparent;color:#50575e;font-size:22px;cursor:pointer}.rvy-shared-resource-notice button:focus-visible{outline:2px solid #2271b1}';
                noticeDocument.head.appendChild(style);
            }
            noticeDocument.body.appendChild(notice);
        }
    }

    function handleClick(event, noticeDocument) {
        const target = event.target;
        if (!target || !target.closest) return;
        if (config.builder === 'beaver') {
            if (target.closest('.fl-builder-global-settings') && target.closest('.fl-builder-settings-save')) explain(event, noticeDocument);
            return;
        }
        if (config.builder === 'wpbakery') {
            if (target.closest('#vc_ui-panel-templates') && target.closest('#vc_ui-save-template-btn, .vc_template-save-btn, [data-vc-ui-delete="template-title"], .vc_template-delete-icon')) explain(event, noticeDocument);
            return;
        }
        if (config.builder === 'divi4') {
            if (target.closest('.et-fb-button--toggle-save, [data-tip="Save To Library"]')) explain(event, noticeDocument);
            return;
        }
        const item = target.closest('[role="menuitem"]');
        if (!item) return;
        const label = item.textContent.replace(/\s+/g, ' ').trim();
        if ((config.builder === 'gutenberg' && [config.labels.createPattern, config.labels.editPattern].includes(label))
            || (config.builder === 'elementor' && label === config.labels.elementorSave)) explain(event, noticeDocument);
    }

    document.addEventListener('click', event => handleClick(event, document), true);
    if (config.builder === 'beaver') {
        try {
            if (window.parent && window.parent !== window) {
                window.parent.document.addEventListener('click', event => handleClick(event, window.parent.document), true);
            }
        } catch (error) {
            // Cross-origin parent frames are not accessible; the local frame listener remains active.
        }
    }

    function guardTemplateEnter(event) {
        if (config.builder !== 'wpbakery' || (event.key !== 'Enter' && event.keyCode !== 13)) return;
        const target = event.target;
        if (target && target.closest && target.closest('#vc_ui-panel-templates') && target.closest('[data-js-element="vc-templates-input"]')) explain(event);
    }
    document.addEventListener('keydown', guardTemplateEnter, true);
    document.addEventListener('keypress', guardTemplateEnter, true);
})();
