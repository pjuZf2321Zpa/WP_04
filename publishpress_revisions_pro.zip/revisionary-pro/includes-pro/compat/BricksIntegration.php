<?php
/** Page-local integration for the reviewed Bricks 2.4.3 save contract. */
defined('ABSPATH') || exit;

final class RevisionaryBricksIntegration {
    public static function supported() {
        return defined('BRICKS_VERSION') && version_compare(BRICKS_VERSION, '2.4.3', '>=') && version_compare(BRICKS_VERSION, '2.5.0-alpha', '<');
    }
    public static function permission($id) { return \Bricks\Capabilities::current_user_can_use_builder($id); }
    private static function error($message) { return new WP_Error('rvy_bricks_scope', $message, ['status' => 403]); }
    private static function decode($value) {
        if (!is_string($value)) { return self::error('Invalid Bricks JSON payload.'); }
        $decoded = json_decode($value, true);
        return JSON_ERROR_NONE === json_last_error() && is_array($decoded) ? $decoded : self::error('Invalid Bricks JSON payload.');
    }
    private static function nonempty($value) {
        if (is_array($value)) { foreach ($value as $item) { if (self::nonempty($item)) { return true; } } return false; }
        return null !== $value && false !== $value && '' !== $value;
    }
    /** Restore native per-request rendering state between comparison snapshots. */
    public static function isolated($callback) {
        $saved = [];
        foreach (['Bricks\\Assets', 'Bricks\\Database', 'Bricks\\Frontend', 'Bricks\\Theme_Styles', 'Bricks\\Query'] as $class) {
            $reflection = new ReflectionClass($class);
            foreach ($reflection->getProperties(ReflectionProperty::IS_STATIC) as $property) {
                $property->setAccessible(true); $saved[] = [$property, $property->getValue()];
            }
        }
        try { return $callback(); }
        finally { foreach (array_reverse($saved) as $state) { $state[0]->setValue(null, $state[1]); } }
    }
    public static function prepare($post, $data) {
        // Ordinary Bricks pages use templateType=content too. The target post
        // and edited area, rather than a nonempty transport value, define scope.
        if ('bricks_template' === $post->post_type
            || (!empty($data['templateType']) && 'content' !== $data['templateType'])
            || (!empty($data['area']) && 'content' !== $data['area'])) { return self::error('Only page-local Bricks content can be edited in a revision.'); }
        $shared = [
            'components' => BRICKS_DB_COMPONENTS, 'colorPalette' => BRICKS_DB_COLOR_PALETTE,
            'styleManager' => BRICKS_DB_STYLE_MANAGER, 'globalQueries' => BRICKS_DB_GLOBAL_QUERIES,
            'globalQueriesCategories' => BRICKS_DB_GLOBAL_QUERIES_CATEGORIES, 'iconSets' => BRICKS_DB_ICON_SETS,
            'customIcons' => BRICKS_DB_CUSTOM_ICONS, 'disabledIconSets' => BRICKS_DB_DISABLED_ICON_SETS,
            'fontFavorites' => BRICKS_DB_FONT_FAVORITES, 'globalClasses' => BRICKS_DB_GLOBAL_CLASSES,
            'globalClassesCategories' => BRICKS_DB_GLOBAL_CLASSES_CATEGORIES, 'globalClassesLocked' => BRICKS_DB_GLOBAL_CLASSES_LOCKED,
            'globalClassesTrash' => BRICKS_DB_GLOBAL_CLASSES_TRASH, 'globalVariables' => BRICKS_DB_GLOBAL_VARIABLES,
            'globalVariablesTrash' => BRICKS_DB_GLOBAL_VARIABLES_TRASH, 'globalVariablesCategories' => BRICKS_DB_GLOBAL_VARIABLES_CATEGORIES,
            'globalElements' => BRICKS_DB_GLOBAL_ELEMENTS, 'pinnedElements' => BRICKS_DB_PINNED_ELEMENTS,
            'pseudoClasses' => BRICKS_DB_PSEUDO_CLASSES, 'themeStyles' => BRICKS_DB_THEME_STYLES,
        ];
        foreach ($shared as $key => $option) {
            if (!isset($data[$key])) { continue; }
            $value = self::decode($data[$key]); if (is_wp_error($value)) { return $value; }
            $expected = json_decode(wp_json_encode(get_option($option, [])), true);
            if ($value != $expected) { return self::error('Shared Bricks resources cannot be changed from a revision (' . $key . ').'); }
        }
        $changes = ['globalChanges', 'globalVariablesRenamed', 'colorPaletteRenamed', 'iconSetAttachmentCleanup', 'fontChanges', 'fonts', 'templateSettings'];
        foreach ($changes as $key) {
            if (!isset($data[$key])) { continue; }
            $value = self::decode($data[$key]); if (is_wp_error($value)) { return $value; }
            if (self::nonempty($value)) { return self::error('Shared Bricks resources cannot be changed from a revision (' . $key . ').'); }
        }
        // Header/footer trees may be sent unchanged by a forced native save.
        foreach (['header' => BRICKS_DB_PAGE_HEADER, 'footer' => BRICKS_DB_PAGE_FOOTER] as $area => $key) {
            if (!isset($data[$area])) { continue; }
            $value = self::decode($data[$area]); if (is_wp_error($value)) { return $value; }
            $expected = get_post_meta($post->ID, $key, true) ?: [];
            if (!$expected) {
                $expected = self::isolated(static function () use ($post, $area) {
                    \Bricks\Database::set_active_templates(rvy_post_id($post));
                    $id = \Bricks\Database::$active_templates[$area] ?? 0;
                    return $id ? \Bricks\Database::get_data($id, $area) : [];
                });
            }
            if ($value != $expected) { return self::error('Shared Bricks headers and footers are read-only in revisions.'); }
        }
        // Project only the reviewed page-local fields into the write plan below.
        // Unknown transport/extension fields are inert: never persist them or
        // forward this request to Bricks' native save handler. Known shared
        // resources above remain read-only even when local content is included.
        if (!isset($data['content']) && !isset($data['pageSettings'])) {
            // Bricks can send a save request with no page-local payload when
            // the user clicks Save without making changes. Shared-resource
            // checks above still run, but this request needs no database write.
            return ['noop' => true, 'update' => [], 'meta' => []];
        }
        $result = ['update' => [], 'meta' => [BRICKS_DB_EDITOR_MODE => 'bricks']];
        if (isset($data['content'])) {
            $content = self::decode($data['content']); if (is_wp_error($content)) { return $content; }
            $ids = [];
            foreach ($content as $element) {
                if (!is_array($element) || empty($element['id']) || !is_string($element['id']) || empty($element['name']) || !is_string($element['name']) || isset($ids[$element['id']]) || !is_array($element['settings'] ?? []) || !is_array($element['children'] ?? [])) { return self::error('Invalid Bricks element tree.'); }
                $ids[$element['id']] = true;
            }
            // Native sanitizer enforces content-only/structure/code permissions and expects slashed values.
            $content = wp_unslash(\Bricks\Helpers::security_check_elements_before_save(wp_slash($content), $post->ID, 'content'));
            $result['meta'][BRICKS_DB_PAGE_CONTENT] = $content;
            if (\Bricks\Database::get_setting('bricks_to_wp') && (!$post->post_content || has_blocks($post))) { $result['update']['post_content'] = \Bricks\Blocks::serialize_bricks_to_blocks($content, $post->ID); }
        }
        if (isset($data['pageSettings'])) {
            $settings = self::decode($data['pageSettings']); if (is_wp_error($settings)) { return $settings; }
            if (!\Bricks\Builder_Permissions::user_has_permission('access_page_settings')) {
                $old = get_post_meta($post->ID, BRICKS_DB_PAGE_SETTINGS, true) ?: [];
                $expected = json_decode(wp_json_encode($old), true);
                if ($settings != $expected) { return self::error('Bricks page settings access is required.'); }
                return $result; // An unchanged native settings echo does not require write access.
            }
            if (!current_user_can('unfiltered_html')) {
                $old = get_post_meta($post->ID, BRICKS_DB_PAGE_SETTINGS, true) ?: [];
                foreach (['customScriptsHeader', 'customScriptsBodyHeader', 'customScriptsBodyFooter'] as $key) { unset($settings[$key]); if (isset($old[$key])) { $settings[$key] = $old[$key]; } }
            }
            if (isset($settings['postTitle'])) { $result['update']['post_title'] = sanitize_text_field($settings['postTitle']); unset($settings['postTitle']); }
            if (isset($settings['postName'])) { $result['meta']['_requested_slug'] = sanitize_title($settings['postName']); unset($settings['postName']); }
            $result['meta'][BRICKS_DB_PAGE_SETTINGS] = $settings;
        }
        return $result;
    }
    public static function refresh($id) {
        if ('file' === \Bricks\Database::get_setting('cssLoading')) {
            require_once BRICKS_PATH . 'includes/assets/files.php';
            self::isolated(static function () use ($id) { \Bricks\Assets_Files::generate_post_css_file($id, 'content', get_post_meta($id, BRICKS_DB_PAGE_CONTENT, true) ?: []); });
        }
    }
}
