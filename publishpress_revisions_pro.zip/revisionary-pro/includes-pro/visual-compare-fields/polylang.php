<?php
defined('ABSPATH') || exit;

return ['polylang' => ['label' => 'Polylang', 'classification_prefixes' => ['_pll_' => 'internal']]];
