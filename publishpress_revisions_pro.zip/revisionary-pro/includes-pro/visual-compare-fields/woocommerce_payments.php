<?php
defined('ABSPATH') || exit;

return ['woocommerce_payments' => ['label' => 'WooPayments', 'classifications' => ['woopay_merchant_customer_id' => 'sensitive']]];
