<?php
defined('ABSPATH') || exit;

return [
    'theme_tourze_lite' => [
        'label' => 'Tourze Lite',
        'classifications' => ['_import_source' => 'internal'],
    ],
];
