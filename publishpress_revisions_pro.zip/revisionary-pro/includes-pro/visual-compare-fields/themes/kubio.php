<?php
defined('ABSPATH') || exit;

return [
    'theme_kubio' => [
        'label' => 'Kubio',
        'classifications' => ['_kubio_front_starter_content' => 'internal'],
    ],
];
