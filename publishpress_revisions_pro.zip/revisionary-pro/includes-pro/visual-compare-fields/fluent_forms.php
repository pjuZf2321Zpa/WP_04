<?php
defined('ABSPATH') || exit;

return ['fluent_forms' => ['label' => 'Fluent Forms', 'classifications' => ['_has_fluentform' => 'internal']]];
