<?php
defined('ABSPATH') || exit;

return ['akismet' => ['label' => 'Akismet', 'classifications' => ['akismet_error' => 'internal']]];
