<?php
defined('ABSPATH') || exit;

return ['smush' => ['label' => 'Smush', 'classification_prefixes' => ['wp-smush-' => 'internal']]];
