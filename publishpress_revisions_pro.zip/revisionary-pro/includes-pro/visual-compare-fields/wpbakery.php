<?php
defined('ABSPATH') || exit;

return [
    'wpbakery' => [
        'label' => 'WPBakery Page Builder',
        'caption_prefixes' => ['_wpb_'],
        'fields' => [
            '_wpb_post_custom_css' => RevisionaryVisualCompareFieldProviders::field('Custom CSS', 'Page settings'),
            '_wpb_post_custom_layout' => RevisionaryVisualCompareFieldProviders::field('Custom layout', 'Page settings'),
        ],
        'blacklist' => ['_wpb_post_custom_css', '_wpb_post_custom_layout'],
    ],
];
