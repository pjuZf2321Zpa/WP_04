<?php
defined('ABSPATH') || exit;

$meta_key = defined('BRICKS_DB_PAGE_SETTINGS') ? BRICKS_DB_PAGE_SETTINGS : '_bricks_page_settings';

return [
    'bricks' => [
        'label' => 'Bricks',
        'caption_prefixes' => ['_bricks_'],
        'fields' => [
            $meta_key => RevisionaryVisualCompareFieldProviders::field('Page settings', 'Page settings'),
        ],
        'blacklist' => [$meta_key],
    ],
];
