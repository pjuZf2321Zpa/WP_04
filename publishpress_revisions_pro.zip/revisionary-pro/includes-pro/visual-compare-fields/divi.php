<?php
defined('ABSPATH') || exit;

return [
    'divi' => [
        'label' => 'Divi',
        'caption_prefixes' => ['_et_pb_'],
        'fields' => [
            '_et_pb_page_layout' => RevisionaryVisualCompareFieldProviders::field('Page layout', 'Page settings'),
            '_et_pb_custom_css' => RevisionaryVisualCompareFieldProviders::field('Custom CSS', 'Page settings'),
            '_et_pb_side_nav' => RevisionaryVisualCompareFieldProviders::field('Vertical navigation', 'Page settings', RevisionaryVisualCompareFieldProviders::enabledDisabled()),
            '_et_pb_post_hide_nav' => RevisionaryVisualCompareFieldProviders::field('Hide navigation before scroll', 'Page settings', RevisionaryVisualCompareFieldProviders::yesNo()),
        ],
        'blacklist' => ['_et_pb_page_layout', '_et_pb_custom_css', '_et_pb_side_nav', '_et_pb_post_hide_nav'],
    ],
];
