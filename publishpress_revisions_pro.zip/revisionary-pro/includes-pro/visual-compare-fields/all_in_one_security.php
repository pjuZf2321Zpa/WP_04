<?php
defined('ABSPATH') || exit;

return ['all_in_one_security' => ['label' => 'All-In-One Security', 'classifications' => ['aiowps_account_status' => 'internal']]];
