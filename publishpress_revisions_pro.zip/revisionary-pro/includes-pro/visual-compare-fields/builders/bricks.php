<?php
defined('ABSPATH') || exit;

require_once dirname(__DIR__, 2) . '/compat/BricksIntegration.php';
return new class {
    public function available() { return RevisionaryBricksIntegration::supported() && class_exists('Bricks\\Frontend'); }
    public function optInConstant() { return 'REVISIONARY_BRICKS_VISUAL_COMPARE'; }
    public function label() { return 'Bricks Builder'; }
    public function uses($post) { return metadata_exists('post', $post->ID, '_bricks_page_content_2'); }
    public function register() {
        add_filter('revisionary_compare_meta_from', static function ($meta) {
            unset($meta['_bricks_page_content_2'], $meta['_bricks_editor_mode']);
            if (defined('BRICKS_DB_PAGE_SETTINGS')) { unset($meta[BRICKS_DB_PAGE_SETTINGS]); }
            else { unset($meta['_bricks_page_settings']); }
            return $meta;
        });
    }
    public function render($post) {
        if (!$this->uses($post)) { return wp_is_post_revision($post) ? RevisionaryBuilderCompare::missing() : RevisionaryBuilderCompare::plain($post); }
        $data = get_post_meta($post->ID, BRICKS_DB_PAGE_CONTENT, true);
        if (!is_array($data)) { throw new RuntimeException('Invalid Bricks snapshot'); }
        return RevisionaryBricksIntegration::isolated(static function () use ($post, $data) {
            $defaults = (new ReflectionClass('Bricks\\Assets'))->getDefaultProperties();
            foreach (['inline_css', 'inline_css_breakpoints', 'elements', 'global_classes_elements', 'page_settings_post_ids', 'css_looping_elements', 'templates_css', 'generated_loop_common_selectors', 'generated_loop_common_selectors_breakpoints', 'inline_css_dynamic_data', 'popup_settings_css', 'loop_index_elements'] as $key) { \Bricks\Assets::$$key = $defaults[$key]; }
            \Bricks\Assets::reset_duplication_tracking(); \Bricks\Assets::$post_id = $post->ID;
            \Bricks\Database::init_active_templates();
            \Bricks\Database::$active_templates['content'] = $post->ID;
            \Bricks\Database::$page_data = ['original_post_id' => $post->ID, 'preview_or_post_id' => $post->ID, 'post_id' => $post->ID, 'content' => $data, 'header' => [], 'footer' => [], 'settings' => get_post_meta($post->ID, BRICKS_DB_PAGE_SETTINGS, true) ?: []];
            \Bricks\Database::$page_settings = \Bricks\Database::$page_data['settings'];
            \Bricks\Theme_Styles::load_set_styles(rvy_in_revision_workflow($post) ? rvy_post_id($post) : (wp_is_post_revision($post) ?: $post->ID));
            $nodes = []; $styles = [BRICKS_URL_ASSETS . 'css/frontend.min.css'];
            $capture = static function ($attributes, $element) use (&$nodes, &$styles) {
                $id = (string) $element->id;
                if (!empty($element->element['cid'])) { $id = 'component-' . $id; }
                $nodes[$id] = ['label' => $element->element['label'] ?? $element->name, 'type' => $element->name, 'attributes' => $element->element['settings'] ?? []];
                $attributes['data-rvy-builder-id'] = $id;
                if (file_exists(BRICKS_PATH_ASSETS . 'css/elements/' . basename($element->name) . '.min.css')) { $styles[] = BRICKS_URL_ASSETS . 'css/elements/' . basename($element->name) . '.min.css'; }
                return $attributes;
            };
            add_filter('bricks/element/set_root_attributes', $capture, PHP_INT_MAX, 2);
            try {
                $level = ob_get_level(); ob_start();
                try { \Bricks\Frontend::render_content($data); $html = ob_get_clean(); }
                finally { while (ob_get_level() > $level) { ob_end_clean(); } }
                $css = \Bricks\Assets::generate_inline_css($post->ID);
                $nodes['__root__'] = ['label' => __('Page settings', 'revisionary-pro'), 'attributes' => \Bricks\Database::$page_settings];
                return array_merge(RevisionaryBuilderCompare::document($html, $css, $nodes, array_merge($styles, \Bricks\Assets::$google_fonts_urls, RevisionaryBuilderCompare::styleUrls([])), 'bricks-is-frontend'), ['selector' => '[data-rvy-builder-id]', 'idAttribute' => 'data-rvy-builder-id', 'identity' => 'stable', 'signature' => md5(wp_json_encode([$data, get_post_meta($post->ID, BRICKS_DB_PAGE_SETTINGS, true)]))]);
            } finally { remove_filter('bricks/element/set_root_attributes', $capture, PHP_INT_MAX); }
        });
    }
};
