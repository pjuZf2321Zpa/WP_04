(function (wp) {
    'use strict';
    const initialized = new WeakSet();
    wp.hooks.addAction('revisionary.builderCompare.initializeRuntime', 'revisionary-bricks-runtime', (builder, doc, root) => {
        if (builder.name !== 'bricks' || initialized.has(doc)) return;
        const runtime = doc.defaultView;
        if (typeof runtime?.reinitBricksFunctions !== 'function') return;
        // The comparison activates assets after DOMContentLoaded. Use Bricks'
        // native widget reinitialization instead of replaying that event for
        // unrelated theme and plugin scripts in the preview.
        initialized.add(doc);
        runtime.bricksIsFrontend = doc.body.classList.contains('bricks-is-frontend');
        (runtime.bricksFunctionInstances || []).forEach((instance) => {
            if (typeof instance?.addEventListeners === 'function') instance.addEventListeners();
        });
        runtime.reinitBricksFunctions(root);
    });
})(window.wp);
