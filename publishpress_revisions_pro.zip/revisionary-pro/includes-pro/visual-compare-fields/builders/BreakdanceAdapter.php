<?php
defined('ABSPATH') || exit;

final class RevisionaryBreakdanceCompareAdapter {
    private $major;
    public function __construct($major) { $this->major = $major; }
    public function available() {
        if (!defined('__BREAKDANCE_VERSION') || !function_exists('Breakdance\\Render\\getRenderedNodes')) { return false; }
        return 3 === $this->major ? version_compare(__BREAKDANCE_VERSION, '3.0.0-alpha', '>=') : version_compare(__BREAKDANCE_VERSION, '2.8.3', '>=') && version_compare(__BREAKDANCE_VERSION, '2.9.0-alpha', '<');
    }
    public function defaultEnabled() { return true; }
    public function optInConstant() { return 'REVISIONARY_BREAKDANCE' . $this->major . '_VISUAL_COMPARE'; }
    public function label() { return 'Breakdance ' . (3 === $this->major ? '3' : '2.8'); }
    public function uses($post) { return metadata_exists('post', $post->ID, '_breakdance_data'); }
    public function register() { add_filter('revisionary_compare_meta_from', static function ($meta) { unset($meta['_breakdance_data']); return $meta; }); }
    private function sharedCss() {
        // Use each installed engine's selector syntax and current shared styles.
        // These generators return CSS; never call the persistent cache writers.
        $settings = \Breakdance\Data\get_global_settings_array();
        $selectors = json_decode(wp_json_encode(\Breakdance\Data\load_selectors()), true) ?: [];
        $css = \Breakdance\Render\cssForGlobalStyles($settings, \Breakdance\GlobalSettings\globalSettingsCssTemplate(), \Breakdance\GlobalSettings\globalPropertyPathsToWhitelistInFlatProps());
        $css .= \Breakdance\Render\cssForPresets(\Breakdance\Data\load_presets(), $settings);
        $css .= \Breakdance\Render\cssForSelectors($selectors);
        if (function_exists('Breakdance\\Variables\\cssForVariables')) { $css .= \Breakdance\Variables\cssForVariables(\Breakdance\Variables\getVariables(), $settings); }
        return $css;
    }
    public function render($post) {
        if (!$this->uses($post)) { return wp_is_post_revision($post) ? RevisionaryBuilderCompare::missing() : RevisionaryBuilderCompare::plain($post); }
        $tree = \Breakdance\Data\get_tree($post->ID);
        if (!is_array($tree)) { throw new RuntimeException('Invalid Breakdance snapshot'); }
        $nodes = [];
        $capture = static function ($html, $node) use (&$nodes) {
            if (!isset($node['id'])) { return $html; }
            $id = (string) $node['id']; $name = $node['data']['type'] ?? 'Element';
            $nodes[$id] = ['label' => str_replace('\\', ' ', $name), 'type' => $name, 'attributes' => $node['data']['properties'] ?? []];
            return RevisionaryBuilderCompare::annotate($html, $id);
        };
        add_filter('breakdance_render_element_html', $capture, PHP_INT_MAX, 2);
        try {
            $rendered = \Breakdance\Render\getRenderedNodes($post->ID, false);
            if (!is_array($rendered)) { throw new RuntimeException('Breakdance render failed'); }
            // Match native precedence: base/dependency stylesheets, element
            // defaults, global settings/presets/selectors/variables, inline
            // dependencies, then page-specific rules. Never generate cache files.
            $styles = RevisionaryBuilderCompare::styleUrls([]);
            if (class_exists('Breakdance\\GlobalDefaultStylesheets\\GlobalDefaultStylesheetsController')) {
                $styles = array_merge($styles, (array) \Breakdance\GlobalDefaultStylesheets\GlobalDefaultStylesheetsController::getInstance()->stylesheetUrls);
            }
            $styles = array_merge($styles, (array) ($rendered['dependencies']['styles'] ?? []));
            if (function_exists('Breakdance\\GoogleFontsPlugin\\buildGoogleFontUrl')) {
                $fontUrl = \Breakdance\GoogleFontsPlugin\buildGoogleFontUrl((array) ($rendered['dependencies']['googleFonts'] ?? []));
                if ($fontUrl) { $styles[] = $fontUrl; }
            }
            $css = '';
            foreach ($rendered['defaultCss'] ?? [] as $rule) { $css .= ($rule['css'] ?? '') . "\n"; }
            $css .= $this->sharedCss() . "\n";
            $css .= implode("\n", (array) ($rendered['dependencies']['inlineStyles'] ?? [])) . "\n";
            $css .= implode("\n", $rendered['cssRules'] ?? []);
            $document = RevisionaryBuilderCompare::document($rendered['html'], $css, $nodes, array_values(array_unique($styles)), 'breakdance');
            if (RevisionaryBuilderCompare::javascriptEnabled()) {
                $document['scripts'] = '';
                foreach ((array) ($rendered['dependencies']['scripts'] ?? []) as $url) { if (is_string($url)) { $document['scripts'] .= '<script src="' . esc_url($url) . '"></script>'; } }
                foreach ((array) ($rendered['dependencies']['inlineScripts'] ?? []) as $script) { $document['scripts'] .= '<script>' . str_ireplace('</script', '<\/script', $script) . '</script>'; }
            }
            return array_merge($document, ['selector' => '[data-rvy-builder-id]', 'idAttribute' => 'data-rvy-builder-id', 'identity' => 'stable', 'signature' => md5(wp_json_encode($tree))]);
        } finally { remove_filter('breakdance_render_element_html', $capture, PHP_INT_MAX); }
    }
}
