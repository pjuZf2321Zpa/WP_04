<?php
defined('ABSPATH') || exit;

return new class {
    public function available() { return defined('SEEDPROD_PLUGIN_PATH') && function_exists('seedprod_lite_strip_vue_render_helpers'); }
    public function optInConstant() { return 'REVISIONARY_SEEDPROD_VISUAL_COMPARE'; }
    public function label() { return 'SeedProd'; }
    public function uses($post) { return (bool) (get_post_meta($post->ID, '_seedprod_page', true) || get_post_meta($post->ID, '_seedprod_edited_with_seedprod', true)); }
    public function register() { add_filter('revisionary_compare_meta_from', static function ($meta) { unset($meta['_rvy_seedprod_settings']); return $meta; }); }
    public function render($post) {
        if (!$this->uses($post)) { return RevisionaryBuilderCompare::plain($post); }
        $settings = json_decode($post->post_content_filtered);
        if (!is_object($settings)) { return RevisionaryBuilderCompare::missing(); }
        $nodes = [];
        $walk = static function ($value) use (&$walk, &$nodes) {
            if (!is_array($value)) { return; }
            if (isset($value['id'], $value['type'])) { $nodes['sp-' . $value['id']] = ['label' => ucwords(str_replace('-', ' ', $value['type'])), 'type' => $value['type'], 'attributes' => $value['settings'] ?? []]; }
            foreach ($value as $item) { if (is_array($item)) { $walk($item); } }
        };
        $saved_settings = json_decode($post->post_content_filtered, true);
        $walk($saved_settings);
        unset($saved_settings['document']['sections'], $saved_settings['document']['rows']);
        $nodes['__root__'] = ['label' => __('Page settings', 'revisionary-pro'), 'attributes' => $saved_settings];
        $level = ob_get_level();
        try { $page = $post; ob_start(); include SEEDPROD_PLUGIN_PATH . 'resources/views/seedprod-preview.php'; $full = ob_get_clean(); }
        finally { while (ob_get_level() > $level) { ob_end_clean(); } }
        $html = preg_match('#<body\b[^>]*>(.*?)</body>#is', $full, $body) ? $body[1] : $post->post_content;
        // Remove SeedProd's escaped image initializer from this compare-only snapshot.
        // The saved revision content is not modified.
        $html = preg_replace('#<div\b[^>]*\bid=["\']sp-image-dynamic-tags-js-[^"\']+["\'][^>]*>.*?</div>#is', '', $html);
        $body_class = preg_match('#<body\b[^>]*class=[\'"]([^\'"]*)#is', $full, $classes) ? $classes[1] : '';
        preg_match_all('#<style\b[^>]*>(.*?)</style>#is', $full, $styles); $urls = RevisionaryBuilderCompare::styleUrls([]);
        if (class_exists('WP_HTML_Tag_Processor')) { $tags = new WP_HTML_Tag_Processor($full); while ($tags->next_tag('LINK')) { if ('stylesheet' === strtolower((string) $tags->get_attribute('rel')) && $tags->get_attribute('href')) { $urls[] = $tags->get_attribute('href'); } } }
        $document = RevisionaryBuilderCompare::document($html, implode("\n", $styles[1]), $nodes, array_unique($urls), $body_class);
        if (RevisionaryBuilderCompare::javascriptEnabled()) { preg_match_all('#<script\b[^>]*>.*?</script>#is', $full, $scripts); $document['scripts'] = implode("\n", $scripts[0]); }
        return array_merge($document, ['selector' => '[id^="sp-"]', 'idAttribute' => 'id', 'identity' => 'stable', 'signature' => md5($post->post_content . $post->post_content_filtered)]);
    }
};
