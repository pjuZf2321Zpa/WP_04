<?php
defined('ABSPATH') || exit;

return new class {
    public function available() { return class_exists('SiteOrigin_Panels') && class_exists('SiteOrigin_Panels_Renderer'); }
    public function optInConstant() { return 'REVISIONARY_SITEORIGIN_VISUAL_COMPARE'; }
    public function label() { return 'SiteOrigin Page Builder'; }
    public function uses($post) { return metadata_exists('post', $post->ID, 'panels_data'); }
    public function register() { add_filter('revisionary_compare_meta_from', static function ($meta) { unset($meta['panels_data']); return $meta; }); }
    public function render($post) {
        if (!$this->uses($post)) { return wp_is_post_revision($post) ? RevisionaryBuilderCompare::missing() : RevisionaryBuilderCompare::plain($post); }
        $data = get_post_meta($post->ID, 'panels_data', true);
        if (!is_array($data)) { throw new RuntimeException('Invalid SiteOrigin snapshot'); }
        $nodes = []; $index = 0;
        $capture = static function ($attributes, $info) use (&$nodes, &$index, $data) {
            $id = 'widget-' . $index; $widget = $data['widgets'][$index++] ?? []; $class = $info['class'] ?? 'Widget';
            $nodes[$id] = ['label' => str_replace(['SiteOrigin_Widget_', '_Widget', '_'], ['', '', ' '], $class), 'type' => $class, 'attributes' => array_diff_key($widget, array_fill_keys(['so_sidebar_emulator_id', 'option_name'], true))];
            $attributes['data-rvy-builder-id'] = $id; return $attributes;
        };
        $saved = [];
        foreach (['siteorigin_panels_current_post', 'siteorigin_panels_cache', 'SITEORIGIN_PANELS_PREVIEW_RENDER'] as $name) { $saved[$name] = [array_key_exists($name, $GLOBALS), $GLOBALS[$name] ?? null]; }
        $GLOBALS['siteorigin_panels_cache'] = []; $GLOBALS['siteorigin_panels_current_post'] = null;
        add_filter('siteorigin_panels_widget_attributes', $capture, PHP_INT_MAX, 2);
        try {
            $renderer = new SiteOrigin_Panels_Renderer(); $layout = [];
            $html = $renderer->render($post->ID, false, $data, $layout); $css = $renderer->generate_css($post->ID, $data, $layout);
            $nodes['__root__'] = ['label' => __('Layout settings', 'revisionary-pro'), 'attributes' => ['grids' => $data['grids'] ?? [], 'cells' => $data['grid_cells'] ?? []]];
            return array_merge(RevisionaryBuilderCompare::document($html, $css, $nodes, array_merge([SiteOrigin_Panels::front_css_url()], RevisionaryBuilderCompare::styleUrls([])), ''), ['selector' => '[data-rvy-builder-id]', 'idAttribute' => 'data-rvy-builder-id', 'identity' => 'positional', 'signature' => md5(wp_json_encode($data))]);
        } finally {
            remove_filter('siteorigin_panels_widget_attributes', $capture, PHP_INT_MAX);
            if (isset($renderer)) { remove_action('wp_enqueue_scripts', [$renderer, 'enqueue_styles'], 1); }
            foreach ($saved as $name => $state) { if ($state[0]) { $GLOBALS[$name] = $state[1]; } else { unset($GLOBALS[$name]); } }
        }
    }
};
