<?php
defined('ABSPATH') || exit;
require_once __DIR__ . '/BreakdanceAdapter.php';
return new RevisionaryBreakdanceCompareAdapter(2);
