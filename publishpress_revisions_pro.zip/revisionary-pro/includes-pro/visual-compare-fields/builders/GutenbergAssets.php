<?php
/** In-memory assets derived from saved block attributes. */
defined('ABSPATH') || exit;

final class RevisionaryGutenbergAssets {
    public static function collect($post) {
        $css = ''; $scripts = ''; $blocks = parse_blocks($post->post_content);
        if (false !== strpos($post->post_content, 'wp:uagb/') && class_exists('UAGB_Post_Assets')) {
            $preview = [array_key_exists('preview', $_GET), $_GET['preview'] ?? null]; $state = []; // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- Preserve the original request value verbatim for restoration in finally; it is not consumed as user input here.
            foreach (['common_assets_added', 'custom_css_appended', 'conditional_blocks_printed'] as $property) { $state[$property] = UAGB_Post_Assets::$$property; UAGB_Post_Assets::$$property = false; }
            $_GET['preview'] = true;
            try {
                // Preview mode disables file generation. Do not enqueue/rebuild page files.
                $assets = new UAGB_Post_Assets($post->ID);
                $css .= $assets->stylesheet . $assets->get_block_static_css('extensions') . UAGB_Block_Helper::get_condition_block_css();
                UAGB_Scripts_Utils::enqueue_blocks_dependency_both();
                $assets->enqueue_blocks_dependency_frontend();
                if (RevisionaryBuilderCompare::javascriptEnabled() && $assets->script) { $scripts .= '<script>(function(){function initialize(){' . str_ireplace('</script', '<\/script', $assets->script) . '}if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",initialize,{once:true});}else{initialize();}})();</script>'; }
            } finally {
                foreach ($state as $property => $value) { UAGB_Post_Assets::$$property = $value; }
                if ($preview[0]) { $_GET['preview'] = $preview[1]; } else { unset($_GET['preview']); }
            }
        }
        if (false !== strpos($post->post_content, 'wp:themeisle-blocks/') && class_exists('ThemeIsle\\GutenbergBlocks\\CSS\\Block_Frontend')) {
            $css .= \ThemeIsle\GutenbergBlocks\CSS\Block_Frontend::instance()->cycle_through_static_blocks($blocks);
            if (class_exists('ThemeIsle\\GutenbergBlocks\\Blocks_CSS')) { $css .= \ThemeIsle\GutenbergBlocks\Blocks_CSS::instance()->cycle_through_blocks($blocks, $post->ID); }
        }
        if (false !== strpos($post->post_content, 'wp:essential-blocks/') && class_exists('EssentialBlocks\\Utils\\CSSParser')) {
            $found = []; $names = [];
            $parsed = \EssentialBlocks\Utils\CSSParser::eb_block_style_recursive($blocks, $found, $names);
            unset($parsed['reusableBlocks']);
            $css .= \EssentialBlocks\Utils\CSSParser::build_css(\EssentialBlocks\Utils\CSSParser::blocks_to_style_array($parsed));
        }
        return compact('css', 'scripts');
    }
}
