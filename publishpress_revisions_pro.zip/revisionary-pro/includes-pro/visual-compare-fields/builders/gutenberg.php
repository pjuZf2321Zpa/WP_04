<?php
/** Shared native rendering for supported Gutenberg extensions. */
defined('ABSPATH') || exit;

require_once __DIR__ . '/GutenbergAssets.php';
return new class {
    private $namespaces = ['kadence/', 'uagb/', 'themeisle-blocks/', 'essential-blocks/', 'stackable/', 'ugb/', 'ub/', 'advgb/'];
    public function available() {
        if (!class_exists('WP_Block_Type_Registry')) { return false; }
        if (WP_Block_Type_Registry::get_instance()->get_registered('core/paragraph')) { return true; }
        foreach (WP_Block_Type_Registry::get_instance()->get_all_registered() as $name => $type) {
            foreach ($this->namespaces as $namespace) { if (0 === strpos($name, $namespace)) { return true; } }
        }
        return false;
    }
    public function optInConstant() { return 'REVISIONARY_GUTENBERG_VISUAL_COMPARE'; }
    public function label() { return __('Block', 'revisionary-pro'); }
    public function register() {
        add_filter('revisionary_compare_meta_from', static function ($meta, $post_id) {
            $post = get_post($post_id);
            if ($post && false !== strpos((string) $post->post_content, 'wp:uagb/')) {
                // Spectra's page-level CSS is loaded into the comparison
                // canvas by UAGB_Post_Assets, so it is not a separate field.
                unset($meta['_uag_custom_page_level_css']);
            }
            return $meta;
        }, 20, 2);
    }
    public function uses($post) { return $post instanceof WP_Post && has_blocks($post->post_content); }
    public function render($post) {
        if (!has_blocks($post->post_content)) { return RevisionaryBuilderCompare::plain($post); }
        $nodes = [];
        $registry = WP_Block_Type_Registry::get_instance();
        $mark = static function ($blocks, $path = '') use (&$mark, &$nodes, $registry) {
            foreach ($blocks as $index => &$block) {
                $id = 'block-' . $path . $index;
                if (!empty($block['blockName'])) {
                    $type = $registry->get_registered($block['blockName']);
                    $caption = substr($block['blockName'], strpos($block['blockName'], '/') + 1);
                    $nodes[$id] = ['label' => $type && $type->title ? $type->title : ucwords(str_replace(['-', '_'], ' ', $caption)), 'type' => $block['blockName'], 'attributes' => (array) ($block['attrs'] ?? [])];
                    $block['attrs']['__rvy_compare_id'] = $id;
                }
                $block['innerBlocks'] = $mark($block['innerBlocks'] ?? [], $path . $index . '-');
            }
            return $blocks;
        };
        $blocks = $mark(parse_blocks($post->post_content));
        $capture = static function ($html, $block) {
            $id = $block['attrs']['__rvy_compare_id'] ?? '';
            return $id ? RevisionaryBuilderCompare::annotate($html, $id) : $html;
        };
        $saved = [];
        if (class_exists('Kadence_Blocks_CSS')) {
            foreach (['styles', 'head_styles', 'custom_styles'] as $property) {
                if (property_exists('Kadence_Blocks_CSS', $property)) { $saved[$property] = Kadence_Blocks_CSS::$$property; Kadence_Blocks_CSS::$$property = []; }
            }
        }
        $preview = $GLOBALS['wp_query']->is_preview;
        $GLOBALS['wp_query']->is_preview = true;
        add_filter('render_block', $capture, PHP_INT_MAX, 2);
        try {
            $html = implode('', array_map('render_block', $blocks));
            if (class_exists('Kadence_Blocks_Frontend')) { Kadence_Blocks_Frontend::get_instance()->frontend_build_css($post); }
            if (class_exists('Kadence_Blocks_CSS')) { Kadence_Blocks_CSS::get_instance()->frontend_block_css(); }
            $assets = RevisionaryGutenbergAssets::collect($post);
            $document = RevisionaryBuilderCompare::document($html, $assets['css'], $nodes, RevisionaryBuilderCompare::styleUrls([]), '');
            $document['scripts'] = $assets['scripts'];
            return array_merge($document, ['selector' => '[data-rvy-builder-id]', 'idAttribute' => 'data-rvy-builder-id', 'identity' => 'positional', 'signature' => md5($post->post_content), 'ignoredAttributes' => ['Content']]);
        } finally {
            remove_filter('render_block', $capture, PHP_INT_MAX);
            $GLOBALS['wp_query']->is_preview = $preview;
            foreach ($saved as $property => $value) { Kadence_Blocks_CSS::$$property = $value; }
        }
    }
};
