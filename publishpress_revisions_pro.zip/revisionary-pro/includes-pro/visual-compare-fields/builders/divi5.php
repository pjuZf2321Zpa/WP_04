<?php
defined('ABSPATH') || exit;

return new class {
    public function available() { return class_exists('ET\\Builder\\FrontEnd\\Module\\Style') && class_exists('ET\\Builder\\Packages\\Module\\Module'); }
    public function optInConstant() { return 'REVISIONARY_DIVI5_VISUAL_COMPARE'; }
    public function label() { return 'Divi 5'; }
    public function register() {
        add_filter('revisionary_compare_meta_from', static function ($meta, $post_id) {
            $post = get_post($post_id);
            if (!$post || false === strpos((string) $post->post_content, 'wp:divi/')) { return $meta; }
            foreach (array_keys($meta) as $key) {
                if (0 === strpos($key, '_et_pb_') && !preg_match('/cache|static_css|last_edited/i', $key)) { unset($meta[$key]); }
            }
            return $meta;
        }, 20, 2);
    }
    public function uses($post) { return false !== strpos($post->post_content, 'wp:divi/'); }
    public function render($post) {
        if (!$this->uses($post)) {
            if (false !== strpos($post->post_content, '[et_pb_') && function_exists('et_builder_render_layout')) { $legacy = require __DIR__ . '/divi.php'; return $legacy->render($post); }
            return RevisionaryBuilderCompare::plain($post);
        }
        $style = 'ET\\Builder\\FrontEnd\\Module\\Style'; $script = 'ET\\Builder\\FrontEnd\\Module\\ScriptData'; $parser = 'ET\\Builder\\FrontEnd\\BlockParser\\BlockParserStore';
        foreach ([$style, $script, $parser, 'ET_Builder_Module_Order'] as $class) {
            if (!is_callable([$class, 'capture_state']) || !is_callable([$class, 'restore_state'])) { throw new RuntimeException('Unsupported Divi isolation API'); }
        }
        $style_state = $style::capture_state(); $script_state = $script::capture_state(); $parser_state = $parser::capture_state(); $order_state = ET_Builder_Module_Order::capture_state();
        $style::reset(); $script::reset(); $parser::reset(); ET_Builder_Module_Order::reset_all_indexes();
        $nodes = [];
        $capture = static function ($html, $args) use (&$nodes) {
            $id = 'divi5-' . count($nodes); $name = $args['name'] ?? 'divi/module'; $type = WP_Block_Type_Registry::get_instance()->get_registered($name);
            $nodes[$id] = ['label' => $type && $type->title ? $type->title : $name, 'type' => $name, 'attributes' => $args['attrs'] ?? []];
            return RevisionaryBuilderCompare::annotate($html, $id);
        };
        add_filter('divi_module_wrapper_render', $capture, PHP_INT_MAX, 2);
        try {
            $html = do_blocks($post->post_content); $css = (string) get_post_meta($post->ID, '_et_pb_custom_css', true); $state = $style::capture_state();
            foreach (($state['styles'] ?? []) as $groups) { foreach ($groups as $rules) { $css .= $style::render_by_styles_data($rules, 'default') . $style::render_by_styles_data($rules, 'critical'); } }
            foreach (['get_global_colors_style', 'get_global_numeric_and_fonts_vars_style'] as $method) { if (is_callable([$style, $method])) { $css .= $style::$method(); } }
            if (RevisionaryBuilderCompare::javascriptEnabled()) { $data = $script::capture_state(); foreach (array_keys($data['script_data'] ?? []) as $name) { $script::enqueue_data($name); } }
            $settings = [];
            foreach (get_post_meta($post->ID) as $key => $values) { if (0 === strpos($key, '_et_pb_') && !preg_match('/cache|static_css|last_edited/', $key)) { $settings[$key] = array_map('maybe_unserialize', $values); } }
            $nodes['__root__'] = ['label' => __('Page settings', 'revisionary-pro'), 'attributes' => $settings];
            return array_merge(RevisionaryBuilderCompare::document($html, $css, $nodes, RevisionaryBuilderCompare::styleUrls([]), 'et_divi_theme et_pb_pagebuilder_layout'), ['selector' => '[data-rvy-builder-id]', 'idAttribute' => 'data-rvy-builder-id', 'identity' => 'positional', 'ignoredAttributes' => ['content', 'Content'], 'signature' => md5(wp_json_encode([$post->post_content, $settings]))]);
        } finally {
            remove_filter('divi_module_wrapper_render', $capture, PHP_INT_MAX);
            $style::reset(); $style::restore_state($style_state); $script::restore_state($script_state); $parser::restore_state($parser_state); ET_Builder_Module_Order::restore_state($order_state);
        }
    }
};
