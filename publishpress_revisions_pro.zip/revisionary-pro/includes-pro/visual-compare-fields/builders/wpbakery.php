<?php
defined('ABSPATH') || exit;

return new class {
    public function available() { return defined('WPB_VC_VERSION') && function_exists('wpbakery'); }
    public function optInConstant() { return 'REVISIONARY_WPBAKERY_VISUAL_COMPARE'; }
    public function label() { return 'WPBakery'; }
    public function register() {
        add_filter('revisionary_compare_meta_from', static function ($meta) {
            // WPBakery compares both values in its Page settings canvas node.
            unset($meta['_wpb_post_custom_css'], $meta['_wpb_post_custom_layout']);
            return $meta;
        });
    }
    public function uses($post) { return 'true' === get_post_meta($post->ID, '_wpb_vc_js_status', true) || (bool) preg_match('/\[vc_[a-z_]+\b/', $post->post_content); }
    public function render($post) {
        if (!$this->uses($post)) { return RevisionaryBuilderCompare::plain($post); }
        if (class_exists('WPBMap')) { WPBMap::addAllMappedShortcodes(); }
        $nodes = [];
        $capture = static function ($output, $module, $attrs, $tag) use (&$nodes) {
            $id = 'vc-' . count($nodes);
            $title = is_callable([$module, 'settings']) ? $module->settings('name') : $tag;
            $nodes[$id] = ['label' => wp_strip_all_tags($title ?: $tag), 'type' => $tag, 'attributes' => (array) $attrs];
            return RevisionaryBuilderCompare::annotate($output, $id);
        };
        add_filter('vc_shortcode_output', $capture, PHP_INT_MAX, 4);
        try {
            $html = do_shortcode(shortcode_unautop($post->post_content));
            $css = (string) get_post_meta($post->ID, '_wpb_post_custom_css', true); $builder = wpbakery();
            if (is_callable([$builder, 'parseShortcodesCss'])) { foreach (['default', 'custom'] as $type) { $css .= $builder->parseShortcodesCss($post->post_content, $type); } }
            elseif (is_callable([$builder, 'parseShortcodesCustomCss'])) { $css .= $builder->parseShortcodesCustomCss($post->post_content); }
            foreach (['_wpb_post_custom_css', '_wpb_post_custom_layout'] as $key) { $nodes['__root__']['attributes'][$key] = get_post_meta($post->ID, $key, true); }
            $nodes['__root__']['label'] = __('Page settings', 'revisionary-pro');
            return array_merge(RevisionaryBuilderCompare::document($html, $css, $nodes, RevisionaryBuilderCompare::styleUrls(['js_composer_front']), 'wpb-js-composer'), ['selector' => '[data-rvy-builder-id]', 'idAttribute' => 'data-rvy-builder-id', 'identity' => 'positional', 'signature' => md5(wp_json_encode([$post->post_content, $nodes['__root__']['attributes']]))]);
        } finally { remove_filter('vc_shortcode_output', $capture, PHP_INT_MAX); }
    }
};
