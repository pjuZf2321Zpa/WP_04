<?php
defined('ABSPATH') || exit;

return new class {
    public function available() { return defined('AVADA_VERSION') && function_exists('Fusion_App') && shortcode_exists('fusion_builder_container'); }
    public function optInConstant() { return 'REVISIONARY_AVADA_VISUAL_COMPARE'; }
    public function label() { return 'Avada Builder'; }
    public function uses($post) { return 'active' === get_post_meta($post->ID, 'fusion_builder_status', true) || (bool) preg_match('/\[fusion_[a-z_]+\b/', $post->post_content); }
    public function register() {
        add_filter('revisionary_compare_meta_from', static function ($meta) {
            // Page options and custom CSS are compared in the canvas root.
            unset($meta['_fusion'], $meta['_fusion_builder_custom_css'], $meta['fusion_builder_status'], $meta['_fusion_google_fonts']);
            return $meta;
        });
    }
    public function render($post) {
        if (!$this->uses($post)) { return RevisionaryBuilderCompare::plain($post); }
        $nodes = [];
        $capture = static function ($output, $tag, $attrs, $match) use (&$nodes) {
            if (0 !== strpos($tag, 'fusion_')) { return $output; }
            $id = 'avada-' . count($nodes);
            $attributes = (array) $attrs;
            if (!empty($match[5]) && false === strpos($match[5], '[fusion_')) { $attributes['content'] = $match[5]; }
            $nodes[$id] = ['label' => ucwords(str_replace('_', ' ', preg_replace('/^fusion_(?:builder_)?/', '', $tag))), 'type' => $tag, 'attributes' => $attributes];
            return RevisionaryBuilderCompare::annotate($output, $id);
        };
        add_filter('do_shortcode_tag', $capture, PHP_INT_MAX, 4);
        try {
            $html = do_shortcode(shortcode_unautop($post->post_content));
            $css = (string) get_post_meta($post->ID, '_fusion_builder_custom_css', true);
            $nodes['__root__'] = ['label' => __('Page settings', 'revisionary-pro'), 'attributes' => ['options' => get_post_meta($post->ID, '_fusion', true), 'css' => $css]];
            return array_merge(RevisionaryBuilderCompare::document($html, $css, $nodes, [], 'fusion-body avada'), ['selector' => '[data-rvy-builder-id]', 'idAttribute' => 'data-rvy-builder-id', 'identity' => 'positional', 'signature' => md5(wp_json_encode([$post->post_content, $nodes]))]);
        } finally { remove_filter('do_shortcode_tag', $capture, PHP_INT_MAX); }
    }
};
