<?php
defined('ABSPATH') || exit;

return ['complianz' => ['label' => 'Complianz', 'classifications' => ['_cmplz_scanned_post' => 'internal']]];
