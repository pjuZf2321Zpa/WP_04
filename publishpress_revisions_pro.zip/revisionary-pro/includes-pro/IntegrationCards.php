<?php
defined('ABSPATH') || exit;

/**
 * Adds Visual Compare field providers to the Integrations settings screen.
 */
class RevisionaryProIntegrationCards
{
    public static function filter($integrations)
    {
        $integrations = array_values((array) $integrations);

        foreach ($integrations as &$integration) {
            if (empty($integration['id'])) {
                continue;
            }

            if (in_array($integration['id'], ['beaver_compatibility', 'elementor_compatibility'], true)) {


            } elseif ('planner_compatibility' === $integration['id']) {
                self::addCategory($integration, 'fields');
                self::addFeature($integration, esc_html__('Revise custom fields and display changes', 'revisionary-pro'));
            } elseif ('woocommerce_compatibility' === $integration['id']) {
                self::addCategory($integration, 'fields');
                self::addFeature($integration, esc_html__('Revise custom fields and display changes', 'revisionary-pro'));
            } elseif ('yoast_seo_compatibility' === $integration['id']) {
                self::addCategory($integration, 'fields');
                self::addFeature($integration, esc_html__('Revise custom fields and display changes', 'revisionary-pro'));
            }
        }
        unset($integration);

        foreach (self::pluginCards() as $card) {
            if (self::cardExcluded($card['id'])) {
                continue;
            }

            $integrations[] = self::fieldCard($card);
        }

        foreach (self::cacheCards() as $card) {
            $integrations[] = self::cacheCard($card);
        }

        foreach (self::themeCards() as $card) {
            if (self::cardExcluded($card['id'])) {
                continue;
            }

            $integrations[] = self::fieldCard($card, true);
        }

        return $integrations;
    }

    /**
     * Providers whose field definitions remain available for comparison, but
     * whose editing or persistence workflow is not safe to advertise as fully
     * compatible with Revisionary's end-to-end revision lifecycle.
     */
    private static function cardExcluded($integrationId)
    {
        $excluded = [
            // Uses a dedicated form editor and a post type Revisionary hides.
            'contact_form_7_field_compatibility',

            // Uses a dedicated slide editor and related ml-slide entities.
            'metaslider_field_compatibility',

            // Gallery state is primarily maintained in proprietary tables.
            'nextgen_gallery_field_compatibility',

            // Custom block styles use the plugin's stackable_temp_post store.
            'stackable_field_compatibility',
            // These plugins are represented by their block integration cards.
            'spectra_field_compatibility',
            'publishpress_blocks_field_compatibility',

            // Expiration changes require PublishPress Future to reschedule its
            // separate action; Revisionary currently disables this editor UI.
            'publishpress_future_field_compatibility',

            // The theme routes page and template editing through Pagelayer,
            // for which Revisionary does not provide an editor integration.
            'theme_popularfx_field_compatibility',
        ];

        return in_array($integrationId, $excluded, true);
    }

    private static function addCategory(&$integration, $category)
    {
        $integration['categories'] = array_values(array_unique(array_merge(
            (array) ($integration['categories'] ?? []),
            [$category]
        )));
    }

    private static function addFeature(&$integration, $feature)
    {
        $integration['features'] = (array) ($integration['features'] ?? []);
        if (!in_array($feature, $integration['features'], true)) {
            $integration['features'][] = $feature;
        }
    }

    private static function fieldCard($card, $theme = false)
    {
        $title = $card['title'];
        $features = [
            esc_html__('Revise and compare custom fields', 'revisionary-pro'),
            esc_html__('Display custom field changes', 'revisionary-pro'),
            esc_html__('Update custom fields on revision publication', 'revisionary-pro'),
        ];

        if (!empty($card['features'])) {
            $features = $card['features'];
        }

        return [
            'id' => $card['id'],
            'title' => $title,
            'description' => !empty($card['description'])
                ? $card['description']
                : ($theme
                    ? sprintf(esc_html__('Compatibility with %s theme custom fields.', 'revisionary-pro'), $title)
                    : sprintf(esc_html__('Compatibility with %s custom fields.', 'revisionary-pro'), $title)),
            'icon_class' => $theme ? 'remote theme' : (!empty($card['icon_class']) ? $card['icon_class'] : 'remote'),
            'icon_url' => $card['icon_url'] ?? '',
            'categories' => array_values(array_unique(array_merge(
                $theme ? ['all'] : ['all', 'fields'],
                (array) ($card['categories'] ?? [])
            ))),
            'features' => $features,
            'enabled' => false,
            'available' => $theme
                ? self::themeActive($card['slug'])
                : self::pluginActive(
                    $card['plugin'],
                    $card['constant'] ?? '',
                    $card['function'] ?? '',
                    $card['class'] ?? ''
                ),
            'learn_more_url' => $card['learn_more_url'] ?? '',
            'free' => false,
        ];
    }

    private static function cacheCard($card)
    {
        $title = $card['title'];
        $description = preg_match('/cache$/i', wp_strip_all_tags($title))
            ? sprintf(esc_html__('Compatibility with %s.', 'revisionary-pro'), $title)
            : sprintf(esc_html__('Compatibility with %s cache.', 'revisionary-pro'), $title);

        return [
            'id' => $card['id'],
            'title' => $title,
            'description' => $description,
            'icon_class' => $card['icon_class'] ?? 'remote',
            'icon_url' => $card['icon_url'] ?? '',
            'categories' => ['all', 'cache'],
            'features' => [
                esc_html__('Clear cache on revision publication', 'revisionary-pro'),
                esc_html__('Support immediate and scheduled publication', 'revisionary-pro'),
            ],
            'enabled' => false,
            'available' => self::pluginActive(
                $card['plugin'],
                $card['constant'] ?? '',
                $card['function'] ?? '',
                $card['class'] ?? ''
            ),
            'learn_more_url' => $card['learn_more_url'] ?? '',
            'free' => false,
        ];
    }

    private static function cacheCards()
    {
        return [
            ['id' => 'litespeed_compatibility', 'title' => esc_html__('LiteSpeed Cache', 'revisionary-pro'), 'plugin' => 'litespeed-cache/litespeed-cache.php', 'constant' => 'LSCWP_V', 'icon_url' => 'https://ps.w.org/litespeed-cache/assets/icon-128x128.png'],
            ['id' => 'wp_fastest_cache_compatibility', 'title' => esc_html__('WP Fastest Cache', 'revisionary-pro'), 'plugin' => 'wp-fastest-cache/wpFastestCache.php', 'function' => 'wpfc_clear_post_cache_by_id', 'icon_url' => 'https://ps.w.org/wp-fastest-cache/assets/icon-128x128.png'],
            ['id' => 'wp_super_cache_compatibility', 'title' => esc_html__('WP Super Cache', 'revisionary-pro'), 'plugin' => 'wp-super-cache/wp-cache.php', 'function' => 'wp_cache_post_change', 'icon_url' => 'https://ps.w.org/wp-super-cache/assets/icon-128x128.png'],
            ['id' => 'wp_optimize_cache_compatibility', 'title' => esc_html__('WP-Optimize', 'revisionary-pro'), 'plugin' => 'wp-optimize/wp-optimize.php', 'constant' => 'WPO_VERSION', 'icon_url' => 'https://ps.w.org/wp-optimize/assets/icon-128x128.png'],
            ['id' => 'w3_total_cache_compatibility', 'title' => esc_html__('W3 Total Cache', 'revisionary-pro'), 'plugin' => 'w3-total-cache/w3-total-cache.php', 'constant' => 'W3TC_VERSION', 'icon_url' => 'https://ps.w.org/w3-total-cache/assets/icon-128x128.png'],
            ['id' => 'breeze_cache_compatibility', 'title' => esc_html__('Breeze', 'revisionary-pro'), 'plugin' => 'breeze/breeze.php', 'constant' => 'BREEZE_VERSION', 'icon_url' => 'https://ps.w.org/breeze/assets/icon-128x128.png'],
            ['id' => 'speedycache_compatibility', 'title' => esc_html__('SpeedyCache', 'revisionary-pro'), 'plugin' => 'speedycache/speedycache.php', 'constant' => 'SPEEDYCACHE_VERSION', 'icon_url' => 'https://ps.w.org/speedycache/assets/icon-128x128.png'],
        ];
    }

    private static function pluginCards()
    {
        return [
            [
                'id' => 'publishpress_cart_field_compatibility',
                'title' => esc_html__('PublishPress Cart', 'revisionary-pro'),
                'plugin' => 'publishpress-cart/publishpress-cart.php',
                'constant' => 'PPCART_VERSION',
                'icon_class' => 'publishpress-cart',
                'categories' => ['ecommerce'],
                'description' => esc_html__('Revision submission and approval for products.', 'revisionary-pro'),
                'features' => [
                    esc_html__('Product revisions', 'revisionary-pro'),
                    esc_html__('Priority on ongoing compatibility', 'revisionary-pro'),
                    esc_html__('Revise custom fields and display changes', 'revisionary-pro'),
                ],
            ],
            ['id' => 'cptui_field_compatibility', 'title' => esc_html__('Custom Post Type UI', 'revisionary-pro'), 'plugin' => 'custom-post-type-ui/custom-post-type-ui.php', 'constant' => 'CPTUI_VERSION', 'function' => 'cptui_get_post_type_data', 'icon_url' => 'https://ps.w.org/custom-post-type-ui/assets/icon-128x128.png?rev=2744389'],
            ['id' => 'contact_form_7_field_compatibility', 'title' => esc_html__('Contact Form 7', 'revisionary-pro'), 'plugin' => 'contact-form-7/wp-contact-form-7.php', 'constant' => 'WPCF7_VERSION', 'categories' => ['form'], 'icon_url' => 'https://ps.w.org/contact-form-7/assets/icon.svg?rev=2339255'],
            ['id' => 'site_kit_field_compatibility', 'title' => esc_html__('Site Kit by Google', 'revisionary-pro'), 'plugin' => 'google-site-kit/google-site-kit.php', 'constant' => 'GOOGLESITEKIT_VERSION', 'icon_url' => 'https://ps.w.org/google-site-kit/assets/icon-128x128.png?rev=3606666'],
            ['id' => 'rank_math_field_compatibility', 'title' => esc_html__('Rank Math SEO', 'revisionary-pro'), 'plugin' => 'seo-by-rank-math/rank-math.php', 'constant' => 'RANK_MATH_VERSION', 'categories' => ['seo'], 'icon_url' => 'https://ps.w.org/seo-by-rank-math/assets/icon.svg?rev=3438330'],
            ['id' => 'jetpack_field_compatibility', 'title' => esc_html__('Jetpack', 'revisionary-pro'), 'plugin' => 'jetpack/jetpack.php', 'constant' => 'JETPACK__VERSION', 'icon_url' => 'https://ps.w.org/jetpack/assets/icon.svg?rev=2819237'],
            ['id' => 'essential_addons_elementor_field_compatibility', 'title' => esc_html__('Essential Addons for Elementor', 'revisionary-pro'), 'plugin' => 'essential-addons-for-elementor-lite/essential_adons_elementor.php', 'constant' => 'EAEL_PLUGIN_VERSION', 'categories' => ['builder'], 'icon_url' => 'https://ps.w.org/essential-addons-for-elementor-lite/assets/icon-128x128.gif?rev=3182943'],
            ['id' => 'stackable_field_compatibility', 'title' => esc_html__('Stackable', 'revisionary-pro'), 'plugin' => 'stackable-ultimate-gutenberg-blocks/plugin.php', 'constant' => 'STACKABLE_VERSION', 'categories' => ['builder'], 'icon_url' => 'https://ps.w.org/stackable-ultimate-gutenberg-blocks/assets/icon-128x128.png?rev=2749547'],
            ['id' => 'spectra_field_compatibility', 'title' => esc_html__('Spectra Legacy', 'revisionary-pro'), 'plugin' => 'ultimate-addons-for-gutenberg/ultimate-addons-for-gutenberg.php', 'constant' => 'UAGB_VER', 'categories' => ['builder'], 'icon_url' => 'https://ps.w.org/ultimate-addons-for-gutenberg/assets/icon-128x128.gif?rev=3240412'],
            ['id' => 'premium_addons_elementor_field_compatibility', 'title' => esc_html__('Premium Addons for Elementor', 'revisionary-pro'), 'plugin' => 'premium-addons-for-elementor/premium-addons-for-elementor.php', 'constant' => 'PREMIUM_ADDONS_VERSION', 'categories' => ['builder'], 'icon_url' => 'https://ps.w.org/premium-addons-for-elementor/assets/icon.svg?rev=3705658'],
            ['id' => 'events_calendar_field_compatibility', 'title' => esc_html__('The Events Calendar', 'revisionary-pro'), 'plugin' => 'the-events-calendar/the-events-calendar.php', 'class' => 'Tribe__Events__Main', 'icon_url' => 'https://ps.w.org/the-events-calendar/assets/icon-128x128.gif?rev=2516440'],
            ['id' => 'page_links_to_field_compatibility', 'title' => esc_html__('Page Links To', 'revisionary-pro'), 'plugin' => 'page-links-to/page-links-to.php', 'class' => 'CWS_PageLinksTo', 'icon_url' => 'https://s.w.org/plugins/geopattern-icon/page-links-to_fafafa.svg'],
            ['id' => 'taxopress_field_compatibility', 'title' => esc_html__('TaxoPress', 'revisionary-pro'), 'plugin' => 'simple-tags/simple-tags.php', 'constant' => 'STAGS_VERSION', 'icon_url' => 'https://ps.w.org/simple-tags/assets/icon-128x128.png?rev=2853049'],
            ['id' => 'publishpress_authors_field_compatibility', 'title' => esc_html__('PublishPress Authors', 'revisionary-pro'), 'plugin' => 'publishpress-authors/publishpress-authors.php', 'constant' => 'PP_AUTHORS_VERSION', 'categories' => ['workflow'], 'icon_url' => 'https://ps.w.org/publishpress-authors/assets/icon-128x128.png?rev=3391318'],
            ['id' => 'publishpress_future_field_compatibility', 'title' => esc_html__('PublishPress Future', 'revisionary-pro'), 'plugin' => 'post-expirator/post-expirator.php', 'constant' => 'PUBLISHPRESS_FUTURE_VERSION', 'categories' => ['workflow'], 'icon_url' => 'https://ps.w.org/post-expirator/assets/icon-128x128.png?rev=3569472'],
            ['id' => 'publishpress_blocks_field_compatibility', 'title' => esc_html__('PublishPress Blocks', 'revisionary-pro'), 'plugin' => 'advanced-gutenberg/advanced-gutenberg.php', 'constant' => 'ADVANCED_GUTENBERG_VERSION', 'categories' => ['builder'], 'icon_url' => 'https://ps.w.org/advanced-gutenberg/assets/icon-128x128.png?rev=3393761'],
            ['id' => 'metaslider_field_compatibility', 'title' => esc_html__('MetaSlider', 'revisionary-pro'), 'plugin' => 'ml-slider/ml-slider.php', 'constant' => 'METASLIDER_VERSION', 'categories' => ['slider'], 'icon_url' => 'https://ps.w.org/ml-slider/assets/icon.svg?rev=3646237'],
            ['id' => 'nextgen_gallery_field_compatibility', 'title' => esc_html__('NextGEN Gallery', 'revisionary-pro'), 'plugin' => 'nextgen-gallery/nggallery.php', 'constant' => 'NGG_PLUGIN_VERSION', 'icon_url' => 'https://ps.w.org/nextgen-gallery/assets/icon-128x128.png?rev=2083961'],
            ['id' => 'royal_addons_elementor_field_compatibility', 'title' => esc_html__('Royal Addons for Elementor', 'revisionary-pro'), 'plugin' => 'royal-elementor-addons/wpr-addons.php', 'constant' => 'WPR_ADDONS_VERSION', 'categories' => ['builder'], 'icon_url' => 'https://ps.w.org/royal-elementor-addons/assets/icon-128x128.gif?rev=2604295'],
            ['id' => 'ultimate_addons_elementor_field_compatibility', 'title' => esc_html__('Ultimate Addons for Elementor', 'revisionary-pro'), 'plugin' => 'header-footer-elementor/header-footer-elementor.php', 'constant' => 'HFE_VER', 'categories' => ['builder'], 'icon_url' => 'https://ps.w.org/header-footer-elementor/assets/icon-128x128.gif?rev=3278750'],
        ];
    }

    private static function themeCards()
    {
        $themes = [
            'astra' => ['Astra', 'jpg'],
            'kadence' => ['Kadence', 'png'],
            'oceanwp' => ['OceanWP', 'png'],
            'blocksy' => ['Blocksy', 'jpg'],
            'generatepress' => ['GeneratePress', 'png'],
            'neve' => ['Neve', 'png'],
            'popularfx' => ['PopularFX', 'jpg'],
            'envo-royal' => ['Envo Royal', 'png'],
            'inspiro' => ['Inspiro', 'png'],
            'envo-one' => ['Envo One', 'png'],
            'lightning' => ['Lightning', 'jpg'],
            'hestia' => ['Hestia', 'png'],
            'go' => ['Go', 'png'],
            'sydney' => ['Sydney', 'png'],
            'bloghash' => ['BlogHash', 'jpg'],
        ];
        $cards = [];

        foreach ($themes as $slug => $theme) {
            $cards[] = [
                'id' => 'theme_' . str_replace('-', '_', $slug) . '_field_compatibility',
                'title' => esc_html($theme[0]),
                'slug' => $slug,
                'categories' => ['themes'],
                'icon_url' => sprintf('https://ts.w.org/wp-content/themes/%1$s/screenshot.%2$s', $slug, $theme[1]),
            ];
        }

        return $cards;
    }

    private static function pluginActive($plugin, $constant = '', $function = '', $class = '')
    {
        static $active_plugins = null;

        if (null === $active_plugins) {
            $active_plugins = array_fill_keys((array) get_option('active_plugins', []), true);
            if (is_multisite()) {
                $active_plugins += (array) get_site_option('active_sitewide_plugins', []);
            }
        }

        return isset($active_plugins[$plugin])
            || ($constant && defined($constant))
            || ($function && function_exists($function))
            || ($class && class_exists($class, false));
    }

    private static function themeActive($slug)
    {
        return in_array($slug, array_unique(array_filter([get_stylesheet(), get_template()])), true);
    }
}
