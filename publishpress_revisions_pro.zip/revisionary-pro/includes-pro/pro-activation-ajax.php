<?php
namespace PublishPress\Revisions;

\defined('ABSPATH') || exit;

require_once(REVISIONARY_PRO_ABSPATH . '/includes-pro/pro-maint.php');

if ('POST' !== ($_SERVER['REQUEST_METHOD'] ?? '')) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- Strict HTTP method comparison only; nonce and capability checks follow for each activation action.
    wp_die('Method not allowed.', '', ['response' => 405]);
}
nocache_headers();
header('Cache-Control: no-store, private');

$rvy_ajax_settings = isset($_POST['rvy_ajax_settings']) ? sanitize_key(wp_unslash($_POST['rvy_ajax_settings'])) : '';
$key = isset($_POST['key']) ? sanitize_text_field(wp_unslash($_POST['key'])) : '';

switch ($rvy_ajax_settings) {
    case 'activate_key':
        check_admin_referer('wp_ajax_pp_activate_key');
        if (
            is_multisite() && !is_super_admin() && (PWP::isNetworkActivated() || PWP::isMuPlugin())
        ) {
            return;
        }

        if (empty($key)) {
            return;
        }

        $request_vars = [
            'edd_action' => "activate_license",
            'item_id' => REVISIONARY_EDD_ITEM_ID,
            'license' => sanitize_text_field($key),
            'url' => site_url(''),
        ];

        $response = RevisionaryMaint::callHome('activate_license', $request_vars);

        $result = json_decode($response);
        if (is_object($result) && ('valid' == $result->license)) {
            $setting = ['license_status' => $result->license, 'license_key' => sanitize_text_field($key), 'expire_date' => $result->expires];
            revisionary()->updateOption('edd_key', $setting);
        }

        echo $response;                                     //phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        exit();

        break;

    case 'deactivate_key':
        check_admin_referer('wp_ajax_pp_deactivate_key');
        if (
            is_multisite() && !is_super_admin() && (PWP::isNetworkActivated() || PWP::isMuPlugin())
        ) {
            return;
        }

        $support_key = revisionary()->getOption('edd_key');
        $request_vars = [
            'edd_action' => "deactivate_license",
            'item_id' => REVISIONARY_EDD_ITEM_ID,
            'license' => $support_key['license_key'],
            'url' => site_url(''),
        ];

        $response = RevisionaryMaint::callHome('deactivate_license', $request_vars);

        $result = json_decode($response);
        if (is_object($result) && $result->license != 'valid') {
            revisionary()->deleteOption('edd_key');
        }

        echo $response;                                     //phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        exit();

        break;
}
