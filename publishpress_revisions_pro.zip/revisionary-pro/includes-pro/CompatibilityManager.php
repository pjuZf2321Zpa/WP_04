<?php
namespace PublishPress\Revisions;

\defined('ABSPATH') || exit;

class CompatibilityManager
{
    public function __construct()
    {
        add_action('init', [$this, 'registerIntegrations'], 5);
        add_action('init', [$this, 'loadEnabledIntegrations'], 10);
        add_action('wp_ajax_pp_toggle_integration', [$this, 'handleToggleIntegration']);
    }

    public function registerIntegrations()
    {
        $integrations = [
            [
                'id' => 'acf_compatibility',
                'title' => esc_html__('Advanced Custom Fields', 'revisionary-pro'),
                'description' => esc_html__('Compatibility with ACF custom fields.', 'revisionary-pro'),
                'icon_class' => 'acf',
                'categories' => ['all', 'fields'],
                'features' => [
                    esc_html__('Revise and compare custom fields', 'revisionary-pro'),
                    esc_html__('Display custom field changes', 'revisionary-pro'),
                    esc_html__('Update custom fields on revision publication', 'revisionary-pro'),
                ],
                'enabled' => false,
                'available' => function_exists('acf'),
                'learn_more_url' => 'https://publishpress.com/knowledge-base/acf-publishpress-revisions/'
            ],
            [
                'id' => 'acfe_compatibility',
                'title' => esc_html__('ACF Extended', 'revisionary-pro'),
                'description' => esc_html__('Support ACFE data model.', 'revisionary-pro'),
                'icon_class' => 'acf',
                'categories' => ['all', 'fields'],
                'features' => [
                    esc_html__('Support ACFE single_meta data type', 'revisionary-pro'),
                    esc_html__('Correct field display on Compare screen', 'revisionary-pro'),
                ],
                'enabled' => false,
                'available' => class_exists('ACFE'),
                'learn_more_url' => 'https://publishpress.com/knowledge-base/acfe-publishpress-revisions/'
            ],
            [
                'id' => 'beaver_compatibility',
                'title' => esc_html__('Beaver Builder', 'revisionary-pro'),
                'description' => esc_html__('Integration with Beaver Builder\'s front end editor.', 'revisionary-pro'),
                'icon_class' => 'beaver-builder',
                'categories' => ['all', 'builder'],
                'features' => [
                    esc_html__('Frontend revision editing, submission', 'revisionary-pro'),
                    esc_html__('Visually compare changes', 'revisionary-pro'),
                    esc_html__('Revision preview with builder styling', 'revisionary-pro'),
                ],
                'enabled' => false,
                'available' => defined('FL_BUILDER_VERSION'),
                'learn_more_url' => 'https://publishpress.com/knowledge-base/beaver-builder-publishpress-revisions/'
            ],
            [
                'id' => 'divi_compatibility',
                'title' => esc_html__('Divi', 'revisionary-pro'),
                'description' => esc_html__('Integration with Divi 4 Theme and Builder', 'revisionary-pro'),
                'icon_class' => 'divi',
                'categories' => ['all', 'builder'],
                'features' => [
                    esc_html__('Frontend revision editing, submission', 'revisionary-pro'),
                    esc_html__('Visually compare changes', 'revisionary-pro'),
                    esc_html__('Revision preview with builder styling', 'revisionary-pro'),
                ],
                'enabled' => false,
                'available' => defined('ET_BUILDER_PLUGIN_VERSION') || (false !== stripos(get_template(), 'divi')),
                'learn_more_url' => 'https://publishpress.com/knowledge-base/divi-publishpress-revisions/',
            ],
            [
                'id' => 'elementor_compatibility',
                'title' => esc_html__('Elementor', 'revisionary-pro'),
                'description' => esc_html__('Integration with Elementor\'s front end editor.', 'revisionary-pro'),
                'icon_class' => 'elementor',
                'categories' => ['all', 'builder'],
                'features' => [
                    esc_html__('Frontend revision editing, submission', 'revisionary-pro'),
                    esc_html__('Visually compare changes', 'revisionary-pro'),
                    esc_html__('Revision preview with builder styling', 'revisionary-pro'),
                ],
                'enabled' => false,
                'available' => defined('ELEMENTOR_VERSION'),
                'learn_more_url' => 'https://publishpress.com/knowledge-base/elementor-publishpress-revisions/',
            ],
            [
                'id' => 'nitropack_compatibility',
                'title' => esc_html__('Nitro Pack', 'revisionary-pro'),
                'description' => esc_html__('Compatibility with Nitro Pack cache.', 'revisionary-pro'),
                'icon_class' => 'nitropack',
                'categories' => ['all', 'cache'],
                'features' => [
                    esc_html__('Clear cache on revision publication', 'revisionary-pro'),
                    esc_html__('Support immediate and scheduled publication', 'revisionary-pro'),
                ],
                'enabled' => false,
                'available' => defined('NITROPACK_VERSION'),
                'learn_more_url' => 'https://publishpress.com/knowledge-base/nitropack-publishpress-revisions/'
            ],
            [
                'id' => 'pods_compatibility',
                'title' => esc_html__('Pods', 'revisionary-pro'),
                'description' => esc_html__('Compatibility with Pods custom fields.', 'revisionary-pro'),
                'icon_class' => 'pods',
                'categories' => ['all', 'fields'],
                'features' => [
                    esc_html__('Revise and compare custom fields', 'revisionary-pro'),
                    esc_html__('Display custom field changes', 'revisionary-pro'),
                    esc_html__('Update custom fields on revision publication', 'revisionary-pro'),
                ],
                'enabled' => false,
                'available' => defined('PODS_VERSION'),
                'learn_more_url' => 'https://publishpress.com/knowledge-base/pods-publishpress-revisions/'
            ],
            [
                'id' => 'polylang_compatibility',
                'title' => esc_html__('Polylang', 'revisionary-pro'),
                'description' => esc_html__('Compatibility with Polylang translation.', 'revisionary-pro'),
                'icon_class' => 'polylang',
                'categories' => ['all', 'multilingual'],
                'features' => [
                    esc_html__('Revisions carry over Polylang data', 'revisionary-pro'),
                    esc_html__('Translation retained on Revision approval', 'revisionary-pro'),
                ],
                'enabled' => false,
                'available' => defined('POLYLANG_VERSION'),
                'learn_more_url' => 'https://publishpress.com/knowledge-base/polylang-publishpress-revisions/'
            ],
            [
                'id' => 'planner_compatibility',
                'title' => esc_html__('PublishPress Planner', 'revisionary-pro'),
                'description' => esc_html__('PublishPress Planner Integration.', 'revisionary-pro'),
                'icon_class' => 'planner',
                'categories' => ['all'],
                'features' => [
                    esc_html__('Planner Notifications for revision actions', 'revisionary-pro'),
                    esc_html__('Revision schedule shown in Calendar', 'revisionary-pro'),
                ],
                'enabled' => false,
                'available' => defined('PUBLISHPRESS_VERSION'),
                'learn_more_url' => 'https://publishpress.com/knowledge-base/planner-publishpress-revisions/'
            ],
            [
                'id' => 'woocommerce_compatibility',
                'title' => esc_html__('WooCommerce', 'revisionary-pro'),
                'description' => esc_html__('Advanced permissions for products, orders, and customer data.', 'revisionary-pro'),
                'icon_class' => 'woocommerce',
                'categories' => ['all', 'ecommerce'],
                'features' => [
                    esc_html__('Product permissions', 'revisionary-pro'),
                    esc_html__('Order management controls', 'revisionary-pro'),
                    esc_html__('Customer data access', 'revisionary-pro')
                ],
                'enabled' => false,
                'available' => class_exists('WooCommerce'),
                'learn_more_url' => 'https://publishpress.com/knowledge-base/woocommerce-publishpress-permissions/'
            ],
            [
                'id' => 'wpml_compatibility',
                'title' => esc_html__('WPML', 'revisionary-pro'),
                'description' => esc_html__('Multilingual revisioning with WPML.', 'revisionary-pro'),
                'icon_class' => 'wpml',
                'categories' => ['all', 'multilingual'],
                'features' => [
                    esc_html__('Language-specific revisions', 'revisionary-pro'),
                    esc_html__('Translation Management integration', 'revisionary-pro')
                ],
                'enabled' => false,
                'available' => defined('ICL_SITEPRESS_VERSION'),
                'learn_more_url' => 'https://publishpress.com/knowledge-base/wpml-publishpress-revisions/'
            ],
            [
                'id' => 'yoast_seo_compatibility',
                'title' => esc_html__('Yoast SEO', 'revisionary-pro'),
                'description' => esc_html__('.', 'revisionary-pro'),
                'icon_class' => 'yoast',
                'categories' => ['all', 'seo'],
                'features' => [
                    esc_html__('Prevent indexing of revisions', 'revisionary-pro'),
                    esc_html__('Compatibility for Yoast SEO + Elementor', 'revisionary-pro'),
                    esc_html__('Compare revisions to Yoast SEO fields', 'revisionary-pro'),
                ],
                'enabled' => false,
                'available' => defined('WPSEO_VERSION'),
                'learn_more_url' => 'https://publishpress.com/knowledge-base/yoast-seo-publishpress-revisions/'
            ],
        ];

        ksort($integrations);

        foreach ($integrations as $integration_id => $args) {
            CompatibilityRegistry::register($integration_id, $args);
        }

        // Allow other plugins to register integrations
        do_action('revisionary_register_integrations');
    }

    public function loadEnabledIntegrations()
    {
        $enabled_integrations = get_option('revisionary_enabled_integrations', []);

        foreach ($enabled_integrations as $integration_id => $enabled) {
            if ($enabled && CompatibilityRegistry::isAvailable($integration_id)) {
                CompatibilityRegistry::enableIntegration($integration_id);
            }
        }
    }

    public function handleToggleIntegration()
    {
        check_ajax_referer('pp_toggle_integration', 'nonce');

        if (!current_user_can('pp_manage_settings')) {
            wp_die(esc_html__('Insufficient permissions', 'presspermit-pro'));
        }

        $integration_id = (isset($_POST['integration_id'])) ? sanitize_text_field(wp_unslash($_POST['integration_id'])) : 0;
        $enabled = !empty($_POST['enabled']);

        if ($enabled) {
            $success = CompatibilityRegistry::enableIntegration($integration_id);
        } else {
            $success = CompatibilityRegistry::disableIntegration($integration_id);
        }

        wp_send_json_success(['enabled' => $enabled, 'success' => $success]);
    }

    /**
     * Get available integrations for admin display
     */
    public function getAvailableIntegrations()
    {
        return CompatibilityRegistry::getIntegrations();
    }

    /**
     * Check if a specific integration is enabled and available
     */
    public function isIntegrationActive($integration_id)
    {
        return CompatibilityRegistry::isEnabled($integration_id) &&
            CompatibilityRegistry::isAvailable($integration_id);
    }

    /**
     * Get integration statistics for admin dashboard
     */
    public function getIntegrationStats()
    {
        $integrations = CompatibilityRegistry::getIntegrations();
        $stats = [
            'total' => count($integrations),
            'enabled' => 0,
            'available' => 0,
            'active' => 0
        ];

        foreach ($integrations as $integration) {
            if ($integration['available']) {
                $stats['available']++;
            }
            if ($integration['enabled']) {
                $stats['enabled']++;
            }
            if ($integration['enabled'] && $integration['available']) {
                $stats['active']++;
            }
        }

        return $stats;
    }
}
