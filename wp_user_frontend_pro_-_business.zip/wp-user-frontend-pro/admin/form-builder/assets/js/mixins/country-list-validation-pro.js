;(function($) {
    'use strict';

    /**
     * Country List Validation Mixin
     * 
     * Validates that country list is filled when using "Hide these" or "Only show" modes
     * Used by both field-country-list and field-address components
     * 
     * @since 4.2.2
     */
    window.mixin_country_list_validation_pro = {
        computed: {
            has_validation_error: function () {
                var visibility = this.active_visibility;
                var show_list = this.get_country_show_list();
                var hide_list = this.get_country_hide_list();

                // Show error only if list is empty when using "show" or "hide" modes
                if ('show' === visibility && !show_list.length) {
                    return true;
                }
                if ('hide' === visibility && !hide_list.length) {
                    return true;
                }

                return false;
            },

            validation_error_message: function () {
                var visibility = this.active_visibility;
                var show_list = this.get_country_show_list();
                var hide_list = this.get_country_hide_list();

                if ('show' === visibility && !show_list.length) {
                    return '⚠️ Please select at least one country';
                }

                if ('hide' === visibility && !hide_list.length) {
                    return '⚠️ Please select at least one country';
                }

                return '';
            }
        },

        methods: {
            /**
             * Get country show list - must be implemented by component
             * 
             * @returns {array}
             */
            get_country_show_list: function () {
                throw new Error('get_country_show_list() must be implemented by component');
            },

            /**
             * Get country hide list - must be implemented by component
             * 
             * @returns {array}
             */
            get_country_hide_list: function () {
                throw new Error('get_country_hide_list() must be implemented by component');
            }
        }
    };
})(jQuery);
