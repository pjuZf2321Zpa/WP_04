<div class="wpuf-fields">
    <template v-if="!is_rs_captcha_active">
        <p v-html="no_plugin_msg"></p>
    </template>

    <template v-else>
        <div class="wpuf-flex">
            <div class="wpuf-w-1/4">
            <img class="wpuf-rs-captcha-placeholder" src="<?php echo WPUF_PRO_ASSET_URI . '/images/really-simple-captcha-placeholder.png' ?>" alt="">
            </div>
            <div class="wpuf-w-3/4">
            <input
                type="text"
                :class="builder_class_names('text')">
            </div>
        </div>
    </template>
</div>
