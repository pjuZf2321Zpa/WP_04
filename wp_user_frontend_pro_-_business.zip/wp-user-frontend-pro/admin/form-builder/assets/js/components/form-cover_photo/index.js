/**
 * Field template: Cover Photo
 */
Vue.component('form-cover_photo', {
    template: '#tmpl-wpuf-form-cover_photo',

    mixins: [
        wpuf_mixins.form_field_mixin
    ]
});

