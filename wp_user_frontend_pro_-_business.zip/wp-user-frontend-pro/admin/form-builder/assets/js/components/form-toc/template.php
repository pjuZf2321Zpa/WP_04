<div class="wpuf-toc-container wpuf-fields wpuf-flex wpuf-items-center !wpuf-w-full">
    <input v-if="field.show_checkbox" type="checkbox" :class="builder_class_names('checkbox')" class="!wpuf-mr-2">
    <div class="wpuf-toc-description" v-html="content"></div>
</div>

