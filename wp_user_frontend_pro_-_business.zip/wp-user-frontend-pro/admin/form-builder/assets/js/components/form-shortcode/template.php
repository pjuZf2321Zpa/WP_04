<div class="wpuf-flex wpuf-items-center">
    <div class="wpuf-fields" v-html="field.shortcode"></div>
</div>
