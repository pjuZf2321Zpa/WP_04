<div class="wpuf-fields">
    <div class="wpuf-cart-total-display" style="font-size: 18px; font-weight: bold; padding: 15px; background: #f9f9f9; border: 1px solid #e0e0e0; border-radius: 4px;">
        <span class="wpuf-cart-total-label">{{ field.label }}:</span>
        <span class="wpuf-cart-total-amount">0.00</span>
    </div>
    <span v-if="field.help" class="wpuf-help" v-html="field.help" />
</div>