Vue.component('form-cart_total', {
    template: '#tmpl-wpuf-form-cart_total',

    mixins: [
        wpuf_mixins.form_field_mixin
    ]
});