Vue.component('form-price_field', {
    template: '#tmpl-wpuf-form-price_field',

    mixins: [
        wpuf_mixins.form_field_mixin
    ]
});