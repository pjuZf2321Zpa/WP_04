<div class="wpuf-fields">
    <input
        type="number"
        step="0.01"
        :class="builder_class_names('textfield')"
        :placeholder="field.placeholder"
        :value="field.default"
        :readonly="field.price_input_mode === 'fixed'"
    >
    <span v-if="field.help" class="wpuf-help" v-html="field.help" />
</div>