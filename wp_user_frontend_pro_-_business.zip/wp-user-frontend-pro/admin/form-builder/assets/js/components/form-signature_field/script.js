/**
 * Load the signature field component
 */
(function($) {
    'use strict';

    // The Vue component is already loaded via wpuf-form-builder-components-pro.js
    // This file can be used for additional signature field specific JavaScript if needed

})(jQuery);