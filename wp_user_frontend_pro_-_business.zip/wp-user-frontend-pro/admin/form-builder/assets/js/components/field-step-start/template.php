<div class="panel-field-opt panel-field-opt-multi-step">
    <div class="panel-field-opt panel-field-opt-text">
        <div class="wpuf-flex">
            <label
                class="wpuf-option-field-title wpuf-font-sm wpuf-text-gray-700 wpuf-font-medium">
                <?php _e( 'Section Name', 'wpuf-pro' ); ?>
                <help-text text="<?php _e( 'Title', 'wpuf-pro' ); ?>"></help-text>
            </label>
        </div>
        <input
            type="text"
            v-model="editing_form_field.label"
            :class="builder_class_names('text')">
    </div>

    <div class="panel-field-opt panel-field-opt-text">
        <div class="wpuf-flex">
            <label
                class="wpuf-option-field-title wpuf-font-sm wpuf-text-gray-700 wpuf-font-medium">
                <?php _e( 'Previous Button Text', 'wpuf-pro' ); ?>
                <help-text text="<?php _e( 'Previous Button Text', 'wpuf-pro' ); ?>"></help-text>
            </label>
        </div>
        <input
            type="text"
            v-model="editing_form_field.step_start.prev_button_text"
            :class="builder_class_names('text')">
    </div>

    <div class="panel-field-opt panel-field-opt-text">
        <div class="wpuf-flex">
            <label
                class="wpuf-option-field-title wpuf-font-sm wpuf-text-gray-700 wpuf-font-medium">
            <?php _e( 'Next Button Text', 'wpuf-pro' ); ?> <help-text text="<?php _e( 'Next Button Text', 'wpuf-pro' ); ?>"></help-text>
        </label>
        </div>
        <input
            type="text"
            v-model="editing_form_field.step_start.next_button_text"
            :class="builder_class_names('text')">
    </div>
</div>
