<div class="wpuf-fields">
    <select
        :class="builder_class_names('dropdown')">
        <option v-if="field.first" value="">{{ field.first }}</option>
        <option value="male"><?php esc_html_e( 'Male', 'wpuf-pro' ); ?></option>
        <option value="female"><?php esc_html_e( 'Female', 'wpuf-pro' ); ?></option>
        <option value="non_binary"><?php esc_html_e( 'Non-binary', 'wpuf-pro' ); ?></option>
        <option value="prefer_not_say"><?php esc_html_e( 'Prefer not to say', 'wpuf-pro' ); ?></option>
    </select>
    <p v-if="field.help" class="wpuf-mt-2 wpuf-mb-0 wpuf-text-sm wpuf-text-gray-500" v-html="field.help"></p>
</div>
