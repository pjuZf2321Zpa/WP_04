/**
 * Field template: Gender
 */
Vue.component('form-gender_field', {
    template: '#tmpl-wpuf-form-gender_field',

    mixins: [
        wpuf_mixins.form_field_mixin
    ]
});
