<div class="wpuf-fields">
    <input
        type="url"
        :class="builder_class_names('url')"
    >
    <span v-if="field.help" class="wpuf-help" v-html="field.help" />
</div>
