/**
 * Field template: LinkedIn URL
 */
Vue.component('form-linkedin_url', {
    template: '#tmpl-wpuf-form-linkedin_url',

    mixins: [
        wpuf_mixins.form_field_mixin
    ]
});