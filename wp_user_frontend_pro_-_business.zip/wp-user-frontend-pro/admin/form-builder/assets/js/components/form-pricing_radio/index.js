Vue.component('form-pricing_radio', {
    template: '#tmpl-wpuf-form-pricing_radio',

    mixins: [
        wpuf_mixins.form_field_mixin
    ]
});