Vue.component('form-pricing_checkbox', {
    template: '#tmpl-wpuf-form-pricing_checkbox',

    mixins: [
        wpuf_mixins.form_field_mixin
    ]
});