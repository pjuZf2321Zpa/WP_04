Vue.component('form-pricing_multiselect', {
    template: '#tmpl-wpuf-form-pricing_multiselect',

    mixins: [
        wpuf_mixins.form_field_mixin
    ]
});