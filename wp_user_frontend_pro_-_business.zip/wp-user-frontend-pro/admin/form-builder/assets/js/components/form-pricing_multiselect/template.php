<div class="wpuf-fields">
    <select :class="builder_class_names('select')" multiple style="height: 150px;">
        <option v-if="has_options" v-for="(option, key) in field.options" :key="key" :value="key" :selected="is_selected(key)">
            {{ option }}<template v-if="field.prices && field.prices[key]"> - {{ format_price(field.prices[key]) }}</template>
        </option>
    </select>
    <span v-if="field.help" class="wpuf-help" v-html="field.help" />
</div>