/**
 * Field template: Date of Birth
 */
Vue.component('form-date_of_birth_field', {
    template: '#tmpl-wpuf-form-date_of_birth_field',

    mixins: [
        wpuf_mixins.form_field_mixin
    ]
});
