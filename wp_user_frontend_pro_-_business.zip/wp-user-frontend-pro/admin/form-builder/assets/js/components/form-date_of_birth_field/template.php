<div class="wpuf-fields">
    <input
        type="text"
        :class="builder_class_names('textfield')"
        :placeholder="field.format"
        :value="field.default"
        :size="field.size"
    >
    <!-- Death Date preview in builder -->
    <div v-if="field.show_death_date === 'yes'" style="margin-top: 12px;">
        <label style="font-weight: 600; display: block; margin-bottom: 4px;">
            <?php esc_html_e( 'Death Date', 'wpuf-pro' ); ?>
        </label>
        <input
            type="text"
            :class="builder_class_names('textfield')"
            :placeholder="field.format"
            :size="field.size"
            disabled
        >
    </div>
    <span v-if="field.help" class="wpuf-help" v-html="field.help" />
</div>
