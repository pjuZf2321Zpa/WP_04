/**
 * Field template: Secondary Email
 */
Vue.component('form-secondary_email', {
    template: '#tmpl-wpuf-form-secondary_email',

    mixins: [
        wpuf_mixins.form_field_mixin
    ]
});
