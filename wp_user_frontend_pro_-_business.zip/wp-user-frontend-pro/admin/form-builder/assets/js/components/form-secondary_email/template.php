<div class="wpuf-fields">
    <input
        type="email"
        :class="builder_class_names('textfield')"
        :placeholder="field.placeholder"
        :value="field.default"
        :size="field.size"
        :readonly="field.read_only === 'yes'"
    >
    <span v-if="field.help" class="wpuf-help" v-html="field.help" />
</div>
