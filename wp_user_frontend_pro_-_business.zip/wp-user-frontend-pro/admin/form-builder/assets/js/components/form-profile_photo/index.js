/**
 * Field template: Profile Photo
 */
Vue.component('form-profile_photo', {
    template: '#tmpl-wpuf-form-profile_photo',

    mixins: [
        wpuf_mixins.form_field_mixin
    ]
});
