<div class="wpuf-fields">
    <!-- Icon next to label if enabled -->
    <div class="wpuf-social-input-wrapper" :class="field.width ? 'wpuf-' + field.width : 'wpuf-medium'">
        <input
            type="url"
            :class="builder_class_names('url')"
            :placeholder="field.placeholder"
            :value="field.default"
            :size="field.size"
        >
    </div>
    <span v-if="field.help" class="wpuf-help" v-html="field.help" />
</div>