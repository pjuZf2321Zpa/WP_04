/**
 * Field template: Facebook URL
 */
Vue.component('form-facebook_url', {
    template: '#tmpl-wpuf-form-facebook_url',

    mixins: [
        wpuf_mixins.form_field_mixin
    ]
});
