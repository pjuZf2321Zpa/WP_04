Vue.component('form-pricing_dropdown', {
    template: '#tmpl-wpuf-form-pricing_dropdown',

    mixins: [
        wpuf_mixins.form_field_mixin
    ]
});