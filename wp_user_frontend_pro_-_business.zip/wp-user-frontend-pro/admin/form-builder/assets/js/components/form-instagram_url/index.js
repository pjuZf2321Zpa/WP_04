/**
 * Field template: Instagram URL
 */
Vue.component('form-instagram_url', {
    template: '#tmpl-wpuf-form-instagram_url',

    mixins: [
        wpuf_mixins.form_field_mixin
    ]
});