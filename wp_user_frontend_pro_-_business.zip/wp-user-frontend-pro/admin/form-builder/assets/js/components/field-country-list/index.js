Vue.component('field-country-list', {
    template: '#tmpl-wpuf-field-country-list',

    mixins: [
        wpuf_mixins.option_field_mixin,
        mixin_country_list_validation_pro,
    ],

    data: function () {
        return {
            default_country: this.editing_form_field.country_list.name
        };
    },

    computed: {
        countries: function () {
            return wpuf_form_builder.countries;
        },

        visibility_buttons: function () {
            return [
                { name: 'all', title: this.i18n.show_all },
                { name: 'hide', title: this.i18n.hide_these },
                { name: 'show', title: this.i18n.only_show_these }
            ];
        },

        active_visibility: function () {
            return this.editing_form_field.country_list.country_list_visibility_opt_name;
        },

        country_in_hide_list: function () {
            return this.editing_form_field.country_list.country_select_hide_list;
        },

        country_in_show_list: function () {
            return this.editing_form_field.country_list.country_select_show_list;
        },

    },

    mounted: function () {
        this.bind_selectize();
    },

    watch: {
        met_dependencies: function(newVal, oldVal) {
            // When dependencies become met (component becomes visible)
            if (newVal && !oldVal) {
                this.schedule_selectize_rebind();
            }
        },

        active_visibility: function(newVal, oldVal) {
            if (newVal !== oldVal) {
                this.schedule_selectize_rebind();
            }
        }
    },

    methods: {
        schedule_selectize_rebind: function () {
            var self = this;

            this.$nextTick(function() {
                setTimeout(function() {
                    self.bind_selectize();
                }, 100);
            });
        },

        bind_selectize: function () {
            var self = this;

            // Destroy existing selectize instances first (like field-multiselect does)
            var $defaultCountry = $(this.$el).find('.default-country');
            if ($defaultCountry[0] && $defaultCountry[0].selectize) {
                $defaultCountry[0].selectize.destroy();
            }

            $(this.$el).find('select.country-list-selector').each(function() {
                if ($(this)[0] && $(this)[0].selectize) {
                    $(this)[0].selectize.destroy();
                }
            });

            $defaultCountry.selectize({
                plugins: ['remove_button'],

            }).on('change', function () {
                var value = $(this).val();

                self.default_country = value;
                self.update_country_list('name', value);
            });

            $(this.$el).find('select.country-list-selector').selectize({
                plugins: ['remove_button'],
                placeholder: this.i18n.select_countries

            }).on('change', function (e) {
                var select      = $(this),
                    visibility  = e.target.dataset.visibility,
                    value       = select.val(),
                    list        = '';

                switch(visibility) {
                    case 'hide':
                        list = 'country_select_hide_list';
                        break;

                    case 'show':
                        list = 'country_select_show_list';
                        break;
                }

                if (!list) {
                    return;
                }

                if (!value) {
                    value = [];
                }

                self.update_country_list(list, value);

            });
        },

        update_country_list: function (prop, value) {
            var country_list = $.extend(true, {}, this.editing_form_field.country_list);

            country_list[prop] = value;

            this.update_value('country_list', country_list);
        },

        set_visibility: function(visibility) {
            var country_list = $.extend(true, {}, this.editing_form_field.country_list);

            country_list.country_list_visibility_opt_name = visibility;

            if ('show' === visibility) {
                country_list.country_select_hide_list = [];
            } else if ('hide' === visibility) {
                country_list.country_select_show_list = [];
            } else {
                country_list.country_select_show_list = [];
                country_list.country_select_hide_list = [];
            }

            this.update_value('country_list', country_list);
        },

        // Mixin implementation methods
        get_country_show_list: function () {
            return this.editing_form_field.country_list.country_select_show_list;
        },

        get_country_hide_list: function () {
            return this.editing_form_field.country_list.country_select_hide_list;
        },
    }
});
