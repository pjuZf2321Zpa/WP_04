<?php
$name='DejaVuSansCondensed-Bold';
$type='TTF';
$desc=array (
  'Ascent' => 928.0,
  'Descent' => -236.0,
  'CapHeight' => 928.0,
  'Flags' => 262148,
  'FontBBox' => '[-962 -415 1778 1174]',
  'ItalicAngle' => 0.0,
  'StemV' => 165.0,
  'MissingWidth' => 540.0,
);
$up=-63;
$ut=44;
$ttffile='D:\xampp\htdocs\pmdemo\wp-content\plugins\pm-invoice\includes\fpdf\req\fpdf/font/unifont/DejaVuSansCondensed-Bold.ttf';
$originalsize=631992;
$fontkey='dejavuB';
?>