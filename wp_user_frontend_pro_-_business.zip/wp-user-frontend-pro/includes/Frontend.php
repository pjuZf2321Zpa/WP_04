<?php

namespace WeDevs\Wpuf\Pro;

use WeDevs\Wpuf\Pro\Post_View_Control;
use WeDevs\WpUtils\ContainerTrait;

/**
 * The class which will hold all the starting point of operations outside WordPress dashboard for WPUF
 * We will initialize all the admin classes from here.
 *
 * @since 4.2.14
 */

class Frontend {
    use ContainerTrait;

    public function __construct() {
        $this->profile_form        = new Frontend\Profile_Form();
        $this->content_restriction = new Frontend\Content_Restriction();
        $this->shortcode           = new Frontend\Shortcode();
        $this->account             = new Frontend\Account();
        $this->invoice             = new Frontend\Invoice();
        $this->post_view_control   = new Post_View_Control\Frontend();

        // Priority 20: the free plugin decides at priority 10 whether this page needs
        // the form bundle, and Pro follows that decision instead of guessing on its own.
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_assets' ], 20 );
        // Render-time fallback: the free bundle can also be enqueued while a form
        // renders (page builders, theme templates), and Pro must follow then too.
        add_action( 'wpuf_enqueue_form_assets', [ $this, 'enqueue_assets' ] );
        add_filter( 'wpuf_frontend_object', [ $this, 'wpuf_frontend_object' ] );
    }

    /**
     * Add pro asset URL to the frontend object
     *
     * @since 4.0.8
     *
     * @param array $object
     *
     * @return array
     */
    public function wpuf_frontend_object( $object ) {
        $object['pro_asset_url'] = WPUF_PRO_ASSET_URI;

        return $object;
    }

    /**
     * Enqueue JS and CSS files upon checking WPUF pages
     *
     * @since 4.2.14
     *
     * @return void
     */
    public function enqueue_assets() {
        global $post;

        // Check if we're on a BuddyPress/BuddyBoss page
        $is_buddypress_page = false;
        if ( function_exists( 'is_buddypress' ) ) {
            $is_buddypress_page = is_buddypress();
        }

        // Don't return early if we're on a BuddyPress/BuddyBoss page
        if ( ! is_a( $post, 'WP_Post' ) && ! $is_buddypress_page ) {
            return;
        }

        $has_wpuf_content = ( $post && has_shortcode( $post->post_content, 'wpuf_form' ) ) || ( $post && has_shortcode(
            $post->post_content, 'wpuf_edit'
        ) ) || ( $post && has_shortcode( $post->post_content, 'wpuf_profile' ) ) || ( $post && has_shortcode(
            $post->post_content, 'weforms'
        ) ) || ( $post && has_shortcode( $post->post_content, 'wpuf_account' ) );

        // The free plugin has already enqueued its form bundle for this request
        // (shortcode, block, Elementor widget, special page, or a form rendering).
        // Pro's field assets are only ever used inside those forms, so this replaces
        // the old is_single() / is_page_template() catch-alls that loaded them on
        // every blog post and every custom-template page.
        $free_bundle_loaded = wp_script_is( 'wpuf-frontend-form', 'enqueued' );

        if ( $is_buddypress_page || $has_wpuf_content || $free_bundle_loaded || ( isset( $_GET['section'] ) && $_GET['section'] == 'submit-post' ) || ( isset( $_GET['wpuf_preview'] ) && isset( $_GET['form_id'] ) ) ) {
            wp_enqueue_style( 'wpuf-css-stars' );
            wp_enqueue_style( 'wpuf-math-captcha' );
            wp_enqueue_style( 'wpuf-social-fields' );
            // Load International Telephone Input CSS - https://github.com/jackocnr/intl-tel-input.
            wp_enqueue_style( 'wpuf-intlTelInput' );

            wp_enqueue_script( 'wpuf-rating-js' );
            wp_enqueue_script( 'wpuf-conditional-logic' );
            // Load International Telephone Input JS - https://github.com/jackocnr/intl-tel-input.s
            wp_enqueue_script( 'wpuf-intlTelInput' );
            wp_enqueue_script( 'wpuf-frontend-twitter-validation' );
            wp_enqueue_script( 'wpuf-field-initialization' );
        }
    }
}
