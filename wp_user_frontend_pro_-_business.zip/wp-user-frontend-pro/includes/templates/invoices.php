<?php
global $wpdb;
$user_id = get_current_user_id();
$pagenum = isset( $_GET['pagenum'] ) ? intval( wp_unslash( $_GET['pagenum'] ) ) : 1;

/**
 * Filter the number of invoices displayed per page
 *
 * @since 4.2.7
 *
 * @param int $per_page Number of invoices per page
 */
$per_page = apply_filters( 'wpuf_invoices_per_page', 5 );
$offset = ( $pagenum - 1 ) * $per_page;

$sql = $wpdb->prepare(
    "SELECT transaction_id, created, cost
    FROM " . $wpdb->prefix . "wpuf_transaction
    WHERE user_id = %s
    ORDER BY id DESC
    LIMIT %d OFFSET %d",
    $user_id,
    $per_page,
    $offset
);

$results = $wpdb->get_results( $sql );

$total_sql = $wpdb->prepare(
    "SELECT COUNT(*)
    FROM " . $wpdb->prefix . "wpuf_transaction
    WHERE user_id = %s",
    $user_id
);
$total_items = $wpdb->get_var( $total_sql );
$total_pages = ceil( $total_items / $per_page );
?>

<div>
    <!-- Header -->
    <div class="wpuf-bg-transparent wpuf-rounded-t-lg wpuf-mb-3">
        <h2 class="wpuf-text-gray-700 wpuf-font-bold wpuf-text-[32px] wpuf-leading-[48px] wpuf-tracking-[0.13px] wpuf-m-0">
            <?php esc_html_e( 'My Invoices', 'wpuf-pro' ); ?>
        </h2>
    </div>

    <!-- Subheader -->
    <div class="wpuf-bg-transparent wpuf-mb-[48px]">
        <p class="wpuf-text-gray-400 wpuf-font-normal wpuf-text-[18px] wpuf-leading-[24px] wpuf-tracking-[0.13px] wpuf-m-0">
            <?php
            printf(
                // translators: %s is invoice count
                esc_html( _n( '%s item', '%s items', $total_items, 'wpuf-pro' ) ),
                number_format_i18n( $total_items )
            );
            ?>
        </p>
    </div>

    <?php if ( ! empty( $results ) ) : ?>
        <!-- Table -->
        <div class="wpuf-bg-white wpuf-rounded-b-lg wpuf-shadow-sm wpuf-border wpuf-border-gray-200 wpuf-rounded-[6px] wpuf-max-w-[868px]">
            <table class="items-table wpuf-w-full wpuf-border-separate wpuf-border-spacing-0">
                <thead class="wpuf-bg-[#ECFDF5]">
                    <tr class="items-list-header wpuf-border-b wpuf-border-[#ECFDF5]">
                        <th class="wpuf-px-6 wpuf-py-4 wpuf-text-left wpuf-text-xs wpuf-font-medium wpuf-text-gray-500 wpuf-uppercase wpuf-tracking-wider"><?php esc_html_e( 'Transaction ID', 'wpuf-pro' ); ?></th>
                        <th class="wpuf-px-6 wpuf-py-4 wpuf-text-left wpuf-text-xs wpuf-font-medium wpuf-text-gray-500 wpuf-uppercase wpuf-tracking-wider"><?php esc_html_e( 'Link', 'wpuf-pro' ); ?></th>
                        <th class="wpuf-px-6 wpuf-py-4 wpuf-text-left wpuf-text-xs wpuf-font-medium wpuf-text-gray-500 wpuf-uppercase wpuf-tracking-wider"><?php esc_html_e( 'Amount', 'wpuf-pro' ); ?></th>
                        <th class="wpuf-px-6 wpuf-py-4 wpuf-text-left wpuf-text-xs wpuf-font-medium wpuf-text-gray-500 wpuf-uppercase wpuf-tracking-wider"><?php esc_html_e( 'Options', 'wpuf-pro' ); ?></th>
                    </tr>
                </thead>
                <tbody class="wpuf-bg-white">
                    <?php foreach ( $results as $result ) :
                        $t_id = (array) $result;
                        $invoice_link = get_user_meta( $user_id, '_invoice_link' . $t_id['transaction_id'], true );
                    ?>
                        <tr class="wpuf-h-[96px] hover:wpuf-bg-gray-50 wpuf-transition-colors">
                            <!-- Transaction ID -->
                            <td class="wpuf-px-6 wpuf-py-4" style="border-bottom: 1px solid #E5E7EB;">
                                <span class="wpuf-font-medium wpuf-text-gray-900"><?php echo esc_html( $t_id['transaction_id'] ); ?></span>
                            </td>

                            <!-- Link Button -->
                            <td class="wpuf-px-6 wpuf-py-4" style="border-bottom: 1px solid #E5E7EB;">
                                <?php if ( $invoice_link ) : ?>
                                    <a href="<?php echo esc_url( $invoice_link ); ?>" target="_blank" class="wpuf-inline-flex wpuf-items-center wpuf-justify-center wpuf-px-[12px] wpuf-py-[8px] !wpuf-bg-gray-900 !wpuf-text-white wpuf-text-base wpuf-rounded-sm hover:wpuf-bg-gray-950 hover:wpuf-text-gray-300 wpuf-transition-colors wpuf-no-underline">
                                        <?php esc_html_e( 'View', 'wpuf-pro' ); ?>
                                    </a>
                                <?php else : ?>
                                    <span class="wpuf-text-gray-400"><?php esc_html_e( 'N/A', 'wpuf-pro' ); ?></span>
                                <?php endif; ?>
                            </td>

                            <!-- Amount -->
                            <td class="wpuf-px-6 wpuf-py-4" style="border-bottom: 1px solid #E5E7EB;">
                                <span class="wpuf-text-gray-900"><?php echo esc_html( wpuf_format_price( $t_id['cost'] ) ); ?></span>
                            </td>

                            <!-- Options (3-dot menu) -->
                            <td class="wpuf-px-6 wpuf-py-4 wpuf-whitespace-nowrap" style="border-bottom: 1px solid #E5E7EB;">
                                <div class="wpuf-relative wpuf-inline-block wpuf-text-left wpuf-invoice-menu-wrapper">
                                    <button type="button" class="wpuf-invoice-menu-button wpuf-inline-flex wpuf-items-center wpuf-justify-center wpuf-p-2 wpuf-rounded-md hover:wpuf-bg-gray-100 wpuf-transition-colors wpuf-text-gray-600" aria-haspopup="true">
                                        <span class="wpuf-text-xl wpuf-font-bold wpuf-leading-none">&#8942;</span>
                                    </button>
                                    <div class="wpuf-invoice-menu wpuf-hidden wpuf-absolute wpuf-right-0 wpuf-w-48 wpuf-rounded-md wpuf-shadow-lg wpuf-bg-white wpuf-z-50 wpuf-border wpuf-border-gray-200" style="display: none;">
                                        <div class="wpuf-py-1" role="menu">
                                            <?php if ( $invoice_link ) : ?>
                                                <a href="<?php echo esc_url( $invoice_link ); ?>" target="_blank" class="wpuf-block wpuf-px-4 wpuf-py-2 wpuf-text-sm wpuf-text-gray-700 hover:wpuf-bg-gray-100 wpuf-no-underline" role="menuitem">
                                                    <?php esc_html_e( 'View Invoice', 'wpuf-pro' ); ?>
                                                </a>
                                                <a href="<?php echo esc_url( $invoice_link ); ?>" download class="wpuf-block wpuf-px-4 wpuf-py-2 wpuf-text-sm wpuf-text-gray-700 hover:wpuf-bg-gray-100 wpuf-no-underline" role="menuitem">
                                                    <?php esc_html_e( 'Download', 'wpuf-pro' ); ?>
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php
        // Add modern pagination if there are multiple pages
        if ( $total_pages > 1 ) {
            $current = $pagenum;
            $total = $total_pages;

            /**
             * Filter the maximum number of visible pagination links
             *
             * @since 4.2.3
             *
             * @param int $visible_page_count Maximum visible page links
             */
            $visible_page_count = apply_filters( 'wpuf_invoices_visible_page_count', 7 );
            $pages = [];

            if ( $total <= $visible_page_count ) {
                for ( $i = 1; $i <= $total; $i++ ) {
                    $pages[] = $i;
                }
            } else {
                $pages[] = 1;
                $start = max( 2, $current - 2 );
                $end = min( $total - 1, $current + 2 );

                if ( $start > 2 ) {
                    $pages[] = '...';
                }

                for ( $i = $start; $i <= $end; $i++ ) {
                    $pages[] = $i;
                }

                if ( $end < $total - 1 ) {
                    $pages[] = '...';
                }

                $pages[] = $total;
            }
            ?>

            <div class="wpuf-pagination !wpuf-mt-10">
                <nav class="!wpuf-flex !wpuf-items-center !wpuf-justify-center !wpuf-gap-2" aria-label="<?php esc_attr_e( 'Invoices Pagination', 'wpuf-pro' ); ?>">

                    <!-- Previous Button -->
                    <?php if ( $current > 1 ) : ?>
                        <a href="<?php echo esc_url( add_query_arg( 'pagenum', $current - 1 ) ); ?>"
                           class="wpuf-pagination-link !wpuf-inline-flex !wpuf-items-center !wpuf-px-3 !wpuf-py-2 !wpuf-text-sm !wpuf-text-gray-700 hover:!wpuf-text-gray-900 !wpuf-no-underline">
                            <svg class="!wpuf-w-5 !wpuf-h-5 !wpuf-mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
                            </svg>
                            <?php esc_html_e( 'Previous', 'wpuf-pro' ); ?>
                        </a>
                    <?php else : ?>
                        <span class="!wpuf-inline-flex !wpuf-items-center !wpuf-px-3 !wpuf-py-2 !wpuf-text-sm !wpuf-text-gray-300 !wpuf-cursor-not-allowed">
                            <svg class="!wpuf-w-5 !wpuf-h-5 !wpuf-mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
                            </svg>
                            <?php esc_html_e( 'Previous', 'wpuf-pro' ); ?>
                        </span>
                    <?php endif; ?>

                    <!-- Page Numbers -->
                    <div class="!wpuf-flex !wpuf-items-center !wpuf-gap-1">
                        <?php foreach ( $pages as $page ) : ?>
                            <?php if ( $page === '...' ) : ?>
                                <span class="!wpuf-px-3 !wpuf-py-2 !wpuf-text-sm !wpuf-text-gray-500">
                                    &hellip;
                                </span>
                            <?php elseif ( $page == $current ) : ?>
                                <span aria-current="page"
                                      class="!wpuf-relative !wpuf-inline-flex !wpuf-items-center !wpuf-px-4 !wpuf-py-2 !wpuf-text-sm !wpuf-font-medium !wpuf-text-gray-600 !wpuf-border-t-2 !wpuf-border-gray-900">
                                    <?php echo esc_html( $page ); ?>
                                </span>
                            <?php else : ?>
                                <a href="<?php echo esc_url( add_query_arg( 'pagenum', $page ) ); ?>"
                                   class="!wpuf-no-underline wpuf-pagination-link !wpuf-relative !wpuf-inline-flex !wpuf-items-center !wpuf-px-4 !wpuf-py-2 !wpuf-text-sm !wpuf-font-medium !wpuf-text-gray-700 hover:!wpuf-text-gray-900 hover:!wpuf-border-gray-900 hover:!wpuf-border-t-2 !wpuf-transition-colors">
                                    <?php echo esc_html( $page ); ?>
                                </a>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>

                    <!-- Next Button -->
                    <?php if ( $current < $total ) : ?>
                        <a href="<?php echo esc_url( add_query_arg( 'pagenum', $current + 1 ) ); ?>"
                           class="wpuf-pagination-link !wpuf-inline-flex !wpuf-items-center !wpuf-px-3 !wpuf-py-2 !wpuf-text-sm !wpuf-text-gray-700 hover:!wpuf-text-gray-900 !wpuf-no-underline">
                            <?php esc_html_e( 'Next', 'wpuf-pro' ); ?>
                            <svg class="!wpuf-w-5 !wpuf-h-5 !wpuf-ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                            </svg>
                        </a>
                    <?php else : ?>
                        <span class="!wpuf-inline-flex !wpuf-items-center !wpuf-px-3 !wpuf-py-2 !wpuf-text-sm !wpuf-text-gray-300 !wpuf-cursor-not-allowed">
                            <?php esc_html_e( 'Next', 'wpuf-pro' ); ?>
                            <svg class="!wpuf-w-5 !wpuf-h-5 !wpuf-ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                            </svg>
                        </span>
                    <?php endif; ?>

                </nav>
            </div>
        <?php } ?>

    <?php else : ?>
        <div class="wpuf-bg-white wpuf-rounded-lg wpuf-shadow-sm wpuf-p-8 wpuf-text-center wpuf-border wpuf-border-gray-200">
            <p class="wpuf-text-gray-500 wpuf-mb-0"><?php esc_html_e( 'No invoices found', 'wpuf-pro' ); ?></p>
        </div>
    <?php endif; ?>
</div>
