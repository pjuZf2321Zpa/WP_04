<?php
// DESCRIPTION: Extends the free AI form builder with pro-only templates and integrations.

namespace WeDevs\Wpuf\Pro\AI;

/**
 * Pro AI Templates Class
 *
 * Extends the free AI form builder with pro-only templates and integrations.
 * Hooks into the free plugin's filter system to add additional functionality.
 *
 * @since 4.2.12
 */
class Pro_AI_Templates {

    /**
     * Constructor
     *
     * @since 4.2.12
     *
     * @return void
     */
    public function __construct() {
        add_filter( 'wpuf_ai_prompt_templates', [ $this, 'add_pro_templates' ], 10, 3 );
        add_filter( 'wpuf_ai_prompt_instructions', [ $this, 'add_pro_instructions' ], 10, 3 );
        add_filter( 'wpuf_ai_prompt_file_path', [ $this, 'get_pro_prompt_file_path' ], 10, 3 );
    }

    /**
     * Add Pro templates to the AI form builder
     *
     * @since 4.2.12
     *
     * @param array  $templates   Existing templates
     * @param string $form_type   Form type ('post' or 'profile')
     * @param string $integration Integration identifier
     *
     * @return array Modified templates
     */
    public function add_pro_templates( $templates, $form_type, $integration ) {
        $integration = sanitize_key( $integration );

        // Handle profile/registration form templates
        if ( 'profile' === $form_type || 'registration' === $form_type ) {
            return $this->get_profile_templates( $templates, $integration );
        }

        // Handle post form integration templates.
        // Basic post forms (no integration) are intentionally left to the free plugin —
        // Pro adds value only when a specific third-party integration is active.
        if ( 'post' === $form_type && ! empty( $integration ) ) {
            return $this->get_post_integration_templates( $templates, $integration );
        }

        return $templates;
    }

    /**
     * Get profile/registration form templates
     *
     * @since 4.2.12
     *
     * @param array  $templates   Existing templates
     * @param string $integration Integration identifier
     *
     * @return array Templates
     */
    private function get_profile_templates( $templates, $integration ) {
        switch ( $integration ) {
            case 'dokan':
                return array_merge(
                    $templates, [
                        [
                            'id'    => 'dokan_basic',
                            'label' => __( 'Basic Vendor Registration', 'wpuf-pro' ),
                        ],
                        [
                            'id'    => 'dokan_complete',
                            'label' => __( 'Complete Vendor Profile', 'wpuf-pro' ),
                        ],
                        [
                            'id'    => 'dokan_marketplace',
                            'label' => __( 'Marketplace Seller', 'wpuf-pro' ),
                        ],
                        [
                            'id'    => 'dokan_simple',
                            'label' => __( 'Simple Vendor Signup', 'wpuf-pro' ),
                        ],
                    ]
                );

            case 'wc_vendors':
                return array_merge(
                    $templates, [
                        [
                            'id'    => 'wcv_basic',
                            'label' => __( 'Basic Vendor Registration', 'wpuf-pro' ),
                        ],
                        [
                            'id'    => 'wcv_complete',
                            'label' => __( 'Complete Vendor Profile', 'wpuf-pro' ),
                        ],
                        [
                            'id'    => 'wcv_seller',
                            'label' => __( 'Seller Application', 'wpuf-pro' ),
                        ],
                        [
                            'id'    => 'wcv_simple',
                            'label' => __( 'Simple Vendor Signup', 'wpuf-pro' ),
                        ],
                    ]
                );

            case 'wcfm':
                return array_merge(
                    $templates, [
                        [
                            'id'    => 'wcfm_basic',
                            'label' => __( 'Basic Vendor Registration', 'wpuf-pro' ),
                        ],
                        [
                            'id'    => 'wcfm_complete',
                            'label' => __( 'Complete Vendor Profile', 'wpuf-pro' ),
                        ],
                        [
                            'id'    => 'wcfm_marketplace',
                            'label' => __( 'Marketplace Vendor', 'wpuf-pro' ),
                        ],
                        [
                            'id'    => 'wcfm_multistep',
                            'label' => __( 'Multi-Step Registration', 'wpuf-pro' ),
                        ],
                    ]
                );

            default:
                // The free plugin already returns the default registration templates
                // when no integration is selected; adding them again listed every
                // prompt twice.
                if ( empty( $integration ) ) {
                    return $templates;
                }

                return array_merge(
                    $templates, [
                        [
                            'id'    => 'basic_registration',
                            'label' => __( 'Basic User Registration', 'wpuf-pro' ),
                        ],
                        [
                            'id'    => 'member_directory',
                            'label' => __( 'Member Directory Profile', 'wpuf-pro' ),
                        ],
                        [
                            'id'    => 'job_applicant',
                            'label' => __( 'Job Applicant Registration', 'wpuf-pro' ),
                        ],
                        [
                            'id'    => 'blog_author_signup',
                            'label' => __( 'Blog Author Signup', 'wpuf-pro' ),
                        ],
                        [
                            'id'    => 'community_member_join',
                            'label' => __( 'Community Member Join', 'wpuf-pro' ),
                        ],
                        [
                            'id'    => 'freelancer_profile_signup',
                            'label' => __( 'Freelancer Profile Signup', 'wpuf-pro' ),
                        ],
                    ]
                );
        }
    }

    /**
     * Get post form integration templates
     *
     * @since 4.2.12
     *
     * @param array  $templates   Existing templates
     * @param string $integration Integration identifier
     *
     * @return array Templates
     */
    private function get_post_integration_templates( $templates, $integration ) {
        switch ( $integration ) {
            case 'edd':
                return array_merge(
                    $templates, [
                        [
                            'id'    => 'edd_digital_download',
                            'label' => __( 'Digital Download', 'wpuf-pro' ),
                        ],
                        [
                            'id'    => 'edd_software',
                            'label' => __( 'Software Product', 'wpuf-pro' ),
                        ],
                        [
                            'id'    => 'edd_ebook',
                            'label' => __( 'eBook', 'wpuf-pro' ),
                        ],
                        [
                            'id'    => 'edd_course',
                            'label' => __( 'Online Course', 'wpuf-pro' ),
                        ],
                    ]
                );

            default:
                // WooCommerce and Events Calendar templates come from the free plugin, and
                // there are no Pro templates for unrecognised post-form integrations.
                break;
        }

        return $templates;
    }

    /**
     * Add Pro AI instructions to the form builder
     *
     * @since 4.2.12
     *
     * @param array  $instructions Existing instructions
     * @param string $form_type    Form type ('post' or 'profile')
     * @param string $integration  Integration identifier
     *
     * @return array Modified instructions
     */
    public function add_pro_instructions( $instructions, $form_type, $integration ) {
        $integration = sanitize_key( $integration );

        // Handle profile/registration form instructions
        if ( 'profile' === $form_type || 'registration' === $form_type ) {
            return $this->get_profile_instructions( $instructions, $integration );
        }

        // Handle post form integration instructions
        if ( 'post' === $form_type && ! empty( $integration ) ) {
            return $this->get_post_integration_instructions( $instructions, $integration );
        }

        return $instructions;
    }

    /**
     * Get profile/registration form instructions
     *
     * @since 4.2.12
     *
     * @param array  $instructions Existing instructions
     * @param string $integration  Integration identifier
     *
     * @return array Instructions
     */
    private function get_profile_instructions( $instructions, $integration ) {
        switch ( $integration ) {
            case 'dokan':
                return array_merge(
                    $instructions, [
                        'dokan_basic'       => __( 'Create a Dokan basic vendor registration form with first name, last name, email, shop name, password', 'wpuf-pro' ),
                        'dokan_complete'    => __( 'Create a Dokan complete vendor registration form with first name, last name, email, shop name, shop URL, profile picture, shop banner, phone number, address, store location map, password', 'wpuf-pro' ),
                        'dokan_marketplace' => __( 'Create a Dokan marketplace seller registration form with first name, last name, email, shop name, shop URL, store description, profile picture, shop banner, phone number, PayPal email, password', 'wpuf-pro' ),
                        'dokan_simple'      => __( 'Create a Dokan simple vendor signup form with email, shop name, password', 'wpuf-pro' ),
                    ]
                );

            case 'wc_vendors':
                return array_merge(
                    $instructions, [
                        'wcv_basic'    => __( 'Create a WC Vendors basic registration form with email, PayPal address, shop name, password', 'wpuf-pro' ),
                        'wcv_complete' => __( 'Create a WC Vendors complete registration form with email, first name, last name, PayPal address, shop name, seller info, shop description, shop logo, password', 'wpuf-pro' ),
                        'wcv_seller'   => __( 'Create a WC Vendors seller application form with email, first name, last name, PayPal address, shop name, seller info, shop description, password', 'wpuf-pro' ),
                        'wcv_simple'   => __( 'Create a WC Vendors simple vendor signup form with email, shop name, PayPal address, password', 'wpuf-pro' ),
                    ]
                );

            case 'wcfm':
                return array_merge(
                    $instructions, [
                        'wcfm_basic'       => __( 'Create a WCFM basic vendor registration form with email, store name (username), password', 'wpuf-pro' ),
                        'wcfm_complete'    => __( 'Create a WCFM complete vendor registration form with email, store name, first name, last name, phone number, store logo, store banner, store description, store address, social links (Facebook, Twitter, Instagram, LinkedIn), password', 'wpuf-pro' ),
                        'wcfm_marketplace' => __( 'Create a WCFM marketplace vendor registration form with email, store name, first name, last name, phone, store logo, store description, address, password', 'wpuf-pro' ),
                        'wcfm_multistep'   => __( 'Create a WCFM multi-step vendor registration form with section breaks: Step 1 (email, store name, password), Step 2 (store logo, store banner, store description), Step 3 (phone, address, social links)', 'wpuf-pro' ),
                    ]
                );

            default:
                // Default registration instructions (no integration)
                return array_merge(
                    $instructions, [
                        'basic_registration'       => __( 'Create a Basic User Registration form with email, name, username, password', 'wpuf-pro' ),
                        'member_directory'         => __( 'Create a Member Directory Profile form with name, email, bio, profile photo', 'wpuf-pro' ),
                        'job_applicant'            => __( 'Create a Job Applicant Registration form with name, email, phone, resume upload', 'wpuf-pro' ),
                        'blog_author_signup'       => __( 'Create a registration form for new blog authors. Collect their login details, public display information, a short introduction about themselves, a profile photo or avatar, and an optional personal website link.', 'wpuf-pro' ),
                        'community_member_join'    => __( 'Create a registration form for new community members. Collect their basic personal details, login information, a public name, a nickname, their interests (as checkboxes), a short personal introduction, and a profile picture', 'wpuf-pro' ),
                        'freelancer_profile_signup' => __( 'Create a registration form for freelancers that captures their professional details, skills, experience summary, portfolio information, and profile photo.', 'wpuf-pro' ),
                    ]
                );
        }
    }

    /**
     * Get post form integration instructions
     *
     * @since 4.2.12
     *
     * @param array  $instructions Existing instructions
     * @param string $integration  Integration identifier
     *
     * @return array Instructions
     */
    private function get_post_integration_instructions( $instructions, $integration ) {
        switch ( $integration ) {
            case 'woocommerce':
                return array_merge(
                    $instructions, [
                        'woo_simple_product'   => __( 'Create a WooCommerce Simple Product form with product title, product description, short description, regular price, sale price, featured image, product gallery, catalog visibility', 'wpuf-pro' ),
                        'woo_digital_product'  => __( 'Create a WooCommerce Digital Product form with product title, product description, regular price, featured image, SKU, Downloadable Product, Downloadable Files', 'wpuf-pro' ),
                        'woo_service_listing'  => __( 'Create a WooCommerce Service form with product title, product description, regular price, featured image, purchase note', 'wpuf-pro' ),
                        'woo_handmade_product' => __( 'Create a WooCommerce Handmade Product form with product title, product description, short description, regular price, featured image, product gallery, product attributes for size and color, weight, dimensions', 'wpuf-pro' ),
                    ]
                );

            case 'edd':
                return array_merge(
                    $instructions, [
                        'edd_digital_download' => __( 'Create an EDD Digital Download form with download title, download description, short description, price, downloadable files, featured image, download categories', 'wpuf-pro' ),
                        'edd_software'         => __( 'Create an EDD Software Product form with download title, download description, price, downloadable files, product notes, featured image, download categories', 'wpuf-pro' ),
                        'edd_ebook'            => __( 'Create an EDD eBook form with download title, download description, short description, price, downloadable files, featured image, download categories', 'wpuf-pro' ),
                        'edd_course'           => __( 'Create an EDD Online Course form with download title, download description, price, downloadable files, product notes, featured image, download categories', 'wpuf-pro' ),
                    ]
                );

            case 'events_calendar':
                return array_merge(
                    $instructions, [
                        'event_conference' => __( 'Create a Conference Event form with event title, event details, event start date, event end date, venue name, event address, event city, event cost, currency symbol, featured image, event categories', 'wpuf-pro' ),
                        'event_workshop'   => __( 'Create a Workshop/Training Event form with event title, event details, event start date, event end date, venue name, event address, event cost, featured image, event categories', 'wpuf-pro' ),
                        'event_meetup'     => __( 'Create a Meetup/Networking Event form with event title, event details, short description, event start date, event end date, venue name, event address, event website, featured image, event categories', 'wpuf-pro' ),
                        'event_webinar'    => __( 'Create a Webinar Event form with event title, event details, event start date, event end date, event website, event cost, currency symbol, featured image, event categories', 'wpuf-pro' ),
                    ]
                );
        }

        return $instructions;
    }

    /**
     * Get Pro prompt file path for AI system prompts
     *
     * @since 4.2.12
     *
     * @param string $file_path   Default file path
     * @param string $form_type   Form type ('post' or 'profile')
     * @param string $integration Integration identifier
     *
     * @return string Modified file path
     */
    public function get_pro_prompt_file_path( $file_path, $form_type, $integration ) {
        $integration  = sanitize_key( $integration );
        $pro_ai_path  = WPUF_PRO_INCLUDES . '/AI/prompts/';

        // Handle registration/profile form prompts.
        // Only override when there is an explicit Pro integration — let the free plugin
        // handle the no-integration default so Pro does not go stale relative to free.
        if ( 'profile' === $form_type || 'registration' === $form_type ) {
            switch ( $integration ) {
                case 'dokan':
                    $pro_file = $pro_ai_path . 'wpuf-ai-prompt-dokan-registration.md';
                    break;

                case 'wc_vendors':
                    $pro_file = $pro_ai_path . 'wpuf-ai-prompt-wc-vendors-registration.md';
                    break;

                case 'wcfm':
                    $pro_file = $pro_ai_path . 'wpuf-ai-prompt-wcfm-registration.md';
                    break;

                default:
                    return $file_path;
            }

            if ( file_exists( $pro_file ) ) {
                return $pro_file;
            }
        }

        // Handle post form integration prompts
        if ( 'post' === $form_type && ! empty( $integration ) ) {
            switch ( $integration ) {
                case 'woocommerce':
                    $pro_file = $pro_ai_path . 'wpuf-ai-prompt-woocommerce.md';
                    break;

                case 'edd':
                    $pro_file = $pro_ai_path . 'wpuf-ai-prompt-edd.md';
                    break;

                case 'events_calendar':
                    $pro_file = $pro_ai_path . 'wpuf-ai-prompt-events-calendar.md';
                    break;

                default:
                    return $file_path;
            }

            if ( file_exists( $pro_file ) ) {
                return $pro_file;
            }
        }

        return $file_path;
    }
}
