<?php

namespace WeDevs\Wpuf\Pro\Admin\Forms\ProfileTemplates;

use WeDevs\Wpuf\Admin\Forms\Form_Template;

/**
 * Personal Blog Author Signup registration form template
 *
 * @since 4.2.13
 */
class Personal_Blog_Author_Signup_Template extends Form_Template {

    public function __construct() {
        parent::__construct();

        $this->enabled     = true;
        $this->title       = __( 'Personal Blog Author Signup', 'wpuf-pro' );
        $this->description = __( 'For bloggers or guest writers.', 'wpuf-pro' );
        $this->image       = WPUF_PRO_ASSET_URI . '/images/templates/blog-author-signup.svg';

        $this->form_fields = [
            [
                'input_type'       => 'text',
                'template'         => 'user_login',
                'required'         => 'yes',
                'label'            => 'Username',
                'name'             => 'user_login',
                'is_meta'          => 'no',
                'help'             => '',
                'css'              => '',
                'placeholder'      => 'Choose a unique username',
                'default'          => '',
                'size'             => 40,
                'word_restriction' => '',
                'wpuf_cond'        => $this->conditionals,
                'wpuf_visibility'  => $this->get_default_visibility_prop(),
            ],
            [
                'input_type'      => 'email',
                'template'        => 'user_email',
                'required'        => 'yes',
                'label'           => 'Email',
                'name'            => 'user_email',
                'is_meta'         => 'no',
                'help'            => 'Required',
                'css'             => '',
                'placeholder'     => 'Enter your email address',
                'default'         => '',
                'size'            => 40,
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
            ],
            [
                'input_type'      => 'password',
                'template'        => 'password',
                'required'        => 'yes',
                'label'           => 'Password',
                'name'            => 'password',
                'is_meta'         => 'no',
                'help'            => 'Secure your account',
                'css'             => '',
                'placeholder'     => '•••••••',
                'default'         => '',
                'size'            => 40,
                'min_length'      => 6,
                'repeat_pass'     => 'yes',
                're_pass_label'   => 'Confirm Password',
                'pass_strength'   => 'no',
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
            ],
            [
                'input_type'       => 'text',
                'template'         => 'display_name',
                'required'         => 'yes',
                'label'            => 'Display Name',
                'name'             => 'display_name',
                'is_meta'          => 'no',
                'help'             => 'Name shown on your blog posts',
                'css'              => '',
                'placeholder'      => 'enter display name',
                'default'          => '',
                'size'             => 40,
                'word_restriction' => '',
                'wpuf_cond'        => $this->conditionals,
                'wpuf_visibility'  => $this->get_default_visibility_prop(),
            ],
            [
                'input_type'       => 'textarea',
                'template'         => 'user_bio',
                'required'         => 'no',
                'label'            => 'Bio',
                'name'             => 'description',
                'is_meta'          => 'no',
                'help'             => 'Share your background and writing interests',
                'css'              => '',
                'rows'             => 5,
                'cols'             => 25,
                'placeholder'      => 'A short intro about you',
                'default'          => '',
                'rich'             => 'no',
                'word_restriction' => '',
                'wpuf_cond'        => $this->conditionals,
                'wpuf_visibility'  => $this->get_default_visibility_prop(),
            ],
            [
                'input_type'      => 'profile_photo',
                'template'        => 'profile_photo',
                'required'        => 'yes',
                'label'           => 'Profile Picture',
                'button_label'    => __( 'Select Profile Photo', 'wpuf-pro' ),
                'name'            => 'wpuf_profile_photo',
                'is_meta'         => 'no',
                'help'            => 'Upload your author profile photo',
                'css'             => '',
                'max_size'        => '2048',
                'extension'       => [ 'jpg', 'jpeg', 'png' ],
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
            ],
            [
                'input_type'       => 'url',
                'template'         => 'user_url',
                'required'         => 'no',
                'label'            => 'Website URL',
                'name'             => 'user_url',
                'is_meta'          => 'no',
                'help'             => 'Optional personal or blog site',
                'css'              => '',
                'placeholder'      => 'https://yourblog.com',
                'default'          => '',
                'size'             => 40,
                'word_restriction' => '',
                'wpuf_cond'        => $this->conditionals,
                'wpuf_visibility'  => $this->get_default_visibility_prop(),
            ],
        ];

        $this->form_settings = [
            'role'                       => 'author',
            'wpuf_user_status'           => 'pending',
            'form_template'              => '',
            'reg_redirect_to'            => 'same',
            'message'                    => 'Registration successful',
            'registration_url'           => '',
            'submit_text'                => 'Register',
            'user_notification'          => 'off',
            'admin_notification'         => 'on',
            'notification_type'          => 'welcome_email',
            'profile_redirect_to'        => 'same',
            'update_message'             => 'Profile has been updated successfully.',
            'profile_url'                => '',
            'update_text'                => 'Update Information',
            'label_position'             => 'above',
            'profile_form_layout'        => 'layout1',
            'enable_multistep'           => '',
            'multistep_progressbar_type' => 'step_by_step',
        ];
    }

}
