<?php

namespace WeDevs\Wpuf\Pro\Admin\Forms\ProfileTemplates;

use WeDevs\Wpuf\Admin\Forms\Form_Template;

/**
 * Club/Association Member registration form template
 *
 * A general-purpose registration form designed for private member clubs
 * and associations. Includes fields for membership identification,
 * contact information, and profile management.
 *
 * @since 4.2.12
 */
class Club_Association_Member_Template extends Form_Template {

    /**
     * Constructor
     *
     * @since 4.2.12
     */
    public function __construct() {
        parent::__construct();

        $this->enabled     = true;
        $this->title       = __( 'Club/Association Member', 'wpuf-pro' );
        $this->description = __( 'General-purpose private member registration form for clubs and associations.', 'wpuf-pro' );
        $this->image       = WPUF_PRO_ASSET_URI . '/images/templates/club-association-member.svg';

        $this->form_fields   = $this->get_form_field_definitions();
        $this->form_settings = $this->get_form_setting_definitions();
    }

    /**
     * Get form field definitions
     *
     * @since 4.2.12
     *
     * @return array
     */
    private function get_form_field_definitions() {
        return [
            // Username Field
            [
                'input_type'      => 'text',
                'template'        => 'user_login',
                'required'        => 'yes',
                'label'           => __( 'Username', 'wpuf-pro' ),
                'name'            => 'user_login',
                'is_meta'         => 'no',
                'help'            => __( 'Used for login & profile', 'wpuf-pro' ),
                'css'             => '',
                'placeholder'     => __( 'Choose a unique username', 'wpuf-pro' ),
                'default'         => '',
                'size'            => 40,
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
            ],
            // Email Field
            [
                'input_type'      => 'email',
                'template'        => 'user_email',
                'required'        => 'yes',
                'label'           => __( 'Email', 'wpuf-pro' ),
                'name'            => 'user_email',
                'is_meta'         => 'no',
                'help'            => __( 'Required', 'wpuf-pro' ),
                'css'             => '',
                'placeholder'     => __( 'Enter your email address', 'wpuf-pro' ),
                'default'         => '',
                'size'            => 40,
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
            ],
            // Password Field
            [
                'input_type'      => 'password',
                'template'        => 'password',
                'required'        => 'yes',
                'label'           => __( 'Password', 'wpuf-pro' ),
                'name'            => 'password',
                'is_meta'         => 'no',
                'help'            => __( 'Minimum 6 characters recommended', 'wpuf-pro' ),
                'css'             => '',
                'placeholder'     => '',
                'default'         => '',
                'size'            => 40,
                'min_length'      => 6,
                'repeat_pass'     => 'yes',
                're_pass_label'   => __( 'Confirm Password', 'wpuf-pro' ),
                'pass_strength'   => 'no',
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
            ],
            // First Name Field
            [
                'input_type'      => 'text',
                'template'        => 'first_name',
                'required'        => 'yes',
                'label'           => __( 'First Name', 'wpuf-pro' ),
                'name'            => 'first_name',
                'is_meta'         => 'no',
                'help'            => '',
                'css'             => '',
                'placeholder'     => __( 'Enter your first name', 'wpuf-pro' ),
                'default'         => '',
                'size'            => 40,
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
            ],
            // Last Name Field
            [
                'input_type'      => 'text',
                'template'        => 'last_name',
                'required'        => 'yes',
                'label'           => __( 'Last Name', 'wpuf-pro' ),
                'name'            => 'last_name',
                'is_meta'         => 'no',
                'help'            => '',
                'css'             => '',
                'placeholder'     => __( 'Enter your last name', 'wpuf-pro' ),
                'default'         => '',
                'size'            => 40,
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
            ],
            // Membership ID Field
            [
                'input_type'      => 'text',
                'template'        => 'text_field',
                'required'        => 'yes',
                'label'           => __( 'Membership ID', 'wpuf-pro' ),
                'name'            => 'membership_id',
                'is_meta'         => 'yes',
                'help'            => __( 'Your unique membership number', 'wpuf-pro' ),
                'css'             => '',
                'placeholder'     => 'ABC123',
                'default'         => '',
                'size'            => 40,
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
            ],
            // Phone Number Field
            [
                'input_type'        => 'phone',
                'template'          => 'phone_field',
                'required'          => 'yes',
                'label'             => __( 'Phone Number', 'wpuf-pro' ),
                'name'              => 'phone_number',
                'is_meta'           => 'yes',
                'help'              => __( 'Required contact number', 'wpuf-pro' ),
                'width'             => 'large',
                'css'               => '',
                'placeholder'       => '+1234567890',
                'default'           => '',
                'size'              => 40,
                'show_country_list' => 'yes',
                'auto_placeholder'  => 'yes',
                'country_list'      => [
                    'name'                             => '',
                    'country_list_visibility_opt_name' => 'all',
                    'country_select_show_list'         => [],
                    'country_select_hide_list'         => [],
                ],
                'step_text_field'   => '0',
                'min_value_field'   => '0',
                'max_value_field'   => '0',
                'wpuf_cond'         => $this->conditionals,
                'wpuf_visibility'   => $this->get_default_visibility_prop(),
            ],
            // Address Field
            [
                'input_type'      => 'address',
                'template'        => 'address_field',
                'required'        => 'no',
                'label'           => __( 'Address', 'wpuf-pro' ),
                'name'            => 'address',
                'is_meta'         => 'yes',
                'help'            => __( 'Optional contact address', 'wpuf-pro' ),
                'width'           => '',
                'css'             => '',
                'wpuf_cond'       => $this->conditionals,
                'address_desc'    => '',
                'address'         => [
                    'street_address'  => [
                        'checked'     => 'checked',
                        'type'        => 'text',
                        'required'    => '',
                        'label'       => __( 'Street Address', 'wpuf-pro' ),
                        'value'       => '',
                        'placeholder' => '',
                    ],
                    'street_address2' => [
                        'checked'     => 'checked',
                        'type'        => 'text',
                        'required'    => '',
                        'label'       => __( 'Street Address Line 2', 'wpuf-pro' ),
                        'value'       => '',
                        'placeholder' => '',
                    ],
                    'city_name'       => [
                        'checked'     => 'checked',
                        'type'        => 'text',
                        'required'    => '',
                        'label'       => __( 'City', 'wpuf-pro' ),
                        'value'       => '',
                        'placeholder' => '',
                    ],
                    'zip'             => [
                        'checked'     => 'checked',
                        'type'        => 'text',
                        'required'    => '',
                        'label'       => __( 'ZIP/Postal Code', 'wpuf-pro' ),
                        'value'       => '',
                        'placeholder' => '',
                    ],
                    'country_select'  => [
                        'checked'                          => 'checked',
                        'type'                             => 'select',
                        'required'                         => '',
                        'label'                            => __( 'Country', 'wpuf-pro' ),
                        'value'                            => '',
                        'country_list_visibility_opt_name' => 'all',
                        'country_select_hide_list'         => [],
                        'country_select_show_list'         => [],
                    ],
                    'state'           => [
                        'checked'     => 'checked',
                        'type'        => 'select',
                        'required'    => '',
                        'label'       => __( 'State/Province', 'wpuf-pro' ),
                        'value'       => '',
                        'placeholder' => '',
                    ],
                ],
                'wpuf_visibility' => $this->get_default_visibility_prop(),
            ],
            // Profile Picture Field
            [
                'input_type'      => 'profile_photo',
                'template'        => 'profile_photo',
                'required'        => 'no',
                'label'           => __( 'Profile Picture', 'wpuf-pro' ),
                'button_label'    => __( 'Select Profile Photo', 'wpuf-pro' ),
                'name'            => 'wpuf_profile_photo',
                'is_meta'         => 'yes',
                'help'            => __( 'Upload profile photo', 'wpuf-pro' ),
                'width'           => '',
                'css'             => '',
                'max_size'        => '2048',
                'count'           => '1',
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
            ],
        ];
    }

    /**
     * Get form setting definitions
     *
     * @since 4.2.12
     *
     * @return array
     */
    private function get_form_setting_definitions() {
        return [
            // General Settings
            'role'                       => 'subscriber',
            'user_status'                => 'on',
            'form_template'              => 'club_association_member_template',

            // After Sign Up Settings
            'reg_redirect_to'            => 'same',
            'message'                    => __( 'Thank you for registering as a member! Your registration is pending approval. You will receive an email once your account has been reviewed and activated.', 'wpuf-pro' ),
            'registration_url'           => '',

            // Profile Update Settings
            'profile_redirect_to'        => 'same',
            'update_message'             => __( 'Your member profile has been updated successfully.', 'wpuf-pro' ),
            'profile_url'                => '',

            // Button Settings
            'submit_text'                => __( 'Register as Member', 'wpuf-pro' ),
            'update_text'                => __( 'Update Profile', 'wpuf-pro' ),

            // Display Settings
            'label_position'             => 'above',
            'enable_multistep'           => 'no',
            'multistep_progressbar_type' => 'step_by_step',

            // Notification Settings
            'user_notification'          => 'off',
            'admin_notification'         => 'on',
            'notification_type'          => 'admin_approval',
            'notification'               => [
                'admin_email_subject' => __( 'New Club/Association Member Registration', 'wpuf-pro' ),
                'admin_email_body'    => __( "A new member has registered.\n\nUsername: {username}\nEmail: {user_email}\nDisplay Name: {display_name}\n\nUser Status: {user_status}", 'wpuf-pro' ),
            ],
        ];
    }

    /**
     * Run necessary processing after new insert (registration)
     *
     * @since 4.2.12
     *
     * @param int   $user_id       The user ID
     * @param int   $form_id       The form ID
     * @param array $form_settings The form settings
     *
     * @return void
     */
    public function after_insert( $user_id, $form_id, $form_settings ) {
        $this->handle_form_updates( $user_id, $form_id, $form_settings );
    }

    /**
     * Run necessary processing after editing a profile
     *
     * @since 4.2.12
     *
     * @param int   $user_id       The user ID
     * @param int   $form_id       The form ID
     * @param array $form_settings The form settings
     *
     * @return void
     */
    public function after_update( $user_id, $form_id, $form_settings ) {
        $this->handle_form_updates( $user_id, $form_id, $form_settings );
    }

    /**
     * Run the functions on update/insert
     *
     * Handle club/association member-specific data processing
     *
     * @since 4.2.12
     *
     * @param int   $user_id       The user ID
     * @param int   $form_id       The form ID
     * @param array $form_settings The form settings
     *
     * @return void
     */
    private function handle_form_updates( $user_id, $form_id, $form_settings ) {
        // Mark user as a club/association member.
        // Field-based meta (membership_id, phone_number, address) is auto-saved
        // by WPUF for all is_meta:'yes' fields — no duplicate saves needed here.
        update_user_meta( $user_id, 'is_club_member', 'yes' );
        update_user_meta( $user_id, 'club_member_joined', current_time( 'mysql' ) );

        /**
         * Action hook fired after club/association member data is saved
         *
         * @since 4.2.12
         *
         * @param int   $user_id       The user ID
         * @param int   $form_id       The form ID
         * @param array $form_settings The form settings
         */
        do_action( 'wpuf_club_member_data_saved', $user_id, $form_id, $form_settings );
    }
}
