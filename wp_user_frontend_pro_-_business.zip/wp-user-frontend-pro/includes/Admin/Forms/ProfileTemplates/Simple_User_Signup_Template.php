<?php

namespace WeDevs\Wpuf\Pro\Admin\Forms\ProfileTemplates;

use WeDevs\Wpuf\Admin\Forms\Form_Template;

/**
 * Simple User Signup registration form template
 *
 * @since 4.2.13
 */
class Simple_User_Signup_Template extends Form_Template {

    public function __construct() {
        parent::__construct();

        $this->enabled     = true;
        $this->title       = __( 'Simple User Signup', 'wpuf-pro' );
        $this->description = __( 'Simple user sign-up for any site.', 'wpuf-pro' );
        $this->image       = WPUF_PRO_ASSET_URI . '/images/templates/simple-user-signup.svg';

        $this->form_fields = [
            [
                'input_type'       => 'text',
                'template'         => 'first_name',
                'required'         => 'yes',
                'label'            => 'First Name',
                'name'             => 'first_name',
                'is_meta'          => 'no',
                'help'             => '',
                'css'              => '',
                'placeholder'      => 'Enter your first name',
                'default'          => '',
                'size'             => 40,
                'word_restriction' => '',
                'wpuf_cond'        => $this->conditionals,
                'wpuf_visibility'  => $this->get_default_visibility_prop(),
            ],
            [
                'input_type'       => 'text',
                'template'         => 'last_name',
                'required'         => 'yes',
                'label'            => 'Last Name',
                'name'             => 'last_name',
                'is_meta'          => 'no',
                'help'             => '',
                'css'              => '',
                'placeholder'      => 'Enter your last name',
                'default'          => '',
                'size'             => 40,
                'word_restriction' => '',
                'wpuf_cond'        => $this->conditionals,
                'wpuf_visibility'  => $this->get_default_visibility_prop(),
            ],
            [
                'input_type'       => 'text',
                'template'         => 'user_login',
                'required'         => 'yes',
                'label'            => 'Username',
                'name'             => 'user_login',
                'is_meta'          => 'no',
                'help'             => '',
                'css'              => '',
                'placeholder'      => 'Choose a unique username',
                'default'          => '',
                'size'             => 40,
                'word_restriction' => '',
                'wpuf_cond'        => $this->conditionals,
                'wpuf_visibility'  => $this->get_default_visibility_prop(),
            ],
            [
                'input_type'      => 'email',
                'template'        => 'user_email',
                'required'        => 'yes',
                'label'           => 'Email',
                'name'            => 'user_email',
                'is_meta'         => 'no',
                'help'            => "We'll never share your email address",
                'css'             => '',
                'placeholder'     => 'Enter your email address',
                'default'         => '',
                'size'            => 40,
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
            ],
            [
                'input_type'      => 'password',
                'template'        => 'password',
                'required'        => 'yes',
                'label'           => 'Password',
                'name'            => 'password',
                'is_meta'         => 'no',
                'help'            => 'Minimum 6 characters recommended',
                'css'             => '',
                'placeholder'     => '•••••••',
                'default'         => '',
                'size'            => 40,
                'min_length'      => 6,
                'repeat_pass'     => 'yes',
                're_pass_label'   => 'Confirm Password',
                'pass_strength'   => 'no',
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
            ],
        ];

        $this->form_settings = [
            'role'                       => 'subscriber',
            'wpuf_user_status'           => 'pending',
            'form_template'              => '',
            'reg_redirect_to'            => 'same',
            'message'                    => 'Registration successful',
            'registration_url'           => '',
            'submit_text'                => 'Register',
            'user_notification'          => 'off',
            'admin_notification'         => 'on',
            'notification_type'          => 'welcome_email',
            'profile_redirect_to'        => 'same',
            'update_message'             => 'Profile has been updated successfully.',
            'profile_url'                => '',
            'update_text'                => 'Update Information',
            'label_position'             => 'above',
            'profile_form_layout'        => 'layout1',
            'enable_multistep'           => '',
            'multistep_progressbar_type' => 'step_by_step',
        ];
    }

}
