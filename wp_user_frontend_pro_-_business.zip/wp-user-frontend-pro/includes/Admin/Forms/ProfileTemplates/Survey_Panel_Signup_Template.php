<?php

namespace WeDevs\Wpuf\Pro\Admin\Forms\ProfileTemplates;

use WeDevs\Wpuf\Admin\Forms\Form_Template;

/**
 * Survey Panel Signup registration form template
 *
 * A registration form designed for collecting participants for future surveys.
 * Includes fields for demographics and interests to build a survey panel.
 *
 * @since 4.2.12
 */
class Survey_Panel_Signup_Template extends Form_Template {

    /**
     * Constructor
     *
     * @since 4.2.12
     */
    public function __construct() {
        parent::__construct();

        $this->enabled     = true;
        $this->title       = __( 'Survey Panel Signup', 'wpuf-pro' );
        $this->description = __( 'Form for collecting participants for future surveys. Captures demographics and interests.', 'wpuf-pro' );
        $this->image       = WPUF_PRO_ASSET_URI . '/images/templates/survey-panel.svg';

        $this->form_fields   = $this->get_form_field_definitions();
        $this->form_settings = $this->get_form_setting_definitions();
    }

    /**
     * Get form field definitions
     *
     * @since 4.2.12
     *
     * @return array
     */
    private function get_form_field_definitions() {
        return [
            // Username Field
            [
                'input_type'      => 'text',
                'template'        => 'user_login',
                'required'        => 'yes',
                'label'           => __( 'Username', 'wpuf-pro' ),
                'name'            => 'user_login',
                'is_meta'         => 'no',
                'help'            => __( 'Used for login & profile', 'wpuf-pro' ),
                'css'             => '',
                'placeholder'     => __( 'Choose a unique username', 'wpuf-pro' ),
                'default'         => '',
                'size'            => 40,
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
            ],
            // Email Field
            [
                'input_type'      => 'email',
                'template'        => 'user_email',
                'required'        => 'yes',
                'label'           => __( 'Email', 'wpuf-pro' ),
                'name'            => 'user_email',
                'is_meta'         => 'no',
                'help'            => __( 'Required', 'wpuf-pro' ),
                'css'             => '',
                'placeholder'     => __( 'Enter your email address', 'wpuf-pro' ),
                'default'         => '',
                'size'            => 40,
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
            ],
            // Password Field
            [
                'input_type'      => 'password',
                'template'        => 'password',
                'required'        => 'yes',
                'label'           => __( 'Password', 'wpuf-pro' ),
                'name'            => 'password',
                'is_meta'         => 'no',
                'help'            => __( 'Minimum 6 characters recommended', 'wpuf-pro' ),
                'css'             => '',
                'placeholder'     => '',
                'default'         => '',
                'size'            => 40,
                'min_length'      => 6,
                'repeat_pass'     => 'yes',
                're_pass_label'   => __( 'Confirm Password', 'wpuf-pro' ),
                'pass_strength'   => 'no',
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
            ],
            // Age Field (Numeric)
            [
                'input_type'       => 'numeric_text_field',
                'template'         => 'numeric_text_field',
                'required'         => 'yes',
                'label'            => __( 'Age', 'wpuf-pro' ),
                'name'             => 'survey_age',
                'is_meta'          => 'yes',
                'help'             => __( 'Your age', 'wpuf-pro' ),
                'css'              => '',
                'placeholder'      => '25',
                'default'          => '',
                'size'             => 40,
                'step_text_field'  => '1',
                'min_value_field'  => '13',
                'max_value_field'  => '120',
                'width'            => 'medium',
                'wpuf_cond'        => $this->conditionals,
                'wpuf_visibility'  => $this->get_default_visibility_prop(),
            ],
            // Gender Field (Radio)
            [
                'input_type'      => 'radio',
                'template'        => 'radio_field',
                'required'        => 'yes',
                'label'           => __( 'Gender', 'wpuf-pro' ),
                'name'            => 'survey_gender',
                'is_meta'         => 'yes',
                'help'            => __( 'Select your gender', 'wpuf-pro' ),
                'css'             => '',
                'show_icon'       => 'no',
                'inline'          => 'yes',
                'options'         => [
                    'male'   => __( 'Male', 'wpuf-pro' ),
                    'female' => __( 'Female', 'wpuf-pro' ),
                    'other'  => __( 'Other', 'wpuf-pro' ),
                ],
                'selected'        => '',
                'width'           => 'large',
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
            ],
            // Interests Field (Checkbox)
            [
                'input_type'      => 'checkbox',
                'template'        => 'checkbox_field',
                'required'        => 'yes',
                'label'           => __( 'Interests', 'wpuf-pro' ),
                'name'            => 'survey_interests',
                'is_meta'         => 'yes',
                'help'            => __( 'Choose your interests', 'wpuf-pro' ),
                'css'             => '',
                'show_icon'       => 'no',
                'inline'          => 'yes',
                'options'         => [
                    'sports' => __( 'Sports', 'wpuf-pro' ),
                    'music'  => __( 'Music', 'wpuf-pro' ),
                    'tech'   => __( 'Tech', 'wpuf-pro' ),
                ],
                'selected'        => [],
                'width'           => 'large',
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
            ],
            // Consent Field (Terms & Conditions)
            [
                'input_type'      => 'toc',
                'template'        => 'toc',
                'required'        => 'yes',
                'label'           => __( 'Consent', 'wpuf-pro' ),
                'name'            => 'survey_consent',
                'is_meta'         => 'yes',
                'help'            => __( 'Must agree to participate', 'wpuf-pro' ),
                'css'             => '',
                'description'     => __( 'I agree to participate in future surveys and consent to the collection and use of my demographic data for research purposes. I understand that my participation is voluntary and I may withdraw at any time.', 'wpuf-pro' ),
                'show_checkbox'   => 'yes',
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
            ],
        ];
    }

    /**
     * Get form setting definitions
     *
     * @since 4.2.12
     *
     * @return array
     */
    private function get_form_setting_definitions() {
        return [
            // General Settings
            'role'                       => 'subscriber',
            'user_status'                => 'on',
            'form_template'              => 'survey_panel_signup_template',

            // After Sign Up Settings
            'reg_redirect_to'            => 'same',
            'message'                    => __( 'Thank you for signing up for our survey panel! Your registration is pending approval. You will receive an email once your account has been reviewed.', 'wpuf-pro' ),
            'registration_url'           => '',

            // Profile Update Settings
            'profile_redirect_to'        => 'same',
            'update_message'             => __( 'Your survey panel profile has been updated successfully.', 'wpuf-pro' ),
            'profile_url'                => '',

            // Button Settings
            'submit_text'                => __( 'Sign Up for Survey Panel', 'wpuf-pro' ),
            'update_text'                => __( 'Update Profile', 'wpuf-pro' ),

            // Display Settings
            'label_position'             => 'above',
            'multistep_progressbar_type' => 'step_by_step',

            // Notification Settings
            'user_notification'          => 'off',
            'admin_notification'         => 'on',
            'notification_type'          => 'admin_approval',
            'notification'               => [
                'admin_email_subject' => __( 'New Survey Panel Signup', 'wpuf-pro' ),
                'admin_email_body'    => __( "A new user has signed up for the survey panel.\n\nUsername: {username}\nEmail: {user_email}\nDisplay Name: {display_name}\n\nUser Status: {user_status}", 'wpuf-pro' ),
            ],
        ];
    }

    /**
     * Run necessary processing after new insert (registration)
     *
     * @since 4.2.12
     *
     * @param int   $user_id       The user ID
     * @param int   $form_id       The form ID
     * @param array $form_settings The form settings
     *
     * @return void
     */
    public function after_insert( $user_id, $form_id, $form_settings ) {
        $this->handle_form_updates( $user_id, $form_id, $form_settings );
    }

    /**
     * Run necessary processing after editing a profile
     *
     * @since 4.2.12
     *
     * @param int   $user_id       The user ID
     * @param int   $form_id       The form ID
     * @param array $form_settings The form settings
     *
     * @return void
     */
    public function after_update( $user_id, $form_id, $form_settings ) {
        $this->handle_form_updates( $user_id, $form_id, $form_settings );
    }

    /**
     * Run the functions on update/insert
     *
     * Handle survey panel-specific data processing
     *
     * @since 4.2.12
     *
     * @param int   $user_id       The user ID
     * @param int   $form_id       The form ID
     * @param array $form_settings The form settings
     *
     * @return void
     */
    private function handle_form_updates( $user_id, $form_id, $form_settings ) {
        // Field-based meta (survey_age, survey_gender, survey_interests, survey_consent)
        // is auto-saved by WPUF for all is_meta:'yes' fields — no duplicate saves needed here.
        // Only save derived/non-field meta below.

        // phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce verified in parent handler
        // Record consent timestamp only when consent was given.
        if ( isset( $_POST['survey_consent'] ) ) {
            update_user_meta( $user_id, 'survey_consent_date', current_time( 'mysql' ) );
        }
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        // Mark user as a survey panel member
        update_user_meta( $user_id, 'is_survey_panel_member', 'yes' );
        update_user_meta( $user_id, 'survey_panel_joined', current_time( 'mysql' ) );

        /**
         * Action hook fired after survey panel data is saved
         *
         * @since 4.2.12
         *
         * @param int   $user_id       The user ID
         * @param int   $form_id       The form ID
         * @param array $form_settings The form settings
         */
        do_action( 'wpuf_survey_panel_data_saved', $user_id, $form_id, $form_settings );
    }
}
