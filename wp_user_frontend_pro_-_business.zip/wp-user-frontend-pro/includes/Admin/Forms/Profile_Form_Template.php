<?php
// phpcs:disable Generic.Arrays.DisallowShortArraySyntax.Found

namespace WeDevs\Wpuf\Pro\Admin\Forms;

use WeDevs\Wpuf\Admin\Forms\Form_Template;
use WeDevs\Wpuf\Frontend_Render_Form;
use WeDevs\Wpuf\Pro\Admin\FormBuilder\Render_Form;
use WeDevs\Wpuf\Pro\Admin\Forms\ProfileTemplates\Club_Association_Member_Template;
use WeDevs\Wpuf\Pro\Admin\Forms\ProfileTemplates\Dokan_Vendor_Reg_Template;
use WeDevs\Wpuf\Pro\Admin\Forms\ProfileTemplates\Community_Member_Join_Form_Template;
use WeDevs\Wpuf\Pro\Admin\Forms\ProfileTemplates\Personal_Blog_Author_Signup_Template;
use WeDevs\Wpuf\Pro\Admin\Forms\ProfileTemplates\Simple_User_Signup_Template;
use WeDevs\Wpuf\Pro\Admin\Forms\ProfileTemplates\Survey_Panel_Signup_Template;
use WeDevs\Wpuf\Pro\Admin\Forms\ProfileTemplates\WC_Marketplace_Reg_Template;
use WeDevs\Wpuf\Pro\Admin\Forms\ProfileTemplates\WC_Vendor_Reg_Template;

/**
 * Admin profile form template handler
 *
 * Create profile forms based on form templates
 *
 * @since 2.7
 */
class Profile_Form_Template {

    public function __construct() {
        // profile form templates
        // add_action( 'admin_footer', [ $this, 'render_profile_form_templates' ] );
        // dynamic hook. format: "admin_action_{$action}". more details: wp-admin/admin.php
        add_action( 'admin_action_wpuf_profile_form_template', [ $this, 'create_profile_form_from_template' ] );
        // form settings
        add_action( 'wpuf_profile_setting', [ $this, 'profile_form_settings' ], 8, 2 );
        // process registration errors
        add_filter( 'registration_errors', [ $this, 'register_errors' ], 10, 3 );
        add_filter( 'wpuf_duplicate_username_error', [ $this, 'duplicate_username_error' ], 10, 2 );
        // frontend insert/update
        add_action( 'wpuf_update_profile', [ $this, 'profile_form_submission' ], 10, 3 );
        add_action( 'wpuf_after_register', [ $this, 'profile_form_submission' ], 10, 3 );
    }

    /**
     * Should a form displayed or script enqueued?
     *
     * @return boolean
     */
    public function should_display() {
        $current_screen = get_current_screen();
        $submenu_hooks  = wpuf_pro()->admin->pro_menu->get_all_submenu_hooks();

        if ( ! empty( $submenu_hooks['profile_forms'] ) && $submenu_hooks['profile_forms'] === $current_screen->id ) {
            return true;
        }

        return false;
    }

    /**
     * Get profile form templates
     *
     * @return array
     */
    public function wpuf_get_profile_form_templates() {
        $integrations                                           = [];
        $integrations['simple_user_signup_template']            = new Simple_User_Signup_Template();
        $integrations['personal_blog_author_signup_template']   = new Personal_Blog_Author_Signup_Template();
        $integrations['community_member_join_form_template']    = new Community_Member_Join_Form_Template();
        $integrations['dokan_vendor_reg_template']              = new Dokan_Vendor_Reg_Template();
        $integrations['wc_vendor_reg_template']                 = new WC_Vendor_Reg_Template();
        $integrations['wc_marketplace_reg_template']            = new WC_Marketplace_Reg_Template();
        $integrations['survey_panel_signup_template']       = new Survey_Panel_Signup_Template();
        $integrations['club_association_member_template']   = new Club_Association_Member_Template();

        return apply_filters( 'wpuf_get_profile_form_templates', $integrations );
    }

    /**
     * Render the forms in the modal
     *
     * @return void
     */
    public function render_profile_form_templates() {
        if ( ! $this->should_display() ) {
            return;
        }

        $registry = $this->wpuf_get_profile_form_templates();
        $pro_templates = wpuf_get_pro_form_previews();
        $blank_form_url = admin_url( 'admin.php?page=wpuf-profile-forms&action=add-new' );
        $action_name = 'wpuf_profile_form_template';
        $footer_help = sprintf(
            // translators: %s is the mailto link for support email
            __( 'Want a new integration? <a href="%s" target="_blank">Let us know</a>.', 'wpuf-pro' ),
            'mailto:support@wedevs.com?subject=WPUF Custom Profile Template Integration Request'
        );

        if ( ! $registry ) {
            return;
        }

        // Use v4.2 modal (new design with better AI Forms support)
        $is_post_form = false; // This is a registration/profile form
        include WPUF_ROOT . '/includes/Admin/template-parts/modal-v4.2.php';
    }

    /**
     * Get a template object by name from the registry
     *
     * @param string $template
     *
     * @return boolean|Form_Template
     */
    public function get_template_object( $template ) {
        $registry = $this->wpuf_get_profile_form_templates();
        if ( ! array_key_exists( $template, $registry ) ) {
            return false;
        }

        $template_object = $registry[ $template ];

        if ( ! is_a( $template_object, 'WeDevs\Wpuf\Admin\Forms\Form_Template' ) ) {
            return false;
        }

        return $template_object;
    }

    /**
     * Create a profile form from a profile template
     *
     * @since 2.7
     *
     * @return void
     */
    public function create_profile_form_from_template() {
        check_admin_referer( 'wpuf_create_from_template' );
        $template_name = isset( $_GET['template'] ) ? sanitize_text_field( wp_unslash( $_GET['template'] ) ) : '';
        if ( ! $template_name ) {
            return;
        }

        // Check if this is an AI form request
        if ( 'ai_form' === $template_name ) {
            // Check if the free AI Form Handler class exists (without triggering autoload)
            if ( ! class_exists( 'WeDevs\Wpuf\Admin\Forms\AI_Form_Handler', false ) ) {
                wp_die(
                    esc_html__( 'AI Form Builder is not available. Please ensure WP User Frontend free version is installed and up to date.', 'wpuf-pro' ),
                    esc_html__( 'AI Form Builder Not Available', 'wpuf-pro' ),
                    [ 'back_link' => true ]
                );
            }

            // Delegate to the free plugin's AI Form Handler
            // The AI handler will automatically detect this is a profile form from the action parameter
            $ai_handler = new \WeDevs\Wpuf\Admin\Forms\AI_Form_Handler();
            $ai_handler->handle_ai_form_template();
            exit;
        }

        $template_object = $this->get_template_object( $template_name );
        if ( false === $template_object ) {
            return;
        }
        $current_user = get_current_user_id();
        $form_post_data = [
            'post_title'  => $template_object->get_title(),
            'post_type'   => 'wpuf_profile',
            'post_status' => 'publish',
            'post_author' => $current_user,
        ];
        $form_id = wp_insert_post( $form_post_data );
        if ( is_wp_error( $form_id ) ) {
            return;
        }
        // form has been created, lets setup
        update_post_meta( $form_id, 'wpuf_form_settings', $template_object->get_form_settings() );
        $form_fields = $template_object->get_form_fields();
        if ( ! $form_fields ) {
            return;
        }
        foreach ( $form_fields as $menu_order => $field ) {
            wp_insert_post(
                [
                    'post_type'    => 'wpuf_input',
                    'post_status'  => 'publish',
                    'post_content' => maybe_serialize( $field ),
                    'post_parent'  => $form_id,
                    'menu_order'   => $menu_order,
                ]
            );
        }
        wp_safe_redirect( admin_url( 'admin.php?page=wpuf-profile-forms&action=edit&id=' . $form_id ) );
        exit;
    }

    /**
     * Add settings field to override a form template
     *
     * @param array  $form_settings
     * @param object $_post Unused - required by hook signature.
     *
     * @return void
     */
    // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed -- Required by wpuf_profile_setting hook signature
    public function profile_form_settings( $form_settings, $_post ) {
        $registry = $this->wpuf_get_profile_form_templates();
        $selected = isset( $form_settings['form_template'] ) ? $form_settings['form_template'] : '';
        ?>
        <tr>
            <th>
                <?php esc_html_e( 'Form Template', 'wpuf-pro' ); ?>
            </th>
            <td>
                <select name="wpuf_settings[form_template]">
                    <option value="">
                        <?php esc_html_e( '— No Template —', 'wpuf-pro' ); ?>
                    </option>
                    <?php
                    if ( $registry ) {
                        foreach ( $registry as $key => $template ) {
                            printf(
                                '<option value="%s"%s>%s</option>' . "\n",
                                esc_attr( $key ),
                                selected( $selected, $key, false ),
                                esc_html( $template->get_title() )
                            );
                        }
                    }
                    ?>
                </select>
                <p class="description">
                    <?php
                    esc_html_e(
                        'If selected a form template, it will try to execute that integration options when new post created and updated.',
                        'wpuf-pro'
                    );
                    ?>
                </p>
            </td>
        </tr>
        <?php
    }

    /**
     * Call the integration functions on form submission/update
     *
     * @param int   $post_id
     * @param int   $form_id
     * @param array $form_settings
     *
     * @return void
     */
    public function profile_form_submission( $user_id, $form_id, $form_settings ) {
        $template = isset( $form_settings['form_template'] ) ? $form_settings['form_template'] : '';
        if ( ! $template ) {
            return;
        }
        $template_object = $this->get_template_object( $template );
        if ( false === $template_object ) {
            return;
        }
        $current_action = current_action();
        if ( 'wpuf_after_register' === $current_action ) {
            $template_object->after_insert( $user_id, $form_id, $form_settings );
        } elseif ( 'wpuf_update_profile' === $current_action ) {
            $template_object->after_update( $user_id, $form_id, $form_settings );
        }
    }

    /**
     * Process registration errors
     *
     * @param str $errors
     * @param str $_username  Unused - required by hook signature.
     * @param str $_user_email Unused - required by hook signature.
     *
     * @return str $errors
     */
    // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed -- Required by registration_errors filter signature
    public function register_errors( $errors, $_username, $_user_email ) {
        // phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce verified in WordPress registration flow
        // WC Vendor registration form: check the unique value of shop name
        $pv_shop_name = isset( $_POST['pv_shop_name'] ) ? sanitize_title( wp_unslash( $_POST['pv_shop_name'] ) ) : '';
        if ( ! empty( $pv_shop_name ) ) {
            // phpcs:disable WordPress.DB.SlowDBQuery.slow_db_query_meta_key, WordPress.DB.SlowDBQuery.slow_db_query_meta_value
            $users = get_users(
                [
                    'meta_key'   => 'pv_shop_slug',
                    'meta_value' => $pv_shop_name,
                ]
            );
            // phpcs:enable WordPress.DB.SlowDBQuery.slow_db_query_meta_key, WordPress.DB.SlowDBQuery.slow_db_query_meta_value
            if ( ! empty( $users ) && get_current_user_id() !== $users[0]->ID ) {
                ( new \WeDevs\Wpuf\Frontend_Render_Form() )->send_error(
                    __( 'That shop name is already taken. Your shop name must be unique.', 'wpuf-pro' )
                );
            }
        }
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        return $errors;
    }

    /**
     * Check unique username
     *
     * @param String   $username_error
     * @param array $form_settings
     *
     * @return String $username_error
     */
    public function duplicate_username_error( $username_error, $form_settings ) {
        $template = isset( $form_settings['form_template'] ) ? $form_settings['form_template'] : '';
        if ( 'wc_marketplace_reg_template' === $template ) {
            $username_error = __( 'That store name is already taken. Your store name must be unique.', 'wpuf-pro' );
        }

        return $username_error;
    }
}
