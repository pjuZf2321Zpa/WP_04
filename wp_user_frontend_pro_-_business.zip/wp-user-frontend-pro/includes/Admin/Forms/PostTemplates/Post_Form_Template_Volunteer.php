<?php

namespace WeDevs\Wpuf\Pro\Admin\Forms\PostTemplates;

use WeDevs\Wpuf\Admin\Forms\Form_Template;

/**
 * Volunteer Opportunity form template
 */
class Post_Form_Template_Volunteer extends Form_Template {

    public function __construct() {
        $this->enabled     = true;
        $this->title       = __( 'Volunteer Opportunity', 'wpuf-pro' );
        $this->description = __( 'Enable organizations, nonprofits, or community groups to post volunteer opportunities with detailed role descriptions, location, duration, skills required, and contact information.', 'wpuf-pro' );
        $this->image       = WPUF_PRO_ASSET_URI . '/images/templates/volunteer.svg';
        $this->form_fields = [
            // Opportunity Title (Post Title)
            [
                'input_type'      => 'text',
                'template'        => 'post_title',
                'required'        => 'yes',
                'label'           => 'Opportunity Title',
                'name'            => 'post_title',
                'is_meta'         => 'no',
                'help'            => 'A clear and concise title for the volunteer position.',
                'css'             => '',
                'placeholder'     => '',
                'default'         => '',
                'size'            => '40',
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
                'show_in_post'    => 'yes',
            ],
            // Organization Name (Text)
            [
                'input_type'      => 'text',
                'template'        => 'text_field',
                'required'        => 'yes',
                'label'           => 'Organization Name',
                'name'            => 'organization_name',
                'is_meta'         => 'yes',
                'help'            => 'The name of the group or charity posting this opportunity.',
                'css'             => '',
                'placeholder'     => '',
                'default'         => '',
                'size'            => '40',
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
                'show_in_post'    => 'yes',
            ],
            // Location (Address Field)
            [
                'input_type'           => 'address',
                'template'             => 'address_field',
                'required'             => 'yes',
                'label'                => 'Location',
                'name'                 => 'volunteer_location',
                'is_meta'              => 'yes',
                'help'                 => 'Please provide the primary location for this volunteer opportunity.',
                'css'                  => '',
                'address_desc'         => '',
                'address'              => [
                    'street_address'  => [
                        'checked'     => 'checked',
                        'type'        => 'text',
                        'required'    => '',
                        'label'       => __( 'Street', 'wpuf-pro' ),
                        'value'       => '',
                        'placeholder' => '',
                    ],
                    'street_address2' => [
                        'checked'     => '',
                        'type'        => 'text',
                        'required'    => '',
                        'label'       => __( 'Street 2', 'wpuf-pro' ),
                        'value'       => '',
                        'placeholder' => '',
                    ],
                    'city_name'       => [
                        'checked'     => 'checked',
                        'type'        => 'text',
                        'required'    => '',
                        'label'       => __( 'City', 'wpuf-pro' ),
                        'value'       => '',
                        'placeholder' => '',
                    ],
                    'state'           => [
                        'checked'     => 'checked',
                        'type'        => 'text',
                        'required'    => '',
                        'label'       => __( 'State', 'wpuf-pro' ),
                        'value'       => '',
                        'placeholder' => '',
                    ],
                    'zip'             => [
                        'checked'     => 'checked',
                        'type'        => 'text',
                        'required'    => '',
                        'label'       => __( 'Zip Code', 'wpuf-pro' ),
                        'value'       => '',
                        'placeholder' => '',
                    ],
                    'country_select'  => [
                        'checked'                          => 'checked',
                        'type'                             => 'select',
                        'required'                         => '',
                        'label'                            => __( 'Country', 'wpuf-pro' ),
                        'value'                            => '',
                        'country_list_visibility_opt_name' => 'all',
                        'country_select_hide_list'         => [],
                        'country_select_show_list'         => [],
                    ],
                ],
                'wpuf_cond'            => $this->conditionals,
                'wpuf_visibility'      => $this->get_default_visibility_prop(),
                'show_in_post'         => 'yes',
            ],
            // Opportunity Description (Post Content)
            [
                'input_type'          => 'textarea',
                'template'            => 'post_content',
                'required'            => 'yes',
                'label'               => 'Opportunity Description',
                'name'                => 'post_content',
                'is_meta'             => 'no',
                'help'                => 'Provide a full overview of duties & expectations.',
                'css'                 => '',
                'rows'                => '8',
                'cols'                => '25',
                'placeholder'         => '',
                'default'             => '',
                'rich'                => 'yes',
                'insert_image'        => 'no',
                'word_restriction'    => '',
                'wpuf_cond'           => $this->conditionals,
                'wpuf_visibility'     => $this->get_default_visibility_prop(),
                'text_editor_control' => [],
                'show_in_post'        => 'yes',
            ],
            // Benefits for Volunteers (Textarea)
            [
                'input_type'          => 'textarea',
                'template'            => 'textarea_field',
                'required'            => 'no',
                'label'               => 'Benefits for Volunteers',
                'name'                => 'volunteer_benefits',
                'is_meta'             => 'yes',
                'help'                => 'Describe any benefits for volunteers, such as skill development, networking, or impact.',
                'css'                 => '',
                'rows'                => '5',
                'cols'                => '25',
                'placeholder'         => '',
                'default'             => '',
                'rich'                => 'no',
                'insert_image'        => 'no',
                'word_restriction'    => '',
                'wpuf_cond'           => $this->conditionals,
                'wpuf_visibility'     => $this->get_default_visibility_prop(),
                'text_editor_control' => [],
                'show_in_post'        => 'yes',
            ],
            // Duration (Radio)
            [
                'input_type'      => 'radio',
                'template'        => 'radio_field',
                'required'        => 'yes',
                'label'           => 'Duration',
                'name'            => 'volunteer_duration',
                'is_meta'         => 'yes',
                'help'            => 'Select how long the volunteer commitment is expected to last.',
                'css'             => '',
                'selected'        => '',
                'inline'          => 'no',
                'options'         => [
                    'one_time' => 'One-time',
                    '2_weeks'  => '2 Weeks',
                    '3_months' => '3 Months',
                    'ongoing'  => 'Ongoing',
                ],
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
                'show_in_post'    => 'yes',
            ],
            // Start Date (Date / Time)
            [
                'input_type'      => 'date',
                'template'        => 'date_field',
                'required'        => 'no',
                'label'           => 'Start Date (if applicable)',
                'name'            => 'start_date',
                'is_meta'         => 'yes',
                'help'            => 'If applicable, specify when the volunteer opportunity begins.',
                'css'             => '',
                'format'          => 'mm/dd/yy',
                'time'            => 'yes',
                'placeholder'     => 'Select a date and time',
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
                'show_in_post'    => 'yes',
            ],
            // End Date (Date / Time)
            [
                'input_type'      => 'date',
                'template'        => 'date_field',
                'required'        => 'no',
                'label'           => 'End Date (if applicable)',
                'name'            => 'end_date',
                'is_meta'         => 'yes',
                'help'            => 'If applicable, specify when the volunteer opportunity concludes.',
                'css'             => '',
                'format'          => 'mm/dd/yy',
                'time'            => 'yes',
                'placeholder'     => 'Select a date and time',
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
                'show_in_post'    => 'yes',
            ],
            // Skills Required (Multi Select)
            [
                'input_type'      => 'multiselect',
                'template'        => 'multiple_select',
                'required'        => 'no',
                'label'           => 'Skills Required',
                'name'            => 'skills_required',
                'is_meta'         => 'yes',
                'help'            => 'Choose relevant skills or experience beneficial for this role (e.g., teaching, first aid, communication).',
                'css'             => '',
                'first'           => 'Start typing to find skills...',
                'options'         => [
                    'teaching'      => 'Teaching',
                    'first_aid'     => 'First Aid',
                    'communication' => 'Communication',
                    'leadership'    => 'Leadership',
                    'event_planning' => 'Event Planning',
                    'writing'       => 'Writing',
                    'marketing'     => 'Marketing',
                    'fundraising'   => 'Fundraising',
                    'counseling'    => 'Counseling',
                    'languages'     => 'Languages',
                    'technical'     => 'Technical Skills',
                    'driving'       => 'Driving',
                ],
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
                'show_in_post'    => 'yes',
            ],
            // Remote / On-site Option (Radio)
            [
                'input_type'      => 'radio',
                'template'        => 'radio_field',
                'required'        => 'yes',
                'label'           => 'Remote / On-site Option',
                'name'            => 'work_location_type',
                'is_meta'         => 'yes',
                'help'            => 'Indicate whether the opportunity is remote, on-site, or a hybrid.',
                'css'             => '',
                'selected'        => '',
                'inline'          => 'yes',
                'options'         => [
                    'remote'  => 'Remote',
                    'onsite'  => 'On-site',
                    'hybrid'  => 'Hybrid',
                ],
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
                'show_in_post'    => 'yes',
            ],
            // Age Requirement (Numeric Field)
            [
                'input_type'      => 'numeric_text',
                'template'        => 'numeric_text_field',
                'required'        => 'no',
                'label'           => 'Age Requirement',
                'name'            => 'age_requirement',
                'is_meta'         => 'yes',
                'help'            => 'If applicable, specify any minimum or maximum age requirement for volunteers.',
                'css'             => '',
                'placeholder'     => 'e.g., 18 (minimum)',
                'default'         => '',
                'size'            => '40',
                'step_text_field' => '1',
                'min_value_field' => '0',
                'max_value_field' => '100',
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
                'show_in_post'    => 'yes',
            ],
            // Weekly Time Commitment (Dropdown)
            [
                'input_type'      => 'select',
                'template'        => 'dropdown_field',
                'required'        => 'no',
                'label'           => 'Weekly Time Commitment',
                'name'            => 'time_commitment',
                'is_meta'         => 'yes',
                'help'            => 'Choose the estimated weekly hours or time flexibility.',
                'css'             => '',
                'first'           => 'Select commitment level',
                'options'         => [
                    'less_than_5'  => 'Less than 5 hours',
                    '5_to_10'      => '5–10 hours',
                    'full_time'    => 'Full Time',
                    'flexible'     => 'Flexible',
                ],
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
                'show_in_post'    => 'yes',
            ],
            // Application Deadline (Date / Time)
            [
                'input_type'      => 'date',
                'template'        => 'date_field',
                'required'        => 'no',
                'label'           => 'Application Deadline',
                'name'            => 'application_deadline',
                'is_meta'         => 'yes',
                'help'            => 'The last date by which applications for this opportunity will be accepted.',
                'css'             => '',
                'format'          => 'mm/dd/yy',
                'time'            => 'yes',
                'placeholder'     => 'Select a date and time',
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
                'show_in_post'    => 'yes',
            ],
            // Upload Flyer / Poster (File Upload)
            [
                'input_type'      => 'file_upload',
                'template'        => 'file_upload',
                'required'        => 'no',
                'label'           => 'Upload Flyer / Poster',
                'name'            => 'volunteer_flyer',
                'is_meta'         => 'yes',
                'help'            => 'Share promotional PDFs or posters related to this opportunity. Max size: 5MB. Accepted formats: PDF, JPG, PNG.',
                'css'             => '',
                'max_size'        => '5120',
                'count'           => '3',
                'extension'       => [ 'images', 'pdf' ],
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
                'show_in_post'    => 'yes',
            ],
            // Contact Email (Email Address)
            [
                'input_type'      => 'email',
                'template'        => 'email_address',
                'required'        => 'yes',
                'label'           => 'Contact Email',
                'name'            => 'contact_email',
                'is_meta'         => 'yes',
                'help'            => '',
                'css'             => '',
                'placeholder'     => 'Enter contact email',
                'default'         => '',
                'size'            => '40',
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
                'show_in_post'    => 'yes',
            ],
            // Phone Number (Phone Field)
            [
                'input_type'        => 'phone',
                'template'          => 'phone_field',
                'required'          => 'no',
                'label'             => 'Phone Number',
                'name'              => 'contact_phone',
                'is_meta'           => 'yes',
                'help'              => '',
                'css'               => '',
                'placeholder'       => 'Enter phone number',
                'default'           => '',
                'size'              => '40',
                'show_country_list' => 'yes',
                'auto_placeholder'  => 'yes',
                'country_list'      => [
                    'name'                             => '',
                    'country_list_visibility_opt_name' => 'all',
                    'country_select_show_list'         => [],
                    'country_select_hide_list'         => [],
                ],
                'wpuf_cond'         => $this->conditionals,
                'wpuf_visibility'   => $this->get_default_visibility_prop(),
                'show_in_post'      => 'yes',
            ],
            // Website / Application Link (Website URL)
            [
                'input_type'      => 'website_url',
                'template'        => 'website_url',
                'required'        => 'no',
                'label'           => 'Website / Application Link',
                'name'            => 'website_link',
                'is_meta'         => 'yes',
                'help'            => '',
                'css'             => '',
                'placeholder'     => 'Enter your website URL',
                'default'         => '',
                'size'            => '40',
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
                'show_in_post'    => 'yes',
            ],
            // Terms Agreement (Terms & Conditions)
            [
                'input_type'      => 'toc',
                'template'        => 'toc',
                'required'        => 'yes',
                'label'           => 'Terms Agreement',
                'name'            => 'terms_agreement',
                'is_meta'         => 'yes',
                'help'            => 'Please review and agree to our terms and community guidelines.',
                'css'             => '',
                'description'     => 'I agree to the terms and conditions of this volunteer opportunity platform.',
                'show_checkbox'   => 'yes',
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
                'show_in_post'    => 'yes',
            ],
        ];
        $this->form_settings = [
            'post_type'          => 'post',
            'expiration_settings' => [],
            'post_status'        => 'draft',
            'default_cat'        => '-1',
            'post_permission'    => 'guest_post',
            'guest_post'         => 'true',
            'guest_details'      => 'on',
            'name_label'         => 'Name',
            'email_label'        => 'E-Mail',
            'guest_email_verify' => 'on',
            'message_restrict'   => 'This page is restricted. Please Log in / Register to view this page.',
            'redirect_to'        => 'same',
            'message'            => 'Thank you for submitting your volunteer opportunity!

Your listing has been received and is pending review. We\'ll notify you once it\'s approved and live. To submit another opportunity, please fill out the form again.',
            'comment_status'     => 'closed',
            'submit_text'        => 'Submit Opportunity',
            'submit_button_cond' => [
                'condition_status' => 'no',
                'cond_logic'       => 'any',
                'conditions'       => [
                    [
                        'name'     => '',
                        'operator' => '=',
                        'option'   => '',
                    ],
                ],
            ],
            'draft_post'         => 'true',
            'edit_post_status'   => 'draft',
            'edit_redirect_to'   => 'same',
            'update_message'     => 'Your posted opportunity has been updated!',
            'edit_url'           => '',
            'update_text'        => 'Update Opportunity',
            'show_form_title'    => 'yes',
            'form_description'   => 'Thank you for helping build a stronger community!

Use this form to submit a volunteer opportunity on behalf of your organization or initiative. Please include important details such as the role description, location, duration, required skills, and how volunteers can get involved.

Submissions will be reviewed before being published. If you have multiple opportunities, submit each one separately.',
            'form_template'      => 'post_form_template_volunteer',
            'notification_edit'  => 'on',
            'notification_edit_to' => get_option( 'admin_email' ),
            'notification_edit_subject' => 'Volunteer opportunity has been updated',
            'notification_edit_body' => 'Hi,
The volunteer opportunity "{post_title}" has been updated.

Here are the details:
Opportunity Title: {post_title}
Organization Name: {organization_name}
Location: {volunteer_location}
Duration: {volunteer_duration}
Remote/On-site: {work_location_type}
Time Commitment: {time_commitment}
Contact Email: {contact_email}
Contact Phone: {contact_phone}
Website: {website_link}
Application Deadline: {application_deadline}

Description:
{post_content}

Benefits for Volunteers:
{volunteer_benefits}

Skills Required: {skills_required}

Author: {author}
Post URL: {permalink}
Edit URL: {editlink}',
            'notification'       => [
                'new'          => 'on',
                'new_to'       => get_option( 'admin_email' ),
                'new_subject'  => 'New volunteer opportunity submission',
                'new_body'     => 'Hi,
A new volunteer opportunity has been submitted to your site {sitename} ({siteurl}).

Here are the details:
Opportunity Title: {post_title}
Organization Name: {organization_name}
Location: {volunteer_location}
Duration: {volunteer_duration}
Remote/On-site: {work_location_type}
Time Commitment: {time_commitment}
Contact Email: {contact_email}
Contact Phone: {contact_phone}
Website: {website_link}
Application Deadline: {application_deadline}

Description:
{post_content}

Benefits for Volunteers:
{volunteer_benefits}

Skills Required: {skills_required}

Author: {author}
Post URL: {permalink}
Edit URL: {editlink}',
                'edit'         => 'on',
                'edit_to'      => get_option( 'admin_email' ),
                'edit_subject' => 'Volunteer opportunity has been updated',
                'edit_body'    => 'Hi,
The volunteer opportunity "{post_title}" has been updated.

Here are the details:
Opportunity Title: {post_title}
Organization Name: {organization_name}
Location: {volunteer_location}
Duration: {volunteer_duration}
Remote/On-site: {work_location_type}
Time Commitment: {time_commitment}
Contact Email: {contact_email}
Contact Phone: {contact_phone}
Website: {website_link}
Application Deadline: {application_deadline}

Description:
{post_content}

Benefits for Volunteers:
{volunteer_benefits}

Skills Required: {skills_required}

Author: {author}
Post URL: {permalink}
Edit URL: {editlink}'
            ],
        ];
    }
}
