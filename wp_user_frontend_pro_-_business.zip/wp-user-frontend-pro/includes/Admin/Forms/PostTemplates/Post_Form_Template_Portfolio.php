<?php

namespace WeDevs\Wpuf\Pro\Admin\Forms\PostTemplates;

use WeDevs\Wpuf\Admin\Forms\Form_Template;

/**
 * Portfolio Submission form template
 */
class Post_Form_Template_Portfolio extends Form_Template {

    public function __construct() {
        $this->enabled     = true;
        $this->title       = __( 'Portfolio Submission', 'wpuf-pro' );
        $this->description = __( 'Showcase your work with this portfolio submission form. Perfect for individuals or agencies to submit projects with key details and visual assets.', 'wpuf-pro' );
        $this->image       = WPUF_PRO_ASSET_URI . '/images/templates/portfolio.svg';
        $this->form_fields = [
            // Project Title (Post Title)
            [
                'input_type'      => 'text',
                'template'        => 'post_title',
                'required'        => 'yes',
                'label'           => 'Project Title',
                'name'            => 'post_title',
                'is_meta'         => 'no',
                'help'            => 'What\'s your project called?',
                'css'             => '',
                'placeholder'     => 'e.g., Responsive E-commerce Website Redesign',
                'default'         => '',
                'size'            => '40',
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
                'show_in_post'    => 'yes',
            ],
            // Project Description (Post Content)
            [
                'input_type'          => 'textarea',
                'template'            => 'post_content',
                'required'            => 'yes',
                'label'               => 'Project Description',
                'name'                => 'post_content',
                'is_meta'             => 'no',
                'help'                => '',
                'css'                 => '',
                'rows'                => '10',
                'cols'                => '25',
                'placeholder'         => 'Briefly describe your project...',
                'default'             => '',
                'rich'                => 'yes',
                'insert_image'        => 'yes',
                'word_restriction'    => '',
                'wpuf_cond'           => $this->conditionals,
                'wpuf_visibility'     => $this->get_default_visibility_prop(),
                'text_editor_control' => [],
                'show_in_post'        => 'yes',
            ],
            // Client Name (Text)
            [
                'input_type'      => 'text',
                'template'        => 'text_field',
                'required'        => 'no',
                'label'           => 'Client Name',
                'name'            => 'client_name',
                'is_meta'         => 'yes',
                'help'            => 'Who was this project for?',
                'css'             => '',
                'placeholder'     => 'Enter client name',
                'default'         => '',
                'size'            => '40',
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
                'show_in_post'    => 'yes',
            ],
            // Project URL (Website URL)
            [
                'input_type'      => 'website_url',
                'template'        => 'website_url',
                'required'        => 'yes',
                'label'           => 'Project URL',
                'name'            => 'project_url',
                'is_meta'         => 'yes',
                'help'            => 'A direct link to the live project or demo.',
                'css'             => '',
                'placeholder'     => 'Enter Project URL',
                'default'         => '',
                'size'            => '40',
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
                'show_in_post'    => 'yes',
            ],
            // Featured Image
            [
                'input_type'      => 'image_upload',
                'template'        => 'featured_image',
                'count'           => '1',
                'required'        => 'yes',
                'label'           => 'Featured Image',
                'name'            => 'featured_image',
                'button_label'    => 'Upload Featured Image',
                'is_meta'         => 'no',
                'help'            => 'Choose the best image to represent your project.',
                'css'             => '',
                'max_size'        => '5120',
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
                'show_in_post'    => 'yes',
            ],
            // Tags
            [
                'input_type'      => 'text',
                'template'        => 'post_tags',
                'required'        => 'yes',
                'label'           => 'Tags',
                'name'            => 'tags',
                'is_meta'         => 'no',
                'help'            => 'Add keywords to describe your project.',
                'css'             => '',
                'placeholder'     => '',
                'default'         => '',
                'size'            => '40',
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
                'show_in_post'    => 'yes',
            ],
            // Project Type (Category)
            [
                'input_type'      => 'taxonomy',
                'template'        => 'taxonomy',
                'required'        => 'no',
                'label'           => 'Project Type',
                'name'            => 'category',
                'is_meta'         => 'no',
                'help'            => 'What kind of project is this?',
                'first'           => __( 'Select a category', 'wpuf-pro' ),
                'css'             => '',
                'type'            => 'select',
                'orderby'         => 'name',
                'order'           => 'ASC',
                'exclude_type'    => 'exclude',
                'exclude'         => [],
                'woo_attr'        => 'no',
                'woo_attr_vis'    => 'no',
                'options'         => [],
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
                'show_in_post'    => 'yes',
            ],
            // Additional Images/Files (File Upload)
            [
                'input_type'      => 'file_upload',
                'template'        => 'file_upload',
                'required'        => 'no',
                'label'           => 'Additional Images/Files',
                'name'            => 'additional_files',
                'is_meta'         => 'yes',
                'help'            => 'Add supporting visuals or related documents.',
                'css'             => '',
                'max_size'        => '5120',
                'count'           => '5',
                'extension'       => [ 'images', 'pdf', 'office' ],
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
                'show_in_post'    => 'yes',
            ],
            // Completion Date (Date)
            [
                'input_type'      => 'date',
                'template'        => 'date_field',
                'required'        => 'no',
                'label'           => 'Completion Date',
                'name'            => 'completion_date',
                'is_meta'         => 'yes',
                'help'            => 'When did you finish this project?',
                'css'             => '',
                'format'          => 'mm/dd/yy',
                'time'            => 'no',
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
                'show_in_post'    => 'yes',
            ],
            // Your Role on Project (Text)
            [
                'input_type'      => 'text',
                'template'        => 'text_field',
                'required'        => 'no',
                'label'           => 'Your Role on Project',
                'name'            => 'project_role',
                'is_meta'         => 'yes',
                'help'            => 'If it was a team effort, what was your specific contribution?',
                'css'             => '',
                'placeholder'     => 'Enter your project role',
                'default'         => '',
                'size'            => '40',
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
                'show_in_post'    => 'yes',
            ],
        ];
        $this->form_settings = [
            'post_type'          => 'post',
            'expiration_settings' => [],
            'post_status'        => 'publish',
            'default_cat'        => '-1',
            'post_permission'    => 'guest_post',
            'guest_post'         => 'true',
            'guest_details'      => 'on',
            'name_label'         => 'Name',
            'email_label'        => 'E-Mail',
            'guest_email_verify' => 'on',
            'message_restrict'   => 'This page is restricted. Please Log in / Register to view this page.',
            'redirect_to'        => 'same',
            'comment_status'     => 'closed',
            'submit_text'        => 'Submit Portfolio',
            'submit_button_cond' => [
                'condition_status' => 'no',
                'cond_logic'       => 'any',
                'conditions'       => [
                    [
                        'name'     => '',
                        'operator' => '=',
                        'option'   => '',
                    ],
                ],
            ],
            'draft_post'         => 'true',
            'edit_post_status'   => 'draft',
            'edit_redirect_to'   => 'same',
            'update_message'     => 'Your portfolio project has been updated successfully!',
            'edit_url'           => '',
            'update_text'        => 'Update Portfolio',
            'form_template'      => 'post_form_template_portfolio',
            'notification'       => [
                'new'          => 'on',
                'new_to'       => get_option( 'admin_email' ),
                'new_subject'  => 'New portfolio submission',
                'new_body'     => 'Hi,
A new portfolio project has been submitted to your site {sitename} ({siteurl}).

Here are the details:
Project Title: {post_title}
Project Description: {post_content}
Client Name: {client_name}
Project URL: {project_url}
Completion Date: {completion_date}
Role on Project: {project_role}
Author: {author}
Post URL: {permalink}
Edit URL: {editlink}',
                'edit'         => 'on',
                'edit_to'      => get_option( 'admin_email' ),
                'edit_subject' => 'Portfolio project has been updated',
                'edit_body'    => 'Hi,
The portfolio project "{post_title}" has been updated.

Here are the details:
Project Title: {post_title}
Client Name: {client_name}
Project URL: {project_url}
Completion Date: {completion_date}
Role on Project: {project_role}
Author: {author}
Post URL: {permalink}
Edit URL: {editlink}'
            ],
        ];
    }
}
