<?php

namespace WeDevs\Wpuf\Pro\Admin\Forms\PostTemplates;

use WeDevs\Wpuf\Admin\Forms\Form_Template;

/**
 * Testimonial submission form template
 */
class Post_Form_Template_Testimonial extends Form_Template {

    public function __construct() {
        parent::__construct();

        $this->enabled     = true;
        $this->title       = __( 'Testimonial Submission', 'wpuf-pro' );
        $this->description = __( 'Form for collecting client testimonials with ratings and feedback.', 'wpuf-pro' );
        $this->image       = WPUF_PRO_ASSET_URI . '/images/templates/testimonial.svg';
        $this->form_fields = [
            [
                'input_type'       => 'text',
                'template'         => 'post_title',
                'required'         => 'yes',
                'label'            => __( 'Testimonial Title', 'wpuf-pro' ),
                'name'             => 'post_title',
                'is_meta'          => 'no',
                'help'             => '',
                'css'              => '',
                'placeholder'      => __( 'A brief, catchy headline for your testimonial', 'wpuf-pro' ),
                'default'          => '',
                'size'             => '40',
                'wpuf_cond'        => $this->conditionals,
                'wpuf_visibility'  => $this->get_default_visibility_prop(),
                'restriction_to'   => 'max',
                'restriction_type' => 'character',
                'width'            => 'large',
            ],
            [
                'input_type'       => 'text',
                'template'         => 'text_field',
                'required'         => 'yes',
                'label'            => __( 'Client Name', 'wpuf-pro' ),
                'name'             => 'client_name',
                'is_meta'          => 'yes',
                'help'             => '',
                'css'              => '',
                'placeholder'      => __( 'Your full name', 'wpuf-pro' ),
                'default'          => '',
                'size'             => '40',
                'wpuf_cond'        => $this->conditionals,
                'wpuf_visibility'  => $this->get_default_visibility_prop(),
                'restriction_to'   => 'max',
                'restriction_type' => 'character',
                'width'            => 'large',
                'show_in_post'     => 'yes',
                'hide_field_label' => 'no',
            ],
            [
                'input_type'      => 'checkbox',
                'template'        => 'checkbox_field',
                'required'        => 'yes',
                'label'           => __( 'Testimonial About', 'wpuf-pro' ),
                'name'            => 'testimonial_about',
                'is_meta'         => 'yes',
                'help'            => __( 'This testimonial is about...', 'wpuf-pro' ),
                'css'             => '',
                'show_icon'       => 'no',
                'inline'          => 'no',
                'options'         => [
                    'product'            => __( 'Product', 'wpuf-pro' ),
                    'service'            => __( 'Service', 'wpuf-pro' ),
                    'support'            => __( 'Support', 'wpuf-pro' ),
                    'overall_experience' => __( 'Overall Experience', 'wpuf-pro' ),
                ],
                'selected'        => [],
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
                'width'           => 'large',
                'show_in_post'    => 'yes',
                'hide_field_label' => 'no',
            ],
            [
                'input_type'          => 'textarea',
                'template'            => 'post_content',
                'required'            => 'yes',
                'label'               => __( 'Your Testimonial', 'wpuf-pro' ),
                'name'                => 'post_content',
                'is_meta'             => 'no',
                'help'                => __( 'Share your full experience and feedback here.', 'wpuf-pro' ),
                'css'                 => '',
                'rows'                => '5',
                'cols'                => '25',
                'placeholder'         => '',
                'default'             => '',
                'rich'                => 'yes',
                'insert_image'        => 'yes',
                'wpuf_cond'           => $this->conditionals,
                'wpuf_visibility'     => $this->get_default_visibility_prop(),
                'restriction_to'      => 'max',
                'restriction_type'    => 'character',
                'text_editor_control' => [],
                'width'               => 'large',
            ],
            [
                'input_type'       => 'ratings',
                'template'         => 'ratings',
                'required'         => 'yes',
                'label'            => __( 'Rating', 'wpuf-pro' ),
                'name'             => 'testimonial_rating',
                'is_meta'          => 'yes',
                'help'             => '',
                'css'              => '',
                'show_icon'        => 'no',
                'selected'         => '',
                'options'          => [
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                    '5' => '5',
                ],
                'inline'           => 'no',
                'wpuf_cond'        => $this->conditionals,
                'wpuf_visibility'  => $this->get_default_visibility_prop(),
                'width'            => 'large',
                'show_in_post'     => 'yes',
                'hide_field_label' => 'no',
            ],
            [
                'input_type'       => 'image_upload',
                'template'         => 'image_upload',
                'required'         => 'no',
                'label'            => __( 'Client Photo', 'wpuf-pro' ),
                'button_label'     => __( 'Upload Photo', 'wpuf-pro' ),
                'name'             => 'client_photo',
                'is_meta'          => 'yes',
                'help'             => __( 'Upload a photo of yourself to accompany your testimonial (optional).', 'wpuf-pro' ),
                'css'              => '',
                'max_size'         => '2048',
                'count'            => '1',
                'readonly'         => 'no',
                'show_icon'        => 'no',
                'wpuf_cond'        => $this->conditionals,
                'wpuf_visibility'  => $this->get_default_visibility_prop(),
                'width'            => 'large',
                'show_in_post'     => 'yes',
                'hide_field_label' => 'no',
            ],
            [
                'input_type'      => 'email',
                'template'        => 'email_address',
                'required'        => 'no',
                'label'           => __( 'Client Email', 'wpuf-pro' ),
                'name'            => 'client_email',
                'is_meta'         => 'yes',
                'help'            => __( 'Your email address for follow-up (won\'t be made public).', 'wpuf-pro' ),
                'css'             => '',
                'show_icon'       => 'no',
                'placeholder'     => '',
                'default'         => '',
                'size'            => '40',
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
                'width'           => 'large',
                'show_in_post'    => 'yes',
                'hide_field_label' => 'no',
            ],
            [
                'input_type'      => 'website_url',
                'template'        => 'website_url',
                'required'        => 'no',
                'label'           => __( 'Client Website', 'wpuf-pro' ),
                'name'            => 'client_website',
                'is_meta'         => 'yes',
                'help'            => __( 'A link to your website or social media profile (optional).', 'wpuf-pro' ),
                'css'             => '',
                'placeholder'     => __( 'https://your-website.com', 'wpuf-pro' ),
                'default'         => '',
                'size'            => '40',
                'wpuf_cond'       => $this->conditionals,
                'wpuf_visibility' => $this->get_default_visibility_prop(),
                'width'           => 'large',
                'show_in_post'    => 'yes',
                'hide_field_label' => 'no',
            ],
            [
                'input_type'       => 'toc',
                'template'         => 'toc',
                'label'            => '',
                'name'             => 'terms_and_conditions',
                'is_meta'          => 'yes',
                'description'      => __( 'I have read and agree to the <a href="#">Terms and Conditions</a> and <a href="#">Privacy Policy</a>', 'wpuf-pro' ),
                'show_checkbox'    => true,
                'css'              => '',
                'wpuf_cond'        => $this->conditionals,
                'wpuf_visibility'  => $this->get_default_visibility_prop(),
                'width'            => 'large',
                'show_in_post'     => 'yes',
                'hide_field_label' => 'no',
            ],
        ];

        $this->form_settings = [
            'post_type'          => 'post',
            'post_status'        => 'draft',
            'default_cat'        => '-1',
            'post_permission'    => '-1',
            'guest_post'         => 'false',
            'show_form_title'    => 'yes',
            'form_description'   => __( 'Share your feedback and tell us what you loved. Your testimonial helps us improve and lets others know what to expect. Thanks for taking the time to share your thoughts.', 'wpuf-pro' ),
            'message_restrict'   => __( 'This page is restricted. Please {login} / {register} to view this page.', 'wpuf-pro' ),
            'redirect_to'        => 'same',
            'message'            => __( 'Thanks so much for taking the time to share your experience with us. We really appreciate your feedback!', 'wpuf-pro' ),
            'comment_status'     => 'closed',
            'draft_post'         => 'true',
            'submit_text'        => __( 'Submit Testimonial', 'wpuf-pro' ),
            'submit_button_cond' => [
                'condition_status' => 'no',
                'cond_logic'       => 'any',
                'conditions'       => [
                    [
                        'name'     => '',
                        'operator' => '=',
                        'option'   => '',
                    ],
                ],
            ],
            'edit_post_status'   => 'draft',
            'edit_redirect_to'   => 'same',
            'update_message'     => __( 'Your testimonial has been updated!', 'wpuf-pro' ),
            'edit_url'           => '',
            'update_text'        => __( 'Update Testimonial', 'wpuf-pro' ),
            'form_template'      => 'post_form_template_testimonial',
            'notification'       => [
                'new'          => 'on',
                'new_to'       => get_option( 'admin_email' ),
                'new_subject'  => 'New testimonial submitted',
                'new_body'     => 'Hi,
A new testimonial has been submitted to your site {sitename} ({siteurl}).

Here are the details:
Testimonial Title: {post_title}
Client Name: {client_name}
Testimonial: {post_content}
Author: {author}
Post URL: {permalink}
Edit URL: {editlink}',
                'edit'         => 'on',
                'edit_to'      => get_option( 'admin_email' ),
                'edit_subject' => 'Testimonial has been updated',
                'edit_body'    => 'Hi,
The testimonial "{post_title}" has been updated.

Here are the details:
Testimonial Title: {post_title}
Client Name: {client_name}
Testimonial: {post_content}
Author: {author}
Post URL: {permalink}
Edit URL: {editlink}',
            ],
        ];
    }
}
