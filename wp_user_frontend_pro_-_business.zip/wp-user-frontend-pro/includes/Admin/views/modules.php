<?php
    $modules = wpuf_pro_get_modules();

    // Split modules by the current plan tier (see functions/modules.php).
    $my_modules    = array();
    $other_modules = array();

    foreach ( $modules as $slug => $module ) {
        if ( wpuf_pro_is_module_allowed( $slug ) ) {
            $my_modules[ $slug ] = $module;
        } else {
            $other_modules[ $slug ] = $module;
        }
    }

    $current_plan = function_exists( 'wpuf_pro_current_plan' ) ? wpuf_pro_current_plan() : '';
    $plan_label   = $current_plan ? ucwords( str_replace( '-', ' ', $current_plan ) ) : '';

    /**
     * Render a single module card.
     *
     * @param string $slug
     * @param array  $module
     * @param bool   $locked
     */
    $wpuf_render_module_card = function ( $slug, $module, $locked ) {
        ?>
        <div class="plugin-card<?php echo $locked ? ' wpuf-module-locked' : ''; ?>">
            <div class="plugin-card-top">
                <div class="name column-name">
                    <h3>
                        <span class="plugin-name"><a href="<?php echo $module['plugin_uri']; ?>" target="_blank"><?php echo $module['name']; ?></a></span>
                        <a href="<?php echo $module['plugin_uri']; ?>" target="_blank"><img class="plugin-icon" src="<?php echo WPUF_ASSET_URI . '/images/modules/' . $module['thumbnail']; ?>" alt="" /></a>
                    </h3>
                </div>

                <div class="action-links">
                    <ul class="plugin-action-buttons">
                        <li data-module="<?php echo $slug; ?>">
                            <?php if ( $locked ) : ?>
                                <?php
                                    $required_plan  = wpuf_pro_module_required_plan( $slug );
                                    $required_label = $required_plan ? ucwords( str_replace( '-', ' ', $required_plan ) ) : '';
                                ?>
                                <span class="wpuf-module-upgrade" title="<?php echo $required_label ? esc_attr( sprintf( __( 'Available in the %s plan', 'wpuf-pro' ), $required_label ) ) : esc_attr__( 'Not available in your current plan', 'wpuf-pro' ); ?>">
                                    <span class="dashicons dashicons-lock"></span>
                                    <a href="https://wedevs.com/wp-user-frontend-pro/pricing/" target="_blank">
                                        <?php
                                        if ( $required_label ) {
                                            /* translators: %s: plan name */
                                            printf( esc_html__( 'Upgrade to %s', 'wpuf-pro' ), esc_html( $required_label ) );
                                        } else {
                                            esc_html_e( 'Upgrade', 'wpuf-pro' );
                                        }
                                        ?>
                                    </a>
                                </span>
                            <?php else : ?>
                                <label class="wpuf-toggle-switch">
                                    <input style="display: none;" type="checkbox" <?php echo wpuf_pro_is_module_active( $slug ) ? 'checked' : ''; ?> name="module_toggle" class="wpuf-toggle-module">
                                    <span class="slider round"></span>
                                </label>
                            <?php endif ?>
                        </li>
                    </ul>
                    <div class="wpuf-doc-link" ><a href="<?php echo $module['plugin_uri']; ?>" target="_blank">Documentation</a></div>
                </div>

                <div class="desc column-description">
                    <p>
                        <?php echo $module['description']; ?>
                    </p>
                </div>
            </div>
        </div>
        <?php
    };
?>
<style>
    .wpuf-modules-section-title { display: flex; align-items: center; gap: 8px; font-size: 16px; font-weight: 600; margin: 24px 0 4px; }
    .wpuf-modules-count { display: inline-flex; align-items: center; justify-content: center; min-width: 20px; height: 20px; padding: 0 6px; border-radius: 999px; background: #d1fae5; color: #047857; font-size: 12px; font-weight: 600; }
    .wpuf-modules-section-desc { color: #6b7280; margin: 0 0 12px; }
    .wpuf-plan-badge { display: inline-flex; align-items: center; margin-left: 10px; padding: 2px 10px; border-radius: 999px; background: #d1fae5; color: #047857; font-size: 12px; font-weight: 600; vertical-align: middle; box-shadow: inset 0 0 0 1px rgba(5,150,105,.2); }
    .wpuf-module-locked { opacity: .85; }
    .wpuf-module-upgrade { display: inline-flex; align-items: center; gap: 4px; }
    .wpuf-module-upgrade .dashicons-lock { color: #9ca3af; }
</style>
<div class="wrap weforms-modules">
    <div class="activate-deactivate-all">
        <span id="activate-all-modules"><?php esc_attr_e( 'Activate All', 'wpuf-pro' ); ?></span> |
        <span id="deactivate-all-modules"><?php esc_attr_e( 'Deactivate All', 'wpuf-pro' ); ?></span>
    </div>

    <h1>
        <?php esc_attr_e( 'Modules', 'wpuf-pro' ); ?>
        <?php if ( $plan_label ) : ?>
            <span class="wpuf-plan-badge"><?php echo esc_html( $plan_label ); ?> <?php esc_html_e( 'plan', 'wpuf-pro' ); ?></span>
        <?php endif ?>
    </h1>

    <?php if ( ! $modules ) : ?>
        <p><?php esc_attr_e( 'No modules found.', 'wpuf-pro' ); ?></p>
    <?php endif ?>

    <?php if ( $my_modules ) : ?>
        <h2 class="wpuf-modules-section-title">
            <?php esc_html_e( 'My Modules', 'wpuf-pro' ); ?>
            <span class="wpuf-modules-count"><?php echo count( $my_modules ); ?></span>
        </h2>
        <div class="wp-list-table widefat wpuf-modules">
            <?php foreach ( $my_modules as $slug => $module ) { $wpuf_render_module_card( $slug, $module, false ); } ?>
        </div>
    <?php endif ?>

    <?php if ( $other_modules ) : ?>
        <h2 class="wpuf-modules-section-title">
            <?php esc_html_e( 'Other Modules', 'wpuf-pro' ); ?>
            <span class="wpuf-modules-count"><?php echo count( $other_modules ); ?></span>
        </h2>
        <p class="wpuf-modules-section-desc"><?php esc_html_e( 'Upgrade your plan to unlock these modules.', 'wpuf-pro' ); ?></p>
        <div class="wp-list-table widefat wpuf-modules">
            <?php foreach ( $other_modules as $slug => $module ) { $wpuf_render_module_card( $slug, $module, true ); } ?>
        </div>
    <?php endif ?>

</div>
