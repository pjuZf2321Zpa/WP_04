<div class="wpuf-bg-white">
    <div class="wpuf-px-6 wpuf-py-24 sm:wpuf-px-6 sm:wpuf-py-32 lg:wpuf-px-8">
        <div class="wpuf-mx-auto wpuf-w-2/3 wpuf-text-center">
            <h2 class="text-balance wpuf-text-4xl wpuf-font-semibold wpuf-tracking-tight wpuf-text-gray-900 sm:wpuf-text-5xl">WP User Frontend Core Update Required</h2>
            <p class="wpuf-mx-auto wpuf-mt-6 wpuf-text-pretty wpuf-text-lg wpuf-text-gray-600">We've made significant improvements to our form builder, including a complete UI/UX revamp, enhancing both design and usability. <span class="wpuf-font-bold">These updates require WP User Frontend latest version</span>. Please update to the latest version to enjoy a seamless experience with the improved form builder.</p>
            <div class="wpuf-mt-10 wpuf-flex wpuf-items-center wpuf-justify-center wpuf-gap-x-6">
                <a href="<?php echo admin_url('plugins.php'); ?>" class="wpuf-btn-primary">Update to Latest</a>
                <a href="<?php echo esc_url( 'https://wedevs.com/blog/504745/wp-user-frontend-release-march-2025/' ); ?>" target="_blank" class="wpuf-btn-secondary">Learn more <span aria-hidden="true">→</span></a>
            </div>
        </div>
    </div>
</div>
