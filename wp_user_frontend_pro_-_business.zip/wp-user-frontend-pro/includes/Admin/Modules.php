<?php

namespace WeDevs\Wpuf\Pro\Admin;

/**
 * The modules class
 */
class Modules {

    /**
     * Toggle module
     *
     * @since 2.7
     *
     * @return void
     **/
    public function toggle_module() {
        check_ajax_referer( 'wpuf-admin-nonce', 'nonce' );

        if ( ! current_user_can( wpuf_admin_role() ) ) {
            wp_send_json_error( __( 'Permission denied', 'wpuf-pro' ) );
        }

        $module = isset( $_POST['module'] ) ? sanitize_text_field( wp_unslash( $_POST['module'] ) ) : '';
        $type   = isset( $_POST['type'] ) ? sanitize_text_field( wp_unslash( $_POST['type'] ) ) : '';
        if ( ! $module ) {
            wp_send_json_error( __( 'Invalid module provided', 'wpuf-pro' ) );
        }
        if ( ! in_array( $type, [ 'activate', 'deactivate' ], true ) ) {
            wp_send_json_error( __( 'Invalid request type', 'wpuf-pro' ) );
        }
        $module_data = wpuf_pro_get_module( $module );
        if ( 'activate' == $type ) {
            if ( ! wpuf_pro_is_module_allowed( $module ) ) {
                wp_send_json_error(
                    [
                        'error'   => 'module_not_in_plan',
                        'message' => __( 'This module is not available in your current plan.', 'wpuf-pro' ),
                    ]
                );
            }
            $status = wpuf_pro_activate_module( $module );
            if ( is_wp_error( $status ) ) {
                wp_send_json_error(
                    [
                        'error'   => $status->get_error_code(),
                        'message' => $status->get_error_message(),
                    ]
                );
            }
            $message = __( 'Activated', 'wpuf-pro' );
        } else {
            wpuf_pro_deactivate_module( $module );
            $message = __( 'Deactivated', 'wpuf-pro' );
        }
        wp_send_json_success( $message );
    }

    /**
     * Toggle all modules
     *
     * @since 2.7
     *
     * @return void
     **/
    public function toggle_all_modules() {
        check_ajax_referer( 'wpuf-admin-nonce', 'nonce' );

        if ( ! current_user_can( wpuf_admin_role() ) ) {
            wp_send_json_error( __( 'Permission denied', 'wpuf-pro' ) );
        }

        $type = isset( $_POST['type'] ) ? sanitize_text_field( wp_unslash( $_POST['type'] ) ) : '';
        if ( ! in_array( $type, [ 'activate', 'deactivate' ], true ) ) {
            wp_send_json_error( __( 'Invalid request type', 'wpuf-pro' ) );
        }
        $modules = wpuf_pro_get_modules();
        if ( 'activate' == $type ) {
            foreach ( $modules as $module => $data ) {
                // Skip modules outside the current plan tier.
                if ( ! wpuf_pro_is_module_allowed( $module ) ) {
                    continue;
                }
                wpuf_pro_activate_module( $module );
            }
            $message = __( 'Activated', 'wpuf-pro' );
        } else {
            foreach ( $modules as $module => $data ) {
                wpuf_pro_deactivate_module( $module );
            }
            $message = __( 'Deactivated', 'wpuf-pro' );
        }
        wp_send_json_success( $message );
    }
}
