<?php
/**
 * Post View Control Settings
 *
 * @package WPUF_Pro
 * @since 4.2.6
 */

namespace WeDevs\Wpuf\Pro\Post_View_Control;

// don't call the file directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Settings class for Post View Control
 *
 * @since 4.2.6
 */
class Settings {

    /**
     * Class constructor
     *
     * @since 4.2.6
     */
    public function __construct() {
        add_filter( 'wpuf_form_builder_settings_general', [ $this, 'add_view_control_settings' ], 12 );
    }

    /**
     * Add view control settings to form builder
     *
     * @since 4.2.6
     *
     * @param array $settings Existing form settings
     * @return array Modified form settings
     */
    public function add_view_control_settings( $settings ) {
        $settings['section']['view_control'] = [
            'label'  => __( 'View Control', 'wpuf-pro' ),
            'desc'   => __( 'Control who can view posts submitted through this form. Choose to make them publicly visible or restrict access based on user roles or subscription plans.', 'wpuf-pro' ),
            'fields' => [
                'view_control_role_enabled' => [
                    'label'     => __( 'Restrict by user roles', 'wpuf-pro' ),
                    'type'      => 'toggle',
                    'help_text' => __( 'Only users with selected roles can view these posts.', 'wpuf-pro' ),
                ],
                'view_control_roles' => [
                    'label'     => __( 'Select allowed roles', 'wpuf-pro' ),
                    'type'      => 'multi-select',
                    'options'   => $this->get_user_roles(),
                    'help_text' => __( 'Select the user roles who can view these posts', 'wpuf-pro' ),
                    'depends_on' => [
                        [
                            'field' => 'view_control_role_enabled',
                            'value' => true,
                        ],
                    ],
                ],
                'view_control_role_message' => [
                    'label'     => __( 'Unauthorized Message (Roles)', 'wpuf-pro' ),
                    'type'      => 'textarea',
                    'help_text' => __( 'Message to display when users without required roles try to view the content', 'wpuf-pro' ),
                    'default'   => __( 'This post is restricted. Please {login}/{register} to view this post.', 'wpuf-pro' ),
                    'depends_on' => [
                        [
                            'field' => 'view_control_role_enabled',
                            'value' => true,
                        ],
                    ],
                ],
                'view_control_subscription_enabled' => [
                    'label'     => __( 'Restrict by subscription packs', 'wpuf-pro' ),
                    'type'      => 'toggle',
                    'help_text' => __( 'Only users with selected subscription packs can view these posts.', 'wpuf-pro' ),
                ],
                'view_control_subscriptions' => [
                    'label'     => __( 'Select subscription packs', 'wpuf-pro' ),
                    'type'      => 'multi-select',
                    'options'   => $this->get_subscription_packs(),
                    'help_text' => __( 'Select the subscription packs required to view these posts', 'wpuf-pro' ),
                    'depends_on' => [
                        [
                            'field' => 'view_control_subscription_enabled',
                            'value' => true,
                        ],
                    ],
                ],
                'view_control_subscription_message' => [
                    'label'     => __( 'Unauthorized Message (Subscription)', 'wpuf-pro' ),
                    'type'      => 'textarea',
                    'help_text' => __( 'Message to display when users without required subscription try to view the content', 'wpuf-pro' ),
                    'default'   => __( 'You need to have one of the {subscriptions} to view this post. Have not subscribed yet? Please {login}/{register} to subscribe.', 'wpuf-pro' ),
                    'depends_on' => [
                        [
                            'field' => 'view_control_subscription_enabled',
                            'value' => true,
                        ],
                    ],
                ],
            ],
        ];

        return $settings;
    }

    /**
     * Get all available user roles
     *
     * @since 4.2.6
     *
     * @return array User roles
     */
    private function get_user_roles() {
        $roles = wp_roles()->get_names();

        // Remove administrator from the list as they should always have access
        unset( $roles['administrator'] );

        return $roles;
    }

        /**
     * Get all available subscription packs
     *
     * @since 4.2.6
     *
     * @return array Subscription packs
     */
    private function get_subscription_packs() {
        $packs = [];

        // Try to get subscription packs using the most reliable method
        try {
            // Method 1: Use wpuf() container if available
            if ( function_exists( 'wpuf' ) && isset( wpuf()->subscription ) && method_exists( wpuf()->subscription, 'get_subscriptions' ) ) {
                $all_packs = wpuf()->subscription->get_subscriptions();
                if ( $all_packs ) {
                    foreach ( $all_packs as $pack ) {
                        $packs[ $pack->ID ] = $pack->post_title;
                    }
                }
            }
            // Method 2: Fallback to direct instantiation
            elseif ( class_exists( '\WeDevs\Wpuf\Admin\Subscription' ) ) {
                $subscription = new \WeDevs\Wpuf\Admin\Subscription();
                $all_packs = $subscription->get_subscriptions();
                if ( $all_packs ) {
                    foreach ( $all_packs as $pack ) {
                        $packs[ $pack->ID ] = $pack->post_title;
                    }
                }
            }
            // Method 3: Fallback to global class
            elseif ( class_exists( 'WPUF_Subscription' ) ) {
                $subscription = new \WPUF_Subscription();
                $all_packs = $subscription->get_subscriptions();
                if ( $all_packs ) {
                    foreach ( $all_packs as $pack ) {
                        $packs[ $pack->ID ] = $pack->post_title;
                    }
                }
            }
        } catch ( \Exception $e ) {
            // Log error but don't break the form
            error_log( 'View Control: Error getting subscription packs: ' . $e->getMessage() );
        }

        // If no subscription packs found, add a placeholder option
        if ( empty( $packs ) ) {
            $packs['no_packs'] = __( 'No subscription packs available', 'wpuf-pro' );
        }

        return $packs;
    }
}
