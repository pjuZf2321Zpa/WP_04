<?php

namespace WeDevs\Wpuf\Pro\AI_Review\Providers;

/**
 * Provider Factory
 *
 * Factory class for creating AI provider instances
 *
 * @since 4.2.9
 */
class Provider_Factory {

	/**
	 * Supported provider mappings
	 *
	 * @var array
	 */
	private static $provider_map = [
		'openai'    => OpenAI_Provider::class,
		'anthropic' => Anthropic_Provider::class,
		'google'    => Google_Provider::class,
	];

	/**
	 * Create a provider instance
	 *
	 * @since 4.2.9
	 *
	 * @param string $provider_name Provider name (e.g., 'openai', 'anthropic', 'google')
	 * @param string $endpoint      API endpoint
	 * @param string $api_key       API key
	 * @param string $model         Model to use
	 *
	 * @return Abstract_Provider Provider instance
	 * @throws \Exception If provider is not supported
	 */
	public static function create( $provider_name, $endpoint, $api_key, $model ) {
		$provider_name = strtolower( trim( $provider_name ) );

		if ( ! isset( self::$provider_map[ $provider_name ] ) ) {
			throw new \Exception( 'Unsupported AI provider: ' . $provider_name );
		}

		$class_name = self::$provider_map[ $provider_name ];

		return new $class_name( $endpoint, $api_key, $model );
	}

	/**
	 * Get list of supported providers
	 *
	 * @since 4.2.9
	 *
	 * @return array List of supported provider names
	 */
	public static function get_supported_providers() {
		return array_keys( self::$provider_map );
	}

	/**
	 * Check if a provider is supported
	 *
	 * @since 4.2.9
	 *
	 * @param string $provider_name Provider name to check
	 *
	 * @return bool True if provider is supported
	 */
	public static function is_supported( $provider_name ) {
		return isset( self::$provider_map[ strtolower( trim( $provider_name ) ) ] );
	}
}
