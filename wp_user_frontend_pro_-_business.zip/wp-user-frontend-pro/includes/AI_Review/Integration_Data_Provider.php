<?php

// DESCRIPTION: Provides integration-specific field data for AI review.
// Hooks into wpuf_ai_review_integration_data to enrich review content for Events Calendar, EDD, and WooCommerce CPTs.

namespace WeDevs\Wpuf\Pro\AI_Review;

/**
 * Integration Data Provider for AI Review
 *
 * Extracts integration-specific field data (event dates, product prices, etc.)
 * and provides them to the AI review pipeline via a filter hook.
 *
 * @since 4.2.13
 */
class Integration_Data_Provider {

    /**
     * Constructor
     *
     * @since 4.2.13
     */
    public function __construct() {
        add_filter( 'wpuf_ai_review_integration_data', [ $this, 'add_integration_data' ], 10, 3 );
    }

    /**
     * Add integration-specific data for AI review based on post type
     *
     * @since 4.2.13
     *
     * @param array  $data      Existing integration data
     * @param int    $post_id   Post ID
     * @param string $post_type Post type slug
     *
     * @return array Integration data with section label keys and field arrays
     */
    public function add_integration_data( $data, $post_id, $post_type ) {
        switch ( $post_type ) {
            case 'tribe_events':
                $event_data = $this->get_event_data( $post_id );
                if ( ! empty( $event_data ) ) {
                    $data['Event Details'] = $event_data;
                }
                break;

            case 'download':
                $edd_data = $this->get_edd_data( $post_id );
                if ( ! empty( $edd_data ) ) {
                    $data['Download Details'] = $edd_data;
                }
                break;

            case 'product':
                $woo_data = $this->get_woo_data( $post_id );
                if ( ! empty( $woo_data ) ) {
                    $data['Product Details'] = $woo_data;
                }
                break;
        }

        return $data;
    }

    /**
     * Extract Events Calendar specific data for review
     *
     * @since 4.2.13
     *
     * @param int $post_id Event post ID
     *
     * @return array Associative array of field labels to values
     */
    private function get_event_data( $post_id ) {
        $data = [];

        $start_date = get_post_meta( $post_id, '_EventStartDate', true );
        if ( ! empty( $start_date ) ) {
            $data['Start Date'] = $start_date;
        }

        $end_date = get_post_meta( $post_id, '_EventEndDate', true );
        if ( ! empty( $end_date ) ) {
            $data['End Date'] = $end_date;
        }

        $all_day = get_post_meta( $post_id, '_EventAllDay', true );
        if ( ! empty( $all_day ) ) {
            $data['All Day Event'] = $all_day === 'yes' ? 'Yes' : 'No';
        }

        $cost = get_post_meta( $post_id, '_EventCost', true );
        if ( $cost !== '' && $cost !== false ) {
            $currency = get_post_meta( $post_id, '_EventCurrencySymbol', true );
            $data['Cost'] = ! empty( $currency ) ? $currency . $cost : $cost;
        }

        $url = get_post_meta( $post_id, '_EventURL', true );
        if ( ! empty( $url ) ) {
            $data['Event URL'] = $url;
        }

        $timezone = get_post_meta( $post_id, '_EventTimezone', true );
        if ( ! empty( $timezone ) ) {
            $data['Timezone'] = $timezone;
        }

        // Resolve venue name from venue post ID
        $venue_id = get_post_meta( $post_id, '_EventVenueID', true );
        if ( ! empty( $venue_id ) ) {
            $venue_name = get_the_title( $venue_id );
            if ( ! empty( $venue_name ) ) {
                $data['Venue'] = $venue_name;
            }

            $venue_address = get_post_meta( $venue_id, '_VenueAddress', true );
            if ( ! empty( $venue_address ) ) {
                $data['Venue Address'] = $venue_address;
            }

            $venue_city = get_post_meta( $venue_id, '_VenueCity', true );
            if ( ! empty( $venue_city ) ) {
                $data['Venue City'] = $venue_city;
            }
        }

        // Resolve organizer name from organizer post ID
        $organizer_id = get_post_meta( $post_id, '_EventOrganizerID', true );
        if ( ! empty( $organizer_id ) ) {
            $organizer_name = get_the_title( $organizer_id );
            if ( ! empty( $organizer_name ) ) {
                $data['Organizer'] = $organizer_name;
            }

            $organizer_email = get_post_meta( $organizer_id, '_OrganizerEmail', true );
            if ( ! empty( $organizer_email ) ) {
                $data['Organizer Email'] = $organizer_email;
            }

            $organizer_phone = get_post_meta( $organizer_id, '_OrganizerPhone', true );
            if ( ! empty( $organizer_phone ) ) {
                $data['Organizer Phone'] = $organizer_phone;
            }
        }

        return $data;
    }

    /**
     * Extract Easy Digital Downloads specific data for review
     *
     * @since 4.2.13
     *
     * @param int $post_id Download post ID
     *
     * @return array Associative array of field labels to values
     */
    private function get_edd_data( $post_id ) {
        $data = [];

        $price = get_post_meta( $post_id, 'edd_price', true );
        if ( $price !== '' && $price !== false ) {
            $data['Price'] = $price;
        }

        $product_notes = get_post_meta( $post_id, 'edd_product_notes', true );
        if ( ! empty( $product_notes ) ) {
            $data['Product Notes'] = $product_notes;
        }

        $download_files = get_post_meta( $post_id, 'edd_download_files', true );
        if ( ! empty( $download_files ) && is_array( $download_files ) ) {
            $data['Downloadable Files'] = count( $download_files ) . ' file(s) attached';
        }

        return $data;
    }

    /**
     * Extract WooCommerce specific data for review
     *
     * @since 4.2.13
     *
     * @param int $post_id Product post ID
     *
     * @return array Associative array of field labels to values
     */
    private function get_woo_data( $post_id ) {
        $data = [];

        $regular_price = get_post_meta( $post_id, '_regular_price', true );
        if ( $regular_price !== '' && $regular_price !== false ) {
            $data['Regular Price'] = $regular_price;
        }

        $sale_price = get_post_meta( $post_id, '_sale_price', true );
        if ( $sale_price !== '' && $sale_price !== false ) {
            $data['Sale Price'] = $sale_price;
        }

        $purchase_note = get_post_meta( $post_id, '_purchase_note', true );
        if ( ! empty( $purchase_note ) ) {
            $data['Purchase Note'] = $purchase_note;
        }

        // Since WooCommerce 3.0+, visibility is stored as a taxonomy, not post meta
        $visibility_terms = get_the_terms( $post_id, 'product_visibility' );
        if ( ! is_wp_error( $visibility_terms ) && ! empty( $visibility_terms ) ) {
            $data['Catalog Visibility'] = implode( ', ', wp_list_pluck( $visibility_terms, 'name' ) );
        }

        $downloadable = get_post_meta( $post_id, '_downloadable', true );
        if ( ! empty( $downloadable ) ) {
            $data['Downloadable'] = $downloadable === 'yes' ? 'Yes' : 'No';
        }

        $gallery = get_post_meta( $post_id, '_product_image_gallery', true );
        if ( ! empty( $gallery ) ) {
            $image_ids = array_filter( explode( ',', $gallery ) );
            $data['Gallery Images'] = count( $image_ids ) . ' image(s)';
        }

        return $data;
    }
}
