<?php

namespace WeDevs\Wpuf\Pro;

/**
 * Post Expiration
 *
 * Handles form-driven post expiration: persisting per-post expiration metadata
 * when a form is submitted and processing expired posts on the daily cron.
 *
 * Meta keys (defined by WPUF free for backward compatibility):
 *   - wpuf-post_expiration_date
 *   - wpuf-expired_post_status
 *   - wpuf-post_expiration_message
 *
 * @since 4.2.13
 */
class Post_Expiration {

    const META_EXPIRATION_DATE    = 'wpuf-post_expiration_date';
    const META_EXPIRED_STATUS     = 'wpuf-expired_post_status';
    const META_EXPIRATION_MESSAGE = 'wpuf-post_expiration_message';
    const META_ALREADY_EXPIRED    = 'wpuf-post_expired';

    public function __construct() {
        add_action( 'wpuf_after_post_submit_expiration_settings', [ $this, 'save_expiration_meta' ], 10, 3 );
        add_action( 'wpuf_remove_expired_post_hook', [ $this, 'process_expired_posts' ], 10 );
    }

    /**
     * Save per-post expiration metadata after a form submission.
     *
     * Called from WPUF free via do_action( 'wpuf_after_post_submit_expiration_settings', ... )
     * after the subscription-pack branch has been evaluated. Only writes metadata when
     * the form has expiration enabled and the user is NOT on an active subscription pack
     * that provides its own expiration.
     *
     * @param array      $form_settings               Form settings array.
     * @param int        $post_id                     Post ID of the newly submitted post.
     * @param array|string $user_wpuf_subscription_pack User subscription pack meta value, or empty.
     *
     * @return void
     */
    public function save_expiration_meta( $form_settings, $post_id, $user_wpuf_subscription_pack ) {
        if ( empty( $post_id ) ) {
            return;
        }

        $enable_post_expiration = isset( $form_settings['expiration_settings']['enable_post_expiration'] )
            ? $form_settings['expiration_settings']['enable_post_expiration']
            : '';

        // The toggle is stored as the string 'off' when disabled, and empty( 'off' )
        // is false — so guard on the actual on/off value, not emptiness (#1945).
        if ( ! wpuf_is_checkbox_or_toggle_on( $enable_post_expiration ) ) {
            return;
        }

        // The pack only owns expiration when it actually has it switched on. Testing isset()
        // alone made a pack storing 'off' suppress the form-level expiration as well, so a form
        // with expiration configured silently stopped expiring for users holding such a pack.
        $has_active_pack = ! empty( $user_wpuf_subscription_pack )
            && is_array( $user_wpuf_subscription_pack )
            && isset( $user_wpuf_subscription_pack['_enable_post_expiration'] )
            && wpuf_validate_boolean( $user_wpuf_subscription_pack['_enable_post_expiration'] )
            && isset( $user_wpuf_subscription_pack['expire'] )
            && strtotime( $user_wpuf_subscription_pack['expire'] ) >= time();

        // When an active subscription pack already set expiration, skip form-level writes.
        if ( $has_active_pack ) {
            return;
        }

        $time_value = isset( $form_settings['expiration_settings']['expiration_time_value'] ) ? intval( $form_settings['expiration_settings']['expiration_time_value'] ) : 0;
        $time_type  = isset( $form_settings['expiration_settings']['expiration_time_type'] ) ? $form_settings['expiration_settings']['expiration_time_type'] : 'day';

        // A duration below one (0, '', or a non-numeric value) is not a valid expiration window.
        // The old check only rejected '', so '0' produced "+0 day": an expiry date of today,
        // which made the daily cron unpublish the post roughly 24 hours after submission.
        if ( $time_value < 1 ) {
            return;
        }

        // Only the durations the form builder offers are accepted; anything else would make
        // strtotime() fail below and store 1970-01-01, expiring the post on the next cron run.
        $allowed_time_types = [ 'day', 'week', 'month', 'year' ];

        if ( ! in_array( $time_type, $allowed_time_types, true ) ) {
            $time_type = 'day';
        }

        $expire_timestamp = strtotime( '+' . $time_value . ' ' . $time_type );

        if ( ! $expire_timestamp ) {
            return;
        }

        $expire_date = gmdate( 'Y-m-d', $expire_timestamp );
        update_post_meta( $post_id, self::META_EXPIRATION_DATE, $expire_date );

        if ( isset( $form_settings['expiration_settings']['expired_post_status'] ) ) {
            update_post_meta(
                $post_id,
                self::META_EXPIRED_STATUS,
                $form_settings['expiration_settings']['expired_post_status']
            );
        }

        if ( isset( $form_settings['expiration_settings']['enable_mail_after_expired'] )
            && 'on' === $form_settings['expiration_settings']['enable_mail_after_expired']
            && isset( $form_settings['expiration_settings']['post_expiration_message'] )
        ) {
            update_post_meta(
                $post_id,
                self::META_EXPIRATION_MESSAGE,
                $form_settings['expiration_settings']['post_expiration_message']
            );
        }
    }

    /**
     * Check whether a post's stored expiration date is corrupt rather than due.
     *
     * A duration that strtotime() could not parse used to be stored as 1970-01-01, and a
     * zero duration as the submission date itself, so the cron unpublished posts that were
     * never meant to expire. Both are now prevented at write time, but sites that already
     * ran the old code keep those values on disk. An expiration date at or before the post's
     * own creation date cannot be a real expiry, so treat it as corrupt.
     *
     * @since 4.2.18
     *
     * @param int $post_id Post ID.
     *
     * @return bool
     */
    protected function has_corrupt_expiration_date( $post_id ) {
        $expiration_date = get_post_meta( $post_id, self::META_EXPIRATION_DATE, true );
        $expiration_time = is_string( $expiration_date ) && '' !== $expiration_date
            ? strtotime( $expiration_date )
            : false;

        if ( ! $expiration_time ) {
            return true;
        }

        $created = get_post_field( 'post_date_gmt', $post_id );
        $created_time = ! empty( $created ) && '0000-00-00 00:00:00' !== $created
            ? strtotime( $created . ' UTC' )
            : false;

        if ( ! $created_time ) {
            return false;
        }

        return $expiration_time < $created_time;
    }

    /**
     * Flip post status for posts whose expiration date has passed.
     *
     * Runs on the daily wpuf_remove_expired_post_hook cron. For each post where:
     *   - wpuf-post_expiration_date <= today, and
     *   - wpuf-post_expired guard meta is not set,
     * updates the post to the configured expired status (wpuf-expired_post_status),
     * sets the guard meta so the same post is never re-processed, and fires
     * wpuf_post_expired for downstream listeners (e.g., notification emails).
     *
     * @return void
     */
    public function process_expired_posts() {
        $today = gmdate( 'Y-m-d' );

        $expired_posts = get_posts(
            [
                'post_type'      => 'any',
                'post_status'    => 'any',
                'posts_per_page' => -1,
                'fields'         => 'ids',
                // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- daily cron, bounded by expiration date.
                'meta_query'     => [
                    'relation' => 'AND',
                    [
                        'key'     => self::META_EXPIRATION_DATE,
                        'value'   => $today,
                        'compare' => '<=',
                        'type'    => 'DATE',
                    ],
                    [
                        'key'     => self::META_ALREADY_EXPIRED,
                        'compare' => 'NOT EXISTS',
                    ],
                ],
            ]
        );

        if ( empty( $expired_posts ) ) {
            return;
        }

        foreach ( $expired_posts as $post_id ) {
            if ( $this->has_corrupt_expiration_date( $post_id ) ) {
                // Metadata already written by the bugs fixed above: drop it and leave the
                // post alone, otherwise every cron run keeps unpublishing posts that were
                // never meant to expire.
                delete_post_meta( $post_id, self::META_EXPIRATION_DATE );
                continue;
            }

            $new_status = get_post_meta( $post_id, self::META_EXPIRED_STATUS, true );

            if ( empty( $new_status ) ) {
                continue;
            }

            $previous_status = get_post_status( $post_id );

            if ( $previous_status === $new_status ) {
                // Already in the target state; still mark as processed so we stop revisiting.
                update_post_meta( $post_id, self::META_ALREADY_EXPIRED, gmdate( 'c' ) );
                continue;
            }

            $updated = wp_update_post(
                [
                    'ID'          => $post_id,
                    'post_status' => $new_status,
                ],
                true
            );

            if ( is_wp_error( $updated ) || ! $updated ) {
                continue;
            }

            update_post_meta( $post_id, self::META_ALREADY_EXPIRED, gmdate( 'c' ) );

            /**
             * Fires after a post has been transitioned to its expired status.
             *
             * @since 4.2.13
             *
             * @param int    $post_id         The expired post ID.
             * @param string $previous_status Post status before expiration.
             * @param string $new_status      Post status after expiration.
             */
            do_action( 'wpuf_post_expired', $post_id, $previous_status, $new_status );
        }
    }
}
