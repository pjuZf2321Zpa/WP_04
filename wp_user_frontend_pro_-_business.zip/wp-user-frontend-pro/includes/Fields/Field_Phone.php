<?php

namespace WeDevs\Wpuf\Pro\Fields;

/**
 * Phone Field Class
 *
 * @since 3.4.11
 **/
class Field_Phone extends Pro_Field_Contract {

    public function __construct() {
        $this->name       = __( 'Phone Field', 'wpuf-pro' );
        $this->input_type = 'phone_field';
        $this->icon       = 'device-phone-mobile';
    }

    /**
     * Render the Phone field in the frontend
     *
     * @since 3.4.11
     *
     * @param array   $field_settings
     * @param integer $form_id
     * @param string  $type
     * @param integer $post_id
     *
     * @return void
     */
    public function render( $field_settings, $form_id, $type = 'post', $post_id = null ) {
        $attr = $field_settings;
        $value = '';
        $country_list = ! empty( $attr['country_list'] ) && is_array( $attr['country_list'] ) ? $attr['country_list'] : [];
        $country_list_visibility = ! empty( $country_list['country_list_visibility_opt_name'] ) ? $country_list['country_list_visibility_opt_name'] : 'all';
        $only_countries = '';
        $exclude_countries = '';

        if ( 'show' === $country_list_visibility && ! empty( $country_list['country_select_show_list'] ) ) {
            $only_countries = wp_json_encode( $country_list['country_select_show_list'] );
        } elseif ( 'hide' === $country_list_visibility && ! empty( $country_list['country_select_hide_list'] ) ) {
            $exclude_countries = wp_json_encode( $country_list['country_select_hide_list'] );
        }

        if ( ! empty( $post_id ) ) {
            if ( $this->is_meta( $attr ) ) {
                $value = $this->get_meta( $post_id, $attr['name'], $type );
            }
        } else {
            $value = $attr['default'];
        }

        $this->field_print_label( $attr, $form_id ); ?>

        <style>
            .iti--allow-dropdown.has-error .iti__selected-flag {
                height: 70%;
                padding-left: 16px;
            }

            /* field specific style to override our default padding */
            .iti--allow-dropdown input, .iti--allow-dropdown input[type=text], .iti--allow-dropdown input[type=tel], .iti--separate-dial-code input, .iti--separate-dial-code input[type=text], .iti--separate-dial-code input[type=tel] {
                padding-right: 6px !important;
                padding-left: 52px !important;
            }

        </style>
        <div class="wpuf-fields">
            <input
                class="wpuf_telephone text <?php echo 'wpuf_' . $attr['name'] . '_' . $form_id; ?>"
                id="<?php echo $attr['name'] . '_' . $form_id; ?>"
                type="text"
                data-required="<?php echo esc_attr( $attr['required'] ); ?>"
                data-label="<?php echo esc_attr( $attr['label'] ); ?>"
                data-show-list="<?php echo esc_attr( $attr['show_country_list'] ); ?>"
                data-default-country="<?php echo ! empty( $country_list['name'] ) ? esc_attr( $country_list['name'] ) : ''; ?>"
                data-only-countries="<?php echo esc_attr( $only_countries ); ?>"
                data-exclude-countries="<?php echo esc_attr( $exclude_countries ); ?>"
                data-auto-placeholder="<?php echo ! empty( $attr['auto_placeholder'] ) ? esc_attr( $attr['auto_placeholder'] ) : 'yes'; ?>"
                data-utils-script="<?php echo esc_attr( WPUF_PRO_ROOT_URI . '/assets/vendor/intl-tel-input/js/utils.js' ); ?>"
                data-type="text"
                name="<?php echo esc_attr( $attr['name'] ); ?>"
                placeholder="<?php echo esc_attr( $attr['placeholder'] ); ?>"
                value="<?php echo esc_attr( $value ); ?>"
                size="<?php echo esc_attr( $attr['size'] ); ?>" />
            <?php $this->help_text( $attr ); ?>
        </div>

        <?php
        // Phone field initialization is now handled by WPUF_Field_Initializer
        // This ensures proper initialization for repeat field instances
        ?>

        <?php
        $this->after_field_print_label();
    }

    /**
     * Get field options setting
     *
     * @since 3.4.11
     *
     * @return array
     */
    public function get_options_settings() {
        $default_options = $this->get_default_option_settings();
        $text_options    = $this->get_default_text_option_settings();

        $settings = [
            [
                'name'      => 'show_country_list',
                'title'     => __( 'Show Country List', 'wpuf-pro' ),
                'type'      => 'radio',
                'options'   => [
                    'yes' => __( 'Yes', 'wpuf-pro' ),
                    'no'  => __( 'No', 'wpuf-pro' ),
                ],
                'inline'    => true,
                'default'   => 'yes',
                'section'   => 'advanced',
                'priority'  => 23,
                'help_text' => __( 'Select yes to show the country selection dropdown.', 'wpuf-pro' ),
            ],
            [
                'name'      => 'auto_placeholder',
                'title'     => __( 'Auto Placeholder', 'wpuf-pro' ),
                'type'      => 'radio',
                'options'   => [
                    'yes' => __( 'Yes', 'wpuf-pro' ),
                    'no'  => __( 'No', 'wpuf-pro' ),
                ],
                'inline'    => true,
                'default'   => 'yes',
                'section'   => 'advanced',
                'priority'  => 23.1,
                'help_text' => __( 'Set the input\'s placeholder to an example number for the selected country, and update it if the country changes.', 'wpuf-pro' ),
                'dependencies'  => [
                    'show_country_list' => 'yes',
                ],
            ],
            [
                'name'          => 'country_list',
                'title'         => '',
                'type'          => 'country-list',
                'section'       => 'advanced',
                'priority'      => 23.2,
                'dependencies'  => [
                    'show_country_list' => 'yes',
                ],
                'help_text' => __( 'You must include the Default Country if you choose "Only Show These" option', 'wpuf-pro' ),
            ],
        ];

        return array_merge( $default_options, $text_options, $settings );
    }

    /**
     * Get the field props for this Vue Component
     *
     * @since 3.4.11
     *
     * @return array
     */
    public function get_field_props() {
        $defaults = $this->default_attributes();

        $props = [
            'show_country_list' => 'yes',
            'auto_placeholder'  => 'yes',
            'input_type'        => 'country_list',
            'country_list'  => [
                'name'                              => '',
                'country_list_visibility_opt_name'  => 'all', // all, hide, show
                'country_select_show_list'          => [],
                'country_select_hide_list'          => [],
            ],
            'show_in_post'      => 'yes',
            'hide_field_label'  => 'no',
            'is_meta'           => 'yes',
            'id'                => 0,
            'is_new'            => true,
        ];

        return array_merge( $defaults, $props );
    }
}
