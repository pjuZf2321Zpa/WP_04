;(function($) {
'use strict';

;(function($) {
    'use strict';

    /**
     * Only proceed if current page is a 'Post Forms' form builder page
     */
    if (!$('#wpuf-form-builder').length) {
        // return;
    }

    window.mixin_builder_stage_pro = {
        computed: {
            action_hook_fields: function () {
                return this.$store.state.form_fields.filter(function (item) {
                    return 'action_hook' === item.input_type;
                });
            }
        },

        hiddenClasses: function() {
            return [
                'hidden',           // Tailwind: display: none
                'wpuf_hidden_field',
                'screen-reader-text'
            ];
        },

        methods: {
            /**
             * Filter CSS classes to prevent hiding fields in the builder
             * Removes classes that would make the field invisible or hidden in the backend
             * while preserving them for frontend rendering
             *
             * @param {string} cssClasses - Space-separated CSS class names
             * @return {string} Filtered CSS classes safe for builder
             */
            filter_builder_css_classes: function(cssClasses) {
                if (!cssClasses || typeof cssClasses !== 'string') {
                    return '';
                }

                // Split classes, filter out forbidden ones, and rejoin
                var classes = cssClasses.split(/\s+/).filter(function(className) {
                    return className && this.hiddenClasses().indexOf(className.toLowerCase()) === -1;
                }.bind(this));

                return classes.join(' ');
            },

            /**
             * Check if field has CSS classes that would hide it on the frontend
             * Used to display a visual indicator in the builder
             *
             * @param {string} cssClasses - Space-separated CSS class names
             * @return {boolean} True if field has hiding CSS classes
             */
            has_hidden_css_class: function(cssClasses) {
                if (!cssClasses || typeof cssClasses !== 'string') {
                    return false;
                }

                var hiddenClasses = this.hiddenClasses();
                var classes = cssClasses.toLowerCase().split(/\s+/);

                for (var i = 0; i < hiddenClasses.length; i++) {
                    if (classes.indexOf(hiddenClasses[i]) !== -1) {
                        return true;
                    }
                }

                return false;
            }
        }
    };
})(jQuery);

;(function($) {
    'use strict';

    /**
     * Country List Validation Mixin
     * 
     * Validates that country list is filled when using "Hide these" or "Only show" modes
     * Used by both field-country-list and field-address components
     * 
     * @since 4.2.2
     */
    window.mixin_country_list_validation_pro = {
        computed: {
            has_validation_error: function () {
                var visibility = this.active_visibility;
                var show_list = this.get_country_show_list();
                var hide_list = this.get_country_hide_list();

                // Show error only if list is empty when using "show" or "hide" modes
                if ('show' === visibility && !show_list.length) {
                    return true;
                }
                if ('hide' === visibility && !hide_list.length) {
                    return true;
                }

                return false;
            },

            validation_error_message: function () {
                var visibility = this.active_visibility;
                var show_list = this.get_country_show_list();
                var hide_list = this.get_country_hide_list();

                if ('show' === visibility && !show_list.length) {
                    return '⚠️ Please select at least one country';
                }

                if ('hide' === visibility && !hide_list.length) {
                    return '⚠️ Please select at least one country';
                }

                return '';
            }
        },

        methods: {
            /**
             * Get country show list - must be implemented by component
             * 
             * @returns {array}
             */
            get_country_show_list: function () {
                throw new Error('get_country_show_list() must be implemented by component');
            },

            /**
             * Get country hide list - must be implemented by component
             * 
             * @returns {array}
             */
            get_country_hide_list: function () {
                throw new Error('get_country_hide_list() must be implemented by component');
            }
        }
    };
})(jQuery);

;(function($) {
    'use strict';

    /**
     * Only proceed if current page is a 'Post Forms' form builder page
     */
    if (!$('#wpuf-form-builder').length) {
        // return;
    }

    window.mixin_form_field_pro = {
        methods: {
            has_gmap_api_key: function () {
                return wpuf_form_builder.gmap_api_key ? true : false;
            },

            is_rs_captcha_active: function () {
                return wpuf_form_builder.is_rs_captcha_active ? true : false;
            }
        }
    };
})(jQuery);

})(jQuery);
