import { createApp } from 'vue';
import FormsList from './components/FormsList.vue';

const app = createApp(FormsList);

app.mount('#wpuf-profile-forms-list-table-view');
