// DESCRIPTION: Updates AI review prompt textarea placeholder based on
// the selected post type in the form builder.
(function($) {
    'use strict';

    var promptSuggestions = wpufAIReviewFormSettings.promptSuggestions;
    var defaultPrompt = wpufAIReviewFormSettings.defaultPrompt;

    function updatePromptPlaceholder() {
        var postType = $('select[name="wpuf_settings[post_type]"]').val();
        var textarea = $('#ai_review_prompt');

        if (textarea.length) {
            var placeholder = promptSuggestions[postType] || defaultPrompt;
            textarea.attr('placeholder', placeholder);
        }
    }

    $(document).ready(function() {
        updatePromptPlaceholder();

        $('select[name="wpuf_settings[post_type]"]').on('change', function() {
            updatePromptPlaceholder();
        });
    });
})(jQuery);
