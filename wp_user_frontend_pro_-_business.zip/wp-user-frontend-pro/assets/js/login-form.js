/**
 * WP User Frontend Pro - Login Form Frontend Logic
 *
 * Handles placeholder conversion, help text, and form element manipulation
 * for all login form layouts.
 *
 * @package WP User Frontend Pro
 * @since 1.0.0
 */

(function($) {
    'use strict';

    /**
     * Initialize login form enhancements
     */
    function initializeLoginForm() {
        var loginForm = document.getElementById('wpuf-login-form');

        if (!loginForm) {
            return;
        }

        // Get current layout from localized data
        var layout = wpufLoginForm.layout || 'layout1';
        var texts = wpufLoginForm.texts || {};

        // Add layout class to form
        loginForm.classList.add('wpuf-layout-' + layout.replace('layout', ''));

        // Apply custom texts to form elements
        applyCustomTexts(loginForm, texts);

        // Add help text for layout 7
        if (layout === 'layout7') {
            addHelpText(loginForm, texts);
        }

        // Wrap action links
        wrapActionLinks(loginForm);
    }

    /**
     * Apply custom texts to form labels, placeholders, and buttons
     *
     * @param {HTMLElement} loginForm The login form element
     * @param {Object} texts Custom text values from settings
     */
    function applyCustomTexts(loginForm, texts) {
        var form = loginForm.querySelector('form');

        if (!form) {
            return;
        }

        // Apply username label and placeholder
        var usernameInput = form.querySelector('input[name="log"]');

        if (usernameInput) {
            var usernameLabel = form.querySelector('label[for="wpuf-user_login"]');

            if (usernameLabel && texts.usernameLabel) {
                usernameLabel.textContent = texts.usernameLabel;
            }

            if (texts.usernamePlaceholder) {
                usernameInput.setAttribute('placeholder', texts.usernamePlaceholder);
            }
        }

        // Apply password label and placeholder
        var passwordInput = form.querySelector('input[name="pwd"]');

        if (passwordInput) {
            var passwordLabel = form.querySelector('label[for="wpuf-user_pass"]');

            if (passwordLabel && texts.passwordLabel) {
                passwordLabel.textContent = texts.passwordLabel;
            }

            if (texts.passwordPlaceholder) {
                passwordInput.setAttribute('placeholder', texts.passwordPlaceholder);
            }
        }

        // Apply Remember Me text
        var rememberMeLabel = form.querySelector('.wpuf-remember-me label[for="wpuf-rememberme"]');

        if (rememberMeLabel && texts.rememberMe) {
            rememberMeLabel.textContent = texts.rememberMe;
        }

        // Apply Lost Password text
        var lostPasswordLink = form.querySelector('.wpuf-lost-password a');

        if (lostPasswordLink && texts.lostPassword) {
            lostPasswordLink.textContent = texts.lostPassword;
        }

        // Apply Login Button text
        var submitButton = form.querySelector('input[type="submit"]');

        if (submitButton && texts.buttonText) {
            submitButton.value = texts.buttonText;
        }
    }

    /**
     * Add help text to form fields (Layout 7 only)
     *
     * @param {HTMLElement} loginForm The login form element
     * @param {Object} texts Custom text values from settings
     */
    function addHelpText(loginForm, texts) {
        var form = loginForm.querySelector('form');

        if (!form) {
            return;
        }

        // Help text from custom texts or defaults
        var usernameHelp = texts.usernameHelp || 'Please enter your username or email address';
        var passwordHelp = texts.passwordHelp || 'Please enter your password';

        // Add help text to username/email field
        var usernameField = form.querySelector('input[name="log"]');

        if (usernameField && !usernameField.parentElement.querySelector('.wpuf-help')) {
            var usernameHelpSpan = document.createElement('span');
            usernameHelpSpan.className = 'wpuf-help';
            usernameHelpSpan.textContent = usernameHelp;
            usernameField.parentElement.appendChild(usernameHelpSpan);
        }

        // Add help text to password field
        var passwordField = form.querySelector('input[type="password"]');

        if (passwordField && !passwordField.parentElement.querySelector('.wpuf-help')) {
            var passwordHelpSpan = document.createElement('span');
            passwordHelpSpan.className = 'wpuf-help';
            passwordHelpSpan.textContent = passwordHelp;
            passwordField.parentElement.appendChild(passwordHelpSpan);
        }
    }

    /**
     * Wrap action links in proper containers
     *
     * @param {HTMLElement} loginForm The login form element
     */
    function wrapActionLinks(loginForm) {
        var links = loginForm.querySelectorAll('a');

        links.forEach(function(link) {
            // Skip if already wrapped
            if (link.parentElement.classList.contains('wpuf-lost-password-wrapper')) {
                return;
            }

            // Skip if inside form
            if (link.closest('form')) {
                return;
            }

            // Check if it's an action link (lost password, register, etc.)
            var isActionLink = /lostpassword|action=login|\/login\/|register/.test(link.href);

            if (isActionLink || link.parentElement.id === 'wpuf-login-form') {
                var wrapper = document.createElement('span');
                wrapper.className = 'wpuf-lost-password-wrapper';
                link.parentNode.insertBefore(wrapper, link);
                wrapper.appendChild(link);
            }
        });
    }

    /**
     * Initialize on DOM ready
     */
    $(document).ready(function() {
        initializeLoginForm();
    });

})(jQuery);
