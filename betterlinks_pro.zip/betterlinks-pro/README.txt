=== BetterLinks Pro - Shorten, Track and Manage any URL ===
Contributors: wpdevteam, re_enter_rupok, asif2bd
Donate link: https://wpdeveloper.com
Tags:  links, urls, shortlinks, link branding, link tracking, affiliate links, link cloaking, marketing, redirect, forward, rewrite, shorturl, shorten, shortening, clicks, track, tracking, tiny, tinyurl, shrinking, domain, shrink, mask, masking, cloak, cloaking, slugs, stats, statistics, seo, automation, dashboard, analytics, betterlinks, link shortener, url shortener
Requires at least: 6.2
Requires PHP: 7.4
Tested up to: 7.1
Stable tag: 3.1.0
License: GPL-3.0-or-later
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Ultimate plugin to create, shorten, track and manage any URL. Gather analytics reports and run successful marketing campaigns easily.


== Description ==

Want to make your brand standout? BetterLinks brings you the chance to easily create, shorten and manage any URL to help you cross-promote your brands & products. With its aesthetic User Interface, you can shorten anything without breaking any sweat and track & collect analytics reports to run successful campaigns easily.

## Perks of Using BetterLinks 🔥

- Easy-to-use & Simple Link Shortener
- Create attractive looking links instantly
- Safe Redirection URLs
- Analyze and Track your marketing campaigns from one place
- Optimized queries to reduce load time & make faster
- Power up your affiliate marketing level
- UTM Builder to evaluate marketing campaigns
- Instant Gutenberg Redirect to manage links from Gutenberg Editor
- Indiviual Analytics for better insights [PRO]
- User Role Management [PRO]
- Set Link Expiration date & control where users will be redirected [PRO]
- Integration with Google Analytics [PRO]
- Dynamic Redirects with Split Testing [PRO]
- HTTPS Redirection [PRO]
- Open Links in Native Apps from In-App Browsers [PRO]


## Simple & Fast Link Shortener 🎉


**✨ Aesthetic Drag & Drop UI:** Create & manage any links with just a couple of clicks. Manage everything from creating, editing, configurations & all from just one place

**💫 One-Click Share:** Copy your shortened URL right from the dashboard and share it instantly

**⚙️ Easy Configuration:** Easily setup your Link Redirects (301, 302 and 307) and all your Link options

**💪 Fast Response:** Less Database queries resulting in faster response time

**🔃 Simple Migration:** Migrate from Third-party Plugins such as PrettyLinks with one-click

## Easily Analyze and Track Your Cloaked Links 📈

**📈 Real Time Analytics:** Generate real-time analytics data and easily evaluate the performance of your cloaked links with just a glance

**🔎 Examine Click-Through Rate:** Examine the performance of your click-through rates of your shortend URLs right from one place

**📊 Generate Reports:** Gather analytics reports to evaulate and run successful marketing campaigns

**📅 Interactive Calendar to Filter Clicks:** Easily Filter your clokaed links based on certain dates from the interactive Calendar

**🔗  UTM Builder to Track Campaigns:** Add Campaign Parameters to track your marketing campaigns


== External services ==

BetterLinks Pro adds these connections to the free plugin, only when the related feature is used:

* **DB-IP / FreeIPAPI**: visitor IP address, to look up the country when Country Tracking is on
* **NotificationX (api.notificationx.com)**: visitor IP address, for Geographic redirects
* **Google Analytics / Meta Pixel**: click events, only with your own IDs
* **OpenAI / Google Gemini**: the content you send, only with your own API key
* **Google Fonts**: fonts on Link in Bio pages
* **Google Tag Manager**: on BetterLinks admin screens, only if usage sharing is opted in
* **WPDeveloper (api.wpdeveloper.com)**: licence key and site URL, for licensing and updates

Each provider's own terms and privacy policy apply.

== Changelog ==

= 3.1.0 - 01/11/2026 =

- Added: Open in App to open links in native apps from in-app browsers
- Few minor bug fixes & improvements

= 3.0.5 - 14/10/2026 =

- Added: Role-based access control for MCP
- Improvement: Enhanced block editor experience
- Few minor bug fixes & improvements

= 3.0.4 - 22/09/2026 =

- Improvement: Country tracking is now an opt-in setting under Settings → Tracking
- Improvement: Added compatibility alert and update notice
- Improvement: Auto Post Link Generator, AI Bulk Link Generator, Geography analytics, IP exclusion and UTM templates now run from BetterLinks Pro
- Security: Improved plugin security enhancements
- Few minor bug fixes & improvements

= 3.0.3 - 10/09/2026 =

- Few minor bug fixes & improvements

= 3.0.2 - 21/08/2026 =

- Security: Improved plugin security enhancements
- Few minor bug fixes & improvements

= 3.0.1 - 10/08/2026 =

- Added: Option to remove the "Made with BetterLinks" credit from Bio Links pages
- Fixed: Promo Cards tables failed to create on some hosting configurations
- Fixed: Bio Links page views counted bots and link previews as visitors
- Improvement: Analytics filtering and Bio Links configuration options
- Few minor bug fixes & improvements

= 3.0.0 - 03/08/2026 =

- Added: All-new interface with a refreshed, optimized design
- Added: Promo Cards for product promotions
- Added: Bio Links for link-in-bio pages
- Improvement: Streamlined workflows with better performance and accessibility
- Few minor bug fixes & improvements

= 2.8.0 -24/06/2026 =

- Added: Introduced AI Link Assistant Feature for intelligent keyword recommendations
- Fixed: Resolved Auto-Link Keywords compatibility issues with Elementor
- Fixed: Improved No Follow and Sponsored attribute support for Auto-Link Keywords
- Few minor bug fixes & improvements

= 2.7.1 - 07/06/2026 =

- Improvement: Resolved Plugin Check (PCP) warnings and errors.
- Few minor bug fixes & improvements

= 2.7.0 - 11/05/2026 =

- Added: Scheduled Scan & Reports for Full Site Link Scanner.
- Improvement: WPML support for Affiliate Link Disclosure Notice translations.
- Improvement: Background scanning support after starting a new Link Scanner scan.
- Improvement: Bulk status change actions for short links (Active, Draft, Expired).
- Improvement: Redesigned BetterLinks Broken Link Scanner with a modernized UI.
- Fixed: Missing ABSPATH protection issue causing PHP fatal errors on direct file access.
- Fixed: False-positive broken link detection in Broken Link Scanner.
- Fixed: UTM Builder role-based template apply permission issue.
- Few minor bug fixes & improvements

= 2.6.6 -16/04/2026 =

- Improvement: Added WPML-compatible translatable string support.
- Improvement: Introduced Affiliate Link Disclosure shortcode system.
- Fixed: Resolved Affiliate Disclosure block styling issue in Elementor
- Few minor bug fixes & improvements

= 2.6.5 - 07/04/2026 =

- Improvement: Introduced Import & Export functionality for Auto-link Keywords
- Improvement: Added an option to customize the Password Protected Form permalink
- Fixed: Resolved Social Link Preview conflicts with the Breakdance plugin
- Few minor bug fixes & improvements

= 2.6.3 - 26/02/2026 =

- Added: Option to exclude specific IP addresses from analytics tracking
- Improvement: Added new User Agent tracking system for enhanced visitor insights
- Fix: Minor bug fixes & improvements

= 2.6.2 - 10/02/2026 =

- Improvement: Optimized settings loading mechanism for better performance
- Few minor bug fixes & improvements

= 2.6.1 - 02/02/2026 =

- Improvement: Affiliate link disclosure styling and added a new setting to apply it only to Auto-link keywords
- Improvement: Color picker now supports HEX, RGB, and HSL color formats
- Improvement: Link Scanner REST API performance to handle large datasets, with role-based permission support
- Improvement: Added Activate/Draft status option for Auto-link keywords with bulk actions
- Improvement: Added full analytics view for individual short link details
- Improvement: Updated AI model with a maximum token limit mechanism and partial bulk processing support when limits are exceeded
- Fixed: Auto-link keyword issue that was breaking page layouts
- Few minor bug fixes & improvements

= 2.6.0 - 05/01/2026 =

- Added: AI powered Bulk Link Generator to generate bulk short links
- Few minor bug fixes & improvements

= 2.5.0 - 18/12/2025 =

- Added : Auto Post Link Generator feature to generate links for existing post types.
- Improvement: Added Country column in Analytics.
- Improvement: Added Auto Link Keyword Style Control with icon uploading support.
- Few minor bug fixes & improvements

= 2.4.0 - 26/10/2025 =

- Added: New Global UTM Builder support
- Few minor bug fixes & improvements

= 2.3.2 - 21/09/2025 =
- Improvement: Added Role-Based Management for Tags & Categories.
- Improvement: License activation and deactivation are now managed by user roles.
- Improvement: Improved Dynamic Redirect UI with better target field validation.
- Few minor bug fixes & improvements

= 2.3.0 - 26/08/2025 =

- Added: Auto-link Creation now supports Custom Post Types (CPTs)
- Improvement: Updated Twitter logo to the new X branding
- Fixed: Resolved PHP deprecated warnings for PHP 8.4 compatibility
- Fixed: Addressed issue with Google Analytics event tracking for “View” events
- Few minor bug fixes & improvements

= 2.2.4 - 13/02/2025 =

- Fixed: Broken Link email report shows incorrect count.
- Few minor bug fixes & improvements

= 2.2.3 - 22/12/2024 =

- Fixed: Fatal Error On Schedule Scan
- Few minor bug fixes & improvements

= 2.2.2 - 27/11/2024 =

- Few minor bug fixes & improvements

= 2.2.1 - 26/11/2024 =

- Few minor bug fixes & improvements

= 2.2.0 - 21/11/2024 =

- Added: Full Site Link Scanner Feature 
- Improvements: Moved 'Broken Link Checker' to 'Link Scanner' as 'BetterLinks Broken Link Scanner'
- Few minor bug fixes & improvements

= 2.1.6 - 14/11/2024 =

- Improvements: Added global disable option for Auto-Link Keywords Feature
- Few minor bug fixes & improvement

= 2.1.5 - 10/11/2024 =

- Tested up to WordPress version 6.7
- Few minor bug fixes & improvements

= 2.1.4 - 23/10/2024 =

- Improvements: Link Uncloak Feature
- Fixed: Analytics for Uncloaked link
- Fixed: Unicode character encode issue with Dynamic Redirect URL
- Fixed: Instant Redirect is not working when Custom Domain Feature is enabled
- Fixed: Dark mode issue in individual link Analytics page.
- Few minor bug fixes & improvements

= 2.1.3 - 15/10/2024 =

- Improved: Security Enhancement
- Few minor bug fixes & improvements

= 2.1.2 - 19/09/2024 =

- Fixed: Fatal Error - Uncaught TypeError issue
- Fixed: Google Analytics Tracking issue
- Fixed: Custom Permalink Structure issue in Password Protected Redirect
- Few minor bug fixes & improvement

= 2.1.1 - 06/09/2024 =

- Fixed: Fatal Error - Uncaught TypeError issue
- Few minor bug fixes & improvements

= 2.1.0 - 05/09/2024 =

- Added: Parameter Tracking Feature
- Fixed: Auto-Create Links multiple link creation issue
- Few minor bug fixes & improvement

= 2.0.2 - 11/08/2024 =

- Improvement: Added Auto-Link Keywords Import/Export functionality
- Improvement: Added Additional global configuration options for Auto-Link Keywords Feature
- Improvement: Added more options to enable specific post types in Affiliate Disclosure Settings
- Fixed: Website IP issue in the Custom Domain feature
- Few minor bug fixes & improvement

= 2.0.1 - 16/07/2024 =

- Added: WordPress 6.6 Compatibility 
- Few minor bug fixes & improvement

= 2.0.0 - 07/07/2024 =

- Added: Custom Domain Feature
- Fixed: Multiple category creation issue when saving Quick Link Creation settings.
- Few minor bug fixes & improvement

= 1.9.4 - 19/05/2024 =

- Added: Advanced Options for Quick Link Creation Feature
- Improvement: Auto-Link Keywords UI
- Fixed: Added proper validation for Split Test
- Few minor bug fixes & improvement

= 1.9.3 - 07/05/2024 =

- Few minor bug fixes & improvement

= 1.9.2 - 24/04/2024 =

- Fixed: Click Expiration Feature
- Few minor bug fixes & improvement

= 1.9.1 - 25/03/2024 =

- Fixed: Fatal error - expecting variable in Auto Link Keyword.
- Few minor bug fixes & improvement

= 1.9.0 - 24/03/2024 =

- Added: Custom Scripts Feature
- Fixed: Role Management for UTM Builder
- Fixed: Auto Link Keywords for multiple comma separated keywords
- Improved: Google Analytics "page_view" event
- Few minor bug fixes & improvement

= 1.8.3 - 06/03/2024 =

- Improved: Added Winner and Expire option in Split Test feature
- Few minor bug fixes & improvement

= 1.8.2 - 08/02/2024 =

- Improved: Security Enhancements
- Fixed: Comma separated Auto Link Keyword issue
- Fixed: Broken Link status Icon issue
- Fixed: Meta attributes issue in Customize Link Preview
- Few minor bug fixes & improvements

= 1.8.1 - 21/01/2024 =

- Fixed: Fatal error - Trait not found issue
- Few minor bug fixes & improvements

= 1.8.0 - 17/01/2024 =

- Added: Customize Link Preview Feature
- Fixed: Split Test Conversion issue
- Fixed: Auto-Link Keywords Link Options issue
- Improved: Split Test Analytics UI
- Few minor bug fixes & improvements

= 1.7.4 - 31/12/2023 =

- Few minor bug fixes & improvements

= 1.7.3 - 31/12/2023 =

- Few minor bug fixes & improvements

= 1.7.2 - 31/12/2023 =

- Improved: Revamped Analytics with Charts for a few key metrics
- Fixed: Autolink Keyword not working properly when the same Keyword exists in other Auto Link Keyword and Shorten Link Title
- Few minor bug fixes & improvements

= 1.7.1 - 09/11/2023 =

- Improved: Password Protected Redirect | Password show/hide Icon Added in Password input field
- Few minor bug fixes & improvements

= 1.7.0 - 08/10/2023 =

- Added: Password Protected Redirect Feature
- Improved: UTM Builder | Added Support for "Edit," "Delete," and "Save As New" Actions
- Few minor bug fixes & improvements

= 1.6.2 - 21/09/2023 =
- Fixed: "Uncaught TypeError" in the Affiliate Link Disclosure Feature
- Few minor bug fixes & improvements

= 1.6.1 - 13/09/2023 =
- Fixed: PHP Deprecation Warnings
- Improved: Security Enhancements
- Few minor bug fixes & improvements

= 1.6.0 - 11/09/2023 =

- Added: Affiliate Link Disclosure Feature
- Fixed: Dynamic Redirects | Geographic Target URL Redirection issue
- Few minor bug fixes & improvements

= 1.5.0 - 26/07/2023 =

- Added: Auto-Create Links Feature
- Fixed: Broken link checker Freezing issue
- Few minor bug fixes & improvements

= 1.4.8 - 13/06/2023 =

- Few minor bug fixes & improvements

= 1.4.7 - 13/06/2023 =

- Added: Integration with Google Analytics 4
- Fixed: "Uncloaked" option not getting checked out after adding the categories to the "Uncloaked Category"
- Improved: Security Enhancement
- Few minor bug fixes & improvements

= 1.4.6 - 30/04/2023 =

- Fixed: Heading tags getting autolinked even when disabled
- Few minor bug fixes & improvements

= 1.4.5 - 16/04/2023 =

- Added: Option to Uncloak link or entire category for strict Affiliate Marketing programs like Amazon Associates
- Added: Feature to search Autolink-keywords
- Fixed: Made role management accessible only to admin
- Few minor bug fixes & improvements

= 1.4.4 - 28/02/2023 =

- Improved: Show Status for Broken link Checker
- Improved: Show Links which are 401 Unauthorised & 403 Forbidden Links
- Few minor bug fixes & improvements

= 1.4.3 - 29/01/2023 =

- Fixed: PHP notice 'Undefined index' when creating a post/page
- Few minor bug fixes & improvements

= 1.4.2 - 25/01/2023 =

- Added: Option to Disable instant redirect & autolink keywords for custom post types
- Fixed: Cloaking prevents mobile responsive adjustment & favicon not showing
- Fixed: Undefined index when trying link redirection
- Fixed: Set Default value as on Technology based Redirects
- Few minor bug fixes & improvements

= 1.4.1 - 22/12/2022 =

- Fixed: Auto-Link Keywords | Heading tags getting autolinked even when not enabled
- Fixed: Auto-Link Keywords not working when a keyword is used twice inside a phrase/sentence
- Few minor bug fixes & improvements

= 1.4.0 - 20/11/2022 =

- Added: Facebook Pixel Tracking option
- Few minor bug fixes & improvements

= 1.3.0 - 03/08/2022 =

- Added: Link Cloaking redirection option
- Few minor bug fixes & improvements

= 1.2.5 - 06/07/2022 =

- Fixed: Auto-Links keywords causing single quotes (’) to convert to smart quotes
- Fixed: Auto-link keywords not opening in new tabs
- Few minor bug fixes & improvements

= 1.2.4 - 19/06/2022 =

- Improved: Added option to enable icon for auto-link Keywords
- Improved: Added option to enable auto-link keywords inside Heading tags
- Improved: Added option to include multiple keywords at a time for auto-link keywords
- Fixed: Auto-link keywords not working when the post is not fully visible
- Few minor bug fixes & improvements

= 1.2.3 - 30/05/2022 =

- Added: Display Link status in the Manage Links page
- Fixed: Auto-Link Keywords conflict with Fluent Forms
- FIxed: Date wise link expiration not working properly
- Fixed: Auto-link Keywords broken UI with long tag name
- Few minor bug fixes & improvements

= 1.2.2 - 19/01/2022 =

- Added: Link Expiration options for Instant Link Redirect inside Elementor Page Builder
- Few minor bug fixes & improvements

= 1.2.1 - 11/01/2022 =

- Fixed: Auto-Link Keywords not working after changing the Link ID
- Fixed: Broken Page format when tags & attitrubtes are used as an auto-link keyword
- Fixed: Protected HTML Tag attributes
- Few minor bug fix & improvements

= 1.2.0 - 30/11/2021 =

- Added: Auto-Link Keywords
- Few minor bug fix & improvements

= 1.1.3 - 28/10/2021 =

- Added: Translation capability for missing strings
- Few minor bug fix & improvements

= 1.1.2 - 07/10/2021 =

- Added: Link Scheduler option
- Few minor bug fix & improvements

= 1.1.1 - 29/09/2021 =

- Improved: Query optimization for better performance & security enhancement
- Few minor bug fix & improvements

= 1.1.0 - 21/09/2021 =
- Added: Broken Link Checker with Email Notification
- Few minor bug fix & improvements

= 1.0.6 - 12/08/2021 =
- Added: Added: AJAX Fallback when REST API is disabled
- Fixed: Sanitized REST API data
- Fixed: Individual analytics not working properly
- Few minor bug fix & improvements

= 1.0.5 - 27/07/2021 =

- Added: Dynamic Redirects based on Geography, Time & Device
- Added: Force HTTPS Redirections feature
- Few minor bug fix and improvements

= 1.0.4 - 08/07/2021 =

- Improved: UI for Dynamic Redirects
- Few minor bug fix and improvements

= 1.0.3 - 06/07/2021 =

- Added: Dynamic Redirects with Split Testing feature
- Few minor bug fix and improvements

= 1.0.2 - 14/06/2021 =

- Added Link expiration options for Instant Gutenberg Redirect
- Few minor bug fix and improvements

= 1.0.1 - 07/06/2021 =

- Added: Compatibility with PHP 8.0
- Fixed: Google Analytics Settings migration issue
- Few minor bug fix and improvements

= 1.0.0 - 20/05/2021 =

- Added: Individual Analytics
- Added: Link Expiration
- Added: Google Analytics Integration
- Added: User Role Management
- Added: Social Share for UTM

== Upgrade Notice ==
