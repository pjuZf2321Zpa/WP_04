<?php

namespace BetterLinksPro;
if ( ! defined( 'ABSPATH' ) ) { exit; }

use BetterLinksPro\Dependencies\WPDeveloper\Licensing\Manager;

class Admin {
	public function __construct() {
		Admin\Menu::init();
		Admin\Ajax::init();
		// Auto Post Link Generator: older free plugins still ship their own copy.
		if ( \BetterLinksPro\Compat::free_has_extension_api() ) {
			Admin\ShortLinkGenerator::getInstance();
		}
		Admin\Metabox::init();
		$this->add_scripts();
		// On `init`, not here: this class is built on `betterlinks_loaded` (which
		// fires on `plugins_loaded`), and the licensing args carry translated
		// strings. Touching the text domain before `init` trips WP 6.7+'s
		// "_load_textdomain_just_in_time was called incorrectly" notice. Priority 0
		// keeps it ahead of the SDK's own `init` callbacks, and every hook the
		// SDK registers (`init`, `admin_notices`, `admin_enqueue_scripts`,
		// `wp_ajax_*`) still fires normally from here.
		add_action( 'init', [ $this, 'licensing' ], 0 );
		// $this->plugin_licensing();
		add_filter( 'betterlinks/tools/export_content', [ $this, 'export_content' ], 10, 2 );
		add_filter( 'betterlinks/tools/import_row_bucket', [ $this, 'import_row_bucket' ], 10, 2 );
		add_filter( 'betterlinks/tools/import_process_data', [ $this, 'import_process_data' ], 10, 3 );
		add_filter( 'betterlinks/tools/migration/ptl_one_click_import_link_arg', [
			$this,
			'ptl_one_click_import_link_arg'
		], 10, 2 );
		add_filter( 'betterlinks/helper/menu_items', [ $this, 'add_new_menu_item' ], 10, 2 );
		// Add custom capability for role-based license management
		add_filter( 'user_has_cap', [ $this, 'add_custom_license_capability' ], 10, 3 );
	}

	/**
	 * @return void
	 */
	public function licensing() {
		// Guarded per the SDK readme: if the library is missing at runtime — a
		// partial plugin update, or a host serving stale OPcache — an unguarded
		// static call throws an uncaught Error on `init` and white-screens every
		// request. Guarded, the plugin degrades to "license inactive" instead.
		if ( ! class_exists( Manager::class ) ) {
			return;
		}

		try {
			Manager::get_instance( [
				'plugin_file' => BETTERLINKS_PRO_FILE,
				'version'     => BETTERLINKS_PRO_VERSION,
				'item_id'     => BETTERLINKS_SL_ITEM_ID,
				'item_name'   => BETTERLINKS_SL_ITEM_NAME,
				'item_slug'   => BETTERLINKS_PRO_PLUGIN_SLUG,
				'storeURL'    => BETTERLINKS_STORE_URL,
				'textdomain'  => 'betterlinks-pro',
				'db_prefix'   => BETTERLINKS_PRO_SL_DB_PREFIX,
				'page_slug'   => 'betterlinks-settings',
				'permission'  => 'betterlinks_edit_settings', // Custom permission for role-based access

				// Custom body for the "not activated yet" notice. Supplied through the
				// SDK's documented `activation_notice` arg rather than by editing the
				// vendored library, so an SDK update cannot drop it. Styled by
				// `_admin-notices.scss` in the free plugin; on admin screens where that
				// stylesheet is absent it degrades to a plain WordPress notice.
				'activation_notice' => $this->license_activation_notice(),

				'scripts_handle' => 'betterlinkspro-admin-core',
				'screen_id'      => [
					"betterlinks_page_betterlinks-keywords-linking",
					"betterlinks_page_betterlinks-manage-tags-and-categories",
					"betterlinks_page_betterlinks-custom-domain",
					"betterlinks_page_betterlinks-promo-cards",
					"betterlinks_page_betterlinks-bio-links",
					"betterlinks_page_betterlinks-analytics",
					"betterlinks_page_betterlinks-link-scanner",
					"betterlinks_page_betterlinks-settings",
					"toplevel_page_betterlinks"
				],
				'api'  => 'ajax',
				'ajax' => [
					'textdomain'  => 'betterlinks-pro',
					'action_prefix' => 'betterlinks'
				]
			] );
		} catch ( \Exception $e ) {
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG && defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
				error_log( 'BetterLinks Pro licensing: ' . $e->getMessage() );
			}
		}
	}

	/**
	 * Body of the "license not active" notice.
	 *
	 * The SDK wraps whatever this returns in its own `.notice.notice-error` shell
	 * and passes it through `wp_kses_post()`, so only post-safe markup survives —
	 * no <button>, and the icon is an inline SVG rather than a background image.
	 *
	 * @return string
	 */
	private function license_activation_notice() {
		$settings_url = admin_url( 'admin.php?page=betterlinks-settings&tab=license' );

		// An empty span, not an <svg>: the SDK runs this through wp_kses_post(),
		// which strips svg/circle/path outright. The glyph is painted by
		// `_admin-notices.scss` as a background image instead.
		$icon = '<span class="btl-notice__icon" aria-hidden="true"></span>';

		return sprintf(
			'<span class="btl-notice__body">%1$s<span class="btl-notice__text">%2$s<a class="btl-notice__link" href="%3$s">%4$s</a>%5$s</span><a class="btl-notice__action" href="%3$s">%6$s</a></span>',
			$icon,
			esc_html__( 'Your license is not active for this site. ', 'betterlinks-pro' ),
			esc_url( $settings_url ),
			esc_html__( 'Activate your license', 'betterlinks-pro' ),
			esc_html__( ' to unlock Pro features & updates.', 'betterlinks-pro' ),
			esc_html__( 'Activate', 'betterlinks-pro' )
		);
	}

	public function add_scripts() {
		new Admin\Assets();
	}

	/**
	 * Plugin Licensing
	 *
	 * @since v1.0.0
	 */
	public function plugin_licensing() {
		new Admin\License( BETTERLINKS_PRO_PLUGIN_SLUG, BETTERLINKS_SL_ITEM_NAME, 'betterlinks-pro' );
	}

	public function pro_enabled() {
		return true;
	}

	public function export_content( $content, $type = 'rotations' ) {
		if ( 'rotations' === $type ) {
			$content['rotations'] = Helper::get_all_clicks_rotations();
		}

		return $content;
	}

	/**
	 * Claim link-rotation rows in a BetterLinks CSV import.
	 *
	 * @param string $bucket Current bucket.
	 * @param array  $header CSV header row.
	 * @return string
	 */
	public function import_row_bucket( $bucket, $header ) {
		$header = is_array( $header ) ? $header : array();
		if ( '' === $bucket && in_array( 'click_id', $header, true ) && in_array( 'link_id', $header, true ) && in_array( 'target_url', $header, true ) && ! in_array( 'short_url', $header, true ) ) {
			return 'rotations';
		}
		return $bucket;
	}

	public function import_process_data( $message, $data, $link_IDs ) {
		if ( isset( $data['rotations'] ) && is_array( $data['rotations'] ) && count( $data['rotations'] ) > 0 ) {
			$message['rotations'] = $this->rotation_data_insert( $data['rotations'], $link_IDs );
		}

		return $message;
	}

	public function rotation_data_insert( $data, $link_IDs ) {
		$message = [];
		foreach ( $data as $item ) {
			if ( isset( $link_IDs[ $item['link_id'] ] ) ) {
				$item['link_id'] = $link_IDs[ $item['link_id'] ];
			}
			$link_id = Helper::insert_click_rotation( $item );
			if ( $link_id ) {
				$message[] = 'Imported Successfully "' . $item['target_url'] . '"';
			}
		}

		return $message;
	}

	public function ptl_one_click_import_link_arg( $arg, $data ) {
		global $wpdb;
		$wpdb_prefix    = $wpdb->prefix;
		$prli_link_meta = new \PrliLinkMeta();
		if ( $prli_link_meta->get_link_meta( $data['id'], 'enable_expire', true ) ) {
			$expire                    = [];
			$expire['status']          = true;
			$expire['type']            = $prli_link_meta->get_link_meta( $data['id'], 'expire_type', true );
			$expire['date']            = $prli_link_meta->get_link_meta( $data['id'], 'expire_date', true );
			$expire['clicks']          = $prli_link_meta->get_link_meta( $data['id'], 'expire_clicks', true );
			$expire['redirect_status'] = $prli_link_meta->get_link_meta( $data['id'], 'enable_expired_url', true );
			$expire['expired_url']     = $prli_link_meta->get_link_meta( $data['id'], 'expired_url', true );
			$arg['expire']             = json_encode( $expire );
		}

		if ( $prli_link_meta->get_link_meta( $data['id'], 'prli_dynamic_redirection', true ) == 'rotate' ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$rotate         = $wpdb->get_results( $wpdb->prepare( "SELECT url, weight, link_id from {$wpdb_prefix}prli_link_rotations where link_id = %d", $data['id'] ), OBJECT );
			$redirect_url   = [];
			$redirect_url[] = [
				'link'   => $data['url'],
				'weight' => (int) $prli_link_meta->get_link_meta( $data['id'], 'prli-target-url-weight', true )
			];
			if ( is_array( $rotate ) && count( $rotate ) > 0 ) {
				foreach ( $rotate as $rotate_item ) {
					$redirect_url[] = [
						'link'   => $rotate_item->url,
						'weight' => (int) $rotate_item->weight
					];
				}
			}
			$redirect                = [];
			$redirect['type']        = 'rotation';
			$redirect['value']       = $redirect_url;
			$redirect['extra']       = [
				'rotation_mode' => 'weighted',
				'split_test'    => $prli_link_meta->get_link_meta( $data['id'], 'prli-enable-split-test', true ),
				'goal_link'     => ''
			];
			$arg['dynamic_redirect'] = json_encode( $redirect );
		} elseif ( $prli_link_meta->get_link_meta( $data['id'], 'prli_dynamic_redirection', true ) == 'geo' ) {
			$countries    = Helper::get_prettylinks_meta( $data['id'], 'geo_countries' );
			$countries    = wp_list_pluck( $countries, 'meta_value' );
			$urls         = Helper::get_prettylinks_meta( $data['id'], 'geo_url' );
			$urls         = wp_list_pluck( $urls, 'meta_value' );
			$allCountries = array_combine( $urls, $countries );
			$redirect_url = [];
			if ( is_array( $allCountries ) && count( $allCountries ) > 0 ) {
				foreach ( $allCountries as $url => $country ) {
					preg_match_all( "/((?<=\[).+?(?=\]))/i", $country, $countryList );
					$redirect_url[] = [
						'link'    => $url,
						'country' => is_array( $countryList ) ? $countryList[0] : []
					];
				}
			}
			$redirect                = [];
			$redirect['type']        = 'geographic';
			$redirect['value']       = $redirect_url;
			$arg['dynamic_redirect'] = json_encode( $redirect );
		} elseif ( $prli_link_meta->get_link_meta( $data['id'], 'prli_dynamic_redirection', true ) == 'tech' ) {
			$tech_device  = Helper::get_prettylinks_meta( $data['id'], 'tech_device' );
			$tech_device  = wp_list_pluck( $tech_device, 'meta_value' );
			$tech_os      = Helper::get_prettylinks_meta( $data['id'], 'tech_os' );
			$tech_os      = wp_list_pluck( $tech_os, 'meta_value' );
			$tech_browser = Helper::get_prettylinks_meta( $data['id'], 'tech_browser' );
			$tech_browser = wp_list_pluck( $tech_browser, 'meta_value' );
			$tech_url     = Helper::get_prettylinks_meta( $data['id'], 'tech_url' );
			$tech_url     = wp_list_pluck( $tech_url, 'meta_value' );

			$redirect_url = [];
			if ( is_array( $tech_url ) && count( $tech_url ) > 0 ) {
				foreach ( $tech_url as $key => $url ) {
					$redirect_url[] = [
						'link'    => $url,
						'device'  => $tech_device[ $key ],
						'os'      => $tech_os[ $key ],
						'browser' => $tech_browser[ $key ]
					];
				}
			}
			$redirect                = [];
			$redirect['type']        = 'technology';
			$redirect['value']       = $redirect_url;
			$arg['dynamic_redirect'] = json_encode( $redirect );
		} elseif ( $prli_link_meta->get_link_meta( $data['id'], 'prli_dynamic_redirection', true ) == 'time' ) {
			$time_url   = Helper::get_prettylinks_meta( $data['id'], 'time_url' );
			$time_url   = wp_list_pluck( $time_url, 'meta_value' );
			$time_start = Helper::get_prettylinks_meta( $data['id'], 'time_start' );
			$time_start = wp_list_pluck( $time_start, 'meta_value' );
			$time_end   = Helper::get_prettylinks_meta( $data['id'], 'time_end' );
			$time_end   = wp_list_pluck( $time_end, 'meta_value' );

			$redirect_url = [];
			if ( is_array( $time_url ) && count( $time_url ) > 0 ) {
				foreach ( $time_url as $key => $url ) {
					$redirect_url[] = [
						'link'       => $url,
						'start_date' => $time_start[ $key ],
						'end_date'   => $time_end[ $key ]
					];
				}
			}
			$redirect                = [];
			$redirect['type']        = 'time';
			$redirect['value']       = $redirect_url;
			$arg['dynamic_redirect'] = json_encode( $redirect );
		}

		return $arg;
	}

	public function add_new_menu_item( $items ) {
		$sub_menu                          = [];
		$user                              = wp_get_current_user();
		$user_permission                   = json_decode( get_option( BETTERLINKS_PRO_ROLE_PERMISSON_OPTION_NAME, '{}' ), true );
		$can_current_user_manage_autolinks = Helper::current_user_can_do( 'manageAutoliks', $user, $user_permission );
		$can_current_user_manage_link_scanner = Helper::current_user_can_do( 'manageLinkScanner', $user, $user_permission );
		$can_current_user_edit_settings = Helper::current_user_can_do( 'editsettings', $user, $user_permission );
		$can_current_user_manage_tags_categories = Helper::current_user_can_do( 'manageTagsCategories', $user, $user_permission );
		$can_current_user_manage_promo_cards = Helper::current_user_can_do( 'managePromoCards', $user, $user_permission );
		$can_current_user_manage_bio_links = Helper::current_user_can_do( 'manageBioLinks', $user, $user_permission );

		foreach ( $items as $key => $item ) {
			// Skip Custom Domain menu if user doesn't have edit settings permission
			if ( $key === BETTERLINKS_PLUGIN_SLUG . '-custom-domain' && ! $can_current_user_edit_settings ) {
				continue;
			}

			// Skip Tags & Categories menu if user doesn't have manage tags categories permission
			if ( $key === BETTERLINKS_PLUGIN_SLUG . '-manage-tags-and-categories' && ! $can_current_user_manage_tags_categories ) {
				continue;
			}

			// Skip Promo Cards menu if user doesn't have manage promo cards permission
			if ( $key === BETTERLINKS_PLUGIN_SLUG . '-promo-cards' && ! $can_current_user_manage_promo_cards ) {
				continue;
			}

			// Skip Bio Links menu if user doesn't have manage bio links permission
			if ( $key === BETTERLINKS_PLUGIN_SLUG . '-bio-links' && ! $can_current_user_manage_bio_links ) {
				continue;
			}
			// (capability strings for these two are set below, mirroring Link Scanner,
			// so direct page access is gated too — not just the sidebar link.)
			
			$sub_menu[ $key ] = $item;
			
			// Add Auto-Link Keywords menu if user has permission
			if ( $key === 'betterlinks' && $can_current_user_manage_autolinks ) {
				$sub_menu[ BETTERLINKS_PLUGIN_SLUG . '-keywords-linking' ] = [
					'title'      => __( 'Auto-Link Keywords', 'betterlinks-pro' ),
					'capability' => 'manage_options',
				];
			}
			
			// Update Custom Domain capability to use custom permission
			if ( $key === BETTERLINKS_PLUGIN_SLUG . '-custom-domain' ) {
				$sub_menu[ $key ]['capability'] = 'betterlinks_edit_settings';
			}
			
			// Update Settings capability to use custom permission
			if ( $key === BETTERLINKS_PLUGIN_SLUG . '-settings' ) {
				$sub_menu[ $key ]['capability'] = 'betterlinks_edit_settings';
			}
			
			// Update Analytics capability to use custom permission
			if ( $key === BETTERLINKS_PLUGIN_SLUG . '-analytics' ) {
				$sub_menu[ $key ]['capability'] = 'betterlinks_check_analytics';
			}
			
			// Update Link Scanner capability to use custom permission
			if ( $key === BETTERLINKS_PLUGIN_SLUG . '-link-scanner' ) {
				$sub_menu[ $key ]['capability'] = 'betterlinks_manage_link_scanner';
			}

			// Update Promo Cards capability to use custom permission
			if ( $key === BETTERLINKS_PLUGIN_SLUG . '-promo-cards' ) {
				$sub_menu[ $key ]['capability'] = 'betterlinks_manage_promo_cards';
			}

			// Update Bio Links capability to use custom permission
			if ( $key === BETTERLINKS_PLUGIN_SLUG . '-bio-links' ) {
				$sub_menu[ $key ]['capability'] = 'betterlinks_manage_bio_links';
			}
			
			// Update Tags & Categories capability to use custom permission
			if ( $key === BETTERLINKS_PLUGIN_SLUG . '-manage-tags-and-categories' ) {
				$sub_menu[ $key ]['capability'] = 'betterlinks_manage_tags_categories';
			}
		}

		// BetterLinks only registers the Custom Domain page when the
		// `enable_custom_domain_menu` setting is on, but Pro's admin sidebar links
		// to it whenever the user can edit settings. When the two disagree the link
		// points at a page WordPress never registered, so loading it directly (a
		// reload, a bookmark) dies with "Sorry, you are not allowed to access this
		// page". Pro links to it, so Pro registers it.
		$custom_domain_key = BETTERLINKS_PLUGIN_SLUG . '-custom-domain';
		if ( $can_current_user_edit_settings && ! isset( $sub_menu[ $custom_domain_key ] ) ) {
			// Match the position BetterLinks uses: straight after Manage Links and
			// Tags & Categories. String keys survive array_splice, numeric ones don't.
			$before   = array_splice( $sub_menu, 0, 2 );
			$sub_menu = $before + array(
				$custom_domain_key => array(
					'title'      => __( 'Custom Domain', 'betterlinks-pro' ),
					'capability' => 'betterlinks_edit_settings',
				),
			) + $sub_menu;
		}

		return $sub_menu;
	}

	/**
	 * Add custom capability for license management based on role permissions
	 *
	 * @param array $allcaps All capabilities for the user
	 * @param array $caps Required capabilities
	 * @param array $args Arguments passed to current_user_can()
	 * @return array Modified capabilities
	 */
	public function add_custom_license_capability( $allcaps, $caps, $args ) {
		// Check if we're checking for our custom capability
		if ( isset( $args[0] ) && $args[0] === 'betterlinks_edit_settings' ) {
			// Use the same filter that other parts of the plugin use
			$can_edit_settings = apply_filters( 'betterlinkspro/admin/current_user_can_edit_settings', current_user_can( 'manage_options' ) );
			$allcaps['betterlinks_edit_settings'] = $can_edit_settings;
		}
		
		// Check if we're checking for Analytics capability
		if ( isset( $args[0] ) && $args[0] === 'betterlinks_check_analytics' ) {
			$user               = wp_get_current_user();
			$user_permission    = json_decode( get_option( BETTERLINKS_PRO_ROLE_PERMISSON_OPTION_NAME, '{}' ), true );
			$can_check_analytics = Helper::current_user_can_do( 'checkanalytics', $user, $user_permission );
			$allcaps['betterlinks_check_analytics'] = $can_check_analytics;
		}
		
		// Check if we're checking for Link Scanner capability
		if ( isset( $args[0] ) && $args[0] === 'betterlinks_manage_link_scanner' ) {
			$user               = wp_get_current_user();
			$user_permission    = json_decode( get_option( BETTERLINKS_PRO_ROLE_PERMISSON_OPTION_NAME, '{}' ), true );
			$can_manage_link_scanner = Helper::current_user_can_do( 'manageLinkScanner', $user, $user_permission );
			$allcaps['betterlinks_manage_link_scanner'] = $can_manage_link_scanner;
		}

		// Check if we're checking for Promo Cards capability
		if ( isset( $args[0] ) && $args[0] === 'betterlinks_manage_promo_cards' ) {
			$user               = wp_get_current_user();
			$user_permission    = json_decode( get_option( BETTERLINKS_PRO_ROLE_PERMISSON_OPTION_NAME, '{}' ), true );
			$allcaps['betterlinks_manage_promo_cards'] = Helper::current_user_can_do( 'managePromoCards', $user, $user_permission );
		}

		// Check if we're checking for Bio Links capability
		if ( isset( $args[0] ) && $args[0] === 'betterlinks_manage_bio_links' ) {
			$user               = wp_get_current_user();
			$user_permission    = json_decode( get_option( BETTERLINKS_PRO_ROLE_PERMISSON_OPTION_NAME, '{}' ), true );
			$allcaps['betterlinks_manage_bio_links'] = Helper::current_user_can_do( 'manageBioLinks', $user, $user_permission );
		}
		
		// Check if we're checking for Tags & Categories capability
		// Allow viewing for anyone with BetterLinks permissions, but manage permission is checked separately
		if ( isset( $args[0] ) && $args[0] === 'betterlinks_manage_tags_categories' ) {
			// Administrators always have access
			if ( current_user_can( 'manage_options' ) ) {
				$allcaps['betterlinks_manage_tags_categories'] = true;
			} else {
				$user               = wp_get_current_user();
				$user_permission    = json_decode( get_option( BETTERLINKS_PRO_ROLE_PERMISSON_OPTION_NAME, '{}' ), true );
				
				// Allow page access if user has any BetterLinks permission
				if ( ! is_array( $user_permission ) ) {
					$allcaps['betterlinks_manage_tags_categories'] = false;
				} else {
					$current_user_roles = current( $user->roles );
					$has_any_permission = false;
					
					// Check if user has any BetterLinks permission
					foreach ( ['viewlinks', 'writelinks', 'editlinks', 'checkanalytics', 'editsettings', 'manageTagsCategories', 'manageAutoliks', 'editFavorite', 'manageLinkScanner'] as $permission ) {
						if ( isset( $user_permission[$permission] ) && \BetterLinksPro\Helper::role_matches( $current_user_roles, $user_permission[$permission] ) ) {
							$has_any_permission = true;
							break;
						}
					}
					
					$allcaps['betterlinks_manage_tags_categories'] = $has_any_permission;
				}
			}
		}
		
		return $allcaps;
	}
}
