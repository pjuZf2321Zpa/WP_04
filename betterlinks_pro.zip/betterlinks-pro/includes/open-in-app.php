<?php
/**
 * Open in App interstitial.
 *
 * Rendered by {@see \BetterLinksPro\Link\OpenInApp::render()} with:
 *   $plan    { app, mode, label, open, web, os, in_app, auto }
 *   $nonce   CSP nonce for this response
 *   $link_id The link's ID, for `btl_header_redirect`
 *   $title   The link's title
 *
 * One bottom sheet: a card saying who shared the link and where it goes, one
 * button, and a way to stay. Help for a blocked tap only appears once a tap
 * has been blocked.
 *
 * @package BetterLinksPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$btl_open      = (string) $plan['open'];
$btl_web       = (string) $plan['web'];
$btl_label     = (string) $plan['label'];
$btl_in_app    = \BetterLinksPro\Link\OpenInApp::in_app_label( $plan['in_app'] );
$btl_protocols = \BetterLinksPro\Link\OpenInApp::allowed_protocols( $btl_open );
$btl_is_ios    = 'ios' === $plan['os'];
$btl_browser   = isset( $plan['mode'] ) && 'browser' === $plan['mode'];
// On iPhone, Meta's in-app browser may refuse the app link however it is
// tapped. When that happens the page says so and points at the menu route
// that always works, instead of loading the web page inside the app.
$btl_guide = $btl_is_ios && '' !== (string) $plan['in_app'];
$btl_menu  = \BetterLinksPro\Link\OpenInApp::escape_menu_label( (string) $plan['in_app'] );

if ( $btl_browser ) {
	$btl_button = $btl_is_ios ? __( 'Open in Safari', 'betterlinks-pro' ) : __( 'Open in your browser', 'betterlinks-pro' );
} else {
	/* translators: %s: app name, e.g. Amazon */
	$btl_button = sprintf( __( 'Open in %s app', 'betterlinks-pro' ), $btl_label );
}

// Who shared the link. Without it the page is an anonymous "open this app"
// prompt, which reads like phishing.
$btl_site_name = trim( wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) );
$btl_site_host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
$btl_sender    = '' !== $btl_site_name ? $btl_site_name : $btl_site_host;
$btl_site_icon = get_site_icon_url( 96 );
$btl_initial   = function_exists( 'mb_substr' ) ? mb_strtoupper( mb_substr( $btl_sender, 0, 1 ) ) : strtoupper( substr( $btl_sender, 0, 1 ) );

// Where it goes, as people read a link: host, path and whatever query
// identifies the page (YouTube's `v=`), without the scheme, "www." or
// tracking and affiliate parameters.
$btl_dest_parts = wp_parse_url( $btl_web );
$btl_dest       = preg_replace( '/^www\./i', '', isset( $btl_dest_parts['host'] ) ? (string) $btl_dest_parts['host'] : '' )
	. ( isset( $btl_dest_parts['path'] ) && '/' !== $btl_dest_parts['path'] ? untrailingslashit( (string) $btl_dest_parts['path'] ) : '' );
if ( ! empty( $btl_dest_parts['query'] ) ) {
	wp_parse_str( (string) $btl_dest_parts['query'], $btl_query );
	foreach ( array_keys( $btl_query ) as $btl_key ) {
		if ( preg_match( '/^(utm_.*|si|tag|ref_?|fbclid|gclid|igsh|igshid|feature|list|index|start_radio|pp|ascsubtag|linkcode|psc|th)$/i', (string) $btl_key ) ) {
			unset( $btl_query[ $btl_key ] );
		}
	}
	if ( $btl_query ) {
		$btl_dest .= '?' . http_build_query( $btl_query );
	}
}
// "Wikipedia.org" over "wikipedia.org" says nothing twice.
$btl_dest_line = strtolower( $btl_dest ) !== strtolower( $btl_label ) ? $btl_dest : '';

/* translators: %s: app name, e.g. Amazon, or a site such as Wikipedia.org */
$btl_heading = sprintf( __( 'Open in %s', 'betterlinks-pro' ), $btl_browser ? ( $btl_is_ios ? 'Safari' : __( 'your browser', 'betterlinks-pro' ) ) : $btl_label );

// Inside an in-app browser the web link loads right there, so say so.
$btl_web_label = '' !== $btl_in_app
	/* translators: %s: the app whose browser the visitor is in, e.g. Instagram */
	? sprintf( __( 'Continue in %s', 'betterlinks-pro' ), $btl_in_app )
	: __( 'Continue in browser', 'betterlinks-pro' );
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
	<meta name="robots" content="noindex, nofollow">
	<meta name="color-scheme" content="light dark">
	<title><?php echo esc_html( '' !== $title ? $title : $btl_heading ); ?></title>
	<?php wp_site_icon(); ?>
	<style nonce="<?php echo esc_attr( $nonce ); ?>">
		:root {
			--ink: #0f1115; --ink-2: #5d6470; --ink-3: #9aa0a9;
			--line: #e7e8eb; --sheet: #fff; --wash: #f4f4f5; --chip: #f4f4f5;
			--btn: #0f1115; --btn-ink: #fff;
		}
		@media (prefers-color-scheme: dark) {
			:root {
				--ink: #f2f3f5; --ink-2: #a3a9b3; --ink-3: #6e7581;
				--line: #2a2d33; --sheet: #17191d; --wash: #0c0d0f; --chip: #24272c;
				--btn: #f2f3f5; --btn-ink: #0f1115;
			}
		}
		* { box-sizing: border-box; }
		html, body { margin: 0; }
		body {
			min-height: 100vh; min-height: 100dvh;
			display: flex; flex-direction: column; justify-content: flex-end; align-items: center;
			padding: 12px 12px calc(12px + env(safe-area-inset-bottom));
			background: var(--wash); color: var(--ink);
			font: 15px/1.45 -apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
			-webkit-font-smoothing: antialiased; -webkit-text-size-adjust: 100%;
		}
		.oia { width: 100%; max-width: 440px; padding: 14px 14px 6px; border-radius: 22px; background: var(--sheet); }
		.oia__card { border: 1px solid var(--line); border-radius: 16px; overflow: hidden; }
		.oia__by { display: flex; align-items: center; gap: 10px; padding: 12px 14px; }
		.oia__av {
			flex: none; width: 32px; height: 32px; border-radius: 50%; overflow: hidden;
			display: grid; place-items: center; background: var(--ink); color: var(--sheet);
			font-size: 14px; font-weight: 700;
		}
		.oia__av img { width: 100%; height: 100%; object-fit: cover; display: block; }
		.oia__by p { margin: 0; min-width: 0; line-height: 1.25; }
		.oia__by strong { display: block; font-size: 14px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
		.oia__by small { font-size: 12px; color: var(--ink-3); }
		.oia__to { padding: 12px 14px; border-top: 1px solid var(--line); min-width: 0; }
		.oia__to b { display: block; font-size: 15px; font-weight: 600; letter-spacing: -.01em; }
		.oia__to span { display: block; font-size: 12.5px; color: var(--ink-3); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
		.oia__help {
			display: none; margin: 12px 0 0; padding: 11px 12px; border-radius: 12px;
			background: var(--chip); font-size: 13.5px; color: var(--ink);
		}
		.oia__dots { display: inline-block; padding: 0 5px; border-radius: 5px; background: var(--sheet); font-weight: 700; letter-spacing: 1px; }
		.oia__btn {
			display: block; margin-top: 14px; padding: 14px 16px; border-radius: 13px;
			background: var(--btn); color: var(--btn-ink); text-align: center; text-decoration: none;
			font-size: 16px; font-weight: 600; letter-spacing: -.01em; -webkit-tap-highlight-color: transparent;
		}
		.oia__btn:active { opacity: .85; }
		.oia__btn:focus, .oia__stay:focus { outline: none; }
		.oia__btn:focus-visible, .oia__stay:focus-visible { outline: 2px solid var(--ink-3); outline-offset: 2px; }
		.oia__stay { display: block; padding: 12px; text-align: center; color: var(--ink-2); font-size: 14px; text-decoration: none; }
		.oia__arrow { position: fixed; top: 4px; right: 14px; width: 48px; height: 48px; color: var(--ink); display: none; }
		.is-blocked .oia__help, .is-blocked .oia__arrow { display: block; }
		@media (prefers-reduced-motion: no-preference) {
			.is-blocked .oia__help { animation: oia-in .25s ease-out; }
			.is-blocked .oia__arrow { animation: oia-nudge 1s ease-in-out infinite alternate; }
			@keyframes oia-in { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: none; } }
			@keyframes oia-nudge { from { transform: translate(0, 0); } to { transform: translate(3px, -5px); } }
		}
	</style>
</head>
<body>
	<?php if ( $btl_guide ) : ?>
	<svg class="oia__arrow" viewBox="0 0 48 48" fill="none" aria-hidden="true"><path d="M8 42C14 25 25 15 40 9" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/><path d="M29 6l12 3-3 12" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>
	<?php endif; ?>
	<main class="oia">
		<div class="oia__card">
			<div class="oia__by">
				<span class="oia__av" aria-hidden="true">
					<?php if ( $btl_site_icon ) : ?>
					<img src="<?php echo esc_url( $btl_site_icon ); ?>" alt="">
					<?php else : ?>
						<?php echo esc_html( $btl_initial ); ?>
					<?php endif; ?>
				</span>
				<p>
					<strong><?php echo esc_html( $btl_sender ); ?></strong>
					<small><?php esc_html_e( 'shared a link', 'betterlinks-pro' ); ?></small>
				</p>
			</div>
			<div class="oia__to">
				<b><?php echo esc_html( $btl_label ); ?></b>
				<?php if ( '' !== $btl_dest_line ) : ?>
				<span><?php echo esc_html( $btl_dest_line ); ?></span>
				<?php endif; ?>
			</div>
		</div>

		<?php if ( $btl_guide ) : ?>
		<p class="oia__help" id="oia-help" role="status">
			<?php
			printf(
				/* translators: 1: the in-app browser, e.g. Instagram; 2: the "···" menu button; 3: the menu item, e.g. Open in external browser */
				esc_html__( '%1$s blocked it. Tap %2$s above, then %3$s.', 'betterlinks-pro' ),
				esc_html( $btl_in_app ),
				'<span class="oia__dots" aria-label="' . esc_attr__( 'more', 'betterlinks-pro' ) . '">···</span>',
				'<b>' . esc_html( $btl_menu ) . '</b>'
			);
			?>
		</p>
		<?php endif; ?>

		<a class="oia__btn" id="oia-open" href="<?php echo esc_url( $btl_open, $btl_protocols ); ?>" rel="noopener"><?php echo esc_html( $btl_button ); ?></a>
		<a class="oia__stay" href="<?php echo esc_url( $btl_web ); ?>" rel="noopener"><?php echo esc_html( $btl_web_label ); ?></a>
	</main>
	<?php
	// The admin's tracking snippets (GTM, Pixel…) belong on a page the visitor
	// actually sees; this is one. Tags come back stamped with the CSP nonce.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
	do_action( 'btl_header_redirect', $link_id );
	?>
	<script nonce="<?php echo esc_attr( $nonce ); ?>">
	(function () {
		var open = <?php echo wp_json_encode( esc_url_raw( $btl_open, $btl_protocols ) ); ?>;
		var web = <?php echo wp_json_encode( esc_url_raw( $btl_web ) ); ?>;
		var auto = <?php echo $plan['auto'] ? 'true' : 'false'; ?>;
		var guide = <?php echo $btl_guide ? 'true' : 'false'; ?>;
		var retry = <?php echo wp_json_encode( __( 'Try again', 'betterlinks-pro' ) ); ?>;
		var hidden = false;
		document.addEventListener('visibilitychange', function () { if (document.hidden) { hidden = true; } });
		window.addEventListener('pagehide', function () { hidden = true; });

		// When the app opens, this page is hidden and the timer is cancelled.
		// When it does not (app not installed, host browser refused), the
		// visitor still lands on the web page without a second tap.
		function fallBack(delay) {
			var started = Date.now();
			setTimeout(function () {
				if (!hidden && Date.now() - started < delay + 1500) { window.location.replace(web); }
			}, delay);
		}
		// On iPhone a refused tap leaves this page in place. Sending the visitor
		// on to the web page there would strand them in the in-app browser,
		// which is the one thing they came here to avoid — point at the menu
		// that gets them out instead.
		function flagBlocked() {
			setTimeout(function () {
				if (!hidden && document.body.className.indexOf('is-blocked') === -1) {
					document.body.className += ' is-blocked';
					document.getElementById('oia-open').textContent = retry;
				}
			}, 1200);
		}
		document.getElementById('oia-open').addEventListener('click', function () {
			if (guide) { flagBlocked(); } else { fallBack(2500); }
		});
		if (auto && !guide) {
			// Android in-app browsers honour a programmatic intent:// load.
			setTimeout(function () { window.location.href = open; fallBack(3000); }, 60);
		} else if (auto) {
			// iPhone in-app browser: try once without a tap. When Instagram lets
			// it through, the app opens and this page is never really seen.
			// When it refuses, nothing happens and the page stays as the
			// backup, its button a real tap — no web fallback, no "blocked"
			// message for a launch the visitor never asked for.
			setTimeout(function () { if (!hidden) { window.location.href = open; } }, 150);
		}
	})();
	</script>
</body>
</html>
