<?php
// @-collapse
namespace BetterLinksPro;
if ( ! defined( 'ABSPATH' ) ) { exit; }

// use BetterLinks\Traits\Clicks;

class Helper {
	// use Clicks;

	private static $transient_timeout = MINUTE_IN_SECONDS * 30;
	
	public static function get_all_roles() {
		global $wp_roles;
		$all_roles = $wp_roles->roles;
		unset( $all_roles['administrator'] );
		return wp_list_pluck( $all_roles, 'name' );
	}
	public static function current_user_can_do( $role, $user, $userPermission ) {
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}
		$current_user_roles = current( $user->roles );

		if ( isset( $userPermission[ $role ] ) && self::role_matches( $current_user_roles, $userPermission[ $role ] ) ) {
			return true;
		}
		return false;
	}

	/**
	 * Does the current user's role appear in one of the role-management buckets?
	 *
	 * Replaces the loose `in_array( $role, $bucket )` this matrix used everywhere.
	 * Two facts combined into a privilege escalation there:
	 *
	 *   1. `current( $user->roles )` returns FALSE for a user with no role on this
	 *      site — a normal WordPress state ("— No role for this site —"), and the
	 *      usual way an account is parked without deleting it.
	 *   2. The Role Management screen posts an unchecked capability as an empty
	 *      string, which `explode( ',', '' )` stores as `array( '' )`. So a bucket
	 *      nobody is granted is `['']`, not `[]`.
	 *
	 * `in_array( false, [''] )` is TRUE under PHP's loose comparison, so a role-less
	 * logged-in user matched every capability the admin had granted to nobody —
	 * including `editsettings` (full settings read/write over REST) and
	 * `writelinks` / `editlinks` (create and repoint short links on this domain).
	 *
	 * Strict comparison alone is not enough: '' === '' would still match once the
	 * resolver is normalised to a string, so empty entries are dropped from the
	 * bucket as well. Both ends are handled here so an option that was already
	 * saved in the poisoned shape is safe without a migration.
	 *
	 * @param mixed $role   Role slug from current( $user->roles ) — FALSE when none.
	 * @param mixed $bucket The permission bucket to test against.
	 * @return bool
	 */
	public static function role_matches( $role, $bucket ) {
		if ( ! is_string( $role ) || '' === $role || ! is_array( $bucket ) ) {
			return false;
		}

		foreach ( $bucket as $allowed ) {
			if ( is_string( $allowed ) && '' !== $allowed && $allowed === $role ) {
				return true;
			}
		}

		return false;
	}

	public static function is_json( $string, $return_data = false ) {
		if ( is_array( $string ) ) {
			return false;
		}
		$data = json_decode( $string );
		return ( json_last_error() == JSON_ERROR_NONE ) ? ( $return_data ? $data : true ) : false;
	}

	/**
	 * Resolve the visitor IP.
	 *
	 * Delegates to the core resolver, which trusts REMOTE_ADDR and only honors a
	 * forwarding header when the peer is inside an operator-configured
	 * trusted-proxy range. Previously this walked HTTP_CLIENT_IP /
	 * X-Forwarded-For / Forwarded first, which any anonymous visitor can set:
	 * that both let a caller pick which branch of a geographic dynamic redirect
	 * they land on, and let them force a fresh per-IP transient + outbound
	 * lookup on every hit of a public short link.
	 *
	 * @return string|null
	 */
	public static function get_current_client_ip() {
		// The free plugin's trusted-proxy aware resolver (BetterLinks 3.2+), then
		// the same resolver under its older class name.
		if ( class_exists( '\\BetterLinks\\Services\\ClientIp' ) ) {
			return \BetterLinks\Services\ClientIp::get_current_client_ip();
		}
		if ( class_exists( '\\BetterLinks\\Services\\CountryDetectionService' ) && method_exists( '\\BetterLinks\\Services\\CountryDetectionService', 'get_current_client_ip' ) ) {
			return \BetterLinks\Services\CountryDetectionService::get_current_client_ip();
		}

		// Fallback if core is unavailable: REMOTE_ADDR only, never a header.
		$ipaddress = isset( $_SERVER['REMOTE_ADDR'] )
			? trim( sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) )
			: '';

		return filter_var( $ipaddress, FILTER_VALIDATE_IP ) ? $ipaddress : null;
	}
	/**
	 * Google Analytics / Pixel / parameter tracking settings (Pro option).
	 *
	 * Read from the option directly: they are no longer merged into links.json.
	 *
	 * @return array
	 */
	public static function get_external_analytics_settings() {
		static $settings = null;
		if ( null === $settings ) {
			$settings = get_option( BETTERLINKS_PRO_EXTERNAL_ANALYTICS_OPTION_NAME, array() );
			if ( is_string( $settings ) ) {
				$settings = json_decode( $settings, true );
			}
			$settings = is_array( $settings ) ? $settings : array();
		}
		return $settings;
	}

	/**
	 * Fixed-window counter (rate limiting / lookup budgets).
	 *
	 * Uses the free plugin's shared limiter when available so both plugins count
	 * against the same transient, otherwise the same algorithm locally.
	 *
	 * @param string $key    Transient key.
	 * @param int    $limit  Allowed hits per window.
	 * @param int    $window Window length in seconds.
	 * @return bool True when the hit is within budget.
	 */
	public static function consume_bucket( $key, $limit, $window ) {
		if ( class_exists( '\\BetterLinks\\Services\\RateLimiter' ) ) {
			return \BetterLinks\Services\RateLimiter::consume_bucket( $key, $limit, $window );
		}
		if ( class_exists( '\\BetterLinks\\Services\\CountryDetectionService' ) && method_exists( '\\BetterLinks\\Services\\CountryDetectionService', 'consume_bucket' ) ) {
			return \BetterLinks\Services\CountryDetectionService::consume_bucket( $key, $limit, $window );
		}
		$bucket = get_transient( $key );
		$now    = time();
		if ( ! is_array( $bucket ) || ! isset( $bucket['start'], $bucket['count'] ) || ( $now - (int) $bucket['start'] ) >= $window ) {
			$bucket = array( 'start' => $now, 'count' => 0 );
		}
		++$bucket['count'];
		set_transient( $key, $bucket, max( 1, $window - ( $now - (int) $bucket['start'] ) ) );
		return ( $bucket['count'] <= $limit );
	}

	public static function get_country_code() {
		$ip = self::get_current_client_ip();

		if ( empty( $ip ) ) {
			return;
		}

		// Key kept byte-identical to the pre-existing scheme so upgrading does not
		// invalidate every site's cached country data at once.
		$transient_key = 'betterlinkspro' . $ip;
		$country_code  = get_transient( $transient_key );
		if ( $country_code ) {
			return $country_code;
		}

		// Circuit breaker on cache-miss lookups so a burst of traffic cannot burn
		// unbounded upstream quota or create unbounded transients.
		$limit = (int) apply_filters( 'betterlinks/geolocation/hourly_lookup_limit', \BetterLinksPro\Services\CountryDetectionService::MAX_LOOKUPS_PER_HOUR );
		if ( $limit > 0 && ! self::consume_bucket( 'btl_geo_lookup_budget', $limit, HOUR_IN_SECONDS ) ) {
			return;
		}

		$apiUrl       = 'https://api.notificationx.com/maps/v2/?ip=' . rawurlencode( $ip );
		$response     = wp_remote_get( $apiUrl, array(
			'headers' => array(
				'User-Agent' => 'BetterLinks/'
			)
		) );

		if ( is_wp_error( $response ) ) {
			return;
		}

		$responseBody = wp_remote_retrieve_body( $response );
		$result       = json_decode( $responseBody, true );
		if ( is_array( $result ) && isset( $result['success'], $result['data']['country_code'] ) && $result['success'] ) {
			set_transient( $transient_key, $result['data']['country_code'], DAY_IN_SECONDS );
			return $result['data']['country_code'];
		}

		return;
	}
	public static function get_client_info() {
		$useragent = ( isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '' );
		if ( $useragent ) {
			$Browser = new Lib\BrowserDetection();
			return array(
				'browser' => $Browser->getBrowser( $useragent )['browser_name'],
				'os'      => $Browser->getOS( $useragent )['os_name'],
				'device'  => $Browser->getDevice( $useragent )['device_type'],
			);
		}
		return;
	}

	public static function check_in_range( $start_date, $end_date, $date_from_user ) {
		// Convert to timestamp
		$start = strtotime( $start_date );
		$end   = strtotime( $end_date );
		$check = is_numeric( $date_from_user ) ? $date_from_user : strtotime( $date_from_user );
		// Check that user date is between start & end
		return ( ( $start <= $check ) && ( $check <= $end ) );
	}
	public static function addScheme( $url, $scheme = 'http://' ) {
		if ( strpos( $url, '/' ) === 0 ) {
			return $url = site_url( '/' ) . $url;
		}
		return apply_filters( 'betterlinks/link/target_url', wp_parse_url( $url, PHP_URL_SCHEME ) === null ? $scheme . $url : $url );
	}
	/**
	 * Classify a target URL as healthy / broken / unverifiable.
	 *
	 * A pure HTTP scanner cannot reliably tell "real 4xx" from "bot-detection 4xx" with a
	 * single request — Cloudflare, Akamai, Shopify, Linksynergy etc. all return 403/404
	 * to anything they classify as a scraper, even when the URL works fine in a real
	 * browser. This classifier reduces those false positives by:
	 *
	 *   1. Sending a primary GET via Guzzle that mimics a real Chrome session
	 *      (browser UA, full Sec-Fetch-* set, Accept-Encoding, optional Referer).
	 *   2. Inspecting response headers for known anti-bot CDN signals
	 *      (Cloudflare / Akamai / Sucuri / Imperva). When those are present alongside a
	 *      non-2xx, the response is almost certainly a bot challenge — verdict
	 *      "unverifiable", not "broken".
	 *   3. Cross-verifying ambiguous 4xx/5xx via WordPress' native HTTP API (different
	 *      cURL handle, different default UA). If the secondary path comes back healthy,
	 *      the primary failure was bot detection — verdict "healthy".
	 *
	 * Only the following are reported as definitively "broken":
	 *   - HTTP 410 Gone / 451 Unavailable For Legal Reasons (explicit "this is gone")
	 *   - Connection-level failure that survived a retry (DNS / TLS / connection refused
	 *     / timeout) AND whose secondary verification also fails
	 *
	 * Backwards-compatible return shape — callers reading $result['status_code'] get the
	 * same int|true value they used to. New keys ('verdict', 'note', 'verified_via') are
	 * additive.
	 *
	 * @param string $url  Absolute URL to check.
	 * @param array  $args Optional: referer, connect_timeout, timeout.
	 * @return array {
	 *     status_code: int|true,
	 *     verdict:     'healthy'|'broken'|'unverifiable',
	 *     note?:       string,
	 *     verified_via?: 'primary'|'secondary',
	 *     err_type?:   string,
	 *     err_message?: string,
	 * }
	 */
	public static function url_http_response_is_broken( $url, $args = array() ) {
		// SSRF gate: the scanner fetches caller-influenced link URLs server-side,
		// so refuse anything that is not a public http(s) target. wp_http_validate_url()
		// rejects loopback, RFC1918, link-local 169.254/16, CGNAT, reserved ranges
		// and non-http(s) schemes. Redirects are re-validated per hop below.
		if ( ! self::is_public_http_url( $url ) ) {
			return array(
				'status_code'  => true,
				'verdict'      => 'unverifiable',
				'note'         => 'blocked_non_public_url',
			);
		}

		$primary = self::scanner_request_via_guzzle( $url, $args );

		// Healthy response — done.
		if ( self::scanner_is_healthy_code( $primary['status_code'] ) ) {
			$primary['verdict']      = 'healthy';
			$primary['verified_via'] = 'primary';
			return $primary;
		}

		// 410 Gone / 451 are unambiguous "this resource is dead" signals.
		if ( in_array( intval( $primary['status_code'] ), array( 410, 451 ), true ) ) {
			$primary['verdict'] = 'broken';
			return $primary;
		}

		// Anti-bot CDN signature on a non-2xx → almost certainly a challenge, not real
		// breakage. Skip the secondary call (it would hit the same CDN and give the same
		// answer) and downgrade to "unverifiable".
		if ( ! empty( $primary['bot_protected'] ) ) {
			$primary['verdict'] = 'unverifiable';
			$primary['note']    = 'bot_protected_origin';
			return $primary;
		}

		// Cross-verify everything else (401/403/404/4xx/5xx and connection errors)
		// via wp_remote_get. The different request shape sometimes slips past
		// per-handle bot detection (different default UA, different cURL options).
		$secondary = self::scanner_request_via_wp_http( $url, $args );

		if ( self::scanner_is_healthy_code( $secondary['status_code'] ) ) {
			// Primary failure was a false positive — the link works.
			return array(
				'status_code'    => $secondary['status_code'],
				'verdict'        => 'healthy',
				'verified_via'   => 'secondary',
				'primary_status' => $primary['status_code'],
			);
		}

		// Both attempts failed. Connection-level failure on both is a real broken link.
		if ( true === $primary['status_code'] && true === $secondary['status_code'] ) {
			$primary['verdict'] = 'broken';
			$primary['note']    = 'connection_failed_both_paths';
			return $primary;
		}

		// Two HTTP paths returning matching definitive-broken codes (410/451) is broken;
		// already handled above. Anything else (consistent 401/403/404/5xx across paths)
		// is more likely the origin not liking automated requests than a real outage.
		$primary['verdict']         = 'unverifiable';
		$primary['note']            = 'consistent_non_2xx';
		$primary['secondary_status'] = $secondary['status_code'];
		return $primary;
	}

	/**
	 * Whether an HTTP status code indicates the link works.
	 */
	private static function scanner_is_healthy_code( $code ) {
		if ( ! is_int( $code ) ) {
			return false;
		}
		return $code >= 200 && $code < 400;
	}

	/**
	 * Set of headers that make a request indistinguishable from a real Chrome session.
	 */
	private static function scanner_browser_headers( $args ) {
		$default_ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36';
		$user_agent = ! empty( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : $default_ua;

		$headers = array(
			'User-Agent'                => $user_agent,
			'Accept'                    => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
			'Accept-Language'           => 'en-US,en;q=0.9',
			'Accept-Encoding'           => 'gzip, deflate',
			'Cache-Control'             => 'max-age=0',
			'Sec-Fetch-Dest'            => 'document',
			'Sec-Fetch-Mode'            => 'navigate',
			'Sec-Fetch-Site'            => 'none',
			'Sec-Fetch-User'            => '?1',
			'Upgrade-Insecure-Requests' => '1',
		);
		if ( ! empty( $args['referer'] ) ) {
			$headers['Referer'] = $args['referer'];
		}
		return $headers;
	}

	/**
	 * Detect anti-bot CDN markers in response headers. Conservative — a true positive
	 * here means the origin is fronted by a service that commonly returns 4xx to
	 * automated traffic (Cloudflare, Akamai, Sucuri, Imperva/Incapsula, Linksynergy).
	 */
	private static function scanner_detect_bot_protection( array $response_headers ) {
		// Normalize header keys to lowercase for case-insensitive checks.
		$normalized = array();
		foreach ( $response_headers as $name => $values ) {
			$normalized[ strtolower( $name ) ] = is_array( $values ) ? implode( ' ', $values ) : (string) $values;
		}
		$bot_marker_headers = array( 'cf-ray', 'cf-cache-status', 'cf-mitigated', 'x-akamai-transformed', 'x-sucuri-id', 'x-iinfo' );
		foreach ( $bot_marker_headers as $h ) {
			if ( isset( $normalized[ $h ] ) ) {
				return true;
			}
		}
		$server = isset( $normalized['server'] ) ? strtolower( $normalized['server'] ) : '';
		foreach ( array( 'cloudflare', 'akamai', 'sucuri', 'incapsula', 'imperva', 'linksynergy' ) as $needle ) {
			if ( '' !== $server && false !== strpos( $server, $needle ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Primary check: GET via Guzzle with a real-Chrome request shape. Retries once on
	 * connection-level failure. Returns at minimum a status_code (int|true).
	 */
	/**
	 * Whether a URL is a public http(s) target safe to fetch server-side.
	 *
	 * Wraps wp_http_validate_url(), which blocks loopback, private, link-local
	 * (incl. 169.254.169.254 cloud metadata), CGNAT and reserved ranges and any
	 * non-http(s) scheme. Used to gate the broken-link scanner against SSRF.
	 *
	 * @param string $url
	 * @return bool
	 */
	private static function is_public_http_url( $url ) {
		if ( ! is_string( $url ) || '' === $url ) {
			return false;
		}
		$scheme = strtolower( (string) wp_parse_url( $url, PHP_URL_SCHEME ) );
		if ( ! in_array( $scheme, array( 'http', 'https' ), true ) ) {
			return false;
		}
		return (bool) wp_http_validate_url( $url );
	}

	private static function scanner_request_via_guzzle( $url, $args ) {
		$options = array(
			'headers'         => self::scanner_browser_headers( $args ),
			'http_errors'     => false,
			'verify'          => false,
			'allow_redirects' => array(
				// Browsers cap at ~20; affiliate hops can easily reach 12-15.
				'max'             => 20,
				'strict'          => false,
				'referer'         => true,
				'protocols'       => array( 'http', 'https' ),
				'track_redirects' => false,
				// Re-validate each redirect target so a public URL cannot bounce the
				// request onto an internal address (SSRF via redirect / DNS rebinding).
				'on_redirect'     => function ( $request, $response, $uri ) {
					if ( ! self::is_public_http_url( (string) $uri ) ) {
						throw new \BetterLinksPro\Dependencies\GuzzleHttp\Exception\TooManyRedirectsException(
							'Redirect to a non-public address was blocked.',
							$request
						);
					}
				},
			),
			'connect_timeout' => isset( $args['connect_timeout'] ) ? $args['connect_timeout'] : 15.0,
			'timeout'         => isset( $args['timeout'] ) ? $args['timeout'] : 20,
		);

		$client       = new \BetterLinksPro\Dependencies\GuzzleHttp\Client( $options );
		$max_attempts = 2;
		$attempt      = 0;
		$last_error   = null;
		while ( $attempt < $max_attempts ) {
			$attempt++;
			try {
				$response = $client->request( 'GET', $url );
				$code     = intval( $response->getStatusCode() );
				$out      = array( 'status_code' => $code );
				if ( self::scanner_detect_bot_protection( $response->getHeaders() ) ) {
					$out['bot_protected'] = true;
				}
				return $out;
			} catch ( \BetterLinksPro\Dependencies\GuzzleHttp\Exception\ConnectException $e ) {
				$last_error = array(
					'status_code' => true,
					'err_type'    => 'ConnectException',
					'err_message' => $e->getMessage(),
				);
				if ( $attempt < $max_attempts ) {
					usleep( 500000 );
					continue;
				}
				return $last_error;
			} catch ( \BetterLinksPro\Dependencies\GuzzleHttp\Exception\TooManyRedirectsException $e ) {
				// A long-but-alive redirect chain is not a broken link.
				return array(
					'status_code' => 200,
					'note'        => 'redirect_limit_exceeded',
				);
			} catch ( \BetterLinksPro\Dependencies\GuzzleHttp\Exception\RequestException $e ) {
				return array(
					'status_code' => true,
					'err_type'    => 'GuzzleHttp_Exception_RequestException',
					'err_message' => $e->getMessage(),
				);
			} catch ( \Throwable $e ) {
				return array(
					'status_code' => true,
					'err_type'    => 'Throwable',
					'err_message' => $e->getMessage(),
				);
			} catch ( \Exception $e ) {
				return array(
					'status_code' => true,
					'err_type'    => 'Exception',
					'err_message' => $e->getMessage(),
				);
			}
		}
		return $last_error;
	}

	/**
	 * Secondary check: GET via WordPress' native HTTP API. Different cURL handle,
	 * different default UA — slips past per-client bot heuristics in some cases.
	 */
	private static function scanner_request_via_wp_http( $url, $args ) {
		$wp_args = array(
			'timeout'     => isset( $args['timeout'] ) ? $args['timeout'] : 15,
			'redirection' => 20,
			'sslverify'   => false,
			'headers'     => array(
				'Accept'          => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
				'Accept-Language' => 'en-US,en;q=0.9',
			),
		);
		if ( ! empty( $args['referer'] ) ) {
			$wp_args['headers']['Referer'] = $args['referer'];
		}
		// wp_safe_remote_get() validates the host and re-checks each redirect,
		// closing the SSRF path. $wp_args keeps sslverify=false so cert behavior
		// for external link checks is unchanged — only the destination policy is added.
		$response = wp_safe_remote_get( $url, $wp_args );
		if ( is_wp_error( $response ) ) {
			return array(
				'status_code' => true,
				'err_type'    => 'WP_Error',
				'err_message' => $response->get_error_message(),
			);
		}
		$code = intval( wp_remote_retrieve_response_code( $response ) );
		if ( $code <= 0 ) {
			return array( 'status_code' => true );
		}
		return array( 'status_code' => $code );
	}
	public static function get_timestamp_from_string( $string ) {
		if ( $string === 'yearly' ) {
			return time() + YEAR_IN_SECONDS;
		} elseif ( $string === 'monthly' ) {
			return time() + MONTH_IN_SECONDS;
		} elseif ( $string === 'weekly' ) {
			return time() + WEEK_IN_SECONDS;
		} elseif ( $string === 'daily' ) {
			return time() + DAY_IN_SECONDS;
		}
		return time();
	}
	/**
	 * Normalize a stored scan_time value to a plain HH:MM string.
	 * Tolerates legacy formats:
	 *   - "HH:MM" or "H:MM" (already correct)
	 *   - JSON-stringified ISO datetime ("\"2026-05-05T18:14:29.818Z\"") from Date.toJSON()
	 *   - Plain ISO datetime "2026-05-05T18:14:29.818Z"
	 *   - Microsoft .NET style "/Date(1700000000000)/"
	 * Falls back to "12:00" when the input is unparseable.
	 */
	public static function normalize_scan_time( $value ) {
		$raw = trim( (string) $value );
		if ( '' === $raw ) {
			return '12:00';
		}
		$raw = trim( $raw, '"' );
		if ( preg_match( '/^(\d{1,2}):(\d{2})/', $raw, $m ) ) {
			$h = max( 0, min( 23, (int) $m[1] ) );
			$i = max( 0, min( 59, (int) $m[2] ) );
			return sprintf( '%02d:%02d', $h, $i );
		}
		if ( preg_match( '/Date\((\d+)\)/', $raw, $m ) ) {
			$ts = (int) ( $m[1] / 1000 );
			if ( $ts > 0 ) {
				return wp_date( 'H:i', $ts );
			}
		}
		if ( false !== strpos( $raw, 'T' ) ) {
			$ts = strtotime( $raw );
			if ( false !== $ts ) {
				return wp_date( 'H:i', $ts );
			}
		}
		return '12:00';
	}

	public static function calculate_schedule_timestamp( $scan_mode, $scan_day, $scan_time, $scan_month = null, $scan_year = null ) {
		$scan_time = self::normalize_scan_time( $scan_time );
		if ( 'daily' === $scan_mode ) {
			$today_at  = strtotime( $scan_time, strtotime( 'today' ) );
			if ( false === $today_at || $today_at <= time() ) {
				$today_at = strtotime( '+1 day', $today_at ?: time() );
			}
			return $today_at;
		}

		if ( 'monthly' === $scan_mode ) {
			$day_of_month = (int) $scan_day;
			if ( $day_of_month < 1 || $day_of_month > 31 ) {
				$day_of_month = 1;
			}

			$month = (int) $scan_month;
			$year  = (int) $scan_year;
			if ( $month < 1 || $month > 12 ) {
				$month = (int) gmdate( 'n' );
			}
			if ( $year < 1970 || $year > 9999 ) {
				$year = (int) gmdate( 'Y' );
			}

			$days_in_month = (int) gmdate( 't', mktime( 0, 0, 0, $month, 1, $year ) );
			$use_day       = min( $day_of_month, $days_in_month );
			$candidate     = strtotime( $scan_time, mktime( 0, 0, 0, $month, $use_day, $year ) );
			if ( false === $candidate || $candidate <= time() ) {
				$next_month = $month + 1;
				$next_year  = $year;
				if ( $next_month > 12 ) {
					$next_month = 1;
					$next_year  = $year + 1;
				}
				$next_days_in_month = (int) gmdate( 't', mktime( 0, 0, 0, $next_month, 1, $next_year ) );
				$use_day_next       = min( $day_of_month, $next_days_in_month );
				$candidate          = strtotime( $scan_time, mktime( 0, 0, 0, $next_month, $use_day_next, $next_year ) );
			}
			return $candidate;
		}

		$timestamp           = self::get_timestamp_from_string( $scan_mode );
		$daynum              = (int) gmdate( 'w', strtotime( $scan_day ) );
		$todayWeekDayNumbeer = (int) gmdate( 'w', time() );
		if ( $daynum < $todayWeekDayNumbeer ) {
			return $timestamp = strtotime( $scan_time . ' ' . $scan_day . ' next week', $timestamp );
		}
		$daynum    = abs( $daynum - $todayWeekDayNumbeer );
		$timestamp = strtotime( '+' . $daynum . ' days ' . $scan_time, $timestamp );
		return $timestamp;
	}
	public static function get_individual_link_analytics( $args ) {
		$ID   = isset( $args['id'] ) ? sanitize_text_field( $args['id'] ) : '';
		$from = self::sanitize_date( $args['from'] ) ? sanitize_text_field( $args['from'] ) : gmdate( 'Y-m-d', strtotime( ' - 30 days' ) );
		$to   = self::sanitize_date( $args['to'] ) ? sanitize_text_field( $args['to'] ) : gmdate( 'Y-m-d' );

		global $wpdb;
		$prefix  = $wpdb->prefix;
		$countries_table = $prefix . 'betterlinks_countries';

		// Use normalized schema with JOIN to countries table
		// Table name interpolation via $wpdb->prefix is the recommended WP idiom; values are bound via prepare().
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter
		$results = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT CLICKS.ID as click_ID, link_id, browser, created_at, referer, short_url, target_url, ip,
				co.country_code, co.country_name, {$prefix}betterlinks.link_title,
				(select count(id) from {$prefix}betterlinks_clicks where CLICKS.ip = {$prefix}betterlinks_clicks.ip group by ip) as IPCOUNT
				from {$prefix}betterlinks_clicks as CLICKS
				LEFT JOIN {$countries_table} co ON CLICKS.country_id = co.id
				left join {$prefix}betterlinks on {$prefix}betterlinks.id = CLICKS.link_id
				WHERE created_at BETWEEN %s AND %s AND {$prefix}betterlinks.id = %d
				group by CLICKS.id ORDER BY CLICKS.created_at DESC",
				$from . ' 00:00:00',
				$to . ' 23:59:00',
				$ID
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter
		return $results;
	}
	public static function get_split_test_analytics_data( $args ) {
		$ID                   = isset( $args['id'] ) ? $args['id'] : '';
		$split_analytics_meta = \BetterLinks\Helper::get_link_meta( $ID, 'split_test_analytics' );

		if ( ! empty( $split_analytics_meta ) ) {
			return $split_analytics_meta;
		}
		global $wpdb;
		$prefix  = $wpdb->prefix;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$results = $wpdb->get_results(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$wpdb->prepare( "SELECT cr.target_url as url, COUNT(cr.target_url) as clicks, COUNT(DISTINCT cl.visitor_id) as uniques, (select COUNT(DISTINCT {$prefix}betterlinks_clicks.visitor_id) from {$prefix}betterlinks_clicks where {$prefix}betterlinks_clicks.referer = cr.target_url) as conversions  FROM {$prefix}betterlinks_clicks cl JOIN {$prefix}betterlinks_clicks_rotations cr ON cl.id=cr.click_id WHERE cl.link_id=%d GROUP BY cr.target_url", $ID ),
			ARRAY_A
		);
		return $results;
	}
	public static function get_individual_clicks_count( $id ) {
		global $wpdb;
		
		// Get excluded IPs
		$options      = json_decode( get_option( BETTERLINKS_LINKS_OPTION_NAME ), true );
		$excluded_ips = isset( $options['excluded_ips'] ) && is_array( $options['excluded_ips'] ) ? $options['excluded_ips'] : array();
		$excluded_ips_condition = '';
		if ( ! empty( $excluded_ips ) ) {
			$placeholders = implode( ', ', array_fill( 0, count( $excluded_ips ), '%s' ) );
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
			$excluded_ips_condition = $wpdb->prepare( " AND ip NOT IN ({$placeholders})", $excluded_ips );
		}
		
		$query = "SELECT COUNT(*) FROM {$wpdb->prefix}betterlinks_clicks WHERE link_id=%d" . $excluded_ips_condition;
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$query = $wpdb->prepare( $query, array( $id ) );

		// phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		return (int) $wpdb->get_var( $query );
	}
	public static function get_individual_unique_clicks_count( $id ) {
		global $wpdb;
		
		// Get excluded IPs
		$options      = json_decode( get_option( BETTERLINKS_LINKS_OPTION_NAME ), true );
		$excluded_ips = isset( $options['excluded_ips'] ) && is_array( $options['excluded_ips'] ) ? $options['excluded_ips'] : array();
		$excluded_ips_condition = '';
		if ( ! empty( $excluded_ips ) ) {
			$placeholders = implode( ', ', array_fill( 0, count( $excluded_ips ), '%s' ) );
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
			$excluded_ips_condition = $wpdb->prepare( " AND ip NOT IN ({$placeholders})", $excluded_ips );
		}
		
		$query = "SELECT COUNT(*) FROM (SELECT ip FROM `{$wpdb->prefix}betterlinks_clicks` WHERE `link_id`=%d{$excluded_ips_condition} group by ip) as unique_clicks";
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$query = $wpdb->prepare( $query, array( $id ) );

		// phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		return (int) $wpdb->get_var( $query );
	}

	public static function insert_click_rotation( $args ) {
		global $wpdb;
		$defaults = apply_filters(
			'betterlinkspro/insert_click_rotation_args',
			array(
				'link_id'    => '',
				'click_id'   => '',
				'target_url' => '',
			)
		);
		$args     = wp_parse_args( $args, $defaults );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query(
			$wpdb->prepare(
				"INSERT INTO {$wpdb->prefix}betterlinks_clicks_rotations (
                        link_id,click_id,target_url
                    ) VALUES ( %d, %d, %s )",
				array(
					$args['link_id'],
					$args['click_id'],
					$args['target_url'],
				)
			)
		);
		return $wpdb->insert_id;
	}
	public static function get_all_clicks_rotations() {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$rotations = $wpdb->get_results(
			"SELECT * FROM {$wpdb->prefix}betterlinks_clicks_rotations",
			ARRAY_A
		);
		return $rotations;
	}
	public static function get_prettylinks_meta( $id, $meta_key ) {
		global $wpdb;
		$wpdb_prefix = $wpdb->prefix;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$results     = $wpdb->get_results( $wpdb->prepare( "SELECT meta_key, meta_value from {$wpdb_prefix}prli_link_metas where meta_key=%s AND link_id = %d", $meta_key, $id ), OBJECT );
		return $results;
	}

	public static function insert_new_category( $slug ) {
		// Use the free plugin's implementation, which also returns the ID when the
		// category already exists (this copy returned the slug in that case).
		if ( is_callable( array( '\\BetterLinks\\Helper', 'insert_new_category' ) ) ) {
			return \BetterLinks\Helper::insert_new_category( $slug );
		}
		if ( ! ! intval( $slug ) ) {
			return $slug;
		}

		$is_cat_exists = \BetterLinks\Helper::term_exists( $slug );
		if ( ! $is_cat_exists ) {
			$insert_id = \BetterLinks\Helper::insert_term(
				array(
					'term_name' => $slug,
					'term_slug' => \BetterLinks\Helper::make_slug( $slug ),
					'term_type' => 'category',
				)
			);
			if ( $insert_id ) {
				\BetterLinks\Helper::clear_query_cache();
				$slug = $insert_id;
			}
		}
		return $slug;
	}

	/**
	 * Sanitize a CSS colour value for output inside a style block or attribute.
	 *
	 * Accepts hex, rgb(a)/hsl(a) functional notation and plain colour keywords.
	 * Anything else (semicolons, braces, url(), expressions) returns ''.
	 *
	 * @param mixed  $value    Stored value.
	 * @param string $fallback Returned when the value is not a colour.
	 * @return string
	 */
	public static function sanitize_css_color( $value, $fallback = '' ) {
		$value = trim( (string) $value );
		if ( '' === $value ) {
			return $fallback;
		}
		if ( preg_match( '/^#(?:[0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/', $value ) ) {
			return $value;
		}
		if ( preg_match( '/^(?:rgb|rgba|hsl|hsla)\(\s*[0-9.%\s,\/-]+\)$/i', $value ) ) {
			return $value;
		}
		if ( preg_match( '/^[a-zA-Z]{3,30}$/', $value ) ) {
			return $value;
		}
		return $fallback;
	}

	/**
	 * Sanitize a single CSS keyword token (font-weight, font-style, text-decoration).
	 *
	 * @param mixed  $value    Stored value.
	 * @param string $fallback Returned when the value is not a plain token.
	 * @return string
	 */
	public static function sanitize_css_token( $value, $fallback = 'inherit' ) {
		$value = trim( (string) $value );
		return preg_match( '/^[a-zA-Z0-9-]{1,30}$/', $value ) ? $value : $fallback;
	}

	public static function get_password_by_link_id( $link_id ) {
		global $wpdb;
		$query_string    = "SELECT `id`,`status` FROM {$wpdb->prefix}betterlinks_password where `link_id`=%d";
		$query_value_arr = array( $link_id );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$result          = $wpdb->get_results( $wpdb->prepare( $query_string, $query_value_arr ) );
		return $result;
	}

	/**
	 * Whether a stored link password is a WordPress password hash.
	 *
	 * Passwords saved before hashing was introduced are stored as plain text.
	 *
	 * @param string $stored Stored value.
	 * @return bool
	 */
	public static function is_password_hash( $stored ) {
		$stored = (string) $stored;
		return 0 === strpos( $stored, '$P$' ) || 0 === strpos( $stored, '$wp$' ) || 0 === strpos( $stored, '$2y$' ) || 0 === strpos( $stored, '$argon2' );
	}

	/**
	 * Hash a link password for storage.
	 *
	 * @param string $password Plain password.
	 * @return string
	 */
	public static function hash_link_password( $password ) {
		return wp_hash_password( (string) $password );
	}

	/**
	 * Stored password value for a link, or null.
	 *
	 * @param int $link_id Link ID.
	 * @return string|null
	 */
	private static function get_stored_password( $link_id ) {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$stored = $wpdb->get_var( $wpdb->prepare( "SELECT `password` FROM {$wpdb->prefix}betterlinks_password where `link_id`=%d", $link_id ) );
		return null === $stored ? null : (string) $stored;
	}

	public static function check_password( $password, $link_id ) {
		$password = (string) $password;
		$stored   = self::get_stored_password( $link_id );
		if ( null === $stored || '' === $stored || '' === $password ) {
			return false;
		}

		if ( self::is_password_hash( $stored ) ) {
			return wp_check_password( $password, $stored );
		}

		// Plain-text password saved by an older version: compare in constant time,
		// then replace it with a hash so it is no longer stored readable.
		if ( ! hash_equals( $stored, $password ) ) {
			return false;
		}
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->update( $wpdb->prefix . 'betterlinks_password', array( 'password' => self::hash_link_password( $password ) ), array( 'link_id' => (int) $link_id ), array( '%s' ), array( '%d' ) );
		return true;
	}

	/**
	 * Value of the "remember password" cookie for a link.
	 *
	 * An HMAC of the link and its stored password hash: it proves the visitor
	 * entered the right password without containing it, and stops working when
	 * the password changes.
	 *
	 * @param int $link_id Link ID.
	 * @return string '' when the link has no password.
	 */
	public static function password_cookie_value( $link_id ) {
		$stored = self::get_stored_password( $link_id );
		if ( null === $stored || '' === $stored ) {
			return '';
		}
		return hash_hmac( 'sha256', (int) $link_id . '|' . $stored, wp_salt( 'auth' ) );
	}

	public static function check_is_visitor_allowed_in_password_protection( $link_id ) {
		global $wpdb;
		$query_string    = "SELECT `allow_contact` FROM {$wpdb->prefix}betterlinks_password where `link_id`=%d";
		$query_value_arr = array( $link_id );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$result          = $wpdb->get_var( $wpdb->prepare( $query_string, $query_value_arr ) );

		return $result === '1';
	}

	private function get_page_title_for_slug( $page_slug ) {
		$page = get_page_by_path( $page_slug, OBJECT );
		if ( $page ) {
			return true;
		}
		return false;
	}
	public function delete_custom_page( $page_slug ) {
		$page = get_page_by_path( $page_slug, OBJECT );
		if ( $page ) {
			wp_delete_post( $page->ID, true );
		}
		return;
	}
	/**
	 * Meta key marking the page BetterLinks Pro created for the password form.
	 */
	const PASSWORD_PAGE_META = '_betterlinks_password_page';

	/**
	 * Whether a page is the password-form page this plugin created.
	 *
	 * Pages created before the marker existed are recognised by the default
	 * title and empty content the plugin always used.
	 *
	 * @param int|\WP_Post $page Page.
	 * @return bool
	 */
	public static function is_plugin_password_page( $page ) {
		$page = get_post( $page );
		if ( ! $page || 'page' !== $page->post_type ) {
			return false;
		}
		if ( get_post_meta( $page->ID, self::PASSWORD_PAGE_META, true ) ) {
			return true;
		}
		$template = BETTERLINKS_PRO_ROOT_DIR_PATH . 'includes/Admin/views/password-protect-form.php';
		return get_post_meta( $page->ID, '_wp_page_template', true ) === $template
			&& 'Password Protected Form' === $page->post_title
			&& '' === trim( (string) $page->post_content );
	}

	public function add_password_protect_page( $form_key = 'password-protected-form' ) {
		// Sanitize form key to be a valid slug
		$form_key = sanitize_title( $form_key );
		if ( empty( $form_key ) ) {
			$form_key = 'password-protected-form';
		}
		$password_template = BETTERLINKS_PRO_ROOT_DIR_PATH . 'includes/Admin/views/password-protect-form.php';

		// Reuse a page at this slug only if this plugin created it. A settings
		// editor must not be able to re-template (and later delete) an existing
		// page such as "about" by typing its slug into the form key.
		$existing_page = get_page_by_path( $form_key );
		if ( $existing_page ) {
			if ( self::is_plugin_password_page( $existing_page ) ) {
				update_post_meta( $existing_page->ID, '_wp_page_template', $password_template );
				update_post_meta( $existing_page->ID, self::PASSWORD_PAGE_META, 1 );
				return $existing_page->ID;
			}
			// Leave the site's page alone; wp_insert_post() below picks a unique slug.
		}
		
		// Define the page title and content
		$page_title   = 'Password Protected Form';
		$page_content = '';
		$pageGuid     = site_url() . '/' . $form_key;

		// Create an array of page data
		$page_data = array(
			'post_title'   => $page_title,
			'post_content' => $page_content,
			'post_status'  => 'publish', // 'publish', 'draft', etc.
			'post_type'    => 'page',
			'post_name'    => $form_key, // Set the slug
			'guid'         => $pageGuid,
		);

		// Insert the page into the database
		$page_id = wp_insert_post( $page_data, false );

		if ( ! is_wp_error( $page_id ) && $page_id ) {
			update_post_meta( $page_id, '_wp_page_template', $password_template );
			update_post_meta( $page_id, self::PASSWORD_PAGE_META, 1 );
			return $page_id;
		}
		
		return false;
	}

	public function add_customized_meta_tag_page() {
		if ( $this->get_page_title_for_slug( 'customized-meta-tags' ) ) {
			return false;
		}
		// Define the page title and content
		$page_title   = 'Customized Meta Tags';
		$page_content = '';
		$pageGuid     = site_url() . '/customized-meta-tags';

		// Create an array of page data
		$page_data = array(
			'post_title'   => $page_title,
			'post_content' => $page_content,
			'post_status'  => 'publish', // 'publish', 'draft', etc.
			'post_type'    => 'page',
			'guid'         => $pageGuid,
		);

		// Insert the page into the database
		$page_id = wp_insert_post( $page_data, false );

		if ( ! is_wp_error( $page_id ) ) {
			$password_template = BETTERLINKS_PRO_ROOT_DIR_PATH . 'includes/Admin/views/customized-meta-tags.php';
			update_post_meta( $page_id, '_wp_page_template', $password_template );
		}
	}

	private static function get_transient_key( $key, $from, $to, $id = null ) {
		$transient_key = str_replace( '-', '_', $from ) . '_' . str_replace( '-', '_', $to );
		if ( $id ) {
			$transient_key .= '_' . $id;
		}
		
		// Vary with the excluded IP list (shared with the free plugin's report caches).
		$transient_key .= \BetterLinksPro\Analytics\IpExclusion::key_suffix();
		
		return $key . $transient_key;
	}
	/**
	 * @param string $from timestamp from
	 * @param string $to timestamp to
	 * @return array top 5 referer by clicks
	 */
	public static function get_top_referer( $from, $to ) {
		$transient_key = self::get_transient_key( 'btl_top_referer_', $from, $to );
		if ( $results = get_transient( $transient_key ) ) {
			return $results;
		}
		global $wpdb;
		
		// Get excluded IPs
		$options      = json_decode( get_option( BETTERLINKS_LINKS_OPTION_NAME ), true );
		$excluded_ips = isset( $options['excluded_ips'] ) && is_array( $options['excluded_ips'] ) ? $options['excluded_ips'] : array();
		$excluded_ips_condition = '';
		if ( ! empty( $excluded_ips ) ) {
			$placeholders = implode( ', ', array_fill( 0, count( $excluded_ips ), '%s' ) );
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
			$excluded_ips_condition = $wpdb->prepare( " and ip NOT IN ({$placeholders})", $excluded_ips );
		}
		
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$query = $wpdb->prepare(
			"select clicks.domain, count(clicks.domain) as clicks from 
        (select SUBSTRING_INDEX(SUBSTRING_INDEX(SUBSTRING_INDEX(referer, '/', 3), '/', -1), '.', -2) AS domain from {$wpdb->prefix}betterlinks_clicks where created_at between %s and %s and referer!=''{$excluded_ips_condition}) as clicks 
            group by  domain 
            order by clicks desc limit 5;",
			$from . ' 00:00:00',
			$to . ' 23:59:59'
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		// phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$results = $wpdb->get_results( $query, ARRAY_A );
		set_transient( $transient_key, $results, self::$transient_timeout );
		return $results;
	}

	/**
	 * @param string $from
	 * @param string $to
	 * @return array top device by clicks
	 */
	public static function get_device_click_stats( $from, $to ) {
		$transient_key = self::get_transient_key( 'btl_click_stats_', $from, $to );
		if ( $results = get_transient( $transient_key ) ) {
			return $results;
		}

		global $wpdb;
		
		// Get excluded IPs
		$options      = json_decode( get_option( BETTERLINKS_LINKS_OPTION_NAME ), true );
		$excluded_ips = isset( $options['excluded_ips'] ) && is_array( $options['excluded_ips'] ) ? $options['excluded_ips'] : array();
		$excluded_ips_condition = '';
		if ( ! empty( $excluded_ips ) ) {
			$placeholders = implode( ', ', array_fill( 0, count( $excluded_ips ), '%s' ) );
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
			$excluded_ips_condition = $wpdb->prepare( " and ip NOT IN ({$placeholders})", $excluded_ips );
		}
		
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$query = $wpdb->prepare(
			"select clicks.device, count(clicks.device) as clicks from 
        (select device from {$wpdb->prefix}betterlinks_clicks where created_at between %s and %s and device!=''{$excluded_ips_condition}) as clicks 
            group by device 
            order by clicks desc limit 5;",
			$from . ' 00:00:00',
			$to . ' 23:59:59'
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		// phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$results = $wpdb->get_results( $query, ARRAY_A );
		set_transient( $transient_key, $results, self::$transient_timeout );
		return $results;
	}

	/**
	 * @param string $from - timestate from
	 * @param string $to - timestate to
	 *
	 * @return array top os by clicks
	 */
	public static function get_top_os( $from, $to ) {
		$transient_key = self::get_transient_key( 'btl_top_os_', $from, $to );
		if ( $results = get_transient( $transient_key ) ) {
			return $results;
		}

		global $wpdb;
		
		// Get excluded IPs
		$options      = json_decode( get_option( BETTERLINKS_LINKS_OPTION_NAME ), true );
		$excluded_ips = isset( $options['excluded_ips'] ) && is_array( $options['excluded_ips'] ) ? $options['excluded_ips'] : array();
		$excluded_ips_condition = '';
		if ( ! empty( $excluded_ips ) ) {
			$placeholders = implode( ', ', array_fill( 0, count( $excluded_ips ), '%s' ) );
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
			$excluded_ips_condition = $wpdb->prepare( " and ip NOT IN ({$placeholders})", $excluded_ips );
		}
		
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$query = $wpdb->prepare(
			"select clicks.os,clicks.os_version, count(clicks.os) as clicks from 
        (select os,os_version from {$wpdb->prefix}betterlinks_clicks where created_at between %s and %s and os!=''{$excluded_ips_condition}) as clicks 
            group by os,os_version  
            order by clicks desc limit 5;",
			$from . ' 00:00:00',
			$to . ' 23:59:59'
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		// phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$results = $wpdb->get_results( $query, ARRAY_A );
		set_transient( $transient_key, $results, self::$transient_timeout );
		return $results;
	}


	public static function prepare_browser_data( $from, $to ) {

		$data = self::get_top_browser( $from, $to );

		$browsers = array(
			'chrome',
			'firefox',
			'safari',
			'edge',
			'opera',
			'internet explorer',
			'brave',
			'vivaldi',
			'tor browser',
			'microsoft edge',
			'uc browser',
			'yandex browser',
			'maxthon',
			'pale moon',
			'seamonkey',
			'midori',
			'avant browser',
			'epic privacy browser',
			'comodo dragon',
			'srware iron',
			'waterfox',
			'slimjet',
			'qutebrowser',
			'falkon',
			'gnome web (epiphany)',
			'otter browser',
			'konqueror',
			'lynx',
			'links',
			'dillo',
			'midori',
			'basilisk',
			'cyberfox',
			'dooble',
			'gnu icecat',
			'otter browser',
			'qutebrowser',
			'falkon',
			'luakit',
			'min',
			'surf',
			'vimb',
			'icab',
			'netscape navigator',
			'aol desktop',
			'sleipnir',
			'uc browser',
			'maxthon',
		);

		$browser_data = array();
		$others       = 0;
		foreach ( $data as $item ) {
			if ( in_array( strtolower( $item['browser'] ), $browsers ) ) {
				array_push( $browser_data, $item );
				continue;
			}
			$others += (int) $item['clicks'];
		}

		array_push(
			$browser_data,
			array(
				'browser'         => 'Others',
				'browser_version' => null,
				'clicks'          => $others,
			)
		);

		return $browser_data;
	}
	/**
	 * @param string $from - timestate from
	 * @param string $to - timestate to
	 *
	 * @return array top browser by clicks
	 */
	public static function get_top_browser( $from, $to ) {
		$transient_key = self::get_transient_key( 'btl_top_browser_', $from, $to );
		if ( $results = get_transient( $transient_key ) ) {
			return $results;
		}

		global $wpdb;
		
		// Get excluded IPs. Every dynamic value ($from, $to, and each excluded IP)
		// is bound through a single prepare() below. The previous build inlined
		// $from/$to straight into the string, so the analytics REST params reached
		// the SQL parser verbatim — an authenticated SQL injection.
		$options      = json_decode( get_option( BETTERLINKS_LINKS_OPTION_NAME ), true );
		$excluded_ips = isset( $options['excluded_ips'] ) && is_array( $options['excluded_ips'] ) ? $options['excluded_ips'] : array();

		$query_params           = array( $from . ' 00:00:00', $to . ' 23:59:00' );
		$excluded_ips_condition = '';
		if ( ! empty( $excluded_ips ) ) {
			$placeholders           = implode( ', ', array_fill( 0, count( $excluded_ips ), '%s' ) );
			$excluded_ips_condition = " and ip NOT IN ({$placeholders})";
			$query_params           = array_merge( $query_params, $excluded_ips );
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		$query = $wpdb->prepare(
			"select clicks.browser,clicks.browser_version, count(clicks.browser) as clicks from 
        (select SUBSTRING_INDEX(SUBSTRING_INDEX(browser, ' ', -2), '/', 1) as browser,browser_version from {$wpdb->prefix}betterlinks_clicks where created_at between %s and %s and browser!=''{$excluded_ips_condition}) as clicks 
            group by browser,browser_version  
            order by clicks desc limit 5;",
			$query_params
		);

		// phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$results = $wpdb->get_results( $query, ARRAY_A );
		set_transient( $transient_key, $results, self::$transient_timeout );
		return $results;
	}

	public static function get_top_medium( $clicks ) {
		$social_domain    = array();
		$search_domain    = array();
		$ecommerce_domain = array();
		$others           = 0;

		$social_media  = array( 'facebook', 'twitter', 'linkedin', 'instagram', 'tiktok', 'youtube', 'pinterest', 'reddit', 'tumblr' );
		$search_engine = array( 'google', 'bing', 'duckduckgo', 'yahoo', 'baidu', 'yandex', 'startpage', 'ecosia', 'ask', 'naver' );
		$ecommerce     = array( 'amazon', 'ebay', 'walmart', 'alibaba', 'aliexpress', 'rakuten', 'wildberries', 'ozon', 'flipcart' );

		for ( $i = 0; $i < count( $clicks ); $i++ ) {
			$element = $clicks[ $i ];
			$referer = $element['referer_strip'];
			$count   = intval( $element['referer_count'] );
			if ( empty( $referer ) ) {
				continue;
			}

			$url          = wp_parse_url( $referer );
			$host         = isset( $url['host'] ) ? $url['host'] : '';
			$hostSegments = explode( '.', $host );
			$host         = count( $hostSegments ) > 1 ? $hostSegments[ count( $hostSegments ) - 2 ] : $hostSegments[0];

			if ( empty( $host ) ) {
				continue;
			}

			if ( in_array( $host, $social_media ) ) {
				$social_domain[ $host ] = $count;
			} elseif ( in_array( $host, $search_engine ) ) {
				$search_domain[ $host ] = $count;
			} elseif ( in_array( $host, $ecommerce ) ) {
				$ecommerce_domain[ $host ] = $count;
			} else {
				$others += 1;
			}
		}
		$result = array(
			'social'    => $social_domain,
			'search'    => $search_domain,
			'ecommerce' => $ecommerce_domain,
			'others'    => $others,
		);
		return $result;
	}

	public static function get_all_referer( $from, $to ) {
		$transient_key = self::get_transient_key( 'btl_all_referer_', $from, $to );
		if ( $results = get_transient( $transient_key ) ) {
			return $results;
		}

		global $wpdb;
		
		// Get excluded IPs
		$options      = json_decode( get_option( BETTERLINKS_LINKS_OPTION_NAME ), true );
		$excluded_ips = isset( $options['excluded_ips'] ) && is_array( $options['excluded_ips'] ) ? $options['excluded_ips'] : array();
		$excluded_ips_condition = '';
		if ( ! empty( $excluded_ips ) ) {
			$placeholders = implode( ', ', array_fill( 0, count( $excluded_ips ), '%s' ) );
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
			$excluded_ips_condition = $wpdb->prepare( " and ip NOT IN ({$placeholders})", $excluded_ips );
		}

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$query = $wpdb->prepare(
			"SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(referer, '/', 3), '//', -2) as referer_strip, count(*) as referer_count FROM {$wpdb->prefix}betterlinks_clicks WHERE referer!='' and created_at between %s and %s{$excluded_ips_condition} group by referer_strip",
			$from . ' 00:00:00',
			$to . ' 23:59:59'
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		// phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$results = $wpdb->get_results( $query, ARRAY_A );
		set_transient( $transient_key, $results, self::$transient_timeout );
		return $results;
	}

	public static function get_meta_tag_by_link_id( $link_id ) {
		global $wpdb;
		$query   = "SELECT `meta_title`, `meta_desc`,`meta_image`, `status` from {$wpdb->prefix}betterlinks_meta_tags where `link_id`=%d";
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$results = $wpdb->get_results( $wpdb->prepare( $query, $link_id ) );

		return $results;
	}

	public static function get_meta_tags_by_short_url( $short_url ) {
		global $wpdb;
		// INNER JOIN: only links that have their own, enabled meta tags. The old
		// RIGHT JOIN returned the target URL of any link, protected or not.
		$query   = "SELECT meta.*, link.link_status FROM {$wpdb->prefix}betterlinks_meta_tags AS meta
			INNER JOIN `{$wpdb->prefix}betterlinks` AS link ON link.id = meta.link_id
			WHERE link.short_url=%s AND meta.status=1 LIMIT 1";
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$results = $wpdb->get_row( $wpdb->prepare( $query, $short_url ), ARRAY_A );
		return $results;
	}

	public static function check_meta_tag_enable_by_link_id( $link_id ) {
		global $wpdb;
		$query   = "SELECT `status` FROM {$wpdb->prefix}betterlinks_meta_tags WHERE link_id=%d";
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$results = $wpdb->get_var( $wpdb->prepare( $query, $link_id ) );
		return $results;
	}

	/**
	 * Returns individual analytics graph data within a time limit
	 *
	 * @param int|string $id Clicks id.
	 * @param string     $from The start time.
	 * @param string     $to The end time.
	 *
	 * @return array Array of individual analytics graph clicks.
	 */
	public static function get_individual_graph_data( $id, $from, $to ) {
		$transient_key = self::get_transient_key( 'btl_individual_graph_data_', $from, $to, $id );
		if ( $results = get_transient( $transient_key ) ) {
			return $results;
		}
		global $wpdb;
		
		// Get excluded IPs. link_id, $from, $to and each excluded IP are all bound
		// via prepare(). Previously link_id={$id} and the dates were interpolated
		// raw, so a caller-supplied id such as "0 OR 1=1" (id only passes through
		// sanitize_text_field upstream, which does not stop it) rewrote the WHERE
		// clause — an authenticated SQL injection.
		$options      = json_decode( get_option( BETTERLINKS_LINKS_OPTION_NAME ), true );
		$excluded_ips = isset( $options['excluded_ips'] ) && is_array( $options['excluded_ips'] ) ? $options['excluded_ips'] : array();

		$query_params           = array( $id, $from . ' 00:00:00', $to . ' 23:59:59' );
		$excluded_ips_condition = '';
		if ( ! empty( $excluded_ips ) ) {
			$placeholders           = implode( ', ', array_fill( 0, count( $excluded_ips ), '%s' ) );
			$excluded_ips_condition = " AND ip NOT IN ({$placeholders})";
			$query_params           = array_merge( $query_params, $excluded_ips );
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		$query         = $wpdb->prepare(
			"SELECT count(ip) as uniq_count, T1.c_date from ( SELECT ip, DATE( created_at ) as c_date FROM {$wpdb->prefix}betterlinks_clicks 
        WHERE link_id=%d and created_at  BETWEEN %s AND %s{$excluded_ips_condition} GROUP BY `ip`, `c_date` ) as T1 GROUP BY T1.c_date ORDER BY T1.c_date DESC",
			$query_params
		);
		// phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$unique_clicks = $wpdb->get_results( $query, ARRAY_A );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		$query        = $wpdb->prepare(
			"SELECT count(id) as click_count, DATE(created_at) as c_date FROM {$wpdb->prefix}betterlinks_clicks 
        WHERE link_id=%d and created_at  BETWEEN %s AND %s{$excluded_ips_condition} GROUP BY c_date ORDER BY c_date DESC",
			$query_params
		);
		// phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$total_clicks = $wpdb->get_results( $query, ARRAY_A );

		$results = array(
			'total_count'  => $total_clicks,
			'unique_count' => $unique_clicks,
		);
		set_transient( $transient_key, $results, self::$transient_timeout );
		return $results;
	}

	public static function update_custom_script_data( $link_id, $arg ) {
		// The per-link custom tracking script is raw JavaScript echoed verbatim on
		// the cloaked redirect page, so persisting it is an unfiltered_html action.
		// A delegated writelinks/editlinks role (Subscriber) does not have that
		// capability; without this gate such a role could store stored XSS that
		// runs for every visitor. Admins/editors with unfiltered_html are
		// unaffected. When the caller lacks the capability, leave the stored
		// script untouched (ignore the incoming script field).
		if ( ! current_user_can( 'unfiltered_html' ) ) {
			return;
		}
		$custom_tracking_scripts = \BetterLinks\Helper::get_link_meta( $link_id, 'btl_custom_tracking_scripts' );
		$is_enable_scripts       = isset( $arg['enable_custom_scripts'] ) ? $arg['enable_custom_scripts'] : false;

		if ( ! empty( $custom_tracking_scripts ) ) {
			$custom_tracking_scripts = unserialize( $custom_tracking_scripts, array( 'allowed_classes' => false ) );
		}
		$custom_script = serialize(
			array(
				'enable' => $is_enable_scripts,
				'script' => isset( $arg['custom_tracking_scripts'] ) ? $arg['custom_tracking_scripts'] : '',
			)
		);
		if ( $is_enable_scripts ) {
			if ( empty( $custom_tracking_scripts ) ) {
				\BetterLinks\Helper::add_link_meta( $link_id, 'btl_custom_tracking_scripts', $custom_script );
			} else {
				\BetterLinks\Helper::update_link_meta( $link_id, 'btl_custom_tracking_scripts', $custom_script );
			}
		} elseif ( isset( $custom_tracking_scripts['enable'] ) && $custom_tracking_scripts['enable'] !== $is_enable_scripts ) {
			\BetterLinks\Helper::update_link_meta( $link_id, 'btl_custom_tracking_scripts', $custom_script );
		}
	}

	public static function parse_url( $url ) {
		if ( empty( $url ) ) {
			return false;
		}
		if ( is_array( $url ) ) {
			return wp_parse_url( $url[0] );
		}
		return wp_parse_url( $url );
	}

	public static function get_url_component( $parsed_url, $component = 'host' ) {
		if ( ! is_array( $parsed_url ) ) {
			return false;
		}
		return ! empty( $parsed_url[ $component ] ) ? $parsed_url[ $component ] : false;
	}

	/**
	 * @param array|int|string $data Either a full link row (array) or a link ID.
	 */
	public static function split_test_enabled( $data ) {
		$extra  = null;
		$id     = null;
		$helper = new \BetterLinks\Helper();
		// `is_scalar`, not `'string' === gettype()`: callers that pass an ID
		// through `absint()` hand over an INTEGER, which used to fall into the
		// array branch below, evaluate `$data['ID']` on an int, and return false
		// for every split test. Arrays still take the else branch.
		if ( is_scalar( $data ) ) {
			$id               = $data;
			$dynamic_redirect = $helper::get_link_data_by_id( $id, 'dynamic_redirect' );

			$split_test_data_meta = $helper::get_link_meta( $id, 'split_test_data' );

			if ( ! empty( $split_test_data_meta ) ) {
				$split_test_data_meta              = (array) $split_test_data_meta;
				$split_test_data_meta['completed'] = true;
				return $split_test_data_meta;
			}

			if ( is_string( $dynamic_redirect ) ) {
				$dynamic_redirect = json_decode( $dynamic_redirect );
			}
			$extra = isset( $dynamic_redirect->extra ) ? (array) $dynamic_redirect->extra : null;
		} else {
			$id                   = $data['ID'];
			$split_test_data_meta = $helper::get_link_meta( $id, 'split_test_data' );
			if ( ! empty( $split_test_data_meta ) ) {
				$split_test_data_meta              = (array) $split_test_data_meta;
				$split_test_data_meta['completed'] = true;
				return $split_test_data_meta;
			}
			$extra = isset( $data['dynamic_redirect'], $data['dynamic_redirect']['extra'] ) ? $data['dynamic_redirect']['extra'] : null;
		}
		if ( empty( $extra ) ) {
			return false;
		}

		$is_enable = isset( $extra['split_test'] ) ? '1' === $extra['split_test'] : false;

		if ( ! $is_enable ) {
			return false;
		}

		$is_expire_enable = isset( $extra['expire_split'] ) ? '1' === $extra['expire_split'] : false;

		if ( $is_enable && ! $is_expire_enable ) {
			return array( 'result' => true );
		}

		$expire_metrics      = isset( $extra['expire_split_after'] ) ? $extra['expire_split_after'] : 'clicks';
		$expire_split_clicks = isset( $extra['expire_split_clicks'] ) ? (int) $extra['expire_split_clicks'] : 0;
		$clicks_count        = null;

		if ( class_exists( '\BetterLinksPro\Helper' ) ) {
			$pro_helper = new \BetterLinksPro\Helper();

			if ( 'clicks' === $expire_metrics ) {
				$clicks_count = $pro_helper::get_individual_clicks_count( $id );
			} elseif ( 'unique_clicks' === $expire_metrics ) {
				$clicks_count = $pro_helper::get_individual_unique_clicks_count( $id );
			}
		}

		$result = $clicks_count < $expire_split_clicks;
		return array(
			'result'              => $result,
			'expire_metrics'      => $expire_metrics,
			'expire_split_clicks' => $expire_split_clicks,
			'clicks_count'        => $clicks_count,
			'completed'           => ! ( $clicks_count < ( $expire_split_clicks - 1 ) ),
		);
	}

	/**
	 * @param boolean $remember_cookies - remember cookies setting enabled or not
	 * @param integer $id - id of the short link
	 *
	 * @return boolean - returns true if password is okay, and cookie is valid, otherwise returns false
	 */
	public function passsword_cookie_enabled( $remember_cookies, $id ) {
		$cookie_name = "betterlinks_pass_protect_{$id}";
		if ( ! empty( $remember_cookies ) && isset( $_COOKIE[ $cookie_name ] ) ) {
			$cookie   = sanitize_text_field( wp_unslash( $_COOKIE[ $cookie_name ] ) );
			$expected = self::password_cookie_value( $id );
			if ( '' !== $expected && hash_equals( $expected, $cookie ) ) {
				return true;
			}
			// Cookies set by older versions held the password itself.
			return self::check_password( $cookie, $id );
		}
		return false;
	}

	/**
	 * @param string $request_uri - REQUEST_URI.
	 *
	 * @return boolean - returns true if the request uri is self site url
	 */
	protected function is_self_url( $request_uri ) {
		// Check if the referer url is a password protection form page
		$password_protection_status = \BetterLinksPro\Link::get_password_protection_status();
		$form_key = isset( $password_protection_status['form_key'] ) ? sanitize_text_field( $password_protection_status['form_key'] ) : 'password-protected-form';
		$form_key = empty( $form_key ) ? 'password-protected-form' : $form_key;
		
		if ( str_contains( $request_uri, $form_key . '?short_url' ) ) {
			return false;
		}
		$is_self_url = url_to_postid( $request_uri );
		return ! empty( $is_self_url );
	}

	/**
	 * @param string $request_uri REQUEST_URI.
	 *
	 * @return string Short URL
	 */
	public function get_protected_self_url_short_link( $request_uri ) {
		global $wpdb;
		$is_self_url = $this->is_self_url( $request_uri );
		if ( empty( $is_self_url ) ) {
			return false;
		}

		$sql = $wpdb->prepare(
			"SELECT l.short_url FROM {$wpdb->prefix}betterlinks AS l
                LEFT JOIN {$wpdb->prefix}betterlinks_password as p
                    on l.ID=p.link_id
                where l.target_url=%s and p.status='1'",
			$request_uri
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$short_url = $wpdb->get_var( $sql );
		return $short_url;
	}

	public function referer_short_url( $referer ) {
		if ( empty( $referer ) ) {
			return false;
		}
		$password_param = explode( '?short_url=', $referer );
		if ( count( $password_param ) > 1 ) {
			return $password_param[1];
		}
		return false;
	}
	
	public static function get_all_post_types() {
		$public_post_types = get_post_types([
			'public'   => true,
		]);
		$builtin_post_types = get_post_types([
			'_builtin'   => false,
		]);
	
		return array_merge(  $public_post_types,$builtin_post_types );
	}
	private function sanitize_date( $date ){
		if( empty( $date ) ){
			return false;
		}
		$date = sanitize_text_field( $date );
		return strtotime( $date );
	}

	/**
	 * Check if bulk link generator feature is available
	 * This function is used to verify Pro version compatibility for the Auto Post Link Generator feature.
	 * The free plugin checks if this function exists to ensure the Pro plugin is updated.
	 * 
	 * @since 2.5.0
	 * @return bool Always returns true when this function exists
	 */
	public static function is_bulk_link_generator_enabled() {
		return true;
	}

	/**
	 * Check if country tracking feature is available
	 * This function is used to verify Pro version compatibility for the Country Tracking feature.
	 * The free plugin checks if this function exists to ensure the Pro plugin is updated.
	 * 
	 * @since 2.5.0
	 * @return bool Always returns true when this function exists
	 */
	public static function is_country_tracking_enabled() {
		return true;
	}

	/**
	 * Get top referer for individual link
	 * @param int $link_id - link ID
	 * @param string $from - timestamp from
	 * @param string $to - timestamp to
	 * @return array top 5 referer by clicks for individual link
	 */
	public static function get_individual_top_referer( $link_id, $from, $to ) {
		$transient_key = self::get_transient_key( 'btl_individual_top_referer_' . $link_id . '_', $from, $to );
		if ( $results = get_transient( $transient_key ) ) {
			return $results;
		}
		global $wpdb;
		
		// Get excluded IPs
		$options      = json_decode( get_option( BETTERLINKS_LINKS_OPTION_NAME ), true );
		$excluded_ips = isset( $options['excluded_ips'] ) && is_array( $options['excluded_ips'] ) ? $options['excluded_ips'] : array();
		$excluded_ips_condition = '';
		if ( ! empty( $excluded_ips ) ) {
			$placeholders = implode( ', ', array_fill( 0, count( $excluded_ips ), '%s' ) );
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
			$excluded_ips_condition = $wpdb->prepare( " and ip NOT IN ({$placeholders})", $excluded_ips );
		}
		
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$query = $wpdb->prepare(
			"select clicks.domain, count(clicks.domain) as clicks from 
        (select SUBSTRING_INDEX(SUBSTRING_INDEX(SUBSTRING_INDEX(referer, '/', 3), '/', -1), '.', -2) AS domain from {$wpdb->prefix}betterlinks_clicks where link_id=%d and created_at between %s and %s and referer!=''{$excluded_ips_condition}) as clicks 
            group by domain 
            order by clicks desc limit 5;",
			$link_id,
			$from . ' 00:00:00',
			$to . ' 23:59:59'
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		// phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$results = $wpdb->get_results( $query, ARRAY_A );
		set_transient( $transient_key, $results, self::$transient_timeout );
		return $results;
	}

	/**
	 * Get device click stats for individual link
	 * @param int $link_id - link ID
	 * @param string $from - timestamp from
	 * @param string $to - timestamp to
	 * @return array top device by clicks for individual link
	 */
	public static function get_individual_device_stats( $link_id, $from, $to ) {
		$transient_key = self::get_transient_key( 'btl_individual_device_stats_' . $link_id . '_', $from, $to );
		if ( $results = get_transient( $transient_key ) ) {
			return $results;
		}

		global $wpdb;
		
		// Get excluded IPs
		$options      = json_decode( get_option( BETTERLINKS_LINKS_OPTION_NAME ), true );
		$excluded_ips = isset( $options['excluded_ips'] ) && is_array( $options['excluded_ips'] ) ? $options['excluded_ips'] : array();
		$excluded_ips_condition = '';
		if ( ! empty( $excluded_ips ) ) {
			$placeholders = implode( ', ', array_fill( 0, count( $excluded_ips ), '%s' ) );
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
			$excluded_ips_condition = $wpdb->prepare( " and ip NOT IN ({$placeholders})", $excluded_ips );
		}
		
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$query = $wpdb->prepare(
			"select clicks.device, count(clicks.device) as clicks from 
        (select device from {$wpdb->prefix}betterlinks_clicks where link_id=%d and created_at between %s and %s and device!=''{$excluded_ips_condition}) as clicks 
            group by device 
            order by clicks desc limit 5;",
			$link_id,
			$from . ' 00:00:00',
			$to . ' 23:59:59'
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		// phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$results = $wpdb->get_results( $query, ARRAY_A );
		set_transient( $transient_key, $results, self::$transient_timeout );
		return $results;
	}

	/**
	 * Get top OS for individual link
	 * @param int $link_id - link ID
	 * @param string $from - timestamp from
	 * @param string $to - timestamp to
	 * @return array top os by clicks for individual link
	 */
	public static function get_individual_top_os( $link_id, $from, $to ) {
		$transient_key = self::get_transient_key( 'btl_individual_top_os_' . $link_id . '_', $from, $to );
		if ( $results = get_transient( $transient_key ) ) {
			return $results;
		}

		global $wpdb;
		
		// Get excluded IPs
		$options      = json_decode( get_option( BETTERLINKS_LINKS_OPTION_NAME ), true );
		$excluded_ips = isset( $options['excluded_ips'] ) && is_array( $options['excluded_ips'] ) ? $options['excluded_ips'] : array();
		$excluded_ips_condition = '';
		if ( ! empty( $excluded_ips ) ) {
			$placeholders = implode( ', ', array_fill( 0, count( $excluded_ips ), '%s' ) );
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
			$excluded_ips_condition = $wpdb->prepare( " and ip NOT IN ({$placeholders})", $excluded_ips );
		}
		
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$query = $wpdb->prepare(
			"select clicks.os,clicks.os_version, count(clicks.os) as clicks from 
        (select os,os_version from {$wpdb->prefix}betterlinks_clicks where link_id=%d and created_at between %s and %s and os!=''{$excluded_ips_condition}) as clicks 
            group by os,os_version  
            order by clicks desc limit 5;",
			$link_id,
			$from . ' 00:00:00',
			$to . ' 23:59:59'
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		// phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$results = $wpdb->get_results( $query, ARRAY_A );
		set_transient( $transient_key, $results, self::$transient_timeout );
		return $results;
	}

	/**
	 * Get browser data for individual link
	 * @param int $link_id - link ID
	 * @param string $from - timestamp from
	 * @param string $to - timestamp to
	 * @return array browser data for individual link
	 */
	public static function get_individual_browser_data( $link_id, $from, $to ) {
		$data = self::get_individual_top_browser( $link_id, $from, $to );

		$browsers = array(
			'chrome',
			'firefox',
			'safari',
			'edge',
			'opera',
			'internet explorer',
			'brave',
			'vivaldi',
			'tor browser',
			'microsoft edge',
			'uc browser',
			'yandex browser',
			'maxthon',
			'pale moon',
			'seamonkey',
			'midori',
			'avant browser',
			'epic privacy browser',
			'comodo dragon',
			'srware iron',
			'waterfox',
			'slimjet',
			'qutebrowser',
			'falkon',
			'gnome web (epiphany)',
			'otter browser',
			'konqueror',
			'lynx',
			'links',
		);

		$final_data = array();

		foreach ( $data as $row ) {
			$browser = strtolower( $row['browser'] );
			$matched = false;

			foreach ( $browsers as $known_browser ) {
				if ( strpos( $browser, $known_browser ) !== false ) {
					$matched                 = true;
					$final_data[ $browser ]  = isset( $final_data[ $browser ] ) ? $final_data[ $browser ] : array();
					$final_data[ $browser ]  = array_merge(
						$final_data[ $browser ],
						array(
							array(
								'version' => $row['browser_version'],
								'clicks'  => $row['clicks'],
							),
						)
					);
					break;
				}
			}

			if ( ! $matched ) {
				$final_data['others'] = isset( $final_data['others'] ) ? $final_data['others'] : array();
				$final_data['others'] = array_merge(
					$final_data['others'],
					array(
						array(
							'version' => $row['browser_version'],
							'clicks'  => $row['clicks'],
						),
					)
				);
			}
		}

		return $final_data;
	}

	/**
	 * Get top browser for individual link
	 * @param int $link_id - link ID
	 * @param string $from - timestamp from
	 * @param string $to - timestamp to
	 * @return array top browser by clicks for individual link
	 */
	public static function get_individual_top_browser( $link_id, $from, $to ) {
		$transient_key = self::get_transient_key( 'btl_individual_top_browser_' . $link_id . '_', $from, $to );
		if ( $results = get_transient( $transient_key ) ) {
			return $results;
		}

		global $wpdb;
		
		// Get excluded IPs
		$options      = json_decode( get_option( BETTERLINKS_LINKS_OPTION_NAME ), true );
		$excluded_ips = isset( $options['excluded_ips'] ) && is_array( $options['excluded_ips'] ) ? $options['excluded_ips'] : array();
		$excluded_ips_condition = '';
		if ( ! empty( $excluded_ips ) ) {
			$placeholders = implode( ', ', array_fill( 0, count( $excluded_ips ), '%s' ) );
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
			$excluded_ips_condition = $wpdb->prepare( " and ip NOT IN ({$placeholders})", $excluded_ips );
		}
		
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$query = $wpdb->prepare(
			"select clicks.browser,clicks.browser_version, count(clicks.browser) as clicks from 
        (select browser,browser_version from {$wpdb->prefix}betterlinks_clicks where link_id=%d and created_at between %s and %s and browser!=''{$excluded_ips_condition}) as clicks 
            group by browser,browser_version  
            order by clicks desc;",
			$link_id,
			$from . ' 00:00:00',
			$to . ' 23:59:59'
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		// phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$results = $wpdb->get_results( $query, ARRAY_A );
		set_transient( $transient_key, $results, self::$transient_timeout );
		return $results;
	}

	/**
	 * Get all referer for individual link
	 * @param int $link_id - link ID
	 * @param string $from - timestamp from
	 * @param string $to - timestamp to
	 * @return array all referer for individual link
	 */
	public static function get_individual_referer( $link_id, $from, $to ) {
		$transient_key = self::get_transient_key( 'btl_individual_referer_' . $link_id . '_', $from, $to );
		if ( $results = get_transient( $transient_key ) ) {
			return $results;
		}

		global $wpdb;
		
		// Get excluded IPs
		$options      = json_decode( get_option( BETTERLINKS_LINKS_OPTION_NAME ), true );
		$excluded_ips = isset( $options['excluded_ips'] ) && is_array( $options['excluded_ips'] ) ? $options['excluded_ips'] : array();
		$excluded_ips_condition = '';
		if ( ! empty( $excluded_ips ) ) {
			$placeholders = implode( ', ', array_fill( 0, count( $excluded_ips ), '%s' ) );
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
			$excluded_ips_condition = $wpdb->prepare( " and ip NOT IN ({$placeholders})", $excluded_ips );
		}

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$query = $wpdb->prepare(
			"SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(referer, '/', 3), '//', -2) as referer_strip, count(*) as referer_count FROM {$wpdb->prefix}betterlinks_clicks WHERE link_id=%d and referer!='' and created_at between %s and %s{$excluded_ips_condition} group by referer_strip",
			$link_id,
			$from . ' 00:00:00',
			$to . ' 23:59:59'
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		// phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$results = $wpdb->get_results( $query, ARRAY_A );
		set_transient( $transient_key, $results, self::$transient_timeout );
		return $results;
	}
}
