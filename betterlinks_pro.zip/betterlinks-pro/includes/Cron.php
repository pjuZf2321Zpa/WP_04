<?php
namespace BetterLinksPro;
if ( ! defined( 'ABSPATH' ) ) { exit; }

use BetterLinks\Helper;

class Cron
{
    public static function init()
    {
        $self = new self();
        add_filter('cron_schedules', array($self, 'cron_time_intervals'));
        add_action('betterlinkspro/expire_link_status_handler', array($self, 'expire_link_status_handler'));
        // Accepted-args bumped from 5 → 6 (GA) and 4 → 5 (Pixel) for $ga_session_data.
        // WordPress truncates extra args silently when this number is wrong.
        add_action('betterlinkspro/send_google_analytics_data', array($self, 'send_google_analytics_data'), 10, 6);
        add_action('betterlinkspro/send_pixel_analytics_data', array($self, 'send_pixel_analytics_data'), 10, 5);
        add_action('betterlinkspro/broken_link_checker', array($self, 'broken_link_checker'));
        add_action('betterlinkspro/force_fullsite_scan_cron', array($self, 'force_fullsite_scan_handler'));
        add_action('betterlinks/scheduled_link_publish', [$self, 'scheduled_link_publish'], 10, 1);
        
        // Full Site Scanner Report initialization
        Admin\FullSiteScannerReport::init();
        
        $self->dispatch_brokenlink_checker();
    }

    public function cron_time_intervals($schedules)
    {
        $schedules['monthly'] = array(
            'interval' => MONTH_IN_SECONDS,
            'display' => 'Once Monthly'
        );
        $schedules['yearly'] = array(
            'interval' => YEAR_IN_SECONDS,
            'display' => 'Once Yearly'
        );
        return $schedules;
    }

    public function dispatch_brokenlink_checker()
    {
        if (! wp_next_scheduled('betterlinkspro/broken_link_checker')) {
            $settings_broken = json_decode(get_option(BETTERLINKS_PRO_BROKEN_LINK_OPTION_NAME, '{}'), true);
            if (isset($settings_broken['enable_scan']) && $settings_broken['enable_scan'] == true) {
                $scan_mode  = isset($settings_broken['scan_mode']) ? $settings_broken['scan_mode'] : 'weekly';
                $scan_day   = isset($settings_broken['scan_day']) ? $settings_broken['scan_day'] : 'sunday';
                $scan_time  = isset($settings_broken['scan_time']) ? \BetterLinksPro\Helper::normalize_scan_time($settings_broken['scan_time']) : '12:00';
                $scan_month = isset($settings_broken['scan_month']) ? $settings_broken['scan_month'] : null;
                $scan_year  = isset($settings_broken['scan_year']) ? $settings_broken['scan_year'] : null;
                $timestamp = \BetterLinksPro\Helper::calculate_schedule_timestamp(
                    $scan_mode,
                    $scan_day,
                    $scan_time,
                    $scan_month,
                    $scan_year
                );
                wp_schedule_event($timestamp, $scan_mode, 'betterlinkspro/broken_link_checker');
            }
        }
    }

    public function expire_link_status_handler($data)
    {
        // for clicks
        if ($data['expire']['type'] == 'clicks') {
            // clear clicks json data
            $clicks = new \BetterLinks\Cron();
            $clicks->analytics();
            $analytic = json_decode(get_option('betterlinks_analytics_data'), true);
            if (isset($analytic[$data['ID']])) {
                $analytic = $analytic[$data['ID']];
                if (intval($analytic['link_count']) >= intval($data['expire']['clicks'])) {
                    $this->change_links_status_by_id($data['ID'], 'expired');
                    Helper::clear_query_cache(); // clear previous links cache
                    Helper::create_links_cache(); // creats nre links cache
                    if (BETTERLINKS_EXISTS_LINKS_JSON) {
                        // change status
                        $data['link_status'] = 'expired';
                        Helper::update_json_into_file(trailingslashit(BETTERLINKS_UPLOAD_DIR_PATH) . 'links.json', $data, $data['short_url']);
                    }
                }
            }
        } else {
            // for date
            if (!empty($data['expire']['date'])) {
                $timezone = wp_timezone_string();
                $specificTime = new \DateTime($data['expire']['date'], new \DateTimeZone($timezone));
                $now = new \DateTime("now", new \DateTimeZone($timezone));
                if ($specificTime->getTimestamp() < $now->getTimestamp()) {
                    $this->change_links_status_by_id($data['ID'], 'expired');
                    Helper::clear_query_cache();
                    Helper::create_links_cache();
                    if (BETTERLINKS_EXISTS_LINKS_JSON) {
                        $data['link_status'] = 'expired';
                        Helper::update_json_into_file(trailingslashit(BETTERLINKS_UPLOAD_DIR_PATH) . 'links.json', $data, $data['short_url']);
                    }
                }
            }
        }
    }
    /**
     * Cron handler for the deferred GA send.
     *
     * $ga_session_data is optional for backward compatibility with events
     * scheduled before this upgrade — old events fire with 5 args and still work,
     * they just lose the session_id / event_id enrichment for that one tick.
     */
    public function send_google_analytics_data($data, $page_url, $ga_tracking_code, $ga4_api_secret, $visitor, $ga_session_data = array())
    {
        if ($ga_tracking_code) {
            // Issue #1: send the human-readable link_title (Hebrew, etc.) as page_title,
            // not the ASCII slug.
            //
            // Catch: in JSON-cache mode (the default), $data is shaped by free's
            // Helper::json_link_formatter() which OMITS link_title to keep links.json
            // small on the redirect hot path. So $data['link_title'] is empty here.
            // The cron tick is deferred so a single SELECT by ID is acceptable.
            $title = ! empty( $data['link_title'] ) ? $data['link_title'] : '';
            if ( '' === $title && ! empty( $data['ID'] ) ) {
                $row = \BetterLinks\Helper::get_link_by_ID( $data['ID'] );
                if ( ! empty( $row ) ) {
                    $row = is_array( $row ) ? current( $row ) : $row;
                    if ( is_array( $row ) && ! empty( $row['link_title'] ) ) {
                        $title = $row['link_title'];
                    } elseif ( is_object( $row ) && ! empty( $row->link_title ) ) {
                        $title = $row->link_title;
                    }
                }
            }
            // Final defensive fallback: if even the DB lookup yielded nothing, send slug
            // so we at least populate page_title with something.
            if ( '' === $title ) {
                $title = ! empty( $data['link_slug'] ) ? $data['link_slug'] : '';
            }
            $slug = ! empty( $data['link_slug'] ) ? $data['link_slug'] : '';

            $analytic = new Analytics\GoogleAnalytics($visitor, $ga_session_data);
            $analytic->ga_send_pageview($ga_tracking_code, $ga4_api_secret, get_site_url(), $page_url, $title, $slug);
        }
    }
    public function send_pixel_analytics_data($data, $server, $pixel_id, $access_token, $ga_session_data = array())
    {
        $event_id = ! empty( $ga_session_data['event_id'] ) ? $ga_session_data['event_id'] : '';
        $pixelAnalytic = new Analytics\PixelAnalytics();
        $pixelAnalytic->pixel_send_pageview($data, $server, $pixel_id, $access_token, $event_id);
    }
    public function change_links_status_by_id($ID, $status)
    {
        $retults = \BetterLinks\Helper::insert_link(['ID' => $ID, 'link_status' => $status], true);
        return $retults;
    }
    public function broken_link_checker()
    {
        if ($this->should_skip_scan_today()) {
            return;
        }
        $brokenlink = Admin\BrokenLink::getInstance();
        if (!$brokenlink->doing_dispatch()) {
            global $wpdb;
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
            $betterlinks = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}betterlinks", ARRAY_A);
            delete_option('betterlinkspro_broken_links_logs');
            $brokenlink->init();
            foreach ($betterlinks as $link) {
                $brokenlink->push_to_queue($link);
            }
            $brokenlink->push_to_queue('send_report_to_email');
            $brokenlink->save();
            // Keep the report card's "Last run" in step with scheduled scans too.
            update_option(\BetterLinksPro\Admin\Ajax::BROKENLINK_LAST_RUN_OPTION, time(), false);
        }
    }

    private function should_skip_scan_today()
    {
        $settings = json_decode(get_option(BETTERLINKS_PRO_BROKEN_LINK_OPTION_NAME, '{}'), true);
        if (empty($settings) || !is_array($settings)) {
            return false;
        }
        $mode     = isset($settings['scan_mode']) ? $settings['scan_mode'] : 'weekly';
        $scan_day = isset($settings['scan_day']) ? (string) $settings['scan_day'] : '';

        if ('daily' === $mode && '' !== $scan_day) {
            $allowed = array_filter(array_map('trim', explode(',', strtolower($scan_day))));
            if (!empty($allowed) && !in_array(strtolower(gmdate('l')), $allowed, true)) {
                return true;
            }
        }

        if ('monthly' === $mode) {
            $day_of_month = (int) $scan_day;
            if ($day_of_month >= 1 && $day_of_month <= 31) {
                $today = (int) gmdate('j');
                if ($today !== $day_of_month) {
                    $days_in_month = (int) gmdate('t');
                    if (!($day_of_month > $days_in_month && $today === $days_in_month)) {
                        return true;
                    }
                }
            }
        }

        return false;
    }
    public function scheduled_link_publish($link_id)
    {
        delete_transient(BETTERLINKS_CACHE_LINKS_NAME);
        $retults = \BetterLinks\Helper::insert_link(['ID' => $link_id, 'link_status' => 'publish'], true);
        $Cron = new \BetterLinks\Cron();
        $Cron->write_json_links();
        return $retults;
    }

    /**
     * Force Fullsite Scan Handler (CRON Job)
     * Processes posts in small batches to handle large sites.
     * Each invocation scans a batch of posts, saves progress, and schedules
     * the next batch immediately. This avoids PHP timeout issues.
     */
    public function force_fullsite_scan_handler()
    {
        // Prevent concurrent execution
        $lock = get_transient( 'betterlinkspro_force_scan_lock' );
        if ( $lock ) {
            return;
        }
        // Short lock — just enough to prevent overlap within a single batch
        set_transient( 'betterlinkspro_force_scan_lock', true, 5 * MINUTE_IN_SECONDS );

        try {
            $batch_size = apply_filters( 'betterlinkspro/force_scan_batch_size', 20 );

            // Get scan progress state
            $progress = get_option( 'betterlinkspro_force_scan_progress', array() );
            if ( empty( $progress ) || ! is_array( $progress ) ) {
                // No scan initialized — nothing to do
                delete_transient( 'betterlinkspro_force_scan_lock' );
                return;
            }

            $last_post_id = isset( $progress['last_post_id'] ) ? intval( $progress['last_post_id'] ) : 0;
            $total_posts  = isset( $progress['total_posts'] ) ? intval( $progress['total_posts'] ) : 0;
            $scanned      = isset( $progress['scanned'] ) ? intval( $progress['scanned'] ) : 0;
            $status       = isset( $progress['status'] ) ? $progress['status'] : 'running';

            if ( 'complete' === $status ) {
                delete_transient( 'betterlinkspro_force_scan_lock' );
                return;
            }

            // Get allowed post types from settings
            $settings = json_decode( get_option( 'betterlinkspro_fullsite_broken_link_settings', '{}' ), true );
            $allowed_post_types = isset( $settings['post_types'] ) ? $settings['post_types'] : array( 'post', 'page' );

            if ( is_string( $allowed_post_types ) ) {
                $allowed_post_types = array_map( 'trim', explode( ',', $allowed_post_types ) );
            }

            // Fetch the next batch of posts (paginated by ID cursor)
            $args = array(
                'post_type'      => $allowed_post_types,
                'posts_per_page' => $batch_size,
                'post_status'    => array( 'publish', 'pending', 'draft', 'future', 'private', 'inherit' ),
                'orderby'        => 'ID',
                'order'          => 'ASC',
                'fields'         => 'all',
            );

            if ( $last_post_id > 0 ) {
                $args['where'] = '';
                // Use post__not_in would be slow for large sets; use ID offset via WP_Query filter
                add_filter( 'posts_where', function( $where ) use ( $last_post_id ) {
                    global $wpdb;
                    $where .= $wpdb->prepare( " AND {$wpdb->posts}.ID > %d", $last_post_id );
                    return $where;
                });
            }

            $query = new \WP_Query( $args );
            $posts = $query->posts;

            // Remove the filter to avoid side effects
            remove_all_filters( 'posts_where' );

            // Load existing logs
            $logs = json_decode( get_option( BETTERLINKS_PRO_FULLSITE_BROKEN_LINK_LOGS, '{}' ), true );
            if ( ! is_array( $logs ) ) {
                $logs = array();
            }

            if ( empty( $posts ) ) {
                // No more posts — scan is complete
                $progress['status'] = 'complete';
                $progress['scanned'] = $total_posts; // Ensure scanned equals total when complete
                $progress['completed_at'] = current_time( 'mysql' );
                update_option( 'betterlinkspro_force_scan_progress', $progress );
                update_option( 'betterlinkspro_force_scan_completed', true );

                // Unschedule the recurring CRON event
                wp_clear_scheduled_hook( 'betterlinkspro/force_fullsite_scan_cron' );

                delete_transient( 'betterlinkspro_force_scan_lock' );
                return;
            }

            // Process this batch
            foreach ( $posts as $post ) {
                $post_id = $post->ID;

                // Skip if already scanned (e.g., from a resumed scan)
                if ( isset( $logs[ $post_id ] ) ) {
                    $scanned++;
                    $last_post_id = $post_id;
                    continue;
                }

                $post_content = ! empty( $post->post_content ) ? $post->post_content : '';

                if ( empty( $post_content ) ) {
                    $scanned++;
                    $last_post_id = $post_id;
                    continue;
                }

                $doc = new \DomDocument();
                @$doc->loadHTML( '<?xml encoding="UTF-8">' . $post_content );
                $link_elements = $doc->getElementsByTagName( 'a' );

                $extracted_links = array();
                foreach ( $link_elements as $link_element ) {
                    $href = $link_element->getAttribute( 'href' );
                    if ( empty( $href ) || strpos( $href, '#' ) === 0 ) {
                        continue;
                    }
                    $extracted_links[ $href ] = array(
                        'innerText' => $link_element->textContent,
                        'post_type' => $post->post_type,
                    );
                }

                if ( ! empty( $extracted_links ) ) {
                    $post_logs = array();
                    foreach ( $extracted_links as $link => $link_data ) {
                        // wp_safe_remote_get(), not wp_remote_get(): $link comes from
                        // post content, so the scanner would otherwise fetch whatever
                        // href an author (down to a Contributor writing a draft — draft
                        // and pending are in the post_status list above) put in a page,
                        // including http://127.0.0.1:8080/ or a cloud metadata endpoint,
                        // and record the response code where an admin can read it.
                        // wp_http_validate_url() rejects loopback, RFC1918, link-local
                        // 169.254/16, CGNAT and reserved ranges, and non-http(s) schemes.
                        // A rejected URL comes back as WP_Error and therefore lands in
                        // the logs as 404, exactly like any other unreachable link.
                        $response = wp_safe_remote_get( $link, array(
                            'timeout'     => 5,
                            'sslverify'   => false,
                            'httpversion' => '1.1',
                        ) );

                        $code   = wp_remote_retrieve_response_code( $response );
                        $status = ( ! empty( $code ) && intval( $code ) >= 100 ) ? intval( $code ) : 404;
                        // Keep 401/403 distinct — the report treats them as "check manually",
                        // not as confirmed breakage. Every other 4xx/5xx folds into 404.
                        $status = in_array( $status, array( 401, 403 ), true ) ? $status : ( $status >= 400 ? 404 : $status );

                        $post_logs[ $link ] = array(
                            'innerText'  => $link_data['innerText'],
                            'post_type'  => $link_data['post_type'],
                            'status'     => $status,
                            'checked_at' => time(),
                        );
                    }
                    if ( ! empty( $post_logs ) ) {
                        $logs[ $post_id ] = $post_logs;
                    }
                }

                $scanned++;
                $last_post_id = $post_id;
            }

            // Save progress after this batch
            update_option( BETTERLINKS_PRO_FULLSITE_BROKEN_LINK_LOGS, wp_json_encode( $logs ) );
            // Keep the "Last scan" stat in step with background (force) scans too.
            update_option( \BetterLinksPro\Admin\Ajax::FULLSITE_LAST_SCAN_OPTION, time(), false );

            $progress['last_post_id'] = $last_post_id;
            $progress['scanned']      = $scanned;
            $progress['status']       = 'running';
            update_option( 'betterlinkspro_force_scan_progress', $progress );

            delete_transient( 'betterlinkspro_force_scan_lock' );

            // Schedule next batch immediately via a non-blocking loopback
            $this->trigger_next_batch();

        } catch ( \Exception $e ) {
            if ( defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
                // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Gated by WP_DEBUG_LOG.
                error_log( 'BetterLinks Force Scan Error: ' . $e->getMessage() );
                // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Gated by WP_DEBUG_LOG.
                error_log( 'BetterLinks Force Scan Trace: ' . $e->getTraceAsString() );
            }

            // Mark progress as failed so frontend can report it
            $progress = get_option( 'betterlinkspro_force_scan_progress', array() );
            if ( is_array( $progress ) ) {
                $progress['status'] = 'failed';
                $progress['error']  = $e->getMessage();
                update_option( 'betterlinkspro_force_scan_progress', $progress );
            }

            delete_transient( 'betterlinkspro_force_scan_lock' );
        }
    }

    /**
     * Trigger the next batch via a non-blocking loopback request.
     * This allows each batch to run in its own PHP process, avoiding timeouts.
     */
    private function trigger_next_batch()
    {
        wp_remote_post(
            admin_url( 'admin-ajax.php' ),
            array(
                'blocking'  => false,
                // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
                'sslverify' => apply_filters( 'https_local_over_ssl', false ),
                'timeout'   => 0.01,
                'body'      => array(
                    'action' => 'betterlinkspro/force_fullsite_scan_background',
                    // Each hop mints the credential for the next one; the handler
                    // consumes it, so tokens are single-use.
                    'token'  => \BetterLinksPro\Admin\Ajax::issue_force_scan_token(),
                ),
            )
        );
    }
}
