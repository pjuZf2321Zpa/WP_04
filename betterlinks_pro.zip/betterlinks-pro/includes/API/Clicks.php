<?php
namespace BetterLinksPro\API;
if ( ! defined( 'ABSPATH' ) ) { exit; }

use BetterLinks\Traits\ArgumentSchema;
use BetterLinksPro\Helper;

class Clicks
{
    use ArgumentSchema;
    private $namespace;
    public function __construct()
    {
        $this->namespace = BETTERLINKS_PLUGIN_SLUG . '/v1';
        add_action('betterlinks_register_clicks_routes', array($this, 'register_routes'));
    }

    public function register_routes()
    {
        $endpoint = '/clicks/';
        // Geography and Timing report data: older free plugins still register these routes.
        if ( \BetterLinksPro\Compat::free_has_extension_api() ) {
            register_rest_route(
                $this->namespace,
                $endpoint . 'get_timing/',
                array(
                    array(
                        'methods'             => \WP_REST_Server::READABLE,
                        'callback'            => array( $this, 'get_timing' ),
                        'permission_callback' => [$this, 'permissions_check'],
                        'args'                => $this->get_clicks_schema(),
                    ),
                )
            );
            register_rest_route(
                $this->namespace,
                $endpoint . 'get_countries/',
                array(
                    array(
                        'methods'             => \WP_REST_Server::READABLE,
                        'callback'            => array( $this, 'get_countries' ),
                        'permission_callback' => [$this, 'permissions_check'],
                        'args'                => $this->get_clicks_schema(),
                    ),
                )
            );
        }
        register_rest_route(
            $this->namespace,
            '/clicks/individual/(?P<id>[\d]+)',
            array(
                'args'   => array(
                    'id' => array(
                        'description' => __('Unique identifier for the object.', 'betterlinks-pro'),
                        'type'        => 'integer',
                    ),
                ),
                array(
                    'methods'             => \WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'get_item' ),
                    'permission_callback' => [$this, 'permissions_check'],
                    'args'                => $this->get_clicks_schema(),
                ),
            )
        );
        register_rest_route(
            $this->namespace,
            '/clicks/splittest/(?P<id>[\d]+)',
            array(
                'args'   => array(
                    'id' => array(
                        'description' => __('Unique identifier for the object.', 'betterlinks-pro'),
                        'type'        => 'integer',
                    ),
                ),
                array(
                    'methods'             => \WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'get_split_test_item' ),
                    'permission_callback' => [$this, 'permissions_check'],
                    'args'                => $this->get_clicks_schema(),
                ),
            )
        );

        register_rest_route(
			$this->namespace,
			$endpoint . 'get_medium/',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_medium' ),
					'permission_callback' => array( $this, 'permissions_check' ),
					'args'                => $this->get_clicks_schema(),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			$endpoint . 'get_charts/',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_charts' ),
					'permission_callback' => array( $this, 'permissions_check' ),
					'args'                => $this->get_clicks_schema(),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/clicks/get_individual_charts/(?P<id>[\d]+)',
			array(
				'args'   => array(
					'id' => array(
						'description' => __('Unique identifier for the link.', 'betterlinks-pro'),
						'type'        => 'integer',
					),
				),
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_individual_charts' ),
					'permission_callback' => array( $this, 'permissions_check' ),
					'args'                => $this->get_clicks_schema(),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/clicks/get_individual_medium/(?P<id>[\d]+)',
			array(
				'args'   => array(
					'id' => array(
						'description' => __('Unique identifier for the link.', 'betterlinks-pro'),
						'type'        => 'integer',
					),
				),
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_individual_medium' ),
					'permission_callback' => array( $this, 'permissions_check' ),
					'args'                => $this->get_clicks_schema(),
				),
			)
		);
    }

    public function get_item($request)
    {
        $request = $request->get_params();
        $results = \BetterLinksPro\Helper::get_individual_link_analytics($request);
        return new \WP_REST_Response(
            [
                'success' => true,
                'data' => $results,
            ],
            200
        );
    }
    
    public function get_split_test_item($request)
    {
        $request = $request->get_params();
        $results = \BetterLinksPro\Helper::get_split_test_analytics_data($request);
        return new \WP_REST_Response(
            [
                'success' => true,
                'data' => $results,
            ],
            200
        );
    }

    /**
     * Check if a given request has access to update a setting
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|bool
     */
    public function permissions_check($request)
    {
        return apply_filters('betterlinkspro/api/analytics_items_permissions_check', current_user_can('manage_options'));
    }

    /**
     * Normalize an analytics date-range value to a bare Y-m-d string.
     *
     * Defense-in-depth for the analytics graph/chart queries: the underlying
     * Helper methods now bind these through $wpdb->prepare(), but coercing to a
     * strict date here means a caller can never push anything but a date into the
     * range in the first place. Falls back to $default when unparseable.
     *
     * @param mixed  $value   Raw request value.
     * @param string $default Fallback Y-m-d.
     * @return string
     */
    private function normalize_range_date( $value, $default ) {
        if ( ! is_scalar( $value ) ) {
            return $default;
        }
        $ts = strtotime( sanitize_text_field( (string) $value ) );
        return $ts ? gmdate( 'Y-m-d', $ts ) : $default;
    }

    /**
	 * Get Analytics Top Medium Data
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 * @return WP_Error|WP_REST_Response
	 */
	public function get_medium( $request ) {
		$request = $request->get_params();
		$from    = $this->normalize_range_date( isset( $request['from'] ) ? $request['from'] : null, gmdate( 'Y-m-d', strtotime( ' - 30 days' ) ) );
		$to      = $this->normalize_range_date( isset( $request['to'] ) ? $request['to'] : null, gmdate( 'Y-m-d' ) );

		$top_medium = array();
		if ( apply_filters( 'betterlinks/is_extra_data_tracking_compatible', false ) ) {
			$all_referer = Helper::get_all_referer( $from, $to );
			$top_medium  = Helper::get_top_medium( $all_referer );
		}
		return new \WP_REST_Response(
			array(
				'success' => true,
				'data'    => array(
					'medium' => $top_medium,
				),
			)
		);
	}

	/**
	 * Get Analytics Chart Data
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 * @return WP_Error|WP_REST_Response
	 */
	public function get_charts( $request ) {
		$request = $request->get_params();
		$from    = $this->normalize_range_date( isset( $request['from'] ) ? $request['from'] : null, gmdate( 'Y-m-d', strtotime( ' - 30 days' ) ) );
		$to      = $this->normalize_range_date( isset( $request['to'] ) ? $request['to'] : null, gmdate( 'Y-m-d' ) );

		$top_referer = $device_stats = $top_os = $top_browser = array();
		if ( apply_filters( 'betterlinks/is_extra_data_tracking_compatible', false ) ) {
			$top_referer  = Helper::get_top_referer( $from, $to );
			$device_stats = Helper::get_device_click_stats( $from, $to );
			$top_os       = Helper::get_top_os( $from, $to );
			$top_browser  = Helper::prepare_browser_data( $from, $to );
		}

		return new \WP_REST_Response(
			array(
				'success' => true,
				'data'    => array(
					'referer' => $top_referer,
					'devices' => $device_stats,
					'os'      => $top_os,
					'browser' => $top_browser,
				),
			)
		);
	}

	/**
	 * Get Individual Link Analytics Chart Data
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 * @return WP_Error|WP_REST_Response
	 */
	public function get_individual_charts( $request ) {
		$params  = $request->get_params();
		$link_id = isset( $params['id'] ) ? intval( $params['id'] ) : 0;
		$from    = $this->normalize_range_date( isset( $params['from'] ) ? $params['from'] : null, gmdate( 'Y-m-d', strtotime( ' - 30 days' ) ) );
		$to      = $this->normalize_range_date( isset( $params['to'] ) ? $params['to'] : null, gmdate( 'Y-m-d' ) );

		$top_referer = $device_stats = $top_os = $top_browser = array();
		if ( apply_filters( 'betterlinks/is_extra_data_tracking_compatible', false ) && $link_id ) {
			$top_referer  = Helper::get_individual_top_referer( $link_id, $from, $to );
			$device_stats = Helper::get_individual_device_stats( $link_id, $from, $to );
			$top_os       = Helper::get_individual_top_os( $link_id, $from, $to );
			$top_browser  = Helper::get_individual_browser_data( $link_id, $from, $to );
		}

		return new \WP_REST_Response(
			array(
				'success' => true,
				'data'    => array(
					'referer' => $top_referer,
					'devices' => $device_stats,
					'os'      => $top_os,
					'browser' => $top_browser,
				),
			)
		);
	}

	/**
	 * Get Individual Link Analytics Medium Data
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 * @return WP_Error|WP_REST_Response
	 */
	public function get_individual_medium( $request ) {
		$params  = $request->get_params();
		$link_id = isset( $params['id'] ) ? intval( $params['id'] ) : 0;
		$from    = $this->normalize_range_date( isset( $params['from'] ) ? $params['from'] : null, gmdate( 'Y-m-d', strtotime( ' - 30 days' ) ) );
		$to      = $this->normalize_range_date( isset( $params['to'] ) ? $params['to'] : null, gmdate( 'Y-m-d' ) );

		$top_medium = array();
		if ( apply_filters( 'betterlinks/is_extra_data_tracking_compatible', false ) && $link_id ) {
			$all_referer = Helper::get_individual_referer( $link_id, $from, $to );
			$top_medium  = Helper::get_top_medium( $all_referer );
		}

		return new \WP_REST_Response(
			array(
				'success' => true,
				'data'    => array(
					'medium' => $top_medium,
				),
			)
		);
	}

    /**
     * Clicks aggregated by country for the range (Geography report).
     *
     * @param \WP_REST_Request $request Request.
     * @return \WP_REST_Response
     */
    public function get_countries( $request )
    {
        $params = $request->get_params();
        $valid  = static function ( $date ) {
            return is_string( $date ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date );
        };
        $from = isset( $params['from'] ) && $valid( $params['from'] ) ? $params['from'] : gmdate( 'Y-m-d', strtotime( ' - 30 days' ) );
        $to   = isset( $params['to'] ) && $valid( $params['to'] ) ? $params['to'] : gmdate( 'Y-m-d' );

        return new \WP_REST_Response(
            array(
                'success' => true,
                'data'    => array(
                    'countries' => \BetterLinksPro\Services\CountryDetectionService::get_country_statistics( $from, $to ),
                ),
            )
        );
    }

    /**
     * Clicks bucketed by weekday and hour for the range (Timing heatmap).
     *
     * Rows are { dow (0=Mon..6=Sun), hr (0..23), clicks, unique_clicks }; empty
     * buckets are omitted and filled client-side. Uses created_at (site-local).
     *
     * @param \WP_REST_Request $request Request.
     * @return \WP_REST_Response
     */
    public function get_timing( $request )
    {
        $params = $request->get_params();
        $valid  = static function ( $date ) {
            return is_string( $date ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date );
        };
        $from = isset( $params['from'] ) && $valid( $params['from'] ) ? $params['from'] : gmdate( 'Y-m-d', strtotime( ' - 30 days' ) );
        $to   = isset( $params['to'] ) && $valid( $params['to'] ) ? $params['to'] : gmdate( 'Y-m-d' );

        $transient_key = 'btl_analytics_timing_' . str_replace( '-', '_', $from ) . '_' . str_replace( '-', '_', $to );
        $exclusion     = \BetterLinksPro\Analytics\IpExclusion::clause( 'ip' );
        if ( '' !== $exclusion['sql'] ) {
            $transient_key .= '_' . substr( md5( implode( ',', $exclusion['params'] ) ), 0, 8 );
        }

        $timing = get_transient( $transient_key );
        if ( ! is_array( $timing ) ) {
            global $wpdb;
            $query_params     = array( $from . ' 00:00:00', $to . ' 23:59:59' );
            $where_conditions = array( 'created_at BETWEEN %s AND %s' );
            if ( '' !== $exclusion['sql'] ) {
                $where_conditions[] = $exclusion['sql'];
                $query_params       = array_merge( $query_params, $exclusion['params'] );
            }
            // phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
            $query  = "SELECT WEEKDAY(created_at) as dow, HOUR(created_at) as hr, COUNT(id) as clicks, COUNT(DISTINCT ip) as unique_clicks
                FROM {$wpdb->prefix}betterlinks_clicks WHERE " . implode( ' AND ', $where_conditions ) . ' GROUP BY dow, hr';
            $rows   = $wpdb->get_results( $wpdb->prepare( $query, $query_params ), ARRAY_A );
            // phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
            $timing = $rows ? $rows : array();
            set_transient( $transient_key, $timing, HOUR_IN_SECONDS );
        }

        return new \WP_REST_Response(
            array(
                'success' => true,
                'data'    => array(
                    'timing' => $timing,
                ),
            )
        );
    }
}
