<?php
namespace BetterLinksPro\API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use BetterLinksPro\Traits\BioPages as BioPagesTrait;
use BetterLinksPro\Frontend\LinkInBio\Templates;
use BetterLinksPro\Frontend\LinkInBio\LinkFactory;
use BetterLinksPro\Frontend\LinkInBio\Manager;

/**
 * REST controller for the "Link in Bio" feature.
 *
 * Routes (namespace: betterlinks-pro/v1):
 *   GET    /bio-pages                  list
 *   POST   /bio-pages                  create
 *   GET    /bio-pages/{id}             read
 *   PUT    /bio-pages/{id}             update
 *   DELETE /bio-pages/{id}             delete
 *   POST   /bio-pages/{id}/duplicate   duplicate
 *   GET    /bio-pages/check-slug       slug availability
 *   GET    /bio-pages/templates        readymade templates + design tokens
 *   GET    /bio-pages/analytics        overall analytics
 *   GET    /bio-pages/analytics/{id}   per-bio analytics
 */
class BioPages extends \WP_REST_Controller {

	use BioPagesTrait;

	public function __construct() {
		$this->namespace = BETTERLINKS_PRO_PLUGIN_SLUG . '/v1';
		$this->rest_base = 'bio-pages';
	}

	public function register_routes() {
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base,
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_items' ),
					'permission_callback' => array( $this, 'get_items_permissions_check' ),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_item' ),
					'permission_callback' => array( $this, 'create_item_permissions_check' ),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/templates',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_templates' ),
				'permission_callback' => array( $this, 'get_items_permissions_check' ),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/check-slug',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'check_slug' ),
				'permission_callback' => array( $this, 'create_item_permissions_check' ),
				'args'                => array(
					'slug' => array( 'type' => 'string' ),
					'id'   => array( 'type' => 'integer' ),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/analytics',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_overall_analytics' ),
				'permission_callback' => array( $this, 'analytics_permissions_check' ),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/analytics/(?P<id>[\d]+)',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_bio_analytics' ),
				'permission_callback' => array( $this, 'analytics_permissions_check' ),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/(?P<id>[\d]+)/duplicate',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'duplicate_item' ),
				'permission_callback' => array( $this, 'create_item_permissions_check' ),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/(?P<id>[\d]+)',
			array(
				'args' => array(
					'id' => array(
						'description' => __( 'Unique identifier for the bio page.', 'betterlinks-pro' ),
						'type'        => 'integer',
					),
				),
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_item' ),
					'permission_callback' => array( $this, 'get_items_permissions_check' ),
				),
				array(
					'methods'             => \WP_REST_Server::EDITABLE,
					'callback'            => array( $this, 'update_item' ),
					'permission_callback' => array( $this, 'update_item_permissions_check' ),
				),
				array(
					'methods'             => \WP_REST_Server::DELETABLE,
					'callback'            => array( $this, 'delete_item' ),
					'permission_callback' => array( $this, 'update_item_permissions_check' ),
				),
			)
		);
	}

	/* ----------------------------------------------------------------- *
	 * Endpoints                                                          *
	 * ----------------------------------------------------------------- */

	public function get_items( $request ) {
		return new \WP_REST_Response( self::get_bios(), 200 );
	}

	public function get_item( $request ) {
		$bio = self::get_bio( $request['id'] );
		if ( null === $bio ) {
			return $this->not_found();
		}
		return new \WP_REST_Response( $bio, 200 );
	}

	public function get_templates( $request ) {
		return new \WP_REST_Response(
			array(
				'templates'      => Templates::templates(),
				'default_config' => Templates::default_config(),
				'tokens'         => array(
					'style_presets' => Templates::style_presets(),
					'layouts'       => Templates::layouts(),
					'button_styles' => Templates::button_styles(),
					'button_shapes' => Templates::button_shapes(),
					'fonts'         => Templates::fonts(),
					'icon_types'    => Templates::icon_types(),
				),
			),
			200
		);
	}

	public function check_slug( $request ) {
		$slug = self::sanitize_bio_slug( (string) $request->get_param( 'slug' ) );
		$id   = absint( $request->get_param( 'id' ) );
		if ( '' === $slug ) {
			return new \WP_REST_Response(
				array(
					'available' => false,
					'slug'      => '',
					'message'   => __( 'Please enter a handle.', 'betterlinks-pro' ),
				),
				200
			);
		}
		$available = self::is_bio_slug_available( $slug, $id );
		return new \WP_REST_Response(
			array(
				'available' => $available,
				'slug'      => $slug,
				'full_url'  => self::bio_public_url( $slug ),
			),
			200
		);
	}

	public function create_item( $request ) {
		$payload = $this->prepare_payload( $request, 0 );
		if ( is_wp_error( $payload ) ) {
			return $payload;
		}

		$id = self::insert_bio( $payload['columns'] );
		if ( ! $id ) {
			return new \WP_Error( 'betterlinks_bio_insert_failed', __( 'Could not create the bio page.', 'betterlinks-pro' ), array( 'status' => 500 ) );
		}

		// Sync tracked links now that we have a real bio id/slug, then persist link ids.
		$config = LinkFactory::sync_config_links( $payload['config'], $payload['columns']['title'], $payload['columns']['slug'] );
		self::update_bio( $id, array( 'config' => wp_json_encode( $config ) ) );

		return new \WP_REST_Response(
			array(
				'success' => true,
				'message' => esc_html__( 'Bio page created.', 'betterlinks-pro' ),
				'data'    => self::get_bio( $id ),
			),
			201
		);
	}

	public function update_item( $request ) {
		$id  = absint( $request['id'] );
		$bio = self::get_bio( $id );
		if ( null === $bio ) {
			return $this->not_found();
		}

		$payload = $this->prepare_payload( $request, $id );
		if ( is_wp_error( $payload ) ) {
			return $payload;
		}

		$config                       = LinkFactory::sync_config_links( $payload['config'], $payload['columns']['title'], $payload['columns']['slug'] );
		$payload['columns']['config'] = wp_json_encode( $config );

		$updated = self::update_bio( $id, $payload['columns'] );
		if ( false === $updated ) {
			return new \WP_Error( 'betterlinks_bio_update_failed', __( 'Could not update the bio page.', 'betterlinks-pro' ), array( 'status' => 500 ) );
		}

		return new \WP_REST_Response(
			array(
				'success' => true,
				'message' => esc_html__( 'Bio page saved.', 'betterlinks-pro' ),
				'data'    => self::get_bio( $id ),
			),
			200
		);
	}

	public function delete_item( $request ) {
		$id  = absint( $request['id'] );
		$bio = self::get_bio( $id );
		if ( null === $bio ) {
			return $this->not_found();
		}

		// Remove the tracked short links this bio created before dropping the row.
		LinkFactory::delete_config_links( $bio['config'] );
		self::delete_bio( $id );

		return new \WP_REST_Response(
			array(
				'success' => true,
				'message' => esc_html__( 'Bio page deleted.', 'betterlinks-pro' ),
				'id'      => $id,
			),
			200
		);
	}

	public function duplicate_item( $request ) {
		$id  = absint( $request['id'] );
		$bio = self::get_bio( $id );
		if ( null === $bio ) {
			return $this->not_found();
		}

		$config = $bio['config'];
		// Detach tracked links from the copy so we don't share short links.
		foreach ( array( 'icons', 'links' ) as $group ) {
			if ( ! empty( $config[ $group ] ) && is_array( $config[ $group ] ) ) {
				foreach ( $config[ $group ] as $i => $entry ) {
					$config[ $group ][ $i ]['link_id'] = 0;
				}
			}
		}

		$slug = $this->unique_slug( $bio['slug'] . '-copy' );

		$columns = array(
			'title'      => $bio['title'] . ' ' . __( '(copy)', 'betterlinks-pro' ),
			'slug'       => $slug,
			'status'     => 'draft',
			'avatar_id'  => $bio['avatar_id'],
			'avatar_url' => $bio['avatar_url'],
			'config'     => wp_json_encode( $config ),
			'views'      => 0,
			'author'     => get_current_user_id(),
		);

		$new_id = self::insert_bio( $columns );
		if ( ! $new_id ) {
			return new \WP_Error( 'betterlinks_bio_duplicate_failed', __( 'Could not duplicate the bio page.', 'betterlinks-pro' ), array( 'status' => 500 ) );
		}

		return new \WP_REST_Response(
			array(
				'success' => true,
				'message' => esc_html__( 'Bio page duplicated.', 'betterlinks-pro' ),
				'data'    => self::get_bio( $new_id ),
			),
			201
		);
	}

	public function get_overall_analytics( $request ) {
		$bios         = self::get_bios();
		$total_views  = 0;
		$total_clicks = 0;
		$rows         = array();
		$series_days  = 14;

		foreach ( $bios as $bio ) {
			$views         = (int) $bio['views'];
			$clicks        = (int) $bio['clicks'];
			$total_views  += $views;
			$total_clicks += $clicks;

			$rows[] = array(
				'id'         => $bio['ID'],
				'title'      => $this->display_title( $bio ),
				'slug'       => $bio['slug'],
				'status'     => $bio['status'],
				'avatar_url' => isset( $bio['config']['profile']['avatar_url'] ) ? $bio['config']['profile']['avatar_url'] : '',
				'views'      => $views,
				'clicks'     => $clicks,
				// Clicks per visit, as a percentage. Capped at 100 because a
				// visitor can click several links in one visit, which would
				// otherwise read as a nonsensical >100% rate.
				'ctr'        => $views > 0 ? min( 100, round( ( $clicks / $views ) * 100, 1 ) ) : 0,
				'series'     => self::bio_link_click_series( self::bio_tracked_link_ids( $bio['config'] ), $series_days ),
			);
		}

		return new \WP_REST_Response(
			array(
				'total_bios'   => count( $bios ),
				'total_views'  => $total_views,
				'total_clicks' => $total_clicks,
				'total_ctr'    => $total_views > 0 ? min( 100, round( ( $total_clicks / $total_views ) * 100, 1 ) ) : 0,
				'series_days'  => $series_days,
				'bios'         => $rows,
			),
			200
		);
	}

	public function get_bio_analytics( $request ) {
		$id  = absint( $request['id'] );
		$bio = self::get_bio( $id );
		if ( null === $bio ) {
			return $this->not_found();
		}

		$link_stats = array();
		foreach ( array( 'icons', 'links' ) as $group ) {
			if ( empty( $bio['config'][ $group ] ) || ! is_array( $bio['config'][ $group ] ) ) {
				continue;
			}
			foreach ( $bio['config'][ $group ] as $entry ) {
				if ( empty( $entry['link_id'] ) ) {
					continue;
				}
				$stats        = self::bio_link_click_stats( array( (int) $entry['link_id'] ) );
				$label        = isset( $entry['label'] ) && '' !== $entry['label'] ? $entry['label'] : ( isset( $entry['type'] ) ? ucfirst( $entry['type'] ) : __( 'Link', 'betterlinks-pro' ) );
				$link_stats[] = array(
					'link_id' => (int) $entry['link_id'],
					'label'   => $label,
					'url'     => isset( $entry['url'] ) ? $entry['url'] : '',
					'clicks'  => $stats['total'],
					'unique'  => $stats['unique'],
				);
			}
		}

		return new \WP_REST_Response(
			array(
				'id'     => $bio['ID'],
				'title'  => $this->display_title( $bio ),
				'slug'   => $bio['slug'],
				'views'  => (int) $bio['views'],
				'clicks' => (int) $bio['clicks'],
				'links'  => $link_stats,
			),
			200
		);
	}

	/* ----------------------------------------------------------------- *
	 * Helpers                                                            *
	 * ----------------------------------------------------------------- */

	/**
	 * Validate + map a request into DB columns and a sanitized config.
	 *
	 * @param \WP_REST_Request $request
	 * @param int              $id Bio id (0 on create) for slug-uniqueness exclusion.
	 * @return array|\WP_Error { columns: array, config: array }
	 */
	protected function prepare_payload( $request, $id ) {
		$title  = sanitize_text_field( (string) $request->get_param( 'title' ) );
		$status = 'publish' === $request->get_param( 'status' ) ? 'publish' : 'draft';

		$raw_config = $request->get_param( 'config' );
		if ( is_string( $raw_config ) ) {
			$raw_config = json_decode( $raw_config, true );
		}

		// On update, hand the stored config to the sanitizer so settings the payload
		// does not mention are preserved rather than reset to their defaults. Without
		// this a save from a stale admin bundle would quietly switch the
		// "Made with BetterLinks" credit back on for a white-labelled page.
		$existing = array();
		if ( $id ) {
			$current = self::get_bio( $id );
			if ( $current && ! empty( $current['config'] ) && is_array( $current['config'] ) ) {
				$existing = $current['config'];
			}
		}

		$config = $this->sanitize_config( is_array( $raw_config ) ? $raw_config : array(), $existing );

		// Slug: from request, else derive from title.
		$slug = self::sanitize_bio_slug( (string) $request->get_param( 'slug' ) );
		if ( '' === $slug ) {
			$slug = self::sanitize_bio_slug( $title );
		}
		if ( '' === $slug ) {
			$slug = 'bio';
		}
		if ( ! self::is_bio_slug_available( $slug, $id ) ) {
			// Publishing requires a free slug; auto-suffix to keep saving non-blocking.
			$slug = $this->unique_slug( $slug, $id );
		}

		if ( 'publish' === $status && '' === $title ) {
			$title = ucfirst( $slug );
		}

		$avatar_id  = absint( $request->get_param( 'avatar_id' ) );
		$avatar_url = esc_url_raw( (string) $request->get_param( 'avatar_url' ) );
		if ( ! empty( $config['profile']['avatar_url'] ) ) {
			$avatar_url = $config['profile']['avatar_url'];
			$avatar_id  = isset( $config['profile']['avatar_id'] ) ? (int) $config['profile']['avatar_id'] : $avatar_id;
		}

		$columns = array(
			'title'      => $title,
			'slug'       => $slug,
			'status'     => $status,
			'avatar_id'  => $avatar_id,
			'avatar_url' => $avatar_url,
			'config'     => wp_json_encode( $config ),
			'author'     => get_current_user_id(),
		);

		return array(
			'columns' => $columns,
			'config'  => $config,
		);
	}

	/**
	 * Deep-sanitize the builder config against the known token sets.
	 *
	 * @param array $config   Incoming (untrusted) config.
	 * @param array $existing Stored config on update, used to preserve settings the
	 *                        payload does not mention. Empty on create.
	 * @return array
	 */
	protected function sanitize_config( $config, $existing = array() ) {
		$defaults = Templates::default_config();
		$out      = $defaults;
		$existing = is_array( $existing ) ? $existing : array();

		// Profile.
		if ( ! empty( $config['profile'] ) && is_array( $config['profile'] ) ) {
			$p                       = $config['profile'];
			$out['profile']['title'] = isset( $p['title'] ) ? sanitize_text_field( $p['title'] ) : '';
			// Bio supports rich text from the editor (bold/lists/links).
			$out['profile']['bio']   = isset( $p['bio'] ) ? wp_kses_post( $p['bio'] ) : '';
			$out['profile']['avatar_url'] = isset( $p['avatar_url'] ) ? esc_url_raw( $p['avatar_url'] ) : '';
			$out['profile']['avatar_id']  = isset( $p['avatar_id'] ) ? absint( $p['avatar_id'] ) : 0;
		}

		// Icon + link entries.
		$out['icons']  = $this->sanitize_entries( isset( $config['icons'] ) ? $config['icons'] : array(), true );
		$out['links']  = $this->sanitize_entries( isset( $config['links'] ) ? $config['links'] : array(), false );
		$out['footer'] = $this->sanitize_footer( isset( $config['footer'] ) ? $config['footer'] : array() );

		// Enumerated tokens.
		$out['layout'] = ( isset( $config['layout'] ) && in_array( $config['layout'], Templates::layouts(), true ) ) ? $config['layout'] : 'classic';
		$presets       = Templates::style_presets();
		$out['style']  = ( isset( $config['style'] ) && isset( $presets[ $config['style'] ] ) ) ? $config['style'] : 'light';
		$out['font']   = ( isset( $config['font'] ) && in_array( $config['font'], Templates::fonts(), true ) ) ? $config['font'] : 'Inter';

		// Background.
		if ( ! empty( $config['background'] ) && is_array( $config['background'] ) ) {
			$bg   = $config['background'];
			$type = isset( $bg['type'] ) && in_array( $bg['type'], array( 'solid', 'gradient', 'image' ), true ) ? $bg['type'] : 'solid';

			$out['background']['type']  = $type;
			$out['background']['color'] = isset( $bg['color'] ) ? sanitize_text_field( $bg['color'] ) : $defaults['background']['color'];
			if ( ! empty( $bg['gradient'] ) && is_array( $bg['gradient'] ) ) {
				$out['background']['gradient'] = array(
					'from'  => isset( $bg['gradient']['from'] ) ? sanitize_text_field( $bg['gradient']['from'] ) : '#8a8dff',
					'to'    => isset( $bg['gradient']['to'] ) ? sanitize_text_field( $bg['gradient']['to'] ) : '#e0c3fc',
					'angle' => isset( $bg['gradient']['angle'] ) ? max( 0, min( 360, (int) $bg['gradient']['angle'] ) ) : 160,
				);
			}
			$out['background']['image_id']  = isset( $bg['image_id'] ) ? absint( $bg['image_id'] ) : 0;
			$out['background']['image_url'] = isset( $bg['image_url'] ) ? esc_url_raw( $bg['image_url'] ) : '';
		}

		// Buttons.
		if ( ! empty( $config['buttons'] ) && is_array( $config['buttons'] ) ) {
			$b                           = $config['buttons'];
			$out['buttons']['style']     = isset( $b['style'] ) && in_array( $b['style'], Templates::button_styles(), true ) ? $b['style'] : 'solid';
			$out['buttons']['animation'] = isset( $b['animation'] ) && in_array( $b['animation'], Templates::button_animations(), true ) ? $b['animation'] : 'none';
			$out['buttons']['shape']     = isset( $b['shape'] ) && in_array( $b['shape'], Templates::button_shapes(), true ) ? $b['shape'] : 'rounded';
			// Radius: empty string means "auto" (use the shape's radius).
			$out['buttons']['radius']    = ( isset( $b['radius'] ) && '' !== $b['radius'] && null !== $b['radius'] ) ? max( 0, min( 40, (int) $b['radius'] ) ) : '';
			$out['buttons']['color']     = isset( $b['color'] ) ? sanitize_text_field( $b['color'] ) : $defaults['buttons']['color'];
			$out['buttons']['fontColor'] = isset( $b['fontColor'] ) ? sanitize_text_field( $b['fontColor'] ) : $defaults['buttons']['fontColor'];
		}

		// Title / description colour overrides (blank = follow theme).
		if ( ! empty( $config['colors'] ) && is_array( $config['colors'] ) ) {
			$out['colors']['title']       = isset( $config['colors']['title'] ) ? sanitize_text_field( $config['colors']['title'] ) : '';
			$out['colors']['description'] = isset( $config['colors']['description'] ) ? sanitize_text_field( $config['colors']['description'] ) : '';
		}

		// SEO / meta data.
		if ( ! empty( $config['seo'] ) && is_array( $config['seo'] ) ) {
			$seo                          = $config['seo'];
			$out['seo']['meta_title']     = isset( $seo['meta_title'] ) ? sanitize_text_field( $seo['meta_title'] ) : '';
			$out['seo']['meta_description'] = isset( $seo['meta_description'] ) ? sanitize_textarea_field( $seo['meta_description'] ) : '';
			$out['seo']['meta_image_id']  = isset( $seo['meta_image_id'] ) ? absint( $seo['meta_image_id'] ) : 0;
			$out['seo']['meta_image_url'] = isset( $seo['meta_image_url'] ) ? esc_url_raw( $seo['meta_image_url'] ) : '';
		}

		// Branding / white-labelling. Precedence is payload, then whatever the page
		// already had, then the default. A payload that omits the key — an older
		// builder bundle, or the REST API driven directly — must not silently switch
		// the credit back on for a page the owner white-labelled.
		if ( isset( $config['branding']['show_credit'] ) ) {
			$out['branding']['show_credit'] = (bool) filter_var( $config['branding']['show_credit'], FILTER_VALIDATE_BOOLEAN );
		} elseif ( isset( $existing['branding']['show_credit'] ) ) {
			$out['branding']['show_credit'] = (bool) $existing['branding']['show_credit'];
		}

		return $out;
	}

	/**
	 * Sanitize a list of icon/link entries.
	 *
	 * @param mixed $entries
	 * @param bool  $is_icon
	 * @return array
	 */
	protected function sanitize_entries( $entries, $is_icon ) {
		if ( ! is_array( $entries ) ) {
			return array();
		}
		$icon_types = Templates::icon_types();
		$clean      = array();
		foreach ( $entries as $entry ) {
			if ( ! is_array( $entry ) ) {
				continue;
			}
			$row = array(
				'id'      => isset( $entry['id'] ) ? sanitize_text_field( $entry['id'] ) : uniqid( 'e' ),
				'url'     => isset( $entry['url'] ) ? esc_url_raw( $entry['url'] ) : '',
				'track'   => ! empty( $entry['track'] ),
				'link_id' => isset( $entry['link_id'] ) ? absint( $entry['link_id'] ) : 0,
			);
			if ( $is_icon ) {
				$row['type'] = ( isset( $entry['type'] ) && in_array( $entry['type'], $icon_types, true ) ) ? $entry['type'] : 'link';
			} else {
				$row['label'] = isset( $entry['label'] ) ? sanitize_text_field( $entry['label'] ) : '';
				$row['icon']  = ( isset( $entry['icon'] ) && in_array( $entry['icon'], $icon_types, true ) ) ? $entry['icon'] : '';
			}
			$clean[] = $row;
		}
		return $clean;
	}

	/**
	 * Sanitize footer link entries (never tracked).
	 *
	 * @param mixed $entries
	 * @return array
	 */
	protected function sanitize_footer( $entries ) {
		if ( ! is_array( $entries ) ) {
			return array();
		}
		$clean = array();
		foreach ( $entries as $entry ) {
			if ( ! is_array( $entry ) ) {
				continue;
			}
			$clean[] = array(
				'id'    => isset( $entry['id'] ) ? sanitize_text_field( $entry['id'] ) : uniqid( 'f' ),
				'type'  => isset( $entry['type'] ) ? sanitize_key( $entry['type'] ) : 'link',
				'label' => isset( $entry['label'] ) ? sanitize_text_field( $entry['label'] ) : '',
				'url'   => isset( $entry['url'] ) ? esc_url_raw( $entry['url'] ) : '',
			);
		}
		return $clean;
	}

	/**
	 * Produce a unique slug by appending -2, -3, ... when needed.
	 *
	 * @param string $base
	 * @param int    $exclude_id
	 * @return string
	 */
	protected function unique_slug( $base, $exclude_id = 0 ) {
		$base = self::sanitize_bio_slug( $base );
		if ( '' === $base ) {
			$base = 'bio';
		}
		$slug  = $base;
		$guard = 1;
		while ( ! self::is_bio_slug_available( $slug, $exclude_id ) && $guard < 100 ) {
			$guard++;
			$slug = $base . '-' . $guard;
		}
		return $slug;
	}

	/**
	 * Canonical display name for a bio: the profile title, falling back to the
	 * stored column title.
	 *
	 * @param array $bio
	 * @return string
	 */
	protected function display_title( $bio ) {
		if ( ! empty( $bio['config']['profile']['title'] ) ) {
			return $bio['config']['profile']['title'];
		}
		return isset( $bio['title'] ) ? $bio['title'] : '';
	}

	protected function not_found() {
		return new \WP_Error( 'betterlinks_bio_not_found', __( 'Bio page not found.', 'betterlinks-pro' ), array( 'status' => 404 ) );
	}

	/* ----------------------------------------------------------------- *
	 * Permission callbacks (reuse the existing BetterLinks role filters). *
	 * ----------------------------------------------------------------- */

	// Bio Links access is gated by its own Role Management capability
	// (`manageBioLinks`); admins always pass (handled inside current_user_can_do).
	protected function current_user_can_manage_bio_links() {
		$user            = wp_get_current_user();
		$user_permission = json_decode( get_option( BETTERLINKS_PRO_ROLE_PERMISSON_OPTION_NAME, '{}' ), true );
		return \BetterLinksPro\Helper::current_user_can_do( 'manageBioLinks', $user, $user_permission );
	}

	public function get_items_permissions_check( $request ) {
		return $this->current_user_can_manage_bio_links();
	}

	public function create_item_permissions_check( $request ) {
		return $this->current_user_can_manage_bio_links();
	}

	public function update_item_permissions_check( $request ) {
		return $this->current_user_can_manage_bio_links();
	}

	public function analytics_permissions_check( $request ) {
		return $this->current_user_can_manage_bio_links();
	}
}
