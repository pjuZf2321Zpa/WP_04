<?php
namespace BetterLinksPro\API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use BetterLinksPro\Traits\ProductDisplay as ProductDisplayTrait;

/**
 * REST controller for the Product Display feature.
 *
 * Routes (namespace: betterlinks-pro/v1):
 *   GET    /product-displays            list
 *   POST   /product-displays            create
 *   GET    /product-displays/{id}       read
 *   PUT    /product-displays/{id}       update
 *   DELETE /product-displays/{id}       delete
 */
class ProductDisplay extends \WP_REST_Controller {

	use ProductDisplayTrait;

	public function __construct() {
		$this->namespace = BETTERLINKS_PRO_PLUGIN_SLUG . '/v1';
		$this->rest_base = 'product-displays';
	}

	/**
	 * Register the routes for the controller.
	 */
	public function register_routes() {
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base,
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_items' ),
					'permission_callback' => array( $this, 'get_items_permissions_check' ),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_item' ),
					'permission_callback' => array( $this, 'create_item_permissions_check' ),
					'args'                => $this->get_product_display_schema(),
				),
			)
		);

		// WooCommerce product search + lookup (only useful when WC is active).
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/wc/search',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'search_wc_products' ),
					'permission_callback' => array( $this, 'get_items_permissions_check' ),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/wc/product/(?P<id>[\d]+)',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_wc_product' ),
					'permission_callback' => array( $this, 'get_items_permissions_check' ),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/(?P<id>[\d]+)',
			array(
				'args' => array(
					'id' => array(
						'description' => __( 'Unique identifier for the promo card.', 'betterlinks-pro' ),
						'type'        => 'integer',
					),
				),
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_item' ),
					'permission_callback' => array( $this, 'get_items_permissions_check' ),
				),
				array(
					'methods'             => \WP_REST_Server::EDITABLE,
					'callback'            => array( $this, 'update_item' ),
					'permission_callback' => array( $this, 'update_item_permissions_check' ),
					'args'                => $this->get_product_display_schema(),
				),
				array(
					'methods'             => \WP_REST_Server::DELETABLE,
					'callback'            => array( $this, 'delete_item' ),
					'permission_callback' => array( $this, 'update_item_permissions_check' ),
				),
			)
		);
	}

	/**
	 * Argument schema (validation + sanitization) for write requests.
	 *
	 * @return array
	 */
	public function get_product_display_schema() {
		return array(
			'product_name'          => array(
				'type'              => 'string',
				'required'          => true,
				'sanitize_callback' => 'sanitize_text_field',
			),
			'product_source'        => array(
				'type'              => 'string',
				'default'           => 'custom',
				'sanitize_callback' => array( $this, 'sanitize_product_source' ),
			),
			'wc_product_id'         => array(
				'type'              => 'integer',
				'sanitize_callback' => 'absint',
			),
			'product_image_id'      => array(
				'type'              => 'integer',
				'sanitize_callback' => 'absint',
			),
			'product_image_url'     => array(
				'type'              => 'string',
				'sanitize_callback' => 'esc_url_raw',
			),
			'template'              => array(
				'type'              => 'string',
				'default'           => 'epsilon',
				'sanitize_callback' => array( $this, 'sanitize_template' ),
			),
			'badge_text'            => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'price'                 => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'regular_price'         => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'sale_price'            => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'style'                 => array(
				'type' => 'object',
			),
			'description'           => array(
				'type'              => 'string',
				'sanitize_callback' => 'wp_kses_post',
			),
			'primary_link_id'       => array(
				'type'              => 'integer',
				'sanitize_callback' => 'absint',
			),
			'primary_button_text'   => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'primary_new_url'       => array(
				'type'              => 'string',
				'sanitize_callback' => 'esc_url_raw',
			),
			'primary_tracking'      => array( 'type' => 'boolean' ),
			'primary_nofollow'      => array( 'type' => 'boolean' ),
			'secondary_link_id'     => array(
				'type'              => 'integer',
				'sanitize_callback' => 'absint',
			),
			'secondary_button_text' => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'secondary_new_url'     => array(
				'type'              => 'string',
				'sanitize_callback' => 'esc_url_raw',
			),
			'secondary_tracking'    => array( 'type' => 'boolean' ),
			'secondary_nofollow'    => array( 'type' => 'boolean' ),
			'disclosure_text'       => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_textarea_field',
			),
			'show_disclosure'       => array( 'type' => 'boolean' ),
			'default_disclosure'    => array( 'type' => 'boolean' ),
			'new_tab'               => array( 'type' => 'boolean' ),
			'status'                => array( 'type' => 'boolean' ),
		);
	}

	/**
	 * Restrict the template to the supported set.
	 *
	 * @param string $value
	 * @return string
	 */
	public function sanitize_template( $value ) {
		$value = sanitize_text_field( $value );
		return \BetterLinksPro\Frontend\ProductDisplay\Renderer::is_valid_template( $value ) ? $value : \BetterLinksPro\Frontend\ProductDisplay\Renderer::DEFAULT_TEMPLATE;
	}

	/**
	 * Restrict the product source to the supported set.
	 *
	 * @param string $value
	 * @return string
	 */
	public function sanitize_product_source( $value ) {
		$value = sanitize_text_field( $value );
		return 'woocommerce' === $value ? 'woocommerce' : 'custom';
	}

	/**
	 * @return bool Whether WooCommerce is active.
	 */
	protected function wc_active() {
		return class_exists( 'WooCommerce' ) && function_exists( 'wc_get_product' );
	}

	/**
	 * Map an incoming request to sanitized DB columns.
	 *
	 * @param \WP_REST_Request $request
	 * @return array
	 */
	protected function prepare_item_for_database( $request ) {
		$schema = $this->get_product_display_schema();
		$bool   = array(
			'primary_tracking',
			'primary_nofollow',
			'secondary_tracking',
			'secondary_nofollow',
			'show_disclosure',
			'default_disclosure',
			'new_tab',
			'status',
		);

		$transient = array( 'style', 'primary_new_url', 'secondary_new_url' );

		$data = array();
		foreach ( $schema as $field => $args ) {
			if ( in_array( $field, $transient, true ) ) {
				continue; // not columns: style -> JSON below; *_new_url -> link creation.
			}
			$value = $request->get_param( $field );
			if ( null === $value ) {
				continue;
			}
			if ( in_array( $field, $bool, true ) ) {
				$data[ $field ] = rest_sanitize_boolean( $value ) ? 1 : 0;
			} elseif ( in_array( $field, array( 'product_image_id', 'primary_link_id', 'secondary_link_id', 'wc_product_id' ), true ) ) {
				// Allow clearing the relation by sending 0/empty.
				$data[ $field ] = absint( $value ) > 0 ? absint( $value ) : null;
			} else {
				$data[ $field ] = $value;
			}
		}

		$style = $request->get_param( 'style' );
		if ( null !== $style ) {
			$data['style'] = wp_json_encode( self::sanitize_style( (array) $style ) );
		}

		return $data;
	}

	/**
	 * "Create New": when a CTA provides a raw URL, create a BetterLinks short link
	 * from it and point that CTA's link_id at the new link.
	 *
	 * @param \WP_REST_Request $request
	 * @param array            $data
	 * @return array
	 */
	protected function apply_cta_new_links( $request, $data ) {
		$title = (string) $request->get_param( 'product_name' );

		foreach ( array( 'primary', 'secondary' ) as $which ) {
			$url = trim( (string) $request->get_param( $which . '_new_url' ) );
			if ( '' === $url ) {
				continue;
			}
			$link_id = \BetterLinksPro\Frontend\ProductDisplay\LinkFactory::create( $url, $title );
			if ( $link_id ) {
				$data[ $which . '_link_id' ] = $link_id;
			}
		}

		return $data;
	}

	/**
	 * Whitelist + sanitize the per-card style overrides.
	 * Color values keep their raw CSS string (hex/rgba); size values are integers.
	 *
	 * @param array $style
	 * @return array
	 */
	public static function sanitize_style( $style ) {
		$color_keys = array(
			'cardBg',
			'cardColor',
			'cardBorderColor',
			'priceRegularColor',
			'priceSaleColor',
			'badgeBg',
			'badgeColor',
			'primaryBg',
			'primaryColor',
			'primaryHoverBg',
			'primaryHoverColor',
			'secondaryBg',
			'secondaryColor',
			'secondaryHoverBg',
			'secondaryHoverColor',
		);
		$size_keys = array( 'cardBorderWidth', 'cardRadius', 'cardPadding', 'badgeRadius', 'btnRadius' );

		$clean = array();
		foreach ( $color_keys as $key ) {
			if ( isset( $style[ $key ] ) && '' !== $style[ $key ] ) {
				$color = \BetterLinksPro\Helper::sanitize_css_color( $style[ $key ] );
				if ( '' !== $color ) {
					$clean[ $key ] = $color;
				}
			}
		}
		foreach ( $size_keys as $key ) {
			if ( isset( $style[ $key ] ) && '' !== $style[ $key ] && null !== $style[ $key ] ) {
				$clean[ $key ] = max( 0, min( 100, (int) $style[ $key ] ) );
			}
		}
		return $clean;
	}

	/**
	 * GET list.
	 *
	 * @param \WP_REST_Request $request
	 * @return \WP_REST_Response
	 */
	public function get_items( $request ) {
		$displays = self::get_product_displays();
		$displays = array_map( array( $this, 'append_shortcode' ), $displays );
		return new \WP_REST_Response( $displays, 200 );
	}

	/**
	 * GET one.
	 *
	 * @param \WP_REST_Request $request
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function get_item( $request ) {
		$display = self::get_product_display( $request['id'] );
		if ( null === $display ) {
			return new \WP_Error( 'betterlinks_pd_not_found', __( 'Card not found.', 'betterlinks-pro' ), array( 'status' => 404 ) );
		}
		return new \WP_REST_Response( $this->append_shortcode( $display ), 200 );
	}

	/**
	 * POST create.
	 *
	 * @param \WP_REST_Request $request
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function create_item( $request ) {
		$data = $this->prepare_item_for_database( $request );
		$data = $this->apply_cta_new_links( $request, $data );

		if ( empty( $data['product_name'] ) ) {
			return new \WP_Error( 'betterlinks_pd_invalid', __( 'Product name is required.', 'betterlinks-pro' ), array( 'status' => 400 ) );
		}

		$id = self::insert_product_display( $data );
		if ( ! $id ) {
			return new \WP_Error( 'betterlinks_pd_insert_failed', __( 'We couldn’t create this card. Please try again.', 'betterlinks-pro' ), array( 'status' => 500 ) );
		}

		$display = $this->append_shortcode( self::get_product_display( $id ) );
		return new \WP_REST_Response(
			array(
				'success' => true,
				'message' => esc_html__( 'Card created.', 'betterlinks-pro' ),
				'data'    => $display,
			),
			201
		);
	}

	/**
	 * PUT/PATCH update.
	 *
	 * @param \WP_REST_Request $request
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function update_item( $request ) {
		$id = absint( $request['id'] );
		if ( null === self::get_product_display( $id ) ) {
			return new \WP_Error( 'betterlinks_pd_not_found', __( 'Card not found.', 'betterlinks-pro' ), array( 'status' => 404 ) );
		}

		$data    = $this->prepare_item_for_database( $request );
		$data    = $this->apply_cta_new_links( $request, $data );
		$updated = self::update_product_display( $id, $data );
		if ( false === $updated ) {
			return new \WP_Error( 'betterlinks_pd_update_failed', __( 'We couldn’t update this card (database error).', 'betterlinks-pro' ), array( 'status' => 500 ) );
		}

		$display = $this->append_shortcode( self::get_product_display( $id ) );
		return new \WP_REST_Response(
			array(
				'success' => true,
				'message' => esc_html__( 'Card updated.', 'betterlinks-pro' ),
				'data'    => $display,
			),
			200
		);
	}

	/**
	 * DELETE.
	 *
	 * @param \WP_REST_Request $request
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function delete_item( $request ) {
		$id = absint( $request['id'] );
		if ( null === self::get_product_display( $id ) ) {
			return new \WP_Error( 'betterlinks_pd_not_found', __( 'Card not found.', 'betterlinks-pro' ), array( 'status' => 404 ) );
		}

		self::delete_product_display( $id );

		return new \WP_REST_Response(
			array(
				'success' => true,
				'message' => esc_html__( 'Card deleted.', 'betterlinks-pro' ),
				'id'      => $id,
			),
			200
		);
	}

	/**
	 * Attach the ready-to-copy shortcode string to a display payload.
	 *
	 * @param array $display
	 * @return array
	 */
	protected function append_shortcode( $display ) {
		if ( is_array( $display ) && isset( $display['ID'] ) ) {
			$display['shortcode'] = sprintf( '[betterlinks_product_display id="%d"]', (int) $display['ID'] );
		}
		return $display;
	}

	/* ------------------------------------------------------------------ *
	 * WooCommerce integration                                            *
	 * ------------------------------------------------------------------ */

	/**
	 * Search published WooCommerce products (and their variations) by term.
	 *
	 * Performance: only a small page of parent products is fetched (default 10,
	 * by IDs) — never the whole catalogue — and the variation expansion is capped
	 * so a store with 50k products / many variations stays responsive.
	 *
	 * @param \WP_REST_Request $request
	 * @return \WP_REST_Response
	 */
	public function search_wc_products( $request ) {
		if ( ! $this->wc_active() ) {
			return new \WP_REST_Response( array(), 200 );
		}

		$term  = sanitize_text_field( (string) $request->get_param( 'term' ) );
		$limit = absint( $request->get_param( 'limit' ) );
		$limit = $limit > 0 ? min( 20, $limit ) : 10;

		// While searching, over-fetch a little so our own relevance ranking has
		// enough candidates to surface the exact match even if WP buries it.
		$query_args = array(
			'post_type'        => 'product',
			'post_status'      => 'publish',
			'posts_per_page'   => '' !== $term ? max( $limit, 20 ) : $limit,
			'suppress_filters' => false,
			'no_found_rows'    => true,
			'fields'           => 'ids',
		);
		if ( '' !== $term ) {
			$query_args['s'] = $term;
		} else {
			// Default list = the most recent products.
			$query_args['orderby'] = 'date';
			$query_args['order']   = 'DESC';
		}

		$ids      = get_posts( $query_args );
		$out      = array();
		$max_opts = 50; // hard ceiling so variable products can't explode the list.

		$lower  = static function ( $s ) {
			return function_exists( 'mb_strtolower' ) ? mb_strtolower( (string) $s ) : strtolower( (string) $s );
		};
		// Decode entities (e.g. "EverCool&trade;" → "EverCool™") for display + matching.
		$decode = static function ( $s ) {
			return trim( html_entity_decode( wp_strip_all_tags( (string) $s ), ENT_QUOTES, 'UTF-8' ) );
		};
		$needle = '' !== $term ? $lower( $term ) : '';

		// Relevance score: lower is better. Exact title wins, then prefix, phrase,
		// all-words, anything else.
		$score = static function ( $title ) use ( $needle, $lower ) {
			if ( '' === $needle ) {
				return 5;
			}
			$t = $lower( $title );
			if ( $t === $needle ) {
				return 0;
			}
			if ( 0 === strpos( $t, $needle ) ) {
				return 1;
			}
			if ( false !== strpos( $t, $needle ) ) {
				return 2;
			}
			$words = preg_split( '/\s+/', $needle, -1, PREG_SPLIT_NO_EMPTY );
			foreach ( $words as $w ) {
				if ( false === strpos( $t, $w ) ) {
					return 4;
				}
			}
			return 3;
		};

		// Build a ranked list of parent products (decorated with an index so the
		// sort is stable on PHP versions without a stable usort).
		$ranked = array();
		foreach ( $ids as $i => $pid ) {
			$product = wc_get_product( $pid );
			if ( ! $product ) {
				continue;
			}
			$name     = $decode( $product->get_name() );
			$ranked[] = array(
				'product' => $product,
				'name'    => $name,
				'score'   => $score( $name ),
				'i'       => $i,
			);
		}

		if ( '' !== $term ) {
			usort(
				$ranked,
				static function ( $a, $b ) {
					if ( $a['score'] !== $b['score'] ) {
						return $a['score'] - $b['score'];
					}
					if ( strlen( $a['name'] ) !== strlen( $b['name'] ) ) {
						return strlen( $a['name'] ) - strlen( $b['name'] );
					}
					return $a['i'] - $b['i'];
				}
			);
			$ranked = array_slice( $ranked, 0, $limit );
		}

		foreach ( $ranked as $row ) {
			$product   = $row['product'];
			$image_id  = $product->get_image_id();
			$image_url = $image_id ? (string) wp_get_attachment_image_url( $image_id, 'thumbnail' ) : '';

			$out[] = array(
				'id'        => $product->get_id(),
				'title'     => $row['name'],
				'type'      => $product->get_type(),
				'image_url' => $image_url,
			);

			// Expand a variable product's variations as individually selectable
			// options ONLY while searching — and only the variations whose label
			// actually matches the term, so a parent that merely matched on its
			// description doesn't flood the list with unrelated variations.
			if ( '' !== $term && $product->is_type( 'variable' ) ) {
				foreach ( $product->get_children() as $vid ) {
					if ( count( $out ) >= $max_opts ) {
						break;
					}
					$variation = wc_get_product( $vid );
					if ( ! $variation || ! $variation->variation_is_visible() ) {
						continue;
					}
					$attrs = wc_get_formatted_variation( $variation, true );
					$label = $row['name'] . ( $attrs ? ' – ' . $decode( $attrs ) : '' );

					if ( false === strpos( $lower( $label ), $needle ) ) {
						continue;
					}

					$vimg_id = $variation->get_image_id();
					$out[]   = array(
						'id'        => $variation->get_id(),
						'title'     => $label,
						'type'      => 'variation',
						'image_url' => $vimg_id ? (string) wp_get_attachment_image_url( $vimg_id, 'thumbnail' ) : $image_url,
					);
				}
			}

			if ( count( $out ) >= $max_opts ) {
				break;
			}
		}

		return new \WP_REST_Response( $out, 200 );
	}

	/**
	 * Return a single WooCommerce product (or variation), shaped for the form.
	 *
	 * @param \WP_REST_Request $request
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function get_wc_product( $request ) {
		if ( ! $this->wc_active() ) {
			return new \WP_Error( 'betterlinks_wc_inactive', __( 'WooCommerce is not active.', 'betterlinks-pro' ), array( 'status' => 400 ) );
		}

		$product = wc_get_product( absint( $request['id'] ) );
		if ( ! $product ) {
			return new \WP_Error( 'betterlinks_wc_not_found', __( 'Product not found.', 'betterlinks-pro' ), array( 'status' => 404 ) );
		}

		return new \WP_REST_Response( $this->shape_wc_product( $product ), 200 );
	}

	/**
	 * Shape a WC product/variation into the editor form payload.
	 *
	 * @param \WC_Product $product
	 * @return array
	 */
	protected function shape_wc_product( $product ) {
		$is_variation = $product->is_type( 'variation' );
		$parent       = $is_variation ? wc_get_product( $product->get_parent_id() ) : null;

		// Image: prefer the variation's own image, else fall back to the parent.
		$image_id = $product->get_image_id();
		if ( ! $image_id && $parent ) {
			$image_id = $parent->get_image_id();
		}
		$image_url = $image_id ? (string) wp_get_attachment_image_url( $image_id, 'medium' ) : (string) wc_placeholder_img_src( 'medium' );

		// Format prices with the store currency (e.g. "$120.00"); empty when unset.
		$fmt = static function ( $price ) {
			return '' === $price || null === $price ? '' : html_entity_decode( wp_strip_all_tags( wc_price( $price ) ) );
		};

		// Name — variations get their attributes appended for clarity. Decode HTML
		// entities (e.g. "EverCool&trade;" → "EverCool™") for clean display.
		$decode = static function ( $s ) {
			return trim( html_entity_decode( wp_strip_all_tags( (string) $s ), ENT_QUOTES, 'UTF-8' ) );
		};
		$name = $decode( $product->get_name() );
		if ( $is_variation ) {
			$attrs = wc_get_formatted_variation( $product, true );
			$name  = $decode( $parent ? $parent->get_name() : $product->get_name() ) . ( $attrs ? ' – ' . $decode( $attrs ) : '' );
		}

		// Description — fall back to the parent for variations / to long description.
		$desc_src    = $is_variation && $parent ? $parent : $product;
		$description = $desc_src->get_short_description();
		if ( '' === trim( (string) $description ) ) {
			$description = $desc_src->get_description();
		}

		// Badge — surface a product's on-sale / featured status as the card badge.
		$badge = '';
		if ( $product->is_on_sale() ) {
			$badge = __( 'Sale', 'betterlinks-pro' );
		} elseif ( ! $is_variation && $product->is_featured() ) {
			$badge = __( 'Featured', 'betterlinks-pro' );
		}

		$permalink_id = $is_variation ? $product->get_parent_id() : $product->get_id();

		return array(
			'id'              => $product->get_id(),
			'type'            => $product->get_type(),
			'title'           => $name,
			'image_id'        => $image_id ? (int) $image_id : 0,
			'image_url'       => $image_url,
			'regular_price'   => $fmt( $product->get_regular_price() ),
			'sale_price'      => $fmt( $product->get_sale_price() ),
			'permalink'       => (string) get_permalink( $permalink_id ),
			'add_to_cart_url' => $this->wc_add_to_cart_url( $product ),
			'badge'           => $badge,
			'description'     => wp_kses_post( (string) $description ),
		);
	}

	/**
	 * Build an ABSOLUTE add-to-cart URL.
	 *
	 * WooCommerce's WC_Product::add_to_cart_url() returns a query-only, RELATIVE
	 * URL (e.g. "?add-to-cart=123") for simple products. Called inside a REST
	 * request it would resolve against the REST endpoint, producing a broken link
	 * like "/wp-json/.../wc/product/123?add-to-cart=123". Rebuild it absolutely.
	 *
	 * @param \WC_Product $product
	 * @return string
	 */
	protected function wc_add_to_cart_url( $product ) {
		$url = method_exists( $product, 'add_to_cart_url' ) ? (string) $product->add_to_cart_url() : '';

		// External / variable / grouped products already return an absolute URL.
		if ( '' !== $url && preg_match( '#^https?://#i', $url ) ) {
			return esc_url_raw( $url );
		}

		// Variations don't have a reliable one-click cart URL → link to the product page.
		if ( $product->is_type( 'variation' ) ) {
			return esc_url_raw( (string) get_permalink( $product->get_parent_id() ) );
		}

		$permalink = (string) get_permalink( $product->get_id() );
		$base      = '' !== $permalink ? $permalink : home_url( '/' );

		if ( $product->is_purchasable() && $product->is_in_stock() ) {
			return esc_url_raw( add_query_arg( 'add-to-cart', $product->get_id(), $base ) );
		}

		return esc_url_raw( $base );
	}

	/* ------------------------------------------------------------------ *
	 * Permission callbacks (reuse the existing BetterLinks role filters). *
	 * ------------------------------------------------------------------ */

	// Promo Cards access is gated by its own Role Management capability
	// (`managePromoCards`); admins always pass (handled inside current_user_can_do).
	protected function current_user_can_manage_promo_cards() {
		$user            = wp_get_current_user();
		$user_permission = json_decode( get_option( BETTERLINKS_PRO_ROLE_PERMISSON_OPTION_NAME, '{}' ), true );
		return \BetterLinksPro\Helper::current_user_can_do( 'managePromoCards', $user, $user_permission );
	}

	public function get_items_permissions_check( $request ) {
		return $this->current_user_can_manage_promo_cards();
	}

	public function create_item_permissions_check( $request ) {
		return $this->current_user_can_manage_promo_cards();
	}

	public function update_item_permissions_check( $request ) {
		return $this->current_user_can_manage_promo_cards();
	}
}
