<?php

namespace BetterLinksPro\API;
if ( ! defined( 'ABSPATH' ) ) { exit; }

use BetterLinksPro\Services\CountryDetectionService;

/**
 * Geolocation REST API (BetterLinks Pro)
 *
 * Backend fallback for frontend geolocation detection, and per-IP lookups for the
 * analytics click log. Registered by \BetterLinksPro\API only when the free plugin
 * no longer ships its own copy.
 */
class Geolocation {

	private $namespace = BETTERLINKS_PLUGIN_SLUG . '/v1';

	/**
	 * Register the routes for geolocation detection
	 */
	public function register_routes() {
		// Endpoint to fetch country for a specific IP (for backward compatibility).
		// Authenticated only: it takes an ARBITRARY ip, so leaving it open turned every
		// site into a free IP->country lookup proxy that burned the upstream API quota
		// and wrote one transient per probed IP. Its only callers are the admin
		// analytics country backfill paths, which already send a REST nonce.
		register_rest_route(
			$this->namespace,
			'/geolocation/fetch-by-ip',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'fetch_country_by_ip' ),
					'permission_callback' => array( $this, 'fetch_by_ip_permissions_check' ),
					'args'                => array(
						'ip' => array(
							'required'          => true,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						),
					),
				),
			)
		);
	}

	/**
	 * Only users who can see analytics may resolve an arbitrary IP.
	 *
	 * Mirrors the permission filter used by the clicks/analytics endpoints so Pro's
	 * role matrix keeps working for non-admin roles that were granted analytics access.
	 *
	 * @return bool
	 */
	public function fetch_by_ip_permissions_check() {
		return (bool) apply_filters( 'betterlinks/api/analytics_items_permissions_check', current_user_can( 'manage_options' ) );
	}

	/**
	 * Fetch country data for a specific IP address
	 *
	 * Used for backward compatibility to fetch country for existing clicks
	 *
	 * @param \WP_REST_Request $request Full data about the request.
	 * @return \WP_REST_Response
	 */
	public function fetch_country_by_ip( $request ) {


		$ip = $request->get_param( 'ip' );

		if ( ! $ip || ! filter_var( $ip, FILTER_VALIDATE_IP ) ) {
			return new \WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Invalid IP address',
					'data'    => null,
				),
				400
			);
		}

		$country_data = CountryDetectionService::get_country_by_ip( $ip );

		if ( $country_data ) {
			// Get or create country record and include country_id in response
			$country_id = CountryDetectionService::get_or_create_country_id(
				$country_data['country_code'],
				$country_data['country_name']
			);

			$response_data = $country_data;
			if ( $country_id ) {
				$response_data['country_id'] = $country_id;
			}

			return new \WP_REST_Response(
				array(
					'success' => true,
					'message' => 'Country detected successfully',
					'data'    => $response_data,
				),
				200
			);
		}

		return new \WP_REST_Response(
			array(
				'success' => false,
				'message' => 'Could not detect country for this IP',
				'data'    => null,
			),
			404
		);
	}
}

