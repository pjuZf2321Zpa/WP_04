<?php
namespace BetterLinksPro\API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use BetterLinksPro\Traits\ProductDisplay as ProductDisplayTrait;

/**
 * REST controller for Product Display Groups.
 *
 * Routes (namespace: betterlinks-pro/v1):
 *   GET    /product-groups            list
 *   POST   /product-groups            create
 *   GET    /product-groups/{id}       read
 *   PUT    /product-groups/{id}       update
 *   DELETE /product-groups/{id}       delete
 */
class ProductGroup extends \WP_REST_Controller {

	use ProductDisplayTrait;

	public function __construct() {
		$this->namespace = BETTERLINKS_PRO_PLUGIN_SLUG . '/v1';
		$this->rest_base = 'product-groups';
	}

	public function register_routes() {
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base,
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_items' ),
					'permission_callback' => array( $this, 'get_items_permissions_check' ),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_item' ),
					'permission_callback' => array( $this, 'create_item_permissions_check' ),
					'args'                => $this->get_group_schema(),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/(?P<id>[\d]+)',
			array(
				'args' => array(
					'id' => array(
						'description' => __( 'Unique identifier for the card group.', 'betterlinks-pro' ),
						'type'        => 'integer',
					),
				),
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_item' ),
					'permission_callback' => array( $this, 'get_items_permissions_check' ),
				),
				array(
					'methods'             => \WP_REST_Server::EDITABLE,
					'callback'            => array( $this, 'update_item' ),
					'permission_callback' => array( $this, 'update_item_permissions_check' ),
					'args'                => $this->get_group_schema(),
				),
				array(
					'methods'             => \WP_REST_Server::DELETABLE,
					'callback'            => array( $this, 'delete_item' ),
					'permission_callback' => array( $this, 'update_item_permissions_check' ),
				),
			)
		);
	}

	public function get_group_schema() {
		return array(
			'group_title' => array(
				'type'              => 'string',
				'required'          => true,
				'sanitize_callback' => 'sanitize_text_field',
			),
			'group_type'  => array(
				'type'              => 'string',
				'default'           => 'grid',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'columns'     => array(
				'type'              => 'integer',
				'default'           => 2,
				'sanitize_callback' => 'absint',
			),
			'display_ids' => array(
				'type'    => 'array',
				'items'   => array( 'type' => 'integer' ),
				'default' => array(),
			),
			'status'      => array( 'type' => 'boolean' ),
		);
	}

	protected function prepare_group_for_database( $request ) {
		return array(
			'group_title' => $request->get_param( 'group_title' ),
			'group_type'  => $request->get_param( 'group_type' ),
			'columns'     => $request->get_param( 'columns' ),
			'display_ids' => (array) $request->get_param( 'display_ids' ),
			'status'      => null === $request->get_param( 'status' ) ? true : rest_sanitize_boolean( $request->get_param( 'status' ) ),
		);
	}

	public function get_items( $request ) {
		$groups = array_map( array( $this, 'append_shortcode' ), self::get_product_groups() );
		return new \WP_REST_Response( $groups, 200 );
	}

	public function get_item( $request ) {
		$group = self::get_product_group( $request['id'] );
		if ( null === $group ) {
			return new \WP_Error( 'betterlinks_pg_not_found', __( 'Card group not found.', 'betterlinks-pro' ), array( 'status' => 404 ) );
		}
		return new \WP_REST_Response( $this->append_shortcode( $group ), 200 );
	}

	public function create_item( $request ) {
		$data = $this->prepare_group_for_database( $request );
		if ( empty( $data['group_title'] ) ) {
			return new \WP_Error( 'betterlinks_pg_invalid', __( 'Please add a group name.', 'betterlinks-pro' ), array( 'status' => 400 ) );
		}

		$id = self::insert_product_group( $data );
		if ( ! $id ) {
			return new \WP_Error( 'betterlinks_pg_insert_failed', __( 'Could not create the group.', 'betterlinks-pro' ), array( 'status' => 500 ) );
		}

		return new \WP_REST_Response(
			array(
				'success' => true,
				'message' => esc_html__( 'Group created.', 'betterlinks-pro' ),
				'data'    => $this->append_shortcode( self::get_product_group( $id ) ),
			),
			201
		);
	}

	public function update_item( $request ) {
		$id = absint( $request['id'] );
		if ( null === self::get_product_group( $id ) ) {
			return new \WP_Error( 'betterlinks_pg_not_found', __( 'Card group not found.', 'betterlinks-pro' ), array( 'status' => 404 ) );
		}

		self::update_product_group( $id, $this->prepare_group_for_database( $request ) );

		return new \WP_REST_Response(
			array(
				'success' => true,
				'message' => esc_html__( 'Group updated.', 'betterlinks-pro' ),
				'data'    => $this->append_shortcode( self::get_product_group( $id ) ),
			),
			200
		);
	}

	public function delete_item( $request ) {
		$id = absint( $request['id'] );
		if ( null === self::get_product_group( $id ) ) {
			return new \WP_Error( 'betterlinks_pg_not_found', __( 'Card group not found.', 'betterlinks-pro' ), array( 'status' => 404 ) );
		}

		self::delete_product_group( $id );

		return new \WP_REST_Response(
			array(
				'success' => true,
				'message' => esc_html__( 'Group deleted.', 'betterlinks-pro' ),
				'id'      => $id,
			),
			200
		);
	}

	protected function append_shortcode( $group ) {
		if ( is_array( $group ) && isset( $group['ID'] ) ) {
			$group['shortcode'] = sprintf( '[betterlinks_product_display type="group" id="%d"]', (int) $group['ID'] );
		}
		return $group;
	}

	// Promo Card Groups share the Promo Cards Role Management capability
	// (`managePromoCards`); admins always pass (handled inside current_user_can_do).
	protected function current_user_can_manage_promo_cards() {
		$user            = wp_get_current_user();
		$user_permission = json_decode( get_option( BETTERLINKS_PRO_ROLE_PERMISSON_OPTION_NAME, '{}' ), true );
		return \BetterLinksPro\Helper::current_user_can_do( 'managePromoCards', $user, $user_permission );
	}

	public function get_items_permissions_check( $request ) {
		return $this->current_user_can_manage_promo_cards();
	}

	public function create_item_permissions_check( $request ) {
		return $this->current_user_can_manage_promo_cards();
	}

	public function update_item_permissions_check( $request ) {
		return $this->current_user_can_manage_promo_cards();
	}
}
