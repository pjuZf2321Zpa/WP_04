<?php

namespace BetterLinksPro\API;
if ( ! defined( 'ABSPATH' ) ) { exit; }

use BetterLinks\API\Controller;
use BetterLinksPro\Traits\ArgumentSchema;

class Keywords extends Controller
{
    use ArgumentSchema;
    use \BetterLinksPro\Traits\Keywords;

    /**
     * Register the routes for the objects of the controller.
     */
    public function register_routes()
    {
        $endpoint = '/keywords/';
        register_rest_route($this->namespace, $endpoint, [
            [
                'methods' => \WP_REST_Server::READABLE,
                'callback' => [$this, 'get_items'],
                'permission_callback' => [$this, 'permissions_check'],
                'args' => $this->get_keywords_schema(),
            ],
        ]);

        register_rest_route($this->namespace, $endpoint, [
            [
                'methods' => \WP_REST_Server::CREATABLE,
                'callback' => [$this, 'create_item'],
                'permission_callback' => [$this, 'permissions_check'],
                'args' => $this->get_keywords_schema(),
            ],
        ]);

        // Export endpoint
        register_rest_route($this->namespace, $endpoint . 'export', [
            [
                'methods' => \WP_REST_Server::READABLE,
                'callback' => [$this, 'export_keywords'],
                'permission_callback' => [$this, 'permissions_check'],
            ],
        ]);

        // Import endpoint
        register_rest_route($this->namespace, $endpoint . 'import', [
            [
                'methods' => \WP_REST_Server::CREATABLE,
                'callback' => [$this, 'import_keywords'],
                'permission_callback' => [$this, 'permissions_check'],
            ],
        ]);

        register_rest_route(
            $this->namespace,
            $endpoint . '(?P<id>[\d]+)',
            array(
                'args'   => array(
                    'id' => array(
                        'description' => __('Unique identifier for the object.', 'betterlinks-pro'),
                        'type'        => 'integer',
                    ),
                ),
                array(
                    'methods'             => \WP_REST_Server::READABLE,
                    'callback'            => array($this, 'get_item'),
                    'permission_callback' => [$this, 'permissions_check'],
                    'args' => $this->get_keywords_schema(),
                ),
                array(
                    'methods'             => \WP_REST_Server::EDITABLE,
                    'callback'            => array($this, 'update_item'),
                    'permission_callback' => [$this, 'permissions_check'],
                    'args' => $this->get_keywords_schema(),
                ),
                array(
                    'methods'             => \WP_REST_Server::DELETABLE,
                    'callback'            => array($this, 'delete_item'),
                    'permission_callback' => [$this, 'permissions_check'],
                    'args'                => array(
                        'force' => array(
                            'type'        => 'boolean',
                            'default'     => false,
                            'description' => __('Whether to bypass Trash and force deletion.', 'betterlinks-pro'),
                        ),
                    ),
                ),
                // 'schema' => array( $this, 'get_public_item_schema' ),
            )
        );
    }

    /**
     * Get keywords
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Request
     */
    public function get_items($request)
    {
        $results = \BetterLinks\Helper::get_keywords();
        return new \WP_REST_Response(
            [
                'success' => true,
                'data' => $results,
            ],
            200
        );
    }

    public function get_item($request)
    {
        return new \WP_REST_Response(
            [
                'success' => true,
                'data' => [],
            ],
            200
        );
    }

    /**
     * Create OR Update keywords meta
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Request
     */
    public function create_item($request)
    {
        $request = $request->get_params();
        $params = $request['params'];
        $data = $this->prepare_keyword_item_for_db($params);
        $link_id = (isset($data['link_id']) ? $data['link_id'] : 0);
        $is_insert = \BetterLinks\Helper::add_link_meta($link_id, 'keywords', $data);
        if ($is_insert) {
            return new \WP_REST_Response(
                [
                    'success' => true,
                    'data' => $data,
                ],
                200
            );
        }
        return new \WP_REST_Response(
            [
                'success' => false,
                'data' => [],
            ],
            200
        );
    }

    /**
     * Create OR Update keywords
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Request
     */
    public function update_item($request)
    {
        $request = $request->get_params();
        $params = $request['params'];
        $old_link_id = absint(isset($params['oldChooseLink']) ? $params['oldChooseLink'] : 0);
        $old_keywords = (isset($params['oldKeywords']) ? $params['oldKeywords'] : "");
        $data = $this->prepare_keyword_item_for_db($params);
        $link_id = (isset($data['link_id']) ? $data['link_id'] : 0);
        $is_update = false;
        $is_update = \BetterLinks\Helper::update_link_meta($link_id, 'keywords', $data, $old_keywords, $old_link_id);
        if ($is_update) {
            return new \WP_REST_Response(
                [
                    'success' => true,
                    'data' => array_merge($data, [
                        'old_link_id' => $old_link_id,
                        'old_keywords' => $old_keywords
                    ]),
                ],
                200
            );
        }
        return new \WP_REST_Response(
            [
                'success' => false,
                'data' => [],
            ],
            200
        );
    }
    /**
     * Delete keywords
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Request
     */
    public function delete_item($request)
    {
        $request = $request->get_params();
        $id = (isset($request['id']) ? intval(sanitize_text_field($request['id'])) : 0);
        $is_delete = \BetterLinks\Helper::delete_link_meta($id, 'keywords');
        return new \WP_REST_Response(
            [
                'success' => $is_delete,
            ],
            200
        );
    }

    /**
     * Export keywords
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Request
     */
    public function export_keywords($request)
    {
        $results = \BetterLinks\Helper::get_keywords_for_export();
        return new \WP_REST_Response(
            [
                'success' => true,
                'data' => $results,
                'message' => __('Keywords exported successfully.', 'betterlinks-pro'),
            ],
            200
        );
    }

    /**
     * Import keywords
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Request
     */
    public function import_keywords($request)
    {
        $request = $request->get_params();
        $params = $request['params'];
        $csv_data = isset($params['csv_data']) ? $params['csv_data'] : [];
        $rewrite_existing = isset($params['rewrite_existing']) ? (bool)$params['rewrite_existing'] : false;

        if (empty($csv_data) || !is_array($csv_data)) {
            return new \WP_REST_Response(
                [
                    'success' => false,
                    'message' => __('No valid data provided for import.', 'betterlinks-pro'),
                ],
                400
            );
        }

        $imported = 0;
        $skipped = 0;
        $errors = 0;
        $error_messages = [];

        foreach ($csv_data as $item) {
            try {
                // Validate required fields
                // Normalize shortUrl / short_url key
                $short_url_value = ! empty( $item['short_url'] ) ? $item['short_url'] : ( ! empty( $item['shortUrl'] ) ? $item['shortUrl'] : '' );

                if ( empty( $item['keywords'] ) || ( empty( $item['chooseLink'] ) && empty( $short_url_value ) ) ) {
                    $skipped++;
                    continue;
                }

                // Resolve link identifier (accept numeric ID, short_url slug, or full URL)
                $link_identifier = '';
                if ( ! empty( $item['chooseLink'] ) ) {
                    $link_identifier = sanitize_text_field( $item['chooseLink'] );
                } elseif ( ! empty( $short_url_value ) ) {
                    $link_identifier = sanitize_text_field( $short_url_value );
                }

                $link_exists = false;
                $link_id = 0;

                if ( is_numeric( $link_identifier ) ) {
                    $link_exists = \BetterLinks\Helper::get_link_by_ID( intval( $link_identifier ) );
                    $link_id = intval( $link_identifier );
                } else {
                    // If full URL provided, extract slug portion
                    $slug = $link_identifier;
                    if ( filter_var( $link_identifier, FILTER_VALIDATE_URL ) ) {
                        $path = wp_parse_url( $link_identifier, PHP_URL_PATH );
                        $slug = trim( (string) $path, '/');
                    }

                    // Try exact match first (handles prefixed slugs like "go/my-link")
                    $found = \BetterLinks\Helper::get_link_by_short_url( $slug );

                    // If not found, try with prefix prepended (user may have entered "my-link" but DB stores "go/my-link")
                    if ( ( ! $found || ! is_array( $found ) || empty( $found ) ) && strpos( $slug, '/' ) === false ) {
                        $helper = new \BetterLinks\Helper();
                        $prefix = $helper->get_betterlinks_prefix();
                        if ( ! empty( $prefix ) ) {
                            $prefixed_slug = rtrim( $prefix, '/' ) . '/' . $slug;
                            $found = \BetterLinks\Helper::get_link_by_short_url( $prefixed_slug );
                        }
                    }

                    // If still not found and slug has a prefix, try without prefix
                    if ( ( ! $found || ! is_array( $found ) || empty( $found ) ) && strpos( $slug, '/' ) !== false ) {
                        $slug_without_prefix = substr( $slug, strpos( $slug, '/' ) + 1 );
                        $found = \BetterLinks\Helper::get_link_by_short_url( $slug_without_prefix );
                    }

                    if ( $found && is_array( $found ) && ! empty( $found ) ) {
                        $first = current( $found );
                        $link_exists = $first;
                        $link_id = isset( $first['ID'] ) ? intval( $first['ID'] ) : 0;
                    } else {
                        $link_exists = false;
                    }
                }

                if ( ! $link_exists || empty( $link_id ) ) {
                    $errors++;
                    // Show the original identifier in the message for debugging
                    /* translators: %d: numeric value; %s: text value. */
                    $error_messages[] = is_numeric( $link_identifier ) ? sprintf( __('Link ID %d does not exist.', 'betterlinks-pro'), $link_identifier ) : sprintf( __('Link "%s" does not exist.', 'betterlinks-pro'), $link_identifier );
                    continue;
                }

                // Check if keyword already exists — first by meta_id, then by keyword+link_id match
                $meta_id = ! empty( $item['meta_id'] ) ? absint( $item['meta_id'] ) : 0;
                $keyword_exists = false;
                $existing_meta_id = 0;

                if ( $meta_id > 0 ) {
                    // Check if this specific meta_id exists in the database
                    global $wpdb;
                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
                    $existing_row = $wpdb->get_row(
                        $wpdb->prepare(
                            "SELECT meta_id, link_id FROM {$wpdb->prefix}betterlinkmeta WHERE meta_id = %d AND meta_key = %s",
                            $meta_id,
                            'keywords'
                        ),
                        ARRAY_A
                    );
                    if ( $existing_row ) {
                        $keyword_exists = true;
                        $existing_meta_id = absint( $existing_row['meta_id'] );
                    }
                }

                // Fallback: check by keyword text + link_id match
                if ( ! $keyword_exists ) {
                    $existing_keywords = \BetterLinks\Helper::get_keywords();
                    foreach ( $existing_keywords as $existing ) {
                        $existing_data = is_string( $existing ) ? json_decode( $existing, true ) : $existing;
                        if ( isset( $existing_data['link_id'] ) && $existing_data['link_id'] == $link_id &&
                            strtolower( $existing_data['keywords'] ) == strtolower( $item['keywords'] ) ) {
                            $keyword_exists = true;
                            break;
                        }
                    }
                }

                if ( $keyword_exists && ! $rewrite_existing ) {
                    $skipped++;
                    continue;
                }

                // Prepare data for database
                $data = $this->prepare_keyword_item_for_db( $item );

                if ( $keyword_exists && $rewrite_existing ) {
                    // Update existing keyword
                    if ( $existing_meta_id > 0 ) {
                        // Use direct meta_id update for precise targeting
                        $is_updated = \BetterLinks\Helper::update_link_meta_by_meta_id( $existing_meta_id, $link_id, 'keywords', $data );
                    } else {
                        // Fallback to keyword+link_id matching
                        $is_updated = \BetterLinks\Helper::update_link_meta( $link_id, 'keywords', $data, $item['keywords'], $link_id );
                    }
                    if ( $is_updated ) {
                        $imported++;
                    } else {
                        $errors++;
                        /* translators: %s: text value; %d: numeric value. */
                        $error_messages[] = sprintf( __('Failed to update keyword "%1$s" for link ID %2$d.', 'betterlinks-pro'), $item['keywords'], $link_id );
                    }
                } else {
                    // Add new keyword
                    $is_inserted = \BetterLinks\Helper::add_link_meta( $link_id, 'keywords', $data );
                    if ( $is_inserted ) {
                        $imported++;
                    } else {
                        $errors++;
                        /* translators: %s: text value; %d: numeric value. */
                        $error_messages[] = sprintf( __('Failed to import keyword "%1$s" for link ID %2$d.', 'betterlinks-pro'), $item['keywords'], $link_id );
                    }
                }

            } catch (Exception $e) {
                $errors++;
                $error_messages[] = $e->getMessage();
            }
        }

        $message = sprintf(
            /* translators: %d: numeric value. */
            __('Import completed. Imported: %1$d, Skipped: %2$d, Errors: %3$d', 'betterlinks-pro'),
            $imported,
            $skipped,
            $errors
        );

        return new \WP_REST_Response(
            [
                'success' => true,
                'message' => $message,
                'details' => [
                    'imported' => $imported,
                    'skipped' => $skipped,
                    'errors' => $errors,
                    'error_messages' => $error_messages
                ]
            ],
            200
        );
    }

    /**
     * Check if a given request has access to update a setting
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|bool
     */
    public function permissions_check($request)
    {
        return apply_filters('betterlinkspro/api/manage_autolink_permission_check', current_user_can('manage_options'));
    }
}
