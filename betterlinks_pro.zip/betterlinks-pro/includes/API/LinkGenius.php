<?php
/**
 * AI Link Assistant REST controller.
 *
 * Endpoints (namespace betterlinks-pro/v1):
 *   GET  /link-genius/status      — AI configuration + catalog size.
 *   POST /link-genius/suggestions — semantic, performance-ranked link suggestions.
 *   POST /link-genius/rescue      — cloak a naked/linked URL into a BetterLink.
 *   POST /link-genius/lookup      — batch check which target URLs already exist.
 *
 * @package BetterLinksPro\API
 * @since   2.8.0
 */

namespace BetterLinksPro\API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use BetterLinks\API\Controller;
use BetterLinksPro\Tools\AIClient;
use BetterLinks\Traits\ArgumentSchema;
use BetterLinks\Traits\Links;
use BetterLinksPro\Traits\LinkGenius as LinkGeniusTrait;

class LinkGenius extends Controller {

	use LinkGeniusTrait;
	use ArgumentSchema;
	use Links;

	public function __construct() {
		$this->namespace = BETTERLINKS_PRO_PLUGIN_SLUG . '/v1';
	}

	/**
	 * Register routes.
	 */
	public function register_routes() {
		$base = '/link-genius';

		register_rest_route(
			$this->namespace,
			$base . '/status',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_status' ),
					'permission_callback' => array( $this, 'permissions_check' ),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			$base . '/suggestions',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'get_suggestions' ),
					'permission_callback' => array( $this, 'permissions_check' ),
					'args'                => array(
						'post_id' => array(
							'type'              => 'integer',
							'sanitize_callback' => 'absint',
						),
						'blocks'  => array(
							'type'     => 'array',
							'required' => true,
						),
					),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			$base . '/rescue',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'rescue_link' ),
					'permission_callback' => array( $this, 'permissions_check' ),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			$base . '/lookup',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'lookup_targets' ),
					'permission_callback' => array( $this, 'permissions_check' ),
				),
			)
		);
	}

	/**
	 * POST /link-genius/lookup
	 *
	 * Given a batch of target URLs, return the ones that already exist as a
	 * BetterLink — a single query so the editor can offer "reuse" instead of
	 * creating duplicates. Results are keyed by the exact input URL string.
	 */
	public function lookup_targets( $request ) {
		$params = $request->get_json_params();
		if ( empty( $params ) ) {
			$params = $request->get_params();
		}

		$urls = isset( $params['urls'] ) ? (array) $params['urls'] : array();
		if ( empty( $urls ) ) {
			return new \WP_REST_Response( array( 'success' => true, 'data' => array( 'existing' => array() ) ), 200 );
		}

		// Map normalized key → first original input string (dedupe inputs).
		$key_to_input = array();
		foreach ( $urls as $url ) {
			$url = trim( (string) $url );
			if ( '' === $url ) {
				continue;
			}
			$key = $this->normalized_target_key( $url );
			if ( '' !== $key && ! isset( $key_to_input[ $key ] ) ) {
				$key_to_input[ $key ] = $url;
			}
		}

		if ( empty( $key_to_input ) ) {
			return new \WP_REST_Response( array( 'success' => true, 'data' => array( 'existing' => array() ) ), 200 );
		}

		global $wpdb;
		$table        = $wpdb->prefix . 'betterlinks';
		$keys         = array_keys( $key_to_input );
		$placeholders = implode( ',', array_fill( 0, count( $keys ), '%s' ) );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT ID, link_title, short_url, LOWER(TRIM(TRAILING '/' FROM target_url)) AS nkey
				 FROM {$table}
				 WHERE link_status = 'publish'
				 AND LOWER(TRIM(TRAILING '/' FROM target_url)) IN ({$placeholders})",
				$keys
			),
			ARRAY_A
		);

		$found = array();
		if ( ! empty( $rows ) ) {
			foreach ( $rows as $row ) {
				// First match wins per key.
				if ( ! isset( $found[ $row['nkey'] ] ) ) {
					$found[ $row['nkey'] ] = $row;
				}
			}
		}

		$existing = array();
		foreach ( $key_to_input as $key => $input ) {
			if ( isset( $found[ $key ] ) ) {
				$existing[] = array(
					'url'       => $input,
					'link_id'   => (int) $found[ $key ]['ID'],
					'short_url' => $found[ $key ]['short_url'],
					'title'     => $found[ $key ]['link_title'],
				);
			}
		}

		return new \WP_REST_Response(
			array(
				'success' => true,
				'data'    => array( 'existing' => $existing ),
			),
			200
		);
	}

	/**
	 * Whether the free plugin's AI backend (AIClient + its option constant) is present.
	 * When Pro is updated but free isn't, this class/constant can be missing — calling
	 * into it would fatal (HTTP 500), so every endpoint guards on this first and the
	 * editor panel prompts a free-plugin update instead.
	 *
	 * @return bool
	 */
	private function ai_backend_available() {
		// The AI client ships with Pro itself now.
		return class_exists( AIClient::class );
	}

	/**
	 * GET /link-genius/status
	 */
	public function get_status( $request ) {
		// Outdated free plugin: report not-configured cleanly instead of fataling.
		if ( ! $this->ai_backend_available() ) {
			return new \WP_REST_Response(
				array(
					'success' => true,
					'data'    => array(
						'ai_configured'       => false,
						'provider'            => '',
						'model'               => '',
						'links_count'         => 0,
						'free_backend_missing' => true,
					),
				),
				200
			);
		}

		$config  = AIClient::get_config();
		$catalog = $this->get_link_catalog();

		return new \WP_REST_Response(
			array(
				'success' => true,
				'data'    => array(
					'ai_configured' => AIClient::is_configured(),
					'provider'      => $config['provider'],
					'model'         => $config['model'],
					'links_count'   => count( $catalog ),
				),
			),
			200
		);
	}

	/**
	 * POST /link-genius/suggestions
	 */
	public function get_suggestions( $request ) {
		$params  = $request->get_json_params();
		if ( empty( $params ) ) {
			$params = $request->get_params();
		}

		$blocks  = isset( $params['blocks'] ) ? (array) $params['blocks'] : array();
		$post_id = isset( $params['post_id'] ) ? absint( $params['post_id'] ) : 0;

		if ( empty( $blocks ) ) {
			return new \WP_REST_Response(
				array(
					'success' => false,
					'message' => __( 'No content was provided to analyze.', 'betterlinks-pro' ),
				),
				400
			);
		}

		// Outdated free plugin: the AI backend is unavailable — fail cleanly (no 500).
		if ( ! $this->ai_backend_available() ) {
			return new \WP_REST_Response(
				array(
					'success'              => false,
					'free_backend_missing' => true,
					'message'              => __( 'Update the free BetterLinks plugin to use the AI Link Assistant.', 'betterlinks-pro' ),
				),
				400
			);
		}

		if ( ! AIClient::is_configured() ) {
			return new \WP_REST_Response(
				array(
					'success'       => false,
					'ai_configured' => false,
					'message'       => __( 'Add an OpenAI or Gemini API key in BetterLinks → Settings → AI to use AI Link Assistant.', 'betterlinks-pro' ),
				),
				400
			);
		}

		$catalog = $this->get_link_catalog();

		if ( empty( $catalog ) ) {
			return new \WP_REST_Response(
				array(
					'success' => true,
					'data'    => array( 'suggestions' => array() ),
					'message' => __( 'You have no published links yet. Create some BetterLinks first.', 'betterlinks-pro' ),
				),
				200
			);
		}

		$suggestions = $this->generate_genius_suggestions( $blocks, $catalog );

		if ( is_wp_error( $suggestions ) ) {
			return new \WP_REST_Response(
				array(
					'success' => false,
					'message' => $suggestions->get_error_message(),
				),
				502
			);
		}

		// Usage marker (not a settings toggle): the assistant actually ran a suggestion
		// pass over the author's content. Tracked by the free plugin as link_genius_used.
		update_option( 'betterlinks_link_genius_used', true );

		return new \WP_REST_Response(
			array(
				'success' => true,
				'data'    => array( 'suggestions' => $suggestions ),
			),
			200
		);
	}

	/**
	 * POST /link-genius/rescue
	 *
	 * Raw Link Rescue (B3): convert a naked outbound URL found in the content
	 * into a cloaked, tracked BetterLink, auto-suggest a keyword, and return the
	 * data the editor needs to swap the raw URL for the new short link.
	 */
	public function rescue_link( $request ) {
		$params = $request->get_json_params();
		if ( empty( $params ) ) {
			$params = $request->get_params();
		}

		$raw_url = isset( $params['url'] ) ? trim( (string) $params['url'] ) : '';
		$post_id = isset( $params['post_id'] ) ? absint( $params['post_id'] ) : 0;

		if ( '' === $raw_url ) {
			return new \WP_REST_Response(
				array(
					'success' => false,
					'message' => __( 'No URL was provided.', 'betterlinks-pro' ),
				),
				400
			);
		}

		$target_url = $this->normalize_url( $raw_url );
		$host       = $target_url ? wp_parse_url( $target_url, PHP_URL_HOST ) : '';

		if ( ! $target_url || ! $host ) {
			return new \WP_REST_Response(
				array(
					'success' => false,
					'message' => __( 'That does not look like a valid URL.', 'betterlinks-pro' ),
				),
				400
			);
		}

		// Reuse an existing BetterLink for the same target URL instead of duplicating.
		$existing = $this->find_existing_link( $target_url );
		if ( $existing ) {
			return new \WP_REST_Response(
				array(
					'success' => true,
					'data'    => array(
						'link_id'   => (int) $existing['ID'],
						'short_url' => $existing['short_url'],
						'title'     => $existing['link_title'],
						'keyword'   => $existing['link_title'],
						'anchor'    => $raw_url,
						'reused'    => true,
					),
				),
				200
			);
		}

		// Brand / keyword derived from the domain (e.g. uxpilot.ai → uxpilot).
		$host_parts = explode( '.', str_replace( 'www.', '', $host ) );
		$brand      = ! empty( $host_parts[0] ) ? $host_parts[0] : 'link';
		$title      = ucwords( str_replace( array( '-', '_' ), ' ', $brand ) );
		$keyword    = $title;

		// Build a unique short URL using the configured prefix.
		$settings = get_option( BETTERLINKS_LINKS_OPTION_NAME, array() );
		if ( is_string( $settings ) ) {
			$settings = json_decode( $settings, true );
		}
		if ( ! is_array( $settings ) ) {
			$settings = array();
		}

		$prefix    = ! empty( $settings['prefix'] ) ? trailingslashit( $settings['prefix'] ) : '';
		$short_url = $this->ensure_unique_short_url( $prefix . sanitize_title( $brand ) );

		$now = wp_date( 'Y-m-d H:i:s' );

		$link_data = array(
			'link_title'        => $title,
			'link_slug'         => sanitize_title( $brand ),
			'link_note'         => '',
			'target_url'        => $target_url,
			'short_url'         => $short_url,
			'link_author'       => get_current_user_id(),
			'link_date'         => $now,
			'link_date_gmt'     => $now,
			'link_modified'     => $now,
			'link_modified_gmt' => $now,
			'link_status'       => 'publish',
			'redirect_type'     => isset( $settings['redirect_type'] ) ? $settings['redirect_type'] : '307',
			'nofollow'          => isset( $settings['nofollow'] ) ? $settings['nofollow'] : 1,
			'sponsored'         => isset( $settings['sponsored'] ) ? $settings['sponsored'] : 1,
			'track_me'          => isset( $settings['track_me'] ) ? $settings['track_me'] : 1,
			'param_forwarding'  => isset( $settings['param_forwarding'] ) ? $settings['param_forwarding'] : 0,
			'cat_id'            => 1,
		);

		$result = $this->insert_link( $this->sanitize_links_data( $link_data ) );

		if ( ! $result || empty( $result['ID'] ) ) {
			return new \WP_REST_Response(
				array(
					'success' => false,
					'message' => __( 'Could not create the short link. Please try again.', 'betterlinks-pro' ),
				),
				500
			);
		}

		$link_id     = (int) $result['ID'];
		$final_short = ! empty( $result['short_url'] ) ? $result['short_url'] : $short_url;

		// Auto-suggest a keyword for the new link (Auto-Link feature reuse).
		\BetterLinks\Helper::add_link_meta(
			$link_id,
			'keywords',
			array(
				'keywords' => $keyword,
				'link_id'  => $link_id,
			)
		);

		delete_transient( BETTERLINKS_CACHE_LINKS_NAME );

		// Usage marker (not a settings toggle): the user actively converted a raw URL
		// into a tracked link. Tracked by the free plugin as raw_link_rescue_used.
		update_option( 'betterlinks_raw_link_rescue_used', true );

		return new \WP_REST_Response(
			array(
				'success' => true,
				'data'    => array(
					'link_id'   => $link_id,
					'short_url' => $final_short,
					'title'     => $title,
					'keyword'   => $keyword,
					'anchor'    => $raw_url,
				),
			),
			200
		);
	}

	/**
	 * Canonical key for matching a target URL (normalized, lowercased, no trailing slash).
	 *
	 * @param string $raw Raw URL text.
	 *
	 * @return string
	 */
	private function normalized_target_key( $raw ) {
		$url = $this->normalize_url( $raw );
		if ( ! $url ) {
			return '';
		}
		return strtolower( rtrim( $url, '/' ) );
	}

	/**
	 * Find an existing published BetterLink whose target matches the given URL.
	 *
	 * @param string $target_url Normalized target URL.
	 *
	 * @return array|null Row (ID, link_title, short_url) or null.
	 */
	private function find_existing_link( $target_url ) {
		global $wpdb;
		$table = $wpdb->prefix . 'betterlinks';
		$key   = strtolower( rtrim( $target_url, '/' ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT ID, link_title, short_url
				 FROM {$table}
				 WHERE link_status = 'publish'
				 AND LOWER(TRIM(TRAILING '/' FROM target_url)) = %s
				 LIMIT 1",
				$key
			),
			ARRAY_A
		);

		return $row ? $row : null;
	}

	/**
	 * Add an https scheme to scheme-less URLs and validate.
	 *
	 * @param string $raw Raw URL text.
	 *
	 * @return string Sanitized URL, or '' when invalid.
	 */
	private function normalize_url( $raw ) {
		$raw = trim( $raw );
		// Trim trailing sentence punctuation that often clings to URLs.
		$raw = rtrim( $raw, '.,;:!?)]' );

		if ( ! preg_match( '#^https?://#i', $raw ) ) {
			$raw = 'https://' . ltrim( $raw, '/' );
		}

		$url = esc_url_raw( $raw );

		if ( ! $url || ! filter_var( $url, FILTER_VALIDATE_URL ) ) {
			return '';
		}

		return $url;
	}

	/**
	 * Ensure a short URL slug is unique, appending a suffix if needed.
	 *
	 * @param string $short_url Candidate short URL (may include prefix).
	 *
	 * @return string
	 */
	private function ensure_unique_short_url( $short_url ) {
		if ( ! \BetterLinks\Helper::is_exists_short_url( $short_url ) ) {
			return $short_url;
		}
		for ( $i = 1; $i <= 50; $i++ ) {
			$candidate = $short_url . '-' . $i;
			if ( ! \BetterLinks\Helper::is_exists_short_url( $candidate ) ) {
				return $candidate;
			}
		}
		return $short_url . '-' . wp_generate_password( 5, false );
	}

	/**
	 * Permission check — requires the ability to write links.
	 */
	public function permissions_check( $request ) {
		return apply_filters( 'betterlinks/api/links_create_item_permissions_check', current_user_can( 'manage_options' ) );
	}

	/**
	 * Stub methods required by abstract base class.
	 */
	protected function get_items( $request ) {}
	protected function create_item( $request ) {}
	protected function update_item( $request ) {}
	protected function delete_item( $request ) {}
}
