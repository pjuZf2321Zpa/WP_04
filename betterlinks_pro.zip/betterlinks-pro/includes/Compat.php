<?php
namespace BetterLinksPro;
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Compatibility checks between BetterLinks Pro and the free plugin.
 *
 * Call only on or after `betterlinks_loaded`: Pro's file loads before the free
 * plugin's, so free constants are not defined earlier.
 */
final class Compat {

	/**
	 * Whether the free plugin exposes the extension API Pro features plug into.
	 *
	 * Free plugins without it still ship those features themselves; Pro must not
	 * register a second copy (duplicate AJAX handlers, REST routes or click
	 * capture).
	 *
	 * @return bool
	 */
	public static function free_has_extension_api() {
		return defined( 'BETTERLINKS_EXTENSION_API_VERSION' ) && (int) BETTERLINKS_EXTENSION_API_VERSION >= 1;
	}

	/**
	 * Whether the free plugin's block editor sidebar takes Auto-Create Links,
	 * Affiliate Link Disclosure and the Instant Redirect status/expiry from Pro
	 * (extension API 2, free 3.1.5+). Older free plugins ship those panels and
	 * their AJAX handlers themselves.
	 *
	 * @return bool
	 */
	public static function free_has_block_editor_api() {
		return defined( 'BETTERLINKS_EXTENSION_API_VERSION' ) && (int) BETTERLINKS_EXTENSION_API_VERSION >= 2;
	}
}
