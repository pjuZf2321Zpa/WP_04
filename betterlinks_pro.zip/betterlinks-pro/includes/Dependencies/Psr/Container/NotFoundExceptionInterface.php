<?php
// phpcs:ignoreFile -- Vendored third-party code; do not modify.

namespace BetterLinksPro\Dependencies\Psr\Container;

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * No entry was found in the container.
 */
interface NotFoundExceptionInterface extends ContainerExceptionInterface
{
}
