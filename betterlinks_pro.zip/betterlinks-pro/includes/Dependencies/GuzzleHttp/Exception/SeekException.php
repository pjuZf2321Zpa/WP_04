<?php
// phpcs:ignoreFile -- Vendored third-party code; do not modify.
namespace BetterLinksPro\Dependencies\GuzzleHttp\Exception;
if ( ! defined( 'ABSPATH' ) ) { exit; }

use BetterLinksPro\Dependencies\Psr\Http\Message\StreamInterface;

/**
 * Exception thrown when a seek fails on a stream.
 */
class SeekException extends \RuntimeException implements GuzzleException
{
    private $stream;

    public function __construct(StreamInterface $stream, $pos = 0, $msg = '')
    {
        $this->stream = $stream;
        $msg = $msg ?: 'Could not seek the stream to position ' . $pos;
        parent::__construct($msg);
    }

    /**
     * @return StreamInterface
     */
    public function getStream()
    {
        return $this->stream;
    }
}
