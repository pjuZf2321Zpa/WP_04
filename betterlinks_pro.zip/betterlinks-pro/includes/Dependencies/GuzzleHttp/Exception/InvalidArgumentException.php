<?php
// phpcs:ignoreFile -- Vendored third-party code; do not modify.

namespace BetterLinksPro\Dependencies\GuzzleHttp\Exception;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class InvalidArgumentException extends \InvalidArgumentException implements GuzzleException
{
}
