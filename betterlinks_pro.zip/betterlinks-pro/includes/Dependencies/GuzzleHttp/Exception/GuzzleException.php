<?php
// phpcs:ignoreFile -- Vendored third-party code; do not modify.
namespace BetterLinksPro\Dependencies\GuzzleHttp\Exception;
if ( ! defined( 'ABSPATH' ) ) { exit; }

use Throwable;

if (interface_exists(Throwable::class)) {
    interface GuzzleException extends Throwable
    {
    }
} else {
    /**
     * @method string getMessage()
     * @method \Throwable|null getPrevious()
     * @method mixed getCode()
     * @method string getFile()
     * @method int getLine()
     * @method array getTrace()
     * @method string getTraceAsString()
     */
    interface GuzzleException
    {
    }
}
