<?php
// phpcs:ignoreFile -- Vendored third-party code; do not modify.
namespace BetterLinksPro\Dependencies\GuzzleHttp\Exception;
if ( ! defined( 'ABSPATH' ) ) { exit; }

use BetterLinksPro\Dependencies\Psr\Http\Message\RequestInterface;

/**
 * Exception thrown when a connection cannot be established.
 *
 * Note that no response is present for a ConnectException
 */
class ConnectException extends RequestException
{
    public function __construct(
        $message,
        RequestInterface $request,
        \Exception $previous = null,
        array $handlerContext = []
    ) {
        parent::__construct($message, $request, null, $previous, $handlerContext);
    }

    /**
     * @return null
     */
    public function getResponse()
    {
        return null;
    }

    /**
     * @return bool
     */
    public function hasResponse()
    {
        return false;
    }
}
