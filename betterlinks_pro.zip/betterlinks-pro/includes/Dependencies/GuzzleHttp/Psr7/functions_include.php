<?php
// phpcs:ignoreFile -- Vendored third-party code; do not modify.
if ( ! defined( 'ABSPATH' ) ) { exit; }

// Don't redefine the functions if included multiple times.
if (!function_exists('BetterLinksPro\Dependencies\GuzzleHttp\Psr7\str')) {
    require __DIR__ . '/functions.php';
}
