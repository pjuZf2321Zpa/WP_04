<?php
// phpcs:ignoreFile -- Vendored third-party code; do not modify.

namespace BetterLinksPro\Dependencies\GuzzleHttp\Promise;
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Exception thrown when too many errors occur in the some() or any() methods.
 */
class AggregateException extends RejectionException
{
    public function __construct($msg, array $reasons)
    {
        parent::__construct(
            $reasons,
            sprintf('%s; %d rejected promises', $msg, count($reasons))
        );
    }
}
