<?php
// phpcs:ignoreFile -- Vendored third-party code; do not modify.

namespace BetterLinksPro\Dependencies\GuzzleHttp\Promise;
if ( ! defined( 'ABSPATH' ) ) { exit; }

interface TaskQueueInterface
{
    /**
     * Returns true if the queue is empty.
     *
     * @return bool
     */
    public function isEmpty();

    /**
     * Adds a task to the queue that will be executed the next time run is
     * called.
     */
    public function add(callable $task);

    /**
     * Execute all of the pending task in the queue.
     */
    public function run();
}
