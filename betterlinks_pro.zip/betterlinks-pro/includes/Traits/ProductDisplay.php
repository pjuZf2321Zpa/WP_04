<?php
namespace BetterLinksPro\Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Data-access helpers for the Product Display feature.
 *
 * Every method uses prepared statements against the
 * `{$wpdb->prefix}betterlinks_product_display` table.
 */
trait ProductDisplay {

	/**
	 * Fully-qualified product display table name.
	 *
	 * @return string
	 */
	public static function product_display_table() {
		global $wpdb;
		return $wpdb->prefix . 'betterlinks_product_display';
	}

	/**
	 * Whitelisted columns mapped to their `$wpdb` format specifiers.
	 * `ID`, `created_at` and `updated_at` are managed separately.
	 *
	 * @return array
	 */
	protected static function product_display_columns() {
		return array(
			'product_name'          => '%s',
			'product_source'        => '%s',
			'wc_product_id'         => '%d',
			'product_image_id'      => '%d',
			'product_image_url'     => '%s',
			'template'              => '%s',
			'badge_text'            => '%s',
			'price'                 => '%s',
			'regular_price'         => '%s',
			'sale_price'            => '%s',
			'description'           => '%s',
			'style'                 => '%s',
			'primary_link_id'       => '%d',
			'primary_button_text'   => '%s',
			'primary_tracking'      => '%d',
			'primary_nofollow'      => '%d',
			'secondary_link_id'     => '%d',
			'secondary_button_text' => '%s',
			'secondary_tracking'    => '%d',
			'secondary_nofollow'    => '%d',
			'disclosure_text'       => '%s',
			'show_disclosure'       => '%d',
			'default_disclosure'    => '%d',
			'new_tab'               => '%d',
			'status'                => '%d',
		);
	}

	/**
	 * Get all product displays (newest first).
	 *
	 * @return array
	 */
	public static function get_product_displays() {
		global $wpdb;
		$table = self::product_display_table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$rows = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY ID DESC", ARRAY_A );
		if ( ! is_array( $rows ) ) {
			return array();
		}
		return array_map( array( __CLASS__, 'cast_product_display_row' ), $rows );
	}

	/**
	 * Get a single product display by ID.
	 *
	 * @param int $id
	 * @return array|null
	 */
	public static function get_product_display( $id ) {
		global $wpdb;
		$table = self::product_display_table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE ID = %d", absint( $id ) ), ARRAY_A );
		if ( empty( $row ) ) {
			return null;
		}
		return self::cast_product_display_row( $row );
	}

	/**
	 * Insert a new product display.
	 *
	 * @param array $data Sanitized column => value map.
	 * @return int|false New row ID on success, false on failure.
	 */
	public static function insert_product_display( $data ) {
		global $wpdb;
		$table   = self::product_display_table();
		$columns = self::product_display_columns();

		$insert  = array();
		$formats = array();
		foreach ( $columns as $column => $format ) {
			if ( array_key_exists( $column, $data ) ) {
				$insert[ $column ] = $data[ $column ];
				$formats[]         = $format;
			}
		}

		$now                 = current_time( 'mysql' );
		$insert['created_at'] = $now;
		$insert['updated_at'] = $now;
		$formats[]            = '%s';
		$formats[]            = '%s';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->insert( $table, $insert, $formats );
		if ( false === $result ) {
			return false;
		}
		return (int) $wpdb->insert_id;
	}

	/**
	 * Update an existing product display.
	 *
	 * @param int   $id
	 * @param array $data Sanitized column => value map.
	 * @return bool
	 */
	public static function update_product_display( $id, $data ) {
		global $wpdb;
		$table   = self::product_display_table();
		$columns = self::product_display_columns();

		$update  = array();
		$formats = array();
		foreach ( $columns as $column => $format ) {
			if ( array_key_exists( $column, $data ) ) {
				$update[ $column ] = $data[ $column ];
				$formats[]         = $format;
			}
		}

		if ( empty( $update ) ) {
			return false;
		}

		$update['updated_at'] = current_time( 'mysql' );
		$formats[]            = '%s';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->update( $table, $update, array( 'ID' => absint( $id ) ), $formats, array( '%d' ) );
		return false !== $result;
	}

	/**
	 * Delete a product display.
	 *
	 * @param int $id
	 * @return bool
	 */
	public static function delete_product_display( $id ) {
		global $wpdb;
		$table = self::product_display_table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->delete( $table, array( 'ID' => absint( $id ) ), array( '%d' ) );
		return false !== $result;
	}

	/* ====================================================================== *
	 * Product Display Groups
	 * ====================================================================== */

	public static function product_groups_table() {
		global $wpdb;
		return $wpdb->prefix . 'betterlinks_product_groups';
	}

	/**
	 * Get all groups (newest first).
	 *
	 * @return array
	 */
	public static function get_product_groups() {
		global $wpdb;
		$table = self::product_groups_table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$rows = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY ID DESC", ARRAY_A );
		if ( ! is_array( $rows ) ) {
			return array();
		}
		return array_map( array( __CLASS__, 'cast_product_group_row' ), $rows );
	}

	/**
	 * Get a single group by ID.
	 *
	 * @param int $id
	 * @return array|null
	 */
	public static function get_product_group( $id ) {
		global $wpdb;
		$table = self::product_groups_table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE ID = %d", absint( $id ) ), ARRAY_A );
		if ( empty( $row ) ) {
			return null;
		}
		return self::cast_product_group_row( $row );
	}

	/**
	 * Insert a new group.
	 *
	 * @param array $data title/type/columns/display_ids(array)/status
	 * @return int|false
	 */
	public static function insert_product_group( $data ) {
		global $wpdb;
		$table = self::product_groups_table();
		$now   = current_time( 'mysql' );

		$insert = self::prepare_group_columns( $data );
		$insert['created_at'] = $now;
		$insert['updated_at'] = $now;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->insert( $table, $insert, self::group_formats( $insert ) );
		if ( false === $result ) {
			return false;
		}
		return (int) $wpdb->insert_id;
	}

	/**
	 * Update a group.
	 *
	 * @param int   $id
	 * @param array $data
	 * @return bool
	 */
	public static function update_product_group( $id, $data ) {
		global $wpdb;
		$table  = self::product_groups_table();
		$update = self::prepare_group_columns( $data );
		if ( empty( $update ) ) {
			return false;
		}
		$update['updated_at'] = current_time( 'mysql' );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->update( $table, $update, array( 'ID' => absint( $id ) ), self::group_formats( $update ), array( '%d' ) );
		return false !== $result;
	}

	/**
	 * Delete a group.
	 *
	 * @param int $id
	 * @return bool
	 */
	public static function delete_product_group( $id ) {
		global $wpdb;
		$table = self::product_groups_table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->delete( $table, array( 'ID' => absint( $id ) ), array( '%d' ) );
		return false !== $result;
	}

	/**
	 * Build the writable column map for a group from request data.
	 *
	 * @param array $data
	 * @return array
	 */
	protected static function prepare_group_columns( $data ) {
		$columns = array();
		if ( array_key_exists( 'group_title', $data ) ) {
			$columns['group_title'] = sanitize_text_field( $data['group_title'] );
		}
		if ( array_key_exists( 'group_type', $data ) ) {
			$type                  = sanitize_text_field( $data['group_type'] );
			$columns['group_type'] = in_array( $type, array( 'grid', 'list' ), true ) ? $type : 'grid';
		}
		if ( array_key_exists( 'columns', $data ) ) {
			$columns['columns'] = min( 4, max( 1, absint( $data['columns'] ) ) );
		}
		if ( array_key_exists( 'display_ids', $data ) ) {
			$ids = is_array( $data['display_ids'] ) ? $data['display_ids'] : array();
			$ids = array_values( array_filter( array_map( 'absint', $ids ) ) );
			$columns['display_ids'] = wp_json_encode( $ids );
		}
		if ( array_key_exists( 'status', $data ) ) {
			$columns['status'] = $data['status'] ? 1 : 0;
		}
		return $columns;
	}

	/**
	 * Format specifiers matching a prepared group column map.
	 *
	 * @param array $columns
	 * @return array
	 */
	protected static function group_formats( $columns ) {
		$formats = array();
		foreach ( $columns as $key => $value ) {
			$formats[] = in_array( $key, array( 'columns', 'status' ), true ) ? '%d' : '%s';
		}
		return $formats;
	}

	/**
	 * Normalize a raw group row for output (decode ids, cast ints/bools).
	 *
	 * @param array $row
	 * @return array
	 */
	public static function cast_product_group_row( $row ) {
		$row['ID']      = isset( $row['ID'] ) ? (int) $row['ID'] : 0;
		$row['columns'] = isset( $row['columns'] ) ? (int) $row['columns'] : 2;
		$row['status']  = isset( $row['status'] ) ? (bool) (int) $row['status'] : true;

		$ids = array();
		if ( ! empty( $row['display_ids'] ) ) {
			$decoded = json_decode( $row['display_ids'], true );
			if ( is_array( $decoded ) ) {
				$ids = array_values( array_filter( array_map( 'absint', $decoded ) ) );
			}
		}
		$row['display_ids'] = $ids;
		return $row;
	}

	/**
	 * Normalize a raw DB row into typed values for JSON/output.
	 *
	 * @param array $row
	 * @return array
	 */
	public static function cast_product_display_row( $row ) {
		$int_fields  = array( 'ID', 'wc_product_id', 'product_image_id', 'primary_link_id', 'secondary_link_id' );
		$bool_fields = array(
			'primary_tracking',
			'primary_nofollow',
			'secondary_tracking',
			'secondary_nofollow',
			'show_disclosure',
			'default_disclosure',
			'new_tab',
			'status',
		);

		foreach ( $int_fields as $field ) {
			if ( isset( $row[ $field ] ) ) {
				$row[ $field ] = null === $row[ $field ] ? null : (int) $row[ $field ];
			}
		}
		foreach ( $bool_fields as $field ) {
			if ( isset( $row[ $field ] ) ) {
				$row[ $field ] = (bool) (int) $row[ $field ];
			}
		}

		// Per-card style overrides are stored as a JSON object.
		$style = array();
		if ( ! empty( $row['style'] ) ) {
			$decoded = json_decode( $row['style'], true );
			if ( is_array( $decoded ) ) {
				$style = $decoded;
			}
		}
		$row['style'] = $style;

		return $row;
	}
}
