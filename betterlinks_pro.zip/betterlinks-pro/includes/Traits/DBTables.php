<?php
namespace BetterLinksPro\Traits;
if ( ! defined( 'ABSPATH' ) ) { exit; }

trait DBTables {
	public function createBetterClicksRotationsTable() {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table_name = $this->wpdb->prefix . 'betterlinks_clicks_rotations';
		$sql        = "CREATE TABLE IF NOT EXISTS $table_name (
            ID bigint(20) unsigned NOT NULL auto_increment,
            link_id bigint(20) NOT NULL,
            click_id bigint(20) NOT NULL,
            target_url varchar(255) NULL,
            PRIMARY KEY  (ID),
            key link_id (link_id),
            key click_id (click_id)
        ) $this->charset_collate;";
		dbDelta( $sql );
	}

	public function modifyBetterLinksClicksTable() {
		global $wpdb;

		// todo: 👇 if `device` column exists that means we already have added device, brand_name, model, bot_name, browser_type, os_version, browser_version, language column
		// todo: so, we need to skip the betterlinks_clicks table alterations
		$check_column_exists_sql = sprintf( 'select `column_name` from information_schema.columns where table_schema="%1$s" and table_name="%2$sbetterlinks_clicks" and column_name="device";', DB_NAME, $wpdb->prefix );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$result                  = $wpdb->query( $check_column_exists_sql );

		if ( ! $result ) {
			$table_name = $wpdb->prefix . 'betterlinks_clicks';
			$sql        = "ALTER TABLE {$table_name}
                MODIFY created_at datetime NOT NULL default CURRENT_TIMESTAMP,
                MODIFY created_at_gmt datetime NOT NULL default CURRENT_TIMESTAMP,
                ADD COLUMN `device` VARCHAR(20) NULL AFTER `os`,
                ADD COLUMN `brand_name` VARCHAR(20) NULL AFTER `device`,
                ADD COLUMN `model` VARCHAR(20) NULL AFTER `brand_name`,
                ADD COLUMN `bot_name` VARCHAR(20) NULL AFTER `model`,
                ADD COLUMN `browser_type` VARCHAR(20) NULL AFTER `bot_name`,
                ADD COLUMN `os_version` VARCHAR(20) NULL AFTER `browser_type`,
                ADD COLUMN `browser_version` VARCHAR(20) NULL AFTER `os_version`,
                ADD COLUMN `language` VARCHAR(10) NULL AFTER `browser_version`;";

			// phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
			$wpdb->query( $sql );
		}
	}

	public function createBetterLinkCustomizeMetaTagsTable() {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		global $wpdb;
		$prefix          = $wpdb->prefix;
		$charset_collate = $wpdb->get_charset_collate();

		$table_name     = $prefix . 'betterlinks_meta_tags';
		$ref_table_name = $prefix . 'betterlinks';
		$sql            = "CREATE TABLE IF NOT EXISTS $table_name (
            `id` INT NOT NULL AUTO_INCREMENT,
            `link_id` bigint(20) unsigned NOT NULL,
            `meta_title` VARCHAR(100),
            `meta_desc` VARCHAR(300),
            `meta_image` TEXT NULL,
            `status` boolean default false,
            PRIMARY KEY (`id`),
            FOREIGN KEY (`link_id`) REFERENCES $ref_table_name (`ID`)
                ON DELETE CASCADE
        ) $charset_collate;";
		dbDelta( $sql );
	}

	/**
	 * Product Display feature table. One row per display (a presentation card that
	 * wraps up to two existing BetterLinks links into CTA buttons).
	 *
	 * @return void
	 */
	public function createProductDisplayTable() {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		global $wpdb;
		$prefix          = $wpdb->prefix;
		$charset_collate = $wpdb->get_charset_collate();

		$table_name     = $prefix . 'betterlinks_product_display';
		$ref_table_name = $prefix . 'betterlinks';
		$sql            = "CREATE TABLE IF NOT EXISTS $table_name (
            `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            `product_name` VARCHAR(255) NOT NULL DEFAULT '',
            `product_source` VARCHAR(20) NOT NULL DEFAULT 'custom',
            `wc_product_id` bigint(20) unsigned NULL,
            `product_image_id` bigint(20) unsigned NULL,
            `product_image_url` TEXT,
            `template` VARCHAR(20) NOT NULL DEFAULT 'epsilon',
            `badge_text` VARCHAR(100) NULL,
            `price` VARCHAR(50) NULL,
            `regular_price` VARCHAR(50) NULL,
            `sale_price` VARCHAR(50) NULL,
            `description` LONGTEXT NULL,
            `style` LONGTEXT NULL,
            `primary_link_id` bigint(20) unsigned NULL,
            `primary_button_text` VARCHAR(100) NULL,
            `primary_tracking` tinyint(1) NOT NULL DEFAULT 1,
            `primary_nofollow` tinyint(1) NOT NULL DEFAULT 0,
            `secondary_link_id` bigint(20) unsigned NULL,
            `secondary_button_text` VARCHAR(100) NULL,
            `secondary_tracking` tinyint(1) NOT NULL DEFAULT 1,
            `secondary_nofollow` tinyint(1) NOT NULL DEFAULT 0,
            `disclosure_text` TEXT NULL,
            `show_disclosure` tinyint(1) NOT NULL DEFAULT 1,
            `default_disclosure` tinyint(1) NOT NULL DEFAULT 1,
            `new_tab` tinyint(1) NOT NULL DEFAULT 0,
            `status` tinyint(1) NOT NULL DEFAULT 1,
            `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`ID`),
            KEY `primary_link_id` (`primary_link_id`),
            KEY `secondary_link_id` (`secondary_link_id`)
        ) $charset_collate;";
		dbDelta( $sql );
	}

	/**
	 * Remove the FOREIGN KEY constraints from installs created before they were dropped.
	 *
	 * They are what stopped dbDelta from ALTERing this table (see the schema-revision
	 * self-heal above), so shedding them also unblocks future column additions. The
	 * cascade they provided now lives in detach_product_display_links().
	 *
	 * @return void
	 */
	public function dropProductDisplayForeignKeys() {
		global $wpdb;

		$table = $wpdb->prefix . 'betterlinks_product_display';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$constraints = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT CONSTRAINT_NAME FROM information_schema.TABLE_CONSTRAINTS
				 WHERE CONSTRAINT_SCHEMA = %s AND TABLE_NAME = %s AND CONSTRAINT_TYPE = 'FOREIGN KEY'",
				DB_NAME,
				$table
			)
		);

		if ( empty( $constraints ) ) {
			return;
		}

		foreach ( $constraints as $constraint ) {
			$constraint = preg_replace( '/[^A-Za-z0-9_]/', '', (string) $constraint );
			if ( '' === $constraint ) {
				continue;
			}
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.SchemaChange,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$wpdb->query( "ALTER TABLE {$table} DROP FOREIGN KEY `{$constraint}`" );
		}
	}

	/**
	 * Null out product-display references to a link that is being deleted.
	 *
	 * Replaces the FOREIGN KEY ... ON DELETE SET NULL constraints this table used to
	 * declare. Those constraints made the CREATE fail outright whenever the referenced
	 * `betterlinks` table was MyISAM (or otherwise engine-mismatched), which silently
	 * left the whole Promo Cards feature without its tables; they also blocked dbDelta
	 * from ALTERing the table later. WordPress core does not use foreign keys for the
	 * same reasons, so the cascade is enforced here instead.
	 *
	 * @param int $link_id
	 * @return void
	 */
	public static function detach_product_display_links( $link_id ) {
		global $wpdb;

		$link_id = absint( $link_id );
		if ( ! $link_id ) {
			return;
		}

		$table = $wpdb->prefix . 'betterlinks_product_display';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET `primary_link_id` = NULL WHERE `primary_link_id` = %d", $link_id ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET `secondary_link_id` = NULL WHERE `secondary_link_id` = %d", $link_id ) );
	}

	/**
	 * Guarantee the newer product-display columns exist on installs whose table
	 * was created before they were introduced. dbDelta does NOT reliably ALTER a
	 * table that has FOREIGN KEY constraints, so we add the columns explicitly and
	 * idempotently (only when missing).
	 *
	 * @return void
	 */
	public function ensureProductDisplayColumns() {
		global $wpdb;
		$table = $wpdb->prefix . 'betterlinks_product_display';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		if ( ! $exists ) {
			return;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$columns = $wpdb->get_col( "DESC `{$table}`", 0 );
		if ( ! is_array( $columns ) ) {
			return;
		}

		$alters = array();
		if ( ! in_array( 'regular_price', $columns, true ) ) {
			$alters[] = "ADD COLUMN `regular_price` VARCHAR(50) NULL";
		}
		if ( ! in_array( 'sale_price', $columns, true ) ) {
			$alters[] = "ADD COLUMN `sale_price` VARCHAR(50) NULL";
		}
		if ( ! in_array( 'style', $columns, true ) ) {
			$alters[] = "ADD COLUMN `style` LONGTEXT NULL";
		}
		if ( ! in_array( 'product_source', $columns, true ) ) {
			$alters[] = "ADD COLUMN `product_source` VARCHAR(20) NOT NULL DEFAULT 'custom'";
		}
		if ( ! in_array( 'wc_product_id', $columns, true ) ) {
			$alters[] = "ADD COLUMN `wc_product_id` bigint(20) unsigned NULL";
		}

		if ( ! empty( $alters ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter
			$wpdb->query( "ALTER TABLE `{$table}` " . implode( ', ', $alters ) );
		}
	}

	/**
	 * Product Display Groups table. A group is an ordered collection of single
	 * product displays rendered together as a grid or list.
	 *
	 * @return void
	 */
	public function createProductGroupsTable() {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		global $wpdb;
		$prefix          = $wpdb->prefix;
		$charset_collate = $wpdb->get_charset_collate();

		$table_name = $prefix . 'betterlinks_product_groups';
		$sql        = "CREATE TABLE IF NOT EXISTS $table_name (
            `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            `group_title` VARCHAR(255) NOT NULL DEFAULT '',
            `group_type` VARCHAR(10) NOT NULL DEFAULT 'grid',
            `display_ids` LONGTEXT NULL,
            `columns` tinyint(2) NOT NULL DEFAULT 2,
            `status` tinyint(1) NOT NULL DEFAULT 1,
            `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`ID`)
        ) $charset_collate;";
		dbDelta( $sql );
	}

	/**
	 * "Link in Bio" pages table. One row per bio page; the whole builder state is
	 * stored in the `config` JSON column, while identity/listing fields are
	 * dedicated columns so the list view can query/sort without decoding JSON.
	 *
	 * @return void
	 */
	public function createBioPagesTable() {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		global $wpdb;
		$prefix          = $wpdb->prefix;
		$charset_collate = $wpdb->get_charset_collate();

		$table_name = $prefix . 'betterlinks_bio_pages';
		$sql        = "CREATE TABLE IF NOT EXISTS $table_name (
            `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            `title` VARCHAR(255) NOT NULL DEFAULT '',
            `slug` VARCHAR(191) NOT NULL DEFAULT '',
            `status` VARCHAR(20) NOT NULL DEFAULT 'draft',
            `avatar_id` bigint(20) unsigned NULL,
            `avatar_url` TEXT NULL,
            `config` LONGTEXT NULL,
            `views` bigint(20) unsigned NOT NULL DEFAULT 0,
            `author` bigint(20) unsigned NOT NULL DEFAULT 0,
            `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`ID`),
            KEY `slug` (`slug`),
            KEY `status` (`status`)
        ) $charset_collate;";
		dbDelta( $sql );
	}
}
