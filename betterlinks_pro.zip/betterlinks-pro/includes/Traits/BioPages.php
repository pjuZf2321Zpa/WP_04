<?php
namespace BetterLinksPro\Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Data-access helpers for the "Link in Bio" feature.
 *
 * Every method uses prepared statements against the
 * `{$wpdb->prefix}betterlinks_bio_pages` table. The whole builder state lives in
 * the `config` JSON column; identity/listing fields are dedicated columns so the
 * list view can be queried/sorted without decoding JSON.
 */
trait BioPages {

	/**
	 * Fully-qualified bio pages table name.
	 *
	 * @return string
	 */
	public static function bio_pages_table() {
		global $wpdb;
		return $wpdb->prefix . 'betterlinks_bio_pages';
	}

	/**
	 * Whitelisted columns mapped to their `$wpdb` format specifiers.
	 * `ID`, `created_at` and `updated_at` are managed separately.
	 *
	 * @return array
	 */
	protected static function bio_columns() {
		return array(
			'title'      => '%s',
			'slug'       => '%s',
			'status'     => '%s',
			'avatar_id'  => '%d',
			'avatar_url' => '%s',
			'config'     => '%s',
			'views'      => '%d',
			'author'     => '%d',
		);
	}

	/**
	 * Get all bio pages (newest first), with computed views + clicks for the list.
	 *
	 * @return array
	 */
	public static function get_bios() {
		global $wpdb;
		$table = self::bio_pages_table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$rows = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY ID DESC", ARRAY_A );
		if ( ! is_array( $rows ) ) {
			return array();
		}
		return array_map( array( __CLASS__, 'cast_bio_row' ), $rows );
	}

	/**
	 * Get a single bio page by ID.
	 *
	 * @param int $id
	 * @return array|null
	 */
	public static function get_bio( $id ) {
		global $wpdb;
		$table = self::bio_pages_table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE ID = %d", absint( $id ) ), ARRAY_A );
		if ( empty( $row ) ) {
			return null;
		}
		return self::cast_bio_row( $row );
	}

	/**
	 * Get a single published bio page by slug (used by the public renderer).
	 *
	 * @param string $slug
	 * @return array|null
	 */
	public static function get_published_bio_by_slug( $slug ) {
		global $wpdb;
		$table = self::bio_pages_table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE slug = %s AND status = 'publish' LIMIT 1", $slug ),
			ARRAY_A
		);
		if ( empty( $row ) ) {
			return null;
		}
		return self::cast_bio_row( $row );
	}

	/**
	 * Insert a new bio page.
	 *
	 * @param array $data Sanitized column => value map.
	 * @return int|false New row ID on success, false on failure.
	 */
	public static function insert_bio( $data ) {
		global $wpdb;
		$table   = self::bio_pages_table();
		$columns = self::bio_columns();

		$insert  = array();
		$formats = array();
		foreach ( $columns as $column => $format ) {
			if ( array_key_exists( $column, $data ) ) {
				$insert[ $column ] = $data[ $column ];
				$formats[]         = $format;
			}
		}

		$now                  = current_time( 'mysql' );
		$insert['created_at'] = $now;
		$insert['updated_at'] = $now;
		$formats[]            = '%s';
		$formats[]            = '%s';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->insert( $table, $insert, $formats );
		if ( false === $result ) {
			return false;
		}
		return (int) $wpdb->insert_id;
	}

	/**
	 * Update an existing bio page.
	 *
	 * @param int   $id
	 * @param array $data Sanitized column => value map.
	 * @return bool
	 */
	public static function update_bio( $id, $data ) {
		global $wpdb;
		$table   = self::bio_pages_table();
		$columns = self::bio_columns();

		$update  = array();
		$formats = array();
		foreach ( $columns as $column => $format ) {
			if ( array_key_exists( $column, $data ) ) {
				$update[ $column ] = $data[ $column ];
				$formats[]         = $format;
			}
		}

		if ( empty( $update ) ) {
			return false;
		}

		$update['updated_at'] = current_time( 'mysql' );
		$formats[]            = '%s';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->update( $table, $update, array( 'ID' => absint( $id ) ), $formats, array( '%d' ) );
		return false !== $result;
	}

	/**
	 * Delete a bio page row (tracked short links are removed by the caller).
	 *
	 * @param int $id
	 * @return bool
	 */
	public static function delete_bio( $id ) {
		global $wpdb;
		$table = self::bio_pages_table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->delete( $table, array( 'ID' => absint( $id ) ), array( '%d' ) );
		return false !== $result;
	}

	/**
	 * Is the current request a bot / crawler?
	 *
	 * Uses the same DeviceDetector the free click tracker runs, so bio views and link
	 * clicks agree on what counts as a visitor. Crawlers and link unfurlers (Slack,
	 * WhatsApp, Twitter) fetch bio pages with a normal GET after their HEAD probe, so
	 * without this the view counter reads far higher than the click analytics beside it.
	 *
	 * @return bool
	 */
	protected static function is_bot_request() {
		if ( ! class_exists( '\DeviceDetector\DeviceDetector' ) ) {
			return false;
		}

		$user_agent = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
		if ( '' === $user_agent ) {
			// No UA at all is far more typical of a script than a browser.
			return true;
		}

		$detector = new \DeviceDetector\DeviceDetector( $user_agent );
		$detector->parse();

		return (bool) $detector->isBot();
	}

	/**
	 * Increment the cached page-view counter for a published bio.
	 *
	 * Bot traffic is skipped so the counter reflects real visitors.
	 *
	 * @param int $id
	 * @return void
	 */
	public static function increment_bio_views( $id ) {
		if ( self::is_bot_request() ) {
			return;
		}

		global $wpdb;
		$table = self::bio_pages_table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET views = views + 1 WHERE ID = %d", absint( $id ) ) );
	}

	/**
	 * Is a slug free? Checks both bio pages and existing BetterLinks short links
	 * (since a published bio shares the `{prefix}/{slug}` URL namespace with links).
	 *
	 * @param string $slug       Slug without prefix.
	 * @param int    $exclude_id Bio ID to ignore (when editing).
	 * @return bool
	 */
	public static function is_bio_slug_available( $slug, $exclude_id = 0 ) {
		global $wpdb;
		$slug = self::sanitize_bio_slug( $slug );
		if ( '' === $slug ) {
			return false;
		}

		$table = self::bio_pages_table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$existing = $wpdb->get_var(
			$wpdb->prepare( "SELECT ID FROM {$table} WHERE slug = %s AND ID != %d LIMIT 1", $slug, absint( $exclude_id ) )
		);
		if ( $existing ) {
			return false;
		}

		// Collides with an existing short link?
		$short = self::bio_short_url_for_slug( $slug );
		if ( class_exists( '\BetterLinks\Helper' ) && \BetterLinks\Helper::is_exists_short_url( $short ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Resolve the configured BetterLinks short-link prefix (e.g. "go").
	 *
	 * @return string
	 */
	public static function bio_prefix() {
		if ( ! defined( 'BETTERLINKS_LINKS_OPTION_NAME' ) ) {
			return '';
		}
		$settings = get_option( BETTERLINKS_LINKS_OPTION_NAME );
		if ( is_string( $settings ) ) {
			$settings = json_decode( $settings, true );
		}
		return ( is_array( $settings ) && ! empty( $settings['prefix'] ) ) ? sanitize_title( $settings['prefix'] ) : '';
	}

	/**
	 * The `{prefix}/{slug}` short_url value for a bio slug.
	 *
	 * @param string $slug
	 * @return string
	 */
	public static function bio_short_url_for_slug( $slug ) {
		$prefix = self::bio_prefix();
		return $prefix ? $prefix . '/' . $slug : $slug;
	}

	/**
	 * Public URL of a bio page.
	 *
	 * @param string $slug
	 * @return string
	 */
	public static function bio_public_url( $slug ) {
		return home_url( '/' . self::bio_short_url_for_slug( $slug ) );
	}

	/**
	 * Normalize a user-supplied handle into a safe slug.
	 *
	 * @param string $slug
	 * @return string
	 */
	public static function sanitize_bio_slug( $slug ) {
		$slug = sanitize_title( (string) $slug );
		return $slug;
	}

	/**
	 * Sum total + unique clicks across a set of tracked link IDs.
	 *
	 * @param int[] $link_ids
	 * @return array{total:int,unique:int}
	 */
	public static function bio_link_click_stats( $link_ids ) {
		global $wpdb;
		$link_ids = array_values( array_filter( array_map( 'absint', (array) $link_ids ) ) );
		if ( empty( $link_ids ) ) {
			return array(
				'total'  => 0,
				'unique' => 0,
			);
		}
		$placeholders = implode( ',', array_fill( 0, count( $link_ids ), '%d' ) );
		$clicks_table = $wpdb->prefix . 'betterlinks_clicks';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$row = $wpdb->get_row(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$wpdb->prepare(
				"SELECT COUNT(*) AS total, COUNT(DISTINCT ip) AS uniques FROM {$clicks_table} WHERE link_id IN ({$placeholders})",
				$link_ids
			),
			ARRAY_A
		);
		return array(
			'total'  => isset( $row['total'] ) ? (int) $row['total'] : 0,
			'unique' => isset( $row['uniques'] ) ? (int) $row['uniques'] : 0,
		);
	}

	/**
	 * Daily click counts for a set of tracked link IDs, oldest day first.
	 *
	 * Backs the sparkline on each analytics row. Always returns exactly $days
	 * entries — days with no clicks are zero-filled here rather than in JS, so
	 * the sparkline's x-axis is evenly spaced regardless of gaps.
	 *
	 * NOTE: clicks are timestamped, but bio *views* are only a running counter
	 * on the bio row (see increment_bio_views), so there is no view history to
	 * chart. The sparkline is clicks only.
	 *
	 * @param int[] $link_ids
	 * @param int   $days How many days back, including today.
	 * @return int[]
	 */
	public static function bio_link_click_series( $link_ids, $days = 14 ) {
		global $wpdb;
		$days     = max( 1, (int) $days );
		$link_ids = array_values( array_filter( array_map( 'absint', (array) $link_ids ) ) );

		// Zero-filled buckets keyed by Y-m-d, oldest first.
		$buckets = array();
		for ( $i = $days - 1; $i >= 0; $i-- ) {
			$buckets[ gmdate( 'Y-m-d', strtotime( "-{$i} days", current_time( 'timestamp' ) ) ) ] = 0;
		}

		if ( empty( $link_ids ) ) {
			return array_values( $buckets );
		}

		$placeholders = implode( ',', array_fill( 0, count( $link_ids ), '%d' ) );
		$clicks_table = $wpdb->prefix . 'betterlinks_clicks';
		$from         = array_key_first( $buckets ) . ' 00:00:00';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$wpdb->prepare(
				"SELECT DATE(created_at) AS d, COUNT(*) AS c
					FROM {$clicks_table}
					WHERE link_id IN ({$placeholders}) AND created_at >= %s
					GROUP BY d",
				array_merge( $link_ids, array( $from ) )
			),
			ARRAY_A
		);

		foreach ( (array) $rows as $row ) {
			if ( isset( $buckets[ $row['d'] ] ) ) {
				$buckets[ $row['d'] ] = (int) $row['c'];
			}
		}

		return array_values( $buckets );
	}

	/**
	 * Collect the tracked link IDs referenced inside a bio config.
	 *
	 * @param array $config
	 * @return int[]
	 */
	public static function bio_tracked_link_ids( $config ) {
		$ids = array();
		foreach ( array( 'icons', 'links' ) as $group ) {
			if ( empty( $config[ $group ] ) || ! is_array( $config[ $group ] ) ) {
				continue;
			}
			foreach ( $config[ $group ] as $entry ) {
				if ( ! empty( $entry['link_id'] ) ) {
					$ids[] = (int) $entry['link_id'];
				}
			}
		}
		return array_values( array_unique( $ids ) );
	}

	/**
	 * Normalize a raw DB row into typed values for JSON/output.
	 *
	 * @param array $row
	 * @return array
	 */
	public static function cast_bio_row( $row ) {
		$row['ID']        = isset( $row['ID'] ) ? (int) $row['ID'] : 0;
		$row['avatar_id'] = isset( $row['avatar_id'] ) ? (int) $row['avatar_id'] : 0;
		$row['views']     = isset( $row['views'] ) ? (int) $row['views'] : 0;
		$row['author']    = isset( $row['author'] ) ? (int) $row['author'] : 0;
		$row['status']    = isset( $row['status'] ) && 'publish' === $row['status'] ? 'publish' : 'draft';

		$config = array();
		if ( ! empty( $row['config'] ) ) {
			$decoded = json_decode( $row['config'], true );
			if ( is_array( $decoded ) ) {
				$config = $decoded;
			}
		}
		$row['config'] = $config;

		// Computed, read-only helpers for the admin UI.
		$row['public_url'] = self::bio_public_url( $row['slug'] );
		$clicks            = self::bio_link_click_stats( self::bio_tracked_link_ids( $config ) );
		$row['clicks']     = $clicks['total'];

		return $row;
	}
}
