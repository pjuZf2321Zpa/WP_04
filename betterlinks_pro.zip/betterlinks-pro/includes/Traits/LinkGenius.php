<?php
/**
 * AI Link Assistant engine helpers.
 *
 * Builds the link catalog ( enriched with real click data ), constructs the
 * semantic-matching prompt, calls the shared AI engine and ranks the resulting
 * suggestions by blending the model's contextual confidence with owned click
 * performance — the data moat no SEO plugin has.
 *
 * @package BetterLinksPro\Traits
 * @since   2.8.0
 */

namespace BetterLinksPro\Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use BetterLinksPro\Tools\AIClient;

trait LinkGenius {

	/**
	 * Maximum number of links sent to the model, ordered by recent performance.
	 */
	protected $genius_catalog_limit = 150;

	/**
	 * Build the catalog of managed links enriched with click counts and keywords.
	 *
	 * @return array<int,array<string,mixed>> Keyed by link ID.
	 */
	protected function get_link_catalog() {
		global $wpdb;

		$links_table  = $wpdb->prefix . 'betterlinks';
		$clicks_table = $wpdb->prefix . 'betterlinks_clicks';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			"SELECT ID, link_title, link_note, target_url, short_url
			 FROM {$links_table}
			 WHERE link_status = 'publish'",
			ARRAY_A
		);

		if ( empty( $rows ) ) {
			return array();
		}

		// Aggregate click counts (last 90 days) per link in a single query.
		$click_counts = array();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$click_rows = $wpdb->get_results(
			"SELECT link_id, COUNT(ID) AS clicks
			 FROM {$clicks_table}
			 WHERE created_at >= DATE_SUB(NOW(), INTERVAL 90 DAY)
			 GROUP BY link_id",
			ARRAY_A
		);
		if ( ! empty( $click_rows ) ) {
			foreach ( $click_rows as $click_row ) {
				$click_counts[ (int) $click_row['link_id'] ] = (int) $click_row['clicks'];
			}
		}

		// Keywords are stored as link meta by the Auto-Link feature; reuse them.
		$keywords_by_link = array();
		if ( method_exists( '\BetterLinks\Helper', 'get_keywords' ) ) {
			$all_keywords = \BetterLinks\Helper::get_keywords();
			if ( is_array( $all_keywords ) ) {
				foreach ( $all_keywords as $keyword_item ) {
					$keyword_item = is_string( $keyword_item ) ? json_decode( $keyword_item, true ) : $keyword_item;
					if ( ! is_array( $keyword_item ) || empty( $keyword_item['link_id'] ) ) {
						continue;
					}
					$lid = (int) $keyword_item['link_id'];
					if ( ! isset( $keywords_by_link[ $lid ] ) ) {
						$keywords_by_link[ $lid ] = array();
					}
					if ( ! empty( $keyword_item['keywords'] ) ) {
						$keywords_by_link[ $lid ][] = $keyword_item['keywords'];
					}
				}
			}
		}

		$catalog = array();
		foreach ( $rows as $row ) {
			$id     = (int) $row['ID'];
			$host   = wp_parse_url( $row['target_url'], PHP_URL_HOST );
			$clicks = isset( $click_counts[ $id ] ) ? $click_counts[ $id ] : 0;

			$keywords = isset( $keywords_by_link[ $id ] ) ? implode( ', ', $keywords_by_link[ $id ] ) : '';

			$catalog[ $id ] = array(
				'id'         => $id,
				'title'      => (string) $row['link_title'],
				'note'       => (string) $row['link_note'],
				'short_url'  => (string) $row['short_url'],
				'target_url' => (string) $row['target_url'],
				'host'       => $host ? $host : '',
				'keywords'   => $keywords,
				'clicks'     => $clicks,
			);
		}

		// Prioritise the best performers when we have to truncate for token budget.
		uasort(
			$catalog,
			static function ( $a, $b ) {
				return $b['clicks'] <=> $a['clicks'];
			}
		);

		if ( count( $catalog ) > $this->genius_catalog_limit ) {
			$catalog = array_slice( $catalog, 0, $this->genius_catalog_limit, true );
		}

		return $catalog;
	}

	/**
	 * Compose the compact, model-friendly catalog string.
	 *
	 * @param array $catalog Catalog from get_link_catalog().
	 *
	 * @return string
	 */
	protected function format_catalog_for_prompt( $catalog ) {
		$lines = array();
		foreach ( $catalog as $item ) {
			$lines[] = wp_json_encode(
				array(
					'link_id'  => $item['id'],
					'title'    => $item['title'],
					'about'    => wp_trim_words( $item['note'], 25, '' ),
					'domain'   => $item['host'],
					'keywords' => $item['keywords'],
					'clicks'   => $item['clicks'],
				)
			);
		}
		return implode( "\n", $lines );
	}

	/**
	 * Compose the content blocks string sent to the model.
	 *
	 * @param array $blocks Array of [ 'id' => string, 'text' => string ].
	 *
	 * @return string
	 */
	protected function format_blocks_for_prompt( $blocks ) {
		$lines = array();
		foreach ( $blocks as $block ) {
			$text = isset( $block['text'] ) ? trim( wp_strip_all_tags( $block['text'] ) ) : '';
			if ( '' === $text ) {
				continue;
			}
			$lines[] = wp_json_encode(
				array(
					'block_id' => isset( $block['id'] ) ? (string) $block['id'] : '',
					'text'     => $text,
				)
			);
		}
		return implode( "\n", $lines );
	}

	/**
	 * Run the AI suggestion + ranking pass.
	 *
	 * @param array $blocks  Content blocks from the editor.
	 * @param array $catalog Link catalog.
	 *
	 * @return array|\WP_Error List of ranked suggestion arrays.
	 */
	protected function generate_genius_suggestions( $blocks, $catalog ) {
		if ( empty( $catalog ) ) {
			return array();
		}

		$system_prompt = 'You are AI Link Assistant, an assistant inside WordPress that decides where an author should place their own managed affiliate/tracked links inside the content they are writing. '
			. 'Before suggesting anything, first read and understand the overall meaning, topic and intent of the entire post — not individual blocks in isolation. Build that understanding first, then decide which links genuinely belong. '
			. 'You only ever recommend links from the provided catalog. '
			. 'Reason by semantic relevance — the actual intent and meaning of the surrounding context — never by literal, shallow or partial keyword, slug or title matching. '
			. 'Do NOT map or auto-recommend a link just because the text contains words that resemble the link\'s slug, title or keywords. For example, a link titled "BetterLink" must NOT be suggested merely because the text mentions similar-looking terms; recommend it only when the surrounding context truly refers to that concept. Likewise, anchors such as "short link", "affiliate link" or "tracking link" should match only when the passage is genuinely about that idea, not because of surface-level word similarity. '
			. 'Recommend a link for a block only when it is genuinely, topically relevant and would read naturally — never force a match. When no link is a true contextual fit, return no suggestion rather than a weak one. '
			. 'For each recommendation pick a short anchor phrase that already exists verbatim inside that block\'s text and choose it dynamically from the content; there is no fixed number of keywords to find — surface as many or as few as the content genuinely supports. '
			. 'A single block may contain more than one genuinely relevant anchor for different links — when that is the case, suggest each one; do not artificially limit yourself to one suggestion per block. Only avoid recommending the same link with the same anchor twice. '
			. 'Respond ONLY with a JSON object of the shape: {"suggestions":[{"link_id":number,"block_id":string,"anchor":string,"reason":string,"confidence":number}]}. '
			. 'confidence is between 0 and 1. Order suggestions by relevance, strongest first.';

		$user_prompt = "LINK CATALOG (one JSON object per line):\n"
			. $this->format_catalog_for_prompt( $catalog )
			. "\n\nCONTENT BLOCKS (one JSON object per line):\n"
			. $this->format_blocks_for_prompt( $blocks )
			. "\n\nReturn the JSON object now.";

		$result = AIClient::chat_json(
			$system_prompt,
			$user_prompt,
			array(
				'temperature' => 0.4,
			)
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$raw = isset( $result['suggestions'] ) && is_array( $result['suggestions'] ) ? $result['suggestions'] : array();

		return $this->rank_suggestions( $raw, $catalog );
	}

	/**
	 * Validate, enrich and rank raw model suggestions using click performance.
	 *
	 * Blended score = contextual confidence (0-1) weighted by a normalised log of
	 * the link's real click count. This is the A2 "Performance Ranking" pass.
	 *
	 * @param array $raw     Raw suggestions from the model.
	 * @param array $catalog Catalog keyed by link ID.
	 *
	 * @return array
	 */
	protected function rank_suggestions( $raw, $catalog ) {
		$max_clicks = 0;
		foreach ( $catalog as $item ) {
			if ( $item['clicks'] > $max_clicks ) {
				$max_clicks = $item['clicks'];
			}
		}
		$max_log = log( $max_clicks + 1 );

		$suggestions = array();
		$seen        = array();

		foreach ( $raw as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			$link_id = isset( $item['link_id'] ) ? (int) $item['link_id'] : 0;
			$anchor  = isset( $item['anchor'] ) ? sanitize_text_field( $item['anchor'] ) : '';
			$block   = isset( $item['block_id'] ) ? sanitize_text_field( $item['block_id'] ) : '';

			if ( ! isset( $catalog[ $link_id ] ) || '' === $anchor ) {
				continue;
			}

			// De-duplicate identical link+block recommendations.
			$dedupe_key = $link_id . '|' . $block . '|' . strtolower( $anchor );
			if ( isset( $seen[ $dedupe_key ] ) ) {
				continue;
			}
			$seen[ $dedupe_key ] = true;

			$confidence = isset( $item['confidence'] ) ? (float) $item['confidence'] : 0.5;
			$confidence = max( 0, min( 1, $confidence ) );

			$catalog_item = $catalog[ $link_id ];
			$clicks       = (int) $catalog_item['clicks'];

			$performance = $max_log > 0 ? ( log( $clicks + 1 ) / $max_log ) : 0;
			// 70% contextual fit, 30% owned performance.
			$score = round( ( $confidence * 0.7 ) + ( $performance * 0.3 ), 4 );

			$suggestions[] = array(
				'link_id'    => $link_id,
				'block_id'   => $block,
				'anchor'     => $anchor,
				'reason'     => isset( $item['reason'] ) ? sanitize_text_field( $item['reason'] ) : '',
				'confidence' => round( $confidence, 2 ),
				'clicks'     => $clicks,
				'score'      => $score,
				'title'      => $catalog_item['title'],
				'short_url'  => $catalog_item['short_url'],
				'target_url' => $catalog_item['target_url'],
			);
		}

		usort(
			$suggestions,
			static function ( $a, $b ) {
				return $b['score'] <=> $a['score'];
			}
		);

		// Safety ceiling so an unbounded model response can't flood the editor.
		$max_suggestions = (int) apply_filters( 'betterlinks/pro/link_genius_max_suggestions', 25 );
		if ( $max_suggestions > 0 && count( $suggestions ) > $max_suggestions ) {
			$suggestions = array_slice( $suggestions, 0, $max_suggestions );
		}

		return $suggestions;
	}
}
