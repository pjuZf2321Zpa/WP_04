<?php
namespace BetterLinksPro\Traits;
if ( ! defined( 'ABSPATH' ) ) { exit; }

trait Keywords {

	public function prepare_keyword_item_for_db( $params ) {
		// Handle both old isActive (boolean/int) and new keywordStatus (string) formats
		$is_active = 1; // default to active
		if ( isset( $params['keywordStatus'] ) ) {
			// New format: 'active' or 'draft'
			$is_active = ( $params['keywordStatus'] === 'active' ) ? 1 : 0;
		} elseif ( isset( $params['isActive'] ) ) {
			// Old format: boolean or int (for backward compatibility)
			$is_active = intval( sanitize_text_field( $params['isActive'] ) );
		}
		
		// Resolve chooseLink to a numeric link_id (accepts ID, slug or full short URL)
		$link_id = '';
		if ( isset( $params['chooseLink'] ) ) {
			$choose = sanitize_text_field( $params['chooseLink'] );
			if ( is_numeric( $choose ) ) {
				$link_id = intval( $choose );
			} else {
				// If a full URL was provided, extract the last path segment as the slug
				$slug = $choose;
				if ( filter_var( $choose, FILTER_VALIDATE_URL ) ) {
					$path = wp_parse_url( $choose, PHP_URL_PATH );
					$slug = trim( (string) $path, '/');
				}

				// Try to resolve the short-url slug to a link record
				$found = \BetterLinks\Helper::get_link_by_short_url( $slug );

				// If not found and slug has no prefix, try with prefix prepended
				if ( ( ! $found || empty( $found ) ) && strpos( $slug, '/' ) === false ) {
					$helper = new \BetterLinks\Helper();
					$prefix = $helper->get_betterlinks_prefix();
					if ( ! empty( $prefix ) ) {
						$prefixed_slug = rtrim( $prefix, '/' ) . '/' . $slug;
						$found = \BetterLinks\Helper::get_link_by_short_url( $prefixed_slug );
					}
				}

				// If still not found and slug has a prefix, try without prefix
				if ( ( ! $found || empty( $found ) ) && strpos( $slug, '/' ) !== false ) {
					$slug_without_prefix = substr( $slug, strpos( $slug, '/' ) + 1 );
					$found = \BetterLinks\Helper::get_link_by_short_url( $slug_without_prefix );
				}

				if ( $found && is_array( $found ) && ! empty( $found ) ) {
					$first = current( $found );
					$link_id = isset( $first['ID'] ) ? intval( $first['ID'] ) : '';
				} else {
					$link_id = '';
				}
			}
		}

		return array(
			'keywords'       => ( isset( $params['keywords'] ) ? sanitize_text_field( $params['keywords'] ) : '' ),
			'link_id'        => $link_id,
			'post_type'      => ( isset( $params['postType'] ) && is_array( $params['postType'] ) ? array_map( 'sanitize_text_field', $params['postType'] ) : '' ),
			'category'       => ( isset( $params['category'] ) && is_array( $params['category'] ) ? array_map( 'sanitize_text_field', $params['category'] ) : '' ),
			'tags'           => ( isset( $params['tags'] ) && is_array( $params['tags'] ) ? array_map( 'sanitize_text_field', $params['tags'] ) : '' ),
			'open_new_tab'   => ( isset( $params['openNewTab'] ) ? intval( sanitize_text_field( $params['openNewTab'] ) ) : '' ),
			'use_no_follow'  => ( isset( $params['useNoFollow'] ) ? intval( sanitize_text_field( $params['useNoFollow'] ) ) : '' ),
			'case_sensitive' => ( isset( $params['caseSensitive'] ) ? intval( sanitize_text_field( $params['caseSensitive'] ) ) : '' ),
			'left_boundary'  => ( isset( $params['leftBoundary'] ) ? sanitize_text_field( $params['leftBoundary'] ) : '' ),
			'right_boundary' => ( isset( $params['rightBoundary'] ) ? sanitize_text_field( $params['rightBoundary'] ) : '' ),
			'keyword_before' => ( isset( $params['keywordBefore'] ) ? sanitize_text_field( $params['keywordBefore'] ) : '' ),
			'limit'          => ( isset( $params['limit'] ) ? intval( sanitize_text_field( $params['limit'] ) ) : '' ),
			'priority'       => ( isset( $params['priority'] ) ? intval( sanitize_text_field( $params['priority'] ) ) : '' ),
			'keyword_after'  => ( isset( $params['keywordAfter'] ) ? sanitize_text_field( $params['keywordAfter'] ) : '' ),
			'is_active'      => $is_active,
		);
	}
}
