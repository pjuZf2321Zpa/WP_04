<?php
namespace BetterLinksPro\Traits;
if ( ! defined( 'ABSPATH' ) ) { exit; }

trait BrokenLinks {

	public function check_broken_link( $data ) {
		$link_id = isset( $data['ID'] ) ? intval( $data['ID'] ) : 0;
		if ( ! $link_id || empty( $data['target_url'] ) ) {
			return array();
		}

		$logs = json_decode( get_option( 'betterlinkspro_broken_links_logs', '{}' ), true );
		if ( ! is_array( $logs ) ) {
			$logs = array();
		}

		$target_url = \BetterLinksPro\Helper::addScheme( $data['target_url'] );

		// Always re-validate so resumed scans actually refresh stale entries.
		$is_wildcard = strpos( $target_url, '/*' ) !== false;
		if ( $is_wildcard ) {
			$status  = false;
			$verdict = 'healthy';
		} else {
			// Hand the BetterLinks short URL down as the Referer. That's the URL the
			// visitor would have just left when clicking through, and many origins
			// (Shopify product pages, hotlink-protected assets) 404/403 referer-less
			// requests because that's a common scraper signature.
			$short_url = isset( $data['short_url'] ) ? $data['short_url'] : '';
			$args      = array();
			if ( ! empty( $short_url ) ) {
				$args['referer'] = home_url( '/' . ltrim( $short_url, '/' ) );
			}
			$status  = \BetterLinksPro\Helper::url_http_response_is_broken( $target_url, $args );
			$verdict = isset( $status['verdict'] ) ? $status['verdict'] : 'unverifiable';
		}

		// The classifier already weighed primary + secondary checks and bot-protection
		// signals. We act on its verdict directly — only an unambiguous "broken" should
		// flip the link's stored status.
		$is_broken = ( 'broken' === $verdict );

		// Hide "unverifiable" results from the React broken-links report. Its filter is
		// `status_code >= 400 && status_code <= 599`, which would otherwise surface every
		// 4xx that bot-detection produced. Replacing the numeric code with a sentinel
		// string makes that filter NaN-out cleanly without any JS rebuild, and we keep
		// the real code in `original_status_code` for the dashboard / single-link tester.
		if ( is_array( $status ) && 'unverifiable' === $verdict && isset( $status['status_code'] ) && is_int( $status['status_code'] ) ) {
			$status['original_status_code'] = $status['status_code'];
			$status['status_code']          = 'unverifiable';
		}

		// Resolve the link's pre-broken status so we can restore it once it's healthy again.
		$existing_link  = \BetterLinks\Helper::get_link_by_ID( $link_id );
		$existing_link  = is_array( $existing_link ) ? current( $existing_link ) : null;
		$current_status = is_array( $existing_link ) && isset( $existing_link['link_status'] )
			? $existing_link['link_status']
			: 'publish';

		$previous_log    = isset( $logs[ $link_id ] ) && is_array( $logs[ $link_id ] ) ? $logs[ $link_id ] : array();
		$old_link_status = isset( $previous_log['old_link_status'] ) ? $previous_log['old_link_status'] : '';
		if ( empty( $old_link_status ) && 'broken' !== $current_status ) {
			$old_link_status = $current_status;
		}
		if ( empty( $old_link_status ) ) {
			$old_link_status = 'publish';
		}

		// Preserve the user's "Remove Log" decision across re-scans when the upstream
		// response hasn't changed. Without this, every scan undoes the manual dismissal —
		// which forces users to re-dismiss known false positives (Shopify 404s, linksynergy
		// 403s, etc.) on every scan. Reset the flag only when the status code has actually
		// changed, so a previously-dismissed link that develops a *new* problem still gets
		// surfaced.
		$prev_code      = isset( $previous_log['status']['status_code'] ) ? $previous_log['status']['status_code'] : null;
		$new_code       = isset( $status['status_code'] ) ? $status['status_code'] : null;
		$is_log_removed = false;
		if ( ! empty( $previous_log['is_log_removed'] ) && $prev_code === $new_code ) {
			$is_log_removed = true;
		}

		$result = array(
			'ID'              => $link_id,
			'title'           => isset( $data['link_title'] ) ? $data['link_title'] : '',
			'short_url'       => isset( $data['short_url'] ) ? $data['short_url'] : '',
			'target_url'      => $target_url,
			'status'          => $status,
			// Every scan and every single-link re-check writes through here, so this is
			// the moment the row's status was last established. Unix time, to match the
			// full-site scanner's `checked_at` (the UI formats both with formatCheckedAt).
			'checked_at'      => time(),
			'old_link_status' => $old_link_status,
			'is_log_removed'  => $is_log_removed,
		);

		$logs[ $link_id ] = $result;
		update_option( 'betterlinkspro_broken_links_logs', wp_json_encode( $logs ), false );

		// Sync the DB and links.json so the badge in admin and the redirect cache match the scan.
		// If the user has already dismissed this finding, treat it as healthy regardless of
		// the upstream response — they've manually verified it's a false positive.
		$new_db_status = ( $is_broken && ! $is_log_removed ) ? 'broken' : $old_link_status;
		if ( $new_db_status !== $current_status ) {
			\BetterLinks\Helper::insert_link(
				array(
					'ID'          => $link_id,
					'link_status' => $new_db_status,
				),
				true
			);
			\BetterLinks\Helper::clear_query_cache();
			do_action( 'betterlinks/write_json_links' );
		}

		return $result;
	}

	public function send_mail() {
		$settings = json_decode( get_option( BETTERLINKS_PRO_REPORTING_OPTION_NAME ), true );
		if ( $settings['enable_reporting'] == true ) {
			$to      = ( isset( $settings['email'] ) && ! empty( $settings['email'] ) ? $settings['email'] : get_option( 'admin_email' ) );
			$headers = array( 'Content-Type: text/html; charset=UTF-8' );
			$subject = ( isset( $settings['email_subject'] ) && ! empty( $settings['email_subject'] ) ? $settings['email_subject'] : esc_html__( 'Summarized Report Of Broken Links On Your Site.', 'betterlinks-pro' ) );
			$body    = $this->get_email_body();
			return wp_mail( $to, $subject, $body, $headers );
		}
		return;
	}

	public function get_email_body() {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$betterlinks          = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}betterlinks", OBJECT );
		$logs                 = json_decode( get_option( 'betterlinkspro_broken_links_logs' ), true );
		if ( ! is_array( $logs ) ) {
			$logs = array();
		}
		$total_links          = count( $betterlinks );
		$scan_links           = count( $logs );
		$issue_found          = count(
			array_filter(
				is_array( $logs ) ? $logs : array(),
				function ( $log ) {
					if ( ! is_array( $log ) || empty( $log['status'] ) ) {
						return false;
					}
					// Prefer the new verdict field when present (logs written by the
					// post-classifier scanner). Falls back to the legacy "connection
					// failure" check so reports stay accurate for entries written by
					// pre-upgrade versions.
					if ( is_array( $log['status'] ) && isset( $log['status']['verdict'] ) ) {
						return 'broken' === $log['status']['verdict'];
					}
					if ( is_array( $log['status'] ) && isset( $log['status']['status_code'] ) ) {
						return true === $log['status']['status_code'];
					}
					return true === $log['status'];
				}
			)
		);
		$report_time          = gmdate( 'l, F jS, Y' );
		$logo                 = BETTERLINKS_PRO_ASSETS_URI . 'images/betterlinks-logo.png';
		$admin_brokenLink_url = admin_url( 'admin.php?page=betterlinks-settings' );
		$output               = '';
		ob_start();
		include BETTERLINKS_PRO_ROOT_DIR_PATH . 'includes/Admin/views/email-report-template.php';
		$output = ob_get_clean();
		return (string) $output;
	}
}
