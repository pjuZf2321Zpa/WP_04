<?php
namespace BetterLinksPro\Services;
if ( ! defined( 'ABSPATH' ) ) { exit; }

use BetterLinks\Helper;

// phpcs:disable PluginCheck.Security.DirectDB, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL

/**
 * Country Detection Service (BetterLinks Pro)
 *
 * IP-to-country lookups for click analytics and the Geography report, with caching
 * and an hourly outbound lookup budget. Moved from the free plugin, where it only
 * ran for Pro. The shared API token for ipinfo.io was removed; the remaining
 * providers are used in order.
 */
class CountryDetectionService {

    /**
     * Cache duration for IP-to-country mapping (24 hours)
     */
    const CACHE_DURATION = DAY_IN_SECONDS;

    /**
     * Ceiling on outbound provider lookups per hour, across the whole site.
     *
     * Cache hits do not count, and lookups are keyed on the real peer, so on a
     * normal site this tracks new unique visitors per hour. Deliberately set well
     * above real-world traffic: it is a runaway circuit breaker, not a functional
     * quota, and must not throttle geolocation on a busy site. Override with the
     * `betterlinks/geolocation/hourly_lookup_limit` filter (0 or less disables it).
     */
    const MAX_LOOKUPS_PER_HOUR = 5000;

    /**
     * Multiple API endpoints for fallback support
     * Tries APIs in order until one succeeds. HTTPS only: the visitor IP is part of the URL.
     */
    const API_ENDPOINTS = array(
        array(
            'url' => 'https://api.db-ip.com/v2/free/{IP}',
            'limit' => '500 requests per day',
            'country_field' => 'countryName',
            'country_code_field' => 'countryCode'
        ),
        array(
            'url' => 'https://free.freeipapi.com/api/json/{IP}',
            'limit' => '60 requests per minute',
            'country_field' => 'countryName',
            'country_code_field' => 'countryCode'
        )
    );

    /**
     * Get country information for an IP address
     *
     * Runs on the server only; visitors' browsers never call a geolocation service.
     *
     * @param string $ip The IP address to lookup
     * @return array|null Array with country_code and country_name, or null if not found
     */
    public static function get_country_by_ip( $ip ) {
        if ( empty( $ip ) || ! filter_var( $ip, FILTER_VALIDATE_IP ) ) {
            return null;
        }

        // Check cache first
        $cached_country = self::get_cached_country( $ip );
        if ( $cached_country !== null ) {
            return $cached_country;
        }

        // Try to fetch from APIs if not cached
        $country_data = self::fetch_country_from_api( $ip );
        if ( $country_data ) {
            // Cache the result
            self::cache_country( $ip, $country_data );
            return $country_data;
        }

        return null;
    }

    /**
     * Get cached country data for an IP
     * 
     * @param string $ip The IP address
     * @return array|null Cached country data or null
     */
    private static function get_cached_country( $ip ) {
        $cache_key = 'btl_country_' . md5( $ip );
        $cached = get_transient( $cache_key );
        
        if ( $cached && is_array( $cached ) ) {
            return $cached;
        }
        
        return null;
    }

    /**
     * Cache country data for an IP
     *
     * @param string $ip The IP address
     * @param array $country_data Country information
     */
    public static function cache_country( $ip, $country_data ) {
        $cache_key = 'btl_country_' . md5( $ip );
        set_transient( $cache_key, $country_data, self::CACHE_DURATION );
    }

    /**
     * Fetch country data from multiple APIs with fallback support
     *
     * @param string $ip The IP address
     * @return array|null Country data from API or null
     */
    private static function fetch_country_from_api( $ip ) {
        // Global circuit breaker on OUTBOUND lookups (cache misses only). Bounds
        // upstream provider quota burn and the number of per-IP transients this
        // plugin can create in an hour, no matter which caller triggers it.
        if ( ! self::consume_lookup_budget() ) {
            return null;
        }

        foreach ( self::API_ENDPOINTS as $api_config ) {
            $country_data = self::try_single_api( $ip, $api_config );
            if ( $country_data ) {
                return $country_data;
            }
        }
        return null;
    }

    /**
     * Fixed-window budget for outbound geolocation lookups.
     *
     * @return bool True when this lookup is allowed to proceed.
     */
    private static function consume_lookup_budget() {
        $limit  = (int) apply_filters( 'betterlinks/geolocation/hourly_lookup_limit', self::MAX_LOOKUPS_PER_HOUR );
        $window = HOUR_IN_SECONDS;

        if ( $limit <= 0 ) {
            return true; // Explicitly disabled by the site owner.
        }

        return \BetterLinksPro\Helper::consume_bucket( 'btl_geo_lookup_budget', $limit, $window );
    }

    /**
     * Try a single API endpoint
     *
     * @param string $ip The IP address
     * @param array $api_config API configuration
     * @return array|null Country data or null if failed
     */
    private static function try_single_api( $ip, $api_config ) {
        $rate_limit_key = 'btl_api_rate_limit_' . md5( $api_config['url'] );
        if ( get_transient( $rate_limit_key ) ) {
            return null;
        }

        $api_url = str_replace( '{IP}', $ip, $api_config['url'] );

        $response = wp_remote_get( $api_url, array(
            // Short: this can run while a visitor is being redirected.
            'timeout' => 3,
            'headers' => array(
                'User-Agent' => 'BetterLinks/' . BETTERLINKS_VERSION
            )
        ) );

        if ( is_wp_error( $response ) ) {
            return null;
        }

        $response_code = wp_remote_retrieve_response_code( $response );

        if ( $response_code === 429 ) {
            set_transient( $rate_limit_key, true, 5 * MINUTE_IN_SECONDS );
            return null;
        }

        if ( $response_code !== 200 ) {
            return null;
        }

        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body, true );

        if ( ! $data ) {
            return null;
        }

        if ( isset( $data['status'] ) && $data['status'] === 'fail' ) {
            return null;
        }

        $country_field = $api_config['country_field'];
        $country_code_field = $api_config['country_code_field'];

        if ( ! isset( $data[$country_field] ) || ! isset( $data[$country_code_field] ) ) {
            return null;
        }

        return array(
            'country_code' => sanitize_text_field( $data[$country_code_field] ),
            'country_name' => sanitize_text_field( $data[$country_field] ),
        );
    }

    /**
     * Get or create country record and return country_id
     *
     * @param string $country_code The country code
     * @param string $country_name The country name
     * @return int|null Country ID or null if failed
     */
    public static function get_or_create_country_id( $country_code, $country_name ) {
        global $wpdb;

        if ( empty( $country_code ) || empty( $country_name ) ) {
            return null;
        }

        $table_name = $wpdb->prefix . 'betterlinks_countries';

        // Try to get existing country
        $country = $wpdb->get_row( $wpdb->prepare(
            "SELECT id FROM {$table_name} WHERE country_code = %s",
            $country_code
        ), ARRAY_A );

        if ( $country ) {
            return (int) $country['id'];
        }

        // Create new country record
        $inserted = $wpdb->insert(
            $table_name,
            array(
                'country_code' => $country_code,
                'country_name' => $country_name,
            ),
            array( '%s', '%s' )
        );

        if ( $inserted ) {
            return (int) $wpdb->insert_id;
        }

        return null;
    }

    /**
     * Get country data from lookup table by country code
     *
     * @param string $country_code The country code
     * @return array|null Country data or null
     */
    public static function get_country_from_lookup_table( $country_code ) {
        global $wpdb;

        $table_name = $wpdb->prefix . 'betterlinks_countries';

        $country = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$table_name} WHERE country_code = %s",
            $country_code
        ), ARRAY_A );

        return $country ? $country : null;
    }

    /**
     * Get country data by country_id
     *
     * @param int $country_id The country ID
     * @return array|null Country data or null
     */
    public static function get_country_by_id( $country_id ) {
        global $wpdb;

        $table_name = $wpdb->prefix . 'betterlinks_countries';

        $country = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$table_name} WHERE id = %d",
            $country_id
        ), ARRAY_A );

        return $country ? $country : null;
    }

    /**
     * Get all countries from lookup table
     * 
     * @return array Array of all countries
     */
    public static function get_all_countries() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'betterlinks_countries';
        
        $countries = $wpdb->get_results(
            "SELECT * FROM {$table_name} ORDER BY country_name ASC",
            ARRAY_A
        );
        
        return $countries ? $countries : array();
    }

    /**
     * Clear country cache for an IP
     * 
     * @param string $ip The IP address
     */
    public static function clear_country_cache( $ip ) {
        $cache_key = 'btl_country_' . md5( $ip );
        delete_transient( $cache_key );
    }



    /**
     * Get country statistics for analytics
     *
     * @param string $from Start date
     * @param string $to End date
     * @param int|null $link_id Optional link ID to filter by
     * @param int|null $limit Optional row cap. Null returns every country, which
     *                        the geography map needs so it can shade the whole
     *                        world; the list view passes a small number.
     * @return array Country statistics
     */
    public static function get_country_statistics( $from, $to, $link_id = null, $limit = null ) {
        global $wpdb;

        $cache_key = 'btl_country_stats_' . md5( $from . $to . $link_id . '_' . $limit );
        $cached = get_transient( $cache_key );

        if ( $cached && is_array( $cached ) ) {
            return $cached;
        }

        $clicks_table = $wpdb->prefix . 'betterlinks_clicks';
        $countries_table = $wpdb->prefix . 'betterlinks_countries';

        $where_clause = "WHERE c.created_at BETWEEN %s AND %s AND c.country_id IS NOT NULL";
        $params = array( $from . ' 00:00:00', $to . ' 23:59:59' );

        if ( $link_id ) {
            $where_clause .= " AND c.link_id = %d";
            $params[] = $link_id;
        }

        $limit_clause = '';
        if ( null !== $limit ) {
            $limit_clause = ' LIMIT %d';
            $params[]     = (int) $limit;
        }

        // Placeholders supplied via $params; $clicks_table/$countries_table/$where_clause built from controlled internal values.
        // phpcs:disable WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $query = $wpdb->prepare(
            "SELECT co.country_code, co.country_name, COUNT(*) as clicks, COUNT(DISTINCT c.ip) as unique_clicks
             FROM {$clicks_table} c
             LEFT JOIN {$countries_table} co ON c.country_id = co.id
             {$where_clause}
             GROUP BY c.country_id, co.country_code, co.country_name
             ORDER BY clicks DESC{$limit_clause}",
            $params
        );
        // phpcs:enable WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare,WordPress.DB.PreparedSQL.InterpolatedNotPrepared

        $results = $wpdb->get_results( $query, ARRAY_A );

        set_transient( $cache_key, $results, self::CACHE_DURATION );
        return $results ? $results : array();
    }


}
