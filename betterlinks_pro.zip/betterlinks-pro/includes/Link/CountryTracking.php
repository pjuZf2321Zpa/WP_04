<?php
namespace BetterLinksPro\Link;
if ( ! defined( 'ABSPATH' ) ) { exit; }

use BetterLinksPro\Compat;
use BetterLinksPro\Services\CountryDetectionService;

/**
 * Records the visitor's country with each click.
 *
 * Countries are looked up on the server from the click's IP address, only while
 * Settings → Tracking → Enable Country Tracking is on. Plugs into the free
 * plugin's click pipeline through hooks it exposes:
 * - betterlinks/link/insert_click_arg: attach country code/name to the click.
 * - betterlinks/click/country_id: resolve the country row stored with the click,
 *   also for clicks replayed from clicks.json by cron.
 *
 * Older free plugins capture countries themselves, so nothing is registered there.
 */
class CountryTracking {

	/**
	 * Setting key in the free plugin's settings.
	 */
	const SETTING = 'enable_country_tracking';

	/**
	 * Option holding the default used until the setting is saved ('yes' or 'no').
	 */
	const DEFAULT_OPTION = 'betterlinkspro_country_tracking_default';

	public static function init() {
		if ( ! Compat::free_has_extension_api() ) {
			return;
		}
		$self = new self();
		add_filter( 'betterlinks/link/insert_click_arg', array( $self, 'add_country' ), 20, 2 );
		add_filter( 'betterlinks/click/country_id', array( $self, 'resolve_country_id' ), 10, 2 );
		add_filter( 'betterlinks/analytics/individual_clicks_select', array( $self, 'click_log_columns' ), 10, 2 );
	}

	/**
	 * Add the visitor country to the per-link click log.
	 *
	 * @param array $select  { columns, joins }.
	 * @param array $context Query context.
	 * @return array
	 */
	public function click_log_columns( $select, $context ) {
		global $wpdb;
		$select['columns'][] = 'co.country_code';
		$select['columns'][] = 'co.country_name';
		$select['joins'][]   = 'LEFT JOIN ' . $wpdb->prefix . 'betterlinks_countries co ON c.country_id = co.id';
		return $select;
	}

	/**
	 * Whether country tracking runs.
	 *
	 * @return bool
	 */
	public static function enabled() {
		$settings = get_option( BETTERLINKS_LINKS_OPTION_NAME, '[]' );
		if ( is_string( $settings ) ) {
			$settings = json_decode( $settings, true );
		}
		$enabled = is_array( $settings ) && array_key_exists( self::SETTING, $settings )
			? filter_var( $settings[ self::SETTING ], FILTER_VALIDATE_BOOLEAN )
			: self::default_enabled();

		/**
		 * Filters whether click countries are looked up.
		 *
		 * @param bool $enabled From Settings → Tracking → Enable Country Tracking.
		 */
		return (bool) apply_filters( 'betterlinkspro/country_tracking/enabled', $enabled );
	}

	/**
	 * Default while the setting has never been saved.
	 *
	 * Sites that already collected country data keep collecting it, so updating
	 * doesn't silently stop their Geography report. Everywhere else it is off
	 * until an admin turns it on. Decided once and stored.
	 *
	 * @return bool
	 */
	public static function default_enabled() {
		$stored = get_option( self::DEFAULT_OPTION, '' );
		if ( 'yes' !== $stored && 'no' !== $stored ) {
			global $wpdb;
			$table    = $wpdb->prefix . 'betterlinks_countries';
			// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- one-time existence check on the plugin's own table.
			$has_data = $table === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) )
				&& null !== $wpdb->get_var( "SELECT 1 FROM {$table} LIMIT 1" );
			// phpcs:enable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$stored   = $has_data ? 'yes' : 'no';
			update_option( self::DEFAULT_OPTION, $stored, false );
		}
		return 'yes' === $stored;
	}

	/**
	 * Add country code and name to a click about to be stored.
	 *
	 * @param array $arg  Click row data.
	 * @param array $data Link data used for tracking.
	 * @return array
	 */
	public function add_country( $arg, $data = array() ) {
		// No IP means the site disabled IP storage; never look anything up then.
		if ( ! is_array( $arg ) || empty( $arg['ip'] ) || isset( $arg['country_code'] ) || ! self::enabled() ) {
			return $arg;
		}

		$country = CountryDetectionService::get_country_by_ip( $arg['ip'] );
		if ( $country ) {
			$arg['country_code'] = $country['country_code'];
			$arg['country_name'] = $country['country_name'];
		}
		return $arg;
	}

	/**
	 * Country row ID to store with the click.
	 *
	 * @param int   $country_id Current value (0 = none).
	 * @param array $item       Click row data.
	 * @return int
	 */
	public function resolve_country_id( $country_id, $item ) {
		if ( (int) $country_id > 0 ) {
			return (int) $country_id;
		}
		if ( ! is_array( $item ) || empty( $item['country_code'] ) || empty( $item['country_name'] ) ) {
			return 0;
		}
		return (int) CountryDetectionService::get_or_create_country_id( $item['country_code'], $item['country_name'] );
	}
}
