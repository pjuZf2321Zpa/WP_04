<?php
namespace BetterLinksPro\Link;
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Open in App: send a tap from inside an in-app browser to the native app.
 *
 * A short link opened from Instagram, Facebook, TikTok and the like lands in
 * that app's own browser. A plain redirect cannot leave it: iOS Universal Links
 * fire only on the URL the visitor tapped, never on a 302 behind it, and the
 * iOS in-app browsers swallow programmatic navigations to app schemes. The
 * one method that works everywhere is a page with a real button whose href is
 * the app's own URL (`com.amazon.mobile.shopping.web://…`, `youtube://…`, or an
 * Android `intent://…` that names the package). That page is what this class
 * serves, from the point in free's `dispatch_redirect()` where the click is
 * already recorded and nothing has been sent yet.
 *
 * Per link, `dynamic_redirect` is:
 *
 *   { "type": "app",
 *     "value": [ { "link": "https://www.amazon.com/dp/B0…?tag=creator-20" } ],
 *     "extra": { "app": "auto", "when": "in_app" } }
 *
 * `value[0].link` is the URL to open in the app (defaults to the target URL),
 * `extra.app` picks the app or lets the host decide, and `extra.when` says who
 * sees the page: visitors inside an in-app browser (default), or every phone
 * and tablet browser. Desktop, bots and HEAD probes always get the redirect.
 *
 * Nothing in the click path changes: by the time this runs the click row,
 * robots and cache headers, GA/Pixel events and parameter forwarding are done.
 *
 * @see https://github.com/WPDevelopers/betterlinks-pro/issues/65
 */
class OpenInApp {

	/**
	 * The `dynamic_redirect.type` this class answers.
	 */
	const TYPE = 'app';

	/**
	 * Hook into the free plugin's dispatch point.
	 *
	 * Two hooks, so Pro works on its own: `betterlinks/link/send_powered_by_header`
	 * (free 3.1.4+) fires at the same point as the dedicated action — after the
	 * click is recorded and the headers are set, before the redirect — and is
	 * the one that answers on every current free release. The dedicated
	 * `betterlinks/link/dispatch_redirect` action (free 3.1.6+) is kept for
	 * when the header filter goes. Whichever fires first renders and exits.
	 * On a free older than 3.1.4 the type saves and the link simply redirects.
	 */
	public static function init() {
		add_filter( 'betterlinks/link/send_powered_by_header', array( __CLASS__, 'from_header_filter' ), 1, 2 );
		add_action( 'betterlinks/link/dispatch_redirect', array( __CLASS__, 'maybe_render' ), 10, 2 );
	}

	/**
	 * Compatibility entry point on free's powered-by header filter.
	 *
	 * @param bool  $send Whether free sends the header.
	 * @param array $data The link row, with `pf` (forwarded query) set.
	 * @return bool Unchanged.
	 */
	public static function from_header_filter( $send, $data = array() ) {
		if ( is_array( $data ) && self::rule_for( $data ) ) {
			self::maybe_render( self::target_url_for( $data ), $data );
		}
		return $send;
	}

	/**
	 * The redirect destination as free's dispatcher computes it: scheme added,
	 * Force HTTPS applied, forwarded parameters appended when the link
	 * forwards them.
	 *
	 * @param array $data The link row.
	 * @return string
	 */
	public static function target_url_for( $data ) {
		$url = \BetterLinksPro\Helper::addScheme( isset( $data['target_url'] ) ? (string) $data['target_url'] : '' );
		$pf  = isset( $data['pf'] ) ? (string) $data['pf'] : '';
		if ( '' !== $pf && ! empty( $data['param_forwarding'] ) && filter_var( $data['param_forwarding'], FILTER_VALIDATE_BOOLEAN ) ) {
			$url .= ( null === wp_parse_url( $url, PHP_URL_QUERY ) ? '?' : '&' ) . $pf;
		}
		return $url;
	}

	/**
	 * Serve the interstitial when this link and this visitor call for it.
	 *
	 * @param string $target_url Final destination, forwarded parameters applied.
	 * @param array  $data       The link row.
	 * @return void Exits after rendering; returns to let the redirect run.
	 */
	public static function maybe_render( $target_url, $data ) {
		$rule = self::rule_for( $data );
		if ( ! $rule ) {
			return;
		}

		// A metadata probe or a crawler is not a person holding a phone.
		if ( ! empty( $data['is_bot'] ) ) {
			return;
		}
		if ( isset( $_SERVER['REQUEST_METHOD'] ) && 'HEAD' === strtoupper( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) ) {
			return;
		}

		$ua     = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
		$client = self::detect( $ua );
		if ( ! self::applies( $client, $rule['when'] ) ) {
			return;
		}

		// The app opens the link's own target unless the admin typed another
		// URL. When they left the target as is, use the computed one so
		// forwarded parameters ride along into the app.
		$app_url = $rule['link'];
		if ( '' === $app_url || ( isset( $data['target_url'] ) && untrailingslashit( $app_url ) === untrailingslashit( (string) $data['target_url'] ) ) ) {
			$app_url = $target_url;
		}

		$plan = self::plan( $app_url, $target_url, $client, $rule['app'] );
		if ( ! $plan ) {
			return;
		}

		/**
		 * Filters the Open in App plan before it is rendered.
		 *
		 * Return an empty value to fall back to the normal redirect.
		 *
		 * @param array $plan   { app, label, open, web, os, in_app, auto }.
		 * @param array $data   The link row.
		 * @param array $client { os, in_app } as detected from the User-Agent.
		 */
		$plan = apply_filters( 'betterlinks/open_in_app/plan', $plan, $data, $client );
		if ( empty( $plan ) || empty( $plan['open'] ) ) {
			return;
		}

		self::render( $plan, $data );
		exit;
	}

	/**
	 * The Open in App rule stored on a link, or null when the link has none.
	 *
	 * @param array $data The link row; `dynamic_redirect` may be JSON or an array.
	 * @return array|null { link, app, when }.
	 */
	public static function rule_for( $data ) {
		if ( ! is_array( $data ) || empty( $data['dynamic_redirect'] ) ) {
			return null;
		}
		$dr = $data['dynamic_redirect'];
		if ( is_string( $dr ) ) {
			$dr = json_decode( $dr, true );
		}
		if ( ! is_array( $dr ) || ! isset( $dr['type'] ) || self::TYPE !== $dr['type'] ) {
			return null;
		}

		$link = '';
		if ( isset( $dr['value'][0]['link'] ) && is_string( $dr['value'][0]['link'] ) ) {
			$link = trim( $dr['value'][0]['link'] );
		}
		$extra = isset( $dr['extra'] ) && is_array( $dr['extra'] ) ? $dr['extra'] : array();
		$app   = isset( $extra['app'] ) && is_string( $extra['app'] ) ? sanitize_key( $extra['app'] ) : 'auto';
		$when  = isset( $extra['when'] ) && 'mobile' === $extra['when'] ? 'mobile' : 'in_app';

		return array(
			'link' => $link,
			'app'  => '' === $app ? 'auto' : $app,
			'when' => $when,
		);
	}

	/**
	 * What the visitor is holding and which app's browser they are in.
	 *
	 * A small purpose-built matcher rather than the bundled UA library: what
	 * matters here is the in-app marker each host app leaves in its User-Agent,
	 * which general-purpose parsers reduce to "Chrome" or "Safari".
	 *
	 * @param string $ua User-Agent header.
	 * @return array { os: ios|android|other, in_app: key or '' }
	 */
	public static function detect( $ua ) {
		$ua = (string) $ua;
		$os = 'other';
		if ( preg_match( '/iPhone|iPad|iPod/i', $ua ) ) {
			$os = 'ios';
		} elseif ( preg_match( '/Android/i', $ua ) ) {
			$os = 'android';
		}

		// Order matters: Instagram's UA also carries Facebook markers on some
		// builds, and Messenger's carries FB_IAB.
		$hosts = array(
			'instagram' => '/\bInstagram\b/i',
			'threads'   => '/\bBarcelona\b/i',
			'messenger' => '/FB_IAB\/MESSENGER|MessengerForiOS|\bMessengerLite\b/i',
			'facebook'  => '/\bFBAN\b|\bFBAV\b|\bFB_IAB\b|\bFBIOS\b|\bFB4A\b|\bFBSV\b/i',
			'tiktok'    => '/BytedanceWebview|musical_ly|\bTikTok\b|\bTTWebView\b/i',
			'snapchat'  => '/\bSnapchat\b/i',
			'x'         => '/\bTwitter(?:Android| for iPhone| for iPad)?\b/i',
			'linkedin'  => '/\bLinkedInApp\b/i',
			'pinterest' => '/\bPinterest\b/i',
			'telegram'  => '/\bTelegram\b/i',
			'line'      => '/\bLine\/[\d.]+/',
			'wechat'    => '/\bMicroMessenger\b/i',
		);

		/**
		 * Filters the in-app browser markers.
		 *
		 * @param array $hosts key => regex matched against the User-Agent.
		 */
		$hosts = apply_filters( 'betterlinks/open_in_app/in_app_browsers', $hosts );

		$in_app = '';
		foreach ( $hosts as $key => $pattern ) {
			if ( preg_match( $pattern, $ua ) ) {
				$in_app = (string) $key;
				break;
			}
		}

		if ( '' === $in_app && 'android' === $os && preg_match( '/;\s*wv\)/', $ua ) ) {
			$in_app = 'webview';
		}
		if ( '' === $in_app && 'ios' === $os && false !== stripos( $ua, 'AppleWebKit' ) && false === stripos( $ua, 'Safari/' ) && false === stripos( $ua, 'CriOS' ) && false === stripos( $ua, 'FxiOS' ) ) {
			$in_app = 'webview';
		}

		return array(
			'os'     => $os,
			'in_app' => $in_app,
		);
	}

	/**
	 * Whether this visitor should see the page under the link's `when` setting.
	 *
	 * @param array  $client From {@see detect()}.
	 * @param string $when   `in_app` or `mobile`.
	 * @return bool
	 */
	public static function applies( $client, $when ) {
		if ( ! in_array( $client['os'], array( 'ios', 'android' ), true ) ) {
			return false;
		}
		if ( 'mobile' === $when ) {
			return true;
		}
		return '' !== $client['in_app'];
	}

	/**
	 * The apps we know how to open, keyed by the value stored in `extra.app`.
	 *
	 * `hosts` is matched against the URL host with `www.` / `m.` removed.
	 * `ios` is a list of [ path regex, replacement ] tried in order, then
	 * `ios_default`, a template over {url} {host} {path} {query}. `android` is
	 * the package named in the intent URL; Android resolves the rest itself.
	 *
	 * @return array
	 */
	public static function apps() {
		$apps = array(
			'amazon'      => array(
				'label'       => 'Amazon',
				'hosts'       => '/(^|\.)amazon\.[a-z.]+$|^(amzn\.to|amzn\.eu|amzn\.asia|a\.co)$/',
				'ios_default' => 'com.amazon.mobile.shopping.web://{host}{path}{query}',
				'android'     => 'com.amazon.mShop.android.shopping',
			),
			'youtube'     => array(
				'label'        => 'YouTube',
				'hosts'        => '/(^|\.)(youtube\.com|youtu\.be)$/',
				'ios_callback' => array( __CLASS__, 'youtube_ios_url' ),
				'ios_default'  => 'youtube://www.youtube.com{path}{query}',
				'android'      => 'com.google.android.youtube',
			),
			'tiktok'      => array(
				'label'       => 'TikTok',
				'hosts'       => '/(^|\.)tiktok\.com$/',
				'ios_default' => '{url}',
				'android'     => 'com.zhiliaoapp.musically',
			),
			'spotify'     => array(
				'label'       => 'Spotify',
				'hosts'       => '/^open\.spotify\.com$/',
				'ios_default' => 'spotify:/{path}',
				'android'     => 'com.spotify.music',
			),
			'instagram'   => array(
				'label'       => 'Instagram',
				'hosts'       => '/(^|\.)instagram\.com$/',
				'ios'         => array(
					array( '#^/([A-Za-z0-9_.]+)/?$#', 'instagram://user?username=$1' ),
				),
				'ios_default' => '{url}',
				'android'     => 'com.instagram.android',
			),
			'apple_music' => array(
				'label'       => 'Apple Music',
				'hosts'       => '/^music\.apple\.com$/',
				'ios_default' => 'music://{host}{path}{query}',
				'android'     => 'com.apple.android.music',
			),
			'etsy'        => array(
				'label'       => 'Etsy',
				'hosts'       => '/(^|\.)etsy\.com$/',
				'ios'         => array(
					array( '#^/listing/(\d+)#', 'etsy://listing/$1' ),
					array( '#^/shop/([A-Za-z0-9_-]+)#', 'etsy://shop/$1' ),
				),
				'ios_default' => '{url}',
				'android'     => 'com.etsy.android',
			),
			'ebay'        => array(
				'label'       => 'eBay',
				'hosts'       => '/(^|\.)ebay\.[a-z.]+$/',
				'ios'         => array(
					array( '#^/itm/(?:[^/]+/)?(\d+)#', 'ebay://link?nav=item.view&id=$1' ),
				),
				'ios_default' => '{url}',
				'android'     => 'com.ebay.mobile',
			),
			'x'           => array(
				'label'       => 'X',
				'hosts'       => '/^(x\.com|twitter\.com|mobile\.twitter\.com)$/',
				'ios'         => array(
					array( '#^/[^/]+/status(?:es)?/(\d+)#', 'twitter://status?id=$1' ),
					array( '#^/([A-Za-z0-9_]+)/?$#', 'twitter://user?screen_name=$1' ),
				),
				'ios_default' => '{url}',
				'android'     => 'com.twitter.android',
			),
			'pinterest'   => array(
				'label'       => 'Pinterest',
				'hosts'       => '/(^|\.)pinterest\.[a-z.]+$|^pin\.it$/',
				'ios'         => array(
					array( '#^/pin/(\d+)#', 'pinterest://pin/$1' ),
				),
				'ios_default' => '{url}',
				'android'     => 'com.pinterest',
			),
		);

		/**
		 * Filters the apps Open in App knows. Add a key to support another app
		 * without a plugin update; see the shape above.
		 *
		 * @param array $apps
		 */
		return apply_filters( 'betterlinks/open_in_app/apps', $apps );
	}

	/**
	 * Which known app owns a URL, from its host.
	 *
	 * @param string $url
	 * @return string App key, or '' when none matches.
	 */
	public static function app_for_url( $url ) {
		$host = self::bare_host( $url );
		if ( '' === $host ) {
			return '';
		}
		foreach ( self::apps() as $key => $app ) {
			if ( ! empty( $app['hosts'] ) && preg_match( $app['hosts'], $host ) ) {
				return (string) $key;
			}
		}
		return '';
	}

	/**
	 * Work out what to open for this visitor.
	 *
	 * @param string $app_url  URL to open in the app (http/https).
	 * @param string $web_url  Where "Continue in browser" goes.
	 * @param array  $client   From {@see detect()}.
	 * @param string $app_pref `auto` or an app key.
	 * @return array|null { app, label, open, web, os, in_app, auto } or null for the normal redirect.
	 */
	public static function plan( $app_url, $web_url, $client, $app_pref = 'auto' ) {
		$parts = wp_parse_url( $app_url );
		if ( empty( $parts['host'] ) || empty( $parts['scheme'] ) || ! in_array( strtolower( $parts['scheme'] ), array( 'http', 'https' ), true ) ) {
			return null;
		}

		$apps = self::apps();
		$key  = ( 'auto' !== $app_pref && isset( $apps[ $app_pref ] ) ) ? $app_pref : self::app_for_url( $app_url );
		$app  = '' !== $key && isset( $apps[ $key ] ) ? $apps[ $key ] : null;

		$host  = $parts['host'] . ( isset( $parts['port'] ) ? ':' . $parts['port'] : '' );
		$path  = isset( $parts['path'] ) ? $parts['path'] : '/';
		$query = isset( $parts['query'] ) && '' !== $parts['query'] ? '?' . $parts['query'] : '';

		// Not an app we know: the useful move is out of the in-app browser into
		// the phone's own browser, where the site's own app links work again.
		// A visitor already in Safari or Chrome gains nothing from the page.
		$mode = $app ? 'app' : 'browser';
		if ( ! $app && '' === $client['in_app'] ) {
			return null;
		}

		if ( 'ios' === $client['os'] && ! $app ) {
			// Undocumented iOS 17+ scheme that hands the URL to Safari. Meta's
			// in-app browser lets it through on some versions and blocks it on
			// others, so the page always shows the ··· route beside it.
			$open = 'x-safari-' . strtolower( $parts['scheme'] ) . '://' . $host . $path . $query . ( isset( $parts['fragment'] ) ? '#' . $parts['fragment'] : '' );
		} elseif ( 'ios' === $client['os'] ) {
			$open = '';
			if ( ! empty( $app['ios_callback'] ) && is_callable( $app['ios_callback'] ) ) {
				$open = (string) call_user_func( $app['ios_callback'], $parts );
			}
			if ( '' === $open && ! empty( $app['ios'] ) && is_array( $app['ios'] ) ) {
				foreach ( $app['ios'] as $rule ) {
					if ( isset( $rule[0], $rule[1] ) && preg_match( $rule[0], $path, $m ) ) {
						// Fill $1, $2… from the captures; whatever else the
						// path carried is not part of the app URL.
						$open = preg_replace_callback(
							'/\$(\d+)/',
							function ( $mm ) use ( $m ) {
								return isset( $m[ (int) $mm[1] ] ) ? $m[ (int) $mm[1] ] : '';
							},
							$rule[1]
						);
						break;
					}
				}
			}
			if ( '' === $open ) {
				$tpl  = isset( $app['ios_default'] ) ? $app['ios_default'] : '{url}';
				$open = strtr(
					$tpl,
					array(
						'{url}'   => $app_url,
						'{host}'  => $host,
						'{path}'  => $path,
						'{query}' => $query,
					)
				);
			}
		} else {
			// Android resolves intent:// URLs itself: with a package it opens
			// that app or falls back; without one it picks whichever app has
			// verified the domain, so even an unknown host gets a fair try.
			$open = 'intent://' . $host . $path . $query . '#Intent;scheme=' . strtolower( $parts['scheme'] );
			if ( $app && ! empty( $app['android'] ) ) {
				$open .= ';package=' . $app['android'];
			}
			$open .= ';S.browser_fallback_url=' . rawurlencode( $web_url ) . ';end';
		}

		$label = $app && ! empty( $app['label'] ) ? $app['label'] : self::host_label( $parts['host'] );

		return array(
			'app'    => $key,
			'mode'   => $mode,
			'label'  => $label,
			'open'   => $open,
			'web'    => $web_url,
			'os'     => $client['os'],
			'in_app' => $client['in_app'],
			// Try the app as soon as the page loads, so a visitor who can be
			// sent straight there never has to tap. Android in-app browsers
			// honour that. iOS in-app browsers often refuse a launch nobody
			// tapped for, and then the page is the backup. Not in plain
			// Safari: there an app that isn't installed raises an error alert.
			'auto'   => 'android' === $client['os'] || '' !== $client['in_app'],
		);
	}

	/**
	 * The YouTube app URL for an iOS visitor.
	 *
	 * A video goes to `vnd.youtube://VIDEO_ID`, the most widely supported form
	 * of YouTube's scheme, whatever URL shape it came in (`watch?v=`, youtu.be,
	 * Shorts, live, embed); a start time rides along. Anything else — a
	 * channel, a handle, a playlist — keeps its web path on `youtube://`.
	 *
	 * @param array $parts `wp_parse_url()` of the URL.
	 * @return string
	 */
	public static function youtube_ios_url( $parts ) {
		$host = preg_replace( '/^(www|m)\./i', '', strtolower( isset( $parts['host'] ) ? (string) $parts['host'] : '' ) );
		$path = isset( $parts['path'] ) && '' !== $parts['path'] ? (string) $parts['path'] : '/';
		$args = array();
		if ( ! empty( $parts['query'] ) ) {
			wp_parse_str( (string) $parts['query'], $args );
		}

		$id = '';
		if ( 'youtu.be' === $host && preg_match( '#^/([A-Za-z0-9_-]{6,})#', $path, $m ) ) {
			$id = $m[1];
		} elseif ( '/watch' === untrailingslashit( $path ) && isset( $args['v'] ) && is_string( $args['v'] ) ) {
			$id = $args['v'];
		} elseif ( preg_match( '#^/(?:shorts|live|embed)/([A-Za-z0-9_-]{6,})#', $path, $m ) ) {
			$id = $m[1];
		}

		if ( '' !== $id && preg_match( '/^[A-Za-z0-9_-]{6,}$/', $id ) ) {
			$start = isset( $args['t'] ) && is_string( $args['t'] ) ? (int) $args['t'] : 0;
			return 'vnd.youtube://' . $id . ( $start > 0 ? '?t=' . $start : '' );
		}

		return 'youtube://www.youtube.com' . $path . ( ! empty( $parts['query'] ) ? '?' . $parts['query'] : '' );
	}

	/**
	 * What the host app calls its "leave this browser" menu item.
	 *
	 * @param string $key From {@see detect()}.
	 * @return string
	 */
	public static function escape_menu_label( $key ) {
		if ( in_array( $key, array( 'tiktok', 'telegram', 'snapchat', 'x', 'linkedin' ), true ) ) {
			return __( 'Open in browser', 'betterlinks-pro' );
		}
		return __( 'Open in external browser', 'betterlinks-pro' );
	}

	/**
	 * Human-readable in-app browser names for the page copy.
	 *
	 * @param string $key From {@see detect()}.
	 * @return string '' when unknown.
	 */
	public static function in_app_label( $key ) {
		$labels = array(
			'instagram' => 'Instagram',
			'threads'   => 'Threads',
			'messenger' => 'Messenger',
			'facebook'  => 'Facebook',
			'tiktok'    => 'TikTok',
			'snapchat'  => 'Snapchat',
			'x'         => 'X',
			'linkedin'  => 'LinkedIn',
			'pinterest' => 'Pinterest',
			'telegram'  => 'Telegram',
			'line'      => 'LINE',
			'wechat'    => 'WeChat',
		);
		return isset( $labels[ $key ] ) ? $labels[ $key ] : '';
	}

	/**
	 * Protocols `esc_url()` must accept for an app URL.
	 *
	 * `esc_url()` strips any scheme outside `wp_allowed_protocols()`, which
	 * would empty `intent:`, `youtube:` or `com.amazon.mobile.shopping.web:`.
	 *
	 * @param string $url
	 * @return string[]
	 */
	public static function allowed_protocols( $url ) {
		$protocols = wp_allowed_protocols();
		$scheme    = strtolower( (string) strstr( $url, ':', true ) );
		if ( '' !== $scheme && preg_match( '/^[a-z][a-z0-9+.\-]*$/', $scheme ) ) {
			$protocols[] = $scheme;
		}
		return array_values( array_unique( $protocols ) );
	}

	/**
	 * Render the interstitial.
	 *
	 * @param array $plan From {@see plan()}.
	 * @param array $data The link row.
	 * @return void
	 */
	public static function render( $plan, $data ) {
		$nonce = \BetterLinksPro\Link::get_csp_nonce();

		if ( ! headers_sent() ) {
			status_header( 200 );
			header( 'Content-Type: text/html; charset=' . get_bloginfo( 'charset' ) );
			// A hop page for one visitor, never a search result.
			header( 'X-Robots-Tag: noindex, nofollow', true );
			header( 'X-Content-Type-Options: nosniff' );
			header( 'Referrer-Policy: strict-origin-when-cross-origin' );

			/**
			 * Filters the Content-Security-Policy of the Open in App page.
			 *
			 * The page is self-contained; `https:` in script-src is for the
			 * admin's own tracking snippets echoed by `btl_header_redirect`,
			 * which load their vendors from there.
			 *
			 * @param string $policy
			 * @param string $nonce
			 */
			$policy = apply_filters(
				'betterlinks/open_in_app/csp_policy',
				"default-src 'none'; base-uri 'none'; form-action 'none'; "
				. "script-src 'nonce-" . $nonce . "' https:; "
				. "style-src 'nonce-" . $nonce . "'; "
				. "img-src 'self' https: data:; connect-src https:; font-src data:",
				$nonce
			);
			if ( '' !== trim( (string) $policy ) ) {
				header( 'Content-Security-Policy: ' . $policy );
			}
		}

		$link_id = isset( $data['ID'] ) ? (int) $data['ID'] : 0;
		$title   = isset( $data['link_title'] ) ? (string) $data['link_title'] : '';
		require BETTERLINKS_PRO_ROOT_DIR_PATH . '/includes/open-in-app.php';
	}

	/**
	 * Host with the `www.` / `m.` prefix dropped, lower-cased.
	 */
	private static function bare_host( $url ) {
		$host = wp_parse_url( $url, PHP_URL_HOST );
		if ( ! is_string( $host ) || '' === $host ) {
			return '';
		}
		return preg_replace( '/^(www|m)\./i', '', strtolower( $host ) );
	}

	/**
	 * "amazon.com" → "Amazon.com": a label for a host we have no entry for.
	 */
	private static function host_label( $host ) {
		$host = preg_replace( '/^(www|m)\./i', '', strtolower( (string) $host ) );
		return ucfirst( $host );
	}
}
