<?php
namespace BetterLinksPro\Admin;
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Notices {

    /**
     * Same rules as the free plugin's version notices; whichever plugin prints first wins.
     */
    const UPDATE_NOTICE_CSS = '.betterlinks-update-notice{position:relative;padding-right:38px}.betterlinks-update-notice .notice-dismiss{text-decoration:none}.betterlinks-compat{padding:2px 0 12px}.betterlinks-compat-row .betterlinks-compat{padding:12px 0}.betterlinks-compat__separator{margin:10px -12px 12px;border:0;border-top:1px solid #f0c33c}.betterlinks-compat__head{display:flex;align-items:center;gap:6px;font-size:14px;font-weight:600;color:#1d2327}.betterlinks-compat__head .dashicons{color:#e26f2a}.betterlinks-compat__body{max-width:fit-content;margin:6px 0 0 26px}.betterlinks-compat__text{margin:0 0 8px;line-height:1.6}.betterlinks-compat__versions{margin:0 0 8px;line-height:1.8}.betterlinks-compat__versions b{font-weight:600;color:#1d2327}@media (max-width:600px){.betterlinks-compat__body{margin-left:0}}';

    public static function init(){
        $self = new self();

        add_action('admin_notices', array($self, 'install_core_notice'));
        // Free constants exist only once every plugin file is loaded.
        add_action('plugins_loaded', function () use ($self) {
            $hook = \BetterLinksPro\Compat::free_has_extension_api() ? 'betterlinks_compatibility_notices' : 'btl_compatibity_notices';
            add_action($hook, array($self, 'free_update_notice'));
            add_action('admin_notices', array($self, 'free_update_notice'));
        });
        add_action('admin_init', array($self, 'dismiss_free_update_notice'));
        // After the free plugin's own in_admin_header callback adds its notices.
        add_action('in_admin_header', array($self, 'hide_free_new_feature_notice'), 20);
        add_action('load-plugins.php', array($self, 'register_free_plugin_row_alert'));
        add_action('wp_ajax_betterlinkspro/admin/install_core_installer', [$self, 'install_core_installer']);
        add_action( 'in_plugin_update_message-betterlinks-pro/betterlinks-pro.php' , [$self, 'on_plugin_update_message'], 11 );
    }
    /**
     * Plugin file of the installed BetterLinks free plugin, or '' when missing.
     *
     * Matched by text domain rather than by folder name, because sites rename
     * plugin folders.
     *
     * @return string
     */
    public static function get_free_plugin_file()
    {
        if ( ! function_exists( 'get_plugins' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $match = '';
        foreach ( get_plugins() as $file => $plugin ) {
            if ( isset( $plugin['TextDomain'] ) && 'betterlinks' === $plugin['TextDomain'] ) {
                // A site can keep a second, inactive copy (for example a backup folder); the active one is what runs.
                if ( is_plugin_active( $file ) ) {
                    return $file;
                }
                if ( '' === $match ) {
                    $match = $file;
                }
            }
        }
        return $match;
    }

    public function install_core_notice()
    {
        if(did_action('betterlinks_loaded') === 1) return;
        if ( ! current_user_can( 'activate_plugins' ) ) return;
        $free_plugin_file = self::get_free_plugin_file();
        if ( '' === $free_plugin_file && ! current_user_can( 'install_plugins' ) ) return;
        $button_text = '' !== $free_plugin_file ? __( 'Activate Now!', 'betterlinks-pro' ) : __( 'Install Now!', 'betterlinks-pro' );
        ?>
        <div class="error notice is-dismissible">
			<p>
				<?php
				echo wp_kses_post(
					sprintf(
						/* translators: %1$s: plugin name, %2$s: requires, %3$s: dependency name, %4$s: rest of message. */
						'<strong>%1$s</strong> %2$s <strong>%3$s</strong> %4$s',
						esc_html__( 'BetterLinks Pro', 'betterlinks-pro' ),
						esc_html__( 'requires', 'betterlinks-pro' ),
						esc_html__( 'BetterLinks', 'betterlinks-pro' ),
						esc_html__( 'core plugin to be installed. Please get the plugin now!', 'betterlinks-pro' )
					)
				);
				?>
				<button id="betterlinks-install-core" class="button button-primary"><?php echo esc_html( $button_text ); ?></button>
			</p>
		</div>
        <script type="text/javascript">
            jQuery(document).ready( function($) {
                $('#betterlinks-install-core').on('click', function (e) {
                    var self = $(this);
                    e.preventDefault();
                    self.addClass('install-now updating-message');
                    self.text('<?php echo esc_js( 'Installing...' ); ?>');

                    $.ajax({
                        url: '<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>',
                        type: 'post',
                        data: {
                            action: 'betterlinkspro/admin/install_core_installer',
                            _wpnonce: '<?php echo esc_js( wp_create_nonce( 'betterlinks_pro_install_core_installer' ) ); ?>',
                        },
                        success: function(response) {
                            self.text('<?php echo esc_js( 'Installed' ); ?>');
                            window.location.href = '<?php echo esc_url( admin_url( 'admin.php?page=betterlinks' ) ); ?>';
                        },
                        error: function(error) {
                            self.removeClass('install-now updating-message');
                            alert( error?.message || __('Something went wrong', 'betterlinks-pro') );
                        },
                        complete: function() {
                            self.attr('disabled', 'disabled');
                            self.removeClass('install-now updating-message');
                        }
                    });
                });
            } );
        </script>
        <?php
    }

    /**
     * Ask admins to update the free plugin when it predates the extension API.
     *
     * Nothing breaks in that state (the older free plugin still ships the
     * features Pro would otherwise provide); this only keeps both plugins on
     * the supported pairing. Rendered on BetterLinks screens only.
     */
    public function free_update_notice()
    {
        if ( ! current_user_can( 'update_plugins' ) || ! defined( 'BETTERLINKS_VERSION' ) || \BetterLinksPro\Compat::free_has_extension_api() ) {
            return;
        }
        if ( 'admin_notices' === current_action() ) {
            $screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
            if ( ! $screen || ! in_array( $screen->id, array( 'plugins', 'dashboard', 'plugins-network', 'dashboard-network' ), true ) ) {
                return;
            }
        }
        if ( get_user_meta( get_current_user_id(), 'betterlinks_pro_dismissed_free_update_notice', true ) === BETTERLINKS_VERSION ) {
            return;
        }
        $dismiss_url = wp_nonce_url( add_query_arg( 'betterlinks_pro_dismiss_free_update', '1' ), 'betterlinks_pro_dismiss_free_update' );
        $free_file   = self::get_free_plugin_file();
        $update_url  = add_query_arg( '' !== $free_file && self::has_update( $free_file ) ? array( 'plugin_status' => 'upgrade' ) : array(), self_admin_url( 'plugins.php' ) );
        self::print_update_notice_styles();
        printf(
            '<div class="notice notice-warning betterlinks-update-notice"><p><strong>%1$s</strong> %2$s <a href="%3$s">%4$s</a></p><a class="notice-dismiss" href="%5$s"><span class="screen-reader-text">%6$s</span></a></div>',
            esc_html__( 'BetterLinks needs an update.', 'betterlinks-pro' ),
            esc_html(
                sprintf(
                    /* translators: 1: installed BetterLinks version, 2: required BetterLinks version, 3: BetterLinks Pro version */
                    __( 'Update BetterLinks %1$s to %2$s or later to match BetterLinks Pro %3$s. Your data is kept.', 'betterlinks-pro' ),
                    BETTERLINKS_VERSION,
                    BETTERLINKS_PRO_MIN_FREE_VERSION,
                    BETTERLINKS_PRO_VERSION
                )
            ),
            esc_url( $update_url ),
            esc_html__( 'Update now', 'betterlinks-pro' ),
            esc_url( $dismiss_url ),
            esc_html__( 'Dismiss this notice', 'betterlinks-pro' )
        );
    }

    /**
     * Hide an older free plugin's "new feature" notice while BetterLinks needs an update,
     * so BetterLinks screens show one notice at a time.
     *
     * @return void
     */
    public function hide_free_new_feature_notice()
    {
        if ( ! defined( 'BETTERLINKS_VERSION' ) || ! current_user_can( 'update_plugins' ) || \BetterLinksPro\Compat::free_has_extension_api() ) {
            return;
        }
        global $wp_filter;
        if ( empty( $wp_filter['admin_notices'] ) || ! $wp_filter['admin_notices'] instanceof \WP_Hook ) {
            return;
        }
        foreach ( $wp_filter['admin_notices']->callbacks as $priority => $callbacks ) {
            foreach ( $callbacks as $callback ) {
                $function = $callback['function'];
                if ( is_array( $function ) && is_object( $function[0] ) && 'BetterLinks\Admin\Notice' === get_class( $function[0] ) && 'new_feature_notice' === $function[1] ) {
                    remove_action( 'admin_notices', $function, $priority );
                }
            }
        }
    }

    /**
     * Remember a dismissal of the BetterLinks update card for the installed BetterLinks version.
     *
     * @return void
     */
    public function dismiss_free_update_notice()
    {
        if ( empty( $_GET['betterlinks_pro_dismiss_free_update'] ) || ! current_user_can( 'update_plugins' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- nonce checked below.
            return;
        }
        check_admin_referer( 'betterlinks_pro_dismiss_free_update' );
        update_user_meta( get_current_user_id(), 'betterlinks_pro_dismissed_free_update_notice', defined( 'BETTERLINKS_VERSION' ) ? BETTERLINKS_VERSION : '' );
        wp_safe_redirect( remove_query_arg( array( 'betterlinks_pro_dismiss_free_update', '_wpnonce' ) ) );
        exit;
    }

    /**
     * Whether WordPress has an update available for a plugin.
     *
     * @param string $file Plugin file.
     * @return bool
     */
    private static function has_update( $file )
    {
        $updates = get_site_transient( 'update_plugins' );
        return is_object( $updates ) && isset( $updates->response[ $file ] );
    }

    /**
     * Print the version notice styles once per page.
     *
     * @param string $row_plugin_file Plugin whose row gets a notice row below it.
     * @return void
     */
    public static function print_update_notice_styles( $row_plugin_file = '' )
    {
        if ( ! did_action( 'betterlinks_update_notice_styles' ) ) {
            do_action( 'betterlinks_update_notice_styles' );
            echo '<style id="betterlinks-update-notice-styles">' . self::UPDATE_NOTICE_CSS . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static CSS.
        }
        if ( '' !== $row_plugin_file ) {
            printf(
                '<style>.plugins tr[data-plugin="%1$s"]:not(.plugin-update-tr) th,.plugins tr[data-plugin="%1$s"]:not(.plugin-update-tr) td{box-shadow:none}</style>',
                esc_attr( $row_plugin_file )
            );
        }
    }

    /**
     * On the Plugins screen, flag a BetterLinks older than this version of BetterLinks Pro needs.
     *
     * @return void
     */
    public function register_free_plugin_row_alert()
    {
        if ( ! current_user_can( 'update_plugins' ) ) {
            return;
        }
        $file = self::get_free_plugin_file();
        if ( '' === $file ) {
            return;
        }
        $plugins = get_plugins();
        $version = isset( $plugins[ $file ]['Version'] ) ? $plugins[ $file ]['Version'] : '';
        if ( '' === $version || version_compare( $version, BETTERLINKS_PRO_MIN_FREE_VERSION, '>=' ) ) {
            return;
        }
        add_action(
            'admin_head',
            function () use ( $file ) {
                self::print_update_notice_styles( $file );
            }
        );
        add_action(
            "in_plugin_update_message-{$file}",
            function () use ( $version ) {
                // Core prints this inside an open <p>; close it so the alert can use block markup.
                echo '</p>';
                self::render_free_compat_alert( $version, false );
                echo '<p class="hidden">';
            },
            20
        );
        add_action(
            "after_plugin_row_{$file}",
            function ( $plugin_file ) use ( $version ) {
                if ( self::has_update( $plugin_file ) ) {
                    return;
                }
                global $wp_list_table;
                $colspan = $wp_list_table instanceof \WP_List_Table ? $wp_list_table->get_column_count() : 4;
                $active  = is_network_admin() ? is_plugin_active_for_network( $plugin_file ) : is_plugin_active( $plugin_file );
                printf(
                    '<tr class="plugin-update-tr%1$s betterlinks-compat-row"><td colspan="%2$d" class="plugin-update colspanchange"><div class="update-message notice inline notice-warning notice-alt">',
                    $active ? ' active' : '',
                    (int) $colspan
                );
                self::render_free_compat_alert( $version, true );
                echo '</div></td></tr>';
            },
            20
        );
    }

    /**
     * Version mismatch alert for an outdated BetterLinks on the Plugins screen.
     *
     * @param string $installed  Installed BetterLinks version.
     * @param bool   $standalone True when rendered in its own row (no update offered).
     * @return void
     */
    private static function render_free_compat_alert( $installed, $standalone )
    {
        ?>
        <div class="betterlinks-compat">
            <?php if ( ! $standalone ) : ?>
                <hr class="betterlinks-compat__separator" />
            <?php endif; ?>
            <div class="betterlinks-compat__head">
                <span class="dashicons dashicons-warning" aria-hidden="true"></span>
                <?php esc_html_e( 'BetterLinks Compatibility Notice', 'betterlinks-pro' ); ?>
            </div>
            <div class="betterlinks-compat__body">
                <div class="betterlinks-compat__text">
                    <?php
                    printf(
                        /* translators: 1: installed BetterLinks Pro version, 2: required BetterLinks version */
                        esc_html__( 'BetterLinks Pro %1$s requires BetterLinks %2$s or later to ensure all features work seamlessly. We recommend updating BetterLinks to the latest version.', 'betterlinks-pro' ),
                        esc_html( BETTERLINKS_PRO_VERSION ),
                        esc_html( BETTERLINKS_PRO_MIN_FREE_VERSION )
                    );
                    ?>
                </div>
                <div class="betterlinks-compat__versions">
                    <div><?php esc_html_e( 'Installed version:', 'betterlinks-pro' ); ?> <b><?php echo esc_html( $installed ); ?></b></div>
                    <div>
                        <?php esc_html_e( 'Required version:', 'betterlinks-pro' ); ?> <b>
                        <?php
                        /* translators: %s: plugin version */
                        echo esc_html( sprintf( __( '%s or later', 'betterlinks-pro' ), BETTERLINKS_PRO_MIN_FREE_VERSION ) );
                        ?>
                        </b>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    public function install_core_installer()
    {
        check_ajax_referer('betterlinks_pro_install_core_installer', '_wpnonce');
        $free_plugin_file = self::get_free_plugin_file();
        if ( '' !== $free_plugin_file ) {
            if ( ! current_user_can( 'activate_plugins' ) ) wp_die( -1, 403 );
            $result = activate_plugin( $free_plugin_file, '', false );
            if (is_wp_error($result)) {
                wp_send_json_error($result->get_error_message());
            }
            if ($result === false) {
                wp_send_json_error(__('Plugin couldn\'t be activated.', 'betterlinks-pro'));
            }
            wp_send_json_success(__('BetterLinks is activated!', 'betterlinks-pro'));
            wp_die();
        }

        if ( ! current_user_can( 'install_plugins' ) || ! wp_is_file_mod_allowed( 'betterlinks_pro_install_core' ) ) {
            wp_die( -1, 403 );
        }
        $result = self::install_plugin('betterlinks');
        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        }
        wp_send_json_success(__('Plugin is installed successfully!', 'betterlinks-pro'));
        wp_die();
    }

    public function on_plugin_update_message($args){
        // 
    }
    
    public static function get_remote_plugin_data( $slug = '' ) {
		if ( empty( $slug ) ) {
			return new \WP_Error( 'empty_arg', __( 'Argument should not be empty.', 'betterlinks-pro' ) );
		}

		// Use core's plugins_api() instead of a hand-rolled POST to
		// http://api.wordpress.org + unserialize() of the raw body. The old path
		// was two vulnerabilities in one: it fetched over plain HTTP (MITM-able)
		// and then unserialize()d the response, so a network attacker could return
		// a crafted serialized object (PHP object injection) or simply swap
		// download_link — which install_plugin() feeds straight to Plugin_Upgrader,
		// turning a MITM into remote code execution. plugins_api() talks to the
		// HTTPS endpoint and returns a validated object with no object injection.
		if ( ! function_exists( 'plugins_api' ) ) {
			include_once ABSPATH . 'wp-admin/includes/plugin-install.php';
		}

		$plugin_data = plugins_api(
			'plugin_information',
			array(
				'slug'   => sanitize_key( $slug ),
				'fields' => array(
					'version' => false,
				),
			)
		);

		return $plugin_data;
	}

	public static function install_plugin( $slug = '', $active = true ) {
		if ( empty( $slug ) ) {
			return new \WP_Error( 'empty_arg', __( 'Argument should not be empty.', 'betterlinks-pro' ) );
		}

		include_once ABSPATH . 'wp-admin/includes/file.php';
		include_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		include_once ABSPATH . 'wp-admin/includes/class-automatic-upgrader-skin.php';

		$plugin_data = self::get_remote_plugin_data( $slug );

		if ( is_wp_error( $plugin_data ) ) {
			return $plugin_data;
		}

		$upgrader = new \Plugin_Upgrader( new \Automatic_Upgrader_Skin() );

		// install plugin
		$install = $upgrader->install( $plugin_data->download_link );

		if ( is_wp_error( $install ) ) {
			return $install;
		}

		// activate plugin
		if ( $install === true && $active ) {
			$active = activate_plugin( $upgrader->plugin_info(), '', false );

			if ( is_wp_error( $active ) ) {
				return $active;
			}

			return $active === null;
		}

		return $install;
	}
}
