<?php
namespace BetterLinksPro\Admin;
if ( ! defined( 'ABSPATH' ) ) { exit; }

use \BetterLinksPro\Helper;
class Assets {

	public function __construct() {
		add_action( 'admin_enqueue_scripts', array( $this, 'plugin_scripts' ) );
		add_action( 'enqueue_block_editor_assets', array( $this, 'block_editor_assets' ) );
	}

	/**
	 * Enqueue the AI Link Assistant panel inside the block (Gutenberg) editor.
	 */
	/**
	 * The AI Link Assistant feature ships in BetterLinks Pro 2.8.0+.
	 * Gate every entry point on this so older Pro builds defer to the free plugin's
	 * locked, Pro-badged teasers instead of exposing a half-wired feature.
	 */
	public static function is_link_genius_supported() {
		return defined( 'BETTERLINKS_PRO_VERSION' ) && version_compare( BETTERLINKS_PRO_VERSION, '2.8.0', '>=' );
	}

	public function block_editor_assets() {
		global $pagenow;
		if ( 'customize.php' === $pagenow ) {
			return;
		}

		// This bundle also gives the free plugin's Auto-Create Links sidebar its
		// per-post disable switch (free plugins with the extension API no longer
		// call Pro's AJAX themselves), so it loads whenever that sidebar may need
		// it and the AI panel is gated by `enabled` below.
		$needs_editor_bridge = \BetterLinksPro\Compat::free_has_extension_api();

		// Feature requires Pro 2.8.0+. Below that, the free teaser panel takes over.
		$genius_active = self::is_link_genius_supported();

		// Show AI Link Assistant on any post type edited in the block editor that has a
		// content editor — posts, pages, and custom post types alike. This hook only
		// fires in the block editor, so we just need an editor-backed content type;
		// internal/no-editor types (attachments, menu items, etc.) are excluded.
		// Filterable so sites can opt specific post types in or out.
		$post_type    = get_post_type();
		$is_supported = $post_type && post_type_supports( $post_type, 'editor' );

		/**
		 * Filters whether AI Link Assistant loads for the current post type.
		 *
		 * @param bool   $is_supported Whether the panel should load.
		 * @param string $post_type    Current post type being edited.
		 */
		$is_supported  = apply_filters( 'betterlinks/pro/link_genius_post_types', $is_supported, $post_type );
		$genius_active = $genius_active && $is_supported;

		$settings = get_option( BETTERLINKS_LINKS_OPTION_NAME, array() );
		if ( is_string( $settings ) ) {
			$settings = json_decode( $settings, true );
		}
		if ( ! is_array( $settings ) ) {
			$settings = array();
		}

		// Master toggle (default ON) — don't load the panel at all when disabled.
		$genius_enabled = ! isset( $settings['enable_link_genius'] ) || $settings['enable_link_genius'];
		$genius_active  = $genius_active && $genius_enabled;
		if ( ! $genius_active && ! $needs_editor_bridge ) {
			return;
		}
		$rescue_enabled = ! isset( $settings['enable_raw_link_rescue'] ) || $settings['enable_raw_link_rescue'];

		$asset_file = BETTERLINKS_PRO_ASSETS_DIR_PATH . 'js/betterlinkspro-gutenberg.core.min.asset.php';
		$script_file = BETTERLINKS_PRO_ASSETS_DIR_PATH . 'js/betterlinkspro-gutenberg.core.min.js';
		if ( ! file_exists( $asset_file ) || ! file_exists( $script_file ) ) {
			return;
		}

		$dependencies = include $asset_file;

		wp_enqueue_script(
			'betterlinkspro-gutenberg',
			BETTERLINKS_PRO_ASSETS_URI . 'js/betterlinkspro-gutenberg.core.min.js',
			array_merge( $dependencies['dependencies'], array( 'regenerator-runtime' ) ),
			$dependencies['version'],
			true
		);

		$prefix = ! empty( $settings['prefix'] ) ? $settings['prefix'] : '';

		wp_localize_script(
			'betterlinkspro-gutenberg',
			'betterLinksGeniusData',
			array(
				'rest_url'       => rest_url(),
				'nonce'          => wp_create_nonce( 'wp_rest' ),
				'namespace'      => BETTERLINKS_PRO_PLUGIN_SLUG . '/v1/',
				'site_url'       => apply_filters( 'betterlinks/site_url', site_url() ),
				'prefix'         => $prefix,
				'post_id'        => get_the_ID() ? get_the_ID() : 0,
				'enabled'        => $genius_active,
				'rescue_enabled' => (bool) $rescue_enabled,
				'settings_url'   => admin_url( 'admin.php?page=betterlinks-settings&advanced=true' ),
				// The AI Link Assistant backend (REST routes, AIClient) ships in the free
				// plugin. Surface its version so the editor panel can prompt a free update
				// when Pro was updated but free wasn't (otherwise the status check fails
				// and the panel shows a misleading "configure AI" warning).
				'free_version'   => defined( 'BETTERLINKS_VERSION' ) ? BETTERLINKS_VERSION : '',
				'plugins_url'    => admin_url( 'plugins.php' ),
			)
		);

		wp_set_script_translations( 'betterlinkspro-gutenberg', 'betterlinks-pro', BETTERLINKS_PRO_ROOT_DIR_PATH . 'languages/' );
	}

	/**
	 * Enqueue Files on Start Plugin
	 *
	 * @function plugin_script
	 */
	public function plugin_scripts( $hook ) {
		if ( \BetterLinks\Helper::plugin_page_hook_suffix( $hook ) ) {
			add_action(
				'wp_print_scripts',
				function () {
					$isSkip = apply_filters( 'BetterLinks/Admin/skip_no_conflict', false );

					if ( $isSkip ) {
						return;
					}

					global $wp_scripts;
					if ( ! $wp_scripts ) {
						return;
					}

					$pluginUrl = plugins_url();
					foreach ( $wp_scripts->queue as $script ) {
						$src = $wp_scripts->registered[ $script ]->src;
						if ( strpos( $src, $pluginUrl ) !== false && ! strpos( $src, BETTERLINKS_PLUGIN_SLUG ) !== false ) {
							wp_dequeue_script( $wp_scripts->registered[ $script ]->handle );
						}
					}
				},
				1
			);

			wp_enqueue_media();
			// Cache-bust per build: a hardcoded version string meant returning users kept
			// the previously cached betterlinks-pro.css after an update (so newly added
			// styles — e.g. the AI Link Assistant card — rendered unstyled). filemtime
			// changes whenever the file is rebuilt; fall back to the plugin version.
			$admin_css_path    = BETTERLINKS_PRO_ASSETS_DIR_PATH . 'css/betterlinks-pro.css';
			$admin_css_version = file_exists( $admin_css_path ) ? (string) filemtime( $admin_css_path ) : BETTERLINKS_PRO_VERSION;
			wp_enqueue_style( 'betterlinks-pro-admin-style', BETTERLINKS_PRO_ASSETS_URI . 'css/betterlinks-pro.css', array(), $admin_css_version, 'all' );

			$dependencies = include_once BETTERLINKS_PRO_ASSETS_DIR_PATH . 'js/betterlinkspro.core.min.asset.php';

			wp_enqueue_script(
				'betterlinkspro-admin-core',
				BETTERLINKS_PRO_ASSETS_URI . 'js/betterlinkspro.core.min.js',
				array_merge( $dependencies['dependencies'], array( 'betterlinks-admin-core', 'regenerator-runtime' ) ),
				$dependencies['version'],
				true
			);
			// Product analytics only for sites that opted in to usage data sharing.
			$allow_tracking = get_option( 'wpins_allow_tracking' );
			if ( is_array( $allow_tracking ) && ( isset( $allow_tracking['betterlinks'] ) || isset( $allow_tracking['betterlinks-pro'] ) ) ) {
				wp_enqueue_script(
					'betterlinks-analytics',
					'https://www.googletagmanager.com/gtag/js?id=G-9GLQ7H4QPG',
					array(),
					$dependencies['version'],
					true
				);
			}

			$user            = wp_get_current_user();
			$user_permission = json_decode( get_option( BETTERLINKS_PRO_ROLE_PERMISSON_OPTION_NAME, '{}' ), true );
			wp_localize_script(
				'betterlinkspro-admin-core',
				'betterLinksProGlobal',
				array(
					'betterlinkspro_nonce'      => wp_create_nonce( 'betterlinkspro_admin_nonce' ),
					'nonce'                     => wp_create_nonce( 'wp_rest' ),
					'rest_url'                  => rest_url(),
					'site_url'                  => site_url(),
					'namespace'                 => BETTERLINKS_PRO_PLUGIN_SLUG . '/v1/',
					'plugin_root_url'           => BETTERLINKS_PRO_PLUGIN_ROOT_URI,
					'plugin_root_path'          => BETTERLINKS_PRO_ROOT_DIR_PATH,
					'route_path'                => wp_parse_url( admin_url(), PHP_URL_PATH ),
					// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading admin page slug, not processing form data.
					'page'                      => isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '',
					'roles'                     => Helper::get_all_roles(),
					'user_can_write_links'      => Helper::current_user_can_do( 'writelinks', $user, $user_permission ),
					'user_can_view_links'       => Helper::current_user_can_do( 'viewlinks', $user, $user_permission ),
					'user_can_edit_links'       => Helper::current_user_can_do( 'editlinks', $user, $user_permission ),
					'user_can_edit_settings'    => Helper::current_user_can_do( 'editsettings', $user, $user_permission ),
					'user_can_edit_favorite'    => Helper::current_user_can_do( 'editFavorite', $user, $user_permission ),
					'user_can_check_analytics'  => Helper::current_user_can_do( 'checkanalytics', $user, $user_permission ),
					'user_can_manage_autolinks' => Helper::current_user_can_do( 'manageAutoliks', $user, $user_permission ),
					'user_can_manage_tags_categories' => Helper::current_user_can_do( 'manageTagsCategories', $user, $user_permission ),
					'user_can_manage_link_scanner' => Helper::current_user_can_do( 'manageLinkScanner', $user, $user_permission ),
					'user_can_manage_promo_cards' => Helper::current_user_can_do( 'managePromoCards', $user, $user_permission ),
					'user_can_manage_bio_links' => Helper::current_user_can_do( 'manageBioLinks', $user, $user_permission ),
					'user_can_manage_options'   => current_user_can( 'manage_options' ),
					'country_tracking_default'  => \BetterLinksPro\Link\CountryTracking::default_enabled(),
					'bio'                       => array(
						'category_id' => \BetterLinksPro\Frontend\LinkInBio\Manager::get_category_id(),
						'prefix'      => \BetterLinksPro\Frontend\LinkInBio\Manager::get_prefix(),
						'base_url'    => \BetterLinksPro\Frontend\LinkInBio\Manager::get_public_base_url(),
						// Site-wide branding switch, so the builder's preview and
						// per-page credit toggle can show that it is overridden.
						'branding'    => \BetterLinksPro\Frontend\LinkInBio\Manager::is_branding_enabled(),
					),
					'is_woocommerce_active'     => class_exists( 'WooCommerce' ),
					'qr_branding'               => json_decode( get_option( BETTERLINKS_PRO_QR_BRANDING_OPTION_NAME, '{}' ), true ),
					// Free plugin version, so Pro settings screens can apply
					// compatibility fallbacks against older free builds (e.g. layout
					// tweaks needed before the free redesign shipped in 2.4.14).
					'free_version'              => defined( 'BETTERLINKS_VERSION' ) ? BETTERLINKS_VERSION : '',
				)
			);
			wp_set_script_translations( 'betterlinkspro-admin-core', 'betterlinks-pro', BETTERLINKS_PRO_ROOT_DIR_PATH . 'languages/' );
		}
	}
}
