<?php
namespace BetterLinksPro\Admin;
if ( ! defined( 'ABSPATH' ) ) { exit; }

use BetterLinks\Helper as BetterLinksHelper;

class FullSiteScannerReport
{
    const OPTION_SCAN_SETTINGS = 'betterlinks_fullsite_report_scan_settings';
    const OPTION_EMAIL_SETTINGS = 'betterlinks_fullsite_report_email_settings';
    const OPTION_SCAN_LOGS = 'betterlinks_fullsite_report_scan_logs';
    const OPTION_LAST_STATS = 'betterlinks_fullsite_report_last_stats';
    const CRON_HOOK = 'betterlinks_fullsite_scan_report_event';

    /**
     * Initialize the scanner
     */
    public static function init()
    {
        $self = new self();
        add_action(self::CRON_HOOK, array($self, 'run_scheduled_scan'));
    }

    /**
     * Get available post types
     */
    public static function get_available_post_types()
    {
        $post_types = get_post_types(array('public' => true), 'objects');
        
        $options = array();
        foreach ($post_types as $post_type) {
            $options[] = array(
                'label' => $post_type->label,
                'value' => $post_type->name,
            );
        }
        
        return $options;
    }

    /**
     * Get scan settings
     */
    public static function get_scan_settings()
    {
        $defaults = array(
            'enable_scan' => false,
            'scan_mode' => 'weekly',
            'scan_day' => 'sunday',
            'scan_time' => '',
            'post_types' => array('post', 'page'),
        );
        
        $settings = get_option(self::OPTION_SCAN_SETTINGS, json_encode($defaults));
        return is_string($settings) ? json_decode($settings, true) : $settings;
    }

    /**
     * Save scan settings
     */
    public static function save_scan_settings($settings)
    {
        $allowed = array('enable_scan', 'scan_mode', 'scan_day', 'scan_month', 'scan_year', 'scan_time', 'post_types');
        $clean_settings = array();

        foreach ($allowed as $key) {
            if (isset($settings[$key])) {
                if ($key === 'enable_scan') {
                    $clean_settings[$key] = (bool) $settings[$key];
                } elseif ($key === 'post_types') {
                    $clean_settings[$key] = is_array($settings[$key]) ?
                        array_map('sanitize_text_field', $settings[$key]) :
                        array('post', 'page');
                } elseif ($key === 'scan_time') {
                    $clean_settings[$key] = \BetterLinksPro\Helper::normalize_scan_time($settings[$key]);
                } else {
                    $clean_settings[$key] = sanitize_text_field($settings[$key]);
                }
            }
        }

        update_option(self::OPTION_SCAN_SETTINGS, json_encode($clean_settings));
        self::reschedule_cron($clean_settings);

        return $clean_settings;
    }

    /**
     * Get email settings
     */
    public static function get_email_settings()
    {
        $defaults = array(
            'enable_reporting' => true,
            'email' => get_option('admin_email'),
            /* translators: %s: text value. */
            'email_subject' => sprintf(__('Full Site Link Scan Report - %s', 'betterlinks-pro'), get_bloginfo('name')),
        );
        
        $settings = get_option(self::OPTION_EMAIL_SETTINGS, json_encode($defaults));
        return is_string($settings) ? json_decode($settings, true) : $settings;
    }

    /**
     * Save email settings
     */
    public static function save_email_settings($settings)
    {
        $allowed = array('enable_reporting', 'email', 'email_subject');
        $clean_settings = array();
        
        foreach ($allowed as $key) {
            if (isset($settings[$key])) {
                if ($key === 'enable_reporting') {
                    $clean_settings[$key] = (bool) $settings[$key];
                } elseif ($key === 'email') {
                    $clean_settings[$key] = sanitize_email($settings[$key]);
                } else {
                    $clean_settings[$key] = sanitize_text_field($settings[$key]);
                }
            }
        }
        
        update_option(self::OPTION_EMAIL_SETTINGS, json_encode($clean_settings));
        
        return $clean_settings;
    }

    /**
     * Reschedule cron event
     */
    public static function reschedule_cron($settings)
    {
        // Clear existing cron
        wp_clear_scheduled_hook(self::CRON_HOOK);
        
        if (!isset($settings['enable_scan']) || !$settings['enable_scan']) {
            return;
        }
        
        $scan_mode  = isset($settings['scan_mode']) ? $settings['scan_mode'] : 'weekly';
        $scan_day   = isset($settings['scan_day']) ? $settings['scan_day'] : 'sunday';
        $scan_time  = isset($settings['scan_time']) ? $settings['scan_time'] : '12:00';
        $scan_month = isset($settings['scan_month']) ? $settings['scan_month'] : null;
        $scan_year  = isset($settings['scan_year']) ? $settings['scan_year'] : null;

        // Calculate timestamp for scheduled event
        $timestamp = self::calculate_schedule_timestamp($scan_mode, $scan_day, $scan_time, $scan_month, $scan_year);

        if ($timestamp) {
            wp_schedule_event($timestamp, $scan_mode, self::CRON_HOOK);
        }
    }

    /**
     * Calculate schedule timestamp
     */
    public static function calculate_schedule_timestamp($mode, $day, $time, $month = null, $year = null)
    {
        $now = current_time('timestamp');
        $date = new \DateTime('@' . $now);
        $date->setTimezone(new \DateTimeZone(wp_timezone_string()));

        // Normalize legacy/ISO formats, then parse "HH:MM"
        $time = \BetterLinksPro\Helper::normalize_scan_time($time);
        $time_parts = explode(':', $time);
        $hour = isset($time_parts[0]) ? (int) $time_parts[0] : 12;
        $minute = isset($time_parts[1]) ? (int) $time_parts[1] : 0;
        $date->setTime($hour, $minute, 0);

        // Handle different modes
        switch ($mode) {
            case 'hourly':
                $date->add(new \DateInterval('PT1H'));
                break;

            case 'twice_daily':
                $date->add(new \DateInterval('PT12H'));
                break;

            case 'daily':
                // For daily mode the user may pick specific weekdays in $day (comma list).
                // The cron still fires every day; run_scheduled_scan filters per-day.
                if ($date->getTimestamp() <= $now) {
                    $date->add(new \DateInterval('P1D'));
                }
                break;

            case 'monthly':
                $day_of_month = (int) $day;
                if ($day_of_month < 1 || $day_of_month > 31) {
                    $day_of_month = 1;
                }
                $target_month = (int) $month;
                $target_year  = (int) $year;
                if ($target_month < 1 || $target_month > 12) {
                    $target_month = (int) $date->format('n');
                }
                if ($target_year < 1970 || $target_year > 9999) {
                    $target_year = (int) $date->format('Y');
                }
                $days_in_month = (int) gmdate('t', mktime(0, 0, 0, $target_month, 1, $target_year));
                $use_day       = min($day_of_month, $days_in_month);
                $date->setDate($target_year, $target_month, $use_day);
                if ($date->getTimestamp() <= $now) {
                    $next_month = $target_month + 1;
                    $next_year  = $target_year;
                    if ($next_month > 12) {
                        $next_month = 1;
                        $next_year  = $target_year + 1;
                    }
                    $next_days = (int) gmdate('t', mktime(0, 0, 0, $next_month, 1, $next_year));
                    $date->setDate($next_year, $next_month, min($day_of_month, $next_days));
                }
                break;

            case 'weekly':
                // Schedule for specific day
                $day_num = array(
                    'sunday' => 0,
                    'monday' => 1,
                    'tuesday' => 2,
                    'wednesday' => 3,
                    'thursday' => 4,
                    'friday' => 5,
                    'saturday' => 6,
                );

                $target_day = isset($day_num[$day]) ? $day_num[$day] : 0;
                $current_day = (int) $date->format('w');

                // Days to add
                $days_ahead = $target_day - $current_day;
                if ($days_ahead < 0) {
                    $days_ahead += 7;
                } elseif ($days_ahead == 0 && $date->getTimestamp() <= $now) {
                    $days_ahead = 7;
                }

                $date->add(new \DateInterval('P' . $days_ahead . 'D'));
                break;
        }
        return $date->getTimestamp();
    }

    /**
     * Whether today's run should be skipped based on the saved schedule.
     * Used to gate run_scheduled_scan when scan_mode = daily-with-weekday-filter
     * or monthly-on-specific-date so cron drift doesn't fire on the wrong day.
     */
    public static function should_skip_today($settings)
    {
        if (empty($settings) || !is_array($settings)) {
            return false;
        }
        $mode     = isset($settings['scan_mode']) ? $settings['scan_mode'] : 'weekly';
        $scan_day = isset($settings['scan_day']) ? (string) $settings['scan_day'] : '';

        if ('daily' === $mode && '' !== $scan_day) {
            $allowed = array_filter(array_map('trim', explode(',', strtolower($scan_day))));
            if (!empty($allowed) && !in_array(strtolower(gmdate('l')), $allowed, true)) {
                return true;
            }
        }

        if ('monthly' === $mode) {
            $day_of_month = (int) $scan_day;
            if ($day_of_month >= 1 && $day_of_month <= 31) {
                $today         = (int) gmdate('j');
                $days_in_month = (int) gmdate('t');
                if ($today !== $day_of_month) {
                    if (!($day_of_month > $days_in_month && $today === $days_in_month)) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    /**
     * Run scheduled scan
     */
    public function run_scheduled_scan( $post_types = null, $force = false )
    {
        $settings = self::get_scan_settings();

        // Skip cron tick when today doesn't match the user's selected days/date.
        // Manual / force triggers always bypass this gate so users can scan on demand.
        if ( ! $force && self::should_skip_today( $settings ) ) {
            return;
        }

        // Use provided post types or get from settings
        if ( ! $post_types ) {
            $post_types = isset($settings['post_types']) && is_array($settings['post_types']) ? 
                $settings['post_types'] : 
                array('post', 'page');
        }
        
        // Ensure post_types is an array
        if ( is_string($post_types) ) {
            $post_types = array_map('trim', explode(',', $post_types));
        }
        
        // Get posts
        $posts = get_posts(array(
            'post_type' => $post_types,
            'posts_per_page' => -1,
            'post_status' => 'publish',
        ));
        
        $scan_results = array(
            'total_links' => 0,
            'links_scanned' => 0,
            'broken_links' => 0,
            'unauthorized_links' => 0,
            'forbidden_links' => 0,
            'links_data' => array(),
            'scan_time' => current_time('mysql'),
        );
        
        // Scan each post
        foreach ($posts as $post) {
            $content = $post->post_content;
            preg_match_all('/<a[^>]+href=["\']([^"\']+)["\'][^>]*>([^<]*)<\/a>/i', $content, $matches);
            
            if (isset($matches[1]) && !empty($matches[1])) {
                foreach ($matches[1] as $url) {
                    $scan_results['total_links']++;
                    
                    // Check link
                    $status = self::check_link($url);
                    $scan_results['links_scanned']++;
                    
                    $label = self::get_status_label($status);
                    
                    $scan_results['links_data'][] = array(
                        'link_url' => $url,
                        'post_id' => $post->ID,
                        'post_title' => $post->post_title,
                        'post_type' => $post->post_type,
                        'status_code' => $status,
                        'status_label' => $label,
                        'scan_time' => $scan_results['scan_time'],
                    );
                    
                    // Count by status
                    if ($status == 404) {
                        $scan_results['broken_links']++;
                    } elseif ($status == 401) {
                        $scan_results['unauthorized_links']++;
                    } elseif ($status == 403) {
                        $scan_results['forbidden_links']++;
                    }
                }
            }
        }
        
        // Save scan logs
        $scan_logs = get_option(self::OPTION_SCAN_LOGS, json_encode(array()));
        $logs = json_decode($scan_logs, true);
        if (!is_array($logs)) {
            $logs = array();
        }
        
        $logs[] = $scan_results;
        update_option(self::OPTION_SCAN_LOGS, json_encode($logs));

        // Persist a lightweight snapshot of the latest stats so the panel can
        // show the most recent CRON / force-run results across page loads.
        self::save_last_stats($scan_results);

        // Send email report if enabled
        $email_settings = self::get_email_settings();
        if (isset($email_settings['enable_reporting']) && $email_settings['enable_reporting']) {
            self::send_report_email($scan_results, $email_settings);
        }

        return $scan_results;
    }

    /**
     * Persist the latest scan stats snapshot.
     */
    public static function save_last_stats($scan_results)
    {
        $snapshot = array(
            'total_links'        => isset($scan_results['total_links']) ? (int) $scan_results['total_links'] : 0,
            'links_scanned'      => isset($scan_results['links_scanned']) ? (int) $scan_results['links_scanned'] : 0,
            'broken_links'       => isset($scan_results['broken_links']) ? (int) $scan_results['broken_links'] : 0,
            'unauthorized_links' => isset($scan_results['unauthorized_links']) ? (int) $scan_results['unauthorized_links'] : 0,
            'forbidden_links'    => isset($scan_results['forbidden_links']) ? (int) $scan_results['forbidden_links'] : 0,
            'scan_time'          => isset($scan_results['scan_time']) ? $scan_results['scan_time'] : current_time('mysql'),
            // Epoch alongside the display string, so "40 mins ago" needs no date parsing.
            'scan_timestamp'     => time(),
        );

        update_option(self::OPTION_LAST_STATS, wp_json_encode($snapshot), false);

        return $snapshot;
    }

    /**
     * Get the latest persisted stats snapshot.
     */
    public static function get_last_stats()
    {
        $defaults = array(
            'total_links'        => 0,
            'links_scanned'      => 0,
            'broken_links'       => 0,
            'unauthorized_links' => 0,
            'forbidden_links'    => 0,
            'scan_time'          => '',
            'scan_timestamp'     => 0,
        );

        $raw = get_option(self::OPTION_LAST_STATS, '');
        if (empty($raw)) {
            return $defaults;
        }

        $stats = is_string($raw) ? json_decode($raw, true) : $raw;
        if (!is_array($stats)) {
            return $defaults;
        }

        return array_merge($defaults, $stats);
    }

    /**
     * Check single link
     */
    public static function check_link($url)
    {
        $args = array(
            'timeout' => 10,
            // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
            'sslverify' => apply_filters('https_local_ssl_verify', false),
        );
        
        // wp_safe_remote_get() refuses loopback, private and reserved hosts, so
        // links in published content cannot be used to probe the internal network.
        $response = wp_safe_remote_get($url, $args);
        
        if (is_wp_error($response)) {
            return 0;
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        return (int) $status_code;
    }

    /**
     * Get status label
     */
    public static function get_status_label($code)
    {
        switch ($code) {
            case 200:
                return __('Active', 'betterlinks-pro');
            case 301:
            case 302:
                return __('Redirect', 'betterlinks-pro');
            case 401:
                return __('Unauthorized', 'betterlinks-pro');
            case 403:
                return __('Forbidden', 'betterlinks-pro');
            case 404:
                return __('Broken', 'betterlinks-pro');
            case 500:
                return __('Server Error', 'betterlinks-pro');
            default:
                return __('Unknown', 'betterlinks-pro');
        }
    }

    /**
     * Send report email
     */
    public static function send_report_email($scan_results, $email_settings)
    {
        $to = $email_settings['email'];
        $subject = $email_settings['email_subject'];
        
        // Build email body using template
        $body = self::build_email_body($scan_results);
        
        $headers = array('Content-Type: text/html; charset=UTF-8');
        
        return wp_mail($to, $subject, $body, $headers);
    }

    /**
     * Build email body using template file
     */
    public static function build_email_body($scan_results)
    {
        // Prepare variables for template
        $total_links = $scan_results['total_links'];
        $broken_links_count = $scan_results['broken_links'];
        $unauthorized_count = $scan_results['unauthorized_links'];
        $forbidden_count = $scan_results['forbidden_links'];
        $report_time = date_i18n('l, F jS, Y', strtotime($scan_results['scan_time']));
        $logo = BETTERLINKS_PRO_ASSETS_URI . 'images/betterlinks-logo.png';
        $admin_url = admin_url('admin.php?page=betterlinks-settings&tab=fullsite-scanner');
        
        // Get broken links
        $broken_links = array_filter($scan_results['links_data'], function($link) {
            return $link['status_code'] == 404;
        });
        $broken_links = array_values($broken_links); // Re-index array
        
        // Start output buffering and include template
        ob_start();
        include BETTERLINKS_PRO_ROOT_DIR_PATH . 'includes/Admin/views/fullsite-report-email-template.php';
        $output = ob_get_clean();
        
        return (string) $output;
    }
}
