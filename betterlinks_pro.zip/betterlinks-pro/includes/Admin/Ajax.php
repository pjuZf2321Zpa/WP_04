<?php
// @-collapse
namespace BetterLinksPro\Admin;
if ( ! defined( 'ABSPATH' ) ) { exit; }

use BetterLinks\Cron;
use BetterLinksPro\Helper;

class Ajax {

	use \BetterLinksPro\Traits\BrokenLinks;
	use \BetterLinksPro\Traits\Keywords;

	/**
	 * Unix timestamp of the last full-site scanner write. Not autoloaded.
	 */
	const FULLSITE_LAST_SCAN_OPTION = 'betterlinkspro_fullsite_last_scan_time';

	/**
	 * Unix timestamp of the last BetterLinks broken-link scan write. Not autoloaded.
	 */
	const BROKENLINK_LAST_RUN_OPTION = 'betterlinkspro_broken_link_last_run';

	/**
	 * Single-use credential for the force-scan loopback. Not autoloaded.
	 */
	const FORCE_SCAN_TOKEN_OPTION = 'betterlinkspro_force_scan_token';

	/**
	 * How long an unused force-scan token stays valid.
	 */
	const FORCE_SCAN_TOKEN_TTL = 6 * HOUR_IN_SECONDS;

	/**
	 * Mint a single-use token for the next force-scan loopback hop.
	 *
	 * The batch runner reaches itself through a cookieless `wp_remote_post()` to
	 * admin-ajax.php, so its handler has to stay registered on `nopriv` — a
	 * capability check there would reject the plugin's own loopback and break the
	 * feature. This token is what distinguishes that loopback from an outside
	 * caller. Only the hash is persisted, so reading the option back out of the
	 * database does not yield a usable credential.
	 *
	 * @return string Raw token to place in the loopback body.
	 */
	public static function issue_force_scan_token() {
		$token = wp_generate_password( 43, false, false );
		update_option(
			self::FORCE_SCAN_TOKEN_OPTION,
			array(
				'hash'    => wp_hash( $token ),
				'expires' => time() + self::FORCE_SCAN_TOKEN_TTL,
			),
			false
		);
		return $token;
	}

	/**
	 * Verify and consume a force-scan loopback token.
	 *
	 * Consuming on success makes the token strictly single-use: each hop mints the
	 * credential for the next one, so a token that leaks is already spent.
	 *
	 * @param string $token Raw token from the request.
	 * @return bool
	 */
	public static function consume_force_scan_token( $token ) {
		$stored = get_option( self::FORCE_SCAN_TOKEN_OPTION );

		if ( ! is_array( $stored ) || empty( $stored['hash'] ) || empty( $stored['expires'] ) ) {
			return false;
		}

		if ( time() > (int) $stored['expires'] ) {
			delete_option( self::FORCE_SCAN_TOKEN_OPTION );
			return false;
		}

		if ( ! is_string( $token ) || '' === $token ) {
			return false;
		}

		// hash_equals() so a wrong token cannot be narrowed down by timing.
		if ( ! hash_equals( (string) $stored['hash'], wp_hash( $token ) ) ) {
			return false;
		}

		delete_option( self::FORCE_SCAN_TOKEN_OPTION );
		return true;
	}

	public static function init() {
		$self = new self();
		// Country analytics: older free plugins still register these handlers.
		if ( \BetterLinksPro\Compat::free_has_extension_api() ) {
			add_action( 'wp_ajax_betterlinks/admin/update_click_country', array( $self, 'update_click_country' ) );
			add_action( 'wp_ajax_betterlinks/admin/update_clicks_country_by_ip', array( $self, 'update_clicks_country_by_ip' ) );
		}
		add_action( 'wp_ajax_betterlinkspro/admin/get_role_management', array( $self, 'get_role_management' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/role_management', array( $self, 'role_management' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/get_external_analytics', array( $self, 'get_external_analytics' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/external_analytics', array( $self, 'external_analytics' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/analytics', array( $self, 'analytics' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/get_auto_link_create_settings', array( $self, 'get_auto_link_create_settings' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/set_auto_link_create_settings', array( $self, 'set_auto_link_create_settings' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/get_auto_link_disable_ids', array( $self, 'get_auto_link_disable_ids' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/set_auto_link_disable_ids', array( $self, 'set_auto_link_disable_ids' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/get_links', array( $self, 'get_links' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/get_broken_links_data', array( $self, 'get_broken_links_data' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/run_instant_broken_link_checker', array( $self, 'run_instant_broken_link_checker' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/delete_broken_link_checker_logs', array( $self, 'delete_broken_link_checker_logs' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/run_broken_links_checker', array( $self, 'run_broken_links_checker' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/run_single_broken_link_checker', array( $self, 'run_single_broken_link_checker' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/update_broken_link', array( $self, 'update_broken_link' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/remove_broken_link', array( $self, 'remove_broken_link' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/remove_multi_broken_link', array( $self, 'remove_multi_broken_link' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/get_broken_link_settings', array( $self, 'get_broken_link_settings' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/save_broken_link_settings', array( $self, 'save_broken_link_settings' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/get_split_test_analytics', array( $self, 'get_split_test_analytics' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/get_reporting_settings', array( $self, 'get_reporting_settings' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/saved_reporting_settings', array( $self, 'saved_reporting_settings' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/test_report_mail', array( $self, 'test_report_mail' ) );
		// filter
		add_filter( 'betterlinks/admin/current_user_can_edit_settings', array( $self, 'current_user_can_edit_settings' ) );
		add_filter( 'betterlinkspro/admin/current_user_can_edit_settings', array( $self, 'current_user_can_edit_settings' ) );
		// API Fallbck Ajax
		add_action( 'wp_ajax_betterlinks/admin/get_all_keywords', array( $self, 'get_all_keywords' ) );
		add_action( 'wp_ajax_betterlinks/admin/create_keyword', array( $self, 'create_keyword' ) );
		add_action( 'wp_ajax_betterlinks/admin/update_keyword', array( $self, 'update_keyword' ) );
		add_action( 'wp_ajax_betterlinks/admin/delete_keyword', array( $self, 'delete_keyword' ) );
		// Keywords export/import - Pro features
		add_action( 'wp_ajax_betterlinks/admin/export_keywords', array( $self, 'export_keywords' ) );
		add_action( 'wp_ajax_betterlinks/admin/import_keywords', array( $self, 'import_keywords' ) );

		// Password Protection requests
		add_action( 'wp_ajax_betterlinkspro/admin/create_links_password', array( $self, 'create_links_password' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/fetch_links_password', array( $self, 'fetch_links_password' ) );

		// Customize Meta Tags
		add_action( 'wp_ajax_betterlinkspro/admin/fetch_meta_tags', array( $self, 'fetch_meta_tags' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/add_meta_tags', array( $self, 'add_meta_tags' ) );
		
		// Full site link scanner 
		add_action( 'wp_ajax_betterlinkspro/admin/get_full_site_links', array( $self, 'get_full_site_links' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/get_all_used_links_in_post_by_id', array( $self, 'get_all_used_links_in_post_by_id' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/clear_fullsite_broken_links', array( $self, 'clear_fullsite_broken_links' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/recheck_fullsite_link', array( $self, 'recheck_fullsite_link' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/delete_fullsite_scan_logs', array( $self, 'delete_fullsite_scan_logs' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/run_broken_link_checker', array( $self, 'run_broken_link_checker' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/get_fullsite_broken_link_settings', array( $self, 'get_fullsite_broken_link_settings' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/save_fullsite_broken_link_settings', array( $self, 'save_fullsite_broken_link_settings' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/save_qr_branding', array( $self, 'save_qr_branding' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/run_single_link_checker', array( $self, 'run_single_link_checker' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/remove_single_scan_log', array( $self, 'remove_single_scan_log' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/start_force_fullsite_scan', array( $self, 'start_force_fullsite_scan' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/get_force_scan_status', array( $self, 'get_force_scan_status' ) );
		add_action( 'wp_ajax_nopriv_betterlinkspro/force_fullsite_scan_background', array( $self, 'trigger_force_fullsite_scan_background' ) );
		add_action( 'wp_ajax_betterlinkspro/force_fullsite_scan_background', array( $self, 'trigger_force_fullsite_scan_background' ) );

		// Custom Short Domain
		add_action( 'wp_ajax_betterlinkspro/admin/check_custom_domain_dns', array( $self, 'check_custom_domain_dns' ) );

		// Full Site Link Scanner Report with Email
		add_action( 'wp_ajax_betterlinkspro/admin/get_available_post_types', array( $self, 'get_available_post_types' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/get_fullsite_report_scan_settings', array( $self, 'get_fullsite_report_scan_settings' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/save_fullsite_report_scan_settings', array( $self, 'save_fullsite_report_scan_settings' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/get_fullsite_report_email_settings', array( $self, 'get_fullsite_report_email_settings' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/save_fullsite_report_email_settings', array( $self, 'save_fullsite_report_email_settings' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/test_fullsite_report_mail', array( $self, 'test_fullsite_report_mail' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/start_fullsite_report_scan', array( $self, 'start_fullsite_report_scan' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/get_fullsite_report_posts', array( $self, 'get_fullsite_report_posts' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/get_fullsite_report_post_links', array( $self, 'get_fullsite_report_post_links' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/check_fullsite_report_link', array( $self, 'check_fullsite_report_link' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/force_run_fullsite_report_scan', array( $self, 'force_run_fullsite_report_scan' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/get_fullsite_report_last_stats', array( $self, 'get_fullsite_report_last_stats' ) );
		add_action( 'wp_ajax_betterlinkspro/admin/save_fullsite_report_last_stats', array( $self, 'save_fullsite_report_last_stats' ) );
	}

	public function check_custom_domain_dns() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! apply_filters( 'betterlinkspro/admin/current_user_can_edit_settings', current_user_can( 'manage_options' ) ) ) {
			wp_die( "You don't have permission to do this" );
		}

		$custom_domain = isset( $_POST['url'] ) ? sanitize_url( wp_unslash( $_POST['url'] ) ) : '';

		// SSRF guard: this dereferences a caller-supplied URL server-side. Only
		// public http(s) targets are allowed; wp_http_validate_url() rejects
		// loopback, private, link-local (169.254 metadata), CGNAT and reserved
		// hosts, so an editsettings role cannot probe the internal network here.
		$domain_scheme = strtolower( (string) wp_parse_url( $custom_domain, PHP_URL_SCHEME ) );
		if ( '' === $custom_domain || ! in_array( $domain_scheme, array( 'http', 'https' ), true ) || ! wp_http_validate_url( $custom_domain ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid domain URL.', 'betterlinks-pro' ) ), 400 );
		}

		// Read the first response only: get_headers() followed up to 20 redirects,
		// and only the first hop had been validated above.
		$response = wp_safe_remote_head( $custom_domain, array( 'redirection' => 0, 'timeout' => 10 ) );
		$location = is_wp_error( $response ) ? '' : (string) wp_remote_retrieve_header( $response, 'location' );
		$parse_location = Helper::parse_url( $location );
		$location_host  = Helper::get_url_component( $parse_location, 'host' );

		$parse_site_url = Helper::parse_url( site_url() );
		$site_url_host  = Helper::get_url_component( $parse_site_url, 'host' );

		// $site_ip = (isset( $_SERVER['SERVER_ADDR'] ) && filter_var( $_SERVER['SERVER_ADDR'], FILTER_VALIDATE_IP )) ? sanitize_text_field( $_SERVER['SERVER_ADDR'] ) : ( null !== gethostbyname(site_url()) && filter_var( gethostbyname(site_url()), FILTER_VALIDATE_IP ) ? gethostbyname(site_url()) : false);

		$site_ip = null !== gethostbyname( $site_url_host ) && filter_var( gethostbyname( $site_url_host ), FILTER_VALIDATE_IP ) ? gethostbyname( $site_url_host ) : false;

		$site_ip = ! empty( $site_ip ) ? $site_ip : ( ( isset( $_SERVER['SERVER_ADDR'] ) && filter_var( wp_unslash( $_SERVER['SERVER_ADDR'] ), FILTER_VALIDATE_IP ) ) ? sanitize_text_field( wp_unslash( $_SERVER['SERVER_ADDR'] ) ) : false );

		wp_send_json_error(
			array(
				'result'  => $location_host === $site_url_host,
				'site_ip' => $site_ip,
			),
		);
	}

	public function get_fullsite_broken_link_settings() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! $this->current_user_can_manage_link_scanner() ) {
			wp_die( "You don't have permission to do this." );
		}
		$results = get_option( BETTERLINKS_PRO_FULLSITE_BROKEN_LINK_OPTION_NAME, '{}' );
		
		$post_types = Helper::get_all_post_types();
		unset( $post_types['attachment'] );
		$post_types = array_merge(array('all' => 'all'), $post_types);
		
		wp_send_json_success( array(
			'settings' => $results,
			'post_types' => $post_types
		) );
	}

	public function save_fullsite_broken_link_settings() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! $this->current_user_can_manage_link_scanner() ) {
			wp_die( "You don't have permission to do this." );
		}
		$data = \BetterLinks\Helper::fresh_ajax_request_data( $_POST );
		$data = \BetterLinks\Helper::sanitize_text_or_array_field( $data );
		$data = wp_json_encode( $data );
		update_option( BETTERLINKS_PRO_FULLSITE_BROKEN_LINK_OPTION_NAME, $data );
		delete_option(BETTERLINKS_PRO_FULLSITE_BROKEN_LINK_LOGS);
		wp_send_json_success( $data );
	}

	/**
	 * Persist the global brand-QR config (logo + colors) shown on every link's
	 * QR code. Mirrors the fullsite settings save: nonce + capability guarded,
	 * each field sanitized to its expected type before storing as JSON.
	 */
	public function save_qr_branding() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( "You don't have permission to do this." );
		}

		$size = isset( $_POST['logoSize'] ) ? sanitize_text_field( wp_unslash( $_POST['logoSize'] ) ) : 'medium';
		if ( ! in_array( $size, array( 'small', 'medium', 'large' ), true ) ) {
			$size = 'medium';
		}

		$pattern = isset( $_POST['patternStyle'] ) ? sanitize_text_field( wp_unslash( $_POST['patternStyle'] ) ) : 'square';
		if ( ! in_array( $pattern, array( 'square', 'rounded', 'blob', 'dots', 'hearts', 'diamonds' ), true ) ) {
			$pattern = 'square';
		}

		$fg = isset( $_POST['fgColor'] ) ? sanitize_hex_color( wp_unslash( $_POST['fgColor'] ) ) : '';
		$bg = isset( $_POST['bgColor'] ) ? sanitize_hex_color( wp_unslash( $_POST['bgColor'] ) ) : '';

		$branding = array(
			'enabled'  => ! empty( $_POST['enabled'] ) && '0' !== $_POST['enabled'],
			'fgColor'  => $fg ? $fg : '#111827',
			'bgColor'  => $bg ? $bg : '#ffffff',
			'logoSize' => $size,
			'patternStyle' => $pattern,
			'margin'   => ! empty( $_POST['margin'] ) && '0' !== $_POST['margin'],
			'logo'     => array(
				'url' => isset( $_POST['logo_url'] ) ? esc_url_raw( wp_unslash( $_POST['logo_url'] ) ) : '',
				'id'  => isset( $_POST['logo_id'] ) ? absint( $_POST['logo_id'] ) : 0,
			),
		);

		update_option( BETTERLINKS_PRO_QR_BRANDING_OPTION_NAME, wp_json_encode( $branding ) );
		wp_send_json_success( $branding );
	}

	public function run_single_link_checker() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! $this->current_user_can_manage_link_scanner() ) {
			wp_die( "You don't have permission to do this." );
		}

		$row_link = isset( $_POST['row_link'] ) ? esc_url_raw( wp_unslash( $_POST['row_link'] ) ) : '';
		if( empty( $row_link ) ) {
			wp_send_json_error([
				'status_code' => false,
			], 404);
		}
		$status     = Helper::url_http_response_is_broken( $row_link );
		wp_send_json_success($status, 200);
	}

	public function remove_single_scan_log() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! $this->current_user_can_manage_link_scanner() ) {
			wp_die( "You don't have permission to do this." );
		}

		$link = isset( $_POST['link'] ) ? esc_url_raw( wp_unslash( $_POST['link'] ) ) : '';
		$post_link = isset( $_POST['post_link'] ) ? esc_url_raw( wp_unslash( $_POST['post_link'] ) ) : '';
		$status = isset( $_POST['status'] ) ? sanitize_text_field( wp_unslash( $_POST['status'] ) ) : '';
		if( empty( $post_link ) || empty( $link ) ) {
			wp_send_json_error([
				'result' => false,
			], 404);
		}
		$post_id = url_to_postid($post_link);
		$fullsite_broken_link_logs = get_option('betterlinkspro_fullsite_broken_links_logs', []);
		if( is_string( $fullsite_broken_link_logs ) ){
			$fullsite_broken_link_logs = json_decode( $fullsite_broken_link_logs, true );
		}
		
		$fullsite_broken_link_logs[$post_id][$link]['status'] = $status;
		$fullsite_broken_link_logs[$post_id][$link]['checked_at'] = time();
		update_option('betterlinkspro_fullsite_broken_links_logs', json_encode( $fullsite_broken_link_logs ));
		wp_send_json_success([
			'updated_list' => $fullsite_broken_link_logs 
		], 200);
	}

	public function run_broken_link_checker() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! apply_filters( 'betterlinkspro/admin/current_user_can_manage_link_scanner', $this->current_user_can_manage_link_scanner() ) ) {
			wp_die( "You don't have permission to do this" );
		}
		
		$link = isset( $_POST['link'] ) ? esc_url_raw( wp_unslash( $_POST['link'] ) ) : '';
		$id = isset( $_POST['id'] ) ? absint( wp_unslash( $_POST['id'] ) ) : null;
		// JSON payload is parsed via json_decode below; raw unslash is intentional.
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$details = !empty( $_POST['details'] ) ? wp_unslash( $_POST['details'] ) : '';

		$details = json_decode( $details, true );

		$logs       = json_decode( get_option( BETTERLINKS_PRO_FULLSITE_BROKEN_LINK_LOGS, '{}' ), true );

		$http_args = array(
			'connect_timeout' => 10,
			'timeout' => 5
		);
		// $status = Helper::url_http_response_is_broken( $link, $http_args );
		// wp_safe_remote_get(): adds SSRF protection (rejects loopback/private/
		// link-local/metadata hosts and re-validates redirects). sslverify is kept
		// false to preserve the scanner's existing broken-link behavior for targets
		// with invalid certificates — only the destination policy changed.
		$response = wp_safe_remote_get( $link, array( 'timeout' => 5, 'sslverify' => false, 'httpversion' => '1.1' ) );
        $code = wp_remote_retrieve_response_code( $response );
		$status = ['status_code' => $code];
		$details['status'] = (!empty( $status['status_code'] ) && intval($status['status_code']) >= 100) ? $status['status_code'] : 404;
		// $details['status'] = $status['status_code'] == 1 ? 200 : $status['status_code'];
		$details['status'] = intval( $details['status']  ) >= 400 ? 404 : $details['status'];
		// 401/403 are meaningful on their own — every other 4xx/5xx stays folded
		// into 404 ("broken"), which is what the scanner has always recorded.
		$details['status'] = in_array( intval( $details['status'] ), array( 401, 403 ), true )
			? intval( $details['status'] )
			: ( intval( $details['status'] ) >= 400 ? 404 : $details['status'] );
		$details['checked_at'] = time();
		$logs[$id][$link] = $details;

		update_option( BETTERLINKS_PRO_FULLSITE_BROKEN_LINK_LOGS, json_encode( $logs ), true  );
		$this->touch_fullsite_last_scan();
		wp_send_json_success(array(
			'status' =>$details['status'],
			'checked_at' => $details['checked_at'],
		));
	}

	/**
	 * Re-check a single already-logged link and persist the fresh result, so the
	 * table's "Re-check" (and the one-by-one "Re-check all") reflect reality
	 * without needing a full re-scan.
	 */
	public function recheck_fullsite_link() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! apply_filters( 'betterlinkspro/admin/current_user_can_manage_link_scanner', $this->current_user_can_manage_link_scanner() ) ) {
			wp_die( "You don't have permission to do this" );
		}

		$link      = isset( $_POST['link'] ) ? esc_url_raw( wp_unslash( $_POST['link'] ) ) : '';
		$post_link = isset( $_POST['post_link'] ) ? esc_url_raw( wp_unslash( $_POST['post_link'] ) ) : '';
		$post_id   = isset( $_POST['post_id'] ) ? absint( wp_unslash( $_POST['post_id'] ) ) : 0;

		if ( empty( $post_id ) && ! empty( $post_link ) ) {
			$post_id = url_to_postid( $post_link );
		}

		if ( empty( $link ) || empty( $post_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Missing link details.', 'betterlinks-pro' ) ), 400 );
		}

		// SSRF-safe: reject internal hosts and re-validate redirects. sslverify
		// stays false so cert-invalid external links behave as before.
		$response = wp_safe_remote_get( $link, array(
			'timeout'     => 5,
			'sslverify'   => false,
			'httpversion' => '1.1',
		) );

		$code   = wp_remote_retrieve_response_code( $response );
		$status = ( ! empty( $code ) && intval( $code ) >= 100 ) ? intval( $code ) : 404;
		$status = in_array( $status, array( 401, 403 ), true ) ? $status : ( $status >= 400 ? 404 : $status );

		$logs = json_decode( get_option( BETTERLINKS_PRO_FULLSITE_BROKEN_LINK_LOGS, '{}' ), true );
		if ( ! is_array( $logs ) ) {
			$logs = array();
		}

		$checked_at = time();

		if ( isset( $logs[ $post_id ][ $link ] ) && is_array( $logs[ $post_id ][ $link ] ) ) {
			$logs[ $post_id ][ $link ]['status']     = $status;
			$logs[ $post_id ][ $link ]['checked_at'] = $checked_at;
			update_option( BETTERLINKS_PRO_FULLSITE_BROKEN_LINK_LOGS, wp_json_encode( $logs ) );
			$this->touch_fullsite_last_scan();
		}

		wp_send_json_success( array(
			'link'       => $link,
			'post_id'    => $post_id,
			'status'     => $status,
			'checked_at' => $checked_at,
		) );
	}

	/**
	 * Delete specific scan-log entries (the table's "Clear selected"). Posts left
	 * with no links are dropped so they don't count as scanned-but-empty.
	 */
	public function delete_fullsite_scan_logs() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! apply_filters( 'betterlinkspro/admin/current_user_can_manage_link_scanner', $this->current_user_can_manage_link_scanner() ) ) {
			wp_die( "You don't have permission to do this" );
		}

		// JSON payload of [{ post_id, link }, …]; each field is sanitized below.
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$items = isset( $_POST['items'] ) ? json_decode( wp_unslash( $_POST['items'] ), true ) : array();

		if ( empty( $items ) || ! is_array( $items ) ) {
			wp_send_json_error( array( 'message' => __( 'No links selected.', 'betterlinks-pro' ) ), 400 );
		}

		$logs = json_decode( get_option( BETTERLINKS_PRO_FULLSITE_BROKEN_LINK_LOGS, '{}' ), true );
		if ( ! is_array( $logs ) ) {
			$logs = array();
		}

		$removed = 0;
		foreach ( $items as $item ) {
			$link    = isset( $item['link'] ) ? esc_url_raw( $item['link'] ) : '';
			$post_id = isset( $item['post_id'] ) ? absint( $item['post_id'] ) : 0;

			if ( empty( $post_id ) && ! empty( $item['post_link'] ) ) {
				$post_id = url_to_postid( esc_url_raw( $item['post_link'] ) );
			}

			if ( empty( $link ) || empty( $post_id ) || ! isset( $logs[ $post_id ][ $link ] ) ) {
				continue;
			}

			unset( $logs[ $post_id ][ $link ] );
			$removed++;

			if ( empty( $logs[ $post_id ] ) ) {
				unset( $logs[ $post_id ] );
			}
		}

		update_option( BETTERLINKS_PRO_FULLSITE_BROKEN_LINK_LOGS, wp_json_encode( $logs ) );

		wp_send_json_success( array(
			'removed' => $removed,
			'logs'    => $logs,
		) );
	}

	/**
	 * Stamp the moment the full-site scanner last wrote a result. Written on
	 * every link check (cheap: non-autoloaded), so it doubles as "scan activity".
	 */
	private function touch_fullsite_last_scan() {
		update_option( self::FULLSITE_LAST_SCAN_OPTION, time(), false );
	}

	/**
	 * Last-scan timestamp plus a pre-formatted "2 hours ago" string, so the JS
	 * never has to reconcile site timezone against the browser clock.
	 */
	private function get_fullsite_last_scan() {
		$timestamp = (int) get_option( self::FULLSITE_LAST_SCAN_OPTION, 0 );

		return array(
			'last_scan'       => $timestamp,
			/* translators: %s: human readable time difference, e.g. "2 hours". */
			'last_scan_human' => $timestamp ? sprintf( __( '%s ago', 'betterlinks-pro' ), human_time_diff( $timestamp, time() ) ) : '',
		);
	}

	public function clear_fullsite_broken_links() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! apply_filters( 'betterlinkspro/admin/current_user_can_manage_link_scanner', $this->current_user_can_manage_link_scanner() ) ) {
			wp_die( "You don't have permission to do this" );
		}

		delete_option(BETTERLINKS_PRO_FULLSITE_BROKEN_LINK_LOGS);
		delete_option('betterlinks_pro_fullsite_last_scaned_post');
		delete_option('betterlinkspro_force_scan_progress');
		delete_option(self::FULLSITE_LAST_SCAN_OPTION);
		update_option( 'betterlinkspro_fullsite_broken_links_logs_cleared', 1 );
		wp_send_json(array(
			'success' => true,
		));
	}

	public function get_all_used_links_in_post_by_id() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! apply_filters( 'betterlinkspro/admin/current_user_can_manage_link_scanner', $this->current_user_can_manage_link_scanner() ) ) {
			wp_die( "You don't have permission to do this" );
		}

		$id = isset( $_POST['ID'] ) ? intval( $_POST['ID'] ) : null;
		// $isResume = isset( $_POST['isResume'] ) ?  $_POST['isResume']  : null;
		$post = get_post( $id );
		if ( ! $post || ! current_user_can( 'read_post', $post->ID ) ) {
			wp_send_json_error(array(
				'message' => 'Post not found',
				'result' => false,
			));
		}

		$post_content = !empty( $post->post_content ) ? $post->post_content : 'nothing';

		$doc = new \DomDocument();

		@$doc->loadHTML( $post_content );

		$links = $doc->getElementsByTagName( 'a' );
		
		$extracted_links = [];

		foreach ($links as $i){
			// $link = wp_http_validate_url($i->getAttribute( 'href' ));
			$link = !empty( $i->getAttribute( 'href' ) ) ? $i->getAttribute( 'href' ) : '';
			if( strpos( $link, '#' ) === 0 ) {
				continue;
			}
			if( empty( $link  ) ) continue;
			
			$linkText = $i->textContent;
			$extracted_links[$link] = [
				'innerText' => $linkText,
				'post_type' => $post->post_type
			];
        }

		if( empty( $extracted_links ) ){
			$logs       = json_decode( get_option( BETTERLINKS_PRO_FULLSITE_BROKEN_LINK_LOGS, '{}' ), true );
			$logs[$id] = [];
			update_option( BETTERLINKS_PRO_FULLSITE_BROKEN_LINK_LOGS, json_encode( $logs ), false  );
		}

		// Keep track of all scanned posts by merging with existing data
		$scanned_posts = json_decode( get_option('betterlinks_pro_fullsite_last_scaned_post', '{}'), true );
		$scanned_posts[$id] = count( $extracted_links );
		update_option('betterlinks_pro_fullsite_last_scaned_post', json_encode( $scanned_posts ));
		
		wp_send_json_success(array(
			'post_links' => array(
				$id => $extracted_links
			),
			'result' => true,
		));
	}

	public function fullsite_scanner_allowed_post_type() {
		$fullsite_scan_settings = get_option(BETTERLINKS_PRO_FULLSITE_BROKEN_LINK_OPTION_NAME, '{}');
		$fullsite_scan_settings = json_decode( $fullsite_scan_settings, true );
		$post_types = isset( $fullsite_scan_settings['fullsite_scanner_post_types'] ) ? $fullsite_scan_settings['fullsite_scanner_post_types'] : '';
		
		// If post types setting is empty, return empty array (no post types selected)
		if ( empty( trim( $post_types ) ) ) {
			return array();
		}
		
		$post_types = explode( "|", $post_types );
		
		$allowed_post_type = [];
		if( in_array('all**all', $post_types) ){
			$all_post_types = Helper::get_all_post_types();
			unset( $all_post_types['attachment'] );
			return $all_post_types;
		}
		foreach ($post_types as $value) {
			$post_type = explode( '**', $value );
			// Only add non-empty post types
			if ( ! empty( trim( $post_type[0] ) ) ) {
				array_push( $allowed_post_type, $post_type[0] );
			}
		}
		return $allowed_post_type;
	}
	/**
	 * Get full site links with batch processing for memory optimization
	 * Handles large websites by processing posts in batches to prevent memory limit crashes
	 */
	public function get_full_site_links() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! apply_filters( 'betterlinkspro/admin/current_user_can_manage_link_scanner', $this->current_user_can_manage_link_scanner() ) ) {
			wp_die( "You don't have permission to do this" );
		}

		try {
			// Get batch parameters from AJAX request
			$batch_number = isset( $_POST['batch'] ) ? intval( $_POST['batch'] ) : 1;
			$posts_per_batch = isset( $_POST['posts_per_batch'] ) ? intval( $_POST['posts_per_batch'] ) : 200;
			$init_request = isset( $_POST['init_request'] ) ? filter_var( wp_unslash( $_POST['init_request'] ), FILTER_VALIDATE_BOOLEAN ) : false;
			
			// Ensure reasonable batch size limits
			$posts_per_batch = max( 50, min( 500, $posts_per_batch ) );

			// Get allowed post types from settings
			$allowed_post_types = $this->fullsite_scanner_allowed_post_type();
			
			// If no post types are selected, return empty results
			if ( empty( $allowed_post_types ) ) {
				// Return empty data when no post types are selected
				$logs = json_decode( get_option( BETTERLINKS_PRO_FULLSITE_BROKEN_LINK_LOGS, '{}' ), true );
				
				if ( $init_request ) {
					wp_send_json_success( array_merge( array(
						'total_posts'    => 0,
						'total_batches'  => 0,
						'posts_per_batch'=> $posts_per_batch,
						'logs'           => array(),
						'post_links'     => array(),
						'last_scaned_status' => true,
						'batch_info'     => array(
							'current_batch' => 1,
							'has_more'      => false
						)
					), $this->get_fullsite_last_scan() ) );
					return;
				}

				wp_send_json_success( array_merge( array(
					'logs'  => array(),
					'post_links' => array(),
					'last_scaned_status' => true
				), $this->get_fullsite_last_scan() ) );
				return;
			}
			
			// Determine which post types to query
			$query_post_types = array_intersect( get_post_types(), $allowed_post_types );

			// Fallback: if no specific batch request, return all data like original
			if ( ! $init_request && $batch_number === 1 && ! isset( $_POST['batch'] ) ) {
				// This is likely the original call from frontend, return all data
				$posts = get_posts( array(
					'post_type'   => $query_post_types,
					'numberposts' => 1000, // Limit to prevent memory issues
					'post_status' => array('publish', 'pending', 'draft', 'future', 'private', 'inherit'),
				) );

				$post_links = array();
				foreach ( $posts as $post ) {
					if ( ! empty( $allowed_post_types ) && ! in_array( $post->post_type, $allowed_post_types ) ) {
						continue;
					}
					// Only list content the current user may read (drafts/private of others).
					if ( ! current_user_can( 'read_post', $post->ID ) ) {
						continue;
					}
					$post_links[ $post->ID ] = array(
						'permalink' => get_permalink( $post->ID ),
						'name'      => ! empty( $post->post_title ) ? $post->post_title : $post->post_name,
						'edit_link' => get_edit_post_link( $post->ID, '' ),
						'post_type' => $post->post_type
					);
				}


			$logs = json_decode( get_option( BETTERLINKS_PRO_FULLSITE_BROKEN_LINK_LOGS, '{}' ), true );
			$logs = $this->filter_logs_by_post_types( $logs, $allowed_post_types );

			$is_completed = $this->get_scan_completion_status( $logs );
			
			if ( ! empty( $logs ) && ! $is_completed ) {
				$logs = $this->cleanup_incomplete_logs( $logs, $post_links );
			}

			wp_send_json_success( array_merge( array(
				'logs'  => $logs,
				'post_links' => $post_links,
				'last_scaned_status' => $is_completed,
				'completed_posts_count' => $this->get_completed_posts_count()
			), $this->get_fullsite_last_scan() ) );
			return;
		}			// For initial request, return total count and basic info
			if ( $init_request ) {
				$total_count_query = new \WP_Query( array(
					'post_type'      => $query_post_types,
					'post_status'    => array('publish', 'pending', 'draft', 'future', 'private', 'inherit'),
					'fields'         => 'ids', // Memory efficient - only get IDs
					'posts_per_page' => -1,
					'no_found_rows'  => false, // We need total count
				) );

				$total_posts = $total_count_query->found_posts;
				$total_batches = ceil( $total_posts / $posts_per_batch );

				// Clean up query
				wp_reset_postdata();

				// Get existing logs for initial response
				$logs = json_decode( get_option( BETTERLINKS_PRO_FULLSITE_BROKEN_LINK_LOGS, '{}' ), true );
				$logs = $this->filter_logs_by_post_types( $logs, $allowed_post_types );

				wp_send_json_success( array_merge( array(
					'total_posts'    => $total_posts,
					'total_batches'  => $total_batches,
					'posts_per_batch'=> $posts_per_batch,
					'logs'           => $logs,
					'post_links'     => array(), // Empty for init request
					'last_scaned_status' => $this->get_scan_completion_status( $logs ),
					'completed_posts_count' => $this->get_completed_posts_count(),
					'batch_info'     => array(
						'current_batch' => 1,
						'has_more'      => $total_batches > 1
					)
				), $this->get_fullsite_last_scan() ) );
				return;
			}

			// Memory optimization: Use WP_Query with pagination
			$query_args = array(
				'post_type'      => $query_post_types,
				'post_status'    => array('publish', 'pending', 'draft', 'future', 'private', 'inherit'),
				'posts_per_page' => $posts_per_batch,
				'paged'          => $batch_number,
				'fields'         => 'ids', // Only get IDs first to minimize memory usage
				'no_found_rows'  => false, // We need pagination info
			);

			// Execute memory-efficient query
			$post_query = new \WP_Query( $query_args );
			$post_ids = $post_query->posts;
			$total_posts = $post_query->found_posts;
			$total_batches = ceil( $total_posts / $posts_per_batch );
			$has_more = $batch_number < $total_batches;

			// Build post links array for current batch
			$post_links = array();
			
			if ( ! empty( $post_ids ) ) {
				// Get post objects only for current batch
				$posts = get_posts( array(
					'include'        => $post_ids,
					'post_type'      => $query_post_types,
					'post_status'    => 'any',
					'numberposts'    => -1,
				) );

				// Process each post in current batch
				foreach ( $posts as $post ) {
					// Double-check post type filter (defense in depth)
					if ( ! empty( $allowed_post_types ) && ! in_array( $post->post_type, $allowed_post_types ) ) {
						continue;
					}
					// Only list content the current user may read (drafts/private of others).
					if ( ! current_user_can( 'read_post', $post->ID ) ) {
						continue;
					}

					$post_links[ $post->ID ] = array(
						'permalink' => get_permalink( $post->ID ),
						'name'      => ! empty( $post->post_title ) ? $post->post_title : $post->post_name,
						'edit_link' => get_edit_post_link( $post->ID, '' ),
						'post_type' => $post->post_type
					);
				}
			}

			// Get and filter existing logs
			$logs = json_decode( get_option( BETTERLINKS_PRO_FULLSITE_BROKEN_LINK_LOGS, '{}' ), true );
			$logs = $this->filter_logs_by_post_types( $logs, $allowed_post_types );

			// Handle scan completion logic
			$is_completed = $this->get_scan_completion_status( $logs );
			
			// Remove incomplete last log if necessary (preserve original logic)
			if ( ! empty( $logs ) && ! $is_completed ) {
				$logs = $this->cleanup_incomplete_logs( $logs, $post_links );
			}

			// Clean up query
			wp_reset_postdata();

			// Return batch response
			wp_send_json_success( array_merge( array(
				'logs'           => $logs,
				'post_links'     => $post_links,
				'last_scaned_status' => $is_completed,
				'completed_posts_count' => $this->get_completed_posts_count(),
				'batch_info'     => array(
					'current_batch'  => $batch_number,
					'total_batches'  => $total_batches,
					'total_posts'    => $total_posts,
					'posts_per_batch'=> $posts_per_batch,
					'has_more'       => $has_more,
					'next_batch'     => $has_more ? $batch_number + 1 : null,
					'processed_posts'=> count( $post_links )
				)
			), $this->get_fullsite_last_scan() ) );

		} catch ( \Exception $e ) {
			wp_send_json_error( array(
				'message' => 'An error occurred while processing the request: ' . $e->getMessage()
			), 500 );
		} catch ( \Error $e ) {
			wp_send_json_error( array(
				'message' => 'A fatal error occurred: ' . $e->getMessage()
			), 500 );
		}
	}

	/**
	 * Filter logs by allowed post types to maintain compatibility
	 * 
	 * @param array $logs Existing logs
	 * @param array $allowed_post_types Allowed post types
	 * @return array Filtered logs
	 */
	private function filter_logs_by_post_types( $logs, $allowed_post_types ) {
		if ( empty( $allowed_post_types ) || empty( $logs ) ) {
			return $logs;
		}

		foreach ( $logs as $log_key => $log_value ) {
			if ( ! is_array( $log_value ) ) {
				continue;
			}
			
			foreach ( $log_value as $key => $value ) {
				if ( isset( $value['post_type'] ) && ! in_array( $value['post_type'], $allowed_post_types ) ) {
					unset( $logs[ $log_key ][ $key ] );
				}
			}
			
			// Keep empty log entries — they represent scanned posts that had no links.
			// Removing them causes totalScanedPost count to mismatch after page refresh.
		}

		return $logs;
	}

	/**
	 * Get total completed posts count
	 * Checks both normal scan tracking and force scan progress
	 * 
	 * @return int Total number of posts that have been scanned
	 */
	private function get_completed_posts_count() {
		// First check if force scan is active or completed
		$force_scan_progress = get_option( 'betterlinkspro_force_scan_progress', array() );
		if ( ! empty( $force_scan_progress ) ) {
			$scanned = isset( $force_scan_progress['scanned'] ) ? intval( $force_scan_progress['scanned'] ) : 0;
			if ( $scanned > 0 ) {
				return $scanned;
			}
		}
		
		// Otherwise, return count from normal scan tracking
		$last_scaned_post = get_option( 'betterlinks_pro_fullsite_last_scaned_post', '{}' );
		$last_scaned_post = json_decode( $last_scaned_post, true );
		
		// Return the count of posts that have been scanned (keys in the tracking option)
		return count( $last_scaned_post );
	}

	/**
	 * Get scan completion status
	 * 
	 * @param array $logs Current logs
	 * @return bool Whether scan is completed
	 */
	private function get_scan_completion_status( $logs ) {
		if ( empty( $logs ) ) {
			return false;
		}

		$log_keys = array_keys( $logs );
		$last_log_key = end( $log_keys );
		$last_logs = ! empty( $last_log_key ) ? $logs[ $last_log_key ] : array();
		
		$last_scaned_post = get_option( 'betterlinks_pro_fullsite_last_scaned_post', '{}' );
		$last_scaned_post = json_decode( $last_scaned_post, true );

		return isset( $last_scaned_post[ $last_log_key ] ) && $last_scaned_post[ $last_log_key ] == count( $last_logs );
	}

	/**
	 * Clean up incomplete logs (preserve original logic)
	 * 
	 * @param array $logs Current logs
	 * @param array $post_links Current batch post links
	 * @return array Cleaned logs
	 */
	private function cleanup_incomplete_logs( $logs, $post_links ) {
		$post_keys = array_keys( $post_links );
		$first_post_key = isset( $post_keys[0] ) ? $post_keys[0] : '';
		
		$log_keys = array_keys( $logs );
		$last_log_key = count( $log_keys ) > 0 ? $log_keys[ count( $log_keys ) - 1 ] : '';

		$is_completed = $this->get_scan_completion_status( $logs );

		// Remove incomplete last log if conditions match original logic
		if ( ( count( $log_keys ) > 0 && $first_post_key !== $last_log_key ) && ! $is_completed ) {
			unset( $logs[ $last_log_key ] );
		}

		return $logs;
	}

	public function fetch_meta_tags() {
		$nonce             = isset( $_POST['security'] ) ? sanitize_text_field( wp_unslash( $_POST['security'] ) ) : '';
		$betterlinks_nonce = 'betterlinks_admin_nonce';
		if ( ! wp_verify_nonce( $nonce, $betterlinks_nonce ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Security check failed.', 'betterlinks-pro' ),
				)
			);
		}

		// Check if user has permission - either manage_options or role-based permissions
		$can_access = apply_filters( 'betterlinkspro/admin/current_user_can_edit_settings', current_user_can( 'manage_options' ) );
		
		// Also allow users who can edit links since meta tags are link-specific
		if ( ! $can_access ) {
			$can_access = apply_filters( 'betterlinks_can_fetch_meta_tags', false );
		}
		
		if ( ! $can_access ) {
			wp_send_json_error(
				array(
					'message' => __( 'You don\'t have permission to fetch meta tags.', 'betterlinks-pro' ),
				)
			);
		}

		global $wpdb;
		$query   = "SELECT * FROM {$wpdb->prefix}betterlinks_meta_tags";
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$results = $wpdb->get_results( $query, ARRAY_A );
		wp_send_json_success(
			array(
				'data' => $results,
			),
			200
		);
	}


	public function fetch_links_password() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		
		// Check if user has permission - either manage_options or role-based permissions
		$can_access = apply_filters( 'betterlinkspro/admin/current_user_can_edit_settings', current_user_can( 'manage_options' ) );
		
		// Also allow users who can edit or view links since passwords are link-specific
		if ( ! $can_access ) {
			$can_access = apply_filters( 'betterlinks_can_fetch_password', false );
		}
		
		if ( ! $can_access ) {
			wp_send_json_error(
				array(
					'message' => __( 'You don\'t have permission to fetch link passwords.', 'betterlinks-pro' ),
				)
			);
		}
		global $wpdb;
		// Never send stored passwords to the browser; only whether one is set.
		$query_string = "SELECT `id`, `link_id`, `status`, `allow_contact`, '' AS `password`, ( `password` <> '' ) AS `has_password` FROM {$wpdb->prefix}betterlinks_password";
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$results      = $wpdb->get_results( $query_string );

		wp_send_json_success(
			array(
				'links' => $results,
			),
			200
		);
	}

	public function add_meta_tags() {
		$nonce             = isset( $_POST['security'] ) ? sanitize_text_field( wp_unslash( $_POST['security'] ) ) : '';
		$betterlinks_nonce = 'betterlinks_admin_nonce';
		if ( ! wp_verify_nonce( $nonce, $betterlinks_nonce ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Security check failed.', 'betterlinks-pro' ),
				)
			);
		}

		// Check if user has permission - either manage_options or role-based permissions
		$can_access = apply_filters( 'betterlinkspro/admin/current_user_can_edit_settings', current_user_can( 'manage_options' ) );
		
		// Also allow users who can edit links since meta tags are link-specific
		if ( ! $can_access ) {
			$can_access = apply_filters( 'betterlinks_can_manage_meta_tags', false );
		}
		
		if ( ! $can_access ) {
			wp_send_json_error(
				array(
					'message' => __( 'You don\'t have permission to manage meta tags.', 'betterlinks-pro' ),
				)
			);
		}

		global $wpdb;
		$status           = isset( $_POST['status'] ) ? 'true' === $_POST['status'] : 0;
		$link_id          = ! empty( $_POST['link_id'] ) ? sanitize_text_field( wp_unslash( $_POST['link_id'] ) ) : null;
		$meta_title       = ! empty( $_POST['meta_title'] ) ? sanitize_text_field( wp_unslash( $_POST['meta_title'] ) ) : '';
		$meta_description = ! empty( $_POST['meta_description'] ) ? sanitize_text_field( wp_unslash( $_POST['meta_description'] ) ) : '';
		$meta_image       = ! empty( $_POST['meta_image'] ) ? sanitize_url( wp_unslash( $_POST['meta_image'] ) ) : '';

		// check if the meta tags already added
		$result = Helper::get_meta_tag_by_link_id( $link_id );

		if ( 1 === count( $result ) ) {
			$update_query = "UPDATE {$wpdb->prefix}betterlinks_meta_tags set meta_title=%s, meta_desc=%s,meta_image=%s,status=%d where link_id=%d";

			$update_query_values = array( $meta_title, $meta_description, $meta_image, $status, $link_id );

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
			$update = $wpdb->query( $wpdb->prepare( $update_query, $update_query_values ) );
			wp_send_json(
				array(
					'updated' => $update ? true : false,
					'message' => $update ? 'Updated successfully' : 'Failed to update',
				),
				$update ? 200 : 500
			);
		}

		$query_string    = "INSERT INTO {$wpdb->prefix}betterlinks_meta_tags (`link_id`, `meta_title`, `meta_desc`, `meta_image`, `status`) VALUES(%d,%s,%s,%s,%d)";
		$query_value_arr = array( $link_id, $meta_title, $meta_description, $meta_image, $status );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$wpdb->query( $wpdb->prepare( $query_string, $query_value_arr ) );

		if ( $wpdb->insert_id ) {
			wp_send_json_success(
				array(
					'success' => true,
					'message' => 'meta tags inserted successfully.',
					'data'    => array(
						'id'         => $wpdb->insert_id,
						'link_id'    => $link_id,
						'meta_title' => $meta_title,
						'meta_desc'  => $meta_description,
						'meta_image' => $meta_image,
					),
				),
				201
			);
		} else {
			wp_send_json_error(
				array(
					'success' => false,
					'message' => 'Something went wrong.',
				),
				500
			);
		}
	}
	public function create_links_password() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );

		// Check if user has permission - either manage_options or role-based permissions
		$can_access = apply_filters( 'betterlinkspro/admin/current_user_can_edit_settings', current_user_can( 'manage_options' ) );
		
		// Also allow users who can edit links since passwords are link-specific
		if ( ! $can_access ) {
			$can_access = apply_filters( 'betterlinks_can_create_password', false );
		}
		
		if ( ! $can_access ) {
			wp_send_json_error(
				array(
					'message' => __( 'You don\'t have permission to create link passwords.', 'betterlinks-pro' ),
				)
			);
		}
		global $wpdb;
		$link_id       = ! empty( $_POST['link_id'] ) ? absint( wp_unslash( $_POST['link_id'] ) ) : null;
		$password      = ! empty( $_POST['password'] ) ? sanitize_text_field( wp_unslash( $_POST['password'] ) ) : '';
		$status        = ( isset( $_POST['status'] ) && 'true' === $_POST['status'] );
		$allow_contact = ( isset( $_POST['allow_contact'] ) && 'true' === $_POST['allow_contact'] );

		// 👇 check if the link password is already exists using link_id
		$result = Helper::get_password_by_link_id( $link_id );

		if ( count( $result ) === 1 ) { // if result returns true, that means link password already exists
			// The editor no longer receives the stored password, so an empty field
			// keeps it; a new value replaces it (stored as a hash).
			if ( '' === $password ) {
				$update_query        = "UPDATE {$wpdb->prefix}betterlinks_password SET `status`=%d, `allow_contact`=%d WHERE `link_id`=%d";
				$update_query_values = array( $status, $allow_contact, $link_id );
			} else {
				$update_query        = "UPDATE {$wpdb->prefix}betterlinks_password SET `status`=%d, `password`=%s, `allow_contact`=%d WHERE `link_id`=%d";
				$update_query_values = array( $status, Helper::hash_link_password( $password ), $allow_contact, $link_id );
			}

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
			$update = $wpdb->query( $wpdb->prepare( $update_query, $update_query_values ) );
			wp_send_json(
				array(
					'updated' => $update ? true : false,
					'message' => $update ? 'Updated successfully' : 'Failed to update',
				),
				$update ? 200 : 500
			);
		}
		// completed update query

		if ( '' === $password ) {
			wp_send_json_error(
				array(
					'success' => false,
					'message' => __( 'Enter a password to protect this link.', 'betterlinks-pro' ),
				),
				400
			);
		}
		$query_string    = "INSERT INTO {$wpdb->prefix}betterlinks_password (`link_id`, `password`, `status`, `allow_contact`) VALUES(%d,%s,%d,%d)";
		$query_value_arr = array( $link_id, Helper::hash_link_password( $password ), $status, $allow_contact );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$wpdb->query( $wpdb->prepare( $query_string, $query_value_arr ) );

		if ( $wpdb->insert_id ) {
			wp_send_json_success(
				array(
					'success' => true,
					'message' => 'password created successfully.',
					'data'    => array(
						'id'            => $wpdb->insert_id,
						'link_id'       => $link_id,
						'status'        => $status,
						'allow_contact' => $allow_contact,
					),
				),
				201
			);
		} else {
			wp_send_json_error(
				array(
					'success' => false,
					'message' => 'Something went wrong.',
				),
				500
			);
		}
	}


	public function get_role_management() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		// The role-assignment control plane must stay administrator-only. It was
		// gated by current_user_can_edit_settings, which the delegable
		// `editsettings` permission satisfies — so a settings-only role could read
		// (get_role_management) and then rewrite (role_management) the whole
		// permission map, adding its own role to every bucket. That is a
		// plugin-scoped privilege escalation; require manage_options directly.
		if ( current_user_can( 'manage_options' ) ) {
			$data = get_option( BETTERLINKS_PRO_ROLE_PERMISSON_OPTION_NAME, '{}' );
			wp_send_json_success( json_decode( $data, true ) );
		}
		wp_die( "You don't have permission to do this." );
	}
	/**
	 * Read one capability bucket off the Role Management POST.
	 *
	 * The screen posts an unchecked capability as an empty string, and a plain
	 * explode( ',', '' ) stores that as array( '' ) — an entry that used to match
	 * a role-less user under loose comparison. Drop empties so a bucket granted to
	 * nobody is stored as a genuinely empty array. See Helper::role_matches().
	 *
	 * @param string $key POST field name.
	 * @return array<int,string>
	 */
	private static function role_bucket_from_post( $key ) {
		if ( ! isset( $_POST[ $key ] ) || ! is_scalar( $_POST[ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- caller verifies the nonce first.
			return array();
		}

		$raw = explode( ',', sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- caller verifies the nonce first.

		return array_values( array_filter( array_map( 'trim', $raw ), 'strlen' ) );
	}

	public function role_management() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		// Administrator-only: this writes the role->permission map itself. Gating
		// it on the delegable `editsettings` permission let a settings-only role
		// grant itself every other BetterLinks permission. See get_role_management().
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'You do not have permission to perform this action.', 'betterlinks-pro' ) ),
				403
			);
		}
		$viewlinks      = self::role_bucket_from_post( 'viewlinks' );
		$writelinks     = self::role_bucket_from_post( 'writelinks' );
		$editlinks      = self::role_bucket_from_post( 'editlinks' );
		$checkanalytics = self::role_bucket_from_post( 'checkanalytics' );
		$editsettings   = self::role_bucket_from_post( 'editsettings' );
		$editFavorite   = self::role_bucket_from_post( 'editFavorite' );
		$manageAutoliks = self::role_bucket_from_post( 'manageAutoliks' );
		$manageTagsCategories = self::role_bucket_from_post( 'manageTagsCategories' );
		$manageLinkScanner = self::role_bucket_from_post( 'manageLinkScanner' );
		$managePromoCards = self::role_bucket_from_post( 'managePromoCards' );
		$manageBioLinks = self::role_bucket_from_post( 'manageBioLinks' );
		// "Who can use MCP?" is only on screen when BetterLinks supports it, so a
		// save from a screen without the row must not wipe the stored roles.
		if ( isset( $_POST['manageMcp'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified above.
			$manageMcp = self::role_bucket_from_post( 'manageMcp' );
		} else {
			$stored    = json_decode( (string) get_option( BETTERLINKS_PRO_ROLE_PERMISSON_OPTION_NAME, '{}' ), true );
			$manageMcp = is_array( $stored ) && isset( $stored['manageMcp'] ) && is_array( $stored['manageMcp'] ) ? array_values( $stored['manageMcp'] ) : array();
		}
		$update         = update_option(
			BETTERLINKS_PRO_ROLE_PERMISSON_OPTION_NAME,
			wp_json_encode(
				array(
					'viewlinks'      => $viewlinks,
					'writelinks'     => $writelinks,
					'editlinks'      => $editlinks,
					'checkanalytics' => $checkanalytics,
					'editsettings'   => $editsettings,
					'editFavorite'   => $editFavorite,
					'manageAutoliks' => $manageAutoliks,
					'manageTagsCategories' => $manageTagsCategories,
					'manageLinkScanner' => $manageLinkScanner,
					'managePromoCards' => $managePromoCards,
					'manageBioLinks' => $manageBioLinks,
					'manageMcp'      => $manageMcp,
				)
			)
		);
		// A role taken off "Who can use MCP?" loses its MCP connections now, for
		// good, so ticking it again later does not quietly bring them back
		// (WPDevelopers/betterlinks#127). Older BetterLinks has no such method.
		if ( is_callable( array( '\\BetterLinks\\Mcp\\Mcp_OAuth', 'revoke_unauthorized' ) ) ) {
			\BetterLinks\Mcp\Mcp_OAuth::revoke_unauthorized();
		}
		wp_send_json_success( $update );
	}

	public function get_external_analytics() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( apply_filters( 'betterlinkspro/admin/current_user_can_edit_settings', current_user_can( 'manage_options' ) ) ) {
			$data = get_option( BETTERLINKS_PRO_EXTERNAL_ANALYTICS_OPTION_NAME, array() );
			if ( is_string( $data ) ) {
				$data = json_decode( $data, true );
			}
			wp_send_json_success( $data );
		}
		wp_die( "You don't have permission to do this." );
	}

	public function get_auto_link_create_settings() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( apply_filters( 'betterlinkspro/admin/current_user_can_edit_settings', current_user_can( 'manage_options' ) ) ) {
			$data = get_option( BETTERLINKS_PRO_AUTO_LINK_CREATE_OPTION_NAME, array() );
			if ( is_string( $data ) ) {
				$data = json_decode( $data, true );
			}
			wp_send_json_success( $data );
		}
		wp_die( "You don't have permission to do this." );
	}

	public function get_auto_link_disable_ids() {
		check_ajax_referer( 'betterlinks_admin_nonce', 'security' );
		if ( apply_filters( 'betterlinkspro/admin/current_user_can_edit_settings', current_user_can( 'manage_options' ) ) ) {
			$post_id = ( isset( $_POST['id'] ) ? intval( sanitize_text_field( wp_unslash( $_POST['id'] ) ) ) : '' );
			$data    = get_post_meta( $post_id, BETTERLINKS_PRO_AUTO_LINK_DISABLE_IDS );
			wp_send_json_success( $data );
		}
		wp_die( "You don't have permission to do this." );
	}
	public function set_auto_link_disable_ids() {
		check_ajax_referer( 'betterlinks_admin_nonce', 'security' );
		if ( apply_filters( 'betterlinkspro/admin/current_user_can_edit_settings', current_user_can( 'manage_options' ) ) ) {
			$post_id = ( isset( $_POST['id'] ) ? intval( sanitize_text_field( wp_unslash( $_POST['id'] ) ) ) : '' );
			$status  = ( isset( $_POST['status'] ) ? sanitize_text_field( wp_unslash( $_POST['status'] ) ) : '0' );
			$data    = get_post_meta( $post_id, BETTERLINKS_PRO_AUTO_LINK_DISABLE_IDS );

			$update = update_post_meta( $post_id, BETTERLINKS_PRO_AUTO_LINK_DISABLE_IDS, $status );

			wp_send_json( $update );
		}
		wp_die( "You don't have permission to do this." );
	}

	public function external_analytics() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( apply_filters( 'betterlinkspro/admin/current_user_can_edit_settings', current_user_can( 'manage_options' ) ) ) {
			$is_enable_ga = filter_var( ( isset( $_POST['is_enable_ga'] ) ? sanitize_text_field( wp_unslash( $_POST['is_enable_ga'] ) ) : false ), FILTER_VALIDATE_BOOLEAN );
			// $is_ga4 = filter _var( ( is set( $ _ POST['i s_ga4'] ) ? sanit ize_ text_field( $ _ POST['is_ga4'] ) : fal se ), FILTER_V ALIDATE_B OOLEAN );
			$is_ga4                   = true; // Since Universal analytics has stopped tracking, so we only have GA4.
			$is_enable_pixel          = filter_var( ( isset( $_POST['is_enable_pixel'] ) ? sanitize_text_field( wp_unslash( $_POST['is_enable_pixel'] ) ) : false ), FILTER_VALIDATE_BOOLEAN );
			$ga_tracking_code         = ( isset( $_POST['ga_tracking_code'] ) ? sanitize_text_field( wp_unslash( $_POST['ga_tracking_code'] ) ) : '' );
			$ga4_api_secret           = ( isset( $_POST['ga4_api_secret'] ) ? sanitize_text_field( wp_unslash( $_POST['ga4_api_secret'] ) ) : '' );
			$pixel_id                 = ( isset( $_POST['pixel_id'] ) ? sanitize_text_field( wp_unslash( $_POST['pixel_id'] ) ) : '' );
			$pixel_access_token       = ( isset( $_POST['pixel_access_token'] ) ? sanitize_text_field( wp_unslash( $_POST['pixel_access_token'] ) ) : '' );
			$is_enable_custom_scripts = filter_var( ( isset( $_POST['is_enable_custom_scripts'] ) ? sanitize_text_field( wp_unslash( $_POST['is_enable_custom_scripts'] ) ) : false ), FILTER_VALIDATE_BOOLEAN );
			// global_head_scripts is raw JS printed on every cloaked redirect page.
			// Only users with unfiltered_html may set it; a delegated `editsettings`
			// role (Subscriber) must not be able to store stored XSS. When the caller
			// lacks the capability, preserve whatever the option already holds.
			if ( current_user_can( 'unfiltered_html' ) ) {
				$global_head_scripts = isset( $_POST['global_head_scripts'] ) ? $_POST['global_head_scripts'] : ''; // phpcs:ignore
			} else {
				$existing_ext_analytics = get_option( BETTERLINKS_PRO_EXTERNAL_ANALYTICS_OPTION_NAME );
				$global_head_scripts    = isset( $existing_ext_analytics['global_head_scripts'] ) ? $existing_ext_analytics['global_head_scripts'] : '';
				// Also do not let such a role toggle the raw-script feature on.
				if ( empty( $global_head_scripts ) ) {
					$is_enable_custom_scripts = false;
				}
			}
			$parameter_tracking = ( isset( $_POST['parameter_tracking'] ) ?  json_decode( stripslashes($_POST['parameter_tracking']), true )   : ''); // phpcs:ignore

			$analytic_data = array(
				'is_enable_ga'             => $is_enable_ga,
				'is_ga4'                   => $is_ga4,
				'ga_tracking_code'         => $ga_tracking_code,
				'ga4_api_secret'           => $ga4_api_secret,
				'is_enable_pixel'          => $is_enable_pixel,
				'pixel_id'                 => $pixel_id,
				'pixel_access_token'       => $pixel_access_token,
				'is_enable_custom_scripts' => $is_enable_custom_scripts,
				'global_head_scripts'      => $global_head_scripts,
				'parameter_tracking'       => $parameter_tracking,
			);
			$update        = update_option( BETTERLINKS_PRO_EXTERNAL_ANALYTICS_OPTION_NAME, $analytic_data );
			if ( defined( 'BETTERLINKS_EXISTS_LINKS_JSON' ) && BETTERLINKS_EXISTS_LINKS_JSON ) {
				$formattedArray = \BetterLinks\Helper::get_links_for_json();
				file_put_contents( BETTERLINKS_UPLOAD_DIR_PATH . '/links.json', wp_json_encode( $formattedArray ) );
			}
			wp_send_json_success( $update );
		}
		wp_die( "You don't have permission to do this." );
	}

	public function analytics() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( apply_filters( 'betterlinkspro/admin/current_user_can_edit_settings', current_user_can( 'manage_options' ) ) ) {
			$Cron    = new Cron();
			$resutls = $Cron->analytics();
			wp_send_json_success( $resutls );
		}
		wp_die( "You don't have permission to do this." );
	}
	public function set_auto_link_create_settings() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( apply_filters( 'betterlinkspro/admin/current_user_can_edit_settings', current_user_can( 'manage_options' ) ) ) {
			$enable_auto_link             = filter_var( ( isset( $_POST['enable_auto_link'] ) ? sanitize_text_field( wp_unslash( $_POST['enable_auto_link'] ) ) : false ), FILTER_VALIDATE_BOOLEAN );
			$post_shortlinks              = filter_var( ( isset( $_POST['post_shortlinks'] ) ? sanitize_text_field( wp_unslash( $_POST['post_shortlinks'] ) ) : false ), FILTER_VALIDATE_BOOLEAN );
			$page_shortlinks              = filter_var( ( isset( $_POST['page_shortlinks'] ) ? sanitize_text_field( wp_unslash( $_POST['page_shortlinks'] ) ) : false ), FILTER_VALIDATE_BOOLEAN );
			$custom_post_type_shortlinks  = filter_var( ( isset( $_POST['custom_post_type_shortlinks'] ) ? sanitize_text_field( wp_unslash( $_POST['custom_post_type_shortlinks'] ) ) : false ), FILTER_VALIDATE_BOOLEAN );
			$post_default_cat             = ( isset( $_POST['post_default_cat'] ) ? sanitize_text_field( wp_unslash( $_POST['post_default_cat'] ) ) : 0 );
			$page_default_cat             = ( isset( $_POST['page_default_cat'] ) ? sanitize_text_field( wp_unslash( $_POST['page_default_cat'] ) ) : 0 );
			$custom_post_type_default_cat = ( isset( $_POST['custom_post_type_default_cat'] ) ? sanitize_text_field( wp_unslash( $_POST['custom_post_type_default_cat'] ) ) : 0 );
			$custom_post_types_selection  = ( isset( $_POST['custom_post_types_selection'] ) ? sanitize_text_field( wp_unslash( $_POST['custom_post_types_selection'] ) ) : '' );

			$auto_link_create_options = array(
				'enable_auto_link'             => $enable_auto_link,
				'post_shortlinks'              => $enable_auto_link ? $post_shortlinks : false,
				'page_shortlinks'              => $enable_auto_link ? $page_shortlinks : false,
				'custom_post_type_shortlinks'  => $enable_auto_link ? $custom_post_type_shortlinks : false,
				'custom_post_types_selection'  => $enable_auto_link && $custom_post_type_shortlinks ? $custom_post_types_selection : '',
			);

			if ( ! empty( $auto_link_create_options['post_shortlinks'] ) ) {
				$post_default_cat                             = Helper::insert_new_category( $post_default_cat );
				$auto_link_create_options['post_default_cat'] = $post_default_cat;
			}
			if ( ! empty( $auto_link_create_options['page_shortlinks'] ) ) {
				$page_default_cat                             = Helper::insert_new_category( $page_default_cat );
				$auto_link_create_options['page_default_cat'] = $page_default_cat;
			}
			if ( ! empty( $auto_link_create_options['custom_post_type_shortlinks'] ) ) {
				$custom_post_type_default_cat                             = Helper::insert_new_category( $custom_post_type_default_cat );
				$auto_link_create_options['custom_post_type_default_cat'] = $custom_post_type_default_cat;
			}

			// Force update by deleting the option first to ensure it saves
			delete_option( BETTERLINKS_PRO_AUTO_LINK_CREATE_OPTION_NAME );
			$update = update_option( BETTERLINKS_PRO_AUTO_LINK_CREATE_OPTION_NAME, wp_json_encode( $auto_link_create_options ) );
			
			wp_send_json_success( $update );
		}
		wp_die( "You don't have permission to do this." );
	}

	public function get_links() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! apply_filters( 'betterlinks/api/links_get_items_permissions_check', current_user_can( 'manage_options' ) ) ) {
			wp_die( "You don't have permission to do this." );
		}
		global $wpdb;
		$ID = ( isset( $_POST['ID'] ) ? absint( wp_unslash( $_POST['ID'] ) ) : 0 );
		if ( $ID ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$results = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT ID, link_title FROM {$wpdb->prefix}betterlinks WHERE ID=%d",
					$ID
				),
				OBJECT
			);
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$results = $wpdb->get_results( "SELECT ID, link_title FROM {$wpdb->prefix}betterlinks", OBJECT );
		}
		wp_send_json_success( $results );
	}
	public function get_broken_links_data() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! $this->current_user_can_manage_link_scanner() ) {
			wp_die( "You don't have permission to do this." );
		}
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$results = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}betterlinks", OBJECT );
		$links   = wp_json_encode( $results );
		$logs    = get_option( 'betterlinkspro_broken_links_logs' );
		wp_send_json_success(
			array_merge(
				array(
					'links' => $links,
					'logs'  => $logs,
				),
				$this->get_brokenlink_last_run()
			)
		);
	}

	/**
	 * Stamp / read when the BetterLinks broken-link scanner last wrote a result.
	 * Formatted server-side ("40 min ago") so the browser clock never enters into it.
	 */
	private function touch_brokenlink_last_run() {
		update_option( self::BROKENLINK_LAST_RUN_OPTION, time(), false );
	}

	private function get_brokenlink_last_run() {
		$timestamp = (int) get_option( self::BROKENLINK_LAST_RUN_OPTION, 0 );

		return array(
			'last_run'       => $timestamp,
			/* translators: %s: human readable time difference, e.g. "40 mins". */
			'last_run_human' => $timestamp ? sprintf( __( '%s ago', 'betterlinks-pro' ), human_time_diff( $timestamp, time() ) ) : '',
		);
	}

	public function run_instant_broken_link_checker() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! $this->current_user_can_manage_link_scanner() ) {
			wp_die( "You don't have permission to do this." );
		}
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$results = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}betterlinks", OBJECT );
		$links   = wp_json_encode( $results );
		$logs    = get_option( 'betterlinkspro_broken_links_logs' );
		wp_send_json_success(
			array(
				'links' => $links,
				'logs'  => $logs,
			)
		);
	}
	public function delete_broken_link_checker_logs() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! $this->current_user_can_manage_link_scanner() ) {
			wp_die( "You don't have permission to do this." );
		}
		// Before wiping the log option, restore any links the prior scan flipped to
		// "broken" — otherwise rows stay stuck at link_status='broken' with no log to
		// explain why, and links.json never resyncs.
		$existing_logs = json_decode( get_option( 'betterlinkspro_broken_links_logs' ), true );
		if ( is_array( $existing_logs ) && ! empty( $existing_logs ) ) {
			$this->restore_link_statuses_from_logs( array_keys( $existing_logs ), $existing_logs );
		}
		$result = delete_option( 'betterlinkspro_broken_links_logs' );
		delete_option( self::BROKENLINK_LAST_RUN_OPTION );
		wp_send_json_success( $result );
	}

	/**
	 * Roll back DB link_status for a set of broken-link log entries to the value they
	 * had before being flagged, then refresh links.json. Used when the user dismisses
	 * findings via "Remove Log" / multi-remove / "Delete all logs". Idempotent.
	 *
	 * @param array $ids  Link IDs whose stored status should be restored.
	 * @param array $logs Decoded logs option (array form). Optional; loaded if omitted.
	 */
	private function restore_link_statuses_from_logs( $ids, $logs = null ) {
		if ( null === $logs ) {
			$logs = json_decode( get_option( 'betterlinkspro_broken_links_logs' ), true );
		}
		if ( ! is_array( $logs ) || empty( $ids ) ) {
			return;
		}
		$changed = false;
		foreach ( $ids as $id ) {
			$id = intval( $id );
			if ( ! $id || empty( $logs[ $id ] ) || ! is_array( $logs[ $id ] ) ) {
				continue;
			}
			$existing = \BetterLinks\Helper::get_link_by_ID( $id );
			$existing = is_array( $existing ) ? current( $existing ) : null;
			if ( ! is_array( $existing ) || empty( $existing['link_status'] ) ) {
				continue;
			}
			if ( 'broken' !== $existing['link_status'] ) {
				continue;
			}
			$restore_to = isset( $logs[ $id ]['old_link_status'] ) && ! empty( $logs[ $id ]['old_link_status'] )
				? $logs[ $id ]['old_link_status']
				: 'publish';
			\BetterLinks\Helper::insert_link(
				array(
					'ID'          => $id,
					'link_status' => $restore_to,
				),
				true
			);
			$changed = true;
		}
		if ( $changed ) {
			\BetterLinks\Helper::clear_query_cache();
			do_action( 'betterlinks/write_json_links' );
		}
	}
	public function run_broken_links_checker() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! $this->current_user_can_manage_link_scanner() ) {
			wp_die( "You don't have permission to do this." );
		}
		$data = \BetterLinks\Helper::fresh_ajax_request_data( $_POST );
		
		if ( is_array( $data ) && count( $data ) ) {
			$this->check_broken_link( $data );
			$this->touch_brokenlink_last_run();
		}
		wp_send_json_success( get_option( 'betterlinkspro_broken_links_logs' ) );
	}
	public function run_single_broken_link_checker() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! $this->current_user_can_manage_link_scanner() ) {
			wp_die( "You don't have permission to do this." );
		}

		global $wpdb;
		$ID     = ( isset( $_REQUEST['ID'] ) ? absint( wp_unslash( $_REQUEST['ID'] ) ) : 0 );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}betterlinks WHERE ID=%d",
				$ID
			),
			OBJECT
		);

		$result     = current( $result );
		$target_url = '';
		$target_url = Helper::addScheme( $result->target_url );
		$status     = Helper::url_http_response_is_broken( $target_url );
		if ( isset( $status['status_code'] ) ) {
			wp_send_json_success( $status );
		} else {
			wp_send_json_error( "status wasn't recieved" );
		}
	}

	public function update_broken_link() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! $this->current_user_can_manage_link_scanner() ) {
			wp_die( "You don't have permission to do this." );
		}
		do_action( 'betterlinks/write_json_links' );
		$ID                     = ( isset( $_REQUEST['ID'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['ID'] ) ) : 0 );
		$target_url             = ( isset( $_REQUEST['target_url'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['target_url'] ) ) : 0 );
		$logs                   = json_decode( get_option( 'betterlinkspro_broken_links_logs' ), true );
		$log_item               = $logs[ $ID ];
		$log_item['target_url'] = $target_url;
		$logs[ $ID ]            = $log_item;
		update_option( 'betterlinkspro_broken_links_logs', wp_json_encode( $logs ), false );
		wp_send_json_success( wp_json_encode( $logs ) );
	}
	public function remove_broken_link() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! $this->current_user_can_manage_link_scanner() ) {
			wp_die( "You don't have permission to do this." );
		}
		$ID                               = ( isset( $_REQUEST['ID'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['ID'] ) ) : 0 );
		$results                          = json_decode( get_option( 'betterlinkspro_broken_links_logs' ), true );
		if ( ! is_array( $results ) ) {
			$results = array();
		}
		if ( ! isset( $results[ $ID ] ) || ! is_array( $results[ $ID ] ) ) {
			$results[ $ID ] = array();
		}
		$results[ $ID ]['is_log_removed'] = true;
		update_option( 'betterlinkspro_broken_links_logs', wp_json_encode( $results ), false );
		// Dismissing the log means "this isn't actually broken" — roll the link back to
		// its pre-broken status so the dashboard badge and links.json stay consistent.
		$this->restore_link_statuses_from_logs( array( $ID ), $results );
		wp_send_json_success( wp_json_encode( $results ) );
	}
	public function remove_multi_broken_link() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! $this->current_user_can_manage_link_scanner() ) {
			wp_die( "You don't have permission to do this." );
		}
		$logs    = \BetterLinks\Helper::fresh_ajax_request_data( $_REQUEST );
		$results = json_decode( get_option( 'betterlinkspro_broken_links_logs' ), true );
		if ( ! is_array( $results ) ) {
			$results = array();
		}
		$dismissed_ids = array();
		foreach ( $logs as $ID ) {
			if ( ! isset( $results[ $ID ] ) || ! is_array( $results[ $ID ] ) ) {
				$results[ $ID ] = array();
			}
			$results[ $ID ]['is_log_removed'] = true;
			$dismissed_ids[]                  = $ID;
		}
		update_option( 'betterlinkspro_broken_links_logs', wp_json_encode( $results ), false );
		$this->restore_link_statuses_from_logs( $dismissed_ids, $results );
		wp_send_json_success( wp_json_encode( $results ) );
	}


	public function current_user_can_edit_settings() {
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}
		$user               = wp_get_current_user();
		$user_permission    = json_decode( get_option( BETTERLINKS_PRO_ROLE_PERMISSON_OPTION_NAME ), true );
		$current_user_roles = current( $user->roles );
		if (
			is_array( $user_permission ) &&
			isset( $user_permission['editsettings'] ) &&
			is_array( $user_permission['editsettings'] ) &&
			\BetterLinksPro\Helper::role_matches( $current_user_roles, $user_permission['editsettings'] )
		) {
			return true;
		}
		return false;
	}

	public function current_user_can_manage_link_scanner() {
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}
		$user               = wp_get_current_user();
		$user_permission    = json_decode( get_option( BETTERLINKS_PRO_ROLE_PERMISSON_OPTION_NAME ), true );
		if ( ! is_array( $user_permission ) || ! isset( $user_permission['manageLinkScanner'] ) ) {
			return false;
		}
		$current_user_roles = current( $user->roles );
		if (
			is_array( $user_permission['manageLinkScanner'] ) &&
			\BetterLinksPro\Helper::role_matches( $current_user_roles, $user_permission['manageLinkScanner'] )
		) {
			return true;
		}
		return false;
	}

	public function current_user_can_manage_promo_cards() {
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}
		$user               = wp_get_current_user();
		$user_permission    = json_decode( get_option( BETTERLINKS_PRO_ROLE_PERMISSON_OPTION_NAME ), true );
		if ( ! is_array( $user_permission ) || ! isset( $user_permission['managePromoCards'] ) ) {
			return false;
		}
		$current_user_roles = current( $user->roles );
		if (
			is_array( $user_permission['managePromoCards'] ) &&
			\BetterLinksPro\Helper::role_matches( $current_user_roles, $user_permission['managePromoCards'] )
		) {
			return true;
		}
		return false;
	}

	public function current_user_can_manage_bio_links() {
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}
		$user               = wp_get_current_user();
		$user_permission    = json_decode( get_option( BETTERLINKS_PRO_ROLE_PERMISSON_OPTION_NAME ), true );
		if ( ! is_array( $user_permission ) || ! isset( $user_permission['manageBioLinks'] ) ) {
			return false;
		}
		$current_user_roles = current( $user->roles );
		if (
			is_array( $user_permission['manageBioLinks'] ) &&
			\BetterLinksPro\Helper::role_matches( $current_user_roles, $user_permission['manageBioLinks'] )
		) {
			return true;
		}
		return false;
	}

	public function get_broken_link_settings() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! $this->current_user_can_manage_link_scanner() ) {
			wp_die( "You don't have permission to do this." );
		}
		$restuls = get_option( BETTERLINKS_PRO_BROKEN_LINK_OPTION_NAME, '{}' );
		wp_send_json_success( $restuls );
	}

	public function save_broken_link_settings() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! $this->current_user_can_manage_link_scanner() ) {
			wp_die( "You don't have permission to do this." );
		}
		$data = \BetterLinks\Helper::fresh_ajax_request_data( $_POST );
		$data = \BetterLinks\Helper::sanitize_text_or_array_field( $data );

		if ( isset( $data['scan_time'] ) ) {
			$data['scan_time'] = \BetterLinksPro\Helper::normalize_scan_time( $data['scan_time'] );
		}

		wp_clear_scheduled_hook( 'betterlinkspro/broken_link_checker' );
		update_option( BETTERLINKS_PRO_BROKEN_LINK_OPTION_NAME, wp_json_encode( $data ) );
		wp_send_json_success( wp_json_encode( $data ) );
	}
	public function get_split_test_analytics() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! apply_filters( 'betterlinkspro/api/analytics_items_permissions_check', current_user_can( 'manage_options' ) ) ) {
			wp_die( "You don't have permission to do this." );
		}
		$ID      = ( isset( $_REQUEST['ID'] ) ? absint( wp_unslash( $_REQUEST['ID'] ) ) : 0 );
		$results = Helper::get_split_test_analytics_data( array( 'id' => $ID ) );

		$split_test_data = Helper::split_test_enabled( $ID );

		// The analytics rows only carry target URLs, so the screen has nothing to
		// name the link with and no way to show each variant's configured traffic
		// weight. Both come off the link row itself.
		$dynamic_redirect = \BetterLinks\Helper::get_link_data_by_id( $ID, 'dynamic_redirect' );

		$link_details = array(
			'ID'               => $ID,
			'link_title'       => \BetterLinks\Helper::get_link_data_by_id( $ID, 'link_title' ),
			'short_url'        => \BetterLinks\Helper::get_link_data_by_id( $ID, 'short_url' ),
			'target_url'       => \BetterLinks\Helper::get_link_data_by_id( $ID, 'target_url' ),
			'dynamic_redirect' => $dynamic_redirect,
			'goal_link'        => null,
		);

		// `extra.goal_link` holds a BetterLinks link ID (it is picked from a link
		// dropdown), not a URL — resolve it so the screen can name the goal
		// instead of printing a bare number.
		$rotation = json_decode( (string) $dynamic_redirect, true );
		$goal_id  = isset( $rotation['extra']['goal_link'] ) ? absint( $rotation['extra']['goal_link'] ) : 0;
		if ( $goal_id ) {
			$goal_title = \BetterLinks\Helper::get_link_data_by_id( $goal_id, 'link_title' );
			if ( ! empty( $goal_title ) ) {
				$link_details['goal_link'] = array(
					'ID'         => $goal_id,
					'link_title' => $goal_title,
					'short_url'  => \BetterLinks\Helper::get_link_data_by_id( $goal_id, 'short_url' ),
				);
			}
		}

		wp_send_json_success(
			array(
				'results'         => $results,
				'split_test_data' => $split_test_data,
				'link_details'    => $link_details,
			),
			200
		);
	}
	public function get_reporting_settings() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! $this->current_user_can_edit_settings() ) {
			wp_die( "You don't have permission to do this." );
		}
		$restuls = get_option( BETTERLINKS_PRO_REPORTING_OPTION_NAME, '{}' );
		wp_send_json_success(
			$restuls,
			200
		);
	}
	public function saved_reporting_settings() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! $this->current_user_can_edit_settings() ) {
			wp_die( "You don't have permission to do this." );
		}
		$data = \BetterLinks\Helper::fresh_ajax_request_data( $_POST );
		$data = \BetterLinks\Helper::sanitize_text_or_array_field( $data );
		update_option( BETTERLINKS_PRO_REPORTING_OPTION_NAME, wp_json_encode( $data ) );
		wp_send_json_success(
			wp_json_encode( $data ),
			200
		);
	}
	public function test_report_mail() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! $this->current_user_can_edit_settings() ) {
			wp_die( "You don't have permission to do this." );
		}
		$email = $this->send_mail();
		wp_send_json_success(
			$email,
			200
		);
	}
	public function get_all_keywords() {
		check_ajax_referer( 'betterlinks_admin_nonce', 'security' );
		if ( ! apply_filters( 'betterlinkspro/api/manage_autolink_permission_check', current_user_can( 'manage_options' ) ) ) {
			wp_die( "You don't have permission to do this." );
		}
		$results = \BetterLinks\Helper::get_keywords();
		wp_send_json_success(
			$results,
			200
		);
	}
	public function create_keyword() {
		check_ajax_referer( 'betterlinks_admin_nonce', 'security' );
		if ( ! apply_filters( 'betterlinkspro/api/manage_autolink_permission_check', current_user_can( 'manage_options' ) ) ) {
			wp_die( "You don't have permission to do this." );
		}
		$data    = \BetterLinks\Helper::fresh_ajax_request_data( $_POST );
		$item    = $this->prepare_keyword_item_for_db( $data );
		$link_id = ( isset( $item['link_id'] ) ? $item['link_id'] : 0 );
		\BetterLinks\Helper::add_link_meta( $link_id, 'keywords', $item );
		wp_send_json_success(
			$item,
			200
		);
	}
	public function update_keyword() {
		check_ajax_referer( 'betterlinks_admin_nonce', 'security' );
		if ( ! apply_filters( 'betterlinkspro/api/manage_autolink_permission_check', current_user_can( 'manage_options' ) ) ) {
			wp_die( "You don't have permission to do this." );
		}
		$data         = \BetterLinks\Helper::fresh_ajax_request_data( $_POST );
		$old_link_id  = absint( isset( $data['oldChooseLink'] ) ? $data['oldChooseLink'] : 0 );
		$link_id      = absint( isset( $data['chooseLink'] ) ? $data['chooseLink'] : 0 );
		$old_keywords = ( isset( $data['oldKeywords'] ) ? $data['oldKeywords'] : '' );
		$item         = $this->prepare_keyword_item_for_db( $data );
		$is_update    = \BetterLinks\Helper::update_link_meta( $link_id, 'keywords', $item, $old_keywords, $old_link_id );
		if ( $is_update ) {
			wp_send_json_success(
				array_merge(
					$item,
					array(
						'old_link_id'  => $old_link_id,
						'old_keywords' => $old_keywords,
					)
				),
				200
			);
		} else {
			wp_send_json_error( 'updated link meta failed ' );
		}
	}
	public function delete_keyword() {
		check_ajax_referer( 'betterlinks_admin_nonce', 'security' );
		if ( ! apply_filters( 'betterlinkspro/api/manage_autolink_permission_check', current_user_can( 'manage_options' ) ) ) {
			wp_die( "You don't have permission to do this." );
		}
		$id        = ( isset( $_POST['id'] ) ? intval( sanitize_text_field( wp_unslash( $_POST['id'] ) ) ) : 0 );
		$keywords  = ( isset( $_POST['keywords'] ) ? ( sanitize_text_field( wp_unslash( $_POST['keywords'] ) ) ) : '' );
		$is_delete = \BetterLinks\Helper::delete_link_meta( $id, 'keywords', '', $keywords );
		wp_send_json_success(
			$is_delete,
			200
		);
	}


	/**
	 * Export keywords to CSV - Pro Feature
	 */
	public function export_keywords() {
		check_ajax_referer( 'betterlinks_admin_nonce', 'security' );
		if ( ! apply_filters( 'betterlinkspro/api/manage_autolink_permission_check', current_user_can( 'manage_options' ) ) ) {
			wp_die( "You don't have permission to do this." );
		}

		try {
			$keywords_data = \BetterLinks\Helper::get_keywords();
			
			if (empty($keywords_data)) {
				wp_send_json_error([
					'message' => __('No keywords found to export.', 'betterlinks-pro')
				], 400);
			}

			wp_send_json_success([
				'data' => $keywords_data,
				'message' => __('Keywords exported successfully.', 'betterlinks-pro')
			], 200);

		} catch (Exception $e) {
			wp_send_json_error([
				'message' => __('Failed to export keywords: ', 'betterlinks-pro') . $e->getMessage()
			], 500);
		}
	}

	/**
	 * Import keywords from CSV - Pro Feature
	 */
	public function import_keywords() {
		check_ajax_referer( 'betterlinks_admin_nonce', 'security' );
		if ( ! apply_filters( 'betterlinkspro/api/manage_autolink_permission_check', current_user_can( 'manage_options' ) ) ) {
			wp_die( "You don't have permission to do this." );
		}

		try {
			// JSON payload decoded immediately; sanitization happens per-field below.
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$csv_data = isset( $_POST['csv_data'] ) ? json_decode( wp_unslash( $_POST['csv_data'] ), true ) : [];
			$rewrite_existing = isset($_POST['rewrite_existing']) ? (bool) $_POST['rewrite_existing'] : false;

			if (empty($csv_data) || !is_array($csv_data)) {
				wp_send_json_error([
					'message' => __('No valid data provided for import.', 'betterlinks-pro')
				], 400);
			}

			$imported = 0;
			$skipped = 0;
			$errors = 0;
			$error_messages = [];

			foreach ($csv_data as $item) {
				try {
					// Validate required fields
					if (empty($item['keywords']) || empty($item['chooseLink'])) {
						$skipped++;
						continue;
					}

					// Check if link exists
					$link_exists = \BetterLinks\Helper::get_link_by_ID($item['chooseLink']);
					if (!$link_exists) {
						$errors++;
						/* translators: %d: numeric value. */
						$error_messages[] = sprintf(__('Link ID %d does not exist.', 'betterlinks-pro'), $item['chooseLink']);
						continue;
					}

					// Check if keyword already exists for this link
					$existing_keywords = \BetterLinks\Helper::get_keywords();
					$keyword_exists = false;
					
					foreach ($existing_keywords as $existing) {
						$existing_data = is_string($existing) ? json_decode($existing, true) : $existing;
						if ($existing_data['link_id'] == $item['chooseLink'] && 
							strtolower($existing_data['keywords']) == strtolower($item['keywords'])) {
							$keyword_exists = true;
							break;
						}
					}

					if ($keyword_exists && !$rewrite_existing) {
						$skipped++;
						continue;
					}

					// Prepare data for database
					$api = new \BetterLinksPro\API\Keywords();
					$data = $api->prepare_keyword_item_for_db($item);
					
					if ($keyword_exists && $rewrite_existing) {
						// Update existing keyword
						$is_updated = \BetterLinks\Helper::update_link_meta($item['chooseLink'], 'keywords', $data, $item['keywords'], $item['chooseLink']);
						if ($is_updated) {
							$imported++;
						} else {
							$errors++;
							/* translators: %s: text value; %d: numeric value. */
							$error_messages[] = sprintf(__('Failed to update keyword "%1$s" for link ID %2$d.', 'betterlinks-pro'), $item['keywords'], $item['chooseLink']);
						}
					} else {
						// Add new keyword
						$is_inserted = \BetterLinks\Helper::add_link_meta($item['chooseLink'], 'keywords', $data);
						if ($is_inserted) {
							$imported++;
						} else {
							$errors++;
							/* translators: %s: text value; %d: numeric value. */
							$error_messages[] = sprintf(__('Failed to import keyword "%1$s" for link ID %2$d.', 'betterlinks-pro'), $item['keywords'], $item['chooseLink']);
						}
					}

				} catch (Exception $e) {
					$errors++;
					$error_messages[] = $e->getMessage();
				}
			}

			$message = sprintf(
				/* translators: %d: numeric value. */
				__('Import completed. Imported: %1$d, Skipped: %2$d, Errors: %3$d', 'betterlinks-pro'),
				$imported,
				$skipped,
				$errors
			);

			wp_send_json_success([
				'message' => $message,
				'details' => [
					'imported' => $imported,
					'skipped' => $skipped,
					'errors' => $errors,
					'error_messages' => array_slice($error_messages, 0, 10) // Limit to first 10 errors
				]
			], 200);

		} catch (Exception $e) {
			wp_send_json_error([
				'message' => __('Failed to import keywords: ', 'betterlinks-pro') . $e->getMessage()
			], 500);
		}
	}

	/**
	 * Get available post types
	 */
	public function get_available_post_types() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! apply_filters( 'betterlinkspro/admin/current_user_can_edit_settings', current_user_can( 'manage_options' ) ) ) {
			wp_die( "You don't have permission to do this" );
		}

		$post_types = \BetterLinksPro\Admin\FullSiteScannerReport::get_available_post_types();
		wp_send_json_success( $post_types );
	}

	/**
	 * Get full site report scan settings
	 */
	public function get_fullsite_report_scan_settings() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! apply_filters( 'betterlinkspro/admin/current_user_can_edit_settings', current_user_can( 'manage_options' ) ) ) {
			wp_die( "You don't have permission to do this" );
		}

		$settings = \BetterLinksPro\Admin\FullSiteScannerReport::get_scan_settings();
		wp_send_json_success( json_encode( $settings ) );
	}

	/**
	 * Save full site report scan settings
	 */
	public function save_fullsite_report_scan_settings() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! apply_filters( 'betterlinkspro/admin/current_user_can_edit_settings', current_user_can( 'manage_options' ) ) ) {
			wp_die( "You don't have permission to do this" );
		}

		$settings = array();

		if ( isset( $_POST['enable_scan'] ) ) {
			$settings['enable_scan'] = sanitize_text_field( wp_unslash( $_POST['enable_scan'] ) ) === 'true' || sanitize_text_field( wp_unslash( $_POST['enable_scan'] ) ) === '1';
		}
		if ( isset( $_POST['scan_mode'] ) ) {
			$settings['scan_mode'] = sanitize_text_field( wp_unslash( $_POST['scan_mode'] ) );
		}
		if ( isset( $_POST['scan_day'] ) ) {
			$settings['scan_day'] = sanitize_text_field( wp_unslash( $_POST['scan_day'] ) );
		}
		if ( isset( $_POST['scan_month'] ) ) {
			$settings['scan_month'] = sanitize_text_field( wp_unslash( $_POST['scan_month'] ) );
		}
		if ( isset( $_POST['scan_year'] ) ) {
			$settings['scan_year'] = sanitize_text_field( wp_unslash( $_POST['scan_year'] ) );
		}
		if ( isset( $_POST['scan_time'] ) ) {
			$settings['scan_time'] = sanitize_text_field( wp_unslash( $_POST['scan_time'] ) );
		}
		if ( isset( $_POST['post_types'] ) ) {
			$post_types = is_array( $_POST['post_types'] ) ? 
				array_map( 'sanitize_text_field', wp_unslash( $_POST['post_types'] ) ) : 
				array( sanitize_text_field( wp_unslash( $_POST['post_types'] ) ) );
			$settings['post_types'] = $post_types;
		}

		$saved_settings = \BetterLinksPro\Admin\FullSiteScannerReport::save_scan_settings( $settings );
		wp_send_json_success( json_encode( $saved_settings ) );
	}

	/**
	 * Get full site report email settings
	 */
	public function get_fullsite_report_email_settings() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! apply_filters( 'betterlinkspro/admin/current_user_can_edit_settings', current_user_can( 'manage_options' ) ) ) {
			wp_die( "You don't have permission to do this" );
		}

		$settings = \BetterLinksPro\Admin\FullSiteScannerReport::get_email_settings();
		wp_send_json_success( json_encode( $settings ) );
	}

	/**
	 * Save full site report email settings
	 */
	public function save_fullsite_report_email_settings() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! apply_filters( 'betterlinkspro/admin/current_user_can_edit_settings', current_user_can( 'manage_options' ) ) ) {
			wp_die( "You don't have permission to do this" );
		}

		$settings = array();
		if ( isset( $_POST['enable_reporting'] ) ) {
			$settings['enable_reporting'] = sanitize_text_field( wp_unslash( $_POST['enable_reporting'] ) ) === 'true' || sanitize_text_field( wp_unslash( $_POST['enable_reporting'] ) ) === '1';
		}
		if ( isset( $_POST['email'] ) ) {
			$settings['email'] = sanitize_email( wp_unslash( $_POST['email'] ) );
		}
		if ( isset( $_POST['email_subject'] ) ) {
			$settings['email_subject'] = sanitize_text_field( wp_unslash( $_POST['email_subject'] ) );
		}

		$saved_settings = \BetterLinksPro\Admin\FullSiteScannerReport::save_email_settings( $settings );
		wp_send_json_success( json_encode( $saved_settings ) );
	}

	/**
	 * Send test email for full site report
	 */
	public function test_fullsite_report_mail() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! apply_filters( 'betterlinkspro/admin/current_user_can_edit_settings', current_user_can( 'manage_options' ) ) ) {
			wp_die( "You don't have permission to do this" );
		}

		$email_settings = \BetterLinksPro\Admin\FullSiteScannerReport::get_email_settings();
		$test_data = array(
			'total_links' => 150,
			'links_scanned' => 150,
			'broken_links' => 1,
			'unauthorized_links' => 2,
			'forbidden_links' => 1,
			'links_data' => array(
				array(
					'link_url' => 'https://example.com/broken-link',
					'post_id' => 1,
					'post_title' => __('Sample Post', 'betterlinks-pro'),
					'post_type' => 'post',
					'status_code' => 404,
					'status_label' => __('Broken', 'betterlinks-pro'),
					'scan_time' => current_time( 'mysql' ),
				),
			),
			'scan_time' => current_time( 'mysql' ),
		);

		$sent = \BetterLinksPro\Admin\FullSiteScannerReport::send_report_email( $test_data, $email_settings );
		
		if ( $sent ) {
			wp_send_json_success( json_encode( $email_settings ) );
		} else {
			wp_send_json_error( array( 'message' => __('Failed to send email', 'betterlinks-pro') ) );
		}
	}

	/**
	 * Start full site report scan
	 */
	public function start_fullsite_report_scan() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! apply_filters( 'betterlinkspro/admin/current_user_can_edit_settings', current_user_can( 'manage_options' ) ) ) {
			wp_die( "You don't have permission to do this" );
		}

		// Get post types from request, or use defaults
		$post_types = isset( $_REQUEST['post_types'] ) ? 
			array_map( 'sanitize_text_field', explode( ',', sanitize_text_field( wp_unslash( $_REQUEST['post_types'] ) ) ) ) : 
			array( 'post', 'page' );

		$scan_instance = new \BetterLinksPro\Admin\FullSiteScannerReport();
		$results = $scan_instance->run_scheduled_scan( $post_types, true );

		// Prepare clean response
		$response_data = array(
			'total_links' => isset( $results['total_links'] ) ? $results['total_links'] : 0,
			'links_scanned' => isset( $results['links_scanned'] ) ? $results['links_scanned'] : 0,
			'broken_links' => isset( $results['broken_links'] ) ? $results['broken_links'] : 0,
			'unauthorized_links' => isset( $results['unauthorized_links'] ) ? $results['unauthorized_links'] : 0,
			'forbidden_links' => isset( $results['forbidden_links'] ) ? $results['forbidden_links'] : 0,
			'links_data' => isset( $results['links_data'] ) && is_array( $results['links_data'] ) ? $results['links_data'] : array(),
			'scan_time' => isset( $results['scan_time'] ) ? $results['scan_time'] : current_time('mysql'),
		);

		wp_send_json_success( array(
			'success' => true,
			'data' => $response_data,
			'statistics' => array(
				'total_links' => $response_data['total_links'],
				'links_scanned' => $response_data['links_scanned'],
				'broken_links' => $response_data['broken_links'],
				'unauthorized_links' => $response_data['unauthorized_links'],
				'forbidden_links' => $response_data['forbidden_links'],
			),
			'links' => $response_data['links_data'],
		) );
	}

	/**
	 * Get posts for Full Site Scanner Report
	 */
	public function get_fullsite_report_posts() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! apply_filters( 'betterlinkspro/admin/current_user_can_edit_settings', current_user_can( 'manage_options' ) ) ) {
			wp_die( "You don't have permission to do this" );
		}

		$post_types = isset( $_REQUEST['post_types'] ) ? 
			array_map( 'sanitize_key', explode( ',', sanitize_text_field( wp_unslash( $_REQUEST['post_types'] ) ) ) ) : 
			array( 'post', 'page' );
		// Public post types only; the request must not reach arbitrary types.
		$post_types = array_values( array_intersect( $post_types, get_post_types( array( 'public' => true ) ) ) );
		if ( empty( $post_types ) ) {
			wp_send_json_success( array( 'posts' => array() ) );
		}

		$posts = get_posts( array(
			'post_type' => $post_types,
			'posts_per_page' => -1,
			'post_status' => 'publish',
		) );

		// Post content is not returned: links are extracted server-side by
		// get_fullsite_report_post_links(), and password-protected content must
		// not be sent to delegated roles.
		$posts_data = array();
		foreach ( $posts as $post ) {
			if ( ! current_user_can( 'read_post', $post->ID ) ) {
				continue;
			}
			$posts_data[] = array(
				'ID' => $post->ID,
				'post_title' => $post->post_title,
				'post_type' => $post->post_type,
			);
		}

		wp_send_json_success( array(
			'posts' => $posts_data,
		) );
	}

	/**
	 * Get all links in a post
	 */
	public function get_fullsite_report_post_links() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! apply_filters( 'betterlinkspro/admin/current_user_can_edit_settings', current_user_can( 'manage_options' ) ) ) {
			wp_die( "You don't have permission to do this" );
		}

		$post_id = isset( $_REQUEST['post_id'] ) ? intval( $_REQUEST['post_id'] ) : 0;
		$post = get_post( $post_id );

		if ( ! $post || ! current_user_can( 'read_post', $post->ID ) || 'publish' !== $post->post_status || ! empty( $post->post_password ) ) {
			wp_send_json_error( array( 'message' => 'Post not found' ) );
		}

		$links = array();
		preg_match_all( '/<a[^>]+href=["\']([^"\']+)["\'][^>]*>([^<]*)<\/a>/i', $post->post_content, $matches );

		if ( isset( $matches[1] ) && ! empty( $matches[1] ) ) {
			foreach ( $matches[1] as $url ) {
				$links[] = array(
					'url' => $url,
				);
			}
		}

		wp_send_json_success( array(
			'links' => $links,
		) );
	}

	/**
	 * Check a single link
	 */
	public function check_fullsite_report_link() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! apply_filters( 'betterlinkspro/admin/current_user_can_edit_settings', current_user_can( 'manage_options' ) ) ) {
			wp_die( "You don't have permission to do this" );
		}

		$link_url = isset( $_REQUEST['link_url'] ) ? sanitize_url( wp_unslash( $_REQUEST['link_url'] ) ) : '';

		if ( ! $link_url ) {
			wp_send_json_error( array( 'message' => 'Link URL is required' ) );
		}

		// SSRF-safe scanner fetch: internal hosts and unsafe redirects are rejected;
		// sslverify stays false to preserve prior broken-link results.
		$response = wp_safe_remote_get( $link_url, array( 
			'timeout' => 5, 
			'sslverify' => false, 
			'httpversion' => '1.1' 
		) );
		
		$status_code = wp_remote_retrieve_response_code( $response );
		
		// Apply same logic as existing scanner:
		// If status >= 400, convert to 404. If status >= 100 but < 400, keep it.
		if ( ! empty( $status_code ) && intval( $status_code ) >= 100 ) {
			$status_code = intval( $status_code );
		} else {
			$status_code = 404;
		}
		
		// Convert any 400+ to 404 to match existing scanner logic
		$status_code = intval( $status_code ) >= 400 ? 404 : $status_code;
		
		$status_label = $this->get_status_label( $status_code );

		wp_send_json_success( array(
			'status_code' => $status_code,
			'status_label' => $status_label,
		) );
	}

	/**
	 * Get status label for HTTP code
	 */
	private function get_status_label( $code ) {
		// Match the existing Full Site Scanner logic
		if ( ( $code >= 200 && $code <= 299 ) || $code === true ) {
			return 'Active';
		} elseif ( $code === 403 ) {
			return '403 Forbidden';
		} elseif ( $code === 401 ) {
			return '401 Unauthorized';
		} else {
			return 'Broken Link';
		}
	}

	/**
	 * Test scheduled scan (trigger cron manually)
	 */
	/**
	 * Force run the scheduled scan NOW (workaround for disabled WordPress cron)
	 */
	public function force_run_fullsite_report_scan() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array(
				'message' => __( 'Insufficient permissions', 'betterlinks-pro' ),
			), 403 );
		}

		// Prefer post types sent from the form (so user doesn't have to save first);
		// fall back to saved settings, then to the default post/page pair.
		if ( isset( $_REQUEST['post_types'] ) && '' !== $_REQUEST['post_types'] ) {
			$post_types = array_filter( array_map( 'sanitize_text_field', explode( ',', sanitize_text_field( wp_unslash( $_REQUEST['post_types'] ) ) ) ) );
		} else {
			$settings = \BetterLinksPro\Admin\FullSiteScannerReport::get_scan_settings();
			$post_types = isset( $settings['post_types'] ) ? $settings['post_types'] : array( 'post', 'page' );
		}

		// Ensure post_types is an array of strings
		if ( is_string( $post_types ) ) {
			$post_types = array_map( 'trim', explode( ',', $post_types ) );
		}
		if ( empty( $post_types ) ) {
			$post_types = array( 'post', 'page' );
		}

		// Run the scan (force = true bypasses the daily/monthly day-of-week gate)
		$scan_instance = new \BetterLinksPro\Admin\FullSiteScannerReport();
		$results = $scan_instance->run_scheduled_scan( $post_types, true );

		wp_send_json_success( array(
			'message' => __( 'Scheduled scan executed successfully', 'betterlinks-pro' ),
			'scan_results' => array(
				'total_links' => isset( $results['total_links'] ) ? $results['total_links'] : 0,
				'links_scanned' => isset( $results['links_scanned'] ) ? $results['links_scanned'] : 0,
				'broken_links' => isset( $results['broken_links'] ) ? $results['broken_links'] : 0,
				'unauthorized_links' => isset( $results['unauthorized_links'] ) ? $results['unauthorized_links'] : 0,
				'forbidden_links' => isset( $results['forbidden_links'] ) ? $results['forbidden_links'] : 0,
				'scan_time' => isset( $results['scan_time'] ) ? $results['scan_time'] : current_time( 'mysql' ),
			),
		) );
	}

	/**
	 * Return the latest persisted scan stats snapshot.
	 */
	public function get_fullsite_report_last_stats() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! apply_filters( 'betterlinkspro/admin/current_user_can_edit_settings', current_user_can( 'manage_options' ) ) ) {
			wp_die( "You don't have permission to do this" );
		}

		$stats = \BetterLinksPro\Admin\FullSiteScannerReport::get_last_stats();

		// Snapshots written before `scan_timestamp` existed only carry the local
		// mysql `scan_time`, so fall back to converting that.
		$timestamp = ! empty( $stats['scan_timestamp'] ) ? (int) $stats['scan_timestamp'] : 0;
		if ( ! $timestamp && ! empty( $stats['scan_time'] ) ) {
			$timestamp = (int) strtotime( get_gmt_from_date( $stats['scan_time'] ) . ' +0000' );
		}

		/* translators: %s: human readable time difference, e.g. "40 mins". */
		$stats['last_run_human'] = $timestamp ? sprintf( __( '%s ago', 'betterlinks-pro' ), human_time_diff( $timestamp, time() ) ) : '';

		wp_send_json_success( $stats );
	}

	/**
	 * Persist the latest scan stats snapshot from a client-side scan run.
	 */
	public function save_fullsite_report_last_stats() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );
		if ( ! apply_filters( 'betterlinkspro/admin/current_user_can_edit_settings', current_user_can( 'manage_options' ) ) ) {
			wp_die( "You don't have permission to do this" );
		}

		$payload = array(
			'total_links'        => isset( $_POST['total_links'] ) ? absint( $_POST['total_links'] ) : 0,
			'links_scanned'      => isset( $_POST['links_scanned'] ) ? absint( $_POST['links_scanned'] ) : 0,
			'broken_links'       => isset( $_POST['broken_links'] ) ? absint( $_POST['broken_links'] ) : 0,
			'unauthorized_links' => isset( $_POST['unauthorized_links'] ) ? absint( $_POST['unauthorized_links'] ) : 0,
			'forbidden_links'    => isset( $_POST['forbidden_links'] ) ? absint( $_POST['forbidden_links'] ) : 0,
			'scan_time'          => current_time( 'mysql' ),
		);

		$saved = \BetterLinksPro\Admin\FullSiteScannerReport::save_last_stats( $payload );
		wp_send_json_success( $saved );
	}

	/**
	 * Start Force Fullsite Scan with CRON Job
	 * This method initiates a background scan that continues even if the page is closed
	 */
	public function start_force_fullsite_scan() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );

		if ( ! apply_filters( 'betterlinkspro/admin/current_user_can_manage_link_scanner', $this->current_user_can_manage_link_scanner() ) ) {
			wp_send_json_error( array(
				'message' => __( 'You do not have permission to perform this action.', 'betterlinks-pro' ),
			), 403 );
		}

		try {
			// Get allowed post types from settings
			$allowed_post_types = $this->fullsite_scanner_allowed_post_type();

			if ( empty( $allowed_post_types ) ) {
				wp_send_json_error( array(
					'message' => __( 'No post types selected for scanning. Please configure scanner settings.', 'betterlinks-pro' ),
				) );
			}

			// Count total posts to scan
			$count_query = new \WP_Query( array(
				'post_type'      => $allowed_post_types,
				'post_status'    => array( 'publish', 'pending', 'draft', 'future', 'private', 'inherit' ),
				'fields'         => 'ids',
				'posts_per_page' => 1,
			) );
			$total_posts = $count_query->found_posts;

			// Clear previous scan data
			delete_option( BETTERLINKS_PRO_FULLSITE_BROKEN_LINK_LOGS );
			delete_option( 'betterlinks_pro_fullsite_last_scaned_post' );
			delete_option( 'betterlinkspro_force_scan_completed' );
			delete_transient( 'betterlinkspro_force_scan_lock' );

			// Initialize batch progress state
			$progress = array(
				'status'       => 'running',
				'last_post_id' => 0,
				'total_posts'  => $total_posts,
				'scanned'      => 0,
				'started_at'   => current_time( 'mysql' ),
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
			);
			update_option( 'betterlinkspro_force_scan_progress', $progress );

			// Schedule a fallback CRON event (in case loopback fails)
			$hook_name = 'betterlinkspro/force_fullsite_scan_cron';
			wp_clear_scheduled_hook( $hook_name );
			if ( ! wp_next_scheduled( $hook_name ) ) {
				wp_schedule_event( time(), 'hourly', $hook_name );
			}

			// Trigger the first batch immediately via loopback request. The token is
			// minted here, inside the nonce- and capability-checked entry point, and
			// is what authorises the otherwise-anonymous background handler.
			wp_remote_post(
				admin_url( 'admin-ajax.php' ),
				array(
					'blocking'  => false,
					// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WP core filter for local SSL verification.
					'sslverify' => apply_filters( 'https_local_over_ssl', false ),
					'timeout'   => 0.01,
					'body'      => array(
						'action' => 'betterlinkspro/force_fullsite_scan_background',
						'token'  => self::issue_force_scan_token(),
					),
				)
			);

			wp_send_json_success( array(
				'message'        => __( 'Force scan has been initiated! The scan will run in the background.', 'betterlinks-pro' ),
				'cron_scheduled' => true,
				'total_posts'    => $total_posts,
			) );

		} catch ( \Exception $e ) {
			wp_send_json_error( array(
				'message' => $e->getMessage(),
			) );
		}
	}

	/**
	 * Get force scan progress/status.
	 * Returns current batch progress so frontend can show real-time updates.
	 */
	public function get_force_scan_status() {
		check_ajax_referer( 'betterlinkspro_admin_nonce', 'security' );

		if ( ! apply_filters( 'betterlinkspro/admin/current_user_can_manage_link_scanner', $this->current_user_can_manage_link_scanner() ) ) {
			wp_send_json_error( array(
				'message' => __( 'You do not have permission to perform this action.', 'betterlinks-pro' ),
			), 403 );
		}

		$progress = get_option( 'betterlinkspro_force_scan_progress', array() );

		if ( empty( $progress ) ) {
			wp_send_json_success( array(
				'status'      => 'idle',
				'scanned'     => 0,
				'total_posts' => 0,
				'percentage'  => 0,
			) );
		}

		$total   = isset( $progress['total_posts'] ) ? intval( $progress['total_posts'] ) : 0;
		$scanned = isset( $progress['scanned'] ) ? intval( $progress['scanned'] ) : 0;
		$pct     = $total > 0 ? round( ( $scanned / $total ) * 100, 1 ) : 0;

		wp_send_json_success( array(
			'status'      => isset( $progress['status'] ) ? $progress['status'] : 'unknown',
			'scanned'     => $scanned,
			'total_posts' => $total,
			'percentage'  => $pct,
			'started_at'  => isset( $progress['started_at'] ) ? $progress['started_at'] : '',
			'completed_at'=> isset( $progress['completed_at'] ) ? $progress['completed_at'] : '',
			'error'       => isset( $progress['error'] ) ? $progress['error'] : '',
		) );
	}

	/**
	 * Trigger Force Fullsite Scan Background Job
	 * This is called via loopback request to execute the CRON job
	 */
	public function trigger_force_fullsite_scan_background() {
		// This action is registered on wp_ajax_nopriv_ because the loopback that
		// drives each batch carries no cookies. It previously ran do_action()
		// unconditionally, so any anonymous POST could start a full-site crawl —
		// tens of outbound requests per batch, chained batch after batch — and
		// could also overwrite the admin's scan progress and broken-link logs.
		// The single-use token is what the loopback proves and an outsider cannot.
		$token = ( isset( $_POST['token'] ) && is_scalar( $_POST['token'] ) ) ? sanitize_text_field( wp_unslash( $_POST['token'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- cookieless internal loopback; the token below is the authenticator.

		if ( ! self::consume_force_scan_token( $token ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Invalid or expired scan token.', 'betterlinks-pro' ),
				),
				403
			);
		}

		// Execute the CRON hook
		do_action( 'betterlinkspro/force_fullsite_scan_cron' );
		wp_die();
	}

	// ---- Country analytics (moved from the free plugin) ----

	/**
	 * Update click record with country data
	 *
	 * Used for backward compatibility to update existing clicks with country information
	 */
	public function update_click_country() {
		check_ajax_referer( 'betterlinks_admin_nonce', 'security' );

		// Writes to the clicks table by arbitrary click id. Admin-facing
		// analytics repair, so it takes the same gate as the rest of the
		// analytics surface rather than running on a nonce alone.
		// Writes click rows: needs more than the analytics read permission.
		if ( ! apply_filters( 'betterlinks/api/analytics_delete_permissions_check', current_user_can( 'manage_options' ) ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Insufficient permissions', 'betterlinks-pro' ),
				),
				403
			);
		}


		global $wpdb;

		$click_id = isset( $_POST['click_id'] ) ? intval( $_POST['click_id'] ) : 0;
		$country_code = isset( $_POST['country_code'] ) ? sanitize_text_field( wp_unslash( $_POST['country_code'] ) ) : '';
		$country_name = isset( $_POST['country_name'] ) ? sanitize_text_field( wp_unslash( $_POST['country_name'] ) ) : '';

		if ( ! $click_id || ! $country_code || ! $country_name ) {
			wp_send_json_error( array(
				'message' => __( 'Invalid parameters', 'betterlinks-pro' )
			) );
		}

		$table_name = $wpdb->prefix . 'betterlinks_clicks';

		// Get or create country record and get its ID
		$country_id = \BetterLinksPro\Services\CountryDetectionService::get_or_create_country_id(
			$country_code,
			$country_name
		);

		if ( ! $country_id ) {
			wp_send_json_error( array(
				'message' => __( 'Failed to create country record', 'betterlinks-pro' )
			) );
		}

		$updated = $wpdb->update(
			$table_name,
			array( 'country_id' => $country_id ),
			array( 'ID' => $click_id ),
			array( '%d' ),
			array( '%d' )
		);

		if ( $updated !== false ) {
			wp_send_json_success( array(
				'message' => __( 'Country data updated successfully', 'betterlinks-pro' ),
				'country_code' => $country_code,
				'country_name' => $country_name,
				'country_id' => $country_id,
			) );
		} else {
			wp_send_json_error( array(
				'message' => __( 'Failed to update country data', 'betterlinks-pro' )
			) );
		}
	}

	/**
	 * Update all clicks with the same IP within a specific link with country data
	 *
	 * This bulk update ensures that when country is fetched for one IP,
	 * all clicks from the same IP within the same short URL are updated automatically
	 */
	public function update_clicks_country_by_ip() {
		check_ajax_referer( 'betterlinks_admin_nonce', 'security' );

		// Bulk-writes the clicks table by attacker-chosen link_id + ip and
		// flushes that link's analytics caches — same analytics gate as above.
		// Writes click rows: needs more than the analytics read permission.
		if ( ! apply_filters( 'betterlinks/api/analytics_delete_permissions_check', current_user_can( 'manage_options' ) ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Insufficient permissions', 'betterlinks-pro' ),
				),
				403
			);
		}



		global $wpdb;

		$link_id = isset( $_POST['link_id'] ) ? intval( $_POST['link_id'] ) : 0;
		$ip = isset( $_POST['ip'] ) ? sanitize_text_field( wp_unslash( $_POST['ip'] ) ) : '';
		$country_code = isset( $_POST['country_code'] ) ? sanitize_text_field( wp_unslash( $_POST['country_code'] ) ) : '';
		$country_name = isset( $_POST['country_name'] ) ? sanitize_text_field( wp_unslash( $_POST['country_name'] ) ) : '';

		if ( ! $link_id || ! $ip || ! $country_code || ! $country_name ) {
			wp_send_json_error( array(
				'message' => __( 'Invalid parameters', 'betterlinks-pro' )
			) );
		}

		$table_name = $wpdb->prefix . 'betterlinks_clicks';

		// Get or create country record and get its ID
		$country_id = \BetterLinksPro\Services\CountryDetectionService::get_or_create_country_id(
			$country_code,
			$country_name
		);

		if ( ! $country_id ) {
			wp_send_json_error( array(
				'message' => __( 'Failed to create country record', 'betterlinks-pro' )
			) );
		}

		// Update all clicks with the same IP within this link_id
		// This will update ALL clicks with this IP, regardless of whether they already have country data
		$updated = $wpdb->update(
			$table_name,
			array( 'country_id' => $country_id ),
			array(
				'link_id' => $link_id,
				'ip' => $ip,
			),
			array( '%d' ),
			array( '%d', '%s' )
		);

		if ( $updated !== false ) {
			// Clear the transient cache for this link's analytics data
			// This ensures the API returns fresh data with the updated country information
			$this->clear_individual_clicks_transient( $link_id );

			wp_send_json_success( array(
				/* translators: %s = placeholder values supplied by WordPress */
				'message' => sprintf( __( 'Country data updated for %d clicks', 'betterlinks-pro' ), $updated ),
				'country_code' => $country_code,
				'country_name' => $country_name,
				'country_id' => $country_id,
				'updated_count' => $updated,
			) );
		} else {
			wp_send_json_error( array(
				'message' => __( 'Failed to update country data', 'betterlinks-pro' )
			) );
		}
	}

	/**
	 * Clear transient cache for individual clicks analytics
	 * This ensures fresh data is fetched from the database
	 *
	 * @param int $link_id The link ID
	 */
	private function clear_individual_clicks_transient( $link_id ) {
		global $wpdb;

		// Get all transient keys for this link and delete them
		// The transient key format is: btl_individual_analytics_clicks_{from}_{to}_{link_id}
		$transient_prefix = 'btl_individual_analytics_clicks_';

		// Query the options table to find all matching transients
		$transients = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
				'%' . $wpdb->esc_like( $transient_prefix ) . '%' . $wpdb->esc_like( (string) $link_id ) . '%'
			)
		);

		// Delete each transient
		if ( $transients ) {
			foreach ( $transients as $transient ) {
				// Remove the '_transient_' prefix to get the transient name
				$transient_name = str_replace( '_transient_', '', $transient->option_name );
				delete_transient( $transient_name );
			}
		}
	}
}

