<?php
namespace BetterLinksPro\Admin;
if ( ! defined( 'ABSPATH' ) ) { exit; }

use BetterLinksPro\Compat;
use BetterLinksPro\Helper;

/**
 * Pro data the free plugin used to read or compute itself, now supplied through
 * its hooks:
 * - betterlinks/admin/link_item: custom tracking scripts and broken-link status.
 * - betterlinks/analytics/individual_link_clicks: per-link click analytics.
 * - betterlinks/sanitize/skip_keys + betterlinkspro/admin/update_settings: the
 *   custom auto-link icon is sanitized by Pro's SVG sanitizer.
 * - betterlinks/wpinsights/optional_data: password-protection usage counts.
 * - AJAX endpoints the free admin app calls for Pro settings, with the same action
 *   names the free plugin used to register.
 * - The block editor's Affiliate Link Disclosure storage (free 3.1.5+), under the
 *   action names free 3.1.4 registered.
 *
 * Older free plugins do all of this inline, so nothing is registered there.
 */
class FreeBridge {

	/**
	 * @var array|null
	 */
	private $broken_links = null;

	public static function init() {
		if ( ! Compat::free_has_extension_api() ) {
			return;
		}
		$self = new self();
		add_filter( 'betterlinks/admin/link_item', array( $self, 'link_item' ) );
		add_filter( 'betterlinks/analytics/individual_link_clicks', array( $self, 'individual_link_clicks' ), 10, 2 );
		add_filter( 'betterlinks/sanitize/skip_keys', array( $self, 'skip_keys' ) );
		add_filter( 'betterlinkspro/admin/update_settings', array( $self, 'sanitize_custom_icon' ), 20 );
		add_filter( 'betterlinks/wpinsights/optional_data', array( $self, 'usage_data' ) );
		add_action( 'wp_ajax_betterlinks/admin/get_autolink_create_settings', array( $self, 'get_auto_link_create_settings' ) );
		add_action( 'wp_ajax_betterlinks/admin/get_auto_create_links_settings', array( $self, 'get_auto_link_create_settings' ) );
		add_action( 'wp_ajax_betterlinks/admin/get_external_analytics', array( $self, 'get_external_analytics' ) );

		if ( Compat::free_has_block_editor_api() ) {
			add_action( 'wp_ajax_betterlinks/admin/set_affiliate_link_disclosure_post', array( $self, 'set_affiliate_link_disclosure_post' ) );
			add_action( 'wp_ajax_betterlinks/admin/get_affiliate_link_disclosure_post', array( $self, 'get_affiliate_link_disclosure_post' ) );
			add_action( 'wp_ajax_betterlinks/admin/set_affiliate_link_disclosure_text', array( $self, 'set_affiliate_link_disclosure_text' ) );
			add_action( 'wp_ajax_betterlinks/admin/get_affiliate_link_disclosure_text', array( $self, 'get_affiliate_link_disclosure_text' ) );
		}
	}

	/**
	 * @param object $item Link item.
	 * @return object
	 */
	public function link_item( $item ) {
		if ( ! is_object( $item ) || empty( $item->ID ) ) {
			return $item;
		}
		$scripts = \BetterLinks\Helper::get_link_meta( $item->ID, 'btl_custom_tracking_scripts' );
		if ( ! empty( $scripts ) ) {
			$scripts                       = unserialize( $scripts, array( 'allowed_classes' => false ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_unserialize
			$item->enable_custom_scripts   = isset( $scripts['enable'] ) ? $scripts['enable'] : false;
			$item->custom_tracking_scripts = isset( $scripts['script'] ) ? $scripts['script'] : '';
		}

		if ( null === $this->broken_links ) {
			$logs               = get_option( 'betterlinkspro_broken_links_logs' );
			$this->broken_links = $logs ? (array) json_decode( $logs, true ) : array();
		}
		$log = isset( $this->broken_links[ $item->ID ] ) && is_array( $this->broken_links[ $item->ID ] ) ? $this->broken_links[ $item->ID ] : null;
		if ( $log ) {
			if ( isset( $log['status']['status_code'] ) && in_array( (int) $log['status']['status_code'], array( 401, 403, 404 ), true ) && empty( $log['is_log_removed'] ) ) {
				$item->link_status = 'broken';
			} elseif ( isset( $item->link_status ) && 'broken' === $item->link_status && isset( $log['old_link_status'] ) && 'broken' !== $log['old_link_status'] ) {
				// Fixed link whose row was not updated yet: show its previous status.
				$item->link_status = $log['old_link_status'];
			}
		}
		return $item;
	}

	/**
	 * @param array|null $results Rows.
	 * @param array      $args    { id, from, to }.
	 * @return array|null
	 */
	public function individual_link_clicks( $results, $args ) {
		return null === $results ? Helper::get_individual_link_analytics( $args ) : $results;
	}

	/**
	 * @param string[] $skip Keys.
	 * @return string[]
	 */
	public function skip_keys( $skip ) {
		$skip   = (array) $skip;
		$skip[] = 'autolink_custom_icon';
		return $skip;
	}

	/**
	 * @param array $response Settings being saved.
	 * @return array
	 */
	public function sanitize_custom_icon( $response ) {
		if ( is_array( $response ) && ! empty( $response['autolink_custom_icon'] ) && is_string( $response['autolink_custom_icon'] ) ) {
			$response['autolink_custom_icon'] = \BetterLinksPro\Frontend\AutoLinks::sanitize_custom_svg( $response['autolink_custom_icon'] );
		}
		return $response;
	}

	/**
	 * @param array $data Optional usage data.
	 * @return array
	 */
	public function usage_data( $data ) {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$count = $wpdb->get_row( "SELECT COUNT(*) AS password_protected, SUM(status) AS active_password_protected FROM {$wpdb->prefix}betterlinks_password", ARRAY_A );
		return array_merge( (array) $data, is_array( $count ) ? $count : array() );
	}

	/**
	 * Send a Pro settings option to the free admin app.
	 *
	 * @param string $option Option name.
	 */
	private function send_option( $option ) {
		check_ajax_referer( 'betterlinks_admin_nonce', 'security' );
		if ( ! apply_filters( 'betterlinkspro/admin/current_user_can_edit_settings', current_user_can( 'manage_options' ) ) ) {
			wp_die( esc_html__( "You don't have permission to do this.", 'betterlinks-pro' ) );
		}
		$data = get_option( $option, array() );
		if ( is_string( $data ) ) {
			$data = json_decode( $data, true );
		}
		wp_send_json_success( $data );
	}

	public function get_auto_link_create_settings() {
		$this->send_option( BETTERLINKS_PRO_AUTO_LINK_CREATE_OPTION_NAME );
	}

	public function get_external_analytics() {
		$this->send_option( BETTERLINKS_PRO_EXTERNAL_ANALYTICS_OPTION_NAME );
	}

	/**
	 * Affiliate Link Disclosure: nonce and capability check for the block editor's
	 * per-post storage below.
	 */
	private function check_affiliate_disclosure_request() {
		check_ajax_referer( 'betterlinks_admin_nonce', 'security' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( "You don't have permission to do this.", 'betterlinks-pro' ) );
		}
	}

	public function set_affiliate_link_disclosure_post() {
		$this->check_affiliate_disclosure_request();

		$id    = isset( $_POST['ID'] ) ? intval( $_POST['ID'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified in check_affiliate_disclosure_request().
		$value = isset( $_POST['value'] ) ? sanitize_text_field( wp_unslash( $_POST['value'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing

		update_post_meta( $id, Metabox::AFFILIATE_DISCLOSURE_ENABLE, $value );

		wp_send_json(
			array(
				'ID'    => $id,
				'value' => $value,
			)
		);
	}

	public function get_affiliate_link_disclosure_post() {
		$this->check_affiliate_disclosure_request();

		$id = isset( $_POST['ID'] ) ? intval( sanitize_text_field( wp_unslash( $_POST['ID'] ) ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		wp_send_json( get_post_meta( $id, Metabox::AFFILIATE_DISCLOSURE_ENABLE ) );
	}

	public function set_affiliate_link_disclosure_text() {
		$this->check_affiliate_disclosure_request();

		$id    = isset( $_POST['ID'] ) ? sanitize_text_field( wp_unslash( $_POST['ID'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$value = isset( $_POST['value'] ) ? wp_kses_post( wp_unslash( $_POST['value'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing

		if ( ! empty( get_post_meta( $id, Metabox::AFFILIATE_DISCLOSURE_FIELDS ) ) ) {
			update_post_meta( $id, Metabox::AFFILIATE_DISCLOSURE_FIELDS, $value );
		} else {
			add_post_meta( $id, Metabox::AFFILIATE_DISCLOSURE_FIELDS, $value );
		}

		// Register per-post disclosure text with WPML String Translation.
		$decoded_value = is_string( $value ) ? json_decode( $value, true ) : $value;
		if ( is_array( $decoded_value ) && ! empty( $decoded_value['affiliate_disclosure_text'] ) ) {
			do_action( 'wpml_register_single_string', 'BetterLinks', 'Affiliate Disclosure Text - Post ' . $id, $decoded_value['affiliate_disclosure_text'] ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WPML public hook name; cannot be prefixed.
		}

		wp_send_json( $value );
	}

	public function get_affiliate_link_disclosure_text() {
		$this->check_affiliate_disclosure_request();

		$id             = isset( $_POST['ID'] ) ? sanitize_text_field( wp_unslash( $_POST['ID'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$data           = array();
		$affiliate_text = get_post_meta( $id, Metabox::AFFILIATE_DISCLOSURE_FIELDS );
		if ( count( $affiliate_text ) > 0 ) {
			$data = json_decode( html_entity_decode( $affiliate_text[0] ), true );
		}

		$settings                  = json_decode( get_option( BETTERLINKS_LINKS_OPTION_NAME ), true );
		$affiliate_disclosure_text = ! empty( $settings['affiliate_disclosure_text'] ) ? $settings['affiliate_disclosure_text'] : '';
		$affiliate_link_position   = ! empty( $settings['affiliate_link_position'] ) ? sanitize_text_field( $settings['affiliate_link_position'] ) : '';

		wp_send_json(
			array(
				'affiliate_disclosure_text' => empty( $data['affiliate_disclosure_text'] ) ? $affiliate_disclosure_text : str_replace( ' rn ', '', $data['affiliate_disclosure_text'] ),
				'affiliate_link_position'   => empty( $data['affiliate_link_position'] ) ? $affiliate_link_position : $data['affiliate_link_position'],
			)
		);
	}
}
