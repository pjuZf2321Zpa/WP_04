<?php
/**
 * @since 1.8.0
 * @package Cutomize Meta Preview
 *
 * Template Name: Customize Meta Tags
 * Template Post Type: page
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Public-facing routing template; reads short_url query var, no state mutation.
// phpcs:ignore WordPress.Security.NonceVerification.Recommended
$betterlinks_pro_short_url = ! empty( $_GET['short_url'] ) ? sanitize_text_field( wp_unslash( $_GET['short_url'] ) ) : null;
if ( empty( $betterlinks_pro_short_url ) ) {
	wp_safe_redirect( site_url() . '/404' );
	exit();
}
$betterlinks_pro_meta_tags  = \BetterLinksPro\Helper::get_meta_tags_by_short_url( $betterlinks_pro_short_url );

// Only published links with enabled meta tags and no active password get a preview.
$betterlinks_pro_link_id  = isset( $betterlinks_pro_meta_tags['link_id'] ) ? absint( $betterlinks_pro_meta_tags['link_id'] ) : 0;
$betterlinks_pro_password = $betterlinks_pro_link_id ? \BetterLinksPro\Helper::get_password_by_link_id( $betterlinks_pro_link_id ) : array();
$betterlinks_pro_has_pass = ! empty( $betterlinks_pro_password ) && isset( $betterlinks_pro_password[0]->status ) && '1' === (string) $betterlinks_pro_password[0]->status;
if (
	empty( $betterlinks_pro_meta_tags )
	|| ( isset( $betterlinks_pro_meta_tags['link_status'] ) && 'publish' !== $betterlinks_pro_meta_tags['link_status'] )
	|| $betterlinks_pro_has_pass
) {
	wp_safe_redirect( site_url() . '/404' );
	exit();
}

$betterlinks_pro_meta_title = isset( $betterlinks_pro_meta_tags['meta_title'] ) ? sanitize_text_field( $betterlinks_pro_meta_tags['meta_title'] ) : '';
$betterlinks_pro_meta_desc  = isset( $betterlinks_pro_meta_tags['meta_desc'] ) ? sanitize_text_field( $betterlinks_pro_meta_tags['meta_desc'] ) : '';
$betterlinks_pro_meta_image = isset( $betterlinks_pro_meta_tags['meta_image'] ) ? esc_url_raw( $betterlinks_pro_meta_tags['meta_image'] ) : '';
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta property="og:type" content="article" />

	<meta property="og:title" content="<?php echo esc_attr( $betterlinks_pro_meta_title ); ?>">
	<meta property="og:description" content="<?php echo esc_attr( $betterlinks_pro_meta_desc ); ?>">
	<meta property="og:image" content="<?php echo esc_url( $betterlinks_pro_meta_image ); ?>">

	<!-- Twitter Card Tags (Optional) -->
	<meta name="twitter:card" content="summary_large_image">
	<meta name="twitter:title" content="<?php echo esc_attr( $betterlinks_pro_meta_title ); ?>">
	<meta name="twitter:description" content="<?php echo esc_attr( $betterlinks_pro_meta_desc ); ?>">
	<meta name="twitter:image" content="<?php echo esc_url( $betterlinks_pro_meta_image ); ?>">

	<title><?php echo esc_html( $betterlinks_pro_meta_title ); ?></title>
</head>

<body>
	<h1><?php echo esc_html( $betterlinks_pro_meta_title ); ?></h1>
	<img src="<?php echo esc_url( $betterlinks_pro_meta_image ); ?>" alt="<?php echo esc_attr( $betterlinks_pro_meta_title ); ?>" />
	<p><?php echo esc_html( $betterlinks_pro_meta_desc ); ?></p>
</body>

</html>
