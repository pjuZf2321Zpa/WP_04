<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php esc_html_e('BetterLinks', 'betterlinks-pro'); ?></title>
</head>
<body>
    <div class="betterlinks-email-report" style="background-color:#f3f7fa; margin:0;padding:50px;">
        <div style="width: 600px; margin: auto; background: #fff; padding: 30px;">
            <table style="border-collapse: collapse; width: 100.577%; height: 36px;" border="0">
                <tbody>
                    <tr style="height: 36px;">
                        <td style="width: 50%; height: 36px;">
                            <img class="betterlinks-email-logo" src="<?php echo esc_url($logo); ?>"  alt="BetterLinks" style="display: block"/>
                        </td>
                        <td style="width: 50%; height: 36px;" align="right">
                            <span style="color: #848484;"><?php esc_html_e('Your Full Site Link Scan Report', 'betterlinks-pro'); ?></span><br />
                            <span style="color: #444444;"><?php echo esc_html( $report_time ); ?></span>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <p style="margin: 50px 0 15px; color: #444444;">
                                <?php
                                    /* translators: %1$s: text value; %2$s: text value; %3$s: text value. */
                                    echo esc_html(sprintf(__('During the scan conducted on %1$s, %2$s broken links were discovered out of %3$s total links.', 'betterlinks-pro'), $report_time, $broken_links_count, $total_links));
                                ?>
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <table style="border-collapse: collapse; width: 100%;" border="0">
                                <tbody>
                                    <tr>
                                        <td style="width: 25%; background-color:#e5ecf2;text-transform:uppercase;padding:10px 0px;font-size:12px; color: #444444; border: 1px solid #e5ecf2;" align="center"><strong><?php esc_html_e('Total Links', 'betterlinks-pro'); ?></strong></td>
                                        <td style="width: 25%; background-color:#e5ecf2;text-transform:uppercase;padding:10px 0px;font-size:12px; color: #444444; border: 1px solid #e5ecf2;" align="center"><strong><?php esc_html_e('Broken Links', 'betterlinks-pro'); ?></strong></td>
                                        <td style="width: 25%; background-color:#e5ecf2;text-transform:uppercase;padding:10px 0px;font-size:12px; color: #444444; border: 1px solid #e5ecf2;" align="center"><strong><?php esc_html_e('Unauthorized', 'betterlinks-pro'); ?></strong></td>
                                        <td style="width: 25%; background-color:#e5ecf2;text-transform:uppercase;padding:10px 0px;font-size:12px; color: #444444; border: 1px solid #e5ecf2;" align="center"><strong><?php esc_html_e('Forbidden', 'betterlinks-pro'); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td style="width: 25%; padding:10px 5px;font-size:22px; color: #444444; border: 1px solid #e5ecf2;" align="center"><strong><?php echo esc_html( $total_links ); ?></strong></td>
                                        <td style="width: 25%; padding:10px 5px;font-size:22px; color: #d32f2f; border: 1px solid #e5ecf2;" align="center"><strong><?php echo esc_html( $broken_links_count ); ?></strong></td>
                                        <td style="width: 25%; padding:10px 5px;font-size:22px; color: #444444; border: 1px solid #e5ecf2;" align="center"><strong><?php echo esc_html( $unauthorized_count ); ?></strong></td>
                                        <td style="width: 25%; padding:10px 5px;font-size:22px; color: #444444; border: 1px solid #e5ecf2;" align="center"><strong><?php echo esc_html( $forbidden_count ); ?></strong></td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                    <?php if (!empty($broken_links)) : ?>
                        <tr>
                            <td colspan="2" style="padding-top: 30px;">
                                <h3 style="color: #444444; margin-top: 20px;">
                                    <?php esc_html_e('Broken Links Found', 'betterlinks-pro'); ?>
                                </h3>
                                <table style="border-collapse: collapse; width: 100%; margin-top: 15px;" border="0">
                                    <thead>
                                        <tr style="background-color: #e5ecf2;">
                                            <th style="padding: 10px; text-align: left; border: 1px solid #d0d0d0; color: #444444; font-weight: bold;">
                                                <?php esc_html_e('Link URL', 'betterlinks-pro'); ?>
                                            </th>
                                            <th style="padding: 10px; text-align: left; border: 1px solid #d0d0d0; color: #444444; font-weight: bold;">
                                                <?php esc_html_e('Post Title', 'betterlinks-pro'); ?>
                                            </th>
                                            <th style="padding: 10px; text-align: center; border: 1px solid #d0d0d0; color: #444444; font-weight: bold; width: 80px;">
                                                <?php esc_html_e('Action', 'betterlinks-pro'); ?>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($broken_links as $link) : ?>
                                            <tr>
                                                <td style="padding: 10px; border: 1px solid #d0d0d0; color: #444444;">
                                                    <a href="<?php echo esc_url($link['link_url']); ?>" target="_blank" style="color: #2961ff; text-decoration: none;">
                                                        <?php echo esc_html($link['link_url']); ?>
                                                    </a>
                                                </td>
                                                <td style="padding: 10px; border: 1px solid #d0d0d0; color: #444444;">
                                                    <?php
                                                        $betterlinks_pro_post_link = get_permalink( $link['post_id'] );
                                                        if ( $betterlinks_pro_post_link ) :
                                                    ?>
                                                        <a href="<?php echo esc_url( $betterlinks_pro_post_link ); ?>" target="_blank" style="color: #2961ff; text-decoration: none;">
                                                            <?php echo esc_html( $link['post_title'] ); ?>
                                                        </a>
                                                    <?php else : ?>
                                                        <?php echo esc_html( $link['post_title'] ); ?>
                                                    <?php endif; ?>
                                                </td>
                                                <td style="padding: 10px; border: 1px solid #d0d0d0; color: #444444; text-align: center;">
                                                    <?php
                                                        $betterlinks_pro_edit_url = get_edit_post_link( $link['post_id'], 'raw' );
                                                        if ( $betterlinks_pro_edit_url ) :
                                                    ?>
                                                        <a href="<?php echo esc_url( $betterlinks_pro_edit_url ); ?>" target="_blank" style="color: #fff; text-decoration: none; background-color: #2961ff; padding: 6px 12px; border-radius: 3px; display: inline-block; font-size: 12px;">
                                                            <?php esc_html_e( 'Edit', 'betterlinks-pro' ); ?>
                                                        </a>
                                                    <?php else : ?>
                                                        <span style="color: #999; font-size: 12px;">—</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    <?php endif; ?>
                    <tr>
                        <td colspan="2">
                            <div style="text-align: center; margin-top: 30px;">
                                <a href="<?php echo esc_url($admin_url); ?>" style="display: inline-block; padding: 15px 30px; color: #fff; text-decoration: none; background: linear-gradient(202deg,#2961ff 0%,#003be2 100%); border-radius: 4px;" target="_blank"><?php esc_html_e('View Full Site Scanner', 'betterlinks-pro'); ?></a>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="betterlinks-info">
            <p style="color: #444444;text-align: center;width: 70%;margin: auto;margin-top: 15px;">
                <?php echo wp_kses_post(__('If you have any feedback or queries, feel free to reach out to our <a href="https://betterlinks.io/scheduled-scan/support" style="color: #2961ff; text-decoration: none;" target="_blank">support team</a>.', 'betterlinks-pro')); ?>
            </p>
        </div>
    </div>
</body>
</html>
