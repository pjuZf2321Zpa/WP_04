<?php
namespace BetterLinksPro\Admin;
if ( ! defined( 'ABSPATH' ) ) { exit; }

use BetterLinksPro\Compat;

// phpcs:disable WordPress.DB.DirectDatabaseQuery

/**
 * Global UTM templates: auto-apply to new links and bulk apply to categories.
 *
 * Templates stay in the BetterLinks settings option (`global_utm_templates`,
 * `utm_last_applied_templates`). Moved from the free plugin, where the engine ran
 * while template management was locked to Pro. The AJAX action names are
 * unchanged. Bulk apply now requires the link update permission and the status
 * counts the link read permission, instead of the settings permission.
 */
class UTMTemplates {

    public static function init() {
        if ( ! Compat::free_has_extension_api() ) {
            return; // Older free plugins still ship their own copy.
        }
        $self = new self();
        add_filter( 'betterlinks/link/auto_target_url', array( $self, 'auto_target_url' ), 10, 3 );
        add_action( 'wp_ajax_betterlinks/admin/apply_utm_template_to_links', array( $self, 'apply_utm_template_to_links' ) );
        add_action( 'wp_ajax_betterlinks/admin/get_utm_status_counts', array( $self, 'get_utm_status_counts' ) );
    }

    /**
     * betterlinks/link/auto_target_url: the target URL with the category's
     * auto-apply UTM template added, or null when nothing applies. The free plugin
     * saves the returned URL (database and links.json).
     */
    public function auto_target_url($current, $link_id, $link_args)
    {
        // Another extension already rewrote the URL.
        if (is_string($current) && '' !== $current) {
            return $current;
        }

        // Get the category ID from the link
        $category_id = isset($link_args['cat_id']) ? intval($link_args['cat_id']) : 1; // Default to Uncategorized

        // Get current settings
        $settings = get_option(BETTERLINKS_LINKS_OPTION_NAME, []);
        if (is_string($settings)) {
            $settings = json_decode($settings, true);
        }

        // Get UTM templates
        $utm_templates = isset($settings['global_utm_templates']) ? $settings['global_utm_templates'] : [];
        if (!is_array($utm_templates)) {
            return $current;
        }

        // Get last applied templates tracking
        $last_applied_templates = isset($settings['utm_last_applied_templates']) ? $settings['utm_last_applied_templates'] : [];
        
        // Find the most recently applied template for this category
        $matching_template = null;
        
        // First, check if there's a last applied template for this category
        // Normalize category ID for consistent comparison
        $normalized_category_id = strval($category_id);
        
        if (isset($last_applied_templates[$normalized_category_id])) {
            $last_applied_template_index = $last_applied_templates[$normalized_category_id]['template_index'];
            
            // Find the template with this index
            foreach ($utm_templates as $template) {
                if (isset($template['template_index']) && 
                    $template['template_index'] == $last_applied_template_index) {
                    
                    // Verify this template still applies to the current category
                    if (isset($template['categories']) && is_array($template['categories'])) {
                        foreach ($template['categories'] as $template_cat_id) {
                            // Normalize both IDs for comparison
                            $normalized_template_cat_id = strval($template_cat_id);
                            if ($normalized_template_cat_id === $normalized_category_id) {
                                // If the active template has auto-apply enabled, use it
                                if (!empty($template['utm_auto_apply_new_link'])) {
                                    $matching_template = $template;
                                }
                                // If active template exists but auto-apply is disabled, and don't use any template (respect user's choice) and Set a flag to prevent fallback search
                                $active_template_found = true;
                                break 2;
                            }
                        }
                    }
                }
            }
        }
        
        // Only fall back to finding any template if there's no active template for this category
        if (!$matching_template && !isset($active_template_found)) {
            foreach ($utm_templates as $template) {
                // Check if auto-apply is enabled for this template
                if (empty($template['utm_auto_apply_new_link'])) {
                    continue;
                }

                // Check if this template applies to the current category
                if (isset($template['categories']) && is_array($template['categories'])) {
                    foreach ($template['categories'] as $template_cat_id) {
                        // Normalize both IDs for comparison
                        $normalized_template_cat_id = strval($template_cat_id);
                        if ($normalized_template_cat_id === $normalized_category_id) {
                            $matching_template = $template;
                            break 2; // Break out of both loops
                        }
                    }
                }
            }
        }

        // If no matching template found, return
        if (!$matching_template) {
            return $current;
        }

        // Extract UTM parameters from template
        $utm_params = [
            'utm_source' => isset($matching_template['utm_source']) ? sanitize_text_field($matching_template['utm_source']) : '',
            'utm_medium' => isset($matching_template['utm_medium']) ? sanitize_text_field($matching_template['utm_medium']) : '',
            'utm_campaign' => isset($matching_template['utm_campaign']) ? sanitize_text_field($matching_template['utm_campaign']) : '',
            'utm_term' => isset($matching_template['utm_term']) ? sanitize_text_field($matching_template['utm_term']) : '',
            'utm_content' => isset($matching_template['utm_content']) ? sanitize_text_field($matching_template['utm_content']) : '',
        ];

        // Remove empty UTM parameters
        $utm_params = array_filter($utm_params, function($value) {
            return !empty($value);
        });

        // If no UTM parameters to apply, return
        if (empty($utm_params)) {
            return $current;
        }

        // Get the current target URL from the arguments (it should be the original URL)
        $target_url = isset($link_args['target_url']) ? $link_args['target_url'] : '';
        if (empty($target_url)) {
            return $current;
        }

        // Parse current target URL
        $url_parts = wp_parse_url($target_url);
        if (!$url_parts) {
            return $current;
        }
        
        // Parse existing query parameters
        $query_params = [];
        if (isset($url_parts['query'])) {
            parse_str($url_parts['query'], $query_params);
        }

        // Add UTM parameters (don't overwrite existing ones if rewrite is not enabled)
        $rewrite_existing = isset($matching_template['utm_enable_to_rewrite_existing_utm_template']) 
            ? $matching_template['utm_enable_to_rewrite_existing_utm_template'] 
            : false;

        $params_added = false;
        foreach ($utm_params as $key => $value) {
            if ($rewrite_existing || !isset($query_params[$key])) {
                $query_params[$key] = $value;
                $params_added = true;
            }
        }

        // If no parameters were added, return original URL
        if (!$params_added) {
            return $current;
        }

        // Reconstruct the URL
        $new_url = $url_parts['scheme'] . '://' . $url_parts['host'];
        if (isset($url_parts['port'])) {
            $new_url .= ':' . $url_parts['port'];
        }
        if (isset($url_parts['path'])) {
            $new_url .= $url_parts['path'];
        }
        if (!empty($query_params)) {
            $new_url .= '?' . http_build_query($query_params);
        }
        if (isset($url_parts['fragment'])) {
            $new_url .= '#' . $url_parts['fragment'];
        }

        return $new_url;
    }

	/**
	 * Apply UTM template to links
	 */
	public function apply_utm_template_to_links() {
		check_ajax_referer( 'betterlinks_admin_nonce', 'security' );

		if ( ! apply_filters( 'betterlinks/api/links_update_item_permissions_check', current_user_can( 'manage_options' ) ) ) {
			wp_send_json_error( __( 'You do not have permission to perform this action.', 'betterlinks-pro' ) );
		}

		// Clear cache to ensure fresh data after updates
		delete_transient( BETTERLINKS_CACHE_LINKS_NAME );

		// Parse JSON data that comes from makeRequest. JSON content is validated by json_decode + array shape checks below; sanitize_text_field would corrupt JSON.
		// phpcs:disable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$template_data    = isset( $_POST['template_data'] ) ? json_decode( wp_unslash( $_POST['template_data'] ), true ) : array();
		$category_ids     = isset( $_POST['category_ids'] ) ? json_decode( wp_unslash( $_POST['category_ids'] ), true ) : array();
		// phpcs:enable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$rewrite_existing = isset( $_POST['rewrite_existing'] ) ? filter_var( wp_unslash( $_POST['rewrite_existing'] ), FILTER_VALIDATE_BOOLEAN ) : false;
		$reset_existing   = isset( $_POST['reset_existing'] ) ? filter_var( wp_unslash( $_POST['reset_existing'] ), FILTER_VALIDATE_BOOLEAN ) : false;

		// Convert to integers if needed
		if ( is_array( $category_ids ) ) {
			$category_ids = array_map( 'intval', $category_ids );
		}

		if ( empty( $template_data ) || empty( $category_ids ) ) {
			wp_send_json_error( __( 'Invalid template data or categories.', 'betterlinks-pro' ) );
		}

		// Sanitize template data
		$utm_source = sanitize_text_field( $template_data['utm_source'] ?? '' );
		$utm_medium = sanitize_text_field( $template_data['utm_medium'] ?? '' );
		$utm_campaign = sanitize_text_field( $template_data['utm_campaign'] ?? '' );
		$utm_term = sanitize_text_field( $template_data['utm_term'] ?? '' );
		$utm_content = sanitize_text_field( $template_data['utm_content'] ?? '' );

		global $wpdb;

		// Get links for the specified categories.
		// $placeholders is built locally as '%d,%d,...' from $category_ids (int[]); table prefix is wpdb-controlled.
		// phpcs:disable WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$placeholders = implode( ',', array_fill( 0, count( $category_ids ), '%d' ) );
		$query = $wpdb->prepare(
			"SELECT DISTINCT l.ID, l.target_url
			FROM {$wpdb->prefix}betterlinks l
			INNER JOIN {$wpdb->prefix}betterlinks_terms_relationships tr ON l.ID = tr.link_id
			WHERE tr.term_id IN ($placeholders)",
			...$category_ids
		);
		// phpcs:enable WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare,WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		$links = $wpdb->get_results( $query, ARRAY_A );
		$updated_count = 0;
		$skipped_count = 0;

		foreach ( $links as $link ) {
			$target_url = $link['target_url'];
			$parsed_url = wp_parse_url( $target_url );
			
			// Check if URL already has UTM parameters
			$existing_query = isset( $parsed_url['query'] ) ? $parsed_url['query'] : '';
			parse_str( $existing_query, $existing_params );
			
			$has_utm = false;
			$utm_params = array( 'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content' );
			foreach ( $utm_params as $param ) {
				if ( isset( $existing_params[$param] ) && !empty( $existing_params[$param] ) ) {
					$has_utm = true;
					break;
				}
			}

			// Handle reset existing UTM functionality
			if ( $reset_existing ) {
				// Only process links that have UTM parameters to reset
				if ( ! $has_utm ) {
					$skipped_count++;
					continue;
				}
				// Remove all UTM parameters when resetting
				foreach ( $utm_params as $param ) {
					unset( $existing_params[$param] );
				}
			} else {
				// Skip if has UTM and rewrite is disabled
				if ( $has_utm && ! $rewrite_existing ) {
					$skipped_count++;
					continue;
				}

				// Remove existing UTM parameters if rewriting
				if ( $rewrite_existing ) {
					foreach ( $utm_params as $param ) {
						unset( $existing_params[$param] );
					}
				}

				// Add new UTM parameters
				if ( ! empty( $utm_source ) ) {
					$existing_params['utm_source'] = $utm_source;
				}
				if ( ! empty( $utm_medium ) ) {
					$existing_params['utm_medium'] = $utm_medium;
				}
				if ( ! empty( $utm_campaign ) ) {
					$existing_params['utm_campaign'] = $utm_campaign;
				}
				if ( ! empty( $utm_term ) ) {
					$existing_params['utm_term'] = $utm_term;
				}
				if ( ! empty( $utm_content ) ) {
					$existing_params['utm_content'] = $utm_content;
				}
			}

			// Rebuild the URL
			$new_query = http_build_query( $existing_params );
			$new_url = $parsed_url['scheme'] . '://' . $parsed_url['host'];
			
			if ( isset( $parsed_url['port'] ) ) {
				$new_url .= ':' . $parsed_url['port'];
			}
			
			if ( isset( $parsed_url['path'] ) ) {
				$new_url .= $parsed_url['path'];
			}
			
			if ( ! empty( $new_query ) ) {
				$new_url .= '?' . $new_query;
			}
			
			if ( isset( $parsed_url['fragment'] ) ) {
				$new_url .= '#' . $parsed_url['fragment'];
			}

			// Update the link in database
			$result = $wpdb->update(
				$wpdb->prefix . 'betterlinks',
				array( 'target_url' => $new_url ),
				array( 'ID' => $link['ID'] ),
				array( '%s' ),
				array( '%d' )
			);

			if ( $result !== false ) {
				$updated_count++;
			}
		}

		$message = $reset_existing
			? sprintf(
				/* translators: 1: number of links updated, 2: number skipped, 3: total links processed. */
				__( 'UTM parameters reset successfully. Updated: %1$d, Skipped: %2$d, Total: %3$d', 'betterlinks-pro' ),
				$updated_count,
				$skipped_count,
				count( $links )
			)
			: sprintf(
				/* translators: 1: number of links updated, 2: number skipped, 3: total links processed. */
				__( 'UTM template applied successfully. Updated: %1$d, Skipped: %2$d, Total: %3$d', 'betterlinks-pro' ),
				$updated_count,
				$skipped_count,
				count( $links )
			);

		// Clear cache again after all updates to ensure fresh data
		delete_transient( BETTERLINKS_CACHE_LINKS_NAME );

		// Track UTM Builder usage
		if ( $updated_count > 0 ) {
			update_option( 'betterlinks_utm_builder_used', true );
		}

		// Regenerate JSON file cache if it exists
		if ( defined( 'BETTERLINKS_EXISTS_LINKS_JSON' ) && BETTERLINKS_EXISTS_LINKS_JSON ) {
			if ( class_exists( '\\BetterLinks\\Cron' ) ) {
				( new \BetterLinks\Cron() )->write_json_links();
			}
		}

		wp_send_json_success( array(
			'updated_count' => $updated_count,
			'skipped_count' => $skipped_count,
			'total_links' => count( $links ),
			'message' => $message
		) );
	}

	/**
	 * Get UTM status counts for specified categories
	 */
	public function get_utm_status_counts() {
		check_ajax_referer( 'betterlinks_admin_nonce', 'security' );

		if ( ! apply_filters( 'betterlinks/api/links_get_items_permissions_check', current_user_can( 'manage_options' ) ) ) {
			wp_send_json_error( __( 'You do not have permission to perform this action.', 'betterlinks-pro' ) );
		}

		// JSON content validated by json_decode + intval below; sanitize_text_field would corrupt JSON.
		// phpcs:disable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$category_ids = isset( $_POST['category_ids'] ) ? json_decode( wp_unslash( $_POST['category_ids'] ), true ) : array();
		// phpcs:enable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

		// Convert to integers if needed
		if ( is_array( $category_ids ) ) {
			$category_ids = array_map( 'intval', $category_ids );
		}

		if ( empty( $category_ids ) ) {
			wp_send_json_error( __( 'No categories specified.', 'betterlinks-pro' ) );
		}

		global $wpdb;

		// Get links for the specified categories.
		// $placeholders is built locally as '%d,%d,...' from $category_ids (int[]); table prefix is wpdb-controlled.
		// phpcs:disable WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$placeholders = implode( ',', array_fill( 0, count( $category_ids ), '%d' ) );
		$query = $wpdb->prepare(
			"SELECT DISTINCT l.ID, l.target_url
			FROM {$wpdb->prefix}betterlinks l
			INNER JOIN {$wpdb->prefix}betterlinks_terms_relationships tr ON l.ID = tr.link_id
			WHERE tr.term_id IN ($placeholders)",
			...$category_ids
		);
		// phpcs:enable WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare,WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		$links = $wpdb->get_results( $query, ARRAY_A );

		$total_links = count( $links );
		$links_with_utm = 0;
		$links_without_utm = 0;

		foreach ( $links as $link ) {
			$target_url = $link['target_url'];
			$parsed_url = wp_parse_url( $target_url );
			
			// Check if URL already has UTM parameters
			$existing_query = isset( $parsed_url['query'] ) ? $parsed_url['query'] : '';
			parse_str( $existing_query, $existing_params );
			
			$has_utm = false;
			$utm_params = array( 'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content' );
			foreach ( $utm_params as $param ) {
				if ( isset( $existing_params[$param] ) && !empty( $existing_params[$param] ) ) {
					$has_utm = true;
					break;
				}
			}

			if ( $has_utm ) {
				$links_with_utm++;
			} else {
				$links_without_utm++;
			}
		}

		wp_send_json_success( array(
			'total_links' => $total_links,
			'links_with_utm' => $links_with_utm,
			'links_without_utm' => $links_without_utm
		) );
	}
}
