<?php
namespace BetterLinksPro;
if ( ! defined( 'ABSPATH' ) ) { exit; }

use BetterLinks\Admin\Cache;
use BetterLinksPro\Traits\DBTables;
class Migration {
	use DBTables;

	public static function init() {
		global $wpdb;
		// update plugin version
		if ( get_option( 'betterlinks_pro_version' ) !== BETTERLINKS_PRO_VERSION ) {
			if ( class_exists( '\BetterLinks\Helper' ) ) {
				\BetterLinks\Helper::create_cron_jobs_for_json_links();
			}

			if ( version_compare( BETTERLINKS_PRO_VERSION, '1.7.0', '>' ) ) {
				( new self() )->modifyBetterLinksClicksTable();
			}

			if ( version_compare( BETTERLINKS_PRO_VERSION, '1.8.0', '>=' ) ) {
				( new self() )->createBetterLinkCustomizeMetaTagsTable();
			}

			// AI Link Assistant suggestion telemetry table was removed in favour of a
			// client-side cache; drop it on upgrade if it exists.
			if ( version_compare( BETTERLINKS_PRO_VERSION, '2.8.1', '>=' ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.SchemaChange
				$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}betterlinks_genius_suggestions" );
			}

			if ( version_compare( BETTERLINKS_PRO_VERSION, '2.1.0', '>=' ) ) {
				$betterlinkspro_ga = get_option( BETTERLINKS_PRO_EXTERNAL_ANALYTICS_OPTION_NAME, [] );
				if ( is_string( $betterlinkspro_ga ) ) {
					$betterlinkspro_ga = json_decode( $betterlinkspro_ga, true );
				}
				if( !is_array( $betterlinkspro_ga ) ) {
					$betterlinkspro_ga = [];
				}
				if ( empty( $betterlinkspro_ga['parameter_tracking'] ) ) {
					$betterlinkspro_ga['parameter_tracking'] = [];
					$betterlinkspro_ga['parameter_tracking'] = array(
						'pf'         => 1,
						'target_url' => 0,
						'utm'        => 0,
					);
					update_option( BETTERLINKS_PRO_EXTERNAL_ANALYTICS_OPTION_NAME, $betterlinkspro_ga );
				}

				if( version_compare( BETTERLINKS_PRO_VERSION, '2.1.2', '>=' ) ){
					delete_transient('betterlinks_pro_software__license_data');
				}
			}
			/**
			 * License Migration
			 */
			self::license_migration();

			update_option( 'betterlinks_pro_version', BETTERLINKS_PRO_VERSION );
		}
		// Product Display feature tables — create/upgrade on existing installs,
		// independent of the plugin version bump (dbDelta is idempotent). The stored
		// value is a schema revision:
		//   1 = displays table, 2 = + groups table,
		//   3 = + regular_price/sale_price/style columns on the displays table,
		//   4 = self-heal those columns via explicit ALTER (dbDelta can't add them
		//       reliably to a table that has FOREIGN KEY constraints).
		//   5 = + product_source/wc_product_id columns (WooCommerce integration).
		//   6 = drop the FOREIGN KEY constraints (see dropProductDisplayForeignKeys).
		$pd_db_version = (int) get_option( 'betterlinks_pro_product_display_db', 0 );
		if ( $pd_db_version < 6 ) {
			$migration = new self();
			$migration->createProductDisplayTable();
			$migration->createProductGroupsTable();
			$migration->ensureProductDisplayColumns();
			$migration->dropProductDisplayForeignKeys();
			update_option( 'betterlinks_pro_product_display_db', '6' );
		}
		// The customized meta tags table is otherwise only created on activation and
		// behind the version bump above, so an install where the CREATE TABLE failed
		// - it carried an invalid `TEXT default ''` that MySQL 8 rejects under
		// STRICT_TRANS_TABLES - never recovers, and every fetch_meta_tags request
		// raises "table doesn't exist". Retry until the table is really there.
		$meta_tags_table = $wpdb->prefix . 'betterlinks_meta_tags';
		if ( ! get_option( 'betterlinks_pro_meta_tags_db', 0 ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$meta_tags_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $meta_tags_table ) ) === $meta_tags_table;
			if ( ! $meta_tags_exists ) {
				( new self() )->createBetterLinkCustomizeMetaTagsTable();
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
				$meta_tags_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $meta_tags_table ) ) === $meta_tags_table;
			}
			if ( $meta_tags_exists ) {
				update_option( 'betterlinks_pro_meta_tags_db', '1' );
			}
		}
		// "Link in Bio" feature table + protected category, created idempotently on
		// existing installs independent of the plugin version bump.
		$bio_db_version = (int) get_option( 'betterlinks_pro_bio_db', 0 );
		if ( $bio_db_version < 1 ) {
			( new self() )->createBioPagesTable();
			if ( class_exists( '\BetterLinksPro\Frontend\LinkInBio\Manager' ) ) {
				\BetterLinksPro\Frontend\LinkInBio\Manager::maybe_seed_category();
			}
			update_option( 'betterlinks_pro_bio_db', '1' );
		}
		if ( ! get_option( BETTERLINKS_PRO_EXTERNAL_ANALYTICS_OPTION_NAME ) ) {
			add_option(
				BETTERLINKS_PRO_EXTERNAL_ANALYTICS_OPTION_NAME,
				array(
					'is_enable_ga'       => false,
					'ga_tracking_code'   => '',
					'parameter_tracking' => array(
						'pf'         => 1,
						'target_url' => 0,
						'utm'        => 0,
					),
				)
			);
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query( "DELETE FROM {$wpdb->prefix}options WHERE option_name IN( 'betterlinks_autolink_options' )" );
	}

	private static function license_migration() {
		$license_key = get_option( BETTERLINKS_PRO_PLUGIN_SLUG . '-license-key', false );

		if ( $license_key !== false ) {
			$license_status = get_option( BETTERLINKS_PRO_PLUGIN_SLUG . '-license-status' );
			$license_data   = get_transient( BETTERLINKS_PRO_PLUGIN_SLUG . '-license_data' );

			update_option( BETTERLINKS_PRO_SL_DB_PREFIX . '_license', $license_key, 'no' );
			update_option( BETTERLINKS_PRO_SL_DB_PREFIX . '_license_status', $license_status, 'no' );
			set_transient( BETTERLINKS_PRO_SL_DB_PREFIX . '_license_data', $license_data, MONTH_IN_SECONDS * 3 );
		}
	}
}
