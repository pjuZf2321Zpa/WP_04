<?php
namespace BetterLinksPro;
if ( ! defined( 'ABSPATH' ) ) { exit; }

use WP_Http;

class Link {
	private static $link_options;

	public static function init() {
		$self = new self();
		add_filter( 'betterlinks/link/get_link_by_slug', array( $self, 'get_link_by_slug' ) );
		add_action( 'betterlinks/pre_before_redirect', array( $self, 'pre_before_redirect' ) );
		add_action( 'betterlinks/before_redirect', array( $self, 'before_redirect' ) );
		add_filter( 'betterlinks/link/before_dispatch_redirect', array( $self, 'before_dispatch_redirect' ) );
		add_filter( 'betterlinks/link/target_url', array( $self, 'target_url' ) );
		add_filter( 'betterlinks/is_password_protected_redirect_compatible', '__return_true' );
		add_filter( 'betterlinks/site_url', array( $self, 'modify_site_url' ) );

		add_filter( 'betterlinks_before_cle', array( $self, 'before_cle' ), 10, 2 ); // before Create Link Externally
		// analytic
		add_action( 'betterlinks/link/before_start_tracking', array( $self, 'before_start_tracking' ) );
		add_action( 'betterlinks/link/after_insert_click', array( $self, 'after_insert_click' ), 10, 3 );
		add_filter( 'betterlinks/link/insert_click_arg', array( $self, 'rotation_target_url_set' ), 10, 2 );
		// cloaked link redirect
		add_action( 'betterlinks/make_cloaked_redirect', array( $self, 'make_cloaked_redirect' ), 10, 2 );
		add_action( 'btl_header_redirect', array( $self, 'btl_header_redirect' ), 10, 2 );
		// Open in App interstitial, served from free's dispatch point (#65).
		Link\OpenInApp::init();

		// fetching betterlinks settings
		$settings = get_option( 'betterlinks_links', true );
		if ( is_string( $settings ) ) {
			$settings = json_decode( $settings, true );
		}
		$self::$link_options = $settings;
	}
	
	public function modify_site_url() {
		$settings = get_option( BETTERLINKS_LINKS_OPTION_NAME, '[]' );
		if ( is_string( $settings ) ) {
			$settings = json_decode( $settings, true );
		}

		if( empty( $settings['custom_domain']['enable_shortlink_custom_domain'] ) ){
			return site_url();
		}
		
		return wp_unslash( $settings['custom_domain']['shortlink_custom_domain'] );
	}

	public function before_cle( $initial_values, $settings ) {
		if ( empty( $settings['cle']['advanced_options'] ) ) {
			return $initial_values;
		}

		$cle_options = $settings['cle'];
		$advanced_cle_values = array(
			'cat_id'           => ! empty( $cle_options['category'] ) ? sanitize_text_field( $cle_options['category'] ) : 1,
			'redirect_type'    => ! empty( $cle_options['redirect_type'] ) ? sanitize_text_field( $cle_options['redirect_type'] ) : '307',
			'nofollow'         => ! empty( $cle_options['no_follow'] ) ? sanitize_text_field( $cle_options['no_follow'] ) : '',
			'sponsored'        => ! empty( $cle_options['sponsored'] ) ? sanitize_text_field( $cle_options['sponsored'] ) : '',
			'param_forwarding' => ! empty( $cle_options['param_forwarding'] ) ? sanitize_text_field( $cle_options['param_forwarding'] ) : '',
			'track_me'         => ! empty( $cle_options['track_me'] ) ? sanitize_text_field( $cle_options['track_me'] ) : '',
			'social_share'     => ! empty( $cle_options['social_share'] ) ? sanitize_text_field( $cle_options['social_share'] ) : '',
			'pro_enabled'      => true,
		);
		return wp_parse_args( $advanced_cle_values, $initial_values );
	}

	public function btl_header_redirect( $id ) {
		$betterlinkspro_options   = get_option( BETTERLINKS_PRO_EXTERNAL_ANALYTICS_OPTION_NAME );
		$is_enable_custom_scripts = isset( $betterlinkspro_options['is_enable_custom_scripts'] ) ? $betterlinkspro_options['is_enable_custom_scripts'] : false;
		$global_head_scripts      = isset( $betterlinkspro_options['global_head_scripts'] ) ? $betterlinkspro_options['global_head_scripts'] : '';
		$global_head_scripts      = preg_replace( '/\\\\/', '', $global_head_scripts );

		if ( ! empty( $is_enable_custom_scripts ) && ! empty( $global_head_scripts ) ) {
			// Admin-configured tracking script (e.g. GTM, FB pixel); raw HTML/JS by design.
			// Stamped with this request's CSP nonce so it still runs under the
			// cloak page's Content-Security-Policy.
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo self::add_csp_nonce_to_scripts( stripslashes( $global_head_scripts ) );
		}

		$custom_tracking_scripts = \BetterLinks\Helper::get_link_meta( $id, 'btl_custom_tracking_scripts' );
		if ( empty( $custom_tracking_scripts ) ) {
			return;
		}

		$custom_tracking_scripts = unserialize( $custom_tracking_scripts, array( 'allowed_classes' => false ) );
		$tracking_script         = isset( $custom_tracking_scripts['script'] ) ? stripslashes( $custom_tracking_scripts['script'] ) : false;
		if ( $tracking_script ) {
			// Admin-configured per-link tracking script; raw HTML/JS by design.
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo self::add_csp_nonce_to_scripts( $tracking_script );
		}
	}

	/**
	 * Stamp the current CSP nonce onto every top-level <script> tag in an
	 * admin-authored tracking payload.
	 *
	 * Only tags that are literally present in the stored payload get the nonce —
	 * anything injected later by an XSS payload that slipped past the
	 * `unfiltered_html` write gate will not have it and is blocked by the policy.
	 *
	 * @param string $markup Raw tracking markup.
	 * @return string
	 */
	private static function add_csp_nonce_to_scripts( $markup ) {
		if ( ! is_string( $markup ) || '' === $markup ) {
			return $markup;
		}

		if ( ! apply_filters( 'betterlinks/cloaked/csp_enabled', true ) ) {
			return $markup;
		}

		$nonce = self::get_csp_nonce();

		return preg_replace_callback(
			'/<script\b(?![^>]*\bnonce=)([^>]*)>/i',
			function ( $matches ) use ( $nonce ) {
				return '<script nonce="' . esc_attr( $nonce ) . '"' . $matches[1] . '>';
			},
			$markup
		);
	}

	public function get_link_by_slug( $link ) {
		if ( isset( $link['expire'] ) && Helper::is_json( $link['expire'] ) ) {
			$link['expire'] = json_decode( $link['expire'], true );
		}
		if ( isset( $link['dynamic_redirect'] ) && Helper::is_json( $link['dynamic_redirect'] ) ) {
			$link['dynamic_redirect'] = json_decode( $link['dynamic_redirect'], true );
		}
		return $link;
	}
	public function before_redirect( $data ) {
		if ( isset( $data['expire'] ) && ! is_array( $data['expire'] ) ) {
			$data['expire'] = json_decode( $data['expire'], true );
		}
		if ( 'publish' === $data['link_status'] && isset( $data['expire']['status'] ) && true === (bool)$data['expire']['status'] ) {
			wp_schedule_single_event( time(), 'betterlinkspro/expire_link_status_handler', array( $data ) );
			(new WP_Http)->request(site_url('wp-cron.php'));
		}
		// Set up visitor id for tracking
		$visitor_cookie = 'betterlinks_visitor';
		if ( ! isset( $_COOKIE[ $visitor_cookie ] ) ) {
			$visitor_cookie_expire_time = time() + 60 * 60 * 24 * 365; // 1 year
			$visitor_uid                = uniqid( 'bl' );
			setcookie( $visitor_cookie, $visitor_uid, $visitor_cookie_expire_time, '/' );
		}
		$this->start_external_analytics_cron_job( $data );

		// 👇 checking link is protected or not.
		$data['is_protected'] = false;
		if ( class_exists( '\BetterLinksPro\Helper' ) ) {
			// Fetching password credentials, if available.
			if ( ! empty( self::$link_options['enable_password_protection'] ) && empty( $data['skip_password_protection'] ) ) {
				$password = Helper::get_password_by_link_id( $data['ID'] );
				if ( count( $password ) > 0 ) {
					// $data['is_protected'] = '1' === $password[0]->status;
					if( '1' === $password[0]->status ) {
						// Get the dynamic form key from settings
						$password_protection_status = self::get_password_protection_status();
						$form_key = isset( $password_protection_status['form_key'] ) ? sanitize_text_field( $password_protection_status['form_key'] ) : 'password-protected-form';
						$form_key = empty( $form_key ) ? 'password-protected-form' : $form_key;
						
						$form_link = get_permalink( get_page_by_path( $form_key ) );
						wp_safe_redirect( esc_url_raw( $form_link . '?short_url=' . esc_attr( $data['short_url'] ) ) );
						exit();
					}
				}
			}

			// Redirect bots to the Customized Meta Tag template, if enabled. Runs after the
			// password check so a spoofed crawler user agent cannot bypass protection.
			if ( ! empty( self::$link_options['enable_customize_meta_tags'] ) ) {
				$enable_meta = Helper::check_meta_tag_enable_by_link_id( $data['ID'] );
				if ( $enable_meta && $data['is_bot'] ) {
					wp_safe_redirect( esc_url_raw( site_url() . '/customized-meta-tags/?short_url=' . esc_attr( $data['short_url'] ) ) );
					exit();
				}
			}

		}
	}

	public function start_external_analytics_cron_job( $data ) {
		$ga_tracking_code   = false;
		$ga4_api_secret     = false;
		$pixel_id           = false;
		$pixel_access_token = false;

		// Capture GA cookies + a per-click event_id at request time. The two
		// scheduled events fire in a later cron tick where $_COOKIE is gone, so
		// the session data has to be snapshotted here and passed through.
		// Issue #2 / Issue #3 from BetterLinks_GA4_FB_BugReport.
		$ga_session_data = self::capture_ga_session_data();
		$visitor         = $ga_session_data['_ga_raw'];

		// Credentials come from Pro's own option, never from the public links.json file.
		$analytic_options = Helper::get_external_analytics_settings();
		if ( ! empty( $analytic_options['is_enable_ga'] ) && ! empty( $analytic_options['ga_tracking_code'] ) ) {
			$ga_tracking_code = $analytic_options['ga_tracking_code'];
		}
		if ( ! empty( $analytic_options['is_enable_ga'] ) && ! empty( $analytic_options['is_ga4'] ) && ! empty( $analytic_options['ga4_api_secret'] ) ) {
			$ga4_api_secret = $analytic_options['ga4_api_secret'];
		}
		if ( ! empty( $analytic_options['is_enable_pixel'] ) && ! empty( $analytic_options['pixel_id'] ) && ! empty( $analytic_options['pixel_access_token'] ) ) {
			$pixel_id           = $analytic_options['pixel_id'];
			$pixel_access_token = $analytic_options['pixel_access_token'];
		}

		if ( $ga_tracking_code ) {
			$request_uri = !empty( $data['location'] ) ? esc_url_raw( $data['location'] ) : '';
			if( empty( $request_uri ) ){
				$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
			}
			wp_schedule_single_event( time(), 'betterlinkspro/send_google_analytics_data', array( $data, $request_uri, $ga_tracking_code, $ga4_api_secret, $visitor, $ga_session_data ) );
		}

		if ( $pixel_id && $pixel_access_token ) {
			// Pass only what PixelAnalytics reads. The full $_SERVER array carries
			// cookies (including auth cookies) and host environment values, and
			// cron arguments are stored in the autoloaded `cron` option.
			$server_snapshot = array(
				'REQUEST_TIME'    => isset( $_SERVER['REQUEST_TIME'] ) ? (int) $_SERVER['REQUEST_TIME'] : time(),
				'REMOTE_ADDR'     => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '',
				'HTTP_USER_AGENT' => isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '',
			);
			wp_schedule_single_event( time(), 'betterlinkspro/send_pixel_analytics_data', array( $data, $server_snapshot, $pixel_id, $pixel_access_token, $ga_session_data ) );
		}
	}

	public function pre_before_redirect( $data ) {
		if ( isset( $data['link_status'] ) && ( 'draft' === $data['link_status'] || 'scheduled' === $data['link_status'] ) ) {
			return false;
		}
		return true;
	}
	public function before_dispatch_redirect( $data ) {
		if ( isset( $data['expire'] ) && ! is_array( $data['expire'] ) ) {
			$data['expire'] = json_decode( $data['expire'], true );
		}
		if ( 'expired' === $data['link_status'] ) {
			if ( isset( $data['expire'] ) && filter_var( $data['expire']['status'], FILTER_VALIDATE_BOOLEAN ) == true && isset( $data['expire']['redirect_status'] ) && filter_var( $data['expire']['redirect_status'], FILTER_VALIDATE_BOOLEAN ) == true ) {
				$data['target_url'] = $data['expire']['redirect_url'];
				return $data;
			}
			return;
		}
		// dynamic redirect
		if ( isset( $data['dynamic_redirect'] ) && ! empty( $data['dynamic_redirect'] ) ) {
			if ( $data['dynamic_redirect']['type'] == 'rotation' ) {
				if ( is_array( $data['dynamic_redirect']['value'] ) ) {
					$index = ( $data['dynamic_redirect']['extra']['rotation_mode'] == 'random' ? wp_rand( 0, count( $data['dynamic_redirect']['value'] ) - 1 ) : (int) $this->random_weight_index( $data['dynamic_redirect']['value'] ) );
					if ( isset( $data['dynamic_redirect']['value'][ $index ]['link'] ) ) {
						$data['target_url'] = $data['dynamic_redirect']['value'][ $index ]['link'];
					}
				}
			} elseif ( $data['dynamic_redirect']['type'] == 'geographic' ) {
				$country_code = Helper::get_country_code();
				if ( is_array( $data['dynamic_redirect']['value'] ) ) {
					foreach ( $data['dynamic_redirect']['value'] as $item ) {
						if ( isset( $item['country'] ) && is_array( $item['country'] ) && in_array( $country_code, $item['country'] ) ) {
							$data['target_url'] = $item['link'];
							break;
						}
					}
				}
			} elseif ( $data['dynamic_redirect']['type'] == 'technology' ) {
				$client_info = Helper::get_client_info();
				if ( is_array( $client_info ) && is_array( $data['dynamic_redirect']['value'] ) ) {
					foreach ( $data['dynamic_redirect']['value'] as $item ) {
						if (
							( ! isset( $item['device'] ) || ( $item['device'] == 'any' || stripos( $client_info['device'], $item['device'] ) !== false ) ) &&
							( ! isset( $item['browser'] ) || ( $item['browser'] == 'any' || stripos( $client_info['browser'], $item['browser'] ) !== false ) ) &&
							( ! isset( $item['os'] ) || ( stripos( $client_info['os'], $item['os'] ) !== false ) )
						) {
							$data['target_url'] = $item['link'];
							break;
						}
					}
				}
			} elseif ( $data['dynamic_redirect']['type'] == 'time' ) {
				if ( is_array( $data['dynamic_redirect']['value'] ) ) {
					$local_time = current_datetime();
					$now        = $local_time->getTimestamp() + $local_time->getOffset();
					$offset     = (float) get_option( 'gmt_offset' );
					foreach ( $data['dynamic_redirect']['value'] as $item ) {
						if ( isset( $item['start_date'] ) && isset( $item['end_date'] ) ) {
							if ( Helper::check_in_range( $item['start_date'] . ' ' . $offset . ' hours', $item['end_date'] . ' ' . $offset . ' hours', $now ) ) {
								$data['target_url'] = $item['link'];
								break;
							}
						}
					}
				}
			}
		}
		return $data;
	}

	public function random_weight_index( $data ) {
		$r      = wp_rand( 1, 1000 );
		$offset = 0;
		foreach ( $data as $k => $item ) {
			$offset += $item['weight'] * 10;
			if ( $r <= $offset ) {
				return $k;
			}
		}
	}

	public function after_insert_click( $link_id, $click_id, $target_url ) {
		$link = current( \BetterLinks\Helper::get_link_by_ID( $link_id ) );
		if ( isset( $link['dynamic_redirect'] ) && Helper::is_json( $link['dynamic_redirect'] ) ) {
			$dynamic_redirect = (array) json_decode( $link['dynamic_redirect'], true );
			if ( isset( $dynamic_redirect['type'] ) &&
				$dynamic_redirect['type'] == 'rotation' &&
				isset( $dynamic_redirect['extra']['split_test'] ) &&
				filter_var( $dynamic_redirect['extra']['split_test'], FILTER_VALIDATE_BOOLEAN ) == true
			) {
				Helper::insert_click_rotation(
					array(
						'link_id'    => $link_id,
						'click_id'   => $click_id,
						'target_url' => $target_url,
					)
				);
			}
		}
	}

	public function before_start_tracking( $data ) {
		if ( isset( $data['dynamic_redirect'] ) ) {
			if ( Helper::is_json( $data['dynamic_redirect'] ) ) {
				$dynamic_redirect = json_decode( $data['dynamic_redirect'], true );
			} else {
				$dynamic_redirect = $data['dynamic_redirect'];
			}
			if ( isset( $dynamic_redirect['type'] ) && $dynamic_redirect['type'] == 'rotation' && $dynamic_redirect['extra']['split_test'] == true ) {
				if ( isset( $dynamic_redirect['extra']['goal_link'] ) ) {
					// Set Cookie if it doesn't exist
					$cookie_name = 'betterlinks_pro_goal_link_' . $dynamic_redirect['extra']['goal_link'];
					// Used for unique click tracking
					$cookie_expire_time = time() + 60 * 60 * 24 * 7; // Expire in 7 days
					if ( ! isset( $_COOKIE[ $cookie_name ] ) ) {
						setcookie( $cookie_name, $data['target_url'], $cookie_expire_time, '/' );
					}
				}
			}
		}
	}

	public function rotation_target_url_set( $arg ) {
		$cookie_name = 'betterlinks_pro_goal_link_' . $arg['link_id'];
		if ( isset( $_COOKIE[ $cookie_name ] ) ) {
			$cookie_value = sanitize_text_field( wp_unslash( $_COOKIE[ $cookie_name ] ) );
			if ( setcookie( $cookie_name, 0, time() - 3600, '/' ) ) {
				$arg['rotation_target_url'] = $cookie_value;
			}
		}
		return $arg;
	}
	public static function target_url( $url ) {
		global $betterlinks;
		if ( isset( $betterlinks['force_https'] ) && $betterlinks['force_https'] ) {
			return preg_replace( '/^http:/i', 'https:', $url );
		}
		return $url;
	}
	/**
	 * Per-response CSP nonce for the cloak page.
	 *
	 * @var string|null
	 */
	private static $csp_nonce = null;

	/**
	 * Nonce for the current cloak-page render, generated once per request.
	 *
	 * @return string
	 */
	public static function get_csp_nonce() {
		if ( null === self::$csp_nonce ) {
			self::$csp_nonce = wp_generate_password( 24, false, false );
		}

		return self::$csp_nonce;
	}

	/**
	 * Send hardening headers for the cloak page.
	 *
	 * The cloak page is the one place BetterLinks echoes admin-authored raw
	 * HTML/JS (global + per-link tracking scripts) to anonymous visitors. Writing
	 * those scripts is gated on `unfiltered_html`, but this is the defense in
	 * depth for that gate: script execution is restricted to same-origin files,
	 * tags carrying this request's nonce, and an allowlist of analytics vendors.
	 *
	 * Filters:
	 *  - `betterlinks/cloaked/csp_enabled`    bool, set false to send nothing.
	 *  - `betterlinks/cloaked/csp_script_src` array of extra `script-src` sources.
	 *  - `betterlinks/cloaked/csp_policy`     string, replaces the whole policy.
	 *
	 * @return void
	 */
	private static function send_cloak_security_headers() {
		if ( headers_sent() || ! apply_filters( 'betterlinks/cloaked/csp_enabled', true ) ) {
			return;
		}

		// `https:` is deliberate. The realistic injected payload is an inline
		// <script> or an inline event handler, and both are blocked here because
		// the policy never grants 'unsafe-inline' — only tags carrying this
		// request's nonce run. Restricting external hosts to a vendor allowlist
		// instead would be stricter on paper but would silently break any
		// analytics vendor not on the list, and every legacy tracking snippet that
		// document.write()s its own loader (those injected tags inherit no nonce).
		// Tighten it per-site with the filter below.
		$script_src = array(
			"'self'",
			"'nonce-" . self::get_csp_nonce() . "'",
			'https:',
		);

		$script_src = (array) apply_filters( 'betterlinks/cloaked/csp_script_src', $script_src );
		$script_src = array_values( array_unique( array_filter( array_map( 'strval', $script_src ) ) ) );

		$policy = implode(
			'; ',
			array(
				// Everything except script execution stays permissive on purpose —
				// workers, media and manifests used by tracking vendors must keep
				// loading. Script execution is the only thing being restricted.
				"default-src 'self' https: data: blob:",
				"base-uri 'self'",
				"object-src 'none'",
				"form-action 'self'",
				'script-src ' . implode( ' ', $script_src ),
				"style-src 'self' https: 'unsafe-inline'",
				'img-src * data: blob:',
				'font-src * data:',
				'connect-src *',
				// The cloak page exists to iframe the destination, so frames stay open.
				'frame-src *',
			)
		);

		$policy = (string) apply_filters( 'betterlinks/cloaked/csp_policy', $policy, self::get_csp_nonce() );

		if ( '' !== trim( $policy ) ) {
			header( 'Content-Security-Policy: ' . $policy );
		}

		header( 'X-Content-Type-Options: nosniff' );
		header( 'Referrer-Policy: strict-origin-when-cross-origin' );
	}

	public static function make_cloaked_redirect( $target_url, $data ) {
		header( 'Content-Type: text/html' );
		self::send_cloak_security_headers();
		global $wpdb;
		$prefix    = $wpdb->prefix;
		// Table name interpolation via $wpdb->prefix is the recommended WP idiom; the user-supplied value is bound via prepare().
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$query     = $wpdb->prepare( "SELECT ID, link_title, link_note FROM {$prefix}betterlinks WHERE ID = %d", $data['ID'] );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
		$rows      = $wpdb->get_results( $query, ARRAY_A );
		$curr_item = is_array( $rows ) && ! empty( $rows ) ? current( $rows ) : null;
		// current( array() ) is false when the ID is no longer in the table, and
		// cloaked.php reads $curr_item['link_title'] / ['link_note'] / ['ID'] —
		// off a bool those are PHP 8 offset warnings feeding nulls into esc_html().
		// The caller exits straight after us, so returning early would serve a
		// blank page; fall back to the link row we were already handed.
		if ( ! is_array( $curr_item ) ) {
			$curr_item = array(
				'ID'         => isset( $data['ID'] ) ? $data['ID'] : 0,
				'link_title' => isset( $data['link_title'] ) ? $data['link_title'] : '',
				'link_note'  => isset( $data['link_note'] ) ? $data['link_note'] : '',
			);
		}
		require_once BETTERLINKS_PRO_ROOT_DIR_PATH . '/includes/cloaked.php';
	}

	public static function get_password_protection_status() {
		return ! empty( self::$link_options['password'] ) ? self::$link_options['password'] : null;
	}

	public static function setup_ga_cookie() {
		// Set up visitor id for tracking
		$visitor_cookie = '_ga';
		if ( ! isset( $_COOKIE[ $visitor_cookie ] ) ) {
			$visitor_cookie_expire_time = time() + 60 * 60 * 24 * 365; // 1 year
			// $visitor_uid                = uniqid( 'bl' );
			$visitor_uid = (new self())->gaCookieGeneration( site_url());
			setcookie( $visitor_cookie, $visitor_uid, $visitor_cookie_expire_time, '/' );
			return $visitor_uid;
		}
		return sanitize_text_field( wp_unslash( $_COOKIE[ $visitor_cookie ] ) );
	}

	/**
	 * Capture GA cookies + a fresh per-click event_id at request time so the
	 * deferred analytics cron handlers can stitch the event into the visitor's
	 * GA4 session (Issue #2) and customers can dedup browser-side Pixel against
	 * server-side CAPI (Issue #3 partial).
	 *
	 * Must be called from inside the redirect request — $_COOKIE is no longer
	 * available once `wp_schedule_single_event` fires the handler in a later tick.
	 *
	 * @since 2.7.0
	 * @return array{
	 *     client_id: string,
	 *     session_cookies: array<string,string>,
	 *     event_id: string,
	 *     _ga_raw: string
	 * }
	 */
	public static function capture_ga_session_data() {
		// Reuse setup_ga_cookie() so the _ga cookie is created on first hit.
		$ga_cookie_raw = self::setup_ga_cookie();

		// Snapshot every _ga_<MID> session cookie so the cron handler can pick
		// the one that matches its configured measurement_id once it's invoked.
		$session_cookies = array();
		if ( ! empty( $_COOKIE ) && is_array( $_COOKIE ) ) {
			foreach ( $_COOKIE as $name => $value ) {
				if ( is_string( $name ) && strpos( $name, '_ga_' ) === 0 ) {
					$session_cookies[ $name ] = sanitize_text_field( wp_unslash( $value ) );
				}
			}
		}

		// Per-click UUID forwarded to both GA4 (`params.event_id`) and Meta CAPI
		// (`event_id`). Customers running their own browser-side Pixel can read
		// this from a published JS hook (future work) and use it as the dedup key.
		// wp_generate_uuid4() has shipped with WP since 4.7.
		$event_id = wp_generate_uuid4();

		return array(
			'client_id'       => self::parse_client_id_from_ga_cookie( $ga_cookie_raw ),
			'session_cookies' => $session_cookies,
			'event_id'        => $event_id,
			'_ga_raw'         => $ga_cookie_raw,
		);
	}

	/**
	 * Pull GA4 client_id (`<random>.<timestamp>`) out of a raw _ga cookie value.
	 * Format: `GA<v>.<subdomains>.<random>.<timestamp>`.
	 *
	 * For values that don't match (e.g. server-generated fallbacks from
	 * gaCookieGeneration()'s uniqid path), return the value unchanged so we
	 * still send something stable per visitor.
	 */
	public static function parse_client_id_from_ga_cookie( $ga_cookie ) {
		if ( empty( $ga_cookie ) ) {
			return '';
		}
		$parts = explode( '.', $ga_cookie );
		if ( count( $parts ) >= 4 ) {
			return $parts[2] . '.' . $parts[3];
		}
		return $ga_cookie;
	}

	public function gaCookieGeneration($domain, $version = 1, $rootpath = '/') {
		// Count subdomains
		$subdomains = substr_count($domain, '.') + 1;
	
		// Count directories in root path
		$rootpathDirs = substr_count($rootpath, '/');
		$cookiePath = $rootpathDirs > 1 ? "-$rootpathDirs" : '';
	
		// Generate unique ID and timestamp
		$uniqueId = substr(str_replace('.', '', uniqid('', true)), 0, 9);
		$timeStamp = substr(time(), 0, 10);
	
		// Return GA cookie format
		return "GA{$version}.{$subdomains}{$cookiePath}.{$uniqueId}.{$timeStamp}";
	}

}
