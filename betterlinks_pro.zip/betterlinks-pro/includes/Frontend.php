<?php
namespace BetterLinksPro;
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Frontend {


	/**
	 * Initializes the frontend
	 */
	public static function init() {
		$self = new self();
		$self->load_autolink_by_keywords();
	}

	/**
	 * Loaded AutoLinks and affiliate disclosure
	 */
	public function load_autolink_by_keywords() {
		Frontend\AutoLinks::init();
		Frontend\AffiliateDisclosure::init();
	}
}
