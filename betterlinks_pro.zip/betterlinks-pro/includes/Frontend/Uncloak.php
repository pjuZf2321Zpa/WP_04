<?php
namespace BetterLinksPro\Frontend;
if ( ! defined( 'ABSPATH' ) ) { exit; }

use BetterLinksPro\Compat;

/**
 * Uncloaked links: BetterLinks-linked text in post content points straight at
 * the target URL instead of the short URL. Uses the link's existing `uncloaked`
 * flag through the free plugin's betterlinks/frontend/linked_text_href filter.
 */
class Uncloak {

	public static function init() {
		if ( ! Compat::free_has_extension_api() ) {
			return; // Older free plugins swap the href themselves.
		}
		add_filter( 'betterlinks/frontend/linked_text_href', array( new self(), 'linked_text_href' ), 10, 2 );
	}

	/**
	 * @param string $href Short URL.
	 * @param array  $link Link row.
	 * @return string
	 */
	public function linked_text_href( $href, $link ) {
		if ( is_array( $link ) && ! empty( $link['uncloaked'] ) && ! empty( $link['target_url'] ) ) {
			return $link['target_url'];
		}
		return $href;
	}
}
