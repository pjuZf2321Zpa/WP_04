<?php

namespace BetterLinksPro\Frontend;
if ( ! defined( 'ABSPATH' ) ) { exit; }

use BetterLinks\Admin\Cache;

/**
 * Summery
 * Affiliate Disclosure adds an disclosure message to the post and pages frontends.
 */
class AffiliateDisclosure {
	/**
	 * Description
	 *
	 * @var Array - contains BetterLinks settings
	 */
	private $link_options;

	/**
	 * @var bool Whether the [btl_affiliate_link_disclosure] shortcode was found in the current post.
	 */
	private $shortcode_found = false;

	/**
	 * @var bool|null Shortcode 'top' attribute. null = not specified (use global), true/false = explicit.
	 */
	private $shortcode_top = null;

	/**
	 * @var bool|null Shortcode 'bottom' attribute. null = not specified (use global), true/false = explicit.
	 */
	private $shortcode_bottom = null;

	/**
	 * @var bool Flag to skip global WPML translation when per-post text is already translated.
	 */
	private static $skip_global_wpml_translate = false;

	/**
	 * Description
	 *
	 * Initializes the AffiliateDisclosure
	 */
	public static function init() {
		$self = new self();
		// $self->link_options = defined( 'BETTERLINKS_LINKS_OPTION_NAME' ) ? json_decode( get_option( BETTERLINKS_LINKS_OPTION_NAME ), true ) : array();
		$self->link_options = Cache::get_json_settings();
		
		// Ensure link_options is an array (fix for PHP 8+ scalar value error)
		if ( ! is_array( $self->link_options ) ) {
			$self->link_options = array();
		}
		
		// Register affiliate disclosure text with WPML String Translation.
		$self->register_wpml_strings();

		// Translate disclosure text via WPML on the frontend.
		add_filter( 'betterlinks_affiliate_disclosure_text', array( __CLASS__, 'wpml_translate_disclosure' ) );

		add_filter( 'the_content', array( $self, 'add_affiliate_disclosure' ), 100 );
		add_filter( 'get_the_excerpt', array( $self, 'add_affiliate_disclosure' ), 100 );
		add_action( 'wp_enqueue_scripts', array( $self, 'add_styles' ) );
		// Register new shortcode with btl_ prefix
		add_shortcode( 'btl_affiliate_link_disclosure', array( $self, 'shortcode_callback' ) );
		// Register old shortcode for backward compatibility
		add_shortcode( 'affiliate_link_disclosure', array( $self, 'shortcode_callback' ) );
	}

	/**
	 * Description
	 *
	 * @return boolean - checks if the block editor enabled
	 */
	public function is_using_gutenberg_block() {
		$current_screen        = get_current_screen();
		$is_using_block_editor = $current_screen->is_block_editor || ( function_exists( 'is_gutenberg_page' ) && is_gutenberg_page() );
		return $is_using_block_editor;
	}

	/**
	 * Description
	 *
	 * @return void - adds css stylesheet related to affiliate disclosure
	 */
	public function add_styles() {
		$is_enabled_affiliate_disclosure = ! empty( $this->link_options['affiliate_link_disclosure'] ) ? $this->link_options['affiliate_link_disclosure'] : false;
		if ( defined( 'BETTERLINKS_ASSETS_URI' ) && $is_enabled_affiliate_disclosure ) {
			wp_enqueue_style( 'betterlinks-quil-editor', BETTERLINKS_ASSETS_URI . 'css/ql-editor.css', array(), BETTERLINKS_PRO_VERSION );
		}
	}
	/**
	 * Description - adds disclosure message to the content
	 *
	 * @param string $content - The content.
	 * @return string - the modified content
	 */
	public function add_affiliate_disclosure( $content ) {
		if ( is_attachment() || is_feed() ) {
			return $content;
		}

		$i_d      = get_the_ID();
		$settings = $this->link_options;

		$is_enabled_affiliate_disclosure = ! empty( $settings['affiliate_link_disclosure'] ) ? $settings['affiliate_link_disclosure'] : false;
		if ( ! $is_enabled_affiliate_disclosure ) {
			return $content;
		}

		$is_this_post_enabled = get_post_meta( $i_d, 'betterlinks_enable_affiliate_link_disclosure' );
		$default_enabled_post_types = ! empty( $settings['affiliate_link_disclosure_default_post_type'] ) ? $settings['affiliate_link_disclosure_default_post_type'] : '';
		$default_enabled_post_types = explode( '|', $default_enabled_post_types );

		$post_type             = get_post_type();
		$is_enabled_by_default = in_array( $post_type, $default_enabled_post_types );

		// Check if individual post has disclosure explicitly enabled
		$is_individually_enabled = is_array( $is_this_post_enabled ) && in_array( 'true', $is_this_post_enabled, true );

		// Check if "Enable Only for Auto Link Keywords" is enabled
		$only_with_autolink = ! empty( $settings['affiliate_disclosure_only_autolink'] ) ? $settings['affiliate_disclosure_only_autolink'] : false;
		
		// If "Enable Only for Auto Link Keywords" is checked AND post is NOT individually enabled,
		// verify content has auto link keywords
		if ( $only_with_autolink && ! $is_individually_enabled ) {
			// Check if content contains auto link keyword class
			if ( strpos( $content, 'class="btl_autolink_hyperlink"' ) === false ) {
				// No auto link keywords found, don't show disclosure
				return $content;
			}
		}

		$is_enabled_by_default = is_array( $is_this_post_enabled ) &&
			(
				in_array( 'true', $is_this_post_enabled, true )  ||
				( ! count( $is_this_post_enabled ) && $is_enabled_by_default )
			);

		if ( ! $is_enabled_by_default ) {
			return $content;
		}

		$affiliate_link_position   = ! empty( $settings['affiliate_link_position'] ) ? sanitize_text_field( $settings['affiliate_link_position'] ) : '';
		$affiliate_disclosure_text = ! empty( $settings['affiliate_disclosure_text'] ) ? wp_kses_post( $settings['affiliate_disclosure_text'] ) : '';
		// Apply translation to the disclosure text
		$affiliate_disclosure_text = apply_filters( 'betterlinks_affiliate_disclosure_text', $affiliate_disclosure_text );
		// Advanced options for affliate disclosure styles.
		$is_advance_option_enabled = ! empty( $settings['affiliate_advanced_options'] ) ? sanitize_text_field( $settings['affiliate_advanced_options'] ) : '0';

		$affiliate_disclosure_bg_color = ( ! empty( $is_advance_option_enabled ) && ! empty( $settings['affiliate_disclosure_bg_color'] ) ? \BetterLinksPro\Helper::sanitize_css_color( $settings['affiliate_disclosure_bg_color'] ) : '' );

		$affiliate_disclosure_css = sprintf( 'background-color: %1$s;', $affiliate_disclosure_bg_color );

		$want_border = ( ! empty( $settings['affiliate_disclosure_want_border'] ) ) ? filter_var( $settings['affiliate_disclosure_want_border'], FILTER_VALIDATE_BOOLEAN ) : false;
		
		// Handle individual border sizes with backward compatibility
		$border_size_unit = ( ! empty( $settings['affiliate_disclosure_border_size_unit'] ) ) ? sanitize_text_field( $settings['affiliate_disclosure_border_size_unit'] ) : 'px';
		$border_size_top = ( isset( $settings['affiliate_disclosure_border_size_top'] ) && $settings['affiliate_disclosure_border_size_top'] !== '' ) ? max( 0, intval( sanitize_text_field( $settings['affiliate_disclosure_border_size_top'] ) ) ) : '1';
		$border_size_right = ( isset( $settings['affiliate_disclosure_border_size_right'] ) && $settings['affiliate_disclosure_border_size_right'] !== '' ) ? max( 0, intval( sanitize_text_field( $settings['affiliate_disclosure_border_size_right'] ) ) ) : '1';
		$border_size_bottom = ( isset( $settings['affiliate_disclosure_border_size_bottom'] ) && $settings['affiliate_disclosure_border_size_bottom'] !== '' ) ? max( 0, intval( sanitize_text_field( $settings['affiliate_disclosure_border_size_bottom'] ) ) ) : '1';
		$border_size_left = ( isset( $settings['affiliate_disclosure_border_size_left'] ) && $settings['affiliate_disclosure_border_size_left'] !== '' ) ? max( 0, intval( sanitize_text_field( $settings['affiliate_disclosure_border_size_left'] ) ) ) : '1';
		
		// Backward compatibility: if old border_size exists and new ones don't, use old value
		$old_border_size = ( ! empty( $settings['affiliate_disclosure_border_size'] ) ) ? sanitize_text_field( $settings['affiliate_disclosure_border_size'] ) : '';
		if ( empty( $border_size_top ) && empty( $border_size_right ) && empty( $border_size_bottom ) && empty( $border_size_left ) && ! empty( $old_border_size ) ) {
			$border_size_top = $old_border_size;
			$border_size_right = $old_border_size;
			$border_size_bottom = $old_border_size;
			$border_size_left = $old_border_size;
		}

		$border_style = ( ! empty( $settings['affiliate_disclosure_border_style'] ) ) ? sanitize_text_field( $settings['affiliate_disclosure_border_style'] ) : 'solid';

		$border_color = ( ! empty( $settings['affiliate_disclosure_border_color'] ) ) ? sanitize_text_field( $settings['affiliate_disclosure_border_color'] ) : '';

		$font_unit = ( isset( $settings['affiliate_disclosure_font_unit'] ) ) ? sanitize_text_field( $settings['affiliate_disclosure_font_unit'] ) : 'px';
		$font_size = ( ! empty( $settings['affiliate_disclosure_font_size'] ) ) ? sprintf(
			'font-size: %1$s%2$s;',
			esc_attr( $settings['affiliate_disclosure_font_size'] ),
			esc_attr( $font_unit )
		) : '';

		$width_unit = ( isset( $settings['affiliate_disclosure_width_unit'] ) ) ? sanitize_text_field( $settings['affiliate_disclosure_width_unit'] ) : '%';
		$width      = ( ! empty( $settings['affiliate_disclosure_width'] ) ) ? sprintf(
			'width: %1$s%2$s;',
			esc_attr( $settings['affiliate_disclosure_width'] ),
			esc_attr( $width_unit )
		) : '';

		// PADDING.
		// LINE HEIGHT.
		$line_height_unit  = ( isset( $settings['affiliate_disclosure_line_height_unit'] ) && $settings['affiliate_disclosure_line_height_unit'] !== '' ) ? sanitize_text_field( $settings['affiliate_disclosure_line_height_unit'] ) : 'em';
		$line_height_value = ( isset( $settings['affiliate_disclosure_line_height'] ) && $settings['affiliate_disclosure_line_height'] !== '' ) ? max( 0, floatval( sanitize_text_field( $settings['affiliate_disclosure_line_height'] ) ) ) : '1';
		$line_height_css   = sprintf( 'line-height: %1$s%2$s;', esc_attr( $line_height_value ), esc_attr( $line_height_unit ) );

		$padding_unit   = ( ! empty( $settings['affiliate_disclosure_padding_unit'] ) ) ? sanitize_text_field( $settings['affiliate_disclosure_padding_unit'] ) : 'px';
		$padding_top    = ( isset( $settings['affiliate_disclosure_padding_top'] ) && $settings['affiliate_disclosure_padding_top'] !== '' ) ? sprintf( 'padding-top: %1$s%2$s;', esc_attr( max( 0, intval( $settings['affiliate_disclosure_padding_top'] ) ) ), esc_attr( $padding_unit ) ) : sprintf( 'padding-top: %1$s%2$s;', 5, esc_attr( $padding_unit ) );
		$padding_right  = ( isset( $settings['affiliate_disclosure_padding_right'] ) && $settings['affiliate_disclosure_padding_right'] !== '' ) ? sprintf( 'padding-right: %1$s%2$s;', esc_attr( max( 0, intval( $settings['affiliate_disclosure_padding_right'] ) ) ), esc_attr( $padding_unit ) ) : sprintf( 'padding-right: %1$s%2$s;', 5, esc_attr( $padding_unit ) );
		$padding_bottom = ( isset( $settings['affiliate_disclosure_padding_bottom'] ) && $settings['affiliate_disclosure_padding_bottom'] !== '' ) ? sprintf( 'padding-bottom: %1$s%2$s;', esc_attr( max( 0, intval( $settings['affiliate_disclosure_padding_bottom'] ) ) ), esc_attr( $padding_unit ) ) : sprintf( 'padding-bottom: %1$s%2$s;', 5, esc_attr( $padding_unit ) );
		$padding_left   = ( isset( $settings['affiliate_disclosure_padding_left'] ) && $settings['affiliate_disclosure_padding_left'] !== '' ) ? sprintf( 'padding-left: %1$s%2$s;', esc_attr( max( 0, intval( $settings['affiliate_disclosure_padding_left'] ) ) ), esc_attr( $padding_unit ) ) : sprintf( 'padding-left: %1$s%2$s;', 5, esc_attr( $padding_unit ) );
		//echo '$padding_top - '. $padding_top;
		// BORDER RADIUS.
		$radius_unit   = ! empty( $settings['affiliate_disclosure_border_radius_unit'] ) ? sanitize_text_field( $settings['affiliate_disclosure_border_radius_unit'] ) : 'px';
		$radius_top    = ( isset( $settings['affiliate_disclosure_border_radius_top'] ) && $settings['affiliate_disclosure_border_radius_top'] !== '' ) ? max( 0, intval( sanitize_text_field( $settings['affiliate_disclosure_border_radius_top'] ) ) ) : '5';
		$radius_right  = ( isset( $settings['affiliate_disclosure_border_radius_right'] ) && $settings['affiliate_disclosure_border_radius_right'] !== '' ) ? max( 0, intval( sanitize_text_field( $settings['affiliate_disclosure_border_radius_right'] ) ) ) : '5';
		$radius_bottom = ( isset( $settings['affiliate_disclosure_border_radius_bottom'] ) && $settings['affiliate_disclosure_border_radius_bottom'] !== '' ) ? max( 0, intval( sanitize_text_field( $settings['affiliate_disclosure_border_radius_bottom'] ) ) ) : '5';
		$radius_left   = ( isset( $settings['affiliate_disclosure_border_radius_left'] ) && $settings['affiliate_disclosure_border_radius_left'] !== '' ) ? max( 0, intval( sanitize_text_field( $settings['affiliate_disclosure_border_radius_left'] ) ) ) : '5';
		$radius_css    = sprintf(
			'border-radius: %1$s%5$s %2$s%5$s %3$s%5$s %4$s%5$s;',
			esc_attr( $radius_top ),
			esc_attr( $radius_right ),
			esc_attr( $radius_bottom ),
			esc_attr( $radius_left ),
			esc_attr( $radius_unit ),
		);

		$affiliate_border = '';
		if ( $is_advance_option_enabled && $want_border ) {
			// Build individual border properties
			$border_top = ( $border_size_top !== '' ) ? sprintf(
				'border-top: %1$s%2$s %3$s %4$s;',
				esc_attr( $border_size_top ),
				esc_attr( $border_size_unit ),
				esc_attr( $border_style ),
				esc_attr( $border_color )
			) : '';
			
			$border_right = ( $border_size_right !== '' ) ? sprintf(
				'border-right: %1$s%2$s %3$s %4$s;',
				esc_attr( $border_size_right ),
				esc_attr( $border_size_unit ),
				esc_attr( $border_style ),
				esc_attr( $border_color )
			) : '';
			
			$border_bottom = ( $border_size_bottom !== '' ) ? sprintf(
				'border-bottom: %1$s%2$s %3$s %4$s;',
				esc_attr( $border_size_bottom ),
				esc_attr( $border_size_unit ),
				esc_attr( $border_style ),
				esc_attr( $border_color )
			) : '';
			
			$border_left = ( $border_size_left !== '' ) ? sprintf(
				'border-left: %1$s%2$s %3$s %4$s;',
				esc_attr( $border_size_left ),
				esc_attr( $border_size_unit ),
				esc_attr( $border_style ),
				esc_attr( $border_color )
			) : '';
			
			$affiliate_border = $border_top . ' ' . $border_right . ' ' . $border_bottom . ' ' . $border_left . ' ' . $radius_css;
		}

		// Advanced options for affliate disclosure styles.
		$post_saved_disclosure_text = get_post_meta( $i_d, 'betterlinks_enable_affiliate_link_disclosure_text' );

		if ( is_array( $post_saved_disclosure_text ) && count( $post_saved_disclosure_text ) > 0 ) {
			$post_saved_disclosure_text = json_decode( $post_saved_disclosure_text[0], true );

			$affiliate_disclosure_text = isset( $post_saved_disclosure_text['affiliate_disclosure_text'] ) ? wp_kses_post( $post_saved_disclosure_text['affiliate_disclosure_text'] ) : '';

			// Register and translate per-post disclosure text via WPML.
			if ( ! empty( $affiliate_disclosure_text ) ) {
				$wpml_string_name = 'Affiliate Disclosure Text - Post ' . $i_d;
				// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
				do_action( 'wpml_register_single_string', 'BetterLinks', $wpml_string_name, $affiliate_disclosure_text );
				// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
				$affiliate_disclosure_text = apply_filters( 'wpml_translate_single_string', $affiliate_disclosure_text, 'BetterLinks', $wpml_string_name );
				// Prevent the global WPML translation from overriding per-post translation.
				self::$skip_global_wpml_translate = true;
			}

			$affiliate_disclosure_text = apply_filters( 'betterlinks_affiliate_disclosure_text', $affiliate_disclosure_text );
			$affiliate_link_position   = isset( $post_saved_disclosure_text['affiliate_link_position'] ) ? sanitize_text_field( $post_saved_disclosure_text['affiliate_link_position'] ) : '';
		}

		$affiliate_disclosure = sprintf(
			'<div class="ql-snow">
            <div class="betterlinks_affiliate_disclosure_post ql-editor">
                %1$s 
            </div>
            </div>
            <style>
                .betterlinks_affiliate_disclosure_post{
                    %10$s
                    white-space: unset;
                    %2$s
                    %3$s
                    %4$s
                    %5$s
                    %6$s
                    %7$s
                    %8$s
                    %9$s
                }
                .betterlinks_affiliate_disclosure_post p{
                    padding: 0;
                    margin: 0;
                    font-size: inherit;
                }

                .betterlinks_affiliate_disclosure_post .ql-align-center{
                    text-align: center;
                }
                .betterlinks_affiliate_disclosure_post .ql-align-right{
                    text-align: right;
                }
                .betterlinks_affiliate_disclosure_post .ql-align-left{
                    text-align: left;
                }
            </style>',
			str_replace( ' rn ', '', $affiliate_disclosure_text ),
			$affiliate_disclosure_css,
			$affiliate_border,
			$font_size,
			$width,
			$padding_top,
			$padding_right,
			$padding_bottom,
			$padding_left,
			$line_height_css,
		);

		// Strip shortcode placeholder from excerpts — disclosure should not render inline in excerpts.
		if ( doing_filter( 'get_the_excerpt' ) ) {
			$content = str_replace( '<!--btl_affiliate_disclosure_shortcode-->', '', $content );
		}

		// if (($is_enabled_affiliate_disclosure && is_array( $is_this_post_enabled ) && in_array( 'true', $is_this_post_enabled, true )) && $is_enabled_by_default ) {
		if ( $is_enabled_affiliate_disclosure && $is_enabled_by_default ) {
			if ( $this->shortcode_found ) {
				// Replace shortcode placeholder with disclosure HTML.
				$content = str_replace( '<!--btl_affiliate_disclosure_shortcode-->', $affiliate_disclosure, $content );

				// Determine whether to also show at top/bottom positions.
				$show_top    = $this->resolve_shortcode_position( 'top', $affiliate_link_position );
				$show_bottom = $this->resolve_shortcode_position( 'bottom', $affiliate_link_position );

				if ( $show_top ) {
					$content = $affiliate_disclosure . $content;
				}
				if ( $show_bottom ) {
					$content = $content . $affiliate_disclosure;
				}

				// Reset flags for next post in archive/loop.
				$this->shortcode_found  = false;
				$this->shortcode_top    = null;
				$this->shortcode_bottom = null;
			} else {
				// Original behavior — no shortcode.
				if ( 'top' === $affiliate_link_position ) {
					$content = $affiliate_disclosure . $content;
				} elseif ( 'bottom' === $affiliate_link_position ) {
					$content = $content . $affiliate_disclosure;
				} elseif ( 'top-bottom' === $affiliate_link_position ) {
					$content = $affiliate_disclosure . $content . $affiliate_disclosure;
				}
			}
		}
		return $content;
	}

	/**
	 * Shortcode callback for [btl_affiliate_link_disclosure] and legacy [affiliate_link_disclosure].
	 *
	 * Sets flags and returns a placeholder that add_affiliate_disclosure() replaces with actual HTML.
	 *
	 * @param array|string $atts Shortcode attributes.
	 * @return string Placeholder comment or empty string.
	 */
	public function shortcode_callback( $atts ) {
		$atts = shortcode_atts(
			array(
				'top'    => null,
				'bottom' => null,
			),
			$atts,
			'btl_affiliate_link_disclosure'
		);

		// Convert string 'true'/'false' to boolean, keep null if not specified.
		$this->shortcode_top    = ( null !== $atts['top'] ) ? filter_var( $atts['top'], FILTER_VALIDATE_BOOLEAN ) : null;
		$this->shortcode_bottom = ( null !== $atts['bottom'] ) ? filter_var( $atts['bottom'], FILTER_VALIDATE_BOOLEAN ) : null;
		$this->shortcode_found  = true;

		return '<!--btl_affiliate_disclosure_shortcode-->';
	}

	/**
	 * Determine whether to show disclosure at a given position when shortcode is active.
	 *
	 * If the shortcode explicitly sets the position, use that value.
	 * Otherwise, fall back to the global position setting.
	 *
	 * @param string $which           'top' or 'bottom'.
	 * @param string $global_position The global affiliate_link_position value.
	 * @return bool
	 */
	private function resolve_shortcode_position( $which, $global_position ) {
		$value = ( 'top' === $which ) ? $this->shortcode_top : $this->shortcode_bottom;

		if ( null !== $value ) {
			return $value;
		}

		// Fall back to global setting.
		if ( 'top' === $which ) {
			return in_array( $global_position, array( 'top', 'top-bottom' ), true );
		}

		return in_array( $global_position, array( 'bottom', 'top-bottom' ), true );
	}

	/**
	 * Register the global affiliate disclosure text with WPML String Translation.
	 *
	 * Uses the wpml_register_single_string action so the string appears in
	 * WPML → String Translation and can be translated into any active language.
	 *
	 * @return void
	 */
	private function register_wpml_strings() {
		$settings = $this->link_options;

		$is_enabled = ! empty( $settings['affiliate_link_disclosure'] ) ? $settings['affiliate_link_disclosure'] : false;
		if ( ! $is_enabled ) {
			return;
		}

		$disclosure_text = ! empty( $settings['affiliate_disclosure_text'] ) ? $settings['affiliate_disclosure_text'] : '';

		if ( ! empty( $disclosure_text ) ) {
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
			do_action( 'wpml_register_single_string', 'BetterLinks', 'Btl Disclosure Content', $disclosure_text );
		}
	}

	/**
	 * Translate the affiliate disclosure text via WPML String Translation.
	 *
	 * Hooked into the 'betterlinks_affiliate_disclosure_text' filter so that
	 * the global disclosure text is returned in the current frontend language.
	 * Skips translation when per-post text has already been translated.
	 *
	 * @param string $text The original disclosure text.
	 * @return string The translated text (or the original if WPML is inactive).
	 */
	public static function wpml_translate_disclosure( $text ) {
		// Skip global WPML translation for per-post disclosure text
		// (already translated with a post-specific string name).
		if ( self::$skip_global_wpml_translate ) {
			self::$skip_global_wpml_translate = false;
			return $text;
		}

		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
		return apply_filters( 'wpml_translate_single_string', $text, 'BetterLinks', 'Btl Disclosure Content' );
	}
}
