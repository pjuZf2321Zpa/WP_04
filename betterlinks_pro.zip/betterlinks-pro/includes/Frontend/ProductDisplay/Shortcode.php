<?php
namespace BetterLinksPro\Frontend\ProductDisplay;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers and renders the `[betterlinks_product_display]` shortcode.
 *
 * Attributes:
 *   id   (int)    required — the product display ID.
 *   type (string) optional — reserved for future "group" support; defaults to "single".
 */
class Shortcode {

	const TAG = 'betterlinks_product_display';

	public static function init() {
		$self = new self();
		add_shortcode( self::TAG, array( $self, 'render' ) );
	}

	/**
	 * Shortcode callback.
	 *
	 * @param array $atts
	 * @return string
	 */
	public function render( $atts ) {
		$atts = shortcode_atts(
			array(
				'type'     => 'single',
				'id'       => 0,
				'layout'   => '',
				'columns'  => 0,
				'template' => '',
			),
			$atts,
			self::TAG
		);

		$id   = absint( $atts['id'] );
		$type = 'group' === $atts['type'] ? 'group' : 'single';
		if ( ! $id ) {
			return '';
		}

		// Ensure the card styles are present even on non-singular contexts
		// (widgets/archives) where the head-level enqueue did not detect the shortcode.
		if ( ! wp_style_is( 'betterlinks-product-display', 'enqueued' ) ) {
			wp_enqueue_style( 'betterlinks-product-display' );
		}

		$overrides = array();
		if ( ! empty( $atts['template'] ) ) {
			$overrides['template'] = $atts['template'];
		}

		if ( 'group' === $type ) {
			if ( ! empty( $atts['layout'] ) ) {
				$overrides['layout'] = $atts['layout'];
			}
			if ( ! empty( $atts['columns'] ) ) {
				$overrides['columns'] = (int) $atts['columns'];
			}
			return Renderer::render_group( $id, $overrides );
		}

		return Renderer::render( $id, $overrides );
	}
}
