<?php
namespace BetterLinksPro\Frontend\ProductDisplay;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use BetterLinksPro\Traits\ProductDisplay as ProductDisplayTrait;

/**
 * Single source of truth for rendering a Product Display card on the front end.
 * Shared by the shortcode and the Gutenberg block (server-side render).
 *
 * All output is escaped here; callers can echo the returned string directly.
 */
class Renderer {

	use ProductDisplayTrait;

	const DEFAULT_TEMPLATE = 'epsilon';

	/**
	 * Supported premium layout templates. Each maps to a `.btl-pd--{key}` CSS layout.
	 * Add a key here and a matching CSS block to extend the system.
	 *
	 * @return string[]
	 */
	public static function templates() {
		return array( 'epsilon', 'vega', 'pollux', 'sirius', 'orion' );
	}

	/**
	 * @param string $template
	 * @return bool
	 */
	public static function is_valid_template( $template ) {
		return in_array( $template, self::templates(), true );
	}

	/**
	 * Render a product display card by ID.
	 *
	 * @param int   $id        Product display ID.
	 * @param array $overrides Optional per-instance overrides from the block/shortcode:
	 *                         'template' => one of {@see self::templates()} to override the
	 *                         layout saved on the display.
	 * @return string Escaped HTML, or '' when nothing should render.
	 */
	public static function render( $id, $overrides = array() ) {
		$id      = absint( $id );
		$display = $id ? self::get_product_display( $id ) : null;

		if ( null === $display || empty( $display['status'] ) ) {
			// Only surface a hint to users who can edit content; render nothing publicly.
			if ( current_user_can( 'edit_posts' ) ) {
				return '<div class="btl-pd-notice">' . esc_html__( 'This promo card is no longer available. It may have been deleted.', 'betterlinks-pro' ) . '</div>';
			}
			return '';
		}

		$template_override = isset( $overrides['template'] ) ? $overrides['template'] : '';

		return self::render_card( $display, $template_override );
	}

	/**
	 * Render a group of product displays as a grid or list.
	 *
	 * @param int   $group_id
	 * @param array $overrides Optional per-instance overrides from the block/shortcode:
	 *                         'layout'   => 'grid'|'list' to override the saved group type;
	 *                         'columns'  => 1-4 to override the saved grid column count;
	 *                         'template' => one of {@see self::templates()} to override the
	 *                         layout of every card in the group.
	 * @return string
	 */
	public static function render_group( $group_id, $overrides = array() ) {
		$group_id = absint( $group_id );
		$group    = $group_id ? self::get_product_group( $group_id ) : null;

		if ( null === $group || empty( $group['status'] ) || empty( $group['display_ids'] ) ) {
			if ( current_user_can( 'edit_posts' ) ) {
				return '<div class="btl-pd-notice">' . esc_html__( 'This card group is empty or no longer available.', 'betterlinks-pro' ) . '</div>';
			}
			return '';
		}

		$type    = in_array( $group['group_type'], array( 'grid', 'list' ), true ) ? $group['group_type'] : 'grid';
		$columns = isset( $group['columns'] ) ? max( 1, min( 4, (int) $group['columns'] ) ) : 2;

		// Per-instance overrides take precedence over the saved group settings.
		if ( ! empty( $overrides['layout'] ) && in_array( $overrides['layout'], array( 'grid', 'list' ), true ) ) {
			$type = $overrides['layout'];
		}
		if ( ! empty( $overrides['columns'] ) ) {
			$columns = max( 1, min( 4, (int) $overrides['columns'] ) );
		}

		$template_override = isset( $overrides['template'] ) ? $overrides['template'] : '';

		$cards = '';
		foreach ( $group['display_ids'] as $display_id ) {
			$display = self::get_product_display( $display_id );
			if ( null === $display || empty( $display['status'] ) ) {
				continue;
			}
			$cards .= self::render_card( $display, $template_override );
		}

		if ( '' === $cards ) {
			return '';
		}

		$classes = 'btl-pd-group btl-pd-group--' . $type;
		if ( 'grid' === $type ) {
			$classes .= ' btl-pd-group--cols-' . $columns;
		}

		return '<div class="' . esc_attr( $classes ) . '">' . $cards . '</div>';
	}

	/**
	 * Build the markup for a single product display card.
	 *
	 * @param array  $display
	 * @param string $template_override Optional template key that, when valid, overrides the
	 *                                  template saved on the display (block/shortcode control).
	 * @return string
	 */
	public static function render_card( $display, $template_override = '' ) {
		if ( '' !== $template_override && self::is_valid_template( $template_override ) ) {
			$template = $template_override;
		} else {
			$template = self::is_valid_template( $display['template'] ) ? $display['template'] : self::DEFAULT_TEMPLATE;
		}

		$primary_cta   = self::cta_html( $display, 'primary' );
		$secondary_cta = self::cta_html( $display, 'secondary' );
		$disclosure    = self::disclosure_html( $display );
		$price_html    = self::price_html( $display );
		$style_attr    = self::style_attr( $display );

		// media / content / actions / disclosure are DIRECT children so each template
		// can arrange them independently via CSS grid areas (see the SCSS).
		ob_start();
		?>
		<div class="btl-pd btl-pd--<?php echo esc_attr( $template ); ?>"<?php echo $style_attr ? ' style="' . esc_attr( $style_attr ) . '"' : ''; ?>>
			<div class="btl-pd__media">
				<?php if ( ! empty( $display['badge_text'] ) ) : ?>
					<span class="btl-pd__badge"><?php echo esc_html( $display['badge_text'] ); ?></span>
				<?php endif; ?>
				<?php if ( ! empty( $display['product_image_url'] ) ) : ?>
					<img class="btl-pd__image" src="<?php echo esc_url( $display['product_image_url'] ); ?>" alt="<?php echo esc_attr( $display['product_name'] ); ?>" loading="lazy" />
				<?php else : ?>
					<span class="btl-pd__image btl-pd__image--placeholder" aria-hidden="true"></span>
				<?php endif; ?>
			</div>

			<div class="btl-pd__content">
				<?php if ( ! empty( $display['product_name'] ) ) : ?>
					<h3 class="btl-pd__title"><?php echo esc_html( $display['product_name'] ); ?></h3>
				<?php endif; ?>

				<?php
				echo $price_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in price_html().
				?>

				<?php if ( ! empty( $display['description'] ) ) : ?>
					<div class="btl-pd__desc"><?php echo wp_kses_post( $display['description'] ); ?></div>
				<?php endif; ?>
			</div>

			<?php if ( $primary_cta || $secondary_cta ) : ?>
				<div class="btl-pd__actions">
					<?php
					echo $primary_cta;   // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in cta_html().
					echo $secondary_cta; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in cta_html().
					?>
				</div>
			<?php endif; ?>

			<?php
			echo $disclosure; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in disclosure_html().
			?>
		</div>
		<?php
		return trim( ob_get_clean() );
	}

	/**
	 * WooCommerce-style price markup. When a sale price is set, the regular price
	 * is shown struck-through and the sale price highlighted.
	 *
	 * @param array $display
	 * @return string
	 */
	protected static function price_html( $display ) {
		$regular = isset( $display['regular_price'] ) && '' !== trim( (string) $display['regular_price'] )
			? trim( (string) $display['regular_price'] )
			: ( isset( $display['price'] ) ? trim( (string) $display['price'] ) : '' ); // legacy fallback.
		$sale = isset( $display['sale_price'] ) ? trim( (string) $display['sale_price'] ) : '';

		if ( '' === $regular && '' === $sale ) {
			return '';
		}

		if ( '' !== $sale && '' !== $regular ) {
			return '<div class="btl-pd__price btl-pd__price--has-sale">'
				. '<span class="btl-pd__price-sale">' . esc_html( $sale ) . '</span>'
				. '<span class="btl-pd__price-regular">' . esc_html( $regular ) . '</span>'
				. '</div>';
		}

		$single = '' !== $sale ? $sale : $regular;
		return '<div class="btl-pd__price"><span class="btl-pd__price-sale">' . esc_html( $single ) . '</span></div>';
	}

	/**
	 * Build the inline CSS custom-property string from a display's style overrides.
	 *
	 * @param array $display
	 * @return string e.g. "--btl-pd-card-bg:#fff;--btl-pd-btn1-bg:#000;"
	 */
	protected static function style_attr( $display ) {
		$style = isset( $display['style'] ) && is_array( $display['style'] ) ? $display['style'] : array();
		if ( empty( $style ) ) {
			return '';
		}

		$vars = self::style_to_vars( $style );
		$out  = '';
		foreach ( $vars as $prop => $value ) {
			$out .= $prop . ':' . $value . ';';
		}
		return $out;
	}

	/**
	 * Map a style override object to CSS custom properties. Single source shared in
	 * spirit with the JS helper (styleVars.js). Size values become px.
	 *
	 * @param array $style
	 * @return array prop => value
	 */
	public static function style_to_vars( $style ) {
		$color_map = array(
			'cardBg'             => '--btl-pd-card-bg',
			'cardColor'          => '--btl-pd-card-color',
			'cardBorderColor'    => '--btl-pd-card-border-color',
			'priceRegularColor'  => '--btl-pd-price-regular-color',
			'priceSaleColor'     => '--btl-pd-price-sale-color',
			'badgeBg'            => '--btl-pd-badge-bg',
			'badgeColor'         => '--btl-pd-badge-color',
			'primaryBg'          => '--btl-pd-btn1-bg',
			'primaryColor'       => '--btl-pd-btn1-color',
			'primaryHoverBg'     => '--btl-pd-btn1-hover-bg',
			'primaryHoverColor'  => '--btl-pd-btn1-hover-color',
			'secondaryBg'        => '--btl-pd-btn2-bg',
			'secondaryColor'     => '--btl-pd-btn2-color',
			'secondaryHoverBg'   => '--btl-pd-btn2-hover-bg',
			'secondaryHoverColor' => '--btl-pd-btn2-hover-color',
		);
		$size_map  = array(
			'cardBorderWidth' => '--btl-pd-card-border-width',
			'cardRadius'      => '--btl-pd-card-radius',
			'cardPadding'     => '--btl-pd-card-padding',
			'badgeRadius'     => '--btl-pd-badge-radius',
			'btnRadius'       => '--btl-pd-btn-radius',
		);

		$vars = array();
		foreach ( $color_map as $key => $prop ) {
			if ( ! empty( $style[ $key ] ) ) {
				$vars[ $prop ] = $style[ $key ];
			}
		}
		foreach ( $size_map as $key => $prop ) {
			if ( isset( $style[ $key ] ) && '' !== $style[ $key ] && null !== $style[ $key ] ) {
				$vars[ $prop ] = (int) $style[ $key ] . 'px';
			}
		}
		return $vars;
	}

	/**
	 * Build a single CTA anchor.
	 *
	 * Tracking ON  -> href = the link's short URL (routes through BetterLinks redirect + analytics).
	 * Tracking OFF -> href = the link's raw target URL (untracked direct link).
	 *
	 * @param array  $display
	 * @param string $which   'primary' | 'secondary'.
	 * @return string Escaped anchor HTML, or '' when the CTA is not configured.
	 */
	protected static function cta_html( $display, $which ) {
		$link_id = isset( $display[ $which . '_link_id' ] ) ? absint( $display[ $which . '_link_id' ] ) : 0;
		$text    = isset( $display[ $which . '_button_text' ] ) ? trim( (string) $display[ $which . '_button_text' ] ) : '';

		if ( ! $link_id || '' === $text ) {
			return '';
		}

		$link = self::resolve_link( $link_id );
		if ( empty( $link ) ) {
			return '';
		}

		$tracking = ! empty( $display[ $which . '_tracking' ] );
		$nofollow = ! empty( $display[ $which . '_nofollow' ] );
		$new_tab  = ! empty( $display['new_tab'] );

		if ( $tracking && ! empty( $link['short_url'] ) ) {
			$href = trailingslashit( home_url() ) . ltrim( $link['short_url'], '/' );
		} else {
			$href = ! empty( $link['target_url'] ) ? $link['target_url'] : ( ! empty( $link['short_url'] ) ? trailingslashit( home_url() ) . ltrim( $link['short_url'], '/' ) : '' );
		}

		if ( '' === $href ) {
			return '';
		}

		$rel = array();
		if ( $nofollow ) {
			$rel[] = 'nofollow';
			$rel[] = 'sponsored';
		}
		if ( $new_tab ) {
			$rel[] = 'noopener';
		}

		$attrs  = ' href="' . esc_url( $href ) . '"';
		$attrs .= ' class="btl-pd-cta btl-pd-cta--' . esc_attr( $which ) . '"';
		if ( $new_tab ) {
			$attrs .= ' target="_blank"';
		}
		if ( ! empty( $rel ) ) {
			$attrs .= ' rel="' . esc_attr( implode( ' ', array_unique( $rel ) ) ) . '"';
		}

		return '<a' . $attrs . '>' . esc_html( $text ) . '</a>';
	}

	/**
	 * Resolve a link row (id => short_url/target_url) via the free Helper.
	 *
	 * @param int $link_id
	 * @return array
	 */
	protected static function resolve_link( $link_id ) {
		if ( ! class_exists( '\BetterLinks\Helper' ) ) {
			return array();
		}
		$rows = \BetterLinks\Helper::get_link_by_ID( $link_id );
		if ( empty( $rows ) || ! is_array( $rows ) ) {
			return array();
		}
		return (array) current( $rows );
	}

	/**
	 * Build the affiliate-disclosure block for a display.
	 *
	 * @param array $display
	 * @return string
	 */
	protected static function disclosure_html( $display ) {
		if ( empty( $display['show_disclosure'] ) ) {
			return '';
		}

		$text = '';
		if ( ! empty( $display['default_disclosure'] ) ) {
			$text = self::global_disclosure_text();
		} else {
			$text = isset( $display['disclosure_text'] ) ? $display['disclosure_text'] : '';
		}

		$text = apply_filters( 'betterlinks_affiliate_disclosure_text', $text );
		$text = trim( (string) $text );
		if ( '' === $text ) {
			return '';
		}

		return '<div class="btl-pd__disclosure">' . wp_kses_post( wpautop( $text ) ) . '</div>';
	}

	/**
	 * Global affiliate disclosure text from BetterLinks settings.
	 *
	 * @return string
	 */
	protected static function global_disclosure_text() {
		if ( ! defined( 'BETTERLINKS_LINKS_OPTION_NAME' ) ) {
			return '';
		}
		$settings = get_option( BETTERLINKS_LINKS_OPTION_NAME );
		if ( is_string( $settings ) ) {
			$settings = json_decode( $settings, true );
		}
		if ( ! is_array( $settings ) ) {
			return '';
		}
		return isset( $settings['affiliate_disclosure_text'] ) ? (string) $settings['affiliate_disclosure_text'] : '';
	}
}
