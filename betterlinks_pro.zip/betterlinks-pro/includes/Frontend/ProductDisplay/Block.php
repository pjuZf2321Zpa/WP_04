<?php
namespace BetterLinksPro\Frontend\ProductDisplay;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers the `betterlinks/product-display` dynamic block.
 *
 * The block is server-side rendered through the same {@see Renderer} used by the
 * shortcode, so the editor preview matches the front end exactly.
 */
class Block {

	const NAME = 'betterlinks/product-display';

	public static function init() {
		$self = new self();
		add_action( 'init', array( $self, 'register_block' ) );
		add_action( 'enqueue_block_editor_assets', array( $self, 'localize_editor_script' ), 20 );
		add_action( 'admin_notices', array( $self, 'maybe_notice_missing_build' ) );
	}

	/**
	 * Surface a missing editor bundle instead of silently degrading `editor_script`
	 * to null. Without this, a build that never ran looks identical to "block not
	 * enabled" and the Promo Cards block simply never appears in the inserter.
	 *
	 * Shown only to admins on block-editor screens, and only under WP_DEBUG so a
	 * properly built release never nags — in a shipped build the asset exists and
	 * this is a no-op.
	 */
	public function maybe_notice_missing_build() {
		if ( ! ( defined( 'WP_DEBUG' ) && WP_DEBUG ) || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		if ( file_exists( BETTERLINKS_PRO_ASSETS_DIR_PATH . 'js/betterlinkspro-product-display.core.min.asset.php' ) ) {
			return;
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || ! method_exists( $screen, 'is_block_editor' ) || ! $screen->is_block_editor() ) {
			return;
		}
		echo '<div class="notice notice-warning"><p><strong>BetterLinks Pro:</strong> '
			. esc_html__( 'The Promo Cards block editor bundle is missing, so the block will not appear in the inserter. Run the plugin build (yarn build) to generate assets/js/betterlinkspro-product-display.core.min.js.', 'betterlinks-pro' )
			. '</p></div>';
	}

	/**
	 * Register the block type and its editor script.
	 */
	public function register_block() {
		if ( ! function_exists( 'register_block_type' ) ) {
			return;
		}

		$asset_file  = BETTERLINKS_PRO_ASSETS_DIR_PATH . 'js/betterlinkspro-product-display.core.min.asset.php';
		$script_url  = BETTERLINKS_PRO_ASSETS_URI . 'js/betterlinkspro-product-display.core.min.js';
		$has_build   = file_exists( $asset_file );
		$dependencies = $has_build ? include $asset_file : array(
			'dependencies' => array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-i18n', 'wp-server-side-render' ),
			'version'      => BETTERLINKS_PRO_VERSION,
		);

		if ( $has_build ) {
			wp_register_script(
				'betterlinks-product-display-block',
				$script_url,
				$dependencies['dependencies'],
				$dependencies['version'],
				true
			);
			wp_set_script_translations( 'betterlinks-product-display-block', 'betterlinks-pro', BETTERLINKS_PRO_ROOT_DIR_PATH . 'languages/' );
		}

		// Register the card style here too so it can be attached to the block as a
		// block-aware `style` — WordPress then loads it only when the block renders
		// on the front end, and inside the editor iframe for the SSR preview.
		if ( ! wp_style_is( 'betterlinks-product-display', 'registered' ) ) {
			wp_register_style(
				'betterlinks-product-display',
				BETTERLINKS_PRO_ASSETS_URI . 'css/betterlinks-product-display.css',
				array(),
				BETTERLINKS_PRO_VERSION
			);
		}

		register_block_type(
			self::NAME,
			array(
				'api_version'     => 2,
				'editor_script'   => $has_build ? 'betterlinks-product-display-block' : null,
				'style'           => 'betterlinks-product-display',
				'render_callback' => array( $this, 'render_callback' ),
				'attributes'      => array(
					'displayType' => array(
						'type'    => 'string',
						'default' => 'single',
					),
					'displayId'   => array(
						'type'    => 'integer',
						'default' => 0,
					),
					'groupLayout' => array(
						'type'    => 'string',
						'default' => '',
					),
					'columns'     => array(
						'type'    => 'integer',
						'default' => 0,
					),
					'template'    => array(
						'type'    => 'string',
						'default' => '',
					),
				),
			)
		);
	}

	/**
	 * Provide REST details to the block editor script.
	 */
	public function localize_editor_script() {
		if ( ! wp_script_is( 'betterlinks-product-display-block', 'enqueued' ) && ! wp_script_is( 'betterlinks-product-display-block', 'registered' ) ) {
			return;
		}
		wp_localize_script(
			'betterlinks-product-display-block',
			'betterLinksProductDisplayBlock',
			array(
				'rest_url'  => rest_url(),
				'nonce'     => wp_create_nonce( 'wp_rest' ),
				'namespace' => BETTERLINKS_PRO_PLUGIN_SLUG . '/v1/',
				'adminUrl'  => admin_url( 'admin.php?page=' . Manager::MENU_SLUG ),
				'templates' => Renderer::templates(),
			)
		);
	}

	/**
	 * Server-side render callback — delegates to the shared Renderer.
	 *
	 * @param array $attributes
	 * @return string
	 */
	public function render_callback( $attributes ) {
		$type = isset( $attributes['displayType'] ) && 'group' === $attributes['displayType'] ? 'group' : 'single';
		$id   = isset( $attributes['displayId'] ) ? absint( $attributes['displayId'] ) : 0;
		if ( ! $id ) {
			if ( current_user_can( 'edit_posts' ) ) {
				return '<div class="btl-pd-notice">' . esc_html__( 'Select a promo card to show.', 'betterlinks-pro' ) . '</div>';
			}
			return '';
		}

		if ( wp_style_is( 'betterlinks-product-display', 'registered' ) ) {
			wp_enqueue_style( 'betterlinks-product-display' );
		}

		$overrides = array();
		if ( ! empty( $attributes['template'] ) ) {
			$overrides['template'] = $attributes['template'];
		}

		if ( 'group' === $type ) {
			if ( ! empty( $attributes['groupLayout'] ) ) {
				$overrides['layout'] = $attributes['groupLayout'];
			}
			if ( ! empty( $attributes['columns'] ) ) {
				$overrides['columns'] = (int) $attributes['columns'];
			}
			return Renderer::render_group( $id, $overrides );
		}

		return Renderer::render( $id, $overrides );
	}
}
