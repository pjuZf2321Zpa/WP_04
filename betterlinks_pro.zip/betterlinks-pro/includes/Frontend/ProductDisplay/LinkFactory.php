<?php
namespace BetterLinksPro\Frontend\ProductDisplay;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Creates a real BetterLinks short link from a raw URL, reusing BetterLinks' own
 * insert pipeline (so the links.json cache the redirect engine relies on is kept
 * in sync). Used by the "Create New" option on a Product Display CTA.
 */
class LinkFactory {

	use \BetterLinks\Traits\ArgumentSchema;
	use \BetterLinks\Traits\Links;

	/**
	 * Create a short link for $url and return its ID (0 on failure).
	 *
	 * @param string $url   Target URL.
	 * @param string $title Optional link title (defaults to the URL host).
	 * @return int
	 */
	public static function create( $url, $title = '' ) {
		if ( ! class_exists( '\BetterLinks\Helper' ) ) {
			return 0;
		}

		$url = esc_url_raw( trim( (string) $url ) );
		if ( empty( $url ) || ! wp_http_validate_url( $url ) ) {
			return 0;
		}

		$self   = new self();
		$prefix = $self->get_prefix();

		// Generate a unique short URL (prefix/slug).
		$short = '';
		$slug  = '';
		$guard = 0;
		do {
			$slug  = strtolower( wp_generate_password( 8, false, false ) );
			$short = $prefix ? $prefix . '/' . $slug : $slug;
			$guard++;
		} while ( \BetterLinks\Helper::is_exists_short_url( $short ) && $guard < 10 );

		if ( '' === $title ) {
			$host  = wp_parse_url( $url, PHP_URL_HOST );
			$title = $host ? $host : __( 'Product link', 'betterlinks-pro' );
		}

		$arg = array(
			'link_title'    => sanitize_text_field( $title ),
			'link_slug'     => $slug,
			'short_url'     => $short,
			'target_url'    => $url,
			'redirect_type' => '307',
			'link_status'   => 'publish',
			'nofollow'      => '',
			'sponsored'     => '',
			'track_me'      => 'on',
			'cat_id'        => 1,
		);

		$result = $self->insert_link( $arg );
		if ( is_array( $result ) && ! empty( $result['ID'] ) ) {
			// Invalidate + rebuild the links list cache so the new link shows up in
			// Manage Links and in the Product Display CTA picker immediately (the
			// normal Links REST flow clears this transient too).
			if ( method_exists( '\BetterLinks\Helper', 'clear_query_cache' ) ) {
				\BetterLinks\Helper::clear_query_cache();
			}
			return (int) $result['ID'];
		}
		return 0;
	}

	/**
	 * Resolve the configured short-link prefix (e.g. "go").
	 *
	 * @return string
	 */
	private function get_prefix() {
		if ( ! defined( 'BETTERLINKS_LINKS_OPTION_NAME' ) ) {
			return '';
		}
		$settings = get_option( BETTERLINKS_LINKS_OPTION_NAME );
		if ( is_string( $settings ) ) {
			$settings = json_decode( $settings, true );
		}
		return ( is_array( $settings ) && ! empty( $settings['prefix'] ) ) ? $settings['prefix'] : '';
	}
}
