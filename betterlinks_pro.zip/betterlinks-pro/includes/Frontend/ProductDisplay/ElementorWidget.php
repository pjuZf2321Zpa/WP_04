<?php
namespace BetterLinksPro\Frontend\ProductDisplay;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Elementor "Promo Card" widget.
 *
 * The Elementor counterpart to the {@see Block} Gutenberg block: it exposes the
 * same set of controls (card type, card/group, template, layout, columns) and
 * renders through the shared {@see Renderer}, so the output matches the shortcode
 * and block exactly — one source of truth for all three editors.
 */
class ElementorWidget extends \Elementor\Widget_Base {

	/**
	 * Sentinel select value that, when chosen, opens the Promo Cards admin screen
	 * (handled by the editor script in Manager::enqueue_elementor_editor_script()).
	 */
	const CREATE_NEW = 'create_new';

	/**
	 * Unique widget slug used in the Elementor markup and registry.
	 */
	public function get_name() {
		return 'betterlinks-promo-card';
	}

	/**
	 * Widget title shown in the Elementor panel.
	 */
	public function get_title() {
		return __( 'Promo Card', 'betterlinks-pro' );
	}

	/**
	 * Panel icon. `btl-promo-card-icon` paints the custom Promo Card SVG in the tile
	 * centre; the `btl-promo-card-widget` marker lets Manager::enqueue_elementor_icon()
	 * drop a small BetterLinks badge into the tile's top-right corner. Both are styled
	 * in that method.
	 */
	public function get_icon() {
		return 'btl-promo-card-icon btl-promo-card-widget';
	}

	/**
	 * Panel category — the dedicated "BetterLinks" group.
	 */
	public function get_categories() {
		return array( 'betterlinks' );
	}

	/**
	 * Search keywords in the Elementor widget finder.
	 */
	public function get_keywords() {
		return array( 'betterlinks', 'promo', 'product', 'card', 'affiliate' );
	}

	/**
	 * Attach the shared card stylesheet whenever the widget is present.
	 */
	public function get_style_depends() {
		return array( 'betterlinks-product-display' );
	}

	/**
	 * Register the widget controls, mirroring the block attributes.
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'section_card',
			array(
				'label' => __( 'Card Settings', 'betterlinks-pro' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'display_type',
			array(
				'label'   => __( 'Card Type', 'betterlinks-pro' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'single',
				'options' => array(
					'single' => __( 'Single Card', 'betterlinks-pro' ),
					'group'  => __( 'Card Group', 'betterlinks-pro' ),
				),
			)
		);

		$this->add_control(
			'display_id',
			array(
				'label'       => __( 'Promo Card', 'betterlinks-pro' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => '',
				'options'     => $this->card_options(),
				'label_block' => true,
				'condition'   => array(
					'display_type' => 'single',
				),
			)
		);

		$this->add_control(
			'group_id',
			array(
				'label'       => __( 'Card Group', 'betterlinks-pro' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => '',
				'options'     => $this->group_options(),
				'label_block' => true,
				'condition'   => array(
					'display_type' => 'group',
				),
			)
		);

		$this->add_control(
			'template',
			array(
				'label'   => __( 'Template', 'betterlinks-pro' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->template_options(),
			)
		);

		$this->add_control(
			'group_layout',
			array(
				'label'     => __( 'Layout', 'betterlinks-pro' ),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => '',
				'options'   => array(
					''     => __( 'Default', 'betterlinks-pro' ),
					'grid' => __( 'Grid', 'betterlinks-pro' ),
					'list' => __( 'List', 'betterlinks-pro' ),
				),
				'condition' => array(
					'display_type' => 'group',
				),
			)
		);

		$this->add_control(
			'columns',
			array(
				'label'     => __( 'Columns', 'betterlinks-pro' ),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => '',
				'options'   => array(
					''  => __( 'Default', 'betterlinks-pro' ),
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
				),
				'condition' => array(
					'display_type'  => 'group',
					'group_layout!' => 'list',
				),
			)
		);

		$this->end_controls_section();

		$this->register_style_controls();
	}

	/**
	 * Register the Style tab — one control per property the Promo Card designer
	 * exposes, so the same look can be tuned from Elementor. Every control defaults
	 * to empty, meaning "inherit the card's saved style"; a set value overrides it.
	 *
	 * Each control drives the card's CSS custom property through Elementor `selectors`,
	 * so Elementor injects the change live (no widget reload) and it applies on the
	 * front end too. `!important` lets a widget value win over a value baked into the
	 * card's saved inline style, while empty controls emit no rule and fall back to it.
	 */
	protected function register_style_controls() {
		$target = '{{WRAPPER}} .btl-pd';

		// Color control bound to a `--btl-pd-*` custom property.
		$color = function ( $label, $var ) use ( $target ) {
			return array(
				'label'     => $label,
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array( $target => '--' . $var . ': {{VALUE}} !important;' ),
			);
		};
		// Px slider control bound to a `--btl-pd-*` custom property.
		$size = function ( $label, $var, $min, $max ) use ( $target ) {
			return array(
				'label'      => $label,
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => $min, 'max' => $max ) ),
				'selectors'  => array( $target => '--' . $var . ': {{SIZE}}{{UNIT}} !important;' ),
			);
		};
		$heading = function ( $label ) {
			return array(
				'label'     => $label,
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			);
		};

		// ---- Card --------------------------------------------------------------
		$this->start_controls_section(
			'section_style_card',
			array(
				'label' => __( 'Card', 'betterlinks-pro' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_control( 'style_card_bg', $color( __( 'Background Color', 'betterlinks-pro' ), 'btl-pd-card-bg' ) );
		$this->add_control( 'style_card_border_color', $color( __( 'Border Color', 'betterlinks-pro' ), 'btl-pd-card-border-color' ) );
		$this->add_control( 'style_card_border_width', $size( __( 'Border Width', 'betterlinks-pro' ), 'btl-pd-card-border-width', 0, 12 ) );
		$this->add_control( 'style_card_radius', $size( __( 'Border Radius', 'betterlinks-pro' ), 'btl-pd-card-radius', 0, 40 ) );
		$this->add_control( 'style_card_padding', $size( __( 'Padding', 'betterlinks-pro' ), 'btl-pd-card-padding', 0, 60 ) );
		$this->end_controls_section();

		// ---- Pricing -----------------------------------------------------------
		$this->start_controls_section(
			'section_style_pricing',
			array(
				'label' => __( 'Pricing', 'betterlinks-pro' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_control( 'style_price_regular_color', $color( __( 'Regular Price Color', 'betterlinks-pro' ), 'btl-pd-price-regular-color' ) );
		$this->add_control( 'style_price_sale_color', $color( __( 'Sale Price Color', 'betterlinks-pro' ), 'btl-pd-price-sale-color' ) );
		$this->end_controls_section();

		// ---- Badge -------------------------------------------------------------
		$this->start_controls_section(
			'section_style_badge',
			array(
				'label' => __( 'Badge', 'betterlinks-pro' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_control( 'style_badge_bg', $color( __( 'Background', 'betterlinks-pro' ), 'btl-pd-badge-bg' ) );
		$this->add_control( 'style_badge_color', $color( __( 'Text Color', 'betterlinks-pro' ), 'btl-pd-badge-color' ) );
		$this->add_control( 'style_badge_radius', $size( __( 'Radius', 'betterlinks-pro' ), 'btl-pd-badge-radius', 0, 30 ) );
		$this->end_controls_section();

		// ---- Buttons -----------------------------------------------------------
		$this->start_controls_section(
			'section_style_buttons',
			array(
				'label' => __( 'Buttons', 'betterlinks-pro' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_control( 'style_btn_radius', $size( __( 'Button Radius', 'betterlinks-pro' ), 'btl-pd-btn-radius', 0, 40 ) );
		$this->add_control( 'style_primary_heading', $heading( __( 'Primary Button', 'betterlinks-pro' ) ) );
		$this->add_control( 'style_primary_bg', $color( __( 'Background', 'betterlinks-pro' ), 'btl-pd-btn1-bg' ) );
		$this->add_control( 'style_primary_color', $color( __( 'Text', 'betterlinks-pro' ), 'btl-pd-btn1-color' ) );
		$this->add_control( 'style_primary_hover_bg', $color( __( 'Hover Background', 'betterlinks-pro' ), 'btl-pd-btn1-hover-bg' ) );
		$this->add_control( 'style_primary_hover_color', $color( __( 'Hover Text', 'betterlinks-pro' ), 'btl-pd-btn1-hover-color' ) );
		$this->add_control( 'style_secondary_heading', $heading( __( 'Secondary Button', 'betterlinks-pro' ) ) );
		$this->add_control( 'style_secondary_bg', $color( __( 'Background', 'betterlinks-pro' ), 'btl-pd-btn2-bg' ) );
		$this->add_control( 'style_secondary_color', $color( __( 'Text', 'betterlinks-pro' ), 'btl-pd-btn2-color' ) );
		$this->add_control( 'style_secondary_hover_bg', $color( __( 'Hover Background', 'betterlinks-pro' ), 'btl-pd-btn2-hover-bg' ) );
		$this->add_control( 'style_secondary_hover_color', $color( __( 'Hover Text', 'betterlinks-pro' ), 'btl-pd-btn2-hover-color' ) );
		$this->end_controls_section();
	}

	/**
	 * Front-end (and editor preview) render — delegates to the shared Renderer.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$type = ( isset( $settings['display_type'] ) && 'group' === $settings['display_type'] ) ? 'group' : 'single';
		$id   = 'group' === $type ? $this->resolve_id( $settings['group_id'] ?? '' ) : $this->resolve_id( $settings['display_id'] ?? '' );

		if ( ! $id ) {
			if ( $this->is_edit_mode() ) {
				echo '<div class="btl-pd-notice">' . esc_html__( 'Select a promo card to show.', 'betterlinks-pro' ) . '</div>';
			}
			return;
		}

		// The style handle is registered by Manager on wp_enqueue_scripts, but
		// register defensively so the Elementor editor preview is styled too.
		if ( ! wp_style_is( 'betterlinks-product-display', 'registered' ) ) {
			wp_register_style(
				'betterlinks-product-display',
				BETTERLINKS_PRO_ASSETS_URI . 'css/betterlinks-product-display.css',
				array(),
				BETTERLINKS_PRO_VERSION
			);
		}
		wp_enqueue_style( 'betterlinks-product-display' );

		$overrides = array();
		if ( ! empty( $settings['template'] ) ) {
			$overrides['template'] = $settings['template'];
		}

		// Style-tab values are applied as live CSS via each control's `selectors`
		// (see register_style_controls()), so nothing style-related is passed here.
		if ( 'group' === $type ) {
			if ( ! empty( $settings['group_layout'] ) ) {
				$overrides['layout'] = $settings['group_layout'];
			}
			if ( ! empty( $settings['columns'] ) ) {
				$overrides['columns'] = (int) $settings['columns'];
			}
			// Renderer output is fully escaped at build time.
			echo Renderer::render_group( $id, $overrides ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			return;
		}

		echo Renderer::render( $id, $overrides ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Whether Elementor is rendering inside the editor canvas.
	 *
	 * @return bool
	 */
	protected function is_edit_mode() {
		return isset( \Elementor\Plugin::$instance->editor ) && \Elementor\Plugin::$instance->editor->is_edit_mode();
	}

	/**
	 * Turn a select value into a display/group ID. Options are keyed `display-{id}` /
	 * `group-{id}` (see card_options()/group_options()), so pull the trailing digits.
	 * The empty placeholder and the `create_new` sentinel both resolve to 0.
	 *
	 * @param string $value
	 * @return int
	 */
	protected function resolve_id( $value ) {
		return (int) preg_replace( '/\D/', '', (string) $value );
	}

	/**
	 * Build the single-card <option> list for the panel select.
	 *
	 * @return array<string,string>
	 */
	protected function card_options() {
		$cards = array();
		foreach ( Renderer::get_product_displays() as $card ) {
			$label = isset( $card['product_name'] ) && '' !== $card['product_name'] ? $card['product_name'] : '#' . $card['ID'];
			// Prefix so the option key is a non-numeric string: Elementor hands options
			// to the editor as a JS object, where integer-like keys jump to the top and
			// break both the placeholder position and this ordering. See resolve_id().
			$cards[ 'display-' . (int) $card['ID'] ] = $label;
		}
		natcasesort( $cards ); // Organize the list alphabetically by name.

		// No cards yet: offer a shortcut that opens the Promo Cards admin screen
		// (handled by the editor script). Once cards exist, just list them.
		if ( empty( $cards ) ) {
			return array(
				''               => __( '— Select a card —', 'betterlinks-pro' ),
				self::CREATE_NEW => __( '＋ Create New Promo Card', 'betterlinks-pro' ),
			);
		}

		return array( '' => __( '— Select a card —', 'betterlinks-pro' ) ) + $cards;
	}

	/**
	 * Build the card-group <option> list for the panel select.
	 *
	 * @return array<string,string>
	 */
	protected function group_options() {
		$groups = array();
		foreach ( Renderer::get_product_groups() as $group ) {
			$label = isset( $group['group_title'] ) && '' !== $group['group_title'] ? $group['group_title'] : '#' . $group['ID'];
			$groups[ 'group-' . (int) $group['ID'] ] = $label;
		}
		natcasesort( $groups );

		if ( empty( $groups ) ) {
			return array(
				''               => __( '— Select a card group —', 'betterlinks-pro' ),
				self::CREATE_NEW => __( '＋ Create New Card Group', 'betterlinks-pro' ),
			);
		}

		return array( '' => __( '— Select a card group —', 'betterlinks-pro' ) ) + $groups;
	}

	/**
	 * Build the template <option> list (Default + the Renderer's template keys).
	 *
	 * @return array<string,string>
	 */
	protected function template_options() {
		$options = array( '' => __( 'Default', 'betterlinks-pro' ) );
		foreach ( Renderer::templates() as $key ) {
			$options[ $key ] = ucfirst( $key );
		}
		return $options;
	}
}
