<?php
namespace BetterLinksPro\Frontend\ProductDisplay;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Bootstraps the Product Display feature: shortcode, block, front-end styles,
 * and the admin submenu item. Loaded in both admin and front-end contexts so the
 * block can register and the SPA menu/page can mount.
 */
class Manager {

	// Admin page slug. Kept in sync with the Free `Helper::get_menu_items()` key,
	// which registers the submenu page this slug resolves to. NOTE: this is the
	// menu/URL slug only — the REST base (`product-displays`), block name
	// (`betterlinks/product-display`) and style handle stay as they are.
	const MENU_SLUG = 'betterlinks-promo-cards';

	public static function init() {
		Shortcode::init();
		Block::init();

		$self = new self();
		add_action( 'wp_enqueue_scripts', array( $self, 'register_frontend_style' ), 5 );
		add_action( 'wp_enqueue_scripts', array( $self, 'maybe_enqueue_frontend_style' ), 20 );
		add_action( 'enqueue_block_editor_assets', array( $self, 'register_frontend_style' ), 5 );
		add_filter( 'betterlinks/helper/menu_items', array( $self, 'register_menu_item' ) );

		// Stands in for the FOREIGN KEY ... ON DELETE SET NULL constraints the displays
		// table no longer declares (they broke table creation on MyISAM installs).
		add_action( 'betterlinks/link/after_delete', array( '\BetterLinksPro\Migration', 'detach_product_display_links' ) );

		// Elementor "Promo Card" widget — the Elementor counterpart to the block.
		add_action( 'elementor/elements/categories_registered', array( $self, 'register_elementor_category' ) );
		add_action( 'elementor/widgets/register', array( $self, 'register_elementor_widget' ) );
		add_action( 'elementor/editor/after_enqueue_styles', array( $self, 'enqueue_elementor_icon' ) );
		add_action( 'elementor/editor/after_enqueue_scripts', array( $self, 'enqueue_elementor_editor_script' ) );
	}

	/**
	 * When the "Create New" entry in the Promo Card / Card Group select is chosen,
	 * open the Promo Cards admin screen in a new tab and reset the select (so the
	 * sentinel value is never saved). Elementor selects can't redirect natively, so
	 * this small delegated listener watches the two controls by their data-setting.
	 */
	public function enqueue_elementor_editor_script() {
		$url    = admin_url( 'admin.php?page=' . self::MENU_SLUG );
		$create = ElementorWidget::CREATE_NEW;

		$js = "( function( $ ) {"
			. "$( document ).on( 'change', 'select[data-setting=\"display_id\"], select[data-setting=\"group_id\"]', function() {"
			. "if ( this.value === '" . esc_js( $create ) . "' ) {"
			. "window.open( '" . esc_url_raw( $url ) . "', '_blank', 'noopener' );"
			. "this.value = '';"
			. "this.dispatchEvent( new Event( 'change', { bubbles: true } ) );"
			. "}"
			. "} );"
			. "}( jQuery ) );";

		wp_add_inline_script( 'elementor-editor', $js );
	}

	/**
	 * Style the Promo Card widget's tile in the Elementor panel:
	 *  - `.btl-promo-card-icon` paints the custom Promo Card SVG as the centre icon.
	 *  - a small BetterLinks mark is dropped into the tile's top-right corner so users
	 *    recognise it at a glance.
	 *
	 * Both classes come from ElementorWidget::get_icon() and only exist on the panel
	 * tile, so the `:has()` selector targets the tile without ever matching the canvas
	 * element. The corner mark uses a CSS mask so it tints to the tile's own colour.
	 */
	public function enqueue_elementor_icon() {
		$icon_uri = BETTERLINKS_PRO_ASSETS_URI . 'images/promo-card-icon.svg';
		$mark_uri = BETTERLINKS_PRO_ASSETS_URI . 'images/betterlinks-mark.svg';
		$mask     = "url('" . esc_url( $mark_uri ) . "') no-repeat center / contain";

		$css  = ".btl-promo-card-icon{display:inline-block;width:28px;height:28px;background:url('"
			. esc_url( $icon_uri ) . "') no-repeat center / contain;}";
		$css .= '.elementor-element:has(.btl-promo-card-widget){position:relative;}';
		$css .= '.elementor-element:has(.btl-promo-card-widget)::after{content:"";position:absolute;top:8px;right:8px;'
			. 'width:15px;height:15px;background-color:currentColor;opacity:.75;pointer-events:none;'
			. '-webkit-mask:' . $mask . ';mask:' . $mask . ';}';

		wp_add_inline_style( 'elementor-editor', $css );
	}

	/**
	 * Add a dedicated "BetterLinks" category to the Elementor widget panel.
	 *
	 * @param \Elementor\Elements_Manager $elements_manager
	 */
	public function register_elementor_category( $elements_manager ) {
		$elements_manager->add_category(
			'betterlinks',
			array(
				'title' => __( 'BetterLinks', 'betterlinks-pro' ),
				'icon'  => 'fa fa-plug',
			)
		);
	}

	/**
	 * Register the Promo Card widget with Elementor.
	 *
	 * @param \Elementor\Widgets_Manager $widgets_manager
	 */
	public function register_elementor_widget( $widgets_manager ) {
		if ( ! class_exists( '\\Elementor\\Widget_Base' ) ) {
			return;
		}
		$widget = new ElementorWidget();
		// `register()` is Elementor 3.5+; fall back to the legacy method otherwise.
		if ( method_exists( $widgets_manager, 'register' ) ) {
			$widgets_manager->register( $widget );
		} else {
			$widgets_manager->register_widget_type( $widget );
		}
	}

	/**
	 * Register (not enqueue) the card stylesheet so it can be attached on demand.
	 */
	public function register_frontend_style() {
		if ( wp_style_is( 'betterlinks-product-display', 'registered' ) ) {
			return;
		}
		wp_register_style(
			'betterlinks-product-display',
			BETTERLINKS_PRO_ASSETS_URI . 'css/betterlinks-product-display.css',
			array(),
			BETTERLINKS_PRO_VERSION
		);
	}

	/**
	 * Enqueue the card stylesheet on singular views that embed a display.
	 */
	public function maybe_enqueue_frontend_style() {
		if ( ! is_singular() ) {
			return;
		}
		$post = get_post();
		if ( ! $post ) {
			return;
		}
		$content = (string) $post->post_content;
		if ( has_shortcode( $content, Shortcode::TAG ) || has_block( Block::NAME, $post ) ) {
			wp_enqueue_style( 'betterlinks-product-display' );
		}
	}

	/**
	 * Add the "Product Display" submenu right after "Manage Links".
	 *
	 * @param array $items
	 * @return array
	 */
	public function register_menu_item( $items ) {
		// Gate by the "Promo Cards" Role Management capability. Do this here (not
		// only in Admin::add_new_menu_item) because this callback also runs on the
		// same filter and would otherwise re-add the menu a role was denied.
		$user            = wp_get_current_user();
		$user_permission = json_decode( get_option( BETTERLINKS_PRO_ROLE_PERMISSON_OPTION_NAME, '{}' ), true );
		if ( ! \BetterLinksPro\Helper::current_user_can_do( 'managePromoCards', $user, $user_permission ) ) {
			// Ensure it's gone even if another callback (or the free plugin) added it.
			unset( $items[ self::MENU_SLUG ] );
			return $items;
		}

		// Permitted: keep/register the item with the custom capability so a granted
		// non-admin role (which lacks manage_options) can still reach the page.
		if ( isset( $items[ self::MENU_SLUG ] ) ) {
			$items[ self::MENU_SLUG ]['capability'] = 'betterlinks_manage_promo_cards';
			return $items;
		}

		// Only INTRODUCE the menu item when the free plugin can render the Promo Cards
		// screen in its admin nav. Older free hardcodes a fixed React submenu with no
		// Promo Cards entry, so adding the item here would surface it in WordPress's
		// hover flyout (via add_submenu_page) while it never appears once inside the
		// app — a dead menu. The redesigned free that renders it exposes
		// Helper::is_promo_cards_enabled() (and registers this slug itself, handled by
		// the branch above); its absence marks the older free, so we don't add it.
		if ( ! method_exists( '\BetterLinks\Helper', 'is_promo_cards_enabled' ) ) {
			return $items;
		}

		$entry = array(
			self::MENU_SLUG => array(
				'title'      => __( 'Promo Cards', 'betterlinks-pro' ),
				'capability' => 'betterlinks_manage_promo_cards',
			),
		);

		// Insert after the first item (Manage Links) to keep a logical order.
		$before = array_slice( $items, 0, 1, true );
		$after  = array_slice( $items, 1, null, true );

		return $before + $entry + $after;
	}
}
