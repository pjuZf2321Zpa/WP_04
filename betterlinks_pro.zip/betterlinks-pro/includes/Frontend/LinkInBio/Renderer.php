<?php
namespace BetterLinksPro\Frontend\LinkInBio;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use BetterLinksPro\Traits\BioPages;

/**
 * Renders the public "Link in Bio" page as a standalone HTML document.
 *
 * The visual model (style presets, layouts, button styles/shapes, fonts, icons) is
 * shared with the React builder/preview via {@see Templates}. All output is escaped.
 */
class Renderer {

	use BioPages;

	/**
	 * Render the full page for a (already-loaded) bio row and stop.
	 *
	 * @param array $bio Cast bio row (config is an array).
	 * @return void
	 */
	public static function render( $bio ) {
		$config  = isset( $bio['config'] ) && is_array( $bio['config'] ) ? $bio['config'] : array();
		$config  = wp_parse_args( $config, Templates::default_config() );
		$profile = wp_parse_args( isset( $config['profile'] ) ? (array) $config['profile'] : array(), Templates::default_config()['profile'] );

		$theme   = self::resolve_theme( $config );
		$css_vars = self::css_vars( $theme, $config );
		$font     = self::resolve_font( $config );

		$layout    = in_array( $config['layout'], Templates::layouts(), true ) ? $config['layout'] : 'classic';
		$btn_style = in_array( $config['buttons']['style'], Templates::button_styles(), true ) ? $config['buttons']['style'] : 'solid';
		$btn_shape = in_array( $config['buttons']['shape'], Templates::button_shapes(), true ) ? $config['buttons']['shape'] : 'rounded';

		$title      = $profile['title'] ? $profile['title'] : $bio['title'];
		$seo        = isset( $config['seo'] ) ? (array) $config['seo'] : array();
		$meta_title = ! empty( $seo['meta_title'] ) ? $seo['meta_title'] : $title;
		$meta_desc  = ! empty( $seo['meta_description'] ) ? $seo['meta_description'] : ( ! empty( $profile['bio'] ) ? $profile['bio'] : '' );
		$meta_image = ! empty( $seo['meta_image_url'] ) ? $seo['meta_image_url'] : ( ! empty( $profile['avatar_url'] ) ? $profile['avatar_url'] : '' );

		// Send a clean, full-page response.
		if ( ! headers_sent() ) {
			status_header( 200 );
			nocache_headers();
			header( 'Content-Type: text/html; charset=' . get_bloginfo( 'charset' ) );
		}

		$body_classes = array(
			'btl-bio',
			'btl-bio--layout-' . $layout,
			'btl-bio--btn-' . $btn_style,
			'btl-bio--shape-' . $btn_shape,
		);

		?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php echo esc_attr( get_bloginfo( 'charset' ) ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title><?php echo esc_html( $meta_title ); ?></title>
	<meta property="og:type" content="profile" />
	<meta property="og:title" content="<?php echo esc_attr( $meta_title ); ?>" />
	<?php if ( '' !== $meta_desc ) : ?>
		<meta name="description" content="<?php echo esc_attr( wp_strip_all_tags( $meta_desc ) ); ?>" />
		<meta property="og:description" content="<?php echo esc_attr( wp_strip_all_tags( $meta_desc ) ); ?>" />
	<?php endif; ?>
	<?php if ( '' !== $meta_image ) : ?>
		<meta property="og:image" content="<?php echo esc_url( $meta_image ); ?>" />
		<meta name="twitter:card" content="summary_large_image" />
	<?php endif; ?>
	<link rel="canonical" href="<?php echo esc_url( self::bio_public_url( $bio['slug'] ) ); ?>" />
	<?php self::print_font_link( $font ); ?>
	<link rel="stylesheet" href="<?php echo esc_url( BETTERLINKS_PRO_ASSETS_URI . 'css/betterlinks-link-in-bio-public.css' ); ?>?ver=<?php echo esc_attr( BETTERLINKS_PRO_VERSION ); ?>" />
	<style><?php echo self::inline_style( $css_vars, $font ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped tokens. ?></style>
	<?php do_action( 'betterlinks/link_in_bio/head', $bio ); ?>
</head>
<body class="<?php echo esc_attr( implode( ' ', $body_classes ) ); ?>">
	<main class="btl-bio__page">
		<div class="btl-bio__card">
			<?php self::render_header( $profile, $layout ); ?>
			<?php self::render_icons( $config ); ?>
			<?php self::render_links( $config ); ?>
			<?php self::render_footer( $config ); ?>
			<?php if ( self::show_credit( $config, $bio ) ) : ?>
				<div class="btl-bio__brand">
					<a href="https://betterlinks.io/?utm_source=bio_page&amp;utm_medium=made_with" target="_blank" rel="noopener nofollow"><?php esc_html_e( 'Made with BetterLinks', 'betterlinks-pro' ); ?></a>
				</div>
			<?php endif; ?>
		</div>
	</main>
	<?php do_action( 'betterlinks/link_in_bio/footer', $bio ); ?>
</body>
</html>
		<?php
	}

	/**
	 * Should the "Made with BetterLinks" credit appear on this page?
	 *
	 * Per-page setting, edited under Footer in the builder. A page saved before
	 * the setting existed has no `branding` key, and that absence means "show" —
	 * upgrading must never quietly strip attribution from a live page.
	 *
	 * @param array $config Sanitized bio config.
	 * @param array $bio    The bio row, for filter consumers.
	 * @return bool
	 */
	private static function show_credit( $config, $bio ) {
		$show = true;
		if ( isset( $config['branding']['show_credit'] ) ) {
			$show = (bool) $config['branding']['show_credit'];
		}

		/**
		 * Filters whether the BetterLinks credit renders on a bio page.
		 *
		 * Lets agencies white-label every page at once without editing each one.
		 *
		 * @param bool  $show
		 * @param array $bio  The bio row.
		 */
		return (bool) apply_filters( 'betterlinks/link_in_bio/show_credit', $show, $bio );
	}

	/**
	 * Header block (avatar, title, handle, bio) — layout-aware.
	 *
	 * @param array  $profile
	 * @param string $layout
	 * @return void
	 */
	private static function render_header( $profile, $layout ) {
		$has_avatar = ! empty( $profile['avatar_url'] );
		?>
		<header class="btl-bio__header">
			<?php if ( $has_avatar ) : ?>
				<div class="btl-bio__avatar">
					<img src="<?php echo esc_url( $profile['avatar_url'] ); ?>" alt="<?php echo esc_attr( $profile['title'] ); ?>" />
				</div>
			<?php endif; ?>
			<?php if ( ! empty( $profile['title'] ) ) : ?>
				<h1 class="btl-bio__title"><?php echo esc_html( $profile['title'] ); ?></h1>
			<?php endif; ?>
			<?php if ( ! empty( $profile['bio'] ) ) : ?>
				<div class="btl-bio__desc"><?php echo wp_kses_post( $profile['bio'] ); ?></div>
			<?php endif; ?>
		</header>
		<?php
	}

	/**
	 * Social icon row.
	 *
	 * @param array $config
	 * @return void
	 */
	private static function render_icons( $config ) {
		if ( empty( $config['icons'] ) || ! is_array( $config['icons'] ) ) {
			return;
		}
		$icons = array_filter(
			$config['icons'],
			function ( $i ) {
				return ! empty( $i['url'] );
			}
		);
		if ( empty( $icons ) ) {
			return;
		}
		echo '<nav class="btl-bio__icons" aria-label="' . esc_attr__( 'Social links', 'betterlinks-pro' ) . '">';
		foreach ( $icons as $icon ) {
			$type  = isset( $icon['type'] ) ? $icon['type'] : 'link';
			$href  = self::entry_href( $icon );
			$label = isset( $icon['type'] ) ? ucfirst( $icon['type'] ) : __( 'Link', 'betterlinks-pro' );
			echo '<a class="btl-bio__icon" href="' . esc_url( $href ) . '" target="_blank" rel="noopener" aria-label="' . esc_attr( $label ) . '">';
			// SVG markup is from a controlled internal map.
			echo Templates::icon_svg( $type ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '</a>';
		}
		echo '</nav>';
	}

	/**
	 * Main link buttons.
	 *
	 * @param array $config
	 * @return void
	 */
	private static function render_links( $config ) {
		if ( empty( $config['links'] ) || ! is_array( $config['links'] ) ) {
			return;
		}
		$links = array_filter(
			$config['links'],
			function ( $l ) {
				return ! empty( $l['url'] ) && ! empty( $l['label'] );
			}
		);
		if ( empty( $links ) ) {
			return;
		}

		$buttons   = isset( $config['buttons'] ) ? (array) $config['buttons'] : array();
		$btn_style = ( isset( $buttons['style'] ) && in_array( $buttons['style'], Templates::button_styles(), true ) ) ? $buttons['style'] : 'solid';
		$btn_anim  = ( isset( $buttons['animation'] ) && in_array( $buttons['animation'], Templates::button_animations(), true ) ) ? $buttons['animation'] : 'none';
		$btn_shape = ( isset( $buttons['shape'] ) && in_array( $buttons['shape'], Templates::button_shapes(), true ) ) ? $buttons['shape'] : 'rounded';
		$btn_class = sprintf( 'btl-bio__btn btl-bio__btn--%s btl-bio__btn--anim-%s btl-bio__btn--shape-%s', $btn_style, $btn_anim, $btn_shape );

		// Optional custom corner radius (overrides the shape's radius for non-special shapes).
		$btn_radius_style = '';
		if ( isset( $buttons['radius'] ) && '' !== $buttons['radius'] && null !== $buttons['radius'] && ! in_array( $btn_shape, array( 'leaf', 'bevel' ), true ) ) {
			$btn_radius_style = ' style="border-radius:' . absint( $buttons['radius'] ) . 'px"';
		}

		echo '<div class="btl-bio__links">';
		foreach ( $links as $link ) {
			$href = self::entry_href( $link );
			$icon = isset( $link['icon'] ) ? $link['icon'] : '';
			echo '<a class="' . esc_attr( $btn_class ) . '"' . $btn_radius_style . ' href="' . esc_url( $href ) . '" target="_blank" rel="noopener">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- radius is absint.
			if ( $icon ) {
				echo '<span class="btl-bio__btn-icon">' . Templates::icon_svg( $icon ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			echo '<span class="btl-bio__btn-label">' . esc_html( $link['label'] ) . '</span>';
			echo '</a>';
		}
		echo '</div>';
	}

	/**
	 * Footer legal/extra links.
	 *
	 * @param array $config
	 * @return void
	 */
	private static function render_footer( $config ) {
		if ( empty( $config['footer'] ) || ! is_array( $config['footer'] ) ) {
			return;
		}
		$items = array_filter(
			$config['footer'],
			function ( $f ) {
				return ! empty( $f['label'] );
			}
		);
		if ( empty( $items ) ) {
			return;
		}
		echo '<footer class="btl-bio__footer">';
		foreach ( $items as $item ) {
			$url = ! empty( $item['url'] ) ? $item['url'] : '#';
			echo '<a class="btl-bio__footer-link" href="' . esc_url( $url ) . '" target="_blank" rel="noopener nofollow">' . esc_html( $item['label'] ) . '</a>';
		}
		echo '</footer>';
	}

	/**
	 * Resolve the click destination for an entry: the tracked short URL when the
	 * entry opts into tracking and has a link, else the raw URL.
	 *
	 * @param array $entry
	 * @return string
	 */
	private static function entry_href( $entry ) {
		if ( ! empty( $entry['track'] ) && ! empty( $entry['link_id'] ) ) {
			$short = self::short_url_by_link_id( (int) $entry['link_id'] );
			if ( $short ) {
				return home_url( '/' . ltrim( $short, '/' ) );
			}
		}
		return isset( $entry['url'] ) ? $entry['url'] : '#';
	}

	/**
	 * Look up a link's short_url by ID.
	 *
	 * @param int $link_id
	 * @return string
	 */
	private static function short_url_by_link_id( $link_id ) {
		global $wpdb;
		$table = $wpdb->prefix . 'betterlinks';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$short = $wpdb->get_var( $wpdb->prepare( "SELECT short_url FROM {$table} WHERE ID = %d", absint( $link_id ) ) );
		return $short ? (string) $short : '';
	}

	/**
	 * Resolve the effective theme tokens (preset, with explicit overrides on top).
	 *
	 * @param array $config
	 * @return array
	 */
	private static function resolve_theme( $config ) {
		$presets = Templates::style_presets();
		$key     = isset( $config['style'] ) ? $config['style'] : 'light';
		$preset  = isset( $presets[ $key ] ) ? $presets[ $key ] : $presets['light'];

		$colors = isset( $config['colors'] ) ? (array) $config['colors'] : array();
		$theme  = array(
			'text'        => $preset['text'],
			'title'       => ! empty( $colors['title'] ) ? $colors['title'] : $preset['text'],
			'description' => ! empty( $colors['description'] ) ? $colors['description'] : $preset['text'],
			'button'      => $preset['button'],
		);
		return $theme;
	}

	/**
	 * Build the CSS custom properties for the page from config + theme.
	 *
	 * @param array $theme
	 * @param array $config
	 * @return array
	 */
	private static function css_vars( $theme, $config ) {
		$bg = isset( $config['background'] ) ? (array) $config['background'] : array();

		// Background: explicit background config wins; otherwise fall back to preset.
		$presets   = Templates::style_presets();
		$style_key = isset( $config['style'] ) ? $config['style'] : 'light';
		$preset_bg = isset( $presets[ $style_key ]['background'] ) ? $presets[ $style_key ]['background'] : array(
			'type'  => 'solid',
			'color' => '#f7f7f5',
		);

		$effective_bg = ! empty( $bg['type'] ) ? $bg : $preset_bg;
		$bg_css       = self::background_css( $effective_bg );
		$bg_solid     = self::background_solid( $effective_bg );

		$buttons   = isset( $config['buttons'] ) ? (array) $config['buttons'] : array();
		$btn_color = ! empty( $buttons['color'] ) ? $buttons['color'] : $theme['button']['color'];
		$font_set  = ( isset( $buttons['fontColor'] ) && '' !== $buttons['fontColor'] ) ? $buttons['fontColor'] : '';
		// Text on a filled button auto-contrasts when no font colour is chosen.
		$btn_font  = $font_set ? $font_set : self::contrast_color( $btn_color );
		// Text on a non-filled button: the chosen font colour, else the accent.
		$btn_otext = $font_set ? $font_set : $btn_color;

		return array(
			'--btl-bio-bg'         => $bg_css,
			'--btl-bio-bg-solid'   => $bg_solid,
			'--btl-bio-text'       => $theme['text'],
			'--btl-bio-title'      => $theme['title'],
			'--btl-bio-desc'       => $theme['description'],
			'--btl-bio-btn-bg'     => $btn_color,
			'--btl-bio-btn-color'  => $btn_font,
			'--btl-bio-btn-otext'  => $btn_otext,
		);
	}

	/**
	 * Black or white for readable text over a hex background colour.
	 *
	 * @param string $hex
	 * @return string
	 */
	private static function contrast_color( $hex ) {
		$hex = ltrim( (string) $hex, '#' );
		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		if ( strlen( $hex ) < 6 ) {
			return '#ffffff';
		}
		$r   = hexdec( substr( $hex, 0, 2 ) );
		$g   = hexdec( substr( $hex, 2, 2 ) );
		$b   = hexdec( substr( $hex, 4, 2 ) );
		$lum = ( 0.299 * $r + 0.587 * $g + 0.114 * $b ) / 255;
		return $lum > 0.6 ? '#111111' : '#ffffff';
	}

	/**
	 * A single representative solid colour for the background, used to blend the
	 * Hero/Wave cover smoothly into the page.
	 *
	 * @param array $bg
	 * @return string
	 */
	private static function background_solid( $bg ) {
		$type = isset( $bg['type'] ) ? $bg['type'] : 'solid';
		if ( 'gradient' === $type && ! empty( $bg['gradient']['from'] ) ) {
			return self::clean_color( $bg['gradient']['from'] );
		}
		if ( 'solid' === $type && ! empty( $bg['color'] ) ) {
			return self::clean_color( $bg['color'] );
		}
		// Image (or unknown): a neutral dark blend reads well over photos.
		return ! empty( $bg['color'] ) ? self::clean_color( $bg['color'] ) : '#11131a';
	}

	/**
	 * Compute a CSS background value from a background config block.
	 *
	 * @param array $bg
	 * @return string
	 */
	private static function background_css( $bg ) {
		$type = isset( $bg['type'] ) ? $bg['type'] : 'solid';
		if ( 'gradient' === $type && ! empty( $bg['gradient'] ) ) {
			$g     = $bg['gradient'];
			$from  = isset( $g['from'] ) ? $g['from'] : '#8a8dff';
			$to    = isset( $g['to'] ) ? $g['to'] : '#e0c3fc';
			$angle = isset( $g['angle'] ) ? (int) $g['angle'] : 160;
			return sprintf( 'linear-gradient(%ddeg, %s, %s)', $angle, self::clean_color( $from ), self::clean_color( $to ) );
		}
		if ( 'image' === $type && ! empty( $bg['image_url'] ) ) {
			return sprintf( "center / cover no-repeat url('%s')", esc_url_raw( $bg['image_url'] ) );
		}
		$color = isset( $bg['color'] ) ? $bg['color'] : '#f7f7f5';
		return self::clean_color( $color );
	}

	/**
	 * Sanitize a colour/CSS value to a safe inline token.
	 *
	 * @param string $value
	 * @return string
	 */
	private static function clean_color( $value ) {
		$value = (string) $value;
		// Allow hex, rgb(a), hsl(a) and basic keywords; strip anything risky.
		$value = preg_replace( '/[^a-zA-Z0-9#%,.\s()\-]/', '', $value );
		return trim( $value );
	}

	/**
	 * Resolve the chosen font (validated against the allowed list).
	 *
	 * @param array $config
	 * @return string
	 */
	private static function resolve_font( $config ) {
		$font = isset( $config['font'] ) ? $config['font'] : 'Inter';
		return in_array( $font, Templates::fonts(), true ) ? $font : 'Inter';
	}

	/**
	 * Output the Google Fonts <link> for the chosen font.
	 *
	 * @param string $font
	 * @return void
	 */
	private static function print_font_link( $font ) {
		// Google expects spaces encoded as "+" in the family name.
		$family = str_replace( ' ', '+', $font );
		$href   = sprintf( 'https://fonts.googleapis.com/css2?family=%s:wght@400;500;600;700&display=swap', $family );
		echo '<link rel="preconnect" href="https://fonts.googleapis.com" />';
		echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />';
		echo '<link rel="stylesheet" href="' . esc_url( $href ) . '" />';
	}

	/**
	 * Build the inline :root style block.
	 *
	 * @param array  $vars
	 * @param string $font
	 * @return string
	 */
	private static function inline_style( $vars, $font ) {
		$lines = array();
		foreach ( $vars as $name => $value ) {
			$lines[] = sprintf( '%s:%s;', $name, self::clean_color( $value ) );
		}
		$lines[] = sprintf( "--btl-bio-font:'%s', system-ui, sans-serif;", esc_attr( $font ) );
		return ':root{' . implode( '', $lines ) . '}';
	}
}
