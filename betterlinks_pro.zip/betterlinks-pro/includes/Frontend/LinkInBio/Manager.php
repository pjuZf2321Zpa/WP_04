<?php
namespace BetterLinksPro\Frontend\LinkInBio;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use BetterLinksPro\Traits\BioPages;

/**
 * Bootstraps the "Link in Bio" feature.
 *
 * Responsibilities:
 *  - Register the admin submenu item (the page itself is a React app mounted by the
 *    BetterLinks SPA — see dev_betterlinks/pages/LinkInBio).
 *  - Seed + protect the dedicated "Link in Bio" link category so it behaves like the
 *    default "Uncategorized" term (cannot be deleted/renamed).
 *  - Serve the public bio page at `{home}/{prefix}/{slug}`.
 */
class Manager {

	use BioPages;

	// Admin page slug — kept in sync with the Free `Helper::get_menu_items()`
	// key. This is the menu/URL slug only; CATEGORY_SLUG below drives the PUBLIC
	// bio-page URLs and the term rewrite, so it must NOT change.
	const MENU_SLUG     = 'betterlinks-bio-links';
	const CATEGORY_SLUG = 'link-in-bio';
	const CATEGORY_NAME = 'Link in Bio';
	const OPTION_CAT_ID = 'betterlinks_pro_bio_category_id';

	public static function init() {
		$self = new self();
		add_filter( 'betterlinks/helper/menu_items', array( $self, 'register_menu_item' ) );
		// Protect the bio category exactly like "Uncategorized".
		add_filter( 'betterlinks/protected_term_ids', array( __CLASS__, 'protect_category' ) );
		// ...and keep it off Manage Links unless the admin opts in via
		// Settings -> Feature Modules -> Bio Links -> Configure.
		add_filter( 'betterlinks/dashboard_hidden_term_ids', array( __CLASS__, 'maybe_hide_category' ), 10, 2 );
		// Site-wide branding switch (Settings -> Feature Modules -> Bio Links ->
		// Configure). Runs late so a site's own `show_credit` filter still wins.
		add_filter( 'betterlinks/link_in_bio/show_credit', array( __CLASS__, 'maybe_hide_credit' ), 5 );
		// Public bio page: parse the request after the free redirect (priority 0) has
		// had its chance, mirroring how BetterLinks resolves slugs manually on `init`.
		// Also serve HEAD (uptime monitors / link-preview crawlers / CDN probes hit
		// HEAD first): maybe_render_public_page() answers HEAD with 200 + headers and
		// no body, and without counting a view.
		if ( ! is_admin() && isset( $_SERVER['REQUEST_METHOD'] ) && in_array( strtoupper( $_SERVER['REQUEST_METHOD'] ), array( 'GET', 'HEAD' ), true ) ) {
			add_action( 'init', array( $self, 'maybe_render_public_page' ), 1 );
		}
	}

	/**
	 * Register the "Bio Links" submenu item.
	 *
	 * @param array $items
	 * @return array
	 */
	public function register_menu_item( $items ) {
		// Gate by the "Bio Links" Role Management capability. Do this here (not only
		// in Admin::add_new_menu_item) because this callback also runs on the same
		// filter and would otherwise re-add the menu a role was denied.
		$user            = wp_get_current_user();
		$user_permission = json_decode( get_option( BETTERLINKS_PRO_ROLE_PERMISSON_OPTION_NAME, '{}' ), true );
		if ( ! \BetterLinksPro\Helper::current_user_can_do( 'manageBioLinks', $user, $user_permission ) ) {
			// Ensure it's gone even if another callback (or the free plugin) added it.
			unset( $items[ self::MENU_SLUG ] );
			return $items;
		}

		// Permitted: keep/register the item with the custom capability so a granted
		// non-admin role (which lacks manage_options) can still reach the page.
		if ( isset( $items[ self::MENU_SLUG ] ) ) {
			$items[ self::MENU_SLUG ]['capability'] = 'betterlinks_manage_bio_links';
			return $items;
		}

		// Only INTRODUCE the menu item when the free plugin can render the Bio Links
		// screen in its admin nav. Older free hardcodes a fixed React submenu with no
		// Bio Links entry, so adding the item here would surface it in WordPress's
		// hover flyout (via add_submenu_page) while it never appears once inside the
		// app — a dead menu. The redesigned free that renders it exposes
		// Helper::is_bio_links_enabled() (and registers this slug itself, handled by
		// the branch above); its absence marks the older free, so we don't add it.
		if ( ! method_exists( '\BetterLinks\Helper', 'is_bio_links_enabled' ) ) {
			return $items;
		}

		$entry = array(
			self::MENU_SLUG => array(
				'title'      => __( 'Bio Links', 'betterlinks-pro' ),
				'capability' => 'betterlinks_manage_bio_links',
			),
		);

		return $items + $entry;
	}

	/**
	 * Ensure the protected "Link in Bio" category term exists; store its ID.
	 *
	 * @return int The category term ID (0 if it could not be created).
	 */
	public static function maybe_seed_category() {
		$id = (int) get_option( self::OPTION_CAT_ID, 0 );
		if ( $id > 0 ) {
			return $id;
		}
		if ( ! class_exists( '\BetterLinks\Helper' ) ) {
			return 0;
		}

		$term_id = \BetterLinks\Helper::insert_term(
			array(
				'term_name' => self::CATEGORY_NAME,
				'term_slug' => self::CATEGORY_SLUG,
				'term_type' => 'category',
			)
		);

		$term_id = (int) $term_id;
		if ( $term_id > 0 ) {
			update_option( self::OPTION_CAT_ID, $term_id );
		}
		return $term_id;
	}

	/**
	 * The bio category ID (seeds on demand so it is always available to the SPA/API).
	 *
	 * @return int
	 */
	public static function get_category_id() {
		$id = (int) get_option( self::OPTION_CAT_ID, 0 );
		if ( $id <= 0 ) {
			$id = self::maybe_seed_category();
		}
		return $id;
	}

	/**
	 * Add the bio category to the list of protected (non-deletable/non-editable) terms.
	 *
	 * @param array $ids
	 * @return array
	 */
	/**
	 * Hide the bio category from Manage Links unless the admin asked for it.
	 *
	 * The category is machinery: bio pages file their tracked links into it, so
	 * on a busy site it is a column of links nobody filed by hand. Default is
	 * hidden; `show_bio_links_category` (Settings -> Feature Modules -> Bio
	 * Links -> Configure) brings it back.
	 *
	 * @param array $ids      Term IDs already marked hidden.
	 * @param array $settings Decoded BetterLinks settings.
	 * @return array
	 */
	public static function maybe_hide_category( $ids, $settings = array() ) {
		if ( ! empty( $settings['show_bio_links_category'] ) ) {
			return $ids;
		}
		$cat_id = (int) get_option( self::OPTION_CAT_ID, 0 );
		if ( $cat_id > 0 && ! in_array( $cat_id, (array) $ids, true ) ) {
			$ids[] = $cat_id;
		}
		return $ids;
	}

	/**
	 * Is the site-wide "Made with BetterLinks" credit switched on?
	 *
	 * `show_bio_links_branding` lives in the free plugin's settings so the
	 * Configure panel can write it alongside the other bio options. A site that
	 * predates the setting has no key at all, and absent means "show" — an
	 * upgrade must never quietly strip attribution, the same rule
	 * `Renderer::show_credit()` applies to the per-page setting.
	 *
	 * @return bool
	 */
	public static function is_branding_enabled() {
		if ( ! defined( 'BETTERLINKS_LINKS_OPTION_NAME' ) ) {
			return true;
		}
		$settings = get_option( BETTERLINKS_LINKS_OPTION_NAME );
		if ( is_string( $settings ) ) {
			$settings = json_decode( $settings, true );
		}
		if ( ! is_array( $settings ) || ! array_key_exists( 'show_bio_links_branding', $settings ) ) {
			return true;
		}
		return (bool) $settings['show_bio_links_branding'];
	}

	/**
	 * Apply the site-wide branding switch to a page's credit.
	 *
	 * Only ever takes the credit away: with branding on, the per-page "Show
	 * credit" toggle still decides.
	 *
	 * @param bool $show
	 * @return bool
	 */
	public static function maybe_hide_credit( $show ) {
		return self::is_branding_enabled() ? $show : false;
	}

	public static function protect_category( $ids ) {
		$cat_id = (int) get_option( self::OPTION_CAT_ID, 0 );
		if ( $cat_id > 0 && ! in_array( $cat_id, (array) $ids, true ) ) {
			$ids[] = $cat_id;
		}
		return $ids;
	}

	/**
	 * Configured short-link prefix (e.g. "go").
	 *
	 * @return string
	 */
	public static function get_prefix() {
		return self::bio_prefix();
	}

	/**
	 * Base public URL for bio pages, e.g. `https://site.test/go`.
	 *
	 * @return string
	 */
	public static function get_public_base_url() {
		$prefix = self::bio_prefix();
		return $prefix ? home_url( '/' . $prefix ) : home_url( '/' );
	}

	/**
	 * Match the current request to a published bio page and render it.
	 *
	 * @return void
	 */
	public function maybe_render_public_page() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- public page request, read-only.
		$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		if ( '' === $request_uri ) {
			return;
		}
		$request_uri = stripslashes( rawurldecode( $request_uri ) );
		$home_path   = wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		$request_uri = substr( $request_uri, strlen( $home_path ) );
		$request_uri = explode( '?', $request_uri, 2 );
		$path        = trim( current( $request_uri ), '/' );
		if ( '' === $path ) {
			return;
		}

		$prefix = self::bio_prefix();
		if ( $prefix ) {
			$needle = $prefix . '/';
			if ( 0 !== strpos( $path, $needle ) ) {
				return; // Not under our prefix; let WordPress handle it.
			}
			$slug = substr( $path, strlen( $needle ) );
		} else {
			$slug = $path;
		}

		// Only single-segment slugs are bio handles.
		if ( '' === $slug || false !== strpos( $slug, '/' ) ) {
			return;
		}

		$bio = self::get_published_bio_by_slug( $slug );
		if ( null === $bio ) {
			return;
		}

		// HEAD: the bio page exists, so answer 200 with the same headers a GET would
		// send, but emit no body and don't count a view — HEAD is used by monitors
		// and preview crawlers, not real visitors. (Without this the request would
		// fall through to a WordPress 404 and tools flag the page as broken.)
		if ( isset( $_SERVER['REQUEST_METHOD'] ) && 'HEAD' === strtoupper( $_SERVER['REQUEST_METHOD'] ) ) { // phpcs:ignore
			status_header( 200 );
			if ( ! headers_sent() ) {
				header( 'Content-Type: text/html; charset=' . get_option( 'blog_charset' ) );
			}
			exit;
		}

		self::increment_bio_views( $bio['ID'] );
		Renderer::render( $bio );
		exit;
	}
}
