<?php
namespace BetterLinksPro\Frontend\LinkInBio;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use BetterLinksPro\Traits\BioPages;

/**
 * Creates/updates/deletes the real BetterLinks short links used to TRACK clicks on
 * a bio page's links and icons. Reuses BetterLinks' own insert/update pipeline so
 * the links.json cache the redirect engine relies on stays in sync, and files every
 * link under the protected "Link in Bio" category.
 *
 * A bio "entry" (icon or link) opts into tracking via its `track` flag; when on we
 * keep a short link whose target is the entry URL and stash its ID back on the entry
 * as `link_id`. The public renderer then points the entry at the short URL.
 */
class LinkFactory {

	use \BetterLinks\Traits\ArgumentSchema;
	use \BetterLinks\Traits\Links;
	use BioPages;

	/**
	 * Reconcile every entry in a bio config with its tracked short link.
	 *
	 * - track on + no link  -> create a short link
	 * - track on + has link -> update target/title
	 * - track off + has link -> delete the short link, clear link_id
	 *
	 * @param array  $config    The bio config (icons/links arrays mutated in place).
	 * @param string $bio_title Bio page title (used to name links).
	 * @param string $bio_slug  Bio slug (used to derive readable short slugs).
	 * @return array The updated config with link_id values persisted.
	 */
	public static function sync_config_links( $config, $bio_title, $bio_slug ) {
		if ( ! class_exists( '\BetterLinks\Helper' ) ) {
			return $config;
		}

		$factory  = new self();
		$cat_id   = Manager::get_category_id();
		$prefix   = self::bio_prefix();
		$bio_slug = self::sanitize_bio_slug( $bio_slug );

		foreach ( array( 'icons', 'links' ) as $group ) {
			if ( empty( $config[ $group ] ) || ! is_array( $config[ $group ] ) ) {
				continue;
			}

			foreach ( $config[ $group ] as $index => $entry ) {
				$track   = ! empty( $entry['track'] );
				$url     = isset( $entry['url'] ) ? trim( (string) $entry['url'] ) : '';
				$link_id = isset( $entry['link_id'] ) ? absint( $entry['link_id'] ) : 0;
				$label   = '';
				if ( isset( $entry['label'] ) && '' !== $entry['label'] ) {
					$label = $entry['label'];
				} elseif ( isset( $entry['type'] ) ) {
					$label = $entry['type'];
				}

				// Tracking off (or no usable URL): tear down any existing link.
				if ( ! $track || '' === $url || ! wp_http_validate_url( esc_url_raw( $url ) ) ) {
					if ( $link_id ) {
						$factory->remove_link( $link_id );
					}
					$config[ $group ][ $index ]['link_id'] = 0;
					continue;
				}

				$title = trim( $bio_title . ' — ' . $label );

				if ( $link_id && self::link_exists( $link_id ) ) {
					$factory->modify_link( $link_id, $url, $title, $cat_id );
				} else {
					$new_id                                = $factory->create_link( $url, $title, $bio_slug, $label, $prefix, $cat_id );
					$config[ $group ][ $index ]['link_id'] = $new_id;
				}
			}
		}

		if ( method_exists( '\BetterLinks\Helper', 'clear_query_cache' ) ) {
			\BetterLinks\Helper::clear_query_cache();
		}

		return $config;
	}

	/**
	 * Delete every tracked short link referenced by a config (bio deletion).
	 *
	 * @param array $config
	 * @return void
	 */
	public static function delete_config_links( $config ) {
		if ( ! class_exists( '\BetterLinks\Helper' ) ) {
			return;
		}
		$factory = new self();
		foreach ( self::bio_tracked_link_ids( $config ) as $link_id ) {
			$factory->remove_link( $link_id );
		}
		if ( method_exists( '\BetterLinks\Helper', 'clear_query_cache' ) ) {
			\BetterLinks\Helper::clear_query_cache();
		}
	}

	/**
	 * Create a short link for $url and return its ID (0 on failure).
	 *
	 * @param string $url
	 * @param string $title
	 * @param string $bio_slug
	 * @param string $label
	 * @param string $prefix
	 * @param int    $cat_id
	 * @return int
	 */
	private function create_link( $url, $title, $bio_slug, $label, $prefix, $cat_id ) {
		$url = esc_url_raw( trim( (string) $url ) );
		if ( empty( $url ) || ! wp_http_validate_url( $url ) ) {
			return 0;
		}

		$base  = $bio_slug ? $bio_slug : 'bio';
		$piece = sanitize_title( $label );
		$base  = $piece ? $base . '-' . $piece : $base;

		// Find a free unique slug.
		$slug  = $base;
		$short = $prefix ? $prefix . '/' . $slug : $slug;
		$guard = 0;
		while ( \BetterLinks\Helper::is_exists_short_url( $short ) && $guard < 50 ) {
			$guard++;
			$slug  = $base . '-' . $guard;
			$short = $prefix ? $prefix . '/' . $slug : $slug;
		}

		if ( '' === $title ) {
			$host  = wp_parse_url( $url, PHP_URL_HOST );
			$title = $host ? $host : __( 'Bio link', 'betterlinks-pro' );
		}

		$arg = array(
			'link_title'    => sanitize_text_field( $title ),
			'link_slug'     => $slug,
			'short_url'     => $short,
			'target_url'    => $url,
			'redirect_type' => '307',
			'link_status'   => 'publish',
			'nofollow'      => '',
			'sponsored'     => '',
			'track_me'      => 'on',
			'cat_id'        => $cat_id,
		);

		$result = $this->insert_link( $arg );
		if ( is_array( $result ) && ! empty( $result['ID'] ) ) {
			return (int) $result['ID'];
		}
		return 0;
	}

	/**
	 * Update an existing tracked short link's target/title (keeps its slug/short_url).
	 *
	 * @param int    $link_id
	 * @param string $url
	 * @param string $title
	 * @param int    $cat_id
	 * @return void
	 */
	private function modify_link( $link_id, $url, $title, $cat_id ) {
		$link = $this->get_link_row( $link_id );
		if ( empty( $link ) ) {
			return;
		}
		$url = esc_url_raw( trim( (string) $url ) );
		if ( empty( $url ) || ! wp_http_validate_url( $url ) ) {
			return;
		}

		$arg = array(
			'ID'            => (int) $link_id,
			'link_title'    => sanitize_text_field( $title ),
			'link_slug'     => $link['link_slug'],
			'short_url'     => $link['short_url'],
			'old_short_url' => $link['short_url'],
			'target_url'    => $url,
			'redirect_type' => ! empty( $link['redirect_type'] ) ? $link['redirect_type'] : '307',
			'link_status'   => 'publish',
			'track_me'      => 'on',
			'cat_id'        => $cat_id,
		);
		$this->update_link( $arg );
	}

	/**
	 * Delete a tracked short link by ID.
	 *
	 * @param int $link_id
	 * @return void
	 */
	private function remove_link( $link_id ) {
		$link = $this->get_link_row( $link_id );
		$args = array( 'ID' => (int) $link_id );
		if ( ! empty( $link['short_url'] ) ) {
			$args['short_url'] = $link['short_url'];
		}
		$this->delete_link( $args );
	}

	/**
	 * Fetch a raw link row by ID.
	 *
	 * @param int $link_id
	 * @return array|null
	 */
	private function get_link_row( $link_id ) {
		global $wpdb;
		$table = $wpdb->prefix . 'betterlinks';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE ID = %d", absint( $link_id ) ), ARRAY_A );
	}

	/**
	 * Does a link row still exist?
	 *
	 * @param int $link_id
	 * @return bool
	 */
	private static function link_exists( $link_id ) {
		global $wpdb;
		$table = $wpdb->prefix . 'betterlinks';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM {$table} WHERE ID = %d", absint( $link_id ) ) );
	}
}
