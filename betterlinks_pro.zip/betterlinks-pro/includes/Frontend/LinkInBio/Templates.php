<?php
namespace BetterLinksPro\Frontend\LinkInBio;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Design tokens + readymade presets for the "Link in Bio" feature.
 *
 * These data structures are the single source of truth shared between the PHP
 * public renderer ({@see Renderer}) and the React builder/preview
 * (dev_betterlinks/pages/LinkInBio/constants.js — keep the two in sync).
 */
class Templates {

	/**
	 * Style presets (theme swatches in the builder "Styles" panel).
	 * Each preset maps to a background + text + button colour set.
	 *
	 * @return array
	 */
	public static function style_presets() {
		return array(
			'light'    => array(
				'label'      => 'Light',
				'background' => array(
					'type'  => 'solid',
					'color' => '#f7f7f5',
				),
				'text'       => '#111111',
				'button'     => array(
					'color'     => '#111111',
					'fontColor' => '#ffffff',
				),
			),
			'dark'     => array(
				'label'      => 'Dark',
				'background' => array(
					'type'  => 'solid',
					'color' => '#14171f',
				),
				'text'       => '#ffffff',
				'button'     => array(
					'color'     => '#1f2733',
					'fontColor' => '#ffffff',
				),
			),
			'air'      => array(
				'label'      => 'Air',
				'background' => array(
					'type'  => 'solid',
					'color' => '#ffffff',
				),
				'text'       => '#1a1a1a',
				'button'     => array(
					'color'     => '#f1f1f1',
					'fontColor' => '#111111',
				),
			),
			'smoke'    => array(
				'label'      => 'Smoke',
				'background' => array(
					'type'  => 'solid',
					'color' => '#2b2b2b',
				),
				'text'       => '#fafafa',
				'button'     => array(
					'color'     => '#3a3a3a',
					'fontColor' => '#ffffff',
				),
			),
			'gradient' => array(
				'label'      => 'Gradient',
				'background' => array(
					'type'     => 'gradient',
					'gradient' => array(
						'from'  => '#8a8dff',
						'to'    => '#e0c3fc',
						'angle' => 160,
					),
				),
				'text'       => '#1a1a2e',
				'button'     => array(
					'color'     => '#ffffff',
					'fontColor' => '#1a1a2e',
				),
			),
			'seafoam'  => array(
				'label'      => 'Seafoam',
				'background' => array(
					'type'     => 'gradient',
					'gradient' => array(
						'from'  => '#4faba3',
						'to'    => '#2f7d76',
						'angle' => 165,
					),
				),
				'text'       => '#ffffff',
				'button'     => array(
					'color'     => '#0f766e',
					'fontColor' => '#ffffff',
				),
			),
			'rose'     => array(
				'label'      => 'Rose',
				'background' => array(
					'type'     => 'gradient',
					'gradient' => array(
						'from'  => '#f6c6d9',
						'to'    => '#b3284e',
						'angle' => 165,
					),
				),
				'text'       => '#ffffff',
				'button'     => array(
					'color'     => '#b3284e',
					'fontColor' => '#ffffff',
				),
			),
			'peach'    => array(
				'label'      => 'Peach',
				'background' => array(
					'type'     => 'gradient',
					'gradient' => array(
						'from'  => '#fcd9b0',
						'to'    => '#e8651b',
						'angle' => 165,
					),
				),
				'text'       => '#3a2410',
				'button'     => array(
					'color'     => '#e8651b',
					'fontColor' => '#ffffff',
				),
			),
			'lime'     => array(
				'label'      => 'Lime',
				'background' => array(
					'type'     => 'gradient',
					'gradient' => array(
						'from'  => '#e7f6b0',
						'to'    => '#6aa61b',
						'angle' => 165,
					),
				),
				'text'       => '#1f2b06',
				'button'     => array(
					'color'     => '#6aa61b',
					'fontColor' => '#ffffff',
				),
			),
			'blob'     => array(
				'label'      => 'Blob',
				'background' => array(
					'type'     => 'gradient',
					'gradient' => array(
						'from'  => '#f6c6d9',
						'to'    => '#a01a40',
						'angle' => 200,
					),
				),
				'text'       => '#ffffff',
				'button'     => array(
					'color'     => '#a01a40',
					'fontColor' => '#ffffff',
				),
			),
		);
	}

	/**
	 * Allowed layout keys.
	 *
	 * @return string[]
	 */
	public static function layouts() {
		return array( 'classic', 'hero', 'cover', 'spotlight', 'wave', 'pro', 'card', 'frame' );
	}

	/**
	 * Allowed button style keys.
	 *
	 * @return string[]
	 */
	public static function button_styles() {
		return array( 'solid', 'outline', 'soft', 'shadow', 'depth', 'glass', 'gradient', 'neon', 'retro', 'slide', 'ghost', 'underline', 'double', 'elevated', 'minimal' );
	}

	/**
	 * Allowed button animation keys (layered on top of the style).
	 *
	 * @return string[]
	 */
	public static function button_animations() {
		return array( 'none', 'pulse', 'glow', 'shine', 'bounce', 'float', 'flow', 'beam', 'wobble', 'expand', 'arrow' );
	}

	/**
	 * Allowed button shape keys.
	 *
	 * @return string[]
	 */
	public static function button_shapes() {
		return array( 'sharp', 'soft', 'rounded', 'large', 'pill', 'leaf', 'bevel' );
	}

	/**
	 * Allowed Google fonts.
	 *
	 * @return string[]
	 */
	public static function fonts() {
		return array(
			// Sans.
			'Inter',
			'Poppins',
			'Montserrat',
			'DM Sans',
			'Sora',
			'Space Grotesk',
			'Manrope',
			'Outfit',
			'Plus Jakarta Sans',
			'Figtree',
			'Urbanist',
			'Work Sans',
			// Display.
			'Oswald',
			'Bebas Neue',
			'Anton',
			'Archivo Black',
			'Abril Fatface',
			'Fraunces',
			// Serif.
			'Playfair Display',
			'DM Serif Display',
			'Cormorant Garamond',
			'Lora',
			'Libre Baskerville',
			'Merriweather',
			// Handwritten.
			'Pacifico',
			'Caveat',
			'Dancing Script',
			'Lobster',
		);
	}

	/**
	 * The default config used when creating a blank bio page.
	 *
	 * @return array
	 */
	public static function default_config() {
		return array(
			'profile'    => array(
				'avatar_id'  => 0,
				'avatar_url' => '',
				'title'      => '',
				'bio'        => '',
			),
			'icons'      => array(),
			'links'      => array(),
			'footer'     => array(),
			'layout'     => 'classic',
			'style'      => 'light',
			'background' => array(
				'type'     => 'solid',
				'color'    => '#f7f7f5',
				'gradient' => array(
					'from'  => '#8a8dff',
					'to'    => '#e0c3fc',
					'angle' => 160,
				),
				'image_id'  => 0,
				'image_url' => '',
			),
			'buttons'    => array(
				'style'     => 'solid',
				'animation' => 'none',
				'shape'     => 'rounded',
				'radius'    => '',
				'color'     => '#111111',
				'fontColor' => '',
			),
			'font'       => 'Inter',
			'colors'     => array(
				'title'       => '',
				'description' => '',
			),
			'seo'        => array(
				'meta_title'       => '',
				'meta_description' => '',
				'meta_image_id'    => 0,
				'meta_image_url'   => '',
			),
			// White-labelling. Pages saved before this existed have no `branding`
			// key at all, and a missing key keeps the credit — so upgrading never
			// silently removes the attribution from a live page.
			'branding'   => array(
				'show_credit' => true,
			),
		);
	}

	/**
	 * Readymade templates shown in the "Templates" modal. Each provides a ready
	 * config (sans personal data) and swatch colours for the thumbnail.
	 *
	 * @return array
	 */
	public static function templates() {
		$base = self::default_config();

		$make = function ( $overrides ) use ( $base ) {
			return array_replace_recursive( $base, $overrides );
		};

		return array(
			array(
				'id'        => 'minimal',
				'name'      => __( 'Minimal', 'betterlinks-pro' ),
				'swatch'    => array( '#ffffff', '#111111' ),
				'config'    => $make(
					array(
						'layout'  => 'classic',
						'style'   => 'air',
						'font'    => 'Inter',
						'buttons' => array(
							'style' => 'outline',
							'shape' => 'rounded',
							'color' => '#111111',
						),
					)
				),
			),
			array(
				'id'        => 'midnight',
				'name'      => __( 'Midnight', 'betterlinks-pro' ),
				'swatch'    => array( '#14171f', '#1f2733' ),
				'config'    => $make(
					array(
						'layout'  => 'pro',
						'style'   => 'dark',
						'font'    => 'Poppins',
						'buttons' => array(
							'style' => 'solid',
							'shape' => 'pill',
						),
					)
				),
			),
			array(
				'id'        => 'seafoam',
				'name'      => __( 'Seafoam', 'betterlinks-pro' ),
				'swatch'    => array( '#4faba3', '#0f766e' ),
				'config'    => $make(
					array(
						'layout'  => 'hero',
						'style'   => 'seafoam',
						'font'    => 'Oswald',
						'buttons' => array(
							'style' => 'outline',
							'shape' => 'rounded',
							'color' => '#0f766e',
						),
					)
				),
			),
			array(
				'id'        => 'sunset',
				'name'      => __( 'Sunset', 'betterlinks-pro' ),
				'swatch'    => array( '#fcd9b0', '#e8651b' ),
				'config'    => $make(
					array(
						'layout'  => 'hero',
						'style'   => 'peach',
						'font'    => 'Montserrat',
						'buttons' => array(
							'style' => 'shadow',
							'shape' => 'pill',
						),
					)
				),
			),
			array(
				'id'        => 'rosewater',
				'name'      => __( 'Rosewater', 'betterlinks-pro' ),
				'swatch'    => array( '#f6c6d9', '#b3284e' ),
				'config'    => $make(
					array(
						'layout'  => 'frame',
						'style'   => 'rose',
						'font'    => 'Lora',
						'buttons' => array(
							'style' => 'solid',
							'shape' => 'rounded',
						),
					)
				),
			),
			array(
				'id'        => 'aurora',
				'name'      => __( 'Aurora', 'betterlinks-pro' ),
				'swatch'    => array( '#8a8dff', '#e0c3fc' ),
				'config'    => $make(
					array(
						'layout'  => 'classic',
						'style'   => 'gradient',
						'font'    => 'Sora',
						'buttons' => array(
							'style' => 'solid',
							'shape' => 'pill',
						),
					)
				),
			),
		);
	}

	/**
	 * Inline SVG for a social/icon type. Falls back to a generic link glyph.
	 * Uses currentColor so the surrounding CSS controls the colour.
	 *
	 * @param string $type
	 * @return string
	 */
	public static function icon_svg( $type ) {
		$type = sanitize_key( $type );
		$map  = self::icon_paths();
		$path = isset( $map[ $type ] ) ? $map[ $type ] : $map['link'];
		return '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $path . '</svg>';
	}

	/**
	 * Known icon types (for validation + the builder dropdown).
	 *
	 * @return string[]
	 */
	public static function icon_types() {
		return array_keys( self::icon_paths() );
	}

	/**
	 * Stroke-based icon path data keyed by type.
	 *
	 * @return array
	 */
	private static function icon_paths() {
		return array(
			'link'      => '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
			'globe'     => '<circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>',
			'twitter'   => '<path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"/>',
			'x'         => '<path d="M4 4l16 16M20 4L4 20"/>',
			'instagram' => '<rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/>',
			'tiktok'    => '<path d="M9 12a4 4 0 1 0 4 4V4a5 5 0 0 0 5 5"/>',
			'youtube'   => '<path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19c1.72.46 8.6.46 8.6.46s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.33z"/><polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02"/>',
			'facebook'  => '<path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>',
			'linkedin'  => '<path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/>',
			'github'    => '<path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"/>',
			'email'     => '<rect x="2" y="4" width="20" height="16" rx="2"/><polyline points="22,6 12,13 2,6"/>',
			'whatsapp'  => '<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>',
			'telegram'  => '<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>',
			'pinterest' => '<circle cx="12" cy="12" r="10"/><path d="M9 19c1-4 2-7 2-7m0 0a3 3 0 1 0 3-3"/>',
			'spotify'   => '<circle cx="12" cy="12" r="10"/><path d="M7 9c4-1 8-.5 10 1M7.5 12.5c3-.8 6-.3 8 1M8 15.5c2-.5 4-.2 5.5.8"/>',
		);
	}
}
