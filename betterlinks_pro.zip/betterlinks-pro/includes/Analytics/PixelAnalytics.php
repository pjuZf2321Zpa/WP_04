<?php

namespace BetterLinksPro\Analytics;
if ( ! defined( 'ABSPATH' ) ) { exit; }

class PixelAnalytics
{
    /**
     * Send PageView Event to Facebook/Meta Conversions API as Server-Side Analytics.
     *
     * https://developers.facebook.com/docs/marketing-api/conversions-api/using-the-api
     *
     * Issue #3 (partial): emits an `event_id` so customers running their own
     * browser-side Pixel can dedup against this CAPI event. Full Pixel + CAPI
     * dual-send is a separate product change — this only ensures the dedup
     * key exists when the customer needs it.
     *
     * @param array  $data         Link data (uses `short_url`).
     * @param array  $server       $_SERVER snapshot from the redirect request.
     * @param string $pixel_id     FB Pixel ID.
     * @param string $access_token CAPI access token.
     * @param string $event_id     Optional UUIDv4 shared with the GA4 send for cross-platform dedup.
     */
    public function pixel_send_pageview($data, $server, $pixel_id, $access_token, $event_id = '')
    {
        $url = "https://graph.facebook.com/v15.0/{$pixel_id}/events";

        $event_payload = [
            "event_name"       => "PageView",
            "event_time"       => $server['REQUEST_TIME'],
            "user_data"        => [
                "client_ip_address" => $server['REMOTE_ADDR'],
                "client_user_agent" => $server['HTTP_USER_AGENT'],
            ],
            "event_source_url" => get_site_url(null, "/" . $data["short_url"]),
            "action_source"    => "website",
        ];

        if ( ! empty( $event_id ) ) {
            $event_payload['event_id'] = $event_id;
        }

        $pixel_data = [ $event_payload ];

        wp_remote_post(
            $url,
            array(
                'method' => 'POST',
                'body'   => array(
                    // JSON_UNESCAPED_UNICODE preserves non-Latin chars in any
                    // future fields that carry user-visible strings.
                    'data'         => wp_json_encode($pixel_data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                    'access_token' => $access_token,
                ),
            )
        );
    }
}
