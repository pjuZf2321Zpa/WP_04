<?php
namespace BetterLinksPro\Analytics;
if ( ! defined( 'ABSPATH' ) ) { exit; }

class GoogleAnalytics {
	private $visitor      = null;
	private $session_data = array();

	/**
	 * @param string $visitor      Raw _ga cookie value (legacy callers).
	 * @param array  $session_data Captured GA cookie / event-id snapshot from
	 *                             Link::capture_ga_session_data(). Keys:
	 *                             - 'client_id'       (string, GA4 format `random.timestamp`)
	 *                             - 'session_cookies' (array of `_ga_<MID> => raw cookie value`)
	 *                             - 'event_id'        (string UUIDv4, shared with Pixel CAPI for dedup)
	 */
	public function __construct( $visitor, $session_data = array() ) {
		$this->visitor      = $visitor;
		$this->session_data = is_array( $session_data ) ? $session_data : array();
	}

		// Generate UUID
		// Special thanks to stumiller.me for this formula.
	public function gaGenerateUUID() {
		return sprintf(
			'%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
			wp_rand( 0, 0xffff ),
			wp_rand( 0, 0xffff ),
			wp_rand( 0, 0xffff ),
			wp_rand( 0, 0x0fff ) | 0x4000,
			wp_rand( 0, 0x3fff ) | 0x8000,
			wp_rand( 0, 0xffff ),
			wp_rand( 0, 0xffff ),
			wp_rand( 0, 0xffff )
		);
	}

		// Send Data to Google Analytics UA
		// https://developers.google.com/analytics/devguides/collection/protocol/v1/devguide#event
	public function legacyGaSendData( $data ) {
		$getString  = 'https://ssl.google-analytics.com/collect';
		$getString .= '?payload_data&';
		$getString .= http_build_query( $data );
		$result     = wp_remote_get( $getString );
		return $result;
	}

		// Send Data to Google Analytics 4
		// https://firebase.google.com/codelabs/firebase_mp#4
		// https://ga-dev-tools.google/ga4/event-builder/
	public function ga4SendData( $data ) {
		$api_secret     = ! empty( $data['ga4_api_secret'] ) ? $data['ga4_api_secret'] : false;
		$measurement_id = ! empty( $data['tid'] ) ? $data['tid'] : '';

		if ( ! $api_secret || empty( $measurement_id ) ) {
			return;
		}

		$hostname = ! empty( $data['dh'] ) ? $data['dh'] : '';
		$page     = ! empty( $data['dp'] ) ? $data['dp'] : '';
		$title    = ! empty( $data['dt'] ) ? (string) $data['dt'] : '';
		$slug     = ! empty( $data['dt_slug'] ) ? (string) $data['dt_slug'] : '';

		$endpoint = 'https://www.google-analytics.com/mp/collect?api_secret=' . $api_secret . '&measurement_id=' . $measurement_id;

		// Issue #2: GA4 client_id must be the last two segments of the _ga cookie
		// (`<random>.<timestamp>`), not the full cookie value (`GA1.1.<random>.<timestamp>`).
		// Prefer the value captured at request time; fall back to deriving from $this->visitor
		// for legacy callers that didn't go through Link::capture_ga_session_data().
		$client_id = ! empty( $this->session_data['client_id'] )
			? $this->session_data['client_id']
			: self::derive_client_id_from_visitor( $this->visitor );

		// Issue #2: pull session_id from the _ga_<MID> cookie matching the configured
		// measurement_id; without this GA4 treats the event as a brand-new anonymous session.
		$session_id = $this->extract_session_id_for_measurement_id( $measurement_id );

		// Issue #3: per-click UUID forwarded to both GA4 and Meta CAPI so customers
		// running their own browser-side Pixel can dedup against this server send.
		$event_id = ! empty( $this->session_data['event_id'] ) ? $this->session_data['event_id'] : '';

		$event_params = array(
			'page_title'           => $title,
			'page_location'        => $hostname . $page,
			'engagement_time_msec' => 1,
		);
		// Issue #4: belt-and-braces — ASCII-safe slug as a discriminator that survives
		// even if title encoding ever breaks again.
		if ( '' !== $slug ) {
			$event_params['betterlink_slug'] = $slug;
		}
		if ( '' !== $session_id ) {
			$event_params['session_id'] = $session_id;
		}
		if ( '' !== $event_id ) {
			$event_params['event_id'] = $event_id;
		}

		$payload = array(
			'client_id' => $client_id,
			'events'    => array(
				array(
					'name'   => 'page_view',
					'params' => $event_params,
				),
			),
		);

		// Issue #1: JSON_UNESCAPED_UNICODE preserves Hebrew (and any other non-Latin
		// script) in human-readable form on the wire. Without this flag wp_json_encode
		// emits `\uXXXX` escape sequences — still valid JSON but harder to debug, and
		// some intermediaries have been observed to mangle them.
		$result = wp_remote_post(
			$endpoint,
			array(
				'body'    => wp_json_encode( $payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),
				'headers' => array(
					'Content-Type' => 'application/json; charset=utf-8',
				),
			)
		);

		return $result;
	}

	public function gaSendData( $data ) {
		if ( substr( $data['tid'], 0, 1 ) == 'U' ) {
			$this->legacyGaSendData( $data );
		} elseif ( substr( $data['tid'], 0, 1 ) == 'G' ) {
			$this->ga4SendData( $data );
		}
		return;
	}

		// Send Pageview Function for Server-Side Google Analytics
	public function ga_send_pageview( $tid, $ga4_api_secret, $hostname = null, $page = null, $title = null, $slug = null ) {
		if ( empty( $tid ) ) {
			return;
		}

		$data = array(
			'v'              => 1,
			'tid'            => $tid, // GA Tracking/Measurement ID (set in BetterLinks External Analytics).
			'ga4_api_secret' => $ga4_api_secret,
			'cid'            => $this->visitor,
			't'              => 'page_view',
			'dh'             => $hostname, // Document Hostname "example.com"
			'dp'             => $page, // Page "/something"
			'dt'             => $title, // Title (Issue #1: now passes link_title, was link_slug)
			'dt_slug'        => $slug,  // Slug (Issue #4: emitted as `betterlink_slug` custom param)
		);

		$this->gaSendData( $data );
	}

	/**
	 * Derive a GA4 client_id from a raw _ga cookie value.
	 *
	 * `_ga` cookie format: `GA<v>.<subdomains>.<random>.<timestamp>`
	 * GA4 client_id:        `<random>.<timestamp>`
	 *
	 * For values that don't match the GA cookie format (e.g. server-generated
	 * fallbacks from Link::gaCookieGeneration()'s uniqid path), return the
	 * value unchanged so we still send something stable per visitor.
	 */
	private static function derive_client_id_from_visitor( $visitor ) {
		if ( empty( $visitor ) ) {
			return '';
		}
		$parts = explode( '.', $visitor );
		if ( count( $parts ) >= 4 ) {
			return $parts[2] . '.' . $parts[3];
		}
		return $visitor;
	}

	/**
	 * Extract `session_id` from the `_ga_<MID>` cookie that matches the
	 * configured GA4 measurement_id.
	 *
	 * Measurement ID format: `G-XXXXXXXXXX`
	 * Cookie name:           `_ga_XXXXXXXXXX` (no `G-` prefix)
	 * Cookie value format:   `GS<v>.<s>.<session_id>.<session_number>.<flag>.<ts>.0.0.0`
	 */
	private function extract_session_id_for_measurement_id( $measurement_id ) {
		if ( empty( $this->session_data['session_cookies'] ) || ! is_array( $this->session_data['session_cookies'] ) ) {
			return '';
		}
		$cookie_suffix = preg_replace( '/^G-/', '', (string) $measurement_id );
		$cookie_name   = '_ga_' . $cookie_suffix;
		if ( ! isset( $this->session_data['session_cookies'][ $cookie_name ] ) ) {
			return '';
		}
		$parts = explode( '.', $this->session_data['session_cookies'][ $cookie_name ] );
		return isset( $parts[2] ) ? (string) $parts[2] : '';
	}
}
