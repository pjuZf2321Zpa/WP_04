<?php
namespace BetterLinksPro\Analytics;
if ( ! defined( 'ABSPATH' ) ) { exit; }

use BetterLinksPro\Compat;

/**
 * Exclude IP addresses from click analytics.
 *
 * The setting (`excluded_ips` in the BetterLinks settings option) keeps its name
 * and data. Clicks from these IPs still redirect normally; they are only left out
 * of reports. Plugs into the free plugin through:
 * - betterlinks/analytics/where_clause: adds `ip NOT IN (...)` to report queries.
 * - betterlinks/analytics/transient_key: varies cached reports with the IP list.
 * - betterlinkspro/admin/update_settings: validates the list on save.
 */
class IpExclusion {

	/**
	 * @var string[]|null
	 */
	private static $ips = null;

	public static function init() {
		$self = new self();
		// Validation is idempotent, so it also runs alongside older free plugins
		// that validate the list themselves.
		add_filter( 'betterlinkspro/admin/update_settings', array( $self, 'sanitize_settings' ), 5 );
		if ( ! Compat::free_has_extension_api() ) {
			return; // Older free plugins apply the exclusion inline.
		}
		add_filter( 'betterlinks/analytics/where_clause', array( $self, 'where_clause' ), 10, 2 );
		add_filter( 'betterlinks/analytics/transient_key', array( $self, 'transient_key' ), 10, 2 );
	}

	/**
	 * Validated excluded IPs.
	 *
	 * @return string[]
	 */
	public static function get_ips() {
		if ( null !== self::$ips ) {
			return self::$ips;
		}
		$options   = json_decode( (string) get_option( BETTERLINKS_LINKS_OPTION_NAME, '{}' ), true );
		$ips       = is_array( $options ) && isset( $options['excluded_ips'] ) && is_array( $options['excluded_ips'] ) ? $options['excluded_ips'] : array();
		self::$ips = array_values( array_filter( array_map( array( __CLASS__, 'clean_ip' ), $ips ) ) );
		return self::$ips;
	}

	/**
	 * @param mixed $ip Raw value.
	 * @return string|null
	 */
	private static function clean_ip( $ip ) {
		$ip = is_scalar( $ip ) ? sanitize_text_field( trim( (string) $ip ) ) : '';
		return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : null;
	}

	/**
	 * Condition and values for `$column NOT IN (...)`.
	 *
	 * @param string $column Qualified IP column.
	 * @return array{sql:string,params:string[]}
	 */
	public static function clause( $column = 'ip' ) {
		$ips = self::get_ips();
		if ( empty( $ips ) ) {
			return array( 'sql' => '', 'params' => array() );
		}
		$column = in_array( $column, array( 'ip', 'c.ip', 'CLICKS.ip', 'clicks.ip' ), true ) ? $column : 'ip';
		return array(
			'sql'    => $column . ' NOT IN (' . implode( ', ', array_fill( 0, count( $ips ), '%s' ) ) . ')',
			'params' => $ips,
		);
	}

	/**
	 * @param array $extra   Current extra condition.
	 * @param array $context Report context (column, report, from, to).
	 * @return array
	 */
	public function where_clause( $extra, $context ) {
		$clause = self::clause( isset( $context['column'] ) ? $context['column'] : 'ip' );
		if ( '' === $clause['sql'] ) {
			return $extra;
		}
		$sql    = is_array( $extra ) && ! empty( $extra['sql'] ) ? $extra['sql'] . ' AND ' . $clause['sql'] : $clause['sql'];
		$params = is_array( $extra ) && ! empty( $extra['params'] ) ? array_merge( array_values( $extra['params'] ), $clause['params'] ) : $clause['params'];
		return array( 'sql' => $sql, 'params' => $params );
	}

	/**
	 * Cache-key suffix for the current IP list ('' when none).
	 *
	 * @return string
	 */
	public static function key_suffix() {
		$ips = self::get_ips();
		return empty( $ips ) ? '' : '_' . substr( md5( implode( ',', $ips ) ), 0, 8 );
	}

	/**
	 * @param string $key Cache key.
	 * @return string
	 */
	public function transient_key( $key ) {
		return $key . self::key_suffix();
	}

	/**
	 * Keep only valid IPv4/IPv6 addresses in the saved list.
	 *
	 * @param array $response Settings being saved.
	 * @return array
	 */
	public function sanitize_settings( $response ) {
		if ( is_array( $response ) && isset( $response['excluded_ips'] ) ) {
			$response['excluded_ips'] = is_array( $response['excluded_ips'] )
				? array_values( array_filter( array_map( array( __CLASS__, 'clean_ip' ), $response['excluded_ips'] ) ) )
				: array();
			self::$ips = null;
		}
		return $response;
	}
}
