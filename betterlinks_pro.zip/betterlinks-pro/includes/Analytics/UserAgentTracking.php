<?php
namespace BetterLinksPro\Analytics;
if ( ! defined( 'ABSPATH' ) ) { exit; }

use BetterLinksPro\Compat;

// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL

/**
 * User-agent tracking for click analytics.
 *
 * Uses the existing `enable_user_agent_tracking` setting (off by default) and the
 * `betterlinks_user_agents` table the free plugin creates. Plugs into the free
 * plugin through:
 * - betterlinks/link/insert_click_arg: capture the visitor's user agent.
 * - betterlinks/click/inserted: store it and link it to the click row.
 * - betterlinks/analytics/individual_clicks_select: show it in the click log.
 */
class UserAgentTracking {

	public static function init() {
		if ( ! Compat::free_has_extension_api() ) {
			return; // Older free plugins track user agents inline.
		}
		$self = new self();
		add_filter( 'betterlinks/link/insert_click_arg', array( $self, 'capture' ), 10, 2 );
		add_action( 'betterlinks/click/inserted', array( $self, 'store' ), 10, 3 );
		add_filter( 'betterlinks/analytics/individual_clicks_select', array( $self, 'select' ), 10, 2 );
	}

	/**
	 * @return bool
	 */
	private static function enabled() {
		$settings = get_option( BETTERLINKS_LINKS_OPTION_NAME, '[]' );
		if ( is_string( $settings ) ) {
			$settings = json_decode( $settings, true );
		}
		return is_array( $settings ) && ! empty( $settings['enable_user_agent_tracking'] );
	}

	/**
	 * @param array $arg  Click row data.
	 * @param array $data Link data.
	 * @return array
	 */
	public function capture( $arg, $data = array() ) {
		if ( is_array( $arg ) && ! isset( $arg['user_agent'] ) && isset( $_SERVER['HTTP_USER_AGENT'] ) && self::enabled() ) {
			$arg['user_agent'] = sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) );
		}
		return $arg;
	}

	/**
	 * @param int   $click_id Click row ID.
	 * @param array $item     Stored click data.
	 * @param int   $link_id  Link ID.
	 */
	public function store( $click_id, $item, $link_id = 0 ) {
		if ( empty( $item['user_agent'] ) || ! self::enabled() || ! self::column_exists() ) {
			return;
		}
		$user_agent_id = self::get_or_insert_id( $item['user_agent'] );
		if ( $user_agent_id ) {
			global $wpdb;
			$wpdb->update( $wpdb->prefix . 'betterlinks_clicks', array( 'user_agent_id' => $user_agent_id ), array( 'ID' => (int) $click_id ), array( '%d' ), array( '%d' ) );
		}
	}

	/**
	 * @param array $select  { columns, joins }.
	 * @param array $context Query context.
	 * @return array
	 */
	public function select( $select, $context ) {
		global $wpdb;
		$table = $wpdb->prefix . 'betterlinks_user_agents';
		if ( 'yes' !== get_transient( 'betterlinkspro_user_agents_table_exists' ) ) {
			if ( ! $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) ) {
				return $select;
			}
			set_transient( 'betterlinkspro_user_agents_table_exists', 'yes', DAY_IN_SECONDS );
		}
		$select['columns'][] = 'ua.user_agent';
		$select['joins'][]   = 'LEFT JOIN ' . $table . ' ua ON c.user_agent_id = ua.id';
		return $select;
	}

	private static function get_or_insert_id( $user_agent ) {
		global $wpdb;
		
		if ( empty( $user_agent ) ) {
			return null;
		}
		
		// Check if user_agents table exists first
		$user_agents_table_exists = $wpdb->get_var( 
			$wpdb->prepare( 
				"SHOW TABLES LIKE %s", 
				$wpdb->prefix . 'betterlinks_user_agents' 
			)
		);
		
		if ( ! $user_agents_table_exists ) {
			return null; // Table doesn't exist, return null gracefully
		}
		
		// First try to get existing user agent ID
		$existing_id = $wpdb->get_var( 
			$wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}betterlinks_user_agents WHERE user_agent = %s LIMIT 1",
				$user_agent
			)
		);
		
		if ( $existing_id ) {
			return (int) $existing_id;
		}
		
		// Insert new user agent if not exists
		$result = $wpdb->query(
			$wpdb->prepare(
				"INSERT IGNORE INTO {$wpdb->prefix}betterlinks_user_agents (user_agent) VALUES (%s)",
				$user_agent
			)
		);
		
		if ( $result ) {
			return (int) $wpdb->insert_id;
		}
		
		// If INSERT IGNORE failed due to race condition, try to get ID again
		$existing_id = $wpdb->get_var( 
			$wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}betterlinks_user_agents WHERE user_agent = %s LIMIT 1",
				$user_agent
			)
		);
		
		return $existing_id ? (int) $existing_id : null;
	}

	/**
	 * Cached check for user_agent_id column existence to avoid hitting information_schema on every redirect
	 * 
	 * @return bool
	 */
	private static function column_exists() {
		global $wpdb;

		$transient_key = 'betterlinks_user_agent_column_exists';
		$column_exists = get_transient( $transient_key );
		
		if ( $column_exists === false ) {
			// Only hit information_schema when not cached
			$column_exists = $wpdb->get_var( 
				$wpdb->prepare( 
					'SELECT `column_name` FROM information_schema.columns WHERE table_schema=%s AND table_name=%s AND column_name="user_agent_id"',
					DB_NAME,
					$wpdb->prefix . 'betterlinks_clicks'
				)
			);
			
			// Cache for 1 hour - column structure doesn't change often
			set_transient( $transient_key, $column_exists ? 'yes' : 'no', HOUR_IN_SECONDS );
		}
		
		return $column_exists === 'yes';
	}
}
