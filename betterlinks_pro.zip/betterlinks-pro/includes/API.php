<?php
namespace BetterLinksPro;
if ( ! defined( 'ABSPATH' ) ) { exit; }

class API
{
    public function __construct()
    {
        $this->dispatch_hook();
    }

    /**
     * Role permission map, read on every check.
     *
     * The user and the map used to be cached when this class was built on
     * plugins_loaded. For a cookie-authenticated REST request without a valid
     * X-WP-Nonce, core resets the current user to 0 after that, but the cached
     * roles still matched, which let cross-site requests pass the bucket checks.
     *
     * @return array|null
     */
    private function get_user_permission()
    {
        $permission = json_decode((string) get_option(BETTERLINKS_PRO_ROLE_PERMISSON_OPTION_NAME), true);
        return is_array($permission) ? $permission : null;
    }

    /**
     * Primary role of the user making this request.
     *
     * @return string|false
     */
    private function current_user_role()
    {
        return current((array) wp_get_current_user()->roles);
    }

    public function dispatch_hook()
    {
        add_action('rest_api_init', array($this, 'create_initial_rest_routes'), 99);
        new API\Clicks();
        add_filter('betterlinks/insert_link_default_args', array($this, 'add_uncloak'));
        add_filter('betterlinks/links_schema', array($this, 'links_schema'));
        add_filter('betterlinks/api/params', array($this, 'links_params'));
        add_filter('betterlinks/api/links_get_items_permissions_check', array($this, 'links_get_items_permissions_check'));
        // Global settings read/write require the settings permission specifically,
        // not "any of six buckets" (get_permissions_check) — a view-only/favorite/
        // analytics role must not read or rewrite the site-wide settings option.
        add_filter('betterlinks/api/settings_get_items_permissions_check', array($this, 'settings_permissions_check'));
        add_filter('betterlinks/api/terms_get_items_permissions_check', array($this, 'terms_get_items_permissions_check'));
        add_filter('betterlinks/api/settings_update_items_permissions_check', array($this, 'settings_permissions_check'));
        // The AI routes read and write raw OpenAI/Gemini API keys and can publish
        // links; keep them administrator-only (the core default) instead of the
        // collapsed any-bucket check.
        add_filter('betterlinks/api/ai_permissions_check', array($this, 'ai_permissions_check'));
        add_filter('betterlinks/api/links_create_item_permissions_check', array($this, 'links_create_item_permissions_check'));
        add_filter('betterlinks/api/links_update_item_permissions_check', array($this, 'links_update_item_permissions_check'));
        add_filter('betterlinks/api/links_update_favorite_permissions_check', array($this, 'links_update_favorite_permissions_check'));
        add_filter('betterlinks/api/analytics_items_permissions_check', array($this, 'analytics_items_permissions_check'));
        add_filter('betterlinkspro/api/analytics_items_permissions_check', array($this, 'analytics_items_permissions_check'));
        add_filter('betterlinkspro/api/manage_autolink_permission_check', array($this, 'manage_autolink_permission_check'));
        add_filter('betterlinks/api/terms_manage_permissions_check', array($this, 'terms_manage_permissions_check'));
        add_filter('betterlinkspro/admin/current_user_can_manage_link_scanner', array($this, 'manage_link_scanner_permission_check'));
        
        // Add permission check for fetch target URL functionality
        add_filter('betterlinks_can_fetch_target_url', array($this, 'can_fetch_target_url_permission_check'));

        // Role Management's "Who can use MCP?". BetterLinks asks this only for
        // non-administrators, on every MCP request, so removing a role here cuts
        // its connections off on their next call. Versions of BetterLinks that
        // predate the filter never ask, so MCP stays administrator-only there.
        add_filter('betterlinks/mcp/user_can_access', array($this, 'mcp_user_can_access'), 10, 2);
    }

    /**
     * Grant MCP to the roles ticked under "Who can use MCP?".
     *
     * Receives the user being checked rather than reading the current user: the
     * MCP server asks about the account that approved a connection before it
     * switches to it.
     *
     * @param bool          $allowed Whether MCP is already allowed (false unless another filter said so).
     * @param \WP_User|null $user    The user being checked.
     * @return bool
     */
    public function mcp_user_can_access($allowed, $user = null)
    {
        if (!$user instanceof \WP_User) {
            return (bool) $allowed;
        }
        $permission = $this->get_user_permission();
        if (!is_array($permission) || empty($permission['manageMcp'])) {
            return (bool) $allowed;
        }
        if (\BetterLinksPro\Helper::role_matches(current((array) $user->roles), $permission['manageMcp'])) {
            return true;
        }
        return (bool) $allowed;
    }
    public function create_initial_rest_routes()
    {
        // UTM
        $controller = new API\UTM;
        $controller->register_routes();
        $keywords = new API\Keywords();
        $keywords->register_routes();
        // AI Bulk Link Generator and geolocation: older free plugins still register these routes.
        if ( \BetterLinksPro\Compat::free_has_extension_api() ) {
            ( new API\AIBulkLinks() )->register_routes();
            ( new API\Geolocation() )->register_routes();
        }
        // The AI Link Assistant endpoints ship in Pro 2.8.0+.
        if ( \BetterLinksPro\Admin\Assets::is_link_genius_supported() ) {
            $link_genius = new API\LinkGenius();
            $link_genius->register_routes();
        }
        $product_display = new API\ProductDisplay();
        $product_display->register_routes();
        $product_group = new API\ProductGroup();
        $product_group->register_routes();
        $bio_pages = new API\BioPages();
        $bio_pages->register_routes();
    }
    public function links_schema($schema)
    {
        $schema['uncloaked'] = [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        ];

        $schema['expire'] = [
            'type' => 'object',
            'properties' => array(
                'status'  => array(
                    'type' => 'integer',
                    'sanitize_callback' => 'absint'
                ),
                'type' => array(
                    'type' 				=> 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'clicks' => array(
                    'type' 				=> 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'date' => array(
                    'type' => 'string',
                    'format' => 'date-time',
                ),
                'redirect_status'  => array(
                    'type' => 'integer',
                    'sanitize_callback' => 'absint'
                ),
                'redirect_url' => array(
                    'type' 				=> 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ];

        $schema['dynamic_redirect'] = [
            'type' => 'object',
            'properties' => array(
                'type'  => array(
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field'
                ),
                'value'  => array(
                    'type' => 'array',
                    'items' => array(
                        'type' => 'object',
                        'properties' => array(
                            'link' => array(
                                'type' => 'string',
                                'sanitize_callback' => 'sanitize_text_field'
                            ),
                            'weight' => array(
                                'type' => 'string',
                                'sanitize_callback' => 'sanitize_text_field'
                            )
                        )
                    )
                ),
                'extra'  => array(
                    'type' => 'object',
                    'properties' => array(
                        'split_test'  => array(
                            'type' => 'integer',
                            'sanitize_callback' => 'absint'
                        ),
                        'goal_link'  => array(
                            'type' => 'string',
                            'sanitize_callback' => 'sanitize_text_field'
                        ),
                        // Open in App (type `app`): which app, and who sees the page.
                        'app'  => array(
                            'type' => 'string',
                            'sanitize_callback' => 'sanitize_key'
                        ),
                        'when'  => array(
                            'type' => 'string',
                            'enum' => array('in_app', 'mobile'),
                            'sanitize_callback' => 'sanitize_key'
                        ),
                    )
                ),
            ),
        ];
        $schema['enable_custom_scripts'] = [
            'type' => 'boolean'
        ];
        $schema['custom_tracking_scripts'] = [
            'type' => 'string',
            // Raw JS echoed on the cloak page — unfiltered_html only. Mirrors the
            // core schema so a delegated writelinks/editlinks role cannot smuggle
            // markup in through the Pro-augmented route.
            //
            // Wired to a Pro-local callback rather than straight to
            // \BetterLinks\Helper::sanitize_custom_tracking_scripts() on purpose:
            // Pro auto-updates ahead of Free, so during the roll-out window this
            // schema can be registered while the Free half still predates that
            // helper. A non-callable sanitize_callback is not skipped gracefully —
            // WP_REST_Request::sanitize_params() calls it through call_user_func()
            // with no is_callable() guard, which throws a TypeError on PHP 8 (every
            // link write 500s) and nulls the field on PHP 7.4. The wrapper below
            // keeps the gate closed either way.
            'sanitize_callback' => array($this, 'sanitize_custom_tracking_scripts'),
        ];

        return $schema;
    }

    /**
     * Sanitize the `custom_tracking_scripts` REST field.
     *
     * Delegates to the shared Free implementation when the active Free build has
     * it, and otherwise enforces the same rule locally so an older Free can never
     * leave the field unsanitized.
     *
     * @param mixed $value Incoming value.
     * @return string
     */
    public function sanitize_custom_tracking_scripts($value)
    {
        if (is_callable(array('\\BetterLinks\\Helper', 'sanitize_custom_tracking_scripts'))) {
            return \BetterLinks\Helper::sanitize_custom_tracking_scripts($value);
        }

        if (!is_string($value)) {
            return '';
        }

        return current_user_can('unfiltered_html') ? $value : '';
    }
    public function links_params($params)
    {
        $params['expire'] = (isset($params['expire']) ? json_encode($params['expire']) : '{}');
        $params['dynamic_redirect'] = (isset($params['dynamic_redirect']) ? json_encode($params['dynamic_redirect']) : '{}');
        return $params;
    }
    public function add_uncloak($args)
    {
        $args['uncloaked'] = '';
        return $args;
    }
    public function get_permissions_check()
    {
        if (current_user_can('manage_options')) {
            return true;
        }
        if (!is_array($this->get_user_permission())) {
            return false;
        }
        $current_user_roles = $this->current_user_role();
        $checked_permissions = ['writelinks', 'editlinks', 'viewlinks', 'editsettings', 'editFavorite', 'checkanalytics'];
        foreach ($checked_permissions as $permission) {
            if (isset($this->get_user_permission()[$permission]) && is_array($this->get_user_permission()[$permission]) && \BetterLinksPro\Helper::role_matches( $current_user_roles, $this->get_user_permission()[$permission])) {
                return true;
            }
        }
        return false;
    }

    /**
     * Read access to the links list: a link-related delegated permission only.
     *
     * Narrower than get_permissions_check() — settings-only and analytics-only
     * roles have no business enumerating the link table.
     *
     * @return bool
     */
    public function links_get_items_permissions_check()
    {
        if (current_user_can('manage_options')) {
            return true;
        }
        if (!is_array($this->get_user_permission())) {
            return false;
        }
        $current_user_roles = $this->current_user_role();
        $allowed_permissions = ['viewlinks', 'editlinks', 'writelinks', 'editFavorite'];
        foreach ($allowed_permissions as $permission) {
            if (isset($this->get_user_permission()[$permission]) && is_array($this->get_user_permission()[$permission]) && \BetterLinksPro\Helper::role_matches( $current_user_roles, $this->get_user_permission()[$permission])) {
                return true;
            }
        }
        return false;
    }

    /**
     * Read/write access to the site-wide BetterLinks settings option.
     *
     * Requires the delegated `editsettings` permission (or manage_options),
     * matching how the rest of the settings control plane is gated.
     *
     * @return bool
     */
    public function settings_permissions_check()
    {
        if (current_user_can('manage_options')) {
            return true;
        }
        if (!is_array($this->get_user_permission())) {
            return false;
        }
        $current_user_roles = $this->current_user_role();
        return isset($this->get_user_permission()['editsettings'])
            && is_array($this->get_user_permission()['editsettings'])
            && \BetterLinksPro\Helper::role_matches( $current_user_roles, $this->get_user_permission()['editsettings'] ?? array());
    }

    /**
     * Access to the AI routes (key read/write, processing, publishing).
     *
     * These expose raw provider API keys and can create published links, so they
     * stay administrator-only — the core default before Pro's filter widened it.
     *
     * @return bool
     */
    public function ai_permissions_check()
    {
        return current_user_can('manage_options');
    }
    public function links_create_item_permissions_check()
    {
        if (current_user_can('manage_options')) {
            return true;
        }
        if (!is_array($this->get_user_permission())) {
            return false;
        }
        $current_user_roles = $this->current_user_role();
        if (\BetterLinksPro\Helper::role_matches( $current_user_roles, $this->get_user_permission()['writelinks'] ?? array())) {
            return true;
        }
        return false;
    }
    public function links_update_item_permissions_check()
    {
        if (current_user_can('manage_options')) {
            return true;
        }
        if (!is_array($this->get_user_permission())) {
            return false;
        }
        $current_user_roles = $this->current_user_role();
        if (\BetterLinksPro\Helper::role_matches( $current_user_roles, $this->get_user_permission()['editlinks'] ?? array())) {
            return true;
        }
        return false;
    }
    public function manage_autolink_permission_check()
    {
        if (current_user_can('manage_options')) {
            return true;
        }
        if (!is_array($this->get_user_permission())) {
            return false;
        }
        $current_user_roles = $this->current_user_role();
        if (\BetterLinksPro\Helper::role_matches( $current_user_roles, $this->get_user_permission()['manageAutoliks'] ?? array())) {
            return true;
        }
        return false;
    }
    public function links_update_favorite_permissions_check()
    {
        if (current_user_can('manage_options')) {
            return true;
        }
        if (!is_array($this->get_user_permission()) || !isset($this->get_user_permission()['editFavorite'])) {
            return false;
        }
        $current_user_roles = $this->current_user_role();
        if (\BetterLinksPro\Helper::role_matches( $current_user_roles, $this->get_user_permission()['editFavorite'] ?? array())) {
            return true;
        }
        return false;
    }
    public function terms_manage_permissions_check()
    {
        if (current_user_can('manage_options')) {
            return true;
        }
        if (!is_array($this->get_user_permission()) || !isset($this->get_user_permission()['manageTagsCategories'])) {
            return false;
        }
        $current_user_roles = $this->current_user_role();
        if (\BetterLinksPro\Helper::role_matches( $current_user_roles, $this->get_user_permission()['manageTagsCategories'] ?? array())) {
            return true;
        }
        return false;
    }
    
    /**
     * Check if current user can view/read terms (tags & categories)
     * This is more permissive - allows any user with BetterLinks permissions to view
     */
    public function terms_get_items_permissions_check()
    {
        if (current_user_can('manage_options')) {
            return true;
        }
        if (!is_array($this->get_user_permission())) {
            return false;
        }
        $current_user_roles = $this->current_user_role();
        
        // Allow viewing if user has ANY BetterLinks permission
        $all_permissions = ['viewlinks', 'writelinks', 'editlinks', 'checkanalytics', 'editsettings', 'editFavorite', 'manageAutoliks', 'manageTagsCategories', 'manageLinkScanner'];
        
        foreach ($all_permissions as $permission) {
            if (isset($this->get_user_permission()[$permission]) && \BetterLinksPro\Helper::role_matches( $current_user_roles, $this->get_user_permission()[$permission])) {
                return true;
            }
        }
        
        return false;
    }
    
    public function manage_link_scanner_permission_check()
    {
        if (current_user_can('manage_options')) {
            return true;
        }
        if (!is_array($this->get_user_permission()) || !isset($this->get_user_permission()['manageLinkScanner'])) {
            return false;
        }
        $current_user_roles = $this->current_user_role();
        if (\BetterLinksPro\Helper::role_matches( $current_user_roles, $this->get_user_permission()['manageLinkScanner'] ?? array())) {
            return true;
        }
        return false;
    }
    public function analytics_items_permissions_check()
    {
        if (current_user_can('manage_options')) {
            return true;
        }
        if (!is_array($this->get_user_permission())) {
            return false;
        }
        $current_user_roles = $this->current_user_role();
        if (\BetterLinksPro\Helper::role_matches( $current_user_roles, $this->get_user_permission()['checkanalytics'] ?? array())) {
            return true;
        }
        return false;
    }

    /**
     * Check if current user can fetch target URL for title suggestions
     * Users with view, edit, or write permissions should be able to use this feature
     */
    public function can_fetch_target_url_permission_check($can_fetch = false)
    {
        // If already allowed, keep it allowed
        if ($can_fetch) {
            return true;
        }
        
        // Check role-based permissions - allow if user can view, edit, or write links
        if (!is_array($this->get_user_permission())) {
            return false;
        }
        
        $current_user_roles = $this->current_user_role();
        
        // Allow if user has any of these permissions: view, edit, or write links
        $allowed_permissions = ['viewlinks', 'editlinks', 'writelinks'];
        
        foreach ($allowed_permissions as $permission) {
            if (isset($this->get_user_permission()[$permission]) && \BetterLinksPro\Helper::role_matches( $current_user_roles, $this->get_user_permission()[$permission])) {
                return true;
            }
        }
        
        return false;
    }
}
