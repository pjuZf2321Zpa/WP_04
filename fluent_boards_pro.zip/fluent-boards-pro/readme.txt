=== Fluent Boards Pro ===
Contributors: WPManageNinja
Tags: task management, task board, task list, task manager, project management, project manager, project management, to-do list, to-do, kanban board
Requires at least: 5.0
Tested up to: 7.1
Stable tag: 2.3.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Installation Steps:
-----
1. Goto  Plugins » Add New
2. Then click on "Upload Plugins"
3. Then Click "Choose File" and then select the fluent-boards-pro.zip file
4. Then Click, Install Now after that activate that.
5. You may need to activate the License, and You will get the license at your WPManageNinja.com account.


== Changelog ==

= v2.3.0 (Date: October 30, 2026) =

- New: Read-only task share links, no login needed
- New: Share Board controls for layouts and visibility
- New: Emoji in comments and reactions
- New: Pause notifications globally or per board, with scheduled or manual resume
- New: Save and create another task
- New: Task dependencies in task details, with search and blocked indicators
- Improvement: Save boards and tasks as templates through MCP
- Improvement: Board filters persist, with an active count
- Improvement: Dates follow WordPress language and date settings
- Improvement: Trello import recovery and cover retries
- Improvement: Refreshed public boards with flexible layouts, search, task details, and theme styling
- Fixed: Security hardening for board access on task covers, watchers, dependencies, CRM contact links, and template status
- Fixed: Duplicate comment and mention emails
- Fixed: Missing unread counts on Kanban cards
- Fixed: List view not loading more tasks on scroll
- Fixed: Recurring tasks use the site timezone
- Fixed: Invitations keep the selected role and clear once accepted
- Fixed: Missing or duplicate tasks in JSON imports
- Fixed: Field spacing in Fluent Forms task descriptions
- Other improvements and bug fixes

= v2.2.2 (Date: October 16, 2026) =

- Fixed: Attachment previews disrupted by buffered output or PHP notices in Pro
- Other bug fixes and improvements

= v2.2.1 (Date: October 13, 2026) =

- Fix: Upload directory warning issue
- Fix: Cloud attachment downloads failing on some sites
- Fix: Search briefly showing empty results while typing
- Fix: CSV import upload error handling
- Fix: Recurring task and reminder scheduling fixes
- Fix: Minor stability and permission fixes

= v2.2.0 (Date: October 12, 2026) =

- New: Browse, preview, and create boards from built-in templates, or save them for reuse
- New: Ready-to-use board background images
- New: OpenRouter support for AI writing assistance
- New: Create MCP connection keys from your account, with admin-managed access
- New: Import Fluent Boards exports without Pro
- New: Filter recurring tasks and task templates
- New: Drag and drop boards into folders
- Improvement: Update your profile name and photo from your account
- Improvement: Redesigned notification emails with light and dark mode support
- Improvement: Easier member access management across multiple boards
- Improvement: Preserve more task data when duplicating boards, importing, and using templates
- Improvement: Richer comment formatting, slash commands, and easier description copying
- Improvement: Clearer recurring schedules, links to generated tasks, and custom-field activity history
- Improvement: Faster board lists, task activity feeds, and bulk stage moves
- Improvement: Simpler AI setup, updated model choices, and better translations
- Fixed: Assignment notifications, comment email links, and incorrect archive emails when restoring tasks
- Fixed: Bulk task moves now apply stage defaults and trigger notifications and webhooks
- Fixed: Task and board deletion now cleans up related data and local or cloud attachments
- Fixed: Search and filters now work together, and failed status updates preserve the previous status
- Fixed: Recurring tasks retain custom fields and correctly update task counts and creation webhooks
- Fixed: Time-log dates, custom date fields, timesheet access, and CSV exports
- Fixed: Webhook event selection, task completion events, and missing-data handling
- Fixed: FluentCRM task assignments, template data, and contact-board associations
- Fixed: Task navigation, upload protection, and board permission checks

= v2.1.0 (Date: September 17, 2026) =

- New: Rich text formatting for comments and replies
- New: Markdown attachment previews with Mermaid diagrams and full-screen mode
- New: Import Trello boards via API
- New: Label colors that adapt to light and dark modes
- Improvement: Identify labels faster with colored backgrounds
- Improvement: Task descriptions now auto-save, with dedicated Save and Cancel buttons for added control
- Improvement: Task headers now show the current stage
- Improvement: Spot high-priority tasks faster with color-coded priorities
- Improvement: Refined task details and dashboard badges
- Fixed: Table search persistence, Gantt scrolling, and date picker overlap
- Fixed: Timesheet reports, missing board descriptions, and task lookup errors
- Fixed: Tightened security for public boards and API responses
- Fixed: Other security issues
- Other improvements and bug fixes

= v2.0.15 (Date: September 9, 2026) =

- Improvement: Refined priority controls and task card UI
- Improvement: Smoother task description editing
- Improvement: Updated translations
- Improvement: Faster board exports
- Fixed: Task description formatting and links when creating and editing tasks
- Fixed: Duplicate subtask creation through the AI assistant
- Fixed: Subtask and time-tracking cleanup issues
- Fixed: Attachment popover placement, folder title overflow, and template preview contrast in dark mode
- Fixed: Board background cleanup and board-scoped image file resolution
- Fixed: Member authorization issue
- Fixed: Other security issues

= v2.0.12 (Date: August 20, 2026) =

- Improvement: Compatibility with WordPress 7.1
- Improvement: Comments, replies, attached images, and time-tracking entries now move with tasks transferred to another board
- Improvement: Refined the task label interface with a shared label popover
- Improvement: Role & Policy based security improved
- Fixed: Resolved formatting issues in task descriptions, including those created through Fluent Forms
- Fixed: Some Security Issues
- Other improvements and bug fixes

= v2.0.10 (Date: August 12, 2026) =

Improvement: Better RTL support across dashboards, boards, tasks, comments, subtasks, activities, settings, reports, and responsive admin layouts
Improvement: Added a styled confirmation dialog for custom field deletion
Improvement: Task titles now appear in global notifications
Improvement: Newly created tasks now open in the task modal
Improvement: Subtask Group UX updated
Improvement: Member Role Edit Experience Improved
Fixed: Conflicting theme assets loading in the frontend portal
Fixed: Subtask due date and assignee were not saving properly during creation
Fixed: Time tracking estimate popover issue
Fixed: Table label overflow issue
Fixed: Incorrect timezone in task reminder alerts
Fixed: Image and emoji issue in task description
Other improvements and bug fixes

= v2.0.4 (Date: August 3, 2026) =
- Fixed: Subtask Group Bug Fixed
- Fixed: Date change in smaller scree issue
- Fixed: My task section archived task issue
- Fixed: Hello Elementor theme issue
- Fixed: TimeTracking Issues
- Other improvements & bug fixes

= v2.0.1 (Date: July 31, 2026) =
- Improvement: Improved Change Stage performance
- Improvement: Improved Settings, Reports and Dark Mode UI
- Fixed: Removed unnecessary notifications for Task description changes
- Fixed: Subtask layout and Task Modal breadcrumb issues
- Fixed: Other UI issues
- Other improvements & bug fixes

= v2.0.0 (Date: July 30, 2026) =
- New: Completely New UI/UX synced with Fluent System
- New: Featured dashboard with recently opened boards and notifications
- New: Dark Mode with Light / Dark / System theme switching
- New: Newly designed Task details Modal with next/previous task navigation
- New: AI Writing Assistant in task descriptions
- New: AI Powered subtasks generation, summary, labels & priority suggestions,
- New: Markdown editor for task descriptions
- New: Rebuilt & Redesigned Reports with Overview, Tasks, Activity, Timesheet and Roadmap screens
- New: Board template management with editable templates, covers and categories
- New: Automated board creation from FluentCRM automation actions
- New: Task Priority enhanced
- New: MCP tools added for label, stage and task query tools for AI agents
- New: redesigned member profile stats widget, recent-tasks widget, and activity feed
- Improvement: Fully responsive admin, including mobile
- Improvement: Improved Label management experience
- Improvement: Improved Change stage or move task to other boards experience
- Improvement: Some attachments preview UX improved
- Improvement: Redesigned Kanban, List, Table, Calendar and Gantt views
- Improvement: Redesigned comments, activity feed and notifications
- Improvement: Redesigned attachments with per-file upload progress
- Other improvements & bug fixes

= v1.95.3 (Date: July 14, 2026)
- Fixed: Minor Security Issue Fixed (Thanks to Diogo Pinto)

= v1.95.2 (Date: June 12, 2026) =
- Fixed: Tasks filter issue
- Fixed: Table View title sort issue
- Fixed: UI Issue in Stage Reorder
- Fixed: Critical error from task comment email links
- Fixed: Attachment issue when moving task to another board
- Fixed: Folder edit issue
- Other improvements & bug fixes

= v1.95 (Date: May 21, 2026) =
- New: Gantt Chart View
- New: MCP Support for AI Agents
- New: Pin Tasks
- New: Anyone with Permission Can Create Boards
- New: Highlight Recently Opened Tasks in Kanban
- New: Task dependency added
- Improvement: Improved Handling for Large JSON Imports
- Improvement: Optimized CSV Export for Large Numbers of Tasks in Boards
- Improvement: Clone Attachments and Cover Images When Moving Boards
- Improvement: UI improvements in My Task Section
- Fixed: Task Reminder Timezone Issue
- Fixed: Repeat Task Date Issue
- Other improvements and bug fixes

=v1.91.2 (Date: January 26, 2025) =
-Improvement: Auth policy update for better security.
-Fixed: Digital Ocean file upload issue.


= v1.91 (Date: December 24, 2025) =
- Improvement: Global add button moved for better user experience. 
- Improvement: Internal security improved.
- Improvement: Improved button color consistency.
- Fixed: Resolved an issue with Cloudflare R2 file uploads.
- Fixed: Resolved the problem where stages in a board were not reordering properly.
- Fixed: Fixed the issue with the edit button in comments.
- Other Improvements & Bug Fixes

= v1.90 (Date: November 13, 2025) =
- New: Bulk actions in Table View
- New: Bulk restore and delete for archived tasks
- New: Additional webhook triggers
- Improvement: Better cross-board task movement handling
- Improvement: WordPress Guidelines and coding standards compliance
- Improvement: Enhanced error handling and dependency check
- Fixed: Stages ordering issues in board duplication
- Fixed: Board description rendering issue with ampersands
- Fixed: Task deletion issue
- Fixed: Parent ID falsy (zero) value handling
- Fixed: Default preferences not applied to newly added settings
- Fixed: Subtask group assignment inconsistencies
- Fixed: Microsoft office files attachment upload issue
- Other Improvements & Bug Fixes

= v1.86 (Date: September 26, 2025) =
- New: Easy task delete functionality
- Improvement: Task reminder icon added when reminder active.
- Improvement: Webhook data pattern improved , message key added for better handling
- Improvement: Added a close icon to the label popover for easier closing
- Fixed: Custom field select and multiselect error
- Fixed: Kanban view preference error
- Fixed: Task creation issue with default assignee in stage
- Fixed: Duplicate member in assignee
- Other Improvements & Bug Fixes

= v1.85 (Date: September 18, 2025) =
- New: Table View for tasks
- New: Outgoing Webhooks
- New: Task and subtask reminder feature
- New: REST API documentation
- Improvement: 'Assigned' & 'Mentioned' Tab in My tasks section
- Improvement: Added "Create from template" option in task create action in CRM Automation
- Improvement: Improved member search to support partial name matches
- Improvement: Additional translations
- Fixed: Security Issues in board member invitations
- Fixed: Roles Issues in board member management
- Fixed: Frontend portal task creation issue in List view
- Fixed: Incoming webhook task creation issue with watchers and members
- Fixed: Email sent issue when self-assigned to task
- Other Improvements & Bug Fixes

= v1.80 (Date: July 31, 2025) =
- New: Board folderization for better board management.
- New: Task clone with customization for efficient task duplication
- New: Boards list view
- New: Simple notes for subtasks to capture brief task details
- New: Task List view settings for customizable user experience
- New: Rearrange custom fields order with drag functionality for better organization
- New: Added task watcher functionality alongside task assignees
- New: Added ability to make comments public/private in Roadmap tasks.
- New: Mentioned and assigned filters in notification sidebar
- New: Board menu now customizable with ability to add/reorder items
- Improvement: Enhanced JSON export with large data support
- Improvement: Redesigned custom fields interface for better user experience
- Improvement: Added 'load more' in quick search
- Improvement: Open task in new board within move card component for improved task management
- Fixed: Multiple task creation issue in repeat tasks
- Fixed: Resolved board view conflict issue
- Fixed: Stage background color issue in duplicated boards
- Fixed: Multiclick issue during saving
- Fixed: Task positioning issue when moving tasks
- Fixed: Added Fluent Boards to CRM navigation
- Fixed: Task filtering issue with translated priorities
- Fixed: Label popover UX issue in task drawer
- Fixed: Roadmap idea vote count issue
- Fixed: Auto-focus issue in global search
- Other Improvements & Bug Fixes

= v1.65 (Date: June 02, 2025) =
- New: Pinned board functionality for quick access to important boards
- New: Direct task creation from image drops or pastes
- New: Enhanced task filtering by CRM contact association
- New: Task filtering by watchers for better task tracking
- New: Background blur effect in task details dialog for improved focus
- New: Customizable task priority levels via filter hook
- Improvement: Attachments/Files can be mapped with Task from Fluent Form
- Improvement: Added search functionality in move card popover
- Improvement: Customizable task tabs for comments and activities via filter hook
- Improvement: Enhanced comment reply interface
- Improvement: Improved subtask and group creation UX workflow
- Improvement: Direct subtask group creation from CRM contact section
- Fixed: Removed background styling from task title input in list view
- Fixed: Input Method Editor (IME) compatibility in subtask fields
- Fixed: Task date removal functionality issue
- Fixed: Translation Issue
- Other Improvements & Bug Fixes

= v1.60 (Date: May 21, 2025) =
- New: Introduced Subtask Group
- New: Single Board shortcode Functionality
- New: Custom color support for stage background
- Improvement: More Optimized UI in List View, Subtask Section etc.
- Improvement: Scroll to top functionality in task details page
- Improvement: User image now sourced from WordPress user profile
- Improvement: Custom field option added in Board Menu
- Improvement: Task description editor sync and collapse icon added
- Improvement: Background image upload switched from WP Media to local directory
- Improvement: Create label directly from empty search
- Improvement: Added Activity tracking for repeat tasks
- Improvement : Ability to delete board label
- Fixed: Global add-task and stage save button multi-click issue
- Fixed: Multiple emails sent issue on member invitations
- Fixed: Disappearing search popup Issue for keyword "4466" in search
- Fixed: Mention Issue in comments for usernames containing emails or space-separated words
- Fixed: Stage header title text selection issue
- Fixed: CRM contact not showing in task
- Other Improvements

= v1.48 (Date: April 10, 2025) =
- New: Customizable tabs in 'My Tasks' of Dashboard
- New : Time Logs Now offer Date Selection Options
- New: Multi-Select added in Custom Fields
- New: Filter By Task Status
- New: Task descriptions now support "Large Mode" View
- Security: Updated Framework Library
- Improvement: Board Duplication Includes Templates & background
- Improvement: Copy task links directly from the task card
- Improvement: Navbar UI Upated for small screens
- Improvement: Task attachments now support uploading multiple files at once.
- Improvement: Added the ability to delete a time log
- Fixed: Custom Login URL Redirect Issue in Roadmap Authentication Settings
- Fixed: Task loading error in the CRM Contact Section when time tracking is disabled
- Fixed: Issue where multiple clicks created duplicate boards
- Fixed: Stages not appearing issue in global task add button
- Fixed: Improved board and roadmap movement issues
- Fixed: Media attachment functionality issue in task description drawers
- Other Improvements & Bug Fixes

= v1.47 (Date: March 06, 2025) =
- New: Task View Drawer for List View & Calendar View
- New: Global UTF-8 Support for Comments
- Improvement: Navigate to Specific Comment from Notification
- Fixed: Board Menu Translation Issue
- Fixed: Admin Bar Disappearing Issue
- Fixed: Double Logout Icon in Frontend Portal Issue
- Fixed: Task Completion activity bug
- Other Improvements & Bug Fixes

= v1.45 (Date: March 03, 2025) =
- New: CSV Export and Import
- New: Custom color support in Labels
- New: RTL(Right-to-Left) Support
- New: FluentCRM integration in Roadmap 
- New: Added Frontend Portal Link in admin bar for quick access
- New: Easily transition ideas across stages
- Improvement: More translation strings added
- Improvement: Enabled 24-hour time format support
- Improvement: Task link copy via the 'Copy Link' button
- Improvement: Redesigned Features & Modules with improved UI/UX
- Fixed: Multisite Issue
- Fixed: Date diff discrepancy in activities
- Fixed: External storage integration issues
- Fixed: Width overflow issue in task description
- Fixed: Margin issues in frontend portal report
- Fixed: Logged time disappearing when moving tasks between boards
- Fixed: Task created from FluentCRM automations default priority issue
- Other Improvements & Bug Fixes

= v1.40 (Date: January 21, 2025) =
- New : Backblaze storage integration
- New: Digital Ocean storage integration
- New: Create a new stage between existing stages.
- New: Image and Custom color in task Cover
- Improvement:  UX in settings feature module
- Improvement: UI/UX in task comment and image
- Improvement: Replaced pagination with infinite scroll for comments and activities
- Improvement: Stage selection  in Recurring Task.
- Improvement: Updated Roadmap task details with vote counter and improved task type handling
- Improvement: Comment mentions system updated.
- Improvement: Comment mentions notification updated.
- Improvement: Quick Search in mobile view
- Improvement: Automatic deletion of board activities upon board removal
- Improvement: UI improvement in the frontend topbar
- Fixed: Issue where @mentions would occasionally display as "undefined"
- Fixed: Custom field error in the filter
- Fixed: Comment created time issue
- Fixed: Console error while editing webhook.
- Fixed: Notification design-break issue solved.
- Fixed: UI breaking with long activity history text
- Fixed: Improved touch-screen drag icon and task title styling
- Fixed: PHP 7.4 compatibility Issue
- Other Improvements & Bug Fixes

= v1.35 (Date: December 03, 2024) =
- New: Default Stage Assignee.
- New: View-only member Role.
- Improvement: Board-specific layout settings — assign list, Kanban, or calendar view per board.
- Improvement: Board managers can now access timesheets.
- Improvement: Task description editor updated for better usability.
- Improvement: External storage supported for comment and description images.
- Improvement: Calendar week start now follows WordPress settings; updated week, month, and date pickers accordingly.
- Improvement: Better visibility in  All  Activities.
- Improvement: Refreshed media storage design.
- Improvement: Added automatic cleanup of scheduler logs older than 7 days.
- Fixed: Tasks count issue while archive/restore.
- Fixed: Task create input bug in List view
- Fixed: Notification count not clearing after "Mark All as Read."
- Fixed: Task description image issues.
- Other Improvements & Bug Fixes.

= v1.32 (Date: October 23, 2024) =

- Improvement: Task Performance Optimization
- Improvement: More images can be uploaded in comment
- Improvement: Default due time updated
- Improvement: UX in Comment & Reply
- Fixed: Move card issue Resolved and Improved
- Fixed: "Go to Comment" Button in Email Issue
- Fixed: Image issue in task description
- Fixed: Task redirection issue from subtask related notifications
- Fixed: Attachment title issue
- Fixed: Activity issue in profile section
- Fixed: Email send issue for Comment's reply
- Fixed: Comment edit issue for uploaded image
- Other Improvement & Bug Fixes

= v1.30 (Date: September 24, 2024) =

- New: Recurring Task
- New: External Storage Provider: S3, R2 Added
- New: Board Archive Feature
- New: Roadmap Report
- New: Unread Notification Count in task
- New: Easily paste files or URLs directly as attachments
- New: Labels now Searchable
- New: Modifiable Time Track Logs
- New: Enable/Disable Roadmap Options
- Improvement: Task Descriptions Now Support Markdown on Paste
- Improvement: Time Track added in CRM contact section
- Improvement: Custom Fields added in Filter
- Improvement: Datepicker added in Kanban
- Improvement: Archived Tasks searchable as 'archived: (text)' in Quick Search
- Improvement: Number of completed subtasks now visible in the task card
- Improvement: Added Others tab in My Task Section
- Improvement: More Translations
- Fixed: Task assignee Duplicate Issue
- Fixed: UI Breaking Issue in shortcode
- Other Improvement & Bug Fixes

= v1.22 (Date: August 23, 2024) =

- New: Board Export/Import
- New: Global Button to add task/stage/board
- New: Mention in Comment
- New: Image in Comment
- New: Comment/Description Image Paste Feature
- New: Dynamic watching options while creating tasks, commenting, assigning
- New: Smart Search like ID:123
- Improvement: UI/UX - Notification setting moved to User Profile
- Fixed: Roadmap Setting Issue
- Fixed: Codefreeze/Security Plugin Issue
- Fixed: 7G Firewall issue Fixed
- Fixed: Labels in duplicating board
- Fixed: Description Stying, Board activity styling
- Other Improvement & Bug Fixes

= v1.21 (Date: July 29, 2024) =

* New: Fluent Roadmap
* Improvement: Drag & Drop
* Improvement: Profile Section Responsive Now
* Fixed: Due Date Reminder Rescheduling Issue
* Fixed: Email validation issue
* Fixed: Member Invitation Issue for Manager Role
* Fixed: Email Validation Issue in Members
* Other Improvements and Bug Fixes

= v1.20 (Date: July 02, 2024) =

* New: Calendar View
* New: Due Date Reminder (Daily Summary)
* New: Custom Fields
* New: User Profile
* Improvement: Attached labels with Duplicated Boards
* Improvement: Issues In Notification
* Improvement: Comment highlight from a Link/Notification
* Fixed: Subtask Count Issue
* Fixed: Stage Change from More Options
* Fixed: Description Saving Issue on other property changing
* Fixed: User Name/Email not showing in Member Addition
* Fixed: Email Validation Issue in Members
* Other Improvements and Bug Fixes

= v1.13 (Date: June 10, 2024) =

* New: Convert Task to Subtask
* New: WpEditor in Board Description
* New: Added All Board Report & Individual URL
* Improvement: Enhanced Stage Sort UI/UX
* Improvement: Added Due Days in Fluent Form Integration
* Improvement: UX Improvement in Board Member
* Improvement: UX Improvement in Subtask Add/Edit
* Improvement: Date & Time in Comments & Activities. (on hover)
* Fixed: Broken UI for Longtext in description
* Fixed: Deleting imported Subtask Issue
* Fixed: Board Label Scroll Issue
* Fixed: Issue with Member Invitation Email
* Fixed: Task/Subtask Count while Importing from Trello
* Fixed: Issue with Recently Viewed Boards
* Other Improvement & Bug Fixes

= 1.12 (Date: Jun 03, 2024) =
* New: Drag & Drop  in Touch Devices
* New: Completed Task Count now visible on Board Cards
* Improvement: Better UX for task creation
* Improvement: Subtask Edit/Scroll Issue
* Improvement: Allowing Subtasks in Duplicate Board
* Improvement: Improved task moving functionality
* Improvement: Reduced number of AJAX calls
* Fixed: Issue with label editing
* Fixed: Issues with moving tasks and stages
* Fixed: Subtask Modification Issue . Compatible now  with older versions
* Fixed: Recently viewed Boards issue
* Other Improvement & Bug Fixes

= 1.11 (Date: May 28, 2024) =
* New: Timesheet Export
* New: Webhook (Task Creation)
* New: Stage Background
* Added: Custom Solid color & Gradient
* Added: Progress Bar for Subtasks
* Added: All WP Allowed Files Supports in Attachement
* Added: Due Days & Priority for Task Create Action in Automation
* Added: Board Search
* Improvement: Updating description now easier
* Improvement: Role & Permission
* Improvement: Boards UI
* Fixed: Description Formatting Break Issue
* Fixed: Subtask Reorder
* Fixed: Link Add in Attachments
* Fixed: Permission Issue
* Other Improvement & Bug Fixes

= 1.10 (Date: May 20, 2024) =
* Added Frontend Portal via Shortcode
* Improved User Permissions & Roles
* Mobile Responsiveness Improvements
* Notifications Improvements
* Added Translation Files
* Other Improvements & Bug Fixes

= 1.0 =
* Added Basic Reporting (More coming soon)
* Refactored FluentCRM Connections
* Improvement of UI & Bug Fixes

= 0.76 =
* New: Stage Drag and Drop
* New: You can attach zip file now. Files are downloadable.
* Improvement: Board Labels
* Improvement: My Tasks Section
* UI Improvements
* Internal Performance Improvements
* Other Improvements & Bug Fixes

= 0.75 =
* New: Import from Asana
* New: Menu Position in Advanced Modules
* New: Fullscreen Mode
* New: Create Subtask from Task Menu in Kanban
* New: Option to Add/Delete Stages in Onboarding
* New: Completed Tasks in MyTasks
* New: Animation upon Task Status Change
* Improvement: Frontend Settings
* Improvement: Mobile Responsive
* Improvement: UI in Task/Stage Template
* Bug Fix: Broken URL in Task Title Issue
* Bug Fix: Task Count Issue
* Other Improvement and Bug Fixes

= 0.73 =
* New: Advanced Modules with Frontend Capability
* New: Import from Trello
* New: Fluent Support Integration
* New: Task Template & Stage Template
* New: Due Date as well as Start Date with newly improved design
* Improvement: UI of Task Attachment
* Improvement: FluentCRM Contact Section Quick view
* Improvement: Internal Performance
* Bug Fix: 7G Firewall Issue for Nginx
* Other UI/UX improvement & Bug Fixes


= 0.65 =
* Bug Fixes: Notification
* Bug Fixes: My Task
* Bug Fixes: Member Role
* Bug Fixes: Board Member search and CRM contact Search
* Performance Improvement in Table View
* Improvement: UI of Move Task
* New: Duplicate Board
* New: Subtask added in CRM Contact Quick View Section
* New: Fluent Form Integration
* New: Stage Change Trigger in CRM Automation
* Other UI/UX improvement & Bug Fixes


= 0.62 =
* Fix Task Timestamp Issue
* Fix Task move issues
* Improved UI/UX

= 0.60 =
* Initial Release
