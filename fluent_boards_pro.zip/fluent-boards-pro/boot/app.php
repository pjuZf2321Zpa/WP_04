<?php

use FluentBoardsPro\App\Core\Application;
use FluentBoardsPro\App\Hooks\Handlers\ProActivationHandler;
use FluentBoardsPro\App\Hooks\Handlers\ProDeactivationHandler;
use FluentBoardsPro\App\Hooks\Handlers\ProTaskHandler;

return function ($file) {
    add_action('fluent_boards_loaded', function ($app) use ($file) {
        new Application($app, $file);

        if(function_exists('fluent_boards_get_features_config')) {
            $features = fluent_boards_get_features_config();
        } else {
            $features = fbsGetFeaturesConfig();
        }

        // Init Modules
        (new \FluentBoardsPro\App\Modules\TimeTracking\TimerInit($app))->register();
        if (isset($features['cloud_storage']) && $features['cloud_storage'] === 'yes') {
            (new \FluentBoardsPro\App\Modules\CloudStorage\CloudStorageModule())->register($app);
        }
        // Files uploaded while cloud storage was on must still be deleted after it is
        // switched off, so the delete listeners do not depend on the feature flag.
        \FluentBoardsPro\App\Modules\CloudStorage\CloudStorageModule::registerDeleteListeners();

        $proTaskHandler = new ProTaskHandler();

        add_action('fluent_boards/task_updated', function ($task, $updatedProperty) use ($proTaskHandler) {
            if ($updatedProperty === 'position') {
                $proTaskHandler->handleTaskBoardMoveAndUpdateTimeTracking($task);
            }
        }, 10, 2);
    });

    add_action('fluent_boards/rendering_app', function () {

        if (as_next_scheduled_action('fluent_boards/five_minutes_scheduler') === false) {
            as_schedule_recurring_action(time() + (5 * MINUTE_IN_SECONDS), 5 * MINUTE_IN_SECONDS, 'fluent_boards/five_minutes_scheduler', [], 'fluent-boards');
        }
        if(as_next_scheduled_action('fluent_boards/hourly_scheduler') === false) {
            as_schedule_recurring_action(time() + HOUR_IN_SECONDS, HOUR_IN_SECONDS, 'fluent_boards/hourly_scheduler', [], 'fluent-boards');
        }
        if (as_next_scheduled_action('fluent_boards/daily_scheduler') === false) {
            as_schedule_recurring_action( strtotime('tomorrow 00:00:00'), DAY_IN_SECONDS, 'fluent_boards/daily_scheduler', [], 'fluent_boards');
        }

        (new \FluentBoardsPro\App\Hooks\Handlers\ProScheduleHandler())->recurringTaskScheduler();
    });

    register_activation_hook($file, function () {
        (new ProActivationHandler())->handle();
    });

    register_deactivation_hook($file, function () {
        (new ProDeactivationHandler())->handle();
    });


    add_action('plugins_loaded', function () {
        $urlBase = apply_filters('fluent_boards/app_url', admin_url('admin.php?page=fluent-boards#/'));

        $licenseManager = (new \FluentBoardsPro\App\Services\PluginManager\FluentLicensing())->register([
            'version'      => FLUENT_BOARDS_PRO_VERSION,
            'basename'     => 'fluent-boards-pro/fluent-boards-pro.php',
            'api_url'      => 'https://fluentapi.wpmanageninja.com/',
            'item_id'      => 7560871, // FluentCart product ID for Fluent Boards Pro
            'plugin_title' => 'FluentBoards Pro',
            // Same option the old EDD-based LicenseManager wrote to, so an
            // already licensed site stays licensed with no customer action.
            'settings_key' => '__fbs_plugin_license',
            'slug'         => 'fluent-boards-pro',
            'store_url'    => 'https://wpmanageninja.com/',
            'purchase_url' => 'https://fluentboards.com/',
            'account_url'  => 'https://wpmanageninja.com/account/',
            'support_url'  => 'https://wpmanageninja.com/account/support-tickets/',
            'activate_url' => $urlBase . 'settings/license',
            'show_check_update' => true,
            // Refuse update packages that are not signed by our offline release
            // key. Compiled in rather than read from a server response: a switch
            // that lives on the server is one whoever takes the server can flip.
            // A site owner can still opt out locally.
            'verify_updates'    => !(defined('FLUENT_BOARDS_PRO_SKIP_UPDATE_VERIFY') && FLUENT_BOARDS_PRO_SKIP_UPDATE_VERIFY),
        ]);

        $licenseMessage = $licenseManager->getLicenseMessages();

        if ($licenseMessage) {
            add_action('admin_notices', function () use ($licenseMessage) {
                if (defined('FLUENT_BOARDS')) {
                    $class   = 'notice fbs_notice';
                    $message = $licenseMessage['message'];
                    printf('<div class="%1$s">%2$s</div>',
                        esc_attr($class), wp_kses_post($message));
                }
            });
        }

        add_filter('fluent_boards/dashboard_notices',
            function ($notices) use ($licenseManager) {
                $details = $licenseManager->getLicenseMessages();
                if ($details && ! empty($details['message'])) {
                    $notices[] = '<div>'.$details['message'].'</div>';
                }

                return $notices;
            });

        // The updater adds its own "Check Update" link; these two are ours.
        add_filter('plugin_row_meta', function ($links, $file) {
            if ($file !== 'fluent-boards-pro/fluent-boards-pro.php') {
                return $links;
            }

            $links['docs'] = '<a href="' . esc_url(apply_filters('fluent_boards/docs_url', 'https://fluentboards.com/docs/')) . '" aria-label="' . esc_attr__('View FluentBoards documentation', 'fluent-boards-pro') . '">' . esc_html__('Docs', 'fluent-boards-pro') . '</a>';
            $links['support'] = '<a href="' . esc_url(apply_filters('fluent_boards/community_support_url', 'https://wpmanageninja.com/support-tickets/#/')) . '" aria-label="' . esc_attr__('Visit Support', 'fluent-boards-pro') . '">' . esc_html__('Help & Support', 'fluent-boards-pro') . '</a>';

            return $links;
        }, 10, 2);

    }, 0);

    // Register FluentCRM Integration when FluentCRM is loaded
    add_action('fluentcrm_loaded', function () {
        new \FluentBoardsPro\App\Services\Integrations\FluentCRM\Init();
    });

};
