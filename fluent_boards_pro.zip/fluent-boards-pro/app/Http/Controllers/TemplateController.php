<?php

namespace FluentBoardsPro\App\Http\Controllers;

use FluentBoards\App\Http\Controllers\Controller;
use FluentBoards\App\Services\BoardService;
use FluentBoards\App\Services\StageService;
use FluentBoards\App\Services\LabelService;
use FluentBoards\App\Services\TaskService;
use FluentBoards\App\Services\PermissionManager;
use FluentBoards\Framework\Http\Request\Request;
use FluentBoards\Framework\Support\Arr;
use FluentBoardsPro\App\Services\TemplateService;
use Throwable;

class TemplateController extends Controller
{
    private $templateService;
    private $boardService;
    private $stageService;
    private $labelService;
    private $taskService;

    public function __construct()
    {
        parent::__construct();
        $this->templateService = new TemplateService();
        $this->boardService = new BoardService();
        $this->stageService = new StageService();
        $this->labelService = new LabelService();
        $this->taskService = new TaskService();
    }

    /**
     * Return both galleries while keeping user templates available during catalog outages.
     */
    public function getTemplates(Request $request)
    {
        $defaultTemplates = [];
        try {
            $defaultTemplates = $this->templateService->getDefaultTemplates();
        } catch (\Exception $e) {
            // This legacy combined route must not hide local templates when GitHub is unavailable.
        }

        try {
            $userTemplates = $this->templateService->getUserTemplates();

            return $this->sendSuccess([
                'default_templates' => $defaultTemplates,
                'user_templates' => $userTemplates,
            ], 200);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 400);
        }
    }

    /**
     * Return lightweight built-in template metadata from the remote catalog.
     */
    public function getDefaultTemplates()
    {
        try {
            $templates = $this->templateService->getDefaultTemplates();

            return $this->sendSuccess([
                'templates' => $templates,
            ], 200);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 400);
        }
    }

    /**
     * Get user's own templates
     */
    public function getUserTemplates()
    {
        try {
            $templates = $this->templateService->getUserTemplates();

            return $this->sendSuccess([
                'templates' => $templates,
            ], 200);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 400);
        }
    }

    /**
     * Create a board from the selected template stages, labels, and optional custom stages.
     */
    public function createBoardFromTemplate(Request $request)
    {
        $data = $this->validate($request->all(), [
            'title'              => 'required|string',
            'template_type'      => 'required|string', // 'default' or 'user'
            'template_id'        => 'required',
            'include_tasks'      => 'nullable',
            'include_labels'     => 'nullable',
            'selected_stage_ids' => 'nullable|array',
            'additional_stages'  => 'nullable|array',
            'selected_labels'    => 'nullable|array',
        ]);

        try {
            $templateType = $data['template_type'];
            $templateId = $data['template_id'];
            $boardTitle = $data['title'];
            $includeTasks = Arr::get($data, 'include_tasks', 'no') === 'yes';
            $includeLabels = Arr::get($data, 'include_labels', 'yes') === 'yes';
            $selectedStageIds = array_key_exists('selected_stage_ids', $data)
                ? $data['selected_stage_ids']
                : null;
            $additionalStages = Arr::get($data, 'additional_stages', []);
            $selectedLabels = array_key_exists('selected_labels', $data)
                ? $data['selected_labels']
                : null;

            if ($templateType === 'default') {
                // Create from default template (remote)
                $board = $this->templateService->createFromDefaultTemplate(
                    $templateId,
                    $boardTitle,
                    $includeLabels,
                    $selectedStageIds,
                    $additionalStages,
                    $selectedLabels
                );
            } else {
                // Create from user's template (existing board marked as template)
                $board = $this->templateService->createFromUserTemplate(
                    $templateId,
                    $boardTitle,
                    $includeTasks,
                    $includeLabels,
                    $selectedStageIds,
                    $additionalStages,
                    $selectedLabels
                );
            }

            do_action('fluent_boards/board_created_from_template', $board, $templateType, $templateId);

            return $this->sendSuccess([
                'board' => $board,
                'message' => __('Board created successfully from template', 'fluent-boards-pro'),
            ], 201);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 400);
        }
    }

    /** Save a complete built-in template as an independent My Templates entry. */
    public function saveDefaultTemplate(Request $request)
    {
        $data = $this->validate($request->all(), [
            'template_id' => 'required|string',
        ]);

        try {
            $template = $this->templateService->saveDefaultTemplate($data['template_id']);

            $response = $this->sendSuccess([
                'template' => $template,
                'message' => __('Template saved to My Templates', 'fluent-boards-pro'),
            ]);
            $response->set_status(201);

            return $response;
        } catch (Throwable $exception) {
            return $this->sendError($exception->getMessage(), $exception->getCode() === 409 ? 409 : 400);
        }
    }

    /**
     * Convert an existing board to a template
     */
    public function makeTemplate(Request $request, $board_id)
    {
        $data = $this->validate($request->all(), [
            'template_description' => 'nullable|string',
            'template_category' => 'nullable|string',
        ]);

        try {
            if (!PermissionManager::isBoardManager($board_id)) {
                throw new \Exception(__('You do not have permission to convert this board to a template', 'fluent-boards-pro'), 403);
            }

            $board = $this->templateService->makeTemplate(
                $board_id,
                Arr::get($data, 'template_description', ''),
                Arr::get($data, 'template_category', '')
            );

            do_action('fluent_boards/board_converted_to_template', $board);

            return $this->sendSuccess([
                'board' => $board,
                'message' => __('Board has been converted to a template', 'fluent-boards-pro'),
            ], 200);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 400);
        }
    }

    /**
     * Convert a template back to a regular board
     */
    public function convertToBoard(Request $request, $board_id)
    {
        try {
            if (!PermissionManager::isBoardManager($board_id)) {
                throw new \Exception(__('You do not have permission to convert this template to a board', 'fluent-boards-pro'), 403);
            }

            $board = $this->templateService->convertToBoard($board_id);

            do_action('fluent_boards/template_converted_to_board', $board);

            return $this->sendSuccess([
                'board' => $board,
                'message' => __('Template has been converted back to a board', 'fluent-boards-pro'),
            ], 200);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 400);
        }
    }

    /**
     * Update template settings (description, category, etc.)
     */
    public function updateTemplateSettings(Request $request, $board_id)
    {
        $data = $this->validate($request->all(), [
            'template_description' => 'nullable|string',
            'template_category' => 'nullable|string',
        ]);

        try {
            if (!PermissionManager::isBoardManager($board_id)) {
                throw new \Exception(__('You do not have permission to update this template', 'fluent-boards-pro'), 403);
            }

            $board = $this->templateService->updateTemplateSettings($board_id, $data);

            return $this->sendSuccess([
                'board' => $board,
                'message' => __('Template settings updated successfully', 'fluent-boards-pro'),
            ], 200);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 400);
        }
    }

    /**
     * Check task creation status for a board created from template
     */
    public function getTaskCreationStatus(Request $request)
    {
        $boardId = $request->getSafe('board_id', 'intval');

        // The route is open to every Fluent Boards user, so the board itself must be checked.
        if (!$boardId || !PermissionManager::userHasPermission($boardId)) {
            return $this->sendError(__('You do not have access to this board', 'fluent-boards-pro'), 403);
        }

        try {
            $board = \FluentBoards\App\Models\Board::findOrFail($boardId);
            $settings = $board->settings ?: [];
            $status = Arr::get($settings, 'task_creation_status', 'completed');
            $total  = (int) Arr::get($settings, 'task_creation_total', 0);

            // Count actual tasks created so far in this board
            $created = \FluentBoards\App\Models\Task::where('board_id', $boardId)->count();

            return $this->sendSuccess([
                'status'  => $status,
                'total'   => $total,
                'created' => $created,
            ], 200);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 400);
        }
    }

    /**
     * Get a single template details with preview data
     */
    public function getTemplatePreview(Request $request)
    {
        $templateType = $request->getSafe('template_type', 'sanitize_text_field', 'default');
        $templateId = $request->getSafe('template_id');

        try {
            if ($templateType === 'default') {
                $preview = $this->templateService->getDefaultTemplatePreview($templateId);
            } else {
                $preview = $this->templateService->getUserTemplatePreview($templateId);
            }

            return $this->sendSuccess([
                'preview' => $preview,
            ], 200);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 400);
        }
    }
}
