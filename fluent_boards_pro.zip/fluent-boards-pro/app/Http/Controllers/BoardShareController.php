<?php

namespace FluentBoardsPro\App\Http\Controllers;

use FluentBoards\App\Models\Board;
use FluentBoards\Framework\Http\Request\Request;
use FluentBoardsPro\App\Services\PublicAccessService;

/**
 * Share Board drawer: public access switch and visitor settings (board managers, BoardSharePolicy).
 */
class BoardShareController extends Controller
{
    public function getPublicAccessSettings($board_id)
    {
        $board = Board::findOrFail(absint($board_id));

        return $this->sendSuccess($this->payload($board), 200);
    }

    public function togglePublicAccess(Request $request, $board_id)
    {
        $board = Board::findOrFail(absint($board_id));

        $enabled = filter_var(
            $request->getSafe('enabled', 'sanitize_text_field', false),
            FILTER_VALIDATE_BOOLEAN
        );

        $board->updateMeta('public_access_enabled', $enabled ? '1' : '');

        // Old tokens must not come back if access is turned on again; the shortcode issues a new one.
        if (!$enabled) {
            (new PublicAccessService())->revokeAccessToken($board->id);
        }

        return $this->sendSuccess(array_merge($this->payload($board), [
            'message' => $enabled
                ? __('Public access has been enabled', 'fluent-boards-pro')
                : __('Public access has been disabled', 'fluent-boards-pro'),
        ]), 200);
    }

    public function updatePublicAccessSettings(Request $request, $board_id)
    {
        $board = Board::findOrFail(absint($board_id));

        // PublicAccessService normalizes against an allow-list of keys and values.
        $settings = $request->get('settings', []);
        $settings = is_array($settings) ? $settings : [];
        (new PublicAccessService())->saveSettings($board, $settings);

        return $this->sendSuccess(array_merge($this->payload($board), [
            'message' => __('Public view settings have been updated', 'fluent-boards-pro'),
        ]), 200);
    }

    private function payload(Board $board)
    {
        $enabled = (bool)$board->getMetaByKey('public_access_enabled');

        return [
            'enabled'   => $enabled,
            'shortcode' => $enabled ? '[fluent_board_public id="' . (int)$board->id . '"]' : '',
            'settings'  => (new PublicAccessService())->getSettings($board),
        ];
    }
}
