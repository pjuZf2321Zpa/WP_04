<?php

namespace FluentBoardsPro\App\Http\Controllers;

use FluentBoards\Framework\Http\Request\Request;
use FluentBoardsPro\App\Services\PluginManager\FluentLicensing;

/**
 * The three endpoints the license screen talks to.
 *
 * Everything the UI shows is resolved here rather than in JavaScript: dates
 * have to be formatted in the site's timezone and locale, which only PHP
 * knows, and the raw license key must never reach the browser.
 */
class LicenseController extends \FluentBoards\App\Http\Controllers\Controller
{
    /**
     * Returns the admin-only license status with a display-safe license key.
     */
    public function getStatus(Request $request)
    {
        $licenseManager = FluentLicensing::getInstance();

        // true = ask the store. This is the only place that does a remote call
        // on page load, and it is an admin-only screen, so that is fine.
        $data = $licenseManager->getStatus(true);

        if (is_wp_error($data)) {
            // The store is unreachable. Fall back to what is stored locally so a
            // licensed site is not shown the "enter your license key" form over
            // a network blip - the plugin itself keeps working either way.
            $errorMessage = $data->get_error_message();

            $data = $this->formatLicenseData($licenseManager->getStatus(), $licenseManager);

            $data['connection_error'] = true;
            $data['message'] = $errorMessage;
            $data['error_message'] = $errorMessage;

            return $data;
        }

        return $this->formatLicenseData($data, $licenseManager);
    }

    public function saveLicense(Request $request)
    {
        $licenseKey = sanitize_text_field($request->get('license_key'));

        $licenseManager = FluentLicensing::getInstance();

        $response = $licenseManager->activate($licenseKey);

        if (is_wp_error($response)) {
            return $this->sendError([
                'message' => $response->get_error_message()
            ]);
        }

        return [
            'license_data' => $this->formatLicenseData($licenseManager->getStatus(), $licenseManager),
            'message'      => __('Your license key has been successfully updated', 'fluent-boards-pro')
        ];
    }

    public function deactivateLicense(Request $request)
    {
        $licenseManager = FluentLicensing::getInstance();

        $response = $licenseManager->deactivate();

        if (is_wp_error($response)) {
            return $this->sendError([
                'message' => $response->get_error_message()
            ]);
        }

        return [
            'license_data' => $this->formatLicenseData($licenseManager->getStatus(), $licenseManager),
            'message'      => __('Your license key has been successfully deactivated', 'fluent-boards-pro')
        ];
    }

    /**
     * Shape the stored license data for the license screen: everything the UI
     * shows is resolved here so the Vue side only has to render it.
     *
     * Fields are only ever added here, never renamed. A site can be running the
     * previous free plugin against this controller, and that screen reads
     * `status`, `expires` and `masked_license_key`.
     *
     * @param array $data
     * @param FluentLicensing $licenseManager
     *
     * @return array
     */
    protected function formatLicenseData($data, FluentLicensing $licenseManager)
    {
        $status = isset($data['status']) ? $data['status'] : 'unregistered';
        $expires = isset($data['expires']) ? $data['expires'] : '';
        $isLifetime = $expires === 'lifetime';

        if (empty($data['renew_url']) && in_array($status, ['expired', 'valid'], true)) {
            $data['renew_url'] = $licenseManager->getRenewUrl();
        }

        $maskedKey = $licenseManager->getMaskedLicenseKey();

        $data['purchase_url'] = $licenseManager->getConfig('purchase_url');
        $data['account_url'] = $licenseManager->getConfig('account_url');
        $data['support_url'] = $licenseManager->getConfig('support_url');
        $data['license_key_masked'] = $maskedKey;
        // Kept under its original name for free plugin versions that shipped
        // before this migration.
        $data['masked_license_key'] = $maskedKey;
        $data['product_title'] = !empty($data['product_title']) ? $data['product_title'] : $licenseManager->getConfig('plugin_title');
        $data['is_lifetime'] = $isLifetime;
        $data['expires_human'] = '';
        $data['days_remaining'] = null;
        $data['last_checked_human'] = '';

        $remoteGraceDays = isset($data['grace_period_days']) ? (int)$data['grace_period_days'] : 0;
        $data['in_grace_period'] = false;
        $data['grace_period_days'] = null;

        if (!$isLifetime && $expires && $expiresAt = strtotime($expires)) {
            $data['expires_human'] = wp_date(get_option('date_format'), $expiresAt);
            $data['days_remaining'] = (int)floor(($expiresAt - time()) / DAY_IN_SECONDS);
            $data = $this->attachGraceData($data, $expiresAt, $status, $remoteGraceDays);
        }

        if (!empty($data['last_checked']) && $lastChecked = strtotime($data['last_checked'])) {
            $data['last_checked_human'] = sprintf(
            /* translators: %s: human readable time difference, e.g. "2 mins" */
                __('%s ago', 'fluent-boards-pro'),
                human_time_diff($lastChecked)
            );
        }

        // Never let these reach the browser. The masked key above is what the
        // screen shows, and the activation hash is a credential of its own.
        unset($data['license_key'], $data['activation_hash']);

        return $data;
    }

    /**
     * The store keeps a license usable for a grace window after its expiry date,
     * so a renewal that lands a few days late never breaks a live site. It
     * reports that window as a plain "valid" status without saying why, which
     * reads as a contradiction on screen: an Active badge sitting next to an
     * expiry date that has already passed. Resolve the window here so the screen
     * can name it.
     *
     * Only the fact of the window is reported, never its end date: the length
     * below is our assumption about the store's default, so a date built on it
     * would be a promise we cannot keep if the store ever filters it.
     *
     * @param array $data
     * @param int $expiresAt
     * @param string $status
     * @param int $remoteGraceDays grace length the store reported, 0 when it reported none
     *
     * @return array
     */
    protected function attachGraceData($data, $expiresAt, $status, $remoteGraceDays = 0)
    {
        if ($status !== 'valid' || $expiresAt > time()) {
            return $data;
        }

        // Prefer the store's own number when it reports one; the fallback below
        // only mirrors its current default, and the store may filter it.
        $graceDays = $remoteGraceDays;

        if ($graceDays < 1) {
            $graceDays = (int)apply_filters('fluent_boards/license_grace_period_days', 15);
        }

        if ($graceDays < 1) {
            return $data;
        }

        $graceEndsAt = $expiresAt + ($graceDays * DAY_IN_SECONDS);

        if ($graceEndsAt <= time()) {
            return $data; // Window already closed - the store will report it expired.
        }

        $data['in_grace_period'] = true;
        $data['grace_period_days'] = $graceDays;

        return $data;
    }
}
