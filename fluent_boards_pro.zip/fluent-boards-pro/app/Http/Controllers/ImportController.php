<?php

namespace FluentBoardsPro\App\Http\Controllers;

use FluentBoards\App\Http\Controllers\ImportController as CoreImportController;
use FluentBoards\Framework\Http\Request\Request;
use FluentBoards\Framework\Support\Arr;
use FluentBoardsPro\App\Services\Constant;
use FluentBoardsPro\App\Services\TrelloImporter;
use FluentBoardsPro\App\Services\AsanaImporter;

class ImportController extends CoreImportController
{
    /** Import a supported third-party JSON export through the Pro importer. */
    protected function importExternalSource($source, $importData)
    {
        if ($source === 'Trello') {
            return $this->importFromTrello($importData);
        }

        if ($source === 'Asana') {
            return $this->importFromAsana($importData);
        }

        return null;
    }

    /** Validate and import a Trello JSON export. */
    private function importFromTrello($importData)
    {
        try {
            if (!isset($importData['url'])) {
                return null;
            } else {
                if (!str_contains($importData['url'], Constant::TRELLO_URL)) {
                    return null;
                } else {
                    return TrelloImporter::process($importData);
                }
            }
        } catch (\Exception $e) {
            throw $e;
        }
    }

    /** Validate and import an Asana JSON export. */
    private function importFromAsana($importData)
    {
        try {
            if (!isset($importData['data'])) {
                return null;
            } else {
                if (!str_contains($importData['data'][0]['permalink_url'], Constant::ASANA_URL)) {
                    return null;
                } else {
                    return AsanaImporter::process($importData);
                }
            }
        } catch (\Exception $e) {
            throw $e;
        }
    }
    public function getTrelloBoards(Request $request)
    {
        $apiKey = sanitize_text_field($request->get('api_key'));
        $token = sanitize_text_field($request->get('token'));

        if (!$apiKey || !$token) {
            return $this->sendError([
                'message' => __('API Key and Token are required.', 'fluent-boards-pro')
            ]);
        }

        $boards = TrelloImporter::fetchBoards($apiKey, $token);

        if (isset($boards['error'])) {
            return $this->sendError([
                'message' => $boards['error']
            ]);
        }

        return $this->sendSuccess([
            'boards' => $boards
        ]);
    }

    public function importTrelloBoard(Request $request)
    {
        $apiKey = sanitize_text_field($request->get('api_key'));
        $token = sanitize_text_field($request->get('token'));
        $trelloBoardId = sanitize_text_field($request->get('trello_board_id'));
        $importUsers = filter_var($request->get('import_users', false), FILTER_VALIDATE_BOOLEAN);

        if (!$apiKey || !$token || !$trelloBoardId) {
            return $this->sendError([
                'message' => __('API Key, Token, and Board ID are required.', 'fluent-boards-pro')
            ]);
        }

        $result = TrelloImporter::startAsyncImport($apiKey, $token, $trelloBoardId, [
            'import_users' => $importUsers,
            'user_id' => get_current_user_id(),
        ]);

        if (is_array($result) && isset($result['error'])) {
            return $this->sendError([
                'message' => $result['error']
            ]);
        }

        return $this->sendSuccess([
            'message' => __('Trello import started.', 'fluent-boards-pro'),
            'import'  => $result,
        ]);
    }

    public function getTrelloImportStatus(Request $request)
    {
        $importId = sanitize_text_field($request->get('import_id'));

        if (!$importId) {
            return $this->sendError([
                'message' => __('Import ID is required.', 'fluent-boards-pro')
            ]);
        }

        $status = TrelloImporter::getImportStatus($importId, get_current_user_id());

        if (isset($status['error'])) {
            return $this->sendError([
                'message' => $status['error']
            ], $status['http_status'] ?? 400);
        }

        return $this->sendSuccess([
            'import' => $status
        ]);
    }

    /** Continue an owned Trello session without creating a new destination board. */
    public function resumeTrelloImport(Request $request)
    {
        $importId = sanitize_text_field($request->get('import_id'));

        if (!$importId) {
            return $this->sendError([
                'message' => __('Import ID is required.', 'fluent-boards-pro')
            ]);
        }

        $status = TrelloImporter::resumeAsyncImport($importId, get_current_user_id());

        if (isset($status['error'])) {
            return $this->sendError([
                'message' => $status['error']
            ]);
        }

        return $this->sendSuccess([
            'import' => $status
        ]);
    }

    /** Retry only failed covers belonging to the current user's completed import. */
    public function retryTrelloCovers(Request $request)
    {
        $importId = sanitize_text_field($request->get('import_id'));
        $result = TrelloImporter::retryFailedCovers(
            $importId,
            sanitize_text_field($request->get('api_key')),
            sanitize_text_field($request->get('token')),
            get_current_user_id()
        );
        if (isset($result['error'])) {
            return $this->sendError(['message' => $result['error']], 400);
        }
        return $this->sendSuccess(['import' => $result]);
    }

    public function getAsanaWorkspaces(Request $request)
    {
        $pat = sanitize_text_field($request->get('pat'));

        if (!$pat) {
            return $this->sendError([
                'message' => __('Personal Access Token is required.', 'fluent-boards-pro')
            ]);
        }

        $workspaces = AsanaImporter::fetchWorkspaces($pat);

        if (is_array($workspaces) && isset($workspaces['error'])) {
            return $this->sendError([
                'message' => $workspaces['error']
            ]);
        }

        return $this->sendSuccess([
            'workspaces' => $workspaces
        ]);
    }

    public function getAsanaProjects(Request $request)
    {
        $pat = sanitize_text_field($request->get('pat'));
        $workspaceGid = sanitize_text_field($request->get('workspace_gid'));

        if (!$pat || !$workspaceGid) {
            return $this->sendError([
                'message' => __('Personal Access Token and Workspace are required.', 'fluent-boards-pro')
            ]);
        }

        $projects = AsanaImporter::fetchProjects($pat, $workspaceGid);

        if (is_array($projects) && isset($projects['error'])) {
            return $this->sendError([
                'message' => $projects['error']
            ]);
        }

        return $this->sendSuccess([
            'projects' => $projects
        ]);
    }

    public function importAsanaProject(Request $request)
    {
        $pat = sanitize_text_field($request->get('pat'));
        $projectGid = sanitize_text_field($request->get('project_gid'));
        $folderId = $request->get('folder_id');
        $folderId = $folderId ? intval($folderId) : null;

        if (!$pat || !$projectGid) {
            return $this->sendError([
                'message' => __('Personal Access Token and Project are required.', 'fluent-boards-pro')
            ]);
        }

        $result = AsanaImporter::fetchAndImport($pat, $projectGid);

        if (is_array($result) && isset($result['error'])) {
            return $this->sendError([
                'message' => $result['error']
            ]);
        }

        if ($folderId && class_exists('FluentBoards\App\Services\FolderService')) {
            try {
                (new \FluentBoards\App\Services\FolderService())
                    ->addBoardToFolder($folderId, [$result->id]);
            } catch (\Throwable $e) {
                // Non-fatal — board still exists, just not in the folder.
            }
        }

        return $this->sendSuccess([
            'message'  => __('Project imported successfully from Asana', 'fluent-boards-pro'),
            'board_id' => $result->id,
        ]);
    }
}
