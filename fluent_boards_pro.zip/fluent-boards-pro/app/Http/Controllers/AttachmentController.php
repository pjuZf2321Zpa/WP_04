<?php

namespace FluentBoardsPro\App\Http\Controllers;

use FluentBoards\App\Services\Constant;
use FluentBoards\App\Services\Helper;

use FluentBoards\App\Services\Libs\FileSystem;
use FluentBoards\App\Services\UploadService;
use FluentBoards\Framework\Http\Request\Request;
use FluentBoards\Framework\Support\Arr;
use FluentBoardsPro\App\Services\AttachmentService;
use FluentBoardsPro\App\Services\HelperInstaller;
use Exception;

class AttachmentController extends Controller
{

    protected $attachmentService;
    public function __construct(AttachmentService $attachmentService)
    {
        parent::__construct();
        $this->attachmentService = $attachmentService;
    }

    public function deleteTaskAttachment($task_id, $attachment_id)
    {
        try {
            return $this->sendSuccess([
                'message'     => __('Task attachment has been deleted', 'fluent-boards-pro'),
                'attachments' => $this->attachmentService->deleteTaskAttachment($task_id, $attachment_id),
            ], 200);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 404);
        }
    }

    public function updateTaskAttachment($task_id, $attachment_id, Request $request)
    {
        $attachMentData = $this->taskAttachmentSanitizeAndValidate($request->all(), [
            'title' => 'required|string',
        ]);
        try {
            return $this->sendSuccess([
                'message'    => __('Task attachment has been updated', 'fluent-boards-pro'),
                'attachment' => $this->attachmentService->updateTaskAttachment($task_id, $attachment_id, $attachMentData['title']),
            ], 200);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 404);
        }
    }

    public function getAttachments($board_id, $task_id)
    {
        try {
            $task = $this->attachmentService->resolveTaskForCurrentUser($task_id, $board_id);
            return $this->sendSuccess([
                'attachments' => $task->attachments
            ]);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 400);
        }
    }

    public function addTaskAttachment(Request $request, $task_id)
    {
        $attachmentData = $this->taskAttachmentSanitizeAndValidate($request->all(), [
            'title' => 'nullable|string',
            'url'   => 'required|url',
        ]);
        try {
            $attachmentData['type'] = 'url';
            return $this->sendSuccess([
                'message'    => __('Attachment has been added to task', 'fluent-boards-pro'),
                'attachment' => $this->attachmentService->handleAttachment($task_id, $attachmentData),
            ], 200);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 404);
        }
    }

    public function addTaskAttachmentFile(Request $request, $board_id, $task_id)
    {
        try {
            $this->attachmentService->resolveTaskForCurrentUser($task_id, $board_id);

            $files = Arr::get($request->files(), 'file', []);

            if (!$files) {
                throw new \Exception(__('File is empty.', 'fluent-boards-pro'));
            }

            if (!is_array($files)) {
                $files = [$files];
            }

            $uploadService = new UploadService();
            $attachments = [];

            foreach ($files as $file) {
                if (!$file) {
                    continue;
                }

                $fileArray = $file->toArray();
                $uploadService->validateFile($fileArray);
                if (!AttachmentService::getMimeTypeFromFileName(Arr::get($fileArray, 'name', ''))) {
                    throw new \Exception(__('File type not supported', 'fluent-boards-pro'));
                }

                $uploadInfo = UploadService::handleFileUpload($file, $board_id, $task_id);
                $fileData = $uploadInfo[0];

                // Call the unified attachment handler
                $attachments[] = $this->attachmentService->handleAttachment($task_id, $fileData, $file);
            }

            if (empty($attachments)) {
                throw new \Exception(__('File upload failed.', 'fluent-boards-pro'));
            }

            return $this->sendSuccess([
                'message'    => __('Task attachment has been added', 'fluent-boards-pro'),
                'attachments' => $attachments
            ], 200);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 400);
        }


    }

    /**
     * Receive attachment chunks only after preparing their storage protection.
     */
    public function addTaskAttachmentFileChunk(Request $request, $board_id, $task_id)
    {
        if (!HelperInstaller::supportsProtectedUploads()) {
            return $this->sendError(HelperInstaller::getCoreUpdateMessage(), 409);
        }

        try {
            $this->attachmentService->resolveTaskForCurrentUser($task_id, $board_id);

            $chunk = Arr::get($request->files(), 'chunk');
            if (!$chunk) {
                throw new \Exception(__('Chunk data is missing.', 'fluent-boards-pro'));
            }

            $uploadService = new UploadService();
            $fileName = sanitize_file_name($request->get('file_name', ''));
            $fileSize = absint($request->get('file_size', 0));
            $chunkIndex = absint($request->get('chunk_index', 0));
            $totalChunks = absint($request->get('total_chunks', 0));
            $uploadId = sanitize_file_name($request->get('upload_id', ''));
            $canonicalMimeType = AttachmentService::getMimeTypeFromFileName($fileName);

            if (!$fileName || !$totalChunks || !$uploadId || $chunkIndex >= $totalChunks) {
                throw new \Exception(__('Invalid chunk upload request.', 'fluent-boards-pro'));
            }

            if ($fileSize > $uploadService->getFileUploadLimit()) {
                throw new \Exception(__('File size is too large', 'fluent-boards-pro'));
            }

            if (!$uploadService->isFileTypeSupported(['name' => $fileName]) || !$canonicalMimeType) {
                throw new \Exception(__('File type not supported', 'fluent-boards-pro'));
            }

            $chunk = $chunk->toArray();
            if (empty($chunk['tmp_name']) || !file_exists($chunk['tmp_name'])) {
                throw new \Exception(__('Chunk data is missing.', 'fluent-boards-pro'));
            }

            $uploadDir = wp_upload_dir();
            if (empty($uploadDir['basedir']) || empty($uploadDir['baseurl'])) {
                throw new \Exception(__('Upload directory information not available.', 'fluent-boards-pro'));
            }

            // Frontend uploads can arrive before an administrator visits wp-admin.
            if (!FileSystem::installUploadProtectionRules()) {
                throw new Exception(__('Could not create the upload directory. Please check directory permissions.', 'fluent-boards-pro'));
            }

            $uploadFolder = apply_filters('fluent_boards/upload_folder_name', FLUENT_BOARDS_UPLOAD_DIR);
            $chunkDir = trailingslashit(FileSystem::getDir()) . 'chunks/task_attachments/';
            if (!file_exists($chunkDir)) {
                wp_mkdir_p($chunkDir);
            }

            $sessionName = AttachmentService::getChunkUploadSessionName([
                'upload_id'    => $uploadId,
                'user_id'      => get_current_user_id(),
                'board_id'     => $board_id,
                'task_id'      => $task_id,
                'file_name'    => $fileName,
                'file_size'    => $fileSize,
                'total_chunks' => $totalChunks,
            ]);
            $chunkPath = $chunkDir . $sessionName . '.part';
            $statePath = $chunkDir . $sessionName . '.json';
            $lockPath = $chunkDir . $sessionName . '.lock';
            $storedName = '';
            $storedPath = '';
            $lockHandle = fopen($lockPath, 'c');

            if (!$lockHandle || !flock($lockHandle, LOCK_EX)) {
                throw new \Exception(__('File upload failed.', 'fluent-boards-pro'));
            }

            try {
                if ($chunkIndex === 0) {
                    if (file_exists($chunkPath)) {
                        wp_delete_file($chunkPath);
                    }
                    $state = ['next_chunk_index' => 0];
                } else {
                    $state = file_exists($statePath) ? json_decode(file_get_contents($statePath), true) : null;
                    if (!is_array($state)) {
                        throw new \Exception(__('Invalid chunk upload request.', 'fluent-boards-pro'));
                    }
                }

                if ((int) ($state['next_chunk_index'] ?? 0) !== $chunkIndex) {
                    throw new \Exception(__('Invalid chunk upload request.', 'fluent-boards-pro'));
                }

                $chunkContents = file_get_contents($chunk['tmp_name']);
                if ($chunkContents === false || file_put_contents($chunkPath, $chunkContents, FILE_APPEND) === false) {
                    throw new \Exception(__('File upload failed.', 'fluent-boards-pro'));
                }

                if (filesize($chunkPath) > $fileSize) {
                    wp_delete_file($chunkPath);
                    wp_delete_file($statePath);
                    throw new \Exception(__('File upload failed.', 'fluent-boards-pro'));
                }

                $state['next_chunk_index'] = $chunkIndex + 1;

                if (($chunkIndex + 1) < $totalChunks) {
                    if (file_put_contents($statePath, json_encode($state)) === false) {
                        wp_delete_file($chunkPath);
                        throw new \Exception(__('File upload failed.', 'fluent-boards-pro'));
                    }

                    return $this->sendSuccess([
                        'chunk_index' => $chunkIndex,
                        'is_complete' => false,
                    ], 200);
                }

                wp_delete_file($statePath);

                if (!file_exists($chunkPath) || filesize($chunkPath) !== $fileSize) {
                    wp_delete_file($chunkPath);
                    throw new \Exception(__('File upload failed.', 'fluent-boards-pro'));
                }

                $boardDir = FileSystem::setSubDir('board_' . absint($board_id))->getDir();
                if (!file_exists($boardDir)) {
                    wp_mkdir_p($boardDir);
                }

                $storedName = wp_unique_filename($boardDir, apply_filters('fluent_boards/uploaded_file_name_prefix', wp_generate_uuid4() . '-') . $fileName);
                $storedPath = trailingslashit($boardDir) . $storedName;
                if (!rename($chunkPath, $storedPath)) {
                    wp_delete_file($chunkPath);
                    throw new \Exception(__('File upload failed.', 'fluent-boards-pro'));
                }
            } finally {
                // Keep the path stable: another request may already hold or wait on this inode.
                flock($lockHandle, LOCK_UN);
                fclose($lockHandle);
            }

            $detectedMimeType = AttachmentService::detectFileMimeType($storedPath);
            $responsePolicy = AttachmentService::getAttachmentResponsePolicy($fileName, $detectedMimeType);

            // Files that normally render inline must match their declared extension.
            if (
                in_array($canonicalMimeType, AttachmentService::VERIFIED_INLINE_MIME_TYPES, true) &&
                $responsePolicy['disposition'] !== 'inline'
            ) {
                wp_delete_file($storedPath);
                throw new \Exception(__('File contents do not match the file extension.', 'fluent-boards-pro'));
            }

            $baseUrl = trailingslashit($uploadDir['baseurl']) . trim($uploadFolder, '/') . '/board_' . absint($board_id) . '/';
            $fileData = [
                'name'      => $fileName,
                'size'      => $fileSize,
                'type'      => $canonicalMimeType,
                'file'      => $storedName,
                'url'       => $baseUrl . rawurlencode($storedName),
                'full_path' => $storedPath,
                'driver'    => 'local',
            ];

            $fileArray = [
                'name'          => $fileName,
                'type'          => $fileData['type'],
                'tmp_name'      => $storedPath,
                'size'          => $fileSize,
                'size_in_bytes' => $fileSize,
            ];

            $attachment = $this->attachmentService->handleAttachment($task_id, $fileData, $fileArray);

            return $this->sendSuccess([
                'message'     => __('Task attachment has been added', 'fluent-boards-pro'),
                'is_complete' => true,
                'attachments' => [$attachment],
            ], 200);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 400);
        }
    }

    private function taskAttachmentSanitizeAndValidate($data, array $rules = [])
    {
        $data = Helper::sanitizeTask($data);
        return $this->validate($data, $rules);
    }

}
