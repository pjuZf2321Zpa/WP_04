<?php

namespace FluentBoardsPro\App\Http\Controllers;

use FluentBoards\App\Models\Board;
use FluentBoards\App\Models\Meta;
use FluentBoards\App\Models\Stage;
use FluentBoards\App\Models\User;
use FluentBoards\App\Services\BoardService;
use FluentBoards\App\Services\Constant;
use FluentBoards\App\Services\StageService;
use FluentBoards\App\Services\Helper;
use FluentBoards\App\Services\LabelService;
use FluentBoards\App\Services\PermissionManager;
use FluentBoards\App\Services\TaskService;
use FluentBoards\Framework\Http\Request\Request;
use FluentBoards\Framework\Support\Arr;
use FluentBoardsPro\App\Services\CustomFieldService;
use FluentBoardsPro\App\Services\ProTaskService;
use FluentBoardsPro\App\Services\ProHelper;

class ProBoardController extends Controller
{
    /**
     * Apply a known image preset using the existing background lifecycle.
     */
    public function setBoardBackground(Request $request, $board_id)
    {
        $presetId = $request->get('preset_id');
        $preset = null;
        foreach (ProHelper::getBoardBackgroundPresets() as $image) {
            if ($presetId === $image['id'] || $presetId === (string) $image['id']) {
                $preset = $image;
                break;
            }
        }
        if (!$preset) {
            return $this->sendError(__('Background image not found.', 'fluent-boards-pro'), 400);
        }
        $boardId = absint($board_id);
        $board = Board::find($boardId);
        if (!$board) {
            return $this->sendError(__('Board not found.', 'fluent-boards-pro'), 404);
        }

        $oldBackground = $board->background;
        // String IDs prevent preset changes from targeting uploaded attachment IDs.
        $board->background = [
            'id' => 'preset_image_' . $presetId,
            'image_url' => $preset['original'],
            'is_image' => true,
            'color' => null,
        ];
        $board->save();
        do_action('fluent_boards/board_background_updated', $boardId, $oldBackground);

        return $this->sendSuccess([
            'message' => __('Background updated successfully', 'fluent-boards-pro'),
            'background' => $board->background,
        ]);
    }

    public function createBoard(Request $request)
    {
        $boardData = $this->boardSanitizeAndValidate($request->get('board'), [
            'title'       => 'required|string',
            'description' => 'nullable',
            'type'        => 'required|string',
            'currency'    => 'required|string',
            'slug'        => 'required|string',
        ]);

        $boardService = new BoardService();
        $stageService = new StageService();

        try {
            $board = $boardService->createBoard($boardData);
            (new LabelService())->createDefaultLabel($board->id);
            $type = ucfirst($boardData['type']);

            if (isset($boardData['is_roadmap']) && $boardData['is_roadmap'] == 'yes') {
                $stageService->createRoadmapStages($board, $boardData['stages']);
            } else {
                $stageService->createDefaultStages($board);
            }

            do_action('fluent_boards/board_created', $board);

            // translators: This placeholder is for the type of board (e.g., "project" or "task").
            $message = sprintf(__('%s board has been created', 'fluent-boards-pro'), esc_html($type));

            return $this->sendSuccess([
                'message' => $message,
                'board'   => $board,
            ]);

        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 400);
        }
    }


    private function boardSanitizeAndValidate($data, array $rules = [])
    {
        $data = Helper::sanitizeBoard($data);

        return $this->validate($data, $rules);
    }

    public function sendInvitationToBoard(Request $request, $board_id)
    {
        $data = $this->validate($request->all(), [
            'email'  => 'required|email',
            'role'   => 'in:manager,member,viewer'
        ]);

        if (!PermissionManager::isBoardManager($board_id)) {
            return $this->sendError(__('You do not have permission to invite users to this board.', 'fluent-boards-pro'), 403);
        }

        $boardService = new BoardService();

        try {
            $role = $data['role'] ?? ProHelper::getBoardInvitationRole($board_id, $data['email']);
            $user = $boardService->sendInvitationToBoard($board_id, $data['email'], $role);

            if ($user) {
                return $this->sendError([
                    'message' => __('Already a wordpress member', 'fluent-boards-pro'),
                ], 304);
            }

            return $this->sendSuccess([
                'message' => __('Invitation sent successfully!', 'fluent-boards-pro'),
            ], 200);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 404);
        }
    }

    public function getInvitations($board_id)
    {
        try {
            $boardService = new BoardService();

            $invitations = $boardService->getInvitations($board_id);

            return $this->sendSuccess([
                'invitations' => $invitations
            ], 200);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 404);
        }
    }

    public function deleteInvitation($board_id, $invitation_id)
    {
        try {
            $boardService = new BoardService();

            if (!defined('FLUENT_BOARDS_PLUGIN_VERSION')) {
                return $this->sendError([
                    'message' => __('Please update Fluent Boards before deleting invitations.', 'fluent-boards-pro'),
                ], 409);
            }

            $deleted = $boardService->deleteInvitation($board_id, $invitation_id);

            if (!$deleted) {
                return $this->sendError([
                    'message' => __('Invitation not found.', 'fluent-boards-pro'),
                ], 404);
            }

            return $this->sendSuccess([
                'message' => __('Invitation deleted successfully!', 'fluent-boards-pro'),
            ], 200);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 404);
        }
    }

    public function updateStageTemplate($board_id, $stage_id)
    {
        try{
            $this->findStageOnBoard($stage_id, $board_id);
            $stageService = new StageService();

            $stage = $stageService->updateStageTemplate($stage_id);

            return $this->sendSuccess([
                'stage' => $stage,
                'message'      => __('Stage updated successfully', 'fluent-boards-pro'),
            ], 200);

        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 400);
        }
    }

    public function getTemplateStages(Request $request)
    {
        try {
            $stageService = new StageService();

            $userId   = get_current_user_id();
            $templateStages = [];

            if (PermissionManager::isAdmin($userId)) {
                $relatedBoardsQuery = Board::query()->where('type', 'to-do')->pluck('id');
                $relatedStages = Stage::whereIn('board_id', $relatedBoardsQuery)->with('board')->get();
                foreach ($relatedStages as $stage)
                {
                    $isThisStageTemplate = Arr::get($stage->settings, 'is_template', false);
                    if($isThisStageTemplate) {
                        $templateStages[] = $stage;
                    }
                }
            } else {
                $currentUser = User::find($userId);
                $relatedBoardsQuery = $currentUser->whichBoards->pluck('id');
                $relatedStages = Stage::whereIn('board_id', $relatedBoardsQuery)->with('board')->get();
                foreach ($relatedStages as $stage)
                {
                    $isThisStageTemplate = Arr::get($stage->settings, 'is_template', false);
                    if($isThisStageTemplate){
                        $templateStages[] = $stage;
                    }
                }
            }

            return $this->sendSuccess([
                'stages' => $templateStages,
            ], 200);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 404);
        }
    }
    public function getTemplateTasks()
    {
        try {
            return $this->sendSuccess((new ProTaskService())->getTemplateTasks());
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 400);
        }
    }

    public function createFromTemplate(Request $request, $board_id, $task_id)
    {
        $taskData = $this->taskSanitizeAndValidate($request->all(), [
            'title'          => 'required|string',
            'board_id'       => 'required|numeric',
            'stage_id'       => 'required|numeric',
            'assignee'       => 'required',
            'subtask'        => 'required',
            'label'          => 'required',
            'attachment'     => 'required',
        ]);
        try {
            if ((int) $taskData['board_id'] !== absint($board_id)) {
                throw new \Exception(esc_html__('Board id is not valid', 'fluent-boards-pro'));
            }

            $templateTask = \FluentBoards\App\Models\Task::find($task_id);
            if (!$templateTask || !PermissionManager::userHasPermission($templateTask->board_id)) {
                throw new \Exception(esc_html__('Template task not found', 'fluent-boards-pro'));
            }

            $this->findStageOnBoard($taskData['stage_id'], $board_id);
            $task = (new ProTaskService())->createFromTemplate($task_id, $taskData);

            return $this->sendSuccess([
                'task'         => $task,
                'message'      => __('Task has been successfully created', 'fluent-boards-pro'),
                'updatedTasks' => (new TaskService())->getLastOneMinuteUpdatedTasks($task->board_id)
            ], 201);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 400);
        }
    }

    public function setDefaultAssignees(Request $request, $board_id, $stage_id)
    {
        $assigneeIds = $request->get('assigneeIds');
        try{
            $this->findStageOnBoard($stage_id, $board_id);
            $stageService = new StageService();
            $stage = $stageService->setDefaultAssignees($stage_id, $assigneeIds);
            if ($stage) {
                $taskService = new TaskService();
                $taskService->setDefaultAssigneesToEveryTasks($stage);
            }
            return $this->sendSuccess([
                'stage' => $stage,
                'message'      => __('Stage updated successfully', 'fluent-boards-pro'),
            ], 200);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 400);
        }
    }

    public function setDefaultWatchers(Request $request, $board_id, $stage_id)
    {
        $watcherIds = $request->get('watcherIds');
        try{
            $this->findStageOnBoard($stage_id, $board_id);
            $stageService = new StageService();
            $stage = $stageService->setDefaultWatchers($stage_id, $watcherIds);
            if ($stage) {
                $taskService = new ProTaskService();
                $taskService->setDefaultWatchersToEveryTasks($stage);
            }
            return $this->sendSuccess([
                'stage' => $stage,
                'message'      => __('Stage updated successfully', 'fluent-boards-pro'),
            ], 200);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 400);
        }
    }

    private function taskSanitizeAndValidate($data, array $rules = [])
    {
        $data = Helper::sanitizeTask($data);

        return $this->validate($data, $rules);
    }

    /**
     * Resolve a stage only when it belongs to the requested board.
     *
     * @param int $stageId
     * @param int $boardId
     * @return Stage
     * @throws \Exception
     */
    private function findStageOnBoard($stageId, $boardId)
    {
        $stage = Stage::where('id', absint($stageId))
            ->where('board_id', absint($boardId))
            ->first();

        if (!$stage) {
            throw new \Exception(esc_html__('Stage not found', 'fluent-boards-pro'));
        }

        return $stage;
    }
}
