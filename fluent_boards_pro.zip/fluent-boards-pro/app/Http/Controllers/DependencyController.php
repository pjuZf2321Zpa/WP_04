<?php

namespace FluentBoardsPro\App\Http\Controllers;

use FluentBoards\Framework\Http\Request\Request;
use FluentBoardsPro\App\Services\DependencyService;

class DependencyController extends Controller
{
    private DependencyService $dependencyService;

    public function __construct(DependencyService $dependencyService)
    {
        parent::__construct();
        $this->dependencyService = $dependencyService;
    }

    /**
     * GET /projects/{board_id}/dependencies
     * Returns all dependencies for the board (Gantt chart needs this).
     */
    public function getBoardDependencies(Request $request, $boardId)
    {
        $dependencies = $this->dependencyService->getBoardDependencies($boardId);

        return [
            'dependencies' => $dependencies,
        ];
    }

    /**
     * GET /projects/{board_id}/tasks/{task_id}/dependencies
     * Returns predecessors and successors for a single task.
     */
    public function getTaskDependencies(Request $request, $boardId, $taskId)
    {
        $dependencies = $this->dependencyService->getTaskDependencies($taskId, $boardId);

        return [
            'predecessors' => $dependencies['predecessors'],
            'successors'   => $dependencies['successors'],
        ];
    }

    /**
     * POST /projects/{board_id}/tasks/{task_id}/dependencies
     * Body: { predecessor_task_id: int, successor_task_id: int }
     */
    public function addDependency(Request $request, $boardId, $taskId)
    {
        $predecessorId = intval($request->get('predecessor_task_id'));
        $successorId   = intval($request->get('successor_task_id'));

        try {
            $result = $this->dependencyService->addDependency($predecessorId, $successorId, $boardId);
            return $result;
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => $e->getMessage(),
            ], $e->getCode() ?: 422);
        }
    }

    /**
     * DELETE /projects/{board_id}/tasks/{task_id}/dependencies/{related_task_id}
     */
    public function removeDependency(Request $request, $boardId, $taskId, $relatedTaskId)
    {
        $result = $this->dependencyService->removeDependency($taskId, $relatedTaskId, $boardId);

        return $result;
    }
}
