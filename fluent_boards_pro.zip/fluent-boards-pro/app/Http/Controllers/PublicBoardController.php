<?php

namespace FluentBoardsPro\App\Http\Controllers;

use FluentBoards\App\Models\Board;
use FluentBoards\App\Models\Stage;
use FluentBoards\App\Services\PublicTaskSerializer;
use FluentBoardsPro\App\Services\PublicAccessService;
use FluentBoards\Framework\Http\Request\Request;

/**
 * Read-only endpoints for the logged-out public board view (Pro).
 *
 * Every response is built from explicit allow-lists, and every exposure setting is
 * enforced here (queries + 404s); the settings sent to the browser are display hints only.
 * PublicBoardPolicy has already validated the method, token and opt-in for the URL board.
 */
class PublicBoardController extends Controller
{
    const STAGE_PAGE_SIZE = 20;

    private $publicAccessService;

    private $serializer;

    public function __construct()
    {
        parent::__construct();
        $this->publicAccessService = new PublicAccessService();
        $this->serializer = new PublicTaskSerializer();
    }

    public function find($board_id)
    {
        $board_id = absint($board_id);
        $board = Board::findOrFail($board_id);
        $settings = $this->publicAccessService->getSettings($board);
        $stageIds = $this->publicAccessService->getExposedStageIds($board->id, $settings);

        $stages = Stage::where('board_id', $board->id)
            ->whereIn('id', $stageIds ?: [0])
            ->orderBy('position', 'ASC')
            ->get()
            ->map(function ($stage) {
                return [
                    'id'       => (int)$stage->id,
                    'title'    => $stage->title,
                    'position' => (float)$stage->position,
                    'color'    => $stage->color,
                    'bg_color' => $stage->bg_color,
                ];
            })
            ->values()
            ->toArray();

        $background = maybe_unserialize($board->background);

        $data = [
            'id'          => (int)$board->id,
            'title'       => $board->title,
            'background'  => $background,
            'stages'      => $stages,
            'labels'      => [],
            'users'       => [],
        ];

        if ($settings['show_labels']) {
            $data['labels'] = $board->labels()->get()->map(function ($label) {
                return $this->serializer->formatLabel($label);
            })->values()->toArray();
        }

        if ($settings['show_members']) {
            $members = $board->users()->get();
            $data['users'] = $this->serializer->sanitizeUsers($members);
        }

        return [
            'board'    => $data,
            'settings' => $settings,
        ];
    }

    public function getTasksByBoard($board_id)
    {
        $board_id = absint($board_id);
        $board = Board::findOrFail($board_id);
        $settings = $this->publicAccessService->getSettings($board);
        $stageIds = $this->publicAccessService->getExposedStageIds($board->id, $settings);

        $query = $this->publicAccessService->visibleTasksQuery($board->id, $settings, $stageIds);
        $tasks = $this->serializer->withCardRelations($query, $settings)
            ->orderBy('position', 'ASC')
            ->get();
        $cards = $this->serializer->formatCards($tasks, $settings);

        return [
            'tasks' => $cards,
        ];
    }

    public function getTasksByBoardStage($board_id)
    {
        $board_id = absint($board_id);
        $board = Board::findOrFail($board_id);
        $settings = $this->publicAccessService->getSettings($board);
        $stageIds = $this->publicAccessService->getExposedStageIds($board->id, $settings);

        $tasks = [];
        $paginationByStage = [];

        foreach ($stageIds as $stageId) {
            $stageQuery = $this->publicAccessService->visibleTasksQuery($board->id, $settings, [$stageId]);
            $totalCount = (clone $stageQuery)->count();

            $stageTasks = $this->serializer->withCardRelations($stageQuery, $settings)
                ->orderBy('position', 'ASC')
                ->orderBy('id', 'ASC')
                ->limit(self::STAGE_PAGE_SIZE)
                ->get();

            $stageCards = $this->serializer->formatCards($stageTasks, $settings);
            $tasks = array_merge($tasks, $stageCards);

            $startCursor = $stageTasks->count() ? (float) $stageTasks->first()->position : null;
            $endCursor = $stageTasks->count() ? (float) $stageTasks->last()->position : null;
            $hasMoreAfter = $totalCount > $stageTasks->count();

            $paginationByStage[$stageId] = [
                'stage_id' => (int) $stageId,
                'total_count' => (int) $totalCount,
                'limit' => self::STAGE_PAGE_SIZE,
                'direction' => 'next',
                'cursor' => null,
                'has_more' => $hasMoreAfter,
                'has_more_before' => false,
                'has_more_after' => $hasMoreAfter,
                'start_cursor' => $startCursor,
                'end_cursor' => $endCursor,
                'start_cursor_id' => $stageTasks->count() ? (int) $stageTasks->first()->id : null,
                'end_cursor_id' => $stageTasks->count() ? (int) $stageTasks->last()->id : null,
            ];
        }

        return [
            'tasks'               => $tasks,
            'pagination_by_stage' => $paginationByStage,
        ];
    }

    /**
     * Page of one exposed stage, ordered by position and task ID in either direction.
     */
    public function getStageTasksPage(Request $request, $board_id)
    {
        $board_id = absint($board_id);
        $board = Board::findOrFail($board_id);
        $settings = $this->publicAccessService->getSettings($board);

        $stageId = $request->getSafe('stage_id', 'intval');
        $cursor = $request->getSafe('cursor', 'floatval');
        $cursorId = $request->getSafe('cursor_id', 'absint', 0);
        $direction = $request->getSafe('direction', 'sanitize_text_field', 'next');
        $limit = $request->getSafe('limit', 'intval', self::STAGE_PAGE_SIZE);

        if (!in_array($direction, ['next', 'prev'], true)) {
            return $this->sendError(esc_html__('Invalid direction', 'fluent-boards'), 400);
        }

        $limit = max(1, min(100, $limit));
        $stageIds = $this->publicAccessService->getExposedStageIds($board->id, $settings);

        if (!$stageId || !in_array($stageId, $stageIds, true)) {
            return $this->notFound(esc_html__('Stage not found', 'fluent-boards'));
        }

        $query = $this->publicAccessService->visibleTasksQuery($board->id, $settings, [$stageId]);
        if ($cursor !== null) {
            $query->wherePositionCursor($cursor, $cursorId, $direction);
        }

        $stageTasks = $this->serializer->withCardRelations($query, $settings)
            ->orderBy('position', $direction === 'prev' ? 'DESC' : 'ASC')
            ->orderBy('id', $direction === 'prev' ? 'DESC' : 'ASC')
            ->limit($limit + 1)
            ->get();

        $hasMore = $stageTasks->count() > $limit;
        if ($hasMore) {
            $stageTasks = $stageTasks->slice(0, $limit)->values();
        }

        if ($direction === 'prev') {
            $stageTasks = $stageTasks->reverse()->values();
        }

        $cards = $this->serializer->formatCards($stageTasks, $settings);

        $startCursor = $stageTasks->count() ? (float) $stageTasks->first()->position : null;
        $endCursor = $stageTasks->count() ? (float) $stageTasks->last()->position : null;
        $startCursorId = $stageTasks->count() ? (int) $stageTasks->first()->id : null;
        $endCursorId = $stageTasks->count() ? (int) $stageTasks->last()->id : null;

        $hasMoreBefore = false;
        $hasMoreAfter = false;

        if ($startCursor !== null) {
            $hasMoreBefore = $this->publicAccessService->visibleTasksQuery($board->id, $settings, [$stageId])
                ->wherePositionCursor($startCursor, $startCursorId, 'prev')
                ->exists();
        }

        if ($endCursor !== null) {
            $hasMoreAfter = $this->publicAccessService->visibleTasksQuery($board->id, $settings, [$stageId])
                ->wherePositionCursor($endCursor, $endCursorId, 'next')
                ->exists();
        }

        return [
            'tasks'      => $cards,
            'pagination' => [
                'stage_id' => (int) $stageId,
                'limit' => (int) $limit,
                'direction' => $direction,
                'cursor' => $cursor !== null ? (float) $cursor : null,
                'has_more' => $hasMore,
                'has_more_before' => $hasMoreBefore,
                'has_more_after' => $hasMoreAfter,
                'start_cursor' => $startCursor,
                'end_cursor' => $endCursor,
                'start_cursor_id' => $startCursorId,
                'end_cursor_id' => $endCursorId,
            ],
        ];
    }

    public function findTask($board_id, $task_id)
    {
        $board_id = absint($board_id);
        $board = Board::findOrFail($board_id);
        $settings = $this->publicAccessService->getSettings($board);

        $task = $this->publicAccessService->findVisibleTask($board, $settings, $task_id);
        if (!$task) {
            return $this->notFound(esc_html__('Task not found', 'fluent-boards'));
        }

        $detail = $this->serializer->formatTaskDetail($task, $settings);

        return [
            'task' => $detail,
        ];
    }

    public function getTaskComments(Request $request, $board_id, $task_id)
    {
        $board_id = absint($board_id);
        $board = Board::findOrFail($board_id);
        $settings = $this->publicAccessService->getSettings($board);

        $task = $settings['task_comments'] ? $this->publicAccessService->findVisibleTask($board, $settings, $task_id) : null;
        if (!$task) {
            return $this->notFound(esc_html__('Task not found', 'fluent-boards'));
        }

        $page = $request->getSafe('page', 'intval', 1);

        return $this->serializer->commentsPage($task, $page);
    }

    /**
     * Hidden features and ids answer as plain 404s. The message goes in an array because
     * WPFluent's REST 404 customizer writes into the response data and fatals on a string.
     */
    private function notFound($message)
    {
        return $this->sendError(['message' => $message], 404);
    }
}
