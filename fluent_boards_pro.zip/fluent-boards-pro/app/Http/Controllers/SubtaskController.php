<?php

namespace FluentBoardsPro\App\Http\Controllers;

use FluentBoards\App\Models\Task;
use FluentBoards\App\Models\TaskMeta;
use FluentBoards\App\Models\Stage;
use FluentBoards\App\Services\Helper;
use FluentBoards\App\Services\PermissionManager;
use FluentBoards\App\Services\TaskService;
use FluentBoards\Framework\Support\Arr;
use FluentBoardsPro\App\Services\ProTaskService;
use FluentBoardsPro\App\Services\SubtaskService;
use FluentBoards\Framework\Http\Request\Request;
use FluentBoards\App\Services\Constant;

class SubtaskController extends Controller
{
    private SubtaskService $subtaskService;

    public function __construct(SubtaskService $subtaskService)
    {
        parent::__construct();
        $this->subtaskService = $subtaskService;
    }

    public function getSubtasks($board_id, $task_id)
    {
        $parentTask = $this->findTaskOnBoard($task_id, $board_id, false);

        $subTasks = Task::where('parent_id', $parentTask->id)
            ->with(['assignees'])
            ->orderBy('position', 'asc')
            ->get();

        $groups = TaskMeta::where('task_id', $parentTask->id)
            ->select('id', 'value')
            ->where('key', Constant::SUBTASK_GROUP_NAME)
            ->get()
            ->keyBy('id')
            ->toArray();

        $formattedSubTasks = [];

        foreach ($groups as $group) {
            $formattedSubTasks[$group['id']] = [
                'id' => $group['id'],
                'task_id' => $parentTask->id,
                'subtasks' => [],
                'value' => $group['value'] ?? __('Uncategorized', 'fluent-boards-pro'),
            ];
        }

        foreach ($subTasks as $subTask) {
            $groupId = (string) Arr::get($subTask->meta, 'subtask_group_id', 'uncategorized');
            if(!isset($formattedSubTasks[$groupId])) {
                $formattedSubTasks[$groupId] = [
                    'id' => $groupId,
                    'subtasks' => [],
                    'task_id' => $parentTask->id,
                    'value' => $groups[$groupId]['value'] ?? __('Untitled Group', 'fluent-boards-pro'),
                ];
            }
            $formattedSubTasks[$groupId]['subtasks'][] = $subTask;
        }

        if(!empty($formattedSubTasks['uncategorized'])) {
            $uncategorizedSubTasks = $formattedSubTasks['uncategorized']['subtasks'];
            $newGroup = [
                'value' => __('Untitled Group', 'fluent-boards-pro'),
                'task_id' => $parentTask->id,
                'key' => Constant::SUBTASK_GROUP_NAME,
            ];
            $createdGroupId = TaskMeta::query()->insertGetId($newGroup);
            $formattedSubTasks['uncategorized']['id'] = $createdGroupId;
            foreach ($uncategorizedSubTasks as $subTask) {
                TaskMeta::create([
                    'task_id' => $subTask->id,
                    'key' => Constant::SUBTASK_GROUP_CHILD,
                    'value' => $createdGroupId,
                ]);
            }
        }

        $formattedSubTasks = array_values($formattedSubTasks);

        return [
            'subtaskGroups' => $formattedSubTasks
        ];
    }

    public function createSubtaskGroup(Request $request, $board_id, $task_id)
    {
        $subtaskGroupData = $this->subtaskSanitizeAndValidate($request->all(), [
            'title' => 'required|string',
        ]);

        try {
            $this->findTaskOnBoard($task_id, $board_id, false);
            $subtaskGroup = $this->subtaskService->createSubtaskGroup($task_id, $subtaskGroupData);

            return $this->sendSuccess([
                'subtaskGroup' => $subtaskGroup,
                'message'      => __('New Subtask group has been added', 'fluent-boards-pro')
            ], 200);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 400);
        }
    }

    public function updateSubtaskGroup(Request $request, $board_id, $task_id)
    {
        $subtaskGroupData = $this->subtaskSanitizeAndValidate($request->all(), [
            'title'    => 'required|string',
            'group_id' => 'required'
        ]);

        try {
            $this->findSubtaskGroupOnBoard($subtaskGroupData['group_id'], $board_id, $task_id);
            $subtaskGroup = $this->subtaskService->updateSubtaskGroup($subtaskGroupData);

            return $this->sendSuccess([
                'subtaskGroup' => $subtaskGroup,
                'message'      => __('Subtask group title has been added', 'fluent-boards-pro')
            ], 200);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 400);
        }
    }

    public function deleteSubtaskGroup(Request $request, $board_id, $task_id)
    {
        $group_id = $request->getSafe('group_id');

        try {
            $this->findSubtaskGroupOnBoard($group_id, $board_id, $task_id);
            $this->subtaskService->deleteSubtaskGroup($group_id);

            return $this->sendSuccess([
                'message' => __('Subtask group has been deleted', 'fluent-boards-pro')
            ], 200);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 404);
        }
    }

    public function createSubtask(Request $request, $board_id, $task_id)
    {
        $subtaskData = $this->subtaskSanitizeAndValidate($request->all(), [
            'title' => 'required|string',
        ]);

        try {
            $this->findTaskOnBoard($task_id, $board_id, false);
            if (!empty($subtaskData['group_id'])) {
                $this->findSubtaskGroupOnBoard($subtaskData['group_id'], $board_id, $task_id);
            }
            $subtask = $this->subtaskService->createSubtask($task_id, $subtaskData);

            $subtask['assignees'] = $subtask->assignees;

            return $this->sendSuccess([
                'subtask' => $subtask,
                'message' => __('Subtask has been added', 'fluent-boards-pro')
            ], 200);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 400);
        }
    }

    /**
     * Create several subtasks in one transactional request.
     *
     * Used by the AI "Generate subtasks" flow, which would otherwise need one
     * request per generated title.
     */
    public function createBulkSubtasks(Request $request, $board_id, $task_id)
    {
        $titles = array_values(array_filter(array_map(
            'sanitize_text_field',
            (array) $request->get('titles', [])
        )));

        $groupTitle = sanitize_text_field($request->get('group_title', ''));
        if (!$groupTitle) {
            $groupTitle = __('Subtasks', 'fluent-boards-pro');
        }

        try {
            $this->findTaskOnBoard($task_id, $board_id, false);

            $result = $this->subtaskService->createBulkSubtasks($task_id, $titles, $groupTitle);

            return $this->sendSuccess([
                'group'    => $result['group'],
                'subtasks' => $result['subtasks'],
                'message'  => __('Subtasks have been added', 'fluent-boards-pro')
            ], 200);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 400);
        }
    }

    public function deleteSubtasks($board_id, $task_id)
    {
        try {
            $task = $this->findTaskOnBoard($task_id, $board_id);
            $task->subtask_group_id = TaskMeta::where('task_id', $task->id)
                ->where('key', Constant::SUBTASK_GROUP_CHILD)
                ->value('value');
            $deletedTask = clone $task;

            $options = null;
            //if we need to do something before a task is deleted
            do_action('fluent_boards/before_task_deleted', $task, $options);

            $this->subtaskService->deleteSubtask($task);

            do_action('fluent_boards/subtask_deleted_activity', $deletedTask->parent_id, $deletedTask->title);

            // therefore the task is subtask and we need to update other subtasks position
            return $this->sendSuccess([
                'deletedSubtask'  => $deletedTask,
                'changedSubtasks' => $this->subtaskService->getLastMinuteUpdatedSubtasks($deletedTask->parent_id),
                'message'         => __('Task has been deleted', 'fluent-boards-pro'),
            ], 200);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 404);
        }
    }

    /*
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $board_id
     * @param  int  $subtask_id
     * Convert a subtask to a task and move it to the board where parent task was created
     * @return \Illuminate\Http\Response
     */
    public function moveToBoard(Request $request, $board_id, $task_id)
    {
        $subtaskId = $task_id;
        $subtaskData = $this->subtaskSanitizeAndValidate($request->all(), [
            'stage_id' => 'required',
        ]);
        try {
            $subtask = $this->findTaskOnBoard($subtaskId, $board_id);
            $this->findStageOnBoard($subtaskData['stage_id'], $board_id);
            $subtask = $this->subtaskService->moveToBoard($subtask, $subtaskData);
            $changedSubtasks = $this->subtaskService->getLastMinuteUpdatedSubtasks($subtask->parent_id);

            return $this->sendSuccess([
                'moveSubtask'     => $subtask,
                'changedSubtasks' => $changedSubtasks,
            ], 201);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 400);
        }
    }

    public function moveSubtask(Request $request, $board_id, $task_id)
    {
        $subtaskData = $this->subtaskSanitizeAndValidate($request->all(), [
            'group_id'   => 'required',
            'subtask_id' => 'required',
        ]);

        try {
            $this->findTaskOnBoard($task_id, $board_id, false);
            $this->assertSubtasksOnBoard($subtaskData['subtask_id'], $board_id);
            $this->findSubtaskGroupOnBoard($subtaskData['group_id'], $board_id, $task_id);
            $subtask = $this->subtaskService->moveSubtaskToGroup($subtaskData);

            return $this->sendSuccess([
                'subtask' => $subtask,
                'message' => __('Subtask has been moved', 'fluent-boards-pro'),
            ], 201);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 400);
        }
    }


    private function subtaskSanitizeAndValidate($data, array $rules = [])
    {
        $data = Helper::sanitizeSubtask($data);

        return $this->validate($data, $rules);
    }

    public function updateSubtaskPosition(Request $request, $board_id, $subtask_id)
    {
        $subtaskData = $this->subtaskSanitizeAndValidate($request->all(), [
            'newPosition'        => 'required|integer',
            'newSubtasksGroupId' => 'required',
        ]);
        try {
            $subtask = $this->findTaskOnBoard($subtask_id, $board_id);
            if (empty($subtaskData['newSubtasksGroupId'])) {
                $subtaskData['newSubtasksGroupId'] = TaskMeta::where('task_id', $subtask_id)
                    ->where('key', Constant::SUBTASK_GROUP_CHILD)
                    ->value('value');
            }
            $this->findSubtaskGroupOnBoard($subtaskData['newSubtasksGroupId'], $board_id, $subtask->parent_id);
            $subtask = $this->subtaskService->updateSubtaskPosition($subtask_id, $subtaskData);

            $changedSubtasks = $this->subtaskService->getLastMinuteUpdatedSubtasks($subtask->parent_id);
            return $this->sendSuccess([
                'changedSubtasks' => $changedSubtasks
            ], 201);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 400);
        }
    }

    public function ConvertTaskToSubtask(Request $request, $board_id, $task_id)
    {
        $parentId = $request->getSafe('parent_id');
        $assigneeId = absint($request->getSafe('assigneeId'));
        $subtaskGroupId = $request->getSafe('subtaskGroupId');
        $taskService = new ProTaskService();
        try {
            $this->findTaskOnBoard($task_id, $board_id, false);
            $this->findTaskOnBoard($parentId, $board_id, false);
            // Validate before converting so a bad assignee cannot leave a half-applied change.
            if ($assigneeId && !PermissionManager::userHasPermission($board_id, $assigneeId)) {
                throw new \Exception(esc_html__('Only board members can be assigned to a subtask', 'fluent-boards-pro'));
            }
            if (!empty($subtaskGroupId)) {
                $this->findSubtaskGroupOnBoard($subtaskGroupId, $board_id, $parentId);
            }

            $parentTask = $taskService->convertTaskToSubtask($task_id, $parentId);

            if (!empty($subtaskGroupId)) {
                $taskService->addToSubtaskGroup($task_id, $subtaskGroupId, null);
            } else {
                $taskService->addToSubtaskGroup($task_id, null, $parentTask->id);
            }

            if (!empty($assigneeId)) {
                $taskService->addAssigneeToSubtask($task_id, $assigneeId);
            }

            return $this->sendSuccess([
                'message'    => __('Task has been converted to subtask', 'fluent-boards-pro'),
                'parentTask' => $parentTask
            ], 200);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 400);
        }
    }

    public function cloneSubtask(Request $request, $board_id, $subtask_id)
    {
        $subtask = $this->findTaskOnBoard($subtask_id, $board_id);
        $cloneSubtask = $this->subtaskService->cloneSubtask($subtask);

        return $this->sendSuccess([
            'subtask' => $cloneSubtask,
            'message' => __('Subtask has been cloned successfully', 'fluent-boards-pro')
        ],200);
    }

    /**
     * Resolve a task or subtask only when it belongs to the requested board.
     *
     * @param int $taskId
     * @param int $boardId
     * @param bool $allowParentFallback
     * @return Task
     * @throws \Exception
     */
    private function findTaskOnBoard($taskId, $boardId, $allowParentFallback = true)
    {
        return (new TaskService())->findTaskOnBoard($taskId, $boardId, $allowParentFallback);
    }

    /**
     * Resolve a subtask group only when its parent task belongs to the requested board.
     *
     * @param int $groupId
     * @param int $boardId
     * @param int|null $parentTaskId
     * @return TaskMeta
     * @throws \Exception
     */
    private function findSubtaskGroupOnBoard($groupId, $boardId, $parentTaskId = null)
    {
        $group = TaskMeta::where('id', absint($groupId))
            ->where('key', Constant::SUBTASK_GROUP_NAME)
            ->first();

        if (!$group) {
            throw new \Exception(esc_html__('Subtask group not found', 'fluent-boards-pro'));
        }

        $this->findTaskOnBoard($group->task_id, $boardId, false);

        if ($parentTaskId && (int) $group->task_id !== (int) $parentTaskId) {
            throw new \Exception(esc_html__('Subtask group not found', 'fluent-boards-pro'));
        }

        return $group;
    }

    /**
     * Ensure one or more subtasks belong to the requested board.
     *
     * @param int|array $subtaskIds
     * @param int $boardId
     * @return void
     * @throws \Exception
     */
    private function assertSubtasksOnBoard($subtaskIds, $boardId)
    {
        foreach ((array) $subtaskIds as $subtaskId) {
            $this->findTaskOnBoard($subtaskId, $boardId);
        }
    }

    /**
     * Resolve a stage only when it belongs to the requested board.
     *
     * @param int $stageId
     * @param int $boardId
     * @return Stage
     * @throws \Exception
     */
    private function findStageOnBoard($stageId, $boardId)
    {
        $stage = Stage::where('id', absint($stageId))
            ->where('board_id', absint($boardId))
            ->first();

        if (!$stage) {
            throw new \Exception(esc_html__('Stage not found', 'fluent-boards-pro'));
        }

        return $stage;
    }
}
