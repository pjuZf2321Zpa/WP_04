<?php

namespace FluentBoardsPro\App\Http\Policies;

use FluentBoards\App\Http\Policies\BasePolicy;
use FluentBoards\App\Services\PermissionManager;
use FluentBoards\Framework\Http\Request\Request;

class TemplateCreationPolicy extends BasePolicy
{
    /**
     * Check whether the current user may create a board from a template.
     *
     * @param Request $request
     * @return bool
     */
    public function verifyRequest(Request $request)
    {
        if (!PermissionManager::userHasBoardCreationPermission()) {
            return false;
        }

        $templateType = $request->getSafe('template_type', 'sanitize_text_field', 'default');

        if ($templateType === 'default') {
            return true;
        }

        $templateId = absint($request->get('template_id'));

        return $templateId && PermissionManager::userHasPermission($templateId);
    }

    /**
     * Authorize the create-from-template controller action.
     *
     * @param Request $request
     * @return bool
     */
    public function createBoardFromTemplate(Request $request)
    {
        return $this->verifyRequest($request);
    }

    /** Authorize saving a built-in template using the board-creation permission. */
    public function saveDefaultTemplate(Request $request)
    {
        return PermissionManager::userHasBoardCreationPermission();
    }
}
