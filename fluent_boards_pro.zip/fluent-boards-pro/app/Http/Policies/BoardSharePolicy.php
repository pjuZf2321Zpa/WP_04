<?php

namespace FluentBoardsPro\App\Http\Policies;

use FluentBoards\App\Services\PermissionManager;
use FluentBoards\Framework\Http\Request\Request;

/**
 * Share Board settings: board managers (and global admins) of the URL board only.
 */
class BoardSharePolicy extends Policy
{
    public function verifyRequest(Request $request)
    {
        $routeParams = $request->get_url_params();

        return PermissionManager::isBoardManager(absint($routeParams['board_id'] ?? 0));
    }
}
