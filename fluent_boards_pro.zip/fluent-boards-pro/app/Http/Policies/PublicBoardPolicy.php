<?php

namespace FluentBoardsPro\App\Http\Policies;

use FluentBoards\App\Models\Board;
use FluentBoardsPro\App\Services\PublicAccessService;
use FluentBoards\Framework\Http\Request\Request;

/**
 * Logged-out public board view: GET only, with a valid token for the URL board and public access on.
 */
class PublicBoardPolicy extends Policy
{
    public function verifyRequest(Request $request)
    {
        if (strtoupper($request->getMethod()) !== 'GET') {
            return false;
        }

        // The token and opt-in must belong to the controller's URL board.
        $routeParams = $request->get_url_params();
        $boardId = absint($routeParams['board_id'] ?? 0);
        if (!$boardId) {
            return false;
        }

        $token = $request->getSafe('public_token', 'sanitize_text_field');
        $publicAccessService = new PublicAccessService();
        if (!$publicAccessService->validateAccessToken($boardId, $token)) {
            return false;
        }

        return $publicAccessService->isEnabled(Board::find($boardId));
    }
}
