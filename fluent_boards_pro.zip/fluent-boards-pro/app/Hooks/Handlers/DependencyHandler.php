<?php

namespace FluentBoardsPro\App\Hooks\Handlers;

use FluentBoards\App\Hooks\Handlers\NotificationHandler;
use FluentBoards\App\Services\Constant;
use FluentBoards\App\Services\Helper;
use FluentBoards\App\Services\NotificationService;
use FluentBoardsPro\App\Services\DependencyService;

class DependencyHandler
{
    /**
     * Log activity when a dependency is added.
     * Fires on: fluent_boards/task_dependency_added
     *
     * @param \FluentBoards\App\Models\Task $predecessorTask The blocking task
     * @param \FluentBoards\App\Models\Task $successorTask   The blocked task
     * @param int $boardId
     */
    public function logDependencyAdded($predecessorTask, $successorTask, $boardId)
    {
        // Log on the successor task: "waiting on {predecessor}"
        $this->createLogActivity(
            $successorTask->id,
            'added',
            'dependency',
            null,
            $predecessorTask->title
        );

        // Log on the predecessor task: "blocking {successor}"
        $this->createLogActivity(
            $predecessorTask->id,
            'added',
            'dependent',
            null,
            $successorTask->title
        );
    }

    /**
     * Log activity when a dependency is removed.
     * Fires on: fluent_boards/task_dependency_removed
     *
     * @param \FluentBoards\App\Models\Task $predecessorTask
     * @param \FluentBoards\App\Models\Task $successorTask
     * @param int $boardId
     */
    public function logDependencyRemoved($predecessorTask, $successorTask, $boardId)
    {
        // Log on the successor task: "removed dependency on {predecessor}"
        $this->createLogActivity(
            $successorTask->id,
            'removed',
            'dependency',
            $predecessorTask->title,
            null
        );

        // Log on the predecessor task: "no longer blocking {successor}"
        $this->createLogActivity(
            $predecessorTask->id,
            'removed',
            'dependent',
            $successorTask->title,
            null
        );
    }

    /**
     * When a task is marked complete, notify assignees of any successor tasks
     * that are now fully unblocked (all their predecessors are closed), respecting personal pauses.
     * Fires on: fluent_boards/task_closed, for every way a task gets completed.
     *
     * @param \FluentBoards\App\Models\Task $task  The task just completed
     */
    public function notifyDependencyUnblocked($task)
    {

        $successors = $task->successors()->get(['fbs_tasks.id', 'fbs_tasks.title', 'fbs_tasks.board_id', 'fbs_tasks.status']);

        if ($successors->isEmpty()) {
            return;
        }

        $notificationHandler = new NotificationHandler();

        foreach ($successors as $successorTask) {
            // Skip if successor is already closed
            if ($successorTask->status === 'closed') {
                continue;
            }

            // Check if any other predecessors of this successor are still open
            $pendingCount = $successorTask->predecessors()
                ->where('fbs_tasks.status', '!=', 'closed')
                ->count();

            if ($pendingCount > 0) {
                continue;
            }

            // All predecessors done — get assignees of the successor task
            $successorTask->load(['assignees']);
            $assigneeIds = $successorTask->assignees->pluck('ID')->toArray();
            if (method_exists(NotificationService::class, 'filterUnmutedUserIds')) {
                $assigneeIds = (new NotificationService())->filterUnmutedUserIds($successorTask->board_id, $assigneeIds);
            }

            if (empty($assigneeIds)) {
                continue;
            }

            // Create one notification on the successor task, attach all assignees
            $notification = $notificationHandler->createNotification(
                $successorTask,
                Constant::OBJECT_TYPE_BOARD_NOTIFICATION,
                'dependency_unblocked',
                $task->title
            );
            $notification->users()->attach($assigneeIds);
        }
    }

    /**
     * Clean up all dependencies when a task is deleted.
     * Fires on: fluent_boards/task_deleted and fluent_boards/before_task_deleted
     *
     * @param \FluentBoards\App\Models\Task $task
     * @param int|null $boardId
     */
    public function cleanupDependencies($task, $boardId = null)
    {
        (new DependencyService())->removeAllDependencies($task->id);
    }

    /**
     * Create an activity log entry following the core pattern.
     *
     * @param int $taskId
     * @param string $action   (added, removed)
     * @param string $column   (dependency, dependent)
     * @param string|null $oldValue
     * @param string|null $newValue
     */
    private function createLogActivity($taskId, $action, $column, $oldValue = null, $newValue = null)
    {
        $data = [
            'object_type' => Constant::ACTIVITY_TASK,
            'object_id'   => $taskId,
            'action'      => $action,
            'column'      => $column,
            'old_value'   => $oldValue,
            'new_value'   => $newValue,
        ];

        $userId = get_current_user_id();
        if ($userId == 0) {
            $task = \FluentBoards\App\Models\Task::find($taskId);
            $data['created_by'] = $task ? $task->created_by : 0;
        }

        Helper::createActivity($data);
    }
}
