<?php

namespace FluentBoardsPro\App\Hooks\Handlers;

use FluentBoards\App\Models\Board;
use FluentBoards\App\Models\Task;
use FluentBoards\App\Models\User;
use FluentBoards\App\Services\PermissionManager;
use FluentBoards\Framework\Support\Str;
use FluentBoardsPro\App\Modules\TimeTracking\Model\TimeTrack;
use FluentBoardsPro\App\Services\ProHelper;
use FluentBoardsPro\App\Services\Constant as ProConstant;

class DataExporter
{
    private $request;

    public function exportTimeSheet()
    {
        $this->verifyRequest();
        $boardId = $this->request->get('board_id');

        $dateRange = ProHelper::getValidatedDateRange($this->request->get('date_range', []));

        $tracks = TimeTrack::when($this->request->get('board_id'), function ($q) use ($boardId) {
            $q->where('board_id', $boardId);
        })
            ->orderBy('updated_at', 'DESC')
            ->whereBetween('completed_at', $dateRange)
            ->with(['user', 'board', 'task' => function ($q) {
                $q->select('id', 'title', 'slug');
            }])
            ->whereHas('task')
            ->get();

        $writer = $this->getCsvWriter();
        $writer->insertOne([
            __('Board', 'fluent-boards-pro'),
            __('Task', 'fluent-boards-pro'),
            __('Member', 'fluent-boards-pro'),
            __('Log Date', 'fluent-boards-pro'),
            __('Billable Hours', 'fluent-boards-pro'),
            __('Notes', 'fluent-boards-pro')
        ]);

        $rows = [];
        foreach ($tracks as $track) {
            $rows[] = [
                $this->sanitizeForCSV($track->board->title ?? ''),
                $this->sanitizeForCSV($track->task->title ?? ''),
                $this->sanitizeForCSV($track->user->display_name ?? ''),
                $this->formatTime($track->completed_at, 'Y-m-d'),
                $this->minutesToHours($track->billable_minutes),
                $this->sanitizeForCSV($track->message)
            ];
        }

        $writer->insertAll($rows);
        $writer->output('time-sheet-' . gmdate('Y-m-d_H-i') . '.csv');
        die();
    }

    

    private function prepareSubtasksToExport($task)
    {
        $subtasks = $task->subtasks;
        $subtaskTitles = [];
        foreach ($subtasks as $subtask) {
            $subtaskTitles[] = $this->sanitizeForCSV($subtask->title);
        }
        return implode(', ', $subtaskTitles);
    }

    private function verifyRequest()
    {
        check_ajax_referer('wp_rest', '_wpnonce');
        $this->request = FluentBoards('request');
        $boardId = $this->request->get('board_id');
        if (PermissionManager::isBoardManager($boardId)) {
            return true;
        }

        die('You do not have permission');
    }

    /**
     * Build a safe download filename from the board title.
     *
     * @param  \FluentBoards\App\Models\Board $board
     * @param  string $extension
     * @return string
     */
    private function getDownloadFileName($board, $extension)
    {
        $title = sanitize_file_name(preg_replace('/\s+/', '_', $board->title));

        if (!$title) {
            $title = 'board-' . $board->id;
        }

        return $title . '_' . gmdate('Y-m-d') . '.' . $extension;
    }

    private function getCsvWriter()
    {
        if (!class_exists('\League\Csv\Writer')) {
            include FLUENT_BOARDS_PLUGIN_PATH . 'app/Services/Libs/csv/autoload.php';
        }

        return \League\Csv\Writer::createFromFileObject(new \SplTempFileObject());
    }

    private function sanitizeForCSV($content)
    {
        $formulas = ['=', '-', '+', '@', "\t", "\r"];

        if (Str::startsWith($content ?? '', $formulas)) {
            $content = "'" . $content;
        }

        return $content;
    }

    /*
     * Convert minutes to hours 30 mins as .5 hours
     */
    private function minutesToHours($minutes)
    {
        return round($minutes / 60, 2);
    }

    private function formatTime($time, $format = 'Y-m-d H:i:s')
    {
        return gmdate($format, strtotime($time));
    }

    public function exportBoardInCsv()
    {
        $this->streamBoard('csv');
    }

    public function exportBoardInJson()
    {
        $this->streamBoard('json');
    }

    /** Stream an export without staging files or persisting export state. */
    private function streamBoard($format)
    {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
            wp_send_json_error(['message' => __('Use POST to export a board.', 'fluent-boards-pro')], 405);
        }
        check_ajax_referer('wp_rest', '_wpnonce');
        $this->request = FluentBoards('request');
        $boardId = absint($this->request->get('board_id'));
        if (!$boardId || !PermissionManager::isBoardManager($boardId)) {
            wp_send_json_error(['message' => __('You do not have permission to export this board.', 'fluent-boards-pro')], 403);
        }
        $board = Board::find($boardId);
        if (!$board) {
            wp_send_json_error(['message' => __('Board not found.', 'fluent-boards')], 404);
        }
        if ($format !== 'csv') {
            // The importer matches members, assignees and watchers by email; the exporter is
            // already limited to board managers, so serialize the privileged columns here.
            User::serializePrivilegedFields(true);
        }
        $board->load(['stages', 'labels', 'users', 'customFields']);
        // Cap the cursor so tasks created during the download cannot extend it indefinitely.
        $maxId = Task::where('board_id', $boardId)->whereNull('parent_id')->max('id') ?: 0;
        $totalTasks = Task::where('board_id', $boardId)->whereNull('parent_id')
            ->where('id', '<=', $maxId)->count();
        $relations = $format === 'csv' ? ['stage', 'customFields', 'subtasks'] : [
            'assignees', 'watchers', 'comments', 'subtaskGroup.subtasks',
            'subtaskGroup.subtasks.assignees', 'labels', 'customFields'
        ];
        $columns = $format === 'csv' ? $this->getBoardCsvColumns($board) : [];
        $boardData = $board->toArray();
        unset($boardData['tasks']);
        $prefix = $this->encodeExportJson([
            'key' => ProConstant::FLUENT_BOARDS_IMPORT,
            'site_url' => site_url('/'),
            'board' => $boardData
        ]);

        // A streamed export runs in one request, unlike the former scheduled batches.
        // Some hosts disable this function; their request limit still applies.
        if (is_callable('set_time_limit')) {
            set_time_limit(0);
        }

        // Discard PHP buffers so batches can reach the client as they are generated.
        while (ob_get_level()) {
            if (!ob_end_clean()) {
                break;
            }
        }
        nocache_headers();
        header('Content-Type: ' . ($format === 'csv' ? 'text/csv' : 'application/json') . '; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $this->getDownloadFileName($board, $format) . '"');
        header('X-Content-Type-Options: nosniff');
        header('X-Accel-Buffering: no');
        header('X-FBS-Export-Task-Count: ' . $totalTasks);
        $output = fopen('php://output', 'w');
        if ($format === 'csv') {
            fputcsv($output, array_map([$this, 'sanitizeForCSV'], array_column($columns, 'header')), ',', '"', '');
        } else {
            // Reopen the board object to append its tasks array without buffering all tasks.
            echo substr($prefix, 0, -2) . ',"tasks":[';
        }
        $lastId = 0;
        $first = true;
        do {
            $tasks = Task::where('board_id', $boardId)->whereNull('parent_id')
                ->where('id', '>', $lastId)->where('id', '<=', $maxId)
                ->with($relations)->orderBy('id')->take(100)->get();
            foreach ($tasks as $task) {
                if ($format === 'csv') {
                    fputcsv($output, $this->getBoardCsvRow($board, $task, $columns), ',', '"', '');
                } else {
                    $json = $this->encodeExportJson($task->toArray());
                    echo ($first ? '' : ',') . $json;
                    $first = false;
                }
                $lastId = $task->id;
            }
            $count = $tasks->count();
            unset($tasks);
            fflush($output);
            flush();
            if (connection_aborted()) {
                fclose($output);
                exit;
            }
        } while ($count === 100);
        if ($format === 'json') {
            echo ']}}';
        }
        fclose($output);
        exit;
    }

    /** Preserve the import envelope and reject encoding failures instead of exporting corrupt data. */
    private function encodeExportJson($value)
    {
        $json = wp_json_encode($value);
        if ($json === false) {
            throw new \RuntimeException('Unable to encode board export.');
        }
        return $json;
    }

    /** Keep existing headers unless they collide; field IDs keep values independent of names. */
    private function getBoardCsvColumns($board)
    {
        $properties = [
            'board_title', 'task_title', 'slug', 'type', 'status', 'stage', 'source', 'priority',
            'description', 'position', 'started_at', 'due_at', 'archived_at', 'subtasks'
        ];
        $columns = array_map(function ($property) { return ['header' => $property]; }, $properties);
        $used = array_fill_keys($properties, true);
        // Reserve original names so a generated header cannot displace another field.
        $reserved = $used;
        foreach ($board->customFields as $field) {
            $reserved[$field->slug] = true;
        }
        foreach ($board->customFields as $field) {
            $header = $field->slug;
            if (isset($used[$header])) {
                $base = 'cf_' . $header;
                $header = $base;
                $suffix = 2;
                while (isset($reserved[$header]) || isset($used[$header])) {
                    $header = $base . '_' . $suffix++;
                }
            }
            $used[$header] = true;
            $columns[] = ['header' => $header, 'field_id' => $field->id];
        }
        return $columns;
    }

    private function getBoardCsvRow($board, $task, $columns)
    {
        $values = [];
        foreach ($task->customFields as $field) {
            $settings = maybe_unserialize($field->pivot->settings);
            $values[$field->id] = $settings['value'] ?? '';
        }
        $row = [];
        foreach ($columns as $column) {
            $property = $column['header'];
            if (isset($column['field_id'])) {
                $value = $values[$column['field_id']] ?? '';
            } elseif ($property === 'stage') {
                $value = $task->stage->title ?? '';
            } elseif ($property === 'board_title') {
                $value = $board->title;
            } elseif ($property === 'task_title') {
                $value = $task->title;
            } elseif ($property === 'subtasks') {
                $value = $this->prepareSubtasksToExport($task);
            } else {
                $value = $task->{$property};
            }
            if (is_array($value) || is_object($value)) {
                $value = $this->encodeExportJson($value);
            }
            $row[] = $this->sanitizeForCSV($value);
        }
        return $row;
    }
}
