<?php

namespace FluentBoardsPro\App\Hooks\Handlers;

use FluentBoards\App\Models\Attachment;
use FluentBoards\App\Models\Board;
use FluentBoards\App\Models\Label;
use FluentBoards\App\Models\Meta;
use FluentBoards\App\Models\Relation;
use FluentBoards\App\Models\Stage;
use FluentBoards\App\Models\Task;
use FluentBoards\App\Models\Webhook;
use FluentBoards\App\Services\Constant;
use FluentBoards\App\Services\Helper;
use FluentBoards\App\Services\Libs\FileSystem;
use FluentBoards\App\Services\PermissionManager;
use FluentBoards\App\Services\AttachmentAccessService;
use FluentBoards\Framework\Support\Arr;
use FluentBoardsPro\App\Models\TaskAttachment;
use FluentBoardsPro\App\Modules\CloudStorage\CloudStorageModule;
use FluentBoardsPro\App\Services\AttachmentService;
use FluentBoardsPro\App\Services\HelperInstaller;
use FluentBoardsPro\App\Services\PublicAccessService;


class ExternalPages
{
    protected $request;

    /**
     * Board share (public board view): the [fluent_board_public] shortcode and the attachment
     * checks core asks for. Needs core's PublicTaskSerializer, which older cores don't have.
     */
    public function registerPublicBoard()
    {
        if (!class_exists(\FluentBoards\App\Services\PublicTaskSerializer::class)) {
            return;
        }

        add_shortcode('fluent_board_public', [$this, 'renderPublicBoard']);
        add_filter('fluent_boards/public_board_background_visible', [$this, 'isPublicBoardBackgroundVisible'], 10, 2);
        add_filter('fluent_boards/public_board_task_feature_visible', [$this, 'isPublicBoardTaskFeatureVisible'], 10, 3);
    }

    public function renderPublicBoard($atts = [])
    {
        $atts = shortcode_atts([
            'id'    => 0,
            // Block themes cap post-content children at the narrow content width; a board needs room.
            'align' => 'wide',
        ], (array)$atts, 'fluent_board_public');

        $boardId = absint($atts['id']);
        $board = $boardId ? Board::where('id', $boardId)->whereNull('archived_at')->first() : null;
        $publicAccessService = new PublicAccessService();
        if (!$publicAccessService->isEnabled($board)) {
            return '';
        }

        (new \FluentBoards\App\Hooks\Handlers\ShortcodeHandler())->enqueuePublicAssets();

        $align = sanitize_key($atts['align'] ?? '');

        return Helper::loadView('frontend.public_board_view', [
            'board_id'     => $boardId,
            'align_class'  => in_array($align, ['wide', 'full'], true) ? 'align' . $align : '',
            'public_token' => $publicAccessService->generateAccessToken($boardId),
        ]);
    }

    public function isPublicBoardBackgroundVisible($visible, $board)
    {
        return $visible || (new PublicAccessService())->isEnabled($board);
    }

    public function isPublicBoardTaskFeatureVisible($visible, $task, $feature)
    {
        return $visible || (new PublicAccessService())->isTaskFeatureVisible($task, $feature);
    }
    
    /*
     * Render board member invitation form for new user
     */
    public function boardMemberInvitation()
    {
        $boardId  = isset($_GET['bid']) ? sanitize_text_field($_GET['bid']) : '';
        $hashCode = isset($_GET['hash']) ? sanitize_text_field($_GET['hash']) : '';

        if (empty($boardId) || empty($hashCode)) {
            status_header(400);
            die('Invalid invite link');
        }

        (new InvitationHandler())->showInviteeRegistrationForm($boardId, $hashCode);
        exit();

    }

    public function view_attachment()
    {
        $this->clearAttachmentOutputBuffers();
        nocache_headers();
        header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0');
        $attachmentHash = isset($_REQUEST['fbs_attachment']) && is_string($_REQUEST['fbs_attachment'])
            ? sanitize_text_field(wp_unslash($_REQUEST['fbs_attachment'])) : '';

        if (empty($attachmentHash)) {
            wp_die(esc_html__('Invalid Attachment Hash', 'fluent-boards-pro'), '', ['response' => 404]);
        }

        $attachment = $this->getAttachmentByHash($attachmentHash);

        if (!$attachment) {
            wp_die(esc_html__('Invalid Attachment Hash', 'fluent-boards-pro'), '', ['response' => 404]);
        }

        $attachment->load('task');

        // The hash identifies the file; current access comes from its persisted task and board.
        if (!$this->currentUserCanAccessAttachment($attachment)) {
            wp_die(esc_html__('You do not have permission to access this attachment.', 'fluent-boards-pro'), '', ['response' => 403]);
        }

        if ('cloudflare_r2' == $attachment->driver) {
            if(!empty($attachment->file_path)){
                $this->serveRemoteAttachment2($attachment);
            }else{
                die('File could not be found');
            }
        }

        if ('amazon_s3' == $attachment->driver) {
            if(!empty($attachment->file_path)){
//                $this->redirectToExternalAttachment($attachment->full_url);
                $this->serveRemoteAttachment2($attachment);
            }else{
                die('File could not be found');
            }
        }

        if ('blackblaze_b2' == $attachment->driver) {
            if(!empty($attachment->file_path)){
                $this->serveRemoteAttachment2($attachment);
            }else{
                die('File could not be found');
            }
        }

        if ('digital_ocean' == $attachment->driver) {
            if(!empty($attachment->file_path)){
                $this->serveRemoteAttachment2($attachment);
            }else{
                die('File could not be found');
            }
        }

        if ($attachment->driver !== 'local') {
            wp_die(esc_html__('File could not be found.', 'fluent-boards-pro'), '', ['response' => 404]);
        }

        if (!method_exists(FileSystem::class, '_resolveLocalAttachmentPath')) {
            wp_die(esc_html(HelperInstaller::getCoreUpdateMessage()), '', ['response' => 409]);
        }

        $filePath = FileSystem::resolveLocalAttachmentPath($attachment->file_path)
            ?: FileSystem::resolveLocalAttachmentPath($attachment->file_path, (int) $attachment->task->board_id);
        if (!$filePath || !is_readable($filePath)) {
            wp_die(esc_html__('File could not be found.', 'fluent-boards-pro'), '', ['response' => 404]);
        }

        $this->serveLocalAttachment($attachment, $filePath);
    }

    private function getAttachmentByHash($attachmentHash)
    {
        return TaskAttachment::where('file_hash', $attachmentHash)
            ->where('object_type', Constant::TASK_ATTACHMENT)
            ->first();
    }

    private function currentUserCanAccessAttachment($attachment)
    {
        if (empty($attachment->task) || empty($attachment->task->board_id)) {
            return false;
        }

        if (PermissionManager::userHasBoardPermission((int) $attachment->task->board_id, 'GET')) {
            return true;
        }

        // Logged-out visitors of a public board, when its settings expose task attachments.
        if (!method_exists(AttachmentAccessService::class, 'canViewPublicly')) {
            return false;
        }

        return (new AttachmentAccessService())->canViewPublicly($attachment);
    }

    /*
     * Showing local attachment
    */
    private function serveLocalAttachment($attachment, $filePath)
    {
        $detectedMimeType = AttachmentService::detectFileMimeType($filePath);
        $this->sendAttachmentHeaders($attachment, basename($filePath), $detectedMimeType, filesize($filePath));
        
        // Use readfile() correctly - it outputs the file content directly
        readfile($filePath);
        die();
    }

    public function serveRemoteAttachment($attachment)
    {
        $this->serveRemoteAttachment2($attachment);
    }

    private function serveRemoteAttachment2($attachment)
    {
        /*
         * Has Public URL/Path
         * Return as masked. User cannot see the actual path.
         */
        // Stream to disk so historical downloads do not depend on today's upload limit.
        // Recorded larger attachments remain supported; unrecorded responses have a finite ceiling.
        $maxBytes = $this->getRemoteAttachmentDownloadLimit($attachment);
        if (!function_exists('wp_tempnam')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }
        $tempFile = wp_tempnam('fbs-attachment');
        if (!$tempFile) {
            wp_die(esc_html__('Failed to fetch remote file', 'fluent-boards-pro'), '', ['response' => 502]);
        }

        // Also clean up if streaming stops because the client disconnects.
        register_shutdown_function(static function () use ($tempFile) {
            if (is_file($tempFile)) {
                unlink($tempFile);
            }
        });

        $contentLength = $this->downloadWithStorageCredentials($attachment, $tempFile, $maxBytes);
        if ($contentLength === null) {
            // Attachment was stored by another provider/bucket: only its public URL can serve it.
            $response = wp_safe_remote_get($attachment->full_url, [
                'timeout' => 30,
                'stream' => true,
                'filename' => $tempFile,
                'limit_response_size' => $maxBytes + 1,
            ]);
            clearstatcache(true, $tempFile);
            $contentLength = !is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200 && is_file($tempFile)
                ? filesize($tempFile) : false;
        }
        if ($contentLength === false) {
            unlink($tempFile);
            wp_die(esc_html__('Failed to fetch remote file', 'fluent-boards-pro'), '', ['response' => 502]);
        }
        if ($contentLength > $maxBytes) {
            unlink($tempFile);
            wp_die(esc_html__('The remote attachment exceeds the download size limit.', 'fluent-boards-pro'), '', ['response' => 413]);
        }

        $fileName = $this->getAttachmentFileName($attachment);
        $detectedMimeType = AttachmentService::detectFileMimeType($tempFile);
        $this->sendAttachmentHeaders($attachment, $fileName, $detectedMimeType, $contentLength);
        readfile($tempFile);
        unlink($tempFile);
        exit();
    }

    /**
     * Fetch through the configured storage API so private buckets stay private.
     *
     * @return int|false|null Bytes written, false on failure, null when the current storage does not own this file.
     */
    private function downloadWithStorageCredentials($attachment, $tempFile, $maxBytes)
    {
        $module = new CloudStorageModule();
        $driver = $module->getDriver();
        if (!$driver || $module->getDriverName($driver) !== $attachment->driver
            || $driver->getObjectNameFromRemotePath($attachment->file_path) === null) {
            return null;
        }

        $result = $driver->downloadObject($attachment->file_path, $tempFile, $maxBytes);
        if (!is_wp_error($result)) {
            return $result;
        }
        if ($result->get_error_code() === 'remote_too_large') {
            return $maxBytes + 1;
        }

        return false;
    }

    /** Bound remote downloads independently of mutable upload settings, including legacy size labels. */
    private function getRemoteAttachmentDownloadLimit($attachment)
    {
        $storedSize = $attachment->file_size;
        $recordedBytes = is_numeric($storedSize) ? (float) $storedSize : 0;
        if (is_string($storedSize) && preg_match('/^\s*(\d+(?:\.\d+)?)\s*(KB|MB|GB|TB)\s*$/i', $storedSize, $matches)) {
            $unit = array_search(strtoupper($matches[2]), ['KB', 'MB', 'GB', 'TB'], true) + 1;
            // Legacy display labels are rounded, so allow one displayed unit of rounding slack.
            $recordedBytes = ((float) $matches[1] + 1) * pow(1024, $unit);
        }

        // Sites with old records lacking sizes can explicitly raise the fallback ceiling.
        $fallback = (float) apply_filters('fluent_boards/remote_attachment_download_limit', 1024 * 1024 * 1024, $attachment);
        return (int) min(PHP_INT_MAX - 1, max(1, $fallback, $recordedBytes));
    }

    /**
     * Emit attachment headers derived from the stored filename and actual bytes.
     *
     * @param TaskAttachment $attachment
     * @param string $fileName
     * @param string $detectedMimeType
     * @param int $contentLength
     * @return void
     */
    private function sendAttachmentHeaders($attachment, $fileName, $detectedMimeType, $contentLength)
    {
        $this->clearAttachmentOutputBuffers();
        $responsePolicy = AttachmentService::getAttachmentResponsePolicy($fileName, $detectedMimeType);
        $downloadFileName = sanitize_file_name($attachment->title ?: basename($fileName));
        if (!$downloadFileName) {
            $downloadFileName = 'attachment';
        }

        header('Content-Type: ' . $responsePolicy['mime_type']);
        header('X-Content-Type-Options: nosniff');
        header('Content-Disposition: ' . $responsePolicy['disposition'] . '; filename="' . $downloadFileName . '"');
        header('Content-Length: ' . absint($contentLength));
        header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0');
    }

    /** Clear nested buffers without calling operations their handlers prohibit. */
    private function clearAttachmentOutputBuffers()
    {
        while ($buffer = ob_get_status()) {
            // A buffer can exist without allowing cleanup; check its flags to avoid PHP notices.
            if ($buffer['flags'] & PHP_OUTPUT_HANDLER_REMOVABLE) {
                ob_end_clean();
                continue;
            }
            if ($buffer['flags'] & PHP_OUTPUT_HANDLER_CLEANABLE) {
                ob_clean();
            }
            break;
        }

        // A locked buffer can prevent access to earlier output. Do not append file bytes to it.
        foreach (ob_get_status(true) as $buffer) {
            if ($buffer['buffer_used'] > 0) {
                wp_die(esc_html__('Unable to prepare attachment response.', 'fluent-boards-pro'), '', ['response' => 500]);
            }
        }
    }

    /**
     * Resolve the immutable stored filename used for MIME policy decisions.
     *
     * @param TaskAttachment $attachment
     * @return string
     */
    private function getAttachmentFileName($attachment)
    {
        if (!empty($attachment->file_path)) {
            return basename(rawurldecode($attachment->file_path));
        }

        $urlPath = wp_parse_url($attachment->full_url, PHP_URL_PATH);
        if ($urlPath) {
            return basename(rawurldecode($urlPath));
        }

        return sanitize_file_name($attachment->title);
    }

    private function redirectToExternalAttachment($redirectUrl)
    {
        wp_redirect($redirectUrl, 307);
        exit();
    }

    public function handleTaskWebhook()
    {
        $this->request = FluentBoards('request');

        // check if it's a POST request
        if ($this->request->method() != 'POST') {
            wp_send_json_error([
                'message' => __('Webhook must need to be as POST Method', 'fluent-boards-pro'),
                'type'    => 'invalid_request_method'
            ], 200);
        }

        if (empty($hash = $this->request->get('hash'))) {
            wp_send_json_error([
                'message' => __('Invalid Webhook URL', 'fluent-boards-pro'),
                'type'    => 'invalid_webhook_url'
            ], 200);
        }

        $webhook = $this->getWebhookByHash($hash);
        if (!$webhook) {
            wp_send_json_error([
                'message' => __('Invalid Webhook Hash', 'fluent-boards-pro'),
                'type'    => 'invalid_webhook_hash'
            ], 200);
        }

        $postData = $this->request->get();

        if(empty($postData['title'])){
            wp_send_json_error([
                'message' => __('Task Title is required', 'fluent-boards-pro'),
                'type'    => 'task_title_required'
            ], 200);
        }

        $postData = apply_filters('fluent_boards/incoming_webhook_data', $postData, $webhook);

        $task = $this->createTaskFromWebhook($postData, $webhook);

        if(!$task){
            wp_send_json_error([
                'message' => __('Task Creation Failed', 'fluent-boards-pro'),
                'type'    => 'task_creation_failed'
            ], 400);
        }
        wp_send_json_success([
           'message' => __('Task Created Successfully', 'fluent-boards-pro'),
            'task'    => $task
        ], 200);
    }

    /**
     * Create a task from a verified incoming webhook without exposing a PHP API bypass.
     *
     * @param array $postData
     * @param Webhook $webhook
     * @return mixed|false
     */
    private function createTaskFromWebhook($postData, $webhook)
    {
        if (!$webhook || empty($webhook->id) || empty($webhook->key)) {
            return false;
        }

        $verifiedWebhook = Webhook::where('id', $webhook->id)
                                  ->where('key', $webhook->key)
                                  ->first();

        if (!$verifiedWebhook) {
            return false;
        }

        $boardId = absint(Arr::get($verifiedWebhook->value, 'board'));
        if (!$boardId || !Board::where('id', $boardId)->first()) {
            $this->sendInvalidStageOrBoardResponse();
        }

        $stageId = $this->resolveWebhookStageId(
            $boardId,
            absint(Arr::get($verifiedWebhook->value, 'stage')),
            Arr::get($postData, 'stage')
        );

        if (!$stageId) {
            $this->sendInvalidStageOrBoardResponse();
        }

        $data = $postData;
        $data['board_id'] = $boardId;
        $data['stage_id'] = $stageId;

        $data = apply_filters('fluent_boards/webhook_task_data', $data, $verifiedWebhook);

        // Filters may enrich task data, but they cannot redirect a webhook to another board or stage.
        $data['board_id'] = $boardId;
        $data['stage_id'] = $stageId;

        return $this->createWebhookTask($data);
    }

    /**
     * Create an incoming webhook task while restricting assignees to existing board members.
     *
     * @param array $data
     * @return Task|false
     */
    private function createWebhookTask($data)
    {
        $taskData = Helper::sanitizeTaskForWebHook($data);
        $taskData['board_id'] = absint($data['board_id']);
        $taskData['stage_id'] = absint($data['stage_id']);

        $assignees = $this->normalizeWebhookListValue($data['assignees'] ?? []);
        if ($assignees) {
            $assigneeIds = [];
            $hasInvalidAssignee = false;

            foreach ($assignees as $assigneeId) {
                $assigneeId = filter_var($assigneeId, FILTER_VALIDATE_INT, [
                    'options' => ['min_range' => 1]
                ]);

                if (false === $assigneeId) {
                    $hasInvalidAssignee = true;
                    continue;
                }

                $assigneeIds[] = absint($assigneeId);
            }

            $assigneeIds = array_values(array_unique($assigneeIds));

            // Incoming webhooks may assign existing members but must never expand board membership.
            $boardMemberIds = Relation::query()
                                      ->where('object_id', $taskData['board_id'])
                                      ->where('object_type', Constant::OBJECT_TYPE_BOARD_USER)
                                      ->whereIn('foreign_id', $assigneeIds)
                                      ->pluck('foreign_id')
                                      ->toArray();
            $boardMemberIds = array_map('intval', $boardMemberIds);

            if ($hasInvalidAssignee || array_diff($assigneeIds, $boardMemberIds)) {
                wp_send_json_error([
                    'message' => __('One or more assignees are not members of this board.', 'fluent-boards-pro'),
                    'type'    => 'invalid_assignees'
                ], 422);
            }

            $users = get_users(['include' => $assigneeIds]);
            $taskData['assignees'] = array_map(function ($user) {
                return (int) $user->ID;
            }, $users);

            if (count($taskData['assignees']) !== count($assigneeIds)) {
                return false;
            }
        }

        if (!empty($taskData['priority']) && !in_array($taskData['priority'], $this->getAllowedTaskPriorities(), true)) {
            $taskData['priority'] = '';
        }

        if (!empty($taskData['status']) && !in_array($taskData['status'], ['open', 'closed'], true)) {
            $taskData['status'] = 'open';
        }

        if (!empty($data['crm_contact_id'])) {
            $taskData['crm_contact_id'] = absint($data['crm_contact_id']);
        } elseif (!empty($data['contact_email'])) {
            $contact = FluentCrmApi('contacts')->createOrUpdate([
                'email'      => sanitize_email($data['contact_email']),
                'first_name' => sanitize_text_field($data['contact_first_name'] ?? ''),
                'last_name'  => sanitize_text_field($data['contact_last_name'] ?? ''),
                'status'     => 'subscribed'
            ]);
            $taskData['crm_contact_id'] = $contact->id;
        }

        $labels = $this->normalizeWebhookListValue($data['labels'] ?? []);
        if ($labels) {
            $labelIds = [];
            foreach ($labels as $label) {
                $labelModel = is_numeric($label)
                    ? Label::where('id', absint($label))->where('board_id', $taskData['board_id'])->first()
                    : Label::where('board_id', $taskData['board_id'])
                           ->where(function ($query) use ($label) {
                               $label = sanitize_text_field($label);
                               $query->where('title', $label)->orWhere('slug', $label);
                           })
                           ->first();

                if ($labelModel) {
                    $labelIds[] = $labelModel->id;
                }
            }
            $taskData['labels'] = $labelIds;
        }

        return (new Task())->createTask($taskData);
    }

    /**
     * Resolve the final webhook stage while keeping overrides scoped to the saved board.
     *
     * @param int $boardId
     * @param int $savedStageId
     * @param mixed $postedStage
     * @return int
     */
    private function resolveWebhookStageId($boardId, $savedStageId, $postedStage = null)
    {
        $savedStage = Stage::where('id', $savedStageId)
                           ->where('board_id', $boardId)
                           ->first();

        if (!$savedStage || empty($postedStage)) {
            return $savedStage ? (int) $savedStage->id : 0;
        }

        $postedStage = sanitize_text_field($postedStage);
        $stage = Stage::where('board_id', $boardId)
                      ->where(function ($query) use ($postedStage) {
                          $query->where('title', $postedStage)
                                ->orWhere('slug', $postedStage);

                          if (is_numeric($postedStage)) {
                              $query->orWhere('id', absint($postedStage));
                          }
                      })
                     ->first();

        return $stage ? (int) $stage->id : (int) $savedStage->id;
    }

    /**
     * Send the existing invalid board/stage webhook error response.
     *
     * @return void
     */
    private function sendInvalidStageOrBoardResponse()
    {
        wp_send_json_error([
            'message' => __('Stage or Board Mismatched', 'fluent-boards-pro'),
            'type'    => 'invalid_stage_or_board'
        ], 200);
    }

    /**
     * Normalize webhook list fields that may arrive as JSON, scalar, or array.
     *
     * @param mixed $value
     * @return array
     */
    private function normalizeWebhookListValue($value)
    {
        if (empty($value)) {
            return [];
        }

        if (is_string($value)) {
            $decoded = json_decode($value, true);
            if (json_last_error() === JSON_ERROR_NONE) {
                $value = $decoded;
            }
        }

        return is_array($value) ? $value : [$value];
    }

    /**
     * Get priority keys allowed by the task priority filter.
     *
     * @return array
     */
    private function getAllowedTaskPriorities()
    {
        return array_map('strval', array_keys(apply_filters('fluent_boards/task_priorities', [
            ''       => __('No priority', 'fluent-boards'),
            'urgent' => __('Urgent', 'fluent-boards'),
            'high'   => __('High', 'fluent-boards'),
            'medium' => __('Medium', 'fluent-boards'),
            'low'    => __('Low', 'fluent-boards'),
        ])));
    }

    public function getWebhookByHash($hash)
    {
        return Webhook::where('key', $hash)->first();
    }

}
