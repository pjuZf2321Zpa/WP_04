<?php

namespace FluentBoardsPro\App\Hooks\Handlers;


use FluentBoards\App\Hooks\Handlers\BoardHandler;
use FluentBoards\App\Models\Board;
use FluentBoards\App\Models\Meta;
use FluentBoards\App\Models\Relation;
use FluentBoards\App\Models\Task;
use FluentBoards\App\Models\TaskMeta;
use FluentBoards\App\Services\PermissionManager;
use FluentBoards\App\Services\TaskService;
use FluentBoards\Framework\Support\DateTime;
use FluentBoardsPro\App\Modules\TimeTracking\Model\TimeTrack;
use FluentBoardsPro\App\Modules\TimeTracking\TimeTrackingHelper;
use FluentBoardsPro\App\Services\Constant;
use FluentBoardsPro\App\Services\ProTaskService;
use FluentBoardsPro\App\Services\Helper as ProHelper;
use InvalidArgumentException;
use Throwable;

class ProTaskHandler
{
    /** Run a due rule, retaining unsupported rules for correction without stopping other tasks. */
    public function repeatTask($task_id, $repeatMetaId = null)
    {
        $task = Task::find($task_id);
        $metaQuery = Meta::where('object_type', Constant::REPEAT_TASK_META)
            ->where('object_id', $task_id);

        if ($repeatMetaId) {
            $metaQuery->where('id', (int) $repeatMetaId);
        }

        $meta = $metaQuery->first();
        if(!$meta) {
            return null;
        }

        if (!$this->isRepeatMetaDue($meta)) {
            return null;
        }

        if (!$task) {
            $meta->delete();
            return null;
        }
        
        // Skip dead recurring sources without leaving due rows in the scheduler.
        if ($task->archived_at !== null) {
            $meta->delete();
            return null;
        }

        $board = Board::find($task->board_id);
        if (!$board || $board->archived_at !== null) {
            return null;
        }

        $repeatTaskStage = $meta['value']['selected_stage'] ?? $task['stage_id'];
        
        // Check if target stage exists and is not archived
        $stage = \FluentBoards\App\Models\Stage::find($repeatTaskStage);
        if (!$stage || $stage->archived_at !== null) {
            $meta->delete();
            return null;
        }
        
        // Validate stage and clean up meta if invalid
        if (!$this->validateRecurringTaskStage($task_id, $repeatTaskStage, $task['board_id'])) {
            return null;
        }
        try {
            $nextRepeatDate = $this->taskNextRepeatDate($task, $meta);
        } catch (InvalidArgumentException $e) {
            error_log(sprintf('Fluent Boards recurring task %d skipped: %s', $task_id, $e->getMessage()));
            return null;
        }
        if (!$nextRepeatDate) {
            $meta->delete();
            return null;
        }
        $due_at = $this->setDueDate($task, $meta, $nextRepeatDate);
        if ($meta['value']['create_new'] == 1) {
            if ($meta['value']['repeat_when_complete'] == 1) {
                // Create a new task when the current task is completed
                if ($task['status'] == 'closed') {
                    $newTask = $this->createNewTask($task, $repeatTaskStage, $meta['value']['next_repeat_date'], $due_at);
                    $this->updateTaskRepeatMeta($meta, $nextRepeatDate, $newTask->id);
                }
            } else {
                // Create a new task regardless of the current task's status
                $this->createNewTask($task, $repeatTaskStage, $meta['value']['next_repeat_date'], $due_at);
                $this->updateTaskRepeatMeta($meta, $nextRepeatDate);
            }
        } else {
            if($meta['value']['repeat_when_complete'] == 1) {
                // Update the due_at date when the current task is completed
                if ($task['status'] == 'closed') {
                    $this->updateTask($task, $repeatTaskStage, $meta['value']['next_repeat_date'], $due_at);
                    $this->updateTaskRepeatMeta($meta, $nextRepeatDate);
                }
            } else {
                // Update the due_at date regardless of the current task's status
                $this->updateTask($task, $repeatTaskStage, $meta['value']['next_repeat_date'], $due_at);
                $this->updateTaskRepeatMeta($meta, $nextRepeatDate);
            }
        }
    }
    /** Calculate the next occurrence in the saved timezone, normalizing legacy aliases. */
    private function taskNextRepeatDate($task, $meta)
    {
        
        $timeZone = ProHelper::recurringTimezone(!empty($meta['value']['next_repeat_date']) ? $meta['value'] : null);
        $nextRepeat = new DateTime('now', $timeZone);
        if (!empty($meta['value']['next_repeat_date'])) {
            // The saved recurrence date is wall time in the selected timezone.
            $nextRepeat = new DateTime($meta['value']['next_repeat_date'], $timeZone);
        } else {
            if (!empty($task['due_at']) || !empty($task['started_at'])) {
                $dateString = !empty($task['due_at']) ? $task['due_at'] : $task['started_at'];
                $date = new DateTime($dateString);
                $nextRepeat->setDate($date->format('Y'), $date->format('m'), $date->format('d'));
            }
        }
        $previousRepeat = clone $nextRepeat;
        $repeatIn = !empty($meta['value']['repeat_in']) && $meta['value']['repeat_in'] > 0 ? intval($meta['value']['repeat_in']) : 1;
        $repeatType = $meta['value']['repeat_type'];
        if (!in_array($repeatType, Constant::TASK_REPEAT_TYPES, true)) {
            return null;
        }

        if ($repeatType === 'daily') {
            if ($repeatIn > 365) {
                $repeatIn = 365;
            }
            $nextRepeat->modify("+$repeatIn days");
        } elseif ($repeatType === 'weekly') {
            if ($repeatIn > 99) {
                $repeatIn = 99;
            }
            if (!empty($meta['value']['selected_repeat_week_days'])) {
                $weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
                $selected_repeat_week_days = array_values(array_filter((array) $meta['value']['selected_repeat_week_days'], function ($day) use ($weekDays) {
                    return in_array($day, $weekDays, true);
                }));
                if (!$selected_repeat_week_days) {
                    return null;
                }
                usort($selected_repeat_week_days, function ($a, $b) use ($weekDays) {
                    return array_search($a, $weekDays) <=> array_search($b, $weekDays);
                });
                $currentDayIndex = $nextRepeat->format('w');
                $nextDayIndex = null;
                foreach ($selected_repeat_week_days as $day) {
                    if (array_search($day, $weekDays) > $currentDayIndex) {
                        $nextDayIndex = array_search($day, $weekDays);
                        break;
                    }
                }
                if ($nextDayIndex !== null) {
                    $nextRepeat->modify('+' . ((($repeatIn - 1) * 7) + ($nextDayIndex - $currentDayIndex)) . ' days');
                } else {
                    $nextRepeat->modify('+' . (($repeatIn * 7) - $currentDayIndex + array_search($selected_repeat_week_days[0], $weekDays)) . ' days');
                }
            } else {
                $nextRepeat->modify("+$repeatIn weeks");
            }
        } elseif ($repeatType === 'monthly') {
            if ($repeatIn > 12) {
                $repeatIn = 12;
            }
            if (!empty($meta['value']['selected_month_days'])) {
                $selected_month_days = array_values(array_filter(array_map('intval', (array) $meta['value']['selected_month_days']), function ($day) {
                    return $day >= 1 && $day <= 31;
                }));
                if (!$selected_month_days) {
                    return null;
                }
                sort($selected_month_days);
                $currentDay = $nextRepeat->format('d');
                $nextDay = null;
                foreach ($selected_month_days as $day) {
                    if ($day > $currentDay) {
                        $nextDay = $day;
                        break;
                    }
                }
                if ($nextDay !== null) {
                    $nextRepeat->setDate($nextRepeat->format('Y'), $nextRepeat->format('m'), $nextDay);
                    $nextRepeat->modify('+' . ($repeatIn - 1) . ' months');
                } else {
                    $nextRepeat->setDate($nextRepeat->format('Y'), $nextRepeat->format('m') + $repeatIn, $selected_month_days[0]);
                }
            } elseif ($meta['value']['repeat_in_month_type'] === 'firstDay') {
                $nextRepeat->setDate($nextRepeat->format('Y'), $nextRepeat->format('m'), 1);
                $nextRepeat->modify("+$repeatIn months");
            } elseif ($meta['value']['repeat_in_month_type'] === 'lastDay') {
                $nextRepeat->setDate($nextRepeat->format('Y'), $nextRepeat->format('m'), 1);
                $nextRepeat->modify("+$repeatIn months");
                $nextRepeat->modify('last day of this month');
            } else {
                $nextRepeat->modify("+$repeatIn months");
            }
        } elseif ($repeatType === 'yearly') {
            if (!empty($meta['value']['selected_month']) && !empty($meta['value']['selected_month_days'])) {
                $monthIndex = array_search($meta['value']['selected_month'], Constant::TASK_REPEAT_MONTHS, true);
                if ($monthIndex === false) {
                    return null;
                }
                $selected_month_days = array_values(array_filter(array_map('intval', (array) $meta['value']['selected_month_days']), function ($day) {
                    return $day >= 1 && $day <= 31;
                }));
                if (!$selected_month_days) {
                    return null;
                }
                sort($selected_month_days);
                $nextRepeatDate = null;
                foreach ($selected_month_days as $day) {
                    $candidate = clone $nextRepeat;
                    $candidate->setDate($nextRepeat->format('Y'), $monthIndex + 1, $day);
                    if ($candidate->getTimestamp() > $previousRepeat->getTimestamp()) {
                        $nextRepeatDate = $candidate;
                        break;
                    }
                }

                if ($nextRepeatDate) {
                    $nextRepeat = $nextRepeatDate;
                    $nextRepeat->modify('+' . ($repeatIn - 1) . ' years');
                } else {
                    $nextRepeat->setDate($nextRepeat->format('Y') + $repeatIn, $monthIndex + 1, $selected_month_days[0]);
                }
            } elseif ($meta['value']['repeat_in_month_type'] === 'firstDay') {
                $nextRepeat->setDate($nextRepeat->format('Y') + $repeatIn, 1, 1);
            } elseif ($meta['value']['repeat_in_month_type'] === 'lastDay') {
                $nextRepeat->setDate($nextRepeat->format('Y') + $repeatIn, 12, 31);
            } else {
                $nextRepeat->modify("+$repeatIn years");
            }
        }

        if (!empty($meta['value']['time'])) {
            $time = $meta['value']['time'];
            $hours = intval(substr($time, 0, 2));
            $minutes = intval(substr($time, 3, 2));
            $seconds = intval(substr($time, 6, 2));

            $nextRepeat->setTime($hours, $minutes, $seconds);
        }

        $next_repeat_date = $nextRepeat->format('Y-m-d H:i:s');
        $serverTimeZone = new \DateTimeZone(date_default_timezone_get());
        $nextRepeat->setTimezone($serverTimeZone);
        $next_repeat_date_server = $nextRepeat->format('Y-m-d H:i:s');
        
        return [
            'next_repeat_date' => $next_repeat_date,
            'next_repeat_date_server' => $next_repeat_date_server
        ];


    }

    private function createNewTask($task, $repeatTaskStage, $started_at, $due_at)
    {
        $newTask = Task::withoutTaskCreatedEvent(function() use ($task, $repeatTaskStage, $started_at, $due_at) {
            $newTask = $task->replicate()->fill([
                'started_at' => $started_at,
                'due_at' => $due_at,
                'status' => 'open',
                'archived_at' => null,
                'last_completed_at' => null,
                'stage_id' => $repeatTaskStage
            ]);

            $newTask->save();
            $newTask->moveToNewPosition(1);
            return $newTask;
        });

        do_action('fluent_boards/repeat_task_created', $newTask, $task);
        do_action('fluent_boards/task_due_date_changed', $newTask, $started_at);

        $this->addAssigneesToNewTask($newTask, $task);
        $this->addWatcherToNewTask($newTask, $task);
        $this->addLabelsToNewTask($newTask, $task);
        (new ProTaskService())->copyCustomFieldAssociations($task->id, $newTask->id);
        
        // Clone subtask groups first to get the group mapping
        $subtaskGroupMap = $this->cloneSubtaskGroups($task, $newTask);
        $this->createNewSubtasks($newTask, $task, $started_at, $due_at, $subtaskGroupMap);

        // Restore creation side effects without re-running generic creation/CRM hooks.
        (new BoardHandler())->updateBoardTaskCount($newTask->board_id);
        try {
            $webhookTask = Task::findOrFail($newTask->id);
            $webhookTask->is_recurring = true;
            $webhookTask->source_task_id = (int) $task->id;
            (new OutWebhookHandler())->queueTaskCreatedWebhook($webhookTask);
        } catch (Throwable $e) {
            // A queue failure must not leave this repeat due and create another copy.
            error_log(sprintf('FluentBoards recurring webhook queue failed for task %d.', (int) $newTask->id));
        }

        return $newTask;
    }
    private function updateTaskRepeatMeta($meta, $nextRepeatDate, $taskId = null)
    {
        $previousTaskId = isset($meta->object_id) ? (int) $meta->object_id : (int) $taskId;
        $value = (array) $meta->value;
        $value['next_repeat_date'] = $nextRepeatDate['next_repeat_date'];
        $data = [
            'value' => $value,
            'key' => $nextRepeatDate['next_repeat_date_server']
        ];

        if ($taskId) {
            $data['object_id'] = (int) $taskId;
        }

        $meta->update($data);

        $targetTaskId = $taskId ? (int) $taskId : $previousTaskId;
        $keepMetaId = isset($meta->id) ? (int) $meta->id : 0;

        $this->deleteDuplicateRepeatMetas($previousTaskId, $keepMetaId);

        if ($targetTaskId !== $previousTaskId) {
            $this->deleteDuplicateRepeatMetas($targetTaskId, $keepMetaId);
        }
    }

    private function isRepeatMetaDue($meta)
    {
        if (empty($meta->key)) {
            return true;
        }

        $dateTime = new \DateTime('now', new \DateTimeZone(date_default_timezone_get()));

        return $meta->key <= $dateTime->format('Y-m-d H:i:s');
    }

    private function deleteDuplicateRepeatMetas($taskId, $keepMetaId)
    {
        $taskId = (int) $taskId;
        $keepMetaId = (int) $keepMetaId;

        if (!$taskId || !$keepMetaId) {
            return;
        }

        Meta::where('object_id', $taskId)
            ->where('object_type', Constant::REPEAT_TASK_META)
            ->where('id', '!=', $keepMetaId)
            ->delete();
    }
    private function updateTask($task, $repeatTaskStage, $startedAt, $dueAt)
    {
        $task->update([
            'started_at' => $startedAt,
            'due_at' => $dueAt,
            'stage_id' => $repeatTaskStage
        ]);
        $task->reopen();
        // update subtasks
        $subTasks = $task->subTasks;
        foreach ($subTasks as $subTask) {
            $subTask->update([
                'started_at' => $startedAt,
                'due_at' => $dueAt,
                'stage_id' => $repeatTaskStage
            ]);
            $subTask->reopen();
        }
        
    }

    private function setDueDate($task, $meta, $nextRepeatDate)
    {
        if (empty($task->due_at)) {
            return null;
        }

        $startedAt = new DateTime($meta['value']['next_repeat_date']);

        if (empty($task->started_at)) {
            return $startedAt;
        }

        $taskDueAt = new DateTime($task->due_at);
        $taskStartAt = new DateTime($task->started_at);
        $interval = $taskStartAt->diff($taskDueAt);
        $startedAt->add($interval);

        return $startedAt->modify('-5 minutes');
    }

    private function addAssigneesToNewTask($newTask, $oldTask)
    {
        // Runs from cron: skip assignees who left the board rather than failing the recurrence.
        $assigneeIds = PermissionManager::getUserIdsWithBoardAccess(
            $newTask->board_id,
            $oldTask->assignees->pluck('ID')->all()
        );
        foreach ($assigneeIds as $assigneeId) {
            (new TaskService())->updateAssignee($assigneeId, $newTask);
        }
    }

    private function addLabelsToNewTask($newTask, $oldTask)
    {
        $oldTaskLabels = $oldTask->labels;
        foreach ($oldTaskLabels as $label) {
            $newRelation = new Relation();
            $newRelation['object_id'] = $newTask->id;
            $newRelation['object_type'] = \FluentBoards\App\Services\Constant::OBJECT_TYPE_TASK_LABEL;
            $newRelation['foreign_id'] = $label->id;
            $newRelation->save();
        }
    }
    private function createNewSubtasks($newTask, $oldTask, $started_at, $due_at, $subtaskGroupMap = [])
    {
        $subTasks = $oldTask->subTasks;
        foreach ($subTasks as $subTask) {
            $newSubTask = $subTask->replicate()->fill([
                'parent_id' => $newTask->id,
                'board_id' => $newTask->board_id,
                'stage_id' => $newTask->stage_id,
                'started_at' => $started_at,
                'due_at' => $due_at,
                'status' => 'open',
                'archived_at' => null,
                'last_completed_at' => null
            ]);
            $newSubTask->save();

            $this->addAssigneesToNewTask($newSubTask, $subTask);
            (new ProTaskService())->copyCustomFieldAssociations($subTask->id, $newSubTask->id);
            
            // Copy subtask group relationship
            $groupRelation = TaskMeta::where('task_id', $subTask->id)
                ->where('key', \FluentBoards\App\Services\Constant::SUBTASK_GROUP_CHILD)
                ->first();

            if ($groupRelation && isset($subtaskGroupMap[$groupRelation->value])) {
                TaskMeta::create([
                    'task_id' => $newSubTask->id,
                    'key' => \FluentBoards\App\Services\Constant::SUBTASK_GROUP_CHILD,
                    'value' => $subtaskGroupMap[$groupRelation->value]
                ]);
            }
        }
    }

    private function addWatcherToNewTask($newTask, $oldTask)
    {
        $oldTaskWatchers = $oldTask->watchers;
        foreach ($oldTaskWatchers as $watcher) {
            $existingWatcher = Relation::where('object_id', $newTask->id)->where('object_type', \FluentBoards\App\Services\Constant::OBJECT_TYPE_USER_TASK_WATCH)->where('foreign_id', $watcher->ID)->first();
            if (!$existingWatcher) {
                $newRelation = new Relation();
                $newRelation['object_id'] = $newTask->id;
                $newRelation['object_type'] = \FluentBoards\App\Services\Constant::OBJECT_TYPE_USER_TASK_WATCH;
                $newRelation['foreign_id'] = $watcher->ID;
                $newRelation->save();
            }
        }
    }

    /**
     * Clone subtask groups from old task to new task for recurring tasks
     * @param Task $oldTask The original recurring task
     * @param Task $newTask The newly created recurring task
     * @return array Map of old group IDs to new group IDs
     */
    private function cloneSubtaskGroups($oldTask, $newTask)
    {
        $subtaskGroupMap = [];
        
        $subtaskGroups = TaskMeta::where('task_id', $oldTask->id)
            ->where('key', \FluentBoards\App\Services\Constant::SUBTASK_GROUP_NAME)
            ->get();
        
        foreach ($subtaskGroups as $group) {
            $newGroup = TaskMeta::create([
                'task_id' => $newTask->id,
                'key' => \FluentBoards\App\Services\Constant::SUBTASK_GROUP_NAME,
                'value' => $group->value
            ]);
            
            $subtaskGroupMap[$group->id] = $newGroup->id;
        }
        
        return $subtaskGroupMap;
    }

    /**
     * Move every time-track record with its task to the destination board.
     */
    public function handleTaskBoardMoveAndUpdateTimeTracking($task)
    {
        $taskId = absint($task->id);
        $boardId = absint($task->board_id);

        if (!$taskId || !$boardId || !TimeTrackingHelper::timeTrackingTableExists()) {
            return;
        }

        // Bypass ORM timestamps so board ownership is the only changed field.
        TimeTrack::where('task_id', $taskId)
            ->toBase()
            ->update(['board_id' => $boardId]);
    }
    
    /**
     * Validate recurring task stage and cleanup metadata if invalid
     * 
     * @param int $taskId The task ID
     * @param int $stageId The stage ID to validate
     * @param int $boardId The board ID to check against
     * @return bool True if stage is valid, false if invalid (and meta deleted)
     */
    private function validateRecurringTaskStage($taskId, $stageId, $boardId)
    {
        // Basic input validation - convert to int and check if valid
        $taskId = (int) $taskId;
        $stageId = (int) $stageId;
        $boardId = (int) $boardId;
        
        if ($taskId <= 0 || $stageId <= 0 || $boardId <= 0) {
            return false;
        }
        
        try {
            // Check if stage exists on the specified board
            $stageExists = \FluentBoards\App\Models\Stage::where('id', $stageId)
                ->where('board_id', $boardId)
                ->exists();
                
            if (!$stageExists) {
                // Stage doesn't exist - delete recurring metadata
                $deletedRows = Meta::where('object_id', $taskId)
                    ->where('object_type', Constant::REPEAT_TASK_META)
                    ->delete();
                    
                if ($deletedRows > 0) {
                    error_log("FluentBoards: Recurring task metadata deleted - original stage no longer exists on current board");
                }
                return false;
            }
            
            return true;
            
        } catch (\Exception $e) {
            error_log("FluentBoards: Error validating recurring task stage: " . $e->getMessage());
            return false;
        }
    }
}
