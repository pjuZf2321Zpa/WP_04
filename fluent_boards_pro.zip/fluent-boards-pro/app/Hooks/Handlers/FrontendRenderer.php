<?php

namespace FluentBoardsPro\App\Hooks\Handlers;


use FluentBoards\App\Hooks\Handlers\AdminMenuHandler;
use FluentBoards\App\Services\PermissionManager;
use FluentBoardsPro\App\Core\App;

class FrontendRenderer
{
    public function register()
    {
        // check if the frontend features are enabled
        $featureSettings = fluent_boards_get_pref_settings(true);

        $frontendSettings = \FluentBoards\Framework\Support\Arr::get($featureSettings, 'frontend', []);

        if ($frontendSettings['enabled'] !== 'yes') {
            return;
        }

        add_action('init', function () {
            $frontAppUrl = \FluentBoardsPro\App\Services\ProHelper::getFrontAppUrl();

            if (!$frontAppUrl) {
                return;
            }

            add_filter('fluent_boards/app_url', function ($url) use ($frontAppUrl) {
                return $frontAppUrl;
            }, 100);

            add_action('template_redirect', function () {
                $frontSlug = \FluentBoardsPro\App\Services\ProHelper::getFrontEndSlug();

                if (!$frontSlug) {
                    return;
                }

                global $wp;
                $currentUrl = home_url($wp->request);

                $extension = str_replace(home_url(), '', $currentUrl);

                if (!$extension) {
                    return;
                }

                // trim the /
                $uri = trim($extension, '/');

                if (!$uri) {
                    return;
                }

                $urlParts = array_values(array_filter(explode('/', $uri)));

                if (!count($urlParts) || $urlParts[0] !== $frontSlug) {
                    return;
                }

                $this->renderFullApp();
            }, 1);
        }, 1);

        if($frontendSettings['render_type'] === 'shortcode') {
            add_shortcode('fluent_boards', [$this, 'renderFrontendShortcode']);
        }
        // Add frontend portal menu item
        add_action('admin_bar_menu', [$this, 'addFrontendPortalMenuItem'], 99);

    }

    public function renderFullApp()
    {
        // Logout now lives inside the profile-avatar dropdown (ProfileMenu.vue),
        // so the standalone logout link in the menu actions bar is no longer added here.

        $this->disableConflictingAssetsForPortal();

        add_filter('fluent_boards/app_logo', function ($logo) {
            if (function_exists('get_theme_mod')) {
                $custom_logo_id = get_theme_mod('custom_logo');
                $custom_logo = wp_get_attachment_url($custom_logo_id);
                if ($custom_logo) {
                    return $custom_logo;
                }
            }
            return $logo;
        }, 9, 1);

        // remove wp admin bar
        add_filter('show_admin_bar', '__return_false');

        $app = App::getInstance();

        if (get_current_user_id()) {
            $content = (string)$this->getRenderedContent();
        } else {
            $content = $this->getAuthContent();
        }

        $app->view->render('front-app', [
            'content' => $content
        ]);

        exit;
    }

    protected function disableConflictingAssetsForPortal()
    {
        add_action('wp_print_styles', function () {
            global $wp_styles;
            $this->dequeuePortalAssets($wp_styles, 'style');
        }, 100);

        add_action('wp_print_scripts', function () {
            global $wp_scripts;
            $this->dequeuePortalAssets($wp_scripts, 'script');
        }, 100);
    }

    protected function dequeuePortalAssets($registry, $type)
    {
        if (!$registry || empty($registry->queue) || empty($registry->registered)) {
            return;
        }

        foreach ((array)$registry->queue as $handle) {
            if (empty($registry->registered[$handle])) {
                continue;
            }

            $src = $registry->registered[$handle]->src ?? '';

            if ($this->shouldKeepPortalAsset($src)) {
                continue;
            }

            if ($type === 'style') {
                wp_dequeue_style($handle);
            } else {
                wp_dequeue_script($handle);
            }
        }
    }

    protected function shouldKeepPortalAsset($src)
    {
        $src = (string)$src;

        if ($src === '') {
            return true;
        }

        $normalizedSrc = strtolower(str_replace(['http:', 'https:'], '', $src));

        $coreAssetMarkers = [
            '/wp-admin/',
            '/wp-includes/',
            '@vite/client',
            '/resources/',
        ];

        foreach ($coreAssetMarkers as $marker) {
            if (strpos($normalizedSrc, $marker) !== false) {
                return true;
            }
        }

        $approvedSlugs = apply_filters('fluent_boards/asset_listed_slugs', [
            '\/fluent-crm\/',
        ]);

        $approvedSlugs[] = '\/fluent-boards\/';
        $approvedSlugs[] = '\/fluent-boards-pro\/';
        $approvedSlugs[] = '\/fluent-security\/';

        $approvedSlugs = apply_filters('fluent_boards/portal_asset_listed_slugs', array_unique($approvedSlugs));

        foreach ($approvedSlugs as $approvedSlug) {
            $approvedSlug = (string)$approvedSlug;

            if (!$approvedSlug) {
                continue;
            }

            $isMatched = @preg_match('/' . $approvedSlug . '/', $normalizedSrc);

            if ($isMatched === 1) {
                return true;
            }

            if ($isMatched === false && strpos($normalizedSrc, strtolower(str_replace('\/', '/', $approvedSlug))) !== false) {
                return true;
            }
        }

        return false;
    }

    public function renderFrontendShortcode()
    {
        add_filter('fluent_boards/app_url', function () {
            $page = get_the_permalink();
            return $page . '#/';
        }, 100);

        add_filter('fluent_boards/app_icon', function ($logo) {
            if (function_exists('get_theme_mod')) {
                $custom_logo_id = get_theme_mod('custom_logo');
                $custom_logo = wp_get_attachment_url($custom_logo_id);
                if ($custom_logo) {
                    return $custom_logo;
                }
            }
            return $logo;
        }, 9, 1);

        add_filter('fluent_boards/skip_no_conflict', '__return_true');

        wp_enqueue_style('fluent-boards-pro-frontend', FLUENT_BOARDS_PRO_URL . 'dist/css/frontend.css', [], FLUENT_BOARDS_PRO_VERSION);

        if (!get_current_user_id()) {
            return $this->getAuthContent();
        }

        if (!PermissionManager::userHasAnyBoardAccess(get_current_user_id())) {
            return '<div class="fbs_no_permission">' . apply_filters('fluent_boards/no_permission_message', __('You do not have permission to view the projects', 'fluent-boards-pro')) . '</div>';
        }

        return (string)$this->getRenderedContent('fbs_page_render');
    }

    protected function getRenderedContent($extraClass = '')
    {

        add_filter('fluent_boards/menu_items', function ($items) {

            unset($items['help']);

            return $items;

        });

        (new AdminMenuHandler())->enqueueAssets();

        ob_start();

        echo '<div class="fluent_boards_frontend fbs_front ' . esc_attr($extraClass) . '">';

        (new AdminMenuHandler())->render();

        echo '</div>';

        return ob_get_clean();
    }

    public function getAuthContent()
    {
        $loginContent = '';
        if (defined('FLUENT_AUTH_PLUGIN_PATH')) {
            add_filter('fluent_boards/asset_listed_slugs', function ($slugs) {
                $slugs[] = '\/fluent-security\/';
                return $slugs;
            });

            $authHandler = new \FluentAuth\App\Hooks\Handlers\CustomAuthHandler();

            if ($authHandler->isEnabled()) {
                $loginContent = do_shortcode('[fluent_auth_login redirect_to="self"]');
            }
        }

        if (!$loginContent) {
            $loginContent = wp_login_form([
                'echo'     => false,
                'redirect' => fluent_boards_page_url()
            ]);
        }

        return '<div class="fbs_login_form"><div class="fbs_login_form_heading">' . apply_filters('fluent_boards/login_header', __('Please login to view the project', 'fluent-boards-pro')) . '</div><div class="fbs_login_wrap">' . $loginContent . '</div></div>';
    }

    /**
     * Adds a menu item to the WordPress admin bar for accessing the FluentBoards frontend portal
     * 
     * @param \WP_Admin_Bar $wp_admin_bar WordPress admin bar object
     * @return void
     */
    public function addFrontendPortalMenuItem($wp_admin_bar)
    {
        // Early return if user doesn't have access
        if (!PermissionManager::userHasAnyBoardAccess()) {
            return;
        }

        // Check if frontend features are enabled
        $frontAppUrl = \FluentBoardsPro\App\Services\ProHelper::getFrontAppUrl();
        $frontSlug = \FluentBoardsPro\App\Services\ProHelper::getFrontEndSlug();

        if (!$frontAppUrl || !$frontSlug) {
            return;
        }

        // Add menu item to admin bar
        $wp_admin_bar->add_node([
            'id'     => 'fluent-boards-frontend',
            'parent' => 'site-name',
            'title'  => __('Visit FluentBoards Portal', 'fluent-boards-pro'),
            'href'   => home_url($frontSlug),
            'meta'   => [
                'target' => '_blank'
            ]
        ]);
    }
}
