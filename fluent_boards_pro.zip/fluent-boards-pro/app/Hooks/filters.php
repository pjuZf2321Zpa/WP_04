<?php

/**
 * @var $app FluentBoards\Framework\Foundation\Application
 */


use FluentBoardsPro\App\Modules\TimeTracking\TimeTrackingHelper;
use FluentBoardsPro\App\Services\ProHelper;

$app->addFilter('fluent_boards/accepted_plugins', 'FluentBoardsPro\App\Hooks\Handlers\InstallationHandler@acceptedPlugins',10, 1);
$app->addFilter('fluent_boards/addons_settings', 'FluentBoardsPro\App\Hooks\Handlers\InstallationHandler@addOnSettings', 10, 1);

// Board Template menu items (Pro feature)
add_filter('fluent_boards/board_menu_items', function ($menuItems) {
    $menuItems[] = [
        'key' => 'make_template',
        'icon_name' => 'template',
        'label' => __('Make Template', 'fluent-boards-pro'),
        'type' => 'default',
        'position' => 10.2,
        'role' => 'manager',
        'pro' => true
    ];

    $menuItems[] = [
        'key' => 'convert_to_board',
        'icon_name' => 'convert_to_board',
        'label' => __('Convert to Board', 'fluent-boards-pro'),
        'type' => 'default',
        'position' => 10.3,
        'role' => 'manager',
        'pro' => true
    ];

    return $menuItems;
}, 10, 1);


(new \FluentBoardsPro\App\Services\PluginManager\PluginInstaller())->registerCoreUpdater();

// Let Core detect the direct-download contract independently of plugin version numbers.
add_filter('fluent_boards/app_vars', function ($vars) {
    $vars['board_export_streaming'] = true;
    $vars['board_background_presets'] = ProHelper::getBoardBackgroundPresets();
    return $vars;
});
