<?php

/**
 * @var $app FluentBoards\Framework\Foundation\Application
 */

use FluentBoardsPro\App\Hooks\Handlers\InvitationHandler;
use FluentBoardsPro\App\Hooks\Handlers\ProScheduleHandler;

(new \FluentBoardsPro\App\Hooks\Handlers\FrontendRenderer())->register();
(new \FluentBoardsPro\App\Hooks\Handlers\ExternalPages())->registerPublicBoard();

/*
 * MCP - Register Pro abilities under the core `fluent-boards/` namespace.
 */
(new \FluentBoardsPro\App\Modules\MCP\MCPInit())->init();

$app->addAction('admin_post_myform', 'InvitationHandler@processInvitation', 10, 0);
$app->addAction('admin_post_nopriv_myform', 'InvitationHandler@processInvitation', 10, 0);
$app->addAction('wp_ajax_fluent_boards_export_timesheet', 'FluentBoardsPro\App\Hooks\Handlers\DataExporter@exportTimeSheet', 10, 0);

/* 
 * Begin Webhook Related Actions
 */

(new \FluentBoardsPro\App\Hooks\Handlers\OutWebhookHandler())->ListenWebhookActions();

$app->addAction('fluent_boards/async_task_created_webhook', 'OutWebhookHandler@handleWebhookRequest', 10, 3);
$app->addAction('fluent_boards/async_task_completed_webhook', 'OutWebhookHandler@handleWebhookRequest', 10, 3);
$app->addAction('fluent_boards/async_task_stage_updated_webhook', 'OutWebhookHandler@handleWebhookRequest', 10, 3);
$app->addAction('fluent_boards/async_task_date_changed_webhook', 'OutWebhookHandler@handleWebhookRequest', 10, 3);
$app->addAction('fluent_boards/async_task_priority_changed_webhook', 'OutWebhookHandler@handleWebhookRequest', 10, 3);
$app->addAction('fluent_boards/async_task_label_added_webhook', 'OutWebhookHandler@handleWebhookRequest', 10, 3);
$app->addAction('fluent_boards/async_task_label_removed_webhook', 'OutWebhookHandler@handleWebhookRequest', 10, 3);
$app->addAction('fluent_boards/async_stage_added_webhook', 'OutWebhookHandler@handleWebhookRequest', 10, 3);
$app->addAction('fluent_boards/async_comment_created_webhook', 'OutWebhookHandler@handleWebhookRequest', 10, 3);
$app->addAction('fluent_boards/async_task_assignee_added_webhook', 'OutWebhookHandler@handleWebhookRequest', 10, 3);
$app->addAction('fluent_boards/async_task_archived_webhook', 'OutWebhookHandler@handleWebhookRequest', 10, 3);

/*
 *  End Webhook Related Actions
 */

$app->addAction('fluent_boards/five_minutes_scheduler', [ProScheduleHandler::class, 'fiveMinutesScheduler'], 10, 0);
$app->addAction('fluent_boards/hourly_scheduler', 'ProScheduleHandler@hourlyScheduler', 10, 0);
$app->addAction('fluent_boards/daily_scheduler', 'ProScheduleHandler@dailyScheduler', 10, 0);
$app->addAction('fluent_boards/daily_task_reminder', 'ProScheduleHandler@dailyTaskSummaryMail', 10, 0);
$app->addAction('fluent_boards/install_plugin', 'FluentBoardsPro\App\Hooks\Handlers\InstallationHandler@installPlugin', 10, 2);
$app->addFilter('fluent_boards/repeat_task', 'FluentBoardsPro\App\Hooks\Handlers\ProTaskHandler@repeatTask', 10, 2);
$app->addAction('fluent_boards/repeat_task_scheduler', 'FluentBoardsPro\App\Hooks\Handlers\ProScheduleHandler@repeatTasks', 10, 0);
$app->addAction('fluent_boards/recurring_task_disabled', 'FluentBoardsPro\App\Hooks\Handlers\ProScheduleHandler@clearRepeatTaskScheduler', 10, 0);

$app->addAction('fluent_boards/task_reminder_scheduler_for_rest', [ProScheduleHandler::class, 'processTaskRemindersForRest'], 10, 0);

$app->addAction('wp_ajax_fluent_boards_export_csv', 'FluentBoardsPro\App\Hooks\Handlers\DataExporter@exportBoardInCsv', 10, 0);

$app->addAction('fluent_boards/send_invitation', [InvitationHandler::class, 'sendInvitationViaEmail'], 10, 4);


$app->addAction('wp_ajax_fluent_boards_export_json', 'FluentBoardsPro\App\Hooks\Handlers\DataExporter@exportBoardInJson', 10, 0);

$app->addAction('fluent_boards/task_moved_update_time_tracking', 'FluentBoardsPro\App\Hooks\Handlers\ProTaskHandler@handleTaskBoardMoveAndUpdateTimeTracking', 10, 1);

/*
 * Task Dependency Actions
 */
$app->addAction('fluent_boards/task_dependency_added', 'FluentBoardsPro\App\Hooks\Handlers\DependencyHandler@logDependencyAdded', 10, 3);
$app->addAction('fluent_boards/task_dependency_removed', 'FluentBoardsPro\App\Hooks\Handlers\DependencyHandler@logDependencyRemoved', 10, 3);
$app->addAction('fluent_boards/task_deleted', 'FluentBoardsPro\App\Hooks\Handlers\DependencyHandler@cleanupDependencies', 10, 1);
$app->addAction('fluent_boards/before_task_deleted', 'FluentBoardsPro\App\Hooks\Handlers\DependencyHandler@cleanupDependencies', 10, 2);
$app->addAction('fluent_boards/task_closed', 'FluentBoardsPro\App\Hooks\Handlers\DependencyHandler@notifyDependencyUnblocked', 10, 1);

/*
 * Async Template Task Creation Actions (chunked batch processing)
 */
add_action('fluent_boards/async_create_tasks_from_template', function ($boardId) {
    (new \FluentBoardsPro\App\Services\TemplateService())->handleAsyncCreateTasksFromTemplate($boardId);
}, 10, 1);

add_action('fluent_boards/async_copy_tasks_from_user_template', function ($newBoardId) {
    (new \FluentBoardsPro\App\Services\TemplateService())->handleAsyncCopyTasksFromUserTemplate($newBoardId);
}, 10, 1);

add_action('fluent_boards/process_trello_import', function ($importId, $coverRun = null) {
    \FluentBoardsPro\App\Services\TrelloImporter::processAsyncImport($importId, $coverRun);
}, 10, 2);

add_action('fluent_boards/recover_trello_import', function ($importId, $coverRun = null) {
    \FluentBoardsPro\App\Services\TrelloImporter::recoverAsyncImport($importId, $coverRun);
}, 10, 2);

add_action('fluent_boards/before_board_deleted', [\FluentBoardsPro\App\Services\TrelloImporter::class, 'deleteBoardCoverWork']);

/*
 * IMPORTANT
 * External Pages Handler
 * Each Request must have fbs=1 as a query parameter, then the plugin will handle the request.
 */

if(isset($_GET['fbs']) && $_GET['fbs'] == 1) {

    // For viewing attachment
    if(isset($_GET['fbs_attachment'])) {
        add_action('init', function() {
            (new \FluentBoardsPro\App\Hooks\Handlers\ExternalPages())->view_attachment();
        });
    }

    // Form page for invited user to join the board
    if(isset($_GET['invitation']) && $_GET['invitation'] == 'board') {
        add_action('init', function () {
            (new \FluentBoardsPro\App\Hooks\Handlers\ExternalPages())->boardMemberInvitation();
        });
    }
}
