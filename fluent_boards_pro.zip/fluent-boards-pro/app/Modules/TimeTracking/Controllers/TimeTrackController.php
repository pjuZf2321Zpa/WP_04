<?php

namespace FluentBoardsPro\App\Modules\TimeTracking\Controllers;

use FluentBoards\App\Services\PermissionManager;
use FluentBoards\App\Services\TaskService;
use FluentBoards\Framework\Http\Request\Request;
use FluentBoardsPro\App\Modules\TimeTracking\Model\TimeTrack;
use FluentBoardsPro\App\Modules\TimeTracking\TimeTrackingHelper;
use FluentBoardsPro\App\Services\ProTaskService;
use FluentBoardsPro\App\Services\Helper;
use InvalidArgumentException;

class TimeTrackController extends \FluentBoards\App\Http\Controllers\Controller
{
    public function getTracks(Request $request, $boardId, $taskId)
    {
        (new TaskService())->findTaskOnBoard($taskId, $boardId);

        $tracks = (new ProTaskService())->getTaskTimeTrack($boardId, $taskId);

        return [
            'tracks'            => $tracks,
            'estimated_minutes' => TimeTrackingHelper::getTaskEstimation($taskId)
        ];
    }

    /**
     * Update the task estimate only while time tracking is enabled.
     */
    public function updateTimeEstimation(Request $request, $boardId, $taskId)
    {
        if (!TimeTrackingHelper::isTimeTrackingEnabled()) {
            return $this->sendError([
                'message' => __('Time tracking is disabled', 'fluent-boards-pro'),
            ], 403);
        }

        $task = (new TaskService())->findTaskOnBoard($taskId, $boardId);
        $task->updateMeta('_estimated_minutes', (int)$request->get('estimated_minutes'));

        return [
            'message' => __('Estimated time has been updated', 'fluent-boards-pro')
        ];
    }

    /**
     * Delete an accessible work log only while time tracking is enabled.
     */
    public function deleteTrack($boardId, $taskId, $trackId)
    {
        if (!TimeTrackingHelper::isTimeTrackingEnabled()) {
            return $this->sendError([
                'message' => __('Time tracking is disabled', 'fluent-boards-pro'),
            ], 403);
        }

        (new TaskService())->findTaskOnBoard($taskId, $boardId);

        $activeTrack = TimeTrack::where('board_id', $boardId)
            ->where('task_id', $taskId)
            ->find($trackId);

        if (!$activeTrack) {
            return $this->sendError([
                'success' => false,
                'message' => __('Time track not found', 'fluent-boards-pro'),
            ], 422);
        }

        // Members may delete only their own records; board managers may delete any board record.
        if ((int)$activeTrack->user_id !== get_current_user_id() && !PermissionManager::isBoardManager($boardId)) {
            return $this->sendError([
                'success' => false,
                'message' => __('You do not have permission to delete this time track', 'fluent-boards-pro'),
            ], 403);
        }

        try {
            $activeTrack->delete();
            return $this->sendSuccess([
                'success' => true,
                'message' => __('Selected time track has been deleted', 'fluent-boards-pro'),
            ]);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), 400);
        }
    }

    /**
     * Create a manual work log only while time tracking is enabled.
     */
    public function manualCommitTrack(Request $request, $boardId, $taskId)
    {
        if (!TimeTrackingHelper::isTimeTrackingEnabled()) {
            return $this->sendError([
                'message' => __('Time tracking is disabled', 'fluent-boards-pro'),
            ], 403);
        }

        $task = (new TaskService())->findTaskOnBoard($taskId, $boardId);

        $this->validate($request->all(), [
            'billable_minutes' => 'required|numeric|min:1',
            'message'          => 'string',
            'started_at'       => 'string',
            'completed_at'     => 'nullable|string'
        ]);

        $totalMinutes = (int)$request->get('billable_minutes');
        $message = $request->getSafe('message', 'wp_kses_post');
        $taskDate = $request->getSafe('completed_at', 'sanitize_text_field', NULL);

        try {
            $finalFormattedDate = Helper::parseDate($taskDate) ?? current_time('mysql');
        } catch (InvalidArgumentException $e) {
            return $this->sendError($e->getMessage(), 422);
        }

        if ($totalMinutes <= 0) {
            return $this->sendError([
                'message' => __('Please provide valid hours and minutes', 'fluent-boards-pro')
            ]);
        }

        $data = [
            'status'           => 'commited',
            'completed_at'     => $finalFormattedDate,
            'billable_minutes' => $totalMinutes,
            'working_minutes'  => $totalMinutes,
            'message'          => $message,
            'user_id'          => get_current_user_id(),
            'board_id'         => $boardId,
            'is_manual'        => 1,
            'task_id'          => $taskId
        ];

        $track = TimeTrack::create($data);

        $track->load('user');

        return [
            'track'   => $track,
            'message' => __('You have successfully submitted your working time', 'fluent-boards-pro')
        ];
    }

    /**
     * Update an owned or managed work log only while time tracking is enabled.
     */
    public function updateCommitTrack(Request $request, $boardId, $taskId, $trackId)
    {
        if (!TimeTrackingHelper::isTimeTrackingEnabled()) {
            return $this->sendError([
                'message' => __('Time tracking is disabled', 'fluent-boards-pro'),
            ], 403);
        }

        (new TaskService())->findTaskOnBoard($taskId, $boardId);

        $this->validate($request->all(), [
            'billable_minutes' => 'required|numeric|min:1',
            'message'          => 'string',
            'started_at'       => 'string',
            'completed_at'     => 'nullable|string'
        ]);

        $totalMinutes = (int)$request->get('billable_minutes');
        $message = $request->getSafe('message', 'wp_kses_post');
        $taskDate = $request->getSafe('completed_at', 'sanitize_text_field', NULL);


        try {
            $track = TimeTrack::where('board_id', $boardId)
                ->where('task_id', $taskId)
                ->findOrFail($trackId);

            if ((int)$track->user_id !== get_current_user_id() && !PermissionManager::isBoardManager($boardId)) {
                return $this->sendError([
                    'success' => false,
                    'message' => __('You do not have permission to edit this time track', 'fluent-boards-pro'),
                ], 403);
            }

            $completedAt = Helper::parseDate($taskDate);
            if ($completedAt !== null) {
                $track->completed_at = $completedAt;
            }
            $track->message = $message;
            $track->billable_minutes = $totalMinutes;
            $track->working_minutes  = $totalMinutes;
            $track->save();

            return $this->sendSuccess([
                'success' => true,
                'message' => __('Selected Time-track has been updated', 'fluent-boards-pro'),
            ]);
        } catch (\Exception $e) {
            return $this->sendError($e->getMessage(), $e instanceof InvalidArgumentException ? 422 : 400);
        }
    }
}
