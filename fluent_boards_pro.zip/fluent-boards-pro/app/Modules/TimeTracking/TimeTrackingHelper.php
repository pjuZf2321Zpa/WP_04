<?php

namespace FluentBoardsPro\App\Modules\TimeTracking;

use FluentBoards\App\Models\TaskMeta;
use FluentBoardsPro\App\Services\ProHelper;

class TimeTrackingHelper
{

    public static function isTimeTrackingEnabled()
    {
        static $enabled = null;

        if ($enabled !== null) {
            return $enabled;
        }

        $settings = ProHelper::getModuleSettings();

        $enabled = isset($settings['timeTracking']['enabled']) && $settings['timeTracking']['enabled'] === 'yes';

        return $enabled;
    }

    public static function canUseTimeTracking()
    {
        return self::isTimeTrackingEnabled() && self::timeTrackingTableExists();
    }

    public static function timeTrackingTableExists()
    {
        static $exists = null;

        if ($exists !== null) {
            return $exists;
        }

        global $wpdb;

        $table = $wpdb->prefix . 'fbs_time_tracks';
        $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) === $table;

        return $exists;
    }

    public static function getTaskEstimation($taskId)
    {
        $exist = TaskMeta::where('task_id', $taskId)->where('key', '_estimated_minutes')->first();

        if ($exist) {
            return (int)$exist->value;
        }

        return 0;
    }

}
