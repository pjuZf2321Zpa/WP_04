<?php

namespace FluentBoardsPro\App\Modules\CloudStorage;

use FluentBoardsPro\App\Modules\CloudStorage\S3\S3;

abstract class RemoteDriver
{
    protected $bucket;
    protected $accessKey;
    protected $secretKey;
    protected $endpoint;
    protected $region;

    public function __construct($accessKey, $secretKey, $endpoint, $bucket, $region = 'us-east-1')
    {
        $this->accessKey = $accessKey;
        $this->secretKey = $secretKey;
        $this->endpoint = $endpoint;
        $this->bucket = $bucket;
        $this->region = $region;
    }

    public function getDriver()
    {
        return new S3($this->accessKey, $this->secretKey, true, $this->endpoint, $this->region);
    }

    abstract public function putObject($mediaPath);

    abstract public function getPublicUrl($objectName);

    abstract public function getRemotePath($objectName);

    /**
     * Delete an object by the remote path stored on the attachment row.
     *
     * Only a path this driver itself produced (same scheme, endpoint and bucket)
     * is accepted, so an empty or foreign path can never turn into a request
     * against the bucket root or another bucket.
     *
     * @param string $path Value of the attachment's file_path.
     * @return true|\WP_Error
     */
    public function deleteObject($path)
    {
        $objectName = $this->getObjectNameFromRemotePath($path);
        if ($objectName === null) {
            return new \WP_Error('invalid_path', 'The path does not belong to this storage bucket', []);
        }

        $driver = $this->getDriver();

        return $this->deleteResult($driver::deleteObject($this->bucket, $objectName));
    }

    /**
     * Turn the S3 library's response into true or a WP_Error.
     *
     * S3::deleteObject() always returns a response object, failed or not, with
     * the failure in `error` (false on success). Deleting a key that does not
     * exist is a 204, so it counts as success.
     *
     * @param mixed $response
     * @return true|\WP_Error
     */
    public function deleteResult($response)
    {
        if (is_object($response) && isset($response->error) && $response->error === false) {
            return true;
        }

        $error = (is_object($response) && !empty($response->error) && is_array($response->error)) ? $response->error : [];
        $message = !empty($error['message']) ? $error['message'] : 'Unknown error when deleting the remote file';

        return new \WP_Error('remote_delete_failed', $message, $error);
    }

    /**
     * Turn a stored remote path back into its object key (sub-folder included).
     *
     * @param string $path
     * @return string|null Null when the path was not produced by this driver.
     */
    public function getObjectNameFromRemotePath($path)
    {
        $prefix = $this->getRemotePath('');
        if (!is_string($path) || $prefix === '' || strpos($path, $prefix) !== 0) {
            return null;
        }

        $objectName = substr($path, strlen($prefix));
        if ($objectName === '' || $objectName === false || strpos($objectName, '..') !== false) {
            return null;
        }

        return $objectName;
    }

    /**
     * Download an object with signed credentials, so private buckets work.
     *
     * @param string $path     Value of the attachment's file_path.
     * @param string $saveTo   Local file to write into.
     * @param int    $maxBytes Refuse objects larger than this.
     * @return int|\WP_Error Bytes written.
     */
    public function downloadObject($path, $saveTo, $maxBytes)
    {
        $objectName = $this->getObjectNameFromRemotePath($path);
        if ($objectName === null) {
            return new \WP_Error('invalid_path', 'The path does not belong to this storage bucket', []);
        }

        $driver = $this->getDriver();

        try {
            $info = $driver::getObjectInfo($this->bucket, $objectName);
            if (!is_array($info)) {
                return new \WP_Error('remote_not_found', 'Remote file could not be found', []);
            }
            if (isset($info['size']) && (int) $info['size'] > $maxBytes) {
                return new \WP_Error('remote_too_large', 'Remote file exceeds the download size limit', []);
            }
            $response = $driver::getObject($this->bucket, $objectName, $saveTo);
        } catch (\Exception $exception) {
            return new \WP_Error('remote_fetch_failed', $exception->getMessage(), []);
        }

        clearstatcache(true, $saveTo);
        if (!$response || !is_file($saveTo)) {
            return new \WP_Error('remote_fetch_failed', 'Failed to fetch remote file', []);
        }

        return filesize($saveTo);
    }

    abstract public function testConnection();
}
