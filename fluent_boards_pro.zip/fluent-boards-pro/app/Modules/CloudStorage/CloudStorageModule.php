<?php

namespace FluentBoardsPro\App\Modules\CloudStorage;


use FluentBoardsPro\App\Modules\CloudStorage\R2\CloudFlareDriver;
use FluentBoardsPro\App\Modules\CloudStorage\S3\S3Driver;
use FluentBoardsPro\App\Modules\CloudStorage\DigitalOceanStorageS3\DigitalOceanDriver;
use FluentBoardsPro\App\Modules\CloudStorage\Blackblaze\BlackblazeB2Driver;



class CloudStorageModule
{
    /** Action Scheduler hook that retries a failed remote delete. */
    const RETRY_HOOK = 'fluent_boards/retry_remote_attachment_delete';

    /** Attempts in total, an hour apart, before a failed delete is given up. */
    const MAX_DELETE_ATTEMPTS = 3;

    public function register($app)
    {
        add_filter('fluent_boards/upload_media_data', function ($mediaData) {
            $remoteDriver = $this->getDriver();

            if (!$remoteDriver) {
                return $mediaData;
            }

            $mediaPath = $mediaData['file_path'];

            try {
                $response = $remoteDriver->putObject($mediaPath);
            } catch (\Exception $exception) {
                return $mediaData;
            }

            if (!$response || is_wp_error($response)) {
                return $mediaData;
            }

            $mediaData['file_path'] = $response['remote_path'];
            $mediaData['full_url'] = $response['public_url'];
            $mediaData['driver'] = $this->getDriverName($remoteDriver);

            // unlink the old file now
            @unlink($mediaPath);

            return $mediaData;
        });

    }

    /**
     * Register the remote-file delete listeners once, whether or not the cloud
     * storage feature is currently enabled.
     *
     * @return void
     */
    public static function registerDeleteListeners()
    {
        static $registered = false;
        if ($registered) {
            return;
        }
        $registered = true;

        $module = new self();
        // Fired by the core plugin once no attachment row references the object any more.
        add_action('fluent_boards/delete_remote_attachment_file', [$module, 'deleteRemoteMedia']);
        // Legacy hook name; nothing in core fires it, kept so third-party callers still work.
        add_action('fluent_boards/delete_remote_media_s3', [$module, 'deleteRemoteMedia']);
        add_action(self::RETRY_HOOK, [$module, 'retryRemoteMediaDelete'], 10, 3);
    }

    /**
     * Delete an attachment's object from the configured bucket.
     *
     * Skipped when the attachment was stored by a different driver than the one
     * configured now: those credentials cannot reach the other provider's bucket.
     * A failed request is reported on `fluent_boards/remote_attachment_delete_failed`
     * and retried by Action Scheduler, an hour apart, up to MAX_DELETE_ATTEMPTS.
     *
     * @param object $media   Attachment (or snapshot) with `driver` and `file_path`.
     * @param int    $attempt 1 for the first try.
     * @return true|\WP_Error|false False when there was nothing this site could delete.
     */
    public function deleteRemoteMedia($media, $attempt = 1)
    {
        $path = '';
        if (is_object($media)) {
            $path = !empty($media->file_path) ? $media->file_path : ($media->media_path ?? '');
        }

        if (!is_string($path) || $path === '') {
            return false;
        }

        $remoteDriver = $this->getDriver();
        if (!$remoteDriver) {
            return false;
        }

        if (!empty($media->driver) && $media->driver !== $this->getDriverName($remoteDriver)) {
            return false;
        }

        try {
            $result = $remoteDriver->deleteObject($path);
        } catch (\Exception $exception) {
            $result = new \WP_Error('remote_delete_failed', $exception->getMessage(), []);
        }

        if (!is_wp_error($result)) {
            return true;
        }

        do_action('fluent_boards/remote_attachment_delete_failed', $media, $result, (int) $attempt);
        error_log(sprintf(
            'FluentBoards Pro: remote attachment delete failed (attempt %d): %s',
            (int) $attempt,
            sanitize_text_field($result->get_error_message())
        ));

        // A path from another bucket will never succeed; a network or permission error might.
        if ($result->get_error_code() !== 'invalid_path'
            && (int) $attempt < self::MAX_DELETE_ATTEMPTS
            && function_exists('as_schedule_single_action')) {
            as_schedule_single_action(time() + HOUR_IN_SECONDS, self::RETRY_HOOK, [$path, (string) ($media->driver ?? ''), (int) $attempt + 1], 'fluent-boards');
        }

        return $result;
    }

    /**
     * Action Scheduler callback for a delete that failed earlier.
     *
     * @param string $path
     * @param string $driver
     * @param int    $attempt
     * @return true|\WP_Error|false
     */
    public function retryRemoteMediaDelete($path, $driver, $attempt)
    {
        return $this->deleteRemoteMedia((object) ['file_path' => $path, 'driver' => $driver], max(2, (int) $attempt));
    }

    public function getDriver()
    {
        return $this->getConnectionDriver();
    }

    public function getDriverName($driver)
    {
        if ($driver instanceof CloudFlareDriver) {
            return 'cloudflare_r2';
        }
        if ($driver instanceof DigitalOceanDriver) {
            return 'digital_ocean';
        }

        if ($driver instanceof S3Driver) {
            return 'amazon_s3';
        }

        if ($driver instanceof BlackblazeB2Driver) {
            return 'blackblaze_b2';
        }

        return 'local';
    }

    public function getConnectionDriver($config = null)
    {
        if (!$config) {
            $config = StorageHelper::getConfig();
        }

        if ($config['driver'] == 'local') {
            return null;
        }

        if ($config['driver'] === 'cloudflare_r2') {
            return $this->cloudflareDriver($config);
        }

        if ($config['driver'] === 'amazon_s3') {
            return $this->s3Driver($config);
        }
        if ($config['driver'] === 'digital_ocean') {
            return $this->digitalOceanDriver($config);
        }

        if ($config['driver'] === 'blackblaze_b2') {
            return $this->blackblazeB2Driver($config);
        }


        return null;
    }

    private function cloudflareDriver($config = null)
    {
        if (!$config) {
            $config = StorageHelper::getConfig();
        }

        if (
            empty($config['access_key']) ||
            empty($config['secret_key']) ||
            !isset($config['bucket']) ||
            !isset($config['public_url']) ||
            !isset($config['account_id']) ||
            $config['driver'] != 'cloudflare_r2'
        ) {
            return null;
        }

        $endPoint = $config['account_id'] . '.r2.cloudflarestorage.com';

        $driver = (new CloudFlareDriver($config['access_key'], $config['secret_key'], $endPoint, $config['bucket']))
            ->setPublicUrl($config['public_url']);

        if (!empty($config['sub_folder'])) {
            $driver = $driver->setSubFolder($config['sub_folder']);
        }

        return $driver;
    }

    private function s3Driver($config = null)
    {
        if (!$config) {
            $config = StorageHelper::getConfig();
        }

        if (
            empty($config['region']) ||
            empty($config['access_key']) ||
            empty($config['secret_key']) ||
            !isset($config['bucket']) ||
            $config['driver'] != 'amazon_s3'
        ) {
            return null;
        }

        $endPoint = defined('FLUENT_BOARDS_CLOUD_STORAGE_ENDPOINT') ? FLUENT_BOARDS_CLOUD_STORAGE_ENDPOINT : 's3.amazonaws.com';

        $driver = new S3Driver($config['access_key'], $config['secret_key'], $endPoint, $config['bucket'], $config['region']);

        if (!empty($config['sub_folder'])) {
            $driver = $driver->setSubFolder($config['sub_folder']);
        }

        return $driver;
    }


    private function digitalOceanDriver($config = null)
    {
        if (!$config) {
            $config = StorageHelper::getConfig();
        }

        if (
            empty($config['region']) ||
            empty($config['access_key']) ||
            empty($config['secret_key']) ||
            !isset($config['bucket']) ||
            $config['driver'] != 'digital_ocean'
        ) {
            return null;
        }

        // Construct the endpoint based on the region
        $endPoint = $config['region'] . '.digitaloceanspaces.com';

        // Initialize digital ocean with configuration parameters
        $driver = new DigitalOceanDriver($config['access_key'], $config['secret_key'], $endPoint, $config['bucket'], $config['region']);

        if (!empty($config['sub_folder'])) {
            $driver = $driver->setSubFolder($config['sub_folder']);
        }

        return $driver;
    }

    public function blackblazeB2Driver($config = null)
    {
        if (!$config) {
            $config = StorageHelper::getConfig();
        }
        /*
         * https://www.backblaze.com/apidocs/introduction-to-the-s3-compatible-api
         * access_key = <your-application-key-id>
         * Secret Key	<your-application-key>
         */

        if (
            empty($config['access_key']) ||
            empty($config['secret_key']) ||
            !isset($config['bucket']) ||
            !isset($config['region']) ||
            $config['driver'] != 'blackblaze_b2'
        ) {
            return null;
        }

        // Construct the endpoint based on the region

        $endPoint = 's3.' . $config['region'] . '.backblazeb2.com';

        $driver = (new BlackblazeB2Driver($config['access_key'], $config['secret_key'], $endPoint, $config['bucket'], $config['region']));

        if (!empty($config['sub_folder'])) {
            $driver = $driver->setSubFolder($config['sub_folder']);
        }

        return $driver;
    }
}
