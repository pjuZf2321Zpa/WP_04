<?php

namespace FluentBoardsPro\App\Modules\MCP;

use FluentBoards\App\Modules\MCP\Helpers\MCPHelper;
use FluentBoardsPro\App\Modules\MCP\Tools\ProTaskTools;
use FluentBoardsPro\App\Modules\MCP\Tools\TemplateTools;

/**
 * Fluent Boards Pro MCP ability definitions.
 */
class ProAbilitiesRegistrar
{
    /** Define the Pro abilities exposed by the shared Fluent Boards MCP server. */
    public static function getDefinitions()
    {
        return [
            'fluent-boards/make-board-template' => [
                'label'       => __('Make Board Template', 'fluent-boards-pro'),
                'description' => __('Convert an active board in place into a reusable template. Requires board-manager permission. To build a new template, first create a board and populate its stages, labels and tasks using the existing tools, then call this tool. Does not duplicate the board. Repeated calls keep template status enabled.', 'fluent-boards-pro'),
                'input_schema' => [
                    'type'       => 'object',
                    'properties' => [
                        'board_id'    => ['type' => 'integer', 'minimum' => 1],
                        'description' => ['type' => 'string', 'description' => __('Optional template description. Omit or pass an empty string to preserve the existing value.', 'fluent-boards-pro')],
                        'category'    => ['type' => 'string', 'description' => __('Optional template category. Omit or pass an empty string to preserve the existing value.', 'fluent-boards-pro')],
                    ],
                    'required' => ['board_id'],
                ],
                'execute_callback'    => [TemplateTools::class, 'makeBoardTemplate'],
                'permission_callback' => [TemplateTools::class, 'canMakeBoardTemplate'],
                'annotations' => ['readonly' => false, 'destructive' => false, 'idempotent' => true],
            ],

            'fluent-boards/make-task-template' => [
                'label'       => __('Make Task Template', 'fluent-boards-pro'),
                'description' => __('Save an active top-level task in place as a reusable template. Requires write access to its board. To build a new template, first create a task and populate its content and subtasks using the existing tools, then call this tool. Does not duplicate the task. Repeated calls keep template status enabled.', 'fluent-boards-pro'),
                'input_schema' => [
                    'type'       => 'object',
                    'properties' => [
                        'board_id' => ['type' => 'integer', 'minimum' => 1],
                        'task_id'  => ['type' => 'integer', 'minimum' => 1],
                    ],
                    'required' => ['board_id', 'task_id'],
                ],
                'execute_callback'    => [TemplateTools::class, 'makeTaskTemplate'],
                'permission_callback' => [TemplateTools::class, 'canMakeTaskTemplate'],
                'annotations' => ['readonly' => false, 'destructive' => false, 'idempotent' => true],
            ],

            'fluent-boards/get-subtasks' => [
                'label'       => __('Get Subtasks', 'fluent-boards-pro'),
                'description' => __('List subtask groups and subtasks for a task. Returns assignees inline.', 'fluent-boards-pro'),
                'input_schema' => [
                    'type'       => 'object',
                    'properties' => [
                        'board_id' => ['type' => 'integer'],
                        'task_id'  => ['type' => 'integer'],
                    ],
                    'required' => ['board_id', 'task_id'],
                ],
                'execute_callback'    => [ProTaskTools::class, 'getSubtasks'],
                'permission_callback' => function ($params = []) {
                    return !empty($params['board_id']) && MCPHelper::canReadBoard($params['board_id']);
                },
                'annotations' => ['readonly' => true],
            ],

            'fluent-boards/create-subtask-group' => [
                'label'       => __('Create Subtask Group', 'fluent-boards-pro'),
                'description' => __('Create a subtask group for a task.', 'fluent-boards-pro'),
                'input_schema' => [
                    'type'       => 'object',
                    'properties' => [
                        'board_id' => ['type' => 'integer'],
                        'task_id'  => ['type' => 'integer'],
                        'title'    => ['type' => 'string'],
                    ],
                    'required' => ['board_id', 'task_id', 'title'],
                ],
                'execute_callback'    => [ProTaskTools::class, 'createSubtaskGroup'],
                'permission_callback' => function ($params = []) {
                    return !empty($params['board_id']) && MCPHelper::canWriteBoard($params['board_id']);
                },
            ],

            'fluent-boards/create-subtask' => [
                'label'       => __('Create Subtask', 'fluent-boards-pro'),
                'description' => __('Create a subtask inside an existing subtask group.', 'fluent-boards-pro'),
                'input_schema' => [
                    'type'       => 'object',
                    'properties' => [
                        'board_id'    => ['type' => 'integer'],
                        'task_id'     => ['type' => 'integer', 'description' => 'Parent task id.'],
                        'group_id'    => ['type' => 'integer'],
                        'title'       => ['type' => 'string'],
                        'add_to_top'  => ['type' => 'boolean', 'default' => false],
                    ],
                    'required' => ['board_id', 'task_id', 'group_id', 'title'],
                ],
                'execute_callback'    => [ProTaskTools::class, 'createSubtask'],
                'permission_callback' => function ($params = []) {
                    return !empty($params['board_id']) && MCPHelper::canWriteBoard($params['board_id']);
                },
            ],

            'fluent-boards/assign-subtask' => [
                'label'       => __('Assign Subtask', 'fluent-boards-pro'),
                'description' => __('Add, remove, or sync assignees on a subtask. Newly added user ids must identify existing WordPress users who are board members or global administrators. Assignees are also task watchers.', 'fluent-boards-pro'),
                'input_schema' => [
                    'type'       => 'object',
                    'properties' => [
                        'board_id'     => ['type' => 'integer'],
                        'subtask_id'   => ['type' => 'integer'],
                        'user_id'      => ['type' => 'integer', 'description' => 'Single user id. Ignored when user_ids is provided.'],
                        'user_ids'     => ['type' => 'array', 'items' => ['type' => 'integer']],
                        'mode'         => ['type' => 'string', 'enum' => ['add', 'remove', 'sync'], 'default' => 'add'],
                    ],
                    'required' => ['board_id', 'subtask_id'],
                ],
                'execute_callback'    => [ProTaskTools::class, 'assignSubtask'],
                'permission_callback' => function ($params = []) {
                    return !empty($params['board_id']) && MCPHelper::canWriteBoard($params['board_id']);
                },
            ],

            'fluent-boards/update-subtask' => [
                'label'       => __('Update Subtask', 'fluent-boards-pro'),
                'description' => __('Update subtask fields and optionally move it to another subtask group or position.', 'fluent-boards-pro'),
                'input_schema' => [
                    'type'       => 'object',
                    'properties' => [
                        'board_id'    => ['type' => 'integer'],
                        'subtask_id'  => ['type' => 'integer'],
                        'title'       => ['type' => 'string'],
                        'status'      => ['type' => 'string', 'enum' => ['open', 'closed']],
                        'priority'    => ['type' => 'string', 'enum' => ['low', 'medium', 'high']],
                        'due_at'      => ['type' => 'string', 'description' => 'Omit to leave unchanged. Pass empty string to clear.'],
                        'started_at'  => ['type' => 'string', 'description' => 'Omit to leave unchanged. Pass empty string to clear.'],
                        'group_id'    => ['type' => 'integer'],
                        'position'    => ['type' => 'integer', 'description' => '1-based position inside the target/current group.'],
                    ],
                    'required' => ['board_id', 'subtask_id'],
                ],
                'execute_callback'    => [ProTaskTools::class, 'updateSubtask'],
                'permission_callback' => function ($params = []) {
                    return !empty($params['board_id']) && MCPHelper::canWriteBoard($params['board_id']);
                },
            ],

            'fluent-boards/add-task-assignee' => [
                'label'       => __('Add Task Assignee', 'fluent-boards-pro'),
                'description' => __('Add one or more assignees to a task without removing existing assignees. User ids must identify existing WordPress users who are board members or global administrators.', 'fluent-boards-pro'),
                'input_schema' => [
                    'type'       => 'object',
                    'properties' => [
                        'board_id' => ['type' => 'integer'],
                        'task_id'  => ['type' => 'integer'],
                        'user_id'  => ['type' => 'integer', 'description' => 'Single user id. Ignored when user_ids is provided.'],
                        'user_ids' => ['type' => 'array', 'items' => ['type' => 'integer']],
                    ],
                    'required' => ['board_id', 'task_id'],
                ],
                'execute_callback'    => [ProTaskTools::class, 'addTaskAssignee'],
                'permission_callback' => function ($params = []) {
                    return !empty($params['board_id']) && MCPHelper::canWriteBoard($params['board_id']);
                },
            ],

            'fluent-boards/remove-task-assignee' => [
                'label'       => __('Remove Task Assignee', 'fluent-boards-pro'),
                'description' => __('Remove one or more assignees from a task.', 'fluent-boards-pro'),
                'input_schema' => [
                    'type'       => 'object',
                    'properties' => [
                        'board_id' => ['type' => 'integer'],
                        'task_id'  => ['type' => 'integer'],
                        'user_id'  => ['type' => 'integer', 'description' => 'Single user id. Ignored when user_ids is provided.'],
                        'user_ids' => ['type' => 'array', 'items' => ['type' => 'integer']],
                    ],
                    'required' => ['board_id', 'task_id'],
                ],
                'execute_callback'    => [ProTaskTools::class, 'removeTaskAssignee'],
                'permission_callback' => function ($params = []) {
                    return !empty($params['board_id']) && MCPHelper::canWriteBoard($params['board_id']);
                },
            ],

            'fluent-boards/delete-subtask' => [
                'label'       => __('Delete Subtask', 'fluent-boards-pro'),
                'description' => __('Permanently delete a subtask. Detaches its watchers and group link, and re-counts the parent task. This cannot be undone.', 'fluent-boards-pro'),
                'input_schema' => [
                    'type'       => 'object',
                    'properties' => [
                        'board_id'   => ['type' => 'integer'],
                        'subtask_id' => ['type' => 'integer'],
                    ],
                    'required' => ['board_id', 'subtask_id'],
                ],
                'execute_callback'    => [ProTaskTools::class, 'deleteSubtask'],
                'permission_callback' => function ($params = []) {
                    return !empty($params['board_id']) && MCPHelper::canWriteBoard($params['board_id']);
                },
            ],
        ];
    }

    public static function register()
    {
        foreach (self::getDefinitions() as $name => $definition) {
            $args = [
                'label'               => $definition['label'],
                'description'         => $definition['description'],
                'category'            => 'fluent-boards',
                'execute_callback'    => self::wrapExecuteCallback($name, $definition['execute_callback']),
                'permission_callback' => $definition['permission_callback'],
                'meta'                => [
                    'show_in_rest' => true,
                    'mcp'          => [
                        'public' => true,
                    ],
                ],
            ];

            if (!empty($definition['input_schema'])) {
                $args['input_schema'] = $definition['input_schema'];
            }

            if (!empty($definition['annotations'])) {
                $args['meta']['annotations'] = $definition['annotations'];
            }

            wp_register_ability($name, $args);
        }
    }

    private static function wrapExecuteCallback($toolName, $callback)
    {
        return function ($params = []) use ($toolName, $callback) {
            try {
                return call_user_func($callback, is_array($params) ? $params : []);
            } catch (\Throwable $exception) {
                return new \WP_Error(
                    'fluent_boards_pro_mcp_error',
                    $exception->getMessage(),
                    [
                        'tool' => $toolName,
                    ]
                );
            }
        };
    }
}
