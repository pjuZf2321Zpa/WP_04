<?php

namespace FluentBoardsPro\App\Modules\MCP\Tools;

use FluentBoards\App\Models\Relation;
use FluentBoards\App\Models\Task;
use FluentBoards\App\Models\TaskMeta;
use FluentBoards\App\Modules\MCP\Helpers\MCPHelper;
use FluentBoards\App\Services\Constant;
use FluentBoards\App\Services\PermissionManager;
use FluentBoards\App\Services\TaskService;
use FluentBoardsPro\App\Services\SubtaskService;

/**
 * Pro project-management tools for Fluent Boards MCP.
 */
class ProTaskTools
{
    public static function getSubtasks($params = [])
    {
        $parentTask = self::resolveTaskOnBoard($params['task_id'] ?? 0, $params['board_id'] ?? 0);
        if (is_wp_error($parentTask)) {
            return $parentTask;
        }

        $groups = self::getSubtaskGroups($parentTask->id);
        $formattedGroups = [];

        foreach ($groups as $group) {
            $formattedGroups[(string) $group->id] = self::formatSubtaskGroup($group);
        }

        $subtasks = Task::where('parent_id', $parentTask->id)
            ->with(['assignees'])
            ->whereNull('archived_at')
            ->orderBy('position', 'asc')
            ->get();

        foreach ($subtasks as $subtask) {
            $groupId = (string) self::getSubtaskGroupId($subtask->id);
            if (!$groupId || !isset($formattedGroups[$groupId])) {
                $groupId = 'uncategorized';
                if (!isset($formattedGroups[$groupId])) {
                    $formattedGroups[$groupId] = [
                        'id'       => $groupId,
                        'task_id'  => (int) $parentTask->id,
                        'title'    => __('Uncategorized', 'fluent-boards-pro'),
                        'subtasks' => [],
                    ];
                }
            }

            $formattedGroups[$groupId]['subtasks'][] = self::formatSubtask($subtask, $groupId);
        }

        return [
            'task_id'        => (int) $parentTask->id,
            'subtask_groups' => array_values($formattedGroups),
        ];
    }

    public static function createSubtaskGroup($params = [])
    {
        $parentTask = self::resolveTaskOnBoard($params['task_id'] ?? 0, $params['board_id'] ?? 0);
        if (is_wp_error($parentTask)) {
            return $parentTask;
        }

        if ($parentTask->parent_id) {
            return MCPHelper::error('invalid_param', __('Subtasks cannot own subtask groups', 'fluent-boards-pro'));
        }

        $title = isset($params['title']) ? sanitize_text_field($params['title']) : '';
        if ($title === '') {
            return MCPHelper::error('invalid_param', __('Subtask group title is required', 'fluent-boards-pro'));
        }

        $group = (new SubtaskService())->createSubtaskGroup($parentTask->id, [
            'title' => $title,
        ]);

        return [
            'subtask_group' => self::formatSubtaskGroup($group),
            'message'       => __('New Subtask group has been added', 'fluent-boards-pro'),
        ];
    }

    public static function createSubtask($params = [])
    {
        $parentTask = self::resolveTaskOnBoard($params['task_id'] ?? 0, $params['board_id'] ?? 0);
        if (is_wp_error($parentTask)) {
            return $parentTask;
        }

        if ($parentTask->parent_id) {
            return MCPHelper::error('invalid_param', __('Create subtasks from a parent task, not another subtask', 'fluent-boards-pro'));
        }

        $group = self::resolveSubtaskGroup($params['group_id'] ?? 0, $parentTask->id);
        if (is_wp_error($group)) {
            return $group;
        }

        $title = isset($params['title']) ? sanitize_text_field($params['title']) : '';
        if ($title === '') {
            return MCPHelper::error('invalid_param', __('Subtask title is required', 'fluent-boards-pro'));
        }

        $subtask = (new SubtaskService())->createSubtask($parentTask->id, [
            'title'      => $title,
            'group_id'   => (int) $group->id,
            'add_to_top' => !empty($params['add_to_top']),
        ]);
        $subtask->load('assignees');

        return [
            'subtask' => self::formatSubtask($subtask, $group->id),
            'message' => __('Subtask has been added', 'fluent-boards-pro'),
        ];
    }

    public static function assignSubtask($params = [])
    {
        $subtask = self::resolveTaskOnBoard($params['subtask_id'] ?? 0, $params['board_id'] ?? 0, true);
        if (is_wp_error($subtask)) {
            return $subtask;
        }

        $mode = !empty($params['mode']) ? sanitize_text_field($params['mode']) : 'add';
        if (!in_array($mode, ['add', 'remove', 'sync'], true)) {
            return MCPHelper::error('invalid_param', __('Invalid assignment mode', 'fluent-boards-pro'), [
                'allowed' => ['add', 'remove', 'sync'],
            ]);
        }

        $userIds = self::readUserIds($params);
        if (is_wp_error($userIds)) {
            return $userIds;
        }

        $syncResult = self::syncTaskAssignees($subtask, $userIds, $mode);
        if (is_wp_error($syncResult)) {
            return $syncResult;
        }

        $subtask->load('assignees');

        return [
            'subtask' => self::formatSubtask($subtask),
            'message' => __('Subtask assignees have been updated', 'fluent-boards-pro'),
        ];
    }

    /**
     * Mirrors SubtaskController::deleteSubtasks(): the service detaches watchers, clears the
     * group link and re-counts the parent task.
     */
    public static function deleteSubtask($params = [])
    {
        $subtask = self::resolveTaskOnBoard($params['subtask_id'] ?? 0, $params['board_id'] ?? 0, true);
        if (is_wp_error($subtask)) {
            return $subtask;
        }

        $parentId = (int) $subtask->parent_id;
        $deleted = clone $subtask;

        $options = null;
        do_action('fluent_boards/before_task_deleted', $subtask, $options);

        (new SubtaskService())->deleteSubtask($subtask);

        do_action('fluent_boards/subtask_deleted_activity', $parentId, $deleted->title);

        $parent = Task::find($parentId);

        return [
            'subtask_id'     => (int) $deleted->id,
            'task_id'        => $parentId,
            'board_id'       => (int) $deleted->board_id,
            'title'          => $deleted->title,
            'subtask_count'  => $parent ? (int) ($parent->settings['subtask_count'] ?? 0) : 0,
            'message'        => __('Subtask has been deleted', 'fluent-boards-pro'),
        ];
    }

    public static function updateSubtask($params = [])
    {
        $subtask = self::resolveTaskOnBoard($params['subtask_id'] ?? 0, $params['board_id'] ?? 0, true);
        if (is_wp_error($subtask)) {
            return $subtask;
        }

        $service = new TaskService();
        $fields = [
            'title'      => 'text',
            'status'     => 'text',
            'priority'   => 'nullable_text',
            'due_at'     => 'nullable_text',
            'started_at' => 'nullable_text',
        ];

        foreach ($fields as $field => $type) {
            if (!array_key_exists($field, $params)) {
                continue;
            }

            $validationError = self::validateSubtaskField($field, $params[$field]);
            if (is_wp_error($validationError)) {
                return $validationError;
            }

            $service->updateTaskProperty($field, self::sanitizeUpdateValue($params[$field], $type), $subtask);
        }

        if (array_key_exists('group_id', $params) || array_key_exists('position', $params)) {
            $groupId = !empty($params['group_id']) ? absint($params['group_id']) : self::getSubtaskGroupId($subtask->id);
            $group = self::resolveSubtaskGroup($groupId, $subtask->parent_id);
            if (is_wp_error($group)) {
                return $group;
            }

            if (array_key_exists('position', $params)) {
                (new SubtaskService())->updateSubtaskPosition($subtask->id, [
                    'newPosition'        => max(1, absint($params['position'])),
                    'newSubtasksGroupId' => (int) $group->id,
                ]);
            } else {
                (new SubtaskService())->moveSubtaskToGroup([
                    'subtask_id' => (int) $subtask->id,
                    'group_id'   => (int) $group->id,
                ]);
            }
        }

        $subtask = self::resolveTaskOnBoard($subtask->id, $subtask->board_id, true);
        if (is_wp_error($subtask)) {
            return $subtask;
        }

        $subtask->load('assignees');

        return [
            'subtask' => self::formatSubtask($subtask),
            'message' => __('Subtask has been updated', 'fluent-boards-pro'),
        ];
    }

    public static function addTaskAssignee($params = [])
    {
        return self::manageTaskAssignees($params, 'add', __('Task assignees have been added', 'fluent-boards-pro'));
    }

    public static function removeTaskAssignee($params = [])
    {
        return self::manageTaskAssignees($params, 'remove', __('Task assignees have been removed', 'fluent-boards-pro'));
    }

    private static function manageTaskAssignees($params, $mode, $message)
    {
        $task = self::resolveTaskOnBoard($params['task_id'] ?? 0, $params['board_id'] ?? 0);
        if (is_wp_error($task)) {
            return $task;
        }

        $userIds = self::readUserIds($params);
        if (is_wp_error($userIds)) {
            return $userIds;
        }

        $syncResult = self::syncTaskAssignees($task, $userIds, $mode);
        if (is_wp_error($syncResult)) {
            return $syncResult;
        }

        $task->load(['stage', 'labels', 'assignees']);

        return [
            'task'    => MCPHelper::formatTaskSummary($task),
            'message' => $message,
        ];
    }

    private static function resolveTaskOnBoard($taskId, $boardId, $mustBeSubtask = false)
    {
        $taskId = absint($taskId);
        $boardId = absint($boardId);

        if (!$taskId || !$boardId) {
            return MCPHelper::error('invalid_param', __('Provide board_id and task id', 'fluent-boards-pro'));
        }

        $task = Task::with(['assignees'])
            ->where('id', $taskId)
            ->where('board_id', $boardId)
            ->first();

        if (!$task) {
            return MCPHelper::error('not_found', __('Task not found on this board', 'fluent-boards-pro'), [
                'board_id' => $boardId,
                'task_id'  => $taskId,
            ]);
        }

        if ($mustBeSubtask && !$task->parent_id) {
            return MCPHelper::error('invalid_param', __('Provided task is not a subtask', 'fluent-boards-pro'), [
                'task_id' => $taskId,
            ]);
        }

        return $task;
    }

    private static function getSubtaskGroups($parentTaskId)
    {
        return TaskMeta::where('task_id', absint($parentTaskId))
            ->select('id', 'task_id', 'value')
            ->where('key', Constant::SUBTASK_GROUP_NAME)
            ->get();
    }

    private static function resolveSubtaskGroup($groupId, $parentTaskId)
    {
        $groupId = absint($groupId);
        $parentTaskId = absint($parentTaskId);

        if (!$groupId || !$parentTaskId) {
            return MCPHelper::error('invalid_param', __('Provide a valid subtask group id', 'fluent-boards-pro'));
        }

        $group = TaskMeta::where('id', $groupId)
            ->where('task_id', $parentTaskId)
            ->where('key', Constant::SUBTASK_GROUP_NAME)
            ->first();

        if (!$group) {
            return MCPHelper::error('not_found', __('Subtask group not found for this task', 'fluent-boards-pro'), [
                'task_id'  => $parentTaskId,
                'group_id' => $groupId,
            ]);
        }

        return $group;
    }

    private static function getSubtaskGroupId($subtaskId)
    {
        return TaskMeta::where('task_id', absint($subtaskId))
            ->where('key', Constant::SUBTASK_GROUP_CHILD)
            ->value('value');
    }

    private static function formatSubtaskGroup($group)
    {
        return [
            'id'       => (int) $group->id,
            'task_id'  => (int) $group->task_id,
            'title'    => $group->value,
            'subtasks' => [],
        ];
    }

    private static function formatSubtask($subtask, $groupId = null)
    {
        if ($groupId === null) {
            $groupId = self::getSubtaskGroupId($subtask->id);
        }

        return [
            'id'          => (int) $subtask->id,
            'title'       => $subtask->title,
            'slug'        => $subtask->slug,
            'board_id'    => (int) $subtask->board_id,
            'parent_id'   => $subtask->parent_id ? (int) $subtask->parent_id : null,
            'group_id'    => is_numeric($groupId) ? (int) $groupId : null,
            'status'      => $subtask->status,
            'priority'    => $subtask->priority,
            'position'    => isset($subtask->position) ? (float) $subtask->position : null,
            'due_at'      => MCPHelper::toIso8601($subtask->due_at),
            'started_at'  => MCPHelper::toIso8601($subtask->started_at),
            'created_at'  => MCPHelper::toIso8601($subtask->created_at),
            'updated_at'  => MCPHelper::toIso8601($subtask->updated_at),
            'assignees'   => MCPHelper::formatUserList($subtask->assignees ?? [], (int) $subtask->board_id),
        ];
    }

    private static function readUserIds($params)
    {
        $userIds = !empty($params['user_ids']) ? MCPHelper::sanitizeIdArray($params['user_ids']) : [];
        if (!$userIds && !empty($params['user_id'])) {
            $userIds = [absint($params['user_id'])];
        }

        $userIds = array_values(array_unique(array_filter($userIds)));
        if (!$userIds) {
            return MCPHelper::error('invalid_param', __('Provide user_id or user_ids', 'fluent-boards-pro'));
        }

        foreach ($userIds as $userId) {
            if (!get_user_by('ID', $userId)) {
                return MCPHelper::error('not_found', __('User not found', 'fluent-boards-pro'), [
                    'user_id' => $userId,
                ]);
            }
        }

        return $userIds;
    }

    private static function syncTaskAssignees($task, $userIds, $mode)
    {
        $task->load('assignees');
        $existingIds = array_map('intval', $task->assignees->pluck('ID')->toArray());

        if ($mode === 'sync') {
            $toAdd = array_values(array_diff($userIds, $existingIds));
            $toRemove = array_values(array_diff($existingIds, $userIds));
        } elseif ($mode === 'remove') {
            $toAdd = [];
            $toRemove = array_values(array_intersect($existingIds, $userIds));
        } else {
            $toAdd = array_values(array_diff($userIds, $existingIds));
            $toRemove = [];
        }

        $nonMemberIds = self::findIneligibleAssigneeUserIds($toAdd, $task->board_id);
        if ($nonMemberIds) {
            return MCPHelper::error('forbidden', __('Some users are not members of this board', 'fluent-boards-pro'), [
                'non_board_member_user_ids' => $nonMemberIds,
            ]);
        }

        $service = new TaskService();
        foreach ($toAdd as $userId) {
            $service->updateAssignee($userId, $task);
        }

        foreach ($toRemove as $userId) {
            $service->updateAssignee($userId, $task);
        }

        return $task;
    }

    /**
     * @return array User ids that are neither board members nor global administrators.
     */
    private static function findIneligibleAssigneeUserIds($userIds, $boardId)
    {
        if (!$userIds) {
            return [];
        }

        $memberIds = Relation::where('object_type', Constant::OBJECT_TYPE_BOARD_USER)
            ->where('object_id', (int) $boardId)
            ->whereIn('foreign_id', $userIds)
            ->pluck('foreign_id')
            ->toArray();

        $memberIds = array_map('intval', $memberIds);

        $ineligibleIds = [];
        foreach (array_diff($userIds, $memberIds) as $userId) {
            if (!PermissionManager::isAdmin($userId)) {
                $ineligibleIds[] = $userId;
            }
        }

        return $ineligibleIds;
    }

    private static function validateSubtaskField($field, $value)
    {
        if ($field === 'status' && !in_array($value, ['open', 'closed'], true)) {
            return MCPHelper::error('invalid_param', __('Invalid subtask status', 'fluent-boards-pro'), [
                'allowed' => ['open', 'closed'],
            ]);
        }

        if ($field === 'priority' && $value !== '' && $value !== null && !in_array($value, ['low', 'medium', 'high'], true)) {
            return MCPHelper::error('invalid_param', __('Invalid subtask priority', 'fluent-boards-pro'), [
                'allowed' => ['low', 'medium', 'high'],
            ]);
        }

        return true;
    }

    private static function sanitizeUpdateValue($value, $type)
    {
        if ($type === 'nullable_text') {
            return $value === null ? null : sanitize_text_field((string) $value);
        }

        return sanitize_text_field((string) $value);
    }
}
