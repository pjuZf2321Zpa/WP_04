<?php

namespace FluentBoardsPro\App\Modules\MCP\Tools;

use FluentBoards\App\Models\Board;
use FluentBoards\App\Models\Task;
use FluentBoards\App\Modules\MCP\Helpers\MCPHelper;
use FluentBoards\App\Services\Constant;
use FluentBoards\App\Services\PermissionManager;
use FluentBoards\App\Services\TaskService;
use FluentBoardsPro\App\Services\TemplateService;

/** Save content assembled through MCP as reusable Pro templates. */
class TemplateTools
{
    /** Board conversion requires a manager who can also write to the board. */
    public static function canMakeBoardTemplate($params = [])
    {
        $boardId = absint($params['board_id'] ?? 0);

        return $boardId && MCPHelper::canWriteBoard($boardId) && PermissionManager::isBoardManager($boardId);
    }

    /** Task template conversion follows the board's task-editing permission. */
    public static function canMakeTaskTemplate($params = [])
    {
        $boardId = absint($params['board_id'] ?? 0);

        return $boardId && MCPHelper::canWriteBoard($boardId);
    }

    /** Convert a board in place, preserving content and omitted template metadata. */
    public static function makeBoardTemplate($params = [])
    {
        if (!self::canMakeBoardTemplate($params)) {
            return MCPHelper::error('forbidden', __('You do not have permission to convert this board to a template', 'fluent-boards-pro'));
        }

        $board = self::resolveActiveBoard($params);
        if (is_wp_error($board)) {
            return $board;
        }

        $service = new TemplateService();
        $wasTemplate = $service->isTemplate($board);
        $description = sanitize_textarea_field($params['description'] ?? '');
        $category = sanitize_text_field($params['category'] ?? '');

        if (!$wasTemplate || $description !== '' || $category !== '') {
            $board = $service->makeTemplate($board->id, $description, $category);
        }

        // Retried calls must not emit the conversion event a second time.
        if (!$wasTemplate) {
            do_action('fluent_boards/board_converted_to_template', $board);
        }

        return [
            'board' => [
                'id'          => (int) $board->id,
                'title'       => $board->title,
                'is_template' => true,
            ],
        ];
    }

    /** Mark an active top-level task as a template without duplicating its content. */
    public static function makeTaskTemplate($params = [])
    {
        if (!self::canMakeTaskTemplate($params)) {
            return MCPHelper::error('forbidden', __('You do not have permission to convert this task to a template', 'fluent-boards-pro'));
        }

        $board = self::resolveActiveBoard($params);
        if (is_wp_error($board)) {
            return $board;
        }

        $task = Task::where('board_id', $board->id)->find(absint($params['task_id'] ?? 0));
        if (!$task || $task->archived_at) {
            return MCPHelper::error('not_found', __('Active task not found on this board', 'fluent-boards-pro'));
        }

        if ($task->parent_id) {
            return MCPHelper::error('invalid_param', __('Subtasks cannot be saved as templates', 'fluent-boards-pro'));
        }

        if ($task->getMeta(Constant::IS_TASK_TEMPLATE) !== 'yes') {
            (new TaskService())->updateTaskProperty('is_template', 'yes', $task);

            /** Fires when an MCP task conversion first enables reusable template status. */
            do_action('fluent_boards/task_converted_to_template', $task);
        }

        return [
            'task' => [
                'id'          => (int) $task->id,
                'board_id'    => (int) $task->board_id,
                'title'       => $task->title,
                'is_template' => true,
            ],
        ];
    }

    /** Resolve the destination after permission checks, excluding archived boards. */
    private static function resolveActiveBoard($params)
    {
        $board = Board::find(absint($params['board_id'] ?? 0));
        if (!$board || $board->archived_at) {
            return MCPHelper::error('not_found', __('Active board not found', 'fluent-boards-pro'));
        }

        return $board;
    }
}
