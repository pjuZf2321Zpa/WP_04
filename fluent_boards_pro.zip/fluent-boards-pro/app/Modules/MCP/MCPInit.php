<?php

namespace FluentBoardsPro\App\Modules\MCP;

/**
 * Bootstrap Fluent Boards Pro MCP additions into the core Fluent Boards server.
 */
class MCPInit
{
    public function init()
    {
        (new ToolkitInstaller())->init();

        add_action('fluent_boards/mcp_loaded', [$this, 'registerProAbilities']);
        add_filter('fluent_boards/mcp_ability_names', [$this, 'addAbilityNames']);
    }

    public function registerProAbilities()
    {
        if (!function_exists('wp_register_ability')) {
            return;
        }

        ProAbilitiesRegistrar::register();
    }

    public function addAbilityNames($names)
    {
        $names = is_array($names) ? $names : [];

        return array_merge($names, array_keys(ProAbilitiesRegistrar::getDefinitions()));
    }
}
