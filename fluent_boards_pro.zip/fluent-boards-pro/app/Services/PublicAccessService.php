<?php

namespace FluentBoardsPro\App\Services;

use FluentBoards\App\Models\Board;
use FluentBoards\App\Models\Stage;
use FluentBoards\App\Models\Task;

/**
 * Public board view (Pro): exposure settings, access tokens and which tasks a visitor may see.
 * Response shapes come from core's PublicTaskSerializer, shared with free task share links.
 */
class PublicAccessService
{
    const TOKEN_DELIMITER = '|';

    const SETTINGS_META_KEY = 'public_access_settings';

    const LAYOUTS = ['kanban', 'list', 'table'];

    /** "theme": typography follows the host page's theme; "fluent": Fluent Boards' own typography. */
    const APPEARANCES = ['theme', 'fluent'];

    /**
     * Exposure defaults match the original public view (cards only, no task details),
     * so boards made public before these settings existed expose nothing new.
     */
    const DEFAULT_SETTINGS = [
        'layouts'          => ['kanban', 'list', 'table'],
        'default_layout'   => 'kanban',
        'appearance'       => 'theme',
        'stage_ids'        => [],
        'include_closed'   => true,
        'show_assignees'   => true,
        'show_labels'      => true,
        'show_due_dates'   => true,
        'show_priority'    => true,
        'show_members'     => false,
        'task_details'     => false,
        'task_description' => false,
        'task_subtasks'    => false,
        'task_attachments' => false,
        'task_comments'    => false,
    ];

    public function isEnabled($board)
    {
        return $board && !$board->archived_at && (bool)$board->getMetaByKey('public_access_enabled');
    }

    /**
     * Stored exposure settings merged over the defaults, reduced to known keys and valid values.
     */
    public function getSettings(Board $board)
    {
        return $this->normalizeSettings($board->getMetaByKey(self::SETTINGS_META_KEY));
    }

    public function saveSettings(Board $board, $input)
    {
        $settings = $this->normalizeSettings($input);

        // Stage selections may only reference this board's stages. If none of the selected stages
        // exist any more, keep the selection: [] means "all stages" and would widen exposure.
        if ($settings['stage_ids']) {
            $boardStageIds = Stage::where('board_id', $board->id)->pluck('id')->map(function ($id) { return (int)$id; })->toArray();
            $boardSelection = array_values(array_intersect($settings['stage_ids'], $boardStageIds));
            if ($boardSelection) {
                $settings['stage_ids'] = $boardSelection;
            }
        }

        $board->updateMeta(self::SETTINGS_META_KEY, $settings);

        return $settings;
    }

    private function normalizeSettings($input)
    {
        $input = is_array($input) ? $input : [];
        $settings = [];

        foreach (self::DEFAULT_SETTINGS as $key => $default) {
            $value = array_key_exists($key, $input) ? $input[$key] : $default;

            if (is_bool($default)) {
                $settings[$key] = filter_var($value, FILTER_VALIDATE_BOOLEAN);
            } elseif ($key === 'layouts') {
                $value = array_map('sanitize_key', is_array($value) ? $value : []);
                $settings[$key] = array_values(array_intersect(self::LAYOUTS, $value));
            } elseif ($key === 'stage_ids') {
                $value = array_map('absint', is_array($value) ? $value : []);
                $settings[$key] = array_values(array_unique(array_filter($value)));
            } else {
                $settings[$key] = sanitize_key((string)$value);
            }
        }

        if (!$settings['layouts']) {
            $settings['layouts'] = [self::DEFAULT_SETTINGS['default_layout']];
        }

        if (!in_array($settings['default_layout'], $settings['layouts'], true)) {
            $settings['default_layout'] = $settings['layouts'][0];
        }

        if (!in_array($settings['appearance'], self::APPEARANCES, true)) {
            $settings['appearance'] = self::DEFAULT_SETTINGS['appearance'];
        }

        // Task sub-features are meaningless without the task-details master switch.
        if (!$settings['task_details']) {
            foreach (['task_description', 'task_subtasks', 'task_attachments', 'task_comments'] as $key) {
                $settings[$key] = false;
            }
        }

        return $settings;
    }

    /**
     * Non-archived stage ids a visitor may see. A selection whose stages were all removed
     * exposes nothing rather than silently falling back to every stage.
     */
    public function getExposedStageIds($boardId, array $settings)
    {
        $query = Stage::where('board_id', absint($boardId))->whereNull('archived_at');

        if ($settings['stage_ids']) {
            $query->whereIn('id', $settings['stage_ids']);
        }

        return $query->pluck('id')->map(function ($id) { return (int)$id; })->toArray();
    }

    /**
     * Top-level, non-archived tasks in exposed stages, honoring the completed-task filter.
     */
    public function visibleTasksQuery($boardId, array $settings, array $stageIds)
    {
        $query = Task::query()
            ->where('board_id', absint($boardId))
            ->whereNull('archived_at')
            ->whereNull('parent_id')
            ->whereIn('stage_id', $stageIds ?: [0]);

        if (!$settings['include_closed']) {
            $query->where('status', '!=', 'closed');
        }

        return $query;
    }

    /**
     * Resolve a task a visitor may open, or null. Every id taken from a URL goes through here.
     */
    public function findVisibleTask(Board $board, array $settings, $taskId)
    {
        $taskId = absint($taskId);
        if (!$taskId || !$settings['task_details']) {
            return null;
        }

        $stageIds = $this->getExposedStageIds($board->id, $settings);

        return $this->visibleTasksQuery($board->id, $settings, $stageIds)
            ->where('id', $taskId)
            ->first();
    }

    /**
     * Whether the board's public view currently exposes this task's section (e.g. task_comments).
     */
    public function isTaskFeatureVisible(Task $task, $feature)
    {
        $board = Board::find($task->board_id);
        if (!$this->isEnabled($board)) {
            return false;
        }

        $settings = $this->getSettings($board);
        if (empty($settings[$feature])) {
            return false;
        }

        $visibleTask = $this->findVisibleTask($board, $settings, $task->id);

        return (bool)$visibleTask;
    }

    public function generateAccessToken($boardId)
    {
        $boardId = absint($boardId);
        if (!$boardId) {
            return '';
        }

        $signature = $this->signature($boardId);
        $payload = $boardId . self::TOKEN_DELIMITER . $signature;

        return rtrim(strtr(base64_encode($payload), '+/', '-_'), '=');
    }

    public function validateAccessToken($boardId, $token)
    {
        $boardId = absint($boardId);
        $token = sanitize_text_field($token);

        if (!$boardId || !$token) {
            return false;
        }

        $decoded = base64_decode(strtr($token, '-_', '+/'), true);
        if (!$decoded || strpos($decoded, self::TOKEN_DELIMITER) === false) {
            return false;
        }

        [$tokenBoardId, $tokenSignature] = explode(self::TOKEN_DELIMITER, $decoded, 2);
        $tokenBoardId = absint($tokenBoardId);
        if (!$tokenBoardId || $tokenBoardId !== $boardId) {
            return false;
        }

        return hash_equals($this->signature($boardId), $tokenSignature);
    }

    private function signature($boardId)
    {
        $secret = $this->getSecretForBoard($boardId);

        return hash_hmac('sha256', 'fluent_boards_public_board_' . absint($boardId), $secret);
    }

    private function getSecretForBoard($boardId)
    {
        $board = Board::find($boardId);
        $perBoardSalt = $board ? $board->getMetaByKey('public_token_salt') : '';

        return wp_salt('auth') . $perBoardSalt;
    }

    public function revokeAccessToken($boardId)
    {
        $board = Board::find($boardId);
        if ($board) {
            $board->updateMeta('public_token_salt', wp_generate_password(32, true, true));
        }
    }
}

