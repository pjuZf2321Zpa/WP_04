<?php

namespace FluentBoardsPro\App\Services;

use FluentBoards\App\Models\Board;
use FluentBoards\App\Models\Comment;
use FluentBoards\App\Models\Meta;
use FluentBoards\App\Models\NotificationUser;
use FluentBoards\App\Models\Task;
use FluentBoards\App\Models\Stage;
use FluentBoards\App\Models\TaskMeta;
use FluentBoards\App\Models\User;
use FluentBoards\App\Services\Constant;
use FluentBoards\App\Services\Helper;
use FluentBoards\App\Services\PermissionManager;
use FluentBoards\App\Services\TaskService;
use FluentBoardsPro\App\Models\TaskAttachment;
use FluentBoardsPro\App\Modules\TimeTracking\Model\TimeTrack;

class ProTaskService
{
    public function getTemplateTasks()
    {
        $userId = get_current_user_id();
        $currentUser = User::find($userId);

        $relatedBoardsQuery = Board::query();

        if (!PermissionManager::isAdmin($userId)) {
            $relatedBoardsQuery->whereIn('id', $currentUser->whichBoards->pluck('id'));
        }

        $templateTaskIds = TaskMeta::where('key', 'is_template')->where('value', 'yes')->pluck('task_id');
        return Task::whereIn('id', $templateTaskIds)
            ->where('archived_at', null)
            ->whereIn('board_id', $relatedBoardsQuery->pluck('id'))
            ->with('assignees', 'labels')
            ->get();

    }

    /** Preserve creator, contact and assignment context supplied by trusted automations. */
    public function createFromTemplateForAutomation($taskId, $data, array $context)
    {
        return $this->createFromTemplate($taskId, $data, $context);
    }

    /** Copy template data. Context is supplied by trusted integrations, never request data. */
    public function createFromTemplate($taskId, $data, array $context = [])
    {
        // Input validation
        if (!is_numeric($taskId) || $taskId <= 0) {
            throw new \Exception('Invalid task id', 400);
        }
        
        if (!isset($data['board_id']) || !is_numeric($data['board_id']) || $data['board_id'] <= 0 || !is_int($data['board_id'] + 0) || $data['board_id'] != (int)$data['board_id']) {
            throw new \Exception('Invalid board id - must be a positive integer', 400);
        }
        
        $templateTask = Task::find($taskId);
        if (!$templateTask) {
            throw new \Exception('Template task not found', 404);
        }
        
        // Additional validation: ensure template task exists and is accessible
        if (!$templateTask->id || $templateTask->id != $taskId) {
            throw new \Exception('Template task not found', 404);
        }
        
        if (!Stage::where('id', absint($data['stage_id'] ?? 0))
            ->where('board_id', (int) $data['board_id'])->exists()) {
            throw new \Exception(__('Stage not found', 'fluent-boards-pro'), 404);
        }

        $taskService = new TaskService();
        $task = new Task();

        $task->fill($templateTask->toArray());

        $task->title = sanitize_text_field($data['title']);
        $task->board_id = (int) $data['board_id'];
        $task->stage_id = absint($data['stage_id']);
        $task->created_by = array_key_exists('created_by', $context) ? absint($context['created_by']) : get_current_user_id();
        $task->comments_count = 0;
        $task->parent_id = null;
        if (array_key_exists('crm_contact_id', $context)) {
            $task->crm_contact_id = absint($context['crm_contact_id']);
        }
        if (isset($context['source'])) {
            $task->source = sanitize_key($context['source']);
        }
        $settings = $task->settings ?: [];
        $settings['subtask_count'] = 0;
        $settings['subtask_completed_count'] = 0;
        $task->settings = $settings;
        
        // Remove task cover if creating in a DIFFERENT board
        if ($templateTask->board_id !== $task->board_id) {
            $this->removeTaskCoverImage($task);
        }
        
        $task->moveToNewPosition(1);
        $task->save();

        // Check if creating in the same board or different board
        $isSameBoard = (int)$templateTask->board_id === (int)$task->board_id;

        if ($isSameBoard) {
            // SAME BOARD: Copy everything as before
            if (!array_key_exists('assignees', $context) && isset($data['assignee']) && $data['assignee'] == 'true') {
                $templateTask->load('assignees');
                $assigneeIds = PermissionManager::getUserIdsWithBoardAccess($task->board_id, $templateTask->assignees->pluck('ID')->all());
                foreach ($assigneeIds as $assigneeId) {
                    $taskService->updateAssignee($assigneeId, $task);
                }
            }
            if (isset($data['label']) && $data['label'] == 'true') {
                $templateTask->load('labels');
                foreach ($templateTask->labels as $label) {
                    $task->labels()->syncWithoutDetaching([$label->id => ['object_type' => Constant::OBJECT_TYPE_TASK_LABEL]]);
                }
            }
            if (isset($data['watcher']) && $data['watcher'] == 'true') {
                $templateTask->load('watchers');
                foreach ($templateTask->watchers as $watcher) {
                    $task->watchers()->syncWithoutDetaching([$watcher->ID => ['object_type' => Constant::OBJECT_TYPE_USER_TASK_WATCH]]);
                }
            }
            if (isset($data['attachment']) && $data['attachment'] == 'true') {
                $templateTask->load('attachments');
                foreach ($templateTask->attachments as $attachment) {
                    $newAttachment = new TaskAttachment();
                    $newAttachment->object_id = $task->id;
                    $newAttachment->object_type = $attachment->object_type;
                    $newAttachment->attachment_type = $attachment->attachment_type;
                    $newAttachment->title = $attachment->title;
                    $newAttachment->file_path = $attachment->file_path;
                    $newAttachment->full_url = $attachment->full_url;
                    $newAttachment->file_size = $attachment->file_size;
                    $newAttachment->settings = $attachment->settings;
                    $newAttachment->driver = $attachment->driver;
                    $newAttachment->save();
                }
            }
            if (isset($data['comment']) && $data['comment'] == 'true') {
                $this->copyCommentsAndReplies($templateTask->id, $task->id);
            }
            if (isset($data['time_tracking']) && $data['time_tracking'] == 'true') {
                $this->copyTimeTrackingRecords($templateTask->id, $task->id);
            }
            if (isset($data['custom_field']) && $data['custom_field'] == 'true') {
                $this->copyCustomFieldAssociations($templateTask->id, $task->id);
            }
        }
        // DIFFERENT BOARD: Only copy safe data (subtasks, recurring tasks)
        // SECURITY: Don't copy user-specific or file data

        // KEEP: Non-user-specific data only (works for both same and different boards)
        if (isset($data['subtask']) && $data['subtask'] == 'true') {
            $subtaskGroupMap = [];
            $subtaskGroupMap = (new TaskService())->copySubtaskGroup($templateTask, $task, $subtaskGroupMap);
            $subtaskQuery = Task::where('parent_id', $taskId);
            if ($isSameBoard) {
                $subtaskQuery->with('assignees');
            }
            $subtasks = $subtaskQuery->get();
            $groupRelations = TaskMeta::where('key', Constant::SUBTASK_GROUP_CHILD)
                ->whereIn('task_id', $subtasks->pluck('id')->toArray())
                ->orderBy('id')->get()->groupBy('task_id');
            foreach ($subtasks as $subtask) {
                $newSubtask = new Task();
                $newSubtask->fill($subtask->toArray());
                $newSubtask['parent_id'] = $task->id;
                $newSubtask['board_id'] = $task->board_id;
                $newSubtask['stage_id'] = $task->stage_id;
                $newSubtask['created_by'] = $task->created_by;
                $newSubtask->save();

                //adding to subtasktask group
                $subtaskGroupRelations = $groupRelations->get($subtask->id);
                $groupRelationOfTask = $subtaskGroupRelations ? $subtaskGroupRelations->first() : null;
                if ($groupRelationOfTask && isset($subtaskGroupMap[$groupRelationOfTask->value])) {
                    TaskMeta::create([
                        'task_id' => $newSubtask->id,
                        'key' => Constant::SUBTASK_GROUP_CHILD,
                        'value' => $subtaskGroupMap[$groupRelationOfTask->value]
                    ]);
                }

                //adding assignees - SECURITY: Only if same board
                if ($isSameBoard) {
                    $subtaskAssigneeIds = PermissionManager::getUserIdsWithBoardAccess($newSubtask->board_id, $subtask->assignees->pluck('ID')->all());
                    foreach ($subtaskAssigneeIds as $assigneeId) {
                        $taskService->updateAssignee($assigneeId, $newSubtask);
                    }
                }
            }
        }
        
        // Handle recurring tasks for both same and different boards
        if (isset($data['recurring']) && $data['recurring'] == 'true') {
            if ($isSameBoard) {
                // SAME BOARD: Copy recurring task settings
                $this->copyRecurringTaskSettings($templateTask->id, $task->id);
            } else {
                // DIFFERENT BOARD: Remove recurring task settings for security
                $this->removeRecurringTaskSettings($task->id);
            }
        }
        
        // Apply stage default assignees ONLY if no template assignees were copied
        // This prevents conflicts with template assignees
        if (array_key_exists('assignees', $context)) {
            $assigneeIds = PermissionManager::getUserIdsWithBoardAccess($task->board_id, (array) $context['assignees']);
            foreach ($assigneeIds as $assigneeId) {
                $taskService->updateAssignee($assigneeId, $task);
            }
        } elseif (!isset($data['assignee']) || $data['assignee'] != 'true') {
            $taskService->manageDefaultAssignees($task, $task['stage_id']);
        }

        Task::adjustSubtaskCount($task->id);
        $task = $task->fresh();
        $task->load(['board', 'assignees', 'labels', 'watchers', 'attachments']);

        return $task;
    }

    public function setDefaultWatchersToEveryTasks($stage)
    {
        if (!$stage) {
            return null;
        }

        $settings = $stage->settings;
        if (!$settings) {
            return $stage;
        }

        $defaultWatchers = [];
        if (isset($settings['default_task_watchers']) && is_array($settings['default_task_watchers'])) {
            $defaultWatchers = $settings['default_task_watchers'];
        }
        if (isset($settings['default_task_assignees']) && is_array($settings['default_task_assignees'])) {
            $defaultWatchers = array_unique(array_merge($defaultWatchers, $settings['default_task_assignees']));
        }
        if (!$defaultWatchers) {
            return $stage;
        }

        $tasks = $stage->tasks->whereNull('archived_at');

        foreach ($tasks as $task) {
            $existingWatcherIds = $task->watchers->pluck('ID')->toArray();

            foreach ($defaultWatchers as $watcherId) {
                if (!in_array($watcherId, $existingWatcherIds)) {
                    $task->watchers()->syncWithoutDetaching([
                        $watcherId => ['object_type' => Constant::OBJECT_TYPE_USER_TASK_WATCH]
                    ]);
                }
            }
        }

        return $stage;
    }


    /**
     * Remove task cover image for security reasons
     * Keeps background colors but removes image references
     */
    private function removeTaskCoverImage($task)
    {
        $settings = $task->settings;
        if (empty($settings) || !is_array($settings)) {
            return;
        }
        
        if (isset($settings['cover']) && is_array($settings['cover'])) {
            $cover = $settings['cover'];
            
            // Remove image references
            unset($cover['imageId']);
            unset($cover['backgroundImage']);
            
            // Keep only background color if it exists
            if (isset($cover['backgroundColor'])) {
                $settings['cover'] = array('backgroundColor' => $cover['backgroundColor']);
            } else {
                unset($settings['cover']);
            }
            
            $task->settings = $settings;
        }
    }

    /**
     * Copy comments and replies from template task to new task
     * Only used when creating in same board for security
     */
    private function copyCommentsAndReplies($templateTaskId, $newTaskId)
    {
        if (!is_numeric($templateTaskId) || $templateTaskId <= 0 || !is_numeric($newTaskId) || $newTaskId <= 0) {
            return;
        }

        $comments = Comment::where('task_id', (int) $templateTaskId)->get();
        
        foreach ($comments as $comment) {
            $newComment = new Comment();
            $newComment->fill($comment->toArray());
            $newComment->task_id = (int) $newTaskId;
            $newComment->id = null; // Let database assign new ID
            $newComment->save();
        }
    }

    /**
     * Copy time tracking records from template task to new task
     * Only used when creating in same board for security
     */
    private function copyTimeTrackingRecords($templateTaskId, $newTaskId)
    {
        if (!is_numeric($templateTaskId) || $templateTaskId <= 0 || !is_numeric($newTaskId) || $newTaskId <= 0) {
            return;
        }

        if (class_exists('FluentBoardsPro\App\Modules\TimeTracking\Model\TimeTrack')) {
            $timeRecords = \FluentBoardsPro\App\Modules\TimeTracking\Model\TimeTrack::where('task_id', (int) $templateTaskId)->get();
            
            foreach ($timeRecords as $timeRecord) {
                $newTimeRecord = new \FluentBoardsPro\App\Modules\TimeTracking\Model\TimeTrack();
                $newTimeRecord->fill($timeRecord->toArray());
                $newTimeRecord->task_id = (int) $newTaskId;
                $newTimeRecord->id = null; // Let database assign new ID
                $newTimeRecord->save();
            }
        }
    }

    /**
     * Copy custom field associations for same-board templates and recurring tasks.
     */
    public function copyCustomFieldAssociations($templateTaskId, $newTaskId)
    {
        if (!is_numeric($templateTaskId) || $templateTaskId <= 0 || !is_numeric($newTaskId) || $newTaskId <= 0) {
            return;
        }

        $customFields = Task::findOrFail($templateTaskId)->taskCustomFields()->get();
        foreach ($customFields as $customField) {
            $copy = $customField->replicate();
            $copy->object_id = (int) $newTaskId;
            $copy->save();
        }
    }

    /**
     * Copy recurring task settings from template task to new task
     * Only used when creating in same board for security
     */
    private function copyRecurringTaskSettings($templateTaskId, $newTaskId)
    {
        if (!is_numeric($templateTaskId) || $templateTaskId <= 0 || !is_numeric($newTaskId) || $newTaskId <= 0) {
            return;
        }

        $existingRecurringSettings = Meta::where('object_id', (int) $newTaskId)
            ->where('object_type', Constant::REPEAT_TASK_META)
            ->first();

        if ($existingRecurringSettings) {
            return;
        }

        // Get recurring settings from fbs_metas table
        $recurringSettings = Meta::where('object_id', (int) $templateTaskId)
            ->where('object_type', Constant::REPEAT_TASK_META)
            ->first();
        
        if ($recurringSettings) {
            // Create new recurring setting in fbs_metas table
            $newRecurringSetting = new Meta();
            $newRecurringSetting->object_id = (int) $newTaskId;
            $newRecurringSetting->object_type = Constant::REPEAT_TASK_META;
            $newRecurringSetting->key = $recurringSettings->key;
            $newRecurringSetting->value = $recurringSettings->value;
            $newRecurringSetting->save();
        }
    }

    /**
     * Remove recurring task settings for security reasons
     * Used when creating in different board
     */
    private function removeRecurringTaskSettings($taskId)
    {
        if (!is_numeric($taskId) || $taskId <= 0) {
            return;
        }

        // Remove recurring task settings from fbs_metas table
        Meta::where('object_id', (int) $taskId)
            ->where('object_type', Constant::REPEAT_TASK_META)
            ->delete();
    }

    public function convertTaskToSubtask($taskId, $parent_id)
    {
        $task = Task::findOrFail($taskId);
        $parentTask = Task::findOrFail($parent_id);
        
        // Prevent converting task to subtask if they have different board IDs
        if ($task->board_id != $parentTask->board_id) {
            throw new \Exception(__('Cannot convert task to subtask: Task and parent task must be on the same board', 'fluent-boards-pro'));
        }
        
        if($task)
        {
            $task->parent_id = $parent_id;
            $task->stage_id = null;
            $task->save();

            //Removing all task related notifications, because task can not be opened from notification
            $notificationIds = $task->notifications->pluck('id');
            $task->notifications()->delete();
            NotificationUser::whereIn('notification_id', $notificationIds)->delete();
        }

        do_action('fluent_boards/subtask_added', $parentTask, $task);

        return $parentTask;
    }

    public function addAssigneeToSubtask($taskId, $assigneeId){
        $task = Task::findOrFail($taskId);

        //task assignees watchers removed
        $task->watchers()->detach();
        $task->assignees()->detach();

        $taskService = new TaskService();
        $taskService->updateTaskProperty('assignees', $assigneeId, $task);
    }

    public function addToSubtaskGroup($taskId, $subtaskGroupId = null, $parentTaskId = null) {
        if (!$subtaskGroupId && $parentTaskId) {
            $newGroup = TaskMeta::create([
                'task_id' => $parentTaskId,
                'key'     => Constant::SUBTASK_GROUP_NAME,
                'value'   => 'Default Subtask Group'
            ]);
            if ($newGroup) {
                TaskMeta::create([
                    'task_id' => $taskId,
                    'key'     => Constant::SUBTASK_GROUP_CHILD,
                    'value'   => $newGroup->id
                ]);
            }
            return;
        }
        TaskMeta::create([
           'task_id' => $taskId,
           'key'     => Constant::SUBTASK_GROUP_CHILD,
           'value'   => $subtaskGroupId
        ]);
    }

    public function getTaskTimeTrack($boardId, $taskId)
    {
        return TimeTrack::where('board_id', $boardId)
            ->where('task_id', $taskId)
            ->orderBy('updated_at', 'DESC')
            ->with(['user'])
            ->get();
    }

}
