<?php

namespace FluentBoardsPro\App\Services;

use FluentBoards\App\Services\FluentBoardsImporter as CoreFluentBoardsImporter;

/** Backward-compatible alias for the importer now provided by Fluent Boards core. */
class FluentBoardsImporter extends CoreFluentBoardsImporter
{
}
