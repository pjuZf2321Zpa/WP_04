<?php

namespace FluentBoardsPro\App\Services\Integrations\FluentCRM;

use FluentBoardsPro\App\Services\Integrations\FluentCRM\CreateBoardFromTemplateAction;

/**
 * Registers Fluent Boards Pro integrations for FluentCRM.
 */
class Init
{
    /**
     * Register the available FluentCRM integrations.
     */
    public function __construct()
    {
        $this->registerAutomationActions();
    }

    /**
     * Register Fluent Boards automation actions.
     *
     * @return void
     */
    public function registerAutomationActions()
    {
        new CreateBoardFromTemplateAction();
    }
}
