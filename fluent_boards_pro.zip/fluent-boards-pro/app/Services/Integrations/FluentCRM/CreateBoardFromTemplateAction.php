<?php

namespace FluentBoardsPro\App\Services\Integrations\FluentCRM;

use FluentBoards\App\Models\Board;
use FluentBoards\App\Services\BoardService;
use FluentBoardsPro\App\Services\TemplateService;
use FluentCrm\App\Services\Funnel\BaseAction;
use FluentCrm\App\Services\Funnel\FunnelHelper;
use FluentCrm\Framework\Support\Arr;

/**
 * Creates a Fluent Boards board from a user template in a FluentCRM automation.
 */
class CreateBoardFromTemplateAction extends BaseAction
{
    /**
     * Register the automation block and its save-time validator.
     */
    public function __construct()
    {
        $this->actionName = 'create_board_from_template';
        $this->priority = 20;

        parent::__construct();

        add_filter(
            'fluentcrm_funnel_sequence_saving_' . $this->actionName,
            [$this, 'savingAction'],
            10,
            2
        );
    }

    /**
     * Define the automation block and its default settings.
     *
     * @return array
     */
    public function getBlock()
    {
        return [
            'category'    => __('FluentBoards', 'fluent-boards-pro'),
            'title'       => __('Create Board from Template', 'fluent-boards-pro'),
            'description' => __('Create a new board from a user template', 'fluent-boards-pro'),
            'icon'        => 'fc-icon-apply_list',
            'settings'    => [
                'template_id' => '',
                'board_title' => $this->getDefaultBoardTitleTemplate(),
            ],
        ];
    }

    /**
     * Define the template selector and optional board title fields.
     *
     * @return array
     */
    public function getBlockFields()
    {
        return [
            'title'     => __('Create Board from Template', 'fluent-boards-pro'),
            'sub_title' => __('Select a user template to create a new board', 'fluent-boards-pro'),
            'fields'    => [
                'template_id' => [
                    'type'        => 'rest_selector',
                    'option_key'  => 'board_user_templates',
                    'is_multiple' => false,
                    'clearable'   => false,
                    'required'    => true,
                    'label'       => __('Select Template', 'fluent-boards-pro'),
                    'placeholder' => __('Select Template', 'fluent-boards-pro'),
                ],
                'board_title' => [
                    'type'        => 'input-text-popper',
                    'field_type'  => 'text',
                    'label'       => __('Board Title', 'fluent-boards-pro'),
                    'placeholder' => $this->getDefaultBoardTitleTemplate(),
                    'inline_help' => sprintf(
                        /* translators: %s: Default board title containing a FluentCRM smart code. */
                        __('Defaults to %s. FluentCRM smart codes are supported. The new board ID is appended to every title.', 'fluent-boards-pro'),
                        $this->getDefaultBoardTitleTemplate()
                    ),
                ],
            ],
        ];
    }

    /**
     * Validate and sanitize settings whenever the automation sequence is saved.
     *
     * @param array  $sequence
     * @param object $funnel
     * @return array
     * @throws \InvalidArgumentException
     */
    public function savingAction($sequence, $funnel)
    {
        $templateId = $this->sanitizeTemplateId(Arr::get($sequence, 'settings.template_id'));

        if (!$this->findUserTemplate($templateId, get_current_user_id())) {
            throw new \InvalidArgumentException(
                __('Please select a valid user board template.', 'fluent-boards-pro')
            );
        }

        $boardTitle = Arr::get($sequence, 'settings.board_title', '');
        $boardTitle = is_scalar($boardTitle) ? sanitize_text_field((string) $boardTitle) : '';

        if ($boardTitle === '') {
            $boardTitle = $this->getDefaultBoardTitleTemplate();
        }

        $sequence['settings'] = [
            'template_id' => $templateId,
            'board_title' => $boardTitle,
        ];

        return $sequence;
    }

    /**
     * Create a system-owned board with its ID appended to the title for the automation contact.
     *
     * @param object $subscriber
     * @param object $sequence
     * @param int    $funnelSubscriberId
     * @param object $funnelMetric
     * @return bool
     */
    public function handle($subscriber, $sequence, $funnelSubscriberId, $funnelMetric)
    {
        $templateId = $this->sanitizeTemplateId(Arr::get($sequence->settings, 'template_id'));

        if (!$templateId) {
            return $this->skipAction(
                $sequence,
                $funnelSubscriberId,
                $funnelMetric,
                __('Funnel skipped because no board template was selected.', 'fluent-boards-pro')
            );
        }

        $creatorId = absint($sequence->created_by ?? 0);
        $template = $this->findUserTemplate($templateId, $creatorId);
        if (!$template) {
            return $this->skipAction(
                $sequence,
                $funnelSubscriberId,
                $funnelMetric,
                __('Funnel skipped because the selected board template is no longer available.', 'fluent-boards-pro')
            );
        }

        $contactId = is_object($subscriber) ? absint($subscriber->id ?? 0) : 0;
        if (!$contactId) {
            return $this->skipAction(
                $sequence,
                $funnelSubscriberId,
                $funnelMetric,
                __('Funnel skipped because the CRM contact is unavailable.', 'fluent-boards-pro')
            );
        }

        $boardTitle = Arr::get($sequence->settings, 'board_title', '');
        $boardTitle = is_scalar($boardTitle) ? (string) $boardTitle : '';

        if ($boardTitle === '') {
            $boardTitle = $this->getDefaultBoardTitleTemplate();
        }

        $boardTitle = (string) apply_filters(
            'fluent_crm/parse_campaign_email_text',
            $boardTitle,
            $subscriber
        );

        $boardTitle = sanitize_text_field($boardTitle);
        if ($boardTitle === '') {
            $boardTitle = sanitize_text_field($template->title);
        }

        if ($boardTitle === '') {
            $boardTitle = __('New Board', 'fluent-boards-pro');
        }

        $previousUserId = get_current_user_id();

        try {
            // Automation-created boards and their queued template tasks are system-owned.
            wp_set_current_user(0);

            $board = (new TemplateService())->createFromUserTemplate(
                $templateId,
                $boardTitle,
                true,
                true,
                null,
                [],
                null,
                $creatorId
            );

            // Use the persisted title to preserve creation filters, without scanning other boards.
            $boardTitle = $board->title . ' - ' . $board->id;
            $updated = $board->newModelQuery()
                ->where('id', $board->id)
                ->update(['title' => $boardTitle]);

            if ($updated !== 1) {
                throw new \RuntimeException(
                    __('The created board title could not be updated.', 'fluent-boards-pro')
                );
            }

            $board->title = $boardTitle;
            $board->syncOriginalAttribute('title');

            $this->storeCrmContactMeta($board->id, $contactId);

            // Task copying is asynchronous; these hooks represent board creation only.
            do_action('fluent_boards/board_created_from_template', $board, 'user', $templateId);
            do_action('fluent_boards/board_created_from_automation', $board, $subscriber, $funnelSubscriberId);
        } catch (\Throwable $exception) {
            $this->failAction($funnelMetric, $exception);
            return false;
        } finally {
            wp_set_current_user($previousUserId);
        }

        return true;
    }

    /**
     * Get the localized default title template shown and used by the automation action.
     *
     * @return string
     */
    private function getDefaultBoardTitleTemplate()
    {
        /* translators: %s: FluentCRM contact email smart code. */
        return sprintf(__('New Board - %s', 'fluent-boards-pro'), '{{contact.email}}');
    }

    /**
     * Normalize a template selector value to a positive integer.
     *
     * @param mixed $templateId
     * @return int
     */
    private function sanitizeTemplateId($templateId)
    {
        return is_scalar($templateId) ? absint($templateId) : 0;
    }

    /**
     * Find an existing board that is still a user template.
     *
     * @param int $templateId
     * @param int $userId User whose source-board access should be applied.
     * @return Board|null
     */
    private function findUserTemplate($templateId, $userId)
    {
        $userId = absint($userId);

        if (!$templateId || !$userId || !get_user_by('id', $userId)) {
            return null;
        }

        return Board::query()
            ->byAccessUser($userId)
            ->onlyTemplates()
            ->find($templateId);
    }

    /**
     * Store the automation contact ID on the created board.
     *
     * @param int $boardId
     * @param int $contactId
     * @return void
     */
    private function storeCrmContactMeta($boardId, $contactId)
    {
        (new BoardService())->updateAssociateMember(absint($contactId), absint($boardId));
    }

    /**
     * Record an expected skip and stop this automation sequence.
     *
     * @param object $sequence
     * @param int    $funnelSubscriberId
     * @param object $funnelMetric
     * @param string $note
     * @return bool
     */
    private function skipAction($sequence, $funnelSubscriberId, $funnelMetric, $note)
    {
        if ($funnelMetric) {
            $funnelMetric->status = 'skipped';
            $funnelMetric->notes = $note;
            $funnelMetric->save();
        }

        FunnelHelper::changeFunnelSubSequenceStatus(
            absint($funnelSubscriberId),
            absint($sequence->id),
            'skipped'
        );

        return false;
    }

    /**
     * Record an unexpected board-creation failure for diagnostics.
     *
     * @param object     $funnelMetric
     * @param \Throwable $exception
     * @return void
     */
    private function failAction($funnelMetric, \Throwable $exception)
    {
        if (!$funnelMetric) {
            return;
        }

        $message = sanitize_text_field($exception->getMessage());
        $funnelMetric->status = 'failed';
        $funnelMetric->notes = sprintf(
            /* translators: %s is the error message */
            __('Board creation failed: %s', 'fluent-boards-pro'),
            $message ?: get_class($exception)
        );
        $funnelMetric->save();
    }
}
