<?php

namespace FluentBoardsPro\App\Services;

use FluentBoards\App\Models\Board;
use FluentBoards\App\Models\Relation;
use FluentBoards\App\Models\TaskMeta;
use FluentBoards\App\Services\Constant as CoreConstant;
use FluentBoards\Framework\Support\Str;

class AsanaImporter
{
    private static $alreadyCreatedStages = [];
    private static $stageMapper = [];
    private static $boardMapper = null;
    private static $labelMapper = [];
    private static $fallbackStageId = null;

    private static $stagePosition = 1;

    private static $apiBaseUrl = 'https://app.asana.com/api/1.0';

    public static function process($data)
    {
        // Reset static state so repeat imports in the same request don't leak.
        self::$alreadyCreatedStages = [];
        self::$stageMapper = [];
        self::$boardMapper = null;
        self::$labelMapper = [];
        self::$fallbackStageId = null;
        self::$stagePosition = 1;

        $board = self::createBoard($data);

        // Pre-create all stages from the sections list (API flow). This preserves
        // Asana's left-to-right section order AND includes empty sections, which
        // the task-driven discovery below would silently drop.
        if (!empty($data['sections'])) {
            self::createStagesFromSections($board, $data['sections']);
        }

        // Create labels once per unique tag gid across the whole import.
        self::createLabelsFromTasks($board, $data['data']);

        $taskCount = 0;
        foreach ($data['data'] as $asanaTask) {
            $taskStage = self::getStageIdOfAsanaTask($asanaTask);

            // JSON flow: no pre-seeded sections, so create stages lazily as we
            // encounter new ones (matches original behavior).
            if ($taskStage && !in_array($taskStage['gid'], self::$alreadyCreatedStages)) {
                $newStage = self::createStage($board, $taskStage['name']);
                self::$stageMapper[trim($taskStage['gid'])] = $newStage->id;
                self::$alreadyCreatedStages[] = trim($taskStage['gid']);
                if (self::$fallbackStageId === null) {
                    self::$fallbackStageId = $newStage->id;
                }
            }

            $taskData = self::prepareTaskData($asanaTask, null, $taskStage);

            // Nothing should be stage-less — a null stage_id makes the task
            // invisible in the Kanban view. Route orphans to a fallback stage.
            if (empty($taskData['stage_id'])) {
                $taskData['stage_id'] = self::ensureFallbackStage($board);
            }

            $task = $board->tasks()->create($taskData);
            $taskCount++;

            self::attachTagsToTask($task, $asanaTask);

            if (!empty($asanaTask['subtasks'])) {
                self::loadSubtasks($task, $asanaTask['subtasks'], $board);
            }
        }

        Helper::defaultTaskCountAdd($board, $taskCount);

        return $board;
    }

    /**
     * Pre-create a board stage for every Asana section, preserving order and
     * including sections with zero tasks.
     */
    private static function createStagesFromSections($board, $sections)
    {
        foreach ($sections as $section) {
            if (empty($section['gid']) || empty($section['name'])) {
                continue;
            }
            $newStage = self::createStage($board, $section['name']);
            self::$stageMapper[trim($section['gid'])] = $newStage->id;
            self::$alreadyCreatedStages[] = trim($section['gid']);
            if (self::$fallbackStageId === null) {
                self::$fallbackStageId = $newStage->id;
            }
        }
    }

    /**
     * Return the id of a stage that orphan tasks can live on. Creates an
     * "Imported" stage if nothing exists yet (can happen in the JSON flow when
     * the first task we see has no section).
     */
    private static function ensureFallbackStage($board)
    {
        if (self::$fallbackStageId !== null) {
            return self::$fallbackStageId;
        }
        $newStage = self::createStage($board, __('Imported', 'fluent-boards-pro'));
        self::$fallbackStageId = $newStage->id;
        return $newStage->id;
    }

    private static function loadSubtasks($task, $subtasks, $board)
    {
        $subtaskGroup = self::createDefaultSubtaskGroup($task);

        foreach ($subtasks as $asanaSubtask) {
            $taskData = self::prepareTaskData($asanaSubtask, $task, null);
            $subtask = $board->tasks()->create($taskData);
            if ($subtask) {
                $parentTaskSettings = $task->settings;
                $parentTaskSettings['subtask_count'] = ($parentTaskSettings['subtask_count'] ?? 0) + 1;
                $task->settings = $parentTaskSettings;
                $task->save();

                TaskMeta::create([
                    'task_id' => $subtask->id,
                    'key' => CoreConstant::SUBTASK_GROUP_CHILD,
                    'value' => $subtaskGroup->id
                ]);

                self::attachTagsToTask($subtask, $asanaSubtask);
            }
        }
    }

    private static function getStageIdOfAsanaTask($asanaTask)
    {
        if (empty($asanaTask['memberships'])) {
            return null;
        }

        // Strict: only accept a section that belongs to the project we're importing.
        // Picking a "last resort" foreign-project section would mislabel the task's
        // stage when it's a direct (unsectioned) member of our project.
        foreach ($asanaTask['memberships'] as $membership) {
            if (empty($membership['project']['gid']) || empty($membership['section'])) {
                continue;
            }
            if ((string) $membership['project']['gid'] === (string) self::$boardMapper) {
                return $membership['section'];
            }
        }

        // JSON-import fallback: if boardMapper wasn't set (legacy JSON shapes) or
        // the task has no matching-project section, fall back to the first
        // membership that has any section at all.
        if (!self::$boardMapper) {
            foreach ($asanaTask['memberships'] as $membership) {
                if (!empty($membership['section'])) {
                    return $membership['section'];
                }
            }
        }

        return null;
    }

    private static function createBoard($asanaTasks)
    {
        $boardName = null;
        $boardId = null;
        $boardDescription = null;

        // Prefer explicit project info if the API fetcher passed it at the top level.
        if (!empty($asanaTasks['project']) && !empty($asanaTasks['project']['gid'])) {
            $boardName = $asanaTasks['project']['name'] ?? null;
            $boardId = $asanaTasks['project']['gid'];
            $boardDescription = $asanaTasks['project']['html_notes']
                ?? $asanaTasks['project']['notes']
                ?? null;
        } else {
            foreach ($asanaTasks['data'] as $index => $task) {
                if (empty($task['projects'])) {
                    continue;
                }
                // Single-project task is the most reliable signal; otherwise use
                // the last task's first project (matches the JSON flow).
                if (count($task['projects']) == 1 || $index == count($asanaTasks['data']) - 1) {
                    $boardName = $task['projects'][0]['name'];
                    $boardId = $task['projects'][0]['gid'];
                    break;
                }
            }
        }

        $boardData = [
            'title' => sanitize_text_field($boardName ?: __('Imported from Asana', 'fluent-boards-pro')),
            'slug' => Str::slug($boardName ?: 'asana-import'),
            'description' => $boardDescription ? wp_kses_post($boardDescription) : null,
            'user_id' => get_current_user_id()
        ];

        $board = Board::create($boardData);

        if ($board) {
            Helper::setCurrentUserPreferencesOnBoardCreate($board);
            Helper::createDefaultLabels($board->id);
            do_action('fluent_boards/board_created', $board);
        }

        self::$boardMapper = $boardId;

        return $board;
    }

    private static function createStage($board, $taskStageName)
    {
        return $board->stages()->create([
            'title' => sanitize_text_field($taskStageName),
            'slug' => Str::slug($taskStageName),
            'type' => 'stage',
            'position' => self::$stagePosition++
        ]);
    }

    private static function prepareTaskData($task, $parentTask = null, $taskStage = null)
    {
        // $wpdb->insert binds INT columns with %d (null → 0) and TIMESTAMP
        // columns with %s (null → "" → stored as 0000-00-00 00:00:00 in
        // non-strict sql_mode). Either coercion breaks the board load query
        // (which filters whereNull('archived_at')) and shows zero-dates in the
        // UI. Solution: only include keys that have real values; let the DB
        // default (NULL) handle the rest.

        $taskData = [
            'title' => sanitize_text_field($task['name']),
            'source' => 'asana',
            'status' => !empty($task['completed']) ? 'closed' : 'open',
        ];

        if (!empty($task['html_notes'])) {
            $taskData['description'] = wp_kses_post($task['html_notes']);
        } elseif (!empty($task['notes'])) {
            $taskData['description'] = wp_kses_post(nl2br($task['notes']));
        }

        if (!empty($task['completed_at'])) {
            $taskData['last_completed_at'] = gmdate('Y-m-d H:i:s', strtotime($task['completed_at']));
        }
        if (!empty($task['due_on'])) {
            $taskData['due_at'] = gmdate('Y-m-d H:i:s', strtotime($task['due_on']));
        }
        if (!empty($task['start_on'])) {
            $taskData['started_at'] = gmdate('Y-m-d H:i:s', strtotime($task['start_on']));
        }

        if ($parentTask) {
            $taskData['parent_id'] = $parentTask->id;
        }

        if ($taskStage && isset(self::$stageMapper[trim($taskStage['gid'])])) {
            $taskData['stage_id'] = self::$stageMapper[trim($taskStage['gid'])];
        }

        return $taskData;
    }

    /**
     * Called once before the task loop — scans all tasks AND subtasks for
     * unique tag gids and creates one board label per unique gid.
     */
    private static function createLabelsFromTasks($board, $tasks)
    {
        $seen = [];
        $unique = [];

        $collect = function ($task) use (&$seen, &$unique, &$collect) {
            if (!empty($task['tags'])) {
                foreach ($task['tags'] as $tag) {
                    if (empty($tag['gid']) || isset($seen[$tag['gid']])) {
                        continue;
                    }
                    $seen[$tag['gid']] = true;
                    $unique[] = $tag;
                }
            }
            if (!empty($task['subtasks'])) {
                foreach ($task['subtasks'] as $subtask) {
                    $collect($subtask);
                }
            }
        };

        foreach ($tasks as $task) {
            $collect($task);
        }

        foreach ($unique as $tag) {
            $bg = self::resolveTagBgColor($tag['color'] ?? null);
            $textColor = self::resolveTagTextColor($tag['color'] ?? null);

            $newLabel = $board->labels()->create([
                'title' => sanitize_text_field($tag['name'] ?? ''),
                'slug' => Str::slug($tag['name'] ?? $tag['gid']),
                'color' => $textColor,
                'bg_color' => $bg,
            ]);
            self::$labelMapper[trim($tag['gid'])] = $newLabel->id;
        }
    }

    private static function attachTagsToTask($task, $asanaTask)
    {
        if (empty($asanaTask['tags'])) {
            return;
        }
        foreach ($asanaTask['tags'] as $tag) {
            if (empty($tag['gid']) || !isset(self::$labelMapper[trim($tag['gid'])])) {
                continue;
            }
            Relation::create([
                'object_id'   => $task->id,
                'object_type' => CoreConstant::OBJECT_TYPE_TASK_LABEL,
                'foreign_id'  => self::$labelMapper[trim($tag['gid'])]
            ]);
        }
    }

    /**
     * Asana tag colors look like "dark-pink" / "light-blue". Normalize to the
     * Trello color map keys ("pink_dark" / "blue_light") and reuse the shared map.
     */
    private static function resolveTagBgColor($asanaColor)
    {
        $fallback = '#9f8fef';
        if (!$asanaColor) {
            return $fallback;
        }
        $key = self::normalizeAsanaColorKey($asanaColor);
        return Constant::TRELLO_COLOR_MAP[$key] ?? $fallback;
    }

    private static function resolveTagTextColor($asanaColor)
    {
        $fallback = '#1B2533';
        if (!$asanaColor) {
            return $fallback;
        }
        $key = self::normalizeAsanaColorKey($asanaColor);
        return Constant::TEXT_COLOR_MAP[$key] ?? $fallback;
    }

    private static function normalizeAsanaColorKey($asanaColor)
    {
        // "dark-pink" -> "pink_dark", "light-blue" -> "blue_light",
        // "pink" -> "pink", "blue" -> "blue"
        $parts = explode('-', $asanaColor);
        if (count($parts) === 1) {
            return $parts[0];
        }
        [$modifier, $base] = $parts;
        return $base . '_' . $modifier;
    }

    private static function createDefaultSubtaskGroup($task)
    {
        $group = TaskMeta::where('task_id', $task->id)
            ->where('key', CoreConstant::SUBTASK_GROUP_NAME)
            ->first();

        if (!$group) {
            return TaskMeta::create([
                'task_id' => $task->id,
                'key' => CoreConstant::SUBTASK_GROUP_NAME,
                'value' => 'Default Subtask Group'
            ]);
        }

        return $group;
    }

    /**
     * =========================================================================
     * API-driven import (Personal Access Token flow)
     * =========================================================================
     */

    /**
     * Fetch workspaces accessible by the PAT.
     *
     * @return array  List of {gid, name} or ['error' => message]
     */
    public static function fetchWorkspaces($pat)
    {
        $response = self::apiGet(self::$apiBaseUrl . '/workspaces?opt_fields=name', $pat);
        if (isset($response['error'])) {
            return $response;
        }
        return $response['data'] ?? [];
    }

    /**
     * Fetch open projects in a workspace.
     *
     * @return array  List of {gid, name} or ['error' => message]
     */
    public static function fetchProjects($pat, $workspaceGid)
    {
        $url = self::$apiBaseUrl . '/workspaces/' . urlencode($workspaceGid)
            . '/projects?archived=false&opt_fields=name,permalink_url&limit=100';

        $all = [];
        while ($url) {
            $response = self::apiGet($url, $pat);
            if (isset($response['error'])) {
                return $response;
            }
            foreach ($response['data'] ?? [] as $project) {
                $all[] = $project;
            }
            $url = self::nextPageUrl($response);
        }
        return $all;
    }

    /**
     * Fetch a project + its tasks (with subtasks, tags, memberships inlined)
     * and run them through the existing process() pipeline.
     *
     * @return Board|array  Created Board, or ['error' => message]
     */
    public static function fetchAndImport($pat, $projectGid)
    {
        if (ini_get('max_execution_time') < 300) {
            @ini_set('max_execution_time', '300');
        }
        $currentMemory = wp_convert_hr_to_bytes(ini_get('memory_limit'));
        if ($currentMemory < 536870912) {
            @ini_set('memory_limit', '512M');
        }

        $projectUrl = self::$apiBaseUrl . '/projects/' . urlencode($projectGid)
            . '?opt_fields=name,notes,html_notes,permalink_url,color';
        $project = self::apiGet($projectUrl, $pat);
        if (isset($project['error'])) {
            return $project;
        }
        $projectData = $project['data'] ?? null;
        if (!$projectData) {
            return ['error' => __('Project not found or not accessible.', 'fluent-boards-pro')];
        }

        // Fetch sections explicitly. This is what makes stages appear in the
        // correct order AND includes empty sections (which task-driven
        // discovery silently drops).
        $sections = [];
        $sectionsUrl = self::$apiBaseUrl . '/projects/' . urlencode($projectGid)
            . '/sections?opt_fields=name&limit=100';
        while ($sectionsUrl) {
            $response = self::apiGet($sectionsUrl, $pat);
            if (isset($response['error'])) {
                return $response;
            }
            foreach ($response['data'] ?? [] as $section) {
                $sections[] = $section;
            }
            $sectionsUrl = self::nextPageUrl($response);
        }

        // Task list. opt_fields traverses `subtasks.*` to inline subtasks in one shot.
        $taskFields = implode(',', [
            'name',
            'notes',
            'html_notes',
            'completed',
            'completed_at',
            'due_on',
            'start_on',
            'permalink_url',
            'memberships.section.gid',
            'memberships.section.name',
            'memberships.project.gid',
            'tags.gid',
            'tags.name',
            'tags.color',
            'subtasks.name',
            'subtasks.notes',
            'subtasks.html_notes',
            'subtasks.completed',
            'subtasks.completed_at',
            'subtasks.due_on',
            'subtasks.start_on',
            'subtasks.tags.gid',
            'subtasks.tags.name',
            'subtasks.tags.color',
        ]);

        $tasksUrl = self::$apiBaseUrl . '/projects/' . urlencode($projectGid)
            . '/tasks?limit=100&opt_fields=' . $taskFields;

        $tasks = [];
        while ($tasksUrl) {
            $response = self::apiGet($tasksUrl, $pat);
            if (isset($response['error'])) {
                return $response;
            }
            foreach ($response['data'] ?? [] as $task) {
                // Shape: ensure each task advertises its project so createBoard() can resolve it.
                if (empty($task['projects'])) {
                    $task['projects'] = [[
                        'gid' => $projectData['gid'],
                        'name' => $projectData['name'],
                    ]];
                }
                $tasks[] = $task;
            }
            $tasksUrl = self::nextPageUrl($response);
        }

        $shaped = [
            'project' => $projectData,
            'sections' => $sections,
            'data' => $tasks,
        ];

        return self::process($shaped);
    }

    /**
     * @param array $response  Decoded Asana response
     * @return string|null     Next-page URL (absolute) or null when done.
     */
    private static function nextPageUrl($response)
    {
        if (empty($response['next_page']) || empty($response['next_page']['uri'])) {
            return null;
        }
        return $response['next_page']['uri'];
    }

    /**
     * @param string $url  Full URL including any query string
     * @param string $pat  Personal Access Token
     * @return array       Decoded JSON response, or ['error' => message]
     */
    private static function apiGet($url, $pat)
    {
        $maxAttempts = 3;
        $attempt = 0;
        $lastError = null;

        while ($attempt < $maxAttempts) {
            $attempt++;

            $response = wp_remote_get($url, [
                'timeout' => 30,
                'headers' => [
                    'Authorization' => 'Bearer ' . $pat,
                    'Accept' => 'application/json',
                ],
            ]);

            // Transport-level failure (timeout, DNS, etc.) — retry with linear backoff.
            if (is_wp_error($response)) {
                $lastError = $response->get_error_message();
                if ($attempt < $maxAttempts) {
                    sleep($attempt); // 1s, 2s
                    continue;
                }
                return ['error' => $lastError];
            }

            $code = wp_remote_retrieve_response_code($response);

            // 5xx and 429 are transient — back off and retry.
            if (($code >= 500 || $code === 429) && $attempt < $maxAttempts) {
                $retryAfter = (int) wp_remote_retrieve_header($response, 'retry-after');
                sleep($retryAfter > 0 ? min($retryAfter, 5) : $attempt);
                continue;
            }

            $body = json_decode(wp_remote_retrieve_body($response), true);

            if ($code === 401) {
                return ['error' => __('Invalid Personal Access Token. Please check and try again.', 'fluent-boards-pro')];
            }
            if ($code === 403) {
                return ['error' => __('No access to this resource. Your token may lack the required permissions.', 'fluent-boards-pro')];
            }
            if ($code === 404) {
                return ['error' => __('Resource not found on Asana.', 'fluent-boards-pro')];
            }
            if ($code === 429) {
                return ['error' => __('Asana rate limit hit. Please try again in a minute.', 'fluent-boards-pro')];
            }

            if ($code !== 200 || !is_array($body)) {
                $message = is_array($body) && !empty($body['errors'][0]['message'])
                    ? $body['errors'][0]['message']
                    : __('Asana API request failed.', 'fluent-boards-pro');
                return ['error' => $message];
            }

            return $body;
        }

        return ['error' => $lastError ?: __('Asana API request failed after retries.', 'fluent-boards-pro')];
    }
}
