<?php

namespace FluentBoardsPro\App\Services;

use FluentBoards\Framework\Support\Arr;
use FluentBoards\App\Services\Libs\FileSystem;
use FluentBoards\App\Services\UploadService;
use FluentBoardsPro\App\Modules\CloudStorage\CloudStorageModule;
use FluentBoardsPro\App\Modules\CloudStorage\StorageHelper;
use RuntimeException;

/** Resolve and stage Trello covers independently of import sessions or input format. */
class TrelloCoverService
{
    const MAX_WIDTH = 1600;
    const TIMEOUT = 15;
    const MAX_REDIRECTS = 3;

    /** Return null for no image, but retain a broken selection so it can be reported/retried. */
    public function resolve(array $card)
    {
        $attachmentId = Arr::get($card, 'cover.idAttachment') ?: Arr::get($card, 'idAttachmentCover', '');
        $scaled = Arr::get($card, 'cover.scaled', []);
        if (!$attachmentId && !$scaled && !Arr::get($card, 'cover.idUploadedBackground')) {
            return null;
        }
        $url = $this->pickSize($scaled);
        foreach ((array) Arr::get($card, 'attachments', []) as $attachment) {
            if (Arr::get($attachment, 'id') === $attachmentId) {
                $url = $url ?: $this->pickSize(Arr::get($attachment, 'previews', [])) ?: esc_url_raw(Arr::get($attachment, 'url', ''));
                break;
            }
        }
        return [
            'card_id' => (string) Arr::get($card, 'id', ''),
            'attachment_id' => (string) $attachmentId,
            'background_id' => (string) Arr::get($card, 'cover.idUploadedBackground', ''),
            'url' => $url ?: '',
        ];
    }

    /** Prefer a usable cover-sized preview, falling back to the smallest larger image. */
    private function pickSize($images)
    {
        if (!is_array($images)) {
            return '';
        }
        usort($images, function ($a, $b) { return (int) Arr::get($b, 'width') <=> (int) Arr::get($a, 'width'); });
        $fallback = '';
        foreach ($images as $image) {
            $url = esc_url_raw(Arr::get($image, 'url', ''));
            if (!$url) {
                continue;
            }
            if ((int) Arr::get($image, 'width') <= self::MAX_WIDTH) {
                return $url;
            }
            $fallback = $url;
        }
        return $fallback;
    }

    /** Refresh only the originally selected attachment/background, never today's replacement cover. */
    public function refresh(array $source, array $auth)
    {
        $cardId = rawurlencode($source['card_id']);
        if (!empty($source['attachment_id'])) {
            $attachmentId = rawurlencode($source['attachment_id']);
            $attachment = $this->readJson("https://api.trello.com/1/cards/$cardId/attachments/$attachmentId", $auth);
            if (Arr::get($attachment, 'id') !== $source['attachment_id']) {
                throw new RuntimeException('source_missing');
            }
            $source['url'] = $this->pickSize(Arr::get($attachment, 'previews', [])) ?: esc_url_raw(Arr::get($attachment, 'url', ''));
            return $source;
        }
        $card = $this->readJson("https://api.trello.com/1/cards/$cardId?fields=cover,idAttachmentCover&attachments=true&attachment_fields=id,url,previews", $auth);
        $fresh = $this->resolve($card);
        if (!$fresh || $fresh['attachment_id'] !== $source['attachment_id']
            || ($source['background_id'] ? $fresh['background_id'] !== $source['background_id'] : $fresh['url'] !== $source['url'])) {
            throw new RuntimeException('source_changed');
        }
        $fresh['card_id'] = $source['card_id'];
        return $fresh;
    }

    /** Read bounded source metadata without affecting the card import's API retry state. */
    private function readJson($url, array $auth)
    {
        $response = wp_safe_remote_get($url, [
            'headers' => $this->headers($url, $auth), 'timeout' => self::TIMEOUT,
            'redirection' => 0, 'limit_response_size' => 1048576,
        ]);
        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
            throw new RuntimeException('source_unavailable');
        }
        $data = json_decode(wp_remote_retrieve_body($response), true);
        if (!is_array($data)) {
            throw new RuntimeException('source_invalid');
        }
        return $data;
    }

    /** Restrict download origins; OAuth never leaves Trello's own API hosts. */
    private function hostType($url)
    {
        if (wp_parse_url($url, PHP_URL_SCHEME) !== 'https' || wp_parse_url($url, PHP_URL_USER)
            || wp_parse_url($url, PHP_URL_PASS) || !in_array(wp_parse_url($url, PHP_URL_PORT), [null, 443], true)) {
            return null;
        }
        $host = strtolower((string) wp_parse_url($url, PHP_URL_HOST));
        if (in_array($host, ['trello.com', 'api.trello.com'], true)) {
            return 'api';
        }
        if (in_array($host, ['trello-attachments.s3.amazonaws.com', 'trello-backgrounds.s3.amazonaws.com', 'images.unsplash.com'], true)
            || preg_match('/\Atrello-(?:backgrounds|attachments)\.s3\.[a-z]{2}(?:-[a-z]+)+-[0-9]+\.amazonaws\.com\z/', $host)
            || preg_match('/\.trello-attachments\.s3\.amazonaws\.com$/', $host)) {
            return 'storage';
        }
        return null;
    }

    /** Encode credentials as OAuth header values, never URL parameters or persisted image URLs. */
    private function headers($url, $auth)
    {
        if ($this->hostType($url) !== 'api' || empty($auth['key']) || empty($auth['token'])) {
            return [];
        }
        return ['Authorization' => sprintf('OAuth oauth_consumer_key="%s", oauth_token="%s"', rawurlencode($auth['key']), rawurlencode($auth['token']))];
    }

    /** Stage an image and checkpoint file identities before side effects, including cloud upload. */
    public function stage(array $source, $boardId, $auth, callable $checkpoint)
    {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        $url = $source['url'];
        if (!$this->hostType($url)) {
            throw new RuntimeException('unsupported_source');
        }
        $temp = wp_tempnam('fbs-trello-cover');
        if (!$temp) {
            throw new RuntimeException('storage_failed');
        }
        try {
            $checkpoint(['temp' => $temp]);
            $limit = (new UploadService())->getFileUploadLimit();
            for ($redirect = 0; $redirect <= self::MAX_REDIRECTS; $redirect++) {
                if (!$this->hostType($url)) {
                    throw new RuntimeException('unsupported_redirect');
                }
                $response = wp_safe_remote_get($url, [
                    'headers' => $this->headers($url, $auth), 'timeout' => self::TIMEOUT,
                    'redirection' => 0, 'stream' => true, 'filename' => $temp, 'limit_response_size' => $limit + 1,
                ]);
                if (is_wp_error($response)) {
                    throw new RuntimeException('download_failed');
                }
                $code = wp_remote_retrieve_response_code($response);
                if (in_array($code, [301, 302, 303, 307, 308], true) && $redirect < self::MAX_REDIRECTS) {
                    $url = (string) wp_remote_retrieve_header($response, 'location');
                    continue;
                }
                if ($code !== 200) {
                    throw new RuntimeException('download_failed');
                }
                break;
            }
            clearstatcache(true, $temp);
            $size = filesize($temp);
            $mime = wp_get_image_mime($temp);
            // WordPress before 5.8.1 has no default-extension helper; use the plugin's allow-list.
            $extension = false;
            foreach (UploadService::getAllowedMimeMap() as $extensions => $allowedMime) {
                if ($mime && $allowedMime === $mime) {
                    $extension = explode('|', $extensions)[0];
                    break;
                }
            }
            if (!$size || $size > $limit || !$extension) {
                throw new RuntimeException('invalid_image');
            }
            $name = wp_generate_uuid4() . '-trello-cover.' . $extension;
            (new UploadService())->validateFile(['name' => $name, 'size_in_bytes' => $size]);
            if (!FileSystem::installUploadProtectionRules()) {
                throw new RuntimeException('storage_failed');
            }
            $fileSystem = FileSystem::setSubDir('board_' . absint($boardId));
            $directory = $fileSystem->_setCustomUploadDir(wp_upload_dir());
            if (!empty($directory['error'])) {
                throw new RuntimeException('storage_failed');
            }
            $path = trailingslashit($directory['path']) . $name;
            $staged = ['temp' => $temp, 'local' => $path];
            $checkpoint($staged);
            if (!rename($temp, $path)) {
                throw new RuntimeException('storage_failed');
            }
            $file = ['name' => $name, 'file' => $name, 'full_path' => $path, 'size' => $size, 'type' => $mime,
                'url' => trailingslashit($directory['url']) . $name];
            // Built-in cloud drivers use this deterministic key, allowing cleanup after a worker dies in upload.
            $cloud = new CloudStorageModule();
            $driver = $cloud->getDriver();
            if ($driver) {
                $config = StorageHelper::getConfig();
                $key = empty($config['sub_folder']) ? $name : $config['sub_folder'] . '/' . $name;
                $staged['remote'] = ['driver' => $cloud->getDriverName($driver), 'file_path' => $driver->getRemotePath($key)];
                $checkpoint($staged);
            }
            $media = (new AttachmentService())->processMediaData($file, $file);
            if ($media['driver'] !== 'local') {
                $staged['remote'] = ['driver' => $media['driver'], 'file_path' => $media['file_path']];
            }
            $checkpoint($staged);
            return array_merge($file, $media);
        } finally {
            if (is_file($temp)) {
                wp_delete_file($temp);
            }
        }
    }

    /** Remove only files belonging to this attempt; remote cleanup uses the existing retry listener. */
    public function discard(array $staged, $boardId)
    {
        if (!empty($staged['temp']) && is_file($staged['temp'])) {
            wp_delete_file($staged['temp']);
        }
        if (!empty($staged['local'])) {
            $path = FileSystem::resolveLocalAttachmentPath($staged['local'], $boardId);
            if ($path) {
                wp_delete_file($path);
            }
        }
        if (!empty($staged['remote'])) {
            do_action('fluent_boards/delete_remote_attachment_file', (object) $staged['remote']);
        }
    }
}
