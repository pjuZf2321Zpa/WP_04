<?php

namespace FluentBoardsPro\App\Services;

use FluentBoards\App\Models\Activity;
use FluentBoards\App\Models\Board;
use FluentBoards\App\Models\BoardTerm;
use FluentBoards\App\Models\Comment;
use FluentBoards\App\Models\Meta;
use FluentBoards\App\Models\Relation;
use FluentBoards\App\Models\Task;
use FluentBoards\App\Models\TaskMeta;
use FluentBoards\App\Models\User;
use FluentBoards\Framework\Database\QueryException;
use FluentBoards\Framework\Support\Arr;
use FluentBoards\Framework\Support\Str;
use FluentBoards\App\Services\Constant;
use FluentBoards\App\Services\TaskService;
use FluentBoards\App\Services\CommentService;
use FluentBoards\App\Services\PermissionManager;
use FluentBoardsPro\App\Models\TaskAttachment;
use RuntimeException;
use Throwable;
use UnexpectedValueException;

class TrelloImporter
{
    const META_OBJECT_TYPE = 'trello_import';
    const ASYNC_ACTION = 'fluent_boards/process_trello_import';
    const CARD_BATCH_SIZE = 30;
    const BATCH_OBJECT_TYPE = 'trello_import_batch';
    const STORAGE_VERSION = 'db_batches_v1';
    const RECOVERY_ACTION = 'fluent_boards/recover_trello_import';
    const RECOVERY_DELAY = 600;
    const RESUMABLE_STORAGE_VERSION = 'db_batches_v2';
    const PAUSE_RETENTION = 86400;
    const RETRY_DELAYS = [5, 15, 30];
    const COVER_OBJECT_TYPE = 'trello_import_cover';
    const COVER_BATCH_SIZE = 5;
    const COVER_BATCH_SECONDS = 20;

    private static $apiFailure;


    public static function process($data, $options = [])
    {
        // Increase max execution time to 5 minutes if less than 5 minutes
        if (ini_get('max_execution_time') < 300) {
            ini_set('max_execution_time', '300');
        }

        $cards = self::normalizeCardPositions(Arr::get($data, 'cards', []));
        $subtaskGroups = Arr::get($data, 'checklists', []);
        $actions = Arr::get($data, 'actions', []);
        $context = self::createBoardImportContext($data, $options);
        $board = $context['board'];
        $actionsByCard = self::groupActionsByCard($actions);
        $checklistsByCard = self::groupChecklistsByCard($subtaskGroups);

        // Create cards
        foreach ($cards as $card) {
            $trelloCardId = (string) Arr::get($card, 'id', '');
            self::importCard(
                $board,
                $card,
                $context,
                $checklistsByCard[$trelloCardId] ?? [],
                $actionsByCard[$trelloCardId] ?? []
            );
        }
        self::updateBoardTaskCount($board->id);
        self::createBoardActivity($board, $data, $context['import_user_id']);

        return $board;
    }

    /** Preserve each list's order with integer ranks that fit the task position column. */
    private static function normalizeCardPositions($cards)
    {
        usort($cards, function ($a, $b) {
            return ((float) Arr::get($a, 'pos', 0) <=> (float) Arr::get($b, 'pos', 0))
                ?: strcmp((string) Arr::get($a, 'id', ''), (string) Arr::get($b, 'id', ''));
        });
        foreach ($cards as $index => &$card) {
            $card['pos'] = $index + 1;
        }
        unset($card);

        return $cards;
    }

    private static function createBoardImportContext($data, $options = [])
    {
        $board = self::createBoardFromTrelloData($data, $options);
        $members = Arr::get($data, 'members', []);
        $importUsers = !empty($options['import_users']);

        return [
            'board' => $board,
            'parse_down' => new Parsedown(),
            'members' => $members,
            'list_stage_mapper' => self::stageCreateAgainstList($board, Arr::get($data, 'lists', [])),
            'member_mapper' => self::createMembers($board, $members, $importUsers),
            'label_mapper' => self::labelCreate($board, Arr::get($data, 'labels', [])),
            'custom_field_mapper' => self::customFieldCreate($board, Arr::get($data, 'customFields', [])),
            'import_user_id' => absint(Arr::get($options, 'user_id', get_current_user_id())),
        ];
    }

    private static function createBoardFromTrelloData($data, $options = [])
    {
        $parseDown = new Parsedown();
        $boardName = Arr::get($data, 'name', __('Imported Trello Board', 'fluent-boards-pro'));
        $prefs = Arr::get($data, 'prefs', []);

        $boardData = [
            'title' => sanitize_text_field($boardName),
            'slug' => Str::slug($boardName),
            'description' => strip_tags($parseDown->text((string) Arr::get($data, 'desc', ''))),
            'archived_at' => Arr::get($data, 'closed') ? self::formatTrelloDate(Arr::get($data, 'dateClosed')) : null,
            'user_id' => absint(Arr::get($options, 'user_id', get_current_user_id())),
        ];

        if (empty($prefs['backgroundImage'])) {
            $boardData['background']['image'] = null;
            $boardData['background']['is_image'] = false;
            $boardData['background']['color'] = $prefs['backgroundColor'] ?? null;
        }

        return Board::create($boardData);
    }

    private static function importCard($board, $card, $context, $subtaskGroups = [], $actions = [])
    {
        $parseDown = $context['parse_down'];
        $listStageMapper = $context['list_stage_mapper'];
        $members = $context['members'];
        $memberMapper = $context['member_mapper'];
        $labelMapper = $context['label_mapper'];
        $customFieldMapper = $context['custom_field_mapper'];
        $importUserId = $context['import_user_id'];

        $taskData = [
            'title' => sanitize_text_field(Arr::get($card, 'name', __('Untitled Trello card', 'fluent-boards-pro'))),
            'source' => 'trello',
            'description' => wp_kses_post($parseDown->text((string) Arr::get($card, 'desc', ''))),
            'position' => Arr::get($card, 'pos'),
            'status' => Arr::get($card, 'dueComplete') ? 'closed' : 'open',
            'due_at' => self::formatTrelloDate(Arr::get($card, 'due')),
            'started_at' => self::formatTrelloDate(Arr::get($card, 'start')),
            'archived_at' => Arr::get($card, 'closed') ? gmdate('Y-m-d H:i:s') : null,
            'stage_id' => $listStageMapper[trim((string) Arr::get($card, 'idList'))] ?? reset($listStageMapper),
            'settings' => self::prepareTaskSettings($card, $members),
        ];

        if (Arr::get($card, 'dueComplete')) {
            $taskData['last_completed_at'] = gmdate('Y-m-d H:i:s');
        }

        $cover = self::prepareTaskCover($card);
        if ($cover) {
            $taskData['settings']['cover'] = $cover;
        }

        $task = $board->tasks()->create($taskData);
        $relatedCheckLists = Arr::get($card, 'idChecklists', []);
        $task->updateMeta('is_template', Arr::get($card, 'isTemplate') ? 'yes' : 'no');
        self::associateLabelsWithTask(Arr::get($card, 'idLabels', []), $task, $labelMapper);
        self::associateMembersWithTask(Arr::get($card, 'idMembers', []), $task, $memberMapper);
        self::associateCustomFieldsWithTask(Arr::get($card, 'customFieldItems', []), $task, $customFieldMapper);
        self::createAttachments(Arr::get($card, 'attachments', []), $task);
        self::createComments($actions, $task, $memberMapper, $parseDown, $importUserId);
        self::createCardActivities($actions, $task, $memberMapper, $importUserId);
        self::addSubtasks($subtaskGroups, $card, $task, $relatedCheckLists);

        return $task;
    }

    private static function createBoardActivity($board, $data, $importUserId)
    {
        Activity::create([
            'created_by' => $importUserId,
            'action' => 'created',
            'object_id' => $board->id,
            'object_type' => Constant::ACTIVITY_BOARD,
            'old_value' => null,
            'new_value' => Arr::get($data, 'name', __('Imported Trello Board', 'fluent-boards-pro')),
            'column' => 'board',
            'description' => 'imported from Trello <a href="' . esc_url(Arr::get($data, 'url', '')) . '" target="_blank">' . esc_html(Arr::get($data, 'url', '')) . '</a>',
        ]);
    }


    private static function addSubtasks($subtaskGroups, $card, $task, $relatedCheckLists)
    {
        $subTaskCounter  = 0;
        foreach ($subtaskGroups as $subtaskGroup) {
            if (Arr::get($subtaskGroup, 'idCard') == Arr::get($card, 'id')) {
                $subtaskGroupOfTask = self::createSubtaskGroupOfTask($task, $subtaskGroup);
                foreach (Arr::get($subtaskGroup, 'checkItems', []) as $subtask) {
                    if(in_array(Arr::get($subtask, 'idChecklist'), $relatedCheckLists)) {
                        $createdSubtask = Task::create([
                            'source' => 'trello',
                            'board_id' => $task->board_id,
                            'title' => sanitize_text_field(Arr::get($subtask, 'name', __('Untitled Trello checklist item', 'fluent-boards-pro'))),
                            'status' => Arr::get($subtask, 'state') == 'complete' ? 'closed' : 'open',
                            'due_at' => self::formatTrelloDate(Arr::get($subtask, 'due')),
                            'position' => Arr::get($subtask, 'pos'),
                            'parent_id' => $task->id,
                        ]);
                        $subTaskCounter++;

                        //adding newly created subtask to subtask group
                        TaskMeta::create([
                            'task_id' => $createdSubtask->id,
                            'key' => Constant::SUBTASK_GROUP_CHILD,
                            'value' => $subtaskGroupOfTask->id
                        ]);
                    }
                }
            }
        }
        $taskSettings = $task->settings ?? [];
        $taskSettings['subtask_count'] = $subTaskCounter;
        $task->settings = $taskSettings;
        $task->save();

    }

    private static function createSubtaskGroupOfTask($task, $subtaskGroup)
    {
        $taskMeta = TaskMeta::where('task_id', $task->id)
            ->where('key', Constant::SUBTASK_GROUP_NAME)
            ->where('value', Arr::get($subtaskGroup, 'name', __('Trello Checklist', 'fluent-boards-pro')))
            ->first();
        if (!$taskMeta) {
            return TaskMeta::create([
                'task_id' => $task->id,
                'key' => Constant::SUBTASK_GROUP_NAME,
                'value' => Arr::get($subtaskGroup, 'name', __('Trello Checklist', 'fluent-boards-pro'))
            ]);
        }

        return $taskMeta;
    }

    private static function updateBoardTaskCount($boardId)
    {
        $board = Board::find($boardId);
        $settings = $board->settings ?? [];
        $settings['tasks_count'] = $board->tasks()->where('parent_id', null)->count();
        $board->settings = $settings;
        $board->save();
    }

    private static function associateLabelsWithTask($taskAssociatedLabels, $task, $labelMapper)
    {
        foreach ($taskAssociatedLabels as $label) {
            if (!isset($labelMapper[$label])) {
                continue;
            }
            Relation::create([
                'object_id'   =>  $task->id,
                'object_type' => \FluentBoards\App\Services\Constant::OBJECT_TYPE_TASK_LABEL,
                'foreign_id'   =>  $labelMapper[$label]
            ]);
        }
    }

    private static function stageCreateAgainstList($board, $stages)
    {
        $listStageMapper = [];
        foreach ($stages as $stage) {
            $trelloStageId = trim((string) Arr::get($stage, 'id', ''));
            if (!$trelloStageId) {
                continue;
            }

            $newStage = $board->stages()->create([
                'title' => sanitize_text_field(Arr::get($stage, 'name', __('Untitled Trello list', 'fluent-boards-pro'))),
                'slug' => Str::slug(Arr::get($stage, 'name', $trelloStageId)),
                'type' => 'stage',
                'archived_at' => Arr::get($stage, 'closed') ? gmdate('Y-m-d H:i:s') : null,
                'position' => Arr::get($stage, 'pos'),
            ]);
            $listStageMapper[$trelloStageId] = $newStage->id;
        }
        return $listStageMapper;
    }

    private static function createMembers($board, $members, $createMissingUsers = false)
    {
        $memberMapper = [];

        foreach ($members as $member) {
            $email = sanitize_email(Arr::get($member, 'email', ''));
            $trelloMemberId = trim((string) Arr::get($member, 'id', ''));

            if (!$trelloMemberId) {
                continue;
            }

            $boardMember = $email ? User::where('user_email', $email)->first() : null;
            if (!$boardMember) {
                $boardMember = self::findUserByTrelloMemberId($trelloMemberId);
            }
            if (!$boardMember && $createMissingUsers) {
                $boardMember = self::createWordPressUserFromTrelloMember($member, $email, $trelloMemberId);
            }

            if (!$boardMember) {
                continue;
            }

            $memberMapper[$trelloMemberId] = (int) $boardMember->ID;

            $exists = Relation::where('object_id', $board->id)
                ->where('foreign_id', $boardMember->ID)
                ->where('object_type', Constant::OBJECT_TYPE_BOARD_USER)
                ->first();

            if ($exists) {
                continue;
            }

            $board->users()->attach(
                $boardMember->ID,
                [
                    'object_type' => Constant::OBJECT_TYPE_BOARD_USER,
                    'settings'    => maybe_serialize(Constant::BOARD_USER_SETTINGS),
                    'preferences' => maybe_serialize(Constant::BOARD_NOTIFICATION_TYPES)
                ]
            );
        }

        return $memberMapper;
    }

    private static function findUserByTrelloMemberId($trelloMemberId)
    {
        $userIds = get_users([
            'fields' => 'ID',
            'meta_key' => '_fluent_boards_trello_member_id',
            'meta_value' => $trelloMemberId,
            'number' => 1,
        ]);

        if (!$userIds) {
            return null;
        }

        return User::find((int) $userIds[0]);
    }

    private static function createWordPressUserFromTrelloMember($member, $email, $trelloMemberId)
    {
        $email = $email ?: self::placeholderEmailForTrelloMember($trelloMemberId);
        if (!is_email($email)) {
            return null;
        }

        $displayName = sanitize_text_field(Arr::get($member, 'fullName', Arr::get($member, 'username', $email)));
        $login = self::uniqueUserLoginFromMember($member, $email, $trelloMemberId);
        $nameParts = preg_split('/\s+/', trim($displayName), 2);

        $userId = wp_insert_user([
            'user_login' => $login,
            'user_pass' => wp_generate_password(24, true),
            'user_email' => $email,
            'display_name' => $displayName ?: $email,
            'first_name' => sanitize_text_field($nameParts[0] ?? ''),
            'last_name' => sanitize_text_field($nameParts[1] ?? ''),
            'role' => 'subscriber',
        ]);

        if (is_wp_error($userId)) {
            return null;
        }

        update_user_meta($userId, '_fluent_boards_trello_member_id', $trelloMemberId);
        update_user_meta($userId, '_fluent_boards_trello_imported_user', 'yes');

        return User::find($userId);
    }

    private static function placeholderEmailForTrelloMember($trelloMemberId)
    {
        $memberKey = sanitize_key($trelloMemberId);

        return 'trello-' . $memberKey . '@trello.local';
    }

    private static function uniqueUserLoginFromMember($member, $email, $trelloMemberId)
    {
        $username = Arr::get($member, 'username', '');
        $emailParts = explode('@', $email);
        $emailPrefix = $emailParts[0] ?? '';
        $baseLogin = sanitize_user($username ?: $emailPrefix, true);

        if (!$baseLogin) {
            $baseLogin = 'trello-' . sanitize_key($trelloMemberId);
        }

        $login = $baseLogin;
        $suffix = 1;

        while (username_exists($login)) {
            $login = $baseLogin . '-' . $suffix;
            $suffix++;
        }

        return $login;
    }

    private static function labelCreate($board, $labels)
    {
        $labelMapper = [];
        foreach ($labels as $label) {
            $trelloLabelId = trim((string) Arr::get($label, 'id', ''));
            if (!$trelloLabelId) {
                continue;
            }

            $color = Arr::get($label, 'color') ?: 'blue';
            $newLabel = $board->labels()->create([
                'title' => sanitize_text_field(Arr::get($label, 'name', '') ?: __('Untitled Trello label', 'fluent-boards-pro')),
                'slug' => sanitize_text_field($color),
                'color' => Constant::TEXT_COLOR_MAP[$color] ?? '#1B2533',
                'bg_color' => Constant::TRELLO_COLOR_MAP[$color] ?? Constant::TRELLO_COLOR_MAP['blue'],
            ]);
            $labelMapper[$trelloLabelId] = $newLabel->id;
        }
        return $labelMapper;
    }

    private static function customFieldCreate($board, $customFields)
    {
        $customFieldMapper = [];

        foreach ($customFields as $customField) {
            $trelloFieldId = trim((string) Arr::get($customField, 'id', ''));
            if (!$trelloFieldId) {
                continue;
            }

            $type = self::mapCustomFieldType(Arr::get($customField, 'type'));
            $optionMapper = self::mapCustomFieldOptions(Arr::get($customField, 'options', []));

            $newCustomField = $board->customFields()->create([
                'title' => sanitize_text_field(Arr::get($customField, 'name', __('Trello Custom Field', 'fluent-boards-pro'))),
                'slug' => Str::slug(Arr::get($customField, 'name', $trelloFieldId)),
                'type' => 'custom-field',
                'position' => (int) Arr::get($customField, 'pos', 1),
                'settings' => [
                    'custom_field_type' => $type,
                    'select_options' => array_values($optionMapper),
                    'trello' => [
                        'id' => $trelloFieldId,
                        'type' => Arr::get($customField, 'type'),
                    ],
                ],
            ]);

            $customFieldMapper[$trelloFieldId] = [
                'id' => $newCustomField->id,
                'type' => $type,
                'options' => $optionMapper,
            ];
        }

        return $customFieldMapper;
    }

    private static function mapCustomFieldType($trelloType)
    {
        $types = [
            'text' => 'text',
            'number' => 'number',
            'date' => 'date',
            'checkbox' => 'checkbox',
            'list' => 'select',
        ];

        return $types[$trelloType] ?? 'text';
    }

    private static function mapCustomFieldOptions($options)
    {
        $optionMapper = [];

        foreach ($options as $option) {
            $optionId = trim((string) Arr::get($option, 'id', ''));
            if (!$optionId) {
                continue;
            }

            $optionMapper[$optionId] = sanitize_text_field(Arr::get($option, 'value.text', ''));
        }

        return array_filter($optionMapper, function ($value) {
            return $value !== '';
        });
    }

    private static function associateMembersWithTask($trelloMemberIds, $task, $memberMapper)
    {
        foreach ($trelloMemberIds as $trelloMemberId) {
            $trelloMemberId = trim((string) $trelloMemberId);
            if (empty($memberMapper[$trelloMemberId])) {
                continue;
            }

            $exists = Relation::where('object_id', $task->id)
                ->where('foreign_id', $memberMapper[$trelloMemberId])
                ->where('object_type', Constant::OBJECT_TYPE_TASK_ASSIGNEE)
                ->first();

            if ($exists) {
                continue;
            }

            Relation::create([
                'object_id' => $task->id,
                'object_type' => Constant::OBJECT_TYPE_TASK_ASSIGNEE,
                'foreign_id' => $memberMapper[$trelloMemberId],
            ]);
        }
    }

    private static function associateCustomFieldsWithTask($customFieldItems, $task, $customFieldMapper)
    {
        foreach ($customFieldItems as $customFieldItem) {
            $trelloFieldId = trim((string) Arr::get($customFieldItem, 'idCustomField', ''));
            if (!$trelloFieldId || empty($customFieldMapper[$trelloFieldId])) {
                continue;
            }

            $mappedField = $customFieldMapper[$trelloFieldId];
            $value = self::extractCustomFieldValue($customFieldItem, $mappedField);

            if ($value === null || $value === '') {
                continue;
            }

            Relation::create([
                'object_id' => $task->id,
                'object_type' => \FluentBoardsPro\App\Services\Constant::TASK_CUSTOM_FIELD,
                'foreign_id' => $mappedField['id'],
                'settings' => [
                    'value' => $value,
                    'trello' => [
                        'idCustomField' => $trelloFieldId,
                        'idValue' => Arr::get($customFieldItem, 'idValue'),
                    ],
                ],
            ]);
        }
    }

    private static function extractCustomFieldValue($customFieldItem, $mappedField)
    {
        if (!empty($customFieldItem['idValue'])) {
            return $mappedField['options'][$customFieldItem['idValue']] ?? null;
        }

        $value = Arr::get($customFieldItem, 'value', []);

        if (isset($value['checked'])) {
            return $value['checked'] === 'true';
        }

        if (isset($value['date'])) {
            return self::formatTrelloDate($value['date']);
        }

        if (isset($value['number'])) {
            return sanitize_text_field($value['number']);
        }

        if (isset($value['text'])) {
            return sanitize_text_field($value['text']);
        }

        return null;
    }

    private static function createAttachments($attachments, $task)
    {
        $attachmentCount = 0;

        foreach ($attachments as $attachment) {
            $url = esc_url_raw(Arr::get($attachment, 'url'));
            if (!$url) {
                continue;
            }

            $taskAttachment = new TaskAttachment();
            $taskAttachment->object_id = $task->id;
            $taskAttachment->object_type = Constant::TASK_ATTACHMENT;
            $taskAttachment->attachment_type = 'url';
            $taskAttachment->title = sanitize_text_field(Arr::get($attachment, 'name', __('Trello attachment', 'fluent-boards-pro')));
            $taskAttachment->file_path = null;
            $taskAttachment->full_url = $url;
            $taskAttachment->file_size = Arr::get($attachment, 'bytes') ? absint(Arr::get($attachment, 'bytes')) : null;
            $taskAttachment->driver = 'trello';
            $taskAttachment->settings = [
                'trello' => [
                    'id' => Arr::get($attachment, 'id'),
                    'date' => Arr::get($attachment, 'date'),
                    'mimeType' => Arr::get($attachment, 'mimeType'),
                    'isUpload' => Arr::get($attachment, 'isUpload'),
                ],
            ];
            $taskAttachment->save();
            $attachmentCount++;
        }

        if (!$attachmentCount) {
            return;
        }

        $settings = $task->settings ?? [];
        $settings['attachment_count'] = (int) ($settings['attachment_count'] ?? 0) + $attachmentCount;
        $task->settings = $settings;
        $task->save();
    }

    private static function createComments($actions, $task, $memberMapper, $parseDown, $importUserId = null)
    {
        foreach ($actions as $action) {
            if (Arr::get($action, 'type') !== 'commentCard') {
                continue;
            }

            $description = trim((string) Arr::get($action, 'data.text', ''));
            if ($description === '') {
                continue;
            }

            $memberId = Arr::get($action, 'idMemberCreator');
            $creatorId = $memberMapper[$memberId] ?? absint($importUserId ?: get_current_user_id());
            $member = Arr::get($action, 'memberCreator', []);
            $authorName = sanitize_text_field(Arr::get($member, 'fullName', Arr::get($member, 'username', __('Trello user', 'fluent-boards-pro'))));
            $comment = Comment::create([
                'task_id' => $task->id,
                'board_id' => $task->board_id,
                'description' => wp_kses_post($parseDown->text($description)),
                'type' => 'comment',
                'privacy' => 'private',
                'status' => 'published',
                'author_name' => $authorName,
                'author_email' => self::trelloAuthorEmail($member),
                'author_ip' => '',
                'created_by' => $creatorId,
                'settings' => [
                    'trello' => [
                        'action_id' => Arr::get($action, 'id'),
                        'member_id' => $memberId,
                        'username' => Arr::get($member, 'username'),
                    ],
                ],
            ]);

            self::setModelDates($comment, Arr::get($action, 'date'));
        }
    }

    private static function createCardActivities($actions, $task, $memberMapper, $importUserId = null)
    {
        foreach ($actions as $action) {
            $type = Arr::get($action, 'type');
            if ($type === 'commentCard') {
                continue;
            }

            $description = self::describeAction($action);
            if (!$description) {
                continue;
            }

            $memberId = Arr::get($action, 'idMemberCreator');
            $activity = Activity::create([
                'created_by' => $memberMapper[$memberId] ?? absint($importUserId ?: get_current_user_id()),
                'action' => sanitize_text_field($type),
                'object_id' => $task->id,
                'object_type' => Constant::ACTIVITY_TASK,
                'old_value' => null,
                'new_value' => null,
                'column' => 'trello',
                'description' => wp_kses_post($description),
                'settings' => [
                    'trello' => [
                        'action_id' => Arr::get($action, 'id'),
                        'type' => $type,
                        'data' => Arr::get($action, 'data', []),
                    ],
                ],
            ]);

            self::setModelDates($activity, Arr::get($action, 'date'));
        }
    }

    private static function describeAction($action)
    {
        $type = Arr::get($action, 'type');
        $memberName = esc_html(Arr::get($action, 'memberCreator.fullName', Arr::get($action, 'memberCreator.username', __('A Trello member', 'fluent-boards-pro'))));

        if ($type === 'addAttachmentToCard') {
            return sprintf(
                /* translators: %1$s is the Trello member's name, %2$s is the attachment name */
                __('%1$s added Trello attachment %2$s', 'fluent-boards-pro'),
                $memberName,
                esc_html(Arr::get($action, 'data.attachment.name', __('Untitled attachment', 'fluent-boards-pro')))
            );
        }

        if ($type === 'deleteAttachmentFromCard') {
            return sprintf(
                /* translators: %1$s is the Trello member's name, %2$s is the attachment name */
                __('%1$s removed Trello attachment %2$s', 'fluent-boards-pro'),
                $memberName,
                esc_html(Arr::get($action, 'data.attachment.name', __('Untitled attachment', 'fluent-boards-pro')))
            );
        }

        if ($type === 'addMemberToCard' || $type === 'removeMemberFromCard') {
            $targetName = esc_html(Arr::get($action, 'data.member.name', Arr::get($action, 'data.member.username', __('a member', 'fluent-boards-pro'))));
            return sprintf(
                $type === 'addMemberToCard'
                    /* translators: %1$s is the Trello member's name, %2$s is the member added */
                    ? __('%1$s added %2$s to this Trello card', 'fluent-boards-pro')
                    /* translators: %1$s is the Trello member's name, %2$s is the member removed */
                    : __('%1$s removed %2$s from this Trello card', 'fluent-boards-pro'),
                $memberName,
                $targetName
            );
        }

        if ($type === 'addLabelToCard' || $type === 'removeLabelFromCard') {
            $labelName = esc_html(Arr::get($action, 'data.label.name', Arr::get($action, 'data.label.color', __('a label', 'fluent-boards-pro'))));
            return sprintf(
                $type === 'addLabelToCard'
                    /* translators: %1$s is the Trello member's name, %2$s is the label name */
                    ? __('%1$s added Trello label %2$s', 'fluent-boards-pro')
                    /* translators: %1$s is the Trello member's name, %2$s is the label name */
                    : __('%1$s removed Trello label %2$s', 'fluent-boards-pro'),
                $memberName,
                $labelName
            );
        }

        if ($type === 'updateCard') {
            return self::describeCardUpdate($action, $memberName);
        }

        return null;
    }

    private static function describeCardUpdate($action, $memberName)
    {
        $old = Arr::get($action, 'data.old', []);

        if (isset($old['idList'])) {
            return sprintf(
                /* translators: %1$s is the Trello member's name, %2$s is the previous list, %3$s is the new list */
                __('%1$s moved this Trello card from %2$s to %3$s', 'fluent-boards-pro'),
                $memberName,
                esc_html(Arr::get($action, 'data.listBefore.name', __('another list', 'fluent-boards-pro'))),
                esc_html(Arr::get($action, 'data.listAfter.name', __('another list', 'fluent-boards-pro')))
            );
        }

        if (isset($old['due'])) {
            /* translators: %s is the Trello member's name */
            return sprintf(__('%s changed the Trello due date', 'fluent-boards-pro'), $memberName);
        }

        if (isset($old['name'])) {
            /* translators: %s is the Trello member's name */
            return sprintf(__('%s renamed this Trello card', 'fluent-boards-pro'), $memberName);
        }

        if (isset($old['desc'])) {
            /* translators: %s is the Trello member's name */
            return sprintf(__('%s changed this Trello card description', 'fluent-boards-pro'), $memberName);
        }

        if (isset($old['closed'])) {
            /* translators: %s is the Trello member's name */
            return sprintf(__('%s changed this Trello card archive state', 'fluent-boards-pro'), $memberName);
        }

        return null;
    }

    private static function prepareTaskSettings($card, $members)
    {
        $settings = [
            'trello' => [
                'card_id' => Arr::get($card, 'id'),
                'url' => Arr::get($card, 'url'),
                'short_url' => Arr::get($card, 'shortUrl'),
                'id_short' => Arr::get($card, 'idShort'),
                'subscribed' => Arr::get($card, 'subscribed'),
                'id_members' => Arr::get($card, 'idMembers', []),
                'id_members_voted' => Arr::get($card, 'idMembersVoted', []),
                'members' => self::summarizeCardMembers(Arr::get($card, 'idMembers', []), $members),
                'stickers' => Arr::get($card, 'stickers', []),
                'badges' => Arr::get($card, 'badges', []),
            ],
        ];

        return $settings;
    }

    private static function prepareTaskCover($card)
    {
        $cover = [];
        $coverColor = Arr::get($card, 'cover.color');
        $coverImage = self::extractCoverImageUrl($card);

        if ($coverColor && isset(Constant::TRELLO_COLOR_MAP[$coverColor])) {
            $cover['backgroundColor'] = Constant::TRELLO_COLOR_MAP[$coverColor];
        }

        if ($coverImage) {
            $cover['backgroundImage'] = $coverImage;
        }

        return $cover;
    }

    private static function extractCoverImageUrl($card)
    {
        $scaled = Arr::get($card, 'cover.scaled', []);
        if (is_array($scaled) && $scaled) {
            usort($scaled, function ($first, $second) {
                return (int) Arr::get($second, 'width', 0) <=> (int) Arr::get($first, 'width', 0);
            });

            foreach ($scaled as $image) {
                $url = esc_url_raw(Arr::get($image, 'url'));
                if ($url) {
                    return $url;
                }
            }
        }

        $coverAttachmentId = Arr::get($card, 'cover.idAttachment');
        if (!$coverAttachmentId) {
            return null;
        }

        foreach (Arr::get($card, 'attachments', []) as $attachment) {
            if (Arr::get($attachment, 'id') !== $coverAttachmentId) {
                continue;
            }

            $previews = Arr::get($attachment, 'previews', []);
            if (is_array($previews) && $previews) {
                usort($previews, function ($first, $second) {
                    return (int) Arr::get($second, 'width', 0) <=> (int) Arr::get($first, 'width', 0);
                });

                foreach ($previews as $preview) {
                    $url = esc_url_raw(Arr::get($preview, 'url'));
                    if ($url) {
                        return $url;
                    }
                }
            }

            return esc_url_raw(Arr::get($attachment, 'url')) ?: null;
        }

        return null;
    }

    private static function trelloAuthorEmail($member)
    {
        $email = sanitize_email(Arr::get($member, 'email', ''));
        if ($email) {
            return $email;
        }

        $username = sanitize_user(Arr::get($member, 'username', 'trello-user'), true);
        return sanitize_email($username . '@trello.local');
    }

    private static function summarizeCardMembers($memberIds, $members)
    {
        $membersById = [];
        foreach ($members as $member) {
            $membersById[Arr::get($member, 'id')] = $member;
        }

        $summary = [];
        foreach ($memberIds as $memberId) {
            $member = $membersById[$memberId] ?? [];
            $summary[] = [
                'id' => $memberId,
                'fullName' => Arr::get($member, 'fullName'),
                'username' => Arr::get($member, 'username'),
                'email' => Arr::get($member, 'email'),
            ];
        }

        return $summary;
    }

    private static function groupActionsByCard($actions)
    {
        $grouped = [];

        foreach ($actions as $action) {
            $cardId = Arr::get($action, 'data.card.id');
            if (!$cardId) {
                continue;
            }

            if (!isset($grouped[$cardId])) {
                $grouped[$cardId] = [];
            }

            $grouped[$cardId][] = $action;
        }

        return $grouped;
    }

    private static function groupChecklistsByCard($checklists)
    {
        $grouped = [];

        foreach ($checklists as $checklist) {
            $cardId = Arr::get($checklist, 'idCard');
            if (!$cardId) {
                continue;
            }

            if (!isset($grouped[$cardId])) {
                $grouped[$cardId] = [];
            }

            $grouped[$cardId][] = $checklist;
        }

        return $grouped;
    }

    private static function setModelDates($model, $trelloDate)
    {
        $date = self::formatTrelloDate($trelloDate);
        if (!$date) {
            return;
        }

        $model->created_at = $date;
        $model->updated_at = $date;
        $model->save();
    }

    private static function formatTrelloDate($date)
    {
        if (!$date) {
            return null;
        }

        $timestamp = strtotime($date);
        if (!$timestamp) {
            return null;
        }

        return gmdate('Y-m-d H:i:s', $timestamp);
    }


    private static $apiBaseUrl = 'https://api.trello.com/1';

    /**
     * @param string $apiKey  Trello API key (from https://trello.com/power-ups/admin)
     * @param string $token   Trello user token (generated via the API key page)
     * @return array          List of boards [{id, name, url}, ...] or ['error' => message]
     */
    public static function fetchBoards($apiKey, $token)
    {
        $url = self::$apiBaseUrl . '/members/me/boards?' . http_build_query([
            'key'    => $apiKey,
            'token'  => $token,
            'fields' => 'name,url,closed',
            'filter' => 'open',
        ]);

        $response = self::apiGet($url);

        if (isset($response['error'])) {
            return $response;
        }

        return $response;
    }

    /** Create a pollable session and schedule recovery before starting background work. */
    public static function startAsyncImport($apiKey, $token, $trelloBoardId, $options = [])
    {
        if (!function_exists('as_enqueue_async_action') || !function_exists('as_schedule_single_action')) {
            return ['error' => __('Background imports are not available on this site.', 'fluent-boards-pro')];
        }

        $importId = function_exists('wp_generate_uuid4') ? wp_generate_uuid4() : uniqid('trello_', true);
        $userId = absint(Arr::get($options, 'user_id', get_current_user_id()));
        $session = [
            'import_id' => $importId,
            'storage_version' => self::RESUMABLE_STORAGE_VERSION,
            'cover_version' => 1,
            'user_id' => $userId,
            'status' => 'queued',
            'phase' => 'queued',
            'message' => __('Preparing Trello import...', 'fluent-boards-pro'),
            'percentage' => 0,
            'completed' => 0,
            'total' => 0,
            'board_id' => null,
            'current_page' => 1,
            'total_pages' => 0,
            'batch_size' => self::CARD_BATCH_SIZE,
            'api_key' => $apiKey,
            'token' => $token,
            'trello_board_id' => $trelloBoardId,
            'import_users' => !empty($options['import_users']),
            'created_at' => gmdate('Y-m-d H:i:s'),
            'updated_at' => gmdate('Y-m-d H:i:s'),
        ];

        $meta = Meta::create([
            'object_id' => $userId,
            'object_type' => self::META_OBJECT_TYPE,
            'key' => self::sessionKey($importId),
            'value' => $session,
        ]);

        try {
            self::ensureRecovery($importId);
            // A failed immediate dispatch is recoverable from the queued session.
            self::enqueueAsyncImport($importId);
        } catch (Throwable $e) {
            self::markSessionFailed($meta, $meta->value, __('Could not schedule the Trello import.', 'fluent-boards-pro'));
        }

        return self::publicStatus($meta->value);
    }

    /** Read owner-scoped progress, including committed cards in the current batch. */
    public static function getImportStatus($importId, $userId = null)
    {
        $meta = self::getSessionMeta($importId);
        if (!$meta) {
            return ['error' => __('Trello import session was not found.', 'fluent-boards-pro'), 'http_status' => 404];
        }

        $session = $meta->value;
        if ($userId !== null && absint(Arr::get($session, 'user_id')) !== absint($userId)) {
            return ['error' => __('You do not have access to this Trello import session.', 'fluent-boards-pro'), 'http_status' => 403];
        }

        if (!empty($session['cover_retry']) && (int) Arr::get($session, 'cover_expires_at') <= time()) {
            self::runAsyncImport($importId, true, $session['cover_run']);
            $meta = self::getSessionMeta($importId);
            $session = $meta->value;
        }
        if (!empty($session['board_id']) && !Board::where('id', $session['board_id'])->exists()) {
            return ['error' => __('The imported board no longer exists.', 'fluent-boards-pro'), 'http_status' => 404];
        }
        return self::publicStatus($session, $meta->id);
    }

    /** Process at most one batch under a database-owned, per-import lock. */
    public static function processAsyncImport($importId, $coverRun = null)
    {
        self::runAsyncImport($importId, false, $coverRun);
    }

    /** Recover queue gaps or fail an interrupted mutation without replaying its side effects. */
    public static function recoverAsyncImport($importId, $coverRun = null)
    {
        self::runAsyncImport($importId, true, $coverRun);
    }

    /** Keep recovery and normal workers on the same locked state machine. */
    private static function runAsyncImport($importId, $recover = false, $coverRun = null)
    {
        global $wpdb;
        if (ini_get('max_execution_time') < 300) {
            @ini_set('max_execution_time', '300');
        }

        $lockName = self::importLockName($importId);
        $locked = (string) $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 0)', $lockName)) === '1';
        if (!$locked) {
            // Do not treat a live worker as interrupted, even if its API calls are slow.
            self::ensureRecovery($importId, $recover, 60, $coverRun);
            return;
        }

        // The advisory lock belongs to this connection, including nontransactional checkpoints.
        $reconnectRetries = $wpdb->reconnect_retries;
        $wpdb->reconnect_retries = 0;
        $retryCleanup = false;
        self::$apiFailure = null;
        try {
            $meta = self::getSessionMeta($importId);
            if (!$meta) {
                return;
            }
            $session = $meta->value;
            if ($coverRun !== null && (empty($session['cover_retry']) || $coverRun !== Arr::get($session, 'cover_run'))) {
                return;
            }
            if (!empty($session['cover_retry'])) {
                if ($coverRun !== $session['cover_run']) {
                    return;
                }
                // Expired credentials must be removable even when Action Scheduler is unavailable.
                if ((int) Arr::get($session, 'cover_expires_at') > time()) {
                    self::ensureRecovery($importId, $recover, self::RECOVERY_DELAY, $coverRun);
                }
                self::processCoverBatch($meta, $session);
                return;
            }
            if (in_array(Arr::get($session, 'status'), ['completed', 'failed'], true) && empty($session['cleanup_pending'])) {
                return;
            }
            if (in_array(Arr::get($session, 'status'), ['completed', 'failed'], true)) {
                try {
                    self::ensureRecovery($importId, $recover);
                } catch (Throwable $e) {
                    // Still attempt cleanup; dispatch a fallback only if cleanup also fails.
                    $retryCleanup = true;
                }
                self::cleanupAsyncImport($meta, $session);
                $retryCleanup = false;
                return;
            }
            if (self::isResumable($session)) {
                if (Arr::get($session, 'status') === 'paused') {
                    if ((int) Arr::get($session, 'expires_at') <= time()) {
                        self::markSessionFailed($meta, $session, __('The paused Trello import has expired.', 'fluent-boards-pro'));
                    } else {
                        self::ensureRecovery($importId, $recover, $session['expires_at'] - time());
                    }
                    return;
                }
                if ((int) Arr::get($session, 'retry_at') > time()) {
                    self::ensureRecovery($importId, $recover, $session['retry_at'] - time());
                    return;
                }
            }
            // A recovery action cannot rely on itself as the next pending watchdog.
            self::ensureRecovery($importId, $recover);
            if (!self::isResumable($session) && in_array(Arr::get($session, 'processing_state'), ['initializing', 'processing', 'finalizing'], true)) {
                throw new RuntimeException(__('The Trello import was interrupted. The board may be partially imported. Restart the import.', 'fluent-boards-pro'));
            }
            if (Arr::get($session, 'status') === 'queued') {
                if (self::isResumable($session)) {
                    self::assertTransactionalTables($session);
                }
                $session = self::initializeAsyncImport($meta, $session);
            }
            if (Arr::get($session, 'status') === 'running') {
                if (Arr::get($session, 'phase') === 'covers') {
                    self::processCoverBatch($meta, $session);
                } else {
                    self::processAsyncCardBatch($meta, $session);
                }
            }
        } catch (Throwable $e) {
            // Reload: a checkpoint/terminal write may have succeeded before cleanup failed.
            if (self::ownsImportLock($importId)) {
                $meta = self::getSessionMeta($importId);
                if ($meta && (Arr::get($meta->value, 'phase') === 'covers' || !empty($meta->value['cover_retry']))) {
                    // Durable cover checkpoints recover independently; never pause/retry the card import.
                    return;
                }
                if ($meta && !in_array(Arr::get($meta->value, 'status'), ['completed', 'failed'], true)) {
                    $message = $e instanceof QueryException
                        ? __('Could not save the Trello import. Please restart the import.', 'fluent-boards-pro')
                        : $e->getMessage();
                    if (self::isResumable($meta->value) && !($e instanceof UnexpectedValueException)
                        && (!self::$apiFailure || self::$apiFailure['retryable'])) {
                        self::pauseOrRetry($meta, $meta->value);
                    } else {
                        self::markSessionFailed($meta, $meta->value, $message);
                    }
                }
            }
            // Existing recovery remains scheduled if persistence/cleanup is unavailable.
        } finally {
            $wpdb->reconnect_retries = $reconnectRetries;
            $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lockName));
            if ($retryCleanup) {
                self::enqueueAsyncImport($importId);
            }
        }
    }

    /** Scope the advisory lock to this database, site and import (under MySQL's 64-byte limit). */
    private static function importLockName($importId)
    {
        global $wpdb;
        return 'fbs_trello_' . md5(DB_NAME . '|' . $wpdb->prefix . '|' . sanitize_key($importId));
    }

    /** Reconnection must not allow a worker to continue after losing its lock. */
    private static function ownsImportLock($importId)
    {
        global $wpdb;
        return (string) $wpdb->get_var($wpdb->prepare(
            'SELECT IS_USED_LOCK(%s) = CONNECTION_ID()', self::importLockName($importId)
        )) === '1';
    }

    /** Check ownership after network calls and before mutations/checkpoints. */
    private static function assertImportLock($importId)
    {
        if (!self::ownsImportLock($importId)) {
            throw new RuntimeException(__('The Trello import worker lost its database lock.', 'fluent-boards-pro'));
        }
    }

    /** Schedule a successor even when the current recovery action is still running. */
    private static function ensureRecovery($importId, $force = false, $delay = self::RECOVERY_DELAY, $coverRun = null)
    {
        $args = $coverRun === null ? [$importId] : [$importId, $coverRun];
        if (!$force && as_has_scheduled_action(self::RECOVERY_ACTION, $args, 'fluent-boards')) {
            return;
        }
        if (!as_schedule_single_action(time() + $delay, self::RECOVERY_ACTION, $args, 'fluent-boards')) {
            throw new RuntimeException(__('Could not schedule Trello import recovery.', 'fluent-boards-pro'));
        }
    }

    /** Recovery already covers queue errors, including exceptions after a saved checkpoint. */
    private static function enqueueAsyncImport($importId, $coverRun = null)
    {
        try {
            return (bool) as_enqueue_async_action(self::ASYNC_ACTION, $coverRun === null ? [$importId] : [$importId, $coverRun], 'fluent-boards');
        } catch (Throwable $e) {
            return false;
        }
    }

    /** Fetch the board once and publish a linked list of bounded database batches. */
    private static function initializeAsyncImport($meta, $session)
    {
        self::touchSession($meta, array_merge($session, [
            'status' => self::isResumable($session) ? 'queued' : 'running',
            'phase' => 'fetching',
            'processing_state' => 'initializing',
            'message' => __('Fetching Trello board data...', 'fluent-boards-pro'),
            'percentage' => 5,
        ]));

        $apiKey = Arr::get($session, 'api_key');
        $token = Arr::get($session, 'token');
        $authQuery = 'key=' . urlencode($apiKey) . '&token=' . urlencode($token);
        $base = self::$apiBaseUrl . '/boards/' . urlencode(Arr::get($session, 'trello_board_id'));

        $board = self::apiGet($base . '?' . $authQuery . '&fields=name,desc,url,closed,dateClosed,prefs');
        self::throwIfApiError($board);

        $lists = self::apiGet($base . '/lists?' . $authQuery . '&fields=name,pos,closed');
        self::throwIfApiError($lists);

        $labels = self::apiGet($base . '/labels?' . $authQuery . '&fields=name,color');
        self::throwIfApiError($labels);

        $checklists = self::apiGet($base . '/checklists?' . $authQuery . '&fields=name,idCard&checkItems=all');
        self::throwIfApiError($checklists);

        $members = self::apiGetOptional($base . '/members?' . $authQuery . '&fields=fullName,username,initials,avatarUrl,email', self::isResumable($session));
        $currentMember = self::apiGetOptional(self::$apiBaseUrl . '/members/me?' . $authQuery . '&fields=id,fullName,username,initials,avatarUrl,email', self::isResumable($session));
        $members = self::mergeCurrentMemberEmail($members, $currentMember);
        $customFields = self::apiGetOptional($base . '/customFields?' . $authQuery, self::isResumable($session));

        $cards = self::apiGet($base . '/cards?' . $authQuery . '&fields=id,pos');
        self::throwIfApiError($cards);
        self::validateCardIds(array_column($cards, 'id'), count($cards));
        $cards = self::normalizeCardPositions($cards);

        $board['lists'] = $lists;
        $board['labels'] = $labels;
        $board['checklists'] = $checklists;
        $board['members'] = $members;
        $board['customFields'] = $customFields;

        $cardIds = array_map(function ($card) {
            $id = Arr::get($card, 'id');
            return is_string($id) ? sanitize_text_field($id) : null;
        }, $cards);
        self::validateCardIds($cardIds, count($cards));
        $cardIds = array_values($cardIds);
        $totalCards = count($cardIds);
        $batchSize = self::CARD_BATCH_SIZE;
        $totalPages = (int) ceil($totalCards / $batchSize);

        $publish = function () use ($meta, $session, $board, $checklists, $cardIds, $totalCards, $batchSize, $totalPages) {
            self::assertImportLock($session['import_id']);
            $context = self::createBoardImportContext($board, [
                'import_users' => !empty($session['import_users']),
                'user_id' => absint(Arr::get($session, 'user_id')),
            ]);
            // Keep the partial board discoverable if staging later fails.
            self::assertImportLock($session['import_id']);
            $session = array_merge($meta->value, ['board_id' => $context['board']->id]);
            self::touchSession($meta, $session);
            $nextBatchId = null;
            for ($page = $totalPages; $page >= 1; $page--) {
                self::assertImportLock($session['import_id']);
                $batch = Meta::create([
                    'object_id' => $meta->id,
                    'object_type' => self::BATCH_OBJECT_TYPE,
                    'key' => 'page_' . $page,
                    'value' => [
                        'version' => self::isResumable($session) ? 2 : 1,
                        'completed_cards' => [],
                        'page' => $page,
                        'card_ids' => array_slice($cardIds, ($page - 1) * $batchSize, $batchSize),
                        'next_batch_id' => $nextBatchId,
                    ],
                ]);
                if (!$batch->id) {
                    throw new RuntimeException(__('Could not save the Trello import batch.', 'fluent-boards-pro'));
                }
                $nextBatchId = (int) $batch->id;
            }

            $session = array_merge($session, [
                'status' => 'running',
                'phase' => 'cards',
                'message' => __('Importing Trello cards...', 'fluent-boards-pro'),
                'percentage' => $totalCards ? 15 : 95,
                'completed' => 0,
                'total' => $totalCards,
                'current_page' => 1,
                'total_pages' => $totalPages,
                'board_id' => $context['board']->id,
                'board_data' => [
                    'name' => Arr::get($board, 'name'),
                    'url' => Arr::get($board, 'url'),
                ],
                'storage_version' => self::isResumable($session) ? self::RESUMABLE_STORAGE_VERSION : self::STORAGE_VERSION,
                'normalize_positions' => true,
                'processing_state' => 'ready',
                'retry_count' => 0,
                'retry_at' => null,
                'current_batch_id' => $nextBatchId,
                'batch_size' => $batchSize,
                'context' => [
                    'members' => $context['members'],
                    'list_stage_mapper' => $context['list_stage_mapper'],
                    'member_mapper' => $context['member_mapper'],
                    'label_mapper' => $context['label_mapper'],
                    'custom_field_mapper' => $context['custom_field_mapper'],
                    'checklists_by_card' => self::groupChecklistsByCard($checklists),
                    'import_user_id' => $context['import_user_id'],
                ],
            ]);

            self::assertImportLock($session['import_id']);
            self::touchSession($meta, $session);
            return $session;
        };
        $session = self::isResumable($session) ? self::atomicImportWrite($session['import_id'], $publish) : $publish();
        if (!$totalCards) {
            self::completeAsyncImport($meta, $session);
            return $meta->value;
        }

        return $session;
    }

    /** Validate and import one page; persist progress before discarding its staging data. */
    private static function processAsyncCardBatch($meta, $session)
    {
        $page = (int) Arr::get($session, 'current_page');
        $batchSize = (int) Arr::get($session, 'batch_size');
        $total = (int) Arr::get($session, 'total');
        $completed = (int) Arr::get($session, 'completed');
        $totalPages = (int) Arr::get($session, 'total_pages');
        if ($batchSize < 1 || $total < 0 || $page < 1 || $page > $totalPages + 1
            || $totalPages !== (int) ceil($total / $batchSize)
            || $completed !== min(($page - 1) * $batchSize, $total)) {
            throw new UnexpectedValueException(__('The Trello import progress is invalid. Restart the import.', 'fluent-boards-pro'));
        }
        if ($page === $totalPages + 1 && $completed === $total) {
            self::finishCardsOrStartCovers($meta, $session);
            return;
        }

        $batch = null;
        $pageFile = null;
        $nextBatchId = null;
        if (in_array(Arr::get($session, 'storage_version'), [self::STORAGE_VERSION, self::RESUMABLE_STORAGE_VERSION], true)) {
            $batch = Meta::where('id', absint(Arr::get($session, 'current_batch_id')))
                ->where('object_id', $meta->id)->where('object_type', self::BATCH_OBJECT_TYPE)->first();
            if (!$batch) {
                throw new UnexpectedValueException(__('The Trello import batch is missing. Restart the import.', 'fluent-boards-pro'));
            }
            $payload = $batch->value;
            $nextBatchId = Arr::get($payload, 'next_batch_id');
            if (Arr::get($payload, 'version') !== (self::isResumable($session) ? 2 : 1) || Arr::get($payload, 'page') !== $page || $batch->key !== 'page_' . $page
                || ($page === $totalPages ? $nextBatchId !== null : (!is_int($nextBatchId) || $nextBatchId < 1 || $nextBatchId === (int) $batch->id))) {
                throw new UnexpectedValueException(__('The Trello import batch is invalid.', 'fluent-boards-pro'));
            }
            $cardIds = Arr::get($payload, 'card_ids');
        } elseif (!isset($session['storage_version']) && !empty($session['import_dir'])) {
            // Compatibility for pre-upgrade sessions only; remove in a later release.
            $pageFile = trailingslashit($session['import_dir']) . 'cards_page_' . $page . '.json';
            if (!is_file($pageFile) || !is_readable($pageFile)) {
                throw new UnexpectedValueException(__('The Trello import batch is missing. Restart the import.', 'fluent-boards-pro'));
            }
            $cardIds = json_decode(file_get_contents($pageFile));
        } else {
            throw new UnexpectedValueException(__('The Trello import batch is missing. Restart the import.', 'fluent-boards-pro'));
        }
        self::validateCardIds($cardIds, min($batchSize, $total - $completed));

        $board = Board::findOrFail(absint(Arr::get($session, 'board_id')));
        $context = self::restoreAsyncContext($session);
        $apiKey = Arr::get($session, 'api_key');
        $token = Arr::get($session, 'token');

        $completedCards = self::isResumable($session) ? Arr::get($payload, 'completed_cards', []) : [];
        if (!is_array($completedCards) || array_diff(array_keys($completedCards), $cardIds)
            || count(array_filter($completedCards, function ($id) { return is_int($id) && $id > 0; })) !== count($completedCards)) {
            throw new UnexpectedValueException(__('The Trello import checkpoint is invalid.', 'fluent-boards-pro'));
        }
        $remainingIds = array_values(array_diff($cardIds, array_keys($completedCards)));
        $cardsById = self::fetchCardsDetailsBatch($remainingIds, $apiKey, $token);
        $actionsByCard = self::fetchCardActionsBatch($remainingIds, $apiKey, $token);

        foreach ($remainingIds as $cardId) {
            if (empty($cardsById[$cardId])) {
                throw new UnexpectedValueException(__('Trello did not return every requested card. Restart the import.', 'fluent-boards-pro'));
            }
        }
        self::assertImportLock($session['import_id']);
        $session = self::touchSession($meta, array_merge($session, ['processing_state' => 'processing']));
        foreach ($cardIds as $index => $cardId) {
            if (isset($completedCards[$cardId])) {
                continue;
            }
            self::assertImportLock($session['import_id']);
            $card = $cardsById[$cardId];
            // Pre-upgrade sessions must retain their original position scheme when resumed.
            if (!empty($session['normalize_positions'])) {
                $card['pos'] = $completed + $index + 1;
            }
            $actions = $actionsByCard[$cardId] ?? [];
            $subtaskGroups = Arr::get($context, 'checklists_by_card.' . $cardId, []);
            if (self::isResumable($session)) {
                self::atomicImportWrite($session['import_id'], function () use ($board, $card, $context, $subtaskGroups, $actions, $batch, &$payload, $cardId, $session) {
                    $task = self::importCard($board, $card, $context, $subtaskGroups, $actions);
                    if (!$task->id) {
                        throw new RuntimeException(__('Could not save the Trello card.', 'fluent-boards-pro'));
                    }
                    self::queueTaskCover($session, $card, $task);
                    $payload['completed_cards'][$cardId] = (int) $task->id;
                    $batch->value = $payload;
                    if (!$batch->save()) {
                        throw new RuntimeException(__('Could not save the Trello card checkpoint.', 'fluent-boards-pro'));
                    }
                });
            } else {
                self::importCard($board, $card, $context, $subtaskGroups, $actions);
            }
        }

        self::assertImportLock($session['import_id']);
        $completed += count($cardIds);
        $total = absint(Arr::get($session, 'total'));
        $percentage = $total ? 15 + floor(($completed / $total) * 80) : 95;
        $session = array_merge($session, [
            'completed' => $completed,
            'current_page' => $page + 1,
            'current_batch_id' => $nextBatchId,
            'processing_state' => 'ready',
            'retry_count' => 0,
            'retry_at' => null,
            'percentage' => min(95, $percentage),
            'message' => sprintf(
                /* translators: %1$d is the number of cards imported so far, %2$d is the total number of cards */
                __('Imported %1$d of %2$d Trello cards...', 'fluent-boards-pro'),
                $completed,
                $total
            ),
        ]);

        self::touchSession($meta, $session);
        if ($page === $totalPages && $completed === $total) {
            self::finishCardsOrStartCovers($meta, $session);
            return;
        }
        // Deletion is best-effort after the checkpoint; terminal cleanup retries leftovers.
        try {
            if ($batch) {
                $batch->delete();
            } elseif ($pageFile) {
                @unlink($pageFile);
            }
        } catch (Throwable $e) {
            // The next page remains safe to process even if this row cannot yet be deleted.
        }
        self::enqueueAsyncImport($session['import_id']);
    }

    /** Scope cover work by destination board and import, independently of disposable card batches. */
    private static function coverRecords($session, $state = null)
    {
        $states = $state ? [$state] : ['pending', 'processing', 'succeeded', 'failed', 'skipped'];
        $keys = array_map(function ($value) use ($session) { return $session['import_id'] . ':' . $value; }, $states);
        return Meta::where('object_id', absint(Arr::get($session, 'board_id')))
            ->where('object_type', self::COVER_OBJECT_TYPE)->whereIn('key', $keys);
    }

    /** Queue the selected cover in the same transaction as its task and card checkpoint. */
    private static function queueTaskCover($session, $card, $task)
    {
        if (empty($session['cover_version'])) {
            return;
        }
        $source = (new TrelloCoverService())->resolve($card);
        if ($source === null) {
            return;
        }
        $record = Meta::create([
            'object_id' => $task->board_id, 'object_type' => self::COVER_OBJECT_TYPE,
            'key' => $session['import_id'] . ':pending',
            'value' => ['task_id' => (int) $task->id, 'source' => $source,
                'expected_cover' => Arr::get($task->settings, 'cover'), 'staged' => []],
        ]);
        if (!$record->id) {
            throw new RuntimeException('Could not checkpoint the Trello cover.');
        }
    }

    /** Aggregate indexed states without loading source URLs or image metadata into status responses. */
    private static function coverStatus($session)
    {
        $counts = ['pending' => 0, 'processing' => 0, 'succeeded' => 0, 'failed' => 0, 'skipped' => 0];
        foreach (self::coverRecords($session)->selectRaw('`key`, COUNT(*) AS total')->groupBy('key')->get() as $row) {
            $state = substr($row->key, strlen($session['import_id']) + 1);
            $counts[$state] = (int) $row->total;
        }
        $retrying = !empty($session['cover_retry']);
        return [
            'total' => array_sum($counts), 'pending' => $counts['pending'] + $counts['processing'],
            'succeeded' => $counts['succeeded'], 'failed' => $counts['failed'], 'skipped' => $counts['skipped'],
            'retrying' => $retrying,
            'can_retry' => $session['status'] === 'completed' && !$retrying && $counts['failed'] > 0
                && Board::where('id', absint(Arr::get($session, 'board_id')))->exists(),
        ];
    }

    /** Persist one state transition; callers own the import lock. */
    private static function saveCoverRecord($record, $session, $state, $data)
    {
        self::assertImportLock($session['import_id']);
        $record->key = $session['import_id'] . ':' . $state;
        $record->value = $data;
        if (!$record->save()) {
            throw new RuntimeException('Could not checkpoint the Trello cover.');
        }
    }

    /** Enter the image phase only for new API imports; legacy sessions retain their original flow. */
    private static function finishCardsOrStartCovers($meta, $session)
    {
        if (empty($session['cover_version']) || !self::coverRecords($session, 'pending')->exists()) {
            self::completeAsyncImport($meta, $session);
            return;
        }
        self::touchSession($meta, array_merge($session, [
            'phase' => 'covers', 'processing_state' => 'ready', 'percentage' => 95,
            'message' => __('Importing Trello cover images...', 'fluent-boards-pro'),
        ]));
        self::enqueueAsyncImport($session['import_id']);
    }

    /** Process bounded cover work without retrying failed downloads or replaying card finalization. */
    private static function processCoverBatch($meta, $session)
    {
        $service = new TrelloCoverService();
        $started = microtime(true);
        $expired = !empty($session['cover_retry']) && (int) Arr::get($session, 'cover_expires_at') <= time();
        // A processing record can only be abandoned: the connection-owned import lock excludes a live worker.
        foreach (self::coverRecords($session, 'processing')->get() as $record) {
            $data = $record->value;
            $service->discard(Arr::get($data, 'staged', []), $session['board_id']);
            $data['staged'] = [];
            $data['error'] = 'interrupted';
            self::saveCoverRecord($record, $session, 'failed', $data);
        }
        if ($expired) {
            // Do not perform downloads after expiry. Pending work remains manually retryable.
            self::coverRecords($session, 'pending')->update(['key' => $session['import_id'] . ':failed']);
            self::finishCoverRetry($meta, $session);
            return;
        }
        foreach (self::coverRecords($session, 'pending')->orderBy('id')->limit(self::COVER_BATCH_SIZE)->get() as $record) {
            if (microtime(true) - $started >= self::COVER_BATCH_SECONDS) {
                break;
            }
            $data = $record->value;
            self::saveCoverRecord($record, $session, 'processing', $data);
            $media = null;
            try {
                $task = Task::find(Arr::get($data, 'task_id'));
                if (!$task || (int) $task->board_id !== (int) $session['board_id']
                    || Arr::get($task->settings, 'cover') !== $data['expected_cover']) {
                    self::saveCoverRecord($record, $session, 'skipped', $data);
                    continue;
                }
                $service->discard(Arr::get($data, 'staged', []), $session['board_id']);
                $data['staged'] = [];
                $auth = ['key' => Arr::get($session, 'api_key'), 'token' => Arr::get($session, 'token')];
                $source = !empty($session['cover_retry']) ? $service->refresh($data['source'], $auth) : $data['source'];
                $media = $service->stage($source, $session['board_id'], $auth, function ($staged) use ($record, $session, &$data) {
                    $data['staged'] = $staged;
                    self::saveCoverRecord($record, $session, 'processing', $data);
                });
                $saved = self::atomicImportWrite($session['import_id'], function () use ($record, $session, $media, $data) {
                    $task = Task::where('id', $data['task_id'])->where('board_id', $session['board_id'])->lockForUpdate()->first();
                    if (!$task || Arr::get($task->settings, 'cover') !== $data['expected_cover']) {
                        return false;
                    }
                    $settings = $task->settings ?: [];
                    $original = $task->getRawOriginal('settings');
                    $image = (new TaskService())->uploadMediaFileFromWpEditor($task->id, $media, Constant::TASK_DESCRIPTION);
                    $image->driver = $media['driver'];
                    $image->file_path = $media['file_path'];
                    $image->full_url = $media['full_url'];
                    if (!$image->save()) {
                        throw new RuntimeException('cover_save_failed');
                    }
                    $settings['cover']['imageId'] = $image->id;
                    $settings['cover']['backgroundImage'] = (new CommentService())->createPublicUrl($image, $task->board_id);
                    // Compare-and-set keeps a concurrent settings update from being overwritten by stale importer data.
                    $updated = Task::where('id', $task->id)->where('board_id', $session['board_id'])
                        ->where('settings', $original)->update(['settings' => maybe_serialize($settings)]);
                    if (!$updated) {
                        throw new RuntimeException('cover_changed');
                    }
                    $data['staged'] = [];
                    $data['image_id'] = (int) $image->id;
                    unset($data['error']);
                    self::saveCoverRecord($record, $session, 'succeeded', $data);
                    return true;
                });
                if (!$saved) {
                    $service->discard($data['staged'], $session['board_id']);
                    $data['staged'] = [];
                    self::saveCoverRecord($record, $session, 'skipped', $data);
                }
            } catch (Throwable $e) {
                // Re-read after an uncertain commit before deleting any file referenced by a successful cover.
                self::assertImportLock($session['import_id']);
                $fresh = Meta::find($record->id);
                if ($fresh && $fresh->key === $session['import_id'] . ':succeeded') {
                    continue;
                }
                $service->discard(Arr::get($data, 'staged', []), $session['board_id']);
                $data['staged'] = [];
                $data['error'] = 'cover_failed';
                self::saveCoverRecord($record, $session, $e->getMessage() === 'cover_changed' ? 'skipped' : 'failed', $data);
            }
        }
        if (self::coverRecords($session, 'pending')->exists()) {
            self::enqueueAsyncImport($session['import_id'], !empty($session['cover_retry']) ? $session['cover_run'] : null);
            return;
        }
        if (!empty($session['cover_retry'])) {
            self::finishCoverRetry($meta, $session);
        } else {
            self::completeAsyncImport($meta, $session);
        }
    }

    /** Complete only the retry run: no card counts, board activity or import finalization is replayed. */
    private static function finishCoverRetry($meta, $session)
    {
        $run = $session['cover_run'];
        unset($session['api_key'], $session['token'], $session['cover_expires_at']);
        $session['cover_retry'] = false;
        self::touchSession($meta, $session);
        as_unschedule_all_actions(self::RECOVERY_ACTION, [$session['import_id'], $run], 'fluent-boards');
    }

    /** Start one owner-authorized retry of failed covers on an already imported board. */
    public static function retryFailedCovers($importId, $apiKey, $token, $userId)
    {
        global $wpdb;
        $importId = sanitize_key($importId);
        $userId = absint($userId);
        $status = self::getImportStatus($importId, $userId);
        if (isset($status['error'])) {
            return $status;
        }
        $lock = self::importLockName($importId);
        if ((string) $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 0)', $lock)) !== '1') {
            return $status;
        }
        $reconnectRetries = $wpdb->reconnect_retries;
        $wpdb->reconnect_retries = 0;
        try {
            $meta = self::getSessionMeta($importId);
            $session = $meta->value;
            if (!PermissionManager::isAdmin($userId) || !Board::find(Arr::get($session, 'board_id'))
                || !PermissionManager::userHasPermission($session['board_id'], $userId)) {
                return ['error' => __('You do not have access to this Trello import board.', 'fluent-boards-pro')];
            }
            if (empty($session['cover_version']) || $session['status'] !== 'completed' || !empty($session['cover_retry'])) {
                return self::publicStatus($session, $meta->id);
            }
            $apiKey = sanitize_text_field($apiKey);
            $token = sanitize_text_field($token);
            if (!$apiKey || !$token) {
                return ['error' => __('API Key and Token are required to retry covers.', 'fluent-boards-pro')];
            }
            if (!self::coverRecords($session, 'failed')->exists()) {
                return self::publicStatus($session, $meta->id);
            }
            $session = array_merge($session, ['cover_retry' => true, 'cover_run' => wp_generate_uuid4(),
                'cover_expires_at' => time() + self::PAUSE_RETENTION, 'api_key' => $apiKey, 'token' => $token]);
            self::ensureRecovery($importId, true, self::RECOVERY_DELAY, $session['cover_run']);
            self::atomicImportWrite($importId, function () use ($meta, $session) {
                self::coverRecords($session, 'failed')->update(['key' => $session['import_id'] . ':pending']);
                self::touchSession($meta, $session);
            });
            self::enqueueAsyncImport($importId, $session['cover_run']);
            return self::publicStatus($session, $meta->id);
        } finally {
            $wpdb->reconnect_retries = $reconnectRetries;
            $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lock));
        }
    }

    /** Board deletion removes retry records without touching another import or board's files. */
    public static function deleteBoardCoverWork($board)
    {
        $query = Meta::where('object_id', absint($board->id))->where('object_type', self::COVER_OBJECT_TYPE);
        foreach ((clone $query)->cursor() as $record) {
            (new TrelloCoverService())->discard(Arr::get($record->value, 'staged', []), $board->id);
        }
        $query->delete();
    }

    /** Reject truncated, malformed or duplicated IDs before creating any tasks. */
    private static function validateCardIds($cardIds, $expectedCount)
    {
        if (!is_array($cardIds) || count($cardIds) !== $expectedCount
            || count(array_filter($cardIds, function ($id) { return is_string($id) && trim($id) !== ''; })) !== $expectedCount
            || count(array_unique($cardIds)) !== $expectedCount) {
            throw new UnexpectedValueException(__('The Trello import batch could not be read or is incomplete.', 'fluent-boards-pro'));
        }
    }

    /** Finalize once, preserving a terminal session for the progress polling API. */
    private static function completeAsyncImport($meta, $session)
    {
        $finalize = function () use ($meta, $session) {
            self::assertImportLock($session['import_id']);
            self::touchSession($meta, array_merge($session, ['processing_state' => 'finalizing']));
            $boardId = absint(Arr::get($session, 'board_id'));
            if ($boardId) {
                self::updateBoardTaskCount($boardId);
                $board = Board::find($boardId);
                if ($board) {
                    self::createBoardActivity($board, Arr::get($session, 'board_data', []), absint(Arr::get($session, 'user_id')));
                }
            }

            unset($session['api_key'], $session['token'], $session['context'], $session['processing_state']);
            self::assertImportLock($session['import_id']);
            $session = self::touchSession($meta, array_merge($session, [
                'status' => 'completed',
                'phase' => 'completed',
                'message' => __('Board imported successfully from Trello', 'fluent-boards-pro'),
                'percentage' => 100,
                'completed' => absint(Arr::get($session, 'total')),
                'cleanup_pending' => true,
            ]));
            return $session;
        };
        $session = self::isResumable($session) ? self::atomicImportWrite($session['import_id'], $finalize) : $finalize();
        self::cleanupAsyncImport($meta, $session);
    }

    /** Clean only this import's staging data; a failure leaves terminal status pollable. */
    private static function cleanupAsyncImport($meta, $session)
    {
        Meta::where('object_id', $meta->id)->where('object_type', self::BATCH_OBJECT_TYPE)->delete();
        self::cleanupImportDirectory(Arr::get($session, 'import_dir'));
        unset($session['import_dir'], $session['current_batch_id']);
        self::touchSession($meta, array_merge($session, ['cleanup_pending' => false]));
        as_unschedule_all_actions(self::RECOVERY_ACTION, [$session['import_id']], 'fluent-boards');
    }

    private static function restoreAsyncContext($session)
    {
        $context = Arr::get($session, 'context', []);

        return [
            'parse_down' => new Parsedown(),
            'members' => Arr::get($context, 'members', []),
            'list_stage_mapper' => Arr::get($context, 'list_stage_mapper', []),
            'member_mapper' => Arr::get($context, 'member_mapper', []),
            'label_mapper' => Arr::get($context, 'label_mapper', []),
            'custom_field_mapper' => Arr::get($context, 'custom_field_mapper', []),
            'checklists_by_card' => Arr::get($context, 'checklists_by_card', []),
            'import_user_id' => absint(Arr::get($context, 'import_user_id', Arr::get($session, 'user_id'))),
        ];
    }

    private static function fetchCardsDetailsBatch($cardIds, $apiKey, $token)
    {
        $cardsById = [];
        $query = [
            'fields' => 'id,name,desc,pos,due,dueComplete,start,closed,idList,idLabels,idMembers,idMembersVoted,isTemplate,cover,idAttachmentCover,idChecklists,url,shortUrl,idShort,subscribed,badges',
            'attachments' => 'true',
            'attachment_fields' => 'id,name,url,bytes,date,mimeType,isUpload,previews',
            'members' => 'false',
            'stickers' => 'true',
            'sticker_fields' => 'id,image,imageUrl,top,left,zIndex,rotate',
            'customFieldItems' => 'true',
        ];

        foreach (array_chunk($cardIds, 10) as $chunk) {
            $urls = array_map(function ($cardId) use ($query) {
                return '/cards/' . rawurlencode($cardId) . '?' . http_build_query($query);
            }, $chunk);

            $responses = self::apiBatchGet($urls, $apiKey, $token);
            self::throwIfApiError($responses);

            foreach ($responses as $response) {
                $card = self::normalizeBatchResponse($response);
                self::throwIfApiError($card);

                $cardId = Arr::get($card, 'id');
                if ($cardId) {
                    $cardsById[$cardId] = $card;
                }
            }
        }

        return $cardsById;
    }

    private static function fetchCardActionsBatch($cardIds, $apiKey, $token)
    {
        $actionsByCard = [];
        $query = [
            'filter' => 'commentCard,addAttachmentToCard,deleteAttachmentFromCard,updateCard,addMemberToCard,removeMemberFromCard,addLabelToCard,removeLabelFromCard',
            'limit' => 1000,
            'fields' => 'data,type,date,idMemberCreator',
            'memberCreator_fields' => 'fullName,username,initials,avatarUrl,email',
        ];

        foreach (array_chunk($cardIds, 10) as $chunk) {
            $urls = array_map(function ($cardId) use ($query) {
                return '/cards/' . rawurlencode($cardId) . '/actions?' . http_build_query($query);
            }, $chunk);

            $responses = self::apiBatchGet($urls, $apiKey, $token);
            self::throwIfApiError($responses);

            foreach ($responses as $index => $response) {
                $cardId = $chunk[$index] ?? null;
                if (!$cardId) {
                    continue;
                }

                $actions = self::normalizeBatchResponse($response);
                self::throwIfApiError($actions);

                $actionsByCard[$cardId] = is_array($actions) ? $actions : [];
            }
        }

        return $actionsByCard;
    }

    private static function apiBatchGet($urls, $apiKey, $token)
    {
        if (!$urls) {
            return [];
        }

        $response = self::apiGet(self::$apiBaseUrl . '/batch?' . http_build_query([
            'urls' => implode(',', $urls),
            'key' => $apiKey,
            'token' => $token,
        ]));
        if (!isset($response['error']) && count($response) !== count($urls)) {
            return self::apiError(0);
        }
        return $response;
    }

    /** Retain inner HTTP failures instead of accepting a successful outer batch response. */
    private static function normalizeBatchResponse($response)
    {
        if (is_array($response)) {
            foreach ($response as $statusCode => $body) {
                if ((int) $statusCode === 200 && is_array($body)) {
                    return $body;
                }
                if (is_numeric($statusCode)) {
                    return self::apiError((int) $statusCode);
                }
            }
        }
        return self::apiError(0);
    }

    private static function sessionKey($importId)
    {
        return 'trello_import_' . sanitize_key($importId);
    }

    private static function getSessionMeta($importId)
    {
        return Meta::where('object_type', self::META_OBJECT_TYPE)
            ->where('key', self::sessionKey($importId))
            ->first();
    }

    /** Persist checkpoints explicitly; a rejected save must never advance the worker. */
    private static function touchSession($meta, $session)
    {
        $session['updated_at'] = gmdate('Y-m-d H:i:s');
        $meta->value = $session;
        if (!$meta->save()) {
            throw new RuntimeException(__('Could not save the Trello import progress.', 'fluent-boards-pro'));
        }

        return $session;
    }

    /** Include only committed card checkpoints; never expose credentials or import context. */
    private static function publicStatus($session, $sessionId = null)
    {
        $completed = (int) Arr::get($session, 'completed', 0);
        if (self::isResumable($session) && $sessionId && !empty($session['current_batch_id'])) {
            $batch = Meta::where('id', $session['current_batch_id'])->where('object_id', $sessionId)
                ->where('object_type', self::BATCH_OBJECT_TYPE)->first();
            $completed += $batch ? count(Arr::get($batch->value, 'completed_cards', [])) : 0;
        }
        $paused = Arr::get($session, 'status') === 'paused';
        $expiresAt = Arr::get($session, 'expires_at');
        if ($paused && $expiresAt <= time()) {
            // Expiry is visible even when cron has not yet cleaned the retained payload.
            $session['status'] = 'failed';
            $session['phase'] = 'failed';
            $session['message'] = __('The paused Trello import has expired.', 'fluent-boards-pro');
        }
        $status = [
            'import_id' => Arr::get($session, 'import_id'),
            'status' => Arr::get($session, 'status', 'queued'),
            'phase' => Arr::get($session, 'phase', ''),
            'percentage' => max((int) Arr::get($session, 'percentage', 0), !empty($session['total']) ? (int) (15 + floor($completed / $session['total'] * 80)) : 0),
            'completed' => $completed,
            'can_resume' => $paused && self::isResumable($session) && $expiresAt > time(),
            'retry_at' => Arr::get($session, 'retry_at'),
            'expires_at' => $expiresAt,
            'total' => (int) Arr::get($session, 'total', 0),
            'board_id' => Arr::get($session, 'board_id'),
            'message' => Arr::get($session, 'message', ''),
        ];
        if (!empty($session['cover_version'])) {
            $status['covers'] = self::coverStatus($session);
            $status['board_name'] = (string) Arr::get($session, 'board_data.name', '');
        }
        return $status;
    }

    /** Legacy sessions only: remove this compatibility cleanup in a later release. */
    private static function cleanupImportDirectory($importDir)
    {
        if (!$importDir || !is_dir($importDir)) {
            return;
        }

        $files = glob(trailingslashit($importDir) . 'cards_page_*.json');
        if ($files) {
            foreach ($files as $file) {
                @unlink($file);
            }
        }

        if (!@rmdir($importDir) && is_dir($importDir)) {
            throw new RuntimeException(__('Could not remove the legacy Trello import folder.', 'fluent-boards-pro'));
        }
    }

    /** Persist failure and remove credentials before retryable staging cleanup. */
    private static function markSessionFailed($meta, $session, $message)
    {
        unset($session['api_key'], $session['token'], $session['context'], $session['processing_state']);
        $session = self::touchSession($meta, array_merge($session, [
            'status' => 'failed',
            'cleanup_pending' => true,
            'phase' => 'failed',
            'message' => $message ?: __('Trello import failed.', 'fluent-boards-pro'),
        ]));
        self::cleanupAsyncImport($meta, $session);
    }

    private static function throwIfApiError($response)
    {
        if (is_array($response) && isset($response['error'])) {
            self::$apiFailure = $response;
            throw new RuntimeException($response['error']);
        }
    }

    /**
     * @param string $apiKey         Trello API key
     * @param string $token          Trello user token
     * @param string $trelloBoardId  The Trello board ID to import
     * @return Board|array           The created Board model, or ['error' => message]
     */
    public static function fetchAndImport($apiKey, $token, $trelloBoardId, $options = [])
    {
        if (ini_get('max_execution_time') < 300) {
            @ini_set('max_execution_time', '300');
        }

        $authQuery = 'key=' . urlencode($apiKey) . '&token=' . urlencode($token);
        $base = self::$apiBaseUrl . '/boards/' . urlencode($trelloBoardId);

        // 1. Fetch board details
        $board = self::apiGet($base . '?' . $authQuery . '&fields=name,desc,url,closed,dateClosed,prefs');
        if (isset($board['error'])) {
            return $board;
        }

        // 2. Fetch lists (→ stages)
        $lists = self::apiGet($base . '/lists?' . $authQuery . '&fields=name,pos,closed');
        if (isset($lists['error'])) {
            return $lists;
        }

        // 3. Fetch cards (→ tasks), including related card-level data available from Trello nested resources.
        $cards = self::apiGet($base . '/cards?' . $authQuery . '&' . http_build_query([
            'fields' => 'id,name,desc,pos,due,dueComplete,start,closed,idList,idLabels,idMembers,idMembersVoted,isTemplate,cover,idAttachmentCover,idChecklists,url,shortUrl,idShort,subscribed,badges',
            'attachments' => 'true',
            'attachment_fields' => 'id,name,url,bytes,date,mimeType,isUpload,previews',
            'members' => 'true',
            'member_fields' => 'fullName,username,initials,avatarUrl,email',
            'stickers' => 'true',
            'sticker_fields' => 'id,image,imageUrl,top,left,zIndex,rotate',
            'customFieldItems' => 'true',
        ]));
        if (isset($cards['error'])) {
            return $cards;
        }

        // 4. Fetch labels
        $labels = self::apiGet($base . '/labels?' . $authQuery . '&fields=name,color');
        if (isset($labels['error'])) {
            return $labels;
        }

        // 5. Fetch checklists (→ subtask groups)
        // checkItems=all tells Trello to include the individual checklist items inline
        $checklists = self::apiGet($base . '/checklists?' . $authQuery . '&fields=name,idCard&checkItems=all');
        if (isset($checklists['error'])) {
            return $checklists;
        }

        $members = self::apiGetOptional($base . '/members?' . $authQuery . '&fields=fullName,username,initials,avatarUrl,email');
        $currentMember = self::apiGetOptional(self::$apiBaseUrl . '/members/me?' . $authQuery . '&fields=id,fullName,username,initials,avatarUrl,email');
        $members = self::mergeCurrentMemberEmail($members, $currentMember);
        $customFields = self::apiGetOptional($base . '/customFields?' . $authQuery);
        $actions = self::fetchAllBoardActions($base, $authQuery);

        $board['lists'] = $lists;
        $board['cards'] = $cards;
        $board['labels'] = $labels;
        $board['checklists'] = $checklists;
        $board['members'] = $members;
        $board['customFields'] = $customFields;
        $board['actions'] = $actions;

        return self::process($board, $options);
    }

    private static function fetchAllBoardActions($base, $authQuery)
    {
        $actions = [];
        $before = null;
        $pages = 0;
        $limit = 1000;
        $maxPages = 20;

        do {
            $query = [
                'filter' => 'commentCard,addAttachmentToCard,deleteAttachmentFromCard,updateCard,addMemberToCard,removeMemberFromCard,addLabelToCard,removeLabelFromCard',
                'limit' => $limit,
                'fields' => 'data,type,date,idMemberCreator',
                'memberCreator_fields' => 'fullName,username,initials,avatarUrl,email',
            ];

            if ($before) {
                $query['before'] = $before;
            }

            $page = self::apiGetOptional($base . '/actions?' . $authQuery . '&' . http_build_query($query));
            if (!$page) {
                break;
            }

            $actions = array_merge($actions, $page);
            $lastAction = end($page);
            $before = $lastAction ? Arr::get($lastAction, 'id') : null;
            $pages++;
        } while (count($page) === $limit && $before && $pages < $maxPages);

        return $actions;
    }

    private static function mergeCurrentMemberEmail($members, $currentMember)
    {
        $currentMemberId = Arr::get($currentMember, 'id');
        if (!$currentMemberId) {
            return $members;
        }

        foreach ($members as $index => $member) {
            if (Arr::get($member, 'id') !== $currentMemberId) {
                continue;
            }

            $members[$index] = array_merge($member, array_filter($currentMember));
            return $members;
        }

        $members[] = $currentMember;

        return $members;
    }

    /** Only sessions created with atomic card checkpoints can be replayed. */
    private static function isResumable($session)
    {
        return Arr::get($session, 'storage_version') === self::RESUMABLE_STORAGE_VERSION;
    }

    /** Check rollback support once before publishing a destination board. */
    private static function assertTransactionalTables($session)
    {
        global $wpdb;
        $tables = [];
        foreach ([Board::class, BoardTerm::class, Task::class, TaskMeta::class, Meta::class, Relation::class, Comment::class, Activity::class, TaskAttachment::class] as $model) {
            $tables[] = $wpdb->prefix . (new $model())->getTable();
        }
        foreach (['actionscheduler_actions', 'actionscheduler_groups', 'actionscheduler_logs'] as $table) {
            $tables[] = $wpdb->prefix . $table;
        }
        if (!empty($session['import_users'])) {
            $tables[] = $wpdb->users;
            $tables[] = $wpdb->usermeta;
        }
        $placeholders = implode(',', array_fill(0, count($tables), '%s'));
        $rows = $wpdb->get_results($wpdb->prepare("SHOW TABLE STATUS WHERE Name IN ($placeholders)", $tables));
        if (count($rows) !== count($tables)) {
            throw new UnexpectedValueException(__('Trello resume requires transactional import tables.', 'fluent-boards-pro'));
        }
        foreach ($rows as $row) {
            if (strtolower($row->Engine) !== 'innodb') {
                throw new UnexpectedValueException(__('Trello resume requires InnoDB import tables.', 'fluent-boards-pro'));
            }
        }
    }

    /** Commit imported rows and their checkpoint together, without reconnect/replay mid-transaction. */
    private static function atomicImportWrite($importId, $callback)
    {
        global $wpdb;
        $cacheSuspended = wp_suspend_cache_addition();
        // WordPress user caches must not publish users that a rollback may remove.
        wp_suspend_cache_addition(true);
        $committed = false;
        try {
            self::assertImportLock($importId);
            if ($wpdb->query('START TRANSACTION') === false) {
                throw new RuntimeException(__('Could not start the Trello import transaction.', 'fluent-boards-pro'));
            }
            $result = $callback();
            self::assertImportLock($importId);
            if ($wpdb->query('COMMIT') === false) {
                throw new RuntimeException(__('Could not confirm the Trello import transaction.', 'fluent-boards-pro'));
            }
            $committed = true;
            return $result;
        } finally {
            try {
                if (!$committed) {
                    $wpdb->query('ROLLBACK');
                }
            } finally {
                wp_suspend_cache_addition($cacheSuspended);
            }
        }
    }

    /** Schedule bounded read retries or retain the checkpoint for manual continuation. */
    private static function pauseOrRetry($meta, $session)
    {
        $attempt = (int) Arr::get($session, 'retry_count', 0);
        $session['processing_state'] = 'ready';
        if (self::$apiFailure && $attempt < count(self::RETRY_DELAYS)) {
            $delay = max(self::RETRY_DELAYS[$attempt], (int) Arr::get(self::$apiFailure, 'retry_after', 0));
            $session['retry_count'] = $attempt + 1;
            $session['retry_at'] = time() + $delay;
            $session['message'] = __('Trello is temporarily unavailable. Retrying the import...', 'fluent-boards-pro');
        } else {
            $session['status'] = 'paused';
            $session['retry_at'] = null;
            $session['expires_at'] = time() + self::PAUSE_RETENTION;
            $session['message'] = __('The Trello import is paused. You can continue within 24 hours.', 'fluent-boards-pro');
            $delay = self::PAUSE_RETENTION;
        }
        self::touchSession($meta, $session);
        self::ensureRecovery($session['import_id'], true, $delay);
    }

    /** Resume the owner's existing session under the worker lock; repeated requests are harmless. */
    public static function resumeAsyncImport($importId, $userId)
    {
        global $wpdb;
        $importId = sanitize_key($importId);
        $status = self::getImportStatus($importId, $userId);
        if (isset($status['error'])) {
            return $status;
        }
        $lockName = self::importLockName($importId);
        if ((string) $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 0)', $lockName)) !== '1') {
            return $status;
        }
        $reconnectRetries = $wpdb->reconnect_retries;
        $wpdb->reconnect_retries = 0;
        try {
            $meta = self::getSessionMeta($importId);
            $session = $meta->value;
            if (Arr::get($session, 'status') !== 'paused' || !self::isResumable($session)) {
                return self::publicStatus($session, $meta->id);
            }
            if ((int) Arr::get($session, 'expires_at') <= time()) {
                self::markSessionFailed($meta, $session, __('The paused Trello import has expired.', 'fluent-boards-pro'));
                return self::publicStatus($meta->value);
            }
            // Recovery is durable before a resumable checkpoint becomes runnable again.
            self::ensureRecovery($importId, true);
            $session = self::touchSession($meta, array_merge($session, [
                'status' => empty($session['board_id']) ? 'queued' : 'running',
                'processing_state' => 'ready',
                'retry_count' => 0,
                'retry_at' => null,
                'expires_at' => null,
                'message' => __('Continuing Trello import...', 'fluent-boards-pro'),
            ]));
            self::enqueueAsyncImport($importId);
            return self::publicStatus($session, $meta->id);
        } finally {
            $wpdb->reconnect_retries = $reconnectRetries;
            $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lockName));
        }
    }

    /** Use sanitized messages and explicit retry metadata, never credential-bearing transport errors. */
    private static function apiError($code, $retryAfter = 0, $transportRetryable = false)
    {
        return [
            'error' => $code === 401
                ? __('Invalid API key or token. Please check your credentials.', 'fluent-boards-pro')
                : __('Trello API request failed.', 'fluent-boards-pro'),
            'retryable' => $transportRetryable || in_array($code, [408, 429], true) || ($code >= 500 && $code <= 599),
            'retry_after' => max(0, $retryAfter),
        ];
    }

    /** Optional unsupported fields stay optional; v2 imports retry transient read failures. */
    private static function apiGetOptional($url, $retryTransient = false)
    {
        $response = self::apiGet($url);

        if (isset($response['error'])) {
            if ($retryTransient && !empty($response['retryable'])) {
                self::throwIfApiError($response);
            }
            return [];
        }

        return $response;
    }

    /**
     * @param string $url  Full URL including query parameters
     * @return array       Decoded JSON response, or ['error' => message]
     */
    private static function apiGet($url)
    {
        $response = wp_remote_get($url, ['timeout' => 30]);

        if (is_wp_error($response)) {
            $retryable = (bool) preg_match('/cURL error (6|7|18|28|52|55|56)\b|timed? ?out|connection (reset|refused)|network is unreachable/i', $response->get_error_message());
            return self::apiError(0, 0, $retryable);
        }

        $code = wp_remote_retrieve_response_code($response);

        $body = json_decode(wp_remote_retrieve_body($response), true);

        if ($code !== 200 || !is_array($body)) {
            $retryAfter = wp_remote_retrieve_header($response, 'retry-after');
            $delay = is_numeric($retryAfter) ? (int) $retryAfter : max(0, (int) strtotime((string) $retryAfter) - time());
            return self::apiError($code, $delay);
        }

        return $body;
    }
}
