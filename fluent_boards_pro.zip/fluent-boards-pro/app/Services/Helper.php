<?php

namespace FluentBoardsPro\App\Services;

use DateTimeImmutable;
use DateTimeZone;
use Exception;
use InvalidArgumentException;

use FluentBoards\App\Models\Activity;
use FluentBoards\App\Models\Label;
use FluentBoards\App\Services\Constant;

class Helper
{
    /** Resolve recurrence time without silently reinterpreting an existing schedule. */
    public static function recurringTimezone($savedRule = null, $useSiteTimezone = false)
    {
        try {
            if ($savedRule === null || $useSiteTimezone) {
                $name = wp_timezone_string();
            } else {
                // The framework interpreted older rules without a timezone in site time.
                $name = !empty($savedRule['time_zone']) ? $savedRule['time_zone'] : wp_timezone_string();
            }
            if ($name === 'Asia/Calcutta') {
                $name = 'Asia/Kolkata';
            }
            return new DateTimeZone($name);
        } catch (Exception $e) {
            throw new InvalidArgumentException(__('The recurring task timezone is not supported. Please select the site timezone or check the site timezone settings.', 'fluent-boards-pro'), 422);
        }
    }

    /**
     * Normalize date-picker/API dates without shifting their supplied calendar time.
     * Accept date-only, stored datetime, ISO datetime and JavaScript Date strings.
     *
     * @return string|null
     * @throws InvalidArgumentException
     */
    public static function parseDate($value)
    {
        if ($value === null || (is_string($value) && trim($value) === '')) {
            return null;
        }
        if (!is_string($value) || strpos($value, "\0") !== false) {
            throw new InvalidArgumentException(__('Please provide a valid date.', 'fluent-boards-pro'), 422);
        }

        $value = preg_replace('/\s+\([^)]*\)$/', '', trim($value));
        if (preg_match('/^\d{4}-\d{2}-\d{2}[Tt]/', $value)) {
            $value[10] = 'T';
            $value = preg_replace('/[Zz]$/', '+00:00', $value);
            $value = preg_replace('/([+-]\d{2})(\d{2})$/', '$1:$2', $value);
            $value = preg_replace_callback('/\.(\d{1,6})(?=(?:[+-]\d{2}:\d{2})?$)/', function ($matches) {
                return '.' . str_pad($matches[1], 6, '0');
            }, $value);
        }

        $timezone = wp_timezone();
        $formats = [
            'Y-m-d', 'Y-m-d H:i:s',
            'Y-m-d\TH:i:sP', 'Y-m-d\TH:i:s.uP',
            'Y-m-d\TH:i:s', 'Y-m-d\TH:i:s.u',
            'D M d Y H:i:s \G\M\TO',
        ];
        foreach ($formats as $format) {
            $date = DateTimeImmutable::createFromFormat('!' . $format, $value, $timezone);
            $errors = DateTimeImmutable::getLastErrors();
            if ($date && (!$errors || (!$errors['warning_count'] && !$errors['error_count']))
                && $date->format($format) === $value
                && checkdate((int) $date->format('m'), (int) $date->format('d'), (int) $date->format('Y'))) {
                return $date->format('Y-m-d H:i:s');
            }
        }

        throw new InvalidArgumentException(__('Please provide a valid date.', 'fluent-boards-pro'), 422);
    }

    public static function setCurrentUserPreferencesOnBoardCreate($board)
    {
        $board->users()->attach(
            get_current_user_id(),
            [
                'object_type' => Constant::OBJECT_TYPE_BOARD_USER,
                'settings' => maybe_serialize([
                    Constant::IS_BOARD_ADMIN => true
                ]),
                'preferences' => maybe_serialize(Constant::BOARD_NOTIFICATION_TYPES)
            ]
        );
    }

    public static function createDefaultLabels($boardId)
    {
        $bg_colors = ['#4bce97', '#f5cd47', '#fea362', '#f87168', '#9f8fef'];
        $text_colors = ['#1B2533', '#1B2533', '#1B2533', '#1B2533', '#1B2533'];

        $data = [];

        foreach ($text_colors as $index => $text_color)
        {
            $data[] = [
                'board_id' => $boardId,
                'type' => 'label',
                'bg_color' => $bg_colors[$index],
                'color' => $text_colors[$index],
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql')
            ];
        }

        Label::insert($data);
    }

    public static function defaultTaskCountAdd($board, $totalTasks)
    {
        $settings = $board->settings ?? [];

        if (isset($settings['tasks_count'])) {
            $settings['tasks_count'] += $totalTasks;
        } else {
            $settings['tasks_count'] = $totalTasks;
        }
        $board->settings = $settings;
        $board->save();
    }

    public static function createTrackingActivity($track, $type)
    {
        $data = [
            'object_type' => Constant::ACTIVITY_TASK,
            'object_id' => $track->task_id,
            'action' => $type == 'start' ? 'started' : 'committed',
            'column' => 'time_tracking',
            'old_value' => null,
            'new_value' => $track->billable_minutes,
            'description' => $type == 'start' ? 'time tracking started' : 'logged time ' . $track->billable_minutes . ' minutes',
            'settings' => null,
            'created_by' => $track->user_id,
        ];

        \FluentBoards\App\Services\Helper::createActivity($data);
    }
}

