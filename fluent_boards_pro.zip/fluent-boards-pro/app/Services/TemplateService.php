<?php

namespace FluentBoardsPro\App\Services;

use FluentBoards\App\App;
use FluentBoards\App\Models\Attachment;
use FluentBoards\App\Models\Board;
use FluentBoards\App\Models\Stage;
use FluentBoards\App\Models\Label;
use FluentBoards\App\Models\Relation;
use FluentBoards\App\Models\Task;
use FluentBoards\App\Models\TaskMeta;
use FluentBoards\App\Services\AttachmentFileService;
use FluentBoards\App\Services\BoardService;
use FluentBoards\App\Services\Constant;
use FluentBoards\App\Services\LabelService;
use FluentBoards\App\Services\PermissionManager;
use FluentBoards\App\Services\StageService;
use FluentBoards\App\Services\TaskService;
use FluentBoards\Framework\Support\Arr;
use FluentBoardsPro\App\Models\CustomField;
use FluentBoardsPro\App\Services\Constant as ProConstant;
use RuntimeException;
use Throwable;

class TemplateService
{
    private $boardService;
    private $stageService;
    private $labelService;
    private $taskService;

    /** Attachment IDs owned by the current save, or null outside a save operation. */
    private $templateSaveAttachmentIds = null;

    const CACHE_KEY = 'fbs_default_template_catalog_v2';
    const CACHE_DURATION = HOUR_IN_SECONDS;
    const CATALOG_MAX_BYTES = 262144;
    const TEMPLATE_MAX_BYTES = 1048576;
    private const TEMPLATE_SAVE_LOCK_TIMEOUT = 5;

    public function __construct()
    {
        $this->boardService = new BoardService();
        $this->stageService = new StageService();
        $this->labelService = new LabelService();
        $this->taskService = new TaskService();
    }

    /**
     * Get lightweight built-in template cards from the cached catalog.
     *
     * @return array
     */
    public function getDefaultTemplates()
    {
        $templates = $this->getCachedDefaultTemplates();

        return array_values(array_map(function ($template) {
            return $this->formatDefaultTemplateSummary($template);
        }, $templates));
    }

    /**
     * Get the small catalog, limited to board types supported by this install.
     *
     * @return array
     */
    private function getCachedDefaultTemplates()
    {
        $templates = get_transient(self::CACHE_KEY);

        if ($templates === false) {
            $templates = $this->fetchDefaultTemplatesFromRemote();
            set_transient(self::CACHE_KEY, $templates, self::CACHE_DURATION);
        }

        // Check availability after reading the cache so add-on changes apply immediately.
        return array_values(array_filter($templates, function ($template) {
            return Arr::get($template, 'type', 'to-do') === 'to-do' || defined('FLUENT_ROADMAP');
        }));
    }

    /**
     * Fetch and validate the versioned catalog of template metadata.
     *
     * @return array
     */
    private function fetchDefaultTemplatesFromRemote()
    {
        $catalog = $this->fetchRemoteJson(FLUENT_BOARDS_PRO_REMOTE_ASSETS_URL . '/catalog.json', self::CATALOG_MAX_BYTES);

        if (Arr::get($catalog, 'version') !== 1 || !isset($catalog['templates']) || !is_array($catalog['templates'])) {
            throw new \RuntimeException(__('Built-in template catalog is invalid', 'fluent-boards-pro'));
        }

        $templates = [];
        $seenIds = [];
        foreach ($catalog['templates'] as $entry) {
            if (!is_array($entry)) {
                continue;
            }

            $id = sanitize_key(Arr::get($entry, 'id', ''));
            $url = Arr::get($entry, 'template_url', '');
            $title = Arr::get($entry, 'title', '');
            if (!$id || !is_scalar($title) || $title === '' || isset($seenIds[$id]) || !$this->isAllowedTemplateUrl($url)) {
                continue;
            }

            $type = Arr::get($entry, 'type', 'to-do');
            if (!in_array($type, ['to-do', 'roadmap'], true)) {
                continue;
            }

            $seenIds[$id] = true;
            $backgroundUrl = Arr::get($entry, 'background_url');
            $backgroundUrl = is_string($backgroundUrl) && strpos($backgroundUrl, 'https://') === 0 && wp_http_validate_url($backgroundUrl)
                ? esc_url_raw($backgroundUrl)
                : '';
            $backgroundColor = Arr::get($entry, 'background_color');
            $backgroundColor = is_string($backgroundColor) ? trim($backgroundColor) : '';
            if ($backgroundColor && !sanitize_hex_color($backgroundColor)
                && !preg_match('/^linear-gradient\([0-9]{1,3}deg, #[0-9a-fA-F]{6} [0-9]{1,3}%, #[0-9a-fA-F]{6} [0-9]{1,3}%\)$/', $backgroundColor)) {
                $backgroundColor = '';
            }

            $templates[] = [
                'id' => $id,
                'title' => sanitize_text_field($title),
                'description' => sanitize_text_field(Arr::get($entry, 'description', '')),
                'category' => sanitize_key(Arr::get($entry, 'category', 'general')),
                'type' => $type,
                'background' => $this->catalogBackground($backgroundUrl, $backgroundColor),
                'preview_image' => $backgroundUrl,
                'template_url' => $url,
                'stages_count' => absint(Arr::get($entry, 'stages_count', 0)),
                'labels_count' => absint(Arr::get($entry, 'labels_count', 0)),
                'tasks_count' => absint(Arr::get($entry, 'tasks_count', 0)),
            ];
        }

        if ($catalog['templates'] && !$templates) {
            throw new \RuntimeException(__('Built-in template catalog is invalid', 'fluent-boards-pro'));
        }

        return $templates;
    }

    /**
     * Accept only JSON files in the configured public template directory.
     */
    private function isAllowedTemplateUrl($url)
    {
        $templateUrlPattern = '~^' . preg_quote(FLUENT_BOARDS_PRO_REMOTE_ASSETS_URL, '~') . '/templates/([^/?#]+)\.json$~';
        if (!is_string($url) || !preg_match($templateUrlPattern, $url, $matches)) {
            return false;
        }

        $filename = rawurldecode($matches[1]);

        return $filename !== '' && $filename !== '.' && $filename !== '..'
            && (bool) preg_match('/^[A-Za-z0-9 _&.-]+$/', $filename)
            && strpos($filename, '..') === false;
    }

    /**
     * Download bounded JSON over verified HTTPS without redirects.
     */
    private function fetchRemoteJson($url, $maxBytes)
    {
        $response = wp_safe_remote_get($url, [
            'timeout' => 15,
            'redirection' => 0,
            'sslverify' => true,
            'limit_response_size' => $maxBytes + 1,
            'headers' => ['Accept' => 'application/json'],
        ]);

        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
            throw new \RuntimeException(__('Built-in template could not be downloaded', 'fluent-boards-pro'));
        }

        $body = wp_remote_retrieve_body($response);
        if (strlen($body) > $maxBytes) {
            throw new \RuntimeException(__('Built-in template exceeds the size limit', 'fluent-boards-pro'));
        }

        $data = json_decode($body, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($data)) {
            throw new \RuntimeException(__('Built-in template JSON is invalid', 'fluent-boards-pro'));
        }

        return $data;
    }

    /**
     * Build the card and board background from public catalog metadata.
     */
    private function catalogBackground($imageUrl, $color)
    {
        if ($imageUrl) {
            return ['is_image' => true, 'image_url' => $imageUrl, 'color' => null];
        }

        return ['is_image' => false, 'image_url' => null, 'color' => $color ?: null];
    }

    /**
     * Format a catalog entry for the gallery without its private fetch URL.
     */
    private function formatDefaultTemplateSummary($template)
    {
        return [
            'id' => (string) Arr::get($template, 'id'),
            'title' => Arr::get($template, 'title', ''),
            'description' => Arr::get($template, 'description', ''),
            'category' => Arr::get($template, 'category', 'general'),
            'type' => Arr::get($template, 'type', 'to-do'),
            'background' => $this->normalizeBackground(Arr::get($template, 'background')),
            'preview_image' => Arr::get($template, 'preview_image', ''),
            'stages_count' => Arr::get($template, 'stages_count', 0),
            'labels_count' => Arr::get($template, 'labels_count', 0),
            'tasks_count' => Arr::get($template, 'tasks_count', 0),
        ];
    }

    /**
     * Get user's own templates
     *
     * @return array
     */
    public function getUserTemplates()
    {
        $boards = $this->getAccessibleUserTemplateQuery()->get();

        return $boards->map(function ($board) {
            return $this->formatUserTemplateSummary($board);
        })->values()->toArray();
    }

    /**
     * Build the current user's source-board-scoped template query.
     *
     * @param int|null $userId User whose source-board access should be applied.
     * @return \FluentBoards\Framework\Database\Orm\Builder
     */
    private function getAccessibleUserTemplateQuery($userId = null)
    {
        $userId = $userId === null ? get_current_user_id() : absint($userId);
        $query = Board::query()
            ->whereIn('type', ['to-do', 'roadmap'])
            ->availableInCurrentInstall()
            ->onlyTemplates();

        if (!$userId) {
            return $query->where('id', 0);
        }

        return $query->byAccessUser($userId);
    }

    /**
     * Resolve a user template without exposing inaccessible source boards.
     *
     * @param int $templateId
     * @param int|null $userId User whose source-board access should be applied.
     * @return Board
     */
    private function findAccessibleUserTemplate($templateId, $userId = null)
    {
        return $this->getAccessibleUserTemplateQuery($userId)->findOrFail(absint($templateId));
    }

    /**
     * Format a saved template board for the gallery list.
     *
     * @param Board $board
     * @return array
     */
    private function formatUserTemplateSummary($board)
    {
        $stages = Stage::where('board_id', $board->id)
            ->where('type', 'stage')
            ->whereNull('archived_at')
            ->orderBy('position', 'asc')
            ->get()
            ->map(function ($stage) {
                return $this->normalizeStageForPreview($stage);
            })
            ->toArray();

        $labels = Label::where('board_id', $board->id)
            ->where('type', 'label')
            ->whereNull('archived_at')
            ->orderBy('position', 'asc')
            ->get()
            ->map(function ($label) {
                return $this->normalizeLabelForPreview($label);
            })
            ->toArray();

        // Count the actual top-level tasks rather than the settings snapshot, which
        // is only present on boards that were themselves created from a template.
        $tasksCount = Task::where('board_id', $board->id)
            ->whereNull('archived_at')
            ->whereNull('parent_id')
            ->count();

        return [
            'id' => $board->id,
            'title' => $board->title,
            'description' => Arr::get($board->settings, 'template_description', $board->description),
            'category' => Arr::get($board->settings, 'template_category', 'custom'),
            'type' => $board->type,
            'background' => $this->normalizeBackground($board->background),
            'stages' => $stages,
            'labels' => $labels,
            'stages_count' => count($stages),
            'labels_count' => count($labels),
            'tasks_count' => $tasksCount,
            'created_at' => $board->created_at,
            'can_manage' => PermissionManager::isAdmin() || PermissionManager::isBoardManager($board->id),
        ];
    }

    /**
     * Import a built-in template atomically, reserving its original title within accessible templates.
     *
     * @param string $templateId Catalog identifier; content and title are resolved on the server.
     * @return array Saved template gallery summary.
     */
    public function saveDefaultTemplate($templateId)
    {
        global $wpdb;

        $templateId = sanitize_text_field($templateId);
        $template = $this->findDefaultTemplateById($templateId);
        if (!$template) {
            throw new RuntimeException(__('Template not found', 'fluent-boards-pro'));
        }

        $title = sanitize_text_field(Arr::get($template, 'title', ''));
        // MySQL locks are server-wide; scope equal-title saves to this database and site.
        $lockName = 'fbs_template_save_' . md5(DB_NAME . '|' . $wpdb->prefix . '|' . $title);
        $locked = $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, %d)', $lockName, self::TEMPLATE_SAVE_LOCK_TIMEOUT));
        if ((string) $locked !== '1') {
            throw new RuntimeException(__('Another template save is in progress. Please try again.', 'fluent-boards-pro'), 409);
        }

        $db = App::getInstance('db');
        $this->templateSaveAttachmentIds = [];
        try {
            $db->beginTransaction();
            try {
                $board = $this->importDefaultTemplate($template, $title, true, null, [], null, true);
                $existingTitles = $this->getAccessibleUserTemplateQuery()
                    ->where('id', '!=', $board->id)
                    ->where('title', $title)
                    ->pluck('title')->all();

                // Compare exactly in PHP: the database collation can ignore case and accents.
                if (in_array($title, $existingTitles, true)) {
                    $board->title = $title . ' - ' . $board->id;
                    if (!$board->save()) {
                        throw new RuntimeException(__('Template could not be saved', 'fluent-boards-pro'));
                    }
                }

                $summary = $this->formatUserTemplateSummary($board);
                $db->commit();
            } catch (Throwable $exception) {
                try {
                    // WordPress needs the still-visible attachment metadata to remove image files.
                    foreach ($this->templateSaveAttachmentIds as $attachmentId) {
                        wp_delete_attachment($attachmentId, true);
                    }
                } finally {
                    $db->rollBack();
                }
                throw $exception;
            }
        } finally {
            $this->templateSaveAttachmentIds = null;
            $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lockName));
        }

        /** Fires after the independent template and all supported content have been saved. */
        do_action('fluent_boards/default_template_saved', $board, $templateId);

        return $summary;
    }

    /**
     * Convert a board to a template
     *
     * @param int $boardId
     * @param string $description
     * @param string $category
     * @return Board
     */
    public function makeTemplate($boardId, $description = '', $category = '')
    {
        $board = Board::findOrFail($boardId);

        $settings = $board->settings ?: [];
        $settings['is_template'] = true;

        if (!empty($description)) {
            $settings['template_description'] = sanitize_textarea_field($description);
        }

        if (!empty($category)) {
            $settings['template_category'] = sanitize_text_field($category);
        }

        $board->settings = $settings;
        $board->save();

        return $board->fresh();
    }

    /**
     * Convert a template back to a regular board
     *
     * @param int $boardId
     * @return Board
     */
    public function convertToBoard($boardId)
    {
        $board = Board::findOrFail($boardId);

        $settings = $board->settings ?: [];
        unset($settings['is_template']);
        unset($settings['template_description']);
        unset($settings['template_category']);

        $board->settings = $settings;
        $board->save();

        return $board->fresh();
    }

    /**
     * Update template settings
     *
     * @param int $boardId
     * @param array $data
     * @return Board
     */
    public function updateTemplateSettings($boardId, $data)
    {
        $board = Board::findOrFail($boardId);

        $settings = $board->settings ?: [];

        if (isset($data['template_description'])) {
            $settings['template_description'] = sanitize_textarea_field($data['template_description']);
        }

        if (isset($data['template_category'])) {
            $settings['template_category'] = sanitize_text_field($data['template_category']);
        }

        $board->settings = $settings;
        $board->save();

        return $board->fresh();
    }

    /**
     * Sanitizes optional source stage identifiers while preserving an omitted selection.
     *
     * @param mixed $stageIds
     * @param bool $numeric
     * @return array|null
     */
    private function normalizeSelectedStageIds($stageIds, $numeric = false)
    {
        if ($stageIds === null) {
            return null;
        }

        $normalizedIds = [];
        foreach ((array) $stageIds as $stageId) {
            if (!is_scalar($stageId)) {
                continue;
            }

            $stageId = $numeric
                ? absint($stageId)
                : sanitize_text_field((string) $stageId);

            if ($stageId === '' || ($numeric && !$stageId)) {
                continue;
            }

            $normalizedIds[] = $stageId;
        }

        return array_values(array_unique($normalizedIds, SORT_REGULAR));
    }

    /**
     * Sanitizes user-supplied stage titles without collapsing intentional duplicates.
     *
     * @param mixed $stages
     * @return array
     */
    private function sanitizeAdditionalStages($stages)
    {
        if (!is_array($stages)) {
            return [];
        }

        $sanitizedStages = [];
        foreach ($stages as $stage) {
            if (!is_array($stage)) {
                continue;
            }

            $title = Arr::get($stage, 'title', '');
            if (!is_scalar($title)) {
                continue;
            }

            $title = sanitize_text_field((string) $title);
            if ($title === '') {
                continue;
            }

            $title = function_exists('mb_substr')
                ? mb_substr($title, 0, 100)
                : substr($title, 0, 100);

            $sanitizedStages[] = ['title' => $title];
        }

        return $sanitizedStages;
    }

    /**
     * Filters default template stages and keeps their original identifiers for task mapping.
     *
     * @param array $stages
     * @param array|null $selectedStageIds
     * @return array
     */
    private function selectDefaultTemplateStages($stages, $selectedStageIds)
    {
        $selectedLookup = $selectedStageIds === null
            ? null
            : array_fill_keys(array_map('strval', $selectedStageIds), true);
        $selectedStages = [];

        foreach ((array) $stages as $index => $stage) {
            if (!is_array($stage)) {
                continue;
            }

            $sourceStageId = isset($stage['id']) && is_scalar($stage['id'])
                ? sanitize_text_field((string) $stage['id'])
                : (string) $index;

            if ($sourceStageId === '') {
                $sourceStageId = (string) $index;
            }

            if ($selectedLookup !== null && !isset($selectedLookup[$sourceStageId])) {
                continue;
            }

            $stage['_source_stage_id'] = $sourceStageId;
            $selectedStages[] = $stage;
        }

        return $selectedStages;
    }

    /**
     * Prevents creation of a board without any retained or additional stages.
     *
     * @param array $selectedStages
     * @param array $additionalStages
     * @return void
     * @throws \Exception
     */
    private function validateStageSelection($selectedStages, $additionalStages)
    {
        if (!$selectedStages && !$additionalStages) {
            throw new \Exception(__('At least one stage is required', 'fluent-boards-pro'));
        }
    }

    /**
     * Appends sanitized open stages after the copied template structure.
     *
     * @param Board $board
     * @param array $stages
     * @return void
     */
    private function createAdditionalStages($board, $stages)
    {
        if (!$stages) {
            return;
        }

        $lastStage = $this->stageService->getLastPositionOfStagesOfBoard($board->id);
        $position = $lastStage ? (float) $lastStage->position : 0;

        foreach ($stages as $stage) {
            $position++;
            $settings = [
                'default_task_status' => 'open',
                'is_template'         => false,
            ];

            if ($board->type === 'roadmap') {
                $settings['is_public'] = true;
            }

            Stage::create([
                'board_id' => $board->id,
                'title'    => $stage['title'],
                'slug'     => sanitize_title($stage['title']),
                'type'     => 'stage',
                'position' => $position,
                'settings' => $settings,
            ]);
        }
    }

    /**
     * Resolves selected active stage IDs within a user template board.
     *
     * @param int $templateId
     * @param array|null $selectedStageIds
     * @return array
     */
    private function getSelectedUserTemplateStageIds($templateId, $selectedStageIds)
    {
        $stageQuery = Stage::where('board_id', $templateId)
            ->where('type', 'stage')
            ->whereNull('archived_at')
            ->orderBy('position', 'asc');

        if ($selectedStageIds !== null) {
            if (!$selectedStageIds) {
                return [];
            }

            $stageQuery->whereIn('id', $selectedStageIds);
        }

        return $stageQuery->pluck('id')->map(function ($stageId) {
            return absint($stageId);
        })->filter()->values()->toArray();
    }

    /**
     * Builds the active task query, selecting subtasks through their retained parent tasks.
     *
     * @param int $templateId
     * @param array|null $sourceStageIds
     * @return mixed
     */
    private function getUserTemplateTaskQuery($templateId, $sourceStageIds = null)
    {
        $query = Task::where('board_id', $templateId)
            ->whereNull('archived_at');

        if (is_array($sourceStageIds)) {
            $parentTasks = Task::where('board_id', $templateId)
                ->whereNull('archived_at')
                ->whereNull('parent_id')
                ->whereIn('stage_id', $sourceStageIds ?: [0])
                ->select('id');

            // Subtasks belong to their parent's stage and may have no stage_id of their own.
            $query->where(function ($query) use ($sourceStageIds, $parentTasks) {
                $query->where(function ($query) use ($sourceStageIds) {
                    $query->whereNull('parent_id')
                        ->whereIn('stage_id', $sourceStageIds ?: [0]);
                })->orWhereIn('parent_id', $parentTasks);
            });
        }

        return $query;
    }

    /**
     * Creates sanitized, persistence-safe labels for a new board and maps valid source labels for copied tasks.
     *
     * @param Board $board
     * @param array $labels
     * @param array $validSourceLabelIds
     * @return array
     */
    private function createSelectedLabelsForBoard($board, $labels, $validSourceLabelIds)
    {
        $validSourceLabels = array_fill_keys(array_map('strval', $validSourceLabelIds), true);
        $labelMap = [];
        $position = 0;

        foreach ((array) $labels as $labelData) {
            if (!is_array($labelData)) {
                continue;
            }

            $title = Arr::get($labelData, 'label', '');
            $bgColor = Arr::get($labelData, 'bg_color', '');
            $color = Arr::get($labelData, 'color', '');

            $title = is_scalar($title) ? sanitize_text_field((string) $title) : '';
            $title = function_exists('mb_substr')
                ? mb_substr($title, 0, 100)
                : substr($title, 0, 100);
            $bgColor = is_scalar($bgColor) ? sanitize_hex_color((string) $bgColor) : null;
            $color = is_scalar($color) ? sanitize_hex_color((string) $color) : null;

            if ($title === '' && !$bgColor) {
                continue;
            }

            $slug = sanitize_title($title);
            if (strlen($slug) > 100) {
                // Preserve complete percent-encoded multibyte characters while enforcing the term schema limit.
                $decodedSlug = urldecode($slug);
                $slug = $decodedSlug === $slug
                    ? substr($slug, 0, 100)
                    : utf8_uri_encode($decodedSlug, 100, true);
                $slug = rtrim($slug, '-');
            }

            $position++;
            $newLabel = Label::create([
                'board_id' => $board->id,
                'title' => $title,
                'slug' => $slug,
                'type' => 'label',
                'position' => $position,
                'color' => $color ?: null,
                'bg_color' => $bgColor ?: null,
                'settings' => $this->labelPresetSettings(Arr::get($labelData, 'color_preset', '')),
            ]);

            $sourceId = Arr::get($labelData, 'source_id');
            if (!is_scalar($sourceId) || $sourceId === '') {
                continue;
            }

            $sourceId = sanitize_text_field((string) $sourceId);
            if (isset($validSourceLabels[$sourceId])) {
                $labelMap[$sourceId] = $newLabel->id;
            }
        }

        return $labelMap;
    }

    /**
     * Copy active custom field definitions from a user template board to a new board.
     *
     * @param int $templateId
     * @param Board $newBoard
     * @return array
     */
    private function copyCustomFieldsOfBoard($templateId, $newBoard)
    {
        $customFields = CustomField::where('board_id', absint($templateId))
            ->whereNull('archived_at')
            ->orderBy('position', 'asc')
            ->get();

        $customFieldMap = [];

        foreach ($customFields as $customField) {
            $newCustomField = CustomField::create([
                'board_id' => $newBoard->id,
                'title' => $customField->title,
                'slug' => $customField->slug,
                'type' => $customField->type ?: 'custom-field',
                'position' => $customField->position,
                'settings' => $customField->settings ?: [],
                'color' => $customField->color,
                'bg_color' => $customField->bg_color,
            ]);

            $customFieldMap[(int) $customField->id] = (int) $newCustomField->id;
        }

        return $customFieldMap;
    }

    /**
     * Create a board from a selected remote export, copying active tasks and fields.
     *
     * @param string $templateId
     * @param string $boardTitle
     * @param bool $includeLabels
     * @param array|null $selectedStageIds
     * @param array $additionalStages
     * @param array|null $selectedLabels
     * @return Board
     */
    public function createFromDefaultTemplate(
        $templateId,
        $boardTitle,
        $includeLabels = true,
        $selectedStageIds = null,
        $additionalStages = [],
        $selectedLabels = null
    )
    {
        $templateId = sanitize_text_field($templateId);
        $boardTitle = sanitize_text_field($boardTitle);
        $template = $this->findDefaultTemplateById($templateId);

        if (!$template) {
            throw new \Exception(__('Template not found', 'fluent-boards-pro'));
        }

        return $this->importDefaultTemplate($template, $boardTitle, $includeLabels, $selectedStageIds, $additionalStages, $selectedLabels);
    }

    /** Import supported catalog content into a regular board or a saved template. */
    private function importDefaultTemplate(
        $template,
        $boardTitle,
        $includeLabels = true,
        $selectedStageIds = null,
        $additionalStages = [],
        $selectedLabels = null,
        $asTemplate = false
    )
    {
        $selectedStageIds = $this->normalizeSelectedStageIds($selectedStageIds);
        $additionalStages = $this->sanitizeAdditionalStages($additionalStages);
        $stages = $this->selectDefaultTemplateStages(
            Arr::get($template, 'stages', []),
            $selectedStageIds
        );
        $this->validateStageSelection($stages, $additionalStages);

        // Create the board
        $boardData = [
            'title' => $boardTitle,
            'description' => wp_kses_post(Arr::get($template, 'description', '')),
            'type' => Arr::get($template, 'type', 'to-do'),
            'created_by' => get_current_user_id(),
        ];

        // Add background if available, downloading remote images locally
        if (!empty($template['background'])) {
            $background = $template['background'];
            if (!empty($background['is_image']) && !empty($background['image_url'])) {
                $localUrl = $this->downloadRemoteImage($background['image_url']);
                if ($localUrl) {
                    $background['image_url'] = $localUrl;
                } else {
                    $background['is_image'] = false;
                    $background['image_url'] = null;
                }
            }
            $boardData['background'] = $background;
        }

        $boardData = apply_filters('fluent_boards/before_create_board', $boardData);
        if ($asTemplate) {
            $boardData['settings'] = array_merge((array) Arr::get($boardData, 'settings', []), [
                'is_template' => true,
                'template_description' => sanitize_textarea_field(Arr::get($template, 'description', '')),
                'template_category' => sanitize_text_field(Arr::get($template, 'category', 'custom')),
            ]);
            $boardData['title'] = $boardTitle;
        }
        $board = Board::create($boardData);

        // Set current user as admin
        $this->boardService->setCurrentUserPreferencesOnBoardCreate($board);

        // Create stages from template and map old stage IDs to new ones
        $stageMap = [];
        foreach ($stages as $index => $stageData) {
            $newStage = Stage::create([
                'board_id' => $board->id,
                'title' => sanitize_text_field($stageData['title']),
                'slug' => sanitize_title($stageData['title']),
                'type' => 'stage',
                'position' => absint(Arr::get($stageData, 'position', $index + 1)) ?: $index + 1,
                'bg_color' => sanitize_hex_color(Arr::get($stageData, 'bg_color', '')) ?: null,
                'settings' => Arr::get($stageData, 'settings', ['default_task_status' => 'open']),
            ]);

            $stageKey = $stageData['_source_stage_id'];
            $stageMap[$stageKey] = $newStage->id;
        }

        $this->createAdditionalStages($board, $additionalStages);

        // Create labels from template if requested and map old label IDs to new ones
        $labelMap = [];
        if ($includeLabels) {
            $labels = Arr::get($template, 'labels', []);
            if ($selectedLabels === null) {
                foreach ($labels as $index => $labelData) {
                    $newLabel = Label::create([
                        'board_id' => $board->id,
                        'title' => sanitize_text_field($labelData['title']),
                        'slug' => sanitize_title($labelData['title']),
                        'type' => 'label',
                        'position' => $index + 1,
                        'color' => sanitize_hex_color(Arr::get($labelData, 'color', '')) ?: null,
                        'bg_color' => sanitize_hex_color(Arr::get($labelData, 'bg_color', '')) ?: null,
                        'settings' => $this->labelPresetSettings(Arr::get($labelData, 'color_preset', Arr::get($labelData, 'settings.color_preset', ''))),
                    ]);

                    // Map old label ID to new label ID for task creation.
                    $labelKey = $labelData['id'] ?? $index;
                    $labelMap[$labelKey] = $newLabel->id;
                }
            } else {
                $sourceLabelIds = [];
                foreach ($labels as $index => $labelData) {
                    if (!is_array($labelData)) {
                        continue;
                    }

                    $sourceLabelIds[] = isset($labelData['id']) && is_scalar($labelData['id'])
                        ? $labelData['id']
                        : $index;
                }

                $labelMap = $this->createSelectedLabelsForBoard($board, $selectedLabels, $sourceLabelIds);
            }
        } else {
            // Create default labels
            $this->labelService->createDefaultLabel($board->id);
        }

        $customFieldMap = $this->createDefaultTemplateCustomFields($board, Arr::get($template, 'custom_fields', []));

        // Create tasks from template
        $tasks = Arr::get($template, 'tasks', []);
        if ($selectedStageIds !== null) {
            // Explicit selection means tasks from removed stages must not fall back to another stage.
            $tasks = array_values(array_filter($tasks, function ($task) use ($stageMap) {
                $sourceStageId = Arr::get($task, 'stage_id');

                return is_scalar($sourceStageId)
                    && array_key_exists((string) $sourceStageId, $stageMap);
            }));
        }

        if (!empty($tasks)) {
            Task::withoutTaskCreatedEvent(function () use ($board, $tasks, $stageMap, $labelMap, $customFieldMap) {
                $this->createTasksFromTemplate($board, $tasks, $stageMap, $labelMap, $customFieldMap);
            });

            $settings = $board->settings ?: [];
            $settings['tasks_count'] = Task::where('board_id', $board->id)->whereNull('parent_id')->count();
            $board->settings = $settings;
            $board->save();
        }

        return $board->fresh(['stages', 'labels']);
    }

    /**
     * Copy active parent tasks, their labels, field values, and nested subtasks.
     *
     * @param Board $board
     * @param array $tasks
     * @param array $stageMap
     * @param array $labelMap
     * @param array $customFieldMap
     * @return void
     */
    private function createTasksFromTemplate($board, $tasks, $stageMap, $labelMap, $customFieldMap = [])
    {
        // Get the first stage as fallback for tasks without a valid stage_id
        $firstStageId = !empty($stageMap) ? reset($stageMap) : null;

        foreach ($tasks as $taskData) {
            // Map stage ID — try explicit id, then fall back to first stage
            $stageId = isset($taskData['stage_id']) && isset($stageMap[$taskData['stage_id']])
                ? $stageMap[$taskData['stage_id']]
                : $firstStageId;

            if (!$stageId) {
                continue;
            }

            // Build task settings with cover image
            $taskSettings = [
                'cover' => ['backgroundColor' => ''],
                'subtask_count' => 0,
                'attachment_count' => 0,
                'subtask_completed_count' => 0,
            ];

            $cover = Arr::get($taskData, 'settings.cover', []);
            if (!empty($cover['backgroundColor'])) {
                $taskSettings['cover']['backgroundColor'] = sanitize_hex_color($cover['backgroundColor']) ?: '';
            }
            if (!empty($cover['backgroundImage']) && is_string($cover['backgroundImage'])
                && strpos($cover['backgroundImage'], 'https://') === 0
                && wp_http_validate_url($cover['backgroundImage'])) {
                $localUrl = $this->downloadRemoteImage($cover['backgroundImage']);
                if ($localUrl) {
                    $taskSettings['cover']['backgroundImage'] = $localUrl;
                }
            }

            // Create the task
            $task = Task::create([
                'board_id' => $board->id,
                'stage_id' => $stageId,
                'title' => sanitize_text_field($taskData['title']),
                'description' => wp_kses_post(Arr::get($taskData, 'description', '')),
                'position' => (float) Arr::get($taskData, 'position', 1),
                'status' => sanitize_text_field(Arr::get($taskData, 'status', 'open')),
                'priority' => sanitize_text_field(Arr::get($taskData, 'priority', '') ?: ''),
                'settings' => $taskSettings,
                'due_at' => null,
                'started_at' => null,
                'created_by' => get_current_user_id(),
            ]);

            $this->attachDefaultTemplateRelations($task, $taskData, $labelMap, $customFieldMap);
            $this->createDefaultTemplateSubtasks($board, $task, $taskData, $customFieldMap);
        }
    }

    /**
     * Copy active custom-field definitions and map their source IDs.
     */
    private function createDefaultTemplateCustomFields($board, $fields)
    {
        $map = [];
        foreach ($fields as $field) {
            if (!is_array($field) || empty($field['title'])) {
                continue;
            }

            $settings = Arr::get($field, 'settings', []);
            $newField = CustomField::create([
                'board_id' => $board->id,
                'title' => sanitize_text_field($field['title']),
                'slug' => sanitize_title(Arr::get($field, 'slug') ?: $field['title']),
                'type' => 'custom-field',
                'position' => absint(Arr::get($field, 'position', 0)),
                'settings' => is_array($settings) && $this->isTemplatePrimitiveValue($settings)
                    ? $this->sanitizeTemplateValue($settings) : [],
                'color' => sanitize_hex_color(Arr::get($field, 'color', '')) ?: null,
                'bg_color' => sanitize_hex_color(Arr::get($field, 'bg_color', '')) ?: null,
            ]);

            $map[(string) $field['id']] = $newField->id;
        }

        return $map;
    }

    /**
     * Map only selected labels and validated custom-field values to a new task.
     */
    private function attachDefaultTemplateRelations($task, $source, $labelMap, $customFieldMap)
    {
        $labelIds = Arr::get($source, 'label_ids', []);
        if (!$labelIds && is_array(Arr::get($source, 'labels', []))) {
            $labelIds = array_column(Arr::get($source, 'labels', []), 'id');
        }

        foreach (array_unique((array) $labelIds) as $sourceId) {
            if (!is_scalar($sourceId) || !isset($labelMap[(string) $sourceId])) {
                continue;
            }

            Relation::create([
                'object_id' => $task->id,
                'object_type' => Constant::OBJECT_TYPE_TASK_LABEL,
                'foreign_id' => $labelMap[(string) $sourceId],
            ]);
        }

        foreach ((array) Arr::get($source, 'custom_fields', []) as $field) {
            if (!is_array($field) || !isset($field['id']) || !isset($customFieldMap[(string) $field['id']])) {
                continue;
            }

            $settings = $this->sanitizeDefaultTemplateFieldSettings(Arr::get($field, 'pivot.settings'));
            if ($settings === null) {
                continue;
            }

            Relation::create([
                'object_id' => $task->id,
                'object_type' => ProConstant::TASK_CUSTOM_FIELD,
                'foreign_id' => $customFieldMap[(string) $field['id']],
                'settings' => $settings,
            ]);
        }
    }

    /**
     * Decode an export's custom-field value without loading PHP objects.
     */
    private function sanitizeDefaultTemplateFieldSettings($settings)
    {
        if (is_string($settings)) {
            if (!is_serialized($settings) || preg_match('/(?:^|[;{}])E:[0-9]+:"/s', $settings)) {
                return null;
            }

            $settings = @unserialize($settings, ['allowed_classes' => false, 'max_depth' => 20]);
        }

        if (!is_array($settings) || !array_key_exists('value', $settings)
            || !$this->isTemplatePrimitiveValue($settings['value'])) {
            return null;
        }

        return ['value' => $this->sanitizeTemplateValue($settings['value'])];
    }

    /**
     * Reject objects and deeply nested values from remote custom-field data.
     */
    private function isTemplatePrimitiveValue($value, $depth = 0)
    {
        if ($depth > 20) {
            return false;
        }

        if (is_array($value)) {
            foreach ($value as $item) {
                if (!$this->isTemplatePrimitiveValue($item, $depth + 1)) {
                    return false;
                }
            }

            return true;
        }

        return $value === null || is_scalar($value);
    }

    /**
     * Sanitize strings recursively while retaining scalar field value types.
     */
    private function sanitizeTemplateValue($value)
    {
        if (is_array($value)) {
            $sanitized = [];
            foreach ($value as $key => $item) {
                $sanitized[is_string($key) ? sanitize_text_field($key) : $key] = $this->sanitizeTemplateValue($item);
            }

            return $sanitized;
        }

        return is_string($value) ? sanitize_text_field($value) : $value;
    }

    /**
     * Copy active subtasks into their source groups without old assignments or history.
     */
    private function createDefaultTemplateSubtasks($board, $parent, $source, $customFieldMap)
    {
        $groups = Arr::get($source, 'subtask_group', []);
        if (!$groups && !empty($source['subtasks'])) {
            $groups = [['value' => __('Default Subtask Group', 'fluent-boards-pro'), 'subtasks' => $source['subtasks']]];
        }

        foreach ((array) $groups as $group) {
            if (!is_array($group) || empty($group['subtasks']) || !is_array($group['subtasks'])) {
                continue;
            }

            $groupMeta = null;
            foreach ($group['subtasks'] as $subtask) {
                if (!is_array($subtask) || !empty($subtask['archived_at']) || empty($subtask['title'])) {
                    continue;
                }

                if (!$groupMeta) {
                    $groupMeta = TaskMeta::create([
                        'task_id' => $parent->id,
                        'key' => Constant::SUBTASK_GROUP_NAME,
                        'value' => sanitize_text_field(Arr::get($group, 'value', __('Default Subtask Group', 'fluent-boards-pro'))),
                    ]);
                }

                $newSubtask = Task::create([
                    'board_id' => $board->id,
                    'stage_id' => $parent->stage_id,
                    'parent_id' => $parent->id,
                    'title' => sanitize_text_field($subtask['title']),
                    'description' => wp_kses_post(Arr::get($subtask, 'description', '')),
                    'position' => (float) Arr::get($subtask, 'position', 1),
                    'status' => sanitize_text_field(Arr::get($subtask, 'status', 'open')),
                    'priority' => sanitize_text_field(Arr::get($subtask, 'priority', '')),
                    'due_at' => null,
                    'started_at' => null,
                    'created_by' => get_current_user_id(),
                ]);

                TaskMeta::create([
                    'task_id' => $newSubtask->id,
                    'key' => Constant::SUBTASK_GROUP_CHILD,
                    'value' => $groupMeta->id,
                ]);
                $this->attachDefaultTemplateRelations($newSubtask, $subtask, [], $customFieldMap);
            }
        }
    }

    /**
     * Create a board from a user template and queue its active tasks for copying.
     *
     * @param int    $templateId
     * @param string $boardTitle
     * @param bool   $includeTasks
     * @param bool   $includeLabels
     * @param array|null $selectedStageIds
     * @param array $additionalStages
     * @param array|null $selectedLabels
     * @param int|null $sourceAccessUserId User used to authorize the source board.
     * @return Board
     * @throws \Throwable
     */
    public function createFromUserTemplate(
        $templateId,
        $boardTitle,
        $includeTasks = false,
        $includeLabels = true,
        $selectedStageIds = null,
        $additionalStages = [],
        $selectedLabels = null,
        $sourceAccessUserId = null
    )
    {
        $templateId = absint($templateId);
        $boardTitle = sanitize_text_field($boardTitle);
        $templateBoard = $this->findAccessibleUserTemplate($templateId, $sourceAccessUserId);

        $selectedStageIds = $this->normalizeSelectedStageIds($selectedStageIds, true);
        $additionalStages = $this->sanitizeAdditionalStages($additionalStages);
        $sourceStageIds = $this->getSelectedUserTemplateStageIds($templateId, $selectedStageIds);
        $this->validateStageSelection($sourceStageIds, $additionalStages);

        $dbInstance = App::getInstance('db');
        $batchKey = null;
        $dbInstance->beginTransaction();

        try {
            $newBoard = $this->boardService->copyBoard([
                'title'           => $boardTitle,
                'type'            => $templateBoard->type,
                'source_board_id' => $templateId,
            ]);

            // Give the new board its own copy of the template's background image so
            // deleting the template later doesn't break the derived board's background
            $this->cloneBoardBackgroundFromTemplate($templateBoard, $newBoard);

            $labelMap = [];
            if ($includeLabels) {
                if ($selectedLabels === null) {
                    $labelMap = $this->labelService->copyLabelsOfBoard($templateId, $newBoard);
                } else {
                    $sourceLabelIds = Label::where('board_id', $templateId)
                        ->whereNull('archived_at')
                        ->pluck('id')
                        ->toArray();
                    $labelMap = $this->createSelectedLabelsForBoard(
                        $newBoard,
                        $selectedLabels,
                        $sourceLabelIds
                    );
                }
            } else {
                $this->labelService->createDefaultLabel($newBoard->id);
            }

            $customFieldMap = $this->copyCustomFieldsOfBoard($templateId, $newBoard);

            $stageMap = $this->stageService->copyStagesOfBoard(
                $newBoard,
                $templateId,
                'no',
                $sourceStageIds
            );
            $this->createAdditionalStages($newBoard, $additionalStages);

            if ($includeTasks) {
                $taskCount = $this->getUserTemplateTaskQuery($templateId, $sourceStageIds)->count();

                $settings = $newBoard->settings ?: [];
                $settings['task_creation_status'] = $taskCount > 0 ? 'pending' : 'completed';
                $settings['task_creation_total'] = $taskCount;

                if (!$taskCount) {
                    $settings['tasks_count'] = 0;
                }

                $newBoard->settings = $settings;
                $newBoard->save();

                if ($taskCount > 0) {
                    // Persist the initiating user because async requests have no current user.
                    $batchKey = 'fbs_user_tpl_copy_' . $newBoard->id;
                    $batchStored = set_transient($batchKey, [
                        'template_id'       => $templateId,
                        'stage_map'         => $stageMap,
                        'source_stage_ids'  => $sourceStageIds,
                        'label_map'         => $labelMap,
                        'custom_field_map'  => $customFieldMap,
                        'created_by'        => absint($newBoard->created_by ?: get_current_user_id()),
                        'offset'            => 0,
                        'task_map'          => [],
                        'subtask_group_map' => [],
                        'parent_task_count' => 0,
                    ], HOUR_IN_SECONDS);

                    if (!$batchStored) {
                        throw new \RuntimeException(__('Task copy state could not be prepared', 'fluent-boards-pro'));
                    }

                    $this->enqueueUserTemplateTaskCopy($newBoard->id);
                }
            }

            $dbInstance->commit();
        } catch (\Throwable $exception) {
            $dbInstance->rollBack();

            if ($batchKey) {
                delete_transient($batchKey);
            }

            throw $exception;
        }

        return $newBoard->fresh(['stages', 'labels']);
    }

    /**
     * Clone the template board's background attachment for a board created from it.
     *
     * copyBoard() copies the background array verbatim, so the new board's image_url
     * still points at the template's attachment. External URLs and color-only
     * backgrounds are left as they are.
     *
     * @param Board $templateBoard
     * @param Board $newBoard
     * @return void
     */
    private function cloneBoardBackgroundFromTemplate($templateBoard, $newBoard)
    {
        $background = $newBoard->background;

        if (!is_array($background) || empty($background['is_image']) || empty($background['id'])) {
            return;
        }

        $attachment = Attachment::find($background['id']);

        if (!$attachment
            || $attachment->object_type !== Constant::BOARD_BACKGROUND_IMAGE
            || (int) $attachment->object_id !== (int) $templateBoard->id
        ) {
            return;
        }

        $result = (new AttachmentFileService())->cloneAttachmentToBoard(
            $attachment,
            $newBoard->id,
            $newBoard->id,
            $attachment->object_type,
            $templateBoard->id
        );

        if (empty($result['new_attachment_id']) || empty($result['new_public_url'])) {
            return;
        }

        $background['id'] = $result['new_attachment_id'];
        $background['image_url'] = $result['new_public_url'];
        $newBoard->background = $background;
        $newBoard->save();
    }

    /**
     * Get preview data for a default template
     *
     * @param string $templateId
     * @return array
     */
    public function getDefaultTemplatePreview($templateId)
    {
        $template = $this->findDefaultTemplateById($templateId);

        if ($template) {
            return $this->formatDefaultTemplatePreview($template);
        }

        throw new \Exception(__('Template not found', 'fluent-boards-pro'));
    }

    /**
     * Get preview data for a user's template
     *
     * @param int $templateId
     * @return array
     */
    public function getUserTemplatePreview($templateId)
    {
        $board = $this->findAccessibleUserTemplate($templateId);

        $stages = Stage::where('board_id', $board->id)
            ->where('type', 'stage')
            ->whereNull('archived_at')
            ->orderBy('position', 'asc')
            ->get();

        $labels = Label::where('board_id', $board->id)
            ->where('type', 'label')
            ->whereNull('archived_at')
            ->orderBy('position', 'asc')
            ->get();

        $tasks = Task::with('labels')
            ->where('board_id', $board->id)
            ->whereNull('archived_at')
            ->whereNull('parent_id')
            ->orderBy('stage_id', 'asc')
            ->orderBy('position', 'asc')
            ->get();

        return [
            'id' => $board->id,
            'title' => $board->title,
            'description' => Arr::get($board->settings, 'template_description', $board->description),
            'category' => Arr::get($board->settings, 'template_category', 'custom'),
            'type' => $board->type,
            'background' => $this->normalizeBackground($board->background),
            'stages' => $stages->map(function ($stage) {
                return $this->normalizeStageForPreview($stage);
            })->toArray(),
            'labels' => $labels->map(function ($label) {
                return $this->normalizeLabelForPreview($label);
            })->toArray(),
            'tasks' => $tasks->map(function ($task) {
                return $this->normalizeTaskForPreview($task);
            })->toArray(),
            'stages_count' => $stages->count(),
            'labels_count' => $labels->count(),
            'tasks_count' => $tasks->count(),
            'created_at' => $board->created_at,
        ];
    }

    /**
     * Resolve an ID from the catalog, then fetch only its selected board export.
     *
     * @param string $templateId
     * @return array|null
     */
    private function findDefaultTemplateById($templateId)
    {
        foreach ($this->getCachedDefaultTemplates() as $template) {
            if ((string) Arr::get($template, 'id') === (string) $templateId) {
                $cacheKey = 'fbs_default_template_' . md5($template['id'] . '|' . $template['template_url']);
                $export = get_transient($cacheKey);

                if ($export === false) {
                    $export = $this->fetchRemoteJson($template['template_url'], self::TEMPLATE_MAX_BYTES);
                    $this->validateBoardExport($export, $template);
                    set_transient($cacheKey, $export, self::CACHE_DURATION);
                }

                $board = $export['board'];
                $stages = $this->activeExportRows($board['stages']);
                $labels = $this->activeExportRows($board['labels'], true);
                $stageIds = array_fill_keys(array_map('strval', array_column($stages, 'id')), true);
                $tasks = array_values(array_filter($this->activeExportRows($board['tasks']), function ($task) use ($stageIds) {
                    return empty($task['parent_id']) && isset($stageIds[(string) Arr::get($task, 'stage_id', '')]);
                }));

                return array_merge($template, [
                    'stages' => $stages,
                    'labels' => $labels,
                    'tasks' => $tasks,
                    'custom_fields' => $this->activeExportRows($board['custom_fields'] ?? []),
                ]);
            }
        }

        return null;
    }

    /**
     * Require a Fluent Boards export with the arrays used for preview and creation.
     */
    private function validateBoardExport($export, $entry)
    {
        $board = Arr::get($export, 'board');
        if (Arr::get($export, 'key') !== 'FluentBoards' || !is_array($board)
            || empty($board['title']) || Arr::get($board, 'type') !== $entry['type']
            || !isset($board['stages'], $board['labels'], $board['tasks'])
            || !is_array($board['stages']) || !is_array($board['labels']) || !is_array($board['tasks'])
            || (isset($board['custom_fields']) && !is_array($board['custom_fields']))
            || !$this->activeExportRows($board['stages'])) {
            throw new \RuntimeException(__('Built-in template export is invalid', 'fluent-boards-pro'));
        }
    }

    /**
     * Keep active export records with a usable source ID; labels may have no title.
     */
    private function activeExportRows($rows, $allowEmptyTitle = false)
    {
        if (!is_array($rows)) {
            return [];
        }

        return array_values(array_filter($rows, function ($row) use ($allowEmptyTitle) {
            return is_array($row) && empty($row['archived_at'])
                && isset($row['id'], $row['title'])
                && is_scalar($row['id']) && (string) $row['id'] !== ''
                && is_scalar($row['title']) && ($allowEmptyTitle || (string) $row['title'] !== '');
        }));
    }

    /**
     * Format a default template for the preview modal.
     *
     * @param array $template
     * @return array
     */
    private function formatDefaultTemplatePreview($template)
    {
        $stages = Arr::get($template, 'stages', []);
        usort($stages, function ($left, $right) {
            return (int) Arr::get($left, 'position', 0) <=> (int) Arr::get($right, 'position', 0);
        });
        $stages = array_values(array_map(function ($stage, $index) {
            return $this->normalizeStageForPreview($stage, $index);
        }, $stages, array_keys($stages)));

        $labels = array_values(array_map(function ($label, $index) {
            return $this->normalizeLabelForPreview($label, $index);
        }, Arr::get($template, 'labels', []), array_keys(Arr::get($template, 'labels', []))));

        $tasks = Arr::get($template, 'tasks', []);
        usort($tasks, function ($left, $right) {
            $leftStageId = (string) Arr::get($left, 'stage_id', '');
            $rightStageId = (string) Arr::get($right, 'stage_id', '');
            $stageCompare = strnatcmp($leftStageId, $rightStageId);
            if ($stageCompare !== 0) {
                return $stageCompare;
            }

            return (int) Arr::get($left, 'position', 0) <=> (int) Arr::get($right, 'position', 0);
        });
        $tasks = array_map(function ($task) {
            return $this->normalizeTaskForPreview($task);
        }, $tasks);

        return [
            'id' => (string) Arr::get($template, 'id'),
            'title' => Arr::get($template, 'title', ''),
            'description' => Arr::get($template, 'description', ''),
            'category' => Arr::get($template, 'category', 'general'),
            'type' => Arr::get($template, 'type', 'to-do'),
            'background' => $this->normalizeBackground(Arr::get($template, 'background')),
            'preview_image' => Arr::get($template, 'preview_image', ''),
            'stages' => $stages,
            'labels' => $labels,
            'tasks' => $tasks,
            'stages_count' => count($stages),
            'labels_count' => count($labels),
            'tasks_count' => count($tasks),
            'created_at' => Arr::get($template, 'created_at', ''),
        ];
    }

    /**
     * Normalize background data so the frontend can render a single shape.
     *
     * @param mixed $background
     * @return array|null
     */
    private function normalizeBackground($background)
    {
        $background = maybe_unserialize($background);

        if (empty($background) || !is_array($background)) {
            return null;
        }

        return [
            'color' => Arr::get($background, 'color'),
            'is_image' => (bool) Arr::get($background, 'is_image', false),
            'image_url' => Arr::get($background, 'image_url'),
        ];
    }

    /**
     * Normalize a stage for preview rendering.
     *
     * @param mixed $stage
     * @return array
     */
    private function normalizeStageForPreview($stage, $fallbackId = null)
    {
        return [
            'id' => Arr::get($stage, 'id', $fallbackId),
            'title' => Arr::get($stage, 'title', ''),
            'position' => (int) Arr::get($stage, 'position', 0),
            'bg_color' => Arr::get($stage, 'bg_color') ?: null,
        ];
    }

    /**
     * Normalize a label for preview rendering.
     *
     * @param mixed $label
     * @return array
     */
    private function normalizeLabelForPreview($label, $fallbackId = null)
    {
        return [
            'id' => Arr::get($label, 'id', $fallbackId),
            'title' => Arr::get($label, 'title', ''),
            'color' => Arr::get($label, 'color') ?: null,
            'bg_color' => Arr::get($label, 'bg_color') ?: null,
            'color_preset' => Arr::get($label, 'color_preset', Arr::get($label, 'settings.color_preset', '')),
        ];
    }

    /**
     * Retain only a known core label preset when a template creates a board.
     *
     * @param mixed $presetId
     * @return array
     */
    private function labelPresetSettings($presetId)
    {
        $presetId = is_scalar($presetId) ? sanitize_key((string) $presetId) : '';

        if (!\FluentBoards\App\Services\Constant::getLabelColorPreset($presetId)) {
            return [];
        }

        return [\FluentBoards\App\Services\Constant::LABEL_COLOR_PRESET_SETTING => $presetId];
    }

    /**
     * Normalize a task for preview rendering.
     *
     * @param mixed $task
     * @return array
     */
    private function normalizeTaskForPreview($task)
    {
        if (is_object($task) && method_exists($task, 'toArray')) {
            $taskArray = $task->toArray();
        } else {
            $taskArray = (array) $task;
        }

        $labelIds = Arr::get($taskArray, 'label_ids', []);

        if (!$labelIds && !empty($taskArray['labels']) && is_array($taskArray['labels'])) {
            $labelIds = array_values(array_filter(array_map(function ($label) {
                return (int) Arr::get($label, 'id');
            }, $taskArray['labels'])));
        }

        return [
            'id' => Arr::get($taskArray, 'id'),
            'stage_id' => Arr::get($taskArray, 'stage_id', 0),
            'title' => Arr::get($taskArray, 'title', ''),
            'description' => Arr::get($taskArray, 'description', ''),
            'position' => (int) Arr::get($taskArray, 'position', 0),
            'status' => Arr::get($taskArray, 'status', 'open'),
            'priority' => Arr::get($taskArray, 'priority', ''),
            'due_at' => Arr::get($taskArray, 'due_at'),
            'settings' => Arr::get($taskArray, 'settings', []) ?: [],
            'label_ids' => array_values(array_unique(array_filter((array) $labelIds, function ($labelId) {
                return $labelId !== null && $labelId !== '';
            }))),
        ];
    }

    /**
     * Number of tasks to process per batch
     */
    const TASK_BATCH_SIZE = 100;

    /**
     * Handle async task creation from default template data in chunks.
     * Reads batch state from a transient, processes one chunk, then
     * schedules the next chunk or marks creation as completed.
     *
     * @param int $boardId
     * @return void
     */
    public function handleAsyncCreateTasksFromTemplate($boardId)
    {
        $board = Board::find($boardId);
        if (!$board) {
            return;
        }

        $batchKey = 'fbs_tpl_tasks_' . $boardId;
        $batchData = get_transient($batchKey);

        if (!$batchData) {
            $this->markTaskCreationCompleted($board);
            return;
        }

        $tasks    = $batchData['tasks'];
        $stageMap = $batchData['stage_map'];
        $labelMap = $batchData['label_map'];
        $offset   = $batchData['offset'] ?? 0;

        $batch = array_slice($tasks, $offset, self::TASK_BATCH_SIZE);
        $this->createTasksFromTemplate($board, $batch, $stageMap, $labelMap);

        $nextOffset = $offset + self::TASK_BATCH_SIZE;

        if ($nextOffset < count($tasks)) {
            // More tasks remain — update offset and schedule next batch
            $batchData['offset'] = $nextOffset;
            set_transient($batchKey, $batchData, HOUR_IN_SECONDS);

            as_enqueue_async_action('fluent_boards/async_create_tasks_from_template', [
                $boardId,
            ], 'fluent-boards');
        } else {
            // All tasks created
            delete_transient($batchKey);
            $this->markTaskCreationCompleted($board);
        }
    }

    /**
     * Copy one retry-safe batch of tasks from a user template.
     *
     * @param int $newBoardId
     * @return void
     * @throws \Throwable
     */
    public function handleAsyncCopyTasksFromUserTemplate($newBoardId)
    {
        $newBoardId = absint($newBoardId);
        $newBoard = Board::find($newBoardId);
        if (!$newBoard) {
            return;
        }

        $batchKey  = 'fbs_user_tpl_copy_' . $newBoardId;
        $batchData = get_transient($batchKey);

        if (!$batchData) {
            if (Arr::get($newBoard->settings, 'task_creation_status') === 'completed') {
                return;
            }

            $this->updateTaskCreationStatus($newBoard, 'failed');
            throw new \RuntimeException(__('Task copy state is unavailable', 'fluent-boards-pro'));
        }

        if (Arr::get($newBoard->settings, 'task_creation_status') === 'failed') {
            $this->updateTaskCreationStatus($newBoard, 'pending');
        }

        $originalBatchData = $batchData;
        $templateId = absint($batchData['template_id']);
        $stageMap = $batchData['stage_map'];
        $sourceStageIds = array_key_exists('source_stage_ids', $batchData)
            ? $this->normalizeSelectedStageIds($batchData['source_stage_ids'], true)
            : null;
        $labelMap = $batchData['label_map'];
        $customFieldMap = $batchData['custom_field_map'] ?? [];
        $createdBy = absint($batchData['created_by'] ?? $newBoard->created_by);
        $offset = absint($batchData['offset'] ?? 0);
        $taskMap = $batchData['task_map'] ?? [];
        $subtaskGroupMap = $batchData['subtask_group_map'] ?? [];
        $parentTaskCount = absint($batchData['parent_task_count'] ?? 0);
        $dbInstance = App::getInstance('db');
        $dbInstance->beginTransaction();
        $previousUserId = get_current_user_id();

        // Preserve system ownership (ID 0) as well as user ownership in every async context.
        wp_set_current_user($createdBy);

        try {
            // Parent-first ordering keeps cross-batch parent and subtask maps complete.
            $tasks = $this->getUserTemplateTaskQuery($templateId, $sourceStageIds)
                ->orderByRaw('CASE WHEN parent_id IS NULL THEN 0 ELSE 1 END')
                ->orderBy('id')
                ->offset($offset)
                ->limit(self::TASK_BATCH_SIZE)
                ->get();

            if ($labelMap) {
                // Only parent task labels are copied, so bulk-load that relation for parent tasks only.
                $tasks->whereNull('parent_id')->load('labels');
            }

            $subtaskGroupsByTaskId = [];
            $subtaskGroupRelationsByTaskId = [];
            $taskIds = $tasks->pluck('id')->toArray();

            if ($taskIds) {
                // Load the two subtask-group meta types once for the whole batch.
                $taskMetas = TaskMeta::whereIn('task_id', $taskIds)
                    ->whereIn('key', [
                        Constant::SUBTASK_GROUP_NAME,
                        Constant::SUBTASK_GROUP_CHILD,
                    ])
                    ->orderBy('id')
                    ->get();

                foreach ($taskMetas as $taskMeta) {
                    $taskId = (int) $taskMeta->task_id;

                    if ($taskMeta->key === Constant::SUBTASK_GROUP_NAME) {
                        $subtaskGroupsByTaskId[$taskId][] = $taskMeta;
                        continue;
                    }

                    if (!isset($subtaskGroupRelationsByTaskId[$taskId])) {
                        $subtaskGroupRelationsByTaskId[$taskId] = $taskMeta;
                    }
                }
            }

            $createdTaskMap = [];

            foreach ($tasks as $task) {
                // Never promote a subtask when its parent was filtered out with a removed stage.
                if ($task->parent_id && !isset($taskMap[$task->parent_id])) {
                    continue;
                }

                $newTaskData = [
                    'title'       => $task->title,
                    'parent_id'   => $task->parent_id && isset($taskMap[$task->parent_id]) ? $taskMap[$task->parent_id] : null,
                    'description' => $task->description,
                    'board_id'    => $newBoard->id,
                    'stage_id'    => $stageMap[$task->stage_id] ?? null,
                    'status'      => $task->status,
                    'priority'    => $task->priority,
                    'position'    => $task->position,
                    'due_at'      => $task->due_at,
                    'created_by'  => $createdBy,
                    'settings'    => [
                        'cover' => [
                            'backgroundColor' => $task->settings['cover']['backgroundColor'] ?? '',
                        ]
                    ],
                ];

                if (!$task->parent_id && !$newTaskData['stage_id']) {
                    continue;
                }

                $newTask = Task::create($newTaskData);
                $createdTaskMap[(int) $task->id] = (int) $newTask->id;

                if (!$task->parent_id) {
                    $subtaskGroups = $subtaskGroupsByTaskId[$task->id] ?? [];

                    foreach ($subtaskGroups as $group) {
                        $newGroup = TaskMeta::create([
                            'task_id' => $newTask->id,
                            'key'     => Constant::SUBTASK_GROUP_NAME,
                            'value'   => $group->value,
                        ]);
                        $subtaskGroupMap[$group->id] = $newGroup->id;
                    }

                    $taskMap[$task->id] = $newTask->id;
                    $parentTaskCount++;

                    if ($labelMap) {
                        $labelIds = $task->labels->pluck('id')->toArray();
                        if ($labelIds) {
                            $flipLabelIds = array_flip($labelIds);
                            $labelsToAttach = array_intersect_key($labelMap, $flipLabelIds);
                            if ($labelsToAttach) {
                                $newTask->labels()->attach($labelsToAttach, [
                                    'object_type' => Constant::OBJECT_TYPE_TASK_LABEL,
                                ]);
                            }
                        }
                    }
                } else {
                    $groupRelation = $subtaskGroupRelationsByTaskId[$task->id] ?? null;

                    if ($groupRelation && isset($subtaskGroupMap[$groupRelation->value])) {
                        TaskMeta::create([
                            'task_id' => $newTask->id,
                            'key'     => Constant::SUBTASK_GROUP_CHILD,
                            'value'   => $subtaskGroupMap[$groupRelation->value],
                        ]);
                    }
                }
            }

            $this->copyTaskCustomFieldRelationsForBatch($taskIds, $createdTaskMap, $customFieldMap);

            $nextOffset = $offset + self::TASK_BATCH_SIZE;
            $totalTasks = $this->getUserTemplateTaskQuery($templateId, $sourceStageIds)->count();

            if ($nextOffset < $totalTasks) {
                $batchData['offset'] = $nextOffset;
                $batchData['task_map'] = $taskMap;
                $batchData['subtask_group_map'] = $subtaskGroupMap;
                $batchData['parent_task_count'] = $parentTaskCount;

                if (!set_transient($batchKey, $batchData, HOUR_IN_SECONDS)) {
                    throw new \RuntimeException(__('Task copy state could not be updated', 'fluent-boards-pro'));
                }

                $this->enqueueUserTemplateTaskCopy($newBoardId);
            } else {
                if (!delete_transient($batchKey)) {
                    throw new \RuntimeException(__('Task copy state could not be cleared', 'fluent-boards-pro'));
                }

                $settings = $newBoard->settings ?: [];
                $settings['tasks_count'] = $parentTaskCount;
                $settings['task_creation_status'] = 'completed';
                $newBoard->settings = $settings;
                $newBoard->save();
            }

            $dbInstance->commit();
        } catch (\Throwable $exception) {
            $dbInstance->rollBack();

            // Clear the rolled-back option cache before restoring the committed cursor.
            delete_transient($batchKey);
            set_transient($batchKey, $originalBatchData, HOUR_IN_SECONDS);
            $failedBoard = Board::find($newBoardId);
            if ($failedBoard) {
                $this->updateTaskCreationStatus($failedBoard, 'failed');
            }

            throw $exception;
        } finally {
            wp_set_current_user($previousUserId);
        }
    }

    /**
     * Copy custom field values for the tasks created in one async user-template batch.
     *
     * @param array $sourceTaskIds
     * @param array $createdTaskMap
     * @param array $customFieldMap
     * @return void
     */
    private function copyTaskCustomFieldRelationsForBatch(array $sourceTaskIds, array $createdTaskMap, array $customFieldMap): void
    {
        if (!$sourceTaskIds || !$createdTaskMap || !$customFieldMap) {
            return;
        }

        $sourceCustomFieldIds = array_values(array_filter(array_map('absint', array_keys($customFieldMap))));
        if (!$sourceCustomFieldIds) {
            return;
        }

        $copyableTaskIds = array_values(array_filter(array_map('absint', $sourceTaskIds), function ($taskId) use ($createdTaskMap) {
            return isset($createdTaskMap[$taskId]);
        }));

        if (!$copyableTaskIds) {
            return;
        }

        $relations = Relation::whereIn('object_id', $copyableTaskIds)
            ->where('object_type', Constant::TASK_CUSTOM_FIELD)
            ->whereIn('foreign_id', $sourceCustomFieldIds)
            ->orderBy('id')
            ->get();

        if ($relations->isEmpty()) {
            return;
        }

        $timestamp = current_time('mysql');
        $rows = [];

        foreach ($relations as $relation) {
            $sourceTaskId = (int) $relation->object_id;
            $sourceCustomFieldId = (int) $relation->foreign_id;

            if (!isset($createdTaskMap[$sourceTaskId], $customFieldMap[$sourceCustomFieldId])) {
                continue;
            }

            $rows[] = [
                'object_id' => (int) $createdTaskMap[$sourceTaskId],
                'object_type' => Constant::TASK_CUSTOM_FIELD,
                'foreign_id' => (int) $customFieldMap[$sourceCustomFieldId],
                'settings' => maybe_serialize($relation->settings),
                'preferences' => maybe_serialize($relation->preferences),
                'created_at' => $timestamp,
                'updated_at' => $timestamp,
            ];
        }

        // Keep large template copies fast without creating oversized insert queries.
        foreach (array_chunk($rows, 500) as $chunk) {
            Relation::insert($chunk);
        }
    }

    /**
     * Queue the next user-template task-copy batch.
     *
     * @param int $boardId
     * @return int
     */
    private function enqueueUserTemplateTaskCopy($boardId)
    {
        $actionId = as_enqueue_async_action('fluent_boards/async_copy_tasks_from_user_template', [
            absint($boardId),
        ], 'fluent-boards');

        if (!$actionId) {
            throw new \RuntimeException(__('Task copy could not be scheduled', 'fluent-boards-pro'));
        }

        return $actionId;
    }

    /**
     * Update the task-copy lifecycle status on a board.
     *
     * @param Board  $board
     * @param string $status
     * @return void
     */
    private function updateTaskCreationStatus($board, $status)
    {
        $settings = $board->settings ?: [];
        $settings['task_creation_status'] = $status;
        $board->settings = $settings;
        $board->save();
    }

    /**
     * Mark task creation as completed on a board
     *
     * @param Board $board
     * @return void
     */
    private function markTaskCreationCompleted($board)
    {
        $this->updateTaskCreationStatus($board, 'completed');
    }

    /**
     * Check if a board is a template
     *
     * @param Board|int $board
     * @return bool
     */
    public function isTemplate($board)
    {
        if (is_numeric($board)) {
            $board = Board::find($board);
        }

        if (!$board) {
            return false;
        }

        return Arr::get($board->settings, 'is_template', false) === true;
    }

    /**
     * Clear the default templates cache
     *
     * @return bool
     */
    public function clearTemplatesCache()
    {
        return delete_transient(self::CACHE_KEY);
    }

    /**
     * Download a bounded HTTPS image into the media library, leaving no temporary file on failure.
     *
     * @param string $url Remote image URL
     * @return string|null Local URL on success, null on failure
     */
    private function downloadRemoteImage($url)
    {
        if (!is_string($url) || strpos($url, 'https://') !== 0 || !wp_http_validate_url($url)) {
            return null;
        }

        if (!function_exists('media_handle_sideload')) {
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }

        $tmpFile = wp_tempnam('template-image');
        if (!$tmpFile) {
            return null;
        }

        $downloadedFile = $tmpFile;
        try {
            // Read one byte past the limit so a truncated oversized response is rejected.
            $maxBytes = 5 * MB_IN_BYTES;
            $response = wp_safe_remote_get($url, [
                'timeout' => 30,
                'redirection' => 0,
                'sslverify' => true,
                'stream' => true,
                'filename' => $tmpFile,
                'limit_response_size' => $maxBytes + 1,
            ]);

            if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
                return null;
            }

            clearstatcache(true, $tmpFile);
            $size = filesize($tmpFile);
            if (!$size || $size > $maxBytes) {
                return null;
            }

            $mime = wp_get_image_mime($tmpFile);
            $mimeMap = [
                'image/jpeg' => 'jpg',
                'image/png'  => 'png',
                'image/gif'  => 'gif',
                'image/webp' => 'webp',
            ];
            $ext = $mimeMap[$mime] ?? null;
            if (!$ext) {
                return null;
            }

            $newTmpFile = $tmpFile . '.' . $ext;
            if (!@rename($tmpFile, $newTmpFile)) {
                return null;
            }
            $downloadedFile = $newTmpFile;

            $fileArray = [
                'name'     => 'template-image-' . uniqid() . '.' . $ext,
                'tmp_name' => $newTmpFile,
            ];

            $attachmentId = media_handle_sideload($fileArray, 0);
            if (is_wp_error($attachmentId)) {
                return null;
            }

            if ($this->templateSaveAttachmentIds !== null) {
                $this->templateSaveAttachmentIds[] = $attachmentId;
            }

            $attachmentUrl = wp_get_attachment_url($attachmentId);
            if (!$attachmentUrl) {
                wp_delete_attachment($attachmentId, true);
                return null;
            }

            return $attachmentUrl;
        } finally {
            if (file_exists($downloadedFile)) {
                @unlink($downloadedFile);
            }
        }
    }
}
