<?php

namespace FluentBoardsPro\App\Services;

use FluentBoardsPro\App\Models\TaskAttachment;
use FluentBoards\App\Models\Task;
use FluentBoards\App\Models\CommentImage;
use FluentBoards\App\Models\TaskMeta;
use FluentBoards\App\Services\PermissionManager;
use FluentBoards\App\Services\TaskService;
use FluentBoards\App\Services\UploadService;
use FluentCommunity\Framework\Support\Arr;

class AttachmentService
{
    const BLOCKED_ATTACHMENT_EXTENSIONS = [
        'php', 'php3', 'php4', 'php5', 'php7', 'php8', 'phtml', 'phar',
        'html', 'htm', 'shtml', 'xhtml', 'xht',
        'js', 'mjs', 'svg', 'svgz', 'xml', 'xsl', 'xslt', 'swf', 'htaccess',
    ];

    const VERIFIED_INLINE_MIME_TYPES = [
        'image/jpeg',
        'image/gif',
        'image/png',
        'image/bmp',
        'image/tiff',
        'image/webp',
        'image/avif',
        'image/x-icon',
        'image/heic',
        'application/pdf',
    ];

    const SANITIZED_INLINE_MIME_TYPES = [
        'text/markdown',
        'text/x-markdown',
    ];

    /**
     * Build a filesystem-safe chunk upload session name from the route and file scope.
     *
     * @param array $scope
     * @return string
     */
    public static function getChunkUploadSessionName(array $scope)
    {
        $parts = [
            'upload_id'    => (string) ($scope['upload_id'] ?? ''),
            'user_id'      => (int) ($scope['user_id'] ?? 0),
            'board_id'     => (int) ($scope['board_id'] ?? 0),
            'task_id'      => (int) ($scope['task_id'] ?? 0),
            'file_name'    => (string) ($scope['file_name'] ?? ''),
            'file_size'    => (int) ($scope['file_size'] ?? 0),
            'total_chunks' => (int) ($scope['total_chunks'] ?? 0),
        ];

        return 'task-attachment-' . hash('sha256', json_encode($parts));
    }

    public function handleAttachment($taskId, $attachmentData, $file = null, $type = null)
    {
        // Fetch the task
        $task = $this->resolveTaskForCurrentUser($taskId);

        // Determine attachment type and handle accordingly
        if ($attachmentData['type'] === 'url') {
            $attachment = $this->createUrlAttachment($task, $attachmentData, $type);
        } else {
            $attachment = $this->createFileAttachment($task, $attachmentData, $file, $type);
        }

        // Update task's attachment count
        $this->updateTaskAttachmentCount($task);

        return $attachment;
    }

    /**
     * Creates and handles a URL attachment.
     */
    protected function createUrlAttachment($task, $urlData, $type = null)
    {
        $urlMeta = RemoteUrlParser::parse($urlData['url']);
        $urlData['settings'] = ['meta' => $urlMeta];
        $attachment = $this->initializeAttachment($task, $urlData, $type, $urlMeta);
        $attachment->save();

        return $attachment;
    }

    /**
     * Creates and handles a file attachment.
     */
    protected function createFileAttachment($task, $fileData, $file, $type = null)
    {
        // Process media data for file attachment and merge with file data
        $mediaData = $this->processMediaData($fileData, $file);
        $updatedData = array_merge($fileData, $mediaData);

        // Create and initialize TaskAttachment object
        $attachment = $this->initializeAttachment($task, $updatedData, $type);
        $attachment->fill($mediaData); // Fill with processed media data
        $attachment->save(); // Save the attachment

        return $attachment;
    }

    /**
     * Initializes a TaskAttachment object.
     */
    protected function initializeAttachment($task, $attachData, $type, $urlMeta = [])
    {
        $attachment = new TaskAttachment();
        $attachment->object_id = $task->id;
        $attachment->object_type = $type ?? \FluentBoards\App\Services\Constant::TASK_ATTACHMENT;
        $attachment->attachment_type = $attachData['type'];
        if ($attachData['type'] === 'url') {
            $titleValue = $attachData['title'] ?? '';
        } else {
            $titleValue = $attachData['name'];
        }
        $attachment->title = $this->setTitle($attachData['type'], $titleValue, $urlMeta);
        $attachment->file_path = ($attachData['type'] !== 'url') ? $attachData['file'] : null;
        $attachment->full_url = esc_url($attachData['url']);
        $attachment->file_size = $attachData['size'] ?? null;
        $attachment->settings = $attachData['settings'] ?? '';
        $attachment->driver = $attachData['driver'] ?? 'local';

        return $attachment;
    }

    /**
     * Processes media data for non-URL attachments.
     */
    public function processMediaData($attachData, $file)
    {
        $attachData['driver'] = $attachData['driver'] ?? 'local';
        return apply_filters('fluent_boards/upload_media_data', [
            'type' => $attachData['type'],
            'driver' => $attachData['driver'],
            'file_path' => $attachData['full_path'],
            'full_url' => $attachData['url'],
            'settings' => '',
        ], $file);
    }

    /**
     * Updates the task's attachment count.
     */
    protected function updateTaskAttachmentCount($task)
    {
        $taskSettings = $task->settings;
        $taskSettings['attachment_count'] = (int)($taskSettings['attachment_count'] ?? 0) + 1;
        $task->settings = $taskSettings;
        $task->save();
    }

    private function setTitle($type, $title, $UrlMeta)
    {
        if($type != 'url') {
            return sanitize_file_name($title);
        }
        return $title ?? $UrlMeta['title'] ?? '';
    }

    public function deleteTaskAttachment($taskId, $attachmentId, $boardId = null)
    {
        $task = $this->resolveTaskForCurrentUser($taskId, $boardId);
        $attachment = TaskAttachment::where('id', absint($attachmentId))
            ->where('object_id', $task->id)
            ->where('object_type', \FluentBoards\App\Services\Constant::TASK_ATTACHMENT)
            ->first();

        if (!$attachment) {
            throw new \Exception(__('Attachment not found', 'fluent-boards-pro'));
        }

        $deletedAttachment = clone $attachment;
        $attachment->delete();

        do_action('fluent_boards/task_attachment_deleted', $deletedAttachment);

        $taskSettings = $task->settings;
        $taskSettings['attachment_count'] = max((int)($taskSettings['attachment_count'] ?? 0) - 1, 0);
        $task->settings = $taskSettings;
        $task->save();
        // Return the updated list of task attachments
        return $task->attachments;
    }

    public function updateTaskAttachment($taskId, $attachmentId, $attachmentTitle, $boardId = null)
    {
        $task = $this->resolveTaskForCurrentUser($taskId, $boardId);
        $attachment = TaskAttachment::where('id', absint($attachmentId))
            ->where('object_id', $task->id)
            ->where('object_type', \FluentBoards\App\Services\Constant::TASK_ATTACHMENT)
            ->first();

        if (!$attachment) {
            throw new \Exception(__('Attachment not found', 'fluent-boards-pro'));
        }

        $attachment->title = $attachmentTitle;
        $attachment->save();

        // Return the updated list of task attachments
        return $attachment;
    }

    /**
     * Resolve a task for the current user, optionally scoped by route board id.
     *
     * @param int $taskId
     * @param int|null $boardId
     * @return Task
     * @throws \Exception
     */
    public function resolveTaskForCurrentUser($taskId, $boardId = null)
    {
        if ($boardId) {
            return (new TaskService())->findTaskOnBoard($taskId, $boardId);
        }

        $task = Task::find(absint($taskId));
        if (!$task || !PermissionManager::userHasBoardPermission($task->board_id, 'POST')) {
            throw new \Exception(__("Task doesn't exist", 'fluent-boards-pro'));
        }

        return $task;
    }

    /**
     * Resolve a canonical MIME type from the core extension allow-list.
     *
     * @param string $fileName
     * @return string
     */
    public static function getMimeTypeFromFileName($fileName)
    {
        $extension = strtolower(pathinfo((string) $fileName, PATHINFO_EXTENSION));
        if (!$extension) {
            return '';
        }

        if (in_array($extension, self::BLOCKED_ATTACHMENT_EXTENSIONS, true)) {
            return '';
        }

        foreach (UploadService::getAllowedMimeMap() as $extensionPattern => $mimeType) {
            if (in_array($extension, explode('|', $extensionPattern), true)) {
                return self::normalizeMimeType($mimeType);
            }
        }

        return '';
    }

    /**
     * Detect a local file's MIME type from its bytes.
     *
     * @param string $filePath
     * @return string
     */
    public static function detectFileMimeType($filePath)
    {
        if (!$filePath || !is_file($filePath) || !is_readable($filePath)) {
            return '';
        }

        $handle = fopen($filePath, 'rb');
        $signature = $handle ? fread($handle, 5) : '';
        if ($handle) {
            fclose($handle);
        }

        if ($signature === '%PDF-') {
            return 'application/pdf';
        }

        if (function_exists('wp_get_image_mime')) {
            $imageMime = wp_get_image_mime($filePath);
            if ($imageMime) {
                return self::normalizeMimeType($imageMime);
            }
        }

        $imageInfo = @getimagesize($filePath);
        if (!empty($imageInfo['mime'])) {
            return self::normalizeMimeType($imageInfo['mime']);
        }

        if (!function_exists('finfo_open')) {
            return '';
        }

        $fileInfo = finfo_open(FILEINFO_MIME_TYPE);
        if (!$fileInfo) {
            return '';
        }

        $mimeType = finfo_file($fileInfo, $filePath);
        if (is_resource($fileInfo)) {
            finfo_close($fileInfo);
        }

        return self::normalizeMimeType($mimeType);
    }

    /**
     * Detect MIME type from proxied cloud attachment bytes.
     *
     * @param string $content
     * @return string
     */
    public static function detectStringMimeType($content)
    {
        if (strncmp((string) $content, '%PDF-', 5) === 0) {
            return 'application/pdf';
        }

        $imageInfo = @getimagesizefromstring((string) $content);
        if (!empty($imageInfo['mime'])) {
            return self::normalizeMimeType($imageInfo['mime']);
        }

        if (!function_exists('finfo_open')) {
            return '';
        }

        $fileInfo = finfo_open(FILEINFO_MIME_TYPE);
        if (!$fileInfo) {
            return '';
        }

        $mimeType = finfo_buffer($fileInfo, (string) $content);
        if (is_resource($fileInfo)) {
            finfo_close($fileInfo);
        }

        return self::normalizeMimeType($mimeType);
    }

    /**
     * Build safe response metadata without trusting stored attachment MIME data.
     *
     * @param string $fileName
     * @param string $detectedMimeType
     * @return array
     */
    public static function getAttachmentResponsePolicy($fileName, $detectedMimeType = '')
    {
        $canonicalMimeType = self::getMimeTypeFromFileName($fileName);
        $detectedMimeType = self::normalizeMimeType($detectedMimeType);

        if (in_array($canonicalMimeType, self::SANITIZED_INLINE_MIME_TYPES, true)) {
            return [
                'mime_type'   => 'text/plain',
                'disposition' => 'inline',
            ];
        }

        $isVerifiedPreview = in_array($canonicalMimeType, self::VERIFIED_INLINE_MIME_TYPES, true)
            && $canonicalMimeType === $detectedMimeType;

        if ($isVerifiedPreview) {
            return [
                'mime_type'   => $canonicalMimeType,
                'disposition' => 'inline',
            ];
        }

        return [
            'mime_type'   => 'application/octet-stream',
            'disposition' => 'attachment',
        ];
    }

    /**
     * Normalize MIME aliases before strict comparisons.
     *
     * @param mixed $mimeType
     * @return string
     */
    private static function normalizeMimeType($mimeType)
    {
        $mimeType = strtolower(trim((string) $mimeType));
        $mimeType = trim(explode(';', $mimeType, 2)[0]);

        $aliases = [
            'image/vnd.microsoft.icon' => 'image/x-icon',
            'image/ico'                => 'image/x-icon',
            'image/icon'               => 'image/x-icon',
            'application/x-pdf'        => 'application/pdf',
        ];

        return $aliases[$mimeType] ?? $mimeType;
    }

}
