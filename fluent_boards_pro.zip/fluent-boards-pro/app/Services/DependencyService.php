<?php

namespace FluentBoardsPro\App\Services;

use FluentBoards\App\Models\Relation;
use FluentBoards\App\Models\Task;
use FluentBoards\App\Services\Constant;
use FluentBoards\App\Services\Helper;
use FluentBoards\App\Services\TaskService;

class DependencyService
{
    /**
     * Add a dependency: predecessorTask blocks successorTask (Finish-to-Start).
     *
     * @param int $predecessorTaskId The task that must finish first (blocker)
     * @param int $successorTaskId   The task that is waiting (blocked)
     * @param int $boardId
     * @return array
     * @throws \Exception
     */
    public function addDependency($predecessorTaskId, $successorTaskId, $boardId)
    {
        $predecessorTaskId = absint($predecessorTaskId);
        $successorTaskId   = absint($successorTaskId);
        $boardId           = absint($boardId);

        // Cannot depend on itself
        if ($predecessorTaskId === $successorTaskId) {
            throw new \Exception(__('A task cannot depend on itself.', 'fluent-boards-pro'), 422);
        }

        // Validate both tasks exist and belong to this board
        $predecessorTask = Task::where('id', $predecessorTaskId)->where('board_id', $boardId)->first();
        $successorTask   = Task::where('id', $successorTaskId)->where('board_id', $boardId)->first();

        if (!$predecessorTask || !$successorTask) {
            throw new \Exception(__('One or both tasks were not found in this board.', 'fluent-boards-pro'), 404);
        }

        // Check for duplicate
        $exists = Relation::where('object_id', $predecessorTaskId)
            ->where('foreign_id', $successorTaskId)
            ->where('object_type', Constant::OBJECT_TYPE_TASK_DEPENDENCY)
            ->exists();

        if ($exists) {
            throw new \Exception(__('This dependency already exists.', 'fluent-boards-pro'), 422);
        }

        // Check for circular dependency
        if ($this->hasCircularDependency($predecessorTaskId, $successorTaskId)) {
            throw new \Exception(__('Cannot create dependency: it would create a circular reference.', 'fluent-boards-pro'), 422);
        }

        // Create the dependency relation
        Relation::create([
            'object_id'   => $predecessorTaskId,
            'foreign_id'  => $successorTaskId,
            'object_type' => Constant::OBJECT_TYPE_TASK_DEPENDENCY,
            'settings'    => maybe_serialize(['type' => 'FS']),
            'preferences' => '',
        ]);

        do_action('fluent_boards/task_dependency_added', $predecessorTask, $successorTask, $boardId);

        return [
            'message' => __('Dependency added successfully.', 'fluent-boards-pro'),
        ];
    }

    /**
     * Remove a dependency between two tasks.
     * Tries both directions: the caller may pass IDs in either order.
     *
     * @param int $taskId
     * @param int $relatedTaskId
     * @return array
     */
    public function removeDependency($taskId, $relatedTaskId, $boardId = null)
    {
        $taskId        = absint($taskId);
        $relatedTaskId = absint($relatedTaskId);
        $boardId       = absint($boardId);

        if ($boardId) {
            (new TaskService())->findTaskOnBoard($taskId, $boardId);
            (new TaskService())->findTaskOnBoard($relatedTaskId, $boardId);
        }

        // Try object_id=taskId, foreign_id=relatedTaskId first
        $relation = Relation::where('object_type', Constant::OBJECT_TYPE_TASK_DEPENDENCY)
            ->where(function ($query) use ($taskId, $relatedTaskId) {
                $query->where(function ($q) use ($taskId, $relatedTaskId) {
                    $q->where('object_id', $taskId)->where('foreign_id', $relatedTaskId);
                })->orWhere(function ($q) use ($taskId, $relatedTaskId) {
                    $q->where('object_id', $relatedTaskId)->where('foreign_id', $taskId);
                });
            })
            ->first();

        if (!$relation) {
            return [
                'message' => __('Dependency not found.', 'fluent-boards-pro'),
            ];
        }

        $predecessorTask = Task::find($relation->object_id);
        $successorTask   = Task::find($relation->foreign_id);
        $boardId         = $predecessorTask ? $predecessorTask->board_id : null;

        $relation->delete();

        if ($predecessorTask && $successorTask && $boardId) {
            do_action('fluent_boards/task_dependency_removed', $predecessorTask, $successorTask, $boardId);
        }

        return [
            'message' => __('Dependency removed successfully.', 'fluent-boards-pro'),
        ];
    }

    /**
     * Get all dependencies for a single task (both directions).
     *
     * @param int $taskId
     * @return array ['predecessors' => Collection, 'successors' => Collection]
     */
    public function getTaskDependencies($taskId, $boardId = null)
    {
        $task = $boardId ? (new TaskService())->findTaskOnBoard($taskId, $boardId) : Task::findOrFail($taskId);

        $columns = ['fbs_tasks.id', 'fbs_tasks.title', 'fbs_tasks.stage_id', 'fbs_tasks.status', 'fbs_tasks.board_id', 'fbs_tasks.due_at'];

        $predecessors = $task->predecessors()->with('assignees')->get($columns);
        $successors   = $task->successors()->with('assignees')->get($columns);

        foreach ([$predecessors, $successors] as $relatedTasks) {
            foreach ($relatedTasks as $relatedTask) {
                Helper::sanitizeUserCollections($relatedTask->assignees);
            }
        }

        return [
            'predecessors' => $predecessors,
            'successors'   => $successors,
        ];
    }

    /**
     * Get all dependency relations for a board (for Gantt chart rendering).
     * Returns flat array of predecessor/successor ID pairs.
     *
     * @param int $boardId
     * @return array
     */
    public function getBoardDependencies($boardId)
    {
        $boardId = absint($boardId);

        // Get all task IDs in this board
        $taskIds = Task::where('board_id', $boardId)->pluck('id')->toArray();

        if (empty($taskIds)) {
            return [];
        }

        // Get all dependency relations where both tasks are in this board
        $relations = Relation::where('object_type', Constant::OBJECT_TYPE_TASK_DEPENDENCY)
            ->whereIn('object_id', $taskIds)
            ->whereIn('foreign_id', $taskIds)
            ->get(['object_id', 'foreign_id']);

        if ($relations->isEmpty()) {
            return [];
        }

        // Predecessor status lets the board show blocked state for tasks not loaded on the client
        $predecessorStatuses = Task::whereIn('id', $relations->pluck('object_id')->unique()->toArray())
            ->pluck('status', 'id')
            ->toArray();

        // Skip links whose predecessor no longer exists so a deleted task never blocks its successor
        return $relations->filter(function ($relation) use ($predecessorStatuses) {
            return isset($predecessorStatuses[$relation->object_id]);
        })->map(function ($relation) use ($predecessorStatuses) {
            return [
                'predecessor_id'     => (int) $relation->object_id,
                'successor_id'       => (int) $relation->foreign_id,
                'predecessor_status' => $predecessorStatuses[$relation->object_id],
            ];
        })->values()->toArray();
    }

    /**
     * Check if adding predecessor→successor would create a circular dependency.
     *
     * Algorithm (BFS): Starting from the predecessor, walk backwards through
     * its own predecessors. If we ever reach the successor, adding this link
     * would create a cycle.
     *
     * @param int $predecessorTaskId
     * @param int $successorTaskId
     * @return bool true if circular
     */
    public function hasCircularDependency($predecessorTaskId, $successorTaskId)
    {
        $visited = [];
        $queue   = [$predecessorTaskId];

        while (!empty($queue)) {
            $current = array_shift($queue);

            if ($current == $successorTaskId) {
                return true; // Cycle detected
            }

            if (isset($visited[$current])) {
                continue;
            }

            $visited[$current] = true;

            // Find all predecessors of the current task (walk backwards)
            $currentPredecessors = Relation::where('foreign_id', $current)
                ->where('object_type', Constant::OBJECT_TYPE_TASK_DEPENDENCY)
                ->pluck('object_id')
                ->toArray();

            foreach ($currentPredecessors as $predId) {
                if (!isset($visited[$predId])) {
                    $queue[] = $predId;
                }
            }
        }

        return false;
    }

    /**
     * Remove all dependencies for a task (called on task deletion).
     * Removes relations where this task is either predecessor OR successor.
     *
     * @param int $taskId
     * @return void
     */
    public function removeAllDependencies($taskId)
    {
        $taskId = absint($taskId);

        Relation::where('object_type', Constant::OBJECT_TYPE_TASK_DEPENDENCY)
            ->where(function ($query) use ($taskId) {
                $query->where('object_id', $taskId)
                      ->orWhere('foreign_id', $taskId);
            })
            ->delete();
    }
}
