<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <title>Projects - <?php echo esc_attr(get_bloginfo('name')); ?></title>
    <meta charset='utf-8'>

    <meta name="viewport"
          content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0,viewport-fit=cover"/>
    <meta content='yes' name='apple-mobile-web-app-capable'>
    <meta name="description" content="<?php echo esc_attr(get_bloginfo('description')); ?>">
    <meta name="robots" content="noindex">

    <link rel="icon" type="image/x-icon" href="<?php echo get_site_icon_url(); ?>"/>

    <?php wp_head(); ?>

    <style>
        html, body {
            margin-top: 0 !important;
        }

        .fbs_full_screen_btn {
            display: none !important;
        }

        body {
            background: var(--fbs-secondary-bg);
            color: var(--fbs-secondary-text);
            font-family: -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif;
            font-size: 13px;
            line-height: 1.4em;
        }
        ul,ol {
            margin: 0;
        }

        body * {
            box-sizing: border-box;
            font-family: -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif;
        }

        .fbs_front {
            display: block;
            width: 100%;
        }

        .fbs_front .fbs_regular_view {
            margin: 0 auto !important;
        }

        .fframe_main-menu-items {
            margin-left: 0;
        }

        footer#footer {
            display: block;
            text-align: center;
            margin: 0;
        }

        .fbs_front .fframe_body {
            margin-left: 0 !important;
        }

        ul.fbs_board_setting_list_container {
            list-style: none;
            margin: 0;
            padding: 0;
        }

        .fbs_front .fluentboards_databox {
            height: calc(100vh - 60px);
        }

        body.fluentcrm_page_fluent-boards #wpbody #fbs_tasks_wrapper, .toplevel_page_fluent-boards #wpbody #fbs_tasks_wrapper {
            height: calc(100vh - 145px);
        }

        .fbs_right_sidebar .fbs_notification_header, .fbs_right_sidebar .fbs_right_sidebar_header, .fbs_filters_sidebar .fbs_filters_hearder, .fbs-add_new_board .head {
            padding: 0 0 24px !important;
            margin: 0 !important;
        }
        .fbs_member_page,
        .fbs_sidenav_page {
            min-height: calc(100vh - 58px);
        }
        .fbs_member_content,
        .fbs_sidenav_content {
            min-height: calc(100vh - 58px);
            max-height: calc(100vh - 58px);
        }

        /* RTL */
        html[dir="rtl"] .fbs_front .fframe_body {
            margin-right: 0 !important;
        }
        html[dir="rtl"] .fbs_front .fframe_main-menu-items {
            margin-right: 0;
        }
    </style>

    <?php if (!get_current_user_id()): ?>
        <style>
            .fbs_login_form {
                margin: 100px auto;
                max-width: 500px;
                background: white;
                border-radius: 5px;
            }
            .fbs_login_form {
                .fbs_login_form_heading {
                    padding: 20px;
                    background: #fbfbfb;
                    border-bottom: 1px solid #e5e7eb;
                    font-size: 20px;
                    font-weight: 500;
                    border-top-left-radius: 5px;
                    border-top-right-radius: 5px;
                    text-align: center;
                }
            }

            .fbs_login_wrap {
                padding: 20px;
                border-bottom-left-radius: 5px;
                border-bottom-right-radius: 5px;
            }
            #loginform p {
                margin-bottom: 10px;
                display: block;
            }
            #loginform * {
                box-sizing: border-box;
            }
            #loginform p > label {
                font-size: 14px;
                font-weight: 500;
                display: block;
            }
            input.input {
                width: 100%;
                padding: 10px;
                border: 1px solid #e5e7eb;
                border-radius: 5px;
                margin-top: 5px;
            }
            .button-primary {
                background: #3b82f6;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 5px;
                cursor: pointer;
                margin-top: 10px;
            }
        </style>

        <script type="text/javascript">
            document.addEventListener('DOMContentLoaded', function () {
                // get the current full url
                var currentUrl = window.location.href;

                // set to input[name=redirect_to] value as current url
                document.querySelector('input[name=redirect_to]').value = currentUrl;
            });
        </script>
    <?php endif; ?>

    <?php do_action('fluent_boards/front_head'); ?>

</head>
<body class="fluentcrm_page_fluent-boards">

<div id="wpbody" class="fluent_boards_front">
    <?php echo $content; ?>
</div>

<?php wp_footer(); ?>

<?php do_action('fluent_boards/front_footer'); ?>

</body>
</html>
