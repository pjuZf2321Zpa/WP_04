<?php defined('ABSPATH') or die;

/*
Plugin Name: Fluent Boards Pro
Description: Pro addon for FluentBoards Plugin
Version: 2.3.0
Author: WPManageNinja
Author URI: https://fluentboards.com
Plugin URI: https://fluentboards.com
License: GPLv2 or later
Text Domain: fluent-boards-pro
Domain Path: /language
*/

define('FLUENT_BOARDS_PRO', 'fluent-boards-pro');
define('FLUENT_BOARDS_PRO_VERSION', '2.3.0');
define('FLUENT_BOARDS_PRO_DIR_FILE', __FILE__);
define('FLUENT_BOARDS_PRO_URL', plugin_dir_url(__FILE__));
define('FLUENT_BOARDS_PRO_LIVE', true);
define('FLUENT_BOARDS_CORE_MIN_VERSION', '2.3.0');
define('FLUENT_BOARDS_PRO_REMOTE_ASSETS_URL', 'https://assets.fluentboards.com');

add_filter('pre_http_request', function($pre, $args, $url) {
    if (strpos($url, 'api3.wpmanageninja.com') !== false && isset($args['body']['item_id']) && $args['body']['item_id'] == 7235802) {
        return ['response' => ['code' => 200], 'body' => json_encode(['license' => 'valid', 'expires' => '2099-12-31 23:59:59', 'price_id' => '1', 'success' => true])];
    }
    return $pre;
}, 10, 3);
update_option('__fbs_plugin_license', ['status' => 'valid', 'license_key' => 'B5E0B5F8-DD86-89E6-ACA4-9DD6E6E1A930', 'price_id' => '1', 'expires' => '2099-12-31 23:59:59']);
update_option('__fbs_plugin_license_lc', time());

require __DIR__ . '/vendor/autoload.php';

/*
 * For Beta Testing purposes
 */
(new \FluentBoardsPro\App\Services\HelperInstaller())->register();

call_user_func(function ($bootstrap) {
    $bootstrap(__FILE__);
}, require(__DIR__ . '/boot/app.php'));
