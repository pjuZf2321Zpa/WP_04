<script type="text/html" id="tmpl-fusion_privacy-shortcode">
<div {{{ _.fusionGetAttributes( attr ) }}}>
<div {{{ _.fusionGetAttributes( contentAttr ) }}}> {{{ FusionPageBuilderApp.renderContent( output, cid, false ) }}} </div>
	<# if ( embeds && embeds.length ) { #>
		<form {{{ _.fusionGetAttributes( formAttr ) }}}>
			<# if ( 'grouped' === privacyLayout ) { #>
				<# var categoryOrder = visibleGroups ? visibleGroups.split( ',' ).map( function( s ) { return s.trim(); } ) : []; #>
				<# var byCategory = { necessary: [] }; #>
				<# _.each( embeds, function( embed ) {
					var cat = embed.category || 'embeds';
					if ( ! byCategory[ cat ] ) { byCategory[ cat ] = []; }
					byCategory[ cat ].push( embed );
				} ); #>
				<# _.each( contentCategoryTypes, function( cat ) {
					if ( ! byCategory[ cat ] ) { byCategory[ cat ] = []; }
				} ); #>

				<# var groupsClass = 'fusion-privacy-groups' + ( 'columns' === groupColumnsLayout ? ' fusion-privacy-groups--columns' : '' ); #>
				<div class="{{ groupsClass }}">
				<# _.each( categoryOrder, function( cat, catIndex ) {
					if ( ! byCategory[ cat ] ) {
						return;
					}
					var catLabel = ( groupTitles && groupTitles[ cat ] ) ? groupTitles[ cat ] : ( categoryFallbacks[ cat ] || cat );
					var isCollapsed = collapsedOnLoad || ( isAccordion && catIndex > 0 );
				#>
					<div class="fusion-privacy-group">
						<# var catHasMaster = ( 'undefined' !== typeof showGroupToggle && showGroupToggle ) && 'necessary' !== cat && byCategory[ cat ].length > 0; #>
						<# if ( ( isCollapsible || catHasMaster ) && showGroupTitles ) { #>
							<# var expanded = isCollapsed ? 'false' : 'true'; #>
							<# var rotateCls = isCollapsed ? ' awb-rotate' : ''; #>
							<div class="fusion-privacy-group-heading">
								<{{{ titleSize }}} class="fusion-privacy-group-title">{{ catLabel }}</{{{ titleSize }}}>
								<# if ( catHasMaster ) { #>
									<input type="checkbox" class="awb-privacy-group-master-input" data-category="{{ cat }}" aria-label="<?php esc_attr_e( 'Toggle all items in this group', 'fusion-core' ); ?>">
								<# } #>
								<# if ( isCollapsible ) { #>
									<button type="button" class="awb-privacy-group-toggle{{ rotateCls }}" aria-expanded="{{ expanded }}" aria-label="<?php esc_attr_e( 'Toggle group', 'fusion-core' ); ?>"><i class="awb-icon-angle-up"></i></button>
								<# } #>
							</div>
						<# } else if ( showGroupTitles ) { #>
							<{{{ titleSize }}} class="fusion-privacy-group-title">{{ catLabel }}</{{{ titleSize }}}>
						<# } #>
						<# if ( isCollapsible ) { #>
							<# var bodyStyle = isCollapsed ? 'display:none;' : ''; #>
							<div class="fusion-privacy-group-body" style="{{ bodyStyle }}">
						<# } #>
						<# if ( showGroupDescription && groupDescriptions && groupDescriptions[ cat ] ) { #>
							<div class="fusion-privacy-group-description">{{{ groupDescriptions[ cat ] }}}</div>
						<# } #>
						<# var hasItems = 'necessary' === cat || byCategory[ cat ].length > 0; #>
						<# if ( hasItems ) { #>
						<ul class="fusion-privacy-choices">

							<# if ( 'necessary' === cat ) { #>
								<# if ( showWpCookies && wpCookies ) {
								_.each( wpCookies, function( cookieData, cookieName ) { #>
									<li class="is-necessary">
										<label style="pointer-events:none;">
											<input name="consents[]" type="checkbox" value="{{ cookieName }}" checked="checked" disabled="disabled">
											<span class="label-text">{{ cookieName }}
											<# if ( showLifespan && cookieData.lifespan ) { #>
												<span class="awb-cookie-lifespan">{{ cookieData.lifespan }}</span>
											<# } #>
											</span>
										</label>
										<# if ( showDesc && cookieData.description ) { #>
											<# if ( descToggleOn ) { #><button type="button" class="awb-privacy-desc-toggle awb-rotate" aria-expanded="false" aria-label="<?php esc_attr_e( 'Toggle description', 'fusion-core' ); ?>"><i class="awb-icon-angle-up"></i></button><# } #>
											<p class="awb-cookie-description">{{ cookieData.description }}</p>
										<# } #>
									</li>
								<# } ); } #>
								<# if ( pluginCookies && ! _.isEmpty( pluginCookies ) ) {
								_.each( pluginCookies, function( cookieData, cookieName ) { #>
									<li class="is-necessary">
										<label style="pointer-events:none;">
											<input name="consents[]" type="checkbox" value="{{ cookieName }}" checked="checked" disabled="disabled">
											<span class="label-text">{{ cookieName }}
											<# if ( showLifespan && cookieData.lifespan ) { #>
												<span class="awb-cookie-lifespan">{{ cookieData.lifespan }}</span>
											<# } #>
											</span>
										</label>
										<# if ( showDesc && cookieData.description ) { #>
											<# if ( descToggleOn ) { #><button type="button" class="awb-privacy-desc-toggle awb-rotate" aria-expanded="false" aria-label="<?php esc_attr_e( 'Toggle description', 'fusion-core' ); ?>"><i class="awb-icon-angle-up"></i></button><# } #>
											<p class="awb-cookie-description">{{ cookieData.description }}</p>
										<# } #>
									</li>
								<# } ); } #>
								<# if ( customSnippets ) {
									_.each( customSnippets, function( snippet ) {
										if ( 'necessary' === snippet.category ) { #>
											<li class="is-necessary">
												<label style="pointer-events:none;">
													<input name="consents[]" type="checkbox" checked="checked" disabled="disabled">
													<span class="label-text">{{ snippet.label }}
													<# if ( showLifespan ) { #>
														<span class="awb-cookie-lifespan"><# if ( snippet.lifespan ) { #>{{ snippet.lifespan }}<# } else { #>{{ lifespanStr }}<# } #></span>
													<# } #>
													</span>
												</label>
												<# if ( showDesc && snippet.snippet_description ) { #>
													<# if ( descToggleOn ) { #><button type="button" class="awb-privacy-desc-toggle awb-rotate" aria-expanded="false" aria-label="<?php esc_attr_e( 'Toggle description', 'fusion-core' ); ?>"><i class="awb-icon-angle-up"></i></button><# } #>
													<p class="awb-cookie-description">{{ snippet.snippet_description }}</p>
												<# } #>
											</li>
									<# } } ); } #>
							<# } else { #>
								<# _.each( byCategory[ cat ], function( embed ) { #>
									<li>
										<label for="{{ embed.id }}-live">
											<input name="consents[]" type="checkbox" value="{{ embed.id }}" {{ embed.selected }} id="{{ embed.id }}-live">
											<span class="label-text">{{ embed.label }}
											<# if ( showLifespan ) { #>
												<span class="awb-cookie-lifespan"><# if ( embed.lifespan ) { #>{{ embed.lifespan }}<# } else { #>{{ lifespanStr }}<# } #></span>
											<# } #>
											</span>
										</label>
										<# if ( showDesc && embed.description ) { #>
											<# if ( descToggleOn ) { #><button type="button" class="awb-privacy-desc-toggle awb-rotate" aria-expanded="false" aria-label="<?php esc_attr_e( 'Toggle description', 'fusion-core' ); ?>"><i class="awb-icon-angle-up"></i></button><# } #>
											<p class="awb-cookie-description">{{ embed.description }}</p>
										<# } #>
									</li>
								<# } ); #>
							<# } #>

						</ul>
						<# } #>
						<# if ( isCollapsible ) { #>
							</div>
						<# } #>
					</div>
				<# } ); #>
				</div>

			<# } else { #>

				<ul class="fusion-privacy-choices">
					<# if ( showWpCookies && wpCookies ) {
					_.each( wpCookies, function( cookieData, cookieName ) { #>
						<li class="is-necessary">
							<label style="pointer-events:none;">
								<input name="consents[]" type="checkbox" value="{{ cookieName }}" checked="checked" disabled="disabled">
								<span class="label-text">{{ cookieName }}
								<# if ( showLifespan && cookieData.lifespan ) { #>
									<span class="awb-cookie-lifespan">{{ cookieData.lifespan }}</span>
								<# } #>
								</span>
							</label>
							<# if ( showDesc && cookieData.description ) { #>
								<# if ( descToggleOn ) { #><button type="button" class="awb-privacy-desc-toggle awb-rotate" aria-expanded="false" aria-label="<?php esc_attr_e( 'Toggle description', 'fusion-core' ); ?>"><i class="awb-icon-angle-up"></i></button><# } #>
								<p class="awb-cookie-description">{{ cookieData.description }}</p>
							<# } #>
						</li>
					<# } ); } #>
					<# if ( showWpCookies && pluginCookies && ! _.isEmpty( pluginCookies ) ) {
					_.each( pluginCookies, function( cookieData, cookieName ) { #>
						<li class="is-necessary">
							<label style="pointer-events:none;">
								<input name="consents[]" type="checkbox" value="{{ cookieName }}" checked="checked" disabled="disabled">
								<span class="label-text">{{ cookieName }}
								<# if ( showLifespan && cookieData.lifespan ) { #>
									<span class="awb-cookie-lifespan">{{ cookieData.lifespan }}</span>
								<# } #>
								</span>
							</label>
							<# if ( showDesc && cookieData.description ) { #>
								<# if ( descToggleOn ) { #><button type="button" class="awb-privacy-desc-toggle awb-rotate" aria-expanded="false" aria-label="<?php esc_attr_e( 'Toggle description', 'fusion-core' ); ?>"><i class="awb-icon-angle-up"></i></button><# } #>
								<p class="awb-cookie-description">{{ cookieData.description }}</p>
							<# } #>
						</li>
					<# } ); } #>
					<# _.each( embeds, function( embed ) { #>
						<li>
							<label for="{{ embed.id }}-live">
								<input name="consents[]" type="checkbox" value="{{ embed.id }}" {{ embed.selected }} id="{{ embed.id }}-live">
								<span class="label-text">{{ embed.label }}
								<# if ( showLifespan ) { #>
									<span class="awb-cookie-lifespan"><# if ( embed.lifespan ) { #>{{ embed.lifespan }}<# } else { #>{{ lifespanStr }}<# } #></span>
								<# } #>
								</span>
							</label>
							<# if ( showDesc && embed.description ) { #>
								<# if ( descToggleOn ) { #><button type="button" class="awb-privacy-desc-toggle awb-rotate" aria-expanded="false" aria-label="<?php esc_attr_e( 'Toggle description', 'fusion-core' ); ?>"><i class="awb-icon-angle-up"></i></button><# } #>
								<p class="awb-cookie-description">{{ embed.description }}</p>
							<# } #>
						</li>
					<# } ); #>
				</ul>

			<# } #>

			<# if ( showUpdateButton || showAcceptAllButton || showRejectAllButton ) { #>
				<div class="fusion-privacy-element-button-wrapper">
					<# if ( showAcceptAllButton ) { #>
						<button class="fusion-privacy-element-button fusion-privacy-element-accept-all fusion-button fusion-button-default fusion-button-default-size" type="button">{{ acceptAllButtonText }}</button>
					<# } #>
					<# if ( showRejectAllButton ) { #>
						<button class="fusion-privacy-element-button fusion-privacy-element-reject-all fusion-button fusion-button-default fusion-button-default-size" type="button">{{ rejectAllButtonText }}</button>
					<# } #>
					<# if ( showUpdateButton ) { #>
						<button class="fusion-privacy-element-button fusion-button fusion-button-default fusion-button-default-size" type="submit">{{ updateButtonText }}</button>
					<# } #>
				</div>
			<# } #>
		</form>
	<# } #>
</div>
</script>
