<?php
defined( 'SECUPRESS_VERSION' ) or die( 'Something went wrong.' );

add_action( 'secupress.plugins.move-login.deny_login_access', 'secupress_pro_move_login_deny_login_access' );
/**
 * Add custom behaviour for move login
 *
 * @since 2.0
 * @author Julio Potier
 *
 **/
function secupress_pro_move_login_deny_login_access() {

	$setting       = secupress_get_module_option( 'move-login_whattodo', 'sperror', 'users-login' );
	if ( 'honeypot' === $setting && ! secupress_is_honeypotable() ) {
		$setting = 'sperror';
	}
	$error_message = '<p>' . __( 'This page does not exist, has moved or you are not allowed to access it.', 'secupress' ) . '</p>';
	$form          = true;
	
	switch ( $setting ) {
		case 'custom_page':
			$url  = secupress_get_module_option( 'move-login_custom_page_url', home_url(), 'users-login' );
			$page = wp_validate_redirect( $url, home_url() );
			wp_redirect( $page, 301 );
			die();
		break;

		case 'custom_error':
			$setting_message = wp_kses_post( secupress_get_module_option( 'move-login_custom_error_content', '', 'users-login' ) );
			$error_message   = ! empty( $setting_message ) ? $setting_message : $error_message;
		break;

		case 'honeypot':
			global $sp_action;
			$sp_action     = 'honeypot';
			$wp_login_form = wp_login_form( [ 'echo' => false ] );
			$banme_nonce   = wp_create_nonce( 'ban_me_please-' . date( 'ymdhi' ) );
			$wp_login_form = str_replace( 'action="' . wp_login_url(), 'action="' . home_url() . '/login?action=login', $wp_login_form );
			$wp_login_form = str_replace( '</form>', '<input type="hidden" name="token" value="' . $banme_nonce . '" /></form>', $wp_login_form );
			remove_action( 'login_init', 'secupress_move_login_maybe_deny_login_page', 0 );
			secupress_login_page( __( 'Log In', 'secupress' ), $wp_login_form );
		break;
	}
	echo '<style>';
	include( ABSPATH . WPINC . '/js/tinymce/skins/wordpress/wp-content.css' );
	echo '</style>';

	secupress_die( secupress_check_ban_ips_form( [ 'content'  => $error_message ] ), '', [ 'force_die' => true, 'attack_type' => 'move_login' ] );

}

add_action( 'admin_post_send_passwordless_validation_link', 'secupress_send_passwordless_validation_link' );
/**
 * Resend the validation link when activating passwordless
 *
 * @since 2.2.6
 * @author Julio Potier
**/
function secupress_send_passwordless_validation_link() {
	if ( ! isset( $_GET['_wpnonce'] ) || empty( $_GET['_wpnonce'] ) || ! check_admin_referer( 'send_passwordless_validation_link' ) ) {
		wp_die( 'Something went wrong.' );
	}
	secupress_passwordless_activation_validation_mail();
	wp_safe_redirect( wp_get_referer() );
	die();
}

/**
 * Get the user capability or role to use this plugin.
 *
 * @since 2.2.6 Deprecated
 * @since 1.0
 * @author Grégory Viguier
 *
 * @return (string) A user capability or role.
 */
function secupress_pro_sessions_control_get_capability() {
	_deprecated_function( __FUNCTION__, '2.2.6', "secupress_get_capability( false, 'sessions_control' )" );
	$capability = secupress_get_capability( false, 'sessions_control' );
	/**
	 * Filter the user capability or role.
	 *
	 * @since 2.2.6 Deprecated
	 * @since 1.0
	 *
	 * @param (string) $capability A user capability or role.
	 */
	if ( has_filter( 'secupress_pro.plugin.sessions_control.capability' ) ) {
		_deprecated_hook( 'secupress_pro.plugin.sessions_control.capability', '2.2.6', 'see secupress_get_capability()' );
	}
	return apply_filters( 'secupress_pro.plugin.sessions_control.capability', $capability );
}

/**
 * Get user IDs with active sessions.
 *
 * @since 2.2.6
 * @author Julio Potier
 *
 * @return (array) User IDs with active sessions.
 */
function secupress_pro_sessions_control_get_connected_user_ids() {
	static $user_ids = [];
	$user_ids = $user_ids ?? [];

	if ( ! empty( $user_ids ) ) {
		return $user_ids;
	}

    // Get all user IDs
    $users = get_users( [
	    'meta_key'     => 'session_tokens',
	    'meta_compare' => 'EXISTS'
	] );

    foreach ($users as $user) {
        $instance = WP_Session_Tokens::get_instance( $user->ID );
        $sessions = $instance->get_all();
        foreach ( $sessions as $session ) {
            if ( $session['expiration'] > time() ) {
                $user_ids[] = $user->ID;
                break; // No need to check further tokens for this user
            }
        }
    }

    return $user_ids;
}

/**
 * Check the verification code entered by the user.
 * @see https://github.com/emreakay/CodeIgniter-Aauth/blob/master/application/helpers/googleauthenticator_helper.php#L42
 */
function secupress_base32_verify( $secretkey, $thistry, $lasttimeslot ) {

	$shortcut = apply_filters( 'secupress.otp-auth.base32_verify', false, $thistry );
	if ( $shortcut ) {
		return true;
	}

	require_once( dirname( __FILE__ ) . '/plugins/inc/php/base32.php' );

	$tm        = floor( time() / 30 );
	$b32       = new Base32();
  	$secretkey = $b32->base32_decode( $secretkey );

	// Key from 30 seconds before is also valid.
	for ( $i = -1; $i <= 0; $i++ ) {
		// Pack time into binary string
		$time = chr( 0 ).chr( 0 ).chr( 0 ).chr( 0 ).pack( 'N*', $tm + $i );
		// Hash it with users secret key
		$hm = hash_hmac( 'SHA1', $time, $secretkey, true );
		// Use last nipple of result as index/offset
		$offset = ord( substr( $hm, -1 ) ) & 0x0F;
		// grab 4 bytes of the result
		$hashpart = substr( $hm, $offset, 4 );
		// Unpak binary value
		$value = unpack( "N", $hashpart );
		$value = $value[1];
		// Only 32 bits
		$value = $value & 0x7FFFFFFF;
		$value = $value % 1000000;
		if ( hash_equals( (string) $value, $thistry ) ) {
			// Check for replay (Man-in-the-middle) attack.
			if ( $lasttimeslot >= ( $tm + $i ) ) {
				do_action( 'secupress.otp-auth.mitm', $secretkey );
				return false;
			}
			// Return timeslot in which login happened.
			return $tm+$i;
		}
	}

	return false;
}

/**
 * Validity delay of a passwordless code, in minutes. Never below 1.
 *
 * @author Julio Potier
 * @since 2.7.2
 *
 * @return (int)
 */
function secupress_passwordless_get_timing() {
	$timing = apply_filters( 'secupress.plugin.passwordless.timing', 10 );
	if ( has_filter( 'secupress.plugin.passwordless.timing' ) ) {
		_deprecated_hook( 'secupress.plugin.passwordless.timing', '2.2.6', 'secupress.plugins.passwordless.timing' );
	}
	/**
	 * Filter the delay of validity of the email.
	 *
	 * @since 2.0
	 *
	 * @param (int) $timing In minutes.
	 */
	$timing = (int) apply_filters( 'secupress.plugins.passwordless.timing', $timing );
	if ( $timing < 1 ) {
		$timing = 1;
	}

	return $timing;
}

/**
 * Keep only the characters used in a passwordless form token.
 *
 * @author Julio Potier
 * @since 2.7.2
 *
 * @param (string) $token
 *
 * @return (string)
 */
function secupress_passwordless_sanitize_token( $token ) {
	$token = (string) $token;
	if ( ! preg_match( '/^[A-Za-z0-9]{32,128}$/', $token ) ) {
		return '';
	}

	return $token;
}

/**
 * Login URL where the magic code can be typed.
 *
 * @author Julio Potier
 * @since 2.7.2
 *
 * @param (string) $token
 *
 * @return (string)
 */
function secupress_passwordless_get_form_url( $token ) {
	$url = add_query_arg(
		[
			'action' => 'passwordless_autologin',
			'token'  => $token,
		],
		wp_login_url()
	);
	if ( function_exists( 'secupress_move_login_login_to_action' ) && secupress_is_submodule_active( 'users-login', 'move-login' ) ) {
		$url = secupress_move_login_login_to_action( $url, 'passwordless_autologin' );
	}

	return $url;
}

/**
 * Cookie that keeps the magic-code screen after its token leaves the address bar.
 *
 * @author Julio Potier
 * @since 2.7.2
 *
 * @return (string)
 */
function secupress_passwordless_form_cookie_name() {
	return 'secupress_pl_form';
}

/**
 * Options shared by setting and clearing the magic-code screen cookie.
 *
 * @author Julio Potier
 * @since 2.7.2
 *
 * @param (int) $expires Unix timestamp.
 *
 * @return (array)
 */
function secupress_passwordless_form_cookie_options( $expires ) {
	return [
		'expires'  => (int) $expires,
		'path'     => COOKIEPATH ? COOKIEPATH : '/',
		'domain'   => is_string( COOKIE_DOMAIN ) ? COOKIE_DOMAIN : '',
		'secure'   => secupress_server_is_ssl(),
		'httponly' => true,
		'samesite' => 'Lax',
	];
}

/**
 * Remember the current magic-code token until the code expires.
 *
 * @author Julio Potier
 * @since 2.7.2
 *
 * @param (string) $token
 * @param (int)    $expires Unix timestamp.
 */
function secupress_passwordless_set_form_cookie( $token, $expires ) {
	$token = secupress_passwordless_sanitize_token( $token );
	if ( ! $token || headers_sent() ) {
		return;
	}

	$name    = secupress_passwordless_form_cookie_name();
	$options = secupress_passwordless_form_cookie_options( $expires );
	setcookie( $name, $token, $options );
	if ( SITECOOKIEPATH !== COOKIEPATH ) {
		$options['path'] = SITECOOKIEPATH ? SITECOOKIEPATH : '/';
		setcookie( $name, $token, $options );
	}
	$_COOKIE[ $name ] = $token;
}

/**
 * Token stored for the magic-code screen, when the address bar no longer has it.
 *
 * @author Julio Potier
 * @since 2.7.2
 *
 * @return (string)
 */
function secupress_passwordless_get_form_cookie() {
	$name = secupress_passwordless_form_cookie_name();
	if ( empty( $_COOKIE[ $name ] ) || ! is_string( $_COOKIE[ $name ] ) ) {
		return '';
	}

	return secupress_passwordless_sanitize_token( wp_unslash( $_COOKIE[ $name ] ) );
}

/**
 * Login URL without its token when the browser already owns the form cookie.
 *
 * @author Julio Potier
 * @since 2.7.2
 *
 * @param (string) $token
 *
 * @return (string)
 */
function secupress_passwordless_get_cookie_form_url( $token ) {
	$token        = secupress_passwordless_sanitize_token( $token );
	$cookie_token = secupress_passwordless_get_form_cookie();
	if ( ! $token || ! $cookie_token || strlen( $token ) !== strlen( $cookie_token ) || ! hash_equals( $token, $cookie_token ) ) {
		return '';
	}

	return remove_query_arg( 'token', secupress_passwordless_get_form_url( $token ) );
}

/**
 * Drop the magic-code screen cookie.
 *
 * @author Julio Potier
 * @since 2.7.2
 */
function secupress_passwordless_clear_form_cookie() {
	$name = secupress_passwordless_form_cookie_name();
	if ( ! headers_sent() ) {
		$options = secupress_passwordless_form_cookie_options( time() - YEAR_IN_SECONDS );
		setcookie( $name, '', $options );
		if ( SITECOOKIEPATH !== COOKIEPATH ) {
			$options['path'] = SITECOOKIEPATH ? SITECOOKIEPATH : '/';
			setcookie( $name, '', $options );
		}
	}
	unset( $_COOKIE[ $name ] );
}

/**
 * Pending magic-code state for a user, when the delay is not over.
 *
 * @author Julio Potier
 * @since 2.7.2
 *
 * @param (int) $user_id
 *
 * @return (array|null) Null when no code session is waiting.
 */
function secupress_passwordless_get_pending_state( $user_id ) {
	$user_id  = (int) $user_id;
	$timeout  = (int) get_user_meta( $user_id, 'secupress_passwordless_timeout', true );
	$token    = secupress_passwordless_sanitize_token( (string) get_user_meta( $user_id, 'secupress_passwordless_token', true ) );
	$code     = (string) get_user_meta( $user_id, 'secupress_passwordless_code', true );
	$attempts = (int) get_user_meta( $user_id, 'secupress_passwordless_attempts', true );

	if ( ! $token || $timeout <= time() ) {
		return null;
	}

	$max_attempts = (int) secupress_get_module_option( 'login-protection_number_attempts', 5, 'users-login' );
	if ( ! $code && $attempts < $max_attempts ) {
		return null;
	}

	return [
		'token'     => $token,
		'timeout'   => $timeout,
		'attempts'  => $attempts,
		'locked'    => ( $attempts >= $max_attempts || ! $code ),
		'remaining' => $timeout - time(),
	];
}

/**
 * Delete every user meta used by a passwordless login attempt.
 *
 * @author Julio Potier
 * @since 2.7.2
 *
 * @param (int) $user_id
 */
function secupress_passwordless_delete_login_metas( $user_id ) {
	$user_id = (int) $user_id;
	delete_user_meta( $user_id, 'secupress_passwordless_token' );
	delete_user_meta( $user_id, 'secupress_passwordless_code' );
	delete_user_meta( $user_id, 'secupress_passwordless_rememberme' );
	delete_user_meta( $user_id, 'secupress_passwordless_timeout' );
	delete_user_meta( $user_id, 'secupress_passwordless_redirect' );
	delete_user_meta( $user_id, 'secupress_passwordless_attempts' );
	delete_user_meta( $user_id, 'secupress_passwordless_session' );
}

/**
 * Use this to send a passwordless code to anyone.
 *
 * @since 2.7.2 A 6-digit code replaces the magic link. `force` bypasses the current delay.
 * @since 2.2.1
 * @author Julio Potier
 *
 * @param (WP_User|int|string) $raw_user
 * @param (array) $args [ 'redirect_to' => (string), 'rememberme' => 0|1, 'sendmail' => (bool), 'force' => (bool) ]
 *
 * @return (array)
 */
function secupress_passwordless_send_link( $raw_user, $args = [] ) {
	// Step 1 for everybody: if not a user yet, try to find them by ID, username or email.
	$raw_user  = secupress_get_user_by( $raw_user );
	if ( ! secupress_is_user( $raw_user ) ) {
		return [ 'success' => false, 'is_user' => false ];
	}

	$defaults = [
		'redirect_to' => '',
		'rememberme'  => 0,
		'sendmail'    => true,
		'force'       => false,
	];
	$args     = wp_parse_args( $args, $defaults );

	if ( secupress_is_submodule_active( 'users-login', 'user-creation-protection' ) ) {
		if ( secupress_is_fake_user( $raw_user->ID, true ) ) {
			secupress_kill_fake_user( $raw_user->ID );
		}
		if ( in_array( $raw_user->ID, secupress_get_pending_user_ids() ) ) {
			return [ 'success' => false, 'is_user' => false ];
		}
	}

	if ( ! $args['sendmail'] ) {
		remove_all_filters( 'random_password' );
		$key = wp_generate_password( 32, false );
		delete_user_meta( $raw_user->ID, 'secupress_passwordless_code' );
		delete_user_meta( $raw_user->ID, 'secupress_passwordless_attempts' );
		delete_user_meta( $raw_user->ID, 'secupress_passwordless_redirect' );
		update_user_meta( $raw_user->ID, 'secupress_passwordless_token', $key );
		update_user_meta( $raw_user->ID, 'secupress_passwordless_timeout', time() + ( secupress_passwordless_get_timing() * MINUTE_IN_SECONDS ) + 1 );
		update_user_meta( $raw_user->ID, 'secupress_passwordless_rememberme', (int) ! empty( $args['rememberme'] ) );
		$redirect_query = '';
		if ( ! empty( $args['redirect_to'] ) && is_string( $args['redirect_to'] ) ) {
			$redirect_query = '&redirect_to=' . rawurlencode( $args['redirect_to'] );
		}
		$token_url = admin_url( 'admin-post.php?action=passwordless_autologin&token=' . $key . $redirect_query );

		return [
			'success'   => true,
			'is_user'   => true,
			'WP_User'   => $raw_user,
			'mailsent'  => false,
			'token_url' => $token_url,
		];
	}

	if ( empty( $args['force'] ) ) {
		$pending = secupress_passwordless_get_pending_state( $raw_user->ID );
		if ( $pending ) {
			$form_url = secupress_passwordless_get_cookie_form_url( $pending['token'] );

			return [
				'success'      => true,
				'is_user'      => true,
				'WP_User'      => $raw_user,
				'mailsent'     => false,
				'form_url'     => $form_url,
				'token_url'    => $form_url,
				'already_sent' => empty( $pending['locked'] ),
				'locked'       => ! empty( $pending['locked'] ),
			];
		}
	}

	remove_all_filters( 'random_password' );
	$token       = wp_generate_password( 64, false );
	$code        = str_pad( (string) random_int( 0, 999999 ), 6, '0', STR_PAD_LEFT );
	$timing      = secupress_passwordless_get_timing();
	$redirect_to = '';
	if ( ! empty( $args['redirect_to'] ) && is_string( $args['redirect_to'] ) ) {
		$redirect_to = wp_sanitize_redirect( $args['redirect_to'] );
	}

	update_user_meta( $raw_user->ID, 'secupress_passwordless_code', wp_hash_password( $code ) );
	update_user_meta( $raw_user->ID, 'secupress_passwordless_token', $token );
	update_user_meta( $raw_user->ID, 'secupress_passwordless_timeout', time() + ( $timing * MINUTE_IN_SECONDS ) + 1 );
	update_user_meta( $raw_user->ID, 'secupress_passwordless_rememberme', (int) ! empty( $args['rememberme'] ) );
	update_user_meta( $raw_user->ID, 'secupress_passwordless_redirect', $redirect_to );
	update_user_meta( $raw_user->ID, 'secupress_passwordless_attempts', 0 );

	$form_url   = secupress_passwordless_get_form_url( $token );
	$subject    = sprintf(
		/* translators: 1: site name, 2: 6-digit code. */
		__( '[%1$s] %2$s is your magic code for a secure login (2FA)', 'secupress' ),
		'###SITENAME###',
		$code
	);
	$subject    = apply_filters( 'secupress.plugin.passwordless_email_subject', $subject, $raw_user );
	if ( has_filter( 'secupress.plugin.passwordless_email_subject' ) ) {
		_deprecated_hook( 'secupress.plugin.passwordless_email_subject', '2.2.6', 'secupress.plugins.passwordless_email_subject' );
	}
	/**
	 * Filter the subject of the mail sent to the user.
	 *
	 * @since 2.0 $raw_user parameter
	 * @since 1.0
	 *
	 * @param (string) $subject The email subject.
	 * @param (WP_User) $raw_user The user
	 */
	$subject    = apply_filters( 'secupress.plugins.passwordless_email_subject', $subject, $raw_user );
	$body       = sprintf(
		/** Translators: 1 is a user name, 2 is a 6-digit code, 3 is the page where the code is entered. */
		__( 'Hello %1$s,

You recently tried to log in on ###SITEURL###.

If this is correct, please enter the following code to really log in:
%2$s

Enter this code on the following page:
%3$s

You can safely ignore and delete this email if you do not want to take this action.

Regards,
All at ###SITENAME###
###SITEURL###', 'secupress' ),
		esc_html( $raw_user->display_name ),
		esc_html( $code ),
		esc_url_raw( $form_url ),
	);

	$body = apply_filters( 'secupress.plugin.passwordless_email_message', $body, $raw_user, $code, $form_url );
	if ( has_filter( 'secupress.plugin.passwordless_email_message' ) ) {
		_deprecated_hook( 'secupress.plugin.passwordless_email_message', '2.2.6', 'secupress.plugins.passwordless_email_message' );
	}
	/**
	 * Filter the body of the mail sent to the user.
	 * You can use ###ADMIN_EMAIL###, ###SITENAME###, ###SITEURL### as placeholder if needed.
	 *
	 * @since 2.7.2 The third parameter is the plain magic code. The fourth is the page where it is entered.
	 * @since 2.0 $raw_user and $token_url parameters
	 * @since 1.0
	 *
	 * @param (string)  $body     The email body.
	 * @param (WP_User) $raw_user The user.
	 * @param (string)  $code     The 6-digit code.
	 * @param (string)  $form_url The page where the code is entered.
	 */
	$body = apply_filters( 'secupress.plugins.passwordless_email_message', $body, $raw_user, $code, $form_url );

	secupress_send_mail( $raw_user->user_email, $subject, $body );

	return [
		'success'      => true,
		'is_user'      => true,
		'WP_User'      => $raw_user,
		'mailsent'     => true,
		'form_url'     => $form_url,
		'token_url'    => $form_url,
		'already_sent' => false,
		'locked'       => false,
	];
}

/**
 * Destroy sessions, cookies and passwordless tokens for a fake user, then die.
 *
 * @since 2.7
 * @author Julio Potier
 *
 * @param (int) $user_id
 **/
function secupress_kill_fake_user( $user_id ) {
	$user_id = (int) $user_id;
	if ( $user_id > 0 ) {
		if ( class_exists( 'WP_Session_Tokens' ) ) {
			WP_Session_Tokens::get_instance( $user_id )->destroy_all();
		}
		wp_clear_auth_cookie();
		secupress_passwordless_delete_login_metas( $user_id );
	}

	secupress_die( '', '', array( 'force_die' => true, 'attack_type' => 'users', 'response' => 403 ) );
}

/**
 * Callback to destroy all sessions for all users (no JS).
 *
 * @since 2.2.6 $force
 * @author Julio Potier
 * @author Grégory Viguier
 * 
 * @param (bool) $keep_current_user_session true to keep the current user session
 */
function secupress_pro_sessions_control_destroy_all_sessions( $keep_current_user_session = false ) {
	// Get current user session.
	if ( $keep_current_user_session ) {
		$sessions_inst   = WP_Session_Tokens::get_instance( get_current_user_id() );
		$token_to_keep   = wp_get_session_token();
		$session_to_keep = $sessions_inst->get( $token_to_keep );
	}

	/** This filter is documented in /wp-includes/session.php */
	$manager = apply_filters( 'session_token_manager', 'WP_User_Meta_Session_Tokens' );
	call_user_func( array( $manager, 'destroy_all_for_all_users' ) );

	// Recreate current session.
	if ( $keep_current_user_session ) {
		$sessions_inst->update( $token_to_keep, $session_to_keep );
	}
}

/**
 * Handles sending password retrieval email to user.
 *
 * @since 2.2.6
 * @author Julio Potier
 * 
 * @see retrieve_password()
 * 
 * @param (WP_User) $user_data
 * @param (bool) $with_email true will send the password reset email
 * 
 * @return (bool)
 */
function secupress_pro_reset_passwords( $user_data, $with_email ) { 
	$key      = get_password_reset_key( $user_data );

	wp_set_password( wp_generate_password( 64 ), $user_data->ID ); // Force password change

	if ( is_wp_error( $key ) ) {
		return false;
	}

	if ( ! $with_email ) {
		return true;
	}

	// with email
	// Redefining user_login ensures we return the right case in the email.
	$user_login = $user_data->user_login;
	$user_email = $user_data->user_email;
	if ( is_multisite() ) {
		$site_name = get_network()->site_name;
	} else {
		/*
		 * The blogname option is escaped with esc_html on the way into the database
		 * in sanitize_option we want to reverse this for the plain text arena of emails.
		 */
		$site_name = wp_specialchars_decode( get_option( 'blogname' ), ENT_QUOTES );
	}

	$message = __( 'A person from the website administration has requested a password reset for your account:', 'secupress' ) . "\r\n\r\n";
	/* translators: %s: Site name. */
	$message .= sprintf( __( 'Site Name: %s', 'secupress' ), $site_name ) . "\r\n\r\n";
	/* translators: %s: User login. */
	$message .= sprintf( __( 'Username: %s', 'secupress' ), $user_login ) . "\r\n\r\n";
	$message .= __( 'To reset your password, visit the following address:', 'secupress' ) . "\r\n\r\n";
	$message .= network_site_url( "wp-login.php?action=rp&key=$key&login=" . rawurlencode( $user_login ), 'login' ) . "\r\n";

	/* translators: Password reset notification email subject. %s: Site title. */
	$title = sprintf( __( '[%s] Mandatory Password Reset', 'secupress' ), $site_name );

	/**
	 * Filters the subject of the password reset email.
	 *
	 * @since 2.2.6
	 *
	 * @param string  $title      Default email title.
	 * @param string  $user_login The username for the user.
	 * @param WP_User $user_data  WP_User object.
	 */
	$title = apply_filters( 'secupress.retrieve_password_title', $title, $user_login, $user_data );

	/**
	 * Filters the message body of the password reset mail.
	 *
	 * If the filtered message is empty, the password reset email will not be sent.
	 *
	 * @since 2.2.6
	 *
	 * @param string  $message    Default mail message.
	 * @param string  $key        The activation key.
	 * @param string  $user_login The username for the user.
	 * @param WP_User $user_data  WP_User object.
	 */
	$message = apply_filters( 'secupress.retrieve_password_message', $message, $key, $user_login, $user_data );

	return wp_mail( $user_email, wp_specialchars_decode( $title ), $message );
}

/**
 * Return true if the passwordless module is activated and validated.
 *
 * @since 2.5
 * @author Julio Potier
 *
 * @return (bool|int) The user ID if the module is validated, true if active.
 */
function secupress_passwordless_is_activated() {
	return secupress_get_option( 'secupress_passwordless_activation_validation' );
}

/**
 * Set the user ID in the options to validate the passwordless module.
 *
 * @since 2.5
 * @author Julio Potier
 *
 * @return (void)
 */
function secupress_passwordless_set_user_id() {
	$options = get_site_option( SECUPRESS_SETTINGS_SLUG );
	if ( isset( $options['secupress_passwordless_activation_validation'] ) && true === $options['secupress_passwordless_activation_validation'] ) {
		return;
	}
	$options['secupress_passwordless_activation_validation'] = get_current_user_id();
	secupress_update_options( $options );
}
