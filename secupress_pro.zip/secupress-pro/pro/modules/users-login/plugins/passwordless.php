<?php
/**
 * Module Name: PasswordLess Double Authentication
 * Description: When you try to log in, you'll receive an email containing a validation code. Without entering it, you can't log in.
 * Main Module: users_login
 * Author: SecuPress
 * Version: 2.4.1
 */

defined( 'SECUPRESS_VERSION' ) or die( 'Something went wrong.' );

if ( ! secupress_passwordless_is_activated() ) {
	return;
}

// EMERGENCY BYPASS!
if ( defined( 'SECUPRESS_ALLOW_LOGIN_ACCESS' ) && constant( 'SECUPRESS_ALLOW_LOGIN_ACCESS' ) ) {
	return;
}

add_filter( 'authenticate', 'secupress_passwordless_login_authenticate', SECUPRESS_INT_MAX - 10, 3 );
/**
 * Send an email with the magic code.
 *
 * @since 2.2.1 If your role is affected by PasswordLess, force it.
 * @since 1.0
 * @author Julio Potier
 *
 * @param (object) $raw_user A WP_Error object if user is not correctly authenticated, a WP_User object if he is.
 * @param (string) $username A username or email address.
 * @param (string) $password User password.
 *
 * @return (object) A WP_Error or WP_User object.
 */
function secupress_passwordless_login_authenticate( 
	$raw_user, 
	$username, 
	#[\SensitiveParameter]
	$password
) {
	static $running = false;

	if ( isset( $_POST['passwordless_get_magik_link'] ) ) { // WPCS: CSRF ok.
		$_POST['pwd'] = '';
		$password     = '';
	}

	// Errors from other plugins.
	if ( is_wp_error( $raw_user ) ) {
		unset( $raw_user->errors['empty_username'], $raw_user->errors['empty_password'] );
		if ( isset( $_POST['passwordless_get_magik_link'] ) ) { // WPCS: CSRF ok.
			unset( $raw_user->errors['incorrect_password'] );
			if ( secupress_is_submodule_active( 'users-login', 'stop-user-enumeration' ) ) {
				unset( $raw_user->errors['invalid_username'], $raw_user->errors['invalid_email'] );
			}
		}

		if ( $raw_user->errors ) {
			// There are still errors, don't go further.
			$running = false;
			return $raw_user;
		}
	}

	if ( $running || 'POST' !== $_SERVER['REQUEST_METHOD'] ) {
		return $raw_user;
	}
	$running = true;

	// Make sure to process only credentials provided by the login form.
	$username = ! empty( $_POST['log'] ) && $username === $_POST['log'] ? $username : ''; // WPCS: CSRF ok.
	$password = ! empty( $_POST['pwd'] ) && $password === $_POST['pwd'] ? $password : ''; // WPCS: CSRF ok.

	if ( ! $username && ! $password || $username && $password ) {
		$running = false;
		if ( ! secupress_is_affected_role( 'users-login', 'double-auth', $raw_user ) ) {
			return $raw_user;
		} else {
			$error_msg = __( 'You cannot login using your password, please just fill your login or email address.', 'secupress' );
			$wp_error  = new WP_Error( 'authentication_failed', $error_msg );
			return $wp_error;
		}
	}
	if ( $username && isset( $_POST['passwordless_get_magik_link'] ) ) {
		if ( ! secupress_is_user( $raw_user ) ) {
			$by           = is_email( $username ) ? 'email' : 'login';
			$temp_user    = get_user_by( $by, $username );
			// if the login was a fake email like "foobar@example.com", try now with a login.
			if ( ! secupress_is_user( $temp_user ) && is_email( $username ) ) {
				$raw_user = get_user_by( 'login', $username );
			} else {
				$raw_user = $temp_user;
			}
		}
	}

	$redirect_to = '';
	if ( isset( $_REQUEST['redirect_to'] ) && is_string( $_REQUEST['redirect_to'] ) ) {
		$redirect_to = wp_unslash( $_REQUEST['redirect_to'] );
	}
	$result = secupress_passwordless_send_link(
		$raw_user,
		[
			'redirect_to' => $redirect_to,
			'rememberme'  => empty( $_REQUEST['rememberme'] ) ? 0 : 1,
		]
	);
	if ( ( empty( $result['success'] ) || empty( $result['form_url'] ) ) && secupress_is_submodule_active( 'users-login', 'stop-user-enumeration' ) ) {
		$result = secupress_passwordless_begin_unknown( $username );
	}
	if ( ! empty( $result['success'] ) && ! empty( $result['form_url'] ) ) {
		$form_url = $result['form_url'];
		if ( ! empty( $result['already_sent'] ) ) {
			$form_url = add_query_arg( 'pending', '1', $form_url );
		}
		wp_safe_redirect( $form_url );
		die();
	} else {
		$errors = new WP_Error();
		if ( ! empty( $result['success'] ) ) {
			$errors->add( 'passwordless_already_sent', __( 'A code has already been sent. You can request a new one when the countdown ends.', 'secupress' ) );
		} else {
			$errors->add( 'invalid_username', __( '<strong>Error</strong>: Invalid username or email.', 'secupress' ) );
		}
		return $errors;
	}

	return $raw_user; // Should not happen
}

add_action( 'login_head', 'secupress_passwordless_buffer_start_login' );
/**
 * Start the buffer if we are on the login page.
 *
 * @since 1.0
 * @author Julio Potier
 */
function secupress_passwordless_buffer_start_login() {
	if ( ! isset( $_GET['action'] ) || 'login' === $_GET['action'] ) {
		ob_start( 'secupress_passwordless_hide_password_field_ob' );
	}
}

add_action( 'login_footer', 'secupress_passwordless_buffer_stop', 1000 );
/**
 * End the buffer if we are on the login page + not passwordless.
 *
 * @since 2.0 load gravatar if possible
 * @since 1.0
 * @author Julio Potier
 */
function secupress_passwordless_buffer_stop() {
	if ( isset( $_GET['action'] ) && 'login' !== $_GET['action'] && 'notpasswordless' !== $_GET['action'] ) {
		return;
	}
	?>
	<script>
	jQuery('#user_login').on('keyup',
		function() {
			var val = jQuery('#user_login').val();
			var md5email = jQuery('#md5email').length;
			var md5val   = md5email ? jQuery('#md5email').val() : '';
			if ( val.includes('@') ) { // Works only for email logins.
				var url  = jQuery('#loginform').val();
				if (url.indexOf('?') === -1) {
					url += '?';
				} else {
					url += '&';
				}
				url += 'action=md5&e=' + val;
				var ajax = jQuery.getJSON( url )
				.always( function(data) {
					jQuery('.login h1 a').css({ "background-image": 'url(https://0.gravatar.com/avatar/' + data.responseText + '?s:180)', "border-radius": '100%'});
				});
			} else if ( md5email && 32 === md5val.length ) {
				jQuery('.login h1 a').css({ "background-image": 'url(https://0.gravatar.com/avatar/' + md5val + '?s:180)', "border-radius": '100%'});
			} else {
				jQuery('.login h1 a').css({ "background-image": ''});
			}
		}
	).trigger('keyup');

	jQuery('.hide-if-js').hide().find('input[type="password"]').prop('disabled', true);
	jQuery('#wp-submit').val(jQuery('#wp-submit').data('newvalue')).css('margin-bottom', '10px');
	jQuery('.forgetmenot').insertAfter('.submit');
	<?php 
	$sp_roles = secupress_get_module_option( 'double-auth_affected_role', [], 'users-login' );

	if ( count( $sp_roles ) ) { // Not everyone is affected, let the choice
	?>
	jQuery('#loginwithpassword').css('display', 'inline-block');
	jQuery('#loginwithpassword button:first').on('click', function(e){
		jQuery(this).parent().remove();
		jQuery('.forgetmenot').insertBefore('.submit');
		jQuery('.user-pass-wrap').show().find('input').prop('disabled', false).focus();
		jQuery('[name=passwordless_get_magik_link]').remove();
		jQuery('#wp-submit').val(jQuery('#wp-submit').data('origvalue')).css('margin-bottom', '0px');
	});
	<?php } ?>
	</script>
	<?php

	ob_end_flush();

	// Focus the password field.
	if ( ! isset( $_GET['action'] ) || 'notpasswordless' !== $_GET['action'] ) {
		return;
	}

	?>
<script type="text/javascript">
function secupress_attempt_focus() {
	setTimeout( function() {
		try {
			d = document.getElementById( 'user_pass' );
			d.focus();
			d.select();
		} catch( e ) {}
	}, 300 );
}

secupress_attempt_focus();

if ( typeof wpOnload === 'function' ) {
	wpOnload();
}
</script>
	<?php
}


/**
 * Alter the buffer content to hide the password label and field.
 *
 * @since 2.2.1 New UI/UX
 * @since 1.0
 * @author Julio Potier
 *
 * @param (string) $buffer Contains the login page between the action `login_head` and `login_footer`.
 *
 * @return (string)
 */
function secupress_passwordless_hide_password_field_ob( $buffer ) {
	$sp_roles = secupress_get_module_option( 'double-auth_affected_role', [], 'users-login' );

	$buffer   = str_replace( '<div class="user-pass-wrap">', '<div class="user-pass-wrap hide-if-js"><input type="hidden" name="passwordless_get_magik_link" value="1" />', $buffer );
	$buffer   = str_replace( 'value="' . esc_attr__( 'Log In' ) . '"', 'data-origvalue="' . esc_attr__( 'Log In' ) . '" data-newvalue="' . esc_attr__( 'Get my Magic Code', 'secupress' ) . '" value="' . esc_attr__( 'Log In' ) . '"', $buffer );
	if ( count( $sp_roles ) ) { // Not everyone is affected, let the choice
		$buffer   = str_replace( '</form>', sprintf( '<div id="loginwithpassword" style="display:none;line-height:2.35em">— %1$s <button type="button" class="button-secondary button-link" style="font-weight:600">%2$s</button></div>', __( 'or', 'secupress' ), __( 'Log In using a password', 'secupress' ) ) . '</form>', $buffer );
	}
	return $buffer;
}

add_filter( 'mepr-validate-login', 'secupress_passwordless_support_memberpress' );
/**
 * Support PasswordLess 2FA for MemberPress plugin
 *
 * @since 2.2 
 * @author Julio Potier 
 * @param (array) $errors
 * @return (array) $errors
 **/
function secupress_passwordless_support_memberpress( $errors ) {
	if ( ! isset( $_SERVER['REQUEST_METHOD'], $_POST['log'] ) || 'POST' !== $_SERVER['REQUEST_METHOD'] ) {
		return $errors;
	}

	// Check for login by email address
	$by   = is_email( $_POST['log'] ) ? 'email' : 'login'; 
	$user = get_user_by( $by, $_POST['log'] );

	if ( ! is_wp_error( $user ) && secupress_is_affected_role( 'users-login', 'double-auth', $user ) ) {
		$message  = apply_filters( 'secupress.passwordless.memberpress_message', __( 'You cannot login using this page.', 'secupress' ) );
		$errors[] = $message;
	}

	return $errors;
}

add_filter( 'user_row_actions', 'secupress_passwordless_add_magiclink', 10, 2 );
/**
 * Add a "send a magic code" action for users
 *
 * @param (array) $actions
 * @param (WP_User) $user_object
 * @author Julio Potier
 * @since 2.2.1
 * @return (array) $actions
 **/
function secupress_passwordless_add_magiclink( $actions, $user_object, $force = false ) {
	if ( $force || ( get_current_user_id() !== $user_object->ID && current_user_can( 'edit_user', $user_object->ID ) ) ) {
		$actions['passwordless_magiclink'] = '<a class="resetpassword" href="' . wp_nonce_url( admin_url( 'admin-post.php?action=send_passwordless_magiclink&uid=' . $user_object->ID ), 'passwordless_magiclink_' . $user_object->ID ) . '">' . __( 'Send PasswordLess Magic Code', 'secupress' ) . '</a>';
	}
	return $actions;
}

add_action( 'admin_post_send_passwordless_magiclink', 'secupress_passwordless_send_magiclink' );
/**
 * Send a magic code even if the user is not affected by its role. This bypasses the current delay.
 *
 * @since 2.2.1
 * @author Julio Potier
 **/
function secupress_passwordless_send_magiclink() {
	$uid = isset( $_GET['uid'] ) ? absint( $_GET['uid'] ) : 0;
	if ( ! $uid || ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( $_GET['_wpnonce'], 'passwordless_magiclink_' . $uid ) ) {
		wp_die( __( 'Magic Code not sent.', 'secupress' ) );
	}
	$result  = secupress_passwordless_send_link( $uid, [ 'force' => true ] );
	$message = ! empty( $result['success'] ) ? 'ok' : 'ko';
	wp_safe_redirect( admin_url( 'users.php?message=passwordless_' . $message ) );
	die();
}

add_action( 'admin_head-users.php', 'secupress_passwordless_messages' );
/**
 * Manage the feedback message from the magic code admin action
 *
 * @since 2.2.1
 * @author Julio Potier
 **/
function secupress_passwordless_messages() {
	if ( ! isset( $_GET['message'] ) ) {
		return;
	}
	switch ( $_GET['message'] ) {
		case 'passwordless_ko':
			echo '<div class="error"><p>' . __( 'Magic Code not sent.', 'secupress' ) . '</p></div>';
		break;
		case 'passwordless_ok':
			echo '<div class="updated"><p>' . __( 'Magic Code has been sent.', 'secupress' ) . '</p></div>';
		break;
	}
}

add_filter( 'allow_password_reset', 'secupress_passwordless_disable_password_reset_for_some_users', 10, 2 );
/**
 * Prevent password reset for affected roles
 *
 * @since 2.4
 * @author Julio Potier
 * 
 * @param (bool) $allow
 * @param (int) $user_id
 * 
 * @return (bool)
 **/
function secupress_passwordless_disable_password_reset_for_some_users( $allow, $user_id ) {
	$user = secupress_get_user_by( $user_id );
	if ( secupress_is_affected_role( 'users-login', 'double-auth', $user ) ) {
		return false;
	}
	return $allow;
}


/**
 * Find the single user who owns a passwordless token.
 *
 * @author Julio Potier
 * @since 2.7.2
 *
 * @param (string) $token
 *
 * @return (WP_User|false)
 */
function secupress_passwordless_get_user_by_token( $token ) {
	$token = secupress_passwordless_sanitize_token( $token );
	if ( ! $token ) {
		return false;
	}

	remove_all_actions( 'pre_get_users' );
	$user_ids = get_users(
		[
			'meta_key'   => 'secupress_passwordless_token',
			'meta_value' => $token,
			'fields'     => 'ID',
			'number'     => 2,
		]
	);
	if ( 1 !== count( $user_ids ) ) {
		return false;
	}

	$user = get_user_by( 'id', (int) reset( $user_ids ) );
	if ( ! secupress_is_user( $user ) ) {
		return false;
	}

	return $user;
}

/**
 * Format a remaining delay as mm:ss.
 *
 * @author Julio Potier
 * @since 2.7.2
 *
 * @param (int) $remaining Seconds.
 *
 * @return (string)
 */
function secupress_passwordless_format_remaining( $remaining ) {
	$remaining = max( 0, (int) $remaining );

	return sprintf( '%02d:%02d', (int) floor( $remaining / MINUTE_IN_SECONDS ), $remaining % MINUTE_IN_SECONDS );
}

/**
 * Hash an identifier that has no account, so the transient never stores it in clear.
 *
 * @author Julio Potier
 * @since 2.7.2
 *
 * @param (string) $username Login or email as typed.
 *
 * @return (string)
 */
function secupress_passwordless_unknown_hash( $username ) {
	$username = strtolower( trim( (string) $username ) );

	return hash_hmac( 'sha256', $username, wp_salt( 'auth' ) );
}

/**
 * Unknown-identifier magic-code sessions still inside their delay.
 *
 * @author Julio Potier
 * @since 2.7.2
 *
 * @return (array)
 */
function secupress_passwordless_unknown_get_bag() {
	$bag = secupress_get_site_transient( 'secupress_pl_unknown' );
	if ( ! is_array( $bag ) ) {
		return [];
	}

	$now     = time();
	$changed = false;
	foreach ( $bag as $hash => $entry ) {
		if ( ! is_array( $entry ) || empty( $entry['token'] ) || empty( $entry['timeout'] ) || (int) $entry['timeout'] <= $now ) {
			unset( $bag[ $hash ] );
			$changed = true;
		}
	}
	if ( $changed ) {
		secupress_passwordless_unknown_set_bag( $bag );
	}

	return $bag;
}

/**
 * Save the unknown-identifier magic-code sessions.
 *
 * @author Julio Potier
 * @since 2.7.2
 *
 * @param (array) $bag
 */
function secupress_passwordless_unknown_set_bag( $bag ) {
	if ( ! $bag ) {
		secupress_delete_site_transient( 'secupress_pl_unknown' );
		return;
	}

	$timeout = 0;
	foreach ( $bag as $entry ) {
		$timeout = max( $timeout, (int) $entry['timeout'] );
	}
	secupress_set_site_transient( 'secupress_pl_unknown', $bag, max( 1, $timeout - time() ) );
}

/**
 * Shape one unknown session like a real pending magic-code state.
 *
 * @author Julio Potier
 * @since 2.7.2
 *
 * @param (string) $hash
 * @param (array)  $entry
 *
 * @return (array)
 */
function secupress_passwordless_unknown_format_state( $hash, $entry ) {
	$attempts = (int) $entry['attempts'];
	$timeout  = (int) $entry['timeout'];

	return [
		'unknown'   => true,
		'hash'      => $hash,
		'token'     => (string) $entry['token'],
		'timeout'   => $timeout,
		'attempts'  => $attempts,
		'locked'    => $attempts >= (int) secupress_get_module_option( 'login-protection_number_attempts', 5, 'users-login' ),
		'remaining' => $timeout - time(),
	];
}

/**
 * Find an unknown magic-code session from its form token.
 *
 * @author Julio Potier
 * @since 2.7.2
 *
 * @param (string) $token
 *
 * @return (array|null)
 */
function secupress_passwordless_unknown_state_by_token( $token ) {
	$token = secupress_passwordless_sanitize_token( $token );
	if ( ! $token ) {
		return null;
	}

	foreach ( secupress_passwordless_unknown_get_bag() as $hash => $entry ) {
		$stored = secupress_passwordless_sanitize_token( (string) $entry['token'] );
		if ( $stored && strlen( $stored ) === strlen( $token ) && hash_equals( $stored, $token ) ) {
			return secupress_passwordless_unknown_format_state( $hash, $entry );
		}
	}

	return null;
}

/**
 * Open the same magic-code form for an identifier that has no account, without sending mail.
 *
 * @author Julio Potier
 * @since 2.7.2
 *
 * @param (string) $username Login or email as typed.
 *
 * @return (array)
 */
function secupress_passwordless_begin_unknown( $username ) {
	$username = trim( (string) $username );
	if ( '' === $username ) {
		return [ 'success' => false, 'is_user' => false ];
	}

	$hash = secupress_passwordless_unknown_hash( $username );
	$bag  = secupress_passwordless_unknown_get_bag();
	if ( ! empty( $bag[ $hash ] ) && is_array( $bag[ $hash ] ) ) {
		$state    = secupress_passwordless_unknown_format_state( $hash, $bag[ $hash ] );
		$form_url = secupress_passwordless_get_cookie_form_url( $state['token'] );

		return [
			'success'      => true,
			'is_user'      => false,
			'mailsent'     => false,
			'form_url'     => $form_url,
			'token_url'    => $form_url,
			'already_sent' => empty( $state['locked'] ),
			'locked'       => ! empty( $state['locked'] ),
		];
	}

	remove_all_filters( 'random_password' );
	$token        = wp_generate_password( 64, false );
	$timeout      = time() + ( secupress_passwordless_get_timing() * MINUTE_IN_SECONDS ) + 1;
	$bag[ $hash ] = [
		'token'    => $token,
		'timeout'  => $timeout,
		'attempts' => 0,
	];
	secupress_passwordless_unknown_set_bag( $bag );
	$form_url = secupress_passwordless_get_form_url( $token );

	return [
		'success'      => true,
		'is_user'      => false,
		'mailsent'     => false,
		'form_url'     => $form_url,
		'token_url'    => $form_url,
		'already_sent' => false,
		'locked'       => false,
	];
}

add_action( 'login_form_passwordless_autologin', 'secupress_passwordless_autologin_validation' );
/**
 * Show the magic-code form, or log the user in when the code is correct.
 *
 * @since 2.7.2 Magic code screen. An unknown, expired or replaced token redirects to the login page. A reload without the token uses the screen cookie.
 * @since 1.0
 * @author Julio Potier
 */
function secupress_passwordless_autologin_validation() {
	$token = '';
	if ( isset( $_REQUEST['token'] ) && is_string( $_REQUEST['token'] ) ) {
		$token = secupress_passwordless_sanitize_token( wp_unslash( $_REQUEST['token'] ) );
	}
	if ( ! $token && isset( $_SERVER['REQUEST_METHOD'] ) && 'GET' === $_SERVER['REQUEST_METHOD'] ) {
		$token = secupress_passwordless_get_form_cookie();
	}
	$user  = $token ? secupress_passwordless_get_user_by_token( $token ) : false;
	$state = ( $user instanceof WP_User ) ? secupress_passwordless_get_pending_state( $user->ID ) : null;
	if ( ! $state && secupress_is_submodule_active( 'users-login', 'stop-user-enumeration' ) ) {
		$state = secupress_passwordless_unknown_state_by_token( $token );
	}

	if ( ! $state || strlen( $state['token'] ) !== strlen( $token ) || ! hash_equals( $state['token'], $token ) ) {
		secupress_passwordless_clear_form_cookie();
		wp_safe_redirect( wp_login_url() );
		die();
	}

	if ( isset( $_SERVER['REQUEST_METHOD'] ) && 'POST' === $_SERVER['REQUEST_METHOD'] && isset( $_POST['secupress_passwordless_code'] ) ) {
		if ( ! empty( $state['unknown'] ) ) {
			secupress_passwordless_handle_unknown_code_post( $state, $token );
		} else {
			secupress_passwordless_handle_code_post( $user, $state, $token );
		}
	}

	secupress_passwordless_render_code_screen( $state, $token );
}

/**
 * Check a submitted magic code.
 *
 * @author Julio Potier
 * @since 2.7.2
 *
 * @param (WP_User) $user
 * @param (array)   $state
 * @param (string)  $token
 */
function secupress_passwordless_handle_code_post( $user, $state, $token ) {
	if ( ! empty( $state['locked'] ) ) {
		return;
	}

	$nonce = '';
	if ( isset( $_POST['_wpnonce'] ) && is_string( $_POST['_wpnonce'] ) ) {
		$nonce = wp_unslash( $_POST['_wpnonce'] );
	}
	if ( ! wp_verify_nonce( $nonce, 'secupress_passwordless_code_' . $token ) ) {
		wp_safe_redirect( secupress_passwordless_get_form_url( $token ) );
		die();
	}

	$code = '';
	if ( isset( $_POST['secupress_passwordless_code'] ) && is_string( $_POST['secupress_passwordless_code'] ) ) {
		$code = preg_replace( '/\D/', '', wp_unslash( $_POST['secupress_passwordless_code'] ) );
	}
	$hash = (string) get_user_meta( $user->ID, 'secupress_passwordless_code', true );

	if ( 6 !== strlen( $code ) || ! $hash || ! wp_check_password( $code, $hash ) ) {
		$attempts = (int) get_user_meta( $user->ID, 'secupress_passwordless_attempts', true );
		++$attempts;
		update_user_meta( $user->ID, 'secupress_passwordless_attempts', $attempts );
		secupress_passwordless_flag_invalid_code();
		if ( $attempts >= (int) secupress_get_module_option( 'login-protection_number_attempts', 5, 'users-login' ) ) {
			delete_user_meta( $user->ID, 'secupress_passwordless_code' );
			wp_safe_redirect( secupress_passwordless_get_form_url( $token ) );
			die();
		}
		wp_safe_redirect( secupress_passwordless_get_form_url( $token ) );
		die();
	}

	secupress_passwordless_signon( $user, $token );
}

/**
 * Reject every code typed for an identifier that has no account.
 *
 * @author Julio Potier
 * @since 2.7.2
 *
 * @param (array)  $state
 * @param (string) $token
 */
function secupress_passwordless_handle_unknown_code_post( $state, $token ) {
	if ( ! empty( $state['locked'] ) ) {
		return;
	}

	$nonce = '';
	if ( isset( $_POST['_wpnonce'] ) && is_string( $_POST['_wpnonce'] ) ) {
		$nonce = wp_unslash( $_POST['_wpnonce'] );
	}
	if ( ! wp_verify_nonce( $nonce, 'secupress_passwordless_code_' . $token ) ) {
		wp_safe_redirect( secupress_passwordless_get_form_url( $token ) );
		die();
	}

	$bag  = secupress_passwordless_unknown_get_bag();
	$hash = $state['hash'];
	if ( empty( $bag[ $hash ] ) || ! is_array( $bag[ $hash ] ) ) {
		secupress_passwordless_clear_form_cookie();
		wp_safe_redirect( wp_login_url() );
		die();
	}
	$stored = secupress_passwordless_sanitize_token( (string) $bag[ $hash ]['token'] );
	if ( ! $stored || strlen( $stored ) !== strlen( $token ) || ! hash_equals( $stored, $token ) ) {
		secupress_passwordless_clear_form_cookie();
		wp_safe_redirect( wp_login_url() );
		die();
	}

	$attempts                       = (int) $bag[ $hash ]['attempts'] + 1;
	$bag[ $hash ]['attempts']       = $attempts;
	secupress_passwordless_unknown_set_bag( $bag );
	secupress_passwordless_flag_invalid_code();
	wp_safe_redirect( secupress_passwordless_get_form_url( $token ) );
	die();
}

/**
 * Remember a rejected magic code until the next screen is shown.
 *
 * @author Julio Potier
 * @since 2.7.2
 */
function secupress_passwordless_flag_invalid_code() {
	if ( headers_sent() ) {
		return;
	}

	$name    = 'secupress_pl_code_err';
	$options = secupress_passwordless_form_cookie_options( time() + MINUTE_IN_SECONDS );
	setcookie( $name, '1', $options );
	if ( SITECOOKIEPATH !== COOKIEPATH ) {
		$options['path'] = SITECOOKIEPATH ? SITECOOKIEPATH : '/';
		setcookie( $name, '1', $options );
	}
	$_COOKIE[ $name ] = '1';
}

/**
 * Read and forget the rejected-code flag.
 *
 * @author Julio Potier
 * @since 2.7.2
 *
 * @return (bool)
 */
function secupress_passwordless_consume_invalid_code_flag() {
	$name = 'secupress_pl_code_err';
	$flag = ! empty( $_COOKIE[ $name ] );

	if ( $flag && ! headers_sent() ) {
		$options = secupress_passwordless_form_cookie_options( time() - YEAR_IN_SECONDS );
		setcookie( $name, '', $options );
		if ( SITECOOKIEPATH !== COOKIEPATH ) {
			$options['path'] = SITECOOKIEPATH ? SITECOOKIEPATH : '/';
			setcookie( $name, '', $options );
		}
		unset( $_COOKIE[ $name ] );
	}

	return $flag;
}

/**
 * Render the magic-code screen, or the wait screen after too many attempts.
 *
 * @author Julio Potier
 * @since 2.7.2 The token, error and pending query arguments leave the address bar once the screen is shown.
 *
 * @param (array)  $state
 * @param (string) $token
 */
function secupress_passwordless_render_code_screen( $state, $token ) {
	secupress_passwordless_set_form_cookie( $token, (int) $state['timeout'] );

	$remaining = max( 0, (int) $state['remaining'] );
	$locked    = ! empty( $state['locked'] );
	$wp_error  = new WP_Error();

	if ( secupress_passwordless_consume_invalid_code_flag() ) {
		$wp_error->add( 'invalid_code', __( '<strong>Error</strong>: This code is incorrect.', 'secupress' ) );
	}

	if ( $locked ) {
		$message = '<p class="message">' . esc_html__( 'Please wait before requesting a new code.', 'secupress' ) . '</p>';
	} elseif ( isset( $_GET['pending'] ) && '1' === $_GET['pending'] ) {
		$message = '<p class="message">' . esc_html__( 'A code has already been sent. You can request a new one when the countdown ends.', 'secupress' ) . '</p>';
	} else {
		$message = '<p class="message">' . esc_html__( 'Enter the code sent to your email address.', 'secupress' ) . '</p>';
	}

	add_action( 'login_head', 'secupress_passwordless_code_screen_assets' );
	login_header( __( 'Log In', 'secupress' ), $message, $wp_error );

	echo '<form name="secupress-passwordless-code" id="secupress-passwordless-code" action="' . esc_url( secupress_passwordless_get_form_url( $token ) ) . '" method="post">';
	$countdown = '<span id="secupress-passwordless-countdown" class="secupress-passwordless-remaining" data-remaining="' . esc_attr( $remaining ) . '" data-login-url="' . esc_url( wp_login_url() ) . '">' . esc_html( secupress_passwordless_format_remaining( $remaining ) ) . '</span>';

	if ( ! $locked ) {
		wp_nonce_field( 'secupress_passwordless_code_' . $token );
		echo '<p class="secupress-passwordless-code-wrap">';
		echo '<label for="secupress_passwordless_code">' . esc_html__( 'Magic Code', 'secupress' ) . '</label>';
		echo '<input type="text" name="secupress_passwordless_code" id="secupress_passwordless_code" class="input secupress-passwordless-code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" size="20" pattern="[0-9]{6}" required="required" autofocus="autofocus" />';
		echo $countdown;
		echo '</p>';
		echo '<p class="submit"><input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="' . esc_attr__( 'Log In', 'secupress' ) . '" /></p>';
	} else {
		echo '<p class="secupress-passwordless-code-wrap">' . $countdown . '</p>';
	}
	echo '</form>';

	login_footer();
	die();
}

/**
 * Styles and countdown for the magic-code screen.
 *
 * @author Julio Potier
 * @since 2.7.2
 */
function secupress_passwordless_code_screen_assets() {
	$visible_url = remove_query_arg( [ 'token', 'pending' ] );
	?>
	<link id="secupress-passwordless-screen" href="<?php echo esc_url( $visible_url ); ?>" />
	<script>
	if ( window.history.replaceState ) {
		var passwordlessScreen = document.getElementById('secupress-passwordless-screen');
		if (passwordlessScreen) {
			window.history.replaceState( null, null, passwordlessScreen.href + window.location.hash );
		}
	}
	</script>
	<style>
	.secupress-passwordless-code{font-size:2em;text-align:center;font-weight:bold;letter-spacing:0.2em;border-radius:8px;color:#666;}
	.secupress-passwordless-code-wrap{margin-bottom:0;}
	.secupress-passwordless-remaining{display:block;margin:4px 0 0;text-align:left;font-variant-numeric:tabular-nums;font-weight:600;}
	</style>
	<script>
	document.addEventListener('DOMContentLoaded', function () {
		var countdown = document.getElementById('secupress-passwordless-countdown');
		if (countdown) {
			var remaining = parseInt(countdown.getAttribute('data-remaining'), 10);
			var loginUrl = countdown.getAttribute('data-login-url');
			if (!isNaN(remaining) && loginUrl) {
				var endsAt = Date.now() + (remaining * 1000);
				var timer = window.setInterval(function () {
					var left = Math.round((endsAt - Date.now()) / 1000);
					if (left <= 0) {
						window.clearInterval(timer);
						window.location.href = loginUrl;
						return;
					}
					var minutes = Math.floor(left / 60);
					var seconds = left % 60;
					var minutesText = minutes < 10 ? '0' + minutes : String(minutes);
					var secondsText = seconds < 10 ? '0' + seconds : String(seconds);
					countdown.textContent = minutesText + ':' + secondsText;
				}, 1000);
			}
		}
		var codeInput = document.getElementById('secupress_passwordless_code');
		if (codeInput && codeInput.form) {
			var codeForm = codeInput.form;
			var codeSent = false;
			var sendCodeOnce = function () {
				if (codeSent) {
					return;
				}
				codeSent = true;
				var submitButton = codeForm.querySelector('[type="submit"]');
				if (submitButton) {
					submitButton.disabled = true;
				}
				codeForm.submit();
			};
			codeForm.addEventListener('submit', function (event) {
				if (codeSent) {
					event.preventDefault();
					return;
				}
				codeSent = true;
			});
			codeInput.addEventListener('input', function () {
				codeInput.value = codeInput.value.replace(/\D/g, '').slice(0, 6);
				if (6 === codeInput.value.length) {
					sendCodeOnce();
				}
			});
		}
	});
	</script>
	<?php
}

/**
 * Give a PasswordLess account a random password when its hash would mark it as a fake user.
 *
 * @author Julio Potier
 * @since 2.7.2
 *
 * @param (WP_User) $user
 */
function secupress_passwordless_replace_unusable_password( $user ) {
	if ( ! secupress_is_submodule_active( 'users-login', 'force-strong-encryption' ) || ! secupress_is_affected_role( 'users-login', 'double-auth', $user ) ) {
		return;
	}

	$user_id = (int) $user->ID;
	$prefix  = secupress_get_encryption_prefix( secupress_get_best_encryption_system() );
	$hash_ok = str_starts_with( (string) $user->user_pass, $prefix );
	$suffix_required = (bool) secupress_get_module_option( 'double-auth_prevent-hash-reuse', 0, 'users-login' );
	$suffix_ok       = ! $suffix_required || get_user_meta( $user_id, 'secupress-blind-password', true );
	if ( $hash_ok && $suffix_ok ) {
		return;
	}

	wp_set_password( wp_generate_password( 64, true, true ), $user_id );
	clean_user_cache( $user_id );
}

/**
 * Log a user in after a correct magic code and delete the attempt metas.
 *
 * @author Julio Potier
 * @since 2.7.2
 *
 * @param (WP_User) $user
 * @param (string)  $token
 */
function secupress_passwordless_signon( $user, $token ) {
	global $wpdb;

	$user_id               = (int) $user->ID;
	$requested_redirect_to = (string) get_user_meta( $user_id, 'secupress_passwordless_redirect', true );
	$rememberme            = (bool) get_user_meta( $user_id, 'secupress_passwordless_rememberme', true );

	$claimed = $wpdb->query(
		$wpdb->prepare(
			"DELETE FROM {$wpdb->usermeta} WHERE user_id = %d AND meta_key = %s AND meta_value = %s",
			$user_id,
			'secupress_passwordless_token',
			$token
		)
	);
	if ( ! $claimed ) {
		secupress_passwordless_clear_form_cookie();
		wp_safe_redirect( wp_login_url() );
		die();
	}

	secupress_passwordless_replace_unusable_password( $user );

	if ( secupress_is_submodule_active( 'users-login', 'user-creation-protection' ) ) {
		if ( secupress_is_fake_user( $user_id, true ) ) {
			if ( has_action( 'secupress.plugin.passwordless.autologin_error' ) ) {
				_deprecated_hook( 'secupress.plugin.passwordless.autologin_error', '2.2.6', 'secupress.plugins.passwordless.autologin_error' );
			}
			do_action( 'secupress.plugin.passwordless.autologin_error', $user_id, $token, 'fake user' );
			do_action( 'secupress.plugins.passwordless.autologin_error', $user_id, $token, 'fake user' );
			secupress_kill_fake_user( $user_id );
		}
		if ( in_array( $user_id, secupress_get_pending_user_ids() ) ) {
			if ( has_action( 'secupress.plugin.passwordless.autologin_error' ) ) {
				_deprecated_hook( 'secupress.plugin.passwordless.autologin_error', '2.2.6', 'secupress.plugins.passwordless.autologin_error' );
			}
			do_action( 'secupress.plugin.passwordless.autologin_error', $user_id, $token, 'pending user' );
			do_action( 'secupress.plugins.passwordless.autologin_error', $user_id, $token, 'pending user' );
			secupress_passwordless_delete_login_metas( $user_id );
			secupress_passwordless_clear_form_cookie();
			wp_safe_redirect( wp_login_url() );
			die();
		}
	}

	secupress_passwordless_delete_login_metas( $user_id );
	wp_cache_delete( $user_id, 'user_meta' );

	if ( has_action( 'secupress.plugin.passwordless.autologin_success' ) ) {
		_deprecated_hook( 'secupress.plugin.passwordless.autologin_success', '2.2.6', 'secupress.plugins.passwordless.autologin_success' );
	}
	do_action( 'secupress.plugin.passwordless.autologin_success', $user, $token );
	/**
	 * Triggers an action when an autologin action from the module is a success.
	 *
	 * @since 1.0
	 *
	 * @param (WP_User) $user  The user.
	 * @param (string)  $token The security token.
	 */
	do_action( 'secupress.plugins.passwordless.autologin_success', $user, $token );

	secupress_passwordless_finish_login( $user, $requested_redirect_to, $rememberme );
}

/**
 * Set the auth cookie and send the user to their redirect target.
 *
 * @author Julio Potier
 * @since 2.7.2
 *
 * @param (WP_User) $user
 * @param (string)  $requested_redirect_to
 * @param (bool)    $rememberme
 */
function secupress_passwordless_finish_login( $user, $requested_redirect_to, $rememberme ) {
	$user_id       = (int) $user->ID;
	$secure_cookie = secupress_server_is_ssl();
	$secure_args   = [
		'user_login'    => $user->user_login,
		'user_password' => time(),
	];

	/** This filter is documented in wp-includes/user.php. */
	$secure_cookie = apply_filters( 'secure_signon_cookie', $secure_cookie, $secure_args );

	secupress_passwordless_clear_form_cookie();
	wp_set_auth_cookie( $user_id, $rememberme, $secure_cookie );

	if ( $requested_redirect_to ) {
		$redirect_to = $requested_redirect_to;
		if ( $secure_cookie && false !== strpos( $redirect_to, 'wp-admin' ) ) {
			$redirect_to = preg_replace( '|^http://|', 'https://', $redirect_to );
		}
	} else {
		$redirect_to = admin_url( 'index.php' );
	}

	if ( $redirect_to === admin_url() ) {
		$redirect_to = admin_url( 'index.php' );
	}

	/** This filter is documented in wp-login.php. */
	$redirect_to = apply_filters( 'login_redirect', $redirect_to, $requested_redirect_to, $user );

	wp_safe_redirect( esc_url_raw( $redirect_to ) );
	die();
}

add_action( 'admin_post_passwordless_autologin',        'secupress_passwordless_autologin' );
add_action( 'admin_post_nopriv_passwordless_autologin', 'secupress_passwordless_autologin' );
/**
 * Automatically log-in a user with the correct token.
 *
 * @since 1.0
 * @author Julio Potier
 */
function secupress_passwordless_autologin() {
	$user_id            = 0;
	$fallback_error_msg = sprintf( __( 'This link is not valid for this user, please try to %slog-in again%s.', 'secupress' ), '<a href="' . esc_url( wp_login_url( '', true ) ) . '">', '</a>' );

	if ( empty( $_GET['token'] ) ) {
		$token = '';

		if ( has_action( 'secupress.plugin.passwordless.autologin_error' ) ) {
			_deprecated_hook( 'secupress.plugin.passwordless.autologin_error', '2.2.6', 'secupress.plugins.passwordless.autologin_error' );
		}
		do_action( 'secupress.plugin.passwordless.autologin_error', $user_id, $token, 'no token' );
		/**
		 * Triggers an action when an autologin action from the module has failed.
		 *
		 * @since 1.0
		 *
		 * @param (int)    $user_id    The user ID.
		 * @param (string) $token      The security token.
		 * @param (string) $error_code The error code.
		 */
		do_action( 'secupress.plugins.passwordless.autologin_error', $user_id, $token, 'no token' );

		secupress_die( $fallback_error_msg, '', array( 'force_die' => true ) );
	}

	// Get the user with the given token.
	$token   = $_GET['token'];
	// Prevent plugins to filter the users (like "Advanced Access Manager" does …)
	remove_all_actions( 'pre_get_users' );
	// Get the only user with that token
	$user_id = get_users( array(
		'meta_key'   => 'secupress_passwordless_token',
		'meta_value' => $token,
		'fields'     => 'ID',
		'number'     => 2, // 2, not 1!
	) );
	$user_id = count( $user_id ) === 1 ? (int) reset( $user_id ) : 0;
	$user    = $user_id ? get_user_by( 'id', $user_id ) : false;

	if ( ! secupress_is_user( $user ) ) {
		if ( has_action( 'secupress.plugin.passwordless.autologin_error' ) ) {
			_deprecated_hook( 'secupress.plugin.passwordless.autologin_error', '2.2.6', 'secupress.plugins.passwordless.autologin_error' );
		}
		do_action( 'secupress.plugin.passwordless.autologin_error', $user_id, $token, 'no user' );
		/** This action is documented in inc/modules/users-login/plugins/passwordless.php. */
		do_action( 'secupress.plugins.passwordless.autologin_error', $user_id, $token, 'no user' );

		secupress_die( $fallback_error_msg, '', array( 'force_die' => true ) );
	}

	$code_hash = (string) get_user_meta( $user_id, 'secupress_passwordless_code', true );
	$attempts  = (int) get_user_meta( $user_id, 'secupress_passwordless_attempts', true );
	$timeout   = (int) get_user_meta( $user_id, 'secupress_passwordless_timeout', true );
	if ( $code_hash || ( $attempts >= (int) secupress_get_module_option( 'login-protection_number_attempts', 5, 'users-login' ) && $timeout > time() ) ) {
		$form_token = secupress_passwordless_sanitize_token( is_string( $token ) ? $token : '' );
		if ( $form_token ) {
			wp_safe_redirect( secupress_passwordless_get_form_url( $form_token ) );
			die();
		}
		wp_safe_redirect( wp_login_url() );
		die();
	}

	// Test token validity period.
	$requested_redirect_to = ! empty( $_GET['redirect_to'] ) ? rawurldecode( $_GET['redirect_to'] ) : '';
	$time                  = get_user_meta( $user_id, 'secupress_passwordless_timeout', true );
	$rememberme            = get_user_meta( $user_id, 'secupress_passwordless_rememberme', true );

	delete_user_meta( $user_id, 'secupress_passwordless_token' );
	delete_user_meta( $user_id, 'secupress_passwordless_code' );
	delete_user_meta( $user_id, 'secupress_passwordless_rememberme' );
	delete_user_meta( $user_id, 'secupress_passwordless_timeout' );
	delete_user_meta( $user_id, 'secupress_passwordless_redirect' );
	delete_user_meta( $user_id, 'secupress_passwordless_attempts' );

	if ( $time < time() ) {
		// The 10 minutes limit has passed.
		if ( has_action( 'secupress.plugin.passwordless.autologin_error' ) ) {
			_deprecated_hook( 'secupress.plugin.passwordless.autologin_error', '2.2.6', 'secupress.plugins.passwordless.autologin_error' );
		}
		do_action( 'secupress.plugin.passwordless.autologin_error', $user_id, $token, 'expired token' );
		/** This action is documented in inc/modules/users-login/plugins/passwordless.php. */
		do_action( 'secupress.plugins.passwordless.autologin_error', $user_id, $token, 'expired token' );

		$message = sprintf( __( 'This link is now expired, please try to <a href="%s">log-in again</a>.', 'secupress' ), esc_url( wp_login_url( $requested_redirect_to, true ) ) );
		secupress_die( $message, '', array( 'force_die' => true ) );
	}

	secupress_passwordless_replace_unusable_password( $user );

	if ( secupress_is_submodule_active( 'users-login', 'user-creation-protection' ) ) {
		if ( secupress_is_fake_user( $user_id, true ) ) {
			if ( has_action( 'secupress.plugin.passwordless.autologin_error' ) ) {
				_deprecated_hook( 'secupress.plugin.passwordless.autologin_error', '2.2.6', 'secupress.plugins.passwordless.autologin_error' );
			}
			do_action( 'secupress.plugin.passwordless.autologin_error', $user_id, $token, 'fake user' );
			do_action( 'secupress.plugins.passwordless.autologin_error', $user_id, $token, 'fake user' );
			secupress_kill_fake_user( $user_id );
		}
		if ( in_array( $user_id, secupress_get_pending_user_ids() ) ) {
			if ( has_action( 'secupress.plugin.passwordless.autologin_error' ) ) {
				_deprecated_hook( 'secupress.plugin.passwordless.autologin_error', '2.2.6', 'secupress.plugins.passwordless.autologin_error' );
			}
			do_action( 'secupress.plugin.passwordless.autologin_error', $user_id, $token, 'pending user' );
			do_action( 'secupress.plugins.passwordless.autologin_error', $user_id, $token, 'pending user' );
			secupress_die( $fallback_error_msg, '', array( 'force_die' => true ) );
		}
	}

	$secure_cookie = secupress_server_is_ssl();
	$secure_args   = array(
		'user_login'    => $user->user_login,
		'user_password' => time(),
	);

	/** This filter is documented in wp-includes/user.php. */
	$secure_cookie = apply_filters( 'secure_signon_cookie', $secure_cookie, $secure_args );

	wp_set_auth_cookie( $user_id, (bool) $rememberme, $secure_cookie );

	if ( $requested_redirect_to ) {
		$redirect_to = $requested_redirect_to;
		// Redirect to https if user wants ssl.
		if ( $secure_cookie && false !== strpos( $redirect_to, 'wp-admin' ) ) {
			$redirect_to = preg_replace( '|^http://|', 'https://', $redirect_to );
		}
	} else {
		$redirect_to = admin_url( 'index.php' );
	}

	// Add 'index.php" to prevent infinite loop of login.
	if ( $redirect_to === admin_url() ) {
		$redirect_to = admin_url( 'index.php' );
	}

	/** This filter is documented in wp-login.php. */
	$redirect_to = apply_filters( 'login_redirect', $redirect_to, $requested_redirect_to, $user );

	if ( has_action( 'secupress.plugin.passwordless.autologin_success' ) ) {
		_deprecated_hook( 'secupress.plugin.passwordless.autologin_success', '2.2.6', 'secupress.plugins.passwordless.autologin_success' );
	}
	do_action( 'secupress.plugin.passwordless.autologin_success', $user, $token );
	/**
	 * Triggers an action when an autologin action from the module is a success.
	 *
	 * @since 1.0
	 *
	 * @param (int)    $user    The user
	 * @param (string) $token   The security token.
	 */
	do_action( 'secupress.plugins.passwordless.autologin_success', $user, $token );

	wp_safe_redirect( esc_url_raw( $redirect_to ) );
	die();
}
