<?php
defined( 'ABSPATH' ) or die( 'Something went wrong.' );


/**
 * Catalog of third-party referers that can be allowed to hotlink.
 *
 * @author Julio Potier
 * @since 2.7
 *
 * @return (array)
 */
function secupress_hotlink_get_allowed_referers_catalog() {
	return [
		'google'      => [
			'label' => 'Google',
			'group' => 'search',
			'slug'  => 'google',
		],
		'bing'        => [
			'label' => 'Bing',
			'group' => 'search',
			'slug'  => 'bing',
		],
		'duckduckgo'  => [
			'label' => 'DuckDuckGo',
			'group' => 'search',
			'slug'  => 'duckduckgo',
		],
		'yahoo'       => [
			'label' => 'Yahoo',
			'group' => 'search',
			'slug'  => 'yahoo',
		],
		'qwant'       => [
			'label' => 'Qwant',
			'group' => 'search',
			'slug'  => 'qwant',
		],
		'ecosia'      => [
			'label' => 'Ecosia',
			'group' => 'search',
			'slug'  => 'ecosia',
		],
		'brave'       => [
			'label' => 'Brave',
			'group' => 'search',
			'slug'  => 'brave',
		],
		'yandex'      => [
			'label' => 'Yandex',
			'group' => 'search',
			'slug'  => 'yandex',
		],
		'startpage'   => [
			'label' => 'Startpage',
			'group' => 'search',
			'slug'  => 'startpage',
		],
		'facebook'    => [
			'label' => 'Facebook',
			'group' => 'social',
			'slug'  => 'facebook|fbcdn',
			'hosts' => [ 'fb\.com', 'fb\.me' ],
		],
		'x'           => [
			'label' => 'X (Twitter)',
			'group' => 'social',
			'slug'  => 'twitter',
			'hosts' => [ 'x\.com', 't\.co' ],
		],
		'slack'       => [
			'label' => 'Slack',
			'group' => 'social',
			'slug'  => 'slack',
		],
		'whatsapp'    => [
			'label' => 'WhatsApp',
			'group' => 'social',
			'slug'  => 'whatsapp',
		],
		'linkedin'    => [
			'label' => 'LinkedIn',
			'group' => 'social',
			'slug'  => 'linkedin',
		],
		'discord'     => [
			'label' => 'Discord',
			'group' => 'social',
			'slug'  => 'discord',
		],
	];
}


/**
 * Default allowed referer ids (all of them).
 *
 * @author Julio Potier
 * @since 2.7
 *
 * @return (array)
 */
function secupress_hotlink_get_default_allowed_referers() {
	return array_keys( secupress_hotlink_get_allowed_referers_catalog() );
}


/**
 * Selected allowed referer ids.
 *
 * @author Julio Potier
 * @since 2.7
 *
 * @return (array)
 */
function secupress_hotlink_get_selected_allowed_referers() {
	$selected = secupress_get_module_option( 'content-protect_hotlink_allow', null, 'sensitive-data' );
	if ( null === $selected ) {
		return secupress_hotlink_get_default_allowed_referers();
	}

	$catalog = array_keys( secupress_hotlink_get_allowed_referers_catalog() );
	return array_values( array_intersect( (array) $selected, $catalog ) );
}


/**
 * Redirection type: pixel, 403 or image.
 *
 * @author Julio Potier
 * @since 2.7
 *
 * @return (string)
 */
function secupress_hotlink_get_redirection_type() {
	$type    = secupress_get_module_option( 'content-protect_hotlink_redirection', '403', 'sensitive-data' );
	$allowed = [ 'pixel', '403', 'image' ];

	return in_array( $type, $allowed, true ) ? $type : '403';
}


/**
 * URL of the replacement image.
 *
 * @author Julio Potier
 * @since 2.7
 *
 * @return (string)
 */
function secupress_hotlink_get_replacement_image_url() {
	return SECUPRESS_ADMIN_IMAGES_URL . 'hotlinking.png';
}


/**
 * Regex matching selected third-party referers.
 *
 * @author Julio Potier
 * @since 2.7
 *
 * @return (string) Empty when nothing is selected.
 */
function secupress_hotlink_get_allowed_services_regex_pattern() {
	$catalog  = secupress_hotlink_get_allowed_referers_catalog();
	$selected = secupress_hotlink_get_selected_allowed_referers();
	$slugs    = [];
	$hosts    = [];

	foreach ( $selected as $id ) {
		if ( empty( $catalog[ $id ] ) ) {
			continue;
		}
		if ( ! empty( $catalog[ $id ]['slug'] ) ) {
			$slugs[] = $catalog[ $id ]['slug'];
		}
		if ( ! empty( $catalog[ $id ]['hosts'] ) ) {
			$hosts = array_merge( $hosts, $catalog[ $id ]['hosts'] );
		}
	}

	$alts = [];
	if ( $slugs ) {
		$alts[] = '(?:' . implode( '|', $slugs ) . ')\.[a-z]{2,}(?:\.[a-z]{2,})?';
	}
	if ( $hosts ) {
		$alts[] = '(?:' . implode( '|', $hosts ) . ')';
	}
	if ( ! $alts ) {
		return '';
	}

	return '^https?://(?:[a-z0-9-]+\.)*(?:' . implode( '|', $alts ) . ')(?::[0-9]+)?(?:/|$)';
}
