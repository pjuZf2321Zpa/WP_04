<?php
/**
 * Module Name: Anti Hotlink
 * Description: Prevent medias hotlinking.
 * Main Module: sensitive_data
 * Author: SecuPress
 * Version: 1.0
 */

defined( 'SECUPRESS_VERSION' ) or die( 'Something went wrong.' );

/** --------------------------------------------------------------------------------------------- */
/** ACTIVATION / DEACTIVATION =================================================================== */
/** ----------------------------------------------------------------------------------------------*/

add_action( 'secupress.modules.activate_submodule_' . basename( __FILE__, '.php' ), 'secupress_hotlink_activation' );
/**
 * On module activation, maybe write the rules.
 *
 * @since 1.0
 */
function secupress_hotlink_activation() {
	global $is_apache, $is_nginx, $is_iis7;

	// Hotlink protection won't work over http, it needs SSL to (maybe) get the referer.
	if ( ! secupress_is_site_ssl() ) {
		$message  = sprintf( __( '%s:', 'secupress' ), __( 'Anti Hotlink', 'secupress' ) ) . ' ';
		$message .= sprintf( __( 'The anti hotlink can work only over SSL (the URL of your website must start with %s).', 'secupress' ), secupress_code_me( 'https://' ) );

		secupress_add_settings_error( 'general', 'no_ssl', $message, 'error' );

		secupress_deactivate_submodule_silently( $module, $submodule );
		return;
	}

	// Apache.
	if ( $is_apache ) {
		$rules = secupress_hotlink_get_apache_rules();
	}
	// IIS7.
	elseif ( $is_iis7 ) {
		$rules = secupress_hotlink_get_iis7_rules();
	}
	// Nginx.
	elseif ( $is_nginx ) {
		$rules = secupress_hotlink_get_nginx_rules();
	}
	// Not supported.
	else {
		$rules = '';
	}

	secupress_add_module_rules_or_notice( array(
		'rules'  => $rules,
		'marker' => 'hotlink',
		'title'  => __( 'Anti Hotlink', 'secupress' ),
	) );
}


add_action( 'update_option_secupress_sensitive-data_settings', 'secupress_hotlink_rewrite_on_settings_update', 10, 2 );
add_action( 'update_site_option_secupress_sensitive-data_settings', 'secupress_hotlink_rewrite_on_settings_update', 10, 2 );
/**
 * Rewrite hotlink rules when expert settings change.
 *
 * @author Julio Potier
 * @since 2.7
 *
 * @param (mixed) $old_value Previous module settings.
 * @param (mixed) $value     New module settings.
 */
function secupress_hotlink_rewrite_on_settings_update( $old_value, $value ) {
	if ( ! secupress_is_submodule_active( 'sensitive-data', 'hotlink' ) ) {
		return;
	}
	$old_value = is_array( $old_value ) ? $old_value : [];
	$value     = is_array( $value ) ? $value : [];
	$keys      = [ 'content-protect_hotlink_redirection', 'content-protect_hotlink_allow' ];
	foreach ( $keys as $key ) {
		$old = isset( $old_value[ $key ] ) ? $old_value[ $key ] : null;
		$new = isset( $value[ $key ] ) ? $value[ $key ] : null;
		if ( $old !== $new ) {
			secupress_hotlink_activation();
			return;
		}
	}
}


add_action( 'secupress.modules.deactivate_submodule_' . basename( __FILE__, '.php' ), 'secupress_hotlink_deactivate' );
/**
 * On module deactivation, maybe remove rewrite rules from the `.htaccess`/`web.config` file.
 *
 * @since 1.0
 */
function secupress_hotlink_deactivate() {
	secupress_remove_module_rules_or_notice( 'hotlink', __( 'Anti Hotlink', 'secupress' ) );
}


add_filter( 'secupress.pro.plugins.activation.write_rules', 'secupress_hotlink_plugin_activate', 10, 2 );
/**
 * On SecuPress Pro activation, add the rules to the list of the rules to write.
 *
 * @since 1.0
 *
 * @param (array) $rules Other rules to write.
 *
 * @return (array) Rules to write.
 */
function secupress_hotlink_plugin_activate( $rules ) {
	global $is_apache, $is_nginx, $is_iis7;
	$marker = 'hotlink';

	if ( $is_apache ) {
		$rules[ $marker ] = secupress_hotlink_get_apache_rules();
	} elseif ( $is_iis7 ) {
		$rules[ $marker ] = array( 'nodes_string' => secupress_hotlink_get_iis7_rules() );
	} elseif ( $is_nginx ) {
		$rules[ $marker ] = secupress_hotlink_get_nginx_rules();
	}

	return $rules;
}


/** --------------------------------------------------------------------------------------------- */
/** TOOLS ======================================================================================= */
/** ----------------------------------------------------------------------------------------------*/

/**
 * Get a regex pattern matching an authorized referer host (scheme, optional subdomains, optional port).
 *
 * @author Julio Potier
 * @since 2.7
 *
 * @param (string) $host A hostname, without scheme.
 *
 * @return (string)
 */
function secupress_hotlink_get_host_referer_regex_pattern( $host ) {
	$host = preg_replace( '/^www\./i', '', (string) $host );
	$host = preg_quote( $host );

	return '^https?://(?:[a-z0-9-]+\.)*' . $host . '(?::[0-9]+)?(?:/|$)';
}


/**
 * Get a list of autorized referers as regex patterns.
 *
 * @since 2.7 Use host-based patterns with optional subdomains.
 * @since 1.0
 *
 * @return (array) A list of regex patterns.
 */
function secupress_hotlink_get_referer_regex_patterns_list() {
	$refs = apply_filters( 'secupress.plugin.hotlink.additional_autorized_referers', [] );
	if ( has_filter( 'secupress.plugin.hotlink.additional_autorized_referers' ) ) {
		_deprecated_hook( 'secupress.plugin.hotlink.additional_autorized_referers', '2.2.6', 'secupress.plugins.hotlink.additional_autorized_referers' );
	}
	/**
	 * Add autorized referers. Current domain will ba added later.
	 *
	 * @since 1.0
	 *
	 * @param (array) $refs An array of autorized referers.
	 */
	$refs = apply_filters( 'secupress.plugins.hotlink.additional_autorized_referers', $refs );
	$refs = array_filter( (array) $refs );

	foreach ( $refs as $i => $ref ) {
		$host = wp_parse_url( $ref, PHP_URL_HOST );
		if ( ! $host && false === strpos( $ref, '://' ) ) {
			$host = wp_parse_url( 'https://' . ltrim( $ref, '/' ), PHP_URL_HOST );
		}
		if ( $host ) {
			$refs[ $i ] = secupress_hotlink_get_host_referer_regex_pattern( $host );
		} else {
			$refs[ $i ] = preg_quote( rtrim( $ref, '/' ) );
		}
	}

	$host = wp_parse_url( home_url(), PHP_URL_HOST );
	if ( $host ) {
		array_unshift( $refs, secupress_hotlink_get_host_referer_regex_pattern( $host ) );
	}

	return $refs;
}


/**
 * Get a list of protected file extensions as a regex pattern.
 *
 * @since 2.7 Add webp, avif, svg. Use a non-capturing group.
 * @since 1.0
 *
 * @return (string) A regex pattern.
 */
function secupress_hotlink_get_protected_extensions_regex_pattern() {
	$ext = apply_filters( 'secupress.plugin.hotlink.protected_extensions', [ 'jpg', 'jpeg', 'png', 'gif', 'webp', 'avif', 'svg', 'heic', 'heif', 'bmp', 'ico' ] );
	if ( has_filter( 'secupress.plugin.hotlink.protected_extensions' ) ) {
		_deprecated_hook( 'secupress.plugin.hotlink.protected_extensions', '2.2.6', 'secupress.plugins.hotlink.protected_extensions' );
	}
	/**
	 * Filter the list of protected file extensions.
	 *
	 * @since 1.0
	 *
	 * @param (array) $ext An array of file extensions.
	 */
	$ext = apply_filters( 'secupress.plugins.hotlink.protected_extensions', $ext );
	$ext = array_filter( array_map( 'sanitize_key', (array) $ext ) );
	$ext = array_map( 'preg_quote', $ext );

	return '\.(?:' . implode( '|', $ext ) . ')$';
}


/**
 * Get the URL of the image replacement.
 *
 * @since 2.7 Use the selected redirection type.
 * @since 1.0
 *
 * @return (string)
 */
function secupress_hotlink_get_replacement_url() {
	$url = 'image' === secupress_hotlink_get_redirection_type() ? secupress_hotlink_get_replacement_image_url() : 'data:image/gif;base64,R0lGODdhAQABAPAAAP///wAAACwAAAAAAQABAEACAkQBADs=';
	$url = apply_filters( 'secupress.plugin.hotlink.replacement_url', $url );
	if ( has_filter( 'secupress.plugin.hotlink.replacement_url' ) ) {
		_deprecated_hook( 'secupress.plugin.hotlink.replacement_url', '2.2.6', 'secupress.plugins.hotlink.replacement_url' );
	}
	/**
	 * Filter the URL of the image used as replacement when a media is hotlinked.
	 *
	 * @since 1.0
	 *
	 * @param (string) $url The replacement image URL.
	 */
	return apply_filters( 'secupress.plugins.hotlink.replacement_url', $url );
}


/**
 * Get the URI of the image replacement as a regex pattern. The aim is to use it in `RewriteCond`.
 *
 * @since 1.0
 *
 * @return (string|bool) A regex pattern that matches the image replacement URI. False if the image is not delivered from the same domain.
 */
function secupress_hotlink_get_replacement_regex_pattern() {
	$url = secupress_hotlink_get_replacement_url();

	if ( false === strpos( $url, $_SERVER['HTTP_HOST'] ) ) {
		return false;
	}

	$url = explode( $_SERVER['HTTP_HOST'], $url );
	$url = end( $url );
	$url = preg_quote( $url );

	return $url;
}


/** --------------------------------------------------------------------------------------------- */
/** RULES ======================================================================================= */
/** ----------------------------------------------------------------------------------------------*/

/**
 * Get the rewrite rules that should be added into the `.htaccess` file (without the SecuPress marker).
 * Will output something like:
 * <IfModule mod_rewrite.c>
 *     RewriteEngine On
 *     RewriteCond %{REQUEST_FILENAME} -f
 *     RewriteCond %{REQUEST_FILENAME} \.(?:jpg|jpeg|png|gif|webp|avif|svg)$ [NC]
 *     RewriteCond %{HTTP_REFERER} !^$
 *     RewriteCond %{HTTP_REFERER} !^https?://(?:[a-z0-9-]+\.)*example\.com(?::[0-9]+)?(?:/|$) [NC]
 *     RewriteCond %{HTTP_REFERER} !^https?://(?:[a-z0-9-]+\.)*(?:google|bing|duckduckgo|yahoo|qwant|ecosia)\.[a-z]{2,}(?:\.[a-z]{2,})?(?:/.*)?$ [NC]
 *     RewriteRule \.(?:jpg|jpeg|png|gif|webp|avif|svg)$ "data:image/gif;base64,..." [NC,R,L]
 * </IfModule>
 *
 * @since 2.7
 * @since 1.0
 *
 * @return (string) The rewrite rules, ready to be insterted into the `.htaccess` file.
 */
function secupress_hotlink_get_apache_rules() {
	$refs     = secupress_hotlink_get_referer_regex_patterns_list();
	$ext      = secupress_hotlink_get_protected_extensions_regex_pattern();
	$repl     = secupress_hotlink_get_replacement_url();
	$type     = secupress_hotlink_get_redirection_type();
	$uri_cond = 'image' === $type ? secupress_hotlink_get_replacement_regex_pattern() : false;
	$search   = secupress_hotlink_get_allowed_services_regex_pattern();

	$out  = "<IfModule mod_rewrite.c>\n";
	$out .= "    RewriteEngine On\n";
	$out .= "    RewriteCond %{REQUEST_FILENAME} -f\n";
	$out .= "    RewriteCond %{REQUEST_FILENAME} $ext [NC]\n";
	$out .= "    RewriteCond %{HTTP_REFERER} !^$\n";
	foreach ( $refs as $ref ) {
		$out .= "    RewriteCond %{HTTP_REFERER} !$ref [NC]\n";
	}
	if ( $search ) {
		$out .= "    RewriteCond %{HTTP_REFERER} !$search [NC]\n";
	}
	if ( $uri_cond ) {
		$out .= "    RewriteCond %{REQUEST_URI} !^$uri_cond$ [NC]\n";
	}
	if ( '403' === $type ) {
		$out .= '    RewriteRule ' . $ext . " - [F,NC,L]\n";
	} else {
		$out .= '    RewriteRule ' . $ext . ' "' . $repl . "\" [NC,R,L]\n";
	}
	$out .= '</IfModule>';

	return $out;
}


/**
 * Get the rewrite rules that should be added into the `web.config` file.
 * Will output something like:
 * <rule name="SecuPress hotlink">
 *     <match url="\.(?:jpg|jpeg|png|gif|webp|avif|svg)$" ignoreCase="true"/>
 *     <conditions>
 *         <add input="{REQUEST_FILENAME}" matchType="isFile"/>
 *         <add input="{REQUEST_FILENAME}" pattern="\.(?:jpg|jpeg|png|gif|webp|avif|svg)$" ignoreCase="true"/>
 *         <add input="{HTTP_REFERER}" pattern="^$" negate="true"/>
 *         <add input="{HTTP_REFERER}" pattern="^https?://(?:[a-z0-9-]+\.)*domain\.com(?::[0-9]+)?(?:/|$)" negate="true" ignoreCase="true"/>
 *     </conditions>
 *     <action type="Rewrite" url="data:image/gif;base64,..." />
 * </rule>
 *
 * @since 2.7
 * @since 1.0
 * @see https://www.iis.net/learn/extensions/url-rewrite-module/url-rewrite-module-configuration-reference
 * @see http://www.it-notebook.org/iis/article/prevent_hotlinking_url_rewrite.htm
 *
 * @return (string) The rewrite rules, ready to be insterted into the `web.config` file.
 */
function secupress_hotlink_get_iis7_rules() {
	$refs     = secupress_hotlink_get_referer_regex_patterns_list();
	$ext      = secupress_hotlink_get_protected_extensions_regex_pattern();
	$repl     = secupress_hotlink_get_replacement_url();
	$type     = secupress_hotlink_get_redirection_type();
	$uri_cond = 'image' === $type ? secupress_hotlink_get_replacement_regex_pattern() : false;
	$search   = secupress_hotlink_get_allowed_services_regex_pattern();
	$marker   = 'hotlink';
	$spaces   = str_repeat( ' ', 10 );

	$out  = "<rule name=\"SecuPress $marker\">\n";
	$out .= "$spaces  <match url=\"$ext\" ignoreCase=\"true\"/>\n";
	$out .= "$spaces  <conditions>\n";
	$out .= "$spaces    <add input=\"{REQUEST_FILENAME}\" matchType=\"isFile\"/>\n";
	$out .= "$spaces    <add input=\"{REQUEST_FILENAME}\" pattern=\"$ext\" ignoreCase=\"true\"/>\n";
	$out .= "$spaces    <add input=\"{HTTP_REFERER}\" pattern=\"^$\" negate=\"true\"/>\n";
	foreach ( $refs as $ref ) {
		$out .= "$spaces    <add input=\"{HTTP_REFERER}\" pattern=\"$ref\" negate=\"true\" ignoreCase=\"true\"/>\n";
	}
	if ( $search ) {
		$out .= "$spaces    <add input=\"{HTTP_REFERER}\" pattern=\"$search\" negate=\"true\" ignoreCase=\"true\"/>\n";
	}
	if ( $uri_cond ) {
		$out .= "$spaces    <add input=\"{REQUEST_URI}\" pattern=\"^$uri_cond$\" negate=\"true\" ignoreCase=\"true\"/>\n";
	}
	$out .= "$spaces  </conditions>\n";
	if ( '403' === $type ) {
		$out .= "$spaces  <action type=\"CustomResponse\" statusCode=\"403\" statusReason=\"Forbidden\" statusDescription=\"Forbidden\" />\n";
	} else {
		$out .= "$spaces  <action type=\"Rewrite\" url=\"$repl\" />\n";
	}
	$out .= "$spaces</rule>";

	return $out;
}


/**
 * Get the rewrite rules that should be added into the `nginx.conf` file (without the SecuPress marker).
 * Will output something like:
 * if (-f $request_filename) {
 *     set $cond_hotlink 1$cond_hotlink;
 * }
 * if ($request_filename ~* "\.(jpg|jpeg|png|gif)$") {
 *     set $cond_hotlink 2$cond_hotlink;
 * }
 * if ($http_referer !~ "^$") {
 *     set $cond_hotlink 3$cond_hotlink;
 * }
 * if ($http_referer !~* "^https?:\/\/www\.domain\.com(?:\/?|\/.+)$") {
 *     set $cond_hotlink 4$cond_hotlink;
 * }
 * if ($uri !~* "^\/wp-content\/plugins\/secupress-free\/assets\/front\/images\/hotlink\.png$") {
 *     set $cond_hotlink 5$cond_hotlink;
 * }
 * if ($cond_hotlink = "54321") {
 *     rewrite \.(jpg|jpeg|png|gif)$ http://www.domain.com/wp-content/plugins/secupress-free/assets/front/images/hotlink.png redirect;
 * }
 *
 * @since 2.7
 * @since 1.0
 *
 * @return (string) The rewrite rules, ready to be insterted into the `nginx.conf` file.
 */
function secupress_hotlink_get_nginx_rules() {
	$refs     = secupress_hotlink_get_referer_regex_patterns_list();
	$ext      = secupress_hotlink_get_protected_extensions_regex_pattern();
	$repl     = secupress_hotlink_get_replacement_url();
	$type     = secupress_hotlink_get_redirection_type();
	$uri_cond = 'image' === $type ? secupress_hotlink_get_replacement_regex_pattern() : false;
	$search   = secupress_hotlink_get_allowed_services_regex_pattern();
	$base     = secupress_get_rewrite_bases();
	$base     = $base['base'];
	$marker   = 'hotlink';
	$i        = 3;
	$rule_val = '321';

	$out  = "location $base {\n";
	$out .= "    # BEGIN SecuPress $marker\n";
	$out .= '    if (-f $request_filename) {' . "\n";
	$out .= '        set $cond_hotlink 1$cond_hotlink;' . "\n";
	$out .= "    }\n";
	$out .= '    if ($request_filename ~* "' . $ext . '") {' . "\n";
	$out .= '        set $cond_hotlink 2$cond_hotlink;' . "\n";
	$out .= "    }\n";
	$out .= '    if ($http_referer !~ "^$") {' . "\n";
	$out .= '        set $cond_hotlink 3$cond_hotlink;' . "\n";
	$out .= "    }\n";
	foreach ( $refs as $ref ) {
		++$i;
		$rule_val = $i . $rule_val;
		$out .= '    if ($http_referer !~* "' . $ref . '") {' . "\n";
		$out .= '        set $cond_hotlink ' . $i . '$cond_hotlink;' . "\n";
		$out .= "    }\n";
	}
	if ( $search ) {
		++$i;
		$rule_val = $i . $rule_val;
		$out .= '    if ($http_referer !~* "' . $search . '") {' . "\n";
		$out .= '        set $cond_hotlink ' . $i . '$cond_hotlink;' . "\n";
		$out .= "    }\n";
	}
	if ( $uri_cond ) {
		++$i;
		$rule_val = $i . $rule_val;
		$out .= '    if ($uri !~* "' . $uri_cond . '") {' . "\n";
		$out .= '        set $cond_hotlink ' . $i . '$cond_hotlink;' . "\n";
		$out .= "    }\n";
	}
	$out .= '    if ($cond_hotlink = "' . $rule_val . '") {' . "\n";
	if ( '403' === $type ) {
		$out .= "        return 403;\n";
	} else {
		$out .= "        rewrite ^ $repl redirect;\n";
	}
	$out .= "    }\n";
	$out .= "    # END SecuPress\n";
	$out .= '}';

	return $out;
}
