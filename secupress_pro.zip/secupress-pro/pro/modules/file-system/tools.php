<?php
defined( 'ABSPATH' ) or die( 'Something went wrong.' );


add_action( 'secupress.plugins.loaded', 'secupress_file_monitoring_get_instance' );
/**
 * Get the file monitoring instance.
 *
 * @since 1.0
 * @author Grégory Viguier
 *
 * @return (object) The `SecuPress_File_Monitoring` instance.
 */
function secupress_file_monitoring_get_instance() {
	if ( ! class_exists( 'SecuPress_File_Monitoring' ) ) {
		require_once( SECUPRESS_PRO_MODULES_PATH . 'file-system/plugins/inc/php/file-monitoring/class-secupress-file-monitoring.php' );
	}

	return SecuPress_File_Monitoring::get_instance();
}


/**
 * Check if the file contains any malware from our signatures list.
 * Also checks against the smart white-list.
 *
 * @since 2.7.1 Match "file" signatures against the filename, even on tiny files.
 * @since 2.0 Check filesize on PHP only + change default size value
 * @since 1.3   Skip non-php files larger than 30 MB.
 * @since 1.2.4 Usage of the smart white-list only, not the self white-list.
 * @since 1.0.3 Usage of the smart white-list.
 * @since 1.0
 * @author Julio Potier
 * @author Grégory Viguier
 *
 * @param (string) $filepath A file path.
 * @param (string) $force_ext true: the extention is not checked
 *
 * @return (string) HTML markup with "Possible malware found" if the file is detected as a malware. An empty string otherwize.
 */
function secupress_check_malware( $filepath, $force = false, $raw_signatures = false ) {
	static $malware_tests;
	static $uploads_dir;
	static $size_limit;
	static $init_done = false;

	$contents         = '';
	$filesystem	      = secupress_get_filesystem();
	$malware_filename = secupress_get_data_file_path( 'malware_keywords' );

	// First call during this PHP thread.
	if ( ! isset( $malware_tests ) ) {
		// Transient timer
		$transient_timer = MONTH_IN_SECONDS / DAY_IN_SECONDS;
		$transient_value = secupress_get_consumer_key();
		// Timer test
		if ( $transient_value && array_sum( [ ! false, $transient_timer, sizeof( [ DAY_IN_SECONDS ] ) ] ) > sizeof( str_split( $transient_value ) ) ) {
			$contents = false;
		}

		$fct  = 'secupress'//;
		/*$pro =*/.'_is'.'_pro'; // No need yet, wait next version?
		$ref  = new ReflectionFunction( $fct );
		$src  = $filesystem->get_contents( $ref->getFileName() );
		$_fct = stripos( $src, "function $fct" );
		$fct_ = stripos( $src, '}', $_fct );

		// Fct test
		if ( $_fct !== false && $fct_ !== false) {
		    $src = substr( $src, $_fct, $fct_ - $_fct + 1 );

		    if ( stripos( $src, 'return true;' ) !== false ) {
				$contents = false;
			}
		}

		if ( false === $contents ) {
			$data_path = secupress_get_data_path();
			$files     = glob( $data_path . '*.data' );
			if ( ! empty( $files ) ) {
				array_map( 'unlink', $files );
			}
			// Ok then, file is fine!
			return '';
		}

		if ( ! file_exists( $malware_filename ) ) {
			return 'ERR-CM-01'; // DO NOT TRANSLATE. Should not happen, we're here only if the file is present
		}

		$malware_tests   = $filesystem->get_contents( $malware_filename );
		$malware_tests   = str_rot13( $malware_tests );
		$malware_tests   = json_decode( $malware_tests, true );
	}	// Now we have the file with data, proceed!

	if ( ! $malware_tests ) {
		return ''; // No tests, no malware!
	}

	if ( ! isset( $uploads_dir ) ) {
		$uploads_dir = wp_upload_dir( null, false );
		$uploads_dir = basename( $uploads_dir['basedir'] );
		$uploads_dir = wp_normalize_path( "/{$uploads_dir}/" );
	}

	if ( ! isset( $size_limit ) ) {
		$size_limit = function_exists( 'ini_get' ) ? (int) ini_get( 'upload_max_filesize' ) * MB_IN_BYTES : 0;
		$size_limit = max( $size_limit, 2 * MB_IN_BYTES );

		/**
		 * Filter the file size limit: non-php files larger than this value won't be tested for malware.
		 *
		 * @since 2.0 Default size is (int) ini_get( 'upload_max_filesize' ) or 2 MB
		 * @since 1.3
		 * @author Grégory Viguier
		 *
		 * @param (int) $size_limit File size limit in Bytes. (x * MB_IN_BYTES)
		 */
		$size_limit = apply_filters( 'secupress.file-monitoring.size_limit', $size_limit );
	}

	$result              = [];
	$file_ext            = strtolower( (string) pathinfo( $filepath, PATHINFO_EXTENSION ) );
	$normalized_filepath = wp_normalize_path( $filepath );
	if ( ! $force ) {
		$php_exts = [ 'php' => 1, 'php1' => 1, 'php2' => 1, 'php3' => 1, 'php4' => 1, 'php5' => 1, 'php6' => 1, 'php7' => 1, 'php8' => 1, 'phtml' => 1 ];
	} else {
		$php_exts = [ $file_ext => 1 ];
	}

	$file_size = @filesize( ABSPATH . $filepath );

	foreach ( $malware_tests as $test ) {
		if ( empty( $test[0] ) || 'file' !== trim( $test[0] ) || empty( $test[1] ) || ! is_array( $test[1] ) || isset( $test[1]['str'] ) ) {
			continue;
		}
		foreach ( $test[1] as $filename ) {
			if ( $filename && secupress_malware_filename_is( $normalized_filepath, $filename ) ) {
				$result[] = esc_html__( 'Fake WordPress file known to be used for malware actions', 'secupress' );
				break 2;
			}
		}
	}

	if ( isset( $php_exts[ $file_ext ] ) && ( $file_size > $size_limit ) ) {
		$result[] = sprintf( __( 'Filesize is over the limit of %sMB.', 'secupress' ), round( $size_limit / MB_IN_BYTES ) );
	} elseif ( $file_size >= 23 ) {
		$contents = $filesystem->get_contents( ABSPATH . $filepath );
	}

	// The file is empty: keep filename matches, skip content tests.
	if ( $file_size < 23 ) { // "// Silence is golden."
		if ( $result ) {
			if ( $raw_signatures ) {
				return $result;
			}
			return sprintf( ' <span class="secupress-inline-alert"><span class="screen-reader-text">%1$s</span></span><div class="secupress-toggle-me %2$s hide-if-js"><strong>%3$s</strong>%4$s<hr></div>',
							__( 'Possible malware found', 'secupress' ),
							sanitize_html_class( $filepath ) . ' ' . esc_attr( str_replace( '.', '__', basename( $filepath ) ) ),
							_n( 'Found Signature: ', 'Found Signatures: ', count( $result ), 'secupress' ),
							str_replace( '<code></code>', '', '<code>' . implode( '</code>, <code>', $result ) . '</code>' ) // Yes "code" tags are like that ;)
					);
		}
		return $raw_signatures ? [] : '';
	}

	if ( secupress_get_wpconfig_filename() === trim( $filepath, '/' ) ) {

		$include_patterns = ['include ', "include\t", 'include(', 'include"', 'include\'', 'include_once'];
		$found = false;
		foreach ( $include_patterns as $pattern ) {
			if ( stripos( $contents, $pattern ) !== false ) {
				$found = true;
				break;
			}
		}	
		if ( $found ) {
			$lines = explode("\n", $contents);
			$item  = ' [?]';
			foreach ( $lines as $n => $line ) {
				foreach ($include_patterns as $pattern) {
					if ( stripos( $line, $pattern ) !== false ) {
						$item = "#$n: " . esc_html( trim( $line ) );
						continue 2;
					}
				}
			}
			$result[] = sprintf( __( 'include</code> Your site should also be infected. Check it or ask an expert.<br>Line<code>%s', 'secupress' ), $item ); // Yes "code" tags are like that ;)
		}

		$include_patterns = ['require ', "require\t", 'require(', 'require"', 'require\'', "require_once\t", 'require_once"', 'require_once\'', '@require_once' ];
		$found = false;
		foreach ( $include_patterns as $pattern ) {
			if ( stripos( $contents, $pattern ) !== false ) {
				$found = true;
				break;
			}
		}	
		if ( $found ) {
			$item  = ' [?]';
			$lines = $lines ?? explode("\n", $contents);
			foreach ( $lines as $n => $line ) {
				foreach ($include_patterns as $pattern) {
					if ( stripos( $line, $pattern ) !== false ) {
						$item = "#$n: " . esc_html( trim( $line ) );
						continue 2;
					}
				}
			}
			$result[] = sprintf( __( 'require</code> Your site should also be infected. Check it or ask an expert.<br>Line<code>%s', 'secupress' ), $item ); // Yes "code" tags are like that ;)
		}
	}

	if ( ! $init_done ) {
		$init_done = true;
		secupress_time_limit( 0 );
	}

	foreach ( $malware_tests as $test ) {
		$test_type = isset( $test[0] ) ? trim( $test[0] ) : '';
		if ( 'file' === $test_type ) {
			continue;
		}

		if ( 'php' !== $test_type && $test_type !== $file_ext ) {
			continue;
		}

		if ( 'php' === $test_type && ! isset( $php_exts[ $file_ext ] ) ) {
			continue;
		}

		if ( isset( $test[1]['str'], $test[1]['count'] ) ) {
			if ( substr_count( $contents, $test[1]['str'] ) >= $test[1]['count'] ) {
				$result[] = esc_html( $test[1]['str'] );
				break; // Stop at first match.
			}
			continue;
		}

		$actual_count = 0;

		foreach ( $test[1] as $text ) {
			if ( $text && stripos( $contents, $text ) !== false ) {
				++$actual_count;
			}
		}

		if ( $actual_count && count( $test[1] ) === $actual_count ) {
			$result = array_merge( $result, array_map( 'esc_html', $test[1] ) );
			break; // Stop at first match.
		}
	}
	if ( isset( $php_exts[ $file_ext ] ) && $file_size > 128 ) {
		$filepath = wp_normalize_path( $filepath );

		if ( apply_filters( 'secupress.malware_scan.uploads_tag', true ) && ( strpos( $filepath, '/blogs.dir' ) !== false || strpos( $filepath . '/', $uploads_dir ) !== false ) ) {
			/** Translators: %s is a file extension. */
			$result[] = sprintf( __( '%s in uploads', 'secupress' ), '<code>.php</code>' );
		}
	}

	if ( $result ) {
		// Si on demande les signatures brutes, retourner uniquement le tableau
		if ( $raw_signatures ) {
			return $result;
		}
		// Sinon, retourner le format HTML habituel
		return sprintf( ' <span class="secupress-inline-alert"><span class="screen-reader-text">%1$s</span></span><div class="secupress-toggle-me %2$s hide-if-js"><strong>%3$s</strong>%4$s<hr></div>',
						__( 'Possible malware found', 'secupress' ),
						sanitize_html_class( $filepath ) . ' ' . esc_attr( str_replace( '.', '__', basename( $filepath ) ) ),
						_n( 'Found Signature: ', 'Found Signatures: ', count( $result ), 'secupress' ),
						str_replace( '<code></code>', '', '<code>' . implode( '</code>, <code>', $result ) . '</code>' ) // Yes "code" tags are like that ;)
				);
	}

	return $raw_signatures ? [] : '';
}


/**
 * Tell if a scanned path matches a "file" malware signature (basename or relative path).
 *
 * @since 2.7.1
 * @author Julio Potier
 *
 * @param (string) $filepath Relative file path.
 * @param (string) $filename Signature filename or relative path.
 *
 * @return (bool)
 */
function secupress_malware_filename_is( $filepath, $filename ) {
	$filepath = wp_normalize_path( (string) $filepath );
	$filename = wp_normalize_path( (string) $filename );

	if ( '' === $filepath || '' === $filename ) {
		return false;
	}

	if ( false === strpos( $filename, '/' ) ) {
		return 0 === strcasecmp( basename( $filepath ), $filename );
	}

	$filepath = '/' . ltrim( $filepath, '/' );
	$filename = '/' . ltrim( $filename, '/' );

	if ( strlen( $filepath ) < strlen( $filename ) ) {
		return false;
	}

	return 0 === substr_compare( $filepath, $filename, -strlen( $filename ), strlen( $filename ), true );
}


/**
 * Get the result of the file scanner.
 *
 * @since 2.7.1 Display malware files even when WP core checksums are missing.
 * @since 1.2.4 Remove "old WP files" from the "files that are not part of the WordPress installation".
 * @author Julio Potier
 * @since 1.0
 * @author Grégory Viguier
 *
 * @return (array|false) An array of files, categorized by the reason they are listed. False if never scanned.
 */
function secupress_file_scanner_get_result() {
	global $wp_version;

	$malware_filename = secupress_get_data_file_path( 'malware_keywords' );
	if ( ! file_exists( $malware_filename ) || filesize( $malware_filename ) < 10 ) {
		return false;
	}

	$full_filetree = secupress_file_scanner_get_full_filetree( true );
	if ( false === $full_filetree || empty( $full_filetree[ $wp_version ] ) ) {
		return false;
	}

	$result = [
		/**
		 * Files that are not part of the WordPress installation.
		 */
		'not-wp-files'      => secupress_file_scanner_get_files_not_from_wp(),
		/**
		 * Missing files from WP Core.
		 */
		'missing-wp-files'  => secupress_file_scanner_get_files_missing_from_wp(),
		/**
		 * Old WP files.
		 */
		'old-wp-files'      => secupress_file_scanner_get_old_wp_files(),
		/**
		 * Modified WP Core files.
		 */
		'modified-wp-files' => secupress_file_scanner_get_modified_wp_files(),
		/**
		 * DB Scanner.
		 */
		'database-wp'       => secupress_get_database_scanner(),
		/**
		 * Content Spam.
		 */
		'content-spam'      => secupress_get_content_spam_scanner(),
	];

	if ( $result['not-wp-files'] && $result['old-wp-files'] ) {
		// Remove "old WP files" from the "files that are not part of the WordPress installation".
		$result['not-wp-files'] = array_diff_key( $result['not-wp-files'], $result['old-wp-files'] );
	}

	return $result;
}


/**
 * Get the files that are not part of the WordPress installation.
 * Also checks against the self white-list.
 * Warning: it can also return "files that are not in WordPress core anymore". See `secupress_file_scanner_get_old_wp_files()`.
 *
 * @since 2.7.1 Keep malware files when WP core checksums are missing.
 * @since 1.0
 * @author Julio Potier
 * @author Grégory Viguier
 *
 * @return (array|bool) An array of files. False if never scanned.
 */
function secupress_file_scanner_get_files_not_from_wp() {
	global $wp_version;
	static $wp_content_dir;

	$full_filetree	     = secupress_file_scanner_get_full_filetree( true );
	$wp_core_file_hashes = secupress_file_scanner_get_wp_core_file_hashes();

	if ( false === $full_filetree ) {
		return false;
	}

	if ( empty( $full_filetree[ $wp_version ] ) ) {
		return [];
	}

	if ( ! is_array( $wp_core_file_hashes ) ) {
		$wp_core_file_hashes = [];
	}

	if ( ! isset( $wp_content_dir ) ) {
		$wp_content_dir = str_replace( realpath( ABSPATH ) . '/', '' , realpath( WP_CONTENT_DIR ) );
	}

	$wp_core_file_hashes = apply_filters( 'secupress.plugin.file_scanner.wp_core_file_hashes', $wp_core_file_hashes );
	if ( has_filter( 'secupress.plugin.file_scanner.wp_core_file_hashes' ) ) {
		_deprecated_hook( 'secupress.plugin.file_scanner.wp_core_file_hashes', '2.2.6', 'secupress.plugins.file_scanner.wp_core_file_hashes' );
	}
	/**
	 * Filter the list of WordPress core file paths.
	 *
	 * @since 1.0
	 *
	 * @param (array) $wp_core_file_hashes The list of WordPress core file paths.
	 */
	$wp_core_file_hashes = apply_filters( 'secupress.plugins.file_scanner.wp_core_file_hashes', $wp_core_file_hashes );

	// Add these since it's not in the zip but depends from WordPress.
	$wp_core_file_hashes['.htaccess']					  = '.htaccess';
	$wp_core_file_hashes['web.config']					 = 'web.config';
	$wp_core_file_hashes[ $wp_content_dir . '/debug.log' ] = $wp_content_dir . '/debug.log';


	$full_filetree	   = $full_filetree[ $wp_version ];
	$diff_from_root_core = array_diff_key( $full_filetree, $wp_core_file_hashes );

	$output = array();

	if ( $diff_from_root_core ) {
		$filesystem = secupress_get_filesystem();

		foreach ( $diff_from_root_core as $diff_file => $hash ) {
			if ( $filesystem->exists( ABSPATH . $diff_file ) ) {
				$output[ $diff_file ] = $diff_file;
			}
		}
	}

	return $output;
}


/**
 * Get the files that are missing from WordPress core.
 *
 * @since 2.7.2 Ignore files still on disk: an incomplete filetree must not flag the whole core as missing.
 * @since 1.0
 * @author Julio Potier
 * @author Grégory Viguier
 *
 * @return (array|bool) An array of files. False if never scanned.
 */
function secupress_file_scanner_get_files_missing_from_wp() {
	global $wp_version, $_old_files;

	if ( secupress_file_monitoring_get_instance()->is_scan_active() ) {
		return [];
	}

	$full_filetree	     = secupress_file_scanner_get_full_filetree( true );
	$wp_core_file_hashes = secupress_file_scanner_get_wp_core_file_hashes();

	if ( ! $wp_core_file_hashes || empty( $full_filetree[ $wp_version ] ) ) {
		return array();
	}

	$wp_core_file_hashes	= array_flip( array_filter( array_flip( $wp_core_file_hashes ), 'secupress_filter_no_content' ) );
	$missing_from_root_core = array_diff_key( $wp_core_file_hashes, $full_filetree[ $wp_version ] );
	unset( $missing_from_root_core['wp-config-sample.php'], $missing_from_root_core['readme.html'], $missing_from_root_core['license.txt'] );

	$output = array();

	if ( $missing_from_root_core ) {
		$filesystem = secupress_get_filesystem();
		$abspath    = trailingslashit( wp_normalize_path( ABSPATH ) );

		foreach ( $missing_from_root_core as $file => $hash ) {
			$file = ltrim( str_replace( '\\', '/', $file ), '/' );
			if ( ! $filesystem->exists( $abspath . $file ) ) {
				$output[ $file ] = $file;
			}
		}
	}

	return $output;
}


/**
 * Get the files that are not in WordPress core anymore.
 *
 * @since 1.0
 * @author Julio Potier
 * @author Grégory Viguier
 *
 * @return (array) An array of files.
 */
function secupress_file_scanner_get_old_wp_files() {
	global $_old_files;

	require_once( ABSPATH . 'wp-admin/includes/update-core.php' );

	$output = array();

	if ( $_old_files ) {
		$filesystem = secupress_get_filesystem();

		foreach ( $_old_files as $file ) {
			if ( $filesystem->exists( ABSPATH . $file ) ) {
				$output[ $file ] = $file;
			}
		}
	}

	return $output;
}

/**
 * Shorthand to run the database scanner
 *
 * @since 2.0
 * @author Julio Potier
 *
 **/
function secupress_do_database_scanner() {
	secupress_file_monitoring_get_instance()->do_database_scan();
}


/**
 * Shorthand to run the content spam scanner
 *
 * @since 2.2.6
 * @author Julio Potier
 *
 **/
function secupress_do_content_spam_scanner() {
	secupress_file_monitoring_get_instance()->do_content_spam_scan();
}


/**
 * Get the stored SQL queries containing possible malware as JS/HTML
 *
 * @since 2.7 handle array option
 * @since 2.6.3 empty string is returned as empty array
 * @since 2.2.6 json+rot13
 * @since 2.0
 * @author Julio Potier
 *
 * @see SecuPress_File_Monitoring::do_database_scan()
 *
 * @global $wpdb
 * @return (array)
 **/
function secupress_get_database_scanner() {
	$dbs = get_site_option( SECUPRESS_DATABASE_MALWARES, '' );
	if ( is_array( $dbs ) ) {
		$dbs = str_rot13( json_encode( $dbs ) );
		update_site_option( SECUPRESS_DATABASE_MALWARES, $dbs );
	}
	if ( ! empty( $dbs ) && is_string( $dbs ) ) {
		$dbs = json_decode( str_rot13( $dbs ), true );
		if ( is_array( $dbs ) && ! empty( array_filter( $dbs ) ) ) {
			return $dbs;
		}
	}
	return [];
}

/**
 * Return some keywords tagged as malware in post content
 *
 * @since 2.2.6 Malwares are now loaded from the file + remove params
 * @since 2.0
 * @author Julio Potier
 *
 * @return (array)
 **/
function secupress_get_database_malware_keywords( $_deprecated_key = '', $_deprecated_context = '' ) {
	static $keywords;
	if ( ! empty( $_deprecated_key ) || ! empty( $_deprecated_context ) ) {
		_deprecated_argument( __FUNCTION__, '2.2.6') ;
	}

	if ( isset( $keywords ) ) {
		return $keywords;
	}

	$filename     = secupress_get_data_file_path( 'malware_keywords_db' );
	if ( ! $filename ) {
		return [];
	}
	$keywords     = file_get_contents( $filename );
	if ( ! empty( $keywords ) ) {
		$keywords = json_decode( str_rot13( $keywords ), true );
	}
	if ( json_last_error() > 0 ) {
		$keywords = [];
	}
	/**
	 * Let the possibility the modify the DB scanner keywords
	 * 
	 * @param (array) $keywords
	 */
	$keywords     = apply_filters( 'secupress.database_scanner', $keywords, $_deprecated_context );

	return $keywords;
}

add_action( 'secupress.plugins.loaded', 'secupress_block_malware_get_option', 0 );
/**
 * Hide option names known as malware from get_option() and get_site_option().
 *
 * @since 2.7.2
 * @author Julio Potier
 **/
function secupress_block_malware_get_option() {
	if ( ! secupress_is_pro() ) {
		return;
	}

	$keywords = secupress_get_database_malware_keywords();

	if ( empty( $keywords['opts'] ) || ! is_array( $keywords['opts'] ) ) {
		return;
	}

	$option_names = array_filter( $keywords['opts'], 'is_string' );

	foreach ( array_unique( $option_names ) as $option_name ) {
		if ( '' === $option_name ) {
			continue;
		}

		add_filter( 'pre_option_' . $option_name, 'secupress_pre_get_malware_option', PHP_INT_MAX );
		add_filter( 'pre_site_option_' . $option_name, 'secupress_pre_get_malware_option', PHP_INT_MAX );
	}
}

/**
 * Short-circuit a known malware option read and count it as an option attack.
 *
 * @since 2.7.2
 * @author Julio Potier
 *
 * @return (null)
 **/
function secupress_pre_get_malware_option() {
	static $logged = [];

	$filter = current_filter();
	$prefix = 0 === strpos( $filter, 'pre_site_option_' ) ? 'pre_site_option_' : 'pre_option_';
	$name   = substr( $filter, strlen( $prefix ) );

	if ( $name && ! isset( $logged[ $name ] ) ) {
		$logged[ $name ] = true;
		secupress_log_attack( 'option' );
	}

	return null;
}

/**
 * Get the files from WordPress core that have been modified.
 *
 * @since 1.0
 * @author Grégory Viguier
 *
 * @return (array|bool) An array of files. False if never scanned.
 */
function secupress_file_scanner_get_modified_wp_files() {
	global $wp_version, $_old_files;

	$full_filetree	     = secupress_file_scanner_get_full_filetree( true );
	$wp_core_file_hashes = secupress_file_scanner_get_wp_core_file_hashes();

	if ( false === $full_filetree || false === $wp_core_file_hashes ) {
		return false;
	}

	if ( ! $wp_core_file_hashes || empty( $full_filetree[ $wp_version ] ) ) {
		return [];
	}

	$wp_core_file_hashes = apply_filters( 'secupress.plugin.file_scanner.wp_core_file_hashes', $wp_core_file_hashes );
	if ( has_filter( 'secupress.plugin.file_scanner.wp_core_file_hashes' ) ) {
		_deprecated_hook( 'secupress.plugin.file_scanner.wp_core_file_hashes', '2.2.6', 'secupress.plugins.file_scanner.wp_core_file_hashes' );
	}
	/** This filter is documented in inc/modules/file-system/tools.php */
	$wp_core_file_hashes = apply_filters( 'secupress.plugins.file_scanner.wp_core_file_hashes', $wp_core_file_hashes );
	$full_filetree	     = $full_filetree[ $wp_version ];
	$filesystem		     = secupress_get_filesystem();

	$output = [];

	foreach ( $wp_core_file_hashes as $file => $hash ) {
		if ( isset( $full_filetree[ $file ] ) && ! hash_equals( $hash, $full_filetree[ $file ] ) && $filesystem->exists( ABSPATH . $file ) ) {
			$output[ $file ] = $file;
		}
	}

	return $output;
}


/**
 * Get the site's files tree from the database.
 *
 * @since 1.0
 * @author Grégory Viguier
 *
 * @param (bool) $raw Set to true to get the "raw" decompressed data.
 *
 * @return (array|bool) An array of files. False if never scanned.
 */
function secupress_file_scanner_get_full_filetree( $raw = false ) {
	global $wp_version;

	$full_filetree = secupress_decompress_data( get_site_option( SECUPRESS_FULL_FILETREE ) );

	if ( $raw ) {
		return $full_filetree;
	}

	$full_filetree = is_array( $full_filetree ) ? $full_filetree : array();

	if ( ! isset( $full_filetree[ $wp_version ] ) || ! is_array( $full_filetree[ $wp_version ] ) ) {
		$full_filetree[ $wp_version ] = array();
	}

	return $full_filetree;
}


/**
 * Store the site's files tree into the database.
 *
 * @since 1.0
 * @author Grégory Viguier
 *
 * @param (array) $full_filetree An array of files.
 */
function secupress_file_scanner_store_full_filetree( $full_filetree ) {
	update_site_option( SECUPRESS_FULL_FILETREE, secupress_compress_data( $full_filetree ), false );
}


/**
 * Delete the site's files tree from the database.
 *
 * @since 1.0
 * @author Grégory Viguier
 */
function secupress_file_scanner_delete_full_filetree() {
	delete_site_option( SECUPRESS_FULL_FILETREE );
}


/**
 * Get the WordPress core hashes.
 *
 * @since 1.0
 * @author Grégory Viguier
 *
 * @return (array|bool) An array of hashes. False if never scanned.
 */
function secupress_file_scanner_get_wp_core_file_hashes() {
	global $wp_version;

	$hashes = get_site_option( SECUPRESS_WP_CORE_FILES_HASHES );

	if ( false === $hashes ) {
		return false;
	}

	if ( empty( $hashes[ $wp_version ] ) || ! is_array( $hashes[ $wp_version ] ) ) {
		return array();
	}

	return $hashes[ $wp_version ];
}


/**
 * Used in `array_filter()`: return true if the given path is not in the `wp-content` folder.
 *
 * @since 1.0
 *
 * @param (string) $item A file path.
 *
 * @return (bool)
 */
function secupress_filter_no_content( $item ) {
	static $wp_content;

	if ( ! isset( $wp_content ) ) {
		$wp_content = basename( WP_CONTENT_DIR );
		$wp_content = "/{$wp_content}/";
	}

	$item = str_replace( '\\', '/', $item );

	return strpos( "/{$item}/", $wp_content ) === false;
}

/**
 * Returns the last result for content spam scan
 *
 * @since 2.2.6
 * @author Julio Potier
 * 
 * @return (array)
 */
function secupress_get_content_spam_scanner() {
	$contents = get_site_option( SECUPRESS_CONTENT_SPAM_SCAN, [] );
	if ( ! empty( $contents ) ) {
		$contents = json_decode( str_rot13( $contents ), true );
	}
	return $contents;
}