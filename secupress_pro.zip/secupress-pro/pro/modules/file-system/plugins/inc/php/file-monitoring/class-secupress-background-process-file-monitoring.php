<?php
defined( 'ABSPATH' ) or die( 'Something went wrong.' );


/**
 * Background File Monitoring class.
 *
 * @package SecuPress
 * @since 1.0
 */
class SecuPress_Background_Process_File_Monitoring extends SecuPress_Background_Process {

	const VERSION = '1.0';

	/**
	 * Prefix used to build the global process identifier.
	 *
	 * @var (string)
	 */
	protected $prefix = 'secupress';

	/**
	 * Suffix used to build the global process identifier.
	 *
	 * @var (string)
	 */
	protected $action = 'file_monitoring';


	/**
	 * Task.
	 *
	 * @since 1.0
	 *
	 * @param (string) $item Queue item to iterate over.
	 *
	 * @return (string|bool) Next in queue or false.
	 */
	protected function task( $item ) {
		if ( is_array( $item ) ) {
			if ( empty( $item['action'] ) || ! is_string( $item['action'] ) || ! method_exists( $this, $item['action'] ) ) {
				return false;
			}

			$args = [];
			if ( ! empty( $item['args'] ) && is_array( $item['args'] ) ) {
				$args = $item['args'];
			}

			return call_user_func_array( [ $this, $item['action'] ], $args );
		}

		if ( ! $item || ! is_string( $item ) || ! method_exists( $this, $item ) ) {
			return false;
		}
		return $this->$item();
	}


	/**
	 * Remove everything from the queue.
	 *
	 * @since 1.0
	 */
	public function delete_queue() {
		global $wpdb;

		$table  = $wpdb->options;
		$column = 'option_name';

		if ( is_multisite() ) {
			$table  = $wpdb->sitemeta;
			$column = 'meta_key';
		}

		$key = $this->identifier . '_batch_%';

		$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE {$column} LIKE %s", $key ) ); // WPCS: unprepared SQL ok.

		secupress_delete_site_transient( SECUPRESS_FULL_FILETREE );
		secupress_delete_site_transient( SECUPRESS_DATABASE_MALWARES );
		secupress_delete_site_transient( SECUPRESS_CONTENT_SPAM_SCAN );
		// If we stop before the end, the files tree will be incomplete, we'll have lots of "missing files".
		secupress_file_scanner_delete_full_filetree();
	}


	/**
	 * Is process running.
	 * Check whether the current process is already running in a background process.
	 *
	 * @since 2.6 is_processing() is used instead of is_process_running()
	 * @since 1.0
	 *
	 * @return (bool)
	 */
	public function is_monitoring_running() {
		return $this->is_processing();
	}


	/**
	 * Will store the wp core files hashes (md5), first from the w.org api.
	 *
	 * @since 2.7.3 Checksums follow the installed package locale, not the site locale.
	 * @since 2.7.2 Fallback to en_US when the locale checksums are missing.
	 * @since 2.7.1 Do not persist empty checksums: retry the API until hashes are available.
	 * @since 2.6 Better handling of locales
	 * @since 2.3 Removed the zip call, checksums are always ok (if not, zip won't too)
	 * @since 1.0
	 */
	public function get_wp_hashes() {
		global $wp_version, $wp_local_package;

		$locale        = ! empty( $wp_local_package ) ? $wp_local_package : 'en_US';
		$stored        = get_site_option( SECUPRESS_WP_CORE_FILES_HASHES );
		$stored_locale = ( is_array( $stored ) && isset( $stored['locale'] ) ) ? $stored['locale'] : '';

		if ( is_array( $stored ) && ! empty( $stored[ $wp_version ] ) && is_array( $stored[ $wp_version ] ) && $locale === $stored_locale ) {
			return true;
		}

		$checksums = get_core_checksums( $wp_version, $locale );

		if ( ( empty( $checksums ) || ! is_array( $checksums ) ) && 'en_US' !== $locale ) {
			$checksums = get_core_checksums( $wp_version, 'en_US' );
			$locale    = 'en_US';
		}

		if ( empty( $checksums ) || ! is_array( $checksums ) ) {
			return false;
		}

		$result                 = is_array( $stored ) ? $stored : [];
		$result['locale']      = $locale;
		$result[ $wp_version ] = $checksums;

		$plugins_path = trailingslashit( str_replace( ABSPATH, '', WP_PLUGIN_DIR ) );
		$themes_path  = trailingslashit( str_replace( ABSPATH, '', get_theme_root() ) );

		$core_files = &$result[ $wp_version ];

		foreach ( $core_files as $filename => $hash ) {
			if ( false !== strpos( $filename, $plugins_path ) || false !== strpos( $filename, $themes_path ) ) {
				unset( $core_files[ $filename ] );
			}
		}
		update_site_option( SECUPRESS_WP_CORE_FILES_HASHES, $result );

		return true;
	}


	/**
	 * Will store the possible dists file from wp core files hashes (md5), first from the w.org API, then from the .zip from w.org too.
	 *
	 * @since 1.0
	 *
	 * @param (string) $type
	 * @param (string) $path
	 * @param (string) $pre
	 */
	public function fix_dists( $type = 'branches', $path = '', $pre = '' ) {
		global $wp_version, $wp_local_package;
		static $wp_files_hashes;
		static $flag = false;

		if ( ! isset( $wp_files_hashes ) ) {
			update_site_option( SECUPRESS_FIX_DISTS, [ $wp_version => [] ], false );
		}

		$branch   = 'branches' === $type ? substr( $wp_version, 0, 3 ) : $wp_version;
		$i18n_url = $path ? $path : 'http://i18n.svn.wordpress.org/' . $wp_local_package . '/' . $type . '/' . $branch . '/dist/';
		$response = wp_remote_get( $i18n_url );

		if ( ! is_wp_error( $response ) && 200 === wp_remote_retrieve_response_code( $response ) ) {
			$body       = wp_remote_retrieve_body( $response );
			$links_html = strip_tags( $body, '<a>' );

			preg_match_all( '/>(.*)<\/a>/', $links_html, $matches );

			if ( ! empty( $matches[1] ) ) {
				$links = $matches[1];

				array_shift( $links );
				array_pop( $links );

				foreach ( $links as $dist ) {
					secupress_time_limit( 0 );

					if ( '/' !== substr( $dist, -1 ) ) {
						$response = wp_remote_get( $i18n_url . $dist );

						if ( ! is_wp_error( $response ) && 200 === wp_remote_retrieve_response_code( $response ) ) {
							$content = wp_remote_retrieve_body( $response );
							$wp_files_hashes[ $wp_version ][ $pre . $dist ] = md5( $content );
						}
					} else {
						$this->fix_dists( $type, $i18n_url . $dist, $pre . $dist );
					}
				}
			}
		} elseif ( $flag !== $path ) {
			$this->fix_dists( 'tags', $path, $pre );
			$flag = $path;
		}

		update_site_option( SECUPRESS_FIX_DISTS, $wp_files_hashes, false );
	}


	/**
	 * Init for `get_full_tree()`.
	 *
	 * @since 1.0
	 *
	 * @return (string) Next in queue.
	 */
	public function scan_full_tree() {
		// Be sure to delete everything before starting.
		secupress_file_scanner_delete_full_filetree();
		secupress_set_site_transient( SECUPRESS_FULL_FILETREE, array( ABSPATH ) );

		return 'get_full_tree';
	}


	/**
	 * Wrapper for `get_file_tree()` with full recursivity.
	 *
	 * @since 1.0
	 *
	 * @return (string|bool) 'get_full_tree' while scanning, then false when finished.
	 */
	public function get_full_tree() {
		if ( $this->get_file_tree() ) {
			// There are still files to fetch.
			return 'get_full_tree';
		}

		// OK, we're done.
		return false;
	}


	public function scan_db_pattern( $type = '', $items = [] ) {
		global $wpdb;

		if ( empty( $type ) || empty( $items ) || ! is_array( $items ) ) {
			return false;
		}

		$items = array_values( array_filter( $items ) );

		if ( empty( $items ) ) {
			return false;
		}

		$post_results = [];
		$opt_results  = [];

		if ( 'posts' === $type ) {
			$post_conditions = [];
			$opt_conditions  = [];
			$values          = [];

			foreach ( $items as $item ) {
				$values[]          = '%' . $wpdb->esc_like( $item ) . '%';
				$post_conditions[] = 'post_content LIKE %s';
				$opt_conditions[]  = 'option_value LIKE %s';
			}

			$post_sql = 'SELECT ID, post_content FROM ' . $wpdb->posts . ' WHERE ( ' . implode( ' AND ', $post_conditions ) . ' )';
			$post_sql = $wpdb->prepare( $post_sql, $values );
			$opt_sql  = 'SELECT option_name, option_value FROM ' . $wpdb->options . ' WHERE ( ' . implode( ' AND ', $opt_conditions ) . ' )';
			$opt_sql  = $wpdb->prepare( $opt_sql, $values );

			$post_results = $wpdb->get_results( $post_sql, ARRAY_A );
			$opt_results  = $wpdb->get_results( $opt_sql, ARRAY_A );
		}

		if ( 'opts' === $type ) {
			$conditions = [];
			$values     = [];

			foreach ( $items as $item ) {
				$conditions[] = 'option_name = %s';
				$values[]     = $item;

				$transient_like = '%\_transient\_%' . $wpdb->esc_like( $item );
				$conditions[]   = 'option_name LIKE %s';
				$values[]       = $transient_like;
			}

			$opt_sql      = 'SELECT option_name, option_value FROM ' . $wpdb->options . ' WHERE ( ' . implode( ' OR ', $conditions ) . ' )';
			$opt_sql      = $wpdb->prepare( $opt_sql, $values );
			$opt_results  = $wpdb->get_results( $opt_sql, ARRAY_A );
		}

		if ( 'cpts' === $type ) {
			$placeholders = implode( ', ', array_fill( 0, count( $items ), '%s' ) );
			$post_sql     = 'SELECT ID, post_content FROM ' . $wpdb->posts . ' WHERE post_type IN ( ' . $placeholders . ' )';
			$post_sql     = $wpdb->prepare( $post_sql, $items );
			$post_results = $wpdb->get_results( $post_sql, ARRAY_A );
		}

		$stored = get_site_option( SECUPRESS_DATABASE_MALWARES, '' );

		if ( is_array( $stored ) ) {
			$stored = str_rot13( json_encode( $stored ) );
		}

		if ( ! empty( $stored ) && is_string( $stored ) ) {
			$stored = json_decode( str_rot13( $stored ), true );
		}

		if ( empty( $stored ) || ! is_array( $stored ) ) {
			$stored = [];
		}

		if ( empty( $stored['posts'] ) || ! is_array( $stored['posts'] ) ) {
			$stored['posts'] = [];
		}

		if ( empty( $stored['opt_val'] ) || ! is_array( $stored['opt_val'] ) ) {
			$stored['opt_val'] = [];
		}

		if ( ! empty( $post_results ) ) {
			$post_index = [];
			foreach ( $stored['posts'] as $row ) {
				if ( isset( $row['ID'] ) ) {
					$post_index[ $row['ID'] ] = $row;
				}
			}
			foreach ( $post_results as $row ) {
				if ( isset( $row['ID'] ) ) {
					$post_index[ $row['ID'] ] = $row;
				}
			}
			$stored['posts'] = array_values( $post_index );
		}

		if ( ! empty( $opt_results ) ) {
			$batch_prefix = 'secupress_file_monitoring_batch';
			foreach ( $opt_results as $index => $row ) {
				if ( isset( $row['option_name'] ) && 0 === strpos( $row['option_name'], $batch_prefix ) ) {
					unset( $opt_results[ $index ] );
				}
			}
			if ( empty( $opt_results ) ) {
				$opt_results = [];
			}
		}

		if ( ! empty( $opt_results ) ) {
			$opt_index = [];
			foreach ( $stored['opt_val'] as $row ) {
				if ( isset( $row['option_name'] ) ) {
					$opt_index[ $row['option_name'] ] = $row;
				}
			}
			foreach ( $opt_results as $row ) {
				if ( isset( $row['option_name'] ) ) {
					$opt_index[ $row['option_name'] ] = $row;
				}
			}
			$stored['opt_val'] = array_values( $opt_index );
		}

		update_site_option( SECUPRESS_DATABASE_MALWARES, str_rot13( json_encode( array_filter( $stored ) ) ) );

		return false;
	}


	/**
	 * Will store the wp core files hashes (md5), first from the w.org api, then from the .zip from w.org too.
	 *
	 * @since 1.0
	 *
	 * @param (array) $args An array of arguments.
	 *                      (array) $ext_filter An array of file extensions: only files with those extensions will be fetched. Empty to get everything.
	 *                      (array) $ignore     An array of folders and files to ignore (absolute path).
	 *
	 * @return (bool) True if there are still some folders to scan. False otherwise.
	 */
	public function get_file_tree( $args = array() ) {
		global $wp_version;
		static $abspath;
		static $init_done = false;
		static $hashes;

		if ( ! secupress_get_data_file_path( 'malware_keywords' ) ) {
			return false;
		}

		if ( ! $init_done ) {
			$init_done = true;
			secupress_maybe_increase_memory_limit();
		}

		if ( ! isset( $abspath ) ) {
			$abspath = trailingslashit( wp_normalize_path( ABSPATH ) );
		}

		if ( ! isset( $hashes ) ) {
			$hashes = secupress_file_scanner_get_wp_core_file_hashes();
		}

		// Folders to scan.
		$paths = secupress_get_site_transient( SECUPRESS_FULL_FILETREE );

		if ( ! $paths ) {
			// The end, nothing more to scan.
			secupress_delete_site_transient( SECUPRESS_FULL_FILETREE );
			return false;
		}

		$paths = array_filter( (array) $paths, 'is_dir' );

		if ( ! $paths ) {
			// The fuck?
			secupress_delete_site_transient( SECUPRESS_FULL_FILETREE );
			return false;
		}

		$result = secupress_file_scanner_get_full_filetree( true );
		if ( ! is_array( $result ) ) {
			$result = [];
		}

		$ext_filter = ! empty( $args['ext_filter'] ) ? array_flip( array_map( 'strtolower', (array) $args['ext_filter'] ) ) : array();
		$ignore     = ! empty( $args['ignore'] )     ? array_flip( (array) $args['ignore'] )                                : array();

		$dir   = array_shift( $paths );
		$files = scandir( $dir );
		$files = array_diff( $files, array( '.', '..' ) );

		$update_result = false;

		if ( $files ) {
			$wp_hashes = get_site_option( SECUPRESS_WP_CORE_FILES_HASHES );
			$wp_hashes = ! empty( $wp_hashes[ $wp_version ] ) && is_array( $wp_hashes[ $wp_version ] ) ? $wp_hashes[ $wp_version ] : array();
			$new_paths = array();

			foreach ( $files as $file_or_dir_name ) {
				// We must not use `realpath()`, otherwise `str_replace( $abspath,...` will fail for symlinked files.
				$file_or_dir = wp_normalize_path( $dir . '/' . $file_or_dir_name );

				if ( isset( $ignore[ $file_or_dir ] ) ) {
					continue;
				}

				if ( ! is_file( $file_or_dir ) ) {
					// Probably a directory.
					$new_paths[] = $file_or_dir;
					continue;
				}

				if ( $ext_filter ) {
					$file_ext = strtolower( pathinfo( $file_or_dir, PATHINFO_EXTENSION ) );

					if ( ! isset( $ext_filter[ $file_ext ] ) ) {
						continue;
					}
				}

				if ( $abspath && 0 === strpos( $file_or_dir, $abspath ) ) {
					$key = substr( $file_or_dir, strlen( $abspath ) );
				} else {
					$key = str_replace( $abspath, '', $file_or_dir );
				}
				$key = ltrim( str_replace( '\\', '/', $key ), '/' );

				if ( empty( $hashes[ $key ] ) && ! secupress_check_malware( $key ) ) {
					// If not a WP core file, keep only files that are possibly a malware.
					continue;
				}

				$update_result = true;
				// If the file is not listed in the WP hashes, no need to calculate the md5.
				$result[ $wp_version ][ $key ] = ! empty( $wp_hashes[ $key ] ) ? md5_file( $file_or_dir ) : $file_or_dir;
			}

			// Put new paths at the beginning. Not really important, it simply feels more logic.
			$paths = array_merge( $new_paths, $paths );
			if ( $update_result  ) {
				secupress_file_scanner_store_full_filetree( $result );
			}
		}

		if ( $paths ) {
			// We have still folders to scan.
			secupress_set_site_transient( SECUPRESS_FULL_FILETREE, $paths );
			return true;
		}

		// The end, nothing more to scan.
		secupress_delete_site_transient( SECUPRESS_FULL_FILETREE );
		return false;
	}
}
